set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
filter='Category!=Stress&(FullyQualifiedName~IteratorAdapter|FullyQualifiedName~IteratorProtocol|FullyQualifiedName~IteratorValueAccounting|FullyQualifiedName~BuiltinIteratorSequence|FullyQualifiedName~ManagedStackGuard|FullyQualifiedName~ExecutableStackAdmission|FullyQualifiedName~ZipNative|FullyQualifiedName~CopiedFileCancellation)'
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="../$suite-ubuntu10.log"
    if dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --artifacts-path ../ubuntu --filter "$filter" > "$log" 2>&1; then
        tail -6 "$log"
    else
        tail -55 "$log"
        exit 1
    fi
done