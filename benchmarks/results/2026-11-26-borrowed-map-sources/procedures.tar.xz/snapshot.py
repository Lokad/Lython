from pathlib import Path
from io import BytesIO
import subprocess,sys,zipfile

lab=Path(sys.argv[1]).resolve()
root=lab.parents[3]
source=lab/'source'
source.mkdir()
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert revision=='d370fef841a12d53087ab0fc3bf41da7a86d9084'
snapshot=subprocess.check_output(['git','archive','--format=zip',revision,'--','src','tests','tools','docs',
    'Directory.Build.props','Directory.Build.targets','Directory.Build.rsp','Directory.Packages.props',
    'global.json','NuGet.Config','AGENTS.md','.editorconfig','.gitattributes','.gitignore','README.md','LICENSE.txt',
    'THIRD_PARTY_NOTICES.md','CHANGELOG.md','icon.png','Lokad.Lython.slnx'],cwd=root)
with zipfile.ZipFile(BytesIO(snapshot)) as files:
    assert all(not Path(x.filename).is_absolute() and '..' not in Path(x.filename).parts for x in files.infolist())
    files.extractall(source)
(lab/'base-revision.txt').write_text(revision+'\n',encoding='utf-8')
print(source)
