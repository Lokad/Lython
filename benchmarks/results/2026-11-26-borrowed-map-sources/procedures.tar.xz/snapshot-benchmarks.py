from pathlib import Path
from io import BytesIO
import subprocess,sys,zipfile
lab=Path(sys.argv[1]).resolve()
revision=(lab/'base-revision.txt').read_text().strip()
revision_archive=subprocess.check_output(['git','archive','--format=zip',revision,'--',
    'benchmarks/Lokad.Lython.Benchmarks','benchmarks/scripts','benchmarks/cpython-worker.py'],cwd=lab.parents[3])
with zipfile.ZipFile(BytesIO(revision_archive)) as files:
    assert all(not Path(x.filename).is_absolute() and '..' not in Path(x.filename).parts for x in files.infolist())
    files.extractall(lab/'source')
