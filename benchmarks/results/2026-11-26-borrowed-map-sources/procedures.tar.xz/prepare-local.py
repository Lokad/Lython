from pathlib import Path
import hashlib,json,shutil

lab=Path(__file__).resolve().parent
local=lab/'local'
prior=lab.with_name('deferred-site-placement-20261126')/'local'
source=lab.with_name('json-ascii-character-20261126')/'comparison/repeat'
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
write=lambda path,data:path.write_text(data,encoding='utf-8',newline='\n')

identity=read(local/'identity.json')
previous=read(source/'identity.json')
assert identity['imageFiles']['reference']==previous['imageFiles']['candidate']
assert identity['catalogSHA256']==sha(local/'representative.json')
jobs={'warm': [
    ['diagnostic.shipment-routing-callbacks','warm'],
    ['diagnostic.shipment-file-fed-map','warm-async'],
    ['diagnostic.shipment-routing-callbacks','warm-async'],
    ['scripts.csv-meter-report.explicit-float','warm'],
]}
write(local/'jobs.json',json.dumps(jobs,indent=2)+'\n')
identity['coreSHA256']={r+s:v['Lokad.Lython.dll'] for r,v in identity['imageFiles'].items() for s in ('','-control')}
identity['catalogs']={name:{'sha256':sha(local/name)} for name in ('representative.json','jobs.json')}
identity['expectedCPythonSHA256']=previous['expectedCPythonSHA256']
identity['purpose']='Retire cursor allocation and forwarding around existing map inputs.'
write(local/'identity.json',json.dumps(identity,indent=2)+'\n')
collector=(prior/'collect.py').read_text(encoding='utf-8')
assert collector.count('lython-deferred-site-placement-fixture-')==1
collector=collector.replace('lython-deferred-site-placement-fixture-','lython-borrowed-map-sources-fixture-')
compile(collector,'collect.py','exec')
write(local/'collect.py',collector)
shutil.copyfile(prior/'run.sh',local/'run.sh')
assert b'\r' not in (local/'run.sh').read_bytes()
shutil.copyfile(prior.parent/'summarize.py',lab/'summarize.py')
