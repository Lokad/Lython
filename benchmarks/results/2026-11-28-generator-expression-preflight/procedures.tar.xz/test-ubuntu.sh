#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython
lab=.git/agent-notes/review-20261031/generator-expression-preflight-b1952-20261128
export NUGET_PACKAGES=$PWD/.git/agent-notes/review-20261031/regex-released-050-20261127/packages-ubuntu
log="$lab/ubuntu-core-build.log"
~/.dotnet/dotnet build src/Lokad.Lython/Lokad.Lython.csproj -c Release -f net11.0 --artifacts-path "$lab/ubuntu-artifacts" --no-incremental --disable-build-servers > "$log" 2>&1 || { tail -55 "$log"; exit 1; }
tail -5 "$log"
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
  if [[ $suite = Lokad.Lython.Tests ]]; then
    filter='Category!=Stress&(FullyQualifiedName~Generator|FullyQualifiedName~RecordFieldLookup|FullyQualifiedName~Sum|FullyQualifiedName~StackAdmission|FullyQualifiedName~IterationWorkspace|FullyQualifiedName~ExecutableOperandStackBoundary|FullyQualifiedName~ExecutableCall)'
  else
    filter='Category!=Stress&(FullyQualifiedName~Generator|FullyQualifiedName~RecordFieldLookup|FullyQualifiedName~Sum|FullyQualifiedName~BuiltinIterationCancellation|FullyQualifiedName~IteratorScalarIdentity|FullyQualifiedName~AdmissionFailureCommandTests|FullyQualifiedName~BoundedDrain|FullyQualifiedName~CallArgument)'
  fi
  log="$lab/ubuntu-$suite-net11.0.log"
  ~/.dotnet/dotnet test "tests/$suite/$suite.csproj" -c Release -f net11.0 --artifacts-path "$lab/ubuntu-artifacts" --filter "$filter" > "$log" 2>&1 || { tail -55 "$log"; exit 1; }
  tail -2 "$log"
done
