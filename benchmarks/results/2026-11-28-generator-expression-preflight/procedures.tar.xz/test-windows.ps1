$lab='.git/agent-notes/review-20261031/generator-expression-preflight-b1952-20261128'
$exe=Join-Path $env:USERPROFILE '.dotnet11/dotnet.exe'
$filters=[ordered]@{
 'Lokad.Lython.Tests'='Category!=Stress&(FullyQualifiedName~Generator|FullyQualifiedName~RecordFieldLookup|FullyQualifiedName~Sum|FullyQualifiedName~StackAdmission|FullyQualifiedName~IterationWorkspace|FullyQualifiedName~ExecutableOperandStackBoundary|FullyQualifiedName~ExecutableCall)'
 'Lokad.Lython.PublicApi.Tests'='Category!=Stress&(FullyQualifiedName~Generator|FullyQualifiedName~RecordFieldLookup|FullyQualifiedName~Sum|FullyQualifiedName~BuiltinIterationCancellation|FullyQualifiedName~IteratorScalarIdentity|FullyQualifiedName~AdmissionFailureCommandTests|FullyQualifiedName~BoundedDrain|FullyQualifiedName~CallArgument)'
}
foreach ($tfm in 'net11.0','net10.0') {
  foreach ($entry in $filters.GetEnumerator()) {
    $suite=$entry.Key
    $log="$lab/windows-$suite-$tfm.log"
    & $exe test "tests/$suite/$suite.csproj" -c Release -f $tfm --filter $entry.Value *> $log
    $code=$LASTEXITCODE
    if ($code -ne 0) { Get-Content $log -Encoding utf8 -Tail 55; exit $code }
    Get-Content $log -Encoding utf8 -Tail 2
  }
}
