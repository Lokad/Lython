from hashlib import sha256
from pathlib import Path
from shutil import copy2, copytree
from subprocess import check_output
import json

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
base = lab.parent / 'generator-expression-lookup-b1951-20261128'
prior = base / 'comparison'
pair = lab / 'comparison'
build = lab / 'ubuntu-artifacts/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
files = lambda folder: {path.name: digest(path) for path in folder.iterdir()}

def git(*args):
    return check_output(['git', *args], cwd=repo)

def write(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8', newline='\n')

old = read(prior / 'identity.json')
head = git('rev-parse', 'HEAD').decode().strip()
assert head.startswith('52ba7a052')
assert sha256(git('diff', '--binary', old['sourceRevision'], head, '--', 'src/Lokad.Lython', 'tests')).hexdigest() == old['sourcePatchSHA256']
assert not git('diff', '--binary', head, '--', 'Directory.Packages.props', 'src/Lokad.Lython.Utf8Regex')
frozen = old['imageFiles']['candidate']
assert len(frozen) == 32 and files(prior / 'candidate') == frozen
pair.mkdir()
for role in ('reference', 'candidate'):
    copytree(prior / 'candidate', pair / role)
copy2(build, pair / 'candidate/Lokad.Lython.dll')
assert not (pair / 'candidate/Lokad.Lython.dll').samefile(build)
images = {role: files(pair / role) for role in ('reference', 'candidate')}
assert {name for name, checksum in frozen.items() if images['candidate'][name] != checksum} == {'Lokad.Lython.dll'}
assert images['reference'] == frozen
patch = git('diff', '--binary', head, '--', 'src/Lokad.Lython', 'tests')
(lab / 'candidate.patch').write_bytes(patch)
for name in ('representative.json', 'cpython-worker.py', 'run.sh'):
    copy2(prior / name, pair / name)
assert digest(pair / 'representative.json') == old['catalogs']['representative.json']['sha256']
assert digest(pair / 'cpython-worker.py') == old['cpythonWorkerSHA256']
jobs = read(prior / 'jobs.json')['warm']
assert len(jobs) == 6 and jobs[0] == ['diagnostic.shipment-row-range-generator-reduction', 'warm']
jobs = jobs[1:]
write(pair / 'jobs.json', dict(warm=jobs))
write(pair / 'identity.json', dict(sourceRevision=head, sourcePatchSHA256=sha256(patch).hexdigest(),
    imageFiles=images, coreSHA256={r+s: v['Lokad.Lython.dll'] for r, v in images.items() for s in ('', '-control')},
    expectedCPythonSHA256=old['expectedCPythonSHA256'], cpythonWorkerSHA256=old['cpythonWorkerSHA256'],
    catalogs={name: {'sha256': digest(pair / name)} for name in ('representative.json', 'jobs.json')},
    purpose='Coalesce generator-expression shell and initial executable slot admission.'))
collector = (prior / 'collect.py').read_text(encoding='utf-8')
assert collector.count('len(jobs) == 6') == 1
(pair / 'collect.py').write_text(collector.replace('len(jobs) == 6', 'len(jobs) == 5'), encoding='utf-8', newline='\n')
summary = (base / 'summarize.py').read_text(encoding='utf-8')
assert summary.count('== 6') == 1 and summary.count('== 168') == 1
(lab / 'summarize.py').write_text(summary.replace('== 6', '== 5').replace('== 168', '== 140'), encoding='utf-8', newline='\n')
copy2(base / 'measure-allocation.py', lab / 'measure-allocation.py')
assert b'\r' not in (pair / 'run.sh').read_bytes()
print('Frozen 32 files per image. Five scoped lanes and same-image controls.')
