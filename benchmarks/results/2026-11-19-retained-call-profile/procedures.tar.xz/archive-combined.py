from pathlib import Path
import shutil,hashlib,json,tarfile

follow=Path(__file__).resolve().parent
first=follow.parent/'retained-call-profile-r641'
out=Path('benchmarks/results/2026-11-19-retained-call-profile')
load=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
measured=[]
for lab,name,expected,partial in [(first,'B1070',['rules'],True),(follow,'B1071',['siblings','forwarding'],False)]:
    receipt=load(lab/'archive-receipt.json')
    terminal=load(lab/'terminal-status.json')
    assert receipt==terminal['receipt'] and (terminal['exitCode']=='0')!=partial
    assert receipt['complete'] != partial and all(receipt[key] for key in ('allWorkersJoined','guestFixturesRemoved',
        'quietBeforeAndAfter','archivedAndVerifiedUnderLease','ramTraceArchivedAndVerifiedBeforeUnmount'))
    assert not terminal['remainingWorkers'] and not terminal['remainingTrace']
    assert hashlib.sha256((lab/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
    identity=load(lab/'identity.json')
    catalog={item['id']:item for item in load(lab/'catalog.json')['cases']}
    assert identity['sourceRevision']=='12fabffb1' and len(identity['imageFiles']['candidate'])==32
    rows=load(lab/'attribution.json')['rows']
    assert [row['label'] for row in rows]==expected
    for row in rows:
        record=load(lab/'retrieved/profiles'/row['label']/'record.json')
        assert record['exitCode']==0 and record['closed']['status']=='Closed' and record['warmupSeconds']>=8
        case=catalog[row['case']]
        for check in ('verificationBefore','verificationAfter'):
            assert record[check]['actualOutputSha256']==case['expectedOutputSha256']
            assert record[check].get('actualFilesSha256')==case.get('expectedFilesSha256')
        measured.append(row|dict(collection=name))
    target=out/name.lower();target.mkdir(parents=True,exist_ok=False)
    for filename in ('observations.tgz','archive-receipt.json','terminal-status.json','identity.json'):
        shutil.copyfile(lab/filename,target/filename)
with tarfile.open(out/'procedures.tar.xz','w:xz',preset=6) as tar:
    for lab,prefix in ((first,'b1070'),(follow,'b1071')):
        for name in ('prepare.py','catalog.json','config.json','collect.py','ops-profile.py','run.sh','launch.py','launch.log',
                     'observe-not-before.json','analyze.py','retrieve.py','retrieval.log','remote-launch.py','verify.json',
                     'quiet-space.json','original-analyze.py','analysis.log'):
            if (lab/name).is_file():tar.add(lab/name,arcname=prefix+'/'+name)
    tar.add(follow/'archive-combined.py',arcname='archive-combined.py')
(out/'attribution.json').write_text(json.dumps(dict(sourceRevision='12fabffb1',diagnosticOnly=True,rows=measured),indent=2)+'\n',encoding='utf-8',newline='\n')
for row in measured:
    print(row['label'],row['guestRuntimeAncestry'], row['guestRuntimeFocus']['definition execution'],
          row['guestRuntimeFocus']['borrowed invocation'],row['nearestReserveCallers'][:8],
          row['nearestRuntimeMethods'][:12])
