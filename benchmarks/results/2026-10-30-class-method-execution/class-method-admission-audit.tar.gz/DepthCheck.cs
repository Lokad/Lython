using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;

var fixture = Assembly.LoadFrom(Path.Combine(AppContext.BaseDirectory, "Lokad.Lython.WorkerFixture.dll"));
var hostType = fixture.GetType("Lokad.Lython.Tests.Harness.DelayedLythonHost", throwOnError: true)!;
var host = (ILythonHost)Activator.CreateInstance(hostType, nonPublic: true)!;
hostType.GetMethod("SeedFile")!.Invoke(host, ["/ready", "ready"]);
var body = args[0] == "descriptor" ? """
    class Slot:
        def __get__(self,obj,owner):return owner[0]
    class Loop:__class_getitem__=Slot()
    Loop[0]
    """ : """
    class Loop:
        def __class_getitem__(cls,key):return cls[key]
    Loop[0]
    """;
using var script = new LythonEngine().Compile("with open('/ready') as stream:\n stream.read()\n" + body);
using var result = await script.RunAsync(host, new LythonRunOptions { MemoryBudget = new LythonMemoryBudget(16 * 1024 * 1024) });
var completed = (int)hostType.GetProperty("CompletedAsynchronously")!.GetValue(host)!;
Console.WriteLine(JsonSerializer.Serialize(new
{
    scenario = args[0], result.Success, error = result.Failure?.ExceptionType,
    message = result.Failure?.Message, frames = result.Failure?.StackTrace.Count,
    result.FailureAttribution, reason = result.FailureAttribution?.Reason.ToString(), completed,
    library = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))),
}));
return !result.Success && result.FailureAttribution?.Reason is LythonFailureReason.InterpreterStackLimit or LythonFailureReason.RecursionDepthLimit && completed > 0 ? 0 : 1;
