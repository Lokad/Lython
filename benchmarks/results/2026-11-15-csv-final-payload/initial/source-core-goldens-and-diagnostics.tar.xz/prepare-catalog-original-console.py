from pathlib import Path
import base64,csv,hashlib,importlib.util,io,json,subprocess,tempfile
r=Path(__file__).parent;old=r.parent/'closed-word-segment-r376/refinement'
catalog=json.loads((old/'catalog.json').read_text(encoding='utf-8'));template=next(v for v in catalog['cases']if v['id']=='scripts.csv-invoice.large')
source=Path('benchmarks/scripts/csv-validated-records.py').read_text(encoding='utf-8').replace('\r\n','\n')
n=1024;stream=io.StringIO(newline='');writer=csv.writer(stream,lineterminator='\n');writer.writerow(['kind','amount','note','reference'])
north='north-america / standard';europe='europe / priority'
rows=[(north,3,'café, "quoted"\ncustomer delivery 😀','customer-reference-north-0001'),
      (europe,2,'customer 😀 delivery annotation','customer-reference-europe-0002'),
      (north,-1,'skip','customer-reference-north-0003'),
      (europe,5,'confirmed shipment annotation','customer-reference-europe-0004'),
      (north,9,'skip','customer-reference-north-0005')]
for _ in range(n):writer.writerows(rows)
inputBytes=stream.getvalue().encode('utf-8');report=f'kind,total\n{europe},{7*n}\n{north},{3*n}\n'.encode('utf-8');stdout=f'{3*n}\n'
with tempfile.TemporaryDirectory(prefix='lython-csv-golden-')as directory:
 root=Path(directory);(root/'input.csv').write_bytes(inputBytes);(root/'workload.py').write_text(source,encoding='utf-8',newline='\n')
 done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8',str(root/'workload.py')],cwd=root,capture_output=True,timeout=30)
 assert done.returncode==0 and done.stdout==stdout.encode('utf-8') and not done.stderr,done.stderr
 assert(root/'report.csv').read_bytes()==report
fixture=json.loads(template['fixtureJson']);fixture.update(size=n,text=None,inputFiles={'input.csv':base64.b64encode(inputBytes).decode()},outputFiles={'report.csv':base64.b64encode(report).decode()})
fixtureJson=json.dumps(fixture,ensure_ascii=False,separators=(',',':'))
spec=importlib.util.spec_from_file_location('protocol','benchmarks/cpython-worker.py');protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
digest=lambda text:hashlib.sha256(text.encode('utf-8')).hexdigest()
case=dict(template,id='diagnostic.csv-validated-records.long-fields.large',size=n,source=source,fixtureJson=fixtureJson,expectedOutput=stdout,sourceUtf8Bytes=len(source.encode('utf-8')),expectedOutputUtf8Bytes=len(stdout.encode('utf-8')),fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,sourceSha256=digest(source),fixtureSha256=digest(fixtureJson),expectedOutputSha256=digest(stdout),expectedFilesSha256=protocol.file_digest({'report.csv':report}))
catalog['cases'].append(case);(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
(r/'long-fields-case.json').write_text(json.dumps(case,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
(r/'fixture-design.json').write_text(json.dumps(dict(source='Unchanged maintained csv-validated-records.py',purpose='Complete metadata-heavy CSV aggregation with three long string columns, multiline quoted Unicode notes and ordinary numeric/filter paths. Source/fixture identical between core roles; data-specific diagnostic, not a gain claim for short-field CSV.',rows=5*n,inputBytes=len(inputBytes),expectedStdout=stdout,expectedReport=report.decode('utf-8'),independentExpectedTotals='Manual3naccepted,Europe7n,North3n; separately verified isolatedCPython3.13.2',independentCPythonVersion=subprocess.check_output(['C:/Python313/python.exe','--version'],text=True).strip(),publicationHeld=True),indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
print('Existing complete source,5120metadata-heavy rows,',len(inputBytes),'input bytes; independent totals/isolated CPython match.')
