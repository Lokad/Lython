from pathlib import Path
import json,os,subprocess,time
r=Path(__file__).parent;sdk='C:/Users/JoannesVermorel/.dotnet11'
env={k:v for k,v in os.environ.items()if k.casefold()!='path'};env['DOTNET_ROOT']=sdk;env['PATH']=sdk+';C:/Python313;'+next(v for k,v in os.environ.items()if k.casefold()=='path')
assert 'Passed:     1' in(r/'reference-funding-test.log').read_text(encoding='utf-8')
records=[]
for tfm in ['net11.0','net10.0']:
 for project in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:
  log=r/(project+'-'+tfm+'.log');assert not log.exists();start=time.monotonic()
  with log.open('w',encoding='utf-8')as output:
   done=subprocess.run([sdk+'/dotnet.exe','test',f'tests/{project}/{project}.csproj','-c','Release','-f',tfm,'--filter','(Category!=Stress)&FullyQualifiedName~Csv','--logger','trx;LogFileName=r379-'+project+'-'+tfm+'.trx'],env=env,stdout=output,stderr=subprocess.STDOUT,timeout=180)
  records.append(dict(framework=tfm,project=project,exitCode=done.returncode,elapsedSeconds=time.monotonic()-start));(r/'focused-checks.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n');print(tfm,project,done.returncode,log.read_text(encoding='utf-8')[-4000:],flush=True)
  assert done.returncode==0
