from pathlib import Path
import ast,hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;old=r.parent/'closed-word-segment-r376/refinement';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
checks=json.loads((r/'focused-checks.json').read_text(encoding='utf-8'));assert len(checks)==4 and all(v['exitCode']==0 for v in checks)
prior=json.loads((old/'candidate-identity.json').read_text(encoding='utf-8'));sources={p:sha(p)for p in prior['sources']}
changed=[p for p,h in sources.items()if prior['sources'][p]!=h];assert changed==['src/Lokad.Lython/Runtime/LythonRuntime.CsvModule.cs']
sdk='C:/Users/JoannesVermorel/.dotnet11';env={k:v for k,v in os.environ.items()if k.casefold()!='path'};env['DOTNET_ROOT']=sdk;env['PATH']=sdk+';C:/Python313;'+next(v for k,v in os.environ.items()if k.casefold()=='path')
with(r/'freeze-build.log').open('w',encoding='utf-8')as f:done=subprocess.run([sdk+'/dotnet.exe','build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-restore','--no-incremental','-m:1','-v','quiet'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=120)
assert done.returncode==0,(r/'freeze-build.log').read_text(encoding='utf-8')
assert all(sha(p)==h for p,h in sources.items())
for role in ['reference','candidate']:shutil.copytree(old/'candidate',r/role)
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'candidate/Lokad.Lython.dll');shutil.copyfile(r/'candidate/Lokad.Lython.dll',r/'candidate-core.dll')
assert sha(r/'reference/Lokad.Lython.dll')==prior['coreSHA256']['candidate']
assert all(sha(r/role/name)==h for role in ['reference','candidate']for name,h in prior['auxiliaryFiles'].items())
identity=dict(headBeforeCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),referenceRuntimeCommit='ec6c041672a5e6edf85676bfe2442cd62abe1b76',referenceFullQualification='43669461343GREENterminalcached',sources=sources,productionFiles=len(sources),changedProductionInputs=changed,coreSHA256={role:sha(r/role/'Lokad.Lython.dll')for role in ['reference','candidate']},auxiliaryFiles=prior['auxiliaryFiles'],frozenFiles={role:{p.name:sha(p)for p in(r/role).iterdir()if p.is_file()}for role in ['reference','candidate']},qualified=False,status='R379 active one-final-CSV-payload prototype;118internal/390public per actual11/10 pass, funding regression passes reference first. No retention or CPU qualification yet.')
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as archive:
 for p in sources:archive.add(p,arcname=p)
catalog=json.loads((r/'catalog.json').read_text(encoding='utf-8'));ids=['diagnostic.csv-validated-records.long-fields.large','scripts.csv-invoice.large','scripts.csv-fulfillment.large','scripts.text-summary-helpers.nonlocal-counter.large']
goldens=dict(catalog,cases=[next(c for c in catalog['cases']if c['id']==name)for name in ids]);(r/'allocation-catalog.json').write_text(json.dumps(goldens,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
allocation=dict(catalog,cases=goldens['cases'][:3])
for role in ['reference','candidate']:(r/('allocation-'+role+'-catalog.json')).write_text(json.dumps(allocation,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
s=(old/'verify.py').read_text(encoding='utf-8');a=s.index("worker=r.parent.parent/");b=s.index('\nspec=',a);s=s[:a]+"worker=Path('benchmarks/cpython-worker.py')"+s[b:]
s=s.replace("[('Lython',[sdk", "[('LythonReference',[sdk+'/dotnet.exe',str((r/'reference/Lokad.Lython.Benchmarks.dll').resolve()),'--compare','worker','--catalog',str(catalog)]),('LythonCandidate',[sdk")
needle="            assert ready and ready['status']=='Ready' and ready['catalogSha256']==identity['catalogSHA256'],ready\n";assert needle in s
s=s.replace(needle,needle+'''            if role.startswith('Lython'):
                image='reference'if role=='LythonReference'else'candidate'
                loaded=next(v for v in ready['libraries']if Path(v['path']).name=='Lokad.Lython.dll')
                assert loaded['sha256'].lower()==identity['coreSHA256'][image]
                for name,h in identity['auxiliaryFiles'].items():
                    library=next((v for v in ready['libraries']if Path(v['path']).name==name),None)
                    if library:assert library['sha256'].lower()==h
''').replace('16 independent','24 independent')
ast.parse(s);(r/'verify.py').write_text(s,encoding='utf-8',newline='\n')
with(r/'goldens.log').open('w',encoding='utf-8')as f:done=subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'verify.py')],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=90)
assert done.returncode==0,(r/'goldens.log').read_text(encoding='utf-8')[-5000:]
s=(old/'measure-allocation.py').read_text(encoding='utf-8');ast.parse(s);(r/'measure-allocation.py').write_text(s,encoding='utf-8',newline='\n')
shutil.copyfile(r.parent/'word-buffer-loan-r324/allocation/Program.cs',r/'allocation-driver-source.cs')
with(r/'allocation.log').open('w',encoding='utf-8')as f:done=subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'measure-allocation.py')],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=150)
assert done.returncode==0,(r/'allocation.log').read_text(encoding='utf-8')[-5000:]
print(identity['coreSHA256'],flush=True)
print((r/'allocation.log').read_text(encoding='utf-8')[-3500:],flush=True)
