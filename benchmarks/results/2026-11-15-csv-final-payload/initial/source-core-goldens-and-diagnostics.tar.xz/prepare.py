from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).parent;prior=r.parent/'closed-word-segment-r376/refinement'
f=json.loads((prior/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in f['sources'].items())
(r/'original-identity.json').write_text(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),sources=f['sources'],referenceCore=f['coreSHA256']['candidate']),indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('tests/Lokad.Lython.Tests/CsvLongFieldOwnershipTests.cs');(r/'original-test.cs').write_bytes(p.read_bytes())
s=p.read_text(encoding='utf-8').replace('using System.Text;','using System.Text;\nusing System.Runtime.InteropServices;')
tag='    [Theory]\n    [InlineData(false)]\n    [InlineData(true)]\n    public void CompletedPayloadAdmissionStopsBeforeAllocationAndPublication'
assert tag in s
s=s.replace(tag,'''    [Fact]
    public void DiscardingPrivateFieldsKeepsRetainedBackingFunded()
    {
        var budget = new LythonMemoryBudget(1024 * 1024);
        using (var owner = budget.CreateScope())
        {
            var context = new LythonRuntime.ExecutionContext(new MockLythonHost(), new() { MemoryBudget = owner });
            var left = new string('a', 8192);
            var middle = new string('b', 12288) + "é😀";
            var right = new string('c', 16384);
            var source = new LythonRuntime.CsvRecordSource(
                new PyList([PyString.FromString(left + "," + middle + "," + right + "\\n")]),
                Options, Span, context);
            try
            {
                Assert.True(source.TryMoveNext(out var row));
                var kept = Assert.IsType<PyString>(row[1]);
                Assert.True(MemoryMarshal.TryGetArray(kept.Utf8Bytes, out var backing));
                Assert.NotNull(backing.Array);
                Assert.False(source.TryMoveNext(out _)); // Ends parser working storage.
                for (var i = 0; i < row.Length; i++)
                {
                    if (i == 1) continue;
                    var relinquished = row[i];
                    row[i] = PyNone.Instance;
                    context.MemoryGovernor.RefundUnpublishedValue(relinquished);
                }
                row[1] = PyNone.Instance;
                source.ReleaseRecord(row);
                // This applies to either independent fields or an immutable
                // shared payload: the actual retained array must stay funded.
                Assert.True(budget.ReservedBytes >= backing.Array.Length);
                Assert.Equal(middle, kept.AsString());
                Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
            }
            finally { context.State.CloseResources(); }
        }
        Assert.Equal(0, budget.ReservedBytes);
    }

'''+tag)
p.write_text(s,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');s=s.replace('UTF-8 JSON and\nincremental XML.','UTF-8 JSON (including iterative container construction/real-callback-only\ncontinuations) and incremental XML.')
tag='3. **Per-record construction and remaining bulk conversions.** Reassess complete'
assert tag in s;s=s.replace(tag,'''3. **R379 active: one immutable final payload for CSV long fields.**
   Hypothesis: per-field byte arrays remain real construction work after final
   row adoption. Replace those arrays with one exact admitted row payload and
   existing UTF8 windows, retaining independent Python string identities. Keep
   short inline fields and numeric conversion/error order. This removes arrays
   and metadata/allocator traffic, not the already-required final byte copy.
   No raw-range inventory, retained mutable input, tracing, new owner/refcount,
   cache or policy. Existing per-record preflight conservatively funds all bytes;
   shared payload stays with the execution/result owner through actual users.
   Tradeoff: an unpublished sibling withdrawal may retain the whole shared
   payload longer; arbitrary-reference-withdrawal precision is not promised.
   Consolidate duplicate parser reset state. Preserve original syntax/error
   timing, Unicode/dialects, duplicate headers, aliases, pending I/O, cancellation
   and first refusal. New actual-backing funding regression must pass old/new.
   Use existing long-field/CSV semantic and refusal checks on actual11/10.
   Compare the existing complete validated-record script with a declared long-
   metadata CSV fixture (independent goldens), plus unchanged invoice/fulfillment/
   text controls, allocation separate from CPU. One short local diagnostic then
   a bounded quiet warm/fresh source pair if justified; final retain/debt or
   withdrawal and remove displaced machinery. No broad measurement framework.

   **Wider record/conversion roadmap:** Reassess complete''')
p.write_text(s,encoding='utf-8',newline='\n')
print('R379 design/contract recorded; independent backing-funding regression added before runtime edits.')
