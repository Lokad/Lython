from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-15-csv-final-payload/initial');out.mkdir(parents=True)
f=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in f['sources'].items())
checks=json.loads((r/'focused-checks.json').read_text(encoding='utf-8'));allocation=json.loads((r/'allocation-summary.json').read_text(encoding='utf-8'));assert len(checks)==4 and all(c['exitCode']==0 for c in checks)and allocation['complete']
(r/'prototype.patch').write_bytes(subprocess.check_output(['git','-c','core.safecrlf=false','diff','--','src/Lokad.Lython']))
for name in ['candidate-identity.json','focused-checks.json','allocation-summary.json','fixture-design.json']:shutil.copyfile(r/name,out/name)
with tarfile.open(out/'source-core-goldens-and-diagnostics.tar.xz','w:xz')as archive:
 for p in sorted(r.iterdir()):
  if p.is_file()and p.name not in {'candidate-identity.json','allocation-summary.json'}:archive.add(p,arcname=p.name)
 archive.add('tests/Lokad.Lython.Tests/CsvLongFieldOwnershipTests.cs',arcname='tests/CsvLongFieldOwnershipTests.cs')
with tarfile.open(out/'source-core-goldens-and-diagnostics.tar.xz')as archive:assert hashlib.sha256(archive.extractfile('candidate-core.dll').read()).hexdigest()==f['coreSHA256']['candidate']
(out/'README.md').write_text('''# One final CSV payload: active prototype

R379, 2026-11-15. Frozen candidate `716176a8` versus qualified ec6c0416/
`6164a933`; one of585production inputs changes. Runtime is uncommitted/unretained,
with no CPU/elapsed or final platform qualification claim at this checkpoint.

Final record construction gives long fields separate immutable Python string
identities over one exact admitted payload, using existing UTF8 windows. Short
fields retain inline storage; numeric conversion/error order remains. Remove
per-field long byte arrays and consolidate repeated parser reset code. This
reduces allocations, not the necessary final copy from parser working storage.
No raw syntax/range inventory, new owner/refcount/cache, policy or memory layer.
Conservative per-record admission remains unchanged and funds working/output
overlap. Unpublished sibling withdrawal may retain the whole payload longer;
arbitrary-reference-withdrawal precision is not promised. Retained storage stays
funded until actual execution/result ownership ends.

## Focused validation and allocation

118internal/390public Release cases pass per actual .NET11/10, covering CSV
Unicode/dialects, numeric/error timing, duplicate/custom headers, aliases, real
I/O, cancellation, terminal refusal, retained results and cleanup. One new test
checks funding of the actual retained backing after private siblings/scratch end;
it also passes on the reference implementation before the runtime edit. Existing
large-payload checks prove cancellation/refusal before allocation/publication.
24 independent reference/candidate/isolatedCPython3.13.2 engine/phase goldens pass.

The maintained csv-validated-records.py source is unchanged. Its diagnostic input
has5,120rows/400,411B, three long metadata columns, quoted Unicode/newline notes,
numeric conversion and filtering. Manual totals are separately checked under
isolated CPython using the existing worker's StringIO output boundary. Initial
Windows-console CRLF validation refusal and capture correction are preserved;
no guest bytes/source/data or timing boundary was normalized or changed.

| Complete warm workload | Reference allocation | Candidate allocation | Change |
| --- | ---: | ---: | ---: |
| Metadata-heavy validated CSV |3,982,195.875B|3,760,902.125B|−5.557%|
| Ordinary invoice control |4,590,464.875B|4,590,441.625B|Effectively flat|
| Ordinary fulfillment control |4,673,332.375B|4,673,188.375B|Effectively flat|

Existing allocation tool, one fresh process/image, five64-invocation batches
after128warmups/at least4seconds. Medians use process-wide cumulative CLR
allocation, no forced GC. Includes fixture reset, mediated filesystem I/O, full
stdout/file validation and result cleanup; excludes compile/startup/final cache
teardown. This is allocation evidence, not live memory, CPU, RSS or tail latency.
All image/auxiliary/source identities, goldens and budget baselines verify;
all local workers join and fixtures close. Exact core/source/tool/checks/controls
remain in the archive. No VM collection or final retention decision yet.

Next: one bounded quiet-machine whole-script warm/fresh source pair with ordinary
CSV/text controls; retain with explicit debt, justified refinement or withdrawal.
Keep adverse observations; no fixed percentage veto. Publication remains held and
the broader performance roadmap remains active.
''',encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');s+='''

R379 [one final CSV payload initial checkpoint](results/2026-11-15-csv-final-payload/initial/README.md)
is an active, uncommitted prototype716176a8 versus qualified6164. Replace long-field
byte arrays with one admitted immutable row payload/existing windows; short fields
stay inline and parser reset is consolidated.118internal/390public per actual11/10,
24reference/candidate/CPythongoldenspass; new actual-backing funding test passes
reference first. Existing complete metadata-heavy CSV fixture5120rows/400411B
allocates−5.557%; ordinary invoice/fulfillment effectivelyflat. Allocation only,
one process/image/five64runbatches/no forcedGC; includes I/O/reset/goldens/cleanup.
CPU unmeasured, no retention/full-qualification claim. Preserve initial Windows
console newline validation refusal/corrected StringIO capture, all source/core/
raw/tool checks. All local users/fixtures close; no VM collection yet. Next bounded
quiet warm/fresh pair with controls, then explicit decision. Publication held.
''';p.write_text(s,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');tag='| R378 withdrawn and restored |';a=s.index(tag);b=s.index('\n',a)
s=s[:b]+'''\n| Active uncommitted R379 prototype | [One final CSV payload](benchmarks/results/2026-11-15-csv-final-payload/initial/README.md), frozen `716176a8` versus qualified6164, one production file. Per actual11/10:118internal/390public;24reference/candidate/CPythongoldenspass. Metadata-heavy validated CSV allocation−5.557%, ordinary CSV controls effectivelyflat. CPU unmeasured; no retention/full qualification yet. All local users/fixtures closed. |'''+s[b:]
s=s.replace('   Use existing long-field/CSV semantic and refusal checks on actual11/10.','   Existing CSV semantics/refusal checks now pass118internal/390public per\n   actual11/10, including reference-first actual-backing funding;24goldenspass.')
s=s.replace('   text controls, allocation separate from CPU. One short local diagnostic then\n   a bounded quiet warm/fresh source pair if justified; final retain/debt or','   text controls, allocation separate from CPU. Local allocation diagnostic is\n   complete:−5.557%metadata-heavy CSV, ordinary controlsflat. Proceed to one\n   bounded quiet warm/fresh source pair; final retain/debt or')
p.write_text(s,encoding='utf-8',newline='\n')
print('R379 preliminary evidence preserved; runtime remains uncommitted/nonretained, CPU comparison next.')
