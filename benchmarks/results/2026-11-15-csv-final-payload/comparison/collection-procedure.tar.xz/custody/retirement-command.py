from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
groups=[{'commit': 'ab435af9c95d0532dc3c6cbe3bc7341bbf2b547c', 'canonicalArchive': 'benchmarks/results/2026-11-15-shared-executable-slots/completed-sources-and-checks.tar.xz', 'canonicalArchiveSHA256': 'a5e42e4eb1b1a0a014cda9c3bcf451d770926057efea1dbec423b1cf4fca9162', 'member': 'candidate-core.dll', 'bytes': 5749760, 'sha256': '95798eb99ca4945d06d10c05d4f0a64925719377190abb82c5a5775d91bb52b0', 'paths': ['shared-slots-b763-20261115/candidate-core.dll', 'slots-cpython-b764-20261115/candidate/Lokad.Lython.dll', 'shared-slots-b763-20261115/candidate/Lokad.Lython.dll', 'text-stage-b765-20261115/candidate/Lokad.Lython.dll', 'word-segment-b766-20261115/reference/Lokad.Lython.dll', 'word-segment-b767-20261115/reference/Lokad.Lython.dll'], 'expectedLinks': 6}, {'commit': 'ab435af9c95d0532dc3c6cbe3bc7341bbf2b547c', 'canonicalArchive': 'benchmarks/results/2026-11-14-builtin-scalar-publication/sources-and-local-checks.tar.xz', 'canonicalArchiveSHA256': '5f500de90c608e7f5f7965e0bf72a2c44da3e6bcabda25035ae540515ebdc44e', 'member': 'candidate-core.dll', 'bytes': 5747712, 'sha256': 'bed6e57e060da7983b4c995f75c6d6adbb335cbe91aecca1e7a943840c44df54', 'paths': ['scalar-results-b759-20261114/candidate-core.dll', 'scalar-results-b759-20261114/candidate/Lokad.Lython.dll', 'current-cpython-b761-20261114/candidate/Lokad.Lython.dll', 'call-publication-b760-20261114/candidate/Lokad.Lython.dll', 'shared-slots-b763-20261115/reference/Lokad.Lython.dll', 'shared-slots-b762-20261115/reference/Lokad.Lython.dll'], 'expectedLinks': 6}]
planned=7733668
base=Path('/home/lokad/lython-bench-checks').resolve()
current=base/'word-segment-b767-20261115/candidate/Lokad.Lython.dll'
currentSHA='6164a933f5eef8f39e91e4541ac54bcfdd38832f01c4e58d68d331bafaa58217'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(p.is_mount()for p in base.glob('*/guest-fixtures'))
 assert hashlib.sha256(current.read_bytes()).hexdigest()==currentSHA
 paths=[];observations=[]
 for group in groups:
  selected=[base/n for n in group['paths']];metadata=[p.lstat()for p in selected]
  assert all(p.resolve()==p and p.is_relative_to(base)and p!=current and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_nlink==group['expectedLinks']and s.st_size==group['bytes']for p,s in zip(selected,metadata))
  assert len({(s.st_dev,s.st_ino)for s in metadata})==1 and len(selected)==group['expectedLinks']
  assert all(hashlib.sha256(p.read_bytes()).hexdigest()==group['sha256']for p in selected)
  paths.extend(selected);observations.extend(dict(path=str(p),inode=s.st_ino,links=s.st_nlink,uid=s.st_uid,bytes=s.st_size,sha256=group['sha256'])for p,s in zip(selected,metadata))
 before=shutil.disk_usage(base).free
 assert before+sum(g['bytes']for g in groups)>254*1024*1024+planned+32768
 for p in paths:p.unlink()
 assert hashlib.sha256(current.read_bytes()).hexdigest()==currentSHA
 receipt=dict(groups=groups,remoteMetadataAndHashes=observations,allMetadataHashesVerifiedBeforeMutation=True,freshIdleLease=True,retiredOnly=[str(p)for p in paths],beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,current6164AndLocal7161Preserved=True,allEvidenceArchivesCatalogsAuxiliariesToolchainsAndFloorsPreserved=True,localAndCommittedArchiveMemberCustody=True,plannedUnpackedBytes=planned)
 (base/'b770-proved-superseded-image-retirement.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt),flush=True)
