from pathlib import Path
import hashlib,io,json,subprocess,tarfile
r=Path(__file__).parent;head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
inventory=json.loads((r/'space-inventory.json').read_text(encoding='utf-8'));planned=json.loads((r/'b770/config.json').read_text(encoding='utf-8'))['unpackedBytes'];proof=[]
archives=[('benchmarks/results/2026-11-15-shared-executable-slots/completed-sources-and-checks.tar.xz','95798eb99ca4945d06d10c05d4f0a64925719377190abb82c5a5775d91bb52b0'),('benchmarks/results/2026-11-14-builtin-scalar-publication/sources-and-local-checks.tar.xz','bed6e57e060da7983b4c995f75c6d6adbb335cbe91aecca1e7a943840c44df54')]
for name,digest in archives:
 blob=subprocess.check_output(['git','show',head+':'+name]);assert blob==Path(name).read_bytes()
 with tarfile.open(fileobj=io.BytesIO(blob),mode='r:xz')as archive:body=archive.extractfile('candidate-core.dll').read()
 assert hashlib.sha256(body).hexdigest()==digest
 rows=[v for v in inventory['candidates']if v['sha256']==digest];assert len(rows)==6 and all(v['links']==6 and v['bytes']==len(body)for v in rows)
 assert len({(v['dev'],v['inode'])for v in rows})==1
 proof.append(dict(commit=head,canonicalArchive=name,canonicalArchiveSHA256=hashlib.sha256(blob).hexdigest(),member='candidate-core.dll',bytes=len(body),sha256=digest,paths=[v['path']for v in rows],expectedLinks=len(rows)))
(r/'retirement-proof.json').write_text(json.dumps(dict(groups=proof,plannedUnpackedBytes=planned),indent=2)+'\n',encoding='utf-8',newline='\n')
code=r'''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
groups=GROUPS
planned=PLANNED
base=Path('/home/lokad/lython-bench-checks').resolve()
current=base/'word-segment-b767-20261115/candidate/Lokad.Lython.dll'
currentSHA='6164a933f5eef8f39e91e4541ac54bcfdd38832f01c4e58d68d331bafaa58217'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(p.is_mount()for p in base.glob('*/guest-fixtures'))
 assert hashlib.sha256(current.read_bytes()).hexdigest()==currentSHA
 paths=[];observations=[]
 for group in groups:
  selected=[base/n for n in group['paths']];metadata=[p.lstat()for p in selected]
  assert all(p.resolve()==p and p.is_relative_to(base)and p!=current and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_nlink==group['expectedLinks']and s.st_size==group['bytes']for p,s in zip(selected,metadata))
  assert len({(s.st_dev,s.st_ino)for s in metadata})==1 and len(selected)==group['expectedLinks']
  assert all(hashlib.sha256(p.read_bytes()).hexdigest()==group['sha256']for p in selected)
  paths.extend(selected);observations.extend(dict(path=str(p),inode=s.st_ino,links=s.st_nlink,uid=s.st_uid,bytes=s.st_size,sha256=group['sha256'])for p,s in zip(selected,metadata))
 before=shutil.disk_usage(base).free
 assert before+sum(g['bytes']for g in groups)>254*1024*1024+planned+32768
 for p in paths:p.unlink()
 assert hashlib.sha256(current.read_bytes()).hexdigest()==currentSHA
 receipt=dict(groups=groups,remoteMetadataAndHashes=observations,allMetadataHashesVerifiedBeforeMutation=True,freshIdleLease=True,retiredOnly=[str(p)for p in paths],beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,current6164AndLocal7161Preserved=True,allEvidenceArchivesCatalogsAuxiliariesToolchainsAndFloorsPreserved=True,localAndCommittedArchiveMemberCustody=True,plannedUnpackedBytes=planned)
 (base/'b770-proved-superseded-image-retirement.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt),flush=True)
'''.replace('GROUPS',repr(proof)).replace('PLANNED',repr(planned))
(r/'retirement-command.py').write_text(code,encoding='utf-8',newline='\n')
done=subprocess.run(['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73','python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=45)
(r/'retirement-result.log').write_text(done.stdout+done.stderr,encoding='utf-8',newline='\n');assert done.returncode==0,done.stdout+done.stderr
receipt=json.loads(done.stdout);(r/'retirement-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(retiredSupersededAliases=len(receipt['retiredOnly']),archivedImages=2,afterFreeBytes=receipt['afterFreeBytes'],plannedUnpackedBytes=planned,allProofsPassed=True)))
