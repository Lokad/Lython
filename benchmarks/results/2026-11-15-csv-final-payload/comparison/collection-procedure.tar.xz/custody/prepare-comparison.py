from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent;b=r/'b770';b.mkdir()
old=r.parent/'closed-word-segment-r376/refinement/b767';f=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert all(sha(p)==h for p,h in f['sources'].items())
remote='/home/lokad/lython-bench-checks/csv-payload-b770-20261115';unit='lython-b770-csv-payload-20261115'
prior=json.loads((old/'config.json').read_text(encoding='utf-8'))
identity=dict(prior['identity']);identity.update(sourceRevision='R379 frozen716176a8 vs qualifiedec6c0416/frozen6164a933; sourcebaseab435af9,585inputs/oneCsvModulechange',purpose='One final immutable CSV payload; complete unchanged validation script with declared metadata-heavy input plus ordinary CSV/text controls. Allocation-5.557%established separately. No universal or external-baseline gain claim.',coreSHA256={role:f['coreSHA256']['candidate'if role.startswith('candidate')else'reference']for role in prior['identity']['coreSHA256']},catalogSHA256=sha(r/'catalog.json'),fullSourceIdentitySHA256=sha(r/'candidate-identity.json'),qualification='Active uncommitted prototype;118internal/390public per actual11/10 and24engine/phase goldenspass, independent backing-funding test passes reference first. Final delivery pending if retained.')
(b/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
prospective=dict(purpose=identity['purpose'],jobs=5,ownershipSeconds=300,scope='Metadata-heavy complete CSV warm/fresh, ordinary invoice/fulfillment and captured-text warm;5sfull-request warmups/12stext,5rotating0.5srounds,fourfreshprocesses/job. Separate allocation and widerCPU.',acceptance='All source/image/aux/catalog/golden/budget/quiet/join/archive gates. Preserve all adverse/control variability and current cancellation/terminalrefusal/ownership. Explicitretain/debt,justifiedrefinementorwithdraw; no rigidpercentveto.',storage='Retire only two exact superseded957/bed image inode groups after committed/local/member proof and fresh remote path/UID/link/hash checks. Preserve compressed evidence,current6164/new7161,auxiliaries/catalogs/toolchains and254/252MiBfloors.',publicationHeld=True)
(b/'prospective.json').write_text(json.dumps(prospective,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=(old/name).read_text(encoding='utf-8').replace('word-segment-b767-20261115','csv-payload-b770-20261115').replace('lython-b767-word-segment-20261115',unit).replace('B767','B770')
 if name=='collect.py':
  a=s.index('jobs=');z=s.index('\nenv =',a);s=s[:a]+"jobs=[['diagnostic.csv-validated-records.long-fields.large','warm'],['diagnostic.csv-validated-records.long-fields.large','compile-run'],['scripts.csv-invoice.large','warm'],['scripts.csv-fulfillment.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','warm']]\nassert len(jobs)==5 and all(case in cases for case,lane in jobs)\n"+s[z:]
  s=s.replace("< 350, 'Reserve70seconds", "< 240, 'Reserve60seconds").replace('Representative CPython delivery checkpoint','CSV final-payload source pair')
 else:s=s.replace('==6','==5').replace('jobs=6','jobs=5').replace("<420", "<300")
 if name.endswith('.py'):ast.parse(s)
 (b/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(b/'payload.tgz','w:gz')as archive:
 for name in ['identity.json','prospective.json','collect.py','archive-owned.py','run.sh']:archive.add(b/name,arcname=name)
 archive.add(r/'candidate-core.dll',arcname='candidate-core.dll');archive.add(r/'catalog.json',arcname='representative.json')
with tarfile.open(b/'payload.tgz')as archive:unpacked=sum(m.size for m in archive.getmembers())
config=dict(prior,root=remote,sourceRoot='/home/lokad/lython-bench-checks/word-segment-b767-20261115',unit=unit,identity=identity,payloadBytes=(b/'payload.tgz').stat().st_size,payloadSHA256=sha(b/'payload.tgz'),unpackedBytes=unpacked)
(b/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'launch-command.py').read_text(encoding='utf-8');a=s.index('c=');z=s.index('\nbase=',a);s=s[:a]+'c='+repr(config)+s[z:]
s=s.replace(" and sha(source/'representative.json')==c['identity']['catalogSHA256']", " and sha(root/'representative.json')==c['identity']['catalogSHA256']")
s=s.replace(" os.link(source/'representative.json',root/'representative.json')\n",'')
s=s.replace('lython-b763-fixtures','lython-b770-fixtures').replace("'--property=RuntimeMaxSec=420'", "'--property=RuntimeMaxSec=300'")
ast.parse(s);(b/'launch-command.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'launch.py').read_text(encoding='utf-8');a=s.index('prior=json.loads(');z=s.index('\nnow=',a)
s=s[:a]+"prior=json.loads((r.parent.parent/'file-stage-r377/terminal-status.json').read_text(encoding='utf-8'))\nassert prior['receipt']['complete']and not prior['remainingWorkers']and not prior['remainingTrace']\nassert json.loads((r.parent/'retirement-receipt.json').read_text(encoding='utf-8'))['allMetadataHashesVerifiedBeforeMutation']\n"+s[z:]
s=s.replace('seconds=350','seconds=240').replace('ownerSeconds=420','ownerSeconds=300');ast.parse(s);(b/'launch.py').write_text(s,encoding='utf-8',newline='\n')
assert b'\r'not in(b/'run.sh').read_bytes()
print(json.dumps(dict(prepared=True,jobs=5,unpackedBytes=unpacked,ownerSeconds=300,images=f['coreSHA256'])))
