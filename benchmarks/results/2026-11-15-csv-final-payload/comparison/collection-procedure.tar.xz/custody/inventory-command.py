from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 workers=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True).stdout
 mounts=[str(p)for p in base.glob('*/guest-fixtures')if p.is_mount()]
 assert not workers and not mounts
 targets={'95798eb99ca4945d06d10c05d4f0a64925719377190abb82c5a5775d91bb52b0','bed6e57e060da7983b4c995f75c6d6adbb335cbe91aecca1e7a943840c44df54'}
 rows=[]
 for p in list(base.glob('*/*.dll'))+list(base.glob('*/candidate/*.dll'))+list(base.glob('*/reference/*.dll')):
  if not 5500000<=p.stat().st_size<=6000000:continue
  digest=hashlib.sha256(p.read_bytes()).hexdigest()
  if digest not in targets:continue
  s=p.lstat();rows.append(dict(path=str(p.relative_to(base)),sha256=digest,bytes=s.st_size,inode=s.st_ino,dev=s.st_dev,links=s.st_nlink,uid=s.st_uid,resolved=str(p.resolve())))
 print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,closedIdleLease=True,workers=workers,mounts=mounts,candidates=rows)))
