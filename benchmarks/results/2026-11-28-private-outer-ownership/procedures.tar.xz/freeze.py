from hashlib import sha256
from pathlib import Path
from shutil import copy2, copytree
from subprocess import check_output
import json

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
base = lab.parent / 'combined-reduction-profile-b1961-20261128/comparison/quiet'
prior = lab.parent / 'integer-reduction-owner-b1960-20261128'
catalog = prior / 'comparison'
pair = lab / 'comparison'
core = 'Lokad.Lython.dll'
build = lab / 'ubuntu-artifacts/bin/Lokad.Lython/release_net11.0' / core
read = lambda path: json.loads(path.read_bytes())
hashes = lambda path: {p.name: digest(p.read_bytes()) for p in path.iterdir()}
digest = lambda data: sha256(data).hexdigest()
hash_file = lambda path: digest(path.read_bytes())

def git(*args):
    return check_output(['git', *args], cwd=repo)

def save(path, content):
    path.write_text(content, encoding='utf-8', newline='\n')
    assert b'\r' not in path.read_bytes()

old = read(base / 'identity.json')
head = git('rev-parse', 'HEAD').decode().strip()
assert head.startswith('8a619a657') and old['sourceRevision'].startswith('b663af554')
assert not git('diff', old['sourceRevision'], head, '--', 'src', 'Directory.Packages.props',
    'Directory.Build.props', 'Directory.Build.targets', 'benchmarks/Lokad.Lython.Benchmarks')
patch = git('diff', '--binary', 'HEAD', '--', 'src','tests')
assert patch.count(b'diff --git ') == 2 and not git('ls-files','--others','--exclude-standard','--','src','tests')
changed = git('diff', '--name-only', 'HEAD','--','src','tests').decode().splitlines()
assert set(changed) == {
    'src/Lokad.Lython/Runtime/LythonRuntime.Executable.GeneratorSum.cs',
    'tests/Lokad.Lython.PublicApi.Tests/NativeGeneratorSumTests.cs',
}
frozen = old['imageFiles']['candidate']
assert len(frozen) == 32 and hashes(base / 'local-image') == frozen
pair.mkdir()
for role in ('reference','candidate'):
    copytree(base / 'local-image', pair / role)
copy2(build, pair / 'candidate' / core)
assert not (pair / 'candidate' / core).samefile(build)
images = {role: hashes(pair / role) for role in ('reference', 'candidate')}
assert images['reference'] == frozen
assert {name for name, checksum in images['candidate'].items() if frozen[name] != checksum} == {core}
predecessor = read(catalog / 'identity.json')
assert hash_file(catalog/'representative.json') == predecessor['catalogs']['representative.json']['sha256']
catalogue = read(catalog / 'representative.json')
assert len(catalogue['cases']) == 4
alias_source = """observed = []
def observe(value, outer):
    observed.append(outer)
    assert next(outer) == 3
    return value
items = (1, 2, 3, 5)
for index in range(128):
    assert sum(value if value != 2 else observe(value, locals()['.0']) for value in items) == 8
assert len(observed) == 128
assert all(next(iterator, 'end') == 'end' for iterator in observed)
print(len(observed))
"""
alias_fixture = json.dumps(dict(size=128, text=None, inputFiles={}, outputFiles={}), separators=(',', ':'))
alias_output = '128\n'
alias = dict(catalogue['cases'][1], id='diagnostic.sum-retained-outer-aliases', size=128,
    source=alias_source, fixtureJson=alias_fixture, expectedOutput=alias_output,
    sourceSha256=digest(alias_source.encode('utf-8')), sourceUtf8Bytes=len(alias_source.encode('utf-8')),
    fixtureSha256=digest(alias_fixture.encode('utf-8')),
    expectedOutputSha256=digest(alias_output.encode('utf-8')), expectedOutputUtf8Bytes=len(alias_output),
    expectedFilesSha256=digest(b'\0\0\0\0'))
catalogue['cases'].append(alias)
save(pair / 'representative.json', json.dumps(catalogue, indent=2) + '\n')
for name in ('cpython-worker.py','jobs.json','collect.py','run.sh'):
    copy2(catalog / name, pair / name)
assert hash_file(pair / 'cpython-worker.py') == old['cpythonWorkerSHA256']
assert b'\r' not in (pair/'run.sh').read_bytes()
assert len(read(pair/'jobs.json')['warm']) == 3
(lab / 'candidate.patch').write_bytes(patch)
identity = dict(sourceRevision=head, referenceRevision=old['sourceRevision'],
    sourcePatchSHA256=digest(patch), imageFiles=images,
    coreSHA256={role+suffix: image[core] for role,image in images.items() for suffix in ('','-control')},
    expectedCPythonSHA256=old['expectedCPythonSHA256'], cpythonWorkerSHA256=old['cpythonWorkerSHA256'],
    catalogs={name: {'sha256':hash_file(pair/name)} for name in ('representative.json','jobs.json')},
    purpose='Admit a private generator outer with its operand and retain the same charge on promotion.')
save(pair / 'identity.json', json.dumps(identity, indent=2)+'\n')
copy2(prior/'check-admission.py', lab/'check-admission.py')
for name in ('measure-allocation.py','summarize.py'):
    script = (prior/name).read_text(encoding='utf-8')
    assert script.count("['cases'])==4" if name == 'measure-allocation.py' else '["caseCount"] == 4') == 1
    save(lab/name, script.replace("['cases'])==4", "['cases'])==5").replace('["caseCount"] == 4', '["caseCount"] == 5'))
print(head, 'two complete images, three matched lanes and a retained alias witness')
