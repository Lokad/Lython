#!/bin/bash
set -euo pipefail
root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
export DOTNET_ROOT="$HOME/.dotnet"
python=/mnt/d/code/Lython/.git/agent-notes/review-20261031/bench-cpython-3.13.16-runtime/runtime/bin/python3.13
worker=Lokad.Lython.Benchmarks.dll
catalog="$root/representative.json"
trap 'status=$?; printf "%s\n" "$status" > "$root/exit-code.txt"' EXIT
for role in reference candidate; do
  "$DOTNET_ROOT/dotnet" "$root/$role/$worker" --compare verify --catalog "$catalog" \
    --dotnet "$DOTNET_ROOT/dotnet" --python "$python" --python-worker "$root/cpython-worker.py" \
    --out "$root/$role-verify.json"
done
flock -n "$root/collection.lock" timeout --signal=TERM 180s taskset -c 27 python3 "$root/collect.py"
