from pathlib import Path
import hashlib,json,re,shutil,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/'comparison/quiet'
out=repo/'benchmarks/results/2026-11-25-prepared-map-callback'
route=lab.with_name('prepared-map-callback-routes-20261125')
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=read(quiet/'identity.json')
assert sha(lab/'candidate.patch')==identity['sourcePatchSHA256']
assert read(route/'identity.json')['patchSHA256']==identity['sourcePatchSHA256']
assert read(route/'identity.json')['coreSHA256']==identity['coreSHA256']['candidate']
routes=read(route/'routes.json')['rows']
assert len(routes)==4
for row in routes:
    assert row['allowanceReturned'] and row['routes']['OtherShortCallbacks']==0
    assert row['routes']['CompleteMapRows']==(2048 if 'file-fed' in row['id'] else 4096)
passed={}
for suite,num in (('Lokad.Lython.Tests',23),('Lokad.Lython.PublicApi.Tests',169)):
    for platform in ('win11','ubuntu10'):
        file=f'{suite}-{platform}.log'
        assert re.search(rf"Failed:\s+0, Passed:\s+{num},", (lab/file).read_text(encoding='utf-8-sig')), file
        passed[file]=num
out.mkdir(exist_ok=True)
for name in ('identity.json','storage-custody.json'):
    shutil.copyfile(quiet/name,out/name)
shutil.copyfile(lab/'allocation-summary.json',out/'allocation-summary.json')
shutil.copyfile(route/'routes.json',out/'routes.json')
with tarfile.open(out/'procedures.tar.xz','w:xz') as archive:
    for name in ('package-evidence.py','archive.py','prepare.py','prepare.log',
        'launch-console.log','quiet.py','retrieve.log','verified-raw-replicas.json',
        'candidate.patch','bench-build.log','test-ubuntu.sh','allocations.py','allocations.log',
        'reference-allocation-final.json','candidate-allocation-final.json',
        'comparison/reference-verify.json','comparison/candidate-verify.json',*passed):
        archive.add(lab/name,arcname=name,recursive=False)
    for name in ('prepare.py','diagnostic.patch','identity.json','Program.cs','RouteProbe.csproj',
                 'cases.json','core-build.log','probe-build.log'):
        archive.add(route/name,arcname='routes/'+name,recursive=False)
