from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile
from difflib import unified_diff

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
p=lab.with_name('prepared-map-callback-20261125')
prior=lab.with_name('shipment-comprehension-routes-20261125')
out=lab/'source'
out.mkdir(exist_ok=False)
write=lambda f,s:f.write_text(s,encoding='utf-8',newline='\n')
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=repo)
base=git('rev-parse','HEAD').decode().strip()
delta=git('diff','--binary',base,'--','src')
assert delta==(p/'candidate.patch').read_bytes()
with zipfile.ZipFile(prior/'source.zip') as clean:
    assert all(not Path(name).is_absolute() and '..' not in Path(name).parts for name in clean.namelist())
    clean.extractall(out)
for n in git('diff','--name-only',base,'--','src').decode().splitlines():
    shutil.copyfile(repo/n,out/n)
name='src/Lokad.Lython/Runtime/LythonRuntime.Calls.cs'
path=out/name
before=path.read_text(encoding='utf-8')
s=before.replace('    internal static PyIterationResult StartIterationCallback(','''    internal static int DiagnosticCompleteMapRows;
    internal static int DiagnosticOtherShortCallbacks;

    internal static PyIterationResult StartIterationCallback(''')
target='''        if (completePositional)
        {
            var prepared'''
assert s.count(target)==1
s=s.replace(target,'''        if (completePositional)
        {
            Interlocked.Increment(ref DiagnosticCompleteMapRows);
            var prepared''')
target='''        if (callable is BoundArgumentsCallable builtin)
        {
            var operands = storage[..argumentCount];'''
assert s.count(target)==1
s=s.replace(target,'        Interlocked.Increment(ref DiagnosticOtherShortCallbacks);\n'+target)
write(path,s)
write(lab/'diagnostic.patch',''.join(unified_diff(before.splitlines(keepends=True),s.splitlines(keepends=True),'a/'+name,'b/'+name)))
image=lab/'image'
image.mkdir(exist_ok=False)
ids=json.loads((p/'comparison/quiet/identity.json').read_text(encoding='utf-8'))
files=ids['imageFiles']['candidate']
assert len(files)==32 and {f.name:sha(f)for f in (p/'candidate').iterdir()}==files
for n in files: shutil.copyfile(p/'candidate'/n,image/n)
shutil.copyfile(prior/'RouteProbe.csproj',lab/'RouteProbe.csproj')
shutil.copyfile(prior/'cases.json',lab/'cases.json')
s=(prior/'Program.cs').read_text(encoding='utf-8')
a=s.index('string[] names')
b=s.index('foreach (var item',a)
s=s[:a]+'''string[] names = ["CompleteMapRows", "OtherShortCallbacks"];
var runtime = typeof(LythonEngine).Assembly.GetType("Lokad.Lython.Runtime.LythonRuntime", true)!;
var fields = names.Select(name => runtime.GetField("Diagnostic" + name, all)!).ToArray();
'''+s[b:]
s=s.replace('        transfers.Clear();\n','').replace('transfers = transfers.OrderBy(pair => pair.Key).ToDictionary(), ','')
write(lab/'Program.cs',s)
write(lab/'identity.json',json.dumps(dict(source=base,patchSHA256=ids['sourcePatchSHA256'],
    diagnosticSHA256=sha(lab/'diagnostic.patch'),coreSHA256=files['Lokad.Lython.dll'],catalogSHA256=sha(lab/'cases.json')),indent=2)+'\n')
