from pathlib import Path
import subprocess
import sys

lab = Path(__file__).resolve().parent
previous = lab.parent / 'current-rule-profile-r695'
warm = lab.parent / 'validator-warm-profile-b1132'
source = (previous / 'prepare.py').read_text(encoding='utf-8')
source = source.replace("'proven-record-keywords-r694'", "'validator-native-roundtrip-r706'")
source = source.replace("'referenceCommit'", "'candidateCommit'").replace("'40ab5132a'", "'e20604ef4'")
source = source.replace("pair['images']['reference']", "pair['images']['candidate']")
source = source.replace("'frozen/reference'", "'frozen/candidate'").replace("['imageFiles']['reference']", "['imageFiles']['candidate']")
source = source.replace('current-rule-profile-b1125', 'current-rule-profile-b1137')
source = source.replace('lython-b1125-current-rule-profile', 'lython-b1137-current-rule-profile')
source = source.replace('B1125 rule CPU attribution after lexical and ownership consolidation', 'B1137 current rule CPU attribution after native integer transport')
source = source.replace('R695/B1125 current rule CPU attribution', 'B1137 current rule CPU attribution')
source = source.replace('catalogSHA256=identity[\'catalogSHA256\'],identity=identity,retireGroups=[]',
                        "catalogSHA256=identity['catalogSHA256'],identity=identity,retireGroups=selected")
insert = '''
receipt=load(donor/'quiet/archive-receipt.json')
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease'] and sha(donor/'quiet/observations.tgz')==receipt['archiveSHA256']
space=load(lab/'quiet-space.json')
needed=182452224+2097152+sum((lab/name).stat().st_size for name in names)
selected=[]
available=space['freeBytes']
for proof in space['replicas']:
    if available>needed+49152: break
    assert proof['sha256'] != files['Lokad.Lython.dll'] and proof['committedBlobVerified']
    available+=proof['bytes']
    selected.append(proof)
save('preflight.json',dict(available=available,required=needed,selected=selected))
assert available>needed,(available,needed)
'''
source = source.replace('config=dict(root=', insert + '\nconfig=dict(root=')
source = source.replace("payloadSHA256=sha(payload),unpackedBytes=sum((lab/name).stat().st_size for name in names))",
                        "payloadSHA256=sha(payload),unpackedBytes=sum((lab/name).stat().st_size for name in names),donorArchive=receipt['archiveSHA256'])")
source = source[:source.index("source=read(prior/'remote-launch.py')")]+'''source=read(lab.parent/'validator-warm-profile-b1132/remote-launch.py')
a,b=source.index('\\nc=')+1,source.index('\\nb=Path(')
source=(source[:a]+'c='+repr(config)+source[b:]).replace('lython-b1132-fixtures','lython-b1137-fixtures')
assert source.count("source/'candidate'/n")==2
write('remote-launch.py',source)
'''
proof = (lab.parent / 'integer-transport-cpython-b1136/prove-quiet-space.py').read_text(encoding='utf-8')
assert 'retireGroups=selected' in source
for name, contents in [('prove-quiet-space.py', proof), ('prepare.py', source)]:
    (lab / name).write_text(contents, encoding='utf-8', newline='\n')
    subprocess.run([sys.executable, '-X', 'utf8', lab / name], check=True)
