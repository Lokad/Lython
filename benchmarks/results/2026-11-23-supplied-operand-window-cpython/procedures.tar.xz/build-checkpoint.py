from pathlib import Path

lab = Path(__file__).resolve().parent
prior = lab.parent / 'integer-call-update-cpython-20261123/prepare.py'
code = prior.read_text(encoding='utf-8')
updates = (
    ("donor=lab.parent/'supplied-call-accumulation-20261123'",
     "donor=lab.parent/'supplied-operand-window-20261123'"),
    ("tracked='benchmarks/results/2026-11-23-integer-call-update/'",
     "tracked='benchmarks/results/2026-11-23-supplied-operand-window/'"),
    ("run='integer-call-update-cpython-b1523-20261123'",
     "run='supplied-operand-window-cpython-b1525-20261123-verified'"),
    ('reference=base,original=base,originalArchive=',"reference=base,original='supplied-operand-window-b1524-20261123',originalArchive="),
    ('lython-b1523-fixtures','lython-b1525-fixtures'),
    ('CPython checkpoint after integer call updates','CPython checkpoint after removing the early supplied integer boxes'),
    ('lython-b1523-integer-call-update-cpython-20261123','lython-b1525-supplied-operand-window-20261123'),
    ('.+b1523-','.+b1525-'),('lython-b1523-stage-','lython-b1525-stage-'),
    ('A 51 MiB','A 45 MiB'),('51 * 1024 * 1024','45 * 1024 * 1024'),
    ('"digest(reference/\'reference\'/name)"','"digest(reference/\'candidate\'/name)"'),
)
for before,after in updates:
    assert code.count(before)==1,before
    code=code.replace(before,after)
target=lab/'prepare.py'
compile(code,str(target),'exec')
target.write_text(code,encoding='utf-8',newline='\n')
