from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/'comparison/quiet'
quiet.mkdir(parents=True,exist_ok=True)
donor=lab.parent/'supplied-operand-window-20261123'
collection=lab.parent/'short-csv-utf8-cpython-20261123'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda data:hashlib.sha256(data).hexdigest()
digest=lambda p:sha(p.read_bytes())
git=lambda *args:subprocess.check_output(['git',*args],cwd=repo)
def write(p,value):
    p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def adapt(source,target,pairs):
    code=source.read_text(encoding='utf-8')
    for a,b in pairs:
        assert code.count(a)==1,(source,a)
        code=code.replace(a,b)
    compile(code,str(target),'exec')
    target.write_text(code,encoding='utf-8',newline='\n')
tracked='benchmarks/results/2026-11-23-supplied-operand-window/'
pushed=lambda name:git('show','origin/master:'+tracked+name)
proof=json.loads(pushed('identity.json'))
status=json.loads(pushed('terminal-status.json'))['receipt']
assert status['complete'] and status['allWorkersJoined'] and status['archivedAndVerifiedUnderLease']
assert sha(pushed('observations.tar.xz'))==status['archiveSHA256']
head=git('rev-parse','origin/master').decode().strip()
retained=proof['retainedRevision']
assert not git('diff','--name-only',retained,head,'--','src')
assert not git('diff','--name-only',retained,proof['candidate'],'--','src')
files=proof['imageFiles']['candidate']
image=donor/'candidate'
assert len(files)==32 and all(digest(image/name)==value for name,value in files.items())
protocol=repo/'benchmarks/cpython-worker.py'
assert digest(protocol)==proof['cpythonWorkerSHA256']
name='scripts.ordinary-fully-supplied-helper'
catalog=read(donor/'comparison/representative.json')
catalog['cases']=[row for row in catalog['cases'] if row['id']==name]
assert len(catalog['cases'])==1
write(quiet/'representative.json',catalog)
write(quiet/'jobs.json',[[name,'warm'],[name,'compile-run']])
dotnet=Path.home()/'.dotnet11/dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent))
verified=quiet/'candidate-verify.json'
subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'representative.json',
    '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',protocol,'--out',verified],
    env=env,check=True,timeout=85)
verification=read(verified)
assert verification['state']=='Completed' and verification['caseCount']==1
assert verification['launched']['library']['sha256']==files['Lokad.Lython.dll']
assert all(digest(image/name)==value for name,value in files.items())
remote='/home/lokad/lython-bench-checks'
run='supplied-operand-window-cpython-b1525-20261123-verified'
base='supplied-call-accumulation-b1522-20261123'
write(quiet/'identity.json',dict(sourceRevision=retained,candidate=proof['candidate'],retainedRevision=retained,deliveryRevision=head,
    frozenImage=remote+'/'+run+'/candidate',imageFiles=proof['imageFiles'],
    auxiliaryFiles={name:value for name,value in files.items() if name!='Lokad.Lython.dll'},
    coreSHA256={role:files['Lokad.Lython.dll'] for role in ('candidate','candidate-control')},
    cpythonWorkerSHA256=proof['cpythonWorkerSHA256'],expectedCPythonSHA256=proof['expectedCPythonSHA256'],
    catalogs={name:dict(sha256=digest(quiet/name)) for name in ('representative.json','jobs.json')}))
past=collection/'comparison/quiet'
adapt(past/'collect.py',quiet/'collect.py',(('len(jobs) == 3','len(jobs) == 2'),('<175,','<127,'),
    ('lython-b1521-fixtures','lython-b1525-fixtures'),('CPython checkpoint after deferred CSV fields','CPython checkpoint after removing the early supplied integer boxes')))
adapt(past/'summarize.py',quiet/'summarize.py',(('len(raw["jobs"])==3','len(raw["jobs"])==2'),
    ('receipt["warmJobs"]==3','receipt["warmJobs"]==2')))
shutil.copyfile(past/'run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz') as archive:
    for name in ('identity.json','representative.json','jobs.json','run.sh','collect.py'):
        archive.add(quiet/name,arcname=name)
write(quiet/'upload.json',dict(root=run,reference=base,original='supplied-operand-window-b1524-20261123',originalArchive=status['archiveSHA256'],
    payloadBytes=payload.stat().st_size,payloadSHA256=digest(payload)))
adapt(collection/'quiet.py',lab/'quiet.py',(
    ('lython-b1521-short-csv-utf8-cpython-20261123','lython-b1525-supplied-operand-window-20261123'),
    ('.+b1521-','.+b1525-'),('lython-b1521-stage-','lython-b1525-stage-'),
    ('Three bounded lanes','Two bounded lanes'),('A 65 MiB','A 45 MiB'),('65 * 1024 * 1024','45 * 1024 * 1024'),
    ("digest(reference/'candidate'/name)","digest(reference/'candidate'/name)"),
    ('RuntimeMaxSec=210','RuntimeMaxSec=155'),('seconds=157','seconds=109'),
))

