# R221 — bounded whole-script confirmation

Three existing complete captured CSV/text/report variants add one nonlocal progress
counter with a caller assertion; fixtures/full output files unchanged and independently
verified under CPython. Identical source across the two Lython images. Ordinary text
controls prefix/code-placement effects. No CPython lane or single-kernel substitute.
Four independent roles,5s warmup,7rotated400msrounds, normalGC/tiering, fixed fec79
worker/host/optional0.4 adapter. Warm sync only; desktop async/compile/allocation
and every adverse result remain separate. No fixed gain veto or universal CPU claim.
180s owner/30stop/30margin. Full mediated RAM I/O, per-invocation validation and
prior-result cleanup included; compile/reset/separate verification/protocol/startup/
final caches excluded. Wider CPU includes surrounding work and coarse ticks.
