from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
config={'payloadBytes': 3775381, 'payloadSHA256': '2c6e88c3728114f1827c19cd7bf8305b71d5ec4e9614f7aad5370487900b8cc6', 'required': 276389888, 'coresToRetire': [], 'expectedCores': {'reference': 'd5311220899ada168ab0a4debf9651aa21a61842383bb9c19f6eb0ac60fa6851', 'reference-control': 'd5311220899ada168ab0a4debf9651aa21a61842383bb9c19f6eb0ac60fa6851', 'candidate': 'cb03fd47311a7c8252691a598c1bbe03b8ce83c67c6d0ae84e5b0266d8514060', 'candidate-control': 'cb03fd47311a7c8252691a598c1bbe03b8ce83c67c6d0ae84e5b0266d8514060'}, 'exactCopies': [{'path': 'direct-operands-b457-20261108/observations.tgz', 'canonical': 'benchmarks/results/2026-11-08-direct-operand-transport/observations.tar.xz', 'canonicalMember': 'b457/observations.tgz', 'bytes': 3919884, 'sha256': 'ec10b49d091b17202954b799049e9d67430a6d267673f36aecde8c8cf4604e7c'}, {'path': 'shared-cased-split-b453-20261108/observations.tgz', 'canonical': 'benchmarks/results/2026-11-08-shared-cased-split/observations.tar.xz', 'canonicalMember': 'b453/observations.tgz', 'bytes': 3916691, 'sha256': 'f72d516e04b26da268253534b63c365fcaeeac030e84b1b7d1325d17071a01ed'}, {'path': 'direct-native-fusion-b451-20261108/observations.tgz', 'canonical': 'benchmarks/results/2026-11-08-native-method-facts/observations.tar.xz', 'canonicalMember': 'b451/observations.tgz', 'bytes': 3915043, 'sha256': '232b175d928e4b6f37bef2329edb02ab7df2259a3be49e0f22ef2712a19561c2'}]}
base=Path('/home/lokad/lython-bench-checks').resolve();root=base/'lexical-stores-b567-20261111';source=base/'json-cpython-b566-20261111/candidate';fixture=root/'guest-fixtures'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists()and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[c]omplete-jobs.dll|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(config['payloadBytes']+1);assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:
  for name,role in [('baseline-core.dll','reference'),('current-core.dll','candidate')]:
   assert hashlib.sha256(a.extractfile(name).read()).hexdigest()==config['expectedCores'][role]
 assert hashlib.sha256((source/'Lokad.Lython.dll').read_bytes()).hexdigest()=='9dadd59bd75528186c66a9a95e2efcf411e611e0ccaa718ff38c4facdb191e33'
 stable=source/'Lokad.Lython.dll'
 assert hashlib.sha256(stable.read_bytes()).hexdigest()=='9dadd59bd75528186c66a9a95e2efcf411e611e0ccaa718ff38c4facdb191e33'
 protected=base/'json-string-b565-20261111/reference/Lokad.Lython.dll'
 assert hashlib.sha256(protected.read_bytes()).hexdigest()=='c27160d53d66489976b181fb425b2f46c927fa85156433b80dc6f5477a3e5506'
 protocol=base/'prepared-call-layout-b384-20261107/cpython-worker.py'
 assert hashlib.sha256(protocol.read_bytes()).hexdigest()=='02ca606af6b937a5bec8da744da36e6dbea45ef14ee7207732f34da052ad32f1'
 before=shutil.disk_usage(base).free;retired=[];reclaim=0
 if before<=config['required']:
  for proof in config['coresToRetire']:
   firstPath=base/proof['knownPath'];first=firstPath.lstat();key=(first.st_dev,first.st_ino)
   assert first.st_size==proof['bytes']and hashlib.sha256(firstPath.read_bytes()).hexdigest()==proof['sha256']
   aliases=[]
   for folder,dirs,files in os.walk(base):
    for name in files:
     path=Path(folder)/name;st=path.lstat()
     if(st.st_dev,st.st_ino)!=key:continue
     assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(st.st_mode)and st.st_uid==os.getuid()
     aliases.append(path.relative_to(base).as_posix())
   assert len(aliases)==first.st_nlink and aliases and proof['knownPath']in aliases
   assert proof['sha256']not in[config['expectedCores']['reference'],'9dadd59bd75528186c66a9a95e2efcf411e611e0ccaa718ff38c4facdb191e33']
   reclaim+=first.st_blocks*512;retired.append(dict(proof,paths=aliases,allocatedBytes=first.st_blocks*512,allHardlinkAliasesVerified=True))
  for exact in config['exactCopies']:
   path=base/exact['path'];st=path.lstat()
   assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(st.st_mode)and st.st_uid==os.getuid()and st.st_nlink==1
   assert st.st_size==exact['bytes']and hashlib.sha256(path.read_bytes()).hexdigest()==exact['sha256']
   reclaim+=st.st_blocks*512;retired.append(dict(exact,paths=[exact['path']],allocatedBytes=st.st_blocks*512,allHardlinkAliasesVerified=True))
  assert before+reclaim>config['required'],(before,reclaim,config['required'])
  for proof in retired:
   for path in proof['paths']:(base/path).unlink()
 assert hashlib.sha256(stable.read_bytes()).hexdigest()=='9dadd59bd75528186c66a9a95e2efcf411e611e0ccaa718ff38c4facdb191e33'
 assert hashlib.sha256((source/'Lokad.Lython.dll').read_bytes()).hexdigest()=='9dadd59bd75528186c66a9a95e2efcf411e611e0ccaa718ff38c4facdb191e33'
 assert hashlib.sha256(protected.read_bytes()).hexdigest()=='c27160d53d66489976b181fb425b2f46c927fa85156433b80dc6f5477a3e5506'
 assert shutil.disk_usage(base).free>config['required']
 beforeExtractionFreeBytes=shutil.disk_usage(base).free
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:root.mkdir();a.extractall(root,filter='data')
 recovery=dict(beforeFreeBytes=before,afterRecoveryFreeBytes=beforeExtractionFreeBytes,postExtractionFreeBytes=shutil.disk_usage(base).free,requiredFreeBytes=config['required'],freshIdleLease=True,verifiedReplacementInPayload=True,files=retired,osFloorMiB=240,evidenceHeadroomMiB=12,fullyQualifiedE122AndB8Preserved=True)
 (root/'space-recovery.json').write_text(json.dumps(recovery,indent=2)+'\n')
 shutil.copyfile(protocol,root/'cpython-worker.py')
 for role in ['reference','candidate']:
  shutil.copytree(source,root/role,copy_function=os.link)
  (root/role/'Lokad.Lython.dll').unlink();os.link(root/('baseline-core.dll'if role=='reference'else'current-core.dll'),root/role/'Lokad.Lython.dll')
 identity=json.loads((root/'identity.json').read_text())
 for role in ['reference','candidate']:
  for name,digest in{**identity['auxiliaryFiles'],'Lokad.Lython.dll':identity['coreSHA256'][role]}.items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==digest,(role,name)
 assert hashlib.sha256((root/'representative.json').read_bytes()).hexdigest()==identity['catalogSHA256']
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b567-fixtures',str(fixture)],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,imagesVerified=True,jobs=4,ownerSeconds=180,stopSeconds=30,marginSeconds=30,osFloorMiB=240,evidenceHeadroomMiB=12)
 assert setup['freeBytes']>252*1024*1024
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
try:
 subprocess.run(['sudo','-n','systemd-run','--unit=lython-b567-lexical-stores-20261111','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=180','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show','lython-b567-lexical-stores-20261111.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert'ActiveState=active'in live and'MainPID=0'not in live;print(live,flush=True)
