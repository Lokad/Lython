from pathlib import Path
import hashlib
import io
import json
import shutil
import subprocess
import tarfile
import xml.etree.ElementTree as E

repo = Path('D:/code/Lython')
root = Path(__file__).parent
target = repo / 'benchmarks/results/2026-11-11-incoming-lexical-stores'
target.mkdir(exist_ok=True)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
measured = json.loads((root / 'diagnostic-identity.json').read_text(encoding='utf-8'))
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
committed = {}
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git', 'archive', revision, 'src/Lokad.Lython'], cwd=repo))) as archive:
    for member in archive.getmembers():
        if member.isfile() and member.name.endswith('.cs'):
            committed[member.name] = hashlib.sha256(archive.extractfile(member).read().replace(b'\r\n', b'\n')).hexdigest()
assert committed == measured['measuredSource'] and len(committed) == 568
checks = {}
for path in (root / 'tests').glob('*.trx'):
    document = E.parse(path)
    checks[path.name] = next(n.attrib for n in document.iter() if n.tag.endswith('Counters'))
for suite in ['Lokad.Lython.Tests', 'Lokad.Lython.PublicApi.Tests']:
    for framework in ['net11.0', 'net10.0']:
        assert checks[f'final-{suite}-{framework}.trx']['failed'] == '0'
quiet = root / 'b567'
receipt = json.loads((quiet / 'archive-receipt.json').read_text(encoding='utf-8'))
assert receipt['complete'] and receipt['jobs'] == 4 and receipt['allWorkersJoined']
assert sha(quiet / 'observations.tgz') == receipt['archiveSHA256']
(target / 'focused-checks.json').write_text(json.dumps(checks, indent=2) + '\n', encoding='utf-8')
identity = dict(deliveryRevision=revision, measuredProductionSource=committed,
    beforeRevision=measured['before']['revision'],
    coreSHA256=json.loads((quiet / 'identity.json').read_text(encoding='utf-8'))['coreSHA256'],
    sourceQualification='Committed retained R221,672internal/2587public focused checks per actual11/10. CI42942735331 verifies exact4625d83e; full Windows/Ubuntu/stress/installed consumers pending. Includes retained R219.',
    limits='Quiet warm synchronous complete counter variants, not CPython ratios or pending-I/O latency. Desktop allocation and async/compile clocks separate, all adversity retained. Ordinary-text neutrality unresolved; no universal CPU claim.')
(target / 'source-identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8')
for name in ['before.json', 'diagnostic-identity.json', 'catalog.json', 'cpython-goldens.json',
             'semantic-goldens.json', 'semantic-golden-refinement.json', 'prepare.py', 'prepare-measure.py', 'prepare-quiet.py']:
    shutil.copyfile(root / name, target / name)
for phase in ['warm-sync', 'warm-async', 'compile']:
    data = json.loads((root / phase / 'measurements.json').read_text(encoding='utf-8'))
    assert data['allGoldensPassed'] and data['allBalancesZero'] and data['ownedFixturesRemoved']
    destination = target / phase
    destination.mkdir(exist_ok=True)
    for name in ['summary.json', 'measurements.json']:
        shutil.copyfile(root / phase / name, destination / name)
destination = target / 'quiet'
destination.mkdir(exist_ok=True)
for name in ['summary.json', 'identity.json', 'archive-receipt.json', 'terminal-status.json', 'observe-not-before.json',
             'observations.tgz', 'footprint.json', 'exact-copies.json']:
    shutil.copyfile(quiet / name, destination / name)
shutil.copyfile(quiet / 'retrieved/space-recovery.json', destination / 'space-recovery.json')
ci = json.loads((root / 'delivery-ci-status.json').read_text(encoding='utf-8-sig'))
assert ci['headSha'] == revision and ci['status'] in {'queued', 'in_progress'}
(target / 'delivery-ci-initial.json').write_text(json.dumps(ci, indent=2) + '\n', encoding='utf-8')
with tarfile.open(target / 'preparation.tar.xz', 'w:xz') as archive:
    seen = {}
    def add(path, name):
        if path.suffix == '.dll':
            digest = sha(path)
            if digest in seen:
                entry = tarfile.TarInfo(name)
                entry.type = tarfile.LNKTYPE
                entry.linkname = seen[digest]
                archive.addfile(entry)
                return
            seen[digest] = name
        archive.add(path, arcname=name)
    for framework in ['net11.0', 'net10.0']:
        add(root / f'baseline/{framework}/Lokad.Lython.dll', f'baseline/{framework}/Lokad.Lython.dll')
        add(repo / f'src/Lokad.Lython/bin/Release/{framework}/Lokad.Lython.dll', f'candidate/{framework}/Lokad.Lython.dll')
    for name in ['Lokad.Lython.Benchmarks.dll', 'Lokad.Lython.Benchmarks.deps.json',
                 'Lokad.Lython.Benchmarks.runtimeconfig.json', 'Lokad.Lython.Utf8Regex.dll',
                 'Lokad.Utf8Regex.dll', 'Lokad.Utf8Regex.PythonRe.dll']:
        add(root / 'images/candidate' / name, 'desktop-common/' + name)
    for path in root.iterdir():
        if path.is_file() and path.suffix in {'.cs', '.py', '.json', '.txt', '.md', '.log', '.patch'}:
            add(path, path.name)
    for name in ['src/Lokad.Lython/Runtime/LythonRuntime.Executable.cs',
                 'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Binding.cs',
                 'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs',
                 'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.cs',
                 'tests/Lokad.Lython.PublicApi.Tests/NativeReturnFunctionTests.cs']:
        add(repo / name, 'delivery-source/' + name)
    for folder in ['tests', 'source-before', 'tool', 'b567']:
        for path in (root / folder).rglob('*'):
            parts = path.relative_to(root).parts
            if path.is_file() and not any(x in {'obj', 'retrieved'} for x in parts) and path.suffix != '.tgz':
                add(path, path.relative_to(root).as_posix())
for name in ['preparation.tar.xz', 'quiet/observations.tgz']:
    with tarfile.open(target / name) as archive:
        for member in archive.getmembers():
            if member.isfile():
                assert len(archive.extractfile(member).read()) == member.size
(target / 'archive-identity.json').write_text(json.dumps({name: dict(bytes=(target / name).stat().st_size,
    sha256=sha(target / name)) for name in ['preparation.tar.xz', 'quiet/observations.tgz']}, indent=2) + '\n', encoding='utf-8')
print('Recorded exact568-source commit, both-target focused checks, all original failures, desktop data and four-job quiet receipt.')
