from pathlib import Path
import json
import subprocess

root = Path(__file__).parent
cases = {
    'incoming-write-live-owner': "def outer():\n value=1\n def write(x):\n  nonlocal value\n  value=x\n  return value\n print(value,write(7),value)\n value=11\n print(write(13),value)\n return write\nwrite=outer()\nprint(write(17))\n",
    'incoming-write-owner-locals': "def outer():\n value=[]\n def write(x):\n  nonlocal value\n  value=x\n  return locals()['value']\n saved=[]\n print(write(saved) is saved,value is saved,locals()['value'] is saved)\n return write\nwrite=outer()\nother=[]\nprint(write(other) is other)\n",
    'incoming-write-after-owner-deletion': "def outer():\n value=1\n def write(x):\n  nonlocal value\n  value=x\n def read():return value\n del value\n try:read()\n except NameError:print('missing')\n write(7)\n print(value,read())\n del value\n return write,read\nwrite,read=outer()\nwrite(19)\nprint(read())\n",
    'incoming-write-transitive-shadow': "value=100\ndef outer():\n value=1\n def middle():\n  nonlocal value\n  def write(x):\n   nonlocal value\n   value=x\n   return value\n  return write\n write=middle()\n print(write(7),value)\n return write\nprint(outer()(11),value)\n",
    'incoming-write-comprehension-binding': "def outer():\n value=0\n def write(items):\n  nonlocal value\n  result=[(value:=item) for item in items]\n  return result,value\n print(write([3,8]),value)\n return write\nprint(outer()([5,9]))\n",
    'incoming-write-class-cell': "class C:\n def write(self,new):\n  nonlocal __class__\n  __class__=new\n  return __class__\n def read(self):return __class__\ninstance=C()\nprint(instance.write(int).__name__,instance.read().__name__)\n",
    'incoming-write-class-body-owner': "def outer():\n value=1\n def write(x):\n  nonlocal value\n  value=x\n write(7)\n class C:\n  result=value\n print(value,C.result)\n return write,C\nwrite,C=outer()\nprint(write(11),C.result)\n",
    'incoming-write-default-and-exception': "events=[]\ndef outer():\n value=1\n def write(x=events.append('default')):\n  nonlocal value\n  value=3\n  raise ValueError(value)\n try:write()\n except ValueError as error:print(value,error.args,events)\n return write\nwrite=outer()\ntry:write(9)\nexcept ValueError as error:print(error.args,events)\n",
}
rows = []
for name, source in cases.items():
    result = subprocess.run(['C:/Python313/python.exe', '-I', '-S', '-X', 'utf8', '-c', source],
                            text=True, encoding='utf-8', capture_output=True, check=True)
    rows.append(dict(name=name, source=source, expected=result.stdout))
(root / 'semantic-goldens.json').write_text(json.dumps(dict(reference='CPython3.13.2 isolated local', cases=rows),
    ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
path = Path('D:/code/Lython/tests/Lokad.Lython.PublicApi.Tests/NativeReturnFunctionTests.cs')
text = path.read_text(encoding='utf-8')
at = text.index('        { "record-locals-and-retained-aliases"')
text = text[:at] + ''.join('        { ' + ', '.join(json.dumps(row[k], ensure_ascii=False)
    for k in ['name', 'source', 'expected']) + ' },\n' for row in rows) + text[at:]
text = text.replace('"captured-write-promotion"', '"captured-write-and-retained-reader"')
path.write_text(text, encoding='utf-8', newline='\n')
print('Eight independent observable lexical-store goldens added; no test-only frame/checkpoint counters.')
