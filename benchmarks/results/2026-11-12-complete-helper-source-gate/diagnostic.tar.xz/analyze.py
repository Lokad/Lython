from pathlib import Path
import json
r=Path(__file__).parent;d=json.loads((r/'facts.json').read_text(encoding='utf-8'))
assert d['coreSHA256'].lower()=='e4cc65b251ace242546f337b0846908a4e2a4313953da74df6fb666e1ce87529'
for case in d['facts']:
    for f in case['functions']:
        if f['path']!='module':
            print(case['caseId'],f['path'],'native',f['nativeBody'],'mirror',f['mirrors'],'fallbacks',f['statementFallbackCount'],'capacity',f['valueStorageCapacity'])
            if 'csv-validated' in case['caseId']:
                print('locals',f['localNames'])
                print([(v['index'],v['op'],v.get('localSlot'),v.get('itemCount')) for v in f['instructions']])
