from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;old=r.parent/'lexical-cell-storage-r284'
cases=json.loads((old/'catalog.json').read_text(encoding='utf-8'))['cases']
selected={c['id']:c['source'] for c in cases if any(x in c['id'] for x in ['csv-validated','json-summary','report-render','nonlocal-counter','file-search'])}
(r/'sources.json').write_text(json.dumps(selected,indent=2)+'\n',encoding='utf-8',newline='\n')
out=Path('benchmarks/results/2026-11-12-complete-helper-source-gate');out.mkdir(exist_ok=True)
for name in ['facts.json','sources.json']:shutil.copyfile(r/name,out/name)
with tarfile.open(out/'diagnostic.tar.xz','w:xz') as t:
    for p in sorted(r.iterdir()):
        if p.is_file():t.add(p,arcname=p.name)
text='''# Complete helper construction — R288 source gate

2026-11-12. Read-only compilation of the existing seven complete scripts against
qualified9bca1337/e4cc65b2 and the existing optional adapter. No runtime prototype,
timing or new qualification. The R287 tuple-storage experiment is independent.

| Existing helper | Native body prepared | Executable slots | Statement fallbacks |
| --- | --- | ---: | ---: |
| Search/wanted, both search scripts | yes | 6 | 0 |
| CSV/validated_record | no | 8 | 0 |
| Captured text/words_from_line | yes | 5 | 0 |
| JSON/record_amount | yes | 5 | 0 |
| Report/render, both encodings | no | 6 | 0 |

All these helpers have unmirrored ordinary executable scopes. CSV has three locals
(record,minimum,amount), thirteen flattened instructions and no lowered statement
fallback. It binds/executes ordinary shared workspace; there is no second local
array or unavoidable lexical-frame allocation to delete. Its local value is reused
after a branch, then two values form the actual observable return tuple. Native
preparation only forwards one immediately reloaded local; later reads decline it,
and nonempty MakeTuple is excluded. Merely extending tuple shape eligibility does
not complete this helper.

Prepared NativeBody presence is not runtime hit counts. The actual JSON helper
returns record['amount'] directly; it does not call int, and a root subscript
can complete under the existing native guard. Do not invent a coverage gap for it.
The CSV helper does call int on a computed dictionary field. In a proposed expanded
body, Subscript validates dictionary/key but leaves computed shape Other, whereas
BuiltinUnary needs an actual argument or accepted computed shape. Extending local/
tuple construction therefore also needs a coherent guard/value policy for this
computed input. This is a source design requirement, not current native hit counts
or an attribution of the full CPython gap.

**The direct local/tuple-node extension is insufficient.** A single-assignment
local must evaluate once and remain available to later branches/return; substituting
its expression repeats conversion, admission and error effects. Guarding every later
dictionary field before execution is also insufficient: int parsing/formatting can
admit storage, and host reentry can change a later field/type. An actual later
protocol can require asynchronous host I/O. Whole-call restart after those effects
is forbidden. Current native entry/proof/evaluation is valuable (R268 replacement
measured slower), but extending its eligibility must preserve actual ordered reads
and a complete transition to the ordinary executable state when required.

The larger design must identify the code it removes: recurring ordinary operand/
instruction transport for complete eligible helpers, plus the current limited
single-load forwarder and any displaced native-state code. Preserve exact Python
tuples/defaults/aliases/branch and error order; no new private result convention,
second dispatcher, cache, general type solver or replay. Keep shared admission,
first refusal, cancellation, managed stack and funded pending cleanup. Read-only
facts do not prove that a larger promotion scheme is simpler or faster.

This bounded gate closes with a precise obstacle to the proposed simple expansion,
not a failed design or permanent architecture veto. Continue design around one
ordered call state, or choose a materially different source-backed stage. Require
an explicit removal argument before implementation; compare complete CSV/JSON and
search/captured/report controls, compilation and fresh boundaries if selected.
Do not count another isolated storage experiment as completing the performance goal.

[Exact executable facts](facts.json), [unchanged script sources](sources.json),
[inspection sources/build and analysis](diagnostic.tar.xz). No repeated platform,
stress/package run or producer-version probing. Publication remains postponed.
'''
(out/'README.md').write_text(text,encoding='utf-8',newline='\n')
files={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in out.iterdir()if p.is_file()and p.name not in ['README.md','manifest.json']}
(out/'manifest.json').write_text(json.dumps(files,indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')
s=s.replace('3. **Next substantial call/return milestone: source proof before migration.**','3. **Next substantial call/return milestone: ordered state design.**')
s=s.replace('   - Bounded source gate: map this exact helper plus captured/search/report controls,\n     identify eligibility and post-effect transition requirements, and finish with\n     one implementable design or a precise source objection. A literal/local node\n     tweak alone does not finish the milestone.', '''   - R288's bounded source gate now maps all seven scripts: CSV has13 ordinary
     instructions/8slots and0statement fallbacks; nonempty tuple and repeated local
     use prevent native preparation. JSON directly returns a field and is prepared;
     CSV's computed int(field) adds a guard/value requirement to any expansion.
     Prepared metadata is not runtime hit counts. A local initializer
     cannot be duplicated, and early field-type proof cannot survive arbitrary
     admission reentry. [Exact facts/objection](benchmarks/results/2026-11-12-complete-helper-source-gate/README.md).
     The simple local/tuple-node proposal is insufficient. Next design one ordered
     call state with complete ordinary/protocol transition and explicit displaced
     code; stop before implementation if it merely adds another frame/controller.
     No permanent rejection or automatic broader compiler rewrite follows.''')
p.write_text(s,encoding='utf-8',newline='\n')
print('Recorded complete-helper facts and the ordered-effect design obstacle; no guessed native coverage or CPU claim.')
print(selected.get('scripts.json-summary-helpers.large',''))
