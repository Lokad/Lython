using System.Collections;
using System.Reflection;
using System.Runtime.Loader;
using System.Security.Cryptography;
using System.Text.Json;

var directory = Path.GetDirectoryName(Path.GetFullPath(args[0]))!;
AssemblyLoadContext.Default.Resolving += (_, name) =>
{
    var path = Path.Combine(directory, name.Name + ".dll");
    return File.Exists(path) ? AssemblyLoadContext.Default.LoadFromAssemblyPath(path) : null;
};
var core = AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.GetFullPath(args[0]));
var adapter = AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.Combine(directory, "Lokad.Lython.Utf8Regex.dll"));
var provider = adapter.GetType("Lokad.Lython.Utf8Regex.Utf8RegexProvider", true)!.GetProperty("Instance")!.GetValue(null);
var frontend = core.GetType("Lokad.Lython.Frontend.LythonFrontend", true)!.GetMethod("Compile")!;
var lower = core.GetType("Lokad.Lython.Frontend.LoweredScript", true)!.GetMethod("Lower")!;
var executable = core.GetType("Lokad.Lython.Frontend.ExecutableScript", true)!.GetMethod("Compile")!;
using var catalog = JsonDocument.Parse(File.ReadAllBytes(args[1]));
var facts = new List<object>();
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var parsed = frontend.Invoke(null, [item.GetProperty("source").GetString(), null, provider, CancellationToken.None, null])!;
    var syntax = Read(parsed, "Script") ?? throw new InvalidDataException("Invalid existing source: " + item.GetProperty("id").GetString());
    var lowered = lower.Invoke(null, [syntax])!;
    var program = executable.Invoke(null, [lowered])!;
    var functions = new List<object>();
    Walk(Read(program, "EntryPoint")!, "module", functions);
    facts.Add(new { caseId = item.GetProperty("id").GetString(), functions });
}
Console.WriteLine(JsonSerializer.Serialize(new {
    coreSHA256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))),
    catalogSHA256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[1]))),
    runtime = System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription,
    purpose = "Read-only executable eligibility/source gate; no execution, timing or optimization claim", facts
}));

static object? Read(object value, string name) => value.GetType().GetProperty(name,
    BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)?.GetValue(value);

static void Walk(object code, string path, List<object> output)
{
    var instructions = new List<object>();
    var index = 0;
    foreach (var instruction in (IEnumerable)Read(code, "Instructions")!)
    {
        var op = Read(instruction, "OpCode")!.ToString()!;
        var row = new Dictionary<string, object?> { ["index"] = index++, ["op"] = op,
            ["inputStart"] = Read(instruction, "InputStart"), ["resultSlot"] = Read(instruction, "ResultSlot"),
            ["liveExtent"] = Read(instruction, "LiveExtent") };
        if (op is "LoadLocal" or "StoreLocal") row["localSlot"] = Read(instruction, "LocalSlot");
        if (op is "MakeTuple" or "MakeList") row["itemCount"] = Read(instruction, "ItemCount");
        instructions.Add(row);
    }
    output.Add(new { path, nativeBody = Read(code, "NativeBody") is not null,
        mirrors = Read(code, "RequiresLocalVariableMirroring"), localNames = Read(code, "LocalNames"),
        capturedSlots = Read(code, "CapturedLocalSlots"), valueStorageCapacity = Read(code, "ValueStorageCapacity"),
        statementFallbackCount = ((IEnumerable)Read(code, "StatementFallbacks")!).Cast<object>().Count(), instructions });
    foreach (var binding in (IEnumerable)Read(code, "Functions")!)
        Walk(Read(binding, "CodeObject")!, path + "/" + Read(binding, "Name"), output);
}
