from pathlib import Path
import os,subprocess
r=Path(__file__).parent
(r/'inspect.csproj').write_text('<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net11.0</TargetFramework><ImplicitUsings>enable</ImplicitUsings><Nullable>enable</Nullable><IsPackable>false</IsPackable><EnableDefaultCompileItems>false</EnableDefaultCompileItems></PropertyGroup><ItemGroup><Compile Include="Program.cs" /></ItemGroup></Project>\n',encoding='utf-8',newline='\n')
sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
with (r/'build.log').open('w',encoding='utf-8',newline='\n') as log:done=subprocess.run([str(sdk/'dotnet.exe'),'build',str(r/'inspect.csproj'),'-c','Release'],env=env,stdout=log,stderr=subprocess.STDOUT)
assert done.returncode==0,(r/'build.log').read_text(encoding='utf-8')
old=r.parent/'lexical-cell-storage-r284'
with (r/'facts.json').open('w',encoding='utf-8',newline='\n') as stdout,(r/'inspect.stderr').open('w',encoding='utf-8',newline='\n') as stderr:
    done=subprocess.run([str(sdk/'dotnet.exe'),str(r/'bin/Release/net11.0/inspect.dll'),str(old/'reference/Lokad.Lython.dll'),str(old/'catalog.json')],env=env,stdout=stdout,stderr=stderr)
assert done.returncode==0,(r/'inspect.stderr').read_text(encoding='utf-8')
print('Seven unchanged scripts compile; immutable eligibility/operand facts recorded, no runtime work or timing.')
