from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
quiet = lab/"quiet"
out = Path("benchmarks/results/2026-11-22-direct-range-cursors")
def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

identity = read(quiet/"identity.json")
before, _, after = identity["sourceRevision"].split()
assert before.startswith("12cecc6cf") and after.startswith("3bbc7a416")
cases = {c["id"]:c for c in read(quiet/"representative.json")["cases"]}
assert len(cases)==4
for role,files in identity["imageFiles"].items():
    image = lab/"frozen"/role
    assert len(files)==32 and {n:sha(image/n) for n in files}==files
    for prefix in ("","quiet-"):
        proof = read(lab/f"{prefix}{role}-verify.json")
        catalog = (quiet if prefix else lab)/"representative.json"
        assert proof["state"]=="Completed" and proof["caseCount"]==4 and proof["catalogSha256"]==sha(catalog)
allocation = read(lab/"allocation-summary.json")
assert len(allocation)==4 and all(r["allowanceRestored"] and r["referenceAccountedPeak"]==r["candidateAccountedPeak"] for r in allocation)
assert all(row["allocationChangePercent"]<0 for row in allocation)
for platform in ("win","ubuntu"):
    for suite,count in (("white",431),("public",1551)):
        text = (lab/f"{suite}-{platform}.log").read_text(encoding="utf-8-sig")
        assert "Passed!" in text and f"Passed: {count:5d}, Skipped:" in text
receipt = read(quiet/"archive-receipt.json")
terminal = read(quiet/"terminal-status.json")
assert receipt==terminal["receipt"] and terminal["exitCode"]=="0"
for name in ("machine-before.json","machine-after.json"):
    assert read(quiet/"retrieved/confirmation"/name)["gate"]["quiet"]
assert not terminal["remainingWorkers"] and not terminal["remainingTrace"]
assert all(receipt[k] for k in ("complete","allWorkersJoined","guestFixturesRemoved","quietBeforeAndAfter","archivedAndVerifiedUnderLease"))
assert sha(quiet/"observations.tgz")==receipt["archiveSHA256"]
raw = read(quiet/"retrieved/confirmation/confirmation.json")
assert raw["complete"] and raw["warmupSeconds"]==8 and raw["targetBatchSeconds"]==.65 and raw["rounds"]==7
assert len(raw["jobs"])==receipt["jobs"]==4
assert [(j["case"],j["lane"]) for j in raw["jobs"]]==[(case,"warm") for case in cases]
for job in raw["jobs"]:
    case = cases[job["case"]]
    assert job["workersJoinedAndFixturesRemoved"] and len(job["samples"])==28
    for sample in job["samples"]:
        response = sample["response"]
        assert response["completedInvocations"]>0 and response["status"]=="Completed"
        assert response["sourceSha256"]==case["sourceSha256"] and response["fixtureSha256"]==case["fixtureSha256"]
        assert response["actualOutputSha256"]==case["expectedOutputSha256"]
        assert response.get("actualFilesSha256")==case.get("expectedFilesSha256")
summary = read(quiet/"quiet-summary.json")
del summary["retentionDecisionPending"]
summary.update(collection="B1350",sourceRevision=identity["sourceRevision"],verifiedTimedBatches=112,
    coreSHA256=identity["coreSHA256"],archiveSHA256=receipt["archiveSHA256"],
    retentionDecision=read(lab/"decision.json")["decision"])
out.mkdir(exist_ok=False)
(out/"summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8",newline="\n")
for name in ("README.md","allocation-summary.json"):
    shutil.copyfile(lab/name,out/name)
for name in ("archive-receipt.json","terminal-status.json","observations.tgz"):
    shutil.copyfile(quiet/name,out/name)
authority = Path("benchmarks/results/2026-11-22-computed-capture-stores/candidate-core.dll.gz")
assert gzip.decompress(authority.read_bytes())==(quiet/"reference/Lokad.Lython.dll").read_bytes()
core = (quiet/"candidate/Lokad.Lython.dll").read_bytes()
(out/"candidate-core.dll.gz").write_bytes(gzip.compress(core,mtime=0))
(lab/"measured-source.patch").write_bytes(subprocess.check_output(["git","diff",before,after,"--","src","tests"]))
with tarfile.open(out/"checks-and-procedures.tar.xz","w:xz",preset=6) as archive:
    for folder in (lab,quiet):
        for path in sorted(folder.iterdir()):
            if path.is_file() and path.suffix not in {".dll",".tgz"}:
                archive.add(path,arcname=path.relative_to(lab).as_posix())
print("112 timed batches, all image files, goldens, allocations, ownership regressions verified.")
