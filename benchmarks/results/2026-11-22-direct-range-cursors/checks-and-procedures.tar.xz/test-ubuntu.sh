#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/direct-range-cursor-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
dir=/mnt/d/code/Lython/.git/agent-notes/review-20261031/direct-range-cursor-20261122
filter='Category!=Stress&(FullyQualifiedName~Range|FullyQualifiedName~Iteration|FullyQualifiedName~Generator|FullyQualifiedName~Comprehension|FullyQualifiedName~MemoryOwnership|FullyQualifiedName~Cancellation|FullyQualifiedName~Captured)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter "$filter" --verbosity quiet > "$dir/white-ubuntu.log" 2>&1 || { tail -30 "$dir/white-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter "$filter" --verbosity quiet > "$dir/public-ubuntu.log" 2>&1 || { tail -30 "$dir/public-ubuntu.log"; exit 1; }
grep -H 'Passed!' "$dir/white-ubuntu.log" "$dir/public-ubuntu.log"
