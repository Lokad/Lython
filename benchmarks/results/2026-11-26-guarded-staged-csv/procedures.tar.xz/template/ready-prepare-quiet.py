from pathlib import Path
import ast
import hashlib
import json
import shutil
import tarfile

lab=Path(__file__).resolve().parent
quiet=lab/'comparison/quiet'
quiet.mkdir(parents=True,exist_ok=True)
baseline=lab.parent/'json-magnitude-utf8-20261126'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(path,data): path.write_text(data,encoding='utf-8',newline='\n')
def save(path,data): write(path,json.dumps(data,ensure_ascii=False,indent=2)+'\n')

identity=read(lab/'identity.json')
baseline_quiet=baseline/'comparison/quiet'
donor=read(baseline_quiet/'identity.json')
receipt=read(baseline_quiet/'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['allWorkersJoined'] and sha(baseline_quiet/'observations.tar.xz')==receipt['archiveSHA256']
assert identity['imageFiles']['reference']==donor['imageFiles']['candidate']
for role,files in identity['imageFiles'].items():
    assert len(files)==32 and {p.name:sha(p) for p in (lab/role).iterdir()}==files
    golden=read(lab/f'{role}-verify.json')
    assert golden['state']=='Completed' and golden['caseCount']==4 and golden['catalogSha256']==identity['catalogSHA256']
    assert golden['launched']['library']['sha256']==files['Lokad.Lython.dll']
shutil.copyfile(lab/'representative.json',quiet/'representative.json')
shutil.copyfile(baseline_quiet/'cpython-worker.py',quiet/'cpython-worker.py')
assert sha(quiet/'cpython-worker.py')==identity['cpythonWorkerSHA256']
save(quiet/'jobs.json',{'warm':[
    ['diagnostic.shipment-bound-starmap','warm-async'],
    ['diagnostic.shipment-retained-zip','warm-async'],
    ['diagnostic.shipment-routing-callbacks','warm-async'],
    ['diagnostic.shipment-bound-starmap','warm'],
]})
identity['coreSHA256'].update({role+'-control':identity['coreSHA256'][role] for role in identity['imageFiles']})
identity['catalogs']={name:{'sha256':sha(quiet/name)} for name in ('representative.json','jobs.json')}
identity['purpose']='Compare fixed zip unpack and starmap ready results against retained tuple and synchronous controls.'
save(quiet/'identity.json',identity)
body=(baseline_quiet/'collect.py').read_text(encoding='utf-8-sig').replace('lython-b1751-fixtures','lython-b1753-fixtures')
body=body.replace('len(jobs) == 3','len(jobs) == 4')
required={node.slice.value for node in ast.walk(ast.parse(body)) if isinstance(node,ast.Subscript)
          and isinstance(node.value,ast.Name) and node.value.id=='identity' and isinstance(node.slice,ast.Constant)}
assert required<=identity.keys(),required-identity.keys()
write(quiet/'collect.py',body)
shutil.copyfile(baseline_quiet/'run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()

source=(baseline/'quiet.py').read_text(encoding='utf-8-sig')
source=source.replace('lython-b1751-json-magnitude-utf8-20261126','lython-b1753-ready-shipment-rows-20261126')
source=source.replace("donor=base/'short-path-cpython-b1750-20261126'", "donor=base/'json-magnitude-utf8-b1751-20261126'")
source=source.replace("verified['caseCount']==3","verified['caseCount']==4")
source=source.replace('RuntimeMaxSec=210','RuntimeMaxSec=270').replace('seconds=170','seconds=219')
start=source.index('bytes=shutil.disk_usage(base).free')
end=source.index("assert bytes>cfg['payloadBytes']",start)
source=source[:start]+'''with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 retired=base/'whitespace-bulk-20261101-ae22392d.tar.gz'
 initial=shutil.disk_usage(base).free
 if retired.is_file():
  assert retired.resolve()==retired and retired.parent==base and retired.stat().st_nlink==1
  assert retired.stat().st_size==cfg['replicaBytes'] and sha(retired)==cfg['replicaSHA256']
  retired.unlink()
 bytes=shutil.disk_usage(base).free
 print(json.dumps(dict(freeBeforeUploadBytes=bytes,freeBeforeReclaimBytes=initial,
  verifiedDuplicate=retired.name,duplicateSHA256=cfg['replicaSHA256'])))
'''+source[end:]
source=source.replace('print(json.dumps(dict(freeBeforeUploadBytes=bytes)))','')
compile(source,'quiet.py','exec');write(lab/'quiet.py',source)
replica=lab.parent/'whitespace-bulk/payload.tar.gz'
assert sha(replica)=='188256d3745d52d1f6d6bbbb2bebb1379526a8b09ed4a19de94e28cf6eeb523b'
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=6) as arc:
    for name in ('identity.json','jobs.json','representative.json','collect.py','run.sh','cpython-worker.py'):
        arc.add(quiet/name,arcname=name,recursive=False)
    arc.add(lab/'candidate/Lokad.Lython.dll',arcname='new-core.dll',recursive=False)
save(quiet/'upload.json',dict(root='ready-shipment-rows-b1753-20261126',payloadSHA256=sha(payload),
     payloadBytes=payload.stat().st_size,donorSHA256=receipt['archiveSHA256'],replicaSHA256=sha(replica),
     replicaBytes=replica.stat().st_size))
