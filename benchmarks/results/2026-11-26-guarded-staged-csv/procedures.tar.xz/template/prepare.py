from pathlib import Path
from statistics import median
import base64
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
baseline = lab.parent/'short-path-cpython-20261126'
prior = lab.parent/'json-integer-r46'
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
git = lambda *args: subprocess.check_output(['git',*args],cwd=repo)
def save(path,data):
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')

revision = git('rev-parse','HEAD').decode().strip()
assert revision.startswith('0a0e32c16')
assert git('diff','--name-only',revision,'--','src').decode().splitlines() == ['src/Lokad.Lython/Runtime/LythonRuntime.Json.Deserialize.cs']
patch = git('diff','--binary',revision,'--','src')
(lab/'candidate.patch').write_bytes(patch)
sdk = Path.home()/'.dotnet11'
dotnet = sdk/'dotnet.exe'
env = dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
with (lab/'frozen-build.log').open('wb') as log:
    subprocess.run([dotnet,'build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0',
                    '--no-incremental','--artifacts-path',lab/'image-build'],cwd=repo,env=env,stdout=log,
                   stderr=subprocess.STDOUT,check=True,timeout=150)
assert patch == git('diff','--binary',revision,'--','src')
before = read(baseline/'comparison/quiet/identity.json')
reference = before['imageFiles']['candidate']
donor = baseline/'candidate'
assert before['sourceRevision']==revision and len(reference)==32 and {p.name:sha(p) for p in donor.iterdir()}==reference
core = lab/'image-build/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'
images = {'reference': reference, 'candidate': reference | {core.name:sha(core)}}
assert images['candidate'][core.name]!=reference[core.name]
for role,files in images.items():
    folder = lab/role
    folder.mkdir(exist_ok=True)
    for name in files:
        shutil.copyfile(core if role=='candidate' and name==core.name else donor/name,folder/name)
    assert {p.name:sha(p) for p in folder.iterdir()}==files

catalog=read(prior/'catalog.json')
catalog['cases']=[case for case in catalog['cases'] if case['id'].startswith('scripts.json-summary-helpers.')]
assert len(catalog['cases'])==3
save(lab/'representative.json',catalog)
cases=lab/'representative.json'
worker=repo/'benchmarks/cpython-worker.py'
assert sha(worker)==before['cpythonWorkerSHA256']
alloc_tool=lab.parent/'json-traversal-20261124/reference'
rows={}
for role,files in images.items():
    proof=lab/f'{role}-verify.json'
    subprocess.run([dotnet,lab/role/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',cases,
                    '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',worker,'--out',proof],
                   cwd=repo,env=env,check=True,timeout=65)
    checked=read(proof)
    assert checked['state']=='Completed' and checked['caseCount']==3 and checked['catalogSha256']==sha(cases)
    assert checked['launched']['library']['sha256']==files[core.name]
    allocated=lab/f'{role}-allocated'
    allocated.mkdir(exist_ok=True)
    for name,digest in files.items():
        shutil.copyfile(lab/role/name,allocated/name)
        assert sha(allocated/name)==digest
    for source in alloc_tool.glob('ValidatedAllocation*'):
        shutil.copyfile(source,allocated/source.name)
    output=lab/f'{role}-refined-allocation.json'
    subprocess.run([dotnet,allocated/'ValidatedAllocation.dll',allocated,cases,output],cwd=repo,env=env,check=True,timeout=60)
    rows[role]=read(output)['rows']

summary=[]
for old,new,case in zip(rows['reference'],rows['candidate'],catalog['cases'],strict=True):
    assert old['id']==new['id']==case['id'] and all(r['sharedBudgetBaselineRestored'] for r in (old,new))
    data=json.loads(case['fixtureJson'])
    summary.append(dict(case=case['id'],records=case['size'],inputBytes=sum(len(base64.b64decode(f)) for f in data['inputFiles'].values()),
                        allocationBytes=[median(r['allocatedBytesPerInvocation']) for r in (old,new)],
                        peakAdmission=[r['peakExecutionMemoryBytes'] for r in (old,new)]))
save(lab/'allocation-summary.json',summary)
save(lab/'identity.json',dict(sourceRevision=revision,sourcePatchSHA256=sha(lab/'candidate.patch'),imageFiles=images,
                              coreSHA256={role:files[core.name] for role,files in images.items()},catalogSHA256=sha(cases),
                              cpythonWorkerSHA256=sha(worker),expectedCPythonSHA256=before['expectedCPythonSHA256']))
print(json.dumps(summary,indent=2))
