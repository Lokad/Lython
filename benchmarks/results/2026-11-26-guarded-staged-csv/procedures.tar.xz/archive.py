import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
quiet = lab / 'comparison' / 'quiet'
root = lab.parents[3]
previous = lab.with_name('transformed-csv-rows-20261126')
ready = lab.with_name('ready-shipment-rows-20261126')
wide = lab.with_name('json-magnitude-utf8-20261126')
result = root / 'benchmarks/results/2026-11-26-guarded-staged-csv'
identity = json.loads((quiet/'identity.json').read_text(encoding='utf-8'))
def git(*args):
    return subprocess.check_output(['git',*args],cwd=root)
delivery = git('rev-parse','4a273f36d').decode().strip()
patch = git('diff','--binary',identity['sourceRevision'],delivery,'--','src')
assert patch == (lab/'candidate.patch').read_bytes()
assert hashlib.sha256(patch).hexdigest() == identity['sourcePatchSHA256']
assert git('diff','--binary',identity['sourceRevision'],delivery,'--','tests') == (lab/'focused-tests.patch').read_bytes()
terminal = json.loads((quiet/'terminal-status.json').read_text(encoding='utf-8'))
assert hashlib.sha256((quiet/'observations.tar.xz').read_bytes()).hexdigest() == terminal['receipt']['archiveSHA256']
result.mkdir()
for name in ('summary.json','allocation-summary.json','routes.json'):
    shutil.copyfile(lab/name,result/name)
shutil.copyfile(previous/'routes.json',result/'transformed-only-routes.json')
shutil.copyfile(previous/'allocation-summary.json',result/'transformed-only-allocation.json')
for name in ('identity.json','terminal-status.json','observations.tar.xz'):
    shutil.copyfile(quiet/name,result/name)

local_files = (
    'candidate.patch','focused-tests.patch','prepare.py','prepare-quiet.py','quiet.py','summarize.py',
    'archive.py','reference-verify.json','candidate-verify.json','reference-allocation.json','candidate-allocation.json',
    'frozen-build.log','verify-routes.py','test-ubuntu.sh','Lokad.Lython.PublicApi.Tests-ubuntu10.log',
    'Lokad.Lython.Tests-ubuntu10.log','delivery-dispatch.log',
    'instrumented/Program.cs','instrumented/RouteProbe.csproj','instrumented/diagnostic.patch','instrumented/cases.json',
    'instrumented/core.log','instrumented/probe.log','instrumented/verify.log',
)
prior_files = (
    'candidate.patch','identity.json','staged-reference-win11.log','Lokad.Lython.Tests-staged-win11.log',
    'Lokad.Lython.PublicApi.Tests-staged-win11.log','Lokad.Lython.Tests-win11.log','Lokad.Lython.PublicApi.Tests-win11.log',
    'verify-routes.py','prepare.py','reference-verify.json','candidate-verify.json','instrumented/diagnostic.patch',
)
quiet_files = ('launch.log','collect.py','run.sh','jobs.json','representative.json','cpython-worker.py')
with tarfile.open(result/'procedures.tar.xz','w:xz') as archive:
    for name in local_files:
        archive.add(lab/name,arcname=name)
    for name in prior_files:
        archive.add(previous/name,arcname='prior/'+name)
    for name in quiet_files:
        archive.add(quiet/name,arcname='quiet/'+name)
    for name in ('prepare.py','quiet.py','comparison/quiet/collect.py','comparison/quiet/run.sh'):
        archive.add(wide/name,arcname='template/'+name)
    archive.add(ready/'prepare-quiet.py',arcname='template/ready-prepare-quiet.py')
with tarfile.open(result/'procedures.tar.xz') as archive:
    assert archive.extractfile('candidate.patch').read() == patch
    assert len(archive.getmembers())==len(local_files)+len(prior_files)+len(quiet_files)+5