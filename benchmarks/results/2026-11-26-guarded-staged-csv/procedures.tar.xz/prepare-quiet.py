from pathlib import Path

lab = Path(__file__).resolve().parent
template = lab.with_name('ready-shipment-rows-20261126')/'prepare-quiet.py'
source = template.read_text(encoding='utf-8')
source = source.replace('1753','1755').replace('ready-shipment-rows','staged-csv-rows')
old = """    ['diagnostic.shipment-bound-starmap','warm-async'],
    ['diagnostic.shipment-retained-zip','warm-async'],
    ['diagnostic.shipment-routing-callbacks','warm-async'],
    ['diagnostic.shipment-bound-starmap','warm'],"""
new = """    ['scripts.csv-invoice.method-policy.quoted-control','warm'],
    ['scripts.csv-invoice.method-policy.quoted-control','warm-async'],
    ['diagnostic.invoice-plain-reader','warm'],"""
assert source.count(old)==1
source = source.replace(old,new)
source = source.replace("body=body.replace('len(jobs) == 3','len(jobs) == 4')","")
source = source.replace(".replace('seconds=170','seconds=219')","")
source = source.replace(".replace('RuntimeMaxSec=210','RuntimeMaxSec=270')","")
source = source.replace("source=source\n","")
source = source.replace('Compare fixed zip unpack and starmap ready results against retained tuple and synchronous controls.',
                        'Compare guarded staged dictionary publication for the quoted invoice, with a plain-reader control.')
start = source.index("start=source.index('bytes=shutil.disk_usage(base).free')")
end = source.index("payload=quiet/'stage.tar.gz'",start)
source = source[:start] + "compile(source,'quiet.py','exec');write(lab/'quiet.py',source)\n" + source[end:]
source = source.replace(",replicaSHA256=sha(replica),\n     replicaBytes=replica.stat().st_size)",")")
exec(compile(source,str(template),'exec'),{'__file__':str(lab/'prepare-quiet.py')})