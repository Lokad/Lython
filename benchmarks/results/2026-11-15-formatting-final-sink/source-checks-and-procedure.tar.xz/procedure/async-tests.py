from pathlib import Path
p=Path('tests/Lokad.Lython.Tests/StringFormatPrimitiveTests.cs');s=p.read_text(encoding='utf-8').replace('    // Consume the production async API synchronously for primitive error/golden assertions.','    // Keep primitive error/golden assertions on the production async API.')
s=s.replace('private static PyString Format(', 'private static Task<PyString> Format(').replace('forbidPositionalFields).GetAwaiter().GetResult();','forbidPositionalFields).AsTask();').replace('public void ', 'public async Task ')
for n in ['manual','automatic','formatted','named']:s=s.replace('var '+n+' = Format(', 'var '+n+' = await Format(')
s=s.replace('Assert.Throws<InvalidOperationException>(() => Format(', 'await Assert.ThrowsAsync<InvalidOperationException>(() => Format(')
p.write_text(s,encoding='utf-8',newline='\n')
