from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile,xml.etree.ElementTree as E
repo=Path.cwd();r=Path(__file__).parent;q=r/'quiet';out=repo/'benchmarks/results/2026-11-15-formatting-final-sink';out.mkdir();ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
for src,n in [(r/'summary.json','summary.json'),(r/'allocation-summary.json','allocation-summary.json'),(r/'r415-source-decision.json','r415-source-decision.json'),(r/'python-goldens.json','python-goldens.json'),(r/'frozen/identity.json','identity.json'),(q/'observations.tgz','observations.tgz'),(q/'archive-receipt.json','archive-receipt.json'),(q/'terminal-status.json','terminal-status.json')]:shutil.copyfile(src,out/n)
checks={}
with tarfile.open(out/'source-checks-and-procedure.tar.xz','w:xz')as t:
 for n in ['sources-and-checks.tar.xz','reference/Lokad.Lython.dll','candidate/Lokad.Lython.dll']:t.add(r/'frozen'/n,arcname='frozen/'+n)
 for p in r.iterdir():
  if p.is_file()and p.name not in ['baseline-source.tar']:t.add(p,arcname='procedure/'+p.name)
 for p in q.iterdir():
  if p.is_file()and p.name!='observations.tgz':t.add(p,arcname='quiet/'+p.name)
 for p in(r/'allocation').iterdir():
  if p.is_file():t.add(p,arcname='allocation/'+p.name)
 for p in(r/'allocation/bin/Release/net11.0').glob('ValidatedAllocation.*'):t.add(p,arcname='allocation/driver/'+p.name)
 for suite in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:
  for p in(repo/'tests'/suite/'TestResults').glob('r416-*.trx'):
   checks[suite+'/'+p.name]=E.parse(p).find('.//t:Counters',ns).attrib;t.add(p,arcname='checks/'+suite+'/'+p.name)
base=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))['baseCommit'];(out/'original-format-protocol-tests.cs.txt').write_bytes(subprocess.check_output(['git','show',base+':tests/Lokad.Lython.PublicApi.Tests/FormatProtocolTests.cs']))
summary=json.loads((out/'summary.json').read_text(encoding='utf-8'));summary.update(retained=True,retentionDecisionPending=False,reason='Whole output contract and ownership simplification; real hosted str.format callbacks;17.31%allocation and warm/fresh CPU/elapsed support. Control adversity remains explicit.',fullQualificationPending=True,compatibility='str.format now awaits supported hosted callbacks in RunAsync; conservative operation metadata/argument admission can reject earlier. No public API/dependency/policy switch.')
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n');(out/'checks.json').write_text(json.dumps(dict(checks=checks,cleanNonincrementalReleaseSolutionBuildPassed=True,independentCPythonFullGoldensPassed=True,originalFailure='Two old assertions expected unsupported hosted str.format; new operation succeeds. Original test source and initial TRX retained. Primitive helper migration and CP launcher/cleanup mistakes are not runtime failures.',publicApiSignatureChanges=False,publicationHeld=True),indent=2)+'\n',encoding='utf-8',newline='\n');print('Preserved R415 source gate, R416 coherent source/binaries, full goldens, allocation/timing controls and original conditions.')
