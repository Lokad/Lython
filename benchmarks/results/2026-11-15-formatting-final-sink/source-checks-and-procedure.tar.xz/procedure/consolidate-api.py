from pathlib import Path
p=Path('src/Lokad.Lython/Runtime/Text/PyStringOps.Formatting.cs');s=p.read_text(encoding='utf-8');a=s.index('    public static PyString Format(');b=s.index('    {\n        var state = new FormatState(',a)
s=s[:a]+'''    public static async ValueTask<PyString> FormatAsync(
        PyString template,
        IReadOnlyList<object> positional,
        IReadOnlyDictionary<string, object>? keywords,
        Func<object, string, ValueTask<object>>? resolveFieldSuffix,
        Func<GovernedByteBuilder, object, char?, string?, ValueTask>? appendValue,
        MemoryGovernor? governor,
        LythonSourceSpan? span,
        bool forbidPositionalFields = false,
        CancellationToken cancellationToken = default,
        Func<string, ValueTask<object>>? resolveKeyword = null)
'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.StringMembers.AffixFormat.cs');s=p.read_text(encoding='utf-8').replace('                    context.State.CancellationToken).ConfigureAwait(false);','                    cancellationToken: context.State.CancellationToken).ConfigureAwait(false);')
s=s.replace('PyStringOps.FormatMapAsync(text, ResolveKeyword,','PyStringOps.FormatAsync(text, [], null,').replace('context.MemoryGovernor, span, context.State.CancellationToken).ConfigureAwait(false);','context.MemoryGovernor, span, forbidPositionalFields: true,\n                    cancellationToken: context.State.CancellationToken, resolveKeyword: ResolveKeyword).ConfigureAwait(false);')
p.write_text(s,encoding='utf-8',newline='\n')
p=Path('tests/Lokad.Lython.Tests/StringFormatPrimitiveTests.cs');s=p.read_text(encoding='utf-8').replace('PyStringOps.Format(', 'Format(')
s=s.replace('void FormatStub(', 'ValueTask FormatStub(').replace('                ? rendered : $"<{rendered}|{conversion?.ToString() ?? "-"}|{spec ?? "-"}>");','                ? rendered : $"<{rendered}|{conversion?.ToString() ?? "-"}|{spec ?? "-"}>");\n            return default;')
s=s.replace('static object PassThrough(object current, string suffix) => current;', 'static ValueTask<object> PassThrough(object current, string suffix) => new(current);')
s=s.replace('(output, value, conversion, spec) => output.AppendString("!")','(output, value, conversion, spec) => { output.AppendString("!"); return default; }')
s=s.replace('                return current;','                return new ValueTask<object>(current);').replace('(current, suffix) => current,','(current, suffix) => new(current),')
needle='public sealed class StringFormatPrimitiveTests\n{'
assert needle in s;s=s.replace(needle,needle+'''
    // Consume the production async API synchronously for primitive error/golden assertions.
    private static PyString Format(PyString template, IReadOnlyList<object> positional,
        IReadOnlyDictionary<string, object>? keywords, Func<object, string, ValueTask<object>>? suffix,
        Func<GovernedByteBuilder, object, char?, string?, ValueTask>? append,
        MemoryGovernor? governor, LythonSourceSpan? span, bool forbidPositionalFields = false)
        => PyStringOps.FormatAsync(template, positional, keywords, suffix, append, governor, span,
            forbidPositionalFields).GetAwaiter().GetResult();
''',1);p.write_text(s,encoding='utf-8',newline='\n')
p=Path('tests/Lokad.Lython.Tests/FormatStorageTests.cs');s=p.read_text(encoding='utf-8').replace('PyStringOps.Format(template,','PyStringOps.FormatAsync(template,').replace('if (value is PyString text) { output.Append(text); return; }','if (value is PyString text) { output.Append(text); return default; }').replace('Assert.Equal(new string(\'x\', 4096), spec);','Assert.Equal(new string(\'x\', 4096), spec);\n                        return default;').replace('}, governor, null);','}, governor, null).GetAwaiter().GetResult();')
s=s.replace('PyStringOps.FormatMapAsync(template, _ => { entered.TrySetResult(); return new(release.Task); },','PyStringOps.FormatAsync(template, [], null,').replace('governor, new(0, 0, 0, 0), cancellation.Token).AsTask();','governor, new(0, 0, 0, 0), forbidPositionalFields: true, cancellationToken: cancellation.Token,\n                resolveKeyword: _ => { entered.TrySetResult(); return new(release.Task); }).AsTask();')
p.write_text(s,encoding='utf-8',newline='\n')
p=Path('tests/Lokad.Lython.Tests/PyStringOpsPrimitiveTests.cs');s=p.read_text(encoding='utf-8').replace('PyStringOps.Format(', 'PyStringOps.FormatAsync(').replace('[new BigInteger(12), PyNone.Instance], null, null, null, governor: null, span: null);','[new BigInteger(12), PyNone.Instance], null, null, null, governor: null, span: null).GetAwaiter().GetResult();');p.write_text(s,encoding='utf-8',newline='\n')
