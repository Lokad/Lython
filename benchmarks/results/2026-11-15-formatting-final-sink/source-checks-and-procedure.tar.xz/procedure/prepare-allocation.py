from pathlib import Path
import json,shutil
r=Path(__file__).parent;d=r/'allocation';d.mkdir()
s=(r.parent/'csv-final-payload-r379/allocation-driver-source.cs').read_text(encoding='utf-8').replace('var check = hostType.GetMethod("ReadOutputs", all)!;', 'var check = hostType.GetMethod("ReadOutputs", all)!;\nvar digest = fixtureType.GetMethod("Digest", all)!;')
s=s.replace('                check.Invoke(host, null);','''                var files = check.Invoke(host, null);
                var actualFiles = (string)digest.Invoke(null, [files])!;
                if (actualFiles != item.GetProperty("expectedFilesSha256").GetString())
                    throw new InvalidDataException("File golden mismatch.");''')
(d/'Program.cs').write_text(s,encoding='utf-8',newline='\n')
project=(r.parent/'word-buffer-loan-r324/allocation/Allocation.csproj').read_text(encoding='utf-8').replace('../reference/','../frozen/reference/').replace('<OutputType>','<AssemblyName>ValidatedAllocation</AssemblyName><OutputType>')
(d/'Allocation.csproj').write_text(project,encoding='utf-8',newline='\n');shutil.copyfile(r/'catalog.json',d/'catalog.json')
