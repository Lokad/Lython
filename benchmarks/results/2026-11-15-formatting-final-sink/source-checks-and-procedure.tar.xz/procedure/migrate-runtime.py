from pathlib import Path
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.StringMembers.AffixFormat.cs');s=p.read_text(encoding='utf-8');a=s.index('                    "format" => new CustomMethodCallable(');b=s.index('                    "format_map" =>',a)
s=s[:a]+'''                    "format" => new CustomMethodCallable(
                        (arguments, span, context) => FormatStringAsync(text, arguments, span, context, false).GetAwaiter().GetResult(),
                        (arguments, span, context) => FormatStringAsync(text, arguments, span, context, true)),
'''+s[b:]
needle='        private static async ValueTask<object> FormatMappingAsync('
method='''        private static async ValueTask<object> FormatStringAsync(PyString text, CallArgumentValue[] arguments,
            LythonSourceSpan span, ExecutionContext context, bool asynchronous)
        {
            try
            {
                var positionalCount = 0;
                foreach (var argument in arguments)
                    if (argument.IsPositional) positionalCount++;
                var keywordCount = arguments.Length - positionalCount;
                // Copies remain private through actual callback suspension.
                // Admit their capacity/metadata before constructing either one.
                using var argumentStorage = context.MemoryGovernor.ReserveTemporary(
                    checked(EstimateObjectArrayBytes(positionalCount) + 64L + 64L * keywordCount), span);
                context.CheckExecution(span);
                var positional = new object[positionalCount];
                var keywords = new Dictionary<string, object>(keywordCount, StringComparer.Ordinal);
                var index = 0;
                foreach (var argument in arguments)
                {
                    if (argument.IsPositional) positional[index++] = argument.Value;
                    else if (!keywords.TryAdd(argument.KeywordName, argument.Value))
                        throw CallErrors.MultipleValues(PythonCallableKind.Method, "str.format", argument.KeywordName, span);
                }
                return await PyStringOps.FormatAsync(text, positional, keywords,
                    (current, suffix) => ResolveFormatFieldSuffixAsync(current, suffix, span, context, asynchronous),
                    (output, value, conversion, spec) => AppendInterpolatedStringPartAsync(output, value, conversion,
                        spec, context, span, asynchronous), context.MemoryGovernor, span,
                    context.State.CancellationToken).ConfigureAwait(false);
            }
            catch (InvalidOperationException ex) { throw new LythonRuntimeException("ValueError", ex.Message, span); }
            catch (IndexOutOfRangeException ex) { throw new LythonRuntimeException("IndexError", ex.Message, span); }
            catch (KeyNotFoundException ex)
            {
                throw new LythonRuntimeException("KeyError", ex.Message, span, null, PyString.FromString(ex.Message, context.MemoryGovernor, span));
            }
        }

'''
assert needle in s;s=s.replace(needle,method+needle,1)
s=s.replace('(value, conversion, spec) => FormatSuspendedFieldAsync(value, conversion, spec, context, span, asynchronous)', '(output, value, conversion, spec) => AppendInterpolatedStringPartAsync(output, value, conversion, spec, context, span, asynchronous)')
p.write_text(s,encoding='utf-8',newline='\n')
# The sync suffix facade now has no caller: both public methods use the same
# current-operation async/sync resolver, without a compatibility overload.
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.StringMembers.cs');s=p.read_text(encoding='utf-8');a=s.index('        private static object ResolveFormatFieldSuffix(');b=s.index('        private static async ValueTask<object> ResolveFormatFieldSuffixAsync(',a);s=s[:a]+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
