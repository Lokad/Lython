from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile,xml.etree.ElementTree as E
repo=Path.cwd();r=Path(__file__).parent;f=r/'frozen';f.mkdir();base=r.parent/'prepared-stores-r413/frozen/candidate';images={};sources={};checks={};ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
for role in ['reference','candidate']:
 d=f/role;shutil.copytree(base,d)
 if role=='candidate':shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',d/'Lokad.Lython.dll')
 images[role]={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in d.iterdir()if p.is_file()}
assert images['reference']['Lokad.Lython.dll']=='55ba4c8a24f3ae110a937f6b9b2b11179c90720a991a8f119cba1dab035fa2b2'
assert all(images['candidate'][n]==h for n,h in images['reference'].items()if n!='Lokad.Lython.dll')
with tarfile.open(f/'sources-and-checks.tar.xz','w:xz')as t:
 paths=subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True).splitlines()+['Directory.Build.props','Directory.Packages.props','NuGet.Config','global.json','tests/Lokad.Lython.Tests/FormatStorageTests.cs','tests/Lokad.Lython.Tests/StringFormatPrimitiveTests.cs','tests/Lokad.Lython.Tests/PyStringOpsPrimitiveTests.cs','tests/Lokad.Lython.PublicApi.Tests/FormatProtocolTests.cs','tests/Lokad.Lython.PublicApi.Tests/FormatSinkTests.cs']
 for n in paths:
  p=repo/n;sources[n]=hashlib.sha256(p.read_bytes()).hexdigest();t.add(p,arcname=n)
 for suite in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:
  for p in(repo/'tests'/suite/'TestResults').glob('r416-*.trx'):
   checks[suite+'/'+p.name]=E.parse(p).find('.//t:Counters',ns).attrib;t.add(p,arcname='checks/'+suite+'/'+p.name)
 t.add(r/'clean-build.log',arcname='clean-build.log');t.add(r/'baseline-source.tar',arcname='baseline-source.tar')
identity=dict(baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),prototype=True,images=images,sources=sources,checks=checks,contracts='Single async formatter/sink callback; ordinary scalar fields append to final admitted builder; one conservative metadata scratch reservation per operation, retained/grown through callbacks. str.format now awaits real lookup/format protocols in RunAsync. Spec/name CLR metadata and observable custom/date return strings remain.',focused='10 internal/484 public each actual11/10; 6new held-success/cancellation/refusal tests and 2new descriptor/call cancellation cases. Clean nonincremental Release solution build passes. Original unsupported-async assertions preserved in initial TRX.')
(f/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n');shutil.copyfile(r/'catalog.json',f/'catalog.json');print({role:files['Lokad.Lython.dll']for role,files in images.items()},flush=True)
