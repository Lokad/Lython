set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/format-operand-transport
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab=../../agent-notes/review-20261031/retained-dispatch-profile
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --artifacts-path /tmp/lython-format-operand-release --filter '(FullyQualifiedName~Format|FullyQualifiedName~CallExpansion|FullyQualifiedName~SharedBudget|FullyQualifiedName~AdmissionRefusal|FullyQualifiedName~ClassHeaderUnpacking)&Category!=Stress' 2>&1 | tee "$lab/format-ubuntu-public.log"
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --artifacts-path /tmp/lython-format-operand-release --filter '(FullyQualifiedName~Format|FullyQualifiedName~Builtin|FullyQualifiedName~ManagedStackGuard)&Category!=Stress' 2>&1 | tee "$lab/format-ubuntu-whitebox.log"
