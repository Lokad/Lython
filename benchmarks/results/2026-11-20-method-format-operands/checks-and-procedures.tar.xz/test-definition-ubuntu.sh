set -euo pipefail
cd /mnt/d/code/Lython
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --artifacts-path "$PWD/.git/agent-notes/artifacts/definition-effects" --filter '(FullyQualifiedName~Decorat|FullyQualifiedName~Annotation|FullyQualifiedName~ClassHeaderUnpacking|FullyQualifiedName~StaticAnalysis)&Category!=Stress' 2>&1 | tee .git/agent-notes/review-20261031/retained-dispatch-profile/definition-ubuntu.log
