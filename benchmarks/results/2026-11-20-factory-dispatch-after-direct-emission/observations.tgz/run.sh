set -eu
root=/home/lokad/lython-bench-checks/factory-dispatch-after-direct-emission-b1193-20261120
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
