from pathlib import Path
import gzip
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
out = Path('benchmarks/results/2026-11-20-factory-dispatch-after-direct-emission')
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
term = read(lab/'terminal-status.json')
receipt = read(lab/'archive-receipt.json')
assert term['receipt']==receipt and term['exitCode']=='0' and term['live'] is False
assert not term['remainingWorkers'] and not term['remainingTrace']
assert all(receipt[name] for name in ('complete','quietBeforeAndAfter','allWorkersJoined','guestFixturesRemoved',
                                      'archivedAndVerifiedUnderLease','persistentTraceArchivedAndVerifiedBeforeUnmount'))
assert sha(lab/'observations.tgz')==receipt['archiveSHA256']
identity=read(lab/'identity.json')
assert identity['sourceRevision'].startswith('2dad15d55') and identity['imageSource'].startswith('2131039a4')
assert identity['catalogSHA256']==sha(lab/'catalog.json')
files=identity['imageFiles']['candidate']
assert len(files)==32 and {name:sha(lab/'candidate'/name) for name in files}==files
exact_core=Path('benchmarks/results/2026-11-20-direct-statement-emission/measured-core.dll.gz')
assert hashlib.sha256(gzip.decompress(exact_core.read_bytes())).hexdigest()==files['Lokad.Lython.dll']
verified=read(lab/'verify.json')
assert verified['state']=='Completed' and verified['catalogSha256']==identity['catalogSHA256']
rows=read(lab/'attribution.json')['rows']
catalog={case['id']:case for case in read(lab/'catalog.json')['cases']}
assert len(rows)==len(catalog)==2
for row in rows:
    run=read(lab/'retrieved/profiles'/row['label']/'record.json')
    assert run['exitCode']==0 and run['closed']['status']=='Closed' and run['warmupSeconds']>=8 and row['sampleCount']>900
    libraries={Path(lib['path']).name:lib['sha256'].lower() for lib in run['identity']['libraries']}
    assert libraries['Lokad.Lython.dll']==files['Lokad.Lython.dll']
    assert all(libraries[name]==files[name] for name in libraries.keys() & files.keys())
    case=catalog[row['case']]
    for check in ('verificationBefore','response','verificationAfter'):
        assert run[check]['actualOutputSha256']==case['expectedOutputSha256']
        assert run[check].get('actualFilesSha256')==case.get('expectedFilesSha256')

out.mkdir(exist_ok=True)
for name in ('attribution.json','archive-receipt.json','terminal-status.json','observations.tgz'):
    shutil.copyfile(lab/name,out/name)
with tarfile.open(out/'procedures.tar.xz','w:xz',preset=6) as archive:
    for name in ('identity.json','config.json','catalog.json','prepare.py','prepare-console.log','verify.json','verify.log',
                 'analyze.py','analysis.log','archive-profile.py','launch.py','launch.log','launch-console.log','retrieval.log','ops-profile.py',
                 'collect.py','run.sh','retrieve.py','remote-launch.py','observe-not-before.json'):
        archive.add(lab/name,arcname=name)
print('Verified two captures, the complete image, both goldens and the retained trace hashes.')
