from pathlib import Path
import hashlib, json, os, subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab/'comparison/quiet'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
digest = lambda text: hashlib.sha256(text.encode('utf-8')).hexdigest()
python = Path('C:/Python313/python.exe')
sdk = Path.home()/'.dotnet11'
worker = repo/'benchmarks/cpython-worker.py'
identity = read(quiet/'identity.json')
assert sha(worker)==identity['cpythonWorkerSHA256']
fixtures = {
'positional-backing-and-replacement': '''
def build(seed):
    def large(value=10000 + seed): return value
    def wide(value=1 << (seed + 126)): return value
    def alias(value=(seed,)): return value
    def literal(value=65000): return value
    def deferred(value=10000 + seed): yield value
    return large, wide, alias, literal, deferred
for f in build(3)[:4]:
    value = f()
    first = f.__defaults__
    print(value, first, first is f.__defaults__, value is first[0])
    f.__defaults__ = (None,)
    print(f(), first[0] is value)
*_, deferred = build(3)
previous = deferred()
original = deferred.__defaults__
deferred.__defaults__ = ('replacement',)
print(next(previous) is original[0], next(deferred()))
''',
'failed-and-decorated-definition': '''
order = []
keep = []
def save(value):
    order.append('default')
    return value
def fail():
    order.append('annotation')
    raise ValueError('stop')
def decorator(fn):
    keep.append(fn)
    order.append('decorator')
    raise ValueError('stop')
seed = 129
try:
    def failure(value=save(1 << seed)) -> fail(): return value
except ValueError:
    pass
try:
    @decorator
    def saved(value=save(1 << seed)): return value
except ValueError:
    pass
print(order, keep[0]() == 1 << seed, keep[0]() is keep[0].__defaults__[0])
'''
}
catalog = read(quiet/'representative.json')
catalog['cases'] = []
for name, code in fixtures.items():
    answer = subprocess.run([python,'-I','-S','-X','utf8','-'],input=code,encoding='utf-8',capture_output=True,check=True,timeout=15)
    assert not answer.stderr
    fixture = '{"size":1,"text":null}'
    catalog['cases'].append(dict(id='diagnostic.'+name,source=code,family='scripts',category='whole-script',scale='small',size=1,
        fixtureJson=fixture,expectedOutput=answer.stdout,sourceUtf8Bytes=len(code.encode('utf-8')),
        expectedOutputUtf8Bytes=len(answer.stdout.encode('utf-8')),fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,
        sourceSha256=digest(code),fixtureSha256=digest(fixture),expectedOutputSha256=digest(answer.stdout)))
manifest = lab/'boundary-catalog.json'
manifest.write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
for role, expected in identity['imageFiles'].items():
    image=lab/role
    assert {p.name:sha(p) for p in image.iterdir()}==expected
    result=lab/f'{role}-boundary-verification.json'
    subprocess.run([sdk/'dotnet.exe',image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',manifest,
        '--dotnet',sdk/'dotnet.exe','--python',python,'--python-worker',worker,'--out',result],cwd=repo,env=env,check=True,timeout=60)
    verified=read(result)
    assert verified['state']=='Completed' and verified['caseCount']==len(fixtures)
    assert verified['catalogSha256']==sha(manifest) and verified['launched']['library']['sha256']==expected['Lokad.Lython.dll']