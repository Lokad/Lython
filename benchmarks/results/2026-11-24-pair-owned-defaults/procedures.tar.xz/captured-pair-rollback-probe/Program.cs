using Lokad.Lython;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime;

foreach (var multi in new[] { false, true })
{
    var second = multi ? "    factor = seed % 5 + 1\n" : "";
    var expression = multi ? "(value + offset) * factor" : "value + offset";
    var source = "def make(seed):\n    offset = seed % 7\n" + second +
        "    def left(value):\n        return " + expression + "\n" +
        "    def alternate():\n        step = 7 // seed\n        return lambda value: value - step\n" +
        "    return left, alternate()\nfirst, other = make(0)\n";
    var module = ExecutableScript.Compile(LythonFrontend.Compile(source).Script!).EntryPoint;
    var factory = module.Constants.OfType<ExecutableCreateFunction>().DistinctBy(binding => binding.CodeObject).Single().CodeObject;
    if (!factory.HasDirectCapturedDefinitionPair) throw new Exception("Expected native captured pair.");
    var budget = new LythonMemoryBudget(1024 * 1024);
    using var owner = budget.CreateScope();
    var context = new LythonRuntime.ExecutionContext(new PureHost(),new LythonRunOptions { MemoryBudget = owner });
    LythonRuntime.ChargeClosureRetention(context, context.MemoryGovernor, null);
    var output = new LythonRuntime.ExecutableSlot[2];
    var start = budget.ReservedBytes;
    try
    {
        for (var i=0; i<2; ++i)
        {
            var before = budget.ReservedBytes;
            try { LythonRuntime.CompleteClosedCapturedPair(factory, context, 0, output); throw new Exception("Unexpected success."); }
            catch (LythonRuntimeException error) when (error.ExceptionType=="ZeroDivisionError") { }
            if (output.Any(slot => !slot.IsUnassigned)) throw new Exception("A private callable escaped.");
            Console.WriteLine($"multi={multi} before={before} after={budget.ReservedBytes} delta={budget.ReservedBytes-before}");
        }
    }
    finally { context.State.CloseResources(); }
    owner.Dispose();
    Console.WriteLine($"admitted initially={start} after scope={budget.ReservedBytes}");
}

class PureHost : ILythonHost
{
    public string Cwd => "/";
    public virtual ILythonTextOutput? StandardError => null;
    public virtual ILythonTextOutput? StandardOutput => null;
    public DateTimeOffset LocalNow => DateTimeOffset.UnixEpoch;
    public DateTimeOffset UtcNow => DateTimeOffset.UnixEpoch;
    public virtual ValueTask<bool> ExistsAsync(LythonPathRequest path, CancellationToken cancellationToken) => ValueTask.FromResult(false);
    public ValueTask<IReadOnlyList<string>> ListDirAsync(LythonPathRequest path, CancellationToken cancellationToken) => throw new NotSupportedException();
    public ValueTask MkDirAsync(LythonPathRequest path, CancellationToken cancellationToken) => throw new NotSupportedException();
    public ValueTask RemoveAsync(LythonPathRequest path, CancellationToken cancellationToken) => throw new NotSupportedException();
    public ValueTask CopyAsync(LythonPathRequest source, LythonPathRequest destination, CancellationToken cancellationToken) => throw new NotSupportedException();
    public ValueTask MoveAsync(LythonPathRequest source, LythonPathRequest destination, CancellationToken cancellationToken) => throw new NotSupportedException();
    public virtual ValueTask<LythonPathStat> StatAsync(LythonPathRequest path, CancellationToken cancellationToken) => ValueTask.FromResult(new LythonPathStat(LythonPathKind.Missing, 0, null));
}
