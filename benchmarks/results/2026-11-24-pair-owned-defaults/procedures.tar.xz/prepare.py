from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
donor=lab.with_name('inline-positional-default-20261124')
previous=donor/'comparison/quiet'
quiet=lab/'comparison/quiet'
quiet.mkdir(parents=True,exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
save=lambda p,d:write(p,json.dumps(d,ensure_ascii=False,indent=2)+'\n')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head.startswith('b37403891')
assert not subprocess.check_output(['git','diff','6b41db7b3',head,'--','src','tests'],cwd=repo)
patch=lab/'candidate.patch'
assert subprocess.check_output(['git','diff','--binary','--','src','tests'],cwd=repo)==patch.read_bytes()
assert b'ref FunctionDefaults defaults' in patch.read_bytes()
base=read(previous/'identity.json')
core='Lokad.Lython.dll'
reference=base['imageFiles']['candidate']
assert len(reference)==32 and {p.name:sha(p) for p in (donor/'candidate').iterdir()}==reference
candidate=lab/'candidate-build/bin/Lokad.Lython/release_net11.0'/core
images={'reference':reference,'candidate':reference | {core:sha(candidate)}}
assert images['candidate'][core]!=reference[core]
for role,files in images.items():
    folder=lab/role
    folder.mkdir(exist_ok=True)
    for name in files:
        shutil.copyfile(candidate if role=='candidate' and name==core else donor/'candidate'/name,folder/name)
    assert {p.name:sha(p) for p in folder.iterdir()}==files
for name in ('representative.json','jobs.json','run.sh'):
    shutil.copyfile(previous/name,quiet/name)
assert b'\r' not in (quiet/'run.sh').read_bytes()
identity=dict(sourceRevision=head,comparisonRevision='6b41db7b368532589dc0e9f20939d56a6cb5ceb6',
    sourcePatchSHA256=sha(patch),purpose='Use a single rollback owner for the two closed definition defaults',
    imageFiles=images,expectedCPythonSHA256=base['expectedCPythonSHA256'],cpythonWorkerSHA256=base['cpythonWorkerSHA256'],
    coreSHA256={role+suffix:files[core] for role,files in images.items() for suffix in ('','-control')},
    catalogs={name:{'sha256':sha(quiet/name)} for name in ('representative.json','jobs.json')})
save(quiet/'identity.json',identity)
collector=(previous/'collect.py').read_text(encoding='utf-8').replace('b1655-fixtures','b1658-fixtures').replace('targetBatchSeconds=.28','targetBatchSeconds=.52')
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
sdk=Path.home()/'.dotnet11'
worker=repo/'benchmarks/cpython-worker.py'
assert sha(worker)==identity['cpythonWorkerSHA256']
for role,files in images.items():
    output=lab/f'comparison/{role}-verify.json'
    subprocess.run([sdk/'dotnet.exe',lab/role/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'representative.json',
        '--dotnet',sdk/'dotnet.exe','--python','C:/Python313/python.exe','--python-worker',worker,'--out',output],cwd=repo,
        env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk)),check=True,timeout=75)
    checked=read(output)
    assert checked['state']=='Completed' and checked['caseCount']==5 and checked['launched']['library']['sha256']==files[core]
    assert checked['catalogSha256']==identity['catalogs']['representative.json']['sha256']
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=3) as bundle:
    for name in ('identity.json','jobs.json','representative.json','collect.py','run.sh'):
        bundle.add(quiet/name,arcname=name)
    bundle.add(candidate,arcname='candidate-core.dll')
save(quiet/'upload.json',dict(root='pair-owned-defaults-b1658-20261124',reference='inline-positional-default-b1655-20261124',
    payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
save(lab/'verified-raw-replicas.json',[])
receipt=read(previous/'terminal-status.json')['receipt']
assert receipt['complete'] and sha(previous/'observations.tar.xz')==receipt['archiveSHA256']
launcher=(lab.with_name('shared-function-definition-descriptor-20261124')/'quiet.py').read_text(encoding='utf-8')
launcher=launcher.replace('a8edbf7d71eb5e7b3536469dde376f927415170b3b76ebc1de9ad619d2a3060e',receipt['archiveSHA256'])
assert receipt['archiveSHA256'] in launcher
launcher=launcher.replace('b1647-','b1658-').replace('shared-function-definition-descriptor-20261124','pair-owned-defaults-20261124')
launcher=launcher.replace('RuntimeMaxSec=292','RuntimeMaxSec=325').replace('seconds=208','seconds=246')
compile(launcher,'quiet.py','exec')
write(lab/'quiet.py',launcher)
shutil.copyfile(donor/'allocations.py',lab/'allocations.py')
shutil.copyfile(donor/'verify-boundaries.py',lab/'verify-boundaries.py')
print('Verified all worker files and five CPython goldens on the unchanged and candidate images.')