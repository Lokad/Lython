set -eu
lab="$PWD/.git/agent-notes/review-20261031/pair-owned-defaults-20261124"
export DOTNET_ROOT="$HOME/.dotnet"
filter='FullyQualifiedName~ExecutableDefinitionPair|FullyQualifiedName~NativeDefinitionPair|FullyQualifiedName~AsyncExecutableFunction|FullyQualifiedName~FunctionDefaultMetadata|FullyQualifiedName~FunctionDefaultConstruction|FullyQualifiedName~AnnotatedHelper|FullyQualifiedName~FunctionBindingLifetime'
for target in net11.0 net10.0; do
 for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="$lab/ubuntu-$target-$suite.log"
    if "$DOTNET_ROOT/dotnet" test "tests/$suite/$suite.csproj" -c Release -f "$target" --artifacts-path "$lab/ubuntu" --filter "$filter" > "$log" 2>&1; then
        tail -3 "$log"
    else
        tail -48 "$log"
        exit 1
    fi
 done
done
