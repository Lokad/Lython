from pathlib import Path
import hashlib,json,shutil

lab=Path(__file__).resolve().parent
quiet=lab/'comparison/quiet'
output=lab/'confirmation'
output.mkdir(exist_ok=True)
read=lambda path:json.loads(path.read_text(encoding='utf-8'))
write=lambda path,text:path.write_text(text,encoding='utf-8',newline='\n')
save=lambda path,value:write(path,json.dumps(value,ensure_ascii=False,indent=2)+'\n')
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
identity=read(quiet/'identity.json')
for role,files in identity['imageFiles'].items():
    assert {p.name:sha(p) for p in (lab/role).iterdir()}==files
    checked=read(lab/f'comparison/{role}-verify.json')
    assert checked['state']=='Completed' and checked['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert checked['launched']['library']['sha256']==files['Lokad.Lython.dll']
original=read(quiet/'jobs.json')['warm']
save(output/'jobs.json',dict(warm=[original[i] for i in (0,2,3,4,5)]))
shutil.copyfile(quiet/'representative.json',output/'representative.json')
shutil.copyfile(quiet/'run.sh',output/'run.sh')
assert b'\r' not in (output/'run.sh').read_bytes()
identity['catalogs']['jobs.json']['sha256']=sha(output/'jobs.json')
identity['purpose']='Repeat defaulted-rule timings and three controls with longer batches'
save(output/'identity.json',identity)
collect=(quiet/'collect.py').read_text(encoding='utf-8').replace('b1658-fixtures','b1658-confirmation-fixtures').replace('len(jobs) == 6','len(jobs) == 5').replace('targetBatchSeconds=.52','targetBatchSeconds=.68')
compile(collect,'collect.py','exec')
write(output/'collect.py',collect)
launcher=(lab.with_name('frontend-cpython-20261124')/'external.py').read_text(encoding='utf-8').replace("lab.parent / 'shared-comprehension-facts-20261124/comparison/quiet'","lab / 'comparison/quiet'").replace("lab / 'external'","lab / 'confirmation'").replace('lython-b1643-frontend-cpython','lython-b1658-pair-owned-confirmation').replace('frontend-cpython-b1643-20261124','pair-owned-confirmation-b1658-20261124').replace('shared-comprehension-facts-b1642-20261124','pair-owned-defaults-b1658-20261124').replace('seconds=275','seconds=221').replace('RuntimeMaxSec=365','RuntimeMaxSec=295')
start=launcher.index(" (root/'candidate').mkdir()")
end=launcher.index(" os.link(original/'cpython-worker.py'",start)
launcher=launcher[:start]+''' for name, content in payload.items(): (root/name).write_text(content,encoding='utf-8')
 identity=json.loads((root/'identity.json').read_text(encoding='utf-8'))
 for role, files in identity['imageFiles'].items():
  image=root/role
  image.mkdir()
  assert len(files)==32
  for name, sha in files.items():
   item=original/role/name
   assert digest(item)==sha
   os.link(item,image/name)
'''+launcher[end:]
# Five lanes reuse immutable image files without allocating copies. The
# original receipt's unpacked result fits in 256 KiB, and the archive in
# 64 KiB. Keep an additional MiB for result growth, machine logs and journals.
launcher=launcher.replace('minimum=staged+3840*1024', 'minimum=staged+1536*1024').replace('>=3584*1024','>=1408*1024')
compile(launcher,'confirm.py','exec')
write(lab/'confirm.py',launcher)
archive=(lab/'archive.py').read_text(encoding='utf-8').replace('lab/"comparison/quiet"','lab/"confirmation"').replace('2026-11-24-pair-owned-defaults"','2026-11-24-pair-owned-defaults/confirmation"').replace('receipt["warmJobs"]==6','receipt["warmJobs"]==5').replace('timedBatches=168,lanes=6','timedBatches=140,lanes=5')
compile(archive,'archive-confirmation.py','exec')
write(lab/'archive-confirmation.py',archive)