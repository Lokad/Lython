from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
quiet=lab/'comparison/quiet'
old=lab.with_name('inline-positional-default-20261124')
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
payload=quiet/'payload.tar.gz'
assert sha(payload)==load(quiet/'upload.json')['payloadSHA256']
with tarfile.open(payload) as bundle:
    members=[m.size for m in bundle.getmembers()]
core='Lokad.Lython.dll'
prior=old/'reference'/core
copies=[]
for path,name,unit in ((old/'comparison/quiet','inline-positional-default','lython-b1655-inline-positional-default-20261124'),
                       (old/'confirmation','inline-default-confirmation','lython-b1655-inline-default-confirmation-20261124')):
    receipt=load(path/'terminal-status.json')['receipt']
    assert all(receipt[x] for x in ('complete','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
    assert sha(path/'observations.tar.xz')==receipt['archiveSHA256']
    assert sha(prior)==load(path/'identity.json')['imageFiles']['reference'][core]
    copies.append(dict(name=name+'-b1655-20261124',unit=unit,archive=receipt['archiveSHA256']))
backup=lab/'verified-b1655-reference.dll'
shutil.copyfile(prior,backup)
assert sha(backup)==sha(prior)
script=f'copies={copies!r}\ndigest={sha(backup)!r}\nsize={backup.stat().st_size}\nmembers={members!r}\ncompressed={payload.stat().st_size}\n'+'''
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with (base/'comparison-vm.lock').open('a') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    free=shutil.disk_usage(base).free
    block=os.statvfs(base).f_frsize
    required=max(compressed+1400*1024,sum((s+block-1)//block*block for s in members)+1912*1024)
    paths=[]
    if free<required:
        for copy in copies:
            root=base/copy['name']
            assert root.resolve()==root and not (root/'guest-fixtures').exists()
            status=subprocess.check_output(['systemctl','show',copy['unit']+'.service','-p','ActiveState,MainPID'],text=True)
            assert 'ActiveState=inactive' in status and 'MainPID=0' in status
            marker=json.loads((root/'archive-receipt.json').read_text())
            assert marker['complete'] and marker['allWorkersJoined'] and marker['archivedAndVerifiedUnderLease']
            assert marker['archiveSHA256']==copy['archive']==sha(root/'observations.tar.xz')
            assert json.loads((root/'identity.json').read_text())['imageFiles']['reference']['Lokad.Lython.dll']==digest
            target=root/'reference/Lokad.Lython.dll'
            info=target.lstat()
            assert stat.S_ISREG(info.st_mode) and target.resolve()==target and target.is_relative_to(root)
            assert info.st_nlink==len(copies) and info.st_size==size and sha(target)==digest
            paths.append((target,info))
        assert len({(info.st_dev,info.st_ino) for _,info in paths})==1
        assert free+paths[0][1].st_blocks*512>=required,(free,required)
        for target,_ in paths:target.unlink()
        for copy in copies: assert sha(base/copy['name']/'observations.tar.xz')==copy['archive']
    after=shutil.disk_usage(base).free
    assert after>=required
    print(json.dumps(dict(freeBefore=free,required=required,freeAfter=after,
                          verifiedDuplicateLinksRetired=[str(path.relative_to(base)) for path,_ in paths],sha256=digest)))
'''
command=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73','python3 -']
result=subprocess.run(command,input=script,encoding='utf-8',capture_output=True,timeout=30)
print(result.stdout,result.stderr,end='')
result.check_returncode()
(lab/'retired-stage-custody.json').write_text(result.stdout,encoding='utf-8',newline='\n')