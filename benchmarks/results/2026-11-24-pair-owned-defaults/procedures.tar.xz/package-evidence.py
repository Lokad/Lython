from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/'comparison/quiet'
out=repo/'benchmarks/results/2026-11-24-pair-owned-defaults'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=read(quiet/'identity.json')
assert identity['sourcePatchSHA256']==sha(lab/'candidate.patch')
assert subprocess.check_output(['git','diff','--binary',identity['sourceRevision'],'--','src'],cwd=repo)==(lab/'candidate.patch').read_bytes()
proof=subprocess.check_output(['git','diff','--binary',identity['sourceRevision'],'--','tests'],cwd=repo)
assert b'ArithmeticFailureRefundsUnpublishedPairWhileItsScopeIsAlive' in proof
(lab/'refund-regression.patch').write_bytes(proof)
outputs=[lab/'comparison/reference-verify.json',lab/'comparison/candidate-verify.json',lab/'reference-boundary-verification.json',lab/'candidate-boundary-verification.json']
for index,report in enumerate(outputs):
    receipt=read(report)
    role=('reference','candidate')[index%2]
    assert receipt['state']=='Completed' and receipt['caseCount']==(5 if index<2 else 2)
    assert receipt['launched']['library']['sha256']==identity['imageFiles'][role]['Lokad.Lython.dll']
for role,files in identity['imageFiles'].items():
    assert {p.name:sha(p) for p in (lab/role).iterdir()}==files
for platform in ('windows','ubuntu'):
    for target in ('net11.0','net10.0'):
        for suite,count in (('Lokad.Lython.Tests',60),('Lokad.Lython.PublicApi.Tests',117)):
            log=(lab/f'{platform}-{target}-{suite}.log').read_text(encoding='utf-8-sig')
            assert 'Failed:     0, Passed:' in log and f'Total:   {count:3d},' in log, (platform,target,suite)
shutil.copyfile(quiet/'identity.json',out/'identity.json')
shutil.copyfile(lab/'allocation-summary.json',out/'allocation-summary.json')
items=['candidate.patch','refund-regression.patch','freeze.py','candidate-build.log','prepare.py','prepare.log','test-ubuntu.sh',
    'verify-boundaries.py','boundary-catalog.json','allocations.py','reference-allocation-final.json','candidate-allocation-final.json',
    'verified-space.py','retired-stage-custody.json','quiet.py','archive.py','package-evidence.py',
    'comparison/quiet/collect.py','comparison/quiet/run.sh','comparison/quiet/representative.json','comparison/quiet/jobs.json',
    'comparison/quiet/launch.log','comparison/quiet/storage-custody.json','comparison/quiet/upload.json','retrieve.log','prepare-confirmation.py','confirm.py','archive-confirmation.py','confirmation/launch.log','captured-pair-rollback-probe/Probe.csproj','captured-pair-rollback-probe/Program.cs','captured-pair-rollback-probe/observations.log','windows-fixture-missing-module-owner.log','ubuntu-fixture-missing-module-owner.log']
items += [p.relative_to(lab).as_posix() for p in outputs]
items += [p.name for p in sorted(lab.glob('*net1*.log'))]
assert len(set(items))==len(items)
with tarfile.open(out/'procedures.tar.xz','w:xz') as bundle:
    for name in items: bundle.add(lab/name,arcname=name,recursive=False)
with tarfile.open(out/'procedures.tar.xz') as bundle:
    assert set(items)==set(bundle.getnames())
    for name in items: assert hashlib.sha256(bundle.extractfile(name).read()).hexdigest()==sha(lab/name)
print('Verified runtime patch, refund regression, all platform tests and image identities in the archive.')