from pathlib import Path

lab = Path(__file__).resolve().parent
prior = lab.parent / 'native-format-selectors-r615'
read=lambda p:p.read_text(encoding='utf-8-sig')
write=lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
source=read(prior/'stage-quiet.py')
source=source.replace('prepared-definition-text-r611','native-format-selectors-r615')
source=source.replace('quiet.mkdir()','quiet.mkdir(exist_ok=True)')
source=source.replace('for role in ("reference","candidate"):', 'for role in ("candidate",):')
source=source.replace('image.mkdir()','image.mkdir(exist_ok=True)')
source=source.replace('"reference/" + core, "candidate/" + core', '"candidate/" + core')
source=source.replace('R615 native dictionary selectors in ordered format rendering',
    'R616 one nested binding-header walk and borrowed prepared locals')
source=source.replace('native-format-selectors-b1045','prepared-binding-diagnostics-b1048').replace('lython-b1045','lython-b1048')
source=source.replace('Native format selectors source pair','Prepared binding diagnostics source pair').replace('Prepared definition text source pair','Native format selectors source pair')
start=source.index('        jobs=')
end=source.index('\n',start)
source=source[:start]+'''        cases = ['scripts.config-manifest.small','scripts.config-generated-guards.medium','scripts.config-edit.small']
        jobs = [(name, lane) for name in cases for lane in ('compile','compile-run')]
        jobs.append(('scripts.report-render.format-selectors.large', 'warm'))
        source = source.replace('Native format selectors source pair', 'Prepared binding diagnostics source pair')'''+source[end:]
source=source.replace('254 * 1024 * 1024','242 * 1024 * 1024')
source=source.replace('"lython-b1048-fixtures", launcher)', '"lython-b1048-fixtures", launcher)\nlauncher = launcher.replace("254*1024*1024", "242*1024*1024")')
source=source.replace('six-case, seven-job','four-case, seven-job')
compile(source,'r616-stage','exec')
write(lab/'stage-quiet.py',source)
for file in ('launch-quiet.py','summarize-quiet.py'):
    text=read(prior/file).replace('Native format selectors source pair','Prepared binding diagnostics source pair')
    text=text.replace('B1045','B1048')
    write(lab/file,text)
