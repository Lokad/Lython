#!/usr/bin/env bash
set -euo pipefail
export DOTNET_ROOT="$HOME/.dotnet"
cd /mnt/d/code/Lython/.git/agent-worktrees/prepared-binding-diagnostics-r616
filter='FullyQualifiedName~StaticErrorDiagnostics|FullyQualifiedName~SharedCompilerFact|FullyQualifiedName~UnboundLocal|FullyQualifiedName~Nonlocal|FullyQualifiedName~Lambda|FullyQualifiedName~ImplicitClassCell|FullyQualifiedName~ScopeDirective|FullyQualifiedName~CompileCancellation'
"$DOTNET_ROOT/dotnet" test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --artifacts-path artifacts/r616-wsl --filter "$filter"
"$DOTNET_ROOT/dotnet" test tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj -c Release -f net10.0 --artifacts-path artifacts/r616-wsl --filter "$filter"
