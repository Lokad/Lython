from pathlib import Path
import gzip, hashlib, json, shutil, subprocess, tarfile

lab=Path(__file__).parent
run=lab/'quiet'
out=Path('benchmarks/results/2026-11-19-prepared-binding-diagnostics')
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda data:hashlib.sha256(data).hexdigest()
identity=load(lab/'frozen-identity.json')
proof=load(run/'archive-recovery.json')
prior=next(run.glob('observation-*.json'))
assert proof['archiveSHA256']==sha((run/'observations.tgz').read_bytes())
assert load(prior)['exitCode']=='1' and proof['archiveOnlyFailure']
assert proof['complete'] and proof['allWorkersJoined'] and proof['guestFixturesRemoved']
for role, image in identity['images'].items():
 assert len(image)==32 and image=={name:sha((lab/'frozen'/role/name).read_bytes()) for name in image}
retained='c8e749318'
subprocess.run(['git','diff','--exit-code',identity['candidateCommit'],retained,'--','src','tests'],check=True)
summary=load(lab/'quiet-summary.json')
summary['initialStagingReceipt']=summary.pop('archivalOnlyRecovery')
summary.update(collection='B1048',archivalOnlyRecovery=proof,retained=retained,retentionDecisionPending=False)
summary.update(sourcePair={key:identity[key] for key in ['referenceCommit','candidateCommit']})
out.mkdir(exist_ok=False)
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(run/'observations.tgz',out/'observations.tgz')
shutil.copyfile(run/'archive-recovery.json',out/'archive-recovery.json')
shutil.copyfile(prior,out/'original-terminal-status.json')
(out/'measured-core.dll.gz').write_bytes(gzip.compress((lab/'frozen/candidate/Lokad.Lython.dll').read_bytes(),mtime=0))
with tarfile.open(out/'checks-and-procedures.tar.xz','w:xz',preset=6) as bundle:
 for name in ['measured-source.patch','candidate-core-build.log','freeze-and-verify.py','frozen-identity.json','catalog.json',
    'reference-verify.json','candidate-verify.json','old-diagnostic.log','public-win-net11.log','white-win-net11.log',
    'focused-wsl-net10.log','focused-wsl.sh','stage-quiet.py','prepare-stage.py','launch-quiet.py','canonical-space.py',
    'quiet-space.json','preflight.json','recover-archive.py','summarize-quiet.py','archive-r616.py',
    'quiet/config.json','quiet/identity.json','quiet/launch.log','quiet/retrieve.log','quiet/observe-not-before.json']:
  bundle.add(lab/name,arcname=name)
print('Full source pair and recovered archive verified. Elapsed',summary['elapsedSeconds'])
