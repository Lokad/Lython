from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
root = Path.cwd()
donor = lab.parent / 'native-format-selectors-r615'
profile = lab.parent / 'current-compile-attribution-r588'
trial = root / '.git/agent-worktrees/prepared-binding-diagnostics-r616'
sdk = Path.home() / '.dotnet11'
dotnet = sdk / 'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk),
           PATH=str(sdk)+os.pathsep+os.environ['PATH'])
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
write = lambda p,d: p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
git = lambda *args: subprocess.check_output(['git',*args])
ref = git('rev-parse','bed567750').decode().strip()
can = git('-C',str(trial),'rev-parse','HEAD').decode().strip()
assert can.startswith('d6adfc554') and not git('-C',str(trial),'status','--porcelain')
manifest = load(donor/'frozen-identity.json')
assert not git('diff','--name-only',manifest['candidateCommit'],ref,'--','src')
assert not git('diff','--name-only',ref,can,'--','benchmarks','src/Lokad.Lython.Utf8Regex')
(lab/'measured-source.patch').write_bytes(git('diff','--binary',ref,can,'--','src','tests'))
plan = load(profile/'catalog.json')
config = load(lab.parent/'text-cache-storage-r173/catalog.json')
plan['cases'] += [c for c in config['cases'] if c['id']=='scripts.config-edit.small']
assert [c['id'] for c in plan['cases']] == ['scripts.config-manifest.small',
    'scripts.config-generated-guards.medium','scripts.config-edit.small']
selector = load(donor/'catalog.json')
plan['cases'] += [c for c in selector['cases'] if c['id']=='scripts.report-render.format-selectors.large']
assert len(plan['cases'])==4
catalog=lab/'catalog.json'
write(catalog,plan)
parent=donor/'frozen/candidate'
base=manifest['images']['candidate']
core='Lokad.Lython.dll'
assert len(base)==32 and {name:sha(parent/name) for name in base}==base
images={}
for role in ('reference','candidate'):
    seed=base.copy()
    image=lab/'frozen'/role
    image.mkdir(parents=True,exist_ok=True)
    for name in base:
        origin=parent/name
        if name==core and role=='candidate':
            origin=trial/'src/Lokad.Lython/bin/Release/net11.0'/name
            seed[name]=sha(origin)
        if not (image/name).exists():
            shutil.copyfile(origin,image/name)
    assert {name:sha(image/name) for name in base}==seed
    with (lab/(role+'-verify.log')).open('wb') as log:
        subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',catalog,
            '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',root/'benchmarks/cpython-worker.py',
            '--out',lab/(role+'-verify.json')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
    verified=load(lab/(role+'-verify.json'))
    assert verified['state']=='Completed' and verified['catalogSha256']==sha(catalog)
    assert {name:sha(image/name) for name in base}==seed
    images[role]=seed
assert images['reference'][core]!=images['candidate'][core]
write(lab/'frozen-identity.json',dict(referenceCommit=ref,candidateCommit=can,casesSHA256=sha(catalog),images=images))
print('Verified both complete 32-file images against the four exact CPython cases.')
