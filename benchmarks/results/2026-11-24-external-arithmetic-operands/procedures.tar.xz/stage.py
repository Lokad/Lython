from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.with_name('dictionary-loop-entry-20261124')
comparison = lab/'comparison'
quiet = comparison/'quiet'
core = 'Lokad.Lython.dll'
reference = 'closed-scalar-branches-b1572-20261124'
root = 'external-arithmetic-operands-b1574-20261124'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(path):
    return sha(path.read_bytes())


def write(path, value):
    path.write_text(value,encoding='utf-8',newline='\n')


def save(path, value):
    write(path,json.dumps(value,indent=2)+'\n')


replicas=[]
for name,remote in [
    ('closure-scalar-operands','closure-scalar-operands-b1571-20261124'),
    ('dictionary-loop-entry','dictionary-loop-entry-b1573-20261124'),
]:
    archive='benchmarks/results/2026-11-24-'+name+'/'
    def tracked(file):
        return subprocess.check_output(['git','show','origin/master:'+archive+file],cwd=repo)
    receipt=json.loads(tracked('terminal-status.json'))['receipt']
    assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
    assert sha(tracked('observations.tar.xz'))==receipt['archiveSHA256']
    binary=sha(gzip.decompress(tracked('candidate-core.dll.gz')))
    assert json.loads(tracked('identity.json'))['imageFiles']['candidate'][core]==binary
    replicas.append(dict(path=remote+'/candidate/'+core,sha256=binary,
        observationSHA256=receipt['archiveSHA256'],trackedArchive=archive))
save(lab/'verified-replicas.json',replicas)

original = donor/'comparison/quiet'
collector = (original/'collect.py').read_text(encoding='utf-8').replace('b1573-', 'b1574-')
assert collector.count("'closed-scalar-branches-b1572-20261124'/'candidate'")==1
collector = collector.replace("'closed-scalar-branches-b1572-20261124'/'candidate'",repr(reference)+"/'candidate'")
assert collector.count(reference)==1
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
shutil.copyfile(original/'run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
payload = quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz') as bundle:
    for name in ('identity.json','representative.json','jobs.json'):
        bundle.add(comparison/name,arcname=name)
    for name in ('collect.py','run.sh'):
        bundle.add(quiet/name,arcname=name)
    bundle.add(lab/'candidate'/core,arcname='candidate-core.dll')
save(quiet/'upload.json',dict(root=root,reference=reference,payloadSHA256=digest(payload),payloadBytes=payload.stat().st_size))
launch = (donor/'quiet.py').read_text(encoding='utf-8').replace('b1573-dictionary-loop-entry','b1574-external-arithmetic-operands').replace('b1573-','b1574-')
import ast
remote_stage, = (n.value for n in ast.walk(ast.parse(launch))
    if isinstance(n, ast.Constant) and isinstance(n.value,str) and n.value.startswith('digest=lambda path:'))
compile(remote_stage,'remote-stage','exec')
compile(launch,'quiet.py','exec')
write(lab/'quiet.py',launch)
shutil.copyfile(donor/'summarize.py',lab/'summarize.py')
