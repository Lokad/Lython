; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 7 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 56
       xor      eax, eax
       mov      qword ptr [rsp+0x30], rax
       mov      qword ptr [rsp+0x28], rax
       mov      rbx, rcx
       mov      esi, r8d
       mov      edi, r9d
 
G_M000_IG02:                ;; offset=0x001D
       test     esi, esi
       jl       G_M000_IG09
 
G_M000_IG03:                ;; offset=0x0025
       cmp      esi, dword ptr [rdx+0x08]
       jae      G_M000_IG16
       mov      ecx, esi
       shl      rcx, 4
       add      rcx, bword ptr [rdx]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rcx, rax
       cmp      esi, dword ptr [rbx+0xD8]
       jge      SHORT G_M000_IG07
       test     rcx, rcx
       je       SHORT G_M000_IG06
 
G_M000_IG04:                ;; offset=0x004D
       mov      rax, 0x7FFA028166B0
       cmp      qword ptr [rcx], rax
       jne      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x005C
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      rcx, rax
 
G_M000_IG06:                ;; offset=0x0065
       test     rcx, rcx
       je       SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x006A
       mov      rdx, rcx
       mov      rcx, 0x7FFA028177A8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       jmp      G_M000_IG12
 
G_M000_IG08:                ;; offset=0x0082
       mov      rcx, rbx
       mov      edx, edi
       mov      r8d, dword ptr [rsp+0x80]
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      edx, esi
       mov      rcx, rbx
       mov      r9, gword ptr [rsp+0x88]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       jmp      G_M000_IG12
 
G_M000_IG09:                ;; offset=0x00B0
       not      esi
       mov      rbp, gword ptr [rbx+0x30]
       cmp      dword ptr [rbp+0x08], esi
       jg       G_M000_IG11
       mov      rcx, rbx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CaptureOperandBase():int:this]
       mov      ebp, esi
       sub      ebp, eax
       jns      SHORT G_M000_IG10
       mov      rdx, gword ptr [rbx+0x38]
       mov      r9, gword ptr [rbx+0x30]
       mov      ecx, esi
       sub      ecx, dword ptr [r9+0x08]
       cmp      ecx, dword ptr [rdx+0x08]
       jae      G_M000_IG16
       mov      rbp, gword ptr [rdx+8*rcx+0x10]
       mov      edx, esi
       sub      edx, dword ptr [r9+0x08]
       lea      r9, [rsp+0x30]
       mov      rcx, rbx
       mov      r8, gword ptr [rsp+0x88]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG15
       mov      rax, gword ptr [rsp+0x30]
       jmp      SHORT G_M000_IG12
 
G_M000_IG10:                ;; offset=0x0115
       lea      rcx, [rsp+0x90]
       lea      r8, [rsp+0x28]
       mov      edx, ebp
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures:TryRead(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG14
       cmp      gword ptr [rsp+0x28], 0
       je       SHORT G_M000_IG14
       mov      rax, gword ptr [rsp+0x28]
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x013D
       cmp      esi, dword ptr [rbp+0x08]
       jae      G_M000_IG16
       mov      ecx, esi
       mov      rcx, gword ptr [rbp+8*rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
 
G_M000_IG12:                ;; offset=0x0153
       nop      
 
G_M000_IG13:                ;; offset=0x0154
       add      rsp, 56
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       ret      
 
G_M000_IG14:                ;; offset=0x015D
       mov      rcx, gword ptr [rbx+0x80]
       mov      edx, ebp
       mov      r11, 0x7FFA02161FB0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rsi, rax
       mov      rcx, rbx
       mov      edx, edi
       mov      r8d, dword ptr [rsp+0x80]
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.RuntimeErrors:FreeVariableNotAssociated(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG15:                ;; offset=0x019E
       mov      rcx, rbx
       mov      edx, edi
       mov      r8d, dword ptr [rsp+0x80]
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.RuntimeErrors:NameNotDefined(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG16:                ;; offset=0x01C6
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 460

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:TryEvaluateIntegerInstruction(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):bool (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; partially interruptible
; No PGO data
; 1 inlinees with PGO data; 27 single block inlinees; 10 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 200
       lea      rbp, [rsp+0x100]
       xor      eax, eax
       mov      qword ptr [rbp-0xA8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xA0], ymm4
       vmovdqu  ymmword ptr [rbp-0x80], ymm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       mov      qword ptr [rbp-0x40], rax
       mov      rbx, rcx
       mov      esi, r8d
       mov      rdi, r9
       mov      r13, bword ptr [rbp+0x30]
       mov      r14, bword ptr [rbp+0x38]
       mov      r15, gword ptr [rbp+0x40]
 
G_M000_IG02:                ;; offset=0x0053
       mov      r12, bword ptr [rdx]
       mov      eax, dword ptr [rdx+0x08]
       mov      dword ptr [rbp-0xAC], eax
       mov      dword ptr [r13], esi
       xor      ecx, ecx
       mov      qword ptr [r14], rcx
       mov      qword ptr [r14+0x08], rcx
       mov      rcx, gword ptr [rbx+0x98]
       cmp      esi, dword ptr [rcx+0x08]
       jae      G_M000_IG46
       mov      edx, esi
       shl      rdx, 5
       lea      rdx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0xB8], rdx
       mov      ecx, dword ptr [rdx+0x1C]
       cmp      ecx, 46
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0096
       cmp      ecx, 47
       jne      G_M000_IG34
 
G_M000_IG04:                ;; offset=0x009F
       mov      r8d, dword ptr [rdx+0x10]
       mov      gword ptr [rbp-0x78], r15
       test     r8d, r8d
       jge      G_M000_IG14
       not      r8d
       mov      dword ptr [rbp-0x64], r8d
       mov      r10, gword ptr [rbx+0x30]
       cmp      dword ptr [r10+0x08], r8d
       jg       G_M000_IG13
       mov      rcx, rbx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CaptureOperandBase():int:this]
       mov      edx, dword ptr [rbp-0x64]
       mov      r10d, edx
       sub      r10d, eax
       mov      eax, r10d
       mov      dword ptr [rbp-0x68], eax
       test     eax, eax
       jge      SHORT G_M000_IG05
       mov      r9, gword ptr [rbx+0x30]
       sub      edx, dword ptr [r9+0x08]
       lea      r9, [rbp-0x70]
       mov      rcx, rbx
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       lea      rdx, [rbp-0x40]
       mov      rcx, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      G_M000_IG15
 
G_M000_IG05:                ;; offset=0x010C
       lea      rcx, [rbp-0x78]
       mov      edx, eax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures:GetCell(int):Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:this]
       test     rax, rax
       jne      SHORT G_M000_IG11
       cmp      dword ptr [rbp-0x68], 0
       jne      SHORT G_M000_IG08
       mov      rdx, gword ptr [rbp-0x78]
       test     rdx, rdx
       je       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x012C
       mov      rcx, 0x7FFA02844510
       xor      rax, rax
       cmp      qword ptr [rdx], rcx
       cmovne   rdx, rax
 
G_M000_IG07:                ;; offset=0x013F
       test     rdx, rdx
       je       SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x0144
       xor      edx, edx
       mov      qword ptr [rbp-0x40], rdx
 
G_M000_IG09:                ;; offset=0x014A
       xor      eax, eax
       jmp      SHORT G_M000_IG12
 
G_M000_IG10:                ;; offset=0x014E
       lea      rdx, [rbp-0x40]
       mov      rcx, gword ptr [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x015E
       lea      rdx, [rbp-0x40]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:TryReadInteger(byref):bool:this]
 
G_M000_IG12:                ;; offset=0x016B
       jmp      SHORT G_M000_IG15
 
G_M000_IG13:                ;; offset=0x016D
       mov      r8d, dword ptr [rbp-0x64]
       cmp      r8d, dword ptr [r10+0x08]
       jae      G_M000_IG46
       mov      ecx, r8d
       mov      rcx, gword ptr [r10+8*rcx+0x10]
       lea      rdx, [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x018F
       cmp      r8d, dword ptr [rbp-0xAC]
       jae      G_M000_IG46
       mov      ecx, r8d
       shl      rcx, 4
       add      rcx, r12
       lea      rdx, [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
 
G_M000_IG15:                ;; offset=0x01B0
       xor      rcx, rcx
       mov      gword ptr [rbp-0x70], rcx
       test     eax, eax
       je       G_M000_IG34
       mov      rax, bword ptr [rbp-0xB8]
       mov      edx, dword ptr [rax+0x0C]
       mov      gword ptr [rbp-0x90], r15
       test     edx, edx
       jge      G_M000_IG25
       not      edx
       mov      dword ptr [rbp-0x7C], edx
       mov      r8, gword ptr [rbx+0x30]
       cmp      dword ptr [r8+0x08], edx
       jg       G_M000_IG24
       mov      rcx, rbx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CaptureOperandBase():int:this]
       mov      edx, dword ptr [rbp-0x7C]
       mov      r10d, edx
       sub      r10d, eax
       mov      eax, r10d
       mov      dword ptr [rbp-0x80], eax
       test     eax, eax
       jge      SHORT G_M000_IG16
       mov      r9, gword ptr [rbx+0x30]
       sub      edx, dword ptr [r9+0x08]
       lea      r9, [rbp-0x88]
       mov      rcx, rbx
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       lea      rdx, [rbp-0x48]
       mov      rcx, gword ptr [rbp-0x88]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      G_M000_IG26
 
G_M000_IG16:                ;; offset=0x0237
       lea      rcx, [rbp-0x90]
       mov      edx, eax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures:GetCell(int):Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:this]
       test     rax, rax
       jne      SHORT G_M000_IG22
       cmp      dword ptr [rbp-0x80], 0
       jne      SHORT G_M000_IG19
       mov      rdx, gword ptr [rbp-0x90]
       test     rdx, rdx
       je       SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x025D
       mov      rcx, 0x7FFA02844510
       xor      rax, rax
       cmp      qword ptr [rdx], rcx
       cmovne   rdx, rax
 
G_M000_IG18:                ;; offset=0x0270
       test     rdx, rdx
       je       SHORT G_M000_IG21
 
G_M000_IG19:                ;; offset=0x0275
       xor      edx, edx
       mov      qword ptr [rbp-0x48], rdx
 
G_M000_IG20:                ;; offset=0x027B
       xor      eax, eax
       jmp      SHORT G_M000_IG23
 
G_M000_IG21:                ;; offset=0x027F
       lea      rdx, [rbp-0x48]
       mov      rcx, gword ptr [rbp-0x90]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG23
 
G_M000_IG22:                ;; offset=0x0292
       lea      rdx, [rbp-0x48]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:TryReadInteger(byref):bool:this]
 
G_M000_IG23:                ;; offset=0x029F
       jmp      SHORT G_M000_IG26
 
G_M000_IG24:                ;; offset=0x02A1
       mov      edx, dword ptr [rbp-0x7C]
       cmp      edx, dword ptr [r8+0x08]
       jae      G_M000_IG46
       mov      ecx, edx
       mov      rcx, gword ptr [r8+8*rcx+0x10]
       lea      rdx, [rbp-0x48]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x02C1
       cmp      edx, dword ptr [rbp-0xAC]
       jae      G_M000_IG46
       mov      ecx, edx
       shl      rcx, 4
       add      rcx, r12
       lea      rdx, [rbp-0x48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
 
G_M000_IG26:                ;; offset=0x02E0
       xor      rdx, rdx
       mov      gword ptr [rbp-0x88], rdx
       test     eax, eax
       je       G_M000_IG34
       mov      rax, bword ptr [rbp-0xB8]
       cmp      dword ptr [rax+0x1C], 46
       jne      G_M000_IG29
       mov      edx, dword ptr [rax+0x08]
       mov      ecx, edx
       and      ecx, 0x7FFFFFFF
       add      ecx, -15
       cmp      ecx, 5
       jbe      G_M000_IG37
       test     edx, 0xFFFFFFFF80000000
       jne      SHORT G_M000_IG28
 
G_M000_IG27:                ;; offset=0x0321
       mov      rax, bword ptr [rbp-0xB8]
       jmp      SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x032A
       mov      r9, qword ptr [rbp-0x40]
       mov      rdx, qword ptr [rbp-0x48]
       mov      gword ptr [rbp-0xA8], r15
       mov      bword ptr [rbp-0xA0], r12
       mov      r15d, dword ptr [rbp-0xAC]
       mov      dword ptr [rbp-0x98], r15d
       mov      qword ptr [rsp+0x20], rdx
       mov      gword ptr [rsp+0x28], rdi
       lea      rdx, [rbp-0x58]
       mov      qword ptr [rsp+0x30], rdx
       lea      rdx, [rbp-0x60]
       mov      qword ptr [rsp+0x38], rdx
       lea      rdx, [rbp-0xA8]
       mov      rcx, rbx
       mov      r8d, esi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryIntegerChain[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,int,long,long,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,byref):bool]
       test     eax, eax
       mov      rax, bword ptr [rbp-0xB8]
       jne      G_M000_IG36
 
G_M000_IG29:                ;; offset=0x038C
       mov      ecx, dword ptr [rax+0x1C]
       cmp      ecx, 47
       je       SHORT G_M000_IG32
       cmp      ecx, 51
       jne      SHORT G_M000_IG30
       mov      ecx, dword ptr [rax+0x14]
       jmp      SHORT G_M000_IG31
 
G_M000_IG30:                ;; offset=0x039E
       mov      ecx, dword ptr [rax+0x08]
       and      ecx, 0x7FFFFFFF
 
G_M000_IG31:                ;; offset=0x03A7
       jmp      SHORT G_M000_IG33
 
G_M000_IG32:                ;; offset=0x03A9
       cmp      dword ptr [rax+0x08], 3
       je       SHORT G_M000_IG34
       mov      ecx, dword ptr [rax+0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime:AugmentedBinaryOperator(int):int]
       mov      ecx, eax
 
G_M000_IG33:                ;; offset=0x03BA
       lea      r9, [rbp-0x50]
       mov      rdx, qword ptr [rbp-0x40]
       mov      r8, qword ptr [rbp-0x48]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineBinary(int,long,long,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG34
       mov      r13, qword ptr [rbp-0x50]
       mov      rcx, 0x23A4C001CF0
       mov      rdx, gword ptr [rcx]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      qword ptr [r14+0x08], r13
       jmp      G_M000_IG43
 
G_M000_IG34:                ;; offset=0x03F2
       xor      eax, eax
 
G_M000_IG35:                ;; offset=0x03F4
       add      rsp, 200
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG36:                ;; offset=0x0408
       mov      ecx, dword ptr [rbp-0x58]
       mov      dword ptr [r13], ecx
       mov      rdi, qword ptr [rbp-0x60]
       mov      rcx, 0x23A4C001CF0
       mov      rdx, gword ptr [rcx]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      qword ptr [r14+0x08], rdi
       jmp      G_M000_IG43
 
G_M000_IG37:                ;; offset=0x0431
       mov      rax, bword ptr [rbp-0xB8]
       mov      rbx, gword ptr [rax]
       mov      rsi, gword ptr [rdi+0xA0]
       cmp      byte  ptr [rsi], sil
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG38
       mov      rcx, rsi
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG38:                ;; offset=0x045E
       mov      rbx, bword ptr [rbp-0xB8]
       cmp      dword ptr [rbx+0x1C], 51
       jne      SHORT G_M000_IG39
       mov      ecx, dword ptr [rbx+0x14]
       jmp      SHORT G_M000_IG40
 
G_M000_IG39:                ;; offset=0x0470
       mov      ecx, dword ptr [rbx+0x08]
       and      ecx, 0x7FFFFFFF
 
G_M000_IG40:                ;; offset=0x0479
       mov      rdx, qword ptr [rbp-0x48]
       cmp      qword ptr [rbp-0x40], rdx
       jge      SHORT G_M000_IG45
 
G_M000_IG41:                ;; offset=0x0483
       mov      edx, -1
 
G_M000_IG42:                ;; offset=0x0488
       call     [Lokad.Lython.Runtime.LythonRuntime:CompareOrderedResult(int,int):bool]
       mov      rcx, 0x23A4C0013C0
       mov      rdx, 0x23A4C0013C8
       test     eax, eax
       mov      rdx, gword ptr [rdx]
       cmovne   rdx, gword ptr [rcx]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      eax, eax
       mov      qword ptr [r14+0x08], rax
 
G_M000_IG43:                ;; offset=0x04B9
       mov      eax, 1
 
G_M000_IG44:                ;; offset=0x04BE
       add      rsp, 200
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG45:                ;; offset=0x04D2
       cmp      qword ptr [rbp-0x40], rdx
       setg     dl
       movzx    rdx, dl
       jmp      SHORT G_M000_IG42
 
G_M000_IG46:                ;; offset=0x04DE
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1252

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:TryEvaluateBuiltinArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):bool (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 35 single block inlinees; 5 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 120
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x40], ymm4
       vmovdqa  xmmword ptr [rsp+0x60], xmm4
       xor      eax, eax
       mov      qword ptr [rsp+0x70], rax
       mov      rbp, rcx
       mov      rbx, rdx
       mov      r14d, r8d
       mov      rsi, r9
       mov      rdi, bword ptr [rsp+0xE0]
       mov      r15, gword ptr [rsp+0xE8]
 
G_M000_IG02:                ;; offset=0x0043
       xor      edx, edx
       mov      qword ptr [rdi], rdx
       mov      qword ptr [rdi+0x08], rdx
       mov      rdx, gword ptr [rbp+0x98]
       cmp      r14d, dword ptr [rdx+0x08]
       jae      G_M000_IG50
       mov      r8d, r14d
       shl      r8, 5
       lea      r13, bword ptr [rdx+r8+0x10]
       cmp      dword ptr [r13+0x1C], 47
       sete     r12b
       movzx    r12, r12b
       test     r12d, r12d
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x007B
       cmp      dword ptr [r13+0x08], 3
       je       G_M000_IG24
 
G_M000_IG04:                ;; offset=0x0086
       mov      rdx, bword ptr [rbx]
       mov      r8d, dword ptr [rbx+0x08]
       mov      bword ptr [rsp+0x50], rdx
       mov      dword ptr [rsp+0x58], r8d
       lea      rdx, [rsp+0x70]
       mov      qword ptr [rsp+0x20], rdx
       mov      gword ptr [rsp+0x28], r15
       lea      rdx, [rsp+0x50]
       mov      r8d, dword ptr [r13+0x10]
       mov      rcx, rbp
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryReadDoubleOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):bool]
       test     eax, eax
       je       G_M000_IG13
       cmp      dword ptr [r13+0x1C], 48
       je       G_M000_IG12
       mov      rdx, bword ptr [rbx]
       mov      r8d, dword ptr [rbx+0x08]
       mov      bword ptr [rsp+0x50], rdx
       mov      dword ptr [rsp+0x58], r8d
       lea      rdx, [rsp+0x60]
       mov      qword ptr [rsp+0x20], rdx
       mov      gword ptr [rsp+0x28], r15
       lea      rdx, [rsp+0x50]
       mov      r8d, dword ptr [r13+0x0C]
       mov      rcx, rbp
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryReadDoubleOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):bool]
       test     eax, eax
       je       G_M000_IG13
       test     r12d, r12d
       je       SHORT G_M000_IG05
       mov      ecx, dword ptr [r13+0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime:AugmentedBinaryOperator(int):int]
       jmp      SHORT G_M000_IG07
 
G_M000_IG05:                ;; offset=0x011C
       cmp      dword ptr [r13+0x1C], 51
       jne      SHORT G_M000_IG06
       mov      eax, dword ptr [r13+0x14]
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x0129
       mov      eax, dword ptr [r13+0x08]
       and      eax, 0x7FFFFFFF
 
G_M000_IG07:                ;; offset=0x0132
       add      eax, -2
       cmp      eax, 2
       ja       G_M000_IG13
 
G_M000_IG08:                ;; offset=0x013E
       mov      ecx, eax
       lea      rdx, [reloc @RWD00]
       mov      edx, dword ptr [rdx+4*rcx]
       lea      rax, G_M000_IG02
       add      rdx, rax
       jmp      rdx
 
G_M000_IG09:                ;; offset=0x0156
       vmovsd   xmm0, qword ptr [rsp+0x70]
       vmulsd   xmm0, xmm0, qword ptr [rsp+0x60]
       mov      rcx, 0x23A4C001CF8
       mov      rdx, gword ptr [rcx]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       vmovq    rcx, xmm0
       mov      qword ptr [rdi+0x08], rcx
       jmp      G_M000_IG48
 
G_M000_IG10:                ;; offset=0x0185
       vmovsd   xmm0, qword ptr [rsp+0x70]
       vsubsd   xmm0, xmm0, qword ptr [rsp+0x60]
       mov      rcx, 0x23A4C001CF8
       mov      rdx, gword ptr [rcx]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       vmovq    rcx, xmm0
       mov      qword ptr [rdi+0x08], rcx
       jmp      G_M000_IG48
 
G_M000_IG11:                ;; offset=0x01B4
       vmovsd   xmm0, qword ptr [rsp+0x70]
       vaddsd   xmm0, xmm0, qword ptr [rsp+0x60]
       mov      rcx, 0x23A4C001CF8
       mov      rdx, gword ptr [rcx]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       vmovq    rdx, xmm0
       mov      qword ptr [rdi+0x08], rdx
       jmp      G_M000_IG48
 
G_M000_IG12:                ;; offset=0x01E3
       cmp      dword ptr [r13+0x08], 2
       je       G_M000_IG47
 
G_M000_IG13:                ;; offset=0x01EE
       vmovdqu  xmm0, xmmword ptr [rbx]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG14:                ;; offset=0x01F8
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      gword ptr [rsp+0x28], rsi
       mov      gword ptr [rsp+0x30], r15
       lea      rdx, [rsp+0x40]
       mov      r8d, dword ptr [r13+0x10]
       mov      rcx, rbp
       mov      r9d, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      gword ptr [rsp+0x38], rax
       cmp      dword ptr [r13+0x1C], 48
       je       G_M000_IG42
       mov      dword ptr [rsp+0x20], 1
       mov      gword ptr [rsp+0x28], rsi
       mov      gword ptr [rsp+0x30], r15
       mov      r8d, dword ptr [r13+0x0C]
       mov      rcx, rbp
       mov      rdx, rbx
       mov      r9d, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      rbx, rax
       test     r12d, r12d
       je       SHORT G_M000_IG15
       mov      ecx, dword ptr [r13+0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime:AugmentedBinaryOperator(int):int]
       jmp      SHORT G_M000_IG19
 
G_M000_IG15:                ;; offset=0x0266
       cmp      dword ptr [r13+0x1C], 51
       jne      SHORT G_M000_IG16
       mov      ecx, dword ptr [r13+0x14]
       jmp      SHORT G_M000_IG17
 
G_M000_IG16:                ;; offset=0x0273
       mov      ecx, dword ptr [r13+0x08]
       and      ecx, 0x7FFFFFFF
 
G_M000_IG17:                ;; offset=0x027D
       mov      rdx, gword ptr [r13]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x68]
       mov      qword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rsp+0x38]
       mov      r8, rbx
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       jne      G_M000_IG41
       cmp      dword ptr [r13+0x1C], 51
       jne      SHORT G_M000_IG18
       mov      eax, dword ptr [r13+0x14]
       jmp      SHORT G_M000_IG19
 
G_M000_IG18:                ;; offset=0x02B6
       mov      eax, dword ptr [r13+0x08]
       and      eax, 0x7FFFFFFF
 
G_M000_IG19:                ;; offset=0x02BF
       mov      rbp, gword ptr [rsp+0x38]
       test     rbp, rbp
       je       SHORT G_M000_IG26
 
G_M000_IG20:                ;; offset=0x02C9
       mov      r14, qword ptr [rbp]
       mov      rcx, 0x7FFA0266DA80
       cmp      r14, rcx
       jne      SHORT G_M000_IG26
 
G_M000_IG21:                ;; offset=0x02DC
       test     rbx, rbx
       je       SHORT G_M000_IG27
 
G_M000_IG22:                ;; offset=0x02E1
       mov      rcx, 0x7FFA0266DA80
       cmp      qword ptr [rbx], rcx
       jne      SHORT G_M000_IG27
 
G_M000_IG23:                ;; offset=0x02F0
       cmp      eax, 2
       je       G_M000_IG36
 
G_M000_IG24:                ;; offset=0x02F9
       xor      eax, eax
 
G_M000_IG25:                ;; offset=0x02FB
       add      rsp, 120
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG26:                ;; offset=0x030C
       test     rbp, rbp
       je       SHORT G_M000_IG24
 
G_M000_IG27:                ;; offset=0x0311
       mov      r14, qword ptr [rbp]
       mov      rcx, 0x7FFA025FFD50
       cmp      r14, rcx
       je       SHORT G_M000_IG28
       mov      rcx, 0x7FFA02256488
       cmp      r14, rcx
       je       SHORT G_M000_IG28
       mov      rcx, 0x7FFA02223388
       cmp      r14, rcx
       jne      SHORT G_M000_IG24
 
G_M000_IG28:                ;; offset=0x0342
       test     rbx, rbx
       je       SHORT G_M000_IG24
 
G_M000_IG29:                ;; offset=0x0347
       mov      rcx, 0x7FFA025FFD50
       cmp      qword ptr [rbx], rcx
       je       SHORT G_M000_IG30
       mov      rcx, 0x7FFA02256488
       cmp      qword ptr [rbx], rcx
       je       SHORT G_M000_IG30
       mov      rcx, 0x7FFA02223388
       cmp      qword ptr [rbx], rcx
       jne      SHORT G_M000_IG24
 
G_M000_IG30:                ;; offset=0x0374
       add      eax, -2
       cmp      eax, 18
       ja       G_M000_IG24
 
G_M000_IG31:                ;; offset=0x0380
       mov      ecx, eax
       lea      rdx, [reloc @RWD12]
       mov      edx, dword ptr [rdx+4*rcx]
       lea      r8, G_M000_IG02
       add      rdx, r8
       jmp      rdx
 
G_M000_IG32:                ;; offset=0x0398
       mov      rcx, 0x7FFA02256488
       cmp      r14, rcx
       jne      SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x03A7
       xor      ecx, ecx
       jmp      SHORT G_M000_IG35
 
G_M000_IG34:                ;; offset=0x03AB
       mov      rcx, 0x7FFA02256488
       cmp      qword ptr [rbx], rcx
       sete     cl
       movzx    rcx, cl
       test     ecx, ecx
       sete     cl
       movzx    rcx, cl
 
G_M000_IG35:                ;; offset=0x03C6
       test     ecx, ecx
       je       G_M000_IG24
 
G_M000_IG36:                ;; offset=0x03CE
       test     r12d, r12d
       je       SHORT G_M000_IG37
       mov      r8d, dword ptr [r13+0x08]
       mov      rcx, gword ptr [r13]
       mov      gword ptr [rsp+0x20], rcx
       mov      rcx, rbp
       mov      rdx, rbx
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateAugmentedBuiltin(System.Object,System.Object,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       jmp      SHORT G_M000_IG40
 
G_M000_IG37:                ;; offset=0x03F1
       cmp      dword ptr [r13+0x1C], 51
       jne      SHORT G_M000_IG38
       mov      ecx, dword ptr [r13+0x14]
       jmp      SHORT G_M000_IG39
 
G_M000_IG38:                ;; offset=0x03FE
       mov      ecx, dword ptr [r13+0x08]
       and      ecx, 0x7FFFFFFF
 
G_M000_IG39:                ;; offset=0x0408
       mov      rdx, gword ptr [r13]
       mov      gword ptr [rsp+0x20], rdx
       mov      rdx, rbp
       mov      r8, rbx
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateBinaryOperator(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
 
G_M000_IG40:                ;; offset=0x0420
       mov      rcx, rdi
       mov      rdx, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      SHORT G_M000_IG44
 
G_M000_IG41:                ;; offset=0x042D
       movzx    rcx, byte  ptr [rsp+0x68]
       mov      rdx, 0x23A4C0013C0
       mov      rax, 0x23A4C0013C8
       test     ecx, ecx
       mov      rdx, gword ptr [rdx]
       cmove    rdx, gword ptr [rax]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      SHORT G_M000_IG44
 
G_M000_IG42:                ;; offset=0x0459
       mov      rax, gword ptr [rsp+0x38]
       cmp      dword ptr [r13+0x08], 0
       jne      SHORT G_M000_IG45
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       je       G_M000_IG24
 
G_M000_IG43:                ;; offset=0x0476
       mov      ecx, dword ptr [r13+0x08]
       mov      rbx, gword ptr [r13]
       call     [Lokad.Lython.Runtime.LythonRuntime:MapExecutableUnary(int):int]
       mov      ecx, eax
       mov      rdx, gword ptr [rsp+0x38]
       mov      r8, rsi
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateUnaryOperator(int,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      rdx, rax
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG44:                ;; offset=0x04A2
       xor      eax, eax
       mov      qword ptr [rdi+0x08], rax
       jmp      SHORT G_M000_IG48
 
G_M000_IG45:                ;; offset=0x04AA
       test     rax, rax
       je       G_M000_IG24
 
G_M000_IG46:                ;; offset=0x04B3
       mov      r14, qword ptr [rax]
       mov      rcx, 0x7FFA025FFD50
       cmp      r14, rcx
       je       SHORT G_M000_IG43
       mov      rcx, 0x7FFA02256488
       cmp      r14, rcx
       je       SHORT G_M000_IG43
       mov      rcx, 0x7FFA02223388
       cmp      r14, rcx
       jne      G_M000_IG24
       jmp      SHORT G_M000_IG43
 
G_M000_IG47:                ;; offset=0x04E9
       vmovsd   xmm0, qword ptr [rsp+0x70]
       vxorps   xmm0, xmm0, xmmword ptr [reloc @RWD88]
       mov      rcx, 0x23A4C001CF8
       mov      rdx, gword ptr [rcx]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       vmovq    rax, xmm0
       mov      qword ptr [rdi+0x08], rax
 
G_M000_IG48:                ;; offset=0x0515
       mov      eax, 1
 
G_M000_IG49:                ;; offset=0x051A
       add      rsp, 120
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG50:                ;; offset=0x052B
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	00000171h ; case G_M000_IG11
       	dd	00000142h ; case G_M000_IG10
       	dd	00000113h ; case G_M000_IG09
RWD12  	dd	0000038Bh ; case G_M000_IG36
       	dd	0000038Bh ; case G_M000_IG36
       	dd	0000038Bh ; case G_M000_IG36
       	dd	000002B6h ; case G_M000_IG24
       	dd	0000038Bh ; case G_M000_IG36
       	dd	0000038Bh ; case G_M000_IG36
       	dd	0000038Bh ; case G_M000_IG36
       	dd	000002B6h ; case G_M000_IG24
       	dd	00000355h ; case G_M000_IG32
       	dd	00000355h ; case G_M000_IG32
       	dd	00000355h ; case G_M000_IG32
       	dd	00000355h ; case G_M000_IG32
       	dd	00000355h ; case G_M000_IG32
       	dd	0000038Bh ; case G_M000_IG36
       	dd	0000038Bh ; case G_M000_IG36
       	dd	0000038Bh ; case G_M000_IG36
       	dd	0000038Bh ; case G_M000_IG36
       	dd	0000038Bh ; case G_M000_IG36
       	dd	0000038Bh ; case G_M000_IG36
RWD88  	dq	8000000000000000h, 8000000000000000h

; Total bytes of code 1329

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:TryReadDoubleOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):bool (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 3 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r14
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 48
       xor      eax, eax
       mov      qword ptr [rsp+0x28], rax
       mov      rbx, rcx
       mov      rsi, r9
       mov      rdi, bword ptr [rsp+0x80]
 
G_M000_IG02:                ;; offset=0x001F
       test     r8d, r8d
       jge      G_M000_IG12
 
G_M000_IG03:                ;; offset=0x0028
       mov      ebp, r8d
       not      ebp
       mov      r14, gword ptr [rbx+0x30]
       cmp      dword ptr [r14+0x08], ebp
       jg       SHORT G_M000_IG05
       mov      rcx, rbx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CaptureOperandBase():int:this]
       mov      edx, ebp
       sub      edx, eax
       jns      SHORT G_M000_IG04
       mov      rdx, gword ptr [rbx+0x30]
       sub      ebp, dword ptr [rdx+0x08]
       mov      edx, ebp
       lea      r9, [rsp+0x28]
       mov      rcx, rbx
       mov      r8, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       jmp      SHORT G_M000_IG06
 
G_M000_IG04:                ;; offset=0x0062
       lea      rcx, [rsp+0x88]
       lea      r8, [rsp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures:TryRead(int,byref):bool:this]
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0077
       cmp      ebp, dword ptr [r14+0x08]
       jae      SHORT G_M000_IG14
       mov      eax, ebp
       mov      rax, gword ptr [r14+8*rax+0x10]
       mov      gword ptr [rsp+0x28], rax
 
G_M000_IG06:                ;; offset=0x0089
       cmp      gword ptr [rsp+0x28], 0
       je       SHORT G_M000_IG10
 
G_M000_IG07:                ;; offset=0x0091
       mov      rax, gword ptr [rsp+0x28]
       mov      rcx, 0x7FFA02256488
       cmp      qword ptr [rax], rcx
       jne      SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x00A5
       mov      rax, gword ptr [rsp+0x28]
       vmovsd   xmm0, qword ptr [rax+0x08]
       vmovsd   qword ptr [rdi], xmm0
       mov      eax, 1
 
G_M000_IG09:                ;; offset=0x00B8
       add      rsp, 48
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r14
       ret      
 
G_M000_IG10:                ;; offset=0x00C3
       xor      eax, eax
       mov      qword ptr [rdi], rax
 
G_M000_IG11:                ;; offset=0x00C8
       add      rsp, 48
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r14
       ret      
 
G_M000_IG12:                ;; offset=0x00D3
       cmp      r8d, dword ptr [rdx+0x08]
       jae      SHORT G_M000_IG14
       mov      ecx, r8d
       shl      rcx, 4
       add      rcx, bword ptr [rdx]
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetDouble(byref):bool:this]
       nop      
 
G_M000_IG13:                ;; offset=0x00ED
       add      rsp, 48
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r14
       ret      
 
G_M000_IG14:                ;; offset=0x00F8
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 254

