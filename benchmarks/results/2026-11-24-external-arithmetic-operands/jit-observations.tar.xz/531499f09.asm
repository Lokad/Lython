; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 7 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r14
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 48
       xor      eax, eax
       mov      qword ptr [rsp+0x28], rax
       mov      qword ptr [rsp+0x20], rax
       mov      rsi, rcx
       mov      ebx, r8d
       mov      edi, r9d
 
G_M000_IG02:                ;; offset=0x001F
       test     ebx, ebx
       jl       G_M000_IG09
 
G_M000_IG03:                ;; offset=0x0027
       cmp      ebx, dword ptr [rdx+0x08]
       jae      G_M000_IG16
       mov      ecx, ebx
       shl      rcx, 4
       add      rcx, bword ptr [rdx]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rcx, rax
       cmp      ebx, dword ptr [rsi+0xD8]
       jge      SHORT G_M000_IG07
       test     rcx, rcx
       je       SHORT G_M000_IG06
 
G_M000_IG04:                ;; offset=0x004F
       mov      rax, 0x7FFA028366B0
       cmp      qword ptr [rcx], rax
       jne      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x005E
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      rcx, rax
 
G_M000_IG06:                ;; offset=0x0067
       test     rcx, rcx
       je       SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x006C
       mov      rdx, rcx
       mov      rcx, 0x7FFA028377A8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       jmp      G_M000_IG12
 
G_M000_IG08:                ;; offset=0x0084
       mov      rcx, rsi
       mov      edx, edi
       mov      r8d, dword ptr [rsp+0x80]
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      edx, ebx
       mov      rcx, rsi
       mov      r9, gword ptr [rsp+0x88]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       jmp      G_M000_IG12
 
G_M000_IG09:                ;; offset=0x00B2
       not      ebx
       mov      rbp, gword ptr [rsi+0x30]
       mov      r14d, ebx
       sub      r14d, dword ptr [rbp+0x08]
       js       SHORT G_M000_IG11
       mov      rbp, gword ptr [rsi+0x38]
       cmp      dword ptr [rbp+0x08], r14d
       jle      SHORT G_M000_IG10
       lea      r9, [rsp+0x28]
       mov      rcx, rsi
       mov      edx, r14d
       mov      r8, gword ptr [rsp+0x88]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG15
       mov      rax, gword ptr [rsp+0x28]
       jmp      SHORT G_M000_IG12
 
G_M000_IG10:                ;; offset=0x00F3
       sub      r14d, dword ptr [rbp+0x08]
       lea      rcx, [rsp+0x90]
       lea      r8, [rsp+0x20]
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures:TryRead(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG14
       cmp      gword ptr [rsp+0x20], 0
       je       SHORT G_M000_IG14
       mov      rax, gword ptr [rsp+0x20]
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x0120
       cmp      ebx, dword ptr [rbp+0x08]
       jae      G_M000_IG16
       mov      ecx, ebx
       mov      rcx, gword ptr [rbp+8*rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
 
G_M000_IG12:                ;; offset=0x0136
       nop      
 
G_M000_IG13:                ;; offset=0x0137
       add      rsp, 48
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r14
       ret      
 
G_M000_IG14:                ;; offset=0x0142
       mov      rcx, gword ptr [rsi+0x80]
       mov      edx, r14d
       mov      r11, 0x7FFA02181FB0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rbx, rax
       mov      rcx, rsi
       mov      edx, edi
       mov      r8d, dword ptr [rsp+0x80]
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.RuntimeErrors:FreeVariableNotAssociated(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG15:                ;; offset=0x0184
       mov      rcx, gword ptr [rsi+0x38]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG16
       mov      edx, r14d
       mov      rbp, gword ptr [rcx+8*rdx+0x10]
       mov      rcx, rsi
       mov      edx, edi
       mov      r8d, dword ptr [rsp+0x80]
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.RuntimeErrors:NameNotDefined(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG16:                ;; offset=0x01BE
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 452

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:TryEvaluateIntegerInstruction(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):bool (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; partially interruptible
; No PGO data
; 1 inlinees with PGO data; 29 single block inlinees; 8 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 184
       lea      rbp, [rsp+0xF0]
       xor      eax, eax
       mov      qword ptr [rbp-0x98], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       mov      qword ptr [rbp-0x40], rax
       mov      rbx, rcx
       mov      esi, r8d
       mov      rdi, r9
       mov      r13, bword ptr [rbp+0x30]
       mov      r14, bword ptr [rbp+0x38]
       mov      r15, gword ptr [rbp+0x40]
 
G_M000_IG02:                ;; offset=0x0053
       mov      r12, bword ptr [rdx]
       mov      eax, dword ptr [rdx+0x08]
       mov      dword ptr [rbp-0x9C], eax
       mov      dword ptr [r13], esi
       xor      r9d, r9d
       mov      qword ptr [r14], r9
       mov      qword ptr [r14+0x08], r9
       mov      r9, gword ptr [rbx+0x98]
       cmp      esi, dword ptr [r9+0x08]
       jae      G_M000_IG32
       mov      ecx, esi
       shl      rcx, 5
       lea      r10, bword ptr [r9+rcx+0x10]
       mov      bword ptr [rbp-0xA8], r10
       mov      r9d, dword ptr [r10+0x1C]
       cmp      r9d, 46
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x009A
       cmp      r9d, 47
       jne      G_M000_IG20
 
G_M000_IG04:                ;; offset=0x00A4
       mov      r11d, dword ptr [r10+0x10]
       mov      gword ptr [rbp-0x70], r15
       test     r11d, r11d
       jge      SHORT G_M000_IG07
       not      r11d
       mov      r8, gword ptr [rbx+0x30]
       mov      edx, r11d
       sub      edx, dword ptr [r8+0x08]
       js       SHORT G_M000_IG06
       mov      r11, gword ptr [rbx+0x38]
       cmp      dword ptr [r11+0x08], edx
       jle      SHORT G_M000_IG05
       lea      r9, [rbp-0x68]
       mov      rcx, rbx
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       lea      rdx, [rbp-0x40]
       mov      rcx, gword ptr [rbp-0x68]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG08
 
G_M000_IG05:                ;; offset=0x00EB
       sub      edx, dword ptr [r11+0x08]
       lea      rcx, [rbp-0x70]
       lea      r8, [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures:TryReadInteger(int,byref):bool:this]
       jmp      SHORT G_M000_IG08
 
G_M000_IG06:                ;; offset=0x00FF
       cmp      r11d, dword ptr [r8+0x08]
       jae      G_M000_IG32
       mov      ecx, r11d
       mov      rcx, gword ptr [r8+8*rcx+0x10]
       lea      rdx, [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x011D
       cmp      r11d, dword ptr [rbp-0x9C]
       jae      G_M000_IG32
       mov      ecx, r11d
       shl      rcx, 4
       add      rcx, r12
       lea      rdx, [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
 
G_M000_IG08:                ;; offset=0x013E
       xor      r9, r9
       mov      gword ptr [rbp-0x68], r9
       test     eax, eax
       je       G_M000_IG20
       mov      rax, bword ptr [rbp-0xA8]
       mov      r10d, dword ptr [rax+0x0C]
       mov      gword ptr [rbp-0x80], r15
       test     r10d, r10d
       jge      SHORT G_M000_IG11
       not      r10d
       mov      r11, gword ptr [rbx+0x30]
       mov      edx, r10d
       sub      edx, dword ptr [r11+0x08]
       js       SHORT G_M000_IG10
       mov      r10, gword ptr [rbx+0x38]
       cmp      dword ptr [r10+0x08], edx
       jle      SHORT G_M000_IG09
       lea      r9, [rbp-0x78]
       mov      rcx, rbx
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       lea      rdx, [rbp-0x48]
       mov      rcx, gword ptr [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG12
 
G_M000_IG09:                ;; offset=0x019B
       sub      edx, dword ptr [r10+0x08]
       lea      rcx, [rbp-0x80]
       lea      r8, [rbp-0x48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures:TryReadInteger(int,byref):bool:this]
       jmp      SHORT G_M000_IG12
 
G_M000_IG10:                ;; offset=0x01AF
       cmp      r10d, dword ptr [r11+0x08]
       jae      G_M000_IG32
       mov      ecx, r10d
       mov      rcx, gword ptr [r11+8*rcx+0x10]
       lea      rdx, [rbp-0x48]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x01CD
       cmp      r10d, dword ptr [rbp-0x9C]
       jae      G_M000_IG32
       mov      ecx, r10d
       shl      rcx, 4
       add      rcx, r12
       lea      rdx, [rbp-0x48]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
 
G_M000_IG12:                ;; offset=0x01EE
       xor      rdx, rdx
       mov      gword ptr [rbp-0x78], rdx
       test     eax, eax
       je       G_M000_IG20
       mov      rax, bword ptr [rbp-0xA8]
       cmp      dword ptr [rax+0x1C], 46
       jne      G_M000_IG15
       mov      edx, dword ptr [rax+0x08]
       mov      ecx, edx
       and      ecx, 0x7FFFFFFF
       add      ecx, -15
       cmp      ecx, 5
       jbe      G_M000_IG23
       test     edx, 0xFFFFFFFF80000000
       jne      SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x022C
       mov      rax, bword ptr [rbp-0xA8]
       jmp      SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x0235
       mov      r9, qword ptr [rbp-0x40]
       mov      rdx, qword ptr [rbp-0x48]
       mov      gword ptr [rbp-0x98], r15
       mov      bword ptr [rbp-0x90], r12
       mov      r15d, dword ptr [rbp-0x9C]
       mov      dword ptr [rbp-0x88], r15d
       mov      qword ptr [rsp+0x20], rdx
       mov      gword ptr [rsp+0x28], rdi
       lea      rdx, [rbp-0x58]
       mov      qword ptr [rsp+0x30], rdx
       lea      rdx, [rbp-0x60]
       mov      qword ptr [rsp+0x38], rdx
       lea      rdx, [rbp-0x98]
       mov      rcx, rbx
       mov      r8d, esi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryIntegerChain[Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands](Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+SlotIntegerOperands,int,long,long,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,byref):bool]
       test     eax, eax
       mov      rax, bword ptr [rbp-0xA8]
       jne      G_M000_IG22
 
G_M000_IG15:                ;; offset=0x0297
       mov      ecx, dword ptr [rax+0x1C]
       cmp      ecx, 47
       je       SHORT G_M000_IG18
       cmp      ecx, 51
       jne      SHORT G_M000_IG16
       mov      ecx, dword ptr [rax+0x14]
       jmp      SHORT G_M000_IG17
 
G_M000_IG16:                ;; offset=0x02A9
       mov      ecx, dword ptr [rax+0x08]
       and      ecx, 0x7FFFFFFF
 
G_M000_IG17:                ;; offset=0x02B2
       jmp      SHORT G_M000_IG19
 
G_M000_IG18:                ;; offset=0x02B4
       cmp      dword ptr [rax+0x08], 3
       je       SHORT G_M000_IG20
       mov      ecx, dword ptr [rax+0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime:AugmentedBinaryOperator(int):int]
       mov      ecx, eax
 
G_M000_IG19:                ;; offset=0x02C5
       lea      r9, [rbp-0x50]
       mov      rdx, qword ptr [rbp-0x40]
       mov      r8, qword ptr [rbp-0x48]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineBinary(int,long,long,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG20
       mov      r13, qword ptr [rbp-0x50]
       mov      rcx, 0x2280AC01CF0
       mov      rdx, gword ptr [rcx]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      qword ptr [r14+0x08], r13
       jmp      G_M000_IG29
 
G_M000_IG20:                ;; offset=0x02FD
       xor      eax, eax
 
G_M000_IG21:                ;; offset=0x02FF
       add      rsp, 184
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG22:                ;; offset=0x0313
       mov      ecx, dword ptr [rbp-0x58]
       mov      dword ptr [r13], ecx
       mov      rdi, qword ptr [rbp-0x60]
       mov      rcx, 0x2280AC01CF0
       mov      rdx, gword ptr [rcx]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      qword ptr [r14+0x08], rdi
       jmp      G_M000_IG29
 
G_M000_IG23:                ;; offset=0x033C
       mov      rax, bword ptr [rbp-0xA8]
       mov      rbx, gword ptr [rax]
       mov      rsi, gword ptr [rdi+0xA0]
       cmp      byte  ptr [rsi], sil
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG24
       mov      rcx, rsi
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG24:                ;; offset=0x0369
       mov      rbx, bword ptr [rbp-0xA8]
       cmp      dword ptr [rbx+0x1C], 51
       jne      SHORT G_M000_IG25
       mov      ecx, dword ptr [rbx+0x14]
       jmp      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x037B
       mov      ecx, dword ptr [rbx+0x08]
       and      ecx, 0x7FFFFFFF
 
G_M000_IG26:                ;; offset=0x0384
       mov      rdx, qword ptr [rbp-0x48]
       cmp      qword ptr [rbp-0x40], rdx
       jge      SHORT G_M000_IG31
 
G_M000_IG27:                ;; offset=0x038E
       mov      edx, -1
 
G_M000_IG28:                ;; offset=0x0393
       call     [Lokad.Lython.Runtime.LythonRuntime:CompareOrderedResult(int,int):bool]
       mov      rcx, 0x2280AC013C0
       mov      rdx, 0x2280AC013C8
       test     eax, eax
       mov      rdx, gword ptr [rdx]
       cmovne   rdx, gword ptr [rcx]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      eax, eax
       mov      qword ptr [r14+0x08], rax
 
G_M000_IG29:                ;; offset=0x03C4
       mov      eax, 1
 
G_M000_IG30:                ;; offset=0x03C9
       add      rsp, 184
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG31:                ;; offset=0x03DD
       cmp      qword ptr [rbp-0x40], rdx
       setg     dl
       movzx    rdx, dl
       jmp      SHORT G_M000_IG28
 
G_M000_IG32:                ;; offset=0x03E9
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1007

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:TryEvaluateBuiltinArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):bool (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 35 single block inlinees; 5 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 120
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x40], ymm4
       vmovdqa  xmmword ptr [rsp+0x60], xmm4
       xor      eax, eax
       mov      qword ptr [rsp+0x70], rax
       mov      rbp, rcx
       mov      rbx, rdx
       mov      r14d, r8d
       mov      rsi, r9
       mov      rdi, bword ptr [rsp+0xE0]
       mov      r15, gword ptr [rsp+0xE8]
 
G_M000_IG02:                ;; offset=0x0043
       xor      edx, edx
       mov      qword ptr [rdi], rdx
       mov      qword ptr [rdi+0x08], rdx
       mov      rdx, gword ptr [rbp+0x98]
       cmp      r14d, dword ptr [rdx+0x08]
       jae      G_M000_IG50
       mov      r8d, r14d
       shl      r8, 5
       lea      r13, bword ptr [rdx+r8+0x10]
       cmp      dword ptr [r13+0x1C], 47
       sete     r12b
       movzx    r12, r12b
       test     r12d, r12d
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x007B
       cmp      dword ptr [r13+0x08], 3
       je       G_M000_IG24
 
G_M000_IG04:                ;; offset=0x0086
       mov      rdx, bword ptr [rbx]
       mov      r8d, dword ptr [rbx+0x08]
       mov      bword ptr [rsp+0x50], rdx
       mov      dword ptr [rsp+0x58], r8d
       lea      rdx, [rsp+0x70]
       mov      qword ptr [rsp+0x20], rdx
       mov      gword ptr [rsp+0x28], r15
       lea      rdx, [rsp+0x50]
       mov      r8d, dword ptr [r13+0x10]
       mov      rcx, rbp
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryReadDoubleOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):bool]
       test     eax, eax
       je       G_M000_IG13
       cmp      dword ptr [r13+0x1C], 48
       je       G_M000_IG12
       mov      rdx, bword ptr [rbx]
       mov      r8d, dword ptr [rbx+0x08]
       mov      bword ptr [rsp+0x50], rdx
       mov      dword ptr [rsp+0x58], r8d
       lea      rdx, [rsp+0x60]
       mov      qword ptr [rsp+0x20], rdx
       mov      gword ptr [rsp+0x28], r15
       lea      rdx, [rsp+0x50]
       mov      r8d, dword ptr [r13+0x0C]
       mov      rcx, rbp
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryReadDoubleOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):bool]
       test     eax, eax
       je       G_M000_IG13
       test     r12d, r12d
       je       SHORT G_M000_IG05
       mov      ecx, dword ptr [r13+0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime:AugmentedBinaryOperator(int):int]
       jmp      SHORT G_M000_IG07
 
G_M000_IG05:                ;; offset=0x011C
       cmp      dword ptr [r13+0x1C], 51
       jne      SHORT G_M000_IG06
       mov      eax, dword ptr [r13+0x14]
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x0129
       mov      eax, dword ptr [r13+0x08]
       and      eax, 0x7FFFFFFF
 
G_M000_IG07:                ;; offset=0x0132
       add      eax, -2
       cmp      eax, 2
       ja       G_M000_IG13
 
G_M000_IG08:                ;; offset=0x013E
       mov      ecx, eax
       lea      rdx, [reloc @RWD00]
       mov      edx, dword ptr [rdx+4*rcx]
       lea      rax, G_M000_IG02
       add      rdx, rax
       jmp      rdx
 
G_M000_IG09:                ;; offset=0x0156
       vmovsd   xmm0, qword ptr [rsp+0x70]
       vmulsd   xmm0, xmm0, qword ptr [rsp+0x60]
       mov      rcx, 0x2280AC01CF8
       mov      rdx, gword ptr [rcx]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       vmovq    rcx, xmm0
       mov      qword ptr [rdi+0x08], rcx
       jmp      G_M000_IG48
 
G_M000_IG10:                ;; offset=0x0185
       vmovsd   xmm0, qword ptr [rsp+0x70]
       vsubsd   xmm0, xmm0, qword ptr [rsp+0x60]
       mov      rcx, 0x2280AC01CF8
       mov      rdx, gword ptr [rcx]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       vmovq    rcx, xmm0
       mov      qword ptr [rdi+0x08], rcx
       jmp      G_M000_IG48
 
G_M000_IG11:                ;; offset=0x01B4
       vmovsd   xmm0, qword ptr [rsp+0x70]
       vaddsd   xmm0, xmm0, qword ptr [rsp+0x60]
       mov      rcx, 0x2280AC01CF8
       mov      rdx, gword ptr [rcx]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       vmovq    rdx, xmm0
       mov      qword ptr [rdi+0x08], rdx
       jmp      G_M000_IG48
 
G_M000_IG12:                ;; offset=0x01E3
       cmp      dword ptr [r13+0x08], 2
       je       G_M000_IG47
 
G_M000_IG13:                ;; offset=0x01EE
       vmovdqu  xmm0, xmmword ptr [rbx]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG14:                ;; offset=0x01F8
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      gword ptr [rsp+0x28], rsi
       mov      gword ptr [rsp+0x30], r15
       lea      rdx, [rsp+0x40]
       mov      r8d, dword ptr [r13+0x10]
       mov      rcx, rbp
       mov      r9d, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      gword ptr [rsp+0x38], rax
       cmp      dword ptr [r13+0x1C], 48
       je       G_M000_IG42
       mov      dword ptr [rsp+0x20], 1
       mov      gword ptr [rsp+0x28], rsi
       mov      gword ptr [rsp+0x30], r15
       mov      r8d, dword ptr [r13+0x0C]
       mov      rcx, rbp
       mov      rdx, rbx
       mov      r9d, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      rbx, rax
       test     r12d, r12d
       je       SHORT G_M000_IG15
       mov      ecx, dword ptr [r13+0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime:AugmentedBinaryOperator(int):int]
       jmp      SHORT G_M000_IG19
 
G_M000_IG15:                ;; offset=0x0266
       cmp      dword ptr [r13+0x1C], 51
       jne      SHORT G_M000_IG16
       mov      ecx, dword ptr [r13+0x14]
       jmp      SHORT G_M000_IG17
 
G_M000_IG16:                ;; offset=0x0273
       mov      ecx, dword ptr [r13+0x08]
       and      ecx, 0x7FFFFFFF
 
G_M000_IG17:                ;; offset=0x027D
       mov      rdx, gword ptr [r13]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x68]
       mov      qword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rsp+0x38]
       mov      r8, rbx
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       jne      G_M000_IG41
       cmp      dword ptr [r13+0x1C], 51
       jne      SHORT G_M000_IG18
       mov      eax, dword ptr [r13+0x14]
       jmp      SHORT G_M000_IG19
 
G_M000_IG18:                ;; offset=0x02B6
       mov      eax, dword ptr [r13+0x08]
       and      eax, 0x7FFFFFFF
 
G_M000_IG19:                ;; offset=0x02BF
       mov      rbp, gword ptr [rsp+0x38]
       test     rbp, rbp
       je       SHORT G_M000_IG26
 
G_M000_IG20:                ;; offset=0x02C9
       mov      r14, qword ptr [rbp]
       mov      rcx, 0x7FFA0268DA80
       cmp      r14, rcx
       jne      SHORT G_M000_IG26
 
G_M000_IG21:                ;; offset=0x02DC
       test     rbx, rbx
       je       SHORT G_M000_IG27
 
G_M000_IG22:                ;; offset=0x02E1
       mov      rcx, 0x7FFA0268DA80
       cmp      qword ptr [rbx], rcx
       jne      SHORT G_M000_IG27
 
G_M000_IG23:                ;; offset=0x02F0
       cmp      eax, 2
       je       G_M000_IG36
 
G_M000_IG24:                ;; offset=0x02F9
       xor      eax, eax
 
G_M000_IG25:                ;; offset=0x02FB
       add      rsp, 120
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG26:                ;; offset=0x030C
       test     rbp, rbp
       je       SHORT G_M000_IG24
 
G_M000_IG27:                ;; offset=0x0311
       mov      r14, qword ptr [rbp]
       mov      rcx, 0x7FFA0261FD50
       cmp      r14, rcx
       je       SHORT G_M000_IG28
       mov      rcx, 0x7FFA02276488
       cmp      r14, rcx
       je       SHORT G_M000_IG28
       mov      rcx, 0x7FFA02243388
       cmp      r14, rcx
       jne      SHORT G_M000_IG24
 
G_M000_IG28:                ;; offset=0x0342
       test     rbx, rbx
       je       SHORT G_M000_IG24
 
G_M000_IG29:                ;; offset=0x0347
       mov      rcx, 0x7FFA0261FD50
       cmp      qword ptr [rbx], rcx
       je       SHORT G_M000_IG30
       mov      rcx, 0x7FFA02276488
       cmp      qword ptr [rbx], rcx
       je       SHORT G_M000_IG30
       mov      rcx, 0x7FFA02243388
       cmp      qword ptr [rbx], rcx
       jne      SHORT G_M000_IG24
 
G_M000_IG30:                ;; offset=0x0374
       add      eax, -2
       cmp      eax, 18
       ja       G_M000_IG24
 
G_M000_IG31:                ;; offset=0x0380
       mov      ecx, eax
       lea      rdx, [reloc @RWD12]
       mov      edx, dword ptr [rdx+4*rcx]
       lea      r8, G_M000_IG02
       add      rdx, r8
       jmp      rdx
 
G_M000_IG32:                ;; offset=0x0398
       mov      rcx, 0x7FFA02276488
       cmp      r14, rcx
       jne      SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x03A7
       xor      ecx, ecx
       jmp      SHORT G_M000_IG35
 
G_M000_IG34:                ;; offset=0x03AB
       mov      rcx, 0x7FFA02276488
       cmp      qword ptr [rbx], rcx
       sete     cl
       movzx    rcx, cl
       test     ecx, ecx
       sete     cl
       movzx    rcx, cl
 
G_M000_IG35:                ;; offset=0x03C6
       test     ecx, ecx
       je       G_M000_IG24
 
G_M000_IG36:                ;; offset=0x03CE
       test     r12d, r12d
       je       SHORT G_M000_IG37
       mov      r8d, dword ptr [r13+0x08]
       mov      rcx, gword ptr [r13]
       mov      gword ptr [rsp+0x20], rcx
       mov      rcx, rbp
       mov      rdx, rbx
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateAugmentedBuiltin(System.Object,System.Object,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       jmp      SHORT G_M000_IG40
 
G_M000_IG37:                ;; offset=0x03F1
       cmp      dword ptr [r13+0x1C], 51
       jne      SHORT G_M000_IG38
       mov      ecx, dword ptr [r13+0x14]
       jmp      SHORT G_M000_IG39
 
G_M000_IG38:                ;; offset=0x03FE
       mov      ecx, dword ptr [r13+0x08]
       and      ecx, 0x7FFFFFFF
 
G_M000_IG39:                ;; offset=0x0408
       mov      rdx, gword ptr [r13]
       mov      gword ptr [rsp+0x20], rdx
       mov      rdx, rbp
       mov      r8, rbx
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateBinaryOperator(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
 
G_M000_IG40:                ;; offset=0x0420
       mov      rcx, rdi
       mov      rdx, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      SHORT G_M000_IG44
 
G_M000_IG41:                ;; offset=0x042D
       movzx    rcx, byte  ptr [rsp+0x68]
       mov      rdx, 0x2280AC013C0
       mov      rax, 0x2280AC013C8
       test     ecx, ecx
       mov      rdx, gword ptr [rdx]
       cmove    rdx, gword ptr [rax]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      SHORT G_M000_IG44
 
G_M000_IG42:                ;; offset=0x0459
       mov      rax, gword ptr [rsp+0x38]
       cmp      dword ptr [r13+0x08], 0
       jne      SHORT G_M000_IG45
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       je       G_M000_IG24
 
G_M000_IG43:                ;; offset=0x0476
       mov      ecx, dword ptr [r13+0x08]
       mov      rbx, gword ptr [r13]
       call     [Lokad.Lython.Runtime.LythonRuntime:MapExecutableUnary(int):int]
       mov      ecx, eax
       mov      rdx, gword ptr [rsp+0x38]
       mov      r8, rsi
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateUnaryOperator(int,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      rdx, rax
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG44:                ;; offset=0x04A2
       xor      eax, eax
       mov      qword ptr [rdi+0x08], rax
       jmp      SHORT G_M000_IG48
 
G_M000_IG45:                ;; offset=0x04AA
       test     rax, rax
       je       G_M000_IG24
 
G_M000_IG46:                ;; offset=0x04B3
       mov      r14, qword ptr [rax]
       mov      rcx, 0x7FFA0261FD50
       cmp      r14, rcx
       je       SHORT G_M000_IG43
       mov      rcx, 0x7FFA02276488
       cmp      r14, rcx
       je       SHORT G_M000_IG43
       mov      rcx, 0x7FFA02243388
       cmp      r14, rcx
       jne      G_M000_IG24
       jmp      SHORT G_M000_IG43
 
G_M000_IG47:                ;; offset=0x04E9
       vmovsd   xmm0, qword ptr [rsp+0x70]
       vxorps   xmm0, xmm0, xmmword ptr [reloc @RWD88]
       mov      rcx, 0x2280AC01CF8
       mov      rdx, gword ptr [rcx]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       vmovq    rax, xmm0
       mov      qword ptr [rdi+0x08], rax
 
G_M000_IG48:                ;; offset=0x0515
       mov      eax, 1
 
G_M000_IG49:                ;; offset=0x051A
       add      rsp, 120
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG50:                ;; offset=0x052B
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	00000171h ; case G_M000_IG11
       	dd	00000142h ; case G_M000_IG10
       	dd	00000113h ; case G_M000_IG09
RWD12  	dd	0000038Bh ; case G_M000_IG36
       	dd	0000038Bh ; case G_M000_IG36
       	dd	0000038Bh ; case G_M000_IG36
       	dd	000002B6h ; case G_M000_IG24
       	dd	0000038Bh ; case G_M000_IG36
       	dd	0000038Bh ; case G_M000_IG36
       	dd	0000038Bh ; case G_M000_IG36
       	dd	000002B6h ; case G_M000_IG24
       	dd	00000355h ; case G_M000_IG32
       	dd	00000355h ; case G_M000_IG32
       	dd	00000355h ; case G_M000_IG32
       	dd	00000355h ; case G_M000_IG32
       	dd	00000355h ; case G_M000_IG32
       	dd	0000038Bh ; case G_M000_IG36
       	dd	0000038Bh ; case G_M000_IG36
       	dd	0000038Bh ; case G_M000_IG36
       	dd	0000038Bh ; case G_M000_IG36
       	dd	0000038Bh ; case G_M000_IG36
       	dd	0000038Bh ; case G_M000_IG36
RWD88  	dq	8000000000000000h, 8000000000000000h

; Total bytes of code 1329

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:TryReadDoubleOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):bool (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 4 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 48
       xor      eax, eax
       mov      qword ptr [rsp+0x28], rax
       mov      rax, r9
       mov      rbx, bword ptr [rsp+0x70]
 
G_M000_IG02:                ;; offset=0x0016
       test     r8d, r8d
       jge      G_M000_IG12
 
G_M000_IG03:                ;; offset=0x001F
       mov      esi, r8d
       not      esi
       mov      rdi, gword ptr [rcx+0x30]
       mov      edx, esi
       sub      edx, dword ptr [rdi+0x08]
       js       SHORT G_M000_IG05
       mov      rdi, gword ptr [rcx+0x38]
       cmp      dword ptr [rdi+0x08], edx
       jle      SHORT G_M000_IG04
       lea      r9, [rsp+0x28]
       mov      r8, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:TryResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       jmp      SHORT G_M000_IG06
 
G_M000_IG04:                ;; offset=0x0048
       sub      edx, dword ptr [rdi+0x08]
       lea      rcx, [rsp+0x78]
       lea      r8, [rsp+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures:TryRead(int,byref):bool:this]
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x005D
       cmp      esi, dword ptr [rdi+0x08]
       jae      SHORT G_M000_IG14
       mov      eax, esi
       mov      rax, gword ptr [rdi+8*rax+0x10]
       mov      gword ptr [rsp+0x28], rax
 
G_M000_IG06:                ;; offset=0x006E
       cmp      gword ptr [rsp+0x28], 0
       je       SHORT G_M000_IG10
 
G_M000_IG07:                ;; offset=0x0076
       mov      rax, gword ptr [rsp+0x28]
       mov      rcx, 0x7FFA02276488
       cmp      qword ptr [rax], rcx
       jne      SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x008A
       mov      rax, gword ptr [rsp+0x28]
       vmovsd   xmm0, qword ptr [rax+0x08]
       vmovsd   qword ptr [rbx], xmm0
       mov      eax, 1
 
G_M000_IG09:                ;; offset=0x009D
       add      rsp, 48
       pop      rbx
       pop      rsi
       pop      rdi
       ret      
 
G_M000_IG10:                ;; offset=0x00A5
       xor      eax, eax
       mov      qword ptr [rbx], rax
 
G_M000_IG11:                ;; offset=0x00AA
       add      rsp, 48
       pop      rbx
       pop      rsi
       pop      rdi
       ret      
 
G_M000_IG12:                ;; offset=0x00B2
       cmp      r8d, dword ptr [rdx+0x08]
       jae      SHORT G_M000_IG14
       mov      ecx, r8d
       shl      rcx, 4
       add      rcx, bword ptr [rdx]
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetDouble(byref):bool:this]
       nop      
 
G_M000_IG13:                ;; offset=0x00CC
       add      rsp, 48
       pop      rbx
       pop      rsi
       pop      rdi
       ret      
 
G_M000_IG14:                ;; offset=0x00D4
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 218

