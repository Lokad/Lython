using System.Diagnostics.CodeAnalysis;
using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;

using var input = JsonDocument.Parse(File.ReadAllBytes(args[0]));
var rows = new List<object>();
var engine = new LythonEngine();
foreach (var row in input.RootElement.GetProperty("cases").EnumerateArray())
{
    var track = new Peak();
    var source = row.GetProperty("source").GetString()!;
    using (var code = engine.Compile(source, new Budget(track.Root, track)))
    {
        rows.Add(new { id = row.GetProperty("id").GetString(), code.IsValid,
            Diagnostics = code.Diagnostics.Select(d => new { d.Code, d.Message, d.Severity, d.Span }).ToArray(),
            track.PeakBytes, RetainedBytes = track.Root.ReservedBytes });
    }
    if (track.Root.ReservedBytes != 0) throw new InvalidDataException("Compilation left a charged owner.");
}
File.WriteAllText(args[1], JsonSerializer.Serialize(new {
    CoreHash = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))),
    CatalogHash = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(args[0]))), Rows = rows
},new JsonSerializerOptions { WriteIndented = true }));

file sealed class Peak
{
    internal readonly LythonMemoryBudget Root = new();
    internal long PeakBytes { get; private set; }
    internal void Observe() => PeakBytes = Math.Max(PeakBytes, Root.ReservedBytes);
}

file sealed class Budget(ILythonMemoryBudget inner, Peak track) : ILythonMemoryScope
{
    public ILythonMemoryScope CreateScope() => new Budget(inner.CreateScope(), track);
    public bool TryReserve(long bytes, [NotNullWhen(true)] out ILythonMemoryReservation? reservation)
    {
        if (!inner.TryReserve(bytes, out var admitted)) { reservation = null; return false; }
        track.Observe();
        reservation = new Reservation(admitted, track);
        return true;
    }
    public void Dispose() => (inner as ILythonMemoryScope)?.Dispose();
}

file sealed class Reservation(ILythonMemoryReservation inner, Peak track) : ILythonMemoryReservation
{
    public long Bytes => inner.Bytes;
    public bool TryResize(long bytes)
    {
        if (!inner.TryResize(bytes)) return false;
        track.Observe();
        return true;
    }
    public void Dispose() => inner.Dispose();
}
