from pathlib import Path
import sys

frontend = Path(sys.argv[1]) / "src/Lokad.Lython/Frontend"
p = frontend / "ScopeDirectiveFacts.cs"
s = p.read_text(encoding="utf-8")
a = s.index("    internal static void CollectPatternBindings(")
b = s.index("    internal static void CollectExpressionBindings(",a)
orig = s[a:b]
pattern = orig.replace("internal static void CollectPatternBindings(PatternSyntax pattern, ICollection<string> names)",
    "internal static void CollectPatternBindings<TState>(PatternSyntax pattern, TState state, Action<TState, string> add)")
pattern = pattern.replace("names.Add(", "add(state, ").replace(", names);", ", state, add);")
a1 = """    internal static void CollectPatternBindings(PatternSyntax pattern, ICollection<string> names)
        => CollectPatternBindings(pattern, names, static (collection, name) => collection.Add(name));

"""
orig = s[b:]
expr = orig.replace("internal static void CollectExpressionBindings(ExpressionSyntax expression, ICollection<string> names)",
    "internal static void CollectExpressionBindings<TState>(ExpressionSyntax expression, TState state, Action<TState, string> add)")
expr = expr.replace("names.Add(", "add(state, ").replace(", names);", ", state, add);")
b1 = """    internal static void CollectExpressionBindings(ExpressionSyntax expression, ICollection<string> names)
        => CollectExpressionBindings(expression, names, static (collection, name) => collection.Add(name));

"""
p.write_text(s[:a]+a1+pattern+b1+expr,encoding="utf-8",newline="\n")

p = frontend / "StaticNameBindingDiagnostics.cs"
s = p.read_text(encoding="utf-8")
def replace(old,new):
    global s
    assert s.count(old)==1,old
    s=s.replace(old,new)
s=s.replace("HashSet<string> maybeAssigned","AssignmentFacts maybeAssigned").replace("HashSet<string> assigned","AssignmentFacts assigned")
replace("""        var maybeAssigned = new HashSet<string>(
            functionDefinition.Parameters
                .Select(static parameter => parameter.Name)
                .Where(name => !scopeFacts.GlobalNames.Contains(name) && !scopeFacts.NonlocalNames.Contains(name)),
            StringComparer.Ordinal);""","""        var maybeAssigned = new AssignmentFacts(
            functionDefinition.Parameters
                .Select(static parameter => parameter.Name)
                .Where(name => !scopeFacts.GlobalNames.Contains(name) && !scopeFacts.NonlocalNames.Contains(name)), context);""")
replace("""                var lambdaAssigned = new HashSet<string>(
                    lambda.Parameters.Select(static parameter => parameter.Name),
                    StringComparer.Ordinal);""","""                var lambdaAssigned = new AssignmentFacts(lambda.Parameters.Select(static parameter => parameter.Name), context);""")
replace("""            var maybeAssigned = new HashSet<string>(
                lambda.Parameters.Select(static parameter => parameter.Name),
                StringComparer.Ordinal);""","""            var maybeAssigned = new AssignmentFacts(lambda.Parameters.Select(static parameter => parameter.Name), context);""")
a=s.index("            case IfStatementSyntax ifStatement:")
b=s.index("            case DeleteStatementSyntax",a)
s=s[:a]+"""            case IfStatementSyntax ifStatement:
                {
                    // Analyze both alternatives from the original bindings.
                    // The join keeps a name assigned on either path.
                    var saved = maybeAssigned.SavedCount;
                    var branch = maybeAssigned.BeginBranch();
                    AnalyzeStatements(ifStatement.ThenStatements, context, localNames, maybeAssigned);
                    maybeAssigned.SaveAndRewind(branch);
                    AnalyzeOptionalBranch(ifStatement.ElseStatements, context, localNames, maybeAssigned);
                    maybeAssigned.ApplySaved(saved);
                    break;
                }

            case ForStatementSyntax forStatement:
                {
                    var branch = maybeAssigned.BeginBranch();
                    AnalyzeLoopStores(forStatement.Target, context, localNames, maybeAssigned);
                    AnalyzeStatements(forStatement.Body, context, localNames, maybeAssigned);
                    maybeAssigned.Merge(branch);
                    AnalyzeOptionalBranch(forStatement.ElseStatements, context, localNames, maybeAssigned);
                    break;
                }

            case WhileStatementSyntax whileStatement:
                AnalyzeOptionalBranch(whileStatement.Body, context, localNames, maybeAssigned);
                AnalyzeOptionalBranch(whileStatement.ElseStatements, context, localNames, maybeAssigned);
                break;

            case MatchStatementSyntax matchStatement:
                {
                    var savedBodies = maybeAssigned.SavedCount;
                    foreach (var matchCase in matchStatement.Cases)
                    {
                        var branch = maybeAssigned.BeginBranch();
                        ScopeDirectiveFactsCollector.CollectPatternBindings(matchCase.Pattern, maybeAssigned,
                            static (facts, name) => facts.Add(name));
                        if (matchCase.Guard is not null)
                        {
                            AnalyzeExpression(matchCase.Guard, context, localNames, maybeAssigned);
                            // Pattern and guard only add bindings. Their effects
                            // are visible to later cases, unlike body effects.
                            maybeAssigned.Merge(branch);
                            branch = maybeAssigned.BeginBranch();
                        }

                        AnalyzeStatements(matchCase.Body, context, localNames, maybeAssigned);
                        maybeAssigned.SaveAndRewind(branch);
                    }
                    maybeAssigned.ApplySaved(savedBodies);
                    break;
                }

"""+s[b:]
replace("""                maybeAssigned.UnionWith(ScopeDirectiveFactsCollector.ForClass(classDefinition).NonlocalNames.Intersect(localNames));""",
"""                foreach (var name in ScopeDirectiveFactsCollector.ForClass(classDefinition).NonlocalNames)
                    if (localNames.Contains(name)) maybeAssigned.Add(name);""")
a=s.index("            case TryStatementSyntax tryStatement:")
b=s.index("                    if (tryStatement.FinallyBody",a)
s=s[:a]+"""            case TryStatementSyntax tryStatement:
                {
                    AnalyzeOptionalBranch(tryStatement.TryBody, context, localNames, maybeAssigned);
                    foreach (var exceptClause in tryStatement.ExceptClauses)
                    {
                        var name = exceptClause.ExceptionVariableName;
                        var hideHandler = name is not null && !maybeAssigned.Contains(name);
                        var branch = maybeAssigned.BeginBranch();
                        if (exceptClause.ExceptionTypeExpression is { } header)
                            AnalyzeExpression(header, context, localNames, maybeAssigned);
                        if (name is not null) maybeAssigned.Add(name);

                        AnalyzeStatements(exceptClause.Body, context, localNames, maybeAssigned);
                        // Only a handler variable that existed before the handler
                        // can remain a possible assignment after it exits.
                        if (hideHandler) maybeAssigned.Remove(name!);
                        maybeAssigned.Merge(branch);
                    }
                    AnalyzeOptionalBranch(tryStatement.ElseBody, context, localNames, maybeAssigned);
"""+s[b:]
m="    private static void AnalyzeExpression(\n"
replace(m,"""    private static void AnalyzeOptionalBranch(IReadOnlyList<StatementSyntax>? statements, StaticAnalysisContext context,
        IReadOnlySet<string> localNames, AssignmentFacts assignments)
    {
        if (statements is null) return;
        var branch = assignments.BeginBranch();
        AnalyzeStatements(statements, context, localNames, assignments);
        assignments.Merge(branch);
    }

"""+m)
a=s.index("            case ListComprehensionExpressionSyntax listComprehension:")
b=s.index("            case AssignmentExpressionSyntax assignment:",a)
s=s[:a]+"""            case ListComprehensionExpressionSyntax listComprehension:
                AnalyzeComprehension(expression, listComprehension.Clauses, listComprehension.ItemExpression, null,
                    context, localNames, maybeAssigned);
                return;

            case GeneratorExpressionSyntax generator:
                AnalyzeComprehension(expression, generator.Clauses, generator.ItemExpression, null,
                    context, localNames, maybeAssigned);
                return;

            case SetComprehensionExpressionSyntax setComprehension:
                AnalyzeComprehension(expression, setComprehension.Clauses, setComprehension.ItemExpression, null,
                    context, localNames, maybeAssigned);
                return;

            case DictComprehensionExpressionSyntax dictComprehension:
                AnalyzeComprehension(expression, dictComprehension.Clauses, dictComprehension.KeyExpression,
                    dictComprehension.ValueExpression, context, localNames, maybeAssigned);
                return;

"""+s[b:]
a=s.index("    // The first iterable evaluates")
b=s.index("    private static void AnalyzeLocalRead(",a)
s=s[:a]+"""    // Clause targets stay visible within this comprehension. Only binding
    // expressions can assign in the surrounding scope.
    private static void AnalyzeComprehension(ExpressionSyntax expression, IReadOnlyList<ComprehensionClauseSyntax> clauses,
        ExpressionSyntax item, ExpressionSyntax? value, StaticAnalysisContext context, IReadOnlySet<string> localNames,
        AssignmentFacts assignments)
    {
        var branch = assignments.BeginBranch();
        foreach (var clause in clauses)
        {
            AnalyzeExpression(clause.Iterable, context, localNames, assignments);
            AnalyzeLoopStores(clause.Target, context, localNames, assignments);
            if (clause.Condition is not null)
                AnalyzeExpression(clause.Condition, context, localNames, assignments);
        }
        AnalyzeExpression(item, context, localNames, assignments);
        if (value is not null) AnalyzeExpression(value, context, localNames, assignments);
        assignments.Rewind(branch);
        ScopeDirectiveFactsCollector.CollectExpressionBindings(expression, assignments, static (facts, name) => facts.Add(name));
    }

"""+s[b:]
a=s.index("    private static HashSet<string> Clone(")
s=s[:a]+"""    // Branches change one live set. Record actual writes so restoration
    // and conservative joins only visit the names touched by a branch.
    private sealed class AssignmentFacts(IEnumerable<string> initial, StaticAnalysisContext context)
    {
        private readonly HashSet<string> _names = new(initial, StringComparer.Ordinal);
        private readonly record struct Change(string Name, bool Added);
        private List<Change>? _changes;
        private List<string>? _saved;
        private int _branchDepth;

        internal bool Contains(string name) => _names.Contains(name);
        internal int SavedCount => _saved?.Count ?? 0;

        internal void Add(string name)
        {
            if (_names.Add(name) && _branchDepth != 0) (_changes ??= []).Add(new(name, true));
        }

        internal void Remove(string name)
        {
            if (_names.Remove(name) && _branchDepth != 0) (_changes ??= []).Add(new(name, false));
        }

        internal int BeginBranch()
        {
            _branchDepth++;
            return _changes?.Count ?? 0;
        }

        internal void Rewind(int start)
        {
            _branchDepth--;
            if (_changes is not { } changes || changes.Count == start) return;
            for (var i = changes.Count - 1; i >= start; i--)
            {
                if ((i & 255) == 0) context.CheckExecution();
                var change = changes[i];
                if (change.Added) _names.Remove(change.Name);
                else _names.Add(change.Name);
            }
            changes.RemoveRange(start, changes.Count - start);
        }

        internal void SaveAndRewind(int start)
        {
            if (_changes is { } changes)
            {
                for (var i = start; i < changes.Count; i++)
                {
                    if ((i & 255) == 0) context.CheckExecution();
                    var change = changes[i];
                    if (change.Added && _names.Contains(change.Name)) (_saved ??= []).Add(change.Name);
                }
            }
            Rewind(start);
        }

        internal void ApplySaved(int start)
        {
            if (_saved is not { } saved || saved.Count == start) return;
            for (var i = start; i < saved.Count; i++)
            {
                if ((i & 255) == 0) context.CheckExecution();
                Add(saved[i]);
            }
            saved.RemoveRange(start, saved.Count - start);
        }

        internal void Merge(int start)
        {
            var saved = SavedCount;
            SaveAndRewind(start);
            ApplySaved(saved);
        }
    }
}
"""
assert "Clone(" not in s and "UnionWith(" not in s
p.write_text(s,encoding="utf-8",newline="\n")
