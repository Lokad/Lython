#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/static-assignment-deltas-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
dir=/mnt/d/code/Lython/.git/agent-notes/review-20261031/static-assignment-deltas-20261122
white='Category!=Stress&(FullyQualifiedName~Frontend|FullyQualifiedName~Executable|FullyQualifiedName~Compiler|FullyQualifiedName~Lexical)'
public='Category!=Stress&(FullyQualifiedName~CompilerCancellation|FullyQualifiedName~Lexical|FullyQualifiedName~ScopeDirective|FullyQualifiedName~SharedCompilerFact|FullyQualifiedName~StaticErrorDiagnostics|FullyQualifiedName~MatchGuard|FullyQualifiedName~NonlocalRebinding|FullyQualifiedName~UnboundLocalVariable|FullyQualifiedName~Comprehension|FullyQualifiedName~ControlFlow)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter "$white" --artifacts-path "$dir/ubuntu" --nologo > "$dir/white-ubuntu.log" 2>&1 || { tail -65 "$dir/white-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter "$public" --artifacts-path "$dir/ubuntu" --nologo > "$dir/public-ubuntu.log" 2>&1 || { tail -65 "$dir/public-ubuntu.log"; exit 1; }
awk '/Passed!/{count++;print} END{exit count!=2}' "$dir/white-ubuntu.log" "$dir/public-ubuntu.log"
