from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
pair=lab/"comparison"
pair.mkdir(exist_ok=True)
producer=lab.parent/"regex-template-source-ranges-20261122"
reference=producer/"comparison/reference"
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(data):return hashlib.sha256(data).hexdigest()
def write(p,data):p.write_text(json.dumps(data,indent=2)+"\n",encoding="utf-8",newline="\n")
anchor=repo/"benchmarks/results/2026-11-22-demanded-jump-targets/observations.tgz"
blob=subprocess.check_output(["git","show","origin/master:"+anchor.relative_to(repo).as_posix()],cwd=repo)
assert sha(blob)==sha(anchor.read_bytes())
with tarfile.open(anchor)as a:
    suite=json.load(a.extractfile("representative.json"))
ids=["scripts.config-generated-guards.medium.bad-0.sparse-lexical",
     "scripts.annotated-rule-closures.nested-factories.postponed",
     "scripts.dataclass-inherited-configuration.generated"]
rows=[next(row for row in suite["cases"] if row["id"]==id) for id in ids]
dense=next(r for r in read(lab/"inspect-catalog.json")["cases"] if r["id"]=="compiler.generated-read-only-branches")
source=dense["source"]
fixture='{"size":384,"text":null}'
stdout="123\n"
cpython=Path("C:/Python313/python.exe")
result=subprocess.check_output([cpython,"-I","-S","-X","utf8","-c",source],encoding="utf-8",timeout=8)
assert result==stdout
row=dict(rows[0],id=dense["id"],size=384,source=source,fixtureJson=fixture,expectedOutput=stdout,
         sourceUtf8Bytes=len(source.encode()),expectedOutputUtf8Bytes=len(stdout.encode()),
         fixtureTextCodePoints=0,fixtureTextUtf8Bytes=0,sourceSha256=sha(source.encode()),
         fixtureSha256=sha(fixture.encode()),expectedOutputSha256=sha(stdout.encode()),expectedFilesSha256=None)
suite["cases"]=[*rows,row]
suite["performanceQualified"]=False
catalog=pair/"catalog.json"
write(catalog,suite)

prior=read(producer/"comparison/images.json")
expected=prior["imageFiles"]["reference"]
assert len(expected)==32 and {name:sha((reference/name).read_bytes())for name in expected}==expected
candidate=pair/"frozen-candidate"
candidate.mkdir(exist_ok=True)
core="Lokad.Lython.dll"
built=lab/"frozen-build/bin/Lokad.Lython/release_net11.0"/core
assert sha(built.read_bytes())==read(lab/"inspection-identity.json")["workerImages"]["candidate"]["inspect"][core]
for name in expected:shutil.copyfile(built if name==core else reference/name,candidate/name)
files={"reference":expected,"candidate":{**expected,core:sha(built.read_bytes())}}
assert files["reference"][core]!=files["candidate"][core]
root=Path.home()/".dotnet11"
dotnet=root/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(root),DOTNET_ROOT_X64=str(root),PATH=str(root)+os.pathsep+os.environ["PATH"])
protocol=repo/"benchmarks/cpython-worker.py"
assert sha(protocol.read_bytes())==prior["protocolSHA256"]
for role,image in (("reference",reference),("candidate",candidate)):
    assert {n:sha((image/n).read_bytes())for n in expected}==files[role]
    receipt=pair/(role+"-verify.json")
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog,
        "--dotnet",dotnet,"--python",cpython,"--python-worker",protocol,"--out",receipt],
        env=env,check=True,timeout=100)
    verification=read(receipt)
    assert verification["state"]=="Completed" and verification["caseCount"]==4 and verification["catalogSha256"]==sha(catalog.read_bytes())
patch=subprocess.check_output(["git","diff","c097d73db","d5fa8c906","--","src","tests"],cwd=repo)
(pair/"source.patch").write_bytes(patch)
write(pair/"images.json",{"reference":"c097d73db","candidate":"d5fa8c906","imageFiles":files,
                        "catalogSHA256":sha(catalog.read_bytes()),"sourcePatchSHA256":sha(patch),
                        "protocolSHA256":prior["protocolSHA256"]})
