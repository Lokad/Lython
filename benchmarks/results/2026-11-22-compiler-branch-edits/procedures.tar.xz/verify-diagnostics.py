from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
tool=lab/"diagnostics-driver"
tool.mkdir(exist_ok=True)
def read(p):return json.loads(p.read_text(encoding="utf-8"))
def write(p,s):p.write_text(s,encoding="utf-8",newline="\n")
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
inputs=read(lab/"inspect-catalog.json")
inputs["cases"] += [
    dict(id="diagnostics.if-sibling",source="""def f(flag):
    if flag:
        ready = 1
    else:
        print(ready)
    return ready
"""),
    dict(id="diagnostics.branch-add-delete",source="""def f(flag):
    if flag:
        item = 5
        del item
    return item
"""),
    dict(id="diagnostics.exception-alias",source="""def f():
    try:
        raise ValueError()
    except ValueError as error:
        pass
    return error
"""),
    dict(id="diagnostics.comprehension-target",source="""def f():
    values = [item for item in (1, 2)]
    print(item)
    item = 3
    return values
"""),
    dict(id="diagnostics.sibling-body-unavailable",source="""def f(value):
    match value:
        case 1:
            seen = 1
        case 2 if seen:
            pass
    return seen
"""),
    dict(id="diagnostics.mapping-delete-order",source="""def f(k, table):
    if k:
        target = table
        del target
        target[k] = 1
    else:
        print(target)
"""),
]
catalog=tool/"diagnostics-catalog.json"
write(catalog,json.dumps(inputs,indent=2)+"\n")
write(tool/"Program.cs","""using System.Diagnostics.CodeAnalysis;
using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;

using var input = JsonDocument.Parse(File.ReadAllBytes(args[0]));
var rows = new List<object>();
var engine = new LythonEngine();
foreach (var row in input.RootElement.GetProperty("cases").EnumerateArray())
{
    var track = new Peak();
    var source = row.GetProperty("source").GetString()!;
    using (var code = engine.Compile(source, new Budget(track.Root, track)))
    {
        rows.Add(new { id = row.GetProperty("id").GetString(), code.IsValid,
            Diagnostics = code.Diagnostics.Select(d => new { d.Code, d.Message, d.Severity, d.Span }).ToArray(),
            track.PeakBytes, RetainedBytes = track.Root.ReservedBytes });
    }
    if (track.Root.ReservedBytes != 0) throw new InvalidDataException("Compilation left a charged owner.");
}
File.WriteAllText(args[1], JsonSerializer.Serialize(new {
    CoreHash = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))),
    CatalogHash = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(args[0]))), Rows = rows
},new JsonSerializerOptions { WriteIndented = true }));

file sealed class Peak
{
    internal readonly LythonMemoryBudget Root = new();
    internal long PeakBytes { get; private set; }
    internal void Observe() => PeakBytes = Math.Max(PeakBytes, Root.ReservedBytes);
}

file sealed class Budget(ILythonMemoryBudget inner, Peak track) : ILythonMemoryScope
{
    public ILythonMemoryScope CreateScope() => new Budget(inner.CreateScope(), track);
    public bool TryReserve(long bytes, [NotNullWhen(true)] out ILythonMemoryReservation? reservation)
    {
        if (!inner.TryReserve(bytes, out var admitted)) { reservation = null; return false; }
        track.Observe();
        reservation = new Reservation(admitted, track);
        return true;
    }
    public void Dispose() => (inner as ILythonMemoryScope)?.Dispose();
}

file sealed class Reservation(ILythonMemoryReservation inner, Peak track) : ILythonMemoryReservation
{
    public long Bytes => inner.Bytes;
    public bool TryResize(long bytes)
    {
        if (!inner.TryResize(bytes)) return false;
        track.Observe();
        return true;
    }
    public void Dispose() => inner.Dispose();
}
""")
write(tool/"CompilerDiagnostics.csproj","""<Project>
  <PropertyGroup><ImportDirectoryBuildProps>false</ImportDirectoryBuildProps><ImportDirectoryBuildTargets>false</ImportDirectoryBuildTargets></PropertyGroup>
  <Import Project="Sdk.props" Sdk="Microsoft.NET.Sdk" />
  <PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net11.0</TargetFramework><ImplicitUsings>enable</ImplicitUsings><Nullable>enable</Nullable><AllowUnsafeBlocks>false</AllowUnsafeBlocks><EnableDefaultCompileItems>false</EnableDefaultCompileItems></PropertyGroup>
  <ItemGroup>
    <Compile Include="Program.cs"/>
    <Reference Include="Lokad.Lython"><HintPath>../reference/inspect/Lokad.Lython.dll</HintPath></Reference>
  </ItemGroup>
  <Import Project="Sdk.targets" Sdk="Microsoft.NET.Sdk" />
</Project>
""")
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
subprocess.run([dotnet,"build",tool/"CompilerDiagnostics.csproj","-c","Release","--no-incremental","--nologo"],
    env=env,check=True,timeout=95)
rows=[]
for role in ("reference","candidate"):
    image=tool/role
    image.mkdir(exist_ok=True)
    for p in (tool/"bin/Release/net11.0").glob("CompilerDiagnostics.*"):shutil.copyfile(p,image/p.name)
    core=lab/role/"inspect/Lokad.Lython.dll"
    shutil.copyfile(core,image/core.name)
    core_hash=read(lab/"inspection-identity.json")["workerImages"][role]["inspect"][core.name]
    assert sha(image/core.name)==sha(core)==core_hash
    out=tool/(role+".json")
    subprocess.run([dotnet,image/"CompilerDiagnostics.dll",catalog,out],env=env,check=True,timeout=45)
    proof=read(out)
    assert proof["CoreHash"]==core_hash and proof["CatalogHash"]==sha(catalog)
    rows.append(proof["Rows"])
a,b=rows
assert a==b, [r["id"]for r,s in zip(a,b,strict=True)if r!=s]
assert any(d["Code"]=="LA3146" for r in a for d in r["Diagnostics"])
print(f"{len(a)} sources have identical diagnostics and admitted peaks. Every compilation refunded its owner.")
for row in a:
    if row["id"].startswith("diagnostics."):print(row["id"],[d["Code"]for d in row["Diagnostics"]],row["PeakBytes"])
