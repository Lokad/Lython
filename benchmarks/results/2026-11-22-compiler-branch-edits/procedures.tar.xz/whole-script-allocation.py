from pathlib import Path
import hashlib
import json
import os
import statistics
import subprocess

lab = Path(__file__).resolve().parent
suite = lab / "comparison/catalog.json"
identity = json.loads((lab/"inspection-identity.json").read_text(encoding="utf-8"))
def check(role):
    folder = lab / role / "compile"
    actual = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.iterdir() if p.is_file()}
    assert actual == identity["workerImages"][role]["compile"]
    return actual["Lokad.Lython.dll"]

sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
roles = ["reference", "candidate", "candidate", "reference"]
runs = []
for i, role in enumerate(roles):
    core = check(role)
    report = lab / f"{role}-whole-script-alloc-{i}.json"
    subprocess.run([dotnet, lab / role / "compile/Lokad.Lython.WhiteBox.Tests.dll", suite, report], env=env, check=True, timeout=50)
    raw = json.loads(report.read_text(encoding="utf-8-sig"))
    assert raw["imageSHA256"] == core and raw["catalogSHA256"] == hashlib.sha256(suite.read_bytes()).hexdigest()
    runs.append(raw["rows"])
rows = []
for cases in zip(*runs, strict=True):
    assert len({row["id"] for row in cases}) == 1
    allocations = [statistics.median(s["compileBytes"] for s in row["samples"]) for row in cases]
    elapsed = [statistics.median(s["compileMicroseconds"] for s in row["samples"]) for row in cases]
    rows.append(dict(id=cases[0]["id"], allocatedBytes=allocations, elapsedDiagnosticMicroseconds=elapsed))
    print(cases[0]["id"], allocations, elapsed, flush=True)
(lab/"whole-script-allocation-summary.json").write_text(json.dumps(dict(roles=roles, rows=rows), indent=2) + "\n",encoding="utf-8",newline="\n")
