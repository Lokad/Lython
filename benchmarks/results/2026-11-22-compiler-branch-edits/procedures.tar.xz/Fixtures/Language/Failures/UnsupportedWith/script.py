with resource:
    pass
