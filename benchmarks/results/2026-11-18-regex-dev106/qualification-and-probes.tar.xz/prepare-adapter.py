from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import zipfile

lab = Path(__file__).resolve().parent
repo = Path.cwd()
work = repo/".git/agent-worktrees/native-json-encoding-options"
prior = lab.parent/"regex-native-names-r528"
project = lab/"adapter"
project.mkdir()
source = prior/"adapter/Utf8RegexProvider.cs"
shutil.copyfile(source,project/source.name)
inputs = json.loads((lab/"inputs.json").read_text(encoding="utf-8"))
sha=lambda data: hashlib.sha256(data).hexdigest()
for tfm in ("net11.0","net10.0"):
    location = lab/"binaries"/tfm
    location.mkdir(parents=True)
    for item in inputs["packages"]:
        path = lab/"feed"/item["filename"]
        assert sha(path.read_bytes())==item["packageSha256"]
        with zipfile.ZipFile(path) as package:
            data = package.read(f'lib/{tfm}/{item["id"]}.dll')
        assert sha(data)==item["targetAssemblyHashes"][tfm]
        (location/(item["id"]+".dll")).write_bytes(data)
csproj=(prior/"adapter/Adapter.csproj").read_text(encoding="utf-8")
import re
refs = {
    "Lokad.Lython": work/"src/Lokad.Lython/bin/Release/$(TargetFramework)/Lokad.Lython.dll",
    "Lokad.Utf8Regex": lab/"binaries/$(TargetFramework)/Lokad.Utf8Regex.dll",
    "Lokad.Utf8Regex.PythonRe": lab/"binaries/$(TargetFramework)/Lokad.Utf8Regex.PythonRe.dll"
}
for name,path in refs.items():
    prefix=f'<Reference Include="{name}"><HintPath>'
    rx=re.escape(prefix)+r'[^<]*'
    csproj,count=re.subn(rx,lambda _:prefix+path.as_posix(),csproj)
    assert count==1
(project/"Adapter.csproj").write_text(csproj,encoding="utf-8",newline="\n")
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),DOTNET_HOST_PATH=str(dotnet),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
with (lab/"adapter-build.log").open("w",encoding="utf-8") as log:
    subprocess.run([dotnet,"build",project/"Adapter.csproj","-c","Release","--no-incremental"],cwd=repo,env=env,
                   stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
hashes={}
for tfm in ("net11.0","net10.0"):
    image=lab/"consumers"/tfm
    shutil.copytree(work/"tests/Lokad.Lython.PublicApi.Tests/bin/Release"/tfm,image,copy_function=shutil.copyfile)
    for p in (lab/"binaries"/tfm).glob("*.dll"):
        shutil.copyfile(p,image/p.name)
    shutil.copyfile(project/"bin/Release"/tfm/"Lokad.Lython.Utf8Regex.dll",image/"Lokad.Lython.Utf8Regex.dll")
    fixture=image/"tests/Lokad.Lython.WorkerFixture/bin/Release"/tfm
    shutil.copytree(work/"tests/Lokad.Lython.WorkerFixture/bin/Release"/tfm,fixture,copy_function=shutil.copyfile)
    for name in ("Lokad.Lython.dll","Lokad.Lython.Utf8Regex.dll","Lokad.Utf8Regex.dll","Lokad.Utf8Regex.PythonRe.dll"):
        shutil.copyfile(image/name,fixture/name)
        assert (image/name).read_bytes()==(fixture/name).read_bytes()
    (image/"Directory.Build.props").write_text("<Project/>\n",encoding="utf-8",newline="\n")
    shutil.copytree(repo/"tests/Fixtures/Workflows/RegexRewrite",image/"Fixtures/Workflows/RegexRewrite",copy_function=shutil.copyfile,dirs_exist_ok=True)
    hashes[tfm]={n:sha((image/n).read_bytes()) for n in ("Lokad.Lython.dll","Lokad.Lython.Utf8Regex.dll","Lokad.Utf8Regex.dll",
                 "Lokad.Utf8Regex.PythonRe.dll","Lokad.Lython.PublicApi.Tests.dll")}
    assert hashes[tfm]["Lokad.Lython.dll"]==sha((work/"src/Lokad.Lython/bin/Release"/tfm/"Lokad.Lython.dll").read_bytes())
    for package in inputs["packages"]:
        assert hashes[tfm][package["id"]+".dll"]==package["targetAssemblyHashes"][tfm]
(lab/"image-identity.json").write_text(json.dumps(dict(images=hashes,adapterSHA256=sha(source.read_bytes()),
    parentAndChildImagesIdentical=True,normalPinUnchanged=True,coreDependenciesUnchanged=True),indent=2)+"\n",encoding="utf-8")
shutil.copyfile(prior/"qualify.py",lab/"qualify.py")
print("Built and verified the optional development adapter against both exact package target assemblies.",flush=True)
