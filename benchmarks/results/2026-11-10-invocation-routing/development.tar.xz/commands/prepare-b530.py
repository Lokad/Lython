from pathlib import Path
import json,hashlib,tarfile,subprocess,shutil
root=Path('D:/code/Lython');h=Path(__file__).parent;old=h.parent/'shared-operand-r180/b528';t=h/'tree';local=json.loads((h/'sync-completion/identity.json').read_text(encoding='utf-8'));d=h/'b530';d.mkdir()
assert all(hashlib.sha256((t/p).read_bytes()).hexdigest()==digest for p,digest in local['source'].items())
def adapt(s):return s.replace('shared-operand-b528-20261110','invocation-routing-b530-20261110').replace('lython-b528-shared-operand-20261110','lython-b530-invocation-routing-20261110').replace('lython-b528-fixtures','lython-b530-fixtures').replace('shared-operand-b528-launch','invocation-routing-b530-launch').replace('B528','B530')
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'));identity['sourceRevision']='R183 uncommitted invocation-only routing consolidation above567dd53e; synchronous bool completion preserved. Qualifiedee448715-equivalent reference, fully managed ownership/cancellation unchanged.';identity['coreSHA256']={role:local['cores']['before'if role.startswith('reference')else'candidate']for role in ['reference','reference-control','candidate','candidate-control']};identity['catalogSHA256']=local['catalogSHA256'];(d/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
for target,source in [('current-core.dll',h/'sync-completion/images/candidate/Lokad.Lython.dll'),('representative.json',h/'sync-completion/catalog.json'),('final-source.json',h/'sync-completion/identity.json'),('source.patch',h/'sync-completion/source.patch')]:shutil.copyfile(source,d/target)
baseline=json.loads((h.parent/'handler-native-entry-r179/identity.json').read_text(encoding='utf-8'));(d/'baseline-source.json').write_text(json.dumps(baseline,indent=2)+'\n',encoding='utf-8');shutil.copyfile(h.parent/'shared-operand-r180/record-comparison/golden.json',d/'golden.json')
# Preserve real original-script identity; no CSV helper-source substitution in this comparison.
(d/'golden.json').write_text(json.dumps(dict(source='Original maintained CSV/text/report/search/config catalog from B525, exact Unicode control from R179.',catalogSHA256=local['catalogSHA256'],everyInvocationVerifiedByExistingWorker=True),indent=2)+'\n',encoding='utf-8')
with tarfile.open(d/'source-checks.tar.xz','w:xz',preset=3)as a:
 for name in subprocess.check_output(['git','diff','--name-only','--','src','tests'],cwd=t,text=True).splitlines():
  after=t/name;before=root/name
  if after.exists():a.add(after,arcname='candidate/'+name)
  if before.exists():
   if name.startswith('src/Lokad.Lython/'):assert hashlib.sha256(before.read_bytes()).hexdigest()==baseline['productionSources'][before.as_posix()]
   a.add(before,arcname='before/'+name)
 for p in h.glob('*.py'):a.add(p,arcname='commands/'+p.name)
 for p in (h/'sync-completion').glob('*.log'):a.add(p,arcname='qualification/'+p.name)
jobs=[['scripts.csv-validated-records.large','warm'],['scripts.text-summary-helpers.large','warm'],['scripts.file-search.large','warm'],['scripts.report-render.large','warm'],['scripts.unicode-index-report.control','warm'],['scripts.config-edit.small','warm']]
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=adapt((old/name).read_text(encoding='utf-8'));s=s.replace('len(jobs)==5','len(jobs)==6').replace("len(r['jobs'])==5","len(r['jobs'])==6").replace("len(raw['jobs'])==5","len(raw['jobs'])==6").replace("receipt']['jobs']==5","receipt']['jobs']==6").replace('jobs=5','jobs=6').replace("['elapsedSeconds']<180","['elapsedSeconds']<210").replace('time.monotonic()-started < 180','time.monotonic()-started < 210')
 lines=[]
 for line in s.splitlines():
  if line.startswith('jobs='):line='jobs='+repr(jobs)
  if 'record = dict(sourceRevision=' in line:line="    record = dict(sourceRevision=identity['sourceRevision'], purpose='R183 common invocation-only boundary, direct synchronous completion, original complete scripts. Allocation separate. No CPython timing or performance claim from code size. All adverse data retained.',"
  lines.append(line)
 (d/name).write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n')
for name in ['setup-contract.json','sizing.json']:
 data=json.loads((old/name).read_text(encoding='utf-8'));(d/name).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
(d/'focused.json').write_text(json.dumps(dict(publicEachTarget=1381,internalPreviousSourceStackEachTarget=17,frameworks=['net11.0','net10.0'],fullDeliveryPending=True),indent=2)+'\n',encoding='utf-8')
contract='''R183 one existing controlled comparison after coherent invocation routing consolidation.
Reference qualifiedee448715 production(coreb49), candidate above567dd53e with direct
synchronous bool completion and unchanged native shortcut/ownership/cancellation.
Original whole CSV/text/search/report scripts, Unicode/config controls;6jobs,4
independent processes(two/source),5swarmup/role,7rotated150msrounds, ordinaryGC/tiering.
Includes mediated RAM I/O/full validation/prior-result cleanup; excludes compile,
startup/reset/protocol/final caches. Wider processCPU separate; allocation/compile
use the existing local diagnostic on exact frozen images. No speedup forecast.
Original desktop moving/adverse controls preserved; no unchanged profiles repeated.
Extra sixth control budgets total240sowner/30sstop/30smargin, collectguard210s;
per-worker/batch guards unchanged. Join/unmount/archive under lease, localSHA.
'''
for name in ['contract.md','pre-measurement-plan.md']:(d/name).write_text(contract,encoding='utf-8',newline='\n')
assert b'\r'not in(d/'run.sh').read_bytes()
with tarfile.open(d/'payload.tgz','w:gz')as a:
 for p in sorted(d.iterdir()):
  if p.is_file()and p.name!='payload.tgz':a.add(p,arcname=p.name)
payload=(d/'payload.tgz').read_bytes()
with tarfile.open(d/'payload.tgz')as a:required=sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+(240+12)*1024*1024+65536+256*1024
(d/'payload-sizing.json').write_text(json.dumps(dict(requiredFreeBytes=required,payloadBytes=len(payload),baselineAndAuxiliariesReused=True),indent=2)+'\n',encoding='utf-8')
s=adapt((old/'launch-command.py').read_text(encoding='utf-8')).replace('assert len(jobs)==5','assert len(jobs)==6').replace('ownerSeconds=210','ownerSeconds=240').replace('RuntimeMaxSec=210','RuntimeMaxSec=240');lines=[]
for line in s.splitlines():
 if line.startswith(' payload=sys.stdin.buffer.read('):line=' payload=sys.stdin.buffer.read('+str(len(payload))+'+1);assert len(payload)=='+str(len(payload))+' and hashlib.sha256(payload).hexdigest()=='+repr(hashlib.sha256(payload).hexdigest())
 lines.append(line)
(d/'launch-command.py').write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n')
s=adapt((old/'launch.py').read_text(encoding='utf-8')).replace('timedelta(seconds=270)','timedelta(seconds=300)').replace('ownerSeconds=210','ownerSeconds=240');(d/'launch.py').write_text(s,encoding='utf-8',newline='\n');shutil.copyfile(old/'recover-space.py',d/'recover-space.py')
# One bounded retirement of superseded remote core copies; canonical frozen bytes survive.
spec=[]
for folder,remote,member in [('2026-11-10-shared-prefix-assessment/fixed-facts','shared-operand-b528-20261110','current-core.dll'),('2026-11-10-framed-native-entry/quiet','bound-native-entry-b521-20261110','baseline-core.dll')]:
 p=root/'benchmarks/results'/folder/'observations.tgz';rel=p.relative_to(root).as_posix();assert subprocess.check_output(['git','ls-files','--',rel],cwd=root,text=True).strip()==rel
 with tarfile.open(p)as a:data=a.extractfile(member).read()
 assert hashlib.sha256(data).hexdigest()!=local['cores']['before']
 spec.append(dict(path='/home/lokad/lython-bench-checks/'+remote+'/'+member,size=len(data),sha256=hashlib.sha256(data).hexdigest(),preservedLocal=str(p),preservedMember=member,archiveSHA256=hashlib.sha256(p.read_bytes()).hexdigest(),tracked=True))
p=root/'benchmarks/results/2026-11-10-ordinary-runtime-attribution/partial-observations.tgz';rel=p.relative_to(root).as_posix();assert subprocess.check_output(['git','ls-files','--',rel],cwd=root,text=True).strip()==rel
spec.append(dict(path='/home/lokad/lython-bench-checks/ordinary-work-b529-20261110/partial-observations.tgz',size=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),preservedLocal=str(p),tracked=True))
s='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks')
'''+f'spec={spec!r}\nrequired={required}\n'+'''with (base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not (base/'invocation-routing-b530-20261110').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-*'))
 free=shutil.disk_usage(base).free
 if free>required:
  print(json.dumps(dict(skipped=True,beforeFreeBytes=free,requiredFreeBytes=required)));raise SystemExit
 rows=[]
 for entry in spec:
  p=Path(entry['path']);info=p.lstat()
  assert stat.S_ISREG(info.st_mode)and p.resolve()==p and info.st_uid==os.getuid() and info.st_gid==os.getgid()
  assert info.st_size==entry['size']and hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256']
  aliases=[]
  for current,dirs,files in os.walk(base,followlinks=False):
   dirs[:]=[n for n in dirs if not (Path(current)/n).is_symlink()]
   for name in files:
    q=Path(current)/name;meta=q.lstat()
    if (meta.st_dev,meta.st_ino)!=(info.st_dev,info.st_ino):continue
    assert stat.S_ISREG(meta.st_mode)and q.resolve()==q and meta.st_uid==os.getuid()
    assert hashlib.sha256(q.read_bytes()).hexdigest()==entry['sha256'];aliases.append(str(q))
  assert len(aliases)==info.st_nlink,(p,aliases,info.st_nlink)
  rows.append(dict(**entry,device=info.st_dev,inode=info.st_ino,links=info.st_nlink,allocatedBytes=info.st_blocks*512,allAliases=aliases))
  if free+sum(r['allocatedBytes']for r in rows)>required:break
 assert free+sum(r['allocatedBytes']for r in rows)>required,('Canonical duplicate copies cannot fund unchanged floors; no mutation',free,required)
 plan=dict(beforeFreeBytes=free,requiredFreeBytes=required,freshIdleLease=True,osFloorMiB=240,evidenceHeadroomMiB=12,files=rows,operation='Retire only exact redundant remote copies of superseded frozen cores/optional compressed archive, every alias verified. All original core/raw bytes survive in tracked immutable canonical evidence; current production baseline and active images survive.')
 with (base/'invocation-routing-b530-space-plan.json').open('x')as f:f.write(json.dumps(plan,indent=2)+chr(10));f.flush();os.fsync(f.fileno())
 for row in rows:
  for name in row['allAliases']:
   q=Path(name);info=q.lstat();assert(info.st_dev,info.st_ino)==(row['device'],row['inode'])and q.resolve()==q
   assert hashlib.sha256(q.read_bytes()).hexdigest()==row['sha256'];q.unlink()
 plan['afterFreeBytes']=shutil.disk_usage(base).free;assert plan['afterFreeBytes']>required
 (base/'invocation-routing-b530-space-receipt.json').write_text(json.dumps(plan,indent=2)+chr(10));print(json.dumps(plan))
'''
compile(s,'space-recovery-command.py','exec');(d/'space-recovery-command.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared6-job coherent comparison; requiredfree',required,'payload',len(payload),'No remote action.')
