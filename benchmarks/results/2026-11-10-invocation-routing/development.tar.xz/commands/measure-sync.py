from pathlib import Path
import json,os,subprocess,statistics
h=Path(__file__).parent;d=h/'sync-completion';env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH'];dotnet=env['DOTNET_ROOT']+'/dotnet.exe';tool=h.parent/'bulk-whitespace-r157/tool/out/complete-jobs.dll';witness=h/'diagnostic/hash-witness.json'
for phase,field in [('warm','executionMilliseconds'),('compile','elapsedMilliseconds')]:
 o=d/phase;o.mkdir()
 with(o/'measurements.json').open('w',encoding='utf-8')as out,(o/'stderr.txt').open('w',encoding='utf-8')as err:r=subprocess.run([dotnet,str(tool),str(d/'images/before/Lokad.Lython.Benchmarks.dll'),str(d/'images/candidate/Lokad.Lython.Benchmarks.dll'),str(d/'catalog.json'),str(witness),'reverse',phase,'sync'],env=env,stdout=out,stderr=err,timeout=120)
 assert r.returncode==0,(o/'stderr.txt').read_text(encoding='utf-8')[-2000:]
 raw=json.loads((o/'measurements.json').read_text(encoding='utf-8'));assert all(raw[k]for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified']);rows=[]
 for c in raw['observations']:
  roles={role:{key:statistics.median(s[f]/s['jobs']for s in c['samples']if s['image']==role)for key,f in [('bytes','allocatedBytes'),('elapsedMs',field)]}for role in ['before','before-control','candidate']}
  row=dict(case=c['caseId'],roles=roles,changes={b:{k:100*(roles['candidate'][k]/roles[b][k]-1)for k in roles[b]}for b in ['before','before-control']});rows.append(row);print(phase,row['case'],row['changes'],flush=True)
 (o/'summary.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
