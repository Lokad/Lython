from pathlib import Path
import subprocess,os
h=Path(__file__).parent;t=h/'tree';env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH'];dotnet=env['DOTNET_ROOT']+'/dotnet.exe'
for target in ['net11.0','net10.0']:
 for label,project,query in [('targets','Lokad.Lython.PublicApi.Tests','(Category!=Stress)&(FullyQualifiedName~ContextManagerSubsystemTests|FullyQualifiedName~LoweredMatchBodyTests|FullyQualifiedName~AssignmentTargetCompatibilityTests|FullyQualifiedName~DeleteLifetimeTests|FullyQualifiedName~ClassAnnotationExecutionTests|FullyQualifiedName~NativeSlice|FullyQualifiedName~GeneratorAugmentedSliceBoundaryTests)'),('stack','Lokad.Lython.Tests','FullyQualifiedName~ManagedStackGuardTests|FullyQualifiedName~ExecutableStackAdmissionTests|FullyQualifiedName~RenderingStackAdmissionTests')]:
  log=h/(label+'-'+target+'.log')
  with log.open('w',encoding='utf-8')as out:r=subprocess.run([dotnet,'test','tests/'+project+'/'+project+'.csproj','-c','Release','-f',target,'--filter',query],cwd=t,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=180)
  print(log.name,log.read_text(encoding='utf-8')[-300:],flush=True);assert r.returncode==0
