R183 one existing controlled comparison after coherent invocation routing consolidation.
Reference qualifiedee448715 production(coreb49), candidate above567dd53e with direct
synchronous bool completion and unchanged native shortcut/ownership/cancellation.
Original whole CSV/text/search/report scripts, Unicode/config controls;6jobs,4
independent processes(two/source),5swarmup/role,7rotated150msrounds, ordinaryGC/tiering.
Includes mediated RAM I/O/full validation/prior-result cleanup; excludes compile,
startup/reset/protocol/final caches. Wider processCPU separate; allocation/compile
use the existing local diagnostic on exact frozen images. No speedup forecast.
Original desktop moving/adverse controls preserved; no unchanged profiles repeated.
Extra sixth control budgets total240sowner/30sstop/30smargin, collectguard210s;
per-worker/batch guards unchanged. Join/unmount/archive under lease, localSHA.
