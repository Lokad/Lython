from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks')
spec=[{'path': '/home/lokad/lython-bench-checks/shared-operand-b528-20261110/current-core.dll', 'size': 5650944, 'sha256': 'c39dcffc77c9336ae21a1a1578dd460b8e3930ccb2cc5c88c2c91f7f33cc5642', 'preservedLocal': 'D:\\code\\Lython\\benchmarks\\results\\2026-11-10-shared-prefix-assessment\\fixed-facts\\observations.tgz', 'preservedMember': 'current-core.dll', 'archiveSHA256': '0095337e44ac698f6ff5ea0b0cb74964ee9540d1bedec901f1ba3ee500783507', 'tracked': True}, {'path': '/home/lokad/lython-bench-checks/bound-native-entry-b521-20261110/baseline-core.dll', 'size': 5655552, 'sha256': 'e833f03ce220fe7569b6cc2db89bb3a93504773b3b5e33a9e1b92a4d4d4c55ba', 'preservedLocal': 'D:\\code\\Lython\\benchmarks\\results\\2026-11-10-framed-native-entry\\quiet\\observations.tgz', 'preservedMember': 'baseline-core.dll', 'archiveSHA256': '82b084b6b0a815eca609fc21a4fc4124c0eacf4d596910218f08118b855714a0', 'tracked': True}, {'path': '/home/lokad/lython-bench-checks/ordinary-work-b529-20261110/partial-observations.tgz', 'size': 2156969, 'sha256': 'a9ab7985d95b04ff48344ee00e2056f2ab2c7df6837a3f311c0e2fa9195c6790', 'preservedLocal': 'D:\\code\\Lython\\benchmarks\\results\\2026-11-10-ordinary-runtime-attribution\\partial-observations.tgz', 'tracked': True}]
required=271159296
with (base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not (base/'invocation-routing-b530-20261110').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-*'))
 free=shutil.disk_usage(base).free
 if free>required:
  print(json.dumps(dict(skipped=True,beforeFreeBytes=free,requiredFreeBytes=required)));raise SystemExit
 rows=[]
 for entry in spec:
  p=Path(entry['path']);info=p.lstat()
  assert stat.S_ISREG(info.st_mode)and p.resolve()==p and info.st_uid==os.getuid() and info.st_gid==os.getgid()
  assert info.st_size==entry['size']and hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256']
  aliases=[]
  for current,dirs,files in os.walk(base,followlinks=False):
   dirs[:]=[n for n in dirs if not (Path(current)/n).is_symlink()]
   for name in files:
    q=Path(current)/name;meta=q.lstat()
    if (meta.st_dev,meta.st_ino)!=(info.st_dev,info.st_ino):continue
    assert stat.S_ISREG(meta.st_mode)and q.resolve()==q and meta.st_uid==os.getuid()
    assert hashlib.sha256(q.read_bytes()).hexdigest()==entry['sha256'];aliases.append(str(q))
  assert len(aliases)==info.st_nlink,(p,aliases,info.st_nlink)
  rows.append(dict(**entry,device=info.st_dev,inode=info.st_ino,links=info.st_nlink,allocatedBytes=info.st_blocks*512,allAliases=aliases))
  if free+sum(r['allocatedBytes']for r in rows)>required:break
 assert free+sum(r['allocatedBytes']for r in rows)>required,('Canonical duplicate copies cannot fund unchanged floors; no mutation',free,required)
 plan=dict(beforeFreeBytes=free,requiredFreeBytes=required,freshIdleLease=True,osFloorMiB=240,evidenceHeadroomMiB=12,files=rows,operation='Retire only exact redundant remote copies of superseded frozen cores/optional compressed archive, every alias verified. All original core/raw bytes survive in tracked immutable canonical evidence; current production baseline and active images survive.')
 with (base/'invocation-routing-b530-space-plan.json').open('x')as f:f.write(json.dumps(plan,indent=2)+chr(10));f.flush();os.fsync(f.fileno())
 for row in rows:
  for name in row['allAliases']:
   q=Path(name);info=q.lstat();assert(info.st_dev,info.st_ino)==(row['device'],row['inode'])and q.resolve()==q
   assert hashlib.sha256(q.read_bytes()).hexdigest()==row['sha256'];q.unlink()
 plan['afterFreeBytes']=shutil.disk_usage(base).free;assert plan['afterFreeBytes']>required
 (base/'invocation-routing-b530-space-receipt.json').write_text(json.dumps(plan,indent=2)+chr(10));print(json.dumps(plan))
