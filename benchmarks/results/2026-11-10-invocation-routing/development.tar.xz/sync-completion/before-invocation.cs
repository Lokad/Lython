using Lokad.Lython.Frontend;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal sealed partial class ExecutionContext
    {
        // These operations already require an invocation. Keep their original
        // handlers and share one completion/suspension transition in the prefix;
        // native operations still execute before requesting this context.
        private ValueTask<bool> ExecuteInvocationInstruction(in ExecutableInstruction instruction, bool asynchronous)
        {
            switch (instruction.OpCode)
            {
                case ExecutableOpCode.StoreMember or ExecutableOpCode.StoreMemberLast
                    or ExecutableOpCode.StoreSlice or ExecutableOpCode.StoreSliceLast
                    or ExecutableOpCode.ReadRetainedSubscript or ExecutableOpCode.ReadRetainedSlice
                    or ExecutableOpCode.UnpackValues or ExecutableOpCode.FailAssertion or ExecutableOpCode.Raise
                    or ExecutableOpCode.DeleteName or ExecutableOpCode.DeleteMember
                    or ExecutableOpCode.DeleteSubscript or ExecutableOpCode.DeleteSlice:
                    return WithoutJump(ExecuteTargetInstruction(instruction, asynchronous));
                case ExecutableOpCode.ApplyOperation:
                    return WithoutJump(ExecutePreparedOperationAsync(instruction, asynchronous));
                case ExecutableOpCode.StartFormattedString or ExecutableOpCode.AppendFormattedText
                    or ExecutableOpCode.FinishFormattedString or ExecutableOpCode.ConvertFormattedValue or ExecutableOpCode.FormatField:
                    return WithoutJump(ExecuteFormattedValueAsync(instruction, asynchronous));
                case ExecutableOpCode.Import or ExecutableOpCode.DefineFunction or ExecutableOpCode.ExecuteFallbackStatement:
                    if (asynchronous) return WithoutJump(ExecuteDefinitionOrFallbackAsync(instruction));
                    ExecuteDefinitionOrFallback(instruction);
                    return new(false);
                case ExecutableOpCode.MakeSet or ExecutableOpCode.MakeDict or ExecutableOpCode.MatchCase:
                    return new(ExecuteStructure(instruction));
                case ExecutableOpCode.ResolveContextManager or ExecutableOpCode.EnterContextManager or ExecutableOpCode.ExitContextManager:
                    return asynchronous ? ExecuteContextManagerAsync(instruction) : new(ExecuteStructure(instruction));
                case ExecutableOpCode.ForNext:
                    return asynchronous ? ExecuteForNextAsync(instruction) : new(ExecuteForNext(instruction));
                case ExecutableOpCode.GetIter or ExecutableOpCode.Slice or ExecutableOpCode.MakeSlice:
                    if (!asynchronous || instruction.OpCode == ExecutableOpCode.MakeSlice)
                    {
                        ExecuteValueOperation(instruction);
                        return new(false);
                    }
                    return WithoutJump(instruction.OpCode == ExecutableOpCode.GetIter
                        ? ExecuteGetIteratorAsync(instruction) : ExecuteSliceValueOperationAsync(instruction));
                default:
                    throw new InvalidOperationException($"Unexpected invocation instruction: {instruction.OpCode}");
            }
        }
    }
}
