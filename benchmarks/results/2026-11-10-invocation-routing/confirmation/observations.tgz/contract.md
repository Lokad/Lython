R183 unchanged-source control confirmation after B530 Unicode/report adversity.
Three existing jobs: Unicode/report/text, four independent processes(two/source),
5srole warmup and7rotated400msrounds. Larger batches reduce100Hztickquantization;
per-worker/frame guards unchanged. OrdinaryGC/tiering, original frozen core858c4ac9
versus qualifiedcoreb49. Same catalog/source/auxiliaries/goldens; keep all adversity.
No new attribution/CPython lane/framework or universal speedup claim. Warm boundary
includes mediated RAM I/O/output validation/prior-result cleanup; reset/protocol/
compile/startup/final caches excluded. WiderCPU separate.180sowner/30sstop/30smargin,
150scollectionguard, join/unmount/archive/localSHA. Decide retention/debt afterward;
do not repeat unchanged confirmation unless a concrete setup defect invalidates it.
