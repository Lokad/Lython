from pathlib import Path
import hashlib,json,tarfile,subprocess,shutil
h=Path(__file__).parent;old=h/'b530';d=h/'b531';d.mkdir()
def adapt(s):return s.replace('invocation-routing-b530-20261110','invocation-controls-b531-20261110').replace('lython-b530-invocation-routing-20261110','lython-b531-invocation-controls-20261110').replace('lython-b530-fixtures','lython-b531-fixtures').replace('invocation-routing-b530-launch','invocation-controls-b531-launch').replace('B530','B531')
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'));identity['sourceRevision']+='; unchanged frozen images, bounded larger-batch confirmation of adverse Unicode/report and text control.';(d/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
jobs=[['scripts.unicode-index-report.control','warm'],['scripts.report-render.large','warm'],['scripts.text-summary-helpers.large','warm']]
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=adapt((old/name).read_text(encoding='utf-8')).replace('len(jobs)==6','len(jobs)==3').replace("len(r['jobs'])==6","len(r['jobs'])==3").replace("len(raw['jobs'])==6","len(raw['jobs'])==3").replace("receipt']['jobs']==6","receipt']['jobs']==3").replace('jobs=6','jobs=3').replace("['elapsedSeconds']<210","['elapsedSeconds']<150").replace('time.monotonic()-started < 210','time.monotonic()-started < 150').replace('targetBatchSeconds=.15','targetBatchSeconds=.4').replace('count*.15','count*.4')
 lines=[]
 for line in s.splitlines():
  if line.startswith('jobs='):line='jobs='+repr(jobs)
  if 'record = dict(sourceRevision='in line:line="    record = dict(sourceRevision=identity['sourceRevision'], purpose='Unchanged R183 source; confirm adverse Unicode/report with text control using400msbatches to reduce100HzCPUquantization. Preserve all B530 evidence, no new gain forecast.',"
  lines.append(line)
 (d/name).write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n')
(d/'setup-contract.json').write_text(json.dumps(dict(jobs=3,roles=4,ownerSeconds=180,stopSeconds=30,marginSeconds=30,osFreeFloorMiB=240,evidenceHeadroomMiB=12,referenceReuse='/home/lokad/lython-bench-checks/handler-native-entry-b522-20261110/current-core.dll',frozenImagesReusedFrom='invocation-routing-b530-20261110',protocolSHA256='02ca606af6b937a5bec8da744da36e6dbea45ef14ee7207732f34da052ad32f1'),indent=2)+'\n',encoding='utf-8')
(d/'sizing.json').write_text(json.dumps(dict(jobs=3,expectedSeconds=105,maximumOwnerSeconds=180,cleanupReserveSeconds=30),indent=2)+'\n',encoding='utf-8')
contract='''R183 unchanged-source control confirmation after B530 Unicode/report adversity.
Three existing jobs: Unicode/report/text, four independent processes(two/source),
5srole warmup and7rotated400msrounds. Larger batches reduce100Hztickquantization;
per-worker/frame guards unchanged. OrdinaryGC/tiering, original frozen core858c4ac9
versus qualifiedcoreb49. Same catalog/source/auxiliaries/goldens; keep all adversity.
No new attribution/CPython lane/framework or universal speedup claim. Warm boundary
includes mediated RAM I/O/output validation/prior-result cleanup; reset/protocol/
compile/startup/final caches excluded. WiderCPU separate.180sowner/30sstop/30smargin,
150scollectionguard, join/unmount/archive/localSHA. Decide retention/debt afterward;
do not repeat unchanged confirmation unless a concrete setup defect invalidates it.
'''
for name in ['contract.md','pre-measurement-plan.md']:(d/name).write_text(contract,encoding='utf-8',newline='\n')
assert b'\r'not in(d/'run.sh').read_bytes()
with tarfile.open(d/'payload.tgz','w:gz')as a:
 for p in sorted(d.iterdir()):
  if p.is_file()and p.name!='payload.tgz':a.add(p,arcname=p.name)
payload=(d/'payload.tgz').read_bytes()
with tarfile.open(d/'payload.tgz')as a:required=sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+(240+12)*1024*1024+65536+256*1024
(d/'payload-sizing.json').write_text(json.dumps(dict(requiredFreeBytes=required,payloadBytes=len(payload),allFrozenImagesAndSourcesReused=True),indent=2)+'\n',encoding='utf-8')
s=adapt((old/'launch-command.py').read_text(encoding='utf-8')).replace("reference=base/'handler-native-entry-b522-20261110/candidate'","reference=base/'invocation-routing-b530-20261110/candidate'").replace('assert len(jobs)==6','assert len(jobs)==3').replace('ownerSeconds=240','ownerSeconds=180').replace('RuntimeMaxSec=240','RuntimeMaxSec=180')
anchor=" previous=base/'shared-comparison-b514-20261109'";assert s.count(anchor)==1;s=s.replace(anchor," for name in ['current-core.dll','representative.json','final-source.json','source.patch','source-checks.tar.xz','golden.json','focused.json','baseline-source.json']:os.link(base/'invocation-routing-b530-20261110'/name,root/name)\n"+anchor)
lines=[]
for line in s.splitlines():
 if line.startswith(' payload=sys.stdin.buffer.read('):line=' payload=sys.stdin.buffer.read('+str(len(payload))+'+1);assert len(payload)=='+str(len(payload))+' and hashlib.sha256(payload).hexdigest()=='+repr(hashlib.sha256(payload).hexdigest())
 lines.append(line)
(d/'launch-command.py').write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n')
s=adapt((old/'launch.py').read_text(encoding='utf-8')).replace('timedelta(seconds=300)','timedelta(seconds=240)').replace('ownerSeconds=240','ownerSeconds=180');(d/'launch.py').write_text(s,encoding='utf-8',newline='\n');shutil.copyfile(old/'recover-space.py',d/'recover-space.py')
root=Path('D:/code/Lython');p=root/'benchmarks/results/2026-11-10-invocation-routing/observations.tgz';rel=p.relative_to(root).as_posix();assert subprocess.check_output(['git','ls-files','--',rel],cwd=root,text=True).strip()==rel
spec=[dict(path='/home/lokad/lython-bench-checks/invocation-routing-b530-20261110/observations.tgz',size=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),preservedLocal=str(p),tracked=True)]
# Reuse the simple exact-archive retirement checker; do not inspect known-retired cores again.
oldRecovery=h.parent/'shared-operand-r180/b527';s=(oldRecovery/'space-recovery-command.py').read_text(encoding='utf-8').replace('text-proof-b527-20261110','invocation-controls-b531-20261110').replace('text-proof-b527','invocation-controls-b531').replace(str(json.loads((oldRecovery/'payload-sizing.json').read_text(encoding='utf-8'))['requiredFreeBytes']),str(required));s='\n'.join('spec='+repr(spec)if line.startswith('spec=')else line for line in s.splitlines())+'\n';(d/'space-recovery-command.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared unchanged three-case400msconfirmation, requiredfree',required,'payload',len(payload))
