set -eu
root=/home/lokad/lython-bench-checks/invoice-current-b665-20261113
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
