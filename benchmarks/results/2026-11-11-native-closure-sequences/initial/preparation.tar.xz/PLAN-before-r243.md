# Lokad.Lython 0.11.0

Updated 2026-11-11. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial whole-script improvements,
including compile-to-result. Finishing one experiment does not complete it.

## Delivery and evidence

| State | Actual outcome / remaining uncertainty |
| --- | --- |
| Fully qualified runtime b5849b04; documentation HEAD30b03de0 | GREEN43033830025: Windows/Ubuntu, actual .NET11/10, originalStress and installed Release consumers. Terminal cached; never query again. Ancestorfe43024046530 also cached. |
| Shared compiler facts | Corrected exponential traversal/nonlocal diagnostics and reused scope/binding facts. Fully qualified; no CPU claim. |
| Direct UTF-8 formatting/storage | Fully qualified. Allocation−8.67%; controlled elapsed/CPU5–8% lower. Original adverse15.125ms remains unexplained and preserved; no unchanged qualification replay. |
| Native helper returns | Fully qualified. Allocation−19.92%sync/−19.31%async is established separately from diagnostic elapsed. R2398314c02d fixes real double refund during cleanup/reentry on both APIs; included in b584 delivery. |
| R237 complete native counting loops | Qualifiedfe, included in b584. Quiet captured sync elapsed9–11% lower; other text shapes/APIs improve with wider controls. Allocation flat. [Evidence](benchmarks/results/2026-11-11-native-counting-loops/README.md). |
| R240 private integer segments | Qualifiedb584. Allocation−9.04%captured/−9.7%ordinary on both APIs. Ordinary-sync direction repeats; captured/async uncertain. Report+0.65..+3.40% does not recur with fresh processes; cause unknown. [All adversity/decision](benchmarks/results/2026-11-11-private-counter-segments/README.md). |
| CPython checkpoint | Qualifiedfe/frozenbf93 vs CPython3.13.16. Warm ordinary text1.21–1.22x, captured2.24–2.27x, CSV1.06–1.08x. Compile and compile-to-result separate. [Current guide](docs/BENCHMARKS.md), [raw9jobs](benchmarks/results/2026-11-11-native-loops-cpython-checkpoint/README.md). These are fe measurements, not current HEAD ratios. |
| Committed/pushed R2415f9059fa | Every compiled function binds final workspace; mirrored namespaces preserved, second array/copy and selection branches removed. 4744focused actual11/10 checks pass. Local-record CSV allocation−4.92%bothAPIs; quiet affectedsync−5.37..−0.83%/async−4.14..−0.95%, original desktop+8% does not recur/cause unknown. OrdinaryCSVcontrol+0.97..+2.83% remains debt. Full43042632656 underway separately. [Evidence](benchmarks/results/2026-11-11-mirrored-function-storage/README.md). |

Completed invocation setup/async worker reuse, direct calls/receiver entry, shared
CSV keys/adopted rows, lexical writes, returned iteration, canonical construction,
bulk UTF-8/JSON and regex coordinates remain delivered. Full history is archived
outside docs: `.git/agent-notes/review-20261031/mirrored-call-storage-r241/PLAN-before-r241.md`
and [EXPERIMENTS](benchmarks/EXPERIMENTS.md). Do not repeat unchanged qualification.

Debt: historical15f/4aa ordinary-text async+1.92..+2.55%; R237 capturedCSV async
control−1.76..+2.74%; R240 report controls inconclusive. Reassess material debt at
a coherent checkpoint before publication. RSS, pending-I/O performance and
embedding tail latency remain unqualified; no universal CPU/neutrality claim.

R241 is retained: displaced branches/second allocation are removed. Actual
mirrors and contexts remain; namespaces never borrow reusable backing. Final
capacity admits earlier and larger idle capacity stays charged until cleanup.
Focused ownership, cancellation and both-target semantics pass. All source pairs,
cores and adversity are archived; full43042632656 remains separate and pending.

## P1 — select and implement the next whole phase

The remaining captured-text gap is material. R238 currentfe profile has1151guest
leaves/5.8CPU seconds: native loop12.25%, dispatch11.38%, preparation7.91%,
MoveNext4.00%; useful/inlined work overlaps, not removable percentages.
[Profile/source gate](benchmarks/results/2026-11-11-native-word-costs/README.md).

1. **Active source gate — complete compiled-call preparation.** R241 gives one
   array, but completed binding/presence/owner state still transfers into a
   separately constructed executable work state, with multiple cleanup paths.
   Assess binding directly into that existing state; identify state/code removed,
   not another carrier/arena/controller/span ABI. Common captured helpers already
   defer contexts/reuse arrays. Preserve real builtin omission bits and genuinely
   suspending defaults; one owner survives binding/body/awaited cleanup/first
   refusal. Stop/refine if another dispatch or ownership model is required. Use
   current profiling only where existing evidence cannot select the complete phase,
   then one whole-script pair with unchanged controls and compilation separate.
   Gate refinement: completed binding is a transient descriptor, not another
   backing allocation after R241. Merging it blindly would move presence/default
   and control-storage admission across real suspension/error boundaries without
   a demonstrated dominant cost. B582 now captures current retained captured/
   ordinary text CPU for6s each, using the existing worker/profiler and pinned
   f702 core; full source/leaf/unknown evidence, no elapsed comparison or new
   framework. One finite120sowner, archive under lease and join all users. Select
   the complete phase from that evidence before implementation.
2. Native word source gate: maintained text fixtures have3072lines/6144words,
   four keys and maxword5bytes; all words already inline. Last-word identity still
   needs a shell per line; adding a cursor scratch array would replace almost as
   many objects as it removes. No raw-word prototype selected for these workloads,
   no timing rejection/permanent veto. Detailed gate outside docs:
   `.git/agent-notes/review-20261031/mirrored-call-storage-r241/next-phase-source-gate.md`.
   Assess remaining per-record phases only on demonstrated workload costs.
   A constant worst-case word estimate can overcharge long words/spaceruns64x;
   it is not an acceptable streaming substitute. Shared CSV keys/adopted rows
   already exist. Preserve retention, duplicate/order/header mutation and reentry.
3. Operand/scalar representation and frontend work require current measured
   evidence of complete duplicated work, exact promotion/identity/projection,
   annotations/generators/executable imports. Compilation does not explain the
   captured warm gap. Do not presume remaining per-character/token conversions.

For each selected redesign: hypothesis, removed work/storage and displaced code,
representative script, semantic/cancellation/ownership acceptance, one bounded
before/after with unchanged controls and compilation separate, completion and
regression-debt decision. A justified temporary regression needs a named delivery
milestone. Stop an investigation after the source/lifetime gate and a usable
bounded observation, or a concrete unresolved dependency; choose/refine next work.

Selective reconsideration is allowed. Bulk CSV’s earlier6–8% result led to shared
keys/adopted storage; inspect any *remaining* relevant phase before reopening.
Slower call arenas/controllers, R235 partial banks, R236 broad canonical-span
staging and R230 range wrappers are removed; preserve lessons and adverse data.
Timeouts, unstable controls and inconclusive data establish uncertainty, not a
failed design. Allow bounded confirmation/refinement/correction with evidence;
retain original failed conditions. No one-attempt/no-retiming/permanent veto rules.

## Independent regex track

Core-owned Python/native-UTF-8 contract, byte/scalar ranges, original windows,
effective flags, current tokens, ownership/cache semantics are delivered. Continue
independently with adapter-local bridges or pinned immutable development producers.
Normal optional nonpackable adapter0.4; immutabledev68/a7e985ed qualified86internal/
532public per target, unchanged Validate bridge/29normal files; reuse this proof.
Only affected **final adapter qualification** awaits: independent single-match
working/result owners; native UTF-8 group-name enumeration (lookup exists);
token-independent cursor creation with cancellable preparation (per-move alone
insufficient). Remove displaced conversions/DetailedData when supported. No
publication polling. Contract tests, backend semantics/CPU/safety/SizeOf are
separate claims. Missing published capabilities never stop independent development.

## Lasting contracts and delivery

Fully managed/safe; no unsafe/Unsafe/pointers/PInvoke/native probing. Preserve
managed stack admission, host capabilities, cancellation, cycles/XML depth,
checked representation bounds/bounded I/O. No fuel/quotas/independent caps/hidden
allowance, tracing/root inventories/weak reclamation/forcedGC/retries/background
users. Borrowed allowance funds capacity/overlap/results/aliases/caches/pending
users until awaited cleanup. First refusal fails command with original structured
origin despite suppression/finally returns; guest MemoryError remains catchable.
Long streams use bounded host commands. Preserve LythonPathRequest/Cwd/component
resolution and destination on refused copy; never delete-before-copy/replacement.

Focused Release correctness/cancellation/ownership during iteration. Batch full
Windows/Ubuntu actual11/10, originalStress and installed consumers at delivery.
No timeout/assertion relaxation. Process-wide GC tests use existing collections.
CPython remains primary external baseline; include warm I/O/checks/prior-result
cleanup explicitly, separate compilation/startup/final teardown. Preserve raw
adversity outside concise current docs. Existing VM needs fresh lease/identity/
disk proof before staging; persistent evidence separate from RAM fixtures, verify
archives and join every user before releasing lease. B576–B581 terminal/cached; VMfree266821632B, new staging needs fresh disk proof. Full43042632656 pending; check no more often than every5minutes, cache terminal result.
