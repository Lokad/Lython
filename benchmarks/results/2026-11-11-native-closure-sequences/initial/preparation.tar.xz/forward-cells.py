from pathlib import Path
import re
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeReturn.cs');s=p.read_text(encoding='utf-8')
names=['TryExecuteNativeReturn','TryExecuteNativeFunction','GuardNativeBody','ExecuteNativeBody','TryReadNativeInput','GuardNativeReturn','GuardNativeFormattedValue','TryReadNativeFormattedValue','EvaluateNativeReturn','TryReadNativeOperand']
edits=[];declarations=0;calls=0
for m in re.finditer(r'\b('+'|'.join(names)+r')\(',s):
 start=m.end();i=start;depth=1
 while depth:
  if s[i]=='(':depth+=1
  elif s[i]==')':depth-=1
  i+=1
 declaration=bool(re.search(r'\b(?:internal|private) static\s+[\w?<>]+\s+$',s[:m.start()]))
 edits.append((i-1,', IReadOnlyList<ExecutableCell>? closureCells = null'if declaration else', closureCells: closureCells'))
 declarations+=declaration;calls+=not declaration
assert declarations==len(names),(declarations,calls)
for position,text in reversed(edits):s=s[:position]+text+s[position:]
p.write_text(s,encoding='utf-8')
print('Forwarded actual function cells through',declarations,'existing native entry/proof/evaluation methods and',calls,'calls; no ambient execution state or new carrier.')
