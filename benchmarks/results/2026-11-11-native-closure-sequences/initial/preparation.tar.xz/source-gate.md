# Native captured-helper sequence — R243

Source gate on retained5f9059fa / documentationc5047d21. No prototype yet.
R242 B582 reuses the exact frozenf702 executable code. Captured1168guest CPU
leaves/5.89CPU seconds vs ordinary1140/5.74; unknown52/64. Named captured binding,
BeginPendingCall/BeginBoundCall and CreateExecutableWorkState remain visible;
ordinary helpers use existing native-body evaluation. Profiles are not source-pair
timings, allocation attribution or additive removable CPU percentages.

The current representative captured helper increments a nonlocal counter, then
returns line.lower().split(). It already defers lexical contexts but must rent/
bind a full workspace and enter shared VM dispatch. Native-body preparation rejects
all incoming closures and has no store/continuation operation. Existing captured
cell StoreThroughOwner is the correct semantic write, including persistent mirrors.

Hypothesis: reuse the existing bounded native-body proof/evaluator for incoming
cell reads and closed store/continuation sequences. Execute the complete helper
using existing borrowed/inline argument entry; remove binding/work-state/VM stages
from proven invocations. No new carrier, arena, controller, owner, route or option.
Ordinary executable code remains the pre-effect path for invalid proofs, unbound
cells, protocols, unsafe namespace targets or effects followed by mutable reads.
Guard the complete body before any effects; never restart after native work.

Prepare Read nodes for LoadClosure, pass the actual function-owned incoming cells
through existing native helpers, and represent StoreClosure plus its continuation
in the existing operation tree. Reuse canonical augmented arithmetic via ordinary
binary semantics only after exact builtin shape guards. Preserve native depth16;
do not lift stack admission or change arbitrary guest syntax limits. Real namespace
writes, incoming aliases and owner lifetimes remain unchanged. Block later mutable
global/closure reads after admission/effects rather than speculate across callbacks.

Acceptance: original captured-text script and five unchanged whole-script controls,
both APIs and compilation separate; ordinary/expanded/named/default/receiver calls;
live cell mutation/deletion, handler clearing, dynamic protocol fallback exactly
once, scalar promotion, original spans/errors/exception context, retained aliases,
refusal after an earlier store with no replay, true pending cancellation and joined
cleanup, conservative cache funding and baseline after command cleanup. Verify
actual prepared shape and independent Python outputs before timing. No speed
forecast. One bounded source pair and justified quiet comparison; preserve adverse
controls and original conditions, refine on evidence rather than fixed% thresholds.

Tradeoff: eligible compiled metadata can grow by a bounded sequence node per native
store; compilation and unchanged native controls must be measured. If this requires
another execution framework, speculative mutable snapshots or duplicated ownership,
stop/refine before expanding. Pending producer APIs do not affect this work.
