from pathlib import Path
import hashlib,json,re,subprocess,sys
r=Path(__file__).resolve().parent
source=Path('tests/Lokad.Lython.PublicApi.Tests/NativeReturnFunctionTests.cs').read_text(encoding='utf-8')
cases=[]
pattern=r'^\s*\{\s*("(?:\\.|[^"\\])*"),\s*("(?:\\.|[^"\\])*"),\s*("(?:\\.|[^"\\])*")\s*\},'
for match in re.finditer(pattern,source,re.M):
 name,program,golden=map(json.loads,match.groups())
 if name not in {'captured-sequence-text','captured-sequence-protocol-once','captured-live-read-delete',
   'captured-sequence-error-context','captured-sequence-later-read','captured-sequence-promotion'}:continue
 done=subprocess.run([sys.executable,'-X','utf8','-I','-c',program],capture_output=True,timeout=10)
 assert done.returncode==0,(name,done.stderr.decode())
 output=done.stdout.decode().replace('\r\n','\n');assert output==golden,(name,output,golden)
 cases.append(dict(name=name,source=program,sha256=hashlib.sha256(program.encode()).hexdigest(),output=output))
assert len(cases)==6,len(cases)
(r/'python-goldens.json').write_text(json.dumps(dict(reference=subprocess.check_output([sys.executable,'--version'],text=True).strip(),cases=cases),indent=2)+'\n',encoding='utf-8')
print('Six new closure/sequence semantic goldens independently match isolated CPython; no timing claim.')
