from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent;repo=Path.cwd();prior=r.parent/'mirrored-call-storage-r241'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip().startswith('c5047d21')
targets=['Frontend/ExecutableScript.NativeReturns.cs','Frontend/ExecutableNativeBody.cs','Runtime/LythonRuntime.Executable.NativeReturn.cs','Runtime/PyExecutableFunction.cs','Runtime/LythonRuntime.Executable.Calls.cs','Runtime/LythonRuntime.Evaluation.Assignments.cs']
for target in targets:
 name='src/Lokad.Lython/'+target;p=r/'originals'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(name,p)
for role in ['before','candidate']:
 shutil.copytree(prior/'images/candidate',r/'images'/role)
 shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'images'/role/'Lokad.Lython.dll')
shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net10.0/Lokad.Lython.dll',r/'before-net10.dll')
shutil.copyfile(prior/'catalog.json',r/'catalog.json')
for phase in ['warm-sync','warm-async','compile']:
 (r/phase).mkdir();shutil.copyfile(prior/phase/'hash-witness.json',r/phase/'hash-witness.json')
data=dict(head='c5047d21',runtimeSource='5f9059fa',qualification='4744focused actual11/10 R241 checks; full43042632656 in progress separately. Fresh nonincremental both-target baseline cores, not replaying unchanged qualification.',
 sourceHashes={p.relative_to(repo).as_posix():sha(p)for p in(repo/'src/Lokad.Lython').rglob('*.cs')if not {'bin','obj'}&set(p.parts)},
 images={role:{p.name:sha(p)for p in(r/'images'/role).iterdir()if p.is_file()}for role in ['before','candidate']},net10SHA256=sha(r/'before-net10.dll'),
 hypothesis='Extend existing bounded native-body proof/evaluator to incoming-cell reads and closed StoreClosure/continuation sequences. Original captured-text counter helper omits binding/work-state/VM phase, keeping original cell writes, source spans, dynamic pre-effect guards and borrowed argument ownership. No new framework/route/carrier/owner/options.',
 controls='Original captured-text helper beneficiary; five existing complete scripts unchanged, both APIs and compilation separate. Preserve all allocations, adverse clocks and uncertainty. No speed forecast or rigid threshold.')
assert not(r/'before.json').exists()
(r/'before.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print('Fresh retained5f source/cores frozen on both targets before R243 production edits.')
