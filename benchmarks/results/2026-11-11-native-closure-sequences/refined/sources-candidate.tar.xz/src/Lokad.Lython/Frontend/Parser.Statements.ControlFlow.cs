
namespace Lokad.Lython.Frontend;

internal sealed partial class Parser
{
    private StatementSyntax? ParseReturnStatement()
    {
        var returnToken = ReadToken();
        if (CurrentToken is Token.Eol or Token.Semicolon or Token.Dedent or Token.End)
        {
            return new ReturnStatementSyntax(null, SpanOf(returnToken));
        }

        var expression = ParseExpressionList();
        if (expression is null)
        {
            AddDiagnostic("LA1036", "Expected expression after 'return'.", returnToken);
            return null;
        }

        return new ReturnStatementSyntax(expression, Merge(SpanOf(returnToken), expression.Span));
    }

    private StatementSyntax? ParseRaiseStatement()
    {
        var raiseToken = ReadToken();
        if (CurrentToken is Token.Eol or Token.Semicolon or Token.Dedent or Token.End)
        {
            return new RaiseStatementSyntax(null, null, SpanOf(raiseToken));
        }

        var expression = ParseExpression();
        if (expression is null)
        {
            AddDiagnostic("LA1042", "Expected expression after 'raise'.", raiseToken);
            return null;
        }

        ExpressionSyntax? causeExpression = null;
        var causeSpan = expression.Span;
        if (CurrentToken == Token.From)
        {
            ReadToken();
            causeExpression = ParseExpression();
            if (causeExpression is null)
            {
                AddDiagnostic("LA1076", "Expected exception cause after 'from'.", raiseToken);
                return null;
            }

            causeSpan = causeExpression.Span;
        }

        return new RaiseStatementSyntax(expression, causeExpression, Merge(SpanOf(raiseToken), causeSpan));
    }

    private StatementSyntax? ParseAssertStatement()
    {
        var assertToken = ReadToken();
        var condition = ParseExpression();
        if (condition is null)
        {
            AddDiagnostic("LA1056", "Expected expression after 'assert'.", assertToken);
            return null;
        }

        ExpressionSyntax? message = null;
        if (CurrentToken == Token.Comma)
        {
            ReadToken();
            message = ParseExpression();
            if (message is null)
            {
                AddDiagnostic("LA1057", "Expected expression after ',' in assert statement.", _position);
                return null;
            }
        }

        return new AssertStatementSyntax(
            condition,
            message,
            Merge(SpanOf(assertToken), (message ?? condition).Span));
    }

    private StatementSyntax? ParseDeleteStatement()
    {
        var delToken = ReadToken();
        var target = ParsePostfixExpression();
        if (target is null)
        {
            AddDiagnostic("LA1069", "Expected target after 'del'.", delToken);
            return null;
        }

        // CPython deletes every target in `del a, b` like the parenthesized form.
        if (CurrentToken == Token.Comma)
        {
            var items = new List<CollectionDisplayItemSyntax> { new CollectionValueItemSyntax(target) };
            while (CurrentToken == Token.Comma)
            {
                ReadToken();
                if (CurrentToken is Token.Eol or Token.Semicolon or Token.End)
                {
                    break;
                }

                var next = ParsePostfixExpression();
                if (next is null)
                {
                    return null;
                }

                items.Add(new CollectionValueItemSyntax(next));
            }

            target = new TupleLiteralExpressionSyntax(items, Merge(target.Span, items[^1].Span));
        }

        target = UnwrapParenthesizedTarget(target);
        return target switch
        {
            IdentifierExpressionSyntax or SubscriptExpressionSyntax or SliceExpressionSyntax or MemberExpressionSyntax => new DeleteStatementSyntax(target, Merge(SpanOf(delToken), target.Span)),
            TupleLiteralExpressionSyntax tuple when IsSupportedDeleteDisplay(tuple.Items) => new DeleteStatementSyntax(target, Merge(SpanOf(delToken), target.Span)),
            ListLiteralExpressionSyntax list when IsSupportedDeleteDisplay(list.Items) => new DeleteStatementSyntax(target, Merge(SpanOf(delToken), target.Span)),
            _ => AddUnsupportedDeleteTarget(target, "delete target")
        };
    }

    // Only displays of direct single targets are supported like CPython; anything
    // else (starred or non-target shapes) keeps the existing diagnostic. Empty displays delete nothing like CPython.
    private static bool IsSupportedDeleteDisplay(IReadOnlyList<CollectionDisplayItemSyntax> items)
    {
        foreach (var item in items)
        {
            if (!IsSupportedDeleteItem(item))
            {
                return false;
            }
        }

        return true;
    }

    // Parentheses never change the target like CPython; nested displays delete
    // every leaf like the flat form.
    private static bool IsSupportedDeleteItem(CollectionDisplayItemSyntax item)
    {
        if (item.IsUnpacking)
        {
            return false;
        }

        return UnwrapParenthesizedTarget(item.Expression) switch
        {
            IdentifierExpressionSyntax or SubscriptExpressionSyntax or SliceExpressionSyntax or MemberExpressionSyntax => true,
            TupleLiteralExpressionSyntax tuple => IsSupportedDeleteDisplay(tuple.Items),
            ListLiteralExpressionSyntax list => IsSupportedDeleteDisplay(list.Items),
            _ => false,
        };
    }

    private StatementSyntax? AddUnsupportedDeleteTarget(ExpressionSyntax target, string construct)
    {
        AddDiagnostic("LA2000", $"Unsupported Python construct '{construct}'.", target.Span);
        return null;
    }

    private StatementSyntax? ParseTryStatement()
    {
        IReadOnlyList<StatementSyntax>? ParseTrailingSuite(
            string colonDiagnosticCode,
            string colonDiagnostic,
            string suiteDiagnosticCode,
            string suiteDiagnostic)
        {
            ReadToken();
            if (!TryRead(Token.Colon, out _))
            {
                AddDiagnostic(colonDiagnosticCode, colonDiagnostic, _position);
                return null;
            }

            return ParseSuite(suiteDiagnosticCode, suiteDiagnostic);
        }

        var tryToken = ReadToken();
        if (!TryRead(Token.Colon, out _))
        {
            AddDiagnostic("LA1043", "Expected ':' after 'try'.", tryToken);
            return null;
        }

        var tryBody = ParseSuite("LA1044", "Expected indented block after 'try'.");
        if (tryBody is null)
        {
            return null;
        }

        var exceptClauses = new List<ExceptClauseSyntax>();
        IReadOnlyList<StatementSyntax>? elseBody = null;
        IReadOnlyList<StatementSyntax>? finallyBody = null;
        var span = Merge(SpanOf(tryToken), tryBody[^1].Span);

        while (CurrentToken == Token.Except)
        {
            var exceptToken = ReadToken();
            if (CurrentToken == Token.Star)
            {
                AddDiagnostic("LA2000", "Unsupported Python construct 'except*'.", _position);
                return null;
            }
            ExpressionSyntax? exceptionTypeExpression = null;
            string? exceptionVariable = null;
            if (CurrentToken != Token.Colon)
            {
                exceptionTypeExpression = ParseExpression();
                if (exceptionTypeExpression is null)
                {
                    AddDiagnostic("LA1045", "Expected exception expression after 'except'.", _position);
                    return null;
                }
                if (exceptionTypeExpression is AssignmentExpressionSyntax or YieldExpressionSyntax)
                {
                    AddDiagnostic("LA1045", "Assignment and yield expressions in an exception header require parentheses.", exceptionTypeExpression.Span);
                    return null;
                }
                if (CurrentToken == Token.As)
                {
                    ReadToken();
                    if (!TryReadNameToken(out var variableToken))
                    {
                        AddDiagnostic("LA1045", "Expected identifier after 'as' in except clause.", _position);
                        return null;
                    }

                    exceptionVariable = IdentifierText(variableToken);
                }
            }

            if (!TryRead(Token.Colon, out _))
            {
                AddDiagnostic("LA1046", "Expected ':' after except clause.", _position);
                return null;
            }

            var body = ParseSuite("LA1047", "Expected indented block after 'except'.");
            if (body is null)
            {
                return null;
            }

            var clauseSpan = Merge(SpanOf(exceptToken), body[^1].Span);
            exceptClauses.Add(new ExceptClauseSyntax(exceptionVariable, body, clauseSpan, exceptionTypeExpression));
            span = Merge(span, body[^1].Span);
        }

        for (var clauseIndex = 0; clauseIndex + 1 < exceptClauses.Count; clauseIndex++)
        {
            if (exceptClauses[clauseIndex].ExceptionTypeExpression is null)
            {
                AddDiagnostic("LA1075", "Default 'except:' must be last.", exceptClauses[clauseIndex].Span);
                return null;
            }
        }

        if (CurrentToken == Token.Else)
        {
            elseBody = ParseTrailingSuite(
                "LA1048",
                "Expected ':' after 'else'.",
                "LA1048",
                "Expected indented block after 'else'.");
            if (elseBody is null)
            {
                return null;
            }

            span = Merge(span, elseBody[^1].Span);
        }

        if (CurrentToken == Token.Finally)
        {
            finallyBody = ParseTrailingSuite(
                "LA1048",
                "Expected ':' after 'finally'.",
                "LA1049",
                "Expected indented block after 'finally'.");
            if (finallyBody is null)
            {
                return null;
            }

            span = Merge(span, finallyBody[^1].Span);
        }

        if (exceptClauses.Count == 0 && finallyBody is null)
        {
            AddDiagnostic("LA1050", "Expected 'except' or 'finally' after 'try'.", tryToken);
            return null;
        }

        return new TryStatementSyntax(
            tryBody,
            exceptClauses,
            elseBody,
            finallyBody,
            span);
    }
}
