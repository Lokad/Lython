using Lokad.Lython.Runtime;
using static Lokad.Lython.Frontend.StaticKnownCallArgumentChecks;

namespace Lokad.Lython.Frontend;

internal static class StaticProcessContractFamily
{
    private static readonly SubprocessRunArgumentLayout RunLayout = SubprocessRunArgumentLayout.Standard;
    private const int PopenBufsizeIndex = 1;
    private const int PopenStdinIndex = 3;
    private const int PopenStdoutIndex = 4;
    private const int PopenStderrIndex = 5;
    private const int PopenShellIndex = 8;
    private const int PopenCwdIndex = 9;
    private const int PopenEnvIndex = 10;
    private const int PopenCreationFlagsIndex = 13;
    private const int PopenEncodingIndex = 20;
    private const int PopenErrorsIndex = 21;
    private const int PopenUmaskIndex = 23;
    private const int PopenPipeSizeIndex = 24;

    public static bool AnalyzeKnownCallArgumentTypes(
        string targetName,
        ConcreteCallArguments arguments,
        List<LythonDiagnostic> diagnostics,
        AbstractState bindings)
    {
        if (string.Equals(targetName, LythonKnownCallableSignatures.SubprocessCompletedProcess.Name, StringComparison.Ordinal))
        {
            var completedProcessEmitted = AnalyzeIntegerArgument(arguments, 1, "returncode", "subprocess.CompletedProcess(..., returncode=...) expects an integer.", diagnostics, bindings);
            return completedProcessEmitted;
        }

        if (string.Equals(targetName, LythonKnownCallableSignatures.SubprocessList2Cmdline.Name, StringComparison.Ordinal))
        {
            return AnalyzeIterableOfStringsArgument(arguments, 0, "seq", "subprocess.list2cmdline(seq) expects an iterable of strings.", diagnostics, bindings, rejectSingleString: true);
        }

        if (string.Equals(targetName, LythonKnownCallableSignatures.SubprocessPopen.Name, StringComparison.Ordinal))
        {
            return AnalyzePopenArguments(arguments, diagnostics, bindings);
        }

        if (!IsSubprocessKnownCall(targetName))
        {
            return false;
        }

        var owner = targetName;
        var emitted = AnalyzeSubprocessArgsArgument(arguments, owner, diagnostics, bindings);
        emitted |= AnalyzePathLikeOrNoneArgument(arguments, RunLayout.CurrentDirectory, "cwd", $"{owner}(..., cwd=...) expects a string, Path, or None.", diagnostics, bindings);
        emitted |= AnalyzeIntegerOrNoneArgument(arguments, RunLayout.StandardInput, "stdin", $"{owner}(..., stdin=...) expects a subprocess stream constant or None.", diagnostics, bindings);
        emitted |= AnalyzeIntegerOrNoneArgument(arguments, RunLayout.StandardOutput, "stdout", $"{owner}(..., stdout=...) expects a subprocess stream constant or None.", diagnostics, bindings);
        emitted |= AnalyzeIntegerOrNoneArgument(arguments, RunLayout.StandardError, "stderr", $"{owner}(..., stderr=...) expects a subprocess stream constant or None.", diagnostics, bindings);
        emitted |= AnalyzeStringOrNoneArgument(arguments, RunLayout.Encoding, "encoding", $"{owner}(..., encoding=...) expects a string or None.", diagnostics, bindings);
        emitted |= AnalyzeStringOrNoneArgument(arguments, RunLayout.Errors, "errors", $"{owner}(..., errors=...) expects a string or None.", diagnostics, bindings);
        emitted |= AnalyzeUtf8Encoding(arguments, RunLayout.Encoding, "encoding", $"{owner}(...) only supports encoding='utf-8' or 'utf-8-sig'.", diagnostics, bindings);
        emitted |= StaticContractChecks.AnalyzeSupportedTextErrorArgument(arguments, RunLayout.Errors, "errors", "LA3032", $"{owner}(...) only supports UTF-8 error handlers 'strict', 'ignore', 'replace', and 'backslashreplace'.", diagnostics, bindings);
        emitted |= AnalyzeRealOrNoneArgument(arguments, RunLayout.Timeout, "timeout", $"{owner}(..., timeout=...) expects numeric seconds or None.", diagnostics, bindings);
        emitted |= AnalyzeSubprocessEnvArgument(arguments, owner, diagnostics, bindings);
        return emitted;
    }

    private static bool AnalyzeSubprocessArgsArgument(ConcreteCallArguments arguments, string owner, List<LythonDiagnostic> diagnostics, AbstractState bindings)
        => AnalyzeSubprocessArgsArgument(arguments, owner, diagnostics, bindings, RunLayout.Shell);

    private static bool AnalyzeSubprocessArgsArgument(
        ConcreteCallArguments arguments,
        string owner,
        List<LythonDiagnostic> diagnostics,
        AbstractState bindings,
        int shellIndex)
    {
        if (!arguments.TryGetValue(RunLayout.Args, "args", out var argsExpression))
        {
            return false;
        }

        if (arguments.TryGetValue(shellIndex, "shell", out var shellExpression) &&
            (!StaticAbstractValueResolver.TryResolve(shellExpression, bindings, out var shellValue) ||
             !StaticAbstractFacts.TryGetTruthiness(shellValue, out var shellTruth) || shellTruth))
        {
            var value = StaticAbstractValueResolver.ResolveOrUnknown(argsExpression, bindings);
            if (value.IsStringLike || value.Kind == AbstractValueKind.Path || StaticKnownCallArgumentChecks.IsUnknown(value))
            {
                return false;
            }

            return AnalyzePathLikeCollectionArgument(arguments, RunLayout.Args, "args", $"{owner}(args) expects a string command or an iterable of strings or Paths.", diagnostics, bindings, PathLikeArgumentPolicy.AllowSinglePath | PathLikeArgumentPolicy.RequireNonEmpty);
        }

        return AnalyzePathLikeCollectionArgument(arguments, RunLayout.Args, "args", $"{owner}(args) expects a non-empty iterable of strings or Paths, not a single string.", diagnostics, bindings, PathLikeArgumentPolicy.RequireNonEmpty);
    }

    private static bool AnalyzeSubprocessEnvArgument(ConcreteCallArguments arguments, string owner, List<LythonDiagnostic> diagnostics, AbstractState bindings)
        => AnalyzeSubprocessEnvArgument(arguments, owner, diagnostics, bindings, RunLayout.Environment);

    private static bool AnalyzeSubprocessEnvArgument(
        ConcreteCallArguments arguments,
        string owner,
        List<LythonDiagnostic> diagnostics,
        AbstractState bindings,
        int envIndex)
    {
        if (!arguments.TryGetValue(envIndex, "env", out var envExpression) ||
            envExpression is NoneLiteralExpressionSyntax)
        {
            return false;
        }

        var value = StaticAbstractValueResolver.ResolveOrUnknown(envExpression, bindings);
        if (StaticKnownCallArgumentChecks.IsUnknown(value) || value.Kind == AbstractValueKind.Dict)
        {
            return false;
        }

        if (value.IsLiteralLike)
        {
            AddDiagnostic(diagnostics, "LA3158", $"{owner}(..., env=...) expects a dictionary of strings or None.", envExpression.Span);
            return true;
        }

        return false;
    }

    private static bool AnalyzeUtf8Encoding(
        ConcreteCallArguments arguments,
        int position,
        string keyword,
        string message,
        List<LythonDiagnostic> diagnostics,
        AbstractState bindings)
    {
        if (!arguments.TryGetValue(position, keyword, out var expression) ||
            expression is NoneLiteralExpressionSyntax ||
            !StaticAbstractValueResolver.TryResolveKnownString(expression, bindings, out var text) ||
            text.Equals("utf-8", StringComparison.OrdinalIgnoreCase) ||
            text.Equals("utf-8-sig", StringComparison.OrdinalIgnoreCase))
        {
            return false;
        }

        StaticDiagnosticSink.AddError(diagnostics, "LA3031", message, expression.Span);
        return true;
    }

    private static bool IsSubprocessKnownCall(string targetName)
        => string.Equals(targetName, LythonKnownCallableSignatures.SubprocessRun.Name, StringComparison.Ordinal) ||
           string.Equals(targetName, LythonKnownCallableSignatures.SubprocessCall.Name, StringComparison.Ordinal) ||
           string.Equals(targetName, LythonKnownCallableSignatures.SubprocessCheckCall.Name, StringComparison.Ordinal) ||
           string.Equals(targetName, LythonKnownCallableSignatures.SubprocessCheckOutput.Name, StringComparison.Ordinal);

    private static bool AnalyzePopenArguments(
        ConcreteCallArguments arguments,
        List<LythonDiagnostic> diagnostics,
        AbstractState bindings)
    {
        const string owner = "subprocess.Popen";
        var emitted = AnalyzeSubprocessArgsArgument(arguments, owner, diagnostics, bindings, PopenShellIndex);
        emitted |= AnalyzeIntegerOrNoneArgument(arguments, PopenBufsizeIndex, "bufsize", $"{owner}(..., bufsize=...) expects an integer.", diagnostics, bindings);
        emitted |= AnalyzeIntegerOrNoneArgument(arguments, PopenStdinIndex, "stdin", $"{owner}(..., stdin=...) expects a subprocess stream constant or None.", diagnostics, bindings);
        emitted |= AnalyzeIntegerOrNoneArgument(arguments, PopenStdoutIndex, "stdout", $"{owner}(..., stdout=...) expects a subprocess stream constant or None.", diagnostics, bindings);
        emitted |= AnalyzeIntegerOrNoneArgument(arguments, PopenStderrIndex, "stderr", $"{owner}(..., stderr=...) expects a subprocess stream constant or None.", diagnostics, bindings);
        emitted |= AnalyzePathLikeOrNoneArgument(arguments, PopenCwdIndex, "cwd", $"{owner}(..., cwd=...) expects a string, Path, or None.", diagnostics, bindings);
        emitted |= AnalyzeSubprocessEnvArgument(arguments, owner, diagnostics, bindings, PopenEnvIndex);
        emitted |= AnalyzeIntegerOrNoneArgument(arguments, PopenCreationFlagsIndex, "creationflags", $"{owner}(..., creationflags=...) expects an integer.", diagnostics, bindings);
        emitted |= AnalyzeStringOrNoneArgument(arguments, PopenEncodingIndex, "encoding", $"{owner}(..., encoding=...) expects a string or None.", diagnostics, bindings);
        emitted |= AnalyzeStringOrNoneArgument(arguments, PopenErrorsIndex, "errors", $"{owner}(..., errors=...) expects a string or None.", diagnostics, bindings);
        emitted |= AnalyzeIntegerOrNoneArgument(arguments, PopenUmaskIndex, "umask", $"{owner}(..., umask=...) expects an integer.", diagnostics, bindings);
        emitted |= AnalyzeIntegerOrNoneArgument(arguments, PopenPipeSizeIndex, "pipesize", $"{owner}(..., pipesize=...) expects an integer.", diagnostics, bindings);
        emitted |= AnalyzeUtf8Encoding(arguments, PopenEncodingIndex, "encoding", $"{owner}(...) only supports encoding='utf-8' or 'utf-8-sig'.", diagnostics, bindings);
        emitted |= StaticContractChecks.AnalyzeSupportedTextErrorArgument(arguments, PopenErrorsIndex, "errors", "LA3032", $"{owner}(...) only supports UTF-8 error handlers 'strict', 'ignore', 'replace', and 'backslashreplace'.", diagnostics, bindings);
        return emitted;
    }

}
