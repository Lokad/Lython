namespace Lokad.Lython.Frontend;

internal sealed partial class Parser
{
    private const string MalformedFormattedStringMessage = "Invalid string literal. Malformed f-string replacement field or unmatched brace.";

    private bool TryParseFormattedStringLiteral(string prefix, string literal, int literalStart, out IReadOnlyList<FormattedStringPartSyntax> parts, out string message)
    {
        parts = Array.Empty<FormattedStringPartSyntax>();
        message = MalformedFormattedStringMessage;
        if (!TryExtractStringContent(literal, out var content))
        {
            return false;
        }

        var quoteWidth = literal.Length >= 3 && literal[0] == literal[1] && literal[0] == literal[2] ? 3 : 1;
        return TryParseFormattedStringContent(prefix, content, literalStart + quoteWidth, inFormatSpecifier: false, allowNestedFormatFields: true, out parts, out message);
    }

    private bool TryParseFormattedStringContent(
        string prefix,
        string content,
        int contentStart,
        bool inFormatSpecifier,
        bool allowNestedFormatFields,
        out IReadOnlyList<FormattedStringPartSyntax> parts,
        out string message)
    {
        parts = Array.Empty<FormattedStringPartSyntax>();
        message = MalformedFormattedStringMessage;
        var isRaw = prefix.Contains('r', StringComparison.OrdinalIgnoreCase);

        var parsedParts = new List<FormattedStringPartSyntax>();
        var text = new System.Text.StringBuilder();

        for (var i = 0; i < content.Length; i++)
        {
            CheckCancellation(i);
            var c = content[i];
            if (!isRaw && c == '\\' && i + 1 < content.Length)
            {
                if (content[i + 1] == '\\')
                {
                    text.Append("\\\\");
                    i++;
                    continue;
                }
                if (content[i + 1] == 'N')
                {
                    message = UnsupportedNamedUnicodeEscapeMessage;
                    return false;
                }
            }
            if (c == '{')
            {
                if (!inFormatSpecifier && i + 1 < content.Length && content[i + 1] == '{')
                {
                    text.Append('{');
                    i++;
                    continue;
                }

                if (text.Length > 0)
                {
                    if (!TryDecodeEscapedText(text.ToString(), isRaw, out var decodedText, out message))
                    {
                        return false;
                    }

                    parsedParts.Add(new FormattedStringTextPartSyntax(decodedText));
                    text.Clear();
                }

                if (!TryParseFormattedStringField(
                        prefix,
                        content,
                        i + 1,
                        contentStart,
                        allowNestedFormatFields,
                        out var end,
                        out var expressionPart,
                        out var debugText,
                        out message))
                {
                    return false;
                }

                if (debugText is not null)
                {
                    parsedParts.Add(new FormattedStringTextPartSyntax(debugText));
                }

                parsedParts.Add(expressionPart);
                i = end;
                continue;
            }

            if (c == '}')
            {
                if (!inFormatSpecifier && i + 1 < content.Length && content[i + 1] == '}')
                {
                    text.Append('}');
                    i++;
                    continue;
                }

                return false;
            }

            text.Append(c);
        }

        if (text.Length > 0)
        {
            if (!TryDecodeEscapedText(text.ToString(), isRaw, out var decodedText, out message))
            {
                return false;
            }

            parsedParts.Add(new FormattedStringTextPartSyntax(decodedText));
        }

        parts = parsedParts;
        return true;
    }

    private bool TryParseFormattedStringField(
        string prefix,
        string content,
        int start,
        int contentStart,
        bool allowNestedFormatFields,
        out int end,
        [MaybeNullWhen(false)] out FormattedStringExpressionPartSyntax part,
        out string? debugText,
        out string message)
    {
        end = -1;
        part = null;
        debugText = null;
        message = MalformedFormattedStringMessage;

        if (!TryFindFormattedStringFieldEnd(content, start, out end, cancellationToken: _cancellationToken))
        {
            return false;
        }

        var field = content[start..end];
        if (!TrySplitFormattedStringField(
                field,
                out var expressionText,
                out var conversion,
                out var formatSpecifier,
                out var expressionOffset,
                out var formatOffset,
                out debugText) ||
            expressionText.Length == 0 ||
            !TryParseEmbeddedExpression(expressionText, contentStart + start + expressionOffset, out var expression, out message))
        {
            return false;
        }

        IReadOnlyList<FormattedStringPartSyntax>? formatSpecifierParts = null;
        if (formatSpecifier is not null &&
            (formatSpecifier.Contains('{', StringComparison.Ordinal) || formatSpecifier.Contains('}', StringComparison.Ordinal)))
        {
            if (!allowNestedFormatFields ||
                !TryParseFormattedStringContent(
                    prefix,
                    formatSpecifier,
                    contentStart + start + formatOffset,
                    inFormatSpecifier: true,
                    allowNestedFormatFields: false,
                    out formatSpecifierParts,
                    out message))
            {
                return false;
            }

            formatSpecifier = null;
        }
        else if (formatSpecifier is not null)
        {
            if (!TryDecodeEscapedText(formatSpecifier, prefix.Contains('r', StringComparison.OrdinalIgnoreCase), out var decodedSpecifier, out message))
                return false;
            formatSpecifier = decodedSpecifier;
        }

        if (debugText is not null && conversion is null && formatSpecifier is null && formatSpecifierParts is null)
        {
            conversion = 'r';
        }

        part = new FormattedStringExpressionPartSyntax(
            expression,
            conversion,
            formatSpecifier,
            formatSpecifierParts);
        return true;
    }

    internal static bool TryFindFormattedStringFieldEnd(string content, int start, out int end, int depth = 0, char? outerQuote = null, int outerQuoteWidth = 0, CancellationToken cancellationToken = default)
    {
        end = -1;
        if (depth >= MaxNestingDepth) return false;
        var parenDepth = 0;
        var bracketDepth = 0;
        var braceDepth = 0;
        var format = false;

        for (var i = start; i < content.Length; i++)
        {
            PythonTokenization.CheckCancellation(cancellationToken, i);
            var c = content[i];
            if (format)
            {
                if (c == '\\' && i + 1 < content.Length && content[i + 1] is not ('{' or '}'))
                {
                    i++;
                    if (content[i] == '\r' && i + 1 < content.Length && content[i + 1] == '\n') i++;
                    continue;
                }
                if (outerQuoteWidth == 1 && c is '\r' or '\n') return false;
                if (c == outerQuote && (outerQuoteWidth == 1 ||
                    i + 2 < content.Length && content[i + 1] == c && content[i + 2] == c)) return false;
                if (c == '{')
                {
                    if (!TryFindFormattedStringFieldEnd(content, i + 1, out i, depth + 1, outerQuote, outerQuoteWidth, cancellationToken)) return false;
                }
                else if (c == '}')
                {
                    end = i;
                    return true;
                }
                continue;
            }
            if (c == '#')
            {
                FormattedStringLexicalScanner.SkipComment(content, ref i, cancellationToken);
                continue;
            }
            if (c is '"' or '\'')
            {
                if (!FormattedStringLexicalScanner.TrySkipString(content, ref i, depth + 1, cancellationToken))
                {
                    return false;
                }

                continue;
            }
            if (c == ':' && parenDepth == 0 && bracketDepth == 0 && braceDepth == 0)
            {
                format = true;
                continue;
            }

            switch (c)
            {
                case '(':
                    parenDepth++;
                    break;
                case ')':
                    if (parenDepth == 0)
                    {
                        return false;
                    }

                    parenDepth--;
                    break;
                case '[':
                    bracketDepth++;
                    break;
                case ']':
                    if (bracketDepth == 0)
                    {
                        return false;
                    }

                    bracketDepth--;
                    break;
                case '{':
                    braceDepth++;
                    break;
                case '}':
                    if (parenDepth == 0 && bracketDepth == 0 && braceDepth == 0)
                    {
                        end = i;
                        return true;
                    }

                    if (braceDepth == 0)
                    {
                        return false;
                    }

                    braceDepth--;
                    break;
            }
        }

        return false;
    }

    private bool TrySplitFormattedStringField(
        string field,
        out string expressionText,
        out char? conversion,
        out string? formatSpecifier,
        out int expressionOffset,
        out int formatOffset,
        out string? debugText)
    {
        expressionText = string.Empty;
        conversion = null;
        formatSpecifier = null;
        debugText = null;
        expressionOffset = 0;
        formatOffset = 0;

        if (!TryFindFormattedStringSeparators(field, out var conversionIndex, out var formatIndex))
        {
            return false;
        }

        var expressionEnd = conversionIndex >= 0
            ? conversionIndex
            : formatIndex >= 0
                ? formatIndex
                : field.Length;
        var expressionSource = field[..expressionEnd];
        var visibleExpression = FormattedStringLexicalScanner.DebugText(expressionSource, out var debugMarker, _cancellationToken);
        var debugEnd = visibleExpression.Length - 1;
        while (debugEnd >= 0 && FormattedStringLexicalScanner.IsWhitespace(visibleExpression[debugEnd]))
        {
            CheckCancellation(debugEnd);
            debugEnd--;
        }

        if (debugEnd >= 0 &&
            visibleExpression[debugEnd] == '=' &&
            (debugEnd == 0 || visibleExpression[debugEnd - 1] is not ('=' or '!' or '<' or '>' or ':')))
        {
            debugText = visibleExpression;
            visibleExpression = visibleExpression[..debugEnd];
            // Locate the actual debug marker without disturbing source offsets.
            expressionSource = expressionSource[..debugMarker];
        }

        expressionOffset = expressionSource.Length - expressionSource.TrimStart(FormattedStringLexicalScanner.Whitespace).Length;
        expressionText = expressionSource.Trim(FormattedStringLexicalScanner.Whitespace);
        if (visibleExpression.Trim(FormattedStringLexicalScanner.Whitespace).Length == 0) return false;

        if (conversionIndex >= 0)
        {
            if (conversionIndex + 1 >= field.Length)
            {
                return false;
            }

            conversion = field[conversionIndex + 1];
            if (conversion is not ('s' or 'r' or 'a'))
            {
                return false;
            }

            var afterConversion = conversionIndex + 2;
            while (afterConversion < field.Length)
            {
                CheckCancellation(afterConversion);
                if (FormattedStringLexicalScanner.IsWhitespace(field[afterConversion])) afterConversion++;
                else if (field[afterConversion] == '#')
                {
                    FormattedStringLexicalScanner.SkipComment(field, ref afterConversion, _cancellationToken);
                    afterConversion++;
                }
                else break;
            }
            if (afterConversion < field.Length)
            {
                if (field[afterConversion] != ':')
                {
                    return false;
                }

                formatIndex = afterConversion;
            }
        }

        if (formatIndex >= 0)
        {
            formatSpecifier = field[(formatIndex + 1)..];
            formatOffset = formatIndex + 1;
        }

        return true;
    }

    private bool TryFindFormattedStringSeparators(string field, out int conversionIndex, out int formatIndex)
    {
        conversionIndex = -1;
        formatIndex = -1;
        var parenDepth = 0;
        var bracketDepth = 0;
        var braceDepth = 0;

        for (var i = 0; i < field.Length; i++)
        {
            CheckCancellation(i);
            var c = field[i];
            if (c == '#')
            {
                FormattedStringLexicalScanner.SkipComment(field, ref i, _cancellationToken);
                continue;
            }
            if (c is '"' or '\'')
            {
                if (!FormattedStringLexicalScanner.TrySkipString(field, ref i, cancellationToken: _cancellationToken))
                {
                    return false;
                }

                continue;
            }

            if (parenDepth == 0 && bracketDepth == 0 && braceDepth == 0)
            {
                if (c == ':' && formatIndex < 0)
                {
                    formatIndex = i;
                    return true;
                }

                if (c == '!' && i + 1 < field.Length && field[i + 1] != '=' && conversionIndex < 0)
                {
                    conversionIndex = i;
                    continue;
                }
            }

            switch (c)
            {
                case '(':
                    parenDepth++;
                    break;
                case ')':
                    if (parenDepth == 0)
                    {
                        return false;
                    }

                    parenDepth--;
                    break;
                case '[':
                    bracketDepth++;
                    break;
                case ']':
                    if (bracketDepth == 0)
                    {
                        return false;
                    }

                    bracketDepth--;
                    break;
                case '{':
                    braceDepth++;
                    break;
                case '}':
                    if (braceDepth == 0)
                    {
                        return false;
                    }

                    braceDepth--;
                    break;
            }
        }

        return parenDepth == 0 && bracketDepth == 0 && braceDepth == 0;
    }

    private bool TryParseEmbeddedExpression(string expressionText, int expressionStart, [MaybeNullWhen(false)] out ExpressionSyntax expression, out string message)
    {
        expression = null;
        message = MalformedFormattedStringMessage;
        // The enclosing syntax pass supplies the real scope, including yield legality.
        const string prefix = "value = (";
        var tokens = PythonTokenization.Read(prefix + expressionText + "\n)\n", _cancellationToken);
        if (tokens.HasInvalidTokens) return false;
        var frontend = new Parser(tokens, _memoryGovernor, _cancellationToken)
        {
            _privateNames = _privateNames,
            _nestingDepth = _nestingDepth + 1,
            _spanSourceTokens = _spanSourceTokens ?? _tokens,
            _spanOffset = expressionStart - prefix.Length
        }.Parse();
        if (frontend.Script?.Statements is not [AssignmentStatementSyntax assignment] || frontend.Diagnostics.Count != 0)
        {
            if (frontend.Diagnostics.Any(diagnostic => diagnostic.Message == UnsupportedNamedUnicodeEscapeMessage))
                message = UnsupportedNamedUnicodeEscapeMessage;
            else if (frontend.Diagnostics.Any(diagnostic => diagnostic.Code == "LA0003"))
                message = SyntaxNestingLimitMessage;
            return false;
        }

        expression = assignment.Expression is ParenthesizedExpressionSyntax parenthesized ? parenthesized.Inner : assignment.Expression;
        if (assignment.Expression is TupleLiteralExpressionSyntax tuple)
        {
            (_spanSourceTokens ?? _tokens).LineOfPosition(expressionStart, out var line, out var column);
            expression = tuple with { Span = new LythonSourceSpan(expressionStart, expressionText.Length, line, column) };
        }
        return true;
    }
}
