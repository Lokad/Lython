using System.Collections;
using System.Globalization;
using System.Numerics;
using Lokad.Lython.Runtime.Numbers;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    private sealed class TimeModule : PyModule, IPyContextualDynamicAttributes
    {
        public static readonly TimeModule Instance = new();

        private static readonly string[] Names =
        [
            "time",
            "time_ns",
            "monotonic",
            "monotonic_ns",
            "perf_counter",
            "perf_counter_ns",
            "sleep",
            "get_clock_info",
            "process_time",
            "process_time_ns",
            "thread_time",
            "thread_time_ns",
            "clock_gettime",
            "clock_gettime_ns",
            "clock_getres",
            "clock_settime",
            "clock_settime_ns",
            "pthread_getcpuclockid",
            "gmtime",
            "localtime",
            "ctime",
            "mktime",
            "asctime",
            "strftime",
            "strptime",
            "struct_time",
            "timezone",
            "altzone",
            "daylight",
            "tzname",
            "tzset",
        ];

        private TimeModule() : base("time")
        {
        }

        public override IReadOnlyList<string> ExportedNames => Names;

        public override IReadOnlyList<string> MemberNames => Names;

        public override bool TryGetMember(string name, [MaybeNullWhen(false)] out object value)
        {
            value = name switch
            {
                "time" => BuiltinCallable.Create(LythonKnownCallableSignatures.TimeTime, CurrentTime),
                "time_ns" => BuiltinCallable.Create(LythonKnownCallableSignatures.TimeTimeNs, CurrentTimeNanoseconds),
                "monotonic" => BuiltinCallable.Create(LythonKnownCallableSignatures.TimeMonotonic, Monotonic),
                "monotonic_ns" => BuiltinCallable.Create(LythonKnownCallableSignatures.TimeMonotonicNs, MonotonicNanoseconds),
                "perf_counter" => BuiltinCallable.Create(LythonKnownCallableSignatures.TimePerfCounter, Monotonic),
                "perf_counter_ns" => BuiltinCallable.Create(LythonKnownCallableSignatures.TimePerfCounterNs, MonotonicNanoseconds),
                "sleep" => BuiltinCallable.Create(LythonKnownCallableSignatures.TimeSleep, Sleep, SleepAsync),
                "get_clock_info" => BuiltinCallable.Create(LythonKnownCallableSignatures.TimeGetClockInfo, GetClockInfo),
                "process_time" => Unsupported(LythonKnownCallableSignatures.TimeProcessTime, "process CPU clocks"),
                "process_time_ns" => Unsupported(LythonKnownCallableSignatures.TimeProcessTimeNs, "process CPU clocks"),
                "thread_time" => Unsupported(LythonKnownCallableSignatures.TimeThreadTime, "thread CPU clocks"),
                "thread_time_ns" => Unsupported(LythonKnownCallableSignatures.TimeThreadTimeNs, "thread CPU clocks"),
                "clock_gettime" => Unsupported(LythonKnownCallableSignatures.TimeClockGetTime, "platform clock IDs"),
                "clock_gettime_ns" => Unsupported(LythonKnownCallableSignatures.TimeClockGetTimeNs, "platform clock IDs"),
                "clock_getres" => Unsupported(LythonKnownCallableSignatures.TimeClockGetRes, "platform clock IDs"),
                "clock_settime" => Unsupported(LythonKnownCallableSignatures.TimeClockSetTime, "clock mutation"),
                "clock_settime_ns" => Unsupported(LythonKnownCallableSignatures.TimeClockSetTimeNs, "clock mutation"),
                "pthread_getcpuclockid" => Unsupported(LythonKnownCallableSignatures.TimePthreadGetCpuClockId, "platform thread clocks"),
                "gmtime" => BuiltinCallable.Create(LythonKnownCallableSignatures.TimeGmtime, Gmtime),
                "localtime" => BuiltinCallable.Create(LythonKnownCallableSignatures.TimeLocaltime, Localtime),
                "ctime" => BuiltinCallable.Create(LythonKnownCallableSignatures.TimeCtime, Ctime),
                "mktime" => BuiltinCallable.Create(LythonKnownCallableSignatures.TimeMktime, Mktime),
                "asctime" => BuiltinCallable.Create(LythonKnownCallableSignatures.TimeAsctime, Asctime),
                "strftime" => BuiltinCallable.Create(LythonKnownCallableSignatures.TimeStrftime, Strftime),
                "strptime" => BuiltinCallable.Create(LythonKnownCallableSignatures.TimeStrptime, Strptime),
                "struct_time" => TimeStructTimeType.Instance,
                "tzset" => BuiltinCallable.Create(
                    LythonKnownCallableSignatures.TimeTzset,
                    (_, span, _) => throw new LythonRuntimeException(
                        "NotImplementedError",
                        "time.tzset() is unsupported because Lython uses the host's fixed local offset and has no ambient timezone database.",
                        span)),
                _ => MissingMemberValue.Instance,
            };

            return !ReferenceEquals(value, MissingMemberValue.Instance);
        }

        public bool TryGetMember(string name, ExecutionContext context, LythonSourceSpan span, [MaybeNullWhen(false)] out object value)
        {
            if (name is not ("timezone" or "altzone" or "daylight" or "tzname"))
            {
                return TryGetMember(name, out value);
            }

            context.CheckExecution(span);
            var offset = context.State.ReadHostLocalNow().Offset;
            var secondsWest = new BigInteger(-(long)offset.TotalSeconds);
            var zoneName = FixedZoneName(offset);
            value = name switch
            {
                "timezone" or "altzone" => secondsWest,
                "daylight" => BigInteger.Zero,
                "tzname" => new PyTuple(
                    [PyString.FromString(zoneName, context.MemoryGovernor, span), PyString.FromString(zoneName, context.MemoryGovernor, span)],
                    context.MemoryGovernor,
                    span),
                _ => MissingMemberValue.Instance,
            };

            return true;
        }

        private static object CurrentTime(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            _ = arguments;
            context.CheckExecution(span);
            return UnixSeconds(context.State.ReadHostUtcNow());
        }

        private static object CurrentTimeNanoseconds(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            _ = arguments;
            context.CheckExecution(span);
            var ticks = context.State.ReadHostUtcNow().UtcDateTime.Ticks - DateTime.UnixEpoch.Ticks;
            return new BigInteger(ticks) * 100;
        }

        private static object Monotonic(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            _ = arguments;
            return context.ReadHostMonotonicNanoseconds(span) / 1_000_000_000d;
        }

        private static object MonotonicNanoseconds(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            _ = arguments;
            return new BigInteger(context.ReadHostMonotonicNanoseconds(span));
        }

        private static object Sleep(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            var duration = ReadSleepDuration(arguments[0], span);
            context.DelayHost(duration, span);
            return PyNone.Instance;
        }

        private static async ValueTask<object> SleepAsync(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            var duration = ReadSleepDuration(arguments[0], span);
            await context.DelayHostAsync(duration, span).ConfigureAwait(false);
            return PyNone.Instance;
        }

        // Fixed engine vocabulary: share both labels forever like the
        // built-in origin instead of charging a fresh copy per call.
        private static readonly PyString UtcClockImplementation = PyString.FromString("Lython host UTC wall clock");
        private static readonly PyString MonotonicClockImplementation = PyString.FromString("Lython host monotonic clock");

        private static object GetClockInfo(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            if (!PyStringOps.TryAsString(arguments[0], out var nameValue))
            {
                throw new LythonRuntimeException("TypeError", "time.get_clock_info(name) expects a string.", span);
            }

            var name = nameValue.AsString();
            bool adjustable;
            PyString implementation;
            bool monotonic;
            double resolution;
            switch (name)
            {
                case "time":
                    adjustable = true;
                    implementation = UtcClockImplementation;
                    monotonic = false;
                    resolution = 1d / TimeSpan.TicksPerSecond;
                    break;
                case "monotonic":
                case "perf_counter":
                    adjustable = false;
                    implementation = MonotonicClockImplementation;
                    monotonic = true;
                    resolution = context.ReadHostMonotonicResolutionNanoseconds(span) / 1_000_000_000d;
                    break;
                case "process_time":
                case "thread_time":
                    throw new LythonRuntimeException(
                        "NotImplementedError",
                        $"time.get_clock_info('{name}') is unsupported because Lython has no host {name.Replace('_', ' ')} capability.",
                        span);
                default:
                    throw new LythonRuntimeException("ValueError", $"unknown clock: {name}", span);
            }

            // Clock-info objects retain a small fixed payload beside the shared
            // implementation labels below; charge one table slot per fresh value
            // once the clock name has validated.
            context.MemoryGovernor.Reserve(64L, span);
            context.MemoryGovernor.Commit(64L);
            return new TimeClockInfoValue(adjustable, implementation, monotonic, resolution);
        }

        private static TimeSpan ReadSleepDuration(object value, LythonSourceSpan span)
        {
            if (!PyNumberOps.TryAsNumber(value, out var number))
            {
                throw new LythonRuntimeException("TypeError", "time.sleep(seconds) expects a real number.", span);
            }

            var seconds = number.ToDouble();
            if (double.IsNaN(seconds))
            {
                throw new LythonRuntimeException("ValueError", "Invalid value NaN (not a number)", span);
            }

            if (seconds < 0)
            {
                throw new LythonRuntimeException("ValueError", "sleep length must be non-negative", span);
            }

            if (!double.IsFinite(seconds) || seconds > TimeSpan.MaxValue.TotalSeconds)
            {
                throw new LythonRuntimeException("OverflowError", "timestamp out of range for platform time_t", span);
            }

            try
            {
                return TimeSpan.FromSeconds(seconds);
            }
            catch (OverflowException ex)
            {
                throw new LythonRuntimeException("OverflowError", ex.Message, span);
            }
        }

        private static BuiltinCallable Unsupported(LythonCallableSignature signature, string capability)
            => BuiltinCallable.Create(
                signature,
                (_, span, _) => throw new LythonRuntimeException(
                    "NotImplementedError",
                    $"{signature.Name}() is unsupported because Lython has no host {capability} capability.",
                    span));

        // gmtime is always GMT: share the zone label forever like the
        // built-in origin instead of charging a fresh copy per call.
        private static readonly PyString GmtZoneName = PyString.FromString("GMT");

        private static object Gmtime(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            DateTime utc;
            if (arguments.Length == 0 || arguments[0] is PyNone)
            {
                context.CheckExecution(span);
                utc = context.State.ReadHostUtcNow().UtcDateTime;
            }
            else
            {
                utc = TimestampToInstant(arguments[0], span, context).UtcDateTime;
            }

            return TimeStructTimeValue.FromDateTime(
                DateTime.SpecifyKind(utc, DateTimeKind.Unspecified),
                isDst: 0,
                GmtZoneName,
                BigInteger.Zero,
                context,
                span);
        }

        private static object Localtime(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            DateTimeOffset local;
            TimeSpan offset;
            context.CheckExecution(span);
            var localNow = context.State.ReadHostLocalNow();
            if (arguments.Length == 0 || arguments[0] is PyNone)
            {
                local = localNow;
                offset = localNow.Offset;
            }
            else
            {
                offset = localNow.Offset;
                local = TimestampToInstant(arguments[0], span, context).ToOffset(offset);
            }

            return TimeStructTimeValue.FromDateTime(
                DateTime.SpecifyKind(local.DateTime, DateTimeKind.Unspecified),
                isDst: 0,
                PyString.FromString(FixedZoneName(offset), context.MemoryGovernor, span),
                new BigInteger((long)offset.TotalSeconds),
                context,
                span);
        }

        private static object Ctime(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            var local = (TimeStructTimeValue)Localtime(arguments, span, context);
            return PyString.FromString(FormatAsctime(ReadTimeTuple(local, "time.ctime", span, context), span), context.MemoryGovernor, span);
        }

        private static object Mktime(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            var fields = ReadTimeTuple(arguments[0], "time.mktime", span, context);
            context.CheckExecution(span);
            return NormalizeFieldsToEpochSeconds(fields, context.State.ReadHostLocalNow().Offset);
        }

        private static double NormalizeFieldsToEpochSeconds(TimeFields fields, TimeSpan offset)
        {
            // Out-of-range calendar and clock fields carry like libc mktime,
            // keeping everything in integer arithmetic for determinism.
            var totalMonths = (long)fields.Year * 12 + (fields.Month - 1);
            var year = FloorDiv(totalMonths, 12, out var monthRemainder);
            var month = (int)monthRemainder + 1;
            var days = DaysFromCivil(year, month) + (fields.MonthDay - 1);
            var daySeconds = (long)fields.Hour * 3600 + (long)fields.Minute * 60 + fields.Second;
            var totalSeconds = days * 86_400L + daySeconds - (long)offset.TotalSeconds;
            return totalSeconds;
        }

        private static long FloorDiv(long value, long divisor, out long remainder)
        {
            var quotient = value / divisor;
            remainder = value % divisor;
            if (remainder != 0 && (remainder < 0) != (divisor < 0))
            {
                quotient -= 1;
                remainder += divisor;
            }

            return quotient;
        }

        private static long DaysFromCivil(long year, int month)
        {
            // Days since 1970-01-01 for any proleptic Gregorian year.
            var adjustedYear = month <= 2 ? year - 1 : year;
            var era = adjustedYear >= 0 ? adjustedYear / 400 : (adjustedYear - 399) / 400;
            var yearOfEra = adjustedYear - era * 400;
            var dayOfYear = (153 * (month + (month > 2 ? -3 : 9)) + 2) / 5;
            var dayOfEra = yearOfEra * 365 + yearOfEra / 4 - yearOfEra / 100 + dayOfYear;
            return era * 146097 + dayOfEra - 719468;
        }

        private static object Asctime(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            TimeFields fields;
            if (arguments.Length == 0)
            {
                fields = ReadTimeTuple(Localtime([], span, context), "time.asctime", span, context);
            }
            else
            {
                fields = ReadTimeTuple(arguments[0], "time.asctime", span, context);
            }

            return PyString.FromString(FormatAsctime(fields, span), context.MemoryGovernor, span);
        }

        private static object Strftime(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            if (!PyStringOps.TryAsString(arguments[0], out var format))
            {
                throw new LythonRuntimeException("TypeError", "time.strftime(format[, t]) expects format to be a string.", span);
            }

            TimeFields fields;
            if (arguments.Length < 2)
            {
                fields = ReadTimeTuple(Localtime([], span, context), "time.strftime", span, context);
            }
            else
            {
                fields = ReadTimeTuple(arguments[1], "time.strftime", span, context);
            }

            ValidateDisplayFields(fields, span);
            var value = new PyDateTimeOps.StrftimeFields(fields.Year, fields.Month, fields.MonthDay,
                fields.Hour, fields.Minute, fields.Second, 0, fields.Weekday, fields.YearDay);
            var timezone = TimezoneForFormatting(fields, context, span);
            var result = PyDateTimeOps.FormatStrftime(
                value, timezone, format, span, context);
            return result;
        }

        private static object Strptime(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            if (!PyStringOps.TryAsString(arguments[0], out var text) ||
                arguments.Length >= 2 && !PyStringOps.TryAsString(arguments[1], out _))
            {
                throw new LythonRuntimeException("TypeError", "time.strptime(string[, format]) expects string arguments.", span);
            }

            var format = arguments.Length >= 2
                ? (PyString)arguments[1]
                : PyString.FromString("%a %b %d %H:%M:%S %Y");
            try
            {
                var parsed = PyDateTimeOps.ParseStrptimeFields(text, format, span, context);
                object zone = parsed.Timezone is not null && parsed.HasZoneName ? parsed.Timezone.Name : PyNone.Instance;
                object offset = parsed.Timezone is null ? PyNone.Instance : new BigInteger((long)parsed.Timezone.Offset.TotalSeconds);
                return new TimeStructTimeValue([
                    new BigInteger(parsed.Year), new BigInteger(parsed.Month), new BigInteger(parsed.Day),
                    new BigInteger(parsed.Hour), new BigInteger(parsed.Minute), new BigInteger(parsed.Second),
                    new BigInteger(parsed.Weekday), new BigInteger(parsed.YearDay), new BigInteger(parsed.HasZoneName ? 0 : -1)],
                    zone, offset, context.MemoryGovernor, span);
            }
            catch (FormatException ex)
            {
                throw new LythonRuntimeException("ValueError", ex.Message, span);
            }
            catch (ArgumentOutOfRangeException ex)
            {
                throw new LythonRuntimeException("ValueError", ex.Message, span);
            }
        }

        private static double UnixSeconds(DateTimeOffset value)
            => (value.UtcDateTime.Ticks - DateTime.UnixEpoch.Ticks) / (double)TimeSpan.TicksPerSecond;

        private static DateTimeOffset TimestampToInstant(object value, LythonSourceSpan span, LythonRuntime.ExecutionContext context)
        {
            // Timestamps convert through __index__ like CPython; remaining
            // rejections name the original type instead of the factory.
            var coerced = LythonRuntime.CoerceIndexProtocol(value, context, span);
            if (!PyNumberOps.TryAsNumber(coerced, out var number))
            {
                throw new LythonRuntimeException("TypeError", "'" + RuntimeErrors.DatetimeQualifiedTypeName(value, context) + "' object cannot be interpreted as an integer", span);
            }

            var seconds = number.ToDouble();
            if (double.IsNaN(seconds))
            {
                throw new LythonRuntimeException("ValueError", "Invalid value NaN (not a number)", span);
            }

            if (!double.IsFinite(seconds))
            {
                throw new LythonRuntimeException("OverflowError", "timestamp out of range for platform time_t", span);
            }

            try
            {
                var ticks = checked((long)Math.Round(seconds * TimeSpan.TicksPerSecond, MidpointRounding.ToEven));
                return DateTimeOffset.UnixEpoch.AddTicks(ticks);
            }
            catch (Exception ex) when (ex is OverflowException or ArgumentOutOfRangeException)
            {
                throw new LythonRuntimeException("OverflowError", "timestamp out of range for platform time_t", span);
            }
        }

        private static TimeFields ReadTimeTuple(object value, string owner, LythonSourceSpan span, ExecutionContext context)
        {
            IReadOnlyList<object> sequence = value switch
            {
                TimeStructTimeValue structTime => structTime,
                PyTuple tuple => tuple,
                PyNamedTupleObject namedTuple => namedTuple,
                _ => throw new LythonRuntimeException("TypeError", "Tuple or struct_time argument required", span),
            };

            if (sequence.Count != 9)
            {
                throw new LythonRuntimeException("TypeError", $"{LythonRuntime.BuiltinCallable.ShortCallableName(owner)}(): illegal time tuple argument", span);
            }

            return new TimeFields(
                IntegerField(sequence[0], span, context),
                IntegerField(sequence[1], span, context),
                IntegerField(sequence[2], span, context),
                IntegerField(sequence[3], span, context),
                IntegerField(sequence[4], span, context),
                IntegerField(sequence[5], span, context),
                IntegerField(sequence[6], span, context),
                IntegerField(sequence[7], span, context),
                IntegerField(sequence[8], span, context),
                value is TimeStructTimeValue timeValue ? timeValue.Zone : PyNone.Instance,
                value is TimeStructTimeValue offsetValue ? offsetValue.GmtOffset : PyNone.Instance);
        }

        private static int IntegerField(object value, LythonSourceSpan span, LythonRuntime.ExecutionContext context)
        {
            // Tuple fields convert through __index__ like CPython; the range
            // follows the int32 C-long convention used across the runtime.
            var coerced = LythonRuntime.CoerceIndexProtocol(value, context, span);
            if (!PyNumberOps.TryAsInteger(coerced, out var integer))
            {
                throw new LythonRuntimeException("TypeError", "'" + RuntimeErrors.DatetimeQualifiedTypeName(value, context) + "' object cannot be interpreted as an integer", span);
            }

            if (integer < int.MinValue || integer > int.MaxValue)
            {
                throw new LythonRuntimeException("OverflowError", "Python int too large to convert to C long", span);
            }

            return (int)integer;
        }

        private static DateTime CreateDateTime(TimeFields fields, string owner, LythonSourceSpan span)
        {
            try
            {
                return new DateTime(
                    fields.Year,
                    fields.Month,
                    fields.MonthDay,
                    fields.Hour,
                    fields.Minute,
                    fields.Second,
                    DateTimeKind.Unspecified);
            }
            catch (ArgumentOutOfRangeException ex)
            {
                throw new LythonRuntimeException("ValueError", $"{owner}(): {ex.Message}", span);
            }
        }

        private static string FormatAsctime(TimeFields fields, LythonSourceSpan span)
        {
            string[] weekdays = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
            string[] months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
            ValidateDisplayFields(fields, span);

            return FormattableString.Invariant(
                $"{weekdays[fields.Weekday]} {months[fields.Month - 1]} {fields.MonthDay,2} {fields.Hour:00}:{fields.Minute:00}:{fields.Second:00} {fields.Year}");
        }

        private static void ValidateDisplayFields(TimeFields fields, LythonSourceSpan span)
        {
            if (fields.Month is < 1 or > 12)
            {
                throw new LythonRuntimeException("ValueError", "month out of range", span);
            }

            if (fields.MonthDay is < 1 or > 31)
            {
                throw new LythonRuntimeException("ValueError", "day of month out of range", span);
            }

            if (fields.Hour is < 0 or > 23)
            {
                throw new LythonRuntimeException("ValueError", "hour out of range", span);
            }

            if (fields.Minute is < 0 or > 59)
            {
                throw new LythonRuntimeException("ValueError", "minute out of range", span);
            }

            if (fields.Second is < 0 or > 61)
            {
                throw new LythonRuntimeException("ValueError", "seconds out of range", span);
            }

            if (fields.Weekday is < 0 or > 6)
            {
                throw new LythonRuntimeException("ValueError", "invalid time tuple fields", span);
            }

        }

        private static PyTimezone TimezoneForFormatting(TimeFields fields, ExecutionContext context, LythonSourceSpan span)
        {
            if (fields.GmtOffset is not PyNone)
            {
                var seconds = IntegerField(fields.GmtOffset, span, context);
                try
                {
                    var name = PyStringOps.TryAsString(fields.Zone, out var zone) ? zone : PyString.Empty;
                    return new PyTimezone(TimeSpan.FromSeconds(seconds), name);
                }
                catch (OverflowException ex)
                {
                    throw new LythonRuntimeException("ValueError", ex.Message, span);
                }
            }

            context.CheckExecution(span);
            var offset = context.State.ReadHostLocalNow().Offset;
            return new PyTimezone(offset);
        }

        private static string FixedZoneName(TimeSpan offset)
            => offset == TimeSpan.Zero ? "UTC" : "UTC" + PyDateTimeOps.FormatOffset(offset);

        private sealed record TimeFields(
            int Year,
            int Month,
            int MonthDay,
            int Hour,
            int Minute,
            int Second,
            int Weekday,
            int YearDay,
            int IsDst,
            object Zone,
            object GmtOffset);
    }

}
