using System.Collections;
using System.Globalization;
using System.Numerics;
using Lokad.Lython.Runtime.Numbers;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal sealed partial class ExecutionContext
    {
        public long ReadHostMonotonicNanoseconds(LythonSourceSpan? span)
        {
            var timing = RequireHostTiming(span);
            CheckExecution(span);
            var value = HostOperation.Invoke(() => timing.MonotonicNanoseconds, "time.monotonic", span, MemoryGovernor);
            if (value < 0)
            {
                throw RuntimeErrors.Runtime("host timing capability returned a negative monotonic reading.", span);
            }

            return value;
        }

        public long ReadHostMonotonicResolutionNanoseconds(LythonSourceSpan? span)
        {
            var timing = RequireHostTiming(span);
            CheckExecution(span);
            var value = HostOperation.Invoke(() => timing.MonotonicResolutionNanoseconds, "time.get_clock_info", span, MemoryGovernor);
            if (value <= 0)
            {
                throw RuntimeErrors.Runtime("host timing capability returned a non-positive monotonic resolution.", span);
            }

            return value;
        }

        public void DelayHost(TimeSpan duration, LythonSourceSpan? span)
        {
            var timing = RequireHostTiming(span);
            CheckExecution(span);
            HostOperation.Await(timing, () => timing.DelayAsync(duration, State.CancellationToken), "time.sleep", span, MemoryGovernor);
        }

        public ValueTask DelayHostAsync(TimeSpan duration, LythonSourceSpan? span)
        {
            var timing = RequireHostTiming(span);
            CheckExecution(span);
            return HostOperation.AwaitAsync(() => timing.DelayAsync(duration, State.CancellationToken), "time.sleep", span, MemoryGovernor);
        }

        private ILythonTiming RequireHostTiming(LythonSourceSpan? span)
            => Host.Timing ?? throw RuntimeErrors.Capability(
                "host timing/sleep capability is not available in this host.",
                span);

    }
}
