using System.Numerics;
using System.Text;
using Lokad.Lython.Runtime.Numbers;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal readonly record struct PyRenderingContext(LythonRuntime.ExecutionContext Context);

internal static class PyRendering
{
    private static readonly PyString TrueLiteral = PyString.FromString("True");
    private static readonly PyString FalseLiteral = PyString.FromString("False");
    private static readonly PyString EmptySetLiteral = PyString.FromString("set()");
    private static readonly PyString FileLiteral = PyString.FromString("<file>");
    private static readonly PyString ObjectLiteral = PyString.FromString("<object>");

    // Mapping misses carry their key as the payload; like CPython, the key
    // renders through repr. Constructed values and domain errors without a
    // payload keep the stored message.
    private static PyString RenderExceptionMessage(PyException exception, PyRenderingContext context)
    {
        if (LythonRuntime.RenderCodecErrorAsync(exception, context, false).GetAwaiter().GetResult() is { } codecMessage) return codecMessage;
        if (LythonRuntime.RenderSubprocessErrorAsync(exception, context, false).GetAwaiter().GetResult() is { } processMessage) return processMessage;
        var args = exception.GetArgs(context.Context.MemoryGovernor);
        return args.Count switch
        {
            0 => PyString.Empty,
            1 when exception.TypeName == "KeyError" && exception.Identity.IsBuiltin => ToReprPyString(args[0], context),
            1 => ToInterpolatedPyString(args[0], context),
            _ => ToReprPyString(args, context),
        };
    }

    internal static async ValueTask<PyString> ToInterpolatedPyStringAsync(object value, PyRenderingContext context)
    {
        if (value is PyException exception) return await RenderExceptionAsync(exception, false, context).ConfigureAwait(false);
        if (value is not PyInstance instance) return ToInterpolatedPyString(value, context);
        context.Context.EnterInterpreterFrame(null);
        try { return await instance.RenderInterpolatedAsync(context).ConfigureAwait(false); }
        finally { context.Context.LeaveInterpreterFrame(); }
    }

    internal static async ValueTask<PyString> ToReprPyStringAsync(object value, PyRenderingContext context)
    {
        if (value is PyException exception) return await RenderExceptionAsync(exception, true, context).ConfigureAwait(false);
        if (value is not PyInstance instance) return ToReprPyString(value, context);
        context.Context.EnterInterpreterFrame(null);
        try { return await instance.RenderPythonAsync(context).ConfigureAwait(false); }
        finally { context.Context.LeaveInterpreterFrame(); }
    }

    private static async ValueTask<PyString> RenderExceptionAsync(PyException exception, bool repr, PyRenderingContext context)
    {
        context.Context.EnterInterpreterFrame(null);
        try
        {
            var args = exception.GetArgs(context.Context.MemoryGovernor);
            if (!repr)
            {
                if (await LythonRuntime.RenderCodecErrorAsync(exception, context, true).ConfigureAwait(false) is { } codecMessage) return codecMessage;
                if (await LythonRuntime.RenderSubprocessErrorAsync(exception, context, true).ConfigureAwait(false) is { } processMessage) return processMessage;
                if (args.Count == 0) return PyString.Empty;
                if (args.Count == 1) return exception.TypeName == "KeyError" && exception.Identity.IsBuiltin
                    ? await ToReprPyStringAsync(args[0], context).ConfigureAwait(false)
                    : await ToInterpolatedPyStringAsync(args[0], context).ConfigureAwait(false);
            }
            var builder = new GovernedByteBuilder(context.Context.MemoryGovernor);
            try
            {
                if (repr) builder.AppendString(exception.TypeName);
                builder.AppendAscii("(");
                for (var i = 0; i < args.Count; i++)
                {
                    context.Context.CheckExecution(null);
                    if (i > 0) builder.AppendAscii(", ");
                    builder.Append(await ToReprPyStringAsync(args[i], context).ConfigureAwait(false));
                }
                builder.AppendAscii(")");
                return builder.ToPyStringAndRelease();
            }
            finally { builder.Release(); }
        }
        finally { context.Context.LeaveInterpreterFrame(); }
    }

    public static PyString ToInterpolatedPyString(object value, PyRenderingContext context)
    {
        context.Context.EnterInterpreterFrame(null);
        try
        {
            if (value is IPyRenderableValue renderable)
            {
                return renderable.RenderInterpolated(context);
            }

            return value switch
            {
                PyNone => PyStringOps.NoneLiteral,
                bool boolean => boolean ? TrueLiteral : FalseLiteral,
                _ when PyNumberOps.TryAsInteger(value, out var integer) => RenderInteger(integer, context),
                double floating => PyString.FromString(Numbers.PyNumberOps.RenderFloat(floating), context.Context.MemoryGovernor),
                LythonRuntime.DictKeysView view => JoinRenderedReprValues("dict_keys([", view, "])", context),
                LythonRuntime.DictValuesView view => JoinRenderedReprValues("dict_values([", view, "])", context),
                LythonRuntime.DictItemsView view => JoinRenderedReprValues("dict_items([", view, "])", context),
                PyException exception => RenderExceptionMessage(exception, context),
                // Like CPython, str(match) renders the repr form, not the text.
                LythonRuntime.ReMatchObject match => ToReprPyString(match, context),
                LythonRuntime.ExecutionContext.TextFileHandle => FileLiteral,
                _ => RenderOpaqueObject()
            };
        }
        finally
        {
            context.Context.LeaveInterpreterFrame();
        }
    }

    public static PyString ToPythonPyString(object value, PyRenderingContext context)
    {
        context.Context.EnterInterpreterFrame(null);
        try
        {
            if (value is IPyRenderableValue renderable)
            {
                return renderable.RenderPython(context);
            }

            return value switch
            {
                PyNone => PyStringOps.NoneLiteral,
                bool boolean => boolean ? TrueLiteral : FalseLiteral,
                _ when PyNumberOps.TryAsInteger(value, out var integer) => RenderInteger(integer, context),
                double floating => PyString.FromString(Numbers.PyNumberOps.RenderFloat(floating), context.Context.MemoryGovernor),
                LythonRuntime.DictKeysView view => JoinRenderedReprValues("dict_keys([", view, "])", context),
                LythonRuntime.DictValuesView view => JoinRenderedReprValues("dict_values([", view, "])", context),
                LythonRuntime.DictItemsView view => JoinRenderedReprValues("dict_items([", view, "])", context),
                PyException exception => RenderExceptionMessage(exception, context),
                // Like CPython, str(match) renders the repr form, not the text.
                LythonRuntime.ReMatchObject match => ToReprPyString(match, context),
                LythonRuntime.ExecutionContext.TextFileHandle => FileLiteral,
                _ => RenderOpaqueObject()
            };
        }
        finally
        {
            context.Context.LeaveInterpreterFrame();
        }
    }

    private static PyString RenderInteger(BigInteger value, PyRenderingContext context)
    {
        var governor = context.Context.MemoryGovernor;
        if (value >= long.MinValue && value <= long.MaxValue)
        {
            // The sign and all signed-64 decimal digits fit in twenty bytes.
            Span<byte> buffer = stackalloc byte[20];
            if (!((long)value).TryFormat(buffer, out var written, provider: System.Globalization.CultureInfo.InvariantCulture))
                throw new InvalidOperationException("Integer formatting exceeded its fixed buffer.");
            return PyString.CopyFromUtf8(buffer[..written], governor, null);
        }

        // bit/3 overestimates decimal digits; include sign, metadata, UTF-16
        // text, active BCL conversion workspace/pool rounding and headroom.
        // Final UTF-8 admission overlaps this scratch until copying completes.
        using var scratch = governor.ReserveTemporary(RuntimeMemoryEstimates.EstimateIntegerRenderingWorkingBytes(value), null);
        return PyString.FromString(value.ToString(System.Globalization.CultureInfo.InvariantCulture), governor);
    }

    public static string ToPythonString(object value, PyRenderingContext context) => ToPythonPyString(value, context).AsString();

    public static string ToInterpolatedString(object value, PyRenderingContext context) => ToInterpolatedPyString(value, context).AsString();

    public static PyString ToReprPyString(object value, PyRenderingContext context)
        => ToReprPyStringCore(value, context, null);

    public static PyString JoinRenderedReprValues(
        string prefix,
        IEnumerable<object> values,
        string suffix,
        PyRenderingContext context)
    {
        var builder = new GovernedByteBuilder(context.Context.MemoryGovernor);
        builder.AppendString(prefix);
        var first = true;
        foreach (var value in values)
        {
            if (!first)
            {
                builder.AppendAscii(", ");
            }

            builder.Append(ToReprPyString(value, context));
            first = false;
        }

        builder.AppendString(suffix);
        return builder.ToPyStringAndRelease();
    }

    public static PyString JoinRenderedSequence(string prefix, IEnumerable<PyString> items, string suffix, PyRenderingContext context)
    {
        var builder = new GovernedByteBuilder(context.Context.MemoryGovernor);
        builder.AppendString(prefix);
        var first = true;
        foreach (var item in items)
        {
            if (!first)
            {
                builder.AppendAscii(", ");
            }

            builder.Append(item);
            first = false;
        }

        builder.AppendString(suffix);
        return builder.ToPyStringAndRelease();
    }

    public static PyString JoinRenderedValues(
        string prefix,
        IEnumerable<object> values,
        string suffix,
        PyRenderingContext context,
        bool interpolated)
    {
        var builder = new GovernedByteBuilder(context.Context.MemoryGovernor);
        builder.AppendString(prefix);
        var first = true;
        foreach (var value in values)
        {
            if (!first)
            {
                builder.AppendAscii(", ");
            }

            builder.Append(interpolated ? ToInterpolatedPyString(value, context) : ToPythonPyString(value, context));
            first = false;
        }

        builder.AppendString(suffix);
        return builder.ToPyStringAndRelease();
    }

    public static PyString RenderSingletonTuple(PyString item, MemoryGovernor governor)
    {
        var builder = new GovernedByteBuilder(governor);
        builder.AppendAscii("(");
        builder.Append(item);
        builder.Append(PyStringOps.CommaLiteral);
        builder.AppendAscii(")");
        return builder.ToPyStringAndRelease();
    }

    public static PyString JoinRenderedDictionary(IEnumerable<KeyValuePair<object, object>> pairs, PyRenderingContext context, bool interpolated)
    {
        var builder = new GovernedByteBuilder(context.Context.MemoryGovernor);
        builder.AppendAscii("{");
        var first = true;
        foreach (var pair in pairs)
        {
            if (!first)
            {
                builder.AppendAscii(", ");
            }

            builder.Append(RenderDictionaryKey(pair.Key, context, interpolated));
            builder.AppendAscii(": ");
            // String values render through repr like CPython on the
            // non-interpolated path; every other value already renders
            // identically through the value renderer.
            if (pair.Value is PyString text && !interpolated)
            {
                builder.Append(ToReprPyString(text, context));
            }
            else
            {
                builder.Append(interpolated ? ToInterpolatedPyString(pair.Value, context) : ToPythonPyString(pair.Value, context));
            }
            first = false;
        }

        builder.AppendAscii("}");
        return builder.ToPyStringAndRelease();
    }

    public static PyString RenderDictionaryKey(object key, PyRenderingContext context, bool interpolated)
    {
        // String keys render through repr like CPython on the
        // non-interpolated path (both live callers pass false), so quoting
        // and escapes match plain-dict rendering; the interpolated path
        // keeps its historical raw form.
        if (key is PyString text)
        {
            return interpolated
                ? JoinRenderedSequence("'", [text], "'", context)
                : ToReprPyString(text, context);
        }

        return interpolated ? ToInterpolatedPyString(key, context) : ToPythonPyString(key, context);
    }

    private static PyString ToReprPyStringCore(object value, PyRenderingContext context, HashSet<object>? activeContainers)
    {
        context.Context.EnterInterpreterFrame(null);
        try
        {
            if (PyStringOps.TryAsString(value, out var text))
            {
                return RenderStringLiteral(text, context);
            }

            return value switch
            {
                PyList list => RenderReprSequence(list, "[", "]", "[...]", context, activeContainers),
                PyTuple tuple => RenderReprTuple(tuple, context, activeContainers),
                PyDict dict => RenderReprDictionary(dict, context, activeContainers),
                PySet set => RenderReprSet(set, context, activeContainers),
                PyNone => PyStringOps.NoneLiteral,
                bool boolean => boolean ? TrueLiteral : FalseLiteral,
                _ when PyNumberOps.TryAsInteger(value, out var integer) => RenderInteger(integer, context),
                double floating => PyString.FromString(Numbers.PyNumberOps.RenderFloat(floating), context.Context.MemoryGovernor),
                LythonRuntime.DictKeysView view => RenderReprSequence(view, "dict_keys([", "])", "dict_keys([...])", context, activeContainers),
                LythonRuntime.DictValuesView view => RenderReprSequence(view, "dict_values([", "])", "dict_values([...])", context, activeContainers),
                LythonRuntime.DictItemsView view => RenderReprSequence(view, "dict_items([", "])", "dict_items([...])", context, activeContainers),
                PyException exception => RenderExceptionRepr(exception, context),
                LythonRuntime.ReMatchObject match => RenderMatchRepr(match, context, activeContainers),
                IPyRenderableValue renderable => renderable.RenderPython(context),
                _ => RenderOpaqueObject()
            };
        }
        finally
        {
            context.Context.LeaveInterpreterFrame();
        }
    }

    private static PyString RenderOpaqueObject() => ObjectLiteral;

    private static PyString RenderMatchRepr(
        LythonRuntime.ReMatchObject match,
        PyRenderingContext context,
        HashSet<object>? activeContainers)
    {
        var builder = new GovernedByteBuilder(context.Context.MemoryGovernor);
        builder.AppendAscii("<re.Match object; span=(");
        builder.AppendString(match.Start.ToString());
        builder.AppendAscii(", ");
        builder.AppendString(match.End.ToString());
        builder.AppendAscii("), match=");
        builder.Append(ToReprPyStringCore(match.MaterializeGroup(0, context.Context, PyStructuralGuard.AmbientSpan), context, activeContainers));
        builder.AppendAscii(">");
        return builder.ToPyStringAndRelease();
    }

    private static PyString RenderStringLiteral(PyString text, PyRenderingContext context)
    {
        var source = text.Utf8Span;
        var builder = new GovernedByteBuilder(context.Context.MemoryGovernor);
        // Like CPython, a string holding a single quote but no double quote
        // renders wrapped in double quotes with its singles left bare;
        // strings holding both, neither, or only doubles keep single quotes.
        var quote = source.IndexOf((byte)'\'') >= 0 && source.IndexOf((byte)'"') < 0 ? (byte)'"' : (byte)'\'';
        Span<byte> escape = stackalloc byte[10];
        long nextCheck = 0;
        try
        {
            builder.Append(quote);
            for (var cursor = 0; cursor < source.Length;)
            {
                if (cursor >= nextCheck)
                {
                    context.Context.State.CheckExecution(null);
                    nextCheck = (long)cursor + 1024;
                }
                Rune.DecodeFromUtf8(source[cursor..], out var rune, out var width);
                if (rune.Value == quote)
                {
                    builder.Append((byte)'\\');
                    builder.Append(quote);
                }
                else switch (rune.Value)
                {
                    case '\\': builder.AppendAscii("\\\\"); break;
                    case '\n': builder.AppendAscii("\\n"); break;
                    case '\r': builder.AppendAscii("\\r"); break;
                    case '\t': builder.AppendAscii("\\t"); break;
                    default:
                        if (PyStringOps.IsPrintableRune(rune))
                            builder.Append(source.Slice(cursor, width));
                        else
                        {
                            var digits = rune.Value <= 0xff ? 2 : rune.Value <= 0xffff ? 4 : 8;
                            escape[0] = (byte)'\\';
                            escape[1] = digits == 2 ? (byte)'x' : digits == 4 ? (byte)'u' : (byte)'U';
                            for (var digit = 0; digit < digits; digit++)
                                escape[digit + 2] = (byte)"0123456789abcdef"[(rune.Value >> (4 * (digits - digit - 1))) & 15];
                            builder.Append(escape[..(digits + 2)]);
                        }
                        break;
                }
                cursor += width;
            }
            builder.Append(quote);
            return builder.ToPyStringAndRelease();
        }
        finally { builder.Release(); }
    }

    private static PyString RenderReprTuple(PyTuple tuple, PyRenderingContext context, HashSet<object>? activeContainers)
    {
        activeContainers ??= new HashSet<object>(ReferenceEqualityComparer.Instance);
        if (!activeContainers.Add(tuple))
        {
            return PyString.FromString("(...)");
        }

        try
        {
            return tuple.Count == 1
                ? RenderSingletonTuple(ToReprPyStringCore(tuple[0], context, activeContainers), context.Context.MemoryGovernor)
                : RenderReprItems(tuple, "(", ")", context, activeContainers);
        }
        finally
        {
            activeContainers.Remove(tuple);
        }
    }

    private static PyString RenderReprSequence(
        IEnumerable<object> items,
        string prefix,
        string suffix,
        string recursiveLiteral,
        PyRenderingContext context,
        HashSet<object>? activeContainers)
    {
        activeContainers ??= new HashSet<object>(ReferenceEqualityComparer.Instance);
        if (!activeContainers.Add(items))
        {
            return PyString.FromString(recursiveLiteral);
        }

        try
        {
            return RenderReprItems(items, prefix, suffix, context, activeContainers);
        }
        finally
        {
            activeContainers.Remove(items);
        }
    }

    private static PyString RenderReprItems(
        IEnumerable<object> items,
        string prefix,
        string suffix,
        PyRenderingContext context,
        HashSet<object> activeContainers)
    {
        var builder = new GovernedByteBuilder(context.Context.MemoryGovernor);
        builder.AppendString(prefix);
        var first = true;
        foreach (var item in items)
        {
            if (!first)
            {
                builder.AppendAscii(", ");
            }

            builder.Append(ToReprPyStringCore(item, context, activeContainers));
            first = false;
        }

        builder.AppendString(suffix);
        return builder.ToPyStringAndRelease();
    }

    private static PyString RenderReprDictionary(PyDict dict, PyRenderingContext context, HashSet<object>? activeContainers)
    {
        activeContainers ??= new HashSet<object>(ReferenceEqualityComparer.Instance);
        if (!activeContainers.Add(dict))
        {
            return PyString.FromString("{...}");
        }

        try
        {
            var builder = new GovernedByteBuilder(context.Context.MemoryGovernor);
            builder.AppendAscii("{");
            var first = true;
            foreach (var pair in dict)
            {
                if (!first)
                {
                    builder.AppendAscii(", ");
                }

                builder.Append(ToReprPyStringCore(pair.Key, context, activeContainers));
                builder.AppendAscii(": ");
                builder.Append(ToReprPyStringCore(pair.Value, context, activeContainers));
                first = false;
            }

            builder.AppendAscii("}");
            return builder.ToPyStringAndRelease();
        }
        finally
        {
            activeContainers.Remove(dict);
        }
    }

    private static PyString RenderReprSet(PySet set, PyRenderingContext context, HashSet<object>? activeContainers)
    {
        if (set.Count == 0)
        {
            return EmptySetLiteral;
        }

        activeContainers ??= new HashSet<object>(ReferenceEqualityComparer.Instance);
        if (!activeContainers.Add(set))
        {
            return PyString.FromString("{...}");
        }

        try
        {
            var rendered = new List<PyString>(set.Count);
            foreach (var item in set)
            {
                rendered.Add(ToReprPyStringCore(item, context, activeContainers));
            }

            ExecutionSort.Sort(rendered, context.Context, null,
                (left, right) => PyString.CompareOrdinal(left, right, context.Context, null));
            return JoinRenderedSequence("{", rendered, "}", context);
        }
        finally
        {
            activeContainers.Remove(set);
        }
    }

    private static PyString RenderExceptionRepr(PyException exception, PyRenderingContext context)
    {
        var builder = new GovernedByteBuilder(context.Context.MemoryGovernor);
        try
        {
            builder.AppendString(exception.TypeName);
            builder.AppendAscii("(");
            var args = exception.GetArgs(context.Context.MemoryGovernor);
            for (var i = 0; i < args.Count; i++)
            {
                if (i > 0) builder.AppendAscii(", ");
                builder.Append(ToReprPyString(args[i], context));
            }
            builder.AppendAscii(")");
            return builder.ToPyStringAndRelease();
        }
        finally { builder.Release(); }
    }

}
