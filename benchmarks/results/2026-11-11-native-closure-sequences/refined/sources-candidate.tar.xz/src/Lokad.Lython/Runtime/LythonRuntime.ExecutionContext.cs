using System.Text.RegularExpressions;
using Lokad.Lython.Frontend;
using System.Numerics;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Threading;
using Lokad.Lython.Runtime.Numbers;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal sealed partial class ExecutionContext : ExecutionFrame
    {

        internal PyDict? GlobalNamespace;
        internal GlobalNamespaceStorage? GlobalNamespaceBacking;

        private bool? _postponedAnnotations;
        public bool PostponedAnnotations
        {
            get => _postponedAnnotations ?? ParentContext?.PostponedAnnotations ?? false;
            set => _postponedAnnotations = value;
        }
        public ExecutionContext(ILythonHost host, LythonRunOptions? options, ILythonRegexProvider? regexProvider = null,
            CompiledRegexPrograms? regexPrograms = null)
        {
            var builtinVariables = CreateBuiltinVariables();
            State = new ExecutionState(host, options, builtinVariables, regexProvider, regexPrograms);
            var sourcePath = options?.SourcePath is null ? null : PathOps.Normalize(options.SourcePath, host.Cwd);
            SourcePath = sourcePath;
            InitializeFrameVariables(CreateModuleVariables(sourcePath, "__main__"));
            FunctionClosureContext = this;
            ScopeFacts = ScopeDirectiveFacts.Empty;

            var globals = options?.Globals;
            if (globals is null)
            {
                return;
            }

            var normalizedContainers = new Dictionary<object, object>(ReferenceEqualityComparer.Instance);
            // The shared memo outlives every container it records; cover one
            // table slot per distinct entry transiently for the run (MG22).
            using var memoScratch = MemoryGovernor.ReserveTemporary(0, null);
            foreach (var pair in globals)
            {
                Frame.Variables[pair.Key] = NormalizeRuntimeValue(pair.Value, this, normalizedContainers, memoScratch);
            }
        }

        public ExecutionContext(ExecutionContext parent)
            : base(parent.Frame, new Dictionary<string, object>(StringComparer.Ordinal))
        {
            State = parent.State;
            SourcePath = parent.SourcePath;
            FunctionClosureContext = this;
            ScopeFacts = ScopeDirectiveFacts.Empty;
        }

        public static ExecutionContext CreateComprehension(ExecutionContext parent, ScopeDirectiveFacts? facts = null)
        {
            var scope = facts is null ? new ExecutionContext(parent) : new ExecutionContext(parent, facts);
            if (parent.IsClassBody || !ReferenceEquals(parent.FunctionClosureContext, parent))
            {
                // Comprehension bodies skip class dictionaries. Functions
                // they create still capture the class cell,
                // and share the comprehension's changing iteration variables.
                scope.FunctionClosureContext = new ExecutionContext(parent.FunctionClosureContext, scope.Variables, facts);
            }
            return scope;
        }

        private ExecutionContext(ExecutionContext parent, Dictionary<string, object> variables, ScopeDirectiveFacts? facts = null)
            : base(parent.Frame, variables)
        {
            State = parent.State;
            SourcePath = parent.SourcePath;
            FunctionClosureContext = this;
            ScopeFacts = facts ?? ScopeDirectiveFacts.Empty;
        }

        public ExecutionContext(ExecutionContext parent, ScopeDirectiveFacts scopeFacts)
            : base(parent.Frame)
        {
            State = parent.State;
            SourcePath = parent.SourcePath;
            FunctionClosureContext = this;
            ScopeFacts = scopeFacts;
            ValidateNonlocalTargets();
        }

        private void ValidateNonlocalTargets()
        {
            if (ScopeFacts.NonlocalNames.Count == 0) return;
            foreach (var name in ScopeFacts.NonlocalNames)
            {
                State.CheckExecution(null);
                if (FindNonlocalTarget(name) is null) throw RuntimeErrors.NameNotDefined(name, null);
            }
        }

        // Scope facts and lexical parent links are immutable. Executable reads
        // use their captured cells; dynamic reads/stores need no per-call map.
        private ExecutionContext? FindNonlocalTarget(string name)
        {
            for (var current = ParentContext; current?.ParentContext is not null; current = current.ParentContext)
            {
                if (current.IsClassBody) continue;
                if (current.ScopeFacts.IsGlobal(name)) break;
                if (current.ScopeFacts.LocalNames.Contains(name)) return current;
            }
            return null;
        }

        public static ExecutionContext CreateModule(
            ExecutionContext template,
            string? sourcePath,
            string moduleName)
            => new(template, new ModuleScope(sourcePath, moduleName));

        public static ExecutionContext CreateClassBody(ExecutionContext parent, ClassDefinitionStatementSyntax definition)
        {
            var scopeFacts = ScopeDirectiveFactsCollector.ForClass(definition);
            var context = new ExecutionContext(parent, ClassBodyScope.Instance, scopeFacts);
            context.Variables["__module__"] = ResolveName("__name__", definition.Span, GetGlobalContext(parent));
            InitializeModuleAnnotations(scopeFacts.ContainsVariableAnnotations ? definition.Body[0].Span : null, context);
            if (!scopeFacts.CreatesClassCell) return context;
            var closureParent = parent.FunctionClosureContext;
            ChargeClosureRetention(closureParent, parent.MemoryGovernor, definition.Span);
            const long bytes = ClosureContextBaseBytes + ClosureCellSlotBytes + 48L;
            parent.MemoryGovernor.Reserve(bytes, definition.Span);
            parent.MemoryGovernor.Commit(bytes);
            var cellScope = new ExecutionContext(closureParent, ClassCellSyntaxFacts.Scope)
            {
                MirrorLocalStores = true,
                ClosureRetentionCharged = true,
                ClosureChargedVariableCount = 1
            };
            cellScope.ClassCell = new ExecutableCell(null, cellScope, "__class__") { RetentionCharged = true };
            context.ClassCell = cellScope.ClassCell;
            context.FunctionClosureContext = cellScope;
            return context;
        }

        private ExecutionContext(ExecutionContext template, ModuleScope scope)
        {
            State = template.State;
            SourcePath = scope.SourcePath;
            InitializeFrameVariables(CreateModuleVariables(scope.SourcePath, scope.Name));
            FunctionClosureContext = this;
            ScopeFacts = ScopeDirectiveFacts.Empty;
        }

        private ExecutionContext(ExecutionContext parent, ClassBodyScope _, ScopeDirectiveFacts facts)
            : base((parent.IsClassBody ? parent.FunctionClosureContext : parent).Frame,
                new Dictionary<string, object>(StringComparer.Ordinal))
        {
            IsClassBody = true;
            State = parent.State;
            SourcePath = parent.SourcePath;
            FunctionClosureContext = parent.FunctionClosureContext;
            ScopeFacts = facts;
            ValidateNonlocalTargets();
        }

        private readonly record struct ModuleScope(string? SourcePath, string Name);

        private sealed class ClassBodyScope
        {
            public static readonly ClassBodyScope Instance = new();

            private ClassBodyScope() { }
        }

        public ExecutionState State { get; }

        // The namespace frame shares this context's identity and lifetime.
        public ExecutionFrame Frame => this;

        public string? SourcePath { get; }

        public ILythonHost Host => State.Host;

        // Context constructors already give the inherited frame this same
        // lexical parent; roots/modules leave it null. Keep one immutable link.
        public ExecutionContext? ParentContext => (ExecutionContext?)Parent;
        internal bool IsClassBody { get; }
        internal bool IsAnnotationScope { get; init; }
        internal bool IsTypeParameterScope { get; init; }
        // Lazy annotation scopes see the completed class dictionary; locals()
        // aliases retain the original body dictionary. Null outside that use.
        internal Dictionary<string, object>? AnnotationClassNamespace { get; set; }

        // Names the invoked function for nested-qualname resolution; null outside
        // function invocations (modules, class bodies and other plain scopes
        // contribute no segment). Set once per invocation frame.
        public string? FunctionName { get; internal set; }

        // MG11: closure-retention ownership marks. A function value retains its
        // defining context chain, so the first definition below a context owns
        // the context storage (base plus per-variable slots); later definitions
        // sharing the context pay only for variables bound since.
        internal bool ClosureRetentionCharged;

        internal int ClosureChargedVariableCount;

        public ExecutionContext FunctionClosureContext { get; private set; }
        internal ExecutableCell? ClassCell { get; private set; }

        internal bool TryGetLexicalClassCell([MaybeNullWhen(false)] out ExecutableCell cell)
        {
            for (var current = this; current is not null; current = current.ParentContext)
            {
                if (current.IsClassBody) continue;
                if (current.ClassCell is { } found)
                {
                    cell = found;
                    return true;
                }
                if (current.ScopeFacts.IsGlobal("__class__") || current.ScopeFacts.LocalNames.Contains("__class__") ||
                    current.FunctionName is not null && current.Frame.ContainsVariable("__class__")) break;
            }
            cell = null;
            return false;
        }

        internal ScopeDirectiveFacts ScopeFacts { get; }

        private bool _executableSlotsActive;
        internal ExecutionContext? CurrentExecutableFrame => _executableSlotsActive ? this : null;

        // Set once a lambda is born below this frame: executable locals live in
        // slots that vanish on return, so flagged frames also mirror slot stores
        // into Variables (catch-up at creation seeds current values), letting
        // escaped lambdas keep reading finals through the parent chain.
        internal bool MirrorLocalStores { get; set; }

        // Lexically enclosing except handlers entered but not yet exited, innermost
        // last; lets abrupt unwinding clear handler variables whose suite the
        // propagation abandons, mirroring CPython deleting them on suite exit.
        internal Stack<(string Name, int SuiteStart, int SuiteEnd)>? ActiveHandlerVariables { get; set; }

        // Static argument metadata only. The receiver itself stays in the actual
        // invocation's locals/cells and is read when zero-argument super runs.
        internal string? FirstPositionalParameterName { get; set; }
        internal ExecutableCell? ImplicitSuperClassCell { get; private set; }
        internal bool MissingImplicitSuperClassCell { get; private set; }

        public MemoryGovernor MemoryGovernor => State.MemoryGovernor;

        public new Dictionary<string, object> Variables => base.Variables;

        public PyDecimalContext DecimalContext => State.DecimalContext;

        public void SetDecimalContext(PyDecimalContext context) => State.DecimalContext = context;

        internal bool TryGetNonlocalTarget(string name, [MaybeNullWhen(false)] out ExecutionContext context)
        {
            context = ScopeFacts.IsNonlocal(name) ? FindNonlocalTarget(name) : null;
            return context is not null;
        }

        internal bool TryReadNonlocalValue(string name, [MaybeNullWhen(false)] out object value)
        {
            if (TryGetNonlocalTarget(name, out var target))
            {
                if (target.CurrentExecutableFrame is { } frame && frame.TryResolveLocalOrClosure(name, out value)) return true;
                if (target.Frame.TryGetVariable(name, out value)) return true;
            }
            value = null;
            return false;
        }

        internal bool MirrorsExecutableLocals { get; private set; }

        internal void EnterExecutableSlots()
        {
            _executableSlotsActive = true;
            MirrorsExecutableLocals = RequiresLocalVariableMirroring;
        }

        internal void LeaveExecutableSlots()
        {
            _executableSlotsActive = false;
        }

        internal bool TryResolveOwnLocal(string name, [MaybeNullWhen(false)] out object value)
        {
            if (TryGetInlinedBinding(name, out var scope)) return scope.Frame.TryGetVariable(name, out value);
            return CurrentExecutableFrame is { } frame ? frame.TryReadExecutableLocal(name, out value) : Frame.TryGetVariable(name, out value);
        }

        internal bool TryResolveImplicitClassValue(out object? value)
        {
            if (ScopeFacts.RequiresClassCell)
            {
                if (CurrentExecutableFrame is { } frame && frame.TryGetCell("__class__", out var captured))
                {
                    value = captured.Value;
                    return true;
                }
                for (var parent = ParentContext; parent?.ParentContext is not null; parent = parent.ParentContext)
                {
                    if (parent.IsClassBody) continue;
                    if (parent.ClassCell is { } classCell)
                    {
                        value = classCell.Value;
                        return true;
                    }
                    if (parent.ScopeFacts.IsGlobal("__class__")) break;
                    if (parent.ScopeFacts.LocalNames.Contains("__class__"))
                    {
                        value = parent.TryResolveOwnLocal("__class__", out var local) ? local : null;
                        return true;
                    }
                    if (parent.FunctionName is not null && parent.Frame.ContainsVariable("__class__")) break;
                }
            }
            if (!MissingImplicitSuperClassCell && ImplicitSuperClassCell is { } bound)
            {
                value = bound.Value;
                return true;
            }
            value = null;
            return false;
        }

        internal void BindImplicitSuper(ExecutableCell cell)
        {
            ImplicitSuperClassCell = cell;
        }

        internal void BindUnavailableImplicitSuper()
        {
            MissingImplicitSuperClassCell = true;
        }

        public void WriteHostBytes(string path,ReadOnlyMemory<byte> payload,LythonSourceSpan? span)
            => State.WriteHostBytes(path,payload,span);

        public ValueTask WriteHostBytesAsync(string path,ReadOnlyMemory<byte> payload,LythonSourceSpan? span)
            => State.WriteHostBytesAsync(path,payload,span);

        public bool HostExists(string path, LythonSourceSpan? span)
            => AwaitHost(Host, () => Host.ExistsAsync(PathOps.HostPathRequest(path, Host.Cwd, span, State.CancellationToken), State.CancellationToken), "exists", span);

        public ValueTask<bool> HostExistsAsync(string path, LythonSourceSpan? span)
            => AwaitHostAsync(() => Host.ExistsAsync(PathOps.HostPathRequest(path, Host.Cwd, span, State.CancellationToken), State.CancellationToken), "exists", span);

        public IReadOnlyList<string> HostListDir(string path, LythonSourceSpan? span)
            => AwaitHost(Host, () => Host.ListDirAsync(PathOps.HostPathRequest(path, Host.Cwd, span, State.CancellationToken), State.CancellationToken), "listdir", span);

        public ValueTask<IReadOnlyList<string>> HostListDirAsync(string path, LythonSourceSpan? span)
            => AwaitHostAsync(() => Host.ListDirAsync(PathOps.HostPathRequest(path, Host.Cwd, span, State.CancellationToken), State.CancellationToken), "listdir", span);

        public void HostMkDir(string path, LythonSourceSpan? span)
            => AwaitHost(Host, () => Host.MkDirAsync(PathOps.HostPathRequest(path, Host.Cwd, span, State.CancellationToken), State.CancellationToken), "mkdir", span);

        public ValueTask HostMkDirAsync(string path, LythonSourceSpan? span)
            => AwaitHostAsync(() => Host.MkDirAsync(PathOps.HostPathRequest(path, Host.Cwd, span, State.CancellationToken), State.CancellationToken), "mkdir", span);

        public void HostRemove(string path, LythonSourceSpan? span)
            => AwaitHost(Host, () => Host.RemoveAsync(PathOps.HostPathRequest(path, Host.Cwd, span, State.CancellationToken), State.CancellationToken), "remove", span);

        public ValueTask HostRemoveAsync(string path, LythonSourceSpan? span)
            => AwaitHostAsync(() => Host.RemoveAsync(PathOps.HostPathRequest(path, Host.Cwd, span, State.CancellationToken), State.CancellationToken), "remove", span);

        public void HostRemoveFile(string path, bool missingOk, LythonSourceSpan? span)
            => AwaitHost(Host, () => Host.RemoveFileAsync(PathOps.HostPathRequest(path, Host.Cwd, span, State.CancellationToken), missingOk, State.CancellationToken), "unlink", span);
        public ValueTask HostRemoveFileAsync(string path, bool missingOk, LythonSourceSpan? span)
            => AwaitHostAsync(() => Host.RemoveFileAsync(PathOps.HostPathRequest(path, Host.Cwd, span, State.CancellationToken), missingOk, State.CancellationToken), "unlink", span);
        public void HostRemoveDirectory(string path, LythonSourceSpan? span)
            => AwaitHost(Host, () => Host.RemoveDirectoryAsync(PathOps.HostPathRequest(path, Host.Cwd, span, State.CancellationToken), State.CancellationToken), "rmdir", span);
        public ValueTask HostRemoveDirectoryAsync(string path, LythonSourceSpan? span)
            => AwaitHostAsync(() => Host.RemoveDirectoryAsync(PathOps.HostPathRequest(path, Host.Cwd, span, State.CancellationToken), State.CancellationToken), "rmdir", span);
        public void HostReplace(string source, string destination, LythonSourceSpan? span)
            => AwaitHost(Host, () => Host.ReplaceAsync(PathOps.HostPathRequest(source, Host.Cwd, span, State.CancellationToken), PathOps.HostPathRequest(destination, Host.Cwd, span, State.CancellationToken), State.CancellationToken), "replace", span);
        public ValueTask HostReplaceAsync(string source, string destination, LythonSourceSpan? span)
            => AwaitHostAsync(() => Host.ReplaceAsync(PathOps.HostPathRequest(source, Host.Cwd, span, State.CancellationToken), PathOps.HostPathRequest(destination, Host.Cwd, span, State.CancellationToken), State.CancellationToken), "replace", span);

        public void HostCopy(string source, string destination, LythonSourceSpan? span)
            => AwaitHost(Host, () => Host.CopyAsync(PathOps.HostPathRequest(source, Host.Cwd, span, State.CancellationToken), PathOps.HostPathRequest(destination, Host.Cwd, span, State.CancellationToken), State.CancellationToken), "copy", span);

        public ValueTask HostCopyAsync(string source, string destination, LythonSourceSpan? span)
            => AwaitHostAsync(() => Host.CopyAsync(PathOps.HostPathRequest(source, Host.Cwd, span, State.CancellationToken), PathOps.HostPathRequest(destination, Host.Cwd, span, State.CancellationToken), State.CancellationToken), "copy", span);

        public void HostMove(string source, string destination, LythonSourceSpan? span)
            => AwaitHost(Host, () => Host.MoveAsync(PathOps.HostPathRequest(source, Host.Cwd, span, State.CancellationToken), PathOps.HostPathRequest(destination, Host.Cwd, span, State.CancellationToken), State.CancellationToken), "move", span);

        public ValueTask HostMoveAsync(string source, string destination, LythonSourceSpan? span)
            => AwaitHostAsync(() => Host.MoveAsync(PathOps.HostPathRequest(source, Host.Cwd, span, State.CancellationToken), PathOps.HostPathRequest(destination, Host.Cwd, span, State.CancellationToken), State.CancellationToken), "move", span);

        public LythonPathStat HostStat(string path, LythonSourceSpan? span)
            => AwaitHost(Host, () => Host.StatAsync(PathOps.HostPathRequest(path, Host.Cwd, span, State.CancellationToken), State.CancellationToken), "stat", span);

        public ValueTask<LythonPathStat> HostStatAsync(string path, LythonSourceSpan? span)
            => AwaitHostAsync(() => Host.StatAsync(PathOps.HostPathRequest(path, Host.Cwd, span, State.CancellationToken), State.CancellationToken), "stat", span);

        public LythonSubprocessResult RunSubprocess(LythonSubprocessRequest request, LythonSourceSpan? span)
        {
            var runner = Host.SubprocessRunner;
            if (runner is null)
            {
                throw RuntimeErrors.Capability("subprocess is not available in this host.", span);
            }

            var result = AwaitHost(runner, () => runner.RunAsync(request, State.CancellationToken), "subprocess.run", span);
            return result;
        }

        public async ValueTask<LythonSubprocessResult> RunSubprocessAsync(LythonSubprocessRequest request, LythonSourceSpan? span)
        {
            var runner = Host.SubprocessRunner;
            if (runner is null)
            {
                throw RuntimeErrors.Capability("subprocess is not available in this host.", span);
            }

            var result = await AwaitHostAsync(() => runner.RunAsync(request, State.CancellationToken), "subprocess.run", span).ConfigureAwait(false);
            return result;
        }

        private T AwaitHost<T>(object capability, Func<ValueTask<T>> operation, string name, LythonSourceSpan? span)
            => HostOperation.Await(capability, operation, name, span, MemoryGovernor);

        private void AwaitHost(object capability, Func<ValueTask> operation, string name, LythonSourceSpan? span)
            => HostOperation.Await(capability, operation, name, span, MemoryGovernor);

        private ValueTask<T> AwaitHostAsync<T>(Func<ValueTask<T>> operation, string name, LythonSourceSpan? span)
            => HostOperation.AwaitAsync(operation, name, span, MemoryGovernor);

        private ValueTask AwaitHostAsync(Func<ValueTask> operation, string name, LythonSourceSpan? span)
            => HostOperation.AwaitAsync(operation, name, span, MemoryGovernor);

        public bool TryGetBuiltinType(string name, [MaybeNullWhen(false)] out PyType type)
        {
            if (TryGetBuiltin(name, out var value) && value is PyType resolved)
            {
                type = resolved;
                return true;
            }

            type = null;
            return false;
        }

        // Implicit class identity and builtin base graphs use the run's canonical
        // table. Guest name resolution belongs to frames and may shadow this table.
        public bool TryGetBuiltin(string name, [MaybeNullWhen(false)] out object value)
            => State.BuiltinVariables.TryGetValue(name, out value);

        private static Dictionary<string, object> CreateModuleVariables(
            string? sourcePath,
            string moduleName)
        {
            var variables = new Dictionary<string, object>(2, StringComparer.Ordinal)
            {
                ["__name__"] = PyString.FromString(moduleName)
            };

            if (!string.IsNullOrWhiteSpace(sourcePath))
            {
                variables["__file__"] = PyString.FromString(PathOps.Normalize(sourcePath));
            }

            return variables;
        }

        private const int MaxGlobalNormalizationDepth = 1_000;

        // One memo-table slot per distinct normalized container, covering the
        // shared identity map plus its growth slack (MG22). The path-only
        // active set stays bounded by MaxGlobalNormalizationDepth.
        private const long MemoEntryBytes = 64;

        private static object NormalizeRuntimeValue(object? value, ExecutionContext context, Dictionary<object, object> normalizedContainers, MemoryGovernor.TemporaryMemoryReservation memoScratch)
            => NormalizeRuntimeValue(
                value,
                context,
                new HashSet<object>(ReferenceEqualityComparer.Instance),
                normalizedContainers,
                memoScratch,
                depth: 0);

        private static object NormalizeRuntimeValue(
            object? value,
            ExecutionContext context,
            HashSet<object> activeContainers,
            Dictionary<object, object> normalizedContainers,
            MemoryGovernor.TemporaryMemoryReservation memoScratch,
            int depth)
        {
            if (depth > MaxGlobalNormalizationDepth)
            {
                throw RuntimeErrors.Type($"initial global values cannot be nested more than {MaxGlobalNormalizationDepth} levels", null);
            }

            switch (value)
            {
                case null:
                case PyNone:
                    return PyNone.Instance;
                case bool boolean:
                    return RuntimeValue(boolean);
                case BigInteger:
                    return OwnFreshInteger(value!, context.MemoryGovernor, null);
                case sbyte integer:
                    return integer;
                case byte integer:
                    return integer;
                case short integer:
                    return integer;
                case ushort integer:
                    return integer;
                case int integer:
                    return integer;
                case uint integer:
                    return integer;
                case long integer:
                    return integer;
                case ulong integer:
                    return integer;
                case float floating:
                    return (double)floating;
                case double floating:
                    return floating;
                case decimal number:
                    return OwnDecimalValue(new PyDecimal(number), context, null);
                case string text:
                    return CreateString(text, context, null);
                case PyString text:
                    return CreateString(text.AsString(), context, null);
                case byte[] bytes:
                    return CreateBytes(bytes.ToArray(), context, null);
                case PyBytes bytes:
                    return CreateBytes(bytes.ToArray(), context, null);
            }

            var valueType = value.GetType();
            return valueType == typeof(PyList)
                ? NormalizeContainer(value, activeContainers, normalizedContainers, memoScratch, () => NormalizePyList((PyList)value, context, activeContainers, normalizedContainers, memoScratch, depth + 1))
                : valueType == typeof(PyTuple)
                    ? NormalizeContainer(value, activeContainers, normalizedContainers, memoScratch, () => NormalizePyTuple((PyTuple)value, context, activeContainers, normalizedContainers, memoScratch, depth + 1))
                    : valueType == typeof(List<object?>)
                        ? NormalizeContainer(value, activeContainers, normalizedContainers, memoScratch, () => NormalizeObjectList((List<object?>)value, context, activeContainers, normalizedContainers, memoScratch, depth + 1))
                        : valueType == typeof(object?[])
                            ? NormalizeContainer(value, activeContainers, normalizedContainers, memoScratch, () => NormalizeObjectArray((object?[])value, context, activeContainers, normalizedContainers, memoScratch, depth + 1))
                            : valueType == typeof(PySet)
                                ? NormalizeContainer(value, activeContainers, normalizedContainers, memoScratch, () => NormalizePySet((PySet)value, context, activeContainers, normalizedContainers, memoScratch, depth + 1))
                                : valueType == typeof(HashSet<object?>)
                                    ? NormalizeContainer(value, activeContainers, normalizedContainers, memoScratch, () => NormalizeObjectSet((HashSet<object?>)value, context, activeContainers, normalizedContainers, memoScratch, depth + 1))
                                    : valueType == typeof(Dictionary<string, object?>)
                                        ? NormalizeContainer(value, activeContainers, normalizedContainers, memoScratch, () => NormalizeStringKeyDictionary((Dictionary<string, object?>)value, context, activeContainers, normalizedContainers, memoScratch, depth + 1))
                                        : valueType == typeof(Dictionary<object, object?>)
                                            ? NormalizeContainer(value, activeContainers, normalizedContainers, memoScratch, () => NormalizeObjectKeyDictionary((Dictionary<object, object?>)value, context, activeContainers, normalizedContainers, memoScratch, depth + 1))
                                            : valueType == typeof(PyDict)
                                                ? NormalizeContainer(value, activeContainers, normalizedContainers, memoScratch, () => NormalizePyDict((PyDict)value, context, activeContainers, normalizedContainers, memoScratch, depth + 1))
                                                : throw RuntimeErrors.Type("initial global values may contain only supported scalar and collection values", null);

            static T NormalizeContainer<T>(object container, HashSet<object> activeContainers, Dictionary<object, object> normalizedContainers, MemoryGovernor.TemporaryMemoryReservation memoScratch, Func<T> normalize)
            {
                if (normalizedContainers.TryGetValue(container, out var existing))
                {
                    return (T)existing;
                }

                if (!activeContainers.Add(container))
                {
                    throw RuntimeErrors.Type("initial global values cannot contain reference cycles", null);
                }

                memoScratch.Grow(MemoEntryBytes, null);
                try
                {
                    var result = normalize();
                    normalizedContainers[container] = result!;
                    return result;
                }
                finally
                {
                    activeContainers.Remove(container);
                }
            }

            static PyList NormalizePyList(
                PyList list,
                ExecutionContext context,
                HashSet<object> activeContainers,
                Dictionary<object, object> normalizedContainers,
                MemoryGovernor.TemporaryMemoryReservation memoScratch,
                int depth)
            {
                context.CheckExecution(null);
                // The items array duplicates the retained copy below while it
                // is built; hold it transiently (MG22).
                using var scratch = context.MemoryGovernor.ReserveTemporary(16L * list.Count, null);
                var items = new object[list.Count];
                for (var i = 0; i < list.Count; i++)
                {
                    items[i] = NormalizeRuntimeValue(list[i], context, activeContainers, normalizedContainers, memoScratch, depth);
                }

                return new PyList(items, context.MemoryGovernor, null);
            }

            static PyTuple NormalizePyTuple(
                PyTuple tuple,
                ExecutionContext context,
                HashSet<object> activeContainers,
                Dictionary<object, object> normalizedContainers,
                MemoryGovernor.TemporaryMemoryReservation memoScratch,
                int depth)
            {
                context.CheckExecution(null);
                // Same transient items-array peak as NormalizePyList (MG22).
                using var scratch = context.MemoryGovernor.ReserveTemporary(16L * tuple.Count, null);
                var items = new object[tuple.Count];
                for (var i = 0; i < tuple.Count; i++)
                {
                    items[i] = NormalizeRuntimeValue(tuple[i], context, activeContainers, normalizedContainers, memoScratch, depth);
                }

                return new PyTuple(items, context.MemoryGovernor, null);
            }

            static PyList NormalizeObjectList(
                List<object?> list,
                ExecutionContext context,
                HashSet<object> activeContainers,
                Dictionary<object, object> normalizedContainers,
                MemoryGovernor.TemporaryMemoryReservation memoScratch,
                int depth)
            {
                context.CheckExecution(null);
                // Same transient items-array peak as NormalizePyList (MG22).
                using var scratch = context.MemoryGovernor.ReserveTemporary(16L * list.Count, null);
                var items = new object[list.Count];
                for (var i = 0; i < list.Count; i++)
                {
                    items[i] = NormalizeRuntimeValue(list[i], context, activeContainers, normalizedContainers, memoScratch, depth);
                }

                return new PyList(items, context.MemoryGovernor, null);
            }

            static PyTuple NormalizeObjectArray(
                object?[] tuple,
                ExecutionContext context,
                HashSet<object> activeContainers,
                Dictionary<object, object> normalizedContainers,
                MemoryGovernor.TemporaryMemoryReservation memoScratch,
                int depth)
            {
                context.CheckExecution(null);
                // Same transient items-array peak as NormalizePyList (MG22).
                using var scratch = context.MemoryGovernor.ReserveTemporary(16L * tuple.Length, null);
                var items = new object[tuple.Length];
                for (var i = 0; i < tuple.Length; i++)
                {
                    items[i] = NormalizeRuntimeValue(tuple[i], context, activeContainers, normalizedContainers, memoScratch, depth);
                }

                return new PyTuple(items, context.MemoryGovernor, null);
            }

            static PySet NormalizePySet(
                PySet set,
                ExecutionContext context,
                HashSet<object> activeContainers,
                Dictionary<object, object> normalizedContainers,
                MemoryGovernor.TemporaryMemoryReservation memoScratch,
                int depth)
            {
                context.CheckExecution(null);
                var normalized = new PySet(context.MemoryGovernor, null);
                foreach (var item in set)
                {
                    normalized.Add(RuntimeValue(NormalizeRuntimeValue(item, context, activeContainers, normalizedContainers, memoScratch, depth)));
                }

                return normalized;
            }

            static PySet NormalizeObjectSet(
                HashSet<object?> set,
                ExecutionContext context,
                HashSet<object> activeContainers,
                Dictionary<object, object> normalizedContainers,
                MemoryGovernor.TemporaryMemoryReservation memoScratch,
                int depth)
            {
                context.CheckExecution(null);
                var normalized = new PySet(context.MemoryGovernor, null);
                foreach (var item in set)
                {
                    normalized.Add(RuntimeValue(NormalizeRuntimeValue(item, context, activeContainers, normalizedContainers, memoScratch, depth)));
                }

                return normalized;
            }

            static PyDict NormalizeStringKeyDictionary(
                Dictionary<string, object?> dict,
                ExecutionContext context,
                HashSet<object> activeContainers,
                Dictionary<object, object> normalizedContainers,
                MemoryGovernor.TemporaryMemoryReservation memoScratch,
                int depth)
            {
                context.CheckExecution(null);
                var normalized = new PyDict(context.MemoryGovernor, null);
                foreach (var pair in dict)
                {
                    normalized.SetItem(CreateString(pair.Key, context, null), NormalizeRuntimeValue(pair.Value, context, activeContainers, normalizedContainers, memoScratch, depth));
                }

                return normalized;
            }

            static PyDict NormalizeObjectKeyDictionary(
                Dictionary<object, object?> dict,
                ExecutionContext context,
                HashSet<object> activeContainers,
                Dictionary<object, object> normalizedContainers,
                MemoryGovernor.TemporaryMemoryReservation memoScratch,
                int depth)
            {
                context.CheckExecution(null);
                var normalized = new PyDict(context.MemoryGovernor, null);
                foreach (var pair in dict)
                {
                    normalized.SetItem(
                        ValidateDictionaryKey(NormalizeRuntimeValue(pair.Key, context, activeContainers, normalizedContainers, memoScratch, depth), null),
                        NormalizeRuntimeValue(pair.Value, context, activeContainers, normalizedContainers, memoScratch, depth));
                }

                return normalized;
            }

            static PyDict NormalizePyDict(
                PyDict dict,
                ExecutionContext context,
                HashSet<object> activeContainers,
                Dictionary<object, object> normalizedContainers,
                MemoryGovernor.TemporaryMemoryReservation memoScratch,
                int depth)
            {
                context.CheckExecution(null);
                var normalized = new PyDict(context.MemoryGovernor, null);
                foreach (var pair in dict)
                {
                    normalized.SetItem(
                        ValidateDictionaryKey(NormalizeRuntimeValue(pair.Key, context, activeContainers, normalizedContainers, memoScratch, depth), null),
                        NormalizeRuntimeValue(pair.Value, context, activeContainers, normalizedContainers, memoScratch, depth));
                }

                return normalized;
            }
        }

        public void CheckExecution(LythonSourceSpan? span) => State.CheckExecution(span);

        public void EnterFunctionCall(LythonSourceSpan? span)
        {
            State.EnterFunctionCall(span);
        }

        public void LeaveFunctionCall()
        {
            State.LeaveFunctionCall();
        }

        public void EnterInterpreterFrame(LythonSourceSpan? span) => State.EnterInterpreterFrame(span);

        public void LeaveInterpreterFrame() => State.LeaveInterpreterFrame();
    }

}
