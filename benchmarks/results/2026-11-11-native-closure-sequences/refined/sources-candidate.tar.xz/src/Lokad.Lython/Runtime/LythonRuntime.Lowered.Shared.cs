using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Calls;
using Lokad.Lython.Runtime.Text;
using System.Numerics;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    private delegate ValueTask<LoweredBlockFlow> LoweredStatementBlockExecutor(
        IReadOnlyList<LoweredStatement> statements,
        ExecutionContext context);

    private delegate ValueTask<object> LoweredExpressionEvaluator(LoweredExpression expression);

    private static async ValueTask<LoweredBlockFlow> DispatchLoweredStatementAsync(
        LoweredStatement statement,
        ExecutionContext context,
        ILoweredStatementExecution execution)
    {
        switch (statement)
        {
            case LoweredTypeAliasStatement alias:
                ExecuteTypeAlias(alias, context);
                return default;
            case LoweredImportStatement importStatement:
                await execution.ExecuteImportAsync(importStatement, context).ConfigureAwait(false);
                return default;
            case LoweredScopeDirectiveStatement:
                return default;
            case LoweredFunctionDefinitionStatement functionDefinition:
                await execution.ExecuteFunctionDefinitionAsync(functionDefinition, context).ConfigureAwait(false);
                return default;
            case LoweredClassDefinitionStatement classDefinition:
                await execution.ExecuteClassDefinitionAsync(classDefinition, context).ConfigureAwait(false);
                return default;
            case LoweredAssignmentStatement assignment:
                await execution.ExecuteAssignmentAsync(assignment, context).ConfigureAwait(false);
                return default;
            case LoweredExpressionStatement expression:
                _ = await execution.EvaluateExpressionAsync(expression.Expression, context).ConfigureAwait(false);
                return default;
            case LoweredIfStatement ifStatement:
                await execution.ExecuteIfAsync(ifStatement, context).ConfigureAwait(false);
                return default;
            case LoweredForStatement forStatement:
                await execution.ExecuteForAsync(forStatement, context).ConfigureAwait(false);
                return default;
            case LoweredWhileStatement whileStatement:
                await execution.ExecuteWhileAsync(whileStatement, context).ConfigureAwait(false);
                return default;
            case LoweredMatchStatement matchStatement:
                await execution.ExecuteMatchAsync(matchStatement, context).ConfigureAwait(false);
                return default;
            case LoweredWithStatement withStatement:
                await execution.ExecuteWithAsync(withStatement, context).ConfigureAwait(false);
                return default;
            case LoweredTryStatement tryStatement:
                await execution.ExecuteTryAsync(tryStatement, context).ConfigureAwait(false);
                return default;
            case LoweredPassStatement:
                return default;
            case LoweredBreakStatement:
                throw new BreakSignal();
            case LoweredContinueStatement:
                throw new ContinueSignal();
            case LoweredAssertStatement assertStatement:
                await execution.ExecuteAssertAsync(assertStatement, context).ConfigureAwait(false);
                return default;
            case LoweredDeleteStatement deleteStatement:
                await execution.ExecuteDeleteAsync(deleteStatement, context).ConfigureAwait(false);
                return default;
            case LoweredReturnStatement returnStatement:
                if (returnStatement.Expression is null)
                {
                    return new LoweredBlockFlow(null, new ReturnSignal(PyNone.Instance));
                }

                var returnValue = await execution.EvaluateExpressionAsync(returnStatement.Expression, context).ConfigureAwait(false);
                return new LoweredBlockFlow(null, new ReturnSignal(RuntimeValue(returnValue)));
            case LoweredRaiseStatement raiseStatement:
                await execution.ExecuteRaiseAsync(raiseStatement, context).ConfigureAwait(false);
                return default;
            case LoweredOtherStatement other:
                throw new InvalidOperationException($"Generic lowered statement fallback reached for supported execution: {other.Syntax.GetType().Name}");
            default:
                throw new InvalidOperationException($"Unknown lowered statement kind: {statement.GetType().Name}");
        }
    }

    private static async ValueTask<object> DispatchLoweredExpressionAsync(
        LoweredExpression expression,
        ExecutionContext context,
        ILoweredExpressionExecution execution)
    {
        switch (expression)
        {
            case LoweredCapturedExpression captured:
                return captured.Value;
            case LoweredUnpackedTypeExpression unpacked:
                var unpackedValue = await execution.EvaluateExpressionAsync(unpacked.Value, context).ConfigureAwait(false);
                return await execution.UnpackAnnotationAsync(unpackedValue, context, unpacked.Span).ConfigureAwait(false);
            case LoweredIdentifierExpression identifier:
                return ResolveIdentifier(identifier.Identifier, context);
            case LoweredStringLiteralExpression text:
                return text.Value;
            case LoweredBytesLiteralExpression bytes:
                var bytesValue = bytes.Value;
                return bytesValue;
            case LoweredIntegerLiteralExpression integer:
                return integer.Value;
            case LoweredImaginaryLiteralExpression imaginary:
                return PyComplex.Create(0, Numbers.PyNumberOps.ParseFloat(imaginary.Literal.ValueText[..^1]), context, imaginary.Span);
            case LoweredFloatLiteralExpression floating:
                return ParseFloat(floating.Literal);
            case LoweredBooleanLiteralExpression boolean:
                return boolean.Literal.Value;
            case LoweredNoneLiteralExpression:
                return PyNone.Instance;
            case LoweredEllipsisLiteralExpression:
                return PyEllipsis.Instance;
            case LoweredFormattedStringExpression formatted:
                return await execution.EvaluateFormattedAsync(formatted, context).ConfigureAwait(false);
            case LoweredParenthesizedExpression parenthesized:
                return await execution.EvaluateExpressionAsync(parenthesized.Inner, context).ConfigureAwait(false);
            case LoweredListLiteralExpression list:
                return await execution.EvaluateListLiteralAsync(list, context).ConfigureAwait(false);
            case LoweredListComprehensionExpression comprehension:
                return await execution.EvaluateListComprehensionAsync(comprehension, context).ConfigureAwait(false);
            case LoweredGeneratorExpression generator:
            {
                // Acquire the outermost iterable eagerly, exactly as the synchronous
                // construction site does; user __iter__ still resolves synchronously
                // here (async-capable resolution belongs to a separate change).
                var outer = await execution.EvaluateExpressionAsync(generator.Clauses[0].Iterable, context).ConfigureAwait(false);
                var producedAsync = new PyGeneratorExpression(
                    generator.Clauses,
                    generator.ItemExpression,
                    context.FunctionClosureContext,
                    generator.Span,
                    await PyIteration.AcquireGeneratorOuterAsync(outer, generator.Clauses[0].Iterable.Span, context).ConfigureAwait(false), generator.ScopeFacts);
                producedAsync.AttachAsyncOuter(outer);
                return producedAsync;
            }
            case LoweredTupleLiteralExpression tuple:
                return await execution.EvaluateTupleLiteralAsync(tuple, context).ConfigureAwait(false);
            case LoweredSetLiteralExpression set:
                return await execution.EvaluateSetLiteralAsync(set, context).ConfigureAwait(false);
            case LoweredSetComprehensionExpression comprehension:
                return await execution.EvaluateSetComprehensionAsync(comprehension, context).ConfigureAwait(false);
            case LoweredDictLiteralExpression dictionary:
                return await execution.EvaluateDictionaryLiteralAsync(dictionary, context).ConfigureAwait(false);
            case LoweredDictComprehensionExpression comprehension:
                return await execution.EvaluateDictionaryComprehensionAsync(comprehension, context).ConfigureAwait(false);
            case LoweredMemberExpression member:
                return await execution.ResolveMemberAsync(member, context).ConfigureAwait(false);
            case LoweredCallExpression call:
                return await execution.InvokeCallAsync(call, context).ConfigureAwait(false);
            case LoweredSubscriptExpression subscript:
                return await execution.EvaluateSubscriptAsync(subscript, context).ConfigureAwait(false);
            case LoweredSliceExpression slice:
                return await execution.EvaluateSliceAsync(slice, context).ConfigureAwait(false);
            case LoweredSliceValueExpression slice:
                return await execution.EvaluateSliceValueAsync(slice, context).ConfigureAwait(false);
            case LoweredBinaryExpression binary:
                return await execution.EvaluateBinaryAsync(binary, context).ConfigureAwait(false);
            case LoweredChainedComparisonExpression chained:
                return await execution.EvaluateChainedComparisonAsync(chained, context).ConfigureAwait(false);
            case LoweredUnaryExpression unary:
                return await execution.EvaluateUnaryAsync(unary, context).ConfigureAwait(false);
            case LoweredConditionalExpression conditional:
                var condition = await execution.EvaluateExpressionAsync(conditional.Condition, context).ConfigureAwait(false);
                return await execution.IsTruthyAsync(condition, context, conditional.Condition.Span).ConfigureAwait(false)
                    ? await execution.EvaluateExpressionAsync(conditional.Consequent, context).ConfigureAwait(false)
                    : await execution.EvaluateExpressionAsync(conditional.Alternative, context).ConfigureAwait(false);
            case LoweredAssignmentExpression assignment:
                return await execution.EvaluateAssignmentAsync(assignment, context).ConfigureAwait(false);
            case LoweredLambdaExpression lambda:
                return await execution.CreateLambdaAsync(lambda, context).ConfigureAwait(false);
            default:
                throw new InvalidOperationException($"Unknown lowered expression type: {expression.GetType().Name}");
        }
    }

    private static async ValueTask<PyString> EvaluateLoweredFormattedStringPartsCoreAsync(
        IReadOnlyList<LoweredFormattedStringPart> parts,
        ExecutionContext context,
        LythonSourceSpan span,
        LoweredExpressionEvaluator evaluateExpression,
        bool asynchronous)
    {
        var builder = new GovernedByteBuilder(context.MemoryGovernor, span);
        try
        {
            foreach (var part in parts)
            {
                switch (part)
                {
                    case LoweredFormattedStringTextPart text:
                        builder.AppendString(text.Text);
                        break;
                    case LoweredFormattedStringExpressionPart expression:
                        var value = await evaluateExpression(expression.Expression).ConfigureAwait(false);
                        if (expression.Conversion is { } conversion)
                            value = await FormatSuspendedFieldAsync(value, conversion, null, context, span, asynchronous).ConfigureAwait(false);
                        var formatSpecifier = expression.FormatSpecifierParts is null
                            ? expression.FormatSpecifier
                            : (await EvaluateLoweredFormattedStringPartsCoreAsync(
                                expression.FormatSpecifierParts, context, span, evaluateExpression, asynchronous).ConfigureAwait(false)).AsString();
                        if (value is PyInstance instance)
                            builder.Append(await FormatInstanceFieldAsync(instance, null, formatSpecifier, context, span, asynchronous).ConfigureAwait(false));
                        else AppendInterpolatedStringPart(builder, value, null, formatSpecifier, context, span);
                        break;
                    default:
                        throw new InvalidOperationException($"Unknown lowered formatted string part: {part.GetType().Name}");
                }
            }
            var result = builder.ToPyStringAndRelease();
            context.CheckExecution(span);
            return result;
        }
        finally { builder.Release(); }
    }

    private static async ValueTask<LoweredBlockFlow> ExecuteTryStatementCoreAsync(
        LoweredTryStatement statement,
        ExecutionContext context,
        LoweredStatementBlockExecutor executeStatements,
        LoweredExpressionEvaluator evaluateExpression)
    {
        ControlSignal? pendingControl = null;
        ReturnSignal? pendingReturn = null;
        LythonRuntimeException? pendingException = null;

        var tryCompleted = false;
        try
        {
            try
            {
                var tryFlow = await executeStatements(statement.TryBody, context).ConfigureAwait(false);
                pendingControl = tryFlow.Control;
                pendingReturn = tryFlow.Return;
                tryCompleted = true;
            }
            catch (ReturnSignal signal)
            {
                pendingReturn = signal;
            }
            catch (LythonRuntimeException ex)
            {
                LoweredExceptClause? matchedClause = null;
                var headerPreviousException = context.State.SetCurrentException(CreatePythonExceptionInstance(ex));
                try
                {
                    foreach (var candidate in statement.ExceptClauses)
                    {
                        var matches = candidate.ExceptionType is { } header
                            ? MatchesCaughtExceptionValue(await evaluateExpression(header).ConfigureAwait(false), ex.Identity, context, header.Span)
                            : true;
                        if (matches)
                        {
                            matchedClause = candidate;
                            break;
                        }
                    }
                }
                catch (LythonRuntimeException handlerError)
                {
                    handlerError.PythonContext ??= CreatePythonExceptionInstance(ex);
                    pendingException = handlerError;
                }
                finally
                {
                    context.State.SetCurrentException(headerPreviousException);
                }

                if (pendingException is null && matchedClause is not null)
                {
                    // Handler suites share the enclosing scope like CPython: only
                    // the `as` variable is suite-local (deleted below). A child
                    // context would hide every handler assignment from the code
                    // after the statement, which the executable engine never does.
                    var pyException = CreatePythonExceptionInstance(ex);
                    if (matchedClause.Syntax.ExceptionVariableName is not null)
                    {
                        pyException.Adopt(context, statement.Span);
                        StoreName(matchedClause.Syntax.ExceptionVariableName, pyException, context, statement.Span);
                    }

                    var previousException = context.State.SetCurrentException(pyException);
                    var handlerVariableName = matchedClause.Syntax.ExceptionVariableName;
                    try
                    {
                        var handlerFlow = await executeStatements(matchedClause.Body, context).ConfigureAwait(false);
                        pendingControl = handlerFlow.Control;
                        pendingReturn = handlerFlow.Return;
                    }
                    catch (LythonRuntimeException error)
                    {
                        if (!ReferenceEquals(error.OriginalPythonException, pyException))
                            error.PythonContext ??= pyException;
                        throw;
                    }
                    finally
                    {
                        if (handlerVariableName is not null)
                        {
                            _ = DeleteName(handlerVariableName, context, statement.Span);
                        }

                        context.State.SetCurrentException(previousException);
                    }
                }
                else if (pendingException is null)
                {
                    pendingException = ex;
                }
            }

            if (tryCompleted && pendingControl is null && pendingReturn is null && pendingException is null && statement.ElseBody is not null)
            {
                var elseFlow = await executeStatements(statement.ElseBody, context).ConfigureAwait(false);
                pendingControl = elseFlow.Control;
                pendingReturn = elseFlow.Return;
            }
        }
        catch (ReturnSignal signal)
        {
            pendingReturn = signal;
        }
        catch (LythonRuntimeException error)
        {
            pendingException = error;
        }
        finally
        {
            if (statement.FinallyBody is not null)
            {
                // A finally suite runs with the pending exception active like
                // CPython, so raises inside it chain the in-flight exception.
                var inFlightException = pendingException is null
                    ? null
                    : CreatePythonExceptionInstance(pendingException);
                var previousActiveException = inFlightException is null
                    ? null
                    : context.State.SetCurrentException(inFlightException);
                try
                {
                    try
                    {
                        var finalFlow = await executeStatements(statement.FinallyBody, context).ConfigureAwait(false);
                        if (finalFlow.Control is not null || finalFlow.Return is not null)
                        {
                            // Python's finally suite wins over every pending exit from try/except.
                            pendingControl = finalFlow.Control;
                            pendingReturn = finalFlow.Return;
                            pendingException = null;
                        }
                    }
                    catch (ReturnSignal signal)
                    {
                        pendingReturn = signal;
                        pendingControl = null;
                        pendingException = null;
                    }
                    catch (LythonRuntimeException ex)
                    {
                        pendingException = ex;
                        pendingControl = null;
                        pendingReturn = null;
                    }
                }
                finally
                {
                    if (inFlightException is not null)
                    {
                        context.State.SetCurrentException(previousActiveException);
                    }
                }
            }
        }

        if (pendingException is not null)
        {
            throw pendingException;
        }

        return new LoweredBlockFlow(pendingControl, pendingReturn);
    }

    private static PyFunctionBase CreateLoweredFunction(
        LoweredFunctionDefinitionStatement functionDefinition,
        ExecutionContext context,
        IReadOnlyDictionary<string, object> defaults)
    {
        var code = functionDefinition.PreparedCode.RequireNotNull();
        var cells = code.ClosureNames.Count > 0
            ? CaptureExecutableClosures(code, context.FunctionClosureContext, functionDefinition.Span) : [];
        PyFunctionBase function = functionDefinition.Syntax.IsGenerator
                ? new PyGeneratorFunction(functionDefinition.Syntax.DeclaredName, functionDefinition.ParameterLayout,
                    code, context.FunctionClosureContext, defaults, code.ScopeFacts, cells)
                : new PyExecutableFunction(functionDefinition.Syntax.DeclaredName, functionDefinition.ParameterLayout,
                    code, context.FunctionClosureContext, cells, defaults, code.ScopeFacts);
        ChargeFunctionValue(context, functionDefinition.Span);
        ChargeClosureRetention(context.FunctionClosureContext, context.MemoryGovernor, functionDefinition.Span);
        PyFunctionBase.CaptureFunctionDocstring(function, functionDefinition.Docstring, context, functionDefinition.Span);
        return function;
    }

    private static object CreateNamedTupleClassType(
        LoweredClassDefinitionStatement classDefinition,
        ExecutionContext classContext,
        ExecutionContext definingContext)
    {
        var members = classContext.Variables;
        var fields = new List<string>();
        var defaults = new List<object>();
        var classVars = new HashSet<string>(StringComparer.Ordinal);
        var seen = new HashSet<string>(StringComparer.Ordinal);
        var defaulted = false;
        foreach (var statement in classDefinition.Syntax.Body.OfType<AnnotatedAssignmentStatementSyntax>())
        {
            if (statement.Target is not NameAssignmentTargetSyntax name)
            {
                continue;
            }

            if (PyDataclass.ClassifyFieldKind(statement.Annotation) == DataclassFieldKind.ClassVar)
            {
                classVars.Add(name.Name);
                continue;
            }

            if (!seen.Add(name.Name))
            {
                continue;
            }

            fields.Add(name.Name);
            if (statement.Expression is not null &&
                members.TryGetValue(name.Name, out var defaultValue))
            {
                defaults.Add(defaultValue);
                defaulted = true;
            }
            else if (defaulted)
            {
                throw new LythonRuntimeException("TypeError", $"non-default argument '{name.Name}' follows default argument.", classDefinition.Span);
            }
        }

        var allowed = new HashSet<string>(fields, StringComparer.Ordinal);
        foreach (var classVar in classVars)
        {
            allowed.Add(classVar);
        }

        allowed.Add("__doc__");
        allowed.Add("__module__");
        allowed.Add("__annotations__");
        foreach (var member in members.Keys)
        {
            if (!allowed.Contains(member))
            {
                throw new LythonRuntimeException("TypeError", $"typing.NamedTuple class body member '{member}' is unsupported in Lython (only annotated fields with optional defaults are supported).", classDefinition.Span);
            }
        }

        object? moduleName = null;
        if (members.TryGetValue("__module__", out var moduleValue) && moduleValue is not PyNone)
        {
            if (!PyStringOps.TryAsString(moduleValue, out var moduleText))
            {
                throw new LythonRuntimeException("TypeError", "typing.NamedTuple __module__ must be a string.", classDefinition.Span);
            }

            moduleName = moduleText;
        }
        else if (PyFunctionBase.TryGetModuleName(definingContext, out var callerModule))
        {
            moduleName = callerModule;
        }
        else
        {
            moduleName = PyNone.Instance;
        }

        var created = new PyNamedTupleType(
            classDefinition.Syntax.DeclaredName,
            fields,
            defaults,
            definingContext.MemoryGovernor,
            classDefinition.Span);
        created.ModuleName = moduleName;
        if (members.TryGetValue("__annotations__", out var annotations) && annotations is PyDict annotationMap)
            created.Annotations = annotationMap;
        return created;
    }
    private static async ValueTask<object> CreateLoweredClassType(
        LoweredClassDefinitionStatement classDefinition,
        IReadOnlyList<PyType> resolvedBases,
        object[] baseTypes,
        CallArgumentValue[] classKeywords,
        ExecutionContext classContext,
        ExecutionContext definingContext, bool asynchronous)
    {
        // A bare typing.NamedTuple base builds the ordinary namedtuple type the
        // functional form returns instead of a plain class; anything beside the
        // lone alias base is explicitly unsupported.
        var namedTupleBase = false;
        foreach (var baseValue in baseTypes)
        {
            if (baseValue is PyTypingAlias { ShortName: "NamedTuple" })
            {
                namedTupleBase = true;
            }
        }

        if (namedTupleBase)
        {
            if (baseTypes.Length != 1)
            {
                throw new LythonRuntimeException("TypeError", "typing.NamedTuple class bases support only a lone NamedTuple base in Lython.", classDefinition.Span);
            }

            return CreateNamedTupleClassType(classDefinition, classContext, definingContext);
        }

        if (baseTypes.Any(b => b is PyTypingAlias { ShortName: "TypedDict" }))
        {
            if (baseTypes.Length != 1 || classDefinition.TypeParameters is not null)
                throw new LythonRuntimeException("TypeError", "TypedDict supports a lone non-generic TypedDict base in Lython.", classDefinition.Span);
            var total = true;
            foreach (var keyword in classKeywords)
            {
                if (keyword.KeywordName != "total")
                    throw new LythonRuntimeException("TypeError", "Unsupported TypedDict class keyword.", classDefinition.Span);
                if (keyword.Value is not bool value)
                    throw new LythonRuntimeException("NotImplementedError", "TypedDict total must be a bool in Lython.", classDefinition.Span);
                total = value;
            }
            var members = classContext.Variables;
            foreach (var member in members.Keys)
                if (member is not ("__annotations__" or "__module__" or "__doc__"))
                    throw new LythonRuntimeException("TypeError", "TypedDict class bodies support annotations and docstrings in Lython.", classDefinition.Span);
            var annotations = members.TryGetValue("__annotations__", out var map) && map is PyDict dictionary
                ? dictionary : new PyDict(definingContext.MemoryGovernor, classDefinition.Span);
            var typed = new PyTypedDictType(
                PyString.FromString(classDefinition.Syntax.DeclaredName, definingContext.MemoryGovernor, classDefinition.Span),
                annotations, total, definingContext, classDefinition.Span);
            if (members.TryGetValue("__module__", out var module)) typed.ModuleName = module;
            if (members.TryGetValue("__doc__", out var doc)) typed.Docstring = doc;
            else if (PyFunctionBase.LeadingDocstring(classDefinition.Body) is { } text)
                typed.Docstring = PyString.FromString(text, definingContext.MemoryGovernor, classDefinition.Span);
            return typed;
        }

        // Class docstrings follow the function rule; an explicit __doc__ assignment
        // in the body wins since it already ran. The entry rides the member charge.
        if (PyFunctionBase.LeadingDocstring(classDefinition.Body) is { } docText &&
            !classContext.Variables.ContainsKey("__doc__"))
        {
            classContext.Variables["__doc__"] = PyString.FromString(docText, definingContext.MemoryGovernor, classDefinition.Span);
        }
        classContext.Variables.TryAdd("__doc__", PyNone.Instance);

        // Admission covers the copied member table before construction or
        // descriptor publication; the original body map may still be retained.
        ChargeClassTypeValue(classContext.Variables.Count, definingContext.MemoryGovernor, classDefinition.Span);
        var classMembers = new Dictionary<string, object>(classContext.Variables, StringComparer.Ordinal);
        PyType type;
        try
        {
            type = new PyType(
                classDefinition.Syntax.DeclaredName,
                resolvedBases,
                classMembers,
                definingContext.MemoryGovernor,
                classDefinition.Span);
        }
        catch (InvalidOperationException ex)
        {
            throw new LythonRuntimeException("TypeError", ex.Message, classDefinition.Span);
        }

        if (classContext.AnnotationClassNamespace is not null) classContext.AnnotationClassNamespace = classMembers;

        // A JSON encoder/decoder base records engine behavior on the guest
        // type without entering its MRO; chains below inherit the kind from
        // their resolved guest bases.
        var jsonBase = JsonBaseKind.None;
        foreach (var baseValue in baseTypes)
        {
            var baseKind = baseValue switch
            {
                JsonEncoderClass => JsonBaseKind.Encoder,
                JsonDecoderClass => JsonBaseKind.Decoder,
                _ => JsonBaseKind.None,
            };
            if (baseKind != JsonBaseKind.None)
            {
                if (jsonBase != JsonBaseKind.None)
                {
                    throw new LythonRuntimeException("TypeError", "Cannot combine multiple JSON encoder/decoder base classes.", classDefinition.Span);
                }

                jsonBase = baseKind;
            }
        }

        if (jsonBase == JsonBaseKind.None)
        {
            foreach (var resolvedBase in resolvedBases)
            {
                if (resolvedBase.JsonBase != JsonBaseKind.None)
                {
                    jsonBase = resolvedBase.JsonBase;
                    break;
                }
            }
        }

        type.SetJsonBase(jsonBase);

        if (definingContext.TryGetBuiltinType("type", out var metaType))
        {
            type.SetMetaType(metaType);
        }

        await PyDataclass.ApplyAsync(type, classDefinition.Syntax, classContext, classDefinition.Span, asynchronous).ConfigureAwait(false);
        type.InitializeClassMembers(definingContext, classDefinition.Span);
        return type;
    }

    private static async ValueTask<object> ReadLoweredSubscriptAsync(object target, object index, LythonSourceSpan span, ExecutionContext context)
    {
        if (target is PyDict dictionary)
        {
            var key = ValidateDictionaryKey(index, span);
            var found = await dictionary.TryGetKeyAsync(key, context, span).ConfigureAwait(false);
            return found.Found ? found.Value : throw RuntimeErrors.MissingKey(key, span);
        }
        if (target is ElementTreeModule.Element element)
            return await ElementTreeModule.ReadIndexAsync(element, index, context, span, true).ConfigureAwait(false);
        if (target is ReMatchObject match)
        {
            return await ReMatchMembers.GetSubscriptAsync(match, index, span, context).ConfigureAwait(false);
        }
        if (target is PyInstance instance)
        {
            return await GetUserItemAsync(instance, index, context, span).ConfigureAwait(false);
        }
        if (index is PySlice slice && PyIndexing.IsNativeSliceTarget(target))
            return await ReadSliceValueAsync(target, slice.StartBound, slice.StopBound, slice.StepBound, span, context).ConfigureAwait(false);
        if (target is PyType type)
        {
            return await ReadTypeSubscriptAsync(type, index, context, span, true).ConfigureAwait(false);
        }
        if ((target is IPyIndexableValue or PyRange) && index is PyInstance)
            index = await CoerceTypeIndexAsync(index, context, span, true).ConfigureAwait(false) ?? PyNone.Instance;
        return ReadSubscriptValue(target, index, span, context);
    }

    private static object ResolveLoweredMemberValue(
        LoweredMemberExpression member,
        object target,
        ExecutionContext context,
        bool isCallTarget = false)
    {
        if (context.State.TryReadRuntimeMemberCache(member, target, out var value) &&
            (isCallTarget || value is not ICallable))
        {
            return value;
        }

        if (!TryResolveRuntimeMember(target, member.Member.MemberName, context, member.Span, out value))
        {
            throw PyMemberAccess.CreateMissingMemberError(target, member.Member.MemberName, member.Span, context);
        }

        if (CanCacheRuntimeMemberValue(target, value, isCallTarget))
        {
            context.State.WriteRuntimeMemberCache(member, target, value);
        }

        return value;
    }

    private static object EvaluateLoweredBinaryOperator(
        LoweredBinaryExpression binary,
        object left,
        object right,
        ExecutionContext context)
        => EvaluateBinaryOperator(binary.Binary.Operator, left, right, context, binary.Span);

    private static object EvaluateLoweredUnaryOperator(
        LoweredUnaryExpression unary,
        object operand,
        ExecutionContext context)
        => EvaluateUnaryOperator(unary.Unary.Operator, operand, context, unary.Span);

    private static PyException? CoerceRaiseCause(object value, LythonSourceSpan span, ExecutionContext context)
    {
        if (value is PyNone)
        {
            return null;
        }

        if (value is PyException instance)
        {
            return instance;
        }

        if (value is ExceptionTypeValue typeValue &&
            typeValue.Invoke([], span, context) is PyException constructed)
        {
            return constructed;
        }

        throw new LythonRuntimeException("TypeError", "exception causes must derive from BaseException", span);
    }

    // An explicit raise chains the active handler exception as its context
    // like CPython; re-raising the active instance itself leaves the link
    // unchanged instead of building a self-cycle.
    private static void AttachImplicitRaiseChain(
        LythonRuntimeException thrown,
        PyException instance,
        ExecutionContext context)
    {
        var current = context.State.CurrentException;
        if (instance.OwnerMemoryGovernor is not null && current is not null && !ReferenceEquals(instance, current))
            current.Adopt(context, thrown.Span);
        thrown.OriginalPythonException = instance;
        thrown.Attribution = instance.Attribution;
        thrown.PythonContext = current is not null && !ReferenceEquals(instance, current) ? current : instance.Context;
    }

    private static void ThrowReraisedException(LythonSourceSpan span, ExecutionContext context)
    {
        var current = context.State.CurrentException;
        if (current is null)
        {
            throw RuntimeErrors.Runtime("No active exception to reraise", span);
        }

        // A bare raise continues the active chain instead of starting a new
        // one, so cause, context and suppression travel with the value.
        throw new LythonRuntimeException(current.Identity, current.Message, span, null, current.Value)
        {
            OriginalPythonException = current,
            Attribution = current.Attribution,
        };
    }

    private static PyFunctionBase CreateLambdaFunction(LoweredLambdaExpression lambda,
        IReadOnlyDictionary<string, object> defaults, ExecutionContext context)
    {
        var code = lambda.Code;
        var cells = CaptureExecutableClosures(code,
            lambda.NamespaceClosure ? context.FunctionClosureContext : context, lambda.Span);
        ChargeFunctionValue(context, lambda.Span);
        PyFunctionBase function = lambda.IsGenerator
            ? new PyGeneratorFunction("<lambda>", lambda.ParameterLayout, code, context.FunctionClosureContext,
                defaults, lambda.ScopeFacts, cells, PythonCallableKind.Lambda)
            : new PyExecutableFunction("<lambda>", lambda.ParameterLayout, code, context.FunctionClosureContext,
                cells, defaults, lambda.ScopeFacts, PythonCallableKind.Lambda);
        ChargeClosureRetention(context.FunctionClosureContext, context.MemoryGovernor, lambda.Span);
        // Module lambdas expose their globals after the executable slots leave.
        // Retain the existing namespace once, without lowering a compiled body.
        if (lambda.NamespaceClosure || code.RequiresLocalVariableMirroring ||
            context.FunctionClosureContext.ParentContext is null && !context.FunctionClosureContext.MirrorLocalStores)
            RetainLocalsForLambda(context.FunctionClosureContext);
        return function;
    }

    private static object StoreLoweredAssignmentResult(
        LoweredAssignmentExpression assignment,
        object value,
        ExecutionContext context)
    {
        StoreName(assignment.Assignment.Name, value, context, assignment.Span);
        return value;
    }

    private static readonly BuiltinCallable ClassHeaderExpansionTarget = BuiltinCallable.Create(
        LythonCallableSignature.Create("__build_class__", []),
        static (_, _, _) => throw new InvalidOperationException("Class header expansion target cannot be invoked."));

    private static async ValueTask<(object[] Bases, CallArgumentValue[] Keywords)> EvaluateClassHeaderArgumentsAsync(
        LoweredClassDefinitionStatement definition, ExecutionContext context,
        MemoryGovernor.TemporaryMemoryReservation storage, bool asynchronous)
    {
        var sourceCount = definition.HeaderArguments.Count;
        if (sourceCount > 0) storage.Grow(64L + 32L * sourceCount, definition.Span);
        var arguments = asynchronous
            ? await CallExpansion.ExpandLoweredArgumentsAsync(definition.HeaderArguments, context,
                EvaluateLoweredExpressionAsync, ClassHeaderExpansionTarget, deferSingleStar: false).ConfigureAwait(false)
            : CallExpansion.ExpandLoweredArguments(definition.HeaderArguments, context,
                EvaluateLoweredExpression, ClassHeaderExpansionTarget, deferSingleStar: false);
        if (arguments.Length > sourceCount)
            storage.Grow(32L * (arguments.Length - sourceCount), definition.Span);

        var positionalCount = arguments.Count(argument => argument.IsPositional);
        var keywordCount = arguments.Length - positionalCount;
        if (arguments.Length > 0)
            storage.Grow(EstimateObjectArrayBytes(positionalCount) + 64L + 32L * keywordCount, definition.Span);
        var bases = new object[positionalCount];
        var keywords = new CallArgumentValue[keywordCount];
        var baseIndex = 0;
        var keywordIndex = 0;
        foreach (var argument in arguments)
        {
            context.CheckExecution(definition.Span);
            if (argument.IsPositional) bases[baseIndex++] = argument.Value;
            else
            {
                // Dynamic ** names are CLR text retained across the class
                // suite and subclass hook, beyond the expansion's scratch.
                storage.Grow(2L * argument.KeywordName.Length, definition.Span);
                keywords[keywordIndex++] = argument;
            }
        }
        return (bases, keywords);
    }

    private static void ValidateClassKeywordArguments(CallArgumentValue[] arguments, LythonSourceSpan span)
    {
        foreach (var argument in arguments)
        {
            if (string.Equals(argument.KeywordName, "metaclass", StringComparison.Ordinal))
            {
                throw new LythonRuntimeException(
                    "TypeError",
                    "class(..., metaclass=...) is not supported by Lython.",
                    span);
            }
        }
    }
}
