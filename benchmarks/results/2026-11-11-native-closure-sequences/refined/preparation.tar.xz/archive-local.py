from pathlib import Path
import gzip,hashlib,json,tarfile
r=Path(__file__).resolve().parent;repo=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=json.loads((r/'before.json').read_text(encoding='utf-8'));candidate=json.loads((r/'diagnostic-identity.json').read_text(encoding='utf-8'))
for role,hashes in [('before',before['sourceHashes']),('candidate',candidate['sourceHashes'])]:
 target=r/('sources-'+role+'.tar.xz');assert not target.exists()
 with tarfile.open(target,'w:xz')as t:
  for name,h in hashes.items():
   original=r/'originals'/name;path=original if role=='before'and original.exists()else repo/name
   assert sha(path)==h,(role,name)
   t.add(path,arcname=name)
 for framework in ['net11.0','net10.0']:
  core=r/'images'/role/'Lokad.Lython.dll'if framework=='net11.0'else r/('before-net10.dll'if role=='before'else'candidate-net10.dll')
  expected=before if role=='before'else candidate
  assert sha(core)==(expected['images'][role]['Lokad.Lython.dll']if framework=='net11.0'else expected['net10SHA256'])
  with gzip.open(r/(role+'-'+framework+'.dll.gz'),'wb')as out:out.write(core.read_bytes())
with tarfile.open(r/'preparation.tar.xz','w:xz')as t:
 for path in sorted(r.rglob('*')):
  rel=path.relative_to(r)
  if not path.is_file()or {'images','b583','bin','obj'}&set(rel.parts):continue
  if path.suffix in {'.dll','.xz','.gz'}or rel.parts[0]in ['warm-sync','warm-async','compile']:continue
  t.add(path,arcname=rel.as_posix())
 for name in ['tests/Lokad.Lython.PublicApi.Tests/NativeReturnFunctionTests.cs','tests/Lokad.Lython.Tests/NativeClosureSequenceTests.cs']:
  t.add(repo/name,arcname=name)
 t.add(repo/'tests/Lokad.Lython.PublicApi.Tests/NativeClosureLifetimeTests.cs',arcname='tests/Lokad.Lython.PublicApi.Tests/NativeClosureLifetimeTests.cs')
print('Exact source pairs/both target cores and focused semantic/ownership checks archived before retention decision.')
