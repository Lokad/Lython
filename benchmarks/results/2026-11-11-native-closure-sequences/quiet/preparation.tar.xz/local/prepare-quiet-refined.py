from pathlib import Path
import ast,gzip,hashlib,json,shutil,tarfile
base=Path(__file__).resolve().parent.parent;r=Path(__file__).resolve().parent/'refined';q=r/'b583';q.mkdir(exist_ok=False)
old=base/'native-counter-loops-r237/b576';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
meta=json.loads((r/'diagnostic-identity.json').read_text(encoding='utf-8'))
for name,h in meta['sourceHashes'].items():assert sha(Path(name))==h,name
root='/home/lokad/lython-bench-checks/captured-sequence-b583-20261111';unit='lython-b583-captured-sequence-20261111'
reference=json.loads((base/'mirrored-call-storage-r241/b581/identity.json').read_text(encoding='utf-8'))['coreSHA256']['candidate']
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision='R243 refined captured-helper prototype versus fully qualified5f9059fa. 4742focused actual11/10 checks/10Python goldens. Live cells in existing input storage; initial extra-parameter prototype/adversity retained. Quiet reference f702/precommit30 metadata has same5f executable source, documented comment-only delta; desktop fresh reference c504 differs in metadata. No cross-host clock merge/CPython ratio.',
 coreSHA256={role:reference if role.startswith('reference')else meta['images']['candidate']['Lokad.Lython.dll']for role in ['reference','candidate','reference-control','candidate-control']},catalogSHA256=sha(r/'catalog.json'))
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(q/'source-identity.json').write_text(json.dumps(dict(beforeRevision='5f9059fa',prototypeUncommitted=True,sourceSHA256=meta['sourceHashes'],changedProductionFiles=meta['changedProductionFiles'],focusedChecks=4742,lastFullyQualified='5f9059fa',referenceMetadataDifference='Quiet reuses verified qualified5f executable code f702; desktop uses fresh c504 baseline with exact5f production source. R241 post-freeze two-line comment patch is archived. No mixed timing medians.'),indent=2)+'\n',encoding='utf-8')
shutil.copyfile(r/'catalog.json',q/'representative.json');shutil.copyfile(r/'images/candidate/Lokad.Lython.dll',q/'current-core.dll')
jobs=[['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','warm-async'],['scripts.text-summary-helpers.large','warm'],['scripts.csv-validated-records.large','warm']]
text=(old/'collect.py').read_text(encoding='utf-8').replace('/native-counter-loops-b576-20261111','/captured-sequence-b583-20261111')
start=text.index('jobs=');end=text.index('\nenv = ',start);text=text[:start]+'jobs='+repr(jobs)+'\nassert len(jobs)==4 and all(case in cases for case,lane in jobs)\n'+text[end:]
start=text.index("purpose='R237");end=text.index("',\n                  warmupSeconds",start)
text=text[:start]+"purpose='R243 bounded refined native-closure source pair versus qualified5f, captured text both APIs plus ordinary text/CSVsync controls. Initial/desktop adversity preserved. Warm includes mediated RAM I/O/full checks/prior-result cleanup, excludes compile/startup/reset/protocol/final caches; no CPython ratio"+text[end:]
text=text.replace(' < 170',' < 140');ast.parse(text);(q/'collect.py').write_text(text,encoding='utf-8',newline='\n')
for name in ['archive-owned.py','run.sh','retrieve.py','summarize.py','launch.py']:
 text=(old/name).read_text(encoding='utf-8').replace('native-counter-loops-b576','captured-sequence-b583').replace('lython-b576-native-counter-loops','lython-b583-captured-sequence').replace('B576 five-job','B583 four-job')
 text=text.replace("len(raw['jobs'])==5","len(raw['jobs'])==4").replace('jobs=5','jobs=4').replace("['jobs']==5","['jobs']==4")
 text=text.replace('ownerSeconds=210','ownerSeconds=180').replace('seconds=270','seconds=240').replace("['elapsedSeconds']<210","['elapsedSeconds']<180")
 if name.endswith('.py'):ast.parse(text)
 (q/name).write_text(text,encoding='utf-8',newline='\n')
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for name in ['current-core.dll','representative.json','source-identity.json','identity.json','collect.py','archive-owned.py','run.sh']:t.add(q/name,arcname=name)
with tarfile.open(q/'payload.tgz')as t:expanded=sum(((m.size+4095)//4096)*4096 for m in t.getmembers())
retire=[]
for canonical,known in [('benchmarks/results/2026-11-11-private-counter-segments/before-net11.0.dll.gz','private-counter-b579-20261111/baseline-core.dll'),('benchmarks/results/2026-11-11-native-counting-loops/before-net11.0.dll.gz','native-counter-loops-b576-20261111/reference/Lokad.Lython.dll')]:
 p=Path(canonical);data=gzip.decompress(p.read_bytes());assert data[:2]==b'MZ'
 retire.append(dict(kind='all-aliases',knownPath=known,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),canonicalStorage=str(p.resolve()),canonicalArchiveSHA256=sha(p),reason='Obsolete historical baseline, no longer a selected live reference; exact core retained independently in existing immutable Git evidence. Fresh absolute path/UID/inode/all-alias proof required before retirement.'))
p=Path('benchmarks/results/2026-11-11-private-counter-segments/quiet/observations.tgz')
retire.append(dict(kind='exact',knownPath='private-counter-b579-20261111/observations.tgz',bytes=p.stat().st_size,sha256=sha(p),canonicalStorage=str(p.resolve()),reason='Historical raw archive already independently retained in immutable Git evidence; fresh unique path/UID/inode/SHA proof required.'))
config=dict(root=root,unit=unit,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha(q/'payload.tgz'),requiredFreeBytes=252*1024*1024+expanded+65536,retire=retire,identity=identity)
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
text=(old/'remote-launch.py').read_text(encoding='utf-8').replace('lython-b576-fixtures','lython-b583-fixtures').replace('jobs=5','jobs=4').replace('ownerSeconds=210','ownerSeconds=180').replace('RuntimeMaxSec=210','RuntimeMaxSec=180')
referencePath="base/'mirrored-storage-b581-20261111/candidate/Lokad.Lython.dll'"
text=text.replace("with(base/'comparison-vm.lock')", "protected["+referencePath+"]="+repr(reference)+"\nprotected[base/'native-counter-loops-b576-20261111/candidate/Lokad.Lython.dll']='bf93c7ce9533fc93c00b4cb315b21d6fce707d0a25ff618b1ca98b7567e6cb22'\nwith(base/'comparison-vm.lock')")
text=text.replace("os.link(root/name,root/role/'Lokad.Lython.dll')","os.link("+referencePath+" if role=='reference' else root/name,root/role/'Lokad.Lython.dll')")
text=text.replace("canonicalStorage='Pre-existing independently verified persistent local source.tar; exact path/bytes/SHA recorded in files'","canonicalStorage='Existing immutable Git benchmark archives, verified by exact decompressed core or raw archive SHA; canonical path/bytes/SHA recorded in each file proof'")
ast.parse(text.replace('config=CONFIG','config='+repr(config)).replace('inventoryOnly=INVENTORY_ONLY','inventoryOnly=True'))
(q/'remote-launch.py').write_text(text,encoding='utf-8',newline='\n')
print('Prepared4short source pairs/180sowner. Exact canonical obsolete-baseline copies verified; fresh idle/disk/path/UID/all-alias inventory must pass before any retirement or staging.')
