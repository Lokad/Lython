#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/regex-byte-capture-20261123
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
export DOTNET_HOST_PATH="$DOTNET_ROOT/dotnet"
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/regex-byte-capture-20261123
filter='FullyQualifiedName~Regex&Category!=Stress'
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$lab/public-ubuntu.log" 2>&1 || { tail -38 "$lab/public-ubuntu.log"; exit 1; }
grep 'Passed!' "$lab/public-ubuntu.log"
