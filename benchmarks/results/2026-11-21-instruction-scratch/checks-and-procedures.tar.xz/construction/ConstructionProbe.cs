namespace Lokad.Lython.Frontend;

internal static class ConstructionProbe
{
    public static readonly long[] Bytes = new long[10];
    public static readonly long[] Shape = new long[8];

    public static void Reset()
    {
        Array.Clear(Bytes);
        Array.Clear(Shape);
    }

    internal static long Record(int stage, long start)
    {
        var end = GC.GetAllocatedBytesForCurrentThread();
        Bytes[stage] += end - start;
        return end;
    }

    internal static void RecordShape(List<List<ExecutableInstruction>> blocks, int regions)
    {
        Shape[0]++;
        Shape[1] += blocks.Count;
        Shape[2] += regions;
        foreach (var block in blocks)
        {
            Shape[3] += block.Count;
            Shape[4] += block.Capacity;
            if (block.Count == 1) Shape[5]++;
            if (block.Count == 0) Shape[6]++;
            if (block.Count == 1 && block[0].OpCode == ExecutableOpCode.Jump) Shape[7]++;
        }
    }
}
