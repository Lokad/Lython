using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Lokad.Lython;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime;

const int WarmupCount = 160, BatchCount = 7, Iterations = 64;
var phases = new[] { "tokenization", "parsing", "syntax validation", "lexical preparation",
    "annotation diagnostics", "abstract interpretation", "name-binding diagnostics",
    "analysis finalization", "executable construction" };
using var catalog = JsonDocument.Parse(File.ReadAllBytes(args[0]));
var rows = new List<object>();
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var id = item.GetProperty("id").GetString()!;
    var source = item.GetProperty("source").GetString()!;
    if (source.Contains('\r') || source.StartsWith('\uFEFF')) throw new InvalidOperationException("Expected normalized source.");
    var budget = new LythonMemoryBudget();
    using (var control = new LythonEngine().Compile(source, budget))
        if (!control.IsValid || control.Diagnostics.Count != 0) throw new InvalidOperationException("Public compiler rejected source.");
    if (budget.ReservedBytes != 0) throw new InvalidOperationException("Public compiler left funded storage.");
    var warmAllocation = new long[phases.Length];
    var warmElapsed = new long[phases.Length];
    for (var warm = 0; warm < WarmupCount; warm++)
        Run(source, budget, warmAllocation, warmElapsed);
    var samples = new List<object>();
    for (var sample = 0; sample < BatchCount; sample++)
    {
        var allocated = new long[phases.Length];
        var elapsed = new long[phases.Length];
        for (var iteration = 0; iteration < Iterations; iteration++)
            Run(source, budget, allocated, elapsed);
        samples.Add(new { allocatedBytes = allocated.Select(v => v / (double)Iterations).ToArray(),
            elapsedMicroseconds = elapsed.Select(v => v * 1e6 / Stopwatch.Frequency / Iterations).ToArray() });
    }
    rows.Add(new { id, sourceCharacters = source.Length, samples });
}
var core = typeof(LythonEngine).Assembly.Location;
File.WriteAllText(args[1], JsonSerializer.Serialize(new
{
    coreSha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(core))).ToLowerInvariant(),
    phases,
    boundary = "Local Windows Release decomposition following the shipped phases on normalized valid sources with admitted compiler ownership. Entry normalization, public wrapper creation and owner setup/cleanup are excluded. Each stage is invoked directly, so JIT/tiering and timing boundaries differ from public compilation. Diagnostic wall time and thread allocations only.",
    rows
}, new JsonSerializerOptions { WriteIndented = true }) + "\n", Encoding.UTF8);

static void Run(string source, LythonMemoryBudget budget, long[] allocated, long[] elapsed)
{
    using (var owner = budget.CreateScope())
    {
        if (!owner.TryReserve(RuntimeMemoryEstimates.EstimateCompilationBytes(source.Length), out _))
            throw new InvalidOperationException("Compiler allowance refused.");
        var governor = new MemoryGovernor(owner);
        using var programs = new CompiledRegexPrograms(governor);
        var meter = new PhaseMeter(allocated, elapsed);
        var tokens = PythonTokenization.Read(source);
        meter.Next(0);
        if (tokens.HasInvalidTokens) throw new InvalidOperationException("Invalid tokens.");
        var parsed = new Parser(tokens, governor).Parse();
        governor.ThrowIfAdmissionFailed();
        meter.Next(1);
        var script = parsed.Script ?? throw new InvalidOperationException("Source did not parse.");
        var syntaxDiagnostics = SyntaxValidityDiagnostics.Analyze(script, out var hasScopeDirectives,
            out var potentialMutations, out var annotationChecks, out var importsRegex, out var needsLexicalExpressions, default);
        governor.ThrowIfAdmissionFailed();
        meter.Next(2);
        if (syntaxDiagnostics.Count != 0 || importsRegex || hasScopeDirectives)
            throw new InvalidOperationException("Expected valid non-regex cases without scope directives.");
        LexicalScopePreparation.Prepare(script, source, needsLexicalExpressions, governor);
        meter.Next(3);
        LythonDiagnostic[] diagnostics;
        using (var analysis = new StaticAnalysisContext(script, governor: governor, regexPrograms: programs,
            potentialMutations: potentialMutations))
        {
            var annotations = AnnotationDiagnostics.Analyze(script, annotationChecks, false, analysis);
            meter.Next(4);
            analysis.CheckExecution();
            StaticAbstractInterpreter.Analyze(analysis);
            meter.Next(5);
            analysis.CheckExecution();
            StaticNameBindingDiagnostics.Analyze(analysis);
            meter.Next(6);
            diagnostics = parsed.Diagnostics.Concat(annotations).Concat(analysis.Diagnostics).ToArray();
        }
        governor.ThrowIfAdmissionFailed();
        meter.Next(7);
        if (diagnostics.Length != 0) throw new InvalidOperationException("Decomposition returned diagnostics.");
        var executable = ExecutableScript.Compile(script, governor: governor);
        governor.ThrowIfAdmissionFailed();
        meter.Next(8);
        GC.KeepAlive(executable);
    }
    if (budget.ReservedBytes != 0) throw new InvalidOperationException("Compilation scope did not refund.");
}

struct PhaseMeter(long[] allocated, long[] elapsed)
{
    private long _bytes = GC.GetAllocatedBytesForCurrentThread();
    private long _ticks = Stopwatch.GetTimestamp();

    internal void Next(int stage)
    {
        var ticks = Stopwatch.GetTimestamp();
        var bytes = GC.GetAllocatedBytesForCurrentThread();
        allocated[stage] += bytes - _bytes;
        elapsed[stage] += ticks - _ticks;
        _bytes = bytes;
        _ticks = ticks;
    }
}
