from pathlib import Path
import hashlib,json,tarfile

lab=Path(__file__).resolve().parent
source=lab/"quiet"
out=lab/"confirmation"
out.mkdir()
load=lambda p:json.loads(p.read_text(encoding="utf-8"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def emit(p,s):
    if p.suffix==".py": compile(s,str(p),"exec")
    p.write_text(s,encoding="utf-8",newline="\n")
def save(p,v): emit(p,json.dumps(v,indent=2)+"\n")

old=load(source/"config.json")
receipt=load(source/"archive-receipt.json")
assert receipt["complete"] and receipt["archivedAndVerifiedUnderLease"]
assert receipt["archiveSHA256"]==sha(source/"observations.tgz")
images=old["identity"]["imageFiles"]
assert all(len(files)==32 and {n:sha(lab/"frozen"/role/n) for n in files}==files for role,files in images.items())
assert old["catalogSHA256"]==sha(source/"representative.json")
identity=old["identity"] | {"purpose":"Repeat conflicting validator compile and compile-to-result outcomes with the exact B1265 images"}
save(out/"identity.json",identity)
root="/home/lokad/lython-bench-checks/instruction-scratch-b1266-20261121"
unit="lython-b1266-instruction-scratch-20261121"
for name in ("collect.py","archive-owned.py","run.sh","retrieve.py"):
    s=(source/name).read_text(encoding="utf-8").replace(old["root"],root).replace(old["unit"],unit)
    if name=="collect.py":
        begin=s.index("\njobs = ")
        end=s.index("\nassert len(jobs)",begin)
        jobs=[("scripts.config-generated-guards.medium.bad-0","compile-run"),("scripts.config-generated-guards.medium.bad-0","compile")]
        s=s[:begin]+"\njobs = "+repr(jobs)+s[end:]
        s=s.replace("len(jobs)==4","len(jobs)==2").replace("if job_index % 2 == 0", "if job_index % 2 == 1")
        s=s.replace("accumulate 16 seconds","accumulate 22 seconds").replace("warmupSeconds=16","warmupSeconds=22")
        s=s.replace("min(warmed)<16","min(warmed)<22").replace("warmed[i]>=16","warmed[i]>=22")
        s=s.replace("targetBatchSeconds=.8","targetBatchSeconds=.9").replace("counts[i]*.8","counts[i]*.9")
    elif name=="archive-owned.py":
        s=s.replace("len(raw['jobs'])==4","len(raw['jobs'])==2").replace("jobs=4,", "jobs=2,")
    elif name=="retrieve.py":
        s=s.replace("['jobs']==4","['jobs']==2")
    emit(out/name,s)
assert b"\r" not in (out/"run.sh").read_bytes()
parts=("identity.json","collect.py","archive-owned.py","run.sh")
payload=out/"payload.tgz"
with tarfile.open(payload,"w:gz") as a:
    for name in parts: a.add(out/name,arcname=name)
config=old | dict(root=root,unit=unit,source=old["root"],donorArchiveSHA256=receipt["archiveSHA256"],
                  sourceCatalogSHA256=old["catalogSHA256"],identity=identity,sourceFiles=images,
                  payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),
                  unpackedBytes=sum((out/n).stat().st_size for n in parts),retireGroups=[])
save(out/"config.json",config)
s=(source/"remote-launch.py").read_text(encoding="utf-8")
start=s.index("\nc=")+1
end=s.index("\nb=Path(",start)
s=s[:start]+"c="+repr(config)+s[end:]
expected=" for n,h in c['sourceFiles'].items():assert sha(source/c['sourceRole']/n)==h,n"
assert expected in s
before=s.index(" present=[];absent=[];paths=[];inodes={}")
after=s.index(" root.mkdir()",before)
s=s[:before]+""" present=[];absent=[]
 assert not c['retireGroups']
 before=shutil.disk_usage(b).free
 assert before>176160768+c['unpackedBytes']+8*1024*1024,(before,c['unpackedBytes'])
"""+s[after:]
s=s.replace(expected," for role,files in c['sourceFiles'].items():\n  for n,h in files.items():assert sha(source/role/n)==h,n")
s=s.replace("source/'catalog.json'","source/'representative.json'").replace("source/c['sourceRole']/n","source/role/n")
s=s.replace("lython-b1265-fixtures","lython-b1266-fixtures").replace("RuntimeMaxSec=540","RuntimeMaxSec=380")
emit(out/"remote-launch.py",s)
launch=(lab/"launch.py").read_text(encoding="utf-8").replace("parent/'quiet'","parent/'confirmation'").replace("305","250")
emit(lab/"launch-confirmation.py",launch)
summarize=(lab/"summarize.py").read_text(encoding="utf-8").replace("quiet/","confirmation/").replace("len(raw['jobs'])==4","len(raw['jobs'])==2")
emit(lab/"summarize-confirmation.py",summarize)
