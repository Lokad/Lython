set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/compiler-construction-20261121
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/current-frontend-phases/refined
dotnet build tools/LythonProbe/LythonProbe.csproj -c Release -f net10.0 | tee "$logs/probe-ubuntu.log"
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Executable|FullyQualifiedName~ProtectedLoopCompilation|FullyQualifiedName~DirectOperandOwnership|FullyQualifiedName~Prepared)&Category!=Stress' | tee "$logs/white-ubuntu.log"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~CompilerCancellation|FullyQualifiedName~OperandReadFailure|FullyQualifiedName~DirectGlobalOperand|FullyQualifiedName~AsyncBoundary|FullyQualifiedName~Exception|FullyQualifiedName~SyntaxValidity|FullyQualifiedName~GeneratorCleanup|FullyQualifiedName~Compile|FullyQualifiedName~SuperCategory|FullyQualifiedName~PreparedDictionary)&Category!=Stress' | tee "$logs/public-ubuntu.log"
