using System.Reflection;
using System.Text.Json;
var a=Assembly.LoadFrom(Path.GetFullPath(args[0]));
var t=a.GetType("Lokad.Utf8Regex.PythonRe.Utf8PythonRegex",true)!;
var members=t.GetMembers(BindingFlags.Public|BindingFlags.Instance|BindingFlags.Static|BindingFlags.DeclaredOnly).Select(m=>m.ToString()).Order(StringComparer.Ordinal).ToArray();
File.WriteAllText(args[1],JsonSerializer.Serialize(members));
Console.WriteLine(members.Length);
