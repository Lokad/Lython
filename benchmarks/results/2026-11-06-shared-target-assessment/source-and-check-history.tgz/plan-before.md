# Lokad.Lython 0.11.0

Updated2026-11-06. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Allocation reductions, source gates and individual experiments do not complete it.

## Actual state

- **Fully qualified runtime b6650f09**: R13C/R14 plus R17 text-operation provenance
  (1e9f53a9) and P01 number formats (b6650f09). Terminal CI42258608463 is GREEN:
  Windows/Ubuntu, actual.NET11/.NET10, original Stress and installed consumers.
  Cached in benchmarks/results/2026-11-06-delivery-cpython/delivery-ci.json;
  never query it or previous terminal runs again. No publication/tagging.
- Local installed Release consumers pass both actual runtimes. Core runtime
  dependencies remain empty; adapter nonpackable. artifacts/nuget/ still holds
  the explicitly packed b6650f09 package, not later evidence/document commits.
- Native cursor admission development committed as evidence222e876b: private
  immutabledev44,84internal/427public per actual11/10, in-flight cancellation and
  independent program/working owners pass. Normal0.4 pin/source stays unchanged.
  The lifetime fixture correction also passes normal0.4 on both runtimes.
- B346–B352 are terminal, persistent archives verified, users joined and fixtures
  removed. B35215jobs/311.43s refreshes five CPython comparisons. No live VM or CI,
  no timestamp-preserving source restoration. No repeated qualification needed.

Evidence: benchmarks/EXPERIMENTS.md and benchmarks/results/. Prior plans, raw
handoffs and source-gate decisions remain under .git/agent-notes/review-20261031/.
docs/ is current implementation only; no transient material or separate README.

## P01 committed b6650f09: numeric Excel formats

Handoff integrated/removed; original retained privately. Direct first-section
classification replaces normalized strings and misleading substring/prefix tests.
Colors/conditions/locale metadata and literals no longer turn numbers or formula
caches into dates/durations. Exact elapsed tokens and existing epochs remain.
Long scans receive the active cancellation token; no regex dependency required.
CPython/openpyxl3.1.5 reference passes60rows/120cells and9real formats. Focused
Release169public/45internal per actual11/10 pass, including shared-budget cleanup.
Evidence benchmarks/results/2026-11-06-openpyxl-number-formats/. Combined delivery
with R17 is fully qualified at b6650f09; no broader workbook redesign.

## R17 closeout: explicit text-operation provenance

Retain the deletion: PyString64→56B actual shells on both runtimes; one explicit
payload admission path, no value birth-span reference or unused governing marker.
Owners/capacities/cache rollback and conservative128B+capacity estimates remain.
Source-less internal helpers can have no span; public operations use their current
instruction and cannot replace an established first refusal.

B351140.60s, complete CSV warm/fresh plus text/JSON/report warm, normal GC/tiering,
unchanged workers/goldens/ownership/quiet/cleanup. CSV warm+0.64/+1.17%, fresh
−0.40/−2.72%; text+2.22/+1.59%, JSON−1.56/−1.65%, report−0.91/−4.13%.
Accept text's1.6–2.2% elapsed debt explicitly; control-limited cases and coarse
CPU ticks do not prove broad improvement. No unchanged timing replay scheduled.

Separate existing whole-job allocation diagnostic, both APIs: text−4.28%, CSV
helpers−2.67/−2.43%, JSON−3.37%, report−1.77/−1.75%, config−3.49/−3.48%.
It includes reset/checking; Windows elapsed is diagnostic. Original failed witness
and fixture conditions remain. No RSS/live-heap/host-latency claim. Preserve source
and evidence, operation-origin contract documented and committed; combined delivery fully qualified.

## Independent U03: cursor migration completed privately; remaining contract work

Immutabledev44 native cursor working admission now passes84internal/427public per
actual11/10. One existing reservation replaces the subject-size heuristic; native
live high-water capacity stays charged until Close. Release cannot call a throwing
host; first refusal throws terminal MemoryAdmission. Fixed range/capture overlap
and local current-token CTS bridge remain. Independent program/working roots,
16,384matches under256KiB, actual in-flight cancellation and cleanup/reuse pass.
Normal0.4 source/pin and core dependency independence remain unchanged.

Direct same-producer/core diagnostic: working peak32,880→2,064B; allocation+128B
per cursor(+0.58%); busy-host elapsed+9.1% adverse/diagnostic. Retain the result and
explicit speed debt, without claiming CPU improvement or rejecting ownership on
an uncontrolled clock. No unchanged replay scheduled. Source/test/failure evidence:
benchmarks/results/2026-11-06-native-cursor-admission/.

Remaining precise boundaries: one-shot DetailedData cannot select Prepare's
independent working owner, so its heuristic/program preflight stays; never charge
the program owner for an independent execution or emulate fullmatch via search.
Native UTF8 lookup does not enumerate all names; adapter-local string bridge stays.
Producer creation-token coupling still requires local forwarding through actual
work. Keep these separate from Lython-owned UTF8/window/flags/ownership semantics.
Development producers/bridges remain usable; final immutable released adapter and
managed-safety qualification await only the affected producer capabilities.
Next regex implementation must remove one precise bridge with semantic/lifetime
acceptance and one bounded diagnostic; no blanket stop, framework or sibling edits.

## Current comparison and open measurement debt

docs/BENCHMARKS.md now measures runtime b6650f09/B352, not future HEAD. CPython
is primary; five scripts, compile/warm/fresh separate. Fresh ratios: CSV1.31x,
text1.75–1.83x, JSON1.12x, report1.44–1.46x, small config1.21–1.22x. Warm text
1.80–1.82x is the largest remaining gap. Text fresh4.44% identical-role spread,
warm CSV3.50% and report variability remain explicit. Config is16paths/181B.
Compilation alone is44–72us in Lython; do not subtract independent job medians.

Same workers/goldens, normal GC/tiering and quiet VM. Includes mediated RAM I/O,
full validation and prior-result cleanup; fresh adds compilation/disposal. Startup,
staging/reset/transport/final teardown excluded. Module import caching differs.
Raw/identities/terminal/cleanup proof in benchmarks/results/2026-11-06-delivery-cpython/.
No allocation/RSS/embedding-tail/suspended-I/O claim or causal additive speedup.
R17 text debt and earlier adverse formatting/native-return clocks remain separate;
new absolute measurements cannot explain them. No unchanged replay scheduled.

## Next R18: complete ordinary target execution on the shared engine

Source fact: ordinary subscript stores with a materialized invocation enter the
general target handler and nested subscript/completion helpers, while deferred
invocations have a separate native no-admission shortcut. Both already avoid an
async state machine for completed work; do not misdescribe ValueTask alone as one.
The existing text capture has12/414 target-handler self samples, with additional
inclusive work; this is evidence of work, not a removable CPU percentage.

Hypothesis: one borrowed-work target implementation can remove duplicated operand
decoding and completed-operation forwarding, make ordinary writes independent of
context materialization, and preserve the existing promotion-before-admission rule.
Build on the current executable handler, not another dispatcher/backend. Expected
deletion: TryExecuteSubscriptStoreWithoutContext, duplicate subscript operand reads
and completed ValueTask forwarding where a common native operation replaces them.
Retain custom protocol operations and genuine asynchronous continuations.

First bounded source gate: verify cleanup/error provenance and liveness when native
hashing/refusal/cancellation throws before a store succeeds. Do not move retirement
past live users or silently bypass context promotion before host admission hooks.
Then one coherent prototype across sync/async module/helper stores, focused
semantics/cancellation/refusal/retained-target checks. A short paired complete-text
and ordinary-CSV comparison with identical controls plus unchanged JSON decides
benefit and remaining regression debt; allocation is separate. No fixed percentage
veto, repeated full qualification or claim of closing the whole performance goal.
If the source gate finds this already equivalent or not coherently removable,
record that fact and select a demonstrated larger boundary, not cosmetic helpers.

## Whole-script roadmap: source facts and stopping criteria

Preserve the implemented source facts below. B352 closes the current external
baseline gap; further measurements answer a specific design question, not routine
HEAD refreshes. The performance objective remains open after this delivery.

- Calls/frames: final argument/local storage, separate receiver/function, shared
  instruction engine and deferred lexical contexts already exist. Text/JSON/report
  helpers already use NativeReturn. No new CFG inventory, copy arena or context swap.
- Operand transport: ForwardValues already folds adjacent immutable constants and
  proved initialized locals; adjacent local-result publication is fused. Preserve
  failable read order, liveness fences and pending cleanup. Do not recreate it.
- Imports/lambdas: already executable (imports840621405); keep real lowered class/
  annotation/opcode consumers. Fixed immutable builtin definitions/signatures are
  already shared; mutable per-run type objects must remain isolated.
- Record/text: bulk CSV field admission, direct parser input and fused casing/split
  exist. Typical text lines do not spill range scratch. Shared string payloads/
  windows and owner-capacity credit admission were tried with actual adverse and
  uncertain conditions; see history before reopening. No renamed repetitions.
- R16 scalar convention is deferred:45 direct BigInteger tests plus production,
  protocols/hash/identity/native proofs/canonical projection need one convention.
  Current samples do not justify an extra scalar subsystem or a lone long path.

Next non-regex design must identify actual eliminated work/storage and displaced
code across representative scripts before coding. Reuse current captures/source;
bounded new measurements only for a specific missing observation. Semantic checks
include closures/classes/generators, order/errors, refusal/cancellation, ownership
and real suspension. One short controlled source pair decides benefit/debt; larger
qualified milestones follow. No new framework or open-ended ownership/profile audit.
The performance objective remains open even when P01/U03 or R17 is complete.

## Completed milestones to preserve

| Delivered | Current result / historical evidence |
| --- | --- |
| Compiler facts, UTF8 formatting/storage, native returns | Class-cell/shared-fact corrections retained. Native returns allocation−19.92/−19.31%; formatting−8.67%, controlledB102 elapsed/CPU−5–8%; original adverse15.125ms remains unexplained. Qualified historical source pairs, not current-head claims. |
| K01, F02–F05, Q01/Q02, R02–R10 | Canonical dict/set storage; explicit ownership; final call/local slots; lexical facts; native iteration/text; actual builtin class patterns; contextual hash/async reads; class extraction/construction/common frame runner. No restored weak/scalar/collector machinery or duplicate backends. |
| R12/R13 | Allocation origins selected context work; frame base/constructors removed. One work state and instruction switch; context promotion adopts current IP/locals without replay. Native writes promote before growth/admission. Shared owned publication preserves NoInlining/lifetime fixes. |
| R14 | Explicit dictionary provenance, native no-growth writes and structural/protocol scopes; cancellation restores outer provenance. Combined source62141d4d fully qualified. |
| R15/R16 gates | Duplicate CSV input-copy/split-spill proposals and new scalar representation deferred on current evidence. This is a decision, not implementation or a permanent ban. |

## Working constraints

Timeouts/unstable controls/inconclusive observations establish uncertainty. Allow
bounded confirmation/refinement/correction for a stated reason; retain adverse
data and original conditions. Percentages inform rather than automatically veto.
Distinguish architectural deletion, physical allocation and measured CPU gains.

Follow AGENTS.md: fully managed/memory-safe, no unsafe/Unsafe/pointers/PInvoke/native
stack probing. Keep managed stack/recursion, host mediation/paths, cycles, active
CancellationToken and shared admission/capacity/replacement/retained aliases.
First refusal fails the command; no retry/fallback/optional-storage recovery.
No fuel, quotas, hidden caps/default allowance, tracing, weak reclamation or forced
GC. Await actual users/cleanup; initial streaming uses bounded host executions.

Use focused Release checks; batch both-platform/runtime/original Stress/package
qualification at delivery. No overlapping local builds/tests. Nonincremental build
after timestamp-preserving source restoration; reuse valid/cached qualification.
Quiet VM lokad@20.166.121.73, key~/.ssh/id_lython-bench.pem: lease, loaded hashes,
quiet/full-golden/funding/joins and persistent verified archives mandatory. Disk
nearly full; preflight. Remove only verified redundant owned transfers with retained
copies/terminal users, never sole evidence/dependencies/runtime images. No publication.
