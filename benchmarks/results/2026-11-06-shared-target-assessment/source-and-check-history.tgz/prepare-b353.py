from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
repo=Path('D:/code/Lython');home=Path(__file__).parent;root=home/'b353';root.mkdir()
old=home.parent/'text-provenance-r17/b351';remote='/home/lokad/lython-bench-checks/shared-targets-b353-20261106';oldremote='/home/lokad/lython-bench-checks/text-operation-provenance-b351-20261106';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,s):
    with (root/n).open('w',encoding='utf-8',newline='\n') as f:f.write(s)
checks=json.loads((home/'focused-results.json').read_text(encoding='utf-8'));core=repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll';assert sha(core)==checks['coreSHA256']['net11.0']
identity=json.loads((home.parent/'delivery-comparison-b352/identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision='7f266368 plus R18 shared subscript target execution; patch/snapshot authoritative',referenceSourceRevision='b6650f09; B352 frozen fully qualified core54b53c7f',coreSHA256=dict(candidate=sha(core),control=sha(core),reference=identity['coreSHA256']['candidate']),qualification=checks)
write('identity.json',json.dumps(identity,indent=2)+'\n');shutil.copyfile(core,root/'Lokad.Lython.dll')
shutil.copyfile(old/'representative.json',root/'representative.json');write('focused-results.json',json.dumps(checks,indent=2)+'\n')
patch=subprocess.check_output(['git','-c','core.safecrlf=false','diff','--','src/Lokad.Lython'],cwd=repo)
(root/'source.patch').write_bytes(patch)
changed=subprocess.check_output(['git','diff','--name-only','--','src/Lokad.Lython'],cwd=repo,text=True).splitlines()
with tarfile.open(root/'source-snapshot.tgz','w:gz') as a:
    for name in changed:a.add(repo/name,arcname=name)
plan=repo/'PLAN.md';s=plan.read_text(encoding='utf-8');s=s.replace('## Next R18: complete ordinary target execution on the shared engine','## Active R18: complete ordinary target execution on the shared engine')
note='''Prototype now has one shared subscript-store helper. Deferred/native and fully
materialized module/function writes decode operands once; completed native writes
avoid generic target/completion forwarding. Non-native/admitting operations still
promote before protocols or host hooks; genuine suspension keeps the existing
awaited-retirement helper. Focused Release114internal/232public each actual11/10
pass, both-target builds0warnings. No CPU/allocation improvement claimed yet.

B353 selects CSV/text/JSON warm plus JSON compile-only as an unchanged-path
control. JSON warm also uses stores, so it is secondary affected coverage, not
an unaffected runtime control. Four roles/current-identical/reference/CPython,
five-second warmups and seven150ms rounds,180s owned supervisor. Full outputs/
funding/quiet/joins/cleanup and persistent verified raw archives required.
No SSH while collecting; preserve adverse/control-limited outcomes.

'''
mark='Source fact: ordinary subscript stores';s=s.replace(mark,note+mark);plan.write_text(s,encoding='utf-8');write('pre-measurement-plan.md',s)
write('contract.md','''# R18 / B353 shared ordinary subscript targets
Remove separate deferred-only store shortcut and duplicate operand decoding.
Native no-admission writes share one handler with materialized modules/helpers;
protocols and growth still promote before host hooks. No new engine or policy.
Try failures retain operands for promotion; exceptions retire once; actual pending
operations keep operands funded until awaited cleanup. Preserve target versus
routing spans, order, aliases, no replay, first refusal and current cancellation.
Focused actual11/10 checks pass. Existing handlers already avoid async state
machines for completed work: this study concerns forwarding/dispatch, not a false
allocation claim. Native hashing itself uses BCL HashCode.AddBytes; do not claim
in-flight cancellation inside that BCL operation or an established prelookup bug.
Four jobs: CSV/text/JSON warm, plus unchanged-path JSON compilation. JSON warm
also uses stores, so it is secondary affected coverage. Two identical current
roles, fully qualified b6650f09 reference and CPython. Unchanged worker/protocol,
normal GC/tiering,5s warmups and7rotated150ms samples.180s process-group owner.
Full goldens/quiet/funding/Closed/join/fixture cleanup/archive proof required.
Includes mediated RAM I/O, validation and previous-result cleanup; excludes
startup/staging/reset/transport/final teardown. No exact allocation/RSS/host-tail
claim. One bounded pair; preserve adverse results; decide benefit/regression debt.
''')
for n in ['collect.py','run.sh','cpython-worker.py','archive-owned.py']:
    s=(old/n).read_text(encoding='utf-8').replace(oldremote,remote)
    if n=='collect.py':
        start=s.index('jobs=[');end=s.index('\n\nenv =',start)
        jobs=[('scripts.csv-summary-functions.large','warm'),('scripts.text-summary-helpers.large','warm'),('scripts.json-summary-helpers.large','warm'),('scripts.json-summary-helpers.large','compile')]
        s=s[:start]+'jobs='+repr(jobs)+'\nassert len(jobs)==4'+s[end:]
        s=s.replace("< 170,", "< 140,").replace("< 380,", "< 140,")
    if n=='archive-owned.py':s=s.replace("len(r['jobs'])==5","len(r['jobs'])==4").replace('jobs=5,','jobs=4,')
    write(n,s)
setup=(old/'setup.py').read_text(encoding='utf-8').replace(oldremote,remote).replace('/home/lokad/lython-bench-checks/native-dictionary-context-b350-20261106/candidate','/home/lokad/lython-bench-checks/delivery-comparison-b352-20261106/candidate')
write('setup.py',setup)
launch=(old/'launch.py').read_text(encoding='utf-8').replace(oldremote,remote).replace('b351','b353').replace('text-operation-provenance','shared-targets').replace('RuntimeMaxSec=200','RuntimeMaxSec=180')
write('launch.py',launch)
names=['Lokad.Lython.dll','identity.json','source.patch','source-snapshot.tgz','representative.json','focused-results.json','pre-measurement-plan.md','contract.md','setup.py','collect.py','run.sh','cpython-worker.py','archive-owned.py']
with tarfile.open(root/'payload.tgz','w:gz') as a:
    for n in names:a.add(root/n,arcname=n)
with tarfile.open(root/'payload.tgz') as a:expanded=sum(m.size for m in a.getmembers())
transfer=dict(payloadBytes=(root/'payload.tgz').stat().st_size,payloadSHA256=sha(root/'payload.tgz'),expandedBytes=expanded,requiredFreeBeforeTransfer=(root/'payload.tgz').stat().st_size+expanded+6*1024*1024)
write('transfer.json',json.dumps(transfer,indent=2)+'\n');print(transfer)
