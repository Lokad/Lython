from pathlib import Path
import hashlib,json,subprocess
home=Path(__file__).parent;old=home/'b353';root=home/'b354';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt=json.loads((old/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete'] and receipt['allWorkersJoined'] and sha(old/'observations.tgz')==receipt['archiveSHA256']
proof={'core':sha(old/'Lokad.Lython.dll'),'catalog':sha(old/'representative.json'),'archive':receipt['archiveSHA256']}
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
script='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess,tarfile
root=Path('/home/lokad/lython-bench-checks');old=root/'shared-targets-b353-20261106';proof=PROOF
with (root/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 receipt=json.loads((old/'archive-receipt.json').read_text());assert receipt['complete'] and receipt['allWorkersJoined']
 assert hashlib.sha256((old/'observations.tgz').read_bytes()).hexdigest()==proof['archive']
 core=old/'Lokad.Lython.dll';alias=old/'candidate/Lokad.Lython.dll';catalog=old/'representative.json'
 assert not core.is_symlink() and core.resolve().parent==old and core.stat().st_nlink==1
 assert alias.is_symlink() and alias.resolve()==core
 assert hashlib.sha256(core.read_bytes()).hexdigest()==proof['core']
 assert not catalog.is_symlink() and catalog.resolve().parent==old and hashlib.sha256(catalog.read_bytes()).hexdigest()==proof['catalog']
 with tarfile.open(old/'observations.tgz') as a:assert hashlib.sha256(a.extractfile('representative.json').read()).hexdigest()==proof['catalog']
 dependencies=[]
 for directory,dirs,files in os.walk(root,followlinks=False):
  for name in dirs+files:
   p=Path(directory)/name
   if p.is_symlink():
    target=p.resolve()
    if target==core or target in core.parents or target==catalog:dependencies.append(str(p))
 assert dependencies==[str(alias)] or sorted(dependencies)==[str(alias)],dependencies
 assert (root/'delivery-comparison-b352-20261106/candidate/Lokad.Lython.dll').resolve()!=core
 alias.unlink();core.unlink();catalog.unlink()
 record={'retiredUnusedCoreAndExpandedCatalog':str(old),'dependenciesWithinRetiredImage':dependencies,'localCoreAndCatalogHashVerified':proof,'catalogAlsoPreservedInRawArchive':True,'currentImagesAndAllArchivesPreserved':True,'freeBytes':shutil.disk_usage(root).free}
 (old/'image-retired.json').write_text(json.dumps(record,indent=2)+'\\n');print(json.dumps(record))
'''.replace('PROOF',repr(proof))
r=subprocess.run([*ssh,'python3 -'],input=script,text=True,encoding='utf-8',capture_output=True);(home/'b353-image-retirement.log').write_text(r.stdout+r.stderr,encoding='utf-8');assert r.returncode==0,r.stderr
print(r.stdout,flush=True);transfer=json.loads((root/'transfer.json').read_text(encoding='utf-8'));assert json.loads(r.stdout)['freeBytes']>transfer['requiredFreeBeforeStreamedSetup']
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for name,target in [('transfer.json','b354-transfer.json'),('launch-stream.py','b354-launch-stream.py')]:
    p=subprocess.run([*scp,str(root/name),'lokad@20.166.121.73:/home/lokad/lython-bench-checks/'+target],capture_output=True,text=True,encoding='utf-8');assert p.returncode==0,p.stderr
payload=(root/'payload.tgz').read_bytes();assert hashlib.sha256(payload).hexdigest()==transfer['payloadSHA256']
r=subprocess.run([*ssh,'python3 /home/lokad/lython-bench-checks/b354-launch-stream.py'],input=payload,capture_output=True)
text=(r.stdout+r.stderr).decode('utf-8');(home/'refined-launch.log').write_text(text,encoding='utf-8');print(text,flush=True);assert r.returncode==0
