from pathlib import Path
import json,shutil,subprocess,tarfile
home=Path(__file__).parent;out=Path('benchmarks/results/2026-11-06-shared-target-assessment');out.mkdir()
for tag,folder in [('initial','b353'),('refined','b354')]:
    source=home/folder;target=out/tag;target.mkdir()
    for name in ['identity.json','summary.json','archive-receipt.json','terminal-status.json','observations.tgz','contract.md']:shutil.copyfile(source/name,target/name)
for name in ['focused-results.json','refined-focused-results.json','withdrawn-focused-results.json','withdrawal.json','next-regex-capture-contract.md']:shutil.copyfile(home/name,out/name)
with tarfile.open(out/'source-and-check-history.tgz','w:gz') as a:
    for p in sorted(home.iterdir()):
        if p.is_file():a.add(p,arcname=p.name)
    for folder in ['b353','b354']:
        for p in sorted((home/folder).iterdir()):
            if p.is_file() and p.name not in ['Lokad.Lython.dll','observations.tgz','payload.tgz']:a.add(p,arcname=folder+'/'+p.name)
(out/'README.md').write_text('''# Shared target forwarding assessment — R18

**Withdraw both prototypes; production runtime source is unchanged.** Neither
candidate justifies the extra handler/branch and stack-argument complexity. This
is a bounded engineering decision, not a permanent ban, timeout rejection or fixed
percentage veto. Preserve original observations and changed-source confirmation.

Baseline: fully qualified b6650f09, frozen54b53c7f. Current source base7f266368.
Initial b82dc5fc and refined4fe1ce0d snapshots/patches are archived. Both moved
native no-admission subscript writes onto the same path for module/helper frames,
removing duplicate operand decoding and generic target forwarding. Protocol/growth
still promoted deferred contexts; pending operations retained operands through
awaited cleanup. Refinement separated cold protocol completion from native writes.
Existing completed target handlers already avoid async state machines; ValueTask
alone was never an allocation explanation. BCL string hashing remains unchanged.

## Controlled complete scripts

Quiet F4as_v7/Ubuntu24.04.4/.NET11RC3, normal GC/tiering, unchanged workerb94fa98c,
normal0.4 adapter, CPython3.13.16. Two independent identical candidate roles plus
qualified reference. Five-second warmups and seven rotated150ms samples. Both
four-job owners finish113.14/112.86s, all goldens/quiet/funding/Closed/joins/fixture
cleanup pass. Archives created/verified under lease and retrieved hash-verified.
Both services are terminal; never query them again.

| Warm script | Initial elapsed vs baseline, two roles | Refined elapsed vs baseline, two roles |
| --- | ---: | ---: |
| CSV/ordinary helper | +2.09% / +5.70% | +1.32% / −0.78% |
| Text/helpers | −4.10% / −5.07% | +0.15% / −1.55% |
| JSON/helpers | −4.13% / +3.18% | −4.66% / −5.44% |
| JSON compilation, unaffected path | +1.89% / +0.67% | +2.92% / +2.16% |

Initial JSON candidate-role difference7.62%; refined CSV2.08%, text1.70%.
Refined text spreads1.85–2.84%; unchanged compilation is also adverse. JSON's
refined improvement is coherent across roles, but the earlier text gain is not
confirmed by the different source variant. Coarse refined CSV process-CPU medians
4.57/4.44ms vs4.29ms are adverse observations with tick-quantization limits, not
proof of a broad CPU regression. No exact allocation/RSS/host-latency claim.

Clocks include mediated RAM I/O, full validation and previous-result cleanup;
compilation is separate. Startup, staging/reset, transport and final teardown are
excluded. This source pair does not replace the primary CPython delivery tables.
No unchanged replay is scheduled; future re-entry needs a distinct justified design.

## Validation and restoration

Each prototype passes focused114internal/232public per actual.NET11/.NET10;
both-target builds have zero warnings/errors. These cover target evaluation order,
setters/protocols, genuine suspension, first refusal, cancellation, retained aliases
and budget cleanup. Original production source was restored with fresh timestamps,
then rebuilt nonincrementally. The same focused checks pass both runtimes after
withdrawal; normalized Git blobs match HEAD exactly. No prototype fields/helpers
or tests enforcing its architecture remain. Baseline full delivery remains green;
do not repeat platform/package qualification for unchanged runtime source.

VM setup failures were disk preflights before guest work. Preserve both failures
and corrections: exact local backups/raw archives validated before retiring unused
historical image cores/catalogs; all symlink dependencies inspected under lease;
current images/dependencies/sole evidence retained. Streaming the exact compressed
transfer saved a redundant VM file; workers/catalogs/raw evidence stayed persistent.
Original6MiB post-setup headroom, timeouts and containment checks were preserved.
No collection was restarted because an observation timed out.

The whole-script performance objective remains open. The next independent regex
source gate identifies actual per-match carrier and eager group materialization
allocations; core development does not wait for a producer release.
''',encoding='utf-8')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');at=s.index('\n')+1
s=s[:at]+'''
The [shared-target forwarding assessment](results/2026-11-06-shared-target-assessment/README.md)
withdraws both prototypes after complete113s source pairs. Initial text−4–5%
did not recur in the refinement; refined JSON improves4.7–5.4%, CSV stays mixed
with coarse adverse CPU, and compilation controls are adverse. Added forwarding/
branch complexity is not justified. Both candidates and restored source pass
114internal/232public per actual11/10; normalized production source is unchanged.
Raw adverse conditions, bounded refinement and setup corrections remain archived.

'''+s[at:];p.write_text(s,encoding='utf-8')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');(home/'plan-before-final-condensation.md').write_text(s,encoding='utf-8')
start=s.index('## Active R18:');end=s.index('## Whole-script roadmap:',start)
s=s[:start]+'''## R18 completed assessment: target forwarding withdrawn

Two coherent source variants passed114internal/232public each actual11/10 and
complete113s quiet source-pair gates. Initial text−4–5% did not recur after cold
protocol refinement; refined JSON−4.66/−5.44%, CSV+1.32/−0.78%, compile control
+2.92/+2.16%. Coarse CSV CPU medians were adverse; precision limits remain.
The modest architectural consolidation does not justify extra forwarding/branch
complexity and unresolved debt. Both variants withdrawn, not permanently banned.
All original/adverse/setup conditions remain in
benchmarks/results/2026-11-06-shared-target-assessment/.
Production normalized blobs match HEAD; fresh-timestamp restoration followed by
nonincremental build and same focused checks passes both runtimes. Baseline full
qualification stands; no platform/package replay for unchanged runtime code.
B353/B354 terminal/archived/verified, all users joined; never query them again.

## Next independent U04: one capture ownership/materialization contract

Demonstrated source work: adapters allocate LythonRegexMatch plus a nullable
capture array on every success. Core uses per-match ProviderCall delegates, then
eagerly copies whole/group strings and builds ReCapture records, even if only
positions or truth are used. ReCapture BigInteger fields are values, not separate
boxed allocations. Remove actual carriers/copies, not another dispatch shortcut.

Design contract gate: provider TryMatch/TryNext fills caller-owned
Span<LythonRegexCapture?>, returning success and lastIndex. Delete LythonRegexMatch
and old provider signatures; intentional0.11 provider API break, no compatibility
backend/options. Keep effective flags/names/byte ranges/original windows/scalar
positions, errors and current-token work. Normal0.4 and immutabledev44 can bridge
existing backend captures; no producer API/release is required for core work.

Core scratch uses existing subject/iterator owners and capacity admission. Remove
per-match delegates through direct provider calls with the existing shared error/
first-refusal mapping. Retained matches own immutable byte/scalar ranges over the
already-funded original subject. Materialize group strings at access with current
admission/provenance; preserve groups/defaults/regs/lastindex/lastgroup/expand,
callback suspension, captures before pos and unmatched/empty semantics. Delete
eager ReCapture records and redundant whole/group payload storage. Preserve funding
for original subjects and retained matches across cursor advances/disposal.

Tradeoff: group allocation/refusal moves to actual access; unused groups consume
no copied payload. Before implementation, inspect all match consumers and CPython
identity/immutability behavior; do not silently change supported aliases or reuse
mutable scratch as retained results. No new memory layer/tracing/pools/GC or quota.

Acceptance: existing re/window/flag/replacement/split tests and independent CPython
goldens; cooperating provider invalid metadata, actual in-flight cancellation,
first refusal/no later effects, retained matches/caches and reusable allowance.
Migrate normal adapter, test providers, owned cancellation fixture and installed
consumer together; focused actual11/10, then full platform/stress/package delivery.
One bounded identical-producer capture diagnostic and affected whole regex script;
separate allocation from CPU. No universal regex framework/final-buffer project.
The non-regex roadmap/objective remains independent and open; no old casing/count
pass proposal: current casing already uses byte bounds and one Unicode mapping
pass, fused whitespace computes capacities while scanning.

'''+s[end:]
s=s.replace('B346–B352 are terminal','B346–B354 are terminal')
p.write_text(s,encoding='utf-8')
subprocess.run(['git','diff','--exit-code','--','src/Lokad.Lython'],check=True)
subprocess.run(['git','diff','--check'],check=True)
subprocess.run(['git','add','--','benchmarks/EXPERIMENTS.md',str(out)],check=True)
subprocess.run(['git','diff','--cached','--check'],check=True)
subprocess.run(['git','commit','-m','Record target execution assessment and preserve source-pair evidence [skip ci]'],check=True)
