from pathlib import Path
import hashlib,json,subprocess
home=Path(__file__).parent;root=home/'b354';old=home.parent/'text-provenance-r17/b351';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt=json.loads((old/'archive-receipt.json').read_text(encoding='utf-8'));assert sha(old/'observations.tgz')==receipt['archiveSHA256']
proof={'catalogSHA256':sha(old/'representative.json'),'archiveSHA256':receipt['archiveSHA256']}
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
script='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess,tarfile
root=Path('/home/lokad/lython-bench-checks');old=root/'text-operation-provenance-b351-20261106';run=root/'shared-targets-b354-20261106';proof=PROOF
with (root/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not (run/'started.utc').exists() and not (run/'confirmation').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 unit=subprocess.run(['systemctl','show','lython-b354-shared-targets-20261106.service','--property=LoadState,ActiveState,MainPID'],capture_output=True,text=True)
 assert 'LoadState=not-found' in unit.stdout and 'MainPID=0' in unit.stdout,unit.stdout+unit.stderr
 assert (old/'image-retired.json').exists()
 catalog=old/'representative.json';assert not catalog.is_symlink() and catalog.resolve().parent==old
 assert hashlib.sha256(catalog.read_bytes()).hexdigest()==proof['catalogSHA256']
 assert hashlib.sha256((old/'observations.tgz').read_bytes()).hexdigest()==proof['archiveSHA256']
 with tarfile.open(old/'observations.tgz') as a:assert hashlib.sha256(a.extractfile('representative.json').read()).hexdigest()==proof['catalogSHA256']
 for directory,dirs,files in os.walk(root,followlinks=False):
  for name in dirs+files:
   p=Path(directory)/name
   if p.is_symlink():assert p.resolve()!=catalog
 catalog.unlink()
 identity=json.loads((run/'identity.json').read_text())
 for role in ['candidate','control','reference']:
  folder=run/('candidate' if role=='control' else role)
  assert hashlib.sha256((folder/'Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256'][role]
  for name,digest in identity['auxiliaryFiles'].items():assert hashlib.sha256((folder/name).read_bytes()).hexdigest()==digest
 free=shutil.disk_usage(root).free;assert free>6*1024*1024
 print(json.dumps({'setupFailureBeforeAnyCollection':True,'resumeValidatedExistingFrozenImages':True,'retiredArchivedExpandedCatalog':str(catalog),'proof':proof,'freeBytes':free,'unitBeforeLaunch':unit.stdout}))
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b354-shared-targets-20261106','--property=User=lokad','--property=WorkingDirectory='+str(run),'--property=RuntimeMaxSec=180','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(run/'run.sh')],check=True)
'''.replace('PROOF',repr(proof))
r=subprocess.run([*ssh,'python3 -'],input=script,capture_output=True,text=True,encoding='utf-8')
(home/'refined-resumed-launch.log').write_text(r.stdout+r.stderr,encoding='utf-8');print(r.stdout+r.stderr,flush=True);assert r.returncode==0
