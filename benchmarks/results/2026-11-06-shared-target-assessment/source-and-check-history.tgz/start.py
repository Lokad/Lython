from pathlib import Path
import hashlib,json,subprocess,tarfile
home=Path(__file__).parent;root=home/'b353';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=root/'collect.py';s=p.read_text(encoding='utf-8');start=s.index("purpose='")+len("purpose='");end=s.index("',",start)
s=s[:start]+'R18 shared subscript targets versus qualified b6650f09: complete warm CSV/text/JSON, unaffected JSON compilation, two identical current roles plus CPython/reference; no exact allocation/RSS/embedding latency claim'+s[end:];p.write_text(s,encoding='utf-8')
names=['Lokad.Lython.dll','identity.json','source.patch','source-snapshot.tgz','representative.json','focused-results.json','pre-measurement-plan.md','contract.md','setup.py','collect.py','run.sh','cpython-worker.py','archive-owned.py']
with tarfile.open(root/'payload.tgz','w:gz') as a:
    for name in names:a.add(root/name,arcname=name)
with tarfile.open(root/'payload.tgz') as a:expanded=sum(m.size for m in a.getmembers())
transfer=dict(payloadBytes=(root/'payload.tgz').stat().st_size,payloadSHA256=sha(root/'payload.tgz'),expandedBytes=expanded,requiredFreeBeforeTransfer=(root/'payload.tgz').stat().st_size+expanded+6*1024*1024)
(root/'transfer.json').write_text(json.dumps(transfer,indent=2)+'\n',encoding='utf-8')
old=home.parent/'text-provenance-r17/b351';prior=home.parent/'delivery-comparison-b352'
oldreceipt=json.loads((old/'archive-receipt.json').read_text(encoding='utf-8'));priorreceipt=json.loads((prior/'archive-receipt.json').read_text(encoding='utf-8'));priortransfer=json.loads((prior/'transfer.json').read_text(encoding='utf-8'))
assert oldreceipt['complete'] and oldreceipt['allWorkersJoined'] and sha(old/'observations.tgz')==oldreceipt['archiveSHA256']
assert priorreceipt['complete'] and priorreceipt['allWorkersJoined'] and sha(prior/'observations.tgz')==priorreceipt['archiveSHA256'] and sha(prior/'payload.tgz')==priortransfer['payloadSHA256']
proof={'coreSHA256':sha(old/'Lokad.Lython.dll'),'archiveSHA256':oldreceipt['archiveSHA256'],'newArchiveSHA256':priorreceipt['archiveSHA256'],'payloadSHA256':priortransfer['payloadSHA256']}
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
cleanup='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess
root=Path('/home/lokad/lython-bench-checks');proof=PROOF
old=root/'text-operation-provenance-b351-20261106';current=root/'delivery-comparison-b352-20261106'
with (root/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 for folder,expected in [(old,proof['archiveSHA256']),(current,proof['newArchiveSHA256'])]:
  receipt=json.loads((folder/'archive-receipt.json').read_text());assert receipt['complete'] and receipt['allWorkersJoined']
  assert hashlib.sha256((folder/'observations.tgz').read_bytes()).hexdigest()==expected
 payload=root/'b352-payload.tgz';assert not payload.is_symlink() and payload.resolve().parent==root
 assert hashlib.sha256(payload.read_bytes()).hexdigest()==proof['payloadSHA256']
 core=old/'Lokad.Lython.dll';alias=old/'candidate/Lokad.Lython.dll'
 assert not core.is_symlink() and core.resolve().parent==old and core.stat().st_nlink==1
 assert hashlib.sha256(core.read_bytes()).hexdigest()==proof['coreSHA256']
 assert alias.is_symlink() and alias.resolve()==core
 dependencies=[]
 for directory,dirs,files in os.walk(root,followlinks=False):
  for name in dirs+files:
   path=Path(directory)/name
   if path.is_symlink():
    target=path.resolve()
    if target==core or target in core.parents:dependencies.append(str(path))
 assert dependencies==[str(alias)] or sorted(dependencies)==[str(alias)],dependencies
 assert (current/'candidate/Lokad.Lython.dll').resolve()!=core
 payload.unlink();alias.unlink();core.unlink()
 record={'retiredUnusedImageCore':str(core),'dependenciesWithinRetiredImage':dependencies,'localVerifiedBackup':'text-provenance-r17/b351/Lokad.Lython.dll','proof':proof,'removedRedundantTransfer':str(payload),'freeBytes':shutil.disk_usage(root).free,'currentImagesAndAllArchivesPreserved':True}
 (old/'image-retired.json').write_text(json.dumps(record,indent=2)+'\\n');print(json.dumps(record))
'''.replace('PROOF',repr(proof))
r=subprocess.run([*ssh,'python3 -'],input=cleanup,text=True,encoding='utf-8',capture_output=True)
(home/'image-retirement.log').write_text(r.stdout+r.stderr,encoding='utf-8');assert r.returncode==0,r.stderr
print(r.stdout,flush=True);assert json.loads(r.stdout)['freeBytes']>transfer['requiredFreeBeforeTransfer']
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for name,target in [('payload.tgz','b353-payload.tgz'),('transfer.json','b353-transfer.json'),('launch.py','b353-launch.py')]:
    p=subprocess.run([*scp,str(root/name),'lokad@20.166.121.73:/home/lokad/lython-bench-checks/'+target],capture_output=True,text=True,encoding='utf-8');assert p.returncode==0,p.stderr
r=subprocess.run([*ssh,'python3 /home/lokad/lython-bench-checks/b353-launch.py'],capture_output=True,text=True,encoding='utf-8')
(home/'launch.log').write_text(r.stdout+r.stderr,encoding='utf-8');print(r.stdout+r.stderr,flush=True);assert r.returncode==0
