from pathlib import Path
import hashlib,json,os,re,subprocess,sys
root=Path(__file__).parent;repo=Path('D:/code/Lython')
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
checks={}
def run(label,args):
    log=root/(label+'.log')
    with log.open('w',encoding='utf-8') as output:r=subprocess.run([env['DOTNET_HOST_PATH'],*args],cwd=repo,env=env,stdout=output,stderr=subprocess.STDOUT)
    text=log.read_text(encoding='utf-8');print(label,r.returncode,text[-900:],flush=True)
    if r.returncode:sys.exit(r.returncode)
    m=re.search(r'Passed:\s+(\d+)',text);checks[label]={'passed':int(m[1])} if m else {'exitCode':r.returncode}
for project in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:run('build-'+project,['build','tests/'+project,'-c','Release','--nologo','--tl:off'])
terms={
    'Lokad.Lython.Tests':['ExecutableSubscriptStoreTests','ExecutableAugmentedSubscriptTests','InstructionFailureRoutingTests','DeferredFunctionOwnershipTests','LocalAugmentedLifetimeTests','LoweredAugmentedTargetBoundaryTests','SubscriptSetterBindingTests','PostfixCallAssignmentHostTests','DictionaryOperationContextTests','NativeCompiledFunctionTests'],
    'Lokad.Lython.PublicApi.Tests':['SubscriptStoreExecutionTests','AssignmentTargetCompatibilityTests','AugmentedTargetRetentionTests','AugmentedSubscriptExecutionTests','DeferredFunctionContextTests','HeaderAssignmentScenarioTests','SubscriptIndexProtocolTests','GeneratorTargetCompositionTests','PostfixCallAssignmentTests','ExactSequenceSubscriptTests','GovernedMemoryContractTests']}
for framework in ['net11.0','net10.0']:
    for project,names in terms.items():
        selection='Category!=Stress&('+'|'.join('FullyQualifiedName~'+name for name in names)+')'
        run(project+'-'+framework,['test','tests/'+project,'-c','Release','-f',framework,'--no-build','--no-restore','--filter',selection])
checks['coreSHA256']={f:hashlib.sha256((repo/f'src/Lokad.Lython/bin/Release/{f}/Lokad.Lython.dll').read_bytes()).hexdigest() for f in ['net11.0','net10.0']}
(root/'focused-results.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8')
