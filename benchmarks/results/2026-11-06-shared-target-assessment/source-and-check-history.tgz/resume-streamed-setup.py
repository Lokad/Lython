from pathlib import Path
import hashlib,json,subprocess
home=Path(__file__).parent;root=home/'b353'
assert not (home/'streamed-launch.log').exists()
transfer=json.loads((root/'transfer.json').read_text(encoding='utf-8'))
source=(root/'launch.py').read_text(encoding='utf-8').replace('import ast,fcntl,hashlib,json,shutil,subprocess,tarfile','import ast,fcntl,hashlib,io,json,shutil,subprocess,sys,tarfile')
source=source.replace("root=Path('/home/lokad/lython-bench-checks/shared-targets-b353-20261106');payload=root.parent/'b353-payload.tgz'", "root=Path('/home/lokad/lython-bench-checks/shared-targets-b353-20261106')")
source=source.replace("assert hashlib.sha256(payload.read_bytes()).hexdigest()==expected['payloadSHA256']\n with tarfile.open(payload) as t:","payload=sys.stdin.buffer.read(expected['payloadBytes']+1)\n assert len(payload)==expected['payloadBytes'] and hashlib.sha256(payload).hexdigest()==expected['payloadSHA256']\n with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as t:")
assert 'payload.read_bytes' not in source and 'io.BytesIO(payload)' in source
(root/'launch-stream.py').write_text(source,encoding='utf-8')
(home/'setup-correction.md').write_text('''# B353 setup correction before any collection
The first disk preflight stopped after retiring an unused historical image and a
verified redundant transfer. Free13,979,648B was below14,613,225B required to hold
both compressed payload and expanded persistent workers with6MiB headroom.
No workload/service was launched. Retain the failure and all retirement proof.
Stream the exact locally retained/hash-verified payload into the owned extraction
bootstrap. Transport scratch alone is temporary Python bytes; worker images,
catalog, raw results and archives remain persistent. Preserve the original6MiB
post-extraction headroom and all measurement/timeout/containment gates. This saves
only the redundant1.9MiB compressed VM transfer; no source/test/timing condition
changes and no old service/workload is restarted.
''',encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for name,target in [('transfer.json','b353-transfer.json'),('launch-stream.py','b353-launch-stream.py')]:
    p=subprocess.run([*scp,str(root/name),'lokad@20.166.121.73:/home/lokad/lython-bench-checks/'+target],capture_output=True,text=True,encoding='utf-8');assert p.returncode==0,p.stderr
payload=(root/'payload.tgz').read_bytes();assert hashlib.sha256(payload).hexdigest()==transfer['payloadSHA256']
r=subprocess.run([*ssh,'python3 /home/lokad/lython-bench-checks/b353-launch-stream.py'],input=payload,capture_output=True)
output=(r.stdout+r.stderr).decode('utf-8');(home/'streamed-launch.log').write_text(output,encoding='utf-8');print(output,flush=True);assert r.returncode==0
