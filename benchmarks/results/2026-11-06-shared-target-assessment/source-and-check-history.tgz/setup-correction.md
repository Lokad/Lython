# B353 setup correction before any collection
The first disk preflight stopped after retiring an unused historical image and a
verified redundant transfer. Free13,979,648B was below14,613,225B required to hold
both compressed payload and expanded persistent workers with6MiB headroom.
No workload/service was launched. Retain the failure and all retirement proof.
Stream the exact locally retained/hash-verified payload into the owned extraction
bootstrap. Transport scratch alone is temporary Python bytes; worker images,
catalog, raw results and archives remain persistent. Preserve the original6MiB
post-extraction headroom and all measurement/timeout/containment gates. This saves
only the redundant1.9MiB compressed VM transfer; no source/test/timing condition
changes and no old service/workload is restarted.
