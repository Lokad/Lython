from pathlib import Path
root=Path(__file__).parent
source=(root/'check.py').read_text(encoding='utf-8')
source=source.replace("label+'.log'","'refined-'+label+'.log'").replace("'focused-results.json'","'refined-focused-results.json'")
exec(compile(source,str(root/'check.py'),'exec'),{'__file__':str(root/'check.py'),'__name__':'__main__'})
