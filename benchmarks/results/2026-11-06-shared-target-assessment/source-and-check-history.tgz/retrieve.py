from pathlib import Path
root=Path(__file__).parent
source=(root.parent/'delivery-comparison-b352/retrieve.py').read_text(encoding='utf-8')
source=source.replace('b352','b353').replace('delivery-comparison','shared-targets').replace("['jobs']==15","['jobs']==4")
target=root/'b353/retrieve.py';target.write_text(source,encoding='utf-8')
exec(compile(source,str(target),'exec'),{'__file__':str(target),'__name__':'__main__'})
