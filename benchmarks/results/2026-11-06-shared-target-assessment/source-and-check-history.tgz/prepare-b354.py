from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
home=Path(__file__).parent;old=home/'b353';root=home/'b354';root.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
remote='/home/lokad/lython-bench-checks/shared-targets-b354-20261106';oldremote='/home/lokad/lython-bench-checks/shared-targets-b353-20261106'
def write(n,s):
    with (root/n).open('w',encoding='utf-8',newline='\n') as f:f.write(s)
checks=json.loads((home/'refined-focused-results.json').read_text(encoding='utf-8'));core=Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll');assert sha(core)==checks['coreSHA256']['net11.0']
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'));identity['sourceRevision']='7f266368 plus refined R18 shared subscript targets; native common path/cold protocol completion'
identity['coreSHA256'].update(candidate=sha(core),control=sha(core));identity['qualification']=checks;identity['priorObservation']='B353: text -4.10/-5.07%; CSV +2.09/+5.70%; JSON conflicting -4.13/+3.18%; raw conditions retained'
write('identity.json',json.dumps(identity,indent=2)+'\n');shutil.copyfile(core,root/'Lokad.Lython.dll');shutil.copyfile(old/'representative.json',root/'representative.json');write('focused-results.json',json.dumps(checks,indent=2)+'\n')
(root/'source.patch').write_bytes(subprocess.check_output(['git','-c','core.safecrlf=false','diff','--','src/Lokad.Lython']))
files=subprocess.check_output(['git','diff','--name-only','--','src/Lokad.Lython'],text=True).splitlines()
with tarfile.open(root/'source-snapshot.tgz','w:gz') as a:
    for name in files:a.add(name,arcname=name)
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');mark='Source fact: ordinary subscript stores'
s=s.replace(mark,'''B353 completed113.14s with all owned gates. Text elapsed−4.10/−5.07%, but
CSV+2.09/+5.70% and JSON−4.13/+3.18% conflict. Compile control+0.67/+1.89%.
Preserve the original variant, all samples and setup disk failure. B354 is one
bounded refinement: keep common decoded native writes small and move protocol/
suspension completion to the existing cold completion boundary. It removes no
semantics or checks; Release114internal/232public per actual11/10 pass. Same four
jobs/controls/baseline/worker/180s owner, not an unchanged replay. Decide the
remaining benefit/debt after this pair; do not automatically promote the prototype.

'''+mark);p.write_text(s,encoding='utf-8');write('pre-measurement-plan.md',s)
for name in ['collect.py','run.sh','cpython-worker.py','archive-owned.py','setup.py','launch-stream.py']:
    s=(old/name).read_text(encoding='utf-8').replace(oldremote,remote)
    if name=='launch-stream.py':s=s.replace('b353','b354')
    write(name,s)
write('contract.md',(old/'contract.md').read_text(encoding='utf-8')+'''
## B354 bounded refinement
Preserve B353's text benefit, adverse CSV and conflicting JSON; no unchanged rerun.
Shared native operand decoding remains; protocol invocation/completion is cold,
outside the native catch, so retirement is never retried. Both actual runtimes
pass focused checks. Same four jobs/worker/baseline/controls/conditions, one bounded
decision on remaining regression debt. No new quota, cache, owner or backend.
''')
names=['Lokad.Lython.dll','identity.json','source.patch','source-snapshot.tgz','representative.json','focused-results.json','pre-measurement-plan.md','contract.md','setup.py','collect.py','run.sh','cpython-worker.py','archive-owned.py']
with tarfile.open(root/'payload.tgz','w:gz') as a:
    for name in names:a.add(root/name,arcname=name)
with tarfile.open(root/'payload.tgz') as a:expanded=sum(m.size for m in a.getmembers())
transfer=dict(payloadBytes=(root/'payload.tgz').stat().st_size,payloadSHA256=sha(root/'payload.tgz'),expandedBytes=expanded,requiredFreeBeforeStreamedSetup=expanded+6*1024*1024)
write('transfer.json',json.dumps(transfer,indent=2)+'\n');print(transfer)
