from pathlib import Path
import hashlib,json,subprocess
root=Path(__file__).parent
files=['src/Lokad.Lython/Runtime/LythonRuntime.Executable.Targets.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs']
(root/'refined-prototype.patch').write_bytes(subprocess.check_output(['git','-c','core.safecrlf=false','diff','--','src/Lokad.Lython']))
record={}
for name in files:
    p=Path(name);before=p.read_bytes();source=(root/p.name).read_text(encoding='utf-8')
    assert source==subprocess.check_output(['git','show','HEAD:'+name],text=True,encoding='utf-8').replace('\r\n','\n')
    p.write_text(source,encoding='utf-8')
    record[name]={'prototypeSHA256':hashlib.sha256(before).hexdigest(),'restoredNormalizedSHA256':hashlib.sha256(p.read_bytes()).hexdigest(),'freshTimestamp':p.stat().st_mtime}
subprocess.run(['git','diff','--exit-code','--','src/Lokad.Lython'],check=True)
(root/'withdrawal.json').write_text(json.dumps({'decision':'Withdraw both target-forwarding prototypes; architecture gain insufficient for extra branches/handlers and CSV CPU debt; not a permanent ban or percentage veto','source':record,'sourceRestoredWithoutPreservingTimestamps':True,'noLiveOwnedVMWork':True,'noCIReplayRequiredForUnchangedRuntime':True},indent=2)+'\n',encoding='utf-8')
script=(root/'check.py').read_text(encoding='utf-8').replace("label+'.log'","'withdrawn-'+label+'.log'").replace("'focused-results.json'","'withdrawn-focused-results.json'")
script=script.replace("'-c','Release','--nologo','--tl:off'","'-c','Release','--no-incremental','--nologo','--tl:off'",1)
exec(compile(script,str(root/'check.py'),'exec'),{'__file__':str(root/'check.py'),'__name__':'__main__'})
