from pathlib import Path
import hashlib, json, subprocess, tarfile

lab=Path(__file__).resolve().parent
root=lab.parents[3]
dest=root/'benchmarks/results/2026-11-23-current-factory-allocation'
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
identity=read(lab/'identity.json')
summary=read(lab/'run-summary.json')
assert summary['retainedSource']==identity['retainedRevision']
assert not subprocess.check_output(['git','diff','--name-only',summary['retainedSource'],'HEAD','--','src'],cwd=root)
files=identity['imageFiles']['candidate']
assert len(files)==32 and all(digest(lab/'retained'/name)==expected for name,expected in files.items())
assert summary['allProcessesJoined'] and digest(lab/'catalog.json')==summary['catalogSha']
verification=read(lab/'verification.json')
assert verification['state']=='Completed' and verification['caseCount']==3
assert verification['launched']['library']['sha256']==files['Lokad.Lython.dll']
raw=()
proof={}
for name in ('postponed','eager','invoice'):
    local=lab/name
    row=read(local/'record.json')
    assert row['allProcessesJoined'] and digest(local/'warm.nettrace')==row['nettraceSha']
    assert row['coreSha']==files['Lokad.Lython.dll']
    profile=read(local/'sampled-allocation.json')
    proof[name]=dict(workload=row['workload'],traceSHA256=row['nettraceSha'],
        allocationTicks=profile['Samples'],batches=len(row['batches']),
        invocations=sum(x['completedInvocations'] for x in row['batches']),
        allocationWeight=profile['Rows'][:10])
    raw+=tuple(name+'/'+entry for entry in ('warm.nettrace','allocation-stacks.json',
        'sampled-allocation.json','record.json','capture.log','worker.stderr','allocation.log'))
assert sum(row['batches'] for row in proof.values())==summary['totalVerifiedBatches']
summary['workloads']=proof
dest.mkdir(exist_ok=True)
assert all(path.name=='README.md' for path in dest.iterdir())
(dest/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(dest/'observations-and-procedures.tar.xz','w:xz',preset=3) as bundle:
    for name in ('archive.py','build-profile.py','profile-allocation.py','run-summary.json',
        'catalog.json','identity.json','verification.json',*raw):
        bundle.add(lab/name,arcname=name)
print(dest)
