from pathlib import Path
import hashlib, json, shutil, subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
notes=lab.parent
retained=notes/'supplied-lexical-call-20261123'
proof=json.loads((repo/'benchmarks/results/2026-11-23-supplied-lexical-call/identity.json').read_text(encoding='utf-8'))
assert not subprocess.check_output(['git','diff','--name-only',proof['retainedRevision'],'HEAD','--','src'],cwd=repo)
image=lab/'retained'
image.mkdir()
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
files=proof['imageFiles']['candidate']
assert len(files)==32
for name,expected in files.items():
    source=retained/'candidate'/name
    assert digest(source)==expected
    shutil.copyfile(source,image/name)
assert all(digest(image/name)==expected for name,expected in files.items())
shutil.copyfile(repo/'benchmarks/results/2026-11-23-supplied-lexical-call/identity.json',lab/'identity.json')
shutil.copyfile(notes/'closed-defaults-cpython-20261123/comparison/quiet/representative.json',lab/'reference-catalog.json')
prior=notes/'supplied-call-accumulation-20261123/reference-allocation-attribution/profile-allocation.py'
source=prior.read_text(encoding='utf-8')
updates=(
    ('repo=lab.parents[4]','repo=lab.parents[3]'),('notes=lab.parents[1]','notes=lab.parent'),
    ('(lab.parent/"comparison/identity.json")','(lab/"identity.json")'),
    ('proof["revision"]=proof["sourceRevision"]','proof["revision"]=proof["retainedRevision"]'),
    ('expected=proof["imageFiles"]["reference"]','expected=proof["imageFiles"]["candidate"]'),
    ('(lab.parent/"comparison/representative.json")','(lab/"reference-catalog.json")'),
    ('ids=("scripts.ordinary-fully-supplied-helper",)','ids=("scripts.annotated-rule-closures.nested-factories.postponed",\n'
     '    "scripts.annotated-rule-closures.nested-factories", "scripts.csv-invoice.method-policy.quoted-control")'),
    ('verification["caseCount"]==1','verification["caseCount"]==3'),
    ("zip(('supplied-call',),cases,strict=True)","zip(('postponed','eager','invoice'),cases,strict=True)"),
)
for a,b in updates:
    assert source.count(a)==1,a
    source=source.replace(a,b)
out=lab/'profile-allocation.py'
compile(source,str(out),'exec')
out.write_text(source,encoding='utf-8',newline='\n')
