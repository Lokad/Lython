# R198 bounded ordinary-method frame comparison

Existing complete class-renderer report versus qualified8d44/E294; same exact
fixtures/output goldens, auxiliary binaries, adapter0.4 and common protocol.
Reference/candidate each have independent controls;5s warmup,7rotated400msrounds.
Fivejobs: class-report warm/both APIs, its compilation, unchanged free-function
report/text warm controls.240sowner/30sstop/30smargin. Current cancellation,
admitted ownership, joins, quiet gates, persistent archive/SHA before RAM retirement.
No speedup/neutrality claim before results; all desktop adversity preserved.
