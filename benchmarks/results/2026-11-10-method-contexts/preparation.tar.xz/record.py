from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
h=Path(__file__).parent;p=h/'b548';d=h/'diagnostic';repo=Path('D:/code/Lython');dest=repo/'benchmarks/results/2026-11-10-method-contexts';dest.mkdir()
summary=json.loads((p/'summary.json').read_text(encoding='utf-8'));receipt=json.loads((p/'archive-receipt.json').read_text(encoding='utf-8'));identity=json.loads((d/'identity.json').read_text(encoding='utf-8'))
assert summary['complete']and receipt['jobs']==5 and hashlib.sha256((p/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
assert len(identity['source'])==568 and all(hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest for name,digest in identity['source'].items())
for name in ['summary.json','archive-receipt.json','observations.tgz','identity.json','terminal-status.json','extraction.json']:shutil.copyfile(p/name,dest/name)
for name in ['observations-partial.tgz','partial-archive-receipt.json','terminal-failure.json']:shutil.copyfile(h/'b547'/name,dest/('startup-'+name))
desktop=dest/'desktop';desktop.mkdir()
for phase in ['warm','warm-async','compile']:
 (desktop/phase).mkdir()
 for name in ['measurements.json','summary.json','stderr.txt']:shutil.copyfile(d/phase/name,desktop/phase/name)
proof=dict(all568ProductionFilesMatchMeasuredPrototype=True,coreSHA256=identity['cores'],baseRevision='28cb769a; fullyqualified8d44 runtime before R198',changes='Only PyExecutableFunction.CanDeferInvocationContext owner-type proxy restriction removed; no other production changes.',finalTests='102public/71internal eachactual.NET11/10 plus18public supplemental eachtarget (15overlap), covering3additionalcases. Supplemental tests were added after image freeze; production unchanged.',fullDelivery='Pending separate exact-commit Windows/Ubuntu, actual11/10 ordinary, originalStress and installedReleaseconsumers. No publication.')
(dest/'source-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
(h/'final-source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src','tests'],cwd=repo,stderr=subprocess.DEVNULL))
with tarfile.open(dest/'preparation.tar.xz','w:xz')as a:
 for path in sorted(h.rglob('*')):
  if not path.is_file():continue
  rel=path.relative_to(h)
  if 'images'in rel.parts or'retrieved'in rel.parts or path.name in ['observations.tgz','observations-partial.tgz','payload.tgz']:continue
  if rel.parts[0]=='diagnostic'and rel.parts[1]in ['warm','warm-async','compile']:continue
  a.add(path,arcname=rel.as_posix())
 for name in identity['source']:a.add(repo/name,arcname='source/'+name)
 for name in ['tests/Lokad.Lython.PublicApi.Tests/DeferredFunctionContextTests.cs','tests/Lokad.Lython.Tests/DeferredFunctionOwnershipTests.cs']:a.add(repo/name,arcname='final-tests/'+name)
rows=[]
for x in summary['timing']:
 e=list(x['changePercent'].values());c=list(x['processCpuChangePercent'].values());sp=x['controlSpreadPercent']
 rows.append(f"| {x['case'].removeprefix('scripts.')} / {x['lane']} | {min(e):+.2f}..{max(e):+.2f}% | {min(c):+.2f}..{max(c):+.2f}% | {sp['reference']:.2f}% / {sp['candidate']:.2f}% |")
(dest/'README.md').write_text('''# R198 — scope facts govern ordinary method contexts

The retained change removes the owner-type proxy from the existing deferred
function-context predicate. Owner binding affects context setup only when lexical
class-cell facts require it, which the predicate already excludes. Eligible
ordinary methods now use the same owned slot workstate and scope-sensitive
promotion as functions. No new execution path, cache, option or ownership layer.
Captured local cells, class cells, implicit super and protected bodies keep their
context; later namespace/protocol/I/O work promotes without replaying prior effects.

The complete class-renderer report reads 3,072 JSON records (189,441 bytes), calls
an ordinary multi-statement formatting method for each and writes a Markdown file.
It is the existing report with only the helper expressed as a class method.
Independent CPython3.13.2 verifies full stdout/file goldens; it is not a timed
external baseline. The primary CPython guide retains its qualified8d44 source.

Reference is fully qualified8d44, fresh postcommit core E294; prototype is the
one production restriction deletion on28cb769a, frozen039dc975. All568 production
files still match [source proof](source-proof.json). Exact cores, scripts, source,
test logs and both patches survive in raw evidence/[preparation](preparation.tar.xz).
Supplemental tests were added after freeze; no production code changed.

Desktop CLR allocation decreases28.51%synchronously/28.50%asynchronously on the
class report. Compilation allocation is flat. [All desktop observations](desktop/)
retain diagnostic elapsed gains and unchanged asyncCSV+6.2..6.5% / compileCSV
+17..20% adversity. These are not CPU qualification or evidence of neutrality.
Desktop Run-only clocks exclude reset, goldens and result disposal; its full
envelope/allocation includes those costs. Startup/compilation are separate.

The quiet F4as_v7/Ubuntu24.04.4/.NET11RC3 confirmation completes five jobs in
179.869seconds, stock GC/tiering, two independent processes per source,5s warmup,
seven rotated400ms rounds. Both source APIs use the existing worker and optional
adapter0.4. [Raw evidence](observations.tgz), [all medians/CPU/IQR/pairings](summary.json),
[receipt](archive-receipt.json). Ranges are all four median pairings, not confidence
intervals. Wider CPU includes reset/protocol and coarse100Hz ticks.

| Complete script / phase | Elapsed change | Wider process CPU | Reference / candidate control spread |
| --- | ---: | ---: | ---: |
'''+ '\n'.join(rows)+'''

Warm VM clocks include mediated RAM I/O, full output validation and prior-result
cleanup; reset, staging, compilation and startup are excluded. Compile measures
construction/disposal. Async uses completed I/O, not pending-I/O latency. Modest
compile differences have no demonstrated causal explanation in this runtime-only
predicate change. Report controls remain inconclusive; CPU up to1.57% is possible
debt. Async class-report candidate spread3.63%/maxIQR3.55% stays visible. Desktop
CSV adversity is not resolved by these other controls and remains qualification debt.

Decision: retain the shared scope invariant and measured whole-class-report frame
reduction. No general CPU/neutrality claim, unchanged retiming or publication.
The broader text/call/record/frontend performance roadmap remains active.

Focused102public/71internal pass per actual.NET11/10;18supplemental public cases
per target (15overlap) cover classmethods and exact method traceback spans. Scope,
super/closures, reentrant admission/refusal, real suspended I/O, cancellation,
retained aliases and cleanup/reuse remain covered. Full delivery qualification is
recorded separately against the committed source, not inferred from these checks.

The original B547 attempt omitted control-process hashes and failed during startup
before warmups/timing: [original archive](startup-observations-partial.tgz),
[receipt](startup-partial-archive-receipt.json). It was joined/cleaned and preserved;
B548 corrects only the manifest, using identical frozen code/settings. Two earlier
headroom refusals, original logs and canonical-copy recovery survive. A bounded
idle operation retired five verified committed duplicate compressed archives,
preserving every image and sole evidence. All successful users joined, RAM removed,
archive verified under lease/local SHA verified; terminal owners are cached.
''',encoding='utf-8',newline='\n')
guide=repo/'docs/BENCHMARKS.md';s=guide.read_text(encoding='utf-8');needle='| Receiver-aware native entry / complete bound-method text |';index=s.index(needle)
s=s[:index]+'''| Scope-based method contexts / complete class-renderer report | CLR allocation about−28.5%both APIs; quiet warm elapsed−7.1–9.7%sync/−4.6–9.9%async with supporting wider CPU | Separate class-helper source pair, not the primary CPython rows. Unchanged report inconclusive; desktop CSV/compile adversity unresolved. [R198](../benchmarks/results/2026-11-10-method-contexts/README.md) |
'''+s[index:];guide.write_text(s,encoding='utf-8',newline='\n')
exp=repo/'benchmarks/EXPERIMENTS.md';s=exp.read_text(encoding='utf-8');index=s.index('The [R197 committed-source CPython checkpoint]')
s=s[:index]+'''The [R198 ordinary-method context simplification](results/2026-11-10-method-contexts/README.md)
removes the redundant owner-type restriction and reuses scope-sensitive function
promotion. Class-report allocation falls about28.5%both APIs; quiet elapsed falls
roughly7–10%sync/5–10%async, supporting widerCPU. Report controls and desktop CSV
debt remain. Original startup manifest failure had zero timed jobs; preserved and
corrected without changing code/settings. Full qualification is recorded separately.

'''+s[index:];exp.write_text(s,encoding='utf-8',newline='\n')
print('Recorded retained method simplification, allocation/CPU distinction, source proof, original failures and unresolved controls.')
