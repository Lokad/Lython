from pathlib import Path
import ast,hashlib,json,subprocess
h=Path(__file__).parent;p=h/'b547';repo=Path('D:/code/Lython')
names=subprocess.check_output(['git','ls-files','-z','benchmarks/results'],cwd=repo).decode('utf-8').split('\0');registry={}
for name in names:
 if Path(name).name.startswith('observations')and name.endswith(('.tgz','.tar.xz','.tar.gz')):
  path=repo/name
  with path.open('rb')as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
  registry.setdefault(digest,[]).append(dict(canonical=name,bytes=path.stat().st_size))
print('Committed canonical archive registry:',sum(map(len,registry.values())),flush=True)
script=r'''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess,tarfile
registry=REGISTRY
base=Path('/home/lokad/lython-bench-checks').resolve();root=base/'deferred-method-b547-20261110';fixture=root/'guest-fixtures'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert(root/'exit-code.txt').read_text().strip()=='1'
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 raw=json.loads((root/'confirmation/confirmation.json').read_text());assert not raw['complete']and not raw['jobs']
 assert fixture.is_dir()and not list(fixture.iterdir())
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir()
 before=shutil.disk_usage(base).free;available=[]
 for folder in base.iterdir():
  if not folder.is_dir()or folder.name in ['deferred-method-b547-20261110','deferred-method-b548-20261110']:continue
  for path in folder.iterdir():
   if path.name.startswith('observations')and path.name.endswith(('.tgz','.tar.xz','.tar.gz')):
    s=path.lstat()
    if stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_nlink==1:available.append((s.st_size,path))
 retired=[];reclaim=0
 for size,path in sorted(available,key=lambda x:x[0],reverse=True)[:128]:
  with path.open('rb')as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
  if digest not in registry:continue
  proof=next((c for c in registry[digest]if c['bytes']==size),None)
  if proof is None:continue
  s=path.lstat();assert path.resolve(strict=True).is_relative_to(base)and s.st_nlink==1 and s.st_uid==os.getuid()and stat.S_ISREG(s.st_mode)
  retired.append(dict(path=str(path),bytes=size,sha256=digest,canonical=proof['canonical'],allocatedBytes=s.st_blocks*512));reclaim+=s.st_blocks*512
  if len(retired)==5:break
 assert reclaim>=8*1024*1024,(len(retired),reclaim)
 for entry in retired:Path(entry['path']).unlink()
 recovery=dict(freshIdleLease=True,canonicalCommittedHEAD='28cb769a',beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,files=retired,imagesUnchanged=True,onlyDuplicateCompressedArchives=True)
 (root/'bounded-archive-recovery.json').write_text(json.dumps(recovery,indent=2)+'\n')
 (root/'failure-journal.txt').write_text(subprocess.check_output(['journalctl','--no-pager','-u','lython-b547-deferred-method-20261110.service','-n','45'],text=True))
 with tarfile.open(root/'observations-partial.tgz','w:gz',dereference=True)as a:
  for path in sorted(root.rglob('*')):
   if path.is_file()and path.name!='observations-partial.tgz'and not any(n in path.relative_to(root).parts for n in ['candidate','reference']):a.add(path,arcname=path.relative_to(root).as_posix())
 assert shutil.disk_usage(base).free>(240+12)*1024*1024
 with tarfile.open(root/'observations-partial.tgz')as a:assert not json.loads(a.extractfile('confirmation/confirmation.json').read())['jobs']
 receipt=dict(complete=False,timedJobs=0,reason='Comparison manifest omitted reference-control/candidate-control hashes; stopped during startup before warmups/timing.',allWorkersJoined=True,guestFixturesRemoved=True,archivedAndVerifiedUnderLease=True,archiveSHA256=hashlib.sha256((root/'observations-partial.tgz').read_bytes()).hexdigest(),freeBytesAfterArchive=shutil.disk_usage(base).free,performanceQualified=False)
 (root/'partial-archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
'''.replace('REGISTRY',repr(registry))
ast.parse(script);(p/'partial-recovery-command.py').write_text(script,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
r=subprocess.run(ssh+['python3 -'],input=script,text=True,encoding='utf-8',capture_output=True);(p/'partial-recovery.log').write_text(r.stdout+'\n'+r.stderr,encoding='utf-8',newline='\n');assert r.returncode==0,r.stderr;print(r.stdout,flush=True)
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for name in ['observations-partial.tgz','partial-archive-receipt.json']:
 subprocess.run(scp+['lokad@20.166.121.73:/home/lokad/lython-bench-checks/deferred-method-b547-20261110/'+name,str(p/name)],check=True)
assert hashlib.sha256((p/'observations-partial.tgz').read_bytes()).hexdigest()==json.loads((p/'partial-archive-receipt.json').read_text(encoding='utf-8'))['archiveSHA256']
print('Original startup failure archived/SHA verified; no VM users/RAM fixtures. No owner restart.',flush=True)
