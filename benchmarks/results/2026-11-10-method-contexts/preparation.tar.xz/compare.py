from pathlib import Path
import base64,copy,hashlib,json,os,shutil,statistics,subprocess,tempfile
h=Path(__file__).parent;repo=Path('D:/code/Lython');d=h/'diagnostic';d.mkdir()
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH'];dotnet=env['DOTNET_ROOT']+'/dotnet.exe'
shared=h.parent/'iterative-json-r196/refined-diagnostic/images/candidate'
for role in ['before','candidate']:shutil.copytree(shared,d/'images'/role)
shutil.copyfile(h.parent/'json-cpython-r197/current-core.dll',d/'images/before/Lokad.Lython.dll')
shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',d/'images/candidate/Lokad.Lython.dll')
assert hashlib.sha256((d/'images/before/Lokad.Lython.dll').read_bytes()).hexdigest()=='e294fad194255fa086a3356a6adc57061ac3f764cc632f83bc459fa784f41ed9'
assert all(p.read_bytes()==(d/'images/candidate'/p.relative_to(d/'images/before')).read_bytes()for p in(d/'images/before').rglob('*')if p.is_file()and p.name!='Lokad.Lython.dll')
catalog=json.loads((h.parent/'json-cpython-r197/representative.json').read_text(encoding='utf-8'))
report=next(c for c in catalog['cases']if c['id']=='scripts.report-render.large');target=copy.deepcopy(report)
a='def render(record):\n    return ';assert target['source'].count(a)==1
target['source']=target['source'].replace(a,'class Renderer:\n    def render(self,record):\n        return ').replace("\n\nwith open('records.json')","\n\nrenderer=Renderer()\n\nwith open('records.json')").replace('target.write(render(record))','target.write(renderer.render(record))')
target['id']='scripts.report-render.class-renderer.large';target['sourceSha256']=hashlib.sha256(target['source'].encode('utf-8')).hexdigest()
prior=json.loads((h.parent/'receiver-native-entry-r192/diagnostic/catalog.json').read_text(encoding='utf-8'));csv=next(c for c in prior['cases']if c['id'].startswith('scripts.csv-'))
catalog['cases']=[target]+catalog['cases']+[csv];assert len(catalog['cases'])==5
(d/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(h.parent/'receiver-native-entry-r192/diagnostic/hash-witness.json',d/'hash-witness.json')
goldens=[]
for c in catalog['cases']:
 fixture=json.loads(c['fixtureJson'])
 with tempfile.TemporaryDirectory(prefix='lython-r198-golden-')as folder:
  folder=Path(folder)
  for path,encoded in fixture['inputFiles'].items():
   dest=folder/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(base64.b64decode(encoded,validate=True))
  r=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',c['source']],cwd=folder,text=True,encoding='utf-8',capture_output=True,timeout=15)
  assert r.returncode==0 and not r.stderr and r.stdout==c['expectedOutput'],(c['id'],r.stderr)
  assert all((folder/path).read_bytes()==base64.b64decode(encoded,validate=True)for path,encoded in fixture['outputFiles'].items())
  goldens.append(dict(case=c['id'],sourceSHA256=c['sourceSha256'],stdout=r.stdout,allFileGoldensPassed=True,reference='CPython3.13.2; semantic golden, not timed baseline'))
(d/'script-goldens.json').write_text(json.dumps(goldens,indent=2)+'\n',encoding='utf-8',newline='\n')
(d/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src','tests'],cwd=repo,stderr=subprocess.DEVNULL))
(d/'identity.json').write_text(json.dumps(dict(baseRevision='8d44bd4e; postcommit qualified E294 baseline',status='Main uncommitted R198 prototype; not promoted/final-qualified',cores={role:hashlib.sha256((d/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']},source={p.relative_to(repo).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in(repo/'src/Lokad.Lython').rglob('*.cs')if'obj'not in p.parts},catalogSHA256=hashlib.sha256((d/'catalog.json').read_bytes()).hexdigest(),qualification='Focused102public/71internal NET11; nonincremental freeze. Desktop elapsed diagnostic only.'),indent=2)+'\n',encoding='utf-8',newline='\n')
for phase,api,field in [('warm','sync','executionMilliseconds'),('warm-async','async','executionMilliseconds'),('compile','sync','elapsedMilliseconds')]:
 o=d/phase;o.mkdir()
 with(o/'measurements.json').open('w',encoding='utf-8')as out,(o/'stderr.txt').open('w',encoding='utf-8')as err:
  r=subprocess.run([dotnet,str(h.parent/'bulk-whitespace-r157/tool/out/complete-jobs.dll'),str(d/'images/before/Lokad.Lython.Benchmarks.dll'),str(d/'images/candidate/Lokad.Lython.Benchmarks.dll'),str(d/'catalog.json'),str(d/'hash-witness.json'),'reverse','compile'if phase=='compile'else'warm',api],env=env,stdout=out,stderr=err,timeout=120)
 assert r.returncode==0,(o/'stderr.txt').read_text(encoding='utf-8')[-2500:]
 raw=json.loads((o/'measurements.json').read_text(encoding='utf-8'));assert all(raw[k]for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
 rows=[]
 for c in raw['observations']:
  roles={role:{key:statistics.median(s[f]/s['jobs']for s in c['samples']if s['image']==role)for key,f in [('bytes','allocatedBytes'),('elapsedMs',field)]}for role in ['before','before-control','candidate']}
  row=dict(case=c['caseId'],roles=roles,changes={b:{k:100*(roles['candidate'][k]/roles[b][k]-1)for k in roles[b]}for b in ['before','before-control']});rows.append(row);print(phase,row['case'],row['changes'],flush=True)
 (o/'summary.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
