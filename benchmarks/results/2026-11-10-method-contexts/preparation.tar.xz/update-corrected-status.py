from pathlib import Path
import json
h=Path(__file__).parent;p=Path('D:/code/Lython/PLAN.md');s=p.read_text(encoding='utf-8')
start=s.index('Owned B547 is running once:');end=s.index('\nAcceptance:',start)
s=s[:start]+'''B547 failed during startup because the copied manifest omitted control-process
hashes; zero warmups/timed jobs. All users joined, RAM removed, original failure
archived/SHAverified3b28b5e4. No runtime failure or performance conclusion follows.
Source/catalog/settings are unchanged in the corrected manifest-only B548 run.
Same qualified8d44/E294 reference, frozen039dc975 prototype, worker/adapter0.4.
Fivejobs: class report warm/bothAPIs, compilation, unchanged report/text controls;
5s warmup,7rotated400msrounds,240sowner/30sstop/30smargin. Observe same handle only
after **13:09:23.248UTC**. Do not restart it on observation expiry.

Two preparation/headroom refusals happened before benchmark work; original logs
remain. One bounded idle operation retired five exact committed duplicate terminal
archives after SHA/UID/link/path proofs, preserving all images/sole evidence. New
setup278315008B passes fixed240MiB floor/12MiBheadroom. No relaxed resource gate.
'''+s[end:]
p.write_text(s,encoding='utf-8',newline='\n')
print('Recorded actual startup failure, cleanup, manifest correction and single active replacement owner.')
