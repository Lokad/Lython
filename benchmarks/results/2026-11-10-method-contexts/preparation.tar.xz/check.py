from pathlib import Path
import hashlib,json,os,subprocess
h=Path(__file__).parent;repo=Path('D:/code/Lython');env=os.environ.copy()
env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH'];dotnet=env['DOTNET_ROOT']+'/dotnet.exe'
public='(Category!=Stress)&(FullyQualifiedName~DeferredFunctionContextTests|FullyQualifiedName~ReceiverFunction|FullyQualifiedName~NamedFunctionBindingTests|FullyQualifiedName~FunctionClassCell|FullyQualifiedName~CooperativeCancellationTests|FullyQualifiedName~FunctionDefaultMetadataTests|FullyQualifiedName~ManagedStack)'
internal='FullyQualifiedName~DeferredFunctionOwnershipTests|FullyQualifiedName~BoundMethodInvocationBoundaryTests|FullyQualifiedName~ExecutableCallFrameTests|FullyQualifiedName~FunctionClassCellBoundaryTests|FullyQualifiedName~ManagedStackGuardTests|FullyQualifiedName~ExecutableStackAdmissionTests'
for name,args in [('public11',['test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f','net11.0','--filter',public]),('internal11',['test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f','net11.0','--filter',internal]),('freeze11',['build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-incremental'])]:
 with(h/(name+'.log')).open('w',encoding='utf-8')as out:r=subprocess.run([dotnet,*args],cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=180)
 print(name,(h/(name+'.log')).read_text(encoding='utf-8')[-1400:],flush=True)
 assert r.returncode==0
print('Focused .NET11 regressions and nonincremental freeze complete.',flush=True)
