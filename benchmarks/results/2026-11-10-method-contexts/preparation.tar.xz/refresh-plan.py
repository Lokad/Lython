from pathlib import Path
import shutil
repo=Path('D:/code/Lython');h=Path(__file__).parent
shutil.copyfile(repo/'PLAN.md',h/'prior-PLAN.md')
(repo/'PLAN.md').write_text('''# Lokad.Lython 0.11.0

Updated2026-11-10. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial whole-script improvement.
One isolated experiment does not complete it. Current contracts: docs/; history:
benchmarks/EXPERIMENTS.md and immutable benchmarks/results/. Detailed prior plans
remain in .git/agent-notes/review-20261031/.

## Actual delivery status

Committed/pushed HEAD28cb769a; runtime8d44bd4e fully qualified. Active R198 source
is an uncommitted prototype. No conflation of committed, qualified or measured.

| Deliverable | Status / remaining uncertainty |
| --- | --- |
| Shared compiler facts, direct UTF-8 formatting/storage, native helper returns | Delivered/fully qualified. Native returns allocate−19.92%sync/−19.31%async; original elapsed diagnostic. Formatting allocates−8.67%; controlled B102 elapsed/CPU−5–8%; original adverse15.125ms unexplained/preserved. No repeated qualification selected. |
| Shared Span binding, native dictionary accumulation, receiver-aware native entry | Delivered/fully qualified through1a83c64f. Source-pair gains and adverse controls remain linked in experimental history; do not reapply shipped optimizations. |
| R196 iterative JSON construction and one decoder admission | Delivered/fully qualified8d44. Removes recursive completion/leaf admission/pending numeric-frame transport. Conservative entry may deny earlier near managed nesting bound. Modest report benefit, flat allocation; text/JSON-lines uncertainty remains. Both variants/original failures preserved in benchmarks/results/2026-11-10-iterative-json-construction/. |
| R197 representative CPython checkpoint | Complete, committed28cb. Fresh postcommit8d44/E294,9jobs245.513s, all gates/SHA/join pass. Warm report1.22–1.24×, text1.43–1.46×, JSON-lines0.89–0.92×CPython3.13.16. Report complete/control variation remains visible. docs/BENCHMARKS.md separates compile/warm/compile-to-result and I/O/cleanup. No single-change attribution. |
| Rejected/partial investigations | R188 integer-local and R194 continuous-prefix variants withdrawn; call-arena/control slower lessons retained. R195 report/compile attribution partial, config/final gates absent; offline thread correction preserved. No unchanged replay selected. |
| Regex | Independent contract delivered. Normal optional adapter pin0.4 unchanged; dev64 development-qualified, dev65 source-only assessment below. Missing released capabilities do not stop core work. |

Full Windows/Ubuntu, actual.NET11/10 ordinary, original Stress and installed Release
consumer qualification is cached GREEN in42813970365 (exact8d44). Earlier receipts
remain linked once in evidence. Never query terminal runs/repeat unchanged gates.

## Active R198: ordinary method activations

Hypothesis: use scope observability rather than owner binding to decide when a
function context is necessary. OwnerType affects frame construction only for
RequiresClassCell, already excluded. Removing the redundant OwnerType gate lets
ordinary methods use the existing deferred function path; no new engine, cache,
ownership layer, signature convention or option. Eliminated work: per-record
function namespace/context allocation in complete class-based report/helpers.

Source change and focused102public/71internal pass on each actual11/10. Tests cover
class cells/super, closures, later locals promotion, traceback context, admission
reentry/refusal, real suspendedI/O, current cancellation, retained aliases/reuse.
Desktop class-report CLR allocation−28.51%sync/−28.50%async; elapsed−12..14%/
−8..11% is diagnostic only. Unchanged asyncCSV+6.2..6.5%elapsed and compileCSV
+17..20% remain adverse uncertainty. Compile allocation flat; no neutrality claim.

Owned B547 is running once: qualified8d44/E294 reference, frozen039dc975 prototype,
same worker/adapter0.4. Fivejobs: complete class report warm/both APIs, compilation,
unchanged free-function report/text warm controls.5s warmup,7rotated400msrounds,
240sowner/30sstop/30smargin. Observe same handle only after **13:01:04.934UTC**.
No restart/retiming on observation expiry. Original staging/headroom refusals
happened before benchmark work and remain preserved. Fixed240MiB floor/12MiB
headroom pass after canonical-copy/all-alias retirement; E294/current039 preserved.

Acceptance: Python effects/order/errors, scopes/captures/super, dynamic protocols,
genuine suspension, cancellation/first refusal, funded borrows/results and joined
cleanup. Validate raw/goldens/quiet/join/SHA, then decide retain/refine/remove and
explicitly record regression debt. Allocation/simplicity/CPU are separate results.
No fixed percentage veto; stop after this bounded source pair unless concrete
evidence justifies a correction/refinement. Do not claim this ends the objective.

## Next coherent redesigns

1. **Whole calls/frames and operands:** finish R198 decision, remove any displaced
   restriction/path, then follow demonstrated costs. Shared binding/final slots,
   native receiver entry, deferred contexts and prepared operands already exist.
   CSV/helper/report targets; text/search controls. Do not introduce another arena,
   control protocol, dormant backend or universal tagged-value representation.
2. **Remaining text representation:** current text remains~1.45×CPython. R189
   attribution predates dictionary accumulation. If no stronger source lead appears,
   collect one short current-text warm attribution (6s) with the existing worker,
   then assess one dominant representation/duplicate-processing cost. Stop the
   investigation after that capture and bounded source gate; select a concrete
   work/storage deletion or record why no justified redesign follows. No broad
   ownership audit, repeated unchanged timing or new benchmark framework.
3. **Per-record construction:** B74's6–8% opportunity already shipped in revised
   constructors/row-array adoption/shared keys. Reassessment and adverse growth
   evidence are in2026-11-10-record-construction-assessment/. A new milestone must
   remove different material allocation/scan; preserve duplicate/custom/wide and
   mutable headers, reentry, retained rows, refusal rollback and cancellation.
4. **Frontend:** shared compiler facts delivered; remaining passes often compute
   distinct facts. R195 traversal samples prove no dominant duplicate. Select a
   measured repeated walk/retained representation before consolidation; remove it.
   Uncached compile-to-result target, warm control; preserve diagnostics/scoping,
   closures/imports and one-provider semantics. No heavyweight JIT assumption.

For every selected redesign, record hypothesis, complete affected scripts, actual
work/storage eliminated, displaced code, semantic gates and bounded controlled
comparison BEFORE editing. Temporary setbacks can support a coherent migration
with explicit completion/debt decision. Timeouts or unstable controls establish
uncertainty; allow justified confirmation/refinement/measurement correction. Retain
all adverse results/original failed conditions. Fixed percentages inform judgment.

## Independent regex delivery

Continue Lython-owned Python semantics: nativeUTF-8 names/data, byte ranges/scalar
positions, original-subject windows, effective flags/captures/replacements/errors,
explicit pattern/cache/result ownership and current-token work. One provider for
frontend/runtime/imports; no backend types/dependencies in core. Development
producers and adapter-local bridges support independent implementation/testing.

Immutable dev64/9af7141f development-qualified86internal/524public eachactualtarget
on unchanged dev59bridge. Supplied dev65/998c630f has identical APIXML/production
C#; only version properties change. Source-only assessment, no new-byte safety/
performance qualification, pin promotion or unchanged test replay.

Precise missing capabilities: separate single-match working owner; nativeUTF-8
group-name enumeration; token-independent cursor creation (per-move tokens exist).
Only affected final released-adapter qualification waits. Contract tests, semantic
validation and backend performance/safety are distinct. Keep in-flight current-token
cancellation, terminal refusal, retained caches/results and budget reuse effective.
Qualify final immutable released package when supplied; publication remains held.

## Delivery / lasting constraints

Focused Release regressions during iteration; batch full Windows/Ubuntu, actual11/10,
original Stress and installed Release consumers at retained coherent milestones.
No simultaneous local builds/tests/timing. Force nonincremental build after timestamp
restores and before freezing. CI observations>=5minapart; cache terminal results.

Fully managed/memory-safe: no unsafe/Unsafe/pointers/PInvoke/native stack probing.
Preserve managed stack/recursion admission, host mediation, CancellationToken,
cycle detection, checked representation bounds, XML depth and boundedI/Ochunks.
Borrowed-root coarse preflights fund capacity/replacement peaks and retained aliases,
caches/results/pending users through awaited cleanup. First refusal stays terminal
with original attribution. No quotas/watchdogs, independent hidden caps, guest-heap
tracing, weak reclamation, forcedGC or new memory-management infrastructure.

Only core Release packages via tools/pack.ps1 to artifacts/nuget/; adapter stays
nonpackable. No publication/tagging. VM lokad@20.166.121.73, key~/.ssh/id_lython-bench.pem.
Persistent workers/catalogs/evidence; RAM only for guest fixtures. Preserve idle
lease, joins, archive/SHA and exact canonical-copy/all-alias retirement proof.
Never remove sole evidence/active users/current qualified reference or candidate.
Known superseded images/copies are retired: use receipts, do not probe missing
paths. If space again obstructs preparation, recover a bounded set of committed
duplicate terminal archives in one idle operation instead of repeated tiny cleanup.
''',encoding='utf-8',newline='\n')
print('Condensed active plan with qualified checkpoint, active prototype, explicit debt/stopping criteria and independent regex track.')
