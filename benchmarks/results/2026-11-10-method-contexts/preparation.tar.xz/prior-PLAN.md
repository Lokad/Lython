# Lokad.Lython 0.11.0

Updated 2026-11-10. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial **whole-script** improvement.
Completing an isolated experiment does not complete this objective. Current
contracts stay in docs/; history/adversity stays in benchmarks/results/ and
benchmarks/EXPERIMENTS.md. Previous detailed plans remain privately under
.git/agent-notes/review-20261031/.

## Delivery status

Committed/pushed and fully qualified runtime: `8d44bd4e` (R196), workflow
`42813970365` GREEN. Completed validation is recorded once in linked evidence.

| Work | Actual status / remaining uncertainty |
| --- | --- |
| Shared compiler-fact correction; direct UTF-8 formatting/storage; native helper returns | Committed and fully qualified. Native returns allocate 19.92% less sync / 19.31% async; original elapsed gains diagnostic. Formatting allocates 8.67% less; controlled B102 elapsed/CPU about 5–8% lower. Original adverse 15.125 ms remains unexplained/preserved, not evidence of current HEAD. |
| JSON transfer and helpers in handlers, ee448715 | Fully qualified. JSON allocation−3.04/−3.03%, elapsed inconclusive; helper allocation−47.31/−47.29%, controlled elapsed/CPU about 18–22% lower. |
| R184 shared Span binding/closed named-default calls; R185 cleared unbound storage | Fully qualified `32d1ea1a` / `3a413c59`. Search elapsed−15.7..−21.5% with CPU support; desktop adversity retained. CSV CPU−1.22..−4.71%; other controls uncertain. |
| [R190 dictionary accumulation](benchmarks/results/2026-11-10-dictionary-accumulation/README.md), e5731404 | Fully qualified; removes duplicate native hash/probe and transport. Quiet text elapsed−14.92..−10.90%, CSV−5.14..−1.08%, allocation flat. Report CPU0.. +3.03% possible debt remains. |
| [R192 receiver-aware native entry](benchmarks/results/2026-11-10-receiver-native-entry/README.md), 1a83c64f | Fully qualified. Existing shared binder/inline destination removes eligible workspace/pending-call transport. Bound-method text elapsed−8.51..−5.18%, CPU−7.69..−5.98%; allocation flat. Ordinary text/report inconclusive; report CPU up to +1.47% possible debt. |
| [R191 CPython refresh](benchmarks/results/2026-11-10-dictionary-cpython-checkpoint/README.md) | Complete: 9 jobs / 246.994 s, gates/SHA pass. Measured e573-equivalent frozen e364, not arbitrary HEAD. Warm CSV 1.07×, text 1.45–1.48×, keyword-default search 1.50–1.52×; compilation 0.91–1.08×. Guide preserves older report/config/JSON/file rows as historical. |
| [R193 exact prefix attribution](benchmarks/results/2026-11-10-prefix-instruction-attribution/README.md) | Complete: 12.033 s; all 437 prefix samples mapped by tier/code-size/instruction offset. Common entry blocks 8.22% CSV / 10.10% text include required checks/useful work, not removable tax. |
| [R194 continuous prefix](benchmarks/results/2026-11-10-continuous-prefix/README.md) | Original/refined prototypes withdrawn, main unchanged. Focused 3,221 public / 1,208 internal each actual .NET 11/10 pass. Allocation flat, larger OSR code/frame, B542 whole-script adversity and unstable controls; no promotion/CPU gain claim. Both variants and original failed conditions preserved. |
| Regex | Core independent; normal optional adapter pin 0.4 unchanged. Immutable dev64 / 9af7141f development-qualified: 86 internal / 524 public each actual target on unchanged dev59 bridge. Precise remaining producer gaps below; no final adapter/pin/safety/performance promotion. |

Cached terminal GREEN 42727417102/42758271911/42761050500/42783134761/42792541280/42813970365
cover completed Windows/Ubuntu, actual .NET 11/10, original Stress and installed
Release consumers. Do not query them again or repeat unchanged qualification.
R190/R192 worktrees retired; frozen images/evidence persist. B542 is terminal,
workers joined, fixtures removed and archive SHA verified; no active VM work.

## Active delivery checkpoint: R196

[Retained decoder source and both variants](benchmarks/results/2026-11-10-iterative-json-construction/README.md)
are committed/pushed as `8d44bd4e`. Measured precommit core `678fc7df`; all 568 main
production sources normalize equal, with no rebuilt-binary identity claim. One
iterative construction operation plus managed admission through awaited hooks
replaces recursive container completion, leaf entry/leave and numeric pending-frame
handoff. Capacity/overlap preflights, cancellation/first refusal and callback guards
remain. Conservative entry admission may reject earlier near the managed nesting
bound. Net +102 production lines; earlier +105 estimate was wrong (original +111).

Focused checks pass 1,002 public / 880 internal per actual .NET 11/10; .NET11 uses
1,001 unchanged passes plus the corrected fixture separately. Fresh main builds
and 222 public / 54 internal per target also pass. The new deep-hook fixture's
25s timeout/1.45s CPU is preserved; one real suspension/deep rejection plus three
callback recoveries passes 747ms with the original deadline and stress coverage.

B545 complete: 6 jobs / 214.221s, all gates/SHA/join/RAM cleanup pass. Report elapsed
−4.09..−0.84% sync / −5.53..−1.74% async; async CPU −6.96..−1.29%, sync CPU uncertain.
Allocation flat. JSON-lines and unchanged text remain inconclusive/possible debt
(text CPU 0..+5.33%, candidate control spread 4.56%). Compilation does not reproduce
large desktop adversity. **Retain for coherent decoder admission and modest report
benefit, carrying that debt into the representative checkpoint.** No general CPU
or neutrality claim and no further unchanged isolated retiming selected. B544's
adverse original is not promoted; both variants/raw clocks/failures survive.

Full Windows/Ubuntu, actual11/10 ordinary, original Stress and installed Release
consumers passed exact-source workflow **42813970365**, observed terminal GREEN
12:40 UTC. Receipt is linked once in R196 evidence. Never query the terminal run
again or repeat unchanged qualification. Publication remains postponed.
The isolated R196 tree is retired after exact archive/committed-source checks;
frozen measured images remain outside it.
All B544/B545 VM users are joined and fixtures removed; terminal owners cached.

## Next: representative performance checkpoint

Refresh report, text and JSON-lines against isolated CPython with existing tools
at this coherent source boundary. Compilation, warm and compile-to-result remain
separate; retain exact scripts/fixtures/output digests, source/core/reference/date/
machine and I/O/cleanup boundary. This must report the useful current state and
remaining text/JSON-lines uncertainty; separate checkpoints cannot attribute a
specific gain or prove neutrality. Publish guide rows only with accurate source
and qualification labels. Keep adverse/missing evidence explicit and size the
owned run before launch. No new framework or blanket one-attempt rule.

R197 is running once as owned B546 on the quiet VM: source `8d44bd4e`, fresh
postcommit core `e294fad1`, actual assembly0.11.0, all568 source hashes and exact
three-case catalog. Nine existing-protocol jobs; 300s owner plus30s stop/30s margin.
Observe the same owner only after **2026-11-10 12:46:34.894 UTC**. No result yet.
Full source qualification is GREEN. Fresh idle lease/exact committed canonical
proof permitted retiring all supersededac6 aliases and four duplicate terminal
copies; current678 and newE294 are preserved. Fixed240MiB floor/12MiB setup
headroom passed, no sole evidence removed. Retrieve/SHA/joins/quiet gates before
guide update. No restart on observation expiry. Publication held.

R195 remains partial attribution: report runtime/compilation captured, configuration
not started, compile post-verification and final quiet gate missing. Offline thread
selection corrected from actual CPU; all users joined/raw evidence preserved. No
unchanged replay selected. Current native UTF-8 strings, row adoption/shared keys,
completed child loops and prepared operands already exist; do not recreate them.

## Redesign roadmap and acceptance

### R198 selected: scope facts govern ordinary method activations

Source evidence: `CanDeferInvocationContext` rejects every `OwnerType`, although
owner binding affects invocation construction only when `RequiresClassCell` is
true, which the same predicate already excludes. Ordinary methods without lexical
class cells therefore allocate a context before executing work that ordinary
functions already run without it. This is distinct from delivered native leaf
method entry. Hypothesis: use the existing scope-sensitive promotion invariant
for methods too, eliminating per-record namespace/frame construction for complete
class-based report/helper scripts. Delete the owner-type proxy restriction; add
no alternate engine, cache, binding convention or public option.

Preserve `super`/`__class__`, closures, later locals/protocol/I/O promotion, effect
order, traceback names, first refusal, current cancellation and retained aliases.
Focused tests exercise both APIs and admission reentry, refusal, actual suspended
I/O and cleanup. Compare the complete class-renderer report against frozen8d44,
with unchanged free-function report/text controls and actual allocation separately
from elapsed. One short diagnostic precedes any quiet confirmation. Stop after a
bounded controlled source pair: retain only a coherent frame reduction with an
explicit regression-debt decision, otherwise remove the prototype. It cannot
by itself complete the broader performance objective. Source selection only;
implementation/measurements pending. No unchanged full qualification replay.

For every selected implementation write hypothesis, affected complete scripts,
actual work/storage eliminated, code to delete, semantic gates, bounded controlled
before/after comparison and explicit completion/regression-debt decision **before
editing**. Prefer one invariant over accumulating special-case dispatch paths.

1. **Complete calls/frames and operand transport.** Shared Span binding, final
   argument/local slots, native receiver entry, deferred contexts and fixed physical
   operand positions already exist. Assess remaining frame and temporary transport
   together where profiles show material cost. Remove the displaced path when a
   replacement is retained; no dormant alternate engine, arena/control protocol or
   universal boxed-value redesign without evidence. CSV/helper/report targets;
   text/search controls. Preserve argument/evaluation effects, error spans,
   closures, dynamic protocols and genuine suspension.
2. **Per-record/bulk construction.** B74's 6–8% opportunity was revised/retained
   c23d1a10/8f07764a and extended by private row arrays/shared keys/compaction.
   [Source reassessment](benchmarks/results/2026-11-10-record-construction-assessment/README.md)
   closes unchanged replay, not future record design. New work must eliminate a
   different allocation/scan. Preserve duplicates/order, mutable/custom/wide
   headers, admission reentry, retained records and refusal rollback. Keep earlier
   allocation +8.42% / CPU +4.3–6.2% growth adversity visible.
3. **Text/JSON/report representation.** Native casing, final-word construction,
   direct UTF-8 formatting/valid JSON strings already exist. Short split ranges use
   managed stack scratch and inline word payloads. Select remaining material
   conversion/duplicate processing using R195, remove its intermediate form.
   Preserve Unicode expansion/final-sigma, JSON hooks / raw_decode / error coordinates,
   custom formatting and exact Python effects. Text/Unicode/JSON/report controls;
   no new lazy ownership/cursor scheme to evade eagerly funded outputs.
4. **Repeated frontend analysis.** Shared lexical/compiler facts are delivered;
   several remaining passes compute distinct facts. Use compile-to-result evidence
   to identify a genuine duplicate walk/representation before consolidation; delete
   it. Uncached/new scripts and compilation/disposal target, warm control. Preserve
   diagnostics, scoping/closures/imports and one regex-provider semantics. No
   heavyweight JIT assumption. If the targeted duplicate is absent, record that
   bounded source gate and choose the next evidenced cost.

Retained redesign completion requires meaningful whole-script outcome and a debt
decision, not a fixed percentage. Architectural simplification, allocation reduction
and demonstrated CPU improvement are distinct. Temporary setbacks may support a
coherent migration with a defined completion milestone; do not accumulate them
indefinitely. Call-arena/control and R194 results inform designs, not permanent
vetoes. Timeouts/unstable controls establish uncertainty. Allow bounded confirmation,
refinement and measurement correction with reasons; retain adversity and original
failed conditions. R194's short-driver search/tier instability needs correction
before it can support any gain claim; no unchanged retiming is currently selected.

## Independent regex delivery

Continue the Lython-owned Python contract: native UTF-8 names/data, byte ranges,
scalar positions, original-subject windows, effective flags/captures/replacements/
errors; explicit pattern/cache/result ownership and current-operation cancellation.
One provider across frontend/runtime/imports; no backend types/dependencies in core.
Development producers/adapter-local bridges can support tests independently.

Supplied dev65 / `998c630f` was inspected without editing/building the producer:
API XML and core/PythonRe production C# are unchanged from qualified dev64; the
build-property delta is the version bump. It supplies none of the missing
capabilities. This is a source-only gate, not qualification of new package bytes;
no pin promotion or unchanged semantic-test replay.

Dev64 still lacks separate single-match working owner, native group-name enumeration
and token-independent cursor construction (per-move tokens exist). Only affected
**final released-adapter qualification** waits. Normal 0.4 pin and unchanged bridge
are not requalified needlessly. Keep core contract tests/semantic validation and
actual backend performance/safety qualification separate. Current-token in-flight
cancellation, terminal refusal, retained results/caches and budget reuse must hold;
entry/exit checks alone are insufficient. Qualify final released adapter when ready.

## Delivery and measurement discipline

Focused Release semantic/cancellation/ownership checks while iterating; batch full
Windows/Ubuntu, actual .NET 11/10, original Stress and installed Release consumers at a
coherent retained milestone. Force nonincremental builds after timestamp restores
before --no-build checks/freezing. Never overlap local build/test/timing. CI checks
at least 5 minutes apart; cache terminal results. CPython remains primary external
baseline; refresh representative rows at the next coherent runtime checkpoint,
separating compilation/warm/compile-to-result and stating I/O/cleanup explicitly.
Do not relabel historical rows as HEAD or confuse Run-only with full envelopes.

Follow AGENTS.md: fully managed/memory-safe, managed stack admission/recursion,
host mediation, CancellationToken, cycle detection, checked representation bounds,
XML depth and bounded I/O chunks. Borrowed-root coarse preflights fund capacity,
replacement peaks, retained aliases/results/caches/pending users through awaited
cleanup. First refusal stays terminal with original attribution. No unsafe/Unsafe/
pointers/PInvoke/native stack probing, quotas/watchdogs, hidden independent caps,
tracing/weak reclamation/forced GC or new ownership infrastructure.

Only core Release packages via tools/pack.ps1→artifacts/nuget/; adapter nonpackable.
Publication remains postponed. Quiet VM: lokad@20.166.121.73, ~/.ssh/id_lython-bench.pem;
persistent evidence/workers, RAM only for guest fixtures. Preserve lease/join/archive/SHA
and exact-copy retirement proofs; never restart terminal owners/probe known-retired
paths or delete sole evidence/current qualified ac6 images. Historical e364 all6aliases
and exact terminalcopies retired in B542 after canonical verification; details remain
in immutable evidence, not repeated operational narratives here.
