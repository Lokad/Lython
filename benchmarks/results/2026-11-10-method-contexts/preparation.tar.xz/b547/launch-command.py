from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
config={'payloadBytes': 1925368, 'payloadSHA256': 'ef0fb381d9d5e93bc1dfcd46244833494ff73264962611baf43e80b9380006d3', 'required': 270017256, 'copies': [{'path': 'json-cpython-b546-20261110/observations.tgz', 'bytes': 2057190, 'sha256': 'b744d9435637a1fc7bb2fce546a8dfc3cb42a4b6c7837e65af5f92fb32345a24', 'canonical': 'benchmarks\\results\\2026-11-10-json-cpython-checkpoint\\observations.tgz'}, {'path': 'json-cpython-b546-20261110/confirmation/confirmation.json', 'bytes': 1312585, 'sha256': '69a34c0537099454614dac21c77ab4f08eba5270561bf950cff085218da24b51', 'canonical': 'benchmarks\\results\\2026-11-10-json-cpython-checkpoint\\observations.tgz:confirmation/confirmation.json'}, {'path': 'json-cpython-b546-20261110/representative.json', 'bytes': 656502, 'sha256': 'c7ea636fbca1b47fdc55e2a3178939634a76b08fec81e222e64d5220cd469e40', 'canonical': 'benchmarks\\results\\2026-11-10-json-cpython-checkpoint\\observations.tgz:representative.json'}, {'path': 'json-cpython-b546-20261110/core-source.json', 'bytes': 75001, 'sha256': '8b3ed29fc278d84be179497d9bb783b5405eb4edaa3f1797d84ee5ee21f7287c', 'canonical': 'benchmarks\\results\\2026-11-10-json-cpython-checkpoint\\observations.tgz:core-source.json'}, {'path': 'json-cpython-b546-20261110/prior-BENCHMARKS.md', 'bytes': 16812, 'sha256': 'cd4c2d1239ca0b856b787380c2ea54c97fe5153cf043a8e3b89c33d9ba353b22', 'canonical': 'benchmarks\\results\\2026-11-10-json-cpython-checkpoint\\observations.tgz:prior-BENCHMARKS.md'}]}
base=Path('/home/lokad/lython-bench-checks').resolve();root=base/'deferred-method-b547-20261110';source=base/'json-cpython-b546-20261110/candidate';fixture=root/'guest-fixtures'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists()and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[c]omplete-jobs.dll'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(config['payloadBytes']+1);assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 assert hashlib.sha256((source/'Lokad.Lython.dll').read_bytes()).hexdigest()=='e294fad194255fa086a3356a6adc57061ac3f764cc632f83bc459fa784f41ed9'
 protocol=base/'prepared-call-layout-b384-20261107/cpython-worker.py'
 assert hashlib.sha256(protocol.read_bytes()).hexdigest()=='02ca606af6b937a5bec8da744da36e6dbea45ef14ee7207732f34da052ad32f1'
 before=shutil.disk_usage(base).free;retired=[];retiredSuperseded678=[]
 if before<=config['required']:
  reclaim=0
  for copy in config['copies']:
   path=base/copy['path'];s=path.lstat()
   assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_nlink==1
   assert s.st_size==copy['bytes']and hashlib.sha256(path.read_bytes()).hexdigest()==copy['sha256']
   reclaim+=s.st_blocks*512;retired.append(dict(copy,allocatedBytes=s.st_blocks*512,allAliases=[str(path)]))
  original=base/'iterative-json-b545-20261110/current-core.dll';old=original.lstat()
  assert stat.S_ISREG(old.st_mode)and old.st_uid==os.getuid()and hashlib.sha256(original.read_bytes()).hexdigest()=='678fc7df05e93fd542f6fb9fa48bcbbc923bc6cc655ed1d814bb50bdc4bdfc37'
  matches=subprocess.check_output(['find',str(base),'-xdev','-samefile',str(original),'-type','f'],text=True).splitlines()
  assert len(matches)==old.st_nlink
  for name in matches:
   path=Path(name);st=path.lstat();assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(st.st_mode)and st.st_uid==os.getuid()
   protected=(source/'Lokad.Lython.dll').stat();assert(st.st_dev,st.st_ino)!=(protected.st_dev,protected.st_ino)
  retiredSuperseded678=matches;reclaim+=old.st_blocks*512
  assert before+reclaim>config['required'],(before,reclaim,config['required'])
  for name in matches:Path(name).unlink()
  for copy in config['copies']:(base/copy['path']).unlink()
 assert shutil.disk_usage(base).free>config['required']
 recovery=dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,requiredFreeBytes=config['required'],freshIdleLease=True,qualifiedPostcommitE294Preserved=True,osFloorMiB=240,evidenceHeadroomMiB=12,files=retired,retiredSuperseded678Aliases=retiredSuperseded678,superseded678Canonical='benchmarks/results/2026-11-10-iterative-json-construction/refined-observations.tgz:current-core.dll')
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:root.mkdir();a.extractall(root,filter='data')
 (root/'space-recovery.json').write_text(json.dumps(recovery,indent=2)+'\n')
 shutil.copyfile(protocol,root/'cpython-worker.py');os.link(source/'Lokad.Lython.dll',root/'baseline-core.dll')
 for role in ['reference','candidate']:
  shutil.copytree(source,root/role,copy_function=os.link)
  (root/role/'Lokad.Lython.dll').unlink();os.link(root/('baseline-core.dll'if role=='reference'else'current-core.dll'),root/role/'Lokad.Lython.dll')
 identity=json.loads((root/'identity.json').read_text())
 for role in ['reference','candidate']:
  for name,digest in {**identity['auxiliaryFiles'],'Lokad.Lython.dll':identity['coreSHA256'][role]}.items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==digest,(role,name)
 assert hashlib.sha256((root/'cpython-worker.py').read_bytes()).hexdigest()==identity['protocolSHA256']
 assert hashlib.sha256((root/'representative.json').read_bytes()).hexdigest()==identity['catalogSHA256']
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b547-fixtures',str(fixture)],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndAuxiliaryImagesVerified=True,jobs=5,ownerSeconds=240,stopSeconds=30,marginSeconds=30,workerUnchanged=True,osFloorMiB=240,evidenceHeadroomMiB=12)
 assert setup['freeBytes']>(240+12)*1024*1024
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
try:
 subprocess.run(['sudo','-n','systemd-run','--unit=lython-b547-deferred-method-20261110','--property=User=lokad','--property=WorkingDirectory='+str(root),
  '--property=RuntimeMaxSec=240','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show','lython-b547-deferred-method-20261110.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert 'ActiveState=active'in live and'MainPID=0'not in live;print(live,flush=True)
