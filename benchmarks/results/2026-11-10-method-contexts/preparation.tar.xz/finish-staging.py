from pathlib import Path
import ast,datetime,hashlib,json,shlex,subprocess,tarfile
h=Path(__file__).parent;p=h/'b547';repo=Path('D:/code/Lython');canonical=repo/'benchmarks/results/2026-11-10-json-cpython-checkpoint/observations.tgz'
assert hashlib.sha256(canonical.read_bytes()).hexdigest()=='b744d9435637a1fc7bb2fce546a8dfc3cb42a4b6c7837e65af5f92fb32345a24'
copies=[]
with tarfile.open(canonical)as a:
 for name in ['source-equivalence.json','cpython-worker.py','__pycache__/cpython-worker.cpython-312.pyc','confirmation/machine-before.json','confirmation/machine-after.json','archive-owned.py','collect.py','contract.md','delivery-ci-status.json','exact-copies.json','identity.json','live-unit.txt','run.sh','setup.json','space-recovery.json','started.utc']:
  m=a.getmember(name);copies.append(dict(path='json-cpython-b546-20261110/'+name,bytes=m.size,sha256=hashlib.sha256(a.extractfile(m).read()).hexdigest(),canonical=str(canonical.relative_to(repo))+':'+name))
canonical=repo/'benchmarks/results/2026-11-10-iterative-json-construction/refined-observations.tgz'
assert hashlib.sha256(canonical.read_bytes()).hexdigest()=='285b18b74bc7f34bdb2eed54aa164297466f68ec7c1d9ee5ef3cec68bc09d809'
with tarfile.open(canonical)as a:
 for name in ['cpython-worker.py','__pycache__/cpython-worker.cpython-312.pyc','collect.py','run.sh','archive-owned.py','identity.json','contract.md','confirmation/machine-before.json','confirmation/machine-after.json','space-recovery.json','setup.json','live-unit.txt','started.utc']:
  m=a.getmember(name);copies.append(dict(path='iterative-json-b545-20261110/'+name,bytes=m.size,sha256=hashlib.sha256(a.extractfile(m).read()).hexdigest(),canonical=str(canonical.relative_to(repo))+':'+name))
(p/'extra-exact-copies.json').write_text(json.dumps(copies,indent=2)+'\n',encoding='utf-8',newline='\n')
script=r'''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
copies=COPIES
base=Path('/home/lokad/lython-bench-checks').resolve();root=base/'deferred-method-b547-20261110';fixture=root/'guest-fixtures';service='lython-b547-deferred-method-20261110.service'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not(root/'setup.json').exists()and not(root/'started.utc').exists()
 status=subprocess.run(['systemctl','show',service,'--property=LoadState,ActiveState,MainPID'],text=True,capture_output=True)
 assert 'LoadState=not-found'in status.stdout and'MainPID=0'in status.stdout,status.stdout
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert fixture.is_dir()and not list(fixture.iterdir())
 assert subprocess.run(['mountpoint','-q',str(fixture)]).returncode==0
 before=shutil.disk_usage(base).free;reclaim=0
 for copy in copies:
  path=base/copy['path'];s=path.lstat()
  assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_nlink==1
  assert s.st_size==copy['bytes']and hashlib.sha256(path.read_bytes()).hexdigest()==copy['sha256']
  reclaim+=s.st_blocks*512
 assert before+reclaim>(240+12)*1024*1024,(before,reclaim)
 for copy in copies:(base/copy['path']).unlink()
 identity=json.loads((root/'identity.json').read_text())
 for role in ['reference','candidate']:
  for name,digest in {**identity['auxiliaryFiles'],'Lokad.Lython.dll':identity['coreSHA256'][role]}.items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==digest,(role,name)
 assert hashlib.sha256((root/'representative.json').read_bytes()).hexdigest()==identity['catalogSHA256']
 assert hashlib.sha256((root/'cpython-worker.py').read_bytes()).hexdigest()==identity['protocolSHA256']
 recovery=dict(noBenchmarkWasStarted=True,freshIdleLease=True,beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,files=copies,osFloorMiB=240,evidenceHeadroomMiB=12,qualifiedE294AndCandidate039Preserved=True)
 (root/'staging-recovery.json').write_text(json.dumps(recovery,indent=2)+'\n')
 setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndAuxiliaryImagesVerified=True,jobs=5,ownerSeconds=240,stopSeconds=30,marginSeconds=30,workerUnchanged=True,osFloorMiB=240,evidenceHeadroomMiB=12)
 assert setup['freeBytes']>(240+12)*1024*1024
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
try:
 subprocess.run(['sudo','-n','systemd-run','--unit=lython-b547-deferred-method-20261110','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=240','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show',service,'--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert'ActiveState=active'in live and'MainPID=0'not in live;print(live,flush=True)
'''.replace('COPIES',repr(copies))
ast.parse(script);(p/'finish-staging-command.py').write_text(script,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
r=subprocess.run(ssh+['python3 -'],input=script,text=True,encoding='utf-8',capture_output=True)
log=p/'finish-staging.log'
if log.exists():log.rename(p/('finish-staging-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'.log'))
log.write_text(r.stdout+'\n'+r.stderr,encoding='utf-8',newline='\n');assert r.returncode==0,r.stderr
now=datetime.datetime.now(datetime.timezone.utc)
(p/'observe-not-before.json').write_text(json.dumps(dict(acknowledgedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=300)).isoformat(),ownerSeconds=240,stopSeconds=30,marginSeconds=30),indent=2)+'\n',encoding='utf-8',newline='\n')
print(r.stdout,flush=True);print('Observe after',(now+datetime.timedelta(seconds=300)).isoformat(),flush=True)
