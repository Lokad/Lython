from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile
h=Path(__file__).parent;d=h/'diagnostic';p=h/'b547';p.mkdir();old=h.parent/'iterative-json-r196/b545';repo=Path('D:/code/Lython')
source=json.loads((d/'identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest for name,digest in source['source'].items())
assert hashlib.sha256((d/'images/candidate/Lokad.Lython.dll').read_bytes()).hexdigest()==source['cores']['candidate']
shutil.copyfile(d/'images/candidate/Lokad.Lython.dll',p/'current-core.dll')
catalog=json.loads((d/'catalog.json').read_text(encoding='utf-8'));catalog['cases']=[c for c in catalog['cases']if c['id']in ['scripts.report-render.class-renderer.large','scripts.report-render.large','scripts.text-summary-helpers.large']]
assert len(catalog['cases'])==3
(p/'representative.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
base=json.loads((old/'identity.json').read_text(encoding='utf-8'))
identity=dict(sourceRevision='R198 uncommitted ordinary-method context prototype on28cb769a; reference fullyqualified8d44 postcommitE294. No final candidate qualification.',coreSHA256={'reference':source['cores']['before'],'candidate':source['cores']['candidate']},auxiliaryFiles=base['auxiliaryFiles'],protocolSHA256='02ca606af6b937a5bec8da744da36e6dbea45ef14ee7207732f34da052ad32f1',catalogSHA256=hashlib.sha256((p/'representative.json').read_bytes()).hexdigest(),performanceQualified=False)
(p/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n');shutil.copyfile(d/'identity.json',p/'source-identity.json');shutil.copyfile(d/'source.patch',p/'source.patch');shutil.copyfile(d/'script-goldens.json',p/'script-goldens.json')
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=(old/name).read_text(encoding='utf-8').replace('iterative-json-b545-20261110','deferred-method-b547-20261110').replace('lython-b545-iterative-json-20261110','lython-b547-deferred-method-20261110')
 if name=='collect.py':
  start=s.index('jobs=');end=s.index('\nassert len(jobs)',start)
  s=s[:start]+"jobs=[['scripts.report-render.class-renderer.large','warm'],['scripts.report-render.class-renderer.large','warm-async'],['scripts.report-render.class-renderer.large','compile'],['scripts.report-render.large','warm'],['scripts.text-summary-helpers.large','warm']]"+s[end:]
  start=s.index("purpose='");end=s.index("',\n",start)
  s=s[:start]+"purpose='R198 scope facts replace owner-type frame restriction; complete class-renderer report bothAPIs, compilation, unchanged plain report/text controls. Original desktop adversity preserved"+s[end:]
  s=s.replace('R192 receiver-aware native entry, complete text plus ordinary text/report controls.','R198 ordinary-method context deferral through existing instruction prefix.')
 s=s.replace('len(jobs)==6','len(jobs)==5').replace("len(raw['jobs'])==6","len(raw['jobs'])==5").replace('jobs=6','jobs=5').replace("['jobs']==6","['jobs']==5").replace('B545 six-job','B547 five-job')
 if name.endswith('.py'):ast.parse(s)
 (p/name).write_text(s,encoding='utf-8',newline='\n')
canonical=repo/'benchmarks/results/2026-11-10-json-cpython-checkpoint/observations.tgz';receipt=json.loads((canonical.parent/'archive-receipt.json').read_text(encoding='utf-8'))
assert hashlib.sha256(canonical.read_bytes()).hexdigest()==receipt['archiveSHA256']
subprocess.run(['git','ls-files','--error-unmatch',str(canonical.relative_to(repo))],cwd=repo,check=True,stdout=subprocess.DEVNULL)
copies=[dict(path='json-cpython-b546-20261110/observations.tgz',bytes=canonical.stat().st_size,sha256=receipt['archiveSHA256'],canonical=str(canonical.relative_to(repo)))]
with tarfile.open(canonical)as a:
 for name in ['confirmation/confirmation.json','representative.json','core-source.json','prior-BENCHMARKS.md']:
  m=a.getmember(name);copies.append(dict(path='json-cpython-b546-20261110/'+name,bytes=m.size,sha256=hashlib.sha256(a.extractfile(m).read()).hexdigest(),canonical=str(canonical.relative_to(repo))+':'+name))
(p/'exact-copies.json').write_text(json.dumps(copies,indent=2)+'\n',encoding='utf-8',newline='\n')
canonical=repo/'benchmarks/results/2026-11-10-iterative-json-construction/refined-observations.tgz'
assert hashlib.sha256(canonical.read_bytes()).hexdigest()=='285b18b74bc7f34bdb2eed54aa164297466f68ec7c1d9ee5ef3cec68bc09d809'
with tarfile.open(canonical)as a:assert hashlib.sha256(a.extractfile('current-core.dll').read()).hexdigest()=='678fc7df05e93fd542f6fb9fa48bcbbc923bc6cc655ed1d814bb50bdc4bdfc37'
s=(old/'launch.py').read_text(encoding='utf-8').replace('iterative-json-b545-20261110','deferred-method-b547-20261110').replace('lython-b545-iterative-json-20261110','lython-b547-deferred-method-20261110').replace('iterative-json-b545-launch.py','deferred-method-b547-launch.py')
s=s.replace("source=base/'prefix-code-b541-20261110/candidate'","source=base/'json-cpython-b546-20261110/candidate'")
s=s.replace('ac6edb6fc361dba9195d973830a5ca02caac10b62cc6d041f134ce31ef9a10d3',source['cores']['before'])
s=s.replace("original=base/'iterative-json-b544-20261110/current-core.dll'","original=base/'iterative-json-b545-20261110/current-core.dll'")
s=s.replace('a9d5620ff8db469894e7a77fe50bb701f5ab8a3cc679248ab97fdd2a2962a17f','678fc7df05e93fd542f6fb9fa48bcbbc923bc6cc655ed1d814bb50bdc4bdfc37')
s=s.replace('retiredA9','retiredSuperseded678').replace('qualifiedac6Preserved=True','qualifiedPostcommitE294Preserved=True').replace("retiredOriginalA9Aliases=retiredSuperseded678,originalA9Canonical='benchmarks/results/2026-11-10-iterative-json-construction/original-observations.tgz:current-core.dll'","retiredSuperseded678Aliases=retiredSuperseded678,superseded678Canonical='benchmarks/results/2026-11-10-iterative-json-construction/refined-observations.tgz:current-core.dll'")
s=s.replace('lython-b545-fixtures','lython-b547-fixtures').replace('jobs=6,ownerSeconds=240','jobs=5,ownerSeconds=240')
assert 'a9d562'not in s and 'iterative-json-b544'not in s and 'ac6edb'not in s
ast.parse(s);(p/'launch.py').write_text(s,encoding='utf-8',newline='\n')
(p/'contract.md').write_text('''# R198 bounded ordinary-method frame comparison

Existing complete class-renderer report versus qualified8d44/E294; same exact
fixtures/output goldens, auxiliary binaries, adapter0.4 and common protocol.
Reference/candidate each have independent controls;5s warmup,7rotated400msrounds.
Fivejobs: class-report warm/both APIs, its compilation, unchanged free-function
report/text warm controls.240sowner/30sstop/30smargin. Current cancellation,
admitted ownership, joins, quiet gates, persistent archive/SHA before RAM retirement.
No speedup/neutrality claim before results; all desktop adversity preserved.
''',encoding='utf-8',newline='\n')
with tarfile.open(p/'payload.tgz','w:gz')as a:
 for name in ['current-core.dll','representative.json','identity.json','source-identity.json','source.patch','script-goldens.json','exact-copies.json','contract.md','collect.py','archive-owned.py','run.sh']:a.add(p/name,arcname=name)
print(json.dumps(dict(preparedOnly=True,jobs=5,payloadBytes=(p/'payload.tgz').stat().st_size,requiredFreeBytes=(240+12)*1024*1024+3*(p/'payload.tgz').stat().st_size,coreSHA256=identity['coreSHA256']),indent=2))
