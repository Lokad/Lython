from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile
h=Path(__file__).parent;old=h/'b547';p=h/'b548';p.mkdir();repo=Path('D:/code/Lython')
failed=json.loads((old/'partial-archive-receipt.json').read_text(encoding='utf-8'));assert failed['timedJobs']==0 and failed['allWorkersJoined']and failed['guestFixturesRemoved']
source=json.loads((h/'diagnostic/identity.json').read_text(encoding='utf-8'));assert all(hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest for name,digest in source['source'].items())
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
for role in ['reference','candidate']:identity['coreSHA256'][role+'-control']=identity['coreSHA256'][role]
identity['sourceRevision']+=' Corrected manifest only: all four control/source hashes explicit; original startup failure preserved separately.'
(p/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['representative.json','source-identity.json','source.patch','script-goldens.json','contract.md']:shutil.copyfile(old/name,p/name)
shutil.copyfile(old/'partial-archive-receipt.json',p/'original-startup-failure.json')
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=(old/name).read_text(encoding='utf-8').replace('deferred-method-b547-20261110','deferred-method-b548-20261110').replace('lython-b547-deferred-method-20261110','lython-b548-deferred-method-20261110').replace('B547 five-job','B548 five-job')
 if name.endswith('.py'):ast.parse(s)
 (p/name).write_text(s,encoding='utf-8',newline='\n')
s=(old/'launch.py').read_text(encoding='utf-8').replace('deferred-method-b547-20261110','deferred-method-b548-20261110').replace('lython-b547-deferred-method-20261110','lython-b548-deferred-method-20261110').replace('deferred-method-b547-launch.py','deferred-method-b548-launch.py').replace('lython-b547-fixtures','lython-b548-fixtures')
start=s.index('before=shutil.disk_usage(base).free;retired=[];');end=s.index(' with tarfile.open(fileobj=',start)
s=s[:start]+'''before=shutil.disk_usage(base).free
 assert before>config['required'],(before,config['required'])
 prototype=base/'deferred-method-b547-20261110/current-core.dll'
 assert hashlib.sha256(prototype.read_bytes()).hexdigest()=='039dc975c341d77400e8df8189524480990b042d0694a2e60e27240abcfc61d1'
 recovery=dict(beforeFreeBytes=before,afterFreeBytes=before,requiredFreeBytes=config['required'],freshIdleLease=True,qualifiedPostcommitE294Preserved=True,frozen039ReusedWithoutCopy=True,osFloorMiB=240,evidenceHeadroomMiB=12,files=[])
'''+s[end:]
s=s.replace(" shutil.copyfile(protocol,root/'cpython-worker.py');os.link(source/'Lokad.Lython.dll',root/'baseline-core.dll')"," os.link(prototype,root/'current-core.dll')\n shutil.copyfile(protocol,root/'cpython-worker.py');os.link(source/'Lokad.Lython.dll',root/'baseline-core.dll')")
s=s.replace("copies=json.loads((r/'exact-copies.json').read_text(encoding='utf-8'))","copies=[]")
ast.parse(s);(p/'launch.py').write_text(s,encoding='utf-8',newline='\n')
assert "root/'current-core.dll'"in s and 'retiredSuperseded'not in s
with tarfile.open(p/'payload.tgz','w:gz')as a:
 for name in ['representative.json','identity.json','source-identity.json','source.patch','script-goldens.json','original-startup-failure.json','contract.md','collect.py','archive-owned.py','run.sh']:a.add(p/name,arcname=name)
print('Prepared manifest-only correction; same source, catalog, workers, all timings/settings. Payload', (p/'payload.tgz').stat().st_size,'bytes.',flush=True)
subprocess.run(['python','-X','utf8',str(p/'launch.py')],check=True)
