from pathlib import Path
import ast
root=Path(__file__).parent;old=root.parent/'current-cpu-r19'
s=(old/'retrieve.py').read_text(encoding='utf-8').replace('current-cpu-b358-20261106','current-cpu-b370-20261107').replace('lython-b358-current-cpu-20261106','lython-b370-current-cpu-20261107')
ast.parse(s);(root/'retrieve.py').write_text(s,encoding='utf-8')
s=(old/'assess.py').read_text(encoding='utf-8').replace('2026-11-06-current-cpu-records','2026-11-07-current-script-cpu')
s=s.replace('ranges=[]','ranges=[];malformed=[]')
s=s.replace("for line in (folder/'perf.map').read_text(encoding='utf-8').splitlines():\n        start,size,name=line.split(' ',2);ranges.append((int(start,16),int(size,16),name))", "for line in (folder/'perf.map').read_text(encoding='utf-8').splitlines(keepends=True):\n        parts=line.rstrip().split(' ',2)\n        if len(parts)!=3 or not line.endswith('\\n'):\n            malformed.append(line);continue\n        start,size,name=parts;ranges.append((int(start,16),int(size,16),name))")
s=s.replace("unknown=counts['[unknown]'],categories=categories", "unknown=counts['[unknown]'],malformedMapLines=malformed,categories=categories")
ast.parse(s);(root/'assess.py').write_text(s,encoding='utf-8')
print('Prepared read-only retrieval and offline analysis; VM left undisturbed.')
