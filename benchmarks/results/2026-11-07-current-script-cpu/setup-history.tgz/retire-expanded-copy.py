from pathlib import Path
home=Path(__file__).parent
s=(home.parent/'regex-program-artifacts-r23/retire-verified-profile.py').read_text(encoding='utf-8')
assert '8275272' in s and 'perf/csv-warm/perf.data' in s
s=s.replace('8275272','6287952').replace('perf/csv-warm/perf.data','perf/text-warm/perf.data')
(home/'retire-verified-profile.py').write_text(s,encoding='utf-8')
exec(compile(s,str(home/'retire-verified-profile.py'),'exec'))
