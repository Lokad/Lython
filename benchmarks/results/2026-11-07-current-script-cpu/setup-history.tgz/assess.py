from pathlib import Path
import bisect,collections,hashlib,json,re,shutil,tarfile
root=Path(__file__).resolve().parent;out=Path('benchmarks/results/2026-11-07-current-script-cpu');out.mkdir()
receipt=json.loads((root/'archive-receipt.json').read_text(encoding='utf-8'))
assert receipt['complete'] and hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
shutil.copyfile(root/'observations.tgz',out/'observations.tgz');shutil.copyfile(root/'archive-receipt.json',out/'archive-receipt.json')
results={}
for case in ['text-warm','report-warm']:
    folder=root/'retrieved/perf'/case;record=json.loads((folder/'record.json').read_text(encoding='utf-8'))
    ranges=[];malformed=[]
    for line in (folder/'perf.map').read_text(encoding='utf-8').splitlines(keepends=True):
        parts=line.rstrip().split(' ',2)
        if len(parts)!=3 or not line.endswith('\n'):
            malformed.append(line);continue
        start,size,name=parts;ranges.append((int(start,16),int(size,16),name))
    ranges.sort();starts=[r[0] for r in ranges];counts=collections.Counter();tids=set(record['guestTids'])
    for line in (folder/'perf-leaves.txt').read_text(encoding='utf-8').splitlines():
        m=re.match(r'\s*(\d+)/(\d+)\s+([0-9a-fx]+)\s*(.*)',line)
        if not m or m[2] not in tids:continue
        address=int(m[3],16);index=bisect.bisect_right(starts,address)-1;symbol=m[4]
        if index>=0:
            start,size,name=ranges[index]
            if address<start+size:symbol=name
        counts[symbol]+=1
    selected={
        'instructionPrefixIncludingInlinedWork':['::ExecuteInstructionPrefix('],
        'nativeGuards':['::GuardNativeReturn(','::GuardNativeFormattedValue(','::GuardNativeFormattedBody('],
        'nativeEvaluation':['::EvaluateNativeReturn(','::EvaluateNativeFormattedReturn('],
        'ordinaryCallsAndBinding':['::ExecuteOrdinaryCall(','::BindPositionalFunctionArguments(','::BeginPendingCall('],
        'jsonStringAndContainer':['::ReadJsonString(','::ReadJsonContainerRemainder('],
        'formattedStringAppend':['::AppendFormattedStringValue('],
        'localResultPublication':['::CompleteLocalResult('],
        'monitor':['System.Threading.Monitor::Enter(','System.Threading.Monitor::Exit('],
        'exactIntegerAddition':['::AddExactIntegers('],
    }
    categories={k:sum(n for name,n in counts.items() if any(token in name for token in tokens)) for k,tokens in selected.items()}
    results[case]=dict(samples=counts.total(),activeGuestCpuSeconds=sum(r['seconds'] for r in record['threadCpuSeconds'] if r['tid'] in tids),
        unknown=counts['[unknown]'],malformedMapLines=malformed,categories=categories,percent={k:100*v/counts.total() for k,v in categories.items()},allLeafCounts=counts.most_common(),
        limitation='Leaf shares include inlined callees and profiler/tiering effects; no causal speedup or subtraction from old captures.')
(out/'assessment.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
for name in ['identity.json','pre-capture-plan.md']:shutil.copyfile(root/name,out/name)
with tarfile.open(out/'source-and-check-history.tgz','w:gz') as a:
    for p in sorted(root.iterdir()):
        if p.is_file() and p.name not in ['payload.tgz','observations.tgz']:a.add(p,arcname=p.name)
print(json.dumps({k:{'samples':v['samples'],'cpuSeconds':v['activeGuestCpuSeconds'],'percent':v['percent'],'unknownPercent':100*v['unknown']/v['samples']} for k,v in results.items()},indent=2))
