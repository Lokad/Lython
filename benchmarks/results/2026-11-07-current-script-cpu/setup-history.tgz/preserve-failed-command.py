from pathlib import Path
import fcntl,hashlib,json,shutil,subprocess,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'current-cpu-b370-20261107'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 archive=root/'failed-observations.tgz'
 with tarfile.open(archive,'w:gz') as a:
  for p in root.rglob('*'):
   if p.is_file() and not p.is_symlink() and p!=archive:a.add(p,arcname=str(p.relative_to(root)))
 receipt=dict(complete=False,reason='perf report owner check after premature chown; missing postverification/quiet; no qualified profile',allUsersEnded=True,archiveSHA256=hashlib.sha256(archive.read_bytes()).hexdigest(),freeBytes=shutil.disk_usage(base).free)
 (root/'failed-archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)
