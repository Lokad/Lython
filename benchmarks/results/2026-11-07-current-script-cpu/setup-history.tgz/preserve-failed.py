from pathlib import Path
import hashlib,json,subprocess
root=Path(__file__).parent
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15']
script='''from pathlib import Path
import fcntl,hashlib,json,shutil,subprocess,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'current-cpu-b370-20261107'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 archive=root/'failed-observations.tgz'
 with tarfile.open(archive,'w:gz') as a:
  for p in root.rglob('*'):
   if p.is_file() and not p.is_symlink() and p!=archive:a.add(p,arcname=str(p.relative_to(root)))
 receipt=dict(complete=False,reason='perf report owner check after premature chown; missing postverification/quiet; no qualified profile',allUsersEnded=True,archiveSHA256=hashlib.sha256(archive.read_bytes()).hexdigest(),freeBytes=shutil.disk_usage(base).free)
 (root/'failed-archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\\n');print(json.dumps(receipt),flush=True)
'''
(root/'preserve-failed-command.py').write_text(script,encoding='utf-8')
p=subprocess.run([*ssh,'lokad@20.166.121.73','python3 -'],input=script,text=True,encoding='utf-8',capture_output=True);assert p.returncode==0,p.stderr
receipt=json.loads(p.stdout);(root/'failed-archive-receipt.json').write_text(p.stdout,encoding='utf-8')
p=subprocess.run(['C:/Windows/System32/OpenSSH/scp.exe',*ssh[1:],'lokad@20.166.121.73:/home/lokad/lython-bench-checks/current-cpu-b370-20261107/failed-observations.tgz',str(root/'failed-observations.tgz')],capture_output=True);assert p.returncode==0,p.stderr
assert hashlib.sha256((root/'failed-observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
print(receipt,flush=True)
