from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path(__file__).resolve().parent
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
script='''from pathlib import Path
import json,subprocess
root=Path('/home/lokad/lython-bench-checks/current-cpu-b370-20261107')
s=subprocess.run(['systemctl','show','lython-b370-current-cpu-20261107.service','--property=ActiveState,SubState,MainPID,Result,ExecMainStatus'],capture_output=True,text=True)
print(json.dumps(dict(service=s.stdout,exitCode=(root/'exit-code.txt').read_text().strip() if (root/'exit-code.txt').exists() else None,
 receipt=json.loads((root/'archive-receipt.json').read_text()) if (root/'archive-receipt.json').exists() else None,
 remainingWorkers=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True,text=True).stdout,
 remainingFixtures=[str(p) for p in Path('/dev/shm').glob('lython-comparison-files-*')],
 journal=subprocess.run(['journalctl','-u','lython-b370-current-cpu-20261107.service','--no-pager','-n','25'],capture_output=True,text=True).stdout)))
'''
r=subprocess.run([*ssh,'python3 -'],input=script,text=True,encoding='utf-8',capture_output=True)
(root/'terminal-status.json').write_text(r.stdout,encoding='utf-8');assert r.returncode==0,r.stderr
d=json.loads(r.stdout);print({k:v for k,v in d.items() if k!='journal'},flush=True)
assert 'MainPID=0' in d['service'] and not d['remainingWorkers'] and not d['remainingFixtures']
if not d['receipt']:
    print(d['journal'],flush=True);raise SystemExit(2)
assert d['exitCode']=='0' and d['receipt']['complete']
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for name in ['observations.tgz','archive-receipt.json']:
    r=subprocess.run([*scp,'lokad@20.166.121.73:/home/lokad/lython-bench-checks/current-cpu-b370-20261107/'+name,str(root/name)],capture_output=True,text=True);assert r.returncode==0,r.stderr
receipt=json.loads((root/'archive-receipt.json').read_text(encoding='utf-8'))
assert hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
dest=root/'retrieved';dest.mkdir()
with tarfile.open(root/'observations.tgz') as a:a.extractall(dest,filter='data')
print(receipt,flush=True)
