from pathlib import Path
import ast,shutil,tarfile
root=Path(__file__).parent;out=root/'refined';out.mkdir()
before='/home/lokad/lython-bench-checks/current-cpu-b370-20261107';after='/home/lokad/lython-bench-checks/current-cpu-b371-20261107'
for name in ['identity.json','catalog.json','pre-capture-plan.md','setup-contract.md','ops-profile.py','run.sh','analyze-cpu-guest.py','archive.py','start.py','retrieve.py','assess.py']:
    s=(root/name).read_text(encoding='utf-8').replace(before,after).replace('lython-b370-current-cpu-20261107','lython-b371-current-cpu-20261107').replace('b370-launch.py','b371-launch.py')
    if name=='ops-profile.py':
        block='''            raw=folder/'perf.data'
            assert raw.is_file() and not raw.is_symlink() and output in raw.resolve().parents
            subprocess.run(['sudo','-n','chown','lokad:lokad',str(raw)],check=True)
'''
        assert block in s;s=s.replace(block,'')
    if name=='run.sh':
        s=s.replace('python3 "$root/archive.py"','''# All sudo perf reads have ended before transferring these owned files.
sudo -n chown lokad:lokad "$root/perf/text-warm/perf.data" "$root/perf/report-warm/perf.data"
python3 "$root/archive.py"''')
    if name.endswith('.py'):ast.parse(s)
    (out/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz') as a:
    for name in ['identity.json','catalog.json','pre-capture-plan.md','ops-profile.py','run.sh','analyze-cpu-guest.py','archive.py']:a.add(out/name,arcname=name)
s=(root.parent/'regex-program-artifacts-r23/retire-verified-profile.py').read_text(encoding='utf-8').replace('8275272','3151400').replace('perf/csv-warm/perf.data','perf/text-compile/perf.data')
(out/'retire-verified-profile.py').write_text(s,encoding='utf-8')
print('Preserved B370; refined only export ownership order for B371.')
