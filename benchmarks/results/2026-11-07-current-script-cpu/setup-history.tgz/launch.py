from pathlib import Path
import ast,fcntl,hashlib,io,json,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'current-cpu-b370-20261107'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(55908+1);assert len(payload)==55908 and hashlib.sha256(payload).hexdigest()=='c59795506620dc17f82c1adb2fa2af4a49322c84696bbdc5503bb63e22f4a06e'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  assert shutil.disk_usage(base).free>sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+12*1024*1024
  root.mkdir();a.extractall(root,filter='data')
 (root/'candidate').symlink_to(base/'regex-programs-b369-20261106/candidate',target_is_directory=True)
 identity=json.loads((root/'identity.json').read_text())
 for name,digest in {**identity['auxiliaryFiles'],**identity['files']}.items():
  assert hashlib.sha256((root/'candidate'/name).read_bytes()).hexdigest()==digest
 cases={c['id'] for c in json.loads((root/'catalog.json').read_text())['cases']}
 assert cases>={'scripts.text-summary-helpers.large','scripts.report-render.large'}
 for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py']:ast.parse((root/name).read_text())
 assert b'\r' not in (root/'run.sh').read_bytes();subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 record=dict(freeBytes=shutil.disk_usage(base).free,coreAndAuxiliaryImagesVerified=True,profilerMode='PerfMapEnabled3',ownerSeconds=150,stopSeconds=30,observeAfterSeconds=180)
 (root/'setup.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b370-current-cpu-20261107','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=150','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
