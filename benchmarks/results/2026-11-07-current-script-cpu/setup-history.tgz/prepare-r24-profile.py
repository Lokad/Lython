from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile
home=Path(__file__).parent;root=home.parent/'current-cpu-r24';root.mkdir()
old=home.parent/'current-cpu-r19';prior='/home/lokad/lython-bench-checks/current-cpu-b358-20261106';remote='/home/lokad/lython-bench-checks/current-cpu-b370-20261107'
def write(name,text):
    (root/name).write_text(text,encoding='utf-8',newline='\n')
snapshot=json.loads((home/'b369/identity.json').read_text(encoding='utf-8'))
actual={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('src/Lokad.Lython').rglob('*.cs') if not {'bin','obj'}.intersection(p.parts)}
assert actual==snapshot['sourceSHA256']
identity=dict(sourceRevision='ec134e8c; production matches B369 frozen23a0a257',files={'Lokad.Lython.dll':snapshot['coreSHA256']['candidate']},
    auxiliaryFiles=snapshot['auxiliaryFiles'],sourceSHA256=actual,purpose='R24 current text/report CPU source gate after record layout/prefix/builtin changes; not a speed comparison',
    diagnosticOverride={'DOTNET_PerfMapEnabled':'3'},limitation='Inlined leaf shares and profiling/tiering effects are not removable fractions or predicted savings.')
write('identity.json',json.dumps(identity,indent=2)+'\n');shutil.copyfile(home/'comparison-catalog.json',root/'catalog.json');shutil.copyfile('PLAN.md',root/'pre-capture-plan.md')
for name in ['ops-profile.py','run.sh','analyze-cpu-guest.py','archive.py']:
    s=(old/name).read_text(encoding='utf-8').replace(prior,remote)
    if name=='ops-profile.py':
        s=s.replace('count = 3072 if name == "text-warm" else 2048','count = 1  # Deadline bounded; each request remains a complete checked job.')
        needle='''            record["response"] = request("batch", count)'''
        assert needle in s
        s=s.replace(needle,'''            batches=[];deadline=time.monotonic()+3
            while time.monotonic()<deadline:
                batches.append(request("batch",1))
            assert batches
            record["batches"]=batches
            record["response"]={**batches[-1],"elapsedTicks":sum(b["elapsedTicks"] for b in batches),
                "completedInvocations":sum(b["completedInvocations"] for b in batches)}''')
        s=s.replace('if total_capture_seconds > 30:', 'if total_capture_seconds > 8:')
        s=s.replace('            assert profiler.returncode == 0','''            assert profiler.returncode == 0
            raw=folder/'perf.data'
            assert raw.is_file() and not raw.is_symlink() and output in raw.resolve().parents
            subprocess.run(['sudo','-n','chown','lokad:lokad',str(raw)],check=True)''')
    if name=='archive.py':s=s.replace("for r in records)<30", "for r in records)<8")
    if name.endswith('.py'):ast.parse(s)
    write(name,s)
with tarfile.open(root/'payload.tgz','w:gz') as a:
    for name in ['identity.json','catalog.json','pre-capture-plan.md','ops-profile.py','run.sh','analyze-cpu-guest.py','archive.py']:a.add(root/name,arcname=name)
write('setup-contract.md','Existing worker/core23a0a257/normal0.4 adapter; complete text/report warm jobs.6s warmup+2s settle per worker, deadline3s captures with checked single-job requests, perf199Hz/cpu-clock/fp and map-only diagnostic. No CPU speed comparison. Require Ready hashes, goldens, terminal budget0/Closed/exit0, joins/fixtures, quiet endpoints and verified persistent under-lease archive.150sowner+30sstop, no SSH before180s. Preserve unknowns/malformed maps and all failures.\n')
print('Prepared local R24 profile payload; nothing launched.')
