from pathlib import Path
import hashlib,json,os,platform,shutil,statistics,subprocess
p=Path(__file__).resolve().parent
sha=lambda data: hashlib.sha256(data).hexdigest()
identity=json.loads((p/'frozen-identity.json').read_text(encoding='utf-8'))
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),DOTNET_TieredCompilation='0',PATH=str(sdk)+os.pathsep+os.environ['PATH'])
stem='Lokad.Lython.WhiteBox.Tests'
build=p/'bin/Release/net11.0'
assembly={}
for role,files in identity['images'].items():
  frozen=p/'frozen'/role
  assert len(files)==32 and {n:sha((frozen/n).read_bytes())for n in files}==files
  directory=p/'diagnostic-images'/role
  directory.mkdir(parents=True)
  for variant in (stem+'.dll',stem+'.deps.json',stem+'.runtimeconfig.json'):
   shutil.copyfile(build/variant,directory/variant)
  shutil.copyfile(frozen/'Lokad.Lython.dll',directory/'Lokad.Lython.dll')
  assert sha((directory/'Lokad.Lython.dll').read_bytes())==files['Lokad.Lython.dll']
  assembly[role]=directory/(stem+'.dll')
execution={}
for role,case in [('reference','reference'),('candidate','candidate'),('candidate','candidate-control'),('reference','reference-control')]:
  values=subprocess.check_output([dotnet,assembly[role]],env=env,timeout=90)
  data=json.loads(values)
  if execution:
    assert len(data['rows'])==len(execution['reference']['rows'])
    for x,y in zip(data['rows'],execution['reference']['rows'],strict=True):
      assert x['name']==y['name'] and x['window']==y['window'] and x['inputBytes']==y['inputBytes']
  for row in data['rows']:
    assert row['allocatedBytes']==0,row
    w=row['window']
    assert row['checksum']==7*row['count']*(w['StartByte']+w['EndByte'])
  execution[case]=data
summary=[]
for i,base in enumerate(execution['reference']['rows']):
   ns={role:statistics.median(d['rows'][i]['samples'])/d['frequency']/d['rows'][i]['count']*1e9
       for role,d in execution.items()}
   print(base['name'],{k:round(v,2)for k,v in ns.items()})
   summary.append(dict(name=base['name'],window=base['window'],inputBytes=base['inputBytes'],
                       elapsedNanoseconds=ns))
(p/'diagnostic-summary.json').write_text(json.dumps(dict(environment=platform.platform(),processor=platform.processor(),
    tieredCompilation=False,timing='Loop around window coordinates only. Input already encoded and scalar count known.',
    core=identity,raw=execution,rows=summary),indent=2)+'\n',encoding='utf-8',newline='\n')
