using System.Diagnostics;
using System.Text;
using System.Text.Json;
using Lokad.Lython;
using Lokad.Lython.Runtime;

var span = new LythonSourceSpan(1, 2, 1, 2);
const string pattern = "aé漢😀";
var shortSubject = Encoding.UTF8.GetBytes(string.Concat(Enumerable.Repeat(pattern, 4)));
var mixed = Encoding.UTF8.GetBytes(string.Concat(Enumerable.Repeat(pattern, 8192)));
const int longLength = 4 * 8192;
var ascii = new byte[longLength];
Array.Fill(ascii, (byte)'a');
var modes = new[]{
    ("ascii-suffix", ascii, longLength, longLength - 12, longLength - 2),
    ("short-prefix", shortSubject, 16, 1, 5),
    ("mixed-prefix", mixed, longLength, 4, 12),
    ("mixed-suffix", mixed, longLength, longLength - 12, longLength - 2),
    ("mixed-interior", mixed, longLength, longLength / 2 - 7, longLength / 2 + 9),
    ("mixed-opposite", mixed, longLength, 7, longLength - 9),
    ("mixed-reversed-suffix", mixed, longLength, longLength - 2, longLength - 12)
};

var output = new List<object>();
foreach (var (name, input, length, position, end) in modes)
{
    var (warmTicks, _) = Call(input, length, position, end, 256);
    var count = (int)Math.Clamp((Stopwatch.Frequency * .04 * 256) / Math.Max(warmTicks, 1), 64, 4_000_000);
    _ = Call(input, length, position, end, count);
    var samples = new long[7];
    var before = GC.GetAllocatedBytesForCurrentThread();
    var checksum = 0L;
    for (var i = 0; i < samples.Length; i++)
    {
        var (ticks, sum) = Call(input, length, position, end, count);
        samples[i] = ticks;
        checksum += sum;
    }
    var after = GC.GetAllocatedBytesForCurrentThread();
    var window = LythonRuntime.RegexCompiler.CreateWindow(input, length, position, end, default, span);
    output.Add(new { name, inputBytes = input.Length, length, window, count, samples, checksum,
        allocatedBytes = after - before });
}
Console.WriteLine(JsonSerializer.Serialize(new { frequency = Stopwatch.Frequency, rows = output }));

(long, long) Call(byte[] input, int length, int position, int end, int count)
{
    var checksum = 0L;
    var started = Stopwatch.GetTimestamp();
    for (var i = 0; i < count; i++)
    {
        var window = LythonRuntime.RegexCompiler.CreateWindow(input, length, position, end, default, span);
        checksum += window.StartByte + window.EndByte;
    }
    return (Stopwatch.GetTimestamp() - started, checksum);
}
