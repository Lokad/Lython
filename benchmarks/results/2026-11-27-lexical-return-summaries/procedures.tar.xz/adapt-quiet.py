from pathlib import Path
lab = Path(__file__).resolve().parent
old = lab.parent / "local-assignment-slots-20261127"
s = (old / "prepare-quiet.py").read_text(encoding="utf-8")
s = s.replace('"generator-definition-cache-20261127/comparison/quiet"', '"local-assignment-slots-20261127/comparison/quiet"')
s = s.replace('"Quiet comparison of slot-indexed assignment analysis and a warm JSON control."',
              '"Quiet comparison of lexical return-summary preparation and ordinary module compile control."')
s = s.replace('["compile", "warm", "compile-run"]', '["compile", "compile", "compile-run"]')
s = s.replace('proof["caseCount"] == 4', 'proof["caseCount"] == 5')
s = s.replace("assignment-slots-quiet-b1900-20261127", "lexical-return-quiet-b1901-20261127")
s = s.replace("lython-b1900-local-assignment-slots-fixtures", "lython-b1901-lexical-return-fixtures")
s = s.replace("lython-b1900-assignment-slots-quiet", "lython-b1901-lexical-return-quiet")
s = s.replace('compile(vm, "quiet-vm.py", "exec")', 'vm = vm.replace("caseCount\x27]==4", "caseCount\x27]==5")\ncompile(vm, "quiet-vm.py", "exec")')
compile(s, "prepare-quiet.py", "exec")
(lab / "prepare-quiet.py").write_text(s, encoding="utf-8", newline="\n")
