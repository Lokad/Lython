from pathlib import Path

lab = Path(__file__).resolve().parent
prior = lab.parent / "local-assignment-slots-20261127"
probe = lab / "probe"
probe.mkdir()
source = (prior / "probe/Program.cs").read_text(encoding="utf-8")
source = source.replace('["large-scope"]', r'''["summary-if-no-else"] = "def choose(flag):\n if flag:\n  return 'text'\nchoose(True).find(1)\n",
    ["summary-if-else-no-return"] = "def choose(flag):\n if flag:\n  return 'text'\n else:\n  pass\nchoose(True).find(1)\n",
    ["summary-if-else-both-return"] = "def choose(flag):\n if flag:\n  return 'text'\n else:\n  return 'other'\nchoose(True).find(1)\n",
    ["summary-with-nested-branches"] = "def load(flag):\n with open('/input.txt') as stream:\n  if flag:\n   return stream.read()\n  else:\n   return 'other'\nload(True).find(1)\n",
    ["summary-unsupported-child"] = "def choose(flag):\n if flag:\n  return 'text'\n else:\n  while flag:\n   pass\n  return 'other'\nchoose(True).find(1)\n",
    ["summary-variadic"] = "def choose(*args):\n return 'text'\nchoose(True).find(1)\n",
    ["summary-decorated"] = "def decorate(function):\n return function\n@decorate\ndef choose(flag):\n return 'text'\nchoose(True).find(1)\n",
    ["large-scope"]''')
(probe / "Program.cs").write_text(source, encoding="utf-8", newline="\n")
(probe / "CompilerFacts.csproj").write_text((prior / "probe/CompilerFacts.csproj").read_text(encoding="utf-8"), encoding="utf-8", newline="\n")
reader = (prior / "check-compiler.py").read_text(encoding="utf-8")
reader = reader.replace("len(diagnostics) == 9", "len(diagnostics) == 16")
reader = reader.replace("assert sum(not row['IsValid'] for row in diagnostics) >= 6", """results = {row["id"]: row["IsValid"] for row in diagnostics}
assert results["summary-if-else-no-return"] and results["summary-unsupported-child"]
assert not results["summary-if-else-both-return"] and not results["summary-with-nested-branches"]""")
compile(reader, "check-compiler.py", "exec")
(lab / "check-compiler.py").write_text(reader, encoding="utf-8", newline="\n")
