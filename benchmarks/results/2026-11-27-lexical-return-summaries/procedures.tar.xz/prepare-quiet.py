from hashlib import sha256
from pathlib import Path
from shutil import copyfile
import json
import tarfile

lab = Path(__file__).resolve().parent
pair = lab / "comparison"
prior = lab.parent / "quiet-generator-outer-20261127"
donor = lab.parent / "local-assignment-slots-20261127/comparison/quiet"
quiet = pair / "quiet"
quiet.mkdir()
read = lambda path: json.loads(path.read_text(encoding="utf-8"))
digest = lambda path: sha256(path.read_bytes()).hexdigest()
def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8", newline="\n")

identity = read(pair / "identity.json")
receipt = read(donor / "terminal-status.json")["receipt"]
donor_files = read(donor / "identity.json")["imageFiles"]["candidate"]
assert receipt["quietBeforeAndAfter"] and receipt["allWorkersJoined"]
assert receipt["archiveSHA256"] == digest(donor / "observations.tar.xz")
assert identity["imageFiles"]["reference"] == donor_files
for role, files in identity["imageFiles"].items():
    assert {file.name: digest(file) for file in (pair / role).iterdir()} == files
    proof = read(pair / f"{role}-verify.json")
    assert proof["state"] == "Completed" and proof["caseCount"] == 5
    assert proof["launched"]["library"]["sha256"] == files["Lokad.Lython.dll"]
    assert proof["launched"]["adapter"]["sha256"] == files["Lokad.Lython.Benchmarks.dll"]
    assert proof["catalogSha256"] == identity["catalogs"]["representative.json"]["sha256"]
identity["donorArchiveSHA256"] = receipt["archiveSHA256"]
identity["purpose"] = "Quiet comparison of lexical return-summary preparation and ordinary module compile control."
for name in ("representative.json", "cpython-worker.py"):
    copyfile(pair / name, quiet / name)
jobs = read(pair / "jobs.json")["warm"]
selected = [jobs[index] for index in (0, 1, 4)]
assert [row[1] for row in selected] == ["compile", "compile", "compile-run"]
write(quiet / "jobs.json", {"warm": selected})
identity["catalogs"]["jobs.json"]["sha256"] = digest(quiet / "jobs.json")
prior_quiet = prior / "comparison/quiet"
copyfile(prior_quiet / "run.sh", quiet / "run.sh")
assert b"\r" not in (quiet / "run.sh").read_bytes()
collector = (prior_quiet / "collect.py").read_text(encoding="utf-8")
collector = collector.replace("lython-b1895-generator-outer-fixtures", "lython-b1901-lexical-return-fixtures")
collector = collector.replace("len(jobs) == 4", "len(jobs) == 3").replace(
    "if job_index % 2 == 0: labels.reverse()", "if job_index % 2 == 1: labels.reverse()")
assert "len(jobs) == 3" in collector
compile(collector, "collect.py", "exec")
(quiet / "collect.py").write_text(collector, encoding="utf-8", newline="\n")
write(quiet / "identity.json", identity)
payload_paths = {name: quiet / name for name in ("identity.json", "representative.json", "jobs.json", "cpython-worker.py", "run.sh", "collect.py")}
payload_paths["candidate/Lokad.Lython.dll"] = pair / "candidate/Lokad.Lython.dll"
payload = quiet / "stage.tar.gz"
with tarfile.open(payload, "w:gz") as archive:
    for name, source in payload_paths.items():
        archive.add(source, arcname=name)
files = {name: dict(length=file.stat().st_size, sha256=digest(file)) for name, file in payload_paths.items()}
write(quiet / "upload.json", dict(root="lexical-return-quiet-b1901-20261127",
    donor=read(donor / "upload.json")["root"], donorFiles=donor_files, donorArchive=receipt["archiveSHA256"],
    payloadSHA256=digest(payload), files=files, expandedBytes=sum(file["length"] for file in files.values()),
    minimumAfterStageBytes=12 * 1024 * 1024))
vm = (prior / "quiet-vm.py").read_text(encoding="utf-8")
vm = vm.replace("lython-b1895-generator-outer-quiet", "lython-b1901-lexical-return-quiet")
vm = vm.replace("RuntimeMaxSec=250", "RuntimeMaxSec=195")
vm = vm.replace("caseCount']==4", "caseCount']==5")
compile(vm, "quiet-vm.py", "exec")
(lab / "quiet-vm.py").write_text(vm, encoding="utf-8", newline="\n")
print("Prepared complete paired images for three lanes.")
