#!/usr/bin/env bash
set -euo pipefail
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
cd /mnt/d/code/Lython
lab="$PWD/.git/agent-notes/review-20261031/lexical-return-summaries-20261127"
export NUGET_PACKAGES="$PWD/.git/agent-notes/review-20261031/regex-released-050-20261127/packages-ubuntu"
project=tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj
filter='Category!=Stress&(FullyQualifiedName~StaticErrorDiagnosticsTests|FullyQualifiedName~SharedCompilerFactTests|FullyQualifiedName~UnboundLocalVariableTests|FullyQualifiedName~NonlocalRebindingTests|FullyQualifiedName~DeferredDefinitionBindingTests|FullyQualifiedName~GeneratorConstructionScenarioTests|FullyQualifiedName~Dataclass|FullyQualifiedName~TypeParameter|FullyQualifiedName~Scope)'
for fw in net11.0 net10.0; do
    dotnet test "$project" -c Release -f "$fw" --artifacts-path "$lab/ubuntu-artifacts" --filter "$filter" 2>&1 | tee "$lab/ubuntu-$fw.log"
done
