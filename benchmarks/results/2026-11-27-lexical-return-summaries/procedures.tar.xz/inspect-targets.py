from pathlib import Path
from collections import Counter
import ast
import json

lab = Path(__file__).resolve().parent
catalog = json.loads((lab / "comparison/representative.json").read_bytes())
rows = []
for case in catalog["cases"]:
    forms = Counter()
    for node in ast.walk(ast.parse(case["source"])):
        if isinstance(node, ast.Assign):
            forms["multi-target assignments"] += len(node.targets) > 1
            forms["unpacking assignment groups"] += sum(isinstance(target, (ast.Tuple, ast.List)) for target in node.targets)
        elif isinstance(node, ast.For):
            forms["unpacking for targets"] += isinstance(node.target, (ast.Tuple, ast.List))
        elif isinstance(node, ast.With):
            forms["with assignment targets"] += sum(item.optional_vars is not None for item in node.items)
        elif isinstance(node, ast.Starred) and isinstance(node.ctx, ast.Store):
            forms["starred assignment targets"] += 1
    rows.append({"case": case["id"], **forms})
for row in rows:
    print(row)
(lab / "syntax-target-census.json").write_text(json.dumps(rows, indent=2) + "\n", encoding="utf-8", newline="\n")
