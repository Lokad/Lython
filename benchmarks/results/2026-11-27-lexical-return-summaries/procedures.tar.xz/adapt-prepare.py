from pathlib import Path

lab = Path(__file__).resolve().parent
prior = lab.parent / "local-assignment-slots-20261127"
entry = (prior / "prepare.py").read_text(encoding="utf-8").replace(
    '"generator-definition-cache-20261127/comparison"', '"local-assignment-slots-20261127/comparison"')
entry = entry.replace('b"private readonly bool[] _assigned;" in patch and patch.count(b"diff --git ") == 1',
                      'b"HasSummarizableReturn" in patch and patch.count(b"diff --git ") == 2')
lo = entry.index("frontend =")
hi = entry.index("write(pair / \"representative.json\"", lo)
entry = entry[:lo] + """catalog_path = production / "representative.json"
assert digest(catalog_path) == original["catalogs"]["representative.json"]["sha256"]
catalog = read(catalog_path)
ordinary, escaping, guarded, nested = catalog["cases"]
module = notes / "name-diagnostic-roots-20261127/comparison"
assert digest(module / "representative.json") == read(module / "identity.json")["catalogs"]["representative.json"]["sha256"]
plain = next(case for case in read(module / "representative.json")["cases"] if case["id"] == "diagnostic.generated-guarded-configuration")
catalog["cases"].append(plain)
jobs = [[ordinary["id"], "compile"], [plain["id"], "compile"], [nested["id"], "warm"],
        [escaping["id"], "compile"], [guarded["id"], "compile-run"]]
""" + entry[hi:]
entry = entry.replace("Share lexical slots with the local definite-assignment diagnostics.",
                      "Prepare function return-summary eligibility with lexical bindings.")
entry = entry.replace('replace("len(jobs) == 4", "len(jobs) == 5").replace(\n    "lython-generator-definition-cache-", "lython-local-assignment-slots-")',
                      'replace("lython-local-assignment-slots-", "lython-lexical-return-summaries-")')
compile(entry, "prepare.py", "exec")
(lab / "prepare.py").write_text(entry, encoding="utf-8", newline="\n")
