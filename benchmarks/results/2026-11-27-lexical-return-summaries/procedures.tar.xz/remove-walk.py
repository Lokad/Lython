from pathlib import Path

path = Path("src/Lokad.Lython/Frontend/StaticBindingEngine.Functions.cs")
text = path.read_text(encoding="utf-8")
before = "!IsStraightLineSummaryBody(functionDefinition.Body)"
assert text.count(before) == 1
text = text.replace(before, "!ScopeDirectiveFactsCollector.ForFunction(functionDefinition).HasSummarizableReturn")
start = text.index("    private static bool IsStraightLineSummaryBody")
end = text.index("    private static bool TryGetParameterCallShapeFailure", start)
text = text[:start] + text[end:]
assert "IsStraightLineSummaryBody" not in text
path.write_text(text, encoding="utf-8", newline="\n")
