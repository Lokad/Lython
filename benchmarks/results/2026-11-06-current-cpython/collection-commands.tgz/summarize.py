from pathlib import Path
import base64,json,statistics
p=Path(__file__).parent;r=json.loads((p/'retrieved/confirmation/confirmation.json').read_text(encoding='utf-8'))
catalog=json.loads((p/'representative.json').read_text(encoding='utf-8'));cases={c['id']:c for c in catalog['cases']}
summary={'complete':r['complete'],'elapsedSeconds':r['elapsedSeconds'],'sourceRevision':json.loads((p/'identity.json').read_text(encoding='utf-8'))['sourceRevision'],'timing':[]}
for j in r['jobs']:
    values={label:[1000*s['response']['elapsedTicks']/s['response']['clockFrequency']/s['response']['completedInvocations'] for s in j['samples'] if s['engine']==label] for label in ['candidate','control','CPython']}
    med={label:statistics.median(v) for label,v in values.items()}
    cpu={label:statistics.median(1000*s['externalProcessCpuTicks']/s['externalCpuFrequency']/s['response']['completedInvocations'] for s in j['samples'] if s['engine']==label) for label in med}
    iqr={label:100*(statistics.quantiles(v,n=4)[2]-statistics.quantiles(v,n=4)[0])/med[label] for label,v in values.items()}
    ratios=sorted([med[label]/med['CPython'] for label in ['candidate','control']])
    times=sorted([med[label] for label in ['candidate','control']])
    control=100*abs(med['control']/med['candidate']-1)
    spread=max(iqr[label] for label in ['candidate','control'])
    fixture=json.loads(cases[j['case']]['fixtureJson'])
    inputbytes=sum(len(base64.b64decode(v)) for v in fixture.get('inputFiles',{}).values())
    row={'case':j['case'],'lane':j['lane'],'medianMilliseconds':med,'processCpuMedianMilliseconds':cpu,'ratioRange':ratios,'timeRangeMilliseconds':times,'controlPercent':control,'iqrPercent':iqr,'inputBytes':inputbytes,'status':'Diagnostic' if control<2 and spread<3 else 'Variable'}
    summary['timing'].append(row)
    print(j['lane'],j['case'].split('.')[1],f"{times[0]:.6f}–{times[1]:.6f}ms /{med['CPython']:.6f}ms = {ratios[0]:.2f}–{ratios[1]:.2f}x",f'control {control:.2f}% IQR {spread:.2f}% {row["status"]}; input {inputbytes}B',flush=True)
(p/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
