from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path(__file__).parent
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
script='''from pathlib import Path
import hashlib,json,subprocess
root=Path('/home/lokad/lython-bench-checks/delivery-comparison-b367-20261106')
service=subprocess.run(['systemctl','show','lython-b367-delivery-comparison-20261106.service','--property=ActiveState,SubState,MainPID,Result,ExecMainStatus'],text=True,capture_output=True)
print(json.dumps({'service':service.stdout,'serviceError':service.stderr,'exitCode':(root/'exit-code.txt').read_text().strip() if (root/'exit-code.txt').exists() else None,'receipt':json.loads((root/'archive-receipt.json').read_text()) if (root/'archive-receipt.json').exists() else None,'remainingWorkers':subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True,text=True).stdout,'remainingFixtures':[str(p) for p in Path('/dev/shm').glob('lython-comparison-files-*')]}))
'''
r=subprocess.run([*ssh,'python3 -'],input=script,text=True,encoding='utf-8',capture_output=True)
(root/'terminal-status.json').write_text(r.stdout,encoding='utf-8');assert r.returncode==0,r.stderr
status=json.loads(r.stdout);print(status,flush=True)
assert status['exitCode']=='0' and status['receipt']['complete'] and status['receipt']['jobs']==15
assert not status['remainingWorkers'] and not status['remainingFixtures']
assert 'MainPID=0' in status['service'] and 'ActiveState=active' not in status['service']
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for name in ['observations.tgz','archive-receipt.json']:
    p=subprocess.run([*scp,'lokad@20.166.121.73:/home/lokad/lython-bench-checks/delivery-comparison-b367-20261106/'+name,str(root/name)],capture_output=True,text=True,encoding='utf-8')
    assert p.returncode==0,p.stderr
receipt=json.loads((root/'archive-receipt.json').read_text(encoding='utf-8'))
assert hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
destination=root/'retrieved';destination.mkdir()
with tarfile.open(root/'observations.tgz') as a:a.extractall(destination,filter='data')
print('Retrieved and verified',receipt,flush=True)

