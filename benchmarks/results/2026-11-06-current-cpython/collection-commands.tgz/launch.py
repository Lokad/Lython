from pathlib import Path
import fcntl,hashlib,io,json,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=Path('/home/lokad/lython-bench-checks/delivery-comparison-b367-20261106');prior=Path('/home/lokad/lython-bench-checks/resume-boundary-b366-20261106')
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(38997+1);assert len(payload)==38997 and hashlib.sha256(payload).hexdigest()=='70fa15f05787390136df91e861abe5f9b2dc0de51414ab39e00084386f323057'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  assert shutil.disk_usage(base).free>sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+128*1024+8*1024*1024
  root.mkdir();a.extractall(root,filter='data')
 for n in ['candidate','representative.json','cpython-worker.py','source.patch']:(root/n).symlink_to(prior/n,target_is_directory=(prior/n).is_dir())
 i=json.loads((root/'identity.json').read_text());assert hashlib.sha256((root/'candidate/Lokad.Lython.dll').read_bytes()).hexdigest()==i['coreSHA256']['candidate']
 for n,digest in i['auxiliaryFiles'].items():assert hashlib.sha256((root/'candidate'/n).read_bytes()).hexdigest()==digest
 cases={c['id'] for c in json.loads((root/'representative.json').read_text())['cases']}
 assert cases=={'scripts.csv-summary-functions.large','scripts.text-summary-helpers.large','scripts.json-summary-helpers.large','scripts.report-render.large','scripts.config-edit.small'}
 for n in ['collect.py','archive-owned.py']:compile((root/n).read_text(),str(root/n),'exec')
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,currentCoreSHA256=i['coreSHA256']['candidate'],allFifteenJobsValidated=True)),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b367-delivery-comparison-20261106','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=420','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
