from pathlib import Path
import json,shutil,tarfile
root=Path(__file__).parent;out=Path('benchmarks/results/2026-11-06-current-cpython');out.mkdir()
summary=json.loads((root/'summary.json').read_text(encoding='utf-8'))
for name in ['identity.json','summary.json','archive-receipt.json','terminal-status.json','observations.tgz']:
    shutil.copyfile(root/name,out/name)
with tarfile.open(out/'collection-commands.tgz','w:gz') as a:
    for p in sorted(root.iterdir()):
        if p.is_file() and p.suffix in ['.py','.md']:a.add(p,arcname=p.name)
    for name in ['ubuntu-job.log','delivery-ci-third.json','admission-boundary-checks.json']:
        a.add(root.parent/'text-operands-r21'/name,arcname=name)
(out/'README.md').write_text('''# Current CPython comparison — R20/R21 checkpoint

2026-11-06. Runtime source4fad63c5, evidence/package source799895ea; measured
corec3e65ad3. Normal0.4 optional adapter/producer and b94fa98c worker remain
unchanged. Private dev46 qualification is outside these images. This refresh
measures the combined runtime; it is not a causal comparison of individual changes.

Existing five complete scripts, separate compilation/disposal, warm execution,
and compile-to-result. CPython3.13.16 plus two independent identical current roles,
normal GC/tiering, five-second warmups and seven rotated150ms rounds. All15jobs
complete312.23s. Full output/file goldens, terminal balances, Closed/joins, quiet
endpoints, fixture cleanup and persistent under-lease archive verification pass.
No SSH during collection; all users are terminal. Exact identities, scripts,
host/worker protocol, raw rounds and command history remain in the archives.

Fresh Lython/CPython: CSV1.25–1.26x, text1.77–1.79x, JSON1.08–1.11x,
report1.50–1.53x, config1.21–1.22x. Warm:1.31–1.32/1.88–1.90/1.08–1.09/
1.32–1.37/1.28–1.29x. JSON fresh has2.13% identical-role spread; report warm3.47%
spread/3.95%IQR. Compilation remains44–73us. Keep the full ranges and adverse
conditions. Do not subtract independent fresh/warm medians or interpret changes
from the earlier checkpoint as isolated source speedups. CPython report fresh
is below its warm block; the distinct observations are retained unchanged.

Includes mediated RAM-file I/O, full validation and prior-result cleanup; fresh
adds compilation/program disposal. Excludes startup, fixture staging/reset,
transport and final teardown. CPython retains modules; Lython isolates imports.
Startup, RSS, genuine pending-I/O and embedding-tail latency remain unmeasured.
External process CPU ticks are preserved but provide no guest-only attribution.

Local full ordinary/focused Release and installed consumers pass both actual
runtimes. Delivery CI42302690579 fails Ubuntu.NET10 on the discovery allocation
test:168736B versus131072B measured through diagnostic construction after refusal.
The test already has a first-refusal observation. Correct its endpoint to that
preflight boundary, retaining the original limit, refusal origin and zero final
balance.23focused admission/cleanup tests pass per actual11/10. The original
failure/log remains here; updated platform/stress qualification is still pending.
Do not label this source fully platform-qualified until those gates pass.

The previous f2ce53db runtime remains fully qualified under GREEN42294911136.
Publication/tagging postponed. The performance objective remains active: the text
gap and earlier source-pair debt are not explained by this aggregate refresh.
''',encoding='utf-8')
p=Path('docs/BENCHMARKS.md');text=p.read_text(encoding='utf-8');head=text[:text.index('## Improvements within Lython')];tail=text[text.index('## Improvements within Lython'):]
labels={'csv-summary-functions':'CSV summary/ordinary helper','text-summary-helpers':'Text summary/helpers','json-summary-helpers':'JSON-lines/helpers','report-render':'JSON-to-Markdown report','config-edit':'Configuration read/edit/write'}
inputs=['4,096 records / 57,361 B','3,072 lines / 35,840 B','4,096 records / 110,592 B','3,072 records / 189,441 B','16 paths / 181 B']
def table(lane,heading):
    rows=[r for r in summary['timing'] if r['lane']==lane];assert len(rows)==5
    lines=[heading,'| --- | --- | ---: | ---: | ---: | --- |'] if lane=='compile-run' else [heading,'| --- | ---: | ---: | ---: | --- |']
    for index,r in enumerate(rows):
        name=labels[r['case'].split('.')[1]];scale=1000 if lane=='compile' or 'config-edit' in r['case'] else 1;unit='µs' if scale==1000 else 'ms'
        lo,hi=[v*scale for v in r['timeRangeMilliseconds']];py=r['medianMilliseconds']['CPython']*scale
        ratio=r['ratioRange'];spread=max(r['iqrPercent'][k] for k in ['candidate','control']);status=f"{r['status']}; {r['controlPercent']:.2f}% / {spread:.2f}%"
        values=[name]+([inputs[index]] if lane=='compile-run' else [])+[f'{lo:.3f}–{hi:.3f} {unit}',f'{py:.3f} {unit}',f'{ratio[0]:.2f}–{ratio[1]:.2f}×',status]
        lines.append('| '+' | '.join(values)+' |')
    return '\n'.join(lines)
def replace_table(text,heading,new):
    start=text.index(heading);end=text.index('\n\n',start);return text[:start]+new+text[end:]
head=replace_table(head,'| Workload |',table('compile-run','| Workload | Input | Lython | CPython | Lython / CPython | Measurement status |'))
head=replace_table(head,'| Warm workload |',table('warm','| Warm workload | Lython | CPython | Ratio | Status; current control / Lython IQR |'))
head=replace_table(head,'| Compile-only script |',table('compile','| Compile-only script | Lython | CPython | Ratio | Status; current control / Lython IQR |'))
head=head.replace('`b6650f09`','`4fad63c5`').replace('Text fresh and report remain variable.','JSON fresh and warm report remain variable.').replace('`54b53c7f` matches the explicitly packed/installed Release package; this runtime\nalso passed Windows/Ubuntu, both runtimes and original Stress.','`c3e65ad3` has the recorded runtime source. Full local ordinary/focused Release\nand installed consumers pass both runtimes. Updated platform/stress qualification\nis pending after an Ubuntu allocation-test measurement failure; this source is\nnot yet fully platform-qualified.').replace('2026-11-06-delivery-cpython','2026-11-06-current-cpython').replace('and JSON fresh is slightly below warm in this collection.','and CPython report fresh is below warm in this collection.').replace('Fifteen jobs completed311.43s','Fifteen jobs completed312.23s')
head=head.replace('[Previous primary comparison, source `9a152ee0`](../benchmarks/results/2026-11-06-deferred-contexts/README.md),','[Previous primary comparison, source `b6650f09`](../benchmarks/results/2026-11-06-delivery-cpython/README.md),')
tail=tail.replace('primary five-script baseline above remains b6650f09.','primary five-script baseline above measures4fad63c5.').replace('not refreshed to `9a152ee0`','not refreshed to `4fad63c5`')
p.write_text(head+tail,encoding='utf-8')
