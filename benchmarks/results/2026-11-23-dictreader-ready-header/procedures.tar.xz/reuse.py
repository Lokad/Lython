from pathlib import Path
import shutil
p=Path(__file__).resolve().parent
prior=p.parent/'dictreader-activation-20261123'
def read(name):
    return (prior/name).read_text(encoding='utf-8-sig')
def write(name,text):
    (p/name).write_text(text,encoding='utf-8',newline='\n')
for name in ('representative.json','jobs.json','allocations.py','summarize.py'):
    shutil.copyfile(prior/name,p/name)
t=read('freeze.py').replace('agent-worktrees/dictreader-activation-20261123','agent-worktrees/dictreader-ready-header-20261123').replace('"9cea1fc0a"','"edb02618a"')
t=t.replace('B1484 complete ready DictReader records through the native record builder','B1485 return ready DictReader headers directly')
t=t.replace('assert not git("diff", "--name-only", base, "HEAD^", "--", "src", "tests")','assert not git("diff", "--name-only", base, "HEAD^", "--", "src", "tests")\nassert not git("diff", "--name-only", base, identity["candidate"], "--", "src")')
write('freeze.py',t)
t=read('stage.py').replace('dictreader-activation-b1484-20261123','dictreader-ready-header-b1485-20261123').replace('lython-b1484-fixtures','lython-b1485-fixtures')
write('stage.py',t)
t=read('quiet.py').replace('lython-b1484-dictreader-activation-20261123','lython-b1485-dictreader-ready-header-20261123').replace('b1484-stage','b1485-stage').replace('.+b1484-', '.+b1485-')
first=t.index('configuration["retire"] = []')
last=t.index('configuration["unit"]=unit',first)
t=t[:first]+t[last:]
first=t.index('  if free < minimum:')
last=t.index('  assert free >= minimum,',first)
t=t[:first]+t[last:]
t=t.replace("   'needs one core, publication archive and working-room floor'","   'needs one core, archive and working-room floor'")
compile(t,'quiet.py','exec')
write('quiet.py',t)
