from pathlib import Path
lab=Path(__file__).resolve().parent
repo=lab.parents[3]
tree=repo/'.git/agent-worktrees/dictreader-ready-header-20261123'
p=tree/'src/Lokad.Lython/Runtime/LythonRuntime.CsvObjects.cs'
t=p.read_text(encoding='utf-8')
old="""        private async ValueTask<object> GetFieldNamesAsync(bool asynchronous)
        {
            if (_fieldNames is PyNone)
            {
                var row = asynchronous ? await Rows.TryMoveNextAsync().ConfigureAwait(false) : Rows.TryMoveNext(out var next) ? next : null;
                if (row is not null) _fieldNames = Rows.AdoptRecord(row);
            }
            _lineNumber.SetInteger(Rows.PhysicalLineCount);
            return _fieldNames;
        }"""
new="""        private ValueTask<object> GetFieldNamesAsync(bool asynchronous)
            => _fieldNames is PyNone ? ReadFieldNamesAsync(asynchronous) : new(CurrentFieldNames());

        private async ValueTask<object> ReadFieldNamesAsync(bool asynchronous)
        {
            var row = asynchronous ? await Rows.TryMoveNextAsync().ConfigureAwait(false) : Rows.TryMoveNext(out var next) ? next : null;
            if (row is not null) _fieldNames = Rows.AdoptRecord(row);
            return CurrentFieldNames();
        }

        private object CurrentFieldNames()
        {
            _lineNumber.SetInteger(Rows.PhysicalLineCount);
            return _fieldNames;
        }"""
assert t.count(old)==1
p.write_text(t.replace(old,new),encoding='utf-8',newline='\n')
running=(lab.parent/'dictreader-activation-20261123/test-platform.py').read_text(encoding='utf-8')
(lab/'test-platform.py').write_text(running.replace('dictreader-activation-20261123','dictreader-ready-header-20261123'),
  encoding='utf-8',newline='\n')
