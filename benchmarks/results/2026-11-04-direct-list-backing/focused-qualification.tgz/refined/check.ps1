$ErrorActionPreference = 'Stop'
$env:DOTNET_ROOT = 'C:/Users/JoannesVermorel/.dotnet11'
$dotnetCommand = "$env:DOTNET_ROOT/dotnet.exe"
$evidenceDirectory = 'D:/code/Lython/.git/agent-notes/review-20261031/list-backing-b203/refinement'
& $dotnetCommand build Lokad.Lython.slnx -c Release --no-incremental *> "$evidenceDirectory/final-build.log"
if ($LASTEXITCODE -ne 0) { Get-Content "$evidenceDirectory/final-build.log" -Tail 35; exit $LASTEXITCODE }
$internalSelection = '(FullyQualifiedName~List|FullyQualifiedName~StorageSubsystem|FullyQualifiedName~PrimitiveStorage|FullyQualifiedName~Slice|FullyQualifiedName~Sort|FullyQualifiedName~BatchedSharedAdmission|FullyQualifiedName~IterationCancellation|FullyQualifiedName~PartialNative|FullyQualifiedName~WhitespaceStorage)&Category!=Stress'
$publicSelection = '(FullyQualifiedName~List|FullyQualifiedName~Sort|FullyQualifiedName~Slice|FullyQualifiedName~GovernedMemory|FullyQualifiedName~AdmissionFailureCommand|FullyQualifiedName~NativeConsumerStreaming|FullyQualifiedName~CollectionDisplayUnpacking|FullyQualifiedName~RepresentativeProtocolCancellation|FullyQualifiedName~Csv|FullyQualifiedName~Json)&Category!=Stress'
foreach ($target in @('net11.0','net10.0')) {
    foreach ($suite in @('internal','public')) {
        $projectFile = if ($suite -eq 'internal') { 'tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj' } else { 'tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj' }
        $selection = if ($suite -eq 'internal') { $internalSelection } else { $publicSelection }
        $recordName = "final-$suite-$target"
        & $dotnetCommand test $projectFile -c Release -f $target --no-build --filter $selection --logger trx --results-directory "$evidenceDirectory/checks/$recordName" *> "$evidenceDirectory/$recordName.log"
        $resultCode = $LASTEXITCODE
        Get-Content "$evidenceDirectory/$recordName.log" -Tail 7
        if ($resultCode -ne 0) { Get-Content "$evidenceDirectory/$recordName.log" -Tail 75; exit $resultCode }
    }
}
