from pathlib import Path
import ast,hashlib,json,shutil,tarfile
parent=Path(__file__).resolve().parent.parent;r=parent/'native-word-boundary-r238';r.mkdir(exist_ok=False)
old=parent/'return-prefix-r227/b572';prior=parent/'native-counter-loops-r237/b577';q=r/'b578';q.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
root='/home/lokad/lython-bench-checks/native-word-profile-b578-20261111';unit='lython-b578-native-word-profile-20261111'
shutil.copyfile(parent/'native-counter-loops-r237/catalog.json',q/'catalog.json')
identity=json.loads((prior/'identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision='R238 source-selection profile on committedfe6648b2/frozenbf93; R237 changes the inner loop. One current captured-text CPU capture, no elapsed source pair or prior-offset transfer.',catalogSHA256=sha(q/'catalog.json'))
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh']:
 text=(old/name).read_text(encoding='utf-8').replace('return-prefix-b572-20261111','native-word-profile-b578-20261111').replace('lython-b572-return-prefix-20261111',unit)
 if name=='ops-profile.py':
  text=text.replace('env["DOTNET_JitDisasm"]="ExecuteInstructionPrefix"','env["DOTNET_JitDisasm"]="TryExecuteDictionaryLoop"')
  text=text.replace("expected['coreSHA256'].lower()","expected['coreSHA256']['candidate'].lower()")
 if name.endswith('.py'):ast.parse(text)
 (q/name).write_text(text,encoding='utf-8',newline='\n')
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for name in ['catalog.json','identity.json','ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh']:t.add(q/name,arcname=name)
with tarfile.open(q/'payload.tgz')as t:expanded=sum(((m.size+4095)//4096)*4096 for m in t.getmembers())
config=dict(root=root,unit=unit,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha(q/'payload.tgz'),requiredFreeBytes=252*1024*1024+expanded+65536,retire=[],identity=identity)
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
text=(prior/'remote-launch.py').read_text(encoding='utf-8')
text=text.replace("digest(root/'representative.json')==config['identity']['catalogSHA256']","digest(root/'catalog.json')==config['identity']['catalogSHA256']")
text=text.replace("for name in ['collect.py','archive-owned.py']","for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py']")
text=text.replace('lython-b577-fixtures','lython-b578-fixtures').replace('jobs=9','sampledSeconds=10').replace('ownerSeconds=330','ownerSeconds=90').replace('RuntimeMaxSec=330','RuntimeMaxSec=90')
ast.parse(text.replace('config=CONFIG','config='+repr(config)).replace('inventoryOnly=INVENTORY_ONLY','inventoryOnly=True'))
(q/'remote-launch.py').write_text(text,encoding='utf-8',newline='\n')
text=(prior/'launch.py').read_text(encoding='utf-8').replace('native-loops-cpython-b577-launch','native-word-profile-b578-launch').replace('seconds=390','seconds=150').replace('ownerSeconds=330','ownerSeconds=90')
(q/'launch.py').write_text(text,encoding='utf-8',newline='\n')
text=(old/'retrieve.py').read_text(encoding='utf-8').replace('return-prefix-b572-20261111','native-word-profile-b578-20261111').replace('lython-b572-return-prefix-20261111',unit)
(q/'retrieve-original.py').write_text(text,encoding='utf-8',newline='\n')
print('Prepared one current-core6sCPU capture,10smaximum/90sowner; no runtime edit, no new core upload or retirement.')
