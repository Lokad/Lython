#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/block-occupancy-20261123
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
export DOTNET_HOST_PATH="$DOTNET_ROOT/dotnet"
python_alias=$(mktemp -d)
trap 'unlink "$python_alias/python"; rmdir "$python_alias"' EXIT
ln -s "$HOME/.local/bin/python3.13" "$python_alias/python"
export PATH="$python_alias:$PATH"
python --version
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/block-occupancy-20261123
white='Category!=Stress&(FullyQualifiedName~Executable|FullyQualifiedName~Annotation|FullyQualifiedName~LocalAugmented)'
public='Category!=Stress&(FullyQualifiedName~Executable|FullyQualifiedName~CompilerCancellation|FullyQualifiedName~GovernedMemoryContract|FullyQualifiedName~Annotation|FullyQualifiedName~ControlFlow|FullyQualifiedName~FString|FullyQualifiedName~Match)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$white" > "$lab/white-ubuntu.log" 2>&1 || { tail -38 "$lab/white-ubuntu.log"; exit 1; }
dotnet build tools/LythonProbe/LythonProbe.csproj -c Release -f net10.0 > "$lab/probe-ubuntu.log" 2>&1 || { tail -38 "$lab/probe-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$public" > "$lab/public-ubuntu.log" 2>&1 || { tail -38 "$lab/public-ubuntu.log"; exit 1; }
awk '/Passed!/{count++;print} END{exit count!=2}' "$lab/white-ubuntu.log" "$lab/public-ubuntu.log"
