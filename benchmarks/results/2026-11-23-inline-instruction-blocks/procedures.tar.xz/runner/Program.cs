using System.Reflection;
using System.Text.Json;
using Lokad.Lython;

var assembly = typeof(LythonEngine).Assembly;
var field = assembly.GetType("Lokad.Lython.Frontend.ExecutableScript", true)!
    .GetField("DiagnosticBlocks", BindingFlags.NonPublic | BindingFlags.Static)!;
var opcode = assembly.GetType("Lokad.Lython.Frontend.ExecutableOpCode", true)!;
using var catalog = JsonDocument.Parse(File.ReadAllBytes(args[0]));
var engine = new LythonEngine();
var budget = new LythonMemoryBudget();
var rows = new List<object>();
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var blocks = new List<(int Count, int Capacity, bool Entry, int SingletonOp)>();
    field.SetValue(null, blocks);
    using (var result = engine.Compile(item.GetProperty("source").GetString()!, budget))
        if (!result.IsValid || result.Diagnostics.Count != 0)
            throw new InvalidOperationException(string.Join("|", result.Diagnostics));
    if (budget.ReservedBytes != 0) throw new InvalidOperationException("Allowance did not refund.");
    rows.Add(new
    {
        id = item.GetProperty("id").GetString(),
        entries = blocks.Count(b => b.Entry),
        blocks = blocks.Count,
        occupied = blocks.Sum(b => b.Count),
        capacity = blocks.Sum(b => b.Capacity),
        width = blocks.GroupBy(b => b.Count).OrderBy(g => g.Key).ToDictionary(g => g.Key, g => g.Count()),
        nonEntrySingletons = blocks.Where(b => !b.Entry && b.Count == 1).GroupBy(b => b.SingletonOp)
            .ToDictionary(g => Enum.GetName(opcode, Enum.ToObject(opcode, g.Key))!, g => g.Count()),
        entry = blocks.Where(b => b.Entry).Select(b => new { b.Count, b.Capacity })
    });
}
File.WriteAllText(args[1], JsonSerializer.Serialize(rows, new JsonSerializerOptions { WriteIndented = true }));
