from pathlib import Path
import hashlib, json, os, shutil, subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
tree = repo / ".git/agent-worktrees/block-occupancy-20261123"
source = tree / "src/Lokad.Lython/Frontend/ExecutableScript.Builder.cs"
known = lab.parent / "abstract-state-snapshots-20261123/comparison"
catalog = known / "representative.json"
files = json.loads((repo / "benchmarks/results/2026-11-23-abstract-state-snapshots/source.json").read_text(encoding="utf-8"))["imageFiles"]["candidate"]
reference = known / "frozen-candidate"
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), DOTNET_HOST_PATH=str(dotnet), PATH=str(sdk) + os.pathsep + os.environ["PATH"])

def run(args, cwd, log=None):
    if log is None:
        subprocess.run(args, cwd=cwd, env=env, timeout=130, check=True)
        return
    with (lab / log).open("w", encoding="utf-8") as output:
        subprocess.run(args, cwd=cwd, env=env, timeout=130, check=True, stdout=output, stderr=subprocess.STDOUT)

def git(*args):
    return subprocess.check_output(["git", *args], cwd=tree)

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

assert not git("status", "--porcelain")
assert {name: sha(reference / name) for name in files} == files
physical = source.read_bytes()
try:
    text = physical.decode("utf-8").replace("\r\n", "\n")
    point = "            // The existing compilation owner funds the immutable function metadata."
    assert text.count(point) == 1
    text = text.replace(point, """            var observed = DiagnosticBlocks;
            if (observed is not null)
                foreach (var block in _buffers.Blocks)
                    observed.Add((block.Count, block.Capacity, ReferenceEquals(block, _buffers.EntryBlock),
                        block.Count == 1 ? (int)block[0].OpCode : -1));

""" + point)
    point = "    public LythonSourceSpan? AnnotationInitializationSpan { get; }"
    text = text.replace(point, """    internal static List<(int, int, bool, int)>? DiagnosticBlocks;

""" + point)
    source.write_text(text, encoding="utf-8", newline="\n")
    (lab / "probe.patch").write_bytes(git("diff", "--binary", "--", "src"))
    run([dotnet, "build", "src/Lokad.Lython/Lokad.Lython.csproj", "-c", "Release", "-f", "net11.0",
         "--no-incremental", "--artifacts-path", lab / "core-build"], tree, "core-build.log")
finally:
    source.write_bytes(physical)
assert not git("status", "--porcelain")
core = "Lokad.Lython.dll"
image = lab / "image"
image.mkdir(exist_ok=True)
for name in files:
    shutil.copyfile(lab / "core-build/bin/Lokad.Lython/release_net11.0" / name if name == core else reference / name,
                    image / name)
actual = {name: sha(image / name) for name in files}
assert [name for name in files if actual[name] != files[name]] == [core]
(lab / "image-hashes.json").write_text(json.dumps(actual, indent=2) + "\n", encoding="utf-8")
project = lab / "runner"
project.mkdir(exist_ok=True)
run([dotnet, "build", project / "BlockProbe.csproj", "-c", "Release", "--no-incremental"], project, "runner-build.log")
for p in (project / "bin/Release/net11.0").glob("BlockProbe.*"):
    shutil.copyfile(p, image / p.name)
run([dotnet, image / "BlockProbe.dll", catalog, lab / "inventory.json"], repo)
assert {name: sha(image / name) for name in files} == actual
