R92 bounded source pair, not a CPython refresh. Exact R89 qualified/current-R90
core6a098198 is the baseline; unchanged worker7cf37ca5/optional0.4/all auxiliary
hashes checked before use. Guarded complete text script sync/async affected;
existing fused text, rsplit, CSV and report controls. All sources/fixtures/output
goldens unchanged from R90. Five-second warmup per process/job, normal GC/tiering,
7x150ms rotated samples, two old/two candidate processes, coarse process CPU.
210s owned unit plus30sstop/30smargin; raw logs/archives on persistent root,128MiB
owned RAM contains only guest fixtures. All readiness/source/runtime/quiet/golden/
Closed/join/unmount/archive/local verification gates must pass. Original failures
and adverse measurements stay evidence. No fixed-percentage veto; distinguish
architecture, allocation and controlled elapsed/CPU. No runtime claim before gates.
Space: bounded atomic hardlink consolidation of exact-byte duplicate old cores
preserved every path/content and all archives, freed27,848,704B; proof included.
No evidence was deleted; no permission for future deletion inferred.
