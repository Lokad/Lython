from pathlib import Path
import ast,json,shutil,tarfile
r=Path(__file__).parent;old=r.parent/'native-method-facts-r89/b451';b=r/'b453';b.mkdir()
source=json.loads((r/'identity.json').read_text())
previous=json.loads((old/'identity.json').read_text())
identity={**previous,'sourceRevision':source['candidateSource'],'baselineSource':source['baselineSource'],
 'coreSHA256':{role:source['coreSHA256']['before'if role.startswith('reference')else'candidate']for role in ['reference','reference-control','candidate','candidate-control']},
 'productionSources':source['productionSources'],'qualification':'Focused 3859 public11 plus 128 public semantic and 24 internal ownership on actual11/10; full delivery pending.'}
(b/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
for name in ['collect.py','run.sh','retrieve.py','assess-vm.py','archive-owned.py','launch.py']:
 s=(old/name).read_text(encoding='utf-8').replace('direct-native-fusion-b451-20261108','shared-cased-split-b453-20261108').replace('lython-b451-direct-native-fusion','lython-b453-shared-cased-split').replace('direct-native-fusion-b451-launch.py','shared-cased-split-b453-launch.py')
 if name=='collect.py':
  a=s.index('jobs=[');z=s.index('\n',a)
  s=s[:a]+"jobs="+repr([['scripts.text-summary-guarded-helpers.large','warm'],['scripts.text-summary-guarded-helpers.large','warm-async'],['scripts.text-summary-helpers.large','warm'],['scripts.text-summary-rsplit-helpers.large','warm'],['scripts.csv-summary-functions.large','warm'],['scripts.report-render.large','warm-async']])+s[z:]
  s=s.replace('R89 direct existing-fusion plan removes dead producer/proof/empty arguments after B450 fused-control concern; rsplit/casefold affected, fused/CSV/report controls unchanged','R92 one shared existing casing-split recipe for ordinary/native execution; guarded text affected, fused/rsplit/CSV/report unchanged controls')
 if name=='launch.py':s=s.replace("reference=base/'native-method-facts-b450-20261108/reference'","reference=base/'direct-native-fusion-b451-20261108/candidate'")
 if name=='archive-owned.py':s=s.replace("'shared-worker-common.json']","'shared-worker-common.json','new-sources','dedup-proof.json']")
 (b/name).write_text(s,encoding='utf-8',newline='\n')
 if name.endswith('.py'):ast.parse(s)
for src,name in [(r/'images/candidate/Lokad.Lython.dll','current-core.dll'),(r/'catalog.json','representative.json'),(r/'identity.json','focused.json'),(r/'source.patch','source.patch'),(r/'pre-measurement-plan.md','pre-measurement-plan.md'),(old/'shared-worker-common.json','shared-worker-common.json'),(old/'setup-contract.json','setup-contract.json'),(r/'dedup-proof.json','dedup-proof.json')]:shutil.copyfile(src,b/name)
shutil.copytree(r/'new-sources',b/'new-sources')
contract='''R92 bounded source pair, not a CPython refresh. Exact R89 qualified/current-R90
core6a098198 is the baseline; unchanged worker7cf37ca5/optional0.4/all auxiliary
hashes checked before use. Guarded complete text script sync/async affected;
existing fused text, rsplit, CSV and report controls. All sources/fixtures/output
goldens unchanged from R90. Five-second warmup per process/job, normal GC/tiering,
7x150ms rotated samples, two old/two candidate processes, coarse process CPU.
210s owned unit plus30sstop/30smargin; raw logs/archives on persistent root,128MiB
owned RAM contains only guest fixtures. All readiness/source/runtime/quiet/golden/
Closed/join/unmount/archive/local verification gates must pass. Original failures
and adverse measurements stay evidence. No fixed-percentage veto; distinguish
architecture, allocation and controlled elapsed/CPU. No runtime claim before gates.
Space: bounded atomic hardlink consolidation of exact-byte duplicate old cores
preserved every path/content and all archives, freed27,848,704B; proof included.
No evidence was deleted; no permission for future deletion inferred.
'''
(b/'contract.md').write_text(contract,encoding='utf-8')
with tarfile.open(b/'payload.tgz','w:gz')as a:
 for n in ['collect.py','run.sh','current-core.dll','representative.json','identity.json','pre-measurement-plan.md','setup-contract.json','contract.md','focused.json','source.patch','shared-worker-common.json','archive-owned.py','new-sources','dedup-proof.json']:a.add(b/n,arcname=n)
print('B453 exact source/core and six bounded jobs prepared; existing qualified baseline reused.')
