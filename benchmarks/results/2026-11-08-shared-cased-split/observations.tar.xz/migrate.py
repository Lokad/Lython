from pathlib import Path
root=Path('D:/code/Lython')
def update(name, before, after):
    p=root/name
    s=p.read_text(encoding='utf-8')
    assert before in s, name
    p.write_text(s.replace(before,after),encoding='utf-8',newline='\r\n')
p=root/'src/Lokad.Lython/Frontend/ExecutableScript.NativeReturns.cs'
s=p.read_text(encoding='utf-8').replace('int exceptionRegionCount)', 'int exceptionRegionCount, ExecutableCallSite[] sites)')
start=s.index('                                if (producer.SourceInstruction == producer.Second + 1)')
end=s.index('\n                            }',start)
s=s[:start]+'''                                if (producer.SourceInstruction == producer.Second + 1
                                    && PrepareCasedSplit(instructions, producer.SourceInstruction, index, sites) is not null)
                                {
                                    operation = NativeReturnOperation.CasedSplit;
                                    first = producer.First;
                                    second = -1;
                                    nativeMethod = null;
                                    values.RemoveAt(values.Count - 1);
                                }'''+s[end:]
p.write_text(s,encoding='utf-8',newline='\r\n')
p=root/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeReturn.cs'
s=p.read_text(encoding='utf-8').replace('NativeReturnOperation.SplitLowerWhitespace or NativeReturnOperation.SplitUpperWhitespace','NativeReturnOperation.CasedSplit')
start=s.index('            if (value.Operation is NativeReturnOperation.CasedSplit)')
end=s.index('            if (value.Operation is NativeReturnOperation.Add', start)
s=s[:start]+'''            first = EvaluateNativeReturn(value.First, code, values, arguments, context, entryException);
            if (value.Operation == NativeReturnOperation.CasedSplit)
            {
                try { return ExecuteCasedSplit(code.CallSites[instruction.CallSiteIndex].CasedSplit!, (PyString)first, context); }
                catch (LythonRuntimeException error) { RestoreNativeReturnException(context, entryException, error); throw; }
            }
'''+s[end:]
start=s.index('            if (value.Operation is NativeReturnOperation.CasedSplit)')
end=s.index('            if (value.Operation == NativeReturnOperation.BuiltinUnary)',start)
s=s[:start]+s[end:]
p.write_text(s,encoding='utf-8',newline='\r\n')
