from pathlib import Path
import hashlib,json,re,shutil,subprocess,tarfile
r=Path(__file__).parent;b=r/'b453';target=Path('benchmarks/results/2026-11-08-shared-cased-split');target.mkdir(exist_ok=True)
identity=json.loads((r/'identity.json').read_text())
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['productionSources'].items())
checks={}
for name,expected in [('public-focused11',3859),('public-final11',128),('public-final10',128),('internal-initial11',24),('internal-focused10',24)]:
 s=(r/(name+'.log')).read_text(encoding='utf-8');assert 'Failed:     0'in s and re.search(r'Passed:\s+'+str(expected)+r'\b',s)
 checks[name]=expected
vm=json.loads((b/'assessment.json').read_text());receipt=json.loads((b/'archive-receipt.json').read_text())
assert vm['complete']and receipt['complete']and len(vm['jobs'])==6
assert hashlib.sha256((b/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
raw=json.loads((b/'retrieved/confirmation/confirmation.json').read_text())
runtime=[]
for j in raw['jobs']:
 assert j['workersJoinedAndFixturesRemoved']
 for role,d in j['identities'].items():
  # Preserve complete Ready identities; inspect exact runtime without guessing
  # producer metadata field names or relying on nominal target frameworks.
  runtime.append(dict(case=j['case'],lane=j['lane'],role=role,identity=d))
(r/'runtime-ready-identities.json').write_text(json.dumps(runtime,indent=2)+'\n',encoding='utf-8')
notes='''Setup/analysis corrections, retained rather than erased:
- Initial expanded read-only space inventory had an indentation error before any
  remote work; corrected script ran under idle lease. Exact-byte core hardlinks
  preserved eight paths/all contents and all archives, freed27,848,704B; proof included.
- First frontend assessment divided zero execution-only ticks in compile phase;
  corrected analysis uses original whole-batch elapsedMilliseconds, no retiming.
  Fresh includes compilation plus complete execution/validation/cleanup; execution
  PhaseTicks exclude compilation and are not a compile-to-result clock.
- An early local retrieval guard at09:26:23 refused before its09:26:24.420 bound;
  no VM status query occurred. Subsequent one terminal retrieval succeeded; never
  requery. Dependent analysis before retrieval lacked its file, then ran on the
  successfully retrieved immutable archive. No failed runtime/measurement erased.
- Desktop guarded async elapsed+68.76to82.65% is adverse, not an accepted CPU claim.
  Original role controls drift. B453 controlled result has opposite direction;
  no complete causal explanation of desktop anomaly. All raw data retained.
'''
(r/'setup-analysis-notes.txt').write_text(notes,encoding='utf-8')
with tarfile.open(target/'observations.tar.xz','w:xz',preset=6)as a:
 for p in sorted(r.iterdir()):
  if p.name in {'images','b453'}:continue
  a.add(p,arcname=p.name)
 for n in ['observations.tgz','archive-receipt.json','terminal-status.json','assessment.json','launch.log','observe-not-before.json','launch.py','collect.py','archive-owned.py','contract.md']:
  a.add(b/n,arcname='b453/'+n)
for src,name in [(r/'assessment-local.json','allocation-and-local.json'),(r/'assessment-frontend.json','frontend-diagnostic.json'),(b/'assessment.json','controlled-comparison.json'),(r/'identity.json','identity.json')]:shutil.copyfile(src,target/name)
status=dict(status='Retained source selected, focused checks pass; full delivery pending',coreSHA256=identity['coreSHA256'],focusedChecks=checks,controlledSeconds=vm['ownedSeconds'],allSixJobGatesPassed=True,vmArchiveSHA256=receipt['archiveSHA256'],localArchiveSHA256=hashlib.sha256((target/'observations.tar.xz').read_bytes()).hexdigest(),noRemainingVMUsersOrFixtures=True)
(target/'status.json').write_text(json.dumps(status,indent=2)+'\n',encoding='utf-8')
print('All original local/VM/source/setup evidence archived;', (target/'observations.tar.xz').stat().st_size,'bytes. Full delivery pending.')
