from pathlib import Path
import json,shlex,subprocess
r=Path(__file__).parent
remote='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks')
names=[p.name for p in base.iterdir() if p.is_dir() and not p.is_symlink()]
with(base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]ollector.dll|[p]erf record'],capture_output=True).returncode==1
 groups={}
 for n in names:
  root=base/n
  for p in list(root.glob('*core.dll'))+list(root.glob('*/Lokad.Lython.dll')):
   stat=p.stat();digest=hashlib.sha256(p.read_bytes()).hexdigest()
   groups.setdefault(digest,[]).append(dict(path=str(p),inode=stat.st_ino,bytes=stat.st_size,links=stat.st_nlink))
 print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,groups=groups),indent=2))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -c '+shlex.quote(remote)],capture_output=True)
(r/'space-inventory.json').write_bytes(done.stdout)
assert done.returncode==0,done.stderr
d=json.loads(done.stdout)
print('freeBytes',d['freeBytes'])
for digest,rows in d['groups'].items():
 inodes={row['inode'] for row in rows}
 if len(inodes)>1:
  print(digest[:12],len(rows),'paths',len(inodes),'inodes',sum({row['inode']:row['bytes']for row in rows}.values()))
