from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).parent;old=r.parent/'native-method-facts-r89/direct-fusion'
for role in ['before','candidate']:shutil.copytree(old/'images/candidate',r/'images'/role,copy_function=os.link)
core=r/'images/candidate/Lokad.Lython.dll';core.unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',core)
d=json.loads((r.parent/'native-cpython-r90/representative.json').read_text(encoding='utf-8'))
ids=['scripts.text-summary-guarded-helpers.large','scripts.text-summary-helpers.large','scripts.text-summary-rsplit-helpers.large','scripts.csv-summary-functions.large','scripts.report-render.large']
assert set(ids)<=set(c['id']for c in d['cases'])
d['cases']=[next(c for c in d['cases']if c['id']==i)for i in ids]
(r/'catalog.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
inventory={str(f).replace('\\','/'):hashlib.sha256(f.read_bytes()).hexdigest()for f in Path('src/Lokad.Lython').rglob('*')if f.is_file()and not {'bin','obj'}&set(f.parts)}
identity=dict(baselineSource='ac5aea97 fully qualified CI42463155006, current R90 CPython checkpoint',candidateSource='bd18ea0f plus R92 shared existing cased-split preparation',coreSHA256={role:hashlib.sha256((r/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']},productionSources=inventory,baselineProductionSources=json.loads((old/'identity.json').read_text())['productionSources'])
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython','tests/Lokad.Lython.PublicApi.Tests/CasedWhitespacePipelineTests.cs']))
for name in ['src/Lokad.Lython/Frontend/ExecutableScript.CasedSplits.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.CasedSplits.cs','tests/Lokad.Lython.Tests/CasedSplitOwnershipTests.cs']:
 p=r/'new-sources'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(name,p)
shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
for name in ['measure.py','assess-local.py']:shutil.copyfile(old/name,r/name)
print(json.dumps(identity['coreSHA256']))
