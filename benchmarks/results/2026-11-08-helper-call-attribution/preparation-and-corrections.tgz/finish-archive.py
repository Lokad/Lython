from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).parent
status=json.loads((r/'terminal-status.json').read_text(encoding='utf8'))
assert status['exitCode']=='1'and not status['remainingWorkers']and not status['remainingTrace']
original=(r/'archive.py').read_text(encoding='utf8')
corrected=original.replace(" assert len(record['redundantTemporaryMapsRetiredAfterJoin'])==2\n assert (p/'perf.map').stat().st_size>0 and (p/'perfinfo.map').stat().st_size>0",
 " assert record['redundantTemporaryMapsRetiredAfterJoin']\n assert (p/'perf.map').stat().st_size>0\n for temporary in record['redundantTemporaryMapsRetiredAfterJoin']:assert not Path(temporary).exists()")
assert corrected!=original
corrected=corrected.replace('performanceQualified=False)',"performanceQualified=False,originalOwnerExitCode=1,archiveCorrection='Removed unsupported assumption that CLR always produces perfinfo.map; actual perf.map copied/hash-verified after join, original failure preserved, no remeasurement')")
(r/'archive-corrected.py').write_text(corrected,encoding='utf8')
remote="""from pathlib import Path
import fcntl,subprocess
base=Path('/home/lokad/lython-bench-checks');root=base/'helper-cost-b482-20261108'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not Path('/dev/shm/lython-b482').exists()
 assert (root/'exit-code.txt').read_text().strip()=='1' and not(root/'archive-receipt.json').exists()
 source=SOURCE
 (root/'archive-corrected.py').write_text(source)
 exec(compile(source,str(root/'archive-corrected.py'),'exec'))
""".replace('SOURCE',repr(corrected))
(r/'finish-archive-command.py').write_text(remote,encoding='utf8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=remote.encode(),capture_output=True)
(r/'archive-correction.stdout').write_bytes(done.stdout);(r/'archive-correction.stderr').write_bytes(done.stderr)
assert done.returncode==0,done.stderr.decode();print(done.stdout.decode())
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for name in ['archive-receipt.json','observations.tgz']:
 done=subprocess.run(scp+['lokad@20.166.121.73:/home/lokad/lython-bench-checks/helper-cost-b482-20261108/'+name,str(r/name)],capture_output=True)
 assert done.returncode==0,done.stderr.decode()
receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf8'))
assert receipt['complete']and receipt['allWorkersJoined']and receipt['archivedAndVerifiedUnderLease']
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
out=r/'retrieved';out.mkdir()
with tarfile.open(r/'observations.tgz')as a:a.extractall(out,filter='data')
print('Both captures verified locally; original owner failure preserved, corrected only archive metadata assumption.')
