from pathlib import Path
import fcntl,json,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks');root=base/'helper-cost-b482-20261108'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not Path('/dev/shm/lython-b482').exists()
 journal=subprocess.run(['journalctl','-u','lython-b482-helper-cost-20261108.service','--no-pager','-n','50','-o','cat'],text=True,capture_output=True)
 records={p.parent.name:json.loads(p.read_text())for p in root.glob('profiles/*/record.json')}
 result=dict(journal=journal.stdout,journalError=journal.stderr,records=records,freeBytes=shutil.disk_usage(base).free,files=[dict(path=str(p.relative_to(root)),bytes=p.stat().st_size)for p in root.glob('profiles/*/*')if p.is_file()])
 (root/'initial-archive-failure.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
