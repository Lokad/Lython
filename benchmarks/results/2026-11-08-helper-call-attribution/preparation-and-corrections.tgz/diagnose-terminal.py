from pathlib import Path
import json,subprocess
r=Path(__file__).parent
status=json.loads((r/'terminal-status.json').read_text(encoding='utf8'))
assert status['exitCode']=='1'and not status['remainingWorkers']and not status['remainingTrace']
script='''from pathlib import Path
import fcntl,json,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks');root=base/'helper-cost-b482-20261108'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not Path('/dev/shm/lython-b482').exists()
 journal=subprocess.run(['journalctl','-u','lython-b482-helper-cost-20261108.service','--no-pager','-n','50','-o','cat'],text=True,capture_output=True)
 records={p.parent.name:json.loads(p.read_text())for p in root.glob('profiles/*/record.json')}
 result=dict(journal=journal.stdout,journalError=journal.stderr,records=records,freeBytes=shutil.disk_usage(base).free,files=[dict(path=str(p.relative_to(root)),bytes=p.stat().st_size)for p in root.glob('profiles/*/*')if p.is_file()])
 (root/'initial-archive-failure.json').write_text(json.dumps(result,indent=2)+'\\n');print(json.dumps(result))
'''
(r/'diagnose-command.py').write_text(script,encoding='utf8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=script.encode(),capture_output=True);assert done.returncode==0,done.stderr.decode()
result=json.loads(done.stdout);(r/'initial-archive-failure.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(result['journal']);print('Free bytes',result['freeBytes'])
for n,record in result['records'].items():print(n,'exit',record['exitCode'],'closed',record.get('closed',{}).get('status'),'maps',record['redundantTemporaryMapsRetiredAfterJoin'])
