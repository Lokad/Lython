from pathlib import Path
import ast,hashlib,json,shutil,tarfile
r=Path(__file__).parent;old=r.parent/'text-cost-r116';current=r.parent/'function-cpython-r122'
i=json.loads((current/'identity.json').read_text(encoding='utf8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in i['productionSources'].items())
identity={**i,'files':{'Lokad.Lython.dll':i['coreSHA256']['candidate']},
 'purpose':'Current complete CSV validation/helper versus equivalent inline CPU attribution; no normal elapsed claim.'}
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf8')
catalog=json.loads((r.parent/'function-lookup-lifetime-r121/b480/representative.json').read_text(encoding='utf8'))
catalog['cases']=[c for c in catalog['cases'] if c['id'] in ['scripts.csv-validated-records.large','scripts.csv-validated-records-inline.large']]
assert len(catalog['cases'])==2
(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
for n in ['core-source.json','source.patch']:shutil.copyfile(current/n,r/n)
shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
contract='''R123 bounded attribution before another call/frame redesign. Existing B480 helper versus independently CPython-verified inline complete CSV validation differs ~5.1 versus3.3ms; this includes useful calls/tuple work, not pure call overhead. Current6f76/corec617, no production edits, exact production inventory, existing frozen7cf/optional0.4. Exact tuple unpack already borrows immutable items, locals borrow funded binding workspace; no absent scratch/frame-array phase to delete. Assess actual keyword binding, prefix/operand/check/tuple construction and useful CSV work. Source gate about20min; choose a coherent complete work/storage deletion only if demonstrated/testable, otherwise preserve uncertainty and pursue independent work. No slower call-arena/control/carrier revival or second evaluator/formatter.
Reuse existing perf CPU-clock/fp199Hz, six-second guest warmup, two-second settle, six-second wall capture per existing helper/inline script, 64completeinvocations/request. Two captures need a bounded16s total guest-clock guard (old one-case8s remains preserved),180sowner+30stop+30margin. Diagnostic PerfMap/JIT, not normal elapsed evidence or CPython ratios. Both fullgoldens/Ready/core/aux/balances/quiet/Closed/exit/join/mapcopyhash/ownedRAMunmount/archive/local gates; include live finite owner. Persistent evidence separate from128MiBownedRAMfixtures/temporary maps; archives reused, no core upload/new framework/dedup/evidence deletion. OS240MiB plus12MiBtrace/archive plus rounded actualpayload guard. Stop at usable source-linked attribution; no open-ended campaign. Full delivery independently active, publication postponed, regex independent.
'''
for n in ['selection.md','contract.md']:(r/n).write_text(contract,encoding='utf8')
for n in ['ops-profile.py','analyze-cpu-guest.py','retrieve.py','run.sh','launch.py']:
 s=(old/n).read_text(encoding='utf8')
 for a,b in [('current-text-profile-b476-20261108','helper-cost-b482-20261108'),('lython-b476-current-text-profile','lython-b482-helper-cost'),('current-text-profile-b476-launch.py','helper-cost-b482-launch.py'),('lython-b476','lython-b482')]:s=s.replace(a,b)
 if n=='ops-profile.py':
  s=s.replace('("text-warm", "scripts.text-summary-helpers.large", "warm"),','("helper-warm", "scripts.csv-validated-records.large", "warm"),\n        ("inline-warm", "scripts.csv-validated-records-inline.large", "warm"),')
  s=s.replace('if total_capture_seconds > 8:', 'if total_capture_seconds > 16:')
  s=s.replace('ExecuteInstructionPrefix GuardNativeReturn TryGetNativeBinaryShape','ExecuteInstructionPrefix BeginBoundCall BindCallOperands CreateTupleFromStack')
 if n=='launch.py':
  s=s.replace("source=(base/'primitive-proof-b475-20261108/candidate').resolve()","source=(base/'function-lookups-b479-20261108/candidate').resolve()")
  s=s.replace('(240+8)*1024*1024','(240+12)*1024*1024').replace('ownerSeconds=120','ownerSeconds=180').replace('traceArchiveHeadroomMiB=8','traceArchiveHeadroomMiB=12').replace('RuntimeMaxSec=120','RuntimeMaxSec=180').replace('seconds=180','seconds=240')
 if n=='run.sh':
  s=s.replace('for case in text-warm;', 'for case in helper-warm inline-warm;')
  s=s.replace('sudo -n chown lokad:lokad "$root/profiles/text-warm/perf.data"','for case in helper-warm inline-warm; do\n sudo -n chown lokad:lokad "$root/profiles/$case/perf.data"\ndone')
 if n=='retrieve.py':s=s.replace("['capturedSeconds']<8","['capturedSeconds']<16")
 (r/n).write_text(s,encoding='utf8',newline='\n')
 if n.endswith('.py'):ast.parse(s)
sizing=dict(osFloorBytes=240*1024*1024,evidenceHeadroomBytes=12*1024*1024,
 priorSingleCaptureArchiveBytes=(old/'observations.tgz').stat().st_size,
 twoCaptureHeadroom='Existing trace/map archive <1MiB; 12MiB retained for two captures/raw+archive; no new binary payload',
 ownerSeconds=180,stopSeconds=30,marginSeconds=30)
(r/'sizing.json').write_text(json.dumps(sizing,indent=2)+'\n',encoding='utf8')
with tarfile.open(r/'payload.tgz','w:gz')as a:
 for n in ['ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','catalog.json','identity.json','source.patch','contract.md','selection.md','sizing.json','core-source.json','pre-measurement-plan.md']:a.add(r/n,arcname=n)
with Path('PLAN.md').open('a',encoding='utf8')as f:f.write('\nR123 active attribution gate: two existing helper/inline six-second CPU captures at\n6f76/corec617. No runtime prototype, no normal elapsed claim.180s finite owner,\nfull quiet/source/semantic/ownership/archive checks. Source-linked decision follows;\nnot another universal call-cost assumption or new benchmark framework.\n')
print('R123 prepared: existing helper/inline CPU attribution only, no runtime edit.')
