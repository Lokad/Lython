from pathlib import Path
import contextlib,io,json
r=Path(__file__).parent
base=(r.parent/'scalar-cost-r111/profile-corrected/attribute.py').read_text(encoding='utf8')
for name in ['helper-warm','inline-warm']:
 s=base.replace("folder=r/'retrieved/profiles/integer-warm'", "folder=r/'retrieved/profiles/"+name+"'")
 at=s.index('counts={tag:')
 s=s[:at]+'''patterns.update(
 bindingAndWorkspace=lambda n:'[Lokad.Lython]'in n and any(t in n for t in ['BindInto','BindFunctionArguments','BindPositionalFunctionArguments','RentFunctionArgumentStorage','FunctionWorkspace','ReturnBoundArguments','ArgumentPresence::']),
 nativeCalls=lambda n:'[Lokad.Lython]'in n and any(t in n for t in ['TryExecuteNativeCall','SelectNativeUnaryOperation','InvokeSingleInput']),
 framePreparation=lambda n:'[Lokad.Lython]'in n and any(t in n for t in ['BeginBoundCall','BeginPendingCall','CreateExecutableWorkState','AdoptExecutableExecution','EnterInvocationFrame']),
 tupleConstruction=lambda n:'[Lokad.Lython]'in n and any(t in n for t in ['CreateTupleFromStack','CreateTuple','PyTuple::']),
 csvConstruction=lambda n:'[Lokad.Lython]'in n and any(t in n for t in ['CsvReader','DictReader','ReadCsv','CsvRecord']),
 inputHandling=lambda n:'ExecuteInputInstruction'in n,
 comparisons=lambda n:'[Lokad.Lython]'in n and any(t in n for t in ['ExecuteComparisonInstruction','EvaluateComparison','TryEvaluateNumericComparison']),
 io=lambda n:'[Lokad.Lython]'in n and any(t in n for t in ['TextFileHandle','ReadLine','ScanLine','ComparisonFileHost']),
 monitor=lambda n:'Monitor::'in n,
 hash=lambda n:any(t in n for t in ['HashUtf8','PyString::GetHashCode','ComputeStructuralHashCode']))
# Method heads prevent names found only in argument type lists from matching.
patterns={tag:(lambda n,test=test:test(n.split('(',1)[0]+'('))for tag,test in patterns.items()}
'''+s[at:]
 s=s.replace("sourceRevision='05790317'", "sourceRevision='6f76f99d'")
 s=s.replace("(r/'attribution.json')", "(r/'attribution-"+name+".json')")
 with contextlib.redirect_stdout(io.StringIO()):data={'__file__':str(r/'attribute.py')};exec(compile(s,str(r/'attribute.py'),'exec'),data)
 d=data['out'];record=data['record']
 d['completedInvocations']=record['response']['completedInvocations']
 d['diagnosticGuestCpuMillisecondsPerInvocation']=1000*d['guestCpuSeconds']/d['completedInvocations']
 (r/('attribution-'+name+'.json')).write_text(json.dumps(d,indent=2)+'\n',encoding='utf8')
 print(name,'samples',d['guestSamples'],'CPU',d['guestCpuSeconds'],'unknown',d['unknownLeaf'],'invocations',d['completedInvocations'])
 for tag,c in d['groups'].items():print(tag,'leaf',c['leaf'],'inclusive',c['inclusive'])
 for row in d['topLeaves'][:14]:print(str(row)[:210])
