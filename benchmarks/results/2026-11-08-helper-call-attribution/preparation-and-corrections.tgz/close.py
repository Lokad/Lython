from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;root=Path('D:/code/Lython')
i=json.loads((r/'identity.json').read_text(encoding='utf8'));receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf8'))
assert receipt['complete']and receipt['allWorkersJoined']and receipt['guestFixturesRemoved']and receipt['quietBeforeAndAfter']
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in i['productionSources'].items())
source='''# Current helper execution source gate

R123/B482, 2026-11-08, current6f76/corec617. Existing normal B480 complete CSV
validation/helper versus independently CPython-verified inline control is roughly
5.1 versus3.3ms. The gap includes real calls, extra bindings, returned tuple creation,
unpacking and useful dispatch; it is not a measurement of pure call overhead.

Compile-only exact-core census finds validated_record has13instructions,3lookup
slots,3locals,no exceptions,mirroring or native body. Its exact native CSV data can
run wholly in the canonical borrowed prefix: int, immutable-layout field reads,
numeric/string comparisons and final tuple construction. No per-call context object
or local-array allocation is needed. Tuple construction transfers its private final
array; exact tuple unpack already borrows that immutable array in both APIs. CSV
record construction already adopts parser arrays. Those hypothesized copy phases
do not exist and cannot justify another collector, arena or tuple transport route.

Two existing six-second CPU captures, not normal elapsed evidence: helper1208leaf
samples/6.08guestCPU/57unknown4.72%, inline1174/5.90CPU/69unknown5.88%. Actual function
context construction has0leaf in both. Helper binding/workspace60leaf4.97%, frame
preparation50leaf4.14%, tuple construction12leaf0.99%; groups overlap. Prefix169leaf
13.99% versus13511.50% mixes checks/control/useful work. Inclusive frame501samples
includes nested prefix work, not a removable42% tax. No inference of zero cost from
inlined0leaf categories. New type-proof or universal value/stack rewrite is unjustified.

Source shows generic named-argument binding still reconstructs CallArgumentValue
views and resolves static keyword names against the immutable parameter layout on
every call. Positional-only binding is a separate loop. Both own the same admitted
workspace and return a BoundCallArguments descriptor whose presence remains useful
for protocol defaults and builtin consumers. Deleting presence globally or deriving
the storage owner from a guessed closure would break real contracts. A new narrower
carrier would repeat the slower earlier call-control direction.

**No runtime prototype selected from these samples.** A coherent next candidate is
consolidation of ordinary fixed-shape argument-to-local binding: prepare static
keyword-to-parameter positions when immutable layout identity permits, reuse the
existing lookup lifetime, keep current defaults live, and share ordinary positional/
keyword local initialization. Remove repeated wrappers/name resolution and displaced
duplicate binding logic; preserve the general protocol/expanded call binder.
This remains a source-gated candidate, not an assumed gain or automatic promotion.
If it needs a new cache owner, dispatch framework, ledger or duplicate binder,
reject that form and record why. Bounded before/after must include complete primary
validatedCSV/report, ordinary native CSV/text controls, compilation/allocation and
two unchanged process controls; actual suspension/refusal/recursion/default mutation/
evaluation order/retained aliases/budget reuse are semantic gates.

This closes the attribution question, not the performance objective. No further
capture without new source-specific uncertainty. Keep regex independent. All original
failed collection/archive conditions survive; no remeasurement or percentage veto.
'''
(r/'source-gate.md').write_text(source,encoding='utf8')
decision=dict(status='Attribution complete; no runtime prototype selected. Continue source-gated coherent call binding consolidation.',
 sourceRevision='6f76f99d',coreSHA256=i['files']['Lokad.Lython.dll'],
 normalElapsedEvidence='Existing B480 unchanged helper/inline; captures diagnostic only.',
 hypothesis='Repeated static keyword resolution and wrapper construction can move to admitted immutable-layout preparation while consolidating existing ordinary binding.',
 noAutomaticPromotion=True,noNewOwnershipOrExecutionFramework=True,
 originalOwnerExitCode=1,correction='Actual captures/output/cleanup pass; unsupported two-map archive assertion corrected under fresh idle lease without rerun.',
 initialSpaceRefusal='Before root creation or workers. Targeted permitted-canonical exact-byte hardlinks recover5537792bytes;17paths/hashes preserved; initial symlink refusal corrected before mutation.',
 next='R124 source gate about20min then prototype only if actual duplicate work/semantic proof is coherent; otherwise pursue independent track, not another profile campaign.')
(r/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf8')
out=root/'benchmarks/results/2026-11-08-helper-call-attribution';out.mkdir()
for n in ['identity.json','archive-receipt.json','attribution-helper-warm.json','attribution-inline-warm.json','census.json','source-gate.md','decision.json','dedup-proof.json','space-post-audit.json','observations.tgz']:shutil.copy2(r/n,out/n)
with tarfile.open(out/'preparation-and-corrections.tgz','w:gz')as a:
 for p in sorted(r.iterdir()):
  if p.is_file()and p.suffix!='.tgz':a.add(p,arcname=p.name)
(out/'README.md').write_text('''# Complete CSV helper versus inline CPU attribution

2026-11-08, R123/B482, runtime6f76/corec617. Same maintained5120record/68625B CSV
validation script and B480 independently verified inline equivalent, frozen7cf /
optional0.4. Quiet F4as_v7/Ubuntu24.04.4/.NET11RC3, normal GC/tiering, six-second
guest warmup/two-second settle/six-second CPU-clock/fp199Hz capture per script.
PerfMap/JIT diagnostics, not normal elapsed or external-baseline measurements.

| Complete script | Guest samples / CPU | Unknown leaves | Binding/workspace leaf | Frame preparation leaf | Context construction leaf |
| --- | ---: | ---: | ---: | ---: | ---: |
| CSV helper |1208 /6.08s|57 /4.72%|60 /4.97%|50 /4.14%|0|
| Equivalent inline |1174 /5.90s|69 /5.88%|0|0|0|

Groups overlap and include inlined work. Inclusive frame samples include useful
execution. Neither these shares nor the existing normal~5.1vs3.3ms gap establishes
a removable call tax. Exact tuples already borrow immutable unpack storage;
ordinary helper locals already borrow funded binding storage. Current helper uses
13canonical instructions/no exception regions and no context construction.

**No runtime prototype selected.** [Source gate](source-gate.md) records the next
coherent fixed-shape argument binding candidate, displaced work, semantic criteria
and bounded before/after controls. General protocols/default mutations, suspension,
cancellation, refusal, retained aliases and existing funding remain essential.
No new owner/arena/control carrier/evaluator/framework or speculative copy removal.

Both captures pass Ready/core/auxiliary/fullgoldens/balances/quiet/Closed/exit/join/
map-copy-hash/ownedRAM-unmount gates. Original180s owner exited1 only after cleanup:
the archive checker wrongly assumed CLR emits perfinfo.map as well as perf.map.
It emitted only perf.map, copied and hash-verified after each worker joined.
Corrected that metadata assertion under a fresh idle lease; preserved the original
failure, logs and owner exit. Same observations archived and independently verified
locally, no rerun. No workers or RAM fixtures remain. Total guest-clock12.067s.

Initial space admission refused before root/worker creation. A targeted exact-byte
hardlink operation used a fresh idle lease, permitted canonical ownership, writable
parents, all-displaced-inode aliases, SHA verification and persisted pre-mutation
plan. Recovered5537792B without losing paths/bytes; later audit verifies all17
original aliases and no temporary links. The first overly restrictive symlink
preflight refusal and correction are retained; no mutation occurred on that refusal.

[Helper attribution](attribution-helper-warm.json), [inline attribution](attribution-inline-warm.json),
[exact-core census](census.json), [decision](decision.json), [identity](identity.json),
[receipt](archive-receipt.json), [raw maps/stacks/disassembly/records](observations.tgz),
[all preparation and failures](preparation-and-corrections.tgz),
[dedup proof](dedup-proof.json), [post-audit and pre-mutation plan](space-post-audit.json).
Performance objective and independent regex track remain active; publication postponed.
''',encoding='utf8')
with(root/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf8')as f:f.write('''

## Complete helper/inline call attribution (2026-11-08)

[R123/B482](results/2026-11-08-helper-call-attribution/README.md),6f76/corec617,
two existing six-second CPU captures/helper1208samples6.08CPU57unknown4.72%,
inline1174/5.90/69unknown5.88%. Helper binding/workspace4.97%leaf, preparation4.14%,
tuple0.99%, context0; inclusive frame42% contains useful prefix work. Exacttuple
unpack and bound locals already borrow existing funded storage, CSV adoptsarrays.
No prototype or universal call-tax claim. Next source-gated ordinary fixed-shape
binding consolidation, not carrier/arena/evaluator/owner expansion. Originalspace
and symlink preflight refusals preserved; permitted-canonical5537792B exact-byte
recovery/post-audit17aliases pass. Owner exited1 aftercleanup for unsupported
two-map archive assumption; corrected metadata underfreshidlelease/no rerun,
samecaptures archived locallyverified. Full source qualification independent;
performance objective and regex active, no publication.
''')
p=root/'PLAN.md';plan=p.read_text(encoding='utf8');plan=plan[:plan.index('\nR123 active attribution gate:')]
plan=plan.replace('R123 source gate should assess remaining mandatory context transitions\n     and complete helper execution, against B480 helper versus inline evidence\n     (~5.1ms versus3.3ms, includes useful calls/tuple work, not pure call overhead).',
 'R123 attribution completed: binding/workspace4.97%leaf, preparation4.14%,\n     context0; inclusive frame samples contain useful work. Exact13instruction\n     helper runs borrowed prefix. Existing B480~5.1vs3.3ms includes tuple/useful\n     work, not pure call overhead. No new arena/carrier/prototype from samples.')
plan+='''
R123/B482 closed: same source, both captures/output/cleanup/map/archive/local gates
pass. Original ownerexit1 aftercleanup/two-map archive assumption preserved; corrected
only metadata underfreshidlelease/no rerun. Initialspace refusal and symlink assumption
preserved; permitted-canonical exact-byte5537792B recovery, post-audit17aliases pass.
No VM users/fixtures. Never requery B482. Source gate/evidence linked in history.

Next R124 candidate: consolidate ordinary fixed-shape argument-to-local binding.
Hypothesis: static keyword positions can be prepared for immutable parameter-layout
identity, removing repeated CallArgumentValue views/name resolution and sharing
positional/keyword local initialization. Keep defaults live and generic expanded/
protocol binder; reuse existing admitted lookup lifetime, no new owner/framework.
Source gate about20min before prototype; reject a form adding a duplicate binder,
carrier or ownership system. Acceptance: rebinding/default mutation/duplicates/
positional-only/receivers/recursion/actual suspension/evaluation order/cancellation/
refusal/funded aliases/budget reuse. Bound normal before/after primary validatedCSV/
report plus nativeCSV/text controls, compiler/allocation costs and two unchanged
process controls. Preserve regressions and decide completion debt explicitly.
'''
p.write_text(plan,encoding='utf8')
print('R123 evidence and source decision preserved. Continue R124 source gate; no performance-objective completion.')
