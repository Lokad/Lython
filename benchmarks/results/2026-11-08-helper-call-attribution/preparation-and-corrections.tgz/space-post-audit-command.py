from pathlib import Path
import fcntl,hashlib,json,os,stat,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve();groups={'4c64ac3c8f928db96c24a04f953d153f68ef73e7cb9f79fdd35592bff873aa5c': ['/home/lokad/lython-bench-checks/frame-transfer-8366e832-20261013/before/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/call-transfer-09aeae83-20261013/before/Lokad.Lython.dll'], 'cb0030174b3e11db90fd16136175582e88a3cd74512771746814c265fcb53957': ['/home/lokad/lython-bench-checks/file-search-b79-20261102/worker/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/compile-native-b86-20261102/wrapper/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/cfg-b81-20261102/baseline/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/frontend-b80-20261102/wrapper/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/frontend-b80-20261102/worker/Lokad.Lython.dll'], '48f4690c8501a2e0205d7c1bc2c4149dea67ebe098830844ec22b551c3d3b0a7': ['/home/lokad/lython-bench-checks/dict-views-b303-20261105/baseline/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/dict-views-b303-20261105/reference/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/counter-keys-final-b302-20261105/candidate/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/counter-keys-final-b302-20261105/core/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/dict-views-final-b304-20261105/baseline/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/dict-views-final-b304-20261105/reference/Lokad.Lython.dll'], 'e55e7fcc0edd975339007c85c70bde53eb29ec500ff0089d9e282b5ffd3747d5': ['/home/lokad/lython-bench-checks/instruction-boundary-b287-20261105/candidate/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/instruction-boundary-b287-20261105/core/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/instruction-boundary-confirm-b288-20261105/candidate/Lokad.Lython.dll', '/home/lokad/lython-bench-checks/instruction-boundary-confirm-b288-20261105/core/Lokad.Lython.dll']}
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]ollector.dll|[p]erf record'],capture_output=True).returncode==1
 rows=[];temporary=[]
 for digest,names in groups.items():
  for name in names:
   p=Path(name);resolved=p.resolve();assert base in resolved.parents
   actual=hashlib.sha256(p.read_bytes()).hexdigest();assert actual==digest,(name,actual,digest)
   st=p.stat();rows.append(dict(path=name,sha256=actual,inode=st.st_ino,bytes=st.st_size,uid=st.st_uid,mode=oct(stat.S_IMODE(st.st_mode)),parentWritable=os.access(p.parent,os.W_OK)))
   extra=p.with_name(p.name+'.r123-identical-link')
   if extra.exists():
    assert hashlib.sha256(extra.read_bytes()).hexdigest()==digest;temporary.append(str(extra))
 proof=dict(persistedPreMutationPlan=json.loads((base/'r123-identical-core-plan.json').read_text()),readOnlyAudit=True,allKnownPathsAndBytesPreserved=True,aliases=rows,temporaryLinks=temporary,originalFailure='Initial space refusal before root creation; permitted-canonical exact-byte recovery after fresh proof; all original paths and bytes preserved',futureRule='Choose permitted canonical and writable alias directories; persist full plan before any mutation')
 path=base/'r123-post-profile-audit.json';assert not path.exists();path.write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
