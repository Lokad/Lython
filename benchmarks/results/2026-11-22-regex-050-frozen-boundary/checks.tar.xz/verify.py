from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import xml.etree.ElementTree as xml
import zipfile

lab=Path(__file__).resolve().parent
producer=Path("D:/code/utf8regex")
candidate=producer/"artifacts/package-candidates/0.5.0"
revision="61228b20fa7103910c7e247eb72b7c4592a4085f"

def sha(data):
    return hashlib.sha256(data).hexdigest()

manifest=json.loads((candidate/"candidate.json").read_text(encoding="utf-8-sig"))
assert manifest["SourceRevision"]==revision and manifest["PackageVersion"]=="0.5.0"
assert manifest["CleanSource"] and manifest["Configuration"]=="Release" and not manifest["Published"]
packages={}
for item in manifest["Packages"]:
    name=item["Id"]
    if name not in ("Lokad.Utf8Regex","Lokad.Utf8Regex.PythonRe"):continue
    framework=item["TargetFramework"]
    path=candidate/item["RelativePath"]
    data=path.read_bytes()
    assert sha(data)==item["PackageSha256"].lower()
    assert sha((producer/"artifacts/nuget"/path.name).read_bytes())!=sha(data)
    assembly=name+".dll"
    with zipfile.ZipFile(path) as package:
        metadata=xml.fromstring(package.read(name+".nuspec"))
        commit=next(r.get("commit") for r in metadata.iter() if r.tag.endswith("}repository"))
        assert commit==revision
        payload=package.read("lib/"+framework+"/"+assembly)
    assert sha(payload)==item["AssemblySha256"].lower()
    output=lab/"probes"/framework
    output.mkdir(parents=True,exist_ok=True)
    (output/assembly).write_bytes(payload)
    packages[name,framework]=dict(PackageSha256=sha(data),AssemblySha256=sha(payload))
assert len(packages)==4
for name in ("candidate.json","steps.json"):
    shutil.copyfile(candidate/name,lab/("producer-"+name))
scan=subprocess.run(["git","-C",producer,"grep","-n","Unsafe.SizeOf<T>",revision,"--",
    "src/Lokad.Utf8Regex/Internal/Construction/Utf8ConstructionBudget.cs"],check=True,capture_output=True)
assert b"Unsafe.SizeOf<T>" in scan.stdout
(lab/"producer-managed-scan.txt").write_bytes(scan.stdout)
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
with (lab/"build.log").open("wb") as log:
    subprocess.run([dotnet,"build",lab/"DirectProbe/DirectProbe.csproj","-c","Release","--no-incremental"],
                   env=env,check=True,timeout=75,stdout=log,stderr=subprocess.STDOUT)
for framework in ("net10.0","net11.0"):
    run=subprocess.run([dotnet,lab/"DirectProbe/bin/Release"/framework/"DirectProbe.dll"],env=env,
                       capture_output=True,timeout=20)
    (lab/(framework+".log")).write_bytes(run.stdout+run.stderr)
    run.check_returncode()
    text=run.stdout.decode("utf-8")
    assert "Running .NET "+framework.removeprefix("net") in text
    assert all(entry["AssemblySha256"] in text.lower() for (_,target),entry in packages.items() if target==framework)
    assert "Reversed direct refuses startOffsetInBytes" in text and "Reversed cursor refuses startOffsetInBytes" in text
    assert "Cancellation during working-storage admission returns the allowance." in text
    assert "First refused working admission ends the operation without retry." in text
    print(text,flush=True)
with (lab/"cpython.log").open("wb") as log:
    subprocess.run(["C:/Python313/python.exe","-I","-X","utf8",lab/"cpython-probe.py"],
                   check=True,timeout=12,stdout=log,stderr=subprocess.STDOUT)
