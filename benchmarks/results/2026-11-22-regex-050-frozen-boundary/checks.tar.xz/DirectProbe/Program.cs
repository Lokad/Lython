using System.Buffers;
using System.Security.Cryptography;
using Lokad.Utf8Regex;
using Lokad.Utf8Regex.PythonRe;

using var ordinary = new Utf8PythonRegex("(?P<é>)"u8);
var name = new byte[4];
if (ordinary.TryCopyGroupNameUtf8(1, name, out var count) != OperationStatus.Done ||
    !name.AsSpan(0, count).SequenceEqual("é"u8)) throw new InvalidOperationException("Wrong capture name.");

var subject = "xé!"u8.ToArray();
using var nested = new Utf8PythonRegex("(?P<é>(?<=x)(é))"u8);
var captures = new Utf8PythonCaptureRange[3];
var match = nested.Match(subject, 1, captures, mode: Utf8PythonMatchMode.FullMatch, endOffsetInBytes: 3);
if (!match.Success || captures.Any(range => !range.Success || range.StartOffsetInBytes != 1 || range.EndOffsetInBytes != 3))
    throw new InvalidOperationException("Expected three captures at original bytes [1,3).");
using (var cursor = nested.CreateMatchCursor(subject, 1, mode: Utf8PythonMatchMode.FullMatch, endOffsetInBytes: 3))
    if (!cursor.MoveNext(out var rangeMatch) || rangeMatch.LastIndex != 1 || cursor.MoveNext(out _))
        throw new InvalidOperationException("Expected the outer capture to close last.");

Console.WriteLine($"Running .NET {Environment.Version}");
Console.WriteLine($"Core SHA256 {Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(Lokad.Utf8Regex.Utf8Regex).Assembly.Location)))}");
Console.WriteLine($"PythonRe SHA256 {Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(Utf8PythonRegex).Assembly.Location)))}");
Console.WriteLine("UTF-8 name, unshifted lookbehind, bounded full match and outer lastIndex pass.");
Console.WriteLine("Public program/key members " + string.Join(", ", typeof(Utf8PythonRegex).GetMembers()
    .Select(member => member.Name).Distinct().Where(member => member.Contains("Program", StringComparison.OrdinalIgnoreCase)
        || member.Contains("Key", StringComparison.OrdinalIgnoreCase)).Order(StringComparer.Ordinal)));

foreach (var route in new[] { "direct", "cursor" })
{
    try
    {
        bool matched;
        if (route == "direct")
            matched = ordinary.Match(subject.AsSpan(), 3, captures.AsSpan(0, 2), mode: Utf8PythonMatchMode.Match,
                endOffsetInBytes: 1).Success;
        else
        {
            using var cursor = ordinary.CreateMatchCursor(subject, 3, mode: Utf8PythonMatchMode.Match, endOffsetInBytes: 1);
            matched = cursor.MoveNext(out _);
        }
        Console.WriteLine($"Reversed {route} matched {matched}");
    }
    catch (ArgumentOutOfRangeException error)
    {
        Console.WriteLine($"Reversed {route} refuses {error.ParamName}");
    }
}

using var cancellable = new Utf8PythonRegex("(?P<pair>(aa)+)!$"u8);
var longSubject = new byte[32768];
Array.Fill(longSubject, (byte)'a');
longSubject[^1] = (byte)'!';
using var cancellation = new CancellationTokenSource();
var cancelAllowance = new ObservedAllowance(cancellation.Cancel);
try
{
    cancellable.Match(longSubject, captures: captures, cancellationToken: cancellation.Token,
        workingMemoryAllowance: cancelAllowance);
    throw new InvalidOperationException("Expected cancellation from inside matching.");
}
catch (OperationCanceledException) when (cancellation.Token.IsCancellationRequested)
{
    if (cancelAllowance.Admissions == 0 || cancelAllowance.Balance != 0)
        throw new InvalidOperationException("Matching did not return its admitted scratch.");
    Console.WriteLine("Cancellation during working-storage admission returns the allowance.");
}

var refuseAllowance = new ObservedAllowance(null);
try
{
    cancellable.Match(longSubject, captures: captures, workingMemoryAllowance: refuseAllowance);
    throw new InvalidOperationException("Expected terminal refusal.");
}
catch (Utf8MemoryAdmissionException error)
{
    if (refuseAllowance.Admissions != 1 || refuseAllowance.Balance != 0 || error.RequestedBytes == 0)
        throw new InvalidOperationException("Matching retried or failed to preserve refusal.");
    Console.WriteLine("First refused working admission ends the operation without retry.");
}

sealed class ObservedAllowance(Action? onReserve) : IUtf8MemoryAllowance
{
    public ulong Balance { get; private set; }
    public int Admissions { get; private set; }

    public bool TryReserve(ulong bytes)
    {
        Admissions++;
        if (onReserve is null) return false;
        Balance += bytes;
        onReserve();
        return true;
    }

    public void Release(ulong bytes) => Balance = checked(Balance - bytes);
}
