
import re, sys
s='xé!'
m=re.compile(r'(?P<é>(?<=x)(é))').fullmatch(s,1,2)
assert m.regs == ((1,2),(1,2),(1,2)) and m.lastindex == 1
r=re.compile(r'(?P<é>)').match(s,2,1)
assert r.regs == ((2,2),(2,2)) and (r.lastindex,r.pos,r.endpos)==(1,2,1)
print(sys.version)
print(m.regs,m.lastindex,r.regs,r.lastindex,r.pos,r.endpos)
