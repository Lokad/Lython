from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab=Path(__file__).resolve().parent
parent=lab.parent
worker=lab/"worker"
worker.mkdir(exist_ok=True)
reference=parent/"candidate/inspect"
identity=json.loads((parent/"inspection-identity.json").read_text(encoding="utf-8"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert {f.name:sha(f) for f in reference.iterdir() if f.is_file()} == identity["workerImages"]["candidate"]["inspect"]
for f in reference.iterdir():
    if f.is_file() and f.name != "Lokad.Lython.dll":shutil.copyfile(f,worker/f.name)
shutil.copyfile(lab/"instrumented-core.dll",worker/"Lokad.Lython.dll")
worker_hashes={f.name:sha(f) for f in worker.iterdir() if f.is_file()}
assert all(identity["workerImages"]["candidate"]["inspect"][key]==value for key,value in worker_hashes.items() if key!="Lokad.Lython.dll")
sdk=Path.home()/".dotnet11"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
catalog=json.loads((parent/"inspect-catalog.json").read_text(encoding="utf-8"))
expected=json.loads((parent/"candidate-inspection.json").read_text(encoding="utf-8"))["rows"]

def analyze(record):
    ranges={}
    extent=high=reopened=copied=0
    for append in record["writes"]:
        block,count=append["Block"],append["Count"]
        start,previous=ranges.get(block,(0,0))
        assert previous>=count,(record["name"],block,previous,count)
        if count<previous and start+previous==extent:
            extent=start+count
        if count==0:
            start=extent
        elif start+count!=extent:
            reopened+=1
            copied+=count
            start=extent
            extent+=count
        extent+=1
        high=max(high,extent)
        ranges[block]=(start,count+1)
    entries=record["blocks"]
    live=sum(block["Count"] for block in entries)
    arrays=sum(block["Capacity"] for block in entries)
    emit=len(record["writes"])
    assert emit>=live and high<=emit+copied
    predicted=1<<max(2,(high-1).bit_length()) if high else 0
    return dict(code=record["name"],blocks=len(entries),heapArrays=sum(1 for x in entries if x["Capacity"]),
                emitted=emit,live=live,listSlots=arrays,nonEmptyReopens=reopened,relocatedWrites=copied,
                arenaHighWaterSlots=high,arenaGeometricSlots=predicted)

rows=[]
for i,(case,original) in enumerate(zip(catalog["cases"],expected,strict=True)):
    manifest=lab/f"case-{i}.json"
    out=lab/f"inspection-{i}.json"
    manifest.write_text(json.dumps({"cases":[case]},ensure_ascii=False),encoding="utf-8",newline='\n')
    result=subprocess.run([sdk/"dotnet.exe",worker/"Inspect.dll",manifest,out],env=env,capture_output=True,check=True,timeout=20)
    (lab/f"emission-{i}.jsonl").write_bytes(result.stderr)
    blocks=[analyze(json.loads(line)) for line in result.stderr.decode("utf-8").splitlines() if line]
    inspection=json.loads(out.read_text(encoding="utf-8"))
    assert inspection["coreSHA256"] == worker_hashes["Lokad.Lython.dll"]
    assert inspection["rows"]==[original]
    aggregate={key:sum(x[key] for x in blocks) for key in blocks[0] if key!="code"}
    rows.append(dict(case=case["id"],total=aggregate,emissions=blocks))
    print(case["id"],aggregate,flush=True)
assert {f.name:sha(f) for f in worker.iterdir() if f.is_file()}==worker_hashes
(lab/"block-emission-summary.json").write_text(json.dumps(dict(source="f069dc7ab with emission diagnostics",workerHashes=worker_hashes,fixtureSHA256=sha(parent/"inspect-catalog.json"),rows=rows),indent=2)+'\n',encoding="utf-8",newline='\n')
