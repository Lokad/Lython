# Lokad.Lython 0.11.0

Updated 2026-11-10. Git-ignored; never force-add. Publication and tagging remain
postponed. Deliver coherent simplification and substantial whole-script gains;
an isolated experiment does not complete this objective. Current contracts belong
in docs/; history and adverse evidence in [EXPERIMENTS](benchmarks/EXPERIMENTS.md)
and immutable benchmarks/results/. Previous detailed ledgers remain privately in
.git/agent-notes/review-20261031/ (including R190/plan-before-delivery-refresh.md).

## Actual delivery status

| Deliverable | Status and evidence |
| --- | --- |
| Shared compiler facts, direct UTF-8 formatting/storage, native helper returns | Committed and fully qualified. Native returns: allocation −19.92% sync / −19.31% async; original elapsed gains diagnostic. Formatting: allocation −8.67%; controlled B102 elapsed/CPU about 5–8% lower. Original adverse 15.125 ms observation remains unexplained and preserved. Do not repeat unchanged qualification. |
| R178/R179 JSON transfer and helpers within handlers | ee448715 fully qualified, cached GREEN CI42727417102. JSON allocation −3.04/−3.03%, elapsed inconclusive. Helper allocation −47.31/−47.29%, controlled elapsed/CPU about 18–22% lower. Capacity/adverse controls retained. |
| R184 shared binding / closed named-default calls | 32d1ea1a fully qualified, cached GREEN42758271911. One Span binder and managed-inline final storage replace duplicate binding/activation where closure facts allow. Quiet search elapsed −15.7..−21.5%, wider CPU −15.4..−18.8%; desktop search elapsed +5.46..+8.31% remains diagnostic/adverse. Other controls inconclusive. |
| R185 empty/unbound storage | 3a413c59 fully qualified, cached GREEN42761050500. Removes UninitializedLocal, Array.Fill and empty class placeholder. Quiet CSV CPU −1.22..−4.71%; controls overlap zero. |
| R190 native dictionary accumulation | e5731404 committed/pushed. Removes a second hash/probe and intermediate transport in proven native get/add/store sequences. Focused 530 public /146 internal checks and full ordinary 16988 public /4473 internal checks pass per actual .NET11/10. Main forced build and installed Release consumers pass both targets. Fully qualified: cached GREEN42783134761 Windows/Ubuntu, actual11/10, original Stress and installed consumers. Measured e364 core is normalized-source-equivalent to main; EOL-only correction explicit. |
| R190 measured outcome | B538 complete110.923s, all gates/SHA pass. Text elapsed −14.92..−10.90%, wider CPU −14.29..−8.80%; CSV elapsed −5.14..−1.08%, CPU −3.38..−1.18%. Report elapsed −0.74..+2.30%, CPU0..+3.03% remains possible debt. Allocation flat; compile target allocation +0.05..0.07%. Retain coherent change, no general CPU or neutrality claim. Desktop adversity preserved. |
| CPython comparison | Published guide currently measures qualified3a413c59-equivalent core26d: warm CSV1.09–1.11×, text1.64–1.71×, keyword-default search1.51–1.52×; compile0.93–1.08×. R191/B539 complete9jobs/246.994s, all gates/SHA pass: e573-equivalent e364 warm CSV1.07×, text1.45–1.48×, keyword-default search1.50–1.52×; compile0.91–1.08×. docs/BENCHMARKS.md now reflects this checkpoint, with text/search variability explicit. |
| Withdrawn designs | R174–R180 integer wrappers, call-control/arena and generic prefix; R183 routing protocol; R188 original/refined integer-local sidecar are absent. Sources, failures, adverse controls and useful regressions survive. R180 helper-CSV allocation −42.95% coexisted with text CPU regression about29–53%; do not recreate its dispatch protocol. These outcomes are lessons, not permanent architecture vetoes. |
| Regex | Core remains backend-independent. Normal adapter pins0.4 unchanged. Immutable dev64/9af7141f is development-qualified86internal/524public each actual target on unchanged dev59 bridge. Only affected final released-adapter qualification waits for precise producer capabilities. |

Cached terminal GREEN42727417102/42758271911/42761050500/42783134761 must not be queried again.
R188/B535–536, attributionB537 and comparisonB538 are terminal/SHA-verified.
R189 current-source attribution and source gates live in
benchmarks/results/2026-11-10-current-call-transport-attribution/.

## R190 delivery checkpoint closed

Full cached GREEN42783134761, local ordinary and installed consumers, source
normalization proof and retired-worktree receipt are recorded in R190/qualification/.
R191 CPython refresh is complete/SHA-verified and the guide updated. No active VM
users/RAM fixtures or isolated R190 source tree remain. Do not repeat unchanged
qualification or requery terminal owners. Publication remains postponed.

## Priority 1: substantial whole-script simplification

**Active R192 source gate / implementation:** receiver-aware native entry. The
opcode currently excludes bound receivers/aliases; the shared Span binder already
accepts one. Verify existing complete R145 text helper's native facts, then reuse
its managed inline destination with a separate receiver, removing eligible owned
binding and pending-call transport. No new binder/dispatcher/owner/cache/arena.
Variants stay separate from primary CPython rows; full criteria and bounded
measurement in .git/agent-notes/review-20261031/receiver-native-entry-r192/milestone.md.
Unchanged ordinary CSV/text/search/report controls, actual11/10 semantics, live
metadata, genuine async/cancellation, terminal refusal, retained funding/cleanup.

**Bounded text-storage assessment:** maintained text input has2048 three-word lines
and1024 blanks. Splitting already uses stack ranges (eight slots), inline short
UTF-8 payloads and final adopted list arrays. Removing heap ranges/word byte arrays
would not eliminate those allocations here; do not manufacture that redesign.

Use existing attribution and current source, not another broad campaign. Current
CSV/text profiles contain useful work as well as overhead: text dictionary16.33%,
text construction21.66%, VM transport33.28%; CSV binding3.60%, activation4.19%.
R190 now removes eligible duplicate dictionary work; those old sample shares do
not predict remaining cost or speedup.

For each selected milestone, write hypothesis, affected complete scripts, actual
work/storage eliminated, displaced code to delete, semantic acceptance, bounded
before/after controls and completion/debt decision before editing. Do not mistake
another guarded optimization for completion of the overall objective.

1. **Complete call/frame and operand transport.** Final locals already hold bound
   arguments; immutable builtin metadata/signatures, shared Span binding, direct
   operands, deferred contexts/workspaces and closed native helpers exist. Identify
   remaining material construction/transport together, then remove its displaced
   implementation. Do not migrate hundreds of delegates for a cost absent from the
   affected scripts, recreate call arenas/control protocols or introduce universal
   value storage without evidence. CSV/helper/report targets; text/search/Unicode
   controls. Preserve argument effects/read spans, closures, dynamic binders and
   genuine async operations, retained funding and joined cleanup.
2. **Per-record construction.** B74's historical6–8% construction opportunity was
   revised/retained c23d1a10/8f07764a, then extended with private row arrays/shared
   record keys and source-buffer compaction. Do not replay it. Identify a different
   eliminated allocation/scan before another trial. Earlier growth design added
   allocation8.42% and CPU4.3–6.2%; preserve that adversity. Validate custom,
   duplicate/wide/mutating headers, order, reentry, retained records and refusal
   rollback on complete CSV aggregation/retention with text control.
3. **Remaining text construction/conversions.** Next bounded source assessment:
   native casing/whitespace splitting still materially appears in current text
   profiles. Bulk UTF-8 casing, final-word construction and formatting already
   exist; inspect actual remaining scanning/storage rather than recreate them.
   Assess elimination of material intermediate storage/duplicate processing as a
   coherent change; avoid a new lazy value/cursor protocol unless eagerly funded
   results and all Python effects/aliases can be preserved simply. Text/Unicode,
   JSON/report controls; keep expansion/final-sigma context, errors, cancellation,
   admission and retained owners. If source disproves removable work or the
   ownership machinery outweighs it, record that bounded finding and move on.
4. **Repeated frontend analysis.** Several passes compute distinct facts. Profile
   compile-to-result and identify genuine duplicate facts/representations before
   consolidation; remove the displaced pass/storage. New scripts, uncached compile
   and compile-to-result targets; warm execution control. Preserve diagnostics,
   closures/scoping/imports and provider semantics. No heavyweight JIT assumption.

Bounded experiments may confirm/refine/correct measurements when evidence warrants.
Timeouts, unstable unchanged controls and inconclusive timings establish uncertainty,
not failed designs. Size runs for usable quiet-VM observations; preserve original
conditions/adversity. Fixed percentages inform decisions, not automatic vetoes.
Distinguish design simplification, allocation reduction and demonstrated CPU gain.
Temporary regression needs an explicit completion milestone and remaining debt
choice, not indefinite accumulation of special cases.

## Independent regex track

Continue core-owned Python semantics with native UTF-8 names/data, byte ranges,
scalar positions, original-subject windows, flags/captures/replacements/errors,
current-operation tokens and explicit pattern/cache/result ownership. One provider
across frontend/runtime/imports; no producer types/dependencies enter core.
Development producers and adapter-local bridges can support independent testing.
R187/dev64 is already qualified for unchanged supported development paths; do not
repeat it or claim backend safety/performance certification or a promoted pin.

Precise remaining dev64 gaps: separate single-match working owner; native group-name
enumeration; token-independent cursor construction despite per-move tokens. Only
these affected final released-adapter checks wait. Continue independent contract
and correctness work, with actual in-flight cancellation, refusal, retained caches/
results and budget reuse through a cooperating provider. Entry/exit checks do not
prove in-flight interruption. Qualify final released adapter when available.

## Validation, measurements and lasting constraints

Focused Release semantics/cancellation/ownership during iteration. Batch full
Windows/Ubuntu, actual.NET11/10, original Stress and installed-package consumers at
coherent retained boundaries. Never relax timeouts/containment, infer excluded
Stress passed, or repeat unchanged qualification. CPython is primary external
baseline; exact revision/core/reference/date/machine and I/O/cleanup boundary
required. Keep evidence/workers persistent and fixtures separate; archive/join/
verify before retiring owned RAM. No new framework or open-ended campaign.

Follow AGENTS.md: fully managed/memory-safe, managed stack admission, host mediation,
CancellationToken as time authority, cycle detection, checked representation limits,
XML depth and bounded I/O chunks. No unsafe/Unsafe/pointers/PInvoke/native probing,
fuel/quotas/watchdogs, independent caps/default hidden allowances, tracing/weak
reclamation/forced GC, new ownership infrastructure or abandoned operations.
Borrowed-root coarse preflights fund retained capacity/replacement, results/aliases,
caches and pending users through awaited cleanup. First refusal is terminal with
its first structured origin; no retries or skipped optional work to recover.

Force nonincremental builds after timestamp restores/before freezing. Never overlap
local build/test/timing. CI observation at least five minutes apart; terminal results
cached. Only core Release packages via tools/pack.ps1 → artifacts/nuget/; adapter
nonpackable. Quiet VM lokad@20.166.121.73, ~/.ssh/id_lython-bench.pem. Follow exact-copy
retirement receipts; never probe known-retired paths, restart terminal owners or
retire sole evidence/active/current-baseline images. Detailed operational state is
private with each owned run, not duplicated in this active plan.
