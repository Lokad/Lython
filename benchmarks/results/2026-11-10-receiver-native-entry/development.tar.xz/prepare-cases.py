from pathlib import Path
import json, subprocess, textwrap

h = Path(__file__).parent
t = h / 'tree'
cases = {
    'direct-alias-and-receiver': '''
        class Reader:
            def identity(self): return self
            def words(self,line): return line.lower().split()
        value=Reader()
        saved=value.words
        print(value.identity() is value,saved.__self__ is value,saved is value.words)
        print(value.words('A Café'),saved('B TEST'))
        ''',
    'live-defaults-and-keywords': '''
        class Reader:
            def wanted(self,value,/,prefix='A',*,suffix='!'):
                return value.startswith(prefix) and value.endswith(suffix)
        value=Reader();saved=value.wanted
        print(saved('ABC!'),value.wanted('ABC!',suffix='?'))
        Reader.wanted.__defaults__=('B',)
        Reader.wanted.__kwdefaults__['suffix']='?'
        print(saved('BCD?'),value.wanted('AX!',prefix='A',suffix='!'))
        for bad in [lambda:saved(value='x'),lambda:saved('x',prefix='A',self=value),lambda:saved()]:
            try:bad()
            except TypeError:print('TypeError')
        ''',
    'evaluated-target-survives-rebinding': '''
        class Reader:
            def old(self,value): return value.lower()
            def new(self,value): return value.upper()
            read=old
        value=Reader();saved=value.read
        def argument():
            Reader.read=Reader.new
            return 'aB'
        print(value.read(argument()),saved('Cd'),value.read('eF'))
        ''',
    'class-static-and-explicit-receiver': '''
        class Reader:
            @classmethod
            def wanted(cls,value,*,prefix='A'): return value.startswith(prefix)
            @staticmethod
            def trim(value): return value.strip()
            def identity(self,value): return value
        value=Reader();saved=Reader.wanted
        print(Reader.wanted('ABC'),value.wanted('ABC',prefix='B'),saved('BCD',prefix='B'))
        print(Reader.trim(' x '),value.trim(' y '),Reader.identity(value,'z'))
        ''',
    'bound-dunder-and-descriptor': '''
        class Reader:
            def words(self,line): return line.lower().split()
        class Descriptor:
            def __get__(self,instance,owner):return Reader().words
        class Box:read=Descriptor()
        print(Box().read('A B'))
        class More:
            def __call__(self,value,*,prefix='A'):return value.startswith(prefix)
        target=More();saved=target.__call__
        print(target('AB'),saved('CD',prefix='C'))
        ''',
    'dynamic-body-preserves-order': '''
        events=[]
        class Value:
            def __add__(self,other):events.append(other);return 'custom'
        class Reader:
            def add(self,value):return value+'!'
        target=Reader();saved=target.add
        print(saved(Value()),target.add('text'),events)
        ''',
    'closure-class-cell-and-late-names': '''
        prefix='A'
        class Parent:
            def read(self,value):return value.lower()
        class Child(Parent):
            def read(self,value):return super().read(value)
            def wanted(self,value):return value.startswith(prefix)
        child=Child();saved=child.wanted
        print(child.read('AB'),saved('AB'))
        prefix='B'
        print(saved('AB'),saved('BC'))
        ''',
    'wide-and-variadic-binding': '''
        class Reader:
            def wide(self,a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p):return p
            def variadic(self,*args,**kwargs):return args,kwargs
        value=Reader()
        print(value.wide(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16))
        print(value.variadic(2,3,key=4))
        ''',
}
goldens = []
rows = []
for name, raw in cases.items():
    source = textwrap.dedent(raw).strip() + '\n'
    r = subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],
                       text=True, encoding='utf-8', capture_output=True, timeout=10)
    assert r.returncode == 0 and not r.stderr, (name, r.stderr)
    goldens.append(dict(name=name, source=source, stdout=r.stdout, reference='CPython3.13.2'))
    rows.append('        { '+', '.join(json.dumps(v,ensure_ascii=False) for v in (name,source,r.stdout))+' },')
(h/'python-goldens.json').write_text(json.dumps(goldens,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
body = '''using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.PublicApi.Tests;

public sealed class ReceiverFunctionEntryTests
{
    public static TheoryData<string, string, string> Cases => new()
    {
'''+'\n'.join(rows)+'''
    };

    [Theory]
    [MemberData(nameof(Cases))]
    public async Task MethodEntryPreservesPythonBehaviorAndOwnership(string name, string source, string expected)
    {
        _ = name;
        var budget = new LythonMemoryBudget(2 * 1024 * 1024);
        using (var script = new LythonEngine().Compile(source, budget))
        {
            Assert.True(script.IsValid, string.Join(';', script.Diagnostics.Select(d => d.Message)));
            var baseline = budget.ReservedBytes;
            foreach (var asynchronous in new[] { false, true })
            {
                using (var result = asynchronous ? await script.RunAsync(new MockLythonHost()) : script.Run(new MockLythonHost()))
                {
                    Assert.True(result.Success, result.Failure?.Message);
                    Assert.Equal(expected, result.StandardOutput);
                }
                Assert.Equal(baseline, budget.ReservedBytes);
            }
        }
        Assert.Equal(0, budget.ReservedBytes);
    }
}
'''
(t/'tests/Lokad.Lython.PublicApi.Tests/ReceiverFunctionEntryTests.cs').write_text(body,encoding='utf-8',newline='\n')
p=t/'tests/Lokad.Lython.PublicApi.Tests/CooperativeCancellationTests.cs'
s=p.read_text(encoding='utf-8');needle='    };\n\n    [Theory]'
extra=''
for asynchronous in ['false','true']:
    source='class Counter:\n def step(self,value):return value+1\nstep=Counter().step\nvalue=0\nwhile True:value=step(value)'
    extra+='        { '+asynchronous+', '+json.dumps(source)+' },\n'
assert needle in s;s=s.replace(needle,extra+needle,1)
p.write_text(s,encoding='utf-8',newline='\n')
print('Eight independent Python goldens and two active bound-method cancellation cases prepared.')
