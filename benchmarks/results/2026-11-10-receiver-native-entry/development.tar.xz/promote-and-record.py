from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
root=Path('D:/code/Lython');h=Path(__file__).parent;t=h/'tree';q=h/'b540'
destination=root/'benchmarks/results/2026-11-10-receiver-native-entry';destination.mkdir()
summary=json.loads((q/'summary.json').read_text(encoding='utf-8'))
assert summary['complete']and summary['jobs']==3
assert hashlib.sha256((q/'observations.tgz').read_bytes()).hexdigest()==json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'))['archiveSHA256']
frozen=json.loads((h/'diagnostic/identity.json').read_text(encoding='utf-8'))
for name,sha in frozen['source'].items():assert hashlib.sha256((t/name).read_bytes()).hexdigest()==sha,name
files=['src/Lokad.Lython/Runtime/LythonRuntime.Executable.Calls.Invoke.cs',
       'src/Lokad.Lython/Runtime/PyExecutableFunction.cs',
       'tests/Lokad.Lython.PublicApi.Tests/CooperativeCancellationTests.cs',
       'tests/Lokad.Lython.PublicApi.Tests/ReceiverFunctionEntryTests.cs',
       'tests/Lokad.Lython.PublicApi.Tests/ReceiverFunctionLifetimeTests.cs',
       'tests/Lokad.Lython.Tests/SimpleFunctionExecutionBoundaryTests.cs']
for name in files:shutil.copyfile(t/name,root/name)
eol=[]
for name,sha in frozen['source'].items():
 a=(t/name).read_bytes();b=(root/name).read_bytes()
 assert a.replace(b'\r\n',b'\n')==b.replace(b'\r\n',b'\n'),name
 if a!=b:eol.append(name)
proof={'baseRevision':'b57bfa47; qualified e5731404 runtime','measuredCore':frozen['cores']['candidate'],
 'referenceCore':frozen['cores']['before'],'copiedFiles':files,'productionFiles':len(frozen['source']),
 'allMainProductionSourcesEqualAfterEOLNormalization':True,'rawEOLOnlyDifferences':eol,
 'privateSourceManifest':'final-source.json','postcommitBinaryIdentityClaimed':False,
 'publicApiChanged':False,'qualification':'Focused actual11/10 passes; full checkpoint follows committed source, no full local ordinary replay.'}
(destination/'source-promotion-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['observations.tgz','archive-receipt.json','terminal-status.json','summary.json','identity.json',
             'final-source.json','focused.json','source.patch','space-recovery.json','exact-copies.json',
             'inventory-correction.json','observe-not-before.json','extraction.json']:
 shutil.copyfile(q/name,destination/name)
for name in ['milestone.md','source-gate.json','python-goldens.json']:
 shutil.copyfile(h/name,destination/name)
with tarfile.open(destination/'development.tar.xz','w:xz')as a:
 for item in h.iterdir():
  if item.is_file()and item.suffix in ['.py','.md','.cs','.json','.log']:a.add(item,arcname=item.name)
 for item in q.iterdir():
  if item.is_file()and item.suffix in ['.py','.md','.json','.log']and item.name not in ['final-source.json','pre-measurement-plan.md','representative.json']:
   a.add(item,arcname='b540/'+item.name)
 for lane in ['warm','warm-async','compile']:
  for name in ['measurements.json','summary.json','stderr.txt']:a.add(h/'diagnostic'/lane/name,arcname='diagnostic/'+lane+'/'+name)
 for name in ['identity.json','source.patch','script-goldens.json','public11.log','public10.log','internal11.log','internal10.log','freeze11.log']:
  a.add(h/'diagnostic'/name,arcname='diagnostic/'+name)
 for name in files:a.add(t/name,arcname='retained-source/'+name)

(destination/'README.md').write_text('''# Receiver-aware native method entry — R192

Source retained for delivery; fully-qualified e5731404/coree364 reference versus
frozen ac6edb6f aboveb57bfa47. The same16-slot managed destination and shared Span
binder now take the already-evaluated receiver separately for eligible ordinary
methods and bound aliases. This removes workspace rental/return and pending-call
transport, with no prepended self array, second binder, owner/cache/arena/engine or
public API. Native proof occurs before effects. Wide, variadic, protocol-default
and dynamic body cases retain ordinary execution before admission/mutation.

The existing complete R145 text script stores Words().from_line; source inspection
verifies its native body and receiver slot. Old workspace arrays were already
reused, so allocation is effectively flat, about−0.005..−0.007%target. Compilation
allocation is flat within0.02%. This is a work/transport removal, not a substantial
allocation result. Original desktop warm target−0.80..+1.07%, completed-I/O async
−1.19..+3.29%, compile+0.30..+9.97% and all adverse/moving controls are retained.

2026-11-10, F4as_v7/Ubuntu24.04.4, actual.NET11RC3, same frozen workers/adapter0.4/
dependencies, ordinary GC/tiering. Four independent processes/job,5swarmup/role,
seven rotated400msrounds. Same scripts/fixtures/goldens per source; no CPython lane.

| Complete warm script | Elapsed change | Wider process CPU | Status |
| --- | ---: | ---: | --- |
| Bound-method text helper | −8.51..−5.18% | −7.69..−5.98% | Target improvement |
| Ordinary text control | −4.85..+0.66% | −4.55..+0.42% | Inconclusive |
| Report control | −2.06..+0.93% | −2.33..+1.47% | Inconclusive/possible small debt |

Empirical all-pairing ranges, not confidence intervals. Reference/candidate target
spreads2.09/1.45%; ordinary-text reference spread3.46%, report candidate spread2.91%.
CPU includes wider reset/protocol and coarse ticks; no general CPU or neutrality
claim. Warm includes mediated RAM-file I/O, complete stdout/file validation and
prior-result cleanup; compile/startup/staging/reset/protocol/final caches excluded.
Pending I/O, RSS and embedding tail latency are not measured. Completed-I/O async
allocation/elapsed are desktop diagnostics, not a quiet async CPU comparison.

**Decision:** retain this completion of the existing receiver convention and the
targeted CPU benefit. Accept unresolved small control/desktop compilation timing
debt, with no new compiler/storage mechanism. Ordinary methods remain exposed as
real bound values; dynamic cases retain their original behavior. This milestone
does not complete the broader whole-script performance objective.

Focused206public/128internal pass per actual.NET11/10. Eight independentCPython3.13.2
goldens cover receiver/alias/default/live metadata, class/static methods, descriptors,
closures, wide/dynamic protocols and evaluation order. Retained results across two
shared-budget executions, active pure-loop cancellation, genuine suspended host
protocol cleanup, terminal admission despite except/finally and budget reuse pass.
Temporary architecture probe was removed. Full platform/Stress/installed-package
qualification follows at the retained boundary; no full local ordinary replay or
unchanged historical qualification. Publication remains postponed.

All three quiet jobs complete110.836seconds, all identity/output/owner/quiet/join/
RAM removal/archive-under-lease/localSHA checks pass. TerminalB540 cached. Initial
generated-script null interpolation, unique-stage guard and unused Windows apphost/
debug-file inventory mismatch stopped before guest work. Correct runtime inventory
matches establishedB538/B539; originals/corrections survive. Exact canonical old26d
and raw-copy retirement preserves the newly-qualified e364/current baseline; no
active/current image or sole evidence was removed.

[Prospective contract](milestone.md), [actual source facts](source-gate.json),
[Python goldens](python-goldens.json), [all quiet results](summary.json),
[raw cores/source/checks/observations](observations.tgz), [source delta](source.patch),
[main equivalence proof](source-promotion-proof.json), [development/adversity/corrections](development.tar.xz),
[retirement proof](space-recovery.json). Normal optional-adapter pins unchanged.
''',encoding='utf-8',newline='\n')

doc=root/'docs/RUNTIME.md';s=doc.read_text(encoding='utf-8')
s=s.replace('Named and default arguments use the same binding fill as ordinary calls. Small\nclosed native helpers can fill managed inline slots without renting function\nworkspace or creating an activation.',
'''Named and default arguments use the same binding fill as ordinary calls. Small
closed native helpers and methods can fill managed inline slots without renting
function workspace or creating an activation. Direct method calls and saved bound
methods pass the evaluated receiver separately through this same binder; exposing
a method as a value still produces its normal Python bound-method object.''')
doc.write_text(s,encoding='utf-8',newline='\n')
doc=root/'tests/README.md';s=doc.read_text(encoding='utf-8');needle='[Unbound-name checks]'
i=s.index(needle);s=s[:i]+'''[Receiver entry](Lokad.Lython.PublicApi.Tests/ReceiverFunctionEntryTests.cs) keeps
ordinary/saved methods, live defaults, descriptors, class/static methods and
evaluation order against independent Python outputs. Its lifetime suite covers
shared-budget retained results, genuinely pending protocol cancellation, terminal
admission and reuse; pure bound-method loops retain active cancellation coverage.

'''+s[i:];doc.write_text(s,encoding='utf-8',newline='\n')
doc=root/'docs/BENCHMARKS.md';s=doc.read_text(encoding='utf-8');needle='| One native dictionary accumulation / complete CSV and text |'
i=s.index(needle);s=s[:i]+'''| Receiver-aware native entry / complete bound-method text | Quiet warm elapsed −5.2–8.5%, supporting wider CPU; allocation effectively flat | Separate existing class-helper source pair, not the primary CPython rows. Controls inconclusive, report CPU up to+1.47%possible debt; delivery qualification pending. [R192](../benchmarks/results/2026-11-10-receiver-native-entry/README.md) |
'''+s[i:];doc.write_text(s,encoding='utf-8',newline='\n')
doc=root/'benchmarks/EXPERIMENTS.md';s=doc.read_text(encoding='utf-8');i=s.index('The [R191 CPython refresh]')
s=s[:i]+'''The [R192 receiver-aware native entry](results/2026-11-10-receiver-native-entry/README.md)
completes the shared inline binding convention for eligible methods/bound aliases,
removing workspace rental/return and pending-call transport. Allocation is flat;
existing complete bound-method text improves5.2–8.5%quiet elapsed with supporting
CPU. Ordinary text/report controls and all desktop/setup adversity remain; full
delivery qualification follows separately. This does not close the larger roadmap.

'''+s[i:];doc.write_text(s,encoding='utf-8',newline='\n')
attr=root/'.gitattributes';s=attr.read_text(encoding='utf-8');s+='\nbenchmarks/results/2026-11-10-receiver-native-entry/** -text whitespace=cr-at-eol\nbenchmarks/results/2026-11-10-receiver-native-entry/**/*.patch -text -whitespace\n';attr.write_text(s,encoding='utf-8',newline='\n')
plan=root/'PLAN.md';s=plan.read_text(encoding='utf-8');a=s.index('**Active isolated R192 prototype:**');b=s.index('**Bounded text-storage assessment:**',a)
s=s[:a]+'''**R192 source retained for delivery:** receiver-aware native entry uses the existing
shared Span binder/inline destination for methods and saved aliases, removing
workspace rental/return and pending-call transport. No new binder/owner/cache/
arena/engine/public API. Existing arrays were reused: allocation effectively flat.
Focused206public/128internal pass each actual11/10. B540 complete110.836s, all
gates/SHA pass: bound-method text elapsed−8.51..−5.18%, CPU−7.69..−5.98%; ordinary
text/report controls inconclusive, reportCPU up to+1.47%possible debt. Retain the
coherent calling-convention completion; no general gain/neutrality claim. Original
desktop adversity/setup failures/corrections and frozen source survive in
benchmarks/results/2026-11-10-receiver-native-entry/. Main source promotion proof
covers all567production sources after EOL normalization. Full delivery checkpoint
follows focused main checks, without repeating full local suites. Publication off.

'''+s[b:]
s=s.replace('B540 three-job quiet comparison is running','B540 three-job quiet comparison is complete')
plan.write_text(s,encoding='utf-8',newline='\n')
print('R192 source copied,567-source proof and complete evidence/current docs recorded.')
