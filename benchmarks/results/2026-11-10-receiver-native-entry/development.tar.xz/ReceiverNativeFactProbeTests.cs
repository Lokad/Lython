using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime;
using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.Tests;

public sealed class ReceiverNativeFactProbeTests
{
    [Fact]
    public void CaptureExistingCompleteTextHelper()
    {
        const string source = "class Words:\n from_line=lambda self,line:line.lower().split()\nwords_from_line=Words().from_line";
        var code = ExecutableScript.Compile(LoweredScript.Lower(LythonFrontend.Compile(source).Script!)).EntryPoint;
        var budget = new LythonMemoryBudget(1024 * 1024);
        using (var owner = budget.CreateScope())
        {
            var context = new LythonRuntime.ExecutionContext(new MockLythonHost(), new() { MemoryBudget = owner });
            try
            {
                LythonRuntime.ExecuteExecutableCodeObject(code, context);
                var method = Assert.IsType<PyBoundMethod>(context.Variables["words_from_line"]);
                var function = Assert.IsType<PyExecutableFunction>(method.Function);
                Assert.NotNull(function.CodeObject.NativeBody);
                Assert.True(function.CanBindNativeArguments);
                File.WriteAllText(@"D:\code\Lython\.git\agent-notes\review-20261031\receiver-native-entry-r192\source-gate.json",
                    System.Text.Json.JsonSerializer.Serialize(new
                    {
                        source,
                        nativeBody = true,
                        canBindNative = function.CanBindNativeArguments,
                        receiverType = method.Receiver.GetType().FullName,
                        parameters = function.CodeObject.LocalNameToSlot,
                        closureIsClass = function.DefinitionContext.IsClassBody,
                        conclusion = "Current bound method is native-eligible after owned binding; opcode excludes it before binding."
                    }, new System.Text.Json.JsonSerializerOptions { WriteIndented = true }), System.Text.Encoding.UTF8);
            }
            finally { context.State.CloseResources(); }
        }
        Assert.Equal(0, budget.ReservedBytes);
    }
}
