from pathlib import Path
import datetime,json,shutil,subprocess
h=Path(__file__).parent;p=h/'b540'
assert not (p/'observe-not-before.json').exists()
for name in ['identity.json','launch.log','launch-driver.log']:
 shutil.copyfile(p/name,p/('inventory-failure-'+name))
identity=json.loads((p/'identity.json').read_text(encoding='utf-8'))
old=json.loads((h.parent/'native-dictionary-accumulation-r190/b538/identity.json').read_text(encoding='utf-8'))
differences={n:dict(localDiagnostic=identity['auxiliaryFiles'].get(n),quietRuntime=old['auxiliaryFiles'].get(n))
 for n in sorted(set(identity['auxiliaryFiles'])|set(old['auxiliaryFiles']))if identity['auxiliaryFiles'].get(n)!=old['auxiliaryFiles'].get(n)}
assert set(differences)=={'Lokad.Lython.Benchmarks.exe','Lokad.Lython.Benchmarks.pdb','Lokad.Lython.Utf8Regex.pdb','Lokad.Lython.pdb'}
identity['auxiliaryFiles']=old['auxiliaryFiles']
identity['setupCorrection']='Local desktop inventory included unused Windows apphost/debug symbols; established frozen runtime manifest is unchanged and all runtime files match. Initial setup stopped before fixture mount/service/guest work.'
(p/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
(p/'inventory-correction.json').write_text(json.dumps({'differences':differences,'runtimeFilesChanged':False,'newGuestRunBeforeCorrection':False,'originalPayloadRetained':True},indent=2)+'\n',encoding='utf-8')
script=r'''from pathlib import Path
import ast,fcntl,hashlib,json,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks');root=base/'receiver-native-b540-20261110'
identity=IDENTITY
service='lython-b540-receiver-native-20261110'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert root.is_dir()and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]ollector.dll|[p]erf record'],capture_output=True).returncode==1
 prior=subprocess.run(['systemctl','show',service+'.service','--property=LoadState'],capture_output=True,text=True)
 assert 'LoadState=not-found'in prior.stdout,(prior.stdout,prior.stderr)
 shutil.copyfile(root/'identity.json',root/'identity-first.json')
 (root/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
 assert hashlib.sha256((root/'representative.json').read_bytes()).hexdigest()==identity['catalogSHA256']
 for role in ['reference','candidate']:
  assert hashlib.sha256((root/role/'Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256'][role]
  for name,digest in identity['auxiliaryFiles'].items():
   assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==digest,(role,name)
 protocol=base/'prepared-call-layout-b384-20261107/cpython-worker.py'
 assert hashlib.sha256(protocol.read_bytes()).hexdigest()=='02ca606af6b937a5bec8da744da36e6dbea45ef14ee7207732f34da052ad32f1'
 (root/'cpython-worker.py').symlink_to(protocol)
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 assert 'assert len(jobs)==3 'in(root/'collect.py').read_text()
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture=root/'guest-fixtures';fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b540-fixtures',str(fixture)],check=True)
 started=False
 try:
  setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndEveryRuntimeAuxiliaryVerified=True,allConfiguredJobsValidated=True,
   roles=4,ownerSeconds=180,stopSeconds=30,marginSeconds=30,osFreeFloorMiB=240,evidenceHeadroomMiB=12,
   setupCorrection=identity['setupCorrection'])
  assert setup['freeBytes']>(240+12)*1024*1024
  (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
  fcntl.flock(lease,fcntl.LOCK_UN)
  subprocess.run(['sudo','-n','systemd-run','--unit='+service,'--property=User=lokad','--property=WorkingDirectory='+str(root),
   '--property=RuntimeMaxSec=180','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
  started=True
  live=subprocess.check_output(['systemctl','show',service+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
  assert 'ActiveState=active'in live and 'MainPID=0'not in live
  print(json.dumps(dict(liveUnit=live)),flush=True)
 except BaseException:
  if started:subprocess.run(['sudo','-n','systemctl','stop',service+'.service'],check=True,timeout=45)
  subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
'''.replace('IDENTITY',repr(identity))
(p/'finish-prepared-command.py').write_text(script,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem',
 '-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
r=subprocess.run([*ssh,'python3 -'],input=script,text=True,encoding='utf-8',capture_output=True)
(p/'finish-prepared.log').write_text(r.stdout+r.stderr,encoding='utf-8');assert r.returncode==0,r.stderr+r.stdout
assert 'ActiveState=active'in r.stdout and 'MainPID=0'not in r.stdout
now=datetime.datetime.now(datetime.timezone.utc)
(p/'observe-not-before.json').write_text(json.dumps(dict(acknowledgedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=240)).isoformat(),ownerSeconds=180,stopSeconds=30,marginSeconds=30),indent=2)+'\n',encoding='utf-8')
print(r.stdout,flush=True);print('Observe after',(now+datetime.timedelta(seconds=240)).isoformat(),flush=True)
