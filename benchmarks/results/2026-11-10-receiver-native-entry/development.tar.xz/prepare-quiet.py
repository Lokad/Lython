from pathlib import Path
import hashlib,json,shutil,tarfile
h=Path(__file__).parent;old=h.parent/'native-dictionary-accumulation-r190/b538';p=h/'b540';p.mkdir()
for name in ['collect.py','archive-owned.py','run.sh','launch.py','retrieve.py','summarize.py']:
 s=(old/name).read_text(encoding='utf-8')
 s=s.replace('dictionary-accumulation-b538-launch.py','receiver-native-b540-launch.py').replace('New B538 owner','New B540 owner')
 s=s.replace('dictionary-accumulation-b538-20261110','receiver-native-b540-20261110').replace('lython-b538-dictionary-accumulation-20261110','lython-b540-receiver-native-20261110').replace('lython-b538-fixtures','lython-b540-fixtures')
 s=s.replace('"""R188 deferred boxing for uncaptured integer locals, no CPython lane through unchanged comparison workers/protocol."""','"""R192 receiver-aware native entry, complete text plus ordinary text/report controls."""')
 if name=='collect.py':
  s=s.replace("jobs=[['scripts.csv-validated-records.large', 'warm'], ['scripts.report-render.large', 'warm'], ['scripts.text-summary-helpers.large', 'warm']]", "jobs=[['scripts.text-summary-helpers.class-callable.large', 'warm'], ['scripts.report-render.large', 'warm'], ['scripts.text-summary-helpers.large', 'warm']]")
 if name=='launch.py':
  # Keep original helper's own directory instead of a hard-coded earlier home.
  assert 'Path(__file__)'in s
 (p/name).write_text(s,encoding='utf-8',newline='\n')
shutil.copyfile(h/'diagnostic/catalog.json',p/'representative.json')
identity=json.loads((h/'diagnostic/identity.json').read_text(encoding='utf-8'))
aux={v.name:hashlib.sha256(v.read_bytes()).hexdigest()for v in(h/'diagnostic/images/before').iterdir()if v.is_file()and v.name!='Lokad.Lython.dll'}
frozen={'sourceRevision':'Isolated R192 aboveb57bfa47; qualifiede5731404/coree364 reference; source not promoted.',
 'coreSHA256':{r:identity['cores']['before'if r.startswith('reference')else'candidate']for r in ['reference','reference-control','candidate','candidate-control']},
 'auxiliaryFiles':aux,'catalogSHA256':hashlib.sha256((p/'representative.json').read_bytes()).hexdigest()}
(p/'identity.json').write_text(json.dumps(frozen,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(h/'diagnostic/images/candidate/Lokad.Lython.dll',p/'current-core.dll')
shutil.copyfile(h/'diagnostic/identity.json',p/'final-source.json')
shutil.copyfile(h/'diagnostic/source.patch',p/'source.patch')
shutil.copyfile(h/'python-goldens.json',p/'golden.json')
shutil.copyfile(Path('D:/code/Lython/PLAN.md'),p/'pre-measurement-plan.md')
(p/'baseline-source.json').write_text(json.dumps({'source':'Qualifiede5731404, normalized source proof and cachedGREEN42783134761 in R190 canonical evidence.','coreSHA256':identity['cores']['before']},indent=2)+'\n',encoding='utf-8')
(p/'focused.json').write_text(json.dumps({'publicPerActualTarget':206,'internalPerActualTarget':128,'actualTargets':['NET11RC3','NET10.0.8'],'temporarySourceFactProbePassedThenRemoved':True,'fullPlatformStressPackage':'Deferred to a retained delivery boundary; prototype not promoted.','initialTestCompileFailure':'new() options was ambiguous; corrected to explicit LythonRunOptions. Original log retained.'},indent=2)+'\n',encoding='utf-8')
(p/'contract.md').write_text('R192: one bounded quiet comparison of existing bound-method complete text against qualifiede573/coree364; unchanged ordinary text/report controls. Three warm jobs, four independent roles,5swarmup,7rotated400msrounds, ordinary GC/tiering. No CPython ratio or CPU claim in advance. Native receiver uses existing shared Span binder/inline destination; removes workspace rental/return and pending call transport, not per-call arrays (already reused). Keep all source/failure/adverse observations. All identity/output/owner/quiet/join/archive/SHA gates, owner180s/stop30s/margin30s,240MiB OSfloor/12MiB evidence headroom. Publication postponed.\n',encoding='utf-8')
(p/'sizing.json').write_text(json.dumps({'jobs':3,'warmupSecondsPerRole':5,'rounds':7,'targetRoundSeconds':.4,'ownerSeconds':180,'stopSeconds':30,'marginSeconds':30},indent=2)+'\n',encoding='utf-8')
(p/'setup-contract.json').write_text(json.dumps({'retainedRuntime':'e5731404 qualified','referenceImage':'e364e4d9','osFreeFloorMiB':240,'evidenceHeadroomMiB':12,'noCurrentBaselineRetirement':True},indent=2)+'\n',encoding='utf-8')
with tarfile.open(p/'source-checks.tar.xz','w:xz')as a:
 for item in h.iterdir():
  if item.is_file()and item.suffix in ['.py','.md','.json','.log','.cs']:a.add(item,arcname=item.name)
 for name in ['public11','public10','internal11','internal10','freeze11']:
  a.add(h/'diagnostic'/(name+'.log'),arcname='focused/'+name+'.log')
 for phase in ['warm','warm-async','compile']:
  for name in ['measurements.json','summary.json','stderr.txt']:a.add(h/'diagnostic'/phase/name,arcname='diagnostic/'+phase+'/'+name)
 for name in ['identity.json','source.patch','script-goldens.json']:a.add(h/'diagnostic'/name,arcname='diagnostic/'+name)
names=['collect.py','archive-owned.py','run.sh','representative.json','identity.json','current-core.dll','final-source.json','source.patch','golden.json','pre-measurement-plan.md','baseline-source.json','focused.json','contract.md','sizing.json','setup-contract.json','source-checks.tar.xz']
with tarfile.open(p/'payload.tgz','w:gz')as a:
 for name in names:a.add(p/name,arcname=name)
payload=(p/'payload.tgz').read_bytes()
s=(old/'launch-command.py').read_text(encoding='utf-8')
s=s.replace('dictionary-accumulation-b538-20261110','receiver-native-b540-20261110').replace('lython-b538-dictionary-accumulation-20261110','lython-b540-receiver-native-20261110').replace('lython-b538-fixtures','lython-b540-fixtures')
s=s.replace('empty-local-b533-20261110','dictionary-cpython-b539-20261110')
s=s.replace('read(2861969)','read('+str(len(payload)+1)+')').replace('len(payload)==2861968','len(payload)=='+str(len(payload)))
s=s.replace('e10981be755d4baec375ab5937fed6a59cbced01b3caf0dee1b9632df7219f18',hashlib.sha256(payload).hexdigest())
(p/'launch-command.py').write_text(s,encoding='utf-8',newline='\n')
# Local canonical copies for exact retirement under a fresh idle lease. Current
# e364 baseline is preserved;26d is now historical and fully archived by R190.
local_archive=Path('D:/code/Lython/benchmarks/results/2026-11-10-dictionary-accumulation/observations.tgz')
with tarfile.open(local_archive)as a:
 old_core=a.extractfile('baseline-core.dll').read()
assert hashlib.sha256(old_core).hexdigest()=='26d43e660d9acb78406504b52bfff4ac463df85f6e980f32d628725f560fbb7a'
last=h.parent/'dictionary-cpython-r191/b539'
receipt=json.loads((last/'archive-receipt.json').read_text(encoding='utf-8'))
assert hashlib.sha256((last/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
copies=[{'path':'dictionary-cpython-b539-20261110/observations.tgz','bytes':(last/'observations.tgz').stat().st_size,'sha256':receipt['archiveSHA256'],'canonical':'benchmarks/results/2026-11-10-dictionary-cpython-checkpoint/observations.tgz'}]
with tarfile.open(last/'observations.tgz')as a:
 for m in a.getmembers():
  if m.isfile()and m.name.startswith('confirmation/')and m.size>32768:
   b=a.extractfile(m).read();copies.append({'path':'dictionary-cpython-b539-20261110/'+m.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'canonical':'benchmarks/results/2026-11-10-dictionary-cpython-checkpoint/observations.tgz:'+m.name})
(p/'exact-copies.json').write_text(json.dumps(copies,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(p/'payload.tgz')as a:required=sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+(240+12)*1024*1024+65536
(p/'payload-identity.json').write_text(json.dumps({'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest(),'requiredFreeBytes':required,'oldHistoricalCoreBytes':len(old_core)},indent=2)+'\n',encoding='utf-8')
print('Prepared B540; required staging/free bytes',required,'exact terminal copies',len(copies),flush=True)
