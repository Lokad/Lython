from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve()
copies=[{'path': 'dictionary-cpython-b539-20261110/observations.tgz', 'bytes': 2000344, 'sha256': 'ed6e2ca4b5067b6c7d1d34c1e9c8b44fa4ff80bef29dfe5e5bcd31ca0fa8bc34', 'canonical': 'benchmarks/results/2026-11-10-dictionary-cpython-checkpoint/observations.tgz'}, {'path': 'dictionary-cpython-b539-20261110/confirmation/confirmation.json', 'bytes': 1287551, 'sha256': '042cc9c2673e0780165a74eafd448f4cfe1a93d4f866131919b049ea7060d78c', 'canonical': 'benchmarks/results/2026-11-10-dictionary-cpython-checkpoint/observations.tgz:confirmation/confirmation.json'}, {'path': 'current-work-b537-20261110/profiles/csv-warm/perf-stacks.txt', 'bytes': 648586, 'sha256': '662955cbf1173f1bc4217fddb7dc170a4e7ab79fb37b755870b79cc76b67db75', 'canonical': 'benchmarks/results/2026-11-10-current-call-transport-attribution/observations.tgz:profiles/csv-warm/perf-stacks.txt'}, {'path': 'current-work-b537-20261110/profiles/text-warm/perf-stacks.txt', 'bytes': 631161, 'sha256': 'c4a85011b8b891b08c8865b9dfd648b22f216caee137f95848570c14116eee3b', 'canonical': 'benchmarks/results/2026-11-10-current-call-transport-attribution/observations.tgz:profiles/text-warm/perf-stacks.txt'}, {'path': 'text-proof-b527-20261110/profiles/text-warm/perf-stacks.txt', 'bytes': 665481, 'sha256': '25f17488e62c7c311fc6d1b1364751c61754800620c1c82fe4c6367ce7c979ae', 'canonical': 'benchmarks/results/2026-11-10-shared-prefix-assessment/profile/observations.tgz:profiles/text-warm/perf-stacks.txt'}]
required=270897152
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]ollector.dll|[p]erf record'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert not(base/'receiver-native-b540-20261110').exists()
 protected=base/'dictionary-cpython-b539-20261110/current-core.dll'
 assert hashlib.sha256(protected.read_bytes()).hexdigest()=='e364e4d94ad8015fc8492760cad235475b5943aa6687d681edbb14692e4956f0'
 old=base/'empty-local-b533-20261110/current-core.dll';old_stat=old.stat()
 assert hashlib.sha256(old.read_bytes()).hexdigest()=='26d43e660d9acb78406504b52bfff4ac463df85f6e980f32d628725f560fbb7a'
 aliases=[Path(os.fsdecode(v))for v in subprocess.check_output(['find',str(base),'-xdev','-samefile',str(old),'-print0']).split(b'\0')if v]
 assert len(aliases)==old_stat.st_nlink
 targets=[];records=[]
 for path in aliases:
  assert path.resolve(strict=True).is_relative_to(base) and stat.S_ISREG(path.lstat().st_mode)
  s=path.stat();assert s.st_uid==os.getuid()and(s.st_dev,s.st_ino)==(old_stat.st_dev,old_stat.st_ino)
  assert(path.stat().st_dev,path.stat().st_ino)!=(protected.stat().st_dev,protected.stat().st_ino)
  targets.append(path)
 records.append(dict(kind='historical26dCore',allAliases=[str(v)for v in aliases],links=old_stat.st_nlink,
  size=old_stat.st_size,allocatedBytes=old_stat.st_blocks*512,sha256='26d43e660d9acb78406504b52bfff4ac463df85f6e980f32d628725f560fbb7a',
  canonical='benchmarks/results/2026-11-10-dictionary-accumulation/observations.tgz:baseline-core.dll',
  reason='e573/e364 is now fully qualified GREEN42783134761 and remains the current baseline;26d is historical.'))
 reclaim=old_stat.st_blocks*512
 for c in copies:
  path=base/c['path'];assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(path.lstat().st_mode)
  s=path.stat();assert s.st_uid==os.getuid()and s.st_nlink==1 and s.st_size==c['bytes']
  assert hashlib.sha256(path.read_bytes()).hexdigest()==c['sha256']
  assert path not in targets;targets.append(path);reclaim+=s.st_blocks*512
  records.append(dict(c,allocatedBytes=s.st_blocks*512,allAliases=[str(path)],links=1))
 before=shutil.disk_usage(base).free
 assert before+reclaim>required,(before,reclaim,required)
 for path in targets:path.unlink()
 after=shutil.disk_usage(base).free;assert after>required
 assert protected.is_file()and hashlib.sha256(protected.read_bytes()).hexdigest()=='e364e4d94ad8015fc8492760cad235475b5943aa6687d681edbb14692e4956f0'
 result=dict(beforeFreeBytes=before,afterFreeBytes=after,requiredFreeBytes=required,osFloorMiB=240,evidenceHeadroomMiB=12,
  freshIdleLease=True,files=records,operation='Exact canonical terminal copies only; newly-qualified e364/current image preserved; no active users or sole evidence retired.')
 (base/'receiver-native-b540-space-recovery.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result))
