from pathlib import Path
import hashlib,json,subprocess,tarfile
p=Path(__file__).parent/'b540'
copies=json.loads((p/'exact-copies.json').read_text(encoding='utf-8'))
for c in copies:
 file,_,member=c['canonical'].partition(':')
 subprocess.run(['git','ls-files','--error-unmatch',file],check=True,capture_output=True)
 if member:
  with tarfile.open(file)as a:b=a.extractfile(member).read()
 else:b=Path(file).read_bytes()
 assert len(b)==c['bytes'] and hashlib.sha256(b).hexdigest()==c['sha256']
required=json.loads((p/'payload-identity.json').read_text(encoding='utf-8'))['requiredFreeBytes']
script=r'''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve()
copies=COPIES
required=REQUIRED
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]ollector.dll|[p]erf record'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert not(base/'receiver-native-b540-20261110').exists()
 protected=base/'dictionary-cpython-b539-20261110/current-core.dll'
 assert hashlib.sha256(protected.read_bytes()).hexdigest()=='e364e4d94ad8015fc8492760cad235475b5943aa6687d681edbb14692e4956f0'
 old=base/'empty-local-b533-20261110/current-core.dll';old_stat=old.stat()
 assert hashlib.sha256(old.read_bytes()).hexdigest()=='26d43e660d9acb78406504b52bfff4ac463df85f6e980f32d628725f560fbb7a'
 aliases=[Path(os.fsdecode(v))for v in subprocess.check_output(['find',str(base),'-xdev','-samefile',str(old),'-print0']).split(b'\0')if v]
 assert len(aliases)==old_stat.st_nlink
 targets=[];records=[]
 for path in aliases:
  assert path.resolve(strict=True).is_relative_to(base) and stat.S_ISREG(path.lstat().st_mode)
  s=path.stat();assert s.st_uid==os.getuid()and(s.st_dev,s.st_ino)==(old_stat.st_dev,old_stat.st_ino)
  assert(path.stat().st_dev,path.stat().st_ino)!=(protected.stat().st_dev,protected.stat().st_ino)
  targets.append(path)
 records.append(dict(kind='historical26dCore',allAliases=[str(v)for v in aliases],links=old_stat.st_nlink,
  size=old_stat.st_size,allocatedBytes=old_stat.st_blocks*512,sha256='26d43e660d9acb78406504b52bfff4ac463df85f6e980f32d628725f560fbb7a',
  canonical='benchmarks/results/2026-11-10-dictionary-accumulation/observations.tgz:baseline-core.dll',
  reason='e573/e364 is now fully qualified GREEN42783134761 and remains the current baseline;26d is historical.'))
 reclaim=old_stat.st_blocks*512
 for c in copies:
  path=base/c['path'];assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(path.lstat().st_mode)
  s=path.stat();assert s.st_uid==os.getuid()and s.st_nlink==1 and s.st_size==c['bytes']
  assert hashlib.sha256(path.read_bytes()).hexdigest()==c['sha256']
  assert path not in targets;targets.append(path);reclaim+=s.st_blocks*512
  records.append(dict(c,allocatedBytes=s.st_blocks*512,allAliases=[str(path)],links=1))
 before=shutil.disk_usage(base).free
 assert before+reclaim>required,(before,reclaim,required)
 for path in targets:path.unlink()
 after=shutil.disk_usage(base).free;assert after>required
 assert protected.is_file()and hashlib.sha256(protected.read_bytes()).hexdigest()=='e364e4d94ad8015fc8492760cad235475b5943aa6687d681edbb14692e4956f0'
 result=dict(beforeFreeBytes=before,afterFreeBytes=after,requiredFreeBytes=required,osFloorMiB=240,evidenceHeadroomMiB=12,
  freshIdleLease=True,files=records,operation='Exact canonical terminal copies only; newly-qualified e364/current image preserved; no active users or sole evidence retired.')
 (base/'receiver-native-b540-space-recovery.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result))
'''.replace('COPIES',repr(copies)).replace('REQUIRED',str(required))
(p/'space-recovery-command.py').write_text(script,encoding='utf-8',newline='\n')
r=subprocess.run(['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem',
 '-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73','python3 -'],input=script,text=True,encoding='utf-8',capture_output=True)
(p/'space-recovery.log').write_text(r.stdout+r.stderr,encoding='utf-8');assert r.returncode==0,r.stderr+r.stdout
(p/'space-recovery.json').write_text(r.stdout,encoding='utf-8')
v=json.loads(r.stdout);print('Retired fully archived historical26d aliases and terminal raw copies; currente364 retained. Free',v['afterFreeBytes'],'required',required,flush=True)
