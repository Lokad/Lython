; Assembly listing for method Lokad.Lython.LythonCompiledScript:RunCore(Lokad.Lython.ILythonHost,Lokad.Lython.LythonRunOptions):Lokad.Lython.LythonExecutionResult:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 7 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 72
       lea      rbp, [rsp+0x70]
       mov      rsi, rcx
       mov      rdi, rdx
       mov      rbx, r8
 
G_M000_IG02:                ;; offset=0x001A
       mov      r14, gword ptr [rsi+0x08]
       test     r14, r14
       je       G_M000_IG13
       test     rbx, rbx
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x002C
       mov      rcx, 0x7FF9CCD71FA0
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
 
G_M000_IG04:                ;; offset=0x003E
       mov      r15, gword ptr [rbx+0x38]
       test     r15, r15
       jne      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0047
       mov      r15, gword ptr [rsi+0x20]
       test     r15, r15
       jne      SHORT G_M000_IG06
       mov      rcx, 0x7FF9CCC15BD8
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      byte  ptr [rbp-0x38], 0
       xor      edx, edx
       mov      qword ptr [rbp-0x30], rdx
       lea      rdx, [rbp-0x38]
       mov      rcx, r15
       call     [Lokad.Lython.LythonMemoryBudget:.ctor(System.Nullable`1[long]):this]
 
G_M000_IG06:                ;; offset=0x0079
       mov      rcx, r15
       mov      r11, 0x7FF9CC901C90
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      gword ptr [rbp-0x40], rax
 
G_M000_IG07:                ;; offset=0x008D
       mov      rcx, gword ptr [rbx+0x40]
       test     rcx, rcx
       cmove    rcx, r15
       mov      r11, 0x7FF9CC901C98
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      r9, rax
       mov      gword ptr [rbp-0x48], r9
 
G_M000_IG08:                ;; offset=0x00AC
       mov      rdx, gword ptr [rbx+0x60]
       mov      rcx, rbx
       mov      r8, gword ptr [rbp-0x40]
       call     [Lokad.Lython.LythonRunOptions:Copy(System.Threading.CancellationToken,Lokad.Lython.ILythonMemoryBudget,Lokad.Lython.ILythonMemoryBudget):Lokad.Lython.LythonRunOptions:this]
       mov      r8, rax
       mov      rdx, rdi
       mov      rcx, gword ptr [r14+0x10]
       call     [r14+0x18]System.Func`3[System.__Canon,System.__Canon,System.__Canon]:Invoke(System.__Canon,System.__Canon):System.__Canon:this
       mov      rbx, rax
       lea      rcx, bword ptr [rbx+0x28]
       mov      rdx, gword ptr [rbp-0x48]
       call     CORINFO_HELP_ASSIGN_REF
       nop      
 
G_M000_IG09:                ;; offset=0x00DC
       cmp      gword ptr [rbp-0x40], 0
       je       SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x00E3
       mov      rcx, gword ptr [rbp-0x40]
       mov      r11, 0x7FF9CC901CA8
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG11:                ;; offset=0x00F4
       mov      rax, rbx
 
G_M000_IG12:                ;; offset=0x00F7
       add      rsp, 72
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG13:                ;; offset=0x0104
       mov      rcx, 0x7FF9CCD4A5F0
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x24D5EE1C950
       call     [System.ObjectDisposedException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG14:                ;; offset=0x0132
       sub      rsp, 40
 
G_M000_IG15:                ;; offset=0x0136
       mov      rcx, gword ptr [rbp-0x48]
       mov      r11, 0x7FF9CC901CA0
       call     [r11]System.IDisposable:Dispose():this
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG16:                ;; offset=0x014D
       sub      rsp, 40
 
G_M000_IG17:                ;; offset=0x0151
       cmp      gword ptr [rbp-0x40], 0
       je       SHORT G_M000_IG18
       mov      rcx, gword ptr [rbp-0x40]
       mov      r11, 0x7FF9CC901CA8
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG18:                ;; offset=0x0169
       nop      
 
G_M000_IG19:                ;; offset=0x016A
       add      rsp, 40
       ret      
 
; Total bytes of code 367

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInstructionPrefix(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref,byref,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 28 inlinees with PGO data; 307 single block inlinees; 76 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 0x3E8
       lea      rbp, [rsp+0x420]
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -768
 
G_M000_IG383:                ;; offset=0x0029
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG383
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      dword ptr [rbp+0x28], r9d
       mov      rbx, r8
       mov      rsi, bword ptr [rbp+0x30]
       mov      r8, bword ptr [rbp+0x38]
       mov      rax, bword ptr [rbp+0x40]
       mov      r10, bword ptr [rbp+0x48]
 
G_M000_IG02:                ;; offset=0x0064
       mov      r9, bword ptr [r10]
       mov      bword ptr [rbp-0x3A0], r9
       mov      r10d, dword ptr [r10+0x08]
       mov      dword ptr [rbp-0x2F0], r10d
       xor      r11d, r11d
       mov      qword ptr [rsi], r11
       mov      qword ptr [rsi+0x08], r11
 
G_M000_IG03:                ;; offset=0x0083
       mov      gword ptr [r8], r11
 
G_M000_IG04:                ;; offset=0x0086
       mov      qword ptr [rax], r11
       mov      qword ptr [rax+0x08], r11
       mov      qword ptr [rax+0x10], r11
       mov      r11, gword ptr [rcx]
       mov      r11, gword ptr [r11+0x98]
       mov      gword ptr [rbp-0x348], r11
       mov      edi, dword ptr [r11+0x08]
       cmp      dword ptr [rcx+0x10], edi
       jge      G_M000_IG364
 
G_M000_IG05:                ;; offset=0x00AF
       xor      r14d, r14d
       mov      dword ptr [rbp-0x3C], r14d
       mov      r14d, dword ptr [rcx+0x10]
       cmp      r14d, edi
       jae      G_M000_IG372
       shl      r14, 5
       lea      r14, bword ptr [r11+r14+0x10]
       mov      bword ptr [rbp-0x350], r14
       mov      r14, gword ptr [rdx+0xA0]
       mov      r15, bword ptr [rbp-0x350]
       mov      r15, gword ptr [r15]
       cmp      byte  ptr [r14], r14b
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00F4
       mov      rcx, r14
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG07:                ;; offset=0x0101
       mov      rcx, bword ptr [rbp-0x350]
       mov      r14d, dword ptr [rcx+0x1C]
       cmp      r14d, 77
       ja       G_M000_IG293
 
G_M000_IG08:                ;; offset=0x0116
       mov      ecx, r14d
       lea      rdx, [reloc @RWD00]
       mov      edx, dword ptr [rdx+4*rcx]
       lea      r8, G_M000_IG02
       add      rdx, r8
       jmp      rdx
 
G_M000_IG09:                ;; offset=0x012F
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       test     rbx, rbx
       je       G_M000_IG149
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG12
       mov      r8, bword ptr [rbp-0x350]
 
G_M000_IG10:                ;; offset=0x014D
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x330], ymm0
 
G_M000_IG11:                ;; offset=0x015A
       lea      r8, [rbp-0x330]
       lea      rdx, [rbp-0x258]
       mov      rcx, rbx
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x268]
       lea      rdx, [rbp-0x258]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rdi, rsi
       mov      rdx, gword ptr [rbp-0x268]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x260]
       mov      qword ptr [rdi+0x08], rdx
       mov      rdi, gword ptr [rsi]
       test     rdi, rdi
       je       G_M000_IG58
       jmp      G_M000_IG299
 
G_M000_IG12:                ;; offset=0x01B9
       mov      r8, bword ptr [rbp-0x350]
 
G_M000_IG13:                ;; offset=0x01C0
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x330], ymm0
 
G_M000_IG14:                ;; offset=0x01CD
       lea      r8, [rbp-0x330]
       lea      rdx, [rbp-0xC0]
       mov      rcx, rbx
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       mov      rdi, gword ptr [rbp-0xC0]
       movsx    r14, word  ptr [rbp-0xB8]
       test     rdi, rdi
       je       G_M000_IG361
 
G_M000_IG15:                ;; offset=0x01FF
       mov      rdx, rdi
       mov      rcx, 0x7FF9CCCFF848
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      G_M000_IG297
 
G_M000_IG16:                ;; offset=0x021A
       mov      rcx, rdi
       mov      edx, r14d
       mov      r11, 0x7FF9CC901E88
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG361
 
G_M000_IG17:                ;; offset=0x0232
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       movzx    rcx, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], ecx
       lea      rcx, [rbp-0x88]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, r15
       mov      rdx, r13
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecutePreparedOperation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG149
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG20
 
G_M000_IG18:                ;; offset=0x0272
       vmovdqu  xmm0, xmmword ptr [rbp-0x88]
       vmovdqu  xmmword ptr [rbp-0x340], xmm0
 
G_M000_IG19:                ;; offset=0x0282
       lea      rdx, [rbp-0x340]
       lea      rcx, [rbp-0x278]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rdi, rsi
       mov      rdx, gword ptr [rbp-0x278]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x270]
       mov      qword ptr [rdi+0x08], rdx
       mov      rdi, gword ptr [rsi]
       test     rdi, rdi
       je       G_M000_IG58
       jmp      G_M000_IG312
 
G_M000_IG20:                ;; offset=0x02C4
       mov      rdi, gword ptr [rbp-0x88]
       movsx    r14, word  ptr [rbp-0x80]
       test     rdi, rdi
       je       G_M000_IG361
 
G_M000_IG21:                ;; offset=0x02D9
       mov      rdx, rdi
       mov      rcx, 0x7FF9CCCFF848
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      G_M000_IG310
 
G_M000_IG22:                ;; offset=0x02F4
       mov      rcx, rdi
       mov      edx, r14d
       mov      r11, 0x7FF9CC901EA8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG361
 
G_M000_IG23:                ;; offset=0x030C
       mov      r13, gword ptr [rbp+0x18]
       test     rbx, rbx
       je       G_M000_IG149
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r15]
       mov      rdi, gword ptr [rcx+0x38]
       mov      rcx, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG360
       mov      ecx, eax
       mov      rcx, gword ptr [rdi+8*rcx+0x10]
       mov      rdx, bword ptr [rbp-0x350]
       mov      rdx, gword ptr [rdx]
       mov      r8, rbx
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveName(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      rdi, rax
       mov      r9, bword ptr [rbp-0x350]
       mov      r14d, dword ptr [r9+0x18]
       test     r14d, r14d
       jge      SHORT G_M000_IG24
       mov      gword ptr [rbp-0x310], rdi
       xor      r9d, r9d
       mov      qword ptr [rbp-0x308], r9
       lea      r9, [rbp-0x310]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x350]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG361
 
G_M000_IG24:                ;; offset=0x039D
       lea      rax, bword ptr [r15+0x20]
       mov      bword ptr [rbp-0x388], rax
       mov      rcx, bword ptr [rbp-0x350]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG27
 
G_M000_IG25:                ;; offset=0x03B7
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x03C7
       mov      r8d, r14d
       mov      dword ptr [rbp-0x2E4], r8d
       jmp      SHORT G_M000_IG28
 
G_M000_IG27:                ;; offset=0x03D3
       mov      r8, bword ptr [rbp-0x350]
       mov      r8d, dword ptr [r8+0x14]
       mov      dword ptr [rbp-0x2E4], r8d
 
G_M000_IG28:                ;; offset=0x03E5
       cmp      r14d, dword ptr [rax+0x40]
       jge      SHORT G_M000_IG29
       mov      rcx, rax
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp-0x388]
 
G_M000_IG29:                ;; offset=0x03FE
       mov      rcx, gword ptr [rax]
       mov      r8d, dword ptr [rbp-0x2E4]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG360
       mov      edx, r8d
       shl      rdx, 4
       lea      r8, bword ptr [rcx+rdx+0x10]
       mov      rcx, r8
       mov      bword ptr [rbp-0x3B8], rcx
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      rdi, bword ptr [rbp-0x3B8]
       mov      qword ptr [rdi+0x08], rcx
       mov      rdi, bword ptr [rbp-0x388]
       mov      dword ptr [rdi+0x40], r14d
       jmp      G_M000_IG361
 
G_M000_IG30:                ;; offset=0x044D
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       mov      rdi, gword ptr [r15]
       mov      rcx, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      edx, eax
       mov      rcx, rdi
       mov      r8, bword ptr [rbp-0x350]
       mov      r8, gword ptr [r8]
       mov      r9, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rdi, rax
       mov      r9, bword ptr [rbp-0x350]
       mov      r14d, dword ptr [r9+0x18]
       test     r14d, r14d
       jge      SHORT G_M000_IG31
       mov      gword ptr [rbp-0x310], rdi
       xor      r9d, r9d
       mov      qword ptr [rbp-0x308], r9
       lea      r9, [rbp-0x310]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x350]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG361
 
G_M000_IG31:                ;; offset=0x04C0
       lea      rax, bword ptr [r15+0x20]
       mov      bword ptr [rbp-0x380], rax
       mov      rcx, bword ptr [rbp-0x350]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG34
 
G_M000_IG32:                ;; offset=0x04DA
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x04EA
       mov      r8d, r14d
       mov      dword ptr [rbp-0x2E0], r8d
       jmp      SHORT G_M000_IG35
 
G_M000_IG34:                ;; offset=0x04F6
       mov      r8, bword ptr [rbp-0x350]
       mov      r8d, dword ptr [r8+0x14]
       mov      dword ptr [rbp-0x2E0], r8d
 
G_M000_IG35:                ;; offset=0x0508
       cmp      r14d, dword ptr [rax+0x40]
       jge      SHORT G_M000_IG36
       mov      rcx, rax
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp-0x380]
 
G_M000_IG36:                ;; offset=0x0521
       mov      rcx, gword ptr [rax]
       mov      r8d, dword ptr [rbp-0x2E0]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG360
       mov      edx, r8d
       shl      rdx, 4
       lea      r8, bword ptr [rcx+rdx+0x10]
       mov      rcx, r8
       mov      bword ptr [rbp-0x3C0], rcx
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      rdi, bword ptr [rbp-0x3C0]
       mov      qword ptr [rdi+0x08], rcx
       mov      rdi, bword ptr [rbp-0x380]
       mov      dword ptr [rdi+0x40], r14d
       jmp      G_M000_IG361
 
G_M000_IG37:                ;; offset=0x0570
       mov      r15, bword ptr [rbp+0x10]
       cmp      gword ptr [r15+0x40], 0
       jne      SHORT G_M000_IG38
       mov      r13, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], r13
       mov      rcx, gword ptr [r15]
       mov      rdx, gword ptr [r15+0x18]
       mov      r8d, dword ptr [r15+0x10]
       mov      r9d, dword ptr [r15+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      G_M000_IG45
 
G_M000_IG38:                ;; offset=0x05A1
       mov      r13, gword ptr [rbp+0x18]
       mov      rcx, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      r8d, eax
       lea      r9, [rbp-0x68]
       mov      qword ptr [rsp+0x20], r9
       mov      r9, bword ptr [rbp-0x350]
       mov      r9, gword ptr [r9]
       mov      rdx, rbx
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:TryLoadClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       G_M000_IG149
       mov      rdi, gword ptr [rbp-0x68]
       mov      r9, bword ptr [rbp-0x350]
       mov      r14d, dword ptr [r9+0x18]
       test     r14d, r14d
       jge      SHORT G_M000_IG39
       mov      gword ptr [rbp-0x310], rdi
       xor      r9d, r9d
       mov      qword ptr [rbp-0x308], r9
       lea      r9, [rbp-0x310]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x350]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG361
 
G_M000_IG39:                ;; offset=0x0620
       lea      rax, bword ptr [r15+0x20]
       mov      bword ptr [rbp-0x370], rax
       mov      rcx, bword ptr [rbp-0x350]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG42
 
G_M000_IG40:                ;; offset=0x063A
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG42
 
G_M000_IG41:                ;; offset=0x064A
       mov      r8d, r14d
       mov      dword ptr [rbp-0x2A8], r8d
       jmp      SHORT G_M000_IG43
 
G_M000_IG42:                ;; offset=0x0656
       mov      r8, bword ptr [rbp-0x350]
       mov      r8d, dword ptr [r8+0x14]
       mov      dword ptr [rbp-0x2A8], r8d
 
G_M000_IG43:                ;; offset=0x0668
       cmp      r14d, dword ptr [rax+0x40]
       jge      SHORT G_M000_IG44
       mov      rcx, rax
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp-0x370]
 
G_M000_IG44:                ;; offset=0x0681
       mov      rcx, gword ptr [rax]
       mov      r8d, dword ptr [rbp-0x2A8]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG360
       mov      edx, r8d
       shl      rdx, 4
       lea      r8, bword ptr [rcx+rdx+0x10]
       mov      rcx, r8
       mov      bword ptr [rbp-0x3C8], rcx
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      rdi, bword ptr [rbp-0x3C8]
       mov      qword ptr [rdi+0x08], rcx
       mov      rdi, bword ptr [rbp-0x370]
       mov      dword ptr [rdi+0x40], r14d
       jmp      G_M000_IG361
 
G_M000_IG45:                ;; offset=0x06D0
       add      dword ptr [r15+0x10], 2
       jmp      G_M000_IG361
 
G_M000_IG46:                ;; offset=0x06DA
       mov      gword ptr [rbp-0x310], r14
       xor      r9d, r9d
       mov      qword ptr [rbp-0x308], r9
       lea      r9, [rbp-0x310]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x350]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG361
 
G_M000_IG47:                ;; offset=0x070A
       mov      r8, bword ptr [rbp-0x350]
       mov      r8d, dword ptr [r8+0x14]
       mov      dword ptr [rbp-0x2A4], r8d
 
G_M000_IG48:                ;; offset=0x071C
       cmp      edi, dword ptr [rax+0x40]
       jge      SHORT G_M000_IG49
       mov      rcx, rax
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp-0x368]
 
G_M000_IG49:                ;; offset=0x0733
       mov      rcx, gword ptr [rax]
       mov      r8d, dword ptr [rbp-0x2A4]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG360
       mov      edx, r8d
       shl      rdx, 4
       lea      r8, bword ptr [rcx+rdx+0x10]
       mov      rcx, r8
       mov      bword ptr [rbp-0x3D0], rcx
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      r14, bword ptr [rbp-0x3D0]
       mov      qword ptr [r14+0x08], rcx
       mov      r14, bword ptr [rbp-0x368]
       mov      dword ptr [r14+0x40], edi
       jmp      G_M000_IG361
 
G_M000_IG50:                ;; offset=0x0782
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r15]
       mov      rdi, gword ptr [rcx+0x30]
       mov      rcx, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG360
       mov      ecx, eax
       mov      rcx, gword ptr [rdi+8*rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      rdi, rax
       mov      r9, bword ptr [rbp-0x350]
       mov      r14d, dword ptr [r9+0x18]
       test     r14d, r14d
       jge      SHORT G_M000_IG51
       mov      gword ptr [rbp-0x310], rdi
       xor      r9d, r9d
       mov      qword ptr [rbp-0x308], r9
       lea      r9, [rbp-0x310]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x350]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG361
 
G_M000_IG51:                ;; offset=0x07F3
       lea      rax, bword ptr [r15+0x20]
       mov      bword ptr [rbp-0x378], rax
       mov      rcx, bword ptr [rbp-0x350]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG54
 
G_M000_IG52:                ;; offset=0x080D
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG54
 
G_M000_IG53:                ;; offset=0x081D
       mov      r8d, r14d
       mov      dword ptr [rbp-0x2DC], r8d
       jmp      SHORT G_M000_IG55
 
G_M000_IG54:                ;; offset=0x0829
       mov      r8, bword ptr [rbp-0x350]
       mov      r8d, dword ptr [r8+0x14]
       mov      dword ptr [rbp-0x2DC], r8d
 
G_M000_IG55:                ;; offset=0x083B
       cmp      r14d, dword ptr [rax+0x40]
       jge      SHORT G_M000_IG56
       mov      rcx, rax
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp-0x378]
 
G_M000_IG56:                ;; offset=0x0854
       mov      rcx, gword ptr [rax]
       mov      r8d, dword ptr [rbp-0x2DC]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG360
       mov      edx, r8d
       shl      rdx, 4
       lea      r8, bword ptr [rcx+rdx+0x10]
       mov      rcx, r8
       mov      bword ptr [rbp-0x3D8], rcx
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       xor      edx, edx
       mov      rdi, bword ptr [rbp-0x3D8]
       mov      qword ptr [rdi+0x08], rdx
       mov      rdi, bword ptr [rbp-0x378]
       mov      dword ptr [rdi+0x40], r14d
       jmp      G_M000_IG361
 
G_M000_IG57:                ;; offset=0x08A3
       test     rbx, rbx
       je       G_M000_IG149
       mov      r15, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [r15]
       mov      rcx, gword ptr [rdx+0xA8]
       mov      rdx, bword ptr [rbp-0x350]
       mov      edx, dword ptr [rdx+0x08]
       mov      r11, 0x7FF9CC901E80
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG59
       lea      rcx, [rbp-0x290]
       mov      rdx, rax
       mov      r8, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteImportAsync(Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Threading.Tasks.ValueTask]
       lea      rcx, [rbp-0x2A0]
       lea      rdx, [rbp-0x290]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rdi, rsi
       mov      rdx, gword ptr [rbp-0x2A0]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x298]
       mov      qword ptr [rdi+0x08], rdx
       mov      rdi, gword ptr [rsi]
       test     rdi, rdi
       jne      G_M000_IG319
 
G_M000_IG58:                ;; offset=0x0927
       mov      r15, bword ptr [rbp+0x10]
       mov      r13, gword ptr [rbp+0x18]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG361
 
G_M000_IG59:                ;; offset=0x093D
       mov      rcx, gword ptr [r15]
       mov      r8, gword ptr [r15+0x08]
       mov      rdx, rax
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteExecutableImport(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext)]
       jmp      G_M000_IG361
 
G_M000_IG60:                ;; offset=0x0955
       test     rbx, rbx
       je       G_M000_IG149
       mov      r15, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [r15+0x20]
       mov      rdx, bword ptr [rbp-0x350]
       mov      r8d, dword ptr [rdx+0x10]
       mov      edx, r14d
       cmp      edx, 51
       ja       SHORT G_M000_IG65
 
G_M000_IG61:                ;; offset=0x0979
       mov      r9, 0x7FFFFFFFFF9FF
       bt       r9, rdx
       jb       SHORT G_M000_IG65
 
G_M000_IG62:                ;; offset=0x0989
       mov      rdx, bword ptr [rbp-0x350]
       mov      edx, dword ptr [rdx+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG63
       mov      r9d, edx
       not      r9d
       jmp      SHORT G_M000_IG64
 
G_M000_IG63:                ;; offset=0x099F
       mov      r9d, edx
 
G_M000_IG64:                ;; offset=0x09A2
       jmp      SHORT G_M000_IG66
 
G_M000_IG65:                ;; offset=0x09A4
       mov      r9, bword ptr [rbp-0x350]
       mov      r9d, dword ptr [r9+0x14]
 
G_M000_IG66:                ;; offset=0x09AF
       lea      rdx, [rbp-0xD0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      r14d, dword ptr [r15+0x10]
       inc      r14d
       mov      r13, gword ptr [rbx+0x70]
       cmp      byte  ptr [rbx+0x10A], 0
       jne      SHORT G_M000_IG67
       cmp      byte  ptr [rbx+0x108], 0
       jne      SHORT G_M000_IG67
       cmp      edi, r14d
       jg       SHORT G_M000_IG68
 
G_M000_IG67:                ;; offset=0x09DE
       xor      r12d, r12d
       jmp      SHORT G_M000_IG69
 
G_M000_IG68:                ;; offset=0x09E3
       cmp      r14d, edi
       jae      G_M000_IG360
       mov      r8d, r14d
       shl      r8, 5
       mov      r11, gword ptr [rbp-0x348]
       cmp      dword ptr [r11+r8+0x2C], 30
       sete     r12b
       movzx    r12, r12b
 
G_M000_IG69:                ;; offset=0x0A08
       test     r12d, r12d
       je       SHORT G_M000_IG72
       test     r13, r13
       je       SHORT G_M000_IG72
 
G_M000_IG70:                ;; offset=0x0A12
       vmovdqu  xmm0, xmmword ptr [rbp-0xD0]
       vmovdqu  xmmword ptr [rbp-0x310], xmm0
 
G_M000_IG71:                ;; offset=0x0A22
       lea      r8, [rbp-0x310]
       mov      rdx, r13
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryAppendBufferedYield(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG73
 
G_M000_IG72:                ;; offset=0x0A39
       lea      rdi, bword ptr [rbx+0x198]
       mov      rdx, gword ptr [rbp-0xD0]
       mov      rcx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, qword ptr [rbp-0xC8]
       mov      qword ptr [rdi+0x08], rcx
       mov      word  ptr [rbx+0x100], 257
       inc      dword ptr [r15+0x10]
       test     r12d, r12d
       jne      G_M000_IG266
       test     r13, r13
       je       G_M000_IG266
       mov      rcx, rbx
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG266
       jmp      G_M000_IG363
 
G_M000_IG73:                ;; offset=0x0A92
       cmp      r14d, edi
       jae      G_M000_IG360
       mov      ecx, r14d
       shl      rcx, 5
       mov      r11, gword ptr [rbp-0x348]
       mov      rdi, gword ptr [r11+rcx+0x10]
       mov      r13, gword ptr [rbp+0x18]
       mov      r12, gword ptr [r13+0xA0]
       cmp      byte  ptr [r12], r12b
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG74
       mov      rcx, r12
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG74:                ;; offset=0x0AD6
       mov      rcx, gword ptr [r13+0xA0]
       mov      rdx, rcx
       mov      rax, gword ptr [rbx+0x78]
       test     rax, rax
       je       SHORT G_M000_IG75
       cmp      dword ptr [rax+0x10], 0
       setg     al
       movzx    rax, al
       test     eax, eax
       je       SHORT G_M000_IG75
       mov      rax, gword ptr [rcx+0x148]
       jmp      SHORT G_M000_IG76
 
G_M000_IG75:                ;; offset=0x0B00
       mov      rax, gword ptr [rbx+0x80]
 
G_M000_IG76:                ;; offset=0x0B07
       lea      rcx, bword ptr [rdx+0x148]
       mov      rdx, rax
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [r15+0x20]
       mov      edx, r14d
       shl      rdx, 5
       mov      r11, gword ptr [rbp-0x348]
       lea      rdx, bword ptr [r11+rdx+0x10]
       mov      edx, dword ptr [rdx+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG77
       not      edx
 
G_M000_IG77:                ;; offset=0x0B36
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       add      dword ptr [r15+0x10], 2
       jmp      G_M000_IG363
 
G_M000_IG78:                ;; offset=0x0B46
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       movzx    rcx, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], ecx
       mov      bword ptr [rsp+0x28], rsi
       mov      r8, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x30], r8
       mov      rcx, r15
       mov      rdx, r13
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteComparisonInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref):int]
       test     eax, eax
       je       G_M000_IG230
       mov      dword ptr [rbp-0xAC], eax
       jmp      G_M000_IG369
 
G_M000_IG79:                ;; offset=0x0B8D
       mov      rdx, bword ptr [rbp-0x350]
       mov      r8d, dword ptr [rdx+0x10]
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r15]
       mov      rdx, gword ptr [r15+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG80
       lea      r9, bword ptr [rdx+0x10]
       mov      edx, dword ptr [rdx+0x08]
       jmp      SHORT G_M000_IG81
 
G_M000_IG80:                ;; offset=0x0BB1
       xor      r9, r9
       xor      edx, edx
 
G_M000_IG81:                ;; offset=0x0BB6
       mov      bword ptr [rbp-0x300], r9
       mov      dword ptr [rbp-0x2F8], edx
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      r13, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x28], r13
       mov      rdx, gword ptr [r15+0x18]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rbp-0x300]
       mov      r9d, dword ptr [r15+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      rdi, rax
       test     rbx, rbx
       jne      SHORT G_M000_IG82
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       je       G_M000_IG149
 
G_M000_IG82:                ;; offset=0x0C05
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG87
       test     rdi, rdi
       je       SHORT G_M000_IG87
 
G_M000_IG83:                ;; offset=0x0C10
       mov      r8, 0x7FF9CCFBD018
       cmp      qword ptr [rdi], r8
       jne      SHORT G_M000_IG87
 
G_M000_IG84:                ;; offset=0x0C1F
       mov      r8, bword ptr [rbp-0x350]
 
G_M000_IG85:                ;; offset=0x0C26
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x330], ymm0
 
G_M000_IG86:                ;; offset=0x0C33
       lea      r8, [rbp-0x330]
       lea      rdx, [rbp-0x1B8]
       mov      rcx, rbx
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteConditionalJumpAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rdi, rsi
       mov      rdx, gword ptr [rbp-0x1B8]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x1B0]
       mov      qword ptr [rdi+0x08], rdx
       mov      rdi, gword ptr [rsi]
       test     rdi, rdi
       je       G_M000_IG230
       jmp      G_M000_IG354
 
G_M000_IG87:                ;; offset=0x0C7A
       mov      rcx, r15
       mov      rdx, r13
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG361
 
G_M000_IG88:                ;; offset=0x0C98
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       test     rbx, rbx
       jne      SHORT G_M000_IG90
       mov      ecx, r14d
       cmp      ecx, 58
       ja       G_M000_IG149
 
G_M000_IG89:                ;; offset=0x0CB1
       mov      rdx, 0x1FDFFFFFFFFFFFF
       bt       rdx, rcx
       jb       G_M000_IG149
 
G_M000_IG90:                ;; offset=0x0CC5
       mov      rcx, r15
       mov      rdx, r13
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp-0x3C], eax
       cmp      gword ptr [r15+0x68], 0
       je       G_M000_IG361
       cmp      byte  ptr [rbp+0x28], 0
       je       G_M000_IG266
       cmp      gword ptr [r15+0x40], 0
       je       G_M000_IG266
       xor      rcx, rcx
       mov      gword ptr [rsi], rcx
       mov      word  ptr [rsi+0x08], 0
       movzx    rcx, byte  ptr [rbp-0x3C]
       mov      byte  ptr [rsi+0x0A], cl
       mov      byte  ptr [rsi+0x0B], 1
       mov      dword ptr [rbp-0xAC], 5
       jmp      G_M000_IG369
 
G_M000_IG91:                ;; offset=0x0D23
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, r15
       mov      rdx, r13
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteBuiltinArithmetic(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG98
       jmp      G_M000_IG361
 
G_M000_IG92:                ;; offset=0x0D4E
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       test     rbx, rbx
       je       G_M000_IG149
 
G_M000_IG93:                ;; offset=0x0D5F
       mov      r14, bword ptr [rbp+0x10]
       mov      rdi, gword ptr [rbp+0x18]
       mov      rcx, rbx
       mov      rdx, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG361
 
G_M000_IG94:                ;; offset=0x0D7C
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       test     rbx, rbx
       je       G_M000_IG149
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG93
       mov      r8, bword ptr [rbp-0x350]
 
G_M000_IG95:                ;; offset=0x0D9A
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x330], ymm0
 
G_M000_IG96:                ;; offset=0x0DA7
       lea      r8, [rbp-0x330]
       lea      rdx, [rbp-0x1C8]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSliceValueOperationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x1D8]
       lea      rdx, [rbp-0x1C8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r14, rsi
       mov      rdx, gword ptr [rbp-0x1D8]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x1D0]
       mov      qword ptr [r14+0x08], rdx
       mov      rdi, gword ptr [rsi]
       test     rdi, rdi
       je       G_M000_IG58
       jmp      G_M000_IG351
 
G_M000_IG97:                ;; offset=0x0E00
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, r15
       mov      rdx, r13
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSequenceIndex(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG361
 
G_M000_IG98:                ;; offset=0x0E26
       mov      r15, bword ptr [rbp+0x10]
       mov      r13, gword ptr [rbp+0x18]
       movzx    rcx, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], ecx
       mov      bword ptr [rsp+0x28], rsi
       mov      rcx, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x30], rcx
       mov      r12, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x38], r12
       mov      rcx, r15
       mov      rdx, r13
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInputInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref,byref):int]
       test     eax, eax
       je       G_M000_IG361
       mov      dword ptr [rbp-0xAC], eax
       jmp      G_M000_IG369
 
G_M000_IG99:                ;; offset=0x0E76
       mov      r15, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [r15]
       mov      rcx, gword ptr [rdx+0xB0]
       cmp      r14d, 42
       jne      G_M000_IG334
       mov      rdx, bword ptr [rbp-0x350]
       mov      edx, dword ptr [rdx+0x08]
       mov      r11, 0x7FF9CC901E78
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r14, rax
       mov      rcx, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      edi, eax
       mov      rdx, bword ptr [rbp-0x350]
       cmp      dword ptr [rdx+0x0C], 0x7FFFFFFF
       je       G_M000_IG121
       cmp      dword ptr [r15+0x60], edi
       jne      G_M000_IG121
       mov      rdx, bword ptr [rbp-0x350]
       mov      r8d, dword ptr [rdx+0x10]
       mov      rcx, gword ptr [r15]
       mov      rdx, gword ptr [r15+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG100
       lea      r9, bword ptr [rdx+0x10]
       mov      edx, dword ptr [rdx+0x08]
       jmp      SHORT G_M000_IG101
 
G_M000_IG100:                ;; offset=0x0EF5
       xor      r9, r9
       xor      edx, edx
 
G_M000_IG101:                ;; offset=0x0EFA
       mov      bword ptr [rbp-0x300], r9
       mov      dword ptr [rbp-0x2F8], edx
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      r13, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x28], r13
       mov      rdx, gword ptr [r15+0x18]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rbp-0x300]
       mov      r9d, dword ptr [r15+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      r12, rax
       mov      r8, bword ptr [rbp-0x350]
       mov      eax, dword ptr [r8+0x0C]
       mov      dword ptr [rbp-0xD4], eax
       mov      r8, bword ptr [rbp-0x350]
       cmp      dword ptr [r8+0x10], 0
       jl       G_M000_IG108
       test     rbx, rbx
       je       G_M000_IG108
       test     r12, r12
       je       G_M000_IG108
 
G_M000_IG102:                ;; offset=0x0F68
       mov      r8, 0x7FF9CCFB5CA0
       cmp      qword ptr [r12], r8
       jne      G_M000_IG108
 
G_M000_IG103:                ;; offset=0x0F7C
       mov      r8, gword ptr [r15+0x20]
       cmp      eax, dword ptr [r8+0x08]
       jae      G_M000_IG360
       mov      edx, eax
       shl      rdx, 4
 
G_M000_IG104:                ;; offset=0x0F90
       vmovdqu  xmm0, xmmword ptr [r8+rdx+0x10]
       vmovdqu  xmmword ptr [rbp-0x310], xmm0
 
G_M000_IG105:                ;; offset=0x0F9F
       lea      r8, [rbp-0xE8]
       mov      qword ptr [rsp+0x20], r8
       lea      r8, [rbp-0x310]
       mov      rdx, r14
       mov      rcx, r12
       mov      r9, r13
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartForwardedComputedDefinition(Lokad.Lython.Frontend.ExecutableCallSite,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool:this]
       test     eax, eax
       mov      eax, dword ptr [rbp-0xD4]
       je       SHORT G_M000_IG108
 
G_M000_IG106:                ;; offset=0x0FCB
       vmovdqu  xmm0, xmmword ptr [rbp-0xE8]
       vmovdqu  xmmword ptr [rbp-0x310], xmm0
 
G_M000_IG107:                ;; offset=0x0FDB
       lea      r9, [rbp-0x310]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x350]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG361
 
G_M000_IG108:                ;; offset=0x0FFA
       test     eax, eax
       jge      SHORT G_M000_IG110
 
G_M000_IG109:                ;; offset=0x0FFE
       jmp      SHORT G_M000_IG111
 
G_M000_IG110:                ;; offset=0x1000
       mov      rcx, gword ptr [r15+0x20]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG360
       mov      edx, eax
       shl      rdx, 4
       lea      rcx, bword ptr [rcx+rdx+0x10]
       lea      rdx, [rbp-0xF0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetShortUtf8(byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG111
       mov      rcx, qword ptr [rbp-0xF0]
       lea      r8, [rbp-0x100]
       mov      qword ptr [rsp+0x20], r8
       mov      r8, gword ptr [r14+0x18]
       mov      rdx, r12
       mov      r9, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeShortUtf8Float(long,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG140
 
G_M000_IG111:                ;; offset=0x1054
       mov      rcx, gword ptr [r15]
       mov      rdx, gword ptr [r15+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG112
       lea      r9, bword ptr [rdx+0x10]
       mov      edx, dword ptr [rdx+0x08]
       jmp      SHORT G_M000_IG113
 
G_M000_IG112:                ;; offset=0x1069
       xor      r9, r9
       xor      edx, edx
 
G_M000_IG113:                ;; offset=0x106E
       mov      bword ptr [rbp-0x300], r9
       mov      dword ptr [rbp-0x2F8], edx
       mov      dword ptr [rsp+0x20], 1
       mov      gword ptr [rsp+0x28], r13
       mov      rdx, gword ptr [r15+0x18]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rbp-0x300]
       mov      r9d, dword ptr [r15+0x10]
       mov      r8d, dword ptr [rbp-0xD4]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      gword ptr [rbp-0x358], rax
       mov      rdx, r12
       mov      rcx, 0x7FF9CCF41E08
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG114
       test     rbx, rbx
       setne    r8b
       movzx    r8, r8b
       mov      dword ptr [rsp+0x20], r8d
       lea      r8, [rbp-0x110]
       mov      qword ptr [rsp+0x28], r8
       mov      r8, gword ptr [r14+0x18]
       mov      rcx, rax
       mov      rdx, gword ptr [rbp-0x358]
       mov      r9, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeUnaryBuiltin(Lokad.Lython.Runtime.LythonRuntime+BuiltinCallable,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       jne      G_M000_IG136
 
G_M000_IG114:                ;; offset=0x1102
       lea      rax, bword ptr [r15+0x20]
       mov      bword ptr [rbp-0x398], rax
       lea      r8d, [rdi+0x01]
       mov      dword ptr [rbp-0x2E8], r8d
       cmp      r8d, dword ptr [rax+0x40]
       jl       SHORT G_M000_IG116
 
G_M000_IG115:                ;; offset=0x111E
       jmp      SHORT G_M000_IG117
 
G_M000_IG116:                ;; offset=0x1120
       mov      rcx, rax
       mov      edx, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp-0x398]
 
G_M000_IG117:                ;; offset=0x1133
       mov      rcx, gword ptr [rax]
       cmp      edi, dword ptr [rcx+0x08]
       jae      G_M000_IG360
       mov      edx, edi
       shl      rdx, 4
       lea      r10, bword ptr [rcx+rdx+0x10]
       mov      rcx, r10
       mov      bword ptr [rbp-0x3A8], rcx
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      r12, bword ptr [rbp-0x3A8]
       mov      qword ptr [r12+0x08], rcx
       mov      r12, bword ptr [rbp-0x398]
       mov      ecx, dword ptr [rbp-0x2E8]
       mov      dword ptr [r12+0x40], ecx
       lea      r12, bword ptr [r15+0x20]
       lea      eax, [rdi+0x02]
       mov      dword ptr [rbp-0x2EC], eax
       cmp      eax, dword ptr [r12+0x40]
       jl       SHORT G_M000_IG119
 
G_M000_IG118:                ;; offset=0x1190
       jmp      SHORT G_M000_IG120
 
G_M000_IG119:                ;; offset=0x1192
       mov      rcx, r12
       mov      edx, eax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG120:                ;; offset=0x119D
       mov      rcx, gword ptr [r12]
       lea      edx, [rdi+0x01]
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG360
       lea      edx, [rdi+0x01]
       shl      rdx, 4
       lea      r8, bword ptr [rcx+rdx+0x10]
       mov      rcx, r8
       mov      bword ptr [rbp-0x3B0], rcx
       mov      rdx, gword ptr [rbp-0x358]
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      rax, bword ptr [rbp-0x3B0]
       mov      qword ptr [rax+0x08], rcx
       mov      ecx, dword ptr [rbp-0x2EC]
       mov      dword ptr [r12+0x40], ecx
 
G_M000_IG121:                ;; offset=0x11E7
       mov      r13, gword ptr [rbp+0x18]
       lea      rcx, bword ptr [r15+0x20]
       cmp      byte  ptr [r14], r14b
       mov      rcx, gword ptr [rcx]
       cmp      byte  ptr [r14+0x30], 0
       setne    al
       movzx    rax, al
       add      eax, edi
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG360
       shl      rax, 4
       lea      rcx, bword ptr [rcx+rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9CCFB77C8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r12, rax
       mov      dword ptr [rsp+0x20], edi
       mov      gword ptr [rsp+0x28], r12
       lea      rcx, [rbp-0xA8]
       mov      qword ptr [rsp+0x30], rcx
       mov      rcx, r15
       mov      rdx, r13
       mov      r8, rbx
       mov      r9, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       jne      G_M000_IG131
       test     rbx, rbx
       je       G_M000_IG130
       movzx    rcx, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], ecx
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x28], rax
       mov      rcx, rbx
       mov      rdx, r14
       mov      r8d, edi
       mov      r9, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBeginExecutableCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG126
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG123
       mov      gword ptr [rsp+0x20], r12
       mov      dword ptr [rsp+0x28], 1
       lea      rdx, [rbp-0x1E8]
       mov      rcx, rbx
       mov      r8, r14
       mov      r9d, edi
 
G_M000_IG122:                ;; offset=0x12B6
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x1F8]
       lea      rdx, [rbp-0x1E8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r12, rsi
       mov      rdx, gword ptr [rbp-0x1F8]
       mov      rcx, r12
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x1F0]
       mov      qword ptr [r12+0x08], rdx
       mov      r14, gword ptr [rsi]
       test     r14, r14
       je       G_M000_IG58
       jmp      G_M000_IG345
 
G_M000_IG123:                ;; offset=0x12FF
       mov      gword ptr [rsp+0x20], r12
       xor      edx, edx
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp-0xC0]
       mov      rcx, rbx
       mov      r8, r14
       mov      r9d, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rdi, rdx
       movsx    rdx, word  ptr [rbp-0xB8]
       mov      r14d, edx
       test     rdi, rdi
       je       G_M000_IG361
 
G_M000_IG124:                ;; offset=0x133E
       mov      rdx, rdi
       mov      rcx, 0x7FF9CCCFF848
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      G_M000_IG343
 
G_M000_IG125:                ;; offset=0x1359
       mov      rcx, rdi
       mov      edx, r14d
       mov      r11, 0x7FF9CC901F00
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG361
 
G_M000_IG126:                ;; offset=0x1371
       mov      rax, bword ptr [rbp+0x40]
       mov      r12, gword ptr [rax]
       test     r12, r12
       jne      G_M000_IG336
 
G_M000_IG127:                ;; offset=0x1381
       mov      rax, bword ptr [rbp+0x40]
       mov      rdi, gword ptr [rax]
       test     rdi, rdi
       jne      G_M000_IG339
 
G_M000_IG128:                ;; offset=0x1391
       mov      r12, gword ptr [rax+0x08]
 
G_M000_IG129:                ;; offset=0x1395
       cmp      r12, rbx
       jne      G_M000_IG134
       xor      ecx, ecx
       mov      rax, bword ptr [rbp+0x40]
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      qword ptr [rax+0x10], rcx
       mov      rdi, r13
       mov      r14, r15
       jmp      G_M000_IG218
 
G_M000_IG130:                ;; offset=0x13BA
       mov      gword ptr [rsp+0x20], r12
       lea      rcx, [rbp-0x118]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, r15
       mov      rdx, r13
       mov      r8, r14
       mov      r9d, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDeferredChild(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       G_M000_IG149
       cmp      gword ptr [rbp-0x118], 0
       je       G_M000_IG361
       mov      rdx, gword ptr [rbp-0x118]
       xor      rcx, rcx
       mov      rax, bword ptr [rbp+0x40]
       mov      gword ptr [rax], rcx
       lea      rcx, bword ptr [rax+0x08]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp+0x40]
       mov      word  ptr [rax+0x10], 0
       mov      byte  ptr [rax+0x12], 1
       jmp      SHORT G_M000_IG134
 
G_M000_IG131:                ;; offset=0x141C
       cmp      gword ptr [rbp-0xA8], 0
       je       G_M000_IG361
       mov      rdx, gword ptr [rbp-0xA8]
       mov      rcx, 0x7FF9CCD46808
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       test     rdi, rdi
       jne      SHORT G_M000_IG135
       mov      rdx, gword ptr [rbp-0xA8]
       mov      rax, rdx
       test     rax, rax
       je       SHORT G_M000_IG133
 
G_M000_IG132:                ;; offset=0x1457
       mov      rcx, 0x7FF9CCF16E78
       cmp      qword ptr [rax], rcx
       jne      G_M000_IG335
 
G_M000_IG133:                ;; offset=0x146A
       xor      rcx, rcx
       mov      r12, bword ptr [rbp+0x40]
       mov      gword ptr [r12], rcx
       lea      rcx, bword ptr [r12+0x08]
       mov      rdx, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      word  ptr [r12+0x10], 0
       mov      byte  ptr [r12+0x12], 1
 
G_M000_IG134:                ;; offset=0x148F
       mov      rdx, gword ptr [r14+0x18]
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xAC], 3
       jmp      G_M000_IG369
 
G_M000_IG135:                ;; offset=0x14AB
       jmp      G_M000_IG368
 
G_M000_IG136:                ;; offset=0x14B0
       mov      rdx, gword ptr [rbp-0x110]
       mov      rcx, 0x7FF9CCD46808
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       test     rdi, rdi
       jne      SHORT G_M000_IG139
 
G_M000_IG137:                ;; offset=0x14CE
       vmovdqu  xmm0, xmmword ptr [rbp-0x110]
       vmovdqu  xmmword ptr [rbp-0x310], xmm0
 
G_M000_IG138:                ;; offset=0x14DE
       lea      r9, [rbp-0x310]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x350]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG361
 
G_M000_IG139:                ;; offset=0x14FD
       jmp      G_M000_IG368
 
G_M000_IG140:                ;; offset=0x1502
       vmovdqu  xmm0, xmmword ptr [rbp-0x100]
       vmovdqu  xmmword ptr [rbp-0x310], xmm0
 
G_M000_IG141:                ;; offset=0x1512
       lea      r9, [rbp-0x310]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x350]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG361
 
G_M000_IG142:                ;; offset=0x1531
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteBorrowedDictionaryGet(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG361
 
G_M000_IG143:                ;; offset=0x1551
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       mov      rdi, gword ptr [r15]
       mov      r14, gword ptr [r15+0x08]
       mov      rcx, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x27C], eax
       mov      rcx, bword ptr [rbp-0x350]
       mov      r8, gword ptr [rcx]
       mov      gword ptr [rbp-0x360], r8
       mov      rcx, r14
       mov      edx, eax
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadLocalValue(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int):System.Object]
       mov      r14, rax
       test     r14, r14
       jne      SHORT G_M000_IG144
       mov      rcx, rdi
       mov      edx, dword ptr [rbp-0x27C]
       mov      r8, gword ptr [rbp-0x360]
       mov      r9, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r14, rax
 
G_M000_IG144:                ;; offset=0x15B3
       mov      r9, bword ptr [rbp-0x350]
       mov      edi, dword ptr [r9+0x18]
       test     edi, edi
       jl       G_M000_IG46
       lea      rax, bword ptr [r15+0x20]
       mov      bword ptr [rbp-0x368], rax
       mov      rcx, bword ptr [rbp-0x350]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       G_M000_IG47
 
G_M000_IG145:                ;; offset=0x15E4
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       G_M000_IG47
 
G_M000_IG146:                ;; offset=0x15F8
       mov      r8d, edi
       mov      dword ptr [rbp-0x2A4], r8d
       jmp      G_M000_IG48
 
G_M000_IG147:                ;; offset=0x1607
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteCasedSplitMember(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG361
 
G_M000_IG148:                ;; offset=0x1627
       mov      r15, bword ptr [rbp+0x10]
       mov      rdi, gword ptr [rbp+0x18]
       mov      rcx, r15
       mov      rdx, rdi
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryLoadDirectCallReceiver(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG361
       test     rbx, rbx
       jne      G_M000_IG289
 
G_M000_IG149:                ;; offset=0x1656
       mov      r15, bword ptr [rbp+0x10]
       mov      r13, gword ptr [rbp+0x18]
       mov      dword ptr [rbp-0xAC], 6
       jmp      G_M000_IG369
 
G_M000_IG150:                ;; offset=0x166D
       cmp      dword ptr [rbp-0x2F0], 0
       je       G_M000_IG143
       mov      rcx, bword ptr [rbp+0x10]
       mov      edx, dword ptr [rcx+0x60]
       add      rcx, 32
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:CanRetireWithoutCleanup(int):bool:this]
       test     eax, eax
       je       G_M000_IG143
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx]
       mov      rdx, gword ptr [rcx+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG151
       lea      r8, bword ptr [rdx+0x10]
       mov      edx, dword ptr [rdx+0x08]
       jmp      SHORT G_M000_IG152
 
G_M000_IG151:                ;; offset=0x16AC
       xor      r8, r8
       xor      edx, edx
 
G_M000_IG152:                ;; offset=0x16B1
       mov      bword ptr [rbp-0x300], r8
       mov      dword ptr [rbp-0x2F8], edx
       mov      r10d, dword ptr [rbp-0x2F0]
       mov      dword ptr [rsp+0x20], r10d
       mov      rdx, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x28], rdx
       lea      r8, [rbp-0x58]
       mov      qword ptr [rsp+0x30], r8
       lea      r8, [rbp-0x60]
       mov      qword ptr [rsp+0x38], r8
       lea      rdx, [rbp-0x300]
       mov      r8d, dword ptr [rcx+0x10]
       mov      r9d, dword ptr [rcx+0x60]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:TryPrepareFixedTupleReturn(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,byref):bool]
       test     eax, eax
       je       G_M000_IG143
       mov      rcx, bword ptr [rbp+0x10]
       mov      r10d, dword ptr [rbp-0x2F0]
       add      dword ptr [rcx+0x60], r10d
       mov      eax, dword ptr [rbp-0x58]
       mov      dword ptr [rcx+0x10], eax
       cmp      dword ptr [rbp-0x58], edi
       jae      G_M000_IG360
       mov      eax, dword ptr [rbp-0x58]
       shl      rax, 5
       mov      r11, gword ptr [rbp-0x348]
       lea      rdi, bword ptr [r11+rax+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r14, gword ptr [rdx+0xA0]
       mov      r15, gword ptr [rdi]
       cmp      byte  ptr [r14], r14b
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG153
       mov      rcx, r14
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG153:                ;; offset=0x1760
       mov      r9, bword ptr [rbp-0x3A0]
       mov      bword ptr [rbp-0x300], r9
       mov      r10d, dword ptr [rbp-0x2F0]
       mov      dword ptr [rbp-0x2F8], r10d
       mov      rdx, qword ptr [rbp-0x60]
       mov      qword ptr [rsp+0x20], rdx
       lea      r9, [rbp-0x300]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, rdi
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteFixedReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],long)]
       mov      rdi, gword ptr [rbp+0x18]
       mov      r14, bword ptr [rbp+0x10]
       jmp      G_M000_IG237
 
G_M000_IG154:                ;; offset=0x17AA
       test     rbx, rbx
       je       SHORT G_M000_IG157
       cmp      byte  ptr [rbx+0x108], 0
       jne      SHORT G_M000_IG157
       cmp      gword ptr [rbx+0x88], 0
       jne      SHORT G_M000_IG157
       mov      rcx, bword ptr [rbp+0x10]
       cmp      gword ptr [rcx+0x40], 0
       jne      SHORT G_M000_IG157
       mov      rax, gword ptr [rcx]
       mov      rdx, gword ptr [rcx+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG155
       lea      r9, bword ptr [rdx+0x10]
       mov      edx, dword ptr [rdx+0x08]
       jmp      SHORT G_M000_IG156
 
G_M000_IG155:                ;; offset=0x17E2
       xor      r9, r9
       xor      edx, edx
 
G_M000_IG156:                ;; offset=0x17E7
       mov      bword ptr [rbp-0x300], r9
       mov      dword ptr [rbp-0x2F8], edx
       mov      rdx, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rdx
       lea      r9, [rbp-0x50]
       mov      qword ptr [rsp+0x28], r9
       lea      rdx, [rbp-0x300]
       mov      r9d, dword ptr [rcx+0x60]
       lea      r8, bword ptr [rcx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateIntegerCallUpdate(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG166
 
G_M000_IG157:                ;; offset=0x1826
       mov      r9, bword ptr [rbp-0x350]
       mov      r9d, dword ptr [r9+0x18]
       test     r9d, r9d
       jge      SHORT G_M000_IG158
       mov      edx, r9d
       not      edx
       jmp      SHORT G_M000_IG159
 
G_M000_IG158:                ;; offset=0x183D
       mov      edx, r9d
 
G_M000_IG159:                ;; offset=0x1840
       mov      r8, bword ptr [rbp-0x350]
       mov      r8d, dword ptr [r8+0x1C]
       cmp      r8d, 51
       ja       SHORT G_M000_IG163
 
G_M000_IG160:                ;; offset=0x1851
       mov      rcx, 0x7FFFFFFFFF9FF
       bt       rcx, r8
       jb       SHORT G_M000_IG163
 
G_M000_IG161:                ;; offset=0x1861
       test     r9d, r9d
       jge      SHORT G_M000_IG162
       not      r9d
 
G_M000_IG162:                ;; offset=0x1869
       jmp      SHORT G_M000_IG164
 
G_M000_IG163:                ;; offset=0x186B
       mov      r9, bword ptr [rbp-0x350]
       mov      r9d, dword ptr [r9+0x14]
 
G_M000_IG164:                ;; offset=0x1876
       cmp      edx, r9d
       jne      G_M000_IG143
 
G_M000_IG165:                ;; offset=0x187F
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdi, gword ptr [rcx+0x08]
       mov      rcx, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG360
       mov      ecx, eax
       shl      rcx, 4
       cmp      gword ptr [rdi+rcx+0x10], 0
       jne      G_M000_IG361
       jmp      G_M000_IG296
 
G_M000_IG166:                ;; offset=0x18B4
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9d, dword ptr [rcx+0x10]
       cmp      r9d, edi
       jae      G_M000_IG360
       shl      r9, 5
       mov      r11, gword ptr [rbp-0x348]
       lea      r8, bword ptr [r11+r9+0x10]
       mov      rdi, gword ptr [rbp-0x50]
       mov      r14, qword ptr [rbp-0x48]
       mov      r15d, dword ptr [r8+0x18]
       test     r15d, r15d
       jge      SHORT G_M000_IG167
       mov      gword ptr [rbp-0x310], rdi
       mov      qword ptr [rbp-0x308], r14
       lea      r9, [rbp-0x310]
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG361
 
G_M000_IG167:                ;; offset=0x1909
       lea      r13, bword ptr [rcx+0x20]
       mov      edx, dword ptr [r8+0x1C]
       cmp      edx, 51
       ja       SHORT G_M000_IG170
 
G_M000_IG168:                ;; offset=0x1916
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG170
 
G_M000_IG169:                ;; offset=0x1926
       mov      r12d, r15d
       jmp      SHORT G_M000_IG171
 
G_M000_IG170:                ;; offset=0x192B
       mov      r12d, dword ptr [r8+0x14]
 
G_M000_IG171:                ;; offset=0x192F
       cmp      r15d, dword ptr [r13+0x40]
       jge      SHORT G_M000_IG172
       mov      rcx, r13
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG172:                ;; offset=0x1941
       mov      rdx, gword ptr [r13]
       cmp      r12d, dword ptr [rdx+0x08]
       jae      G_M000_IG360
       mov      eax, r12d
       shl      rax, 4
       lea      r12, bword ptr [rdx+rax+0x10]
       mov      rcx, r12
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r12+0x08], r14
       mov      dword ptr [r13+0x40], r15d
       jmp      G_M000_IG361
 
G_M000_IG173:                ;; offset=0x1974
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x20]
       mov      r8, bword ptr [rbp-0x350]
       mov      r8d, dword ptr [r8+0x10]
       mov      rax, bword ptr [rbp-0x350]
       mov      eax, dword ptr [rax+0x08]
       test     rdx, rdx
       je       SHORT G_M000_IG174
       mov      r10d, r8d
       mov      r9d, eax
       add      r10, r9
       mov      r9d, dword ptr [rdx+0x08]
       cmp      r10, r9
       ja       G_M000_IG309
       shl      r8, 4
       lea      rdx, bword ptr [rdx+r8+0x10]
       jmp      SHORT G_M000_IG175
 
G_M000_IG174:                ;; offset=0x19B7
       or       r8d, eax
       jne      G_M000_IG309
       xor      rdx, rdx
       xor      eax, eax
 
G_M000_IG175:                ;; offset=0x19C4
       mov      bword ptr [rbp-0x300], rdx
       mov      dword ptr [rbp-0x2F8], eax
       lea      rcx, [rbp-0x300]
       mov      rdx, gword ptr [rbp+0x18]
       mov      rdx, gword ptr [rdx+0xA0]
       mov      r8, bword ptr [rbp-0x350]
       mov      r8, gword ptr [r8]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReverseAssignmentValues(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.ExecutionState,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG361
 
G_M000_IG176:                ;; offset=0x19F8
       mov      rcx, bword ptr [rbp+0x10]
       lea      r8, bword ptr [rcx+0x20]
       cmp      r14d, 51
       ja       SHORT G_M000_IG180
 
G_M000_IG177:                ;; offset=0x1A06
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, r14
       jb       SHORT G_M000_IG180
 
G_M000_IG178:                ;; offset=0x1A16
       mov      rdx, bword ptr [rbp-0x350]
       mov      edi, dword ptr [rdx+0x18]
       test     edi, edi
       jge      SHORT G_M000_IG179
       not      edi
 
G_M000_IG179:                ;; offset=0x1A26
       jmp      SHORT G_M000_IG181
 
G_M000_IG180:                ;; offset=0x1A28
       mov      rdx, bword ptr [rbp-0x350]
       mov      edi, dword ptr [rdx+0x14]
 
G_M000_IG181:                ;; offset=0x1A32
       mov      rdx, bword ptr [rbp-0x350]
       mov      edx, dword ptr [rdx+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG182
       mov      r9d, edx
       not      r9d
       jmp      SHORT G_M000_IG183
 
G_M000_IG182:                ;; offset=0x1A48
       mov      r9d, edx
 
G_M000_IG183:                ;; offset=0x1A4B
       lea      rdx, [rbp-0x78]
       mov      rcx, r8
       mov      r8d, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       je       SHORT G_M000_IG184
       lea      rdx, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
       jmp      SHORT G_M000_IG185
 
G_M000_IG184:                ;; offset=0x1A72
       xor      rdx, rdx
       xor      r8d, r8d
 
G_M000_IG185:                ;; offset=0x1A77
       mov      r9, rbx
       test     r9, r9
       jne      SHORT G_M000_IG186
       mov      rdi, gword ptr [rbp+0x18]
       mov      r9, rdi
 
G_M000_IG186:                ;; offset=0x1A86
       mov      rdi, gword ptr [rbp+0x18]
       mov      r9, gword ptr [r9+0xA0]
       mov      rax, bword ptr [rbp-0x350]
       mov      eax, dword ptr [rax+0x10]
       cmp      eax, r8d
       jae      G_M000_IG360
       mov      r8d, eax
       shl      r8, 4
       add      r8, rdx
 
G_M000_IG187:                ;; offset=0x1AAE
       vmovdqu  xmm0, xmmword ptr [rbp-0x78]
       vmovdqu  xmmword ptr [rbp-0x310], xmm0
 
G_M000_IG188:                ;; offset=0x1ABB
       mov      rcx, r8
       lea      r8, [rbp-0x310]
       mov      rdx, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(byref,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG361
 
G_M000_IG189:                ;; offset=0x1AD7
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx]
       mov      r14, gword ptr [rax+0x30]
       mov      rcx, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [r14+0x08]
       jae      G_M000_IG360
       mov      edx, eax
       mov      rdx, gword ptr [r14+8*rdx+0x10]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG191
 
G_M000_IG190:                ;; offset=0x1B08
       mov      rax, 0x7FF9CCE0ABA8
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG308
 
G_M000_IG191:                ;; offset=0x1B1B
       mov      r14, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [r14+0x20]
       mov      r8, bword ptr [rbp-0x350]
       mov      r8d, dword ptr [r8+0x1C]
       mov      r9d, r8d
       cmp      r9d, 51
       ja       SHORT G_M000_IG195
 
G_M000_IG192:                ;; offset=0x1B37
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, r9
       jb       SHORT G_M000_IG195
 
G_M000_IG193:                ;; offset=0x1B47
       mov      r9, bword ptr [rbp-0x350]
       mov      r9d, dword ptr [r9+0x18]
       test     r9d, r9d
       jge      SHORT G_M000_IG194
       not      r9d
 
G_M000_IG194:                ;; offset=0x1B5A
       jmp      SHORT G_M000_IG196
 
G_M000_IG195:                ;; offset=0x1B5C
       mov      r9, bword ptr [rbp-0x350]
       mov      r9d, dword ptr [r9+0x14]
 
G_M000_IG196:                ;; offset=0x1B67
       mov      rax, bword ptr [rbp-0x350]
       mov      eax, dword ptr [rax+0x18]
       test     eax, eax
       jge      SHORT G_M000_IG197
       mov      r10d, eax
       not      r10d
       jmp      SHORT G_M000_IG198
 
G_M000_IG197:                ;; offset=0x1B7D
       mov      r10d, eax
 
G_M000_IG198:                ;; offset=0x1B80
       cmp      r8d, 51
       ja       SHORT G_M000_IG203
 
G_M000_IG199:                ;; offset=0x1B86
       mov      r11, 0x7FFFFFFFFF9FF
       bt       r11, r8
       jb       SHORT G_M000_IG203
 
G_M000_IG200:                ;; offset=0x1B96
       test     eax, eax
       jge      SHORT G_M000_IG201
       mov      r8d, eax
       not      r8d
       jmp      SHORT G_M000_IG202
 
G_M000_IG201:                ;; offset=0x1BA2
       mov      r8d, eax
 
G_M000_IG202:                ;; offset=0x1BA5
       jmp      SHORT G_M000_IG204
 
G_M000_IG203:                ;; offset=0x1BA7
       mov      r8, bword ptr [rbp-0x350]
       mov      r8d, dword ptr [r8+0x14]
 
G_M000_IG204:                ;; offset=0x1BB2
       sub      r10d, r8d
       test     rdx, rdx
       je       SHORT G_M000_IG205
       mov      r8d, r9d
       mov      eax, r10d
       add      r8, rax
       mov      eax, dword ptr [rdx+0x08]
       cmp      r8, rax
       ja       G_M000_IG309
       mov      r9d, r9d
       shl      r9, 4
       lea      rdx, bword ptr [rdx+r9+0x10]
       jmp      SHORT G_M000_IG206
 
G_M000_IG205:                ;; offset=0x1BDD
       or       r9d, r10d
       jne      G_M000_IG309
       xor      rdx, rdx
       xor      r10d, r10d
 
G_M000_IG206:                ;; offset=0x1BEB
       mov      r8, bword ptr [rbp-0x350]
       cmp      dword ptr [r8+0x0C], 0
       setne    r8b
       movzx    r8, r8b
       mov      r9, rbx
       test     r9, r9
       jne      SHORT G_M000_IG207
       mov      rdi, gword ptr [rbp+0x18]
       mov      r9, rdi
 
G_M000_IG207:                ;; offset=0x1C0E
       mov      rdi, gword ptr [rbp+0x18]
       mov      bword ptr [rbp-0x300], rdx
       mov      dword ptr [rbp-0x2F8], r10d
       mov      rdx, bword ptr [rbp-0x350]
       mov      rdx, gword ptr [rdx]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0x300]
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       lea      rdx, bword ptr [r14+0x20]
       mov      rcx, bword ptr [rbp-0x350]
       mov      ecx, dword ptr [rcx+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG208
       not      ecx
 
G_M000_IG208:                ;; offset=0x1C50
       mov      dword ptr [rdx+0x40], ecx
       jmp      G_M000_IG361
 
G_M000_IG209:                ;; offset=0x1C58
       mov      rdi, gword ptr [rbp+0x18]
       test     rbx, rbx
       je       G_M000_IG213
       mov      r14, bword ptr [rbp+0x10]
       mov      r15d, dword ptr [r14+0x60]
       mov      rcx, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      r15d, eax
       jne      G_M000_IG213
       mov      rcx, gword ptr [r14+0x20]
       mov      rax, bword ptr [rbp-0x350]
       mov      eax, dword ptr [rax+0x10]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG360
       shl      rax, 4
       mov      r15, gword ptr [rcx+rax+0x10]
       test     r15, r15
       je       G_M000_IG213
 
G_M000_IG210:                ;; offset=0x1CAC
       mov      rcx, 0x7FF9CCFB7330
       cmp      qword ptr [r15], rcx
       jne      G_M000_IG213
 
G_M000_IG211:                ;; offset=0x1CBF
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:get_NativeCsvSource():Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:this]
       test     rax, rax
       je       G_M000_IG213
       cmp      gword ptr [rax+0x20], 0
       je       G_M000_IG213
       mov      rdx, bword ptr [rbp-0x350]
       mov      bword ptr [rsp+0x20], rdx
       movzx    rdx, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp-0x178]
       mov      rcx, rbx
       mov      r8, rax
       mov      r9, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AdvanceCsvUnpack(Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource,Lokad.Lython.Runtime.PyIteration+Cursor,byref,bool):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r15, rsi
       mov      rdx, gword ptr [rbp-0x178]
       mov      rcx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x170]
       mov      qword ptr [r15+0x08], rdx
       mov      r15, gword ptr [rsi]
       test     r15, r15
       je       G_M000_IG230
       jmp      G_M000_IG328
 
G_M000_IG212:                ;; offset=0x1D34
       mov      rdi, gword ptr [rbp+0x18]
       mov      r14, bword ptr [rbp+0x10]
       mov      rcx, r14
       mov      rdx, rdi
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG218
 
G_M000_IG213:                ;; offset=0x1D5A
       mov      r14, bword ptr [rbp+0x10]
       mov      rdi, gword ptr [rbp+0x18]
       mov      rdx, bword ptr [rbp-0x350]
       mov      edx, dword ptr [rdx+0x10]
       lea      rcx, bword ptr [r14+0x20]
       lea      r8, [rbp-0x90]
       lea      r9, [rbp-0xA0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryAdvanceNativeIteration(int,byref,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG217
       test     rbx, rbx
       je       G_M000_IG149
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG216
       mov      r8, bword ptr [rbp-0x350]
 
G_M000_IG214:                ;; offset=0x1DA2
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x330], ymm0
 
G_M000_IG215:                ;; offset=0x1DAF
       lea      r8, [rbp-0x330]
       lea      rdx, [rbp-0x208]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNextAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r15, rsi
       mov      rdx, gword ptr [rbp-0x208]
       mov      rcx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x200]
       mov      qword ptr [r15+0x08], rdx
       mov      r15, gword ptr [rsi]
       test     r15, r15
       je       G_M000_IG230
       jmp      G_M000_IG331
 
G_M000_IG216:                ;; offset=0x1DF4
       mov      rcx, rbx
       mov      rdx, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNext(byref):bool:this]
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG361
 
G_M000_IG217:                ;; offset=0x1E0C
       cmp      byte  ptr [rbp-0x90], 0
       jne      SHORT G_M000_IG219
       mov      rdx, bword ptr [rbp-0x350]
       mov      edx, dword ptr [rdx+0x10]
       lea      rcx, bword ptr [r14+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      dword ptr [r14+0x10], eax
 
G_M000_IG218:                ;; offset=0x1E3A
       mov      dword ptr [rbp-0x3C], 1
       jmp      G_M000_IG361
 
G_M000_IG219:                ;; offset=0x1E46
       vmovdqu  xmm0, xmmword ptr [rbp-0xA0]
       vmovdqu  xmmword ptr [rbp-0x310], xmm0
 
G_M000_IG220:                ;; offset=0x1E56
       lea      r9, [rbp-0x310]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x350]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG361
 
G_M000_IG221:                ;; offset=0x1E75
       mov      r14, bword ptr [rbp+0x10]
       lea      r15, bword ptr [r14+0x20]
       mov      rdx, bword ptr [rbp-0x350]
       mov      r8d, dword ptr [rdx+0x10]
       mov      rcx, gword ptr [r14]
       mov      rdx, gword ptr [r14+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG222
       lea      r9, bword ptr [rdx+0x10]
       mov      edx, dword ptr [rdx+0x08]
       jmp      SHORT G_M000_IG223
 
G_M000_IG222:                ;; offset=0x1E9D
       xor      r9, r9
       xor      edx, edx
 
G_M000_IG223:                ;; offset=0x1EA2
       mov      bword ptr [rbp-0x300], r9
       mov      dword ptr [rbp-0x2F8], edx
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdi, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x28], rdi
       mov      rdx, gword ptr [r14+0x18]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rbp-0x300]
       mov      r9d, dword ptr [r14+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      r13, rax
       mov      rcx, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      r8d, eax
       mov      rcx, bword ptr [rbp-0x350]
       mov      r9d, dword ptr [rcx+0x18]
       test     r9d, r9d
       jge      SHORT G_M000_IG224
       not      r9d
 
G_M000_IG224:                ;; offset=0x1EFE
       mov      rcx, bword ptr [rbp-0x350]
       mov      rcx, gword ptr [rcx]
       mov      gword ptr [rsp+0x20], rcx
       mov      rcx, r15
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryPrepareNativeIteration(System.Object,int,int,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      G_M000_IG361
       test     rbx, rbx
       je       G_M000_IG149
       cmp      byte  ptr [rbp+0x28], 0
       je       G_M000_IG93
       mov      r8, bword ptr [rbp-0x350]
 
G_M000_IG225:                ;; offset=0x1F3B
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x330], ymm0
 
G_M000_IG226:                ;; offset=0x1F48
       lea      r8, [rbp-0x330]
       lea      rdx, [rbp-0x218]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteGetIteratorAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x228]
       lea      rdx, [rbp-0x218]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r15, rsi
       mov      rdx, gword ptr [rbp-0x228]
       mov      rcx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x220]
       mov      qword ptr [r15+0x08], rdx
       mov      r15, gword ptr [rsi]
       test     r15, r15
       je       G_M000_IG58
       jmp      G_M000_IG348
 
G_M000_IG227:                ;; offset=0x1FA1
       mov      r14, bword ptr [rbp+0x10]
       test     rbx, rbx
       je       G_M000_IG149
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG232
       mov      r8, bword ptr [rbp-0x350]
 
G_M000_IG228:                ;; offset=0x1FBB
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x330], ymm0
 
G_M000_IG229:                ;; offset=0x1FC8
       lea      r8, [rbp-0x330]
       lea      rdx, [rbp-0x238]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteContextManagerAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r15, rsi
       mov      rdx, gword ptr [rbp-0x238]
       mov      rcx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x230]
       mov      qword ptr [r15+0x08], rdx
       mov      r15, gword ptr [rsi]
       test     r15, r15
       jne      G_M000_IG325
 
G_M000_IG230:                ;; offset=0x2008
       mov      r14, bword ptr [rbp+0x10]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG361
 
G_M000_IG231:                ;; offset=0x201D
       mov      r14, bword ptr [rbp+0x10]
       test     rbx, rbx
       je       G_M000_IG149
 
G_M000_IG232:                ;; offset=0x202A
       mov      rcx, rbx
       mov      rdx, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteStructure(byref):bool:this]
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG361
 
G_M000_IG233:                ;; offset=0x2042
       mov      r14, bword ptr [rbp+0x10]
       test     rbx, rbx
       je       SHORT G_M000_IG234
       mov      rcx, rbx
       mov      rdx, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryStageUnpackedFrameReturn(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG266
 
G_M000_IG234:                ;; offset=0x2063
       cmp      dword ptr [rbp-0x2F0], 0
       je       SHORT G_M000_IG235
       mov      rcx, r14
       mov      rdx, bword ptr [rbp-0x350]
       mov      r8d, dword ptr [rbp-0x2F0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CanForwardFixedReturn(byref,byref,int):bool]
       test     eax, eax
       jne      SHORT G_M000_IG236
 
G_M000_IG235:                ;; offset=0x2087
       lea      r15, bword ptr [r14+0x20]
       mov      rcx, bword ptr [rbp-0x350]
       mov      r13d, dword ptr [rcx+0x10]
       mov      rcx, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      r8d, eax
       mov      rdi, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rdi
       mov      edx, r13d
       mov      rcx, r15
       mov      r9, bword ptr [rbp-0x350]
       mov      r9, gword ptr [r9]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTupleFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyTuple]
       mov      gword ptr [rbp-0x310], rax
       xor      r9d, r9d
       mov      qword ptr [rbp-0x308], r9
       lea      r9, [rbp-0x310]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x350]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG361
 
G_M000_IG236:                ;; offset=0x20F5
       mov      rdi, gword ptr [rbp+0x18]
       mov      r9, bword ptr [rbp-0x3A0]
       mov      bword ptr [rbp-0x300], r9
       mov      r8d, dword ptr [rbp-0x2F0]
       mov      dword ptr [rbp-0x2F8], r8d
       lea      r9, [rbp-0x300]
       mov      rdx, rdi
       mov      r8, bword ptr [rbp-0x350]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CopyFixedReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
 
G_M000_IG237:                ;; offset=0x212F
       mov      dword ptr [rbp-0xAC], 2
       jmp      G_M000_IG369
 
G_M000_IG238:                ;; offset=0x213E
       mov      r14, bword ptr [rbp+0x10]
       mov      r9, rbx
       test     r9, r9
       jne      SHORT G_M000_IG239
       mov      rdi, gword ptr [rbp+0x18]
       mov      r9, rdi
 
G_M000_IG239:                ;; offset=0x2151
       mov      rcx, r14
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteFormattedInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      G_M000_IG361
       test     rbx, rbx
       je       G_M000_IG149
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG242
       mov      r8, bword ptr [rbp-0x350]
 
G_M000_IG240:                ;; offset=0x2182
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x330], ymm0
 
G_M000_IG241:                ;; offset=0x218F
       lea      r8, [rbp-0x330]
       lea      rdx, [rbp-0x188]
       mov      rcx, rbx
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x198]
       lea      rdx, [rbp-0x188]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r15, rsi
       mov      rdx, gword ptr [rbp-0x198]
       mov      rcx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x190]
       mov      qword ptr [r15+0x08], rdx
       mov      r15, gword ptr [rsi]
       test     r15, r15
       je       G_M000_IG58
       jmp      G_M000_IG305
 
G_M000_IG242:                ;; offset=0x21EE
       mov      r8, bword ptr [rbp-0x350]
 
G_M000_IG243:                ;; offset=0x21F5
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x330], ymm0
 
G_M000_IG244:                ;; offset=0x2202
       lea      r8, [rbp-0x330]
       lea      rdx, [rbp-0xC0]
       mov      rcx, rbx
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       mov      r15, gword ptr [rbp-0xC0]
       movsx    r13, word  ptr [rbp-0xB8]
       test     r15, r15
       je       G_M000_IG361
 
G_M000_IG245:                ;; offset=0x2234
       mov      rdx, r15
       mov      rcx, 0x7FF9CCCFF848
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      G_M000_IG303
 
G_M000_IG246:                ;; offset=0x224F
       mov      rcx, r15
       mov      edx, r13d
       mov      r11, 0x7FF9CC901E98
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG361
 
G_M000_IG247:                ;; offset=0x2267
       test     rbx, rbx
       je       G_M000_IG149
       cmp      byte  ptr [rbp+0x28], 0
       jne      G_M000_IG261
       cmp      gword ptr [rbx+0x68], 0
       jne      G_M000_IG253
       mov      r15, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [r15+0x20]
       mov      rdx, bword ptr [rbp-0x350]
       mov      edx, dword ptr [rdx+0x10]
       mov      r8d, r14d
       cmp      r8d, 51
       ja       SHORT G_M000_IG251
 
G_M000_IG248:                ;; offset=0x22A0
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, r8
       jb       SHORT G_M000_IG251
 
G_M000_IG249:                ;; offset=0x22B0
       mov      r8, bword ptr [rbp-0x350]
       mov      r8d, dword ptr [r8+0x18]
       test     r8d, r8d
       jge      SHORT G_M000_IG250
       not      r8d
 
G_M000_IG250:                ;; offset=0x22C3
       jmp      SHORT G_M000_IG252
 
G_M000_IG251:                ;; offset=0x22C5
       mov      r8, bword ptr [rbp-0x350]
       mov      r8d, dword ptr [r8+0x14]
 
G_M000_IG252:                ;; offset=0x22D0
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      r14, rax
       mov      rcx, 0x7FF9CC9C2560
       mov      edx, 1
       call     CORINFO_HELP_NEWARR_1_PTR
       mov      r13, rax
       lea      rcx, bword ptr [r13+0x10]
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdx, bword ptr [rbp-0x350]
       mov      rdx, gword ptr [rdx]
       mov      rcx, r13
       mov      r8, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:Iter(System.Object[],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r14, rax
       mov      rcx, 0x7FF9CCFBB390
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       mov      rcx, bword ptr [rbp-0x350]
       mov      r12, gword ptr [rcx]
       lea      rcx, bword ptr [r13+0x08]
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [r13+0x10]
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [r13+0x18]
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, 0x22D380012A0
       mov      rdx, gword ptr [rcx]
       lea      rcx, bword ptr [r13+0x20]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [rbx+0x68]
       mov      rdx, r13
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG253:                ;; offset=0x2377
       mov      rcx, gword ptr [rbx+0x68]
       mov      r8, gword ptr [rbx+0x58]
       mov      r9, gword ptr [rbx+0x60]
       cmp      byte  ptr [rcx], cl
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       lea      rdx, [rbp-0x2C8]
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:AdvanceAsync(System.Object,Lokad.Lython.Runtime.LythonRuntimeException,bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       mov      r14, gword ptr [rbp-0x2C8]
       movsx    r13, word  ptr [rbp-0x2C0]
       test     r14, r14
       je       SHORT G_M000_IG257
       mov      rdx, r14
       mov      rcx, 0x7FF9CCFD8358
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r12, rax
       test     r12, r12
       jne      SHORT G_M000_IG254
       lea      rdx, [rbp-0x2D8]
       mov      rcx, r14
       mov      r8d, r13d
       mov      r11, 0x7FF9CC901EC0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[Lokad.Lython.Runtime.PyIterationResult]:GetResult(short):Lokad.Lython.Runtime.PyIterationResult:this
       jmp      SHORT G_M000_IG258
 
G_M000_IG254:                ;; offset=0x23E2
       mov      ecx, dword ptr [r12+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       jne      G_M000_IG318
 
G_M000_IG255:                ;; offset=0x23F9
       vmovdqu  xmm0, xmmword ptr [r12+0x38]
       vmovdqu  xmmword ptr [rbp-0x2D8], xmm0
 
G_M000_IG256:                ;; offset=0x2408
       jmp      SHORT G_M000_IG258
 
G_M000_IG257:                ;; offset=0x240A
       vmovdqu  xmm0, xmmword ptr [rbp-0x2B8]
       vmovdqu  xmmword ptr [rbp-0x2D8], xmm0
 
G_M000_IG258:                ;; offset=0x241A
       mov      r8, bword ptr [rbp-0x350]
 
G_M000_IG259:                ;; offset=0x2421
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x330], ymm0
 
G_M000_IG260:                ;; offset=0x242E
       lea      r8, [rbp-0x330]
       lea      rdx, [rbp-0x2D8]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteDelegatedStep(Lokad.Lython.Runtime.PyIterationResult,Lokad.Lython.Frontend.ExecutableInstruction):this]
       jmp      SHORT G_M000_IG265
 
G_M000_IG261:                ;; offset=0x2447
       mov      r8, bword ptr [rbp-0x350]
 
G_M000_IG262:                ;; offset=0x244E
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x330], ymm0
 
G_M000_IG263:                ;; offset=0x245B
       lea      r8, [rbp-0x330]
       lea      rdx, [rbp-0x1A8]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteDelegationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r14, rsi
       mov      rdx, gword ptr [rbp-0x1A8]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x1A0]
       mov      qword ptr [r14+0x08], rdx
       mov      r14, gword ptr [rsi]
       test     r14, r14
       jne      G_M000_IG315
 
G_M000_IG264:                ;; offset=0x249B
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
 
G_M000_IG265:                ;; offset=0x24A4
       cmp      byte  ptr [rbx+0x101], 0
       je       G_M000_IG361
       mov      rdx, gword ptr [rbx+0x70]
       test     rdx, rdx
       je       SHORT G_M000_IG266
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       jne      G_M000_IG363
 
G_M000_IG266:                ;; offset=0x24CB
       mov      r15, bword ptr [rbp+0x10]
       mov      dword ptr [rbp-0xAC], 1
       jmp      G_M000_IG369
 
G_M000_IG267:                ;; offset=0x24DE
       mov      r15, bword ptr [rbp+0x10]
       lea      r14, bword ptr [r15+0x20]
       mov      rcx, bword ptr [rbp-0x350]
       mov      r13d, dword ptr [rcx+0x10]
       mov      rcx, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      r8d, eax
       mov      rdi, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rdi
       mov      edx, r13d
       mov      rcx, r14
       mov      r9, bword ptr [rbp-0x350]
       mov      r9, gword ptr [r9]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateListFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x310], rax
       xor      r9d, r9d
       mov      qword ptr [rbp-0x308], r9
       lea      r9, [rbp-0x310]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x350]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG361
 
G_M000_IG268:                ;; offset=0x2550
       mov      rdi, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r15+0x20]
       mov      rax, bword ptr [rbp-0x350]
       mov      eax, dword ptr [rax+0x10]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG360
       shl      rax, 4
       lea      rcx, bword ptr [rcx+rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9CCFB77C8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       lea      rcx, bword ptr [r15+0x20]
       mov      rdx, bword ptr [rbp-0x350]
       mov      edx, dword ptr [rdx+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG269
       not      edx
 
G_M000_IG269:                ;; offset=0x25A5
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       jmp      G_M000_IG361
 
G_M000_IG270:                ;; offset=0x25B0
       mov      rdi, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       lea      r13, bword ptr [r15+0x20]
       mov      ecx, r14d
       cmp      ecx, 51
       ja       SHORT G_M000_IG275
 
G_M000_IG271:                ;; offset=0x25C4
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jb       SHORT G_M000_IG275
 
G_M000_IG272:                ;; offset=0x25D4
       mov      rcx, bword ptr [rbp-0x350]
       mov      edx, dword ptr [rcx+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG273
       mov      r14d, edx
       not      r14d
       jmp      SHORT G_M000_IG274
 
G_M000_IG273:                ;; offset=0x25EA
       mov      r14d, edx
 
G_M000_IG274:                ;; offset=0x25ED
       jmp      SHORT G_M000_IG276
 
G_M000_IG275:                ;; offset=0x25EF
       mov      rdx, bword ptr [rbp-0x350]
       mov      r14d, dword ptr [rdx+0x14]
 
G_M000_IG276:                ;; offset=0x25FA
       inc      r14d
       mov      rcx, bword ptr [rbp-0x350]
       mov      edx, dword ptr [rcx+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG277
       mov      r12d, edx
       not      r12d
       jmp      SHORT G_M000_IG278
 
G_M000_IG277:                ;; offset=0x2613
       mov      r12d, edx
 
G_M000_IG278:                ;; offset=0x2616
       mov      rcx, gword ptr [r15+0x20]
       mov      rax, bword ptr [rbp-0x350]
       mov      eax, dword ptr [rax+0x10]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG360
       shl      rax, 4
       lea      rcx, bword ptr [rcx+rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9CCFB77C8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x390], rax
       cmp      r12d, dword ptr [r13+0x40]
       jl       SHORT G_M000_IG280
 
G_M000_IG279:                ;; offset=0x265C
       mov      rax, gword ptr [rbp-0x390]
       jmp      SHORT G_M000_IG281
 
G_M000_IG280:                ;; offset=0x2665
       mov      rcx, r13
       mov      edx, r12d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, gword ptr [rbp-0x390]
 
G_M000_IG281:                ;; offset=0x2678
       mov      rcx, gword ptr [r13]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG360
       mov      edx, r14d
       shl      rdx, 4
       lea      r14, bword ptr [rcx+rdx+0x10]
       mov      rcx, r14
       mov      rdx, rax
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r14+0x08], rcx
       mov      dword ptr [r13+0x40], r12d
       jmp      G_M000_IG361
 
G_M000_IG282:                ;; offset=0x26AC
       mov      rdi, gword ptr [rbp+0x18]
       test     rbx, rbx
       je       G_M000_IG149
       mov      r15, bword ptr [rbp+0x10]
       mov      r14, gword ptr [r15]
       mov      r13, gword ptr [r15+0x08]
       mov      rcx, gword ptr [r15]
       mov      r12, gword ptr [rcx+0x38]
       mov      rcx, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [r12+0x08]
       jae      G_M000_IG360
       mov      ecx, eax
       mov      r12, gword ptr [r12+8*rcx+0x10]
       lea      rcx, bword ptr [r15+0x20]
       mov      rdx, bword ptr [rbp-0x350]
       mov      edx, dword ptr [rdx+0x10]
       mov      r8, bword ptr [rbp-0x350]
       mov      r8d, dword ptr [r8+0x18]
       test     r8d, r8d
       jge      SHORT G_M000_IG283
       not      r8d
 
G_M000_IG283:                ;; offset=0x270B
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      r9, rax
       mov      gword ptr [rsp+0x20], rbx
       mov      rdx, bword ptr [rbp-0x350]
       mov      rdx, gword ptr [rdx]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, r13
       mov      r8, r12
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:AssignExecutableBoundName(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG361
 
G_M000_IG284:                ;; offset=0x273C
       mov      rdi, gword ptr [rbp+0x18]
       test     rbx, rbx
       je       G_M000_IG149
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r15]
       mov      r14, gword ptr [rcx+0x38]
       mov      rcx, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [r14+0x08]
       jae      G_M000_IG360
       mov      ecx, eax
       mov      r14, gword ptr [r14+8*rcx+0x10]
       lea      rcx, bword ptr [r15+0x20]
       mov      rdx, bword ptr [rbp-0x350]
       mov      edx, dword ptr [rdx+0x10]
       mov      r8, bword ptr [rbp-0x350]
       mov      r8d, dword ptr [r8+0x18]
       test     r8d, r8d
       jge      SHORT G_M000_IG285
       not      r8d
 
G_M000_IG285:                ;; offset=0x2793
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      rdx, rax
       mov      r9, bword ptr [rbp-0x350]
       mov      r9, gword ptr [r9]
       mov      rcx, r14
       mov      r8, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreName(System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG361
 
G_M000_IG286:                ;; offset=0x27B7
       mov      rdi, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, r15
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryStoreClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG361
       jmp      G_M000_IG149
 
G_M000_IG287:                ;; offset=0x27DF
       mov      rdi, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, r15
       mov      rdx, rdi
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:StoreExecutableLocal(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG361
 
G_M000_IG288:                ;; offset=0x2802
       mov      rdi, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       test     rbx, rbx
       je       G_M000_IG149
       mov      rdx, bword ptr [rbp-0x350]
       mov      rdx, gword ptr [rdx]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:PreloadImplicitSuperArguments(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG361
 
G_M000_IG289:                ;; offset=0x282B
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG292
       mov      r8, bword ptr [rbp-0x350]
 
G_M000_IG290:                ;; offset=0x2838
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x330], ymm0
 
G_M000_IG291:                ;; offset=0x2845
       lea      r8, [rbp-0x330]
       lea      rdx, [rbp-0x248]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteMemberLoadAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r14, rsi
       mov      rdx, gword ptr [rbp-0x248]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x240]
       mov      qword ptr [r14+0x08], rdx
       mov      r14, gword ptr [rsi]
       test     r14, r14
       je       G_M000_IG58
       jmp      G_M000_IG322
 
G_M000_IG292:                ;; offset=0x288A
       mov      rcx, r15
       mov      rdx, rdi
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSynchronousMemberLoad(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG361
 
G_M000_IG293:                ;; offset=0x28A5
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x168], ymm0
       vmovdqu  xmmword ptr [rbp-0x150], xmm0
       lea      rcx, [rbp-0x168]
       mov      edx, 27
       mov      r8d, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
 
G_M000_IG294:                ;; offset=0x28D1
       vmovdqu  ymm0, ymmword ptr [rbp-0x168]
       vmovdqu  ymmword ptr [rbp-0x140], ymm0
       mov      rcx, qword ptr [rbp-0x148]
       mov      qword ptr [rbp-0x120], rcx
 
G_M000_IG295:                ;; offset=0x28EF
       mov      ecx, dword ptr [rbp-0x130]
       cmp      ecx, dword ptr [rbp-0x120]
       jbe      G_M000_IG357
       jmp      G_M000_IG309
 
G_M000_IG296:                ;; offset=0x2906
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx]
       mov      rdi, gword ptr [rax+0x68]
       mov      rcx, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      edx, eax
       mov      rcx, rdi
       mov      r11, 0x7FF9CC901E70
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rcx, rax
       mov      rdx, bword ptr [rbp-0x350]
       mov      rdx, gword ptr [rdx]
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG297:                ;; offset=0x294C
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG361
 
G_M000_IG298:                ;; offset=0x2961
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG361
 
G_M000_IG299:                ;; offset=0x2971
       mov      rdx, rdi
       mov      rcx, 0x7FF9CCFD2F90
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG300
       test     dword ptr [rax+0x34], 0x1600000
       setne    r14b
       movzx    r14, r14b
       jmp      SHORT G_M000_IG301
 
G_M000_IG300:                ;; offset=0x2999
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, rdi
       mov      r11, 0x7FF9CC901E90
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r14b
       movzx    r14, r14b
 
G_M000_IG301:                ;; offset=0x29B8
       test     r14d, r14d
       jne      G_M000_IG58
 
G_M000_IG302:                ;; offset=0x29C1
       mov      r15, bword ptr [rbp+0x10]
       mov      r13, gword ptr [rbp+0x18]
       mov      rcx, bword ptr [rbp-0x350]
       mov      rdx, gword ptr [rcx]
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xAC], 4
       jmp      G_M000_IG369
 
G_M000_IG303:                ;; offset=0x29EB
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG361
 
G_M000_IG304:                ;; offset=0x2A00
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG361
 
G_M000_IG305:                ;; offset=0x2A10
       mov      rdx, r15
       mov      rcx, 0x7FF9CCFD2F90
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG306
       test     dword ptr [rax+0x34], 0x1600000
       setne    r13b
       movzx    r13, r13b
       jmp      SHORT G_M000_IG307
 
G_M000_IG306:                ;; offset=0x2A38
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, r15
       mov      r11, 0x7FF9CC901EA0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r13b
       movzx    r13, r13b
 
G_M000_IG307:                ;; offset=0x2A57
       test     r13d, r13d
       jne      G_M000_IG58
       jmp      G_M000_IG302
 
G_M000_IG308:                ;; offset=0x2A65
       mov      rdi, gword ptr [rbp+0x18]
       mov      rcx, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG309:                ;; offset=0x2A72
       mov      r14, bword ptr [rbp+0x10]
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG310:                ;; offset=0x2A7D
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG361
 
G_M000_IG311:                ;; offset=0x2A92
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG361
 
G_M000_IG312:                ;; offset=0x2AA2
       mov      rdx, rdi
       mov      rcx, 0x7FF9CCFD2F90
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG313
       test     dword ptr [rax+0x34], 0x1600000
       setne    r14b
       movzx    r14, r14b
       jmp      SHORT G_M000_IG314
 
G_M000_IG313:                ;; offset=0x2ACA
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, rdi
       mov      r11, 0x7FF9CC901EB0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r14b
       movzx    r14, r14b
 
G_M000_IG314:                ;; offset=0x2AE9
       test     r14d, r14d
       jne      G_M000_IG58
       jmp      G_M000_IG302
 
G_M000_IG315:                ;; offset=0x2AF7
       mov      rdx, r14
       mov      rcx, 0x7FF9CCFD2F90
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG316
       test     dword ptr [rax+0x34], 0x1600000
       setne    r13b
       movzx    r13, r13b
       jmp      SHORT G_M000_IG317
 
G_M000_IG316:                ;; offset=0x2B1F
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, r14
       mov      r11, 0x7FF9CC901EB8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r13b
       movzx    r13, r13b
 
G_M000_IG317:                ;; offset=0x2B3E
       test     r13d, r13d
       jne      G_M000_IG264
       jmp      G_M000_IG302
 
G_M000_IG318:                ;; offset=0x2B4C
       mov      rcx, r12
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG255
 
G_M000_IG319:                ;; offset=0x2B5C
       mov      rdx, rdi
       mov      rcx, 0x7FF9CCFD2F90
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG320
       test     dword ptr [rax+0x34], 0x1600000
       setne    r14b
       movzx    r14, r14b
       jmp      SHORT G_M000_IG321
 
G_M000_IG320:                ;; offset=0x2B84
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, rdi
       mov      r11, 0x7FF9CC901EC8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r14b
       movzx    r14, r14b
 
G_M000_IG321:                ;; offset=0x2BA3
       test     r14d, r14d
       jne      G_M000_IG58
       jmp      G_M000_IG302
 
G_M000_IG322:                ;; offset=0x2BB1
       mov      rdx, r14
       mov      rcx, 0x7FF9CCFD2F90
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG323
       test     dword ptr [rax+0x34], 0x1600000
       setne    r13b
       movzx    r13, r13b
       jmp      SHORT G_M000_IG324
 
G_M000_IG323:                ;; offset=0x2BD9
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, r14
       mov      r11, 0x7FF9CC901ED0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r13b
       movzx    r13, r13b
 
G_M000_IG324:                ;; offset=0x2BF8
       test     r13d, r13d
       jne      G_M000_IG58
       jmp      G_M000_IG302
 
G_M000_IG325:                ;; offset=0x2C06
       mov      rdx, r15
       mov      rcx, 0x7FF9CCFD2F90
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG326
       test     dword ptr [rax+0x34], 0x1600000
       setne    r13b
       movzx    r13, r13b
       jmp      SHORT G_M000_IG327
 
G_M000_IG326:                ;; offset=0x2C2E
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, r15
       mov      r11, 0x7FF9CC901ED8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r13b
       movzx    r13, r13b
 
G_M000_IG327:                ;; offset=0x2C4D
       test     r13d, r13d
       jne      G_M000_IG230
       jmp      G_M000_IG302
 
G_M000_IG328:                ;; offset=0x2C5B
       mov      rdx, r15
       mov      rcx, 0x7FF9CCFD2F90
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG329
       test     dword ptr [rax+0x34], 0x1600000
       setne    r13b
       movzx    r13, r13b
       jmp      SHORT G_M000_IG330
 
G_M000_IG329:                ;; offset=0x2C83
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, r15
       mov      r11, 0x7FF9CC901EE0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r13b
       movzx    r13, r13b
 
G_M000_IG330:                ;; offset=0x2CA2
       test     r13d, r13d
       jne      G_M000_IG230
       jmp      G_M000_IG302
 
G_M000_IG331:                ;; offset=0x2CB0
       mov      rdx, r15
       mov      rcx, 0x7FF9CCFD2F90
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG332
       test     dword ptr [rax+0x34], 0x1600000
       setne    r13b
       movzx    r13, r13b
       jmp      SHORT G_M000_IG333
 
G_M000_IG332:                ;; offset=0x2CD8
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, r15
       mov      r11, 0x7FF9CC901EE8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r13b
       movzx    r13, r13b
 
G_M000_IG333:                ;; offset=0x2CF7
       test     r13d, r13d
       jne      G_M000_IG230
       jmp      G_M000_IG302
 
G_M000_IG334:                ;; offset=0x2D05
       mov      rcx, bword ptr [rbp-0x350]
       mov      rdx, 0x24D5EE1BFF0
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG335:                ;; offset=0x2D25
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG336:                ;; offset=0x2D2B
       mov      rdx, r12
       mov      rcx, 0x7FF9CCFB92B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG337
       mov      edx, dword ptr [rax+0x34]
       and      edx, 0x1600000
       cmp      edx, 0x1000000
       sete     dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG338
 
G_M000_IG337:                ;; offset=0x2D5B
       mov      rax, bword ptr [rbp+0x40]
       movsx    rdx, word  ptr [rax+0x10]
       mov      rcx, r12
       mov      r11, 0x7FF9CC901EF0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetStatus(short):int:this
       cmp      eax, 1
       sete     dil
       movzx    rdi, dil
 
G_M000_IG338:                ;; offset=0x2D7F
       test     edi, edi
       je       G_M000_IG134
       jmp      G_M000_IG127
 
G_M000_IG339:                ;; offset=0x2D8C
       mov      rdx, rdi
       mov      rcx, 0x7FF9CCFB92B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r12, rax
       test     r12, r12
       je       SHORT G_M000_IG342
       mov      ecx, dword ptr [r12+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       SHORT G_M000_IG341
 
G_M000_IG340:                ;; offset=0x2DB9
       mov      rcx, r12
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG341:                ;; offset=0x2DC4
       mov      r12, gword ptr [r12+0x38]
       jmp      G_M000_IG129
 
G_M000_IG342:                ;; offset=0x2DCE
       mov      rax, bword ptr [rbp+0x40]
       movsx    rdx, word  ptr [rax+0x10]
       mov      rcx, rdi
       mov      r11, 0x7FF9CC901EF8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetResult(short):System.__Canon:this
       mov      r12, rax
       jmp      G_M000_IG129
 
G_M000_IG343:                ;; offset=0x2DEF
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG361
 
G_M000_IG344:                ;; offset=0x2E04
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG361
 
G_M000_IG345:                ;; offset=0x2E14
       mov      rdx, r14
       mov      rcx, 0x7FF9CCFD2F90
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG346
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG347
 
G_M000_IG346:                ;; offset=0x2E3C
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, r14
       mov      r11, 0x7FF9CC901F08
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG347:                ;; offset=0x2E5B
       test     edi, edi
       jne      G_M000_IG58
       jmp      G_M000_IG302
 
G_M000_IG348:                ;; offset=0x2E68
       mov      rdx, r15
       mov      rcx, 0x7FF9CCFD2F90
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG349
       test     dword ptr [rax+0x34], 0x1600000
       setne    r13b
       movzx    r13, r13b
       jmp      SHORT G_M000_IG350
 
G_M000_IG349:                ;; offset=0x2E90
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, r15
       mov      r11, 0x7FF9CC901F10
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r13b
       movzx    r13, r13b
 
G_M000_IG350:                ;; offset=0x2EAF
       test     r13d, r13d
       jne      G_M000_IG58
       jmp      G_M000_IG302
 
G_M000_IG351:                ;; offset=0x2EBD
       mov      rdx, rdi
       mov      rcx, 0x7FF9CCFD2F90
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG352
       test     dword ptr [rax+0x34], 0x1600000
       setne    r14b
       movzx    r14, r14b
       jmp      SHORT G_M000_IG353
 
G_M000_IG352:                ;; offset=0x2EE5
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, rdi
       mov      r11, 0x7FF9CC901F18
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r14b
       movzx    r14, r14b
 
G_M000_IG353:                ;; offset=0x2F04
       test     r14d, r14d
       jne      G_M000_IG58
       jmp      G_M000_IG302
 
G_M000_IG354:                ;; offset=0x2F12
       mov      rdx, rdi
       mov      rcx, 0x7FF9CCFD2F90
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG355
       test     dword ptr [rax+0x34], 0x1600000
       setne    r14b
       movzx    r14, r14b
       jmp      SHORT G_M000_IG356
 
G_M000_IG355:                ;; offset=0x2F3A
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, rdi
       mov      r11, 0x7FF9CC901F20
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r14b
       movzx    r14, r14b
 
G_M000_IG356:                ;; offset=0x2F59
       test     r14d, r14d
       jne      G_M000_IG230
       jmp      G_M000_IG302
 
G_M000_IG357:                ;; offset=0x2F67
       mov      rdx, bword ptr [rbp-0x128]
       mov      eax, ecx
       lea      rdx, bword ptr [rdx+2*rax]
       mov      eax, dword ptr [rbp-0x120]
       sub      eax, ecx
       cmp      eax, 27
       jb       SHORT G_M000_IG358
       vmovups  ymm0, ymmword ptr [reloc @RWD312]
       vmovups  ymmword ptr [rdx], ymm0
       vmovups  xmm0, xmmword ptr [reloc @RWD344]
       vmovups  xmmword ptr [rdx+0x20], xmm0
       mov      dword ptr [rdx+0x30], 0x3A0065
       mov      word  ptr [rdx+0x34], 32
       mov      ecx, dword ptr [rbp-0x130]
       add      ecx, 27
       mov      dword ptr [rbp-0x130], ecx
       jmp      SHORT G_M000_IG359
 
G_M000_IG358:                ;; offset=0x2FB8
       lea      rcx, [rbp-0x140]
       mov      rdx, 0x24D5EE21300
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:GrowThenCopyString(System.String):this]
 
G_M000_IG359:                ;; offset=0x2FCF
       mov      rdx, bword ptr [rbp-0x350]
       mov      edx, dword ptr [rdx+0x1C]
       lea      rcx, [rbp-0x140]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rcx, 0x7FF9CCB294A8
       call     CORINFO_HELP_NEWSFAST
       mov      rdi, rax
       lea      rcx, [rbp-0x140]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      rdx, rax
       mov      rcx, rdi
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rdi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG360:                ;; offset=0x301A
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG361:                ;; offset=0x3020
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG362
       mov      r14, bword ptr [rbp+0x10]
       cmp      gword ptr [r14+0x40], 0
       jne      SHORT G_M000_IG366
 
G_M000_IG362:                ;; offset=0x3031
       cmp      dword ptr [rbp-0x3C], 0
       jne      SHORT G_M000_IG363
       mov      r14, bword ptr [rbp+0x10]
       inc      dword ptr [r14+0x10]
 
G_M000_IG363:                ;; offset=0x303F
       mov      rbx, gword ptr [rbp+0x20]
       mov      rsi, bword ptr [rbp+0x30]
       mov      r15, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [r15+0x10]
       mov      r11, gword ptr [rbp-0x348]
       mov      edi, dword ptr [r11+0x08]
       cmp      ecx, edi
       mov      rcx, r15
       mov      rdx, gword ptr [rbp+0x18]
       jl       G_M000_IG05
 
G_M000_IG364:                ;; offset=0x3069
       mov      eax, 1
 
G_M000_IG365:                ;; offset=0x306E
       vzeroupper 
       add      rsp, 0x3E8
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG366:                ;; offset=0x3085
       xor      rax, rax
       mov      rsi, bword ptr [rbp+0x30]
       mov      gword ptr [rsi], rax
       mov      word  ptr [rsi+0x08], 0
       movzx    rax, byte  ptr [rbp-0x3C]
       mov      byte  ptr [rsi+0x0A], al
       mov      byte  ptr [rsi+0x0B], 1
       mov      eax, 5
 
G_M000_IG367:                ;; offset=0x30A4
       vzeroupper 
       add      rsp, 0x3E8
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG368:                ;; offset=0x30BB
       mov      r9, bword ptr [rbp-0x350]
       mov      r9, gword ptr [r9]
       mov      rcx, rdi
       mov      rdx, r13
       mov      r8, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       je       SHORT G_M000_IG371
       mov      dword ptr [rbp-0x3C], 1
       jmp      G_M000_IG361
 
G_M000_IG369:                ;; offset=0x30E4
       mov      eax, dword ptr [rbp-0xAC]
 
G_M000_IG370:                ;; offset=0x30EA
       vzeroupper 
       add      rsp, 0x3E8
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG371:                ;; offset=0x3101
       mov      rcx, rdi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG372:                ;; offset=0x310A
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG373:                ;; offset=0x3110
       sub      rsp, 72
 
G_M000_IG374:                ;; offset=0x3114
       mov      rbx, rcx
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG375
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG375:                ;; offset=0x3124
       mov      rcx, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      rdx, rbx
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryRouteReturn(Lokad.Lython.Runtime.LythonRuntime+ReturnSignal,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG377
       mov      dword ptr [rbp-0xAC], 1
       lea      rax, G_M000_IG369
 
G_M000_IG376:                ;; offset=0x3156
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG377:                ;; offset=0x315E
       mov      dword ptr [rbp-0x3C], 1
       lea      rax, G_M000_IG361
 
G_M000_IG378:                ;; offset=0x316C
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG379:                ;; offset=0x3174
       sub      rsp, 72
 
G_M000_IG380:                ;; offset=0x3178
       mov      rbx, rcx
       mov      rcx, bword ptr [rbp-0x350]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      r9, rax
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG381
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG381:                ;; offset=0x31A6
       mov      dword ptr [rbp-0x3C], 1
       lea      rax, G_M000_IG361
 
G_M000_IG382:                ;; offset=0x31B4
       vzeroupper 
       add      rsp, 72
       ret      
 
RWD00  	dd	0000083Fh ; case G_M000_IG57
       	dd	0000071Eh ; case G_M000_IG50
       	dd	000014EDh ; case G_M000_IG143
       	dd	0000050Ch ; case G_M000_IG37
       	dd	000003E9h ; case G_M000_IG30
       	dd	000002A8h ; case G_M000_IG23
       	dd	000001CEh ; case G_M000_IG17
       	dd	000000CBh ; case G_M000_IG09
       	dd	000000CBh ; case G_M000_IG09
       	dd	00000DC2h ; case G_M000_IG98
       	dd	00000DC2h ; case G_M000_IG98
       	dd	000000CBh ; case G_M000_IG09
       	dd	000000CBh ; case G_M000_IG09
       	dd	000000CBh ; case G_M000_IG09
       	dd	000000CBh ; case G_M000_IG09
       	dd	000000CBh ; case G_M000_IG09
       	dd	000000CBh ; case G_M000_IG09
       	dd	000000CBh ; case G_M000_IG09
       	dd	000000CBh ; case G_M000_IG09
       	dd	000000CBh ; case G_M000_IG09
       	dd	000000CBh ; case G_M000_IG09
       	dd	000000CBh ; case G_M000_IG09
       	dd	000015C3h ; case G_M000_IG148
       	dd	000015C3h ; case G_M000_IG148
       	dd	0000279Eh ; case G_M000_IG288
       	dd	0000277Bh ; case G_M000_IG287
       	dd	00002753h ; case G_M000_IG286
       	dd	000026D8h ; case G_M000_IG284
       	dd	00002648h ; case G_M000_IG282
       	dd	0000254Ch ; case G_M000_IG270
       	dd	000024ECh ; case G_M000_IG268
       	dd	0000247Ah ; case G_M000_IG267
       	dd	00001FDEh ; case G_M000_IG233
       	dd	00001FB9h ; case G_M000_IG231
       	dd	00001FB9h ; case G_M000_IG231
       	dd	00001FB9h ; case G_M000_IG231
       	dd	00001F3Dh ; case G_M000_IG227
       	dd	00001F3Dh ; case G_M000_IG227
       	dd	00001F3Dh ; case G_M000_IG227
       	dd	00001FB9h ; case G_M000_IG231
       	dd	00001E11h ; case G_M000_IG221
       	dd	00001CF6h ; case G_M000_IG213
       	dd	00000E12h ; case G_M000_IG99
       	dd	00000D9Ch ; case G_M000_IG97
       	dd	00000D18h ; case G_M000_IG94
       	dd	00000CEAh ; case G_M000_IG92
       	dd	00000CBFh ; case G_M000_IG91
       	dd	00000CBFh ; case G_M000_IG91
       	dd	00000CBFh ; case G_M000_IG91
       	dd	00000C34h ; case G_M000_IG88
       	dd	00000B29h ; case G_M000_IG79
       	dd	00000AE2h ; case G_M000_IG78
       	dd	00000C34h ; case G_M000_IG88
       	dd	00000C34h ; case G_M000_IG88
       	dd	00000C34h ; case G_M000_IG88
       	dd	00000C34h ; case G_M000_IG88
       	dd	00000C34h ; case G_M000_IG88
       	dd	00000C34h ; case G_M000_IG88
       	dd	00000C34h ; case G_M000_IG88
       	dd	00002467h ; case G_M000_IG266
       	dd	000008F1h ; case G_M000_IG60
       	dd	00002203h ; case G_M000_IG247
       	dd	00000C34h ; case G_M000_IG88
       	dd	000020DAh ; case G_M000_IG238
       	dd	000020DAh ; case G_M000_IG238
       	dd	000020DAh ; case G_M000_IG238
       	dd	000020DAh ; case G_M000_IG238
       	dd	000020DAh ; case G_M000_IG238
       	dd	00001CD0h ; case G_M000_IG212
       	dd	00001BF4h ; case G_M000_IG209
       	dd	00001A73h ; case G_M000_IG189
       	dd	00001994h ; case G_M000_IG176
       	dd	0000181Bh ; case G_M000_IG165
       	dd	00001910h ; case G_M000_IG173
       	dd	00001746h ; case G_M000_IG154
       	dd	00001609h ; case G_M000_IG150
       	dd	000015A3h ; case G_M000_IG147
       	dd	000014CDh ; case G_M000_IG142
RWD312 	dq	006E006B006E0055h, 0020006E0077006Fh, 0063006500780065h, 0062006100740075h
RWD344 	dq	006F00200065006Ch, 0064006F00630070h

; Total bytes of code 12732

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:RunCore(byref):bool:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 173 single block inlinees; 47 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 248
       lea      rbp, [rsp+0x130]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xF0], ymm4
       vmovdqu  ymmword ptr [rbp-0xD0], ymm4
       vmovdqu  ymmword ptr [rbp-0xB0], ymm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      rbx, rcx
       mov      rsi, rdx
 
G_M000_IG02:                ;; offset=0x0055
       mov      rcx, 0x22D380012A0
       mov      rdx, gword ptr [rcx]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rsi+0x08], rcx
       mov      ecx, dword ptr [rbx+0x38]
       mov      rax, gword ptr [rbx+0x08]
       cmp      ecx, dword ptr [rax+0xEC]
       jge      G_M000_IG147
 
G_M000_IG03:                ;; offset=0x0083
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x98]
       mov      eax, dword ptr [rbx+0x38]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG226
       shl      rax, 5
       lea      rdi, bword ptr [rcx+rax+0x10]
       mov      rcx, gword ptr [rbx+0x10]
       mov      r14, gword ptr [rcx+0xA0]
       mov      r15, gword ptr [rdi]
       cmp      byte  ptr [r14], r14b
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00C1
       mov      rcx, r14
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG05:                ;; offset=0x00CD
       mov      r14d, dword ptr [rdi+0x1C]
       lea      ecx, [r14-0x01]
       cmp      ecx, 76
       ja       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00DA
       mov      ecx, ecx
       lea      rdx, [reloc @RWD00]
       mov      edx, dword ptr [rdx+4*rcx]
       lea      rax, G_M000_IG02
       add      rdx, rax
       jmp      rdx
 
G_M000_IG07:                ;; offset=0x00F2
       xor      eax, eax
 
G_M000_IG08:                ;; offset=0x00F4
       add      rsp, 248
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG09:                ;; offset=0x0108
       mov      rdx, gword ptr [rbx+0x08]
       mov      ecx, dword ptr [rdx+0xEC]
       mov      rax, gword ptr [rdx+0x98]
       cmp      ecx, dword ptr [rax+0x08]
       jne      SHORT G_M000_IG07
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DiscardIterator():bool:this]
       test     eax, eax
       je       G_M000_IG66
       mov      edx, dword ptr [rbx+0x3C]
       dec      edx
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG66
 
G_M000_IG10:                ;; offset=0x0142
       lea      r8, [rbp-0xB0]
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryIntegerComparison(byref,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG17
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG11:                ;; offset=0x0161
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
 
G_M000_IG12:                ;; offset=0x016E
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rbp-0xE0]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      r14, rax
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG13:                ;; offset=0x01A2
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
 
G_M000_IG14:                ;; offset=0x01AF
       mov      dword ptr [rsp+0x20], 1
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rbp-0xE0]
       mov      r8d, dword ptr [rdi+0x0C]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      r8, rax
       cmp      dword ptr [rdi+0x1C], 51
       jne      SHORT G_M000_IG15
       mov      ecx, dword ptr [rdi+0x14]
       jmp      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x01EC
       mov      ecx, dword ptr [rdi+0x08]
       and      ecx, 0x7FFFFFFF
 
G_M000_IG16:                ;; offset=0x01F5
       mov      r9, gword ptr [rdi]
       mov      gword ptr [rsp+0x20], r9
       lea      r9, [rbp-0xB0]
       mov      qword ptr [rsp+0x28], r9
       mov      r9, gword ptr [rbx+0x10]
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       G_M000_IG07
 
G_M000_IG17:                ;; offset=0x021E
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG18
       not      edx
 
G_M000_IG18:                ;; offset=0x0227
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rcx, gword ptr [rbx+0x10]
       mov      r14, gword ptr [rdi]
       mov      r15, gword ptr [rcx+0xA0]
       cmp      byte  ptr [r15], r15b
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG19
       mov      rcx, r15
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG19:                ;; offset=0x025A
       cmp      byte  ptr [rbp-0xB0], 0
       jne      G_M000_IG145
       jmp      G_M000_IG66
 
G_M000_IG20:                ;; offset=0x026C
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, rdx
 
G_M000_IG21:                ;; offset=0x0273
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
 
G_M000_IG22:                ;; offset=0x0280
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rbp-0xE0]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      r14, rax
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       je       G_M000_IG07
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      r8, gword ptr [rdi]
       mov      rdx, gword ptr [rbx+0x10]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:IsTruthy(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      G_M000_IG145
       jmp      G_M000_IG66
 
G_M000_IG23:                ;; offset=0x02EA
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryIntegerOperation():bool:this]
       test     eax, eax
       jne      G_M000_IG145
 
G_M000_IG24:                ;; offset=0x02FB
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG25:                ;; offset=0x02FF
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
 
G_M000_IG26:                ;; offset=0x030C
       lea      rdx, [rbp-0x80]
       mov      qword ptr [rsp+0x20], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rbp-0xE0]
       mov      r8d, dword ptr [rbx+0x38]
       mov      r9, gword ptr [rbx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateBuiltinArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):bool]
       test     eax, eax
       je       G_M000_IG07
 
G_M000_IG27:                ;; offset=0x033B
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0xF0], xmm0
 
G_M000_IG28:                ;; offset=0x0348
       lea      r8, [rbp-0xF0]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG29:                ;; offset=0x0360
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, rdx
 
G_M000_IG30:                ;; offset=0x0367
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
 
G_M000_IG31:                ;; offset=0x0374
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rbp-0xE0]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      r14, rax
       mov      rcx, gword ptr [rbx+0x08]
       mov      r15, bword ptr [rbx+0x48]
       mov      r13d, dword ptr [rbx+0x50]
       mov      r12d, dword ptr [rdi+0x0C]
       mov      r8, gword ptr [rbx+0x10]
       xor      r9d, r9d
       mov      gword ptr [rbp-0xD0], r9
 
G_M000_IG32:                ;; offset=0x03C2
       mov      gword ptr [rbp-0xC8], r9
       test     r12d, r12d
       jge      G_M000_IG35
       mov      r13d, r12d
       not      r13d
       mov      r12, gword ptr [rcx+0x30]
       mov      edx, r13d
       sub      edx, dword ptr [r12+0x08]
       js       SHORT G_M000_IG34
       mov      r12, gword ptr [rcx+0x38]
       cmp      dword ptr [r12+0x08], edx
       jle      SHORT G_M000_IG33
       lea      r9, [rbp-0xC8]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       lea      rdx, [rbp-0x90]
       mov      rcx, gword ptr [rbp-0xC8]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG36
 
G_M000_IG33:                ;; offset=0x0414
       sub      edx, dword ptr [r12+0x08]
       lea      rcx, [rbp-0xD0]
       lea      r8, [rbp-0x90]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures:TryReadInteger(int,byref):bool:this]
       jmp      SHORT G_M000_IG36
 
G_M000_IG34:                ;; offset=0x042F
       cmp      r13d, dword ptr [r12+0x08]
       jae      G_M000_IG226
       mov      ecx, r13d
       mov      rcx, gword ptr [r12+8*rcx+0x10]
       lea      rdx, [rbp-0x90]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG36
 
G_M000_IG35:                ;; offset=0x0451
       cmp      r12d, r13d
       jae      G_M000_IG226
       mov      ecx, r12d
       shl      rcx, 4
       add      rcx, r15
       lea      rdx, [rbp-0x90]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
 
G_M000_IG36:                ;; offset=0x0471
       xor      r9, r9
       mov      gword ptr [rbp-0xC8], r9
       test     eax, eax
       je       SHORT G_M000_IG37
       mov      rdx, qword ptr [rbp-0x90]
       lea      r9, [rbp-0xA0]
       mov      qword ptr [rsp+0x20], r9
       mov      r9, gword ptr [rbx+0x10]
       mov      r8, gword ptr [rdi]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.PyIndexing:TryReadSequenceIndex(System.Object,long,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG50
 
G_M000_IG37:                ;; offset=0x04AA
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG38:                ;; offset=0x04AE
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
 
G_M000_IG39:                ;; offset=0x04BB
       mov      dword ptr [rsp+0x20], 1
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rbp-0xE0]
       mov      r8d, dword ptr [rdi+0x0C]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      r15, rax
       test     r14, r14
       je       G_M000_IG07
 
G_M000_IG40:                ;; offset=0x04F6
       mov      rcx, 0x7FF9CCEB4750
       cmp      qword ptr [r14], rcx
       jne      G_M000_IG07
 
G_M000_IG41:                ;; offset=0x0509
       cmp      gword ptr [r14+0x28], 0
       jne      SHORT G_M000_IG42
       mov      rcx, gword ptr [r14+0x08]
       mov      r11, 0x7FF9CC902030
       call     [r11]Lokad.Lython.Runtime.IPyDictStorage:get_HasProtocolKeys():bool:this
       test     eax, eax
       jne      G_M000_IG07
       jmp      SHORT G_M000_IG43
 
G_M000_IG42:                ;; offset=0x052B
       cmp      dword ptr [r14+0x50], 0
       jne      G_M000_IG07
 
G_M000_IG43:                ;; offset=0x0536
       test     r15, r15
       je       G_M000_IG07
 
G_M000_IG44:                ;; offset=0x053F
       mov      rcx, 0x7FF9CCE0DAA0
       cmp      qword ptr [r15], rcx
       jne      G_M000_IG07
 
G_M000_IG45:                ;; offset=0x0552
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       test     eax, eax
       jl       SHORT G_M000_IG46
       cmp      gword ptr [r14+0x20], 0
       je       SHORT G_M000_IG46
       mov      rcx, gword ptr [rbx]
       mov      rdx, gword ptr [rdi]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:GetLookupCaches(Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntime+ExecutableLookupCache[]:this]
       mov      r13, rax
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       cmp      eax, dword ptr [r13+0x08]
       jae      G_M000_IG226
       mov      r8d, eax
       lea      r8, [r8+2*r8]
       lea      r8, bword ptr [r13+8*r8+0x10]
       mov      r9, gword ptr [rdi]
       mov      gword ptr [rsp+0x20], r9
       lea      r9, [rbp-0xA8]
       mov      qword ptr [rsp+0x28], r9
       mov      r9, gword ptr [rbx+0x10]
       mov      rdx, r15
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.PyDict:TryReadRecordValue(Lokad.Lython.Runtime.Text.PyString,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG49
 
G_M000_IG46:                ;; offset=0x05BE
       cmp      gword ptr [r14+0x28], 0
       jne      SHORT G_M000_IG47
       mov      rcx, gword ptr [r14+0x08]
       mov      r11, 0x7FF9CC902038
       call     [r11]Lokad.Lython.Runtime.IPyDictStorage:get_HasProtocolKeys():bool:this
       test     eax, eax
       jne      G_M000_IG07
       jmp      SHORT G_M000_IG48
 
G_M000_IG47:                ;; offset=0x05E0
       cmp      dword ptr [r14+0x50], 0
       jne      G_M000_IG07
 
G_M000_IG48:                ;; offset=0x05EB
       mov      r8, gword ptr [rdi]
       mov      r9, gword ptr [rbx+0x10]
       mov      rcx, r14
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadSubscriptValue(System.Object,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0xF0], rax
       xor      r8d, r8d
       mov      qword ptr [rbp-0xE8], r8
       lea      r8, [rbp-0xF0]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG49:                ;; offset=0x0627
       mov      r8, gword ptr [rbp-0xA8]
       mov      gword ptr [rbp-0xF0], r8
       xor      r8d, r8d
       mov      qword ptr [rbp-0xE8], r8
       lea      r8, [rbp-0xF0]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG50:                ;; offset=0x0657
       vmovdqu  xmm0, xmmword ptr [rbp-0xA0]
       vmovdqu  xmmword ptr [rbp-0xF0], xmm0
 
G_M000_IG51:                ;; offset=0x0667
       lea      r8, [rbp-0xF0]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG52:                ;; offset=0x067F
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG145
       jmp      G_M000_IG07
 
G_M000_IG53:                ;; offset=0x0698
       lea      rcx, bword ptr [rbx+0x48]
       mov      eax, dword ptr [rdi+0x10]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG226
       shl      rax, 4
       add      rax, bword ptr [rcx]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9CCFB77C8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rcx, rax
       test     rcx, rcx
       je       SHORT G_M000_IG56
 
G_M000_IG54:                ;; offset=0x06D3
       mov      rdx, 0x7FF9CD085448
       cmp      qword ptr [rcx], rdx
       jne      SHORT G_M000_IG56
 
G_M000_IG55:                ;; offset=0x06E2
       lea      rdx, [rbp-0xC0]
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:MoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       jmp      SHORT G_M000_IG62
 
G_M000_IG56:                ;; offset=0x06F1
       test     rcx, rcx
       je       SHORT G_M000_IG59
 
G_M000_IG57:                ;; offset=0x06F6
       mov      rdx, 0x7FF9CD086CE0
       cmp      qword ptr [rcx], rdx
       jne      SHORT G_M000_IG59
 
G_M000_IG58:                ;; offset=0x0705
       lea      rdx, [rbp-0xC0]
       call     [Lokad.Lython.Runtime.PyRange+Enumerator:TryMoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       jmp      SHORT G_M000_IG62
 
G_M000_IG59:                ;; offset=0x0714
       mov      r14, rcx
       test     r14, r14
       je       SHORT G_M000_IG61
 
G_M000_IG60:                ;; offset=0x071C
       mov      rax, 0x7FF9CCFB7330
       cmp      qword ptr [r14], rax
       jne      G_M000_IG222
 
G_M000_IG61:                ;; offset=0x072F
       cmp      byte  ptr [r14], r14b
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:CheckExecution():this]
       lea      rdx, [rbp-0xC0]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:TryMoveNextCore():Lokad.Lython.Runtime.PyIterationResult:this]
 
G_M000_IG62:                ;; offset=0x074B
       cmp      gword ptr [rbp-0xC0], 0
       je       SHORT G_M000_IG65
 
G_M000_IG63:                ;; offset=0x0755
       vmovdqu  xmm0, xmmword ptr [rbp-0xC0]
       vmovdqu  xmmword ptr [rbp-0xF0], xmm0
 
G_M000_IG64:                ;; offset=0x0765
       lea      r8, [rbp-0xF0]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG65:                ;; offset=0x077D
       mov      edx, dword ptr [rdi+0x10]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG66:                ;; offset=0x0789
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      dword ptr [rbx+0x38], eax
       jmp      G_M000_IG146
 
G_M000_IG67:                ;; offset=0x079A
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, rdx
 
G_M000_IG68:                ;; offset=0x07A1
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
 
G_M000_IG69:                ;; offset=0x07AE
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rbp-0xE0]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      r14, rax
       test     r14, r14
       je       G_M000_IG74
 
G_M000_IG70:                ;; offset=0x07E7
       mov      r8, 0x7FF9CD085448
       cmp      qword ptr [r14], r8
       jne      SHORT G_M000_IG72
 
G_M000_IG71:                ;; offset=0x07F6
       mov      gword ptr [rbp-0xF0], r14
       xor      r8d, r8d
       mov      qword ptr [rbp-0xE8], r8
       lea      r8, [rbp-0xF0]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG72:                ;; offset=0x081F
       mov      rcx, 0x7FF9CCFE5E70
       cmp      qword ptr [r14], rcx
       jne      SHORT G_M000_IG74
 
G_M000_IG73:                ;; offset=0x082E
       mov      rcx, 0x7FF9CD086CE0
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rcx, r15
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.PyRange+Enumerator:.ctor(Lokad.Lython.Runtime.PyRange):this]
       mov      gword ptr [rbp-0xF0], r15
       xor      r8d, r8d
       mov      qword ptr [rbp-0xE8], r8
       lea      r8, [rbp-0xF0]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG74:                ;; offset=0x0875
       test     r14, r14
       je       SHORT G_M000_IG76
 
G_M000_IG75:                ;; offset=0x087A
       mov      rdx, 0x7FF9CCFBDA88
       cmp      qword ptr [r14], rdx
       je       SHORT G_M000_IG78
 
G_M000_IG76:                ;; offset=0x0889
       mov      rdx, r14
       mov      rcx, 0x7FF9CCF188D8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG78
       test     r14, r14
       je       G_M000_IG07
 
G_M000_IG77:                ;; offset=0x08A9
       mov      r8, 0x7FF9CCED3CD8
       cmp      qword ptr [r14], r8
       je       SHORT G_M000_IG78
       mov      r8, 0x7FF9CCE0DAA0
       cmp      qword ptr [r14], r8
       je       SHORT G_M000_IG78
       mov      r8, 0x7FF9CCEB4750
       cmp      qword ptr [r14], r8
       je       SHORT G_M000_IG78
       mov      r8, 0x7FF9CCFDD328
       cmp      qword ptr [r14], r8
       jne      G_M000_IG07
 
G_M000_IG78:                ;; offset=0x08E9
       mov      r8, gword ptr [rbx+0x10]
       mov      rdx, gword ptr [rdi]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:Create(System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyIteration+Cursor]
       mov      gword ptr [rbp-0xF0], rax
       xor      r8d, r8d
       mov      qword ptr [rbp-0xE8], r8
       lea      r8, [rbp-0xF0]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG79:                ;; offset=0x0922
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:ConstructContainer(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG145
       jmp      G_M000_IG07
 
G_M000_IG80:                ;; offset=0x093B
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryReturnUnpackedTuple(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG160
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       test     eax, eax
       jne      SHORT G_M000_IG81
       mov      rcx, 0x22D380015F0
       mov      r14, gword ptr [rcx]
       jmp      SHORT G_M000_IG82
 
G_M000_IG81:                ;; offset=0x096B
       lea      r14, bword ptr [rbx+0x48]
       mov      r15d, dword ptr [rdi+0x10]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      ecx, r15d
       mov      edx, eax
       add      rcx, rdx
       mov      edx, dword ptr [r14+0x08]
       cmp      rcx, rdx
       ja       G_M000_IG225
       mov      ecx, r15d
       shl      rcx, 4
       add      rcx, bword ptr [r14]
       mov      bword ptr [rbp-0xE0], rcx
       mov      dword ptr [rbp-0xD8], eax
       lea      rcx, [rbp-0xE0]
       mov      rdx, gword ptr [rbx+0x10]
       mov      r8, gword ptr [rdi]
       call     [Lokad.Lython.Runtime.PyTuple:FromSlots(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      r14, rax
 
G_M000_IG82:                ;; offset=0x09BF
       mov      edx, dword ptr [rdi+0x10]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      gword ptr [rbp-0xF0], r14
       xor      r8d, r8d
       mov      qword ptr [rbp-0xE8], r8
       lea      r8, [rbp-0xF0]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG83:                ;; offset=0x09F4
       lea      r14, bword ptr [rbx+0x48]
       mov      r15d, dword ptr [rdi+0x10]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      ecx, r15d
       mov      edx, eax
       add      rcx, rdx
       mov      edx, dword ptr [r14+0x08]
       cmp      rcx, rdx
       ja       G_M000_IG225
       mov      ecx, r15d
       shl      rcx, 4
       add      rcx, bword ptr [r14]
       mov      bword ptr [rbp-0xE0], rcx
       mov      dword ptr [rbp-0xD8], eax
       lea      rcx, [rbp-0xE0]
       mov      rdx, gword ptr [rbx+0x10]
       mov      r8, gword ptr [rdi]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateSlotList(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyList]
       mov      r14, rax
       mov      edx, dword ptr [rdi+0x10]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      gword ptr [rbp-0xF0], r14
       xor      r8d, r8d
       mov      qword ptr [rbp-0xE8], r8
       lea      r8, [rbp-0xF0]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG84:                ;; offset=0x0A7D
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, rdx
 
G_M000_IG85:                ;; offset=0x0A84
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
 
G_M000_IG86:                ;; offset=0x0A91
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rbp-0xE0]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG87
       not      edx
 
G_M000_IG87:                ;; offset=0x0AC7
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG145
 
G_M000_IG88:                ;; offset=0x0AD5
       mov      ecx, r14d
       cmp      ecx, 51
       ja       SHORT G_M000_IG93
 
G_M000_IG89:                ;; offset=0x0ADD
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG93
 
G_M000_IG90:                ;; offset=0x0AED
       mov      r14d, dword ptr [rdi+0x18]
       test     r14d, r14d
       jge      SHORT G_M000_IG91
       mov      r15d, r14d
       not      r15d
       jmp      SHORT G_M000_IG92
 
G_M000_IG91:                ;; offset=0x0AFE
       mov      r15d, r14d
 
G_M000_IG92:                ;; offset=0x0B01
       jmp      SHORT G_M000_IG94
 
G_M000_IG93:                ;; offset=0x0B03
       mov      r15d, dword ptr [rdi+0x14]
 
G_M000_IG94:                ;; offset=0x0B07
       inc      r15d
       mov      r14d, dword ptr [rdi+0x18]
       test     r14d, r14d
       jge      SHORT G_M000_IG95
       mov      r13d, r14d
       not      r13d
       jmp      SHORT G_M000_IG96
 
G_M000_IG95:                ;; offset=0x0B1B
       mov      r13d, r14d
 
G_M000_IG96:                ;; offset=0x0B1E
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, rdx
 
G_M000_IG97:                ;; offset=0x0B25
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
 
G_M000_IG98:                ;; offset=0x0B32
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rbp-0xE0]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      rdi, rax
       cmp      r13d, dword ptr [rbx+0x3C]
       jge      SHORT G_M000_IG99
       mov      rcx, rbx
       mov      edx, r13d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG99:                ;; offset=0x0B74
       lea      rcx, bword ptr [rbx+0x48]
       cmp      r15d, dword ptr [rcx+0x08]
       jae      G_M000_IG226
       mov      r14d, r15d
       shl      r14, 4
       add      r14, bword ptr [rcx]
       mov      rcx, r14
       mov      rdx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      edx, edx
       mov      qword ptr [r14+0x08], rdx
       mov      dword ptr [rbx+0x3C], r13d
       jmp      G_M000_IG145
 
G_M000_IG100:                ;; offset=0x0BA6
       lea      rcx, bword ptr [rbx+0x58]
       mov      edx, r14d
       cmp      edx, 3
       je       SHORT G_M000_IG101
       cmp      edx, 26
       jne      G_M000_IG224
 
G_M000_IG101:                ;; offset=0x0BBB
       mov      edx, dword ptr [rdi+0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures:GetCell(int):Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:this]
       mov      r14, rax
       test     r14, r14
       je       G_M000_IG07
       mov      rcx, gword ptr [r14+0x10]
       test     rcx, rcx
       je       SHORT G_M000_IG102
       cmp      gword ptr [r14+0x18], 0
       je       G_M000_IG07
       cmp      gword ptr [rcx+0x88], 0
       jne      G_M000_IG07
 
G_M000_IG102:                ;; offset=0x0BF2
       mov      r8d, dword ptr [rdi+0x10]
       test     r8d, r8d
       jl       SHORT G_M000_IG106
       lea      rcx, bword ptr [rbx+0x48]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG226
       mov      edx, r8d
       shl      rdx, 4
       add      rdx, bword ptr [rcx]
       mov      r15, gword ptr [rdx]
       mov      r13, qword ptr [rdx+0x08]
       test     r15, r15
       jne      SHORT G_M000_IG105
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG103:                ;; offset=0x0C23
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
 
G_M000_IG104:                ;; offset=0x0C30
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rbp-0xE0]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
 
G_M000_IG105:                ;; offset=0x0C59
       jmp      SHORT G_M000_IG109
 
G_M000_IG106:                ;; offset=0x0C5B
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG107:                ;; offset=0x0C5F
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
 
G_M000_IG108:                ;; offset=0x0C6C
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rbp-0xE0]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      r15, rax
       xor      r13d, r13d
 
G_M000_IG109:                ;; offset=0x0C9B
       lea      rcx, bword ptr [rbx+0x48]
       mov      edx, dword ptr [rdi+0x10]
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG226
       mov      rcx, bword ptr [rcx]
       shl      rdx, 4
       xor      eax, eax
       mov      qword ptr [rcx+rdx], rax
       mov      qword ptr [rcx+rdx+0x08], rax
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG110
       not      edx
 
G_M000_IG110:                ;; offset=0x0CC6
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      gword ptr [rbp-0xF0], r15
       mov      qword ptr [rbp-0xE8], r13
       lea      rdx, [rbp-0xF0]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:StoreSlot(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG111:                ;; offset=0x0CF2
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StoreLocal(byref):this]
       jmp      G_M000_IG145
 
G_M000_IG112:                ;; offset=0x0D03
       mov      r8, 0x7FF9CCFBD018
       cmp      qword ptr [r14], r8
       jne      G_M000_IG166
 
G_M000_IG113:                ;; offset=0x0D16
       lea      r8, [rbp-0x88]
       mov      rcx, r14
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.PyAttributeLookup:TryResolveInstanceFunctionForCall(Lokad.Lython.Runtime.PyInstance,System.String,byref):bool]
       test     eax, eax
       je       G_M000_IG166
       mov      r13, gword ptr [rbp-0x88]
 
G_M000_IG114:                ;; offset=0x0D38
       test     r13, r13
       je       G_M000_IG07
       mov      ecx, dword ptr [rdi+0x1C]
       mov      edx, ecx
       cmp      edx, 51
       ja       SHORT G_M000_IG118
 
G_M000_IG115:                ;; offset=0x0D4B
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG118
 
G_M000_IG116:                ;; offset=0x0D5B
       mov      r15d, dword ptr [rdi+0x18]
       test     r15d, r15d
       jge      SHORT G_M000_IG117
       not      r15d
 
G_M000_IG117:                ;; offset=0x0D67
       jmp      SHORT G_M000_IG119
 
G_M000_IG118:                ;; offset=0x0D69
       mov      r15d, dword ptr [rdi+0x14]
 
G_M000_IG119:                ;; offset=0x0D6D
       cmp      ecx, 51
       ja       SHORT G_M000_IG124
 
G_M000_IG120:                ;; offset=0x0D72
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG124
 
G_M000_IG121:                ;; offset=0x0D82
       mov      ecx, dword ptr [rdi+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG122
       mov      r12d, ecx
       not      r12d
       jmp      SHORT G_M000_IG123
 
G_M000_IG122:                ;; offset=0x0D91
       mov      r12d, ecx
 
G_M000_IG123:                ;; offset=0x0D94
       jmp      SHORT G_M000_IG125
 
G_M000_IG124:                ;; offset=0x0D96
       mov      r12d, dword ptr [rdi+0x14]
 
G_M000_IG125:                ;; offset=0x0D9A
       inc      r12d
       cmp      r12d, dword ptr [rbx+0x3C]
       jge      SHORT G_M000_IG126
       mov      rcx, rbx
       mov      edx, r12d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG126:                ;; offset=0x0DAF
       lea      rcx, bword ptr [rbx+0x48]
       cmp      r15d, dword ptr [rcx+0x08]
       jae      G_M000_IG226
       mov      r15d, r15d
       shl      r15, 4
       add      r15, bword ptr [rcx]
       mov      rcx, r15
       mov      rdx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r15+0x08], rcx
       mov      dword ptr [rbx+0x3C], r12d
       mov      ecx, dword ptr [rdi+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG130
 
G_M000_IG127:                ;; offset=0x0DE4
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG130
 
G_M000_IG128:                ;; offset=0x0DF4
       mov      r14d, dword ptr [rdi+0x18]
       test     r14d, r14d
       jge      SHORT G_M000_IG129
       not      r14d
 
G_M000_IG129:                ;; offset=0x0E00
       jmp      SHORT G_M000_IG131
 
G_M000_IG130:                ;; offset=0x0E02
       mov      r14d, dword ptr [rdi+0x14]
 
G_M000_IG131:                ;; offset=0x0E06
       inc      r14d
       mov      ecx, dword ptr [rdi+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG132
       mov      edi, ecx
       not      edi
       jmp      SHORT G_M000_IG133
 
G_M000_IG132:                ;; offset=0x0E16
       mov      edi, ecx
 
G_M000_IG133:                ;; offset=0x0E18
       cmp      edi, dword ptr [rbx+0x3C]
       jge      SHORT G_M000_IG134
       mov      rcx, rbx
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG134:                ;; offset=0x0E28
       lea      rcx, bword ptr [rbx+0x48]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG226
       mov      r14d, r14d
       shl      r14, 4
       add      r14, bword ptr [rcx]
       mov      rcx, r14
       mov      rdx, r13
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r14+0x08], rcx
       mov      dword ptr [rbx+0x3C], edi
       jmp      G_M000_IG145
 
G_M000_IG135:                ;; offset=0x0E59
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StoreSubscript(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG145
       jmp      G_M000_IG07
 
G_M000_IG136:                ;; offset=0x0E72
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:ApplyDefinition(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG145
       jmp      G_M000_IG07
 
G_M000_IG137:                ;; offset=0x0E8B
       mov      rdx, gword ptr [rbx+0x08]
       mov      r14, rdx
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      edx, eax
       mov      rcx, r14
       mov      r8, gword ptr [rdi]
       mov      r9, gword ptr [rbx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0xF0], rax
       xor      r8d, r8d
       mov      qword ptr [rbp-0xE8], r8
       lea      r8, [rbp-0xF0]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG138:                ;; offset=0x0ED6
       mov      rcx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x20], rcx
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      r8d, dword ptr [rbx+0x38]
       mov      r9d, dword ptr [rbx+0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      SHORT G_M000_IG140
       lea      rcx, bword ptr [rbx+0x58]
       mov      edx, dword ptr [rdi+0x1C]
       cmp      edx, 3
       je       SHORT G_M000_IG139
       cmp      edx, 26
       jne      G_M000_IG224
 
G_M000_IG139:                ;; offset=0x0F11
       mov      edx, dword ptr [rdi+0x08]
       lea      r8, [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures:TryRead(int,byref):bool:this]
       test     eax, eax
       je       G_M000_IG07
       cmp      gword ptr [rbp-0x60], 0
       je       G_M000_IG07
       mov      r8, gword ptr [rbp-0x60]
       mov      gword ptr [rbp-0xF0], r8
       xor      r8d, r8d
       mov      qword ptr [rbp-0xE8], r8
       lea      r8, [rbp-0xF0]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG140:                ;; offset=0x0F5E
       add      dword ptr [rbx+0x38], 2
       jmp      G_M000_IG145
 
G_M000_IG141:                ;; offset=0x0F67
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      r8d, eax
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG142:                ;; offset=0x0F77
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
 
G_M000_IG143:                ;; offset=0x0F84
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rbp-0xE0]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      gword ptr [rbp-0xF0], rax
       xor      r8d, r8d
       mov      qword ptr [rbp-0xE8], r8
       lea      r8, [rbp-0xF0]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      SHORT G_M000_IG145
 
G_M000_IG144:                ;; offset=0x0FD3
       mov      rdx, gword ptr [rbx+0x08]
       mov      r14, gword ptr [rdx+0x30]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [r14+0x08]
       jae      G_M000_IG226
       mov      ecx, eax
       mov      rcx, gword ptr [r14+8*rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      gword ptr [rbp-0xF0], rax
       xor      r8d, r8d
       mov      qword ptr [rbp-0xE8], r8
       lea      r8, [rbp-0xF0]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
 
G_M000_IG145:                ;; offset=0x101F
       inc      dword ptr [rbx+0x38]
 
G_M000_IG146:                ;; offset=0x1022
       mov      ecx, dword ptr [rbx+0x38]
       mov      rax, gword ptr [rbx+0x08]
       cmp      ecx, dword ptr [rax+0xEC]
       jl       G_M000_IG03
 
G_M000_IG147:                ;; offset=0x1035
       mov      eax, dword ptr [rbx+0x38]
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x98]
       cmp      eax, dword ptr [rcx+0x08]
       setge    al
       movzx    rax, al
 
G_M000_IG148:                ;; offset=0x104C
       add      rsp, 248
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG149:                ;; offset=0x1060
       mov      rdx, gword ptr [rbx+0x08]
       mov      ecx, dword ptr [rdx+0xEC]
       mov      rdx, gword ptr [rdx+0x98]
       cmp      ecx, dword ptr [rdx+0x08]
       jne      G_M000_IG07
       jmp      G_M000_IG159
 
G_M000_IG150:                ;; offset=0x107F
       mov      rdx, gword ptr [rbx+0x08]
       mov      ecx, dword ptr [rdx+0xEC]
       mov      r9, gword ptr [rdx+0x98]
       cmp      ecx, dword ptr [r9+0x08]
       jne      G_M000_IG07
       mov      r8d, dword ptr [rdi+0x10]
       test     r8d, r8d
       jl       SHORT G_M000_IG154
       lea      rcx, bword ptr [rbx+0x48]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG226
       mov      r9d, r8d
       shl      r9, 4
       add      r9, bword ptr [rcx]
       mov      r14, gword ptr [r9]
       mov      r15, qword ptr [r9+0x08]
       test     r14, r14
       jne      SHORT G_M000_IG153
       mov      rcx, rdx
 
G_M000_IG151:                ;; offset=0x10CA
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
 
G_M000_IG152:                ;; offset=0x10D7
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rbp-0xE0]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
 
G_M000_IG153:                ;; offset=0x1100
       jmp      SHORT G_M000_IG157
 
G_M000_IG154:                ;; offset=0x1102
       mov      rcx, rdx
 
G_M000_IG155:                ;; offset=0x1105
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
 
G_M000_IG156:                ;; offset=0x1112
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rbp-0xE0]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      r14, rax
       xor      r15d, r15d
 
G_M000_IG157:                ;; offset=0x1141
       mov      rcx, rsi
       mov      rdx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      qword ptr [rsi+0x08], r15
       mov      edx, dword ptr [rdi+0x10]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      edx, dword ptr [rcx+0xD8]
       jl       SHORT G_M000_IG159
       lea      rcx, bword ptr [rbx+0x48]
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG226
       shl      rdx, 4
       add      rdx, bword ptr [rcx]
       xor      rcx, rcx
       mov      gword ptr [rdx], rcx
 
G_M000_IG158:                ;; offset=0x1178
       mov      qword ptr [rdx+0x08], rcx
 
G_M000_IG159:                ;; offset=0x117C
       mov      rdx, gword ptr [rbx+0x08]
       mov      edx, dword ptr [rdx+0xD8]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG160:                ;; offset=0x118F
       mov      eax, 1
 
G_M000_IG161:                ;; offset=0x1194
       add      rsp, 248
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG162:                ;; offset=0x11A8
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryExecuteCasedSplitMember(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG145
 
G_M000_IG163:                ;; offset=0x11BC
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG164:                ;; offset=0x11C0
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
 
G_M000_IG165:                ;; offset=0x11CD
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rbp-0xE0]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      r14, rax
       mov      rcx, gword ptr [rbx+0x08]
       mov      r15, gword ptr [rcx+0x38]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [r15+0x08]
       jae      G_M000_IG226
       mov      r8d, eax
       mov      r15, gword ptr [r15+8*r8+0x10]
       test     r14, r14
       jne      G_M000_IG112
 
G_M000_IG166:                ;; offset=0x1229
       mov      rcx, r14
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveBuiltinReceiverMethod(System.Object,System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      r13, rax
       jmp      G_M000_IG114
 
G_M000_IG167:                ;; offset=0x123D
       mov      rcx, gword ptr [rbx+0x08]
       mov      edx, dword ptr [rcx+0xEC]
       mov      r8, gword ptr [rcx+0x98]
       cmp      edx, dword ptr [r8+0x08]
       jne      G_M000_IG141
 
G_M000_IG168:                ;; offset=0x1258
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
 
G_M000_IG169:                ;; offset=0x1265
       mov      edx, dword ptr [rbx+0x30]
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rbp-0x50]
       mov      qword ptr [rsp+0x30], rdx
       lea      rdx, [rbp-0x58]
       mov      qword ptr [rsp+0x38], rdx
       lea      rdx, [rbp-0xE0]
       mov      r8d, dword ptr [rbx+0x38]
       mov      r9d, dword ptr [rbx+0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryPrepareFixedTupleReturn(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,byref):bool]
       test     eax, eax
       je       G_M000_IG141
 
G_M000_IG170:                ;; offset=0x12A4
       mov      ecx, dword ptr [rbx+0x30]
       add      dword ptr [rbx+0x3C], ecx
       mov      ecx, dword ptr [rbp-0x50]
       mov      dword ptr [rbx+0x38], ecx
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x98]
       mov      eax, dword ptr [rcx+0x08]
       cmp      dword ptr [rbp-0x50], eax
       jae      G_M000_IG226
       mov      eax, dword ptr [rbp-0x50]
       shl      rax, 5
       lea      rsi, bword ptr [rcx+rax+0x10]
       mov      rcx, gword ptr [rbx+0x10]
       mov      rdi, gword ptr [rcx+0xA0]
       mov      r14, gword ptr [rsi]
       cmp      byte  ptr [rdi], dil
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG171
       mov      rcx, rdi
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG171:                ;; offset=0x12FD
       mov      rcx, qword ptr [rbp-0x58]
       mov      r8, gword ptr [rsi]
       mov      rdx, gword ptr [rbx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:AdmitUnpackedReturnScalars(long,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      ecx, dword ptr [rsi+0x10]
       mov      dword ptr [rbx+0x34], ecx
       jmp      G_M000_IG160
 
G_M000_IG172:                ;; offset=0x1319
       mov      ecx, dword ptr [rdi+0x0C]
       add      ecx, 2
       mov      rdx, gword ptr [rbx+0x08]
       cmp      ecx, dword ptr [rdx+0xEC]
       jge      SHORT G_M000_IG175
       mov      rcx, gword ptr [rbx+0x10]
       mov      rcx, gword ptr [rcx+0xA0]
       cmp      qword ptr [rcx+0x158], 8
       jge      SHORT G_M000_IG175
       mov      rcx, rdx
 
G_M000_IG173:                ;; offset=0x1343
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
 
G_M000_IG174:                ;; offset=0x1350
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0x48]
       mov      qword ptr [rsp+0x28], rdx
       lea      rdx, [rbp-0xE0]
       mov      r9d, dword ptr [rbx+0x3C]
       lea      r8, bword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateIntegerCallUpdate(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG184
 
G_M000_IG175:                ;; offset=0x137B
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG176
       mov      r8d, edx
       not      r8d
       jmp      SHORT G_M000_IG177
 
G_M000_IG176:                ;; offset=0x138A
       mov      r8d, edx
 
G_M000_IG177:                ;; offset=0x138D
       mov      ecx, dword ptr [rdi+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG181
 
G_M000_IG178:                ;; offset=0x1395
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jb       SHORT G_M000_IG181
 
G_M000_IG179:                ;; offset=0x13A5
       test     edx, edx
       jge      SHORT G_M000_IG180
       not      edx
 
G_M000_IG180:                ;; offset=0x13AB
       jmp      SHORT G_M000_IG182
 
G_M000_IG181:                ;; offset=0x13AD
       mov      edx, dword ptr [rdi+0x14]
 
G_M000_IG182:                ;; offset=0x13B0
       cmp      r8d, edx
       jne      G_M000_IG141
 
G_M000_IG183:                ;; offset=0x13B9
       lea      r14, bword ptr [rbx+0x48]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [r14+0x08]
       jae      G_M000_IG226
       mov      rcx, bword ptr [r14]
       mov      eax, eax
       shl      rax, 4
       cmp      gword ptr [rcx+rax], 0
       jne      G_M000_IG145
       jmp      G_M000_IG223
 
G_M000_IG184:                ;; offset=0x13E9
       mov      rdx, gword ptr [rbx+0x08]
       mov      rdx, gword ptr [rdx+0x98]
       mov      r8d, dword ptr [rbx+0x38]
       cmp      r8d, dword ptr [rdx+0x08]
       jae      G_M000_IG226
       shl      r8, 5
       lea      rdx, bword ptr [rdx+r8+0x10]
 
G_M000_IG185:                ;; offset=0x140B
       vmovdqu  xmm0, xmmword ptr [rbp-0x48]
       vmovdqu  xmmword ptr [rbp-0xF0], xmm0
 
G_M000_IG186:                ;; offset=0x1418
       lea      r8, [rbp-0xF0]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG187:                ;; offset=0x142D
       lea      rcx, bword ptr [rbx+0x48]
       mov      edx, dword ptr [rdi+0x10]
       mov      r8d, dword ptr [rdi+0x08]
       mov      eax, edx
       mov      r10d, r8d
       add      rax, r10
       mov      r10d, dword ptr [rcx+0x08]
       cmp      rax, r10
       ja       G_M000_IG225
       shl      rdx, 4
       add      rdx, bword ptr [rcx]
       mov      bword ptr [rbp-0xE0], rdx
       mov      dword ptr [rbp-0xD8], r8d
       lea      rcx, [rbp-0xE0]
       mov      rdx, gword ptr [rbx+0x10]
       mov      rdx, gword ptr [rdx+0xA0]
       mov      r8, gword ptr [rdi]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReverseAssignmentValues(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.ExecutionState,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG145
 
G_M000_IG188:                ;; offset=0x1482
       lea      rcx, bword ptr [rbx+0x48]
       cmp      r14d, 51
       ja       SHORT G_M000_IG192
 
G_M000_IG189:                ;; offset=0x148C
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, r14
       jb       SHORT G_M000_IG192
 
G_M000_IG190:                ;; offset=0x149C
       mov      r14d, dword ptr [rdi+0x18]
       test     r14d, r14d
       jge      SHORT G_M000_IG191
       not      r14d
 
G_M000_IG191:                ;; offset=0x14A8
       jmp      SHORT G_M000_IG193
 
G_M000_IG192:                ;; offset=0x14AA
       mov      r14d, dword ptr [rdi+0x14]
 
G_M000_IG193:                ;; offset=0x14AE
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG226
       mov      rcx, bword ptr [rcx]
       mov      eax, r14d
       shl      rax, 4
 
G_M000_IG194:                ;; offset=0x14C2
       vmovdqu  xmm0, xmmword ptr [rcx+rax]
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG195:                ;; offset=0x14CC
       cmp      gword ptr [rbp-0x70], 0
       jne      SHORT G_M000_IG196
       lea      rcx, [rbp-0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9CCFB77C8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
 
G_M000_IG196:                ;; offset=0x14F0
       lea      rcx, bword ptr [rbx+0x48]
       mov      edx, dword ptr [rdi+0x1C]
       cmp      edx, 51
       ja       SHORT G_M000_IG200
 
G_M000_IG197:                ;; offset=0x14FC
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG200
 
G_M000_IG198:                ;; offset=0x150C
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG199
       not      edx
 
G_M000_IG199:                ;; offset=0x1515
       jmp      SHORT G_M000_IG201
 
G_M000_IG200:                ;; offset=0x1517
       mov      edx, dword ptr [rdi+0x14]
 
G_M000_IG201:                ;; offset=0x151A
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG226
       mov      rcx, bword ptr [rcx]
       mov      edx, edx
       shl      rdx, 4
       xor      eax, eax
       mov      qword ptr [rcx+rdx], rax
       mov      qword ptr [rcx+rdx+0x08], rax
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG202
       not      edx
 
G_M000_IG202:                ;; offset=0x1540
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rcx, bword ptr [rbx+0x48]
       mov      r8d, dword ptr [rbx+0x50]
       mov      rdx, gword ptr [rbp-0x70]
       mov      r9, qword ptr [rbp-0x68]
       mov      rax, gword ptr [rbx+0x10]
       mov      rax, gword ptr [rax+0xA0]
       mov      r10d, dword ptr [rdi+0x10]
       cmp      r10d, r8d
       jae      G_M000_IG226
       mov      r8d, r10d
       shl      r8, 4
       add      rcx, r8
       mov      gword ptr [rbp-0xF0], rdx
       mov      qword ptr [rbp-0xE8], r9
       lea      r8, [rbp-0xF0]
       mov      rdx, rdi
       mov      r9, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(byref,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG145
 
G_M000_IG203:                ;; offset=0x15A1
       mov      rdx, gword ptr [rbx+0x08]
       mov      r14, gword ptr [rdx+0x30]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [r14+0x08]
       jae      G_M000_IG226
       mov      edx, eax
       mov      rdx, gword ptr [r14+8*rdx+0x10]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG205
 
G_M000_IG204:                ;; offset=0x15CB
       mov      rax, 0x7FF9CCE0ABA8
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG221
 
G_M000_IG205:                ;; offset=0x15DE
       lea      rdx, bword ptr [rbx+0x48]
       mov      r8d, dword ptr [rdi+0x1C]
       mov      r9d, r8d
       cmp      r9d, 51
       ja       SHORT G_M000_IG209
 
G_M000_IG206:                ;; offset=0x15EF
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, r9
       jb       SHORT G_M000_IG209
 
G_M000_IG207:                ;; offset=0x15FF
       mov      r9d, dword ptr [rdi+0x18]
       test     r9d, r9d
       jge      SHORT G_M000_IG208
       not      r9d
 
G_M000_IG208:                ;; offset=0x160B
       jmp      SHORT G_M000_IG210
 
G_M000_IG209:                ;; offset=0x160D
       mov      r9d, dword ptr [rdi+0x14]
 
G_M000_IG210:                ;; offset=0x1611
       mov      eax, dword ptr [rdi+0x18]
       test     eax, eax
       jge      SHORT G_M000_IG211
       mov      r10d, eax
       not      r10d
       jmp      SHORT G_M000_IG212
 
G_M000_IG211:                ;; offset=0x1620
       mov      r10d, eax
 
G_M000_IG212:                ;; offset=0x1623
       cmp      r8d, 51
       ja       SHORT G_M000_IG217
 
G_M000_IG213:                ;; offset=0x1629
       mov      r11, 0x7FFFFFFFFF9FF
       bt       r11, r8
       jb       SHORT G_M000_IG217
 
G_M000_IG214:                ;; offset=0x1639
       test     eax, eax
       jge      SHORT G_M000_IG215
       mov      r8d, eax
       not      r8d
       jmp      SHORT G_M000_IG216
 
G_M000_IG215:                ;; offset=0x1645
       mov      r8d, eax
 
G_M000_IG216:                ;; offset=0x1648
       jmp      SHORT G_M000_IG218
 
G_M000_IG217:                ;; offset=0x164A
       mov      r8d, dword ptr [rdi+0x14]
 
G_M000_IG218:                ;; offset=0x164E
       sub      r10d, r8d
       mov      r8d, r9d
       mov      eax, r10d
       add      r8, rax
       mov      eax, dword ptr [rdx+0x08]
       cmp      r8, rax
       ja       G_M000_IG225
       mov      r8d, r9d
       shl      r8, 4
       add      r8, bword ptr [rdx]
       mov      bword ptr [rbp-0xE0], r8
       mov      dword ptr [rbp-0xD8], r10d
       mov      rdx, gword ptr [rdi]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0xE0]
       cmp      dword ptr [rdi+0x0C], 0
       setne    r8b
       movzx    r8, r8b
       mov      r9, gword ptr [rbx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      ecx, dword ptr [rdi+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG219
       not      ecx
 
G_M000_IG219:                ;; offset=0x16AC
       mov      dword ptr [rbx+0x3C], ecx
       jmp      G_M000_IG145
 
G_M000_IG220:                ;; offset=0x16B4
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Format(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG145
       jmp      G_M000_IG07
 
G_M000_IG221:                ;; offset=0x16CD
       mov      rcx, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG222:                ;; offset=0x16D6
       mov      rdx, rcx
       mov      rcx, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG223:                ;; offset=0x16E2
       mov      rcx, gword ptr [rbx+0x08]
       mov      rbx, gword ptr [rcx+0x68]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      edx, eax
       mov      rcx, rbx
       mov      r11, 0x7FF9CC902028
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rcx, rax
       mov      rdx, gword ptr [rdi]
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG224:                ;; offset=0x171A
       mov      rcx, rdi
       mov      rdx, 0x24D5EE1C1B8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG225:                ;; offset=0x1736
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG226:                ;; offset=0x173D
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	00000F7Eh ; case G_M000_IG144
       	dd	00000F12h ; case G_M000_IG141
       	dd	00000E81h ; case G_M000_IG138
       	dd	00000E36h ; case G_M000_IG137
       	dd	0000009Dh ; case G_M000_IG07
       	dd	00000E1Dh ; case G_M000_IG136
       	dd	0000009Dh ; case G_M000_IG07
       	dd	0000009Dh ; case G_M000_IG07
       	dd	00000E04h ; case G_M000_IG135
       	dd	00000E04h ; case G_M000_IG135
       	dd	0000009Dh ; case G_M000_IG07
       	dd	0000009Dh ; case G_M000_IG07
       	dd	0000009Dh ; case G_M000_IG07
       	dd	0000009Dh ; case G_M000_IG07
       	dd	0000009Dh ; case G_M000_IG07
       	dd	0000009Dh ; case G_M000_IG07
       	dd	0000009Dh ; case G_M000_IG07
       	dd	0000009Dh ; case G_M000_IG07
       	dd	0000009Dh ; case G_M000_IG07
       	dd	0000009Dh ; case G_M000_IG07
       	dd	0000009Dh ; case G_M000_IG07
       	dd	0000009Dh ; case G_M000_IG07
       	dd	00001167h ; case G_M000_IG163
       	dd	0000009Dh ; case G_M000_IG07
       	dd	00000C9Dh ; case G_M000_IG111
       	dd	00000B51h ; case G_M000_IG100
       	dd	0000009Dh ; case G_M000_IG07
       	dd	0000009Dh ; case G_M000_IG07
       	dd	00000A80h ; case G_M000_IG88
       	dd	00000A28h ; case G_M000_IG84
       	dd	0000099Fh ; case G_M000_IG83
       	dd	000008E6h ; case G_M000_IG80
       	dd	000008CDh ; case G_M000_IG79
       	dd	000008CDh ; case G_M000_IG79
       	dd	000008CDh ; case G_M000_IG79
       	dd	0000009Dh ; case G_M000_IG07
       	dd	0000009Dh ; case G_M000_IG07
       	dd	0000009Dh ; case G_M000_IG07
       	dd	0000009Dh ; case G_M000_IG07
       	dd	00000745h ; case G_M000_IG67
       	dd	00000643h ; case G_M000_IG53
       	dd	0000062Ah ; case G_M000_IG52
       	dd	0000030Bh ; case G_M000_IG29
       	dd	0000009Dh ; case G_M000_IG07
       	dd	0000009Dh ; case G_M000_IG07
       	dd	00000295h ; case G_M000_IG23
       	dd	00000295h ; case G_M000_IG23
       	dd	000002A6h ; case G_M000_IG24
       	dd	00000734h ; case G_M000_IG66
       	dd	00000217h ; case G_M000_IG20
       	dd	000000EDh ; case G_M000_IG10
       	dd	0000009Dh ; case G_M000_IG07
       	dd	0000009Dh ; case G_M000_IG07
       	dd	0000009Dh ; case G_M000_IG07
       	dd	0000009Dh ; case G_M000_IG07
       	dd	0000009Dh ; case G_M000_IG07
       	dd	0000102Ah ; case G_M000_IG150
       	dd	0000100Bh ; case G_M000_IG149
       	dd	0000100Bh ; case G_M000_IG149
       	dd	0000009Dh ; case G_M000_IG07
       	dd	0000009Dh ; case G_M000_IG07
       	dd	000000B3h ; case G_M000_IG09
       	dd	0000165Fh ; case G_M000_IG220
       	dd	0000165Fh ; case G_M000_IG220
       	dd	0000165Fh ; case G_M000_IG220
       	dd	0000165Fh ; case G_M000_IG220
       	dd	0000165Fh ; case G_M000_IG220
       	dd	0000009Dh ; case G_M000_IG07
       	dd	00000643h ; case G_M000_IG53
       	dd	0000154Ch ; case G_M000_IG203
       	dd	0000142Dh ; case G_M000_IG188
       	dd	00001364h ; case G_M000_IG183
       	dd	000013D8h ; case G_M000_IG187
       	dd	000012C4h ; case G_M000_IG172
       	dd	000011E8h ; case G_M000_IG167
       	dd	00001153h ; case G_M000_IG162
       	dd	00000F12h ; case G_M000_IG141

; Total bytes of code 5955

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:TryPrepareFixedTupleReturn(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,byref):bool (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 15 single block inlinees; 10 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 184
       lea      rbp, [rsp+0xF0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x80], ymm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       mov      rbx, rcx
       mov      esi, r8d
       mov      r15d, r9d
       mov      r13d, dword ptr [rbp+0x30]
       mov      r14, gword ptr [rbp+0x38]
       mov      rcx, bword ptr [rbp+0x40]
       mov      rdi, bword ptr [rbp+0x48]
 
G_M000_IG02:                ;; offset=0x0042
       mov      r12, bword ptr [rdx]
       mov      eax, dword ptr [rdx+0x08]
       mov      dword ptr [rbp-0x60], eax
       mov      rdx, gword ptr [rbx+0x98]
       cmp      esi, dword ptr [rdx+0x08]
       jae      G_M000_IG43
       mov      r8d, esi
       shl      r8, 5
       mov      edx, dword ptr [rdx+r8+0x1C]
       mov      dword ptr [rcx], edx
       xor      edx, edx
       mov      qword ptr [rdi], rdx
       mov      rdx, gword ptr [rbx+0x98]
       mov      ecx, dword ptr [rcx]
       cmp      ecx, dword ptr [rdx+0x08]
       jae      G_M000_IG43
       shl      rcx, 5
       lea      rdx, bword ptr [rdx+rcx+0x10]
       mov      bword ptr [rbp-0x88], rdx
       mov      rcx, rdx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       cmp      eax, r13d
       jne      G_M000_IG40
 
G_M000_IG03:                ;; offset=0x00A2
       mov      rcx, bword ptr [rbp-0x88]
       cmp      r15d, dword ptr [rcx+0x10]
       jne      G_M000_IG40
       mov      ecx, r15d
       mov      eax, r13d
       add      rcx, rax
       mov      edx, dword ptr [rbp-0x60]
       cmp      rcx, rdx
       ja       G_M000_IG42
       mov      ecx, r15d
       shl      rcx, 4
       add      rcx, r12
       mov      bword ptr [rbp-0xB0], rcx
       mov      dword ptr [rbp-0x64], r13d
       xor      edx, edx
       mov      dword ptr [rbp-0x3C], edx
 
G_M000_IG04:                ;; offset=0x00E2
       xor      r15d, r15d
       test     r13d, r13d
       je       G_M000_IG34
 
G_M000_IG05:                ;; offset=0x00EE
       mov      rdx, gword ptr [rbx+0x98]
       lea      r8d, [rsi+r15]
       cmp      r8d, dword ptr [rdx+0x08]
       jae      G_M000_IG35
       shl      r8, 5
       lea      rdx, bword ptr [rdx+r8+0x10]
       mov      bword ptr [rbp-0x90], rdx
       mov      r8, gword ptr [rdx]
       mov      gword ptr [rbp-0x98], r8
       mov      r10, gword ptr [r14+0xA0]
       mov      gword ptr [rbp-0xA0], r10
       cmp      byte  ptr [r10], r10b
       mov      rcx, r10
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x013B
       mov      rcx, gword ptr [rbp-0xA0]
       mov      rdx, gword ptr [rbp-0x98]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG07:                ;; offset=0x014F
       mov      rax, bword ptr [rbp-0x90]
       cmp      dword ptr [rax+0x1C], 46
       je       G_M000_IG28
 
G_M000_IG08:                ;; offset=0x0160
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [rbp-0x60]
       jae      G_M000_IG35
       mov      edx, eax
       shl      rdx, 4
       add      rdx, r12
       mov      rax, gword ptr [rdx]
       mov      r10, qword ptr [rdx+0x08]
       test     rax, rax
       je       G_M000_IG18
       mov      qword ptr [rbp-0x70], r10
       test     r10, r10
       je       SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x0194
       mov      r10, qword ptr [rbp-0x70]
       jmp      SHORT G_M000_IG18
 
G_M000_IG10:                ;; offset=0x019A
       mov      rdx, 0x22D38001CF0
       mov      r9, gword ptr [rdx]
       mov      gword ptr [rbp-0xC8], r9
       cmp      rax, r9
       jne      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x01B3
       mov      r10, qword ptr [rbp-0x70]
       jmp      SHORT G_M000_IG18
 
G_M000_IG12:                ;; offset=0x01B9
       mov      rdx, 0x22D38001CF8
       cmp      rax, gword ptr [rdx]
       jne      SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x01C8
       mov      r10, qword ptr [rbp-0x70]
       jmp      SHORT G_M000_IG18
 
G_M000_IG14:                ;; offset=0x01CE
       mov      rdx, 0x7FF9CCFB7330
       cmp      qword ptr [rax], rdx
       jne      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x01DD
       mov      r10, qword ptr [rbp-0x70]
       jmp      SHORT G_M000_IG18
 
G_M000_IG16:                ;; offset=0x01E3
       mov      gword ptr [rbp-0xB8], rax
       mov      rdx, rax
       mov      rcx, 0x7FF9CCFAC400
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       G_M000_IG27
 
G_M000_IG17:                ;; offset=0x0205
       mov      rax, gword ptr [rbp-0xB8]
       mov      r10, qword ptr [rbp-0x70]
 
G_M000_IG18:                ;; offset=0x0210
       mov      rdx, 0x22D38001CF0
       mov      r9, gword ptr [rdx]
       mov      gword ptr [rbp-0xC8], r9
       cmp      rax, r9
       je       G_M000_IG26
       mov      qword ptr [rbp-0x70], r10
       test     r10, r10
       jle      SHORT G_M000_IG20
       mov      gword ptr [rbp-0xB8], rax
       mov      rdx, rax
       mov      rcx, 0x7FF9CCF188D8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG21
 
G_M000_IG19:                ;; offset=0x0254
       mov      rax, gword ptr [rbp-0xB8]
 
G_M000_IG20:                ;; offset=0x025B
       lea      rdx, [rbp-0x50]
       mov      gword ptr [rbp-0xB8], rax
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG24
 
G_M000_IG21:                ;; offset=0x0271
       mov      r11, rax
       mov      r10, qword ptr [rbp-0x70]
       lea      ecx, [r10-0x01]
       mov      dword ptr [rbp-0x5C], ecx
       mov      gword ptr [rbp-0xA8], r11
       mov      rdx, gword ptr [r11+0x08]
       mov      rcx, 0x7FF9CC9C2560
       call     CORINFO_HELP_ISINSTANCEOFARRAY
       test     rax, rax
       je       SHORT G_M000_IG23
       xor      ecx, ecx
       mov      qword ptr [rbp-0x50], rcx
 
G_M000_IG22:                ;; offset=0x02A4
       xor      eax, eax
       jmp      SHORT G_M000_IG24
 
G_M000_IG23:                ;; offset=0x02A8
       mov      rcx, gword ptr [rbp-0xA8]
       mov      edx, dword ptr [rbp-0x5C]
       call     [Lokad.Lython.Runtime.PyTuple:WritableValueSlot(int):byref:this]
       mov      rcx, rax
       lea      rdx, [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
 
G_M000_IG24:                ;; offset=0x02C5
       test     eax, eax
       mov      rdx, gword ptr [rbp-0xB8]
       jne      SHORT G_M000_IG29
 
G_M000_IG25:                ;; offset=0x02D0
       xor      ebx, ebx
       jmp      G_M000_IG37
 
G_M000_IG26:                ;; offset=0x02D7
       mov      qword ptr [rbp-0x50], r10
       mov      qword ptr [rbp-0x70], r10
       mov      rdx, rax
       jmp      SHORT G_M000_IG29
 
G_M000_IG27:                ;; offset=0x02E4
       mov      rdx, gword ptr [rbp-0xB8]
       jmp      SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x02ED
       mov      bword ptr [rbp-0x80], r12
       mov      r8d, dword ptr [rbp-0x60]
       mov      dword ptr [rbp-0x78], r8d
       lea      rdx, [rbp-0x48]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0x80]
       mov      rcx, rbx
       mov      r8, rax
       mov      r9, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluatePreparedBinary(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG25
       mov      r10, qword ptr [rbp-0x48]
       mov      rcx, 0x22D38001CF0
       mov      r9, gword ptr [rcx]
       mov      rax, r9
       mov      gword ptr [rbp-0xC8], rax
       mov      rcx, rax
       mov      rdx, rcx
       mov      qword ptr [rbp-0x70], r10
 
G_M000_IG29:                ;; offset=0x033E
       mov      r10, r15
       shl      r10, 4
       add      r10, bword ptr [rbp-0xB0]
       mov      rcx, r10
       mov      bword ptr [rbp-0xC0], rcx
       mov      gword ptr [rbp-0xB8], rdx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, bword ptr [rbp-0xC0]
       mov      rcx, qword ptr [rbp-0x70]
       mov      qword ptr [rdx+0x08], rcx
       mov      rax, qword ptr [rdi]
       mov      qword ptr [rbp-0x58], rax
       mov      r8, gword ptr [rbp-0xB8]
       mov      rdx, gword ptr [rbp-0xC8]
       cmp      r8, rdx
       je       SHORT G_M000_IG31
 
G_M000_IG30:                ;; offset=0x038B
       mov      rdx, 0x22D38001CF8
       cmp      r8, gword ptr [rdx]
       je       SHORT G_M000_IG31
       test     rcx, rcx
       jle      SHORT G_M000_IG32
       mov      gword ptr [rbp-0xB8], r8
       mov      rdx, r8
       mov      rcx, 0x7FF9CCF188D8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       mov      r8, gword ptr [rbp-0xB8]
       je       SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x03C4
       mov      edx, 64
       jmp      SHORT G_M000_IG33
 
G_M000_IG32:                ;; offset=0x03CB
       mov      rcx, r8
       call     [Lokad.Lython.Runtime.RuntimeMemoryEstimates:EstimateScalarStorageBytes(System.Object):long]
       mov      rdx, rax
 
G_M000_IG33:                ;; offset=0x03D7
       mov      rcx, qword ptr [rbp-0x58]
       add      rdx, rcx
       jo       SHORT G_M000_IG36
       mov      qword ptr [rdi], rdx
       inc      r15d
       cmp      r15d, r13d
       jl       G_M000_IG05
 
G_M000_IG34:                ;; offset=0x03EF
       mov      dword ptr [rbp-0x3C], 1
       mov      ebx, 1
       jmp      SHORT G_M000_IG37
 
G_M000_IG35:                ;; offset=0x03FD
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG36:                ;; offset=0x0403
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG37:                ;; offset=0x0409
       cmp      dword ptr [rbp-0x3C], 0
       jne      SHORT G_M000_IG38
       mov      edx, r13d
       add      rdx, rdx
       mov      rcx, bword ptr [rbp-0xB0]
       call     [System.SpanHelpers:ClearWithReferences(byref,nuint)]
 
G_M000_IG38:                ;; offset=0x0422
       mov      eax, ebx
 
G_M000_IG39:                ;; offset=0x0424
       add      rsp, 184
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG40:                ;; offset=0x0438
       xor      eax, eax
 
G_M000_IG41:                ;; offset=0x043A
       add      rsp, 184
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG42:                ;; offset=0x044E
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG43:                ;; offset=0x0455
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG44:                ;; offset=0x045B
       sub      rsp, 40
 
G_M000_IG45:                ;; offset=0x045F
       cmp      dword ptr [rbp-0x3C], 0
       jne      SHORT G_M000_IG46
       mov      edx, dword ptr [rbp-0x64]
       add      rdx, rdx
       mov      rcx, bword ptr [rbp-0xB0]
       call     [System.SpanHelpers:ClearWithReferences(byref,nuint)]
 
G_M000_IG46:                ;; offset=0x0478
       nop      
 
G_M000_IG47:                ;; offset=0x0479
       add      rsp, 40
       ret      
 
; Total bytes of code 1150

