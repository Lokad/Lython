from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
donor=lab.with_name('native-callable-definition-20261124')
comparison=lab/'comparison'
quiet=comparison/'quiet'
quiet.mkdir(exist_ok=True)
core='Lokad.Lython.dll'
reference='regex-flag-continuations-b1576-20261124'
root='prepared-tuple-exit-b1583-20261124'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(path):
    return sha(path.read_bytes())


def write(path,value):
    path.write_text(value,encoding='utf-8',newline='\n')


def save(path,value):
    write(path,json.dumps(value,indent=2)+'\n')


replicas=json.loads((lab/'verified-replicas.json').read_text(encoding='utf-8'))
original=donor/'comparison/quiet'
collector=(original/'collect.py').read_text(encoding='utf-8')
collector=collector.replace('b1578-','b1583-').replace('len(jobs) == 7','len(jobs) == 5')
collector=collector.replace('time.monotonic()-started < 410','time.monotonic()-started < 315')
needle="'reference':root.parent/'regex-flag-continuations-b1576-20261124'/'candidate'"
assert collector.count(needle)==1
collector=collector.replace(needle,"'reference':root/'reference'")
assert 'len(jobs) == 5' in collector
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
shutil.copyfile(original/'run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz') as bundle:
    for name in ('identity.json','representative.json','jobs.json'):
        bundle.add(comparison/name,arcname=name)
    for name in ('collect.py','run.sh'):
        bundle.add(quiet/name,arcname=name)
    for role in ('reference','candidate'):
        bundle.add(lab/role/core,arcname=role+'-core.dll')
save(quiet/'upload.json',dict(root=root,reference=reference,payloadSHA256=digest(payload),payloadBytes=payload.stat().st_size))
launch=(donor/'quiet.py').read_text(encoding='utf-8')
launch=launch.replace('b1578-native-callable-definition','b1583-prepared-tuple-exit').replace('b1578-','b1583-')
launch=launch.replace('RuntimeMaxSec=435','RuntimeMaxSec=345').replace('seconds=369','seconds=280')
launch=launch.replace("'collect.py','candidate-core.dll'","'collect.py','candidate-core.dll','reference-core.dll'")
launch=launch.replace('minimum_active = 10 * 1024 * 1024','minimum_active = 5 * 1024 * 1024')
launch=launch.replace('A 10 MiB','A 5 MiB')
start=launch.index('  retired=[]')
end=launch.index('  root.mkdir()',start)
launch=launch[:start]+"""  retired=[]
  if free<minimum:
   available=free
   verified=[]
   for group in configuration['duplicates']:
    aliases=group['aliases']
    names=[]
    inode=None
    for saved in aliases:
     replica=base/saved['path']
     assert replica.resolve()==replica and replica.is_relative_to(base) and replica.is_file()
     archive=replica.parent.parent
     assert archive!=reference and not (archive/'guest-fixtures').exists()
     stat_info=replica.stat()
     key=(stat_info.st_dev, stat_info.st_ino)
     if inode is None: inode=key
     assert inode==key and stat_info.st_nlink==len(aliases)
     assert digest(replica)==group['sha256'] and digest(archive/'observations.tar.xz')==saved['observationSHA256']
     names.append(replica)
    assert len(set(names))==len(aliases)
    verified.append((group,names))
    available+=names[0].stat().st_blocks*512
    if available>=minimum: break
   assert available>=minimum,(available,minimum)
   for group,names in verified:
    for replica in names: replica.unlink()
    retired.append(group)
   free=shutil.disk_usage(base).free
  assert free>=minimum,(free,'needs two cores, receipts and working room')
"""+launch[end:]
start=launch.index("  image=root/role if role")
end=launch.index(" os.link(reference/'cpython-worker.py'",start)
launch=launch[:start]+"""  image=root/role
  image.mkdir()
  for name,sha in files.items():
   if name=='Lokad.Lython.dll':
    (root/(role+'-core.dll')).rename(image/name)
   else:
    os.link(reference/'candidate'/name,image/name)
   assert digest(image/name)==sha,(role,name)
"""+launch[end:]
import ast
remote_stage, = (n.value for n in ast.walk(ast.parse(launch)) if isinstance(n, ast.Constant) and isinstance(n.value, str) and n.value.startswith('digest=lambda path:'))
compile(remote_stage,'remote-stage','exec')
compile(launch,'quiet.py','exec')
write(lab/'quiet.py',launch)
summary=(donor/'summarize.py').read_text(encoding='utf-8')
summary=summary.replace('receipt["warmJobs"] == 7','receipt["warmJobs"] == 5')
summary=summary.replace('len(warm["jobs"])==7','len(warm["jobs"])==5').replace('timedBatches=196','timedBatches=140')
compile(summary,'summarize.py','exec')
write(lab/'summarize.py',summary)
