from pathlib import Path
import ast
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.with_name('native-completed-call-workspace-20261124')
text_read = lab.with_name('decoded-ascii-file-values-20261124')
core = 'Lokad.Lython.dll'

def emit(path, source):
    compile(source, str(path), 'exec')
    path.write_text(source, encoding='utf-8', newline='\n')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def tracked(path):
    return subprocess.check_output(['git','show','origin/master:benchmarks/results/'+path],cwd=repo)

prepare = (donor/'prepare.py').read_text(encoding='utf-8')
prepare = prepare.replace("lab.with_name('regex-wrapper-cache-20261124')","lab.with_name('native-completed-call-workspace-20261124')")
prepare = prepare.replace("'840eba2a7'","'b8c2aa8c8'")
a = prepare.index("nested=read(")
b = prepare.index("assert len(catalog['cases'])==5", a)
prepare = prepare[:a] + prepare[b:]
prepare = prepare.replace('B1582 complete proven native calls before workspace setup',
                          'B1583 complete fixed tuple return during existing preparation')
emit(lab/'prepare.py', prepare)

stage = (donor/'stage.py').read_text(encoding='utf-8')
stage = stage.replace('b1582','b1583').replace('native-completed-call-workspace','prepared-tuple-exit')
stage = stage.replace('minimum_active = 7 * 1024 * 1024','minimum_active = 5 * 1024 * 1024')
stage = stage.replace('A 7 MiB','A 5 MiB')
emit(lab/'stage.py', stage)

result = '2026-11-24-native-completed-call-workspace'
remote = 'native-completed-call-workspace-b1582-20261124'
replicas = []
for role in ('reference','candidate'):
    archive = f'{result}/{role}-core.dll.gz'
    binary = sha(gzip.decompress(tracked(archive)))
    receipt = json.loads(tracked(f'{result}/terminal-status.json'))['receipt']
    assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
    assert sha(tracked(f'{result}/observations.tar.xz')) == receipt['archiveSHA256']
    assert json.loads(tracked(f'{result}/identity.json'))['imageFiles'][role][core] == binary
    replicas.append(dict(sha256=binary,coreArchive=archive,aliases=[
        dict(path=f'{remote}/{role}/{core}',observationSHA256=receipt['archiveSHA256'],source=result)]))
(lab/'verified-replicas.json').write_text(json.dumps(replicas,indent=2)+'\n', encoding='utf-8', newline='\n')
