from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
tree = repo/'.git/agent-worktrees/regex-wrapper-cache-20261124'
comparison = lab/'comparison'
identity = json.loads((comparison/'identity.json').read_text(encoding='utf-8'))
catalog = json.loads((comparison/'representative.json').read_text(encoding='utf-8'))
runtime = Path.home()/'.dotnet11'
dotnet = runtime/'dotnet.exe'
env = dict(os.environ,DOTNET_ROOT=str(runtime),DOTNET_ROOT_X64=str(runtime))
modified = 'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Integers.cs'
entry = tree/modified
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
candidate = identity['candidate']

code = """
    private static class FixedTupleDiagnostic
    {
        private static readonly System.Collections.Concurrent.ConcurrentDictionary<string,int> Counts = new();
        static FixedTupleDiagnostic()
        {
            AppDomain.CurrentDomain.ProcessExit += (_, _) =>
            {
                foreach (var item in Counts.OrderBy(item => item.Key))
                    Console.Error.WriteLine($"FIXED_TUPLE_RETURN\t{item.Key}\t{item.Value}");
            };
        }

        internal static void Add(string name) => Counts.AddOrUpdate(name, 1, static (_, count) => count + 1);
    }

"""
results = {}

def clean():
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=tree)

clean()
for role, commit in (('reference',identity['sourceRevision']),('candidate',candidate)):
    try:
        subprocess.run(['git','switch','--detach',commit],cwd=tree,check=True)
        clean()
        original = entry.read_text(encoding='utf-8')
        a = '    private static bool TryEvaluateIntegerInstruction('
        b = '            return completed = true;'
        assert original.count(a)==original.count(b)==1
        body = original.replace(a,code+a).replace(b,'            FixedTupleDiagnostic.Add(code.Name);\n'+b)
        entry.write_text(body, encoding='utf-8', newline='\n')
        patch = subprocess.check_output(['git','-c','core.safecrlf=false','diff','--binary','--',modified],cwd=tree)
        (lab/f'{role}-route.patch').write_bytes(patch)
        build = lab/(role+'-route-build')
        subprocess.run([dotnet,'build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-incremental','--artifacts-path',build],
                       cwd=tree,env=env,check=True,stdout=subprocess.DEVNULL,timeout=60)
        image = lab/(role+'-route-image')
        image.mkdir(exist_ok=True)
        files = identity['imageFiles'][role] | identity['helperFiles']
        for name,expected in files.items():
            assert digest(lab/role/name)==expected
            shutil.copyfile(lab/role/name,image/name)
        core = 'Lokad.Lython.dll'
        shutil.copyfile(build/'bin/Lokad.Lython/release_net11.0'/core,image/core)
        files[core]=digest(image/core)
        cases = {}
        for index,case in enumerate(catalog['cases']):
            input_path = lab/f'diagnostic-case-{index}.json'
            output_path = lab/f'{role}-diagnostic-output-{index}.json'
            input_path.write_text(json.dumps(catalog | {'cases':[case]},ensure_ascii=False),encoding='utf-8',newline='\n')
            run = subprocess.run([dotnet,image/'ValidatedAllocation.dll',image,input_path,output_path],
                                 env=env,capture_output=True,encoding='utf-8',timeout=40)
            assert run.returncode==0,(run.stdout,run.stderr)
            row, = json.loads(output_path.read_text(encoding='utf-8'))['rows']
            assert row['sharedBudgetBaselineRestored'] and row['id']==case['id']
            counts = {}
            for line in run.stderr.splitlines():
                tag, name, count = line.split('\t')
                assert tag=='FIXED_TUPLE_RETURN' and name not in counts
                counts[name]=int(count)
            cases[case['id']] = counts
        assert all(digest(image/name)==value for name,value in files.items())
        results[role] = dict(source=commit,image=files,counts=cases)
    finally:
        subprocess.run(['git','restore','--',modified],cwd=tree,check=True)
        clean()
        subprocess.run(['git','switch','--detach',candidate],cwd=tree,check=True)
        clean()

for role,data in results.items():
    print(role,data['counts'])
(lab/'prepared-routes.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8',newline='\n')
