from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.with_name('prepared-tuple-exit-20261124')
core='Lokad.Lython.dll'
receipt=json.loads((prior/'comparison/identity.json').read_text(encoding='utf-8'))
role='reference'
source=prior/role/core
sha=lambda data:hashlib.sha256(data).hexdigest()
assert sha(source.read_bytes())==receipt['imageFiles'][role][core]
target=lab/'reference-build/bin/Lokad.Lython/release_net11.0'/core
target.parent.mkdir(parents=True,exist_ok=True)
shutil.copyfile(source,target)

def emit(p,s):
    compile(s,str(p),'exec')
    p.write_text(s,encoding='utf-8',newline='\n')

prepare=(prior/'prepare.py').read_text(encoding='utf-8')
prepare=prepare.replace('B1583 complete fixed tuple return during existing preparation',
                        'B1584 admit prepared tuple returns away from shared dispatch')
emit(lab/'prepare.py',prepare)
stage=(prior/'stage.py').read_text(encoding='utf-8')
stage=stage.replace('b1583','b1584').replace('prepared-tuple-exit','prepared-tuple-exit-refined')
stage=stage.replace("    for role in ('reference','candidate'):\n        bundle.add", "    for role in ('candidate',):\n        bundle.add")
stage=stage.replace("launch=launch.replace(\"'collect.py','candidate-core.dll'\",\"'collect.py','candidate-core.dll','reference-core.dll'\")", "")
needle="""   if name=='Lokad.Lython.dll':
    (root/(role+'-core.dll')).rename(image/name)
"""
instead="""   if name=='Lokad.Lython.dll':
    if role=='candidate':
     (root/'candidate-core.dll').rename(image/name)
    else:
     donor_core = base/'prepared-tuple-exit-b1583-20261124'/'reference'/name
     assert donor_core.resolve()==donor_core and digest(donor_core)==sha
     os.link(donor_core,image/name)
"""
assert stage.count(needle)==1
stage=stage.replace(needle,instead)
emit(lab/'stage.py',stage)
result='2026-11-24-prepared-tuple-exit'
remote='prepared-tuple-exit-b1583-20261124'
def tracked(path):
    return subprocess.check_output(['git','show','origin/master:benchmarks/results/'+path],cwd=repo)
archive=f'{result}/candidate-core.dll.gz'
binary=sha(gzip.decompress(tracked(archive)))
terminal=json.loads(tracked(f'{result}/terminal-status.json'))['receipt']
assert terminal['complete'] and terminal['archivedAndVerifiedUnderLease']
assert sha(tracked(f'{result}/observations.tar.xz'))==terminal['archiveSHA256']
assert json.loads(tracked(f'{result}/identity.json'))['imageFiles']['candidate'][core]==binary
replicas=[dict(sha256=binary,coreArchive=archive,aliases=[
    dict(path=f'{remote}/candidate/{core}',observationSHA256=terminal['archiveSHA256'],source=result)])]
(lab/'verified-replicas.json').write_text(json.dumps(replicas,indent=2)+'\n',encoding='utf-8',newline='\n')
