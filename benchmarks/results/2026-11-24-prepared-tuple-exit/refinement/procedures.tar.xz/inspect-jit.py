from pathlib import Path
import json,hashlib,os,re,subprocess
lab=Path(__file__).resolve().parent
identity=json.loads((lab/'comparison/identity.json').read_text(encoding='utf-8'))
dotnet=Path.home()/'.dotnet11/dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent))
rows=[]
for role,files in identity['imageFiles'].items():
    image=lab/role
    assert all(hashlib.sha256((image/name).read_bytes()).hexdigest()==digest for name,digest in (files|identity['helperFiles']).items())
    log=lab/(role+'-native.asm')
    output=lab/(role+'-jit-allocation.json')
    subprocess.run([dotnet,image/'ValidatedAllocation.dll',image,lab/'comparison/representative.json',output],
        env=dict(env,DOTNET_TieredCompilation='0',DOTNET_JitDisasm='RunCore TryPrepareFixedTupleReturn TryPrepareIntegerTuple CompleteFixedReturn CopyFixedReturn ExecuteInstructionPrefix',
                 DOTNET_JitStdOutFile=str(log)),timeout=50,check=True)
    assert all(row['sharedBudgetBaselineRestored'] for row in json.loads(output.read_text(encoding='utf-8'))['rows'])
    methods=[]
    for entry in log.read_text(encoding='utf-8-sig').split('; Assembly listing for method ')[1:]:
        signature, asm=entry.split('\n',1)
        if 'Lokad.Lython.Runtime.LythonRuntime' not in signature: continue
        method=signature.split(':',1)[1].split('(',1)[0]
        stack=re.search(r'\bsub\s+rsp,\s*(\d+)\b',asm)
        totals=re.search(r'Total bytes of code (\d+)',asm)
        methods.append(dict(method=method,tier=signature.rsplit(' (',1)[-1].strip(')'),stack=int(stack[1]) if stack else 0,
                     bytes=int(totals[1]),countsScalarCapacity=bool(re.search(r'call.*ScalarStorageBytes',asm))))
    print(role,methods)
    assert any(method['method']=='RunCore' for method in methods)
    expected='TryPrepareFixedTupleReturn' if role=='candidate' else 'TryPrepareIntegerTuple'
    assert any(method['method']==expected for method in methods)
    rows.append(dict(role=role,methods=methods,coreSHA256=files['Lokad.Lython.dll']))
(lab/'jit-summary.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
