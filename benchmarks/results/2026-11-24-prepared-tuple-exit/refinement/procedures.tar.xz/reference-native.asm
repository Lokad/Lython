; Assembly listing for method Lokad.Lython.LythonCompiledScript:RunCore(Lokad.Lython.ILythonHost,Lokad.Lython.LythonRunOptions):Lokad.Lython.LythonExecutionResult:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 7 single block inlinees; 0 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 72
       lea      rbp, [rsp+0x70]
       mov      rsi, rcx
       mov      rdi, rdx
       mov      rbx, r8
 
G_M000_IG02:                ;; offset=0x001A
       mov      r14, gword ptr [rsi+0x08]
       test     r14, r14
       je       G_M000_IG13
       test     rbx, rbx
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x002C
       mov      rcx, 0x7FF9CCD81FA0
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
 
G_M000_IG04:                ;; offset=0x003E
       mov      r15, gword ptr [rbx+0x38]
       test     r15, r15
       jne      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0047
       mov      r15, gword ptr [rsi+0x20]
       test     r15, r15
       jne      SHORT G_M000_IG06
       mov      rcx, 0x7FF9CCC25BD8
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      byte  ptr [rbp-0x38], 0
       xor      edx, edx
       mov      qword ptr [rbp-0x30], rdx
       lea      rdx, [rbp-0x38]
       mov      rcx, r15
       call     [Lokad.Lython.LythonMemoryBudget:.ctor(System.Nullable`1[long]):this]
 
G_M000_IG06:                ;; offset=0x0079
       mov      rcx, r15
       mov      r11, 0x7FF9CC911C90
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      gword ptr [rbp-0x40], rax
 
G_M000_IG07:                ;; offset=0x008D
       mov      rcx, gword ptr [rbx+0x40]
       test     rcx, rcx
       cmove    rcx, r15
       mov      r11, 0x7FF9CC911C98
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      r9, rax
       mov      gword ptr [rbp-0x48], r9
 
G_M000_IG08:                ;; offset=0x00AC
       mov      rdx, gword ptr [rbx+0x60]
       mov      rcx, rbx
       mov      r8, gword ptr [rbp-0x40]
       call     [Lokad.Lython.LythonRunOptions:Copy(System.Threading.CancellationToken,Lokad.Lython.ILythonMemoryBudget,Lokad.Lython.ILythonMemoryBudget):Lokad.Lython.LythonRunOptions:this]
       mov      r8, rax
       mov      rdx, rdi
       mov      rcx, gword ptr [r14+0x10]
       call     [r14+0x18]System.Func`3[System.__Canon,System.__Canon,System.__Canon]:Invoke(System.__Canon,System.__Canon):System.__Canon:this
       mov      rbx, rax
       lea      rcx, bword ptr [rbx+0x28]
       mov      rdx, gword ptr [rbp-0x48]
       call     CORINFO_HELP_ASSIGN_REF
       nop      
 
G_M000_IG09:                ;; offset=0x00DC
       cmp      gword ptr [rbp-0x40], 0
       je       SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x00E3
       mov      rcx, gword ptr [rbp-0x40]
       mov      r11, 0x7FF9CC911CA8
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG11:                ;; offset=0x00F4
       mov      rax, rbx
 
G_M000_IG12:                ;; offset=0x00F7
       add      rsp, 72
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG13:                ;; offset=0x0104
       mov      rcx, 0x7FF9CCD5A5F0
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x18F4A14C950
       call     [System.ObjectDisposedException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG14:                ;; offset=0x0132
       sub      rsp, 40
 
G_M000_IG15:                ;; offset=0x0136
       mov      rcx, gword ptr [rbp-0x48]
       mov      r11, 0x7FF9CC911CA0
       call     [r11]System.IDisposable:Dispose():this
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG16:                ;; offset=0x014D
       sub      rsp, 40
 
G_M000_IG17:                ;; offset=0x0151
       cmp      gword ptr [rbp-0x40], 0
       je       SHORT G_M000_IG18
       mov      rcx, gword ptr [rbp-0x40]
       mov      r11, 0x7FF9CC911CA8
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG18:                ;; offset=0x0169
       nop      
 
G_M000_IG19:                ;; offset=0x016A
       add      rsp, 40
       ret      
 
; Total bytes of code 367

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInstructionPrefix(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref,byref,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 28 inlinees with PGO data; 305 single block inlinees; 76 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 984
       lea      rbp, [rsp+0x410]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x330], xmm4
       vmovdqa  xmmword ptr [rbp-0x320], xmm4
       mov      rax, -720
 
G_M000_IG383:                ;; offset=0x0039
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG383
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      dword ptr [rbp+0x28], r9d
       mov      rbx, r8
       mov      rsi, bword ptr [rbp+0x30]
       mov      r8, bword ptr [rbp+0x38]
       mov      rax, bword ptr [rbp+0x40]
       mov      r10, bword ptr [rbp+0x48]
 
G_M000_IG02:                ;; offset=0x0074
       mov      r9, bword ptr [r10]
       mov      bword ptr [rbp-0x390], r9
       mov      r10d, dword ptr [r10+0x08]
       mov      dword ptr [rbp-0x2E0], r10d
       xor      r9d, r9d
       mov      qword ptr [rsi], r9
       mov      qword ptr [rsi+0x08], r9
 
G_M000_IG03:                ;; offset=0x0093
       mov      gword ptr [r8], r9
 
G_M000_IG04:                ;; offset=0x0096
       mov      qword ptr [rax], r9
       mov      qword ptr [rax+0x08], r9
       mov      qword ptr [rax+0x10], r9
       mov      r9, gword ptr [rcx]
       mov      r9, gword ptr [r9+0x98]
       mov      gword ptr [rbp-0x338], r9
       mov      edi, dword ptr [r9+0x08]
       cmp      dword ptr [rcx+0x10], edi
       jge      G_M000_IG364
 
G_M000_IG05:                ;; offset=0x00BF
       mov      rdx, gword ptr [rbp+0x18]
       xor      r11d, r11d
       mov      dword ptr [rbp-0x3C], r11d
       mov      r11d, dword ptr [rcx+0x10]
       cmp      r11d, edi
       jae      G_M000_IG372
       shl      r11, 5
       lea      r11, bword ptr [r9+r11+0x10]
       mov      bword ptr [rbp-0x340], r11
       mov      r14, gword ptr [rdx+0xA0]
       mov      r11, bword ptr [rbp-0x340]
       mov      r15, gword ptr [r11]
       cmp      byte  ptr [r14], r14b
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x0108
       mov      rcx, r14
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG07:                ;; offset=0x0115
       mov      rcx, bword ptr [rbp-0x340]
       mov      r14d, dword ptr [rcx+0x1C]
       cmp      r14d, 77
       ja       G_M000_IG293
 
G_M000_IG08:                ;; offset=0x012A
       mov      ecx, r14d
       lea      rdx, [reloc @RWD00]
       mov      edx, dword ptr [rdx+4*rcx]
       lea      r8, G_M000_IG02
       add      rdx, r8
       jmp      rdx
 
G_M000_IG09:                ;; offset=0x0143
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       test     rbx, rbx
       je       G_M000_IG151
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG12
       mov      r8, bword ptr [rbp-0x340]
 
G_M000_IG10:                ;; offset=0x0161
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x320], ymm0
 
G_M000_IG11:                ;; offset=0x016E
       lea      r8, [rbp-0x320]
       lea      rdx, [rbp-0x248]
       mov      rcx, rbx
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x258]
       lea      rdx, [rbp-0x248]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rdi, rsi
       mov      rdx, gword ptr [rbp-0x258]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x250]
       mov      qword ptr [rdi+0x08], rdx
       mov      rdi, gword ptr [rsi]
       test     rdi, rdi
       je       G_M000_IG58
       jmp      G_M000_IG299
 
G_M000_IG12:                ;; offset=0x01CD
       mov      r8, bword ptr [rbp-0x340]
 
G_M000_IG13:                ;; offset=0x01D4
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x320], ymm0
 
G_M000_IG14:                ;; offset=0x01E1
       lea      r8, [rbp-0x320]
       lea      rdx, [rbp-0xB8]
       mov      rcx, rbx
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       mov      rdi, gword ptr [rbp-0xB8]
       movsx    r14, word  ptr [rbp-0xB0]
       test     rdi, rdi
       je       G_M000_IG361
 
G_M000_IG15:                ;; offset=0x0213
       mov      rdx, rdi
       mov      rcx, 0x7FF9CCD0F848
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      G_M000_IG297
 
G_M000_IG16:                ;; offset=0x022E
       mov      rcx, rdi
       mov      edx, r14d
       mov      r11, 0x7FF9CC911E88
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG361
 
G_M000_IG17:                ;; offset=0x0246
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       movzx    rcx, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], ecx
       lea      rcx, [rbp-0x80]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, r15
       mov      rdx, r13
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecutePreparedOperation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG151
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG20
 
G_M000_IG18:                ;; offset=0x0283
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0x330], xmm0
 
G_M000_IG19:                ;; offset=0x0290
       lea      rdx, [rbp-0x330]
       lea      rcx, [rbp-0x268]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rdi, rsi
       mov      rdx, gword ptr [rbp-0x268]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x260]
       mov      qword ptr [rdi+0x08], rdx
       mov      rdi, gword ptr [rsi]
       test     rdi, rdi
       je       G_M000_IG58
       jmp      G_M000_IG312
 
G_M000_IG20:                ;; offset=0x02D2
       mov      rdi, gword ptr [rbp-0x80]
       movsx    r14, word  ptr [rbp-0x78]
       test     rdi, rdi
       je       G_M000_IG361
 
G_M000_IG21:                ;; offset=0x02E4
       mov      rdx, rdi
       mov      rcx, 0x7FF9CCD0F848
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      G_M000_IG310
 
G_M000_IG22:                ;; offset=0x02FF
       mov      rcx, rdi
       mov      edx, r14d
       mov      r11, 0x7FF9CC911EA8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG361
 
G_M000_IG23:                ;; offset=0x0317
       mov      r13, gword ptr [rbp+0x18]
       test     rbx, rbx
       je       G_M000_IG151
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r15]
       mov      rdi, gword ptr [rcx+0x38]
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG360
       mov      ecx, eax
       mov      rcx, gword ptr [rdi+8*rcx+0x10]
       mov      rdx, bword ptr [rbp-0x340]
       mov      rdx, gword ptr [rdx]
       mov      r8, rbx
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveName(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      rdi, rax
       mov      r9, bword ptr [rbp-0x340]
       mov      r14d, dword ptr [r9+0x18]
       test     r14d, r14d
       jge      SHORT G_M000_IG24
       mov      gword ptr [rbp-0x300], rdi
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2F8], r9
       lea      r9, [rbp-0x300]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x340]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG361
 
G_M000_IG24:                ;; offset=0x03A8
       lea      rax, bword ptr [r15+0x20]
       mov      bword ptr [rbp-0x378], rax
       mov      rcx, bword ptr [rbp-0x340]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG27
 
G_M000_IG25:                ;; offset=0x03C2
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x03D2
       mov      r8d, r14d
       mov      dword ptr [rbp-0x2D4], r8d
       jmp      SHORT G_M000_IG28
 
G_M000_IG27:                ;; offset=0x03DE
       mov      r8, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [r8+0x14]
       mov      dword ptr [rbp-0x2D4], r8d
 
G_M000_IG28:                ;; offset=0x03F0
       cmp      r14d, dword ptr [rax+0x40]
       jge      SHORT G_M000_IG29
       mov      rcx, rax
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp-0x378]
 
G_M000_IG29:                ;; offset=0x0409
       mov      rcx, gword ptr [rax]
       mov      r8d, dword ptr [rbp-0x2D4]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG360
       mov      edx, r8d
       shl      rdx, 4
       lea      r8, bword ptr [rcx+rdx+0x10]
       mov      rcx, r8
       mov      bword ptr [rbp-0x3A8], rcx
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      rdi, bword ptr [rbp-0x3A8]
       mov      qword ptr [rdi+0x08], rcx
       mov      rdi, bword ptr [rbp-0x378]
       mov      dword ptr [rdi+0x40], r14d
       jmp      G_M000_IG361
 
G_M000_IG30:                ;; offset=0x0458
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       mov      rdi, gword ptr [r15]
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      edx, eax
       mov      rcx, rdi
       mov      r8, bword ptr [rbp-0x340]
       mov      r8, gword ptr [r8]
       mov      r9, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rdi, rax
       mov      r9, bword ptr [rbp-0x340]
       mov      r14d, dword ptr [r9+0x18]
       test     r14d, r14d
       jge      SHORT G_M000_IG31
       mov      gword ptr [rbp-0x300], rdi
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2F8], r9
       lea      r9, [rbp-0x300]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x340]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG361
 
G_M000_IG31:                ;; offset=0x04CB
       lea      rax, bword ptr [r15+0x20]
       mov      bword ptr [rbp-0x370], rax
       mov      rcx, bword ptr [rbp-0x340]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG34
 
G_M000_IG32:                ;; offset=0x04E5
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x04F5
       mov      r8d, r14d
       mov      dword ptr [rbp-0x2D0], r8d
       jmp      SHORT G_M000_IG35
 
G_M000_IG34:                ;; offset=0x0501
       mov      r8, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [r8+0x14]
       mov      dword ptr [rbp-0x2D0], r8d
 
G_M000_IG35:                ;; offset=0x0513
       cmp      r14d, dword ptr [rax+0x40]
       jge      SHORT G_M000_IG36
       mov      rcx, rax
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp-0x370]
 
G_M000_IG36:                ;; offset=0x052C
       mov      rcx, gword ptr [rax]
       mov      r8d, dword ptr [rbp-0x2D0]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG360
       mov      edx, r8d
       shl      rdx, 4
       lea      r8, bword ptr [rcx+rdx+0x10]
       mov      rcx, r8
       mov      bword ptr [rbp-0x3B0], rcx
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      rdi, bword ptr [rbp-0x3B0]
       mov      qword ptr [rdi+0x08], rcx
       mov      rdi, bword ptr [rbp-0x370]
       mov      dword ptr [rdi+0x40], r14d
       jmp      G_M000_IG361
 
G_M000_IG37:                ;; offset=0x057B
       mov      r15, bword ptr [rbp+0x10]
       cmp      gword ptr [r15+0x40], 0
       jne      SHORT G_M000_IG38
       mov      r13, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], r13
       mov      rcx, gword ptr [r15]
       mov      rdx, gword ptr [r15+0x18]
       mov      r8d, dword ptr [r15+0x10]
       mov      r9d, dword ptr [r15+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      G_M000_IG45
 
G_M000_IG38:                ;; offset=0x05AC
       mov      r13, gword ptr [rbp+0x18]
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      r8d, eax
       lea      r9, [rbp-0x60]
       mov      qword ptr [rsp+0x20], r9
       mov      r9, bword ptr [rbp-0x340]
       mov      r9, gword ptr [r9]
       mov      rdx, rbx
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime:TryLoadClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       G_M000_IG151
       mov      rdi, gword ptr [rbp-0x60]
       mov      r9, bword ptr [rbp-0x340]
       mov      r14d, dword ptr [r9+0x18]
       test     r14d, r14d
       jge      SHORT G_M000_IG39
       mov      gword ptr [rbp-0x300], rdi
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2F8], r9
       lea      r9, [rbp-0x300]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x340]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG361
 
G_M000_IG39:                ;; offset=0x062B
       lea      rax, bword ptr [r15+0x20]
       mov      bword ptr [rbp-0x360], rax
       mov      rcx, bword ptr [rbp-0x340]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG42
 
G_M000_IG40:                ;; offset=0x0645
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG42
 
G_M000_IG41:                ;; offset=0x0655
       mov      r8d, r14d
       mov      dword ptr [rbp-0x298], r8d
       jmp      SHORT G_M000_IG43
 
G_M000_IG42:                ;; offset=0x0661
       mov      r8, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [r8+0x14]
       mov      dword ptr [rbp-0x298], r8d
 
G_M000_IG43:                ;; offset=0x0673
       cmp      r14d, dword ptr [rax+0x40]
       jge      SHORT G_M000_IG44
       mov      rcx, rax
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp-0x360]
 
G_M000_IG44:                ;; offset=0x068C
       mov      rcx, gword ptr [rax]
       mov      r8d, dword ptr [rbp-0x298]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG360
       mov      edx, r8d
       shl      rdx, 4
       lea      r8, bword ptr [rcx+rdx+0x10]
       mov      rcx, r8
       mov      bword ptr [rbp-0x3B8], rcx
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      rdi, bword ptr [rbp-0x3B8]
       mov      qword ptr [rdi+0x08], rcx
       mov      rdi, bword ptr [rbp-0x360]
       mov      dword ptr [rdi+0x40], r14d
       jmp      G_M000_IG361
 
G_M000_IG45:                ;; offset=0x06DB
       add      dword ptr [r15+0x10], 2
       jmp      G_M000_IG361
 
G_M000_IG46:                ;; offset=0x06E5
       mov      gword ptr [rbp-0x300], r14
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2F8], r9
       lea      r9, [rbp-0x300]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x340]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG361
 
G_M000_IG47:                ;; offset=0x0715
       mov      r8, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [r8+0x14]
       mov      dword ptr [rbp-0x294], r8d
 
G_M000_IG48:                ;; offset=0x0727
       cmp      edi, dword ptr [rax+0x40]
       jge      SHORT G_M000_IG49
       mov      rcx, rax
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp-0x358]
 
G_M000_IG49:                ;; offset=0x073E
       mov      rcx, gword ptr [rax]
       mov      r8d, dword ptr [rbp-0x294]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG360
       mov      edx, r8d
       shl      rdx, 4
       lea      r8, bword ptr [rcx+rdx+0x10]
       mov      rcx, r8
       mov      bword ptr [rbp-0x3C0], rcx
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      r14, bword ptr [rbp-0x3C0]
       mov      qword ptr [r14+0x08], rcx
       mov      r14, bword ptr [rbp-0x358]
       mov      dword ptr [r14+0x40], edi
       jmp      G_M000_IG361
 
G_M000_IG50:                ;; offset=0x078D
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r15]
       mov      rdi, gword ptr [rcx+0x30]
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG360
       mov      ecx, eax
       mov      rcx, gword ptr [rdi+8*rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      rdi, rax
       mov      r9, bword ptr [rbp-0x340]
       mov      r14d, dword ptr [r9+0x18]
       test     r14d, r14d
       jge      SHORT G_M000_IG51
       mov      gword ptr [rbp-0x300], rdi
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2F8], r9
       lea      r9, [rbp-0x300]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x340]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG361
 
G_M000_IG51:                ;; offset=0x07FE
       lea      rax, bword ptr [r15+0x20]
       mov      bword ptr [rbp-0x368], rax
       mov      rcx, bword ptr [rbp-0x340]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG54
 
G_M000_IG52:                ;; offset=0x0818
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG54
 
G_M000_IG53:                ;; offset=0x0828
       mov      r8d, r14d
       mov      dword ptr [rbp-0x2CC], r8d
       jmp      SHORT G_M000_IG55
 
G_M000_IG54:                ;; offset=0x0834
       mov      r8, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [r8+0x14]
       mov      dword ptr [rbp-0x2CC], r8d
 
G_M000_IG55:                ;; offset=0x0846
       cmp      r14d, dword ptr [rax+0x40]
       jge      SHORT G_M000_IG56
       mov      rcx, rax
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp-0x368]
 
G_M000_IG56:                ;; offset=0x085F
       mov      rcx, gword ptr [rax]
       mov      r8d, dword ptr [rbp-0x2CC]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG360
       mov      edx, r8d
       shl      rdx, 4
       lea      r8, bword ptr [rcx+rdx+0x10]
       mov      rcx, r8
       mov      bword ptr [rbp-0x3C8], rcx
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       xor      edx, edx
       mov      rdi, bword ptr [rbp-0x3C8]
       mov      qword ptr [rdi+0x08], rdx
       mov      rdi, bword ptr [rbp-0x368]
       mov      dword ptr [rdi+0x40], r14d
       jmp      G_M000_IG361
 
G_M000_IG57:                ;; offset=0x08AE
       test     rbx, rbx
       je       G_M000_IG151
       mov      r15, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [r15]
       mov      rcx, gword ptr [rdx+0xA8]
       mov      rdx, bword ptr [rbp-0x340]
       mov      edx, dword ptr [rdx+0x08]
       mov      r11, 0x7FF9CC911E80
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG59
       lea      rcx, [rbp-0x280]
       mov      rdx, rax
       mov      r8, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteImportAsync(Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Threading.Tasks.ValueTask]
       lea      rcx, [rbp-0x290]
       lea      rdx, [rbp-0x280]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rdi, rsi
       mov      rdx, gword ptr [rbp-0x290]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x288]
       mov      qword ptr [rdi+0x08], rdx
       mov      rdi, gword ptr [rsi]
       test     rdi, rdi
       jne      G_M000_IG319
 
G_M000_IG58:                ;; offset=0x0932
       mov      r15, bword ptr [rbp+0x10]
       mov      r13, gword ptr [rbp+0x18]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG361
 
G_M000_IG59:                ;; offset=0x0948
       mov      rcx, gword ptr [r15]
       mov      r8, gword ptr [r15+0x08]
       mov      rdx, rax
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteExecutableImport(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext)]
       jmp      G_M000_IG361
 
G_M000_IG60:                ;; offset=0x0960
       test     rbx, rbx
       je       G_M000_IG151
       mov      r15, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [r15+0x20]
       mov      rdx, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [rdx+0x10]
       mov      edx, r14d
       cmp      edx, 51
       ja       SHORT G_M000_IG65
 
G_M000_IG61:                ;; offset=0x0984
       mov      r9, 0x7FFFFFFFFF9FF
       bt       r9, rdx
       jb       SHORT G_M000_IG65
 
G_M000_IG62:                ;; offset=0x0994
       mov      rdx, bword ptr [rbp-0x340]
       mov      edx, dword ptr [rdx+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG63
       mov      r9d, edx
       not      r9d
       jmp      SHORT G_M000_IG64
 
G_M000_IG63:                ;; offset=0x09AA
       mov      r9d, edx
 
G_M000_IG64:                ;; offset=0x09AD
       jmp      SHORT G_M000_IG66
 
G_M000_IG65:                ;; offset=0x09AF
       mov      r9, bword ptr [rbp-0x340]
       mov      r9d, dword ptr [r9+0x14]
 
G_M000_IG66:                ;; offset=0x09BA
       lea      rdx, [rbp-0xC8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      r14d, dword ptr [r15+0x10]
       inc      r14d
       mov      r13, gword ptr [rbx+0x70]
       cmp      byte  ptr [rbx+0x10A], 0
       jne      SHORT G_M000_IG67
       cmp      byte  ptr [rbx+0x108], 0
       jne      SHORT G_M000_IG67
       cmp      edi, r14d
       jg       SHORT G_M000_IG68
 
G_M000_IG67:                ;; offset=0x09E9
       xor      r12d, r12d
       jmp      SHORT G_M000_IG69
 
G_M000_IG68:                ;; offset=0x09EE
       cmp      r14d, edi
       jae      G_M000_IG360
       mov      r8d, r14d
       shl      r8, 5
       mov      rax, gword ptr [rbp-0x338]
       cmp      dword ptr [rax+r8+0x2C], 30
       sete     r12b
       movzx    r12, r12b
 
G_M000_IG69:                ;; offset=0x0A13
       test     r12d, r12d
       je       SHORT G_M000_IG72
       test     r13, r13
       je       SHORT G_M000_IG72
 
G_M000_IG70:                ;; offset=0x0A1D
       vmovdqu  xmm0, xmmword ptr [rbp-0xC8]
       vmovdqu  xmmword ptr [rbp-0x300], xmm0
 
G_M000_IG71:                ;; offset=0x0A2D
       lea      r8, [rbp-0x300]
       mov      rdx, r13
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryAppendBufferedYield(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG73
 
G_M000_IG72:                ;; offset=0x0A44
       lea      rdi, bword ptr [rbx+0x198]
       mov      rdx, gword ptr [rbp-0xC8]
       mov      rcx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, qword ptr [rbp-0xC0]
       mov      qword ptr [rdi+0x08], rcx
       mov      word  ptr [rbx+0x100], 257
       inc      dword ptr [r15+0x10]
       test     r12d, r12d
       jne      G_M000_IG266
       test     r13, r13
       je       G_M000_IG266
       mov      rcx, rbx
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG266
       jmp      G_M000_IG363
 
G_M000_IG73:                ;; offset=0x0A9D
       cmp      r14d, edi
       jae      G_M000_IG360
       mov      ecx, r14d
       shl      rcx, 5
       mov      rax, gword ptr [rbp-0x338]
       mov      rdi, gword ptr [rax+rcx+0x10]
       mov      r13, gword ptr [rbp+0x18]
       mov      r12, gword ptr [r13+0xA0]
       cmp      byte  ptr [r12], r12b
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG74
       mov      rcx, r12
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG74:                ;; offset=0x0AE1
       mov      rcx, gword ptr [r13+0xA0]
       mov      rdx, rcx
       mov      rax, gword ptr [rbx+0x78]
       test     rax, rax
       je       SHORT G_M000_IG75
       cmp      dword ptr [rax+0x10], 0
       setg     al
       movzx    rax, al
       test     eax, eax
       je       SHORT G_M000_IG75
       mov      rax, gword ptr [rcx+0x148]
       jmp      SHORT G_M000_IG76
 
G_M000_IG75:                ;; offset=0x0B0B
       mov      rax, gword ptr [rbx+0x80]
 
G_M000_IG76:                ;; offset=0x0B12
       lea      rcx, bword ptr [rdx+0x148]
       mov      rdx, rax
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [r15+0x20]
       mov      edx, r14d
       shl      rdx, 5
       mov      rax, gword ptr [rbp-0x338]
       lea      rdx, bword ptr [rax+rdx+0x10]
       mov      edx, dword ptr [rdx+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG77
       not      edx
 
G_M000_IG77:                ;; offset=0x0B41
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       add      dword ptr [r15+0x10], 2
       jmp      G_M000_IG363
 
G_M000_IG78:                ;; offset=0x0B51
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       movzx    rcx, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], ecx
       mov      bword ptr [rsp+0x28], rsi
       mov      r8, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x30], r8
       mov      rcx, r15
       mov      rdx, r13
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteComparisonInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref):int]
       test     eax, eax
       je       G_M000_IG231
       mov      dword ptr [rbp-0xA4], eax
       jmp      G_M000_IG369
 
G_M000_IG79:                ;; offset=0x0B98
       mov      rdx, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [rdx+0x10]
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r15]
       mov      rdx, gword ptr [r15+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG80
       lea      r9, bword ptr [rdx+0x10]
       mov      edx, dword ptr [rdx+0x08]
       jmp      SHORT G_M000_IG81
 
G_M000_IG80:                ;; offset=0x0BBC
       xor      r9, r9
       xor      edx, edx
 
G_M000_IG81:                ;; offset=0x0BC1
       mov      bword ptr [rbp-0x2F0], r9
       mov      dword ptr [rbp-0x2E8], edx
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      r13, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x28], r13
       mov      rdx, gword ptr [r15+0x18]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rbp-0x2F0]
       mov      r9d, dword ptr [r15+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      rdi, rax
       test     rbx, rbx
       jne      SHORT G_M000_IG82
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       je       G_M000_IG151
 
G_M000_IG82:                ;; offset=0x0C10
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG87
       test     rdi, rdi
       je       SHORT G_M000_IG87
 
G_M000_IG83:                ;; offset=0x0C1B
       mov      r8, 0x7FF9CCFCD018
       cmp      qword ptr [rdi], r8
       jne      SHORT G_M000_IG87
 
G_M000_IG84:                ;; offset=0x0C2A
       mov      r8, bword ptr [rbp-0x340]
 
G_M000_IG85:                ;; offset=0x0C31
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x320], ymm0
 
G_M000_IG86:                ;; offset=0x0C3E
       lea      r8, [rbp-0x320]
       lea      rdx, [rbp-0x1A8]
       mov      rcx, rbx
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteConditionalJumpAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rdi, rsi
       mov      rdx, gword ptr [rbp-0x1A8]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x1A0]
       mov      qword ptr [rdi+0x08], rdx
       mov      rdi, gword ptr [rsi]
       test     rdi, rdi
       je       G_M000_IG231
       jmp      G_M000_IG354
 
G_M000_IG87:                ;; offset=0x0C85
       mov      rcx, r15
       mov      rdx, r13
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG361
 
G_M000_IG88:                ;; offset=0x0CA3
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       test     rbx, rbx
       jne      SHORT G_M000_IG90
       mov      ecx, r14d
       cmp      ecx, 58
       ja       G_M000_IG151
 
G_M000_IG89:                ;; offset=0x0CBC
       mov      rdx, 0x1FDFFFFFFFFFFFF
       bt       rdx, rcx
       jb       G_M000_IG151
 
G_M000_IG90:                ;; offset=0x0CD0
       mov      rcx, r15
       mov      rdx, r13
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp-0x3C], eax
       cmp      gword ptr [r15+0x68], 0
       je       G_M000_IG361
       cmp      byte  ptr [rbp+0x28], 0
       je       G_M000_IG266
       cmp      gword ptr [r15+0x40], 0
       je       G_M000_IG266
       xor      rcx, rcx
       mov      gword ptr [rsi], rcx
       mov      word  ptr [rsi+0x08], 0
       movzx    rcx, byte  ptr [rbp-0x3C]
       mov      byte  ptr [rsi+0x0A], cl
       mov      byte  ptr [rsi+0x0B], 1
       mov      dword ptr [rbp-0xA4], 5
       jmp      G_M000_IG369
 
G_M000_IG91:                ;; offset=0x0D2E
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, r15
       mov      rdx, r13
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteBuiltinArithmetic(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG98
       jmp      G_M000_IG361
 
G_M000_IG92:                ;; offset=0x0D59
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       test     rbx, rbx
       je       G_M000_IG151
 
G_M000_IG93:                ;; offset=0x0D6A
       mov      r14, bword ptr [rbp+0x10]
       mov      rdi, gword ptr [rbp+0x18]
       mov      rcx, rbx
       mov      rdx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG361
 
G_M000_IG94:                ;; offset=0x0D87
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       test     rbx, rbx
       je       G_M000_IG151
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG93
       mov      r8, bword ptr [rbp-0x340]
 
G_M000_IG95:                ;; offset=0x0DA5
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x320], ymm0
 
G_M000_IG96:                ;; offset=0x0DB2
       lea      r8, [rbp-0x320]
       lea      rdx, [rbp-0x1B8]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSliceValueOperationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x1C8]
       lea      rdx, [rbp-0x1B8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r14, rsi
       mov      rdx, gword ptr [rbp-0x1C8]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x1C0]
       mov      qword ptr [r14+0x08], rdx
       mov      rdi, gword ptr [rsi]
       test     rdi, rdi
       je       G_M000_IG58
       jmp      G_M000_IG351
 
G_M000_IG97:                ;; offset=0x0E0B
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, r15
       mov      rdx, r13
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSequenceIndex(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG361
 
G_M000_IG98:                ;; offset=0x0E31
       mov      r15, bword ptr [rbp+0x10]
       mov      r13, gword ptr [rbp+0x18]
       movzx    rcx, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], ecx
       mov      bword ptr [rsp+0x28], rsi
       mov      rcx, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x30], rcx
       mov      r12, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x38], r12
       mov      rcx, r15
       mov      rdx, r13
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInputInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref,byref):int]
       test     eax, eax
       je       G_M000_IG361
       mov      dword ptr [rbp-0xA4], eax
       jmp      G_M000_IG369
 
G_M000_IG99:                ;; offset=0x0E81
       mov      r15, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [r15]
       mov      rcx, gword ptr [rdx+0xB0]
       cmp      r14d, 42
       jne      G_M000_IG334
       mov      rdx, bword ptr [rbp-0x340]
       mov      edx, dword ptr [rdx+0x08]
       mov      r11, 0x7FF9CC911E78
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r14, rax
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      edi, eax
       mov      rdx, bword ptr [rbp-0x340]
       cmp      dword ptr [rdx+0x0C], 0x7FFFFFFF
       je       G_M000_IG123
       cmp      dword ptr [r15+0x60], edi
       jne      G_M000_IG123
       mov      rdx, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [rdx+0x10]
       mov      rcx, gword ptr [r15]
       mov      rdx, gword ptr [r15+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG100
       lea      r9, bword ptr [rdx+0x10]
       mov      edx, dword ptr [rdx+0x08]
       jmp      SHORT G_M000_IG101
 
G_M000_IG100:                ;; offset=0x0F00
       xor      r9, r9
       xor      edx, edx
 
G_M000_IG101:                ;; offset=0x0F05
       mov      bword ptr [rbp-0x2F0], r9
       mov      dword ptr [rbp-0x2E8], edx
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      r13, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x28], r13
       mov      rdx, gword ptr [r15+0x18]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rbp-0x2F0]
       mov      r9d, dword ptr [r15+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      r12, rax
       mov      r8, bword ptr [rbp-0x340]
       mov      eax, dword ptr [r8+0x0C]
       mov      dword ptr [rbp-0xCC], eax
       mov      r8, bword ptr [rbp-0x340]
       cmp      dword ptr [r8+0x10], 0
       jl       G_M000_IG108
       test     rbx, rbx
       je       G_M000_IG108
       test     r12, r12
       je       G_M000_IG108
 
G_M000_IG102:                ;; offset=0x0F73
       mov      r8, 0x7FF9CCFC5CA0
       cmp      qword ptr [r12], r8
       jne      G_M000_IG108
 
G_M000_IG103:                ;; offset=0x0F87
       mov      r8, gword ptr [r15+0x20]
       cmp      eax, dword ptr [r8+0x08]
       jae      G_M000_IG360
       mov      edx, eax
       shl      rdx, 4
 
G_M000_IG104:                ;; offset=0x0F9B
       vmovdqu  xmm0, xmmword ptr [r8+rdx+0x10]
       vmovdqu  xmmword ptr [rbp-0x300], xmm0
 
G_M000_IG105:                ;; offset=0x0FAA
       lea      r8, [rbp-0xE0]
       mov      qword ptr [rsp+0x20], r8
       lea      r8, [rbp-0x300]
       mov      rdx, r14
       mov      rcx, r12
       mov      r9, r13
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartForwardedComputedDefinition(Lokad.Lython.Frontend.ExecutableCallSite,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool:this]
       test     eax, eax
       mov      eax, dword ptr [rbp-0xCC]
       je       SHORT G_M000_IG108
 
G_M000_IG106:                ;; offset=0x0FD6
       vmovdqu  xmm0, xmmword ptr [rbp-0xE0]
       vmovdqu  xmmword ptr [rbp-0x300], xmm0
 
G_M000_IG107:                ;; offset=0x0FE6
       lea      r9, [rbp-0x300]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x340]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG361
 
G_M000_IG108:                ;; offset=0x1005
       test     eax, eax
       jl       SHORT G_M000_IG113
       mov      r8, gword ptr [r15+0x20]
       cmp      eax, dword ptr [r8+0x08]
       jae      G_M000_IG360
       mov      ecx, eax
       shl      rcx, 4
       lea      r8, bword ptr [r8+rcx+0x10]
       mov      rcx, qword ptr [r8+0x08]
       test     rcx, rcx
       mov      eax, dword ptr [rbp-0xCC]
       jle      SHORT G_M000_IG113
       mov      r8, gword ptr [r8]
       test     r8, r8
       je       SHORT G_M000_IG111
 
G_M000_IG109:                ;; offset=0x1039
       mov      rdx, 0x7FF9CCD557F0
       cmp      qword ptr [r8], rdx
       jne      SHORT G_M000_IG111
 
G_M000_IG110:                ;; offset=0x1048
       mov      r8d, 1
       jmp      SHORT G_M000_IG112
 
G_M000_IG111:                ;; offset=0x1050
       xor      r8d, r8d
 
G_M000_IG112:                ;; offset=0x1053
       test     r8d, r8d
       je       SHORT G_M000_IG113
       lea      r8, [rbp-0xF0]
       mov      qword ptr [rsp+0x20], r8
       mov      r8, gword ptr [r14+0x18]
       mov      rdx, r12
       mov      r9, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeShortUtf8Float(long,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       mov      eax, dword ptr [rbp-0xCC]
       jne      G_M000_IG142
 
G_M000_IG113:                ;; offset=0x1082
       mov      rcx, gword ptr [r15]
       mov      rdx, gword ptr [r15+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG114
       lea      r9, bword ptr [rdx+0x10]
       mov      edx, dword ptr [rdx+0x08]
       jmp      SHORT G_M000_IG115
 
G_M000_IG114:                ;; offset=0x1097
       xor      r9, r9
       xor      edx, edx
 
G_M000_IG115:                ;; offset=0x109C
       mov      bword ptr [rbp-0x2F0], r9
       mov      dword ptr [rbp-0x2E8], edx
       mov      dword ptr [rsp+0x20], 1
       mov      gword ptr [rsp+0x28], r13
       mov      rdx, gword ptr [r15+0x18]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rbp-0x2F0]
       mov      r9d, dword ptr [r15+0x10]
       mov      r8d, eax
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      gword ptr [rbp-0x348], rax
       mov      rdx, r12
       mov      rcx, 0x7FF9CCF51E08
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG116
       test     rbx, rbx
       setne    r8b
       movzx    r8, r8b
       mov      dword ptr [rsp+0x20], r8d
       lea      r8, [rbp-0x100]
       mov      qword ptr [rsp+0x28], r8
       mov      r8, gword ptr [r14+0x18]
       mov      rcx, rax
       mov      rdx, gword ptr [rbp-0x348]
       mov      r9, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeUnaryBuiltin(Lokad.Lython.Runtime.LythonRuntime+BuiltinCallable,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       jne      G_M000_IG138
 
G_M000_IG116:                ;; offset=0x112C
       lea      rax, bword ptr [r15+0x20]
       mov      bword ptr [rbp-0x388], rax
       lea      r8d, [rdi+0x01]
       mov      dword ptr [rbp-0x2D8], r8d
       cmp      r8d, dword ptr [rax+0x40]
       jl       SHORT G_M000_IG118
 
G_M000_IG117:                ;; offset=0x1148
       jmp      SHORT G_M000_IG119
 
G_M000_IG118:                ;; offset=0x114A
       mov      rcx, rax
       mov      edx, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp-0x388]
 
G_M000_IG119:                ;; offset=0x115D
       mov      rcx, gword ptr [rax]
       cmp      edi, dword ptr [rcx+0x08]
       jae      G_M000_IG360
       mov      edx, edi
       shl      rdx, 4
       lea      r10, bword ptr [rcx+rdx+0x10]
       mov      rcx, r10
       mov      bword ptr [rbp-0x398], rcx
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      r12, bword ptr [rbp-0x398]
       mov      qword ptr [r12+0x08], rcx
       mov      r12, bword ptr [rbp-0x388]
       mov      ecx, dword ptr [rbp-0x2D8]
       mov      dword ptr [r12+0x40], ecx
       lea      r12, bword ptr [r15+0x20]
       lea      eax, [rdi+0x02]
       mov      dword ptr [rbp-0x2DC], eax
       cmp      eax, dword ptr [r12+0x40]
       jl       SHORT G_M000_IG121
 
G_M000_IG120:                ;; offset=0x11BA
       jmp      SHORT G_M000_IG122
 
G_M000_IG121:                ;; offset=0x11BC
       mov      rcx, r12
       mov      edx, eax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG122:                ;; offset=0x11C7
       mov      rcx, gword ptr [r12]
       lea      edx, [rdi+0x01]
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG360
       lea      edx, [rdi+0x01]
       shl      rdx, 4
       lea      r8, bword ptr [rcx+rdx+0x10]
       mov      rcx, r8
       mov      bword ptr [rbp-0x3A0], rcx
       mov      rdx, gword ptr [rbp-0x348]
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      rax, bword ptr [rbp-0x3A0]
       mov      qword ptr [rax+0x08], rcx
       mov      ecx, dword ptr [rbp-0x2DC]
       mov      dword ptr [r12+0x40], ecx
 
G_M000_IG123:                ;; offset=0x1211
       mov      r13, gword ptr [rbp+0x18]
       lea      rcx, bword ptr [r15+0x20]
       cmp      byte  ptr [r14], r14b
       mov      rcx, gword ptr [rcx]
       cmp      byte  ptr [r14+0x30], 0
       setne    al
       movzx    rax, al
       add      eax, edi
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG360
       shl      rax, 4
       lea      rcx, bword ptr [rcx+rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9CCFC77C8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r12, rax
       mov      dword ptr [rsp+0x20], edi
       mov      gword ptr [rsp+0x28], r12
       lea      rcx, [rbp-0xA0]
       mov      qword ptr [rsp+0x30], rcx
       mov      rcx, r15
       mov      rdx, r13
       mov      r8, rbx
       mov      r9, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       jne      G_M000_IG133
       test     rbx, rbx
       je       G_M000_IG132
       movzx    rcx, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], ecx
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x28], rax
       mov      rcx, rbx
       mov      rdx, r14
       mov      r8d, edi
       mov      r9, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBeginExecutableCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG128
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG125
       mov      gword ptr [rsp+0x20], r12
       mov      dword ptr [rsp+0x28], 1
       lea      rdx, [rbp-0x1D8]
       mov      rcx, rbx
       mov      r8, r14
       mov      r9d, edi
 
G_M000_IG124:                ;; offset=0x12E0
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x1E8]
       lea      rdx, [rbp-0x1D8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r12, rsi
       mov      rdx, gword ptr [rbp-0x1E8]
       mov      rcx, r12
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x1E0]
       mov      qword ptr [r12+0x08], rdx
       mov      r14, gword ptr [rsi]
       test     r14, r14
       je       G_M000_IG58
       jmp      G_M000_IG345
 
G_M000_IG125:                ;; offset=0x1329
       mov      gword ptr [rsp+0x20], r12
       xor      edx, edx
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp-0xB8]
       mov      rcx, rbx
       mov      r8, r14
       mov      r9d, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       mov      rdx, gword ptr [rbp-0xB8]
       mov      rdi, rdx
       movsx    rdx, word  ptr [rbp-0xB0]
       mov      r14d, edx
       test     rdi, rdi
       je       G_M000_IG361
 
G_M000_IG126:                ;; offset=0x1368
       mov      rdx, rdi
       mov      rcx, 0x7FF9CCD0F848
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      G_M000_IG343
 
G_M000_IG127:                ;; offset=0x1383
       mov      rcx, rdi
       mov      edx, r14d
       mov      r11, 0x7FF9CC911F00
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG361
 
G_M000_IG128:                ;; offset=0x139B
       mov      rax, bword ptr [rbp+0x40]
       mov      r12, gword ptr [rax]
       test     r12, r12
       jne      G_M000_IG336
 
G_M000_IG129:                ;; offset=0x13AB
       mov      rax, bword ptr [rbp+0x40]
       mov      rdi, gword ptr [rax]
       test     rdi, rdi
       jne      G_M000_IG339
 
G_M000_IG130:                ;; offset=0x13BB
       mov      r12, gword ptr [rax+0x08]
 
G_M000_IG131:                ;; offset=0x13BF
       cmp      r12, rbx
       jne      G_M000_IG136
       xor      ecx, ecx
       mov      rax, bword ptr [rbp+0x40]
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      qword ptr [rax+0x10], rcx
       mov      rdi, r13
       mov      r14, r15
       jmp      G_M000_IG219
 
G_M000_IG132:                ;; offset=0x13E4
       mov      gword ptr [rsp+0x20], r12
       lea      rcx, [rbp-0x108]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, r15
       mov      rdx, r13
       mov      r8, r14
       mov      r9d, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDeferredChild(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       G_M000_IG151
       cmp      gword ptr [rbp-0x108], 0
       je       G_M000_IG361
       mov      rdx, gword ptr [rbp-0x108]
       xor      rcx, rcx
       mov      rax, bword ptr [rbp+0x40]
       mov      gword ptr [rax], rcx
       lea      rcx, bword ptr [rax+0x08]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp+0x40]
       mov      word  ptr [rax+0x10], 0
       mov      byte  ptr [rax+0x12], 1
       jmp      SHORT G_M000_IG136
 
G_M000_IG133:                ;; offset=0x1446
       cmp      gword ptr [rbp-0xA0], 0
       je       G_M000_IG361
       mov      rdx, gword ptr [rbp-0xA0]
       mov      rcx, 0x7FF9CCD56808
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       test     rdi, rdi
       jne      SHORT G_M000_IG137
       mov      rdx, gword ptr [rbp-0xA0]
       mov      rax, rdx
       test     rax, rax
       je       SHORT G_M000_IG135
 
G_M000_IG134:                ;; offset=0x1481
       mov      rcx, 0x7FF9CCF26E38
       cmp      qword ptr [rax], rcx
       jne      G_M000_IG335
 
G_M000_IG135:                ;; offset=0x1494
       xor      rcx, rcx
       mov      r12, bword ptr [rbp+0x40]
       mov      gword ptr [r12], rcx
       lea      rcx, bword ptr [r12+0x08]
       mov      rdx, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      word  ptr [r12+0x10], 0
       mov      byte  ptr [r12+0x12], 1
 
G_M000_IG136:                ;; offset=0x14B9
       mov      rdx, gword ptr [r14+0x18]
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xA4], 3
       jmp      G_M000_IG369
 
G_M000_IG137:                ;; offset=0x14D5
       jmp      G_M000_IG368
 
G_M000_IG138:                ;; offset=0x14DA
       mov      rdx, gword ptr [rbp-0x100]
       mov      rcx, 0x7FF9CCD56808
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       test     rdi, rdi
       jne      SHORT G_M000_IG141
 
G_M000_IG139:                ;; offset=0x14F8
       vmovdqu  xmm0, xmmword ptr [rbp-0x100]
       vmovdqu  xmmword ptr [rbp-0x300], xmm0
 
G_M000_IG140:                ;; offset=0x1508
       lea      r9, [rbp-0x300]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x340]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG361
 
G_M000_IG141:                ;; offset=0x1527
       jmp      G_M000_IG368
 
G_M000_IG142:                ;; offset=0x152C
       vmovdqu  xmm0, xmmword ptr [rbp-0xF0]
       vmovdqu  xmmword ptr [rbp-0x300], xmm0
 
G_M000_IG143:                ;; offset=0x153C
       lea      r9, [rbp-0x300]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x340]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG361
 
G_M000_IG144:                ;; offset=0x155B
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteBorrowedDictionaryGet(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG361
 
G_M000_IG145:                ;; offset=0x157B
       mov      r13, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       mov      rdi, gword ptr [r15]
       mov      r14, gword ptr [r15+0x08]
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x26C], eax
       mov      rcx, bword ptr [rbp-0x340]
       mov      r8, gword ptr [rcx]
       mov      gword ptr [rbp-0x350], r8
       mov      rcx, r14
       mov      edx, eax
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadLocalValue(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int):System.Object]
       mov      r14, rax
       test     r14, r14
       jne      SHORT G_M000_IG146
       mov      rcx, rdi
       mov      edx, dword ptr [rbp-0x26C]
       mov      r8, gword ptr [rbp-0x350]
       mov      r9, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r14, rax
 
G_M000_IG146:                ;; offset=0x15DD
       mov      r9, bword ptr [rbp-0x340]
       mov      edi, dword ptr [r9+0x18]
       test     edi, edi
       jl       G_M000_IG46
       lea      rax, bword ptr [r15+0x20]
       mov      bword ptr [rbp-0x358], rax
       mov      rcx, bword ptr [rbp-0x340]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       G_M000_IG47
 
G_M000_IG147:                ;; offset=0x160E
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       G_M000_IG47
 
G_M000_IG148:                ;; offset=0x1622
       mov      r8d, edi
       mov      dword ptr [rbp-0x294], r8d
       jmp      G_M000_IG48
 
G_M000_IG149:                ;; offset=0x1631
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteCasedSplitMember(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG361
 
G_M000_IG150:                ;; offset=0x1651
       mov      r15, bword ptr [rbp+0x10]
       mov      rdi, gword ptr [rbp+0x18]
       mov      rcx, r15
       mov      rdx, rdi
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryLoadDirectCallReceiver(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG361
       test     rbx, rbx
       jne      G_M000_IG289
 
G_M000_IG151:                ;; offset=0x1680
       mov      r15, bword ptr [rbp+0x10]
       mov      r13, gword ptr [rbp+0x18]
       mov      dword ptr [rbp-0xA4], 6
       jmp      G_M000_IG369
 
G_M000_IG152:                ;; offset=0x1697
       cmp      dword ptr [rbp-0x2E0], 0
       je       G_M000_IG145
       mov      rcx, bword ptr [rbp+0x10]
       mov      edx, dword ptr [rcx+0x60]
       add      rcx, 32
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:CanRetireWithoutCleanup(int):bool:this]
       test     eax, eax
       je       G_M000_IG145
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx]
       mov      rdx, gword ptr [rcx+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG153
       lea      r8, bword ptr [rdx+0x10]
       mov      edx, dword ptr [rdx+0x08]
       jmp      SHORT G_M000_IG154
 
G_M000_IG153:                ;; offset=0x16D6
       xor      r8, r8
       xor      edx, edx
 
G_M000_IG154:                ;; offset=0x16DB
       mov      bword ptr [rbp-0x2F0], r8
       mov      dword ptr [rbp-0x2E8], edx
       mov      r10d, dword ptr [rbp-0x2E0]
       mov      dword ptr [rsp+0x20], r10d
       mov      rdx, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x28], rdx
       lea      r8, [rbp-0x58]
       mov      qword ptr [rsp+0x30], r8
       lea      rdx, [rbp-0x2F0]
       mov      r8d, dword ptr [rcx+0x10]
       mov      r9d, dword ptr [rcx+0x60]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:TryPrepareIntegerTuple(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG145
       mov      rcx, bword ptr [rbp+0x10]
       mov      r10d, dword ptr [rbp-0x2E0]
       add      dword ptr [rcx+0x60], r10d
       mov      edx, dword ptr [rbp-0x58]
       mov      dword ptr [rcx+0x10], edx
       jmp      G_M000_IG363
 
G_M000_IG155:                ;; offset=0x1740
       test     rbx, rbx
       je       SHORT G_M000_IG158
       cmp      byte  ptr [rbx+0x108], 0
       jne      SHORT G_M000_IG158
       cmp      gword ptr [rbx+0x88], 0
       jne      SHORT G_M000_IG158
       mov      rcx, bword ptr [rbp+0x10]
       cmp      gword ptr [rcx+0x40], 0
       jne      SHORT G_M000_IG158
       mov      rax, gword ptr [rcx]
       mov      rdx, gword ptr [rcx+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG156
       lea      r9, bword ptr [rdx+0x10]
       mov      edx, dword ptr [rdx+0x08]
       jmp      SHORT G_M000_IG157
 
G_M000_IG156:                ;; offset=0x1778
       xor      r9, r9
       xor      edx, edx
 
G_M000_IG157:                ;; offset=0x177D
       mov      bword ptr [rbp-0x2F0], r9
       mov      dword ptr [rbp-0x2E8], edx
       mov      rdx, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rdx
       lea      r9, [rbp-0x50]
       mov      qword ptr [rsp+0x28], r9
       lea      rdx, [rbp-0x2F0]
       mov      r9d, dword ptr [rcx+0x60]
       lea      r8, bword ptr [rcx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateIntegerCallUpdate(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG167
 
G_M000_IG158:                ;; offset=0x17BC
       mov      r9, bword ptr [rbp-0x340]
       mov      r9d, dword ptr [r9+0x18]
       test     r9d, r9d
       jge      SHORT G_M000_IG159
       mov      edx, r9d
       not      edx
       jmp      SHORT G_M000_IG160
 
G_M000_IG159:                ;; offset=0x17D3
       mov      edx, r9d
 
G_M000_IG160:                ;; offset=0x17D6
       mov      r8, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [r8+0x1C]
       cmp      r8d, 51
       ja       SHORT G_M000_IG164
 
G_M000_IG161:                ;; offset=0x17E7
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, r8
       jb       SHORT G_M000_IG164
 
G_M000_IG162:                ;; offset=0x17F7
       test     r9d, r9d
       jge      SHORT G_M000_IG163
       not      r9d
 
G_M000_IG163:                ;; offset=0x17FF
       jmp      SHORT G_M000_IG165
 
G_M000_IG164:                ;; offset=0x1801
       mov      r9, bword ptr [rbp-0x340]
       mov      r9d, dword ptr [r9+0x14]
 
G_M000_IG165:                ;; offset=0x180C
       cmp      edx, r9d
       jne      G_M000_IG145
 
G_M000_IG166:                ;; offset=0x1815
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdi, gword ptr [rcx+0x08]
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG360
       mov      ecx, eax
       shl      rcx, 4
       cmp      gword ptr [rdi+rcx+0x10], 0
       jne      G_M000_IG361
       jmp      G_M000_IG296
 
G_M000_IG167:                ;; offset=0x184A
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9d, dword ptr [rcx+0x10]
       cmp      r9d, edi
       jae      G_M000_IG360
       shl      r9, 5
       mov      rax, gword ptr [rbp-0x338]
       lea      r8, bword ptr [rax+r9+0x10]
       mov      r14, gword ptr [rbp-0x50]
       mov      rdi, qword ptr [rbp-0x48]
       mov      r15d, dword ptr [r8+0x18]
       test     r15d, r15d
       jge      SHORT G_M000_IG168
       mov      gword ptr [rbp-0x300], r14
       mov      qword ptr [rbp-0x2F8], rdi
       lea      r9, [rbp-0x300]
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG361
 
G_M000_IG168:                ;; offset=0x189F
       lea      r13, bword ptr [rcx+0x20]
       mov      edx, dword ptr [r8+0x1C]
       cmp      edx, 51
       ja       SHORT G_M000_IG171
 
G_M000_IG169:                ;; offset=0x18AC
       mov      r9, 0x7FFFFFFFFF9FF
       bt       r9, rdx
       jb       SHORT G_M000_IG171
 
G_M000_IG170:                ;; offset=0x18BC
       mov      r12d, r15d
       jmp      SHORT G_M000_IG172
 
G_M000_IG171:                ;; offset=0x18C1
       mov      r12d, dword ptr [r8+0x14]
 
G_M000_IG172:                ;; offset=0x18C5
       cmp      r15d, dword ptr [r13+0x40]
       jge      SHORT G_M000_IG173
       mov      rcx, r13
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG173:                ;; offset=0x18D7
       mov      rdx, gword ptr [r13]
       cmp      r12d, dword ptr [rdx+0x08]
       jae      G_M000_IG360
       mov      r8d, r12d
       shl      r8, 4
       lea      r12, bword ptr [rdx+r8+0x10]
       mov      rcx, r12
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r12+0x08], rdi
       mov      dword ptr [r13+0x40], r15d
       jmp      G_M000_IG361
 
G_M000_IG174:                ;; offset=0x190A
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x20]
       mov      r8, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [r8+0x10]
       mov      rax, bword ptr [rbp-0x340]
       mov      eax, dword ptr [rax+0x08]
       test     rdx, rdx
       je       SHORT G_M000_IG175
       mov      r10d, r8d
       mov      r9d, eax
       add      r10, r9
       mov      r9d, dword ptr [rdx+0x08]
       cmp      r10, r9
       ja       G_M000_IG309
       shl      r8, 4
       lea      rdx, bword ptr [rdx+r8+0x10]
       jmp      SHORT G_M000_IG176
 
G_M000_IG175:                ;; offset=0x194D
       or       r8d, eax
       jne      G_M000_IG309
       xor      rdx, rdx
       xor      eax, eax
 
G_M000_IG176:                ;; offset=0x195A
       mov      bword ptr [rbp-0x2F0], rdx
       mov      dword ptr [rbp-0x2E8], eax
       lea      rcx, [rbp-0x2F0]
       mov      rdx, gword ptr [rbp+0x18]
       mov      rdx, gword ptr [rdx+0xA0]
       mov      r8, bword ptr [rbp-0x340]
       mov      r8, gword ptr [r8]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReverseAssignmentValues(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.ExecutionState,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG361
 
G_M000_IG177:                ;; offset=0x198E
       mov      rcx, bword ptr [rbp+0x10]
       lea      r8, bword ptr [rcx+0x20]
       cmp      r14d, 51
       ja       SHORT G_M000_IG181
 
G_M000_IG178:                ;; offset=0x199C
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, r14
       jb       SHORT G_M000_IG181
 
G_M000_IG179:                ;; offset=0x19AC
       mov      rdx, bword ptr [rbp-0x340]
       mov      edi, dword ptr [rdx+0x18]
       test     edi, edi
       jge      SHORT G_M000_IG180
       not      edi
 
G_M000_IG180:                ;; offset=0x19BC
       jmp      SHORT G_M000_IG182
 
G_M000_IG181:                ;; offset=0x19BE
       mov      rdx, bword ptr [rbp-0x340]
       mov      edi, dword ptr [rdx+0x14]
 
G_M000_IG182:                ;; offset=0x19C8
       mov      rdx, bword ptr [rbp-0x340]
       mov      edx, dword ptr [rdx+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG183
       mov      r9d, edx
       not      r9d
       jmp      SHORT G_M000_IG184
 
G_M000_IG183:                ;; offset=0x19DE
       mov      r9d, edx
 
G_M000_IG184:                ;; offset=0x19E1
       lea      rdx, [rbp-0x70]
       mov      rcx, r8
       mov      r8d, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       je       SHORT G_M000_IG185
       lea      rdx, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
       jmp      SHORT G_M000_IG186
 
G_M000_IG185:                ;; offset=0x1A08
       xor      rdx, rdx
       xor      r8d, r8d
 
G_M000_IG186:                ;; offset=0x1A0D
       mov      r9, rbx
       test     r9, r9
       jne      SHORT G_M000_IG187
       mov      rdi, gword ptr [rbp+0x18]
       mov      r9, rdi
 
G_M000_IG187:                ;; offset=0x1A1C
       mov      rdi, gword ptr [rbp+0x18]
       mov      r9, gword ptr [r9+0xA0]
       mov      rax, bword ptr [rbp-0x340]
       mov      eax, dword ptr [rax+0x10]
       cmp      eax, r8d
       jae      G_M000_IG360
       mov      r8d, eax
       shl      r8, 4
       add      r8, rdx
 
G_M000_IG188:                ;; offset=0x1A44
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0x300], xmm0
 
G_M000_IG189:                ;; offset=0x1A51
       mov      rcx, r8
       lea      r8, [rbp-0x300]
       mov      rdx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(byref,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG361
 
G_M000_IG190:                ;; offset=0x1A6D
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx]
       mov      r14, gword ptr [rax+0x30]
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [r14+0x08]
       jae      G_M000_IG360
       mov      edx, eax
       mov      rdx, gword ptr [r14+8*rdx+0x10]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG192
 
G_M000_IG191:                ;; offset=0x1A9E
       mov      rax, 0x7FF9CCE1ABA8
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG308
 
G_M000_IG192:                ;; offset=0x1AB1
       mov      r14, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [r14+0x20]
       mov      r8, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [r8+0x1C]
       mov      r9d, r8d
       cmp      r9d, 51
       ja       SHORT G_M000_IG196
 
G_M000_IG193:                ;; offset=0x1ACD
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, r9
       jb       SHORT G_M000_IG196
 
G_M000_IG194:                ;; offset=0x1ADD
       mov      r9, bword ptr [rbp-0x340]
       mov      r9d, dword ptr [r9+0x18]
       test     r9d, r9d
       jge      SHORT G_M000_IG195
       not      r9d
 
G_M000_IG195:                ;; offset=0x1AF0
       jmp      SHORT G_M000_IG197
 
G_M000_IG196:                ;; offset=0x1AF2
       mov      r9, bword ptr [rbp-0x340]
       mov      r9d, dword ptr [r9+0x14]
 
G_M000_IG197:                ;; offset=0x1AFD
       mov      rax, bword ptr [rbp-0x340]
       mov      eax, dword ptr [rax+0x18]
       test     eax, eax
       jge      SHORT G_M000_IG198
       mov      r10d, eax
       not      r10d
       jmp      SHORT G_M000_IG199
 
G_M000_IG198:                ;; offset=0x1B13
       mov      r10d, eax
 
G_M000_IG199:                ;; offset=0x1B16
       cmp      r8d, 51
       ja       SHORT G_M000_IG204
 
G_M000_IG200:                ;; offset=0x1B1C
       mov      r11, 0x7FFFFFFFFF9FF
       bt       r11, r8
       jb       SHORT G_M000_IG204
 
G_M000_IG201:                ;; offset=0x1B2C
       test     eax, eax
       jge      SHORT G_M000_IG202
       mov      r8d, eax
       not      r8d
       jmp      SHORT G_M000_IG203
 
G_M000_IG202:                ;; offset=0x1B38
       mov      r8d, eax
 
G_M000_IG203:                ;; offset=0x1B3B
       jmp      SHORT G_M000_IG205
 
G_M000_IG204:                ;; offset=0x1B3D
       mov      r8, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [r8+0x14]
 
G_M000_IG205:                ;; offset=0x1B48
       sub      r10d, r8d
       test     rdx, rdx
       je       SHORT G_M000_IG206
       mov      r8d, r9d
       mov      eax, r10d
       add      r8, rax
       mov      eax, dword ptr [rdx+0x08]
       cmp      r8, rax
       ja       G_M000_IG309
       mov      r9d, r9d
       shl      r9, 4
       lea      rdx, bword ptr [rdx+r9+0x10]
       jmp      SHORT G_M000_IG207
 
G_M000_IG206:                ;; offset=0x1B73
       or       r9d, r10d
       jne      G_M000_IG309
       xor      rdx, rdx
       xor      r10d, r10d
 
G_M000_IG207:                ;; offset=0x1B81
       mov      r8, bword ptr [rbp-0x340]
       cmp      dword ptr [r8+0x0C], 0
       setne    r8b
       movzx    r8, r8b
       mov      r9, rbx
       test     r9, r9
       jne      SHORT G_M000_IG208
       mov      rdi, gword ptr [rbp+0x18]
       mov      r9, rdi
 
G_M000_IG208:                ;; offset=0x1BA4
       mov      rdi, gword ptr [rbp+0x18]
       mov      bword ptr [rbp-0x2F0], rdx
       mov      dword ptr [rbp-0x2E8], r10d
       mov      rdx, bword ptr [rbp-0x340]
       mov      rdx, gword ptr [rdx]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0x2F0]
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       lea      rdx, bword ptr [r14+0x20]
       mov      rcx, bword ptr [rbp-0x340]
       mov      ecx, dword ptr [rcx+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG209
       not      ecx
 
G_M000_IG209:                ;; offset=0x1BE6
       mov      dword ptr [rdx+0x40], ecx
       jmp      G_M000_IG361
 
G_M000_IG210:                ;; offset=0x1BEE
       mov      rdi, gword ptr [rbp+0x18]
       test     rbx, rbx
       je       G_M000_IG214
       mov      r14, bword ptr [rbp+0x10]
       mov      r15d, dword ptr [r14+0x60]
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      r15d, eax
       jne      G_M000_IG214
       mov      rcx, gword ptr [r14+0x20]
       mov      rax, bword ptr [rbp-0x340]
       mov      eax, dword ptr [rax+0x10]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG360
       shl      rax, 4
       mov      r15, gword ptr [rcx+rax+0x10]
       test     r15, r15
       je       G_M000_IG214
 
G_M000_IG211:                ;; offset=0x1C42
       mov      rcx, 0x7FF9CCFC7330
       cmp      qword ptr [r15], rcx
       jne      G_M000_IG214
 
G_M000_IG212:                ;; offset=0x1C55
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:get_NativeCsvSource():Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:this]
       test     rax, rax
       je       G_M000_IG214
       cmp      gword ptr [rax+0x20], 0
       je       G_M000_IG214
       mov      rdx, bword ptr [rbp-0x340]
       mov      bword ptr [rsp+0x20], rdx
       movzx    rdx, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp-0x168]
       mov      rcx, rbx
       mov      r8, rax
       mov      r9, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AdvanceCsvUnpack(Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource,Lokad.Lython.Runtime.PyIteration+Cursor,byref,bool):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r15, rsi
       mov      rdx, gword ptr [rbp-0x168]
       mov      rcx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x160]
       mov      qword ptr [r15+0x08], rdx
       mov      r15, gword ptr [rsi]
       test     r15, r15
       je       G_M000_IG231
       jmp      G_M000_IG328
 
G_M000_IG213:                ;; offset=0x1CCA
       mov      rdi, gword ptr [rbp+0x18]
       mov      r14, bword ptr [rbp+0x10]
       mov      rcx, r14
       mov      rdx, rdi
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG219
 
G_M000_IG214:                ;; offset=0x1CF0
       mov      r14, bword ptr [rbp+0x10]
       mov      rdi, gword ptr [rbp+0x18]
       mov      rdx, bword ptr [rbp-0x340]
       mov      edx, dword ptr [rdx+0x10]
       lea      rcx, bword ptr [r14+0x20]
       lea      r8, [rbp-0x88]
       lea      r9, [rbp-0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryAdvanceNativeIteration(int,byref,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG218
       test     rbx, rbx
       je       G_M000_IG151
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG217
       mov      r8, bword ptr [rbp-0x340]
 
G_M000_IG215:                ;; offset=0x1D38
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x320], ymm0
 
G_M000_IG216:                ;; offset=0x1D45
       lea      r8, [rbp-0x320]
       lea      rdx, [rbp-0x1F8]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNextAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r15, rsi
       mov      rdx, gword ptr [rbp-0x1F8]
       mov      rcx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x1F0]
       mov      qword ptr [r15+0x08], rdx
       mov      r15, gword ptr [rsi]
       test     r15, r15
       je       G_M000_IG231
       jmp      G_M000_IG331
 
G_M000_IG217:                ;; offset=0x1D8A
       mov      rcx, rbx
       mov      rdx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNext(byref):bool:this]
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG361
 
G_M000_IG218:                ;; offset=0x1DA2
       cmp      byte  ptr [rbp-0x88], 0
       jne      SHORT G_M000_IG220
       mov      rdx, bword ptr [rbp-0x340]
       mov      edx, dword ptr [rdx+0x10]
       lea      rcx, bword ptr [r14+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      dword ptr [r14+0x10], eax
 
G_M000_IG219:                ;; offset=0x1DD0
       mov      dword ptr [rbp-0x3C], 1
       jmp      G_M000_IG361
 
G_M000_IG220:                ;; offset=0x1DDC
       vmovdqu  xmm0, xmmword ptr [rbp-0x98]
       vmovdqu  xmmword ptr [rbp-0x300], xmm0
 
G_M000_IG221:                ;; offset=0x1DEC
       lea      r9, [rbp-0x300]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x340]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG361
 
G_M000_IG222:                ;; offset=0x1E0B
       mov      r14, bword ptr [rbp+0x10]
       lea      r15, bword ptr [r14+0x20]
       mov      rdx, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [rdx+0x10]
       mov      rcx, gword ptr [r14]
       mov      rdx, gword ptr [r14+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG223
       lea      r9, bword ptr [rdx+0x10]
       mov      edx, dword ptr [rdx+0x08]
       jmp      SHORT G_M000_IG224
 
G_M000_IG223:                ;; offset=0x1E33
       xor      r9, r9
       xor      edx, edx
 
G_M000_IG224:                ;; offset=0x1E38
       mov      bword ptr [rbp-0x2F0], r9
       mov      dword ptr [rbp-0x2E8], edx
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdi, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x28], rdi
       mov      rdx, gword ptr [r14+0x18]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rbp-0x2F0]
       mov      r9d, dword ptr [r14+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      r13, rax
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      r8d, eax
       mov      rcx, bword ptr [rbp-0x340]
       mov      r9d, dword ptr [rcx+0x18]
       test     r9d, r9d
       jge      SHORT G_M000_IG225
       not      r9d
 
G_M000_IG225:                ;; offset=0x1E94
       mov      rcx, bword ptr [rbp-0x340]
       mov      rcx, gword ptr [rcx]
       mov      gword ptr [rsp+0x20], rcx
       mov      rcx, r15
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryPrepareNativeIteration(System.Object,int,int,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      G_M000_IG361
       test     rbx, rbx
       je       G_M000_IG151
       cmp      byte  ptr [rbp+0x28], 0
       je       G_M000_IG93
       mov      r8, bword ptr [rbp-0x340]
 
G_M000_IG226:                ;; offset=0x1ED1
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x320], ymm0
 
G_M000_IG227:                ;; offset=0x1EDE
       lea      r8, [rbp-0x320]
       lea      rdx, [rbp-0x208]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteGetIteratorAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x218]
       lea      rdx, [rbp-0x208]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r15, rsi
       mov      rdx, gword ptr [rbp-0x218]
       mov      rcx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x210]
       mov      qword ptr [r15+0x08], rdx
       mov      r15, gword ptr [rsi]
       test     r15, r15
       je       G_M000_IG58
       jmp      G_M000_IG348
 
G_M000_IG228:                ;; offset=0x1F37
       mov      r14, bword ptr [rbp+0x10]
       test     rbx, rbx
       je       G_M000_IG151
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG233
       mov      r8, bword ptr [rbp-0x340]
 
G_M000_IG229:                ;; offset=0x1F51
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x320], ymm0
 
G_M000_IG230:                ;; offset=0x1F5E
       lea      r8, [rbp-0x320]
       lea      rdx, [rbp-0x228]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteContextManagerAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r15, rsi
       mov      rdx, gword ptr [rbp-0x228]
       mov      rcx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x220]
       mov      qword ptr [r15+0x08], rdx
       mov      r15, gword ptr [rsi]
       test     r15, r15
       jne      G_M000_IG325
 
G_M000_IG231:                ;; offset=0x1F9E
       mov      r14, bword ptr [rbp+0x10]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG361
 
G_M000_IG232:                ;; offset=0x1FB3
       mov      r14, bword ptr [rbp+0x10]
       test     rbx, rbx
       je       G_M000_IG151
 
G_M000_IG233:                ;; offset=0x1FC0
       mov      rcx, rbx
       mov      rdx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteStructure(byref):bool:this]
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG361
 
G_M000_IG234:                ;; offset=0x1FD8
       mov      r14, bword ptr [rbp+0x10]
       test     rbx, rbx
       je       SHORT G_M000_IG235
       mov      rcx, rbx
       mov      rdx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryStageUnpackedFrameReturn(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG266
 
G_M000_IG235:                ;; offset=0x1FF9
       cmp      dword ptr [rbp-0x2E0], 0
       je       SHORT G_M000_IG236
       mov      rcx, r14
       mov      rdx, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [rbp-0x2E0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CanForwardFixedReturn(byref,byref,int):bool]
       test     eax, eax
       jne      SHORT G_M000_IG237
 
G_M000_IG236:                ;; offset=0x201D
       lea      r15, bword ptr [r14+0x20]
       mov      rcx, bword ptr [rbp-0x340]
       mov      r13d, dword ptr [rcx+0x10]
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      r8d, eax
       mov      rdi, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rdi
       mov      edx, r13d
       mov      rcx, r15
       mov      r9, bword ptr [rbp-0x340]
       mov      r9, gword ptr [r9]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTupleFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyTuple]
       mov      gword ptr [rbp-0x300], rax
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2F8], r9
       lea      r9, [rbp-0x300]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x340]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG361
 
G_M000_IG237:                ;; offset=0x208B
       mov      rdi, gword ptr [rbp+0x18]
       mov      r9, bword ptr [rbp-0x390]
       mov      bword ptr [rbp-0x2F0], r9
       mov      r8d, dword ptr [rbp-0x2E0]
       mov      dword ptr [rbp-0x2E8], r8d
       lea      r9, [rbp-0x2F0]
       mov      rdx, rdi
       mov      r8, bword ptr [rbp-0x340]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CopyFixedReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       mov      dword ptr [rbp-0xA4], 2
       jmp      G_M000_IG369
 
G_M000_IG238:                ;; offset=0x20D4
       mov      r14, bword ptr [rbp+0x10]
       mov      r9, rbx
       test     r9, r9
       jne      SHORT G_M000_IG239
       mov      rdi, gword ptr [rbp+0x18]
       mov      r9, rdi
 
G_M000_IG239:                ;; offset=0x20E7
       mov      rcx, r14
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteFormattedInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      G_M000_IG361
       test     rbx, rbx
       je       G_M000_IG151
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG242
       mov      r8, bword ptr [rbp-0x340]
 
G_M000_IG240:                ;; offset=0x2118
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x320], ymm0
 
G_M000_IG241:                ;; offset=0x2125
       lea      r8, [rbp-0x320]
       lea      rdx, [rbp-0x178]
       mov      rcx, rbx
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x188]
       lea      rdx, [rbp-0x178]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r15, rsi
       mov      rdx, gword ptr [rbp-0x188]
       mov      rcx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x180]
       mov      qword ptr [r15+0x08], rdx
       mov      r15, gword ptr [rsi]
       test     r15, r15
       je       G_M000_IG58
       jmp      G_M000_IG305
 
G_M000_IG242:                ;; offset=0x2184
       mov      r8, bword ptr [rbp-0x340]
 
G_M000_IG243:                ;; offset=0x218B
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x320], ymm0
 
G_M000_IG244:                ;; offset=0x2198
       lea      r8, [rbp-0x320]
       lea      rdx, [rbp-0xB8]
       mov      rcx, rbx
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       mov      r15, gword ptr [rbp-0xB8]
       movsx    r13, word  ptr [rbp-0xB0]
       test     r15, r15
       je       G_M000_IG361
 
G_M000_IG245:                ;; offset=0x21CA
       mov      rdx, r15
       mov      rcx, 0x7FF9CCD0F848
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      G_M000_IG303
 
G_M000_IG246:                ;; offset=0x21E5
       mov      rcx, r15
       mov      edx, r13d
       mov      r11, 0x7FF9CC911E98
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG361
 
G_M000_IG247:                ;; offset=0x21FD
       test     rbx, rbx
       je       G_M000_IG151
       cmp      byte  ptr [rbp+0x28], 0
       jne      G_M000_IG261
       cmp      gword ptr [rbx+0x68], 0
       jne      G_M000_IG253
       mov      r15, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [r15+0x20]
       mov      rdx, bword ptr [rbp-0x340]
       mov      edx, dword ptr [rdx+0x10]
       mov      r8d, r14d
       cmp      r8d, 51
       ja       SHORT G_M000_IG251
 
G_M000_IG248:                ;; offset=0x2236
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, r8
       jb       SHORT G_M000_IG251
 
G_M000_IG249:                ;; offset=0x2246
       mov      r8, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [r8+0x18]
       test     r8d, r8d
       jge      SHORT G_M000_IG250
       not      r8d
 
G_M000_IG250:                ;; offset=0x2259
       jmp      SHORT G_M000_IG252
 
G_M000_IG251:                ;; offset=0x225B
       mov      r8, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [r8+0x14]
 
G_M000_IG252:                ;; offset=0x2266
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      r14, rax
       mov      rcx, 0x7FF9CC9D2560
       mov      edx, 1
       call     CORINFO_HELP_NEWARR_1_PTR
       mov      r13, rax
       lea      rcx, bword ptr [r13+0x10]
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdx, bword ptr [rbp-0x340]
       mov      rdx, gword ptr [rdx]
       mov      rcx, r13
       mov      r8, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:Iter(System.Object[],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r14, rax
       mov      rcx, 0x7FF9CCFCB390
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       mov      rcx, bword ptr [rbp-0x340]
       mov      r12, gword ptr [rcx]
       lea      rcx, bword ptr [r13+0x08]
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [r13+0x10]
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [r13+0x18]
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, 0x18F4E8012A0
       mov      rdx, gword ptr [rcx]
       lea      rcx, bword ptr [r13+0x20]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [rbx+0x68]
       mov      rdx, r13
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG253:                ;; offset=0x230D
       mov      rcx, gword ptr [rbx+0x68]
       mov      r8, gword ptr [rbx+0x58]
       mov      r9, gword ptr [rbx+0x60]
       cmp      byte  ptr [rcx], cl
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       lea      rdx, [rbp-0x2B8]
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:AdvanceAsync(System.Object,Lokad.Lython.Runtime.LythonRuntimeException,bool):System.Threading.Tasks.ValueTask`1[Lokad.Lython.Runtime.PyIterationResult]:this]
       mov      r14, gword ptr [rbp-0x2B8]
       movsx    r13, word  ptr [rbp-0x2B0]
       test     r14, r14
       je       SHORT G_M000_IG257
       mov      rdx, r14
       mov      rcx, 0x7FF9CCFE8358
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r12, rax
       test     r12, r12
       jne      SHORT G_M000_IG254
       lea      rdx, [rbp-0x2C8]
       mov      rcx, r14
       mov      r8d, r13d
       mov      r11, 0x7FF9CC911EC0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[Lokad.Lython.Runtime.PyIterationResult]:GetResult(short):Lokad.Lython.Runtime.PyIterationResult:this
       jmp      SHORT G_M000_IG258
 
G_M000_IG254:                ;; offset=0x2378
       mov      ecx, dword ptr [r12+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       jne      G_M000_IG318
 
G_M000_IG255:                ;; offset=0x238F
       vmovdqu  xmm0, xmmword ptr [r12+0x38]
       vmovdqu  xmmword ptr [rbp-0x2C8], xmm0
 
G_M000_IG256:                ;; offset=0x239E
       jmp      SHORT G_M000_IG258
 
G_M000_IG257:                ;; offset=0x23A0
       vmovdqu  xmm0, xmmword ptr [rbp-0x2A8]
       vmovdqu  xmmword ptr [rbp-0x2C8], xmm0
 
G_M000_IG258:                ;; offset=0x23B0
       mov      r8, bword ptr [rbp-0x340]
 
G_M000_IG259:                ;; offset=0x23B7
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x320], ymm0
 
G_M000_IG260:                ;; offset=0x23C4
       lea      r8, [rbp-0x320]
       lea      rdx, [rbp-0x2C8]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteDelegatedStep(Lokad.Lython.Runtime.PyIterationResult,Lokad.Lython.Frontend.ExecutableInstruction):this]
       jmp      SHORT G_M000_IG265
 
G_M000_IG261:                ;; offset=0x23DD
       mov      r8, bword ptr [rbp-0x340]
 
G_M000_IG262:                ;; offset=0x23E4
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x320], ymm0
 
G_M000_IG263:                ;; offset=0x23F1
       lea      r8, [rbp-0x320]
       lea      rdx, [rbp-0x198]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteDelegationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r14, rsi
       mov      rdx, gword ptr [rbp-0x198]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x190]
       mov      qword ptr [r14+0x08], rdx
       mov      r14, gword ptr [rsi]
       test     r14, r14
       jne      G_M000_IG315
 
G_M000_IG264:                ;; offset=0x2431
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
 
G_M000_IG265:                ;; offset=0x243A
       cmp      byte  ptr [rbx+0x101], 0
       je       G_M000_IG361
       mov      rdx, gword ptr [rbx+0x70]
       test     rdx, rdx
       je       SHORT G_M000_IG266
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       jne      G_M000_IG363
 
G_M000_IG266:                ;; offset=0x2461
       mov      r15, bword ptr [rbp+0x10]
       mov      dword ptr [rbp-0xA4], 1
       jmp      G_M000_IG369
 
G_M000_IG267:                ;; offset=0x2474
       mov      r15, bword ptr [rbp+0x10]
       lea      r14, bword ptr [r15+0x20]
       mov      rcx, bword ptr [rbp-0x340]
       mov      r13d, dword ptr [rcx+0x10]
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      r8d, eax
       mov      rdi, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rdi
       mov      edx, r13d
       mov      rcx, r14
       mov      r9, bword ptr [rbp-0x340]
       mov      r9, gword ptr [r9]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateListFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x300], rax
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2F8], r9
       lea      r9, [rbp-0x300]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x340]
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG361
 
G_M000_IG268:                ;; offset=0x24E6
       mov      rdi, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r15+0x20]
       mov      rax, bword ptr [rbp-0x340]
       mov      eax, dword ptr [rax+0x10]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG360
       shl      rax, 4
       lea      rcx, bword ptr [rcx+rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9CCFC77C8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       lea      rcx, bword ptr [r15+0x20]
       mov      rdx, bword ptr [rbp-0x340]
       mov      edx, dword ptr [rdx+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG269
       not      edx
 
G_M000_IG269:                ;; offset=0x253B
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       jmp      G_M000_IG361
 
G_M000_IG270:                ;; offset=0x2546
       mov      rdi, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       lea      r13, bword ptr [r15+0x20]
       mov      ecx, r14d
       cmp      ecx, 51
       ja       SHORT G_M000_IG275
 
G_M000_IG271:                ;; offset=0x255A
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jb       SHORT G_M000_IG275
 
G_M000_IG272:                ;; offset=0x256A
       mov      rcx, bword ptr [rbp-0x340]
       mov      edx, dword ptr [rcx+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG273
       mov      r14d, edx
       not      r14d
       jmp      SHORT G_M000_IG274
 
G_M000_IG273:                ;; offset=0x2580
       mov      r14d, edx
 
G_M000_IG274:                ;; offset=0x2583
       jmp      SHORT G_M000_IG276
 
G_M000_IG275:                ;; offset=0x2585
       mov      rdx, bword ptr [rbp-0x340]
       mov      r14d, dword ptr [rdx+0x14]
 
G_M000_IG276:                ;; offset=0x2590
       inc      r14d
       mov      rcx, bword ptr [rbp-0x340]
       mov      edx, dword ptr [rcx+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG277
       mov      r12d, edx
       not      r12d
       jmp      SHORT G_M000_IG278
 
G_M000_IG277:                ;; offset=0x25A9
       mov      r12d, edx
 
G_M000_IG278:                ;; offset=0x25AC
       mov      rcx, gword ptr [r15+0x20]
       mov      rax, bword ptr [rbp-0x340]
       mov      eax, dword ptr [rax+0x10]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG360
       shl      rax, 4
       lea      rcx, bword ptr [rcx+rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9CCFC77C8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x380], rax
       cmp      r12d, dword ptr [r13+0x40]
       jl       SHORT G_M000_IG280
 
G_M000_IG279:                ;; offset=0x25F2
       mov      rax, gword ptr [rbp-0x380]
       jmp      SHORT G_M000_IG281
 
G_M000_IG280:                ;; offset=0x25FB
       mov      rcx, r13
       mov      edx, r12d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, gword ptr [rbp-0x380]
 
G_M000_IG281:                ;; offset=0x260E
       mov      rcx, gword ptr [r13]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG360
       mov      edx, r14d
       shl      rdx, 4
       lea      r14, bword ptr [rcx+rdx+0x10]
       mov      rcx, r14
       mov      rdx, rax
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r14+0x08], rcx
       mov      dword ptr [r13+0x40], r12d
       jmp      G_M000_IG361
 
G_M000_IG282:                ;; offset=0x2642
       mov      rdi, gword ptr [rbp+0x18]
       test     rbx, rbx
       je       G_M000_IG151
       mov      r15, bword ptr [rbp+0x10]
       mov      r14, gword ptr [r15]
       mov      r13, gword ptr [r15+0x08]
       mov      rcx, gword ptr [r15]
       mov      r12, gword ptr [rcx+0x38]
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [r12+0x08]
       jae      G_M000_IG360
       mov      ecx, eax
       mov      r12, gword ptr [r12+8*rcx+0x10]
       lea      rcx, bword ptr [r15+0x20]
       mov      rdx, bword ptr [rbp-0x340]
       mov      edx, dword ptr [rdx+0x10]
       mov      r8, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [r8+0x18]
       test     r8d, r8d
       jge      SHORT G_M000_IG283
       not      r8d
 
G_M000_IG283:                ;; offset=0x26A1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      r9, rax
       mov      gword ptr [rsp+0x20], rbx
       mov      rdx, bword ptr [rbp-0x340]
       mov      rdx, gword ptr [rdx]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, r13
       mov      r8, r12
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:AssignExecutableBoundName(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG361
 
G_M000_IG284:                ;; offset=0x26D2
       mov      rdi, gword ptr [rbp+0x18]
       test     rbx, rbx
       je       G_M000_IG151
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r15]
       mov      r14, gword ptr [rcx+0x38]
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [r14+0x08]
       jae      G_M000_IG360
       mov      ecx, eax
       mov      r14, gword ptr [r14+8*rcx+0x10]
       lea      rcx, bword ptr [r15+0x20]
       mov      rdx, bword ptr [rbp-0x340]
       mov      edx, dword ptr [rdx+0x10]
       mov      r8, bword ptr [rbp-0x340]
       mov      r8d, dword ptr [r8+0x18]
       test     r8d, r8d
       jge      SHORT G_M000_IG285
       not      r8d
 
G_M000_IG285:                ;; offset=0x2729
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      rdx, rax
       mov      r9, bword ptr [rbp-0x340]
       mov      r9, gword ptr [r9]
       mov      rcx, r14
       mov      r8, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreName(System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG361
 
G_M000_IG286:                ;; offset=0x274D
       mov      rdi, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, r15
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryStoreClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG361
       jmp      G_M000_IG151
 
G_M000_IG287:                ;; offset=0x2775
       mov      rdi, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       mov      rcx, r15
       mov      rdx, rdi
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:StoreExecutableLocal(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG361
 
G_M000_IG288:                ;; offset=0x2798
       mov      rdi, gword ptr [rbp+0x18]
       mov      r15, bword ptr [rbp+0x10]
       test     rbx, rbx
       je       G_M000_IG151
       mov      rdx, bword ptr [rbp-0x340]
       mov      rdx, gword ptr [rdx]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:PreloadImplicitSuperArguments(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG361
 
G_M000_IG289:                ;; offset=0x27C1
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG292
       mov      r8, bword ptr [rbp-0x340]
 
G_M000_IG290:                ;; offset=0x27CE
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x320], ymm0
 
G_M000_IG291:                ;; offset=0x27DB
       lea      r8, [rbp-0x320]
       lea      rdx, [rbp-0x238]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteMemberLoadAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r14, rsi
       mov      rdx, gword ptr [rbp-0x238]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x230]
       mov      qword ptr [r14+0x08], rdx
       mov      r14, gword ptr [rsi]
       test     r14, r14
       je       G_M000_IG58
       jmp      G_M000_IG322
 
G_M000_IG292:                ;; offset=0x2820
       mov      rcx, r15
       mov      rdx, rdi
       mov      r8, rbx
       mov      r9, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSynchronousMemberLoad(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG361
 
G_M000_IG293:                ;; offset=0x283B
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x158], ymm0
       vmovdqu  xmmword ptr [rbp-0x140], xmm0
       lea      rcx, [rbp-0x158]
       mov      edx, 27
       mov      r8d, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
 
G_M000_IG294:                ;; offset=0x2867
       vmovdqu  ymm0, ymmword ptr [rbp-0x158]
       vmovdqu  ymmword ptr [rbp-0x130], ymm0
       mov      rcx, qword ptr [rbp-0x138]
       mov      qword ptr [rbp-0x110], rcx
 
G_M000_IG295:                ;; offset=0x2885
       mov      ecx, dword ptr [rbp-0x120]
       cmp      ecx, dword ptr [rbp-0x110]
       jbe      G_M000_IG357
       jmp      G_M000_IG309
 
G_M000_IG296:                ;; offset=0x289C
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx]
       mov      rdi, gword ptr [rax+0x68]
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      edx, eax
       mov      rcx, rdi
       mov      r11, 0x7FF9CC911E70
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rcx, rax
       mov      rdx, bword ptr [rbp-0x340]
       mov      rdx, gword ptr [rdx]
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG297:                ;; offset=0x28E2
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG361
 
G_M000_IG298:                ;; offset=0x28F7
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG361
 
G_M000_IG299:                ;; offset=0x2907
       mov      rdx, rdi
       mov      rcx, 0x7FF9CCFE2F90
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG300
       test     dword ptr [rax+0x34], 0x1600000
       setne    r14b
       movzx    r14, r14b
       jmp      SHORT G_M000_IG301
 
G_M000_IG300:                ;; offset=0x292F
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, rdi
       mov      r11, 0x7FF9CC911E90
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r14b
       movzx    r14, r14b
 
G_M000_IG301:                ;; offset=0x294E
       test     r14d, r14d
       jne      G_M000_IG58
 
G_M000_IG302:                ;; offset=0x2957
       mov      r15, bword ptr [rbp+0x10]
       mov      r13, gword ptr [rbp+0x18]
       mov      rcx, bword ptr [rbp-0x340]
       mov      rdx, gword ptr [rcx]
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xA4], 4
       jmp      G_M000_IG369
 
G_M000_IG303:                ;; offset=0x2981
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG361
 
G_M000_IG304:                ;; offset=0x2996
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG361
 
G_M000_IG305:                ;; offset=0x29A6
       mov      rdx, r15
       mov      rcx, 0x7FF9CCFE2F90
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG306
       test     dword ptr [rax+0x34], 0x1600000
       setne    r13b
       movzx    r13, r13b
       jmp      SHORT G_M000_IG307
 
G_M000_IG306:                ;; offset=0x29CE
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, r15
       mov      r11, 0x7FF9CC911EA0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r13b
       movzx    r13, r13b
 
G_M000_IG307:                ;; offset=0x29ED
       test     r13d, r13d
       jne      G_M000_IG58
       jmp      G_M000_IG302
 
G_M000_IG308:                ;; offset=0x29FB
       mov      rdi, gword ptr [rbp+0x18]
       mov      rcx, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG309:                ;; offset=0x2A08
       mov      r14, bword ptr [rbp+0x10]
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG310:                ;; offset=0x2A13
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG361
 
G_M000_IG311:                ;; offset=0x2A28
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG361
 
G_M000_IG312:                ;; offset=0x2A38
       mov      rdx, rdi
       mov      rcx, 0x7FF9CCFE2F90
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG313
       test     dword ptr [rax+0x34], 0x1600000
       setne    r14b
       movzx    r14, r14b
       jmp      SHORT G_M000_IG314
 
G_M000_IG313:                ;; offset=0x2A60
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, rdi
       mov      r11, 0x7FF9CC911EB0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r14b
       movzx    r14, r14b
 
G_M000_IG314:                ;; offset=0x2A7F
       test     r14d, r14d
       jne      G_M000_IG58
       jmp      G_M000_IG302
 
G_M000_IG315:                ;; offset=0x2A8D
       mov      rdx, r14
       mov      rcx, 0x7FF9CCFE2F90
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG316
       test     dword ptr [rax+0x34], 0x1600000
       setne    r13b
       movzx    r13, r13b
       jmp      SHORT G_M000_IG317
 
G_M000_IG316:                ;; offset=0x2AB5
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, r14
       mov      r11, 0x7FF9CC911EB8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r13b
       movzx    r13, r13b
 
G_M000_IG317:                ;; offset=0x2AD4
       test     r13d, r13d
       jne      G_M000_IG264
       jmp      G_M000_IG302
 
G_M000_IG318:                ;; offset=0x2AE2
       mov      rcx, r12
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG255
 
G_M000_IG319:                ;; offset=0x2AF2
       mov      rdx, rdi
       mov      rcx, 0x7FF9CCFE2F90
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG320
       test     dword ptr [rax+0x34], 0x1600000
       setne    r14b
       movzx    r14, r14b
       jmp      SHORT G_M000_IG321
 
G_M000_IG320:                ;; offset=0x2B1A
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, rdi
       mov      r11, 0x7FF9CC911EC8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r14b
       movzx    r14, r14b
 
G_M000_IG321:                ;; offset=0x2B39
       test     r14d, r14d
       jne      G_M000_IG58
       jmp      G_M000_IG302
 
G_M000_IG322:                ;; offset=0x2B47
       mov      rdx, r14
       mov      rcx, 0x7FF9CCFE2F90
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG323
       test     dword ptr [rax+0x34], 0x1600000
       setne    r13b
       movzx    r13, r13b
       jmp      SHORT G_M000_IG324
 
G_M000_IG323:                ;; offset=0x2B6F
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, r14
       mov      r11, 0x7FF9CC911ED0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r13b
       movzx    r13, r13b
 
G_M000_IG324:                ;; offset=0x2B8E
       test     r13d, r13d
       jne      G_M000_IG58
       jmp      G_M000_IG302
 
G_M000_IG325:                ;; offset=0x2B9C
       mov      rdx, r15
       mov      rcx, 0x7FF9CCFE2F90
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG326
       test     dword ptr [rax+0x34], 0x1600000
       setne    r13b
       movzx    r13, r13b
       jmp      SHORT G_M000_IG327
 
G_M000_IG326:                ;; offset=0x2BC4
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, r15
       mov      r11, 0x7FF9CC911ED8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r13b
       movzx    r13, r13b
 
G_M000_IG327:                ;; offset=0x2BE3
       test     r13d, r13d
       jne      G_M000_IG231
       jmp      G_M000_IG302
 
G_M000_IG328:                ;; offset=0x2BF1
       mov      rdx, r15
       mov      rcx, 0x7FF9CCFE2F90
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG329
       test     dword ptr [rax+0x34], 0x1600000
       setne    r13b
       movzx    r13, r13b
       jmp      SHORT G_M000_IG330
 
G_M000_IG329:                ;; offset=0x2C19
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, r15
       mov      r11, 0x7FF9CC911EE0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r13b
       movzx    r13, r13b
 
G_M000_IG330:                ;; offset=0x2C38
       test     r13d, r13d
       jne      G_M000_IG231
       jmp      G_M000_IG302
 
G_M000_IG331:                ;; offset=0x2C46
       mov      rdx, r15
       mov      rcx, 0x7FF9CCFE2F90
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG332
       test     dword ptr [rax+0x34], 0x1600000
       setne    r13b
       movzx    r13, r13b
       jmp      SHORT G_M000_IG333
 
G_M000_IG332:                ;; offset=0x2C6E
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, r15
       mov      r11, 0x7FF9CC911EE8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r13b
       movzx    r13, r13b
 
G_M000_IG333:                ;; offset=0x2C8D
       test     r13d, r13d
       jne      G_M000_IG231
       jmp      G_M000_IG302
 
G_M000_IG334:                ;; offset=0x2C9B
       mov      rcx, bword ptr [rbp-0x340]
       mov      rdx, 0x18F4A14BFF0
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG335:                ;; offset=0x2CBB
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG336:                ;; offset=0x2CC1
       mov      rdx, r12
       mov      rcx, 0x7FF9CCFC92B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG337
       mov      edx, dword ptr [rax+0x34]
       and      edx, 0x1600000
       cmp      edx, 0x1000000
       sete     dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG338
 
G_M000_IG337:                ;; offset=0x2CF1
       mov      rax, bword ptr [rbp+0x40]
       movsx    rdx, word  ptr [rax+0x10]
       mov      rcx, r12
       mov      r11, 0x7FF9CC911EF0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetStatus(short):int:this
       cmp      eax, 1
       sete     dil
       movzx    rdi, dil
 
G_M000_IG338:                ;; offset=0x2D15
       test     edi, edi
       je       G_M000_IG136
       jmp      G_M000_IG129
 
G_M000_IG339:                ;; offset=0x2D22
       mov      rdx, rdi
       mov      rcx, 0x7FF9CCFC92B8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r12, rax
       test     r12, r12
       je       SHORT G_M000_IG342
       mov      ecx, dword ptr [r12+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       SHORT G_M000_IG341
 
G_M000_IG340:                ;; offset=0x2D4F
       mov      rcx, r12
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG341:                ;; offset=0x2D5A
       mov      r12, gword ptr [r12+0x38]
       jmp      G_M000_IG131
 
G_M000_IG342:                ;; offset=0x2D64
       mov      rax, bword ptr [rbp+0x40]
       movsx    rdx, word  ptr [rax+0x10]
       mov      rcx, rdi
       mov      r11, 0x7FF9CC911EF8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetResult(short):System.__Canon:this
       mov      r12, rax
       jmp      G_M000_IG131
 
G_M000_IG343:                ;; offset=0x2D85
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG361
 
G_M000_IG344:                ;; offset=0x2D9A
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG361
 
G_M000_IG345:                ;; offset=0x2DAA
       mov      rdx, r14
       mov      rcx, 0x7FF9CCFE2F90
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG346
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG347
 
G_M000_IG346:                ;; offset=0x2DD2
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, r14
       mov      r11, 0x7FF9CC911F08
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG347:                ;; offset=0x2DF1
       test     edi, edi
       jne      G_M000_IG58
       jmp      G_M000_IG302
 
G_M000_IG348:                ;; offset=0x2DFE
       mov      rdx, r15
       mov      rcx, 0x7FF9CCFE2F90
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG349
       test     dword ptr [rax+0x34], 0x1600000
       setne    r13b
       movzx    r13, r13b
       jmp      SHORT G_M000_IG350
 
G_M000_IG349:                ;; offset=0x2E26
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, r15
       mov      r11, 0x7FF9CC911F10
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r13b
       movzx    r13, r13b
 
G_M000_IG350:                ;; offset=0x2E45
       test     r13d, r13d
       jne      G_M000_IG58
       jmp      G_M000_IG302
 
G_M000_IG351:                ;; offset=0x2E53
       mov      rdx, rdi
       mov      rcx, 0x7FF9CCFE2F90
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG352
       test     dword ptr [rax+0x34], 0x1600000
       setne    r14b
       movzx    r14, r14b
       jmp      SHORT G_M000_IG353
 
G_M000_IG352:                ;; offset=0x2E7B
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, rdi
       mov      r11, 0x7FF9CC911F18
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r14b
       movzx    r14, r14b
 
G_M000_IG353:                ;; offset=0x2E9A
       test     r14d, r14d
       jne      G_M000_IG58
       jmp      G_M000_IG302
 
G_M000_IG354:                ;; offset=0x2EA8
       mov      rdx, rdi
       mov      rcx, 0x7FF9CCFE2F90
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG355
       test     dword ptr [rax+0x34], 0x1600000
       setne    r14b
       movzx    r14, r14b
       jmp      SHORT G_M000_IG356
 
G_M000_IG355:                ;; offset=0x2ED0
       movsx    rdx, word  ptr [rsi+0x08]
       mov      rcx, rdi
       mov      r11, 0x7FF9CC911F20
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r14b
       movzx    r14, r14b
 
G_M000_IG356:                ;; offset=0x2EEF
       test     r14d, r14d
       jne      G_M000_IG231
       jmp      G_M000_IG302
 
G_M000_IG357:                ;; offset=0x2EFD
       mov      rdx, bword ptr [rbp-0x118]
       mov      eax, ecx
       lea      rdx, bword ptr [rdx+2*rax]
       mov      eax, dword ptr [rbp-0x110]
       sub      eax, ecx
       cmp      eax, 27
       jb       SHORT G_M000_IG358
       vmovups  ymm0, ymmword ptr [reloc @RWD312]
       vmovups  ymmword ptr [rdx], ymm0
       vmovups  xmm0, xmmword ptr [reloc @RWD344]
       vmovups  xmmword ptr [rdx+0x20], xmm0
       mov      dword ptr [rdx+0x30], 0x3A0065
       mov      word  ptr [rdx+0x34], 32
       mov      ecx, dword ptr [rbp-0x120]
       add      ecx, 27
       mov      dword ptr [rbp-0x120], ecx
       jmp      SHORT G_M000_IG359
 
G_M000_IG358:                ;; offset=0x2F4E
       lea      rcx, [rbp-0x130]
       mov      rdx, 0x18F4A151300
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:GrowThenCopyString(System.String):this]
 
G_M000_IG359:                ;; offset=0x2F65
       mov      rdx, bword ptr [rbp-0x340]
       mov      edx, dword ptr [rdx+0x1C]
       lea      rcx, [rbp-0x130]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rcx, 0x7FF9CCB394A8
       call     CORINFO_HELP_NEWSFAST
       mov      rdi, rax
       lea      rcx, [rbp-0x130]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      rdx, rax
       mov      rcx, rdi
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rdi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG360:                ;; offset=0x2FB0
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG361:                ;; offset=0x2FB6
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG362
       mov      r14, bword ptr [rbp+0x10]
       cmp      gword ptr [r14+0x40], 0
       jne      SHORT G_M000_IG366
 
G_M000_IG362:                ;; offset=0x2FC7
       cmp      dword ptr [rbp-0x3C], 0
       jne      SHORT G_M000_IG363
       mov      r14, bword ptr [rbp+0x10]
       inc      dword ptr [r14+0x10]
 
G_M000_IG363:                ;; offset=0x2FD5
       mov      rbx, gword ptr [rbp+0x20]
       mov      rsi, bword ptr [rbp+0x30]
       mov      rcx, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rcx+0x10]
       mov      rdx, gword ptr [rbp-0x338]
       mov      edi, dword ptr [rdx+0x08]
       cmp      eax, edi
       mov      r9, rdx
       jl       G_M000_IG05
 
G_M000_IG364:                ;; offset=0x2FF9
       mov      eax, 1
 
G_M000_IG365:                ;; offset=0x2FFE
       vzeroupper 
       add      rsp, 984
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG366:                ;; offset=0x3015
       xor      rax, rax
       mov      rsi, bword ptr [rbp+0x30]
       mov      gword ptr [rsi], rax
       mov      word  ptr [rsi+0x08], 0
       movzx    rax, byte  ptr [rbp-0x3C]
       mov      byte  ptr [rsi+0x0A], al
       mov      byte  ptr [rsi+0x0B], 1
       mov      eax, 5
 
G_M000_IG367:                ;; offset=0x3034
       vzeroupper 
       add      rsp, 984
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG368:                ;; offset=0x304B
       mov      r9, bword ptr [rbp-0x340]
       mov      r9, gword ptr [r9]
       mov      rcx, rdi
       mov      rdx, r13
       mov      r8, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       je       SHORT G_M000_IG371
       mov      dword ptr [rbp-0x3C], 1
       jmp      G_M000_IG361
 
G_M000_IG369:                ;; offset=0x3074
       mov      eax, dword ptr [rbp-0xA4]
 
G_M000_IG370:                ;; offset=0x307A
       vzeroupper 
       add      rsp, 984
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG371:                ;; offset=0x3091
       mov      rcx, rdi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG372:                ;; offset=0x309A
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG373:                ;; offset=0x30A0
       sub      rsp, 72
 
G_M000_IG374:                ;; offset=0x30A4
       mov      rbx, rcx
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG375
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG375:                ;; offset=0x30B4
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      rdx, rbx
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryRouteReturn(Lokad.Lython.Runtime.LythonRuntime+ReturnSignal,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG377
       mov      dword ptr [rbp-0xA4], 1
       lea      rax, G_M000_IG369
 
G_M000_IG376:                ;; offset=0x30E6
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG377:                ;; offset=0x30EE
       mov      dword ptr [rbp-0x3C], 1
       lea      rax, G_M000_IG361
 
G_M000_IG378:                ;; offset=0x30FC
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG379:                ;; offset=0x3104
       sub      rsp, 72
 
G_M000_IG380:                ;; offset=0x3108
       mov      rbx, rcx
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      r9, rax
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG381
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG381:                ;; offset=0x3136
       mov      dword ptr [rbp-0x3C], 1
       lea      rax, G_M000_IG361
 
G_M000_IG382:                ;; offset=0x3144
       vzeroupper 
       add      rsp, 72
       ret      
 
RWD00  	dd	0000083Ah ; case G_M000_IG57
       	dd	00000719h ; case G_M000_IG50
       	dd	00001507h ; case G_M000_IG145
       	dd	00000507h ; case G_M000_IG37
       	dd	000003E4h ; case G_M000_IG30
       	dd	000002A3h ; case G_M000_IG23
       	dd	000001D2h ; case G_M000_IG17
       	dd	000000CFh ; case G_M000_IG09
       	dd	000000CFh ; case G_M000_IG09
       	dd	00000DBDh ; case G_M000_IG98
       	dd	00000DBDh ; case G_M000_IG98
       	dd	000000CFh ; case G_M000_IG09
       	dd	000000CFh ; case G_M000_IG09
       	dd	000000CFh ; case G_M000_IG09
       	dd	000000CFh ; case G_M000_IG09
       	dd	000000CFh ; case G_M000_IG09
       	dd	000000CFh ; case G_M000_IG09
       	dd	000000CFh ; case G_M000_IG09
       	dd	000000CFh ; case G_M000_IG09
       	dd	000000CFh ; case G_M000_IG09
       	dd	000000CFh ; case G_M000_IG09
       	dd	000000CFh ; case G_M000_IG09
       	dd	000015DDh ; case G_M000_IG150
       	dd	000015DDh ; case G_M000_IG150
       	dd	00002724h ; case G_M000_IG288
       	dd	00002701h ; case G_M000_IG287
       	dd	000026D9h ; case G_M000_IG286
       	dd	0000265Eh ; case G_M000_IG284
       	dd	000025CEh ; case G_M000_IG282
       	dd	000024D2h ; case G_M000_IG270
       	dd	00002472h ; case G_M000_IG268
       	dd	00002400h ; case G_M000_IG267
       	dd	00001F64h ; case G_M000_IG234
       	dd	00001F3Fh ; case G_M000_IG232
       	dd	00001F3Fh ; case G_M000_IG232
       	dd	00001F3Fh ; case G_M000_IG232
       	dd	00001EC3h ; case G_M000_IG228
       	dd	00001EC3h ; case G_M000_IG228
       	dd	00001EC3h ; case G_M000_IG228
       	dd	00001F3Fh ; case G_M000_IG232
       	dd	00001D97h ; case G_M000_IG222
       	dd	00001C7Ch ; case G_M000_IG214
       	dd	00000E0Dh ; case G_M000_IG99
       	dd	00000D97h ; case G_M000_IG97
       	dd	00000D13h ; case G_M000_IG94
       	dd	00000CE5h ; case G_M000_IG92
       	dd	00000CBAh ; case G_M000_IG91
       	dd	00000CBAh ; case G_M000_IG91
       	dd	00000CBAh ; case G_M000_IG91
       	dd	00000C2Fh ; case G_M000_IG88
       	dd	00000B24h ; case G_M000_IG79
       	dd	00000ADDh ; case G_M000_IG78
       	dd	00000C2Fh ; case G_M000_IG88
       	dd	00000C2Fh ; case G_M000_IG88
       	dd	00000C2Fh ; case G_M000_IG88
       	dd	00000C2Fh ; case G_M000_IG88
       	dd	00000C2Fh ; case G_M000_IG88
       	dd	00000C2Fh ; case G_M000_IG88
       	dd	00000C2Fh ; case G_M000_IG88
       	dd	000023EDh ; case G_M000_IG266
       	dd	000008ECh ; case G_M000_IG60
       	dd	00002189h ; case G_M000_IG247
       	dd	00000C2Fh ; case G_M000_IG88
       	dd	00002060h ; case G_M000_IG238
       	dd	00002060h ; case G_M000_IG238
       	dd	00002060h ; case G_M000_IG238
       	dd	00002060h ; case G_M000_IG238
       	dd	00002060h ; case G_M000_IG238
       	dd	00001C56h ; case G_M000_IG213
       	dd	00001B7Ah ; case G_M000_IG210
       	dd	000019F9h ; case G_M000_IG190
       	dd	0000191Ah ; case G_M000_IG177
       	dd	000017A1h ; case G_M000_IG166
       	dd	00001896h ; case G_M000_IG174
       	dd	000016CCh ; case G_M000_IG155
       	dd	00001623h ; case G_M000_IG152
       	dd	000015BDh ; case G_M000_IG149
       	dd	000014E7h ; case G_M000_IG144
RWD312 	dq	006E006B006E0055h, 0020006E0077006Fh, 0063006500780065h, 0062006100740075h
RWD344 	dq	006F00200065006Ch, 0064006F00630070h

; Total bytes of code 12620

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:RunCore(byref):bool:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 168 single block inlinees; 46 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 240
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x40], ymm4
       vmovdqu  ymmword ptr [rsp+0x60], ymm4
       vmovdqu  ymmword ptr [rsp+0x80], ymm4
       vmovdqu  ymmword ptr [rsp+0xA0], ymm4
       vmovdqu  ymmword ptr [rsp+0xC0], ymm4
       vmovdqa  xmmword ptr [rsp+0xE0], xmm4
       mov      rbx, rcx
       mov      rsi, rdx
 
G_M000_IG02:                ;; offset=0x004B
       mov      rcx, 0x18F4E8012A0
       mov      rdx, gword ptr [rcx]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rsi+0x08], rcx
       mov      ecx, dword ptr [rbx+0x38]
       mov      rax, gword ptr [rbx+0x08]
       cmp      ecx, dword ptr [rax+0xEC]
       jge      G_M000_IG147
 
G_M000_IG03:                ;; offset=0x0079
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x98]
       mov      eax, dword ptr [rbx+0x38]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG224
       shl      rax, 5
       lea      rdi, bword ptr [rcx+rax+0x10]
       mov      rcx, gword ptr [rbx+0x10]
       mov      rbp, gword ptr [rcx+0xA0]
       mov      r14, gword ptr [rdi]
       cmp      byte  ptr [rbp], bpl
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00B8
       mov      rcx, rbp
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG05:                ;; offset=0x00C4
       mov      ebp, dword ptr [rdi+0x1C]
       lea      ecx, [rbp-0x01]
       cmp      ecx, 76
       ja       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00CF
       mov      ecx, ecx
       lea      rdx, [reloc @RWD00]
       mov      edx, dword ptr [rdx+4*rcx]
       lea      rax, G_M000_IG02
       add      rdx, rax
       jmp      rdx
 
G_M000_IG07:                ;; offset=0x00E7
       xor      eax, eax
 
G_M000_IG08:                ;; offset=0x00E9
       add      rsp, 240
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG09:                ;; offset=0x00FB
       mov      rdx, gword ptr [rbx+0x08]
       mov      ecx, dword ptr [rdx+0xEC]
       mov      rax, gword ptr [rdx+0x98]
       cmp      ecx, dword ptr [rax+0x08]
       jne      SHORT G_M000_IG07
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DiscardIterator():bool:this]
       test     eax, eax
       je       G_M000_IG66
       mov      edx, dword ptr [rbx+0x3C]
       dec      edx
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG66
 
G_M000_IG10:                ;; offset=0x0135
       lea      r8, [rsp+0x80]
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryIntegerComparison(byref,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG17
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG11:                ;; offset=0x0155
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x50], xmm0
 
G_M000_IG12:                ;; offset=0x0160
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x50]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      rbp, rax
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG13:                ;; offset=0x0192
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x50], xmm0
 
G_M000_IG14:                ;; offset=0x019D
       mov      dword ptr [rsp+0x20], 1
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x50]
       mov      r8d, dword ptr [rdi+0x0C]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      r8, rax
       cmp      dword ptr [rdi+0x1C], 51
       jne      SHORT G_M000_IG15
       mov      ecx, dword ptr [rdi+0x14]
       jmp      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x01D8
       mov      ecx, dword ptr [rdi+0x08]
       and      ecx, 0x7FFFFFFF
 
G_M000_IG16:                ;; offset=0x01E1
       mov      r9, gword ptr [rdi]
       mov      gword ptr [rsp+0x20], r9
       lea      r9, [rsp+0x80]
       mov      qword ptr [rsp+0x28], r9
       mov      r9, gword ptr [rbx+0x10]
       mov      rdx, rbp
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       G_M000_IG07
 
G_M000_IG17:                ;; offset=0x020B
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG18
       not      edx
 
G_M000_IG18:                ;; offset=0x0214
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rcx, gword ptr [rbx+0x10]
       mov      rbp, gword ptr [rdi]
       mov      r14, gword ptr [rcx+0xA0]
       cmp      byte  ptr [r14], r14b
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG19
       mov      rcx, r14
       mov      rdx, rbp
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG19:                ;; offset=0x0247
       cmp      byte  ptr [rsp+0x80], 0
       jne      G_M000_IG145
       jmp      G_M000_IG66
 
G_M000_IG20:                ;; offset=0x025A
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, rdx
 
G_M000_IG21:                ;; offset=0x0261
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x50], xmm0
 
G_M000_IG22:                ;; offset=0x026C
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x50]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      rbp, rax
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       je       G_M000_IG07
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      r8, gword ptr [rdi]
       mov      rdx, gword ptr [rbx+0x10]
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.LythonRuntime:IsTruthy(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      G_M000_IG145
       jmp      G_M000_IG66
 
G_M000_IG23:                ;; offset=0x02D4
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryIntegerOperation():bool:this]
       test     eax, eax
       jne      G_M000_IG145
 
G_M000_IG24:                ;; offset=0x02E5
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG25:                ;; offset=0x02E9
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x50], xmm0
 
G_M000_IG26:                ;; offset=0x02F4
       lea      rdx, [rsp+0xB0]
       mov      qword ptr [rsp+0x20], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x50]
       mov      r8d, dword ptr [rbx+0x38]
       mov      r9, gword ptr [rbx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateBuiltinArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):bool]
       test     eax, eax
       je       G_M000_IG07
 
G_M000_IG27:                ;; offset=0x0325
       vmovdqu  xmm0, xmmword ptr [rsp+0xB0]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG28:                ;; offset=0x0334
       lea      r8, [rsp+0x40]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG29:                ;; offset=0x034A
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, rdx
 
G_M000_IG30:                ;; offset=0x0351
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x50], xmm0
 
G_M000_IG31:                ;; offset=0x035C
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x50]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      rbp, rax
       mov      rcx, gword ptr [rbx+0x08]
       mov      r14, bword ptr [rbx+0x48]
       mov      r15d, dword ptr [rbx+0x50]
       mov      r13d, dword ptr [rdi+0x0C]
       mov      r8, gword ptr [rbx+0x10]
       xor      r9d, r9d
       mov      gword ptr [rsp+0x60], r9
 
G_M000_IG32:                ;; offset=0x03A6
       mov      gword ptr [rsp+0x68], r9
       test     r13d, r13d
       jge      SHORT G_M000_IG35
       mov      r15d, r13d
       not      r15d
       mov      r13, gword ptr [rcx+0x30]
       mov      edx, r15d
       sub      edx, dword ptr [r13+0x08]
       js       SHORT G_M000_IG34
       mov      r13, gword ptr [rcx+0x38]
       cmp      dword ptr [r13+0x08], edx
       jle      SHORT G_M000_IG33
       lea      r9, [rsp+0x68]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       lea      rdx, [rsp+0xA0]
       mov      rcx, gword ptr [rsp+0x68]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG36
 
G_M000_IG33:                ;; offset=0x03ED
       sub      edx, dword ptr [r13+0x08]
       lea      rcx, [rsp+0x60]
       lea      r8, [rsp+0xA0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures:TryReadInteger(int,byref):bool:this]
       jmp      SHORT G_M000_IG36
 
G_M000_IG34:                ;; offset=0x0406
       cmp      r15d, dword ptr [r13+0x08]
       jae      G_M000_IG224
       mov      ecx, r15d
       mov      rcx, gword ptr [r13+8*rcx+0x10]
       lea      rdx, [rsp+0xA0]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG36
 
G_M000_IG35:                ;; offset=0x0428
       cmp      r13d, r15d
       jae      G_M000_IG224
       mov      ecx, r13d
       shl      rcx, 4
       add      rcx, r14
       lea      rdx, [rsp+0xA0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
 
G_M000_IG36:                ;; offset=0x0449
       xor      r9, r9
       mov      gword ptr [rsp+0x68], r9
       test     eax, eax
       je       SHORT G_M000_IG37
       mov      rdx, qword ptr [rsp+0xA0]
       lea      r9, [rsp+0x90]
       mov      qword ptr [rsp+0x20], r9
       mov      r9, gword ptr [rbx+0x10]
       mov      r8, gword ptr [rdi]
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.PyIndexing:TryReadSequenceIndex(System.Object,long,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG50
 
G_M000_IG37:                ;; offset=0x0482
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG38:                ;; offset=0x0486
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x50], xmm0
 
G_M000_IG39:                ;; offset=0x0491
       mov      dword ptr [rsp+0x20], 1
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x50]
       mov      r8d, dword ptr [rdi+0x0C]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      r14, rax
       test     rbp, rbp
       je       G_M000_IG07
 
G_M000_IG40:                ;; offset=0x04CA
       mov      rcx, 0x7FF9CCEC4750
       cmp      qword ptr [rbp], rcx
       jne      G_M000_IG07
 
G_M000_IG41:                ;; offset=0x04DE
       cmp      gword ptr [rbp+0x28], 0
       jne      SHORT G_M000_IG42
       mov      rcx, gword ptr [rbp+0x08]
       mov      r11, 0x7FF9CC912030
       call     [r11]Lokad.Lython.Runtime.IPyDictStorage:get_HasProtocolKeys():bool:this
       test     eax, eax
       jne      G_M000_IG07
       jmp      SHORT G_M000_IG43
 
G_M000_IG42:                ;; offset=0x0500
       cmp      dword ptr [rbp+0x50], 0
       jne      G_M000_IG07
 
G_M000_IG43:                ;; offset=0x050A
       test     r14, r14
       je       G_M000_IG07
 
G_M000_IG44:                ;; offset=0x0513
       mov      rcx, 0x7FF9CCE1DAA0
       cmp      qword ptr [r14], rcx
       jne      G_M000_IG07
 
G_M000_IG45:                ;; offset=0x0526
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       test     eax, eax
       jl       SHORT G_M000_IG46
       cmp      gword ptr [rbp+0x20], 0
       je       SHORT G_M000_IG46
       mov      rcx, gword ptr [rbx]
       mov      rdx, gword ptr [rdi]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:GetLookupCaches(Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntime+ExecutableLookupCache[]:this]
       mov      r15, rax
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       cmp      eax, dword ptr [r15+0x08]
       jae      G_M000_IG224
       mov      r8d, eax
       lea      r8, [r8+2*r8]
       lea      r8, bword ptr [r15+8*r8+0x10]
       mov      r9, gword ptr [rdi]
       mov      gword ptr [rsp+0x20], r9
       lea      r9, [rsp+0x88]
       mov      qword ptr [rsp+0x28], r9
       mov      r9, gword ptr [rbx+0x10]
       mov      rdx, r14
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.PyDict:TryReadRecordValue(Lokad.Lython.Runtime.Text.PyString,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG49
 
G_M000_IG46:                ;; offset=0x0593
       cmp      gword ptr [rbp+0x28], 0
       jne      SHORT G_M000_IG47
       mov      rcx, gword ptr [rbp+0x08]
       mov      r11, 0x7FF9CC912038
       call     [r11]Lokad.Lython.Runtime.IPyDictStorage:get_HasProtocolKeys():bool:this
       test     eax, eax
       jne      G_M000_IG07
       jmp      SHORT G_M000_IG48
 
G_M000_IG47:                ;; offset=0x05B5
       cmp      dword ptr [rbp+0x50], 0
       jne      G_M000_IG07
 
G_M000_IG48:                ;; offset=0x05BF
       mov      r8, gword ptr [rdi]
       mov      r9, gword ptr [rbx+0x10]
       mov      rcx, rbp
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadSubscriptValue(System.Object,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rsp+0x40], rax
       xor      r8d, r8d
       mov      qword ptr [rsp+0x48], r8
       lea      r8, [rsp+0x40]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG49:                ;; offset=0x05F5
       mov      r8, gword ptr [rsp+0x88]
       mov      gword ptr [rsp+0x40], r8
       xor      r8d, r8d
       mov      qword ptr [rsp+0x48], r8
       lea      r8, [rsp+0x40]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG50:                ;; offset=0x0620
       vmovdqu  xmm0, xmmword ptr [rsp+0x90]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG51:                ;; offset=0x062F
       lea      r8, [rsp+0x40]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG52:                ;; offset=0x0645
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG145
       jmp      G_M000_IG07
 
G_M000_IG53:                ;; offset=0x065E
       lea      rcx, bword ptr [rbx+0x48]
       mov      eax, dword ptr [rdi+0x10]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG224
       shl      rax, 4
       add      rax, bword ptr [rcx]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9CCFC77C8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rcx, rax
       test     rcx, rcx
       je       SHORT G_M000_IG56
 
G_M000_IG54:                ;; offset=0x0699
       mov      rdx, 0x7FF9CD095448
       cmp      qword ptr [rcx], rdx
       jne      SHORT G_M000_IG56
 
G_M000_IG55:                ;; offset=0x06A8
       lea      rdx, [rsp+0x70]
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:MoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       jmp      SHORT G_M000_IG62
 
G_M000_IG56:                ;; offset=0x06B5
       test     rcx, rcx
       je       SHORT G_M000_IG59
 
G_M000_IG57:                ;; offset=0x06BA
       mov      rdx, 0x7FF9CD096CE0
       cmp      qword ptr [rcx], rdx
       jne      SHORT G_M000_IG59
 
G_M000_IG58:                ;; offset=0x06C9
       lea      rdx, [rsp+0x70]
       call     [Lokad.Lython.Runtime.PyRange+Enumerator:TryMoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       jmp      SHORT G_M000_IG62
 
G_M000_IG59:                ;; offset=0x06D6
       mov      rbp, rcx
       test     rbp, rbp
       je       SHORT G_M000_IG61
 
G_M000_IG60:                ;; offset=0x06DE
       mov      rax, 0x7FF9CCFC7330
       cmp      qword ptr [rbp], rax
       jne      G_M000_IG220
 
G_M000_IG61:                ;; offset=0x06F2
       cmp      byte  ptr [rbp], bpl
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:CheckExecution():this]
       lea      rdx, [rsp+0x70]
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:TryMoveNextCore():Lokad.Lython.Runtime.PyIterationResult:this]
 
G_M000_IG62:                ;; offset=0x070D
       cmp      gword ptr [rsp+0x70], 0
       je       SHORT G_M000_IG65
 
G_M000_IG63:                ;; offset=0x0715
       vmovdqu  xmm0, xmmword ptr [rsp+0x70]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG64:                ;; offset=0x0721
       lea      r8, [rsp+0x40]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG65:                ;; offset=0x0737
       mov      edx, dword ptr [rdi+0x10]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG66:                ;; offset=0x0743
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      dword ptr [rbx+0x38], eax
       jmp      G_M000_IG146
 
G_M000_IG67:                ;; offset=0x0754
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, rdx
 
G_M000_IG68:                ;; offset=0x075B
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x50], xmm0
 
G_M000_IG69:                ;; offset=0x0766
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x50]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      rbp, rax
       test     rbp, rbp
       je       G_M000_IG74
 
G_M000_IG70:                ;; offset=0x079D
       mov      r8, 0x7FF9CD095448
       cmp      qword ptr [rbp], r8
       jne      SHORT G_M000_IG72
 
G_M000_IG71:                ;; offset=0x07AD
       mov      gword ptr [rsp+0x40], rbp
       xor      r8d, r8d
       mov      qword ptr [rsp+0x48], r8
       lea      r8, [rsp+0x40]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG72:                ;; offset=0x07D0
       mov      rcx, 0x7FF9CCFF5E70
       cmp      qword ptr [rbp], rcx
       jne      SHORT G_M000_IG74
 
G_M000_IG73:                ;; offset=0x07E0
       mov      rcx, 0x7FF9CD096CE0
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      rcx, r14
       mov      rdx, rbp
       call     [Lokad.Lython.Runtime.PyRange+Enumerator:.ctor(Lokad.Lython.Runtime.PyRange):this]
       mov      gword ptr [rsp+0x40], r14
       xor      r8d, r8d
       mov      qword ptr [rsp+0x48], r8
       lea      r8, [rsp+0x40]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG74:                ;; offset=0x0821
       test     rbp, rbp
       je       SHORT G_M000_IG76
 
G_M000_IG75:                ;; offset=0x0826
       mov      rdx, 0x7FF9CCFCDA88
       cmp      qword ptr [rbp], rdx
       je       SHORT G_M000_IG78
 
G_M000_IG76:                ;; offset=0x0836
       mov      rdx, rbp
       mov      rcx, 0x7FF9CCF28898
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG78
       test     rbp, rbp
       je       G_M000_IG07
 
G_M000_IG77:                ;; offset=0x0856
       mov      r8, 0x7FF9CCEE3CD8
       cmp      qword ptr [rbp], r8
       je       SHORT G_M000_IG78
       mov      r8, 0x7FF9CCE1DAA0
       cmp      qword ptr [rbp], r8
       je       SHORT G_M000_IG78
       mov      r8, 0x7FF9CCEC4750
       cmp      qword ptr [rbp], r8
       je       SHORT G_M000_IG78
       mov      r8, 0x7FF9CCFED2F8
       cmp      qword ptr [rbp], r8
       jne      G_M000_IG07
 
G_M000_IG78:                ;; offset=0x089A
       mov      r8, gword ptr [rbx+0x10]
       mov      rdx, gword ptr [rdi]
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:Create(System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyIteration+Cursor]
       mov      gword ptr [rsp+0x40], rax
       xor      r8d, r8d
       mov      qword ptr [rsp+0x48], r8
       lea      r8, [rsp+0x40]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG79:                ;; offset=0x08CD
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:ConstructContainer(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG145
       jmp      G_M000_IG07
 
G_M000_IG80:                ;; offset=0x08E6
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryReturnUnpackedTuple(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG160
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       test     eax, eax
       jne      SHORT G_M000_IG81
       mov      rcx, 0x18F4E8015F0
       mov      rbp, gword ptr [rcx]
       jmp      SHORT G_M000_IG82
 
G_M000_IG81:                ;; offset=0x0916
       lea      rbp, bword ptr [rbx+0x48]
       mov      r14d, dword ptr [rdi+0x10]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      ecx, r14d
       mov      edx, eax
       add      rcx, rdx
       mov      edx, dword ptr [rbp+0x08]
       cmp      rcx, rdx
       ja       G_M000_IG223
       mov      ecx, r14d
       shl      rcx, 4
       add      rcx, bword ptr [rbp]
       mov      bword ptr [rsp+0x50], rcx
       mov      dword ptr [rsp+0x58], eax
       lea      rcx, [rsp+0x50]
       mov      rdx, gword ptr [rbx+0x10]
       mov      r8, gword ptr [rdi]
       call     [Lokad.Lython.Runtime.PyTuple:FromSlots(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      rbp, rax
 
G_M000_IG82:                ;; offset=0x0964
       mov      edx, dword ptr [rdi+0x10]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      gword ptr [rsp+0x40], rbp
       xor      r8d, r8d
       mov      qword ptr [rsp+0x48], r8
       lea      r8, [rsp+0x40]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG83:                ;; offset=0x0993
       lea      rbp, bword ptr [rbx+0x48]
       mov      r14d, dword ptr [rdi+0x10]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      ecx, r14d
       mov      edx, eax
       add      rcx, rdx
       mov      edx, dword ptr [rbp+0x08]
       cmp      rcx, rdx
       ja       G_M000_IG223
       mov      ecx, r14d
       shl      rcx, 4
       add      rcx, bword ptr [rbp]
       mov      bword ptr [rsp+0x50], rcx
       mov      dword ptr [rsp+0x58], eax
       lea      rcx, [rsp+0x50]
       mov      rdx, gword ptr [rbx+0x10]
       mov      r8, gword ptr [rdi]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateSlotList(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyList]
       mov      rbp, rax
       mov      edx, dword ptr [rdi+0x10]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      gword ptr [rsp+0x40], rbp
       xor      r8d, r8d
       mov      qword ptr [rsp+0x48], r8
       lea      r8, [rsp+0x40]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG84:                ;; offset=0x0A10
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, rdx
 
G_M000_IG85:                ;; offset=0x0A17
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x50], xmm0
 
G_M000_IG86:                ;; offset=0x0A22
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x50]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG87
       not      edx
 
G_M000_IG87:                ;; offset=0x0A56
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG145
 
G_M000_IG88:                ;; offset=0x0A64
       mov      ecx, ebp
       cmp      ecx, 51
       ja       SHORT G_M000_IG93
 
G_M000_IG89:                ;; offset=0x0A6B
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG93
 
G_M000_IG90:                ;; offset=0x0A7B
       mov      ebp, dword ptr [rdi+0x18]
       test     ebp, ebp
       jge      SHORT G_M000_IG91
       mov      r14d, ebp
       not      r14d
       jmp      SHORT G_M000_IG92
 
G_M000_IG91:                ;; offset=0x0A8A
       mov      r14d, ebp
 
G_M000_IG92:                ;; offset=0x0A8D
       jmp      SHORT G_M000_IG94
 
G_M000_IG93:                ;; offset=0x0A8F
       mov      r14d, dword ptr [rdi+0x14]
 
G_M000_IG94:                ;; offset=0x0A93
       inc      r14d
       mov      ebp, dword ptr [rdi+0x18]
       test     ebp, ebp
       jge      SHORT G_M000_IG95
       mov      r15d, ebp
       not      r15d
       jmp      SHORT G_M000_IG96
 
G_M000_IG95:                ;; offset=0x0AA5
       mov      r15d, ebp
 
G_M000_IG96:                ;; offset=0x0AA8
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, rdx
 
G_M000_IG97:                ;; offset=0x0AAF
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x50], xmm0
 
G_M000_IG98:                ;; offset=0x0ABA
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x50]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      rdi, rax
       cmp      r15d, dword ptr [rbx+0x3C]
       jge      SHORT G_M000_IG99
       mov      rcx, rbx
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG99:                ;; offset=0x0AFA
       lea      rcx, bword ptr [rbx+0x48]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG224
       mov      ebp, r14d
       shl      rbp, 4
       add      rbp, bword ptr [rcx]
       mov      rcx, rbp
       mov      rdx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      edx, edx
       mov      qword ptr [rbp+0x08], rdx
       mov      dword ptr [rbx+0x3C], r15d
       jmp      G_M000_IG145
 
G_M000_IG100:                ;; offset=0x0B2C
       lea      rcx, bword ptr [rbx+0x58]
       mov      edx, ebp
       cmp      edx, 3
       je       SHORT G_M000_IG101
       cmp      edx, 26
       jne      G_M000_IG222
 
G_M000_IG101:                ;; offset=0x0B40
       mov      edx, dword ptr [rdi+0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures:GetCell(int):Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:this]
       mov      rbp, rax
       test     rbp, rbp
       je       G_M000_IG07
       mov      rcx, gword ptr [rbp+0x10]
       test     rcx, rcx
       je       SHORT G_M000_IG102
       cmp      gword ptr [rbp+0x18], 0
       je       G_M000_IG07
       cmp      gword ptr [rcx+0x88], 0
       jne      G_M000_IG07
 
G_M000_IG102:                ;; offset=0x0B77
       mov      r8d, dword ptr [rdi+0x10]
       test     r8d, r8d
       jl       SHORT G_M000_IG106
       lea      rcx, bword ptr [rbx+0x48]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG224
       mov      edx, r8d
       shl      rdx, 4
       add      rdx, bword ptr [rcx]
       mov      r14, gword ptr [rdx]
       mov      r15, qword ptr [rdx+0x08]
       test     r14, r14
       jne      SHORT G_M000_IG105
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG103:                ;; offset=0x0BA8
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x50], xmm0
 
G_M000_IG104:                ;; offset=0x0BB3
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x50]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
 
G_M000_IG105:                ;; offset=0x0BDA
       jmp      SHORT G_M000_IG109
 
G_M000_IG106:                ;; offset=0x0BDC
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG107:                ;; offset=0x0BE0
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x50], xmm0
 
G_M000_IG108:                ;; offset=0x0BEB
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x50]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      r14, rax
       xor      r15d, r15d
 
G_M000_IG109:                ;; offset=0x0C18
       lea      rcx, bword ptr [rbx+0x48]
       mov      edx, dword ptr [rdi+0x10]
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG224
       mov      rcx, bword ptr [rcx]
       shl      rdx, 4
       xor      eax, eax
       mov      qword ptr [rcx+rdx], rax
       mov      qword ptr [rcx+rdx+0x08], rax
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG110
       not      edx
 
G_M000_IG110:                ;; offset=0x0C43
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      gword ptr [rsp+0x40], r14
       mov      qword ptr [rsp+0x48], r15
       lea      rdx, [rsp+0x40]
       mov      rcx, rbp
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:StoreSlot(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG111:                ;; offset=0x0C69
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StoreLocal(byref):this]
       jmp      G_M000_IG145
 
G_M000_IG112:                ;; offset=0x0C7A
       mov      r8, 0x7FF9CCFCD018
       cmp      qword ptr [rbp], r8
       jne      G_M000_IG166
 
G_M000_IG113:                ;; offset=0x0C8E
       lea      r8, [rsp+0xA8]
       mov      rcx, rbp
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.PyAttributeLookup:TryResolveInstanceFunctionForCall(Lokad.Lython.Runtime.PyInstance,System.String,byref):bool]
       test     eax, eax
       je       G_M000_IG166
       mov      r15, gword ptr [rsp+0xA8]
 
G_M000_IG114:                ;; offset=0x0CB2
       test     r15, r15
       je       G_M000_IG07
       mov      ecx, dword ptr [rdi+0x1C]
       mov      edx, ecx
       cmp      edx, 51
       ja       SHORT G_M000_IG118
 
G_M000_IG115:                ;; offset=0x0CC5
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG118
 
G_M000_IG116:                ;; offset=0x0CD5
       mov      r14d, dword ptr [rdi+0x18]
       test     r14d, r14d
       jge      SHORT G_M000_IG117
       not      r14d
 
G_M000_IG117:                ;; offset=0x0CE1
       jmp      SHORT G_M000_IG119
 
G_M000_IG118:                ;; offset=0x0CE3
       mov      r14d, dword ptr [rdi+0x14]
 
G_M000_IG119:                ;; offset=0x0CE7
       cmp      ecx, 51
       ja       SHORT G_M000_IG124
 
G_M000_IG120:                ;; offset=0x0CEC
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG124
 
G_M000_IG121:                ;; offset=0x0CFC
       mov      ecx, dword ptr [rdi+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG122
       mov      r13d, ecx
       not      r13d
       jmp      SHORT G_M000_IG123
 
G_M000_IG122:                ;; offset=0x0D0B
       mov      r13d, ecx
 
G_M000_IG123:                ;; offset=0x0D0E
       jmp      SHORT G_M000_IG125
 
G_M000_IG124:                ;; offset=0x0D10
       mov      r13d, dword ptr [rdi+0x14]
 
G_M000_IG125:                ;; offset=0x0D14
       inc      r13d
       cmp      r13d, dword ptr [rbx+0x3C]
       jge      SHORT G_M000_IG126
       mov      rcx, rbx
       mov      edx, r13d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG126:                ;; offset=0x0D29
       lea      rcx, bword ptr [rbx+0x48]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG224
       mov      r14d, r14d
       shl      r14, 4
       add      r14, bword ptr [rcx]
       mov      rcx, r14
       mov      rdx, rbp
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r14+0x08], rcx
       mov      dword ptr [rbx+0x3C], r13d
       mov      ecx, dword ptr [rdi+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG130
 
G_M000_IG127:                ;; offset=0x0D5E
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       SHORT G_M000_IG130
 
G_M000_IG128:                ;; offset=0x0D6E
       mov      ebp, dword ptr [rdi+0x18]
       test     ebp, ebp
       jge      SHORT G_M000_IG129
       not      ebp
 
G_M000_IG129:                ;; offset=0x0D77
       jmp      SHORT G_M000_IG131
 
G_M000_IG130:                ;; offset=0x0D79
       mov      ebp, dword ptr [rdi+0x14]
 
G_M000_IG131:                ;; offset=0x0D7C
       inc      ebp
       mov      ecx, dword ptr [rdi+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG132
       mov      edi, ecx
       not      edi
       jmp      SHORT G_M000_IG133
 
G_M000_IG132:                ;; offset=0x0D8B
       mov      edi, ecx
 
G_M000_IG133:                ;; offset=0x0D8D
       cmp      edi, dword ptr [rbx+0x3C]
       jge      SHORT G_M000_IG134
       mov      rcx, rbx
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG134:                ;; offset=0x0D9D
       lea      rcx, bword ptr [rbx+0x48]
       cmp      ebp, dword ptr [rcx+0x08]
       jae      G_M000_IG224
       mov      ebp, ebp
       shl      rbp, 4
       add      rbp, bword ptr [rcx]
       mov      rcx, rbp
       mov      rdx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rbp+0x08], rcx
       mov      dword ptr [rbx+0x3C], edi
       jmp      G_M000_IG145
 
G_M000_IG135:                ;; offset=0x0DCC
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StoreSubscript(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG145
       jmp      G_M000_IG07
 
G_M000_IG136:                ;; offset=0x0DE5
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:ApplyDefinition(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG145
       jmp      G_M000_IG07
 
G_M000_IG137:                ;; offset=0x0DFE
       mov      rdx, gword ptr [rbx+0x08]
       mov      rbp, rdx
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      edx, eax
       mov      rcx, rbp
       mov      r8, gword ptr [rdi]
       mov      r9, gword ptr [rbx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rsp+0x40], rax
       xor      r8d, r8d
       mov      qword ptr [rsp+0x48], r8
       lea      r8, [rsp+0x40]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG138:                ;; offset=0x0E43
       mov      rcx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x20], rcx
       mov      rdx, gword ptr [rbx+0x08]
       mov      rcx, rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      r8d, dword ptr [rbx+0x38]
       mov      r9d, dword ptr [rbx+0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      SHORT G_M000_IG140
       lea      rcx, bword ptr [rbx+0x58]
       mov      edx, dword ptr [rdi+0x1C]
       cmp      edx, 3
       je       SHORT G_M000_IG139
       cmp      edx, 26
       jne      G_M000_IG222
 
G_M000_IG139:                ;; offset=0x0E7E
       mov      edx, dword ptr [rdi+0x08]
       lea      r8, [rsp+0xD0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures:TryRead(int,byref):bool:this]
       test     eax, eax
       je       G_M000_IG07
       cmp      gword ptr [rsp+0xD0], 0
       je       G_M000_IG07
       mov      r8, gword ptr [rsp+0xD0]
       mov      gword ptr [rsp+0x40], r8
       xor      r8d, r8d
       mov      qword ptr [rsp+0x48], r8
       lea      r8, [rsp+0x40]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG140:                ;; offset=0x0ED1
       add      dword ptr [rbx+0x38], 2
       jmp      G_M000_IG145
 
G_M000_IG141:                ;; offset=0x0EDA
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      r8d, eax
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG142:                ;; offset=0x0EEA
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x50], xmm0
 
G_M000_IG143:                ;; offset=0x0EF5
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x50]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      gword ptr [rsp+0x40], rax
       xor      r8d, r8d
       mov      qword ptr [rsp+0x48], r8
       lea      r8, [rsp+0x40]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      SHORT G_M000_IG145
 
G_M000_IG144:                ;; offset=0x0F3C
       mov      rdx, gword ptr [rbx+0x08]
       mov      rbp, gword ptr [rdx+0x30]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rbp+0x08]
       jae      G_M000_IG224
       mov      ecx, eax
       mov      rcx, gword ptr [rbp+8*rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      gword ptr [rsp+0x40], rax
       xor      r8d, r8d
       mov      qword ptr [rsp+0x48], r8
       lea      r8, [rsp+0x40]
       mov      rdx, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
 
G_M000_IG145:                ;; offset=0x0F81
       inc      dword ptr [rbx+0x38]
 
G_M000_IG146:                ;; offset=0x0F84
       mov      ecx, dword ptr [rbx+0x38]
       mov      rax, gword ptr [rbx+0x08]
       cmp      ecx, dword ptr [rax+0xEC]
       jl       G_M000_IG03
 
G_M000_IG147:                ;; offset=0x0F97
       mov      eax, dword ptr [rbx+0x38]
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x98]
       cmp      eax, dword ptr [rcx+0x08]
       setge    al
       movzx    rax, al
 
G_M000_IG148:                ;; offset=0x0FAE
       add      rsp, 240
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG149:                ;; offset=0x0FC0
       mov      rdx, gword ptr [rbx+0x08]
       mov      ecx, dword ptr [rdx+0xEC]
       mov      rdx, gword ptr [rdx+0x98]
       cmp      ecx, dword ptr [rdx+0x08]
       jne      G_M000_IG07
       jmp      G_M000_IG159
 
G_M000_IG150:                ;; offset=0x0FDF
       mov      rdx, gword ptr [rbx+0x08]
       mov      ecx, dword ptr [rdx+0xEC]
       mov      r9, gword ptr [rdx+0x98]
       cmp      ecx, dword ptr [r9+0x08]
       jne      G_M000_IG07
       mov      r8d, dword ptr [rdi+0x10]
       test     r8d, r8d
       jl       SHORT G_M000_IG154
       lea      rcx, bword ptr [rbx+0x48]
       cmp      r8d, dword ptr [rcx+0x08]
       jae      G_M000_IG224
       mov      r9d, r8d
       shl      r9, 4
       add      r9, bword ptr [rcx]
       mov      rbp, gword ptr [r9]
       mov      r14, qword ptr [r9+0x08]
       test     rbp, rbp
       jne      SHORT G_M000_IG153
       mov      rcx, rdx
 
G_M000_IG151:                ;; offset=0x102A
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x50], xmm0
 
G_M000_IG152:                ;; offset=0x1035
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x50]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
 
G_M000_IG153:                ;; offset=0x105C
       jmp      SHORT G_M000_IG157
 
G_M000_IG154:                ;; offset=0x105E
       mov      rcx, rdx
 
G_M000_IG155:                ;; offset=0x1061
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x50], xmm0
 
G_M000_IG156:                ;; offset=0x106C
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x50]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      rbp, rax
       xor      r14d, r14d
 
G_M000_IG157:                ;; offset=0x1099
       mov      rcx, rsi
       mov      rdx, rbp
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      qword ptr [rsi+0x08], r14
       mov      edx, dword ptr [rdi+0x10]
       mov      rcx, gword ptr [rbx+0x08]
       cmp      edx, dword ptr [rcx+0xD8]
       jl       SHORT G_M000_IG159
       lea      rcx, bword ptr [rbx+0x48]
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG224
       shl      rdx, 4
       add      rdx, bword ptr [rcx]
       xor      rcx, rcx
       mov      gword ptr [rdx], rcx
 
G_M000_IG158:                ;; offset=0x10D0
       mov      qword ptr [rdx+0x08], rcx
 
G_M000_IG159:                ;; offset=0x10D4
       mov      rdx, gword ptr [rbx+0x08]
       mov      edx, dword ptr [rdx+0xD8]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG160:                ;; offset=0x10E7
       mov      eax, 1
 
G_M000_IG161:                ;; offset=0x10EC
       add      rsp, 240
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG162:                ;; offset=0x10FE
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryExecuteCasedSplitMember(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG145
 
G_M000_IG163:                ;; offset=0x1112
       mov      rcx, gword ptr [rbx+0x08]
 
G_M000_IG164:                ;; offset=0x1116
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x50], xmm0
 
G_M000_IG165:                ;; offset=0x1121
       xor      edx, edx
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x50]
       mov      r8d, dword ptr [rdi+0x10]
       mov      r9d, dword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures):System.Object]
       mov      rbp, rax
       mov      rcx, gword ptr [rbx+0x08]
       mov      r14, gword ptr [rcx+0x38]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [r14+0x08]
       jae      G_M000_IG224
       mov      r8d, eax
       mov      r14, gword ptr [r14+8*r8+0x10]
       test     rbp, rbp
       jne      G_M000_IG112
 
G_M000_IG166:                ;; offset=0x117B
       mov      rcx, rbp
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveBuiltinReceiverMethod(System.Object,System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      r15, rax
       jmp      G_M000_IG114
 
G_M000_IG167:                ;; offset=0x118F
       mov      rcx, gword ptr [rbx+0x08]
       mov      edx, dword ptr [rcx+0xEC]
       mov      r8, gword ptr [rcx+0x98]
       cmp      edx, dword ptr [r8+0x08]
       jne      G_M000_IG141
 
G_M000_IG168:                ;; offset=0x11AA
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x50], xmm0
 
G_M000_IG169:                ;; offset=0x11B5
       mov      edx, dword ptr [rbx+0x30]
       mov      dword ptr [rsp+0x20], edx
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0xD8]
       mov      qword ptr [rsp+0x30], rdx
       lea      rdx, [rsp+0x50]
       mov      r8d, dword ptr [rbx+0x38]
       mov      r9d, dword ptr [rbx+0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryPrepareIntegerTuple(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG141
       mov      ecx, dword ptr [rbx+0x30]
       add      dword ptr [rbx+0x3C], ecx
       mov      ecx, dword ptr [rsp+0xD8]
       mov      dword ptr [rbx+0x38], ecx
       jmp      G_M000_IG146
 
G_M000_IG170:                ;; offset=0x1202
       mov      ecx, dword ptr [rdi+0x0C]
       add      ecx, 2
       mov      rdx, gword ptr [rbx+0x08]
       cmp      ecx, dword ptr [rdx+0xEC]
       jge      SHORT G_M000_IG173
       mov      rcx, gword ptr [rbx+0x10]
       mov      rcx, gword ptr [rcx+0xA0]
       cmp      qword ptr [rcx+0x158], 8
       jge      SHORT G_M000_IG173
       mov      rcx, rdx
 
G_M000_IG171:                ;; offset=0x122C
       vmovdqu  xmm0, xmmword ptr [rbx+0x48]
       vmovdqu  xmmword ptr [rsp+0x50], xmm0
 
G_M000_IG172:                ;; offset=0x1237
       mov      rdx, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0xE0]
       mov      qword ptr [rsp+0x28], rdx
       lea      rdx, [rsp+0x50]
       mov      r9d, dword ptr [rbx+0x3C]
       lea      r8, bword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateIntegerCallUpdate(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG182
 
G_M000_IG173:                ;; offset=0x1264
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG174
       mov      r8d, edx
       not      r8d
       jmp      SHORT G_M000_IG175
 
G_M000_IG174:                ;; offset=0x1273
       mov      r8d, edx
 
G_M000_IG175:                ;; offset=0x1276
       mov      ecx, dword ptr [rdi+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG179
 
G_M000_IG176:                ;; offset=0x127E
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jb       SHORT G_M000_IG179
 
G_M000_IG177:                ;; offset=0x128E
       test     edx, edx
       jge      SHORT G_M000_IG178
       not      edx
 
G_M000_IG178:                ;; offset=0x1294
       jmp      SHORT G_M000_IG180
 
G_M000_IG179:                ;; offset=0x1296
       mov      edx, dword ptr [rdi+0x14]
 
G_M000_IG180:                ;; offset=0x1299
       cmp      r8d, edx
       jne      G_M000_IG141
 
G_M000_IG181:                ;; offset=0x12A2
       lea      rbp, bword ptr [rbx+0x48]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [rbp+0x08]
       jae      G_M000_IG224
       mov      rcx, bword ptr [rbp]
       mov      eax, eax
       shl      rax, 4
       cmp      gword ptr [rcx+rax], 0
       jne      G_M000_IG145
       jmp      G_M000_IG221
 
G_M000_IG182:                ;; offset=0x12D2
       mov      rdx, gword ptr [rbx+0x08]
       mov      rdx, gword ptr [rdx+0x98]
       mov      r8d, dword ptr [rbx+0x38]
       cmp      r8d, dword ptr [rdx+0x08]
       jae      G_M000_IG224
       shl      r8, 5
       lea      rdx, bword ptr [rdx+r8+0x10]
 
G_M000_IG183:                ;; offset=0x12F4
       vmovdqu  xmm0, xmmword ptr [rsp+0xE0]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG184:                ;; offset=0x1303
       lea      r8, [rsp+0x40]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG145
 
G_M000_IG185:                ;; offset=0x1316
       lea      rcx, bword ptr [rbx+0x48]
       mov      edx, dword ptr [rdi+0x10]
       mov      r8d, dword ptr [rdi+0x08]
       mov      eax, edx
       mov      r10d, r8d
       add      rax, r10
       mov      r10d, dword ptr [rcx+0x08]
       cmp      rax, r10
       ja       G_M000_IG223
       shl      rdx, 4
       add      rdx, bword ptr [rcx]
       mov      bword ptr [rsp+0x50], rdx
       mov      dword ptr [rsp+0x58], r8d
       lea      rcx, [rsp+0x50]
       mov      rdx, gword ptr [rbx+0x10]
       mov      rdx, gword ptr [rdx+0xA0]
       mov      r8, gword ptr [rdi]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReverseAssignmentValues(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.ExecutionState,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG145
 
G_M000_IG186:                ;; offset=0x1365
       lea      rcx, bword ptr [rbx+0x48]
       cmp      ebp, 51
       ja       SHORT G_M000_IG190
 
G_M000_IG187:                ;; offset=0x136E
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rbp
       jb       SHORT G_M000_IG190
 
G_M000_IG188:                ;; offset=0x137E
       mov      ebp, dword ptr [rdi+0x18]
       test     ebp, ebp
       jge      SHORT G_M000_IG189
       not      ebp
 
G_M000_IG189:                ;; offset=0x1387
       jmp      SHORT G_M000_IG191
 
G_M000_IG190:                ;; offset=0x1389
       mov      ebp, dword ptr [rdi+0x14]
 
G_M000_IG191:                ;; offset=0x138C
       cmp      ebp, dword ptr [rcx+0x08]
       jae      G_M000_IG224
       mov      rcx, bword ptr [rcx]
       mov      eax, ebp
       shl      rax, 4
 
G_M000_IG192:                ;; offset=0x139E
       vmovdqu  xmm0, xmmword ptr [rcx+rax]
       vmovdqu  xmmword ptr [rsp+0xC0], xmm0
 
G_M000_IG193:                ;; offset=0x13AC
       cmp      gword ptr [rsp+0xC0], 0
       jne      SHORT G_M000_IG194
       lea      rcx, [rsp+0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9CCFC77C8
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
 
G_M000_IG194:                ;; offset=0x13D8
       lea      rcx, bword ptr [rbx+0x48]
       mov      edx, dword ptr [rdi+0x1C]
       cmp      edx, 51
       ja       SHORT G_M000_IG198
 
G_M000_IG195:                ;; offset=0x13E4
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG198
 
G_M000_IG196:                ;; offset=0x13F4
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG197
       not      edx
 
G_M000_IG197:                ;; offset=0x13FD
       jmp      SHORT G_M000_IG199
 
G_M000_IG198:                ;; offset=0x13FF
       mov      edx, dword ptr [rdi+0x14]
 
G_M000_IG199:                ;; offset=0x1402
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG224
       mov      rcx, bword ptr [rcx]
       mov      edx, edx
       shl      rdx, 4
       xor      eax, eax
       mov      qword ptr [rcx+rdx], rax
       mov      qword ptr [rcx+rdx+0x08], rax
       mov      edx, dword ptr [rdi+0x18]
       test     edx, edx
       jge      SHORT G_M000_IG200
       not      edx
 
G_M000_IG200:                ;; offset=0x1428
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rcx, bword ptr [rbx+0x48]
       mov      r8d, dword ptr [rbx+0x50]
       mov      rdx, gword ptr [rsp+0xC0]
       mov      r9, qword ptr [rsp+0xC8]
       mov      rax, gword ptr [rbx+0x10]
       mov      rax, gword ptr [rax+0xA0]
       mov      r10d, dword ptr [rdi+0x10]
       cmp      r10d, r8d
       jae      G_M000_IG224
       mov      r8d, r10d
       shl      r8, 4
       add      rcx, r8
       mov      gword ptr [rsp+0x40], rdx
       mov      qword ptr [rsp+0x48], r9
       lea      r8, [rsp+0x40]
       mov      rdx, rdi
       mov      r9, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(byref,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG145
 
G_M000_IG201:                ;; offset=0x148B
       mov      rdx, gword ptr [rbx+0x08]
       mov      rbp, gword ptr [rdx+0x30]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rbp+0x08]
       jae      G_M000_IG224
       mov      edx, eax
       mov      rdx, gword ptr [rbp+8*rdx+0x10]
       mov      rcx, rdx
       test     rcx, rcx
       je       SHORT G_M000_IG203
 
G_M000_IG202:                ;; offset=0x14B4
       mov      rax, 0x7FF9CCE1ABA8
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG219
 
G_M000_IG203:                ;; offset=0x14C7
       lea      rdx, bword ptr [rbx+0x48]
       mov      r8d, dword ptr [rdi+0x1C]
       mov      r9d, r8d
       cmp      r9d, 51
       ja       SHORT G_M000_IG207
 
G_M000_IG204:                ;; offset=0x14D8
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, r9
       jb       SHORT G_M000_IG207
 
G_M000_IG205:                ;; offset=0x14E8
       mov      r9d, dword ptr [rdi+0x18]
       test     r9d, r9d
       jge      SHORT G_M000_IG206
       not      r9d
 
G_M000_IG206:                ;; offset=0x14F4
       jmp      SHORT G_M000_IG208
 
G_M000_IG207:                ;; offset=0x14F6
       mov      r9d, dword ptr [rdi+0x14]
 
G_M000_IG208:                ;; offset=0x14FA
       mov      eax, dword ptr [rdi+0x18]
       test     eax, eax
       jge      SHORT G_M000_IG209
       mov      r10d, eax
       not      r10d
       jmp      SHORT G_M000_IG210
 
G_M000_IG209:                ;; offset=0x1509
       mov      r10d, eax
 
G_M000_IG210:                ;; offset=0x150C
       cmp      r8d, 51
       ja       SHORT G_M000_IG215
 
G_M000_IG211:                ;; offset=0x1512
       mov      r11, 0x7FFFFFFFFF9FF
       bt       r11, r8
       jb       SHORT G_M000_IG215
 
G_M000_IG212:                ;; offset=0x1522
       test     eax, eax
       jge      SHORT G_M000_IG213
       mov      r8d, eax
       not      r8d
       jmp      SHORT G_M000_IG214
 
G_M000_IG213:                ;; offset=0x152E
       mov      r8d, eax
 
G_M000_IG214:                ;; offset=0x1531
       jmp      SHORT G_M000_IG216
 
G_M000_IG215:                ;; offset=0x1533
       mov      r8d, dword ptr [rdi+0x14]
 
G_M000_IG216:                ;; offset=0x1537
       sub      r10d, r8d
       mov      r8d, r9d
       mov      eax, r10d
       add      r8, rax
       mov      eax, dword ptr [rdx+0x08]
       cmp      r8, rax
       ja       G_M000_IG223
       mov      r8d, r9d
       shl      r8, 4
       add      r8, bword ptr [rdx]
       mov      bword ptr [rsp+0x50], r8
       mov      dword ptr [rsp+0x58], r10d
       mov      rdx, gword ptr [rdi]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0x50]
       cmp      dword ptr [rdi+0x0C], 0
       setne    r8b
       movzx    r8, r8b
       mov      r9, gword ptr [rbx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      ecx, dword ptr [rdi+0x18]
       test     ecx, ecx
       jge      SHORT G_M000_IG217
       not      ecx
 
G_M000_IG217:                ;; offset=0x158F
       mov      dword ptr [rbx+0x3C], ecx
       jmp      G_M000_IG145
 
G_M000_IG218:                ;; offset=0x1597
       mov      rcx, rbx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Format(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG145
       jmp      G_M000_IG07
 
G_M000_IG219:                ;; offset=0x15B0
       mov      rcx, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG220:                ;; offset=0x15B9
       mov      rdx, rcx
       mov      rcx, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG221:                ;; offset=0x15C5
       mov      rcx, gword ptr [rbx+0x08]
       mov      rbx, gword ptr [rcx+0x68]
       mov      rcx, rdi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      edx, eax
       mov      rcx, rbx
       mov      r11, 0x7FF9CC912028
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rcx, rax
       mov      rdx, gword ptr [rdi]
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG222:                ;; offset=0x15FD
       mov      rcx, rdi
       mov      rdx, 0x18F4A14C1B8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG223:                ;; offset=0x1619
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG224:                ;; offset=0x1620
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
RWD00  	dd	00000EF1h ; case G_M000_IG144
       	dd	00000E8Fh ; case G_M000_IG141
       	dd	00000DF8h ; case G_M000_IG138
       	dd	00000DB3h ; case G_M000_IG137
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000D9Ah ; case G_M000_IG136
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000D81h ; case G_M000_IG135
       	dd	00000D81h ; case G_M000_IG135
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	000010C7h ; case G_M000_IG163
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000C1Eh ; case G_M000_IG111
       	dd	00000AE1h ; case G_M000_IG100
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000A19h ; case G_M000_IG88
       	dd	000009C5h ; case G_M000_IG84
       	dd	00000948h ; case G_M000_IG83
       	dd	0000089Bh ; case G_M000_IG80
       	dd	00000882h ; case G_M000_IG79
       	dd	00000882h ; case G_M000_IG79
       	dd	00000882h ; case G_M000_IG79
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000709h ; case G_M000_IG67
       	dd	00000613h ; case G_M000_IG53
       	dd	000005FAh ; case G_M000_IG52
       	dd	000002FFh ; case G_M000_IG29
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000289h ; case G_M000_IG23
       	dd	00000289h ; case G_M000_IG23
       	dd	0000029Ah ; case G_M000_IG24
       	dd	000006F8h ; case G_M000_IG66
       	dd	0000020Fh ; case G_M000_IG20
       	dd	000000EAh ; case G_M000_IG10
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000F94h ; case G_M000_IG150
       	dd	00000F75h ; case G_M000_IG149
       	dd	00000F75h ; case G_M000_IG149
       	dd	0000009Ch ; case G_M000_IG07
       	dd	0000009Ch ; case G_M000_IG07
       	dd	000000B0h ; case G_M000_IG09
       	dd	0000154Ch ; case G_M000_IG218
       	dd	0000154Ch ; case G_M000_IG218
       	dd	0000154Ch ; case G_M000_IG218
       	dd	0000154Ch ; case G_M000_IG218
       	dd	0000154Ch ; case G_M000_IG218
       	dd	0000009Ch ; case G_M000_IG07
       	dd	00000613h ; case G_M000_IG53
       	dd	00001440h ; case G_M000_IG201
       	dd	0000131Ah ; case G_M000_IG186
       	dd	00001257h ; case G_M000_IG181
       	dd	000012CBh ; case G_M000_IG185
       	dd	000011B7h ; case G_M000_IG170
       	dd	00001144h ; case G_M000_IG167
       	dd	000010B3h ; case G_M000_IG162
       	dd	00000E8Fh ; case G_M000_IG141

; Total bytes of code 5670

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:TryPrepareIntegerTuple(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 13 single block inlinees; 5 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 184
       lea      rbp, [rsp+0xF0]
       xor      eax, eax
       mov      qword ptr [rbp-0x78], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       mov      rbx, rcx
       mov      esi, r8d
       mov      r14d, r9d
       mov      r15d, dword ptr [rbp+0x30]
       mov      rdi, gword ptr [rbp+0x38]
       mov      rcx, bword ptr [rbp+0x40]
 
G_M000_IG02:                ;; offset=0x0044
       mov      r13, bword ptr [rdx]
       mov      r12d, dword ptr [rdx+0x08]
       mov      rax, gword ptr [rbx+0x98]
       cmp      esi, dword ptr [rax+0x08]
       jae      G_M000_IG28
       mov      edx, esi
       shl      rdx, 5
       mov      eax, dword ptr [rax+rdx+0x1C]
       mov      dword ptr [rcx], eax
       mov      rax, gword ptr [rbx+0x98]
       mov      ecx, dword ptr [rcx]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG28
       shl      rcx, 5
       lea      rax, bword ptr [rax+rcx+0x10]
       mov      bword ptr [rbp-0x80], rax
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       cmp      eax, r15d
       jne      G_M000_IG25
 
G_M000_IG03:                ;; offset=0x0098
       mov      rcx, bword ptr [rbp-0x80]
       cmp      r14d, dword ptr [rcx+0x10]
       jne      G_M000_IG25
       mov      ecx, r14d
       mov      eax, r15d
       add      rcx, rax
       mov      eax, r12d
       cmp      rcx, rax
       ja       G_M000_IG27
       mov      ecx, r14d
       shl      rcx, 4
       add      rcx, r13
       mov      bword ptr [rbp-0xB0], rcx
       mov      dword ptr [rbp-0x60], r15d
       xor      eax, eax
       mov      dword ptr [rbp-0x3C], eax
 
G_M000_IG04:                ;; offset=0x00D5
       xor      r14d, r14d
       test     r15d, r15d
       je       G_M000_IG20
 
G_M000_IG05:                ;; offset=0x00E1
       mov      rax, gword ptr [rbx+0x98]
       lea      edx, [rsi+r14]
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG21
       shl      rdx, 5
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x88], rax
       mov      rdx, gword ptr [rax]
       mov      gword ptr [rbp-0x90], rdx
       mov      r8, gword ptr [rdi+0xA0]
       mov      gword ptr [rbp-0x98], r8
       cmp      byte  ptr [r8], r8b
       mov      rcx, r8
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x012D
       mov      rcx, gword ptr [rbp-0x98]
       mov      rdx, gword ptr [rbp-0x90]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG07:                ;; offset=0x0141
       mov      rax, bword ptr [rbp-0x88]
       cmp      dword ptr [rax+0x1C], 46
       je       G_M000_IG18
 
G_M000_IG08:                ;; offset=0x0152
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, r12d
       jae      G_M000_IG21
       mov      edx, eax
       shl      rdx, 4
       add      rdx, r13
       mov      rax, gword ptr [rdx]
       mov      gword ptr [rbp-0xB8], rax
       mov      r8, qword ptr [rdx+0x08]
       mov      qword ptr [rbp-0x68], r8
       mov      rdx, 0x18F4E801CF0
       cmp      rax, gword ptr [rdx]
       je       G_M000_IG16
       test     r8, r8
       jle      SHORT G_M000_IG10
       mov      rdx, rax
       mov      rcx, 0x7FF9CCF28898
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG11
 
G_M000_IG09:                ;; offset=0x01AE
       mov      rax, gword ptr [rbp-0xB8]
 
G_M000_IG10:                ;; offset=0x01B5
       lea      rdx, [rbp-0x50]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG14
 
G_M000_IG11:                ;; offset=0x01C4
       mov      r10, rax
       mov      r8, qword ptr [rbp-0x68]
       lea      r9d, [r8-0x01]
       mov      dword ptr [rbp-0x5C], r9d
       mov      gword ptr [rbp-0xA8], r10
       mov      rdx, gword ptr [r10+0x08]
       mov      rcx, 0x7FF9CC9D2560
       call     CORINFO_HELP_ISINSTANCEOFARRAY
       test     rax, rax
       je       SHORT G_M000_IG13
       xor      ecx, ecx
       mov      qword ptr [rbp-0x50], rcx
 
G_M000_IG12:                ;; offset=0x01F8
       xor      eax, eax
       jmp      SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x01FC
       mov      rcx, gword ptr [rbp-0xA8]
       mov      edx, dword ptr [rbp-0x5C]
       call     [Lokad.Lython.Runtime.PyTuple:WritableValueSlot(int):byref:this]
       mov      rcx, rax
       lea      rdx, [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
 
G_M000_IG14:                ;; offset=0x0219
       test     eax, eax
       mov      rax, gword ptr [rbp-0xB8]
       jne      SHORT G_M000_IG17
 
G_M000_IG15:                ;; offset=0x0224
       xor      ebx, ebx
       jmp      G_M000_IG22
 
G_M000_IG16:                ;; offset=0x022B
       mov      qword ptr [rbp-0x50], r8
 
G_M000_IG17:                ;; offset=0x022F
       mov      r10, r14
       shl      r10, 4
       add      r10, bword ptr [rbp-0xB0]
       mov      bword ptr [rbp-0xC0], r10
       mov      rcx, r10
       mov      rdx, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, bword ptr [rbp-0xC0]
       mov      rcx, qword ptr [rbp-0x68]
       mov      qword ptr [rdx+0x08], rcx
       jmp      SHORT G_M000_IG19
 
G_M000_IG18:                ;; offset=0x0260
       mov      bword ptr [rbp-0x78], r13
       mov      dword ptr [rbp-0x70], r12d
       lea      rdx, [rbp-0x48]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0x78]
       mov      rcx, rbx
       mov      r8, rax
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluatePreparedBinary(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG15
       mov      rax, r14
       shl      rax, 4
       add      rax, bword ptr [rbp-0xB0]
       mov      bword ptr [rbp-0xA0], rax
       mov      r8, qword ptr [rbp-0x48]
       mov      qword ptr [rbp-0x58], r8
       mov      rcx, 0x18F4E801CF0
       mov      rdx, gword ptr [rcx]
       mov      rcx, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, bword ptr [rbp-0xA0]
       mov      rcx, qword ptr [rbp-0x58]
       mov      qword ptr [rdx+0x08], rcx
 
G_M000_IG19:                ;; offset=0x02C9
       inc      r14d
       cmp      r14d, r15d
       jl       G_M000_IG05
 
G_M000_IG20:                ;; offset=0x02D5
       mov      dword ptr [rbp-0x3C], 1
       mov      ebx, 1
       jmp      SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x02E3
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG22:                ;; offset=0x02E9
       cmp      dword ptr [rbp-0x3C], 0
       jne      SHORT G_M000_IG23
       mov      edx, r15d
       add      rdx, rdx
       mov      rcx, bword ptr [rbp-0xB0]
       call     [System.SpanHelpers:ClearWithReferences(byref,nuint)]
 
G_M000_IG23:                ;; offset=0x0302
       mov      eax, ebx
 
G_M000_IG24:                ;; offset=0x0304
       add      rsp, 184
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG25:                ;; offset=0x0318
       xor      eax, eax
 
G_M000_IG26:                ;; offset=0x031A
       add      rsp, 184
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG27:                ;; offset=0x032E
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG28:                ;; offset=0x0335
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG29:                ;; offset=0x033B
       sub      rsp, 40
 
G_M000_IG30:                ;; offset=0x033F
       cmp      dword ptr [rbp-0x3C], 0
       jne      SHORT G_M000_IG31
       mov      edx, dword ptr [rbp-0x60]
       add      rdx, rdx
       mov      rcx, bword ptr [rbp-0xB0]
       call     [System.SpanHelpers:ClearWithReferences(byref,nuint)]
 
G_M000_IG31:                ;; offset=0x0358
       nop      
 
G_M000_IG32:                ;; offset=0x0359
       add      rsp, 40
       ret      
 
; Total bytes of code 862

