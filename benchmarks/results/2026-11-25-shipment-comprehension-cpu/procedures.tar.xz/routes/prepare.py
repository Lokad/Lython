from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
up = lab.with_name('arithmetic-call-cpython-20261125')
prior = lab.with_name('native-call-construction-20261125')
source = lab/'source'
source.mkdir(exist_ok=False)
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=repo)
def write(path,text): path.write_text(text,encoding='utf-8',newline='\n')
identity=read(up/'external/identity.json')
base=git('rev-parse','HEAD').decode().strip()
assert git('diff','--name-only',identity['sourceRevision'],base,'--','src','tests','benchmarks/Lokad.Lython.Benchmarks')==b''
archive=lab/'source.zip'
git('archive','--format=zip','--output',str(archive),base,'--','src','Directory.Build.props','Directory.Build.targets',
    'Directory.Build.rsp','Directory.Packages.props','global.json','NuGet.Config')
with zipfile.ZipFile(archive) as z:
    assert all(not Path(name).is_absolute() and '..' not in Path(name).parts for name in z.namelist())
    z.extractall(source)

files={}
def patch(name,left,right):
    path=source/'src/Lokad.Lython/Runtime'/name
    old=files.setdefault(name, path.read_text(encoding='utf-8'))
    s=path.read_text(encoding='utf-8')
    assert s.count(left)==1,(name,left,s.count(left))
    write(path,s.replace(left,right))

name='LythonRuntime.Comprehensions.cs'
patch(name,'        private InlinedComprehensionScope? _inlinedComprehension;', '''        private InlinedComprehensionScope? _inlinedComprehension;
        internal static int DiagnosticComprehensionEntries;
        internal static int DiagnosticComprehensionExits;
        internal static int DiagnosticComprehensionReads;
        internal static int DiagnosticComprehensionWrites;
        internal static int DiagnosticComprehensionAppends;''')
patch(name,'                _context = context;', '                Interlocked.Increment(ref DiagnosticComprehensionEntries);\n                _context = context;')
patch(name,'                _context._inlinedComprehension = Previous;', '                Interlocked.Increment(ref DiagnosticComprehensionExits);\n                _context._inlinedComprehension = Previous;')
name='LythonRuntime.Resolution.cs'
patch(name,'            if (binding.Frame.TryGetVariable(name, out var bound)) return bound;',
    '            Interlocked.Increment(ref ExecutionContext.DiagnosticComprehensionReads);\n            if (binding.Frame.TryGetVariable(name, out var bound)) return bound;')
patch(name,'        if (context.TryGetInlinedBinding(name, out var binding)) return binding;',
    '''        if (context.TryGetInlinedBinding(name, out var binding))
        {
            Interlocked.Increment(ref ExecutionContext.DiagnosticComprehensionWrites);
            return binding;
        }''')
name='LythonRuntime.Executable.PreparedOperations.cs'
patch(name,'                    if (!append.Unpacking) Add(value);',
    '''                    if (!append.Unpacking)
                    {
                        if (append.IteratorDepth != 0 && destination is PyList)
                            Interlocked.Increment(ref DiagnosticComprehensionAppends);
                        Add(value);
                    }''')
name='PyExecutableFunction.cs'
patch(name,'    private readonly LythonRuntime.ExecutableCaptures _closureCells;',
    '''    internal static readonly System.Collections.Concurrent.ConcurrentDictionary<string,int> DiagnosticTransfers = new();
    private readonly LythonRuntime.ExecutableCaptures _closureCells;''')
patch(name,'            state.PrepareTransfer();',
    '''            var stop = state.Index < CodeObject.Instructions.Length ? CodeObject.Instructions[state.Index].OpCode.ToString() : "end";
            if (stop == "ApplyOperation")
                stop = CodeObject.Constants[CodeObject.Instructions[state.Index].ConstantIndex]!.GetType().Name;
            var reason = Name + "/" + stop + (existing is null ? "/rent" : "/borrow");
            DiagnosticTransfers.AddOrUpdate(reason, 1, static (_, count) => count + 1);
            state.PrepareTransfer();''')

from difflib import unified_diff
out=[]
for name,old in files.items():
    name_in_git='src/Lokad.Lython/Runtime/'+name
    new=(source/name_in_git).read_text(encoding='utf-8')
    out.extend(unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),'a/'+name_in_git,'b/'+name_in_git))
write(lab/'diagnostic.patch',''.join(out))
frozen=identity['imageFiles']['candidate']
assert len(frozen)==32 and {p.name:sha(p) for p in (up/'candidate').iterdir()}==frozen
image=lab/'image'
image.mkdir(exist_ok=False)
for name in frozen: shutil.copyfile(up/'candidate'/name,image/name)
shutil.copyfile(prior/'RouteProbe.csproj',lab/'RouteProbe.csproj')
s=(prior/'Program.cs').read_text(encoding='utf-8')
a=s.index('string[] names')
b=s.index('foreach (var item',a)
s=s[:a]+'''string[] names = ["ComprehensionEntries", "ComprehensionExits", "ComprehensionReads", "ComprehensionWrites", "ComprehensionAppends"];
var runtime = typeof(LythonEngine).Assembly.GetType("Lokad.Lython.Runtime.LythonRuntime+ExecutionContext", true)!;
var fields = names.Select(name => runtime.GetField("Diagnostic" + name, all)!).ToArray();
var function = typeof(LythonEngine).Assembly.GetType("Lokad.Lython.Runtime.PyExecutableFunction", true)!;
var transfers = (System.Collections.Concurrent.ConcurrentDictionary<string,int>)function.GetField("DiagnosticTransfers", all)!.GetValue(null)!;
'''+s[b:]
s=s.replace('        foreach (var field in fields)', '        transfers.Clear();\n        foreach (var field in fields)')
s=s.replace('            peakExecutionMemoryBytes, allowanceReturned', '            transfers = transfers.OrderBy(pair => pair.Key).ToDictionary(), peakExecutionMemoryBytes, allowanceReturned')
write(lab/'Program.cs',s)
catalog=read(up/'external/representative.json')
ship,=[case for case in catalog['cases'] if case['id']=='diagnostic.shipment-routing-callbacks']
controls=read(lab.with_name('direct-record-cpython-20261125')/'external/representative.json')
filefed,=[case for case in controls['cases'] if case['id']=='diagnostic.shipment-file-fed-map']
catalog['cases']=[case | {'runAsync':mode} for case in (ship,filefed) for mode in (False,True)]
write(lab/'cases.json',json.dumps(catalog,ensure_ascii=False))
write(lab/'identity.json',json.dumps(dict(source=base,referenceFiles=frozen,patchSHA256=sha(lab/'diagnostic.patch'),
    catalogSHA256=sha(lab/'cases.json')),indent=2)+'\n')
