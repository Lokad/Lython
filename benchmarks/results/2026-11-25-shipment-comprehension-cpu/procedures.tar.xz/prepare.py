from pathlib import Path
import hashlib, json, os, shutil, subprocess, tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
template=lab.with_name('default-effects-cpu-20261125')
up=lab.with_name('arithmetic-call-cpython-20261125')
q=up/'external'
read=lambda p: json.loads(p.read_text(encoding='utf-8'))
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def write(path,text): path.write_text(text,encoding='utf-8',newline='\n')
def save(path,value): write(path,json.dumps(value,indent=2)+'\n')

old=read(q/'identity.json')
receipt=read(q/'terminal-status.json')['receipt']
assert receipt['complete'] and sha(q/'observations.tar.xz')==receipt['archiveSHA256']
source=old['sourceRevision']
assert source.startswith('a420c3e05')
assert subprocess.check_output(['git','diff','--name-only',source,'HEAD','--','src','tests',
    'benchmarks/Lokad.Lython.Benchmarks','benchmarks/cpython-worker.py'],cwd=repo)==b''
files=old['imageFiles']['candidate']
assert len(files)==32 and {x.name:sha(x) for x in (up/'candidate').iterdir()}==files
shutil.copyfile(q/'representative.json',lab/'catalog.json')
shutil.copyfile(q/'candidate-verify.json',lab/'candidate-verification.json')
checked=read(lab/'candidate-verification.json')
assert checked['state']=='Completed' and checked['caseCount']==2 and checked['catalogSha256']==sha(lab/'catalog.json')
assert checked['launched']['library']['sha256']==files['Lokad.Lython.dll']
case_id='diagnostic.shipment-routing-callbacks'
assert sum(case['id']==case_id for case in read(lab/'catalog.json')['cases'])==1
profiles=[[label,case_id,'candidate'] for label in ('shipment-warm','shipment-async')]
save(lab/'identity.json',dict(sourceRevision=source,measurementReference=source,imageFiles={'candidate':files},
    coreSHA256={'candidate':files['Lokad.Lython.dll']},cpythonWorkerSHA256=old['cpythonWorkerSHA256'],
    profiles=profiles,purpose='Attribute shipment comprehension, fixed unpack and per-record work',
    donorArchiveSHA256=receipt['archiveSHA256'],profileCatalogSHA256=sha(lab/'catalog.json')))
for name in ('collect.py','quiet.py','ops-profile.py','analyze.py','find-archived-duplicates.py','run.sh'):
 s=(template/name).read_text(encoding='utf-8')
 s=s.replace('ordinary-definition-effects-b1728-20261125','arithmetic-call-cpython-b1731c-20261125')
 s=s.replace('ordinary-definition-effects-20261125','arithmetic-call-cpython-20261125')
 s=s.replace('default-effects-cpu-b1729-20261125','shipment-comprehension-cpu-b1732-20261125')
 s=s.replace('lython-b1729-default-effects-cpu','lython-b1732-shipment-comprehension-cpu')
 s=s.replace('b1729-fixtures','b1732-fixtures').replace('Staged definition and effects profiles','Staged two shipment profiles')
 if name.endswith('.py'): compile(s,name,'exec')
 write(lab/name,s)
assert b'\r' not in (lab/'run.sh').read_bytes()
