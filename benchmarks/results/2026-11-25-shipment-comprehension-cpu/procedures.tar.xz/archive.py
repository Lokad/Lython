from pathlib import Path
import hashlib, json, shutil, tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
out=repo/'benchmarks/results/2026-11-25-shipment-comprehension-cpu'
routes=lab.with_name('shipment-comprehension-routes-20261125')
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=read(lab/'identity.json')
terminal=read(lab/'terminal-status.json')
receipt=terminal['receipt']
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode']=='0'
assert all(receipt[k] for k in ('complete','quietBeforeAndAfter','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
assert sha(lab/'observations.tar.xz')==receipt['archiveSHA256']
a=read(lab/'attribution.json')
assert [(row['label'],row['case'],row['role'])for row in a['rows']]==list(map(tuple,identity['profiles']))
for row in a['rows']:
    record=read(lab/'retrieved/profiles'/row['label']/'record.json')
    assert record['verificationBefore']['status']==record['verificationAfter']['status']=='Equivalent'
    assert record['warmupSeconds']>=8 and record['closed']['status']=='Closed'
r=read(routes/'routes.json')
assert read(routes/'identity.json')['referenceFiles']==identity['imageFiles']['candidate']
for row in r['rows']:
    assert row['allowanceReturned']
    if row['id']==identity['profiles'][0][1]:
        assert row['routes']['ComprehensionEntries']==row['routes']['ComprehensionExits']==32
        assert all(row['routes'][key]==4096 for key in ('ComprehensionReads','ComprehensionWrites','ComprehensionAppends'))
        assert row['transfers']=={'report_shipments/Call/rent':1,'tally/UnpackValues/borrow':16}
    else:
        assert not any(row['routes'].values()) and not row['transfers']
assert sha(routes/'diagnostic.patch')==read(routes/'identity.json')['patchSHA256']
out.mkdir(exist_ok=True)
for f in ('identity.json','terminal-status.json','observations.tar.xz','attribution.json'):
    shutil.copyfile(lab/f,out/f)
shutil.copyfile(routes/'routes.json',out/'routes.json')
with tarfile.open(out/'procedures.tar.xz','w:xz') as bundle:
    for f in ('archive.py','prepare.py','collect.py','ops-profile.py','quiet.py','run.sh','analyze.py',
              'candidate-verification.json','verified-raw-replicas.json','launch.log','retrieve.log','analyze.log',
              'find-archived-duplicates.py','archived-duplicates.json','check-replicas.py','inventory.log','initial-inventory.log'):
        bundle.add(lab/f,arcname=f,recursive=False)
    for f in ('prepare.py','identity.json','diagnostic.patch','Program.cs','RouteProbe.csproj','core-build.log','probe-build.log','cases.json'):
        bundle.add(routes/f,arcname='routes/'+f,recursive=False)
