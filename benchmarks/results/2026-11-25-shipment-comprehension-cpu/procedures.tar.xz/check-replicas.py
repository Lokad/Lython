from pathlib import Path
import hashlib,json,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
out=[]
for item in json.loads((lab/'archived-duplicates.json').read_text(encoding='utf-8')):
    archive=repo/item['path']
    assert hashlib.sha256(archive.read_bytes()).hexdigest()==item['sha']
    with tarfile.open(archive) as bundle:
        raw=bundle.extractfile('confirmation/confirmation.json').read()
    assert len(raw)==item['rawBytes']
    out.append(dict(location=item['run'],archiveSHA256=item['sha'],bytes=len(raw),rawSHA256=hashlib.sha256(raw).hexdigest()))
(lab/'verified-raw-replicas.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8',newline='\n')
