from hashlib import sha256
from pathlib import Path
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
notes=lab.parent
repo=lab.parents[3]
baseline=notes/'generator-resume-protocol-20261127/comparison'
donor=notes/'quiet-generator-outer-20261127/comparison/quiet'
old=notes/'current-cpython-checkpoint-20261127/comparison/quiet'
quiet=lab/'comparison/quiet'
quiet.mkdir(parents=True)
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()

def write(p,v):
    p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')

prepared=read(lab/'identity.json')
current=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert not subprocess.check_output(['git','diff',prepared['sourceRevision'],current,'--','src'],cwd=repo)
candidate=baseline/'candidate'
files=prepared['imageFiles']
assert len(files)==32 and {p.name:digest(p) for p in candidate.iterdir()}==files
baseline_id=read(baseline/'identity.json')
patch = subprocess.check_output(['git','diff','--binary',baseline_id['sourceRevision'],prepared['sourceRevision'],'--','src'],cwd=repo)
assert sha256(patch).hexdigest() == baseline_id['sourcePatchSHA256']
assert digest(lab/'representative.json')==prepared['catalogSHA256']
assert digest(lab/'jobs.json')==prepared['jobsSHA256']
assert digest(lab/'cpython-worker.py')==prepared['cpythonWorkerSHA256']
proof=read(lab/'local-verify.json')
assert proof['caseCount']==4 and proof['state']=='Completed'
assert proof['catalogSha256']==prepared['catalogSHA256']
assert proof['launched']['library']['sha256']==files['Lokad.Lython.dll']
assert proof['launched']['adapter']['sha256']==files['Lokad.Lython.Benchmarks.dll']

for name in ('representative.json','cpython-worker.py'):
    shutil.copyfile(lab/name,quiet/name)
shutil.copyfile(old/'run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
selection=read(lab/'jobs.json')
# Same command measures warm execution as well as the other two boundaries.
configuration=selection['shortCommand'][0][0]
jobs=selection['warm'] + [[configuration,'warm']] + selection['shortCommand']
write(quiet/'jobs.json',jobs)
receipt=read(donor/'archive-receipt.json')
assert receipt['complete'] and receipt['quietBeforeAndAfter'] and receipt['allWorkersJoined']
assert receipt['archiveSHA256']==digest(donor/'observations.tar.xz')
donor_files=read(donor/'identity.json')['imageFiles']['candidate']
assert [name for name,d in files.items() if d!=donor_files[name]]==['Lokad.Lython.dll']
stage_name='script-cpython-quiet-b1896-20261127'

identity=dict(sourceRevision=prepared['sourceRevision'],productionHead=current,
    purpose='Quiet current-revision CPython check of iterable shipment, nested JSON, file-fed map and short configuration edit.',
    imageFiles={'candidate':files},coreSHA256={label:files['Lokad.Lython.dll'] for label in ('candidate','candidate-control')},
    auxiliaryFiles={name:d for name,d in files.items() if name!='Lokad.Lython.dll'},
    frozenImage='/home/lokad/lython-bench-checks/'+stage_name+'/candidate',
    catalogs={name:{'sha256':digest(quiet/name)} for name in ('jobs.json','representative.json')},
    expectedCPythonSHA256=prepared['expectedCPythonSHA256'],cpythonWorkerSHA256=prepared['cpythonWorkerSHA256'],
    donorArchiveSHA256=receipt['archiveSHA256'])
write(quiet/'identity.json',identity)
collector=(old/'collect.py').read_text(encoding='utf-8')
collector=collector.replace('lython-b1834-fixtures','lython-b1896-cpython-fixtures')
collector=collector.replace('len(jobs) == 8','len(jobs) == 6')
collector=collector.replace('math.ceil(counts[w.label,lane]*.46','math.ceil(counts[w.label,lane]*.60')
collector=collector.replace("        self.diagnostic = label.endswith(\"-phases\")\n","")
collector=collector.replace('label.removesuffix("-phases")', 'label')
collector=collector.replace("root/('python-phases.py' if self.diagnostic else 'cpython-worker.py')", "root/'cpython-worker.py'")
collector=collector.replace('jobs=[],diagnosticOverheadNotCorrected=True','jobs=[]')
collector=collector.replace('        diagnostic = False\n','')
collector=collector.replace("labels=['CPython-phases']if diagnostic else ", "labels=")
collector=collector.replace(',diagnostic=diagnostic,',',')
collector=collector.replace("    time.sleep(12)", "    time.sleep(20)")
assert 'len(jobs) == 6' in collector and 'phases.py' not in collector
compile(collector,'collect.py','exec')
(quiet/'collect.py').write_text(collector,encoding='utf-8',newline='\n')

payload_files={name:quiet/name for name in ('identity.json','representative.json','jobs.json','cpython-worker.py','run.sh','collect.py')}
payload_files['candidate/Lokad.Lython.dll']=candidate/'Lokad.Lython.dll'
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz') as archive:
    for name,p in payload_files.items():
        archive.add(p,arcname=name)
manifest={name:dict(length=p.stat().st_size,sha256=digest(p)) for name,p in payload_files.items()}
write(quiet/'upload.json',dict(root=stage_name,donor=read(donor/'upload.json')['root'],donorFiles=donor_files,
    donorArchive=receipt['archiveSHA256'],payloadSHA256=digest(payload),files=manifest,
    expandedBytes=sum(item['length'] for item in manifest.values()),minimumAfterStageBytes=12*1024*1024))

s=(notes/'quiet-generator-outer-20261127/quiet-vm.py').read_text(encoding='utf-8')
s=s.replace("unit='lython-b1895-generator-outer-quiet'","unit='lython-b1896-current-cpython'")
s=s.replace(" for role in ('reference','candidate'):\n  (root/role).mkdir()"," (root/'candidate').mkdir()")
s=s.replace(" reused={'donor':0,'paired':0}\n for role in ('candidate','reference'):",
            " reused={'donor':0}\n for role in ('candidate',):")
lo=s.index("   if cfg['donorFiles'][name]==digest:")
hi=s.index("  assert {p.name",lo)
s=s[:lo]+"""   assert cfg['donorFiles'][name]==digest
   os.link(origin/name,target/name)
   reused['donor']+=1
"""+s[hi:]
s=s.replace('RuntimeMaxSec=250','RuntimeMaxSec=355')
s=s.replace("'observations.tar.xz','reference-remote-verify.json','candidate-remote-verify.json','stage-custody.json'",
            "'observations.tar.xz','candidate-remote-verify.json','stage-custody.json'")
compile(s,'quiet-vm.py','exec')
(lab/'quiet-vm.py').write_text(s,encoding='utf-8',newline='\n')
print('Frozen source',prepared['sourceRevision'],'rows',len(jobs),'staged bytes',sum(item['length'] for item in manifest.values()))
