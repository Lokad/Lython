from pathlib import Path
from hashlib import sha256
import json
import tarfile
import shutil

lab = Path(__file__).resolve().parent
profile = lab / "profile"
target = lab.parents[3] / "benchmarks/results/2026-11-27-current-quiet-cpython"
read = lambda path: json.loads(path.read_text(encoding="utf-8"))
digest = lambda data: sha256(data).hexdigest()
summary = read(profile / "run-summary.json")
identity = read(profile / "identity.json")
proof = read(lab / "verification.json")
cases = {case["id"]: case for case in read(lab / "representative.json")["cases"]}
assert summary["sourceRevision"] == read(target / "summary.json")["source"]
assert proof["state"] == "Completed" and proof["caseCount"] == len(cases) == 4
assert proof["catalogSha256"] == summary["catalogSha"] == identity["catalogs"]["representative.json"]["sha256"]
for name, sha in identity["imageFiles"]["candidate"].items():
    assert digest((lab / "candidate" / name).read_bytes()) == sha

entries = [lab / name for name in ["archive-profile.py", "profile-entry.sh", "verification.json"]]
entries += [profile / name for name in ["run-summary.json", "identity.json", "run.sh", "analyze.py", "collect.py", "collection.log", "attribution.json"]]
count = 0
for record_path in sorted(profile.glob("*/record.json")):
    record = read(record_path)
    case = cases[record["workload"]]
    assert record["allProcessesJoined"]
    assert record["closed"]["status"] == "Closed"
    assert record["coreSha"] == identity["imageFiles"]["candidate"]["Lokad.Lython.dll"]
    assert digest(record_path.with_name("run.nettrace").read_bytes()) == record["nettraceSha"]
    for batch in [record["before"], record["after"], *record["batches"]]:
        timing = batch is not record["before"] and batch is not record["after"]
        assert batch["status"] == ("Completed" if timing else "Equivalent")
        assert all(batch[k] == case[k] for k in ["sourceSha256", "fixtureSha256", "expectedOutputSha256"])
        assert batch.get("actualOutputSha256") == (None if timing and record["lane"] == "compile" else case["expectedOutputSha256"])
        assert batch.get("actualFilesSha256") == (None if timing and record["lane"] == "compile" else case.get("expectedFilesSha256"))
    count += len(record["batches"])
    entries.extend(record_path.with_name(name) for name in ["record.json", "run.nettrace", "capture.log", "worker.stderr"])
assert count == summary["totalVerifiedBatches"] == 764
archive = target / "profile-observations.tar.xz"
with tarfile.open(archive, "w:xz", preset=3) as bundle:
    for path in entries:
        bundle.add(path, arcname=path.relative_to(lab))
with tarfile.open(archive) as bundle:
    for path in entries:
        assert bundle.extractfile(path.relative_to(lab).as_posix()).read() == path.read_bytes()
shutil.copyfile(profile / "attribution.json", target / "profile-attribution.json")
(target / "profile-archive-receipt.json").write_text(json.dumps(dict(sha256=digest(archive.read_bytes()), files=len(entries), verifiedBatches=count), indent=2) + "\n", encoding="utf-8")
print(count, "verified profile batches", archive.stat().st_size, "archived bytes")
