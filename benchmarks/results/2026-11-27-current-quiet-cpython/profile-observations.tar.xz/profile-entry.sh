#!/bin/bash
set -euo pipefail
root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
export DOTNET_ROOT="$HOME/.dotnet"
python=/mnt/d/code/Lython/.git/agent-notes/review-20261031/bench-cpython-3.13.16-runtime/runtime/bin/python3.13
"$DOTNET_ROOT/dotnet" "$root/candidate/Lokad.Lython.Benchmarks.dll" --compare verify --catalog "$root/representative.json" --dotnet "$DOTNET_ROOT/dotnet" --python "$python" --python-worker "$root/cpython-worker.py" --out "$root/verification.json"
bash "$root/profile/run.sh"
python3 "$root/profile/analyze.py"
