from base64 import b64decode
from hashlib import sha256
from pathlib import Path
from statistics import median
import json
import os
import shutil
import subprocess
import tempfile

lab=Path(__file__).resolve().parent
notes=lab.parent
repo=lab.parents[3]
prior=notes/'pattern-one-shot-20261127'
comparison=lab/'comparison/local'
allocation=lab/'allocation'
comparison.mkdir(parents=True)
allocation.mkdir()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
write=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
sha=lambda p:sha256(p.read_bytes()).hexdigest()
image=lambda path:{p.name:sha(p) for p in path.iterdir()}
core='Lokad.Lython.dll'
worker='Lokad.Lython.Benchmarks.dll'
pinned=read(repo/'benchmarks/results/2026-11-27-pattern-one-shot/identity.json')
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert base.startswith('b6268d329')
assert subprocess.check_output(['git','diff','--binary','b285b0bcd','d887f04c5','--','src'],cwd=repo)==(prior/'local/candidate.patch').read_bytes()
assert not subprocess.check_output(['git','diff','d887f04c5','HEAD','--','src','benchmarks/Lokad.Lython.Benchmarks'],cwd=repo)
patch=subprocess.check_output(['git','diff','--binary','HEAD','--','src'],cwd=repo)
assert b'InvokeIterableRowAsync' in patch and patch.count(b'diff --git ')==3
(lab/'candidate.patch').write_bytes(patch)
orig=prior/'local/candidate'
assert image(orig)==pinned['imageFiles']['candidate']
for role in ('reference','candidate'):
    shutil.copytree(orig,comparison/role)
new=repo/'tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0'
assert sha(new/core)==sha(repo/'src/Lokad.Lython/bin/Release/net11.0'/core)
shutil.copyfile(new/core,comparison/'candidate'/core)
images={role:image(comparison/role) for role in ('reference','candidate')}
assert [name for name,digest in images['reference'].items() if images['candidate'][name]!=digest]==[core]

catalog=read(notes/'async-frame-driver-20261127/comparison/quiet/representative.json')
wide='diagnostic.shipment-starmap-wide-lists'
map_case='diagnostic.shipment-file-fed-map'
target='diagnostic.shipment-starmap-iterable-rows'
cases={case['id']:case for case in catalog['cases']}
row_case=cases[map_case].copy()
row_case['id']=target
row_case['source']=('''import csv
from itertools import starmap

def arguments(record):
    yield int(record['quantity'])
    yield record['late'] == 'yes'
    yield record['hold'] == 'yes'
    yield 2 if record['hold'] == 'yes' else 1

def cost(quantity, late, held, multiplier):
    return quantity * multiplier + (3 if late else 0) + (5 if held else 0)

with open('shipments.csv', encoding='utf-8', newline='') as source:
    print(sum(starmap(cost, (arguments(record) for record in csv.DictReader(source)))))
''')
source_bytes=row_case['source'].encode('utf-8')
fixture=json.loads(row_case['fixtureJson'])
assert fixture['size']==2048 and fixture['text'] is None and len(fixture['inputFiles'])==1
python=Path('C:/Python313/python.exe')
with tempfile.TemporaryDirectory(prefix='lython-b1864-goldens-') as location:
    folder=Path(location)
    (folder/'shipment.py').write_bytes(source_bytes)
    for name,content in fixture['inputFiles'].items():
        assert name=='shipments.csv'
        (folder/name).write_bytes(b64decode(content))
    expected=subprocess.check_output([python,'-I','-X','utf8',folder/'shipment.py'],cwd=folder,timeout=15)
    assert len(list(folder.iterdir()))==2
    assert all((folder/name).read_bytes()==b64decode(content) for name,content in fixture['inputFiles'].items())
row_case.update(sourceUtf8Bytes=len(source_bytes),sourceSha256=sha256(source_bytes).hexdigest(),
                expectedOutput=expected.decode('utf-8').replace('\r\n','\n'))
golden=row_case['expectedOutput'].encode('utf-8')
row_case.update(expectedOutputUtf8Bytes=len(golden),expectedOutputSha256=sha256(golden).hexdigest())
print('CPython output',repr(row_case['expectedOutput']),flush=True)
catalog['cases']=[row_case,cases[wide],cases[map_case]]
write(comparison/'representative.json',catalog)
write(comparison/'jobs.json',{'warm':[[target,'warm'],[wide,'warm'],[target,'warm-async'],[map_case,'warm-async']]})
for name in ('cpython-worker.py','run.sh'):
    shutil.copyfile(prior/'comparison/quiet'/name,comparison/name)
assert b'\r' not in (comparison/'run.sh').read_bytes()
collector=(notes/'converted-entry-20261127/confirm/local/collect.py').read_text(encoding='utf-8')
collector=collector.replace('len(jobs) == 3','len(jobs) == 4').replace('lython-converted-entry-fixture-','lython-b1864-starmap-fixture-')
compile(collector,'collect.py','exec')
(comparison/'collect.py').write_text(collector,encoding='utf-8',newline='\n')
identity=dict(sourceRevision=base,sourcePatchSHA256=sha(lab/'candidate.patch'),
    productionReference='d887f04c5',imageFiles=images,
    coreSHA256={role+suffix:files[core] for role,files in images.items() for suffix in ('','-control')},
    catalogs={name:{'sha256':sha(comparison/name)} for name in ('representative.json','jobs.json')},
    comparisonHostRevision=pinned['comparisonHostRevision'],cpythonWorkerSHA256=sha(comparison/'cpython-worker.py'),
    independentCPythonVersion=subprocess.check_output([python,'--version'],text=True).strip(),
    verificationPythonSHA256=sha(python),
    purpose='Compare one argument buffer for generic starmap rows in both APIs with exact-row and file-fed controls.')
write(comparison/'identity.json',identity)
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
for role,files in images.items():
    report=comparison/f'{role}-verify.json'
    subprocess.run([dotnet,comparison/role/worker,'--compare','verify','--catalog',comparison/'representative.json',
       '--dotnet',dotnet,'--python',python,'--python-worker',comparison/'cpython-worker.py','--out',report],env=env,check=True,timeout=65)
    proof=read(report)
    assert proof['state']=='Completed' and proof['caseCount']==3
    assert proof['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert proof['launched']['adapter']['sha256']==files[worker] and proof['launched']['library']['sha256']==files[core]
    folder=allocation/role
    shutil.copytree(comparison/role,folder)
    for path in (prior/'local/candidate-allocated').glob('ValidatedAllocation*'):
        shutil.copyfile(path,folder/path.name)
    assert all(sha(folder/name)==digest for name,digest in files.items())

rows=[]
for mode in ('sync','async'):
    for case in catalog['cases']:case['runAsync']=mode=='async'
    selection=allocation/f'{mode}-catalog.json'
    write(selection,catalog)
    pair=[]
    for role in images:
        folder=allocation/role
        report=allocation/f'{role}-{mode}.json'
        subprocess.run([dotnet,folder/'ValidatedAllocation.dll',folder,selection,report],env=env,check=True,timeout=75)
        pair.append(read(report)['rows'])
    for before,after in zip(*pair,strict=True):
        assert before['id']==after['id'] and before['sharedBudgetBaselineRestored'] and after['sharedBudgetBaselineRestored']
        row=dict(case=before['id'],mode=mode,clr=[median(r['allocatedBytesPerInvocation']) for r in (before,after)],
                 peak=[r['peakExecutionMemoryBytes'] for r in (before,after)],
                 compiled=[r['compiledReservedBytes'] for r in (before,after)])
        rows.append(row)
        print(row,flush=True)
write(allocation/'summary.json',rows)

