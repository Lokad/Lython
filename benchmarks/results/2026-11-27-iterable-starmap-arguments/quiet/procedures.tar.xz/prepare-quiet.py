from hashlib import sha256
from pathlib import Path
import json
import os
import shlex
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
notes=lab.parent
repo=lab.parents[3]
local=lab/'comparison/local'
quiet=lab/'comparison/quiet'
quiet.mkdir()
prior=notes/'pattern-one-shot-20261127'
old=notes/'async-frame-driver-20261127'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
write=lambda p,v:p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
sha=lambda p:sha256(p.read_bytes()).hexdigest()
base=read(local/'identity.json')
donor=read(prior/'comparison/quiet/identity.json')
receipt=read(prior/'comparison/quiet/terminal-status.json')['receipt']
assert base['imageFiles']['reference']==donor['imageFiles']['candidate']
assert receipt['complete'] and receipt['archiveSHA256']==sha(prior/'comparison/quiet/observations.tar.xz')
for role,expected in base['imageFiles'].items():
    assert {p.name:sha(p) for p in (local/role).iterdir()}==expected
for name in ('representative.json','cpython-worker.py','run.sh'):
    shutil.copyfile(local/name,quiet/name)
jobs=list(reversed(read(local/'jobs.json')['warm']))
write(quiet/'jobs.json',{'warm':jobs})
identity=base|dict(
    expectedCPythonSHA256=donor['expectedCPythonSHA256'],
    donorArchiveSHA256=receipt['archiveSHA256'],
    priorLocalArchiveSHA256=sha(local/'observations.tar.xz'),
    catalogs={name:{'sha256':sha(quiet/name)} for name in ('representative.json','jobs.json')},
    purpose='Quiet reverse-order confirmation of B1864 on the exact local source pair.')
write(quiet/'identity.json',identity)
assert sha(quiet/'representative.json')==base['catalogs']['representative.json']['sha256']
assert sha(quiet/'cpython-worker.py')==identity['cpythonWorkerSHA256']
assert b'\r' not in (quiet/'run.sh').read_bytes()
collector=(prior/'comparison/quiet/collect.py').read_text(encoding='utf-8')
collector=collector.replace('len(jobs) == 5','len(jobs) == 4').replace('lython-b1862-fixtures','lython-b1864-fixtures')
compile(collector,'collect.py','exec')
(quiet/'collect.py').write_text(collector,encoding='utf-8',newline='\n')
host=(prior/'quiet-vm.py').read_text(encoding='utf-8')
host=host.replace('lython-b1862-pattern-one-shot-20261127','lython-b1864-iterable-starmap-confirm-20261127')
host=host.replace("name in ('Lokad.Lython.dll','Lokad.Lython.Utf8Regex.dll')","name=='Lokad.Lython.dll'")
host=host.replace("proof['caseCount']==5","proof['caseCount']==3")
host=host.replace('RuntimeMaxSec=255','RuntimeMaxSec=215')
compile(host,'quiet-vm.py','exec')
(lab/'quiet-vm.py').write_text(host,encoding='utf-8',newline='\n')
shutil.copyfile(old/'summarize-quiet.py',lab/'summarize-quiet.py')

(quiet/'candidate').mkdir()
core='Lokad.Lython.dll'
shutil.copyfile(local/'candidate'/core,quiet/'candidate'/core)
names=['identity.json','representative.json','jobs.json','cpython-worker.py','run.sh','collect.py',f'candidate/{core}']
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz') as archive:
    for name in names: archive.add(quiet/name,arcname=name)
manifest={name:dict(length=(quiet/name).stat().st_size,sha256=sha(quiet/name)) for name in names}
expanded=sum(row['length'] for row in manifest.values())
floor=expanded+6*1024*1024+400000
write(quiet/'upload.json',dict(root='iterable-starmap-confirm-b1864-20261127',
    donor=read(prior/'comparison/quiet/upload.json')['root'],donorFiles=identity['imageFiles']['reference'],
    donorArchive=identity['donorArchiveSHA256'],payloadSHA256=sha(payload),files=manifest,
    expandedBytes=expanded,minimumAfterStageBytes=6*1024*1024))

# The two older remote names are aliases of one backed-up worker file.
# All 32 original candidate files still exist in immutable local storage.
old_pin=read(repo/'benchmarks/results/2026-11-27-async-frame-driver/identity.json')
repeat_pin=read(repo/'benchmarks/results/2026-11-27-async-frame-driver-repeat/identity.json')
assert old_pin['imageFiles']==repeat_pin['imageFiles']
stored=old/'local/candidate'
assert {p.name:sha(p) for p in stored.iterdir()}==old_pin['imageFiles']['candidate']
old_digest=old_pin['imageFiles']['candidate'][core]
archive_paths={
    'async-frame-driver-b1854-20261127':repo/'benchmarks/results/2026-11-27-async-frame-driver/observations.tar.xz',
    'async-frame-driver-repeat-b1863-20261127':repo/'benchmarks/results/2026-11-27-async-frame-driver-repeat/observations.tar.xz',
}
proof=dict(floor=floor,core=core,oldDigest=old_digest,
    archives={name:sha(path) for name,path in archive_paths.items()},
    currentDonor=read(prior/'comparison/quiet/upload.json')['root'])
remote='proof='+repr(proof)+'''
from hashlib import sha256
from pathlib import Path
import fcntl
import json
import shutil
import subprocess

base=Path.home()/'lython-bench-checks'
sha=lambda p:sha256(p.read_bytes()).hexdigest()
assert base.resolve()==base
with (base/'comparison-vm.lock').open('r') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    free=shutil.disk_usage(base).free
    result=dict(before=free,requiredBeforeStage=proof['floor'],replicas=[],backedUpCore=proof['oldDigest'])
    if free<proof['floor']:
        replicas=[]
        assert not any(path.is_mount() for path in base.glob('*/guest-fixtures'))
        assert proof['currentDonor'] not in proof['archives']
        for folder,digest in proof['archives'].items():
            parent=base/folder
            assert parent.resolve(strict=True)==parent and parent.parent==base
            receipt=json.loads((parent/'archive-receipt.json').read_text())
            assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
            assert receipt['archiveSHA256']==digest==sha(parent/'observations.tar.xz')
            binary=parent/'candidate'/proof['core']
            assert binary.resolve(strict=True)==binary and binary.is_file() and sha(binary)==proof['oldDigest']
            replicas.append(binary)
        snapshots=[path.stat() for path in replicas]
        assert len(replicas)==2 and snapshots[0].st_ino==snapshots[1].st_ino and snapshots[0].st_dev==snapshots[1].st_dev
        assert all(snapshot.st_nlink==2 for snapshot in snapshots)
        assert free+snapshots[0].st_size>=proof['floor']
        for binary in replicas:
            binary.unlink()
            result['replicas'].append(str(binary))
    result['after']=shutil.disk_usage(base).free
    assert result['after']>=proof['floor']
    print(json.dumps(result))
'''
ssh=['ssh','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','ConnectTimeout=12',
     'lokad@20.166.121.73','python3 -c '+shlex.quote(remote)]
result=subprocess.run(ssh,check=True,capture_output=True,text=True,encoding='utf-8',timeout=40)
write(lab/'vm-storage.json',json.loads(result.stdout))
print(result.stdout.strip())

