from pathlib import Path
import hashlib,json,shutil
root=Path('/home/lokad/lython-bench-checks/flat-operands-b207-20261104/checkpoint');before=Path('/home/lokad/lython-bench-checks/compact-fragments-b205-20261104/metadata/candidate');candidate=root/'candidate'
for file in before.iterdir():
 if file.name=='Lokad.Lython.dll':continue
 if file.name in ['Lokad.Lython.Benchmarks.dll','Lokad.Lython.Benchmarks.deps.json','Lokad.Lython.Benchmarks.runtimeconfig.json']:shutil.copyfile(file,candidate/file.name)
 else:(candidate/file.name).symlink_to(file.resolve(),target_is_directory=file.is_dir())
(root/'reference').symlink_to(before,target_is_directory=True)
d=json.loads((root/'identity.json').read_text())
for label,folder in [('candidate','candidate'),('control','candidate'),('reference','reference')]:assert hashlib.sha256((root/folder/'Lokad.Lython.dll').read_bytes()).hexdigest()==d['coreSHA256'][label]
assert shutil.disk_usage(root).free>64*1024*1024
