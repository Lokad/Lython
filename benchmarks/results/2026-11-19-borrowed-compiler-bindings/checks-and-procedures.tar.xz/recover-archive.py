from pathlib import Path
import hashlib, json, subprocess, tarfile

lab=Path(__file__).resolve().parent
run=lab/'quiet'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
config=load(run/'config.json')
original=load(next(run.glob('observation-*.json')))
assert original['exitCode']=='1' and original['receipt'] is None
assert all(not original[key] for key in ('live','remainingWorkers','remainingTrace'))
assert '222298112' in original['journal']
script='''
from pathlib import Path
import fcntl,hashlib,json,shutil,subprocess,tarfile
c=CONFIG
root=Path(c['root']); assert root.resolve()==root
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with (root.parent/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 state=subprocess.check_output(['systemctl','show',c['unit']+'.service','--property=MainPID,ExecMainStatus'],text=True)
 assert 'MainPID=0' in state and 'ExecMainStatus=1' in state
 assert not (root/'guest-fixtures').exists() and (root/'exit-code.txt').read_text().strip()=='1'
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.13.*cpython-worker.py'],capture_output=True).returncode==1
 for role,files in c['identity']['imageFiles'].items():
  assert {name:sha(root/role/name) for name in files}==files
 assert sha(root/'representative.json')==c['catalogSHA256']
 proof=root/'observations.tgz'
 with tarfile.open(proof) as archive:
  for name in ('confirmation/confirmation.json','confirmation/machine-before.json','confirmation/machine-after.json','identity.json','representative.json','archive-owned.py'):
   assert archive.extractfile(name).read()==(root/name).read_bytes()
 raw=json.loads((root/'confirmation/confirmation.json').read_text());assert raw['complete'] and len(raw['jobs'])==7
 assert all(j['workersJoinedAndFixturesRemoved'] and len(j['samples'])==20 for j in raw['jobs'])
 assert all(json.loads((root/'confirmation'/p).read_text())['gate']['quiet'] for p in ('machine-before.json','machine-after.json'))
 print(json.dumps(dict(complete=True, jobs=len(raw['jobs']), elapsedSeconds=raw['elapsedSeconds'],archiveSHA256=sha(proof),
                verifiedAfterCollectionUnderIdleLease=True,originalExitCode=1,archiveOnlyFailure=True,
                allWorkersJoined=True,guestFixturesRemoved=True,quietBeforeAndAfter=True,freeBytesAtVerification=shutil.disk_usage(root).free)))
'''.replace('CONFIG',repr(config))
key=str(Path.home()/'.ssh/id_lython-bench.pem')
opts=['-i',key,'-o','BatchMode=yes','-o','ConnectTimeout=15']
reply=subprocess.run(['C:/Windows/System32/OpenSSH/ssh.exe',*opts,'lokad@20.166.121.73','python3 -'],
   input=script,text=True,encoding='utf-8',capture_output=True,timeout=35)
assert reply.returncode==0,reply.stderr
proof=json.loads(reply.stdout)
(run/'archive-recovery.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
path=run/'observations.tgz'
subprocess.run(['C:/Windows/System32/OpenSSH/scp.exe',*opts,'lokad@20.166.121.73:'+config['root']+'/observations.tgz',path],check=True,timeout=35)
assert sha(path)==proof['archiveSHA256']
with tarfile.open(path) as archive:
 regular=[m for m in archive.getmembers() if m.isfile() or m.isdir()]
 archive.extractall(run/'retrieved',members=regular,filter='data')
raw=load(run/'retrieved/confirmation/confirmation.json')
cases={r['id']:r for r in load(lab/'catalog.json')['cases']}
for job in raw['jobs']:
 case=cases[job['case']]
 assert job['workersJoinedAndFixturesRemoved'] and len(job['samples'])==20
 for role,worker in job['identities'].items():
  image=config['identity']['imageFiles'][role.removesuffix('-control')]
  observed={Path(lib['path']).name:lib['sha256'].lower() for lib in worker['libraries'] if Path(lib['path']).name in image}
  assert observed.get('Lokad.Lython.dll')==image['Lokad.Lython.dll']
  assert all(image[name]==hash for name,hash in observed.items())
  rows=[r for r in job['samples'] if r['engine']==role]
  assert sorted(r['round'] for r in rows)==list(range(5))
  for row in rows:
   v=row['response']
   assert v['status']=='Completed' and v['completedInvocations']>0
   for field in ('sourceSha256','fixtureSha256','expectedOutputSha256'):
    assert v[field]==case[field]
   assert v.get('actualOutputSha256')==(None if job['lane']=='compile' else case['expectedOutputSha256'])
   assert v.get('actualFilesSha256')==(None if job['lane']=='compile' else case.get('expectedFilesSha256'))
print('Recovered the original archive. Verified 140 golden batches, timings, image hashes and prior teardown.')
