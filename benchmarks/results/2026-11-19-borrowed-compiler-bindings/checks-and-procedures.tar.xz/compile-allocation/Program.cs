using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Lokad.Lython;

using var catalog = JsonDocument.Parse(File.ReadAllText(args[0], Encoding.UTF8));
var budget = new LythonMemoryBudget();
var engine = new LythonEngine();
var rows = new List<object>();
foreach (var workload in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var id = workload.GetProperty("id").GetString();
    var source = workload.GetProperty("source").GetString()!;
    for (var i = 0; i < 64; i++) Compile();
    var bytes = new double[5];
    for (var round = 0; round < bytes.Length; round++)
    {
        var start = GC.GetAllocatedBytesForCurrentThread();
        for (var i = 0; i < 64; i++) Compile();
        bytes[round] = (GC.GetAllocatedBytesForCurrentThread() - start) / 64d;
    }
    rows.Add(new { id, bytes, characters = source.Length });
    void Compile()
    {
        using (var compiled = engine.Compile(source, budget))
        {
            if (!compiled.IsValid) throw new InvalidOperationException(string.Join("; ", compiled.Diagnostics));
        }
        if (budget.ReservedBytes != 0) throw new InvalidOperationException("Compilation allowance did not return to baseline.");
    }
}
var core = File.ReadAllBytes(typeof(LythonEngine).Assembly.Location);
Console.WriteLine(JsonSerializer.Serialize(new
{
    coreSha256 = Convert.ToHexStringLower(SHA256.HashData(core)),
    boundary = "Local synchronous public compilation and compiled-owner disposal. Borrowed budget returns to baseline after every invocation. Counts current-thread allocations. No elapsed claim.",
    rows
}));
