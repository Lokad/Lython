from pathlib import Path
import json,statistics
r=Path(__file__).parent
raw=json.loads((r/'quiet/retrieved/confirmation/confirmation.json').read_text(encoding='utf-8'));assert raw['complete']and len(raw['jobs'])==7;rows=[]
for job in raw['jobs']:
    med={};cpu={};iqr={}
    for label in job['identities']:
        samples=[s for s in job['samples']if s['engine']==label]
        values=[s['response']['elapsedTicks']/s['response']['clockFrequency']/s['response']['completedInvocations']*1000 for s in samples]
        med[label]=statistics.median(values)
        quartiles=statistics.quantiles(values,n=4,method='inclusive');iqr[label]=100*(quartiles[2]-quartiles[0])/med[label]
        cpu[label]=statistics.median(s['externalProcessCpuTicks']/s['externalCpuFrequency']/s['response']['completedInvocations']*1000 for s in samples)
    change=lambda values:sorted(100*(values[a]/values[b]-1)for a in ['candidate','candidate-control']for b in ['reference','reference-control'])
    spread=lambda role:100*(max(med[role],med[role+'-control'])/min(med[role],med[role+'-control'])-1)
    rows.append(dict(case=job['case'],lane=job['lane'],elapsedMilliseconds=med,cpuMilliseconds=cpu,elapsedIQRPercent=iqr,elapsedChangePercent=change(med),cpuChangePercent=change(cpu),referenceSpreadPercent=spread('reference'),candidateSpreadPercent=spread('candidate')))
summary=dict(complete=True,elapsedSeconds=raw['elapsedSeconds'],quietBeforeAndAfter=True,allUsersJoinedAndFixturesRemoved=True,archivalOnlyRecovery=json.loads((r/'quiet/retrieved/retirement-receipt.json').read_text(encoding='utf-8')),rows=rows,retentionDecisionPending=True,CPythonRefreshed=False)
(r/'quiet-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
for row in rows:print(row['case'],row['lane'],'elapsed',row['elapsedChangePercent'],'CPU',row['cpuChangePercent'],'spreads',row['referenceSpreadPercent'],row['candidateSpreadPercent'],'maxIQR',max(row['elapsedIQRPercent'].values()))
