from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
root=Path(__file__).resolve().parent
refined=root/'refinement';refined.mkdir(exist_ok=True)
candidate=refined/'candidate';candidate.mkdir(exist_ok=True)
remote='/home/lokad/lython-bench-checks/scalar-creation-b196-20261104/refinement'
original='/home/lokad/lython-bench-checks/scalar-creation-b196-20261104'
binary=Path('benchmarks/Lokad.Lython.Benchmarks/bin/Release/net11.0/Lokad.Lython.dll')
assert binary.read_bytes()==Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll').read_bytes()
shutil.copyfile(binary,candidate/binary.name)
identity=json.loads((root/'identity.json').read_text(encoding='utf-8'))
identity['sourceRevision']='3e863f40 plus B196 refined typed integer creation patch'
identity['coreSHA256']['initial']=identity['coreSHA256']['candidate']
identity['coreSHA256']['candidate']=hashlib.sha256(binary.read_bytes()).hexdigest()
identity['sourceFiles']={f:hashlib.sha256(Path(f).read_bytes()).hexdigest() for f in identity['sourceFiles']}
(refined/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
(refined/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src']))
for f in ['catalog.json','cpython-worker.py','pre-code-plan.md','refinement-plan.md','value-distribution.py','value-distribution.json']:
 shutil.copyfile(root/f,refined/f)
s=(root/'collect.py').read_text(encoding='utf-8').replace("root = Path('"+original+"')","root = Path('"+remote+"')")
s=s.replace("jobs = [(list(cases)[index],lane) for lane in ['warm','warm-async'] for index in [0,1,2,3,4,6,7]]", "jobs = [(list(cases)[i],lane) for i,lane in [(0,'warm'),(2,'warm'),(1,'warm'),(1,'warm-async'),(7,'warm'),(7,'warm-async')]]")
s=s.replace("else worker), '--compare'", "else Path('"+original+"/candidate/Lokad.Lython.Benchmarks.dll') if label == 'initial' else worker), '--compare'")
s=s.replace("labels=['before-control','candidate','after-control']","labels=['before-control','initial','candidate','after-control']").replace('if job_index >= 7:', 'if job_index >= 3:')
s=s.replace('warmupSeconds=3, targetBatchSeconds=.20, rounds=9','warmupSeconds=5, targetBatchSeconds=.20, rounds=13').replace('range(9):','range(13):').replace('end=time.monotonic()+3;','end=time.monotonic()+5;').replace("started < 350", "started < 260")
s=s.replace("purpose='B196 typed integer creation versus B194;", "purpose='B196 refined creation versus original a6b2 and two B194 controls;")
(refined/'collect.py').write_text(s,encoding='utf-8',newline='\n')
setup=(root/'setup.py').read_text(encoding='utf-8').replace("root=Path('"+original+"')", "root=Path('"+remote+"')")
(refined/'setup.py').write_text(setup,encoding='utf-8',newline='\n')
archive=(root/'archive.py').read_text(encoding='utf-8').replace("root=Path('"+original+"')", "root=Path('"+remote+"')").replace("len(r['jobs'])==14","len(r['jobs'])==6").replace("'pre-code-plan.md',", "'pre-code-plan.md','refinement-plan.md',")
(refined/'archive.py').write_text(archive,encoding='utf-8',newline='\n')
summary=(root/'summarize.py').read_text(encoding='utf-8').replace("labels=['before-control','candidate','after-control']","labels=['before-control','initial','candidate','after-control']")
summary=summary.replace("oldControlPercent=(m['after-control']/m['before-control']-1)*100)", "oldControlPercent=(m['after-control']/m['before-control']-1)*100,initialDeltaPercent=(m['initial']/m['before-control']-1)*100,versusInitialPercent=(m['candidate']/m['initial']-1)*100)")
(refined/'summarize.py').write_text(summary,encoding='utf-8',newline='\n')
with tarfile.open(refined/'payload.tgz','w:gz') as t:
 for f in ['candidate','catalog.json','identity.json','source.patch','collect.py','cpython-worker.py','setup.py','archive.py','pre-code-plan.md','refinement-plan.md','value-distribution.py','value-distribution.json']:
  t.add(refined/f,arcname=f)
print(json.dumps({'frozen':identity['coreSHA256']['candidate'],'original':identity['coreSHA256']['initial'],'payloadBytes':(refined/'payload.tgz').stat().st_size}))
