from pathlib import Path
import hashlib, io, json, shutil, struct, subprocess, tarfile
from contextlib import redirect_stdout

root=Path(__file__).resolve().parent
prior=root.parent/'fixed-text-construction-b194'
remote='/home/lokad/lython-bench-checks/scalar-creation-b196-20261104'
before='/home/lokad/lython-bench-checks/fixed-text-construction-b194-20261104/final/candidate'
catalog=json.loads((prior/'catalog.json').read_text(encoding='utf-8'))
catalog['cases']=catalog['cases'][:6]
for name,source in [
 ('scalar-small',"value = int('0')\ntotal = 0\nfor i in range(8192):\n    value = (value + 1) & 31\n    total = total + value\nprint(total)\n"),
 ('scalar-above-range',"value = int('1000000')\nfor i in range(8192):\n    value += 3\nprint(value)\n")]:
 output=io.StringIO()
 with redirect_stdout(output):exec(compile(source,'<independent-control-golden>','exec'),{})
 fixture=json.dumps(dict(size=8192,text=None,inputFiles={},outputFiles={}),separators=(',',':'))
 case=dict(catalog['cases'][0],id='scripts.'+name+'.large',source=source,fixtureJson=fixture,expectedOutput=output.getvalue(),size=8192,
  sourceUtf8Bytes=len(source.encode()),expectedOutputUtf8Bytes=len(output.getvalue().encode()),fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,
  sourceSha256=hashlib.sha256(source.encode()).hexdigest(),fixtureSha256=hashlib.sha256(fixture.encode()).hexdigest(),
  expectedOutputSha256=hashlib.sha256(output.getvalue().encode()).hexdigest(),expectedFilesSha256=hashlib.sha256(struct.pack('>i',0)).hexdigest())
 catalog['cases'].append(case)
(root/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
candidate=root/'candidate';candidate.mkdir(exist_ok=True)
binary=Path('benchmarks/Lokad.Lython.Benchmarks/bin/Release/net11.0/Lokad.Lython.dll')
assert binary.read_bytes()==Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll').read_bytes()
shutil.copyfile(binary,candidate/binary.name)
files=subprocess.check_output(['git','diff','--name-only','--','src'],text=True).splitlines()
identity=dict(sourceRevision='3e863f40 plus B196 typed fresh-integer creation prototype',baselineRuntimeRevision='2d46dc8e',
 coreSHA256={'before-control':'ba48576af397ef62ce62a493b7ab4eb2ff845874fe44c512e6e5ceadf8e63783',
 'candidate':hashlib.sha256(binary.read_bytes()).hexdigest(),'after-control':'ba48576af397ef62ce62a493b7ab4eb2ff845874fe44c512e6e5ceadf8e63783'},
 sourceFiles={f:hashlib.sha256(Path(f).read_bytes()).hexdigest() for f in files})
(root/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
(root/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src']))
collect=(prior/'collect.py').read_text(encoding='utf-8')
collect=collect.replace('/home/lokad/lython-bench-checks/fixed-text-construction-b194-20261104',remote)
collect=collect.replace("worker = Path('/home/lokad/lython-bench-checks/borrowed-native-arguments-b192-20261104/refinement/candidate/Lokad.Lython.Benchmarks.dll')",f"worker = Path('{before}/Lokad.Lython.Benchmarks.dll')")
collect=collect.replace("for index in [0,1,2,3,4,5]", "for index in [0,1,2,3,4,6,7]")
collect=collect.replace('if job_index >= 6:', 'if job_index >= 7:')
collect=collect.replace("str(Path('"+remote+"/tool/complete-jobs.dll'))", "str(Path('/home/lokad/lython-bench-checks/fixed-text-construction-b194-20261104/tool/complete-jobs.dll'))")
collect=collect.replace('B194 fixed immutable UTF8 construction versus B192; five complete jobs and casing control both APIs; separate eight-case allocation diagnostic includes casing/padding/slices;', 'B196 typed integer creation versus B194; five complete jobs plus small/above-range controls both APIs; separate eight-case allocation diagnostic includes unchanged casing control;')
collect=collect.replace("    subprocess.run([str(dotnet),str(worker),'--compare','check-machine','--out',str(out/'machine-after.json')]", "    time.sleep(5) # Settle owned cleanup before the original quiet gate.\n    subprocess.run([str(dotnet),str(worker),'--compare','check-machine','--out',str(out/'machine-after.json')]")
(root/'collect.py').write_text(collect,encoding='utf-8',newline='\n')
shutil.copyfile(prior/'cpython-worker.py',root/'cpython-worker.py')
setup=f'''from pathlib import Path
import hashlib,json,shutil
root=Path({remote!r});before=Path({before!r});candidate=root/'candidate'
for file in before.iterdir():
 if file.name=='Lokad.Lython.dll':continue
 if file.name in ['Lokad.Lython.Benchmarks.dll','Lokad.Lython.Benchmarks.deps.json','Lokad.Lython.Benchmarks.runtimeconfig.json']:shutil.copyfile(file,candidate/file.name)
 else:(candidate/file.name).symlink_to(file.resolve(),target_is_directory=file.is_dir())
assert hashlib.sha256((candidate/'Lokad.Lython.dll').read_bytes()).hexdigest()==json.loads((root/'identity.json').read_text())['coreSHA256']['candidate']
'''
(root/'setup.py').write_text(setup,encoding='utf-8',newline='\n')
archive=(prior/'final/archive.py').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/fixed-text-construction-b194-20261104/final',remote).replace("len(r['jobs'])==12","len(r['jobs'])==14").replace("'pre-capture-plan.md'","'value-distribution.py','value-distribution.json'")
(root/'archive.py').write_text(archive,encoding='utf-8',newline='\n')
shutil.copyfile(prior/'summarize.py',root/'summarize.py')
with tarfile.open(root/'payload.tgz','w:gz') as t:
 for f in ['candidate','catalog.json','identity.json','source.patch','collect.py','cpython-worker.py','setup.py','archive.py','pre-code-plan.md','value-distribution.py','value-distribution.json']:
  t.add(root/f,arcname=f)
print(json.dumps({'frozen':identity['coreSHA256']['candidate'],'payloadBytes':(root/'payload.tgz').stat().st_size,'jobs':14,'allocationCases':8}))
