"""Untimed local JIT inspection using the existing owned worker protocol."""
import importlib.util,json,os,subprocess,tempfile
from pathlib import Path
root=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('protocol',root/'cpython-worker.py')
protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
case=json.loads((root/'catalog.json').read_text(encoding='utf-8'))['cases'][7]
env=os.environ.copy()
env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11'
env['DOTNET_JitDisasm']='Lokad.Lython.Runtime.Numbers.PyNumberOps:BoxInteger'
env['DOTNET_JitStdOutFile']=str(root/'box-jit.txt')
worker=Path('benchmarks/Lokad.Lython.Benchmarks/bin/Release/net11.0/Lokad.Lython.Benchmarks.dll').resolve()
with tempfile.TemporaryDirectory(prefix='lython-comparison-files-') as folder:
 with (root/'jit-worker-errors.txt').open('wb') as errors:
  p=subprocess.Popen([env['DOTNET_ROOT']+'/dotnet.exe',str(worker),'--compare','worker','--catalog',str(root/'catalog.json')],
   cwd=folder,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=errors)
  try:
   ready=protocol.read_frame(p.stdout);assert ready['status']=='Ready'
   for seq,operation,iterations in [(1,"verify",2),(2,"batch",1000),(3,"batch",1000)]:
    req={k:case[k] for k in ['sourceSha256','fixtureSha256','expectedOutputSha256']}
    req.update(protocolVersion=2,requestId=seq,operation=operation,caseId=case['id'],lane='warm',iterations=iterations)
    protocol.write_frame(p.stdin,req)
    response=protocol.read_frame(p.stdout);assert response['status']==('Equivalent' if operation=='verify' else 'Completed'),response
   protocol.write_frame(p.stdin,dict(protocolVersion=2,requestId=4,operation='quit'))
   assert protocol.read_frame(p.stdout)['status']=='Closed'
   assert p.wait(timeout=5)==0
  finally:
   if p.poll() is None:p.kill();p.wait()
   p.stdin.close();p.stdout.close()
assert not (root/'jit-worker-errors.txt').read_bytes()
print('Owned untimed local JIT diagnostic complete; normal VM comparisons remain separate.')
