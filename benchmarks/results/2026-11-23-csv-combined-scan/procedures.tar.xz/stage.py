from pathlib import Path
import hashlib
import json
import tarfile

lab=Path(__file__).resolve().parent
comparison=lab/"comparison"
donor=lab.parent/"reuse-private-word-admission-20261123/comparison/quiet/collect.py"
worker=donor.read_text(encoding="utf-8")
run=Path("csv-combined-scan-b1494-20261123")
root=comparison/"quiet"
root.mkdir(exist_ok=True)
reference="forwarded-global-call-b1489-20261123"
warm_jobs=json.loads((comparison/"jobs.json").read_text(encoding="utf-8"))["warm"]
worker=worker.replace("import contextlib, fcntl, hashlib, importlib.util, json, math, os, shutil",
    "import contextlib, fcntl, hashlib, importlib.util, json, math, os, shutil, tarfile")
worker=worker.replace("worker = root / 'candidate/Lokad.Lython.Benchmarks.dll'",f"""images = {{'candidate':root/'candidate','reference':root.parent/'{reference}'/'candidate'}}
worker = images['candidate'] / 'Lokad.Lython.Benchmarks.dll'
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
""".rstrip())
start=worker.index("job_catalog =")
end=worker.index("env = os.environ",start)
worker=worker[:start]+"""jobs = json.loads((root/'jobs.json').read_text())['warm']
assert digest(root/'jobs.json') == identity['catalogs']['jobs.json']['sha256']
assert len(jobs) == 6 and all(lane in ('compile','compile-run','warm') and case in cases for case,lane in jobs)

"""+worker[end:]
worker=worker.replace("owned_ram=root/'guest-fixtures';assert owned_ram.is_dir()", "owned_ram=root/'guest-fixtures'")
worker=worker.replace("assert os.stat(owned_ram).st_dev != os.stat('/tmp').st_dev\n","")
worker=worker.replace("str(root/('candidate' if label.startswith('candidate') else 'reference')/'Lokad.Lython.Benchmarks.dll')",
    "str(images['candidate' if label.startswith('candidate') else 'reference']/'Lokad.Lython.Benchmarks.dll')")
start=worker.index("with (root.parent/'comparison-vm.lock')")
end=worker.index("    started = time.monotonic()",start)
tail=worker[end:]
tail=tail[:tail.index("    assert not list(owned_ram.iterdir());")]
tail=tail.replace("assert time.monotonic()-started < 397, 'Reserve60seconds for final owned work/cleanup.'",
    "assert time.monotonic()-started < 307, 'Leave time for warm lane cleanup and persistent archival.'")
tail=tail.replace("catalog = root/job_catalog[case_id]", "catalog = root/'representative.json'")
tail=tail.replace("targetBatchSeconds=.65","targetBatchSeconds=.40").replace("counts[i]*.65", "counts[i]*.40")
tail=tail.replace("    time.sleep(5)  # Outside clocks; settle after all worker/process cleanup.\n", "    time.sleep(3)  # Outside clocks; settle after all worker/process cleanup.\n")
tail=tail.replace("    record.update(complete=True,elapsedSeconds=time.monotonic()-started); save()", 
    "    record.update(complete=True,elapsedSeconds=time.monotonic()-started); save()\n    return record")
worker=worker[:start]+'''def check_image():
    for role, files in identity['imageFiles'].items():
        for name, sha in files.items():
            assert digest(images[role]/name)==sha, (role,name)
    assert digest(root/'cpython-worker.py')==identity['cpythonWorkerSHA256']
    assert digest(python)==identity['expectedCPythonSHA256']

def warm():
'''+tail+'''
def archive(complete, warm):
    bundle=root/'observations.tar.xz'
    with tarfile.open(bundle,'w:xz') as frozen:
        for item in ('identity.json','representative.json','jobs.json','confirmation','collect.py','run.sh'):
            frozen.add(root/item,arcname=item)
    with tarfile.open(bundle) as frozen:
        assert all(hashlib.sha256(frozen.extractfile(member).read()).hexdigest()==digest(root/member.name)
            for member in frozen.getmembers() if member.isfile())
    (root/'archive-receipt.json').write_text(json.dumps(dict(
        complete=complete, warmJobs=len(warm['jobs']) if warm else None,
        allWorkersJoined=complete, guestFixturesRemoved=not owned_ram.exists(),
        quietBeforeAndAfter=complete, archivedAndVerifiedUnderLease=True, archiveSHA256=digest(bundle),
    ),indent=2)+'\\n')

with (root.parent/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX|fcntl.LOCK_NB)
    check_image()
    owned_ram.mkdir()
    subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=32m,mode=0700,uid=lokad,gid=lokad',
        'lython-b1494-fixtures',owned_ram],check=True)
    complete=False
    result=None
    try:
        assert os.stat(owned_ram).st_dev != os.stat('/tmp').st_dev
        time.sleep(3)
        subprocess.run([dotnet,worker,'--compare','check-machine','--out',out/'machine-before.json'],env=env,check=True)
        assert json.loads((out/'machine-before.json').read_text())['gate']['quiet']
        (out/'fixture-filesystem.txt').write_text(subprocess.check_output(
            ['findmnt','-T',str(owned_ram),'-o','TARGET,SOURCE,FSTYPE,OPTIONS'],text=True))
        result=warm()
        check_image()
        assert not list(owned_ram.iterdir()), list(owned_ram.iterdir())
        complete=True
    finally:
        subprocess.run(['sudo','-n','umount',owned_ram],check=True)
        owned_ram.rmdir()
        archive(complete,result)
'''
compile(worker, str(root/"collect.py"),"exec")
(root/"collect.py").write_text(worker,encoding="utf-8",newline="\n")
(root/"run.sh").write_text("""set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
trap 'status=$?; printf "%s\\n" "$status" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
""",encoding="utf-8",newline="\n")
assert b"\r" not in (root/"run.sh").read_bytes()
payload=root/"payload.tar.gz"
with tarfile.open(payload,"w:gz") as bundle:
    for item in ("identity.json","representative.json","jobs.json"):
        bundle.add(comparison/item,arcname=item)
    for item in ("run.sh","collect.py"):
        bundle.add(root/item,arcname=item)
    bundle.add(lab/"candidate/Lokad.Lython.dll",arcname="candidate-core.dll")
receipt=dict(root=str(run), reference=reference, payloadBytes=payload.stat().st_size, payloadSHA256=hashlib.sha256(payload.read_bytes()).hexdigest())
(root/"upload.json").write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf-8")
print(receipt)
