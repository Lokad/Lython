from pathlib import Path
import base64, hashlib, importlib.util, json, os, subprocess, tempfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
protocol=repo/'benchmarks/cpython-worker.py'
spec=importlib.util.spec_from_file_location('comparison_worker',protocol)
proto=importlib.util.module_from_spec(spec); spec.loader.exec_module(proto)
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
identity=read(lab/'comparison/identity.json')
assert sha(protocol.read_bytes())==identity['cpythonWorkerSHA256']
python='C:/Python313/python.exe'
rows=[
    '1,2\n3,4\n', '3,0.5\n4,-0.0\n', '5,1e2\n6,١.٥\n', '7,1_2\n8,+inf\n',
    '9,bad,"unfinished\n10,11\n', '12,"same\nrecord",13\n14,15\n',
    '16,"double""quote",17\n18,19\n', '20,"quoted,é",21\n22,23\n',
    '24,"bad"suffix,25\n26,27\n', '\n28,29,\n,,\n', '30,31', '32,',
    '33,«é»,34\n35,36\n', '37,"🌷",38\n39,40\n',
    '41,"'+('x'*18000)+'",42\n43,44\n',
    '45,'+('0'*18000)+'\n46,47\n',
]
files={f'case-{index:02}-{mode}.csv':('1,2\n'+line).replace('\n',ending).encode('utf-8')
       for index,line in enumerate(rows) for mode,ending in enumerate(('\n','\r\n','\r'))}
source=f"import csv\nfiles={json.dumps(list(files))}\n"+"""settings = [{}, {'strict': True}, {'quoting': csv.QUOTE_NONNUMERIC, 'strict': True}, {'quotechar': '«'}, {'doublequote': False, 'escapechar': '@'}]
for mode in [None, '']:
    for settings_item in settings:
        for name in files:
            with open(name, newline=mode, encoding='utf-8') as source:
                reader = csv.reader(source, **settings_item)
                for index in range(4):
                    try:
                        print(next(reader), reader.line_num)
                    except (csv.Error, ValueError, StopIteration) as error:
                        print(type(error).__name__, reader.line_num)
"""
with tempfile.TemporaryDirectory(prefix='lython-csv-window-oracle-') as work:
    root=Path(work)
    for name,content in files.items(): (root/name).write_bytes(content)
    (root/'run.py').write_text(source,encoding='utf-8',newline='\n')
    run=subprocess.run([python,'-I','-S','-X','utf8','run.py'],cwd=root,capture_output=True,check=True,timeout=25)
    assert not run.stderr
output=run.stdout.decode('utf-8').replace('\r\n','\n')
assert len(output.splitlines())==len(files)*2*5*4
catalog=read(lab/'representative.json')
case=catalog['cases'][0]
size=sum(map(len,files.values()))
fixture=json.dumps(dict(size=size,text=None,inputFiles={name:base64.b64encode(data).decode('ascii') for name,data in files.items()},outputFiles={}),separators=(',',':'))
catalog['cases']=[dict(case,id='diagnostic.csv-native-physical-lines.large',size=size,source=source,
    fixtureJson=fixture,expectedOutput=output,sourceUtf8Bytes=len(source.encode('utf-8')),
    expectedOutputUtf8Bytes=len(output.encode('utf-8')),sourceSha256=sha(source.encode('utf-8')),
    fixtureSha256=sha(fixture.encode('utf-8')),expectedOutputSha256=sha(output.encode('utf-8')),
    expectedFilesSha256=proto.file_digest({}))]
(out:=lab/'grammar-catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
dotnet=Path.home()/'.dotnet11/dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent))
for role,hashes in identity['imageFiles'].items():
    image=lab/role
    assert all(sha((image/name).read_bytes())==digest for name,digest in hashes.items())
    proof=lab/(role+'-grammar-verify.json')
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',out,
        '--dotnet',dotnet,'--python',python,'--python-worker',protocol,'--out',proof],env=env,timeout=100,check=True)
    receipt=read(proof)
    assert receipt['state']=='Completed' and receipt['caseCount']==1 and receipt['catalogSha256']==sha(out.read_bytes())
    assert receipt['launched']['library']['sha256']==hashes['Lokad.Lython.dll']
print(len(files)*2*5,'native file, newline and dialect combinations matched CPython on each immutable image')
