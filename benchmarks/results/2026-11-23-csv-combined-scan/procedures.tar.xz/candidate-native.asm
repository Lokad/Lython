; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext+ChunkedTextFileReadState:TryConsumeBufferedCsvLine(Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource,System.Nullable`1[System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]],byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 320
       lea      rbp, [rsp+0x140]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x110], xmm4
       vmovdqa  xmmword ptr [rbp-0x100], xmm4
       mov      rax, -240
 
G_M000_IG31:                ;; offset=0x002E
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG31
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0055
       mov      rax, bword ptr [rbp+0x28]
       mov      dword ptr [rax], -1
       mov      rax, gword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x6C]
       mov      dword ptr [rbp-0x04], eax
       lea      rdx, [rbp-0x18]
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x78]
       call     [System.ReadOnlyMemory`1[byte]:get_Span():System.ReadOnlySpan`1[byte]:this]
       mov      eax, dword ptr [rbp-0x04]
       cmp      eax, dword ptr [rbp-0x10]
       jne      SHORT G_M000_IG04
       xor      eax, eax
 
G_M000_IG03:                ;; offset=0x008B
       add      rsp, 320
       pop      rbp
       ret      
 
G_M000_IG04:                ;; offset=0x0094
       xor      eax, eax
       mov      dword ptr [rbp-0x20], eax
       mov      rax, gword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x58]
       mov      dword ptr [rbp-0x2C], eax
       cmp      dword ptr [rbp-0x2C], 0
       je       SHORT G_M000_IG05
       cmp      dword ptr [rbp-0x2C], 1
       jne      SHORT G_M000_IG08
 
G_M000_IG05:                ;; offset=0x00AF
       lea      rdx, [rbp-0x40]
       lea      rcx, [rbp-0x18]
       mov      r8d, dword ptr [rbp-0x04]
       call     [System.ReadOnlySpan`1[byte]:Slice(int):System.ReadOnlySpan`1[byte]:this]
 
G_M000_IG06:                ;; offset=0x00C1
       vmovdqu  xmm0, xmmword ptr [rbp-0x40]
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
 
G_M000_IG07:                ;; offset=0x00CE
       lea      rdx, [rbp-0xD8]
       lea      r8, [rbp-0x20]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:TryDescribeBufferedNativeLine(System.ReadOnlySpan`1[byte],byref):bool:this]
       mov      dword ptr [rbp-0x44], eax
       jmp      SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x00EA
       xor      eax, eax
       mov      dword ptr [rbp-0x44], eax
 
G_M000_IG09:                ;; offset=0x00EF
       movzx    rax, byte  ptr [rbp-0x44]
       mov      dword ptr [rbp-0x24], eax
       cmp      dword ptr [rbp-0x24], 0
       jne      SHORT G_M000_IG12
 
G_M000_IG10:                ;; offset=0x00FC
       vmovdqu  xmm0, xmmword ptr [rbp-0x18]
       vmovdqu  xmmword ptr [rbp-0xE8], xmm0
 
G_M000_IG11:                ;; offset=0x0109
       lea      rcx, [rbp-0xE8]
       mov      rax, gword ptr [rbp+0x10]
       mov      r8d, dword ptr [rax+0x58]
       mov      eax, dword ptr [rbp-0x04]
       mov      edx, eax
       add      edx, dword ptr [rbp-0x20]
       call     [Lokad.Lython.Runtime.Text.TextLineScanning:FindLineEndByte(System.ReadOnlySpan`1[byte],int,int):int]
       mov      dword ptr [rbp-0x48], eax
       jmp      SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x012B
       mov      eax, dword ptr [rbp-0x04]
       add      eax, dword ptr [rbp-0x20]
       mov      dword ptr [rbp-0x48], eax
 
G_M000_IG13:                ;; offset=0x0134
       mov      eax, dword ptr [rbp-0x48]
       mov      dword ptr [rbp-0x28], eax
       mov      eax, dword ptr [rbp-0x28]
       cmp      eax, dword ptr [rbp-0x10]
       jne      SHORT G_M000_IG17
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext+ChunkedTextFileReadState:EndsWithTerminator():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG17
       cmp      dword ptr [rbp-0x24], 0
       jne      SHORT G_M000_IG14
       cmp      dword ptr [rbp-0x20], 0
       je       SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x015C
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:DiscardBufferedNativeLine():this]
 
G_M000_IG15:                ;; offset=0x0168
       xor      eax, eax
 
G_M000_IG16:                ;; offset=0x016A
       add      rsp, 320
       pop      rbp
       ret      
 
G_M000_IG17:                ;; offset=0x0173
       mov      rcx, gword ptr [rbp+0x10]
       mov      edx, dword ptr [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext+ChunkedTextFileReadState:Advance(int):this]
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x30]
       xor      rdx, rdx
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      eax, dword ptr [rbp-0x04]
       mov      dword ptr [rbp-0x30], eax
       mov      rax, bword ptr [rbp+0x28]
       mov      bword ptr [rbp-0x50], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x58], rax
       mov      eax, dword ptr [rbp-0x28]
       mov      r9d, eax
       sub      r9d, dword ptr [rbp-0x30]
       lea      rcx, [rbp-0x18]
       lea      rdx, [rbp-0x68]
       mov      r8d, dword ptr [rbp-0x30]
       call     [System.ReadOnlySpan`1[byte]:Slice(int,int):System.ReadOnlySpan`1[byte]:this]
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG18:                ;; offset=0x01C8
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x80], xmm0
       mov      rcx, qword ptr [rax+0x10]
       mov      qword ptr [rbp-0x70], rcx
 
G_M000_IG19:                ;; offset=0x01D9
       mov      eax, dword ptr [rbp-0x24]
       mov      dword ptr [rbp-0x84], eax
       cmp      dword ptr [rbp-0x24], 0
       jne      SHORT G_M000_IG23
       mov      rax, bword ptr [rbp-0x50]
       mov      bword ptr [rbp-0x90], rax
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x98], rax
 
G_M000_IG20:                ;; offset=0x01FE
       vmovdqu  xmm0, xmmword ptr [rbp-0x68]
       vmovdqu  xmmword ptr [rbp-0xA8], xmm0
 
G_M000_IG21:                ;; offset=0x020B
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0xC0], xmm0
       mov      rax, qword ptr [rbp-0x70]
       mov      qword ptr [rbp-0xB0], rax
 
G_M000_IG22:                ;; offset=0x0223
       mov      eax, dword ptr [rbp-0x84]
       mov      dword ptr [rbp-0xC4], eax
       mov      eax, dword ptr [rbp-0x20]
       mov      dword ptr [rbp-0xC8], eax
       jmp      SHORT G_M000_IG27
 
G_M000_IG23:                ;; offset=0x023A
       mov      rax, bword ptr [rbp-0x50]
       mov      bword ptr [rbp-0x90], rax
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x98], rax
 
G_M000_IG24:                ;; offset=0x0250
       vmovdqu  xmm0, xmmword ptr [rbp-0x68]
       vmovdqu  xmmword ptr [rbp-0xA8], xmm0
 
G_M000_IG25:                ;; offset=0x025D
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0xC0], xmm0
       mov      rax, qword ptr [rbp-0x70]
       mov      qword ptr [rbp-0xB0], rax
 
G_M000_IG26:                ;; offset=0x0275
       mov      eax, dword ptr [rbp-0x84]
       mov      dword ptr [rbp-0xC4], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xC8], eax
 
G_M000_IG27:                ;; offset=0x0289
       vmovdqu  xmm0, xmmword ptr [rbp-0xA8]
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
 
G_M000_IG28:                ;; offset=0x0299
       vmovdqu  xmm0, xmmword ptr [rbp-0xC0]
       vmovdqu  xmmword ptr [rbp-0x110], xmm0
       mov      rax, qword ptr [rbp-0xB0]
       mov      qword ptr [rbp-0x100], rax
 
G_M000_IG29:                ;; offset=0x02B7
       mov      eax, dword ptr [rbp-0xC8]
       mov      dword ptr [rsp+0x20], eax
       lea      rdx, [rbp-0xF8]
       lea      r8, [rbp-0x110]
       mov      rcx, gword ptr [rbp-0x98]
       mov      r9d, dword ptr [rbp-0xC4]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:ConsumeBorrowedNativeLine(System.ReadOnlySpan`1[byte],System.Nullable`1[System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]],bool,int):int:this]
       mov      rcx, bword ptr [rbp-0x90]
       mov      dword ptr [rcx], eax
       mov      eax, 1
 
G_M000_IG30:                ;; offset=0x02F3
       add      rsp, 320
       pop      rbp
       ret      
 
; Total bytes of code 764

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:TryDescribeLiteralRecord(System.ReadOnlySpan`1[byte],byref,bool):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 336
       lea      rbp, [rsp+0x150]
       xor      eax, eax
       mov      qword ptr [rbp-0x118], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x110], xmm4
       mov      rax, -192
 
G_M000_IG63:                ;; offset=0x002F
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG63
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      dword ptr [rbp+0x28], r9d
 
G_M000_IG02:                ;; offset=0x005B
       mov      dword ptr [rbp-0xB4], 0x3E8
       mov      rax, gword ptr [rbp+0x10]
       cmp      gword ptr [rax+0x50], 0
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0070
       mov      rcx, 0x7FF9D72AA220
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xB0], rax
       mov      rcx, gword ptr [rbp-0xB0]
       mov      rdx, 0x1A74A076428
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, gword ptr [rbp-0xB0]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG04:                ;; offset=0x00AA
       mov      rcx, bword ptr [rbp+0x18]
       call     [System.ReadOnlySpan`1[byte]:get_IsEmpty():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
       mov      rcx, 0x7FF9D7956EF0
       call     CORINFO_HELP_COUNTPROFILE32
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0xB8], eax
       jmp      G_M000_IG60
 
G_M000_IG05:                ;; offset=0x00DE
       mov      rax, bword ptr [rbp+0x20]
       mov      eax, dword ptr [rax]
       mov      dword ptr [rbp-0x3C], eax
       cmp      dword ptr [rbp-0x3C], 0
       jne      G_M000_IG11
       mov      rax, bword ptr [rbp+0x18]
       cmp      dword ptr [rax+0x08], 0
       jbe      G_M000_IG62
       mov      rax, bword ptr [rbp+0x18]
       mov      rax, bword ptr [rax]
       movzx    rax, byte  ptr [rax]
       mov      dword ptr [rbp-0x60], eax
       cmp      dword ptr [rbp-0x60], 10
       je       SHORT G_M000_IG07
       cmp      dword ptr [rbp-0x60], 13
       jne      SHORT G_M000_IG10
 
G_M000_IG06:                ;; offset=0x0118
       mov      rcx, 0x7FF9D7956EF4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG07:                ;; offset=0x0127
       mov      rcx, 0x7FF9D7956EF8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rax+0x18]
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG08:                ;; offset=0x0152
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
 
G_M000_IG09:                ;; offset=0x015E
       mov      rax, bword ptr [rbp+0x20]
       mov      bword ptr [rsp+0x20], rax
       lea      rdx, [rbp-0xC8]
       movzx    r9, byte  ptr [rbp+0x28]
       mov      rcx, gword ptr [rbp+0x10]
       xor      r8d, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:CompleteLiteralRecord(System.ReadOnlySpan`1[byte],int,bool,byref):this]
       jmp      G_M000_IG52
 
G_M000_IG10:                ;; offset=0x0185
       mov      rcx, 0x7FF9D7956EFC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG11:                ;; offset=0x0194
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x30]
       mov      gword ptr [rbp-0x58], rax
       cmp      gword ptr [rbp-0x58], 0
       jne      SHORT G_M000_IG14
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG12:                ;; offset=0x01B0
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0xA0], xmm0
 
G_M000_IG13:                ;; offset=0x01BD
       jmp      SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x01BF
       mov      rcx, 0x7FF9D7956F00
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdx, [rbp-0xA0]
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
 
G_M000_IG15:                ;; offset=0x01E1
       vmovdqu  xmm0, xmmword ptr [rbp-0xA0]
       vmovdqu  xmmword ptr [rbp-0x50], xmm0
 
G_M000_IG16:                ;; offset=0x01EE
       lea      rcx, [rbp-0x50]
       call     [System.ReadOnlySpan`1[byte]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG17
       cmp      dword ptr [rbp-0x48], 0
       jbe      G_M000_IG62
       mov      rax, bword ptr [rbp-0x50]
       movzx    rax, byte  ptr [rax]
       mov      dword ptr [rbp-0xA4], eax
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0215
       mov      rcx, 0x7FF9D7956F04
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xA4], -1
 
G_M000_IG18:                ;; offset=0x022E
       mov      eax, dword ptr [rbp-0xA4]
       mov      dword ptr [rbp-0x5C], eax
       mov      rax, gword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x60]
       cmp      eax, dword ptr [rbp-0x5C]
       je       SHORT G_M000_IG20
       cmp      dword ptr [rbp-0x5C], 10
       je       SHORT G_M000_IG22
       cmp      dword ptr [rbp-0x5C], 13
       jne      SHORT G_M000_IG21
 
G_M000_IG19:                ;; offset=0x024F
       mov      rcx, 0x7FF9D7956F08
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG20:                ;; offset=0x025E
       mov      dword ptr [rbp-0x5C], -1
       jmp      G_M000_IG55
 
G_M000_IG21:                ;; offset=0x026A
       mov      rcx, 0x7FF9D7956F0C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG55
 
G_M000_IG22:                ;; offset=0x027E
       mov      rcx, 0x7FF9D7956F10
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG20
 
G_M000_IG23:                ;; offset=0x028F
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x3C]
       jle      G_M000_IG37
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x3C], eax
       jae      G_M000_IG62
       mov      rax, bword ptr [rbp+0x18]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x3C]
       movzx    rax, byte  ptr [rax+rcx]
       mov      ecx, dword ptr [rbp-0x5C]
       cmp      eax, ecx
       jne      G_M000_IG36
       cmp      dword ptr [rbp-0x48], 1
       jne      G_M000_IG35
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG24:                ;; offset=0x02D6
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
 
G_M000_IG25:                ;; offset=0x02E2
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       lea      rdx, [rbp-0xD8]
       movzx    r9, byte  ptr [rbp-0x5C]
       mov      eax, dword ptr [rbp-0x3C]
       lea      r8d, [rax+0x01]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:FindLiteralQuote(System.ReadOnlySpan`1[byte],int,byte,bool):int:this]
       mov      dword ptr [rbp-0x8C], eax
       cmp      dword ptr [rbp-0x8C], 0
       jl       G_M000_IG34
       mov      eax, dword ptr [rbp-0x8C]
       inc      eax
       mov      dword ptr [rbp-0x74], eax
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       SHORT G_M000_IG27
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x74]
       je       G_M000_IG33
 
G_M000_IG26:                ;; offset=0x033D
       mov      rcx, 0x7FF9D7956F14
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG27:                ;; offset=0x034C
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x74]
       jle      SHORT G_M000_IG29
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x74], eax
       jae      G_M000_IG62
       mov      rax, bword ptr [rbp+0x18]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x74]
       movzx    rax, byte  ptr [rax+rcx]
       mov      rcx, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x60]
       cmp      eax, ecx
       je       G_M000_IG32
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x74], eax
       jae      G_M000_IG62
       mov      rax, bword ptr [rbp+0x18]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x74]
       movzx    rax, byte  ptr [rax+rcx]
       mov      dword ptr [rbp-0x60], eax
       cmp      dword ptr [rbp-0x60], 10
       je       SHORT G_M000_IG31
       cmp      dword ptr [rbp-0x60], 13
       jne      SHORT G_M000_IG30
 
G_M000_IG28:                ;; offset=0x03B2
       mov      rcx, 0x7FF9D7956F18
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG29:                ;; offset=0x03C1
       mov      rcx, 0x7FF9D7956F1C
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm3, xmm3, xmm3
       lea      rcx, [rbp-0x88]
       mov      eax, dword ptr [rbp-0x3C]
       lea      edx, [rax+0x01]
       mov      eax, dword ptr [rbp-0x8C]
       sub      eax, dword ptr [rbp-0x3C]
       lea      r8d, [rax-0x01]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField:.ctor(int,int,double):this]
       jmp      G_M000_IG44
 
G_M000_IG30:                ;; offset=0x03F9
       mov      rcx, 0x7FF9D7956F20
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG58
 
G_M000_IG31:                ;; offset=0x040D
       mov      rcx, 0x7FF9D7956F24
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG29
 
G_M000_IG32:                ;; offset=0x041E
       mov      rcx, 0x7FF9D7956F28
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG29
 
G_M000_IG33:                ;; offset=0x042F
       mov      rcx, 0x7FF9D7956F2C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG58
 
G_M000_IG34:                ;; offset=0x0443
       mov      rcx, 0x7FF9D7956F30
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG58
 
G_M000_IG35:                ;; offset=0x0457
       mov      rcx, 0x7FF9D7956F34
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG58
 
G_M000_IG36:                ;; offset=0x046B
       mov      rcx, 0x7FF9D7956F38
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG37:                ;; offset=0x047A
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG38:                ;; offset=0x047E
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xE8], xmm0
 
G_M000_IG39:                ;; offset=0x048A
       lea      rdx, [rbp-0xE8]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8d, dword ptr [rbp-0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:FindLiteralFieldEnd(System.ReadOnlySpan`1[byte],int):int:this]
       mov      dword ptr [rbp-0x74], eax
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       SHORT G_M000_IG41
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x74]
       je       G_M000_IG46
 
G_M000_IG40:                ;; offset=0x04BA
       mov      rcx, 0x7FF9D7956F3C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG41:                ;; offset=0x04C9
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG42:                ;; offset=0x04CD
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
 
G_M000_IG43:                ;; offset=0x04D9
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       lea      rax, [rbp-0x88]
       mov      qword ptr [rsp+0x28], rax
       lea      rdx, [rbp-0xF8]
       mov      eax, dword ptr [rbp-0x74]
       mov      r9d, eax
       sub      r9d, dword ptr [rbp-0x3C]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8d, dword ptr [rbp-0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:TryCreateLiteralBareField(System.ReadOnlySpan`1[byte],int,int,bool,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG45
 
G_M000_IG44:                ;; offset=0x0510
       vmovups  xmm0, xmmword ptr [rbp-0x88]
       vmovups  xmmword ptr [rbp-0x108], xmm0
       lea      rdx, [rbp-0x108]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:DescribeField(Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField):this]
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x74]
       jne      SHORT G_M000_IG47
       mov      rcx, 0x7FF9D7956F40
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG52
 
G_M000_IG45:                ;; offset=0x0551
       mov      rcx, 0x7FF9D7956F44
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG58
 
G_M000_IG46:                ;; offset=0x0565
       mov      rcx, 0x7FF9D7956F48
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG58
 
G_M000_IG47:                ;; offset=0x0579
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x74], eax
       jae      G_M000_IG62
       mov      rax, bword ptr [rbp+0x18]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x74]
       movzx    rax, byte  ptr [rax+rcx]
       mov      dword ptr [rbp-0x60], eax
       cmp      dword ptr [rbp-0x60], 10
       je       SHORT G_M000_IG49
       cmp      dword ptr [rbp-0x60], 13
       jne      SHORT G_M000_IG54
 
G_M000_IG48:                ;; offset=0x05A6
       mov      rcx, 0x7FF9D7956F4C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG49:                ;; offset=0x05B5
       mov      rcx, 0x7FF9D7956F50
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG50:                ;; offset=0x05C8
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x118], xmm0
 
G_M000_IG51:                ;; offset=0x05D4
       mov      rax, bword ptr [rbp+0x20]
       mov      bword ptr [rsp+0x20], rax
       lea      rdx, [rbp-0x118]
       movzx    r9, byte  ptr [rbp+0x28]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8d, dword ptr [rbp-0x74]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:CompleteLiteralRecord(System.ReadOnlySpan`1[byte],int,bool,byref):this]
 
G_M000_IG52:                ;; offset=0x05F7
       mov      eax, 1
 
G_M000_IG53:                ;; offset=0x05FC
       add      rsp, 336
       pop      rbp
       ret      
 
G_M000_IG54:                ;; offset=0x0605
       mov      rcx, 0x7FF9D7956F54
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x74]
       inc      eax
       mov      dword ptr [rbp-0x3C], eax
 
G_M000_IG55:                ;; offset=0x061C
       mov      eax, dword ptr [rbp-0xB4]
       dec      eax
       mov      dword ptr [rbp-0xB4], eax
       cmp      dword ptr [rbp-0xB4], 0
       jg       SHORT G_M000_IG57
 
G_M000_IG56:                ;; offset=0x0633
       lea      rcx, [rbp-0xB4]
       mov      edx, 445
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG57:                ;; offset=0x0646
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x20]
       cmp      dword ptr [rcx], ecx
       call     [System.Collections.Generic.List`1[Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField]:get_Count():int:this]
       mov      dword ptr [rbp-0xA8], eax
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x20]
       cmp      dword ptr [rcx], ecx
       call     [System.Collections.Generic.List`1[Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField]:get_Capacity():int:this]
       cmp      eax, dword ptr [rbp-0xA8]
       jg       G_M000_IG23
 
G_M000_IG58:                ;; offset=0x0678
       mov      rcx, 0x7FF9D7956F58
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x20]
       mov      ecx, dword ptr [rbp-0x3C]
       mov      dword ptr [rax], ecx
       xor      eax, eax
 
G_M000_IG59:                ;; offset=0x0692
       add      rsp, 336
       pop      rbp
       ret      
 
G_M000_IG60:                ;; offset=0x069B
       movzx    rax, byte  ptr [rbp-0xB8]
 
G_M000_IG61:                ;; offset=0x06A2
       add      rsp, 336
       pop      rbp
       ret      
 
G_M000_IG62:                ;; offset=0x06AB
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1713

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext+ChunkedTextFileReadState:TryConsumeBufferedCsvLine(Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource,System.Nullable`1[System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]],byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 320
       lea      rbp, [rsp+0x140]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x110], xmm4
       vmovdqa  xmmword ptr [rbp-0x100], xmm4
       mov      rax, -240
 
G_M000_IG36:                ;; offset=0x002E
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG36
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      bword ptr [rbp+0x28], r9
 
G_M000_IG02:                ;; offset=0x0055
       mov      rax, bword ptr [rbp+0x28]
       mov      dword ptr [rax], -1
       mov      rax, gword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x6C]
       mov      dword ptr [rbp-0x04], eax
       lea      rdx, [rbp-0x18]
       mov      rax, gword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, gword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x78]
       call     [System.ReadOnlyMemory`1[byte]:get_Span():System.ReadOnlySpan`1[byte]:this]
       mov      eax, dword ptr [rbp-0x04]
       cmp      eax, dword ptr [rbp-0x10]
       jne      SHORT G_M000_IG04
       mov      rcx, 0x7FF9D7A969D0
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG03:                ;; offset=0x009A
       add      rsp, 320
       pop      rbp
       ret      
 
G_M000_IG04:                ;; offset=0x00A3
       xor      eax, eax
       mov      dword ptr [rbp-0x20], eax
       mov      rax, gword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x58]
       mov      dword ptr [rbp-0x2C], eax
       cmp      dword ptr [rbp-0x2C], 0
       je       SHORT G_M000_IG06
       cmp      dword ptr [rbp-0x2C], 1
       jne      SHORT G_M000_IG09
 
G_M000_IG05:                ;; offset=0x00BE
       mov      rcx, 0x7FF9D7A969D4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG06:                ;; offset=0x00CD
       lea      rdx, [rbp-0x40]
       lea      rcx, [rbp-0x18]
       mov      r8d, dword ptr [rbp-0x04]
       call     [System.ReadOnlySpan`1[byte]:Slice(int):System.ReadOnlySpan`1[byte]:this]
 
G_M000_IG07:                ;; offset=0x00DF
       vmovdqu  xmm0, xmmword ptr [rbp-0x40]
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
 
G_M000_IG08:                ;; offset=0x00EC
       lea      rdx, [rbp-0xD8]
       lea      r8, [rbp-0x20]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:TryDescribeBufferedNativeLine(System.ReadOnlySpan`1[byte],byref):bool:this]
       mov      dword ptr [rbp-0x44], eax
       jmp      SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x0108
       mov      rcx, 0x7FF9D7A969D8
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x44], eax
 
G_M000_IG10:                ;; offset=0x011C
       movzx    rax, byte  ptr [rbp-0x44]
       mov      dword ptr [rbp-0x24], eax
       cmp      dword ptr [rbp-0x24], 0
       jne      SHORT G_M000_IG13
 
G_M000_IG11:                ;; offset=0x0129
       vmovdqu  xmm0, xmmword ptr [rbp-0x18]
       vmovdqu  xmmword ptr [rbp-0xE8], xmm0
 
G_M000_IG12:                ;; offset=0x0136
       lea      rcx, [rbp-0xE8]
       mov      rax, gword ptr [rbp+0x10]
       mov      r8d, dword ptr [rax+0x58]
       mov      eax, dword ptr [rbp-0x04]
       mov      edx, eax
       add      edx, dword ptr [rbp-0x20]
       call     [Lokad.Lython.Runtime.Text.TextLineScanning:FindLineEndByte(System.ReadOnlySpan`1[byte],int,int):int]
       mov      dword ptr [rbp-0x48], eax
       jmp      SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x0158
       mov      rcx, 0x7FF9D7A969DC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x04]
       add      eax, dword ptr [rbp-0x20]
       mov      dword ptr [rbp-0x48], eax
 
G_M000_IG14:                ;; offset=0x0170
       mov      eax, dword ptr [rbp-0x48]
       mov      dword ptr [rbp-0x28], eax
       mov      eax, dword ptr [rbp-0x28]
       cmp      eax, dword ptr [rbp-0x10]
       jne      SHORT G_M000_IG21
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext+ChunkedTextFileReadState:EndsWithTerminator():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG20
       cmp      dword ptr [rbp-0x24], 0
       jne      SHORT G_M000_IG16
       cmp      dword ptr [rbp-0x20], 0
       je       SHORT G_M000_IG19
 
G_M000_IG15:                ;; offset=0x0198
       mov      rcx, 0x7FF9D7A969E0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG16:                ;; offset=0x01A7
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:DiscardBufferedNativeLine():this]
 
G_M000_IG17:                ;; offset=0x01B3
       mov      rcx, 0x7FF9D7A969E4
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG18:                ;; offset=0x01C4
       add      rsp, 320
       pop      rbp
       ret      
 
G_M000_IG19:                ;; offset=0x01CD
       mov      rcx, 0x7FF9D7A969E8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG17
 
G_M000_IG20:                ;; offset=0x01DE
       mov      rcx, 0x7FF9D7A969EC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG21:                ;; offset=0x01ED
       mov      rcx, gword ptr [rbp+0x10]
       mov      edx, dword ptr [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext+ChunkedTextFileReadState:Advance(int):this]
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x30]
       xor      rdx, rdx
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      eax, dword ptr [rbp-0x04]
       mov      dword ptr [rbp-0x30], eax
       mov      rax, bword ptr [rbp+0x28]
       mov      bword ptr [rbp-0x50], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x58], rax
       mov      eax, dword ptr [rbp-0x28]
       mov      r9d, eax
       sub      r9d, dword ptr [rbp-0x30]
       lea      rcx, [rbp-0x18]
       lea      rdx, [rbp-0x68]
       mov      r8d, dword ptr [rbp-0x30]
       call     [System.ReadOnlySpan`1[byte]:Slice(int,int):System.ReadOnlySpan`1[byte]:this]
       mov      rax, bword ptr [rbp+0x20]
 
G_M000_IG22:                ;; offset=0x0242
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x80], xmm0
       mov      rcx, qword ptr [rax+0x10]
       mov      qword ptr [rbp-0x70], rcx
 
G_M000_IG23:                ;; offset=0x0253
       mov      eax, dword ptr [rbp-0x24]
       mov      dword ptr [rbp-0x84], eax
       cmp      dword ptr [rbp-0x24], 0
       jne      SHORT G_M000_IG27
       mov      rax, bword ptr [rbp-0x50]
       mov      bword ptr [rbp-0x90], rax
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x98], rax
 
G_M000_IG24:                ;; offset=0x0278
       vmovdqu  xmm0, xmmword ptr [rbp-0x68]
       vmovdqu  xmmword ptr [rbp-0xA8], xmm0
 
G_M000_IG25:                ;; offset=0x0285
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0xC0], xmm0
       mov      rax, qword ptr [rbp-0x70]
       mov      qword ptr [rbp-0xB0], rax
 
G_M000_IG26:                ;; offset=0x029D
       mov      eax, dword ptr [rbp-0x84]
       mov      dword ptr [rbp-0xC4], eax
       mov      eax, dword ptr [rbp-0x20]
       mov      dword ptr [rbp-0xC8], eax
       jmp      SHORT G_M000_IG31
 
G_M000_IG27:                ;; offset=0x02B4
       mov      rcx, 0x7FF9D7A969F0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x50]
       mov      bword ptr [rbp-0x90], rax
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x98], rax
 
G_M000_IG28:                ;; offset=0x02D9
       vmovdqu  xmm0, xmmword ptr [rbp-0x68]
       vmovdqu  xmmword ptr [rbp-0xA8], xmm0
 
G_M000_IG29:                ;; offset=0x02E6
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0xC0], xmm0
       mov      rax, qword ptr [rbp-0x70]
       mov      qword ptr [rbp-0xB0], rax
 
G_M000_IG30:                ;; offset=0x02FE
       mov      eax, dword ptr [rbp-0x84]
       mov      dword ptr [rbp-0xC4], eax
       xor      eax, eax
       mov      dword ptr [rbp-0xC8], eax
 
G_M000_IG31:                ;; offset=0x0312
       mov      rcx, 0x7FF9D7A969F4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG32:                ;; offset=0x0321
       vmovdqu  xmm0, xmmword ptr [rbp-0xA8]
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
 
G_M000_IG33:                ;; offset=0x0331
       vmovdqu  xmm0, xmmword ptr [rbp-0xC0]
       vmovdqu  xmmword ptr [rbp-0x110], xmm0
       mov      rax, qword ptr [rbp-0xB0]
       mov      qword ptr [rbp-0x100], rax
 
G_M000_IG34:                ;; offset=0x034F
       mov      eax, dword ptr [rbp-0xC8]
       mov      dword ptr [rsp+0x20], eax
       lea      rdx, [rbp-0xF8]
       lea      r8, [rbp-0x110]
       mov      rcx, gword ptr [rbp-0x98]
       mov      r9d, dword ptr [rbp-0xC4]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:ConsumeBorrowedNativeLine(System.ReadOnlySpan`1[byte],System.Nullable`1[System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]],bool,int):int:this]
       mov      rcx, bword ptr [rbp-0x90]
       mov      dword ptr [rcx], eax
       mov      eax, 1
 
G_M000_IG35:                ;; offset=0x038B
       add      rsp, 320
       pop      rbp
       ret      
 
; Total bytes of code 916

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:TryDescribeLiteralRecord(System.ReadOnlySpan`1[byte],byref,bool):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 336
       lea      rbp, [rsp+0x150]
       xor      eax, eax
       mov      qword ptr [rbp-0x118], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x110], xmm4
       mov      rax, -192
 
G_M000_IG63:                ;; offset=0x002F
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG63
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
       mov      bword ptr [rbp+0x20], r8
       mov      dword ptr [rbp+0x28], r9d
 
G_M000_IG02:                ;; offset=0x005B
       mov      dword ptr [rbp-0xB4], 0x3E8
       mov      rax, gword ptr [rbp+0x10]
       cmp      gword ptr [rax+0x50], 0
       je       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0070
       mov      rcx, 0x7FF9D72AA220
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xB0], rax
       mov      rcx, gword ptr [rbp-0xB0]
       mov      rdx, 0x1A74A076428
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, gword ptr [rbp-0xB0]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG04:                ;; offset=0x00AA
       mov      rcx, bword ptr [rbp+0x18]
       call     [System.ReadOnlySpan`1[byte]:get_IsEmpty():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG05
       mov      rcx, 0x7FF9D7956EF0
       call     CORINFO_HELP_COUNTPROFILE32
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0xB8], eax
       jmp      G_M000_IG60
 
G_M000_IG05:                ;; offset=0x00DE
       mov      rax, bword ptr [rbp+0x20]
       mov      eax, dword ptr [rax]
       mov      dword ptr [rbp-0x3C], eax
       cmp      dword ptr [rbp-0x3C], 0
       jne      G_M000_IG11
       mov      rax, bword ptr [rbp+0x18]
       cmp      dword ptr [rax+0x08], 0
       jbe      G_M000_IG62
       mov      rax, bword ptr [rbp+0x18]
       mov      rax, bword ptr [rax]
       movzx    rax, byte  ptr [rax]
       mov      dword ptr [rbp-0x60], eax
       cmp      dword ptr [rbp-0x60], 10
       je       SHORT G_M000_IG07
       cmp      dword ptr [rbp-0x60], 13
       jne      SHORT G_M000_IG10
 
G_M000_IG06:                ;; offset=0x0118
       mov      rcx, 0x7FF9D7956EF4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG07:                ;; offset=0x0127
       mov      rcx, 0x7FF9D7956EF8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rax+0x18]
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG08:                ;; offset=0x0152
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
 
G_M000_IG09:                ;; offset=0x015E
       mov      rax, bword ptr [rbp+0x20]
       mov      bword ptr [rsp+0x20], rax
       lea      rdx, [rbp-0xC8]
       movzx    r9, byte  ptr [rbp+0x28]
       mov      rcx, gword ptr [rbp+0x10]
       xor      r8d, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:CompleteLiteralRecord(System.ReadOnlySpan`1[byte],int,bool,byref):this]
       jmp      G_M000_IG52
 
G_M000_IG10:                ;; offset=0x0185
       mov      rcx, 0x7FF9D7956EFC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG11:                ;; offset=0x0194
       mov      rax, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x30]
       mov      gword ptr [rbp-0x58], rax
       cmp      gword ptr [rbp-0x58], 0
       jne      SHORT G_M000_IG14
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
 
G_M000_IG12:                ;; offset=0x01B0
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0xA0], xmm0
 
G_M000_IG13:                ;; offset=0x01BD
       jmp      SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x01BF
       mov      rcx, 0x7FF9D7956F00
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdx, [rbp-0xA0]
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
 
G_M000_IG15:                ;; offset=0x01E1
       vmovdqu  xmm0, xmmword ptr [rbp-0xA0]
       vmovdqu  xmmword ptr [rbp-0x50], xmm0
 
G_M000_IG16:                ;; offset=0x01EE
       lea      rcx, [rbp-0x50]
       call     [System.ReadOnlySpan`1[byte]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG17
       cmp      dword ptr [rbp-0x48], 0
       jbe      G_M000_IG62
       mov      rax, bword ptr [rbp-0x50]
       movzx    rax, byte  ptr [rax]
       mov      dword ptr [rbp-0xA4], eax
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0215
       mov      rcx, 0x7FF9D7956F04
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xA4], -1
 
G_M000_IG18:                ;; offset=0x022E
       mov      eax, dword ptr [rbp-0xA4]
       mov      dword ptr [rbp-0x5C], eax
       mov      rax, gword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x60]
       cmp      eax, dword ptr [rbp-0x5C]
       je       SHORT G_M000_IG20
       cmp      dword ptr [rbp-0x5C], 10
       je       SHORT G_M000_IG22
       cmp      dword ptr [rbp-0x5C], 13
       jne      SHORT G_M000_IG21
 
G_M000_IG19:                ;; offset=0x024F
       mov      rcx, 0x7FF9D7956F08
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG20:                ;; offset=0x025E
       mov      dword ptr [rbp-0x5C], -1
       jmp      G_M000_IG55
 
G_M000_IG21:                ;; offset=0x026A
       mov      rcx, 0x7FF9D7956F0C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG55
 
G_M000_IG22:                ;; offset=0x027E
       mov      rcx, 0x7FF9D7956F10
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG20
 
G_M000_IG23:                ;; offset=0x028F
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x3C]
       jle      G_M000_IG37
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x3C], eax
       jae      G_M000_IG62
       mov      rax, bword ptr [rbp+0x18]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x3C]
       movzx    rax, byte  ptr [rax+rcx]
       mov      ecx, dword ptr [rbp-0x5C]
       cmp      eax, ecx
       jne      G_M000_IG36
       cmp      dword ptr [rbp-0x48], 1
       jne      G_M000_IG35
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG24:                ;; offset=0x02D6
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xD8], xmm0
 
G_M000_IG25:                ;; offset=0x02E2
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       lea      rdx, [rbp-0xD8]
       movzx    r9, byte  ptr [rbp-0x5C]
       mov      eax, dword ptr [rbp-0x3C]
       lea      r8d, [rax+0x01]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:FindLiteralQuote(System.ReadOnlySpan`1[byte],int,byte,bool):int:this]
       mov      dword ptr [rbp-0x8C], eax
       cmp      dword ptr [rbp-0x8C], 0
       jl       G_M000_IG34
       mov      eax, dword ptr [rbp-0x8C]
       inc      eax
       mov      dword ptr [rbp-0x74], eax
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       SHORT G_M000_IG27
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x74]
       je       G_M000_IG33
 
G_M000_IG26:                ;; offset=0x033D
       mov      rcx, 0x7FF9D7956F14
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG27:                ;; offset=0x034C
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x74]
       jle      SHORT G_M000_IG29
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x74], eax
       jae      G_M000_IG62
       mov      rax, bword ptr [rbp+0x18]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x74]
       movzx    rax, byte  ptr [rax+rcx]
       mov      rcx, gword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x60]
       cmp      eax, ecx
       je       G_M000_IG32
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x74], eax
       jae      G_M000_IG62
       mov      rax, bword ptr [rbp+0x18]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x74]
       movzx    rax, byte  ptr [rax+rcx]
       mov      dword ptr [rbp-0x60], eax
       cmp      dword ptr [rbp-0x60], 10
       je       SHORT G_M000_IG31
       cmp      dword ptr [rbp-0x60], 13
       jne      SHORT G_M000_IG30
 
G_M000_IG28:                ;; offset=0x03B2
       mov      rcx, 0x7FF9D7956F18
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG29:                ;; offset=0x03C1
       mov      rcx, 0x7FF9D7956F1C
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm3, xmm3, xmm3
       lea      rcx, [rbp-0x88]
       mov      eax, dword ptr [rbp-0x3C]
       lea      edx, [rax+0x01]
       mov      eax, dword ptr [rbp-0x8C]
       sub      eax, dword ptr [rbp-0x3C]
       lea      r8d, [rax-0x01]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField:.ctor(int,int,double):this]
       jmp      G_M000_IG44
 
G_M000_IG30:                ;; offset=0x03F9
       mov      rcx, 0x7FF9D7956F20
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG58
 
G_M000_IG31:                ;; offset=0x040D
       mov      rcx, 0x7FF9D7956F24
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG29
 
G_M000_IG32:                ;; offset=0x041E
       mov      rcx, 0x7FF9D7956F28
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG29
 
G_M000_IG33:                ;; offset=0x042F
       mov      rcx, 0x7FF9D7956F2C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG58
 
G_M000_IG34:                ;; offset=0x0443
       mov      rcx, 0x7FF9D7956F30
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG58
 
G_M000_IG35:                ;; offset=0x0457
       mov      rcx, 0x7FF9D7956F34
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG58
 
G_M000_IG36:                ;; offset=0x046B
       mov      rcx, 0x7FF9D7956F38
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG37:                ;; offset=0x047A
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG38:                ;; offset=0x047E
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xE8], xmm0
 
G_M000_IG39:                ;; offset=0x048A
       lea      rdx, [rbp-0xE8]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8d, dword ptr [rbp-0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:FindLiteralFieldEnd(System.ReadOnlySpan`1[byte],int):int:this]
       mov      dword ptr [rbp-0x74], eax
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       SHORT G_M000_IG41
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x74]
       je       G_M000_IG46
 
G_M000_IG40:                ;; offset=0x04BA
       mov      rcx, 0x7FF9D7956F3C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG41:                ;; offset=0x04C9
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG42:                ;; offset=0x04CD
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
 
G_M000_IG43:                ;; offset=0x04D9
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       lea      rax, [rbp-0x88]
       mov      qword ptr [rsp+0x28], rax
       lea      rdx, [rbp-0xF8]
       mov      eax, dword ptr [rbp-0x74]
       mov      r9d, eax
       sub      r9d, dword ptr [rbp-0x3C]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8d, dword ptr [rbp-0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:TryCreateLiteralBareField(System.ReadOnlySpan`1[byte],int,int,bool,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG45
 
G_M000_IG44:                ;; offset=0x0510
       vmovups  xmm0, xmmword ptr [rbp-0x88]
       vmovups  xmmword ptr [rbp-0x108], xmm0
       lea      rdx, [rbp-0x108]
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:DescribeField(Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField):this]
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x74]
       jne      SHORT G_M000_IG47
       mov      rcx, 0x7FF9D7956F40
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG52
 
G_M000_IG45:                ;; offset=0x0551
       mov      rcx, 0x7FF9D7956F44
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG58
 
G_M000_IG46:                ;; offset=0x0565
       mov      rcx, 0x7FF9D7956F48
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG58
 
G_M000_IG47:                ;; offset=0x0579
       mov      rax, bword ptr [rbp+0x18]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x74], eax
       jae      G_M000_IG62
       mov      rax, bword ptr [rbp+0x18]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x74]
       movzx    rax, byte  ptr [rax+rcx]
       mov      dword ptr [rbp-0x60], eax
       cmp      dword ptr [rbp-0x60], 10
       je       SHORT G_M000_IG49
       cmp      dword ptr [rbp-0x60], 13
       jne      SHORT G_M000_IG54
 
G_M000_IG48:                ;; offset=0x05A6
       mov      rcx, 0x7FF9D7956F4C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG49:                ;; offset=0x05B5
       mov      rcx, 0x7FF9D7956F50
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x18]
 
G_M000_IG50:                ;; offset=0x05C8
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x118], xmm0
 
G_M000_IG51:                ;; offset=0x05D4
       mov      rax, bword ptr [rbp+0x20]
       mov      bword ptr [rsp+0x20], rax
       lea      rdx, [rbp-0x118]
       movzx    r9, byte  ptr [rbp+0x28]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8d, dword ptr [rbp-0x74]
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:CompleteLiteralRecord(System.ReadOnlySpan`1[byte],int,bool,byref):this]
 
G_M000_IG52:                ;; offset=0x05F7
       mov      eax, 1
 
G_M000_IG53:                ;; offset=0x05FC
       add      rsp, 336
       pop      rbp
       ret      
 
G_M000_IG54:                ;; offset=0x0605
       mov      rcx, 0x7FF9D7956F54
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x74]
       inc      eax
       mov      dword ptr [rbp-0x3C], eax
 
G_M000_IG55:                ;; offset=0x061C
       mov      eax, dword ptr [rbp-0xB4]
       dec      eax
       mov      dword ptr [rbp-0xB4], eax
       cmp      dword ptr [rbp-0xB4], 0
       jg       SHORT G_M000_IG57
 
G_M000_IG56:                ;; offset=0x0633
       lea      rcx, [rbp-0xB4]
       mov      edx, 445
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG57:                ;; offset=0x0646
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x20]
       cmp      dword ptr [rcx], ecx
       call     [System.Collections.Generic.List`1[Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField]:get_Count():int:this]
       mov      dword ptr [rbp-0xA8], eax
       mov      rax, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x20]
       cmp      dword ptr [rcx], ecx
       call     [System.Collections.Generic.List`1[Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField]:get_Capacity():int:this]
       cmp      eax, dword ptr [rbp-0xA8]
       jg       G_M000_IG23
 
G_M000_IG58:                ;; offset=0x0678
       mov      rcx, 0x7FF9D7956F58
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x20]
       mov      ecx, dword ptr [rbp-0x3C]
       mov      dword ptr [rax], ecx
       xor      eax, eax
 
G_M000_IG59:                ;; offset=0x0692
       add      rsp, 336
       pop      rbp
       ret      
 
G_M000_IG60:                ;; offset=0x069B
       movzx    rax, byte  ptr [rbp-0xB8]
 
G_M000_IG61:                ;; offset=0x06A2
       add      rsp, 336
       pop      rbp
       ret      
 
G_M000_IG62:                ;; offset=0x06AB
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1713

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext+ChunkedTextFileReadState:TryConsumeBufferedCsvLine(Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource,System.Nullable`1[System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]],byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 128425
; 41 inlinees with PGO data; 78 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 376
       vmovaps  xmmword ptr [rsp+0x160], xmm6
       xor      eax, eax
       mov      qword ptr [rsp+0x68], rax
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -240
 
G_M000_IG144:                ;; offset=0x0031
       vmovdqa  xmmword ptr [rsp+rax+0x160], xmm4
       vmovdqa  xmmword ptr [rsp+rax+0x170], xmm4
       vmovdqa  xmmword ptr [rsp+rax+0x180], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG144
       mov      bword ptr [rsp+0x1D0], r8
       mov      rbx, rcx
       mov      rsi, rdx
       mov      rbp, r9
 
G_M000_IG02:                ;; offset=0x0063
       mov      bword ptr [rsp+0x1D8], rbp
       mov      dword ptr [rbp], -1
       mov      r14d, dword ptr [rbx+0x6C]
       lea      r15, bword ptr [rbx+0x78]
       xor      r13, r13
       xor      r12d, r12d
       mov      rcx, gword ptr [r15]
       test     rcx, rcx
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x0088
       mov      rdx, qword ptr [rcx]
       test     dword ptr [rdx], 0xFFFFFFFF80000000
       je       G_M000_IG92
       lea      r13, bword ptr [rcx+0x10]
       mov      r12d, dword ptr [rcx+0x08]
 
G_M000_IG04:                ;; offset=0x009F
       mov      ecx, dword ptr [r15+0x08]
       and      ecx, 0x7FFFFFFF
       mov      eax, dword ptr [r15+0x0C]
       mov      edx, eax
       add      rdx, rcx
       mov      r8d, r12d
       cmp      rdx, r8
       ja       G_M000_IG93
       add      r13, rcx
       mov      r12d, eax
 
G_M000_IG05:                ;; offset=0x00C4
       mov      r15, r13
       mov      bword ptr [rsp+0x38], r15
       mov      dword ptr [rsp+0xCC], r12d
       cmp      r14d, r12d
       je       G_M000_IG94
 
G_M000_IG06:                ;; offset=0x00DD
       xor      ecx, ecx
       mov      dword ptr [rsp+0x158], ecx
       mov      ecx, dword ptr [rbx+0x58]
       test     ecx, ecx
       je       SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x00ED
       cmp      ecx, 1
       jne      G_M000_IG131
 
G_M000_IG08:                ;; offset=0x00F6
       cmp      r14d, r12d
       ja       G_M000_IG93
       mov      r13d, r14d
       add      r13, r15
       mov      eax, r12d
       sub      eax, r14d
       mov      dword ptr [rsp+0x124], eax
       cmp      byte  ptr [rsi], sil
       xor      ecx, ecx
       mov      dword ptr [rsp+0x158], ecx
       mov      gword ptr [rsp+0x1C8], rsi
       mov      rdx, gword ptr [rsi+0x08]
       mov      gword ptr [rsp+0x60], rdx
       mov      r8, r13
       mov      bword ptr [rsp+0x30], r8
       mov      r10d, eax
       mov      dword ptr [rsp+0xC8], r10d
       cmp      gword ptr [rdx+0x50], 0
       jne      G_M000_IG96
       test     r10d, r10d
       je       G_M000_IG97
       mov      r9d, dword ptr [rsp+0x158]
       mov      dword ptr [rsp+0x120], r9d
       test     r9d, r9d
       jne      SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x016B
       movzx    r11, byte  ptr [r8]
       cmp      r11d, 10
       je       G_M000_IG98
       cmp      r11d, 13
       mov      r8, bword ptr [rsp+0x30]
       je       G_M000_IG98
 
G_M000_IG10:                ;; offset=0x0188
       mov      r13, gword ptr [rdx+0x30]
       test     r13, r13
       je       SHORT G_M000_IG16
 
G_M000_IG11:                ;; offset=0x0191
       movzx    rcx, byte  ptr [r13+0x24]
       test     ecx, ecx
       je       G_M000_IG100
 
G_M000_IG12:                ;; offset=0x019E
       cmp      ecx, 255
       je       G_M000_IG104
       lea      rax, bword ptr [r13+0x28]
       mov      r13d, dword ptr [r13+0x18]
       cmp      r13d, 8
       ja       G_M000_IG93
 
G_M000_IG13:                ;; offset=0x01BC
       mov      dword ptr [rsp+0xC4], r13d
       test     r13d, r13d
       je       G_M000_IG107
       movzx    rax, byte  ptr [rax]
 
G_M000_IG14:                ;; offset=0x01D0
       mov      rdx, gword ptr [rsp+0x60]
       cmp      eax, dword ptr [rdx+0x60]
       je       SHORT G_M000_IG17
 
G_M000_IG15:                ;; offset=0x01DA
       cmp      eax, 10
       je       SHORT G_M000_IG17
       cmp      eax, 13
       jne      G_M000_IG52
       jmp      SHORT G_M000_IG17
 
G_M000_IG16:                ;; offset=0x01EA
       xor      rax, rax
       xor      r13d, r13d
       jmp      SHORT G_M000_IG13
       align    [0 bytes for IG38]
 
G_M000_IG17:                ;; offset=0x01F1
       mov      eax, -1
       jmp      G_M000_IG52
 
G_M000_IG18:                ;; offset=0x01FB
       cmp      r13d, 1
       jne      G_M000_IG108
       mov      dword ptr [rsp+0x120], r9d
       lea      r11d, [r9+0x01]
       mov      dword ptr [rsp+0x11C], eax
       movzx    rcx, al
       mov      dword ptr [rsp+0xFC], ecx
       mov      dword ptr [rsp+0x100], r11d
       cmp      r11d, r10d
       jge      G_M000_IG113
 
G_M000_IG19:                ;; offset=0x0233
       mov      r15, gword ptr [rdx+0x10]
       mov      r13, gword ptr [rdx+0x18]
       mov      gword ptr [rsp+0x48], r13
       mov      r15, gword ptr [r15+0x98]
       mov      r13, gword ptr [r15+0x88]
       cmp      gword ptr [r13+0x20], 0
       jne      G_M000_IG110
       mov      r13, gword ptr [r15+0x180]
       test     r13, r13
       jne      G_M000_IG109
 
G_M000_IG20:                ;; offset=0x0269
       mov      r10d, dword ptr [rsp+0xC8]
       mov      r11d, dword ptr [rsp+0x100]
       mov      r15d, r10d
       sub      r15d, r11d
       cmp      r15d, 0x1000
       jge      G_M000_IG28
 
G_M000_IG21:                ;; offset=0x028C
       mov      r13d, r11d
       mov      edi, r15d
       add      rdi, r13
       mov      r13d, r10d
       cmp      rdi, r13
       ja       G_M000_IG93
       mov      dword ptr [rsp+0x100], r11d
       mov      edi, r11d
       add      rdi, bword ptr [rsp+0x30]
       mov      dword ptr [rsp+0x20], r15d
       mov      rcx, rdi
       mov      edx, dword ptr [rsp+0xFC]
       mov      r8d, 13
       mov      r9d, 10
       call     [System.SpanHelpers:NonPackedIndexOfAnyValueType[byte,System.SpanHelpers+DontNegate`1[byte]](byref,byte,byte,byte,int):int]
       test     eax, eax
       jl       G_M000_IG111
 
G_M000_IG22:                ;; offset=0x02DA
       cmp      eax, r15d
       jae      G_M000_IG142
       mov      ecx, eax
       movzx    rcx, byte  ptr [rdi+rcx]
       mov      edi, dword ptr [rsp+0xFC]
       cmp      ecx, edi
       jne      G_M000_IG112
       mov      r13d, dword ptr [rsp+0x100]
       add      eax, r13d
 
G_M000_IG23:                ;; offset=0x0303
       test     eax, eax
       jl       G_M000_IG129
 
G_M000_IG24:                ;; offset=0x030B
       lea      r11d, [rax+0x01]
       mov      r10d, dword ptr [rsp+0xC8]
       cmp      r11d, r10d
       je       G_M000_IG129
       jge      SHORT G_M000_IG27
 
G_M000_IG25:                ;; offset=0x0322
       cmp      r11d, r10d
       jae      G_M000_IG142
       mov      ecx, r11d
       mov      r8, bword ptr [rsp+0x30]
       movzx    rcx, byte  ptr [r8+rcx]
       mov      rdx, gword ptr [rsp+0x60]
       cmp      ecx, dword ptr [rdx+0x60]
       je       SHORT G_M000_IG29
 
G_M000_IG26:                ;; offset=0x0342
       cmp      ecx, 10
       jne      G_M000_IG114
 
G_M000_IG27:                ;; offset=0x034B
       mov      r9d, dword ptr [rsp+0x120]
       lea      ecx, [r9+0x01]
       sub      eax, r9d
       dec      eax
       vxorps   xmm6, xmm6, xmm6
       mov      dword ptr [rsp+0x118], r11d
       mov      esi, ecx
       mov      edi, eax
       mov      r15d, r10d
       mov      rdx, gword ptr [rsp+0x60]
       jmp      G_M000_IG47
 
G_M000_IG28:                ;; offset=0x0379
       mov      r15d, 0x1000
       jmp      G_M000_IG21
 
G_M000_IG29:                ;; offset=0x0384
       jmp      SHORT G_M000_IG27
 
G_M000_IG30:                ;; offset=0x0386
       mov      r15d, 0x1000
 
G_M000_IG31:                ;; offset=0x038C
       mov      ecx, r11d
       mov      r13d, r15d
       add      rcx, r13
       mov      r13d, r10d
       cmp      rcx, r13
       ja       G_M000_IG93
       mov      dword ptr [rsp+0xF8], r11d
       mov      ecx, r11d
       add      rcx, r8
       mov      rdx, gword ptr [rsp+0x60]
       mov      r13, gword ptr [rdx+0x40]
       test     r13, r13
       je       G_M000_IG128
       mov      rdi, 0x7FF9D748EAE8
       cmp      qword ptr [r13], rdi
       jne      G_M000_IG118
       mov      dword ptr [rsp+0x11C], eax
       mov      dword ptr [rsp+0x20], r15d
       movzx    r9, byte  ptr [r13+0x0A]
       movzx    rdx, byte  ptr [r13+0x08]
       movzx    r8, byte  ptr [r13+0x09]
       call     [System.SpanHelpers:NonPackedIndexOfAnyValueType[byte,System.SpanHelpers+DontNegate`1[byte]](byref,byte,byte,byte,int):int]
 
G_M000_IG32:                ;; offset=0x03F6
       test     eax, eax
       jl       G_M000_IG119
 
G_M000_IG33:                ;; offset=0x03FE
       mov      edi, dword ptr [rsp+0xF8]
       add      eax, edi
       mov      r11d, eax
 
G_M000_IG34:                ;; offset=0x040A
       mov      r10d, r11d
       mov      r15d, dword ptr [rsp+0xC8]
       cmp      r10d, r15d
       je       G_M000_IG129
 
G_M000_IG35:                ;; offset=0x041E
       mov      dword ptr [rsp+0x118], r10d
       mov      r9d, dword ptr [rsp+0x120]
       mov      ecx, r10d
       sub      ecx, r9d
       mov      rdx, gword ptr [rsp+0x60]
       mov      r11, gword ptr [rdx+0x08]
       cmp      dword ptr [r11+0x28], 2
       jne      G_M000_IG64
 
G_M000_IG36:                ;; offset=0x0448
       test     ecx, ecx
       je       G_M000_IG64
       mov      r11d, r9d
       mov      r13d, ecx
       add      r11, r13
       mov      r13d, r15d
       cmp      r11, r13
       ja       G_M000_IG93
       mov      r11d, r9d
       add      r11, bword ptr [rsp+0x30]
       movzx    r13, byte  ptr [r11]
       cmp      r13d, 45
       sete     dil
       movzx    rdi, dil
       mov      dword ptr [rsp+0xF4], edi
       cmp      r13d, 43
       je       G_M000_IG122
       cmp      r13d, 45
       setne    r13b
       movzx    r13, r13b
 
G_M000_IG37:                ;; offset=0x049A
       test     r13d, r13d
       sete     r13b
       movzx    r13, r13b
       mov      ebp, ecx
       sub      ebp, r13d
       mov      edi, ebp
       sub      edi, 1
       cmp      edi, 16
       ja       G_M000_IG123
       xor      edi, edi
       mov      r12d, -1
       cmp      r13d, ecx
       jge      SHORT G_M000_IG41
 
G_M000_IG38:                ;; offset=0x04C5
       movzx    rsi, byte  ptr [r11+r13]
       add      esi, -48
       cmp      esi, 9
       ja       G_M000_IG60
 
G_M000_IG39:                ;; offset=0x04D6
       lea      rdi, [rdi+4*rdi]
       mov      esi, esi
       lea      rdi, [rsi+2*rdi]
 
G_M000_IG40:                ;; offset=0x04E0
       inc      r13d
       cmp      r13d, ecx
       jl       SHORT G_M000_IG38
 
G_M000_IG41:                ;; offset=0x04E8
       cmp      ebp, 1
       je       G_M000_IG61
 
G_M000_IG42:                ;; offset=0x04F1
       mov      r11, 0x20000000000000
       cmp      rdi, r11
       mov      dword ptr [rsp+0x120], r9d
       ja       G_M000_IG129
       test     r12d, r12d
       jl       G_M000_IG62
 
G_M000_IG43:                ;; offset=0x0515
       sub      ecx, r12d
       dec      ecx
 
G_M000_IG44:                ;; offset=0x051A
       vxorps   xmm0, xmm0, xmm0
       mov      r11, rdi
       shr      r11, 1
       mov      r9d, edi
       and      r9d, 1
       or       r9, r11
       test     rdi, rdi
       cmovns   r9, rdi
       vcvtsi2sd xmm0, r9
       jns      SHORT G_M000_IG45
       vaddsd   xmm0, xmm0
 
G_M000_IG45:                ;; offset=0x0540
       cmp      ecx, 19
       jae      G_M000_IG142
       mov      ecx, ecx
       mov      r9, 0x1C75878C440
       vdivsd   xmm6, xmm0, qword ptr [r9+8*rcx]
       cmp      dword ptr [rsp+0xF4], 0
       jne      G_M000_IG63
 
G_M000_IG46:                ;; offset=0x0569
       mov      esi, -1
       xor      ecx, ecx
       xor      edi, edi
 
G_M000_IG47:                ;; offset=0x0572
       mov      rcx, gword ptr [rdx+0x20]
       inc      dword ptr [rcx+0x14]
       mov      r9, gword ptr [rcx+0x08]
       mov      r11d, dword ptr [rcx+0x10]
       mov      r13d, dword ptr [r9+0x08]
       cmp      r13d, r11d
       jbe      G_M000_IG127
       lea      r13d, [r11+0x01]
       mov      dword ptr [rcx+0x10], r13d
       mov      ecx, r11d
       shl      rcx, 4
       lea      rcx, bword ptr [r9+rcx+0x10]
       mov      dword ptr [rcx], esi
       mov      dword ptr [rcx+0x04], edi
       vmovsd   qword ptr [rcx+0x08], xmm6
 
G_M000_IG48:                ;; offset=0x05AC
       test     esi, esi
       jl       SHORT G_M000_IG50
 
G_M000_IG49:                ;; offset=0x05B0
       test     edi, edi
       je       SHORT G_M000_IG50
       movsxd   rcx, edi
       add      rcx, 128
       mov      rdx, gword ptr [rsp+0x60]
       add      rcx, qword ptr [rdx+0x58]
       jo       G_M000_IG143
       mov      qword ptr [rdx+0x58], rcx
       cmp      edi, 8
       jg       G_M000_IG65
 
G_M000_IG50:                ;; offset=0x05DA
       mov      r10d, dword ptr [rsp+0x118]
       cmp      r10d, r15d
       je       G_M000_IG68
       cmp      r10d, r15d
       jae      G_M000_IG142
       mov      ecx, r10d
       mov      r8, bword ptr [rsp+0x30]
       movzx    rsi, byte  ptr [r8+rcx]
       mov      ecx, esi
       cmp      ecx, 10
       je       G_M000_IG66
 
G_M000_IG51:                ;; offset=0x060C
       cmp      ecx, 13
       je       G_M000_IG66
       lea      r9d, [r10+0x01]
       mov      esi, r9d
       mov      dword ptr [rsp+0x120], esi
       mov      eax, dword ptr [rsp+0x11C]
       mov      rdx, gword ptr [rsp+0x60]
       mov      r13d, dword ptr [rsp+0xC4]
 
G_M000_IG52:                ;; offset=0x0637
       mov      rcx, gword ptr [rdx+0x20]
       mov      r11d, dword ptr [rcx+0x10]
       mov      rcx, gword ptr [rcx+0x08]
       cmp      r11d, dword ptr [rcx+0x08]
       jge      G_M000_IG129
 
G_M000_IG53:                ;; offset=0x064D
       mov      r9d, dword ptr [rsp+0x120]
       mov      r10d, dword ptr [rsp+0xC8]
       cmp      r9d, r10d
       jge      SHORT G_M000_IG56
 
G_M000_IG54:                ;; offset=0x0662
       cmp      r9d, r10d
       jae      G_M000_IG142
       mov      ecx, r9d
       movzx    rcx, byte  ptr [r8+rcx]
       cmp      ecx, eax
       je       G_M000_IG18
 
G_M000_IG55:                ;; offset=0x067B
       mov      r8, bword ptr [rsp+0x30]
 
G_M000_IG56:                ;; offset=0x0680
       mov      dword ptr [rsp+0x120], r9d
       mov      r11d, r9d
       mov      dword ptr [rsp+0xF8], r11d
       cmp      r11d, r10d
       jge      G_M000_IG121
 
G_M000_IG57:                ;; offset=0x069C
       mov      rcx, gword ptr [rdx+0x10]
       mov      r15, gword ptr [rdx+0x18]
       mov      rcx, gword ptr [rcx+0x98]
       mov      r13, gword ptr [rcx+0x88]
       cmp      gword ptr [r13+0x20], 0
       jne      G_M000_IG116
       mov      r13, gword ptr [rcx+0x180]
       test     r13, r13
       jne      G_M000_IG115
 
G_M000_IG58:                ;; offset=0x06CD
       mov      r10d, dword ptr [rsp+0xC8]
       mov      r11d, dword ptr [rsp+0xF8]
       mov      r15d, r10d
       sub      r15d, r11d
       cmp      r15d, 0x1000
       jge      G_M000_IG30
 
G_M000_IG59:                ;; offset=0x06F0
       jmp      G_M000_IG31
 
G_M000_IG60:                ;; offset=0x06F5
       cmp      byte  ptr [r11+r13], 46
       jne      G_M000_IG126
       test     r12d, r12d
       jge      G_M000_IG125
       mov      r12d, r13d
       jmp      G_M000_IG40
 
G_M000_IG61:                ;; offset=0x0711
       test     r12d, r12d
       jge      G_M000_IG124
       jmp      G_M000_IG42
 
G_M000_IG62:                ;; offset=0x071F
       xor      ecx, ecx
       jmp      G_M000_IG44
 
G_M000_IG63:                ;; offset=0x0726
       vxorps   xmm6, xmm6, xmmword ptr [reloc @RWD00]
       jmp      G_M000_IG46
 
G_M000_IG64:                ;; offset=0x0733
       mov      r11d, ecx
       vxorps   xmm6, xmm6, xmm6
       mov      esi, r9d
       mov      edi, r11d
       jmp      G_M000_IG47
 
G_M000_IG65:                ;; offset=0x0745
       add      edi, dword ptr [rdx+0x68]
       jo       G_M000_IG143
       mov      dword ptr [rdx+0x68], edi
       jmp      G_M000_IG50
 
G_M000_IG66:                ;; offset=0x0756
       lea      ecx, [r10+0x01]
       cmp      esi, 13
       je       G_M000_IG130
 
G_M000_IG67:                ;; offset=0x0763
       mov      dword ptr [rsp+0x158], ecx
 
G_M000_IG68:                ;; offset=0x076A
       mov      r13d, 1
 
G_M000_IG69:                ;; offset=0x0770
       test     r13d, r13d
       jne      G_M000_IG85
 
G_M000_IG70:                ;; offset=0x0779
       mov      r15, bword ptr [rsp+0x38]
       mov      bword ptr [rsp+0xA0], r15
       mov      r12d, dword ptr [rsp+0xCC]
       mov      dword ptr [rsp+0xA8], r12d
       lea      rcx, [rsp+0xA0]
       mov      edx, r14d
       add      edx, dword ptr [rsp+0x158]
       mov      r8d, dword ptr [rbx+0x58]
       call     [Lokad.Lython.Runtime.Text.TextLineScanning:FindLineEndByte(System.ReadOnlySpan`1[byte],int,int):int]
 
G_M000_IG71:                ;; offset=0x07B2
       mov      dword ptr [rsp+0x154], eax
       cmp      eax, r12d
       je       G_M000_IG132
 
G_M000_IG72:                ;; offset=0x07C2
       lea      r8, bword ptr [rbx+0x78]
       mov      bword ptr [rsp+0x40], r8
       mov      rcx, gword ptr [r8]
       test     rcx, rcx
       je       SHORT G_M000_IG75
 
G_M000_IG73:                ;; offset=0x07D3
       mov      rdx, qword ptr [rcx]
       test     dword ptr [rdx], 0xFFFFFFFF80000000
       je       G_M000_IG135
       mov      r10d, dword ptr [rcx+0x08]
 
G_M000_IG74:                ;; offset=0x07E6
       mov      r8, bword ptr [rsp+0x40]
       mov      ecx, dword ptr [r8+0x08]
       and      ecx, 0x7FFFFFFF
       mov      edx, dword ptr [r8+0x0C]
       add      rcx, rdx
       mov      edx, r10d
       cmp      rcx, rdx
       ja       G_M000_IG93
 
G_M000_IG75:                ;; offset=0x0808
       mov      eax, dword ptr [rsp+0x154]
       mov      ecx, eax
       sub      ecx, dword ptr [rbx+0x6C]
       movsxd   rcx, ecx
       add      qword ptr [rbx+0x48], rcx
       mov      dword ptr [rsp+0x154], eax
       mov      dword ptr [rbx+0x6C], eax
       mov      rcx, gword ptr [rbx+0x30]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG137
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG136
 
G_M000_IG76:                ;; offset=0x084B
       mov      eax, dword ptr [rsp+0x154]
       mov      ebx, eax
       sub      ebx, r14d
       mov      ecx, r14d
       mov      edx, ebx
       add      rcx, rdx
       mov      edx, r12d
       cmp      rcx, rdx
       ja       G_M000_IG93
       mov      r14d, r14d
       add      r14, r15
 
G_M000_IG77:                ;; offset=0x0871
       mov      rdi, bword ptr [rsp+0x1D0]
       vmovdqu  xmm0, xmmword ptr [rdi]
       vmovdqu  xmmword ptr [rsp+0x138], xmm0
       mov      rcx, qword ptr [rdi+0x10]
       mov      qword ptr [rsp+0x148], rcx
 
G_M000_IG78:                ;; offset=0x0892
       xor      edi, edi
       test     r13d, r13d
       cmove    edi, dword ptr [rsp+0x158]
       mov      rsi, gword ptr [rsp+0x1C8]
       mov      rcx, gword ptr [rsi+0x28]
       mov      rdx, gword ptr [rsi+0x30]
       mov      rcx, gword ptr [rcx+0x98]
       mov      rax, gword ptr [rcx+0x88]
       cmp      gword ptr [rax+0x20], 0
       jne      G_M000_IG139
       mov      rax, gword ptr [rcx+0x180]
       test     rax, rax
       jne      G_M000_IG138
 
G_M000_IG79:                ;; offset=0x08D8
       inc      dword ptr [rsi+0x3C]
       test     r13d, r13d
       jne      G_M000_IG86
 
G_M000_IG80:                ;; offset=0x08E4
       mov      rcx, gword ptr [rsi+0x08]
       mov      bword ptr [rsp+0xA0], r14
       mov      dword ptr [rsp+0xA8], ebx
 
G_M000_IG81:                ;; offset=0x08F7
       vmovdqu  xmm0, xmmword ptr [rsp+0x138]
       vmovdqu  xmmword ptr [rsp+0x68], xmm0
       mov      rdx, qword ptr [rsp+0x148]
       mov      qword ptr [rsp+0x78], rdx
 
G_M000_IG82:                ;; offset=0x0913
       lea      rdx, [rsp+0xA0]
       lea      r8, [rsp+0x68]
       mov      r9d, edi
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:ConsumeBorrowedLine(System.ReadOnlySpan`1[byte],System.Nullable`1[System.Memory`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]],int):int:this]
 
G_M000_IG83:                ;; offset=0x092B
       mov      rbp, bword ptr [rsp+0x1D8]
       mov      dword ptr [rbp], eax
       mov      eax, 1
 
G_M000_IG84:                ;; offset=0x093B
       vmovaps  xmm6, xmmword ptr [rsp+0x160]
       add      rsp, 376
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG85:                ;; offset=0x0958
       mov      eax, r14d
       add      eax, dword ptr [rsp+0x158]
       mov      r12d, dword ptr [rsp+0xCC]
       mov      r15, bword ptr [rsp+0x38]
       jmp      G_M000_IG71
 
G_M000_IG86:                ;; offset=0x0974
       mov      rsi, gword ptr [rsi+0x08]
       movzx    rdx, byte  ptr [rsp+0x138]
       mov      rcx, gword ptr [rsp+0x140]
       mov      edi, dword ptr [rsp+0x148]
       mov      r15d, dword ptr [rsp+0x14C]
       cmp      byte  ptr [rsi], sil
       test     edx, edx
       je       G_M000_IG141
 
G_M000_IG87:                ;; offset=0x09A2
       xor      r13, r13
       xor      r12d, r12d
       test     rcx, rcx
       je       SHORT G_M000_IG90
 
G_M000_IG88:                ;; offset=0x09AD
       mov      rdx, qword ptr [rcx]
       test     dword ptr [rdx], 0xFFFFFFFF80000000
       je       G_M000_IG140
       lea      r13, bword ptr [rcx+0x10]
       mov      r12d, dword ptr [rcx+0x08]
 
G_M000_IG89:                ;; offset=0x09C4
       and      edi, 0x7FFFFFFF
       mov      edx, edi
       mov      r8d, r15d
       add      r8, rdx
       mov      ecx, r12d
       cmp      r8, rcx
       ja       SHORT G_M000_IG93
       shl      rdx, 4
       add      r13, rdx
       mov      r12d, r15d
 
G_M000_IG90:                ;; offset=0x09E4
       mov      bword ptr [rsp+0xA0], r14
       mov      dword ptr [rsp+0xA8], ebx
       mov      bword ptr [rsp+0x80], r13
       mov      dword ptr [rsp+0x88], r12d
       lea      rdx, [rsp+0xA0]
       lea      r8, [rsp+0x80]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:UnpackRecord(System.ReadOnlySpan`1[byte],System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int:this]
 
G_M000_IG91:                ;; offset=0x0A1C
       jmp      G_M000_IG83
 
G_M000_IG92:                ;; offset=0x0A21
       lea      rdx, [rsp+0x128]
       mov      rax, qword ptr [rcx]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x28]System.Buffers.MemoryManager`1[byte]:GetSpan():System.Span`1[byte]:this
       mov      r13, bword ptr [rsp+0x128]
       mov      r12d, dword ptr [rsp+0x130]
       jmp      G_M000_IG04
 
G_M000_IG93:                ;; offset=0x0A48
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG94:                ;; offset=0x0A4F
       xor      eax, eax
 
G_M000_IG95:                ;; offset=0x0A51
       vmovaps  xmm6, xmmword ptr [rsp+0x160]
       add      rsp, 376
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG96:                ;; offset=0x0A6E
       mov      rcx, 0x7FF9D72AA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x1A74A076428
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG97:                ;; offset=0x0A9C
       xor      r13d, r13d
       jmp      G_M000_IG69
 
G_M000_IG98:                ;; offset=0x0AA4
       mov      rcx, gword ptr [rdx+0x10]
       mov      r8, gword ptr [rdx+0x18]
       mov      gword ptr [rsp+0x58], r8
       mov      r10, gword ptr [rcx+0x98]
       mov      gword ptr [rsp+0x50], r10
       cmp      byte  ptr [r10], r10b
       mov      rcx, r10
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG99
       mov      rcx, gword ptr [rsp+0x50]
       mov      rdx, gword ptr [rsp+0x58]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG99:                ;; offset=0x0ADD
       mov      bword ptr [rsp+0xA0], r13
       mov      r13d, dword ptr [rsp+0x124]
       mov      dword ptr [rsp+0xA8], r13d
       lea      rdx, [rsp+0x158]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rsp+0xA0]
       mov      rcx, gword ptr [rsp+0x60]
       xor      r8d, r8d
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:CompleteLiteralRecord(System.ReadOnlySpan`1[byte],int,bool,byref):this]
       jmp      G_M000_IG68
 
G_M000_IG100:                ;; offset=0x0B23
       mov      rax, gword ptr [r13+0x08]
       mov      r13d, dword ptr [r13+0x18]
       test     rax, rax
       jne      SHORT G_M000_IG102
 
G_M000_IG101:                ;; offset=0x0B30
       test     r13d, r13d
       jne      G_M000_IG93
       xor      rax, rax
       xor      r13d, r13d
       jmp      SHORT G_M000_IG103
 
G_M000_IG102:                ;; offset=0x0B40
       cmp      dword ptr [rax+0x08], r13d
       jb       G_M000_IG93
       add      rax, 16
 
G_M000_IG103:                ;; offset=0x0B4E
       jmp      G_M000_IG13
 
G_M000_IG104:                ;; offset=0x0B53
       mov      rcx, gword ptr [r13+0x08]
       lea      rax, bword ptr [r13+0x28]
       mov      eax, dword ptr [rax]
       mov      r11d, dword ptr [r13+0x18]
       mov      dword ptr [rsp+0x104], r11d
       test     rcx, rcx
       jne      SHORT G_M000_IG105
       or       eax, r11d
       jne      G_M000_IG93
       xor      rcx, rcx
       xor      r11d, r11d
       jmp      SHORT G_M000_IG106
 
G_M000_IG105:                ;; offset=0x0B7E
       mov      r13d, eax
       mov      r11d, r11d
       add      r11, r13
       mov      r13d, dword ptr [rcx+0x08]
       cmp      r11, r13
       ja       G_M000_IG93
       mov      eax, eax
       lea      rcx, bword ptr [rcx+rax+0x10]
       mov      r11d, dword ptr [rsp+0x104]
 
G_M000_IG106:                ;; offset=0x0BA3
       mov      bword ptr [rsp+0xB0], rcx
       mov      dword ptr [rsp+0xB8], r11d
       lea      rdx, [rsp+0xB0]
       lea      rcx, [rsp+0x108]
       call     [System.Span`1[byte]:op_Implicit(System.Span`1[byte]):System.ReadOnlySpan`1[byte]]
       mov      rax, bword ptr [rsp+0x108]
       mov      r13d, dword ptr [rsp+0x110]
       mov      r8, bword ptr [rsp+0x30]
       jmp      G_M000_IG13
 
G_M000_IG107:                ;; offset=0x0BE3
       mov      eax, -1
       jmp      G_M000_IG14
 
G_M000_IG108:                ;; offset=0x0BED
       mov      dword ptr [rsp+0x120], r9d
       jmp      G_M000_IG129
 
G_M000_IG109:                ;; offset=0x0BFA
       cmp      dword ptr [r13+0x20], 0
       setne    r13b
       movzx    r13, r13b
       test     r13d, r13d
       je       G_M000_IG20
 
G_M000_IG110:                ;; offset=0x0C10
       mov      rcx, r15
       mov      rdx, gword ptr [rsp+0x48]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG20
 
G_M000_IG111:                ;; offset=0x0C23
       mov      r13d, dword ptr [rsp+0x100]
       add      r13d, r15d
       mov      edi, dword ptr [rsp+0xC8]
       cmp      r13d, edi
       mov      dword ptr [rsp+0x100], r13d
       mov      rdx, gword ptr [rsp+0x60]
       jl       G_M000_IG19
       jmp      SHORT G_M000_IG113
 
G_M000_IG112:                ;; offset=0x0C4D
       mov      rdx, gword ptr [rsp+0x60]
 
G_M000_IG113:                ;; offset=0x0C52
       mov      r11d, -1
       mov      eax, r11d
       jmp      G_M000_IG23
 
G_M000_IG114:                ;; offset=0x0C60
       cmp      ecx, 13
       jne      G_M000_IG129
       jmp      G_M000_IG27
 
G_M000_IG115:                ;; offset=0x0C6E
       cmp      dword ptr [r13+0x20], 0
       setne    r13b
       movzx    r13, r13b
       test     r13d, r13d
       je       G_M000_IG58
       mov      dword ptr [rsp+0x11C], eax
       jmp      SHORT G_M000_IG117
 
G_M000_IG116:                ;; offset=0x0C8D
       mov      dword ptr [rsp+0x11C], eax
 
G_M000_IG117:                ;; offset=0x0C94
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      eax, dword ptr [rsp+0x11C]
       mov      r8, bword ptr [rsp+0x30]
       jmp      G_M000_IG58
 
G_M000_IG118:                ;; offset=0x0CAE
       mov      dword ptr [rsp+0x11C], eax
       mov      bword ptr [rsp+0xA0], rcx
       mov      dword ptr [rsp+0xA8], r15d
       lea      rdx, [rsp+0xA0]
       mov      rcx, r13
       mov      rdi, qword ptr [r13]
       mov      rdi, qword ptr [rdi+0x40]
       call     [rdi+0x30]System.Buffers.SearchValues`1[byte]:IndexOfAny(System.ReadOnlySpan`1[byte]):int:this
       jmp      G_M000_IG32
 
G_M000_IG119:                ;; offset=0x0CE0
       mov      edi, dword ptr [rsp+0xF8]
       add      edi, r15d
       mov      r15d, dword ptr [rsp+0xC8]
       cmp      edi, r15d
       mov      dword ptr [rsp+0xF8], edi
       mov      eax, dword ptr [rsp+0x11C]
       mov      rdx, gword ptr [rsp+0x60]
       mov      r8, bword ptr [rsp+0x30]
       jl       G_M000_IG57
 
G_M000_IG120:                ;; offset=0x0D13
       mov      r13d, dword ptr [rsp+0xC4]
 
G_M000_IG121:                ;; offset=0x0D1B
       mov      r11d, dword ptr [rsp+0xF8]
       mov      dword ptr [rsp+0x11C], eax
       jmp      G_M000_IG34
 
G_M000_IG122:                ;; offset=0x0D2F
       xor      r13d, r13d
       jmp      G_M000_IG37
 
G_M000_IG123:                ;; offset=0x0D37
       mov      dword ptr [rsp+0x120], r9d
       jmp      SHORT G_M000_IG129
 
G_M000_IG124:                ;; offset=0x0D41
       mov      dword ptr [rsp+0x120], r9d
       jmp      SHORT G_M000_IG129
 
G_M000_IG125:                ;; offset=0x0D4B
       mov      dword ptr [rsp+0x120], r9d
       jmp      SHORT G_M000_IG129
 
G_M000_IG126:                ;; offset=0x0D55
       mov      dword ptr [rsp+0x120], r9d
       jmp      SHORT G_M000_IG129
 
G_M000_IG127:                ;; offset=0x0D5F
       mov      dword ptr [rsp+0x90], esi
       mov      dword ptr [rsp+0x94], edi
       vmovsd   qword ptr [rsp+0x98], xmm6
       lea      rdx, [rsp+0x90]
       call     [System.Collections.Generic.List`1[Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField]:AddWithResize(Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField):this]
       jmp      G_M000_IG48
 
G_M000_IG128:                ;; offset=0x0D89
       mov      ecx, 6
       call     [System.ThrowHelper:ThrowArgumentNullException(int)]
       int3     
 
G_M000_IG129:                ;; offset=0x0D95
       mov      r9d, dword ptr [rsp+0x120]
       mov      dword ptr [rsp+0x158], r9d
       jmp      G_M000_IG97
 
G_M000_IG130:                ;; offset=0x0DAA
       cmp      ecx, r15d
       jge      G_M000_IG67
       cmp      ecx, r15d
       jae      G_M000_IG142
       mov      edx, ecx
       cmp      byte  ptr [r8+rdx], 10
       jne      G_M000_IG67
       inc      ecx
       jmp      G_M000_IG67
 
G_M000_IG131:                ;; offset=0x0DD0
       xor      r13d, r13d
       mov      gword ptr [rsp+0x1C8], rsi
       jmp      G_M000_IG69
 
G_M000_IG132:                ;; offset=0x0DE0
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext+ChunkedTextFileReadState:EndsWithTerminator():bool:this]
       test     eax, eax
       jne      G_M000_IG72
 
G_M000_IG133:                ;; offset=0x0DF1
       test     r13d, r13d
       jne      SHORT G_M000_IG134
       cmp      dword ptr [rsp+0x158], 0
       je       G_M000_IG94
 
G_M000_IG134:                ;; offset=0x0E04
       mov      rsi, gword ptr [rsp+0x1C8]
       mov      rcx, gword ptr [rsi+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:ResetRecord():this]
       jmp      G_M000_IG94
 
G_M000_IG135:                ;; offset=0x0E1D
       lea      rdx, [rsp+0xE0]
       mov      r10, qword ptr [rcx]
       mov      r10, qword ptr [r10+0x40]
       call     [r10+0x28]System.Buffers.MemoryManager`1[byte]:GetSpan():System.Span`1[byte]:this
       mov      r10d, dword ptr [rsp+0xE8]
       jmp      G_M000_IG74
 
G_M000_IG136:                ;; offset=0x0E3D
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG76
 
G_M000_IG137:                ;; offset=0x0E4F
       xor      rdx, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG76
 
G_M000_IG138:                ;; offset=0x0E5C
       cmp      dword ptr [rax+0x20], 0
       setne    al
       movzx    rax, al
       test     eax, eax
       je       G_M000_IG79
 
G_M000_IG139:                ;; offset=0x0E6E
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG79
 
G_M000_IG140:                ;; offset=0x0E79
       lea      rdx, [rsp+0xD0]
       mov      rax, qword ptr [rcx]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x28]System.Buffers.MemoryManager`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:GetSpan():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this
       mov      r13, bword ptr [rsp+0xD0]
       mov      r12d, dword ptr [rsp+0xD8]
       jmp      G_M000_IG89
 
G_M000_IG141:                ;; offset=0x0EA0
       mov      bword ptr [rsp+0xA0], r14
       mov      dword ptr [rsp+0xA8], ebx
       lea      rdx, [rsp+0xA0]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:EmitRecord(System.ReadOnlySpan`1[byte]):this]
       mov      eax, -1
       jmp      G_M000_IG91
 
G_M000_IG142:                ;; offset=0x0ECA
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG143:                ;; offset=0x0ED0
       call     CORINFO_HELP_OVERFLOW
       int3     
 
RWD00  	dq	8000000000000000h, 8000000000000000h

; Total bytes of code 3798

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:TryDescribeLiteralRecord(System.ReadOnlySpan`1[byte],byref,bool):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rsp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 256704
; 30 inlinees with PGO data; 53 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 200
       vmovaps  xmmword ptr [rsp+0xB0], xmm6
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x50], ymm4
       vmovdqu  ymmword ptr [rsp+0x70], ymm4
       xor      eax, eax
       mov      qword ptr [rsp+0x90], rax
       mov      rbx, rcx
       mov      rdi, r8
       mov      esi, r9d
 
G_M000_IG02:                ;; offset=0x003F
       mov      rbp, bword ptr [rdx]
       mov      r14d, dword ptr [rdx+0x08]
       cmp      gword ptr [rbx+0x50], 0
       jne      G_M000_IG69
       test     r14d, r14d
       je       G_M000_IG70
       mov      r15d, dword ptr [rdi]
       test     r15d, r15d
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0062
       movzx    r13, byte  ptr [rbp]
       cmp      r13d, 10
       je       G_M000_IG72
       cmp      r13d, 13
       je       G_M000_IG72
 
G_M000_IG04:                ;; offset=0x007B
       mov      r13, gword ptr [rbx+0x30]
       test     r13, r13
       je       G_M000_IG39
 
G_M000_IG05:                ;; offset=0x0088
       movzx    rdx, byte  ptr [r13+0x24]
       test     edx, edx
       je       G_M000_IG74
 
G_M000_IG06:                ;; offset=0x0095
       cmp      edx, 255
       je       G_M000_IG80
       lea      rax, bword ptr [r13+0x28]
       mov      r12d, dword ptr [r13+0x18]
       cmp      r12d, 8
       ja       G_M000_IG76
 
G_M000_IG07:                ;; offset=0x00B3
       mov      dword ptr [rsp+0x70], r12d
       test     r12d, r12d
       je       G_M000_IG83
       movzx    r13, byte  ptr [rax]
 
G_M000_IG08:                ;; offset=0x00C5
       cmp      r13d, dword ptr [rbx+0x60]
       je       G_M000_IG40
 
G_M000_IG09:                ;; offset=0x00CF
       cmp      r13d, 10
       je       G_M000_IG40
       cmp      r13d, 13
       jne      G_M000_IG28
       jmp      G_M000_IG40
 
G_M000_IG10:                ;; offset=0x00E8
       mov      dword ptr [rsp+0xAC], eax
       mov      r8d, eax
       sub      r8d, r15d
       mov      rdx, gword ptr [rbx+0x08]
       cmp      dword ptr [rdx+0x28], 2
       jne      G_M000_IG61
 
G_M000_IG11:                ;; offset=0x0103
       test     r8d, r8d
       je       G_M000_IG61
       test     sil, sil
       je       G_M000_IG95
 
G_M000_IG12:                ;; offset=0x0115
       mov      edx, r15d
       mov      ecx, r8d
       add      rdx, rcx
       mov      ecx, r14d
       cmp      rdx, rcx
       ja       G_M000_IG76
       mov      edx, r15d
       add      rdx, rbp
       movzx    rcx, byte  ptr [rdx]
       cmp      ecx, 45
       sete     r9b
       movzx    r9, r9b
       cmp      ecx, 43
       je       G_M000_IG96
       cmp      ecx, 45
       setne    cl
       movzx    rcx, cl
 
G_M000_IG13:                ;; offset=0x0150
       test     ecx, ecx
       sete     cl
       movzx    rcx, cl
       mov      r10d, r8d
       sub      r10d, ecx
       mov      r11d, r10d
       sub      r11d, 1
       cmp      r11d, 16
       ja       G_M000_IG103
       mov      bword ptr [rsp+0x120], rdi
       xor      r11d, r11d
       mov      edi, -1
       cmp      ecx, r8d
       jge      SHORT G_M000_IG17
       align    [0 bytes for IG14]
 
G_M000_IG14:                ;; offset=0x0184
       movzx    r12, byte  ptr [rdx+rcx]
       add      r12d, -48
       cmp      r12d, 9
       ja       G_M000_IG57
 
G_M000_IG15:                ;; offset=0x0197
       lea      r11, [r11+4*r11]
       mov      r12d, r12d
       lea      r11, [r12+2*r11]
 
G_M000_IG16:                ;; offset=0x01A2
       inc      ecx
       cmp      ecx, r8d
       jl       SHORT G_M000_IG14
 
G_M000_IG17:                ;; offset=0x01A9
       cmp      r10d, 1
       je       G_M000_IG58
 
G_M000_IG18:                ;; offset=0x01B3
       mov      rdx, 0x20000000000000
       cmp      r11, rdx
       ja       G_M000_IG97
       test     edi, edi
       jl       G_M000_IG59
 
G_M000_IG19:                ;; offset=0x01CE
       sub      r8d, edi
       dec      r8d
 
G_M000_IG20:                ;; offset=0x01D4
       vxorps   xmm0, xmm0, xmm0
       mov      rdx, r11
       shr      rdx, 1
       mov      ecx, r11d
       and      ecx, 1
       or       rcx, rdx
       test     r11, r11
       cmovns   rcx, r11
       vcvtsi2sd xmm0, rcx
       jns      SHORT G_M000_IG21
       vaddsd   xmm0, xmm0
 
G_M000_IG21:                ;; offset=0x01F9
       cmp      r8d, 19
       jae      G_M000_IG106
       mov      r8d, r8d
       mov      rdx, 0x1C75878C440
       vdivsd   xmm6, xmm0, qword ptr [rdx+8*r8]
       test     r9d, r9d
       jne      G_M000_IG60
 
G_M000_IG22:                ;; offset=0x021F
       mov      r15d, -1
       xor      r8d, r8d
       xor      edi, edi
 
G_M000_IG23:                ;; offset=0x022A
       mov      rcx, gword ptr [rbx+0x20]
       inc      dword ptr [rcx+0x14]
       mov      rdx, gword ptr [rcx+0x08]
       mov      r8d, dword ptr [rcx+0x10]
       mov      r10d, dword ptr [rdx+0x08]
       cmp      r10d, r8d
       jbe      G_M000_IG101
       lea      r10d, [r8+0x01]
       mov      dword ptr [rcx+0x10], r10d
       mov      ecx, r8d
       shl      rcx, 4
       lea      rdx, bword ptr [rdx+rcx+0x10]
       mov      dword ptr [rdx], r15d
       mov      dword ptr [rdx+0x04], edi
       vmovsd   qword ptr [rdx+0x08], xmm6
 
G_M000_IG24:                ;; offset=0x0265
       test     r15d, r15d
       jl       SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x026A
       test     edi, edi
       je       SHORT G_M000_IG26
       movsxd   rcx, edi
       add      rcx, 128
       add      rcx, qword ptr [rbx+0x58]
       jo       G_M000_IG107
       mov      qword ptr [rbx+0x58], rcx
       cmp      edi, 8
       jg       G_M000_IG62
 
G_M000_IG26:                ;; offset=0x028F
       mov      eax, dword ptr [rsp+0xAC]
       cmp      eax, r14d
       je       G_M000_IG65
       cmp      eax, r14d
       jae      G_M000_IG106
       mov      ecx, eax
       movzx    rcx, byte  ptr [rcx+rbp]
       cmp      ecx, 10
       je       G_M000_IG63
 
G_M000_IG27:                ;; offset=0x02B7
       cmp      ecx, 13
       je       G_M000_IG63
       lea      r15d, [rax+0x01]
       mov      rdi, bword ptr [rsp+0x120]
       mov      r12d, dword ptr [rsp+0x70]
 
G_M000_IG28:                ;; offset=0x02D1
       mov      rcx, gword ptr [rbx+0x20]
       mov      edx, dword ptr [rcx+0x10]
       mov      rcx, gword ptr [rcx+0x08]
       cmp      edx, dword ptr [rcx+0x08]
       jge      G_M000_IG103
 
G_M000_IG29:                ;; offset=0x02E5
       cmp      r15d, r14d
       jge      SHORT G_M000_IG31
 
G_M000_IG30:                ;; offset=0x02EA
       cmp      r15d, r14d
       jae      G_M000_IG106
       mov      ecx, r15d
       movzx    rcx, byte  ptr [rcx+rbp]
       cmp      ecx, r13d
       je       G_M000_IG41
 
G_M000_IG31:                ;; offset=0x0303
       mov      eax, r15d
       mov      dword ptr [rsp+0x78], eax
       cmp      eax, r14d
       jge      G_M000_IG94
 
G_M000_IG32:                ;; offset=0x0313
       mov      rcx, gword ptr [rbx+0x10]
       mov      rdx, gword ptr [rbx+0x18]
       mov      rcx, gword ptr [rcx+0x98]
       mov      r8, gword ptr [rcx+0x88]
       cmp      gword ptr [r8+0x20], 0
       jne      G_M000_IG91
       mov      r8, gword ptr [rcx+0x180]
       test     r8, r8
       jne      G_M000_IG90
 
G_M000_IG33:                ;; offset=0x0344
       mov      eax, dword ptr [rsp+0x78]
       mov      r10d, r14d
       sub      r10d, eax
       cmp      r10d, 0x1000
       jge      G_M000_IG56
 
G_M000_IG34:                ;; offset=0x035B
       mov      r9d, eax
       mov      edx, r10d
       add      r9, rdx
       mov      edx, r14d
       cmp      r9, rdx
       ja       G_M000_IG76
       mov      dword ptr [rsp+0x78], eax
       mov      ecx, eax
       add      rcx, rbp
       mov      r11, gword ptr [rbx+0x40]
       test     r11, r11
       je       G_M000_IG102
       mov      r9, 0x7FF9D748EAE8
       cmp      qword ptr [r11], r9
       jne      G_M000_IG92
       mov      dword ptr [rsp+0x74], r10d
       mov      dword ptr [rsp+0x20], r10d
       movzx    r9, byte  ptr [r11+0x0A]
       movzx    rdx, byte  ptr [r11+0x08]
       movzx    r8, byte  ptr [r11+0x09]
       call     [System.SpanHelpers:NonPackedIndexOfAnyValueType[byte,System.SpanHelpers+DontNegate`1[byte]](byref,byte,byte,byte,int):int]
 
G_M000_IG35:                ;; offset=0x03B8
       test     eax, eax
       jl       G_M000_IG93
 
G_M000_IG36:                ;; offset=0x03C0
       mov      r8d, dword ptr [rsp+0x78]
       add      eax, r8d
 
G_M000_IG37:                ;; offset=0x03C8
       test     sil, sil
       je       G_M000_IG10
 
G_M000_IG38:                ;; offset=0x03D1
       cmp      eax, r14d
       je       G_M000_IG103
       jmp      G_M000_IG10
 
G_M000_IG39:                ;; offset=0x03DF
       xor      rax, rax
       xor      r12d, r12d
       jmp      G_M000_IG07
 
G_M000_IG40:                ;; offset=0x03E9
       mov      r13d, -1
       jmp      G_M000_IG28
 
G_M000_IG41:                ;; offset=0x03F4
       cmp      r12d, 1
       jne      G_M000_IG103
       lea      eax, [r15+0x01]
       movzx    r8, r13b
       mov      dword ptr [rsp+0x80], r8d
       mov      dword ptr [rsp+0x84], eax
       cmp      eax, r14d
       mov      r8d, dword ptr [rsp+0x80]
       jge      G_M000_IG88
 
G_M000_IG42:                ;; offset=0x0426
       mov      rcx, gword ptr [rbx+0x10]
       mov      rdx, gword ptr [rbx+0x18]
       mov      rcx, gword ptr [rcx+0x98]
       mov      r10, gword ptr [rcx+0x88]
       cmp      gword ptr [r10+0x20], 0
       jne      G_M000_IG85
       mov      r10, gword ptr [rcx+0x180]
       test     r10, r10
       jne      G_M000_IG84
 
G_M000_IG43:                ;; offset=0x0457
       mov      eax, dword ptr [rsp+0x84]
       mov      r10d, r14d
       sub      r10d, eax
       cmp      r10d, 0x1000
       jge      G_M000_IG55
 
G_M000_IG44:                ;; offset=0x0471
       mov      ecx, eax
       mov      edx, r10d
       add      rcx, rdx
       mov      edx, r14d
       cmp      rcx, rdx
       ja       G_M000_IG76
       mov      dword ptr [rsp+0x84], eax
       mov      r11d, eax
       add      r11, rbp
       mov      bword ptr [rsp+0x38], r11
       test     sil, sil
       je       G_M000_IG86
 
G_M000_IG45:                ;; offset=0x04A0
       mov      dword ptr [rsp+0x7C], r10d
       mov      dword ptr [rsp+0x20], r10d
       mov      rcx, r11
       mov      edx, r8d
       mov      r8d, 13
       mov      r9d, 10
       call     [System.SpanHelpers:NonPackedIndexOfAnyValueType[byte,System.SpanHelpers+DontNegate`1[byte]](byref,byte,byte,byte,int):int]
 
G_M000_IG46:                ;; offset=0x04C2
       test     eax, eax
       jl       G_M000_IG87
 
G_M000_IG47:                ;; offset=0x04CA
       cmp      eax, dword ptr [rsp+0x7C]
       jae      G_M000_IG106
       mov      ecx, eax
       mov      rdx, bword ptr [rsp+0x38]
       movzx    rcx, byte  ptr [rdx+rcx]
       mov      edx, dword ptr [rsp+0x80]
       cmp      ecx, edx
       jne      G_M000_IG88
       mov      ecx, dword ptr [rsp+0x84]
       add      eax, ecx
 
G_M000_IG48:                ;; offset=0x04F7
       test     eax, eax
       jl       G_M000_IG103
 
G_M000_IG49:                ;; offset=0x04FF
       lea      r8d, [rax+0x01]
       test     sil, sil
       je       SHORT G_M000_IG51
 
G_M000_IG50:                ;; offset=0x0508
       cmp      r8d, r14d
       je       G_M000_IG103
 
G_M000_IG51:                ;; offset=0x0511
       cmp      r8d, r14d
       jge      SHORT G_M000_IG54
 
G_M000_IG52:                ;; offset=0x0516
       cmp      r8d, r14d
       jae      G_M000_IG106
       mov      ecx, r8d
       movzx    rcx, byte  ptr [rcx+rbp]
       cmp      ecx, dword ptr [rbx+0x60]
       je       SHORT G_M000_IG54
 
G_M000_IG53:                ;; offset=0x052B
       cmp      ecx, 10
       jne      G_M000_IG89
 
G_M000_IG54:                ;; offset=0x0534
       lea      r10d, [r15+0x01]
       sub      eax, r15d
       lea      r15d, [rax-0x01]
       vxorps   xmm6, xmm6, xmm6
       mov      dword ptr [rsp+0xAC], r8d
       mov      bword ptr [rsp+0x120], rdi
       mov      edi, r15d
       mov      r15d, r10d
       jmp      G_M000_IG23
 
G_M000_IG55:                ;; offset=0x055E
       mov      r10d, 0x1000
       jmp      G_M000_IG44
 
G_M000_IG56:                ;; offset=0x0569
       mov      r10d, 0x1000
       jmp      G_M000_IG34
 
G_M000_IG57:                ;; offset=0x0574
       cmp      byte  ptr [rdx+rcx], 46
       jne      G_M000_IG100
       test     edi, edi
       jge      G_M000_IG99
       mov      edi, ecx
       jmp      G_M000_IG16
 
G_M000_IG58:                ;; offset=0x058D
       test     edi, edi
       jge      G_M000_IG98
       jmp      G_M000_IG18
 
G_M000_IG59:                ;; offset=0x059A
       xor      r8d, r8d
       jmp      G_M000_IG20
 
G_M000_IG60:                ;; offset=0x05A2
       vxorps   xmm6, xmm6, xmmword ptr [reloc @RWD00]
       jmp      G_M000_IG22
 
G_M000_IG61:                ;; offset=0x05AF
       vxorps   xmm6, xmm6, xmm6
       mov      bword ptr [rsp+0x120], rdi
       mov      edi, r8d
       jmp      G_M000_IG23
 
G_M000_IG62:                ;; offset=0x05C3
       add      edi, dword ptr [rbx+0x68]
       jo       G_M000_IG107
       mov      dword ptr [rbx+0x68], edi
       jmp      G_M000_IG26
 
G_M000_IG63:                ;; offset=0x05D4
       lea      r15d, [rax+0x01]
       test     sil, sil
       jne      SHORT G_M000_IG67
 
G_M000_IG64:                ;; offset=0x05DD
       cmp      r15d, r14d
       ja       G_M000_IG76
       mov      edx, r15d
       add      rdx, rbp
       sub      r14d, r15d
       mov      bword ptr [rsp+0x50], rdx
       mov      dword ptr [rsp+0x58], r14d
       lea      rdx, [rsp+0x50]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:ValidateRecordEnd(System.ReadOnlySpan`1[byte]):this]
 
G_M000_IG65:                ;; offset=0x0607
       mov      eax, 1
 
G_M000_IG66:                ;; offset=0x060C
       vmovaps  xmm6, xmmword ptr [rsp+0xB0]
       add      rsp, 200
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG67:                ;; offset=0x0629
       mov      eax, eax
       cmp      byte  ptr [rax+rbp], 13
       je       G_M000_IG105
 
G_M000_IG68:                ;; offset=0x0635
       mov      rdi, bword ptr [rsp+0x120]
       mov      dword ptr [rdi], r15d
       jmp      SHORT G_M000_IG65
 
G_M000_IG69:                ;; offset=0x0642
       mov      rcx, 0x7FF9D72AA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x1A74A076428
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG70:                ;; offset=0x0670
       test     sil, sil
       sete     al
       movzx    rax, al
 
G_M000_IG71:                ;; offset=0x0679
       vmovaps  xmm6, xmmword ptr [rsp+0xB0]
       add      rsp, 200
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG72:                ;; offset=0x0696
       mov      rcx, gword ptr [rbx+0x10]
       mov      r15, gword ptr [rbx+0x18]
       mov      r13, gword ptr [rcx+0x98]
       cmp      byte  ptr [r13], r13b
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG73
       mov      rcx, r13
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG73:                ;; offset=0x06C2
       mov      bword ptr [rsp+0x50], rbp
       mov      dword ptr [rsp+0x58], r14d
       mov      bword ptr [rsp+0x20], rdi
       lea      rdx, [rsp+0x50]
       movzx    r9, sil
       mov      rcx, rbx
       xor      r8d, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:CompleteLiteralRecord(System.ReadOnlySpan`1[byte],int,bool,byref):this]
       jmp      G_M000_IG65
 
G_M000_IG74:                ;; offset=0x06EB
       mov      rax, gword ptr [r13+0x08]
       mov      r12d, dword ptr [r13+0x18]
       test     rax, rax
       jne      SHORT G_M000_IG78
 
G_M000_IG75:                ;; offset=0x06F8
       test     r12d, r12d
       je       SHORT G_M000_IG77
 
G_M000_IG76:                ;; offset=0x06FD
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG77:                ;; offset=0x0704
       xor      rax, rax
       xor      r12d, r12d
       jmp      SHORT G_M000_IG79
 
G_M000_IG78:                ;; offset=0x070B
       cmp      dword ptr [rax+0x08], r12d
       jb       SHORT G_M000_IG76
       add      rax, 16
 
G_M000_IG79:                ;; offset=0x0715
       jmp      G_M000_IG07
 
G_M000_IG80:                ;; offset=0x071A
       mov      rdx, gword ptr [r13+0x08]
       lea      rcx, bword ptr [r13+0x28]
       mov      ecx, dword ptr [rcx]
       mov      eax, dword ptr [r13+0x18]
       test     rdx, rdx
       jne      SHORT G_M000_IG81
       or       ecx, eax
       jne      SHORT G_M000_IG76
       xor      rdx, rdx
       xor      eax, eax
       jmp      SHORT G_M000_IG82
 
G_M000_IG81:                ;; offset=0x0737
       mov      r8d, ecx
       mov      r10d, eax
       add      r8, r10
       mov      r10d, dword ptr [rdx+0x08]
       cmp      r8, r10
       ja       SHORT G_M000_IG76
       mov      ecx, ecx
       lea      rdx, bword ptr [rdx+rcx+0x10]
 
G_M000_IG82:                ;; offset=0x0750
       mov      bword ptr [rsp+0x60], rdx
       mov      dword ptr [rsp+0x68], eax
       lea      rdx, [rsp+0x60]
       lea      rcx, [rsp+0x88]
       call     [System.Span`1[byte]:op_Implicit(System.Span`1[byte]):System.ReadOnlySpan`1[byte]]
       mov      rax, bword ptr [rsp+0x88]
       mov      r12d, dword ptr [rsp+0x90]
       jmp      G_M000_IG07
 
G_M000_IG83:                ;; offset=0x0781
       mov      r13d, -1
       jmp      G_M000_IG08
 
G_M000_IG84:                ;; offset=0x078C
       cmp      dword ptr [r10+0x20], 0
       setne    r10b
       movzx    r10, r10b
       test     r10d, r10d
       je       G_M000_IG43
 
G_M000_IG85:                ;; offset=0x07A2
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      r8d, dword ptr [rsp+0x80]
       jmp      G_M000_IG43
 
G_M000_IG86:                ;; offset=0x07B5
       mov      rcx, r11
       mov      edx, r8d
       mov      dword ptr [rsp+0x7C], r10d
       mov      r8d, r10d
       call     [System.SpanHelpers:NonPackedIndexOfValueType[byte,System.SpanHelpers+DontNegate`1[byte]](byref,byte,int):int]
       jmp      G_M000_IG46
 
G_M000_IG87:                ;; offset=0x07CE
       mov      eax, dword ptr [rsp+0x84]
       add      eax, dword ptr [rsp+0x7C]
       cmp      eax, r14d
       mov      dword ptr [rsp+0x84], eax
       mov      r8d, dword ptr [rsp+0x80]
       jl       G_M000_IG42
 
G_M000_IG88:                ;; offset=0x07F1
       mov      eax, -1
       jmp      G_M000_IG48
 
G_M000_IG89:                ;; offset=0x07FB
       cmp      ecx, 13
       jne      G_M000_IG103
       jmp      G_M000_IG54
 
G_M000_IG90:                ;; offset=0x0809
       cmp      dword ptr [r8+0x20], 0
       setne    r8b
       movzx    r8, r8b
       test     r8d, r8d
       je       G_M000_IG33
 
G_M000_IG91:                ;; offset=0x081F
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG33
 
G_M000_IG92:                ;; offset=0x082A
       mov      bword ptr [rsp+0x50], rcx
       mov      dword ptr [rsp+0x74], r10d
       mov      dword ptr [rsp+0x58], r10d
       lea      rdx, [rsp+0x50]
       mov      rcx, r11
       mov      r8, qword ptr [r11]
       mov      r8, qword ptr [r8+0x40]
       call     [r8+0x30]System.Buffers.SearchValues`1[byte]:IndexOfAny(System.ReadOnlySpan`1[byte]):int:this
       jmp      G_M000_IG35
 
G_M000_IG93:                ;; offset=0x0851
       mov      eax, dword ptr [rsp+0x78]
       add      eax, dword ptr [rsp+0x74]
       cmp      eax, r14d
       mov      dword ptr [rsp+0x78], eax
       jl       G_M000_IG32
 
G_M000_IG94:                ;; offset=0x0866
       mov      eax, dword ptr [rsp+0x78]
       jmp      G_M000_IG37
 
G_M000_IG95:                ;; offset=0x086F
       mov      bword ptr [rsp+0x50], rbp
       mov      dword ptr [rsp+0x58], r14d
       mov      dword ptr [rsp+0x20], r8d
       xor      r8d, r8d
       mov      dword ptr [rsp+0x28], r8d
       lea      r8, [rsp+0x50]
       lea      rdx, [rsp+0x98]
       mov      rcx, rbx
       mov      r9d, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser:CreateField(System.ReadOnlySpan`1[byte],int,int,bool):Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField:this]
       mov      r15d, dword ptr [rsp+0x98]
       mov      edx, dword ptr [rsp+0x9C]
       mov      eax, edx
       vmovsd   xmm6, qword ptr [rsp+0xA0]
       mov      bword ptr [rsp+0x120], rdi
       mov      edi, eax
       jmp      G_M000_IG23
 
G_M000_IG96:                ;; offset=0x08C8
       xor      ecx, ecx
       jmp      G_M000_IG13
 
G_M000_IG97:                ;; offset=0x08CF
       mov      rdi, bword ptr [rsp+0x120]
       jmp      SHORT G_M000_IG103
 
G_M000_IG98:                ;; offset=0x08D9
       mov      rdi, bword ptr [rsp+0x120]
       jmp      SHORT G_M000_IG103
 
G_M000_IG99:                ;; offset=0x08E3
       mov      rdi, bword ptr [rsp+0x120]
       jmp      SHORT G_M000_IG103
 
G_M000_IG100:                ;; offset=0x08ED
       mov      rdi, bword ptr [rsp+0x120]
       jmp      SHORT G_M000_IG103
 
G_M000_IG101:                ;; offset=0x08F7
       mov      dword ptr [rsp+0x40], r15d
       mov      dword ptr [rsp+0x44], edi
       vmovsd   qword ptr [rsp+0x48], xmm6
       lea      rdx, [rsp+0x40]
       call     [System.Collections.Generic.List`1[Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField]:AddWithResize(Lokad.Lython.Runtime.LythonRuntime+CsvRecordParser+CsvField):this]
       jmp      G_M000_IG24
 
G_M000_IG102:                ;; offset=0x0916
       mov      ecx, 6
       call     [System.ThrowHelper:ThrowArgumentNullException(int)]
       int3     
 
G_M000_IG103:                ;; offset=0x0922
       mov      dword ptr [rdi], r15d
       xor      eax, eax
 
G_M000_IG104:                ;; offset=0x0927
       vmovaps  xmm6, xmmword ptr [rsp+0xB0]
       add      rsp, 200
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG105:                ;; offset=0x0944
       cmp      r15d, r14d
       jge      G_M000_IG68
       cmp      r15d, r14d
       jae      SHORT G_M000_IG106
       mov      eax, r15d
       cmp      byte  ptr [rax+rbp], 10
       jne      G_M000_IG68
       inc      r15d
       jmp      G_M000_IG68
 
G_M000_IG106:                ;; offset=0x0967
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG107:                ;; offset=0x096D
       call     CORINFO_HELP_OVERFLOW
       int3     
 
RWD00  	dq	8000000000000000h, 8000000000000000h

; Total bytes of code 2419

