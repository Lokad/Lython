from pathlib import Path
import os, subprocess, sys
lab=Path(__file__).resolve().parent
repo=lab.parents[3]
role=sys.argv[1]
tree=repo/'.git/agent-worktrees/csv-combined-scan-20261123'
windows=Path.home()/'.dotnet11/dotnet.exe'
linux='/home/vermorel/.dotnet/dotnet'
def wsl(p):return '/mnt/d/'+p.relative_to(p.anchor).as_posix()
if role=='windows':
    command=[str(windows)]; env=dict(os.environ,DOTNET_ROOT=str(windows.parent),DOTNET_HOST_PATH=str(windows),PATH=str(windows.parent)+os.pathsep+os.environ['PATH']); target='net11.0'; artifacts=lab/'windows'
else:
    command=['wsl.exe','--cd',wsl(tree),'--exec','env','DOTNET_ROOT=/home/vermorel/.dotnet','DOTNET_HOST_PATH='+linux,linux]; env=None; target='net10.0'; artifacts=wsl(lab/'ubuntu')
filters={
    'Lokad.Lython.Tests':'Category!=Stress&(FullyQualifiedName~Csv|FullyQualifiedName~TextLine|FullyQualifiedName~ChunkedRead|FullyQualifiedName~NativeCsv|FullyQualifiedName~TextFile)',
    'Lokad.Lython.PublicApi.Tests':'Category!=Stress&(FullyQualifiedName~Csv|FullyQualifiedName~TextFile|FullyQualifiedName~FileIO|FullyQualifiedName~HostMemoryAdmission)',
}
for project, query in filters.items():
    out=lab/(role+'-'+project+'.log')
    with out.open('wb') as log:
        result=subprocess.run(command+['test','tests/'+project,'-c','Release','-f',target,'--artifacts-path',str(artifacts),'--filter',query],cwd=tree,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=195)
    print('\n'.join(out.read_text(encoding='utf-8').splitlines()[-(10 if result.returncode==0 else 25):]),flush=True)
    result.check_returncode()
