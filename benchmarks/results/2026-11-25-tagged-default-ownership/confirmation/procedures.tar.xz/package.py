from pathlib import Path
import hashlib,json,tarfile
lab=Path(__file__).resolve().parent; root=lab.parents[3]
quiet=lab/'comparison/quiet'
out=root/'benchmarks/results/2026-11-25-tagged-default-ownership/confirmation'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prior=read(out.parent/'identity.json'); latest=read(quiet/'identity.json')
assert {k:v for k,v in prior.items() if k!='catalogs'}=={k:v for k,v in latest.items() if k!='catalogs'}
assert prior['catalogs']['representative.json']==latest['catalogs']['representative.json']
assert all({p.name:sha(p) for p in (lab/role).iterdir()}==files for role,files in latest['imageFiles'].items())
files=['prepare-quiet.py','quiet.py','archive.py','package.py','comparison/quiet/upload.json','comparison/quiet/storage-custody.json']
with tarfile.open(out/'procedures.tar.xz','w:xz') as archive:
 for n in files:archive.add(lab/n,arcname=n,recursive=False)
with tarfile.open(out/'procedures.tar.xz') as archive:
 assert archive.getnames()==files and all(archive.extractfile(n).read()==(lab/n).read_bytes() for n in files)
