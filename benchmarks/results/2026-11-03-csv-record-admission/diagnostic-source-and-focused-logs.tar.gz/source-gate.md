## Priority1 — B150 CSV record storage/admission

SOURCE/DESIGN GATE COMPLETE; bounded record-staging prototype SELECTED, not yet
implemented or performance-qualified. FinishField/FinishRecord and builder paths
confirm the per-field transactions; preserve immediate nonnumeric conversion.
Whole-record capacity/peak and actual CPU benefit remain to be measured. B149 is withdrawn with both sources,
all adverse observations and failed CRLF-golden condition retained. Do not retime
unchanged source or repeat B148 qualification. No dormant string-sharing fields,
rollback flags or copy hooks remain. Original whole-output refusal regression
still permits one fragment but denies the entire output; coverage was not weakened.

Hypothesis: one existing-parser record storage/construction boundary can eliminate
per-string admission/commit transactions and repeated field materialization while
keeping independent byte payloads. B134 attributed about40% inclusive CSV CPU to
parsing/iteration, including useful work; it does not prove reservation dominance
or predict gains. Source verifies Feed already appends UTF8 runs, not per-rune CLR
strings; FinishField still calls ToPyString/admission for each field, then copies
staged cells into a final PyList at FinishRecord. Small integer admission is already
coarse (>64bit magnitudes only), so do not revive that disproven overhead claim.

1. Implement only the bounded Feed/FinishField/FinishRecord storage migration.
   Remove per-string reservation/finalization on ordinary text fields, retain the
   existing parser and current numeric conversion point. Selected candidate: reusable native record payload + field
   descriptors, then one prefunded field/row construction at publication. Preserve
   existing parser and useful staging; no duplicate fast parser, new cache/pool,
   allowance or global string changes. Keep numeric conversion/error timing exact;
   deferring guest-visible failures or extra source callbacks is not acceptable.
2. Explicit tradeoff: whole-record working capacity may exceed the old largest-
   field buffer. Admit capacity/replacement overlap through existing governor;
   document/measure earlier denial and peak cost. Output strings stay independent,
   aliases/results/queued records stay funded. Unknown-width staging must retain
   B135's lesson: do not exchange saved copying for repeated per-row growth.
3. Acceptance: supported quotes/escapes/newlines/Unicode, nonnumeric conversion,
   empty/missing/duplicate/custom fields, line_num/source consumption/error order,
   multiple queued records and retained row aliases. Current cancellation, terminal
   refusal, scratch cleanup, shared-root reuse and actual delayed iteration remain
   effective. Bulk admission precedes output allocation/publication, without
   retry/fallback or optional-storage skips after refusal.
4. Completion: focused Release on both targets, then one frozen CSV/report warm+
   fresh comparison with unchanged JSON and variable-width/quoted/multiline/long-
   field controls, allocation and peak diagnostics. Bounded confirmation/refinement
   when justified; all failed/adverse conditions retained. Stop the source gate
   with implement/refine/decline decision; stop an implementation requiring a
   second parser/ownership subsystem or weakened conversion/source-effect order.
   Retain only with an explicit global cost/debt decision, no rigid%veto.

Secondary coherent candidate: statically address operands using existing compiler
stack facts, displacing mutable Push/Pop/Count work instead of B147's overlay plan.
Source confirms EntryDepths are block facts; instruction positions need deriving
inside the existing pass. Iterator disposal/active call borrows/exception clearing
currently depend on runtime Count. Require one clear cleanup invariant before code;
do not add a parallel dispatch table or in-flight phase framework to force it.
This remains a source gate, not a committed VM rewrite or presumed speedup.

