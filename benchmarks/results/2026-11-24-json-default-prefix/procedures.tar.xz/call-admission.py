from pathlib import Path
import hashlib,json,shutil,subprocess,os

lab=Path(__file__).resolve().parent
root=lab.parents[3]
work=lab/"call-admission"
previous=lab.with_name("current-defaulted-report-cpu-20261124")
source=json.loads((previous/"catalog.json").read_text(encoding="utf-8"))
selected=[entry for entry in source["cases"] if entry["id"]=="scripts.rule-default-closures"]
assert len(selected)==1
catalog=work/"catalog.json"
catalog.write_text(json.dumps(dict(cases=selected),indent=2)+"\n",encoding="utf-8")
sdk=Path.home()/".dotnet11"
tests=root/"tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0"
seal=lab/"comparison/candidate"/"Lokad.Lython.dll"
output=work/"execution"
output.mkdir(exist_ok=True)
for p in tests.iterdir():
    if p.is_file() and p.suffix not in (".pdb",".exe"):shutil.copyfile(p,output/p.name)
for p in (work/"bin/Release/net11.0").glob("Admission.*"):
    if p.suffix not in (".pdb",".exe"):shutil.copyfile(p,output/p.name)
shutil.copyfile(seal,output/seal.name)
run=subprocess.run([sdk/"dotnet.exe",output/"Admission.dll",output/"Lokad.Lython.PublicApi.Tests.dll",catalog],
    check=True,timeout=30,capture_output=True,text=True,encoding="utf-8",env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk)))
result=json.loads(run.stdout)
assert result["core"]==hashlib.sha256(seal.read_bytes()).hexdigest()
(work/"summary.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
print(json.dumps(result,indent=2))
