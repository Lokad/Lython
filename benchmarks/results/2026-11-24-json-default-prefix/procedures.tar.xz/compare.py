from pathlib import Path
import hashlib,json,os,subprocess

lab=Path(__file__).resolve().parent
root=lab.parents[3]
sdk=Path.home()/".dotnet11"
probe=root/"tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
type_name="failure"  # Inspect semantic output, including the visible prefix and callback count.
fixtures=[
    ("root","{1}",""),
    ("first list","[{1}]",""),
    ("later list","[1,{2},{3}]",""),
    ("tuple","(1,{2},{3})",""),
    ("nested lists","[1,[2,{3},{4}]]",""),
    ("first dict","{'a':{1}}",""),
    ("later dict","{'a':1,'b':{2},'c':{3}}",""),
    ("sorted and indented","{'z':[1,{2},{3}],'a':0}",", sort_keys=True, indent=2"),
    ("custom separators","[1,{2},{3}]",", separators=(' | ', '=')"),
    ("empty list separator","[1,{2},{3}]",", separators=('', ':')"),
]
cases=[]
for mode in ("dump","iterencode","implicit"):
    for name,value,options in fixtures:
        invocation=(
            f"json.dump({value}, writer, default=callback{options})"
            if mode=="dump" else
            f"for chunk in json.JSONEncoder(default=callback{options}).iterencode({value}): writer.write(chunk)"
            if mode=="iterencode" else f"json.dump({value}, writer{options})"
        )
        program="""import json
class Writer:
    def __init__(self): self.parts = []
    def write(self, piece): self.parts.append(piece)
writer = Writer()
seen = []
def callback(value):
    seen.append(''.join(writer.parts))
    if value == {2}: return 'saved'
    raise RuntimeError('stop')
try:
    ${CALL}
except (RuntimeError, TypeError) as error:
    print(type(error).__name__)
print(repr(seen))
print(repr(''.join(writer.parts)))
""".replace("${CALL}",invocation)
        cases.append(dict(label=mode+" "+name,source=program))
(lab/"cases.json").write_text(json.dumps(cases,indent=2)+"\n",encoding="utf-8",newline="\n")
for mode in ("sync","async"):
    cmd=[sdk/"dotnet.exe",probe,"--batch-json","--compare-python","--python","C:/Python313/python.exe",*(["--async"] if mode=="async" else [])]
    result=subprocess.run(cmd,input=json.dumps([c["source"]for c in cases]),capture_output=True,text=True,
                         encoding="utf-8",env=env,timeout=75)
    tag=__import__("sys").argv[1]
    (lab/f"{tag}-{mode}.jsonl").write_text(result.stdout,encoding="utf-8",newline="\n")
    rows=[json.loads(line)for line in result.stdout.splitlines()]
    assert len(rows)==len(cases),result.stderr
    assert all(row["Lython"]["Success"] and row["CPython"]["Success"] for row in rows),[(n,r) for n,r in enumerate(rows) if not (r["Lython"]["Success"] and r["CPython"]["Success"])]
    matches=sum(r["Matches"]for r in rows)
    print(tag,mode,matches,"of",len(rows))
    for fixture,row in zip(cases,rows,strict=True):
        if not row["Matches"]:print(fixture["label"],repr(row["Lython"]["StandardOutput"]),repr(row["CPython"]["StandardOutput"]))
print("Core",hashlib.sha256(probe.with_name("Lokad.Lython.dll").read_bytes()).hexdigest())
