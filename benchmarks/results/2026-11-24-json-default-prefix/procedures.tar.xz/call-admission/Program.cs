using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Lokad.Lython;

var hostType = Assembly.LoadFrom(args[0]).GetType("Lokad.Lython.Tests.Harness.MockLythonHost", true)!;
var engine = new LythonEngine();
var rows = new List<object>();
using var catalog = JsonDocument.Parse(File.ReadAllBytes(args[1]));
foreach (var entry in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var id = entry.GetProperty("id").GetString()!;
    using var script = engine.Compile(entry.GetProperty("source").GetString()!);
    if (!script.IsValid) throw new InvalidOperationException(string.Join("\n", script.Diagnostics));
    var root = new LythonMemoryBudget();
    var sites = new Counters();
    using (var allowance = new ObservingScope(root.CreateScope(), sites))
    using (var result = script.Run((ILythonHost)Activator.CreateInstance(hostType, nonPublic:true)!,
               new LythonRunOptions { MemoryBudget = allowance }))
    {
        if (!result.Success) throw new InvalidOperationException(result.Failure?.Message);
        var hash = Convert.ToHexStringLower(SHA256.HashData(Encoding.UTF8.GetBytes(result.StandardOutput)));
        if (hash != entry.GetProperty("expectedOutputSha256").GetString()) throw new InvalidOperationException("Unexpected output.");
        rows.Add(new { id, result.PeakExecutionMemoryBytes, sites.TotalGrowth, sites.PairGrowth, sites.OtherGrowth });
    }
    if (root.ReservedBytes != 0) throw new InvalidOperationException("Allowance did not return to baseline.");
}
var core = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location)));
Console.WriteLine(JsonSerializer.Serialize(new { core, rows }, new JsonSerializerOptions { WriteIndented = true }));

sealed class Counters
{
    public int TotalGrowth { get; private set; }
    public Dictionary<string,int> PairGrowth { get; } = [];
    public Dictionary<long,int> OtherGrowth { get; } = [];

    public void Record(long delta)
    {
        if (delta <= 0) return;
        TotalGrowth++;
        var stack = new StackTrace().GetFrames();
        if (stack.Any(f => f.GetMethod()?.Name == "CreateClosedPairMember"))
        {
            var category = stack.Select(f => f.GetMethod()?.Name).FirstOrDefault(name =>
                name is "AllocateExecutableDefaults" or "CreateFunctionValue" or "CreateClosedEagerDefinition") ?? "Other";
            var key = $"{category} / {delta}";
            PairGrowth[key] = PairGrowth.GetValueOrDefault(key) + 1;
            return;
        }
        OtherGrowth[delta] = OtherGrowth.GetValueOrDefault(delta) + 1;
    }
}

sealed class ObservingScope(ILythonMemoryScope inner, Counters counters) : ILythonMemoryScope
{
    public ILythonMemoryScope CreateScope() => new ObservingScope(inner.CreateScope(), counters);
    public void Dispose() => inner.Dispose();

    public bool TryReserve(long bytes, [NotNullWhen(true)] out ILythonMemoryReservation? reservation)
    {
        if (!inner.TryReserve(bytes, out var actual))
        {
            reservation = null;
            return false;
        }
        counters.Record(bytes);
        reservation = new ObservingReservation(actual, counters);
        return true;
    }
}

sealed class ObservingReservation(ILythonMemoryReservation inner, Counters counters) : ILythonMemoryReservation
{
    public long Bytes => inner.Bytes;

    public bool TryResize(long bytes)
    {
        var growth = bytes - inner.Bytes;
        if (!inner.TryResize(bytes)) return false;
        counters.Record(growth);
        return true;
    }

    public void Dispose() => inner.Dispose();
}
