from pathlib import Path
import hashlib,json,shutil,tarfile

lab=Path(__file__).resolve().parent
root=lab.parents[3]
comparison=lab/"comparison"
quiet=comparison/"quiet"
out=root/"benchmarks/results/2026-11-24-json-default-prefix"
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
identity=read(quiet/"identity.json")
assert identity["comparisonRevision"]=="e353ba446" and sha(lab/"candidate.patch")==identity["sourcePatchSHA256"]
assert read(out/"quiet-summary.json")["sourcePatch"]==identity["sourcePatchSHA256"]
for role,expected in identity["imageFiles"].items():
    assert len(expected)==32 and {p.name:sha(p)for p in (comparison/role).iterdir()}==expected
    proof=read(comparison/f"{role}-verify.json")
    assert proof["state"]=="Completed" and proof["caseCount"]==5
    assert proof["catalogSha256"]==identity["catalogs"]["representative.json"]["sha256"]
    assert proof["launched"]["library"]["sha256"]==expected["Lokad.Lython.dll"]
for role,expected in (("reference",9),("candidate",30)):
    for mode in ("sync","async"):
        rows=[json.loads(line)for line in (lab/f"{role}-{mode}.jsonl").read_text(encoding="utf-8").splitlines()]
        assert len(rows)==30 and sum(row["Matches"]for row in rows)==expected
        assert all(row["Compared"] and row["CPython"]["Success"] and row["Lython"]["Success"] for row in rows)
for platform in ("windows","ubuntu"):
    assert "Passed:  1015" in (lab/f"{platform}-public.log").read_text(encoding="utf-8-sig")
    assert "Passed:   329" in (lab/f"{platform}-white.log").read_text(encoding="utf-8-sig")
    assert "Failed:     2" in (lab/f"{platform}-white-initial.log").read_text(encoding="utf-8-sig")
allocation=read(lab/"allocation-summary.json")
assert allocation[0]["allocationBytes"]==[96536,96536] and allocation[0]["peakAdmission"]==[56623,56399]
calls=read(lab/"call-admission/summary.json")
assert calls["core"]==identity["coreSHA256"]["candidate"]
assert calls["rows"][0]["TotalGrowth"]==8200
assert calls["rows"][0]["PairGrowth"]=={"AllocateExecutableDefaults / 520":4096,"CreateFunctionValue / 160":4096,"CreateFunctionValue / 32":1}
shutil.copyfile(quiet/"identity.json",out/"identity.json")
shutil.copyfile(lab/"allocation-summary.json",out/"allocation-summary.json")
shutil.copyfile(lab/"call-admission/summary.json",out/"call-admission.json")
files=("archive.py","archive-quiet.py","prepare.py","quiet.py","prepare.log","quiet-launch.log","quiet-retrieve.log","candidate.patch",
       "compare.py","cases.json","reference-sync.jsonl","reference-async.jsonl","candidate-sync.jsonl","candidate-async.jsonl",
       "reference-build.log","candidate-build.log","test-ubuntu.sh","windows-public.log","ubuntu-public.log",
       "windows-white.log","ubuntu-white.log","windows-white-initial.log","ubuntu-white-initial.log",
       "compact-catalog.py","catalog-custody.json","comparison/quiet/storage-custody.json",
       "comparison/reference-verify.json","comparison/candidate-verify.json","allocations.py","allocations.log",
       "reference-allocation.json","candidate-allocation.json","call-admission.py","call-admission/Admission.csproj",
       "call-admission/Program.cs","call-admission/catalog.json","call-admission/summary.json","call-admission-build.log")
with tarfile.open(out/"procedures.tar.xz","w:xz") as archive:
    for p in files:archive.add(lab/p,arcname=p)
with tarfile.open(out/"procedures.tar.xz") as archive:
    assert all(hashlib.sha256(archive.extractfile(p).read()).hexdigest()==sha(lab/p)for p in files)
print("Archived the verified source patch, 30+30 probes, test logs and call admission census")
