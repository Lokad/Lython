from pathlib import Path
import fcntl,hashlib,json,os,stat

base=Path("/home/lokad/lython-bench-checks").resolve()
source=base/"method-body-bytecode-20261011/baseline-full-catalog.json"
candidates=[base/name/part for name in ("method-receiver-lease-20261010","shared-frame-owner-20261010")
            for part in ("baseline-full-catalog.json","candidate-full-catalog.json")]
expected="c5031ac6bdc78d2218698c71d8aeb5a2f95277ffedffe572604597c5d633b6a6"
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def available():
    capacity=os.statvfs(base)
    return capacity.f_bavail*capacity.f_frsize

with (base/"comparison-vm.lock").open("a") as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    before=available()
    assert source.resolve()==source and sha(source)==expected
    current=source.stat()
    assert stat.S_ISREG(current.st_mode) and current.st_uid==os.getuid() and current.st_size==11863087
    preserved=[]
    for candidate in candidates:
        if available()>=14_000_000: break
        if not candidate.is_file() or candidate.resolve()!=candidate or sha(candidate)!=expected:
            continue
        old=candidate.stat()
        if old.st_nlink!=1 or (old.st_mode,old.st_uid,old.st_gid)!=(current.st_mode,current.st_uid,current.st_gid):
            continue
        spare=candidate.with_name(".lython-catalog-"+str(os.getpid()))
        assert not spare.exists()
        os.link(source,spare)
        try:
            os.replace(spare,candidate)
        finally:
            if spare.exists(): spare.unlink()
        assert os.path.samefile(source,candidate) and sha(candidate)==expected
        preserved.append(dict(path=str(candidate.relative_to(base)), oldInode=old.st_ino,oldMtimeNs=old.st_mtime_ns))
    print(json.dumps(dict(before=before,after=available(),sha256=expected,canonical=str(source.relative_to(base)),preserved=preserved)))
