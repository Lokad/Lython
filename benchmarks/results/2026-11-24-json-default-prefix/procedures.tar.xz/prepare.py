from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
parent=lab.with_name("json-file-drain-20261124")
baseline=parent/"boxed"
comparison=lab/"comparison"
quiet=comparison/"quiet"
quiet.mkdir(parents=True,exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
save=lambda p,v:p.write_text(json.dumps(v,indent=2)+"\n",encoding="utf-8",newline="\n")
donor=read(baseline/"quiet/identity.json")
core="Lokad.Lython.dll"
current=repo/"src/Lokad.Lython/bin/Release/net11.0"/core
reference=donor["imageFiles"]["candidate"]
assert sha(current)!=reference[core]
assert {p.name:sha(p)for p in (baseline/"candidate").iterdir()}==reference
images=dict(reference=reference,candidate=reference|{core:sha(current)})
for role,manifest in images.items():
    folder=comparison/role
    folder.mkdir(exist_ok=True)
    for name in manifest:shutil.copyfile(current if role=="candidate" and name==core else baseline/"candidate"/name,folder/name)
    assert len(manifest)==32 and {p.name:sha(p)for p in folder.iterdir()}==manifest
expected=quiet/"representative.json"
shutil.copyfile(baseline/"quiet/representative.json",expected)
assert sha(expected)==donor["catalogs"]["representative.json"]["sha256"]
old=read(baseline/"quiet/jobs.json")
jobs={"warm":[row for row in old["warm"] if row[1]=="warm"]+[["scripts.json-summary-helpers.small","warm"]]}
assert len(jobs["warm"])==5
save(quiet/"jobs.json",jobs)
head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip()
assert head.startswith("833fc15d8")
patch=lab/"candidate.patch"
patch.write_bytes(subprocess.check_output(["git","diff","--binary","--","src","tests"],cwd=repo))
identity=dict(sourceRevision=head,comparisonRevision="e353ba446",sourcePatchSHA256=sha(patch),
              purpose="Publish incremental JSON prefixes before default and measure both delivered file changes",
              imageFiles=images,expectedCPythonSHA256=donor["expectedCPythonSHA256"],cpythonWorkerSHA256=donor["cpythonWorkerSHA256"],
              coreSHA256={role+suffix:manifest[core]for role,manifest in images.items()for suffix in ("","-control")},
              catalogs={name:{"sha256":sha(quiet/name)}for name in ("representative.json","jobs.json")})
save(quiet/"identity.json",identity)
collector=(baseline/"quiet/collect.py").read_text(encoding="utf-8").replace("b1619-fixtures","b1621-fixtures")
compile(collector,"collect.py","exec")
(quiet/"collect.py").write_text(collector,encoding="utf-8",newline="\n")
shutil.copyfile(baseline/"quiet/run.sh",quiet/"run.sh")
assert b"\r" not in (quiet/"run.sh").read_bytes()
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
python=Path("C:/Python313/python.exe")
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
worker=parent/"comparison/cpython-worker.py"
assert sha(worker)==identity["cpythonWorkerSHA256"]
prior_proof=read(baseline/"candidate-verify.json")
assert prior_proof["catalogSha256"]==sha(expected) and prior_proof["caseCount"]==5
assert prior_proof["launched"]["library"]["sha256"]==images["reference"][core]
shutil.copyfile(baseline/"candidate-verify.json",comparison/"reference-verify.json")
result=comparison/"candidate-verify.json"
subprocess.run([dotnet,comparison/"candidate/Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",expected,
                "--dotnet",dotnet,"--python",python,"--python-worker",worker,"--out",result],
               env=env,cwd=repo,check=True,timeout=60)
proof=read(result)
assert proof["state"]=="Completed" and proof["caseCount"]==5
assert proof["catalogSha256"]==sha(expected) and proof["launched"]["library"]["sha256"]==images["candidate"][core]
payload=quiet/"payload.tar.gz"
with tarfile.open(payload,"w:gz",compresslevel=3) as archive:
    for p in ("identity.json","jobs.json","representative.json","collect.py","run.sh"):
        archive.add(quiet/p,arcname=p,recursive=False)
    archive.add(comparison/"candidate"/core,arcname="candidate-core.dll",recursive=False)
save(quiet/"upload.json",dict(root="json-default-prefix-b1621-20261124",reference="unused-json-write-result-b1619-20261124",
                             payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
save(lab/"verified-raw-replicas.json",[])
launch=(baseline/"quiet.py").read_text(encoding="utf-8").replace('quiet=lab/"quiet"','quiet=lab/"comparison/quiet"')
launch=launch.replace("lython-b1619-unused-json-write-result-","lython-b1621-json-default-prefix-").replace("b1619-","b1621-")
launch=launch.replace("reference/'reference'/name","reference/'candidate'/name")
oldsha=read(parent/"comparison/quiet/terminal-status.json")["receipt"]["archiveSHA256"]
newsha=read(baseline/"quiet/terminal-status.json")["receipt"]["archiveSHA256"]
launch=launch.replace(oldsha,newsha)
compile(launch,"quiet.py","exec")
(lab/"quiet.py").write_text(launch,encoding="utf-8",newline="\n")
print("Staged exact file checkpoint images with five verified whole-script fixtures.")
