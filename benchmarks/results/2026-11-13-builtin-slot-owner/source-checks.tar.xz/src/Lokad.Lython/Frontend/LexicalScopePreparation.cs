namespace Lokad.Lython.Frontend;

// Prepare lexical facts once, including Python's direct super().member argument
// preloads. These depend on the complete lexical tree, not runtime name values.
internal static class LexicalScopePreparation
{
    private sealed record Scope(Scope? Parent, ScopeDirectiveFacts Facts,
        bool Function = false, bool Class = false, bool Positional = false, bool Annotation = false)
    {
        public bool IsModule => !Function && !Class && !Annotation && (Parent?.IsModule ?? true);

        public bool CanPreload => Function && Positional &&
            !Facts.IsGlobal("__class__") && !Facts.LocalNames.Contains("__class__") &&
            HasEnclosingClassBinding() && SuperIsImplicitGlobal();

        public bool HasEnclosingClassBinding()
        {
            for (var scope = Parent; scope is not null; scope = scope.Parent)
            {
                if (scope.Class) return true;
                if (scope.Facts.IsGlobal("__class__")) return false;
                if (scope.Facts.LocalNames.Contains("__class__")) return true;
            }
            return false;
        }

        private bool SuperIsImplicitGlobal()
        {
            for (var scope = this; scope is not null; scope = scope.Parent)
            {
                if (scope.Class) continue;
                if (scope.Facts.IsGlobal("super") || scope.Facts.IsNonlocal("super") ||
                    scope.Facts.LocalNames.Contains("super")) return false;
            }
            return true;
        }

        public ScopeDirectiveFacts BindGeneratorAssignments(ExpressionSyntax expression, ScopeDirectiveFacts facts)
        {
            var assigned = new HashSet<string>(StringComparer.Ordinal);
            ScopeDirectiveFactsCollector.CollectExpressionBindings(expression, assigned);
            if (assigned.Count == 0) return facts;
            var globals = new HashSet<string>(StringComparer.Ordinal);
            var nonlocals = new HashSet<string>(StringComparer.Ordinal);
            foreach (var name in assigned)
            {
                var nonlocal = false;
                for (var scope = this; scope is not null; scope = scope.Parent)
                {
                    if (scope.Class) continue;
                    if (scope.Facts.IsGlobal(name)) break;
                    if (scope.Facts.IsNonlocal(name) || scope.Function && scope.Facts.LocalNames.Contains(name))
                    {
                        nonlocal = true;
                        break;
                    }
                }
                (nonlocal ? nonlocals : globals).Add(name);
            }
            return facts with { GlobalNames = globals, NonlocalNames = nonlocals };
        }
    }

    public static void Prepare(ScriptSyntax script, Runtime.MemoryGovernor? governor = null,
        CancellationToken cancellationToken = default)
    {
        var postponed = script.Statements.OfType<ImportStatementSyntax>().Any(import =>
            import.ModuleName == "__future__" && import.ImportedMembers?.Any(member => member.Name == "annotations") == true);
        // A module owns bindings, not an enclosing class-cell capture.
        var moduleFacts = ScopeDirectiveFactsCollector.ForFunction([], script.Statements, includeClassCellRequirement: false);
        var moduleUsesSuper = moduleFacts.LocalNames.Contains("super") || moduleFacts.IsGlobal("super");
        List<CallExpressionSyntax>? preloads = null;
        List<LambdaExpressionSyntax>? lambdas = null;
        var requiresAnnotationChecks = false;
        var importsRegex = false;
        // Module bindings do not supply lexical class cells to child functions.
        var root = new Scope(null, ScopeDirectiveFacts.Empty);
        var pending = new Stack<(object Syntax, Scope Scope)>();
        PushStatements(script.Statements, root);
        while (pending.Count != 0)
        {
            var (syntax, scope) = pending.Pop();
            if (syntax is StatementSyntax statement)
            {
                governor?.ThrowIfAdmissionFailed();
                PythonTokenization.CheckCancellation(cancellationToken, statement.Span.Start);
                requiresAnnotationChecks |= statement is AnnotatedAssignmentStatementSyntax { Expression: not null };
                importsRegex |= statement is ImportStatementSyntax import &&
                    (import.ModuleName == "re" || import.ModuleName.StartsWith("re.", StringComparison.Ordinal));
                // Even a later declaration in a sibling function affects the
                // module symbol table. Decide candidate tags after this walk.
                if (statement is ScopeDirectiveStatementSyntax { Kind: ScopeDirectiveKind.Global } directive &&
                    directive.Names.Contains("super", StringComparer.Ordinal)) moduleUsesSuper = true;
                // Lazy type expressions are deliberately outside the ordinary
                // statement-expression walk, but their callable code is eager.
                if (statement is TypeAliasStatementSyntax alias)
                {
                    var aliasScope = new Scope(TypeParameterScope(scope, alias.TypeParameters),
                        ScopeDirectiveFacts.Empty, Annotation: true);
                    pending.Push((alias.Value, aliasScope));
                    PushTypeParameters(alias.TypeParameters, aliasScope);
                    continue;
                }
                foreach (var expression in ReadExpressions(statement, postponed)) pending.Push((expression, scope));
                if (statement is FunctionDefinitionStatementSyntax function)
                {
                    requiresAnnotationChecks |= function.ReturnAnnotation is not null ||
                        function.Parameters.Any(static parameter => parameter.Annotation is not null && parameter.DefaultValue is not null);
                    var enclosing = TypeParameterScope(scope, function.TypeParameters);
                    PushTypeParameters(function.TypeParameters, enclosing);
                    var facts = ScopeDirectiveFactsCollector.ForFunctionBindings(function);
                    var functionScope = new Scope(enclosing, facts,
                        Function: true, Positional: function.Parameters.Any(p => p.Kind is FunctionParameterKind.Positional or FunctionParameterKind.PositionalOnly));
                    function.PreparedScopeFacts = facts with { RequiresClassCell =
                        !facts.IsGlobal("__class__") && !facts.LocalNames.Contains("__class__") &&
                        functionScope.HasEnclosingClassBinding() && ClassCellSyntaxFacts.ReferencesFromFunction(function.Body, postponed) };
                    PushStatements(function.Body, functionScope);
                }
                else if (statement is ClassDefinitionStatementSyntax definition)
                {
                    var enclosing = TypeParameterScope(scope, definition.TypeParameters);
                    PushTypeParameters(definition.TypeParameters, enclosing);
                    PushStatements(definition.Body, new Scope(enclosing,
                        ScopeDirectiveFactsCollector.ForClass(definition), Class: true));
                }
                else foreach (var body in StatementSyntaxTraversal.EnumerateChildBodies(statement)) PushStatements(body, scope);
                continue;
            }
            var node = (ExpressionSyntax)syntax;
            if (node is IdentifierExpressionSyntax { Name: "super" } && scope.IsModule) moduleUsesSuper = true;
            if (node is MemberExpressionSyntax member && member.MemberName != "__class__" &&
                !moduleUsesSuper && scope.CanPreload &&
                Unwrap(member.Target) is CallExpressionSyntax { Arguments.Count: 0 } call &&
                Unwrap(call.Target) is IdentifierExpressionSyntax { Name: "super" })
                (preloads ??= []).Add(call);
            if (node is LambdaExpressionSyntax lambda)
            {
                (lambdas ??= []).Add(lambda);
                foreach (var parameter in lambda.Parameters)
                    if (parameter.DefaultValue is { } value) pending.Push((value, scope));
                var facts = ScopeDirectiveFactsCollector.ForLambda(lambda);
                var lambdaScope = new Scope(scope, facts, Function: true,
                    Positional: lambda.Parameters.Any(p => p.Kind is FunctionParameterKind.Positional or FunctionParameterKind.PositionalOnly));
                lambda.PreparedScopeFacts = facts with { RequiresClassCell = facts.RequiresClassCell && lambdaScope.HasEnclosingClassBinding() };
                pending.Push((lambda.Body, lambdaScope));
            }
            else if (ComprehensionSyntaxFacts.TryGetParts(node, out var items, out var clauses, out var generator))
            {
                pending.Push((clauses[0].Iterable, scope));
                var facts = ComprehensionSyntaxFacts.Bindings(clauses.Select(clause => clause.Target), generator);
                if (!generator && scope.IsModule && facts.LocalNames.Contains("super")) moduleUsesSuper = true;
                if (generator) facts = scope.BindGeneratorAssignments(node, facts);
                var bodyScope = new Scope(scope, facts, Function: generator || scope.Function, Positional: generator || scope.Positional);
                if (generator)
                    facts = facts with { RequiresClassCell = !facts.LocalNames.Contains("__class__") && bodyScope.HasEnclosingClassBinding() &&
                        ComprehensionSyntaxFacts.BodyReferencesClass(items, clauses) };
                node.PreparedComprehensionScopeFacts = facts;
                bodyScope = bodyScope with { Facts = facts };
                foreach (var item in items) pending.Push((item, bodyScope));
                for (var i = 0; i < clauses.Count; i++)
                {
                    var clause = clauses[i];
                    if (i != 0) pending.Push((clause.Iterable, bodyScope));
                    if (clause.Condition is { } condition) pending.Push((condition, bodyScope));
                    foreach (var read in AssignmentTargetFacts.Reads(clause.Target)) pending.Push((read, bodyScope));
                }
            }
            else foreach (var child in ExpressionSyntaxTraversal.EnumerateChildren(node)) pending.Push((child, scope));
        }

        if (!moduleUsesSuper && preloads is not null)
            foreach (var call in preloads) call.PreloadImplicitSuperArguments = true;

        script.PreparedScopeFacts = moduleFacts;
        script.PreparedLambdas = lambdas ?? [];
        script.RequiresAnnotationChecks = requiresAnnotationChecks;
        script.ImportsRegex = importsRegex;

        void PushStatements(IReadOnlyList<StatementSyntax> statements, Scope scope)
        {
            foreach (var statement in statements) pending.Push((statement, scope));
        }

        void PushTypeParameters(IReadOnlyList<TypeParameterSyntax>? parameters, Scope scope)
        {
            if (parameters is null) return;
            foreach (var parameter in parameters)
            {
                if (parameter.Bound is { } bound) pending.Push((bound, scope));
                if (parameter.Default is { } value) pending.Push((value, scope));
            }
        }
    }

    private static Scope TypeParameterScope(Scope parent, IReadOnlyList<TypeParameterSyntax>? parameters)
    {
        if (parameters is not { Count: > 0 }) return parent;
        var names = parameters.Select(p => p.Name).ToArray();
        return new Scope(parent, new ScopeDirectiveFacts(ScopeDirectiveFacts.Empty.GlobalNames,
            ScopeDirectiveFacts.Empty.NonlocalNames, new HashSet<string>(names, StringComparer.Ordinal), names), Annotation: true);
    }

    private static ExpressionSyntax Unwrap(ExpressionSyntax expression)
    {
        while (expression is ParenthesizedExpressionSyntax parentheses) expression = parentheses.Inner;
        return expression;
    }

    internal static IEnumerable<ExpressionSyntax> ReadExpressions(StatementSyntax statement, bool postponedAnnotations)
    {
        if (statement is DeleteStatementSyntax deleted)
        {
            foreach (var read in DeletedTargetReads(deleted.Target)) yield return read;
            yield break;
        }
        if (postponedAnnotations && statement is FunctionDefinitionStatementSyntax function)
        {
            foreach (var decorator in function.Decorators) yield return decorator;
            foreach (var parameter in function.Parameters)
                if (parameter.DefaultValue is { } value) yield return value;
            yield break;
        }
        foreach (var expression in StatementSyntaxTraversal.EnumerateDirectExpressions(statement))
            if (!(postponedAnnotations && statement is AnnotatedAssignmentStatementSyntax annotation &&
                ReferenceEquals(expression, annotation.Annotation))) yield return expression;
    }

    private static IEnumerable<ExpressionSyntax> DeletedTargetReads(ExpressionSyntax target)
    {
        target = Unwrap(target);
        if (target is IdentifierExpressionSyntax) yield break;
        if (target is TupleLiteralExpressionSyntax tuple)
        {
            foreach (var item in tuple.Items)
                foreach (var read in DeletedTargetReads(item.Expression)) yield return read;
        }
        else if (target is ListLiteralExpressionSyntax list)
        {
            foreach (var item in list.Items)
                foreach (var read in DeletedTargetReads(item.Expression)) yield return read;
        }
        else foreach (var read in ExpressionSyntaxTraversal.EnumerateChildren(target)) yield return read;
    }

}
