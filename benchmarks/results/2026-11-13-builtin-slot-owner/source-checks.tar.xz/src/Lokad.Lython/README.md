# Lokad.Lython core

The managed Python frontend and executable runtime target .NET 10. Public API
types are under `Public/`; host capabilities and the regex contract are under
`Host/`. The optional Utf8Regex adapter is a separate project.

See the [project README](../../README.md#documentation),
[runtime and embedding contract](../../docs/RUNTIME.md).
