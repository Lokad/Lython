import hashlib
import json
import os
from pathlib import Path
import shutil
import statistics
import subprocess

lab = Path(__file__).resolve().parent
repo = Path.cwd()
profile = lab.parent / 'owned-annotation-values'
trial = repo / '.git/agent-worktrees/utf8-expanded-format'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')

reference = subprocess.check_output(['git','rev-parse','e631ab53c'],text=True).strip()
candidate = subprocess.check_output(['git','-C',trial,'rev-parse','HEAD'], text=True).strip()
assert reference.startswith('e631ab53c') and candidate != reference
assert not subprocess.check_output(['git','-C',trial,'status','--porcelain'])
subprocess.run(['git','merge-base','--is-ancestor',reference,candidate], check=True)
subprocess.run(['git','diff','--exit-code',reference,candidate,'--','global.json','Directory.Build.props',
                'Directory.Packages.props','benchmarks/cpython-worker.py','benchmarks/Lokad.Lython.Benchmarks',
                'src/Lokad.Lython.Utf8Regex'], check=True)
(lab/'measured-source.patch').write_bytes(subprocess.check_output(['git','diff','--binary',reference,candidate,'--','src','tests']))
catalog=read(lab.parent/'method-format-frame/catalog.json')
nested=next(case for case in catalog['cases'] if case['id']=='strings.nested-format-report.medium')
unicode=nested.copy()
source=nested['source'].replace('{row:0{width}d}','{row:🟩>{width}d}').replace('{following:0{width}d}', '{following:λ^{width}d}')
assert source!=nested['source'] and source.count('{width}')==2
expected = subprocess.check_output(['C:/Python313/python.exe','-I','-X','utf8','-c',source]).decode('utf-8').replace('\r\n','\n')
unicode.update(id='strings.nested-format-unicode.medium',source=source,sourceUtf8Bytes=len(source.encode('utf-8')),
    sourceSha256=hashlib.sha256(source.encode('utf-8')).hexdigest(),expectedOutput=expected,
    expectedOutputUtf8Bytes=len(expected.encode('utf-8')),expectedOutputSha256=hashlib.sha256(expected.encode('utf-8')).hexdigest())
catalog['cases'].append(unicode)
manifest = lab/'catalog.json'
write(manifest, catalog)

sdk = Path.home()/'.dotnet11'
dotnet = sdk/'dotnet.exe'
env = dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
core = 'Lokad.Lython.dll'
previous = read(profile/'frozen-identity.json')
subprocess.run(['git','diff','--exit-code',previous['candidateCommit'],reference,'--','src/Lokad.Lython.Utf8Regex','tools','global.json',
                'Directory.Build.props','Directory.Packages.props','benchmarks/Lokad.Lython.Benchmarks','benchmarks/cpython-worker.py'],check=True)
files = previous['images']['candidate']
assert len(files)==32 and {name:sha(profile/'frozen/candidate'/name) for name in files}==files
images = {}
for role in ('reference','candidate'):
    image = lab/'frozen'/role
    image.mkdir(parents=True, exist_ok=True)
    expected = files.copy()
    for name in files:
        built = lab/'build-win/bin/Lokad.Lython/release_net11.0'/core if role=='candidate' else lab/'reference-build/bin/Lokad.Lython/release_net11.0'/core
        origin = built if name==core else profile/'frozen/candidate'/name
        shutil.copyfile(origin,image/name)
        if name == core: expected[core] = sha(origin)
    for helper in (lab.parent/'native-format-selectors-r615/frozen/candidate').glob('ValidatedAllocation.*'):
        shutil.copyfile(helper,image/helper.name)
    assert {name:sha(image/name) for name in expected} == expected
    with (lab/(role+'-verify.log')).open('wb') as log:
        subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',manifest,
                        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',repo/'benchmarks/cpython-worker.py',
                        '--out',lab/(role+'-verify.json')], env=env,stdout=log,stderr=subprocess.STDOUT, check=True,timeout=140)
    verified=read(lab/(role+'-verify.json'))
    assert verified['state']=='Completed' and verified['catalogSha256']==sha(manifest)
    with (lab/(role+'-allocation.log')).open('wb') as log:
        subprocess.run([dotnet,image/'ValidatedAllocation.dll',image,manifest,lab/(role+'-allocation.json')],
                       env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
    assert {name:sha(image/name) for name in expected} == expected
    images[role]=expected
assert images['reference'][core] != images['candidate'][core]
write(lab/'frozen-identity.json',dict(referenceCommit=reference,candidateCommit=candidate,casesSHA256=sha(manifest),images=images))
for a,b in zip(*(read(lab/(role+'-allocation.json'))['rows'] for role in images),strict=True):
    assert a['id']==b['id'] and a['sharedBudgetBaselineRestored'] and b['sharedBudgetBaselineRestored']
    before,after=[statistics.median(row['allocatedBytesPerInvocation']) for row in (a,b)]
    print(a['id'],f'{before:,} to {after:,} {100*(after/before-1):+.2f}%',a['peakExecutionMemoryBytes'],b['peakExecutionMemoryBytes'])
print('Both 32-file images match all six CPython goldens and restored the shared allowance.')
