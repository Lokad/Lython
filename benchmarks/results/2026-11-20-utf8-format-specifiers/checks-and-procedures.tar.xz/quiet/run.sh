set -eu
root=/home/lokad/lython-bench-checks/utf8-expanded-format-b1172-20261120
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
