from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile

repo=Path.cwd();r=Path(__file__).parent
out=repo/'benchmarks/results/2026-11-11-dispatch-completion-withdrawn';out.mkdir()
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
assert not subprocess.check_output(['git','diff','4aa2d46d','--','src/Lokad.Lython'])
checks=load(r/'focused-checks.json');restored=load(r/'restored-checks.json')
assert len(checks)==len(restored)==4
assert all(v['exitCode']==0 and v['counts']['failed']=='0'for v in [*checks.values(),*restored.values()])
decision=dict(status='Withdraw complete production prototype; exact qualified4aa source restored, forced nonincremental build and focused restored checks pass.',
    architecturalFinding='The explicit compiler terminators make a second array-end success path redundant, but removing generic jump state by direct routes adds22net source lines, route exits and duplicated cleanup guards. The same pending-disposal advancement protocol remains necessary. No new construction/storage phase disappears.',
    measurements='Allocation flat across six complete scripts on both APIs; all outputs/balances/fixture cleanup pass. Desktop elapsed/coarse CPU mixed and adverse with moving unchanged controls; no CPU gain, equivalence or causal regression claim. No quiet confirmation selected because the complete design does not simplify enough to justify its additional routing, not because an improvement percentage failed.',
    retention='No runtime change, partial branch tweak, new helper/backend/mode/public option or test-specific architecture remains. Original source/cores/commands/builds/tests/all adverse observations survive.',
    next='Assess an uncovered complete patch-generation workflow through the existing comparison catalog, independent CPython/file goldens and source-cost gate. Current difflib already uses two reused native match-length maps, not a proposed quadratic guest grid; do not invent its removal.',
    broaderGoal='Substantial complete-script performance remains active; this bounded withdrawal is not completion or a permanent design veto.')
(out/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8')
for name in ['before.json','diagnostic-identity.json','focused-checks.json','restored-checks.json','restoration.json','source.patch']:shutil.copyfile(r/name,out/name)
for phase in ['warm-sync','warm-async','compile']:
    folder=out/'desktop'/phase;folder.mkdir(parents=True)
    x=load(r/phase/'measurements.json');assert all(x[k]for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
    for name in ['measurements.json','summary.json','stderr.log','hash-witness.json']:shutil.copyfile(r/phase/name,folder/name)
with tarfile.open(out/'preparation.tar.xz','w:xz')as t:
    for p in sorted(r.rglob('*')):
        if p.is_file()and 'images'not in p.relative_to(r).parts and '__pycache__'not in p.parts:t.add(p,arcname=p.relative_to(r).as_posix())
    for role in ['before','candidate']:t.add(r/'images'/role/'Lokad.Lython.dll',arcname='cores/'+role+'/Lokad.Lython.dll')
manifest={}
p=out/'preparation.tar.xz'
with tarfile.open(p)as t:
    for m in t.getmembers():
        if m.isfile():t.extractfile(m).read()
manifest[p.name]=dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
(out/'archive-identity.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
summary=load(r/'warm-sync/summary.json')
asyncRows={x['case']:x for x in load(r/'warm-async/summary.json')['rows']}
rows=[]
for x in summary['rows']:
    ranges=[]
    for row in [x,asyncRows[x['case']]]:
        values=[v['elapsedMilliseconds']for v in row['candidateChangePercent'].values()]
        ranges.append(f'{min(values):+.2f}..{max(values):+.2f}%')
    rows.append('| '+x['case'].replace('scripts.','').replace('.large','')+' | '+' | '.join(ranges)+' |')
(out/'README.md').write_text('''# R228 — dispatch completion prototype withdrawn

2026-11-11. Exact qualified4aa/9ee7 baseline, evidence HEADd7279fcb; candidate548a9edc,
one production file. No retained runtime change or current CPython ratio. [Decision](decision.json).

The compiler already emits explicit completion/return/jump/throw terminators. The
prototype removes the additional array-end successful completion and per-instruction
jumped flag/test, routing taken control/exception paths directly back to dispatch.
Managed bounds checks and per-instruction cancellation/terminal-refusal checks stay;
pending async cleanup retains its instruction and advancement outcome.

**Withdraw the whole design.** Direct routes add22net source lines, route exits and
duplicate cleanup guards while retaining the necessary disposal protocol. No extra
argument/frame/storage phase disappears. Allocation is flat. Mixed desktop clocks
do not establish CPU gain/equivalence or an isolated regression. The added routing
is not justified as a simplification; no quiet campaign or partial branch rescue
is selected. This is not a fixed-percentage veto or permanent rejection of a larger
dispatch redesign. R227's method samples include useful inlined scanning.

## Bounded complete-script observations

Existing six scripts, fixed common worker/adapter/auxiliary images; only core DLL
differs.256warmups/image,5rotated16-invocation rounds, two identical baseline ALCs
and one candidate in the same Windows/.NET11RC3 process, ordinary GC/tiering.
These are **diagnostic desktop elapsed ranges**, relative to both baseline roles:

| Complete script | Sync envelope | Async envelope |
| --- | ---: | ---: |
'''+ '\n'.join(rows)+'''

Envelope includes mediated file I/O, fixture reset, full output checks and result
disposal; excludes startup/compilation/final cache disposal. Separate Run-only clocks
exclude reset, post-return verification and disposal. Both clocks and every original
sample survive in [desktop](desktop/warm-sync/measurements.json). Shared JIT/GC and
variable controls prevent CPU conclusions. Compile construction/disposal is separate;
its source is unchanged, allocation flat, clocks variable/adverse up to+31.58%.
Warm compilation/retained capacity are not combined into a universal speed claim.

Candidate passes **1046internal/3483public per actual.NET11/.NET10**, including
protected/generator/import/control semantics, nonallocating cancellation loops,
terminal refusal, held async cleanup, retained values and shared-budget reuse.
All measurement goldens, stable/final-zero balances, image isolation and fixture
cleanup pass. No new test freezes the discarded architecture.

Guarded restoration verifies the owned candidate before writing the exact original;
all production bytes equal qualified4aa. Forced nonincremental solution rebuild
22.54s/0warnings/errors and **62internal/119public per actualtarget** pass. Rebuilt
cores have separate recorded identities, no timing claim. Cached full delivery
42953725339 remains authoritative for unchanged production; no full replay/pin or
publication. [Restoration](restoration.json),[focused](focused-checks.json),
[restored checks](restored-checks.json),[all source/cores/conditions/logs](preparation.tar.xz),
[archive identity](archive-identity.json).

Next assess the missing complete patch-generation shape using existing tooling.
Current difflib already reuses native match-length dictionaries; do not assume a
quadratic guest grid or select another narrow shortcut without workload evidence.
The broader performance objective remains active.
''',encoding='utf-8')
print(json.dumps(manifest))
