from pathlib import Path
import hashlib,json,os,re,shutil,subprocess
repo=Path('D:/code/Lython');root=repo/'.git/agent-notes/review-20261031/adapter40'
log=(root/'public-net11.0.log').read_text(encoding='utf-8');shutil.copyfile(root/'public-net11.0.log',root/'public-net11.0-fixture-failure.log')
paths=sorted(set(re.findall(r'Fixture directory does not exist: (.+?) \(searched',log)));assert len(paths)==5
failed=re.findall(r'^  Failed (\S+) \[',log,re.M);assert len(failed)==5
assert re.search(r'Failed:\s+5, Passed:\s+416,',log)
manifest={}
for relative in paths:
 source=repo/'tests/Fixtures'/relative;assert source.is_dir()
 manifest[relative]={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in source.rglob('*') if p.is_file()}
 for framework in ['net11.0','net10.0']:
  target=root/f'out/Lokad.Lython.PublicApi.Tests/Release/{framework}/Fixtures'/relative
  shutil.copytree(source,target,dirs_exist_ok=True)
(root/'workflow-fixture-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
(root/'fixture-layout-correction.md').write_text('''# Private workflow fixture layout

The selected public.NET11 run passed416 and failed5 because the relocated output
is no longer below tests/Fixtures. Original failure log retained; all five are
DirectoryNotFoundException before guest execution. Copy those maintained workflow
fixtures (hash manifest recorded) into both private output fixture trees. No
production/test assertion change or rebuild. Rerun only the five failed.NET11
cases, then run the still-unexecuted.NET10 selections. Do not replay unchanged
416 public/84 internal.NET11 successes. The exact producer/cursor source remains.
''',encoding='utf-8')
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
props=[f'-p:DirectoryBuildPropsPath={root}/Directory.Build.props',f'-p:DirectoryPackagesPropsPath={root}/Directory.Packages.props',f'-p:RestoreConfigFile={root}/NuGet.Config']
filters=json.loads((root/'filters.json').read_text(encoding='utf-8'))
results={}
for framework,suite,selection,label in [('net11.0','public','|'.join('FullyQualifiedName='+n for n in failed),'public-net11.0-final-fixtures'),('net10.0','internal',filters['native'],'internal-net10.0'),('net10.0','public',filters['public'],'public-net10.0')]:
 project='tests/Lokad.Lython.Tests' if suite=='internal' else 'tests/Lokad.Lython.PublicApi.Tests'
 with (root/(label+'.log')).open('w',encoding='utf-8') as output:
  r=subprocess.run([env['DOTNET_HOST_PATH'],'test',project,'-c','Release','-f',framework,'--no-build','--no-restore',*props,'--filter',selection],cwd=repo,env=env,stdout=output,stderr=subprocess.STDOUT)
 text=(root/(label+'.log')).read_text(encoding='utf-8');print(label,r.returncode,text[-450:],flush=True)
 if r.returncode:print(text[-8000:]);raise SystemExit(r.returncode)
 results[label]=int(re.search(r'Passed:\s+(\d+)',text)[1])
(root/'final-checks.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
