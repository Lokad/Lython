from pathlib import Path
import hashlib,json,shutil
repo=Path('D:/code/Lython');root=repo/'.git/agent-notes/review-20261031/adapter40';old=root.parent/'adapter29'
(root/'feed').mkdir(exist_ok=False)
assessment=json.loads((root/'source-assessment.json').read_text(encoding='utf-8'))
for name,expected in assessment['packages'].items():
 p=Path(f'D:/code/utf8regex/artifacts/nuget/{name}.0.5.0-dev.40.nupkg');assert hashlib.sha256(p.read_bytes()).hexdigest()==expected['sha256'];shutil.copyfile(p,root/'feed'/p.name)
s=(old/'Directory.Build.props').read_text(encoding='utf-8').replace('/adapter29/','/adapter40/')
s=s.replace('<RestoreFallbackFolders>','<RestoreFallbackFolders>D:/code/Lython/.git/agent-notes/review-20261031/adapter29/packages;')
s=s.replace('</Project>','''  <ItemGroup Condition="'$(MSBuildProjectName)' == 'Lokad.Lython.Utf8Regex'">
    <Compile Remove="Utf8RegexProvider.cs" />
    <Compile Include="D:/code/Lython/.git/agent-notes/review-20261031/adapter40/Utf8RegexProvider.cs" Link="Utf8RegexProvider.cs" />
  </ItemGroup>
</Project>''')
(root/'Directory.Build.props').write_text(s,encoding='utf-8')
(root/'Directory.Packages.props').write_text((old/'Directory.Packages.props').read_text(encoding='utf-8').replace('0.5.0-dev.29','0.5.0-dev.40'),encoding='utf-8')
(root/'NuGet.Config').write_text((old/'NuGet.Config').read_text(encoding='utf-8').replace('/adapter29/','/adapter40/'),encoding='utf-8')
shutil.copyfile(old/'filters.json',root/'filters.json')
s=(old/'check.ps1').read_text(encoding='utf-8').replace('/adapter29', '/adapter40').replace('Get-Content "','Get-Content -Encoding utf8 "').replace('Get-Content "$privateRoot/filters.json" -Raw','Get-Content -Encoding utf8 "$privateRoot/filters.json" -Raw')
s=s.replace('Get-Content -Encoding utf8 -Encoding utf8','Get-Content -Encoding utf8')
(root/'check.ps1').write_text(s,encoding='utf-8')
p=repo/'src/Lokad.Lython.Utf8Regex/Utf8RegexProvider.cs';original=p.read_text(encoding='utf-8');(root/'original-Utf8RegexProvider.cs.txt').write_text(original,encoding='utf-8')
s=original.replace('            private readonly CancellationTokenSource _cancellation;\n','').replace('                _cancellation = new CancellationTokenSource();\n','')
s=s.replace('                    using var registration = Forward(token);\n                    _cursor = Backend(() => subject.Pattern.Regex.CreateMatchCursor(subject.BoundedInput, subject._startByte, _cancellation.Token), token, patternSource: subject.Pattern.Regex);', '''                    // Creation validates the subject under this call's token.
                    // The detached synthetic token cannot retain an earlier caller.
                    using var creation = new CancellationTokenSource();
                    using var registration = token.Register(static state => ((CancellationTokenSource)state!).Cancel(), creation);
                    _cursor = Backend(() => subject.Pattern.Regex.CreateMatchCursor(subject.BoundedInput, subject._startByte, creation.Token), token, patternSource: subject.Pattern.Regex);
                    token.ThrowIfCancellationRequested();''')
s=s.replace('''            private CancellationTokenRegistration Forward(CancellationToken token)
                => token.Register(static state => ((CancellationTokenSource)state!).Cancel(), _cancellation);

''','')
s=s.replace('''                    using (Forward(token))
                    {
                        if (Backend(() => _cursor.MoveNext(), token, patternSource: _subject.Pattern.Regex)) return _subject.Convert(_cursor.Current, token);
                    }''','''                    var next = Backend(() =>
                    {
                        var success = _cursor.MoveNext(out var match, token);
                        return (success, match);
                    }, token, patternSource: _subject.Pattern.Regex);
                    if (next.success) return Convert(next.match, token);''')
s=s.replace('                Close(); _cancellation.Dispose();','                Close();')
needle='''            private void Close()
'''
assert s.count(needle)==1
s=s.replace(needle,'''            private static LythonRegexMatch Convert(Utf8PythonRangeMatch data, CancellationToken token)
            {
                var captures = new LythonRegexCapture?[data.Groups.Length];
                for (var i = 0; i < captures.Length; i++)
                {
                    token.ThrowIfCancellationRequested();
                    if (!data.TryGetGroup(i, out var group) || !group.Success) continue;
                    captures[i] = new(group.StartOffsetInBytes, group.EndOffsetInBytes);
                }
                return new(captures, data.LastIndex);
            }

'''+needle)
assert '_cancellation' not in s and 'Forward(token)' not in s and '_cursor.Current' not in s
(root/'Utf8RegexProvider.cs').write_text(s,encoding='utf-8')
import difflib
(root/'provider.patch').write_text(''.join(difflib.unified_diff(original.splitlines(keepends=True),s.splitlines(keepends=True),fromfile='src/Lokad.Lython.Utf8Regex/Utf8RegexProvider.cs',tofile='private-dev40/Utf8RegexProvider.cs')),encoding='utf-8')
(root/'pre-qualification-plan.md').write_text('''# Independent dev40 cursor simplification

Lython source f145daa3 (runtime source88f12099 plus receipt), exact immutable
producerdev40 packages/source6f6fdab9 and SHA256 in source-assessment.json.
Normal adapter0.4 pin, locks, outputs and core dependency graph stay unchanged.
This private Directory.Build.props substitutes only the optional provider source
and pins producer40 in isolated feed/cache/obj/out/locks. No sibling edits.

Hypothesis: native byte-range advances eliminate detailed captured text/global
coordinate-map projection, while direct per-advance tokens eliminate repeated
cancellation registrations and the adapter's cursor CTS field/disposal path.
Creation still validates the entire input. Keep its real in-flight cancellation
using a constructor-local synthetic CTS/registration, disposed before returning;
the backend therefore cannot retain the creation caller's token. Current Next
passes its actual token into producer work and capture processing. Preserve
existing coarse owner/reservation, errors, original-subject byte windows, empty
progression, captures, named lookup and disposal. No replacement quotas/owners.

Run the existing exact dev29 focused selections against actual.NET11/.NET10,
including CursorUsesCurrentAdvanceToken (cancel earlier Find token), actual
in-flight compile/match/cursor subprocesses, shared-budget refusal/unwind/cache
and retained patterns/results, re/fnmatch/glob/frontend goldens. Use loaded DLL
hashes for exact package proof. Preserve any failure and refine boundedly when
source evidence identifies a compatibility defect. No broad benchmark or full
platform replay for a private prototype. A short affected allocation/comparison
can follow semantic success; do not infer backend speed from source deletion.

This is development plumbing, not released-adapter promotion, producer managed-
safety qualification, exact backend storage accounting or general final adapter
qualification. Existing adapter-local one-shot/name/error bridges remain; producer
program/cache/working-receipt integration and missing native names/reversed-window
capabilities require separate explicit assessment. Missing published capabilities
do not stop core development or these correctness checks. Publication postponed.
''',encoding='utf-8')
(root/'prototype-identity.json').write_text(json.dumps(dict(developmentOnly=True,normalPin='0.4.0 unchanged',sourceRevision='f145daa3 (runtime88f12099)',providerSHA256=hashlib.sha256((root/'Utf8RegexProvider.cs').read_bytes()).hexdigest(),packages=assessment['packages']),indent=2)+'\n',encoding='utf-8')
print('Isolated dev40 cursor prototype prepared; no normal-source/pin changes')
