$ErrorActionPreference='Stop'
$env:DOTNET_ROOT='C:/Users/JoannesVermorel/.dotnet11'
$env:DOTNET_HOST_PATH='C:/Users/JoannesVermorel/.dotnet11/dotnet.exe'
$env:PATH=$env:DOTNET_ROOT+';'+$env:PATH
$privateRoot='D:/code/Lython/.git/agent-notes/review-20261031/adapter40'
$properties=@("-p:DirectoryBuildPropsPath=$privateRoot/Directory.Build.props", "-p:DirectoryPackagesPropsPath=$privateRoot/Directory.Packages.props", "-p:RestoreConfigFile=$privateRoot/NuGet.Config")
foreach($suite in 'internal','public') {
    $project=if($suite -eq 'internal') {'tests/Lokad.Lython.Tests'} else {'tests/Lokad.Lython.PublicApi.Tests'}
    dotnet build $project -c Release @properties *> "$privateRoot/build-$suite.log"
    $code=$LASTEXITCODE
    Get-Content -Encoding utf8 "$privateRoot/build-$suite.log" -Tail 9
    if($code -ne 0){exit $code}
}
$workerTarget="$privateRoot/out/Lokad.Lython.WorkerFixture/Release"
if(-not (Test-Path -LiteralPath $workerTarget)){throw 'Private worker fixture was not built'}
New-Item -ItemType Directory -Path "$privateRoot/tests/Lokad.Lython.WorkerFixture/bin" -Force | Out-Null
New-Item -ItemType Junction -Path "$privateRoot/tests/Lokad.Lython.WorkerFixture/bin/Release" -Target $workerTarget | Out-Null
$filters=Get-Content -Encoding utf8 "$privateRoot/filters.json" -Raw | ConvertFrom-Json
foreach($framework in 'net11.0','net10.0') {
    foreach($suite in 'internal','public') {
        $project=if($suite -eq 'internal') {'tests/Lokad.Lython.Tests'} else {'tests/Lokad.Lython.PublicApi.Tests'}
        $filter=if($suite -eq 'internal') {$filters.native} else {$filters.public}
        if([string]::IsNullOrWhiteSpace($filter)){throw 'Missing exact qualification selection'}
        dotnet test $project -c Release -f $framework --no-build --no-restore @properties --filter $filter *> "$privateRoot/$suite-$framework.log"
        $code=$LASTEXITCODE
        Get-Content -Encoding utf8 "$privateRoot/$suite-$framework.log" -Tail 18
        if($code -ne 0){exit $code}
    }
}
