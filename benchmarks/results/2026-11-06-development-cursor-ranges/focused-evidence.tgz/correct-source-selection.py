from pathlib import Path
import shutil
root=Path('D:/code/Lython/.git/agent-notes/review-20261031/adapter40')
shutil.copyfile(root/'build-internal.log',root/'build-internal-source-selection-failure.log')
p=root/'Directory.Build.props';s=p.read_text(encoding='utf-8').replace('    <Compile Remove="Utf8RegexProvider.cs" />\n','');s=s.replace('  <ItemGroup Condition=', '''  <PropertyGroup Condition="'$(MSBuildProjectName)' == 'Lokad.Lython.Utf8Regex'">
    <DefaultItemExcludes>$(DefaultItemExcludes);Utf8RegexProvider.cs</DefaultItemExcludes>
  </PropertyGroup>
  <ItemGroup Condition=''');p.write_text(s,encoding='utf-8')
(root/'source-selection-correction.md').write_text('''# Private source-selection correction

The first build compiled both normal and substituted provider sources: Compile
Remove in early Directory.Build.props ran before SDK default item inclusion.
Original44 duplicate-definition errors are retained. Exclude the normal provider
from that one project's default glob, and explicitly include the private source.
No production source, pin, lock or core dependency was changed. Retry qualification
with this corrected private harness; this is not a producer semantic result.
''',encoding='utf-8')
