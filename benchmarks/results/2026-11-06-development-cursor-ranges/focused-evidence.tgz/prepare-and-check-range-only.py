from pathlib import Path
import hashlib,json,os,shutil,subprocess
repo=Path('D:/code/Lython');root=repo/'.git/agent-notes/review-20261031/adapter40';saved=root/'direct-token-prototype';saved.mkdir(exist_ok=False)
for name in ['Utf8RegexProvider.cs','prototype-identity.json','focused-qualification.json','provider.patch','cursor-diagnostic.json']:
 shutil.copyfile(root/name,saved/name)
# Verify the exact immutable producer source rather than attributing newer HEAD.
source=subprocess.check_output(['git','-C','D:/code/utf8regex','show','6f6fdab9e8b2a801db1863bcfd1984dc357262c1:src/Lokad.Utf8Regex.PythonRe/Utf8PythonMatchCursor.cs'],text=True,encoding='utf-8')
assert 'CancellationTokenSource.CreateLinkedTokenSource(original, cancellationToken)' in source
(saved/'producer-cursor-exact-dev40.cs.txt').write_text(source,encoding='utf-8')
original=(root/'original-Utf8RegexProvider.cs.txt').read_text(encoding='utf-8')
s=original.replace('''                        if (Backend(() => _cursor.MoveNext(), token, patternSource: _subject.Pattern.Regex)) return _subject.Convert(_cursor.Current, token);''','''                        var next = Backend(() =>
                        {
                            var success = _cursor.MoveNext(out var match);
                            return (success, match);
                        }, token, patternSource: _subject.Pattern.Regex);
                        if (next.success) return Convert(next.match, token);''')
converter=(saved/'Utf8RegexProvider.cs').read_text(encoding='utf-8');a=converter.index('            private static LythonRegexMatch Convert(Utf8PythonRangeMatch');b=converter.index('            private void Close()',a)
s=s.replace('            private void Close()',converter[a:b]+'            private void Close()')
assert '_cursor.Current' not in s and 'Forward(token)' in s and 'MoveNext(out var match)' in s
(root/'Utf8RegexProvider.cs').write_text(s,encoding='utf-8')
(root/'range-only-refinement.md').write_text('''# Bounded range-only refinement

Direct current-token + native ranges passed84internal/421public per actual
runtime (loaded exactdev40 DLLs verified). Its controlled same-producer cursor
allocation diagnostic is adverse:29,640 vs28,976 bytes/cursor, +2.29155% in both
identical roles. Busy Windows elapsed~0.113ms vs~0.148ms is diagnostic, not a
qualified CPU gain. Preserve source, qualification and all observations under
direct-token-prototype/; no automatic promotion.

Exact producer source6f6fdab9 Utf8PythonMatchCursor.MoveNextCore links an advance
token to its retained cancellable creation token. A disposed synthetic CTS token
is still cancellable, so the apparently simpler direct-token adapter moves new
linked-CTS work into every advance. Creation validates all input under its token;
using None only with boundary checks would lose actual in-flight cancellation.

One source-justified refinement: keep the already-qualified adapter-local token
bridge for real creation/advance work, use native byte-range snapshots and avoid
detailed Current. No new cancellation framework, owner, quota or option. Repeat
focused semantic/current-token/in-flight/refusal/ownership checks for this changed
variant both runtimes; one same-producer cursor allocation control. Keep direct
and range-only outcomes separate; decide the selected private development variant.
Do not claim the final token simplification is done: a producer API separating
creation-operation cancellation from later advances is a precise remaining need.
This missing API defers that adapter simplification, not core work or contract
correctness. Normal0.4 pin/core dependency graph/publication unchanged.
''',encoding='utf-8')
(root/'range-only-identity.json').write_text(json.dumps(dict(developmentOnly=True,normalPin='0.4.0 unchanged',sourceRevision='f145daa3 (runtime88f12099)',providerSHA256=hashlib.sha256((root/'Utf8RegexProvider.cs').read_bytes()).hexdigest(),producerSource='6f6fdab9e8b2a801db1863bcfd1984dc357262c1',variant='native ranges; existing local current-token bridge retained'),indent=2)+'\n',encoding='utf-8')
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
props=[f'-p:DirectoryBuildPropsPath={root}/Directory.Build.props',f'-p:DirectoryPackagesPropsPath={root}/Directory.Packages.props',f'-p:RestoreConfigFile={root}/NuGet.Config']
for suite in ['internal','public']:
 project='tests/Lokad.Lython.Tests' if suite=='internal' else 'tests/Lokad.Lython.PublicApi.Tests'
 with (root/f'range-only-build-{suite}.log').open('w',encoding='utf-8') as log:
  r=subprocess.run([env['DOTNET_HOST_PATH'],'build',project,'-c','Release','--no-restore','--nologo','--tl:off',*props],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
 print('range-only build',suite,r.returncode,flush=True)
 if r.returncode:print((root/f'range-only-build-{suite}.log').read_text(encoding='utf-8')[-8000:]);raise SystemExit(r.returncode)
filters=json.loads((root/'filters.json').read_text(encoding='utf-8'))
for framework in ['net11.0','net10.0']:
 for suite in ['internal','public']:
  project='tests/Lokad.Lython.Tests' if suite=='internal' else 'tests/Lokad.Lython.PublicApi.Tests'
  selection=filters['native' if suite=='internal' else 'public']
  with (root/f'range-only-{suite}-{framework}.log').open('w',encoding='utf-8') as log:
   r=subprocess.run([env['DOTNET_HOST_PATH'],'test',project,'-c','Release','-f',framework,'--no-build','--no-restore',*props,'--filter',selection],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
  print('range-only test',suite,framework,r.returncode,flush=True)
  if r.returncode:print((root/f'range-only-{suite}-{framework}.log').read_text(encoding='utf-8')[-10000:]);raise SystemExit(r.returncode)
print('Range-only focused checks complete',flush=True)
