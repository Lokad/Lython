from pathlib import Path
import hashlib,json,os,re,shutil,statistics,subprocess
repo=Path('D:/code/Lython');root=repo/'.git/agent-notes/review-20261031/adapter40';diag=root/'cursor-diagnostic';original=json.loads((root/'focused-qualification.json').read_text(encoding='utf-8'))
qualified={}
for framework in ['net11.0','net10.0']:
 for suite,count in [('internal',84),('public',421)]:
  text=(root/f'range-only-{suite}-{framework}.log').read_text(encoding='utf-8');assert re.search(fr'Failed:\s+0, Passed:\s+{count},',text)
 folder=root/f'out/Lokad.Lython.PublicApi.Tests/Release/{framework}'
 hashes={n:hashlib.sha256((folder/(n+'.dll')).read_bytes()).hexdigest() for n in ['Lokad.Lython','Lokad.Lython.Utf8Regex','Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']}
 for n in ['Lokad.Lython','Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']:assert hashes[n]==original['frameworks'][framework]['dllSHA256'][n]
 worker=root/f'out/Lokad.Lython.WorkerFixture/Release/{framework}'
 for n in hashes:assert hashlib.sha256((worker/(n+'.dll')).read_bytes()).hexdigest()==hashes[n]
 qualified[framework]=dict(internalPassed=84,publicPassed=421,dllSHA256=hashes)
(root/'range-only-qualification.json').write_text(json.dumps(dict(developmentOnly=True,promoted=False,normalPin='0.4.0 unchanged',identity=json.loads((root/'range-only-identity.json').read_text(encoding='utf-8')),frameworks=qualified,limitations='Focused private ranges/token/ownership only, including actual in-flight compile/match/cursor. Not final released producer/safety/exact-backend-accounting/whole-script qualification.'),indent=2)+'\n',encoding='utf-8')
shutil.copytree(diag/'candidate',diag/'range-only')
shutil.copyfile(root/'out/Lokad.Lython.PublicApi.Tests/Release/net11.0/Lokad.Lython.Utf8Regex.dll',diag/'range-only/Lokad.Lython.Utf8Regex.dll')
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
results=[]
for index,label in enumerate(['baseline','range-only','range-only','baseline']):
 r=subprocess.run([env['DOTNET_HOST_PATH'],str(diag/label/'CursorDiagnostic.dll'),f'{label}-{index}'],cwd=repo,env=env,capture_output=True,text=True,encoding='utf-8')
 (root/f'range-only-cursor-{label}-{index}.stdout.json').write_text(r.stdout,encoding='utf-8');(root/f'range-only-cursor-{label}-{index}.stderr.log').write_text(r.stderr,encoding='utf-8')
 if r.returncode:print(r.stdout+r.stderr);raise RuntimeError('Range-only diagnostic failed')
 v=json.loads(r.stdout);assert v['finalBudgetBytes']==0 and v['matches']==64
 for n in ['Lokad.Lython','Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']:assert v['hashes'][n].lower()==qualified['net11.0']['dllSHA256'][n]
 if label=='range-only':assert v['hashes']['Lokad.Lython.Utf8Regex'].lower()==qualified['net11.0']['dllSHA256']['Lokad.Lython.Utf8Regex']
 results.append(v);print(v['role'],v['medianAllocatedBytes'],v['medianMilliseconds'],flush=True)
baselines=[v['medianAllocatedBytes'] for v in results if v['role'].startswith('baseline')];candidates=[v['medianAllocatedBytes'] for v in results if v['role'].startswith('range-only')]
summary=dict(developmentOnly=True,performanceQualified=False,allocationBoundary=results[0]['boundary'],sameProducer=True,sourceIdentity='f145daa3 runtime88f12099/private-dev40-range-only',baselineBytes=baselines,candidateBytes=candidates,allocationDeltaPercent=100*(statistics.median(candidates)/statistics.median(baselines)-1),results=results,limitations='Direct cursor-only exact same-thread allocation diagnostic. Busy Windows elapsed diagnostic only. Existing token bridge deliberately retained; producer creation/advance token separation remains missing. No whole-script/CPython/RSS/producer-safety/final qualification claim.')
(root/'range-only-cursor-diagnostic.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in summary.items() if k!='results'}),flush=True)
