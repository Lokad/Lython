from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess
repo=Path('D:/code/Lython');root=repo/'.git/agent-notes/review-20261031/adapter40';diag=root/'cursor-diagnostic'
p=diag/'Program.cs';p.write_text(p.read_text(encoding='utf-8').replace('var samples = new List<object>();\n',''),encoding='utf-8')
(root/'diagnostic-plan.md').write_text('''# Bounded private cursor allocation control

Same immutabledev40 producer/Core/Lython and input in both roles. Original
normal adapter source is compiled privately against40 as baseline; candidate is
the focused-qualified native range/current-token prototype. Neither changes the
normal pin. Existing standalone diagnostic pattern; no production instrumentation.
Precompiled pattern/prepared192-byte UTF8 subject,64 matches with named, unmatched
and successful empty captures. Full byte-range/LastIndex golden and shared-budget
baseline/zero cleanup are required.32 warmups,7x128 cursors per process; four
processes in baseline/candidate/candidate/baseline order, exact loaded DLL hashes.
Synchronous current-thread allocated bytes are the measured allocation boundary.
Elapsed on this busy Windows host is preserved as diagnostic, not CPU/latency
qualification. No whole-script/CPython/RSS/startup/compilation claim. No forced GC.
Build original privately, then restore prototype text with forced Rebuild and
verify its DLL matches the already-qualified candidate; no timestamp-preserving
restoration or normal-output mutation. Preserve failures; one bounded correction
only for a demonstrated diagnostic/source defect.
''',encoding='utf-8')
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
dotnet=env['DOTNET_HOST_PATH'];props=[f'-p:DirectoryBuildPropsPath={root}/Directory.Build.props',f'-p:DirectoryPackagesPropsPath={root}/Directory.Packages.props',f'-p:RestoreConfigFile={root}/NuGet.Config']
def build(args,name):
 with (root/name).open('w',encoding='utf-8') as log:r=subprocess.run([dotnet,*args],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
 print(name,r.returncode,flush=True)
 if r.returncode:print((root/name).read_text(encoding='utf-8')[-9000:]);raise RuntimeError(name+' failed')
build(['build',str(diag/'CursorDiagnostic.csproj'),'-c','Release','--nologo','--tl:off'],'diagnostic-build.log')
out=diag/'bin/Release/net11.0'
for label in ['baseline','candidate']:shutil.copytree(out,diag/label)
source=root/'Utf8RegexProvider.cs';prototype=source.read_text(encoding='utf-8');qualified=json.loads((root/'focused-qualification.json').read_text(encoding='utf-8'))['frameworks']['net11.0']['dllSHA256']
try:
 source.write_text((root/'original-Utf8RegexProvider.cs.txt').read_text(encoding='utf-8'),encoding='utf-8')
 build(['build','src/Lokad.Lython.Utf8Regex','-c','Release','-f','net11.0','--no-restore','--nologo','--tl:off','-t:Rebuild',*props],'diagnostic-original-adapter-build.log')
 original=root/'out/Lokad.Lython.Utf8Regex/Release/net11.0/Lokad.Lython.Utf8Regex.dll'
 shutil.copyfile(original,diag/'baseline/Lokad.Lython.Utf8Regex.dll')
finally:
 source.write_text(prototype,encoding='utf-8')
 build(['build','src/Lokad.Lython.Utf8Regex','-c','Release','-f','net11.0','--no-restore','--nologo','--tl:off','-t:Rebuild',*props],'diagnostic-restored-prototype-build.log')
 assert hashlib.sha256((root/'out/Lokad.Lython.Utf8Regex/Release/net11.0/Lokad.Lython.Utf8Regex.dll').read_bytes()).hexdigest()==qualified['Lokad.Lython.Utf8Regex']
results=[]
for index,label in enumerate(['baseline','candidate','candidate','baseline']):
 r=subprocess.run([dotnet,str(diag/label/'CursorDiagnostic.dll'),f'{label}-{index}'],cwd=repo,env=env,capture_output=True,text=True,encoding='utf-8')
 (root/f'cursor-{label}-{index}.stdout.json').write_text(r.stdout,encoding='utf-8');(root/f'cursor-{label}-{index}.stderr.log').write_text(r.stderr,encoding='utf-8')
 if r.returncode:print(r.stdout+r.stderr);raise RuntimeError('Cursor diagnostic failed')
 v=json.loads(r.stdout);assert v['finalBudgetBytes']==0 and v['matches']==64
 for name in ['Lokad.Lython','Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']:assert v['hashes'][name].lower()==qualified[name]
 if label=='candidate':assert v['hashes']['Lokad.Lython.Utf8Regex'].lower()==qualified['Lokad.Lython.Utf8Regex']
 results.append(v);print(v['role'],v['medianAllocatedBytes'],v['medianMilliseconds'],flush=True)
baselines=[v['medianAllocatedBytes'] for v in results if v['role'].startswith('baseline')];candidates=[v['medianAllocatedBytes'] for v in results if v['role'].startswith('candidate')]
summary=dict(developmentOnly=True,performanceQualified=False,allocationBoundary=results[0]['boundary'],sameProducer=True,sourceIdentity='f145daa3 runtime88f12099/privatedev40',baselineBytes=baselines,candidateBytes=candidates,allocationDeltaPercent=100*(statistics.median(candidates)/statistics.median(baselines)-1),results=results,limitations='Direct cursor-only exact same-thread allocation diagnostic. Busy Windows elapsed diagnostic only; not whole-script/CPython/RSS/retained memory/producer-safety/final qualification.')
(root/'cursor-diagnostic.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in summary.items() if k!='results'}),flush=True)
