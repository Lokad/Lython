set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab="$PWD/.git/agent-notes/review-20261031/single-subscript-dispatch-20261125"
tests="$PWD/tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj"
filter='(FullyQualifiedName~ExactSequenceSubscriptTests|FullyQualifiedName~ClassSubscriptionTests|FullyQualifiedName~ClassSubscriptionLifetimeTests|FullyQualifiedName~DirectGlobalOperandTests|FullyQualifiedName~ExpressionListCompletionTests|FullyQualifiedName~SubscriptIndexProtocolTests|FullyQualifiedName~SubscriptStoreExecutionTests|FullyQualifiedName~TupleKeyIdentityScenarioTests|FullyQualifiedName~Csv)&Category!=Stress'
if dotnet test "$tests" -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$lab/tests-ubuntu10.log" 2>&1; then
 tail -6 "$lab/tests-ubuntu10.log"
else
 tail -35 "$lab/tests-ubuntu10.log"
 exit 1
fi
