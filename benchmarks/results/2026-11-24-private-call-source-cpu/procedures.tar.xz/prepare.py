from pathlib import Path
import hashlib
import json
import shutil
import subprocess

lab=Path(__file__).resolve().parent
root=lab.parents[3]
prior=lab.with_name('retained-rule-factory-cpu-20261124')
donor=lab.with_name('private-call-isolation-20261124')
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda content:hashlib.sha256(content).hexdigest()
digest=lambda path:sha(path.read_bytes())
write=lambda path,content:path.write_text(content,encoding='utf-8',newline='\n')
save=lambda path,content:write(path,json.dumps(content,indent=2)+'\n')
identity=read(donor/'comparison/identity.json')
subprocess.run(['git','diff','--exit-code',identity['candidate'],'c40540135','--','src','tests'],cwd=root,check=True)
assert {role:len(files) for role,files in identity['imageFiles'].items()}=={'reference':32,'candidate':32}
for role,files in identity['imageFiles'].items():
    assert {p.name:digest(p) for p in (donor/role).iterdir()}==files
receipt=read(donor/'comparison/quiet/terminal-status.json')['receipt']
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
assert digest(donor/'comparison/quiet/observations.tar.xz')==receipt['archiveSHA256']
catalog=read(donor/'comparison/representative.json')
captured='scripts.captured-rule-closures'
postponed='scripts.annotated-rule-closures.nested-factories.postponed'
invoice='scripts.csv-invoice.method-policy.quoted-control'
catalog['cases']=[next(c for c in catalog['cases'] if c['id']==key) for key in (captured,postponed,invoice)]
save(lab/'catalog.json',catalog)
profiles=[('captured-current',captured,'candidate'),('postponed-reference',postponed,'reference'),
    ('postponed-current',postponed,'candidate'),('invoice-reference',invoice,'reference'),('invoice-current',invoice,'candidate')]
identity.update(purpose='Attribute the remaining captured-rule CPU and sample both affected controls against the B1599 reference',
    productionSource='c40540135',donorArchiveSHA256=receipt['archiveSHA256'],profileCatalogSHA256=digest(lab/'catalog.json'),profiles=profiles)
save(lab/'identity.json',identity)

collector=(prior/'collect.py').read_text(encoding='utf-8')
collector=collector.replace('external-arithmetic-operands-b1574-20261124','private-call-isolation-b1599-20261124').replace('b1577-fixtures','b1601-fixtures')
collector=collector.replace('expected = json.loads((root/"identity.json").read_text())["imageFiles"]["candidate"]','identity = json.loads((root/"identity.json").read_text())')
collector=collector.replace('    assert len(expected)==32\n    assert all(digest(image/name)==value for name,value in expected.items())',
    '    for role, expected in identity["imageFiles"].items():\n        frozen = image.parent / role\n        assert len(expected)==32\n        assert {p.name:digest(p) for p in frozen.iterdir()}==expected')
collector=collector.replace('>= 10*1024*1024','>= 7*1024*1024')
collector=collector.replace('root/"profiles",image],check=True)','root/"profiles",image.parent],check=True)')
compile(collector,'collect.py','exec');write(lab/'collect.py',collector)

ops=(prior/'ops-profile.py').read_text(encoding='utf-8')
ops=ops.replace('image = pathlib.Path(sys.argv[2]).resolve()','images = pathlib.Path(sys.argv[2]).resolve()')
ops=ops.replace("for name, case_id, lane in [('default-warm', 'scripts.rule-default-closures', 'warm'), ('captured-warm', 'scripts.captured-rule-closures', 'warm')]:\n\n        tree, tfm = image, \"net11.0\"",'for name, case_id, role in json.loads((root/"identity.json").read_text())["profiles"]:\n\n        lane = "warm"\n        tree = images / role')
ops=ops.replace("expected_image['imageFiles']['candidate'].items()","expected_image['imageFiles'][role].items()").replace('(image/filename).read_bytes()','(tree/filename).read_bytes()').replace("expected['coreSHA256']['candidate']","expected['coreSHA256'][role]")
ops=ops.replace('"lane": lane, "count": count','"lane": lane, "role": role, "count": count')
ops=ops.replace("total_capture_seconds > 30", "total_capture_seconds > 40")
compile(ops,'ops-profile.py','exec');write(lab/'ops-profile.py',ops)

analyzer=(prior/'analyze.py').read_text(encoding='utf-8')
analyzer=analyzer.replace("for label in ['default-warm', 'captured-warm']:","for label, case, role in json.loads((r/'identity.json').read_text(encoding='utf-8'))['profiles']:")
analyzer=analyzer.replace('rows.append(dict(label=label,case=record[\'workload\']','rows.append(dict(label=label,role=role,case=record[\'workload\']')
analyzer=analyzer.replace("'StartNativeCall','StartInline'","'StartNativeWorkspace','StartNativeCall','StartInline'")
analyzer=analyzer.replace("'TryIntegerChain','TryMachineBinary','EvaluateInteger','TryEvaluateDirectIntegerReturn'","'TryIntegerChain','TryMachineBinary','EvaluateClosedIntegerSequence','EvaluateInteger','TryEvaluateDirectIntegerReturn'")
analyzer=analyzer.replace("'definition setup': ('ApplyDefinition'","'definition setup': ('TryCompleteImmediatelyCalledDefinition','ApplyDefinition'")
analyzer=analyzer.replace("print(x['sampleCount']","print(x['label'],x['sampleCount']")
compile(analyzer,'analyze.py','exec');write(lab/'analyze.py',analyzer)

launcher=(prior/'quiet.py').read_text(encoding='utf-8')
launcher=launcher.replace('retained-rule-factory-cpu-b1577-20261124','private-call-source-cpu-b1601-20261124').replace('lython-b1577-retained-rule-factory-cpu','lython-b1601-private-call-source-cpu')
start=launcher.index('    image=lab.parent/'); end=launcher.index('    archived=io.BytesIO()',start)
launcher=launcher[:start]+'''    python_worker=repo/"benchmarks/cpython-worker.py"
    assert sha(python_worker)==proof["cpythonWorkerSHA256"]
    sdk=Path.home()/".dotnet11"
    dotnet=sdk/"dotnet.exe"
    catalog=lab/"catalog.json"
    for role, expected in proof['imageFiles'].items():
        image=lab.parent/'private-call-isolation-20261124'/role
        assert len(expected)==32 and {p.name:sha(p) for p in image.iterdir()}==expected
        verification=lab/(role+"-verification.json")
        subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--dotnet",dotnet,
            "--python","C:/Python313/python.exe","--python-worker",python_worker,"--catalog",catalog,"--out",verification],
            env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk)),check=True,timeout=65)
        checked=json.loads(verification.read_text(encoding="utf-8"))
        assert checked["state"]=="Completed" and checked["caseCount"]==3 and checked["catalogSha256"]==sha(catalog)
        assert checked["launched"]["library"]["sha256"]==expected["Lokad.Lython.dll"]
        assert {p.name:sha(p) for p in image.iterdir()}==expected
''' + launcher[end:]
launcher=launcher.replace('"verification.json","ops-profile.py"','"reference-verification.json","candidate-verification.json","ops-profile.py"')
launcher=launcher.replace("'verification.json','ops-profile.py'","'reference-verification.json','candidate-verification.json','ops-profile.py'")
launcher=launcher.replace('    staging=f"""','    replicas=json.loads((lab/"verified-raw-replicas.json").read_text(encoding="utf-8"))\n    staging=f"""')
launcher=launcher.replace('assert shutil.disk_usage(root.parent).free >= 11*1024*1024', '''need = 8*1024*1024
 free = shutil.disk_usage(root.parent).free
 verified=[]
 total=free
 digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
 for item in {replicas!r}:
  if total>=need:break
  archived=root.parent/item['location']
  raw=archived/'confirmation/confirmation.json'
  if not raw.is_file():continue
  assert raw.resolve()==raw and raw.is_relative_to(root.parent) and raw.stat().st_nlink==1
  if (archived/'guest-fixtures').exists() or raw.stat().st_size!=item['bytes']:continue
  if not (archived/'observations.tar.xz').is_file() or digest(archived/'observations.tar.xz')!=item['archiveSHA256'] or digest(raw)!=item['rawSHA256']:continue
  verified.append((item,raw))
  total+=raw.stat().st_blocks*512
 assert not root.exists() and total>=need,(total,need)
 for item,raw in verified:raw.unlink()
 assert shutil.disk_usage(root.parent).free>=need
 custody=dict(freeBefore=free,freeAfter=shutil.disk_usage(root.parent).free,verifiedDuplicateRetired=[i for i,r in verified])''')
launcher=launcher.replace('import fcntl,hashlib,io,shutil,subprocess,sys,tarfile','import fcntl,hashlib,io,json,shutil,subprocess,sys,tarfile')
launcher=launcher.replace("  archive.extractall(root,filter='data')", "  archive.extractall(root,filter='data')\n (root/'storage-custody.json').write_text(json.dumps(custody,indent=2))")
launcher=launcher.replace('Staged two generated rule scripts','Staged five profiles').replace('RuntimeMaxSec=125','RuntimeMaxSec=205').replace('seconds=78','seconds=134')
compile(launcher,'quiet.py','exec');write(lab/'quiet.py',launcher)
shutil.copyfile(prior/'run.sh',lab/'run.sh')
shutil.copyfile(donor/'verified-raw-replicas.json',lab/'verified-raw-replicas.json')
assert b'\r' not in (lab/'run.sh').read_bytes()
print('Prepared five serial profiles against both B1599 images.')
