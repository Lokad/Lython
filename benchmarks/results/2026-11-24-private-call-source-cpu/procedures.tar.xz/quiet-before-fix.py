from pathlib import Path
import datetime
import hashlib
import io
import json
import os
import shlex
import subprocess
import sys
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
host="lokad@20.166.121.73"
root="/home/lokad/lython-bench-checks/private-call-source-cpu-b1601-20261124"
unit="lython-b1601-private-call-source-cpu-20261124"
ssh_options=["-i",str(Path.home()/".ssh/id_lython-bench.pem"),"-o","BatchMode=yes","-o","ConnectTimeout=14"]
ssh=["C:/Windows/System32/OpenSSH/ssh.exe",*ssh_options,host]
scp=["C:/Windows/System32/OpenSSH/scp.exe",*ssh_options]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc)

if sys.argv[1]=="launch":
    proof=json.loads((lab/"identity.json").read_text(encoding="utf-8"))
    python_worker=repo/"benchmarks/cpython-worker.py"
    assert sha(python_worker)==proof["cpythonWorkerSHA256"]
    sdk=Path.home()/".dotnet11"
    dotnet=sdk/"dotnet.exe"
    catalog=lab/"catalog.json"
    for role, expected in proof['imageFiles'].items():
        image=lab.parent/'private-call-isolation-20261124'/role
        assert len(expected)==32 and {p.name:sha(p) for p in image.iterdir()}==expected
        verification=lab/(role+"-verification.json")
        subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--dotnet",dotnet,
            "--python","C:/Python313/python.exe","--python-worker",python_worker,"--catalog",catalog,"--out",verification],
            env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk)),check=True,timeout=65)
        checked=json.loads(verification.read_text(encoding="utf-8"))
        assert checked["state"]=="Completed" and checked["caseCount"]==3 and checked["catalogSha256"]==sha(catalog)
        assert checked["launched"]["library"]["sha256"]==expected["Lokad.Lython.dll"]
        assert {p.name:sha(p) for p in image.iterdir()}==expected
    archived=io.BytesIO()
    with tarfile.open(fileobj=archived,mode="w:gz") as target:
        for name in ("catalog.json","identity.json","reference-verification.json","candidate-verification.json","ops-profile.py","collect.py","run.sh"):
            target.add(lab/name,arcname=name,recursive=False)
    assert b"\r" not in (lab/"run.sh").read_bytes()
    data=archived.getvalue()
    (lab/"payload.tgz").write_bytes(data)
    staging=f"""
from pathlib import Path
import fcntl,hashlib,io,json,shutil,subprocess,sys,tarfile
root=Path({root!r})
bundle=sys.stdin.buffer.read()
assert hashlib.sha256(bundle).hexdigest()=={hashlib.sha256(data).hexdigest()!r}
with (root.parent/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 need = 8*1024*1024
 free = shutil.disk_usage(root.parent).free
 verified=[]
 total=free
 digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
 for item in {read(donor/'verified-raw-replicas.json')!r}:
  if total>=need:break
  archived=root.parent/item['location']
  raw=archived/'confirmation/confirmation.json'
  if not raw.is_file():continue
  assert raw.resolve()==raw and raw.is_relative_to(root.parent) and raw.stat().st_nlink==1
  if (archived/'guest-fixtures').exists() or raw.stat().st_size!=item['bytes']:continue
  if not (archived/'observations.tar.xz').is_file() or digest(archived/'observations.tar.xz')!=item['archiveSHA256'] or digest(raw)!=item['rawSHA256']:continue
  verified.append((item,raw))
  total+=raw.stat().st_blocks*512
 assert not root.exists() and total>=need,(total,need)
 for item,raw in verified:raw.unlink()
 assert shutil.disk_usage(root.parent).free>=need
 custody=dict(freeBefore=free,freeAfter=shutil.disk_usage(root.parent).free,verifiedDuplicateRetired=[i for i,r in verified])
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(bundle)) as archive:
  assert set(archive.getnames())=={{'catalog.json','identity.json','reference-verification.json','candidate-verification.json','ops-profile.py','collect.py','run.sh'}}
  archive.extractall(root,filter='data')
 (root/'storage-custody.json').write_text(json.dumps(custody,indent=2))
print('Staged five profiles',root,flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit={unit}','--property=User=lokad','--property=WorkingDirectory='+str(root),
 '--property=RuntimeMaxSec=205','--property=TimeoutStopSec=20','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
"""
    result=subprocess.run(ssh+["python3 -c "+shlex.quote(staging)],input=data,capture_output=True,timeout=30)
    (lab/"launch.log").write_bytes(result.stdout+result.stderr)
    print((result.stdout+result.stderr).decode(),end="")
    result.check_returncode()
    (lab/"observe-not-before").write_text((now()+datetime.timedelta(seconds=134)).isoformat(),encoding="utf-8")
else:
    assert sys.argv[1]=="retrieve"
    assert now()>=datetime.datetime.fromisoformat((lab/"observe-not-before").read_text(encoding="utf-8"))
    state=f"""
from pathlib import Path
import fcntl,json,subprocess
root=Path({root!r})
service=subprocess.run(['systemctl','show','{unit}.service','--property=ActiveState,Result,MainPID,ExecMainStatus'],capture_output=True,text=True).stdout
if 'ActiveState=active' in service:
 print(json.dumps(dict(live=True,service=service)))
else:
 with (root.parent/'comparison-vm.lock').open('a') as lease:
  fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
  read=lambda name: (root/name).read_text().strip() if (root/name).exists() else None
  print(json.dumps(dict(live=False,service=service,exitCode=read('exit-code.txt'),receipt=json.loads(read('archive-receipt.json') or 'null'),
        fixtures=(root/'guest-fixtures').exists(),
        journal=subprocess.run(['journalctl','-u','{unit}.service','-n','32','--no-pager'],capture_output=True,text=True).stdout)))
"""
    fetched=subprocess.check_output(ssh+["python3 -c "+shlex.quote(state)],encoding="utf-8",timeout=25)
    report=json.loads(fetched)
    (lab/("status-"+now().strftime("%H%M%S")+".json")).write_text(fetched,encoding="utf-8")
    print(fetched,end="")
    if not report["live"] and report["receipt"] is not None:
        archive=lab/"observations.tar.xz"
        subprocess.run(scp+[host+":"+root+"/observations.tar.xz",archive],check=True,timeout=35)
        assert sha(archive)==report["receipt"]["archiveSHA256"]
        (lab/"terminal-status.json").write_text(fetched,encoding="utf-8")
        assert report["exitCode"]=="0" and report["receipt"]["complete"] and not report["fixtures"]
