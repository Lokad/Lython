from pathlib import Path
import hashlib,json,shutil,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
donor=lab.with_name('private-call-isolation-20261124')
out=repo/'benchmarks/results/2026-11-24-private-call-source-cpu'
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
sha=lambda data:hashlib.sha256(data).hexdigest()
digest=lambda path:sha(path.read_bytes())
status=read(lab/'terminal-status.json')
assert not status['live'] and not status['fixtures'] and status['exitCode']=='0'
receipt=status['receipt']
assert all(receipt[k] for k in ('complete','quietBeforeAndAfter','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
assert digest(lab/'observations.tar.xz')==receipt['archiveSHA256']
identity=read(lab/'identity.json')
for role,files in identity['imageFiles'].items():
    verification=read(lab/(role+'-verification.json'))
    assert verification['state']=='Completed' and verification['caseCount']==3
    assert verification['catalogSha256']==identity['profileCatalogSHA256']==digest(lab/'catalog.json')
    assert verification['launched']['library']['sha256']==identity['coreSHA256'][role]
    assert len(files)==32 and {p.name:digest(p) for p in (donor/role).iterdir()}==files
catalog=read(lab/'catalog.json')
by_id={row['id']:row for row in catalog['cases']}
rows=read(lab/'attribution.json')['rows']
jit=read(lab/'jit-summary.json')
assert all(jit[role]['core']==identity['coreSHA256'][role] for role in identity['imageFiles'])
with tarfile.open(lab/'observations.tar.xz') as captured:
    for name in ('identity.json','catalog.json','reference-verification.json','candidate-verification.json'):
        assert sha(captured.extractfile(name).read())==digest(lab/name)
    assert [(row['label'],row['case'],row['role']) for row in rows]==[tuple(row) for row in identity['profiles']]
    for row in rows:
        label=row['label']
        case=by_id[row['case']]
        record=json.load(captured.extractfile(f'profiles/{label}/record.json'))
        assert record['exitCode']==0 and record['closed']['status']=='Closed'
        assert record['workload']==row['case'] and record['lane']=='warm' and record['warmupSeconds']>=8
        assert record['role']==row['role'] and record['response']['completedInvocations']==row['invocations']
        assert all(batch['actualOutputSha256']==case['expectedOutputSha256'] for batch in record['batches'])
        assert sum(row['exclusiveNearestRuntimeGroups'].values())==row['guestRuntimeAncestry']
        assert row['sampleCount']>=1000
    custody=captured.extractfile('storage-custody.json').read()
out.mkdir(exist_ok=True)
(out/'storage-custody.json').write_bytes(custody)
for name in ('attribution.json','identity.json','reference-verification.json','candidate-verification.json','terminal-status.json','observations.tar.xz','jit-summary.json'):
    shutil.copyfile(lab/name,out/name)
inputs=('prepare.py','archive.py','analyze.py','quiet.py','quiet-before-fix.py','ops-profile.py','collect.py','run.sh','catalog.json','launch.log',
    'verified-raw-replicas.json','inspect-jit.py','reference-runtime.asm','candidate-runtime.asm',
    'reference-allocation-fullopts.json','candidate-allocation-fullopts.json')
with tarfile.open(out/'procedures.tar.xz','w:xz') as archive:
    for name in inputs:archive.add(lab/name,arcname=name,recursive=False)
with tarfile.open(out/'procedures.tar.xz') as evidence:
    assert len(evidence.getnames())==len(inputs)
    assert all(sha(evidence.extractfile(name).read())==digest(lab/name) for name in inputs)
print('Archived five paired diagnosis profiles and Windows FullOpts evidence.')
