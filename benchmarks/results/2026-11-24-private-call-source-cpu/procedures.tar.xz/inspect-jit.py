from pathlib import Path
import hashlib
import json
import os
import re
import subprocess

lab=Path(__file__).resolve().parent
parent=lab.with_name('private-call-isolation-20261124')
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
meta=read(parent/'comparison/identity.json')
helpers=read(lab.with_name('closed-factory-pairs-entry-20261124')/'comparison/identity.json')['helperFiles']
catalog=parent/'comparison/representative.json'
assert digest(catalog)==meta['catalogs']['representative.json']['sha256']
sdk=Path.home()/'.dotnet11'
methods='StartNativeWorkspace StartInline RunCore ApplyDefinition CreateInlineDefinition CaptureExecutableCells TryCompleteImmediatelyCalledDefinition CallFunction TryStartDirectIntegerReturn'
results={}
for role,files in meta['imageFiles'].items():
    image=parent/'allocation'/role
    expected=files|helpers
    assert {p.name:digest(p) for p in image.iterdir()}==expected
    trace=lab/(role+'-runtime.asm')
    trace.unlink(missing_ok=True)
    observation=lab/(role+'-allocation-fullopts.json')
    env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk), DOTNET_TieredCompilation='0',DOTNET_JitDisasm=methods,DOTNET_JitStdOutFile=str(trace))
    subprocess.run([sdk/'dotnet.exe',image/'ValidatedAllocation.dll',image,catalog,observation],env=env,check=True,timeout=70)
    assert all(r['sharedBudgetBaselineRestored'] for r in read(observation)['rows'])
    sizes={}
    for part in trace.read_text(encoding='utf-8-sig').split('; Assembly listing for method ')[1:]:
        signature,asm=part.split('\n',1)
        if 'Lokad.Lython.Runtime.' not in signature:continue
        name=signature.split('(',1)[0]
        frame=re.search(r'\bsub\s+rsp,\s*(\d+)\b',asm)
        size=re.search(r'Total bytes of code (\d+)',asm)
        sizes[name]={'bytes':int(size[1]),'frameBytes':int(frame[1]) if frame else None}
    results[role]=dict(core=files['Lokad.Lython.dll'],methods=sizes)
for m in sorted(set(results['reference']['methods'])|set(results['candidate']['methods'])):
    print(m,results['reference']['methods'].get(m),results['candidate']['methods'].get(m),flush=True)
(lab/'jit-summary.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8',newline='\n')
