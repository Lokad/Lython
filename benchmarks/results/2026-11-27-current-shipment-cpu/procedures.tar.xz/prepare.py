from hashlib import sha256
from pathlib import Path
import json
import os
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
history=lab.parent
quiet=lab/'comparison/quiet'
quiet.mkdir(parents=True)
donor=history/'current-cpython-checkpoint-20261127/comparison/quiet'
prior=history/'current-json-construction-profile-20261126/comparison/quiet'
older=history/'composed-native-inputs-20261125/comparison/quiet'
def sha(path): return sha256(path.read_bytes()).hexdigest()
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def save(path,value): path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
def manifest(path): return {file.name:sha(file) for file in path.iterdir()}
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head.startswith('777750e6b')
assert not subprocess.check_output(['git','diff','HEAD','--','src','benchmarks/Lokad.Lython.Benchmarks'],cwd=repo)
pin=read(donor/'identity.json')
files=pin['imageFiles']['candidate']
assert len(files)==32 and manifest(donor/'candidate')==files
image=quiet/'candidate'
shutil.copytree(donor/'candidate',image)
core='Lokad.Lython.dll'
shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net11.0'/core,image/core)
current=manifest(image)
assert [name for name,digest in current.items() if digest!=files[name]]==[core]
catalog=read(history/'shared-pending-zip-20261127/local/representative.json')
workloads=['diagnostic.shipment-starmap-wide-lists','diagnostic.shipment-file-fed-map']
catalog['cases']=[case for case in catalog['cases'] if case['id'] in workloads]
assert {case['id'] for case in catalog['cases']}==set(workloads)
catalog_path=quiet/'catalog.json'
save(catalog_path,catalog)
shutil.copyfile(donor/'cpython-worker.py',quiet/'cpython-worker.py')
assert sha(quiet/'cpython-worker.py')==pin['cpythonWorkerSHA256']
donor_name=Path(pin['frozenImage']).parent.name
donor_archive=read(donor/'terminal-status.json')['receipt']['archiveSHA256']
root_name='current-shipment-cpu-b1836-20261127'
remote_root=Path('/home/lokad/lython-bench-checks')/root_name
identity=dict(sourceRevision=head,owner='lython-b1836-current-shipment-cpu-20261127',
              profileCatalogSHA256=sha(catalog_path),donorArchiveSHA256=donor_archive,
              cpythonWorkerSHA256=pin['cpythonWorkerSHA256'],expectedCPythonSHA256=pin['expectedCPythonSHA256'],
              imageFiles={'candidate':current},coreSHA256={'candidate':current[core]},
              comparisonHostRevision=pin['comparisonHostRevision'],profiles=[
                  ['current-wide-shipment-async',workloads[0],'candidate'],
                  ['current-file-fed-map-async',workloads[1],'candidate']],
              purpose='Attribute on-CPU work in current wide async shipment and file-fed map under existing comparison boundaries.')
save(quiet/'identity.json',identity)
collect=(prior/'collect.py').read_text(encoding='utf-8')
collect=collect.replace('    assert digest(root.parent/"native-segments-at-emission-b1800-20261126"/\'observations.tar.xz\') == json.loads((root/\'identity.json\').read_text())[\'donorArchiveSHA256\']',
                        f'    assert digest(root.parent/"{donor_name}"/"observations.tar.xz") == identity["donorArchiveSHA256"]')
collect=collect.replace('root.parent / "native-segments-at-emission-b1800-20261126/candidate"', 'root / "candidate"')
collect=collect.replace('6*1024*1024-256*1024','6*1024*1024').replace('b1801-fixtures','b1836-fixtures')
collect=collect.replace('if p.is_file() and p != archive','if p.is_file() and p != archive and not p.is_relative_to(image)')
assert 'b1801' not in collect and 'native-segments' not in collect
compile(collect,'collect.py','exec')
(quiet/'collect.py').write_text(collect,encoding='utf-8',newline='\n')
for name in ('ops-profile.py','run.sh','analyze.py'):
    shutil.copyfile(prior/name,quiet/name)
assert b'\r' not in (quiet/'run.sh').read_bytes()
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
result=quiet/'candidate-verify.json'
subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',catalog_path,'--dotnet',dotnet,
    '--python','C:/Python313/python.exe','--python-worker',quiet/'cpython-worker.py','--out',result],
    cwd=repo,env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk)),check=True,timeout=65)
verified=read(result)
assert verified['state']=='Completed' and verified['caseCount']==2
assert verified['catalogSha256']==identity['profileCatalogSHA256']
assert verified['launched']['library']['sha256']==current[core]
assert verified['launched']['adapter']['sha256']==current['Lokad.Lython.Benchmarks.dll']
items=['identity.json','catalog.json','cpython-worker.py','run.sh','collect.py','ops-profile.py',f'candidate/{core}']
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz') as tar:
    for name in items: tar.add(quiet/name,arcname=name)
staged={name:dict(length=(quiet/name).stat().st_size,sha256=sha(quiet/name)) for name in items}
old=read(older/'identity.json')
aux=['Microsoft.CodeAnalysis.CSharp.dll','Microsoft.CodeAnalysis.dll','Microsoft.Diagnostics.Tracing.TraceEvent.dll']
assert all(old['imageFiles']['reference'][name]==files[name] for name in aux)
save(quiet/'upload.json',dict(root=root_name,donor=donor_name,donorFiles=files,donorArchive=donor_archive,
    payloadSHA256=sha(payload),files=staged,expandedBytes=sum(item['length'] for item in staged.values()),
    minimumAfterStageBytes=6*1024*1024,
    duplicate={'root':'composed-native-inputs-b1742-20261125','unit':'lython-b1742-composed-inputs-20261125',
               'archiveSHA256':read(older/'terminal-status.json')['receipt']['archiveSHA256'],
               'role':'reference','manifest':old['imageFiles']['reference'],'files':aux}))
print('Verified profile payload',sum(item['length'] for item in staged.values()))
