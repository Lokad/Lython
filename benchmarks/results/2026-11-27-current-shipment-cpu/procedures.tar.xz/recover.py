from pathlib import Path
import json
import shutil
import subprocess

lab=Path(__file__).resolve().parent
quiet=lab/'comparison/quiet'
configuration=json.loads((quiet/'upload.json').read_text(encoding='utf-8'))
shutil.copyfile(quiet/'terminal-status.json',quiet/'failed-before-recovery.json')
code='cfg='+repr(configuration)+r'''
from pathlib import Path
from hashlib import sha256
import fcntl,json,os,shutil,stat,subprocess
base=Path.home()/'lython-bench-checks'
root=base/cfg['root']
unit='lython-b1836-current-shipment-cpu-20261127'
retry=unit+'-retry'
def sha(path):return sha256(path.read_bytes()).hexdigest()
def snapshot(folder):
 return {path.relative_to(folder).as_posix():sha(path) for path in folder.rglob('*') if path.is_file()}
def service(name):
 return subprocess.check_output(['systemctl','show',name+'.service','--property=ActiveState,MainPID'],text=True)
assert root.resolve()==root and root.parent==base and base.resolve()==base
with (base/'comparison-vm.lock').open('r') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert 'ActiveState=failed' in service(unit) and 'MainPID=0' in service(unit)
 assert (root/'exit-code.txt').read_text().strip()=='1'
 assert not (root/'guest-fixtures').exists() and not (root/'profiles').exists()
 assert not (root/'archive-receipt.json').exists()
 observed=json.loads((root/'identity.json').read_text())['imageFiles']['candidate']
 assert snapshot(root/'candidate')==observed
 for path,wanted in cfg['files'].items(): assert sha(root/path)==wanted['sha256']
 old=cfg['duplicate']
 previous=base/old['root']
 assert previous.resolve()==previous and previous.parent==base and not (previous/'guest-fixtures').exists()
 prior_service=service(old['unit'])
 assert 'ActiveState=inactive' in prior_service and 'MainPID=0' in prior_service
 archive=previous/'observations.tar.xz'
 assert sha(archive)==old['archiveSHA256']
 receipt=json.loads((previous/'archive-receipt.json').read_text())
 assert receipt['archiveSHA256']==old['archiveSHA256']
 assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved'))
 frozen=previous/'candidate'
 prior=json.loads((previous/'identity.json').read_text())['imageFiles']['candidate']
 present=snapshot(frozen)
 assert present=={name:digest for name,digest in prior.items() if name!='Lokad.Lython.dll'}
 prepared=[]
 for name in old['files']:
  source=root/'candidate'/name
  destination=frozen/name
  assert source.resolve()==source and destination.resolve()==destination
  assert sha(source)==prior[name]==present[name] and not source.samefile(destination)
  file=destination.lstat()
  assert file.st_uid==os.getuid() and stat.S_ISREG(file.st_mode) and file.st_nlink==1
  prepared.append(dict(source=str(source),destination=str(destination),bytesRecovered=file.st_blocks*512,
                       sha256=present[name]))
 free=shutil.disk_usage(base).free
 assert free+sum(item['bytesRecovered'] for item in prepared)>=13*1024*1024
 for item in prepared:
  source,destination=Path(item['source']),Path(item['destination'])
  temporary=destination.with_name('.b1836-recovery-identical')
  assert temporary.resolve()==temporary and not temporary.exists()
  os.link(source,temporary)
  try: os.replace(temporary,destination)
  finally: temporary.unlink(missing_ok=True)
  assert source.samefile(destination)
 assert snapshot(frozen)==present and sha(archive)==old['archiveSHA256']
 after=shutil.disk_usage(base).free
 assert after>=13*1024*1024
 recovery=dict(before=free,after=after,additionalDuplicates=prepared,oldCandidateWasMissingCore=True,
     preflight='The first service exited at its disk floor before creating fixtures or profiles.')
 notes=root/'recovery.json'
 notes.write_text(json.dumps(recovery,indent=2)+'\n')
 (root/'exit-code.txt').rename(root/'original-exit-code.txt')
 print(json.dumps(recovery),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit='+retry,'--property=User=lokad',
 '--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=125','--property=TimeoutStopSec=20',
 '--property=KillMode=control-group','--property=StandardOutput=append:'+str(root/'service.log'),
 '--property=StandardError=inherit','/bin/sh',str(root/'run.sh')],check=True)
'''
compile(code,'<resume verified CPU profile>','exec')
common=['-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes','-o','IdentitiesOnly=yes','-o','ConnectTimeout=12']
result=subprocess.run(['ssh',*common,'lokad@20.166.121.73','python3 -'],input=code,encoding='utf-8',timeout=60,check=True,capture_output=True)
(quiet/'recovery-launch.log').write_text(result.stdout,encoding='utf-8',newline='\n')
print(result.stdout)
