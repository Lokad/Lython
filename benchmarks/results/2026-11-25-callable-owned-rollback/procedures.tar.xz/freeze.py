from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import zipfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.with_name("executable-lambda-headers-20261125")
catalog_donor = lab.with_name("closed-default-store-links-20261125")
quiet = lab / "comparison/quiet"
quiet.mkdir(parents=True, exist_ok=True)
read = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(["git", *args], cwd=repo)

def write(path, text):
    path.write_text(text, encoding="utf-8", newline="\n")

def save(path, data):
    write(path, json.dumps(data, indent=2) + "\n")

base = git("rev-parse", "60a293724").decode().strip()
assert git("rev-parse", "HEAD").decode().strip() == base
paths = git("diff", "--name-only", "--", "src").decode().splitlines()
assert len(paths) == 2 and all(path.startswith("src/Lokad.Lython/Runtime/") for path in paths), paths
patch = lab / "candidate.patch"
patch.write_bytes(git("diff", "--binary", "--", "src"))
build_inputs = ("global.json", "Directory.Build.props", "Directory.Build.targets",
                "Directory.Build.rsp", "Directory.Packages.props", "NuGet.Config")
root_files = set(git("ls-tree", "--name-only", base).decode().splitlines())
archive = lab / "base.zip"
git("archive", "--format=zip", f"--output={archive}", base, "--",
    *[name for name in build_inputs if name in root_files], "src/Lokad.Lython")
old_identity = read(donor / "comparison/quiet/identity.json")
old_files = old_identity["imageFiles"]["candidate"]
assert {file.name: sha(file) for file in (donor / "candidate").iterdir()} == old_files

sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
images = {}
assert git("diff", "--binary", old_identity["sourceRevision"], base, "--", "src") == (donor/"candidate.patch").read_bytes()
reference = lab / "reference"
reference.mkdir(exist_ok=True)
for name, expected in old_files.items():
    shutil.copyfile(donor / "candidate" / name, reference / name)
    assert sha(reference / name) == expected
images["reference"] = old_files
for role in ("candidate",):
    frozen = lab / ("frozen-" + role)
    with zipfile.ZipFile(archive) as bundle:
        bundle.extractall(frozen)
        if role == "candidate":
            for path in paths:
                shutil.copyfile(repo / path, frozen / path)
        for name in bundle.namelist():
            if name.endswith("/"):
                continue
            expected = (repo / name).read_bytes() if role == "candidate" and name in paths else bundle.read(name)
            assert (frozen / name).read_bytes() == expected, name
    build = lab / (role + "-build")
    with (lab / (role + "-build.log")).open("wb") as log:
        subprocess.run([dotnet, "build", "src/Lokad.Lython/Lokad.Lython.csproj", "-c", "Release", "-f", "net11.0",
                        "--no-incremental", "--artifacts-path", build], cwd=frozen, env=env, stdout=log,
                       stderr=subprocess.STDOUT, check=True, timeout=180)
    core = build / "bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll"
    image = lab / role
    image.mkdir(exist_ok=True)
    for name in old_files:
        shutil.copyfile(core if name == core.name else donor / "candidate" / name, image / name)
    images[role] = old_files | {core.name: sha(core)}
    assert {file.name: sha(file) for file in image.iterdir()} == images[role]
assert git("diff", "--binary", "--", "src") == patch.read_bytes()
assert images["reference"] != images["candidate"]

jobs = [('scripts.rule-default-closures', 'warm'), ('scripts.rule-default-closures', 'compile-run'), ('scripts.annotated-rule-closures', 'warm'), ('scripts.annotated-rule-closures', 'compile-run'), ('scripts.annotated-rule-closures.nested-factories.postponed', 'warm'), ('scripts.annotated-rule-closures.nested-factories.postponed', 'compile-run'), ('diagnostic.generated-ordinary-definitions', 'compile'), ('diagnostic.shipment-routing-callbacks', 'warm-async')]
catalog = read(catalog_donor / "input-catalog.json")
catalog["cases"] = [case for case in catalog["cases"] if case["id"] in {name for name, _ in jobs}]
assert len(catalog["cases"]) == 5
catalog_path = quiet / "representative.json"
save(catalog_path, catalog)
save(quiet / "jobs.json", {"warm": jobs})
identity = dict(sourceRevision=base, comparisonRevision=base, sourcePatchSHA256=sha(patch), imageFiles=images,
                coreSHA256={role + suffix: files["Lokad.Lython.dll"] for role, files in images.items()
                            for suffix in ("", "-control")},
                expectedCPythonSHA256=old_identity["expectedCPythonSHA256"],
                cpythonWorkerSHA256=old_identity["cpythonWorkerSHA256"],
                catalogs={name: {"sha256": sha(quiet / name)} for name in ("representative.json", "jobs.json")},
                purpose="Transfer rollback of completed private definitions to their callable owner")
save(quiet / "identity.json", identity)
python_worker = repo / "benchmarks/cpython-worker.py"
assert sha(python_worker) == identity["cpythonWorkerSHA256"]
for role, files in images.items():
    evidence = lab / "comparison" / (role + "-verify.json")
    subprocess.run([dotnet, lab / role / "Lokad.Lython.Benchmarks.dll", "--compare", "verify",
                    "--catalog", catalog_path, "--dotnet", dotnet, "--python", "C:/Python313/python.exe",
                    "--python-worker", python_worker, "--out", evidence],
                   cwd=repo, env=env, check=True, timeout=65)
    report = read(evidence)
    assert report["state"] == "Completed" and report["caseCount"] == 5
    assert report["launched"]["library"]["sha256"] == files["Lokad.Lython.dll"]
