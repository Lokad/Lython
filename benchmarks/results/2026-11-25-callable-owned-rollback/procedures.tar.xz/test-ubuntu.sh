set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab="$PWD/.git/agent-notes/review-20261031/callable-owned-rollback-20261125"
filter='(FullyQualifiedName~Definition|FullyQualifiedName~Default|FullyQualifiedName~Annotation|FullyQualifiedName~Closure|FullyQualifiedName~Cancellation|FullyQualifiedName~Ownership|FullyQualifiedName~Admission)&Category!=Stress'
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
  log="$lab/$suite-ubuntu10.log"
  if dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$log" 2>&1; then
    tail -4 "$log"
  else
    tail -55 "$log"
    exit 1
  fi
done
