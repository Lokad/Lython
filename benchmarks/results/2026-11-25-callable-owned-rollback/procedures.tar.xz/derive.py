from pathlib import Path
import json
import shutil

lab = Path(__file__).resolve().parent
old = lab.with_name("executable-lambda-headers-20261125")
prior = lab.with_name("closed-default-store-links-20261125")
jobs = [
    ("scripts.rule-default-closures", "warm"),
    ("scripts.rule-default-closures", "compile-run"),
    ("scripts.annotated-rule-closures", "warm"),
    ("scripts.annotated-rule-closures", "compile-run"),
    ("scripts.annotated-rule-closures.nested-factories.postponed", "warm"),
    ("scripts.annotated-rule-closures.nested-factories.postponed", "compile-run"),
    ("diagnostic.generated-ordinary-definitions", "compile"),
    ("diagnostic.shipment-routing-callbacks", "warm-async"),
]

def edit(source, name, changes):
    text = source.read_text(encoding="utf-8")
    for before, after in changes:
        assert before in text, before
        text = text.replace(before, after)
    compile(text, name, "exec")
    (lab / name).write_text(text, encoding="utf-8", newline="\n")

freeze = old / "freeze.py"
raw = freeze.read_text(encoding="utf-8")
a = raw.index("jobs = [")
b = raw.index("catalog = ", a)
loop = raw.index('for role in ("reference", "candidate"):')
end = raw.index('assert git("diff", "--binary", "--", "src") == patch.read_bytes()', loop)
core_build = raw[loop:end]
replacement = '''assert git("diff", "--binary", old_identity["sourceRevision"], base, "--", "src") == (donor/"candidate.patch").read_bytes()
reference = lab / "reference"
reference.mkdir(exist_ok=True)
for name, expected in old_files.items():
    shutil.copyfile(donor / "candidate" / name, reference / name)
    assert sha(reference / name) == expected
images["reference"] = old_files
''' + core_build.replace('for role in ("reference", "candidate"):', 'for role in ("candidate",):')
edit(freeze, "freeze.py", [
    ('"borrowed-builtin-bindings-20261125"', '"executable-lambda-headers-20261125"'),
    ('"0a8952725"', '"60a293724"'),
    ('assert len(paths) == 6 and all(path.startswith("src/Lokad.Lython/Frontend/") for path in paths), paths',
     'assert len(paths) == 2 and all(path.startswith("src/Lokad.Lython/Runtime/") for path in paths), paths'),
    (core_build, replacement),
    (raw[a:b], "jobs = " + repr(jobs) + "\n"),
    ('assert len(catalog["cases"]) == 4', 'assert len(catalog["cases"]) == 5'),
    ('report["caseCount"] == 4', 'report["caseCount"] == 5'),
    ('Skip unused lowered lambda headers and prepare one executable body',
     'Transfer rollback of completed private definitions to their callable owner'),
])

edit(old / "prepare.py", "prepare.py", [
    ('"borrowed-builtin-bindings-20261125"', '"executable-lambda-headers-20261125"'),
    ('verified["caseCount"] == 4', 'verified["caseCount"] == 5'),
    ('.replace("len(jobs) == 8", "len(jobs) == 6")', ''),
    ('"started < 315"', '"started < 367"'),
    ('"lython-b1715-borrowed-builtin-bindings", "lython-b1716-executable-lambda-headers"',
     '"lython-b1716-executable-lambda-headers", "lython-b1717-callable-owned-rollback"'),
    ('launcher.replace("b1715", "b1716").replace("if name==\'Lokad.Lython.dll\' and role==\'candidate\':", "if name==\'Lokad.Lython.dll\':")',
     'launcher.replace("b1716", "b1717").replace("if name==\'Lokad.Lython.dll\':", "if name==\'Lokad.Lython.dll\' and role==\'candidate\':")'),
    ('''launcher.replace("'candidate-core.dll'}", "'candidate-core.dll','reference-core.dll'}")''',
     '''launcher.replace("'candidate-core.dll','reference-core.dll'}", "'candidate-core.dll'}")'''),
    ('"RuntimeMaxSec=382", "RuntimeMaxSec=332"', '"RuntimeMaxSec=332", "RuntimeMaxSec=392"'),
    ('"seconds=300", "seconds=240"', '"seconds=240", "seconds=310"'),
    ('"b1711-fixtures", "b1716-fixtures"', '"b1711-fixtures", "b1717-fixtures"'),
    ('    for role in identity["imageFiles"]:\n        out.add(lab / role / "Lokad.Lython.dll", arcname=role + "-core.dll")',
     '    out.add(lab / "candidate/Lokad.Lython.dll", arcname="candidate-core.dll")'),
    ('root="executable-lambda-headers-b1716-20261125"', 'root="callable-owned-rollback-b1717-20261125"'),
    ('reference="borrowed-builtin-bindings-b1715-20261125"', 'reference="executable-lambda-headers-b1716-20261125"'),
])

edit(old / "package.py", "package.py", [
    ('2026-11-25-executable-lambda-headers', '2026-11-25-callable-owned-rollback'),
    ('\n).replace(\'==receipt["warmJobs"]==8\', \'==receipt["warmJobs"]==6\').replace(\n    "timedBatches=224,lanes=8", "timedBatches=168,lanes=6"\n)', '\n)'),
    ('"freeze.py", "prepare.py"', '"derive.py", "freeze.py", "prepare.py"'),
    ('"probe-build.log", "lambda-headers.py"', '"probe-build.log", "wide-defaults.py"'),
    ('"candidate.patch", "reference-build.log", "candidate-build.log", "launch-console.log",',
     '"candidate.patch", "candidate-build.log", "launch-console.log", "retrieve.log",'),
])
shutil.copyfile(prior / "wide-defaults.py", lab / "wide-defaults.py")
