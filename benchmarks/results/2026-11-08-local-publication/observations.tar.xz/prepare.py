from pathlib import Path
import copy,hashlib,json,os,shutil
r=Path(__file__).parent;old=r.parent/'json-record-capacity-r110/refinement'
i=json.loads((old/'identity.json').read_text(encoding='utf8'));assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in i['productionSources'].items())
baseline=dict(sourceRevision='05790317',coreSHA256=i['coreSHA256']['candidate'],productionSources=i['productionSources'],qualification='Cached full CI42502610937: Windows/Ubuntu actual11/10/originalStress/installed core; HEAD7bd69241 changes evidence only.')
(r/'baseline.json').write_text(json.dumps(baseline,indent=2)+'\n',encoding='utf8');shutil.copyfile('PLAN.md',r/'pre-implementation-plan.md')
images=r/'images';images.mkdir()
for role in ['before','candidate']:shutil.copytree(old/'images/candidate',images/role,copy_function=os.link)
catalog=json.loads((r.parent/'json-cpython-r103/representative.json').read_text(encoding='utf8'))
loop=copy.deepcopy(json.loads((r.parent/'scalar-cost-r111/catalog.json').read_text(encoding='utf8'))['cases'][0])
fixture=json.loads(loop['fixtureJson']);fixture.update(inputFiles={},outputFiles={})
loop['fixtureJson']=json.dumps(fixture,separators=(',',':'));loop['fixtureSha256']=hashlib.sha256(loop['fixtureJson'].encode()).hexdigest();loop['expectedFilesSha256']=hashlib.sha256(bytes(4)).hexdigest()
# The existing private driver expects file-capable fixtures. Empty maps use
# the existing host/protocol, add no guest I/O, and are identical in both images.
cases=[loop,*[next(c for c in catalog['cases']if c['id']==id)for id in ['scripts.csv-summary-functions.large','scripts.text-summary-helpers.large','scripts.json-summary-helpers.large','scripts.report-render.large']]]
(r/'catalog.json').write_text(json.dumps({**catalog,'cases':cases},ensure_ascii=False,indent=2)+'\n',encoding='utf8')
proposal='''R112 source gate passes. StoreLocalValue's compiler-name lookup and '<' classification are pure reads of immutable valid slot metadata. They affect only GlobalNamespace routing and variable mirroring; cells use their own stored names. Move the lookup/classification into those actual branches. Preserve global-before-local ordering, slot/cell writes before mirroring, mutable MirrorLocalStores/GlobalNamespace behavior and hidden synthetic names. No new flags/cache/owner/dispatch/representation or public API; retain cleanup/retirement/current-token/refusal/preflight/stack checks and both existing NoInlining lifetime fences. Source acceptance: private slot publication performs no LocalNames lookup/classification; visible namespace branches retain original names/behavior.
R111 source0579 profile1170samples: CompleteLocalResult287leaf24.53%; that includes useful work, not predicted savings. Existing integer-loop/representative CSV/text/JSON/report scripts, five-case normal allocation diagnostic bothAPIs, one same-settings six-job controlled before/after with loop bothAPIs plus representative sync controls. Loop uses empty file maps for the existing driver/host, adds no guestI/O and differs only in fixture metadata from R111's no-file micro; no cross-boundary timing comparison or CPython refresh. Existing focused Release namespace/binding/closure/generator/lifetime/cancellation/ownership checks peractual11/10; no tests mirroring the metadata relocation. Retain/correct/reject with explicit debt, bounded confirmation allowed for actual uncertainty. Full exact-source delivery only at a coherent retained boundary, previous source already qualified. Publication/regex unchanged.
'''
(r/'proposal.md').write_text(proposal,encoding='utf8')
print('R112 baseline/catalog frozen; immutable-name source gate and semantic/measurement acceptance recorded.')
