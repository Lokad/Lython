from pathlib import Path
import ast,hashlib,json,shutil,tarfile
r=Path(__file__).parent;old=r.parent/'json-record-capacity-r110/b468';b=r/'b472';b.mkdir()
sour=json.loads((r/'identity.json').read_text(encoding='utf8'));prior=json.loads((old/'identity.json').read_text(encoding='utf8'))
jobs=[['loops.integer.large','warm'],['loops.integer.large','warm-async'],['scripts.csv-summary-functions.large','warm'],['scripts.text-summary-helpers.large','warm'],['scripts.json-summary-helpers.large','warm'],['scripts.report-render.large','warm']]
identity={**prior,'sourceRevision':sour['candidateSource'],'baselineSource':sour['baselineSource'],'coreSHA256':{role:sour['coreSHA256']['before'if role.startswith('reference')else'candidate']for role in ['reference','reference-control','candidate','candidate-control']},'productionSources':sour['productionSources'],'qualification':sour['qualification'],'jobs':jobs}
(b/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf8')
for n in ['collect.py','run.sh','retrieve.py','assess-vm.py','archive-owned.py','launch.py']:
 s=(old/n).read_text(encoding='utf8').replace('json-record-capacity-b468-20261108','local-publication-b472-20261108').replace('lython-b468-json-record-capacity','lython-b472-local-publication').replace('json-record-capacity-b468-launch.py','local-publication-b472-launch.py').replace('lython-b468-fixtures','lython-b472-fixtures')
 if n=='collect.py':
  a=s.index('jobs=');z=s.index('\nassert len(jobs)',a);s=s[:a]+'jobs='+repr(jobs)+s[z:]
  a=s.index("purpose='");z=s.index("',\n",a);s=s[:a]+"purpose='R112 defer immutable local-name lookup to actual namespace branches; existing integer loop bothAPIs and representative CSV/text/JSON/report"+s[z:]
 if n=='launch.py':s=s.replace("reference=base/'refined-conditional-helpers-b465-20261108/candidate'","reference=base/'refined-record-capacity-b469-20261108/candidate'").replace('(240+7)','(240+12)').replace('evidenceHeadroomMiB=7','evidenceHeadroomMiB=12')
 if n=='archive-owned.py':
  s=s.replace(",'baseline-core.dll'",'').replace("'baseline-core.dll',",'').replace("'current-core.dll']","'current-core.dll','baseline-source.json','sizing.json']")
 (b/n).write_text(s,encoding='utf8',newline='\n')
 if n.endswith('.py'):ast.parse(s)
for src,name in [(r/'images/candidate/Lokad.Lython.dll','current-core.dll'),(r/'catalog.json','representative.json'),(r/'identity.json','focused.json'),(r/'source.patch','source.patch'),(r/'pre-measurement-plan.md','pre-measurement-plan.md')]:shutil.copyfile(src,b/name)
priorVm=r.parent/'json-record-capacity-r110/refinement/b469';receipt=json.loads((priorVm/'archive-receipt.json').read_text(encoding='utf8'))
assert hashlib.sha256((priorVm/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
proof=dict(vmArchive='refined-record-capacity-b469-20261108/observations.tgz',archiveSHA256=receipt['archiveSHA256'],member='current-core.dll',coreSHA256=sour['coreSHA256']['before'],immutableLocalArtifact='benchmarks/results/2026-11-08-json-record-capacity/observations.tar.xz (nested B469)')
(b/'baseline-source.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf8')
dynamic=sum((p.stat().st_size+4095)//4096*4096 for p in(priorVm/'retrieved/confirmation').rglob('*')if p.is_file());estimate=(dynamic+(priorVm/'observations.tgz').stat().st_size)*1.5;assert estimate<12*1024*1024
(b/'sizing.json').write_text(json.dumps(dict(priorRoundedDynamicBytes=dynamic,priorFullArchiveBytes=(priorVm/'observations.tgz').stat().st_size,estimateWith50PercentHeadroom=estimate,evidenceHeadroomBytes=12*1024*1024,osFloorBytes=240*1024*1024,baselineArchiveReused=True,noEvidenceDeleted=True),indent=2)+'\n',encoding='utf8')
(b/'setup-contract.json').write_text(json.dumps(dict(jobs=jobs,ownerSeconds=210,stopSeconds=30,marginSeconds=30,evidenceHeadroomMiB=12,osFloorMiB=240),indent=2)+'\n',encoding='utf8')
contract='''R112 one bounded source pair1310/761c exact hashes identity. Defer pure compiler-name lookup/classification to actual namespace/mirroring branches, same canonical writer; slot/cell/mirror/global/synthetic behavior and both NoInlining fences/cleanup/checks retained.446public/132internal Release peractual11/10 pass. Existing five-script integer loop+CSV/text/JSON/report, same source/outputs, loop empty file maps add no guestI/O; no comparison with no-file R111 clocks. Loop both APIs and four representative sync jobs. No claimed24.5% savings, allocation/CPU/architecture distinct. No new flags/cache/owner/representation/dispatch/framework/API or CPython refresh.
Same frozenworker7cf/host/normaloptional0.4/normalGC/tiering, two processes/core,5swarmup/role/job,7rotated150msrounds.210sowner+30stop+30margin. Complete invocation/mediated RAM I/O/fullstdout/filevalidation/priorresultcleanup included; compilation/startup/staging/finalcacheteardown excluded. All Ready/source/core/aux/golden/quiet/Closed/exit/join/unmount/archive/local gates. Persistent raw, owned128MiB RAM guestfixtures.240MiBOSfloor+12MiBevidence+actualpayload preflight: completed prior dynamic+fullarchive plus50% fits12MiB; new archive reuses already-preserved baseline binary via SHA-proven source receipt, no repeated baseline payload. All old paths/bytes/archives retained. Full source0579 already qualified cachedCI42502610937; new-source full delivery independent at retained boundary. Publication/regex unchanged.\n'''
(b/'contract.md').write_text(contract,encoding='utf8')
with tarfile.open(b/'payload.tgz','w:gz')as a:
 for n in ['collect.py','run.sh','current-core.dll','representative.json','identity.json','pre-measurement-plan.md','setup-contract.json','contract.md','focused.json','source.patch','archive-owned.py','baseline-source.json','sizing.json']:a.add(b/n,arcname=n)
print('B472 six-job source pair prepared; baseline archive reused,12MiB evidence allowance sized from actual completed raw data.')
