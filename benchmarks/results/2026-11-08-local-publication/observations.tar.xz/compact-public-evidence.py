from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-08-local-publication')
p=out/'observations.tar.xz';shutil.copyfile(p,r/'initial-full-evidence.tar.xz')
(r/'archive-sizing.json').write_text(json.dumps(dict(originalSHA256=hashlib.sha256(p.read_bytes()).hexdigest(),originalBytes=p.stat().st_size,change='Before commit: omit duplicate unchanged auxiliary image files from public archive; full original private archive and both core binaries retained; exact auxiliary identities in nested VM identity.json.'),indent=2)+'\n',encoding='utf8')
with tarfile.open(p,'w:xz') as t:
    for q in sorted(r.iterdir()):
        if q.name=='images':
            for role in ['before','candidate']:t.add(q/role/'Lokad.Lython.dll',arcname='images/'+role+'/Lokad.Lython.dll')
        elif q.name=='b472':
            for x in sorted(q.iterdir()):
                if x.name not in ['retrieved','payload.tgz']:t.add(x,arcname='b472/'+x.name)
        elif q.name!='initial-full-evidence.tar.xz':t.add(q,arcname=q.name)
with tarfile.open(p) as t:
    receipt=json.loads((r/'b472/archive-receipt.json').read_text(encoding='utf8'))
    assert hashlib.sha256(t.extractfile('b472/observations.tgz').read()).hexdigest()==receipt['archiveSHA256']
print('Public evidence',p.stat().st_size,'bytes; unchanged duplicate auxiliary binaries omitted, original archive private/preserved.')
