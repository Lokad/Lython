from pathlib import Path
import os,subprocess
r=Path(__file__).parent;env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+env['PATH']
public='(FullyQualifiedName~DeclarationNamespaceTests|FullyQualifiedName~FunctionNamespaceLifetimeTests|FullyQualifiedName~Globals|FullyQualifiedName~Closure|FullyQualifiedName~GeneratorSemantics|FullyQualifiedName~GeneratorCleanupComposition|FullyQualifiedName~AsyncFunctionHostingTests|FullyQualifiedName~ExecutableLocalImportTests|FullyQualifiedName~AnnotationOnlyLocalTests|FullyQualifiedName~RepresentativeScriptTests|FullyQualifiedName~Comprehension)&Category!=Stress'
internal='(FullyQualifiedName~ExecutionFrameNamespaceTests|FullyQualifiedName~LiveGlobalNamespaceHostTests|FullyQualifiedName~NamespaceAdmissionTests|FullyQualifiedName~OwnedFunctionLocalsTests|FullyQualifiedName~OrdinaryFunctionTransportTests|FullyQualifiedName~SimpleFunctionExecutionBoundaryTests|FullyQualifiedName~LocalAugmentedLifetimeTests|FullyQualifiedName~FunctionBodyTemporaryLifetimeTests|FullyQualifiedName~FunctionWorkspaceOwnershipTests|FullyQualifiedName~FunctionClassCellBoundaryTests|FullyQualifiedName~AnnotationOnlyLocalBoundaryTests|FullyQualifiedName~ClosureRetentionAccountingTests)&Category!=Stress'
for name,project,framework,filter in [
 ('public11','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','net11.0',public),
 ('public10','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','net10.0',public),
 ('internal11','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','net11.0',internal),
 ('internal10','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','net10.0',internal)]:
 with(r/(name+'.log')).open('w',encoding='utf8')as log:done=subprocess.run([env['DOTNET_HOST_PATH'],'test',project,'-c','Release','-f',framework,'--filter',filter],env=env,stdout=log,stderr=subprocess.STDOUT)
 text=(r/(name+'.log')).read_text(encoding='utf8')
 if done.returncode:print(text[-10000:],flush=True);raise SystemExit(done.returncode)
 print(name,text.strip().splitlines()[-1],flush=True)
