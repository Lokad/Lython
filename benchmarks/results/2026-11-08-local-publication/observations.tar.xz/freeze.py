from pathlib import Path
import hashlib,json,re,shutil,subprocess
r=Path(__file__).parent;b=json.loads((r/'baseline.json').read_text(encoding='utf8'))
sources={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in b['productionSources']};assert {p for p,h in sources.items()if h!=b['productionSources'][p]}=={'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.cs'}
counts={}
for n in ['public11','public10','internal11','internal10']:
 s=(r/(n+'.log')).read_text(encoding='utf8');m=re.search(r'Passed!.*Failed:\s+0, Passed:\s+(\d+),',s);assert m;counts[n]=int(m[1])
paths=[Path(p)/'Lokad.Lython.dll'for p in ['src/Lokad.Lython/bin/Release/net11.0','tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0','tests/Lokad.Lython.Tests/bin/Release/net11.0']];assert len({hashlib.sha256(p.read_bytes()).hexdigest()for p in paths})==1
p=r/'images/candidate/Lokad.Lython.dll';p.unlink();shutil.copyfile(paths[0],p)
i=dict(baselineSource='Fully qualified05790317/core13107e6b, cached CI42502610937',candidateSource='7bd69241 plus deferred immutable local-name lookup in canonical slot publication',coreSHA256={role:hashlib.sha256((r/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']},productionSources=sources,focusedChecks=counts,qualification='446public/132internal focused Release peractual11/10 pass; exact new-source full delivery independent/pending.',controls='Same frozen worker7cf/host/optional0.4 and normalGC/tiering; five maintained scripts: integer-loop(emptyfilemaps), CSV/text/JSON/report. No new frontend or CPython comparison.')
(r/'identity.json').write_text(json.dumps(i,indent=2)+'\n',encoding='utf8');(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.cs']));shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
old=r.parent/'native-json-construction-r105'
for n in ['measure.py','assess-local.py']:
 s=(old/n).read_text(encoding='utf8')
 if n=='assess-local.py':
  a=s.index("out['limitations']=");z=s.index("\n(r/'assessment-local",a);s=s[:a]+"out['limitations']='R112 existing same-process ALC diagnostic, normal GC/tiering; Run-only clocks, allocations include host reset/full validation/prior-result cleanup. Both images use identical empty file maps for the maintained integer loop (no guest I/O), four unchanged file-script fixtures. Desktop elapsed is not controlled CPU evidence; no frontend/CPython source comparison claim.'"+s[z:]
 (r/n).write_text(s,encoding='utf8')
print('R112 frozen',i['coreSHA256'],counts,flush=True)
