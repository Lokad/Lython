# Lokad.Lython 0.11.0

Updated 2026-11-08. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Current contracts belong in docs. Historical designs, failures and adverse data
remain in [EXPERIMENTS](benchmarks/EXPERIMENTS.md) and linked immutable evidence.

## Actual delivery status

- **Committed/pushed, fully qualified production05790317/core13107e6b.** Cached
  CI42502610937: Windows/Ubuntu actual .NET11/.NET10 full Release, original Stress
  both and installed core consumers. Later commits contain evidence/docs only.
  Shared compiler-fact correction, direct UTF-8 formatting/storage, original native
  returns and retained R62–R110 changes are delivered; do not replay qualification.
- **R106 delivered:** one existing native-return proof handles acyclic guards and
  selected return spans, with unchanged list factory borrowed by cold helper.
  No new engine/carrier/arena/owner/cache/options.205public/42internal focused per
  actual11/10. Guarded whole-script elapsed−13–17% across both APIs; coarse CPU
  supports gain, warm allocation neutral. Initial67e CSV+3% did not recur in1aa's
  bounded refinement; cause unresolved, original source/data retained. Compiler
  allocation+0.08–0.53%; Windows compiler timing uncertain, no universal compile gain.
- **Distinct established claims:** original native-return allocation−19.92/−19.31%,
  elapsed diagnostic. Formatting allocation−8.67%; controlled B102 elapsed/CPU−5–8%,
  original adverse15.125ms unexplained/preserved. R105 native JSON construction
  eager allocation−27–28%/elapsed−9–12%, streamed allocation−24%/elapsed−6–7%.
  Config coarseCPU+4–6% possible debt and older R76/R79/R95/R96/R102 debts remain
  separate. Favorable newer pairs do not silently repay old source-pair debt.
- **Current external baseline R109:** committed726/core1aa, CPython3.13.16,
  28jobs581.729s, all gates/archive/local verification pass; no users/fixtures.
  [BENCHMARKS](docs/BENCHMARKS.md) separates compile/warm/compile-to-result and names
  I/O/validation/cleanup boundaries. Warm CSV1.11x, returned CSV1.22–1.23x,
  JSON-lines0.92–0.93x, guarded text1.76–1.78x, eager normalization1.23–1.25x,
  streamed0.61–0.62x. Text/report controls remain variable. These are diagnostic
  named-source comparisons, no isolated causal gain. Startup/RSS/pending-I/O/
  embedding tails unmeasured. Prior15c and older guides preserved.
- **R108 assessment closed:**1110guest samples/5.58CPU seconds/64unknown5.77%.
  Formatting/JSON/dictionaries material; contexts0.72%leaf and call/frame3.96%
  despite84%inclusive. Groups overlap/inlining limits apply. No packaging dominance.
  Direct record filling, completed parser loops, UTF8 windows and final-buffer
  formatting already exist. R26/c4729 removed a stale-proof native formatted
  evaluator for correctness; preserve it. Original/corrected offline classifiers
  and failed pre-collection catalog ID retained; no profile retiming/prototype.

## Prioritized deliverables

1. **R110 committed/pushed05790317/core13107e6b; fully qualified.** One shared ordered-prefix value
   growth choice uses existing immutable layout.Count, removing intermediate
   replacements; baseline JSON seeding restored exactly. No new mechanism or API.
   Eight-record full-report replacement admissions21→7, initial funding unchanged;
   full goldens/balance0.897public/193internal Release peractual11/10 pass, including
   nine new shape/real-async/shared/pending/retained/cancel/refusal/cleanup cases.
   Wide allocation−8.56–8.58%bothAPIs; controlled elapsed−3.80to−10.29%sync/
   −6.05to−7.53%async, coarseCPU supports. Alternating allocation neutral, elapsed
   −1.59to−4.20%, CPUnearflat. CSVcontrol8.67%baseline spread inconclusive; JSON/
   shortreport nearbaseline. Initialeb14 startup capacity source/data preserved:
   wide allocation−11%, alternating+14.7%/elapsed+4.31to+10.82%. One bounded
   refinement, no unchanged favorable retime or unrelated old-debt repayment.
   Prefixes that outgrow initial backing can still retain spare hinted capacity
   or deny earlier; all storage/overlap funded and refusal terminal. Documented.
   Six jobs170.447s/all gates/archive/local pass, no users/fixtures. First disk
   preflight stopped before service/workers; measured wide evidence+50% now uses
   32MiBheadroom above unchanged240MiBfloor. Exact-byte17path hardlinks preserve
   every old alias/path/content/archive. Exact full delivery passes/cached CI42502610937, both OSes/actual11/10/original
   Stress/installed core. No repeated earlier qualification.

2. **R111 assessment closed; R112 selected: local result publication.**
   Existing16384iteration normal micro current0579/core1310≈700.968µs versus
   CPython596.612µs (1.17x), oldnumericcontrol713.390µs; lowIQR, diagnostic/no quiet-
   after, no R110numeric gain claim. Corrected six-second CPU capture1170samples/
   5.92CPU seconds/63unknown5.38%. CompleteLocalResult287leaf24.53%, prefix23420%,
   range14612.48%, exactaddition11810.09%, input1089.23%. Groups overlap; useful
   publication/check/cleanup work is not all removable. Initial missing optional
   file-digest capture failed beforewarmup; completedmicro not repeated, original
   worker/maps/IPC/archive preserved/cleaned; corrected profile-only allgates pass.
   R112 hypothesis: StoreLocalValue reads/classifies compiler names even for
   private slots needing no namespace synchronization. Move that pure metadata
   work into real GlobalNamespace/mirroring branches, retaining canonical writes.
   Remove unconditional LocalNames lookup/guest-name classification from private
   publication. No new flags/cache/arena/taggedvalue/dispatch/public option. Preserve
   cell writes, dynamic globals/locals, imports/module bindings, synthetic names,
   class namespaces/annotations, closures, cleanup order and existing lifetime
   fences. Keep all current cancellation/refusal/preflight/stack checks.
   Source gate~15min: verify no namespace/cell effect depends on earlier pure-name
   access; do not bypass required writes. Then smallest coherent source change,
   existing focused Release binding/namespace/function/generator/ownership/cancel
   regressions, one bounded source pair across loop and representative CSV/text/
   JSON scripts with unchanged controls. Report allocation and CPU separately;
   do not promise24% savings. Retain/correct/reject with explicit debt and bounded
   confirmation for real uncertainty. Full delivery at a coherent retained boundary.

3. **Remaining substantial redesign roadmap.** Complete call/frame construction,
   operand transport, per-record storage, text conversions and repeated frontend
   analysis remain candidates requiring demonstrated removable work. Current gates
   already establish direct arguments/final slots/native workstate, unboxed64-bit
   sum, cheap small-counter admission, UInt128 parsing, shared lexical facts and
   immutable builtins, executable imports and efficient comparison file handles.
   Do not reimplement absent phases. Old bulk CSV6–8% evidence/control regression
   remains; current keys/array adoption removed its proposed copying. Preserve
   slower R71 arena/control/wide-carrier lessons. Before a new prototype name its
   complete affected scripts, hypothesis, eliminated work/storage and displaced
   implementation, semantic/ownership/cancellation acceptance, bounded controlled
   comparison and completion/debt decision. Source selection~20min; unresolved
   attribution means uncertainty, not permission for speculative tags/caches/JIT/
   duplicate evaluators. No permanent ban on evidence-backed reconsideration.

4. **Independent regex contract/implementation.** Lython owns native UTF8 names,
   byte captures/scalar positions/original windows, Python flags/replacements/errors,
   ownership/current cancellation and one frontend/runtime/import provider. Core
   remains backend-independent; optional adapter nonpackable, ordinary0.4 pin.
   Exact dev55/d6067925 development checks86internal/514public peractual11/10 remain.
   Missing producer capabilities: DetailedData separate preparation/working owner,
   native-name enumeration and cursor creation without retaining an earlier token.
   Existing adapter-local bridges remain justified; development producers are valid.
   Separate contract forwarding/unwind, semantic tests and actual backend performance.
   Qualify affected final adapter against a released package when supplied; this
   never stops independent core work. No sibling edits/builds or unchanged replays.

## Acceptance and operating policy

Bounded confirmation, refinement and measurement correction are allowed. Timeout,
unstable unchanged controls or inconclusive data establish uncertainty, not failed
design. Size runs for usable quiet-VM observations. Preserve adverse results and
original failed conditions. Percentages inform decisions rather than veto useful
simplification. Separate architecture, allocation, demonstrated CPU and latency.
Temporary setbacks require an explicit completion milestone and regression decision.

AGENTS.md governs managed safety/stack admission, host mediation, cancellation and
shared coarse admission/preflights/replacement overlap. No unsafe/Unsafe/native
probing, independent caps/fuel/quotas, tracing/weak reclamation/forced GC, silent
regex fallback or abandoned work. Aliases/results/cache/pending users remain funded
until awaited cleanup; first refusal is terminal, no retries. Bounded host executions
remain the initial long-stream ownership boundary. No hidden default allowance.

Focused Release iteration; no overlapping local builds/tests/measurements. Fresh
build after timestamp-preserving restores. Batch actual11/10 Windows/Ubuntu/original
Stress/installed core at delivery. UTF8 text. Only core explicit Release pack into
artifacts/nuget; no publication/tagging. VM lokad@20.166.121.73, key
~/.ssh/id_lython-bench.pem. Persistent evidence separate from owned RAM: join users,
copy/verify maps, unmount, archive under lease and verify locally. No evidence deletion;
core hardlinks require fresh exact-byte/inode proof preserving paths and aliases.

B450–B471 terminal/cached; B470 completed micro/failed capture cleaned and archived,
B471 corrected capture complete/archived/locally verified. No VM users/fixtures. All recorded
terminal CI runs cached, including42496463028/726,42488128858/a7 and42484943603/15c;
never query again. Observations>=5min, no duplicate dispatch. Prior active plans
preserved privately; immutable measurement/qualification history stays separate.

R110 CI42502610937/05790317 is terminal green/cached; never query again.
