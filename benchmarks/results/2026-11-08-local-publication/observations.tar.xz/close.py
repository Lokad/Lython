from pathlib import Path
import hashlib, json, shutil, subprocess, tarfile

r = Path(__file__).parent
b = json.loads((r / 'baseline.json').read_text(encoding='utf8'))
i = json.loads((r / 'identity.json').read_text(encoding='utf8'))
a = json.loads((r / 'b472/archive-receipt.json').read_text(encoding='utf8'))
assert a['complete'] and a['allWorkersJoined'] and a['quietBeforeAndAfter']
assert not a['guestFixtureDirectories']
assert hashlib.sha256((r / 'b472/observations.tgz').read_bytes()).hexdigest() == a['archiveSHA256']
changed = 'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.cs'
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == h for p, h in i['productionSources'].items())
shutil.copyfile(changed, r / 'prototype-source.cs')
shutil.copyfile('PLAN.md', r / 'pre-close-plan.md')
decision = {
    'decision': 'Not retained; restore exact qualified baseline. No claim that the design is permanently closed.',
    'reason': 'Pure metadata relocation duplicates namespace branches without allocation reduction or a convincing whole-script benefit; report CPU debt remains possible. This is a complexity/evidence tradeoff, not a fixed improvement cutoff.',
    'focusedChecks': i['focusedChecks'],
    'qualification': 'Prototype focused Release only; no full CI dispatched. Restored production is already qualified05790317/core13107e6b.',
    'measurement': json.loads((r / 'b472/assessment.json').read_text(encoding='utf8')),
    'localBinaries': 'Still prototype761c30f7; must freshly rebuild nonincrementally before reuse. Frozen baseline13107e6b remains authoritative.'
}
(r / 'decision.json').write_text(json.dumps(decision, indent=2) + '\n', encoding='utf8')
out = Path('benchmarks/results/2026-11-08-local-publication')
out.mkdir()
with tarfile.open(out / 'observations.tar.xz', 'w:xz') as t:
    for p in sorted(r.iterdir()):
        if p.name == 'b472':
            for q in sorted(p.iterdir()):
                if q.name not in ['retrieved', 'payload.tgz']:
                    t.add(q, arcname='b472/' + q.name)
        else:
            t.add(p, arcname=p.name)
with tarfile.open(out / 'observations.tar.xz') as t:
    assert hashlib.sha256(t.extractfile('b472/observations.tgz').read()).hexdigest() == a['archiveSHA256']
for src, dest in [(r/'identity.json','identity.json'), (r/'decision.json','decision.json'), (r/'b472/assessment.json','assessment.json'), (r/'b472/archive-receipt.json','archive-receipt.json')]:
    shutil.copyfile(src, out / dest)
(out / 'README.md').write_text('''# Deferred local-name publication prototype

2026-11-08. Baseline `05790317` / core `13107e6b`; prototype over `7bd69241`,
core `761c30f7`. Only `StoreLocalValue` changed: defer immutable compiler-name
lookup/classification to actual global/mirroring branches. Cell writes, lifetime
fences, refusal/cancellation checks and cleanup were unchanged. No API change.
446 public /132 internal focused Release tests pass per actual .NET11/.NET10.
Prototype was not fully qualified and is **not retained**.

Normal-settings same-process diagnostics are allocation-neutral across the
integer loop and complete CSV/text/JSON/report scripts, both host APIs. Their
elapsed observations are mixed and remain in the archive.

B472 uses the existing quiet F4as_v7 VM, frozen worker7cf/optional0.4, normal
GC/tiering, two isolated roles per core, five-second warmup and seven rotated
150ms rounds. Six jobs/167.915s; full stdout/file goldens, ownership baselines,
image isolation, quiet endpoints, joined workers, fixture cleanup and local
archive verification all pass. Warm excludes compilation/startup/protocol;
includes invocation, I/O for file cases, validation and prior-result cleanup.
The maintained16384-iteration loop has no guest file I/O; empty file maps adapt
it to the existing file-capable diagnostic driver. No new benchmark framework.

| Workload | Elapsed change across all role pairings | CPU change |
| --- | ---: | ---: |
| Integer loop, synchronous |−3.98% to+3.70%|−3.57% to+3.30%|
| Integer loop, async API |−3.22% to−0.20%|−3.40% to−1.48%|
| CSV |−4.79% to+1.53%|0% to+1.82%|
| Text |−3.01% to+0.05%|−2.38% to0%|
| JSON |−1.61% to+1.02%|−2.44% to0%|
| Report |−0.29% to+1.70%|+1.42% to+3.84%|

Negative is faster. The synchronous-loop candidate roles differ5.79%; CSV old
roles differ4.33%. These cases are uncertain. Async loop supports a small gain;
report has possible CPU debt. No general CPU gain or CPython refresh follows.

Decision: restore the simpler canonical implementation. This pure relocation
adds duplicated namespace branch structure, with no allocation reduction and no
convincing whole-script benefit. This is a complexity/evidence tradeoff, not a
fixed percentage veto or permanent rejection of publication redesign. Preserve
the profile lesson: publication includes necessary checks/retirement and cannot
be removed solely from its inclusive or leaf sample share.

[Decision and qualification](decision.json), [all controlled roles](assessment.json),
[identity](identity.json), [archive receipt](archive-receipt.json),
[sources, binaries, diagnostics and raw VM archive](observations.tar.xz).
''', encoding='utf8')
raw = subprocess.check_output(['git', 'show', 'HEAD:' + changed])
variants = [raw, raw.replace(b'\r\n', b'\n'), raw.replace(b'\r\n', b'\n').replace(b'\n', b'\r\n')]
original = next(v for v in variants if hashlib.sha256(v).hexdigest() == b['productionSources'][changed])
Path(changed).write_bytes(original)
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == h for p, h in b['productionSources'].items())
p = Path('benchmarks/EXPERIMENTS.md')
p.write_text(p.read_text(encoding='utf8') + '''
## Local publication tradeoff (2026-11-08)

[R112/B472](results/2026-11-08-local-publication/README.md) defers compiler-name
lookup/classification to real namespace branches; focused446public/132internal
peractual11/10 pass, allocation neutral. Six controlled jobs167.915s/all gates:
async loop modestly faster, sync loop/control spread inconclusive, representative
file scripts nearbaseline/control-limited, report CPU+1.42–3.84%possible debt.
Not retained: duplicated cold branch structure without convincing complete-script
benefit or allocation reduction. No fixed percentage veto/permanent design ban.
Exact fully qualified baseline restored; prototype binaries must not be reused
without a fresh build. Raw/source/binaries/adverse results archived and verified;
all users ended/owned RAM unmounted. No full CI replay for restored identical code.
''', encoding='utf8')
p = Path('PLAN.md'); s = p.read_text(encoding='utf8'); start = s.index('2. **R111'); end = s.index('3. **Remaining substantial', start)
s = s[:start] + '''2. **R111/R112 closed; broader helper source gate next.** R111 existing loop
   diagnostic700.968µs versusCPython596.612µs≈1.17x(no quiet-after), profile1170
   samples: publication24.53%leaf includes necessary checks/cleanup. R112 deferred
   pure name lookup,446public/132internal peractual11/10 pass; allocation neutral.
   B472 six jobs167.915s/all gates/archive/localverified. Async loop modest gain;
   sync loop/control spread uncertain; report CPU+1.42–3.84%possible debt. Not
   retained: duplicated namespace branches without convincing whole-script benefit.
   This is a complexity/evidence tradeoff, no fixed threshold/permanent rejection.
   Exact qualified05790317 production restored; local761 prototype bins are stale
   for current source and require a nonincremental build before reuse. Evidence
   lives under2026-11-08-local-publication; no full CI replay of unchanged baseline.
   Next bounded source gate: assess ordinary primitive arithmetic helper bodies
   against existing Add-only native-return proof. Reuse canonical operations,
   existing metadata/ownership/cancellation; no new evaluator or scalar framework.
   Confirm representative relevance and removable call/frame work before selecting
   a design. Preserve dynamic/suspending protocols, exact results/errors, evaluation
   order, mutable lookup guards and admission reentry. If current scripts do not
   expose material work, record that and select the next demonstrated cost.

''' + s[end:]
s = s.replace('B450–B471 terminal/cached;', 'B450–B472 terminal/cached;')
p.write_text(s, encoding='utf8')
print('R112 archived, not retained, exact production inventory restored; local bins require rebuild.')
