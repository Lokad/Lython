set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab=$1
filter='(FullyQualifiedName~Arithmetic|FullyQualifiedName~Integer|FullyQualifiedName~ExecutableOperandStack|FullyQualifiedName~NativeReturn|FullyQualifiedName~FunctionDefault|FullyQualifiedName~WordBuffer|FullyQualifiedName~CasedSplit|FullyQualifiedName~AsyncMidFlightCancellation|FullyQualifiedName~AdmissionFailureCommand)&Category!=Stress'
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="$lab/$suite-continuation-ubuntu.log"
    dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --artifacts-path "$lab/linux" --filter "$filter" >"$log" 2>&1 || { tail -n 45 "$log"; exit 1; }
    tail -n 8 "$log"
done
