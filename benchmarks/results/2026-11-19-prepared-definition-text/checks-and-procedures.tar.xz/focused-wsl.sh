#!/usr/bin/env bash
set -euo pipefail
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
cd /mnt/d/code/Lython/.git/agent-worktrees/prepared-definition-text-r611
public='FullyQualifiedName~FunctionDocstringLifetime|FullyQualifiedName~FunctionMetadata|FullyQualifiedName~FunctionDefaults|FullyQualifiedName~ClassMethodCompatibility|FullyQualifiedName~Definition|FullyQualifiedName~ImportArchitectureSubsystem|FullyQualifiedName~GovernedImport|FullyQualifiedName~BindingPlanConstruction|FullyQualifiedName~Lambda|FullyQualifiedName~GeneratorFunction'
white='FullyQualifiedName~BoundBoxCleanup|FullyQualifiedName~BoundMethodInvocationBoundary|FullyQualifiedName~CasedSplitOwnership|FullyQualifiedName~ExecutableFunctionInvocationBoundary|FullyQualifiedName~ManagedStackGuard|FullyQualifiedName~NativeFunctionRefund|FullyQualifiedName~SimpleFunctionExecutionBoundary|FullyQualifiedName~FunctionDefaultConstruction'
"$DOTNET_ROOT/dotnet" test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --artifacts-path artifacts/r611-wsl --filter "$public"
"$DOTNET_ROOT/dotnet" test tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj -c Release -f net10.0 --artifacts-path artifacts/r611-wsl --filter "$white"
