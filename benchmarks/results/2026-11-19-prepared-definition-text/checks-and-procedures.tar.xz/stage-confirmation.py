import ast
import hashlib
import json
from pathlib import Path
import tarfile

lab=Path(__file__).resolve().parent
previous=lab/"quiet"
confirmation=lab/"confirmation"
def read(path):
    return path.read_text(encoding="utf-8-sig")
def load(path):
    return json.loads(read(path))
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path, source):
    if path.suffix == ".py":
        ast.parse(source)
    path.write_text(source, encoding="utf-8", newline="\n")
def save(path, data):
    write(path, json.dumps(data, indent=2, ensure_ascii=False) + "\n")

old=load(previous/"config.json")
identity=old["identity"]
images=identity["imageFiles"]
receipt=load(previous/"archive-receipt.json")
assert receipt["complete"] and receipt["allWorkersJoined"] and receipt["archiveSHA256"]==sha(previous/"observations.tgz")
for role, files in images.items():
    assert len(files)==32 and {name:sha(lab/"frozen"/role/name) for name in files}==files
catalog=lab/"catalog.json"
assert sha(catalog)==old["catalogSHA256"]

confirmation.mkdir()
root="/home/lokad/lython-bench-checks/prepared-definition-text-confirmation-b1042-20261119"
unit="lython-b1042-prepared-definition-text-confirmation-20261119"
jobs=[('calls.positional.large', 'warm'), ('scripts.annotated-rule-closures', 'compile-run'), ('scripts.rule-default-closures', 'compile-run')]
runner=read(previous/"collect.py").replace("Prepared definition text source pair","R611 confirmation of positional control and rule compile-to-result")
a,b=runner.index("\njobs = "),runner.index("\nassert len(jobs)")
runner=(runner[:a]+"\njobs = "+repr(jobs)+runner[b:]).replace("len(jobs)==9","len(jobs)==3")
runner=runner.replace("['reference-control','candidate-control','reference','candidate']",
    "['reference','candidate','reference-control','candidate-control']")
write(confirmation/"collect.py",runner)
write(confirmation/"archive-owned.py",read(previous/"archive-owned.py").replace("len(raw['jobs'])==9","len(raw['jobs'])==3").replace("jobs=9,","jobs=3,"))
write(confirmation/"run.sh",read(previous/"run.sh").replace(old["root"],root))
identity = identity | dict(purpose="R611 confirmation of positional control and rule compile-to-result with identical images and catalog")
save(confirmation/"identity.json",identity)
names=["collect.py","archive-owned.py","run.sh","identity.json"]
payload=confirmation/"payload.tgz"
with tarfile.open(payload,"w:gz") as out:
    for name in names:
        out.add(confirmation/name,arcname=name)
expanded=sum((confirmation/name).stat().st_size for name in names)
needed=254*1024*1024+expanded+524288
space=load(lab/"quiet-space.json")
available=space["freeBytes"]
selected=[]
for proof in space["replicas"]:
    if available>needed+49152:
        break
    assert proof["committedBlobVerified"]
    available+=proof["bytes"]
    selected.append(proof)
assert available>needed
config=dict(root=root,unit=unit,source=old["root"],sourceRole="candidate",sourceFiles=images["candidate"],
            sourceCatalogSHA256=old["catalogSHA256"],catalogSHA256=sha(catalog),identity=identity,retireGroups=selected,
            payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),unpackedBytes=expanded)
save(confirmation/"config.json",config)
launch=read(previous/"remote-launch.py")
a,b=launch.index("\nc=")+1,launch.index("\nb=Path(")
launch=(launch[:a]+"c="+repr(config)+launch[b:]).replace("lython-b1041-fixtures","lython-b1042-fixtures")
verify=" for n,h in c['sourceFiles'].items():assert sha(source/c['sourceRole']/n)==h,n"
assert launch.count(verify)==1
launch=launch.replace(verify," for role,files in c['identity']['imageFiles'].items():\n  for n,h in files.items():assert sha(source/role/n)==h,n")
assert launch.count("os.link(source/c['sourceRole']/n,p)")==1
launch=launch.replace("os.link(source/c['sourceRole']/n,p)","os.link(source/role/n,p)")
write(confirmation/"remote-launch.py",launch)
write(lab/"launch-confirmation.py",read(lab/"launch-quiet.py").replace("/'quiet'","/'confirmation'").replace("440","170"))
write(confirmation/"retrieve.py",read(previous/"retrieve.py").replace("==9","==3"))
write(lab/"summarize-confirmation.py",read(lab/"summarize-quiet.py").replace("quiet/","confirmation/").replace("==9","==3").replace("quiet-summary","confirmation-summary"))
print("Three confirmation jobs use the same frozen workers, runtime files and exact case rows.")
