from pathlib import Path
import json
import subprocess
import sys

lab=Path(__file__).resolve().parent
old=lab.parent/'selected-abstract-path-r713'
ref=lab.parent/'factory-cpython-b1151'
catalog=json.loads((old/'catalog.json').read_text(encoding='utf-8-sig'))
known=json.loads((ref/'representative.json').read_text(encoding='utf-8-sig'))['cases']
catalog['cases'].append(next(case for case in known if case['id']=='scripts.csv-invoice.large'))
(lab/'catalog.json').write_text(json.dumps(catalog,indent=2,ensure_ascii=False)+'\n',encoding='utf8',newline='\n')
code=(old/'freeze-and-verify.py').read_text(encoding='utf8').replace('selected-abstract-path-r713','prepared-mutation-calls')
code=code.replace("previous=lab.parent/'integer-transport-cpython-b1136'","previous=lab.parent/'factory-cpython-b1151'")
code=code.replace("git('rev-parse','ee057fd12')","git('rev-parse','0d74b5b18')")
code=code.replace('["cases"]) == 5','["cases"]) == 6').replace('all five cases','all six cases')
code=code.replace("        if name==core:\n            build_dir='windows' if role=='candidate' else 'reference'\n            origin=lab/build_dir/'bin/Lokad.Lython/release_net11.0'/name",
   "        if name==core and role=='candidate':\n            origin=trial/'src/Lokad.Lython/bin/Release/net11.0'/name")
assert 'reference' in code and 'if name==core and role' in code
(lab/'freeze-and-verify.py').write_text(code,encoding='utf8',newline='\n')
subprocess.run([sys.executable,'-X','utf8',lab/'freeze-and-verify.py'],check=True)
subprocess.run([sys.executable,'-X','utf8',lab.parent/'postfix-statement-r699/measure-compile-allocation.py',lab],check=True)
