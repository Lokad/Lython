from pathlib import Path
import subprocess
import sys

lab=Path(__file__).resolve().parent
template=lab.parent/'compiled-definition-keys'
code=(template/'stage-quiet.py').read_text(encoding='utf8')
code=code.replace('integer-transport-cpython-b1136','factory-cpython-b1151')
code=code.replace('compiled-definition-keys-b1149','prepared-mutation-calls-b1152')
code=code.replace('lython-b1149-compiled-definition-keys','lython-b1152-prepared-mutation-calls')
code=code.replace('lython-b1149-fixtures','lython-b1152-fixtures')
code=code.replace('R716 compiler-owned definition keys','Ordered mutation candidates from syntax validation')
code=code.replace('Compiler-owned definition keys','Prepared mutation candidates')
jobs=[('scripts.config-generated-guards.medium','compile'),
      ('scripts.config-manifest.small','compile'),
      ('scripts.config-generated-guards.medium','compile-run'),
      ('scripts.annotated-rule-closures','compile'),
      ('scripts.csv-invoice.large','warm'),
      ('scripts.rule-default-closures','warm')]
start=code.index('        jobs = [')
end=code.index('\n',start)
code=code[:start]+'        jobs = '+repr(jobs)+code[end:]
code=code.replace("jobs'])==7","jobs'])==6").replace("jobs']==7","jobs']==6").replace('len(jobs)==7','len(jobs)==6').replace('jobs=7,','jobs=6,')
code=code.replace('seven-job','six-job').replace('435','355')
code=code.replace('"reference/" + core, "candidate/" + core]', '"candidate/" + core]')
code=code.replace('assert staged[\'sourceFiles\'] == source_files', 'assert files == images["candidate"] and source_files == images["reference"]\nassert staged[\'sourceFiles\'] == source_files') if False else code
code=code.replace('source_files = old["identity"]["imageFiles"]["candidate"]',
                  'source_files = old["identity"]["imageFiles"]["candidate"]\nassert source_files == images["reference"]')
assert '"reference/" + core,' not in code and repr(jobs) in code
proof=(template/'prove-quiet-space.py').read_text(encoding='utf8')
start,end=proof.index('pairs = ['),proof.index('records=[]')
pairs=[('compiled-definition-keys/quiet','2026-11-19-compiled-definition-keys','reference','reference-core.dll.gz'),
       ('csv-rule-cpython-b1143','2026-11-19-csv-rule-cpython-checkpoint','candidate','measured-core.dll.gz')]
proof=proof[:start]+'pairs = '+repr(pairs)+'\n'+proof[end:]
for path,text in [('prove-quiet-space.py',proof),('stage-quiet.py',code)]:
    (lab/path).write_text(text,encoding='utf8',newline='\n')
    subprocess.run([sys.executable,'-X','utf8',lab/path],check=True)
