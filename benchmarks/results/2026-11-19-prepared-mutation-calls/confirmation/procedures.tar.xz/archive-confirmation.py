from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
original = lab/'quiet'
confirmed = lab/'confirmation-corrected'
out = Path('benchmarks/results/2026-11-19-prepared-mutation-calls/confirmation')
def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

terminal = read(confirmed/'terminal-status.json')
receipt = read(confirmed/'archive-receipt.json')
assert terminal['exitCode'] == '0' and terminal['receipt'] == receipt
assert not terminal['remainingWorkers'] and not terminal['remainingTrace']
assert all(receipt[name] for name in ('complete','quietBeforeAndAfter','allWorkersJoined',
    'guestFixturesRemoved','archivedAndVerifiedUnderLease'))
assert receipt['jobs']==2 and receipt['archiveSHA256']==digest(confirmed/'observations.tgz')
identity = read(confirmed/'identity.json')
assert identity == read(original/'identity.json')
assert len(identity['imageFiles']) == 2
for role, files in identity['imageFiles'].items():
    assert len(files)==32 and {name:digest(lab/'frozen'/role/name) for name in files}==files
assert digest(confirmed/'representative.json')==identity['catalogSHA256']
assert read(confirmed/'config.json')['donorArchiveSHA256']==digest(original/'observations.tgz')
cases = {case['id']:case for case in read(confirmed/'representative.json')['cases']}
raw = read(confirmed/'retrieved/confirmation/confirmation.json')
assert raw['complete'] and raw['warmupSeconds']>=10
assert [(job['case'], job['lane']) for job in raw['jobs']]==[
    ('scripts.annotated-rule-closures','compile'), ('scripts.config-generated-guards.medium','compile-run')]
count = 0
for row in raw['jobs']:
    case = cases[row['case']]
    assert row['workersJoinedAndFixturesRemoved']
    for label, worker in row['identities'].items():
        files = identity['imageFiles'][label.split('-',1)[0]]
        for library in worker['libraries']:
            name = Path(library['path']).name
            if name in files: assert library['sha256'].lower()==files[name]
        assert any(Path(lib['path']).name=='Lokad.Lython.dll' for lib in worker['libraries'])
    for sample in row['samples']:
        result = sample['response']
        assert result['status']=='Completed' and result['completedInvocations']>0
        for key in ('sourceSha256','fixtureSha256','expectedOutputSha256'): assert result[key]==case[key]
        assert result.get('actualOutputSha256')==(None if row['lane']=='compile' else case['expectedOutputSha256'])
        assert result.get('actualFilesSha256')==(None if row['lane']=='compile' else case.get('expectedFilesSha256'))
        count += 1
assert count==40
out.mkdir(exist_ok=True)
for name in ('archive-receipt.json','terminal-status.json','observations.tgz'):
    shutil.copyfile(confirmed/name,out/name)
shutil.copyfile(lab/'confirmation-summary.json',out/'summary.json')
with tarfile.open(out/'procedures.tar.xz','w:xz',preset=6) as tar:
    for name in ('prepare-confirmation.py','build-confirmation.py','launch-confirmation.py',
                 'summarize-confirmation.py','archive-confirmation.py','confirmation-stage.log','confirmation-stage-first.log','confirmation-retrieval.log'):
        tar.add(lab/name,arcname=name)
    for name in ('identity.json','config.json','collect.py','archive-owned.py','run.sh','retrieve.py',
                 'remote-launch.py','launch.log','observe-not-before.json'):
        tar.add(confirmed/name,arcname='confirmation/'+name)
print('Verified exact B1152 reuse, 40 timed responses, awaited cleanup and receipts.')
