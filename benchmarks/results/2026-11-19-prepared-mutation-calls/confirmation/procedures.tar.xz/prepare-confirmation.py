from pathlib import Path
import subprocess
import sys

lab = Path(__file__).resolve().parent
prior = lab.parent / 'compiled-definition-keys'
code=(prior/'build-confirmation.py').read_text(encoding='utf8')
code=code.replace('compiled-definition-keys-b1150-20261119','prepared-mutation-calls-b1154-20261119')
code=code.replace('lython-b1150-compiled-definition-keys','lython-b1154-prepared-mutation-calls')
code=code.replace('lython-b1150-control-fixtures','lython-b1154-control-fixtures')
code=code.replace("jobs = [('scripts.annotated-rule-closures', 'warm'), ('scripts.csv-invoice.large', 'warm'), ('scripts.annotated-rule-closures', 'compile-run')]",
    "jobs = [('scripts.annotated-rule-closures', 'compile'), ('scripts.config-generated-guards.medium', 'compile-run')]")
code=code.replace('B1149 lane','B1152 lane')
code=code.replace('len(jobs)==7','len(jobs)==6')
code=code.replace("len(raw['jobs'])==7","len(raw['jobs'])==6").replace("['jobs']==7","['jobs']==6").replace('jobs=7,','jobs=6,')
code=code.replace("len(jobs)==3","len(jobs)==2").replace("len(raw['jobs'])==3","len(raw['jobs'])==2")
code=code.replace("['jobs']==3","['jobs']==2").replace('jobs=3,','jobs=2,')
code=code.replace('out.mkdir(exist_ok=False)','out.mkdir(exist_ok=True)\nassert not (out / "launch.log").exists()')
# Both inputs were collected at index two or later, with reversed labels.
code=code.replace('            if job_index == 0: labels.reverse()\\n','')
code=code.replace("replace('435','185')","replace('355','130')")
code=code.replace('three unchanged cases','two unchanged lanes')
assert "jobs = [('scripts.annotated-rule-closures', 'compile'), ('scripts.config-generated-guards.medium', 'compile-run')]" in code
assert "==6" in code and "==2" in code
p=lab/'build-confirmation.py'
p.write_text(code,encoding='utf8',newline='\n')
subprocess.run([sys.executable,'-X','utf8',p],check=True)
