using Lokad.Lython.Frontend;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal sealed partial class ExecutableFrameInterpreter
    {
        // Only call boundaries copy this state. Opcode handlers keep direct
        // fields and the existing local/operand arrays, without window offsets.
        private struct Activation
        {
            public ExecutionContext Context;
            public ExecutableFrameState Frame;
            public ExecutableValueStack Stack;
            public ExecutableMemberCache?[] MemberCaches;
            public int?[] BlockDepths;
            public int BlockIndex, InstructionIndex;
            public PendingAbruptSignal? PendingAbrupt;
            public bool WaitingForSend, HasYield, HasFrameReturn;
            public object SentValue, YieldValue;
            public LythonRuntimeException? InjectedException;
            public GeneratorDelegation? Delegation;
            public object? FrameReturnValue;
            public Stack<ActiveExceptionSave>? SavedActiveExceptions;
            public PyException? EntryException;
            public ExecutionContext? InvocationCaller;
            public LythonSourceSpan? InvocationSpan;
            public bool OwnsCallerAdmission;
            public MemoryGovernor? BoundStorageOwner;
            public long BoundStorageBytes;
            public ExecutableCallSite? PendingCallSite;
            public PyExecutableFunction? PendingFunction;
            public object? PendingReceiver;
            public int PendingCallStart;
            public object? CompletedCallValue;
            public Exception? CompletedCallError;
            public CallCompletion Completion;
            public LythonSourceSpan? ProtocolCallSpan;
            public object? PreparedTypeSubscription;
        }

        private ExecutableFrameState _lexicalFrame;
        private Activation[] _continuations = [];
        private int _continuationCount;
        private MemoryGovernor.TemporaryMemoryReservation? _continuationStorage;
        // Includes all reference/control fields, the embedded operand descriptor
        // and deliberate metadata headroom. Actual backing capacity stays funded.
        private const long ContinuationBytes = 384;

        internal ExecutableFrameState LexicalFrame => _lexicalFrame;
        internal bool IsActiveFrame(ExecutableFrameState frame) => ReferenceEquals(frame, _lexicalFrame);

        public static ExecutableFrameInterpreter Create(ExecutableCodeObject codeObject,
            ExecutionContext context, BoundCallArguments arguments,
            IReadOnlyList<ExecutableCell>? closureCells, bool argumentsAreLocals)
            => new(CreateActivation(codeObject, context, arguments, closureCells, argumentsAreLocals));

        private static Activation CreateActivation(ExecutableCodeObject codeObject,
            ExecutionContext context, BoundCallArguments boundArguments,
            IReadOnlyList<ExecutableCell>? closureCells, bool argumentsAreLocals)
        {
            // InvokeBound owns bound storage until this interpreter has detached,
            // including actual asynchronous suspension. No second local array/copy
            // is needed for nonmirrored executable functions.
            var entry = codeObject.Blocks[codeObject.EntryBlockIndex].Instructions;
            var span = entry.Count == 0 ? null : entry[0].Span;
            var bytes = argumentsAreLocals || codeObject.LocalNames.Count == 0 ? 64L
                : checked(64L + EstimateObjectArrayBytes(codeObject.LocalNames.Count));
            if (codeObject.CapturedLocalSlots.Count != 0)
                bytes = checked(bytes + EstimateObjectArrayBytes(codeObject.LocalNames.Count)
                    + 48L * codeObject.CapturedLocalSlots.Count);
            if (codeObject.MemberCacheCount != 0)
                bytes = checked(bytes + 32L + 64L * codeObject.MemberCacheCount);
            if (codeObject.ExceptionRegions.Count != 0)
                bytes = checked(bytes + EstimateObjectArrayBytes(codeObject.Blocks.Count));
            // The existing operand lifetime funds private frame arrays before any
            // are allocated. Escaping cells acquire their separate retained charge.
            var stack = new ExecutableValueStack(Math.Max(8, codeObject.LocalNames.Count), context, span, bytes);
            try
            {
                var locals = argumentsAreLocals ? boundArguments.Values
                    : codeObject.LocalNames.Count == 0 ? [] : new object[codeObject.LocalNames.Count];
                Array.Fill(locals, UninitializedLocal, argumentsAreLocals ? boundArguments.Assigned.Length : 0,
                    locals.Length - (argumentsAreLocals ? boundArguments.Assigned.Length : 0));
                var needsLocalCells = codeObject.CapturedLocalSlots.Count != 0;
                ExecutableCell?[]? localCells = null;
                if (needsLocalCells)
                {
                    localCells = new ExecutableCell[codeObject.LocalNames.Count];
                    for (var i = 0; i < codeObject.CapturedLocalSlots.Count; i++)
                    {
                        var slot = codeObject.CapturedLocalSlots[i];
                        localCells[slot] = new ExecutableCell(argumentsAreLocals ? locals[slot] : UninitializedLocal, context, codeObject.LocalNames[slot]);
                    }
                }
    
                var argumentValues = boundArguments.Values ?? Array.Empty<object>();
                for (var i = 0; !argumentsAreLocals && i < boundArguments.Assigned.Length; i++)
                {
                    var value = argumentValues[i];
                    locals[i] = value;
                    if (localCells?[i] is ExecutableCell localCell)
                    {
                        localCell.Value = value;
                    }
                }
    
                return InitializeActivation(codeObject, context, locals, localCells, closureCells, stack);
            }
            catch
            {
                stack.ReleaseStorage();
                throw;
            }
        }

        private static Activation InitializeActivation(ExecutableCodeObject code, ExecutionContext context,
            object[] locals, ExecutableCell?[]? cells, IReadOnlyList<ExecutableCell>? closures,
            ExecutableValueStack stack)
            => new()
            {
                Context = context,
                Frame = new ExecutableFrameState(code, locals, cells, closures),
                Stack = stack,
                MemberCaches = code.MemberCacheCount == 0 ? [] : new ExecutableMemberCache?[code.MemberCacheCount],
                BlockDepths = code.ExceptionRegions.Count == 0 ? [] : new int?[code.Blocks.Count],
                BlockIndex = code.EntryBlockIndex,
                EntryException = context.State.CurrentException,
                SentValue = PyNone.Instance,
                YieldValue = PyNone.Instance,
            };

        private Activation CaptureActivation()
        {
            _lexicalFrame.SaveInstructionSpan(CurrentInstructionSpan);
            return new()
            {
                Context = _context,
                Frame = _lexicalFrame,
                Stack = _stack,
                MemberCaches = _memberCaches,
                BlockDepths = _blockEntryStackDepths,
                BlockIndex = _currentBlockIndex,
                InstructionIndex = _instructionIndex,
                PendingAbrupt = _pendingAbrupt,
                WaitingForSend = _waitingForSend,
                HasYield = HasYield,
                HasFrameReturn = _hasFrameReturn,
                SentValue = _sentValue,
                YieldValue = YieldValue,
                InjectedException = _injectedException,
                Delegation = _delegation,
                FrameReturnValue = _frameReturnValue,
                SavedActiveExceptions = _savedActiveExceptions,
                EntryException = _entryActiveException,
                InvocationCaller = _invocationCaller,
                InvocationSpan = _invocationSpan,
                OwnsCallerAdmission = _ownsCallerAdmission,
                BoundStorageOwner = _boundStorageOwner,
                BoundStorageBytes = _boundStorageBytes,
                PendingCallSite = _pendingCallSite,
                PendingFunction = _pendingFunction,
                PendingReceiver = _pendingReceiver,
                PendingCallStart = _pendingCallStart,
                CompletedCallValue = _completedCallValue,
                CompletedCallError = _completedCallError,
                Completion = _callCompletion,
                ProtocolCallSpan = _protocolCallSpan,
                PreparedTypeSubscription = _preparedTypeSubscription,
            };
        }

        private void InstallActivation(Activation activation)
        {
            RestoreStorage(activation.Frame);
            _context = activation.Context;
            _lexicalFrame = activation.Frame;
            _stack = activation.Stack;
            _memberCaches = activation.MemberCaches;
            _blockEntryStackDepths = activation.BlockDepths;
            _currentBlockIndex = activation.BlockIndex;
            _instructionIndex = activation.InstructionIndex;
            _pendingAbrupt = activation.PendingAbrupt;
            _waitingForSend = activation.WaitingForSend;
            HasYield = activation.HasYield;
            _hasFrameReturn = activation.HasFrameReturn;
            _sentValue = activation.SentValue;
            YieldValue = activation.YieldValue;
            _injectedException = activation.InjectedException;
            _delegation = activation.Delegation;
            _frameReturnValue = activation.FrameReturnValue;
            _savedActiveExceptions = activation.SavedActiveExceptions;
            _entryActiveException = activation.EntryException;
            _invocationCaller = activation.InvocationCaller;
            _invocationSpan = activation.InvocationSpan;
            _ownsCallerAdmission = activation.OwnsCallerAdmission;
            _boundStorageOwner = activation.BoundStorageOwner;
            _boundStorageBytes = activation.BoundStorageBytes;
            _pendingCallSite = activation.PendingCallSite;
            _pendingFunction = activation.PendingFunction;
            _pendingReceiver = activation.PendingReceiver;
            _pendingCallStart = activation.PendingCallStart;
            _completedCallValue = activation.CompletedCallValue;
            _completedCallError = activation.CompletedCallError;
            _callCompletion = activation.Completion;
            _protocolCallSpan = activation.ProtocolCallSpan;
            _preparedTypeSubscription = activation.PreparedTypeSubscription;
            _lexicalFrame.AttachDispatcher(this);
        }

        private void PushContinuation(LythonSourceSpan span)
        {
            if (_continuationCount == _continuations.Length)
            {
                var capacity = _continuations.Length == 0 ? 4 : checked(_continuations.Length * 2);
                var bytes = checked(32L + ContinuationBytes * capacity);
                var previous = _continuations.Length == 0 ? 0 : checked(32L + ContinuationBytes * _continuations.Length);
                var storage = _continuationStorage ??= _context.MemoryGovernor.ReserveTemporary(0, span);
                storage.Grow(bytes, span);
                try
                {
                    _context.CheckExecution(span);
                    var replacement = new Activation[capacity];
                    Array.Copy(_continuations, replacement, _continuationCount);
                    _continuations = replacement;
                }
                catch { storage.Shrink(bytes); throw; }
                storage.Shrink(previous);
            }
            _continuations[_continuationCount] = CaptureActivation();
            _continuationCount++;
        }

        private Activation PopContinuation()
        {
            var index = --_continuationCount;
            var activation = _continuations[index];
            _continuations[index] = default;
            return activation;
        }

        private void ReleaseContinuations()
        {
            _continuations = [];
            _continuationCount = 0;
            _continuationStorage?.Dispose();
            _continuationStorage = null;
        }
    }
}
