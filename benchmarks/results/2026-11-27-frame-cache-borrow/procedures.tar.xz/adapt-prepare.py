from pathlib import Path

lab = Path(__file__).resolve().parent
old = lab.parent / "generator-definition-cache-20261127"
entry = (old / "prepare.py").read_text(encoding="utf-8")
entry = entry.replace('"generator-resume-protocol-20261127/comparison"', '"generator-definition-cache-20261127/comparison"')
entry = entry.replace('b"PyFunctionBase? lookupOwner" in patch and patch.count(b"diff --git ") == 5',
                      'b"_lookupStorage = shared;" in patch and patch.count(b"diff --git ") == 2')
lo = entry.index("_, wide, iterable, file_map")
hi = entry.index("write(pair / \"representative.json\"", lo)
entry = entry[:lo] + """iterable, bound, file_map, wide = catalog["cases"]
assert iterable["id"].endswith("iterable-rows") and bound["id"].endswith("bound-starmap") and wide["id"].endswith("wide-lists")
""" + entry[hi:]
entry = entry.replace('[file_map["id"], "warm"], [iterable["id"], "warm-async"]',
                      '[wide["id"], "warm-async"], [iterable["id"], "warm-async"]')
entry = entry.replace('Compare sharing function-owned lookup backing across generator calls.',
                      'Compare direct access to the established lookup backing from each frame.')
entry = entry.replace('replace("len(jobs) == 3", "len(jobs) == 4").replace("lython-b1894-generator-resume-protocol-", "lython-generator-definition-cache-")',
                      'replace("lython-generator-definition-cache-", "lython-frame-cache-borrow-")')
entry = entry.replace('root.parent / "generator-resume-protocol-20261127/run.sh"', 'old / "comparison/run.sh"')
entry = entry.replace('launch = (old / "comparison/run.sh").read_bytes()', 'launch = (root.parent / "generator-definition-cache-20261127/comparison/run.sh").read_bytes()')
compile(entry, "prepare.py", "exec")
(lab / "prepare.py").write_text(entry, encoding="utf-8", newline="\n")
