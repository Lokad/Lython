from hashlib import sha256
from pathlib import Path
from shutil import copyfile, copytree
from statistics import median
import json
import os
import subprocess

root = Path(__file__).resolve().parent
repo = root.parents[3]
base = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip()
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8", newline="\n")
def image(folder):
    return {path.name: digest(path) for path in folder.iterdir()}

source = root.parent / "generator-definition-cache-20261127/comparison"
original = read(source / "identity.json")
assert sha256(subprocess.check_output(["git", "diff", "--binary", original["sourceRevision"], base, "--", "src"], cwd=repo)).hexdigest() == original["sourcePatchSHA256"]
patch = subprocess.check_output(["git", "diff", "--binary", base, "--", "src"], cwd=repo)
assert b"_lookupStorage = shared;" in patch and patch.count(b"diff --git ") == 2
(root / "candidate.patch").write_bytes(patch)
(root / "regression.patch").write_bytes(subprocess.check_output(["git", "diff", "--binary", base, "--", "tests"], cwd=repo))
pair = root / "comparison"
pair.mkdir()
assert image(source / "candidate") == original["imageFiles"]["candidate"]
for role in ("reference", "candidate"):
    copytree(source / "candidate", pair / role)
core = "Lokad.Lython.dll"
fresh = repo / "src/Lokad.Lython/bin/Release/net11.0" / core
assert digest(fresh) == digest(repo / "tests/Lokad.Lython.Tests/bin/Release/net11.0" / core)
copyfile(fresh, pair / "candidate" / core)
images = {role: image(pair / role) for role in ("reference", "candidate")}
assert [name for name, before in images["reference"].items() if images["candidate"][name] != before] == [core]
copyfile(source / "cpython-worker.py", pair / "cpython-worker.py")
assert digest(pair / "cpython-worker.py") == original["cpythonWorkerSHA256"]
golden = source / "representative.json"
assert digest(golden) == original["catalogs"][golden.name]["sha256"]
catalog = read(golden)
iterable, bound, file_map, wide = catalog["cases"]
assert iterable["id"].endswith("iterable-rows") and bound["id"].endswith("bound-starmap") and wide["id"].endswith("wide-lists")
write(pair / "representative.json", catalog)
write(pair / "jobs.json", {"warm": [[iterable["id"], "warm"], [bound["id"], "warm-async"], [wide["id"], "warm-async"], [iterable["id"], "warm-async"]]})
data = dict(sourceRevision=base, productionReference=base,
            sourcePatchSHA256=digest(root / "candidate.patch"), imageFiles=images,
            coreSHA256={role+suffix: hashes[core] for role, hashes in images.items() for suffix in ("", "-control")},
            cpythonWorkerSHA256=original["cpythonWorkerSHA256"], cpythonPath=original["cpythonPath"],
            expectedCPythonSHA256=original["expectedCPythonSHA256"],
            purpose="Compare direct access to the established lookup backing from each frame.",
            catalogs={name: {"sha256": digest(pair / name)} for name in ("representative.json", "jobs.json")})
write(pair / "identity.json", data)
collector = (source / "collect.py").read_text(encoding="utf-8").replace("lython-generator-definition-cache-", "lython-frame-cache-borrow-")
compile(collector, "collect.py", "exec")
(pair / "collect.py").write_text(collector, encoding="utf-8", newline="\n")
launch = (root.parent / "generator-definition-cache-20261127/comparison/run.sh").read_bytes()
assert b"\r" not in launch
(pair / "run.sh").write_bytes(launch)

allocation = root / "allocation"
allocation.mkdir()
witness = root.parent / "csv-dictwriter-direct-fields-20261127/allocation/candidate"
for role, files in images.items():
    folder = allocation / role
    copytree(pair / role, folder)
    for file in witness.glob("ValidatedAllocation*"):
        copyfile(file, folder / file.name)
    assert (folder / "ValidatedAllocation.dll").is_file()
    assert all(digest(folder / name) == checksum for name, checksum in files.items())
sdk = Path.home() / ".dotnet11"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
rows = []
for mode in ("sync", "async"):
    for case in catalog["cases"]:
        case["runAsync"] = mode == "async"
    selection = allocation / f"{mode}-catalog.json"
    write(selection, catalog)
    comparisons = []
    for role in images:
        folder = allocation / role
        report = allocation / f"{role}-{mode}.json"
        subprocess.run([sdk / "dotnet.exe", folder / "ValidatedAllocation.dll", folder, selection, report], env=env, check=True, timeout=90)
        comparisons.append(read(report)["rows"])
    for before, after in zip(*comparisons, strict=True):
        assert before["id"] == after["id"]
        assert before["sharedBudgetBaselineRestored"] and after["sharedBudgetBaselineRestored"]
        row = dict(case=before["id"], mode=mode, clr=[median(r["allocatedBytesPerInvocation"]) for r in (before, after)],
                   peak=[r["peakExecutionMemoryBytes"] for r in (before, after)],
                   compiled=[r["compiledReservedBytes"] for r in (before, after)])
        rows.append(row)
        print(row, flush=True)
write(allocation / "summary.json", rows)
