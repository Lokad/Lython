from pathlib import Path
from hashlib import sha256
from shutil import copyfile
import json
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
pair = lab / "comparison"
out = repo / "benchmarks/results/2026-11-27-frame-cache-borrow"
read = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()
summary = read(pair / "summary.json")
identity = read(pair / "identity.json")
assert summary["verifiedTimedBatches"] == 112
assert read(pair / "archive-receipt.json")["archiveSHA256"] == digest(pair / "observations.tar.xz")
assert summary["candidatePatchSHA256"] == identity["sourcePatchSHA256"] == digest(lab / "candidate.patch")
assert subprocess.check_output(["git", "diff", "--binary", identity["sourceRevision"], "--", "src"], cwd=repo) == (lab / "candidate.patch").read_bytes()
assert all("Passed!" in (lab / f"windows-{f}.log").read_text(encoding="utf-8") for f in ("net10.0", "net11.0"))
assert all(row["peak"][0] == row["peak"][1] for row in read(lab / "allocation/summary.json"))
out.mkdir(exist_ok=True)
for name in ("identity.json", "summary.json", "observations.tar.xz", "archive-receipt.json"):
    copyfile(pair / name, out / name)
copyfile(lab / "allocation/summary.json", out / "allocation-summary.json")
entries = [lab / name for name in ("archive.py", "adapt-prepare.py", "prepare.py", "prepare.log", "summarize.py", "candidate.patch",
                                  "windows-net10.0.log", "windows-net11.0.log")]
entries.extend(pair / name for name in ("reference-verify.json", "candidate-verify.json", "run.sh", "exit-code.txt", "collection.log"))
entries.extend((lab / "allocation").glob("*.json"))
with tarfile.open(out / "procedures.tar.xz", "w:xz") as bundle:
    for path in entries:
        bundle.add(path, arcname=path.relative_to(lab))
with tarfile.open(out / "procedures.tar.xz") as bundle:
    assert all(bundle.extractfile(path.relative_to(lab).as_posix()).read() == path.read_bytes() for path in entries)
