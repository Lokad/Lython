using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime;

using var document = JsonDocument.Parse(File.ReadAllText(args[0]));
var observations = new List<object>();
foreach (var entry in document.RootElement.GetProperty("cases").EnumerateArray())
{
    var id = entry.GetProperty("id").GetString();
    if (id is not ("scripts.rule-default-closures" or "scripts.annotated-rule-closures" or "scripts.captured-rule-closures" or "scripts.retained-nonlocal-factories")) continue;
    var parsed = LythonFrontend.Compile(entry.GetProperty("source").GetString()!);
    var script = ExecutableScript.Compile(LoweredScript.Lower(parsed.Script!));
    observations.Add(new { id, functions = script.EntryPoint.Constants.OfType<ExecutableCreateFunction>().Select(create => Describe(create.Binding.CodeObject)).ToArray() });
}
Console.WriteLine(JsonSerializer.Serialize(new { coreSha256 = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))), observations }, new JsonSerializerOptions { WriteIndented = true }));

static object Describe(ExecutableCodeObject code) => new
{
    code.Name,
    code.CanRunNativeInstructions,
    code.ValueStorageCapacity,
    managedInlineCapacity = LythonRuntime.NativeValueCapacity,
    capturedLocals = code.CapturedLocalSlots.Count,
    code.RequiresLocalVariableMirroring,
    instructions = code.Instructions.Select(instruction => instruction.OpCode == ExecutableOpCode.ApplyOperation
        ? code.Constants[instruction.ConstantIndex]!.GetType().Name : instruction.OpCode.ToString()).ToArray(),
    definitions = code.Constants.OfType<ExecutableCreateFunction>().Select(create => new
    {
        create.Binding.Name,
        supportedLocalTarget = code.LocalNameToSlot.ContainsKey(create.Binding.Name),
        create.Binding.DecoratorCount,
        annotations = create.Binding.Annotations.Length,
        generics = create.Binding.TypeParameters is not null,
        child = Describe(create.Binding.CodeObject),
    }).ToArray(),
    lambdas = code.Constants.OfType<ExecutableCreateLambda>().Select(create => Describe(create.CodeObject)).ToArray(),
};
