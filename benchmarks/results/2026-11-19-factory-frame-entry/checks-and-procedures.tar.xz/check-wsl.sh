set -e
cd /mnt/d/code/Lython/.git/agent-worktrees/factory-frame-r647
export PATH="$HOME/.dotnet:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/factory-frame-r647
filter='(FullyQualifiedName~Definition|FullyQualifiedName~NativeFunctionRefund|FullyQualifiedName~SimpleFunctionExecutionBoundary|FullyQualifiedName~ComposedNativeCall|FullyQualifiedName~NativeClosureSequence|FullyQualifiedName~FunctionDefault|FullyQualifiedName~Decorat|FullyQualifiedName~Annotation|FullyQualifiedName~GovernedMemoryContract|FullyQualifiedName~AsyncMidFlightCancellation|FullyQualifiedName~StackSafety)&Category!=Stress'
for project in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="$logs/$project-wsl-net10.log"
    code=0
    dotnet test "tests/$project" -c Release -f net10.0 --artifacts-path "$PWD/tests/artifacts/r647-wsl" --filter "$filter" > "$log" 2>&1 || code=$?
    if [ "$code" != 0 ]; then tail -25 "$log"; exit "$code"; fi
    tail -4 "$log"
done
