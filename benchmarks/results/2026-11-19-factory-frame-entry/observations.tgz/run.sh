set -eu
root=/home/lokad/lython-bench-checks/factory-frame-b1077-20261119
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
