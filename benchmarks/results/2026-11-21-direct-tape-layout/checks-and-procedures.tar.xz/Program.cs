using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;

var engine = new LythonEngine();
var budget = new LythonMemoryBudget();
var catalogBytes = File.ReadAllBytes(args[0]);
using var catalog = JsonDocument.Parse(catalogBytes);
Console.Error.WriteLine($"catalog {Convert.ToHexString(SHA256.HashData(catalogBytes))}");
Console.Error.WriteLine($"core {Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location)))}");
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var id = item.GetProperty("id").GetString()!;
    var source = item.GetProperty("source").GetString()!;
    if (!args.Skip(1).Contains(id)) continue;
    Console.Error.WriteLine($"case {id}");
    using (var code = engine.Compile(source, budget))
        if (!code.IsValid || code.Diagnostics.Count != 0)
            throw new InvalidOperationException($"Public compiler rejected {id}.");
    if (budget.ReservedBytes != 0) throw new InvalidOperationException("Compiler budget failed to refund.");
}
