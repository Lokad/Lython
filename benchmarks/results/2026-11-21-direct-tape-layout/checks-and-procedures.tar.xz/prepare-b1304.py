from pathlib import Path
r = Path('.git/agent-notes/review-20261031')
template = r / 'regex-local-one-shot-20261121'
target = r / 'tape-block-layout-20261121'
s = (template / 'prepare-quiet.py').read_text(encoding='utf-8')
start = s.index('csv="')
end = s.index('prior_config =', start)
s = s[:start] + '''retire = []
for stage, directory, label in (
    ("regex-local-single-b1303-20261121", "2026-11-21-regex-local-one-shot", "regex-local-one-shot-20261121"),
    ("abstract-fork-sharing-b1289-20261121", "2026-11-21-abstract-fork-sharing", "abstract-fork-sharing"),
):
    previous = lab.parent / label / "quiet"
    previous_identity = load(previous / "identity.json")
    previous_archive = load(previous / "archive-receipt.json")
    core_hash = previous_identity["imageFiles"]["candidate"]["Lokad.Lython.dll"]
    retire.append(recoverable(directory+"/candidate-core.dll.gz",
        [stage+"/candidate/Lokad.Lython.dll"], 1, core_hash,
        {stage:(directory+"/observations.tgz",previous_archive["archiveSHA256"])}))
''' + s[end:]
s = s.replace('load(lab / "representative.json")','load(lab / "catalog.json")')
s = s.replace('["scripts.regex.single-match-records", "scripts.regex.cursor-records", "scripts.regex.wide-single-match", "scripts.regex.wide-unicode-single-match"]',
              '["scripts.config-generated-guards.medium.bad-0", "scripts.annotated-rule-closures.nested-factories.postponed", "scripts.dataclass-inherited-configuration.generated"]')
s = s.replace('reference.startswith("d51891009") and candidate.startswith("225575497")','reference.startswith("480c89e6b") and candidate.startswith("672a5678a")')
s = s.replace('lab / "frozen"', 'lab / "workers"')
s = s.replace('("white", 67), ("public", 424)','("white", 385), ("public", 1250)')
s = s.replace('        log = (lab / f"{suite}-win.log").read_text(encoding="utf-8-sig")\n        assert "Passed!" in log and f"Passed: {count:5d}, Skipped:" in log',
'''        for platform in ("win", "ubuntu"):
            log = (lab / f"{suite}-{platform}.log").read_text(encoding="utf-8-sig")
            assert "Passed!" in log and f"Passed: {count:5d}, Skipped:" in log''')
s = s.replace('proof["caseCount"] == 4','proof["caseCount"] == 3')
s = s.replace('Remove the prepared-operation wrapper from all one-shot matches','Write checked operand layout directly to the tape')
s = s.replace('regex-local-single-b1303-20261121"\nunit', 'direct-tape-layout-b1304-20261121"\nunit')
s = s.replace('lython-b1303-regex-local-single-20261121','lython-b1304-direct-tape-layout-20261121')
s = s.replace('lython-b1303-fixtures','lython-b1304-fixtures')
s = s.replace('jobs = [(case, "warm") for case in cases]','jobs = [(cases[0], "compile"), (cases[0], "compile-run"), (cases[1], "compile"), (cases[2], "compile")]')
s = s.replace('         "candidate/" + core)', '         "reference/" + core, "candidate/" + core)')
s = s.replace('emit(lab / "launch.py", (csv_stage.parent / "launch.py").read_text(encoding="utf-8")\n     .replace("Native CSV record ranges comparison", "All-width single-match regex scratch comparison").replace("225","300"))',
'''emit(lab / "launch.py", (lab.parent / "regex-local-one-shot-20261121/launch.py").read_text(encoding="utf-8")
     .replace("All-width single-match regex scratch comparison", "Direct tape layout phase comparison"))''')
s = s.replace('emit(lab / "summarize.py", (csv_stage.parent / "summarize.py").read_text(encoding="utf-8")\n     .replace("len(raw[\'jobs\'])==3", "len(raw[\'jobs\'])==4"))',
'''emit(lab / "summarize.py", (lab.parent / "regex-local-one-shot-20261121/summarize.py").read_text(encoding="utf-8"))''')
s = s.replace('    if name == "collect.py":', '    if name == "run.sh":\n        original = original.replace("regex-local","direct-tape-layout")\n    if name == "collect.py":')
compile(s, str(target/'prepare-quiet.py'), 'exec')
(target/'prepare-quiet.py').write_text(s, encoding='utf-8', newline='\n')
