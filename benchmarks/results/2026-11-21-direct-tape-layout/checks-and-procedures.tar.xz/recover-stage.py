from pathlib import Path
import hashlib
import json
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
work = repo / ".git/agent-worktrees/dead-block-shape-20261121"
old = lab / "quiet"
first = lab / "quiet-failed-preflight"
assert old.exists() and not first.exists()
assert b"FileNotFoundError" in (old / "launch.log").read_bytes()
assert not (old / "observe-not-before.json").exists()
old.rename(first)
donor = lab.parent / "native-only-method-lookup-20261121"
prior = json.loads((donor / "quiet/identity.json").read_text(encoding="utf-8"))
hashes = prior["imageFiles"]["candidate"]
assert len(hashes) == 32

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

reference = subprocess.check_output(["git", "rev-parse", "d51891009"], cwd=repo, text=True).strip()
candidate = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=work, text=True).strip()
subprocess.run(["git", "diff", "--exit-code", "672a5678a", candidate, "--", "src/Lokad.Lython/Frontend"], cwd=repo, check=True)
source = donor / "frozen/candidate"
candidate_core = work / "src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll"
known = {}
for role in ("reference", "candidate"):
    folder = lab / "quiet-workers" / role
    folder.mkdir(parents=True)
    for name, digest in hashes.items():
        original = source / name
        assert sha(original) == digest
        if name == "Lokad.Lython.dll" and role == "candidate":
            original = candidate_core
        shutil.copyfile(original, folder / name)
        assert sha(folder / name) == sha(original)
    known[role] = {path.name: sha(path) for path in folder.iterdir()}
(lab / "quiet-images.json").write_text(json.dumps(dict(reference=reference, candidate=candidate, imageFiles=known),indent=2)+"\n",encoding="utf-8",newline="\n")

source = (lab/"prepare-quiet.py").read_text(encoding="utf-8")
source = source.replace('    ("abstract-fork-sharing-b1289-20261121", "2026-11-21-abstract-fork-sharing", "abstract-fork-sharing"),\n', '')
source = source.replace('local = load(lab / "identity.json")','local = load(lab / "quiet-images.json")')
source = source.replace('assert reference.startswith("480c89e6b") and candidate.startswith("672a5678a")','assert reference.startswith("d51891009") and candidate == local["candidate"]')
source = source.replace('image = lab / "workers" / role','image = lab / "quiet-workers" / role')
source = source.replace('shutil.copyfile(lab / "workers" / role / core','shutil.copyfile(lab / "quiet-workers" / role / core')
source = source.replace('         "reference/" + core, "candidate/" + core)','         "candidate/" + core)')
assert 'abstract-fork-sharing-b1289-20261121' not in source
compile(source, str(lab / "prepare-quiet-rebased.py"), "exec")
(lab / "prepare-quiet-rebased.py").write_text(source, encoding="utf-8", newline="\n")
