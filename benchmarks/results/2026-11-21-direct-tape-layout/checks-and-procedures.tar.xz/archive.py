from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
quiet = lab / "quiet"
out = Path("benchmarks/results/2026-11-21-direct-tape-layout")

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

identity = load(quiet / "identity.json")
a, _, b = identity["sourceRevision"].split()
assert a.startswith("d51891009") and b.startswith("77ae31406")
for role, files in identity["imageFiles"].items():
    image = lab / "quiet-workers" / role
    assert len(files) == 32 and {name: sha(image / name) for name in files} == files
    assert sha(quiet / role / "Lokad.Lython.dll") == files["Lokad.Lython.dll"]
    proof = load(lab / f"quiet-{role}-verify.json")
    assert proof["state"] == "Completed" and proof["caseCount"] == 3
    assert proof["catalogSha256"] == identity["catalogSHA256"] == sha(quiet / "representative.json")
    local = load(lab / f"{role}-verify.json")
    assert local["state"] == "Completed" and local["caseCount"] == 3
    assert local["catalogSha256"] == sha(lab / "catalog.json")
subprocess.run(["git", "diff", "--exit-code", "672a5678a", b, "--", "src/Lokad.Lython/Frontend"], check=True)
for platform in ("win", "ubuntu"):
    for suite, count in (("white", 385), ("public", 1250)):
        log = (lab / f"{suite}-{platform}.log").read_text(encoding="utf-8-sig")
        assert "Passed!" in log and f"Passed: {count:5d}, Skipped:" in log
inspection = load(lab / "inspection-identity.json")
assert inspection["exactCodeObjects"] == 61
assert load(lab / "reference-inspection.json")["rows"] == load(lab / "candidate-inspection.json")["rows"]
assert "tape 3 1 3 513 1" in (lab / "dead-heavy-shape.log").read_text(encoding="utf-8")
receipt = load(quiet / "archive-receipt.json")
status = load(quiet / "terminal-status.json")
assert status["exitCode"] == "0" and status["receipt"] == receipt
assert not status["remainingTrace"] and not status["remainingWorkers"]
assert all(receipt[k] for k in ("complete", "allWorkersJoined", "guestFixturesRemoved", "archivedAndVerifiedUnderLease", "quietBeforeAndAfter"))
assert sha(quiet / "observations.tgz") == receipt["archiveSHA256"]
raw = load(quiet / "retrieved/confirmation/confirmation.json")
assert raw["warmupSeconds"] == 8 and raw["targetBatchSeconds"] == .65 and raw["rounds"] == 7
cases = {case["id"]: case for case in load(quiet / "representative.json")["cases"]}
assert raw["complete"] and len(raw["jobs"]) == receipt["jobs"] == 4 and len(cases) == 3
assert [job["lane"] for job in raw["jobs"]] == ["compile", "compile-run", "compile", "compile"]
for job in raw["jobs"]:
    case = cases[job["case"]]
    assert job["workersJoinedAndFixturesRemoved"] and len(job["samples"]) == 28
    for sample in job["samples"]:
        response = sample["response"]
        assert response["completedInvocations"] > 0 and response["status"] == "Completed"
        assert response["sourceSha256"] == case["sourceSha256"] and response["fixtureSha256"] == case["fixtureSha256"]
        run = job["lane"] != "compile"
        assert response.get("actualOutputSha256") == (case["expectedOutputSha256"] if run else None)
        assert response.get("actualFilesSha256") == (case.get("expectedFilesSha256") if run else None)

summary = load(quiet / "quiet-summary.json")
del summary["retentionDecisionPending"]
summary.update(collection="B1304", sourceRevision=identity["sourceRevision"], verifiedTimedBatches=112,
    coreSHA256=identity["coreSHA256"], archiveSHA256=receipt["archiveSHA256"],
    retentionDecision="private; exact-size tape redesign remains open")
out.mkdir(exist_ok=True)
(out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8", newline="\n")
for name in ("README.md", "compile-allocation-summary.json", "micro-summary.json"):
    shutil.copyfile(lab / name, out / name)
for name in ("archive-receipt.json", "terminal-status.json", "observations.tgz"):
    shutil.copyfile(quiet / name, out / name)
reference = Path("benchmarks/results/2026-11-21-native-only-method-lookup/candidate-core.dll.gz")
assert gzip.decompress(reference.read_bytes()) == (quiet / "reference/Lokad.Lython.dll").read_bytes()
core = (quiet / "candidate/Lokad.Lython.dll").read_bytes()
image = out / "candidate-core.dll.gz"
image.write_bytes(gzip.compress(core, mtime=0))
assert gzip.decompress(image.read_bytes()) == core
(lab / "measured-source.patch").write_bytes(subprocess.check_output(["git", "diff", a, b, "--", "src"]))
with tarfile.open(out / "checks-and-procedures.tar.xz", "w:xz", preset=6) as archive:
    for folder in (lab, quiet, lab / "quiet-failed-preflight", lab / "quiet-prepare-failure"):
        for path in sorted(folder.iterdir()):
            if path.is_file() and path.suffix not in {".dll", ".tgz", ".xz"}:
                archive.add(path, arcname=path.relative_to(lab).as_posix())
print("112 timed batches and 61 exact code objects verified. All failures and observations archived.")
