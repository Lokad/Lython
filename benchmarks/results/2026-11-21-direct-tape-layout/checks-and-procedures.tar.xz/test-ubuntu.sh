set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/dead-block-shape-20261121
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/tape-block-layout-20261121
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter 'Category!=Stress&(FullyQualifiedName~Executable|FullyQualifiedName~Frontend|FullyQualifiedName~Parser|FullyQualifiedName~Compiler)' --verbosity quiet > "$logs/white-ubuntu.log" 2>&1
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter 'Category!=Stress&(FullyQualifiedName~Compile|FullyQualifiedName~RuntimePath|FullyQualifiedName~Exception|FullyQualifiedName~GovernedMemoryContract|FullyQualifiedName~Annotation|FullyQualifiedName~ControlFlow)' --verbosity quiet > "$logs/public-ubuntu.log" 2>&1
grep 'Passed!' "$logs/white-ubuntu.log" "$logs/public-ubuntu.log"
