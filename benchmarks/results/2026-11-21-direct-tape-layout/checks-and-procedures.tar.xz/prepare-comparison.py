from pathlib import Path
r = Path(".git/agent-notes/review-20261031")
lab = r / "tape-block-layout-20261121"
prior = r / "branch-prefix-linearization"
s = (prior / "freeze.py").read_text(encoding="utf-8")
s=s.replace("joint-lexical-admission-on-current/frozen/reference","csv-literal-record-ranges-20261121/frozen/candidate").replace("joint-lexical-admission-on-current/identity.json","csv-literal-record-ranges-20261121/identity.json")
s=s.replace('known = reference_manifest["imageFiles"]["reference"]','known = reference_manifest["imageFiles"]["candidate"]').replace('reference_manifest["referenceImageSource"]','reference_manifest["candidate"]')
s=s.replace('a488d561b','480c89e6b').replace('9c2b6e46d','672a5678a')
s=s.replace('candidate_core = lab / "candidate/inspect/Lokad.Lython.dll"','candidate_core = repo / ".git/agent-worktrees/dead-block-shape-20261121/src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll"')
s=s.replace('manifest = lab / "catalog.json"','manifest = lab / "catalog.json"\nshutil.copyfile(lab.parent / "branch-prefix-linearization/catalog.json", manifest)')
(lab/"freeze.py").write_text(s,encoding="utf-8",newline="\n")
s=(prior/"micro.py").read_text(encoding="utf-8").replace('env=env, capture_output=True, encoding="utf-8", errors="replace",','env=env, capture_output=True, encoding="utf-8", errors="replace", timeout=75,')
(lab/"micro.py").write_text(s,encoding="utf-8",newline="\n")
