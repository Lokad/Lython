from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
v={'paths': ['normalization-cpython-b823-20261116/representative.json', 'normalization-profile-b824-20261116/catalog.json'], 'bytes': 143512, 'sha256': 'e54e390cbf0f624487e31a43e2b2df957bc7e51c76f2ff700a3a23fc3826d8fb', 'canonicalCommit': '86d9344e654e94eeab738c8156bd2b7f95c12576', 'canonicalPath': 'benchmarks/results/2026-11-16-normalization-cpython-checkpoint/procedure-and-inputs.tar.xz', 'member': 'inputs/representative.json'}
b=Path('/home/lokad/lython-bench-checks')
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(os.path.ismount(p)for p in b.glob('*/guest-fixtures'))
 paths=[b/n for n in v['paths']];m=paths[0].lstat();key=(m.st_dev,m.st_ino)
 for p in paths:
  n=p.lstat();assert p.resolve()==p and p.is_relative_to(b)and stat.S_ISREG(n.st_mode)and n.st_uid==os.getuid()and n.st_nlink==2 and n.st_size==v['bytes']and(n.st_dev,n.st_ino)==key and hashlib.sha256(p.read_bytes()).hexdigest()==v['sha256']
 aliases=[]
 for root,dirs,names in os.walk(b):
  for name in names:
   p=Path(root)/name;n=p.lstat()
   if(n.st_dev,n.st_ino)==key:aliases.append(str(p.relative_to(b)))
 assert sorted(aliases)==sorted(v['paths'])
 before=shutil.disk_usage(b).free
 for p in paths:p.unlink()
 print(json.dumps(dict(retiredOnly=v,freshIdleLease=True,allHashesPathsOwnershipLinksAndAliasesVerified=True,currentImagesToolchainsAndFloorsUnchanged=True,freeBeforeBytes=before,freeAfterBytes=shutil.disk_usage(b).free)))
