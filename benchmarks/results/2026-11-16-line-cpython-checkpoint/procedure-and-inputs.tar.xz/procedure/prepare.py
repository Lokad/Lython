from pathlib import Path
import ast
r=Path(__file__).parent
s=(r.parent/'normalization-checkpoint-r427/launch.py').read_text(encoding='utf-8')
s=s.replace("base=r.parent/'consume-text-r426'","base=r.parent/'line-construction-r430'").replace("'116fe6e0'","'86d9344e'").replace('==593','==600')
s=s.replace("base/'quiet/identity.json'","base/'confirmation/identity.json'").replace("base/'quiet/retrieved/additional.json'","base/'confirmation/retrieved/additional.json'")
s=s.replace('810dafdd2afb684158374098c5b16e850369b7a6ebe2a56e451f3bd96f741d46','ecd9e956b007224f927de3c722c612668da094529aa125ca6adcd456184eaab2')
s=s.replace("catalog['cases']=[next(c for c in catalog['cases'] if c['id']=='scripts.text-normalization.large')]", "catalog=json.loads((base/'confirmation/representative.json').read_text(encoding='utf-8'))")
s=s.replace("(q/'representative.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\\n',encoding='utf-8',newline='\\n')", "(q/'representative.json').write_bytes((base/'confirmation/representative.json').read_bytes())")
s=s.replace('normalization-cpython-b823-20261116','line-cpython-b829-20261116').replace('lython-b823-normalization-cpython-20261116','lython-b829-line-cpython-20261116').replace('/frozen810dafdd','/frozenecd9e956')
s=s.replace('Complete Unicode file normalization warm/fresh against CPython; fill new useful workload gap to prioritize a whole generator/iteration/text pipeline, not a causal source comparison.', 'Refresh complete normalization warm/fresh against CPython after direct bulk-output and line-construction milestones; exact current source, no causal cross-collection speedup.')
s=s.replace('Committed/pushed116fe6e0;87internal/2547public focused eachactual11/10;593committed inputs verified;full43797131423active','Committed/pushed86d9344e;487internal/1656public plus4relatedstress eachactual11/10;600committed inputs verified;full43805966777active')
s=s.replace(".replace('B816','B823')", ".replace('B816','B829')")
s=s.replace("['identity.json','representative.json','collect.py','archive-owned.py','run.sh']","['identity.json','collect.py','archive-owned.py','run.sh']")
s=s.replace("source='/home/lokad/lython-bench-checks/consume-text-b822-20261116'", "source='/home/lokad/lython-bench-checks/line-confirm-b828-20261116'")
a=s.index("canonical='benchmarks/results/");b=s.index('c=dict(root=root',a)
s=s[:a]+'''canonical='benchmarks/results/2026-11-16-line-construction/confirmation/observations.tgz'
raw=Path(canonical).read_bytes();assert subprocess.check_output(['git','show',head+':'+canonical])==raw
with tarfile.open(fileobj=io.BytesIO(raw))as a:body=a.extractfile('confirmation/confirmation.json').read()
retire=[dict(path='line-confirm-b828-20261116/confirmation/confirmation.json',bytes=len(body),sha256=hashlib.sha256(body).hexdigest(),canonicalCommit=head,canonicalPath=canonical,member='confirmation/confirmation.json'),dict(path='line-confirm-b828-20261116/observations.tgz',bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),canonicalCommit=head,canonicalPath=canonical,member=None)]
'''+s[b:]
s=s.replace("(base/'catalog.json').read_bytes()","(base/'confirmation/representative.json').read_bytes()")
s=s.replace("code=code.replace('lython-b816-fixtures','lython-b823-fixtures')", "code=code.replace('lython-b816-fixtures','lython-b829-fixtures').replace(\" (root/'candidate').mkdir()\",\" os.link(c['catalog'],root/'representative.json')\\n (root/'candidate').mkdir()\")")
ast.parse(s);(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
