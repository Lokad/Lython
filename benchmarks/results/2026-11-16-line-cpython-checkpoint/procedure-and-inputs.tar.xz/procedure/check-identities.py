from pathlib import Path
import hashlib,json
r=Path(__file__).parent;roots={'old':r.parent/'normalization-checkpoint-r427/checkpoint','new':r/'checkpoint'};rows={};cases={}
for name,p in roots.items():
 catalog=json.loads((p/'retrieved/representative.json').read_text(encoding='utf-8'));cases[name]=next(c for c in catalog['cases']if c['id']=='scripts.text-normalization.large')
 raw=json.loads((p/'retrieved/confirmation/confirmation.json').read_text(encoding='utf-8'))
 rows[name]=dict(workerSHA256=hashlib.sha256((p/'retrieved/cpython-worker.py').read_bytes()).hexdigest(),catalogCases=len(catalog['cases']),environment=raw.get('environment'),identities=raw['jobs'][0]['identities'],counts=raw['jobs'][0]['counts'])
differences=[k for k in set(cases['old'])|set(cases['new'])if cases['old'].get(k)!=cases['new'].get(k)]
out=dict(casesIdentical=not differences,caseDifferenceKeys=differences,rows=rows)
(r/'identity-review.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Cases identical:',not differences,'different keys:',differences)
for name,v in rows.items():
 print(name,'worker',v['workerSHA256'],'catalog cases',v['catalogCases'],'counts',v['counts'])
 for label,identity in v['identities'].items():
  if label.startswith('CPython'):print(name,label,identity)
