from pathlib import Path
import hashlib,json,shlex,shutil,subprocess,tarfile
r=Path(__file__).parent;q=r/'checkpoint'
if not(r/'original-floor-stage').exists():shutil.copytree(q,r/'original-floor-stage')
if(r/'catalog-retirement-command.py').exists():shutil.copyfile(r/'catalog-retirement-command.py',r/'original-own-pgrep-command.py')
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();path='benchmarks/results/2026-11-16-normalization-cpython-checkpoint/procedure-and-inputs.tar.xz';raw=Path(path).read_bytes();assert subprocess.check_output(['git','show',head+':'+path])==raw
with tarfile.open(path)as a:data=a.extractfile('inputs/representative.json').read()
proof=dict(paths=['normalization-cpython-b823-20261116/representative.json','normalization-profile-b824-20261116/catalog.json'],bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),canonicalCommit=head,canonicalPath=path,member='inputs/representative.json')
code=r'''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
v=PROOF
b=Path('/home/lokad/lython-bench-checks')
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 workers=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True).stdout
 own={str(os.getpid()),str(os.getppid())};assert all(line.split(maxsplit=1)[0]in own for line in workers.splitlines()),workers
 assert not any(os.path.ismount(p)for p in b.glob('*/guest-fixtures'))
 paths=[b/n for n in v['paths']];m=paths[0].lstat();key=(m.st_dev,m.st_ino)
 for p in paths:
  n=p.lstat();assert p.resolve()==p and p.is_relative_to(b)and stat.S_ISREG(n.st_mode)and n.st_uid==os.getuid()and n.st_nlink==2 and n.st_size==v['bytes']and(n.st_dev,n.st_ino)==key and hashlib.sha256(p.read_bytes()).hexdigest()==v['sha256']
 aliases=[]
 for root,dirs,names in os.walk(b):
  for name in names:
   p=Path(root)/name;n=p.lstat()
   if(n.st_dev,n.st_ino)==key:aliases.append(str(p.relative_to(b)))
 assert sorted(aliases)==sorted(v['paths'])
 before=shutil.disk_usage(b).free
 for p in paths:p.unlink()
 print(json.dumps(dict(retiredOnly=v,freshIdleLease=True,allHashesPathsOwnershipLinksAndAliasesVerified=True,currentImagesToolchainsAndFloorsUnchanged=True,freeBeforeBytes=before,freeAfterBytes=shutil.disk_usage(b).free)))
'''.replace('PROOF',repr(proof))
(r/'catalog-retirement-command.py').write_text(code,encoding='utf-8',newline='\n');ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];p=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],capture_output=True,text=True,encoding='utf-8',timeout=45);assert p.returncode==0,p.stderr;(r/'catalog-retirement-receipt.json').write_text(p.stdout,encoding='utf-8',newline='\n');print(p.stdout)
s=(r/'launch.py').read_text(encoding='utf-8').replace("q.mkdir();old=","q.mkdir(exist_ok=True);old=");(r/'launch-corrected.py').write_text(s,encoding='utf-8',newline='\n')
