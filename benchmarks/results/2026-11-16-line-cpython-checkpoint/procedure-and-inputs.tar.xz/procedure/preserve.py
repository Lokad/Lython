from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;q=r/'checkpoint';out=Path('benchmarks/results/2026-11-16-line-cpython-checkpoint');out.mkdir();d=json.loads((q/'summary.json').read_text(encoding='utf-8'));receipt=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'));review=json.loads((r/'identity-review.json').read_text(encoding='utf-8'))
assert d['complete']and d['jobs']==2 and receipt['complete']and receipt['allWorkersJoined'];assert hashlib.sha256((q/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256'];assert review['casesIdentical']and review['rows']['old']['workerSHA256']==review['rows']['new']['workerSHA256']
for n in ['identity.json','summary.json','observations.tgz','archive-receipt.json','terminal-status.json']:shutil.copyfile(q/n,out/n)
shutil.copyfile(r/'identity-review.json',out/'identity-review.json');shutil.copyfile('docs/BENCHMARKS.md',out/'prior-BENCHMARKS.md')
with tarfile.open(out/'procedure-and-inputs.tar.xz','w:xz')as a:
 for p in q.iterdir():
  if p.is_file()and p.name!='observations.tgz':a.add(p,arcname='checkpoint/'+p.name)
 for p in r.iterdir():
  if p.is_file():a.add(p,arcname='procedure/'+p.name)
 a.add(r/'original-floor-stage',arcname='original-floor-stage')
 for n in ['representative.json','additional.json','cpython-worker.py']:a.add(q/'retrieved'/n,arcname='inputs/'+n)
 a.add(r.parent/'line-construction-r430/delivery/source-proof.json',arcname='source-proof.json')
rows=[];detail=[]
for x in d['timing']:
 phase='warm Run'if x['lane']=='warm'else'compile and execute once';m=x['medianMilliseconds'];l=[m[n]for n in ['candidate','candidate-control']];p=[m[n]for n in ['CPython','CPython-control']];lt=f'{min(l):.3f}–{max(l):.3f} ms';pt=f'{min(p):.3f}–{max(p):.3f} ms';ratio=f"{min(x['ratioRange']):.2f}–{max(x['ratioRange']):.2f}×";status=f"Diagnostic; CPython shifted across collections; IQR ≤{x['maxIqrPercent']:.2f}%"
 rows.append(f'| File normalization / {phase} | 4,096 lines / 52,224 B | {lt} | {pt} | {ratio} | {status} |')
 detail.append(f"| {phase} | {lt} | {pt} | {ratio} | {x['lythonControlPercent']:.2f}/{x['cpythonControlPercent']:.2f}% | {x['maxIqrPercent']:.2f}% |")
(out/'README.md').write_text('''# Current complete normalization against CPython

R432/B829,2026-11-16UTC. **86d9344e /measured ecd9e956** versus stock
**CPython3.13.16**.600 frozen production/build/test inputs match committed source;
487internal/1,656public plus4related original-scale stress pass eachactual.NET11/10.
Full43805966777 is active at capture; this comparison does not qualify all runtime
behavior. Publication held. Existing complete52,224B/4,096-line Unicode normalization,
54,269B/4,095-line output, unchanged independent stdout/file goldens.

| Phase | Lython | CPython | Lython / CPython | L/P process spread | Max IQR |
| --- | ---: | ---: | ---: | ---: | ---: |
'''+ '\n'.join(detail)+f'''

All four process-median pairings, not confidence intervals. Two jobs**{d['elapsedSeconds']:.3f}s**,
two processes/engine,5s full-request warmups and five rotated approximately0.5s
batches. All image/catalog/golden/budget/quiet/Closed/exit/join/archive gates pass.

**Important unresolved comparison:** CPython warm is about0.50ms here versus
0.73ms in [B823](../2026-11-16-normalization-cpython-checkpoint/README.md); fresh
about0.59ms versus0.83ms. Wider CPU also changes. Worker SHA, CPython executable
SHA/build/flags, timing-boundary string and every case field are identical. Current
catalog loads4cases versus1previously; this process-initialization difference is
not isolated as the cause. Within-run controls/IQRs are stable, but exact ratios
are collection-specific. Preserve both results; do not infer a Lython regression,
causal gain or recovered debt from cross-collection ratios. The current material
gap is real within this measurement boundary; its magnitude remains uncertain.
Any follow-up must control catalog/process initialization or another concrete
changed condition; no automatic ban on bounded confirmation or repeated campaign.

Separate retained [bulk-text](../2026-11-16-bulk-text-construction/refined/README.md)
and [line-construction](../2026-11-16-line-construction/confirmation/README.md)
source pairs establish their own allocation/CPU/removal evidence. They cannot be
added or inferred from this external table. Broader performance work remains open.

Quiet Azure F4as_v7/Ubuntu24.04.4,four EPYC9V45 vCPUs,16GiB/no swap,.NET11RC3
ordinary tiering/natural workstation GC and CPython GIL/GC. Warm includes mediated
RAM I/O, full stdout/file goldens and prior-result cleanup; excludes compilation/
startup, reset/protocol and final cache teardown. Fresh adds compilation/compiled-
owner disposal. Wider CPU includes reset/protocol; separate medians are not additive.
Native CPython buffered files do not provide equivalent containment. No startup,
pending-I/O, heap/RSS, contention or embedding-tail comparison.

Original staging failed the unchanged disk floor before mutation/workers. Retired
only two exact archived old-catalog aliases and redundant B828working evidence
after fresh idle-lease path/ownership/hash/all-alias checks. An own-parent pgrep
guard correction is preserved. Current images/toolchains and254/252MiB floors
remain. Full traces archived/verified persistently under lease before RAM unmount;
no workers/fixtures remain. Terminal cached. No new framework or runtime edit.

[All controls](summary.json),[identity review](identity-review.json),
[raw observations](observations.tgz),[procedure/inputs/source proof/original conditions](procedure-and-inputs.tar.xz),
[previous guide](prior-BENCHMARKS.md).
''',encoding='utf-8',newline='\n')
p=Path('docs/BENCHMARKS.md');s=p.read_text(encoding='utf-8');s='\n'.join(line for line in s.splitlines()if not line.startswith('| File normalization /'))+'\n';needle='| --- | --- | ---: | ---: | ---: | --- |';s=s.replace(needle,needle+'\n'+'\n'.join(rows),1)
a=s.index('**File normalization:');b=s.index('**Patch phases and CSV warm:',a)
s=s[:a]+'''**File normalization: 86d9344e /measured ecd9e956**,2026-11-16UTC;
[current warm/fresh checkpoint](../benchmarks/results/2026-11-16-line-cpython-checkpoint/README.md)
passes all measurement/cleanup gates; full runtime qualification is pending.
Warm is2.28–2.34×CPython, fresh2.05–2.10×. **Uncertainty:** CPython is markedly
faster than in the [previous same-case collection](../benchmarks/results/2026-11-16-normalization-cpython-checkpoint/README.md),
despite identical worker/binary/flags/case bytes; catalog initialization differs and
its effect is unisolated. Exact ratios are diagnostic and collection-specific;
this does not establish a Lython regression or causal source gain.

'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');s+='\n\n[R432/B829 current normalization CPython checkpoint](results/2026-11-16-line-cpython-checkpoint/README.md):86d9344e/ecd9e956 versusCPython3.13.16;2jobs70.938s/all gates. Warm2.28–2.34×,fresh2.05–2.10×. CPython shifts0.73→0.50ms warm/0.83→0.59msfresh despite identical worker/binary/flags/case fields;4-case versus1-case catalog initialization not isolated. Current controls/IQRstable; keep bothcollections/no causal cross-collection claims. Full43805966777active, broader objective open.\n';p.write_text(s,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');a=s.index('2. **R432 refreshed CPython phases.**');b=s.index('3. **Resume substantial',a)
s=s[:a]+'''2. **R432 external refresh complete; cross-collection uncertainty explicit.**
   [B829](benchmarks/results/2026-11-16-line-cpython-checkpoint/README.md): current
   86d9344e/ecd9 versusCPython3.13.16,70.938s/all gates. Warm2.28–2.34×,
   fresh2.05–2.10×; stable within-run controls/IQR. CPython is0.50mswarm/0.59ms
   fresh versusprior0.73/0.83ms. Worker/executable/build/flags/case fields identical;
   catalog initialization differs4versus1cases, effect not isolated. Both originals
   preserved; no inference of a Lython regression or causal gains across collections.
   Measurement gap is now precise, not a failed design: a future bounded confirmation
   must control catalog/process initialization or another identified condition.
   Do not repeat unchanged correctness qualification or launch a broad campaign.
   This uncertainty does not stop independent runtime work or adapter development.

'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
print('\n'.join(rows));print('Current source/CPython phases and identity uncertainty archived; older results preserved.')
