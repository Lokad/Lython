from pathlib import Path
import gzip, hashlib, json, os, shutil, statistics, subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.parent / "regex-provider-state-20261122/comparison"
catalog = prior / "catalog.json"
out = lab / "comparison"
out.mkdir(exist_ok=True)

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def write(path, value):
    path.write_text(json.dumps(value, indent=2)+"\n", encoding="utf-8", newline="\n")

def sha(path):
    return hashlib.file_digest(path.open("rb"), "sha256").hexdigest()

sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk),
         PATH=str(sdk)+os.pathsep+os.environ["PATH"])
protocol=repo/"benchmarks/cpython-worker.py"
up=read(prior/"images.json")
assert sha(catalog)==up["catalogSHA256"] and sha(protocol)==up["protocolSHA256"]
donor=prior/"frozen-candidate"
assert len(up["imageFiles"]["candidate"])==32
assert {n:sha(donor/n) for n in up["imageFiles"]["candidate"]}==up["imageFiles"]["candidate"]
allocation=lab.parent/"deferred-word-binding-20261122/comparison/frozen-reference"
adapter="Lokad.Lython.Utf8Regex.dll"
core="Lokad.Lython.dll"
ref=lab.parent/"regex-adapter-window-admission-20261122/windows/bin/Lokad.Lython.PublicApi.Tests/release_net11.0"
cand=repo/"tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0"
names=(core,adapter,"Lokad.Utf8Regex.dll","Lokad.Utf8Regex.PythonRe.dll")
for name in names:
    if name != core:
        assert (sha(ref/name)==sha(cand/name)) == (name!=adapter), name
    if name.startswith("Lokad.Utf8Regex."):
        assert sha(cand/name)==up["imageFiles"]["candidate"][name], name

results = {}
manifests = {}
patch = subprocess.check_output(["git","diff","--binary","HEAD","--","src"],cwd=repo)
assert patch.count(b"diff --git ")==1 and b"src/Lokad.Lython.Utf8Regex/Utf8RegexProvider.cs" in patch
(out/"source.patch").write_bytes(patch)
assert not subprocess.check_output(["git","diff","--name-only","da388dc30","HEAD","--","src"],cwd=repo)
for role,supplied in (("reference",ref),("candidate",cand)):
    image=out/("frozen-"+role)
    image.mkdir(exist_ok=True)
    def origin(name):
        if name==core:
            return ref/name
        return (supplied if name in names else donor)/name
    for name in up["imageFiles"]["candidate"]:
        shutil.copyfile(origin(name),image/name)
    manifest={name:sha(image/name) for name in up["imageFiles"]["candidate"]}
    for name in up["imageFiles"]["candidate"]:
        assert manifest[name]==sha(origin(name))
    manifests[role]=manifest
    for suffix in (".dll",".deps.json",".runtimeconfig.json"):
        name="ValidatedAllocation"+suffix
        shutil.copyfile(allocation/name,image/name)
    receipt=out/(role+"-verify.json")
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog,
                    "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",receipt],
                   env=env,cwd=repo,check=True,timeout=90)
    observed=read(receipt)
    assert observed["state"]=="Completed" and observed["caseCount"]==5 and observed["catalogSha256"]==sha(catalog)
    report=out/(role+"-allocation.json")
    subprocess.run([dotnet,image/"ValidatedAllocation.dll",image,catalog,report],
                   env=env,cwd=repo,check=True,timeout=85)
    rows=read(report)["rows"]
    assert len(rows)==5 and all(r["sharedBudgetBaselineRestored"] for r in rows)
    results[role]=rows
    assert {name:sha(image/name) for name in manifest}==manifest
    data=(image/adapter).read_bytes()
    (out/(role+"-adapter.dll.gz")).write_bytes(gzip.compress(data,compresslevel=9,mtime=0))

assert [n for n in manifests["reference"] if manifests["reference"][n]!=manifests["candidate"][n]]==[adapter]
shutil.copyfile(catalog,out/"catalog.json")
revision=subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip()
assert revision.startswith("97ccf8fbf")
write(out/"images.json", dict(referenceRevision=revision,
    referenceAdapterSourceRevision="da388dc30", commonCoreSourceRevision="da388dc30",
    candidateTestCoreSha256=sha(cand/core), imageFiles=manifests,
    sourcePatchSHA256=sha(out/"source.patch"), catalogSHA256=sha(catalog), protocolSHA256=sha(protocol)))
for a,b in zip(results["reference"],results["candidate"],strict=True):
    assert a["id"]==b["id"]
    x,y=[statistics.median(r["allocatedBytesPerInvocation"]) for r in (a,b)]
    print(a["id"],x,y,round(100*(y/x-1),3),a["peakExecutionMemoryBytes"],b["peakExecutionMemoryBytes"],flush=True)
