from pathlib import Path
import ast,datetime,hashlib,json,shlex,shutil,subprocess,tarfile
h=Path(__file__).parent/'report-construction-r195';h.mkdir(exist_ok=True);p=h/'b543';p.mkdir(exist_ok=True)
repo=Path('D:/code/Lython');old=h.parent/'prefix-attribution-r193/b541'
source=(old/'ops-profile.py').read_text(encoding='utf-8')
source=source.replace('prefix-code-b541-20261110','report-assessment-b543-20261110').replace('lython-b541','lython-b543')
source=source.replace('import select\n','import select\nimport signal\n',1)
source=source.replace('ticks = os.sysconf',"def stop(*_):raise InterruptedError('Owned assessment stopped; join users before cleanup.')\nsignal.signal(signal.SIGTERM,stop)\n\nticks = os.sysconf",1)
needle='for name, case_id, lane in [("csv-warm", "scripts.csv-validated-records.large", "warm"), ("text-warm", "scripts.text-summary-helpers.large", "warm")]:'
replacement='for name, case_id, lane in [("report-warm", "scripts.report-render.large", "warm"), ("report-compile", "scripts.report-render.large", "compile"), ("config-warm", "scripts.config-edit.small", "warm"), ("config-compile", "scripts.config-edit.small", "compile")]:'
assert needle in source;source=source.replace(needle,replacement)
start=source.index('        env["DOTNET_JitDisasm"]')
end=source.index('        worker = ',start)
source=source[:start]+source[end:]
source=source.replace('count = 64  # Batch complete invocations to keep IPC outside guest attribution.',
 'count = 4096 if lane == "compile" else 2048 if "config" in name else 64 # Sized for six seconds within the existing64warmup bound.')
source=source.replace('["DOTNET_PerfMapEnabled","DOTNET_JitDisasm","DOTNET_JitDisasmWithCodeBytes","DOTNET_JitStdOutFile"]','["DOTNET_PerfMapEnabled"]')
source=source.replace("{'DOTNET_PerfMapEnabled','DOTNET_JitDisasm','DOTNET_JitDisasmWithCodeBytes','DOTNET_JitStdOutFile'}","{'DOTNET_PerfMapEnabled'}")
source=source.replace('result = request("batch", 128)','result = request("batch", count)')
source=source.replace('if total_capture_seconds > 20:', 'if total_capture_seconds > 32:')
source=source.replace("guest = [row for row in record['threadCpuSeconds'] if row['seconds'] > .25 and row['name'].startswith('Lython executio')]",
 "guest = [row for row in record['threadCpuSeconds'] if row['seconds'] > .25 and (row['tid'] == str(process.pid) if lane == 'compile' else row['name'].startswith('Lython executio'))]")
assert 'b541'not in source and 'JitDisasm'not in source
ast.parse(source);(p/'ops-profile.py').write_text(source,encoding='utf-8',newline='\n')
shutil.copyfile(old/'analyze-cpu-guest.py',p/'analyze-cpu-guest.py')
catalog=json.loads((h.parent/'agent-workloads-r130/representative.json').read_text(encoding='utf-8'))
selected=[c for c in catalog['cases']if c['id']=='scripts.config-edit.small']
report_catalog=json.loads((h.parent/'native-dictionary-accumulation-r190/diagnostic/catalog.json').read_text(encoding='utf-8'))
selected.extend(c for c in report_catalog['cases']if c['id']=='scripts.report-render.large')
assert len(selected)==2,[c['id']for c in catalog['cases']]
catalog['cases']=selected
(p/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision='Qualified1a83c64f; main795bd907 only adds evidence. Frozenac6 normalized-source equivalent to all567production files.',
 catalogSHA256=hashlib.sha256((p/'catalog.json').read_bytes()).hexdigest(),diagnosticOverrides=['DOTNET_PerfMapEnabled=3'])
(p/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
(p/'contract.md').write_text('''# R195 bounded report/configuration construction attribution

Qualified1a83c64f/ac6, source unchanged. Existing complete report-render.large and
config-edit.small scripts, same inputs/goldens; CPython measurements remain the
published historical checkpoint, not refreshed by these profiles.

Four existing-worker captures: report/config warm and compilation separately,
six-second warmup plus six-second capture each. StockGC/tiering plus explicit
perf-map diagnostics. Count4096compile,2048configwarm,64reportwarm allows usable
observations within the existing64warmup-batch bound. Owner120s/stop30/margin30;
aggregate capture32smaximum. Frame/read bounds and all existing checks preserved.
No timing comparison, new benchmark framework or runtime policy.

Warm clocks include mediatedRAMI/O, complete output checks and prior-result cleanup;
fixture reset excluded by existingworker. Compilation includes construction and
prior-script disposal. Wider captured processCPU includes reset/protocol/validation,
GC/JIT; attribute actual guest runtime threads separately from compile main thread.
Keep all threadCPU, raw stacks and unknowns. No percentage/removable-tax forecast.

Source gate: JSON already uses a completed-child ordinary loop, direct finalUTF8
string decoding; CSV adopts owned row arrays/shared keys; prepared physicaloperand
slots already exist. Select different material duplicate construction/representation,
or reject that source hypothesis and advance to the next evidenced roadmap cost.
Any selected redesign must name code removed, semantic/cancellation/terminalrefusal/
ownership acceptance and bounded complete-script controls before implementation.

Archive/join/cleanup/SHA before retiringRAM; retain all failed/partial conditions.
No unsafe productioncode, quotas, tracing, new memoryinfrastructure or publication.
Regex development remains independent.
''',encoding='utf-8',newline='\n')
archive=(old/'archive.py').read_text(encoding='utf-8').replace('prefix-code-b541-20261110','report-assessment-b543-20261110').replace('lython-b541','lython-b543')
archive=archive.replace("['csv-warm','text-warm']","['report-warm','report-compile','config-warm','config-compile']")
archive=archive.replace(" assert (p/'prefix-jit.txt').stat().st_size>0\n",'')
archive=archive.replace('assert seconds<20','assert seconds<32')
archive=archive.replace('with tarfile.open(r/\'observations.tgz\')as a:', "assert shutil.disk_usage(r).free>240*1024*1024\nwith tarfile.open(r/'observations.tgz')as a:")
ast.parse(archive);(p/'archive.py').write_text(archive,encoding='utf-8',newline='\n')
run=(old/'run.sh').read_text(encoding='utf-8').replace('prefix-code-b541-20261110','report-assessment-b543-20261110').replace('lython-b541-prefix-code-20261110','lython-b543-report-assessment-20261110').replace('lython-b541','lython-b543')
run=run.replace('csv-warm text-warm','report-warm report-compile config-warm config-compile')
(p/'run.sh').write_text(run,encoding='utf-8',newline='\n')
with tarfile.open(p/'payload.tgz','w:gz')as a:
 for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','identity.json','catalog.json','contract.md']:a.add(p/name,arcname=name)
payload=(p/'payload.tgz').read_bytes()
canonical=repo/'benchmarks/results/2026-11-10-continuous-prefix/observations.tgz'
receipt=json.loads((canonical.parent/'archive-receipt.json').read_text(encoding='utf-8'))
assert hashlib.sha256(canonical.read_bytes()).hexdigest()==receipt['archiveSHA256']
with tarfile.open(canonical)as a:
 withdrawn=a.extractfile('current-core.dll').read();assert hashlib.sha256(withdrawn).hexdigest()=='8f24bf388a3d21f3f29e934291ca718e1c079b5cd4fdca011366e8773ffdd8d9'
copies=[dict(path='prefix-confirm-b542-20261110/observations.tgz',bytes=canonical.stat().st_size,sha256=receipt['archiveSHA256'],canonical=str(canonical.relative_to(repo)))]
required=(240+12)*1024*1024+len(payload)*3
script=r'''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks').resolve();root=base/'report-assessment-b543-20261110'
source=base/'prefix-code-b541-20261110/candidate';fixture=Path('/dev/shm/lython-b543')
copies=COPIES
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists()and not fixture.exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[c]omplete-jobs.dll'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 payload=sys.stdin.buffer.read(SIZEPLUS);assert len(payload)==SIZE and hashlib.sha256(payload).hexdigest()=='PAYLOADSHA'
 assert hashlib.sha256((source/'Lokad.Lython.dll').read_bytes()).hexdigest()=='ac6edb6fc361dba9195d973830a5ca02caac10b62cc6d041f134ce31ef9a10d3'
 before=shutil.disk_usage(base).free;retire=[];withdrawnAliases=[];reclaim=0
 if before<=REQUIRED:
  for c in copies:
   path=base/c['path'];s=path.lstat();assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_nlink==1
   assert s.st_size==c['bytes']and hashlib.sha256(path.read_bytes()).hexdigest()==c['sha256']
   reclaim+=s.st_blocks*512;retire.append(dict(c,allocatedBytes=s.st_blocks*512))
  core=base/'prefix-confirm-b542-20261110/current-core.dll';s=core.lstat()
  assert stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and hashlib.sha256(core.read_bytes()).hexdigest()=='8f24bf388a3d21f3f29e934291ca718e1c079b5cd4fdca011366e8773ffdd8d9'
  matches=subprocess.check_output(['find',str(base),'-xdev','-samefile',str(core),'-type','f'],text=True).splitlines()
  assert len(matches)==s.st_nlink
  for name in matches:
   path=Path(name);assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(path.lstat().st_mode)and path.stat().st_uid==os.getuid()
  withdrawnAliases=matches;reclaim+=s.st_blocks*512
  assert before+reclaim>REQUIRED,(before,reclaim,REQUIRED)
  for name in matches:Path(name).unlink()
  for c in copies:(base/c['path']).unlink()
 assert shutil.disk_usage(base).free>REQUIRED
 recovery=dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,files=retire,withdrawn8fAliases=withdrawnAliases,
  canonical='benchmarks/results/2026-11-10-continuous-prefix/observations.tgz:current-core.dll',freshIdleLease=True,qualifiedac6Preserved=True)
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:root.mkdir();a.extractall(root,filter='data')
 (root/'space-recovery.json').write_text(json.dumps(recovery,indent=2)+'\n')
 os.link(source/'Lokad.Lython.dll',root/'current-core.dll');shutil.copytree(source,root/'candidate',copy_function=os.link)
 identity=json.loads((root/'identity.json').read_text())
 for name,digest in {**identity['auxiliaryFiles'],'Lokad.Lython.dll':identity['coreSHA256']}.items():assert hashlib.sha256((root/'candidate'/name).read_bytes()).hexdigest()==digest,name
 for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b543-fixtures',str(fixture)],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndAuxiliaryImagesVerified=True,captures=4,ownerSeconds=120,stopSeconds=30,marginSeconds=30,performanceQualified=False)
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
try:
 subprocess.run(['sudo','-n','systemd-run','--unit=lython-b543-report-assessment-20261110','--property=User=lokad','--property=WorkingDirectory='+str(root),
  '--property=RuntimeMaxSec=120','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show','lython-b543-report-assessment-20261110.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert 'ActiveState=active'in live and'MainPID=0'not in live;print(live,flush=True)
'''.replace('COPIES',repr(copies)).replace('SIZEPLUS',str(len(payload)+1)).replace('SIZE',str(len(payload))).replace('PAYLOADSHA',hashlib.sha256(payload).hexdigest()).replace('REQUIRED',str(required))
ast.parse(script);(p/'launch-command.py').write_text(script,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
stage='/home/lokad/lython-bench-checks/report-assessment-b543-launch.py'
code='from pathlib import Path;import sys;p=Path('+repr(stage)+');assert not p.exists();p.write_bytes(sys.stdin.buffer.read())'
done=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=script.encode('utf-8'),capture_output=True);assert done.returncode==0,done.stderr
done=subprocess.run(ssh+['python3 '+stage],input=payload,capture_output=True)
(p/'launch.log').write_bytes(done.stdout+b'\n'+done.stderr);assert done.returncode==0,done.stderr.decode('utf-8')
assert b'ActiveState=active'in done.stdout and b'MainPID=0'not in done.stdout
now=datetime.datetime.now(datetime.timezone.utc)
(p/'observe-not-before.json').write_text(json.dumps(dict(acknowledgedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=180)).isoformat(),ownerSeconds=120,stopSeconds=30,marginSeconds=30),indent=2)+'\n',encoding='utf-8')
print(done.stdout.decode('utf-8'),flush=True);print('Observe after',(now+datetime.timedelta(seconds=180)).isoformat(),flush=True)
