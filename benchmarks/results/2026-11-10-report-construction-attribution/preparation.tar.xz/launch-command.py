from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks').resolve();root=base/'report-assessment-b543-20261110'
source=base/'prefix-code-b541-20261110/candidate';fixture=Path('/dev/shm/lython-b543')
copies=[{'path': 'prefix-confirm-b542-20261110/observations.tgz', 'bytes': 3843515, 'sha256': 'd2bcb3ea7f2e3895a8d0b7eba827285aac0f35b62fe46d2b8a0c2928ede30433', 'canonical': 'benchmarks\\results\\2026-11-10-continuous-prefix\\observations.tgz'}]
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists()and not fixture.exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[c]omplete-jobs.dll'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 payload=sys.stdin.buffer.read(14690);assert len(payload)==14689 and hashlib.sha256(payload).hexdigest()=='288dbdb586f2c6823cd1944b8f4fa126714a5dba80f1644502c417377be9830f'
 assert hashlib.sha256((source/'Lokad.Lython.dll').read_bytes()).hexdigest()=='ac6edb6fc361dba9195d973830a5ca02caac10b62cc6d041f134ce31ef9a10d3'
 before=shutil.disk_usage(base).free;retire=[];withdrawnAliases=[];reclaim=0
 if before<=264285219:
  for c in copies:
   path=base/c['path'];s=path.lstat();assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_nlink==1
   assert s.st_size==c['bytes']and hashlib.sha256(path.read_bytes()).hexdigest()==c['sha256']
   reclaim+=s.st_blocks*512;retire.append(dict(c,allocatedBytes=s.st_blocks*512))
  core=base/'prefix-confirm-b542-20261110/current-core.dll';s=core.lstat()
  assert stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and hashlib.sha256(core.read_bytes()).hexdigest()=='8f24bf388a3d21f3f29e934291ca718e1c079b5cd4fdca011366e8773ffdd8d9'
  matches=subprocess.check_output(['find',str(base),'-xdev','-samefile',str(core),'-type','f'],text=True).splitlines()
  assert len(matches)==s.st_nlink
  for name in matches:
   path=Path(name);assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(path.lstat().st_mode)and path.stat().st_uid==os.getuid()
  withdrawnAliases=matches;reclaim+=s.st_blocks*512
  assert before+reclaim>264285219,(before,reclaim,264285219)
  for name in matches:Path(name).unlink()
  for c in copies:(base/c['path']).unlink()
 assert shutil.disk_usage(base).free>264285219
 recovery=dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,files=retire,withdrawn8fAliases=withdrawnAliases,
  canonical='benchmarks/results/2026-11-10-continuous-prefix/observations.tgz:current-core.dll',freshIdleLease=True,qualifiedac6Preserved=True)
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:root.mkdir();a.extractall(root,filter='data')
 (root/'space-recovery.json').write_text(json.dumps(recovery,indent=2)+'\n')
 os.link(source/'Lokad.Lython.dll',root/'current-core.dll');shutil.copytree(source,root/'candidate',copy_function=os.link)
 identity=json.loads((root/'identity.json').read_text())
 for name,digest in {**identity['auxiliaryFiles'],'Lokad.Lython.dll':identity['coreSHA256']}.items():assert hashlib.sha256((root/'candidate'/name).read_bytes()).hexdigest()==digest,name
 for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b543-fixtures',str(fixture)],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndAuxiliaryImagesVerified=True,captures=4,ownerSeconds=120,stopSeconds=30,marginSeconds=30,performanceQualified=False)
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
try:
 subprocess.run(['sudo','-n','systemd-run','--unit=lython-b543-report-assessment-20261110','--property=User=lokad','--property=WorkingDirectory='+str(root),
  '--property=RuntimeMaxSec=120','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show','lython-b543-report-assessment-20261110.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert 'ActiveState=active'in live and'MainPID=0'not in live;print(live,flush=True)
