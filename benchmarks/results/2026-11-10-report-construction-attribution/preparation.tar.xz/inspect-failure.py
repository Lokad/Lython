from pathlib import Path
import json,subprocess
r=Path(__file__).parent
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
script='''from pathlib import Path
import fcntl,json,subprocess
r=Path('/home/lokad/lython-bench-checks/report-assessment-b543-20261110')
with(r.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 journal=subprocess.run(['sudo','-n','journalctl','-u','lython-b543-report-assessment-20261110.service','--no-pager','-n','65'],capture_output=True,text=True)
 records={str(p.relative_to(r)):json.loads(p.read_text())for p in r.glob('profiles/*/record.json')}
 files=[dict(path=str(p.relative_to(r)),bytes=p.stat().st_size)for p in r.glob('profiles/*/*')if p.is_file()]
 print(json.dumps(dict(journal=journal.stdout,journalError=journal.stderr,records=records,files=files,fixtureFiles=[str(p)for p in Path('/dev/shm/lython-b543').rglob('*')],
  workers=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True,text=True).stdout)))
'''
done=subprocess.run(ssh+['python3 -'],input=script,text=True,encoding='utf-8',capture_output=True)
assert done.returncode==0,done.stderr
(r/'failure-inspection.json').write_text(done.stdout,encoding='utf-8',newline='\n')
data=json.loads(done.stdout)
print(data['journal'])
for name,record in data['records'].items():print(name,'exit',record.get('exitCode'),'warmup',record.get('warmupSeconds'),'has capture','response'in record)
print('remaining workers',data['workers'],'fixtures',data['fixtureFiles'])
