from pathlib import Path
from statistics import median
from difflib import unified_diff
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
root=lab.parents[3]
source=lab/'source'
head=(lab/'base-revision.txt').read_text(encoding='utf-8').strip()
reference=lab.with_name('starmap-direct-sequence-packet-20261126')
candidate=lab/'windows/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'
local=lab/'local'
core=candidate.name
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=lambda p:{f.name:sha(f) for f in p.iterdir()}
save=lambda p,d:p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n')
for output,files in [('candidate.patch',[
    'src/Lokad.Lython/Frontend/ExecutableScript.cs',
    'src/Lokad.Lython/Frontend/ExecutableScript.NativeSegments.cs',
    'src/Lokad.Lython/Frontend/ExecutableStackLayout.cs',
])]:
    patch=[]
    for name in files:
        base=subprocess.check_output(['git','show',head+':'+name],cwd=root).decode('utf-8')
        after=(source/name).read_text(encoding='utf-8')
        assert after!=base
        patch.append(f'diff --git a/{name} b/{name}\n')
        patch.extend(unified_diff(base.splitlines(keepends=True),after.splitlines(keepends=True),
                                  fromfile='a/'+name,tofile='b/'+name))
    (lab/output).write_text(''.join(patch),encoding='utf-8',newline='\n')
    subprocess.run(['git','apply','--check',str(lab/output)],cwd=root,check=True)
old=read(reference/'comparison/quiet/identity.json')
frozen=reference/'local/candidate'
assert len(old['imageFiles']['candidate'])==32 and manifest(frozen)==old['imageFiles']['candidate']
assert sha(reference/'candidate.patch')==old['sourcePatchSHA256']
ready=subprocess.check_output(['git','diff','--name-only',old['sourceRevision'],head,'--','src'],cwd=root,text=True).splitlines()
assert ready==['src/Lokad.Lython/Runtime/PyItertools.Transforms.cs']
for file in ready:
    active=subprocess.check_output(['git','show',head+':'+file],cwd=root).decode('utf-8')
    assert active==(reference/'source'/file).read_text(encoding='utf-8')
local.mkdir()
images={}
for role in ('reference','candidate'):
    folder=local/role
    shutil.copytree(frozen,folder)
    if role=='candidate':shutil.copyfile(candidate,folder/core)
    images[role]=manifest(folder)
assert [n for n,h in images['reference'].items() if h!=images['candidate'][n]]==[core]
original=lab/'representative.json'
shutil.copyfile(original,local/'representative.json')
shutil.copyfile(reference/'local/cpython-worker.py',local/'cpython-worker.py')
assert sha(local/'cpython-worker.py')==old['cpythonWorkerSHA256']
identity=dict(sourceRevision=head,sourcePatchSHA256=sha(lab/'candidate.patch'),imageFiles=images,
              catalogSHA256=sha(local/'representative.json'),cpythonWorkerSHA256=old['cpythonWorkerSHA256'])
save(local/'identity.json',identity)
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
tool=lab.with_name('json-traversal-20261124')/'reference'
values={}
for role,h in images.items():
    image=local/role
    check=lab/(role+'-verify.json')
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',
        local/'representative.json','--dotnet',dotnet,'--python','C:/Python313/python.exe',
        '--python-worker',local/'cpython-worker.py','--out',check],cwd=root,env=env,
        check=True,timeout=92)
    proof=read(check)
    assert proof['state']=='Completed' and proof['caseCount']==5
    assert proof['catalogSha256']==identity['catalogSHA256']
    assert proof['launched']['library']['sha256']==h[core]
    allocation=lab/(role+'-allocated')
    shutil.copytree(image,allocation)
    for f in tool.glob('ValidatedAllocation*'):shutil.copyfile(f,allocation/f.name)
    out=lab/(role+'-allocation.json')
    subprocess.run([dotnet,allocation/'ValidatedAllocation.dll',allocation,local/'representative.json',out],
                   cwd=root,env=env,check=True,timeout=90)
    values[role]=read(out)['rows']
rows=[]
for before,after in zip(values['reference'],values['candidate'],strict=True):
    assert before['id']==after['id'] and before['sharedBudgetBaselineRestored'] and after['sharedBudgetBaselineRestored']
    rows.append(dict(case=before['id'],allocatedBytes=[median(r['allocatedBytesPerInvocation']) for r in (before,after)],
                     peak=[r['peakExecutionMemoryBytes'] for r in (before,after)],
                     compiledReservedBytes=[r['compiledReservedBytes'] for r in (before,after)]))
save(lab/'allocation-summary.json',rows)
print(json.dumps(rows))
