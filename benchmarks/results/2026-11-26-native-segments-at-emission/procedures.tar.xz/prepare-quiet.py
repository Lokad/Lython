from pathlib import Path
import hashlib, json, shutil, tarfile

lab=Path(__file__).resolve().parent
donor=lab.with_name('starmap-direct-sequence-packet-20261126')
local=lab/'local'
quiet=lab/'comparison/quiet'
previous=lab.with_name('json-single-string-pass-20261126')
quiet.mkdir(parents=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,t:p.write_text(t,encoding='utf-8',newline='\n')
save=lambda p,o:write(p,json.dumps(o,indent=2)+'\n')
def edit(s,replacements):
    for old,new in replacements:
        assert s.count(old)==1,old
        s=s.replace(old,new)
    return s

for name in ('representative.json','cpython-worker.py'):
    shutil.copyfile(local/name,quiet/name)
shutil.copyfile(donor/'comparison/quiet/run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
identity=read(local/'identity.json')
original=read(donor/'comparison/quiet/identity.json')
assert original['imageFiles']['candidate']==identity['imageFiles']['reference']
assert identity['catalogs']['representative.json']['sha256']==sha(quiet/'representative.json')
assert identity['cpythonWorkerSHA256']==sha(quiet/'cpython-worker.py')
assert identity['sourcePatchSHA256']==sha(lab/'candidate.patch')
for role,files in identity['imageFiles'].items():
    assert len(files)==32 and {p.name:sha(p) for p in (local/role).iterdir()}==files
    verify=read(lab/(role+'-verify.json'))
    assert verify['caseCount']==5 and verify['state']=='Completed'
    assert verify['catalogSha256']==sha(quiet/'representative.json')
    assert verify['launched']['library']['sha256']==files['Lokad.Lython.dll']
jobs=read(local/'jobs.json')
jobs['warm']=[jobs['warm'][4],jobs['warm'][3],jobs['warm'][1],jobs['warm'][0]]
save(quiet/'jobs.json',jobs)
identity['catalogs']['jobs.json']['sha256']=sha(quiet/'jobs.json')
save(quiet/'identity.json',identity)
collector=edit((previous/'comparison/quiet/collect.py').read_text(encoding='utf-8'),[
    ('lython-b1796-fixtures','lython-b1800-fixtures'),
])
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
names=('identity.json','jobs.json','representative.json','collect.py','run.sh','cpython-worker.py')
package=quiet/'stage.tar.gz'
with tarfile.open(package,'w:gz',compresslevel=6) as blob:
    for name in names:blob.add(quiet/name,arcname=name,recursive=False)
donor_quiet=donor/'comparison/quiet'
receipt=read(donor_quiet/'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['archiveSHA256']==sha(donor_quiet/'observations.tar.xz')
core=local/'candidate/Lokad.Lython.dll'
save(quiet/'upload.json',dict(root='native-segments-at-emission-b1800-20261126',
    payloadSHA256=sha(package),payloadBytes=package.stat().st_size,
    expandedBytes=sum((quiet/name).stat().st_size for name in names),
    coreBytes=core.stat().st_size,coreSHA256=sha(core),minimumAfterStageBytes=7_500_000,
    donorSHA256=receipt['archiveSHA256']))
launcher=(previous/'quiet.py').read_text(encoding='utf-8')
launcher=edit(launcher,[
    ('lython-b1796-json-single-string-pass-20261126','lython-b1800-native-segments-at-emission-20261126'),
])
compile(launcher,'quiet.py','exec')
write(lab/'quiet.py',launcher)

print(read(quiet/'upload.json'))
