from pathlib import Path

lab=Path(__file__).resolve().parent
previous=lab.with_name('direct-map-result-handoff-20261126')

def edit(source, replacements):
    for old,new in replacements:
        assert source.count(old)==1,old
        source=source.replace(old,new)
    return source

def read(root,name):
    return (root/name).read_text(encoding='utf-8')

def write(name,source):
    compile(source,name,'exec')
    (lab/name).write_text(source,encoding='utf-8',newline='\n')

source=edit(read(previous,'prepare-quiet.py'),[
    ("verify['caseCount']==3","verify['caseCount']==5"),
    ("jobs['warm']=[jobs['warm'][2],jobs['warm'][4],jobs['warm'][0]]","jobs['warm']=[jobs['warm'][4],jobs['warm'][3],jobs['warm'][1],jobs['warm'][0]]"),
    ("    ('lython-b1796-fixtures','lython-b1799-fixtures'),\n    ('len(jobs) == 4','len(jobs) == 3'),",
     "    ('lython-b1796-fixtures','lython-b1800-fixtures'),"),
    ("root='direct-map-result-handoff-b1799-20261126'","root='native-segments-at-emission-b1800-20261126'"),
    ("minimumAfterStageBytes=8_000_000","minimumAfterStageBytes=7_500_000"),
    ("('lython-b1796-json-single-string-pass-20261126','lython-b1799-direct-map-result-handoff-20261126'),",
     "('lython-b1796-json-single-string-pass-20261126','lython-b1800-native-segments-at-emission-20261126'),"),
    ("    ('timedelta(seconds=166)','timedelta(seconds=137)'),\n",""),
    ("    (\"verified['caseCount']==5\",\"verified['caseCount']==3\"),\n",""),
])
write('prepare-quiet.py',source)
reference=lab.with_name('json-single-string-pass-20261126')
write('summarize-quiet.py',read(reference,'summarize-quiet.py'))
preserve=edit(read(previous,'preserve-core.py'),[
    ("source='json-single-string-pass-20261126'","source='direct-map-result-handoff-20261126'"),
    ("'2026-11-26-json-single-string-pass'","'2026-11-26-direct-map-result-handoff'"),
])
write('preserve-core.py',preserve)
