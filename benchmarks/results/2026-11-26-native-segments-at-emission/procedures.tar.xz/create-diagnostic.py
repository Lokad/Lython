from pathlib import Path
import json

lab=Path(__file__).resolve().parent
before=lab.with_name('direct-map-result-handoff-20261126')
definitions=lab.with_name('deferred-site-placement-20261126')/'local'
json_lab=lab.with_name('json-single-string-pass-20261126')/'local'

def read(path):
    return path.read_text(encoding='utf-8-sig')

def write(name,source):
    (lab/name).write_text(source,encoding='utf-8',newline='\n')

def edit(source, pairs):
    for old,new in pairs:
        assert source.count(old)==1,old
        source=source.replace(old,new)
    return source

source=edit(read(before/'prepare.py'),[
    ("'src/Lokad.Lython/Runtime/PyBuiltinIterators.cs',\n    'src/Lokad.Lython/Runtime/PyIteration.cs',\n    'src/Lokad.Lython/Runtime/LythonRuntime.BuiltinIterables.Aggregates.cs',",
     "'src/Lokad.Lython/Frontend/ExecutableScript.cs',\n    'src/Lokad.Lython/Frontend/ExecutableScript.NativeSegments.cs',\n    'src/Lokad.Lython/Frontend/ExecutableStackLayout.cs',"),
    ("]), ('regression.patch',['tests/Lokad.Lython.PublicApi.Tests/IteratorAdapterTests.cs'])]:","] )]:".replace(' ','')),
    ("proof['caseCount']==3","proof['caseCount']==5"),
])
compile(source,'prepare.py','exec')
write('prepare.py',source)
catalog=json.loads(read(definitions/'representative.json'))
text=json.loads(read(json_lab/'representative.json'))
case,= [c for c in text['cases'] if c['id']=='diagnostic.text-summary.nonlocal-computed-width.large']
catalog['cases'].append(case)
assert len(catalog['cases'])==5
write('representative.json',json.dumps(catalog,indent=2,ensure_ascii=False)+'\n')

source=edit(read(before/'prepare-local.py'),[
    ("prior=lab.with_name('direct-literal-keyword-metadata-20261126')/'local'","prior=lab.with_name('direct-map-result-handoff-20261126')/'local'"),
    ("    ['diagnostic.shipment-routing-callbacks','warm-async'],\n    ['diagnostic.shipment-file-fed-map','warm'],\n    ['scripts.file-search.large','warm'],\n    ['diagnostic.shipment-routing-callbacks','warm'],\n    ['diagnostic.shipment-file-fed-map','warm-async'],",
     "    ['diagnostic.generated-ordinary-definitions','compile'],\n    ['scripts.rule-default-closures','compile'],\n    ['diagnostic.text-summary.nonlocal-computed-width.large','warm'],\n    ['diagnostic.generated-ordinary-definitions','compile-run'],\n    ['scripts.file-search.large','warm'],"),
    ("Pass completed short map rows directly to nested maps and sum.","Prepare native arithmetic and dictionary segments at their final tape endings."),
    ("assert collector.count('lython-direct-literal-keyword-metadata-fixture-')==1","assert collector.count('lython-direct-map-result-handoff-fixture-')==1"),
    ("collector=collector.replace('lython-direct-literal-keyword-metadata-fixture-','lython-direct-map-result-handoff-fixture-')",
     "collector=collector.replace('lython-direct-map-result-handoff-fixture-','lython-native-segments-at-emission-fixture-')"),
    ("collector=collector.replace('len(jobs) == 4','len(jobs) == 5')\n",""),
    ("summary=(prior.parent/'summarize.py').read_text(encoding='utf-8').replace(\"receipt['warmJobs'] == 4\", \"receipt['warmJobs'] == 5\").replace(\"len(raw['jobs']) == 4\", \"len(raw['jobs']) == 5\").replace('timedBatches=112','timedBatches=140')",
     "summary=(prior.parent/'summarize.py').read_text(encoding='utf-8')"),
])
compile(source,'prepare-local.py','exec')
write('prepare-local.py',source)

additional=[
    ('closure-and-loop', '''
def histogram(words):
    counts = {}
    for word in words:
        counts[word] = counts.get(word, 0) + 1
    return counts

def with_total(words):
    counts, total = {}, 0
    for word in words:
        counts[word] = counts.get(word, 0) + 1
        total += 1
    return counts, total

def counter():
    total = 0
    def advance():
        nonlocal total
        total += 3
        return total
    return advance
print(histogram(['a','b','a']), with_total(['a','a']), counter()())
'''),
    ('protected-native-tails', '''
def summarize(rows):
    totals = {}
    try:
        for row in rows:
            service = row['service']
            totals[service] = totals.get(service, 0) + int(row['quantity'])
    finally:
        print('done')
    return totals

def conditional(words):
    counts = {}
    for value in words:
        try:
            counts[value] = counts.get(value, 0) + 1
        finally:
            pass
    return counts

def factory(value):
    def update():
        nonlocal value
        try:
            value += 1
        finally:
            pass
        return value
    return update
print(summarize([{'service':'a','quantity':'3'}]), conditional(['a']), factory(4)())
'''),
]
shipment=json.loads(read(before/'representative.json'))
extra={k:v for k,v in catalog.items() if k!='cases'}
extra['cases']=[{'id':key,'source':body.lstrip()} for key,body in additional]
extra['cases'].extend(c for c in shipment['cases'] if c['id'].startswith('diagnostic.'))
write('shape-cases.json',json.dumps(extra,indent=2,ensure_ascii=False)+'\n')
