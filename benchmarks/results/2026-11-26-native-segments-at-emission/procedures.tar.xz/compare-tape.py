from pathlib import Path
import hashlib
import json

lab = Path(__file__).resolve().parent
reference = (lab/'reference-tape.json').read_bytes()
candidate = (lab/'candidate-tape.json').read_bytes()
before,after = (json.loads(raw) for raw in (reference,candidate))
assert len(before) == len(after) == 9
for old,new in zip(before,after,strict=True):
    assert old['id'] == new['id']
    assert old['compileAdmissionBytes'] == new['compileAdmissionBytes'], old['id']
    assert len(old['codes']) == len(new['codes']), old['id']
    for previous,current in zip(old['codes'],new['codes'],strict=True):
        if previous != current:
            raise AssertionError((old['id'],previous['name'],[key for key in previous if previous[key]!=current[key]]))
assert reference == candidate
output=[]
for case in before:
    codes=case['codes']
    output.append(dict(case=case['id'], codeObjects=len(codes),
        instructionCount=sum(len(code['instructions']) for code in codes),
        removedScanSlots=sum(max(0,len(code['instructions'])-2) for code in codes),
        protectedRegions=sum(len(code['regions']) for code in codes),
        dictionaryCalls=sum(code['dictionaryCalls'] for code in codes),
        dictionaryLoops=sum(code['dictionaryLoops'] for code in codes),
        closureArithmetic=sum(code['closureArithmetic'] for code in codes),
        compileAdmissionBytes=case['compileAdmissionBytes']))
assert all(sum(row[key] for row in output) > 0 for key in
           ('closureArithmetic','dictionaryCalls','dictionaryLoops','protectedRegions'))
result=dict(byteIdentical=True, snapshotSHA256=hashlib.sha256(reference).hexdigest(), rows=output)
(lab/'tape-summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(result))
