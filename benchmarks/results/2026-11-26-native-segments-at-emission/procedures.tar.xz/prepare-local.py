from pathlib import Path
import hashlib,json,shutil

lab=Path(__file__).resolve().parent
local=lab/'local'
prior=lab.with_name('direct-map-result-handoff-20261126')/'local'
source=lab.with_name('starmap-direct-sequence-packet-20261126')/'comparison/quiet'
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
write=lambda path,data:path.write_text(data,encoding='utf-8',newline='\n')

identity=read(local/'identity.json')
previous=read(source/'identity.json')
assert identity['imageFiles']['reference']==previous['imageFiles']['candidate']
assert identity['catalogSHA256']==sha(local/'representative.json')
jobs={'warm': [
    ['diagnostic.generated-ordinary-definitions','compile'],
    ['scripts.rule-default-closures','compile'],
    ['diagnostic.text-summary.nonlocal-computed-width.large','warm'],
    ['diagnostic.generated-ordinary-definitions','compile-run'],
    ['scripts.file-search.large','warm'],
]}
write(local/'jobs.json',json.dumps(jobs,indent=2)+'\n')
identity['coreSHA256']={r+s:v['Lokad.Lython.dll'] for r,v in identity['imageFiles'].items() for s in ('','-control')}
identity['catalogs']={name:{'sha256':sha(local/name)} for name in ('representative.json','jobs.json')}
identity['expectedCPythonSHA256']=previous['expectedCPythonSHA256']
identity['purpose']='Prepare native arithmetic and dictionary segments at their final tape endings.'
write(local/'identity.json',json.dumps(identity,indent=2)+'\n')
collector=(prior/'collect.py').read_text(encoding='utf-8')
assert collector.count('lython-direct-map-result-handoff-fixture-')==1
collector=collector.replace('lython-direct-map-result-handoff-fixture-','lython-native-segments-at-emission-fixture-')
compile(collector,'collect.py','exec')
write(local/'collect.py',collector)
shutil.copyfile(prior/'run.sh',local/'run.sh')
assert b'\r' not in (local/'run.sh').read_bytes()
summary=(prior.parent/'summarize.py').read_text(encoding='utf-8')
write(lab/'summarize.py',summary)
