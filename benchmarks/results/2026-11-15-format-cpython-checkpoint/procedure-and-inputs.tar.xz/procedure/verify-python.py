from pathlib import Path
import io,json,os,struct,subprocess,tempfile
r=Path(__file__).parent.resolve();catalog=r/'catalog.json';cases=json.loads(catalog.read_text(encoding='utf-8'))['cases'];worker=r.parent/'prepared-stores-r413/corrected/retrieved/cpython-worker.py'
def packet(value):
 b=json.dumps(value).encode();return struct.pack('>I',len(b))+b
def read(s):
 n=struct.unpack('>I',s.read(4))[0];return json.loads(s.read(n))
requests=[dict(protocolVersion=2,requestId=i+1,operation='verify',caseId=c['id'],lane='warm',iterations=2,**{k:c[k]for k in ['sourceSha256','fixtureSha256','expectedOutputSha256']})for i,c in enumerate(cases)];requests.append(dict(protocolVersion=2,requestId=len(cases)+1,operation='quit'))
with tempfile.TemporaryDirectory(prefix='lython-comparison-files-')as directory:
 p=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8',str(worker),'--catalog',str(catalog)],input=b''.join(packet(x)for x in requests),capture_output=True,cwd=directory,timeout=30)
 (r/'python-worker.bin').write_bytes(p.stdout);(r/'python-worker.stderr').write_bytes(p.stderr);assert p.returncode==0,p.stderr.decode('utf-8','replace');assert not p.stderr
 s=io.BytesIO(p.stdout);ready=read(s);assert ready['status']=='Ready';responses=[read(s)for _ in requests];assert not s.read()
 for c,v in zip(cases,responses):assert v['status']=='Equivalent'and v['actualOutputSha256']==c['expectedOutputSha256']and v['actualFilesSha256']==c['expectedFilesSha256']
 assert responses[-1]['status']=='Closed'
 filesAtClose=sorted(p.relative_to(directory).as_posix()for p in Path(directory).rglob('*')if p.is_file())
assert not Path(directory).exists()
(r/'python-goldens.json').write_text(json.dumps(dict(ready=ready,responses=responses,allOutputAndFileGoldensPassed=True,allUsersJoinedAndFixturesRemoved=True,timingClaim=False),indent=2)+'\n',encoding='utf-8',newline='\n');print('Both report sources independently match CPython full output/file goldens; no timing claim.')
