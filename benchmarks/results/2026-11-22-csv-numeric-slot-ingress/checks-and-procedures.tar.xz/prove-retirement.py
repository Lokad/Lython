from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]

def sha(data):
    return hashlib.sha256(data).hexdigest()

proofs = []
for artifact, catalog, core in (
    ("packed-block-layout", True, True),
    ("retained-csv-cpython", True, False),
    ("direct-float-text", True, False),
    ("csv-quoted-ranges", True, False),
    ("compiled-literal-defaults-keywords", True, False),
    ("direct-float-output", True, False),
):
    older = artifact == "direct-float-output"
    old = lab.parent / (artifact if older else artifact + "-20261122") / "quiet"
    config = json.loads((old / "config.json").read_text(encoding="utf-8"))
    name = Path(config["root"]).name
    prefix = f"benchmarks/results/2026-11-{'21' if older else '22'}-{artifact}/"
    observation = prefix + "observations.tgz"
    tracked = subprocess.check_output(["git", "show", "origin/master:" + observation], cwd=repo)
    assert sha(tracked) == sha((repo / observation).read_bytes())
    archives = {name + "/observations.tgz": sha(tracked)}
    if core:
        path = prefix + "candidate-core.dll.gz"
        data = gzip.decompress(subprocess.check_output(["git", "show", "origin/master:" + path], cwd=repo))
        assert sha(data) == config["identity"]["coreSHA256"]["candidate"]
        proofs.append(dict(paths=[name + "/candidate/Lokad.Lython.dll"], bytes=len(data), links=1,
                           sha256=sha(data), archives=archives, optional=False))
    if catalog:
        with tarfile.open(repo / observation) as archive:
            data = archive.extractfile("representative.json").read()
        assert sha(data) == config["catalogSHA256"]
        proofs.append(dict(paths=[name + "/representative.json"], bytes=len(data), links=1,
                           sha256=sha(data), archives=archives, optional=False))

remote = r'''
from pathlib import Path
import fcntl, hashlib, json, os, shutil, stat
base = Path('/home/lokad/lython-bench-checks')
proofs = PROOFS
def sha(path):
  with path.open('rb') as source: return hashlib.file_digest(source,'sha256').hexdigest()
with (base/'comparison-vm.lock').open('a') as lease:
  fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
  for proof in proofs:
    paths=[base/name for name in proof['paths']]
    assert not any(os.path.ismount(p) for p in base.glob('*/guest-fixtures'))
    if not all(p.exists() for p in paths): continue
    for p in paths:
      info=p.lstat()
      if not (p.resolve()==p and stat.S_ISREG(info.st_mode) and info.st_uid==os.getuid()
                and info.st_nlink==proof['links'] and info.st_size==proof['bytes']
                and sha(p)==proof['sha256']): break
    else:
      if all(sha(base/name)==checksum for name,checksum in proof['archives'].items()):
        proof['verified'] = True
  print(json.dumps(dict(free=shutil.disk_usage(base).free,proofs=proofs)))
'''.replace("PROOFS", repr(proofs))
ssh = ["C:/Windows/System32/OpenSSH/ssh.exe", "-i", str(Path.home()/".ssh/id_lython-bench.pem"),
       "-o", "BatchMode=yes", "-o", "ConnectTimeout=15", "lokad@20.166.121.73", "python3 -"]
result = json.loads(subprocess.check_output(ssh, input=remote, encoding="utf-8", timeout=40))
(lab / "retire-inventory.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps(result, indent=2))
