from pathlib import Path

lab = Path(__file__).resolve().parent
source = (lab.parent / 'packed-block-layout-20261122/archive.py').read_text(encoding='utf-8')
source = source.replace('2026-11-22-packed-block-layout', '2026-11-22-csv-numeric-slot-ingress')
source = source.replace('9a956c91c', '52d80f93b').replace('B1333', 'B1334').replace('140', '168').replace('1680', '1124').replace('358', '279')
start = source.index('        if platform == "win" and suite == "white":')
end = source.index('receipt = load(quiet / "archive-receipt.json")')
source = source[:start] + '''        assert "Passed!" in log and f"Passed: {count:5d}, Skipped:" in log
allocation = load(lab / "allocation-summary.json")
assert len(allocation) == 4 and all(row["allowanceRestored"] for row in allocation)
''' + source[end:]
source = source.replace('receipt["jobs"] == 5 and len(cases) == 4', 'receipt["jobs"] == 6 and len(cases) == 4')
source = source.replace('[(key,"compile") for key in cases] + [(list(cases)[0],"compile-run")]',
                        '[(key,"warm") for key in cases] + [(list(cases)[3],"warm-async"), (list(cases)[0],"compile-run")]')
source = source.replace('"compile-allocation-summary.json"', '"allocation-summary.json"')
source = source.replace('response.get("actualOutputSha256") == (None if job["lane"] == "compile" else case["expectedOutputSha256"])',
                        'response.get("actualOutputSha256") == case["expectedOutputSha256"]')
source = source.replace('response.get("actualFilesSha256") == (None if job["lane"] == "compile" else case.get("expectedFilesSha256"))',
                        'response.get("actualFilesSha256") == case.get("expectedFilesSha256")')
assert 'len(raw["jobs"]) == receipt["jobs"] == 6' in source
assert '(("white", 279), ("public", 1124))' in source
compile(source, str(lab / 'archive.py'), 'exec')
(lab / 'archive.py').write_text(source, encoding='utf-8', newline='\n')
