from pathlib import Path
import hashlib
import json

lab = Path(__file__).resolve().parent
prior = lab.parent / "packed-block-layout-20261122"
source = (prior / "prepare-quiet.py").read_text(encoding="utf-8")
source = source.replace('9a956c91c', '52d80f93b')
source = source.replace('(("white", 358), ("public", 1400))', '(("white", 279), ("public", 1124))')
source = source.replace('            if platform == "win" and suite == "white":\n'
                        '                assert "Test Run Successful." in log and f"Passed: {count}" in log\n'
                        '            else:\n'
                        '                assert "Passed!" in log and f"Passed: {count:5d}, Skipped:" in log',
                        '            assert "Passed!" in log and f"Passed: {count:5d}, Skipped:" in log')
source = source.replace('packed-block-layout-b1333', 'csv-numeric-slot-ingress-b1334')
source = source.replace('b1333-packed-block-layout', 'b1334-csv-numeric-slot-ingress')
source = source.replace('b1333-fixtures', 'b1334-fixtures')
source = source.replace('One funded packed buffer for emitted blocks', 'Fixed CSV unpack transports parsed doubles in existing operands')
source = source.replace('Packed block buffer compilation comparison', 'Fixed CSV numeric slot transport comparison').replace('"400"', '"465"')
begin = source.index('cases = [')
end = source.index('\ncatalog["cases"]', begin)
source = source[:begin] + '''cases = ['scripts.csv-meter-report.typed-ascii', 'scripts.csv-meter-report.explicit-float',
         'scripts.csv-meter-report.typed-unicode', 'scripts.csv-invoice.large']''' + source[end:]
source = source.replace('[(case, "compile") for case in cases] + [(cases[0], "compile-run")]',
                        '[(case, "warm") for case in cases] + [(cases[3], "warm-async"), (cases[0], "compile-run")]')
source = source.replace('len(jobs)==5', 'len(jobs)==6').replace('jobs=5,', 'jobs=6,').replace("len(raw['jobs'])==5", "len(raw['jobs'])==6").replace("['jobs']==5", "['jobs']==6")
source = source.replace('emit(lab / "summarize.py", (lab.parent / "regex-local-one-shot-20261121/summarize.py").read_text(encoding="utf-8"))',
                        'emit(lab / "summarize.py", (lab.parent / "packed-block-layout-20261122/summarize.py").read_text(encoding="utf-8").replace("len(raw[\'jobs\'])==5", "len(raw[\'jobs\'])==6"))')
source = source.replace('Prepared five lanes', 'Prepared six lanes')
source = source.replace('proof = load(lab / "retire-proof.json")\nretire = proof["proof"]',
                        'inventory = load(lab / "retire-inventory.json")\n'
                        'retire = [entry.copy() for entry in inventory["proofs"] if entry.get("verified")]')
source = source.replace('stage = dict(root=root,', '''
needed = 176160768 + sum((out / name).stat().st_size for name in parts) + 640 * 1024
selected = []
free = inventory["free"]
for entry in sorted(retire, key=lambda group: group["bytes"], reverse=True):
    if free > needed:
        break
    entry.pop("verified")
    selected.append(entry)
    free += entry["bytes"]
assert free > needed, (free, needed)
retire = selected
stage = dict(root=root,''')
assert source.count('jobs==6') == 0 and source.count('len(jobs)==6') == 1
(lab / "prepare-quiet.py").write_text(source, encoding="utf-8", newline="\n")
exec(compile(source, str(lab / "prepare-quiet.py"), "exec"))
