from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent; repo=Path('D:/code/Lython'); out=repo/'benchmarks/results/2026-11-18-helper-validation-cpython';out.mkdir(exist_ok=False)
guide=repo/'docs/BENCHMARKS.md';shutil.copyfile(guide,out/'prior-BENCHMARKS.md')
for n in ['summary.json','catalog.json','preflight.json']:shutil.copyfile(r/n,out/n)
for n in ['identity.json','archive-receipt.json','terminal-status.json','observations.tgz']:shutil.copyfile(r/'quiet'/n,out/n)
identity=json.loads((out/'identity.json').read_text(encoding='utf-8'))
source=repo/'benchmarks/results/2026-11-18-discarded-call-results/refined/candidate-sources.tar.xz'
assert hashlib.sha256(source.read_bytes()).hexdigest()==identity['sourceInputsArchiveSHA256']
with tarfile.open(out/'procedures.tar.xz','w:xz')as a:
 for p in sorted(r.rglob('*')):
  if p.is_file()and 'retrieved'not in p.relative_to(r).parts and p.suffix in ['.py','.json','.log','.sh']:a.add(p,arcname=p.relative_to(r).as_posix())
s=json.loads((out/'summary.json').read_text(encoding='utf-8'));names={'scripts.text-normalization.helper-list':'Helper text normalization','scripts.csv-field-validation.large':'CSV field validation'}
def cells(row):
 t=row['medianMilliseconds'];l=[t[x]for x in ['candidate','candidate-control']];c=[t[x]for x in ['CPython','CPython-control']]
 return [f'{min(l):.3f}–{max(l):.3f} ms',f'{min(c):.3f}–{max(c):.3f} ms',f"{min(row['ratioRange']):.2f}–{max(row['ratioRange']):.2f}×",f"Diagnostic7db/c036; controls L/C {row['lythonControlPercent']:.2f}/{row['cpythonControlPercent']:.2f}%; IQR≤{row['maxIqrPercent']:.2f}%"]
table=[];warm=[];phases=[]
for row in s['timing']:
 title=names[row['case']];phase={'compile':'Compilation only','warm':'Warm execution','compile-run':'Compile-to-result'}[row['lane']]
 table.append('| '+title+' | '+phase+' | '+' | '.join(cells(row))+' |')
 if row['lane']=='warm':
  size='4,096 lines / 52,224 B'if 'text' in row['case']else'4,128 rows / 128,183 B'
  warm.append('| '+title+' | '+size+' | '+' | '.join(cells(row))+' |')
 else:phases.append('| '+title+' | '+phase+' | '+' | '.join(cells(row))+' |')
(out/'README.md').write_text('''# Helper text and CSV validation against CPython

R517/B946, measured 2026-11-18 UTC: committed **7db1de02 / frozen c0367d98**
versus stock **CPython 3.13.16** (PGO/LTO, GIL, no JIT). Azure F4as_v7,
4 vCPU AMD EPYC 9V45 / 16 GiB, Ubuntu 24.04.4, .NET 11 RC3, default GC/tiering.
Six jobs / 227.62 seconds; six-second warmups, five rotated rounds, two processes
per engine. Existing worker protocol/catalog, no new measurement framework.

**Qualification limitation:** full run 44247104176 failed existing entry-error
context regressions on both platforms. Cancellation/refusal after a forwarded
call result can acquire operation context. A subsequent correction must be
qualified independently. These observations remain useful for these exact
successful scripts, but describe neither corrected HEAD nor a qualified release.

| Complete script | Phase | Lython | CPython | Lython / CPython | Status |
| --- | --- | ---: | ---: | ---: | --- |
'''+ '\n'.join(table)+'''

Ratios above one mean slower. Ranges combine the four process-median pairs, not
confidence intervals. Helper text warm is 1.28–1.32× and fresh 1.51–1.54×;
CSV validation warm is 0.69–0.70× and fresh 0.68–0.69×. Helper fresh IQR reaches
4.89%; all adverse samples and controls remain in the raw archive. This is an
external baseline, not a causal improvement over another Lython revision.

Helper input: 4,096 lines / 52,224 B. CSV: 4,128 rows / 128,183 B, including
32 malformed fields, quoted newlines and Unicode. The complete script parses
quantity and price, counts valid/invalid rows and emits fixed independent goldens.
This new validation script complements the existing numeric CSV report.

Warm includes Run, mediated RAM I/O, goldens and previous-result cleanup. Fresh
adds compilation/compiled-owner disposal; compilation includes owner disposal.
Startup/reset/request framing/final cache teardown are outside guest clocks;
process CPU is wider. Separately warmed phases are not additive. CPython native
files do not provide equivalent containment/ownership. All 32 image files and
the actual catalog passed verification. Every worker verifies outputs and Closed;
quiet gates, joined users and persistent/local SHA archives passed before RAM
teardown. Existing space floors and current images remain intact.

[Summary](summary.json), [raw](observations.tgz), [identity](identity.json),
[catalog](catalog.json), [goldens](preflight.json), [procedures](procedures.tar.xz),
[previous guide](prior-BENCHMARKS.md). Publication remains postponed.
''',encoding='utf-8',newline='\n')
text=guide.read_text(encoding='utf-8');marker='\n**Ratio =';assert text.count(marker)==1
text=text.replace(marker,'\n'+'\n'.join(warm)+'\n'+marker)
marker='\nCompilation includes compiled-owner disposal.';assert text.count(marker)==1
text=text.replace(marker,'\n'+'\n'.join(phases)+'\n'+marker)
marker='\nWarm clocks include';assert text.count(marker)==1
text=text.replace(marker,'''
Helper text and CSV-validation rows use **7db1de02 / c0367d98**, measured
**2026-11-18** on the same machine/toolchains. **Full qualification failed**:
entry-error context after forwarded results needs correction. These successful
scripts are diagnostic for that exact revision, not corrected HEAD. Helper fresh
IQR reaches 4.89%. [Sources, controls and limitations](../benchmarks/results/2026-11-18-helper-validation-cpython/README.md).
'''+marker)
text=text.replace('Focused checks pass; joint full delivery pending.','Full delivery exposed an entry-error-context regression; correction/qualification pending.')
text=text.replace('Focused checks pass; full delivery pending.','Focused checks pass; joint full delivery needs the result-routing correction.')
guide.write_text(text,encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as a:a.write('''

R517/B946 [helper-text/CSV-validation CPython checkpoint](results/2026-11-18-helper-validation-cpython/README.md): exact committed7db1de02/frozenc0367d98 versus stock3.13.16; sixjobs227.62s,32image/goldens/quiet/join/SHAarchive pass. Helper compile1.03–1.05×/warm1.28–1.32×/fresh1.51–1.54×; CSVvalidation compile0.96–0.98×/warm0.69–0.70×/fresh0.68–0.69×. HelperfreshIQR4.89% retained. Full44247104176 FAILED entry-failure-context regressions; not correctedHEAD or fully qualified. Independent runtime correction required; no causal source-gain claim. Original reports, raw controls and source snapshots preserved; publication held.
''')
print('Archived exact pre-correction external baseline; added two workloads with explicit qualification failure.')
