R175 source-pair confirmation, not CPython or pending-I/O latency.
Existing five complete jobs, four independent processes (two per source), ordinary
GC/tiering, 5s warmup/role, seven rotated150ms rounds. Full output/ownership/quiet/
join/RAM-unmount/archive-under-lease/localSHA gates. Preserve Unicode adversity.
Warm includes mediated RAM I/O/output validation/prior-result cleanup; excludes
startup/reset/protocol/final caches. External CPU is coarser and wider. Compilation
separately measured locally. No fixed-percentage veto or equivalence claim.
Reuse only exact frozen R173 baseline; every managed auxiliary/config remains exact.
No source restoring with old timestamps; candidate was freshly nonincremental-built.
