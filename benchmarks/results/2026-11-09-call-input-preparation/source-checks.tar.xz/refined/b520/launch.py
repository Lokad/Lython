from pathlib import Path
import datetime, hashlib, json, shlex, subprocess

home=Path(__file__).parent
payload=(home/'payload.tgz').read_bytes()
script=(home.parent.parent.parent/'text-cache-storage-r173/b518/launch-command.py').read_text(encoding='utf-8')
old="root=base/'string-index-storage-b518-20261109';reference=base/'config-boundary-b509-20261109/candidate'"
new="root=base/'call-inputs-b520-20261109';reference=base/'string-index-storage-b518-20261109/candidate'"
assert script.count(old)==1
script=script.replace(old,new).replace('lython-b518-string-index-storage','lython-b520-call-inputs').replace('lython-b518-fixtures','lython-b520-fixtures')
script='\n'.join(" payload=sys.stdin.buffer.read("+str(len(payload))+"+1);assert len(payload)=="+str(len(payload))+" and hashlib.sha256(payload).hexdigest()=="+repr(hashlib.sha256(payload).hexdigest()) if line.startswith(' payload=') else line for line in script.splitlines())+'\n'
script=script.replace('+(240+12)*1024*1024','+(240+12)*1024*1024+65536')
script=script.replace(" assert hashlib.sha256((root/'baseline-core.dll').read_bytes())",
                      " os.link(base/'string-index-storage-b518-20261109/current-core.dll',root/'baseline-core.dll')\n assert hashlib.sha256((root/'baseline-core.dll').read_bytes())")
old=" (root/'cpython-worker.py').symlink_to(base/'prepared-call-layout-b384-20261107/cpython-worker.py')"
new=" protocol=base/'prepared-call-layout-b384-20261107/cpython-worker.py'\n assert hashlib.sha256(protocol.read_bytes()).hexdigest()=='02ca606af6b937a5bec8da744da36e6dbea45ef14ee7207732f34da052ad32f1'\n (root/'cpython-worker.py').symlink_to(protocol)"
assert script.count(old)==1
script=script.replace(old,new)
marker=" except BaseException:\n"
assert script.count(marker)==1
script=script.replace(marker,"  live=subprocess.check_output(['systemctl','show','lython-b520-call-inputs-20261109.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)\n  print(json.dumps(dict(liveUnit=live)),flush=True)\n"+marker)
compile(script,'b520-launch','exec')
(home/'launch-command.py').write_text(script,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
stage='/home/lokad/lython-bench-checks/call-inputs-b520-launch.py'
code='from pathlib import Path; import sys; p=Path('+repr(stage)+'); assert not p.exists(); p.write_bytes(sys.stdin.buffer.read())'
done=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=script.encode('utf-8'),capture_output=True)
assert done.returncode==0,done.stderr
done=subprocess.run(ssh+['python3 '+stage],input=payload,capture_output=True)
(home/'launch.log').write_bytes(done.stdout+b'\n'+done.stderr)
print((done.stdout+done.stderr).decode('utf-8'),flush=True)
assert done.returncode==0
assert b'ActiveState=active' in done.stdout and b'MainPID=0' not in done.stdout
now=datetime.datetime.now(datetime.timezone.utc)
(home/'observe-not-before.json').write_text(json.dumps(dict(acknowledgedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=270)).isoformat(),ownerSeconds=210,stopSeconds=30,marginSeconds=30),indent=2)+'\n',encoding='utf-8')
print('New B519 owner verified live; observe after', (now+datetime.timedelta(seconds=270)).isoformat(),flush=True)
