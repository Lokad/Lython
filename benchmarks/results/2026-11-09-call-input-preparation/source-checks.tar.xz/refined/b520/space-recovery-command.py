from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks')
spec=[{'path': '/home/lokad/lython-bench-checks/helper-confirm-b480-20261108/observations.tgz', 'sha256': '990a2cbc6324d249eac568f2f5c79b31fce3c21e6b153ddc96e42042d72daa88', 'size': 3974326, 'preservedLocal': 'D:/code/Lython/benchmarks/results/2026-11-08-function-lookup-lifetimes/confirmation-observations.tgz', 'tracked': True}, {'path': '/home/lokad/lython-bench-checks/prepared-binding-b483-20261108/observations.tgz', 'sha256': '364d43c579d6ea9d7f3dfe474c026bf572d84db1e3f5f564fe98aebfd105e05a', 'size': 3888904, 'preservedLocal': 'D:/code/Lython/benchmarks/results/2026-11-08-prepared-function-binding/initial-observations.tgz', 'tracked': True}, {'path': '/home/lokad/lython-bench-checks/function-lookups-b479-20261108/observations.tgz', 'sha256': '79bebeac6cfdf356bac408d78f76e05855b6a96eeb06c6cc36328df19f36cac4', 'size': 2113936, 'preservedLocal': 'D:/code/Lython/benchmarks/results/2026-11-08-function-lookup-lifetimes/combined-observations.tgz', 'tracked': True}, {'path': '/home/lokad/lython-bench-checks/cpython-checkpoint-b517-20261109/observations.tgz', 'sha256': 'df152e38e1e993cda80222493814cdcb5b1a1e64582b94b2c95a8440b9c32f9a', 'size': 2008876, 'preservedLocal': 'D:/code/Lython/benchmarks/results/2026-11-09-current-cpython-checkpoint/observations.tgz', 'tracked': True}]
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not (base/'call-inputs-b520-20261109').exists()
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*')) and not Path('/dev/shm/lython-b512').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 free=shutil.disk_usage(base).free
 if free>270852096:
  print(json.dumps(dict(skipped=True,beforeFreeBytes=free,requiredFreeBytes=270852096,reason='Fresh space sufficient; no mutation')));__import__('sys').exit(0)
 rows=[];unavailable=[]
 for entry in spec:
  p=Path(entry['path'])
  if not p.exists():unavailable.append(entry['path']);continue
  assert p.resolve(strict=True)==p and p.parent.parent==base and p.name=='observations.tgz'
  info=p.lstat();assert stat.S_ISREG(info.st_mode) and info.st_nlink==1 and info.st_uid==os.getuid() and info.st_gid==os.getgid()
  assert info.st_size==entry['size'] and hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256']
  receipt=json.loads((p.parent/'archive-receipt.json').read_text());receipt=receipt.get('receipt',receipt);assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['archiveSHA256']==entry['sha256']
  parents=[]
  for parent in p.parents:
   meta=parent.lstat();assert stat.S_ISDIR(meta.st_mode) and not parent.is_symlink()
   parents.append(dict(path=str(parent),uid=meta.st_uid,gid=meta.st_gid,mode=oct(meta.st_mode)))
  rows.append(dict(**entry,device=info.st_dev,inode=info.st_ino,links=info.st_nlink,uid=info.st_uid,gid=info.st_gid,mode=oct(info.st_mode),parents=parents,allAliases=[str(p)]))
  if free+sum(Path(e['path']).stat().st_blocks*512 for e in rows)>270852096:break
 assert free+sum(Path(e['path']).stat().st_blocks*512 for e in rows)>270852096, ('Exact copies cannot fund unchanged payload/floors; no mutation',dict(freeBytes=free,requiredBytes=270852096,selectedBytes=sum(Path(e['path']).stat().st_blocks*512 for e in rows),unavailable=unavailable))
 plan=dict(requiredFreeBytes=270852096,freshIdleLease=True,beforeFreeBytes=free,osFloorMiB=240,evidenceHeadroomMiB=12,files=rows,unavailable=unavailable,operation='Remove only redundant remote compressed archives. Their raw trees, receipts, frozen workers and byte-identical tracked local archives survive.')
 target=base/'call-inputs-b520-space-plan.json'
 with target.open('x') as f:f.write(json.dumps(plan,indent=2)+'\n');f.flush();os.fsync(f.fileno())
 for entry in rows:
  p=Path(entry['path']);info=p.lstat()
  assert info.st_dev==entry['device'] and info.st_ino==entry['inode'] and info.st_nlink==1 and hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256']
  p.unlink()
 plan['afterFreeBytes']=shutil.disk_usage(base).free
 assert plan['afterFreeBytes']>270852096 and plan['afterFreeBytes']>free and plan['afterFreeBytes']>(240+12)*1024*1024
 (base/'call-inputs-b520-space-receipt.json').write_text(json.dumps(plan,indent=2)+'\n')
 print(json.dumps(plan))
