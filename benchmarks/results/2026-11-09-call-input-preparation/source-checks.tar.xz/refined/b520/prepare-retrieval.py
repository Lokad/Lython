from pathlib import Path
home=Path(__file__).parent
old=home.parent.parent.parent/'text-cache-storage-r173/b518'
text=(old/'retrieve.py').read_text(encoding='utf-8').replace('string-index-storage-b518-20261109','call-inputs-b520-20261109').replace('lython-b518-string-index-storage-run2-20261109','lython-b520-call-inputs-20261109')
text=text.replace('Five-job raw observations/cores independently SHA-verified;', 'B519 five-job raw observations/cores independently SHA-verified;')
(home/'retrieve.py').write_text(text,encoding='utf-8',newline='\n')
(home/'summarize.py').write_text((old/'summarize.py').read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
print('Prepared bounded retrieval/analysis; no remote observation before the recorded deadline.')
