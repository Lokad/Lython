from pathlib import Path
import json, os, re, subprocess

home=Path(__file__).parent
env=os.environ.copy()
env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11'
env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
checks={}
filters={
    'internal': 'Category!=Stress&(FullyQualifiedName~Executable|FullyQualifiedName~CallArgument|FullyQualifiedName~CallBinding|FullyQualifiedName~PositionalCall|FullyQualifiedName~StaticCallArgument|FullyQualifiedName~CompletedHelper|FullyQualifiedName~NativeOperationAllocation|FullyQualifiedName~NativeScalar|FullyQualifiedName~NativeTruth)',
    'public': 'Category!=Stress&(FullyQualifiedName~Call|FullyQualifiedName~Argument|FullyQualifiedName~Constructor|FullyQualifiedName~Closure|FullyQualifiedName~Generator|FullyQualifiedName~OperandRead|FullyQualifiedName~Refusal|FullyQualifiedName~MemoryBudget|FullyQualifiedName~Cancellation|FullyQualifiedName~Comprehension|FullyQualifiedName~Native|FullyQualifiedName~NumericIngressContract)'
}
for framework in ['net11.0','net10.0']:
    for kind,project in [('internal','tests/Lokad.Lython.Tests'),('public','tests/Lokad.Lython.PublicApi.Tests')]:
        label=kind+'-'+framework
        with(home/(label+'.log')).open('w',encoding='utf-8')as out:
            done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','test',project,'-c','Release','-f',framework,'--no-restore','--filter',filters[kind]],env=env,stdout=out,stderr=subprocess.STDOUT)
        text=(home/(label+'.log')).read_text(encoding='utf-8')
        print(label,done.returncode,text[-400:],flush=True)
        assert done.returncode==0,label
        checks[label]=int(re.search(r'Passed:\s+(\d+)',text).group(1))
(home/'qualification.json').write_text(json.dumps(dict(checks=checks,stressExcluded=True,
    limitations='Refined shared-operand metadata source; initial source full16931public.NET11 is recorded separately, not attributed to this source. Full platform/stress/package batch at delivery.'),indent=2)+'\n',encoding='utf-8')
