from pathlib import Path
import hashlib, json, shutil, tarfile

home = Path(__file__).parent
old = home.parent.parent/'text-cache-storage-r173/b518'
dest = home/'b520'
dest.mkdir()
identity = json.loads((old/'identity.json').read_text(encoding='utf-8'))
local = json.loads((home/'identity.json').read_text(encoding='utf-8'))
for name, digest in local['productionSources'].items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest, name
assert local['cores']['before']==identity['coreSHA256']['candidate']
identity['coreSHA256']={role:local['cores']['before' if role.startswith('reference') else 'candidate']
                       for role in ['reference','reference-control','candidate','candidate-control']}
identity['sourceRevision']='R175 refined shared prepared-input metadata, f9a84542 plus working patch; initial B519 adversity retained; baseline qualified cac4acf8-equivalent R173 freeze. Exact source/core hashes supplied.'
identity['catalogSHA256']=local['catalogSHA256']
identity.pop('startupCorrection', None)
(dest/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
for label, source in [('current-core.dll',home/'images/candidate/Lokad.Lython.dll'),
                      ('representative.json',home/'catalog.json'), ('baseline-source.json',home/'baseline.json'),
                      ('final-source.json',home/'identity.json'), ('source.patch',home/'source.patch'),
                      ('before-shapes.json',home/'before-shapes.json'), ('candidate-shapes.json',home/'candidate-shapes.json'),
                      ('CallInputLifetimeTests.cs',Path('tests/Lokad.Lython.PublicApi.Tests/CallInputLifetimeTests.cs'))]:
    shutil.copyfile(source,dest/label)
for name in ['collect.py','archive-owned.py','run.sh']:
    text=(old/name).read_text(encoding='utf-8').replace('string-index-storage-b518-20261109','call-inputs-b520-20261109').replace('lython-b518-string-index-storage-20261109','lython-b520-call-inputs-20261109')
    text=text.replace('R173 string indexing storage source comparison','R175 ordinary call input source comparison')
    text=text.replace('R173 optional string index metadata; complete CSV/text/report plus Unicode-index control. Text sync/async included. Allocation savings and elapsed/CPU evidence remain separate; preserve all adverse controls.',
                      'R175 ordinary call input preparation; complete CSV/text/report plus adverse Unicode-index control. Text sync/async included. Runtime allocation, compilation debt and elapsed/CPU evidence separate; preserve all adverse controls.')
    text=text.replace("'PyString.cs',", "'CallInputLifetimeTests.cs','before-shapes.json','candidate-shapes.json',")
    (dest/name).write_text(text,encoding='utf-8',newline='\n')
(dest/'focused.json').write_text(json.dumps(dict(net11Internal=576,net10Internal=576,net11Public=3886,net10Public=3886,stressExcluded=True),indent=2)+'\n',encoding='utf-8')
(dest/'setup-contract.json').write_text(json.dumps(dict(jobs=5,roles=4,ownerSeconds=210,stopSeconds=30,marginSeconds=30,osFreeFloorMiB=240,evidenceHeadroomMiB=12,
    referenceReuse='/home/lokad/lython-bench-checks/string-index-storage-b518-20261109/current-core.dll', protocolSHA256='02ca606af6b937a5bec8da744da36e6dbea45ef14ee7207732f34da052ad32f1'),indent=2)+'\n',encoding='utf-8')
contract='''R175 source-pair confirmation, not CPython or pending-I/O latency.
Existing five complete jobs, four independent processes (two per source), ordinary
GC/tiering, 5s warmup/role, seven rotated150ms rounds. Full output/ownership/quiet/
join/RAM-unmount/archive-under-lease/localSHA gates. Preserve Unicode adversity.
Warm includes mediated RAM I/O/output validation/prior-result cleanup; excludes
startup/reset/protocol/final caches. External CPU is coarser and wider. Compilation
separately measured locally. No fixed-percentage veto or equivalence claim.
Reuse only exact frozen R173 baseline; every managed auxiliary/config remains exact.
No source restoring with old timestamps; candidate was freshly nonincremental-built.
'''
for name in ['contract.md','pre-measurement-plan.md']:(dest/name).write_text(contract,encoding='utf-8',newline='\n')
(dest/'sizing.json').write_text(json.dumps(dict(jobs=5,expectedSeconds=150,maximumOwnerSeconds=210,cleanupReserveSeconds=30),indent=2)+'\n',encoding='utf-8')
with tarfile.open(dest/'payload.tgz','w:gz')as archive:
    for p in sorted(dest.iterdir()):
        if p.is_file()and p.name!='payload.tgz':archive.add(p,arcname=p.name)
with tarfile.open(dest/'payload.tgz')as archive:
    needed=sum(((p.size+4095)//4096)*4096 for p in archive.getmembers())+252*1024*1024+65536
(dest/'payload-sizing.json').write_text(json.dumps(dict(requiredFreeBytes=needed,payloadBytes=(dest/'payload.tgz').stat().st_size,
    persistentBaselineReused=True,extraSetupHeadroomBytes=65536),indent=2)+'\n',encoding='utf-8')
print('B519 finite payload prepared; required free bytes',needed,'one new core, baseline hardlinked.')
