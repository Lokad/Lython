from pathlib import Path
import hashlib, json, shutil, tarfile

root=Path('D:/code/Lython')
home=Path(__file__).parent
target=root/'benchmarks/results/2026-11-09-call-input-preparation'
assert not target.exists()
baseline=json.loads((home/'baseline.json').read_text(encoding='utf-8'))
for name,digest in baseline['productionSources'].items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
for folder,identity in [(home/'b519',home/'identity.json'),(home/'refined/b520',home/'refined/identity.json')]:
    terminal=json.loads((folder/'terminal-status.json').read_text(encoding='utf-8'))
    receipt=json.loads((folder/'archive-receipt.json').read_text(encoding='utf-8'))
    assert terminal['exitCode']=='0' and not terminal['remainingWorkers'] and not terminal['remainingFixtures'] and not terminal['remainingTrace']
    assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['jobs']==5 and receipt['archivedAndVerifiedUnderLease']
    assert hashlib.sha256((folder/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
    assert json.loads((identity).read_text(encoding='utf-8'))['cores']['candidate']==json.loads((folder/'identity.json').read_text(encoding='utf-8'))['coreSHA256']['candidate']
target.mkdir()
for source,name in [
    (home/'identity.json','original-identity.json'),(home/'refined/identity.json','refined-identity.json'),
    (home/'assessment.json','original-desktop.json'),(home/'refined/assessment.json','refined-desktop.json'),
    (home/'qualification.json','qualification.json'),(home/'python-goldens.json','python-goldens.json'),
    (home/'before-shapes.json','before-shapes.json'),(home/'candidate-shapes.json','original-shapes.json'),
    (home/'refined/candidate-shapes.json','refined-shapes.json')]:
    shutil.copyfile(source,target/name)
for prefix,folder in [('original',home/'b519'),('refined',home/'refined/b520')]:
    for source,suffix in [('observations.tgz','observations.tgz'),('summary.json','quiet.json'),('terminal-status.json','terminal.json'),
                          ('archive-receipt.json','archive-receipt.json'),('space-recovery.json','space-recovery.json')]:
        shutil.copyfile(folder/source,target/(prefix+'-'+suffix))
with tarfile.open(target/'source-checks.tar.xz','w:xz')as archive:
    for folder in [home,home/'refined',home/'b519',home/'refined/b520']:
        for item in sorted(folder.iterdir()):
            if item.is_file()and item.suffix in ['.cs','.csproj','.py','.json','.log','.patch']:
                archive.add(item,arcname=item.relative_to(home).as_posix())
    for folder in [home/'original-source',home/'refined/source',home/'python-goldens',home/'warm-sync',home/'warm-async',home/'compile-sync',
                   home/'refined/warm-sync',home/'refined/warm-async',home/'refined/compile-sync']:
        for item in sorted(folder.rglob('*')):
            if item.is_file():archive.add(item,arcname=item.relative_to(home).as_posix())
    for name in ['CallInputLifetimeTests.cs','OperandReadFailureTests.cs']:
        archive.add(root/'tests/Lokad.Lython.PublicApi.Tests'/name,arcname='retained-tests/'+name)
(target/'README.md').write_text('''# Ordinary call input preparation — R175

2026-11-09. Qualified cac4acf8-equivalent R173/e833 freeze versus two private
source variants after f9a84542. **Both variants withdrawn completely.** All six
production files match the qualified baseline; retained semantic coverage passes.
No public API, regex provider, memory policy, stack or cancellation change ships.

## Work and implementation

The existing ForwardValues pass forwards pure adjacent local/constant operands to
arithmetic. Extend the same pass to complete ordinary call argument suffixes;
retain source read spans and original funded packet capacity. Materialize the
packet in the call instruction with per-argument cancellation, then use existing
binding/callback/async paths. Existing LiveExtent identifies pending packets after
context promotion; no invocation flag, new array, cache, policy or engine.

Initial metadata added a source int beside the native proof input. Refine to reuse
the existing prepared-input int, with one compiler-only call-site fact and ordinary
forwarding restricted to code without NativeBody. Remove the duplicate argument
field and preserve closed helper borrowing/proof domains. Wider cold read-span
keys support arguments after the fourth. Each variant removes module instructions:
CSV93→79, text74→65, JSON report58→50, Unicode-index64→56, config67→60.
This static census establishes fewer dispatches, not a removable CPU percentage.

Initial checks:537internal/2831public each actual.NET11/.NET10; full16931public.NET11.
Refined source:576internal/3886public each target. Independent trusted CPython3.13.2
goldens verify target/keyword order, positional aliases and successful constructor/
function output; guest top-level return is explicitly wrapped for that reference.
New public cases observe original unbound spans beyond argument four, keyword
identity, genuine delayed host calls/constructors, cancellation, retained results,
joined cleanup and budget reuse. Nothing relaxes assertions or containment.

## Measurements

Same five complete trusted scripts, same worker/adapter0.4 and auxiliaries; both
APIs and two identical original desktop roles. Runtime allocation effectively flat;
compilation allocation initial+0.41..0.86%, refined+0.29..0.66%. Compilation timing
includes construction/disposal and driver overhead, no execution or I/O. Original
summary divided by zero execution time in compile-only data; all lanes had already
completed. Offline analysis fixes the clock selection without rerunning anything.
Desktop elapsed remains diagnostic, with all original/refined adversity retained.

Two separate quiet F4as_v7/Ubuntu24.04.4/.NET11RC3 batches, ordinary GC/tiering:
B519141.267s and revised-source B520141.365s, five jobs each. Four independent
processes (two per source),5s warmup/role, seven rotated150ms rounds. Warm includes
mediated RAM I/O, full stdout/file validation and prior-result cleanup; excludes
startup/reset/protocol/final caches. External process CPU is coarser/wider. Ranges
span all four median pairings, not confidence intervals or CPython comparisons.

| Complete script/API | Original elapsed change | Refined elapsed change |
| --- | ---: | ---: |
| CSV/sync |−1.66..−0.09%|−2.03..+2.17%|
| Text/sync |−2.66..+0.22%|−4.81..+1.09%|
| Text/async completed I/O |+2.71..+5.14%|−1.38..+1.55%|
| JSON report/sync |−3.10..+0.11%|−3.25..+2.10%|
| Unicode-index control/sync |−3.49..+3.61%|−0.79..+5.30%|

Original async text has tight0.40% reference spread,1.92% candidate spread, a
demonstrated adverse result. Revised source overlaps controls; it does not establish
recovery, equivalence or general CPU gain. Revised text reference spread4.19%,
report4.38%; Unicode external CPU0..+7.86% and elapsed retain possible cost.
All identities/goldens/ownership/quiet/Closed/joins/RAM-unmount/archive-under-lease/
localSHA gates pass. Both owners terminal; no workers/fixtures remain. Revised
console labels retain B519 in a reused print string; exact B520 unit/identity/raw
records identify the revised collection, not the original run.

## Decision and preserved failed conditions

Withdraw the dispatch-only implementation. It keeps argument reads/copies in a
new preparation loop and grows compiler allocation; these controlled results do
not justify that additional machinery. This is a bounded engineering decision,
not a fixed-percentage veto, failed semantics or permanent rejection of direct
operands. A later coherent call/frame migration must remove actual packet/workspace
work while preserving native helper allocation gains and suspension ownership.

Restore all production bytes exactly using fresh timestamps, force nonincremental
builds, then42retained public contract checks pass per actual11/10. Runtime source
remains covered by previous full42684724223; no unchanged full platform/Stress/
package replay for discarded prototypes. The broader performance objective stays
active; the primary external benchmark guide is unchanged.

First B519 space proof refused before mutation: a path substitution incorrectly
renamed its first candidate, and B505 was genuinely absent. Both failed command/log
survive. Exclude known-absent B505, correct substitution ordering; fresh exact SHA,
single-alias/metadata/parent/receipt proofs remove only B518/B486/B485 compressed
duplicates. B520 separately removes only B480/B483/B479/B517 copies. Canonical
tracked archives, raw trees, receipts and frozen workers survive;240MiBOS/12MiB
evidence floors unchanged. Reuse the exact persistent R173 baseline by hardlink;
only one new core is staged per run. No broader storage audit or old-terminal poll.

[Initial quiet](original-quiet.json), [revised quiet](refined-quiet.json),
[initial desktop](original-desktop.json), [revised desktop](refined-desktop.json),
[qualification](qualification.json), [independent goldens](python-goldens.json),
[initial identity](original-identity.json), [revised identity](refined-identity.json),
[initial raw/cores](original-observations.tgz), [revised raw/cores](refined-observations.tgz),
[exact source/tests/desktop/failed conditions](source-checks.tar.xz).
''',encoding='utf-8',newline='\n')
path=root/'benchmarks/EXPERIMENTS.md'
text=path.read_text(encoding='utf-8')
marker='The [R174 private integer transport prototype]'
assert text.count(marker)==1
text=text.replace(marker,'''The [R175 ordinary call-input batch](results/2026-11-09-call-input-preparation/README.md)
removes14CSV/9text/8report module dispatches in two private variants, but retains
reads/copies in a new loop. Shared prepared metadata removes a duplicate field.
Both quiet5job141s batches pass all gates; original async text+2.71..5.14%, refined
controls overlap with possible Unicode cost. Runtime allocation flat, compilation
+0.29..0.66%. Withdraw both variants completely, retain seven semantic cases and
all adverse/raw evidence. Exact qualified production restored;42retained checks
per actual11/10 pass. Initial full16931public11 and refined576/3886each target are
labelled by source. No CPU/equivalence claim or permanent design veto; objective open.

''' + marker)
path.write_text(text,encoding='utf-8',newline='\n')
print('Published exact R175 initial/refined evidence; both production variants absent, seven external semantic cases retained.')
