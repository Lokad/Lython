from pathlib import Path
import hashlib, json, shutil, subprocess

root = Path('D:/code/Lython')
home = Path(__file__).parent
baseline = json.loads((home.parent / 'machine-integers-r174/baseline.json').read_text(encoding='utf-8'))
for name, expected in baseline['productionSources'].items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == expected, name
shutil.copytree(home.parent / 'text-cache-storage-r173/refined/images/candidate', home / 'images/before')
shutil.copyfile(home.parent / 'machine-integers-r174/catalog.json', home / 'catalog.json')
for name in ['Frontend/ExecutableScript.cs', 'Frontend/ExecutableStackLayout.cs', 'Frontend/ExecutableScript.InputSpans.cs',
             'Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs']:
    target = home / 'before-source' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(root / 'src/Lokad.Lython' / name, target)
(home / 'baseline.json').write_text(json.dumps(dict(revision=subprocess.check_output(['git','rev-parse','HEAD'], text=True).strip(),
    production='cac4acf8 equivalent', frozenCoreSHA256=hashlib.sha256((home/'images/before/Lokad.Lython.dll').read_bytes()).hexdigest(),
    productionSources=baseline['productionSources'],
    contract='Fold only an entire adjacent pure local/constant call-argument suffix in existing ForwardValues. Preserve NativeInput graph domain separately. Existing packet capacity/lifetime retained; LiveExtent distinguishes prepared pending packets. Cold argument read keys must support indexes above three.',
    expectedRemoval='Per-argument load opcode dispatch, while retaining checked reads, per-argument cancellation and existing contiguous borrows. One extra source int in existing immutable argument metadata, no runtime array or cache.',
    acceptance=['target before arguments', 'unbound read spans including argument index above3', 'positional/keyword binding', 'mutable aliases', 'constructors/reentry', 'promotion and actual async I/O', 'terminal refusal and cleanup'],
    measurement='Existing five complete scripts, both APIs, two unchanged roles; separate compilation. CPU remains unproven.'
), indent=2)+'\n', encoding='utf-8')
plan = root / 'PLAN.md'
text = plan.read_text(encoding='utf-8').replace('R175 next: ordinary call inputs through existing compiler facts.', 'R175 active: ordinary call inputs through existing compiler facts.')
text = text.replace('   Define code removed and remaining metadata before prototyping;',
'''   Displace per-leaf load opcode dispatch, not argument reads/checks or packet
   lifetime. Add one source int to existing argument metadata, no runtime allocation.
   Use existing LiveExtent to recognize already prepared packets; no new state flag.
   Widen cold read-span keys for arbitrary argument indexes, preserving all operands.
   Define code removed and remaining metadata before prototyping;''')
plan.write_text(text, encoding='utf-8', newline='\n')
print('Qualified production baseline verified; call-input migration contract recorded before edits.')
