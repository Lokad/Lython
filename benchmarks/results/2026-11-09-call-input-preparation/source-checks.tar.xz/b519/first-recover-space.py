from pathlib import Path
import hashlib, json, subprocess

home=Path(__file__).parent
required=json.loads((home/'payload-sizing.json').read_text(encoding='utf-8'))['requiredFreeBytes']
spec=[]
for remote,local in [
    ('string-index-storage-b518-20261109','2026-11-09-optional-string-index-metadata'),
    ('dispatch-liveness-b486-20261109','2026-11-09-dispatch-liveness'),
    ('cpython-checkpoint-b517-20261109','2026-11-09-current-cpython-checkpoint'),
    ('json-runtime-b505-20261109','2026-11-09-json-runtime-attribution')]:
    p=Path('benchmarks/results')/local/'observations.tgz'
    assert subprocess.check_output(['git','ls-files','--',p.as_posix()],text=True).strip()==p.as_posix()
    spec.append(dict(path='/home/lokad/lython-bench-checks/'+remote+'/observations.tgz',
        sha256=hashlib.sha256(p.read_bytes()).hexdigest(),size=p.stat().st_size,preservedLocal=p.resolve().as_posix(),tracked=True))
old=home.parent.parent/'text-cache-storage-r173/b518/space-recovery-command.py'
script=old.read_text(encoding='utf-8')
script='\n'.join('spec='+repr(spec) if line.startswith('spec=') else line for line in script.splitlines())+'\n'
script=script.replace('string-index-storage-b518','call-inputs-b519').replace('276512768',str(required))
script=script.replace("receipt=json.loads((p.parent/'archive-receipt.json').read_text());assert", "receipt=json.loads((p.parent/'archive-receipt.json').read_text());receipt=receipt.get('receipt',receipt);assert")
script=script.replace("assert plan['afterFreeBytes']>free and", "assert plan['afterFreeBytes']>"+str(required)+" and plan['afterFreeBytes']>free and")
compile(script,'b519-exact-space-proof','exec')
(home/'space-recovery-command.py').write_text(script,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=script,text=True,encoding='utf-8',capture_output=True)
(home/'space-recovery.log').write_text(done.stdout+'\n'+done.stderr,encoding='utf-8')
assert done.returncode==0,done.stderr
data=json.loads(done.stdout)
(home/'space-recovery.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print('Exact idle-space proof:', data.get('beforeFreeBytes'), 'to',data.get('afterFreeBytes'),'; removed copies',len(data.get('files',[])),'unavailable',data.get('unavailable',[]))
