from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks')
spec=[{'path': '/home/lokad/lython-bench-checks/string-index-storage-b518-20261109/observations.tgz', 'sha256': 'e60d3c24f961d024399a79027834c7efc78edb563a09e2c8a5637ef46477a57e', 'size': 4050731, 'preservedLocal': 'D:/code/Lython/benchmarks/results/2026-11-09-optional-string-index-metadata/observations.tgz', 'tracked': True}, {'path': '/home/lokad/lython-bench-checks/dispatch-liveness-b486-20261109/observations.tgz', 'sha256': 'cb290981cdddeb718fcfeb44c9a2d67b6c7ed4603ab747692d695c411d4b48b0', 'size': 3796206, 'preservedLocal': 'D:/code/Lython/benchmarks/results/2026-11-09-dispatch-liveness/observations.tgz', 'tracked': True}, {'path': '/home/lokad/lython-bench-checks/text-read-lifetime-b485-20261108/observations.tgz', 'sha256': '0937d726f8127cdf8727e083e42f7b35af5b2cd56d50152b6f0a2fb4adbeed3c', 'size': 3795048, 'preservedLocal': 'D:/code/Lython/benchmarks/results/2026-11-09-text-read-lifetimes/observations.tgz', 'tracked': True}, {'path': '/home/lokad/lython-bench-checks/cpython-checkpoint-b517-20261109/observations.tgz', 'sha256': 'df152e38e1e993cda80222493814cdcb5b1a1e64582b94b2c95a8440b9c32f9a', 'size': 2008876, 'preservedLocal': 'D:/code/Lython/benchmarks/results/2026-11-09-current-cpython-checkpoint/observations.tgz', 'tracked': True}]
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not (base/'call-inputs-b519-20261109').exists()
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*')) and not Path('/dev/shm/lython-b512').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 free=shutil.disk_usage(base).free
 if free>270856192:
  print(json.dumps(dict(skipped=True,beforeFreeBytes=free,requiredFreeBytes=270856192,reason='Fresh space sufficient; no mutation')));__import__('sys').exit(0)
 rows=[];unavailable=[]
 for entry in spec:
  p=Path(entry['path'])
  if not p.exists():unavailable.append(entry['path']);continue
  assert p.resolve(strict=True)==p and p.parent.parent==base and p.name=='observations.tgz'
  info=p.lstat();assert stat.S_ISREG(info.st_mode) and info.st_nlink==1 and info.st_uid==os.getuid() and info.st_gid==os.getgid()
  assert info.st_size==entry['size'] and hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256']
  receipt=json.loads((p.parent/'archive-receipt.json').read_text());receipt=receipt.get('receipt',receipt);assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['archiveSHA256']==entry['sha256']
  parents=[]
  for parent in p.parents:
   meta=parent.lstat();assert stat.S_ISDIR(meta.st_mode) and not parent.is_symlink()
   parents.append(dict(path=str(parent),uid=meta.st_uid,gid=meta.st_gid,mode=oct(meta.st_mode)))
  rows.append(dict(**entry,device=info.st_dev,inode=info.st_ino,links=info.st_nlink,uid=info.st_uid,gid=info.st_gid,mode=oct(info.st_mode),parents=parents,allAliases=[str(p)]))
  if free+sum(Path(e['path']).stat().st_blocks*512 for e in rows)>270856192:break
 assert free+sum(Path(e['path']).stat().st_blocks*512 for e in rows)>270856192, ('Exact copies cannot fund unchanged payload/floors; no mutation',dict(freeBytes=free,requiredBytes=270856192,selectedBytes=sum(Path(e['path']).stat().st_blocks*512 for e in rows),unavailable=unavailable))
 plan=dict(requiredFreeBytes=270856192,freshIdleLease=True,beforeFreeBytes=free,osFloorMiB=240,evidenceHeadroomMiB=12,files=rows,unavailable=unavailable,operation='Remove only redundant remote compressed archives. Their raw trees, receipts, frozen workers and byte-identical tracked local archives survive.')
 target=base/'call-inputs-b519-space-plan.json'
 with target.open('x') as f:f.write(json.dumps(plan,indent=2)+'\n');f.flush();os.fsync(f.fileno())
 for entry in rows:
  p=Path(entry['path']);info=p.lstat()
  assert info.st_dev==entry['device'] and info.st_ino==entry['inode'] and info.st_nlink==1 and hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256']
  p.unlink()
 plan['afterFreeBytes']=shutil.disk_usage(base).free
 assert plan['afterFreeBytes']>270856192 and plan['afterFreeBytes']>free and plan['afterFreeBytes']>(240+12)*1024*1024
 (base/'call-inputs-b519-space-receipt.json').write_text(json.dumps(plan,indent=2)+'\n')
 print(json.dumps(plan))
