from pathlib import Path
import json, statistics

home = Path(__file__).parent
summary = {}
for label in ['warm-sync','warm-async','compile-sync']:
    data = json.loads((home/label/'measurements.json').read_text(encoding='utf-8'))
    assert all(data[k] for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
    field = 'elapsedMilliseconds' if label=='compile-sync' else 'executionMilliseconds'
    rows = []
    for case in data['observations']:
        values = {role: {name: statistics.median(s[key]/s['jobs'] for s in case['samples'] if s['image']==role)
                   for name, key in [('bytes','allocatedBytes'), ('elapsedMs',field)]}
                  for role in ['before','before-control','candidate']}
        row = dict(case=case['caseId'], roles=values,
            allocationPercent=[100*(values['candidate']['bytes']/values[b]['bytes']-1) for b in ['before','before-control']],
            elapsedPercent=[100*(values['candidate']['elapsedMs']/values[b]['elapsedMs']-1) for b in ['before','before-control']],
            boundary='Compile construction/disposal plus driver/reflection overhead; no execution or I/O.' if label=='compile-sync' else 'Warm mediated I/O, full goldens and prior-result cleanup; startup/reset/protocol/final caches excluded.')
        rows.append(row)
        print(label, row['case'], 'allocation', [round(v,2)for v in row['allocationPercent']], 'elapsed', [round(v,2)for v in row['elapsedPercent']], flush=True)
    summary[label]=rows
summary['analysisCorrection']='Original summary attempted to divide zero guest execution time in compile-only lane. All three existing raw lane measurements/gates completed; only offline analysis corrected. No retiming.'
summary['limitations']='Desktop isolated ALCs share process JIT/GC; elapsed is diagnostic, no CPU or equivalence claim. Changes are relative to two identical qualified production roles, not CPython.'
(home/'assessment.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
