from pathlib import Path
import hashlib, json, os, subprocess

root=Path('D:/code/Lython')
home=Path(__file__).parent
identity=json.loads((home/'refined/identity.json').read_text(encoding='utf-8'))
baseline=json.loads((home/'baseline.json').read_text(encoding='utf-8'))
for name,digest in identity['productionSources'].items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
changes=[name for name,digest in identity['productionSources'].items() if baseline['productionSources'][name]!=digest]
assert len(changes)==6,changes
for name in changes:
    path=Path(name)
    relative=path.relative_to(root/'src/Lokad.Lython')
    snapshot=home/'refined/source'/relative
    snapshot.parent.mkdir(parents=True,exist_ok=True)
    snapshot.write_bytes(path.read_bytes())
    original=home/'before-source'/relative
    if not original.exists():original=home.parent/'machine-integers-r174/initial-source'/relative
    data=original.read_bytes()
    assert hashlib.sha256(data).hexdigest()==baseline['productionSources'][name],str(original)
    path.write_bytes(data)  # fresh timestamps; do not restore metadata
for name,digest in baseline['productionSources'].items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name

path=root/'docs/RUNTIME.md'
text=path.read_text(encoding='utf-8')
old='''original read spans in cold metadata. An adjacent call-argument suffix made entirely
of these reads is prepared by the call instruction, after target lookup and before
binding. Argument checks and order remain; the existing admitted packet keeps its
evaluated references across context promotion, constructors and asynchronous work.
Resumption uses that packet rather than rereading caller locals. Closed native
helper proofs keep their separate operand domain. One shape pass after forwarding prepares'''
assert text.count(old)==1
path.write_text(text.replace(old,'original read spans in cold metadata. One shape pass after forwarding prepares'),encoding='utf-8',newline='\n')
path=root/'CHANGELOG.md'
text=path.read_text(encoding='utf-8')
old='''- Prepare adjacent local/constant call arguments in the existing executable call
  path, retaining evaluation order, source diagnostics and pending argument owners.

'''
assert text.count(old)==1
path.write_text(text.replace(old,''),encoding='utf-8',newline='\n')
env=os.environ.copy()
env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11'
env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
checks={}
for framework in ['net11.0','net10.0']:
    for label,args in [
        ('restored-build-'+framework,['build','src/Lokad.Lython','-c','Release','-f',framework,'--no-restore','--no-incremental']),
        ('retained-regressions-'+framework,['test','tests/Lokad.Lython.PublicApi.Tests','-c','Release','-f',framework,'--no-restore','--filter','FullyQualifiedName~CallInputLifetimeTests|FullyQualifiedName~OperandReadFailureTests|FullyQualifiedName~NumericIngressContractTests'])]:
        with(home/(label+'.log')).open('w',encoding='utf-8')as out:
            done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe',*args],env=env,stdout=out,stderr=subprocess.STDOUT)
        text=(home/(label+'.log')).read_text(encoding='utf-8')
        print(label,done.returncode,text[-380:],flush=True)
        assert done.returncode==0,label
        checks[label]=dict(exitCode=0,tail=text[-500:])
checks.update(productionRestoredExactly=True,sourceRestoreUsedFreshTimestamps=True,testsRelaxed=0,
    originalInternalEachFramework=537,originalPublicEachFramework=2831,originalFullPublicNet11=16931,
    refined=json.loads((home/'refined/qualification.json').read_text(encoding='utf-8')),
    decision='Withdraw both runtime variants, retain semantic tests and all original/refined evidence. No demonstrated whole-script CPU gain; compiler allocation grew and argument reads/copies remained. Not a permanent design veto.',
    limitations='Initial full public/quiet qualification is not relabelled as refined source; no repeated full platform/Stress/package checks for discarded prototypes. Production equals previously qualified cac4acf8.')
(home/'qualification.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8')
plan=root/'PLAN.md'
text=plan.read_text(encoding='utf-8')
start=text.index('1. **R175')
end=text.index('\n2. **Call/frame',start)
text=text[:start]+'''1. **R174/R175 bounded batches closed; select a coherent value pipeline next.**
   R174 raw Int64 results saved6.91% text allocation but violated documented
   BigInteger projection; two externally observable tests retained. Both variants
   removed, original/refined timings and136numeric/42admission checks preserved.

   R175 ordinary call-input forwarding removed14CSV/9text/8report root instructions,
   but retained reads/copies in a new preparation loop. Initial537/2831eachtarget,
   full16931public11; refined576/3886eachtarget. B519141.267s initial async text
   +2.71..5.14%; B520141.365s refined controls overlap, possible Unicode0..5.30%
   cost. Both quiet five-job owners fully archived/verified/retired. No general
   CPU gain/equivalence. Runtime allocation flat, compiler allocation+0.29..0.66%
   after deleting duplicate per-argument metadata. Withdraw all six production
   files/helpers/flags; source exactly qualified cac4acf8. Keep seven public
   semantic cases, no relaxed assertions. Forced builds and retained regressions
   pass actual11/10. This is not a fixed-percentage veto or permanent rejection of
   compiler call sources. No more unchanged timing in this bounded batch.

   R176 proposed source/proof milestone: contract-preserving machine integers,
   building on R174's demonstrated box traffic. Assess a private24B immutable
   scalar representation, not a universal tagged VM or raw-long public output.
   Keep host scalar ingress round trips and all public guest results BigInteger;
   preserve guest identity/aliases, methods, hashing, mixed arithmetic and exact
   promotion. Centralize literal/arithmetic production and common numeric consumers,
   rather than add an increment special case. Public projection must admit its
   output/replacement overlap and retain existing owners; no scalar identity ledger,
   cache, pool, new budget or policy. Name affected producers/consumers and code
   displaced before prototyping. First bounded source inventory must show that a
   coherent migration is feasible; stop at a concrete compatibility/ownership
   obstacle rather than widen automatically. A complete candidate needs focused
   semantic/cancellation/refusal/retention checks and whole CSV/text/report/config
   controls. Projection and alias compatibility are gates, not deferred cleanup.

   Native dictionary ambient-context hypothesis assessed: common updates already
   TryWriteKeyWithoutAdmission before PushAmbient. No second native fast path or
   retiming justified by that premise. Broader frame/span work stays item2.
''' + text[end:]
text=text.replace('R174 removed after measured allocation/public-contract assessment; R175 source phase next. No uncommitted runtime prototype.',
    'R174/R175 prototypes fully removed after bounded source pairs; R176 source/proof phase next. No uncommitted runtime prototype.')
text=text.replace('VM lokad@20.166.121.73, key ~/.ssh/id_lython-bench.pem. B518 terminal/all evidence',
    'VM lokad@20.166.121.73, key ~/.ssh/id_lython-bench.pem. B519/B520 terminal/all evidence')
plan.write_text(text,encoding='utf-8',newline='\n')
print('Both R175 variants completely withdrawn; source exactly qualified baseline, retained semantics green.')
