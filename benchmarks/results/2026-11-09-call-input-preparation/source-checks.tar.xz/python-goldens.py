from pathlib import Path
import hashlib, json, re, subprocess, textwrap

home=Path(__file__).parent
test=Path('tests/Lokad.Lython.PublicApi.Tests/CallInputLifetimeTests.cs').read_text(encoding='utf-8')
folder=home/'python-goldens'
folder.mkdir()
record=[]
source=textwrap.dedent(re.search(r'const string source = """\n(.*?)\n\s*""";',test,re.S).group(1))
rows=[('keywords',source,"['target', 'argument'] ((1, 2), {'last': 3})\nTrue\n",False)]
template=textwrap.dedent(re.search(r'var source = \$\$"""\n(.*?)\n\s*""";',test,re.S).group(1))
for label,expression in [('function',"check(value,value,'called')"),('constructor',"Holder(value,value,'called').same")]:
    body=re.sub(r'\{\{.*?\}\}',expression,template)
    source='def run_case():\n'+textwrap.indent(body,'    ')+'\nreturned = run_case()\nassert returned == [7]\n'
    rows.append((label,source,'True\n',True))
for label,source,expected,files in rows:
    work=folder/label
    work.mkdir()
    (work/'workload.py').write_text(source,encoding='utf-8',newline='\n')
    if files:(work/'events.txt').write_text('before',encoding='utf-8')
    done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','workload.py'],cwd=work,capture_output=True,check=True)
    output=done.stdout.replace(b'\r\n',b'\n').decode('utf-8')
    assert output==expected and not done.stderr,(label,output)
    if files:assert(work/'events.txt').read_bytes()==b'beforecalled'
    record.append(dict(case=label,sourceSHA256=hashlib.sha256(source.encode()).hexdigest(),expectedOutput=expected,files={'events.txt':'beforecalled'}if files else{},
                       wrapper='Top-level guest return wrapped in a Python function; return list asserted separately.'if files else None))
(home/'python-goldens.json').write_text(json.dumps(dict(reference=subprocess.check_output(['C:/Python313/python.exe','--version'],text=True).strip(),records=record,
    purpose='Independent semantic goldens only, not timing or cancellation. Windows physical stdout CRLF normalized to logical LF.'),indent=2)+'\n',encoding='utf-8')
print('Three independent Python3.13 semantic goldens match; no timing claim.')
