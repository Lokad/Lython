from pathlib import Path
import hashlib, json, shutil

root=Path('D:/code/Lython')
home=Path(__file__).parent
identity=json.loads((home/'identity.json').read_text(encoding='utf-8'))
for name,digest in identity['productionSources'].items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
refined=home/'refined'
refined.mkdir()
shutil.copytree(home/'images/before',refined/'images/before')
shutil.copyfile(home/'catalog.json',refined/'catalog.json')
names=['Frontend/ExecutableScript.cs','Frontend/ExecutableStackLayout.cs','Frontend/ExecutableScript.NativeReturns.cs',
       'Frontend/ExecutableScript.InputSpans.cs','Runtime/LythonRuntime.Executable.Calls.Invoke.cs',
       'Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs']
for name in names:
    p=root/'src/Lokad.Lython'/name
    snapshot=home/'original-source'/name
    snapshot.parent.mkdir(parents=True,exist_ok=True)
    snapshot.write_bytes(p.read_bytes())

def edit(name,old,new,count=1):
    path=root/'src/Lokad.Lython'/name
    text=path.read_text(encoding='utf-8')
    assert text.count(old)==count,(name,text.count(old))
    path.write_text(text.replace(old,new),encoding='utf-8',newline='\n')

edit('Frontend/ExecutableScript.cs', '        NativeInput = int.MaxValue;\n        SourceInput = int.MaxValue;', '        PreparedInput = int.MaxValue;')
edit('Frontend/ExecutableScript.cs', '    public int NativeInput { get; init; }\n    public int SourceInput { get; init; }', '    public int PreparedInput { get; init; }')
edit('Frontend/ExecutableScript.cs',
'''    // NativeInput names closed proof nodes; SourceInput names ordinary locals
    // and constants. Only a complete adjacent argument suffix is forwarded.
    public bool HasDirectInputs => Arguments.Length != 0 && Arguments[0].SourceInput != int.MaxValue;''',
'''    // PreparedInput belongs either to a closed native proof or ordinary
    // forwarded sources. The compiler chooses one domain before publication;
    // native helpers already bypass ordinary argument preparation.
    public bool HasDirectInputs { get; internal set; }''')
edit('Frontend/ExecutableScript.cs', '? Arguments[index].NativeInput : int.MaxValue;', '? Arguments[index].PreparedInput : int.MaxValue;')
edit('Frontend/ExecutableScript.NativeReturns.cs', 'NativeInput = stack[start + 1 + a].Value', 'PreparedInput = stack[start + 1 + a].Value')
edit('Frontend/ExecutableStackLayout.cs',
    '                if (instruction.OpCode == ExecutableOpCode.Call)\n',
    '                if (instruction.OpCode == ExecutableOpCode.Call && code.NativeBody is null)\n')
edit('Frontend/ExecutableStackLayout.cs',
    '                            call.Arguments[argument] = call.Arguments[argument] with { SourceInput = source };',
    '                            call.Arguments[argument] = call.Arguments[argument] with { PreparedInput = source };')
edit('Frontend/ExecutableStackLayout.cs',
'''                            if (readSpan is not null) reads.Add((block, kept, argument, readSpan));
                        }
                    }''',
'''                            if (readSpan is not null) reads.Add((block, kept, argument, readSpan));
                        }
                        call.HasDirectInputs = true;
                    }''')
edit('Runtime/LythonRuntime.Executable.Calls.Invoke.cs', 'call.Arguments[argument].SourceInput', 'call.Arguments[argument].PreparedInput')
measure=(home/'measure.py').read_text(encoding='utf-8').replace("home.parent/'bulk-whitespace-r157/tool/out/complete-jobs.dll'", "home.parent.parent/'bulk-whitespace-r157/tool/out/complete-jobs.dll'")
measure=measure.replace("elapsedPercent=[100*(values['candidate']['elapsedMs']/values[b]['elapsedMs']-1) for b in ['before','before-control']])", "elapsedPercent=None if phase=='compile' else [100*(values['candidate']['elapsedMs']/values[b]['elapsedMs']-1) for b in ['before','before-control']])")
measure=measure.replace("[round(v,2) for v in row['elapsedPercent']]", "None if row['elapsedPercent'] is None else [round(v,2) for v in row['elapsedPercent']]")
(refined/'measure.py').write_text(measure,encoding='utf-8',newline='\n')
(refined/'assess.py').write_text((home/'assess.py').read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
plan=root/'PLAN.md'
text=plan.read_text(encoding='utf-8')
text=text.replace('   Source assessment next: actual call shapes, cold unbound-read spans, stack\n   capacity and constructor reentry.',
'''   Initial implementation passes537internal/2831public each11/10, full16931public
   .NET11. Root instruction counts CSV93→79/text74→65/report58→50. B519 quiet5jobs
   141.267s/allgates: sync text−2.66..+0.22%, async+2.71..5.14% adverse; no general
   gain. Runtime allocation flat, compilation+0.41..0.86%. All originals preserved.
   Active refinement removes the new per-argument source field: existing prepared
   inputs serve ordinary code only when NativeBody is absent. One compiler-only
   call-site fact discriminates the domain; no invocation prepared-state flag.
   Cold unbound-read spans, capacity, constructor reentry already checked.''')
text=text.replace('   Displace per-leaf load opcode dispatch, not argument reads/checks or packet\n   lifetime. Add one source int to existing argument metadata, no runtime allocation.',
'''   Displace per-leaf load opcode dispatch, not argument reads/checks or packet
   lifetime. Reuse the existing input int; remove duplicate metadata. No runtime
   allocation or new execution route.''')
plan.write_text(text,encoding='utf-8',newline='\n')
print('Original source/quiet adversity retained; refined compiler metadata shares the existing prepared-input field.')
