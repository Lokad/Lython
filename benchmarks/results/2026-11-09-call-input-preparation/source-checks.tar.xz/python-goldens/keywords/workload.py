events=[]
class Target:
    def __getattribute__(self,name):
        events.append('target')
        return lambda *args,**kwargs: (args,kwargs)
def later():
    events.append('argument')
    return 2
result=Target().method(1,later(),last=3)
print(events,result)
def check(*args,last):
    return args[0] is args[1] and args[-1] is last
value=[]
print(check(value,value,1,2,3,value,last=value))