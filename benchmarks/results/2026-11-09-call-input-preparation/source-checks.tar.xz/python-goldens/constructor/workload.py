def run_case():
    class Holder:
        def __init__(self, first, second, marker):
            with open('events.txt','a') as target: target.write(marker)
            self.same = first is second and first == [7]
    def check(first, second, marker):
        with open('events.txt','a') as target: target.write(marker)
        return first is second and first == [7]
    def main():
        value = [7]
        same = Holder(value,value,'called').same
        print(same)
        return value
    return main()
returned = run_case()
assert returned == [7]
