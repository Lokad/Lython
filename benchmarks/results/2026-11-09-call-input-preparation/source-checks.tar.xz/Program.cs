using System.Collections;
using System.Reflection;
using System.Runtime.Loader;
using System.Text.Json;

var core = AssemblyLoadContext.Default.LoadFromAssemblyPath(Path.GetFullPath(args[0]));
var engineType = core.GetType("Lokad.Lython.LythonEngine")!;
var engine = Activator.CreateInstance(engineType)!;
var compile = engineType.GetMethod("Compile", [typeof(string)])!;
using var catalog = JsonDocument.Parse(File.ReadAllText(args[1]));
var rows = new List<object>();
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    using var script = (IDisposable)compile.Invoke(engine, [item.GetProperty("source").GetString()!])!;
    if (!(bool)Get(script, "IsValid")) throw new Exception("Invalid source: " + item.GetProperty("id"));
    var runner = (Delegate)script.GetType().GetField("_runner", BindingFlags.Instance | BindingFlags.NonPublic)!.GetValue(script)!;
    var target = runner.Target!;
    var executable = target.GetType().GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)
        .Select(f => f.GetValue(target)).Single(v => v?.GetType().FullName == "Lokad.Lython.Frontend.ExecutableScript")!;
    var codeRows = new List<object>();
    Visit(Get(executable, "EntryPoint"));
    rows.Add(new { caseId = item.GetProperty("id").GetString(), code = codeRows });

    void Visit(object code)
    {
        var instructions = ((IEnumerable)Get(code, "Instructions")).Cast<object>().ToArray();
        var calls = ((IEnumerable)Get(code, "CallSites")).Cast<object>().ToArray();
        var captures = ((IEnumerable)Get(code, "CapturedLocalSlots")).Cast<int>().ToHashSet();
        var mirrored = (bool)Get(code, "RequiresLocalVariableMirroring");
        var candidates = new List<object>();
        for (var index = 0; index < instructions.Length; index++)
        {
            if (Get(instructions[index], "OpCode").ToString() != "Call") continue;
            var call = calls[(int)Get(instructions[index], "CallSiteIndex")];
            var count = (int)Get(call, "ArgumentCount");
            if (count == 0 || index < count) continue;
            var leaves = instructions[(index-count)..index];
            if (!leaves.All(leaf => Get(leaf, "OpCode").ToString() == "LoadConst" ||
                    Get(leaf, "OpCode").ToString() == "LoadLocal" && !mirrored && !captures.Contains((int)Get(leaf, "LocalSlot")))) continue;
            candidates.Add(new { instruction = index, count, span = Get(call, "CallSpan") });
        }
        codeRows.Add(new { name = Get(code, "Name"), mirrored, instructions = instructions.Length,
            opcodes = instructions.GroupBy(i => Get(i,"OpCode").ToString()!).ToDictionary(g => g.Key, g => g.Count()),
            nativeBody = code.GetType().GetProperty("NativeBody")!.GetValue(code) is not null, candidates });
        foreach (var function in (IEnumerable)Get(code, "Functions")) Visit(Get(function!, "CodeObject"));
    }
}
File.WriteAllText(args[2], JsonSerializer.Serialize(rows, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine("Recorded compiled root/ordinary-function shapes; static opportunities, not dynamic CPU attribution.");

static object Get(object target, string name) => target.GetType().GetProperty(name, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic)!.GetValue(target)!;
