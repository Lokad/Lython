from pathlib import Path
import subprocess

home=Path(__file__).parent
refined=home/'refined'
source=(home/'prepare-vm.py').read_text(encoding='utf-8')
assert source.count("old = home.parent/'text-cache-storage-r173/b518'")==1
source=source.replace("old = home.parent/'text-cache-storage-r173/b518'", "old = home.parent.parent/'text-cache-storage-r173/b518'")
source=source.replace('b519','b520').replace('net11Internal=537,net10Internal=537,net11Public=2831,net10Public=2831,initialNet11Public=221', 'net11Internal=576,net10Internal=576,net11Public=3886,net10Public=3886')
source=source.replace('R175 ordinary call inputs, f9a84542 plus working patch;', 'R175 refined shared prepared-input metadata, f9a84542 plus working patch; initial B519 adversity retained;')
(refined/'prepare-vm.py').write_text(source,encoding='utf-8',newline='\n')
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(refined/'prepare-vm.py')],check=True)
dest=refined/'b520'
for filename in ['launch.py','prepare-retrieval.py']:
    text=(home/'b519'/filename).read_text(encoding='utf-8').replace('b519','b520')
    text=text.replace("home.parent.parent/'text-cache-storage-r173", "home.parent.parent.parent/'text-cache-storage-r173")
    (dest/filename).write_text(text,encoding='utf-8',newline='\n')
text=(home/'b519/recover-space.py').read_text(encoding='utf-8').replace('b519','b520')
text=text.replace("home.parent.parent/'text-cache-storage-r173", "home.parent.parent.parent/'text-cache-storage-r173")
start=text.index('for remote,local in [')
end=text.index("    assert subprocess.check_output",start)
text=text[:start]+'''for remote,local,filename in [
    ('helper-confirm-b480-20261108','2026-11-08-function-lookup-lifetimes','confirmation-observations.tgz'),
    ('prepared-binding-b483-20261108','2026-11-08-prepared-function-binding','initial-observations.tgz'),
    ('function-lookups-b479-20261108','2026-11-08-function-lookup-lifetimes','combined-observations.tgz'),
    ('cpython-checkpoint-b517-20261109','2026-11-09-current-cpython-checkpoint','observations.tgz')]:
    p=Path('benchmarks/results')/local/filename
'''+text[end:]
(dest/'recover-space.py').write_text(text,encoding='utf-8',newline='\n')
print('Final revised-source payload and exact candidate-copy proof prepared; no remote execution yet.')
