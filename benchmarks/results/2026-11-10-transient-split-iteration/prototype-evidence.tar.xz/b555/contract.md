# R203 bounded transient split collection comparison

Qualified f6798fd7 before1ac042d3 versus isolated refined101ba9d3. All future
word storage admitted before loop effects; exact direct/helper results use one
private native cursor instead of PyList/object[]. Escaping lists unchanged.
Original adverse desktop results and refinement remain preserved. Four complete
script jobs: report/CSV controls, text helpers sync/async; four independent
source/control processes,5s warmup/role,7rotated400msrounds.180sowner/30stop/30margin.
Stock GC/tiering, mediated RAM I/O/capture/projection/prior-result cleanup inside
warm clocks; compilation/reset/verification/protocol outside. Wider process CPU
is coarse and includes surrounds. No CPython timing or full candidate claim.
Replace old ed5 working baseline only after receiving/verifying the qualified
replacement payload; exact old core/raw copies remain in committed Git archive.
Fixed240MiBfloor/12MiBheadroom, never relaxed. No unrelated deletion.
