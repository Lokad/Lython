from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
config={'payloadBytes': 3779063, 'payloadSHA256': 'c4acd8cc98aacc1a6fd838c55a4132b135888c2a1e07280cb4e28777352053c0', 'required': 276516864, 'copies': [{'paths': ['coarse-admission-b554-20261110/baseline-core.dll', 'coarse-admission-b554-20261110/reference/Lokad.Lython.dll'], 'bytes': 5660160, 'sha256': 'ed5dbf70a423ec0c8239e382e76604b634aa757d55a775c364a0094d3d3c663e', 'canonical': 'benchmarks/results/2026-11-10-coarse-admission/quiet/observations.tgz:baseline-core.dll'}, {'paths': ['coarse-admission-b554-20261110/representative.json'], 'bytes': 753467, 'sha256': 'd64ade9f47ae23d99f28bd4292583d11cc9eb63f3c3a1aecc887e774c475d70a', 'canonical': 'benchmarks/results/2026-11-10-coarse-admission/quiet/observations.tgz:representative.json'}, {'paths': ['coarse-admission-b554-20261110/confirmation/confirmation.json'], 'bytes': 550264, 'sha256': '29886a04ab4c3f2a9d1b813c127d583e18f65fe1bd9f30add9d4ded926a96a8d', 'canonical': 'benchmarks/results/2026-11-10-coarse-admission/quiet/observations.tgz:confirmation/confirmation.json'}], 'expectedCores': {'reference': '1ac042d34a9b4f27297fc9354a2dfd9b55a9f9abe229bb33c85bbb3c01a94a19', 'reference-control': '1ac042d34a9b4f27297fc9354a2dfd9b55a9f9abe229bb33c85bbb3c01a94a19', 'candidate': '101ba9d3e5237b8d0da09689a94abf9b7dbbe276634becedac61e859e84ac897', 'candidate-control': '101ba9d3e5237b8d0da09689a94abf9b7dbbe276634becedac61e859e84ac897'}}
base=Path('/home/lokad/lython-bench-checks').resolve();root=base/'transient-split-b555-20261110';source=base/'deferred-method-b548-20261110/candidate';fixture=root/'guest-fixtures'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists()and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[c]omplete-jobs.dll'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(config['payloadBytes']+1);assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:
  for name,role in [('baseline-core.dll','reference'),('current-core.dll','candidate')]:
   assert hashlib.sha256(a.extractfile(name).read()).hexdigest()==config['expectedCores'][role]
 assert hashlib.sha256((source/'Lokad.Lython.dll').read_bytes()).hexdigest()=='039dc975c341d77400e8df8189524480990b042d0694a2e60e27240abcfc61d1'
 prior=base/'json-cpython-b546-20261110/candidate/Lokad.Lython.dll'
 assert hashlib.sha256(prior.read_bytes()).hexdigest()=='e294fad194255fa086a3356a6adc57061ac3f764cc632f83bc459fa784f41ed9'
 protocol=base/'prepared-call-layout-b384-20261107/cpython-worker.py'
 assert hashlib.sha256(protocol.read_bytes()).hexdigest()=='02ca606af6b937a5bec8da744da36e6dbea45ef14ee7207732f34da052ad32f1'
 before=shutil.disk_usage(base).free;retired=[];reclaim=0
 if before<=config['required']:
  for copy in config['copies']:
   paths=[base/v for v in copy['paths']];first=paths[0].lstat();key=(first.st_dev,first.st_ino)
   for path in paths:
    st=path.lstat()
    assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(st.st_mode)and st.st_uid==os.getuid()
    assert(st.st_dev,st.st_ino)==key and st.st_nlink==len(paths)
    assert st.st_size==copy['bytes']and hashlib.sha256(path.read_bytes()).hexdigest()==copy['sha256']
   aliases=[]
   for folder,dirs,files in os.walk(base):
    for name in files:
     path=Path(folder)/name;st=path.lstat()
     if(st.st_dev,st.st_ino)==key:aliases.append(path.relative_to(base).as_posix())
   assert sorted(aliases)==sorted(copy['paths']),aliases
   reclaim+=first.st_blocks*512;retired.append(dict(copy,allocatedBytes=first.st_blocks*512,allHardlinkAliasesVerified=True))
  assert before+reclaim>config['required'],(before,reclaim,config['required'])
  for copy in config['copies']:
   for path in copy['paths']:(base/path).unlink()
 assert shutil.disk_usage(base).free>config['required']
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:root.mkdir();a.extractall(root,filter='data')
 recovery=dict(beforeFreeBytes=before,afterRecoveryFreeBytes=shutil.disk_usage(base).free,requiredFreeBytes=config['required'],freshIdleLease=True,verifiedReplacementInPayload=True,files=retired,osFloorMiB=240,evidenceHeadroomMiB=12,qualified039AndPriorE294Preserved=True)
 (root/'space-recovery.json').write_text(json.dumps(recovery,indent=2)+'\n')
 shutil.copyfile(protocol,root/'cpython-worker.py')
 for role in ['reference','candidate']:
  shutil.copytree(source,root/role,copy_function=os.link)
  (root/role/'Lokad.Lython.dll').unlink();os.link(root/('baseline-core.dll'if role=='reference'else'current-core.dll'),root/role/'Lokad.Lython.dll')
 identity=json.loads((root/'identity.json').read_text())
 for role in ['reference','candidate']:
  for name,digest in{**identity['auxiliaryFiles'],'Lokad.Lython.dll':identity['coreSHA256'][role]}.items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==digest,(role,name)
 assert hashlib.sha256((root/'representative.json').read_bytes()).hexdigest()==identity['catalogSHA256']
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b555-fixtures',str(fixture)],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,imagesVerified=True,jobs=4,ownerSeconds=180,stopSeconds=30,marginSeconds=30,osFloorMiB=240,evidenceHeadroomMiB=12)
 assert setup['freeBytes']>252*1024*1024
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
try:
 subprocess.run(['sudo','-n','systemd-run','--unit=lython-b555-transient-split-20261110','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=180','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show','lython-b555-transient-split-20261110.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert'ActiveState=active'in live and'MainPID=0'not in live;print(live,flush=True)
