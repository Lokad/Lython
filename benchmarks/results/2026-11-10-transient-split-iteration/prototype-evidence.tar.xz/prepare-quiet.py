from pathlib import Path
import ast,hashlib,io,json,shutil,subprocess,tarfile

h=Path(__file__).resolve().parent;repo=h.parents[3];d=h/'diagnostic-refined';p=h/'b555';p.mkdir()
old=h.parent/'coarse-admission-r202/b554';source=json.loads((d/'identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((h/'tree'/n).read_bytes()).hexdigest()==v for n,v in source['source']['candidate'].items())
for phase in ['warm','warm-async']:
    raw=json.loads((d/phase/'measurements.json').read_text(encoding='utf-8'))
    assert all(raw[k]for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified','normalGcAndTiering'])
for a,b in [('catalog.json','representative.json'),('source.patch','source.patch'),('script-goldens.json','script-goldens.json')]:shutil.copyfile(d/a,p/b)
for role,name in [('before','baseline-core.dll'),('candidate','current-core.dll')]:shutil.copyfile(d/'images'/role/'Lokad.Lython.dll',p/name)
base=json.loads((old/'identity.json').read_text(encoding='utf-8'))
identity=dict(sourceRevision='R203 on fully qualified f6798fd7; root before1ac042d3, isolated refined101ba9d3. Candidate focused-tested, not full platform-qualified.',
    coreSHA256={role:source['cores']['before'if role.startswith('reference')else'candidate']for role in ['reference','reference-control','candidate','candidate-control']},
    auxiliaryFiles=base['auxiliaryFiles'],protocolSHA256=base['protocolSHA256'],catalogSHA256=base['catalogSHA256'],performanceQualified=False)
(p/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
minimal=dict(baseRevision=source['baseRevision'],cores=source['cores'],sourceDifferences=source['sourceDifferences'],
    fullLocalIdentitySHA256=hashlib.sha256((d/'identity.json').read_bytes()).hexdigest(),
    sourceGate='568 production files, eight normalized source differences, raw hashes and CRLF correction retained locally. Sequential forced builds; same auxiliaries.')
(p/'source-identity.json').write_text(json.dumps(minimal,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.report-render.large','warm'],['scripts.csv-validated-records.large','warm'],
      ['scripts.text-summary-helpers.large','warm'],['scripts.text-summary-helpers.large','warm-async']]
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
    s=(old/name).read_text(encoding='utf-8').replace('coarse-admission-b554-20261110','transient-split-b555-20261110')
    s=s.replace('lython-b554-coarse-admission-20261110','lython-b555-transient-split-20261110').replace('lython-b554-fixtures','lython-b555-fixtures').replace('B554','B555')
    if name=='collect.py':
        a=s.index('jobs=');b=s.index('\nassert len(jobs)',a);s=s[:a]+'jobs='+repr(jobs)+s[b:]
        s=s.replace('len(jobs)==6','len(jobs)==4').replace(' < 200',' < 140').replace('Reserve40seconds','Reserve40seconds')
        a=s.index("purpose='");b=s.index("',\n",a);s=s[:a]+"purpose='R203 private transient split collection removal, refined shared checks. Qualified before source, exact complete helper text with report/CSV controls and independent source controls; allocation, elapsed and wider CPU separate"+s[b:]
    if name=='archive-owned.py':s=s.replace("len(raw['jobs'])==6","len(raw['jobs'])==4").replace('jobs=6','jobs=4')
    if name=='retrieve.py':s=s.replace("['jobs']==6","['jobs']==4").replace("['elapsedSeconds']<240","['elapsedSeconds']<180").replace('six-job','four-job')
    if name.endswith('.py'):ast.parse(s)
    (p/name).write_text(s,encoding='utf-8',newline='\n')
canonical='benchmarks/results/2026-11-10-coarse-admission/quiet/observations.tgz'
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo)
assert blob==(repo/canonical).read_bytes()
copies=[]
with tarfile.open(fileobj=io.BytesIO(blob),mode='r:gz')as a:
    for name,paths in [('baseline-core.dll',['baseline-core.dll','reference/Lokad.Lython.dll']),
                       ('representative.json',['representative.json']),
                       ('confirmation/confirmation.json',['confirmation/confirmation.json'])]:
        b=a.extractfile(name).read()
        copies.append(dict(paths=['coarse-admission-b554-20261110/'+v for v in paths],bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),canonical=canonical+':'+name))
(p/'exact-copies.json').write_text(json.dumps(copies,indent=2)+'\n',encoding='utf-8',newline='\n')
(p/'contract.md').write_text('''# R203 bounded transient split collection comparison

Qualified f6798fd7 before1ac042d3 versus isolated refined101ba9d3. All future
word storage admitted before loop effects; exact direct/helper results use one
private native cursor instead of PyList/object[]. Escaping lists unchanged.
Original adverse desktop results and refinement remain preserved. Four complete
script jobs: report/CSV controls, text helpers sync/async; four independent
source/control processes,5s warmup/role,7rotated400msrounds.180sowner/30stop/30margin.
Stock GC/tiering, mediated RAM I/O/capture/projection/prior-result cleanup inside
warm clocks; compilation/reset/verification/protocol outside. Wider process CPU
is coarse and includes surrounds. No CPython timing or full candidate claim.
Replace old ed5 working baseline only after receiving/verifying the qualified
replacement payload; exact old core/raw copies remain in committed Git archive.
Fixed240MiBfloor/12MiBheadroom, never relaxed. No unrelated deletion.
''',encoding='utf-8',newline='\n')
with tarfile.open(p/'payload.tgz','w:gz')as a:
    for name in ['baseline-core.dll','current-core.dll','representative.json','identity.json','source-identity.json','source.patch','script-goldens.json','contract.md','collect.py','archive-owned.py','run.sh']:a.add(p/name,arcname=name)
with tarfile.open(p/'payload.tgz')as a:footprint=sum((m.size+4095)//4096*4096 for m in a.getmembers()if m.isfile())+128*1024
payload=(p/'payload.tgz').read_bytes()
(p/'footprint.json').write_text(json.dumps(dict(payloadBytes=len(payload),footprintBytes=footprint,requiredFreeBytes=252*1024*1024+max(3*len(payload),footprint),recoverableLogicalBytes=sum(c['bytes']for c in copies)),indent=2)+'\n',encoding='utf-8',newline='\n')
print((p/'footprint.json').read_text(encoding='utf-8'),flush=True)
