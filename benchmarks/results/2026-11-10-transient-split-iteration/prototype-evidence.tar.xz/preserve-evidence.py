from pathlib import Path
import hashlib,json,re,shutil,subprocess,tarfile

h=Path(__file__).resolve().parent;repo=h.parents[3];d=h/'diagnostic-refined';q=h/'b555';out=repo/'benchmarks/results/2026-11-10-transient-split-iteration';out.mkdir()
identity=json.loads((d/'identity.json').read_text(encoding='utf-8'))
for name,digest in identity['normalizedSource']['candidate'].items():
    assert hashlib.sha256((repo/name).read_text(encoding='utf-8').encode()).hexdigest()==digest,name
validation=[]
for tfm in ['net11.0','net10.0']:
    for kind in ['internal','public']:
        log=(h/f'delivery-{kind}-{tfm}.log').read_text(encoding='utf-8')
        assert 'Failed:     0' in log
        validation.append(dict(target=tfm,kind=kind,result=next(v for v in log.splitlines() if v.startswith('Passed!'))))
(out/'retained-validation.json').write_text(json.dumps(dict(focused=validation,build='Release solution forced nonincremental; zero warnings/errors, both actual targets.',source='f6798fd7 plus runtime.patch; normalized production source matches refined101ba9d3.',fullDelivery='Pending coherent platform/stress/installed-package qualification.'),indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'runtime.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src'],cwd=repo,stderr=subprocess.DEVNULL))
(h/'retained-tests.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','tests'],cwd=repo,stderr=subprocess.DEVNULL))
shutil.copyfile(repo/'tests/Lokad.Lython.PublicApi.Tests/ImmediateCasedSplitIterationTests.cs',h/'retained-new-public-tests.cs')
shutil.copyfile(h/'tree/tests/Lokad.Lython.PublicApi.Tests/ImmediateCasedSplitIterationTests.cs',h/'prototype-new-public-tests.cs')
shutil.copyfile(repo/'tests/Lokad.Lython.Tests/CasedSplitOwnershipTests.cs',h/'retained-ownership-tests.cs')
receipt=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'))
assert hashlib.sha256((q/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
quiet=out/'quiet';quiet.mkdir()
for name in ['observations.tgz','archive-receipt.json','summary.json','terminal-status.json','identity.json']:
    shutil.copyfile(q/name,quiet/name)
shutil.copyfile(q/'retrieved/space-recovery.json',out/'vm-baseline-replacement.json')
for variant in ['diagnostic','diagnostic-refined']:
    target=out/('desktop-original'if variant=='diagnostic'else'desktop-refined');target.mkdir()
    for phase in ['warm','warm-async']:
        (target/phase).mkdir()
        for name in ['measurements.json','summary.json','stderr.txt']:shutil.copyfile(h/variant/phase/name,target/phase/name)
with tarfile.open(out/'prototype-evidence.tar.xz','w:xz')as a:
    for path in sorted(h.iterdir()):
        if path.is_file()and path.suffix in ['.py','.json','.log','.cs','.patch']:
            a.add(path,arcname=path.name)
    for variant in ['diagnostic','diagnostic-refined']:
        for name in ['identity.json','source.patch','script-goldens.json','catalog.json','hash-witness.json']:
            a.add(h/variant/name,arcname=variant+'/'+name)
    a.add(h/'diagnostic/images/candidate/Lokad.Lython.dll',arcname='original-candidate-core.dll')
    for path in sorted(q.iterdir()):
        if path.is_file()and path.suffix in ['.py','.json','.log','.md','.sh']:
            a.add(path,arcname='b555/'+path.name)
ci=repo/'.git/agent-notes/review-20261031/coarse-admission-r202/full-delivery-observation.json'
green=json.loads(ci.read_text(encoding='utf-8'))
assert green['conclusion']=='success'and green['headSha']=='f6798fd7bc4f65f137b107f7121496ef3e73f44f'
shutil.copyfile(ci,repo/'benchmarks/results/2026-11-10-coarse-admission/retained-delivery-ci.json')
(out/'README.md').write_text('''# R203 — private split-result iteration

2026-11-10. Qualified f6798fd7 before1ac042d3 versus isolated refined101ba9d3;
the [retained patch](runtime.patch) has identical normalized production source.
Sequential forced nonincremental .NET11RC3 builds, identical039 worker/auxiliaries,
optional adapter0.4 and existing complete scripts/fixtures/goldens. Original
candidate1d0bea78 is preserved separately. Neither comparison labels the candidate
fully platform-qualified; [focused retained checks](retained-validation.json) pass
212internal/617public cases on each actualNET11/10, with a zero-warning Release build.

Compiler-proven immediate consumption of an exact lower/upper whitespace split
uses one private cursor in the existing native iteration engine. It replaces the
PyList shell/object array across direct and closed-helper calls. One shared forward
scanner serves ordinary materialization, initial sizing and cursor movement;
the shared UTF-8 casing writer produces independently owned words. All future
word capacities and cursor metadata are admitted before loop-body effects.
The immutable source and unused conservative capacity stay funded through their
owners. Escaping/assigned lists, dynamic targets, protocols and genuine suspension
retain ordinary execution. No new public option, allowance, pool, tracing or engine.

Original desktop elapsed text +0.71..+4.14%sync/+0.01..+2.38%async, allocation
−5.18..−5.19%, with moving unchanged controls. One source-guided refinement removes
only two newly added duplicate cursor checks. Existing ForNext, scanner/writer
and publication checks remain; focused cancellation/refusal/cleanup still pass.
Refined desktop text −2.14..+0.46%sync/−1.22..−0.41%async, allocation unchanged;
CSV sync +4.43..+6.03% and other variable/adverse controls remain. These desktop
run-only clocks are diagnostic; wider envelope/CPU and all raw samples survive.
[Original](desktop-original/warm/summary.json), [refined](desktop-refined/warm/summary.json),
[source, original conditions, both identities, scripts and test logs](prototype-evidence.tar.xz).

B555: four jobs144.648s, F4as_v7 Ubuntu24.04.4/.NET11RC3, stock GC/tiering,
four independent source/control processes,5s warmup/role and7rotated400msrounds.
All identity/golden/ownership/quiet/join/RAM/archive/localSHA gates pass.

| Complete script | Candidate elapsed change | Wider process CPU change |
| --- | ---: | ---: |
| Report, sync | −3.82..+0.54% | −3.88..+0.02% |
| CSV validation, sync | +0.12..+0.42% | −1.30..−0.99% |
| Text helpers, sync | −3.21..−1.04% | −3.28..−0.84% |
| Text helpers, async API | −11.14..−2.32% | −9.58..+0.20% |

Ranges compare both candidates with both references, not confidence intervals.
Sync text has supporting CPU evidence; CSV elapsed is essentially flat. Report
reference spread3.99% and async-text reference spread9.14% leave their effect
uncertain. Async does not establish an11% gain. Allocation falls about5.2% in both
APIs in the separate desktop allocation measurement. CPU, allocation and storage
simplification remain distinct. [Raw cores/observations](quiet/observations.tgz),
[receipt](quiet/archive-receipt.json), [medians/controls](quiet/summary.json).

Quiet clocks include mediated RAM file I/O, capture/projection and prior-result
cleanup; exclude compilation, fixture reset, verification and protocol. Wider CPU
includes those surrounds and coarse ticks. This is a Lython source pair, not a new
CPython comparison. Compilation/startup and real I/O latency are unmeasured here.
Existing CPython rows keep their original source identities.

Decision: retain the complete producer/consumer change for actual collection
storage removal, about5.2% less allocation and modest supporting sync CPU.
The preparatory scanner alone was never promoted. Report/async uncertainty and
desktop adversity stay explicit. This does not close the whole-script objective;
next source gate examines prepared call arguments and operand transport, without
another call arena/control loop. Cancellation, refusal before body effects,
Unicode expansions/final sigma/all29whitespaces, default/keyword/direct calls,
generators, aliases, genuine I/O suspension, awaited cleanup and budget reuse pass.
Public checks also retain rsplit Unicode coverage and escaping mutable-list behavior.

The old ed5 working baseline and two exact raw copies were retired only after
receiving/verifying the new qualified-source baseline and matching all inode
aliases, UID/path and committed Git archive bytes. [Replacement proof](vm-baseline-replacement.json).
Qualified039/priorE294 survive; fixed240MiBfloor/12MiBsetupheadroom remain.
No remaining VM users or RAM fixtures. Publication/tagging remain postponed.
''',encoding='utf-8',newline='\n')
print(json.dumps(dict(evidence=out.relative_to(repo).as_posix(),archiveBytes=(out/'prototype-evidence.tar.xz').stat().st_size,focused=validation),indent=2),flush=True)
