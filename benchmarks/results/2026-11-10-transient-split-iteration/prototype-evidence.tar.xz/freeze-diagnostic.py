from pathlib import Path
import hashlib,json,os,shutil,subprocess

h=Path(__file__).resolve().parent
root=h.parents[3]
assert root.name=='Lython' and (root/'.git').is_dir(), root
t=h/'tree';d=h/'diagnostic';d.mkdir()
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11'
env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH'];dotnet=env['DOTNET_ROOT']+'/dotnet.exe'
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert revision=='f6798fd7bc4f65f137b107f7121496ef3e73f44f'
assert not subprocess.check_output(['git','diff','--','src'],cwd=root)
for log in ['phase-c-internal-net11.0.log','phase-c-public-net11.0.log',
            'phase-bc-internal-net10.0.log','phase-bc-public-net10.0.log']:
    assert 'Failed:     0' in (h/log).read_text(encoding='utf-8'),log
common=h.parent/'deferred-method-r198/diagnostic/images/candidate'
assert hashlib.sha256((common/'Lokad.Lython.dll').read_bytes()).hexdigest()=='039dc975c341d77400e8df8189524480990b042d0694a2e60e27240abcfc61d1'
source={};cores={}
for role,tree in [('before',root),('candidate',t)]:
    shutil.copytree(common,d/'images'/role)
    with (h/('freeze-'+role+'.log')).open('w',encoding='utf-8') as log:
        result=subprocess.run([dotnet,'build',str(tree/'src/Lokad.Lython/Lokad.Lython.csproj'),
            '-c','Release','-f','net11.0','--no-incremental'],env=env,stdout=log,stderr=subprocess.STDOUT)
    assert result.returncode==0,role
    shutil.copyfile(tree/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',d/'images'/role/'Lokad.Lython.dll')
    cores[role]=hashlib.sha256((d/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest()
    source[role]={p.relative_to(tree).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
                  for p in (tree/'src/Lokad.Lython').rglob('*.cs') if 'obj' not in p.parts}
    print(role,cores[role],flush=True)
differences=[name for name in source['before'] if source['before'][name]!=source['candidate'][name]]
assert len(differences)==8,differences
assert all(p.read_bytes()==(d/'images/candidate'/p.relative_to(d/'images/before')).read_bytes()
    for p in (d/'images/before').rglob('*') if p.is_file() and p.name!='Lokad.Lython.dll')
old=h.parent/'coarse-admission-r202/diagnostic'
for name in ['catalog.json','hash-witness.json','script-goldens.json']:shutil.copyfile(old/name,d/name)
catalog=json.loads((d/'catalog.json').read_text(encoding='utf-8'))
goldens=json.loads((d/'script-goldens.json').read_text(encoding='utf-8'))
assert len(catalog['cases'])==5 and all(any(g['case']==c['id'] and g['sourceSHA256']==c['sourceSha256']
    and g['allGoldensPassed'] for g in goldens['cases']) for c in catalog['cases'])
(d/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src'],cwd=t,stderr=subprocess.DEVNULL))
identity=dict(baseRevision=revision,baseQualification='Cached GREEN42854501354 Windows/Ubuntu actualNET11/10 ordinary/stress/package; no repeat.',
    cores=cores,source=source,sourceDifferences=differences,
    candidate='Shared forward scanner; immediate-iteration call fact reaches exact cased split and closed helper returns. Fund all future words before body effects; independent words, one private cursor replaces PyList/object[]. No generic wrapper. Ordinary escapes materialize lists.',
    freeze='Sequential forced nonincremental NET11 builds from clean qualified root and isolated prototype. No source restoration. Identical auxiliary bytes from039.',
    catalogSHA256=hashlib.sha256((d/'catalog.json').read_bytes()).hexdigest(),
    status='Focused semantics passed; isolated source pair, not full candidate qualification or performance claim.')
(d/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(h.parent/'coarse-admission-r202/measure.py',h/'measure.py')
print(json.dumps(dict(cores=cores,sourceFiles=len(source['before']),differences=differences),indent=2),flush=True)
