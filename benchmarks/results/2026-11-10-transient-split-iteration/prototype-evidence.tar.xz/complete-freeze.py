from pathlib import Path
import hashlib,json,shutil,subprocess

h=Path(__file__).resolve().parent;root=h.parents[3];t=h/'tree';d=h/'diagnostic'
revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert revision=='f6798fd7bc4f65f137b107f7121496ef3e73f44f'
assert not subprocess.check_output(['git','diff','--','src'],cwd=root)
expected=dict(before='1ac042d34a9b4f27297fc9354a2dfd9b55a9f9abe229bb33c85bbb3c01a94a19',
              candidate='1d0bea7862e0c80fdbfac8149a9eff751ddfaa7a4fbaccaa04c5d62c1629e26c')
source={};normalized={}
for role,tree in [('before',root),('candidate',t)]:
    assert '0 Error(s)' in (h/('freeze-'+role+'.log')).read_text(encoding='utf-8')
    frozen=d/'images'/role/'Lokad.Lython.dll'
    assert hashlib.sha256(frozen.read_bytes()).hexdigest()==expected[role]
    assert frozen.read_bytes()==(tree/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll').read_bytes()
    files=[p for p in (tree/'src/Lokad.Lython').rglob('*.cs') if 'obj' not in p.parts]
    source[role]={p.relative_to(tree).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    normalized[role]={p.relative_to(tree).as_posix():hashlib.sha256(p.read_text(encoding='utf-8').encode('utf-8')).hexdigest() for p in files}
raw=[n for n in source['before'] if source['before'][n]!=source['candidate'][n]]
differences=[n for n in normalized['before'] if normalized['before'][n]!=normalized['candidate'][n]]
assert len(differences)==8,differences
assert all(p.read_bytes()==(d/'images/candidate'/p.relative_to(d/'images/before')).read_bytes()
    for p in (d/'images/before').rglob('*') if p.is_file() and p.name!='Lokad.Lython.dll')
correction=dict(originalCondition='freeze-diagnostic.py completed both nonincremental builds and froze both cores, then refused raw source count!=8.',
    rawDifferenceCount=len(raw),rawDifferences=raw,normalizedDifferences=differences,
    explanation='Root and detached checkout differ in CRLF/LF materialization. UTF-8 universal-newline normalization proves exactly the eight intended source differences. Raw hashes retained; no failed design/timing conclusion.',
    reused='Both already completed forced builds and frozen images; verified current sources/artifacts and clean root, no redundant build.')
(h/'freeze-source-gate-correction.json').write_text(json.dumps(correction,indent=2)+'\n',encoding='utf-8',newline='\n')
old=h.parent/'coarse-admission-r202/diagnostic'
for name in ['catalog.json','hash-witness.json','script-goldens.json']:shutil.copyfile(old/name,d/name)
catalog=json.loads((d/'catalog.json').read_text(encoding='utf-8'));goldens=json.loads((d/'script-goldens.json').read_text(encoding='utf-8'))
assert len(catalog['cases'])==5 and all(any(g['case']==c['id'] and g['sourceSHA256']==c['sourceSha256'] and g['allGoldensPassed'] for g in goldens['cases']) for c in catalog['cases'])
(d/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src'],cwd=t,stderr=subprocess.DEVNULL))
identity=dict(baseRevision=revision,baseQualification='Cached GREEN42854501354 full Windows/Ubuntu actualNET11/10 ordinary/stress/package.',
    cores=expected,source=source,normalizedSource=normalized,sourceDifferences=differences,
    candidate='Shared forward scanner and private funded cased-whitespace cursor. Immediate GetIter call fact follows direct and native helper returns; all future words admitted before loop effects. Ordinary escaping lists unchanged.',
    freeze='Sequential forced nonincremental builds from qualified root and isolated prototype. Source count corrected for checkout CRLF/LF only; original refusal preserved. Same039 auxiliary bytes.',
    catalogSHA256=hashlib.sha256((d/'catalog.json').read_bytes()).hexdigest(),status='Focused correctness only; timing/full candidate qualification pending.')
(d/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(h.parent/'coarse-admission-r202/measure.py',h/'measure.py')
print(json.dumps(dict(cores=expected,sourceFiles=len(source['before']),rawDifferences=len(raw),normalizedDifferences=differences),indent=2),flush=True)
