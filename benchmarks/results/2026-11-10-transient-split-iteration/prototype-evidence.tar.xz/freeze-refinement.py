from pathlib import Path
import hashlib,json,os,shutil,subprocess

h=Path(__file__).resolve().parent;t=h/'tree';old=h/'diagnostic';d=h/'diagnostic-refined';d.mkdir()
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
for tfm in ['net11.0','net10.0']:
    for kind in ['internal','public']:
        assert 'Failed:     0' in (h/f'refinement1-{kind}-{tfm}.log').read_text(encoding='utf-8')
for role in ['before','candidate']:shutil.copytree(old/'images'/role,d/'images'/role)
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
with (h/'freeze-refinement.log').open('w',encoding='utf-8') as log:
    result=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','build',str(t/'src/Lokad.Lython/Lokad.Lython.csproj'),
        '-c','Release','-f','net11.0','--no-incremental'],env=env,stdout=log,stderr=subprocess.STDOUT)
assert result.returncode==0
shutil.copyfile(t/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',d/'images/candidate/Lokad.Lython.dll')
assert hashlib.sha256((d/'images/before/Lokad.Lython.dll').read_bytes()).hexdigest()==identity['cores']['before']
source={p.relative_to(t).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in(t/'src/Lokad.Lython').rglob('*.cs') if 'obj'not in p.parts}
changed=[name for name in source if source[name]!=identity['source']['candidate'][name]]
assert changed==['src/Lokad.Lython/Runtime/Text/PyStringOps.Whitespace.cs'],changed
normalized={p.relative_to(t).as_posix():hashlib.sha256(p.read_text(encoding='utf-8').encode()).hexdigest() for p in(t/'src/Lokad.Lython').rglob('*.cs') if 'obj'not in p.parts}
identity['source']['candidate']=source;identity['normalizedSource']['candidate']=normalized
identity.update(originalCandidate=identity['cores']['candidate'],refinement='Remove only two new redundant cursor checks; ForNext, shared scanners/writers and publication keep existing effective checks. Original adversity/control variability retained.')
identity['cores']['candidate']=hashlib.sha256((d/'images/candidate/Lokad.Lython.dll').read_bytes()).hexdigest()
for name in ['catalog.json','hash-witness.json','script-goldens.json']:shutil.copyfile(old/name,d/name)
(d/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
(d/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src'],cwd=t,stderr=subprocess.DEVNULL))
script=(h/'measure.py').read_text(encoding='utf-8').replace("d=h/'diagnostic'","d=h/'diagnostic-refined'")
(h/'measure-refined.py').write_text(script,encoding='utf-8',newline='\n')
print(json.dumps(dict(cores=identity['cores'],onlyRefinementSource=changed),indent=2),flush=True)
