from hashlib import sha256
from pathlib import Path
import json
import os
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
notes=lab.parent
repo=lab.parents[3]
prior=notes/'paired-shipment-api-cpu-20261127/comparison/quiet'
checkpoint=notes/'direct-regex-cpython-repeat-20261127'
frozen=notes/'signed-regex-small-match-20261127'/'local/candidate'
donor=checkpoint/'comparison/quiet'
quiet=lab/'comparison/quiet'
quiet.mkdir(parents=True)
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
sha=lambda path:sha256(path.read_bytes()).hexdigest()
def write(path,value): path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
pin=read(donor/'identity.json')
revision=pin['sourceRevision']
assert revision.startswith('7305efabf')
assert not subprocess.check_output(['git','diff',revision,'--','src','benchmarks/Lokad.Lython.Benchmarks'],cwd=repo)
files=pin['imageFiles']['candidate']
assert len(files)==32 and {p.name:sha(p) for p in frozen.iterdir()}==files
cases=read(donor/'representative.json')
compiled='scripts.regex-log-search.compiled'
case=next(row for row in cases['cases'] if row['id']==compiled)
write(quiet/'catalog.json',cases|{'cases':[case]})
for name in ('ops-profile.py','run.sh','analyze.py'):
    shutil.copyfile(prior/name,quiet/name)
shutil.copyfile(donor/'cpython-worker.py',quiet/'cpython-worker.py')
previous_archive=read(donor/'terminal-status.json')['receipt']['archiveSHA256']
assert sha(donor/'observations.tar.xz')==previous_archive
donor_name=Path(pin['frozenImage']).parent.name
root='direct-regex-cpu-b1861-20261127'
unit='lython-b1861-direct-regex-cpu-20261127'
identity=dict(sourceRevision=revision,owner=unit,profileCatalogSHA256=sha(quiet/'catalog.json'),
              donorArchiveSHA256=previous_archive,cpythonWorkerSHA256=pin['cpythonWorkerSHA256'],
              expectedCPythonSHA256=pin['expectedCPythonSHA256'],imageFiles={'candidate':files},
              coreSHA256={'candidate':files['Lokad.Lython.dll']}, comparisonHostRevision=pin['comparisonHostRevision'],
              catalogs={'catalog.json':{'sha256':sha(quiet/'catalog.json')}},
              frozenImage=f'/home/lokad/lython-bench-checks/{root}/candidate',auxiliaryFiles=files,
              profiles=[['direct-compiled-log-sync',compiled,'candidate']],
              purpose='Locate active CPU in the delivered compiled-pattern log search from B1860.')
write(quiet/'identity.json',identity)
collector=(prior/'collect.py').read_text(encoding='utf-8').replace('post-ready-insertion-cpython-b1849-20261127',donor_name).replace('b1851-fixtures','b1861-fixtures')
compile(collector,'collect.py','exec')
(quiet/'collect.py').write_text(collector,encoding='utf-8',newline='\n')
assert b'\r' not in (quiet/'run.sh').read_bytes()
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
report=quiet/'candidate-verify.json'
subprocess.run([dotnet,frozen/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'catalog.json',
   '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',quiet/'cpython-worker.py','--out',report],
   cwd=repo,env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk)),check=True,timeout=65)
verification=read(report)
assert verification['state']=='Completed' and verification['caseCount']==1
assert verification['catalogSha256']==identity['profileCatalogSHA256']
assert verification['launched']['library']['sha256']==files['Lokad.Lython.dll']
assert verification['launched']['adapter']['sha256']==files['Lokad.Lython.Benchmarks.dll']
names=['identity.json','catalog.json','cpython-worker.py','run.sh','collect.py','ops-profile.py']
with tarfile.open(quiet/'stage.tar.gz','w:gz') as tar:
    for name in names: tar.add(quiet/name,arcname=name)
manifest={name:dict(length=(quiet/name).stat().st_size,sha256=sha(quiet/name)) for name in names}
write(quiet/'upload.json',dict(root=root,donor=donor_name,donorFiles=files,donorArchive=previous_archive,
    payloadSHA256=sha(quiet/'stage.tar.gz'),files=manifest,expandedBytes=sum(row['length'] for row in manifest.values()),
    minimumAfterStageBytes=6*1024*1024))
host=(checkpoint/'quiet-vm.py').read_text(encoding='utf-8').replace('lython-b1860-repeat-cpython-20261127',unit)
host=host.replace("proof['caseCount']==2", "proof['caseCount']==1").replace("root/'representative.json'", "root/'catalog.json'").replace("['representative.json']['sha256']", "['catalog.json']['sha256']").replace('RuntimeMaxSec=135','RuntimeMaxSec=125')
compile(host,'quiet-vm.py','exec')
(lab/'quiet-vm.py').write_text(host,encoding='utf-8',newline='\n')
