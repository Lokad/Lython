from pathlib import Path
p=Path(__file__).resolve().parent/'measure-initial-allocation.py'
source=p.read_text(encoding='utf-8').replace("/'initial-unified'", "/'reused-storage'")
exec(compile(source,str(p),'exec'))
