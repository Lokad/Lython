from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=r.parents[3]
proof=repo/'benchmarks/results/2026-11-15-canonical-activation-prototype/refinement/decision.json'
decision=json.loads(proof.read_text(encoding='utf-8'));assert decision['withdrawEntireActivationPrototype']
archive=proof.parent/'sources-checks-and-observations.tar.xz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==decision['archiveSHA256']
with tarfile.open(archive) as a:
    assert hashlib.sha256(a.extractfile('retirement/candidate-core.dll').read()).hexdigest().startswith('17b04146')
    assert a.getmember('retirement/sources.tar.xz').size>0
subprocess.run(['git','restore','--source=02340b14','--worktree','--','src','tests'],cwd=repo,check=True)
for name in ['LythonRuntime.Executable.Invocation.cs','LythonRuntime.Executable.Invocation.Calls.cs','LythonRuntime.Executable.Invocation.Execution.cs']:
    path=(repo/'src/Lokad.Lython/Runtime'/name).resolve()
    assert path.parent==(repo/'src/Lokad.Lython/Runtime').resolve() and path.is_file()
    path.unlink()
# Keep the independent semantic case: it exposed a prototype routing error but
# regular Python behavior remains useful coverage on the qualified implementation.
p=repo/'tests/Lokad.Lython.PublicApi.Tests/ProtectedHelperExecutionTests.cs'
s=p.read_text(encoding='utf-8')
marker='    public static IEnumerable<object[]> PythonControls()\n    {\n'
assert marker in s
s=s.replace(marker,marker+'''        yield return ["binding-fault-after-context-materialization", """
            def required(*, value): return value
            def guarded():
                try: return required()
                except TypeError: return 'caught'
            print(guarded())
            """, "caught\\n"];
''',1);p.write_text(s,encoding='utf-8')
inputs=subprocess.check_output(['git','ls-files','src/Lokad.Lython'],cwd=repo,text=True,encoding='utf-8').splitlines()
rows=[]
for name in inputs:
    original=subprocess.check_output(['git','show','02340b14:'+name],cwd=repo)
    actual=(repo/name).read_bytes()
    normalized=lambda b:b.replace(b'\r\n',b'\n')
    assert normalized(actual)==normalized(original),name
    rows.append(dict(path=name,sha256=hashlib.sha256(normalized(actual)).hexdigest()))
(r/'restoration-source-proof.json').write_text(json.dumps(dict(reference='02340b14; runtime6e276759',allProductionInputsMatch=True,inputs=rows,newSemanticRegressionRetained=True,forcedMatchingBuildsRequired=True),indent=2)+'\n',encoding='utf-8')
print('Restored all production sources to qualified6e/02340 baseline; removed only the three archived prototype files. Independent public regression retained. Force builds before --no-build verification.')
