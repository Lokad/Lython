from pathlib import Path
root=Path(__file__).resolve().parent
source=(root/'freeze-initial.py').read_text(encoding='utf-8')
source=source.replace("root/'initial-unified'", "root/'typed-storage'")
source=source.replace("('r403-initial-internal.trx','r403-internal-refined.trx')", "('r403-workspace-refined.trx','r403-storage-edges.trx','r403-storage-net10.trx')")
source=source.replace("('r403-initial-public.trx','r403-expanded-public.trx')", "('r403-typed-public11.trx','r403-typed-probe-corrected-public11.trx','r403-storage-net10-public.trx')")
source=source.replace('126internal/401expanded public net11 pass; no full or net10 qualification yet.', 'Reused canonical activation; shared typed builtin returns restored. 478public net11/net10 pass;167internal both targets+57edges net11; no full qualification.')
exec(compile(source,str(root/'freeze-initial.py'),'exec'))
