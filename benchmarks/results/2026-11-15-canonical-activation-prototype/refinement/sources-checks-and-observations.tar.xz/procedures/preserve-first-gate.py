from pathlib import Path
import hashlib,json,tarfile
r=Path(__file__).resolve().parent;repo=r.parents[3]
out=repo/'benchmarks/results/2026-11-15-canonical-activation-prototype';out.mkdir(exist_ok=False)
stages=['initial-unified','reused-storage','typed-storage','final-storage']
archivePath=out/'sources-images-checks-and-observations.tar.xz'
with tarfile.open(archivePath,'x:xz') as a:
    # One complete baseline image plus exact changed cores reconstruct every
    # measured allocation image; all per-stage manifests remain immutable.
    for p in sorted((r/'final-storage/reference').iterdir()):
        if p.is_file():a.add(p,arcname='reference-image/'+p.name,recursive=False)
    for stage in stages:
        folder=r/stage
        for p in folder.iterdir():
            if p.is_file():a.add(p,arcname=stage+'/'+p.name,recursive=False)
        a.add(folder/'candidate/Lokad.Lython.dll',arcname=stage+'/candidate-core.dll',recursive=False)
    for p in r.glob('*.py'):a.add(p,arcname='procedures/'+p.name,recursive=False)
    for name in ['transition-map.md','baseline-source.tar']:
        a.add(r/name,arcname=name,recursive=False)
    for p in (r/'quiet').iterdir():
        if p.is_file() and p.name!='payload.tgz':a.add(p,arcname='quiet/'+p.name,recursive=False)
    for suite in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:
        for p in (repo/'tests'/suite/'TestResults').glob('r403-*.trx'):
            a.add(p,arcname='checks/'+suite+'/'+p.name,recursive=False)
    # Current test sources preserve meaningful coverage independently of the
    # discarded implementation assertions. Production snapshots are per-stage.
    for suite in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:
        for p in (repo/'tests'/suite).rglob('*.cs'):
            if not {'bin','obj','TestResults'}&set(p.relative_to(repo).parts):
                a.add(p,arcname=p.relative_to(repo).as_posix(),recursive=False)
manifest=dict(archiveSHA256=hashlib.sha256(archivePath.read_bytes()).hexdigest(),prototype=True,retained=False,fullyQualified=False,
    measuredCoreSHA256=hashlib.sha256((r/'final-storage/candidate/Lokad.Lython.dll').read_bytes()).hexdigest(),
    allocationReference='qualified6e276759/45dd2da1',quietReference='qualified51e3c2c1/22e5b72c',
    finalAllocation=json.loads((r/'final-storage/allocation-summary.json').read_text(encoding='utf-8')),
    quiet=json.loads((r/'quiet/summary.json').read_text(encoding='utf-8')))
(out/'decision.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(dict(archive=str(archivePath.relative_to(repo)),bytes=archivePath.stat().st_size,sha256=manifest['archiveSHA256']))
