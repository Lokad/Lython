from pathlib import Path

repo=Path(__file__).resolve().parents[4]
runtime=repo/'src/Lokad.Lython/Runtime'
def edit(name,old,new):
    p=runtime/name;s=p.read_text(encoding='utf-8');assert old in s,(name,old[:70]);p.write_text(s.replace(old,new,1),encoding='utf-8')

edit('LythonRuntime.Executable.cs','        internal ExecutableWorkState _execution = new();', '''        private ExecutableInvocation? _invocation;
        internal ref ExecutableWorkState _execution => ref _invocation!.Work;''')
edit('LythonRuntime.Executable.cs','''        private void ClearExecutableBindings()
        {
            _execution.Code''','''        private void ClearExecutableBindings()
        {
            if (_invocation is null) return;
            _execution.Code''')

fields=[('ExecutionContext?','_caller','CallerContext','null'),('MemoryGovernor?','_boundStorageOwner','BoundStorageOwner','null'),
('ExecutableCallSite?','_pendingCallSite','PendingCallSite','null'),('int','_pendingCallStart','PendingCallStart','0'),
('ExecutableSlot','_completedCallValue','CompletedCallValue','default'),('Exception?','_completedCallError','CompletedCallError','null'),
('CallCompletion','_callCompletion','Completion','CallCompletion.Call'),('LythonSourceSpan?','_protocolCallSpan','ProtocolCallSpan','null'),
('object?','_preparedCallValue','PreparedCallValue','null')]
p=runtime/'LythonRuntime.Executable.Calls.cs';s=p.read_text(encoding='utf-8')
for typ,old,new,_ in fields:
    line=f'        private {typ} {old};'
    assert line in s,line
    s=s.replace(line,f'        private ref {typ} {old} => ref _invocation!.{new};',1)
s=s.replace('private enum CallCompletion','internal enum CallCompletion',1)
s=s.replace('            current._caller = null;','            if (current._invocation is { } remaining) remaining.CallerContext = null;',1)
p.write_text(s,encoding='utf-8')

edit('LythonRuntime.Executable.Interpreter.cs','''            _execution = execution;
            _entryActiveException''','''            _invocation = ExecutableInvocation.Create(this);
            _execution = execution;
            _entryActiveException''')
edit('LythonRuntime.Executable.Interpreter.cs','            if (_execution.Code is not null)','            if (_invocation?.Work.Code is not null)')
edit('LythonRuntime.Executable.Interpreter.cs','''        internal void DetachExecutableExecution()
        {
            ClearExecutableBindings();''','''        internal void DetachExecutableExecution()
        {
            if (_invocation is null) return;
            ClearExecutableBindings();''')
edit('LythonRuntime.Executable.Interpreter.cs','''            _preparedCallValue = null;
        }

        // The mutable stack''','''            _preparedCallValue = null;
            var retired = _invocation;
            _invocation = null;
            retired.ReleaseMetadata();
        }

        // The mutable stack''')
edit('LythonRuntime.Executable.Interpreter.cs','internal bool HasFrameReturn => !_execution.ReturnValue.IsUnassigned;',
     'internal bool HasFrameReturn => _invocation is not null && !_execution.ReturnValue.IsUnassigned;')
edit('LythonRuntime.Executable.Interpreter.cs','''            => _execution.InstructionIndex < _execution.Code.Instructions.Length''',
     '''            => _invocation is not null && _execution.InstructionIndex < _execution.Code.Instructions.Length''')

code='''using Lokad.Lython.Frontend;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    // The active work and call-completion state have one owner. A lexical
    // context may retain cells/namespaces after this invocation has retired.
    internal sealed partial class ExecutableInvocation
    {
        private const long MetadataBytes = 384;
        internal ExecutableWorkState Work = new();
        internal readonly ExecutionContext Scope;
        private bool _metadataOwned;
'''
for typ,old,new,initial in fields:
    if typ=='CallCompletion':typ='ExecutionContext.CallCompletion'
    if initial=='CallCompletion.Call':initial='ExecutionContext.CallCompletion.Call'
    code+=f'        internal {typ} {new} = {initial};\n'
code+='''
        private ExecutableInvocation(ExecutionContext scope) { Scope = scope; _metadataOwned = true; }

        internal static ExecutableInvocation Create(ExecutionContext scope)
        {
            scope.MemoryGovernor.Reserve(MetadataBytes, null);
            try
            {
                scope.CheckExecution(null);
                var invocation = new ExecutableInvocation(scope);
                scope.MemoryGovernor.Commit(MetadataBytes);
                return invocation;
            }
            catch { scope.MemoryGovernor.ReleaseReserved(MetadataBytes); throw; }
        }

        internal void ReleaseMetadata()
        {
            if (!_metadataOwned) return;
            _metadataOwned = false;
            Scope.MemoryGovernor.Release(MetadataBytes);
        }
    }
}
'''
(runtime/'LythonRuntime.Executable.Invocation.cs').write_text(code,encoding='utf-8')
print('Extracted the authoritative work/call state; native path remains until the coherent migration completes.')
