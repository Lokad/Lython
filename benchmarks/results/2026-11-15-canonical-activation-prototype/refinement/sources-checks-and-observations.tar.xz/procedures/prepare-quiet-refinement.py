from pathlib import Path
import hashlib,io,json,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=r.parents[3];q=r/'quiet-retirement'
code=(r/'prepare-quiet.py').read_text(encoding='utf-8')
code=code.replace("q=r/'quiet'", "q=r/'quiet-retirement'").replace("r/'final-storage", "r/'retirement")
code=code.replace('b787','b788').replace('Uncommitted R403 canonical activation','Uncommitted R403 retirement refinement')
if not q.exists():exec(compile(code,str(r/'prepare-quiet.py'),'exec'))
sha=lambda data:hashlib.sha256(data).hexdigest()
proofs=[]
archive=repo/'benchmarks/results/2026-11-15-canonical-activation-prototype/sources-images-checks-and-observations.tar.xz'
name=archive.relative_to(repo).as_posix();commit=subprocess.check_output(['git','log','-1','--format=%H','--',name],cwd=repo,text=True).strip()
assert subprocess.check_output(['git','hash-object',str(archive)],cwd=repo,text=True).strip()==subprocess.check_output(['git','rev-parse',f'{commit}:{name}'],cwd=repo,text=True).strip()
with tarfile.open(archive) as a:
    core=a.extractfile('final-storage/candidate-core.dll').read()
    observations=a.extractfile('quiet/observations.tgz').read()
    custody=dict(commit=commit,archive=name,archiveSHA256=sha(archive.read_bytes()))
    proofs.append(dict(path='activation-b787-20261115/candidate/Lokad.Lython.dll',bytes=len(core),sha256=sha(core),custody=dict(custody,member='final-storage/candidate-core.dll')))
    proofs.append(dict(path='activation-b787-20261115/observations.tgz',bytes=len(observations),sha256=sha(observations),custody=dict(custody,member='quiet/observations.tgz')))
    with tarfile.open(fileobj=io.BytesIO(observations)) as inner:
        data=inner.extractfile('confirmation/confirmation.json').read()
        proofs.append(dict(path='activation-b787-20261115/confirmation/confirmation.json',bytes=len(data),sha256=sha(data),custody=dict(custody,member='quiet/observations.tgz',nestedMember='confirmation/confirmation.json')))
archive=repo/'benchmarks/results/2026-11-15-tuple-operand-prototype/refined/quiet/observations.tgz'
name=archive.relative_to(repo).as_posix();commit=subprocess.check_output(['git','log','-1','--format=%H','--',name],cwd=repo,text=True).strip()
assert subprocess.check_output(['git','hash-object',str(archive)],cwd=repo,text=True).strip()==subprocess.check_output(['git','rev-parse',f'{commit}:{name}'],cwd=repo,text=True).strip()
expected=sha((r.parent/'tuple-transport-r397/quiet/retrieved/confirmation/confirmation.json').read_bytes())
with tarfile.open(archive) as a:
    matches=[]
    for m in a:
        if m.isfile() and m.name.endswith('confirmation/confirmation.json'):
            data=a.extractfile(m).read()
            if sha(data)==expected:matches.append((m.name,data))
    assert len(matches)==1,matches
    member,raw=matches[0]
    proofs.append(dict(path='tuple-transport-b782-20261115/confirmation/confirmation.json',bytes=len(raw),sha256=sha(raw),custody=dict(commit=commit,archive=name,archiveSHA256=sha(archive.read_bytes()),member=member)))
config=json.loads((q/'config.json').read_text(encoding='utf-8'));config['retire']=proofs
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
launch=(r/'launch-quiet.py').read_text(encoding='utf-8').replace("parent/'quiet'","parent/'quiet-retirement'")
launch=launch.replace('b787','b788')
(r/'launch-quiet-refinement.py').write_text(launch,encoding='utf-8')
retrieval=(r/'quiet/retrieve.py').read_text(encoding='utf-8').replace('b787','b788').replace('B787','B788')
(q/'retrieve.py').write_text(retrieval,encoding='utf-8')
summary=(r/'summarize-quiet.py').read_text(encoding='utf-8').replace("parent/'quiet'","parent/'quiet-retirement'")
(r/'summarize-quiet-refinement.py').write_text(summary,encoding='utf-8')
print(dict(retirementBytes=sum(v['bytes'] for v in proofs),exactArchivedPaths=[v['path']for v in proofs],newCore=config['identity']['coreSHA256']['candidate']))
