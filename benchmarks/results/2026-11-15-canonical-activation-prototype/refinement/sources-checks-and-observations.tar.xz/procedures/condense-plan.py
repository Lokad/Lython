from pathlib import Path
p=Path(__file__).resolve().parents[4]/'PLAN.md';s=p.read_text(encoding='utf-8')
a=s.index('## Priority 1 —');b=s.index('## Priority 2 —',a)
s=s[:a]+'''## Priority 1 — complete the canonical-activation decision

**Delivered prerequisite:** R402 live-default lookup is committed/pushed and fully
qualified at6e276759; preserve it. [R400 attribution](benchmarks/results/2026-11-15-search-cost-attribution/README.md)
and [R401 host boundary](benchmarks/results/2026-11-15-host-cost-attribution/README.md)
already establish the source gate. Host wall spans about13.9%, disposal about0.07us;
inclusive dispatch/call samples contain useful work, not removable shares. No
unchanged recapture, benchmark-host optimization or inferred CPU gain.

**Active R403, uncommitted:** one deferred executable activation owns final slots,
PC, return and child-completion state independently of its optional lexical
context. The existing linear runner handles calls/faults/suspension. Deleted in
the prototype: NativePrefix's duplicate loop, separate sync driver, fixed-buffer
and native-depth eligibility, StartNativeCall/StartInline and prepared-child
transfer. Direct unpacked returns and exception restoration use common completion.
The old array-only cache is replaced, not wrapped, by exclusive activation/slot
loans. There is no second controller/cache, arena, owner framework or public option.

**Contracts:** bind once into final slots; inspect live defaults after admission;
materialize exact lexical/handler state without replay. Preserve ordered effects,
closures/identity, tuple admission, fault positions, generators and real suspension.
Managed stack/logical admission and current tokens stay effective. Capacity,
metadata and replacement overlap are admitted; idle peak-loan capacity stays
charged until reuse ends and can deny earlier. Clear execution/token/guest
references before reuse. Await all pending users before relinquishment; retained
aliases/cache/results keep their owners and first refused admission stays terminal.

**Demonstrated adverse result:** [77a63bea/B787](benchmarks/results/2026-11-15-canonical-activation-prototype/README.md)
finishes six complete jobs in170.68s. Stable controls show invoice+28–33%,
fulfillment+15–17%, text+47–50%, JSON+14–15%, search+44–55%elapsed and adverse CPU.
Fresh configuration is roughly flat. Four changed-source allocation screens finish
effectively flat; all earlier large allocation regressions stay preserved. Allocation
reference is6e/45dd; quiet comparison reference is51e/22e. Evidence-only3c3eb130 is
committed locally; the runtime is not retained, delivered or fully qualified.

**One selected refinement / current stopping criterion:** canonical retirement
keeps ordinary dead references in funded storage until its owner relinquishes
the array, removing repeated per-instruction Array.Clear. Private cursors/builders
still retire immediately and returned loans clear used capacity. Conservative
reference retention is explicit; there is no refund, tracing or collector dependency.
Frozen17b04146 passes190internal/516public actual11 and96internal/516public actual10
(orphan helper deletion follows the11checks). B788 is one changed-source quiet-VM
comparison with the same six jobs/controls; no unchanged campaign is selected.
Decide retention, justified remaining debt or withdrawal when its archived result
is available. A broad material regression is not a performance improvement.
Further work must remove demonstrated whole construction/operand work, rather
than add another fast route, replay slowerR378/R382 or accumulate small special cases.

Affected complete scripts are CSV invoice/fulfillment, protected file search,
configuration-to-result and text/JSON controls. Warm includes I/O/goldens/prior
cleanup; compilation/fresh and wider process CPU remain distinct. Batch full
platform/original-stress/installed-consumer checks for a retained changed runtime,
then refresh representative CPython phases. Completed qualification is not repeated
for an unretained prototype. This decision does not complete the performance goal.

''' +s[b:]
marker='## Completed milestones and retained debt\n\n'
s=s.replace(marker,marker+'''R402 [live keyword defaults](benchmarks/results/2026-11-15-live-keyword-defaults/README.md)
is fully qualified at6e276759. It removes pre-admission async protocol snapshots;
actual suspending lookup, cancellation, terminal refusal and joined cleanup are
covered. Its desktop elapsed screen retains adverse+3.21% and5–30% unchanged
drift; no CPU gain is claimed. R402's separate native-only activation stack was
not implemented: duplicating unwind/context construction beside the runner would
add a controller. That does not establish that all consolidation must be slow.

''',1)
p.write_text(s,encoding='utf-8')
print('Condensed active deliverables and moved delivered R402 history; original adverse evidence stays linked.')
