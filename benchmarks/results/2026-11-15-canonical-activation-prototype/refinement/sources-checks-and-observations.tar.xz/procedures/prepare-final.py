from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parent;repo=r.parents[3]
source=(r/'freeze-typed.py').read_text(encoding='utf-8').replace("root/'typed-storage'", "root/'final-storage'")
source=source.replace("'r403-workspace-refined.trx'", "'r403-final-internal11.trx'")
exec(compile(source,str(r/'freeze-typed.py'),'exec'))
catalog=json.loads((r/'final-storage/catalog.json').read_text(encoding='utf-8'))
for source in [r.parent/'activation-r402/catalog.json',r.parent/'async-cpython-r393/retrieved/representative.json']:
    data=json.loads(source.read_text(encoding='utf-8'))
    print(source.name, [c['id'] for c in data['cases'] if 'config' in c['id'] or 'file-search' in c['id']],flush=True)
# Preserve the existing four allocation jobs and their hashes unchanged.
measure=(r/'measure-initial-allocation.py').read_text(encoding='utf-8').replace("/'initial-unified'", "/'final-storage'")
(r/'measure-final-allocation.py').write_text(measure,encoding='utf-8')
