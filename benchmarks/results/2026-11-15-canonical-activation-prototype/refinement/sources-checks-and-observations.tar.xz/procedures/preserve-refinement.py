from pathlib import Path
import hashlib,json,tarfile
r=Path(__file__).resolve().parent;repo=r.parents[3]
out=repo/'benchmarks/results/2026-11-15-canonical-activation-prototype/refinement';out.mkdir(exist_ok=False)
archive=out/'sources-checks-and-observations.tar.xz'
with tarfile.open(archive,'x:xz') as a:
    for p in (r/'retirement').iterdir():
        if p.is_file():a.add(p,arcname='retirement/'+p.name,recursive=False)
    a.add(r/'retirement/candidate/Lokad.Lython.dll',arcname='retirement/candidate-core.dll',recursive=False)
    for p in (r/'quiet-retirement').iterdir():
        if p.is_file() and p.name!='payload.tgz':a.add(p,arcname='quiet/'+p.name,recursive=False)
    for p in r.glob('*.py'):a.add(p,arcname='procedures/'+p.name,recursive=False)
    for suite in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:
        for p in (repo/'tests'/suite/'TestResults').glob('r403-retirement-*.trx'):
            a.add(p,arcname='checks/'+suite+'/'+p.name,recursive=False)
        for p in (repo/'tests'/suite).rglob('*.cs'):
            if not {'bin','obj','TestResults'}&set(p.relative_to(repo).parts):a.add(p,arcname=p.relative_to(repo).as_posix(),recursive=False)
summary=json.loads((r/'quiet-retirement/summary.json').read_text(encoding='utf-8'))
decision=dict(retained=False,fullyQualified=False,withdrawEntireActivationPrototype=True,sourcePair='17b04146 versus qualified51e3c2c1/22e5b72c',
    coherentDeletionAchieved=True,performanceObjectiveAchieved=False,allocationNotRemeasuredForRefinement=True,
    originalEvidenceCommit='3c3eb130',archiveSHA256=hashlib.sha256(archive.read_bytes()).hexdigest(),quiet=summary,
    reason='The changed refinement remains materially slower across the complete CPU workloads, despite simplification and flat allocation at its preceding source. Do not retain this broad CPU debt. Future complete call/operand redesigns remain eligible; no unchanged retry is selected.')
(out/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8')
print(dict(bytes=archive.stat().st_size,sha256=decision['archiveSHA256'],decision='withdraw prototype, preserve evidence and independent public regression'))
