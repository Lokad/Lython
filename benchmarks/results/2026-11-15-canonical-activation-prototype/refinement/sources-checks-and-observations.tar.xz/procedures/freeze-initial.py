from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile

root=Path(__file__).resolve().parent
repo=root.parents[3]
folder=root/'initial-unified';folder.mkdir(exist_ok=False)
reference=repo/'.git/agent-notes/review-20261031/activation-r402/candidate'
manifest={}
for role in ('reference','candidate'):
    image=folder/role;image.mkdir()
    for source in reference.iterdir():
        if source.is_file():shutil.copyfile(source,image/source.name)
    if role=='candidate':shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',image/'Lokad.Lython.dll')
    manifest[role]={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in image.iterdir() if p.is_file()}
assert manifest['reference']['Lokad.Lython.dll']=='45dd2da18723d26882868c27ccf10c84c1ec24dfe4b526eaa890b727de002d21'
catalog=repo/'.git/agent-notes/review-20261031/tuple-transport-r397/catalog.json'
shutil.copyfile(catalog,folder/'catalog.json')
with tarfile.open(folder/'sources.tar.xz','w:xz') as archive:
    production=subprocess.check_output(['git','ls-files','src/Lokad.Lython'],cwd=repo,text=True,encoding='utf-8').splitlines()
    new=subprocess.check_output(['git','ls-files','--others','--exclude-standard','src/Lokad.Lython'],cwd=repo,text=True,encoding='utf-8').splitlines()
    for name in sorted(set(production+new)):
        if (repo/name).is_file():archive.add(repo/name,arcname=name,recursive=False)
    for name in ('r403-initial-internal.trx','r403-internal-refined.trx'):
        archive.add(repo/'tests/Lokad.Lython.Tests/TestResults'/name,arcname=name,recursive=False)
    for name in ('r403-initial-public.trx','r403-expanded-public.trx'):
        archive.add(repo/'tests/Lokad.Lython.PublicApi.Tests/TestResults'/name,arcname=name,recursive=False)
(folder/'identity.json').write_text(json.dumps(dict(referenceRevision='6e276759',baseRevision='02340b14',prototype=True,files=manifest,semanticState='Uncommitted canonical activation;126internal/401expanded public net11 pass; no full or net10 qualification yet.'),indent=2)+'\n',encoding='utf-8')
print('Copied both complete images and source/TRX snapshots; prototype not retained or qualified.')
