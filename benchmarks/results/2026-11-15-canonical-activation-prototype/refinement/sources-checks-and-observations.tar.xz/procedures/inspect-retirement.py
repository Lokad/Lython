from pathlib import Path
import json,subprocess
r=Path(__file__).resolve().parent
proofs=json.loads((r/'retirable-proof-candidates.json').read_text(encoding='utf-8'))
code='''from pathlib import Path
import hashlib,json,os,stat
base=Path('/home/lokad/lython-bench-checks').resolve()
proofs=PROOFS
rows=[]
for folder in ['canonical-format-instructions-b386-20261107','canonical-format-instructions-b387-20261107']:
 for p in (base/folder).rglob('Lokad.Lython.dll'):
  m=p.lstat(); h=hashlib.sha256(p.read_bytes()).hexdigest()
  rows.append(dict(path=p.relative_to(base).as_posix(),bytes=m.st_size,links=m.st_nlink,uid=m.st_uid,inode=m.st_ino,coreSHA256=h,proof=next((v for v in proofs if v['coreSHA256']==h),None)))
print(json.dumps(rows,indent=2))
'''.replace('PROOFS',repr(proofs))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=30)
assert done.returncode==0,done.stderr
(r/'retirement-inspection.json').write_text(done.stdout,encoding='utf-8')
print(done.stdout)
