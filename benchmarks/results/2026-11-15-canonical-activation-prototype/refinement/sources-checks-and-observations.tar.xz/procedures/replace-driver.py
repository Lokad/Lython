from pathlib import Path

repo=Path(__file__).resolve().parents[4]
r=repo/'src/Lokad.Lython/Runtime'
def change(name,old,new):
    p=r/name;s=p.read_text(encoding='utf-8');assert old in s,(name,old[:100]);p.write_text(s.replace(old,new,1),encoding='utf-8')

# The current context owns only actual lexical/control identity. All executable
# work and normal call-completion state live in its optional activation.
p=r/'LythonRuntime.Executable.Calls.cs';s=p.read_text(encoding='utf-8')
start=s.index('        public void Execute()');end=s.index('        private bool TryBeginExecutableCall',start)
s=s[:start]+'''        public void Execute() => _invocation!.Execute();

        public ValueTask ExecuteAsync() => _invocation!.ExecuteAsync();

'''+s[end:]
start=s.index('        private bool TryBeginExecutableCall');end=s.index('        private bool TryBeginExecutableConstructor',start)
s=s[:start]+s[end:]
start=s.index('        private static ExecutionContext? CompleteCallFrame');end=s.index('        private void AttachPreparedCall',start)
s=s[:start]+'''        private ValueTask<ExecutableInvocation?> BeginFunctionCall(PyExecutableFunction function, object? receiver,
            ExecutableCallSite? site, int start, LythonSourceSpan span, CallCompletion completion,
            bool asynchronous, bool callEntered = false)
            => _invocation!.BeginFunctionCall(function, receiver, site, start, span, completion, asynchronous, callEntered);

'''+s[end:]
# Pending/native chains are replaced by the ordinary activation's caller link.
start=s.index('        private void AttachPreparedCall');end=s.index('        private void CompletePendingCall',start)
s=s[:start]+s[end:]
# Completion now runs for deferred and materialized invocations alike.
start=s.index('        private void CompletePendingCall');s=s[:start]+'''        private void ResumePendingCall() => _invocation!.ResumePendingCall();
    }
}
'''
s=s.replace('private ref ExecutionContext? _caller => ref _invocation!.CallerContext;',
            'private ref ExecutableInvocation? _caller => ref _invocation!.Caller;')
s=s.replace('private bool HasPendingCall => _pendingCallSite is not null || _protocolCallSpan is not null;',
            'private bool HasPendingCall => _invocation?.HasPendingCall == true;')
s=s.replace('private LythonSourceSpan PendingCallSpan => _pendingCallSite?.CallSpan ?? _protocolCallSpan!;',
            'private LythonSourceSpan PendingCallSpan => _invocation!.PendingCallSpan;')
s=s.replace('ValueTask<ExecutionContext?>','ValueTask<ExecutableInvocation?>')
s=s.replace('private bool TryBeginExecutableConstructor','internal bool TryBeginExecutableConstructor')
p.write_text(s,encoding='utf-8')

# Share the ordinary instruction loop; a call yields the existing linear runner
# even when the caller has not needed a lexical context.
p=r/'LythonRuntime.Executable.Interpreter.Dispatch.cs';s=p.read_text(encoding='utf-8')
s=s.replace('private enum InstructionPause','internal enum InstructionPause',1)
old='''        private static InstructionPause ExecuteInstructionPrefix(ref ExecutableWorkState execution, ExecutionContext scope,
            ExecutionContext? invocation, bool asynchronous, out ValueTask<bool> pending, out LythonSourceSpan? pendingSpan,
            out ValueTask<ExecutionContext?> nextCall)
        {
'''
new='''        internal static InstructionPause ExecuteInstructionPrefix(ExecutableInvocation activation,
            bool asynchronous, out ValueTask<bool> pending, out LythonSourceSpan? pendingSpan,
            out ValueTask<ExecutableInvocation?> nextCall)
        {
            ref var execution = ref activation.Work;
            var scope = activation.EvaluationContext;
            var invocation = activation.Context;
'''
assert old in s;s=s.replace(old,new,1)
start=s.index('                            if (TryExecuteNativeCall(');end=s.index('                            if (!asynchronous) invocation!.ExecuteOrdinaryCall',start)
s=s[:start]+'''                            if (TryExecuteClosedCall(ref execution, scope, invocation, call, callStart, target)) break;
                            if (activation.TryBeginExecutableCall(call, callStart, target, asynchronous, out nextCall))
                            {
                                if (!nextCall.IsCompletedSuccessfully || !ReferenceEquals(nextCall.Result, activation))
                                {
                                    pendingSpan = call.CallSpan;
                                    return InstructionPause.Call;
                                }
                                nextCall = default;
                                jumped = true;
                                break;
                            }
                            if (invocation is null) return InstructionPause.ContextRequired;
'''+s[end:]
# Direct return is a completion intent, not another opcode engine.
needle='''                        case ExecutableOpCode.MakeTuple:
'''
assert needle in s;s=s.replace(needle,needle+'''                            if (activation.TryReturnUnpackedTuple(instruction)) return InstructionPause.Boundary;
''',1)
p.write_text(s,encoding='utf-8')

p=r/'LythonRuntime.Executable.Calls.Invoke.cs';s=p.read_text(encoding='utf-8')
start=s.index('        // The same native selection');end=s.index('            // These existing native receiver operations',start)
s=s[:start]+'''        // Closed builtins use the ordinary instruction/completion storage.
        private static bool TryExecuteClosedCall(ref ExecutableWorkState execution, ExecutionContext scope,
            ExecutionContext? invocation, ExecutableCallSite call, int start, object target)
        {
'''+s[end:]
start=s.index('        private static Span<ExecutableSlot> PrepareUnpackedCallReturn');end=s.index('        // The opcode has already read',start)
s=s[:start]+s[end:]
p.write_text(s,encoding='utf-8')

# No second body entry or native argument buffer remains on a compiled function.
p=r/'PyExecutableFunction.cs';s=p.read_text(encoding='utf-8')
s=s.replace('        _codeObject.ExceptionRegions.Count == 0 &&\n','')
start=s.index('    private bool CanRunNativePrefix');s=s[:start]+'''    internal ExecutableInvocation StartInvocation(in BoundFunctionArguments arguments, LythonSourceSpan span)
        => LythonRuntime.ExecutableInvocation.CreateFunction(this, arguments, span);
}
'''
# Alias only names the containing type's common activation; no new backend.
s=s.replace('internal ExecutableInvocation StartInvocation','internal LythonRuntime.ExecutableInvocation StartInvocation')
p.write_text(s,encoding='utf-8')

# Other branches already use the existing common kernels. Delete the old view.
(r/'LythonRuntime.Executable.NativePrefix.cs').unlink()
p=r/'LythonRuntime.Executable.Integers.cs';s=p.read_text(encoding='utf-8');start=s.index('    internal ref partial struct NativeExecution');s=s[:start]+'}\n';p.write_text(s,encoding='utf-8')
p=r/'LythonRuntime.Executable.NativeCalls.cs';s=p.read_text(encoding='utf-8');start=s.index('    // Exact bounds cannot run Python protocols.');end=s.index('    // Conditional branches and unary not',start);s=s[:start]+s[end:];p.write_text(s,encoding='utf-8')

# Control/operation helpers still serve actual lexical contexts.
for name in ('LythonRuntime.Executable.Inputs.cs',):
    p=r/name;s=p.read_text(encoding='utf-8').replace('ValueTask<ExecutionContext?>','ValueTask<ExecutableInvocation?>');p.write_text(s,encoding='utf-8')
for name, names in {
    'LythonRuntime.Executable.Interpreter.Routing.cs':['RoutePendingFrameException','TryRouteReturn','TryRouteControl','TryRouteRuntimeException'],
    'LythonRuntime.Executable.Results.cs':['PublishInstructionResult'],
    'LythonRuntime.Executable.Interpreter.cs':['AbandonFrame'],
}.items():
    p=r/name;s=p.read_text(encoding='utf-8')
    for method in names:
        s=s.replace('private void '+method+'(', 'internal void '+method+'(')
        s=s.replace('private bool '+method+'(', 'internal bool '+method+'(')
        s=s.replace('private static void '+method+'(', 'internal static void '+method+'(')
    p.write_text(s,encoding='utf-8')
# The driver now performs stepping and awaited retirement for all activations.
(r/'LythonRuntime.Executable.Interpreter.Sync.cs').unlink()
p=r/'LythonRuntime.Executable.Interpreter.cs';s=p.read_text(encoding='utf-8');start=s.index('        private async ValueTask<ExecutionContext?> ExecuteUntilCallAsync()');s=s[:start]+'    }\n}\n';
s=s.replace('        private LythonRuntimeException? _injectedException;','        private ref LythonRuntimeException? _injectedException => ref _invocation!.InjectedException;')
s=s.replace('        private PyException? _entryActiveException;','        private ref PyException? _entryActiveException => ref _invocation!.EntryException;')
p.write_text(s,encoding='utf-8')
print('Replaced native entry/driver and ordinary stepping with one activation driver; new driver implementation follows.')
