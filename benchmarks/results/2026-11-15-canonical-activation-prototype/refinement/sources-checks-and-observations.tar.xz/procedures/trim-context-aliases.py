from pathlib import Path

repo=Path(__file__).resolve().parents[4];r=repo/'src/Lokad.Lython/Runtime'
p=r/'LythonRuntime.Executable.Calls.cs';s=p.read_text(encoding='utf-8')
aliases=['_caller','_boundStorageOwner','_pendingCallSite','_pendingCallStart','_completedCallValue','_completedCallError','_callCompletion','_protocolCallSpan']
s=''.join(line for line in s.splitlines(keepends=True) if not any(' '+v+' =>' in line for v in aliases)
    and 'private bool HasPendingCall =>' not in line and 'private LythonSourceSpan PendingCallSpan =>' not in line
    and 'private void ResumePendingCall() =>' not in line)
p.write_text(s,encoding='utf-8')
p=r/'LythonRuntime.Executable.Interpreter.cs';s=p.read_text(encoding='utf-8')
s=''.join(line for line in s.splitlines(keepends=True) if not any(line.lstrip().startswith(v+' =') for v in aliases))
s=s.replace('            retired.ReleaseMetadata();','            retired.ClearCallState();\n            retired.ReleaseMetadata();',1)
p.write_text(s,encoding='utf-8')
p=r/'LythonRuntime.Executable.Invocation.cs';s=p.read_text(encoding='utf-8')
s=s.replace('        internal MemoryGovernor? BoundStorageOwner;\n','').replace('                activation.BoundStorageOwner = bound.StorageOwner;\n','')
marker='        internal void ReleaseMetadata()'
at=s.index(marker)
s=s[:at]+'''        internal void ClearCallState()
        {
            Caller = null;
            PendingCallSite = null;
            PendingCallStart = 0;
            CompletedCallValue = default;
            CompletedCallError = null;
            Completion = ExecutionContext.CallCompletion.Call;
            ProtocolCallSpan = null;
            PreparedCallValue = null;
            InjectedException = null;
            EntryException = null;
            _unpackedValues = null;
        }

'''+s[at:]
s=s.replace('                    Work = default;\n                    Caller = null;', '                    Work = default;\n                    ClearCallState();\n                    Context = null;')
p.write_text(s,encoding='utf-8')
print('Removed temporary context aliases and redundant bound-owner storage; invocation state has one authoritative owner.')
