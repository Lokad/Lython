from pathlib import Path

repo=Path(__file__).resolve().parents[4]
r=repo/'src/Lokad.Lython/Runtime'
p=r/'Calls/BoundFunctionArguments.cs'
p.write_text('''namespace Lokad.Lython.Runtime;

// Binding fills the same exclusive workspace that becomes the invocation.
// Default is the absence of function arguments at module/generator entry.
internal readonly record struct BoundFunctionArguments(
    LythonRuntime.ExecutableInvocation? Workspace,
    int ParameterCount)
{
    internal LythonRuntime.ExecutableSlot[] Values => Workspace?.WorkspaceValues!;
    internal MemoryGovernor? StorageOwner => Workspace?.WorkspaceOwner;
}
''',encoding='utf-8')
p=r/'LythonRuntime.Calls.Binding.cs';s=p.read_text(encoding='utf-8')
a=s.index('    internal static void ReturnBoundArguments(BoundFunctionArguments bound, int usedLength)')
b=s.index('    internal static BoundFunctionArguments RentFunctionArgumentStorage',a)
s=s[:a]+'''    internal static void ReturnBoundArguments(BoundFunctionArguments bound, int usedLength)
    {
        if (bound.Workspace is { WorkspaceOwner: { } owner } workspace)
            owner.ReturnFunctionWorkspace(workspace, usedLength);
    }

'''+s[b:]
s=s.replace('new BoundFunctionArguments(values, parameterCount, governor)','new BoundFunctionArguments(values, parameterCount)')
p.write_text(s,encoding='utf-8')
p=r/'MemoryGovernor.cs';s=p.read_text(encoding='utf-8')
s=s.replace('internal LythonRuntime.ExecutableSlot[] RentFunctionWorkspace','internal LythonRuntime.ExecutableInvocation RentFunctionWorkspace')
s=s.replace('internal void ReturnFunctionWorkspace(LythonRuntime.ExecutableSlot[] values, int usedLength)', 'internal void ReturnFunctionWorkspace(LythonRuntime.ExecutableInvocation values, int usedLength)')
a=s.index('    // Invocation workspaces use')
b=s.index('    public MemoryGovernor(',a)
s=s[:a]+'''    // The canonical activation and its final slots share one exclusive loan.
    // Idle loans retain capacity but no execution, token, callable or guest refs.
    // Peak concurrent loans determine reuse storage; there is no separate cap.
    private struct WorkspaceCache
    {
        private LythonRuntime.ExecutableInvocation? _idle;
        private bool _ended;

        internal LythonRuntime.ExecutableInvocation Rent(MemoryGovernor governor, int capacity, LythonSourceSpan? span,
            LythonRuntime.ExecutionContext? context = null)
        {
            governor.ThrowIfAdmissionFailed();
            context?.CheckExecution(span);
            capacity = Math.Max(1, capacity);
            var workspace = _idle;
            if (workspace is not null)
            {
                _idle = workspace.NextIdle;
                workspace.NextIdle = null;
            }
            if (workspace is not null && workspace.WorkspaceValues.Length >= capacity)
            {
                workspace.BeginWorkspaceLoan(governor);
                return workspace;
            }
            var previousBytes = workspace is null ? 0 : WorkspaceBytes(workspace.WorkspaceValues.Length);
            var bytes = WorkspaceBytes(capacity);
            try
            {
                // Fund the complete replacement while old capacity is retained.
                governor.Reserve(bytes, span);
                try
                {
                    context?.CheckExecution(span);
                    var values = new LythonRuntime.ExecutableSlot[capacity];
                    workspace ??= new LythonRuntime.ExecutableInvocation();
                    workspace.WorkspaceValues = values;
                    governor.Commit(bytes);
                }
                catch { governor.ReleaseReserved(bytes); throw; }
            }
            catch
            {
                // The popped idle loan has no remaining user. Refusal is terminal,
                // never a reason to retry with its smaller, now relinquished array.
                if (previousBytes != 0) governor.Release(previousBytes);
                throw;
            }
            workspace.BeginWorkspaceLoan(governor);
            try { if (previousBytes != 0) governor.Release(previousBytes); }
            catch { Return(governor, workspace, 0); throw; }
            return workspace;
        }

        internal void Return(MemoryGovernor governor, LythonRuntime.ExecutableInvocation workspace, int usedLength)
        {
            if (!ReferenceEquals(workspace.WorkspaceOwner, governor))
                throw new InvalidOperationException("Only an active workspace owner can return its loan.");
            Array.Clear(workspace.WorkspaceValues, 0, usedLength);
            workspace.EndWorkspaceLoan();
            if (!_ended)
            {
                workspace.NextIdle = _idle;
                _idle = workspace;
            }
            else governor.Release(WorkspaceBytes(workspace.WorkspaceValues.Length));
        }

        internal void End(MemoryGovernor governor)
        {
            _ended = true;
            var workspace = _idle;
            _idle = null;
            System.Runtime.ExceptionServices.ExceptionDispatchInfo? failure = null;
            while (workspace is not null)
            {
                var next = workspace.NextIdle;
                workspace.NextIdle = null;
                try { governor.Release(WorkspaceBytes(workspace.WorkspaceValues.Length)); }
                catch (Exception error) { failure ??= System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(error); }
                workspace = next;
            }
            failure?.Throw();
        }
    }

'''+s[b:];p.write_text(s,encoding='utf-8')
p=r/'LythonRuntime.Executable.Invocation.cs';s=p.read_text(encoding='utf-8')
s=s.replace('        internal readonly ExecutionContext Scope;', '''        private ExecutionContext? _scope;
        internal ExecutionContext Scope => _scope.RequireNotNull();
        internal ExecutableSlot[] WorkspaceValues = [];
        internal MemoryGovernor? WorkspaceOwner;
        internal ExecutableInvocation? NextIdle;''')
s=s.replace('        private ExecutableInvocation(ExecutionContext scope, bool metadataOwned)\n        { Scope = scope; _metadataOwned = metadataOwned; }', '''        internal ExecutableInvocation() { }

        private ExecutableInvocation(ExecutionContext scope, bool metadataOwned)
        { _scope = scope; _metadataOwned = metadataOwned; }

        internal void BeginWorkspaceLoan(MemoryGovernor owner)
        { WorkspaceOwner = owner; _retired = false; }

        internal void EndWorkspaceLoan()
        {
            Work = default;
            ClearCallState();
            _scope = null;
            Context = null;
            _function = null;
            _bound = default;
            _entrySpan = null;
            _functionEntered = _callerEntered = _metadataOwned = false;
            _unpackedStart = _unpackedCount = _originalCallerExtent = 0;
            _returnedUnpacked = _completedUnpacked = false;
            WorkspaceOwner = null;
            _retired = true;
        }''')
s=s.replace('activation = bound.StorageOwner is null ? Create(scope) : new ExecutableInvocation(scope, false);', '''activation = bound.Workspace.RequireNotNull();
                activation._scope = scope;''')
a=s.index('            catch (Exception error)\n',s.index('internal static ExecutableInvocation CreateFunction'))
b=s.index('\n        private ExecutionContext MaterializeContext()',a)
s=s[:a]+'''            catch (Exception error)
            {
                try
                {
                    if (error is LythonRuntimeException runtime)
                        PyFunctionBinding.AnnotateException(runtime, function.DefinitionContext, function.Name, span);
                }
                finally
                {
                    if (activation is null) ReturnBoundArguments(bound, function.CodeObject.ValueStorageCapacity);
                    else activation.Retire();
                }
                throw;
            }
        }
'''+s[b:]
a=s.index('        internal void Retire()');b=s.index('        internal void Execute()',a)
s=s[:a]+'''        internal void Retire()
        {
            if (_retired) return;
            _retired = true;
            var function = _function;
            var bound = _bound;
            try { if (Work.Code is not null) Work.Stack.ReleaseStorage(); }
            finally
            {
                try
                {
                    if (_functionEntered) { _functionEntered = false; Scope.LeaveFunctionCall(); }
                    Context?.LeaveExecutableSlots();
                    Context?.DetachExecutableExecution();
                }
                finally
                {
                    ReleaseMetadata();
                    // Returning the loan can reenter host code. Nothing may read
                    // or mutate this activation after it becomes available again.
                    if (function is not null) ReturnBoundArguments(bound, function.CodeObject.ValueStorageCapacity);
                    else { Work = default; ClearCallState(); }
                }
            }
        }

'''+s[b:];p.write_text(s,encoding='utf-8')

# These fixtures now borrow the same real final-slot owner as production.
t=repo/'tests/Lokad.Lython.Tests'
p=t/'FunctionWorkspaceOwnershipTests.cs';s=p.read_text(encoding='utf-8')
import re
for name in ['values','first','second','a','b','active','idle','previous','cached']:
    s=s.replace(name+'.Length',name+'.WorkspaceValues.Length')
    s=re.sub(r'\b'+name+r'\[',name+'.WorkspaceValues[',s)
    s=s.replace('Assert.All('+name+',','Assert.All('+name+'.WorkspaceValues,')
p.write_text(s,encoding='utf-8')
p=t/'FunctionClassCellBoundaryTests.cs';s=p.read_text(encoding='utf-8')
a=s.index('        => PyFunctionBinding.EnterInvocationFrame(')
b=s.index('\n    private static LoweredFunctionParameter Parameter',a)
s=s[:a]+'''    {
        var plan = FunctionBindingPlan.CreateDynamic("f", PythonCallableKind.Function, parameters, new Dictionary<string, object>());
        var bound = LythonRuntime.RentFunctionArgumentStorage(plan, Span, closure, null);
        try
        {
            for (var i = 0; i < values.Length; i++) bound.Values[i].Object = values[i];
            return PyFunctionBinding.EnterInvocationFrame(closure,
                facts ?? ScopeDirectiveFacts.Empty with { RequiresClassCell = true }, plan, bound, mirror, owner, Span);
        }
        finally { LythonRuntime.ReturnBoundArguments(bound); }
    }
'''+s[b:];p.write_text(s,encoding='utf-8')
p=t/'ExecutableAsyncIteratorCleanupTests.cs';s=p.read_text(encoding='utf-8')
old='''        return LythonRuntime.PyGenerator.Create(code, frame, definition.Span,
            arguments: new BoundFunctionArguments([LythonRuntime.ExecutableSlot.FromObject(sources[0])], 1));'''
new='''        var workspace = context.MemoryGovernor.RentFunctionWorkspace(1, definition.Span, context);
        workspace.WorkspaceValues[0].Object = sources[0];
        var arguments = new BoundFunctionArguments(workspace, 1);
        try { return LythonRuntime.PyGenerator.Create(code, frame, definition.Span, arguments: arguments); }
        finally { LythonRuntime.ReturnBoundArguments(arguments); }'''
assert old in s;s=s.replace(old,new);p.write_text(s,encoding='utf-8')
p=t/'NativeFunctionRefundTests.cs';s=p.read_text(encoding='utf-8')
s=s.replace('''                // Model legitimate admission reentry while the native helper
                // constructs its output. A smaller returned workspace is idle
                // when the outer call relinquishes its own larger storage.''','''                // End idle reuse during output admission. The active outer
                // loan must remain funded if a refund reenters and refuses.''')
s=s.replace('''                    throw first;
                };
            };''','''                    throw first;
                };
                governor.EndWorkspaceReuse();
            };''')
p.write_text(s,encoding='utf-8')
