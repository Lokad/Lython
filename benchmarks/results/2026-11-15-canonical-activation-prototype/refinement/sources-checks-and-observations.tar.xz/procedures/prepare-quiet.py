from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=r.parents[3];q=r/'quiet';q.mkdir(exist_ok=False)
old=r.parent/'tuple-transport-r397/quiet'
remote='/home/lokad/lython-bench-checks/activation-b787-20261115'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
reference=identity['coreSHA256']['candidate'];candidate=sha(r/'final-storage/candidate/Lokad.Lython.dll')
identity.update(sourceRevision='Uncommitted R403 canonical activation versus qualified51e3c2c1/frozen22e5b72c; local allocation reference separately qualified6e276759/45dd2da1.',
 purpose='Canonical activation replaces both native and ordinary construction/dispatch; complete CSV/search/config and text/JSON controls. Not a speedup claim.',
 coreSHA256={label:(candidate if label.startswith('candidate') else reference) for label in ['reference','reference-control','candidate','candidate-control']},
 candidateSourceIdentitySHA256=sha(r/'final-storage/identity.json'),qualification='Focused actual11/10 only; prototype not retained or fully qualified.')
for name,h in identity['auxiliaryFiles'].items():assert sha(r/'final-storage/candidate'/name)==h,name
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
extra=json.loads((r.parent/'activation-r402/catalog.json').read_text(encoding='utf-8'))
extra['cases']=[c for c in extra['cases'] if c['id']=='scripts.file-search.large.protected']
extra['cases']+=json.loads((r.parent/'config-phases-r336/catalog.json').read_text(encoding='utf-8'))['cases']
(q/'additional.json').write_text(json.dumps(extra,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf-8')
jobs=[['scripts.csv-invoice.large','warm'],['scripts.csv-fulfillment.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.json-summary-helpers.large','warm'],['scripts.file-search.large.protected','warm'],['scripts.config-edit.empty','compile-run']]
collect=(old/'collect.py').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/tuple-transport-b782-20261115',remote)
a=collect.index('jobs=');b=collect.index('\nenv =',a)
collect=collect[:a]+'jobs='+repr(jobs)+"\ncases.update({c['id']:c for c in json.loads((root/'additional.json').read_text())['cases']})\n"+collect[b:]
collect=collect.replace('assert time.monotonic()-started < 240','assert time.monotonic()-started < 240')
collect=collect.replace("with contextlib.ExitStack() as stack:\n            labels=", "catalog = root/('additional.json' if job_index >= 4 else 'representative.json')\n        manifest_hash=hashlib.sha256(catalog.read_bytes()).hexdigest()\n        with contextlib.ExitStack() as stack:\n            labels=")
collect=collect.replace('warmupSeconds=5, capturedWarmupSeconds=12, compilationWarmupSeconds=5','warmupSeconds=3, capturedWarmupSeconds=8, compilationWarmupSeconds=3')
collect=collect.replace('else 5); rows=[]','else 3); rows=[]').replace('(12 if case_id','(8 if case_id')
(q/'collect.py').write_text(collect,encoding='utf-8',newline='\n')
archive=(old/'archive-owned.py').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/tuple-transport-b782-20261115',remote).replace("len(raw['jobs'])==4","len(raw['jobs'])==6").replace('jobs=4,','jobs=6,')
(q/'archive-owned.py').write_text(archive,encoding='utf-8',newline='\n')
(q/'run.sh').write_text('set -eu\nroot='+remote+'\ntrap \'result=$?; printf "%s\\n" "$result" > "$root/exit-code.txt"\' EXIT\npython3 "$root/collect.py"\n',encoding='utf-8',newline='\n')
retire=[]
proof=json.loads((r/'retirement-inspection.json').read_text(encoding='utf-8'))[0]
assert proof['proof'] and proof['links']==1
retire.append(dict(path=proof['path'],sha256=proof['coreSHA256'],bytes=proof['bytes'],custody=proof['proof']))
p=repo/'benchmarks/results/2026-11-15-search-cost-attribution/observations.tgz';name=p.relative_to(repo).as_posix()
commit=subprocess.check_output(['git','log','-1','--format=%H','--',name],cwd=repo,text=True).strip()
assert subprocess.check_output(['git','hash-object',str(p)],cwd=repo,text=True).strip()==subprocess.check_output(['git','rev-parse',f'{commit}:{name}'],cwd=repo,text=True).strip()
retire.append(dict(path='search-attribution-b785-20261115/observations.tgz',sha256=sha(p),bytes=p.stat().st_size,custody=dict(commit=commit,archive=name)))
with tarfile.open(p) as a:
    member=a.getmember('profiles/search/perf.data'); data=a.extractfile(member).read()
    retire.append(dict(path='search-attribution-b785-20261115/profiles/search/perf.data',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),custody=dict(commit=commit,archive=name,archiveSHA256=sha(p),member=member.name)))
with tarfile.open(q/'payload.tgz','w:gz') as a:
    for name in ['identity.json','additional.json','collect.py','archive-owned.py','run.sh']:a.add(q/name,arcname=name)
    a.add(r/'final-storage/candidate/Lokad.Lython.dll',arcname='candidate/Lokad.Lython.dll')
with tarfile.open(q/'payload.tgz') as a:unpacked=sum(m.size for m in a if m.isfile())
config=dict(root=remote,sourceRoot='/home/lokad/lython-bench-checks/tuple-transport-b782-20261115',unit='lython-b787-canonical-activation-20261115',identity=identity,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha(q/'payload.tgz'),unpackedBytes=unpacked,retire=retire)
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
print(dict(jobs=jobs,payloadBytes=config['payloadBytes'],unpackedBytes=unpacked,retirementBytes=sum(v['bytes']for v in retire),frozenCore=candidate))
