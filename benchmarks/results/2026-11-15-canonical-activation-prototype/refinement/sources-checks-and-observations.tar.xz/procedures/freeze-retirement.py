from pathlib import Path
root=Path(__file__).resolve().parent
source=(root/'freeze-initial.py').read_text(encoding='utf-8').replace("root/'initial-unified'", "root/'retirement'")
source=source.replace("('r403-initial-internal.trx','r403-internal-refined.trx')", "('r403-retirement-internal11.trx','r403-retirement-internal10.trx')")
source=source.replace("('r403-initial-public.trx','r403-expanded-public.trx')", "('r403-retirement-public11.trx',)")
source=source.replace('126internal/401expanded public net11 pass; no full or net10 qualification yet.', 'Retirement refinement190internal/516public net11,96internal net10. No full qualification; original measured regression preserved in3c3eb130.')
exec(compile(source,str(root/'freeze-initial.py'),'exec'))
