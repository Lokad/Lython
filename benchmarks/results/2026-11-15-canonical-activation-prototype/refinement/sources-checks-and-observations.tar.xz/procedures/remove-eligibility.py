from pathlib import Path
import subprocess

repo=Path(__file__).resolve().parents[4];r=repo/'src/Lokad.Lython/Runtime'
p=repo/'src/Lokad.Lython/Frontend/ExecutableScript.cs';s=p.read_text(encoding='utf-8')
old='''        CanRunNativeInstructions = IsFunctionScope && !RequiresLocalVariableMirroring && capturedLocalSlots.Count == 0
            && !ExceptionRegions.Any(region => region.FinallyIndex is not null)
            && SupportsNativeInstructions();
''';assert old in s;s=s.replace(old,'',1)
start=s.index('    public bool CanRunNativeInstructions');end=s.index('    private bool CrossesExceptionBoundary',start);s=s[:start]+s[end:]
start=s.index('    private static bool IsInlineInstruction');s=s[:start]+'}\n';p.write_text(s,encoding='utf-8')
for p in (repo/'tests/Lokad.Lython.Tests').glob('*.cs'):
    s=p.read_text(encoding='utf-8');lines=s.splitlines(keepends=True)
    changed=[line for line in lines if not ('Assert.' in line and any(v in line for v in ('CanRunNativeInstructions','CanStartInline')))]
    if changed!=lines:p.write_text(''.join(changed),encoding='utf-8')

old=subprocess.check_output(['git','show','02340b14:src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeCalls.cs'],cwd=repo,text=True,encoding='utf-8')
start=old.index('    // Exact bounds cannot run Python protocols.');end=old.index('    // Conditional branches',start)
helper=old[start:end].replace('TryInvokeNativeRange','TryInvokeClosedRange')
p=r/'LythonRuntime.Executable.NativeCalls.cs';s=p.read_text(encoding='utf-8');where=s.index('    // Conditional branches');s=s[:where]+helper+s[where:];p.write_text(s,encoding='utf-8')
p=r/'LythonRuntime.Executable.Calls.Invoke.cs';s=p.read_text(encoding='utf-8');where=s.index('            // These existing native receiver operations')
s=s[:where]+'''            if (!call.HasReceiver && call.IsPositionalOnly && IsRangeBuiltinTarget(target)
                && TryInvokeClosedRange(execution.Stack.Values.AsSpan(start + call.ArgumentOffset, call.ArgumentCount),
                    call.CallSpan, invocation ?? scope, out var range))
            {
                PublishInstructionResult(ref execution, invocation, execution.Code.Instructions[execution.InstructionIndex], range);
                return true;
            }

'''+s[where:];s=s.replace('IsRangeBuiltinTarget(target)','IsRangeBuiltin(target)');p.write_text(s,encoding='utf-8')
print('Removed obsolete native eligibility/architecture assertions; common calls retain the existing closed range kernel.')
