from pathlib import Path
import json,shutil
r=Path(__file__).resolve().parent/'quiet'
shutil.copyfile(r/'launch.log',r/'launch-missing-archived-trace.log')
shutil.copyfile(r/'config.json',r/'config-before-absent-trace.json')
config=json.loads((r/'config.json').read_text(encoding='utf-8'))
absent='search-attribution-b785-20261115/profiles/search/perf.data'
assert len(config['retire'])==3 and config['retire'][-1]['path']==absent
config['retire']=config['retire'][:-1]
(r/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
print('Removed nonexistent RAM-trace working path from prospective retirement; canonical trace remains committed. Both prior preflight failures preserved; no staging/deletion happened.')
