from pathlib import Path

repo=Path(__file__).resolve().parents[4];r=repo/'src/Lokad.Lython/Runtime'
p=r/'PyFunctionBase.cs';s=p.read_text(encoding='utf-8')
s=s.replace('''        LythonRuntime.ExecutionContext? frame = null;
        try
        {
            var prepared = TryStartBoundInvocation(boundArguments, span, out var result, out frame);
            if (prepared && frame is null) return result.Object.RequireNotNull();
            frame ??= EnterInvocationFrame(boundArguments, span);
            try { return prepared ? LythonRuntime.ExecuteInitializedFrame(frame) ?? PyNone.Instance
                : ExecuteBody(frame, boundArguments, span); }''','''        if (this is PyExecutableFunction compiled)
            return LythonRuntime.ExecutableInvocation.InvokeRoot(compiled, boundArguments, span);
        LythonRuntime.ExecutionContext? frame = null;
        try
        {
            frame = EnterInvocationFrame(boundArguments, span);
            try { return ((PyGeneratorFunction)this).CreateGenerator(frame, boundArguments, span); }''',1)
s=s.replace('''        LythonRuntime.ExecutionContext? frame = null;
        try
        {
            var prepared = TryStartBoundInvocation(boundArguments, span, out var result, out frame);
            if (prepared && frame is null) return result.Object.RequireNotNull();
            frame ??= EnterInvocationFrame(boundArguments, span);
            try { return prepared ? await LythonRuntime.ExecuteInitializedFrameAsync(frame).ConfigureAwait(false) ?? PyNone.Instance
                : await ExecuteBodyAsync(frame, boundArguments, span).ConfigureAwait(false); }''','''        if (this is PyExecutableFunction compiled)
            return await LythonRuntime.ExecutableInvocation.InvokeRootAsync(compiled, boundArguments, span).ConfigureAwait(false);
        LythonRuntime.ExecutionContext? frame = null;
        try
        {
            frame = EnterInvocationFrame(boundArguments, span);
            try { return ((PyGeneratorFunction)this).CreateGenerator(frame, boundArguments, span); }''',1)
start=s.index('    protected abstract object ExecuteBody(');end=s.index('    internal LythonRuntime.ExecutionContext EnterInvocationFrame(',start)
s=s[:start]+s[end:]
assert 'TryStartBoundInvocation' not in s and 'ExecuteBody(' not in s
p.write_text(s,encoding='utf-8')
p=r/'PyGeneratorFunction.cs';s=p.read_text(encoding='utf-8').replace('protected override object ExecuteBody(','internal object CreateGenerator(')
start=s.index('    protected override ValueTask<object> ExecuteBodyAsync(');s=s[:start]+'}\n';p.write_text(s,encoding='utf-8')

# Root and actual lexical contexts attach the same activation; no duplicate work
# survives in a context. An admission failure must relinquish incoming work too.
p=r/'LythonRuntime.Executable.Interpreter.cs';s=p.read_text(encoding='utf-8')
start=s.index('        internal void AdoptExecutableExecution(');end=s.index('        internal void EnsureExecutableStateAvailable()',start)
s=s[:start]+'''        internal void AdoptExecutableExecution(ref ExecutableWorkState execution, PyException? entryException)
        {
            try
            {
                _invocation = ExecutableInvocation.Create(this);
                _execution = execution;
                _entryActiveException = entryException;
                execution = default;
            }
            catch { execution.Stack.ReleaseStorage(); execution = default; throw; }
        }

        internal void AttachInvocation(ExecutableInvocation invocation)
        {
            if (_invocation is not null) throw new InvalidOperationException("An invocation is already attached.");
            _invocation = invocation;
        }

'''+s[end:]
p.write_text(s,encoding='utf-8')

# A funded exclusive workspace includes coarse activation metadata. Even an empty
# function needs one funded loan; idle storage retains its complete charge.
p=r/'MemoryGovernor.cs';s=p.read_text(encoding='utf-8')
s=s.replace('capacity == 0 ? 0 : 64L + 24L * capacity','capacity == 0 ? 0 : 512L + 24L * capacity',1)
s=s.replace('            if (capacity == 0) return [];','            capacity = Math.Max(1, capacity);',1)
p.write_text(s,encoding='utf-8')
print('Unified compiled callback entry and explicit workspace/activation funding; no abstract native body hooks remain.')
