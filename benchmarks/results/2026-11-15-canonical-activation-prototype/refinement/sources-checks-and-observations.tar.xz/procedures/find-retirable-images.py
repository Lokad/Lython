from pathlib import Path
import hashlib,json,subprocess,tarfile
repo=Path(__file__).resolve().parents[4]
folder=repo/'benchmarks/results/2026-11-07-canonical-format-instructions'
proofs=[]
for filename in ['b386-checked-source-and-images.tgz','checked-source-and-images-final.tgz']:
    p=folder/filename
    tracked=p.relative_to(repo).as_posix()
    commit=subprocess.check_output(['git','log','-1','--format=%H','--',tracked],cwd=repo,text=True).strip()
    assert commit
    assert subprocess.check_output(['git','hash-object',str(p)],cwd=repo,text=True).strip()==subprocess.check_output(['git','rev-parse',f'{commit}:{tracked}'],cwd=repo,text=True).strip()
    with tarfile.open(p) as archive:
        for member in archive:
            if member.isfile() and member.name.endswith('Lokad.Lython.dll'):
                value=archive.extractfile(member).read()
                proofs.append(dict(commit=commit,archive=tracked,archiveSHA256=hashlib.sha256(p.read_bytes()).hexdigest(),member=member.name,coreSHA256=hashlib.sha256(value).hexdigest(),bytes=len(value)))
(Path(__file__).parent/'retirable-proof-candidates.json').write_text(json.dumps(proofs,indent=2)+'\n',encoding='utf-8')
print(json.dumps(proofs,indent=2))
