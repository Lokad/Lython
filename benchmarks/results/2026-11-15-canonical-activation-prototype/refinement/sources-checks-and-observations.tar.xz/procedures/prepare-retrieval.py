from pathlib import Path
r=Path(__file__).resolve().parent;q=r/'quiet'
source=(r.parent/'tuple-transport-r397/quiet/retrieve.py').read_text(encoding='utf-8')
source=source.replace('/home/lokad/lython-bench-checks/tuple-transport-b782-20261115','/home/lokad/lython-bench-checks/activation-b787-20261115')
source=source.replace('lython-b782-tuple-transport-20261115.service','lython-b787-canonical-activation-20261115.service')
source=source.replace("status['receipt']['jobs']==4", "status['receipt']['jobs']==6")
source=source.replace('B782','B787').replace('four-job','six-job')
(q/'retrieve.py').write_text(source,encoding='utf-8')
