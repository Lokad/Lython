from pathlib import Path
import json, os, statistics, subprocess, tempfile, time

root=Path(__file__).resolve().parent/'final-storage'
sdk='C:/Users/JoannesVermorel/.dotnet11'
env=dict(os.environ);env['DOTNET_ROOT']=sdk
start=time.monotonic(); records=[]
with tempfile.TemporaryDirectory(prefix='lython-comparison-files-') as fixture:
    env['TEMP']=fixture;env['TMP']=fixture
    for role in ('reference','candidate'):
        output=root/(role+'-allocation.json')
        assert not output.exists()
        with (root/(role+'-allocation.log')).open('w',encoding='utf-8') as log:
            done=subprocess.run([sdk+'/dotnet.exe',str(root/role/'Allocation.dll'),str(root/role),str(root/'catalog.json'),str(output)],
                env=env,stdout=log,stderr=subprocess.STDOUT,timeout=75)
        assert done.returncode==0,(role,(root/(role+'-allocation.log')).read_text(encoding='utf-8')[-2000:])
        records.append(dict(role=role,data=json.loads(output.read_text(encoding='utf-8'))))
        print(role,[(v['id'],statistics.median(v['allocatedBytesPerInvocation']))for v in records[-1]['data']['rows']],flush=True)
    assert not list(Path(fixture).iterdir())
rows=[]
for case in records[0]['data']['rows']:
    before=statistics.median(case['allocatedBytesPerInvocation'])
    after=statistics.median(next(c for c in records[1]['data']['rows'] if c['id']==case['id'])['allocatedBytesPerInvocation'])
    rows.append(dict(case=case['id'],referenceBytes=before,candidateBytes=after,changePercent=100*(after/before-1)))
(root/'allocation-summary.json').write_text(json.dumps(dict(complete=True,elapsedSeconds=time.monotonic()-start,rows=rows,allGoldensAndBudgetChecksPassed=True,allUsersJoinedAndFixturesRemoved=True,CPUorElapsedClaim=False),indent=2)+'\n',encoding='utf-8')
print(rows)
