from pathlib import Path
root=Path(__file__).resolve().parent
source=(root/'freeze-initial.py').read_text(encoding='utf-8')
source=source.replace("root/'initial-unified'", "root/'reused-storage'")
source=source.replace("('r403-initial-internal.trx','r403-internal-refined.trx')", "('r403-workspace-initial.trx','r403-workspace-refined.trx')")
source=source.replace("('r403-initial-public.trx','r403-expanded-public.trx')", "('r403-workspace-public.trx',)")
source=source.replace('126internal/401expanded public net11 pass; no full or net10 qualification yet.', '167internal/411public net11 pass; canonical workspace replaces array-only cache; no full or net10 qualification yet.')
exec(compile(source, str(root/'freeze-initial.py'), 'exec'))
