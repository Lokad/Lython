from pathlib import Path

repo=Path(__file__).resolve().parents[4];t=repo/'tests/Lokad.Lython.Tests'
p=t/'SimpleFunctionExecutionBoundaryTests.cs';s=p.read_text(encoding='utf-8')
s=s.replace('function.TryStartBoundInvocation(bound, CallSpan, out _, out _)', 'RunBound(function, bound, CallSpan)')
s=s.replace('''                    Assert.True(function.TryStartBoundInvocation(bound, CallSpan, out var result, out var frame));
                    Assert.Null(frame);
                    Assert.Equal(new BigInteger(expected), result.Object);''','''                    Assert.Equal(new BigInteger(expected), RunBound(function, bound, CallSpan));''',1)
# RunBound owns and returns its binding; retain independent semantic assertions.
s=s.replace('                LythonRuntime.ReturnBoundArguments(bound, code.ValueStorageCapacity);\n','')
s=s.replace('                    LythonRuntime.ReturnBoundArguments(bound, code.ValueStorageCapacity);\n','')
s=s.replace('BuiltinForLoopsFinishWithoutMaterializingAnInvocation','BuiltinForLoopsPreserveResultsAndOwnedInputs')
s=s.replace('KeywordDefaultPrefixUsesFundedInputsWithoutAdditionalAdmission','KeywordDefaultsUseOwnedArgumentsAndKeepInputAliases')
s=s.replace('                Assert.True(function.CanBindNativeArguments);\n','')
old='''                var baseline = budget.ReservedBytes;
                hook.RefuseGrowth = _ => true;
                context.EnterInterpreterFrame(CallSpan);'''
new='''                var bound = function.BindCallOperands([Slot.FromObject(line)], CallSpan, context, null, call);
                var baseline = budget.ReservedBytes;
                hook.RefuseGrowth = _ => true;
                context.EnterInterpreterFrame(CallSpan);'''
assert old in s;s=s.replace(old,new,1)
start=s.index('                    function.StartNativeCall(');end=s.index('                    Assert.Null(context.MemoryGovernor.AdmissionFailure);',start)
s=s[:start]+'''                    Assert.True(Assert.IsType<bool>(RunBound(function, bound, CallSpan)));
'''+s[end:]
where=s.index('    private static (PyExecutableFunction Function,')
s=s[:where]+'''    private static object RunBound(PyExecutableFunction function, BoundFunctionArguments bound, LythonSourceSpan span)
    {
        var invocation = function.StartInvocation(bound, span);
        try
        {
            invocation.Execute();
            return invocation.Work.ReturnValue.Object.RequireNotNull();
        }
        finally { invocation.Retire(); }
    }

'''+s[where:]
p.write_text(s,encoding='utf-8')

p=t/'CasedSplitOwnershipTests.cs';s=p.read_text(encoding='utf-8')
start=s.index('            var values = new LythonRuntime.ExecutableSlot[code.ValueStorageCapacity];');end=s.index('            context.State.CloseResources();',start)
s=s[:start]+'''            var bound = function.BindCallOperands([LythonRuntime.ExecutableSlot.FromObject(input)], span, context, null, null);
            var execution = function.StartInvocation(bound, span);
            execution.Work.Stack.Values[source].Object = cursor;
            execution.Work.InstructionIndex = index;
            execution.Work.Stack.RestoreNativeExtent(source + 1);
            // Interrupt a real prepared private result before its consumer.
'''+s[end:]
s=s.replace('execution.Run(span, out _)','execution.Execute()',1).replace('finally { execution.Dispose(); }','finally { execution.Retire(); }',1)
p.write_text(s,encoding='utf-8')
print('Adapted native-only entry tests to the actual common activation; observable lifetime assertions remain.')
