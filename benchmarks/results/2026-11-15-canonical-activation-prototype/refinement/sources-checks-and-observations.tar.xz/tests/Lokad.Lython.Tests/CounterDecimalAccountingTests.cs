using System.Numerics;
using System.Reflection;
using Lokad.Lython.Runtime;
using Lokad.Lython.Runtime.Text;
using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.Tests;

/// <summary>
/// MG11: fresh decimal counts produced on Counter paths own their storage;
/// increments, totals and arithmetic over decimal counts commit per fresh value.
/// Borrowed counters fund fresh decimal values through the active execution.
/// </summary>
public sealed class CounterDecimalAccountingTests
{
    [Fact]
    public void BorrowedCounterUnaryResultUsesTheActiveOwnerAndContext()
    {
        var root = new LythonMemoryBudget(65536);
        using (var owner = root.CreateScope())
        {
            var context = new LythonRuntime.ExecutionContext(new MockLythonHost(), new LythonRunOptions { MemoryBudget = owner });
            var span = new LythonSourceSpan(0, 0, 0, 0);
            var policy = context.DecimalContext;
            policy.TrySetMember("prec", new BigInteger(3));
            var key = PyString.FromString("negative");
            var old = new PyDecimal(-1.239m);
            var source = new PyCounter();
            source.SetItem(key, old);
            var before = root.ReservedBytes;
            var result = Assert.IsType<PyCounter>(InvokeOperator("EvaluateUnaryMinus", context, span, source));
            Assert.Same(context.MemoryGovernor, result.OwnerMemoryGovernor);
            Assert.True(result.TryGetValue(key, out var resultCount));
            Assert.Equal(1.24m, Assert.IsType<PyDecimal>(resultCount).Value);
            Assert.True(source.TryGetValue(key, out var sourceCount));
            Assert.Same(old, sourceCount);
            Assert.True(root.ReservedBytes > before);
            Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
        }
        Assert.Equal(0, root.ReservedBytes);
    }

    [Fact]
    public void CounterDecimalIncrementsPreserveValuesAndAliases()
    {
        var host = new MockLythonHost();
        var context = new LythonRuntime.ExecutionContext(host, new LythonRunOptions(),regexProvider:Utf8RegexProvider.Instance);
        var span = new LythonSourceSpan(0, 0, 0, 0);
        var key = PyString.FromString("a");
        var counter = new PyCounter(context.MemoryGovernor, span);
        counter.SetItem(key, new PyDecimal(1m));
        _ = context.DecimalContext;
        var before = context.MemoryGovernor.CurrentCommittedBytes;
        Assert.True(LythonRuntime.CounterMembers.TryGetMember(counter, "update", out var update));
        var incoming = new PyDict();
        incoming.SetItem(key, new PyDecimal(2m));
        ((LythonRuntime.ICallable)update).Invoke([CallArgumentValue.Positional(incoming)], span, context);
        Assert.True(counter.TryGetValue(key, out var stored));
        Assert.Equal(3m, ((PyDecimal)stored).Value);
        Assert.Equal(before + 64L, context.MemoryGovernor.CurrentCommittedBytes);
        Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
    }

    [Fact]
    public void CounterDecimalTotalsPreserveValuesAndAliases()
    {
        var host = new MockLythonHost();
        var context = new LythonRuntime.ExecutionContext(host, new LythonRunOptions(),regexProvider:Utf8RegexProvider.Instance);
        var span = new LythonSourceSpan(0, 0, 0, 0);
        var counter = new PyCounter(context.MemoryGovernor, span);
        counter.SetItem(PyString.FromString("a"), new PyDecimal(1m));
        counter.SetItem(PyString.FromString("b"), new PyDecimal(2m));
        Assert.True(LythonRuntime.CounterMembers.TryGetMember(counter, "total", out var member));
        var callable = (LythonRuntime.ICallable)member;
        var before = context.MemoryGovernor.CurrentCommittedBytes;
        var total = callable.Invoke([], span, context);
        Assert.Equal(3m, ((PyDecimal)total).Value);
        Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
    }

    [Fact]
    public void BorrowedCounterDecimalUpdatesUseTheActiveOwner()
    {
        var host = new MockLythonHost();
        var context = new LythonRuntime.ExecutionContext(host, new LythonRunOptions(),regexProvider:Utf8RegexProvider.Instance);
        var span = new LythonSourceSpan(0, 0, 0, 0);
        var counter = new PyCounter();
        counter.SetItem(PyString.FromString("a"), new PyDecimal(1m));
        Assert.True(LythonRuntime.CounterMembers.TryGetMember(counter, "update", out var update));
        var incoming = new PyDict();
        incoming.SetItem(PyString.FromString("a"), new PyDecimal(2m));
        _ = context.DecimalContext;
        var baseline = context.MemoryGovernor.CurrentCommittedBytes;
        ((LythonRuntime.ICallable)update).Invoke([CallArgumentValue.Positional(incoming)], span, context);
        Assert.Equal(64, context.MemoryGovernor.CurrentCommittedBytes - baseline);
        Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
    }

    [Fact]
    public void CounterDecimalSubtractsPreserveValuesAndAliases()
    {
        var host = new MockLythonHost();
        var context = new LythonRuntime.ExecutionContext(host, new LythonRunOptions(),regexProvider:Utf8RegexProvider.Instance);
        var span = new LythonSourceSpan(0, 0, 0, 0);
        var key = PyString.FromString("a");
        var counter = new PyCounter(context.MemoryGovernor, span);
        counter.SetItem(key, new PyDecimal(1m));
        var delta = new PyDict(context.MemoryGovernor, span);
        delta.SetItem(key, new PyDecimal(2m));
        Assert.True(LythonRuntime.CounterMembers.TryGetMember(counter, "subtract", out var member));
        var callable = (LythonRuntime.ICallable)member;
        var before = context.MemoryGovernor.CurrentCommittedBytes;
        callable.Invoke([CallArgumentValue.Positional(delta)], span, context);
        Assert.True(counter.TryGetValue(key, out var stored));
        Assert.Equal(-1m, ((PyDecimal)stored).Value);
        // The receiver transfers its entry allowance; the fresh decimal payload
        // and call machinery keep their independently funded storage.
        Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
    }

    private static object InvokeOperator(
        string name,
        LythonRuntime.ExecutionContext context,
        LythonSourceSpan span,
        params object[] operands)
    {
        var method = typeof(LythonRuntime).GetMethod(name, BindingFlags.Static | BindingFlags.NonPublic)
            ?? throw new InvalidOperationException(name + " not found.");
        var arguments = new object?[method.GetParameters().Length];
        Array.Copy(operands, arguments, operands.Length);
        arguments[operands.Length] = context;
        arguments[operands.Length + 1] = span;
        return method.Invoke(null, arguments)
            ?? throw new InvalidOperationException(name + " returned null.");
    }

    [Fact]
    public void CounterDecimalOperatorsPreserveValuesAndAliases()
    {
        var host = new MockLythonHost();
        var context = new LythonRuntime.ExecutionContext(host, new LythonRunOptions(),regexProvider:Utf8RegexProvider.Instance);
        var span = new LythonSourceSpan(0, 0, 0, 0);
        var key = PyString.FromString("a");
        static PyCounter CounterWith(LythonRuntime.ExecutionContext context, LythonSourceSpan span, object key, object value)
        {
            var counter = new PyCounter(context.MemoryGovernor, span);
            counter.SetItem(key, value);
            return counter;
        }

        var sum = (PyCounter)InvokeOperator("EvaluateAdd", context, span,
            CounterWith(context, span, key, new PyDecimal(1m)), CounterWith(context, span, key, new PyDecimal(2m)));
        Assert.True(sum.TryGetValue(key, out var sumValue));
        Assert.Equal(3m, ((PyDecimal)sumValue).Value);
        // Fresh results stay funded without a pending construction reservation.
        Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);

        var diff = (PyCounter)InvokeOperator("EvaluateSubtract", context, span,
            CounterWith(context, span, key, new PyDecimal(2m)), CounterWith(context, span, key, new PyDecimal(1m)));
        Assert.True(diff.TryGetValue(key, out var diffValue));
        Assert.Equal(1m, ((PyDecimal)diffValue).Value);

        var intNeg = (PyCounter)InvokeOperator("EvaluateUnaryMinus", context, span,
            CounterWith(context, span, key, new BigInteger(2)));
        Assert.Equal(0, intNeg.Count);
        var neg = (PyCounter)InvokeOperator("EvaluateUnaryMinus", context, span,
            CounterWith(context, span, key, new PyDecimal(2m)));
        Assert.Equal(0, neg.Count);
    }

    [Fact]
    public void CounterBitwiseSelectionsPreserveAliasesAndFundStorage()
    {
        var host = new MockLythonHost();
        var context = new LythonRuntime.ExecutionContext(host, new LythonRunOptions(),regexProvider:Utf8RegexProvider.Instance);
        var span = new LythonSourceSpan(0, 0, 0, 0);
        var key = PyString.FromString("a");
        static PyCounter CounterWith(LythonRuntime.ExecutionContext context, LythonSourceSpan span, object key, object value)
        {
            var counter = new PyCounter(context.MemoryGovernor, span);
            counter.SetItem(key, value);
            return counter;
        }

        static long Committed(LythonRuntime.ExecutionContext context) => context.MemoryGovernor.CurrentCommittedBytes;

        var leftCount = new PyDecimal(1m);
        var rightCount = new PyDecimal(2m);
        var beforeIntOr = Committed(context);
        _ = InvokeOperator("EvaluateBitwiseOr", context, span,
            CounterWith(context, span, key, new BigInteger(1)), CounterWith(context, span, key, new BigInteger(2)));
        var intOrBacking = Committed(context) - beforeIntOr;
        var beforeDecOr = Committed(context);
        var union = (PyCounter)InvokeOperator("EvaluateBitwiseOr", context, span,
            CounterWith(context, span, key, leftCount), CounterWith(context, span, key, rightCount));
        Assert.True(union.TryGetValue(key, out var unionValue));
        Assert.Same(rightCount, unionValue);
        Assert.Equal(intOrBacking, Committed(context) - beforeDecOr);

        var beforeIntAnd = Committed(context);
        _ = InvokeOperator("EvaluateBitwiseAnd", context, span,
            CounterWith(context, span, key, new BigInteger(1)), CounterWith(context, span, key, new BigInteger(2)));
        var intAndBacking = Committed(context) - beforeIntAnd;
        var beforeDecAnd = Committed(context);
        var intersection = (PyCounter)InvokeOperator("EvaluateBitwiseAnd", context, span,
            CounterWith(context, span, key, leftCount), CounterWith(context, span, key, rightCount));
        Assert.True(intersection.TryGetValue(key, out var intersectionValue));
        Assert.Same(leftCount, intersectionValue);
        Assert.Equal(intAndBacking, Committed(context) - beforeDecAnd);
        Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
    }
}

