using System.Numerics;
using Lokad.Lython.Runtime;
using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.Tests;

// Live container storage allowances: mutations preserve retained-capacity
// funding; denied growth leaves existing storage and metadata funded.
public sealed class ContainerScalarStorageTests
{
    private static (LythonRuntime.ExecutionContext Context, LythonSourceSpan Span) Budgeted(long maxBytes)
    {
        var host = new MockLythonHost();
        var context = new LythonRuntime.ExecutionContext(host, new LythonRunOptions { MemoryBudget = new LythonMemoryBudget(maxBytes) },regexProvider:Utf8RegexProvider.Instance);
        return (context, new LythonSourceSpan(0, 0, 0, 0));
    }

    [Fact]
    public void ListRemovalRetainsCapacityFunding()
    {
        // Removing values retains the admitted backing and numeric headroom.
        var host = new MockLythonHost();
        var context = new LythonRuntime.ExecutionContext(host, new LythonRunOptions(),regexProvider:Utf8RegexProvider.Instance);
        var span = new LythonSourceSpan(0, 0, 0, 0);
        var governor = context.MemoryGovernor;
        var items = new object[] { new BigInteger(1), new BigInteger(2) };
        var before = governor.CurrentCommittedBytes;
        var list = new PyList(items, governor, span);

        var trackedBefore = list.CommittedStorageBytes;
        list.RemoveAt(0);
        list.RemoveAt(0);
        Assert.Equal(trackedBefore, list.CommittedStorageBytes);

        Assert.Equal(
            list.CommittedStorageBytes,
            governor.CurrentCommittedBytes - before);
    }

    [Theory]
    [InlineData(0, 5, 2)]
    [InlineData(4, -1, -2)]
    public void ListSteppedDeletionPreservesValuesAndCapacity(int start, int end, int step)
    {
        var governor = new MemoryGovernor(new LythonMemoryBudget(65536));
        var items = Enumerable.Range(0, 5).Select(i => (object)new BigInteger(i)).ToArray();
        var list = new PyList(items, governor);
        var backing = list.CommittedStorageBytes;

        list.DeleteSlice(new PyIndexing.SliceBounds(start, end, step));
        Assert.Equal(2, list.Count);
        Assert.Same(items[1], list[0]);
        Assert.Same(items[3], list[1]);
        list.RemoveAt(0);
        list.RemoveAt(0);

        Assert.Empty(list);
        Assert.Equal(backing, list.CommittedStorageBytes);
        Assert.Equal(backing, list.CommittedStorageBytes);
        Assert.Equal(backing, governor.CurrentCommittedBytes);
        Assert.Equal(0, governor.CurrentReservedBytes);
    }

    [Fact]
    public void ListSteppedDeletionRetainsArrayCapacity()
    {
        var governor = new MemoryGovernor(new LythonMemoryBudget(65536));
        var items = Enumerable.Range(0, 32).Select(i => (object)new BigInteger(i)).ToArray();
        var list = new PyList(items, governor);
        var backing = list.CommittedStorageBytes;

        list.DeleteSlice(new PyIndexing.SliceBounds(0, items.Length, 2));
        Assert.Equal(16, list.Count);
        for (var index = 0; index < list.Count; index++) Assert.Same(items[index * 2 + 1], list[index]);
        while (list.Count != 0) list.RemoveAt(0);

        Assert.Equal(backing, list.CommittedStorageBytes);
        Assert.Equal(backing, list.CommittedStorageBytes);
        Assert.Equal(backing, governor.CurrentCommittedBytes);
        Assert.Equal(0, governor.CurrentReservedBytes);
    }

    [Fact]
    public void ListSteppedDeletionPreservesAliasesAndCapacity()
    {
        var governor = new MemoryGovernor(new LythonMemoryBudget(65536));
        object removed = new BigInteger(1);
        object kept = new BigInteger(2);
        var list = new PyList(new object[] { removed, kept, removed, kept, new BigInteger(3) }, governor);
        var backing = list.CommittedStorageBytes;

        list.DeleteSlice(new PyIndexing.SliceBounds(0, 5, 2));
        Assert.Equal(2, list.Count);
        Assert.Same(kept, list[0]);
        Assert.Same(kept, list[1]);
        Assert.Equal(backing, list.CommittedStorageBytes);

        list.RemoveAt(0);
        Assert.Equal(backing, list.CommittedStorageBytes);
        list.RemoveAt(0);
        Assert.Equal(backing, list.CommittedStorageBytes);
        Assert.Equal(backing, list.CommittedStorageBytes);
        Assert.Equal(backing, governor.CurrentCommittedBytes);
        Assert.Equal(0, governor.CurrentReservedBytes);
    }

    [Fact]
    public void SetDuplicateAddAdoptsOnce()
    {
        // Sets deduplicate: re-adding a held identity (or a structural twin)
        // retains nothing new, so no second slot estimate commits.
        var host = new MockLythonHost();
        var context = new LythonRuntime.ExecutionContext(host, new LythonRunOptions(),regexProvider:Utf8RegexProvider.Instance);
        var span = new LythonSourceSpan(0, 0, 0, 0);
        var governor = context.MemoryGovernor;
        var set = new PySet(governor, span);
        object box = new BigInteger(7);
        Assert.True(set.Add(box));
        var trackedAfterFirst = set.CommittedStorageBytes;
        Assert.False(set.Add(box));
        Assert.Equal(trackedAfterFirst, set.CommittedStorageBytes);
        Assert.False(set.Add(new BigInteger(7)));
        Assert.Equal(trackedAfterFirst, set.CommittedStorageBytes);
    }

    [Fact]
    public void SetRemovalKeepsRetainedCapacityFunded()
    {
        // Removals keep the actual capacity and scalar headroom funded.
        var host = new MockLythonHost();
        var context = new LythonRuntime.ExecutionContext(host, new LythonRunOptions(),regexProvider:Utf8RegexProvider.Instance);
        var span = new LythonSourceSpan(0, 0, 0, 0);
        var governor = context.MemoryGovernor;
        var before = governor.CurrentCommittedBytes;
        var set = new PySet(new object[] { new BigInteger(1), new BigInteger(2) }, governor, span);

        var trackedBefore = set.CommittedStorageBytes;
        Assert.True(set.Remove(new BigInteger(1)));
        Assert.True(set.Remove(new BigInteger(2)));
        Assert.Equal(trackedBefore, set.CommittedStorageBytes);

        Assert.Equal(
            set.CommittedStorageBytes,
            governor.CurrentCommittedBytes - before);
    }

    [Fact]
    public void SetStructuralTwinRemovesHeldBox()
    {
        // Removal resolves the stored identity: discarding via an equal-but-
        // distinct box evicts the held box while retaining funded capacity.
        var host = new MockLythonHost();
        var context = new LythonRuntime.ExecutionContext(host, new LythonRunOptions(),regexProvider:Utf8RegexProvider.Instance);
        var span = new LythonSourceSpan(0, 0, 0, 0);
        var governor = context.MemoryGovernor;
        var set = new PySet(governor, span);
        object held = new BigInteger(7);
        Assert.True(set.Add(held));
        var trackedBefore = set.CommittedStorageBytes;
        Assert.False(set.Add(new BigInteger(7)));
        Assert.True(set.Remove(new BigInteger(7)));
        Assert.Equal(trackedBefore, set.CommittedStorageBytes);
        Assert.Equal(0, set.Count);
    }

    [Fact]
    public void FailedGrowthLeavesTableUnchanged()
    {
        // Hold genuine storage pressure after construction, then prove
        // refused replacement capacity leaves the table and aliases intact.
        var host = new MockLythonHost();
        var span = new LythonSourceSpan(0, 0, 0, 0);
        static PySet BuildSet(LythonRuntime.ExecutionContext context, LythonSourceSpan span)
        {
            var set = new PySet(context.MemoryGovernor, span);
            for (var i = 0; i < 16; i++)
            {
                Assert.True(set.Add(new BigInteger(1000 + i)));
            }

            return set;
        }

        var measureContext = new LythonRuntime.ExecutionContext(host, new LythonRunOptions(),regexProvider:Utf8RegexProvider.Instance);
        var measured = BuildSet(measureContext, span);
        var baseline = measureContext.MemoryGovernor.CurrentCommittedBytes;
        var denyContext = new LythonRuntime.ExecutionContext(
            host, new LythonRunOptions { MemoryBudget = new LythonMemoryBudget(8192) },regexProvider:Utf8RegexProvider.Instance);
        var denied = BuildSet(denyContext, span);
        using var pressure = denyContext.MemoryGovernor.ReserveTemporary(8192 - denyContext.MemoryGovernor.CurrentAccountedBytes, span);
        Assert.Equal(baseline, denyContext.MemoryGovernor.CurrentCommittedBytes);
        Assert.Equal(16, denied.Count);
        var storedBefore = denied.CommittedStorageBytes;
        Assert.Throws<LythonRuntimeException>(() => denied.Add(new BigInteger(99999)));
        Assert.Equal(16, denied.Count);
        Assert.Equal(storedBefore, denied.CommittedStorageBytes);
        Assert.Equal(baseline, denyContext.MemoryGovernor.CurrentCommittedBytes);
        var retryContext = new LythonRuntime.ExecutionContext(
            host, new LythonRunOptions { MemoryBudget = new LythonMemoryBudget(baseline + 65536) },regexProvider:Utf8RegexProvider.Instance);
        var retried = BuildSet(retryContext, span);
        Assert.True(retried.Add(new BigInteger(99999)));
        Assert.Equal(17, retried.Count);
        Assert.Equal(measured.Count, retried.Count - 1);
    }

    [Fact]
    public void DictReplacementReusesEntryFunding()
    {
        // Replacing a value preserves the original key and reuses the entry
        // estimate; funding does not depend on the displaced scalar identity.
        var host = new MockLythonHost();
        var context = new LythonRuntime.ExecutionContext(host, new LythonRunOptions(),regexProvider:Utf8RegexProvider.Instance);
        var span = new LythonSourceSpan(0, 0, 0, 0);
        var governor = context.MemoryGovernor;
        var dict = new PyDict(governor, span);
        object key = new BigInteger(1);
        dict.SetItem(key, new BigInteger(100));
        var trackedAfterInsert = dict.CommittedStorageBytes;
        dict.SetItem(key, new BigInteger(200));
        Assert.Equal(trackedAfterInsert, dict.CommittedStorageBytes);
        Assert.Equal(new BigInteger(200), dict.GetItem(key));
    }

    [Fact]
    public void DictTwinKeyRemovalRetainsTheFundedCapacity()
    {
        // Removing via a structural twin (7.0 for stored 7) evicts the held pair
        // and releases its allowance without retaining a key identity map.
        var host = new MockLythonHost();
        var context = new LythonRuntime.ExecutionContext(host, new LythonRunOptions(),regexProvider:Utf8RegexProvider.Instance);
        var span = new LythonSourceSpan(0, 0, 0, 0);
        var governor = context.MemoryGovernor;
        var dict = new PyDict(governor, span);
        object held = new BigInteger(7);
        dict.SetItem(held, new BigInteger(100));
        var trackedBefore = dict.CommittedStorageBytes;
        Assert.True(dict.Remove(7.0));
        Assert.Equal(trackedBefore, dict.CommittedStorageBytes);
        Assert.Equal(0, dict.Count);
    }

    [Fact]
    public void DictGrowShrinkAndClearReuseFundedCapacity()
    {
        // Removed slots retain their pair headroom for reuse, without readmission.
        var (context, span) = Budgeted(1L << 20);
        var governor = context.MemoryGovernor;
        var dict = new PyDict(governor, span);
        var unrelated = governor.CurrentCommittedBytes - dict.CommittedStorageBytes;
        var keys = new object[6];
        var values = new object[6];
        for (var i = 0; i < 6; i++)
        {
            keys[i] = new BigInteger(i);
            values[i] = new BigInteger(1000 + i);
            dict.SetItem(keys[i], values[i]);
        }
        var fundedCapacity = dict.CommittedStorageBytes;

        for (var i = 0; i < 5; i++)
        {
            Assert.True(dict.Remove(keys[i]));
        }

        Assert.Equal(1, dict.Length);
        Assert.Equal(fundedCapacity, dict.CommittedStorageBytes);
        Assert.Equal(unrelated + dict.CommittedStorageBytes, governor.CurrentCommittedBytes);
        Assert.True(dict.Remove(keys[5]));
        Assert.Equal(fundedCapacity, dict.CommittedStorageBytes);
        Assert.Equal(unrelated + fundedCapacity, governor.CurrentCommittedBytes);
        dict.Clear();
        Assert.Equal(fundedCapacity, dict.CommittedStorageBytes);
        dict.SetItem(keys[2], values[2]);
        Assert.Equal(fundedCapacity, dict.CommittedStorageBytes);
    }

    [Fact]
    public void DictCopyAdoptsSharedPairs()
    {
        // Copies adopt shared identities again (bounded double charge), so each
        // side carries its own slotEstimates: identical construction commits identical
        // totals, and the shared boxes stay identical across the copy.
        var host = new MockLythonHost();
        var context = new LythonRuntime.ExecutionContext(host, new LythonRunOptions(),regexProvider:Utf8RegexProvider.Instance);
        var span = new LythonSourceSpan(0, 0, 0, 0);
        var governor = context.MemoryGovernor;
        var before = governor.CurrentCommittedBytes;
        var source = new PyDict(governor, span);
        object key = new BigInteger(1);
        object value = new BigInteger(2);
        source.SetItem(key, value);
        var copy = new PyDict(source);
        Assert.Equal(source.CommittedStorageBytes, copy.CommittedStorageBytes);
        Assert.Equal(
            source.CommittedStorageBytes + copy.CommittedStorageBytes,
            governor.CurrentCommittedBytes - before);
        Assert.True(ReferenceEquals(copy.GetItem(key), value));
    }

    [Fact]
    public void DictFailedGrowthLeavesTableUnchanged()
    {
        // Hold genuine storage pressure after construction, then prove
        // refused replacement capacity leaves the table and aliases intact.
        var host = new MockLythonHost();
        var span = new LythonSourceSpan(0, 0, 0, 0);
        static PyDict BuildDict(LythonRuntime.ExecutionContext context, LythonSourceSpan span)
        {
            var dict = new PyDict(context.MemoryGovernor, span);
            for (var i = 0; i < 10; i++)
            {
                dict.SetItem(new BigInteger(1000 + i), new BigInteger(i));
            }

            return dict;
        }

        var measureContext = new LythonRuntime.ExecutionContext(host, new LythonRunOptions(),regexProvider:Utf8RegexProvider.Instance);
        var measured = BuildDict(measureContext, span);
        Assert.Equal(10, measured.Count);
        var baseline = measureContext.MemoryGovernor.CurrentCommittedBytes;
        var denyContext = new LythonRuntime.ExecutionContext(
            host, new LythonRunOptions { MemoryBudget = new LythonMemoryBudget(8192) },regexProvider:Utf8RegexProvider.Instance);
        var denied = BuildDict(denyContext, span);
        using var pressure = denyContext.MemoryGovernor.ReserveTemporary(
            8192 - denyContext.MemoryGovernor.CurrentAccountedBytes, span);
        Assert.Equal(baseline, denyContext.MemoryGovernor.CurrentCommittedBytes);
        var storedBefore = denied.CommittedStorageBytes;
        var refused = false;
        for (var i = 0; i < 128; i++)
        {
            var contents = denied.ToArray();
            try { denied.SetItem(new BigInteger(99999 + i), new BigInteger(1)); }
            catch (LythonRuntimeException error)
            {
                Assert.Equal("MemoryError", error.ExceptionType);
                Assert.Equal(contents, denied.ToArray());
                refused = true;
                break;
            }
        }
        Assert.True(refused);
        Assert.Equal(storedBefore, denied.CommittedStorageBytes);
        Assert.Equal(baseline, denyContext.MemoryGovernor.CurrentCommittedBytes);
        var independentContext = new LythonRuntime.ExecutionContext(
            host, new LythonRunOptions { MemoryBudget = new LythonMemoryBudget(baseline + 65536) },regexProvider:Utf8RegexProvider.Instance);
        var independentlyFunded = BuildDict(independentContext, span);
        independentlyFunded.SetItem(new BigInteger(99999), new BigInteger(1));
        Assert.Equal(11, independentlyFunded.Count);
    }

    [Fact]
    public void TupleChargesEachRetainedNumericSlot()
    {
        // Immutable storage uses a conservative per-slot estimate; aliases
        // retain Python identity and have no identity-accounting table.
        var host = new MockLythonHost();
        var context = new LythonRuntime.ExecutionContext(host, new LythonRunOptions(),regexProvider:Utf8RegexProvider.Instance);
        var span = new LythonSourceSpan(0, 0, 0, 0);
        var governor = context.MemoryGovernor;
        var before = governor.CurrentCommittedBytes;
        object shared = new BigInteger(9);
        var tuple = new PyTuple(new object[] { new BigInteger(1), new BigInteger(2), shared, shared }, governor, span);
        var expected = PyTuple.EstimateApproximateBytes(4) + 4 * 64L;
        Assert.Equal(expected, tuple.CommittedStorageBytes);
        Assert.Equal(expected, governor.CurrentCommittedBytes - before);
        Assert.Equal(0, governor.CurrentReservedBytes);
    }

    [Fact]
    public void TupleDenialRefundsStorage()
    {
        // A denied construction slot estimate refunds the orphaned backing: nothing
        // stays committed and the tuple never publishes.
        var host = new MockLythonHost();
        var context = new LythonRuntime.ExecutionContext(host, new LythonRunOptions(),regexProvider:Utf8RegexProvider.Instance);
        var span = new LythonSourceSpan(0, 0, 0, 0);
        var governor = context.MemoryGovernor;
        var before = governor.CurrentCommittedBytes;
        var items = new object[] { new BigInteger(1), new BigInteger(2), new BigInteger(3) };
        var budget = PyTuple.EstimateApproximateBytes(items.Length) + RuntimeMemoryEstimates.ScalarStorageBytes - 1;
        var tight = new LythonRuntime.ExecutionContext(host, new LythonRunOptions { MemoryBudget = new LythonMemoryBudget(budget) },regexProvider:Utf8RegexProvider.Instance);
        Assert.Throws<LythonRuntimeException>(() => new PyTuple(items, tight.MemoryGovernor, span));
        Assert.Equal(0, tight.MemoryGovernor.CurrentCommittedBytes);
    }

    [Fact]
    public void DequeEvictionReusesRetainedCapacity()
    {
        // Bounded eviction adopts the incoming box and releases the evicted one:
        // node and slot estimate totals both stay flat across rotation.
        var host = new MockLythonHost();
        var context = new LythonRuntime.ExecutionContext(host, new LythonRunOptions(),regexProvider:Utf8RegexProvider.Instance);
        var span = new LythonSourceSpan(0, 0, 0, 0);
        var governor = context.MemoryGovernor;
        var deque = new PyDeque(2, governor, span);
        object a = new BigInteger(1);
        object b = new BigInteger(2);
        deque.Append(a);
        deque.Append(b);
        var tracked = deque.CommittedStorageBytes;
        deque.Append(new BigInteger(3));
        var current = deque.ToArray();
        Assert.Equal(2, current.Length);
        Assert.Same(b, current[0]);
        Assert.Equal(new BigInteger(3), current[1]);
        Assert.Equal(tracked, deque.CommittedStorageBytes);
    }

    [Fact]
    public void DequeFailedAppendRollsBackNode()
    {
        // A denied slot estimate rolls the node insertion back: count and charges are
        // exactly as before, and a funded retry succeeds. Nothing is
        // The borrowed owner refuses before mutation; no collection or retry.
        var host = new MockLythonHost();
        var context = new LythonRuntime.ExecutionContext(host, new LythonRunOptions(),regexProvider:Utf8RegexProvider.Instance);
        var span = new LythonSourceSpan(0, 0, 0, 0);
        static PyDeque BuildDeque(LythonRuntime.ExecutionContext context, LythonSourceSpan span)
        {
            var deque = new PyDeque(null, context.MemoryGovernor, span);
            for (var i = 0; i < 5; i++)
            {
                deque.Append(new BigInteger(i));
            }

            return deque;
        }

        var measureContext = new LythonRuntime.ExecutionContext(host, new LythonRunOptions(),regexProvider:Utf8RegexProvider.Instance);
        _ = BuildDeque(measureContext, span);
        var baseline = measureContext.MemoryGovernor.CurrentCommittedBytes;
        var denyContext = new LythonRuntime.ExecutionContext(
            host, new LythonRunOptions { MemoryBudget = new LythonMemoryBudget(8192) },regexProvider:Utf8RegexProvider.Instance);
        var denied = BuildDeque(denyContext, span);
        using var pressure = denyContext.MemoryGovernor.ReserveTemporary(8192 - denyContext.MemoryGovernor.CurrentAccountedBytes - RuntimeMemoryEstimates.ScalarStorageBytes + 1, span);
        Assert.Equal(baseline, denyContext.MemoryGovernor.CurrentCommittedBytes);
        Assert.Equal(5, denied.Count);
        var storedBefore = denied.CommittedStorageBytes;
        Assert.Throws<LythonRuntimeException>(() => denied.Append(new BigInteger(999)));
        Assert.Equal(5, denied.Count);
        Assert.Equal(storedBefore, denied.CommittedStorageBytes);
        Assert.Equal(baseline, denyContext.MemoryGovernor.CurrentCommittedBytes);
        var retryContext = new LythonRuntime.ExecutionContext(
            host, new LythonRunOptions { MemoryBudget = new LythonMemoryBudget(baseline + 65536) },regexProvider:Utf8RegexProvider.Instance);
        var retried = BuildDeque(retryContext, span);
        retried.Append(new BigInteger(999));
        Assert.Equal(6, retried.Count);
    }

    [Fact]
    public void DequeIndexReplacementPreservesCapacityFunding()
    {
        // Indexed writes adopt the incoming box and release the displaced one.
        var host = new MockLythonHost();
        var context = new LythonRuntime.ExecutionContext(host, new LythonRunOptions(),regexProvider:Utf8RegexProvider.Instance);
        var span = new LythonSourceSpan(0, 0, 0, 0);
        var governor = context.MemoryGovernor;
        var deque = new PyDeque(null, governor, span);
        object kept = new BigInteger(1);
        deque.Append(kept);
        deque.Append(new BigInteger(2));
        var before = governor.CurrentCommittedBytes;
        deque.SetIndex(1, new BigInteger(3));
        Assert.True(ReferenceEquals(kept, deque.GetIndex(0)));
        Assert.Equal(new BigInteger(3), deque.GetIndex(1));
        Assert.Equal(before, governor.CurrentCommittedBytes);
    }

}
