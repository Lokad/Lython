using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime;
using Lokad.Lython.Runtime.Text;
using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.Tests;

public sealed class DirectStringStartsWithTests
{
    [Theory]
    [InlineData(false, "startswith")]
    [InlineData(true, "startswith")]
    [InlineData(false, "endswith")]
    [InlineData(true, "endswith")]
    public async Task OrdinaryCallsPreserveValuesAndCleanup(bool asynchronous, string method)
    {
        var (code, context) = Prepare("return text.startswith(prefix)", method: method);
        context.Variables["text"] = PyString.FromString("alpha", context.MemoryGovernor, null);
        context.Variables["prefix"] = PyString.FromString("a", context.MemoryGovernor, null);
        if (asynchronous)
        {
            var pending = LythonRuntime.ExecuteExecutableCodeObjectAsync(code.EntryPoint, context);
            Assert.True(pending.IsCompleted);
            Assert.Equal(true, await pending);
        }
        else Assert.Equal(true, LythonRuntime.ExecuteExecutableCodeObject(code.EntryPoint, context, default, null));
        Assert.Null(context.CurrentExecutableFrame);
        Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
    }

    [Theory]
    [InlineData(false, "startswith")]
    [InlineData(true, "startswith")]
    [InlineData(false, "endswith")]
    [InlineData(true, "endswith")]
    public async Task DistinctStringsPreserveValuesAndUnwind(bool asynchronous, string method)
    {
        var (code, context) = Prepare("for text in [left,right]:\n    result=text.startswith(prefix)\n    record()\n", method: method);
        var left = PyString.FromString("alpha", context.MemoryGovernor, null);
        var right = PyString.FromString(" café😀 ", context.MemoryGovernor, null);
        var record = new Record();
        context.Variables["left"] = left;
        context.Variables["right"] = right;
        context.Variables["prefix"] = PyString.FromString("a", context.MemoryGovernor, null);
        context.Variables["record"] = record;
        Assert.Equal(1, Assert.Single(code.EntryPoint.CallSites, site => site.HasReceiver).ArgumentCount);
        if (asynchronous)
        {
            var pending = LythonRuntime.ExecuteExecutableCodeObjectAsync(code.EntryPoint, context);
            Assert.True(pending.IsCompleted);
            await pending;
        }
        else LythonRuntime.ExecuteExecutableCodeObject(code.EntryPoint, context, default, null);
        Assert.Equal(2, record.Values.Count);
        Assert.True(Assert.IsType<bool>(record.Values[0]));
        Assert.False(Assert.IsType<bool>(record.Values[1]));

        Assert.Null(context.CurrentExecutableFrame);
        Assert.Equal(0, context.State.CurrentInterpreterDepth);
        Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
    }

    [Theory]
    [InlineData(false, "startswith")]
    [InlineData(true, "startswith")]
    [InlineData(false, "endswith")]
    [InlineData(true, "endswith")]
    public async Task OrdinaryCallsPreserveResultsAndCleanup(bool asynchronous, string method)
    {
        {
            var (code, context) = Prepare("return text.startswith(prefix)\n", new LythonRunOptions { }, method);
            var text = PyString.FromString("word", context.MemoryGovernor, null);
            context.Variables["text"] = text;
            context.Variables["prefix"] = PyString.FromString(method == "startswith" ? "w" : "d", context.MemoryGovernor, null);
                Assert.Equal(true, asynchronous ? await LythonRuntime.ExecuteExecutableCodeObjectAsync(code.EntryPoint, context)
                    : LythonRuntime.ExecuteExecutableCodeObject(code.EntryPoint, context, default, null));
            Assert.Null(context.CurrentExecutableFrame);
            Assert.Equal(0, context.State.CurrentInterpreterDepth);
            Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
        }
    }

    [Theory]
    [InlineData(false, "startswith")]
    [InlineData(true, "startswith")]
    [InlineData(false, "endswith")]
    [InlineData(true, "endswith")]
    public async Task SuspendedArgumentKeepsTheEvaluatedReceiver(bool cancel, string method)
    {
        var (code, context) = Prepare("return text.startswith(argument())\n", method: method);
        var receiver = PyString.FromString("alpha", context.MemoryGovernor, null);
        var replacement = PyString.FromString("other", context.MemoryGovernor, null);
        var argument = new SuspendedArgument();
        context.Variables["text"] = receiver;
        context.Variables["argument"] = argument;
        var pending = LythonRuntime.ExecuteExecutableCodeObjectAsync(code.EntryPoint, context).AsTask();
        try
        {
            Assert.NotNull(argument.Frame);
            Assert.False(pending.IsCompleted);
            var operands = Operands(argument.Frame!);
            Assert.Same(receiver, operands[0]);
            Assert.IsNotAssignableFrom<LythonRuntime.ICallable>(operands[1]);
            context.Variables["text"] = replacement;
            if (cancel)
            {
                argument.Release.TrySetCanceled();
                await Assert.ThrowsAnyAsync<OperationCanceledException>(() => pending);

            }
            else
            {
                argument.Release.TrySetResult();
                Assert.Equal(true, await pending.WaitAsync(TimeSpan.FromSeconds(5)));

                Assert.Empty(Operands(argument.Frame!));
            }
            Assert.Equal(1, argument.Calls);
        }
        finally
        {
            argument.Release.TrySetCanceled();
            try { await pending.WaitAsync(TimeSpan.FromSeconds(5)); }
            catch (OperationCanceledException) { }
        }
        Assert.Null(context.CurrentExecutableFrame);
        Assert.Equal(0, context.State.CurrentInterpreterDepth);
        Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
    }

    [Theory]
    [InlineData(false, "startswith")]
    [InlineData(true, "startswith")]
    [InlineData(false, "endswith")]
    [InlineData(true, "endswith")]
    public async Task FallbackLookupCanSuspendBeforeArguments(bool cancel, string memberName)
    {
        var (code, context) = Prepare("class C:\n    @property\n    def startswith(self): return lookup()\nreturn C().startswith(argument())\n", method: memberName);
        var method = new ArgumentProbe();
        var argument = new ArgumentProbe();
        var lookup = new SuspendedArgument { Value = method };
        context.Variables["lookup"] = lookup;
        context.Variables["argument"] = argument;
        var pending = LythonRuntime.ExecuteExecutableCodeObjectAsync(code.EntryPoint, context).AsTask();
        try
        {
            await lookup.Started.Task.WaitAsync(TimeSpan.FromSeconds(5));
            // Class getters may retain the lowered route; the enclosing
            // executable invocation remains active while lookup suspends.
            Assert.NotNull(context.CurrentExecutableFrame);
            Assert.Equal(1, lookup.Calls);
            Assert.False(pending.IsCompleted);
            Assert.Equal(0, argument.Calls);
            if (cancel)
            {
                lookup.Release.TrySetCanceled();
                await Assert.ThrowsAnyAsync<OperationCanceledException>(() => pending);
                Assert.Equal(0, argument.Calls);
                Assert.Equal(0, method.Calls);
            }
            else
            {
                lookup.Release.TrySetResult();
                Assert.Same(method.Value, await pending.WaitAsync(TimeSpan.FromSeconds(5)));
                Assert.Equal(1, argument.Calls);
                Assert.Equal(1, method.Calls);
                Assert.Same(argument.Value, method.LastArgument);
            }
        }
        finally
        {
            lookup.Release.TrySetCanceled();
            try { await pending.WaitAsync(TimeSpan.FromSeconds(5)); }
            catch (OperationCanceledException) { }
        }
        Assert.Null(context.CurrentExecutableFrame);
        Assert.Equal(0, context.State.CurrentInterpreterDepth);
        Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
    }

    private static (ExecutableScript, LythonRuntime.ExecutionContext) Prepare(string source, LythonRunOptions? options = null, string method = "startswith")
    {
        var frontend = LythonFrontend.Compile(source.Replace("startswith", method, StringComparison.Ordinal),regexProvider:Utf8RegexProvider.Instance);
        return (ExecutableScript.Compile(LoweredScript.Lower(frontend.Script.RequireNotNull())), new(new MockLythonHost(), options ?? new()));
    }

    private sealed class Record : LythonRuntime.ICallable
    {
        internal List<object> Values { get; } = [];
        internal LythonRuntime.ExecutionContext? Frame;
        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, LythonRuntime.ExecutionContext context)
        {
            Frame = context.CurrentExecutableFrame;
            Assert.True(Frame!.TryReadExecutableLocal("result", out var value));
            Values.Add(value);
            return PyNone.Instance;
        }
    }
    private static object[] Operands(object frame)
    {
        var context = (LythonRuntime.ExecutionContext)frame;
        var stack = context._execution.Stack;
        var items = stack.Values;
        var count = stack.LiveExtent;
        if (items is null)
        {
            Assert.Equal(0, count);
            Assert.Empty(context._execution.Locals);
            Assert.Null(context._execution.Code);
            return [];
        }
        var first = context._execution.Code.FirstTemporarySlot;
        var values = new object[count - first];
        for (var i = 0; i < values.Length; i++) values[i] = items[first + i].Object.RequireNotNull();
        return values;
    }

    private sealed class SuspendedArgument : LythonRuntime.ICallable
    {
        internal object Value { get; init; } = PyString.FromString("a");
        internal LythonRuntime.ExecutionContext? Frame;
        internal int Calls;
        internal TaskCompletionSource Started { get; } = new(TaskCreationOptions.RunContinuationsAsynchronously);
        internal TaskCompletionSource Release { get; } = new(TaskCreationOptions.RunContinuationsAsynchronously);
        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, LythonRuntime.ExecutionContext context)
            => throw new InvalidOperationException("Expected asynchronous call.");
        public async ValueTask<object> InvokeAsync(CallArgumentValue[] arguments, LythonSourceSpan span, LythonRuntime.ExecutionContext context)
        {
            Calls++;
            Frame = context.CurrentExecutableFrame;
            Started.TrySetResult();
            await Release.Task.ConfigureAwait(false);
            return Value;
        }
    }
    private sealed class ArgumentProbe : LythonRuntime.ICallable
    {
        internal int Calls;
        internal object Value { get; } = new();
        internal object? LastArgument;
        internal LythonRuntime.ExecutionContext? Frame;
        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, LythonRuntime.ExecutionContext context)
        {
            Calls++;
            if (arguments.Length != 0) LastArgument = Assert.Single(arguments).Value;
            Frame = context.CurrentExecutableFrame;
            return Value;
        }
    }


}
