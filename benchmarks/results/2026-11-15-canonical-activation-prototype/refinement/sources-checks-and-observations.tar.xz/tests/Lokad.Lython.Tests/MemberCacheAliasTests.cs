using System.Reflection;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime;
using Lokad.Lython.Runtime.Text;
using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.Tests;

/// <summary>
/// Only immediate calls may reuse bound method objects. Exposed methods and
/// mutable data arms resolve anew; immutable data caching stays run-local.
/// </summary>
public sealed class MemberCacheAliasTests
{
    private static LoweredMemberExpression SiteFor(string name)
    {
        var span = new LythonSourceSpan(0, 0, 0, 0);
        return new LoweredMemberExpression(new MemberExpressionSyntax(null!, name, span), null!);
    }

    private static object Resolve(object target, LoweredMemberExpression site, LythonRuntime.ExecutionContext context, bool isCallTarget = false)
    {
        var method = typeof(LythonRuntime).GetMethod("ResolveLoweredMemberValue", BindingFlags.Static | BindingFlags.NonPublic)
            ?? throw new InvalidOperationException("ResolveLoweredMemberValue not found.");
        return method.Invoke(null, [site, target, context, isCallTarget])
            ?? throw new InvalidOperationException("Resolve returned null.");
    }

    private static LythonRuntime.ExecutionContext NewContext()
        => new(new MockLythonHost(), new LythonRunOptions(),regexProvider:Utf8RegexProvider.Instance);

    private static object MakeZipInfo(LythonRuntime.ExecutionContext context, LythonSourceSpan span)
    {
        var type = typeof(LythonRuntime).GetNestedType("ZipInfoCallable", BindingFlags.NonPublic)
            ?? throw new InvalidOperationException("ZipInfoCallable not found.");
        var instance = type.GetField("Instance", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static)?.GetValue(null)
            ?? throw new InvalidOperationException("ZipInfoCallable.Instance not found.");
        var method = type.GetMethod("Invoke") ?? throw new InvalidOperationException("Invoke not found.");
        return method.Invoke(instance, [Array.Empty<CallArgumentValue>(), span, context])
            ?? throw new InvalidOperationException("Invoke returned null.");
    }

    [Fact]
    public void ExposedListMethodsAreFresh()
    {
        var context = NewContext();
        var site = SiteFor("append");
        var target = new PyList();
        Assert.NotSame(Resolve(target, site, context), Resolve(target, site, context));
    }

    [Fact]
    public void ExposedCounterMethodsAreFresh()
    {
        var context = NewContext();
        var site = SiteFor("most_common");
        var target = new PyCounter();
        Assert.NotSame(Resolve(target, site, context), Resolve(target, site, context));
    }

    [Fact]
    public void ExposedZipInfoMethodsAreFresh()
    {
        var context = NewContext();
        var span = new LythonSourceSpan(0, 0, 0, 0);
        var site = SiteFor("is_dir");
        var target = MakeZipInfo(context, span);
        Assert.NotSame(Resolve(target, site, context), Resolve(target, site, context));
    }

    [Fact]
    public void ImmediateCallsKeepTheReceiverCache()
    {
        var context = NewContext();
        var site = SiteFor("append");
        var target = new PyList();
        var first = Resolve(target, site, context, true);
        Assert.Same(first, Resolve(target, site, context, true));
        Assert.NotSame(first, Resolve(target, site, context));
    }

    [Fact]
    public void ExecutableMemberReadsAndImmediateCallsRemainDistinct()
    {
        var frontend = LythonFrontend.Compile("items=[]\nmethod=items.append\n(items.append)(1)\n",regexProvider:Utf8RegexProvider.Instance);
        var code = ExecutableScript.Compile(LoweredScript.Lower(frontend.Script.RequireNotNull()));
        var instructions = code.EntryPoint.Instructions.ToArray();
        Assert.Single(instructions, i => i.OpCode == ExecutableOpCode.LoadMember);
        Assert.Single(instructions, i => i.OpCode == ExecutableOpCode.LoadCallMember);
    }

    [Fact]
    public void NormalDistMeanAliases()
    {
        var context = NewContext();
        var site = SiteFor("mean");
        var target = new LythonRuntime.StatisticsModule.PyNormalDist(0.0, 1.0);
        Assert.Same(Resolve(target, site, context), Resolve(target, site, context));
    }

    [Fact]
    public void DequeMaxlenAliases()
    {
        var context = NewContext();
        var site = SiteFor("maxlen");
        var target = new PyDeque(5);
        Assert.Same(Resolve(target, site, context), Resolve(target, site, context));
    }

    [Fact]
    public void ModuleInfoFlagAliases()
    {
        var context = NewContext();
        var site = SiteFor("ispkg");
        var target = new PyNamedTupleType("ModuleInfo", ["module_finder", "name", "ispkg"]).CreateFromValues([PyNone.Instance, PyString.FromString("m"), false], null);
        Assert.Same(Resolve(target, site, context), Resolve(target, site, context));
    }

    [Fact]
    public void ZipInfoFilenameStaysCurrent()
    {
        var context = NewContext();
        var span = new LythonSourceSpan(0, 0, 0, 0);
        var site = SiteFor("filename");
        var target = MakeZipInfo(context, span);
        var first = Resolve(target, site, context);
        Assert.Equal("NoName", ((PyString)first).AsString());
        var setMember = target.GetType().GetMethod("SetMember") ?? throw new InvalidOperationException("SetMember not found.");
        setMember.Invoke(target, ["filename", PyString.FromString("b"), span]);
        var second = Resolve(target, site, context);
        Assert.Equal("b", ((PyString)second).AsString());
        Assert.NotSame(first, second);
    }

    [Fact]
    public void DistinctTargetsDoNotShare()
    {
        var context = NewContext();
        var span = new LythonSourceSpan(0, 0, 0, 0);
        var site = SiteFor("append");
        var first = new PyList();
        var second = new PyList();
        var firstAppend = (LythonRuntime.ICallable)Resolve(first, site, context);
        var secondAppend = (LythonRuntime.ICallable)Resolve(second, site, context);
        Assert.NotSame(firstAppend, secondAppend);
        secondAppend.Invoke([CallArgumentValue.Positional(7)], span, context);
        Assert.Empty(first);
        Assert.Single(second);
    }
}
