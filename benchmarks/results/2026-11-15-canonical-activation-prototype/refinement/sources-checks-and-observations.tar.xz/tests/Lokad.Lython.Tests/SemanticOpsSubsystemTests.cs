using System.Numerics;
using Lokad.Lython.Runtime;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Tests;

public sealed class SemanticOpsSubsystemTests
{
    [Fact]
    public void TruthinessEqualityComparisonAndContainment_AreOwnedByFocusedOps()
    {
        Assert.False(PyTruthiness.IsTruthy(PyNone.Instance));
        Assert.True(PyTruthiness.IsTruthy(new PyList([BigInteger.One])));

        Assert.True(PyEquality.AreEqual(BigInteger.One, true));
        Assert.True(PyEquality.AreEqual(PyString.FromString("x"), PyString.FromString("x")));
        Assert.False(PyEquality.AreEqual(PyString.FromString("x"), PyString.FromString("y")));
        Assert.False(PyStringOps.TryAsString("x", out _));

        var span = new LythonSourceSpan(0, 0, 0, 0);
        Assert.Equal(0, PyComparison.Compare(PyString.FromString("a"), PyString.FromString("a"), span));
        Assert.Throws<LythonRuntimeException>(() => PyComparison.Compare(PyString.FromString("a"), "a", span));
        Assert.True(PyContainment.Contains(new PyTuple([PyString.FromString("a"), BigInteger.One]), true, span));
    }

    [Fact]
    public void MemberResolution_ReturnsKnownMembersAndRejectsMissingOnes()
    {
        var text = PyString.FromString("abc");

        Assert.True(PyMemberAccess.TryResolve(text, "upper", out var upper));
        Assert.IsAssignableFrom<object>(upper);
        Assert.False(PyMemberAccess.TryResolve(text, "missing", out _));
    }
}
