using Lokad.Lython.Runtime;
using Lokad.Lython.Runtime.Text;
using Lokad.Lython.Tests.Harness;
using Context = Lokad.Lython.Runtime.LythonRuntime.ExecutionContext;

namespace Lokad.Lython.Tests;

[Collection("AllocationSensitive")]
public sealed class NativeHashCancellationTests
{
    private static readonly LythonSourceSpan Span = new(13, 4, 2, 6);

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ColdKeysUseTheirCurrentCallerWithoutAmbientState(bool binary)
    {
        var budget = new LythonMemoryBudget(1024 * 1024);
        using (var owner = budget.CreateScope())
        using (var cancellation = new CancellationTokenSource())
        {
            var context = new Context(new MockLythonHost(), new LythonRunOptions
                { MemoryBudget = owner, CancellationToken = cancellation.Token });
            object value = binary ? new PyBytes("native"u8.ToArray(), context.MemoryGovernor, Span)
                : PyString.FromString("native", context.MemoryGovernor, Span);
            var baseline = budget.ReservedBytes;
            Assert.Null(PyStructuralGuard.AmbientContext);
            cancellation.Cancel();
            var sync = Assert.Throws<LythonRuntimeException>(() => PyHashProtocols.GetProtocolHash(value, context, Span));
            var async = await Assert.ThrowsAsync<LythonRuntimeException>(async () =>
                await PyHashProtocols.GetProtocolHashAsync(value, context, Span));
            Assert.Equal(LythonFailureReason.Cancelled, sync.Attribution?.Reason);
            Assert.Equal(LythonFailureReason.Cancelled, async.Attribution?.Reason);
            Assert.Equal(Span, sync.Span);
            Assert.Equal(Span, async.Span);
            Assert.Equal(baseline, budget.ReservedBytes);
            Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
            Assert.Null(PyStructuralGuard.AmbientContext);
            context.State.CloseResources();
        }
        Assert.Equal(0, budget.ReservedBytes);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void CachedHashesDoNotRetainAnEarlierCallersToken(bool binary)
    {
        var budget = new LythonMemoryBudget(1024 * 1024);
        using (var owner = budget.CreateScope())
        using (var firstCancellation = new CancellationTokenSource())
        using (var secondCancellation = new CancellationTokenSource())
        {
            var first = new Context(new MockLythonHost(), new LythonRunOptions
                { MemoryBudget = owner, CancellationToken = firstCancellation.Token });
            var second = new Context(new MockLythonHost(), new LythonRunOptions
                { MemoryBudget = owner, CancellationToken = secondCancellation.Token });
            object value = binary ? new PyBytes("cached"u8.ToArray(), first.MemoryGovernor, Span)
                : PyString.FromString("cached", first.MemoryGovernor, Span);
            var baseline = budget.ReservedBytes;
            var expected = PyHashProtocols.GetProtocolHash(value, first, Span);
            firstCancellation.Cancel();
            Assert.Equal(expected, PyHashProtocols.GetProtocolHash(value, second, Span));
            secondCancellation.Cancel();
            var failure = Assert.Throws<LythonRuntimeException>(() => PyHashProtocols.GetProtocolHash(value, second, Span));
            Assert.Equal(LythonFailureReason.Cancelled, failure.Attribution?.Reason);
            Assert.Equal(baseline, budget.ReservedBytes);
            first.State.CloseResources();
            second.State.CloseResources();
        }
        Assert.Equal(0, budget.ReservedBytes);
    }

    [Fact]
    public void DirectNativeReadAndWriteObserveCancellationBeforeMutation()
    {
        var budget = new LythonMemoryBudget(1024 * 1024);
        using (var owner = budget.CreateScope())
        using (var cancellation = new CancellationTokenSource())
        {
            var context = new Context(new MockLythonHost(), new LythonRunOptions
                { MemoryBudget = owner, CancellationToken = cancellation.Token });
            var dictionary = new PyDict(context.MemoryGovernor, Span);
            var stored = PyString.FromString("key", context.MemoryGovernor, Span);
            dictionary.SetItem(stored, PyNone.Instance);
            var requested = PyString.FromString("key", context.MemoryGovernor, Span);
            var baseline = budget.ReservedBytes;
            cancellation.Cancel();
            var read = Assert.Throws<LythonRuntimeException>(() =>
                dictionary.TryReadNativeStringValue(requested, context, Span, out _));
            var write = Assert.Throws<LythonRuntimeException>(() =>
                dictionary.TryWriteKeyWithoutAdmission(requested, true, context, Span));
            Assert.Equal(LythonFailureReason.Cancelled, read.Attribution?.Reason);
            Assert.Equal(LythonFailureReason.Cancelled, write.Attribution?.Reason);
            Assert.Single(dictionary);
            Assert.True(dictionary.TryGetValue(stored, out var value));
            Assert.Same(PyNone.Instance, value);
            Assert.Equal(baseline, budget.ReservedBytes);
            Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
            context.State.CloseResources();
        }
        Assert.Equal(0, budget.ReservedBytes);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public void FirstRefusedAdmissionRetainsPriorityOverHashCancellation(bool binary)
    {
        var budget = new LythonMemoryBudget(1024 * 1024);
        using (var owner = budget.CreateScope())
        using (var cancellation = new CancellationTokenSource())
        {
            var context = new Context(new MockLythonHost(), new LythonRunOptions
                { MemoryBudget = owner, CancellationToken = cancellation.Token });
            object value = binary ? new PyBytes("key"u8.ToArray(), context.MemoryGovernor, Span)
                : PyString.FromString("key", context.MemoryGovernor, Span);
            var origin = new LythonSourceSpan(17, 8, 2, 5);
            var refusal = Assert.Throws<LythonRuntimeException>(() =>
                context.MemoryGovernor.Reserve(budget.LimitBytes!.Value + 1, origin));
            cancellation.Cancel();
            var failure = Assert.Throws<LythonRuntimeException>(() => PyHashProtocols.GetProtocolHash(value, context, Span));
            Assert.Same(refusal, failure);
            Assert.Equal(origin, failure.Span);
            Assert.Equal(LythonFailureReason.SharedMemoryAllowance, failure.Attribution?.Reason);
            Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
            context.State.CloseResources();
        }
        Assert.Equal(0, budget.ReservedBytes);
    }

    [Theory, Trait("Category", "Stress")]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ActiveNativeHashStopsBeforePublishingItsCache(bool binary)
    {
        // Keep the nonallocating scan longer than a normal scheduler quantum.
        // This stress case owns one buffer; ordinary checks stay small.
        const int length = 256 * 1024 * 1024;
        var budget = new LythonMemoryBudget(length + 32 * 1024 * 1024);
        using (var owner = budget.CreateScope())
        using (var cancellation = new CancellationTokenSource())
        {
            var context = new Context(new MockLythonHost(), new LythonRunOptions
                { MemoryBudget = owner, CancellationToken = cancellation.Token });
            var nextCaller = new Context(new MockLythonHost(), new LythonRunOptions { MemoryBudget = owner });
            var bytes = binary ? PyBytes.EstimateApproximateBytes(length) : PyString.EstimateApproximateBytes(length);
            using var storage = context.MemoryGovernor.ReserveTemporary(bytes, Span);
            var input = new byte[length];
            Array.Fill(input, (byte)'a');
            object value = binary ? new PyBytes(input, context.MemoryGovernor, Span, storage)
                : PyString.FromOwnedUtf8(input, context.MemoryGovernor, Span, storage);
            object small = binary ? new PyBytes("warm"u8.ToArray()) : PyString.FromString("warm");
            var warm = HashMember(small);
            _ = warm.Invoke([], Span, context);
            var callable = HashMember(value);
            var baseline = budget.ReservedBytes;
            using var started = new ManualResetEventSlim();
            using var cancellerReady = new ManualResetEventSlim();
            var canceller = Task.Factory.StartNew(() =>
            {
                cancellerReady.Set();
                Assert.True(started.Wait(TimeSpan.FromSeconds(10)));
                // Request directly from an owned thread. Timer-queue or pool
                // startup must not postpone cancellation past this scan.
                Thread.Sleep(1);
                cancellation.Cancel();
            }, CancellationToken.None, TaskCreationOptions.LongRunning, TaskScheduler.Default);
            var requestedAtCompletion = false;
            Task<object>? run = null;
            try
            {
                Assert.True(cancellerReady.Wait(TimeSpan.FromSeconds(10)));
                run = Task.Factory.StartNew(() =>
                {
                    started.Set();
                    try { return callable.Invoke([], Span, context); }
                    finally { requestedAtCompletion = cancellation.IsCancellationRequested; }
                }, CancellationToken.None, TaskCreationOptions.LongRunning, TaskScheduler.Default);
                var observed = await Record.ExceptionAsync(async () =>
                    await run.WaitAsync(TimeSpan.FromSeconds(10)));
                if (observed is null)
                    Assert.Fail($"Hash completed normally; cancellation requested before completion: {requestedAtCompletion}.");
                var failure = Assert.IsType<LythonRuntimeException>(observed);
                Assert.Equal(LythonFailureReason.Cancelled, failure.Attribution?.Reason);
                Assert.Equal(Span, failure.Span);
            }
            finally
            {
                cancellation.Cancel();
                started.Set();
                // Both owned workers end before the input or events retire,
                // including when an assertion or checkpoint fails.
                try { await canceller; }
                finally
                {
                    if (run is not null)
                    {
                        try { await run; }
                        catch (LythonRuntimeException failure) when (failure.Attribution?.Reason == LythonFailureReason.Cancelled) { }
                    }
                }
            }
            // A completed cache would bypass the scan even for this token. A
            // refusal here proves that cancellation did not finish/cache it.
            var retry = Assert.Throws<LythonRuntimeException>(() =>
            {
                _ = value is PyString text ? text.GetHashCode(cancellation.Token, Span)
                    : ((PyBytes)value).GetHashCode(cancellation.Token, Span);
            });
            Assert.Equal(LythonFailureReason.Cancelled, retry.Attribution?.Reason);
            var hash = callable.Invoke([], Span, nextCaller);
            Assert.Equal(hash, callable.Invoke([], Span, nextCaller));
            Assert.Equal(baseline, budget.ReservedBytes);
            Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
            Assert.Equal(0, context.State.CurrentInterpreterDepth);
            Assert.Equal(0, nextCaller.State.CurrentInterpreterDepth);
            Assert.Null(PyStructuralGuard.AmbientContext);
            Assert.Equal((byte)'a', input[0]);
            context.State.CloseResources();
            nextCaller.State.CloseResources();
        }
        Assert.Equal(0, budget.ReservedBytes);
    }

    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(15)]
    [InlineData(4095)]
    [InlineData(4096)]
    [InlineData(4097)]
    [InlineData(8195)]
    public void ChunkedNativeHashesPreserveWholeBufferValues(int length)
    {
        var input = new byte[length];
        for (var index = 0; index < input.Length; index++) input[index] = (byte)('a' + index % 26);
        var expected = new HashCode();
        expected.AddBytes(input);
        Assert.Equal(expected.ToHashCode(), new PyBytes(input).GetPyHashCode());
        Assert.Equal(expected.ToHashCode(), PyString.FromOwnedUtf8(input).GetPyHashCode());
    }

    private static LythonRuntime.ICallable HashMember(object value)
    {
        object? member;
        var found = value is PyBytes bytes
            ? LythonRuntime.BytesMembers.TryGetMember(bytes, "__hash__", out member)
            : LythonRuntime.StringMembers.TryGetMember((PyString)value, "__hash__", out member);
        Assert.True(found);
        return Assert.IsAssignableFrom<LythonRuntime.ICallable>(member);
    }
}
