using System.Reflection;
using Lokad.Lython.Runtime;
using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.Tests;

/// <summary>
/// MG17: constructed style values and comments commit object storage;
/// internal defaults built without a context stay free.
/// </summary>
public sealed class StyleValueAccountingTests
{
    private static object CreateFont(LythonRuntime.ExecutionContext? context, LythonSourceSpan? span)
    {
        var method = typeof(LythonRuntime).GetMethod("CreateFont", BindingFlags.Static | BindingFlags.NonPublic)
            ?? throw new InvalidOperationException("CreateFont not found.");
        return method.Invoke(null, [Array.Empty<object>(), span, context])
            ?? throw new InvalidOperationException("CreateFont returned null.");
    }

    [Fact]
    public void StyleValueCommitsExactly()
    {
        var host = new MockLythonHost();
        var context = new LythonRuntime.ExecutionContext(host, new LythonRunOptions(),regexProvider:Utf8RegexProvider.Instance);
        var span = new LythonSourceSpan(0, 0, 0, 0);
        _ = CreateFont(context, span);
        Assert.Equal(128L, context.MemoryGovernor.CurrentCommittedBytes);
        Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
    }

    [Fact]
    public void ContextFreeDefaultsStayFree()
    {
        var host = new MockLythonHost();
        var context = new LythonRuntime.ExecutionContext(host, new LythonRunOptions(),regexProvider:Utf8RegexProvider.Instance);
        _ = CreateFont(null, null);
        Assert.Equal(0, context.MemoryGovernor.CurrentCommittedBytes);
        Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
    }

    private static object CreateComment(LythonRuntime.ExecutionContext? context, LythonSourceSpan? span)
    {
        var method = typeof(LythonRuntime).GetMethod("CreateComment", BindingFlags.Static | BindingFlags.NonPublic)
            ?? throw new InvalidOperationException("CreateComment not found.");
        object?[] args = [Lokad.Lython.Runtime.Text.PyString.FromString("t"), Lokad.Lython.Runtime.Text.PyString.FromString("a")];
        return method.Invoke(null, [args, span, context])
            ?? throw new InvalidOperationException("CreateComment returned null.");
    }

    [Fact]
    public void CommentValueCommitsExactly()
    {
        var host = new MockLythonHost();
        var context = new LythonRuntime.ExecutionContext(host, new LythonRunOptions(),regexProvider:Utf8RegexProvider.Instance);
        var span = new LythonSourceSpan(0, 0, 0, 0);
        _ = CreateComment(context, span);
        Assert.Equal(128L, context.MemoryGovernor.CurrentCommittedBytes);
        Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
    }

    [Fact]
    public void ContextFreeCommentStaysFree()
    {
        var host = new MockLythonHost();
        var context = new LythonRuntime.ExecutionContext(host, new LythonRunOptions(),regexProvider:Utf8RegexProvider.Instance);
        _ = CreateComment(null, null);
        Assert.Equal(0, context.MemoryGovernor.CurrentCommittedBytes);
        Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
    }
}