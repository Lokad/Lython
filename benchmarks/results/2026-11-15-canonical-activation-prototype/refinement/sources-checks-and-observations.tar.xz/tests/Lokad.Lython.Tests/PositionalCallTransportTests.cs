using Slot = Lokad.Lython.Runtime.LythonRuntime.ExecutableSlot;
using System.Numerics;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime;
using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.Tests;

// Inspect the actual execution-owned backing through suspension and return.
// Separate executions cannot borrow one another's idle buffers.
public sealed class PositionalCallTransportTests
{
    private static readonly LythonSourceSpan Span = new(0, 0, 0, 0);
    [Theory]
    [InlineData(1, false, false)]
    [InlineData(2, false, false)]
    [InlineData(3, false, false)]
    [InlineData(1, true, false)]
    [InlineData(2, true, false)]
    [InlineData(3, true, false)]
    [InlineData(1, false, true)]
    [InlineData(2, false, true)]
    [InlineData(3, false, true)]
    [InlineData(1, true, true)]
    [InlineData(2, true, true)]
    [InlineData(3, true, true)]
    public async Task MatchingFrameUsesInvocationOwnedBoundStorage(int width, bool asynchronous, bool keywords)
    {
        var parameters = string.Join(",", Enumerable.Range(0, width).Select(i => "a" + i));
        var arguments = string.Join(",", Enumerable.Range(0, width).Select(i => keywords ? $"a{i}=value" : "value"));
        var frontend = LythonFrontend.Compile($"def f({parameters}):\n    a0=value\n    tap()\n    return a0\nreturn f({arguments})\n",regexProvider:Utf8RegexProvider.Instance);
        var script = ExecutableScript.Compile(LoweredScript.Lower(frontend.Script.RequireNotNull()));
        var context = new LythonRuntime.ExecutionContext(new MockLythonHost(), new LythonRunOptions(),regexProvider:Utf8RegexProvider.Instance);
        var marker = new object();
        var tap = new StorageTap(marker, width);
        context.Variables["value"] = marker;
        context.Variables["tap"] = tap;
        var result = asynchronous
            ? await LythonRuntime.ExecuteExecutableCodeObjectAsync(script.EntryPoint, context)
            : LythonRuntime.ExecuteExecutableCodeObject(script.EntryPoint, context, default, null);
        Assert.Same(marker, result);
        Assert.True(tap.Invoked);
        Assert.All(tap.Storage!, item => Assert.Null(item.Reference));
        Assert.Null(tap.Frame!.CurrentExecutableFrame);
        Assert.Null(context.CurrentExecutableFrame);
        Assert.Equal(0, context.State.CurrentInterpreterDepth);
        Assert.Equal(0, context.State.CurrentRecursionDepth);
        Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
    }

    private static Slot[] FrameStorage(LythonRuntime.ExecutionContext context)
    {
        var frame = Assert.IsAssignableFrom<LythonRuntime.ExecutionContext>(context.CurrentExecutableFrame);
        var values = frame._execution.Locals;
        var stack = frame._execution.Stack;
        Assert.Same(values, stack.Values);
        return values;
    }

    private sealed class StorageTap(object marker, int width) : LythonRuntime.ICallable
    {
        internal bool Invoked;
        internal LythonRuntime.ExecutionContext? Frame;
        internal Slot[]? Storage;
        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, LythonRuntime.ExecutionContext context)
        {
            Invoked = true;
            Frame = context;
            Storage = FrameStorage(context);
            for (var i = 0; i < width; i++) Assert.Same(marker, Storage[i].Object);
            return PyNone.Instance;
        }
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task BorrowedLocalsRemainOwnedUntilSuspendedInvocationFinishes(bool cancel)
    {
        var frontend = LythonFrontend.Compile("def f(value):\n    tap()\n    return value\nreturn f(value)\n",regexProvider:Utf8RegexProvider.Instance);
        var script = ExecutableScript.Compile(LoweredScript.Lower(frontend.Script.RequireNotNull()));
        var context = new LythonRuntime.ExecutionContext(new MockLythonHost(), new LythonRunOptions(),regexProvider:Utf8RegexProvider.Instance);
        var marker = new object();
        var tap = new SuspendedStorageTap(marker);
        context.Variables["value"] = marker;
        context.Variables["tap"] = tap;
        var pending = LythonRuntime.ExecuteExecutableCodeObjectAsync(script.EntryPoint, context).AsTask();
        try
        {
            Assert.NotNull(tap.Frame);
            Assert.False(pending.IsCompleted);
            Assert.Same(marker, tap.Storage![0].Object);
            Assert.NotNull(tap.Frame.CurrentExecutableFrame);
            if (cancel)
            {
                tap.Release.TrySetCanceled();
                await Assert.ThrowsAnyAsync<OperationCanceledException>(() => pending);
            }
            else
            {
                tap.Release.TrySetResult();
                Assert.Same(marker, await pending.WaitAsync(TimeSpan.FromSeconds(5)));
            }
        }
        finally
        {
            tap.Release.TrySetCanceled();
            try { await pending.WaitAsync(TimeSpan.FromSeconds(5)); }
            catch (OperationCanceledException) { }
        }
        Assert.All(tap.Storage!, item => Assert.Null(item.Reference));
        Assert.Null(tap.Frame!.CurrentExecutableFrame);
        Assert.Null(context.CurrentExecutableFrame);
        Assert.Equal(0, context.State.CurrentInterpreterDepth);
        Assert.Equal(0, context.State.CurrentRecursionDepth);
        Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
    }

    private sealed class SuspendedStorageTap(object marker) : LythonRuntime.ICallable
    {
        internal LythonRuntime.ExecutionContext? Frame;
        internal Slot[]? Storage;
        internal TaskCompletionSource Release { get; } = new(TaskCreationOptions.RunContinuationsAsynchronously);
        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, LythonRuntime.ExecutionContext context)
            => throw new InvalidOperationException("Expected async call.");
        public async ValueTask<object> InvokeAsync(CallArgumentValue[] arguments, LythonSourceSpan span, LythonRuntime.ExecutionContext context)
        {
            Frame = context;
            Storage = FrameStorage(context);
            Assert.Same(marker, Storage[0].Object);
            await Release.Task.ConfigureAwait(false);
            return PyNone.Instance;
        }
    }

    [Theory]
    [InlineData(1, false)]
    [InlineData(2, false)]
    [InlineData(3, false)]
    [InlineData(1, true)]
    [InlineData(2, true)]
    [InlineData(3, true)]
    public async Task CompiledPositionalCallsPreserveArgumentsAndCleanup(int width, bool asynchronous)
    {
        var parameters = string.Join(",", Enumerable.Range(0, width).Select(i => "a" + i));
        var arguments = string.Join(",", Enumerable.Repeat("value", width));
        var frontend = LythonFrontend.Compile($"def f({parameters}):\n    return a0\nreturn f({arguments})\n",regexProvider:Utf8RegexProvider.Instance);
        var script = ExecutableScript.Compile(LoweredScript.Lower(frontend.Script.RequireNotNull()));
        var context = new LythonRuntime.ExecutionContext(new MockLythonHost(), new LythonRunOptions(),regexProvider:Utf8RegexProvider.Instance);
        var marker = new object();
        context.Variables["value"] = marker;
        object? result;
        if (asynchronous)
        {
            var pending = LythonRuntime.ExecuteExecutableCodeObjectAsync(script.EntryPoint, context);
            Assert.True(pending.IsCompleted);
            result = await pending;
        }
        else result = LythonRuntime.ExecuteExecutableCodeObject(script.EntryPoint, context, default, null);
        Assert.Same(marker, result);
        Assert.Null(context.CurrentExecutableFrame);
        Assert.Equal(0, context.State.CurrentInterpreterDepth);
        Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
    }

    [Theory]
    [InlineData(1, false, false)]
    [InlineData(2, false, false)]
    [InlineData(3, false, false)]
    [InlineData(1, true, false)]
    [InlineData(2, true, false)]
    [InlineData(3, true, false)]
    [InlineData(1, false, true)]
    [InlineData(1, true, true)]
    public async Task ClassDefinedMethodsPreserveArgumentsAndCleanup(int width, bool asynchronous, bool keywords)
    {
        var parameters = string.Join(",", Enumerable.Range(0, width).Select(i => "a" + i));
        var definition = LythonFrontend.Compile($"class Box:\n def method(self,{parameters}):return a0\nbox=Box()\nmethod=box.method",regexProvider:Utf8RegexProvider.Instance);
        var code = ExecutableScript.Compile(LoweredScript.Lower(definition.Script.RequireNotNull())).EntryPoint;
        var budget = new LythonMemoryBudget(4 * 1024 * 1024);
        using var owner = budget.CreateScope();
        var context = new LythonRuntime.ExecutionContext(new MockLythonHost(), new LythonRunOptions { MemoryBudget = owner },regexProvider:Utf8RegexProvider.Instance);
        _ = asynchronous ? await LythonRuntime.ExecuteExecutableCodeObjectAsync(code, context)
            : LythonRuntime.ExecuteExecutableCodeObject(code, context, default, null);
        var method = Assert.IsType<PyBoundMethod>(context.Variables["method"]);
        Assert.IsType<PyExecutableFunction>(method.Function);
        var marker = new object();
        context.Variables["value"] = marker;
        var arguments = string.Join(",", Enumerable.Range(0, width).Select(i => keywords ? $"a{i}=value" : "value"));
        var call = LythonFrontend.Compile("return method(" + arguments + ")",regexProvider:Utf8RegexProvider.Instance);
        code = ExecutableScript.Compile(LoweredScript.Lower(call.Script.RequireNotNull())).EntryPoint;
        var result = asynchronous ? await LythonRuntime.ExecuteExecutableCodeObjectAsync(code, context)
            : LythonRuntime.ExecuteExecutableCodeObject(code, context, default, null);
        Assert.Same(marker, result);
        Assert.Same(method, context.Variables["method"]);
        Assert.Null(context.CurrentExecutableFrame);
        Assert.Equal(0, context.State.CurrentInterpreterDepth);
        Assert.Equal(0, context.State.CurrentRecursionDepth);
        Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
        owner.Dispose();
        Assert.Equal(0, budget.ReservedBytes);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ClassDefinedMethodInputsRemainOwnedUntilItsNativeHookFinishes(bool cancel)
    {
        var definition = LythonFrontend.Compile("class Box:\n def method(self,value):\n  tap()\n  return value\nbox=Box()\nmethod=box.method",regexProvider:Utf8RegexProvider.Instance);
        var code = ExecutableScript.Compile(LoweredScript.Lower(definition.Script.RequireNotNull())).EntryPoint;
        var budget = new LythonMemoryBudget(4 * 1024 * 1024);
        using var owner = budget.CreateScope();
        var context = new LythonRuntime.ExecutionContext(new MockLythonHost(), new LythonRunOptions { MemoryBudget = owner },regexProvider:Utf8RegexProvider.Instance);
        await LythonRuntime.ExecuteExecutableCodeObjectAsync(code, context);
        var marker = Runtime.Text.PyString.FromString("owned", context.MemoryGovernor, null);
        var tap = new SuspendedMethodTap(context.Variables["box"], marker);
        context.Variables["value"] = marker;
        context.Variables["tap"] = tap;
        var baseline = budget.ReservedBytes;
        var call = LythonFrontend.Compile("return method(value)",regexProvider:Utf8RegexProvider.Instance);
        code = ExecutableScript.Compile(LoweredScript.Lower(call.Script.RequireNotNull())).EntryPoint;
        var pending = LythonRuntime.ExecuteExecutableCodeObjectAsync(code, context).AsTask();
        try
        {
            await tap.Started.Task.WaitAsync(TimeSpan.FromSeconds(5));
            Assert.False(pending.IsCompleted);
            Assert.NotNull(tap.Frame);
            Assert.NotNull(tap.Frame.CurrentExecutableFrame);
            var storage = tap.Storage!;
            Assert.Same(context.Variables["box"], storage[0].Object);
            Assert.Same(marker, storage[1].Object);
            Assert.Same(storage[0].Object, LythonRuntime.ResolveName("self", Span, tap.Frame));
            Assert.Same(marker, LythonRuntime.ResolveName("value", Span, tap.Frame));
            Assert.True(budget.ReservedBytes >= baseline);
            if (cancel)
            {
                tap.Release.TrySetCanceled();
                await Assert.ThrowsAnyAsync<OperationCanceledException>(() => pending);
            }
            else
            {
                tap.Release.TrySetResult();
                Assert.Same(marker, await pending.WaitAsync(TimeSpan.FromSeconds(5)));
            }
        }
        finally
        {
            tap.Release.TrySetCanceled();
            try { await pending.WaitAsync(TimeSpan.FromSeconds(5)); }
            catch (OperationCanceledException) { }
        }
        Assert.All(tap.Storage!, item => Assert.Null(item.Reference));
        Assert.Null(context.CurrentExecutableFrame);
        Assert.Equal(0, context.State.CurrentInterpreterDepth);
        Assert.Equal(0, context.State.CurrentRecursionDepth);
        Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
        Assert.True(budget.ReservedBytes >= baseline);
        owner.Dispose();
        Assert.Equal(0, budget.ReservedBytes);
    }

    private sealed class SuspendedMethodTap(object receiver, object value) : LythonRuntime.ICallable
    {
        internal LythonRuntime.ExecutionContext? Frame;
        internal Slot[]? Storage;
        internal TaskCompletionSource Started { get; } = new(TaskCreationOptions.RunContinuationsAsynchronously);
        internal TaskCompletionSource Release { get; } = new(TaskCreationOptions.RunContinuationsAsynchronously);
        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, LythonRuntime.ExecutionContext context)
            => throw new InvalidOperationException("Expected an asynchronous native call.");
        public async ValueTask<object> InvokeAsync(CallArgumentValue[] arguments, LythonSourceSpan span, LythonRuntime.ExecutionContext context)
        {
            Frame = context;
            Storage = context.CurrentExecutableFrame!._execution.Locals;
            Assert.Same(receiver, Storage[0].Object);
            Assert.Same(value, Storage[1].Object);
            Assert.Same(receiver, LythonRuntime.ResolveName("self", span, context));
            Assert.Same(value, LythonRuntime.ResolveName("value", span, context));
            Started.TrySetResult();
            await Release.Task.ConfigureAwait(false);
            return PyNone.Instance;
        }
    }


    [Theory]
    [InlineData(false, false)]
    [InlineData(true, false)]
    [InlineData(false, true)]
    [InlineData(true, true)]
    public async Task RealMethodCallSitesKeepEveryGuardAndBodyEffect(bool asynchronous, bool defaulted)
    {
        const string definitionSource = "class Box:\n def method(self,value=7):\n  stamp(self,value)\n  return value\nbox=Box()\nmethod=box.method";
        var definition = ExecutableScript.Compile(LoweredScript.Lower(LythonFrontend.Compile(definitionSource,regexProvider:Utf8RegexProvider.Instance).Script!)).EntryPoint;
        var callSource = defaulted ? "return method()" : "return method(value)";
        var call = ExecutableScript.Compile(LoweredScript.Lower(LythonFrontend.Compile(callSource,regexProvider:Utf8RegexProvider.Instance).Script!)).EntryPoint;
        var budget = new LythonMemoryBudget(4 * 1024 * 1024);
        var marker = new object();
        string[] fullEffects;
        using (var owner = budget.CreateScope())
        {
            var (context, tape) = await Prepare(owner);
            var result = await Execute(call, context);
            if (defaulted) Assert.Equal(new BigInteger(7), result);
            else Assert.Same(marker, result);
            fullEffects = tape.Events.ToArray();
            Assert.Single(fullEffects);
            Unwound(context);
        }
        Assert.Equal(0, budget.ReservedBytes);
        Assert.Equal(["body"], fullEffects);

        async ValueTask<(LythonRuntime.ExecutionContext, MethodEffects)> Prepare(ILythonMemoryBudget owner)
        {
            var context = new LythonRuntime.ExecutionContext(new MockLythonHost(), new LythonRunOptions
            { MemoryBudget = owner},regexProvider:Utf8RegexProvider.Instance);
            var tape = new MethodEffects(defaulted ? new BigInteger(7) : marker);
            context.Variables["value"] = marker;
            context.Variables["stamp"] = tape;
            await Execute(definition, context);
            Assert.IsType<PyExecutableFunction>(Assert.IsType<PyBoundMethod>(context.Variables["method"]).Function);
            tape.Receiver = context.Variables["box"];
            return (context, tape);
        }

        async ValueTask<object?> Execute(ExecutableCodeObject code, LythonRuntime.ExecutionContext context)
            => asynchronous ? await LythonRuntime.ExecuteExecutableCodeObjectAsync(code, context)
                : LythonRuntime.ExecuteExecutableCodeObject(code, context, default, null);

        static void Unwound(LythonRuntime.ExecutionContext context)
        {
            Assert.Null(context.CurrentExecutableFrame);
            Assert.Equal(0, context.State.CurrentInterpreterDepth);
            Assert.Equal(0, context.State.CurrentRecursionDepth);
            Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
        }
    }

    private sealed class MethodEffects(object expected) : LythonRuntime.ICallable
    {
        internal object? Receiver;
        internal List<string> Events { get; } = [];
        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, LythonRuntime.ExecutionContext context)
        {
            Assert.Equal(2, arguments.Length);
            Assert.Same(Receiver, arguments[0].Value);
            Assert.Equal(expected, arguments[1].Value);
            Assert.NotNull(context.CurrentExecutableFrame);
            Assert.True(context.State.CurrentInterpreterDepth > 0);
            Assert.Equal(1, context.State.CurrentRecursionDepth);
            Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
            Events.Add("body");
            return PyNone.Instance;
        }
    }

}
