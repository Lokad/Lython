using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime;
using Lokad.Lython.Runtime.Text;
using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.Tests;

public sealed class OwnedTupleReturnTests
{
    private static readonly LythonSourceSpan Span = new(0, 1, 1, 1);

    [Theory]
    [InlineData(false, 0)]
    [InlineData(false, 1)]
    [InlineData(false, 2)]
    [InlineData(true, 0)]
    [InlineData(true, 1)]
    [InlineData(true, 2)]
    public void TupleAssignmentPreservesAliasesAndRejectsBeforeTargetsChange(bool wide, int failure)
    {
        var budget = new LythonMemoryBudget(1024 * 1024);
        using (var owner = budget.CreateScope())
        using (var cancellation = new CancellationTokenSource())
        {
            var gate = new AdmissionHookMemoryBudget(owner);
            var context = new LythonRuntime.ExecutionContext(new MockLythonHost(),
                new() { MemoryBudget = gate, CancellationToken = cancellation.Token });
            var armed = false;
            context.Variables["arm"] = new Arm(() =>
            {
                armed = true;
                if (failure == 1) gate.AfterGrowth = _ => cancellation.Cancel();
                if (failure == 2) gate.RefuseGrowth = _ => true;
            });
            try
            {
                var locals = wide ? " a0=a1=a2=a3=a4=a5=a6=a7=left\n b0=b1=b2=b3=b4=b5=b6=b7=right\n" : "";
                LythonRuntime.ExecuteExecutableCodeObject(Compile("def pair(left,right):\n arm()\n" + locals + " return left,right"), context);
                var left = PyString.FromString(new string('x', 8192), context.MemoryGovernor, Span);
                var right = new PyList(0, context.MemoryGovernor, Span);
                var first = new object();
                var second = new object();
                context.Variables["left"] = left;
                context.Variables["right"] = right;
                context.Variables["a"] = first;
                context.Variables["b"] = second;
                var assignment = Compile("global a,b\na,b=pair(left,right)");
                if (failure != 0)
                {
                    var error = Assert.Throws<LythonRuntimeException>(() =>
                        LythonRuntime.ExecuteExecutableCodeObject(assignment, context));
                    Assert.True(armed);
                    Assert.Equal(failure == 1 ? LythonFailureReason.Cancelled : LythonFailureReason.SharedMemoryAllowance,
                        error.Attribution?.Reason);
                    if (failure == 2) Assert.Same(context.MemoryGovernor.AdmissionFailure, error);
                    Assert.Same(first, context.Variables["a"]);
                    Assert.Same(second, context.Variables["b"]);
                }
                else
                {
                    LythonRuntime.ExecuteExecutableCodeObject(assignment, context);
                    Assert.True(armed);
                    Assert.Same(left, context.Variables["a"]);
                    Assert.Same(right, context.Variables["b"]);
                }
                Assert.Equal(new string('x', 8192), left.AsString());
                Assert.Empty(right);
                Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
                Assert.Equal(0, context.State.CurrentInterpreterDepth);
                Assert.Equal(0, context.State.CurrentRecursionDepth);
                Assert.Null(context.CurrentExecutableFrame);
            }
            finally
            {
                gate.AfterGrowth = null;
                gate.RefuseGrowth = null;
                context.State.CloseResources();
            }
        }
        Assert.Equal(0, budget.ReservedBytes);
    }

    private sealed class Arm(Action action) : LythonRuntime.ICallable
    {
        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, LythonRuntime.ExecutionContext context)
        { action(); return PyNone.Instance; }
    }

    private static ExecutableCodeObject Compile(string source)
    {
        var frontend = LythonFrontend.Compile(source);
        Assert.DoesNotContain(frontend.Diagnostics, d => d.Severity == LythonDiagnosticSeverity.Error);
        return ExecutableScript.Compile(LoweredScript.Lower(frontend.Script!)).EntryPoint;
    }
}
