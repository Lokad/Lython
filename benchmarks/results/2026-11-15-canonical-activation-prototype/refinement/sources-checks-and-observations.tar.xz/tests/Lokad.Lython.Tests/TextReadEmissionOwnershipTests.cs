using Lokad.Lython.Runtime;
using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.Tests;

[Collection("AllocationSensitive")]
public sealed class TextReadEmissionOwnershipTests
{
    [Theory]
    [InlineData(false, -1)]
    [InlineData(true, -1)]
    [InlineData(false, 2)]
    [InlineData(true, 2)]
    [InlineData(false, 4)]
    [InlineData(true, 4)]


    public async Task DeniedEmissionStorageReturnsUnpublishedStorage(
        bool asynchronous, int readSize)
    {
        const long cap = 65536;
        var host = new MockLythonHost();
        host.SeedFile("/data.txt", "!abc\nxyz\n");
        var budget = new LythonMemoryBudget(cap);
        var context = new LythonRuntime.ExecutionContext(host,
            new LythonRunOptions { MemoryBudget = budget },regexProvider:Utf8RegexProvider.Instance);
        var file = new OpenedByteFile(context.State);
        await file.OpenAsync("/data.txt", new LythonFileOpenOptions(LythonFileAccess.Read), null, asynchronous);
        using var state = new LythonRuntime.ExecutionContext.ChunkedTextFileReadState(
            file, context, LythonRuntime.TextEncodingMode.Utf8,
            LythonRuntime.TextErrorMode.Strict,
            LythonRuntime.TextNewlineMode.TranslateUniversal, windowBytes: 5);
        var prefix = asynchronous ? await state.ReadAsync(1) : state.Read(1);
        Assert.Equal("!", prefix.AsString());
        context.MemoryGovernor.RefundUnpublishedValue(prefix);

        var governor = context.MemoryGovernor;
        var committed = governor.CurrentCommittedBytes;
        var reserved = governor.CurrentReservedBytes;
        // Keep the reader/current window owned. Allow only working capacity,
        // then deny the new returned value whether it copies bytes or borrows
        // admitted immutable storage. Exact-window reads need builder scratch.
        var builderScratch = readSize == 4 ? 8 : 0;
        var pressure = cap - budget.ReservedBytes - builderScratch;
        Assert.True(pressure > 0);
        governor.Reserve(pressure, null);

        LythonRuntimeException error;
        if (asynchronous)
            error = await Assert.ThrowsAsync<LythonRuntimeException>(async () =>
            {
                if (readSize < 0) await state.ReadLineAsync(-1);
                else await state.ReadAsync(readSize);
            });
        else
            error = Assert.Throws<LythonRuntimeException>(() =>
            {
                if (readSize < 0) state.ReadLine(-1);
                else state.Read(readSize);
            });

        Assert.Equal("MemoryError", error.ExceptionType);
        Assert.True(governor.LastDeniedReservationBytes >= 128);
        Assert.Equal(reserved + pressure, governor.CurrentReservedBytes);
        Assert.Equal(committed, governor.CurrentCommittedBytes);
        governor.ReleaseReserved(pressure);
        var denied = asynchronous
            ? await Assert.ThrowsAsync<LythonRuntimeException>(async () => await state.ReadLineAsync(-1))
            : Assert.Throws<LythonRuntimeException>(() => state.ReadLine(-1));
        Assert.Same(error, denied);
        Assert.Equal(0, governor.CurrentReservedBytes);
        GC.KeepAlive(state);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task RetainedLineStaysChargedAfterReaderCloses(bool asynchronous)
    {
        var host = new MockLythonHost();
        host.SeedFile("/data.txt", "abc\nxyz\n");
        var context = new LythonRuntime.ExecutionContext(host, null,regexProvider:Utf8RegexProvider.Instance);
        var file = new OpenedByteFile(context.State);
        await file.OpenAsync("/data.txt", new LythonFileOpenOptions(LythonFileAccess.Read), null, asynchronous);
        using var state = new LythonRuntime.ExecutionContext.ChunkedTextFileReadState(
            file, context, LythonRuntime.TextEncodingMode.Utf8,
            LythonRuntime.TextErrorMode.Strict,
            LythonRuntime.TextNewlineMode.TranslateUniversal, windowBytes: 4);
        var line = asynchronous ? await state.ReadLineAsync(-1) : state.ReadLine(-1);
        var pool = context.State.MemoryGovernor;
        state.Release();
        var committed = context.MemoryGovernor.CurrentCommittedBytes;
        GC.Collect();
        GC.WaitForPendingFinalizers();
        GC.Collect();
        Assert.Equal(committed, context.MemoryGovernor.CurrentCommittedBytes);
        Assert.Equal("abc\n", line.AsString());
        GC.KeepAlive(line);
        GC.KeepAlive(state);
    }
}
