using System.Runtime.CompilerServices;
using Lokad.Lython.Runtime;
using Lokad.Lython.Runtime.Text;
using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.Tests;

[Collection("AllocationSensitive")]
public sealed class PathByteAccountingTests
{
    private static readonly LythonSourceSpan Span = new(0, 0, 0, 0);

    [Theory]
    [InlineData(200)]
    public void DeniedReadsRefundAcquisitionAndFreshResult(long cap)
    {
        var host = new MockLythonHost();
        host.SeedBytes("/blob", new byte[123]);
        var context = new LythonRuntime.ExecutionContext(host, new LythonRunOptions { MemoryBudget = new LythonMemoryBudget(cap) },regexProvider:Utf8RegexProvider.Instance);
        var method = Method("read_bytes");
        for (var i = 0; i < 50; i++)
        {
            var failure = Assert.Throws<LythonRuntimeException>(() => method.Invoke([], Span, context));
            Assert.Equal("MemoryError", failure.ExceptionType);
            Assert.Equal(0, context.MemoryGovernor.CurrentCommittedBytes);
            Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
        }
    }

    [Fact]
    public void ReadBatchesReturnTheirOwnedCopiesAfterCleanup()
    {
        var host = new MockLythonHost();
        host.SeedBytes("/blob", new byte[1024]);
        var budget = new LythonMemoryBudget(16 * 1024);
        for (var batch = 0; batch < 8; batch++)
        {
            using (var owner = budget.CreateScope())
            {
                var context = new LythonRuntime.ExecutionContext(host,
                    new LythonRunOptions { MemoryBudget = owner },regexProvider:Utf8RegexProvider.Instance);
                Consume(context);
                Assert.True(budget.ReservedBytes >= 1024);
                Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
            }
            Assert.Equal(0, budget.ReservedBytes);
        }
    }

    [Fact]
    public void FailedWritesReleaseAcquisitionAndKeepCallerInputFunded()
    {
        var host = new MockLythonHost();
        var context = new LythonRuntime.ExecutionContext(host, new LythonRunOptions { MemoryBudget = new LythonMemoryBudget(4096) },regexProvider:Utf8RegexProvider.Instance);
        var input = new PyBytes(new byte[1024], context.MemoryGovernor, Span);
        var before = context.MemoryGovernor.CurrentCommittedBytes;
        var method = Method("write_bytes");
        for (var i = 0; i < 50; i++)
        {
            host.FailNextFileWrite("/blob", "denied");
            var failure = Assert.Throws<HostOperationException>(() => method.Invoke([CallArgumentValue.Positional(input)], Span, context));
            Assert.Equal("OSError", failure.ExceptionType);
            Assert.Equal("denied", failure.Message);
            Assert.Equal(before, context.MemoryGovernor.CurrentCommittedBytes);
            Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
            Assert.Equal(1024, input.Length);
        }
        GC.KeepAlive(input);
    }

    [MethodImpl(MethodImplOptions.NoInlining)]
    private static void Consume(LythonRuntime.ExecutionContext context)
    {
        var value = Assert.IsType<PyBytes>(Method("read_bytes").Invoke([], Span, context));
        Assert.Equal(1024, value.Length);
        GC.KeepAlive(value);
    }

    private static LythonRuntime.ICallable Method(string name)
    {
        Assert.True(LythonRuntime.PathMembers.TryGetMember(new PyPath(PyString.FromString("/blob")), name, out var method));
        return Assert.IsAssignableFrom<LythonRuntime.ICallable>(method);
    }

}
