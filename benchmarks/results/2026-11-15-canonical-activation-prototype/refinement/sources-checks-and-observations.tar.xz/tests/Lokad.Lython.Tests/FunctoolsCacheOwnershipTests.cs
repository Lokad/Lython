using System.Numerics;
using System.Reflection;
using Lokad.Lython.Runtime;
using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.Tests;

// N08 white-box: explicit key/infra/metadata ownership with exact release on
// eviction, clear, insertion denial and wrapper drops.
[Collection("AllocationSensitive")]
public sealed class FunctoolsCacheOwnershipInvariantTests
{
    private static object NewWrapper(LythonRuntime.ExecutionContext context, int? maxSize)
    {
        var wrapperType = typeof(LythonRuntime).GetNestedType("PyLruCacheWrapper", BindingFlags.NonPublic)
            ?? throw new InvalidOperationException("PyLruCacheWrapper not found.");
        var keyModeType = typeof(LythonRuntime).GetNestedType("CacheKeyMode", BindingFlags.NonPublic)
            ?? throw new InvalidOperationException("CacheKeyMode not found.");
        var ctor = wrapperType.GetConstructors().Single();
        return ctor.Invoke([null, maxSize, Enum.ToObject(keyModeType, 0), context.State]);
    }

    private static LythonRuntime.ExecutionContext NewContext()
        => new(new MockLythonHost(), new LythonRunOptions(),regexProvider:Utf8RegexProvider.Instance);

    private static LythonSourceSpan Span() => new(0, 0, 0, 0);

    private static PyTuple NewKey(LythonRuntime.ExecutionContext context, LythonSourceSpan span, int value)
    {
        var key = new PyTuple([(object)new BigInteger(value)], context.MemoryGovernor, span);
        return key;
    }

    private static void InvokeStore(object wrapper, object key, long keyCharge, object value, LythonSourceSpan span, LythonRuntime.ExecutionContext context)
    {
        var method = wrapper.GetType().GetMethod("Store", BindingFlags.NonPublic | BindingFlags.Instance)
            ?? throw new InvalidOperationException("Store not found.");
        method.Invoke(wrapper, [key, keyCharge, value, span, context, PyHashProtocols.GetProtocolHash(key, context, span)]);
    }

    [Fact]
    public void EvictionReleasesEvictedKeyGraphs()
    {
        var context = NewContext();
        var span = Span();
        var wrapper = NewWrapper(context, 1);
        var baseline = context.MemoryGovernor.CurrentCommittedBytes;
        var k1 = NewKey(context, span, 1);
        var c1 = k1.CommittedStorageBytes;
        InvokeStore(wrapper, k1, c1, new BigInteger(1), span, context);
        var retained = context.MemoryGovernor.CurrentCommittedBytes - baseline;
        Assert.True(retained > c1);
        var k2 = NewKey(context, span, 2);
        var c2 = k2.CommittedStorageBytes;
        InvokeStore(wrapper, k2, c2, new BigInteger(2), span, context);
        Assert.Equal(retained - c1 + c2, context.MemoryGovernor.CurrentCommittedBytes - baseline); // evicted key released
    }

    [Fact]
    public void InsertionDenialReleasesFreshKey()
    {
        var host = new MockLythonHost();
        var context = new LythonRuntime.ExecutionContext(host, new LythonRunOptions { MemoryBudget = new LythonMemoryBudget(128) },regexProvider:Utf8RegexProvider.Instance);
        var span = Span();
        var wrapper = NewWrapper(context, 1);
        var baseline = context.MemoryGovernor.CurrentCommittedBytes;
        var key = new PyTuple([(object)new BigInteger(1)], context.MemoryGovernor, span);
        var keyCharge = key.CommittedStorageBytes;
        var store = wrapper.GetType().GetMethod("Store", BindingFlags.NonPublic | BindingFlags.Instance)
            ?? throw new InvalidOperationException("Store not found.");
        // Entry infrastructure cannot fit beside the fresh key: denial refunds it.
        var failure = Assert.Throws<TargetInvocationException>(() => store.Invoke(wrapper, [key, keyCharge, new BigInteger(1), span, context, PyHashProtocols.GetProtocolHash(key, context, span)]));
        Assert.IsType<LythonRuntimeException>(failure.InnerException);
        Assert.Equal("MemoryError", ((LythonRuntimeException)failure.InnerException!).ExceptionType);
        Assert.Equal(baseline, context.MemoryGovernor.CurrentCommittedBytes);
    }

    [Fact]
    public void DroppedWrapperRemainsBatchFundedUntilExplicitOwnerCleanup()
    {
        var budget = new LythonMemoryBudget(512 * 1024);
        using var owner = budget.CreateScope();
        var context = new LythonRuntime.ExecutionContext(new MockLythonHost(), new LythonRunOptions { MemoryBudget = owner },regexProvider:Utf8RegexProvider.Instance);
        var weak = AbandonPopulatedWrapper(context);
        var retained = budget.ReservedBytes;
        Assert.True(retained > 0);
        GC.Collect();
        GC.WaitForPendingFinalizers();
        GC.Collect();
        Assert.False(weak.IsAlive);
        Assert.Equal(retained, budget.ReservedBytes);
        context = null!;
        owner.Dispose();
        Assert.Equal(0, budget.ReservedBytes);
    }

    [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
    private static WeakReference AbandonPopulatedWrapper(LythonRuntime.ExecutionContext context)
    {
        var span = Span();
        var wrapper = NewWrapper(context, null);
        var key = NewKey(context, span, 1);
        InvokeStore(wrapper, key, key.CommittedStorageBytes, new BigInteger(1), span, context);
        return new WeakReference(wrapper);
    }
}
