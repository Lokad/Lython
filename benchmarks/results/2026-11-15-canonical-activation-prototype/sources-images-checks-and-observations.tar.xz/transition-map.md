# Canonical activation — prospective design, not an implementation

Source baseline: committed 6e276759. R402's native-only stack was not selected:
manually rebuilding unwind/continuation chains beside the ordinary runner would
add a controller. R378 and all three R382 variants remain adverse evidence. No
claim that merely moving state or sharing a switch makes this faster.

The proposed invariant is one mutable activation, owning final argument/local/
operand storage and the ordinary call-completion state, independently of whether
a lexical ExecutionContext has been materialized. The ordinary runner owns calls,
faults and suspension. ExecutionContext keeps actual lexical identity, namespaces,
cells, class/annotation state and host services; namespaces are already lazy.
Do not add a frame cache or another per-function arena.

| Transition | State and required behavior |
| --- | --- |
| Entry | Read evaluated receiver/arguments once, bind live defaults through existing binder, borrow funded final workspace. Preserve caller and definition scope/owner separately. Save entry exception and actual function/call spans. Establish logical/managed stack admission before body effects. |
| Ordinary instruction | Use canonical ExecutableWorkState and its existing instruction prefix. Retain current cancellation and first-refusal checks. Operand/scalar publication keeps current alias rules. |
| Child call | Preserve parent's PC/live extent and exact completion intent. Finished children resume the same activation without constructing a parent namespace. A genuinely pending binder or operation stays owned until completion; do not restart/rebind when materializing a context. |
| Protocol/context boundary | Materialize the exact current lexical invocation only when required. Adopt existing slots/PC/exception state; no replay or extra binding. Mirrored/captured/class-sensitive scopes retain real contexts from entry. |
| Fault | Use existing Python translation/provenance and exception-region routing. A deferred protected body materializes once at the failing instruction. Cancellation/refused admission remain terminal despite guest handlers. No parallel native fault dispatcher. |
| Return | Common completion retains typed values, direct unpacked-return intent, tuple admission and target order. Drain actual cleanup before relinquishing backing. Returning aliases keep their surviving owner/identity. |
| Yield/pending I/O | Activation and all pending users remain funded; retain generator send/throw/close behavior. Resume on current managed stack admission, never a borrowed CLR span or an abandoned task. |
| Cleanup | Retire private owned temporaries, await actual users, restore exception/nesting, detach activation from any surviving lexical context, then return workspace. No refund of retained values/caches/aliases. |

Concrete displacement:

- Replace ordinary `_execution` and call-completion storage together, rather than
  leave them authoritative beside a new activation object.
- Remove NativeExecution and its duplicate opcode/read/publish/format/call loop.
- Remove PyExecutableFunction's fixed NativeValues buffer, StartNativeCall,
  StartInline, CanStartInline/CanBindNativeArguments where superseded, plus the
  native-only depth eligibility cutoff and prepared-native-child chain.
- Common completion owns direct tuple unpacking and entry exception restoration.
  Retain shared numeric/text kernels that have genuine ordinary-engine callers.
- Remove tests of private buffer eligibility, preserving their independent
  semantic/refusal/cancellation/cleanup assertions. Retain all externally useful
  tests and current measured source-pair evidence.

Array-backed capacity may deny earlier than stack-private storage. Document that
tradeoff and preflight capacity/metadata/replacement overlap with existing owners.
The new representation must have one actual owner and no hidden allowance,
per-object ledger, weak reclamation, forced GC, fuel or private deadline.

The implementation gate is a coherent replacement with the displaced native
machinery absent. Temporary intermediate source/elapsed regressions are not a
retention decision. If a second authoritative controller or duplicate owned frame
is still necessary, revise the representation before declaring the milestone.
Do not claim the literal transition table proves implementation feasibility.

Focused acceptance reuses function/argument/protected/tuple/closure/stack/generator/
async-host/ownership regressions, including the newly corrected admission-time
defaults. Add tests only for real uncovered semantics. Frozen source/image proof
must precede timing. The controlled scope is complete protected search, invoice/
fulfillment, short fresh config-manifest and unchanged text/JSON controls. Reuse
the existing quiet-VM framed workers and phase boundaries, with a short finite
collection sized to resolve observations (not another full lane). Keep warm,
compile, compile-to-result and wider CPU distinct. A timeout or moving control is
uncertainty, eligible for justified bounded correction, never silent adverse-data
removal or automatic permanent rejection. Decide remaining regression debt only
at the coherent deletion milestone. Full platform/stress/installed consumers
follow a retained source; publication remains postponed.
