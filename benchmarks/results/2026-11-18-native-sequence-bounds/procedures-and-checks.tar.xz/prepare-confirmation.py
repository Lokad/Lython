from pathlib import Path
import ast
import hashlib
import json
import tarfile

lab = Path(__file__).resolve().parent
original = lab / 'quiet'
target = lab / 'confirmation'
target.mkdir()
read = lambda path: path.read_text(encoding='utf-8')
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def write(name, text):
    if name.endswith('.py'):
        ast.parse(text)
    (target / name).write_text(text, encoding='utf-8', newline='\n')


config = json.loads(read(original / 'config.json'))
identity = config['identity']
for role, files in identity['imageFiles'].items():
    assert all(sha(lab / 'frozen' / role / name) == digest for name, digest in files.items())
assert sha(lab / 'representative.json') == config['catalogSHA256']
base = config['root']
root = base.replace('native-index-bounds-b967', 'native-index-bounds-confirm-b968')
unit = config['unit'].replace('lython-b967-native-index-bounds', 'lython-b968-native-index-bounds-confirm')
config.update(root=root, unit=unit, source=base, retireGroups=[],
              sourceCatalogSHA256=config['catalogSHA256'])
jobs = [('scripts.numeric-squared-error.floating.large', 'warm'),
        ('scripts.numeric-squared-error.floating.large', 'compile-run'),
        ('scripts.text-normalization.helper-list', 'warm')]
collect = read(original / 'collect.py')
left, right = collect.index('jobs = '), collect.index('\nassert len(jobs)')
collect = collect[:left] + 'jobs = ' + repr(jobs) + collect[right:]
collect = collect.replace('len(jobs)==5', 'len(jobs)==3').replace('accumulate8seconds', 'accumulate12seconds')
collect = collect.replace('warmupSeconds=8', 'warmupSeconds=12').replace('min(warmed)<8', 'min(warmed)<12')
collect = collect.replace('warmed[i]>=8', 'warmed[i]>=12').replace('if job_index >= 2:', 'if job_index != 1:')
write('collect.py', collect)
write('archive-owned.py', read(original / 'archive-owned.py').replace(
    "len(raw['jobs'])==5", "len(raw['jobs'])==3").replace('jobs=5,elapsedSeconds', 'jobs=3,elapsedSeconds'))
write('run.sh', read(original / 'run.sh').replace(base, root))
assert b'\r' not in (target / 'run.sh').read_bytes()
write('identity.json', read(original / 'identity.json'))
members = ['collect.py', 'archive-owned.py', 'run.sh', 'identity.json']
payload = target / 'payload.tgz'
with tarfile.open(payload, 'w:gz') as archive:
    for name in members:
        archive.add(target / name, arcname=name)
config.update(payloadBytes=payload.stat().st_size, payloadSHA256=sha(payload),
              unpackedBytes=sum((target / name).stat().st_size for name in members))
write('config.json', json.dumps(config, indent=2) + '\n')

launch = read(original / 'remote-launch.py')
left, right = launch.index('\nc=') + 1, launch.index('\nb=Path(')
launch = launch[:left] + 'c=' + repr(config) + launch[right:]
old_source = "for n,h in c['sourceFiles'].items():assert sha(source/c['sourceRole']/n)==h,n"
assert old_source in launch
launch = launch.replace(old_source, "for role, files in c['identity']['imageFiles'].items():\n"
                        "  for n,h in files.items():assert sha(source/role/n)==h,n")
assert "os.link(source/c['sourceRole']/n,p)" in launch
launch = launch.replace("os.link(source/c['sourceRole']/n,p)", 'os.link(source/role/n,p)')
launch = launch.replace('lython-b967-fixtures', 'lython-b968-fixtures').replace('RuntimeMaxSec=330', 'RuntimeMaxSec=270')
write('remote-launch.py', launch)
write('retrieve.py', read(original / 'retrieve.py').replace("['jobs']==5", "['jobs']==3"))
launcher = read(lab / 'launch.py').replace("/'quiet'", "/'confirmation'").replace('seconds=255', 'seconds=220')
launcher = launcher.replace('before255seconds', 'before220seconds')
ast.parse(launcher)
(lab / 'launch-confirmation.py').write_text(launcher, encoding='utf-8', newline='\n')
summary = read(lab / 'summarize.py').split('reference=json.loads', 1)[0]
summary = summary.replace("r/'quiet/retrieved", "r/'confirmation/retrieved")
summary = summary.replace("len(raw['jobs'])==5", "len(raw['jobs'])==3")
summary = summary.replace("r/'summary.json'", "r/'confirmation/summary.json'")
summary += "print('duration', raw['elapsedSeconds'])\n"
ast.parse(summary)
(lab / 'summarize-confirmation.py').write_text(summary, encoding='utf-8', newline='\n')
