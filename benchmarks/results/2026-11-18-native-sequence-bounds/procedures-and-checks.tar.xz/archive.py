from pathlib import Path
import gzip
import hashlib
import json
import shutil
import tarfile

repo = Path('D:/code/Lython')
lab = Path(__file__).resolve().parent
out = repo / 'benchmarks/results/2026-11-18-native-sequence-bounds'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
for index, folder in enumerate(('quiet', 'confirmation')):
    source = lab / folder
    target = out if index == 0 else out / 'confirmation'
    target.mkdir()
    status = read(source / 'terminal-status.json')
    receipt = status['receipt']
    assert status['exitCode'] == '0' and not status['remainingTrace'] and not status['remainingWorkers']
    assert receipt['jobs'] == [5, 3][index] and receipt['complete'] and receipt['quietBeforeAndAfter']
    assert receipt['archivedAndVerifiedUnderLease'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
    assert digest(source / 'observations.tgz') == receipt['archiveSHA256']
    for name in ('archive-receipt.json', 'terminal-status.json', 'observations.tgz'):
        shutil.copyfile(source / name, target / name)
    summary = read((lab if index == 0 else source) / 'summary.json')
    summary['retentionDecisionPending'] = False
    summary['decision'] = 'Retain the native index conversion deletion and repeated compile-to-result gain. Preserve the adverse first warm result and uncertainty.'
    (target / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n',
                                         encoding='utf-8', newline='\n')

for name in ('allocation-summary.json', 'reference-verification.json', 'candidate-verification.json',
             'frozen-identity.json', 'source.patch'):
    shutil.copyfile(lab / name, out / name)
identity = read(lab / 'frozen-identity.json')
for role, files in identity['imageFiles'].items():
    core = lab / 'frozen' / role / 'Lokad.Lython.dll'
    assert digest(core) == files[core.name]
    (out / (role + '-core.dll.gz')).write_bytes(gzip.compress(core.read_bytes(), mtime=0))
with tarfile.open(out / 'procedures-and-checks.tar.xz', 'w:xz') as archive:
    for name in ('prepare.py', 'stage.py', 'launch.py', 'summarize.py', 'archive.py',
                 'prepare-confirmation.py', 'launch-confirmation.py', 'summarize-confirmation.py',
                 'space.json', 'representative.json', 'jobs.json', 'build.log',
                 'reference-verification.log', 'candidate-verification.log',
                 'reference-allocation.json', 'candidate-allocation.json'):
        archive.add(lab / name, arcname=name)
    for check in sorted(lab.glob('Lokad.*.log')):
        archive.add(check, arcname=check.name)
    for folder in ('quiet', 'confirmation'):
        for name in ('config.json', 'collect.py', 'archive-owned.py', 'run.sh', 'remote-launch.py',
                     'retrieve.py', 'launch.log'):
            archive.add(lab / folder / name, arcname=folder + '/' + name)
