from pathlib import Path
import ast
import hashlib
import io
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = Path('D:/code/Lython')
previous = lab.parent / 'json-numeric-tokens-r534'
old = previous / 'quiet'
quiet = lab / 'quiet'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: path.read_text(encoding='utf-8')
read_json = lambda path: json.loads(read(path))
ssh = ['C:/Windows/System32/OpenSSH/ssh.exe', '-i', str(Path.home() / '.ssh/id_lython-bench.pem'),
       '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15', 'lokad@20.166.121.73']


def write(path, value):
    if path.suffix == '.py':
        ast.parse(value)
    path.write_text(value, encoding='utf-8', newline='\n')


proofs = []
for folder, member, anchor in [
    ('local-publication', 'b472/current-core.dll', 'local-publication-b472-20261108'),
    ('integer-helper-prototype', 'b473/current-core.dll', 'primitive-helpers-b473-20261108'),
]:
    canonical = f'benchmarks/results/2026-11-08-{folder}/observations.tar.xz'
    blob = (repo / canonical).read_bytes()
    assert blob == subprocess.check_output(['git', 'show', 'HEAD:' + canonical], cwd=repo)
    with tarfile.open(fileobj=io.BytesIO(blob)) as archive:
        exact = archive.extractfile(member).read()
    proofs.append(dict(kind='superseded archived core replica', canonical=canonical,
                       canonicalSHA256=sha(blob), member=member, sha256=sha(exact),
                       bytes=len(exact), anchor=anchor + '/candidate/Lokad.Lython.dll',
                       committedBlobVerified=True))

proof_script = '''from pathlib import Path
import fcntl, hashlib, json, os, shutil, stat, subprocess
root = Path('/home/lokad/lython-bench-checks').resolve()
proofs = PROOFS
with (root / 'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert subprocess.run(['pgrep', '-af', '[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],
                          capture_output=True).returncode == 1
    assert not any(os.path.ismount(path) for path in root.glob('*/guest-fixtures'))
    inodes = {}
    for proof in proofs:
        anchor = root / proof.pop('anchor')
        info = anchor.lstat()
        assert anchor.resolve() == anchor and stat.S_ISREG(info.st_mode) and info.st_uid == os.getuid()
        assert info.st_size == proof['bytes'] and hashlib.sha256(anchor.read_bytes()).hexdigest() == proof['sha256']
        proof.update(links=info.st_nlink, paths=[])
        inodes[info.st_dev, info.st_ino] = proof
    for base, _, names in os.walk(root):
        for name in names:
            path = Path(base) / name
            info = path.lstat()
            if (proof := inodes.get((info.st_dev, info.st_ino))) is not None:
                assert path.resolve() == path and stat.S_ISREG(info.st_mode) and info.st_uid == os.getuid()
                proof['paths'].append(str(path.relative_to(root)))
    for proof in proofs:
        assert len(proof['paths']) == proof['links']
        assert all(path.startswith(('local-publication-b472-', 'primitive-helpers-b473-',
                                    'independent-proof-b474-', 'primitive-proof-b475-'))
                   for path in proof['paths']), proof
        proof['paths'].sort()
    print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free, choices=proofs)))
'''.replace('PROOFS', repr(proofs))
response = subprocess.run(ssh + ['python3 -'], input=proof_script, text=True, encoding='utf-8',
                          capture_output=True, timeout=55)
(lab / 'space.log').write_text(response.stdout + response.stderr, encoding='utf-8')
assert response.returncode == 0, response.stderr
space = json.loads(response.stdout)
write(lab / 'space.json', json.dumps(space, indent=2) + '\n')

identity = read_json(lab / 'frozen-identity.json')
assert all(sha((lab / 'frozen' / role / name).read_bytes()) == digest
           for role, files in identity['imageFiles'].items() for name, digest in files.items())
quiet.mkdir()
root = '/home/lokad/lython-bench-checks/native-index-bounds-b967-20261118'
unit = 'lython-b967-native-index-bounds-20261118'
source = read_json(old / 'config.json')
jobs = [tuple(row) for row in read_json(lab / 'jobs.json')]
collector = read(old / 'collect.py')
start, end = collector.index('\njobs = '), collector.index('\nassert len(jobs)')
collector = collector[:start] + '\njobs = ' + repr(jobs) + collector[end:]
write(quiet / 'collect.py', collector.replace('JSON numeric decoding source pair', 'Native sequence bounds source pair'))
write(quiet / 'archive-owned.py', read(old / 'archive-owned.py'))
write(quiet / 'run.sh', read(old / 'run.sh').replace(source['root'], root))
assert b'\r' not in (quiet / 'run.sh').read_bytes()
write(quiet / 'identity.json', json.dumps(identity, indent=2) + '\n')
shutil.copyfile(lab / 'representative.json', quiet / 'representative.json')
members = ['collect.py', 'archive-owned.py', 'run.sh', 'identity.json', 'representative.json']
for role in ('reference', 'candidate'):
    name = role + '/Lokad.Lython.dll'
    (quiet / role).mkdir()
    shutil.copyfile(lab / 'frozen' / name, quiet / name)
    members.append(name)
payload = quiet / 'payload.tgz'
with tarfile.open(payload, 'w:gz') as archive:
    for name in members:
        archive.add(quiet / name, arcname=name)
total = sum((quiet / name).stat().st_size for name in members)
available = space['freeBytes']
retire = []
for proof in space['choices']:
    if available > 254 * 1024 * 1024 + total + 131072:
        break
    retire.append(proof)
    available += proof['bytes']
assert available > 254 * 1024 * 1024 + total + 131072, (available, total)
settings = dict(root=root, unit=unit, source=source['root'], sourceRole='candidate',
                sourceFiles=source['identity']['imageFiles']['candidate'],
                sourceCatalogSHA256=source['catalogSHA256'], catalogSHA256=identity['catalogSHA256'],
                identity=identity, retireGroups=retire, payloadBytes=payload.stat().st_size,
                payloadSHA256=sha(payload.read_bytes()), unpackedBytes=total)
write(quiet / 'config.json', json.dumps(settings, indent=2) + '\n')
launcher = read(old / 'remote-launch.py')
start, end = launcher.index('\nc=') + 1, launcher.index('\nb=Path(')
launcher = launcher[:start] + 'c=' + repr(settings) + launcher[end:]
write(quiet / 'remote-launch.py', launcher.replace('lython-b964-fixtures', 'lython-b967-fixtures'))
write(quiet / 'retrieve.py', read(old / 'retrieve.py').replace('JSON numeric decoding', 'Native sequence bounds'))
write(lab / 'launch.py', read(previous / 'launch.py').replace('JSON numeric decoding', 'Native sequence bounds'))
write(lab / 'summarize.py', read(previous / 'summarize.py'))
print('Staged', total, 'bytes with', len(retire), 'exact archived replica groups')
