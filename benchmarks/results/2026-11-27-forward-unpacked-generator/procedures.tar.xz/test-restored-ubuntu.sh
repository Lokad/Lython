set -eu
source_root=/mnt/d/code/Lython
target_root="$HOME/lython-starmap-rows-8066Vm"
test -d "$target_root"
for file in $(cat "$source_root/.git/agent-notes/review-20261031/forward-unpacked-generator-20261127/tested-paths.txt"); do
    cp -- "$source_root/$file" "$target_root/$file"
    cmp -- "$source_root/$file" "$target_root/$file"
done
cd "$target_root"
sdk="$HOME/.dotnet/dotnet"
"$sdk" build src/Lokad.Lython/Lokad.Lython.csproj -c Release -f net10.0 --no-restore --no-incremental
for suite in Lokad.Lython.PublicApi.Tests Lokad.Lython.Tests; do
    "$sdk" test "tests/$suite/$suite.csproj" -c Release -f net10.0 --no-restore --filter 'FullyQualifiedName~UnpackedGeneratorDisplay'
done
