set -eu
root=/home/lokad/lython-bench-checks/casing-checkpoint-cpython-b1274-20261121
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
