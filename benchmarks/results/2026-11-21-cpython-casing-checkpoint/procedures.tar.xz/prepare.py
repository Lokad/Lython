from pathlib import Path
import gzip, hashlib, json, shutil, subprocess, sys, tarfile
from io import BytesIO

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
source=lab.parent/sys.argv[1]
template=lab.parent/'normalize-json-cpython'
q=lab/'quiet'
previous=template/'confirmation/quiet'
def read(p): return p.read_text(encoding='utf-8')
def load(p): return json.loads(read(p))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def emit(p,s):
    if p.suffix=='.py': compile(s,str(p),'exec')
    p.write_text(s,encoding='utf-8',newline='\n')
def save(p,v): emit(p,json.dumps(v,indent=2,ensure_ascii=False)+'\n')
index=load(source/'identity.json')
revision=index['candidate']
assert revision.startswith('b140244f0')
assert not subprocess.check_output(['git','diff','--name-only',revision,'HEAD','--','src'],cwd=repo)
assert not subprocess.check_output(['git','diff','--name-only','HEAD','--','src'],cwd=repo)
retained=subprocess.check_output(['git','log','-1','--format=%H','--','src'],cwd=repo,text=True).strip()
measured="../2026-11-21-pinned-unicode-casing/fold/candidate-core.dll.gz"
payload_source=repo/"benchmarks/results"/measured.removeprefix("../")
assert gzip.decompress(payload_source.read_bytes())==(source/'frozen/candidate/Lokad.Lython.dll').read_bytes()
save(lab/'selected-source.json',dict(lab=sys.argv[1],retained=retained,measuredCore=measured))
verified=load(source/'candidate-verify.json')
assert index['candidate']==revision and verified['state']=='Completed'
files=index['imageFiles']['candidate']
image=source/'frozen/candidate'
assert len(files)==32 and {n:sha(image/n) for n in files}==files
assert verified['catalogSha256']==index['catalogSHA256']==sha(source/'representative.json')
assert index['pythonWorkerSHA256']==sha(repo/'benchmarks/cpython-worker.py')
staging=load(source/'quiet/config.json')
receipt=load(source/'quiet/archive-receipt.json')
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
assert receipt['archiveSHA256']==sha(source/'quiet/observations.tgz')
q.mkdir()
identity=dict(sourceRevision=revision,imageSource=revision,purpose='Map-based text report at the casing checkpoint against stock CPython',
              imageFiles=dict(candidate=files),catalogSHA256=index['catalogSHA256'],cpythonWorkerSHA256=index['pythonWorkerSHA256'],
              auxiliaryFiles={name:digest for name,digest in files.items() if name!='Lokad.Lython.dll'},
              coreSHA256={name:files['Lokad.Lython.dll'] for name in ('candidate','candidate-control')})
save(q/'identity.json',identity)
shutil.copyfile(repo/'benchmarks/cpython-worker.py',q/'cpython-worker.py')

prior=load(previous/'config.json')
root='/home/lokad/lython-bench-checks/casing-checkpoint-cpython-b1274-20261121'
unit='lython-b1274-compiler-checkpoint-cpython-20261121'
normalize='scripts.json-normalized-records.large'
validator='scripts.text-summary-helpers.map-callback.large'
for name in ('collect.py','archive-owned.py','retrieve.py','run.sh'):
    s=read(previous/name).replace(prior['root'],root).replace(prior['unit'],unit).replace('B1253','B1274')
    if name == 'collect.py':
        begin=s.index("    for case_id,lane in ")
        end=s.index("        assert time.monotonic()",begin)
        case=validator
        s=s[:begin]+f"    for case_id,lane in [({case!r},'warm'),({case!r},'compile-run'),({case!r},'compile')]:\n"+s[end:]
        s=s.replace("+16","+12")
    if name in ('archive-owned.py','retrieve.py'):
        s=s.replace("==2","==3").replace("jobs=2,","jobs=3,")
    if name == 'run.sh':
        assert '\r' not in s
    emit(q/name,s)
assert b'\r' not in (q/'run.sh').read_bytes()
parts=('identity.json','collect.py','archive-owned.py','run.sh','cpython-worker.py')
archive=q/'payload.tgz'
with tarfile.open(archive,'w:gz') as f:
    for n in parts: f.add(q/n,arcname=n)
# Remove only the unpacked duplicate of a verified prior observation.
archive_path = 'benchmarks/results/2026-11-21-pinned-unicode-casing/observations.tgz'
canonical = subprocess.check_output(['git', 'show', 'HEAD:'+archive_path], cwd=repo)
prior_receipt = load(repo / archive_path.replace('observations.tgz', 'archive-receipt.json'))
archive_sha = hashlib.sha256(canonical).hexdigest()
assert prior_receipt['archiveSHA256']==archive_sha and prior_receipt['archivedAndVerifiedUnderLease']
prior_root = 'pinned-unicode-casing-b1272-20261121'
member = 'confirmation/confirmation.json'
with tarfile.open(fileobj=BytesIO(canonical),mode='r:gz') as packed:
    duplicate = packed.extractfile(member).read()
proof = dict(archives={prior_root+'/observations.tgz':archive_sha}, paths=[prior_root+'/'+member],
             bytes=len(duplicate),links=1, sha256=hashlib.sha256(duplicate).hexdigest(), verifiedCanonicalGitArchive=archive_path)
config=dict(root=root,unit=unit,identity=identity,source=staging['root'],sourceRole='candidate',
            sourceFiles=files,sourceCatalogSHA256=identity['catalogSHA256'],catalogSHA256=identity['catalogSHA256'],
            cpythonWorkerSHA256=identity['cpythonWorkerSHA256'],retireGroups=[proof],donorArchiveSHA256=receipt['archiveSHA256'],
            payloadBytes=archive.stat().st_size,payloadSHA256=sha(archive),unpackedBytes=sum((q/n).stat().st_size for n in parts))
save(q/'config.json',config)
s=read(previous/'remote-launch.py')
a,b=s.index('\nc=')+1,s.index('\nb=Path(')
s=(s[:a]+'c='+repr(config)+s[b:]).replace('lython-b1253-fixtures','lython-b1274-fixtures')
s=s.replace("176160768+c['unpackedBytes']+32*1024*1024","176160768+c['unpackedBytes']+8*1024*1024")
emit(q/'remote-launch.py',s)
launch=read(template/'confirmation/launch.py').replace("parent/'quiet-space-verified'","parent/'quiet'")
emit(lab/'launch.py',launch.replace("B1253 JSON normalization confirmation","B1274 casing checkpoint"))
