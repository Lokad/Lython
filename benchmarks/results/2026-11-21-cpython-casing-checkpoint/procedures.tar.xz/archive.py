from pathlib import Path
import base64
import hashlib
import gzip
import json
import shutil
import statistics
import tarfile

local = Path(__file__).resolve().parent
lab = local / "quiet"
out = Path("benchmarks/results/2026-11-21-cpython-casing-checkpoint")
selection=json.loads((local/'selected-source.json').read_text(encoding='utf-8'))
candidate_lab=local.parent/selection["lab"]
read = lambda path: path.read_text(encoding="utf-8-sig")
load = lambda path: json.loads(read(path))
sha = lambda value: hashlib.sha256(value).hexdigest()
terminal = load(lab / "terminal-status.json")
receipt = load(lab / "archive-receipt.json")
identity = load(lab / "identity.json")
built = dict(sourceRevision=identity["sourceRevision"], imageSource=identity["imageSource"], coreSHA256=identity["coreSHA256"]["candidate"])
files = identity["imageFiles"]["candidate"]
assert len(files) == 32
assert {name: sha((candidate_lab / "frozen/candidate" / name).read_bytes()) for name in files} == files
assert built["sourceRevision"] == identity["sourceRevision"] and built["coreSHA256"] == files["Lokad.Lython.dll"]
assert terminal["exitCode"] == "0" and terminal["receipt"] == receipt and receipt["jobs"] == 3
assert receipt["archivedAndVerifiedUnderLease"]
assert sha((lab / "observations.tgz").read_bytes()) == receipt["archiveSHA256"]
assert not terminal.get("remainingTrace",False) and not terminal.get("remainingWorkers","")
assert all(receipt[name] for name in ("complete","allWorkersJoined","guestFixturesRemoved",
                                      "quietBeforeAndAfter","archivedAndVerifiedUnderLease"))
raw = load(lab / "retrieved/confirmation/confirmation.json")
cases = load(candidate_lab / "representative.json")["cases"]
assert sha((candidate_lab / "representative.json").read_bytes()) == load(lab / "identity.json")["catalogSHA256"]
assert raw["complete"] and len(raw["jobs"]) == 3 and len(cases) == 4
previous = load(lab.parents[1] / "postponed-annotation-cpython/quiet/retrieved/confirmation/confirmation.json")
stock_python = previous["jobs"][0]["identities"]["CPython"]
labels = ["candidate","candidate-control","CPython","CPython-control"]
rows = []
by_id = {case['id']: case for case in cases}
full_case='scripts.text-summary-helpers.map-callback.large'
assert [job['case'] for job in raw['jobs']] == [full_case]*3
assert [job['lanes'] for job in raw['jobs']] == [['warm'],['compile-run'],['compile']]
for job in raw['jobs']:
    case = by_id[job['case']]
    assert job["case"] == case["id"] and job["workersJoinedAndFixturesRemoved"] and not job["diagnostic"]
    assert set(labels) == set(job["identities"])
    for role in labels[2:]:
        python = job["identities"][role]
        assert python["version"] == stock_python["version"] and python["version"].startswith("3.13.16 ")
        assert python["executableSha256"] == stock_python["executableSha256"]
        assert python["adapterSha256"] == identity["cpythonWorkerSHA256"]
    for role in labels[:2]:
        worker_image = identity["imageFiles"]["candidate"]
        supplied = {
            Path(lib["path"]).name: lib["sha256"].lower()
            for lib in job["identities"][role]["libraries"]
            if Path(lib["path"]).name in worker_image
        }
        assert supplied.get("Lokad.Lython.dll") == worker_image["Lokad.Lython.dll"]
        assert all(worker_image[name] == value for name, value in supplied.items())
    lanes = job["lanes"]
    assert len(job["samples"]) == len(labels)*len(lanes)*7
    fixture = json.loads(case["fixtureJson"])
    byte_counts = {name:len(base64.b64decode(data)) for name,data in fixture.get("inputFiles",{}).items()}
    line_counts = {name:len(base64.b64decode(data).splitlines()) for name,data in fixture.get("inputFiles",{}).items()}
    for lane in lanes:
        engines = {}
        for label in labels:
            samples = [s for s in job["samples"] if s["engine"] == label and s["lane"] == lane]
            assert [s["round"] for s in samples] == list(range(7))
            values, cpu = [], []
            for row in samples:
                value = row["response"]
                assert value["completedInvocations"] > 0 and value["status"] == "Completed"
                assert value["sourceSha256"] == case["sourceSha256"] and value["fixtureSha256"] == case["fixtureSha256"]
                assert value.get("actualOutputSha256") == (None if lane == "compile" else case["expectedOutputSha256"])
                assert value.get("actualFilesSha256") == (None if lane == "compile" else case.get("expectedFilesSha256"))
                values.append(1000*value["elapsedTicks"]/value["clockFrequency"]/value["completedInvocations"])
                cpu.append(1000*row["externalProcessCpuTicks"]/row["externalCpuFrequency"]/value["completedInvocations"])
            median = statistics.median(values)
            low, _, high = statistics.quantiles(values, n=4, method="inclusive")
            engines[label] = dict(elapsedMs=median, cpuMs=statistics.median(cpu), elapsedIQRPercent=100*(high-low)/median)
        left = [engines[x]["elapsedMs"] for x in labels[:2]]
        right = [engines[x]["elapsedMs"] for x in labels[2:]]
        ratio = [l/r for l in left for r in right]
        lc, rc = [100*(max(x)/min(x)-1) for x in (left,right)]
        rows.append(dict(case=case["id"],lane=lane,inputFileBytes=byte_counts,inputFileLines=line_counts,
                         lythonMs=[min(left),max(left)],cpythonMs=[min(right),max(right)],
                         ratio=[min(ratio),max(ratio)],lythonControlPercent=lc,cpythonControlPercent=rc,
                         maxIQRPercent=max(e["elapsedIQRPercent"] for e in engines.values()),engines=engines))
        print(case["id"], lane, "L", left, "C", right, "ratio", min(ratio), max(ratio),
              "spread", lc, rc, "IQR max", rows[-1]["maxIQRPercent"])
assert len(rows) == 3
out.mkdir(exist_ok=False)
core_bytes=(candidate_lab/'frozen/candidate/Lokad.Lython.dll').read_bytes()
assert sha(core_bytes)==files['Lokad.Lython.dll']
summary = dict(source=load(lab/'identity.json')['sourceRevision'],coreSHA256=load(lab/"identity.json")["coreSHA256"]["candidate"],
               collection="B1274", retainedSource=selection["retained"],rows=rows,elapsedSeconds=raw["elapsedSeconds"],
               archiveSHA256=receipt["archiveSHA256"],measuredColdStartup=False,
               measuredCore=selection["measuredCore"],
               memoryMeasurementIncluded=False, builtImageSource=built["imageSource"], verifiedBatches=84)
(out / "summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8")
for name in ["terminal-status.json","archive-receipt.json","observations.tgz"]:
    shutil.copyfile(lab / name, out / name)
assert gzip.decompress((out / summary["measuredCore"]).read_bytes()) == core_bytes
with tarfile.open(out / "procedures.tar.xz", "w:xz", preset=6) as tar:
    for name in ("prepare.py","launch.py","archive.py","selected-source.json"):
        tar.add(local/name,arcname=name)
    for file in sorted(lab.iterdir()):
        if file.suffix in {".json",".py",".sh",".log"}:
            tar.add(file,arcname=file.name)
print("Verified and archived B1274, all measured lanes and original control observations.")
