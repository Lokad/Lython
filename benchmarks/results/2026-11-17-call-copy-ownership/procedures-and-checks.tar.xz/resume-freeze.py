from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;notes=r.parent;repo=Path('D:/code/Lython');reference=notes/'utf8-width-r483/refined';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=json.loads((reference/'frozen/identity.json').read_text(encoding='utf-8'))['imageFiles']['candidate'];frozen=r/'frozen';images={role:{n:sha(frozen/role/n)for n in files}for role in ['reference','candidate']}
assert images['reference']==files and[n for n in files if images['reference'][n]!=images['candidate'][n]]==['Lokad.Lython.dll']
assert images['candidate']['Lokad.Lython.dll']==sha(repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll')
s=(r/'freeze.py').read_text(encoding='utf-8');exec(compile(s[s.index('old=json.loads'):],str(r/'freeze.py'),'exec'))

