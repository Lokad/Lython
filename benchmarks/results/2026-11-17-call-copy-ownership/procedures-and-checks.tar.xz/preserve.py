from pathlib import Path
import gzip,json,shutil,subprocess,tarfile
r=Path(__file__).parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-17-call-copy-ownership';out.mkdir(exist_ok=False)
for source,target in [(r/'summary.json','summary.json'),(r/'allocation-summary.json','allocation-summary.json'),(r/'frozen/identity.json','identity.json'),(r/'candidate-sources.tar.xz','candidate-sources.tar.xz'),(r/'catalog.json','catalog.json'),(r/'quiet/observations.tgz','observations.tgz'),(r/'quiet/archive-receipt.json','archive-receipt.json'),(r/'quiet/terminal-status.json','terminal-status.json')]:shutil.copyfile(source,out/target)
with gzip.open(out/'candidate-core.dll.gz','wb')as f:f.write((r/'frozen/candidate/Lokad.Lython.dll').read_bytes())
# Preserve the failed unavailable-types fixture and make the current preparation
# script reflect the separately verified supported classmethod diagnostic.
p=r/'freeze.py';shutil.copyfile(p,r/'freeze-original-types.py');text=p.read_text(encoding='utf-8');case=json.loads((r/'catalog.json').read_text(encoding='utf-8'))['cases'][0]
a=text.index('case.update(');b=text.index("\ncase['sourceUtf8Bytes']",a);text=text[:a]+"case.update("+", ".join(k+'='+repr(case[k])for k in ['id','category','scale','size','source','fixtureJson','expectedOutput','fixtureTextUtf8Bytes','fixtureTextCodePoints'])+")"+text[b:];p.write_text(text,encoding='utf-8',newline='\n')
with tarfile.open(out/'procedures-and-checks.tar.xz','w:xz')as a:
 for p in r.rglob('*'):
  if p.is_file()and not{'frozen','retrieved','__pycache__'}&set(p.relative_to(r).parts)and p.suffix in{'.py','.log','.json','.txt','.sh'}:a.add(p,arcname=p.relative_to(r).as_posix())
s=json.loads((r/'summary.json').read_text(encoding='utf-8'));assert s['complete']and s['allUsersJoinedAndFixturesRemoved'];table=[]
for x in s['rows']:
 fmt=lambda k:f"{min(x[k]):+.2f}..{max(x[k]):+.2f}%"
 table.append(f"| {x['case']} / {x['lane']} | {fmt('elapsedChangePercent')} | {fmt('cpuChangePercent')} | {x['referenceSpreadPercent']:.2f}/{x['candidateSpreadPercent']:.2f}% |")
decision=dict(retain=True,basis='Copied argument capacity and prepended receivers must remain admitted until actual pending users/cleanup finish. Independent4regressions fail qualified baseline/pass final fix. Correct resource funding required despite diagnostic overhead.',reference='Qualifieddbdf8262/frozena95ff2a4',candidate='Four-fileR486on9d9fd1e9/frozen384327c2; no borrowed-view representation',compatibility='Large private copies can refuse earlier; failure before allocation/body effects and cleanup/refunds preserved; public API unchanged.',diagnosticCost='1025wide bound calls allocate32800additional bytes (+2.86%),accountedpeak+288B; fresh+2.13..+3.89%,warmuncertain/ref5.26%movement. JSONcontrol essentiallyflat. No speedup claim.',focused='Each actualWindows11/10:38internal,1050ordinarypublic,422continuation/generator; filters overlap, not summed. Extra18context-manager/cleanup11 pass.',fullDeliveryPending=True,broaderPerformanceObjectiveComplete=False,publicationHeld=True)
(out/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8')
(out/'README.md').write_text('''# Copied callable storage: admission and pending ownership

R486/B903,2026-11-17UTC. Retained correctness correction, full delivery pending.
Qualifieddbdf8262/frozena95ff2a4 versus four-file source on9d9fd1e9/frozen384327c2.
585production/2382build-test inputs archived; public API unchanged. No wider
argument view/collection bridge or migrated binder signatures remain. Original
[R485 prototype and decision](../2026-11-17-borrowed-binding/README.md) stay separate.

General default copied packets and non-function bound receiver prefixes now use
one existing conservative capacity estimate and temporary reservation. Admit
before allocation/body effects, preserve references/funding through pending users
and awaited cleanup, then clear/refund. No independent allowance, new owner
framework, retry, tracing, per-object ledger, quota or abandoned work. Small
control headroom remains; major copies may reject earlier. Deterministic native
cleanup/refunds and terminal first-refusal behavior remain.

Four independent admission/cancellation regressions fail qualified4bfsource after
a nonincremental build and pass final source. Current actualWindows11/10 each
pass38internal/1050ordinarypublic/422continuation-generator cases; filters overlap
and are not summed. Extra18context-manager/native-cleanup11 cases pass. Private
baseline test copy retired after exact archived/current-source verification.

| Complete workload / lane | Elapsed change | Wider process CPU change | Reference/candidate control spread |
| --- | ---: | ---: | ---: |
'''+ '\n'.join(table)+'''

The affected synthetic bound-wide max uses seven Python comparison callbacks per
call,1025calls including the identity assertion. Correct funding adds32800allocated
bytes (+2.86%) and288Baccountedpeak. Fresh elapsed+2.13..+3.89%; widerCPU−0.27..+5.76%.
Warm controls move5.26%/1.08%, so no precise warm CPU claim. JSON-lines control
allocation/peaks essentially flat. All shared-budget baselines restore. This cost
is accepted for required admission/lifetime correctness, not claimed as a gain.
One bounded diagnostic is sufficient; no unchanged confirmation campaign.

Actual copied32file workers pass both catalog goldens against CPython3.13.2 before
staging. Initial diagnostic used unavailable types module and failed before
timing; original source/result preserved. Revised supported classmethod(max)
keeps Python identity and comparison semantics. No production compatibility change
was made to accommodate the benchmark.

Quiet AzureF4as_v7/Ubuntu24.04.4/.NET11RC3,3jobs117.05seconds,6second rotated
warmups/five samples/four processes; normalGC/tiering. Mediated I/O/full output/
file validation/prior-result cleanup included; compilation only fresh. Staging,
reset/protocol/startup/final cache teardown excluded. WiderCPU is quantized.
All quiet/golden/Closed/exit/join/archive checks pass; RAM removed,terminal cached.
Only exact committed withdrawn912core/raw/archive and older profile archive
retired with fresh lease/path/UID/hash/link/all-alias proof. Currentqualifieda95,
toolchains/canonicals and254/252MiB floors preserved. Full Windows/Ubuntu,
original stress and installed Release consumers qualify the final four-file
boundary next. Publication held; substantial performance roadmap remains active.

[Decision](decision.json),[source](candidate-sources.tar.xz),[catalog](catalog.json),
[summary](summary.json),[allocation](allocation-summary.json),[raw](observations.tgz),
[identity](identity.json),[checks/original failure](procedures-and-checks.tar.xz).
''',encoding='utf-8',newline='\n')
p=repo/'benchmarks/EXPERIMENTS.md';text=p.read_text(encoding='utf-8');text+='\nR486/B903: [copied callable storage](results/2026-11-17-call-copy-ownership/README.md) retained independently after wider view removal. Four-file fix,4regressions fail qualified baseline/pass final; actual11/10each38internal/1050public/422continuation cases (overlapping). One117.05s affected diagnostic:1025wide bound calls+32800allocatedB/+288Bpeak,fresh+2.13..+3.89%; warmref5.26%movement. JSONcontrol effectivelyflat, all baselines/gates/join/archive restored. Necessary correctness cost accepted, no speedupclaim/unchanged campaign. Full delivery next, publication held/broader objective active.\n';p.write_text(text,encoding='utf-8',newline='\n')
p=repo/'PLAN.md';text=p.read_text(encoding='utf-8').replace('final diagnostics/full delivery pending.','final diagnostic117.05s complete; full delivery pending.');text=text.replace('  Correct funding is required even if it has a cost; claim no unmeasured gain.','  Final117.05s pair: diagnostic1025boundcalls+32800allocatedB/+288Bpeak,\\n  fresh+2.13..+3.89%; warmref5.26%movement. JSONcontrol essentiallyflat.\\n  Accept necessary correctness cost, no speedupclaim/unchanged campaign.');p.write_text(text,encoding='utf-8',newline='\n')
print('Final four-file ownership correction/checks/diagnostic cost preserved; prototype removed, full delivery pending.')

