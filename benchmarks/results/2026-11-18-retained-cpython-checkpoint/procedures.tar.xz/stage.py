from pathlib import Path
import ast
import hashlib
import io
import json
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
donor = lab.parent / "borrowed-expanded-call-r566"
phase = lab.parent / "current-helper-phases-r560"
quiet = donor / "quiet"
read = lambda path: path.read_text(encoding="utf-8")
load = lambda path: json.loads(read(path))
sha = lambda value: hashlib.sha256(value).hexdigest()

def write(path, data):
    if path.suffix == ".py":
        ast.parse(data)
    path.write_text(data, encoding="utf-8", newline="\n")

def save(path, data):
    write(path, json.dumps(data, indent=2, ensure_ascii=False) + "\n")

catalog = lab / "representative.json"
catalog_hash = sha(catalog.read_bytes())
verified = load(lab / "verify.json")
assert verified["state"] == "Completed" and verified["catalogSha256"] == catalog_hash
prior = load(quiet / "config.json")
files = prior["identity"]["imageFiles"]["candidate"]
assert len(files) == 32 and files["Lokad.Lython.dll"].startswith("dd0dc932")
assert {name: sha((donor / "frozen/candidate" / name).read_bytes()) for name in files} == files

root = "/home/lokad/lython-bench-checks/retained-cpython-b993-20261118"
unit = "lython-b993-retained-cpython-20261118"
script_hash = sha(Path("benchmarks/cpython-worker.py").read_bytes())
identity = dict(sourceRevision="d63004a6f", purpose="Four retained-source workloads against stock CPython",
                imageFiles={"candidate": files}, auxiliaryFiles={k: v for k,v in files.items() if k != "Lokad.Lython.dll"},
                coreSHA256={role: files["Lokad.Lython.dll"] for role in ("candidate","candidate-control")},
                catalogSHA256=catalog_hash, cpythonWorkerSHA256=script_hash, normalAdapterPin="0.4.0")
save(lab / "identity.json", identity)
jobs = [(row["id"], False) for row in load(catalog)["cases"]]
lanes = '["warm", "compile-run", "compile"]'
runner = read(phase / "collect.py")
runner = runner.replace("B986 same-process warm/fresh helper comparison with a configuration control",
                        "B993 retained-source warm, compile-to-result and compilation comparison")
runner = runner.replace("for case_id,diagnostic in [('scripts.text-normalization.helper-list',False),('scripts.config-edit.small',False),('scripts.text-normalization.helper-list',True)]:",
                        f"for case_id,diagnostic in {jobs!r}:")
runner = runner.replace("time.monotonic()-started<150,'Retain at least30seconds for cleanup/archive'",
                        "time.monotonic()-started<270,'Leave time for cleanup and archival'")
runner = runner.replace("(['warm','compile-run']if index%2==0 else ['compile-run','warm'])",
                        f"({lanes} if index%2==0 else list(reversed({lanes})))")
runner = runner.replace("(2 if diagnostic else 8 if case_id=='scripts.text-normalization.helper-list' else 3)",
                        "(3 if lane=='compile' or case_id=='scripts.config-edit.small' else 6 if case_id=='scripts.text-normalization.helper-list' else 4)")
runner = runner.replace("['warm','compile-run']", lanes)
assert runner.count(lanes) == 3
assert script_hash in runner
write(lab / "collect.py", runner)
archive_script = read(phase / "archive-owned.py").replace("==3", "==4").replace("jobs=3", "jobs=4")
write(lab / "archive-owned.py", archive_script)
write(lab / "run.sh", f'set -eu\nroot={root}\ntrap \'result=$?; printf "%s\\n" "$result" > "$root/exit-code.txt"\' EXIT\npython3 "$root/collect.py"\n')
assert b"\r" not in (lab / "run.sh").read_bytes()

proofs = []
member = "confirmation/confirmation.json"
for artifact, folder in [
    ("current-helper-phases", "current-helper-phases-b986"),
    ("direct-keyword-overflow", "keyword-hash-b991"),
    ("borrowed-expanded-call", "expanded-call-b992"),
    ("line-count-cpython-checkpoint", "line-count-cpython-b984"),
    ("normalization-cpython-checkpoint", "trimmed-split-cpython-b982"),
]:
    canonical = f"benchmarks/results/2026-11-18-{artifact}/observations.tgz"
    exact = subprocess.check_output(["git","show",f"origin/master:{canonical}"])
    assert exact == Path(canonical).read_bytes()
    with tarfile.open(fileobj=io.BytesIO(exact), mode="r:gz") as tar:
        observation = tar.extractfile(member).read()
    assert json.loads(observation)["complete"]
    proofs.append(dict(paths=[f"{folder}-20261118/{member}"], canonical=canonical, canonicalSHA256=sha(exact),
                       member=member, sha256=sha(observation), bytes=len(observation), links=1,
                       kind="exact archived raw observation replica", committedBlobVerified=True))
for proof in load(donor / "quiet-space.json")["replicas"]:
    canonical = proof["canonical"]
    if not canonical.startswith(("benchmarks/results/2026-11-16-", "benchmarks/results/2026-11-17-")):
        continue
    assert len(proof["paths"]) == proof["links"] == 1 and canonical.endswith("/observations.tgz")
    exact = subprocess.check_output(["git","show",f"origin/master:{canonical}"])
    assert exact == Path(canonical).read_bytes()
    assert sha(exact) == proof["canonicalSHA256"] == proof["sha256"] and len(exact) == proof["bytes"]
    proofs.append(proof)
remote = r'''
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
root=Path('/home/lokad/lython-bench-checks').resolve()
assert root==Path('/home/lokad/lython-bench-checks')
verified=[]
with (root/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert not subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.13.*cpython-worker.py'],capture_output=True).stdout
    assert not any(os.path.ismount(p) for p in root.glob('*/guest-fixtures'))
    for proof in PROOFS:
        p=root/proof['paths'][0]
        if not p.exists():continue
        v=p.lstat()
        assert p.resolve()==p and p.is_relative_to(root) and stat.S_ISREG(v.st_mode)
        assert v.st_uid==os.getuid() and v.st_size==proof['bytes'] and v.st_nlink==proof['links']
        assert hashlib.sha256(p.read_bytes()).hexdigest()==proof['sha256']
        verified.append(proof)
    print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free,replicas=verified)))
'''.replace("PROOFS",repr(proofs))
write(lab / "replica-proof.py", remote)
ssh = ["C:/Windows/System32/OpenSSH/ssh.exe","-i",str(Path.home()/".ssh/id_lython-bench.pem"),
       "-o","BatchMode=yes","-o","ConnectTimeout=15","lokad@20.166.121.73"]
space = json.loads(subprocess.check_output(ssh+["python3 -"], input=remote.encode("utf-8"),timeout=45))
save(lab / "space.json",space)
payload = lab / "payload.tgz"
names = ["representative.json","identity.json","collect.py","archive-owned.py","run.sh"]
with tarfile.open(payload, "w:gz") as archive:
    for name in names:
        archive.add(lab / name, arcname=name)
unpacked = sum((lab / name).stat().st_size for name in names)
needed,available = 254*1024*1024 + unpacked + 512*1024, space["freeBytes"]
retire = []
for proof in sorted(space["replicas"],key=lambda it:-it["bytes"]):
    if available >= needed:break
    retire.append(proof)
    available += proof["bytes"]
assert available >= needed,(available,needed,space["replicas"])
config = dict(root=root,unit=unit,source=prior["root"],sourceRole="candidate",sourceFiles=files,
              sourceCatalogSHA256=prior["catalogSHA256"],catalogSHA256=catalog_hash,identity=identity,
              retireGroups=retire,payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload.read_bytes()),
              unpackedBytes=unpacked,cpythonWorkerSHA256=script_hash)
save(lab / "config.json",config)
launcher = read(quiet / "remote-launch.py")
a,b = launcher.index("\nc=")+1, launcher.index("\nb=Path(")
launcher = launcher[:a] + "c=" + repr(config) + launcher[b:]
launcher = launcher.replace("['reference','candidate']", "['candidate']").replace("lython-b992-fixtures","lython-b993-fixtures")
launcher = launcher.replace(" payload=sys.stdin", " assert sha(source/'cpython-worker.py')==c['cpythonWorkerSHA256']\n payload=sys.stdin")
write(lab / "remote-launch.py",launcher)
write(lab / "launch.py",read(phase / "launch.py").replace("seconds=160","seconds=265").replace("before160seconds","before 265 seconds").replace("B986 phase diagnostic","B993 representative comparison"))
write(lab / "retrieve.py",read(phase / "retrieve.py").replace("['jobs']==3","['jobs']==4").replace("B986","B993"))
print("Verified all worker files and four-case catalog. Archived-only reclamation", len(retire), "files")
