from pathlib import Path
import gzip, hashlib, json, shutil, subprocess, tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/'comparison/quiet'
dest=repo/'benchmarks/results/2026-11-23-supplied-lexical-call-cpython'
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=repo)
identity=read(quiet/'identity.json')
status=read(quiet/'terminal-status.json')
receipt=status['receipt']
assert not status['live'] and not status['fixtures'] and status['exitCode']=='0'
assert all(receipt[k] for k in ('complete','archivedAndVerifiedUnderLease','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter'))
assert digest(quiet/'observations.tar.xz')==receipt['archiveSHA256']
assert read(quiet/'summary.json')['timedBatches']==56
for version in (identity['candidate'],identity['deliveryRevision'],'origin/master'):
    assert not git('diff','--name-only',identity['sourceRevision'],version,'--','src')
image=lab.parent/'supplied-lexical-call-20261123/candidate'
files=identity['imageFiles']['candidate']
assert len(files)==32 and all(digest(image/name)==value for name,value in files.items())
core=dest.parent/'2026-11-23-supplied-lexical-call/candidate-core.dll.gz'
assert hashlib.sha256(gzip.decompress(core.read_bytes())).hexdigest()==files['Lokad.Lython.dll']
dest.mkdir(exist_ok=True)
assert all(path.name=='README.md' for path in dest.iterdir())
for name in ('observations.tar.xz','identity.json','summary.json','terminal-status.json'):
    shutil.copyfile(quiet/name,dest/name)
with tarfile.open(dest/'procedures.tar.xz','w:xz') as bundle:
    for name in ('archive.py','build-checkpoint.py','prepare.py','quiet.py','comparison/quiet/launch.log',
        'comparison/quiet/observe-not-before','comparison/quiet/candidate-verify.json','comparison/quiet/summarize.py'):
        bundle.add(lab/name,arcname=name)
print(dest)
