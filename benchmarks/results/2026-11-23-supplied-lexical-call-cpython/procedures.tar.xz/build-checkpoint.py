from pathlib import Path

lab=Path(__file__).resolve().parent
original=lab.parent/'supplied-operand-window-cpython-20261123/prepare.py'
source=original.read_text(encoding='utf-8')
pairs=(
    ("donor=lab.parent/'supplied-operand-window-20261123'","donor=lab.parent/'supplied-lexical-call-20261123'"),
    ("tracked='benchmarks/results/2026-11-23-supplied-operand-window/'","tracked='benchmarks/results/2026-11-23-supplied-lexical-call/'"),
    ("name='scripts.ordinary-fully-supplied-helper'","name='scripts.ordinary-fully-supplied-helper.local-function'"),
    ("run='supplied-operand-window-cpython-b1525-20261123-verified'","run='supplied-lexical-call-cpython-b1527-20261123'"),
    ("base='supplied-call-accumulation-b1522-20261123'","base='supplied-operand-window-b1524-20261123'"),
    ("original='supplied-operand-window-b1524-20261123'","original='supplied-lexical-call-b1526-20261123'"),
    ('lython-b1525-fixtures','lython-b1527-fixtures'),
    ('CPython checkpoint after removing the early supplied integer boxes','CPython checkpoint for the lexical supplied integer script'),
    ('lython-b1525-supplied-operand-window-20261123','lython-b1527-supplied-lexical-call-20261123'),
    ('.+b1525-','.+b1527-'),('lython-b1525-stage-','lython-b1527-stage-'),
    ('A 45 MiB','A 40 MiB'),('45 * 1024 * 1024','40 * 1024 * 1024'),
)
for a,b in pairs:
    assert source.count(a)==1,a
    source=source.replace(a,b)
out=lab/'prepare.py'
compile(source,str(out),'exec')
out.write_text(source,encoding='utf-8',newline='\n')
