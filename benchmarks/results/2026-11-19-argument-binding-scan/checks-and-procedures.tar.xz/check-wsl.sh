set -e
cd /mnt/d/code/Lython/.git/agent-worktrees/binding-completion-r657
export PATH="$HOME/.dotnet:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/binding-completion-r657
out="$PWD/tests/artifacts/r657-wsl"
filter='(FullyQualifiedName~NamedFunctionBinding|FullyQualifiedName~FunctionSlotBinding|FullyQualifiedName~DeferredDefinitionBinding|FullyQualifiedName~BindingPlanConstruction|FullyQualifiedName~FunctionDefault|FullyQualifiedName~BoundBoxCleanup|FullyQualifiedName~AsyncMidFlightCancellation|FullyQualifiedName~CallBoundary|FullyQualifiedName~ExecutableFunctionInvocation|FullyQualifiedName~SimpleFunctionExecution|FullyQualifiedName~NativeFunctionRefund|FullyQualifiedName~ArgumentOrder|FullyQualifiedName~ParameterSyntax|FullyQualifiedName~ExtendedCall|FullyQualifiedName~CallExpansion|FullyQualifiedName~MethodBinding|FullyQualifiedName~ComposedNativeCall)&Category!=Stress'
for p in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="$logs/$p-wsl-net10.log"
    dotnet test "tests/$p" -c Release -f net10.0 --artifacts-path "$out" --filter "$filter" > "$log" 2>&1 || (tail -27 "$log"; exit 1)
    tail -5 "$log"
done
