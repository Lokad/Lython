set -e
cd /mnt/d/code/Lython/.git/agent-worktrees/binding-completion-r657
export PATH="$HOME/.dotnet:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/binding-completion-r657
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --artifacts-path "$PWD/tests/artifacts/r657-wsl" --filter 'FullyQualifiedName~NamedFunctionBindingTests&FullyQualifiedName~PartialNamedCalls' > "$logs/suspended-default-wsl-net10.log" 2>&1 || (tail -24 "$logs/suspended-default-wsl-net10.log"; exit 1)
tail -6 "$logs/suspended-default-wsl-net10.log"
