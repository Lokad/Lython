from pathlib import Path
import hashlib,json,os,shutil,subprocess

notes=Path('.git/agent-notes/review-20261031')
lab=notes/'positional-debt-r635'
lab.mkdir(exist_ok=True)
previous=notes/'prepared-definition-text-r611'
current=notes/'detached-cells-confirmation-r631'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p, val:p.write_text(json.dumps(val,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
origins={'reference':(previous,'reference','b491250cb'),
         'candidate':(current,'candidate','43c9f2c38')}
catalog=load(current/'catalog.json')
names=('calls.positional.large','scripts.rule-default-closures','scripts.report-forwarding.expanded')
catalog['cases']=[next(case for case in catalog['cases'] if case['id']==name) for name in names]
old_cases={row['id']:row for row in load(previous/'catalog.json')['cases']}
for case in catalog['cases']:
    assert case==old_cases[case['id']],case['id']
target=lab/'catalog.json'
write(target,catalog)
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
files={}
for label,(donor,direction,retained) in origins.items():
    identity=load(donor/'frozen-identity.json')
    measured=identity[direction+'Commit']
    subprocess.run(['git','diff','--exit-code',measured,retained,'--','src','tests'],check=True)
    source=donor/'frozen'/direction
    frozen=lab/'frozen'/label
    frozen.mkdir(parents=True,exist_ok=True)
    expected=identity['images'][direction]
    assert len(expected)==32 and {name:sha(source/name) for name in expected}==expected
    for name in expected:
        target_file=frozen/name
        if not target_file.exists():shutil.copyfile(source/name,target_file)
    assert {name:sha(frozen/name) for name in expected}==expected
    with (lab/(label+'-verify.log')).open('wb') as log:
        subprocess.run([dotnet,frozen/'Lokad.Lython.Benchmarks.dll','--compare','verify',
            '--catalog',target,'--dotnet',dotnet,'--python','C:/Python313/python.exe',
            '--python-worker',Path.cwd()/'benchmarks/cpython-worker.py','--out',lab/(label+'-verify.json')],
            stdout=log,stderr=subprocess.STDOUT,env=env,check=True,timeout=90)
    result=load(lab/(label+'-verify.json'))
    assert result['state']=='Completed' and result['catalogSha256']==sha(target)
    assert {name:sha(frozen/name) for name in expected}==expected
    files[label]=expected
assert {name:files['reference'][name] for name in files['reference'] if name!='Lokad.Lython.dll'}=={name:files['candidate'][name] for name in files['candidate'] if name!='Lokad.Lython.dll'}
write(lab/'frozen-identity.json',dict(referenceCommit='b491250cb',candidateCommit='43c9f2c38',casesSHA256=sha(target),images=files))
print('Both complete images verify against the unchanged positional, rule and forwarding catalog.')
