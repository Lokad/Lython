import ast
import hashlib
import json
from pathlib import Path
import re
import shutil
import tarfile

lab = Path(__file__).resolve().parent
prior = lab.parent / "detached-cells-confirmation-r631"
previous = prior / "quiet"
quiet = lab / "quiet"
def read(path):
    return path.read_text(encoding="utf-8-sig")
def load(path):
    return json.loads(read(path))
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path, value):
    if path.suffix == ".py":
        ast.parse(value)
    path.write_text(value, encoding="utf-8", newline="\n")
def save(path, value):
    write(path, json.dumps(value, ensure_ascii=False, indent=2) + "\n")

old = load(previous / "config.json")
earlier = load(lab.parent / "prepared-definition-text-r611/quiet/config.json")

donor_archive=load(previous/"archive-receipt.json")
assert donor_archive["complete"] and donor_archive["archivedAndVerifiedUnderLease"]
minimum_headroom = 174 * 1024 * 1024
pair = load(lab / "frozen-identity.json")
catalog = lab / "catalog.json"
images = pair["images"]
source_files = old["identity"]["imageFiles"]["candidate"]
core = "Lokad.Lython.dll"
assert pair["casesSHA256"] == sha(catalog)
for role, files in images.items():
    assert len(files) == 32 and files == source_files | {core: files[core]}
    assert {name: sha(lab / "frozen" / role / name) for name in files} == files
    verified = load(lab / f"{role}-verify.json")
    assert verified["state"] == "Completed" and verified["catalogSha256"] == sha(catalog)

quiet.mkdir(exist_ok=True)
for role in ("candidate",):
    image = quiet / role
    image.mkdir(exist_ok=True)
    assert sha(lab / "frozen" / role / core) == images[role][core]
shutil.copyfile(catalog, quiet / "representative.json")
identity = dict(sourceRevision=pair["referenceCommit"] + " versus " + pair["candidateCommit"],
    purpose="R635 cumulative positional comparison since prepared formatting", imageFiles=images,
    catalogSHA256=sha(catalog), normalAdapterPin="0.4.0",
    coreSHA256={label: images[role][core] for role in images for label in (role, role + "-control")})
save(quiet / "identity.json", identity)

root = "/home/lokad/lython-bench-checks/positional-debt-b1065-20261119"
unit = "lython-b1065-positional-debt-20261119"
for name in ("collect.py", "archive-owned.py", "run.sh", "retrieve.py"):
    source = read(previous / name).replace(old["root"], root)
    source = source.replace("Prepared executable capture sources", "Cumulative positional comparison")
    if name == "collect.py":
        a,b=source.index("\njobs = "),source.index("\nassert len(jobs)")
        jobs = [
            ('calls.positional.large','warm'),('scripts.rule-default-closures','warm'),
            ('scripts.report-forwarding.expanded','compile-run')]
        source=source[:a]+"\njobs = "+repr(jobs)+source[b:]
    source = source.replace("len(jobs)==8","len(jobs)==3").replace("len(raw['jobs'])==8","len(raw['jobs'])==3").replace("jobs=8,","jobs=3,").replace("['jobs']==8","['jobs']==3")
    if name == "archive-owned.py":
        source=source.replace(str(192*1024*1024), str(minimum_headroom))
    write(quiet / name, source)
write(lab / "launch-quiet.py", read(prior / "launch-quiet.py").replace(
    "Prepared executable capture sources", "Cumulative positional comparison").replace("412","177"))
write(lab / "summarize-quiet.py", read(prior / "summarize-quiet.py").replace("==8","==3"))
parts = ["collect.py", "archive-owned.py", "run.sh", "identity.json", "representative.json",
         ]
payload = quiet / "payload.tgz"
with tarfile.open(payload, "w:gz") as archive:
    for part in parts:
        archive.add(quiet / part, arcname=part)
expanded = sum((quiet / part).stat().st_size for part in parts)
archive_headroom = 1024 * 1024 # Three lanes with no new DLL payload.
needed = minimum_headroom + expanded + archive_headroom
space = load(lab / "quiet-space.json")
available = space["freeBytes"]
selected = []
for proof in sorted(space["replicas"], key=lambda item: -item["bytes"]):
    if available > needed + 49152:
        break
    assert proof["committedBlobVerified"]
    available += proof["bytes"]
    selected.append(proof)
save(lab / "preflight.json", dict(available=available, need=needed, withoutRetirement=space["freeBytes"], selected=selected))
assert available > needed, (available, needed)

config = dict(root=root, unit=unit, source=old["root"], sourceRole="candidate",
              sourceFiles=source_files, sourceCatalogSHA256=old["catalogSHA256"],
              catalogSHA256=sha(catalog), identity=identity, retireGroups=selected, donorArchiveSHA256=donor_archive["archiveSHA256"],
              earlierRoot=earlier["root"], payloadBytes=payload.stat().st_size, payloadSHA256=sha(payload), unpackedBytes=expanded)
save(quiet / "config.json", config)
launcher = read(lab.parent / "prepared-compiler-bindings-r627" / "quiet" / "remote-launch.py")
a, b = launcher.index("\nc=") + 1, launcher.index("\nb=Path(")
launcher = launcher[:a] + "c=" + repr(config) + launcher[b:]
launcher = re.sub(r"lython-b[0-9]+-fixtures", "lython-b1065-fixtures", launcher)
launcher = launcher.replace(str(200*1024*1024), str(minimum_headroom)).replace("+2097152,", f"+{archive_headroom},")
launcher = launcher.replace(" payload=sys.stdin", '''
 earlier=Path(c['earlierRoot'])
 assert earlier.parent==b and earlier.resolve()==earlier and not (earlier/'guest-fixtures').exists()
 for name,digest in c['identity']['imageFiles']['reference'].items():
  assert sha(earlier/'reference'/name)==digest,name
 payload=sys.stdin''')
launcher = launcher.replace("if not p.exists():os.link(source/c['sourceRole']/n,p)",
    "if not p.exists():os.link(earlier/'reference'/n if role=='reference' and n=='Lokad.Lython.dll' else source/c['sourceRole']/n,p)")
write(quiet / "remote-launch.py", launcher)
print("Verified both full images and the three-case, three-job plan. Staging headroom", available - needed, "bytes.")
