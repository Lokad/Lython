using System.Text;

namespace Lokad.Lython.Frontend;

internal sealed partial class Parser
{
    /// <summary>Enters one level of syntactic nesting shared by suites and right-recursive expressions.</summary>
    private bool EnterNestingDepth(int tokenIndex)
    {
        if (_nestingDepth >= MaxNestingDepth)
        {
            AddDiagnostic(
                "LA0003",
                SyntaxNestingLimitMessage,
                tokenIndex);
            return false;
        }

        _nestingDepth++;
        return true;
    }

    private void LeaveNestingDepth() => _nestingDepth--;

    /// <summary>Parses a nested operand expression within the shared nesting budget.</summary>
    private ExpressionSyntax? ParseNestedExpression(int tokenIndex)
    {
        if (!EnterNestingDepth(tokenIndex))
        {
            return null;
        }

        try
        {
            return ParseExpression();
        }
        finally
        {
            LeaveNestingDepth();
        }
    }

    private IReadOnlyList<StatementSyntax>? ParseSuite(LythonDiagnosticCode code, string message)
    {
        if (!EnterNestingDepth(_position))
        {
            return null;
        }

        try
        {
            return ParseSuiteCore(code, message);
        }
        finally
        {
            LeaveNestingDepth();
        }
    }

    private IReadOnlyList<StatementSyntax>? ParseSuiteCore(LythonDiagnosticCode code, string message)
    {
        if (TryRead(Token.Eol, out _))
        {
            return ParseIndentedSuite(code, message);
        }

        return ParseSimpleStatementSuite(code);
    }

    private IReadOnlyList<StatementSyntax>? ParseSimpleStatementSuite(LythonDiagnosticCode code)
    {
        var statements = new List<StatementSyntax>();
        while (true)
        {
            var statement = ParseSimpleStatement();
            if (statement is null)
            {
                return null;
            }

            statements.Add(statement);
            while (_pendingStatements.Count != 0)
            {
                statements.Add(_pendingStatements.Dequeue());
            }

            if (CurrentToken != Token.Semicolon)
            {
                break;
            }

            ReadToken();
            if (CurrentToken is Token.Eol or Token.Dedent or Token.End)
            {
                break;
            }
        }

        if (CurrentToken == Token.Eol)
        {
            ReadToken();
            SkipEndOfLines();
            return statements;
        }

        if (CurrentToken is Token.Dedent or Token.End)
        {
            return statements;
        }

        AddDiagnostic(code, "Expected end-of-line after one-line suite.", _position);
        return null;
    }

    private IReadOnlyList<StatementSyntax>? ParseIndentedSuite(LythonDiagnosticCode code, string message)
    {
        if (CurrentToken == Token.Eol)
        {
            AddDiagnostic(code, message, _position);
            return null;
        }

        if (!TryRead(Token.Indent, out _))
        {
            AddDiagnostic(code, message, _position);
            return null;
        }

        var statements = new List<StatementSyntax>();
        SkipEndOfLines();

        StatementSyntax? previousStatement = null;
        var previousEndTokenIndex = 0;
        while (CurrentToken is not Token.Dedent and not Token.End)
        {
            var gapStartTokenIndex = _position;
            var pendingBeforeParse = _pendingStatements.Count;
            var statement = ParseStatement();
            if (statement is null)
            {
                Synchronize();
                previousStatement = null;
            }
            else
            {
                statements.Add(statement);
                if (previousStatement is not null)
                {
                    CheckStatementSeparation(previousStatement.Span, statement.Span, previousEndTokenIndex, gapStartTokenIndex);
                }

                previousStatement = statement;
                previousEndTokenIndex = SeparationGapEnd(previousEndTokenIndex, gapStartTokenIndex, pendingBeforeParse);
            }

            SkipEndOfLines();
        }

        if (statements.Count == 0)
        {
            AddDiagnostic(code, "Expected at least one statement in block.", _position);
            return null;
        }

        if (!TryRead(Token.Dedent, out _))
        {
            AddDiagnostic(code, "Expected dedent after block.", _position);
            return null;
        }

        return statements;
    }

    private void Synchronize()
    {
        if (CurrentToken == Token.Dedent)
        {
            ReadToken();
            return;
        }

        while (CurrentToken is not Token.End and not Token.Eol and not Token.Dedent and not Token.Semicolon)
        {
            ReadToken();
        }
    }

    private void SkipEndOfLines()
    {
        while (CurrentToken is Token.Eol or Token.Semicolon)
        {
            ReadToken();
        }
    }

    private void SkipGroupedExpressionTrivia()
    {
        while (CurrentToken is Token.Eol or Token.Indent or Token.Dedent)
        {
            ReadToken();
        }
    }

    private void SkipGroupedImportTrivia()
    {
        while (CurrentToken is Token.Eol or Token.Indent or Token.Dedent)
        {
            ReadToken();
        }
    }

    private Token CurrentToken => _tokens.Tokens[_position].Token;

    private Token PeekToken(int offset)
        => _position + offset < _tokens.Count ? _tokens.Tokens[_position + offset].Token : Token.End;

    private int ReadToken()
    {
        CheckCancellation(_position);
        return _position++;
    }

    private void CheckCancellation(int position = 0)
    {
        if ((position & 1023) < 4 && _cancellationToken.IsCancellationRequested)
        {
            _memoryGovernor?.ThrowIfAdmissionFailed();
            throw Runtime.RuntimeErrors.Cancelled(null);
        }
    }

    private bool TryRead(Token token, out int tokenIndex)
    {
        if (CurrentToken == token)
        {
            tokenIndex = ReadToken();
            return true;
        }

        tokenIndex = -1;
        return false;
    }

    private bool TryReadNameToken(out int tokenIndex)
    {
        if (IsNameToken(CurrentToken))
        {
            tokenIndex = ReadToken();
            return true;
        }

        tokenIndex = -1;
        return false;
    }

    private bool TryReadMemberName(out int tokenIndex) => TryReadNameToken(out tokenIndex);

    private string IdentifierText(int tokenIndex)
        => MangleIdentifier(RawIdentifierText(tokenIndex));

    private string RawIdentifierText(int tokenIndex)
        => _tokens.GetString(tokenIndex).Normalize(NormalizationForm.FormKC);

    // Mangling belongs to the lexical class, including nested functions. Cache
    // the expanded names so a long class name is shared across repeated uses.
    private sealed class PrivateNameContext(string className, HashSet<string>? selectiveNames = null)
    {
        public string Prefix { get; } = className.TrimStart('_') is { Length: > 0 } name ? "_" + name : string.Empty;
        public HashSet<string>? SelectiveNames { get; } = selectiveNames;
        public Dictionary<string, string> Names { get; } = new(StringComparer.Ordinal);
    }

    private string MangleIdentifier(string name)
    {
        if (_privateNames is not { Prefix.Length: > 0 } context ||
            !name.StartsWith("__", StringComparison.Ordinal) ||
            name.EndsWith("__", StringComparison.Ordinal) || name.Contains('.') ||
            context.SelectiveNames is { } selected && !selected.Contains(name)) return name;
        if (!context.Names.TryGetValue(name, out var mangled))
        {
            var length = (long)context.Prefix.Length + name.Length;
            if (length > int.MaxValue)
                throw Runtime.RuntimeErrors.Attributed("MemoryError", "private name exceeds the string representation", null,
                    LythonFailureReason.ByteBufferCapacityLimit);
            var bytes = checked(128L + 4L * length);
            using var storage = _memoryGovernor?.ReserveTemporary(bytes, null);
            context.Names[name] = mangled = context.Prefix + name;
            storage?.Commit(bytes);
        }
        return mangled;
    }

    // Generic class headers mangle their type parameters, but preserve all
    // other spellings. Collect the complete list before parsing lazy bounds,
    // which may refer to a parameter declared later in the list.
    private HashSet<string> CollectTypeParameterNames()
    {
        var names = new HashSet<string>(StringComparer.Ordinal);
        var depth = 0;
        var expectName = false;
        for (var i = _position; i < _tokens.Count; i++)
        {
            CheckCancellation(i);
            var token = _tokens.Tokens[i].Token;
            if (token is Token.OpenBracket or Token.OpenParen or Token.OpenBrace)
            {
                depth++;
                if (depth == 1) expectName = true;
            }
            else if (token is Token.CloseBracket or Token.CloseParen or Token.CloseBrace)
            {
                if (--depth == 0) break;
            }
            else if (depth == 1 && token == Token.Comma) expectName = true;
            else if (depth == 1 && expectName && IsNameToken(token))
            {
                names.Add(RawIdentifierText(i));
                expectName = false;
            }
        }
        return names;
    }

    private static bool IsNameToken(Token token) => token is Token.Identifier or Token.Match or Token.Case;

    private void ReadExpected(Token token, LythonDiagnosticCode code, string message)
    {
        if (TryRead(token, out _))
        {
            return;
        }

        AddDiagnostic(code, message, _position);
    }

    private void AddDiagnostic(LythonDiagnosticCode code, string message, int tokenIndex)
    {
        var span = tokenIndex >= 0 && tokenIndex < _tokens.Count
            ? SpanOf(tokenIndex)
            : null;

        _diagnostics.Add(new LythonDiagnostic(
            code.Value,
            message,
            LythonDiagnosticSeverity.Error,
            span));
    }

    private void AddDiagnostic(LythonDiagnosticCode code, string message, LythonSourceSpan span)
    {
        _diagnostics.Add(new LythonDiagnostic(
            code.Value,
            message,
            LythonDiagnosticSeverity.Error,
            span));
    }

    private static bool TryGetUnsupportedTrailingExpressionConstruct(Token token, out string construct)
    {
        construct = token switch
        {
            Token.PlusEqual or Token.MinusEqual or Token.StarEqual or Token.SlashEqual or Token.PercentEqual or Token.SlashSlashEqual => "augmented assignment",
            _ => string.Empty
        };

        return construct.Length != 0;
    }

    private bool TryParseUnsupportedStatement(out StatementSyntax? statement)
    {
        if (CurrentToken is Token.From or Token.Del)
        {
            statement = null;
            return false;
        }

        if (!TryGetUnsupportedConstruct(CurrentToken, out var construct))
        {
            statement = null;
            return false;
        }

        var tokenIndex = ReadToken();
        AddDiagnostic("LA2000", $"Unsupported Python construct '{construct}'.", tokenIndex);
        statement = null;
        return true;
    }

    private bool TryParseUnsupportedExpression(out ExpressionSyntax? expression)
    {
        if (CurrentToken == Token.Lambda)
        {
            expression = null;
            return false;
        }

        if (!TryGetUnsupportedConstruct(CurrentToken, out var construct))
        {
            expression = null;
            return false;
        }

        var tokenIndex = ReadToken();
        AddDiagnostic("LA2000", $"Unsupported Python construct '{construct}'.", tokenIndex);
        expression = null;
        return true;
    }

    private bool LooksLikeMatchStatement()
    {
        if (PeekToken(1) is Token.Assign or Token.ColonEqual)
        {
            return false;
        }

        for (var offset = 1; ; offset++)
        {
            CheckCancellation(offset);
            var token = PeekToken(offset);
            switch (token)
            {
                case Token.Eol:
                case Token.End:
                    return false;
                case Token.Assign:
                    return false;
                case Token.Colon:
                    return true;
            }
        }
    }

    private static bool TryGetUnsupportedConstruct(Token token, out string construct)
    {
        construct = token switch
        {
            Token.Elif => "elif",
            Token.With => "with",
            Token.Async => "async",
            Token.Await => "await",
            Token.Lambda => "lambda",
            Token.Del => "del",
            Token.From => "from import",
            Token.At => "decorator",
            _ => string.Empty,
        };

        return construct.Length != 0;
    }

    private LythonSourceSpan SpanOf(int tokenIndex)
    {
        var token = _tokens.Tokens[tokenIndex];
        var start = token.Start + _spanOffset;
        (_spanSourceTokens ?? _tokens).LineOfPosition(start, out var line, out var column);
        return new LythonSourceSpan(start, token.Length, line, column);
    }

    private LythonSourceSpan Merge(int leftTokenIndex, int rightTokenIndex)
    {
        return Merge(SpanOf(leftTokenIndex), SpanOf(rightTokenIndex));
    }

    private LythonSourceSpan Merge(int leftTokenIndex, LythonSourceSpan rightSpan)
    {
        return Merge(SpanOf(leftTokenIndex), rightSpan);
    }

    private static LythonSourceSpan Merge(LythonSourceSpan left, LythonSourceSpan right)
    {
        var start = Math.Min(left.Start, right.Start);
        var end = Math.Max(left.Start + left.Length, right.Start + right.Length);
        var line = left.Start <= right.Start ? left.Line : right.Line;
        var column = left.Start <= right.Start ? left.Column : right.Column;
        return new LythonSourceSpan(start, end - start, line, column);
    }
}
