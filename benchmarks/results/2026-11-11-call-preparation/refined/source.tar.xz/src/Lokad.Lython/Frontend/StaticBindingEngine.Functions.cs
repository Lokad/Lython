using System.Globalization;

namespace Lokad.Lython.Frontend;

internal static partial class StaticBindingEngine
{
    private static bool TryBuildSimpleFunctionSummary(
        FunctionDefinitionStatementSyntax functionDefinition,
        AbstractState bindings,
        [MaybeNullWhen(false)] out AbstractFunctionSummary summary)
    {
        if (functionDefinition.Decorators.Count != 0 ||
            functionDefinition.ParameterLayout.VariadicListIndex >= 0 ||
            functionDefinition.ParameterLayout.VariadicDictionaryIndex >= 0 ||
            ScopeDirectiveFactsCollector.ContainsScopeDirective(functionDefinition.Body) ||
            !IsStraightLineSummaryBody(functionDefinition.Body))
        {
            summary = default;
            return false;
        }

        var capturedBindings = bindings.CloneForDeferredBody();
        capturedBindings.Remove(functionDefinition.Name);
        // Type parameters belong to the function's annotation scope, not to
        // a same-named value inferred in the defining module or outer function.
        if (functionDefinition.TypeParameters is { } typeParameters)
            foreach (var typeParameter in typeParameters) capturedBindings.Remove(typeParameter.Name);
        summary = new AbstractFunctionSummary(functionDefinition, capturedBindings);
        return true;
    }

    private static bool IsStraightLineSummaryBody(IReadOnlyList<StatementSyntax> statements)
        => IsStraightLineSummaryBody(statements, out var hasReturn) && hasReturn;

    private static bool IsStraightLineSummaryBody(IReadOnlyList<StatementSyntax> statements, out bool hasReturn)
    {
        hasReturn = false;
        foreach (var statement in statements)
        {
            switch (statement)
            {
                case AssignmentStatementSyntax:
                case ChainedAssignmentStatementSyntax:
                case AnnotatedAssignmentStatementSyntax:
                case ExpressionStatementSyntax:
                case PassStatementSyntax:
                    break;

                case WithStatementSyntax withStatement:
                    if (!IsStraightLineSummaryBody(withStatement.Body, out var withHasReturn))
                    {
                        return false;
                    }

                    hasReturn |= withHasReturn;
                    break;

                case IfStatementSyntax ifStatement:
                    if (!IsStraightLineSummaryBody(ifStatement.ThenStatements, out var thenHasReturn))
                    {
                        return false;
                    }

                    if (ifStatement.ElseStatements is not null)
                    {
                        if (!IsStraightLineSummaryBody(ifStatement.ElseStatements, out var elseHasReturn))
                        {
                            return false;
                        }

                        hasReturn |= thenHasReturn && elseHasReturn;
                    }
                    else
                    {
                        hasReturn |= thenHasReturn;
                    }
                    break;

                case ReturnStatementSyntax:
                    hasReturn = true;
                    break;

                default:
                    return false;
            }
        }

        return true;
    }

    private static bool TryGetParameterCallShapeFailure(
        AbstractFunctionSummary summary,
        int firstParameterIndex,
        ConcreteCallArguments arguments,
        out string reason,
        out ExpressionSyntax? offendingExpression)
    {
        var parameters = summary.Parameters;
        var layout = summary.ParameterLayout;
        if (layout.VariadicListIndex >= 0 || layout.VariadicDictionaryIndex >= 0)
        {
            reason = string.Empty;
            offendingExpression = null;
            return false;
        }

        if (firstParameterIndex > parameters.Count)
        {
            reason = "method has no receiver parameter";
            offendingExpression = null;
            return true;
        }

        var effectiveParameterCount = parameters.Count - firstParameterIndex;
        Span<bool> assigned = effectiveParameterCount <= 128
            ? stackalloc bool[effectiveParameterCount]
            : new bool[effectiveParameterCount];
        var positionalParameterCount = Math.Max(0, layout.PositionalCount - firstParameterIndex);
        if (arguments.Positional.Count > positionalParameterCount)
        {
            reason = "too many positional arguments";
            offendingExpression = null;
            return true;
        }

        assigned[..arguments.Positional.Count].Fill(true);
        foreach (var (keyword, expression) in arguments.Keywords)
        {
            if (!layout.LayoutParameterIndex.TryGetValue(keyword, out var parameterIndex) ||
                parameterIndex < firstParameterIndex || parameterIndex < layout.PositionalOnlyCount ||
                parameterIndex >= layout.NamedLayoutCount)
            {
                reason = $"unexpected keyword '{keyword}'";
                offendingExpression = expression;
                return true;
            }

            var effectiveIndex = parameterIndex - firstParameterIndex;
            if (assigned[effectiveIndex])
            {
                reason = $"duplicate binding for '{keyword}'";
                offendingExpression = expression;
                return true;
            }

            assigned[effectiveIndex] = true;
        }

        for (var parameterIndex = firstParameterIndex; parameterIndex < parameters.Count; parameterIndex++)
        {
            var parameter = parameters[parameterIndex];
            if (parameter.DefaultValue is null && !assigned[parameterIndex - firstParameterIndex])
            {
                reason = $"missing required argument '{parameter.Name}'";
                offendingExpression = null;
                return true;
            }
        }

        reason = string.Empty;
        offendingExpression = null;
        return false;
    }

    private static bool TryBindFunctionArguments(
        AbstractFunctionSummary summary,
        ConcreteCallArguments arguments,
        AbstractState callBindings,
        out AbstractState functionBindings)
        => TryBindParameterArguments(summary, firstParameterIndex: 0, receiver: null, arguments, callBindings, out functionBindings);

    private static bool TryBindInstanceMethodArguments(
        AbstractFunctionSummary summary,
        AbstractValue selfValue,
        ConcreteCallArguments arguments,
        AbstractState callBindings,
        out AbstractState methodBindings)
        => TryBindParameterArguments(summary, firstParameterIndex: 1, selfValue, arguments, callBindings, out methodBindings);

    private static bool TryBindParameterArguments(
        AbstractFunctionSummary summary,
        int firstParameterIndex,
        AbstractValue? receiver,
        ConcreteCallArguments arguments,
        AbstractState callBindings,
        out AbstractState parameterBindings)
    {
        parameterBindings = summary.CapturedBindings.Clone();
        if (firstParameterIndex > summary.Parameters.Count)
        {
            return false;
        }

        if (receiver.HasValue)
        {
            if (firstParameterIndex != 1 ||
                summary.Parameters.Count == 0 ||
                summary.Parameters[0].Kind is not (FunctionParameterKind.Positional or FunctionParameterKind.PositionalOnly))
            {
                return false;
            }

            parameterBindings.Set(summary.Parameters[0].Name, receiver.Value.WithSpan(summary.Span));
        }

        var consumedKeywordCount = 0;
        var positionalIndex = 0;

        for (var parameterIndex = firstParameterIndex; parameterIndex < summary.Parameters.Count; parameterIndex++)
        {
            var parameter = summary.Parameters[parameterIndex];
            if (parameter.Kind == FunctionParameterKind.KeywordOnly)
            {
                if (parameter.Kind != FunctionParameterKind.PositionalOnly && arguments.Keywords.ContainsKey(parameter.Name))
                {
                    consumedKeywordCount++;
                    parameterBindings.Set(parameter.Name, arguments.ResolveKeywordValue(parameter.Name, callBindings));
                }
                else if (parameter.DefaultValue is not null)
                {
                    parameterBindings.Set(parameter.Name, ResolveArgumentValue(parameter.DefaultValue, summary.CapturedBindings));
                }
                else
                {
                    return false;
                }

                continue;
            }

            if (parameter.Kind is not (FunctionParameterKind.Positional or FunctionParameterKind.PositionalOnly))
            {
                return false;
            }

            if (positionalIndex < arguments.Positional.Count)
            {
                if (parameter.Kind != FunctionParameterKind.PositionalOnly && arguments.Keywords.ContainsKey(parameter.Name))
                {
                    return false;
                }

                parameterBindings.Set(parameter.Name, arguments.ResolvePositionalValue(positionalIndex, callBindings));
                positionalIndex++;
            }
            else if (parameter.Kind != FunctionParameterKind.PositionalOnly && arguments.Keywords.ContainsKey(parameter.Name))
            {
                consumedKeywordCount++;
                parameterBindings.Set(parameter.Name, arguments.ResolveKeywordValue(parameter.Name, callBindings));
            }
            else if (parameter.DefaultValue is not null)
            {
                parameterBindings.Set(parameter.Name, ResolveArgumentValue(parameter.DefaultValue, summary.CapturedBindings));
            }
            else
            {
                return false;
            }
        }

        return positionalIndex == arguments.Positional.Count && consumedKeywordCount == arguments.Keywords.Count;
    }

    private static AbstractValue ResolveArgumentValue(ExpressionSyntax expression, AbstractState bindings)
        => StaticAbstractValueResolver.ResolveOrUnknown(expression, bindings);

    private static bool TryInferStraightLineReturn(
        IReadOnlyList<StatementSyntax> statements,
        AbstractState bindings,
        out AbstractValue returnValue)
    {
        // This deliberately stops at unsupported control flow instead of guessing. For an if statement,
        // a returning branch is removed from the continuation state while two returning branches join values.
        foreach (var statement in statements)
        {
            switch (statement)
            {
                case AssignmentStatementSyntax assignment:
                    UpdateBinding(assignment.Name, assignment.Expression, bindings);
                    break;

                case ChainedAssignmentStatementSyntax chained:
                    foreach (var target in chained.Targets)
                    {
                        if (target is NameAssignmentTargetSyntax nameTarget)
                        {
                            UpdateBinding(nameTarget.Name, chained.Expression, bindings);
                        }
                    }
                    break;

                case AnnotatedAssignmentStatementSyntax annotated when annotated.Expression is not null:
                    UpdateAnnotatedTargetBinding(annotated.Target, annotated.Expression, bindings);
                    break;

                case ExpressionStatementSyntax:
                case PassStatementSyntax:
                    break;

                case WithStatementSyntax withStatement:
                    {
                        var withBindings = bindings.Clone();
                        foreach (var name in withStatement.BoundNames) withBindings.Remove(name);
                        if (withStatement.VariableName is not null &&
                            StaticAbstractValueResolver.TryResolve(withStatement.ContextExpression, bindings, out var contextValue) &&
                            contextValue.Kind is AbstractValueKind.TextFileHandle or AbstractValueKind.BinaryFileHandle or AbstractValueKind.StringIO or AbstractValueKind.BytesIO)
                        {
                            withBindings.Set(withStatement.VariableName, contextValue);
                        }

                        if (TryInferStraightLineReturn(withStatement.Body, withBindings, out returnValue))
                        {
                            return true;
                        }

                        bindings.ReplaceWith(withBindings);
                        foreach (var name in withStatement.BoundNames) bindings.Remove(name);

                        break;
                    }

                case IfStatementSyntax ifStatement:
                    {
                        var thenBindings = bindings.Clone();
                        StaticConditionRefinements.Apply(ifStatement.Condition, assumedTruth: true, thenBindings);
                        var thenReturned = TryInferStraightLineReturn(ifStatement.ThenStatements, thenBindings, out var thenReturnValue);
                        var elseBindings = bindings.Clone();
                        StaticConditionRefinements.Apply(ifStatement.Condition, assumedTruth: false, elseBindings);
                        AbstractValue elseReturnValue = default;
                        var elseReturned = ifStatement.ElseStatements is not null &&
                                           TryInferStraightLineReturn(ifStatement.ElseStatements, elseBindings, out elseReturnValue);

                        if (thenReturned && elseReturned)
                        {
                            returnValue = AbstractValue.Join(thenReturnValue, elseReturnValue, statement.Span);
                            return true;
                        }

                        if (thenReturned)
                        {
                            bindings.ReplaceWith(elseBindings);
                        }
                        else if (elseReturned)
                        {
                            bindings.ReplaceWith(thenBindings);
                        }
                        else
                        {
                            bindings.MergeFrom(thenBindings, elseBindings);
                        }

                        break;
                    }

                case ReturnStatementSyntax { Expression: null }:
                    returnValue = AbstractValue.None(statement.Span);
                    return true;

                case ReturnStatementSyntax { Expression: var expression }:
                    return StaticAbstractValueResolver.TryResolve(expression, bindings, out returnValue);

                default:
                    returnValue = default;
                    return false;
            }
        }

        returnValue = default;
        return false;
    }

}
