using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    private static void InitializeModuleAnnotations(LythonSourceSpan? span, ExecutionContext context)
    {
        if (span is null || context.Variables.ContainsKey("__annotations__")) return;
        var annotations = new PyDict(context.MemoryGovernor, span);
        if (context.GlobalNamespace is not null) StoreGlobalNamespaceName(context, "__annotations__", annotations);
        else context.Variables["__annotations__"] = annotations;
    }

    private static async ValueTask StoreVariableAnnotationAsync(LoweredAnnotatedAssignmentStatement statement,
        ExecutionContext context, bool asynchronous)
    {
        if (context.ParentContext is not null && !context.IsClassBody) return;
        if (context.PostponedAnnotations && !statement.Assignment.IsSimple) return;
        var annotation = context.PostponedAnnotations ? CreatePostponedAnnotationValue(statement.Annotation.Syntax, context)
            : await EvaluateTypeExpressionAsync(statement.Annotation, context, asynchronous).ConfigureAwait(false);
        if (!statement.Assignment.IsSimple || statement.Assignment.Target is not NameAssignmentTargetSyntax name) return;
        // Annotation stores use LOAD_NAME semantics, even when the class body
        // declares __annotations__ global/nonlocal. The implicit lookup checks
        // the class mapping, then module globals; it does not capture a closure.
        var annotations = context.IsClassBody
            ? context.Variables.TryGetValue("__annotations__", out var localAnnotations) ? localAnnotations
                : ResolveName("__annotations__", statement.Span, GetGlobalContext(context))
            : ResolveName("__annotations__", statement.Span, context);
        await StoreAnnotationEntryAsync(annotations, name.Name, annotation, context, statement.Span, asynchronous).ConfigureAwait(false);
    }

    private static PyString CreatePostponedAnnotationValue(ExpressionSyntax expression, ExecutionContext context)
    {
        var text = expression.PostponedAnnotationText ?? throw RuntimeErrors.Runtime("Postponed annotation metadata is unavailable.", expression.Span);
        var result = PyString.FromString(text, context.MemoryGovernor, expression.Span);
        context.CheckExecution(expression.Span);
        return result;
    }

    private static async ValueTask StoreAnnotationEntryAsync(object annotations, string name, object annotation,
        ExecutionContext context, LythonSourceSpan span, bool asynchronous)
    {
        var key = PyString.FromString(name, context.MemoryGovernor, span);
        context.CheckExecution(span);
        if (annotations is PyDict dictionary && !dictionary.ContainsKey(key))
            { _ = dictionary.Count + 1; context.CheckExecution(span); }
        if (asynchronous)
            await SetHeaderSubscriptAsync(annotations, key, annotation, span, context).ConfigureAwait(false);
        else SetSubscriptValue(annotations, key, annotation, span, context);
    }

    private static async ValueTask EvaluateAnnotationTargetReadsAsync(LoweredAnnotatedAssignmentStatement statement,
        ExecutionContext context, bool asynchronous)
    {
        foreach (var read in statement.Target.Reads.Values)
            await EvaluateTypeExpressionAsync(read, context, asynchronous).ConfigureAwait(false);
    }
}
