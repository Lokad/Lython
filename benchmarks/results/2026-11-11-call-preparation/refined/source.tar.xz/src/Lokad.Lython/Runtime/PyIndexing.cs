using System.Numerics;
using Lokad.Lython.Runtime.Numbers;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal static class PyIndexing
{
    // Names the receiver for index-type failures like CPython; Unnamed keeps
    // the legacy context-free text where no receiver shape is known.
    internal enum IndexTargetName
    {
        Unnamed,
        List,
        Tuple,
        Text,
        Sequence,
        Byte,
    }

    // Distinguishes reads from deletions and stores because out-of-range
    // failures name the operation like CPython.
    internal enum IndexOperation
    {
        Read,
        Delete,
        Assign,
    }

    public readonly record struct SliceBounds(int Start, int End, int Step)
    {
        public int Count => Step > 0
            ? Start >= End ? 0 : (int)(1L + ((long)End - 1 - Start) / Step)
            : Start <= End ? 0 : (int)(1L + ((long)Start - 1 - End) / -(long)Step);

        public IEnumerable<int> Indices()
        {
            if (Step > 0)
            {
                for (long i = Start; i < End; i += Step)
                {
                    yield return (int)i;
                }
            }
            else
            {
                for (long i = Start; i > End; i += Step)
                {
                    yield return (int)i;
                }
            }
        }

        public bool Contains(int index)
        {
            if (Step > 0)
            {
                return index >= Start && index < End && (index - (long)Start) % Step == 0;
            }

            return index <= Start && index > End && ((long)Start - index) % -(long)Step == 0;
        }
    }

    public static object ReadIndex(object target, object index, LythonSourceSpan span, LythonRuntime.ExecutionContext? context = null)
    {
        if (target is PyDict dict) return ReadDictIndex(dict, index, span, context);

        // Other structural operations still observe ambient provenance.
        using var _ambientScope = context is null
            ? default(PyStructuralGuard.AmbientScope)
            : PyStructuralGuard.PushAmbient(context, span);
        if (context is not null && target is LythonRuntime.ElementTreeModule.Element element)
            return LythonRuntime.ElementTreeModule.ReadIndexAsync(element, index, context, span, false).GetAwaiter().GetResult();
        // Keyed lookups resolve first like CPython, so slice objects serve
        // as dictionary keys instead of slicing the mapping.
        if (target is LythonRuntime.ReMatchObject match)
        {
            return LythonRuntime.ReMatchMembers.GetSubscript(match, index, span, context);
        }

        if (target is PyCounter counter)
        {
            return ReadCounterIndex(counter, index, span);
        }

        // ChainMaps resolve every key through the mapped lookup like CPython,
        // so slice objects serve as keys instead of slicing the mapping. The
        // contextful read invokes defaultdict factories (storing the result)
        // where plain misses continue.
        if (target is PyChainMap chainMap)
        {
            return context is null
                ? chainMap.GetSubscript(index, span)
                : chainMap.GetSubscript(index, span, context);
        }

        if (target is PyDataclassInitVarMarker initVar)
            return initVar.GetSubscript(index, span, context ?? PyStructuralGuard.AmbientContext);

        if (context is not null && target is PyType type)
            return LythonRuntime.ReadTypeSubscriptAsync(type, index, context, span, false).GetAwaiter().GetResult();

        if (index is PySlice slice)
        {
            return ReadSlice(target, slice.StartBound, slice.StopBound, slice.StepBound, span, context);
        }

        if (context is not null && target is INamedRuntimeCallable named && named.Name is "list" or "tuple" or "dict" or "set" or "type")
        {
            var alias = LythonRuntime.CreateGenericSubscriptAsync(target, index, context, span, false).GetAwaiter().GetResult();
            return alias;
        }
        return target switch
        {
            IPySubscriptableValue value => value.GetSubscript(index, span),
            IPyIndexableValue value => value.GetIndex(NormalizeIndex(index, value.Length, span, TargetKind(value))),
            _ when PyStringOps.TryAsString(target, out var text) => text.Index(NormalizeIndex(index, text.Length, span, IndexTargetName.Text)),
            _ => throw RuntimeErrors.NotSubscriptable(span)
        };
    }

    // Guest-visible colon keys keep raw bounds, like explicit slice() calls.
    // Fund the actual key before exposing it to a user or mapping; its storage
    // remains charged to the execution owner, including escaped aliases.
    internal static PySlice CreateMappingSliceKey(object? start, object? end, object? step, LythonRuntime.ExecutionContext? context, LythonSourceSpan span)
    {
        context?.MemoryGovernor.Reserve(64L, span);
        context?.MemoryGovernor.Commit(64L);
        var value = new PySlice(start ?? PyNone.Instance, end ?? PyNone.Instance, step ?? PyNone.Instance);
        return value;
    }

    public static object ReadSlice(object target, object? start, object? end, object? step, LythonSourceSpan span, LythonRuntime.ExecutionContext? context = null)
    {
        if (context is not null && target is PyType type)
            return LythonRuntime.ReadTypeSubscriptAsync(type, CreateMappingSliceKey(start, end, step, context, span), context, span, false).GetAwaiter().GetResult();

        if (context is not null && target is LythonRuntime.ElementTreeModule.Element element)
            return LythonRuntime.ElementTreeModule.ReadSliceAsync(element, start, end, step, context, span, false).GetAwaiter().GetResult();
        if (target is LythonRuntime.ReMatchObject)
        {
            throw new LythonRuntimeException("IndexError", "no such group", span);
        }

        // Mappings resolve colon slices as keys like CPython, ahead of any
        // bound coercion or sequence slicing.
        if (target is PyDict || target is PyCounter || target is PyDefaultDict || target is PyChainMap)
        {
            var key = CreateMappingSliceKey(start, end, step, context, span);
            if (target is PyDict dict)
            {
                return ReadDictIndex(dict, key, span, context);
            }

            if (target is PyCounter counter)
            {
                return ReadCounterIndex(counter, key, span);
            }

            if (target is PyChainMap chainMap)
            {
                return context is null
                    ? chainMap.GetSubscript(key, span)
                    : chainMap.GetSubscript(key, span, context);
            }

            var defaultDict = (PyDefaultDict)target;
            if (context is not null)
            {
                return defaultDict.GetOrCreate(LythonRuntime.ValidateDictionaryKey(key, span), context, span);
            }

            if (defaultDict.TryGetValue(LythonRuntime.ValidateDictionaryKey(key, span), out var value))
            {
                return value;
            }

            throw RuntimeErrors.MissingKey(key, span);
        }

        // Native sequences validate integer bounds. Other slice protocols
        // (for example worksheet cell ranges) receive their own raw keys.
        if (context is not null && IsNativeSliceTarget(target))
        {
            (start, end, step) = CoerceSliceBounds(start, end, step, context, span);
        }

        return ReadSliceCore(target, start, end, step, span, context);
    }

    internal static bool IsNativeSliceTarget(object target)
        => target is not PyDeque && (target is IPyIndexableValue || target is PyRange || PyStringOps.TryAsString(target, out _));

    internal static object ReadSliceCore(object target, object? start, object? end, object? step,
        LythonSourceSpan span, LythonRuntime.ExecutionContext? context)
    {
        var result = target switch
        {
            PyDeque => throw new LythonRuntimeException("TypeError", "sequence index must be integer, not 'slice'", span),
            PyBytes bytes when context is not null => bytes.Slice(NormalizeSliceBounds(bytes.Length, start, end, step, span), context, span),
            IPySliceableValue value => value.GetSlice(start, end, step, span),
            IPyIndexableValue value => value.GetSlice(SliceIndices(value.Length, start, end, step, span)),
            _ when PyStringOps.TryAsString(target, out var text) => text.Slice(NormalizeSliceBounds(text.Length, start, end, step, span)),
            _ => throw RuntimeErrors.NotSliceable(span)
        };

        // String slices built from unowned receivers would escape accounting.
        if (context is not null && result is PyString textResult && target is PyString receiver)
        {
            result = LythonRuntime.OwnMethodResult(textResult,receiver,context.MemoryGovernor,span);
        }

        return result;
    }

    internal static (object? Start, object? End, object? Step) CoerceSliceBounds(
        object? start, object? end, object? step, LythonRuntime.ExecutionContext context, LythonSourceSpan span)
        => LythonRuntime.CoerceSliceBoundsAsync(start, end, step, context, span, false).GetAwaiter().GetResult();

    public static int NormalizeIndex(object? index, int length, LythonSourceSpan span)
        => NormalizeIndex(index, length, span, IndexTargetName.Unnamed);

    public static int NormalizeIndex(object? index, int length, LythonSourceSpan span, IndexTargetName target)
        => NormalizeIndex(index, length, span, target, IndexOperation.Read);

    public static int NormalizeIndex(object? index, int length, LythonSourceSpan span, IndexTargetName target, IndexOperation operation)
    {
        if (index is null || !PyNumberOps.TryAsInteger(index, out var integer))
        {
            throw InvalidIndexType(index, target, span);
        }

        return ApplyIndexBounds(integer, length, span, target, operation);
    }

    public static int NormalizePopIndex(object? index, int length, LythonSourceSpan span)
    {
        if (index is null || !PyNumberOps.TryAsInteger(index, out var integer))
        {
            throw new LythonRuntimeException("TypeError", $"'{IndexTypeName(index)}' object cannot be interpreted as an integer", span);
        }

        if (integer < int.MinValue || integer > int.MaxValue)
        {
            throw new LythonRuntimeException("OverflowError", "Python int too large to convert to C ssize_t", span);
        }

        var position = (int)integer;
        if (position < 0)
        {
            position += length;
        }

        if (position < 0 || position >= length)
        {
            throw new LythonRuntimeException("IndexError", "pop index out of range", span);
        }

        return position;
    }

    internal static IndexTargetName TargetKind(object target) => target switch
    {
        PyString => IndexTargetName.Text,
        PyList => IndexTargetName.List,
        _ when PyTupleLike.TryGetItems(target, out _) => IndexTargetName.Tuple,
        PyDeque => IndexTargetName.Sequence,
        PyBytes => IndexTargetName.Byte,
        _ => IndexTargetName.Unnamed,
    };

    private static int ApplyIndexBounds(BigInteger integer, int length, LythonSourceSpan span, IndexTargetName target, IndexOperation operation)
    {
        if (integer < int.MinValue || integer > int.MaxValue)
        {
            if (target == IndexTargetName.Unnamed)
            {
                throw new LythonRuntimeException("IndexError", "Index is out of range.", span);
            }

            throw new LythonRuntimeException("IndexError", "cannot fit 'int' into an index-sized integer", span);
        }

        var position = (int)integer;
        if (position < 0)
        {
            position += length;
        }

        if (position < 0 || position >= length)
        {
            throw OutOfRange(target, operation, span);
        }

        return position;
    }

    private static LythonRuntimeException OutOfRange(IndexTargetName target, IndexOperation operation, LythonSourceSpan span)
    {
        if (target == IndexTargetName.Unnamed)
        {
            return new LythonRuntimeException("IndexError", "Index is out of range.", span);
        }

        if (target == IndexTargetName.Byte && operation == IndexOperation.Read)
        {
            return new LythonRuntimeException("IndexError", "index out of range", span);
        }

        var name = target switch
        {
            IndexTargetName.List => "list",
            IndexTargetName.Tuple => "tuple",
            IndexTargetName.Text => "string",
            IndexTargetName.Byte => "byte",
            _ => "deque",
        };

        // Deque never names the operation; lists and tuples name stores.
        var message = operation == IndexOperation.Read || target == IndexTargetName.Sequence
            ? $"{name} index out of range"
            : $"{name} assignment index out of range";

        return new LythonRuntimeException("IndexError", message, span);
    }

    private static LythonRuntimeException InvalidIndexType(object? index, IndexTargetName target, LythonSourceSpan span)
    {
        var name = IndexTypeName(index);
        var message = target switch
        {
            IndexTargetName.List => $"list indices must be integers or slices, not {name}",
            IndexTargetName.Tuple => $"tuple indices must be integers or slices, not {name}",
            IndexTargetName.Text => $"string indices must be integers, not '{name}'",
            IndexTargetName.Sequence => $"sequence index must be integer, not '{name}'",
            IndexTargetName.Byte => $"byte indices must be integers or slices, not {name}",
            _ => "Indices must be integers.",
        };

        return RuntimeErrors.Type(message, span);
    }

    // Names mirror the shared operand namer except where sequence indexing
    // has its own shape; anything unlisted (callables, modules, mappings with
    // dotted names, exotic values) resolves through that helper.
    private static string IndexTypeName(object? index) => index switch
    {
        null => "NoneType",
        PyNone => "NoneType",
        PyString => "str",
        double => "float",
        _ when Numbers.PyNumberOps.IsInteger(index) => "int",
        PyList => "list",
        PyDict => "dict",
        PyCounter => "Counter",
        PyDefaultDict => "collections.defaultdict",
        PyTuple => "tuple",
        PySet => "set",
        PyBytes => "bytes",
        PyRange => "range",
        PySlice => "slice",
        PyDeque => "collections.deque",
        PyChainMap => "ChainMap",
        PyInstance instance => instance.Type.Name,
        _ => RuntimeErrors.OperandTypeName(index),
    };

    public static IEnumerable<int> SliceIndices(int length, object? start, object? end, object? step, LythonSourceSpan span)
        => NormalizeSliceBounds(length, start, end, step, span).Indices();

    public static SliceBounds NormalizeSliceBounds(int length, object? start, object? end, object? step, LythonSourceSpan span)
    {
        var bounds = NormalizeSliceIndices(length, start, end, step, span);
        // Real backing indices fit Int32. A larger stride still selects its
        // first element; saturation preserves that traversal without changing
        // the exact step returned by the metadata-only indices operation.
        return new SliceBounds((int)bounds.Start, (int)bounds.Stop,
            (int)BigInteger.Clamp(bounds.Step, int.MinValue, int.MaxValue));
    }

    internal static (BigInteger Start, BigInteger Stop, BigInteger Step) NormalizeSliceIndices(
        BigInteger length, object? start, object? stop, object? step, LythonSourceSpan span)
    {
        var stride = NormalizeSliceBound(step, span) ?? BigInteger.One;
        if (stride.IsZero) throw RuntimeErrors.Value("slice step cannot be zero", span);
        var backwards = stride.Sign < 0;
        var lower = backwards ? BigInteger.MinusOne : BigInteger.Zero;
        var upper = backwards ? length - 1 : length;
        return (AdjustSliceBound(length, NormalizeSliceBound(start, span), lower, upper, backwards ? upper : lower),
            AdjustSliceBound(length, NormalizeSliceBound(stop, span), lower, upper, backwards ? lower : upper), stride);
    }

    private static BigInteger AdjustSliceBound(BigInteger length, BigInteger? bound,
        BigInteger lower, BigInteger upper, BigInteger defaultValue)
    {
        if (bound is not { } value) return defaultValue;
        if (value.Sign < 0)
        {
            // Saturate before addition so a huge bound on a small real
            // container does not need another huge temporary magnitude.
            if (value < -length) return lower;
            value += length;
        }
        return BigInteger.Clamp(value, lower, upper);
    }

    private static object ReadDictIndex(PyDict dict, object index, LythonSourceSpan span, LythonRuntime.ExecutionContext? context)
    {
        var key = LythonRuntime.ValidateDictionaryKey(index, span);
        var found = context is null ? dict.TryGetValue(key, out var value)
            : dict.TryGetValue(key, out value, context, span);
        if (!found)
        {
            throw RuntimeErrors.MissingKey(index, span);
        }

        return value!;
    }

    private static object ReadCounterIndex(PyCounter counter, object index, LythonSourceSpan span)
    {
        var key = LythonRuntime.ValidateDictionaryKey(index, span);
        return counter.GetCount(key);
    }

    internal static BigInteger? NormalizeSliceBound(object? value, LythonSourceSpan span)
    {
        return value switch
        {
            null => null,
            PyNone _ => null,
            _ when PyNumberOps.TryAsInteger(value, out var integer) => integer,
            _ => throw RuntimeErrors.Type("slice indices must be integers or None or have an __index__ method", span)
        };
    }

}
