using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    private readonly record struct TypeScope(ExecutionContext Annotations, ExecutionContext Closure, PyTuple Parameters);

    private static ExecutionContext CreateAnnotationScope(ExecutionContext parent, int names, LythonSourceSpan span)
    {
        var bytes = checked(512L + 96L * names);
        parent.MemoryGovernor.Reserve(bytes, span);
        parent.MemoryGovernor.Commit(bytes);
        var scope = new ExecutionContext(parent) { IsAnnotationScope = true, IsTypeParameterScope = names != 0 };
        RetainLocalsForLambda(parent);
        return scope;
    }

    private static TypeScope CreateTypeScope(IReadOnlyList<LoweredTypeParameter>? parameters, ExecutionContext context, LythonSourceSpan span, bool alias = false)
    {
        if (parameters is null && !alias) return new(context, context, PyTuple.Empty);
        var scope = CreateAnnotationScope(context, parameters?.Count ?? 0, span);
        if (context.IsClassBody) context.AnnotationClassNamespace ??= context.Variables;
        var closure = ReferenceEquals(context.FunctionClosureContext, context) ? scope
            : CreateAnnotationScope(context.FunctionClosureContext, parameters?.Count ?? 0, span);
        using var scratch = context.MemoryGovernor.ReserveTemporary(EstimateObjectArrayBytes(parameters?.Count ?? 0), span);
        var values = new object[parameters?.Count ?? 0];
        for (var i = 0; i < values.Length; i++)
        {
            var parameter = parameters![i];
            var boundSyntax = parameter.Syntax.Bound;
            while (boundSyntax is ParenthesizedExpressionSyntax parenthesized) boundSyntax = parenthesized.Inner;
            var variable = new PyTypeParameter(parameter.Syntax.DeclaredName, parameter.Syntax.Kind,
                parameter.Syntax.Kind != TypeParameterKind.TypeVarTuple,
                parameter.Bound is null ? null : new(parameter.Bound, scope), boundSyntax is TupleLiteralExpressionSyntax,
                parameter.Default is null ? null : new(parameter.Default, scope), parameter.Syntax.UnpackDefault, context, parameter.Syntax.Span);
            values[i] = variable;
            scope.Variables[parameter.Syntax.Name] = variable;
            if (!ReferenceEquals(scope, closure)) closure.Variables[parameter.Syntax.Name] = variable;
        }
        var tuple = values.Length == 0 ? PyTuple.Empty : new PyTuple(values, context.MemoryGovernor, span);
        return new(scope, closure, tuple);
    }

    private static bool HasTypeParameterScope(ExecutionContext context)
    {
        for (var current = context; current is not null; current = current.ParentContext)
            if (current.IsTypeParameterScope) return true;
        return false;
    }

    private static void ExecuteTypeAlias(LoweredTypeAliasStatement alias, ExecutionContext context)
    {
        var scope = CreateTypeScope(alias.TypeParameters, context, alias.Span, alias: true);
        StoreName(alias.Syntax.Name, new PyTypeAlias(alias.Syntax.DeclaredName, scope.Parameters, alias.Value, scope.Annotations, alias.Span), context, alias.Span);
    }

    internal static ValueTask<object> EvaluateTypeExpressionAsync(LoweredExpression expression, ExecutionContext context, bool asynchronous)
        => asynchronous ? EvaluateLoweredExpressionAsync(expression, context) : new(EvaluateLoweredExpression(expression, context));

    internal static async ValueTask<object> CreateGenericSubscriptAsync(object origin, object index, ExecutionContext context,
        LythonSourceSpan span, bool asynchronous)
    {
        if (origin is not PyType type || !type.TryGetMember("__type_params__", out var raw) || raw is not PyTuple parameters)
            return PyGenericAlias.Create(origin,index,context.MemoryGovernor,span);
        if (parameters.Count(parameter => parameter is PyTypeParameter { Kind: TypeParameterKind.TypeVarTuple }) > 1)
            throw new LythonRuntimeException("TypeError", "More than one TypeVarTuple parameter in generic class", span);
        var arguments = index is PyTuple tuple ? tuple : new PyTuple([index], context.MemoryGovernor, span);
        var values = new PyList([], context.MemoryGovernor, span);
        var offset = 0;
        for (var parameterIndex = 0; parameterIndex < parameters.Count; parameterIndex++)
        {
            var parameter = (PyTypeParameter)parameters[parameterIndex];
            if (parameter.Kind == TypeParameterKind.TypeVarTuple)
            {
                var suffix = parameters.Count - parameterIndex - 1;
                var count = Math.Max(0, arguments.Count - offset - suffix);
                if (count == 0 && parameter.HasDefault)
                {
                    var defaultValue = await Default(parameter).ConfigureAwait(false);
                    if (defaultValue is PyUnpackedType { Value: PyGenericAlias alias })
                        foreach (var argument in alias.Arguments) values.Add(argument);
                    else if (defaultValue is PyTuple defaults)
                        foreach (var argument in defaults) values.Add(argument);
                    else throw new LythonRuntimeException("TypeError", "TypeVarTuple default must be a tuple or unpacked tuple type", span);
                }
                else while (count-- > 0) values.Add(arguments[offset++]);
                continue;
            }
            if (parameter.Kind == TypeParameterKind.ParamSpec && parameters.Count == 1 && arguments.Count > 0)
            {
                object specification = arguments.Count == 1 ? arguments[0] : arguments;
                if (specification is PyList list) specification = new PyTuple(list, context.MemoryGovernor, span);
                else if (specification is not (PyTuple or PyTypeParameter or PyEllipsis)) specification = new PyTuple([specification], context.MemoryGovernor, span);
                values.Add(specification); offset = arguments.Count;
                continue;
            }
            if (offset < arguments.Count) values.Add(arguments[offset++]);
            else if (parameter.HasDefault) values.Add(await Default(parameter).ConfigureAwait(false));
            else throw new LythonRuntimeException("TypeError", "Too few arguments for generic class", span);
        }
        if (offset != arguments.Count) throw new LythonRuntimeException("TypeError", "Too many arguments for generic class", span);
        var final = new PyTuple(values, context.MemoryGovernor, span);
        return PyGenericAlias.Create(origin,final,context.MemoryGovernor,span);

        async ValueTask<object> Default(PyTypeParameter parameter)
            => asynchronous ? (await parameter.TryGetMemberAsync("__default__", context, span).ConfigureAwait(false)).Value
                : parameter.TryGetMember("__default__", context, span, out var value) ? value : PyTypeParameter.NoDefault;
    }

    private static async ValueTask AttachTypeMetadataAsync(PyFunctionBase function,
        IReadOnlyList<LoweredFunctionParameter> parameters, LoweredExpression? returnAnnotation,
        bool hasTypeParameters, LythonSourceSpan span, TypeScope scope, ExecutionContext definingContext, bool asynchronous)
    {
        if (hasTypeParameters)
            function.TrySetMember("__type_params__", scope.Parameters);
        if (!hasTypeParameters && !HasTypeParameterScope(definingContext) &&
            returnAnnotation is null && parameters.All(p => p.Annotation is null)) return;
        var annotations = new PyDict(definingContext.MemoryGovernor, span);
        // CPython's annotation table visits regular arguments before positional-only
        // arguments, followed by *args, keyword-only arguments and **kwargs.
        foreach (var parameter in parameters.OrderBy(parameter => parameter.Kind switch
        {
            FunctionParameterKind.Positional => 0, FunctionParameterKind.PositionalOnly => 1,
            FunctionParameterKind.VariadicList => 2, FunctionParameterKind.KeywordOnly => 3, _ => 4
        }))
            if (parameter.Annotation is not null)
                await StoreAnnotationEntryAsync(annotations, parameter.Name,
                    definingContext.PostponedAnnotations ? CreatePostponedAnnotationValue(parameter.Annotation.Syntax, definingContext)
                        : await EvaluateTypeExpressionAsync(parameter.Annotation, scope.Annotations, asynchronous).ConfigureAwait(false),
                    definingContext, parameter.Annotation.Span, asynchronous).ConfigureAwait(false);
        if (returnAnnotation is not null)
            await StoreAnnotationEntryAsync(annotations, "return",
                definingContext.PostponedAnnotations ? CreatePostponedAnnotationValue(returnAnnotation.Syntax, definingContext)
                    : await EvaluateTypeExpressionAsync(returnAnnotation, scope.Annotations, asynchronous).ConfigureAwait(false),
                definingContext, returnAnnotation.Span, asynchronous).ConfigureAwait(false);
        function.TrySetMember("__annotations__", annotations);
    }

    private static async ValueTask AttachGenericClassMetadataAsync(LoweredClassDefinitionStatement definition, TypeScope scope,
        ExecutionContext classContext, bool asynchronous, object[] baseTypes)
    {
        if (definition.TypeParameters is null) return;
        classContext.Variables["__type_params__"] = scope.Parameters;
        classContext.Variables["__parameters__"] = scope.Parameters;
        var originalBases = new PyTuple(baseTypes.Concat([PyGenericAlias.Create(GetTypingGeneric(classContext, definition.Span),scope.Parameters,classContext.MemoryGovernor,definition.Span)]), classContext.MemoryGovernor, definition.Span);
        classContext.Variables["__orig_bases__"] = originalBases;
        await ValueTask.CompletedTask;
    }

    private static PyType GetTypingGeneric(ExecutionContext context, LythonSourceSpan span)
    {
        if (context.State.TypingGeneric is { } existing) return existing;
        context.TryGetBuiltinType("object", out var root);
        using var scratch = context.MemoryGovernor.ReserveTemporary(1024, span);
        var members = new Dictionary<string, object>(StringComparer.Ordinal) { ["__module__"] = PyString.FromString("typing") };
        var generic = new PyType("Generic", [root!], members, context.MemoryGovernor, span);
        if (context.TryGetBuiltinType("type", out var metatype)) generic.SetMetaType(metatype);
        ChargeClassTypeValue(members.Count, context.MemoryGovernor, span);
        context.State.TypingGeneric = generic;
        return generic;
    }

    private static IReadOnlyList<PyType> AddGenericClassBase(LoweredClassDefinitionStatement definition, IReadOnlyList<PyType> bases, ExecutionContext context)
    {
        if (definition.TypeParameters is null) return bases;
        var generic = GetTypingGeneric(context, definition.Span);
        if (bases.Contains(generic)) return bases;
        using var preflight12613 = context.MemoryGovernor.ReserveTemporary(EstimateObjectArrayBytes(bases.Count + 1), definition.Span);
        return bases.Count == 1 && bases[0].Name == "object" ? [generic] : bases.Concat([generic]).ToArray();
    }

    internal static ValueTask<object> ConstructTypeParameterAsync(TypeParameterKind kind, ReadOnlySpan<CallArgumentValue> arguments,
        ExecutionContext context, LythonSourceSpan span, bool asynchronous)
    {
        var scratch = context.MemoryGovernor.ReserveTemporary(128L + 64L * arguments.Length, span);
        try
        {
            object? nameValue = null, bound = null, defaultValue = null;
            var constraints = new List<object>();
            object covariantValue = false, contravariantValue = false, inferVarianceValue = false;
            var positional = 0;
            foreach (var argument in arguments)
            {
                if (!argument.IsKeyword)
                {
                    if (positional++ == 0)
                    {
                        if (nameValue is not null) throw new LythonRuntimeException("TypeError", "Multiple type parameter names", span);
                        nameValue = argument.Value;
                    }
                    else constraints.Add(argument.Value);
                    continue;
                }
                switch (argument.KeywordName)
                {
                    case "name":
                        if (nameValue is not null) throw new LythonRuntimeException("TypeError", "Multiple type parameter names", span);
                        nameValue = argument.Value; break;
                    case "bound" when kind != TypeParameterKind.TypeVarTuple: bound = argument.Value is PyNone ? null : argument.Value; break;
                    case "default": defaultValue = ReferenceEquals(argument.Value, PyTypeParameter.NoDefault) ? null : argument.Value; break;
                    case "covariant" when kind != TypeParameterKind.TypeVarTuple:
                        covariantValue = argument.Value; break;
                    case "contravariant" when kind != TypeParameterKind.TypeVarTuple:
                        contravariantValue = argument.Value; break;
                    case "infer_variance" when kind != TypeParameterKind.TypeVarTuple:
                        inferVarianceValue = argument.Value; break;
                    default: throw new LythonRuntimeException("TypeError", "Unexpected type parameter keyword", span);
                }
            }
            return CreateTypeParameterAsync(kind, nameValue, bound, defaultValue, constraints,
                covariantValue, contravariantValue, inferVarianceValue, scratch, context, span, asynchronous);
        }
        catch { scratch.Dispose(); throw; }
    }

    private static async ValueTask<object> CreateTypeParameterAsync(TypeParameterKind kind, object? nameValue,
        object? bound, object? defaultValue, List<object> constraints, object covariantValue, object contravariantValue,
        object inferVarianceValue, MemoryGovernor.TemporaryMemoryReservation scratch,
        ExecutionContext context, LythonSourceSpan span, bool asynchronous)
    {
        using var owner = scratch;
        var covariant = asynchronous ? await IsTruthyAsync(covariantValue, context, span).ConfigureAwait(false) : IsTruthy(covariantValue, context, span);
        var contravariant = asynchronous ? await IsTruthyAsync(contravariantValue, context, span).ConfigureAwait(false) : IsTruthy(contravariantValue, context, span);
        var inferVariance = asynchronous ? await IsTruthyAsync(inferVarianceValue, context, span).ConfigureAwait(false) : IsTruthy(inferVarianceValue, context, span);
        if (nameValue is null || !PyStringOps.TryAsString(nameValue, out var name))
            throw new LythonRuntimeException("TypeError", "Type parameter name must be a string", span);
        if (constraints.Count == 1 || constraints.Count != 0 && (kind != TypeParameterKind.TypeVar || bound is not null))
            throw new LythonRuntimeException("TypeError", "Invalid type parameter constraints", span);
        if (covariant && contravariant || inferVariance && (covariant || contravariant))
            throw new LythonRuntimeException("ValueError", "Invalid variance flags", span);
        if (constraints.Count != 0)
        {
            var tuple = new PyTuple(constraints, context.MemoryGovernor, span);
            bound = tuple;
        }
        return new PyTypeParameter(name.AsString(), kind, inferVariance, null, constraints.Count != 0, null, false,
            context, span, bound, defaultValue, covariant, contravariant);
    }

    private static bool IsTypeLike(object value) => value is PyType or PyTypeAlias or PyGenericAlias or PyTypingAlias or PyNone ||
        value is PyTypeParameter { Kind: TypeParameterKind.TypeVar } || value is PyBuiltinRuntimeType ||
        value is INamedRuntimeCallable named && IsBuiltinTypeName(named.Name);

    private static bool TryTypeUnion(object left, object right, ExecutionContext context, LythonSourceSpan span, [MaybeNullWhen(false)] out object value)
    {
        value = null;
        if (!IsTypeLike(left) || !IsTypeLike(right)) return false;
        var legacy = left is PyGenericAlias { IsUnion: true, Definition: not null } || right is PyGenericAlias { IsUnion: true, Definition: not null };
        var arguments = new PyTuple([left, right], context.MemoryGovernor, span);
        value = PyGenericAlias.Create(legacy ? PyTyping.Definition("Union") : PyGenericAlias.UnionType, arguments,
            context.MemoryGovernor, span, legacy ? PyTyping.Definition("Union") : null);
        return true;
    }

    internal static async ValueTask<(bool Found, object Value)> TryResolveRuntimeMemberAsync(object target, string member,
        ExecutionContext context, LythonSourceSpan span)
    {
        if (target is PyException exception && member == "message" &&
            (exception.CustomDict is null || !exception.CustomDict.TryGetValue(PyString.FromString(member), out _)))
            return (true, await PyRendering.ToInterpolatedPyStringAsync(exception, new PyRenderingContext(context)).ConfigureAwait(false));
        if (target is PyInstance instance)
        {
            var resolved = await PyAttributeLookup.TryResolveInstanceMemberAsync(instance, member, context, span).ConfigureAwait(false);
            if (resolved.Found) return resolved;
            return PyAttributeLookup.TryResolveObjectSlot(target, member, context, span, out var slot)
                ? (true, slot) : (false, PyNone.Instance);
        }
        if (target is IPyAsyncDynamicAttributes asynchronous)
        {
            var result = await asynchronous.TryGetMemberAsync(member, context, span).ConfigureAwait(false);
            if (result.Found) return result;
        }
        return TryResolveRuntimeMember(target, member, context, span, out var value) ? (true, value) : (false, PyNone.Instance);
    }
}
