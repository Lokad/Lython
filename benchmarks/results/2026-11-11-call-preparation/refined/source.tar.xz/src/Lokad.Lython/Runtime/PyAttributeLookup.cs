using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal static class PyAttributeLookup
{
    // Immediate calls can carry an ordinary non-data function and receiver in
    // their existing operands. Exposed attributes still create bound methods.
    // No cache: mutable instance/type lookup is repeated before the arguments.
    internal static bool TryResolveInstanceFunctionForCall(PyInstance instance, string memberName,
        [MaybeNullWhen(false)] out PyFunctionBase function)
    {
        if (instance.Type.TryLookupInMro("__getattribute__", 0, out var lookup, out _) &&
            LythonRuntime.IsDefaultObjectGetAttribute(lookup) &&
            !instance.TryGetOwnAttribute(memberName, out _) &&
            instance.Type.TryLookupInMro(memberName, 0, out var member, out _) &&
            member is PyFunctionBase found)
        {
            function = found;
            return true;
        }
        function = null;
        return false;
    }

    public static bool TryResolveTypeMember(PyType type, string memberName, [MaybeNullWhen(false)] out object value)
    {
        // Own-dict docstrings (stored at creation or assigned later) win over the
        // absent None; subclasses do not inherit like CPython.
        if (memberName == "__doc__" && type.TryGetOwnMember("__doc__", out var doc))
        {
            value = doc;
            return true;
        }

        if (TryResolveBuiltinTypeMember(type, memberName, out value))
        {
            return true;
        }

        if (type.TryLookupInMro(memberName, 0, out var rawValue, out _))
        {
            value = BindForType(type, rawValue, null, null);
            return true;
        }

        value = PyNone.Instance;
        return false;
    }

    public static bool TryResolveTypeMember(PyType type, string memberName, LythonRuntime.ExecutionContext context, LythonSourceSpan span, [MaybeNullWhen(false)] out object value)
    {
        if (memberName == "__doc__" && type.TryGetOwnMember("__doc__", out var doc))
        {
            value = doc;
            return true;
        }

        if (TryResolveBuiltinTypeMember(type, memberName, context, span, out value))
        {
            return true;
        }

        if (type.TryLookupInMro(memberName, 0, out var rawValue, out _))
        {
            value = BindForType(type, rawValue, context, span);
            return true;
        }

        value = PyNone.Instance;
        return false;
    }

    public static bool TryResolveInstanceMember(PyInstance instance, string memberName, LythonRuntime.ExecutionContext context, LythonSourceSpan span, [MaybeNullWhen(false)] out object value)
    {
        if (instance.Type.TryLookupInMro("__getattribute__", 0, out var getAttributeValue, out _))
        {
            var defaultSlot = LythonRuntime.IsDefaultObjectGetAttribute(getAttributeValue);
            LythonRuntime.ICallable? getAttributeCallable = null;
            if (!defaultSlot)
            {
                var bound = BindForInstance(instance, getAttributeValue, context, span);
                if (bound is not LythonRuntime.ICallable callable)
                    throw new LythonRuntimeException("TypeError", "__getattribute__ must be callable.", span);
                getAttributeCallable = callable;
            }

            try
            {
                value = defaultSlot
                    ? LythonRuntime.GetObjectInstanceAttribute(instance, memberName, context, span)
                    : CallableInvocation.InvokeUnary(getAttributeCallable!, PyString.FromString(memberName), span, context);
                return true;
            }
            catch (LythonRuntimeException ex) when (ex.ExceptionType == "AttributeError")
            {
                context.CheckExecution(span);
                if (instance.Type.TryLookupInMro("__getattr__", 0, out var rawGetAttr, out _))
                {
                    var boundGetAttr = BindForInstance(instance, rawGetAttr, context, span);
                    if (boundGetAttr is not LythonRuntime.ICallable getAttrCallable)
                    {
                        throw new LythonRuntimeException("TypeError", "__getattr__ must be callable.", span);
                    }

                    value = CallableInvocation.InvokeUnary(getAttrCallable, PyString.FromString(memberName), span, context);
                    return true;
                }

                if (!defaultSlot || instance.Type.TryLookupInMro(memberName, 0, out _, out _)) throw;

                value = PyNone.Instance;
                return false;
            }
        }

        value = PyNone.Instance;
        return false;
    }

    public static bool TryResolveInstanceMemberWithoutGetAttrFallback(PyInstance instance, string memberName, LythonRuntime.ExecutionContext context, LythonSourceSpan span, [MaybeNullWhen(false)] out object value)
    {
        var classMemberFound = instance.Type.TryLookupInMro(memberName, 0, out var rawValue, out _);
        if (memberName == "__class__" && !classMemberFound)
        {
            value = instance.Type;
            return true;
        }

        if (classMemberFound &&
            (rawValue is IPySettableDescriptor ||
             rawValue is PyInstance descriptorInstance && descriptorInstance.Type.TryLookupInMro("__set__", 0, out _, out _)))
        {
            value = BindForInstance(instance, rawValue, context, span);
            return true;
        }

        if (instance.TryGetOwnAttribute(memberName, out value))
        {
            return true;
        }

        // The own-attribute dictionary read invokes no guest code, so this
        // operation can reuse the live member already resolved above.
        if (classMemberFound)
        {
            value = BindForInstance(instance, rawValue!, context, span);
            return true;
        }

        if (memberName == "__dict__") { value = instance.GetNamespace(context, span); return true; }
        if (memberName == "__doc__") { value = PyNone.Instance; return true; }

        // Guest subclasses of the JSON encoder/decoder resolve engine
        // members here, where a base-class entry would sit: after instance
        // and guest-class lookup, so overrides and writes win, and inside
        // custom __getattribute__ only when it delegates to this path.
        if (LythonRuntime.JsonSubclassSupport.TryGetEngineMember(instance, memberName, context, span, out value))
        {
            return true;
        }

        value = PyNone.Instance;
        return false;
    }

    internal static async ValueTask<(bool Found, object Value)> TryResolveInstanceMemberAsync(
        PyInstance instance, string memberName, LythonRuntime.ExecutionContext context, LythonSourceSpan span)
    {
        if (!instance.Type.TryLookupInMro("__getattribute__", 0, out var rawGetAttribute, out _))
            return (false, PyNone.Instance);
        var defaultSlot = LythonRuntime.IsDefaultObjectGetAttribute(rawGetAttribute);
        LythonRuntime.ICallable? getAttribute = null;
        if (!defaultSlot)
        {
            var bound = await BindForInstanceAsync(instance, rawGetAttribute, context, span).ConfigureAwait(false);
            if (bound is not LythonRuntime.ICallable callable)
                throw new LythonRuntimeException("TypeError", "__getattribute__ must be callable.", span);
            getAttribute = callable;
        }
        try
        {
            return (true, defaultSlot
                ? await LythonRuntime.GetObjectInstanceAttributeAsync(instance, memberName, context, span).ConfigureAwait(false)
                : await CallableInvocation.InvokeUnaryAsync(getAttribute!, PyString.FromString(memberName), span, context).ConfigureAwait(false));
        }
        catch (LythonRuntimeException error) when (error.ExceptionType == "AttributeError")
        {
            context.CheckExecution(span);
            if (!instance.Type.TryLookupInMro("__getattr__", 0, out var rawGetAttr, out _))
            {
                if (!defaultSlot || instance.Type.TryLookupInMro(memberName, 0, out _, out _)) throw;
                return (false, PyNone.Instance);
            }
            var fallback = await BindForInstanceAsync(instance, rawGetAttr, context, span).ConfigureAwait(false);
            if (fallback is not LythonRuntime.ICallable getAttr)
                throw new LythonRuntimeException("TypeError", "__getattr__ must be callable.", span);
            return (true, await CallableInvocation.InvokeUnaryAsync(getAttr, PyString.FromString(memberName), span, context).ConfigureAwait(false));
        }
    }

    internal static async ValueTask<(bool Found, object Value)> TryResolveInstanceMemberWithoutGetAttrFallbackAsync(
        PyInstance instance, string memberName, LythonRuntime.ExecutionContext context, LythonSourceSpan span)
    {
        var classMemberFound = instance.Type.TryLookupInMro(memberName, 0, out var rawValue, out _);
        if (memberName == "__class__" && !classMemberFound) return (true, instance.Type);
        if (classMemberFound &&
            (rawValue is IPySettableDescriptor ||
             rawValue is PyInstance descriptorInstance && descriptorInstance.Type.TryLookupInMro("__set__", 0, out _, out _)))
            return (true, await BindForInstanceAsync(instance, rawValue, context, span).ConfigureAwait(false));
        if (instance.TryGetOwnAttribute(memberName, out var ownValue)) return (true, ownValue);
        if (classMemberFound)
            return (true, await BindForInstanceAsync(instance, rawValue!, context, span).ConfigureAwait(false));
        if (memberName == "__dict__") return (true, instance.GetNamespace(context, span));
        if (memberName == "__doc__") return (true, PyNone.Instance);
        return LythonRuntime.JsonSubclassSupport.TryGetEngineMember(instance, memberName, context, span, out var engineValue)
            ? (true, engineValue) : (false, PyNone.Instance);
    }

    internal static ValueTask<object> BindForInstanceAsync(
        PyInstance instance, object rawValue, LythonRuntime.ExecutionContext context, LythonSourceSpan span)
        => BindDescriptorAsync(rawValue, instance, instance.Type, context, span);

    internal static ValueTask<object> BindForTypeAsync(
        PyType type, object rawValue, LythonRuntime.ExecutionContext context, LythonSourceSpan span)
        => BindDescriptorAsync(rawValue, null, type, context, span);

    internal static async ValueTask<object> BindDescriptorAsync(
        object rawValue, object? instance, PyType owner, LythonRuntime.ExecutionContext context, LythonSourceSpan span)
    {
        if (rawValue is IPyDescriptor descriptor)
            return await descriptor.GetAsync(instance, owner, context, span).ConfigureAwait(false);
        if (rawValue is PyInstance descriptorInstance &&
            TryLookupRawDescriptorGetter(descriptorInstance, context, span, out var callable))
            return await CallableInvocation.InvokeTernaryAsync(callable, descriptorInstance, instance ?? PyNone.Instance, owner, span, context).ConfigureAwait(false);
        return rawValue;
    }

    // Builtin exception __new__ slots live on the defining type like CPython:
    // most builtins own theirs; the mapped ones inherit the ancestor slot.
    private static readonly IReadOnlyDictionary<string, string> InheritedExceptionNewSlots =
        new Dictionary<string, string>(StringComparer.Ordinal)
        {
            ["KeyError"] = "LookupError",
            ["ImportError"] = "Exception",
            ["ModuleNotFoundError"] = "Exception",
            ["NameError"] = "Exception",
            ["UnboundLocalError"] = "Exception",
            ["AttributeError"] = "Exception",
            ["SyntaxError"] = "Exception",
            ["StopIteration"] = "Exception",
            ["FileNotFoundError"] = "OSError",
            ["FileExistsError"] = "OSError",
            ["IsADirectoryError"] = "OSError",
            ["NotADirectoryError"] = "OSError",
            ["PermissionError"] = "OSError",
            ["BrokenPipeError"] = "OSError",
            ["TimeoutError"] = "OSError",
            ["SystemExit"] = "BaseException",
            ["GeneratorExit"] = "BaseException",
        };

    // Collections members route by name like CPython: deque owns its slot,
    // the dict subclasses inherit dict slot, and ChainMap shares the object
    // slot. Anything else (namedtuple factory, User* stubs) stays missing.
    private static bool TryResolveCollectionsNewSlot(LythonRuntime.CollectionsCallable member, LythonRuntime.ExecutionContext context, LythonSourceSpan span, [MaybeNullWhen(false)] out object value)
    {
        if (member.Name is "collections.deque")
        {
            return LythonRuntime.TryGetTypeNewSlot(member, out value);
        }

        if (member.Name is "collections.Counter" or "collections.defaultdict" or "collections.OrderedDict")
        {
            if (context.TryGetBuiltin("dict", out var dictBase) &&
                dictBase is not null &&
                LythonRuntime.TryGetTypeNewSlot(dictBase, out value))
            {
                return true;
            }

            value = PyNone.Instance;
            return false;
        }

        if (member.Name is "collections.ChainMap")
        {
            if (!context.TryGetBuiltin("object", out var objectBase) ||
                objectBase is not PyType objectType ||
                !objectType.TryLookupInMro("__new__", 0, out var sharedRaw, out _) ||
                sharedRaw is not IPyDescriptor sharedDescriptor)
            {
                value = PyNone.Instance;
                return false;
            }

            value = sharedDescriptor.Get(null, objectType, context, span);
            return true;
        }

        value = PyNone.Instance;
        return false;
    }

    private static bool TryResolveExceptionNewSlot(object target, LythonRuntime.ExecutionContext context, [MaybeNullWhen(false)] out object value)
    {
        string? typeName = target switch
        {
            LythonRuntime.ExceptionTypeValue typeValue => typeValue.ExceptionIdentity.ModuleName is "builtins" ? typeValue.TypeName : null,
            PyException exception when exception.Identity.IsBuiltin => exception.Identity.TypeName,
            _ => null,
        };

        if (typeName is null)
        {
            value = PyNone.Instance;
            return false;
        }

        var definingName = typeName;
        while (InheritedExceptionNewSlots.TryGetValue(definingName, out var baseName))
        {
            definingName = baseName;
        }

        if (!context.TryGetBuiltin(definingName, out var definingBase) ||
            definingBase is not LythonRuntime.ExceptionTypeValue definingType)
        {
            value = PyNone.Instance;
            return false;
        }

        return LythonRuntime.TryGetExceptionNewSlot(definingType, definingName, out value);
    }

    // Object slots resolve through the run object type for any receiver missed
    // by the flat member tables, like CPython where every object carries them.
    // Instance slots bind the receiver; __init_subclass__ binds type(target);
    // __new__ resolves through the target type own slot.
    internal static bool TryResolveObjectSlot(object target, string memberName, LythonRuntime.ExecutionContext context, LythonSourceSpan span, [MaybeNullWhen(false)] out object value)
    {
        if (memberName is "__new__")
        {
            // Exception types own or inherit their slot along the builtin
            // hierarchy like CPython; module exceptions stay missing.
            if (TryResolveExceptionNewSlot(target, context, out value))
            {
                return true;
            }

            // The partial factory owns its slot directly, like the
            // collections members below.
            if (target is LythonRuntime.PartialFactory directPartial &&
                LythonRuntime.TryGetTypeNewSlot(directPartial, out value))
            {
                return true;
            }

            // Factory members reuse existing slots like CPython: the
            // partialmethod factory shares object.__new__ while the
            // namedtuple factory resolves the function slot.
            if (target is LythonRuntime.PartialMethodFactory)
            {
                if (!context.TryGetBuiltin("object", out var factoryBase) ||
                    factoryBase is not PyType factoryObject ||
                    !factoryObject.TryLookupInMro(memberName, 0, out var factoryRaw, out _) ||
                    factoryRaw is not IPyDescriptor factoryDescriptor)
                {
                    value = PyNone.Instance;
                    return false;
                }

                value = factoryDescriptor.Get(null, factoryObject, context, span);
                return true;
            }

            if (target is LythonRuntime.CollectionsCallable namedtupleFactory &&
                namedtupleFactory.Name is "collections.namedtuple" &&
                LythonRuntime.TryGetTypeNewSlot(PyType.FunctionType, out value))
            {
                return true;
            }

            // Collections members route by name, both directly and through
            // the class values of their instances.
            if (target is LythonRuntime.CollectionsCallable directMember &&
                TryResolveCollectionsNewSlot(directMember, context, span, out value))
            {
                return true;
            }

            if (LythonRuntime.TryGetValueClass(target, context, out var collectionsClass) &&
                collectionsClass is LythonRuntime.CollectionsCallable memberClass &&
                TryResolveCollectionsNewSlot(memberClass, context, span, out value))
            {
                return true;
            }

            // Instances never carry __new__ (it lives on the type): builtin
            // values resolve their type own slot, engine callables share
            // object.__new__, and anything else stays missing.
            if (!LythonRuntime.TryGetValueClass(target, context, out var classValue) ||
                classValue is null)
            {
                value = PyNone.Instance;
                return false;
            }

            if (ReferenceEquals(classValue, PyType.BuiltinFunctionType) ||
                ReferenceEquals(classValue, PyType.MethodWrapperType) ||
                ReferenceEquals(classValue, PyType.WrapperDescriptorType) ||
                ReferenceEquals(classValue, PyType.RegexPatternType) ||
                ReferenceEquals(classValue, PyType.RegexMatchType) ||
                ReferenceEquals(classValue, LythonRuntime.StatisticsModule.NormalDistType))
            {
                if (!context.TryGetBuiltin("object", out var sharedBase) ||
                    sharedBase is not PyType sharedType ||
                    !sharedType.TryLookupInMro(memberName, 0, out var sharedRaw, out _) ||
                    sharedRaw is not IPyDescriptor sharedDescriptor)
                {
                    value = PyNone.Instance;
                    return false;
                }

                value = sharedDescriptor.Get(null, sharedType, context, span);
                return true;
            }

            return LythonRuntime.TryGetTypeNewSlot(classValue, out value);
        }

        if (memberName is "__init_subclass__")
        {
            if (!context.TryGetBuiltin("object", out var subclassBase) ||
                subclassBase is not PyType subclassObject ||
                !subclassObject.TryLookupInMro(memberName, 0, out var subclassRaw, out _) ||
                subclassRaw is not IPyBindableCallable subclassBindable ||
                !LythonRuntime.TryGetBoundSubclassTarget(target, context, out var typeValue) ||
                typeValue is null)
            {
                value = PyNone.Instance;
                return false;
            }

            value = subclassBindable.Bind(typeValue);
            return true;
        }

        if (memberName is not ("__init__" or "__getattribute__" or "__setattr__" or "__delattr__"))
        {
            value = PyNone.Instance;
            return false;
        }

        if (!context.TryGetBuiltin("object", out var objectBase) ||
            objectBase is not PyType objectType ||
            !objectType.TryLookupInMro(memberName, 0, out var rawValue, out _))
        {
            value = PyNone.Instance;
            return false;
        }

        if (rawValue is IPyDescriptor descriptor)
        {
            value = descriptor.Get(target, objectType, context, span);
            return true;
        }

        value = rawValue;
        return true;
    }

    public static bool TryResolveSuperMember(PySuper superObject, string memberName, LythonRuntime.ExecutionContext context, LythonSourceSpan span, [MaybeNullWhen(false)] out object value)
    {
        // Super serves its own descriptors on the proxy itself like CPython:
        // __thisclass__ is always the anchor while __self__ and
        // __self_class__ fall back to None when unbound.
        if (memberName is "__thisclass__")
        {
            value = superObject.AnchorType;
            return true;
        }

        if (memberName is "__self__")
        {
            value = superObject.BoundObject ?? (object)PyNone.Instance;
            return true;
        }

        if (memberName is "__self_class__")
        {
            value = superObject.BoundType ?? (object)PyNone.Instance;
            return true;
        }

        if (superObject.BoundType is not PyType boundType)
        {
            // Unbound super exposes no instance MRO like CPython.
            value = PyNone.Instance;
            return false;
        }

        if (!boundType.TryGetSuccessorMroIndex(superObject.AnchorType, out var startIndex))
        {
            value = PyNone.Instance;
            return false;
        }

        var foundInMro = boundType.TryLookupInMro(memberName, startIndex, out var rawValue, out var ownerType);
        var mroValue = foundInMro ? rawValue : null;
        var defersToEngine = foundInMro && ownerType is not null && context.TryGetBuiltin("object", out var objectBase) && ReferenceEquals(ownerType, objectBase);
        if (mroValue is not null && !defersToEngine)
        {
            value = BindForSuper(superObject.BoundObject, boundType, mroValue, context, span);
            return true;
        }

        // Engine members sit between the last guest base and object, so an
        // object-root hit (like __init__) defers to them first; guest mixins
        // above keep precedence through the branch above.
        if (LythonRuntime.JsonSubclassSupport.TryGetSuperEngineMember(superObject, memberName, context, span, out value))
        {
            return true;
        }

        if (mroValue is not null)
        {
            value = BindForSuper(superObject.BoundObject, boundType, mroValue, context, span);
            return true;
        }

        value = PyNone.Instance;
        return false;
    }

    internal static async ValueTask<bool> TrySetDescriptorValueAsync(object descriptor, PyInstance instance, object value, LythonRuntime.ExecutionContext context, LythonSourceSpan span)
    {
        if (descriptor is PyProperty property)
        {
            await property.SetAsync(instance, value, context, span).ConfigureAwait(false);
            return true;
        }
        if (descriptor is PyInstance descriptorInstance &&
            await LookupDescriptorMethodAsync(descriptorInstance, "__set__", context, span).ConfigureAwait(false) is { } callable)
        {
            _ = await CallableInvocation.InvokeBinaryAsync(callable, instance, value, span, context).ConfigureAwait(false);
            return true;
        }
        return TrySetDescriptorValue(descriptor, instance, value, context, span);
    }

    public static bool TrySetDescriptorValue(object descriptor, PyInstance instance, object value, LythonRuntime.ExecutionContext context, LythonSourceSpan span)
    {
        if (descriptor is IPySettableDescriptor settable)
        {
            settable.Set(instance, value, context, span);
            return true;
        }

        if (descriptor is PyInstance descriptorInstance &&
            TryLookupDescriptorMethod(descriptorInstance, "__set__", context, span, out var callable))
        {
            _ = CallableInvocation.InvokeBinary(callable, instance, value, span, context);
            return true;
        }

        return false;
    }

    internal static async ValueTask<bool> TryDeleteDescriptorValueAsync(object descriptor, PyInstance instance, LythonRuntime.ExecutionContext context, LythonSourceSpan span)
    {
        if (descriptor is PyProperty property)
        {
            await property.DeleteAsync(instance, context, span).ConfigureAwait(false);
            return true;
        }
        if (descriptor is PyInstance descriptorInstance &&
            await LookupDescriptorMethodAsync(descriptorInstance, "__delete__", context, span).ConfigureAwait(false) is { } callable)
        {
            _ = await CallableInvocation.InvokeUnaryAsync(callable, instance, span, context).ConfigureAwait(false);
            return true;
        }
        return TryDeleteDescriptorValue(descriptor, instance, context, span);
    }

    public static bool TryDeleteDescriptorValue(object descriptor, PyInstance instance, LythonRuntime.ExecutionContext context, LythonSourceSpan span)
    {
        if (descriptor is IPyDeletableDescriptor deletable)
        {
            deletable.Delete(instance, context, span);
            return true;
        }

        if (descriptor is PyInstance descriptorInstance &&
            TryLookupDescriptorMethod(descriptorInstance, "__delete__", context, span, out var callable))
        {
            _ = CallableInvocation.InvokeUnary(callable, instance, span, context);
            return true;
        }

        return false;
    }

    internal static object BindForType(PyType type, object rawValue, LythonRuntime.ExecutionContext? context, LythonSourceSpan? span)
    {
        return TryBindDynamicDescriptor(rawValue, null, type, context, span, out var value)
            ? value
            : rawValue;
    }

    internal static object BindForInstance(PyInstance instance, object rawValue, LythonRuntime.ExecutionContext context, LythonSourceSpan span)
    {
        return TryBindDynamicDescriptor(rawValue, instance, instance.Type, context, span, out var value)
            ? value
            : rawValue;
    }

    private static object BindForSuper(object? boundObject, PyType boundType, object rawValue, LythonRuntime.ExecutionContext context, LythonSourceSpan span)
    {
        return TryBindDynamicDescriptor(rawValue, boundObject, boundType, context, span, out var value)
            ? value
            : rawValue;
    }

    internal static bool TryBindDynamicDescriptor(object rawValue, object? instance, PyType owner, LythonRuntime.ExecutionContext? context, LythonSourceSpan? span, [MaybeNullWhen(false)] out object value)
    {
        if (rawValue is IPyDescriptor descriptor)
        {
            value = descriptor.Get(instance, owner, context, span);
            return true;
        }

        if (rawValue is PyInstance descriptorInstance)
        {
            if (context is null || span is null)
            {
                value = rawValue;
                return false;
            }

            if (TryLookupRawDescriptorGetter(descriptorInstance, context, span, out var callable))
            {
                value = CallableInvocation.InvokeTernary(
                    callable,
                    descriptorInstance,
                    instance ?? PyNone.Instance,
                    owner,
                    span,
                    context);
                return true;
            }
        }

        value = rawValue;
        return false;
    }

    private static bool TryLookupRawDescriptorGetter(PyInstance descriptorInstance, LythonRuntime.ExecutionContext context,
        LythonSourceSpan span, [MaybeNullWhen(false)] out LythonRuntime.ICallable callable)
    {
        if (!descriptorInstance.Type.TryLookupInMro("__get__", 0, out var raw, out _))
        {
            callable = null;
            return false;
        }
        // Unlike setter/deleter method lookup, Python calls this slot raw.
        // Classmethod wrappers are bindable but cannot be raw getter callables.
        if (raw is PyClassMethod || raw is not LythonRuntime.ICallable resolved)
            throw LythonRuntime.NotCallableError(raw, context, span);
        callable = resolved;
        return true;
    }

    private static async ValueTask<LythonRuntime.ICallable?> LookupDescriptorMethodAsync(
        PyInstance descriptorInstance, string methodName, LythonRuntime.ExecutionContext context, LythonSourceSpan span)
    {
        if (!descriptorInstance.Type.TryLookupInMro(methodName, 0, out var rawMethod, out _))
            return null;
        var bound = rawMethod is IPyDescriptor descriptor
            ? await descriptor.GetAsync(descriptorInstance, descriptorInstance.Type, context, span).ConfigureAwait(false)
            : rawMethod;
        return bound as LythonRuntime.ICallable
            ?? throw new LythonRuntimeException("TypeError", $"Descriptor method '{methodName}' must be callable.", span);
    }

    private static bool TryLookupDescriptorMethod(PyInstance descriptorInstance, string methodName, LythonRuntime.ExecutionContext context, LythonSourceSpan span, [MaybeNullWhen(false)] out LythonRuntime.ICallable callable)
    {
        if (descriptorInstance.Type.TryLookupInMro(methodName, 0, out var rawMethod, out _))
        {
            var bound = rawMethod is IPyDescriptor descriptor
                ? descriptor.Get(descriptorInstance, descriptorInstance.Type, context, span)
                : rawMethod;
            if (bound is not LythonRuntime.ICallable resolved)
            {
                throw new LythonRuntimeException("TypeError", $"Descriptor method '{methodName}' must be callable.", span);
            }

            callable = resolved;
            return true;
        }

        callable = null;
        return false;
    }

    private static bool TryResolveBuiltinTypeMember(PyType type, string memberName, [MaybeNullWhen(false)] out object value)
    {
        // Absent docstrings report None like CPython (doc texts are not stored).
        if (memberName == "__doc__")
        {
            value = PyNone.Instance;
            return true;
        }

        value = memberName switch
        {
            "__name__" => type.NameValue,
            "__qualname__" => type.NameValue,
            "__base__" => (object?)type.Bases.FirstOrDefault() ?? PyNone.Instance,
            "__bases__" => type.BasesTuple,
            "__mro__" => type.MroTuple,
            "__class__" => (object?)type.MetaType ?? PyNone.Instance,
            // Absent docstrings report None like CPython (doc texts are not stored).
            _ => PyNone.Instance
        };
        return !ReferenceEquals(value, PyNone.Instance);
    }

    private static bool TryResolveBuiltinTypeMember(PyType type, string memberName, LythonRuntime.ExecutionContext context, LythonSourceSpan span, [MaybeNullWhen(false)] out object value)
    {
        if (memberName == "__dict__") { value = type.GetNamespace(context, span); return true; }
        // Absent docstrings report None like CPython (doc texts are not stored).
        if (memberName == "__doc__")
        {
            value = PyNone.Instance;
            return true;
        }

        value = memberName switch
        {
            "__name__" => type.NameValue,
            "__qualname__" => type.NameValue,
            "__base__" => (object?)type.Bases.FirstOrDefault() ?? PyNone.Instance,
            "__bases__" => type.BasesTuple,
            "__mro__" => type.MroTuple,
            "__class__" => (object?)type.MetaType ?? PyNone.Instance,
            // Absent docstrings report None like CPython (doc texts are not stored).
            _ => PyNone.Instance
        };
        return !ReferenceEquals(value, PyNone.Instance);
    }

}
