using System.Numerics;
using System.Text;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal static class RegexCompiler
    {
        internal const int PythonIgnoreCaseFlag = 2;
        internal const int PythonLocaleFlag = 4;
        internal const int PythonMultilineFlag = 8;
        internal const int PythonDotAllFlag = 16;
        internal const int PythonUnicodeFlag = 32;
        internal const int PythonVerboseFlag = 64;
        internal const int RegexDebugFlag = 128;
        internal const int PythonAsciiFlag = 256;

        internal static T ProviderCall<T>(Func<T> operation, MemoryGovernor? governor,
            CancellationToken cancellationToken, LythonSourceSpan? span, PyString? pattern = null,
            string operationName = "Regex provider")
        {
            governor?.ThrowIfAdmissionFailed();
            if (cancellationToken.IsCancellationRequested) throw RuntimeErrors.Cancelled(span);
            try
            {
                var result = operation();
                try
                {
                    governor?.ThrowIfAdmissionFailed();
                    if (cancellationToken.IsCancellationRequested) throw RuntimeErrors.Cancelled(span);
                    return result;
                }
                catch
                {
                    // Ownership has not reached the caller's using/field yet.
                    // A token changing as preparation returns must still close
                    // the acquired working resource before its owner can end.
                    if (result is ILythonRegexSubject subject) subject.Dispose();
                    else if (result is ILythonRegexCursor cursor) cursor.Dispose();
                    else if (result is ILythonRegexPattern patternHandle) patternHandle.Dispose();
                    throw;
                }
            }
            catch (Exception error) when (error is not LythonRuntimeException and not OutOfMemoryException)
            { throw ProviderFailure(error, governor, cancellationToken, span, pattern, operationName); }
        }

        internal static bool TryMatch(ILythonRegexSubject subject, LythonRegexMatchMode mode,
            Span<LythonRegexCapture?> captures, out int? lastIndex, MemoryGovernor? governor,
            CancellationToken token, LythonSourceSpan? span, PyString? pattern = null,
            string operationName = "Regex provider")
        {
            governor?.ThrowIfAdmissionFailed();
            if (token.IsCancellationRequested) throw RuntimeErrors.Cancelled(span);
            try
            {
                var success = subject.TryMatch(mode, captures, out lastIndex, token);
                governor?.ThrowIfAdmissionFailed();
                if (token.IsCancellationRequested) throw RuntimeErrors.Cancelled(span);
                return success;
            }
            catch (Exception error) when (error is not LythonRuntimeException and not OutOfMemoryException)
            { throw ProviderFailure(error, governor, token, span, pattern, operationName); }
        }

        internal static bool TryNext(ILythonRegexCursor cursor, Span<LythonRegexCapture?> captures,
            out int? lastIndex, MemoryGovernor governor, CancellationToken token,
            LythonSourceSpan span, PyString pattern)
        {
            governor.ThrowIfAdmissionFailed();
            if (token.IsCancellationRequested) throw RuntimeErrors.Cancelled(span);
            try
            {
                var success = cursor.TryNext(captures, out lastIndex, token);
                governor.ThrowIfAdmissionFailed();
                if (token.IsCancellationRequested) throw RuntimeErrors.Cancelled(span);
                return success;
            }
            catch (Exception error) when (error is not LythonRuntimeException and not OutOfMemoryException)
            { throw ProviderFailure(error, governor, token, span, pattern); }
        }

        private static LythonRuntimeException ProviderFailure(Exception error, MemoryGovernor? governor,
            CancellationToken token, LythonSourceSpan? span, PyString? pattern,
            string operationName = "Regex provider")
        {
            if (error is OperationCanceledException)
            {
                governor?.ThrowIfAdmissionFailed();
                return RuntimeErrors.Cancelled(span);
            }
            if (error is not LythonRegexException providerError)
                return RuntimeErrors.Host("regex provider", error, span);
            governor?.ThrowIfAdmissionFailed();
            if (providerError.Failure != LythonRegexFailure.MemoryAdmission && token.IsCancellationRequested)
                return RuntimeErrors.Cancelled(span);
            return providerError.Failure switch
            {
                LythonRegexFailure.Capability => RuntimeErrors.Capability(providerError.Message, span),
                LythonRegexFailure.MemoryAdmission => governor?.RefuseAdmission($"{operationName}: {providerError.Message}", providerError.RequestedBytes, span, providerError)
                    ?? RuntimeErrors.Attributed("MemoryError", $"{operationName}: {providerError.Message}", span,
                        LythonFailureReason.SharedMemoryAllowance, requested: providerError.RequestedBytes),
                _ => CreatePatternErrorFailure(providerError.Message, pattern, providerError.Position, governor, token, span),
            };
        }

        internal readonly record struct RegexPatternRange(RePatternObject Pattern, RegexSubjectRange Range);

        internal readonly record struct RegexSubstituteInputs(
            RePatternObject Pattern,
            object Replacement,
            RegexSubjectRange Range,
            int Count);

        internal readonly record struct RegexSplitInputs(RePatternObject Pattern, RegexSubjectRange Range, int MaxSplit);

        internal static IReadOnlyDictionary<PyString, int> CopyNamedGroups(ILythonRegexPattern pattern,
            MemoryGovernor? governor, CancellationToken token, LythonSourceSpan? span, PyString? sourcePattern = null)
        {
            var entries = ProviderCall(() => pattern.NamedGroups, governor, token, span, sourcePattern);
            var bytes = checked(64L + 96L * entries.Count);
            using var storage = governor?.ReserveTemporary(bytes, span);
            var names = new Dictionary<PyString, int>(entries.Count);
            var previous = 0;
            for (var i = 0; i < entries.Count; i++)
            {
                if (token.IsCancellationRequested) throw RuntimeErrors.Cancelled(span);
                governor?.ThrowIfAdmissionFailed();
                var entry = entries[i];
                if (token.IsCancellationRequested) throw RuntimeErrors.Cancelled(span);
                if (entry.Index <= previous || entry.Index >= pattern.CaptureSlotCount || entry.Name.IsEmpty)
                    throw RuntimeErrors.Runtime("Regex provider returned inconsistent named-group metadata.", span);
                var input = entry.Name.Span;
                for (int offset = 0, scalar = 0; offset < input.Length; scalar++)
                {
                    if ((scalar & 1023) == 0 && token.IsCancellationRequested) throw RuntimeErrors.Cancelled(span);
                    if (Rune.DecodeFromUtf8(input[offset..], out _, out var width) != System.Buffers.OperationStatus.Done)
                        throw RuntimeErrors.Runtime("Regex provider returned invalid UTF-8 group names.", span);
                    offset += width;
                }
                // Metadata is borrowed. Copy before its pattern handle can close;
                // a full-array view is not permission to adopt provider storage.
                var name = governor is null ? PyString.FromUtf8(entry.Name.ToArray())
                    : PyString.CopyFromUtf8(entry.Name.Span, governor, span);
                if (!names.TryAdd(name, entry.Index))
                    throw RuntimeErrors.Runtime("Regex provider returned duplicate group names.", span);
                previous = entry.Index;
            }
            if (token.IsCancellationRequested) throw RuntimeErrors.Cancelled(span);
            storage?.Commit(bytes);
            return names;
        }

        internal static RePatternObject CreatePattern(object[] arguments, string signature, LythonSourceSpan span, ExecutionContext context)
        {
            if (arguments.Length is < 1 or > 2)
            {
                throw new LythonRuntimeException("TypeError", $"{signature} expects a string pattern and optional flags.", span);
            }

            CheckFlagsHashable(arguments, 1, span);
            if (arguments[0] is RePatternObject existing)
            {
                if (arguments.Length == 2 && IsTruthy(arguments[1], context, span))
                {
                    throw new LythonRuntimeException("ValueError", "cannot process flags argument with a compiled pattern", span);
                }

                return existing;
            }

            if (!PyStringOps.TryAsString(arguments[0], out var pattern))
            {
                throw new LythonRuntimeException("TypeError", "first argument must be string or compiled pattern", span);
            }

            var options = arguments.Length == 2
                ? ParseFlags(arguments[1], span, context)
                : new LythonRegexOptions(PythonUnicodeFlag, false);
            context.CheckExecution(span);
            _ = pattern.GetHashCode(context.State.CancellationToken, span);
            var cache = context.State.RegexCache ??= new RegexPatternCache();
            if (cache.TryGet(pattern, options, out var cached) && cached is not null)
            {
                return cached;
            }

            var provider = context.State.RegexProvider
                ?? throw RuntimeErrors.Capability("Python regex functionality requires a host-supplied Lython regex provider.", span);
            ILythonRegexPattern? artifact = null;
            _ = context.State.RegexPrograms?.TryGet(pattern, options, out artifact);
            var compiled = artifact ?? ProviderCall(() => provider.Compile(pattern.Utf8Bytes, options,
                context.MemoryGovernor.Budget, context.State.CancellationToken), context.MemoryGovernor,
                context.State.CancellationToken, span, pattern);
            try
            {
                var wrapperBytes = checked(256L + 64L * compiled.CaptureSlotCount);
                using var storage = context.MemoryGovernor.ReserveTemporary(wrapperBytes, span);
                // Guest-visible name strings can acquire caches and produce new
                // strings. Give those values the current run's governor rather
                // than sharing an analysis governor across concurrent runs.
                var names = CopyNamedGroups(compiled, context.MemoryGovernor, context.State.CancellationToken, span, pattern);
                var result = new RePatternObject(pattern, compiled.Flags, compiled,
                    compiled.CaptureSlotCount, names);
                storage.Commit(wrapperBytes);
                cache.Add(pattern, options, result, context.MemoryGovernor, span);
                if (artifact is null) context.State.TrackRegexPattern(compiled);
                return result;
            }
            catch { if (artifact is null) compiled.Dispose(); throw; }
        }

        // The cache lookup hashes flags first, so unhashable flags fail before
        // any dispatch or compiled-pattern check like CPython.
        private static void CheckFlagsHashable(object[] arguments, int flagsIndex, LythonSourceSpan span)
        {
            if (arguments.Length > flagsIndex)
            {
                try
                {
                    _ = PyValueComparer.Instance.GetHashCode(arguments[flagsIndex]);
                }
                catch (InvalidOperationException)
                {
                    throw RuntimeErrors.UnhashableType(arguments[flagsIndex], span);
                }
            }
        }

        // A compiled pattern with truthy flags fails like CPython before any dispatch.
        private static void ThrowIfCompiledFlags(object[] arguments, int flagsIndex, LythonSourceSpan span, ExecutionContext context)
        {
            if (arguments.Length > flagsIndex && IsTruthy(arguments[flagsIndex], context, span))
            {
                throw new LythonRuntimeException("ValueError", "cannot process flags argument with a compiled pattern", span);
            }
        }

        internal static RegexPatternRange CreatePatternAndRange(object[] arguments, string signature, LythonSourceSpan span, ExecutionContext context)
        {
            if (arguments.Length is < 2 or > 5 || !PyStringOps.TryAsString(arguments[1], out var text))
            {
                throw new LythonRuntimeException("TypeError", $"{signature} expects pattern, string, optional flags, pos, and endpos.", span);
            }

            CheckFlagsHashable(arguments, 2, span);
            var pos = arguments.Length >= 4 ? ParseOptionalPosition(arguments[3], 0, span, context) : 0;
            var endPos = arguments.Length >= 5 ? ParseOptionalPosition(arguments[4], text.Length, span, context) : text.Length;

            if (arguments[0] is RePatternObject compiled)
            {
                ThrowIfCompiledFlags(arguments, 2, span, context);
                var compiledRange = CreateSubjectRange(text, pos, endPos);
                return new RegexPatternRange(compiled, compiledRange);
            }

            object[] patternArguments = arguments.Length >= 3 && !ReferenceEquals(arguments[2], PyNone.Instance)
                ? [arguments[0], arguments[2]]
                : [arguments[0]];
            var matchRange = CreateSubjectRange(text, pos, endPos);
            return new RegexPatternRange(
                CreatePattern(patternArguments, signature, span, context),
                matchRange);
        }

        internal static RegexSubstituteInputs CreateSubstituteInputs(object[] arguments, string signature, LythonSourceSpan span, ExecutionContext context)
        {
            if (arguments.Length is < 3 or > 7 || !PyStringOps.TryAsString(arguments[2], out var text))
            {
                throw new LythonRuntimeException("TypeError", $"{signature} expects pattern, replacement, text, optional count, flags, pos, and endpos.", span);
            }

            var replacement = arguments[1];
            if (!PyStringOps.TryAsString(replacement, out _) && replacement is not ICallable)
            {
                throw new LythonRuntimeException("TypeError", $"{signature} expects replacement to be a string or callable.", span);
            }

            var count = arguments.Length >= 4
                ? ParseOptionalIntOrDefault(arguments[3], 0, "count", signature, span, context)
                : 0;
            var pos = arguments.Length >= 6 ? ParseOptionalPosition(arguments[5], 0, span, context) : 0;
            var endPos = arguments.Length >= 7 ? ParseOptionalPosition(arguments[6], text.Length, span, context) : text.Length;

            CheckFlagsHashable(arguments, 4, span);
            RePatternObject pattern;
            if (arguments[0] is RePatternObject compiled)
            {
                ThrowIfCompiledFlags(arguments, 4, span, context);
                pattern = compiled;
            }
            else
            {
                object[] patternArguments = arguments.Length >= 5 && !ReferenceEquals(arguments[4], PyNone.Instance)
                    ? [arguments[0], arguments[4]]
                    : [arguments[0]];
                pattern = CreatePattern(patternArguments, signature, span, context);
            }

            var substituteInputs = new RegexSubstituteInputs(pattern, replacement, CreateSubjectRange(text, pos, endPos), count);
            return substituteInputs;
        }

        internal static RegexSplitInputs CreateSplitInputs(object[] arguments, string signature, LythonSourceSpan span, ExecutionContext context)
        {
            if (arguments.Length is < 2 or > 6 || !PyStringOps.TryAsString(arguments[1], out var text))
            {
                throw new LythonRuntimeException("TypeError", $"{signature} expects pattern, string, optional maxsplit, flags, pos, and endpos.", span);
            }

            var maxSplit = 0;
            var pos = arguments.Length >= 5 ? ParseOptionalPosition(arguments[4], 0, span, context) : 0;
            var endPos = arguments.Length >= 6 ? ParseOptionalPosition(arguments[5], text.Length, span, context) : text.Length;

            CheckFlagsHashable(arguments, 3, span);
            RePatternObject pattern;
            if (arguments[0] is RePatternObject compiled)
            {
                ThrowIfCompiledFlags(arguments, 3, span, context);
                pattern = compiled;
                if (arguments.Length == 3)
                {
                    maxSplit = ParseOptionalIntOrDefault(arguments[2], 0, "maxsplit", signature, span, context);
                }
            }
            else
            {
                object[] patternArguments = arguments.Length >= 4 && !ReferenceEquals(arguments[3], PyNone.Instance)
                    ? [arguments[0], arguments[3]]
                    : [arguments[0]];
                pattern = CreatePattern(patternArguments, signature, span, context);
                if (arguments.Length >= 3)
                {
                    maxSplit = ParseOptionalIntOrDefault(arguments[2], 0, "maxsplit", signature, span, context);
                }
            }

            var splitRange = CreateSubjectRange(text, pos, endPos);
            return new RegexSplitInputs(pattern, splitRange, maxSplit);
        }

        // Regex bounds coerce through __index__ like CPython. Module-level
        // calls arrive binder-filled, where None marks an omitted optional,
        // while compiled-method calls pass raw values where explicit None is
        // rejected like any other non-integer. Out-of-ssize magnitudes report
        // the ssize_t overflow while int-range overflows keep the historical
        // out-of-range shape.
        internal static int ParseOptionalIntOrDefault(object? value, int defaultValue, string name, string signature, LythonSourceSpan span, ExecutionContext context)
        {
            if (value is null || ReferenceEquals(value, PyNone.Instance))
            {
                return defaultValue;
            }

            return ParseExplicitInt(value, name, signature, span, context);
        }

        internal static int ParseExplicitInt(object value, string name, string signature, LythonSourceSpan span, ExecutionContext context)
        {
            var integer = ParseBoundInteger(value, span, context);
            if (integer < int.MinValue || integer > int.MaxValue)
                throw new LythonRuntimeException("ValueError", $"{signature} {name} is out of range.", span);
            return (int)integer;
        }

        internal static int ParsePosition(object value, LythonSourceSpan span, ExecutionContext context)
            => (int)Math.Clamp(ParseBoundInteger(value, span, context), 0, int.MaxValue);

        private static int ParseOptionalPosition(object value, int fallback, LythonSourceSpan span, ExecutionContext context)
            => ReferenceEquals(value, PyNone.Instance) ? fallback : ParsePosition(value, span, context);

        private static long ParseBoundInteger(object? value, LythonSourceSpan span, ExecutionContext context)
        {
            var coerced = value is null ? null : LythonRuntime.CoerceIndexProtocol(value, context, span);
            BigInteger integer;
            if (coerced is bool flag)
            {
                integer = flag ? BigInteger.One : BigInteger.Zero;
            }
            else if (coerced is int small)
            {
                integer = new BigInteger(small);
            }
            else if (coerced is not BigInteger big)
            {
                throw new LythonRuntimeException("TypeError", "'" + RuntimeErrors.DatetimeQualifiedTypeName(value, context) + "' object cannot be interpreted as an integer", span);
            }
            else
            {
                integer = big;
            }

            if (integer > long.MaxValue || integer < long.MinValue)
            {
                throw new LythonRuntimeException("OverflowError", "Python int too large to convert to C ssize_t", span);
            }

            return (long)integer;
        }

        internal static RegexSubjectRange CreateSubjectRange(PyString text, int pos, int endPos)
        {
            var length = text.Length;
            return new RegexSubjectRange(text, Math.Clamp(pos, 0, length), Math.Clamp(endPos, 0, length));
        }

        // Flags flow through operator dispatch like CPython (sre fix_flags plus
        // the _code/_sre combines): verbose/locale/ascii checks, the unicode
        // combine, debug checks, then the state combines; the converted C int
        // carries unknown bits through to the echo.
        private static LythonRegexOptions ParseFlags(object value, LythonSourceSpan span, ExecutionContext context)
        {
            // Verbose parsing follows the dispatched bit like CPython.
            var verbose = IsTruthy(EvaluateBinaryOperator(BinaryOperatorSyntax.BitwiseAnd, value, new BigInteger(PythonVerboseFlag), context, span), context, span);
            if (IsTruthy(EvaluateBinaryOperator(BinaryOperatorSyntax.BitwiseAnd, value, new BigInteger(PythonLocaleFlag), context, span), context, span))
            {
                throw new LythonRuntimeException("ValueError", "cannot use LOCALE flag with a str pattern", span);
            }

            object stateFlags;
            if (!IsTruthy(EvaluateBinaryOperator(BinaryOperatorSyntax.BitwiseAnd, value, new BigInteger(PythonAsciiFlag), context, span), context, span))
            {
                stateFlags = OrAssignFlags(value, span, context);
            }
            else
            {
                if (IsTruthy(EvaluateBinaryOperator(BinaryOperatorSyntax.BitwiseAnd, value, new BigInteger(PythonUnicodeFlag), context, span), context, span))
                {
                    throw new LythonRuntimeException("ValueError", "ASCII and UNICODE flags are incompatible", span);
                }

                stateFlags = value;
            }

            // Debug checks run through dispatch like CPython; Lython cannot print,
            // so a set DEBUG bit stays NotImplementedError on the converted value.
            _ = EvaluateBinaryOperator(BinaryOperatorSyntax.BitwiseAnd, value, new BigInteger(RegexDebugFlag), context, span);
            var combined = EvaluateBinaryOperator(BinaryOperatorSyntax.BitwiseOr, stateFlags, value, context, span);
            _ = EvaluateBinaryOperator(BinaryOperatorSyntax.BitwiseAnd, value, new BigInteger(RegexDebugFlag), context, span);
            var flagBits = ToRegexCInt(EvaluateBinaryOperator(BinaryOperatorSyntax.BitwiseOr, value, combined, context, span), span, context);
            _ = EvaluateBinaryOperator(BinaryOperatorSyntax.BitwiseAnd, value, new BigInteger(RegexDebugFlag), context, span);

            if ((flagBits & RegexDebugFlag) != 0)
            {
                throw new LythonRuntimeException("NotImplementedError", "re.DEBUG is not supported by Lython's regex runtime.", span);
            }

            return new(flagBits, verbose);
        }

        // `flags |= UNICODE` like CPython. Only instances carry hooks, so only
        // they need the manual __ior__/__or__/__ror__ chain with `|=` text;
        // int-like values ride the shared binary shape, which cannot fail them.
        private static object OrAssignFlags(object flags, LythonSourceSpan span, ExecutionContext context)
        {
            var uni = new BigInteger(PythonUnicodeFlag);
            if (flags is PyInstance)
            {
                object? assigned;
                if (TryHookOrAssign(flags, "__ior__", uni, context, span, out assigned))
                {
                    return assigned.RequireNotNull();
                }

                if (TryHookOrAssign(flags, "__or__", uni, context, span, out assigned))
                {
                    return assigned.RequireNotNull();
                }

                if (TryHookOrAssign(uni, "__ror__", flags, context, span, out assigned))
                {
                    return assigned.RequireNotNull();
                }

                throw RuntimeErrors.UnsupportedOperands("|=", flags, uni, span);
            }

            return EvaluateBinaryOperator(BinaryOperatorSyntax.BitwiseOr, flags, uni, context, span);
        }

        private static bool TryHookOrAssign(object target, string method, object argument, ExecutionContext context, LythonSourceSpan span, out object? result)
        {
            if (TryInvokeBinarySpecialMethod(target, method, argument, context, span, out var value) && value is not PyNotImplemented)
            {
                result = value;
                return true;
            }

            result = null;
            return false;
        }

        // The converted C int carries unknown bits through; out-of-range
        // magnitudes report the C-int overflow while other shapes name the type.
        private static int ToRegexCInt(object value, LythonSourceSpan span, ExecutionContext context)
            => value switch
            {
                bool flag => flag ? 1 : 0,
                int small => small,
                BigInteger big when big >= int.MinValue && big <= int.MaxValue => (int)big,
                BigInteger => throw new LythonRuntimeException("OverflowError", "Python int too large to convert to C int", span),
                _ => throw new LythonRuntimeException("TypeError", "'" + RuntimeErrors.DatetimeQualifiedTypeName(value, context) + "' object cannot be interpreted as an integer", span),
            };

    }
}
