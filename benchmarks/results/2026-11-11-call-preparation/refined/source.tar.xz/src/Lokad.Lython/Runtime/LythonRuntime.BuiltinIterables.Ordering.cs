using System.Buffers;
using System.Globalization;
using System.Numerics;
using System.Text;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Numbers;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    private readonly record struct MinMaxArguments(
        IReadOnlyList<object> Positional,
        object? KeyArgument,
        OptionalValue<object> Default);

    private enum ExtremumOperation
    {
        Minimum,
        Maximum,
    }

    private static object Sorted(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length is < 1 or > 3)
        {
            throw new LythonRuntimeException("TypeError", "sorted(iterable[, key][, reverse]) expects one iterable and optional key/reverse arguments.", span);
        }

        // Materialize before resolving the key so one-time iterable effects precede
        // the key error, matching CPython. R13: an invalid key only fails when it
        // would actually be called, so empty input with a bad key succeeds.
        using var materialized = PyIteration.MaterializeLeased(arguments[0], span, context);

        var keyArgument = arguments.Length >= 2 ? arguments[1] : null;

        var reverse = false;
        if (arguments.Length >= 3)
        {
            reverse = IsTruthy(arguments[2], context, span);
        }

        using var items = SortItems(
            materialized.Items,
            keyArgument,
            reverse,
            span,
            context);

        var result = new PyList(items, context.MemoryGovernor, span);
        context.CheckExecution(span);
        return result;
    }

    private static async ValueTask<object> SortedAsync(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length is < 1 or > 3)
        {
            throw new LythonRuntimeException("TypeError", "sorted(iterable[, key][, reverse]) expects one iterable and optional key/reverse arguments.", span);
        }

        using var values = await PyIteration.MaterializeLeasedAsync(arguments[0], span, context).ConfigureAwait(false);
        var keyArgument = arguments.Length >= 2 ? arguments[1] : null;

        var reverse = false;
        if (arguments.Length >= 3)
        {
            reverse = await IsTruthyAsync(arguments[2], context, span).ConfigureAwait(false);
        }

        using var items = await SortItemsAsync(values.Items, keyArgument, reverse, span, context).ConfigureAwait(false);

        var result = new PyList(items, context.MemoryGovernor, span);
        context.CheckExecution(span);
        return result;
    }

    private static object MinMax(ReadOnlySpan<CallArgumentValue> arguments, ExtremumOperation operation, LythonSourceSpan span, ExecutionContext context)
    {
        var operationName = operation == ExtremumOperation.Minimum ? "min" : "max";
        var (positional, keyArgument, defaultValue) = BindMinMaxArguments(arguments, operationName, span);
        using var enumerator = (positional.Count == 1 ? ToSequence(positional[0], span, context) : positional).GetEnumerator();
        if (!enumerator.MoveNext())
        {
            if (defaultValue.HasValue)
            {
                return defaultValue.Value;
            }

            throw new LythonRuntimeException("ValueError", $"{operationName}() iterable argument is empty", span);
        }

        var best = enumerator.Current;
        var keyCallable = keyArgument as ICallable;
        if (keyArgument is not null && keyCallable is null)
        {
            throw new LythonRuntimeException("TypeError", "'" + RuntimeErrors.OperandTypeName(keyArgument) + "' object is not callable", span);
        }

        var bestKey = keyCallable is null
            ? best
            : CallableInvocation.InvokeUnary(keyCallable, best, span, context);
        while (enumerator.MoveNext())
        {
            var candidate = enumerator.Current;
            var candidateKey = keyCallable is null
                ? candidate
                : CallableInvocation.InvokeUnary(keyCallable, candidate, span, context);
            if (IsExtremumBetter(candidateKey, bestKey, operation, span, context))
            {
                best = candidate;
                bestKey = candidateKey;
            }
        }

        return best;
    }

    private static ValueTask<object> MinMaxAsync(ReadOnlySpan<CallArgumentValue> arguments, ExtremumOperation operation, LythonSourceSpan span, ExecutionContext context)
    {
        var operationName = operation == ExtremumOperation.Minimum ? "min" : "max";
        var (positional, keyArgument, defaultValue) = BindMinMaxArguments(arguments, operationName, span);
        return MinMaxAsyncPrepared(operation, span, context, operationName, positional, keyArgument, defaultValue);
    }
    private static async ValueTask<object> MinMaxAsyncPrepared(ExtremumOperation operation, LythonSourceSpan span, ExecutionContext context, string operationName, IReadOnlyList<object> positional, object? keyArgument, OptionalValue<object> defaultValue)
    {
        if (positional.Count > 1)
        {
            return await MinMaxValuesAsync(positional, keyArgument, operation, span, context).ConfigureAwait(false);
        }

        await using var cursor = await PyIteration.Cursor.CreateAsync(positional[0], span, context).ConfigureAwait(false);
        var (hasValue, best) = await cursor.TryMoveNextAsync().ConfigureAwait(false);
        if (!hasValue)
        {
            if (defaultValue.HasValue)
            {
                return defaultValue.Value;
            }

            throw new LythonRuntimeException("ValueError", $"{operationName}() iterable argument is empty", span);
        }

        var keyCallable = keyArgument as ICallable;
        if (keyArgument is not null && keyCallable is null)
        {
            throw new LythonRuntimeException("TypeError", "'" + RuntimeErrors.OperandTypeName(keyArgument) + "' object is not callable", span);
        }

        var bestKey = keyCallable is null ? best : await CallableInvocation.InvokeUnaryAsync(keyCallable, best, span, context).ConfigureAwait(false);
        while (true)
        {
            var (hasCandidate, candidate) = await cursor.TryMoveNextAsync().ConfigureAwait(false);
            if (!hasCandidate)
            {
                break;
            }

            var candidateKey = keyCallable is null ? candidate : await CallableInvocation.InvokeUnaryAsync(keyCallable, candidate, span, context).ConfigureAwait(false);
            if (await IsExtremumBetterAsync(candidateKey, bestKey, operation, span, context).ConfigureAwait(false))
            {
                best = candidate;
                bestKey = candidateKey;
            }
        }

        return best;
    }
    private static async ValueTask<object> MinMaxValuesAsync(
        IReadOnlyList<object> values,
        object? keyArgument,
        ExtremumOperation operation,
        LythonSourceSpan span,
        ExecutionContext context)
    {
        var keyCallable = keyArgument as ICallable;
        if (keyArgument is not null && keyCallable is null)
        {
            throw new LythonRuntimeException("TypeError", "'" + RuntimeErrors.OperandTypeName(keyArgument) + "' object is not callable", span);
        }

        var best = values[0];
        var bestKey = keyCallable is null
            ? best
            : await CallableInvocation.InvokeUnaryAsync(keyCallable, best, span, context).ConfigureAwait(false);
        for (var i = 1; i < values.Count; i++)
        {
            var candidate = values[i];
            var candidateKey = keyCallable is null
                ? candidate
                : await CallableInvocation.InvokeUnaryAsync(keyCallable, candidate, span, context).ConfigureAwait(false);
            if (await IsExtremumBetterAsync(candidateKey, bestKey, operation, span, context).ConfigureAwait(false))
            {
                best = candidate;
                bestKey = candidateKey;
            }
        }

        return best;
    }

    private static bool TryNumericExtremum(object candidate, object best, ExtremumOperation operation, out bool better)
    {
        if (PyNumberOps.TryAsNumber(candidate, out var left) && PyNumberOps.TryAsNumber(best, out var right))
        {
            var comparison = PyNumberOps.Compare(left, right);
            better = operation == ExtremumOperation.Minimum ? comparison < 0 : comparison > 0;
            return true;
        }
        better = false;
        return false;
    }

    private static bool IsExtremumBetter(object candidate, object best, ExtremumOperation operation,
        LythonSourceSpan span, ExecutionContext context)
    {
        if (TryNumericExtremum(candidate, best, operation, out var better)) return better;
        var result = EvaluateBinaryOperator(operation == ExtremumOperation.Minimum ? BinaryOperatorSyntax.Less : BinaryOperatorSyntax.Greater,
            candidate, best, context, span);
        return IsTruthy(result, context, span);
    }

    private static async ValueTask<bool> IsExtremumBetterAsync(object candidate, object best, ExtremumOperation operation,
        LythonSourceSpan span, ExecutionContext context)
    {
        if (TryNumericExtremum(candidate, best, operation, out var better)) return better;
        var result = await EvaluateBinaryOperatorAsync(operation == ExtremumOperation.Minimum ? BinaryOperatorSyntax.Less : BinaryOperatorSyntax.Greater,
            candidate, best, context, span).ConfigureAwait(false);
        return await IsTruthyAsync(result, context, span).ConfigureAwait(false);
    }

    private static MinMaxArguments BindMinMaxArguments(
        ReadOnlySpan<CallArgumentValue> arguments,
        string name,
        LythonSourceSpan span)
    {
        var positional = new List<object>();
        object? key = null;
        var sawKey = false;
        var defaultValue = OptionalValue<object>.Missing;
        foreach (var argument in arguments)
        {
            if (argument.IsPositional)
            {
                positional.Add(argument.Value);
                continue;
            }

            if (argument.KeywordName == "key")
            {
                if (sawKey)
                {
                    throw new LythonRuntimeException("TypeError", $"{name}() got multiple values for keyword argument 'key'", span);
                }

                sawKey = true;
                // R13: delay invalid-key errors until the key would actually be
                // called, so empty input with a bad key returns default/raises
                // ValueError instead of TypeError.
                key = ReferenceEquals(argument.Value, PyNone.Instance) ? null : argument.Value;
                continue;
            }

            if (argument.KeywordName == "default")
            {
                if (defaultValue.HasValue)
                {
                    throw new LythonRuntimeException("TypeError", $"{name}() got multiple values for keyword argument 'default'", span);
                }

                defaultValue = OptionalValue<object>.Present(argument.Value);
                continue;
            }

            throw new LythonRuntimeException("TypeError", $"{name}() got an unexpected keyword argument '{argument.KeywordName}'", span);
        }

        if (positional.Count == 0)
        {
            throw new LythonRuntimeException("TypeError", $"{name} expected at least 1 argument, got 0", span);
        }

        if (positional.Count > 1 && defaultValue.HasValue)
        {
            throw new LythonRuntimeException("TypeError", $"Cannot specify a default for {name}() with multiple positional arguments", span);
        }

        return new MinMaxArguments(positional, key, defaultValue);
    }

    private static bool IsSortKeyLessThan(object left, object right, LythonSourceSpan span, ExecutionContext context)
    {
        // Exact Python integers have no guest comparison slots. Avoid rich-slot
        // dispatch and a boxed boolean for this common key shape; mixed types
        // still use the Python comparison/truthiness path below.
        if (left is BigInteger leftInteger && right is BigInteger rightInteger)
        {
            return leftInteger < rightInteger;
        }

        if (left is PyCmpKey leftKey &&
            right is PyCmpKey rightKey)
        {
            return IsTruthy(leftKey.Compare(rightKey, "__lt__", span, context), context, span);
        }

        // N11: ordering returns raw results; sort order truth-tests like CPython.
        return IsTruthy(EvaluateRichComparison(left, right, BinaryOperatorSyntax.Less, context, span), context, span);
    }

    private static async ValueTask<bool> IsSortKeyLessThanAsync(object left, object right, LythonSourceSpan span, ExecutionContext context)
    {
        if (left is BigInteger leftInteger && right is BigInteger rightInteger)
        {
            return leftInteger < rightInteger;
        }

        if (left is PyCmpKey leftKey &&
            right is PyCmpKey rightKey)
        {
            return await IsTruthyAsync(await leftKey.CompareAsync(rightKey, "__lt__", span, context).ConfigureAwait(false), context, span).ConfigureAwait(false);
        }

        return await IsTruthyAsync(await EvaluateRichComparisonAsync(left, right, BinaryOperatorSyntax.Less, context, span).ConfigureAwait(false), context, span).ConfigureAwait(false);
    }

    private static PyStableSort.Buffer SortItems(
        IEnumerable<object> values,
        object? keyArgument,
        bool reverse,
        LythonSourceSpan span,
        ExecutionContext context)
    {
        var entries = new PyStableSort.Buffer(context.MemoryGovernor, span);
        try
        {
            var keyCallable = keyArgument as ICallable;
            var keyInvalid = keyArgument is not null &&
                !ReferenceEquals(keyArgument, PyNone.Instance) &&
                keyCallable is null;
            foreach (var item in values)
            {
                // R13: an invalid key fails only when it would actually be called.
                if (keyInvalid)
                {
                    throw new LythonRuntimeException("TypeError", "'" + RuntimeErrors.OperandTypeName(keyArgument) + "' object is not callable", span);
                }

                entries.Add(
                    new PyStableSort.Entry(
                        item,
                        keyCallable is null
                            ? item
                            : CallableInvocation.InvokeUnary(keyCallable, item, span, context)),
                    span);
                context.CheckExecution(span);
            }

            entries.Sort(
                reverse,
                (left, right) => IsSortKeyLessThan(left, right, span, context), context, span);
            return entries;
        }
        catch
        {
            entries.Dispose();
            throw;
        }
    }

    private static async ValueTask<PyStableSort.Buffer> SortItemsAsync(
        IEnumerable<object> values,
        object? keyArgument,
        bool reverse,
        LythonSourceSpan span,
        ExecutionContext context)
    {
        var entries = new PyStableSort.Buffer(context.MemoryGovernor, span);
        try
        {
            var keyCallable = keyArgument as ICallable;
            var keyInvalid = keyArgument is not null &&
                !ReferenceEquals(keyArgument, PyNone.Instance) &&
                keyCallable is null;
            foreach (var item in values)
            {
                // R13: an invalid key fails only when it would actually be called.
                if (keyInvalid)
                {
                    throw new LythonRuntimeException("TypeError", "'" + RuntimeErrors.OperandTypeName(keyArgument) + "' object is not callable", span);
                }

                entries.Add(
                    new PyStableSort.Entry(
                        item,
                        keyCallable is null
                            ? item
                            : await CallableInvocation.InvokeUnaryAsync(keyCallable, item, span, context).ConfigureAwait(false)),
                    span);
                context.CheckExecution(span);
            }

            await entries.SortAsync(
                    reverse,
                    (left, right) => IsSortKeyLessThanAsync(left, right, span, context), context, span)
                .ConfigureAwait(false);
            return entries;
        }
        catch
        {
            entries.Dispose();
            throw;
        }
    }

}
