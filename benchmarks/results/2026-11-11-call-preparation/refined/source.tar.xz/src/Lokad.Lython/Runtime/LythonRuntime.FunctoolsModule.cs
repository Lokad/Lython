using System.Numerics;
using Lokad.Lython.Runtime.Numbers;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    private static readonly string[] FunctoolsWrapperAssignmentNames =
    [
        "__module__",
        "__name__",
        "__qualname__",
        "__doc__",
        "__annotations__",
        "__type_params__"
    ];

    private static readonly string[] FunctoolsWrapperUpdateNames = ["__dict__"];
    private static readonly PyTuple FunctoolsWrapperAssignments = CreateStringTuple(FunctoolsWrapperAssignmentNames);
    private static readonly PyTuple FunctoolsWrapperUpdates = CreateStringTuple(FunctoolsWrapperUpdateNames);

    private static readonly OrderingMethod[] OrderingMethods =
        [OrderingMethod.Lt, OrderingMethod.Le, OrderingMethod.Gt, OrderingMethod.Ge];

    private static bool TryReadFunctoolsMetadata(PyDict? metadata, string name, MemoryGovernor owner,
        LythonSourceSpan? span, ExecutionContext? context, [MaybeNullWhen(false)] out object value)
    {
        if (metadata is null) { value = PyNone.Instance; return false; }
        return metadata.TryGetStringValue(name, context?.MemoryGovernor ?? owner, span, context, out value);
    }

    private static bool SetFunctoolsMetadata(ref PyDict? metadata, string name, object value,
        MemoryGovernor governor, LythonSourceSpan? span)
    {
        if (name == "__dict__")
        {
            if (value is not PyDict dictionary)
                throw new LythonRuntimeException("TypeError", "__dict__ must be set to a dictionary", span);
            // The old dictionary can have live aliases. Its owner keeps it funded.
            metadata = dictionary;
            return true;
        }
        metadata ??= new PyDict(governor, span);
        StoreFunctoolsStringKey(metadata, name, value, governor, span);
        return true;
    }

    private static void StoreFunctoolsStringKey(PyDict dictionary, string name, object value,
        MemoryGovernor governor, LythonSourceSpan? span)
    {
        dictionary.SetStringItem(name, value, governor, span);
    }

    private sealed class FunctoolsModule : PyModule
    {
        public static readonly FunctoolsModule Instance = new();

        private FunctoolsModule() : base("functools")
        {
        }

        public override bool TryGetMember(string name, [MaybeNullWhen(false)] out object value)
        {
            value = name switch
            {
                "WRAPPER_ASSIGNMENTS" => FunctoolsWrapperAssignments,
                "WRAPPER_UPDATES" => FunctoolsWrapperUpdates,
                "Placeholder" => UnsupportedPartialPlaceholder.Instance,
                "update_wrapper" => UpdateWrapperCallable.Instance,
                "wraps" => WrapsCallable.Instance,
                "total_ordering" => BuiltinCallable.Create(LythonKnownCallableSignatures.FunctoolsTotalOrdering, TotalOrdering, TotalOrderingAsync),
                "reduce" => BuiltinCallable.Create(LythonKnownCallableSignatures.FunctoolsReduce, Reduce, ReduceAsync),
                "partial" => PartialFactory.Instance,
                "partialmethod" => PartialMethodFactory.Instance,
                "cmp_to_key" => BuiltinCallable.Create(LythonKnownCallableSignatures.FunctoolsCmpToKey, CmpToKey),
                "lru_cache" => LruCacheFactory.Instance,
                "cache" => CacheFactory.Instance,
                "cached_property" => CachedPropertyFactory.Instance,
                "singledispatch" => SingleDispatchFactory.Instance,
                "singledispatchmethod" => SingleDispatchMethodFactory.Instance,
                "recursive_repr" => RecursiveReprFactory.Instance,
                _ => MissingMemberValue.Instance,
            };

            return !ReferenceEquals(value, MissingMemberValue.Instance);
        }
    }

    private sealed class UnsupportedPartialPlaceholder : IPyRenderableValue, IPyHashableValue
    {
        public static readonly UnsupportedPartialPlaceholder Instance = new();

        public int GetPyHashCode() => 0x5F3759DF;

        public PyString RenderPython(PyRenderingContext context)
        {
            _ = context;
            return PyString.FromString("functools.Placeholder");
        }

        public PyString RenderInterpolated(PyRenderingContext context) => RenderPython(context);
    }

    private static PyTuple CreateStringTuple(IReadOnlyList<string> values)
        => new(values.Select(PyString.FromString).Cast<object>());

}
