using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Calls;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal static async ValueTask<LoweredBlockFlow> ExecuteStatementsAsync(IReadOnlyList<LoweredStatement> statements, ExecutionContext context)
    {
        try
        {
            foreach (var statement in statements)
            {
                var flow = await DispatchLoweredStatementAsync(statement, context, AsynchronousLoweredStatementExecution.Instance).ConfigureAwait(false);
                if (flow.Return is not null)
                {
                    return flow;
                }
            }

            return default;
        }
        catch (LythonRuntimeException ex)
        {
            ex.SetSourcePathIfMissing(context.SourcePath);
            throw;
        }
        catch (ControlSignal signal)
        {
            return new LoweredBlockFlow(signal, null);
        }
    }

    private static async ValueTask ExecuteLoweredFunctionDefinitionAsync(LoweredFunctionDefinitionStatement functionDefinition, ExecutionContext context)
    {
        context.EnterInterpreterFrame(functionDefinition.Span);
        try
        {
            using var decoratorStorage = context.MemoryGovernor.ReserveTemporary(EstimateObjectArrayBytes(functionDefinition.Decorators.Count), functionDefinition.Span);
            var decorators = await EvaluateDecoratorsAsync(functionDefinition.Decorators, context).ConfigureAwait(false);
            var syntax = functionDefinition.Syntax;
            var defaultCount = functionDefinition.Parameters.Count(static p => p.DefaultValue is not null);
            using var defaultStorage = ReserveDefaultArgumentsWorkingStorage(defaultCount, context.MemoryGovernor, functionDefinition.Span);
            var defaults = await EvaluateFunctionDefaults(functionDefinition.Parameters, defaultCount, context, true).ConfigureAwait(false);
            var typeScope = CreateTypeScope(functionDefinition.TypeParameters, context, functionDefinition.Span);
            var function = CreateLoweredFunction(functionDefinition, typeScope.Closure, defaults);
            await AttachTypeMetadataAsync(function, functionDefinition.Parameters, functionDefinition.ReturnAnnotation,
                functionDefinition.TypeParameters is not null, functionDefinition.Span, typeScope, context, true).ConfigureAwait(false);
            StoreName(
                syntax.Name,
                await ApplyDecoratorsAsync(function, decorators, functionDefinition.Span, context).ConfigureAwait(false),
                context,
                functionDefinition.Span);
        }
        finally
        {
            context.LeaveInterpreterFrame();
        }
    }

    private static async ValueTask ExecuteLoweredClassDefinitionAsync(LoweredClassDefinitionStatement classDefinition, ExecutionContext context)
    {
        context.EnterInterpreterFrame(classDefinition.Span);
        try
        {
            using var decoratorStorage = context.MemoryGovernor.ReserveTemporary(EstimateObjectArrayBytes(classDefinition.Decorators.Count), classDefinition.Span);
            var decorators = await EvaluateDecoratorsAsync(classDefinition.Decorators, context).ConfigureAwait(false);
            var typeScope = CreateTypeScope(classDefinition.TypeParameters, context, classDefinition.Span);
            var header = await EvaluateClassHeaderArgumentsAsync(classDefinition, typeScope.Annotations, decoratorStorage, true).ConfigureAwait(false);
            var baseTypes = header.Bases;
            var classKeywordArguments = header.Keywords;

            var resolvedBases = AddGenericClassBase(classDefinition, ResolveClassBases(baseTypes, classDefinition.Span, context), context);
            ValidateClassKeywordArguments(classKeywordArguments, classDefinition.Span);

            var classContext = ExecutionContext.CreateClassBody(typeScope.Closure, classDefinition.Syntax);
            var classFlow = await ExecuteStatementsAsync(classDefinition.Body, classContext).ConfigureAwait(false);
            if (classFlow.Control is not null)
            {
                throw new LythonRuntimeException("RuntimeError", "Loop control cannot escape a class body.", classDefinition.Span);
            }

            if (classFlow.Return is not null)
            {
                throw classFlow.Return;
            }

            await AttachGenericClassMetadataAsync(classDefinition, typeScope, classContext, true, baseTypes).ConfigureAwait(false);
            var type = await CreateLoweredClassType(classDefinition, resolvedBases, baseTypes, classKeywordArguments, classContext, context,true).ConfigureAwait(false);
            if (classContext.ClassCell is { } classCell) classCell.Value = type;
            if (type is PyType defined)
            {
                await InvokeInitSubclassAsync(defined, classKeywordArguments, classDefinition.Span, context).ConfigureAwait(false);
            }
            StoreName(
                classDefinition.Syntax.Name,
                await ApplyDecoratorsAsync(type, decorators, classDefinition.Span, context).ConfigureAwait(false),
                context,
                classDefinition.Span);
        }
        finally
        {
            context.LeaveInterpreterFrame();
        }
    }

    private static async ValueTask<object[]> EvaluateDecoratorsAsync(IReadOnlyList<LoweredExpression> expressions, ExecutionContext context)
    {
        var values = new object[expressions.Count];
        for (var i = 0; i < expressions.Count; i++)
        {
            values[i] = await EvaluateLoweredExpressionAsync(expressions[i], context).ConfigureAwait(false);
        }
        return values;
    }

    private static async ValueTask<object> ApplyDecoratorsAsync(object value, IReadOnlyList<object> decorators, LythonSourceSpan span, ExecutionContext context)
    {
        object current = value;
        for (var i = decorators.Count - 1; i >= 0; i--)
        {
            var decorator = decorators[i];
            if (decorator is not ICallable callable)
            {
                throw new LythonRuntimeException("TypeError", "Decorator expression must evaluate to a callable.", span);
            }

            current = await CallableInvocation.InvokeUnaryAsync(callable, current, span, context).ConfigureAwait(false);
        }

        return current;
    }

    private static async ValueTask ExecuteLoweredIfStatementAsync(LoweredIfStatement statement, ExecutionContext context)
    {
        context.EnterInterpreterFrame(statement.Span);
        try
        {
            var branch = await IsTruthyAsync(
                    await EvaluateLoweredExpressionAsync(statement.Condition, context).ConfigureAwait(false),
                    context,
                    statement.Condition.Span)
                .ConfigureAwait(false)
                ? statement.ThenStatements
                : statement.ElseStatements;

            if (branch is not null)
            {
                var branchFlow = await ExecuteStatementsAsync(branch, context).ConfigureAwait(false);
                if (branchFlow.Control is not null)
                {
                    throw branchFlow.Control;
                }

                if (branchFlow.Return is not null)
                {
                    throw branchFlow.Return;
                }
            }
        }
        finally
        {
            context.LeaveInterpreterFrame();
        }
    }

    private static async ValueTask ExecuteLoweredForStatementAsync(LoweredForStatement statement, ExecutionContext context)
    {
        context.EnterInterpreterFrame(statement.Span);
        try
        {
            var syntax = statement.Syntax;
            var iterable = await EvaluateLoweredExpressionAsync(statement.Iterable, context).ConfigureAwait(false);
            var broke = false;
            await foreach (var item in ToSequenceAsync(iterable, statement.Iterable.Span, context).ConfigureAwait(false))
            {
                context.CheckExecution(statement.Span);
                await AssignLoopTargetAsync(syntax.Target, item, statement.Iterable.Span, context).ConfigureAwait(false);
                var bodyFlow = await ExecuteStatementsAsync(statement.Body, context).ConfigureAwait(false);
                if (bodyFlow.Control is ContinueSignal)
                {
                    continue;
                }

                if (bodyFlow.Control is BreakSignal)
                {
                    broke = true;
                    break;
                }
                if (bodyFlow.Return is not null)
                {
                    throw bodyFlow.Return;
                }
            }

            if (!broke && statement.ElseStatements is not null)
            {
                var elseFlow = await ExecuteStatementsAsync(statement.ElseStatements, context).ConfigureAwait(false);
                if (elseFlow.Control is not null)
                {
                    throw elseFlow.Control;
                }

                if (elseFlow.Return is not null)
                {
                    throw elseFlow.Return;
                }
            }
        }
        finally
        {
            context.LeaveInterpreterFrame();
        }
    }

    private static async ValueTask ExecuteLoweredWhileStatementAsync(LoweredWhileStatement statement, ExecutionContext context)
    {
        context.EnterInterpreterFrame(statement.Span);
        try
        {
            var broke = false;
            while (await IsTruthyAsync(
                    await EvaluateLoweredExpressionAsync(statement.Condition, context).ConfigureAwait(false),
                    context,
                    statement.Condition.Span)
                .ConfigureAwait(false))
            {
                var bodyFlow = await ExecuteStatementsAsync(statement.Body, context).ConfigureAwait(false);
                if (bodyFlow.Control is ContinueSignal)
                {
                    continue;
                }

                if (bodyFlow.Control is BreakSignal)
                {
                    broke = true;
                    break;
                }
                if (bodyFlow.Return is not null)
                {
                    throw bodyFlow.Return;
                }
            }

            if (!broke && statement.ElseStatements is not null)
            {
                var elseFlow = await ExecuteStatementsAsync(statement.ElseStatements, context).ConfigureAwait(false);
                if (elseFlow.Control is not null)
                {
                    throw elseFlow.Control;
                }

                if (elseFlow.Return is not null)
                {
                    throw elseFlow.Return;
                }
            }
        }
        finally
        {
            context.LeaveInterpreterFrame();
        }
    }

    private static async ValueTask ExecuteLoweredMatchStatementAsync(LoweredMatchStatement statement, ExecutionContext context)
    {
        context.EnterInterpreterFrame(statement.Span);
        try
        {
            var subject = await EvaluateLoweredExpressionAsync(statement.Subject, context).ConfigureAwait(false);
            foreach (var matchCase in statement.Cases)
            {
                if (!TryExecuteLoweredPattern(matchCase.Pattern, subject, context))
                    continue;

                if (matchCase.Guard is { } guard)
                {
                    var guardValue = await EvaluateLoweredExpressionAsync(guard, context).ConfigureAwait(false);
                    if (!await IsTruthyAsync(guardValue, context, guard.Span).ConfigureAwait(false))
                        continue;
                }

                var flow = await ExecuteStatementsAsync(matchCase.Body, context).ConfigureAwait(false);
                if (flow.Return is not null) throw flow.Return;
                if (flow.Control is not null) throw flow.Control;
                return;
            }
        }
        finally
        {
            context.LeaveInterpreterFrame();
        }
    }

    private static async ValueTask ExecuteLoweredWithStatementAsync(LoweredWithStatement statement, ExecutionContext context)
    {
        context.EnterInterpreterFrame(statement.Span);
        try
        {
            await ExecuteWithStatementAsync(statement.Syntax, statement.ContextExpression, statement.Body, context).ConfigureAwait(false);
        }
        finally
        {
            context.LeaveInterpreterFrame();
        }
    }

    private static async ValueTask ExecuteLoweredTryStatementAsync(LoweredTryStatement statement, ExecutionContext context)
    {
        context.EnterInterpreterFrame(statement.Span);
        try
        {
            var flow = await ExecuteTryStatementCoreAsync(statement, context, ExecuteStatementsAsync,
                expression => EvaluateLoweredExpressionAsync(expression, context)).ConfigureAwait(false);
            if (flow.Control is not null)
            {
                throw flow.Control;
            }

            if (flow.Return is not null)
            {
                throw flow.Return;
            }
        }
        finally
        {
            context.LeaveInterpreterFrame();
        }
    }

    // Assignments do not track interpreter depth (MG25): depth is tracked
    // once per Python nesting level (calls, bodies, compound statements), and
    // assignment targets nest shallowly enough for the frontend bound plus the
    // stack probe. Cancellation checks remain on every statement.
    private static async ValueTask ExecuteLoweredAssignmentAsync(LoweredAssignmentStatement assignment, ExecutionContext context)
    {
        context.CheckExecution(assignment.Span);
        switch (assignment)
            {
                case LoweredNameAssignmentStatement simple:
                    StoreName(simple.Assignment.Name, await EvaluateLoweredExpressionAsync(simple.Expression, context).ConfigureAwait(false), context, simple.Span);
                    return;
                case LoweredChainedAssignmentStatement chained:
                    var chainedValue = await EvaluateLoweredExpressionAsync(chained.Expression, context).ConfigureAwait(false);
                    foreach (var assignmentTarget in chained.Targets)
                    {
                        await AssignTargetAsync(assignmentTarget, chainedValue, context).ConfigureAwait(false);
                    }
                    return;
                case LoweredAnnotatedAssignmentStatement annotated:
                    if (annotated.Expression is not null)
                    {
                        await AssignTargetAsync(annotated.Target, await EvaluateLoweredExpressionAsync(annotated.Expression, context).ConfigureAwait(false), context).ConfigureAwait(false);
                    }
                    else await EvaluateAnnotationTargetReadsAsync(annotated, context, true).ConfigureAwait(false);
                    await StoreVariableAnnotationAsync(annotated, context, true).ConfigureAwait(false);
                    return;
                case LoweredAugmentedAssignmentStatement augmented:
                    var augmentedTarget = await ResolveLoweredAugmentedAssignmentTargetAsync(augmented.Target, context).ConfigureAwait(false);
                    await augmentedTarget.StoreValueAsync(await EvaluateAugmentedAssignmentAsync(
                        augmentedTarget.CurrentValue,
                        await EvaluateLoweredExpressionAsync(augmented.Expression, context).ConfigureAwait(false),
                        augmented.Assignment.Operator,
                        context,
                        augmented.Span).ConfigureAwait(false)).ConfigureAwait(false);
                    return;
                case LoweredUnpackingAssignmentStatement unpacking:
                    await AssignTargetAsync(
                        unpacking.Target,
                        await EvaluateLoweredExpressionAsync(unpacking.Expression, context).ConfigureAwait(false),
                        context).ConfigureAwait(false);
                    return;
                case LoweredSubscriptAssignmentStatement subscript:
                    await ExecuteLoweredSubscriptAssignmentAsync(
                            subscript.Assignment,
                            subscript.Receiver,
                            subscript.Index,
                            await EvaluateLoweredExpressionAsync(subscript.Expression, context).ConfigureAwait(false),
                            context)
                        .ConfigureAwait(false);
                    return;
                case LoweredSliceAssignmentStatement slice:
                    await ExecuteLoweredSliceAssignmentAsync(
                            slice.Assignment,
                            slice.Receiver,
                            slice.Start,
                            slice.End,
                            slice.Step,
                            await EvaluateLoweredExpressionAsync(slice.Expression, context).ConfigureAwait(false),
                            context)
                        .ConfigureAwait(false);
                    return;
                case LoweredMemberAssignmentStatement member:
                    var value = await EvaluateLoweredExpressionAsync(member.Expression, context).ConfigureAwait(false);
                    var target = await EvaluateLoweredExpressionAsync(member.Receiver, context).ConfigureAwait(false);
                    if (!await PyMemberAccess.TryAssignAsync(target, member.Assignment.MemberName, value, context, member.Span).ConfigureAwait(false))
                    {
                        throw new LythonRuntimeException("TypeError", "Object does not support attribute assignment.", member.Span);
                    }
                    return;
                default:
                    throw new InvalidOperationException($"Unsupported lowered assignment: {assignment.GetType().Name}");
            }
    }

    private static async ValueTask<AugmentedAssignmentTargetReference> ResolveLoweredAugmentedAssignmentTargetAsync(
        LoweredAugmentedAssignmentTarget target,
        ExecutionContext context)
    {
        switch (target)
        {
            case LoweredNameAugmentedAssignmentTarget name:
                return ResolveAugmentedAssignmentTarget(name.Target, context);

            case LoweredSubscriptAugmentedAssignmentTarget subscript:
                var subscriptTarget = await EvaluateLoweredExpressionAsync(subscript.Receiver, context).ConfigureAwait(false);
                var index = await EvaluateLoweredExpressionAsync(subscript.Index, context).ConfigureAwait(false);
                var subscriptValue = await ReadLoweredSubscriptAsync(subscriptTarget, index, subscript.Span, context).ConfigureAwait(false);
                return new AugmentedAssignmentTargetReference(
                    subscriptValue,
                    value => SetSubscriptValue(subscriptTarget, index, value, subscript.Span, context),
                    value => SetHeaderSubscriptAsync(subscriptTarget, index, value, subscript.Span, context));

            case LoweredSliceAugmentedAssignmentTarget slice:
                var sliceTarget = await EvaluateLoweredExpressionAsync(slice.Receiver, context).ConfigureAwait(false);
                var start = slice.Start is null
                    ? null
                    : await EvaluateLoweredExpressionAsync(slice.Start, context).ConfigureAwait(false);
                var end = slice.End is null
                    ? null
                    : await EvaluateLoweredExpressionAsync(slice.End, context).ConfigureAwait(false);
                var step = slice.Step is null
                    ? null
                    : await EvaluateLoweredExpressionAsync(slice.Step, context).ConfigureAwait(false);
                var sliceIndex = sliceTarget is PyInstance
                    ? CreateSliceValue(start, end, step, slice.Span, context)
                    : (object)PyNone.Instance;
                var sliceValue = sliceTarget is PyInstance sliceInstance
                    ? await GetUserItemAsync(sliceInstance, sliceIndex, context, slice.Span).ConfigureAwait(false)
                    : await ReadSliceValueAsync(sliceTarget, start, end, step, slice.Span, context).ConfigureAwait(false);
                return new AugmentedAssignmentTargetReference(
                    sliceValue,
                    value => ExecuteSliceAssignment(sliceTarget, start, end, step, value, slice.Span, context),
                    sliceTarget is PyInstance ? value => SetHeaderSubscriptAsync(sliceTarget, sliceIndex, value, slice.Span, context)
                        : value => ExecuteSliceAssignmentAsync(sliceTarget, start, end, step, value, slice.Span, context));

            case LoweredMemberAugmentedAssignmentTarget member:
                var memberTarget = await EvaluateLoweredExpressionAsync(member.Receiver, context).ConfigureAwait(false);
                var resolvedMember = await TryResolveRuntimeMemberAsync(memberTarget, member.Target.MemberName, context, member.Span).ConfigureAwait(false);
                if (!resolvedMember.Found)
                {
                    throw PyMemberAccess.CreateMissingMemberError(memberTarget, member.Target.MemberName, member.Span, context);
                }

                return new AugmentedAssignmentTargetReference(
                    resolvedMember.Value,
                    value => SetMemberValue(memberTarget, member.Target.MemberName, value, member.Span, context),
                    async value =>
                    {
                        if (!await PyMemberAccess.TryAssignAsync(memberTarget, member.Target.MemberName, value, context, member.Span).ConfigureAwait(false))
                            throw new LythonRuntimeException("TypeError", "Object does not support attribute assignment", member.Span);
                    });

            default:
                throw new InvalidOperationException($"Unsupported lowered augmented target: {target.GetType().Name}");
        }
    }

    private static async ValueTask ExecuteLoweredSliceAssignmentAsync(
        SliceAssignmentStatementSyntax statement,
        LoweredExpression targetExpression,
        LoweredExpression? startExpression,
        LoweredExpression? endExpression,
        LoweredExpression? stepExpression,
        object value,
        ExecutionContext context)
    {
        var target = await EvaluateLoweredExpressionAsync(targetExpression, context).ConfigureAwait(false);
        var start = startExpression is null ? null : await EvaluateLoweredExpressionAsync(startExpression, context).ConfigureAwait(false);
        var end = endExpression is null ? null : await EvaluateLoweredExpressionAsync(endExpression, context).ConfigureAwait(false);
        var step = stepExpression is null ? null : await EvaluateLoweredExpressionAsync(stepExpression, context).ConfigureAwait(false);
        await ExecuteSliceAssignmentAsync(target, start, end, step, value, statement.Span, context).ConfigureAwait(false);
    }

    private static async ValueTask ExecuteLoweredSubscriptAssignmentAsync(
        SubscriptAssignmentStatementSyntax statement,
        LoweredExpression targetExpression,
        LoweredExpression indexExpression,
        object value,
        ExecutionContext context)
    {
        var target = await EvaluateLoweredExpressionAsync(targetExpression, context).ConfigureAwait(false);
        var index = await EvaluateLoweredExpressionAsync(indexExpression, context).ConfigureAwait(false);
        await SetHeaderSubscriptAsync(target, index, value, statement.Span, context).ConfigureAwait(false);
    }
}
