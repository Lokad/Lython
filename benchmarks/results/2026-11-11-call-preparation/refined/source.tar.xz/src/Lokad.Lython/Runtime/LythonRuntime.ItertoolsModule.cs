using System.Numerics;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    private readonly record struct PredicateIteratorBinding(object Predicate, object Iterable);

    private sealed class ItertoolsModule : PyModule
    {
        public static readonly ItertoolsModule Instance = new();

        private ItertoolsModule() : base("itertools")
        {
        }

        public override bool TryGetMember(string name, [MaybeNullWhen(false)] out object value)
        {
            value = name switch
            {
                "chain" => ChainFactory.Instance,
                "count" => new ItertoolsCallable("itertools.count", Count),
                "repeat" => new ItertoolsCallable("itertools.repeat", Repeat, RepeatAsync),
                "cycle" => new ItertoolsCallable("itertools.cycle", Cycle, CycleAsync),
                "islice" => new ItertoolsCallable("itertools.islice", Islice, IsliceAsync),
                "product" => new ItertoolsCallable("itertools.product", Product, ProductAsync),
                "zip_longest" => new ItertoolsCallable("itertools.zip_longest", ZipLongest, ZipLongestAsync),
                "combinations" => new ItertoolsCallable("itertools.combinations", Combinations, CombinationsAsync),
                "combinations_with_replacement" => new ItertoolsCallable("itertools.combinations_with_replacement", CombinationsWithReplacement, CombinationsWithReplacementAsync),
                "permutations" => new ItertoolsCallable("itertools.permutations", Permutations, PermutationsAsync),
                "accumulate" => new ItertoolsCallable("itertools.accumulate", Accumulate, AccumulateAsync),
                "compress" => new ItertoolsCallable("itertools.compress", Compress, CompressAsync),
                "filterfalse" => new ItertoolsCallable("itertools.filterfalse", FilterFalse, FilterFalseAsync),
                "dropwhile" => new ItertoolsCallable("itertools.dropwhile", DropWhile, DropWhileAsync),
                "takewhile" => new ItertoolsCallable("itertools.takewhile", TakeWhile, TakeWhileAsync),
                "starmap" => new ItertoolsCallable("itertools.starmap", Starmap, StarmapAsync),
                "pairwise" => new ItertoolsCallable("itertools.pairwise", Pairwise, PairwiseAsync),
                "groupby" => new ItertoolsCallable("itertools.groupby", GroupBy, GroupByAsync),
                "tee" => new ItertoolsCallable("itertools.tee", Tee, TeeAsync),
                "batched" => new ItertoolsCallable("itertools.batched", Batched, BatchedAsync),
                _ => MissingMemberValue.Instance,
            };

            return !ReferenceEquals(value, MissingMemberValue.Instance);
        }
    }

    internal sealed class ChainFactory : ICallable, IPyRenderableValue
    {
        public static readonly ChainFactory Instance = new();

        // itertools.chain denotes a type like CPython.
        public PyString RenderPython(PyRenderingContext context)
        {
            _ = context;
            return PyString.FromString("<class 'itertools.chain'>");
        }

        public PyString RenderInterpolated(PyRenderingContext context) => RenderPython(context);

        public object Invoke(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        {
            context.CheckExecution(span);
            for (var i = 0; i < arguments.Length; i++)
            {
                if (arguments[i].IsKeyword)
                {
                    throw new LythonRuntimeException("TypeError", "itertools.chain(...) does not accept keyword arguments.", span);
                }

            }

            return PyChainIterator.FromSources(arguments, span, context);
        }

        public bool TryGetMember(string name, [MaybeNullWhen(false)] out object value)
        {
            value = name switch
            {
                "from_iterable" => new ItertoolsCallable("itertools.chain.from_iterable", FromIterable, FromIterableAsync),
                _ => MissingMemberValue.Instance,
            };

            return !ReferenceEquals(value, MissingMemberValue.Instance);
        }

        private static object FromIterable(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
            => FromIterableCoreAsync(PositionalOnly(arguments, "itertools.chain.from_iterable", span), span, context, false).GetAwaiter().GetResult();
        private static ValueTask<object> FromIterableAsync(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
            => FromIterableCoreAsync(PositionalOnly(arguments, "itertools.chain.from_iterable", span), span, context, true);
        private static async ValueTask<object> FromIterableCoreAsync(object[] positional, LythonSourceSpan span,
            ExecutionContext context, bool asynchronous)
        {
            if (positional.Length != 1)
                throw new LythonRuntimeException("TypeError", "itertools.chain.from_iterable(iterable) expects one iterable argument.", span);
            return await PyChainIterator.FromIterableAsync(positional[0], span, context, asynchronous).ConfigureAwait(false);
        }
    }

    private sealed class ItertoolsCallable : ICallable, IPyRenderableValue
    {
        private readonly string _name;
        private readonly Func<ReadOnlySpan<CallArgumentValue>, LythonSourceSpan, ExecutionContext, object> _implementation;
        private readonly Func<ReadOnlySpan<CallArgumentValue>, LythonSourceSpan, ExecutionContext, ValueTask<object>>? _asyncImplementation;

        public ItertoolsCallable(string name, Func<ReadOnlySpan<CallArgumentValue>, LythonSourceSpan, ExecutionContext, object> implementation) : this(name, implementation, null) { }

        public ItertoolsCallable(
            string name,
            Func<ReadOnlySpan<CallArgumentValue>, LythonSourceSpan, ExecutionContext, object> implementation,
            Func<ReadOnlySpan<CallArgumentValue>, LythonSourceSpan, ExecutionContext, ValueTask<object>>? asyncImplementation)
        {
            _name = name;
            _implementation = implementation;
            _asyncImplementation = asyncImplementation;
        }

        public object Invoke(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        {
            context.CheckExecution(span);
            return _implementation(arguments, span, context);
        }

        public ValueTask<object> InvokeAsync(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
            => InvokeBorrowedAsync(arguments, span, context);

        public ValueTask<object> InvokeBorrowedAsync(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        {
            context.CheckExecution(span);
            return _asyncImplementation is null ? new(_implementation(arguments, span, context))
                : _asyncImplementation(arguments, span, context);
        }

        // itertools factories denote types like CPython, except tee (a plain
        // builtin function) and chain.from_iterable (a builtin method of type).
        public PyString RenderPython(PyRenderingContext context)
        {
            _ = context;
            return PyString.FromString(BuiltinCallable.ShortCallableName(_name) switch
            {
                "tee" => "<built-in function tee>",
                "from_iterable" => "<built-in method from_iterable of type object>",
                _ => $"<class '{_name}'>",
            });
        }

        public PyString RenderInterpolated(PyRenderingContext context) => RenderPython(context);
    }

    private static object Count(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
    {
        var bound = BindArguments(arguments, LythonKnownCallableSignatures.ItertoolsCount, span);
        var start = bound.Assigned[0] ? ExpectNumber(bound.Values[0], "itertools.count(..., start=...) expects a number.", span) : BigInteger.Zero;
        var step = bound.Assigned[1] ? ExpectNumber(bound.Values[1], "itertools.count(..., step=...) expects a number.", span) : BigInteger.One;
        var countResult = new PyCountIterator(start, step, context, span);
        return countResult;
    }

    private static object Repeat(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => RepeatCoreAsync(BindArguments(arguments, LythonKnownCallableSignatures.ItertoolsRepeat, span), span, context, false).GetAwaiter().GetResult();

    private static ValueTask<object> RepeatAsync(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => RepeatCoreAsync(BindArguments(arguments, LythonKnownCallableSignatures.ItertoolsRepeat, span), span, context, true);

    private static async ValueTask<object> RepeatCoreAsync(BoundCallArguments bound, LythonSourceSpan span, ExecutionContext context, bool asynchronous)
    {
        long? times = bound.Assigned[1]
            ? Math.Max(0, await CoerceItertoolsIndexAsync(bound.Values[1], span, context, asynchronous).ConfigureAwait(false))
            : null;
        PyIteratorBase.ChargeIteratorValue(context.MemoryGovernor, span);
        return new PyRepeatIterator(bound.Values[0], times);
    }

    private static object Cycle(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => CycleCoreAsync(PositionalOnly(arguments, "itertools.cycle", span), span, context, false).GetAwaiter().GetResult();
    private static ValueTask<object> CycleAsync(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => CycleCoreAsync(PositionalOnly(arguments, "itertools.cycle", span), span, context, true);
    private static async ValueTask<object> CycleCoreAsync(object[] positional, LythonSourceSpan span,
        ExecutionContext context, bool asynchronous)
    {
        if (positional.Length != 1) throw new LythonRuntimeException("TypeError", "itertools.cycle(iterable) expects one iterable argument.", span);
        context = GetGlobalContext(context);
        using var storage = context.MemoryGovernor.ReserveTemporary(288, span);
        var source = asynchronous ? await PyIteration.Cursor.CreateAsync(positional[0], span, context).ConfigureAwait(false)
            : PyIteration.Cursor.Create(positional[0], span, context);
        var result = new PyCycleIterator(source, context.MemoryGovernor, context, span);
        storage.Commit(288);
        return result;
    }

    private static object Islice(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => IsliceCoreAsync(PositionalOnly(arguments, "itertools.islice", span), span, context, false).GetAwaiter().GetResult();
    private static ValueTask<object> IsliceAsync(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => IsliceCoreAsync(PositionalOnly(arguments, "itertools.islice", span), span, context, true);
    private static async ValueTask<object> IsliceCoreAsync(object[] positional, LythonSourceSpan span,
        ExecutionContext context, bool asynchronous)
    {
        if (positional.Length is < 2 or > 4)
            throw new LythonRuntimeException("TypeError", "itertools.islice(iterable, stop) or itertools.islice(iterable, start, stop[, step]) is required.", span);
        var start = positional.Length == 2 ? 0 : await CoerceIsliceBoundAsync(positional[1],
            "Indices for islice() must be None or an integer: 0 <= x <= sys.maxsize.", BigInteger.Zero, context, span, asynchronous).ConfigureAwait(false) ?? 0;
        var stop = await CoerceIsliceBoundAsync(positional[positional.Length == 2 ? 1 : 2],
            "Stop argument for islice() must be None or an integer: 0 <= x <= sys.maxsize.", BigInteger.Zero, context, span, asynchronous).ConfigureAwait(false);
        var step = positional.Length < 4 ? 1 : await CoerceIsliceBoundAsync(positional[3],
            "Step for islice() must be a positive integer or None.", BigInteger.One, context, span, asynchronous).ConfigureAwait(false) ?? 1;
        context = GetGlobalContext(context);
        using var storage = context.MemoryGovernor.ReserveTemporary(288, span);
        var source = asynchronous ? await PyIteration.Cursor.CreateAsync(positional[0], span, context).ConfigureAwait(false)
            : PyIteration.Cursor.Create(positional[0], span, context);
        var result = new PyIsliceIterator(source, start, stop, step);
        storage.Commit(288);
        return result;
    }

    private static async ValueTask<long?> CoerceIsliceBoundAsync(object? value, string message, BigInteger minimum,
        ExecutionContext context, LythonSourceSpan span, bool asynchronous)
    {
        if (value is null or PyNone) return null;
        try
        {
            var converted = await CoerceTypeIndexAsync(value, context, span, asynchronous).ConfigureAwait(false);
            return ClampIsliceBound(converted ?? PyNone.Instance, minimum, span);
        }
        catch (LythonRuntimeException)
        {
            context.CheckExecution(span);
            throw new LythonRuntimeException("ValueError", message, span);
        }
    }

    private static long ClampIsliceBound(object coerced, BigInteger minimum, LythonSourceSpan span)
    {
        BigInteger integer = coerced switch
        {
            _ when Numbers.PyNumberOps.TryAsInteger(coerced, out var integerValue) => integerValue,
            _ => throw new LythonRuntimeException("TypeError", "islice bound is not an integer.", span),
        };

        if (integer < minimum || integer > long.MaxValue)
        {
            throw new LythonRuntimeException("OverflowError", "islice bound is out of range.", span);
        }

        return (long)integer;
    }

    private static ValueTask<(int Count, long Repeat)> BindProductAsync(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context, bool asynchronous)
    {
        var count = 0;
        object repeatArgument = BigInteger.One;
        foreach (var argument in arguments)
        {
            context.CheckExecution(span);
            if (argument.IsPositional) count++;
            else if (argument.KeywordName == "repeat")
            {
                repeatArgument = argument.Value;
            }
            else throw new LythonRuntimeException("TypeError", "itertools.product(...) only supports the keyword argument repeat=.", span);
        }

        return ValidateProductRepeatAsync(count, repeatArgument, span, context, asynchronous);
    }

    private static async ValueTask<(int Count, long Repeat)> ValidateProductRepeatAsync(int count, object repeatArgument,
        LythonSourceSpan span, ExecutionContext context, bool asynchronous)
    {
        var repeat = await CoerceItertoolsIndexAsync(repeatArgument, span, context, asynchronous).ConfigureAwait(false);
        if (repeat < 0) throw new LythonRuntimeException("ValueError", "repeat argument cannot be negative", span);
        // CPython checks ssize_t multiplication before consuming any input.
        if (count != 0 && repeat > long.MaxValue / count)
            throw new LythonRuntimeException("OverflowError", "repeat argument too large", span);
        if (count * repeat > Array.MaxLength)
            throw RuntimeErrors.Memory("itertools.product(...) repeat count is too large.", span);
        return (count, repeat);
    }

    private static object Product(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
    {
        var (count, repeat) = BindProductAsync(arguments, span, context, false).GetAwaiter().GetResult();
        if (repeat == 0 || count == 0) return CreateProduct(Array.Empty<PyList>(), 0, span, context);
        using var table = context.MemoryGovernor.ReserveTemporary(PyCombinatoricOwnership.PoolArrayBytes(count), span);
        var pools = new PyList[count];
        try
        {
            var index = 0;
            foreach (var argument in arguments)
                if (argument.IsPositional) pools[index++] = MaterializeSequence(argument.Value, span, context);
            return CreateProduct(pools, repeat, span, context);
        }
        catch
        {
            foreach (var pool in pools) pool?.DiscardUnpublishedStorage();
            throw;
        }
    }

    private static ValueTask<object> ProductAsync(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
    {
        var count = 0;
        foreach (var argument in arguments) { context.CheckExecution(span); if (argument.IsPositional) count++; }
        var working = context.MemoryGovernor.ReserveTemporary(count == 0 ? 0 : checked(32L + 8L * count), span);
        try
        {
            var iterables = count == 0 ? Array.Empty<object>() : new object[count];
            var index = 0;
            foreach (var argument in arguments) { context.CheckExecution(span); if (argument.IsPositional) iterables[index++] = argument.Value; }
            return ProductPreparedAsync(iterables, BindProductAsync(arguments, span, context, true), working, span, context);
        }
        catch { working.Dispose(); throw; }
    }

    private static async ValueTask<object> ProductPreparedAsync(object[] iterables, ValueTask<(int Count, long Repeat)> binding,
        MemoryGovernor.TemporaryMemoryReservation working, LythonSourceSpan span, ExecutionContext context)
    {
        using var owner = working;
        var (count, repeat) = await binding.ConfigureAwait(false);
        if (repeat == 0 || count == 0) return CreateProduct(Array.Empty<PyList>(), 0, span, context);
        using var table = context.MemoryGovernor.ReserveTemporary(PyCombinatoricOwnership.PoolArrayBytes(count), span);
        var pools = new PyList[count];
        try
        {
            var index = 0;
            foreach (var iterable in iterables)
                pools[index++] = await MaterializeItSequenceAsync(iterable, span, context).ConfigureAwait(false);
            return CreateProduct(pools, repeat, span, context);
        }
        catch
        {
            foreach (var pool in pools) pool?.DiscardUnpublishedStorage();
            throw;
        }
    }

    private static PyProductIterator CreateProduct(IReadOnlyList<PyList> pools, long repeat, LythonSourceSpan span, ExecutionContext context)
    {
        var length = checked((int)(pools.Count * repeat));
        var bytes = PyCombinatoricOwnership.PoolArrayBytes(length);
        using var table = context.MemoryGovernor.ReserveTemporary(bytes, span);
        var repeated = new IReadOnlyList<object>[length];
        for (var index = 0; index < length; index++)
        {
            context.CheckExecution(span);
            repeated[index] = pools[index % pools.Count];
        }
        var result = new PyProductIterator(repeated, context.MemoryGovernor, span, context);
        table.Commit(bytes);
        return result;
    }

    private static object ZipLongest(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => ZipLongestCoreAsync(arguments, span, context, false).GetAwaiter().GetResult();
    private static ValueTask<object> ZipLongestAsync(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => ZipLongestCoreAsync(arguments, span, context, true);
    private static ValueTask<object> ZipLongestCoreAsync(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span,
        ExecutionContext context, bool asynchronous)
    {
        var table = context.MemoryGovernor.ReserveTemporary(PyCombinatoricOwnership.PoolArrayBytes(arguments.Length), span);
        try
        {
            var iterables = new object[arguments.Length];
            var iterableCount = 0;
            object fillValue = PyNone.Instance;
            for (var i = 0; i < arguments.Length; i++)
            {
                context.CheckExecution(span);
                var argument = arguments[i];
                if (argument.IsPositional)
                {
                    iterables[iterableCount++] = argument.Value;
                    continue;
                }

                if (!string.Equals(argument.KeywordName, "fillvalue", StringComparison.Ordinal))
                {
                    throw new LythonRuntimeException("TypeError", "itertools.zip_longest(...) only supports the keyword argument fillvalue=.", span);
                }

                fillValue = argument.Value;
            }

            return CompleteZipLongestAsync(iterables, iterableCount, fillValue, table, span, context, asynchronous);
        }
        catch { table.Dispose(); throw; }
    }

    private static async ValueTask<object> CompleteZipLongestAsync(object[] iterables, int iterableCount, object fillValue,
        MemoryGovernor.TemporaryMemoryReservation table, LythonSourceSpan span, ExecutionContext context, bool asynchronous)
    {
        using var owner = table;
        return await PyZipLongestIterator.CreateAsync(iterableCount == iterables.Length ? iterables : iterables[..iterableCount],
            fillValue, span, context.MemoryGovernor, context, asynchronous).ConfigureAwait(false);
    }

    private static object Combinations(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => CreateCombinationsAsync(arguments, span, context, false, false).GetAwaiter().GetResult();
    private static ValueTask<object> CombinationsAsync(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => CreateCombinationsAsync(arguments, span, context, false, true);
    private static object CombinationsWithReplacement(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => CreateCombinationsAsync(arguments, span, context, true, false).GetAwaiter().GetResult();
    private static ValueTask<object> CombinationsWithReplacementAsync(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => CreateCombinationsAsync(arguments, span, context, true, true);

    private static ValueTask<object> CreateCombinationsAsync(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context, bool withReplacement, bool asynchronous)
    {
        var signature = withReplacement ? LythonKnownCallableSignatures.ItertoolsCombinationsWithReplacement : LythonKnownCallableSignatures.ItertoolsCombinations;
        var bound = BindArguments(arguments, signature, span);
        return CreateCombinationsAsyncPrepared(span, context, withReplacement, asynchronous, bound);
    }
    private static async ValueTask<object> CreateCombinationsAsyncPrepared(LythonSourceSpan span, ExecutionContext context, bool withReplacement, bool asynchronous, BoundCallArguments bound)
    {
        // Clinic converts r before tuple(iterable), but checks negativity after it.
        var requested = await CoerceItertoolsIndexAsync(bound.Values[1], span, context, asynchronous).ConfigureAwait(false);
        var pool = asynchronous ? await MaterializeItSequenceAsync(bound.Values[0], span, context).ConfigureAwait(false) : MaterializeSequence(bound.Values[0], span, context);
        try
        {
            var r = CombinatoricLength(requested, span);
            return withReplacement ? new PyCombinationsWithReplacementIterator(pool, r, context.MemoryGovernor, span, context) : new PyCombinationsIterator(pool, r, context.MemoryGovernor, span, context);
        }
        catch
        {
            pool.DiscardUnpublishedStorage();
            throw;
        }
    }
    private static object Permutations(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => PermutationsCoreAsync(BindArguments(arguments, LythonKnownCallableSignatures.ItertoolsPermutations, span), span, context, false).GetAwaiter().GetResult();
    private static ValueTask<object> PermutationsAsync(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => PermutationsCoreAsync(BindArguments(arguments, LythonKnownCallableSignatures.ItertoolsPermutations, span), span, context, true);

    private static async ValueTask<object> PermutationsCoreAsync(BoundCallArguments bound, LythonSourceSpan span,
        ExecutionContext context, bool asynchronous)
    {
        var pool = asynchronous
            ? await MaterializeItSequenceAsync(bound.Values[0], span, context).ConfigureAwait(false)
            : MaterializeSequence(bound.Values[0], span, context);
        try
        {
            var r = pool.Count;
            if (bound.Assigned[1] && bound.Values[1] is not PyNone)
            {
                // CPython permutations deliberately accepts an int, not __index__,
                // and validates it only after pooling the input.
                if (!Numbers.PyNumberOps.TryAsInteger(bound.Values[1], out var integer))
                    throw new LythonRuntimeException("TypeError", "Expected int as r", span);
                r = CombinatoricLength(ItertoolsSsize(integer, span), span);
            }
            return new PyPermutationsIterator(pool, r, context.MemoryGovernor, span, context);
        }
        catch { pool.DiscardUnpublishedStorage(); throw; }
    }

    private static int CombinatoricLength(long value, LythonSourceSpan span)
    {
        if (value < 0) throw new LythonRuntimeException("ValueError", "r must be non-negative", span);
        if (value > Array.MaxLength) throw RuntimeErrors.Memory("iterator index table exceeds managed array capacity", span);
        return (int)value;
    }

    private static object Accumulate(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => AccumulateCoreAsync(BindArguments(arguments, LythonKnownCallableSignatures.ItertoolsAccumulate, span), span, context, false).GetAwaiter().GetResult();
    private static ValueTask<object> AccumulateAsync(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => AccumulateCoreAsync(BindArguments(arguments, LythonKnownCallableSignatures.ItertoolsAccumulate, span), span, context, true);
    private static async ValueTask<object> AccumulateCoreAsync(BoundCallArguments bound, LythonSourceSpan span,
        ExecutionContext context, bool asynchronous)
    {
        var function = !bound.Assigned[1] || bound.Values[1] is PyNone ? null : bound.Values[1];
        var hasInitial = bound.Assigned[2] && bound.Values[2] is not PyNone;
        context = GetGlobalContext(context);
        using var storage = context.MemoryGovernor.ReserveTemporary(288, span);
        var source = asynchronous ? await PyIteration.Cursor.CreateAsync(bound.Values[0], span, context).ConfigureAwait(false)
            : PyIteration.Cursor.Create(bound.Values[0], span, context);
        var result = new PyAccumulateIterator(source, function, bound.Values[2], hasInitial, context, span);
        storage.Commit(288);
        return result;
    }

    private static object Compress(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => CompressCoreAsync(BindArguments(arguments, LythonKnownCallableSignatures.ItertoolsCompress, span), span, context, false).GetAwaiter().GetResult();
    private static ValueTask<object> CompressAsync(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => CompressCoreAsync(BindArguments(arguments, LythonKnownCallableSignatures.ItertoolsCompress, span), span, context, true);
    private static async ValueTask<object> CompressCoreAsync(BoundCallArguments bound, LythonSourceSpan span,
        ExecutionContext context, bool asynchronous)
    {
        context = GetGlobalContext(context);
        using var storage = context.MemoryGovernor.ReserveTemporary(448, span);
        var data = asynchronous ? await PyIteration.Cursor.CreateAsync(bound.Values[0], span, context).ConfigureAwait(false)
            : PyIteration.Cursor.Create(bound.Values[0], span, context);
        try
        {
            var selectors = asynchronous ? await PyIteration.Cursor.CreateAsync(bound.Values[1], span, context).ConfigureAwait(false)
                : PyIteration.Cursor.Create(bound.Values[1], span, context);
            var result = new PyCompressIterator(data, selectors, span, context);
            storage.Commit(448);
            return result;
        }
        catch { if (asynchronous) await data.DisposeAsync().ConfigureAwait(false); else data.Dispose(); throw; }
    }

    private static object FilterFalse(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => FilterFalseCoreAsync(PositionalOnly(arguments, "itertools.filterfalse", span), span, context, false).GetAwaiter().GetResult();
    private static ValueTask<object> FilterFalseAsync(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => FilterFalseCoreAsync(PositionalOnly(arguments, "itertools.filterfalse", span), span, context, true);
    private static async ValueTask<object> FilterFalseCoreAsync(object[] positional, LythonSourceSpan span,
        ExecutionContext context, bool asynchronous)
    {
        if (positional.Length != 2) throw new LythonRuntimeException("TypeError", "itertools.filterfalse(function, iterable) expects two positional arguments.", span);
        var predicate = positional[0] is PyNone ? null : positional[0];
        context = GetGlobalContext(context);
        using var storage = context.MemoryGovernor.ReserveTemporary(288, span);
        var source = asynchronous ? await PyIteration.Cursor.CreateAsync(positional[1], span, context).ConfigureAwait(false)
            : PyIteration.Cursor.Create(positional[1], span, context);
        var result = new PyPredicateIterator(predicate, source, PyPredicateIteratorMode.FilterFalse, context, span);
        storage.Commit(288);
        return result;
    }

    private static object DropWhile(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => DropWhileCoreAsync(arguments, span, context, false).GetAwaiter().GetResult();
    private static ValueTask<object> DropWhileAsync(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => DropWhileCoreAsync(arguments, span, context, true);
    private static ValueTask<object> DropWhileCoreAsync(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context, bool asynchronous)
    {
        var (predicate, iterable) = BindPredicateIterator(arguments, "itertools.dropwhile", span);
        return DropWhileCoreAsyncPrepared(span, context, asynchronous, predicate, iterable);
    }
    private static async ValueTask<object> DropWhileCoreAsyncPrepared(LythonSourceSpan span, ExecutionContext context, bool asynchronous, object predicate, object iterable)
    {
        context = GetGlobalContext(context);
        using var storage = context.MemoryGovernor.ReserveTemporary(288, span);
        var source = asynchronous ? await PyIteration.Cursor.CreateAsync(iterable, span, context).ConfigureAwait(false) : PyIteration.Cursor.Create(iterable, span, context);
        var result = new PyPredicateIterator(predicate, source, PyPredicateIteratorMode.DropWhile, context, span);
        storage.Commit(288);
        return result;
    }
    private static object TakeWhile(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => TakeWhileCoreAsync(arguments, span, context, false).GetAwaiter().GetResult();
    private static ValueTask<object> TakeWhileAsync(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => TakeWhileCoreAsync(arguments, span, context, true);
    private static ValueTask<object> TakeWhileCoreAsync(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context, bool asynchronous)
    {
        var (predicate, iterable) = BindPredicateIterator(arguments, "itertools.takewhile", span);
        return TakeWhileCoreAsyncPrepared(span, context, asynchronous, predicate, iterable);
    }
    private static async ValueTask<object> TakeWhileCoreAsyncPrepared(LythonSourceSpan span, ExecutionContext context, bool asynchronous, object predicate, object iterable)
    {
        context = GetGlobalContext(context);
        using var storage = context.MemoryGovernor.ReserveTemporary(288, span);
        var source = asynchronous ? await PyIteration.Cursor.CreateAsync(iterable, span, context).ConfigureAwait(false) : PyIteration.Cursor.Create(iterable, span, context);
        var result = new PyPredicateIterator(predicate, source, PyPredicateIteratorMode.TakeWhile, context, span);
        storage.Commit(288);
        return result;
    }
    private static object Starmap(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => StarmapCoreAsync(PositionalOnly(arguments, "itertools.starmap", span), span, context, false).GetAwaiter().GetResult();
    private static ValueTask<object> StarmapAsync(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => StarmapCoreAsync(PositionalOnly(arguments, "itertools.starmap", span), span, context, true);
    private static async ValueTask<object> StarmapCoreAsync(object[] positional, LythonSourceSpan span,
        ExecutionContext context, bool asynchronous)
    {
        if (positional.Length != 2) throw new LythonRuntimeException("TypeError", "itertools.starmap(function, iterable) expects two arguments.", span);
        context = GetGlobalContext(context);
        using var storage = context.MemoryGovernor.ReserveTemporary(288, span);
        var source = asynchronous ? await PyIteration.Cursor.CreateAsync(positional[1], span, context).ConfigureAwait(false)
            : PyIteration.Cursor.Create(positional[1], span, context);
        var result = new PyStarmapIterator(positional[0], source, context, span);
        storage.Commit(288);
        return result;
    }

    private static object Pairwise(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => PairwiseCoreAsync(PositionalOnly(arguments, "itertools.pairwise", span), span, context, false).GetAwaiter().GetResult();
    private static ValueTask<object> PairwiseAsync(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => PairwiseCoreAsync(PositionalOnly(arguments, "itertools.pairwise", span), span, context, true);
    private static async ValueTask<object> PairwiseCoreAsync(object[] positional, LythonSourceSpan span,
        ExecutionContext context, bool asynchronous)
    {
        if (positional.Length != 1) throw new LythonRuntimeException("TypeError", "itertools.pairwise(iterable) expects one iterable argument.", span);
        context = GetGlobalContext(context);
        using var storage = context.MemoryGovernor.ReserveTemporary(288, span);
        var source = asynchronous ? await PyIteration.Cursor.CreateAsync(positional[0], span, context).ConfigureAwait(false)
            : PyIteration.Cursor.Create(positional[0], span, context);
        var result = new PyPairwiseIterator(source, context.MemoryGovernor, span, context);
        storage.Commit(288);
        return result;
    }

    private static object GroupBy(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => GroupByCoreAsync(BindArguments(arguments, LythonKnownCallableSignatures.ItertoolsGroupBy, span), span, context, false).GetAwaiter().GetResult();
    private static ValueTask<object> GroupByAsync(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => GroupByCoreAsync(BindArguments(arguments, LythonKnownCallableSignatures.ItertoolsGroupBy, span), span, context, true);
    private static async ValueTask<object> GroupByCoreAsync(BoundCallArguments bound, LythonSourceSpan span,
        ExecutionContext context, bool asynchronous)
    {
        var key = !bound.Assigned[1] || bound.Values[1] is PyNone ? null : bound.Values[1];
        context = GetGlobalContext(context);
        using var storage = context.MemoryGovernor.ReserveTemporary(288, span);
        var source = asynchronous ? await PyIteration.Cursor.CreateAsync(bound.Values[0], span, context).ConfigureAwait(false)
            : PyIteration.Cursor.Create(bound.Values[0], span, context);
        var result = new PyGroupByIterator(source, key, context.MemoryGovernor, context, span);
        storage.Commit(288);
        return result;
    }

    private static object Tee(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => TeeCoreAsync(arguments, span, context, false).GetAwaiter().GetResult();
    private static ValueTask<object> TeeAsync(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => TeeCoreAsync(arguments, span, context, true);

    private static ValueTask<object> TeeCoreAsync(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span,
        ExecutionContext context, bool asynchronous)
    {
        if (arguments.Length is < 1 or > 2)
            throw new LythonRuntimeException("TypeError", "itertools.tee(iterable, n=2) expects one or two positional arguments.", span);
        if (arguments[0].IsKeyword || arguments.Length == 2 && arguments[1].IsKeyword)
            throw new LythonRuntimeException("TypeError", "itertools.tee(...) does not accept keyword arguments.", span);
        return TeePreparedAsync(arguments[0].Value, arguments.Length == 2 ? arguments[1].Value : new BigInteger(2),
            span, context, asynchronous);
    }

    private static async ValueTask<object> TeePreparedAsync(object iterable, object countArgument,
        LythonSourceSpan span, ExecutionContext context, bool asynchronous)
    {
        var requested = await CoerceItertoolsIndexAsync(countArgument, span, context, asynchronous).ConfigureAwait(false);
        if (requested < 0) throw new LythonRuntimeException("ValueError", "n must be >= 0", span);
        if (requested > Array.MaxLength) throw RuntimeErrors.Memory("tee output exceeds managed array capacity", span);
        if (requested == 0) return PyTuple.Empty;
        var count = (int)requested;
        var iteratorBytes = checked(128L * count);
        using var output = context.MemoryGovernor.ReserveTemporary(checked(iteratorBytes + PyTuple.EstimateApproximateBytes(count)), span);
        var shared = new PyTeeSharedState(iterable, count, context.MemoryGovernor, context, span);
        var iterators = new object[count];
        for (var i = 0; i < count; i++)
        {
            context.CheckExecution(span);
            iterators[i] = new PyTeeIterator(shared, i);
        }
        output.Commit(iteratorBytes);
        return PyTuple.FromReservedOwnedArray(iterators, context.MemoryGovernor, span, output);
    }

    private static object Batched(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => BatchedCoreAsync(BindArguments(arguments, LythonKnownCallableSignatures.ItertoolsBatched, span), span, context, false).GetAwaiter().GetResult();
    private static ValueTask<object> BatchedAsync(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => BatchedCoreAsync(BindArguments(arguments, LythonKnownCallableSignatures.ItertoolsBatched, span), span, context, true);

    private static async ValueTask<object> BatchedCoreAsync(BoundCallArguments bound, LythonSourceSpan span,
        ExecutionContext context, bool asynchronous)
    {
        var size = await CoerceItertoolsIndexAsync(bound.Values[1], span, context, asynchronous).ConfigureAwait(false);
        var strict = bound.Assigned[2] && (asynchronous
            ? await IsTruthyAsync(bound.Values[2], context, span).ConfigureAwait(false) : IsTruthy(bound.Values[2], context, span));
        if (size < 1) throw new LythonRuntimeException("ValueError", "n must be at least one", span);
        return await PyBatchedIterator.CreateAsync(bound.Values[0], size, strict, context.MemoryGovernor, span, context, asynchronous).ConfigureAwait(false);
    }

    private static object[] PositionalOnly(ReadOnlySpan<CallArgumentValue> arguments, string owner, LythonSourceSpan span)
    {
        var positional = new object[arguments.Length];
        for (var i = 0; i < arguments.Length; i++)
        {
            if (arguments[i].IsKeyword)
            {
                throw new LythonRuntimeException("TypeError", $"{owner}(...) does not accept keyword arguments in this form.", span);
            }

            positional[i] = arguments[i].Value;
        }

        return positional;
    }

    private static PredicateIteratorBinding BindPredicateIterator(ReadOnlySpan<CallArgumentValue> arguments, string owner, LythonSourceSpan span)
    {
        var positional = PositionalOnly(arguments, owner, span);
        if (positional.Length != 2)
        {
            throw new LythonRuntimeException("TypeError", $"{owner}(predicate, iterable) expects a callable and an iterable.", span);
        }

        return new PredicateIteratorBinding(positional[0], positional[1]);
    }

    private static BoundCallArguments BindArguments(
        ReadOnlySpan<CallArgumentValue> arguments,
        LythonCallableSignature signature,
        LythonSourceSpan span)
        => CallBinder.BindNamedArgumentsWithPresence(
            arguments,
            span,
            signature,
            PythonCallableKind.Builtin);

    // Private governed pools retain capacity directly. No ungoverned staging
    // list or final array copy; the iterator is the only user of this storage.
    private static PyList MaterializeSequence(object value, LythonSourceSpan span, ExecutionContext context)
        => new(ToSequence(value, span, context).Select(RuntimeValue), context.MemoryGovernor, span);

    private static async ValueTask<PyList> MaterializeItSequenceAsync(object value, LythonSourceSpan span, ExecutionContext context)
    {
        var pool = new PyList(Array.Empty<object>(), context.MemoryGovernor, span);
        try
        {
            await foreach (var item in ToSequenceAsync(value, span, context).ConfigureAwait(false))
                pool.Add(RuntimeValue(item));
            return pool;
        }
        catch
        {
            pool.DiscardUnpublishedStorage();
            throw;
        }
    }

    private static object ExpectNumber(object value, string message, LythonSourceSpan span)
    {
        if (!Numbers.PyNumberOps.TryAsNumber(value, out var number))
        {
            throw new LythonRuntimeException("TypeError", message, span);
        }

        return number.IsFloat ? number.Floating : number.Integer;
    }

    private static async ValueTask<long> CoerceItertoolsIndexAsync(object value, LythonSourceSpan span,
        ExecutionContext context, bool asynchronous)
    {
        var converted = await CoerceTypeIndexAsync(value, context, span, asynchronous).ConfigureAwait(false);
        if (converted is null || !Numbers.PyNumberOps.TryAsInteger(converted, out var integer))
            throw new LythonRuntimeException("TypeError", "'" + RuntimeErrors.DatetimeQualifiedTypeName(value, context)
                + "' object cannot be interpreted as an integer", span);
        return ItertoolsSsize(integer, span);
    }

    private static long ItertoolsSsize(BigInteger value, LythonSourceSpan span)
    {
        if (value < long.MinValue || value > long.MaxValue)
            throw new LythonRuntimeException("OverflowError", "Python int too large to convert to C ssize_t", span);
        return (long)value;
    }
}
