from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent;repo=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
assert not(r/'before.json').exists()
source={}
for base in ['src/Lokad.Lython','tests/Lokad.Lython.Tests']:
 for p in (repo/base).rglob('*.cs'):
  if {'bin','obj'}&set(p.parts):continue
  name=p.relative_to(repo).as_posix();source[name]=sha(p);dest=r/'originals'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
prior=r.parent/'closure-operands-r235'
for role in ['before','candidate']:shutil.copytree(prior/'images/before',r/'images'/role)
shutil.copyfile(prior/'catalog.json',r/'catalog.json')
for phase in ['warm-sync','warm-async','compile']:
 (r/phase).mkdir();shutil.copyfile(prior/phase/'hash-witness.json',r/phase/'hash-witness.json')
data=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),runtimeRevision='15f457f7786703bfe2ee251b3fe84145ad155fbe',sourceHashes=source,
 images={role:{p.name:sha(p)for p in(r/'images'/role).iterdir()if p.is_file()}for role in ['before','candidate']},
 scope='Canonical synchronous borrowed-call entry and complete synchronous consumers. Existing async array/borrowed entry remains an actual pending-input contract, not a compatibility shim. Shared helpers consume input into actual bound values/scalars or share existing construction stages; no ToArray sync facade, new control/owner framework or duplicate constructor algorithm.',
 acceptance='Python ordering/errors/binding, descriptors/closures/generators, actual async operations, cancellation/refusal/cleanup/retained aliases; real argument packet and sync forwarders removed. Six maintained scripts and unchanged controls; compile separate; no predicted CPU gain from call-entry profile.')
(r/'before.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8');print('R236 qualified15f source/image baseline and originals preserved; continuing R231 consumer migration, not repeating a signature-only gate.')
