from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent
repo=Path.cwd()
exec((r/'stage-edits.py').read_text(encoding='utf-8').split('# Owners transfer')[0])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ids=json.loads((r/'refined/diagnostic-identity.json').read_text(encoding='utf-8'))
for name,h in ids['allCoreSources'].items(): assert sha(repo/name)==h,name
# Keep actual source bytes, not only a whitespace-normalized patch, for both
# complete candidates. The original snapshots and original failed checks remain.
with tarfile.open(r/'refined/source.tar.xz','w:xz')as archive:
    for name in ids['allCoreSources']: archive.add(repo/name,arcname=name)
    for name in ['tests/Lokad.Lython.PublicApi.Tests/PreparedCallArgumentTests.cs','tests/Lokad.Lython.Tests/CallArgumentAssert.cs']:
        archive.add(repo/name,arcname=name)

tuple_source=(root/'PyTuple.cs').read_text(encoding='utf-8')
a,b,_=method(tuple_source,'internal static PyTuple FromPositionalArguments(')
tuple_factory=tuple_source[a:b]
calls={}
for name in ['LythonRuntime.Calls.Binding.cs','LythonRuntime.SubprocessModule.Errors.cs']:
    s=(root/name).read_text(encoding='utf-8')
    calls[name]=[line for line in s.splitlines()if 'FromPositionalArguments(' in line]
assert sum(map(len,calls.values()))==3,calls

before=json.loads((r/'before.json').read_text(encoding='utf-8'))
for name in before['sourceHashes']:
    shutil.copyfile(r/'originals'/name,repo/name)
    assert sha(repo/name)==before['sourceHashes'][name],name
helper=repo/'tests/Lokad.Lython.Tests/CallArgumentAssert.cs'
assert helper.resolve().is_relative_to((repo/'tests/Lokad.Lython.Tests').resolve())
assert not subprocess.check_output(['git','ls-files','--',str(helper.relative_to(repo))],text=True).strip()
helper.unlink()

# Independent Python fixes require no borrowed-span ABI or new preparation layer.
p=root/'LythonRuntime.ModernTyping.cs';s=p.read_text(encoding='utf-8')
s=s.replace('var covariant = false; var contravariant = false; var inferVariance = false;','object covariantValue = false, contravariantValue = false, inferVarianceValue = false;')
for name in ['covariant','contravariant','inferVariance']:
    old=f'{name} = asynchronous ? await IsTruthyAsync(argument.Value, context, span).ConfigureAwait(false) : IsTruthy(argument.Value, context, span);'
    assert old in s
    s=s.replace(old,f'{name}Value = argument.Value;')
needle='''        if (nameValue is null || !PyStringOps.TryAsString(nameValue, out var name))'''
assert needle in s
s=s.replace(needle,'''        // Python binds the complete call before coercing flags, in parameter
        // order rather than keyword insertion order. Keep the working owner
        // alive through actual asynchronous truth callbacks.
        var covariant = asynchronous ? await IsTruthyAsync(covariantValue, context, span).ConfigureAwait(false) : IsTruthy(covariantValue, context, span);
        var contravariant = asynchronous ? await IsTruthyAsync(contravariantValue, context, span).ConfigureAwait(false) : IsTruthy(contravariantValue, context, span);
        var inferVariance = asynchronous ? await IsTruthyAsync(inferVarianceValue, context, span).ConfigureAwait(false) : IsTruthy(inferVarianceValue, context, span);
'''+needle)
p.write_text(s,encoding='utf-8')

p=root/'PyDataclass.cs';s=p.read_text(encoding='utf-8')
old='''                        var truth = asynchronous ? await LythonRuntime.IsTruthyAsync(argument.Value, context, span).ConfigureAwait(false) : LythonRuntime.IsTruthy(argument.Value, context, span);
                        options = ApplyDataclassOption(options, argument.KeywordName, truth, "dataclasses.make_dataclass", span);'''
assert old in s
s=s.replace(old,'''                        if (!IsDataclassOption(argument.KeywordName))
                            throw CallErrors.UnexpectedKeyword(PythonCallableKind.Builtin, "dataclasses.make_dataclass", argument.KeywordName, span);''')
needle='''            var name = RuntimeArgumentValidation.ExpectString(clsName, "dataclasses.make_dataclass(cls_name=...)", span);'''
assert needle in s
s=s.replace(needle,'''            foreach (var pair in rawOptions)
            {
                var truth = asynchronous ? await LythonRuntime.IsTruthyAsync(pair.Value, context, span).ConfigureAwait(false)
                    : LythonRuntime.IsTruthy(pair.Value, context, span);
                options = ApplyDataclassOption(options, pair.Key, truth, "dataclasses.make_dataclass", span);
            }

'''+needle)
p.write_text(s,encoding='utf-8')

# A final tuple can be admitted and filled directly; no ABI migration is needed.
p=root/'PyTuple.cs';s=p.read_text(encoding='utf-8');needle='    internal static PyTuple FromOwnedArray(object[] items) => new(items, takeOwnership: true);';assert needle in s
s=s.replace(needle,needle+'\n\n    '+tuple_factory);p.write_text(s,encoding='utf-8')
p=root/'LythonRuntime.Calls.Binding.cs';s=p.read_text(encoding='utf-8')
old='            var values = arguments.Select(argument => argument.Value).ToArray();\n            var args = new PyTuple(values, context.MemoryGovernor, span);\n            var payload = values.Length == 0 ? PyNone.Instance : values.Length == 1 ? values[0] : args;';assert old in s
s=s.replace(old,'            var args = PyTuple.FromPositionalArguments(arguments, context.MemoryGovernor, span, context);\n            var payload = args.Count == 0 ? PyNone.Instance : args.Count == 1 ? args[0] : args;');p.write_text(s,encoding='utf-8')
p=root/'LythonRuntime.SubprocessModule.Errors.cs';s=p.read_text(encoding='utf-8')
old='new PyTuple(arguments.Where(a => a.IsPositional).Select(a => a.Value), context.MemoryGovernor, span)'
assert s.count(old)==2,s.count(old)
s=s.replace(old,'PyTuple.FromPositionalArguments(arguments, context.MemoryGovernor, span, context)');p.write_text(s,encoding='utf-8')

# Removing the sync carrier policy does not require converting any native API.
p=root/'LythonRuntime.Calls.cs';s=p.read_text(encoding='utf-8')
old='''        return InvokeCallable(
            callable,
            callSpan,
            context,
            new DeferredCallArguments(expandArguments));
    }

    private static object InvokeCallable<TArguments>(
        ICallable callable,
        LythonSourceSpan callSpan,
        ExecutionContext context,
        TArguments arguments)
        where TArguments : struct, ICallArguments
    {'''
assert old in s;s=s.replace(old,'')
s=s.replace('callable.Invoke(arguments.Expand(), callSpan, context)','callable.Invoke(expandArguments(), callSpan, context)')
old='''        return InvokeCallable(
            callable,
            callSpan,
            context,
            new PreparedCallArguments(arguments));'''
assert old in s
s=s.replace(old,'''        context.EnterInterpreterFrame(callSpan);
        try { return RuntimeValue(callable.Invoke(arguments, callSpan, context)); }
        catch (Exception error) when (TryTranslateCallableException(error, callSpan, out var translated)) { throw translated; }
        finally { context.LeaveInterpreterFrame(); }''')
a=s.index('    private interface ICallArguments');b=s.index('    private interface IAsyncCallArguments',a);s=s[:a]+s[b:]
s=s.replace(' : ICallArguments, IAsyncCallArguments',' : IAsyncCallArguments').replace('        public CallArgumentValue[] Expand() => Arguments;\n','')
p.write_text(s,encoding='utf-8')

for name in ['docs/RUNTIME.md','CHANGELOG.md','tests/README.md']:
    (repo/name).write_bytes(subprocess.check_output(['git','show','HEAD:'+name]))

keep={p.relative_to(repo).as_posix()for p in root.glob('*.cs')if sha(p)!=before['sourceHashes'].get(p.relative_to(repo).as_posix(),sha(p))}
keep.add('src/Lokad.Lython/Runtime/PyTuple.cs')
expected={'src/Lokad.Lython/Runtime/'+n for n in ['LythonRuntime.ModernTyping.cs','PyDataclass.cs','PyTuple.cs','LythonRuntime.Calls.Binding.cs','LythonRuntime.SubprocessModule.Errors.cs','LythonRuntime.Calls.cs']}
assert keep==expected,(keep,expected)
for name,h in before['sourceHashes'].items():
    if name not in expected:assert sha(repo/name)==h,name
(r/'retained-subset.json').write_text(json.dumps(dict(prototypeDecision='Withdraw the complete canonical-span conversion. Its many shared/native preparation stages add more implementation complexity than justified by the representative paths, which already borrow. No useful whole-script allocation reduction or qualified CPU gain is established. Initial captured-text adversity did not repeat; other adverse and unstable measurements remain unresolved, not permanent design vetoes.',retained=sorted(expected),checks='All other snapshotted source and internal tests restored byte-for-byte; retain public binding/descriptor/cancellation regressions and independent fixes. Fresh nonincremental build and focused validation follow.',next='Assess a complete native dictionary-aggregation loop using existing non-admitting accumulation and native iteration. Target per-element VM dispatch rather than argument packaging.'),indent=2)+'\n',encoding='utf-8')
print('Broad prototype withdrawn; six independent production edits retained. All other original source/internal tests verified byte-identical. Prototype source, cores and adverse observations preserved.')
