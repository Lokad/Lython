exec(__import__('pathlib').Path(__file__).with_name('stage-edits.py').read_text(encoding='utf-8').split('# Owners transfer')[0])

for name,marker,async_name,sync_name in [
 ('LythonRuntime.BytesMembers.cs','private sealed class RawBoundCallable','asyncImplementation','implementation'),
 ('LythonRuntime.CollectionsModule.cs','internal sealed class CollectionsCallable','_asyncImplementation','_implementation'),
 ('LythonRuntime.ItertoolsModule.cs','private sealed class ItertoolsCallable','_asyncImplementation','_implementation'),
 ('LythonRuntime.Calls.cs','internal sealed class BuiltinTypeMethod','_asyncImplementation','_implementation')]:
    p=root/name;s=p.read_text(encoding='utf-8');start=s.index(marker)
    # Existing array entry remains an adapter for genuine array-owning callers;
    # borrowed callers now reach the already-prepared implementation directly.
    signature='public async ValueTask<object> InvokeAsync(' if 'public async ValueTask<object> InvokeAsync(' in s[start:s.index('public bool TryGetMember',start) if name=='LythonRuntime.Calls.cs' else len(s)] else 'public ValueTask<object> InvokeAsync('
    # Locate the first public async entry within this class only.
    import re
    match=re.search(r'public (?:async )?ValueTask<object> InvokeAsync\(',s[start:]);assert match
    a,b,o=method(s[start+match.start():],match[0]);a+=start+match.start();b+=start+match.start()
    replacement=f'''public ValueTask<object> InvokeAsync(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
            => InvokeBorrowedAsync(arguments, span, context);

        public ValueTask<object> InvokeBorrowedAsync(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        {{
            context.CheckExecution(span);
            return {async_name} is null ? new({sync_name}(arguments, span, context))
                : {async_name}(arguments, span, context);
        }}'''
    s=s[:a]+replacement+s[b:];p.write_text(s,encoding='utf-8')

p=root/'PyBuiltinRuntimeType.cs';s=p.read_text(encoding='utf-8')
old='''    public ValueTask<object> InvokeAsync(CallArgumentValue[] arguments, LythonSourceSpan span, LythonRuntime.ExecutionContext context)
        => _asyncConstructor is null ? new(Invoke(arguments, span, context)) : _asyncConstructor(arguments, span, context);'''
assert old in s
s=s.replace(old,'''    public ValueTask<object> InvokeAsync(CallArgumentValue[] arguments, LythonSourceSpan span, LythonRuntime.ExecutionContext context)
        => InvokeBorrowedAsync(arguments, span, context);

    public ValueTask<object> InvokeBorrowedAsync(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, LythonRuntime.ExecutionContext context)
        => _asyncConstructor is null ? new(Invoke(arguments, span, context)) : _asyncConstructor(arguments, span, context);''')
p.write_text(s,encoding='utf-8')
