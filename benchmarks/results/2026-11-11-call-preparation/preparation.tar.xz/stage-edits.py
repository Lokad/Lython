from pathlib import Path
import re
root=Path('src/Lokad.Lython/Runtime')
def method(s,signature):
    a=s.index(signature);o=s.index('{',a)
    stripped=re.sub(r'//[^\n]*|/\*[\s\S]*?\*/|@"(?:""|[^"])*"|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'',lambda m:' '*len(m[0]),s)
    level=1;i=o+1
    while level:
        level+=(stripped[i]=='{')-(stripped[i]=='}');i+=1
    return a,i,o
def transform(name,signature,fn):
    p=root/name;s=p.read_text(encoding='utf-8');a,b,o=method(s,signature)
    p.write_text(s[:a]+fn(s[a:b])+s[b:],encoding='utf-8')
def change(name,old,new):
    p=root/name;s=p.read_text(encoding='utf-8');assert old in s,(name,old[:90]);p.write_text(s.replace(old,new),encoding='utf-8')

# Owners transfer to the pending operation, with synchronous-failure rollback.
def parser(m):
    m=m.replace('async ValueTask<object> CreateParserCoreAsync(CallArgumentValue[]','ValueTask<object> CreateParserCoreAsync(ReadOnlySpan<CallArgumentValue>')
    m=m.replace('using var storage =','var storage =',1)
    point=m.index('            var options =')
    m=m[:point]+'            try\n            {\n'+m[point:]
    point=m.index('            var addHelp =')
    suffix=m[point:]
    m=m[:point]+'''                return CompleteParserAsync(options, storage, span, context, asynchronous);
            }
            catch { storage.Dispose(); throw; }
        }

        private static async ValueTask<object> CompleteParserAsync(ArgparseParserOptions options,
            MemoryGovernor.TemporaryMemoryReservation storage, LythonSourceSpan span, ExecutionContext context, bool asynchronous)
        {
            using var owner = storage;
'''+suffix
    return m
transform('LythonRuntime.ArgparseModule.cs','private static async ValueTask<object> CreateParserCoreAsync(',parser)

def parse(m):
    m=m.replace('async ValueTask<object> ParseArgsCoreAsync(CallArgumentValue[]','ValueTask<object> ParseArgsCoreAsync(ReadOnlySpan<CallArgumentValue>')
    m=m.replace('using var working =','var working =',1)
    start=m.index('            var (argv, suppliedNamespace) = await ')
    end=m.index('\n',start)
    call=m[start:end].split(' = await ',1)[1].removesuffix('.ConfigureAwait(false);')
    m=m[:start]+'''            try
            {
                return ParseArgsPreparedAsync('''+call+''', working, span, context, asynchronous, known);
            }
            catch { working.Dispose(); throw; }
        }

        private async ValueTask<object> ParseArgsPreparedAsync(ValueTask<ParseInvocation> invocation,
            MemoryGovernor.TemporaryMemoryReservation working, LythonSourceSpan span, ExecutionContext context, bool asynchronous, bool known)
        {
            using var owner = working;
            var (argv, suppliedNamespace) = await invocation.ConfigureAwait(false);'''+m[end:]
    return m
transform('LythonRuntime.ArgparseParser.Invocation.cs','private async ValueTask<object> ParseArgsCoreAsync(',parse)

def replace(m):
    m=m.replace('async ValueTask<object> ReplaceInstanceCore(PyInstance instance, IReadOnlyList<CallArgumentValue>','ValueTask<object> ReplaceInstanceCore(PyInstance instance, ReadOnlySpan<CallArgumentValue>')
    m=m.replace('changeArguments.Count','changeArguments.Length').replace('using var working =','var working =',1)
    point=m.index('        var changes =')
    m=m[:point]+'        try\n        {\n'+m[point:]
    point=m.index('        foreach (var pair in map)')
    m=m[:point]+'''            return ReplaceFieldsAsync(instance, map, changes, working, span, context, asynchronous);
        }
        catch { working.Dispose(); throw; }
    }

    private static async ValueTask<object> ReplaceFieldsAsync(PyInstance instance, PyDict map,
        Dictionary<string, object> changes, MemoryGovernor.TemporaryMemoryReservation working,
        LythonSourceSpan span, LythonRuntime.ExecutionContext context, bool asynchronous)
    {
        using var owner = working;
'''+m[point:]
    return m
transform('PyDataclass.Operations.cs','private static async ValueTask<object> ReplaceInstanceCore(',replace)
change('PyDataclass.Operations.cs','IReadOnlyList<CallArgumentValue> changes','ReadOnlySpan<CallArgumentValue> changes')

def longest(m):
    m=m.replace('async ValueTask<object> ZipLongestCoreAsync(CallArgumentValue[]','ValueTask<object> ZipLongestCoreAsync(ReadOnlySpan<CallArgumentValue>')
    m=m.replace('using var table =','var table =',1)
    point=m.index('        var iterables =')
    m=m[:point]+'        try\n        {\n'+m[point:]
    point=m.index('        return await PyZipLongestIterator.CreateAsync(')
    suffix=m[point:]
    m=m[:point]+'''            return CompleteZipLongestAsync(iterables, iterableCount, fillValue, table, span, context, asynchronous);
        }
        catch { table.Dispose(); throw; }
    }

    private static async ValueTask<object> CompleteZipLongestAsync(object[] iterables, int iterableCount, object fillValue,
        MemoryGovernor.TemporaryMemoryReservation table, LythonSourceSpan span, ExecutionContext context, bool asynchronous)
    {
        using var owner = table;
'''+suffix
    return m
transform('LythonRuntime.ItertoolsModule.cs','private static async ValueTask<object> ZipLongestCoreAsync(',longest)

def tee(m):
    m=m.replace('async ValueTask<object> TeeCoreAsync(CallArgumentValue[]','ValueTask<object> TeeCoreAsync(ReadOnlySpan<CallArgumentValue>')
    point=m.index('        var requested =')
    m=m[:point]+'''        return TeePreparedAsync(arguments[0].Value, arguments.Length == 2 ? arguments[1].Value : new BigInteger(2),
            span, context, asynchronous);
    }

    private static async ValueTask<object> TeePreparedAsync(object iterable, object countArgument,
        LythonSourceSpan span, ExecutionContext context, bool asynchronous)
    {
'''+m[point:]
    m=m.replace('''var requested = arguments.Length == 2
            ? await CoerceItertoolsIndexAsync(arguments[1].Value, span, context, asynchronous).ConfigureAwait(false) : 2;''','''var requested = await CoerceItertoolsIndexAsync(countArgument, span, context, asynchronous).ConfigureAwait(false);''')
    return m.replace('new PyTeeSharedState(arguments[0].Value,','new PyTeeSharedState(iterable,')
transform('LythonRuntime.ItertoolsModule.cs','private static async ValueTask<object> TeeCoreAsync(',tee)

# Snapshot fixed references, never the input packet, before a handler suspends.
def fixed(name,signature,point,prepared,params,replacements):
    def run(m):
        m=m.replace('async ValueTask<object>','ValueTask<object>',1).replace('CallArgumentValue[] arguments','ReadOnlySpan<CallArgumentValue> arguments',1)
        index=m.index(point)
        for old,new in replacements: m=m[:index]+m[index:].replace(old,new)
        return m[:index]+prepared+params+m[index:]
    p=root/name;s=p.read_text(encoding='utf-8');offset=0
    while True:
        a,b,o=method(s[offset:],signature);a+=offset;b+=offset
        if point in s[a:b]: break
        offset=b
    p.write_text(s[:a]+run(s[a:b])+s[b:],encoding='utf-8')

fixed('LythonRuntime.Functools.Dispatch.cs','private static async ValueTask<object> InvokeCoreAsync(',
      '            var dispatcher =',
      '''            return WrapDispatcherAsync(arguments[0].Value, span, context, asynchronous);
        }

        private static async ValueTask<object> WrapDispatcherAsync(object function, LythonSourceSpan span, ExecutionContext context, bool asynchronous)
        {
''','', [('arguments[0].Value','function')])
# The same helper name lives in the other factory class.
fixed('LythonRuntime.Functools.Dispatch.cs','private static async ValueTask<object> InvokeCoreAsync(',
      '            var dispatcher =',
      '''            return WrapDispatcherAsync(arguments[0].Value, span, context, asynchronous);
        }

        private static async ValueTask<object> WrapDispatcherAsync(object function, LythonSourceSpan span, ExecutionContext context, bool asynchronous)
        {
''','', [('arguments[0].Value','function')])
fixed('LythonRuntime.Functools.Dispatch.cs','private async ValueTask<object> InvokeCoreAsync(',
      '            var wrapper =',
      '''            return WrapRecursiveReprAsync(arguments[0].Value, span, context, asynchronous);
        }

        private async ValueTask<object> WrapRecursiveReprAsync(object function, LythonSourceSpan span, ExecutionContext context, bool asynchronous)
        {
''','', [('arguments[0].Value','function')])
fixed('LythonRuntime.Functools.Cache.cs','private static async ValueTask<object> InvokeCoreAsync(',
      '            var property =',
      '''            return CreateCachedPropertyAsync(arguments[0].Value, span, context, asynchronous);
        }

        private static async ValueTask<object> CreateCachedPropertyAsync(object function, LythonSourceSpan span, ExecutionContext context, bool asynchronous)
        {
''','', [('arguments[0].Value','function')])

change('PyDataclass.GeneratedMethods.cs','arguments.Any(static a => a.IsKeyword)','LythonRuntime.HasKeywordArguments(arguments)')

# The final field-list construction consumes borrowed values without a LINQ view.
change('PyTyping.cs','''            fields = new PyList(arguments.Where(a => a.IsKeyword).Select(a => (object)new PyTuple(
                [PyString.FromString(a.KeywordName, context.MemoryGovernor, span), a.Value], context.MemoryGovernor, span)), context.MemoryGovernor, span);''','''            var keywordFields = new PyList([], context.MemoryGovernor, span);
            foreach (var argument in arguments)
                if (argument.IsKeyword) keywordFields.Add(new PyTuple(
                    [PyString.FromString(argument.KeywordName, context.MemoryGovernor, span), argument.Value], context.MemoryGovernor, span));
            fields = keywordFields;''')
