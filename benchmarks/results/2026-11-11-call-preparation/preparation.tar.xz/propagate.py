from pathlib import Path
import re
changed=[]
pattern=re.compile(r'(?m)^(?P<i>[ \t]*)(?P<head>(?:(?:public|private|internal|protected|static|sealed|virtual|override|new|async)\s+)+(?P<ret>[\w<>,?\.\[\] \t]+)\s+\w+(?:<[^;{}()]+>)?\s*)\((?P<args>[^;{}()]*)\)')
for p in Path('src/Lokad.Lython/Runtime').rglob('*.cs'):
 s=p.read_text(encoding='utf-8')
 def edit(m):
  if 'async 'in m['head']or any(x in m['ret']for x in ['Task','IEnumerable','IEnumerator']):return m[0]
  return m['i']+m['head']+'('+m['args'].replace('CallArgumentValue[] ','ReadOnlySpan<CallArgumentValue> ')+')'
 t=pattern.sub(edit,s)
 if t!=s:p.write_text(t,encoding='utf-8',newline='\n');changed.append(p.name)
print('Propagated synchronous reads into',len(changed),'helper files; pending/iterator consumers remain explicit.')
