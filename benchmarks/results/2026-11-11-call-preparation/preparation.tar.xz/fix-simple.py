from pathlib import Path

root=Path('src/Lokad.Lython/Runtime')
def edit(name, replacements):
    p=root/name
    s=p.read_text(encoding='utf-8')
    for before,after in replacements:
        assert before in s,(name,before[:100])
        s=s.replace(before,after)
    p.write_text(s,encoding='utf-8')

edit('LythonRuntime.BytesMembers.cs',[
('private static async ValueTask<(int Start, int End)> ByteSearchBoundsAsync(PyBytes value, CallArgumentValue[] args,','private static async ValueTask<(int Start, int End)> ByteSearchBoundsAsync(PyBytes value, object startArgument, object endArgument,'),
('args.Length < 2 ? null : await ByteSearchBoundAsync(args[1].Value','await ByteSearchBoundAsync(startArgument'),
('args.Length < 3 ? null : await ByteSearchBoundAsync(args[2].Value','await ByteSearchBoundAsync(endArgument'),
('private static async ValueTask<object> SearchBytesAsync(PyBytes value, string method, CallArgumentValue[] args,','private static ValueTask<object> SearchBytesAsync(PyBytes value, string method, ReadOnlySpan<CallArgumentValue> args,'),
('''        ValidateBytesPositionals(args, method, 1, 3, span);
        var (start, end) = await ByteSearchBoundsAsync(value, args, context, span, asynchronous).ConfigureAwait(false);
        var needle = await ByteNeedleAsync(args[0].Value''','''        ValidateBytesPositionals(args, method, 1, 3, span);
        return SearchBytesPreparedAsync(value, method, args[0].Value, args.Length < 2 ? PyNone.Instance : args[1].Value,
            args.Length < 3 ? PyNone.Instance : args[2].Value, span, context, asynchronous);
    }

    private static async ValueTask<object> SearchBytesPreparedAsync(PyBytes value, string method, object needleArgument,
        object startArgument, object endArgument, LythonSourceSpan span, ExecutionContext context, bool asynchronous)
    {
        var (start, end) = await ByteSearchBoundsAsync(value, startArgument, endArgument, context, span, asynchronous).ConfigureAwait(false);
        var needle = await ByteNeedleAsync(needleArgument'''),
('private static async ValueTask<object> StartsOrEndsWithBytesAsync(PyBytes value, string method, CallArgumentValue[] args,','private static ValueTask<object> StartsOrEndsWithBytesAsync(PyBytes value, string method, ReadOnlySpan<CallArgumentValue> args,'),
('''        ValidateBytesPositionals(args, method, 1, 3, span);
        var (start, end) = await ByteSearchBoundsAsync(value, args, context, span, asynchronous).ConfigureAwait(false);
        var prefix = args[0].Value;''','''        ValidateBytesPositionals(args, method, 1, 3, span);
        return MatchByteAffixAsync(value, method, args[0].Value, args.Length < 2 ? PyNone.Instance : args[1].Value,
            args.Length < 3 ? PyNone.Instance : args[2].Value, span, context, isStart, asynchronous);
    }

    private static async ValueTask<object> MatchByteAffixAsync(PyBytes value, string method, object prefix,
        object startArgument, object endArgument, LythonSourceSpan span, ExecutionContext context, bool isStart, bool asynchronous)
    {
        var (start, end) = await ByteSearchBoundsAsync(value, startArgument, endArgument, context, span, asynchronous).ConfigureAwait(false);'''),
('''    private static async ValueTask<object> JoinBytesAsync(PyBytes separator, CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        using var parts = await PyIteration.MaterializeLeasedAsync(BytesJoinIterable(arguments, span), span, context).ConfigureAwait(false);''','''    private static ValueTask<object> JoinBytesAsync(PyBytes separator, ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => JoinBytesIterableAsync(separator, BytesJoinIterable(arguments, span), span, context);

    private static async ValueTask<object> JoinBytesIterableAsync(PyBytes separator, object iterable, LythonSourceSpan span, ExecutionContext context)
    {
        using var parts = await PyIteration.MaterializeLeasedAsync(iterable, span, context).ConfigureAwait(false);''')])

edit('LythonRuntime.Calls.cs',[
('''private static async ValueTask<object> DictFromKeysAsync(CallArgumentValue[] arguments''','''private static ValueTask<object> DictFromKeysAsync(ReadOnlySpan<CallArgumentValue> arguments'''),
('return await DictFromKeysPositionalAsync(PositionalArguments(arguments), span, context).ConfigureAwait(false);','return DictFromKeysPositionalAsync(PositionalArguments(arguments), span, context);'),
('''private static async ValueTask<object> BoolFromBytesAsync(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        => RuntimeValue(!((BigInteger)await IntFromBytesAsync(arguments, span, context).ConfigureAwait(false)).IsZero);''','''private static ValueTask<object> BoolFromBytesAsync(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        => BoolFromIntegerAsync(IntFromBytesAsync(arguments, span, context));

    private static async ValueTask<object> BoolFromIntegerAsync(ValueTask<object> integer)
        => RuntimeValue(!((BigInteger)await integer.ConfigureAwait(false)).IsZero);''')])

edit('LythonRuntime.CollectionsModule.cs',[
('''        if (arguments.Count(static argument => argument.IsPositional) > 2)''','''        var positionalCount = 0;
        foreach (var argument in arguments) if (argument.IsPositional) positionalCount++;
        if (positionalCount > 2)''')])

edit('PyDataclass.GeneratedMethods.cs',[
('''        private async ValueTask<object> InvokeCore(CallArgumentValue[] arguments, LythonSourceSpan span, LythonRuntime.ExecutionContext context, bool asynchronous)
        {
            if (arguments.Length != 3''','''        private ValueTask<object> InvokeCore(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, LythonRuntime.ExecutionContext context, bool asynchronous)
        {
            if (arguments.Length != 3'''),
('''            if (asynchronous) await LythonRuntime.SetObjectInstanceAttributeAsync(instance, name, arguments[2].Value, context, span).ConfigureAwait(false);
            else LythonRuntime.SetObjectInstanceAttribute(instance, name, arguments[2].Value, context, span);
            return PyNone.Instance;''','''            return SetAttributeAsync(instance, name, arguments[2].Value, context, span, asynchronous);
        }

        private static async ValueTask<object> SetAttributeAsync(PyInstance instance, string name, object value,
            LythonRuntime.ExecutionContext context, LythonSourceSpan span, bool asynchronous)
        {
            if (asynchronous) await LythonRuntime.SetObjectInstanceAttributeAsync(instance, name, value, context, span).ConfigureAwait(false);
            else LythonRuntime.SetObjectInstanceAttribute(instance, name, value, context, span);
            return PyNone.Instance;''')])

edit('PyGenericAlias.cs',[
('''    private async ValueTask<object> InvokeAsyncCore(CallArgumentValue[] arguments''','''    private ValueTask<object> InvokeAsyncCore(ReadOnlySpan<CallArgumentValue> arguments'''),
('''        var value = asynchronous ? await callable.InvokeAsync(arguments, span, context).ConfigureAwait(false) : callable.Invoke(arguments, span, context);
        if (value is PyInstance instance) instance.SetAttribute("__orig_class__", this);''','''        return AttachOriginalClassAsync(asynchronous ? callable.InvokeBorrowedAsync(arguments, span, context) : new(callable.Invoke(arguments, span, context)));
    }

    private async ValueTask<object> AttachOriginalClassAsync(ValueTask<object> pending)
    {
        var value = await pending.ConfigureAwait(false);
        if (value is PyInstance instance) instance.SetAttribute("__orig_class__", this);''')])

edit('LythonRuntime.UrllibParseModule.Query.cs',[
('CallAsync(object callable, ReadOnlySpan<CallArgumentValue> arguments,','CallAsync(object callable, CallArgumentValue[] arguments,'),
('''            => asynchronous ? InvokeCallableTargetAsync(callable, span, span, context, () => ValueTask.FromResult(arguments))
                : ValueTask.FromResult(InvokeCallableTarget(callable, span, span, context, () => arguments));''','''            => asynchronous ? InvokeCallableTargetAsync(callable, span, span, context, arguments)
                : ValueTask.FromResult(InvokeCallableTarget(callable, span, span, context, arguments));''')])
