exec(__import__('pathlib').Path(__file__).with_name('stage-edits.py').read_text(encoding='utf-8').split('# Owners transfer')[0])

def cache(m):
    m=m.replace('async ValueTask<object> InvokeCoreAsync(CallArgumentValue[]','ValueTask<object> InvokeCoreAsync(ReadOnlySpan<CallArgumentValue>')
    m=m.replace('''? await _callable.InvokeAsync(arguments, span, context).ConfigureAwait(false)
                    : _callable.Invoke(arguments, span, context);''','''? _callable.InvokeBorrowedAsync(arguments, span, context)
                    : new(_callable.Invoke(arguments, span, context));''',1)
    m=m.replace('''            try
            {''','''            var transferredToPending = false;
            try
            {''',1)
    m=m.replace('return cached.Value;','return new(cached.Value);')
    point=m.index('                var result = asynchronous')
    m=m[:point]+'''                var pending = asynchronous
                    ? _callable.InvokeBorrowedAsync(arguments, span, context)
                    : new ValueTask<object>(_callable.Invoke(arguments, span, context));
                transferredToPending = true;
                return StoreCallAsync(pending, key, keyCharge, hash, span, context);
            }
            finally { if (!transferredToPending) context.MemoryGovernor.Release(keyCharge); }
        }

        private async ValueTask<object> StoreCallAsync(ValueTask<object> pending, object key, long keyCharge, int hash,
            LythonSourceSpan span, ExecutionContext context)
        {
            try
            {
                var result = await pending.ConfigureAwait(false);
                var transferred = keyCharge;
                keyCharge = 0;
                Store(key, transferred, result, span, context, hash);
                return result;
            }
            finally { context.MemoryGovernor.Release(keyCharge); }
        }'''
    return m
transform('LythonRuntime.Functools.Cache.cs','private async ValueTask<object> InvokeCoreAsync(',cache)

def partial(m):
    m=m.replace('async ValueTask<object> InvokeCoreAsync(CallArgumentValue[]','ValueTask<object> InvokeCoreAsync(ReadOnlySpan<CallArgumentValue>')
    m=m.replace('''return asynchronous ? await callable.InvokeAsync(arguments, span, context).ConfigureAwait(false)
                    : callable.Invoke(arguments, span, context);''','''return asynchronous ? callable.InvokeBorrowedAsync(arguments, span, context)
                    : new(callable.Invoke(arguments, span, context));''')
    m=m.replace('using var working =','var working =',1)
    point=m.index('            Dictionary<string, object>? merged')
    m=m[:point]+'            try\n            {\n'+m[point:]
    point=m.index('            return asynchronous ? await callable.InvokeAsync(combined')
    m=m[:point]+'''                return InvokeCombinedAsync(callable, combined, working, span, context, asynchronous);
            }
            catch { working.Dispose(); throw; }
        }

        private static async ValueTask<object> InvokeCombinedAsync(ICallable callable, CallArgumentValue[] combined,
            MemoryGovernor.TemporaryMemoryReservation working, LythonSourceSpan span, ExecutionContext context, bool asynchronous)
        {
            using var owner = working;
            return asynchronous ? await callable.InvokeAsync(combined, span, context).ConfigureAwait(false)
                : callable.Invoke(combined, span, context);
        }'''
    return m
transform('LythonRuntime.Functools.Partial.cs','internal async ValueTask<object> InvokeCoreAsync(',partial)

# Both entry points share target resolution; only the input lifetime differs.
def dispatch(m):
    isbound='dispatcher.ResolveForValueAsync' in m
    span='sourceSpan' if 'sourceSpan' in m else 'span'
    if '_active.Contains' in m:
        m=m.replace('async ValueTask<object> InvokeCoreAsync(CallArgumentValue[]','ValueTask<object> InvokeCoreAsync(ReadOnlySpan<CallArgumentValue>')
        m=m.replace('return fillValue;','return new(fillValue);')
        point=m.index('            try { return asynchronous')
        return m[:point]+'''            try
            {
                var pending = asynchronous ? callable.InvokeBorrowedAsync(arguments, sourceSpan, context)
                    : new ValueTask<object>(callable.Invoke(arguments, sourceSpan, context));
                return CompleteRecursiveCallAsync(pending, key);
            }
            catch { _active.Remove(key); throw; }
        }

        private async ValueTask<object> CompleteRecursiveCallAsync(ValueTask<object> pending, object key)
        {
            try { return await pending.ConfigureAwait(false); }
            finally { _active.Remove(key); }
        }'''
    prefix=m.index('            var target =')
    tail=m.index('            return asynchronous ? await callable.InvokeAsync(arguments')
    resolve=m[prefix:tail]
    return '''public object Invoke(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        {
            context.CheckExecution(span);
            RequireDispatchArgument(arguments, span);
            var callable = ResolveCallableAsync(arguments[0].Value, span, context, false).GetAwaiter().GetResult();
            return callable.Invoke(arguments, span, context);
        }

        public async ValueTask<object> InvokeAsync(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            context.CheckExecution(span);
            RequireDispatchArgument(arguments, span);
            var callable = await ResolveCallableAsync(arguments[0].Value, span, context, true).ConfigureAwait(false);
            return await callable.InvokeAsync(arguments, span, context).ConfigureAwait(false);
        }

        private async ValueTask<ICallable> ResolveCallableAsync(object value, LythonSourceSpan span, ExecutionContext context, bool asynchronous)
        {
'''+resolve.replace('arguments[0].Value','value')+'''            return callable;
        }'''

p=root/'LythonRuntime.Functools.Dispatch.cs';s=p.read_text(encoding='utf-8')
# Replace dispatcher and bound-dispatcher entry blocks as a unit.
for marker in ['private sealed class PySingleDispatchDispatcher','private sealed class BoundSingleDispatchMethod']:
    start=s.index(marker)
    entry=s.index('public object Invoke(',start)
    a,b,o=method(s[entry:],'private async ValueTask<object> InvokeCoreAsync(');a+=entry;b+=entry
    s=s[:entry]+dispatch(s[a:b])+s[b:]
# Recursive wrapper keeps its existing public entry forwarders.
start=s.index('private sealed class PyRecursiveReprWrapper')
a,b,o=method(s[start:],'private async ValueTask<object> InvokeCoreAsync(');a+=start;b+=start
s=s[:a]+dispatch(s[a:b])+s[b:]
p.write_text(s,encoding='utf-8')
