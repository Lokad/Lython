from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).resolve().parent
repo=Path.cwd()
exec((r/'stage-edits.py').read_text(encoding='utf-8').split('# Owners transfer')[0])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=json.loads((r/'before.json').read_text(encoding='utf-8'))
keep={p.resolve().relative_to(repo).as_posix()for p in root.glob('*.cs')if sha(p)!=before['sourceHashes'].get(p.resolve().relative_to(repo).as_posix(),sha(p))}
keep.add('src/Lokad.Lython/Runtime/PyTuple.cs')
expected={'src/Lokad.Lython/Runtime/'+n for n in ['LythonRuntime.ModernTyping.cs','PyDataclass.cs','PyTuple.cs','LythonRuntime.Calls.Binding.cs','LythonRuntime.SubprocessModule.Errors.cs','LythonRuntime.Calls.cs']}
assert keep==expected,(keep,expected)
for name,h in before['sourceHashes'].items():
    if name not in expected:assert sha(repo/name)==h,name
(r/'retained-subset.json').write_text(json.dumps(dict(prototypeDecision='Withdraw the complete canonical-span conversion. Its many shared/native preparation stages add more implementation complexity than justified by the representative paths, which already borrow. No useful whole-script allocation reduction or qualified CPU gain is established. Initial captured-text adversity did not repeat; other adverse and unstable measurements remain unresolved, not permanent design vetoes.',retained=sorted(expected),checks='All other snapshotted source and internal tests restored byte-for-byte; retain public binding/descriptor/cancellation regressions and independent fixes. Fresh nonincremental build and focused validation follow.',next='Assess a complete native dictionary-aggregation loop using existing non-admitting accumulation and native iteration. Target per-element VM dispatch rather than argument packaging.'),indent=2)+'\n',encoding='utf-8')
print('Broad prototype withdrawn; six independent production edits retained. All other original source/internal tests verified byte-identical. Prototype source, cores and adverse observations preserved.')
