from pathlib import Path
import gzip,hashlib,io,json,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path.cwd()
out=repo/'benchmarks/results/2026-11-11-call-preparation';out.mkdir()
sha=lambda data:hashlib.sha256(data).hexdigest()
initial=json.loads((r/'diagnostic-identity.json').read_text(encoding='utf-8'))
refined=json.loads((r/'refined/diagnostic-identity.json').read_text(encoding='utf-8'))
before=json.loads((r/'before.json').read_text(encoding='utf-8'))
decision=json.loads((r/'retained-subset.json').read_text(encoding='utf-8'))
revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
checks={}
for tf in ['net11.0','net10.0']:
 for suite in ['internal','public']:
  data=(r/f'retained-{suite}-{tf}.log').read_bytes();assert b'Passed!' in data and b'Failed!' not in data
  checks[f'{suite}-{tf}']=sha(data)
  dest=out/'retained-checks'/f'{suite}-{tf}.log';dest.parent.mkdir(exist_ok=True);dest.write_bytes(data)
restored={}
for name,h in before['sourceHashes'].items():
 data=(repo/name).read_bytes();actual=sha(data)
 if name not in decision['retained']:assert actual==h,name
 restored[name]=actual
(out/'retained-source.json').write_text(json.dumps(dict(revision=revision,sourceHashes=restored,
 retained=decision['retained'],checks=checks,
 qualification='Fresh nonincremental Release solution build24.39s;4534 ordinary internal and1003 selected public cases per actual target. Full platform/stress/installed-package checks batch at the next coherent delivery, not for withdrawn prototypes.'),indent=2)+'\n',encoding='utf-8')
for variant,folder,ids in [('initial',r,initial),('refined',r/'refined',refined)]:
 dest=out/variant;dest.mkdir()
 shutil.copyfile(folder/'diagnostic-identity.json',dest/'diagnostic-identity.json')
 shutil.copyfile(folder/'source.patch',dest/'source.patch')
 for phase in ['warm-sync','warm-async','compile']:
  target=dest/phase;target.mkdir()
  for name in ['measurements.json','summary.json','stderr.log','hash-witness.json']:
   shutil.copyfile(folder/phase/name,target/name)
  data=json.loads((target/'measurements.json').read_text(encoding='utf-8-sig'))
  assert data['allGoldensPassed'] and data['allBalancesZero'] and data['ownedFixturesRemoved']
 for src,name in [(folder/'images/candidate/Lokad.Lython.dll','core-net11.dll.gz'),(folder/'candidate-net10.dll','core-net10.dll.gz')]:
  raw=src.read_bytes();assert sha(raw)==(ids['images']['candidate']['Lokad.Lython.dll']if 'net11' in name else ids['net10SHA256'])
  (dest/name).write_bytes(gzip.compress(raw,mtime=0))
raw=(r/'images/before/Lokad.Lython.dll').read_bytes();assert sha(raw)==initial['images']['before']['Lokad.Lython.dll']
(out/'baseline-core-net11.dll.gz').write_bytes(gzip.compress(raw,mtime=0))
shutil.copyfile(r/'refined/source.tar.xz',out/'refined/source.tar.xz')
# Reconstruct and verify every original candidate source byte, including files
# whose only difference from the baseline is line endings.
with tarfile.open(r/'refined/source.tar.xz','r:xz')as source,tarfile.open(out/'initial/source.tar.xz','w:xz')as archive:
 for name,h in initial['allCoreSources'].items():
  p=r/'initial-source'/name
  raw=p.read_bytes()if p.exists()else source.extractfile(name).read()
  assert sha(raw)==h,name
  entry=tarfile.TarInfo(name);entry.size=len(raw);archive.addfile(entry,io.BytesIO(raw))
 for name in ['tests/Lokad.Lython.PublicApi.Tests/PreparedCallArgumentTests.cs','tests/Lokad.Lython.Tests/CallArgumentAssert.cs']:
  archive.add(r/'initial-source'/name,arcname=name)

with tarfile.open(out/'preparation.tar.xz','w:xz')as archive:
 for name in ['before.json','refinement.json','retained-subset.json','cpython-goldens.json','catalog.json']:
  archive.add(r/name,arcname=name)
 for p in sorted(r.glob('*.py')):archive.add(p,arcname=p.name)
 for name in ['Program.cs','prepare-tool.csproj']:archive.add(r/'prepare-tool'/name,arcname='prepare-tool/'+name)
 for p in sorted(r.glob('*.log')):archive.add(p,arcname='checks-and-builds/'+p.name)
 for variant in ['refined']:
  for p in sorted((r/variant).glob('*.py')):archive.add(p,arcname=variant+'/'+p.name)
shutil.copyfile(r/'retained-subset.json',out/'decision.json')
identity={p.relative_to(out).as_posix():dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes()))for p in out.rglob('*')if p.is_file()}
(out/'archive-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
print('R236 immutable evidence preserved; initial/refined core and complete source hashes verified; retained source '+revision[:8]+'.',flush=True)
