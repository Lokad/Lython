from pathlib import Path
import re
count=0
for p in Path('src/Lokad.Lython').rglob('*.cs'):
 if {'obj','bin'}&set(p.parts):continue
 s=p.read_text(encoding='utf-8')
 t,n=re.subn(r'(?m)^(?P<i> +)public object Invoke\(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, (?:LythonRuntime\.)?ExecutionContext context\)\n(?P=i)    => Invoke\(arguments, span, context\);\n\n','',s)
 if n:p.write_text(t,encoding='utf-8',newline='\n');count+=n
print('Removed',count,'remaining nested sync forwarders.')
