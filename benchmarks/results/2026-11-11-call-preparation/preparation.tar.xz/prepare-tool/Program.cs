using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System.Text.Json;

var apply = args.Contains("--apply");
var immediate = args.Contains("--immediate");
var prefix = args.Contains("--prefix");
var root = Path.GetFullPath("src/Lokad.Lython");
var options = CSharpParseOptions.Default.WithLanguageVersion(LanguageVersion.Preview);
var trees = Directory.EnumerateFiles(root,"*.cs",SearchOption.AllDirectories)
    .Where(p=>!p.Split(Path.DirectorySeparatorChar).Any(x=>x is "bin" or "obj"))
    .Select(p=>CSharpSyntaxTree.ParseText(File.ReadAllText(p,System.Text.Encoding.UTF8),options,p)).ToList();
trees.Add(CSharpSyntaxTree.ParseText("global using System;global using System.Collections.Generic;global using System.Linq;global using System.Threading;global using System.Threading.Tasks;global using System.IO;",options));
var references = ((string)AppContext.GetData("TRUSTED_PLATFORM_ASSEMBLIES")!).Split(Path.PathSeparator).Select(p=>MetadataReference.CreateFromFile(p));
var compilation = CSharpCompilation.Create("SourcePreparation",trees,references,new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary));
if(args.Contains("--restore-unchanged-bodies"))
{
 var originals=Path.GetFullPath(".git/agent-notes/review-20261031/call-preparation-r236/originals/src/Lokad.Lython");
 foreach(var tree in trees.Where(t=>t.FilePath.Length!=0))
 {
  var oldPath=Path.Combine(originals,Path.GetRelativePath(root,tree.FilePath));if(!File.Exists(oldPath))continue;
  var old=CSharpSyntaxTree.ParseText(File.ReadAllText(oldPath,System.Text.Encoding.UTF8),options);
  string Key(MethodDeclarationSyntax m)=>string.Join(".",m.Ancestors().OfType<TypeDeclarationSyntax>().Reverse().Select(t=>t.Identifier.ValueText))+"/"+m.Identifier.ValueText+"/"+string.Join(",",m.ParameterList.Parameters.Select(p=>p.Identifier.ValueText));
  var prior=old.GetRoot().DescendantNodes().OfType<MethodDeclarationSyntax>().Where(m=>m.Body is not null).GroupBy(Key).ToDictionary(g=>g.Key,g=>g.ToArray());
  var replacements=new Dictionary<MethodDeclarationSyntax,BlockSyntax>();
  foreach(var m in tree.GetRoot().DescendantNodes().OfType<MethodDeclarationSyntax>().Where(m=>m.Body is not null))
  {
   if(!prior.TryGetValue(Key(m),out var candidates))continue;
   foreach(var candidate in candidates)
   {
    var body=(BlockSyntax)new RenameSyncBorrow().Visit(candidate.Body!)!;
    if(!SyntaxFactory.AreEquivalent(m.Body,body))continue;
    replacements[m]=body;break;
   }
  }
  if(replacements.Count==0)continue;
  var changed=tree.GetRoot().ReplaceNodes(replacements.Keys,(old,current)=>current.WithBody(replacements[old]));
  File.WriteAllText(tree.FilePath,changed.ToFullString().Replace("\r\n","\n"),new System.Text.UTF8Encoding(false));
 }
 return;
}
if(args.Contains("--format-changed"))
{
 var assemblies=Microsoft.CodeAnalysis.Host.Mef.MefHostServices.DefaultAssemblies.Add(System.Reflection.Assembly.Load("Microsoft.CodeAnalysis.CSharp.Workspaces"));
 using var workspace=new AdhocWorkspace(Microsoft.CodeAnalysis.Host.Mef.MefHostServices.Create(assemblies));
 var originals=Path.GetFullPath(".git/agent-notes/review-20261031/call-preparation-r236/originals/src/Lokad.Lython");
 foreach(var tree in trees.Where(t=>t.FilePath.Length!=0))
 {
  var oldPath=Path.Combine(originals,Path.GetRelativePath(root,tree.FilePath));
  if(!File.Exists(oldPath))continue;
  var old=CSharpSyntaxTree.ParseText(File.ReadAllText(oldPath,System.Text.Encoding.UTF8),options);
  var bodies=old.GetRoot().DescendantNodes().OfType<MethodDeclarationSyntax>().Where(m=>m.Body is not null).Select(m=>m.Body!.ToFullString()).ToHashSet();
  var spans=tree.GetRoot().DescendantNodes().OfType<MethodDeclarationSyntax>().Where(m=>m.Body is not null&&!bodies.Contains(m.Body.ToFullString())).Select(m=>m.FullSpan).ToArray();
  if(spans.Length==0)continue;
  var formatted=Microsoft.CodeAnalysis.Formatting.Formatter.Format(tree.GetRoot(),spans,workspace);
  File.WriteAllText(tree.FilePath,formatted.ToFullString(),new System.Text.UTF8Encoding(false));
  Console.WriteLine(Path.GetRelativePath(root,tree.FilePath)+" "+spans.Length+" methods");
 }
 return;
}
if(immediate)
{
 foreach(var tree in trees.Where(t=>t.FilePath.Length!=0))
 {
  var rewritten=new Immediate().Visit(tree.GetRoot())!;
  if(!rewritten.IsEquivalentTo(tree.GetRoot()))File.WriteAllText(tree.FilePath,rewritten.ToFullString(),new System.Text.UTF8Encoding(false));
 }
 return;
}
if(prefix)
{
 foreach(var tree in trees.Where(t=>t.FilePath.Length!=0))
 {
  var model=compilation.GetSemanticModel(tree);var plans=new Dictionary<MethodDeclarationSyntax,PrefixMove>();
  foreach(var method in tree.GetRoot().DescendantNodes().OfType<MethodDeclarationSyntax>())
  {
   if(method.Identifier.ValueText=="InvokeAsync"||!method.Modifiers.Any(SyntaxKind.AsyncKeyword)||method.Body is not{}body||method.ReturnType is not GenericNameSyntax{Identifier.ValueText:"ValueTask"})continue;
   var arg=method.ParameterList.Parameters.FirstOrDefault(p=>p.Type is ArrayTypeSyntax a&&a.ElementType.ToString().EndsWith("CallArgumentValue"));if(arg is null)continue;
   var uses=body.DescendantNodes().OfType<IdentifierNameSyntax>().Where(n=>n.Identifier.ValueText==arg.Identifier.ValueText).ToArray();if(uses.Length==0)continue;
   var last=body.Statements.Select((s,i)=>(s,i)).Where(x=>uses.Any(n=>x.s.Span.Contains(n.Span))).Select(x=>x.i).DefaultIfEmpty(-1).Max();
   if(last<0||last>=body.Statements.Count-1)continue;
   var statements=body.Statements.Take(last+1).ToArray();var nodes=statements.SelectMany(s=>s.DescendantNodesAndSelf()).ToArray();
   if(nodes.Any(n=>n is AwaitExpressionSyntax or YieldStatementSyntax or UsingStatementSyntax or LocalFunctionStatementSyntax||n is LocalDeclarationStatementSyntax d&&d.UsingKeyword.RawKind!=0))continue;
   var lambdas = nodes.OfType<AnonymousFunctionExpressionSyntax>().ToArray();
   if(lambdas.Any(lambda => lambda.DescendantNodes().OfType<IdentifierNameSyntax>().Any(n => model.GetSymbolInfo(n).Symbol is IParameterSymbol p && !lambda.Span.Contains(p.Locations.FirstOrDefault()?.SourceSpan ?? default) || model.GetSymbolInfo(n).Symbol is ILocalSymbol l && !lambda.Span.Contains(l.Locations.FirstOrDefault()?.SourceSpan ?? default))))continue;
   var declared=nodes.Where(n=>n is VariableDeclaratorSyntax or SingleVariableDesignationSyntax).Select(n=>model.GetDeclaredSymbol(n)).OfType<ILocalSymbol>().ToArray();
   var referenced=body.Statements.Skip(last+1).SelectMany(s=>s.DescendantNodesAndSelf().OfType<IdentifierNameSyntax>()).Select(n=>model.GetSymbolInfo(n).Symbol).ToHashSet(SymbolEqualityComparer.Default);
   var locals=declared.Where(n=>referenced.Contains(n)).ToArray();if(locals.Any(n=>n.Type.TypeKind==TypeKind.Error||n.Type.IsRefLikeType))continue;
   var name=method.Identifier.ValueText+"Prepared";if(method.Parent!.ChildNodes().OfType<MethodDeclarationSyntax>().Any(m=>m.Identifier.ValueText==name))continue;
   plans.Add(method,new PrefixMove(last,method.ParameterList.Parameters.IndexOf(arg),name,locals));
   Console.WriteLine(tree.FilePath+":"+method.GetLocation().GetLineSpan().StartLinePosition.Line+" "+method.Identifier.ValueText+" -> "+string.Join(",",locals.Select(n=>n.Name)));
  }
  if(plans.Count!=0)
  {
   var rewritten=new LiftPrefixes(plans).Visit(tree.GetRoot())!;
   File.WriteAllText(tree.FilePath,rewritten.ToFullString(),new System.Text.UTF8Encoding(false));
  }
 }
 return;
}
var moves = new Dictionary<ISymbol,Move>(SymbolEqualityComparer.Default);
foreach(var tree in trees.Where(t=>t.FilePath.Length!=0))
{
 var model=compilation.GetSemanticModel(tree);
 foreach(var method in tree.GetRoot().DescendantNodes().OfType<MethodDeclarationSyntax>())
 {
  if(!method.Modifiers.Any(SyntaxKind.AsyncKeyword)||method.Body is not{}body||body.Statements.Count<1)continue;
  var parameter=method.ParameterList.Parameters.FirstOrDefault(p=>p.Type is ArrayTypeSyntax a&&a.ElementType.ToString().EndsWith("CallArgumentValue"));
  if(parameter is null||body.Statements[0]is not LocalDeclarationStatementSyntax{UsingKeyword.RawKind:0}decl||decl.Declaration.Variables.Count!=1)continue;
  var local=decl.Declaration.Variables[0];if(local.Initializer is null||decl.DescendantNodes().OfType<AwaitExpressionSyntax>().Any())continue;
  var uses=body.DescendantNodes().OfType<IdentifierNameSyntax>().Where(x=>x.Identifier.ValueText==parameter.Identifier.ValueText).ToArray();
  if(uses.Length==0||uses.Any(x=>!decl.Span.Contains(x.Span)))continue;
  var type=(model.GetDeclaredSymbol(local)as ILocalSymbol)?.Type;
  var symbol=model.GetDeclaredSymbol(method);
  if(type is null||type.TypeKind==TypeKind.Error||type.IsRefLikeType||symbol is null)continue;
  var index=method.ParameterList.Parameters.IndexOf(parameter);
  moves.Add(symbol.OriginalDefinition,new Move(method,index,local.Identifier.ValueText,type.ToDisplayString(SymbolDisplayFormat.MinimallyQualifiedFormat),local.Initializer.Value));
 }
}
Console.WriteLine(JsonSerializer.Serialize(moves.Values.Select(m=>new{file=m.Method.SyntaxTree.FilePath,method=m.Method.Identifier.ValueText,prepared=m.Type,variable=m.Name}),new JsonSerializerOptions{WriteIndented=true}));
if(apply)
 foreach(var tree in trees.Where(t=>t.FilePath.Length!=0))
 {
  var rewriter=new Prepare(compilation.GetSemanticModel(tree),moves);
  var rewritten=rewriter.Visit(tree.GetRoot())!;
  if(!rewritten.IsEquivalentTo(tree.GetRoot()))File.WriteAllText(tree.FilePath,rewritten.ToFullString(),new System.Text.UTF8Encoding(false));
 }

record Move(MethodDeclarationSyntax Method,int Index,string Name,string Type,ExpressionSyntax Initializer);
record PrefixMove(int Last,int ArgumentIndex,string Name,ILocalSymbol[] Locals);
sealed class WrapReturns(TypeSyntax taskType,TypeSyntax resultType):CSharpSyntaxRewriter
{
 public override SyntaxNode? VisitSimpleLambdaExpression(SimpleLambdaExpressionSyntax node)=>node;
 public override SyntaxNode? VisitParenthesizedLambdaExpression(ParenthesizedLambdaExpressionSyntax node)=>node;
 public override SyntaxNode? VisitAnonymousMethodExpression(AnonymousMethodExpressionSyntax node)=>node;
 public override SyntaxNode? VisitReturnStatement(ReturnStatementSyntax node)=>node.Expression is{}value?node.WithExpression(SyntaxFactory.ObjectCreationExpression(taskType.WithoutTrivia()).WithArgumentList(SyntaxFactory.ArgumentList(SyntaxFactory.SingletonSeparatedList(SyntaxFactory.Argument(SyntaxFactory.CastExpression(resultType.WithoutTrivia(),SyntaxFactory.ParenthesizedExpression(value.WithoutTrivia()))))))):node;
}
sealed class LiftPrefixes(Dictionary<MethodDeclarationSyntax,PrefixMove> plans):CSharpSyntaxRewriter
{
 public override SyntaxNode? VisitClassDeclaration(ClassDeclarationSyntax node)=>Lift((ClassDeclarationSyntax)base.VisitClassDeclaration(node)!,node.Members).WithTriviaFrom(node);
 ClassDeclarationSyntax Lift(ClassDeclarationSyntax visited,SyntaxList<MemberDeclarationSyntax> originals)
 {
  var members=new List<MemberDeclarationSyntax>();
  for(var i=0;i<originals.Count;i++)
  {
   if(originals[i]is not MethodDeclarationSyntax original||!plans.TryGetValue(original,out var plan)){members.Add(visited.Members[i]);continue;}
   var method=(MethodDeclarationSyntax)visited.Members[i];var ps=method.ParameterList.Parameters;var input=ps[plan.ArgumentIndex];
   var rest=ps.RemoveAt(plan.ArgumentIndex);var format=SymbolDisplayFormat.FullyQualifiedFormat.WithMiscellaneousOptions(SymbolDisplayMiscellaneousOptions.IncludeNullableReferenceTypeModifier|SymbolDisplayMiscellaneousOptions.EscapeKeywordIdentifiers|SymbolDisplayMiscellaneousOptions.UseSpecialTypes);
   foreach(var local in plan.Locals)rest=rest.Add(SyntaxFactory.Parameter(SyntaxFactory.Identifier(local.Name)).WithType(SyntaxFactory.ParseTypeName(local.Type.ToDisplayString(format)).WithTrailingTrivia(SyntaxFactory.Space)));
   var helper=method.WithIdentifier(SyntaxFactory.Identifier(plan.Name)).WithParameterList(method.ParameterList.WithParameters(rest))
    .WithModifiers(SyntaxFactory.TokenList(new[]{SyntaxFactory.Token(SyntaxKind.PrivateKeyword)}.Concat(method.Modifiers.Where(t=>t.IsKind(SyntaxKind.StaticKeyword))).Append(SyntaxFactory.Token(SyntaxKind.AsyncKeyword))))
    .WithBody(method.Body!.WithStatements(SyntaxFactory.List(method.Body.Statements.Skip(plan.Last+1))));
   var callArgs=ps.Where((_,index)=>index!=plan.ArgumentIndex).Select(p=>SyntaxFactory.Argument(SyntaxFactory.IdentifierName(p.Identifier))).Concat(plan.Locals.Select(l=>SyntaxFactory.Argument(SyntaxFactory.IdentifierName(l.Name))));
   var call=SyntaxFactory.InvocationExpression(SyntaxFactory.IdentifierName(plan.Name),SyntaxFactory.ArgumentList(SyntaxFactory.SeparatedList(callArgs)));
   var resultType=((GenericNameSyntax)method.ReturnType).TypeArgumentList.Arguments[0];var returns=new WrapReturns(method.ReturnType,resultType);
   var body=method.Body.Statements.Take(plan.Last+1).Select(s=>(StatementSyntax)returns.Visit(s)!).Append(SyntaxFactory.ReturnStatement(call));
   var wrapper=method.WithModifiers(SyntaxFactory.TokenList(method.Modifiers.Where(t=>!t.IsKind(SyntaxKind.AsyncKeyword))))
    .WithParameterList(method.ParameterList.WithParameters(ps.Replace(input,input.WithType(SyntaxFactory.ParseTypeName("ReadOnlySpan<CallArgumentValue>").WithTriviaFrom(input.Type!)))))
    .WithBody(method.Body.WithStatements(SyntaxFactory.List(body)));
   members.Add(wrapper.NormalizeWhitespace().WithLeadingTrivia(original.GetLeadingTrivia()));
   members.Add(helper.NormalizeWhitespace().WithLeadingTrivia(SyntaxFactory.CarriageReturnLineFeed));
  }
  return visited.WithMembers(SyntaxFactory.List(members));
 }
}
sealed class Immediate:CSharpSyntaxRewriter
{
 static bool CallArray(TypeSyntax type)=>type is ArrayTypeSyntax a&&a.ElementType.ToString().EndsWith("CallArgumentValue");
 public override SyntaxNode? VisitGenericName(GenericNameSyntax node)
 {
  var visited=(GenericNameSyntax)base.VisitGenericName(node)!;
  var types=visited.TypeArgumentList.Arguments;
  if(visited.Identifier.ValueText!="Func"||types.Count<2||!CallArray(types[0])||types[^1].ToString().Contains("Task"))return visited;
  return visited.WithTypeArgumentList(visited.TypeArgumentList.WithArguments(types.Replace(types[0],SyntaxFactory.ParseTypeName("ReadOnlySpan<CallArgumentValue>"))));
 }
 public override SyntaxNode? VisitMethodDeclaration(MethodDeclarationSyntax node)
 {
  var visited=(MethodDeclarationSyntax)base.VisitMethodDeclaration(node)!;
  if(node.Identifier.ValueText=="InvokeAsync"||node.Modifiers.Any(SyntaxKind.AsyncKeyword)||node.DescendantNodes().OfType<YieldStatementSyntax>().Any())return visited;
  var ps=visited.ParameterList.Parameters;
  foreach(var p in ps.Where(p=>p.Type is{}type&&CallArray(type)).ToArray())ps=ps.Replace(p,p.WithType(SyntaxFactory.ParseTypeName("ReadOnlySpan<CallArgumentValue>").WithTrailingTrivia(SyntaxFactory.Space)));
  return visited.WithParameterList(visited.ParameterList.WithParameters(ps));
 }
}
sealed class Substitute(Dictionary<string,ExpressionSyntax> values):CSharpSyntaxRewriter
{
 public override SyntaxNode? VisitIdentifierName(IdentifierNameSyntax node)=>values.TryGetValue(node.Identifier.ValueText,out var value)?value.WithTriviaFrom(node):base.VisitIdentifierName(node);
}
sealed class Prepare(SemanticModel model,Dictionary<ISymbol,Move> moves):CSharpSyntaxRewriter
{
 public override SyntaxNode? VisitInvocationExpression(InvocationExpressionSyntax node)
 {
  var info=model.GetSymbolInfo(node);
  var candidates=info.Symbol is{}symbol?new[]{symbol}:info.CandidateSymbols.ToArray();
  var found=candidates.OfType<IMethodSymbol>().Where(x=>moves.ContainsKey(x.OriginalDefinition)).Select(x=>moves[x.OriginalDefinition]).Distinct().ToArray();
  var visited=(InvocationExpressionSyntax)base.VisitInvocationExpression(node)!;
  if(found.Length!=1)return visited;
  var move=found[0];
  if(visited.ArgumentList.Arguments.Count!=move.Method.ParameterList.Parameters.Count)return visited;
  var map=new Dictionary<string,ExpressionSyntax>();
  for(var i=0;i<move.Method.ParameterList.Parameters.Count;i++)map.Add(move.Method.ParameterList.Parameters[i].Identifier.ValueText,visited.ArgumentList.Arguments[i].Expression.WithoutTrivia());
  var expression=(ExpressionSyntax)new Substitute(map).Visit(move.Initializer.WithoutTrivia())!;
  var argument=visited.ArgumentList.Arguments[move.Index].WithExpression(expression);
  return visited.WithArgumentList(visited.ArgumentList.WithArguments(visited.ArgumentList.Arguments.Replace(visited.ArgumentList.Arguments[move.Index],argument)));
 }
 public override SyntaxNode? VisitMethodDeclaration(MethodDeclarationSyntax node)
 {
  var visited=(MethodDeclarationSyntax)base.VisitMethodDeclaration(node)!;
  var symbol=model.GetDeclaredSymbol(node);
  if(symbol is null||!moves.TryGetValue(symbol.OriginalDefinition,out var move))return visited;
  var parameter=visited.ParameterList.Parameters[move.Index].WithIdentifier(SyntaxFactory.Identifier(move.Name)).WithType(SyntaxFactory.ParseTypeName(move.Type).WithTrailingTrivia(SyntaxFactory.Space));
  return visited.WithParameterList(visited.ParameterList.WithParameters(visited.ParameterList.Parameters.Replace(visited.ParameterList.Parameters[move.Index],parameter)))
   .WithBody(visited.Body!.WithStatements(visited.Body.Statements.RemoveAt(0)));
 }
}

sealed class RenameSyncBorrow:CSharpSyntaxRewriter
{
 public override SyntaxNode? VisitIdentifierName(IdentifierNameSyntax node)=>node.Identifier.ValueText=="InvokeBorrowed"?node.WithIdentifier(SyntaxFactory.Identifier("Invoke").WithTriviaFrom(node.Identifier)):base.VisitIdentifierName(node);
}
