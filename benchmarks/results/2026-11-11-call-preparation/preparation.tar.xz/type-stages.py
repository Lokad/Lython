exec(__import__('pathlib').Path(__file__).with_name('stage-edits.py').read_text(encoding='utf-8').split('# Owners transfer')[0])
p=root/'PyType.cs';s=p.read_text(encoding='utf-8')
s=s.replace('''        => InvokeCoreAsync(arguments, span, context, false).GetAwaiter().GetResult();''','''    {
        context.CheckExecution(span);
        if (IsBuiltinMetatype) return InvokeBuiltInType(arguments, span, context);
        var instance = AllocateInstanceAsync(arguments, span, context, false).GetAwaiter().GetResult();
        context.CheckExecution(span);
        return instance is PyInstance result && result.Type.IsSubtypeOf(this)
            ? InitializeInstance(result, arguments, span, context) : instance;
    }''',1)
s=s.replace('''        => InvokeCoreAsync(arguments, span, context, true);''','''    {
        context.CheckExecution(span);
        if (IsBuiltinMetatype) return new(InvokeBuiltInType(arguments, span, context));
        return ConstructAsync(arguments, span, context);
    }

    private async ValueTask<object> ConstructAsync(CallArgumentValue[] arguments, LythonSourceSpan span, LythonRuntime.ExecutionContext context)
    {
        var instance = await AllocateInstanceAsync(arguments, span, context, true).ConfigureAwait(false);
        context.CheckExecution(span);
        return instance is PyInstance result && result.Type.IsSubtypeOf(this)
            ? await InitializeInstanceAsync(result, arguments, span, context, true).ConfigureAwait(false) : instance;
    }''',1)
a,b,_=method(s,'private async ValueTask<object> InvokeCoreAsync(')
m=s[a:b]
m=m.replace('async ValueTask<object> InvokeCoreAsync(CallArgumentValue[]','ValueTask<object> AllocateInstanceAsync(ReadOnlySpan<CallArgumentValue>')
m=m.replace('''        if (IsBuiltinMetatype)
            return InvokeBuiltInType(arguments, span, context);

        object instance;
''','')
m=m.replace('instance = new PyInstance(this, context.MemoryGovernor, span);','return new(new PyInstance(this, context.MemoryGovernor, span));')
m=m.replace('''            instance = asynchronous
                ? await function.InvokeAsync(arguments, span, context, this).ConfigureAwait(false)
                : function.Invoke(arguments, span, context, this);''','''            return asynchronous ? function.InvokeAsync(arguments, span, context, this)
                : new(function.Invoke(arguments, span, context, this));''')
m=m.replace('''            instance = asynchronous
                ? await callable.InvokeAsync(prefixed, span, context).ConfigureAwait(false)
                : callable.Invoke(prefixed, span, context);''','''            return asynchronous ? callable.InvokeAsync(prefixed, span, context)
                : new(callable.Invoke(prefixed, span, context));''')
point=m.index('        context.CheckExecution(span);\n        if (instance is not PyInstance')
m=m[:point]+'    }'
s=s[:a]+m+s[b:]
a,b,_=method(s,'internal async ValueTask<object> InitializeInstanceAsync(')
s=s[:a]+'''internal ValueTask<object> InitializeInstanceAsync(PyInstance result, CallArgumentValue[] arguments,
        LythonSourceSpan span, LythonRuntime.ExecutionContext context, bool asynchronous)
        => asynchronous ? InitializePendingInstanceAsync(result, arguments, span, context)
            : new(InitializeInstance(result, arguments, span, context));

    private object InitializeInstance(PyInstance result, ReadOnlySpan<CallArgumentValue> arguments,
        LythonSourceSpan span, LythonRuntime.ExecutionContext context)
    {
        var initializer = GetInitializer(result, context, span, out var engine);
        if (engine)
        {
            LythonRuntime.JsonSubclassSupport.RunEngineInit(result.Type, result, arguments, span, context);
            context.CheckExecution(span);
            return result;
        }
        if (initializer is null) return result;
        var bound = BindInitializerAsync(result, initializer, span, context, false).GetAwaiter().GetResult();
        return CompleteInitializerAsync(InvokeInitializer(result, bound, arguments, span, context, false), result, span, context).GetAwaiter().GetResult();
    }

    private async ValueTask<object> InitializePendingInstanceAsync(PyInstance result, CallArgumentValue[] arguments,
        LythonSourceSpan span, LythonRuntime.ExecutionContext context)
    {
        var initializer = GetInitializer(result, context, span, out var engine);
        if (engine)
        {
            await LythonRuntime.JsonSubclassSupport.RunEngineInitAsync(result.Type, result, arguments, span, context).ConfigureAwait(false);
            context.CheckExecution(span);
            return result;
        }
        if (initializer is null) return result;
        var bound = await BindInitializerAsync(result, initializer, span, context, true).ConfigureAwait(false);
        return await CompleteInitializerAsync(InvokeInitializer(result, bound, arguments, span, context, true), result, span, context).ConfigureAwait(false);
    }

    private static object? GetInitializer(PyInstance result, LythonRuntime.ExecutionContext context, LythonSourceSpan span, out bool engine)
    {
        context.CheckExecution(span);
        engine = result.Type.JsonBase != JsonBaseKind.None && !LythonRuntime.JsonSubclassSupport.HasGuestInit(result.Type, context);
        return !engine && result.Type.TryLookupInMro("__init__", 0, out var initializer, out _) ? initializer : null;
    }

    private static ValueTask<object> BindInitializerAsync(PyInstance result, object initializer,
        LythonSourceSpan span, LythonRuntime.ExecutionContext context, bool asynchronous)
        => initializer is PyFunctionBase ? new(initializer)
            : asynchronous ? PyAttributeLookup.BindForInstanceAsync(result, initializer, context, span)
                : new(PyAttributeLookup.BindForInstance(result, initializer, context, span));

    private static ValueTask<object> InvokeInitializer(PyInstance result, object initializer, ReadOnlySpan<CallArgumentValue> arguments,
        LythonSourceSpan span, LythonRuntime.ExecutionContext context, bool asynchronous)
    {
        if (initializer is PyFunctionBase function)
            return asynchronous ? function.InvokeAsync(arguments, span, context, result)
                : new(function.Invoke(arguments, span, context, result));
        context.CheckExecution(span);
        if (initializer is not LythonRuntime.ICallable callable)
            throw new LythonRuntimeException("TypeError", $"Class '{result.Type.Name}' has a non-callable __init__.", span);
        if (!asynchronous) return new(callable.Invoke(arguments, span, context));
        // Dynamic async callables own an invocation-private packet through completion.
        return initializer is PyBoundMethod { Function: PyFunctionBase }
            ? callable.InvokeBorrowedAsync(arguments, span, context)
            : callable.InvokeAsync(CopyArguments(arguments, context, span), span, context);
    }

    private static async ValueTask<object> CompleteInitializerAsync(ValueTask<object> pending, PyInstance result,
        LythonSourceSpan span, LythonRuntime.ExecutionContext context)
    {
        var initialized = await pending.ConfigureAwait(false);
        context.CheckExecution(span);
        if (!ReferenceEquals(initialized, PyNone.Instance))
            throw new LythonRuntimeException("TypeError", $"__init__ for class '{result.Type.Name}' must return None.", span);
        return result;
    }'''+s[b:]
p.write_text(s,encoding='utf-8')
