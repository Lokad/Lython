exec(__import__('pathlib').Path(__file__).with_name('stage-edits.py').read_text(encoding='utf-8').split('# Owners transfer')[0])

def generator(m):
    # Classify the operation and snapshot only the operands its protocol uses.
    m=m.replace('async ValueTask<object> InvokeCoreAsync(CallArgumentValue[]','ValueTask<object> InvokeCoreAsync(ReadOnlySpan<CallArgumentValue>')
    start=m.index('                if (arguments.Any')
    m=m[:start]+'''                if (HasKeywordArguments(arguments)) throw new LythonRuntimeException("TypeError", "generator methods accept positional arguments only", span);
                if (name == "__iter__" && arguments.Length == 0) return new(generator);
                if (name == "close")
                {
                    if (arguments.Length != 0) throw new LythonRuntimeException("TypeError", "close() takes no arguments", span);
                    return CloseAsync(span, context, asynchronous);
                }
                if (name == "throw")
                {
                    if (arguments.Length is < 1 or > 3) throw new LythonRuntimeException("TypeError", "throw() takes one to three arguments", span);
                    return ThrowAsync(arguments[0].Value, arguments.Length > 1 ? arguments[1].Value : PyNone.Instance,
                        arguments.Length == 3 ? arguments[2].Value : PyNone.Instance, span, context, asynchronous);
                }
                if (name == "send" && arguments.Length == 1)
                    return AdvanceAsync(arguments[0].Value, null, span, asynchronous);
                if (name != "__next__" || arguments.Length != 0) throw new LythonRuntimeException("TypeError", "invalid generator method arguments", span);
                return AdvanceAsync(PyNone.Instance, null, span, asynchronous);
            }

            private async ValueTask<object> CloseAsync(LythonSourceSpan span, ExecutionContext context, bool asynchronous)
            {
                if (!generator._started || generator._completed)
                { await generator.CompleteAsync(asynchronous).ConfigureAwait(false); return PyNone.Instance; }
                try
                {
                    var exit = new LythonRuntimeException("GeneratorExit", "", span);
                    var closed = asynchronous ? await generator.AdvanceAsync(PyNone.Instance, exit).ConfigureAwait(false)
                        : generator.Advance(PyNone.Instance, exit);
                    if (closed.HasValue) throw new LythonRuntimeException("RuntimeError", "generator ignored GeneratorExit", span);
                    return generator.ReturnValue;
                }
                catch (LythonRuntimeException exception) when (exception.ExceptionType == "GeneratorExit") { return PyNone.Instance; }
            }

            private async ValueTask<object> ThrowAsync(object exception, object value, object traceback,
                LythonSourceSpan span, ExecutionContext context, bool asynchronous)
            {
                if (exception is PyException && value is not PyNone)
                    throw new LythonRuntimeException("TypeError", "instance exception may not have a separate value", span);
                if (exception is not PyException && exception is IPythonExceptionType && exception is ICallable callable)
                {
                    var values = value is PyNone ? Array.Empty<CallArgumentValue>()
                        : value is PyTuple tuple ? tuple.Select(CallArgumentValue.Positional).ToArray() : [CallArgumentValue.Positional(value)];
                    exception = asynchronous ? await callable.InvokeAsync(values, span, context).ConfigureAwait(false) : callable.Invoke(values, span, context);
                }
                if (exception is not PyException raised || traceback is not PyNone)
                    throw new LythonRuntimeException("TypeError", "exceptions must derive from BaseException; traceback must be None", span);
                var injected = new LythonRuntimeException(raised.Identity, raised.Message, span, null, raised.Value)
                { OriginalPythonException = raised, Attribution = raised.Attribution };
                return await AdvanceAsync(PyNone.Instance, injected, span, asynchronous).ConfigureAwait(false);
            }

            private async ValueTask<object> AdvanceAsync(object sent, LythonRuntimeException? injected, LythonSourceSpan span, bool asynchronous)
            {
                var result = asynchronous ? await generator.AdvanceAsync(sent, injected).ConfigureAwait(false)
                    : generator.Advance(sent, injected);
                if (result.HasValue) return result.Value;
                throw new LythonRuntimeException("StopIteration", "", span, null, generator.ReturnValue);
            }'''
    return m
transform('LythonRuntime.Generators.cs','private async ValueTask<object> InvokeCoreAsync(',generator)

def url(m):
    m=m.replace('async ValueTask<object> InvokeCoreAsync(CallArgumentValue[]','ValueTask<object> InvokeCoreAsync(ReadOnlySpan<CallArgumentValue>')
    start=m.index('                    var values = await UrlComponentsAsync')
    end=m.index('\n                }',start)
    make=m[start:end].replace('bound[0]','iterable')
    m=m[:start]+'''                    return MakeAsync(bound[0], span, context, asynchronous);'''+m[end:]
    m=m.replace('return UrlResult.Create(type, values, context, span);','return new(UrlResult.Create(type, values, context, span));',1)
    start=m.index('                    using var preflight16809')
    end=m.index('\n                }\n                if (arguments.Length',start)
    convert=m[start:end]
    m=m[:start]+'''                    return ConvertAsync(encodingValue, errorsValue, span, context, asynchronous);'''+m[end:]
    m=m.replace('return await ReassembleValuesAsync(receiver!, span, context, asynchronous, type.Parameters).ConfigureAwait(false);','return ReassembleValuesAsync(receiver!, span, context, asynchronous, type.Parameters);')
    m=m.replace('return dict;','return new(dict);')
    return m+'''

            private async ValueTask<object> MakeAsync(object iterable, LythonSourceSpan span, ExecutionContext context, bool asynchronous)
            {
'''+make+'''
            }

            private async ValueTask<object> ConvertAsync(object encodingValue, object errorsValue,
                LythonSourceSpan span, ExecutionContext context, bool asynchronous)
            {
'''+convert+'''
            }'''
transform('LythonRuntime.UrllibParseModule.Results.cs','private async ValueTask<object> InvokeCoreAsync(',url)

# Validate the call shape before the optional guest truth protocols, as Python's
# function binder does. The existing semantic option dictionary is the owned state.
def make_dataclass(m):
    m=m.replace('async ValueTask<object> InvokeCore(CallArgumentValue[]','ValueTask<object> InvokeCore(ReadOnlySpan<CallArgumentValue>')
    m=m.replace('''                        var truth = asynchronous ? await LythonRuntime.IsTruthyAsync(argument.Value, context, span).ConfigureAwait(false) : LythonRuntime.IsTruthy(argument.Value, context, span);
                        options = ApplyDataclassOption(options, argument.KeywordName, truth, "dataclasses.make_dataclass", span);''','''                        if (!IsDataclassOption(argument.KeywordName))
                            throw CallErrors.UnexpectedKeyword(PythonCallableKind.Builtin, "dataclasses.make_dataclass", argument.KeywordName, span);''')
    start=m.index('            var name = RuntimeArgumentValidation.ExpectString(clsName,')
    m=m[:start]+'''            return MakeTypeAsync(clsName, fieldsArgument, basesArgument, namespaceArgument, options, rawOptions, span, context, asynchronous);
        }

        private static async ValueTask<object> MakeTypeAsync(object clsName, object fieldsArgument, object? basesArgument,
            object? namespaceArgument, DataclassDecoratorSyntax options, Dictionary<string, object> rawOptions,
            LythonSourceSpan span, LythonRuntime.ExecutionContext context, bool asynchronous)
        {
            foreach (var pair in rawOptions)
            {
                var truth = asynchronous ? await LythonRuntime.IsTruthyAsync(pair.Value, context, span).ConfigureAwait(false)
                    : LythonRuntime.IsTruthy(pair.Value, context, span);
                options = ApplyDataclassOption(options, pair.Key, truth, "dataclasses.make_dataclass", span);
            }
'''+m[start:]
    return m
transform('PyDataclass.cs','private static async ValueTask<object> InvokeCore(',make_dataclass)

# Resolve the remaining namedtuple options once into semantic fields. No input
# vector survives a field iterator or defaults callback.
p=root/'LythonRuntime.CollectionsModule.cs';s=p.read_text(encoding='utf-8')
s=s.replace('record NamedTupleCallShape(string TypeName, object FieldNamesValue);','record NamedTupleCallShape(string TypeName, object FieldNamesValue, object Rename, object Defaults, object Module);')
s=s.replace('return new NamedTupleCallShape(typeName.AsString(), fieldNamesValue);','''return new NamedTupleCallShape(typeName.AsString(), fieldNamesValue,
            TryGetArgument(arguments, 2, "rename", span, out var rename) ? rename : false,
            TryGetArgument(arguments, 3, "defaults", span, out var defaults) ? defaults : PyNone.Instance,
            TryGetArgument(arguments, 4, "module", span, out var module) ? module : PyNone.Instance);''')
s=s.replace('ValidateNamedTupleFields(shape, names, arguments, span)','ValidateNamedTupleFields(shape, names, span)')
s=s.replace('TryGetArgument(arguments, 3, "defaults", span, out var value) && value is not PyNone','shape.Defaults is not PyNone')
s=s.replace('ToSequence(value, span, context), fields.Count','ToSequence(shape.Defaults, span, context), fields.Count')
s=s.replace('ToSequenceAsync(value, span, context), fields.Count','ToSequenceAsync(shape.Defaults, span, context), fields.Count')
s=s.replace('defaults?.Items, arguments, span, context)','defaults?.Items, shape.Module, span, context)')
s=s.replace('''ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span)
    {
        if (!IsValidIdentifier(shape.TypeName)''','''LythonSourceSpan span)
    {
        if (!IsValidIdentifier(shape.TypeName)''')
s=s.replace('var rename = TryGetArgument(arguments, 2, "rename", span, out var value) && IsTruthy(value);','var rename = IsTruthy(shape.Rename);')
s=s.replace('''ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
    {
        // Like CPython, an explicit module''','''object moduleValue, LythonSourceSpan span, ExecutionContext context)
    {
        // Like CPython, an explicit module''')
s=s.replace('TryGetArgument(arguments, 4, "module", span, out var moduleValue) && moduleValue is not PyNone','moduleValue is not PyNone')
s=s.replace('BuildNamedTupleType(typeName, normalized, null, [], span, context)','BuildNamedTupleType(typeName, normalized, null, PyNone.Instance, span, context)')
p.write_text(s,encoding='utf-8')
