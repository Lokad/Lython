from pathlib import Path
import json,re
r=Path(__file__).parent;repo=Path.cwd();changed=[];removed=0
for base in ['src/Lokad.Lython','tests/Lokad.Lython.Tests']:
 for p in(repo/base).rglob('*.cs'):
  if {'bin','obj'}&set(p.parts):continue
  before=p.read_text(encoding='utf-8');t=before
  t,n=re.subn(r'    (?:    )?public object Invoke\(CallArgumentValue\[\] arguments, LythonSourceSpan span, (?:LythonRuntime\.)?ExecutionContext context\)\n        (?:    )?=> InvokeBorrowed\(arguments, span, context\);\n\n','',t);removed+=n
  if p.name=='LythonRuntime.Calls.cs':
   start=t.index('        // Consume borrowed inputs before returning pending work.');end=t.index('        ValueTask<object> InvokeBorrowedAsync(',start)
   t=t[:start]+'''        // Actual asynchronous consumers may retain their invocation-private
        // packet until completion. Synchronous entry only borrows its inputs.
'''+t[end:]
  t=t.replace('InvokeBorrowed(', 'Invoke(')
  t=re.sub(r'(?m)(\bobject Invoke\()CallArgumentValue\[\]( arguments,)',r'\1ReadOnlySpan<CallArgumentValue>\2',t)
  if p.name=='PyFunctionBase.cs':t=t.replace('=> Invoke(arguments, span, context);','=> Invoke(arguments, span, context, receiver: null);')
  # Propagate the existing synchronous implementation delegate, not async arrays.
  t=re.sub(r'Func<CallArgumentValue\[\], LythonSourceSpan, (LythonRuntime\.)?ExecutionContext, object>',r'Func<ReadOnlySpan<CallArgumentValue>, LythonSourceSpan, \1ExecutionContext, object>',t)
  # Ordinary synchronous helpers can consume the same borrowed representation.
  t=re.sub(r'(?m)(^\s*(?:(?:public|private|internal|protected|static|sealed|virtual|override|new)\s+)+(?:object|bool|int|long|string|void|Py\w+|Bound\w+|CallArgumentValue\[\])\??\s+\w+\([^;{=]*?)CallArgumentValue\[\](\s+\w+)',r'\1ReadOnlySpan<CallArgumentValue>\2',t)
  if t!=before:p.write_text(t,encoding='utf-8',newline='\n');changed.append(p.relative_to(repo).as_posix())
(r/'migration.json').write_text(json.dumps(dict(files=changed,removedSyncForwarders=removed),indent=2)+'\n',encoding='utf-8');print(len(changed),'files; removed',removed,'sync array forwarders; shared async consumer preparation next.')
