from pathlib import Path
import re
root=Path('tests/Lokad.Lython.Tests')
log=Path('.git/agent-notes/review-20261031/call-preparation-r236/tests-build-1.log').read_text(encoding='utf-8-sig')
files={Path(m[1]).name for m in re.finditer(r'(.+?\.cs)\(\d+,\d+\): error ',log)}
for name in files:
    p=root/name;s=p.read_text(encoding='utf-8')
    s=re.sub(r'Assert\.Single\((arguments|args)\)',r'CallArgumentAssert.Single(\1)',s)
    s=re.sub(r'Assert\.Empty\((arguments|args)\)',r'Assert.True(\1.IsEmpty)',s)
    p.write_text(s,encoding='utf-8')

def change(name,old,new):
    p=root/name;s=p.read_text(encoding='utf-8');assert old in s,(name,old[:70]);p.write_text(s.replace(old,new),encoding='utf-8')

(root/'CallArgumentAssert.cs').write_text('''using Lokad.Lython.Runtime;

namespace Lokad.Lython.Tests;

internal static class CallArgumentAssert
{
    internal static CallArgumentValue Single(ReadOnlySpan<CallArgumentValue> arguments)
    {
        Assert.Equal(1, arguments.Length);
        return arguments[0];
    }
}
''',encoding='utf-8')

p=root/'CacheKeyAccountingTests.cs';s=p.read_text(encoding='utf-8')
a=s.index('        var keyModeType =');b=s.index('\n    }',a)
s=s[:a]+'''        return Assert.IsType<PyTuple>(LythonRuntime.BuildCacheKey(arguments,
            (LythonRuntime.CacheKeyMode)mode, context, span, out _));'''+s[b:]
s=s.replace('using System.Reflection;\n','');p.write_text(s,encoding='utf-8')

change('CollectionKwargsKeyAccountingTests.cs','typeof(CallArgumentValue[])','typeof(ReadOnlySpan<CallArgumentValue>)')
change('CollectionKwargsKeyAccountingTests.cs','return method.Invoke(null, [arguments, span, context])!;','return method.CreateDelegate<Func<ReadOnlySpan<CallArgumentValue>, LythonSourceSpan, LythonRuntime.ExecutionContext, object>>()(arguments, span, context);')
change('ZipInfoAccountingTests.cs','LythonRuntime.ExecutionContext? context, LythonSourceSpan? span','LythonRuntime.ExecutionContext context, LythonSourceSpan span')
change('ZipInfoAccountingTests.cs','''        var method = type.GetMethod("Invoke") ?? throw new InvalidOperationException("Invoke not found.");
        return method.Invoke(instance, [arguments, span, context])
            ?? throw new InvalidOperationException("Invoke returned null.");''','''        return Assert.IsAssignableFrom<LythonRuntime.ICallable>(instance).Invoke(arguments, span, context);''')
change('StructuredUrlAccountingTests.cs','Deny(LythonRuntime.ICallable callable, ReadOnlySpan<CallArgumentValue> arguments','Deny(LythonRuntime.ICallable callable, CallArgumentValue[] arguments')
change('MethodBodyCompilationBoundaryTests.cs','Input(CallArgumentValue[] arguments)','Input(ReadOnlySpan<CallArgumentValue> arguments)')
change('SimpleFunctionExecutionBoundaryTests.cs','var values = arguments.Select(argument => (object?)argument.Value).ToArray();','var values = new object?[arguments.Length];\n        for (var i = 0; i < arguments.Length; i++) values[i] = arguments[i].Value;')

# A callable retaining an input must create and fund its own surviving storage.
change('BoundMethodInvocationBoundaryTests.cs','''            Calls.Add((arguments, span, context));
            return arguments;''','''            var bytes = checked(32L + 32L * arguments.Length);
            using var storage = context.MemoryGovernor.ReserveTemporary(bytes, span);
            var retained = arguments.ToArray();
            storage.Commit(bytes);
            Calls.Add((retained, span, context));
            return retained;''')
change('BoundMethodInvocationBoundaryTests.cs','GeneralWrappedCallablesKeepFreshRetainableArrays','GeneralWrappedCallablesRetainTheirOwnFundedArguments')
change('ConstructorOwnershipTests.cs','''        { Arguments = arguments; return PyNone.Instance; }''','''        {
            var bytes = checked(32L + 32L * arguments.Length);
            using var storage = context.MemoryGovernor.ReserveTemporary(bytes, span);
            Arguments = arguments.ToArray();
            storage.Commit(bytes);
            return PyNone.Instance;
        }''')
change('ConstructorOwnershipTests.cs','DynamicInitializerOwnsArgumentsAfterCallerReturnsItsPacket','DynamicInitializerCanRetainItsOwnFundedArgumentSnapshot')

change('ExecutableCallTransferTests.cs','''        internal void AssertReleasedArguments()
            => Assert.All(_arguments!, argument => Assert.True(argument.Value is null or PyNone));''','''        internal void AssertReleasedArguments()
        {
            // A sync span cannot escape. Pending async inputs still expose their
            // real invocation-owned packet, which must be cleared on completion.
            if (_arguments is not null) Assert.All(_arguments, argument => Assert.True(argument.Value is null or PyNone));
        }''')
change('ExecutableCallTransferTests.cs','''            _arguments = arguments;
            Check(context);
            return Complete(span);''','''            Check(context, arguments);
            return Complete(span);''')
change('ExecutableCallTransferTests.cs','''            Assert.NotNull(_arguments);
            Assert.Equal(2, _arguments.Length);''','''            Assert.NotNull(_arguments);
            Check(context, _arguments);
        }

        private void Check(LythonRuntime.ExecutionContext context, ReadOnlySpan<CallArgumentValue> arguments)
        {
            Assert.Equal(2, arguments.Length);''')
p=root/'ExecutableCallTransferTests.cs';s=p.read_text(encoding='utf-8');a=s.index('        private void Check(');b=s.index('        private object Complete(',a);s=s[:a]+s[a:b].replace('_arguments[','arguments[')+s[b:];p.write_text(s,encoding='utf-8')

prod=Path('src/Lokad.Lython/Runtime')
for name,old,new in [('LythonRuntime.FunctoolsCache.cs','private enum CacheKeyMode','internal enum CacheKeyMode'),('LythonRuntime.Functools.Cache.cs','private static object BuildCacheKey(','internal static object BuildCacheKey(')]:
    p=prod/name;s=p.read_text(encoding='utf-8');assert old in s;p.write_text(s.replace(old,new),encoding='utf-8')
