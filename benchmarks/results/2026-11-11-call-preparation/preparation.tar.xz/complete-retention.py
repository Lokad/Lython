from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).resolve().parent
repo=Path.cwd()
exec((r/'stage-edits.py').read_text(encoding='utf-8').split('# Owners transfer')[0])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=json.loads((r/'before.json').read_text(encoding='utf-8'))
p=root/'LythonRuntime.Calls.Binding.cs';s=p.read_text(encoding='utf-8')
old='            var values = arguments.Select(argument => argument.Value).ToArray();\n            var args = new PyTuple(values, context.MemoryGovernor, span);\n            var payload = values.Length == 0 ? PyNone.Instance : values.Length == 1 ? values[0] : args;';assert old in s
s=s.replace(old,'            var args = PyTuple.FromPositionalArguments(arguments, context.MemoryGovernor, span, context);\n            var payload = args.Count == 0 ? PyNone.Instance : args.Count == 1 ? args[0] : args;');p.write_text(s,encoding='utf-8')
p=root/'LythonRuntime.SubprocessModule.Errors.cs';s=p.read_text(encoding='utf-8')
old='new PyTuple(arguments.Where(a => a.IsPositional).Select(a => a.Value), context.MemoryGovernor, span)'
assert s.count(old)==2,s.count(old)
s=s.replace(old,'PyTuple.FromPositionalArguments(arguments, context.MemoryGovernor, span, context)');p.write_text(s,encoding='utf-8')

# Removing the sync carrier policy does not require converting any native API.
p=root/'LythonRuntime.Calls.cs';s=p.read_text(encoding='utf-8')
old='''        return InvokeCallable(
            callable,
            callSpan,
            context,
            new DeferredCallArguments(expandArguments));
    }

    private static object InvokeCallable<TArguments>(
        ICallable callable,
        LythonSourceSpan callSpan,
        ExecutionContext context,
        TArguments arguments)
        where TArguments : struct, ICallArguments
    {'''
assert old in s;s=s.replace(old,'')
s=s.replace('callable.Invoke(arguments.Expand(), callSpan, context)','callable.Invoke(expandArguments(), callSpan, context)')
old='''        return InvokeCallable(
            callable,
            callSpan,
            context,
            new PreparedCallArguments(arguments));'''
assert old in s
s=s.replace(old,'''        context.EnterInterpreterFrame(callSpan);
        try { return RuntimeValue(callable.Invoke(arguments, callSpan, context)); }
        catch (Exception error) when (TryTranslateCallableException(error, callSpan, out var translated)) { throw translated; }
        finally { context.LeaveInterpreterFrame(); }''')
a=s.index('    private interface ICallArguments');b=s.index('    private interface IAsyncCallArguments',a);s=s[:a]+s[b:]
s=s.replace(' : ICallArguments, IAsyncCallArguments',' : IAsyncCallArguments').replace('        public CallArgumentValue[] Expand() => Arguments;\n','')
p.write_text(s,encoding='utf-8')

for name in ['docs/RUNTIME.md','CHANGELOG.md','tests/README.md']:
    (repo/name).write_bytes(subprocess.check_output(['git','show','HEAD:'+name]))

keep={p.relative_to(repo).as_posix()for p in root.glob('*.cs')if sha(p)!=before['sourceHashes'].get(p.relative_to(repo).as_posix(),sha(p))}
keep.add('src/Lokad.Lython/Runtime/PyTuple.cs')
expected={'src/Lokad.Lython/Runtime/'+n for n in ['LythonRuntime.ModernTyping.cs','PyDataclass.cs','PyTuple.cs','LythonRuntime.Calls.Binding.cs','LythonRuntime.SubprocessModule.Errors.cs','LythonRuntime.Calls.cs']}
assert keep==expected,(keep,expected)
for name,h in before['sourceHashes'].items():
    if name not in expected:assert sha(repo/name)==h,name
(r/'retained-subset.json').write_text(json.dumps(dict(prototypeDecision='Withdraw the complete canonical-span conversion. Its many shared/native preparation stages add more implementation complexity than justified by the representative paths, which already borrow. No useful whole-script allocation reduction or qualified CPU gain is established. Initial captured-text adversity did not repeat; other adverse and unstable measurements remain unresolved, not permanent design vetoes.',retained=sorted(expected),checks='All other snapshotted source and internal tests restored byte-for-byte; retain public binding/descriptor/cancellation regressions and independent fixes. Fresh nonincremental build and focused validation follow.',next='Assess a complete native dictionary-aggregation loop using existing non-admitting accumulation and native iteration. Target per-element VM dispatch rather than argument packaging.'),indent=2)+'\n',encoding='utf-8')
print('Broad prototype withdrawn; six independent production edits retained. All other original source/internal tests verified byte-identical. Prototype source, cores and adverse observations preserved.')
