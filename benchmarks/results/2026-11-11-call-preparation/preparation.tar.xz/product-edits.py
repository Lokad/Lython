exec(__import__('pathlib').Path(__file__).with_name('stage-edits.py').read_text(encoding='utf-8').split('# Owners transfer')[0])
def bind(m):
    m=m.replace('async ValueTask<(int Count, long Repeat)> BindProductAsync(CallArgumentValue[]','ValueTask<(int Count, long Repeat)> BindProductAsync(ReadOnlySpan<CallArgumentValue>')
    m=m.replace('long repeat = 1;','object repeatArgument = BigInteger.One;')
    m=m.replace('''                repeat = await CoerceItertoolsIndexAsync(argument.Value, span, context, asynchronous).ConfigureAwait(false);
                if (repeat < 0) throw new LythonRuntimeException("ValueError", "repeat argument cannot be negative", span);''','''                repeatArgument = argument.Value;''')
    point=m.index('        // CPython checks')
    m=m[:point]+'''        return ValidateProductRepeatAsync(count, repeatArgument, span, context, asynchronous);
    }

    private static async ValueTask<(int Count, long Repeat)> ValidateProductRepeatAsync(int count, object repeatArgument,
        LythonSourceSpan span, ExecutionContext context, bool asynchronous)
    {
        var repeat = await CoerceItertoolsIndexAsync(repeatArgument, span, context, asynchronous).ConfigureAwait(false);
        if (repeat < 0) throw new LythonRuntimeException("ValueError", "repeat argument cannot be negative", span);
'''+m[point:]
    return m
transform('LythonRuntime.ItertoolsModule.cs','private static async ValueTask<(int Count, long Repeat)> BindProductAsync(',bind)
def product(m):
    m=m.replace('async ValueTask<object> ProductAsync(CallArgumentValue[]','ValueTask<object> ProductAsync(ReadOnlySpan<CallArgumentValue>')
    point=m.index('        var (count, repeat) =')
    m=m[:point]+'''        var count = 0;
        foreach (var argument in arguments) if (argument.IsPositional) count++;
        var working = context.MemoryGovernor.ReserveTemporary(count == 0 ? 0 : checked(32L + 8L * count), span);
        try
        {
            var iterables = count == 0 ? Array.Empty<object>() : new object[count];
            var index = 0;
            foreach (var argument in arguments) if (argument.IsPositional) iterables[index++] = argument.Value;
            return ProductPreparedAsync(iterables, BindProductAsync(arguments, span, context, true), working, span, context);
        }
        catch { working.Dispose(); throw; }
    }

    private static async ValueTask<object> ProductPreparedAsync(object[] iterables, ValueTask<(int Count, long Repeat)> binding,
        MemoryGovernor.TemporaryMemoryReservation working, LythonSourceSpan span, ExecutionContext context)
    {
        using var owner = working;
'''+m[point:]
    m=m.replace('await BindProductAsync(arguments, span, context, true).ConfigureAwait(false)','await binding.ConfigureAwait(false)')
    m=m.replace('''            foreach (var argument in arguments)
                if (argument.IsPositional) pools[index++] = await MaterializeItSequenceAsync(argument.Value, span, context).ConfigureAwait(false);''','''            foreach (var iterable in iterables)
                pools[index++] = await MaterializeItSequenceAsync(iterable, span, context).ConfigureAwait(false);''')
    return m
transform('LythonRuntime.ItertoolsModule.cs','private static async ValueTask<object> ProductAsync(',product)
