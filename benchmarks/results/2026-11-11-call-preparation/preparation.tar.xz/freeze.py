from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent
repo=Path.cwd()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=json.loads((r/'before.json').read_text(encoding='utf-8'))
assert not (r/'diagnostic-identity.json').exists()
for tf in ['net11.0','net10.0']:
    log=(r/f'internal-final-{tf}.log').read_text(encoding='utf-8-sig')
    assert 'Passed!' in log and 'Failed!' not in log,tf
    log=(r/f'call-final-{tf}.log').read_text(encoding='utf-8-sig')
    assert 'Passed!' in log and 'Failed!' not in log,tf
    log=(r/f'prepared-{tf}.log').read_text(encoding='utf-8-sig')
    assert 'Passed!' in log and 'Failed!' not in log,tf
for name,h in before['images']['before'].items():
    assert sha(r/'images/before'/name)==h,name
shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'images/candidate/Lokad.Lython.dll')
shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net10.0/Lokad.Lython.dll',r/'candidate-net10.dll')
changed=subprocess.check_output(['git','diff','--name-only','--','src/Lokad.Lython'],text=True,stderr=subprocess.DEVNULL).splitlines()
ids=dict(beforeRevision=before['runtimeRevision'],purpose=before['scope'],sourceHashes={p:sha(repo/p)for p in changed},
    allCoreSources={p.relative_to(repo).as_posix():sha(p)for p in(repo/'src/Lokad.Lython').rglob('*.cs')if not {'bin','obj'}&set(p.parts)},
    images={role:{p.name:sha(p)for p in(r/'images'/role).iterdir()if p.is_file()}for role in['before','candidate']},
    net10SHA256=sha(r/'candidate-net10.dll'))
for name,h in ids['images']['before'].items():
    if name!='Lokad.Lython.dll':assert ids['images']['candidate'][name]==h,name
(r/'diagnostic-identity.json').write_text(json.dumps(ids,indent=2)+'\n',encoding='utf-8')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython','tests'],stderr=subprocess.DEVNULL))
for name in ['measure.py','summarize.py']:
    shutil.copyfile(r.parent/'closure-operands-r235'/name,r/name)
print('R236 source pair frozen. Both actual targets build; baseline bits and common worker/adapter identity verified. Timing is diagnostic.')
