from pathlib import Path
for p in Path('src/Lokad.Lython/Runtime').rglob('*.cs'):
 s=p.read_text(encoding='utf-8');t=s.replace('Func<CallArgumentValue[],','Func<ReadOnlySpan<CallArgumentValue>,')
 if p.name=='LythonRuntime.Functools.Partial.cs':t=t.replace('arguments.AsSpan(1)','arguments[1..]')
 if p.name in ['LythonRuntime.Calls.cs','LythonRuntime.Builtins.ObjectAndBytes.cs']:
  t=t.replace('Array.Copy(arguments, 0, rest, 0, receiverIndex);','arguments[..receiverIndex].CopyTo(rest);').replace('Array.Copy(arguments, receiverIndex + 1, rest, receiverIndex, rest.Length - receiverIndex);','arguments[(receiverIndex + 1)..].CopyTo(rest.AsSpan(receiverIndex));')
 if p.name=='LythonRuntime.BuiltinIterables.Ordering.cs':t=t.replace('object keyArgument, global::Lokad.Lython.Runtime.OptionalValue<object> defaultValue','object? keyArgument, global::Lokad.Lython.Runtime.OptionalValue<object> defaultValue')
 if p.name=='PyDataclass.cs':t=t.replace('new ArraySegment<CallArgumentValue>(arguments, 1, arguments.Length - 1)','arguments[1..]')
 if p.name=='LythonRuntime.OperatorModule.cs':t=t.replace('new PyMethodCaller(name.AsString(), arguments[1..])','new PyMethodCaller(name.AsString(), arguments[1..].ToArray())')
 if t!=s:p.write_text(t,encoding='utf-8',newline='\n')
