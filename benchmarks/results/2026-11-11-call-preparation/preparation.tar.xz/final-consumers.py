exec(__import__('pathlib').Path(__file__).with_name('stage-edits.py').read_text(encoding='utf-8').split('# Owners transfer')[0])

def parameter(m):
    m=m.replace('async ValueTask<object> ConstructTypeParameterAsync(TypeParameterKind kind, CallArgumentValue[]','ValueTask<object> ConstructTypeParameterAsync(TypeParameterKind kind, ReadOnlySpan<CallArgumentValue>')
    m=m.replace('using var scratch =','var scratch =',1)
    point=m.index('        object? nameValue')
    m=m[:point]+'        try\n        {\n'+m[point:]
    m=m.replace('var covariant = false; var contravariant = false; var inferVariance = false;','object covariantValue = false, contravariantValue = false, inferVarianceValue = false;')
    for name in ['covariant','contravariant','inferVariance']:
        m=m.replace(f'{name} = asynchronous ? await IsTruthyAsync(argument.Value, context, span).ConfigureAwait(false) : IsTruthy(argument.Value, context, span);',f'{name}Value = argument.Value;')
    point=m.index('        if (nameValue is null')
    m=m[:point]+'''            return CreateTypeParameterAsync(kind, nameValue, bound, defaultValue, constraints,
                covariantValue, contravariantValue, inferVarianceValue, scratch, context, span, asynchronous);
        }
        catch { scratch.Dispose(); throw; }
    }

    private static async ValueTask<object> CreateTypeParameterAsync(TypeParameterKind kind, object? nameValue,
        object? bound, object? defaultValue, List<object> constraints, object covariantValue, object contravariantValue,
        object inferVarianceValue, MemoryGovernor.TemporaryMemoryReservation scratch,
        ExecutionContext context, LythonSourceSpan span, bool asynchronous)
    {
        using var owner = scratch;
        var covariant = asynchronous ? await IsTruthyAsync(covariantValue, context, span).ConfigureAwait(false) : IsTruthy(covariantValue, context, span);
        var contravariant = asynchronous ? await IsTruthyAsync(contravariantValue, context, span).ConfigureAwait(false) : IsTruthy(contravariantValue, context, span);
        var inferVariance = asynchronous ? await IsTruthyAsync(inferVarianceValue, context, span).ConfigureAwait(false) : IsTruthy(inferVarianceValue, context, span);
'''+m[point:]
    return m
transform('LythonRuntime.ModernTyping.cs','internal static async ValueTask<object> ConstructTypeParameterAsync(',parameter)

def update(m):
    return '''internal static ValueTask<object> UpdateDictionaryAsync(PyDict target,
        ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
    {
        var positionalCount = 0;
        var keywordCount = 0;
        object source = PyNone.Instance;
        foreach (var argument in arguments)
        {
            context.CheckExecution(span);
            if (argument.IsKeyword) { keywordCount++; continue; }
            if (positionalCount++ != 0)
                throw new LythonRuntimeException("TypeError", "dict.update expected at most 1 positional argument", span);
            source = argument.Value;
        }
        target.AttachMemoryGovernor(context.MemoryGovernor, span);
        var working = context.MemoryGovernor.ReserveTemporary(keywordCount == 0 ? 0 : checked(32L + 24L * keywordCount), span);
        try
        {
            var keywords = keywordCount == 0 ? Array.Empty<KeyValuePair<string, object>>() : new KeyValuePair<string, object>[keywordCount];
            var index = 0;
            foreach (var argument in arguments)
                if (argument.IsKeyword) keywords[index++] = new(argument.KeywordName, argument.Value);
            return CompleteDictionaryUpdateAsync(target, source, positionalCount != 0, keywords, working, span, context);
        }
        catch { working.Dispose(); throw; }
    }

    private static async ValueTask<object> CompleteDictionaryUpdateAsync(PyDict target, object source, bool hasSource,
        KeyValuePair<string, object>[] keywords, MemoryGovernor.TemporaryMemoryReservation working,
        LythonSourceSpan span, ExecutionContext context)
    {
        using var owner = working;
        if (hasSource) await UpdateDictionaryFromSourceAsync(target, source, context, span).ConfigureAwait(false);
        foreach (var keyword in keywords)
        {
            context.CheckExecution(span);
            target.SetItem(PyString.FromString(keyword.Key, context.MemoryGovernor, span), keyword.Value);
        }
        context.CheckExecution(span);
        return PyNone.Instance;
    }'''
transform('LythonRuntime.BuiltinObjects.cs','internal static async ValueTask<object> UpdateDictionaryAsync(',update)
change('PyCollections.cs','''public async ValueTask<object> UpdateFromAsync(CallArgumentValue[] arguments, LythonRuntime.ExecutionContext context, LythonSourceSpan span)
        => await LythonRuntime.UpdateDictionaryAsync(_items, arguments, span, context).ConfigureAwait(false);''','''public ValueTask<object> UpdateFromAsync(ReadOnlySpan<CallArgumentValue> arguments, LythonRuntime.ExecutionContext context, LythonSourceSpan span)
        => LythonRuntime.UpdateDictionaryAsync(_items, arguments, span, context);''')
change('LythonRuntime.Members.cs','async (arguments, span, context) => await UpdateDictionaryAsync(dict, arguments, span, context).ConfigureAwait(false)','(arguments, span, context) => UpdateDictionaryAsync(dict, arguments, span, context)')
change('LythonRuntime.Members.cs','async (arguments, span, context) => await dict.UpdateFromAsync(arguments, context, span).ConfigureAwait(false)','(arguments, span, context) => dict.UpdateFromAsync(arguments, context, span)')

p=root/'LythonRuntime.CopyModule.cs';s=p.read_text(encoding='utf-8')
start=s.index('private sealed class CopyReplaceCallable')
a=s.index('public object Invoke(',start)
_,b,_=method(s[a:],'private static async ValueTask<object> InvokeCoreAsync(');b+=a
s=s[:a]+'''public object Invoke(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        {
            using var scratch = ValidateArguments(arguments, span, context);
            var target = arguments[0].Value;
            var (cls, method) = ResolveReplaceMethodAsync(target, span, context, false).GetAwaiter().GetResult();
            return ReplaceAsync(target, cls, method, arguments, span, context, false).GetAwaiter().GetResult();
        }

        public async ValueTask<object> InvokeAsync(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            using var scratch = ValidateArguments(arguments, span, context);
            var target = arguments[0].Value;
            var (cls, method) = await ResolveReplaceMethodAsync(target, span, context, true).ConfigureAwait(false);
            return await ReplaceAsync(target, cls, method, arguments, span, context, true).ConfigureAwait(false);
        }

        private static MemoryGovernor.TemporaryMemoryReservation ValidateArguments(ReadOnlySpan<CallArgumentValue> arguments,
            LythonSourceSpan span, ExecutionContext context)
        {
            context.CheckExecution(span);
            if (arguments.Length == 0 || arguments[0].IsKeyword)
                throw RuntimeErrors.Type("copy.replace(obj, /, **changes) expects a positional object.", span);
            var scratch = context.MemoryGovernor.ReserveTemporary(checked(64L + 160L * arguments.Length), span);
            try
            {
                var seen = new HashSet<string>(StringComparer.Ordinal);
                for (var i = 1; i < arguments.Length; i++)
                {
                    context.CheckExecution(span);
                    if (arguments[i].IsPositional) throw RuntimeErrors.Type("copy.replace accepts only one positional argument.", span);
                    if (!seen.Add(arguments[i].KeywordName))
                        throw CallErrors.MultipleValues(PythonCallableKind.Builtin, "copy.replace", arguments[i].KeywordName, span);
                }
                return scratch;
            }
            catch { scratch.Dispose(); throw; }
        }

        private static async ValueTask<(object Class, ICallable? Method)> ResolveReplaceMethodAsync(object target,
            LythonSourceSpan span, ExecutionContext context, bool asynchronous)
        {
            var cls = asynchronous ? await TryResolveRuntimeMemberAsync(target, "__class__", context, span).ConfigureAwait(false)
                : TryResolveRuntimeMember(target, "__class__", context, span, out var type) ? (true, type) : (false, (object)PyNone.Instance);
            if (cls.Item1)
            {
                var method = cls.Item2 is PyType owner && owner.TryLookupInMro("__replace__", 0, out var raw, out _)
                    ? (true, asynchronous ? await PyAttributeLookup.BindForTypeAsync(owner, raw, context, span).ConfigureAwait(false)
                        : PyAttributeLookup.BindForType(owner, raw, context, span))
                    : asynchronous ? await TryResolveRuntimeMemberAsync(cls.Item2, "__replace__", context, span).ConfigureAwait(false)
                        : TryResolveRuntimeMember(cls.Item2, "__replace__", context, span, out var member) ? (true, member) : (false, (object)PyNone.Instance);
                if (method.Item1)
                    return (cls.Item2, method.Item2 as ICallable ?? throw RuntimeErrors.Type("__replace__ must be callable.", span));
            }
            return (cls.Item2, null);
        }

        private static ValueTask<object> ReplaceAsync(object target, object cls, ICallable? method,
            ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context, bool asynchronous)
        {
            if (method is not null)
                return asynchronous ? method.InvokeBorrowedAsync(arguments, span, context) : new(method.Invoke(arguments, span, context));
            if (target is PyInstance instance && ReferenceEquals(cls, instance.Type) && instance.Type.DataclassFields is not null)
                return asynchronous ? PyDataclass.ReplaceInstanceAsync(instance, arguments[1..], span, context, "copy.replace")
                    : new(PyDataclass.ReplaceInstance(instance, arguments[1..], span, context, "copy.replace"));
            if (target is PyNamedTupleObject && PyMemberAccess.TryResolve(target, "_replace", context, span, out var replace) && replace is ICallable native)
                return asynchronous ? native.InvokeBorrowedAsync(arguments[1..], span, context) : new(native.Invoke(arguments[1..], span, context));
            throw RuntimeErrors.Type("copy.replace expects a dataclass, namedtuple, or class with __replace__.", span);
        }'''+s[b:]
p.write_text(s,encoding='utf-8')

# Path construction keeps a borrowed synchronous loop and an owned pending loop;
# both feed the existing normalization and final storage functions.
p=root/'LythonRuntime.PathAndTextModules.cs';s=p.read_text(encoding='utf-8')
a,b,_=method(s,'private static async ValueTask<object> CreatePath(');m=s[a:b]
sync=m.replace('async ValueTask<object> CreatePath(CallArgumentValue[]','object CreatePath(ReadOnlySpan<CallArgumentValue>').replace('ExecutionContext context, bool asynchronous)','ExecutionContext context)')
sync=sync.replace('''var part = asynchronous
                        ? await CoercePathLikeAsync(arguments[i].Value, context, span, "pathlib.Path").ConfigureAwait(false)
                        : CoercePathLike(arguments[i].Value, context, span, "pathlib.Path");''','''var part = CoercePathLike(arguments[i].Value, context, span, "pathlib.Path");''')
pending=m.replace('CreatePath(CallArgumentValue[]','CreatePathAsync(CallArgumentValue[]').replace('ExecutionContext context, bool asynchronous)','ExecutionContext context)')
pending=pending.replace('''var part = asynchronous
                        ? await CoercePathLikeAsync(arguments[i].Value, context, span, "pathlib.Path").ConfigureAwait(false)
                        : CoercePathLike(arguments[i].Value, context, span, "pathlib.Path");''','''var part = await CoercePathLikeAsync(arguments[i].Value, context, span, "pathlib.Path").ConfigureAwait(false);''')
s=s[:a]+sync+'\n\n        '+pending+s[b:]
s=s.replace('''                => InvokeCore(arguments, span, context, false).GetAwaiter().GetResult();''','''            {
                CheckSupported(context, span);
                return CreatePath(arguments, ShortName.StartsWith("Pure", StringComparison.Ordinal), span, context);
            }''')
s=s.replace('''                => InvokeCore(arguments, span, context, true);''','''            {
                CheckSupported(context, span);
                return CreatePathAsync(arguments, ShortName.StartsWith("Pure", StringComparison.Ordinal), span, context);
            }''')
a,b,_=method(s,'private ValueTask<object> InvokeCore(')
s=s[:a]+'''private void CheckSupported(ExecutionContext context, LythonSourceSpan span)
            {
                context.CheckExecution(span);
                if (!_isSupported) throw new LythonRuntimeException("NotImplementedError", $"{Name} is not supported by Lython's normalized POSIX-like path model.", span);
            }'''+s[b:]
p.write_text(s,encoding='utf-8')
