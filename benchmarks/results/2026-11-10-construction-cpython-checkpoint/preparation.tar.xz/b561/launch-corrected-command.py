from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
config={'payloadBytes': 1919761, 'payloadSHA256': 'f97ecfca5f7f2305b578f3355f00a717ae0f0e13906a8f11d48ed09bfa413ffe', 'required': 270295040, 'coresToRetire': [{'knownPath': 'tuple-constructors-b560-20261110/candidate/Lokad.Lython.dll', 'bytes': 5665792, 'sha256': '67b28bba41c4f3afe1b10031b1d4fc306a668751089d0ff85f9644d4e379a495', 'canonical': 'benchmarks/results/2026-11-10-tuple-value-construction/constructor/observations.tgz:current-core.dll', 'archiveSHA256': 'de959157afb98fe7ae73fc45d9b8b6447d81ce441e8f2894be046d51160b031c'}, {'knownPath': 'tuple-constructors-b560-20261110/representative.json', 'bytes': 146691, 'sha256': 'cfe7a07ef706d74e7b12895ba2dd31f3b30c5e44cf01a39d869a310adee98c2c', 'canonical': 'benchmarks/results/2026-11-10-tuple-value-construction/constructor/observations.tgz:representative.json', 'archiveSHA256': 'de959157afb98fe7ae73fc45d9b8b6447d81ce441e8f2894be046d51160b031c'}, {'knownPath': 'tuple-constructors-b560-20261110/observations.tgz', 'bytes': 3812888, 'sha256': 'de959157afb98fe7ae73fc45d9b8b6447d81ce441e8f2894be046d51160b031c', 'canonical': 'benchmarks/results/2026-11-10-tuple-value-construction/constructor/observations.tgz', 'archiveSHA256': 'de959157afb98fe7ae73fc45d9b8b6447d81ce441e8f2894be046d51160b031c'}, {'knownPath': 'tuple-constructors-b560-20261110/confirmation/confirmation.json', 'bytes': 280925, 'sha256': 'af9c9a96846484e7deaa954ca4e16c9dec2238c27b8cdfa53e61a8f756b82f4e', 'canonical': 'benchmarks/results/2026-11-10-tuple-value-construction/constructor/observations.tgz:confirmation/confirmation.json', 'archiveSHA256': 'de959157afb98fe7ae73fc45d9b8b6447d81ce441e8f2894be046d51160b031c'}], 'expectedCores': {'candidate': '0e2bc55bac5ebfafd9d30014e34e2afb3e9776bbe6b5d83a53cc710c0d99c492', 'candidate-control': '0e2bc55bac5ebfafd9d30014e34e2afb3e9776bbe6b5d83a53cc710c0d99c492'}}
base=Path('/home/lokad/lython-bench-checks').resolve();root=base/'construction-cpython-b561-20261110';source=base/'lexical-loop-b558-20261110/candidate';fixture=root/'guest-fixtures'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists()and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[c]omplete-jobs.dll'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(config['payloadBytes']+1);assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:
  for name,role in [('current-core.dll','candidate')]:
   assert hashlib.sha256(a.extractfile(name).read()).hexdigest()==config['expectedCores'][role]
 assert hashlib.sha256((source/'Lokad.Lython.dll').read_bytes()).hexdigest()=='dbe94d4dfdcdc8f86de537ad904ee789664d749f60282713d7ac30c0d0467334'
 stable=base/'transient-split-b555-20261110/candidate/Lokad.Lython.dll'
 assert hashlib.sha256(stable.read_bytes()).hexdigest()=='101ba9d3e5237b8d0da09689a94abf9b7dbbe276634becedac61e859e84ac897'
 protocol=base/'prepared-call-layout-b384-20261107/cpython-worker.py'
 assert hashlib.sha256(protocol.read_bytes()).hexdigest()=='02ca606af6b937a5bec8da744da36e6dbea45ef14ee7207732f34da052ad32f1'
 before=shutil.disk_usage(base).free;retired=[];reclaim=0
 if before<=config['required']:
  for proof in config['coresToRetire']:
   firstPath=base/proof['knownPath'];first=firstPath.lstat();key=(first.st_dev,first.st_ino)
   assert first.st_size==proof['bytes']and hashlib.sha256(firstPath.read_bytes()).hexdigest()==proof['sha256']
   aliases=[]
   for folder,dirs,files in os.walk(base):
    for name in files:
     path=Path(folder)/name;st=path.lstat()
     if(st.st_dev,st.st_ino)!=key:continue
     assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(st.st_mode)and st.st_uid==os.getuid()
     aliases.append(path.relative_to(base).as_posix())
   assert len(aliases)==first.st_nlink and aliases and proof['knownPath']in aliases
   assert proof['sha256']not in['dbe94d4dfdcdc8f86de537ad904ee789664d749f60282713d7ac30c0d0467334','101ba9d3e5237b8d0da09689a94abf9b7dbbe276634becedac61e859e84ac897']
   reclaim+=first.st_blocks*512;retired.append(dict(proof,paths=aliases,allocatedBytes=first.st_blocks*512,allHardlinkAliasesVerified=True))
  assert before+reclaim>config['required'],(before,reclaim,config['required'])
  for proof in retired:
   for path in proof['paths']:(base/path).unlink()
 assert hashlib.sha256(stable.read_bytes()).hexdigest()=='101ba9d3e5237b8d0da09689a94abf9b7dbbe276634becedac61e859e84ac897'
 assert hashlib.sha256((source/'Lokad.Lython.dll').read_bytes()).hexdigest()=='dbe94d4dfdcdc8f86de537ad904ee789664d749f60282713d7ac30c0d0467334'
 assert shutil.disk_usage(base).free>config['required']
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:root.mkdir();a.extractall(root,filter='data')
 recovery=dict(beforeFreeBytes=before,afterRecoveryFreeBytes=shutil.disk_usage(base).free,requiredFreeBytes=config['required'],freshIdleLease=True,verifiedReplacementInPayload=True,files=retired,osFloorMiB=240,evidenceHeadroomMiB=12,qualified101AndBeforeDbePreserved=True)
 (root/'space-recovery.json').write_text(json.dumps(recovery,indent=2)+'\n')
 shutil.copyfile(protocol,root/'cpython-worker.py')
 for role in ['candidate']:
  shutil.copytree(source,root/role,copy_function=os.link)
  (root/role/'Lokad.Lython.dll').unlink();os.link(root/('baseline-core.dll'if role=='reference'else'current-core.dll'),root/role/'Lokad.Lython.dll')
 identity=json.loads((root/'identity.json').read_text())
 for role in ['candidate']:
  for name,digest in{**identity['auxiliaryFiles'],'Lokad.Lython.dll':identity['coreSHA256'][role]}.items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==digest,(role,name)
 assert hashlib.sha256((root/'representative.json').read_bytes()).hexdigest()==identity['catalogSHA256']
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b561-fixtures',str(fixture)],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,imagesVerified=True,jobs=6,ownerSeconds=210,stopSeconds=30,marginSeconds=30,osFloorMiB=240,evidenceHeadroomMiB=12)
 assert setup['freeBytes']>252*1024*1024
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
try:
 subprocess.run(['sudo','-n','systemd-run','--unit=lython-b561-construction-cpython-20261110','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=210','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show','lython-b561-construction-cpython-20261110.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert'ActiveState=active'in live and'MainPID=0'not in live;print(live,flush=True)
