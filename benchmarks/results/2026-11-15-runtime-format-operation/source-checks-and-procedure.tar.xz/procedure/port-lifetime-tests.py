from pathlib import Path
p=Path('tests/Lokad.Lython.PublicApi.Tests/FormatSinkTests.cs');s=p.read_text(encoding='utf-8');a=s.index('        const long limit');b=s.index('        var expression',a);setup=s[a:b];c=s.index('        using (var script',b);source=s[b:c];end=s.index('\n    private sealed class HeldTiming',c);body=s[c:end]
source=source.replace("{'value':Field()}","{'value':value}").replace('.format(Field())','.format(value)')
source=source.replace('"\\ntry:\\n result=" + expression + "\\nexcept', '"\\ndef render(value):return " + expression + "\\nrender(\'warm\')\\ntry:\\n result=render(Field())\\nexcept')
assert "render('warm')" in source and 'result=render(Field())' in source
body=body.replace('"begin|" + payload + ">9|end"','"begin|" + payload + suffix + "|end"')
s=s[:a]+source+'''        await AssertHeldOperation(source, outcome, ">9");
    }

    [Theory]
    [InlineData(false, "success")]
    [InlineData(true, "success")]
    [InlineData(false, "cancel")]
    [InlineData(true, "cancel")]
    [InlineData(false, "refuse")]
    [InlineData(true, "refuse")]
    public async Task PendingMappingOrSuffixLookupKeepsItsOwnerUntilCleanup(bool attribute, string outcome)
    {
        const string setup = """
            import time
            def read_value():
             with open('data.txt') as stream:
              value=stream.read()
              time.sleep(0)
              return value+'!'
            class Mapping:
             def __getitem__(self,key):return read_value()
            class Warm:value='warm'
            class Source:
             @property
             def value(self):return read_value()
            """;
        var selection = attribute
            ? "render='begin|{0.value}|end'.format\\nrender(Warm())\\ntarget=Source()"
            : "render='begin|{value}|end'.format_map\\nrender({'value':'warm'})\\ntarget=Mapping()";
        var source = setup + "\\n" + selection + "\\ntry:\\n result=render(target)\\nexcept BaseException:print('caught')\\nprint('done')\\nreturn result";
        await AssertHeldOperation(source, outcome, "!");
    }

    private static async Task AssertHeldOperation(string source, string outcome, string suffix)
    {
'''+setup+body+s[end:];p.write_text(s,encoding='utf-8',newline='\n')
print('All6held-field assertions retained with warmed methods;6real mapping/suffix lookup lifetime cases added.')
