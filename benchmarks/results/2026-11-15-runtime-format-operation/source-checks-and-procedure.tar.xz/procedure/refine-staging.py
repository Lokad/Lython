from pathlib import Path
import shutil
r=Path(__file__).parent;q=r/'quiet';d=q/'initial-stage-refusal';d.mkdir()
for n in ['config.json','remote-launch.py','launch.log','payload.tgz']:shutil.copyfile(q/n,d/n)
p=r/'launch-vm.py';s=p.read_text(encoding='utf-8');a=s.index('with tarfile.open(q/')
s=s[:a]+'''canonical='benchmarks/results/2026-11-15-helper-boundary-decomposition/observations.tgz';raw=(repo/canonical).read_bytes();assert subprocess.check_output(['git','show',head+':'+canonical])==raw
groups.append(dict(paths=['helper-boundaries-b801-20261115/observations.tgz'],bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),links=1,optional=True,custody=dict(commit=head,archive=canonical,archiveSHA256=hashlib.sha256(raw).hexdigest(),member=None)))
'''+s[a:]
# Reuse the prepared protocol files; retain the refused stage's payload/log intact.
s=s.replace("q=r/'quiet';q.mkdir();","q=r/'quiet';assert q.is_dir();")
p.write_text(s,encoding='utf-8',newline='\n')
