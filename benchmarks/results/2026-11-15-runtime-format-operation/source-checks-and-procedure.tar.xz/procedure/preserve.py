from pathlib import Path
import json,shutil,tarfile,xml.etree.ElementTree as E
r=Path(__file__).parent;q=r/'quiet';out=Path('benchmarks/results/2026-11-15-runtime-format-operation');out.mkdir();ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
for source,name in [(r/'summary.json','summary.json'),(r/'allocation-summary.json','allocation-summary.json'),(r/'cpython-goldens.json','cpython-goldens.json'),(r/'frozen/identity.json','identity.json'),(q/'observations.tgz','observations.tgz'),(q/'archive-receipt.json','archive-receipt.json'),(q/'terminal-status.json','terminal-status.json')]:shutil.copyfile(source,out/name)
checks={}
with tarfile.open(out/'source-checks-and-procedure.tar.xz','w:xz') as a:
 for n in ['sources-and-checks.tar.xz','reference/Lokad.Lython.dll','candidate/Lokad.Lython.dll']:a.add(r/'frozen'/n,arcname='frozen/'+n)
 for p in r.iterdir():
  if p.is_file() and p.name!='catalog.json':a.add(p,arcname='procedure/'+p.name)
 for p in q.iterdir():
  if p.is_file() and p.name not in ['observations.tgz','payload.tgz']:a.add(p,arcname='quiet/'+p.name)
 a.add(q/'initial-stage-refusal',arcname='initial-stage-refusal')
 for p in (r/'allocation').iterdir():
  if p.is_file():a.add(p,arcname='allocation/'+p.name)
 for p in (r/'allocation/bin/Release/net11.0').glob('ValidatedAllocation.*'):a.add(p,arcname='allocation/driver/'+p.name)
 for p in (r/'checks').iterdir():
  if p.is_file():
   a.add(p,arcname='checks/'+p.name)
   if p.suffix=='.trx':checks[p.name]=E.parse(p).find('.//t:Counters',ns).attrib
 a.add(r/'original',arcname='original')
(out/'checks.json').write_text(json.dumps(dict(checks=checks,cleanNonincrementalReleaseSolutionBuildEachActualFramework=True,independentCPythonSemanticPorts=3,allVMOutputAndFileGoldensPassed=True,allocationBudgetReuseAndCleanupPassed=True,publicApiChange=False,publicationHeld=True),indent=2)+'\n',encoding='utf-8',newline='\n')
p=out/'summary.json';v=json.loads(p.read_text(encoding='utf-8'));v.update(retentionDecisionPending=False,retained=True,fullQualificationPending=True,reason='Complete runtime format operation deletes callback executor/captures/fallback/duplicate field names and native per-field async wrapper;9.41%less allocation and modest whole-report elapsed/CPU support. Small adverse controls remain explicit. Not completion of larger call/frame/frontend roadmap.');p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# One runtime method-format operation

R419, retained**0393331a** versus committed**58eeea6f / frozen9d071eba**.
The complete1,024record/189,441B JSON-to-Markdown method-format report keeps
the original stdout/file goldens. Baseline full43771040409 is still active at capture;
its ordinary11/10/package checks pass both platforms and Ubuntu stress passes.
This does not claim final delivery of either changed source.

Exactly two production callers used the generic PyStringOps.FormatAsync executor.
One runtime operation now executes the prepared layout through existing lookup/
format kernels. Deletes that executor/file, callback/delegate captures, nullable
callback rendering fallback, redundant full-name field metadata and the native
per-field async bridge. Pure layout preparation, native spec/index helpers and
the real regex-escape caller remain. Actual root/suffix/format protocols are awaited
with the active token; builtin fields append synchronously. No second formatter,
controller, backend, policy, new ownership scheme or new dependency.

Arguments still preflight/copy and stay funded through completion. Layouts retain
the existing conservative execution/result owner, dynamic nested specs retain their
operation reservation and guest-retained spec aliases remain independently funded.
First refusal remains terminal; no retry, background work, GC or heap tracing.
Native promotion/general call packets remain explicit debt, not silently solved.

**Complete report allocation−9.41%**,5,744,806→5,204,028B/invocation. F-string control
flat(−34B). Same strengthened natural-GC driver checks stdout/files/budget baseline
after cleanup; compilation/startup excluded. Separate collections' byte counts are
not treated as exact constants. No allocation-derived CPU claim.

**B814succeeds140.958s**. Warm elapsed**1.86–4.21%lower**,CPU1.27–3.85%lower;
compile-to-result elapsed**1.10–4.24%lower**,CPU1.70–3.74%lower. Ref/candidate control
spreads warm1.62/0.83%,fresh1.92/1.33%. F-string elapsed−1.73..+0.39%,CPU−2.33..+0.60%,
controls0.85/1.30%;CSVelapsed−0.90..+0.47%,CPU−1.92..0.00%,controls0.11/1.26%.
These modest results support retention with coherent deletion and allocation savings;
moving/adverse pairings stay visible. No universal gain, zero regression or unchanged
retiming claim. This does not complete the broader performance objective.

Focused**6internal/691public each actual.NET11/10** pass after clean nonincremental
Release solution builds. Four callback-wiring tests removed; their useful conversion/
numbering/structural assertions become three public CPython-verified programs, including
escaping4096scalar expanded-spec aliases. Two callback-only lifetime tests removed;
six original held-field cases remain with warmed layouts and six genuine held mapping/
property cases now cover success, in-flight cancellation, terminal refusal, active-token
forwarding, retained storage, joined file cleanup and allowance baseline reuse.
The regex-escape golden and layout owner/refusal assertions remain.595source/build/
changed-test inputs frozen; deleted source/test paths recorded separately.

Quiet F4as_v7/Ubuntu24.04.4,4EPYC9V45vCPUs,16GiB/no swap,.NET11RC3 normal tiering/
workstationGC. Two processes/source,5s full-request warmup/five rotated~0.5s batches.
Warm includesRun/mediatedRAM I/O/goldens/prior-result cleanup; excludes compilation/
startup/reset/protocol/finalcache teardown. Fresh includes compile/compiled-owner
disposal; widerCPU includesreset/protocol. No standalone compile, pending-I/O,RSS or
embedding-tail comparison. No CPython refresh for this modest source change; the
[preceding checkpoint](../2026-11-15-layout-cpython-checkpoint/README.md) retains its
actual58eeea6f/9d071eba revision rather than being relabeled current HEAD.

Every identity/golden/budget/quiet/Closed/exit/join/archive gate passes; persistent
evidence hash-verifies under lease, no users/RAM remain, terminal cached forever.
The original pre-worker stage refusal missed disk headroom by~9KB; no job/data was
started/deleted there. Bounded correction retires one additional exact archived
working response. Historical55ba core's5aliases and committed B813/B801response replicas
are verified by fresh UID/path/hash/link/all-alias proofs before retirement. Canonical
evidence/current0393/9d/8afbimages remain;254/252MiB floors unchanged.

**Full delivery pending; publication held.** [Medians/controls](summary.json),
[allocation](allocation-summary.json),[source/image identity](identity.json),
[checks](checks.json),[raw](observations.tgz),
[source/original tests/procedures/failed staging](source-checks-and-procedure.tar.xz).
''',encoding='utf-8',newline='\n')
p=Path('docs/BENCHMARKS.md');s=p.read_text(encoding='utf-8');needle='| Reused method-format layout / complete report |';a=s.index(needle);s=s[:a]+'| One runtime format operation / complete report | Warm elapsed1.9–4.2%lower; compile-to-result1.1–4.2%lower, supporting CPU | −9.41% | Retained0393331a/9d071eba; callback executor/captures/private fallback removed. Moving controls/CSVup to0.5%slower retained. [Source pair/limits](../benchmarks/results/2026-11-15-runtime-format-operation/README.md); full delivery pending. |\n'+s[a:];p.write_text(s,encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');s+='\n\n[R419one runtime format operation](results/2026-11-15-runtime-format-operation/README.md), retained0393331a/9d071eba. Deletes generic callback executor/captures/fallback/duplicate names/native async field bridge; real protocol work/current tokens/funding preserved.6internal/691public each actual11/10 pass,3CPython semantic ports,6new held lookup cases. Allocation−9.41%,warm1.9–4.2%/fresh1.1–4.2%lower elapsed with CPU support; controls/adversity remain. B814all gates/cleanup; original pre-worker headroom refusal preserved. Full delivery pending; publication held/broader roadmap active.\n';p.write_text(s,encoding='utf-8',newline='\n')
print('R419coherent deletion/source/controls/semantic ports/funding and original staging preserved; full delivery pending.')
