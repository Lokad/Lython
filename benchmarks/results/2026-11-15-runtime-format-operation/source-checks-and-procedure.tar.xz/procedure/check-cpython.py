from pathlib import Path
import json,re,subprocess,textwrap
r=Path(__file__).parent;source=Path('tests/Lokad.Lython.PublicApi.Tests/FormatOperationTests.cs').read_text(encoding='utf-8');sources=re.findall(r'"""\n(.*?)\n\s*"""',source,re.S);assert len(sources)==3;rows=[]
for i,s in enumerate(sources):
 code='def check():\n'+textwrap.indent(textwrap.dedent(s),'    ')+"\nassert check()=='ok'\n"
 p=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',code],capture_output=True,timeout=10);rows.append(dict(case=i,source=code,exitCode=p.returncode,stderr=p.stderr.decode('utf-8')));assert p.returncode==0,rows[-1]
(r/'cpython-goldens.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n');print('All3public semantic ports independently pass CPython3.13.2.')
