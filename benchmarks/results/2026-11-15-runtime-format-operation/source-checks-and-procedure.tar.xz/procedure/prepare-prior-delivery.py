from pathlib import Path
r=Path(__file__).parent.parent;src=r/'format-sinks-r416/save-delivery.py';s=src.read_text(encoding='utf-8')
s=s.replace('[4781,17882,13,406]','[4783,17885,13,406]').replace("proof['inputCount']==594 and len(proof['inputs'])==594","proof['inputCount']==593 and len(proof['inputs'])==593").replace("proof['productionInputs']==585 and proof['additionalBuildInputs']==4 and proof['changedTestInputs']==5","proof['productionInputs']==586 and proof['additionalBuildInputs']==4 and proof['changedTestInputs']==3")
s=s.replace('2026-11-15-formatting-final-sink','2026-11-15-method-format-layout').replace('2026-11-15-format-cpython-checkpoint','2026-11-15-layout-cpython-checkpoint')
a=s.index("(out/'README.md').write_text(");b=s.index("q=out.parent/'summary.json'",a)
s=s[:a]+'''(out/'README.md').write_text("""# Method-format layout delivery

**58eeea6f / measured9d071eba** passes
[43771040409](https://github.com/Lokad/Lython/actions/runs/43771040409).
Windows/Ubuntu actual.NET11/10 each pass4,783internal/17,885public ordinary,
original13internal/406public stress and installed Release package consumers.
All16summaries/full logs terminal-cached; never query this run again.
All593frozen inputs (586production,4build,3changed tests) match committed source
after explicit UTF8 newline normalization; rebuilt byte identity is not inferred.

Qualifies one execution-owned bound-method template/field/native-spec layout,
deletion of repeated async parsing/metadata construction, deferred errors/effects,
Unicode/type/custom native-invalid specs, nested widths, current tokens, actual
hosted callbacks, terminal refusal, retained ownership and joined cleanup.
Conservative layout capacity remains charged until execution/result cleanup;
many one-use methods can reject earlier. No new dependency, public API or policy.

[Controlled source pair and debt](../README.md) establishes18.47%less report
allocation and17–20%lower warm/fresh elapsed with CPU support. Moving f-string
and adverse CSV controls remain. [CPython phases](../../2026-11-15-layout-cpython-checkpoint/README.md)
show remaining warm1.66–1.68×gap. Qualification does not prove a speedup.
The broader operation/call/transport/frontend and independent regex roadmap
remains active. Publication held.
""",encoding='utf-8',newline='\\n')
'''+s[b:]
s=s.replace("s+='\\n[Full platform/stress/package qualification passes](delivery/README.md).\\n'","s=s.replace('R418, retained prototype**9d071eba**','R418, committed**58eeea6f / frozen9d071eba**').replace('**Full platform/stress/package delivery pending; publication held.**','[Full platform/stress/package delivery passes](delivery/README.md); publication held.')")
s=s.replace(".replace('full delivery qualification pending.','[Full delivery passes](../benchmarks/results/2026-11-15-method-format-layout/delivery/README.md).')",".replace('full delivery pending.','[Full delivery passes](../benchmarks/results/2026-11-15-method-format-layout/delivery/README.md).')")
a=s.index("q=repo/'benchmarks/EXPERIMENTS.md'");s=s[:a]+'''q=repo/'benchmarks/EXPERIMENTS.md';s=q.read_text(encoding='utf-8');s+='\\n\\n[R418full delivery43771040409](results/2026-11-15-method-format-layout/delivery/README.md) qualifies58eeea6f/9d071eba on Windows/Ubuntu actual11/10:4,783internal/17,885public ordinary, original13/406stress and installed Release consumers each.16summaries/593source inputs verified. Terminal cached forever. Publication held; broader performance work continues.\\n';q.write_text(s,encoding='utf-8',newline='\\n')
print('GREEN:16summaries,593inputs,actual11/10,Windows/Ubuntu,stress,installed Release consumers verified.')
'''
(r/'format-layout-r418/save-delivery.py').write_text(s,encoding='utf-8',newline='\n')
print('Prior delivery archiver ready; execute only after cached terminal success.')
