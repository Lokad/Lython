from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;f=r/'frozen';f.mkdir();base=r.parent/'format-layout-r418/frozen/candidate';images={};sources={}
for role in ['reference','candidate']:
 d=f/role;shutil.copytree(base,d)
 if role=='candidate':shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',d/'Lokad.Lython.dll')
 images[role]={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in d.iterdir() if p.is_file()}
assert images['reference']['Lokad.Lython.dll']=='9d071eba52291e91d609b6887195485c3e92d7e84538f8513cbe2dbd548cdbd2'
assert all(images['candidate'][n]==h for n,h in images['reference'].items() if n!='Lokad.Lython.dll')
paths=[n for n in subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True).splitlines() if Path(n).exists()]
paths+=['src/Lokad.Lython/Runtime/LythonRuntime.StringMembers.Formatting.cs','Directory.Build.props','Directory.Packages.props','NuGet.Config','global.json','tests/Lokad.Lython.Tests/FormatStorageTests.cs','tests/Lokad.Lython.Tests/PyStringOpsPrimitiveTests.cs','tests/Lokad.Lython.PublicApi.Tests/FormatSinkTests.cs','tests/Lokad.Lython.PublicApi.Tests/FormatTemplateTests.cs','tests/Lokad.Lython.PublicApi.Tests/FormatOperationTests.cs']
with tarfile.open(f/'sources-and-checks.tar.xz','w:xz') as a:
 for n in sorted(set(paths)):
  p=Path(n);sources[n]=hashlib.sha256(p.read_bytes()).hexdigest();a.add(p,arcname=n)
 for p in (r/'checks').iterdir():
  if p.is_file():a.add(p,arcname='checks/'+p.name)
identity=dict(baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),prototype=True,images=images,sources=sources,deletedInputs=['src/Lokad.Lython/Runtime/Text/PyStringOps.Formatting.cs','tests/Lokad.Lython.Tests/StringFormatPrimitiveTests.cs'],contracts='Runtime executes prepared method layout directly, no generic callback executor, nullable callbacks, private rendering fallback, full-name metadata or per-field async bridge for native values. Existing lookup/format kernels/current token/admission/awaited cleanup; arrays/native promotion remain. Semantic ports and actual held mapping/property users replace architecture-only tests.')
(f/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
d=r/'allocation';d.mkdir();shutil.copyfile(r.parent/'format-layout-r418/allocation/catalog.json',d/'catalog.json')
for p in (r.parent/'format-layout-r418/allocation/bin/Release/net11.0').glob('ValidatedAllocation.*'):
 dst=d/'bin/Release/net11.0'/p.name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst)
s=(r.parent/'format-layout-r418/measure-allocation.py').read_text(encoding='utf-8');(r/'measure-allocation.py').write_text(s,encoding='utf-8',newline='\n')
print(dict(core={role:v['Lokad.Lython.dll'] for role,v in images.items()},inputs=len(sources),productionInputs=sum(n.startswith('src/') for n in sources)))
