from pathlib import Path
import json,shutil,subprocess
r=Path(__file__).parent;old=Path('src/Lokad.Lython/Runtime/Text/PyStringOps.Formatting.cs');text=old.read_text(encoding='utf-8')
paths=['src/Lokad.Lython/Runtime/Text/PyStringOps.Formatting.cs','src/Lokad.Lython/Runtime/Text/PyStringOps.FormatTemplate.cs','src/Lokad.Lython/Runtime/LythonRuntime.StringMembers.AffixFormat.cs','src/Lokad.Lython/Runtime/LythonRuntime.Operations.Formatting.cs','tests/Lokad.Lython.Tests/FormatStorageTests.cs','tests/Lokad.Lython.Tests/StringFormatPrimitiveTests.cs','tests/Lokad.Lython.Tests/PyStringOpsPrimitiveTests.cs','tests/Lokad.Lython.PublicApi.Tests/FormatSinkTests.cs']
for n in paths:
 p=r/'original'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(n,p)
(r/'baseline.json').write_text(json.dumps(dict(commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),runtimeCommit='58eeea6f31f259ce173c2a0a415cc7bf98716e58',coreSHA256='9d071eba52291e91d609b6887195485c3e92d7e84538f8513cbe2dbd548cdbd2',prototype=True),indent=2)+'\n',encoding='utf-8',newline='\n')
# Keep actual pure helpers; remove the generic callback executor completely.
a=text.index('    private static bool IsFormatFieldDelimiter');b=text.index('    public static PyString EscapeRegex',a)
helpers=text[a:b]
p=Path('src/Lokad.Lython/Runtime/Text/PyStringOps.FormatTemplate.cs');s=p.read_text(encoding='utf-8');s=s.replace('using System.Text;','using System.Text;\nusing System.Globalization;');s=s.replace('string Root, string Suffix, string Name, Rune? Conversion','string Root, string Suffix, Rune? Conversion');s=s.replace('return new(root, suffix, Encoding.UTF8.GetString(fieldBytes.Span[..fieldNameEnd]),\n            conversion, spec, nested, recursive, prepared);','return new(root, suffix, conversion, spec, nested, recursive, prepared);');i=s.rfind('\n}');s=s[:i]+'\n'+helpers+s[i:];p.write_text(s,encoding='utf-8',newline='\n')
escape=text[b:text.rfind('\n}')];p=Path('src/Lokad.Lython/Runtime/Text/PyStringOps.cs');s=p.read_text(encoding='utf-8');i=s.rfind('\n}');s=s[:i]+'\n'+escape+s[i:];p.write_text(s,encoding='utf-8',newline='\n');old.unlink()
# Wrappers retain preflighted argument ownership, without callback captures.
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.StringMembers.AffixFormat.cs');s=p.read_text(encoding='utf-8');a=s.index('            try\n',s.index('private static async ValueTask<object> FormatStringAsync'));b=s.index('        private sealed class StringTranslateMemberProvider',a)
setup=s[a:b];a0=setup.index('                var positionalCount');b0=setup.index('                return await PyStringOps.FormatAsync')
body=setup[a0:b0]
body='\n'.join(line[4:] if line.startswith('    ') else line for line in body.split('\n'))
s=s[:a]+body+'''            return await new MethodFormatOperation(positional, keywords, null, span, context,
                asynchronous, text.ByteLength).RunAsync(text, prepared).ConfigureAwait(false);
        }

        private static ValueTask<object> FormatMappingAsync(PyString text, object mapping,
            LythonSourceSpan span, ExecutionContext context, bool asynchronous, PyStringOps.FormatTemplate prepared)
            => new MethodFormatOperation([], null, mapping, span, context, asynchronous, text.ByteLength)
                .RunAsync(text, prepared);

'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
# The runtime operation calls the shared synchronous formatter for ordinary values
# and awaits the existing instance protocol only when it is actually needed.
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Operations.Formatting.cs');s=p.read_text(encoding='utf-8');a=s.index('    private static async ValueTask AppendInterpolatedStringPartAsync(');b=s.index('    private static PyString FormatValue(',a);s=s[:a]+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
print('Removed callback executor, duplicate name metadata and per-field async bridge; runtime operation follows.')
