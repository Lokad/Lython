from pathlib import Path
import ast,json,shutil
r=Path(__file__).parent;old=r.parent/'format-layout-r418';shutil.copyfile(old/'catalog.json',r/'catalog.json')
s=(old/'launch-vm.py').read_text(encoding='utf-8')
s=s.replace('format-layout-b812-20261115','format-operation-b814-20261115').replace('lython-b812-format-layout-20261115','lython-b814-format-operation-20261115').replace('B812','B814')
core=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))['images']['candidate']['Lokad.Lython.dll']
s=s.replace('R418 uncommitted9d071eba versus qualifiedb06b8593/frozen8afb146e','R419 uncommitted'+core[:8]+' versus committed58eeea6f/frozen9d071eba')
s=s.replace('Execution-owned reusable method-format template/field/native-spec layout; complete report warm/fresh plus unchanged f-string/CSV controls. Semantic/async/ownership checks separate.','One runtime format operation replaces generic callback executor, nullable primitive fallback and native per-field async bridge; complete method report warm/fresh plus f-string/CSV controls. Semantics/real async ownership checked separately.')
s=s.replace("source='/home/lokad/lython-bench-checks/format-sinks-b809-20261115'","source='/home/lokad/lython-bench-checks/format-layout-b812-20261115'")
a=s.index("canonical='benchmarks/results/2026-11-15-method-format-attribution/observations.tgz'");b=s.index('with tarfile.open(q/',a)
s=s[:a]+'''canonical='benchmarks/results/2026-11-15-layout-cpython-checkpoint/observations.tgz';raw=(repo/canonical).read_bytes();assert subprocess.check_output(['git','show',head+':'+canonical])==raw
with tarfile.open(fileobj=io.BytesIO(raw)) as t:response=t.extractfile('confirmation/confirmation.json').read()
for path,data,member in [('layout-cpython-b813-20261115/observations.tgz',raw,None),('layout-cpython-b813-20261115/confirmation/confirmation.json',response,'confirmation/confirmation.json')]:
 groups.append(dict(paths=[path],bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),links=1,optional=True,custody=dict(commit=head,archive=canonical,archiveSHA256=hashlib.sha256(raw).hexdigest(),member=member)))
'''+s[b:]
ast.parse(s);(r/'launch-vm.py').write_text(s,encoding='utf-8',newline='\n')
(r/'summarize.py').write_text((old/'summarize.py').read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
print('Prepared same complete report warm/fresh/f-string/CSV pair; original image/catalog gates and254/252MiB floors preserved.')
