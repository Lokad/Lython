from pathlib import Path
import json,os,subprocess,time
r=Path(__file__).parent;d=r/'checks';sdk='C:/Users/JoannesVermorel/.dotnet11';env=dict(os.environ);env.update(DOTNET_ROOT=sdk,DOTNET_ROOT_X64=sdk,PATH=sdk+';'+env['PATH'])
for tfm in ['net11.0','net10.0']:
 jobs=[('build',[sdk+'/dotnet.exe','build','Lokad.Lython.slnx','-c','Release','-f',tfm,'--no-incremental','--no-restore','-v','quiet'])]
 for suite,filt in [('Lokad.Lython.Tests','FullyQualifiedName~FormatStorageTests|FullyQualifiedName~PyStringOpsPrimitiveTests'),('Lokad.Lython.PublicApi.Tests','FullyQualifiedName~Format|FullyQualifiedName~NativeFormat|FullyQualifiedName~GovernedMemory')]:
  jobs.append((suite,[sdk+'/dotnet.exe','test','tests/'+suite+'/'+suite+'.csproj','-c','Release','-f',tfm,'--no-build','--filter','Category!=Stress&('+filt+')','--logger','trx;LogFileName=r419-final-'+suite+'-'+tfm+'.trx','--results-directory',str(d)]))
 for name,command in jobs:
  log=d/('final-'+name+'-'+tfm+'.log');assert not log.exists()
  with log.open('w',encoding='utf-8') as f:p=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT,env=env,timeout=180)
  print(name,tfm,p.returncode,flush=True);assert p.returncode==0,log.read_text(encoding='utf-8')[-2500:]
