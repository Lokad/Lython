; Assembly listing for method Lokad.Lython.LythonCompiledScript:RunCore(Lokad.Lython.ILythonHost,Lokad.Lython.LythonRunOptions):Lokad.Lython.LythonExecutionResult:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 192
       lea      rbp, [rsp+0xC0]
       xor      eax, eax
       mov      qword ptr [rbp-0xB8], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqu32 zmmword ptr [rbp-0xB0], zmm8
       vmovdqu32 zmmword ptr [rbp-0x70], zmm8
       vmovdqa  xmmword ptr [rbp-0x30], xmm8
       mov      qword ptr [rbp-0x20], rax
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      gword ptr [rbp-0x18], rdx
 
G_M000_IG02:                ;; offset=0x0047
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x58], rax
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x60], rax
       cmp      gword ptr [rbp-0x58], 0
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0062
       mov      rdi, 0x7828EFC76F18
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xA8], rax
       mov      rdi, gword ptr [rbp-0xA8]
       mov      rsi, 0x7828EC258838
       call     [System.ObjectDisposedException:.ctor(System.String):this]
       mov      rdi, gword ptr [rbp-0xA8]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG04:                ;; offset=0x009C
       mov      rax, gword ptr [rbp-0x60]
       mov      gword ptr [rbp-0x20], rax
       cmp      gword ptr [rbp-0x18], 0
       jne      SHORT G_M000_IG05
       mov      rdi, 0x7828EFDD6A60
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xA0], rax
       mov      rdi, gword ptr [rbp-0xA0]
       call     [Lokad.Lython.LythonRunOptions:.ctor():this]
       mov      rax, gword ptr [rbp-0xA0]
       mov      gword ptr [rbp-0x18], rax
 
G_M000_IG05:                ;; offset=0x00D9
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonRunOptions:get_MemoryBudget():Lokad.Lython.ILythonMemoryBudget:this]
       mov      gword ptr [rbp-0x68], rax
       mov      rax, gword ptr [rbp-0x68]
       mov      gword ptr [rbp-0x70], rax
       cmp      gword ptr [rbp-0x68], 0
       jne      SHORT G_M000_IG06
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x20]
       mov      gword ptr [rbp-0x90], rax
       mov      rax, gword ptr [rbp-0x90]
       mov      gword ptr [rbp-0x70], rax
       cmp      gword ptr [rbp-0x90], 0
       jne      SHORT G_M000_IG06
       vxorps   xmm0, xmm0, xmm0
       vmovups  xmmword ptr [rbp-0x48], xmm0
       mov      rdi, 0x7828EFD16738
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x98], rax
       mov      rsi, qword ptr [rbp-0x48]
       mov      rdx, qword ptr [rbp-0x40]
       mov      rdi, gword ptr [rbp-0x98]
       call     [Lokad.Lython.LythonMemoryBudget:.ctor(System.Nullable`1[long]):this]
       mov      rax, gword ptr [rbp-0x98]
       mov      gword ptr [rbp-0x70], rax
 
G_M000_IG06:                ;; offset=0x015B
       mov      rax, gword ptr [rbp-0x70]
       mov      gword ptr [rbp-0x28], rax
       mov      rdi, gword ptr [rbp-0x28]
       mov      r11, 0x7828EDE62158
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      gword ptr [rbp-0x30], rax
 
G_M000_IG07:                ;; offset=0x0178
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonRunOptions:get_ResultMemoryBudget():Lokad.Lython.ILythonMemoryBudget:this]
       mov      gword ptr [rbp-0x78], rax
       mov      rax, gword ptr [rbp-0x78]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x78], 0
       jne      SHORT G_M000_IG08
       mov      rax, gword ptr [rbp-0x28]
       mov      gword ptr [rbp-0x80], rax
 
G_M000_IG08:                ;; offset=0x019F
       mov      rdi, gword ptr [rbp-0x80]
       mov      r11, 0x7828EDE62160
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      gword ptr [rbp-0x38], rax
 
G_M000_IG09:                ;; offset=0x01B4
       mov      rdi, gword ptr [rbp-0x18]
       mov      rsi, gword ptr [rbp-0x30]
       mov      rdx, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonRunOptions:WithMemoryOwners(Lokad.Lython.ILythonMemoryBudget,Lokad.Lython.ILythonMemoryBudget):Lokad.Lython.LythonRunOptions:this]
       mov      gword ptr [rbp-0xB0], rax
       mov      rdx, gword ptr [rbp-0xB0]
       mov      rsi, gword ptr [rbp-0x10]
       mov      rax, gword ptr [rbp-0x20]
       mov      rdi, gword ptr [rax+0x10]
       mov      rax, gword ptr [rbp-0x20]
       call     [rax+0x18]System.Func`3[System.__Canon,System.__Canon,System.__Canon]:Invoke(System.__Canon,System.__Canon):System.__Canon:this
       mov      gword ptr [rbp-0xB8], rax
       mov      rdi, gword ptr [rbp-0xB8]
       mov      rsi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonExecutionResult:OwnMemoryScope(Lokad.Lython.ILythonMemoryScope):Lokad.Lython.LythonExecutionResult:this]
       mov      gword ptr [rbp-0x50], rax
 
G_M000_IG10:                ;; offset=0x0207
       call     G_M000_IG15
       nop      
 
G_M000_IG11:                ;; offset=0x020D
       mov      rax, gword ptr [rbp-0x50]
 
G_M000_IG12:                ;; offset=0x0211
       add      rsp, 192
       pop      rbp
       ret      
 
G_M000_IG13:                ;; offset=0x021A
       push     rax
 
G_M000_IG14:                ;; offset=0x021B
       mov      gword ptr [rbp-0x88], rdi
       mov      rdi, gword ptr [rbp-0x38]
       mov      r11, 0x7828EDE62168
       call     [r11]System.IDisposable:Dispose():this
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG15:                ;; offset=0x0239
       push     rax
 
G_M000_IG16:                ;; offset=0x023A
       cmp      gword ptr [rbp-0x30], 0
       je       SHORT G_M000_IG17
       mov      rdi, gword ptr [rbp-0x30]
       mov      r11, 0x7828EDE62170
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG17:                ;; offset=0x0252
       nop      
 
G_M000_IG18:                ;; offset=0x0253
       add      rsp, 8
       ret      
 
; Total bytes of code 600

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:RunCore(byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 0x5D0
       lea      rbp, [rsp+0x5D0]
       vxorps   xmm8, xmm8, xmm8
       mov      rax, -0x570
 
G_M000_IG125:                ;; offset=0x001F
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG125
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp-0x30], rdi
       mov      bword ptr [rbp-0x38], rsi
 
G_M000_IG02:                ;; offset=0x0043
       mov      dword ptr [rbp-0x3E4], 0x3E8
       mov      rax, 0x782111801A70
       mov      rsi, gword ptr [rax]
       mov      rdi, bword ptr [rbp-0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG115
 
G_M000_IG03:                ;; offset=0x0068
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rcx+0x38]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG120
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x40], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x1A0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x3F0], rax
       mov      rsi, gword ptr [rbp-0x3F0]
       mov      rdi, gword ptr [rbp-0x1A0]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.ExecutionState:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0x64], eax
       mov      eax, dword ptr [rbp-0x64]
       add      eax, -3
       mov      dword ptr [rbp-0x5B4], eax
       cmp      dword ptr [rbp-0x5B4], 3
       ja       SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00F7
       mov      eax, dword ptr [rbp-0x5B4]
       lea      rcx, [reloc @RWD00]
       mov      ecx, dword ptr [rcx+4*rax]
       lea      rdx, G_M000_IG02
       add      rcx, rdx
       jmp      rcx
 
G_M000_IG05:                ;; offset=0x0113
       mov      eax, dword ptr [rbp-0x64]
       add      eax, -25
       mov      dword ptr [rbp-0x5B8], eax
       cmp      dword ptr [rbp-0x5B8], 43
       ja       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x0128
       mov      eax, dword ptr [rbp-0x5B8]
       lea      rcx, [reloc @RWD16]
       mov      ecx, dword ptr [rcx+4*rax]
       lea      rdx, G_M000_IG02
       add      rcx, rdx
       jmp      rcx
 
G_M000_IG07:                ;; offset=0x0144
       mov      rdi, 0x7828F0962488
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG113
 
G_M000_IG08:                ;; offset=0x0158
       mov      rdi, 0x7828F096248C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       mov      dword ptr [rbp-0x3F4], eax
       mov      esi, dword ptr [rbp-0x3F4]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG118
 
G_M000_IG09:                ;; offset=0x0192
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x3F8], eax
       mov      esi, dword ptr [rbp-0x3F8]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      rsi, rax
       mov      rdi, bword ptr [rbp-0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1A4], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x1A4]
       jg       SHORT G_M000_IG10
       mov      rdi, 0x7828F0962490
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 72
       mov      bword ptr [rbp-0x1B0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1B4], eax
       mov      rax, bword ptr [rbp-0x1B0]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x1B4], eax
       jae      G_M000_IG120
       mov      rax, bword ptr [rbp-0x1B0]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x1B4]
       xor      rdx, rdx
       mov      gword ptr [rax+8*rcx], rdx
 
G_M000_IG10:                ;; offset=0x0248
       mov      rdi, 0x7828F0962494
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       mov      dword ptr [rbp-0x3FC], eax
       mov      esi, dword ptr [rbp-0x3FC]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG118
 
G_M000_IG11:                ;; offset=0x0282
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Collections.Generic.IReadOnlyList`1[System.Object]:this]
       mov      gword ptr [rbp-0x3C0], rax
       mov      rax, gword ptr [rbp-0x3C0]
       mov      gword ptr [rbp-0x3C8], rax
       mov      rdi, gword ptr [rbp-0x3C8]
       mov      rsi, 0x7828F0962498
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x3C8]
       mov      gword ptr [rbp-0x408], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      dword ptr [rbp-0x40C], eax
       mov      rdi, gword ptr [rbp-0x408]
       mov      esi, dword ptr [rbp-0x40C]
       mov      r11, 0x7828EDE626E8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      gword ptr [rbp-0x418], rax
       mov      rdx, gword ptr [rbp-0x418]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG12:                ;; offset=0x031F
       mov      rdi, 0x7828F09625A0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x3B4], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x420], rax
       mov      rdx, gword ptr [rbp-0x420]
       mov      esi, dword ptr [rbp-0x3B4]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:ReadLocal(int,Lokad.Lython.LythonSourceSpan):System.Object:this]
       mov      gword ptr [rbp-0x428], rax
       mov      rdx, gword ptr [rbp-0x428]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG13:                ;; offset=0x0387
       mov      rdi, 0x7828F09625A4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.Collections.Generic.IReadOnlyList`1[System.String]:this]
       mov      gword ptr [rbp-0x3A8], rax
       mov      rax, gword ptr [rbp-0x3A8]
       mov      gword ptr [rbp-0x3D0], rax
       mov      rdi, gword ptr [rbp-0x3D0]
       mov      rsi, 0x7828F09625A8
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x3D0]
       mov      gword ptr [rbp-0x430], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      dword ptr [rbp-0x434], eax
       mov      rdi, gword ptr [rbp-0x430]
       mov      esi, dword ptr [rbp-0x434]
       mov      r11, 0x7828EDE626E0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x3B0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x440], rax
       mov      rsi, gword ptr [rbp-0x440]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdx, gword ptr [rax+0x18]
       mov      rdi, gword ptr [rbp-0x3B0]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x448], rax
       mov      rdx, gword ptr [rbp-0x448]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG14:                ;; offset=0x045E
       mov      rax, bword ptr [rbp-0x30]
       mov      r8, gword ptr [rax+0x18]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       mov      rax, bword ptr [rbp-0x30]
       mov      rsi, gword ptr [rax+0x10]
       mov      rax, bword ptr [rbp-0x30]
       mov      edx, dword ptr [rax+0x38]
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rax+0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       je       SHORT G_M000_IG15
       mov      rdi, 0x7828F09626B0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       add      dword ptr [rax+0x38], 2
       jmp      G_M000_IG114
 
G_M000_IG15:                ;; offset=0x04AA
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      dword ptr [rbp-0x44C], eax
       mov      esi, dword ptr [rbp-0x44C]
       lea      rdx, [rbp-0x48]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryCell(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG17
       mov      rdi, gword ptr [rbp-0x48]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp-0x50], 0
       jne      SHORT G_M000_IG18
 
G_M000_IG16:                ;; offset=0x04E9
       mov      rdi, 0x7828F09626B4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG17:                ;; offset=0x04F8
       mov      rdi, 0x7828F09626B8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG18:                ;; offset=0x050C
       mov      rdi, 0x7828F09626BC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG19:                ;; offset=0x0532
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      dword ptr [rbp-0x450], eax
       mov      esi, dword ptr [rbp-0x450]
       lea      rdx, [rbp-0x58]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryCell(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG21
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_CanStoreThroughOwner():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG22
 
G_M000_IG20:                ;; offset=0x056A
       mov      rdi, 0x7828F09626C0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG21:                ;; offset=0x0579
       mov      rdi, 0x7828F09626C4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG22:                ;; offset=0x058D
       mov      rdi, 0x7828F09626C8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      gword ptr [rbp-0x60], rax
       mov      rdi, gword ptr [rbp-0x58]
       mov      rsi, gword ptr [rbp-0x60]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG23:                ;; offset=0x05C3
       mov      rdi, 0x7828F09626CC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 72
       mov      bword ptr [rbp-0x370], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x374], eax
       mov      rax, bword ptr [rbp-0x370]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x374], eax
       jae      G_M000_IG120
       mov      rax, bword ptr [rbp-0x370]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x374]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x380], rax
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rsi, rax
       mov      rdi, bword ptr [rbp-0x380]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG114
 
G_M000_IG24:                ;; offset=0x064A
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x454], eax
       mov      esi, dword ptr [rbp-0x454]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x70], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.Collections.Generic.IReadOnlyList`1[System.String]:this]
       mov      gword ptr [rbp-0x390], rax
       mov      rax, gword ptr [rbp-0x390]
       mov      gword ptr [rbp-0x3D8], rax
       mov      rdi, gword ptr [rbp-0x3D8]
       mov      rsi, 0x7828F09626D0
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x3D8]
       mov      gword ptr [rbp-0x460], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      dword ptr [rbp-0x464], eax
       mov      rdi, gword ptr [rbp-0x460]
       mov      esi, dword ptr [rbp-0x464]
       mov      r11, 0x7828EDE626D8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x78], rax
       mov      rsi, gword ptr [rbp-0x70]
       mov      rdi, 0x7828F04A75E0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG26
       mov      rsi, gword ptr [rbp-0x70]
       mov      rdi, 0x7828F082EFC8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG25
       xor      rax, rax
       mov      gword ptr [rbp-0x398], rax
       jmp      SHORT G_M000_IG27
 
G_M000_IG25:                ;; offset=0x0724
       mov      rdi, 0x7828F09627D8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime+DictMembers:GetMethod(System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      gword ptr [rbp-0x398], rax
       jmp      SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x0746
       mov      rdi, 0x7828F09627DC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime+StringMembers:GetMethod(System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      gword ptr [rbp-0x398], rax
 
G_M000_IG27:                ;; offset=0x0766
       mov      rax, gword ptr [rbp-0x398]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x80], 0
       jne      SHORT G_M000_IG28
       mov      rdi, 0x7828F09627E0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG28:                ;; offset=0x078C
       mov      rdi, 0x7828F09627E4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x39C], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x468], eax
       mov      edx, dword ptr [rbp-0x468]
       mov      esi, dword ptr [rbp-0x39C]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rcx, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x3A0], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x46C], eax
       mov      edx, dword ptr [rbp-0x46C]
       mov      esi, dword ptr [rbp-0x3A0]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rcx, gword ptr [rbp-0x80]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG29:                ;; offset=0x0818
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG30
       mov      rdi, 0x7828F09627E8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG30:                ;; offset=0x083E
       mov      rdi, 0x7828F09627EC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG114
 
G_M000_IG31:                ;; offset=0x0852
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x470], eax
       mov      esi, dword ptr [rbp-0x470]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x278], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x474], eax
       mov      esi, dword ptr [rbp-0x474]
       mov      rdi, bword ptr [rbp-0x30]
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x88], rax
       mov      rsi, gword ptr [rbp-0x278]
       mov      rdi, 0x7828F082EFC8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x90], rax
       cmp      gword ptr [rbp-0x90], 0
       je       SHORT G_M000_IG33
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_HasProtocolKeys():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG34
       mov      rsi, gword ptr [rbp-0x88]
       mov      rdi, 0x7828F04A75E0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x98], rax
       cmp      gword ptr [rbp-0x98], 0
       jne      SHORT G_M000_IG35
 
G_M000_IG32:                ;; offset=0x090A
       mov      rdi, 0x7828F09627F0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG33:                ;; offset=0x0919
       mov      rdi, 0x7828F09627F4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG34:                ;; offset=0x092D
       mov      rdi, 0x7828F09627F8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG33
 
G_M000_IG35:                ;; offset=0x093E
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       test     eax, eax
       jl       G_M000_IG38
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_HasSharedRecordKeys():bool:this]
       test     eax, eax
       je       G_M000_IG37
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x280], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x480], rax
       mov      rsi, gword ptr [rbp-0x480]
       mov      rdi, gword ptr [rbp-0x280]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:GetLookupCaches(Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntime+ExecutableLookupCache[]:this]
       mov      gword ptr [rbp-0xA0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       mov      rcx, gword ptr [rbp-0xA0]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG120
       mov      edx, eax
       imul     rdx, rdx, 24
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x288], rcx
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x290], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x488], rax
       mov      r8, gword ptr [rbp-0x488]
       lea      r9, [rbp-0xA8]
       mov      rsi, gword ptr [rbp-0x98]
       mov      rdx, bword ptr [rbp-0x288]
       mov      rcx, gword ptr [rbp-0x290]
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryReadRecordValue(Lokad.Lython.Runtime.Text.PyString,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG36
       mov      rdi, 0x7828F09627FC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0xA8]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG36:                ;; offset=0x0A4E
       mov      rdi, 0x7828F0962800
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG38
 
G_M000_IG37:                ;; offset=0x0A5F
       mov      rdi, 0x7828F0962804
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG38:                ;; offset=0x0A6E
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_HasProtocolKeys():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG39
       mov      rdi, 0x7828F0962808
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG39:                ;; offset=0x0A95
       mov      rdi, 0x7828F096280C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x490], rax
       mov      rdx, gword ptr [rbp-0x490]
       mov      rax, bword ptr [rbp-0x30]
       mov      rcx, gword ptr [rax+0x18]
       mov      rsi, gword ptr [rbp-0x98]
       mov      rdi, gword ptr [rbp-0x90]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadSubscriptValue(System.Object,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x498], rax
       mov      rdx, gword ptr [rbp-0x498]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG40:                ;; offset=0x0AF9
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x49C], eax
       mov      esi, dword ptr [rbp-0x49C]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xB0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_UnaryOperator():int:this]
       test     eax, eax
       je       G_M000_IG43
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, 0x7828F0641F78
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG42
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, 0x7828EF0B6558
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG41
       mov      rdi, 0x7828F0962810
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, 0x7828EF0835C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x1D4], eax
       jmp      SHORT G_M000_IG44
 
G_M000_IG41:                ;; offset=0x0BA3
       mov      rdi, 0x7828F0962814
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG42:                ;; offset=0x0BB2
       xor      eax, eax
       mov      dword ptr [rbp-0x1D4], eax
       jmp      SHORT G_M000_IG44
 
G_M000_IG43:                ;; offset=0x0BBC
       mov      rdi, 0x7828F0962818
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x1D4], eax
 
G_M000_IG44:                ;; offset=0x0BE6
       cmp      dword ptr [rbp-0x1D4], 0
       je       SHORT G_M000_IG45
       mov      rdi, 0x7828F096281C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG45:                ;; offset=0x0C03
       mov      rdi, 0x7828F0962820
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_UnaryOperator():int:this]
       mov      dword ptr [rbp-0x1D8], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4A8], rax
       mov      rcx, gword ptr [rbp-0x4A8]
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdx, gword ptr [rbp-0x1E0]
       mov      edi, dword ptr [rbp-0x1D8]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateExecutableUnary(int,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x4B0], rax
       mov      rdx, gword ptr [rbp-0x4B0]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG46:                ;; offset=0x0C84
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4B4], eax
       mov      esi, dword ptr [rbp-0x4B4]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xB8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x4B8], eax
       mov      esi, dword ptr [rbp-0x4B8]
       mov      rdi, bword ptr [rbp-0x30]
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xC0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 48
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0xC4], eax
       cmp      dword ptr [rbp-0xC4], 0
       jne      G_M000_IG49
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x258], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rax+0x48]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdx, qword ptr [rax+0x50]
       mov      rdi, 0x7828EFFFB4D0
       call     [System.Span`1[System.__Canon]:op_Implicit(System.Span`1[System.__Canon]):System.ReadOnlySpan`1[System.__Canon]]
       mov      bword ptr [rbp-0x250], rax
       mov      qword ptr [rbp-0x248], rdx
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rsp], rax
       lea      rax, [rbp-0xD0]
       mov      qword ptr [rsp+0x08], rax
       lea      rax, [rbp-0xD8]
       mov      qword ptr [rsp+0x10], rax
       mov      rsi, bword ptr [rbp-0x250]
       mov      rdx, qword ptr [rbp-0x248]
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rax+0x38]
       mov      rdi, gword ptr [rbp-0x258]
       mov      r8, gword ptr [rbp-0xB8]
       mov      r9, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryIntegerChain(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[System.Object],int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,byref):bool]
       test     eax, eax
       je       G_M000_IG48
       mov      rdi, 0x7828F0962824
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0xD0]
       mov      dword ptr [rax+0x38], ecx
 
G_M000_IG47:                ;; offset=0x0DB4
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0xD0]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG120
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x270], rax
       mov      rdi, qword ptr [rbp-0xD8]
       call     [System.Numerics.BigInteger:op_Implicit(long):System.Numerics.BigInteger]
       mov      gword ptr [rbp-0x268], rax
       mov      qword ptr [rbp-0x260], rdx
       lea      rsi, [rbp-0x268]
       mov      rdi, 0x7828F0641F78
       call     [CORINFO_HELP_BOX]
       mov      gword ptr [rbp-0x4C0], rax
       mov      rdx, gword ptr [rbp-0x4C0]
       mov      rsi, bword ptr [rbp-0x270]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG48:                ;; offset=0x0E3B
       mov      rdi, 0x7828F0962828
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG49:                ;; offset=0x0E4A
       cmp      dword ptr [rbp-0xC4], 0
       jne      G_M000_IG51
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x234], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x240], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4C8], rax
       mov      r8, gword ptr [rbp-0x4C8]
       lea      r9, [rbp-0xE0]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, gword ptr [rbp-0x240]
       mov      edi, dword ptr [rbp-0x234]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG50
       mov      rdi, 0x7828F096282C
       call     CORINFO_HELP_COUNTPROFILE32
       movzx    rdi, byte  ptr [rbp-0xE0]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(bool):System.Object]
       mov      gword ptr [rbp-0x4D0], rax
       mov      rdx, gword ptr [rbp-0x4D0]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG50:                ;; offset=0x0EF8
       mov      rdi, 0x7828F0962830
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG51:                ;; offset=0x0F07
       cmp      dword ptr [rbp-0xC4], 0
       jne      SHORT G_M000_IG52
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x1E4], eax
       jmp      SHORT G_M000_IG53
 
G_M000_IG52:                ;; offset=0x0F22
       mov      rdi, 0x7828F0962834
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_AugmentedOperator():int:this]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.LythonRuntime:AugmentedBinaryOperator(int):int]
       mov      dword ptr [rbp-0x1E4], eax
 
G_M000_IG53:                ;; offset=0x0F49
       mov      edi, dword ptr [rbp-0x1E4]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdx, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeBinary(int,System.Object,System.Object):bool]
       test     eax, eax
       jne      SHORT G_M000_IG54
       mov      rdi, 0x7828F0962838
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG54:                ;; offset=0x0F7B
       cmp      dword ptr [rbp-0xC4], 0
       je       G_M000_IG63
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, 0x7828F0641F78
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG56
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, 0x7828EF0B6558
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG62
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, 0x7828EF0835C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       G_M000_IG61
 
G_M000_IG55:                ;; offset=0x0FE4
       mov      rdi, 0x7828F096283C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG56:                ;; offset=0x0FF3
       mov      rsi, gword ptr [rbp-0xC0]
       mov      rdi, 0x7828F0641F78
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG60
       mov      rsi, gword ptr [rbp-0xC0]
       mov      rdi, 0x7828EF0B6558
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG59
       mov      rsi, gword ptr [rbp-0xC0]
       mov      rdi, 0x7828EF0835C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG58
 
G_M000_IG57:                ;; offset=0x1047
       mov      rdi, 0x7828F0962840
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG58:                ;; offset=0x105B
       mov      rdi, 0x7828F0962844
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG63
 
G_M000_IG59:                ;; offset=0x106C
       mov      rdi, 0x7828F0962848
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG63
 
G_M000_IG60:                ;; offset=0x107D
       mov      rdi, 0x7828F096284C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG63
 
G_M000_IG61:                ;; offset=0x108E
       mov      rdi, 0x7828F0962850
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG57
 
G_M000_IG62:                ;; offset=0x109F
       mov      rdi, 0x7828F0962854
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG56
 
G_M000_IG63:                ;; offset=0x10B3
       mov      rax, bword ptr [rbp-0x30]
       mov      bword ptr [rbp-0x1F0], rax
       mov      rax, bword ptr [rbp-0x40]
       mov      bword ptr [rbp-0x1F8], rax
       cmp      dword ptr [rbp-0xC4], 0
       jne      G_M000_IG64
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x224], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x230], rax
       mov      rax, bword ptr [rbp-0x1F0]
       mov      bword ptr [rbp-0x210], rax
       mov      rax, bword ptr [rbp-0x1F8]
       mov      bword ptr [rbp-0x218], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4D8], rax
       mov      r8, gword ptr [rbp-0x4D8]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, gword ptr [rbp-0x230]
       mov      edi, dword ptr [rbp-0x224]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateBinaryOperator(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x220], rax
       jmp      G_M000_IG65
 
G_M000_IG64:                ;; offset=0x1156
       mov      rdi, 0x7828F0962858
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_AugmentedOperator():int:this]
       mov      dword ptr [rbp-0x1FC], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x208], rax
       mov      rax, bword ptr [rbp-0x1F0]
       mov      bword ptr [rbp-0x210], rax
       mov      rax, bword ptr [rbp-0x1F8]
       mov      bword ptr [rbp-0x218], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4E0], rax
       mov      r8, gword ptr [rbp-0x4E0]
       mov      rsi, gword ptr [rbp-0xC0]
       mov      edx, dword ptr [rbp-0x1FC]
       mov      rcx, gword ptr [rbp-0x208]
       mov      rdi, gword ptr [rbp-0xB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateAugmentedBuiltin(System.Object,System.Object,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x220], rax
 
G_M000_IG65:                ;; offset=0x11E0
       mov      rdi, 0x7828F096285C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x210]
       mov      rsi, bword ptr [rbp-0x218]
       mov      rdx, gword ptr [rbp-0x220]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG66:                ;; offset=0x120F
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4E4], eax
       mov      esi, dword ptr [rbp-0x4E4]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xE8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x4E8], eax
       mov      esi, dword ptr [rbp-0x4E8]
       mov      rdi, bword ptr [rbp-0x30]
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xF0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x1B8], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4F0], rax
       mov      r8, gword ptr [rbp-0x4F0]
       lea      r9, [rbp-0xF8]
       mov      rsi, gword ptr [rbp-0xE8]
       mov      rdx, gword ptr [rbp-0xF0]
       mov      rcx, gword ptr [rbp-0x1C0]
       mov      edi, dword ptr [rbp-0x1B8]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG67
       mov      rdi, 0x7828F0962860
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG67:                ;; offset=0x12DB
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x4F4], eax
       mov      esi, dword ptr [rbp-0x4F4]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x500], rax
       mov      rsi, gword ptr [rbp-0x500]
       mov      rdi, gword ptr [rbp-0x1C8]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       movzx    rax, byte  ptr [rbp-0xF8]
       test     eax, eax
       jne      SHORT G_M000_IG68
       mov      rdi, 0x7828F0962864
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x38], eax
       jmp      G_M000_IG115
 
G_M000_IG68:                ;; offset=0x1361
       mov      rdi, 0x7828F0962868
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG114
 
G_M000_IG69:                ;; offset=0x1375
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x504], eax
       mov      esi, dword ptr [rbp-0x504]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x100], rax
       mov      rdi, gword ptr [rbp-0x100]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       jne      SHORT G_M000_IG70
       mov      rdi, 0x7828F096286C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG70:                ;; offset=0x13C3
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x510], rax
       mov      rdx, gword ptr [rbp-0x510]
       mov      rsi, gword ptr [rbp-0x1D0]
       mov      rdi, gword ptr [rbp-0x100]
       call     [Lokad.Lython.Runtime.LythonRuntime:IsTruthy(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG71
       mov      rdi, 0x7828F0962870
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x38], eax
       jmp      G_M000_IG115
 
G_M000_IG71:                ;; offset=0x1435
       mov      rdi, 0x7828F0962874
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG114
 
G_M000_IG72:                ;; offset=0x1449
       mov      rdi, 0x7828F0962878
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x38], eax
       jmp      G_M000_IG115
 
G_M000_IG73:                ;; offset=0x146E
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DiscardIterator():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG74
       mov      rdi, 0x7828F096287C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      eax, dword ptr [rax+0x3C]
       lea      esi, [rax-0x01]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG74:                ;; offset=0x149F
       mov      rdi, 0x7828F0962880
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x38], eax
       jmp      G_M000_IG115
 
G_M000_IG75:                ;; offset=0x14C4
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x514], eax
       mov      esi, dword ptr [rbp-0x514]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x108], rax
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7828F093C228
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG76
       mov      rdi, 0x7828F0962884
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0x108]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG76:                ;; offset=0x1532
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7828F0833E58
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG78
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7828F04A8090
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG83
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7828F0927C00
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG82
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7828F04AB920
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG81
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7828F04A75E0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG80
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7828F082EFC8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG79
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7828F08E26A8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG84
 
G_M000_IG77:                ;; offset=0x1606
       mov      rdi, 0x7828F0962888
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG78:                ;; offset=0x1615
       mov      dword ptr [rbp-0x10C], 1
       jmp      SHORT G_M000_IG85
 
G_M000_IG79:                ;; offset=0x1621
       mov      rdi, 0x7828F096288C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG78
 
G_M000_IG80:                ;; offset=0x1632
       mov      rdi, 0x7828F0962890
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG78
 
G_M000_IG81:                ;; offset=0x1643
       mov      rdi, 0x7828F0962894
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG78
 
G_M000_IG82:                ;; offset=0x1654
       mov      rdi, 0x7828F0962898
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG78
 
G_M000_IG83:                ;; offset=0x1665
       mov      rdi, 0x7828F096289C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG78
 
G_M000_IG84:                ;; offset=0x1676
       mov      rdi, 0x7828F09628A0
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x10C], eax
 
G_M000_IG85:                ;; offset=0x168D
       cmp      dword ptr [rbp-0x10C], 0
       je       SHORT G_M000_IG86
       mov      rdi, 0x7828F09628A4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x520], rax
       mov      rsi, gword ptr [rbp-0x520]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdx, gword ptr [rax+0x18]
       mov      rdi, gword ptr [rbp-0x108]
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:Create(System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyIteration+Cursor]
       mov      gword ptr [rbp-0x528], rax
       mov      rdx, gword ptr [rbp-0x528]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG86:                ;; offset=0x16F3
       mov      rdi, 0x7828F09628A8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG87:                ;; offset=0x1707
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 72
       mov      bword ptr [rbp-0x298], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x29C], eax
       mov      rax, bword ptr [rbp-0x298]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x29C], eax
       jae      G_M000_IG120
       mov      rax, bword ptr [rbp-0x298]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x29C]
       mov      rax, gword ptr [rax+8*rcx]
       mov      gword ptr [rbp-0x118], rax
       mov      rsi, gword ptr [rbp-0x118]
       mov      rdi, 0x7828F093C228
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x130], rax
       cmp      gword ptr [rbp-0x130], 0
       jne      G_M000_IG93
       mov      rsi, gword ptr [rbp-0x118]
       mov      rdi, 0x7828F0831118
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x530], rax
       mov      rdi, gword ptr [rbp-0x530]
       lea      rsi, [rbp-0x138]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:TryMoveNext(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG90
       call     [Lokad.Lython.Runtime.PyIterationResult:get_End():Lokad.Lython.Runtime.PyIterationResult]
       mov      gword ptr [rbp-0x2E0], rax
       mov      qword ptr [rbp-0x2D8], rdx
 
G_M000_IG88:                ;; offset=0x17D5
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2E0]
       vmovdqu32 xmmword ptr [rbp-0x2C0], xmm0
 
G_M000_IG89:                ;; offset=0x17E3
       jmp      SHORT G_M000_IG95
 
G_M000_IG90:                ;; offset=0x17E5
       mov      rdi, 0x7828F09628AC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x138]
       call     [Lokad.Lython.Runtime.PyIterationResult:Yield(System.Object):Lokad.Lython.Runtime.PyIterationResult]
       mov      gword ptr [rbp-0x2D0], rax
       mov      qword ptr [rbp-0x2C8], rdx
 
G_M000_IG91:                ;; offset=0x180F
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2D0]
       vmovdqu32 xmmword ptr [rbp-0x2C0], xmm0
 
G_M000_IG92:                ;; offset=0x181D
       jmp      SHORT G_M000_IG95
 
G_M000_IG93:                ;; offset=0x181F
       mov      rdi, 0x7828F09628B0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x130]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:MoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       mov      gword ptr [rbp-0x2B0], rax
       mov      qword ptr [rbp-0x2A8], rdx
 
G_M000_IG94:                ;; offset=0x184B
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2B0]
       vmovdqu32 xmmword ptr [rbp-0x2C0], xmm0
 
G_M000_IG95:                ;; offset=0x1859
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2C0]
       vmovdqu  xmmword ptr [rbp-0x128], xmm0
 
G_M000_IG96:                ;; offset=0x1868
       lea      rdi, [rbp-0x128]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_HasValue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG97
       mov      rdi, 0x7828F09628B4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x534], eax
       mov      esi, dword ptr [rbp-0x534]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x38], eax
       jmp      G_M000_IG115
 
G_M000_IG97:                ;; offset=0x18BE
       mov      rdi, 0x7828F09628B8
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdi, [rbp-0x128]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_Value():System.Object:this]
       mov      gword ptr [rbp-0x540], rax
       mov      rdx, gword ptr [rbp-0x540]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG98:                ;; offset=0x18FB
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryReturnUnpackedTuple(byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG99
       mov      rdi, 0x7828F09628BC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG118
 
G_M000_IG99:                ;; offset=0x1921
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       test     eax, eax
       je       G_M000_IG100
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 72
       mov      bword ptr [rbp-0x2F0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x2F4], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x544], eax
       mov      ecx, dword ptr [rbp-0x544]
       mov      rdi, bword ptr [rbp-0x2F0]
       mov      edx, dword ptr [rbp-0x2F4]
       mov      rsi, 0x7828EFFFB4D0
       call     [System.Span`1[System.__Canon]:Slice(int,int):System.Span`1[System.__Canon]:this]
       mov      bword ptr [rbp-0x308], rax
       mov      qword ptr [rbp-0x300], rdx
       mov      rsi, bword ptr [rbp-0x308]
       mov      rdx, qword ptr [rbp-0x300]
       mov      rdi, 0x7828EFFFB4D0
       call     [System.Span`1[System.__Canon]:op_Implicit(System.Span`1[System.__Canon]):System.ReadOnlySpan`1[System.__Canon]]
       mov      bword ptr [rbp-0x318], rax
       mov      qword ptr [rbp-0x310], rdx
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x320], rax
       mov      rdi, 0x7828F04A8090
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x328], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x550], rax
       mov      r8, gword ptr [rbp-0x550]
       mov      rax, bword ptr [rbp-0x30]
       mov      r9, gword ptr [rax+0x18]
       mov      rsi, bword ptr [rbp-0x318]
       mov      rdx, qword ptr [rbp-0x310]
       mov      rcx, gword ptr [rbp-0x320]
       mov      rdi, gword ptr [rbp-0x328]
       call     [Lokad.Lython.Runtime.PyTuple:.ctor(System.ReadOnlySpan`1[System.Object],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):this]
       mov      rax, gword ptr [rbp-0x328]
       mov      gword ptr [rbp-0x2E8], rax
       jmp      SHORT G_M000_IG101
 
G_M000_IG100:                ;; offset=0x1A44
       mov      rdi, 0x7828F09628C0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, 0x782111801968
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x2E8], rax
 
G_M000_IG101:                ;; offset=0x1A67
       mov      rdi, 0x7828F09628C4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x2E8]
       mov      gword ptr [rbp-0x140], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x554], eax
       mov      esi, dword ptr [rbp-0x554]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0x140]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG102:                ;; offset=0x1ABE
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.PyList:EstimateCapacityBytes(int):long]
       mov      qword ptr [rbp-0x148], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x330], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x560], rax
       mov      rdx, gword ptr [rbp-0x560]
       mov      rsi, qword ptr [rbp-0x148]
       mov      rdi, gword ptr [rbp-0x330]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.MemoryGovernor:ReserveTemporary(long,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:this]
       mov      gword ptr [rbp-0x150], rax
 
G_M000_IG103:                ;; offset=0x1B23
       mov      rdi, 0x7828F09628C8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x338], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x568], rax
       mov      rsi, gword ptr [rbp-0x568]
       mov      rdi, gword ptr [rbp-0x338]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 72
       mov      bword ptr [rbp-0x340], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x344], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x56C], eax
       mov      ecx, dword ptr [rbp-0x56C]
       mov      rdi, bword ptr [rbp-0x340]
       mov      edx, dword ptr [rbp-0x344]
       mov      rsi, 0x7828EFFFB4D0
       call     [System.Span`1[System.__Canon]:Slice(int,int):System.Span`1[System.__Canon]:this]
       mov      bword ptr [rbp-0x358], rax
       mov      qword ptr [rbp-0x350], rdx
 
G_M000_IG104:                ;; offset=0x1BCE
       vmovdqu  xmm0, xmmword ptr [rbp-0x358]
       vmovdqu  xmmword ptr [rbp-0x168], xmm0
 
G_M000_IG105:                ;; offset=0x1BDE
       lea      rdi, [rbp-0x168]
       mov      rsi, 0x7828EFFFB4D0
       call     [System.Span`1[System.__Canon]:ToArray():System.__Canon[]:this]
       mov      gword ptr [rbp-0x158], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x570], eax
       mov      esi, dword ptr [rbp-0x570]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, gword ptr [rbp-0x150]
       mov      rsi, qword ptr [rbp-0x148]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:Commit(long):this]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x360], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x578], rax
       mov      rdx, gword ptr [rbp-0x578]
       mov      rsi, gword ptr [rbp-0x360]
       mov      rdi, gword ptr [rbp-0x158]
       call     [Lokad.Lython.Runtime.PyList:FromTransferredArray(System.Object[],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x580], rax
       mov      rdx, gword ptr [rbp-0x580]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       nop      
 
G_M000_IG106:                ;; offset=0x1C92
       call     G_M000_IG121
       jmp      G_M000_IG114
 
G_M000_IG107:                ;; offset=0x1C9C
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Format(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG110
       mov      rdi, 0x7828F09629DC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG108:                ;; offset=0x1CBD
       xor      eax, eax
 
G_M000_IG109:                ;; offset=0x1CBF
       add      rsp, 0x5D0
       pop      rbp
       ret      
 
G_M000_IG110:                ;; offset=0x1CC8
       mov      rdi, 0x7828F09629E0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG114
 
G_M000_IG111:                ;; offset=0x1CDC
       mov      rdi, 0x7828F09629E4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x364], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x368], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x58C], eax
       mov      esi, dword ptr [rbp-0x58C]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x598], rax
       mov      rcx, gword ptr [rbp-0x598]
       mov      esi, dword ptr [rbp-0x364]
       mov      edx, dword ptr [rbp-0x368]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG112:                ;; offset=0x1D58
       mov      rdi, 0x7828F09629E8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x59C], eax
       mov      esi, dword ptr [rbp-0x59C]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x5A0], eax
       mov      esi, dword ptr [rbp-0x5A0]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG114
 
G_M000_IG113:                ;; offset=0x1DAE
       lea      rdi, [rbp-0x190]
       mov      esi, 26
       mov      edx, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
       lea      rdi, [rbp-0x190]
       mov      rsi, 0x7828EC25C048
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendLiteral(System.String):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0x5A4], eax
       mov      esi, dword ptr [rbp-0x5A4]
       lea      rdi, [rbp-0x190]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rdi, 0x7828EF797A68
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x388], rax
       lea      rdi, [rbp-0x190]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      gword ptr [rbp-0x5B0], rax
       mov      rsi, gword ptr [rbp-0x5B0]
       mov      rdi, gword ptr [rbp-0x388]
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, gword ptr [rbp-0x388]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG114:                ;; offset=0x1E4A
       mov      rdi, 0x7828F09629EC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       inc      dword ptr [rax+0x38]
 
G_M000_IG115:                ;; offset=0x1E60
       mov      eax, dword ptr [rbp-0x3E4]
       dec      eax
       mov      dword ptr [rbp-0x3E4], eax
       cmp      dword ptr [rbp-0x3E4], 0
       jg       SHORT G_M000_IG117
 
G_M000_IG116:                ;; offset=0x1E77
       lea      rdi, [rbp-0x3E4]
       mov      esi, 0x96A
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG117:                ;; offset=0x1E8A
       mov      rax, bword ptr [rbp-0x30]
       mov      eax, dword ptr [rax+0x38]
       mov      dword ptr [rbp-0x194], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x194]
       jg       G_M000_IG03
       mov      rdi, 0x7828F09629F0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG118:                ;; offset=0x1EC5
       mov      eax, 1
 
G_M000_IG119:                ;; offset=0x1ECA
       add      rsp, 0x5D0
       pop      rbp
       ret      
 
G_M000_IG120:                ;; offset=0x1ED3
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG121:                ;; offset=0x1ED9
       sub      rsp, 24
 
G_M000_IG122:                ;; offset=0x1EDD
       cmp      gword ptr [rbp-0x150], 0
       je       SHORT G_M000_IG123
       mov      rdi, 0x7828F09628CC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x150]
       mov      gword ptr [rbp-0x3E0], rax
       mov      rdi, gword ptr [rbp-0x3E0]
       mov      rsi, 0x7828F09628D0
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x3E0]
       mov      gword ptr [rbp-0x588], rax
       mov      rdi, gword ptr [rbp-0x588]
       mov      r11, 0x7828EDE626D0
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG123:                ;; offset=0x1F3C
       mov      rdi, 0x7828F09629D8
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG124:                ;; offset=0x1F4C
       add      rsp, 24
       ret      
 
RWD00  	dd	0000023Fh ; case G_M000_IG11
       	dd	000002DCh ; case G_M000_IG12
       	dd	0000041Bh ; case G_M000_IG14
       	dd	00000344h ; case G_M000_IG13
RWD16  	dd	00000607h ; case G_M000_IG24
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00000580h ; case G_M000_IG23
       	dd	000004EFh ; case G_M000_IG19
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001C99h ; case G_M000_IG111
       	dd	00001D15h ; case G_M000_IG112
       	dd	00001A7Bh ; case G_M000_IG102
       	dd	000018B8h ; case G_M000_IG98
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001481h ; case G_M000_IG75
       	dd	000016C4h ; case G_M000_IG87
       	dd	000007D5h ; case G_M000_IG29
       	dd	0000080Fh ; case G_M000_IG31
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00000C41h ; case G_M000_IG46
       	dd	00000C41h ; case G_M000_IG46
       	dd	00000AB6h ; case G_M000_IG40
       	dd	00001406h ; case G_M000_IG72
       	dd	00001332h ; case G_M000_IG69
       	dd	000011CCh ; case G_M000_IG66
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	0000014Fh ; case G_M000_IG09
       	dd	00000115h ; case G_M000_IG08
       	dd	00000115h ; case G_M000_IG08
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	0000142Bh ; case G_M000_IG73
       	dd	00001C59h ; case G_M000_IG107
       	dd	00001C59h ; case G_M000_IG107
       	dd	00001C59h ; case G_M000_IG107
       	dd	00001C59h ; case G_M000_IG107
       	dd	00001C59h ; case G_M000_IG107

; Total bytes of code 8017

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:RunCore(byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 0x5D0
       lea      rbp, [rsp+0x5D0]
       vxorps   xmm8, xmm8, xmm8
       mov      rax, -0x570
 
G_M000_IG125:                ;; offset=0x001F
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG125
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp-0x30], rdi
       mov      bword ptr [rbp-0x38], rsi
 
G_M000_IG02:                ;; offset=0x0043
       mov      dword ptr [rbp-0x3E4], 0x3E8
       mov      rax, 0x782111801A70
       mov      rsi, gword ptr [rax]
       mov      rdi, bword ptr [rbp-0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG115
 
G_M000_IG03:                ;; offset=0x0068
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rcx+0x38]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG120
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x40], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x1A0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x3F0], rax
       mov      rsi, gword ptr [rbp-0x3F0]
       mov      rdi, gword ptr [rbp-0x1A0]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.ExecutionState:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0x64], eax
       mov      eax, dword ptr [rbp-0x64]
       add      eax, -3
       mov      dword ptr [rbp-0x5B4], eax
       cmp      dword ptr [rbp-0x5B4], 3
       ja       SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00F7
       mov      eax, dword ptr [rbp-0x5B4]
       lea      rcx, [reloc @RWD00]
       mov      ecx, dword ptr [rcx+4*rax]
       lea      rdx, G_M000_IG02
       add      rcx, rdx
       jmp      rcx
 
G_M000_IG05:                ;; offset=0x0113
       mov      eax, dword ptr [rbp-0x64]
       add      eax, -25
       mov      dword ptr [rbp-0x5B8], eax
       cmp      dword ptr [rbp-0x5B8], 43
       ja       SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x0128
       mov      eax, dword ptr [rbp-0x5B8]
       lea      rcx, [reloc @RWD16]
       mov      ecx, dword ptr [rcx+4*rax]
       lea      rdx, G_M000_IG02
       add      rcx, rdx
       jmp      rcx
 
G_M000_IG07:                ;; offset=0x0144
       mov      rdi, 0x7828F0962488
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG113
 
G_M000_IG08:                ;; offset=0x0158
       mov      rdi, 0x7828F096248C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       mov      dword ptr [rbp-0x3F4], eax
       mov      esi, dword ptr [rbp-0x3F4]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG118
 
G_M000_IG09:                ;; offset=0x0192
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x3F8], eax
       mov      esi, dword ptr [rbp-0x3F8]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      rsi, rax
       mov      rdi, bword ptr [rbp-0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1A4], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       cmp      eax, dword ptr [rbp-0x1A4]
       jg       SHORT G_M000_IG10
       mov      rdi, 0x7828F0962490
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 72
       mov      bword ptr [rbp-0x1B0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x1B4], eax
       mov      rax, bword ptr [rbp-0x1B0]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x1B4], eax
       jae      G_M000_IG120
       mov      rax, bword ptr [rbp-0x1B0]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x1B4]
       xor      rdx, rdx
       mov      gword ptr [rax+8*rcx], rdx
 
G_M000_IG10:                ;; offset=0x0248
       mov      rdi, 0x7828F0962494
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_FirstTemporarySlot():int:this]
       mov      dword ptr [rbp-0x3FC], eax
       mov      esi, dword ptr [rbp-0x3FC]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG118
 
G_M000_IG11:                ;; offset=0x0282
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Collections.Generic.IReadOnlyList`1[System.Object]:this]
       mov      gword ptr [rbp-0x3C0], rax
       mov      rax, gword ptr [rbp-0x3C0]
       mov      gword ptr [rbp-0x3C8], rax
       mov      rdi, gword ptr [rbp-0x3C8]
       mov      rsi, 0x7828F0962498
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x3C8]
       mov      gword ptr [rbp-0x408], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      dword ptr [rbp-0x40C], eax
       mov      rdi, gword ptr [rbp-0x408]
       mov      esi, dword ptr [rbp-0x40C]
       mov      r11, 0x7828EDE62D78
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      gword ptr [rbp-0x418], rax
       mov      rdx, gword ptr [rbp-0x418]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG12:                ;; offset=0x031F
       mov      rdi, 0x7828F09625A0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x3B4], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x420], rax
       mov      rdx, gword ptr [rbp-0x420]
       mov      esi, dword ptr [rbp-0x3B4]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:ReadLocal(int,Lokad.Lython.LythonSourceSpan):System.Object:this]
       mov      gword ptr [rbp-0x428], rax
       mov      rdx, gword ptr [rbp-0x428]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG13:                ;; offset=0x0387
       mov      rdi, 0x7828F09625A4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.Collections.Generic.IReadOnlyList`1[System.String]:this]
       mov      gword ptr [rbp-0x3A8], rax
       mov      rax, gword ptr [rbp-0x3A8]
       mov      gword ptr [rbp-0x3D0], rax
       mov      rdi, gword ptr [rbp-0x3D0]
       mov      rsi, 0x7828F09625A8
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x3D0]
       mov      gword ptr [rbp-0x430], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      dword ptr [rbp-0x434], eax
       mov      rdi, gword ptr [rbp-0x430]
       mov      esi, dword ptr [rbp-0x434]
       mov      r11, 0x7828EDE62D70
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x3B0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x440], rax
       mov      rsi, gword ptr [rbp-0x440]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdx, gword ptr [rax+0x18]
       mov      rdi, gword ptr [rbp-0x3B0]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x448], rax
       mov      rdx, gword ptr [rbp-0x448]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG14:                ;; offset=0x045E
       mov      rax, bword ptr [rbp-0x30]
       mov      r8, gword ptr [rax+0x18]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       mov      rax, bword ptr [rbp-0x30]
       mov      rsi, gword ptr [rax+0x10]
       mov      rax, bword ptr [rbp-0x30]
       mov      edx, dword ptr [rax+0x38]
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rax+0x3C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       je       SHORT G_M000_IG15
       mov      rdi, 0x7828F09626B0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       add      dword ptr [rax+0x38], 2
       jmp      G_M000_IG114
 
G_M000_IG15:                ;; offset=0x04AA
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      dword ptr [rbp-0x44C], eax
       mov      esi, dword ptr [rbp-0x44C]
       lea      rdx, [rbp-0x48]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryCell(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG17
       mov      rdi, gword ptr [rbp-0x48]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp-0x50], 0
       jne      SHORT G_M000_IG18
 
G_M000_IG16:                ;; offset=0x04E9
       mov      rdi, 0x7828F09626B4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG17:                ;; offset=0x04F8
       mov      rdi, 0x7828F09626B8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG18:                ;; offset=0x050C
       mov      rdi, 0x7828F09626BC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG19:                ;; offset=0x0532
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      dword ptr [rbp-0x450], eax
       mov      esi, dword ptr [rbp-0x450]
       lea      rdx, [rbp-0x58]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryCell(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG21
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_CanStoreThroughOwner():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG22
 
G_M000_IG20:                ;; offset=0x056A
       mov      rdi, 0x7828F09626C0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG21:                ;; offset=0x0579
       mov      rdi, 0x7828F09626C4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG22:                ;; offset=0x058D
       mov      rdi, 0x7828F09626C8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      gword ptr [rbp-0x60], rax
       mov      rdi, gword ptr [rbp-0x58]
       mov      rsi, gword ptr [rbp-0x60]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG23:                ;; offset=0x05C3
       mov      rdi, 0x7828F09626CC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 72
       mov      bword ptr [rbp-0x370], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x374], eax
       mov      rax, bword ptr [rbp-0x370]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x374], eax
       jae      G_M000_IG120
       mov      rax, bword ptr [rbp-0x370]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x374]
       lea      rax, bword ptr [rax+8*rcx]
       mov      bword ptr [rbp-0x380], rax
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rsi, rax
       mov      rdi, bword ptr [rbp-0x380]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG114
 
G_M000_IG24:                ;; offset=0x064A
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x454], eax
       mov      esi, dword ptr [rbp-0x454]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x70], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.Collections.Generic.IReadOnlyList`1[System.String]:this]
       mov      gword ptr [rbp-0x390], rax
       mov      rax, gword ptr [rbp-0x390]
       mov      gword ptr [rbp-0x3D8], rax
       mov      rdi, gword ptr [rbp-0x3D8]
       mov      rsi, 0x7828F09626D0
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x3D8]
       mov      gword ptr [rbp-0x460], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      dword ptr [rbp-0x464], eax
       mov      rdi, gword ptr [rbp-0x460]
       mov      esi, dword ptr [rbp-0x464]
       mov      r11, 0x7828EDE62D68
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x78], rax
       mov      rsi, gword ptr [rbp-0x70]
       mov      rdi, 0x7828F04A75E0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG26
       mov      rsi, gword ptr [rbp-0x70]
       mov      rdi, 0x7828F082EFC8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG25
       xor      rax, rax
       mov      gword ptr [rbp-0x398], rax
       jmp      SHORT G_M000_IG27
 
G_M000_IG25:                ;; offset=0x0724
       mov      rdi, 0x7828F09627D8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime+DictMembers:GetMethod(System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      gword ptr [rbp-0x398], rax
       jmp      SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x0746
       mov      rdi, 0x7828F09627DC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime+StringMembers:GetMethod(System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      gword ptr [rbp-0x398], rax
 
G_M000_IG27:                ;; offset=0x0766
       mov      rax, gword ptr [rbp-0x398]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x80], 0
       jne      SHORT G_M000_IG28
       mov      rdi, 0x7828F09627E0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG28:                ;; offset=0x078C
       mov      rdi, 0x7828F09627E4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x39C], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x468], eax
       mov      edx, dword ptr [rbp-0x468]
       mov      esi, dword ptr [rbp-0x39C]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rcx, gword ptr [rbp-0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x3A0], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x46C], eax
       mov      edx, dword ptr [rbp-0x46C]
       mov      esi, dword ptr [rbp-0x3A0]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rcx, gword ptr [rbp-0x80]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG29:                ;; offset=0x0818
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG30
       mov      rdi, 0x7828F09627E8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG30:                ;; offset=0x083E
       mov      rdi, 0x7828F09627EC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG114
 
G_M000_IG31:                ;; offset=0x0852
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x470], eax
       mov      esi, dword ptr [rbp-0x470]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x278], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x474], eax
       mov      esi, dword ptr [rbp-0x474]
       mov      rdi, bword ptr [rbp-0x30]
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x88], rax
       mov      rsi, gword ptr [rbp-0x278]
       mov      rdi, 0x7828F082EFC8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x90], rax
       cmp      gword ptr [rbp-0x90], 0
       je       SHORT G_M000_IG33
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_HasProtocolKeys():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG34
       mov      rsi, gword ptr [rbp-0x88]
       mov      rdi, 0x7828F04A75E0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x98], rax
       cmp      gword ptr [rbp-0x98], 0
       jne      SHORT G_M000_IG35
 
G_M000_IG32:                ;; offset=0x090A
       mov      rdi, 0x7828F09627F0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG33:                ;; offset=0x0919
       mov      rdi, 0x7828F09627F4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG34:                ;; offset=0x092D
       mov      rdi, 0x7828F09627F8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG33
 
G_M000_IG35:                ;; offset=0x093E
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       test     eax, eax
       jl       G_M000_IG38
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_HasSharedRecordKeys():bool:this]
       test     eax, eax
       je       G_M000_IG37
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x280], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x480], rax
       mov      rsi, gword ptr [rbp-0x480]
       mov      rdi, gword ptr [rbp-0x280]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:GetLookupCaches(Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntime+ExecutableLookupCache[]:this]
       mov      gword ptr [rbp-0xA0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LookupCacheIndex():int:this]
       mov      rcx, gword ptr [rbp-0xA0]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG120
       mov      edx, eax
       imul     rdx, rdx, 24
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x288], rcx
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x290], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x488], rax
       mov      r8, gword ptr [rbp-0x488]
       lea      r9, [rbp-0xA8]
       mov      rsi, gword ptr [rbp-0x98]
       mov      rdx, bword ptr [rbp-0x288]
       mov      rcx, gword ptr [rbp-0x290]
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryReadRecordValue(Lokad.Lython.Runtime.Text.PyString,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG36
       mov      rdi, 0x7828F09627FC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0xA8]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG36:                ;; offset=0x0A4E
       mov      rdi, 0x7828F0962800
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG38
 
G_M000_IG37:                ;; offset=0x0A5F
       mov      rdi, 0x7828F0962804
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG38:                ;; offset=0x0A6E
       mov      rdi, gword ptr [rbp-0x90]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:get_HasProtocolKeys():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG39
       mov      rdi, 0x7828F0962808
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG39:                ;; offset=0x0A95
       mov      rdi, 0x7828F096280C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x490], rax
       mov      rdx, gword ptr [rbp-0x490]
       mov      rax, bword ptr [rbp-0x30]
       mov      rcx, gword ptr [rax+0x18]
       mov      rsi, gword ptr [rbp-0x98]
       mov      rdi, gword ptr [rbp-0x90]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadSubscriptValue(System.Object,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x498], rax
       mov      rdx, gword ptr [rbp-0x498]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG40:                ;; offset=0x0AF9
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x49C], eax
       mov      esi, dword ptr [rbp-0x49C]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xB0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_UnaryOperator():int:this]
       test     eax, eax
       je       G_M000_IG43
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, 0x7828F0641F78
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG42
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, 0x7828EF0B6558
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG41
       mov      rdi, 0x7828F0962810
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdi, 0x7828EF0835C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x1D4], eax
       jmp      SHORT G_M000_IG44
 
G_M000_IG41:                ;; offset=0x0BA3
       mov      rdi, 0x7828F0962814
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG42:                ;; offset=0x0BB2
       xor      eax, eax
       mov      dword ptr [rbp-0x1D4], eax
       jmp      SHORT G_M000_IG44
 
G_M000_IG43:                ;; offset=0x0BBC
       mov      rdi, 0x7828F0962818
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x1D4], eax
 
G_M000_IG44:                ;; offset=0x0BE6
       cmp      dword ptr [rbp-0x1D4], 0
       je       SHORT G_M000_IG45
       mov      rdi, 0x7828F096281C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG45:                ;; offset=0x0C03
       mov      rdi, 0x7828F0962820
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_UnaryOperator():int:this]
       mov      dword ptr [rbp-0x1D8], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1E0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4A8], rax
       mov      rcx, gword ptr [rbp-0x4A8]
       mov      rsi, gword ptr [rbp-0xB0]
       mov      rdx, gword ptr [rbp-0x1E0]
       mov      edi, dword ptr [rbp-0x1D8]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateExecutableUnary(int,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x4B0], rax
       mov      rdx, gword ptr [rbp-0x4B0]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG46:                ;; offset=0x0C84
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4B4], eax
       mov      esi, dword ptr [rbp-0x4B4]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xB8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x4B8], eax
       mov      esi, dword ptr [rbp-0x4B8]
       mov      rdi, bword ptr [rbp-0x30]
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xC0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 48
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0xC4], eax
       cmp      dword ptr [rbp-0xC4], 0
       jne      G_M000_IG49
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x258], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rax+0x48]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdx, qword ptr [rax+0x50]
       mov      rdi, 0x7828EFFFB4D0
       call     [System.Span`1[System.__Canon]:op_Implicit(System.Span`1[System.__Canon]):System.ReadOnlySpan`1[System.__Canon]]
       mov      bword ptr [rbp-0x250], rax
       mov      qword ptr [rbp-0x248], rdx
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rsp], rax
       lea      rax, [rbp-0xD0]
       mov      qword ptr [rsp+0x08], rax
       lea      rax, [rbp-0xD8]
       mov      qword ptr [rsp+0x10], rax
       mov      rsi, bword ptr [rbp-0x250]
       mov      rdx, qword ptr [rbp-0x248]
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rax+0x38]
       mov      rdi, gword ptr [rbp-0x258]
       mov      r8, gword ptr [rbp-0xB8]
       mov      r9, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryIntegerChain(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[System.Object],int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,byref):bool]
       test     eax, eax
       je       G_M000_IG48
       mov      rdi, 0x7828F0962824
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0xD0]
       mov      dword ptr [rax+0x38], ecx
 
G_M000_IG47:                ;; offset=0x0DB4
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0xD0]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG120
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x270], rax
       mov      rdi, qword ptr [rbp-0xD8]
       call     [System.Numerics.BigInteger:op_Implicit(long):System.Numerics.BigInteger]
       mov      gword ptr [rbp-0x268], rax
       mov      qword ptr [rbp-0x260], rdx
       lea      rsi, [rbp-0x268]
       mov      rdi, 0x7828F0641F78
       call     [CORINFO_HELP_BOX]
       mov      gword ptr [rbp-0x4C0], rax
       mov      rdx, gword ptr [rbp-0x4C0]
       mov      rsi, bword ptr [rbp-0x270]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG48:                ;; offset=0x0E3B
       mov      rdi, 0x7828F0962828
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG49:                ;; offset=0x0E4A
       cmp      dword ptr [rbp-0xC4], 0
       jne      G_M000_IG51
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x234], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x240], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4C8], rax
       mov      r8, gword ptr [rbp-0x4C8]
       lea      r9, [rbp-0xE0]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, gword ptr [rbp-0x240]
       mov      edi, dword ptr [rbp-0x234]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG50
       mov      rdi, 0x7828F096282C
       call     CORINFO_HELP_COUNTPROFILE32
       movzx    rdi, byte  ptr [rbp-0xE0]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(bool):System.Object]
       mov      gword ptr [rbp-0x4D0], rax
       mov      rdx, gword ptr [rbp-0x4D0]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG50:                ;; offset=0x0EF8
       mov      rdi, 0x7828F0962830
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG51:                ;; offset=0x0F07
       cmp      dword ptr [rbp-0xC4], 0
       jne      SHORT G_M000_IG52
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x1E4], eax
       jmp      SHORT G_M000_IG53
 
G_M000_IG52:                ;; offset=0x0F22
       mov      rdi, 0x7828F0962834
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_AugmentedOperator():int:this]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.LythonRuntime:AugmentedBinaryOperator(int):int]
       mov      dword ptr [rbp-0x1E4], eax
 
G_M000_IG53:                ;; offset=0x0F49
       mov      edi, dword ptr [rbp-0x1E4]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdx, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeBinary(int,System.Object,System.Object):bool]
       test     eax, eax
       jne      SHORT G_M000_IG54
       mov      rdi, 0x7828F0962838
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG54:                ;; offset=0x0F7B
       cmp      dword ptr [rbp-0xC4], 0
       je       G_M000_IG63
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, 0x7828F0641F78
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG56
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, 0x7828EF0B6558
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG62
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, 0x7828EF0835C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       G_M000_IG61
 
G_M000_IG55:                ;; offset=0x0FE4
       mov      rdi, 0x7828F096283C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG56:                ;; offset=0x0FF3
       mov      rsi, gword ptr [rbp-0xC0]
       mov      rdi, 0x7828F0641F78
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG60
       mov      rsi, gword ptr [rbp-0xC0]
       mov      rdi, 0x7828EF0B6558
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG59
       mov      rsi, gword ptr [rbp-0xC0]
       mov      rdi, 0x7828EF0835C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG58
 
G_M000_IG57:                ;; offset=0x1047
       mov      rdi, 0x7828F0962840
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG58:                ;; offset=0x105B
       mov      rdi, 0x7828F0962844
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG63
 
G_M000_IG59:                ;; offset=0x106C
       mov      rdi, 0x7828F0962848
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG63
 
G_M000_IG60:                ;; offset=0x107D
       mov      rdi, 0x7828F096284C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG63
 
G_M000_IG61:                ;; offset=0x108E
       mov      rdi, 0x7828F0962850
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG57
 
G_M000_IG62:                ;; offset=0x109F
       mov      rdi, 0x7828F0962854
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG56
 
G_M000_IG63:                ;; offset=0x10B3
       mov      rax, bword ptr [rbp-0x30]
       mov      bword ptr [rbp-0x1F0], rax
       mov      rax, bword ptr [rbp-0x40]
       mov      bword ptr [rbp-0x1F8], rax
       cmp      dword ptr [rbp-0xC4], 0
       jne      G_M000_IG64
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x224], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x230], rax
       mov      rax, bword ptr [rbp-0x1F0]
       mov      bword ptr [rbp-0x210], rax
       mov      rax, bword ptr [rbp-0x1F8]
       mov      bword ptr [rbp-0x218], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4D8], rax
       mov      r8, gword ptr [rbp-0x4D8]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, gword ptr [rbp-0x230]
       mov      edi, dword ptr [rbp-0x224]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateBinaryOperator(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x220], rax
       jmp      G_M000_IG65
 
G_M000_IG64:                ;; offset=0x1156
       mov      rdi, 0x7828F0962858
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_AugmentedOperator():int:this]
       mov      dword ptr [rbp-0x1FC], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x208], rax
       mov      rax, bword ptr [rbp-0x1F0]
       mov      bword ptr [rbp-0x210], rax
       mov      rax, bword ptr [rbp-0x1F8]
       mov      bword ptr [rbp-0x218], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4E0], rax
       mov      r8, gword ptr [rbp-0x4E0]
       mov      rsi, gword ptr [rbp-0xC0]
       mov      edx, dword ptr [rbp-0x1FC]
       mov      rcx, gword ptr [rbp-0x208]
       mov      rdi, gword ptr [rbp-0xB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateAugmentedBuiltin(System.Object,System.Object,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x220], rax
 
G_M000_IG65:                ;; offset=0x11E0
       mov      rdi, 0x7828F096285C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x210]
       mov      rsi, bword ptr [rbp-0x218]
       mov      rdx, gword ptr [rbp-0x220]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG66:                ;; offset=0x120F
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4E4], eax
       mov      esi, dword ptr [rbp-0x4E4]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xE8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x4E8], eax
       mov      esi, dword ptr [rbp-0x4E8]
       mov      rdi, bword ptr [rbp-0x30]
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0xF0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      dword ptr [rbp-0x1B8], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x4F0], rax
       mov      r8, gword ptr [rbp-0x4F0]
       lea      r9, [rbp-0xF8]
       mov      rsi, gword ptr [rbp-0xE8]
       mov      rdx, gword ptr [rbp-0xF0]
       mov      rcx, gword ptr [rbp-0x1C0]
       mov      edi, dword ptr [rbp-0x1B8]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG67
       mov      rdi, 0x7828F0962860
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG67:                ;; offset=0x12DB
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x4F4], eax
       mov      esi, dword ptr [rbp-0x4F4]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x500], rax
       mov      rsi, gword ptr [rbp-0x500]
       mov      rdi, gword ptr [rbp-0x1C8]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       movzx    rax, byte  ptr [rbp-0xF8]
       test     eax, eax
       jne      SHORT G_M000_IG68
       mov      rdi, 0x7828F0962864
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x38], eax
       jmp      G_M000_IG115
 
G_M000_IG68:                ;; offset=0x1361
       mov      rdi, 0x7828F0962868
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG114
 
G_M000_IG69:                ;; offset=0x1375
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x504], eax
       mov      esi, dword ptr [rbp-0x504]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x100], rax
       mov      rdi, gword ptr [rbp-0x100]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       jne      SHORT G_M000_IG70
       mov      rdi, 0x7828F096286C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG70:                ;; offset=0x13C3
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x510], rax
       mov      rdx, gword ptr [rbp-0x510]
       mov      rsi, gword ptr [rbp-0x1D0]
       mov      rdi, gword ptr [rbp-0x100]
       call     [Lokad.Lython.Runtime.LythonRuntime:IsTruthy(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG71
       mov      rdi, 0x7828F0962870
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x38], eax
       jmp      G_M000_IG115
 
G_M000_IG71:                ;; offset=0x1435
       mov      rdi, 0x7828F0962874
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG114
 
G_M000_IG72:                ;; offset=0x1449
       mov      rdi, 0x7828F0962878
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x38], eax
       jmp      G_M000_IG115
 
G_M000_IG73:                ;; offset=0x146E
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DiscardIterator():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG74
       mov      rdi, 0x7828F096287C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      eax, dword ptr [rax+0x3C]
       lea      esi, [rax-0x01]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG74:                ;; offset=0x149F
       mov      rdi, 0x7828F0962880
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x38], eax
       jmp      G_M000_IG115
 
G_M000_IG75:                ;; offset=0x14C4
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x514], eax
       mov      esi, dword ptr [rbp-0x514]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x108], rax
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7828F093C228
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG76
       mov      rdi, 0x7828F0962884
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0x108]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG76:                ;; offset=0x1532
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7828F0833E58
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG78
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7828F04A8090
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG83
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7828F0927C00
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG82
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7828F04AB920
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      G_M000_IG81
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7828F04A75E0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG80
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7828F082EFC8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG79
       mov      rsi, gword ptr [rbp-0x108]
       mov      rdi, 0x7828F08E26A8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG84
 
G_M000_IG77:                ;; offset=0x1606
       mov      rdi, 0x7828F0962888
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG78:                ;; offset=0x1615
       mov      dword ptr [rbp-0x10C], 1
       jmp      SHORT G_M000_IG85
 
G_M000_IG79:                ;; offset=0x1621
       mov      rdi, 0x7828F096288C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG78
 
G_M000_IG80:                ;; offset=0x1632
       mov      rdi, 0x7828F0962890
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG78
 
G_M000_IG81:                ;; offset=0x1643
       mov      rdi, 0x7828F0962894
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG78
 
G_M000_IG82:                ;; offset=0x1654
       mov      rdi, 0x7828F0962898
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG78
 
G_M000_IG83:                ;; offset=0x1665
       mov      rdi, 0x7828F096289C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG78
 
G_M000_IG84:                ;; offset=0x1676
       mov      rdi, 0x7828F09628A0
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x10C], eax
 
G_M000_IG85:                ;; offset=0x168D
       cmp      dword ptr [rbp-0x10C], 0
       je       SHORT G_M000_IG86
       mov      rdi, 0x7828F09628A4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x520], rax
       mov      rsi, gword ptr [rbp-0x520]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdx, gword ptr [rax+0x18]
       mov      rdi, gword ptr [rbp-0x108]
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:Create(System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyIteration+Cursor]
       mov      gword ptr [rbp-0x528], rax
       mov      rdx, gword ptr [rbp-0x528]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG86:                ;; offset=0x16F3
       mov      rdi, 0x7828F09628A8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG108
 
G_M000_IG87:                ;; offset=0x1707
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 72
       mov      bword ptr [rbp-0x298], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x29C], eax
       mov      rax, bword ptr [rbp-0x298]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x29C], eax
       jae      G_M000_IG120
       mov      rax, bword ptr [rbp-0x298]
       mov      rax, bword ptr [rax]
       mov      ecx, dword ptr [rbp-0x29C]
       mov      rax, gword ptr [rax+8*rcx]
       mov      gword ptr [rbp-0x118], rax
       mov      rsi, gword ptr [rbp-0x118]
       mov      rdi, 0x7828F093C228
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x130], rax
       cmp      gword ptr [rbp-0x130], 0
       jne      G_M000_IG93
       mov      rsi, gword ptr [rbp-0x118]
       mov      rdi, 0x7828F0831118
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x530], rax
       mov      rdi, gword ptr [rbp-0x530]
       lea      rsi, [rbp-0x138]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:TryMoveNext(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG90
       call     [Lokad.Lython.Runtime.PyIterationResult:get_End():Lokad.Lython.Runtime.PyIterationResult]
       mov      gword ptr [rbp-0x2E0], rax
       mov      qword ptr [rbp-0x2D8], rdx
 
G_M000_IG88:                ;; offset=0x17D5
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2E0]
       vmovdqu32 xmmword ptr [rbp-0x2C0], xmm0
 
G_M000_IG89:                ;; offset=0x17E3
       jmp      SHORT G_M000_IG95
 
G_M000_IG90:                ;; offset=0x17E5
       mov      rdi, 0x7828F09628AC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x138]
       call     [Lokad.Lython.Runtime.PyIterationResult:Yield(System.Object):Lokad.Lython.Runtime.PyIterationResult]
       mov      gword ptr [rbp-0x2D0], rax
       mov      qword ptr [rbp-0x2C8], rdx
 
G_M000_IG91:                ;; offset=0x180F
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2D0]
       vmovdqu32 xmmword ptr [rbp-0x2C0], xmm0
 
G_M000_IG92:                ;; offset=0x181D
       jmp      SHORT G_M000_IG95
 
G_M000_IG93:                ;; offset=0x181F
       mov      rdi, 0x7828F09628B0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x130]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:MoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       mov      gword ptr [rbp-0x2B0], rax
       mov      qword ptr [rbp-0x2A8], rdx
 
G_M000_IG94:                ;; offset=0x184B
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2B0]
       vmovdqu32 xmmword ptr [rbp-0x2C0], xmm0
 
G_M000_IG95:                ;; offset=0x1859
       vmovdqu32 xmm0, xmmword ptr [rbp-0x2C0]
       vmovdqu  xmmword ptr [rbp-0x128], xmm0
 
G_M000_IG96:                ;; offset=0x1868
       lea      rdi, [rbp-0x128]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_HasValue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG97
       mov      rdi, 0x7828F09628B4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x534], eax
       mov      esi, dword ptr [rbp-0x534]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x38], eax
       jmp      G_M000_IG115
 
G_M000_IG97:                ;; offset=0x18BE
       mov      rdi, 0x7828F09628B8
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdi, [rbp-0x128]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_Value():System.Object:this]
       mov      gword ptr [rbp-0x540], rax
       mov      rdx, gword ptr [rbp-0x540]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG98:                ;; offset=0x18FB
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryReturnUnpackedTuple(byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG99
       mov      rdi, 0x7828F09628BC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG118
 
G_M000_IG99:                ;; offset=0x1921
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       test     eax, eax
       je       G_M000_IG100
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 72
       mov      bword ptr [rbp-0x2F0], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x2F4], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x544], eax
       mov      ecx, dword ptr [rbp-0x544]
       mov      rdi, bword ptr [rbp-0x2F0]
       mov      edx, dword ptr [rbp-0x2F4]
       mov      rsi, 0x7828EFFFB4D0
       call     [System.Span`1[System.__Canon]:Slice(int,int):System.Span`1[System.__Canon]:this]
       mov      bword ptr [rbp-0x308], rax
       mov      qword ptr [rbp-0x300], rdx
       mov      rsi, bword ptr [rbp-0x308]
       mov      rdx, qword ptr [rbp-0x300]
       mov      rdi, 0x7828EFFFB4D0
       call     [System.Span`1[System.__Canon]:op_Implicit(System.Span`1[System.__Canon]):System.ReadOnlySpan`1[System.__Canon]]
       mov      bword ptr [rbp-0x318], rax
       mov      qword ptr [rbp-0x310], rdx
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x320], rax
       mov      rdi, 0x7828F04A8090
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x328], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x550], rax
       mov      r8, gword ptr [rbp-0x550]
       mov      rax, bword ptr [rbp-0x30]
       mov      r9, gword ptr [rax+0x18]
       mov      rsi, bword ptr [rbp-0x318]
       mov      rdx, qword ptr [rbp-0x310]
       mov      rcx, gword ptr [rbp-0x320]
       mov      rdi, gword ptr [rbp-0x328]
       call     [Lokad.Lython.Runtime.PyTuple:.ctor(System.ReadOnlySpan`1[System.Object],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):this]
       mov      rax, gword ptr [rbp-0x328]
       mov      gword ptr [rbp-0x2E8], rax
       jmp      SHORT G_M000_IG101
 
G_M000_IG100:                ;; offset=0x1A44
       mov      rdi, 0x7828F09628C0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, 0x782111801968
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x2E8], rax
 
G_M000_IG101:                ;; offset=0x1A67
       mov      rdi, 0x7828F09628C4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x2E8]
       mov      gword ptr [rbp-0x140], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x554], eax
       mov      esi, dword ptr [rbp-0x554]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdx, gword ptr [rbp-0x140]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG102:                ;; offset=0x1ABE
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.PyList:EstimateCapacityBytes(int):long]
       mov      qword ptr [rbp-0x148], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x330], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x560], rax
       mov      rdx, gword ptr [rbp-0x560]
       mov      rsi, qword ptr [rbp-0x148]
       mov      rdi, gword ptr [rbp-0x330]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.MemoryGovernor:ReserveTemporary(long,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:this]
       mov      gword ptr [rbp-0x150], rax
 
G_M000_IG103:                ;; offset=0x1B23
       mov      rdi, 0x7828F09628C8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x338], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x568], rax
       mov      rsi, gword ptr [rbp-0x568]
       mov      rdi, gword ptr [rbp-0x338]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 72
       mov      bword ptr [rbp-0x340], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x344], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x56C], eax
       mov      ecx, dword ptr [rbp-0x56C]
       mov      rdi, bword ptr [rbp-0x340]
       mov      edx, dword ptr [rbp-0x344]
       mov      rsi, 0x7828EFFFB4D0
       call     [System.Span`1[System.__Canon]:Slice(int,int):System.Span`1[System.__Canon]:this]
       mov      bword ptr [rbp-0x358], rax
       mov      qword ptr [rbp-0x350], rdx
 
G_M000_IG104:                ;; offset=0x1BCE
       vmovdqu  xmm0, xmmword ptr [rbp-0x358]
       vmovdqu  xmmword ptr [rbp-0x168], xmm0
 
G_M000_IG105:                ;; offset=0x1BDE
       lea      rdi, [rbp-0x168]
       mov      rsi, 0x7828EFFFB4D0
       call     [System.Span`1[System.__Canon]:ToArray():System.__Canon[]:this]
       mov      gword ptr [rbp-0x158], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x570], eax
       mov      esi, dword ptr [rbp-0x570]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, gword ptr [rbp-0x150]
       mov      rsi, qword ptr [rbp-0x148]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:Commit(long):this]
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x360], rax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x578], rax
       mov      rdx, gword ptr [rbp-0x578]
       mov      rsi, gword ptr [rbp-0x360]
       mov      rdi, gword ptr [rbp-0x158]
       call     [Lokad.Lython.Runtime.PyList:FromTransferredArray(System.Object[],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x580], rax
       mov      rdx, gword ptr [rbp-0x580]
       mov      rsi, bword ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       nop      
 
G_M000_IG106:                ;; offset=0x1C92
       call     G_M000_IG121
       jmp      G_M000_IG114
 
G_M000_IG107:                ;; offset=0x1C9C
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Format(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG110
       mov      rdi, 0x7828F09629DC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG108:                ;; offset=0x1CBD
       xor      eax, eax
 
G_M000_IG109:                ;; offset=0x1CBF
       add      rsp, 0x5D0
       pop      rbp
       ret      
 
G_M000_IG110:                ;; offset=0x1CC8
       mov      rdi, 0x7828F09629E0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG114
 
G_M000_IG111:                ;; offset=0x1CDC
       mov      rdi, 0x7828F09629E4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x364], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x368], eax
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x58C], eax
       mov      esi, dword ptr [rbp-0x58C]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      gword ptr [rbp-0x598], rax
       mov      rcx, gword ptr [rbp-0x598]
       mov      esi, dword ptr [rbp-0x364]
       mov      edx, dword ptr [rbp-0x368]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       jmp      G_M000_IG114
 
G_M000_IG112:                ;; offset=0x1D58
       mov      rdi, 0x7828F09629E8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x59C], eax
       mov      esi, dword ptr [rbp-0x59C]
       mov      rdi, bword ptr [rbp-0x30]
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x5A0], eax
       mov      esi, dword ptr [rbp-0x5A0]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG114
 
G_M000_IG113:                ;; offset=0x1DAE
       lea      rdi, [rbp-0x190]
       mov      esi, 26
       mov      edx, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
       lea      rdi, [rbp-0x190]
       mov      rsi, 0x7828EC25C048
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendLiteral(System.String):this]
       mov      rdi, bword ptr [rbp-0x40]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0x5A4], eax
       mov      esi, dword ptr [rbp-0x5A4]
       lea      rdi, [rbp-0x190]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rdi, 0x7828EF797A68
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x388], rax
       lea      rdi, [rbp-0x190]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      gword ptr [rbp-0x5B0], rax
       mov      rsi, gword ptr [rbp-0x5B0]
       mov      rdi, gword ptr [rbp-0x388]
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, gword ptr [rbp-0x388]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG114:                ;; offset=0x1E4A
       mov      rdi, 0x7828F09629EC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       inc      dword ptr [rax+0x38]
 
G_M000_IG115:                ;; offset=0x1E60
       mov      eax, dword ptr [rbp-0x3E4]
       dec      eax
       mov      dword ptr [rbp-0x3E4], eax
       cmp      dword ptr [rbp-0x3E4], 0
       jg       SHORT G_M000_IG117
 
G_M000_IG116:                ;; offset=0x1E77
       lea      rdi, [rbp-0x3E4]
       mov      esi, 0x96A
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG117:                ;; offset=0x1E8A
       mov      rax, bword ptr [rbp-0x30]
       mov      eax, dword ptr [rax+0x38]
       mov      dword ptr [rbp-0x194], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x08]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x194]
       jg       G_M000_IG03
       mov      rdi, 0x7828F09629F0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG118:                ;; offset=0x1EC5
       mov      eax, 1
 
G_M000_IG119:                ;; offset=0x1ECA
       add      rsp, 0x5D0
       pop      rbp
       ret      
 
G_M000_IG120:                ;; offset=0x1ED3
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG121:                ;; offset=0x1ED9
       sub      rsp, 24
 
G_M000_IG122:                ;; offset=0x1EDD
       cmp      gword ptr [rbp-0x150], 0
       je       SHORT G_M000_IG123
       mov      rdi, 0x7828F09628CC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x150]
       mov      gword ptr [rbp-0x3E0], rax
       mov      rdi, gword ptr [rbp-0x3E0]
       mov      rsi, 0x7828F09628D0
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x3E0]
       mov      gword ptr [rbp-0x588], rax
       mov      rdi, gword ptr [rbp-0x588]
       mov      r11, 0x7828EDE62D60
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG123:                ;; offset=0x1F3C
       mov      rdi, 0x7828F09629D8
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG124:                ;; offset=0x1F4C
       add      rsp, 24
       ret      
 
RWD00  	dd	0000023Fh ; case G_M000_IG11
       	dd	000002DCh ; case G_M000_IG12
       	dd	0000041Bh ; case G_M000_IG14
       	dd	00000344h ; case G_M000_IG13
RWD16  	dd	00000607h ; case G_M000_IG24
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00000580h ; case G_M000_IG23
       	dd	000004EFh ; case G_M000_IG19
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001C99h ; case G_M000_IG111
       	dd	00001D15h ; case G_M000_IG112
       	dd	00001A7Bh ; case G_M000_IG102
       	dd	000018B8h ; case G_M000_IG98
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001481h ; case G_M000_IG75
       	dd	000016C4h ; case G_M000_IG87
       	dd	000007D5h ; case G_M000_IG29
       	dd	0000080Fh ; case G_M000_IG31
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00000C41h ; case G_M000_IG46
       	dd	00000C41h ; case G_M000_IG46
       	dd	00000AB6h ; case G_M000_IG40
       	dd	00001406h ; case G_M000_IG72
       	dd	00001332h ; case G_M000_IG69
       	dd	000011CCh ; case G_M000_IG66
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	0000014Fh ; case G_M000_IG09
       	dd	00000115h ; case G_M000_IG08
       	dd	00000115h ; case G_M000_IG08
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	00001D6Bh ; case G_M000_IG113
       	dd	0000142Bh ; case G_M000_IG73
       	dd	00001C59h ; case G_M000_IG107
       	dd	00001C59h ; case G_M000_IG107
       	dd	00001C59h ; case G_M000_IG107
       	dd	00001C59h ; case G_M000_IG107
       	dd	00001C59h ; case G_M000_IG107

; Total bytes of code 8017

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:RunCore(byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 47192
; 152 inlinees with PGO data; 291 single block inlinees; 20 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 680
       lea      rbp, [rsp+0x2D0]
       xor      eax, eax
       mov      qword ptr [rbp-0x2B8], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqa32 xmmword ptr [rbp-0x2B0], xmm8
       mov      rax, -624
 
G_M000_IG517:                ;; offset=0x0038
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG517
       mov      qword ptr [rbp-0x30], rax
       mov      rbx, rdi
       mov      r15, rsi
 
G_M000_IG02:                ;; offset=0x005A
       mov      rdi, 0x782111801A70
       mov      rsi, gword ptr [rdi]
       mov      rdi, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      edi, dword ptr [rbx+0x38]
       mov      rax, gword ptr [rbx+0x08]
       mov      rax, gword ptr [rax+0x50]
       cmp      edi, dword ptr [rax+0x08]
       jge      G_M000_IG142
       jmp      G_M000_IG106
 
G_M000_IG03:                ;; offset=0x0088
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x10]
       mov      r11, 0x7828EF0827A0
       cmp      qword ptr [rdi], r11
       jne      G_M000_IG459
       not      esi
       mov      r12d, dword ptr [rdi+0x08]
       cmp      r12d, esi
       jbe      G_M000_IG494
       cmp      esi, r12d
       jae      G_M000_IG509
       mov      rdi, gword ptr [rdi+8*rsi+0x10]
 
G_M000_IG04:                ;; offset=0x00C0
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r13, rax
       jmp      G_M000_IG131
 
G_M000_IG05:                ;; offset=0x00CE
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x10]
       mov      r11, 0x7828EF0827A0
       cmp      qword ptr [rdi], r11
       jne      G_M000_IG418
       not      esi
       mov      r12d, dword ptr [rdi+0x08]
       cmp      r12d, esi
       jbe      G_M000_IG494
       cmp      esi, r12d
       jae      G_M000_IG509
       mov      rdi, gword ptr [rdi+8*rsi+0x10]
 
G_M000_IG06:                ;; offset=0x0106
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r13, rax
       jmp      G_M000_IG111
 
G_M000_IG07:                ;; offset=0x0114
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x10]
       mov      r11, 0x7828EF0827A0
       cmp      qword ptr [rdi], r11
       jne      G_M000_IG421
       not      esi
       cmp      dword ptr [rdi+0x08], esi
       jbe      G_M000_IG494
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG509
       mov      rdi, gword ptr [rdi+8*rsi+0x10]
 
G_M000_IG08:                ;; offset=0x0148
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r12, rax
       jmp      G_M000_IG113
 
G_M000_IG09:                ;; offset=0x0156
       movzx    rdi, byte  ptr [rbp-0x58]
       test     edi, edi
       jne      SHORT G_M000_IG19
 
G_M000_IG10:                ;; offset=0x015F
       mov      rdi, 0x782111803118
       mov      r13, gword ptr [rdi]
 
G_M000_IG11:                ;; offset=0x016C
       cmp      dword ptr [r14+0x18], 0
       jl       SHORT G_M000_IG21
 
G_M000_IG12:                ;; offset=0x0173
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x017C
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG434
 
G_M000_IG14:                ;; offset=0x0190
       mov      r12d, dword ptr [r14+0x14]
 
G_M000_IG15:                ;; offset=0x0194
       cmp      dword ptr [r14+0x18], 0
       jl       SHORT G_M000_IG20
 
G_M000_IG16:                ;; offset=0x019B
       mov      r14d, dword ptr [r14+0x18]
 
G_M000_IG17:                ;; offset=0x019F
       cmp      r14d, dword ptr [rbx+0x3C]
       jl       G_M000_IG435
 
G_M000_IG18:                ;; offset=0x01A9
       lea      rdi, bword ptr [rbx+0x48]
       cmp      r12d, dword ptr [rdi+0x08]
       jae      G_M000_IG509
       mov      rdi, bword ptr [rdi]
       mov      esi, r12d
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, r13
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbx+0x3C], r14d
       jmp      G_M000_IG104
 
G_M000_IG19:                ;; offset=0x01D2
       mov      rdi, 0x782111803110
       mov      r13, gword ptr [rdi]
       jmp      SHORT G_M000_IG11
 
G_M000_IG20:                ;; offset=0x01E1
       mov      edi, dword ptr [r14+0x18]
       mov      r14d, edi
       not      r14d
       jmp      SHORT G_M000_IG17
 
G_M000_IG21:                ;; offset=0x01ED
       mov      edi, dword ptr [r14+0x18]
       not      edi
       cmp      edi, dword ptr [rbx+0x3C]
       jge      SHORT G_M000_IG23
 
G_M000_IG22:                ;; offset=0x01F8
       mov      edi, dword ptr [r14+0x18]
       mov      esi, edi
       not      esi
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG23:                ;; offset=0x0209
       lea      r12, bword ptr [rbx+0x48]
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x0216
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG436
 
G_M000_IG25:                ;; offset=0x022A
       mov      eax, dword ptr [r14+0x14]
 
G_M000_IG26:                ;; offset=0x022E
       cmp      eax, dword ptr [r12+0x08]
       jae      G_M000_IG509
       mov      rdi, bword ptr [r12]
       mov      eax, eax
       xor      rcx, rcx
       mov      gword ptr [rdi+8*rax], rcx
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG28
 
G_M000_IG27:                ;; offset=0x024E
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG437
 
G_M000_IG28:                ;; offset=0x0262
       mov      eax, dword ptr [r14+0x14]
 
G_M000_IG29:                ;; offset=0x0266
       mov      dword ptr [rbx+0x3C], eax
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x50]
       mov      eax, dword ptr [rbx+0x38]
       inc      eax
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG509
       shl      rax, 5
       lea      r12, bword ptr [rdi+rax+0x10]
       mov      rdi, gword ptr [rbx+0x18]
       mov      rax, gword ptr [r12]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      rcx, gword ptr [rdi+0x88]
       mov      rcx, gword ptr [rcx+0x20]
       test     rcx, rcx
       jne      G_M000_IG438
       mov      rdi, gword ptr [rdi+0x178]
       test     rdi, rdi
       jne      G_M000_IG439
 
G_M000_IG30:                ;; offset=0x02BB
       lea      rdi, bword ptr [rbx+0x48]
       mov      esi, dword ptr [r12+0x1C]
       cmp      esi, 4
       je       SHORT G_M000_IG32
 
G_M000_IG31:                ;; offset=0x02C9
       cmp      esi, 27
       jne      G_M000_IG440
 
G_M000_IG32:                ;; offset=0x02D2
       mov      esi, dword ptr [r12+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG509
       mov      rdi, bword ptr [rdi]
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, r13
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG254
 
G_M000_IG33:                ;; offset=0x02F4
       mov      edi, dword ptr [rbp-0x48]
       mov      dword ptr [rbx+0x38], edi
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x50]
       mov      esi, dword ptr [rdi+0x08]
       cmp      dword ptr [rbp-0x48], esi
       jae      G_M000_IG509
       mov      esi, dword ptr [rbp-0x48]
       shl      rsi, 5
       lea      r14, bword ptr [rdi+rsi+0x10]
       mov      rsi, qword ptr [rbp-0x50]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu32 xmmword ptr [rbp-0x110], xmm0
       lea      rdi, [rbp-0x110]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rdi, 0x7828F0641F78
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
       lea      rdi, bword ptr [r12+0x08]
       mov      rsi, gword ptr [rbp-0x110]
       call     CORINFO_HELP_ASSIGN_REF
       mov      edi, dword ptr [rbp-0x108]
       mov      dword ptr [r12+0x10], edi
       cmp      dword ptr [r14+0x18], 0
       jl       SHORT G_M000_IG42
 
G_M000_IG34:                ;; offset=0x036B
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG36
 
G_M000_IG35:                ;; offset=0x0374
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG424
 
G_M000_IG36:                ;; offset=0x0388
       mov      r13d, dword ptr [r14+0x14]
 
G_M000_IG37:                ;; offset=0x038C
       cmp      dword ptr [r14+0x18], 0
       jl       SHORT G_M000_IG41
 
G_M000_IG38:                ;; offset=0x0393
       mov      r14d, dword ptr [r14+0x18]
 
G_M000_IG39:                ;; offset=0x0397
       cmp      r14d, dword ptr [rbx+0x3C]
       jl       G_M000_IG425
 
G_M000_IG40:                ;; offset=0x03A1
       lea      rdi, bword ptr [rbx+0x48]
       cmp      r13d, dword ptr [rdi+0x08]
       jae      G_M000_IG509
       mov      rdi, bword ptr [rdi]
       mov      esi, r13d
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, r12
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbx+0x3C], r14d
       jmp      G_M000_IG104
 
G_M000_IG41:                ;; offset=0x03CA
       mov      edi, dword ptr [r14+0x18]
       mov      r14d, edi
       not      r14d
       jmp      SHORT G_M000_IG39
 
G_M000_IG42:                ;; offset=0x03D6
       mov      esi, dword ptr [r14+0x18]
       not      esi
       cmp      esi, dword ptr [rbx+0x3C]
       jge      G_M000_IG51
 
G_M000_IG43:                ;; offset=0x03E5
       mov      esi, dword ptr [r14+0x18]
       mov      r13d, esi
       not      r13d
       mov      esi, dword ptr [rbx+0x3C]
       dec      esi
       mov      rdi, gword ptr [rbx+0x08]
       mov      edi, dword ptr [rdi+0xA0]
       cmp      esi, edi
       jle      G_M000_IG144
 
G_M000_IG44:                ;; offset=0x0406
       mov      eax, edi
       cmp      eax, r13d
       jl       SHORT G_M000_IG50
 
G_M000_IG45:                ;; offset=0x040D
       lea      rsi, bword ptr [rbx+0x48]
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG509
       mov      rsi, bword ptr [rsi]
       mov      qword ptr [rbp-0x138], rax
       mov      rsi, gword ptr [rsi+8*rax]
       mov      rdi, rsi
       test     rdi, rdi
       je       SHORT G_M000_IG48
 
G_M000_IG46:                ;; offset=0x0430
       mov      rcx, 0x7828F04A75E0
       cmp      qword ptr [rdi], rcx
       jne      G_M000_IG426
 
G_M000_IG47:                ;; offset=0x0443
       xor      rdi, rdi
 
G_M000_IG48:                ;; offset=0x0445
       test     rdi, rdi
       jne      G_M000_IG427
 
G_M000_IG49:                ;; offset=0x044E
       mov      rax, qword ptr [rbp-0x138]
       dec      eax
       mov      rdi, rax
       cmp      edi, r13d
       mov      rax, rdi
       jge      SHORT G_M000_IG45
 
G_M000_IG50:                ;; offset=0x0462
       mov      dword ptr [rbx+0x3C], r13d
 
G_M000_IG51:                ;; offset=0x0466
       lea      r13, bword ptr [rbx+0x48]
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG53
 
G_M000_IG52:                ;; offset=0x0473
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG428
 
G_M000_IG53:                ;; offset=0x0487
       mov      eax, dword ptr [r14+0x14]
 
G_M000_IG54:                ;; offset=0x048B
       cmp      eax, dword ptr [r13+0x08]
       jae      G_M000_IG509
       mov      rdi, bword ptr [r13]
       mov      eax, eax
       xor      rcx, rcx
       mov      gword ptr [rdi+8*rax], rcx
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG56
 
G_M000_IG55:                ;; offset=0x04AA
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG429
 
G_M000_IG56:                ;; offset=0x04BE
       mov      eax, dword ptr [r14+0x14]
 
G_M000_IG57:                ;; offset=0x04C2
       mov      dword ptr [rbx+0x3C], eax
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x50]
       mov      eax, dword ptr [rbx+0x38]
       inc      eax
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG509
       shl      rax, 5
       lea      r14, bword ptr [rdi+rax+0x10]
       mov      rdi, gword ptr [rbx+0x18]
       mov      rax, gword ptr [r14]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      rcx, gword ptr [rdi+0x88]
       mov      rcx, gword ptr [rcx+0x20]
       test     rcx, rcx
       jne      G_M000_IG430
       mov      rdi, gword ptr [rdi+0x178]
       test     rdi, rdi
       jne      G_M000_IG431
 
G_M000_IG58:                ;; offset=0x0516
       lea      rdi, bword ptr [rbx+0x48]
       mov      esi, dword ptr [r14+0x1C]
       cmp      esi, 4
       je       SHORT G_M000_IG60
 
G_M000_IG59:                ;; offset=0x0523
       cmp      esi, 27
       jne      G_M000_IG432
 
G_M000_IG60:                ;; offset=0x052C
       mov      esi, dword ptr [r14+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG509
       mov      rdi, bword ptr [rdi]
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, r12
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG254
 
G_M000_IG61:                ;; offset=0x054D
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x10]
       mov      r11, 0x7828EF0827A0
       cmp      qword ptr [rdi], r11
       jne      G_M000_IG376
       not      esi
       mov      r12d, dword ptr [rdi+0x08]
       cmp      r12d, esi
       jbe      G_M000_IG494
       mov      rdi, gword ptr [rdi+8*rsi+0x10]
 
G_M000_IG62:                ;; offset=0x057C
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r13, rax
       jmp      G_M000_IG136
 
G_M000_IG63:                ;; offset=0x058A
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x10]
       mov      r11, 0x7828EF0827A0
       cmp      qword ptr [rdi], r11
       jne      G_M000_IG378
       not      esi
       mov      r11d, dword ptr [rdi+0x08]
       cmp      r11d, esi
       jbe      G_M000_IG494
       mov      rdi, gword ptr [rdi+8*rsi+0x10]
 
G_M000_IG64:                ;; offset=0x05B9
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r12, rax
       jmp      G_M000_IG138
 
G_M000_IG65:                ;; offset=0x05C7
       mov      rdi, 0x7828F082EFC8
       cmp      qword ptr [r13], rdi
       jne      G_M000_IG139
 
G_M000_IG66:                ;; offset=0x05DB
       cmp      gword ptr [r13+0x28], 0
       je       G_M000_IG380
       cmp      dword ptr [r13+0x50], 0
       jne      G_M000_IG139
 
G_M000_IG67:                ;; offset=0x05F1
       test     r12, r12
       je       G_M000_IG139
 
G_M000_IG68:                ;; offset=0x05FA
       mov      rdi, 0x7828F04A75E0
       cmp      qword ptr [r12], rdi
       jne      G_M000_IG139
 
G_M000_IG69:                ;; offset=0x060E
       cmp      dword ptr [r14+0x1C], 44
       jne      G_M000_IG381
       mov      edi, dword ptr [r14+0x08]
 
G_M000_IG70:                ;; offset=0x061D
       test     edi, edi
       jl       G_M000_IG396
       cmp      gword ptr [r13+0x20], 0
       je       G_M000_IG396
       mov      rax, gword ptr [rbx]
       mov      gword ptr [rbp-0x180], rax
       mov      rcx, gword ptr [r14]
       mov      gword ptr [rbp-0x240], rcx
       mov      rdx, gword ptr [rax+0x78]
       test     rdx, rdx
       je       G_M000_IG383
 
G_M000_IG71:                ;; offset=0x0651
       cmp      dword ptr [r14+0x1C], 44
       jne      G_M000_IG392
       mov      edi, dword ptr [r14+0x08]
 
G_M000_IG72:                ;; offset=0x0660
       cmp      edi, dword ptr [rdx+0x08]
       jae      G_M000_IG509
       mov      edi, edi
       lea      rdi, [rdi+2*rdi]
       lea      rax, bword ptr [rdx+8*rdi+0x10]
       mov      bword ptr [rbp-0x188], rax
       mov      rcx, gword ptr [rbx+0x18]
       mov      gword ptr [rbp-0x190], rcx
       mov      rdx, gword ptr [r14]
       mov      gword ptr [rbp-0x270], rdx
       mov      rdi, gword ptr [rcx+0xA0]
       mov      rsi, gword ptr [rdi+0x88]
       mov      rsi, gword ptr [rsi+0x20]
       test     rsi, rsi
       jne      G_M000_IG394
       mov      rcx, gword ptr [rbp-0x190]
       mov      rdi, gword ptr [rdi+0x178]
       test     rdi, rdi
       jne      G_M000_IG395
 
G_M000_IG73:                ;; offset=0x06C2
       mov      r8, gword ptr [r13+0x20]
       mov      gword ptr [rbp-0x278], r8
       test     r8, r8
       je       G_M000_IG396
       mov      rax, bword ptr [rbp-0x188]
       cmp      gword ptr [rax], r8
       jne      G_M000_IG398
 
G_M000_IG74:                ;; offset=0x06E6
       cmp      gword ptr [rax+0x08], r12
       jne      G_M000_IG397
       mov      r9d, dword ptr [rax+0x10]
 
G_M000_IG75:                ;; offset=0x06F4
       cmp      gword ptr [r13+0x20], 0
       je       SHORT G_M000_IG77
 
G_M000_IG76:                ;; offset=0x06FB
       mov      rdi, gword ptr [r13+0x30]
       cmp      dword ptr [rdi+0x08], r9d
       jbe      G_M000_IG399
       cmp      r9d, dword ptr [rdi+0x08]
       jae      G_M000_IG509
       mov      eax, r9d
       cmp      gword ptr [rdi+8*rax+0x10], 0
       je       G_M000_IG399
 
G_M000_IG77:                ;; offset=0x0722
       mov      rdi, gword ptr [r13+0x30]
       mov      rax, rdi
       cmp      r9d, dword ptr [rax+0x08]
       jae      G_M000_IG509
       mov      edi, r9d
       mov      rax, gword ptr [rax+8*rdi+0x10]
 
G_M000_IG78:                ;; offset=0x073B
       mov      gword ptr [rbp-0x160], rax
       test     rax, rax
       je       G_M000_IG396
       mov      r13, rax
       mov      r12d, dword ptr [r14+0x18]
       test     r12d, r12d
       jl       SHORT G_M000_IG86
 
G_M000_IG79:                ;; offset=0x0757
       mov      rax, gword ptr [rbp-0x160]
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG81
 
G_M000_IG80:                ;; offset=0x0767
       mov      rcx, 0xFFFFFFFFFE7FF
       bt       rcx, rdi
       jae      G_M000_IG400
 
G_M000_IG81:                ;; offset=0x077B
       mov      r12d, dword ptr [r14+0x14]
 
G_M000_IG82:                ;; offset=0x077F
       mov      r14d, dword ptr [r14+0x18]
       test     r14d, r14d
       jl       SHORT G_M000_IG85
 
G_M000_IG83:                ;; offset=0x0788
       cmp      r14d, dword ptr [rbx+0x3C]
       jl       G_M000_IG401
 
G_M000_IG84:                ;; offset=0x0792
       lea      rdi, bword ptr [rbx+0x48]
       cmp      r12d, dword ptr [rdi+0x08]
       jae      G_M000_IG509
       mov      rdi, bword ptr [rdi]
       mov      esi, r12d
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbx+0x3C], r14d
       jmp      G_M000_IG104
 
G_M000_IG85:                ;; offset=0x07BB
       not      r14d
       jmp      SHORT G_M000_IG83
 
G_M000_IG86:                ;; offset=0x07C0
       mov      esi, r12d
       not      esi
       cmp      esi, dword ptr [rbx+0x3C]
       jge      SHORT G_M000_IG93
 
G_M000_IG87:                ;; offset=0x07CA
       not      r12d
       mov      esi, dword ptr [rbx+0x3C]
       dec      esi
       mov      rdi, gword ptr [rbx+0x08]
       mov      edi, dword ptr [rdi+0xA0]
       cmp      esi, edi
       jle      G_M000_IG403
       jmp      G_M000_IG402
 
G_M000_IG88:                ;; offset=0x07E9
       mov      eax, edi
       cmp      eax, r12d
       jl       SHORT G_M000_IG92
 
G_M000_IG89:                ;; offset=0x07F0
       lea      rsi, bword ptr [rbx+0x48]
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG509
       mov      rsi, bword ptr [rsi]
       mov      qword ptr [rbp-0x140], rax
       mov      rsi, gword ptr [rsi+8*rax]
       mov      rdi, rsi
       test     rdi, rdi
       jne      G_M000_IG404
 
G_M000_IG90:                ;; offset=0x0817
       test     rdi, rdi
       jne      G_M000_IG407
 
G_M000_IG91:                ;; offset=0x0820
       mov      rax, qword ptr [rbp-0x140]
       dec      eax
       mov      rdi, rax
       cmp      edi, r12d
       mov      rax, rdi
       jge      SHORT G_M000_IG89
 
G_M000_IG92:                ;; offset=0x0834
       mov      dword ptr [rbx+0x3C], r12d
 
G_M000_IG93:                ;; offset=0x0838
       lea      r12, bword ptr [rbx+0x48]
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG95
 
G_M000_IG94:                ;; offset=0x0845
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG408
 
G_M000_IG95:                ;; offset=0x0859
       mov      eax, dword ptr [r14+0x14]
 
G_M000_IG96:                ;; offset=0x085D
       cmp      eax, dword ptr [r12+0x08]
       jae      G_M000_IG509
       mov      rdi, bword ptr [r12]
       mov      eax, eax
       xor      rcx, rcx
       mov      gword ptr [rdi+8*rax], rcx
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG98
 
G_M000_IG97:                ;; offset=0x087D
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG409
 
G_M000_IG98:                ;; offset=0x0891
       mov      eax, dword ptr [r14+0x14]
 
G_M000_IG99:                ;; offset=0x0895
       mov      dword ptr [rbx+0x3C], eax
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x50]
       mov      eax, dword ptr [rbx+0x38]
       inc      eax
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG509
       shl      rax, 5
       lea      r12, bword ptr [rdi+rax+0x10]
       mov      rdi, gword ptr [rbx+0x18]
       mov      rax, gword ptr [r12]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      rcx, gword ptr [rdi+0x88]
       mov      rcx, gword ptr [rcx+0x20]
       test     rcx, rcx
       jne      G_M000_IG410
       mov      rdi, gword ptr [rdi+0x178]
       test     rdi, rdi
       jne      G_M000_IG411
 
G_M000_IG100:                ;; offset=0x08EA
       lea      rdi, bword ptr [rbx+0x48]
       mov      esi, dword ptr [r12+0x1C]
       cmp      esi, 4
       je       SHORT G_M000_IG102
 
G_M000_IG101:                ;; offset=0x08F8
       cmp      esi, 27
       jne      G_M000_IG412
 
G_M000_IG102:                ;; offset=0x0901
       mov      esi, dword ptr [r12+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG509
       mov      rdi, bword ptr [rdi]
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, r13
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG254
 
G_M000_IG103:                ;; offset=0x0923
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this]
       test     eax, eax
       je       G_M000_IG139
 
G_M000_IG104:                ;; offset=0x0937
       inc      dword ptr [rbx+0x38]
 
G_M000_IG105:                ;; offset=0x093A
       mov      esi, dword ptr [rbx+0x38]
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x50]
       cmp      esi, dword ptr [rdi+0x08]
       jge      G_M000_IG142
 
G_M000_IG106:                ;; offset=0x094E
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x50]
       mov      eax, dword ptr [rbx+0x38]
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG509
       shl      rax, 5
       lea      r14, bword ptr [rdi+rax+0x10]
       mov      rdi, gword ptr [rbx+0x18]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      rax, gword ptr [r14]
       mov      rcx, gword ptr [rdi+0x88]
       mov      rcx, gword ptr [rcx+0x20]
       test     rcx, rcx
       jne      G_M000_IG489
       mov      rdi, gword ptr [rdi+0x178]
       test     rdi, rdi
       jne      G_M000_IG316
 
G_M000_IG107:                ;; offset=0x099D
       mov      edi, dword ptr [r14+0x1C]
       lea      r13d, [rdi-0x03]
       cmp      r13d, 3
       jbe      G_M000_IG177
 
G_M000_IG108:                ;; offset=0x09AF
       add      edi, -25
       cmp      edi, 43
       ja       G_M000_IG490
       lea      rsi, [reloc @RWD00]
       mov      esi, dword ptr [rsi+4*rdi]
       lea      rax, G_M000_IG02
       add      rsi, rax
       jmp      rsi
 
G_M000_IG109:                ;; offset=0x09D1
       mov      esi, dword ptr [r14+0x10]
       test     esi, esi
       jl       G_M000_IG05
 
G_M000_IG110:                ;; offset=0x09DD
       lea      rdi, bword ptr [rbx+0x48]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG509
       mov      rdi, bword ptr [rdi]
       mov      r11d, esi
       mov      r13, gword ptr [rdi+8*r11]
       test     r13, r13
       je       G_M000_IG419
 
G_M000_IG111:                ;; offset=0x09FD
       mov      esi, dword ptr [r14+0x0C]
       test     esi, esi
       jl       G_M000_IG07
 
G_M000_IG112:                ;; offset=0x0A09
       lea      rdi, bword ptr [rbx+0x48]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG509
       mov      rdi, bword ptr [rdi]
       mov      r11d, esi
       mov      r12, gword ptr [rdi+8*r11]
       test     r12, r12
       je       G_M000_IG422
 
G_M000_IG113:                ;; offset=0x0A29
       cmp      dword ptr [r14+0x1C], 48
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x3C], eax
       test     eax, eax
       jne      G_M000_IG442
 
G_M000_IG114:                ;; offset=0x0A3F
       mov      rdi, gword ptr [rbx+0x08]
       mov      rsi, bword ptr [rbx+0x48]
       mov      edx, dword ptr [rbx+0x50]
       mov      rcx, gword ptr [rbx+0x18]
       mov      gword ptr [rsp], rcx
       lea      rcx, [rbp-0x48]
       mov      qword ptr [rsp+0x08], rcx
       lea      rcx, [rbp-0x50]
       mov      qword ptr [rsp+0x10], rcx
       mov      ecx, dword ptr [rbx+0x38]
       mov      r8, r13
       mov      r9, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:TryIntegerChain(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[System.Object],int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,byref):bool]
       test     eax, eax
       jne      G_M000_IG33
 
G_M000_IG115:                ;; offset=0x0A7B
       cmp      dword ptr [r14+0x1C], 52
       je       G_M000_IG433
       mov      edi, dword ptr [r14+0x08]
 
G_M000_IG116:                ;; offset=0x0A8A
       mov      rcx, gword ptr [rbx+0x18]
       mov      r8, gword ptr [r14]
       lea      r9, [rbp-0x58]
       mov      rsi, r13
       mov      rdx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       jne      G_M000_IG09
 
G_M000_IG117:                ;; offset=0x0AA9
       cmp      dword ptr [r14+0x1C], 52
       je       G_M000_IG441
       mov      edi, dword ptr [r14+0x08]
 
G_M000_IG118:                ;; offset=0x0AB8
       mov      rsi, r13
       mov      rdx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeBinary(int,System.Object,System.Object):bool]
       test     eax, eax
       je       G_M000_IG139
       cmp      dword ptr [rbp-0x3C], 0
       jne      G_M000_IG443
       cmp      dword ptr [r14+0x1C], 52
       je       G_M000_IG445
       mov      edi, dword ptr [r14+0x08]
 
G_M000_IG119:                ;; offset=0x0AE5
       mov      rcx, gword ptr [rbx+0x18]
       mov      bword ptr [rbp-0x170], rbx
       mov      r9, r14
       mov      bword ptr [rbp-0x178], r9
       mov      r8, gword ptr [r9]
       mov      rsi, r13
       mov      rdx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateBinaryOperator(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      r12, rax
 
G_M000_IG120:                ;; offset=0x0B0C
       mov      r13, r12
       mov      rax, bword ptr [rbp-0x178]
       cmp      dword ptr [rax+0x18], 0
       jl       G_M000_IG146
 
G_M000_IG121:                ;; offset=0x0B20
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG123
 
G_M000_IG122:                ;; offset=0x0B29
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG447
 
G_M000_IG123:                ;; offset=0x0B3D
       mov      r13d, dword ptr [r14+0x14]
 
G_M000_IG124:                ;; offset=0x0B41
       cmp      dword ptr [r14+0x18], 0
       jl       G_M000_IG145
 
G_M000_IG125:                ;; offset=0x0B4C
       mov      r14d, dword ptr [r14+0x18]
 
G_M000_IG126:                ;; offset=0x0B50
       cmp      r14d, dword ptr [rbx+0x3C]
       jl       G_M000_IG448
 
G_M000_IG127:                ;; offset=0x0B5A
       lea      rdi, bword ptr [rbx+0x48]
       cmp      r13d, dword ptr [rdi+0x08]
       jae      G_M000_IG509
       mov      rdi, bword ptr [rdi]
       mov      esi, r13d
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, r12
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbx+0x3C], r14d
       jmp      G_M000_IG104
 
G_M000_IG128:                ;; offset=0x0B83
       mov      esi, dword ptr [r14+0x10]
       test     esi, esi
       jl       G_M000_IG03
 
G_M000_IG129:                ;; offset=0x0B8F
       lea      rdi, bword ptr [rbx+0x48]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG509
       mov      rdi, bword ptr [rdi]
       mov      eax, esi
       mov      rdi, gword ptr [rdi+8*rax]
       test     rdi, rdi
       je       G_M000_IG460
 
G_M000_IG130:                ;; offset=0x0BAE
       mov      rsi, rdi
       mov      rdi, 0x7828F0839E00
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r13, rax
 
G_M000_IG131:                ;; offset=0x0BC4
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       je       G_M000_IG139
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rdx, gword ptr [r14]
       mov      rsi, gword ptr [rbx+0x18]
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:IsTruthy(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      G_M000_IG104
 
G_M000_IG132:                ;; offset=0x0BF9
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      dword ptr [rbx+0x38], eax
       jmp      G_M000_IG105
 
G_M000_IG133:                ;; offset=0x0C0A
       mov      edi, esi
       jmp      G_M000_IG148
 
G_M000_IG134:                ;; offset=0x0C11
       mov      esi, dword ptr [r14+0x10]
       test     esi, esi
       jl       G_M000_IG61
 
G_M000_IG135:                ;; offset=0x0C1D
       lea      rdi, bword ptr [rbx+0x48]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG509
       mov      rdi, bword ptr [rdi]
       mov      r11d, esi
       mov      r13, gword ptr [rdi+8*r11]
       test     r13, r13
       je       G_M000_IG377
 
G_M000_IG136:                ;; offset=0x0C3D
       mov      esi, dword ptr [r14+0x0C]
       test     esi, esi
       jl       G_M000_IG63
 
G_M000_IG137:                ;; offset=0x0C49
       lea      rdi, bword ptr [rbx+0x48]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG509
       mov      rdi, bword ptr [rdi]
       mov      r11d, esi
       mov      r12, gword ptr [rdi+8*r11]
       test     r12, r12
       je       G_M000_IG379
 
G_M000_IG138:                ;; offset=0x0C69
       test     r13, r13
       jne      G_M000_IG65
 
G_M000_IG139:                ;; offset=0x0C72
       xor      eax, eax
 
G_M000_IG140:                ;; offset=0x0C74
       vzeroupper 
       add      rsp, 680
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG141:                ;; offset=0x0C89
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryReturnUnpackedTuple(byref):bool:this]
       test     eax, eax
       je       G_M000_IG470
 
G_M000_IG142:                ;; offset=0x0C9D
       mov      eax, 1
 
G_M000_IG143:                ;; offset=0x0CA2
       vzeroupper 
       add      rsp, 680
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG144:                ;; offset=0x0CB7
       mov      edi, esi
       jmp      G_M000_IG44
 
G_M000_IG145:                ;; offset=0x0CBE
       mov      edi, dword ptr [r14+0x18]
       mov      r14d, edi
       not      r14d
       jmp      G_M000_IG126
 
G_M000_IG146:                ;; offset=0x0CCD
       mov      esi, dword ptr [rax+0x18]
       not      esi
       mov      r14, bword ptr [rbp-0x170]
       cmp      esi, dword ptr [r14+0x3C]
       jge      G_M000_IG155
 
G_M000_IG147:                ;; offset=0x0CE3
       mov      bword ptr [rbp-0x178], rax
       mov      esi, dword ptr [rax+0x18]
       mov      r12d, esi
       not      r12d
       mov      esi, dword ptr [r14+0x3C]
       dec      esi
       mov      rdi, gword ptr [r14+0x08]
       mov      edi, dword ptr [rdi+0xA0]
       cmp      esi, edi
       jle      G_M000_IG133
 
G_M000_IG148:                ;; offset=0x0D0B
       mov      r14d, edi
       cmp      r14d, r12d
       jl       SHORT G_M000_IG154
 
G_M000_IG149:                ;; offset=0x0D13
       lea      rsi, bword ptr [rbx+0x48]
       cmp      r14d, dword ptr [rsi+0x08]
       jae      G_M000_IG509
       mov      rsi, bword ptr [rsi]
       mov      rsi, gword ptr [rsi+8*r14]
       mov      rdi, rsi
       test     rdi, rdi
       je       SHORT G_M000_IG152
 
G_M000_IG150:                ;; offset=0x0D30
       mov      rcx, 0x7828F04A75E0
       cmp      qword ptr [rdi], rcx
       jne      G_M000_IG449
 
G_M000_IG151:                ;; offset=0x0D43
       xor      rdi, rdi
 
G_M000_IG152:                ;; offset=0x0D45
       test     rdi, rdi
       jne      G_M000_IG450
 
G_M000_IG153:                ;; offset=0x0D4E
       dec      r14d
       cmp      r14d, r12d
       jge      SHORT G_M000_IG149
 
G_M000_IG154:                ;; offset=0x0D56
       mov      dword ptr [rbx+0x3C], r12d
       mov      rax, bword ptr [rbp-0x178]
 
G_M000_IG155:                ;; offset=0x0D61
       lea      r14, bword ptr [rbx+0x48]
       mov      edi, dword ptr [rax+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG157
 
G_M000_IG156:                ;; offset=0x0D6D
       mov      rcx, 0xFFFFFFFFFE7FF
       bt       rcx, rdi
       jae      G_M000_IG451
 
G_M000_IG157:                ;; offset=0x0D81
       mov      edi, dword ptr [rax+0x14]
 
G_M000_IG158:                ;; offset=0x0D84
       cmp      edi, dword ptr [r14+0x08]
       jae      G_M000_IG509
       mov      rcx, bword ptr [r14]
       mov      edi, edi
       xor      rdx, rdx
       mov      gword ptr [rcx+8*rdi], rdx
       mov      edi, dword ptr [rax+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG160
 
G_M000_IG159:                ;; offset=0x0DA1
       mov      rcx, 0xFFFFFFFFFE7FF
       bt       rcx, rdi
       jae      G_M000_IG452
 
G_M000_IG160:                ;; offset=0x0DB5
       mov      eax, dword ptr [rax+0x14]
 
G_M000_IG161:                ;; offset=0x0DB8
       mov      dword ptr [rbx+0x3C], eax
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x50]
       mov      eax, dword ptr [rbx+0x38]
       inc      eax
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG509
       shl      rax, 5
       lea      r14, bword ptr [rdi+rax+0x10]
       mov      rdi, gword ptr [rbx+0x18]
       mov      rax, gword ptr [r14]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      rcx, gword ptr [rdi+0x88]
       mov      rcx, gword ptr [rcx+0x20]
       test     rcx, rcx
       jne      G_M000_IG453
       mov      rdi, gword ptr [rdi+0x178]
       test     rdi, rdi
       jne      G_M000_IG454
 
G_M000_IG162:                ;; offset=0x0E0C
       lea      rdi, bword ptr [rbx+0x48]
       mov      esi, dword ptr [r14+0x1C]
       cmp      esi, 4
       je       SHORT G_M000_IG164
 
G_M000_IG163:                ;; offset=0x0E19
       cmp      esi, 27
       jne      G_M000_IG455
 
G_M000_IG164:                ;; offset=0x0E22
       mov      esi, dword ptr [r14+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG509
       mov      rdi, bword ptr [rdi]
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, r13
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       inc      dword ptr [rbx+0x38]
       jmp      G_M000_IG104
 
G_M000_IG165:                ;; offset=0x0E46
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       cmp      dword ptr [r14+0x18], 0
       jl       SHORT G_M000_IG168
 
G_M000_IG166:                ;; offset=0x0E5C
       mov      esi, dword ptr [r14+0x18]
 
G_M000_IG167:                ;; offset=0x0E60
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG104
 
G_M000_IG168:                ;; offset=0x0E6E
       mov      esi, dword ptr [r14+0x18]
       not      esi
       jmp      SHORT G_M000_IG167
 
G_M000_IG169:                ;; offset=0x0E76
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG171
 
G_M000_IG170:                ;; offset=0x0E7F
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG484
 
G_M000_IG171:                ;; offset=0x0E93
       mov      eax, dword ptr [r14+0x14]
 
G_M000_IG172:                ;; offset=0x0E97
       lea      r13d, [rax+0x01]
       cmp      dword ptr [r14+0x18], 0
       jl       SHORT G_M000_IG176
 
G_M000_IG173:                ;; offset=0x0EA2
       mov      r12d, dword ptr [r14+0x18]
 
G_M000_IG174:                ;; offset=0x0EA6
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r14, rax
       cmp      r12d, dword ptr [rbx+0x3C]
       jl       G_M000_IG485
 
G_M000_IG175:                ;; offset=0x0EC2
       lea      rdi, bword ptr [rbx+0x48]
       cmp      r13d, dword ptr [rdi+0x08]
       jae      G_M000_IG509
       mov      rdi, bword ptr [rdi]
       mov      esi, r13d
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbx+0x3C], r12d
       jmp      G_M000_IG104
 
G_M000_IG176:                ;; offset=0x0EEB
       mov      esi, dword ptr [r14+0x18]
       mov      r12d, esi
       not      r12d
       jmp      SHORT G_M000_IG174
 
G_M000_IG177:                ;; offset=0x0EF7
       mov      edi, r13d
       lea      rax, [reloc @RWD176]
       mov      eax, dword ptr [rax+4*rdi]
       lea      rcx, G_M000_IG02
       add      rax, rcx
       jmp      rax
 
G_M000_IG178:                ;; offset=0x0F10
       mov      rdi, gword ptr [rbx+0x08]
       mov      r13, gword ptr [rdi+0x18]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      rdi, 0x7828EF15BEC0
       cmp      qword ptr [r13], rdi
       jne      G_M000_IG339
       cmp      dword ptr [r13+0x08], eax
       jbe      G_M000_IG494
       mov      edi, eax
       mov      r12, gword ptr [r13+8*rdi+0x10]
 
G_M000_IG179:                ;; offset=0x0F46
       mov      r13, gword ptr [r14]
       mov      rax, gword ptr [rbx+0x18]
       mov      gword ptr [rbp-0x1B0], rax
       mov      rcx, rax
 
G_M000_IG180:                ;; offset=0x0F57
       mov      rsi, gword ptr [rcx+0x10]
       mov      rdi, rsi
       test     rdi, rdi
       je       SHORT G_M000_IG182
 
G_M000_IG181:                ;; offset=0x0F63
       mov      rdx, 0x7828F04A52F0
       cmp      qword ptr [rdi], rdx
       jne      G_M000_IG341
 
G_M000_IG182:                ;; offset=0x0F76
       test     rdi, rdi
       jne      G_M000_IG340
       mov      gword ptr [rbp-0x1C0], rcx
       movzx    rdi, byte  ptr [rcx+0x102]
       test     edi, edi
       je       G_M000_IG196
       mov      rsi, rcx
       test     rsi, rsi
       je       G_M000_IG196
 
G_M000_IG183:                ;; offset=0x0FA2
       test     edi, edi
       je       G_M000_IG342
       mov      rdx, rcx
 
G_M000_IG184:                ;; offset=0x0FAD
       cmp      byte  ptr [rdx], dl
       xor      edi, edi
       mov      dword ptr [rbp-0xB0], edi
 
G_M000_IG185:                ;; offset=0x0FB7
       mov      dword ptr [rbp-0xB8], edi
       mov      gword ptr [rbp-0x1C8], rdx
       mov      rdi, gword ptr [rdx+0x108]
       mov      r8, gword ptr [rdi+0x28]
       mov      rdi, 0x7828F039ECA8
       cmp      qword ptr [r8], rdi
       jne      G_M000_IG348
       mov      gword ptr [rbp-0x1D0], r8
       test     r12, r12
       je       G_M000_IG501
       cmp      gword ptr [r8+0x08], 0
       je       G_M000_IG194
 
G_M000_IG186:                ;; offset=0x0FFD
       mov      r9, gword ptr [r8+0x18]
       mov      gword ptr [rbp-0x1E0], r9
       mov      rdi, 0x7828EF1584D8
       cmp      qword ptr [r9], rdi
       jne      G_M000_IG344
       mov      r9, gword ptr [rbp-0x1E0]
       lea      rdi, bword ptr [r12+0x0C]
       mov      bword ptr [rbp-0xC8], rdi
       mov      edi, 0x15051505
       mov      esi, 0x15051505
       mov      r11, bword ptr [rbp-0xC8]
       mov      r10d, dword ptr [r12+0x08]
       cmp      r10d, 2
       jle      SHORT G_M000_IG189
 
G_M000_IG187:                ;; offset=0x104A
       add      r10d, -4
       mov      r9d, edi
       rol      r9d, 5
       add      edi, r9d
       xor      edi, dword ptr [r11]
       mov      r9d, esi
       rol      r9d, 5
       add      esi, r9d
       xor      esi, dword ptr [r11+0x04]
       add      r11, 8
       cmp      r10d, 2
       jg       SHORT G_M000_IG187
 
G_M000_IG188:                ;; offset=0x1073
       mov      r9, gword ptr [rbp-0x1E0]
 
G_M000_IG189:                ;; offset=0x107A
       test     r10d, r10d
       jg       G_M000_IG343
 
G_M000_IG190:                ;; offset=0x1083
       imul     r10d, esi, 0x5D588B65
       add      r10d, edi
       xor      rdi, rdi
       mov      bword ptr [rbp-0xC8], rdi
 
G_M000_IG191:                ;; offset=0x1096
       mov      dword ptr [rbp-0xBC], r10d
       mov      r8, gword ptr [rbp-0x1D0]
       mov      rdi, gword ptr [r8+0x08]
       mov      esi, r10d
       imul     rsi, qword ptr [r8+0x30]
       shr      rsi, 32
       inc      rsi
       mov      r11d, dword ptr [rdi+0x08]
       imul     rsi, r11
       shr      rsi, 32
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG509
       mov      esi, esi
       lea      rdi, bword ptr [rdi+4*rsi+0x10]
       mov      edi, dword ptr [rdi]
       mov      r8, gword ptr [r8+0x10]
       mov      gword ptr [rbp-0x1E8], r8
       xor      r11d, r11d
       mov      dword ptr [rbp-0xC0], r11d
       dec      edi
       cmp      dword ptr [r8+0x08], edi
       jbe      SHORT G_M000_IG194
 
G_M000_IG192:                ;; offset=0x10F2
       mov      edi, edi
       lea      rdi, [rdi+2*rdi]
       lea      rsi, bword ptr [r8+8*rdi+0x10]
       mov      bword ptr [rbp-0x1D8], rsi
       cmp      dword ptr [rsi+0x08], r10d
       je       G_M000_IG345
 
G_M000_IG193:                ;; offset=0x110E
       mov      edi, dword ptr [rsi+0x0C]
       mov      r11d, dword ptr [rbp-0xC0]
       inc      r11d
       mov      r8, gword ptr [rbp-0x1E8]
       cmp      dword ptr [r8+0x08], r11d
       jb       G_M000_IG502
       cmp      dword ptr [r8+0x08], edi
       mov      dword ptr [rbp-0xC0], r11d
       mov      r10d, dword ptr [rbp-0xBC]
       ja       SHORT G_M000_IG192
 
G_M000_IG194:                ;; offset=0x1140
       xor      edi, edi
       mov      dword ptr [rbp-0xB0], edi
 
G_M000_IG195:                ;; offset=0x1148
       mov      rdx, gword ptr [rbp-0x1C8]
       cmp      gword ptr [rdx+0x118], 0
       jne      G_M000_IG351
       mov      rcx, gword ptr [rbp-0x1C0]
 
G_M000_IG196:                ;; offset=0x1164
       mov      rdx, gword ptr [rcx+0x08]
       test     rdx, rdx
       je       G_M000_IG353
 
G_M000_IG197:                ;; offset=0x1171
       mov      rcx, rdx
       mov      gword ptr [rbp-0x1F8], rcx
       cmp      byte  ptr [rcx], cl
       test     r12, r12
       je       G_M000_IG501
       cmp      gword ptr [rcx+0x08], 0
       je       G_M000_IG206
 
G_M000_IG198:                ;; offset=0x1191
       mov      rdx, gword ptr [rcx+0x18]
       mov      gword ptr [rbp-0x208], rdx
       mov      rdi, 0x7828EF1584D8
       cmp      qword ptr [rdx], rdi
       jne      G_M000_IG355
       lea      rdi, bword ptr [r12+0x0C]
       mov      bword ptr [rbp-0xD8], rdi
       mov      edi, 0x15051505
       mov      esi, 0x15051505
       mov      r11, bword ptr [rbp-0xD8]
       mov      r8d, dword ptr [r12+0x08]
       cmp      r8d, 2
       jle      SHORT G_M000_IG200
 
G_M000_IG199:                ;; offset=0x11D7
       add      r8d, -4
       mov      r9d, edi
       rol      r9d, 5
       add      edi, r9d
       xor      edi, dword ptr [r11]
       mov      r9d, esi
       rol      r9d, 5
       add      esi, r9d
       xor      esi, dword ptr [r11+0x04]
       add      r11, 8
       cmp      r8d, 2
       jg       SHORT G_M000_IG199
 
G_M000_IG200:                ;; offset=0x1200
       test     r8d, r8d
       jg       G_M000_IG354
 
G_M000_IG201:                ;; offset=0x1209
       imul     r8d, esi, 0x5D588B65
       add      r8d, edi
       xor      rdi, rdi
       mov      bword ptr [rbp-0xD8], rdi
 
G_M000_IG202:                ;; offset=0x121C
       mov      dword ptr [rbp-0xCC], r8d
       mov      rcx, gword ptr [rbp-0x1F8]
       mov      rsi, gword ptr [rcx+0x08]
       mov      edi, r8d
       imul     rdi, qword ptr [rcx+0x30]
       shr      rdi, 32
       inc      rdi
       mov      r9d, dword ptr [rsi+0x08]
       imul     rdi, r9
       shr      rdi, 32
       cmp      edi, dword ptr [rsi+0x08]
       jae      G_M000_IG509
       mov      edi, edi
       lea      rsi, bword ptr [rsi+4*rdi+0x10]
       mov      esi, dword ptr [rsi]
       mov      rcx, gword ptr [rcx+0x10]
       mov      gword ptr [rbp-0x210], rcx
       xor      r9d, r9d
       mov      dword ptr [rbp-0xD0], r9d
       dec      esi
       mov      r10d, dword ptr [rcx+0x08]
       mov      dword ptr [rbp-0x12C], r10d
       cmp      r10d, esi
       jbe      SHORT G_M000_IG206
 
G_M000_IG203:                ;; offset=0x1282
       mov      esi, esi
       lea      rsi, [rsi+2*rsi]
       lea      r11, bword ptr [rcx+8*rsi+0x10]
       mov      bword ptr [rbp-0x200], r11
       cmp      dword ptr [r11+0x10], r8d
       je       G_M000_IG224
 
G_M000_IG204:                ;; offset=0x129E
       mov      esi, dword ptr [r11+0x14]
       mov      r9d, dword ptr [rbp-0xD0]
       inc      r9d
       mov      r10d, dword ptr [rbp-0x12C]
       cmp      r10d, r9d
       jb       G_M000_IG502
 
G_M000_IG205:                ;; offset=0x12BC
       cmp      r10d, esi
       mov      dword ptr [rbp-0xD0], r9d
       mov      rcx, gword ptr [rbp-0x210]
       mov      r8d, dword ptr [rbp-0xCC]
       ja       SHORT G_M000_IG203
 
G_M000_IG206:                ;; offset=0x12D6
       mov      rax, gword ptr [rbp-0x1B0]
       mov      rdi, gword ptr [rax+0xA0]
       mov      rax, gword ptr [rdi+0xF0]
       mov      gword ptr [rbp-0x220], rax
       cmp      byte  ptr [rax], al
       cmp      gword ptr [rax+0x08], 0
       je       G_M000_IG215
 
G_M000_IG207:                ;; offset=0x12FF
       mov      rcx, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x230], rcx
       mov      rdi, 0x7828EF1584D8
       cmp      qword ptr [rcx], rdi
       jne      G_M000_IG359
       lea      rdi, bword ptr [r12+0x0C]
       mov      bword ptr [rbp-0xE8], rdi
       mov      edi, 0x15051505
       mov      esi, 0x15051505
       mov      r11, bword ptr [rbp-0xE8]
       mov      edx, dword ptr [r12+0x08]
       cmp      edx, 2
       jle      SHORT G_M000_IG209
 
G_M000_IG208:                ;; offset=0x1344
       add      edx, -4
       mov      r8d, edi
       rol      r8d, 5
       add      edi, r8d
       xor      edi, dword ptr [r11]
       mov      r8d, esi
       rol      r8d, 5
       add      esi, r8d
       xor      esi, dword ptr [r11+0x04]
       add      r11, 8
       cmp      edx, 2
       jg       SHORT G_M000_IG208
 
G_M000_IG209:                ;; offset=0x136B
       test     edx, edx
       jg       G_M000_IG358
 
G_M000_IG210:                ;; offset=0x1373
       imul     edx, esi, 0x5D588B65
       add      edx, edi
       xor      rdi, rdi
       mov      bword ptr [rbp-0xE8], rdi
 
G_M000_IG211:                ;; offset=0x1384
       mov      r8d, edx
       mov      dword ptr [rbp-0xDC], r8d
       mov      rax, gword ptr [rbp-0x220]
       mov      rdx, gword ptr [rax+0x08]
       mov      esi, r8d
       imul     rsi, qword ptr [rax+0x30]
       shr      rsi, 32
       inc      rsi
       mov      edi, dword ptr [rdx+0x08]
       mov      r9d, edi
       imul     rsi, r9
       shr      rsi, 32
       cmp      esi, edi
       jae      G_M000_IG509
       mov      esi, esi
       lea      rdx, bword ptr [rdx+4*rsi+0x10]
       mov      edx, dword ptr [rdx]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0x238], rax
       xor      r9d, r9d
       mov      dword ptr [rbp-0xE0], r9d
       dec      edx
       cmp      dword ptr [rax+0x08], edx
       jbe      SHORT G_M000_IG215
 
G_M000_IG212:                ;; offset=0x13E3
       mov      edx, edx
       lea      rdx, [rdx+2*rdx]
       lea      r10, bword ptr [rax+8*rdx+0x10]
       mov      bword ptr [rbp-0x228], r10
       cmp      dword ptr [r10+0x10], r8d
       je       G_M000_IG229
 
G_M000_IG213:                ;; offset=0x13FF
       mov      edx, dword ptr [r10+0x14]
       mov      r9d, dword ptr [rbp-0xE0]
       inc      r9d
       mov      rax, gword ptr [rbp-0x238]
       cmp      dword ptr [rax+0x08], r9d
       jb       G_M000_IG502
 
G_M000_IG214:                ;; offset=0x141E
       cmp      dword ptr [rax+0x08], edx
       mov      dword ptr [rbp-0xE0], r9d
       mov      r8d, dword ptr [rbp-0xDC]
       ja       SHORT G_M000_IG212
 
G_M000_IG215:                ;; offset=0x1431
       xor      rax, rax
       xor      edi, edi
 
G_M000_IG216:                ;; offset=0x1435
       test     edi, edi
       je       G_M000_IG503
 
G_M000_IG217:                ;; offset=0x143D
       mov      gword ptr [rbp-0x1B8], rax
       mov      r12, rax
       cmp      dword ptr [r14+0x18], 0
       jl       G_M000_IG235
 
G_M000_IG218:                ;; offset=0x1452
       mov      rax, gword ptr [rbp-0x1B8]
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG220
 
G_M000_IG219:                ;; offset=0x1462
       mov      rcx, 0xFFFFFFFFFE7FF
       bt       rcx, rdi
       jae      G_M000_IG362
 
G_M000_IG220:                ;; offset=0x1476
       mov      r12d, dword ptr [r14+0x14]
 
G_M000_IG221:                ;; offset=0x147A
       mov      r14d, dword ptr [r14+0x18]
       test     r14d, r14d
       jl       G_M000_IG234
 
G_M000_IG222:                ;; offset=0x1487
       cmp      r14d, dword ptr [rbx+0x3C]
       jl       G_M000_IG363
 
G_M000_IG223:                ;; offset=0x1491
       lea      rdi, bword ptr [rbx+0x48]
       cmp      r12d, dword ptr [rdi+0x08]
       jae      G_M000_IG509
       mov      rdi, bword ptr [rdi]
       mov      esi, r12d
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbx+0x3C], r14d
       jmp      G_M000_IG104
 
G_M000_IG224:                ;; offset=0x14BA
       mov      rsi, gword ptr [r11]
       mov      rdi, 0x7828EF1584D8
       cmp      qword ptr [rdx], rdi
       jne      G_M000_IG357
       mov      rdx, gword ptr [rbp-0x208]
       cmp      rsi, r12
       jne      SHORT G_M000_IG227
 
G_M000_IG225:                ;; offset=0x14DC
       mov      edi, 1
 
G_M000_IG226:                ;; offset=0x14E1
       test     edi, edi
       mov      r11, bword ptr [rbp-0x200]
       je       G_M000_IG204
       add      r11, 8
       mov      r13, gword ptr [r11]
       mov      rax, r13
       jmp      G_M000_IG217
 
G_M000_IG227:                ;; offset=0x14FF
       test     rsi, rsi
       je       G_M000_IG356
       mov      edi, dword ptr [rsi+0x08]
       cmp      edi, dword ptr [r12+0x08]
       jne      G_M000_IG356
 
G_M000_IG228:                ;; offset=0x1516
       add      rsi, 12
       mov      bword ptr [rbp-0x218], rsi
       add      edi, edi
       mov      edx, edi
       lea      rsi, bword ptr [r12+0x0C]
       mov      rdi, bword ptr [rbp-0x218]
       call     [System.SpanHelpers:SequenceEqual(byref,byref,nuint):bool]
       mov      edi, eax
       mov      rdx, gword ptr [rbp-0x208]
       jmp      SHORT G_M000_IG226
 
G_M000_IG229:                ;; offset=0x1542
       mov      rsi, gword ptr [r10]
       mov      rdx, 0x7828EF1584D8
       cmp      qword ptr [rcx], rdx
       jne      G_M000_IG361
       mov      rcx, gword ptr [rbp-0x230]
       cmp      rsi, r12
       jne      SHORT G_M000_IG232
 
G_M000_IG230:                ;; offset=0x1564
       mov      r11d, 1
 
G_M000_IG231:                ;; offset=0x156A
       test     r11d, r11d
       mov      r10, bword ptr [rbp-0x228]
       je       G_M000_IG213
       add      r10, 8
       mov      rdi, gword ptr [r10]
       mov      rax, rdi
       mov      edi, 1
       jmp      G_M000_IG216
 
G_M000_IG232:                ;; offset=0x158E
       test     rsi, rsi
       je       G_M000_IG360
       mov      edx, dword ptr [rsi+0x08]
       cmp      edx, dword ptr [r12+0x08]
       jne      G_M000_IG360
 
G_M000_IG233:                ;; offset=0x15A5
       lea      rdi, bword ptr [rsi+0x0C]
       add      edx, edx
       lea      rsi, bword ptr [r12+0x0C]
       call     [System.SpanHelpers:SequenceEqual(byref,byref,nuint):bool]
       mov      r11d, eax
       mov      rcx, gword ptr [rbp-0x230]
       jmp      SHORT G_M000_IG231
 
G_M000_IG234:                ;; offset=0x15C2
       not      r14d
       jmp      G_M000_IG222
 
G_M000_IG235:                ;; offset=0x15CA
       mov      esi, dword ptr [r14+0x18]
       not      esi
       cmp      esi, dword ptr [rbx+0x3C]
       jge      G_M000_IG244
 
G_M000_IG236:                ;; offset=0x15D9
       mov      esi, dword ptr [r14+0x18]
       mov      r13d, esi
       not      r13d
       mov      esi, dword ptr [rbx+0x3C]
       dec      esi
       mov      rdi, gword ptr [rbx+0x08]
       mov      edi, dword ptr [rdi+0xA0]
       cmp      esi, edi
       jle      G_M000_IG255
 
G_M000_IG237:                ;; offset=0x15FA
       mov      eax, edi
       cmp      eax, r13d
       jl       SHORT G_M000_IG243
 
G_M000_IG238:                ;; offset=0x1601
       lea      rsi, bword ptr [rbx+0x48]
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG509
       mov      rsi, bword ptr [rsi]
       mov      qword ptr [rbp-0x148], rax
       mov      rsi, gword ptr [rsi+8*rax]
       mov      rdi, rsi
       test     rdi, rdi
       je       SHORT G_M000_IG241
 
G_M000_IG239:                ;; offset=0x1624
       mov      rcx, 0x7828F04A75E0
       cmp      qword ptr [rdi], rcx
       jne      G_M000_IG256
 
G_M000_IG240:                ;; offset=0x1637
       xor      rdi, rdi
 
G_M000_IG241:                ;; offset=0x1639
       test     rdi, rdi
       jne      G_M000_IG364
 
G_M000_IG242:                ;; offset=0x1642
       mov      rax, qword ptr [rbp-0x148]
       dec      eax
       mov      rdi, rax
       cmp      edi, r13d
       mov      rax, rdi
       jge      SHORT G_M000_IG238
 
G_M000_IG243:                ;; offset=0x1656
       mov      dword ptr [rbx+0x3C], r13d
 
G_M000_IG244:                ;; offset=0x165A
       lea      r13, bword ptr [rbx+0x48]
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG246
 
G_M000_IG245:                ;; offset=0x1667
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG365
 
G_M000_IG246:                ;; offset=0x167B
       mov      eax, dword ptr [r14+0x14]
 
G_M000_IG247:                ;; offset=0x167F
       cmp      eax, dword ptr [r13+0x08]
       jae      G_M000_IG509
       mov      rdi, bword ptr [r13]
       mov      eax, eax
       xor      rcx, rcx
       mov      gword ptr [rdi+8*rax], rcx
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG249
 
G_M000_IG248:                ;; offset=0x169E
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG366
 
G_M000_IG249:                ;; offset=0x16B2
       mov      eax, dword ptr [r14+0x14]
 
G_M000_IG250:                ;; offset=0x16B6
       mov      dword ptr [rbx+0x3C], eax
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x50]
       mov      eax, dword ptr [rbx+0x38]
       inc      eax
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG509
       shl      rax, 5
       lea      r13, bword ptr [rdi+rax+0x10]
       mov      rdi, gword ptr [rbx+0x18]
       mov      rax, gword ptr [r13]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      rcx, gword ptr [rdi+0x88]
       mov      rcx, gword ptr [rcx+0x20]
       test     rcx, rcx
       jne      G_M000_IG504
       mov      rdi, gword ptr [rdi+0x178]
       test     rdi, rdi
       jne      G_M000_IG367
 
G_M000_IG251:                ;; offset=0x170B
       lea      rdi, bword ptr [rbx+0x48]
       mov      esi, dword ptr [r13+0x1C]
       cmp      esi, 4
       je       SHORT G_M000_IG253
 
G_M000_IG252:                ;; offset=0x1718
       cmp      esi, 27
       jne      G_M000_IG505
 
G_M000_IG253:                ;; offset=0x1721
       mov      esi, dword ptr [r13+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG509
       mov      rdi, bword ptr [rdi]
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, r12
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG254:                ;; offset=0x173D
       inc      dword ptr [rbx+0x38]
       jmp      G_M000_IG104
 
G_M000_IG255:                ;; offset=0x1745
       mov      edi, esi
       jmp      G_M000_IG237
 
G_M000_IG256:                ;; offset=0x174C
       mov      rdi, 0x7828F082A6A8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       jmp      G_M000_IG241
 
G_M000_IG257:                ;; offset=0x1763
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 4
       je       SHORT G_M000_IG259
 
G_M000_IG258:                ;; offset=0x176C
       cmp      edi, 27
       jne      G_M000_IG497
 
G_M000_IG259:                ;; offset=0x1775
       mov      esi, dword ptr [r14+0x08]
       mov      r12, gword ptr [r14]
       lea      rdi, bword ptr [rbx+0x48]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG509
       mov      rdi, bword ptr [rdi]
       mov      eax, esi
       mov      r13, gword ptr [rdi+8*rax]
       test     r13, r13
       je       G_M000_IG498
       mov      r12, r13
       cmp      dword ptr [r14+0x18], 0
       jl       SHORT G_M000_IG267
 
G_M000_IG260:                ;; offset=0x17A5
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG262
 
G_M000_IG261:                ;; offset=0x17AE
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG332
 
G_M000_IG262:                ;; offset=0x17C2
       mov      r12d, dword ptr [r14+0x14]
 
G_M000_IG263:                ;; offset=0x17C6
       mov      r14d, dword ptr [r14+0x18]
       test     r14d, r14d
       jl       SHORT G_M000_IG266
 
G_M000_IG264:                ;; offset=0x17CF
       cmp      r14d, dword ptr [rbx+0x3C]
       jl       G_M000_IG333
 
G_M000_IG265:                ;; offset=0x17D9
       lea      rdi, bword ptr [rbx+0x48]
       cmp      r12d, dword ptr [rdi+0x08]
       jae      G_M000_IG509
       mov      rdi, bword ptr [rdi]
       mov      esi, r12d
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, r13
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbx+0x3C], r14d
       jmp      G_M000_IG104
 
G_M000_IG266:                ;; offset=0x1802
       not      r14d
       jmp      SHORT G_M000_IG264
 
G_M000_IG267:                ;; offset=0x1807
       mov      esi, dword ptr [r14+0x18]
       not      esi
       cmp      esi, dword ptr [rbx+0x3C]
       jge      G_M000_IG276
 
G_M000_IG268:                ;; offset=0x1816
       mov      esi, dword ptr [r14+0x18]
       mov      r13d, esi
       not      r13d
       mov      esi, dword ptr [rbx+0x3C]
       dec      esi
       mov      rdi, gword ptr [rbx+0x08]
       mov      edi, dword ptr [rdi+0xA0]
       cmp      esi, edi
       jle      G_M000_IG286
 
G_M000_IG269:                ;; offset=0x1837
       mov      eax, edi
       cmp      eax, r13d
       jl       SHORT G_M000_IG275
 
G_M000_IG270:                ;; offset=0x183E
       lea      rsi, bword ptr [rbx+0x48]
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG509
       mov      rsi, bword ptr [rsi]
       mov      qword ptr [rbp-0x150], rax
       mov      rsi, gword ptr [rsi+8*rax]
       mov      rdi, rsi
       test     rdi, rdi
       je       SHORT G_M000_IG273
 
G_M000_IG271:                ;; offset=0x1861
       mov      rcx, 0x7828F04A75E0
       cmp      qword ptr [rdi], rcx
       jne      G_M000_IG334
 
G_M000_IG272:                ;; offset=0x1874
       xor      rdi, rdi
 
G_M000_IG273:                ;; offset=0x1876
       test     rdi, rdi
       jne      G_M000_IG335
 
G_M000_IG274:                ;; offset=0x187F
       mov      rax, qword ptr [rbp-0x150]
       dec      eax
       mov      rdi, rax
       cmp      edi, r13d
       mov      rax, rdi
       jge      SHORT G_M000_IG270
 
G_M000_IG275:                ;; offset=0x1893
       mov      dword ptr [rbx+0x3C], r13d
 
G_M000_IG276:                ;; offset=0x1897
       lea      r13, bword ptr [rbx+0x48]
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG278
 
G_M000_IG277:                ;; offset=0x18A4
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG336
 
G_M000_IG278:                ;; offset=0x18B8
       mov      eax, dword ptr [r14+0x14]
 
G_M000_IG279:                ;; offset=0x18BC
       cmp      eax, dword ptr [r13+0x08]
       jae      G_M000_IG509
       mov      rdi, bword ptr [r13]
       mov      eax, eax
       xor      rcx, rcx
       mov      gword ptr [rdi+8*rax], rcx
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG281
 
G_M000_IG280:                ;; offset=0x18DB
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG337
 
G_M000_IG281:                ;; offset=0x18EF
       mov      eax, dword ptr [r14+0x14]
 
G_M000_IG282:                ;; offset=0x18F3
       mov      dword ptr [rbx+0x3C], eax
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x50]
       mov      eax, dword ptr [rbx+0x38]
       inc      eax
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG509
       shl      rax, 5
       lea      r13, bword ptr [rdi+rax+0x10]
       mov      rdi, gword ptr [rbx+0x18]
       mov      rax, gword ptr [r13]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      rcx, gword ptr [rdi+0x88]
       mov      rcx, gword ptr [rcx+0x20]
       test     rcx, rcx
       jne      G_M000_IG499
       mov      rdi, gword ptr [rdi+0x178]
       test     rdi, rdi
       jne      G_M000_IG338
 
G_M000_IG283:                ;; offset=0x1948
       lea      rdi, bword ptr [rbx+0x48]
       mov      esi, dword ptr [r13+0x1C]
       cmp      esi, 4
       je       SHORT G_M000_IG285
 
G_M000_IG284:                ;; offset=0x1955
       cmp      esi, 27
       jne      G_M000_IG500
 
G_M000_IG285:                ;; offset=0x195E
       mov      esi, dword ptr [r13+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG509
       mov      rdi, bword ptr [rdi]
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, r12
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG254
 
G_M000_IG286:                ;; offset=0x197F
       mov      edi, esi
       jmp      G_M000_IG269
 
G_M000_IG287:                ;; offset=0x1986
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x10]
       mov      esi, dword ptr [r14+0x1C]
       cmp      esi, 8
       jg       G_M000_IG318
       cmp      esi, 3
       jne      G_M000_IG317
 
G_M000_IG288:                ;; offset=0x19A4
       mov      esi, dword ptr [r14+0x08]
       mov      r11, 0x7828EF0827A0
       cmp      qword ptr [rdi], r11
       jne      G_M000_IG319
       mov      r12d, dword ptr [rdi+0x08]
       cmp      r12d, esi
       jbe      G_M000_IG494
       mov      r13, gword ptr [rdi+8*rsi+0x10]
 
G_M000_IG289:                ;; offset=0x19CD
       test     r13, r13
       je       G_M000_IG320
       mov      rdi, 0x7828EF0BF460
       cmp      qword ptr [r13], rdi
       je       G_M000_IG315
 
G_M000_IG290:                ;; offset=0x19EA
       mov      r12, r13
       mov      eax, dword ptr [r14+0x18]
       test     eax, eax
       jl       SHORT G_M000_IG298
 
G_M000_IG291:                ;; offset=0x19F5
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG293
 
G_M000_IG292:                ;; offset=0x19FE
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG321
 
G_M000_IG293:                ;; offset=0x1A12
       mov      r12d, dword ptr [r14+0x14]
 
G_M000_IG294:                ;; offset=0x1A16
       mov      r14d, dword ptr [r14+0x18]
       test     r14d, r14d
       jl       SHORT G_M000_IG297
 
G_M000_IG295:                ;; offset=0x1A1F
       cmp      r14d, dword ptr [rbx+0x3C]
       jl       G_M000_IG322
 
G_M000_IG296:                ;; offset=0x1A29
       lea      rdi, bword ptr [rbx+0x48]
       cmp      r12d, dword ptr [rdi+0x08]
       jae      G_M000_IG509
       mov      rdi, bword ptr [rdi]
       mov      esi, r12d
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, r13
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbx+0x3C], r14d
       jmp      G_M000_IG104
 
G_M000_IG297:                ;; offset=0x1A52
       not      r14d
       jmp      SHORT G_M000_IG295
 
G_M000_IG298:                ;; offset=0x1A57
       mov      r13d, eax
       not      r13d
       mov      esi, r13d
       mov      edi, dword ptr [rbx+0x3C]
       cmp      esi, edi
       jge      SHORT G_M000_IG305
 
G_M000_IG299:                ;; offset=0x1A67
       dec      edi
       mov      rsi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rsi+0xA0]
       cmp      edi, esi
       jle      G_M000_IG324
       jmp      G_M000_IG323
 
G_M000_IG300:                ;; offset=0x1A80
       mov      eax, esi
       cmp      eax, r13d
       jl       SHORT G_M000_IG304
 
G_M000_IG301:                ;; offset=0x1A87
       lea      rsi, bword ptr [rbx+0x48]
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG509
       mov      rsi, bword ptr [rsi]
       mov      qword ptr [rbp-0x158], rax
       mov      rsi, gword ptr [rsi+8*rax]
       mov      rdi, rsi
       test     rdi, rdi
       jne      G_M000_IG325
 
G_M000_IG302:                ;; offset=0x1AAE
       test     rdi, rdi
       jne      G_M000_IG328
 
G_M000_IG303:                ;; offset=0x1AB7
       mov      rax, qword ptr [rbp-0x158]
       dec      eax
       mov      rdi, rax
       cmp      edi, r13d
       mov      rax, rdi
       jge      SHORT G_M000_IG301
 
G_M000_IG304:                ;; offset=0x1ACB
       mov      dword ptr [rbx+0x3C], r13d
 
G_M000_IG305:                ;; offset=0x1ACF
       lea      r13, bword ptr [rbx+0x48]
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG307
 
G_M000_IG306:                ;; offset=0x1ADC
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG329
 
G_M000_IG307:                ;; offset=0x1AF0
       mov      eax, dword ptr [r14+0x14]
 
G_M000_IG308:                ;; offset=0x1AF4
       cmp      eax, dword ptr [r13+0x08]
       jae      G_M000_IG509
       mov      rdi, bword ptr [r13]
       mov      eax, eax
       xor      rcx, rcx
       mov      gword ptr [rdi+8*rax], rcx
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 52
       ja       SHORT G_M000_IG310
 
G_M000_IG309:                ;; offset=0x1B13
       mov      rax, 0xFFFFFFFFFE7FF
       bt       rax, rdi
       jae      G_M000_IG330
 
G_M000_IG310:                ;; offset=0x1B27
       mov      eax, dword ptr [r14+0x14]
 
G_M000_IG311:                ;; offset=0x1B2B
       mov      dword ptr [rbx+0x3C], eax
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x50]
       mov      eax, dword ptr [rbx+0x38]
       inc      eax
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG509
       shl      rax, 5
       lea      r13, bword ptr [rdi+rax+0x10]
       mov      rdi, gword ptr [rbx+0x18]
       mov      rax, gword ptr [r13]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      rcx, gword ptr [rdi+0x88]
       mov      rcx, gword ptr [rcx+0x20]
       test     rcx, rcx
       jne      G_M000_IG495
       mov      rdi, gword ptr [rdi+0x178]
       test     rdi, rdi
       jne      G_M000_IG331
 
G_M000_IG312:                ;; offset=0x1B80
       lea      rdi, bword ptr [rbx+0x48]
       mov      esi, dword ptr [r13+0x1C]
       cmp      esi, 4
       je       SHORT G_M000_IG314
 
G_M000_IG313:                ;; offset=0x1B8D
       cmp      esi, 27
       jne      G_M000_IG496
 
G_M000_IG314:                ;; offset=0x1B96
       mov      esi, dword ptr [r13+0x08]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG509
       mov      rdi, bword ptr [rdi]
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, r12
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG254
 
G_M000_IG315:                ;; offset=0x1BB7
       mov      rdi, 0x7828EF797A68
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rdi, rbx
       mov      rsi, 0x7828EC2593B0
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG316:                ;; offset=0x1BE5
       cmp      dword ptr [rdi+0x20], 0
       je       G_M000_IG107
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG107
 
G_M000_IG317:                ;; offset=0x1BFD
       cmp      esi, 8
       je       G_M000_IG288
       jmp      G_M000_IG493
 
G_M000_IG318:                ;; offset=0x1C0B
       cmp      esi, 65
       je       G_M000_IG288
       cmp      esi, 68
       jne      G_M000_IG493
       jmp      G_M000_IG288
 
G_M000_IG319:                ;; offset=0x1C22
       mov      r11, 0x7828EDE630E8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r13, rax
       jmp      G_M000_IG289
 
G_M000_IG320:                ;; offset=0x1C37
       mov      rdi, 0x782111801A70
       mov      r13, gword ptr [rdi]
       jmp      G_M000_IG290
 
G_M000_IG321:                ;; offset=0x1C49
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r12d, eax
       jmp      G_M000_IG294
 
G_M000_IG322:                ;; offset=0x1C5A
       mov      rdi, rbx
       mov      esi, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG296
 
G_M000_IG323:                ;; offset=0x1C6B
       jmp      G_M000_IG300
 
G_M000_IG324:                ;; offset=0x1C70
       mov      esi, edi
       jmp      G_M000_IG300
 
G_M000_IG325:                ;; offset=0x1C77
       mov      rcx, 0x7828F04A75E0
       cmp      qword ptr [rdi], rcx
       je       SHORT G_M000_IG327
 
G_M000_IG326:                ;; offset=0x1C86
       mov      rdi, 0x7828F082A6A8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       jmp      G_M000_IG302
 
G_M000_IG327:                ;; offset=0x1C9D
       xor      rdi, rdi
       jmp      G_M000_IG302
 
G_M000_IG328:                ;; offset=0x1CA4
       lea      rcx, bword ptr [rbx+0x48]
       mov      rax, qword ptr [rbp-0x158]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG509
       mov      rcx, bword ptr [rcx]
       xor      rdx, rdx
       mov      qword ptr [rbp-0x158], rax
       mov      gword ptr [rcx+8*rax], rdx
       mov      rcx, qword ptr [rdi]
       mov      rcx, qword ptr [rcx+0x40]
       call     [rcx+0x20]Lokad.Lython.Runtime.ExecutableTemporaryValue:Dispose():this
       jmp      G_M000_IG303
 
G_M000_IG329:                ;; offset=0x1CD7
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG308
 
G_M000_IG330:                ;; offset=0x1CE5
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG311
 
G_M000_IG331:                ;; offset=0x1CF3
       cmp      dword ptr [rdi+0x20], 0
       je       G_M000_IG312
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG312
 
G_M000_IG332:                ;; offset=0x1D0B
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r12d, eax
       jmp      G_M000_IG263
 
G_M000_IG333:                ;; offset=0x1D1C
       mov      rdi, rbx
       mov      esi, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG265
 
G_M000_IG334:                ;; offset=0x1D2D
       mov      rdi, 0x7828F082A6A8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       jmp      G_M000_IG273
 
G_M000_IG335:                ;; offset=0x1D44
       lea      rcx, bword ptr [rbx+0x48]
       mov      rax, qword ptr [rbp-0x150]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG509
       mov      rcx, bword ptr [rcx]
       xor      rdx, rdx
       mov      qword ptr [rbp-0x150], rax
       mov      gword ptr [rcx+8*rax], rdx
       mov      rcx, qword ptr [rdi]
       mov      rcx, qword ptr [rcx+0x40]
       call     [rcx+0x20]Lokad.Lython.Runtime.ExecutableTemporaryValue:Dispose():this
       jmp      G_M000_IG274
 
G_M000_IG336:                ;; offset=0x1D77
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG279
 
G_M000_IG337:                ;; offset=0x1D85
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG282
 
G_M000_IG338:                ;; offset=0x1D93
       cmp      dword ptr [rdi+0x20], 0
       je       G_M000_IG283
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG283
 
G_M000_IG339:                ;; offset=0x1DAB
       mov      rdi, r13
       mov      esi, eax
       mov      r11, 0x7828EDE630E0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r12, rax
       jmp      G_M000_IG179
 
G_M000_IG340:                ;; offset=0x1DC5
       mov      rsi, gword ptr [rcx+0x10]
       mov      rdi, 0x7828F04A52F0
       call     CORINFO_HELP_CHKCASTCLASS
       mov      rcx, rax
       jmp      G_M000_IG180
 
G_M000_IG341:                ;; offset=0x1DE0
       mov      rdi, rdx
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG342:                ;; offset=0x1DE9
       xor      rdx, rdx
       jmp      G_M000_IG184
 
G_M000_IG343:                ;; offset=0x1DF0
       mov      r10d, esi
       rol      r10d, 5
       add      r10d, esi
       mov      esi, r10d
       xor      esi, dword ptr [r11]
       jmp      G_M000_IG190
 
G_M000_IG344:                ;; offset=0x1E05
       mov      r9, gword ptr [rbp-0x1E0]
       mov      rdi, r9
       mov      rsi, r12
       mov      r11, 0x7828EDE63110
       call     [r11]System.Collections.Generic.IEqualityComparer`1[System.__Canon]:GetHashCode(System.__Canon):int:this
       mov      r10d, eax
       mov      r9, gword ptr [rbp-0x1E0]
       jmp      G_M000_IG191
 
G_M000_IG345:                ;; offset=0x1E2E
       mov      rdi, gword ptr [rsi]
       mov      gword ptr [rbp-0x1F0], rdi
       mov      rdi, 0x7828EF1584D8
       cmp      qword ptr [r9], rdi
       jne      SHORT G_M000_IG346
       mov      rdi, gword ptr [rbp-0x1F0]
       mov      rsi, r12
       call     [System.String:Equals(System.String,System.String):bool]
       jmp      SHORT G_M000_IG347
 
G_M000_IG346:                ;; offset=0x1E59
       mov      r9, gword ptr [rbp-0x1E0]
       mov      rdi, r9
       mov      rdx, r12
       mov      rsi, gword ptr [rbp-0x1F0]
       mov      r11, 0x7828EDE63118
       call     [r11]System.Collections.Generic.IEqualityComparer`1[System.__Canon]:Equals(System.__Canon,System.__Canon):bool:this
 
G_M000_IG347:                ;; offset=0x1E7A
       test     eax, eax
       mov      rsi, bword ptr [rbp-0x1D8]
       mov      r9, gword ptr [rbp-0x1E0]
       je       G_M000_IG193
       add      rsi, 16
       mov      edi, dword ptr [rsi]
       mov      dword ptr [rbp-0xB0], edi
       jmp      SHORT G_M000_IG349
 
G_M000_IG348:                ;; offset=0x1E9E
       lea      rdx, [rbp-0xB0]
       mov      rdi, r8
       mov      rsi, r12
       mov      r11, 0x7828EDE630F8
       call     [r11]System.Collections.Generic.IReadOnlyDictionary`2[System.__Canon,int]:TryGetValue(System.__Canon,byref):bool:this
       test     eax, eax
       je       G_M000_IG195
 
G_M000_IG349:                ;; offset=0x1EC0
       mov      rdx, gword ptr [rbp-0x1C8]
       mov      rdi, gword ptr [rdx+0x110]
       mov      esi, dword ptr [rbp-0xB0]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadLocalValue(System.Object[],int):System.Object]
       test     rax, rax
       je       G_M000_IG195
 
G_M000_IG350:                ;; offset=0x1EE3
       mov      r13, rax
       mov      rax, r13
       jmp      G_M000_IG217
 
G_M000_IG351:                ;; offset=0x1EEE
       mov      gword ptr [rbp-0x1C8], rdx
       mov      rdi, gword ptr [rdx+0x108]
       mov      rdi, gword ptr [rdi+0x40]
       lea      rdx, [rbp-0xB8]
       mov      rsi, r12
       mov      r11, 0x7828EDE63100
       call     [r11]System.Collections.Generic.IReadOnlyDictionary`2[System.__Canon,int]:TryGetValue(System.__Canon,byref):bool:this
       test     eax, eax
       je       SHORT G_M000_IG352
       mov      rdi, gword ptr [rbp-0x1C8]
       mov      rdi, gword ptr [rdi+0x118]
       mov      esi, dword ptr [rbp-0xB8]
       mov      r11, 0x7828EDE63108
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       test     rax, rax
       mov      rcx, gword ptr [rbp-0x1C0]
       je       G_M000_IG196
       mov      r13, rax
       mov      rax, r13
       jmp      G_M000_IG217
 
G_M000_IG352:                ;; offset=0x1F62
       mov      rcx, gword ptr [rbp-0x1C0]
       jmp      G_M000_IG196
 
G_M000_IG353:                ;; offset=0x1F6E
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.ExecutionFrame:InitializeVariables():System.Collections.Generic.Dictionary`2[System.String,System.Object]:this]
       mov      rdx, rax
       jmp      G_M000_IG197
 
G_M000_IG354:                ;; offset=0x1F7F
       mov      r8d, esi
       rol      r8d, 5
       add      r8d, esi
       mov      esi, r8d
       xor      esi, dword ptr [r11]
       jmp      G_M000_IG201
 
G_M000_IG355:                ;; offset=0x1F94
       mov      rdi, rdx
       mov      rsi, r12
       mov      r11, 0x7828EDE63120
       call     [r11]System.Collections.Generic.IEqualityComparer`1[System.__Canon]:GetHashCode(System.__Canon):int:this
       mov      r8d, eax
       mov      rdx, gword ptr [rbp-0x208]
       jmp      G_M000_IG202
 
G_M000_IG356:                ;; offset=0x1FB6
       xor      edi, edi
       jmp      G_M000_IG226
 
G_M000_IG357:                ;; offset=0x1FBD
       mov      rdx, gword ptr [rbp-0x208]
       mov      rdi, rdx
       mov      rdx, r12
       mov      r11, 0x7828EDE63128
       call     [r11]System.Collections.Generic.IEqualityComparer`1[System.__Canon]:Equals(System.__Canon,System.__Canon):bool:this
       mov      edi, eax
       mov      rdx, gword ptr [rbp-0x208]
       jmp      G_M000_IG226
 
G_M000_IG358:                ;; offset=0x1FE5
       mov      edx, esi
       rol      edx, 5
       add      edx, esi
       mov      esi, edx
       xor      esi, dword ptr [r11]
       jmp      G_M000_IG210
 
G_M000_IG359:                ;; offset=0x1FF6
       mov      rdi, rcx
       mov      rsi, r12
       mov      r11, 0x7828EDE63130
       call     [r11]System.Collections.Generic.IEqualityComparer`1[System.__Canon]:GetHashCode(System.__Canon):int:this
       mov      edx, eax
       mov      rcx, gword ptr [rbp-0x230]
       jmp      G_M000_IG211
 
G_M000_IG360:                ;; offset=0x2017
       xor      r11d, r11d
       jmp      G_M000_IG231
 
G_M000_IG361:                ;; offset=0x201F
       mov      rcx, gword ptr [rbp-0x230]
       mov      rdi, rcx
       mov      rdx, r12
       mov      r11, 0x7828EDE63138
       call     [r11]System.Collections.Generic.IEqualityComparer`1[System.__Canon]:Equals(System.__Canon,System.__Canon):bool:this
       mov      r11d, eax
       mov      rcx, gword ptr [rbp-0x230]
       jmp      G_M000_IG231
 
G_M000_IG362:                ;; offset=0x2048
       mov      gword ptr [rbp-0x1B8], rax
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r12d, eax
       mov      rax, gword ptr [rbp-0x1B8]
       jmp      G_M000_IG221
 
G_M000_IG363:                ;; offset=0x2067
       mov      gword ptr [rbp-0x1B8], rax
       mov      rdi, rbx
       mov      esi, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rax, gword ptr [rbp-0x1B8]
       jmp      G_M000_IG223
 
G_M000_IG364:                ;; offset=0x2086
       lea      rcx, bword ptr [rbx+0x48]
       mov      rax, qword ptr [rbp-0x148]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG509
       mov      rcx, bword ptr [rcx]
       xor      rdx, rdx
       mov      qword ptr [rbp-0x148], rax
       mov      gword ptr [rcx+8*rax], rdx
       mov      rcx, qword ptr [rdi]
       mov      rcx, qword ptr [rcx+0x40]
       call     [rcx+0x20]Lokad.Lython.Runtime.ExecutableTemporaryValue:Dispose():this
       jmp      G_M000_IG242
 
G_M000_IG365:                ;; offset=0x20B9
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG247
 
G_M000_IG366:                ;; offset=0x20C7
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG250
 
G_M000_IG367:                ;; offset=0x20D5
       cmp      dword ptr [rdi+0x20], 0
       je       G_M000_IG251
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG251
 
G_M000_IG368:                ;; offset=0x20ED
       mov      rdi, gword ptr [rbx+0x08]
       mov      rsi, gword ptr [rbx+0x10]
       mov      edx, dword ptr [rbx+0x38]
       mov      ecx, dword ptr [rbx+0x3C]
       mov      r8, gword ptr [rbx+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableCell],int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       je       SHORT G_M000_IG369
       add      dword ptr [rbx+0x38], 2
       jmp      G_M000_IG104
 
G_M000_IG369:                ;; offset=0x2112
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      esi, eax
       lea      rdx, [rbp-0x30]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryCell(int,byref):bool:this]
       test     eax, eax
       je       G_M000_IG139
       mov      rdi, gword ptr [rbp-0x30]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       test     rax, rax
       je       G_M000_IG139
       mov      rdi, rbx
       mov      rsi, r14
       mov      rdx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG104
 
G_M000_IG370:                ;; offset=0x215B
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      esi, eax
       lea      rdx, [rbp-0x38]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TryCell(int,byref):bool:this]
       test     eax, eax
       je       G_M000_IG139
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_CanStoreThroughOwner():bool:this]
       test     eax, eax
       je       G_M000_IG139
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rsi, rax
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      G_M000_IG104
 
G_M000_IG371:                ;; offset=0x21AF
       lea      r13, bword ptr [rbx+0x48]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [r13+0x08]
       jae      G_M000_IG509
       mov      rdi, bword ptr [r13]
       mov      esi, eax
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      bword ptr [rbp-0x2B8], rdi
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Take(byref):System.Object:this]
       mov      rsi, rax
       mov      rdi, bword ptr [rbp-0x2B8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      G_M000_IG104
 
G_M000_IG372:                ;; offset=0x21F7
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r13, rax
       mov      rdi, gword ptr [rbx+0x08]
       mov      r12, gword ptr [rdi+0x18]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      esi, eax
       mov      rdi, r12
       mov      r11, 0x7828EDE630D8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r12, rax
       mov      rsi, r13
       mov      rdi, 0x7828F04A75E0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG374
       mov      rsi, r13
       mov      rdi, 0x7828F082EFC8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG373
       xor      r12, r12
       jmp      SHORT G_M000_IG375
 
G_M000_IG373:                ;; offset=0x2262
       mov      rdi, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+DictMembers:GetMethod(System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      r12, rax
       jmp      SHORT G_M000_IG375
 
G_M000_IG374:                ;; offset=0x2270
       mov      rdi, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+StringMembers:GetMethod(System.String):Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod]
       mov      r12, rax
 
G_M000_IG375:                ;; offset=0x227C
       test     r12, r12
       je       G_M000_IG139
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x128], eax
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       lea      edx, [rax+0x01]
       mov      esi, dword ptr [rbp-0x128]
       mov      rdi, rbx
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       lea      r13d, [rax+0x01]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      esi, r13d
       mov      rdi, rbx
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,System.Object):this]
       jmp      G_M000_IG104
 
G_M000_IG376:                ;; offset=0x22DE
       not      esi
       mov      r11, 0x7828EDE63148
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       jmp      G_M000_IG62
 
G_M000_IG377:                ;; offset=0x22F5
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x9C]
       jl       G_M000_IG506
       mov      rdi, 0x7828EF797A68
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rdi, rbx
       mov      rsi, 0x7828EC20F098
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG378:                ;; offset=0x2333
       not      esi
       mov      r11, 0x7828EDE63158
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       jmp      G_M000_IG64
 
G_M000_IG379:                ;; offset=0x234A
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x9C]
       jl       G_M000_IG507
       mov      rdi, 0x7828EF797A68
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rdi, rbx
       mov      rsi, 0x7828EC20F098
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG380:                ;; offset=0x2388
       mov      rdi, gword ptr [r13+0x08]
       mov      r11, 0x7828EDE63160
       call     [r11]Lokad.Lython.Runtime.IPyDictStorage:get_HasProtocolKeys():bool:this
       test     eax, eax
       jne      G_M000_IG139
       jmp      G_M000_IG67
 
G_M000_IG381:                ;; offset=0x23A6
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 24
       je       SHORT G_M000_IG382
       cmp      edi, 25
       jne      G_M000_IG508
 
G_M000_IG382:                ;; offset=0x23B8
       mov      edi, dword ptr [r14+0x0C]
       jmp      G_M000_IG70
 
G_M000_IG383:                ;; offset=0x23C1
       mov      rdi, gword ptr [rax+0x68]
       movsxd   rdi, dword ptr [rdi+0x94]
       imul     rdx, rdi, 64
       jo       G_M000_IG510
       add      rdx, 32
       jo       G_M000_IG510
       mov      qword ptr [rbp-0xF0], rdx
       mov      rdi, gword ptr [rax+0x10]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      rsi, gword ptr [rdi+0x88]
       mov      gword ptr [rbp-0x260], rsi
       cmp      byte  ptr [rsi], sil
       mov      rdi, 0x7828F0158E58
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x268], rax
       mov      rdi, rax
       mov      rsi, gword ptr [rbp-0x260]
       mov      rdx, qword ptr [rbp-0xF0]
       mov      rcx, gword ptr [rbp-0x240]
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:.ctor(Lokad.Lython.Runtime.MemoryGovernor,long,Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp-0x268]
       mov      gword ptr [rbp-0x248], rax
 
G_M000_IG384:                ;; offset=0x2445
       mov      rcx, gword ptr [rbp-0x180]
       mov      rdi, gword ptr [rcx+0x10]
       mov      rdi, gword ptr [rdi+0xA0]
       cmp      byte  ptr [rdi], dil
       xor      edx, edx
       mov      gword ptr [rbp-0xF8], rdx
       mov      rdx, gword ptr [rdi+0x88]
       mov      rdx, gword ptr [rdx+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG386
 
G_M000_IG385:                ;; offset=0x2473
       mov      rdi, rdx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG386:                ;; offset=0x247C
       mov      rdi, gword ptr [rdi+0x178]
       mov      gword ptr [rbp-0xF8], rdi
       lea      rdi, [rbp-0xF8]
       call     [System.Threading.CancellationToken:get_IsCancellationRequested():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG388
 
G_M000_IG387:                ;; offset=0x249B
       mov      rdi, gword ptr [rbp-0x240]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
 
G_M000_IG388:                ;; offset=0x24A8
       mov      rax, gword ptr [rbp-0x180]
       mov      rcx, gword ptr [rax+0x78]
       test     rcx, rcx
       je       SHORT G_M000_IG390
 
G_M000_IG389:                ;; offset=0x24B8
       mov      gword ptr [rbp-0x258], rcx
       jmp      SHORT G_M000_IG391
 
G_M000_IG390:                ;; offset=0x24C1
       mov      rsi, gword ptr [rax+0x68]
       movsxd   rsi, dword ptr [rsi+0x94]
       mov      rdi, 0x7828F0921AA8
       call     CORINFO_HELP_NEWARR_1_VC
       mov      gword ptr [rbp-0x250], rax
       mov      rdi, gword ptr [rbp-0x268]
       mov      rsi, qword ptr [rbp-0xF0]
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:Commit(long):this]
       mov      rdi, gword ptr [rbp-0x180]
       lea      rdi, bword ptr [rdi+0x78]
       mov      rsi, gword ptr [rbp-0x250]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0x250]
       mov      rdx, rax
       mov      gword ptr [rbp-0x258], rdx
 
G_M000_IG391:                ;; offset=0x251E
       mov      rdi, gword ptr [rbp-0x268]
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:Dispose():this]
       mov      rdx, gword ptr [rbp-0x258]
       jmp      G_M000_IG71
 
G_M000_IG392:                ;; offset=0x2537
       mov      edi, dword ptr [r14+0x1C]
       cmp      edi, 24
       je       SHORT G_M000_IG393
       cmp      edi, 25
       jne      G_M000_IG508
 
G_M000_IG393:                ;; offset=0x2549
       mov      edi, dword ptr [r14+0x0C]
       jmp      G_M000_IG72
 
G_M000_IG394:                ;; offset=0x2552
       mov      rdi, rsi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG395:                ;; offset=0x255B
       cmp      dword ptr [rdi+0x20], 0
       je       G_M000_IG73
       mov      rdi, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       mov      rcx, gword ptr [rbp-0x190]
       mov      rdx, gword ptr [rbp-0x270]
       jmp      G_M000_IG73
 
G_M000_IG396:                ;; offset=0x2581
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.PyDict:get_HasProtocolKeys():bool:this]
       test     eax, eax
       jne      G_M000_IG139
       jmp      G_M000_IG413
 
G_M000_IG397:                ;; offset=0x2597
 
G_M000_IG398:                ;; offset=0x2597
       mov      rdi, r12
       mov      rsi, rdx
       mov      rdx, rcx
       call     [Lokad.Lython.Runtime.LythonRuntime:ComputeStructuralHashCode(System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):int]
       mov      edi, eax
       call     [Lokad.Lython.Runtime.PyDict:MixNativeHash(int):uint]
       mov      edx, eax
       mov      rsi, r12
       mov      rdi, r13
       mov      rcx, gword ptr [rbp-0x190]
       mov      r8, gword ptr [rbp-0x270]
       call     [Lokad.Lython.Runtime.PyDict:FindNativeIndex(System.Object,uint,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):int:this]
       mov      dword ptr [rbp-0xFC], eax
       test     eax, eax
       jl       SHORT G_M000_IG396
       mov      rdi, bword ptr [rbp-0x188]
       mov      rsi, gword ptr [rbp-0x278]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, bword ptr [rbp-0x188]
       lea      rdi, bword ptr [rax+0x08]
       mov      rsi, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, bword ptr [rbp-0x188]
       mov      eax, dword ptr [rbp-0xFC]
       mov      dword ptr [rdi+0x10], eax
       mov      r9d, eax
       jmp      G_M000_IG75
 
G_M000_IG399:                ;; offset=0x2612
       xor      rax, rax
       jmp      G_M000_IG78
 
G_M000_IG400:                ;; offset=0x2619
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r12d, eax
       mov      rax, gword ptr [rbp-0x160]
       jmp      G_M000_IG82
 
G_M000_IG401:                ;; offset=0x2631
       mov      rdi, rbx
       mov      esi, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rax, gword ptr [rbp-0x160]
       jmp      G_M000_IG84
 
G_M000_IG402:                ;; offset=0x2649
       jmp      G_M000_IG88
 
G_M000_IG403:                ;; offset=0x264E
       mov      edi, esi
       jmp      G_M000_IG88
 
G_M000_IG404:                ;; offset=0x2655
       mov      rcx, 0x7828F04A75E0
       cmp      qword ptr [rdi], rcx
       je       SHORT G_M000_IG406
 
G_M000_IG405:                ;; offset=0x2664
       mov      rdi, 0x7828F082A6A8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       jmp      G_M000_IG90
 
G_M000_IG406:                ;; offset=0x267B
       xor      rdi, rdi
       jmp      G_M000_IG90
 
G_M000_IG407:                ;; offset=0x2682
       lea      rcx, bword ptr [rbx+0x48]
       mov      rax, qword ptr [rbp-0x140]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG509
       mov      rcx, bword ptr [rcx]
       xor      rdx, rdx
       mov      qword ptr [rbp-0x140], rax
       mov      gword ptr [rcx+8*rax], rdx
       mov      rcx, qword ptr [rdi]
       mov      rcx, qword ptr [rcx+0x40]
       call     [rcx+0x20]Lokad.Lython.Runtime.ExecutableTemporaryValue:Dispose():this
       jmp      G_M000_IG91
 
G_M000_IG408:                ;; offset=0x26B5
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG96
 
G_M000_IG409:                ;; offset=0x26C3
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG99
 
G_M000_IG410:                ;; offset=0x26D1
       mov      rdi, rcx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG411:                ;; offset=0x26DA
       cmp      dword ptr [rdi+0x20], 0
       je       G_M000_IG100
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG100
 
G_M000_IG412:                ;; offset=0x26F2
       mov      rdi, r12
       mov      rsi, 0x7828EC257CC8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG413:                ;; offset=0x270E
       mov      rdx, gword ptr [r14]
       mov      rcx, gword ptr [rbx+0x18]
       mov      rdi, r13
       mov      rsi, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadSubscriptValue(System.Object,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rdx, rax
       mov      rsi, r14
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG104
 
G_M000_IG414:                ;; offset=0x2735
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r12, rax
       cmp      dword ptr [r14+0x08], 0
       je       G_M000_IG416
       mov      rsi, r12
       mov      rdi, 0x7828F0641F78
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG415
       mov      rsi, r12
       mov      rdi, 0x7828EF0B6558
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG415
       mov      rsi, r12
       mov      rdi, 0x7828EF0835C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       sete     r13b
       movzx    r13, r13b
       jmp      SHORT G_M000_IG417
 
G_M000_IG415:                ;; offset=0x279F
       mov      edi, dword ptr [r14+0x08]
       mov      r13, gword ptr [rbx+0x18]
       mov      rax, gword ptr [r14]
       mov      gword ptr [rbp-0x280], rax
       call     [Lokad.Lython.Runtime.LythonRuntime:MapExecutableUnary(int):int]
       mov      edi, eax
       mov      rsi, r12
       mov      rdx, r13
       mov      rcx, gword ptr [rbp-0x280]
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateUnaryOperator(int,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      rdx, rax
       mov      rsi, r14
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG104
 
G_M000_IG416:                ;; offset=0x27E0
       mov      rdi, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       sete     r13b
       movzx    r13, r13b
 
G_M000_IG417:                ;; offset=0x27F3
       test     r13d, r13d
       jne      G_M000_IG139
       jmp      SHORT G_M000_IG415
 
G_M000_IG418:                ;; offset=0x27FE
       not      esi
       mov      r11, 0x7828EDE63178
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       jmp      G_M000_IG06
 
G_M000_IG419:                ;; offset=0x2815
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x9C]
       jge      SHORT G_M000_IG420
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x20]
       mov      r11, 0x7828EDE63170
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r13, rax
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rbx+0x38]
       xor      edx, edx
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rsi, rax
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG420:                ;; offset=0x285F
       mov      rdi, 0x7828EF797A68
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rdi, rbx
       mov      rsi, 0x7828EC20F098
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG421:                ;; offset=0x288D
       not      esi
       mov      r11, 0x7828EDE63188
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       jmp      G_M000_IG08
 
G_M000_IG422:                ;; offset=0x28A4
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x9C]
       jge      SHORT G_M000_IG423
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x20]
       mov      r11, 0x7828EDE63180
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r15, rax
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rbx+0x38]
       mov      edx, 1
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rsi, rax
       mov      rdi, r15
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG423:                ;; offset=0x28F1
       mov      rdi, 0x7828EF797A68
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rdi, rbx
       mov      rsi, 0x7828EC20F098
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG424:                ;; offset=0x291F
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r13d, eax
       jmp      G_M000_IG37
 
G_M000_IG425:                ;; offset=0x2930
       mov      rdi, rbx
       mov      esi, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG40
 
G_M000_IG426:                ;; offset=0x2941
       mov      rdi, 0x7828F082A6A8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       jmp      G_M000_IG48
 
G_M000_IG427:                ;; offset=0x2958
       lea      rcx, bword ptr [rbx+0x48]
       mov      rax, qword ptr [rbp-0x138]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG509
       mov      rcx, bword ptr [rcx]
       xor      rdx, rdx
       mov      qword ptr [rbp-0x138], rax
       mov      gword ptr [rcx+8*rax], rdx
       mov      rcx, qword ptr [rdi]
       mov      rcx, qword ptr [rcx+0x40]
       call     [rcx+0x20]Lokad.Lython.Runtime.ExecutableTemporaryValue:Dispose():this
       jmp      G_M000_IG49
 
G_M000_IG428:                ;; offset=0x298B
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG54
 
G_M000_IG429:                ;; offset=0x2999
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG57
 
G_M000_IG430:                ;; offset=0x29A7
       mov      rdi, rcx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG431:                ;; offset=0x29B0
       cmp      dword ptr [rdi+0x20], 0
       je       G_M000_IG58
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG58
 
G_M000_IG432:                ;; offset=0x29C8
       mov      rdi, r14
       mov      rsi, 0x7828EC257CC8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG433:                ;; offset=0x29E4
       mov      edi, dword ptr [r14+0x14]
       jmp      G_M000_IG116
 
G_M000_IG434:                ;; offset=0x29ED
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r12d, eax
       jmp      G_M000_IG15
 
G_M000_IG435:                ;; offset=0x29FE
       mov      rdi, rbx
       mov      esi, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG18
 
G_M000_IG436:                ;; offset=0x2A0F
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG26
 
G_M000_IG437:                ;; offset=0x2A1D
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG29
 
G_M000_IG438:                ;; offset=0x2A2B
       mov      rdi, rcx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG439:                ;; offset=0x2A34
       cmp      dword ptr [rdi+0x20], 0
       je       G_M000_IG30
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG30
 
G_M000_IG440:                ;; offset=0x2A4C
       mov      rdi, r12
       mov      rsi, 0x7828EC257CC8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG441:                ;; offset=0x2A68
       mov      edi, dword ptr [r14+0x14]
       jmp      G_M000_IG118
 
G_M000_IG442:                ;; offset=0x2A71
       mov      edi, dword ptr [r14+0x08]
       call     [Lokad.Lython.Runtime.LythonRuntime:AugmentedBinaryOperator(int):int]
       mov      edi, eax
       jmp      G_M000_IG118
 
G_M000_IG443:                ;; offset=0x2A82
       mov      rsi, r13
       mov      rdi, 0x7828F0641F78
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG444
       mov      rsi, r13
       mov      rdi, 0x7828EF0B6558
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG444
       mov      rsi, r13
       mov      rdi, 0x7828EF0835C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       G_M000_IG139
 
G_M000_IG444:                ;; offset=0x2ACB
       mov      rsi, r12
       mov      rdi, 0x7828F0641F78
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG446
       mov      rsi, r12
       mov      rdi, 0x7828EF0B6558
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG446
       mov      rsi, r12
       mov      rdi, 0x7828EF0835C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       G_M000_IG139
       jmp      SHORT G_M000_IG446
 
G_M000_IG445:                ;; offset=0x2B16
       mov      edi, dword ptr [r14+0x14]
       jmp      G_M000_IG119
 
G_M000_IG446:                ;; offset=0x2B1F
       mov      edx, dword ptr [r14+0x08]
       mov      rcx, gword ptr [rbx+0x18]
       mov      bword ptr [rbp-0x170], rbx
       mov      r9, r14
       mov      bword ptr [rbp-0x178], r9
       mov      r8, gword ptr [r9]
       mov      rdi, r13
       mov      rsi, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateAugmentedBuiltin(System.Object,System.Object,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      r12, rax
       jmp      G_M000_IG120
 
G_M000_IG447:                ;; offset=0x2B4F
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r13d, eax
       jmp      G_M000_IG124
 
G_M000_IG448:                ;; offset=0x2B60
       mov      rdi, rbx
       mov      esi, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG127
 
G_M000_IG449:                ;; offset=0x2B71
       mov      rdi, 0x7828F082A6A8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       jmp      G_M000_IG152
 
G_M000_IG450:                ;; offset=0x2B88
       lea      rcx, bword ptr [rbx+0x48]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG509
       mov      rcx, bword ptr [rcx]
       xor      rdx, rdx
       mov      gword ptr [rcx+8*r14], rdx
       mov      rcx, qword ptr [rdi]
       mov      rcx, qword ptr [rcx+0x40]
       call     [rcx+0x20]Lokad.Lython.Runtime.ExecutableTemporaryValue:Dispose():this
       jmp      G_M000_IG153
 
G_M000_IG451:                ;; offset=0x2BAE
       mov      bword ptr [rbp-0x178], rax
       mov      rdi, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edi, eax
       mov      rax, bword ptr [rbp-0x178]
       jmp      G_M000_IG158
 
G_M000_IG452:                ;; offset=0x2BCC
       mov      rdi, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG161
 
G_M000_IG453:                ;; offset=0x2BDA
       mov      rdi, rcx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG454:                ;; offset=0x2BE3
       cmp      dword ptr [rdi+0x20], 0
       je       G_M000_IG162
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG162
 
G_M000_IG455:                ;; offset=0x2BFB
       mov      rdi, r14
       mov      rsi, 0x7828EC257CC8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG456:                ;; offset=0x2C17
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r13, rax
       mov      esi, dword ptr [r14+0x0C]
       mov      rdi, rbx
       mov      edx, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r12, rax
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_BinaryOperator():int:this]
       mov      edi, eax
       mov      r8, gword ptr [r14]
       mov      rcx, gword ptr [rbx+0x18]
       lea      r9, [rbp-0x60]
       mov      rsi, r13
       mov      rdx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluateScalarComparison(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       G_M000_IG139
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      esi, eax
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, gword ptr [rbx+0x18]
       mov      r13, gword ptr [r14]
       mov      rdi, gword ptr [rdi+0xA0]
       cmp      byte  ptr [rdi], dil
       xor      eax, eax
       mov      gword ptr [rbp-0x118], rax
       mov      rax, gword ptr [rdi+0x88]
       mov      rax, gword ptr [rax+0x20]
       test     rax, rax
       je       SHORT G_M000_IG457
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG457:                ;; offset=0x2CAF
       mov      rdi, gword ptr [rdi+0x178]
       mov      gword ptr [rbp-0x118], rdi
       lea      rdi, [rbp-0x118]
       call     [System.Threading.CancellationToken:get_IsCancellationRequested():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG458
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
 
G_M000_IG458:                ;; offset=0x2CD7
       cmp      byte  ptr [rbp-0x60], 0
       jne      G_M000_IG104
       jmp      G_M000_IG132
 
G_M000_IG459:                ;; offset=0x2CE6
       not      esi
       mov      r11, 0x7828EDE63198
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       jmp      G_M000_IG04
 
G_M000_IG460:                ;; offset=0x2CFD
       mov      rax, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rax+0x9C]
       jge      G_M000_IG130
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x20]
       mov      r11, 0x7828EDE63190
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r14, rax
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rbx+0x38]
       xor      edx, edx
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rsi, rax
       mov      rdi, r14
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG461:                ;; offset=0x2D4B
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DiscardIterator():bool:this]
       test     eax, eax
       je       G_M000_IG132
       mov      esi, dword ptr [rbx+0x3C]
       dec      esi
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG132
 
G_M000_IG462:                ;; offset=0x2D6F
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      r13, rax
       mov      rsi, r13
       mov      rdi, 0x7828F093C228
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG463
       mov      rdi, rbx
       mov      rsi, r14
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG104
 
G_M000_IG463:                ;; offset=0x2DAC
       mov      rsi, r13
       mov      rdi, 0x7828F0833E58
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      G_M000_IG464
       mov      rsi, r13
       mov      rdi, 0x7828F04A8090
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG464
       mov      rsi, r13
       mov      rdi, 0x7828F0927C00
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG464
       mov      rsi, r13
       mov      rdi, 0x7828F04AB920
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG464
       mov      rsi, r13
       mov      rdi, 0x7828F04A75E0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG464
       mov      rsi, r13
       mov      rdi, 0x7828F082EFC8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG464
       mov      rsi, r13
       mov      rdi, 0x7828F08E26A8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       G_M000_IG139
 
G_M000_IG464:                ;; offset=0x2E55
       mov      rdx, gword ptr [rbx+0x18]
       mov      rsi, gword ptr [r14]
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:Create(System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyIteration+Cursor]
       mov      rdx, rax
       mov      rsi, r14
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG104
 
G_M000_IG465:                ;; offset=0x2E79
       lea      rsi, bword ptr [rbx+0x48]
       mov      edi, dword ptr [r14+0x10]
       cmp      edi, dword ptr [rsi+0x08]
       jae      G_M000_IG509
       mov      rsi, bword ptr [rsi]
       mov      r13, gword ptr [rsi+8*rdi]
       mov      rsi, r13
       mov      rdi, 0x7828F093C228
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG467
       mov      rsi, r13
       mov      rdi, 0x7828F0831118
       call     CORINFO_HELP_CHKCASTCLASS
       mov      r13, rax
       cmp      byte  ptr [r13], r13b
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:CheckExecution():this]
       lea      rsi, [rbp-0x78]
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:TryMoveNextCore(byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG466
       xor      r13, r13
       xor      r12d, r12d
       jmp      SHORT G_M000_IG468
 
G_M000_IG466:                ;; offset=0x2EE3
       mov      rdi, gword ptr [rbp-0x78]
       call     [Lokad.Lython.Runtime.PyIterationResult:Yield(System.Object):Lokad.Lython.Runtime.PyIterationResult]
       mov      r13, rax
       mov      r12d, edx
       jmp      SHORT G_M000_IG468
 
G_M000_IG467:                ;; offset=0x2EF5
       mov      rdi, rax
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:MoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       mov      r13, rax
       mov      r12d, edx
 
G_M000_IG468:                ;; offset=0x2F04
       mov      gword ptr [rbp-0x70], r13
       mov      byte  ptr [rbp-0x68], r12b
       cmp      byte  ptr [rbp-0x68], 0
       jne      SHORT G_M000_IG469
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG132
 
G_M000_IG469:                ;; offset=0x2F24
       lea      rdi, [rbp-0x70]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_Value():System.Object:this]
       mov      rdx, rax
       mov      rsi, r14
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG104
 
G_M000_IG470:                ;; offset=0x2F42
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       test     eax, eax
       je       G_M000_IG473
       lea      r13, bword ptr [rbx+0x48]
       mov      r12d, dword ptr [r14+0x10]
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      esi, r12d
       mov      edx, eax
       add      rsi, rdx
       mov      edx, dword ptr [r13+0x08]
       cmp      rsi, rdx
       jbe      SHORT G_M000_IG472
 
G_M000_IG471:                ;; offset=0x2F75
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG472:                ;; offset=0x2F7C
       mov      rsi, bword ptr [r13]
       mov      edx, r12d
       lea      rsi, bword ptr [rsi+8*rdx]
       mov      edx, eax
       mov      rdi, 0x7828EFFFB4D0
       call     [System.Span`1[System.__Canon]:op_Implicit(System.Span`1[System.__Canon]):System.ReadOnlySpan`1[System.__Canon]]
       mov      r13, rax
       mov      r12d, edx
       mov      rdi, gword ptr [rbx+0x18]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      rax, gword ptr [rdi+0x88]
       mov      gword ptr [rbp-0x198], rax
       mov      rdi, 0x7828F04A8090
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x1A0], rax
       mov      r8, gword ptr [r14]
       mov      rsi, r13
       mov      edx, r12d
       mov      r9, gword ptr [rbx+0x18]
       mov      rdi, rax
       mov      rcx, gword ptr [rbp-0x198]
       call     [Lokad.Lython.Runtime.PyTuple:.ctor(System.ReadOnlySpan`1[System.Object],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):this]
       mov      r13, gword ptr [rbp-0x1A0]
       jmp      SHORT G_M000_IG474
 
G_M000_IG473:                ;; offset=0x2FF4
       mov      rsi, 0x782111801968
       mov      r13, gword ptr [rsi]
 
G_M000_IG474:                ;; offset=0x3001
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, rbx
       mov      rsi, r14
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       jmp      G_M000_IG104
 
G_M000_IG475:                ;; offset=0x3022
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       movsxd   rdi, eax
       imul     r13, rdi, 80
       jo       G_M000_IG510
       add      r13, 64
       jo       G_M000_IG510
       mov      rdi, gword ptr [rbx+0x18]
       mov      rdi, gword ptr [rdi+0xA0]
       mov      r12, gword ptr [rdi+0x88]
       mov      rax, gword ptr [r14]
       mov      gword ptr [rbp-0x288], rax
       cmp      byte  ptr [r12], r12b
       mov      rdi, 0x7828F0158E58
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x290], rax
       mov      rdi, rax
       mov      rsi, r12
       mov      rdx, r13
       mov      rcx, gword ptr [rbp-0x288]
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:.ctor(Lokad.Lython.Runtime.MemoryGovernor,long,Lokad.Lython.LythonSourceSpan):this]
       mov      r12, gword ptr [rbp-0x290]
       mov      gword ptr [rbp-0x168], r12
 
G_M000_IG476:                ;; offset=0x309C
       mov      rdi, gword ptr [rbx+0x18]
       mov      rax, gword ptr [r14]
       mov      gword ptr [rbp-0x298], rax
       mov      rdi, gword ptr [rdi+0xA0]
       cmp      byte  ptr [rdi], dil
       xor      ecx, ecx
       mov      gword ptr [rbp-0x120], rcx
       mov      rcx, gword ptr [rdi+0x88]
       mov      rcx, gword ptr [rcx+0x20]
       test     rcx, rcx
       je       SHORT G_M000_IG477
       mov      rdi, rcx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG477:                ;; offset=0x30D6
       mov      rdi, gword ptr [rdi+0x178]
       mov      gword ptr [rbp-0x120], rdi
       lea      rdi, [rbp-0x120]
       call     [System.Threading.CancellationToken:get_IsCancellationRequested():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG478
       mov      rdi, gword ptr [rbp-0x298]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
 
G_M000_IG478:                ;; offset=0x3102
       lea      rax, bword ptr [rbx+0x48]
       mov      bword ptr [rbp-0x1A8], rax
       mov      ecx, dword ptr [r14+0x10]
       mov      dword ptr [rbp-0xA4], ecx
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x124], eax
       mov      esi, dword ptr [rbp-0xA4]
       mov      edi, esi
       mov      ecx, eax
       add      rdi, rcx
       mov      rcx, bword ptr [rbp-0x1A8]
       mov      edx, dword ptr [rcx+0x08]
       cmp      rdi, rdx
       jbe      SHORT G_M000_IG479
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG479:                ;; offset=0x3149
       mov      rdi, bword ptr [rcx]
       mov      esi, esi
       lea      rcx, bword ptr [rdi+8*rsi]
       mov      bword ptr [rbp-0x2B0], rcx
       test     eax, eax
       jne      SHORT G_M000_IG480
       mov      rax, 0x782111800F80
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x2A0], rax
       jmp      SHORT G_M000_IG481
 
G_M000_IG480:                ;; offset=0x3173
       movsxd   rsi, eax
       mov      rdi, 0x7828EF0827A0
       call     CORINFO_HELP_NEWARR_1_PTR
       mov      gword ptr [rbp-0x2A8], rax
       lea      rdi, bword ptr [rax+0x10]
       mov      edx, dword ptr [rbp-0x124]
       shl      rdx, 3
       mov      rsi, bword ptr [rbp-0x2B0]
       call     [System.Buffer:BulkMoveWithWriteBarrier(byref,byref,nuint)]
       mov      rax, gword ptr [rbp-0x2A8]
       mov      gword ptr [rbp-0x2A0], rax
 
G_M000_IG481:                ;; offset=0x31B5
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rdi, r12
       mov      rsi, r13
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:Commit(long):this]
       mov      rsi, gword ptr [rbx+0x18]
       mov      rsi, gword ptr [rsi+0xA0]
       mov      rsi, gword ptr [rsi+0x88]
       mov      rdx, gword ptr [r14]
       mov      rdi, gword ptr [rbp-0x2A0]
       call     [Lokad.Lython.Runtime.PyList:FromTransferredArray(System.Object[],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyList]
       mov      rdx, rax
       mov      rsi, r14
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,System.Object):this]
       nop      
 
G_M000_IG482:                ;; offset=0x3200
       mov      rdi, r12
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:Dispose():this]
       jmp      G_M000_IG104
 
G_M000_IG483:                ;; offset=0x320E
       mov      rdi, rbx
       mov      rsi, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Format(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG104
       jmp      G_M000_IG139
 
G_M000_IG484:                ;; offset=0x3227
       mov      rdi, r14
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG172
 
G_M000_IG485:                ;; offset=0x3235
       mov      rdi, rbx
       mov      esi, r12d
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG175
 
G_M000_IG486:                ;; offset=0x3246
       mov      rsi, bword ptr [rbp-0x88]
       mov      eax, edi
       lea      rsi, bword ptr [rsi+2*rax]
       mov      eax, dword ptr [rbp-0x80]
       sub      eax, edi
       cmp      eax, 26
       jb       SHORT G_M000_IG487
       vmovups  ymm0, ymmword ptr [reloc @RWD192]
       vmovups  ymmword ptr [rsi], ymm0
       vmovups  xmm0, xmmword ptr [reloc @RWD224]
       vmovups  xmmword ptr [rsi+0x20], xmm0
       mov      dword ptr [rsi+0x30], 0x20003A
       mov      edi, dword ptr [rbp-0x90]
       add      edi, 26
       mov      dword ptr [rbp-0x90], edi
       jmp      SHORT G_M000_IG488
 
G_M000_IG487:                ;; offset=0x328E
       lea      rdi, [rbp-0xA0]
       mov      rsi, 0x7828EC25C048
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:GrowThenCopyString(System.String):this]
 
G_M000_IG488:                ;; offset=0x32A5
       mov      esi, dword ptr [r14+0x1C]
       lea      rdi, [rbp-0xA0]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rdi, 0x7828EF797A68
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       lea      rdi, [rbp-0xA0]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      rsi, rax
       mov      rdi, r14
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, r14
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG489:                ;; offset=0x32EA
       mov      rdi, rcx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG490:                ;; offset=0x32F3
       lea      rdi, [rbp-0xA0]
       mov      esi, 26
       mov      edx, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
       mov      edi, dword ptr [rbp-0x90]
       cmp      edi, dword ptr [rbp-0x80]
       jbe      G_M000_IG486
       jmp      G_M000_IG471
 
G_M000_IG491:                ;; offset=0x331E
       mov      rsi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rsi+0x9C]
       mov      rdi, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG142
 
G_M000_IG492:                ;; offset=0x3336
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, rbx
       xor      edx, edx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Read(int,int):System.Object:this]
       mov      rsi, rax
       mov      rdi, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      esi, dword ptr [r14+0x10]
       mov      rdi, gword ptr [rbx+0x08]
       cmp      esi, dword ptr [rdi+0x9C]
       jl       SHORT G_M000_IG491
       lea      rsi, bword ptr [rbx+0x48]
       mov      edi, dword ptr [r14+0x10]
       cmp      edi, dword ptr [rsi+0x08]
       jae      G_M000_IG509
       mov      rsi, bword ptr [rsi]
       xor      rax, rax
       mov      gword ptr [rsi+8*rdi], rax
       jmp      SHORT G_M000_IG491
 
G_M000_IG493:                ;; offset=0x337C
       mov      rdi, r14
       mov      rsi, 0x7828EC257C98
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG494:                ;; offset=0x3398
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG495:                ;; offset=0x339F
       mov      rdi, rcx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG496:                ;; offset=0x33A8
       mov      rdi, r13
       mov      rsi, 0x7828EC257CC8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG497:                ;; offset=0x33C4
       mov      rdi, r14
       mov      rsi, 0x7828EC257CC8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG498:                ;; offset=0x33E0
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x20]
       mov      r11, 0x7828EDE630F0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdi, rax
       mov      rsi, r12
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG499:                ;; offset=0x340A
       mov      rdi, rcx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG500:                ;; offset=0x3413
       mov      rdi, r13
       mov      rsi, 0x7828EC257CC8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG501:                ;; offset=0x342F
       mov      edi, 4
       call     [System.ThrowHelper:ThrowArgumentNullException(int)]
       int3     
 
G_M000_IG502:                ;; offset=0x343B
       call     [System.ThrowHelper:ThrowInvalidOperationException_ConcurrentOperationsNotSupported()]
       int3     
 
G_M000_IG503:                ;; offset=0x3442
       mov      rdi, r12
       mov      rsi, r13
       call     [Lokad.Lython.Runtime.RuntimeErrors:NameNotDefined(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG504:                ;; offset=0x3457
       mov      rdi, rcx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG505:                ;; offset=0x3460
       mov      rdi, r13
       mov      rsi, 0x7828EC257CC8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG506:                ;; offset=0x347C
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x20]
       mov      r11, 0x7828EDE63140
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r15, rax
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rbx+0x38]
       xor      edx, edx
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rsi, rax
       mov      rdi, r15
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG507:                ;; offset=0x34BA
       mov      rdi, gword ptr [rbx+0x08]
       mov      rdi, gword ptr [rdi+0x20]
       mov      r11, 0x7828EDE63150
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r15, rax
       mov      rdi, gword ptr [rbx+0x08]
       mov      esi, dword ptr [rbx+0x38]
       mov      edx, 1
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rsi, rax
       mov      rdi, r15
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG508:                ;; offset=0x34FB
       mov      rdi, r14
       mov      rsi, 0x7828EC25A5F0
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG509:                ;; offset=0x3517
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG510:                ;; offset=0x351D
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG511:                ;; offset=0x3523
       sub      rsp, 24
 
G_M000_IG512:                ;; offset=0x3527
       mov      rdi, gword ptr [rbp-0x168]
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:Dispose():this]
       nop      
 
G_M000_IG513:                ;; offset=0x3535
       vzeroupper 
       add      rsp, 24
       ret      
 
G_M000_IG514:                ;; offset=0x353D
       sub      rsp, 24
 
G_M000_IG515:                ;; offset=0x3541
       mov      rdi, gword ptr [rbp-0x248]
       call     [Lokad.Lython.Runtime.MemoryGovernor+TemporaryMemoryReservation:Dispose():this]
       nop      
 
G_M000_IG516:                ;; offset=0x354F
       vzeroupper 
       add      rsp, 24
       ret      
 
RWD00  	dd	0000219Dh ; case G_M000_IG372
       	dd	00003299h ; case G_M000_IG490
       	dd	00002155h ; case G_M000_IG371
       	dd	00002101h ; case G_M000_IG370
       	dd	00003299h ; case G_M000_IG490
       	dd	00003299h ; case G_M000_IG490
       	dd	00000E1Ch ; case G_M000_IG169
       	dd	00000DECh ; case G_M000_IG165
       	dd	00002FC8h ; case G_M000_IG475
       	dd	00000C2Fh ; case G_M000_IG141
       	dd	00003299h ; case G_M000_IG490
       	dd	00003299h ; case G_M000_IG490
       	dd	00003299h ; case G_M000_IG490
       	dd	00003299h ; case G_M000_IG490
       	dd	00003299h ; case G_M000_IG490
       	dd	00003299h ; case G_M000_IG490
       	dd	00002D15h ; case G_M000_IG462
       	dd	00002E1Fh ; case G_M000_IG465
       	dd	000008C9h ; case G_M000_IG103
       	dd	00000BB7h ; case G_M000_IG134
       	dd	00003299h ; case G_M000_IG490
       	dd	00003299h ; case G_M000_IG490
       	dd	00000977h ; case G_M000_IG109
       	dd	00000977h ; case G_M000_IG109
       	dd	000026DBh ; case G_M000_IG414
       	dd	00000B9Fh ; case G_M000_IG132
       	dd	00000B29h ; case G_M000_IG128
       	dd	00002BBDh ; case G_M000_IG456
       	dd	00003299h ; case G_M000_IG490
       	dd	00003299h ; case G_M000_IG490
       	dd	00003299h ; case G_M000_IG490
       	dd	00003299h ; case G_M000_IG490
       	dd	00003299h ; case G_M000_IG490
       	dd	000032DCh ; case G_M000_IG492
       	dd	000032C4h ; case G_M000_IG491
       	dd	000032C4h ; case G_M000_IG491
       	dd	00003299h ; case G_M000_IG490
       	dd	00003299h ; case G_M000_IG490
       	dd	00002CF1h ; case G_M000_IG461
       	dd	000031B4h ; case G_M000_IG483
       	dd	000031B4h ; case G_M000_IG483
       	dd	000031B4h ; case G_M000_IG483
       	dd	000031B4h ; case G_M000_IG483
       	dd	000031B4h ; case G_M000_IG483
RWD176 	dd	0000192Ch ; case G_M000_IG287
       	dd	00001709h ; case G_M000_IG257
       	dd	00002093h ; case G_M000_IG368
       	dd	00000EB6h ; case G_M000_IG178
RWD192 	dq	00780065006E0055h, 0074006300650070h, 0069002000640065h, 006E0069006C006Eh
RWD224 	dq	0070006F00200065h, 00650064006F0063h

; Total bytes of code 13655

; Assembly listing for method Lokad.Lython.LythonCompiledScript:RunCore(Lokad.Lython.ILythonHost,Lokad.Lython.LythonRunOptions):Lokad.Lython.LythonExecutionResult:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 272
       lea      rbp, [rsp+0x110]
       xor      eax, eax
       mov      qword ptr [rbp-0x108], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqu32 zmmword ptr [rbp-0x100], zmm8
       vmovdqu32 zmmword ptr [rbp-0xC0], zmm8
       vmovdqu32 zmmword ptr [rbp-0x80], zmm8
       vmovdqu  ymmword ptr [rbp-0x40], ymm8
       mov      qword ptr [rbp-0x20], rax
       mov      gword ptr [rbp-0x08], rdi
       mov      gword ptr [rbp-0x10], rsi
       mov      gword ptr [rbp-0x18], rdx
 
G_M000_IG02:                ;; offset=0x0048
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x58], rax
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x60], rax
       cmp      gword ptr [rbp-0x58], 0
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0063
       mov      rdi, 0x7828EFC76F18
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xA8], rax
       mov      rdi, gword ptr [rbp-0xA8]
       mov      rsi, 0x7828EC258838
       call     [System.ObjectDisposedException:.ctor(System.String):this]
       mov      rdi, gword ptr [rbp-0xA8]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG04:                ;; offset=0x009D
       mov      rax, gword ptr [rbp-0x60]
       mov      gword ptr [rbp-0x20], rax
       cmp      gword ptr [rbp-0x18], 0
       jne      SHORT G_M000_IG05
       mov      rdi, 0x7828F0CD9360
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, 0x7828EFDD6A60
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xA0], rax
       mov      rdi, gword ptr [rbp-0xA0]
       call     [Lokad.Lython.LythonRunOptions:.ctor():this]
       mov      rax, gword ptr [rbp-0xA0]
       mov      gword ptr [rbp-0x18], rax
 
G_M000_IG05:                ;; offset=0x00E9
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonRunOptions:get_MemoryBudget():Lokad.Lython.ILythonMemoryBudget:this]
       mov      gword ptr [rbp-0x68], rax
       mov      rax, gword ptr [rbp-0x68]
       mov      gword ptr [rbp-0x70], rax
       cmp      gword ptr [rbp-0x68], 0
       jne      SHORT G_M000_IG06
       mov      rax, gword ptr [rbp-0x08]
       mov      rax, gword ptr [rax+0x20]
       mov      gword ptr [rbp-0x90], rax
       mov      rax, gword ptr [rbp-0x90]
       mov      gword ptr [rbp-0x70], rax
       cmp      gword ptr [rbp-0x90], 0
       jne      G_M000_IG10
       mov      rdi, 0x7828F0CD9364
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm0, xmm0, xmm0
       vmovups  xmmword ptr [rbp-0x48], xmm0
       mov      rdi, 0x7828EFD16738
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x98], rax
       mov      rsi, qword ptr [rbp-0x48]
       mov      rdx, qword ptr [rbp-0x40]
       mov      rdi, gword ptr [rbp-0x98]
       call     [Lokad.Lython.LythonMemoryBudget:.ctor(System.Nullable`1[long]):this]
       mov      rax, gword ptr [rbp-0x98]
       mov      gword ptr [rbp-0x70], rax
 
G_M000_IG06:                ;; offset=0x017E
       mov      rax, gword ptr [rbp-0x70]
       mov      gword ptr [rbp-0x28], rax
       mov      rax, gword ptr [rbp-0x28]
       mov      gword ptr [rbp-0xB0], rax
       mov      rdi, gword ptr [rbp-0xB0]
       mov      rsi, 0x7828F0CD9368
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0xB0]
       mov      gword ptr [rbp-0xD8], rax
       mov      rdi, gword ptr [rbp-0xD8]
       mov      r11, 0x7828EDE63BE8
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      gword ptr [rbp-0x30], rax
 
G_M000_IG07:                ;; offset=0x01CD
       mov      rdi, gword ptr [rbp-0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonRunOptions:get_ResultMemoryBudget():Lokad.Lython.ILythonMemoryBudget:this]
       mov      gword ptr [rbp-0x78], rax
       mov      rax, gword ptr [rbp-0x78]
       mov      gword ptr [rbp-0x80], rax
       cmp      gword ptr [rbp-0x78], 0
       jne      SHORT G_M000_IG08
       mov      rdi, 0x7828F0CD9470
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x28]
       mov      gword ptr [rbp-0x80], rax
 
G_M000_IG08:                ;; offset=0x0203
       mov      rax, gword ptr [rbp-0x80]
       mov      gword ptr [rbp-0xB8], rax
       mov      rdi, gword ptr [rbp-0xB8]
       mov      rsi, 0x7828F0CD9478
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0xB8]
       mov      gword ptr [rbp-0xE0], rax
       mov      rdi, gword ptr [rbp-0xE0]
       mov      r11, 0x7828EDE63BF0
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      gword ptr [rbp-0x38], rax
 
G_M000_IG09:                ;; offset=0x024A
       mov      rax, gword ptr [rbp-0x20]
       mov      gword ptr [rbp-0xC0], rax
       mov      rdi, gword ptr [rbp-0xC0]
       mov      rsi, 0x7828F0CD9580
       call     CORINFO_HELP_DELEGATEPROFILE32
       mov      rax, gword ptr [rbp-0xC0]
       mov      gword ptr [rbp-0xE8], rax
       mov      rdi, gword ptr [rbp-0x18]
       mov      rsi, gword ptr [rbp-0x30]
       mov      rdx, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonRunOptions:WithMemoryOwners(Lokad.Lython.ILythonMemoryBudget,Lokad.Lython.ILythonMemoryBudget):Lokad.Lython.LythonRunOptions:this]
       mov      gword ptr [rbp-0xF0], rax
       mov      rax, gword ptr [rbp-0xE8]
       mov      rdx, gword ptr [rbp-0xF0]
       mov      rsi, gword ptr [rbp-0x10]
       mov      rdi, gword ptr [rax+0x10]
       mov      rax, gword ptr [rbp-0xE8]
       call     [rax+0x18]System.Func`3[System.__Canon,System.__Canon,System.__Canon]:Invoke(System.__Canon,System.__Canon):System.__Canon:this
       mov      gword ptr [rbp-0xF8], rax
       mov      rdi, gword ptr [rbp-0xF8]
       mov      rsi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.LythonExecutionResult:OwnMemoryScope(Lokad.Lython.ILythonMemoryScope):Lokad.Lython.LythonExecutionResult:this]
       mov      gword ptr [rbp-0x50], rax
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x02D4
       mov      rdi, 0x7828F0CD9790
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG06
 
G_M000_IG11:                ;; offset=0x02E8
       call     G_M000_IG16
       nop      
 
G_M000_IG12:                ;; offset=0x02EE
       mov      rdi, 0x7828F0CD98A4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x50]
 
G_M000_IG13:                ;; offset=0x0301
       add      rsp, 272
       pop      rbp
       ret      
 
G_M000_IG14:                ;; offset=0x030A
       push     rax
 
G_M000_IG15:                ;; offset=0x030B
       mov      gword ptr [rbp-0x88], rdi
       mov      rax, gword ptr [rbp-0x38]
       mov      gword ptr [rbp-0xC8], rax
       mov      rdi, gword ptr [rbp-0xC8]
       mov      rsi, 0x7828F0CD9688
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0xC8]
       mov      gword ptr [rbp-0x100], rax
       mov      rdi, gword ptr [rbp-0x100]
       mov      r11, 0x7828EDE63BF8
       call     [r11]System.IDisposable:Dispose():this
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG16:                ;; offset=0x035B
       push     rax
 
G_M000_IG17:                ;; offset=0x035C
       cmp      gword ptr [rbp-0x30], 0
       je       SHORT G_M000_IG18
       mov      rdi, 0x7828F0CD9794
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x30]
       mov      gword ptr [rbp-0xD0], rax
       mov      rdi, gword ptr [rbp-0xD0]
       mov      rsi, 0x7828F0CD9798
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rbp-0x108], rax
       mov      rdi, gword ptr [rbp-0x108]
       mov      r11, 0x7828EDE63C00
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG18:                ;; offset=0x03B5
       mov      rdi, 0x7828F0CD98A0
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG19:                ;; offset=0x03C5
       add      rsp, 8
       ret      
 
; Total bytes of code 970

; Assembly listing for method Lokad.Lython.LythonCompiledScript:RunCore(Lokad.Lython.ILythonHost,Lokad.Lython.LythonRunOptions):Lokad.Lython.LythonExecutionResult:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 115
; 16 inlinees with PGO data; 70 single block inlinees; 8 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 232
       lea      rbp, [rsp+0x110]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu32 zmmword ptr [rbp-0xB0], zmm8
       vmovdqu32 zmmword ptr [rbp-0x80], zmm8
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      r15, rsi
       mov      rbx, rdx
 
G_M000_IG02:                ;; offset=0x003B
       mov      r14, gword ptr [rdi+0x08]
       test     r14, r14
       je       G_M000_IG66
       test     rbx, rbx
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x004D
       mov      rax, 0x7828EFDD6A60
       mov      qword ptr [rbp-0xB0], rax
       lea      rbx, [rbp-0xB0]
 
G_M000_IG04:                ;; offset=0x0065
       mov      r13, gword ptr [rbx+0x38]
       test     r13, r13
       jne      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x006E
       mov      r13, gword ptr [rdi+0x20]
       test     r13, r13
       je       G_M000_IG67
 
G_M000_IG06:                ;; offset=0x007B
       mov      rdi, 0x7828EFD16738
       cmp      qword ptr [r13], rdi
       jne      G_M000_IG68
       mov      r12, gword ptr [r13+0x10]
       mov      rdi, gword ptr [r12+0x08]
       mov      rdi, gword ptr [rdi+0x08]
       mov      gword ptr [rbp-0xC8], rdi
       xor      edi, edi
       mov      dword ptr [rbp-0x2C], edi
 
G_M000_IG07:                ;; offset=0x00A8
       mov      rdi, gword ptr [rbp-0xC8]
       call     [System.Threading.Monitor:Enter(System.Object)]
       mov      dword ptr [rbp-0x2C], 1
       cmp      byte  ptr [r12+0x38], 0
       jne      G_M000_IG10
       mov      rdi, 0x7828EFD16B38
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xD0], rax
       mov      rsi, gword ptr [r12+0x08]
       lea      rdi, bword ptr [rax+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0xD0]
       lea      rdi, bword ptr [rax+0x10]
       mov      rsi, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [r12+0x18]
       mov      gword ptr [rbp-0x100], rax
       mov      rcx, gword ptr [rbp-0xD0]
       lea      rdi, bword ptr [rcx+0x20]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbp-0x100]
       test     rsi, rsi
       je       SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x012A
       lea      rdi, bword ptr [rsi+0x28]
       mov      rsi, gword ptr [rbp-0xD0]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG09:                ;; offset=0x013A
       lea      rdi, bword ptr [r12+0x18]
       mov      rsi, gword ptr [rbp-0xD0]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x014D
       mov      rdi, r12
       call     [System.ThrowHelper:ThrowObjectDisposedException(System.Object)]
       int3     
 
G_M000_IG11:                ;; offset=0x0157
       mov      rdi, gword ptr [rbp-0xC8]
       call     [System.Threading.Monitor:Exit(System.Object)]
       mov      r12, gword ptr [rbp-0xD0]
 
G_M000_IG12:                ;; offset=0x016B
       mov      gword ptr [rbp-0xB8], r12
 
G_M000_IG13:                ;; offset=0x0172
       mov      rdi, gword ptr [rbx+0x40]
       test     rdi, rdi
       cmove    rdi, r13
       mov      rax, 0x7828EFD16738
       cmp      qword ptr [rdi], rax
       jne      G_M000_IG62
       mov      r13, gword ptr [rdi+0x10]
       mov      rdi, gword ptr [r13+0x08]
       mov      rdi, gword ptr [rdi+0x08]
       mov      gword ptr [rbp-0xD8], rdi
       xor      edi, edi
       mov      dword ptr [rbp-0x30], edi
 
G_M000_IG14:                ;; offset=0x01A8
       mov      rdi, gword ptr [rbp-0xD8]
       call     [System.Threading.Monitor:Enter(System.Object)]
       mov      dword ptr [rbp-0x30], 1
       cmp      byte  ptr [r13+0x38], 0
       jne      G_M000_IG17
       mov      rdi, 0x7828EFD16B38
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xE0], rax
       mov      rsi, gword ptr [r13+0x08]
       lea      rdi, bword ptr [rax+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0xE0]
       lea      rdi, bword ptr [rax+0x10]
       mov      rsi, r13
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [r13+0x18]
       mov      gword ptr [rbp-0x108], rax
       mov      rcx, gword ptr [rbp-0xE0]
       lea      rdi, bword ptr [rcx+0x20]
       mov      rsi, rax
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbp-0x108]
       test     rsi, rsi
       je       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0227
       lea      rdi, bword ptr [rsi+0x28]
       mov      rsi, gword ptr [rbp-0xE0]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG16:                ;; offset=0x0237
       lea      rdi, bword ptr [r13+0x18]
       mov      rsi, gword ptr [rbp-0xE0]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0249
       mov      rdi, r13
       call     [System.ThrowHelper:ThrowObjectDisposedException(System.Object)]
       int3     
 
G_M000_IG18:                ;; offset=0x0253
       mov      rdi, gword ptr [rbp-0xD8]
       call     [System.Threading.Monitor:Exit(System.Object)]
       mov      r13, gword ptr [rbp-0xE0]
 
G_M000_IG19:                ;; offset=0x0267
       mov      gword ptr [rbp-0xC0], r13
 
G_M000_IG20:                ;; offset=0x026E
       mov      rax, gword ptr [rbx+0x60]
       mov      gword ptr [rbp-0xF8], rax
       mov      rdi, 0x7828EFDD6A60
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0xE8], rax
       mov      rsi, gword ptr [rbx+0x08]
       lea      rdi, bword ptr [rax+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbx+0x10]
       mov      rax, gword ptr [rbp-0xE8]
       lea      rdi, bword ptr [rax+0x10]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbx+0x18]
       mov      rax, gword ptr [rbp-0xE8]
       lea      rdi, bword ptr [rax+0x18]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbx+0x20]
       mov      rax, gword ptr [rbp-0xE8]
       lea      rdi, bword ptr [rax+0x20]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rax, gword ptr [rbp-0xE8]
       lea      rdi, bword ptr [rax+0x60]
       mov      rsi, gword ptr [rbp-0xF8]
       call     CORINFO_HELP_ASSIGN_REF
       movzx    rdi, byte  ptr [rbx+0x58]
       mov      rax, gword ptr [rbp-0xE8]
       mov      byte  ptr [rax+0x58], dil
       mov      rsi, gword ptr [rbx+0x28]
       lea      rdi, bword ptr [rax+0x28]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbx+0x30]
       mov      rax, gword ptr [rbp-0xE8]
       lea      rdi, bword ptr [rax+0x30]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, qword ptr [rbx+0x68]
       mov      rax, gword ptr [rbp-0xE8]
       mov      qword ptr [rax+0x68], rdi
       mov      rsi, gword ptr [rbx+0x38]
       lea      rdi, bword ptr [rax+0x38]
 
G_M000_IG21:                ;; offset=0x0337
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbx+0x40]
       mov      rbx, gword ptr [rbp-0xE8]
       lea      rdi, bword ptr [rbx+0x40]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [rbx+0x48]
       mov      rsi, r12
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [rbx+0x50]
       mov      rsi, r13
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, 0x7828F008A1D8
       cmp      qword ptr [r14+0x18], rdi
       jne      G_M000_IG61
       mov      r14, gword ptr [r14+0x10]
       mov      rdi, r14
       call     [Lokad.Lython.LythonEngine+<>c__DisplayClass8_0:<CompileCore>g__CreatePreExecutionFailure|1():Lokad.Lython.LythonExecutionResult:this]
       mov      r13, rax
       test     r13, r13
       jne      G_M000_IG57
       mov      rdi, 0x7828F0396208
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       mov      rsi, gword ptr [r14+0x10]
       mov      r12, gword ptr [r14+0x18]
       lea      rdi, bword ptr [r13+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r13+0x10]
       mov      rsi, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      r14, gword ptr [r14+0x20]
       test     r14, r14
       je       G_M000_IG58
       mov      rdi, 0x7828F07FD6F8
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
 
G_M000_IG22:                ;; offset=0x03E3
       lea      rdi, bword ptr [r12+0x08]
       mov      rsi, r15
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r12+0x10]
       mov      rsi, rbx
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r12+0x18]
       mov      rsi, r13
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r12+0x20]
       mov      rsi, r14
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, 0x7828F07FD778
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       lea      rdi, bword ptr [r15+0x10]
       mov      rsi, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, 0x7828F0801308
       mov      qword ptr [r15+0x18], rdi
       mov      rdi, 0x782111803120
       mov      rbx, gword ptr [rdi]
       mov      rdi, 0x78296D3013F0
       mov      rax, 0x78296DC78810
       call     rax
       cmp      dword ptr [rax], 4
       jle      G_M000_IG59
       mov      rdi, gword ptr [rax+0x08]
       mov      rax, bword ptr [rdi+0x20]
       test     rax, rax
       je       G_M000_IG59
 
G_M000_IG23:                ;; offset=0x0480
       mov      rax, gword ptr [rax+0x10]
       test     rax, rax
       jne      SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x0489
       call     [System.Threading.Thread:InitializeCurrentThread():System.Threading.Thread]
 
G_M000_IG25:                ;; offset=0x048F
       mov      r14, gword ptr [rax+0x08]
       test     r14, r14
       jne      G_M000_IG60
       mov      rdi, 0x782111801158
       mov      r14, gword ptr [rdi]
 
G_M000_IG26:                ;; offset=0x04A9
       mov      rdi, 0x7828F07FDB08
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       mov      rdi, 0x7828EDE54828
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       lea      rdi, bword ptr [r13+0x18]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r13+0x20]
       mov      rsi, r15
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r13+0x08]
       mov      rsi, r14
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, gword ptr [rbx+0x08]
       mov      gword ptr [rbp-0xF0], rdi
       xor      edi, edi
       mov      dword ptr [rbp-0x34], edi
 
G_M000_IG27:                ;; offset=0x04FE
       mov      rdi, gword ptr [rbp-0xF0]
       call     [System.Threading.Monitor:Enter(System.Object)]
       mov      dword ptr [rbp-0x34], 1
       cmp      byte  ptr [rbx+0x20], 0
       jne      G_M000_IG45
       mov      r15, gword ptr [rbx+0x10]
       mov      r14, gword ptr [r15+0x08]
       test     r14, r14
       je       G_M000_IG51
       cmp      byte  ptr [r15], r15b
       cmp      gword ptr [r14+0x08], r15
       jne      G_M000_IG46
       cmp      gword ptr [r14+0x10], r14
       jne      G_M000_IG47
       xor      rdi, rdi
       mov      gword ptr [r15+0x08], rdi
 
G_M000_IG28:                ;; offset=0x054A
       xor      rdi, rdi
       mov      gword ptr [r14+0x08], rdi
 
G_M000_IG29:                ;; offset=0x0550
       mov      gword ptr [r14+0x10], rdi
 
G_M000_IG30:                ;; offset=0x0554
       mov      gword ptr [r14+0x18], rdi
       dec      dword ptr [r15+0x18]
       inc      dword ptr [r15+0x1C]
       mov      rdi, gword ptr [r14+0x20]
       xor      rsi, rsi
       mov      gword ptr [rdi+0x20], rsi
       lea      rdi, bword ptr [rdi+0x18]
       mov      rsi, r13
       call     CORINFO_HELP_ASSIGN_REF
       mov      rbx, gword ptr [rbx+0x08]
       test     rbx, rbx
       je       G_M000_IG48
       mov      rdi, rbx
       call     System.Threading.ObjectHeader:GetLockHandleIfExists(System.Object):nint
       test     rax, rax
       je       G_M000_IG40
 
G_M000_IG31:                ;; offset=0x0594
       mov      r15, gword ptr [rax]
 
G_M000_IG32:                ;; offset=0x0597
       cmp      byte  ptr [r15], r15b
 
G_M000_IG33:                ;; offset=0x059A
       mov      rbx, gword ptr [r15+0x08]
       test     rbx, rbx
       jne      G_M000_IG41
 
G_M000_IG34:                ;; offset=0x05A7
       mov      rdi, 0x7828F00B94C0
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       lea      rdi, bword ptr [r14+0x08]
       mov      rsi, r15
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [r15+0x08]
       test     rsi, rsi
       jne      SHORT G_M000_IG43
 
G_M000_IG35:                ;; offset=0x05CE
       mov      rdi, rsi
       test     rdi, rdi
       je       SHORT G_M000_IG37
 
G_M000_IG36:                ;; offset=0x05D6
       mov      rax, 0x7828F00A3EB8
       cmp      qword ptr [rdi], rax
       jne      G_M000_IG49
 
G_M000_IG37:                ;; offset=0x05E9
       mov      rsi, rdi
 
G_M000_IG38:                ;; offset=0x05EC
       lea      rdi, bword ptr [r14+0x10]
       call     CORINFO_HELP_ASSIGN_REF
       lea      rdi, bword ptr [r15+0x08]
       test     rdi, rdi
       je       G_M000_IG50
       mov      rsi, r14
       mov      rdx, rbx
       call     System.Threading.Interlocked:CompareExchangeObject(byref,System.Object,System.Object):System.Object
       cmp      rax, rbx
       jne      SHORT G_M000_IG33
       mov      rdi, r14
 
G_M000_IG39:                ;; offset=0x0615
       call     [System.Threading.Condition:SignalAll():this]
       jmp      G_M000_IG55
 
G_M000_IG40:                ;; offset=0x0620
       mov      rdi, rbx
       call     [System.Threading.ObjectHeader:<GetLockObject>g__GetLockObjectFallback|11_0(System.Object):System.Threading.Lock]
       mov      r15, rax
       jmp      G_M000_IG32
 
G_M000_IG41:                ;; offset=0x0631
       mov      rdi, 0x7828F00B94C0
       cmp      qword ptr [rbx], rdi
       jne      G_M000_IG34
 
G_M000_IG42:                ;; offset=0x0644
       mov      rdi, rbx
       jmp      SHORT G_M000_IG39
 
G_M000_IG43:                ;; offset=0x0649
       mov      rdi, 0x7828F00B94C0
       cmp      qword ptr [rsi], rdi
       jne      G_M000_IG35
 
G_M000_IG44:                ;; offset=0x065C
       mov      rsi, gword ptr [rsi+0x10]
       jmp      SHORT G_M000_IG38
 
G_M000_IG45:                ;; offset=0x0662
       mov      rdi, rbx
       call     [System.ThrowHelper:ThrowObjectDisposedException(System.Object)]
       int3     
 
G_M000_IG46:                ;; offset=0x066C
       mov      rdi, 0x7828EF797A68
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       call     [System.SR:get_ExternalLinkedListNode():System.String]
       mov      rsi, rax
       mov      rdi, r13
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, r13
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG47:                ;; offset=0x0699
       mov      rdi, gword ptr [r14+0x10]
       lea      rdi, bword ptr [rdi+0x18]
       mov      rsi, gword ptr [r14+0x18]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdi, gword ptr [r14+0x18]
       lea      rdi, bword ptr [rdi+0x10]
       mov      rsi, gword ptr [r14+0x10]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [r14+0x10]
       lea      rdi, bword ptr [r15+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      G_M000_IG28
 
G_M000_IG48:                ;; offset=0x06CD
       mov      rdi, 0x7828EC2007E8
       call     [System.ArgumentNullException:Throw(System.String)]
       int3     
 
G_M000_IG49:                ;; offset=0x06DE
       mov      rdi, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG50:                ;; offset=0x06E7
       call     [System.ThrowHelper:ThrowNullReferenceException()]
       int3     
 
G_M000_IG51:                ;; offset=0x06EE
       mov      rdi, 0x7828F0647320
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rdi, r15
       mov      rsi, rbx
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.ExecutionThreads+Worker:.ctor(Lokad.Lython.Runtime.ExecutionThreads,Lokad.Lython.Runtime.ExecutionThreads+WorkItem):this]
       call     [System.Threading.ExecutionContext:IsFlowSuppressed():bool]
       test     eax, eax
       je       SHORT G_M000_IG52
       mov      rdi, gword ptr [r15+0x10]
       cmp      byte  ptr [rdi], dil
       mov      esi, 1
       call     [System.Threading.Thread:Start(bool):this]
       jmp      SHORT G_M000_IG55
 
G_M000_IG52:                ;; offset=0x072D
       call     [System.Threading.ExecutionContext:SuppressFlow():System.Threading.AsyncFlowControl]
       mov      gword ptr [rbp-0x40], rax
 
G_M000_IG53:                ;; offset=0x0737
       mov      rdi, gword ptr [r15+0x10]
       cmp      byte  ptr [rdi], dil
       mov      esi, 1
       call     [System.Threading.Thread:Start(bool):this]
       nop      
 
G_M000_IG54:                ;; offset=0x074A
       lea      rdi, [rbp-0x40]
       call     [System.Threading.AsyncFlowControl:Undo():this]
       nop      
 
G_M000_IG55:                ;; offset=0x0755
       mov      rdi, gword ptr [rbp-0xF0]
       call     [System.Threading.Monitor:Exit(System.Object)]
       mov      rdi, r13
       call     [Lokad.Lython.Runtime.ExecutionThreads+SynchronousWorkItem:Wait():Lokad.Lython.LythonExecutionResult:this]
       mov      r15, rax
 
G_M000_IG56:                ;; offset=0x076E
       lea      rdi, bword ptr [r15+0x28]
       mov      rsi, gword ptr [rbp-0xC0]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      SHORT G_M000_IG63
 
G_M000_IG57:                ;; offset=0x0780
       mov      r15, r13
       jmp      SHORT G_M000_IG56
 
G_M000_IG58:                ;; offset=0x0785
       mov      rdi, 0x7828EF797A68
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rdi, r15
       mov      rsi, 0x7828EC20F098
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, r15
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG59:                ;; offset=0x07B3
       mov      edi, 4
       call     CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED
       jmp      G_M000_IG23
 
G_M000_IG60:                ;; offset=0x07C2
       xor      rdi, rdi
       cmp      byte  ptr [r14+0x18], 0
       cmovne   r14, rdi
       jmp      G_M000_IG26
 
G_M000_IG61:                ;; offset=0x07D2
       mov      rsi, r15
       mov      rdx, rbx
       mov      rdi, gword ptr [r14+0x10]
       call     [r14+0x18]System.Func`3[System.__Canon,System.__Canon,System.__Canon]:Invoke(System.__Canon,System.__Canon):System.__Canon:this
       mov      r15, rax
       jmp      SHORT G_M000_IG56
 
G_M000_IG62:                ;; offset=0x07E5
       mov      r11, 0x7828EDE64D98
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      r13, rax
       jmp      G_M000_IG19
 
G_M000_IG63:                ;; offset=0x07FA
       cmp      gword ptr [rbp-0xB8], 0
       je       SHORT G_M000_IG64
       mov      rdi, 0x7828EFD16B38
       mov      rax, gword ptr [rbp-0xB8]
       cmp      qword ptr [rax], rdi
       jne      G_M000_IG69
       mov      rdi, rax
       call     [Lokad.Lython.LythonMemoryBudget+Scope:Dispose():this]
 
G_M000_IG64:                ;; offset=0x0827
       mov      rax, r15
 
G_M000_IG65:                ;; offset=0x082A
       add      rsp, 232
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG66:                ;; offset=0x083C
       mov      rdi, 0x7828EFC76F18
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rdi, rbx
       mov      rsi, 0x7828EC258838
       call     [System.ObjectDisposedException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG67:                ;; offset=0x086A
       mov      rdi, 0x7828EFD16738
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       xor      esi, esi
       xor      edx, edx
       mov      rdi, r13
       call     [Lokad.Lython.LythonMemoryBudget:.ctor(System.Nullable`1[long]):this]
       jmp      G_M000_IG06
 
G_M000_IG68:                ;; offset=0x088E
       mov      rdi, r13
       mov      r11, 0x7828EDE64D90
       call     [r11]Lokad.Lython.ILythonMemoryBudget:CreateScope():Lokad.Lython.ILythonMemoryScope:this
       mov      r12, rax
       jmp      G_M000_IG12
 
G_M000_IG69:                ;; offset=0x08A6
       mov      rdi, rax
       mov      r11, 0x7828EDE64DA8
       call     [r11]System.IDisposable:Dispose():this
       jmp      G_M000_IG64
 
G_M000_IG70:                ;; offset=0x08BB
       push     rax
 
G_M000_IG71:                ;; offset=0x08BC
       lea      rdi, [rbp-0x40]
       call     [System.Threading.AsyncFlowControl:Undo():this]
       nop      
 
G_M000_IG72:                ;; offset=0x08C7
       add      rsp, 8
       ret      
 
G_M000_IG73:                ;; offset=0x08CC
       push     rax
 
G_M000_IG74:                ;; offset=0x08CD
       cmp      dword ptr [rbp-0x34], 0
       je       SHORT G_M000_IG75
       mov      rdi, gword ptr [rbp-0xF0]
       call     [System.Threading.Monitor:Exit(System.Object)]
 
G_M000_IG75:                ;; offset=0x08E0
       nop      
 
G_M000_IG76:                ;; offset=0x08E1
       add      rsp, 8
       ret      
 
G_M000_IG77:                ;; offset=0x08E6
       push     rax
 
G_M000_IG78:                ;; offset=0x08E7
       mov      rdi, gword ptr [rbp-0xC0]
       mov      r11, 0x7828EDE64DA0
       call     [r11]System.IDisposable:Dispose():this
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG79:                ;; offset=0x0901
       push     rax
 
G_M000_IG80:                ;; offset=0x0902
       cmp      dword ptr [rbp-0x30], 0
       je       SHORT G_M000_IG81
       mov      rdi, gword ptr [rbp-0xD8]
       call     [System.Threading.Monitor:Exit(System.Object)]
 
G_M000_IG81:                ;; offset=0x0915
       nop      
 
G_M000_IG82:                ;; offset=0x0916
       add      rsp, 8
       ret      
 
G_M000_IG83:                ;; offset=0x091B
       push     rax
 
G_M000_IG84:                ;; offset=0x091C
       cmp      gword ptr [rbp-0xB8], 0
       je       SHORT G_M000_IG86
       mov      rdi, 0x7828EFD16B38
       mov      rax, gword ptr [rbp-0xB8]
       cmp      qword ptr [rax], rdi
       jne      SHORT G_M000_IG85
       mov      rdi, rax
       call     [Lokad.Lython.LythonMemoryBudget+Scope:Dispose():this]
       jmp      SHORT G_M000_IG86
 
G_M000_IG85:                ;; offset=0x0947
       mov      rdi, rax
       mov      r11, 0x7828EDE64DA8
       call     [r11]System.IDisposable:Dispose():this
 
G_M000_IG86:                ;; offset=0x0957
       nop      
 
G_M000_IG87:                ;; offset=0x0958
       add      rsp, 8
       ret      
 
G_M000_IG88:                ;; offset=0x095D
       push     rax
 
G_M000_IG89:                ;; offset=0x095E
       cmp      dword ptr [rbp-0x2C], 0
       je       SHORT G_M000_IG90
       mov      rdi, gword ptr [rbp-0xC8]
       call     [System.Threading.Monitor:Exit(System.Object)]
 
G_M000_IG90:                ;; offset=0x0971
       nop      
 
G_M000_IG91:                ;; offset=0x0972
       add      rsp, 8
       ret      
 
; Total bytes of code 2423

