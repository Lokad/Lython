from pathlib import Path
import ast,base64,datetime,hashlib,json,subprocess,tarfile
r=Path('.git/agent-notes/review-20261031/fulfillment-stage-r354');r.mkdir(exist_ok=False)
prior=r.parent/'script-stage-r350';current=r.parent/'owned-tuple-return-r353'
image=json.loads((current/'b725/identity.json').read_text(encoding='utf-8'))
proof=json.loads((current/'source-proof.json').read_text(encoding='utf-8'))
subprocess.run(['git','diff','--exit-code',proof['commit'],'HEAD','--','src'],check=True)
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in json.loads((current/'candidate-identity.json').read_text(encoding='utf-8'))['sources'].items())
root='/home/lokad/lython-bench-checks/fulfillment-stage-b726-20261114';oldroot='/home/lokad/lython-bench-checks/script-stage-b721-20261114'
identity=dict(coreSHA256={'candidate':image['coreSHA256']['candidate']},auxiliaryFiles=image['candidateAuxiliaryFiles'],catalogSHA256=image['catalogSHA256'],
 sourceRevision='Committedf5817a15/frozen9cfb7d5b; R354 complete fulfillment stage attribution',sourceProofCommit=proof['commit'],sourceProofSHA256=hashlib.sha256((current/'source-proof.json').read_bytes()).hexdigest(),
 diagnosticOnly=True,scriptCaptureWallSeconds=5,warmGuestSeconds=8,compilationExcluded=True,allocationStacksNotMeasured=True,disassemblyCollectedInTheSameProcessAsSamples=True,
 fullDelivery='43583650094pending independently; previous7e2/frozen72 fully qualified43579225278',noSpeedupForecast=True)
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
prospective=dict(recordedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 hypothesis='R353 removes the wide return tuple and6.77%fulfillment allocation, with modest CPU direction. Prior R350 profiled different invoice/search shapes and does not establish owning costs of the larger fulfillment helper. Identify one complete redundant record/scalar/operand construction stage rather than another entry tweak.',
 question='Which owning stages dominate the complete4096-record fulfillment script after direct owned tuple returns?',
 bound='One5s199Hz cpu-clock/fp capture after8guest-second warmup, existing64invocation requests,120sowner. Exact same-process JIT map/disassembly. Attribution only; no normal timing comparison or automatic extra capture.',
 acceptance='Exact core/all auxiliaries and catalog/source proof, independent output/files, shared-budget balance, quiet before/after, all users joined and every RAM trace byte independently archived/verified before unmount; retain unknown/ambiguous leaves.',
 stopping='Select one coherent eliminated stage with alias/identity/promotion/cleanup contract, or reject candidates using owning evidence and advance the roadmap. A hot method is not a removable share. No speculative arena, per-object identity ledger or new policy.',
 constraints='Managed safety, current cancellation/admission and terminal refusal, retained aliases, managed stack protection. Full delivery runs independently; publication held.')
(r/'prospective.json').write_text(json.dumps(prospective,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['ops-profile.py','collect.py','run.sh','retrieve.py']:
 s=(prior/name).read_text(encoding='utf-8').replace(oldroot,root).replace('lython-b721-script-stage-20261114','lython-b726-fulfillment-stage-20261114')
 s=s.replace('Committede235b18b/frozen71ba421c; R350 complete invoice/search stage attribution',identity['sourceRevision'])
 if name=='ops-profile.py':
  s=s.replace("[('invoice','scripts.csv-invoice.large','warm'),('search','scripts.file-search.large','warm')]","[('fulfillment','scripts.csv-fulfillment.large','warm')]")
  s=s.replace("(64 if name=='invoice' else 512)", '64')
 elif name=='collect.py':s=s.replace("['invoice','search']","['fulfillment']")
 elif name=='retrieve.py':s=s.replace('Two CPU profiles','One CPU profile')
 if name.endswith('.py'):ast.parse(s)
 (r/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(r/'payload.tgz','w:gz')as t:
 for name in ['ops-profile.py','collect.py','run.sh','identity.json','prospective.json']:t.add(r/name,arcname=name)
with tarfile.open(r/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
config=dict(root=root,sourceRoot='/home/lokad/lython-bench-checks/owned-return-b725-20261114',unit='lython-b726-fulfillment-stage-20261114',identity=identity,
 payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((r/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(r/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
code=r'''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
config=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['sourceRoot']);digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert root.parent==base and not root.exists()and source.parent==base and source.resolve()==source
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(os.path.ismount(p)for p in base.glob('*/guest-fixtures'))
 state=subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=LoadState,MainPID'],text=True)
 assert 'LoadState=not-found'in state and 'MainPID=0'in state
 assert(source/'exit-code.txt').read_text().strip()=='0'and json.loads((source/'archive-receipt.json').read_text())['complete']
 assert digest(source/'candidate/Lokad.Lython.dll')==config['identity']['coreSHA256']['candidate']
 for name,sha in config['identity']['auxiliaryFiles'].items():assert digest(source/'candidate'/name)==sha
 assert digest(source/'representative.json')==config['identity']['catalogSHA256']
 payload=sys.stdin.buffer.read(config['payloadBytes']+1)
 assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 before=shutil.disk_usage(base).free;assert before>254*1024*1024+config['unpackedBytes']+32768
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as t:t.extractall(root,filter='data')
 (root/'candidate').mkdir()
 for name in [*config['identity']['auxiliaryFiles'],'Lokad.Lython.dll']:os.link(source/'candidate'/name,root/'candidate'/name)
 os.link(source/'representative.json',root/'catalog.json')
 for name in ['ops-profile.py','collect.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture=root/'guest-fixtures';fixture.mkdir();assert shutil.disk_usage(base).free>254*1024*1024
 (root/'space-preflight.json').write_text(json.dumps(dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,noNewCoreOrCatalogUpload=True,noRetirement=True,floorsUnchanged=True))+chr(10))
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b726-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=120','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True))
'''.replace('CONFIG',repr(config));ast.parse(code)
(r/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
p=subprocess.run(ssh+[command],input=(r/'payload.tgz').read_bytes(),capture_output=True,timeout=45)
(r/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode()
now=datetime.datetime.now(datetime.timezone.utc)
(r/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=90)).isoformat(),ownerSeconds=120,stopSeconds=30),indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');(r/'PLAN-before-source-gate.md').write_text(s,encoding='utf-8',newline='\n')
a=s.index('   Next source investigation:');b=s.index('   | Area / representative scripts |',a)
s=s[:a]+'''   **R354 fulfillment source gate active.** Exactf5817a15/frozen9cfb; one5s199Hz
   capture/8guest-second warmup,120sowner, existing64-invocation requests and
   same-process native JIT/map. Different complete workload from R350invoice/search;
   do not repeat those captures. Identify a whole record/scalar/operand stage to
   eliminate, or reject candidates with concrete owning evidence and advance.
   Preserve all unknown/ambiguous leaves, goldens, budget/cancellation/ownership,
   quiet/join and RAM archival-before-unmount gates. No normal timing claim, new
   policy/arena/identity ledger or automatic extra capture. Earliest observation'''+(now+datetime.timedelta(seconds=90)).strftime('%H:%M:%S')+'''UTC.
   Existing immutable image/catalog/auxiliaries reused, no retirement/floor change.
   R353qualification runs independently. Import execution already uses executable
   code, ordinary function bindings retain declaration inputs rather than body IR,
   and module mirroring is demand-driven; don't duplicate delivered removals.

'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
print('B726 first owned profile launched; observe after',(now+datetime.timedelta(seconds=90)).isoformat(),flush=True)
