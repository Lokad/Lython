from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent
d=json.loads((r/'attribution-fulfillment.json').read_text(encoding='utf-8'))
n=json.loads((r/'native-body-fulfillment-instruction-groups.json').read_text(encoding='utf-8'))
receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'))
assert d['samples']==1086 and d['ambiguousLeafSamples']==0 and n['nativeBodyLeafSamples']==171
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
assert all(receipt[k]for k in ['complete','allWorkersJoined','quietBeforeAndAfter','guestFixturesRemoved','ramTraceArchivedAndVerifiedBeforeUnmount'])
decision=dict(source='f5817a15/frozen9cfb7d5b',state='Source gate complete; select R355owned CSV field ranges, not a broad value/frame rewrite',
 findings=[
  '1086guest leaves/5.47guestCPU seconds;88unknown,zeroambiguous. NativeRunCore171leaves map one unique same-process13,655byte Tier1 body. Hottest26/19leaf groups mix loop metadata/cancellation/bounds; these are not removable CPU shares.',
  'CSV Feed29/FinishField20/FinishRecord28leaves are owning useful parsing/construction work. Source inspection identifies one actual repeated storage stage: native ReadLineInto already fills the admitted _record, then FeedOwnedLine truncates and rewrites ordinary bytes into compacted fields before final retained strings copy them again.',
  'Record descriptors can point into the existing owned raw record. Keep ordinary field bytes in place, compact only escapes within each field, then make the same independently funded retained values. Borrowed iterator strings first copy into the same owned raw buffer in cancellable chunks. One parser/state machine, no alternate native fast path.',
  'Exact integer operators already bypass generic numeric dispatch; module mirroring is demand-driven, imports executable and ordinary function bindings retain declaration inputs. Do not duplicate those removals. This profile does not justify a tagged VM or new call arena.'
 ],
 expectedDeletion=['decoded compacted whole-record representation','per-chunk/per-marker builder Append calls during parsing','truncate-then-reappend native input stage'],
 compatibility='Raw CSV syntax remains in admitted scratch until record completion. Heavily escaped/multiline records and borrowed malformed lines can need more scratch or be denied earlier. Exact tiny-budget thresholds are not promised. Preserve Python values, error order without admission refusal, source-item consumption and terminal refusal.',
 acceptance=['QUOTING/escape/doublequote/strict/skipspace/Unicode/empty/trailing/multiline behavior and numeric error order','Borrowed input unchanged; retained fields independent across buffer reuse and actual I/O suspension','Admission before capacity/replacement/result allocation; original prefix/capacity/funding intact on refusal, first origin terminal','Cancellable bounded input copies/parsing, no row publication on failure, scope cleanup/shared-budget reuse','Reasonable bounded CSV working storage for raw record size, not cumulative total row count'],
 comparison='Existing complete CSV fulfillment/invoice warm/fresh and borrowed-row control, unchanged text. First focused actual11/10 and allocation diagnostics, then bounded quiet source pair if justified. No speedup forecast/fixed percentage veto; preserve adverse results and explicitly decide complexity/regression debt.',
 noNormalTimingClaim=True,fullDelivery='43583650094pending independently',publicationHeld=True)
(r/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
out=Path('benchmarks/results/2026-11-14-fulfillment-stage-attribution');out.mkdir(exist_ok=False)
for name in ['identity.json','prospective.json','decision.json','attribution-fulfillment.json','native-body-fulfillment-instruction-groups.json','leaf-census.json','archive-receipt.json','terminal-status.json','observations.tgz']:
 shutil.copyfile(r/name,out/name)
with tarfile.open(out/'collection-and-analysis.tar.xz','w:xz')as t:
 for p in sorted(r.iterdir()):
  if p.is_file()and p.suffix in ['.py','.sh','.json','.log']:t.add(p,arcname=p.name)
 t.add(r.parent/'owned-tuple-return-r353/prepare-profile.py',arcname='prepare-profile.py')
(out/'README.md').write_text(f'''# Complete fulfillment stage attribution

2026-11-14UTC, R354/B726, exact committedf5817a15/frozen9cfb7d5b.
One5s199Hz cpu-clock/fp capture after8guest-second warmup, existing64-invocation
requests,120sowner. Quiet F4as_v7/Ubuntu24.04.4/.NET11RC3, unchanged workers and
optional0.4adapter. Perf maps and native-body disassembly are explicit diagnostic
overrides; this is not normal timing, allocation-stack or CPython evidence.

The complete4,096-row fulfillment/pricing/report script has1,086guest leaves over
5.47guestCPU seconds,88unknown leaves and zero ambiguous. Other-thread CPU remains
in raw records. All171native-body leaves map one unique same-process Tier1
13,655byte body/{len(n['blocks'])}instruction groups. Hottest26/19leaf groups mix
metadata/cancellation/bounds; they do not prove a large removable activation.
CSVFeed29/FinishField20/FinishRecord28leaves include useful parsing and construction.

Source inspection selects one coherent R355proposal: native input is already in
the admitted record buffer, but truncation/reappend compacts ordinary field bytes
before final retained strings copy them again. Use field ranges into the owned
raw record, rewriting only escapes within fields. Borrowed iterator strings copy
in bounded cancellable chunks into the same buffer/parser. Delete decoded whole-
record compaction/per-marker Append; retain required final independent field copies.
No new engine, raw-pointer borrowing, owner, arena or identity ledger.

Raw syntax stays funded until record completion. Escaped/multiline records or
borrowed malformed lines can require more scratch or be denied earlier. Preserve
Python values/error order, exact source consumption, aliases, cancellation, eager
capacity/replacement/result admission and terminal refusal. The proposal is not
promoted by samples or a percentage forecast; focused checks and a bounded complete-
script comparison must decide its simplification and regression tradeoff.

Exact integer dispatch, demand-driven module mirroring, executable imports and
declaration-only function bindings already exist. Do not duplicate those removals
or start a broad boxed-value redesign on these mixed samples. This closes the
bounded source gate by selecting a concrete storage-stage removal.

All image/auxiliary/golden/budget/quiet/join/archival gates pass; no VM workers or
RAM fixtures remain. Every RAM trace byte was independently archived/verified
persistently before unmount. No new core/catalog upload, retirement or changed
254/252MiBfloors. RawSHA256: `{receipt['archiveSHA256']}`.
Full43583650094qualification runs independently. Publication remains postponed;
the whole-script objective is active.

[Decision](decision.json),[owning attribution](attribution-fulfillment.json),
[same-process native groups](native-body-fulfillment-instruction-groups.json),
[complete leaf census](leaf-census.json),[raw](observations.tgz),
[collection/analysis](collection-and-analysis.tar.xz).
''',encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');anchor='[R353 owned native tuple returns]';assert anchor in s
s=s.replace(anchor,'''[R354 fulfillment stage attribution](results/2026-11-14-fulfillment-stage-attribution/README.md)
maps exactf5817a15/frozen9cfb:1086guest leaves/88unknown/zeroambiguous,
171native-body leaves in one13,655byte same-process Tier1 body. Mixed dispatch/
arithmetic/CSV costs justify no broad frame/value rewrite. Source inspection selects
owned raw CSV field ranges to remove actual truncate/reappend compaction; semantic,
scratch-retention and cancellation/admission tradeoffs are recorded before code.
All collection/quiet/ownership/RAM archival gates pass. No normal timing claim.

'''+anchor,1);p.write_text(s,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');(r/'PLAN-before-selection.md').write_text(s,encoding='utf-8',newline='\n')
a=s.index('   **R354 fulfillment source gate active.**');b=s.index('   | Area / representative scripts |',a)
s=s[:a]+'''   **R354 source gate complete; select R355owned CSV field ranges.** Exactf581/9cfb:
   1,086guest leaves/88unknown/zeroambiguous;171native-body leaves map one13,655byte
   Tier1 body. Mixed costs justify no broad frame/value rewrite. Native CSV input
   already fills admitted _record, then parsing truncates/reappends ordinary bytes
   into decoded storage before final retained field copies. Replace whole-record
   compaction with field ranges into the same owned raw buffer; only escapes need
   within-field rewriting. Borrowed iterator input copies in cancellable chunks.
   Delete the decoded compaction stage/per-marker Append, keep one parser/state
   machine and independent result funding. No new owner/backend/ledger.
   Tradeoff: raw syntax stays funded until record completion; escaped/multiline or
   malformed borrowed rows can require more scratch/earlier denial. Preserve values,
   source consumption/error order without refusal, retained aliases, eager capacity/
   replacement/results admission, terminal origin, rollback and bounded cancellation.
   First focused actual11/10 plus allocation/representative storage diagnostics;
   then bounded complete CSV warm/fresh/borrowed-row comparison with unchanged text.
   Decide complexity/regression debt explicitly, no percentage veto or automatic
   promotion. Full delivery at a coherent retained checkpoint. Stop this migration
   at a verified retention/withdrawal decision, then continue the substantial roadmap.
   [Source gate](benchmarks/results/2026-11-14-fulfillment-stage-attribution/README.md).
   Import execution is already executable, function bindings retain declarations,
   and module mirroring is demand-driven; don't duplicate delivered removals.

'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
assert not subprocess.check_output(['git','diff','--cached','--name-only'],text=True).strip()
subprocess.run(['git','add','--',str(out),'benchmarks/EXPERIMENTS.md'],check=True)
subprocess.run(['git','diff','--cached','--check'],check=True)
subprocess.run(['git','commit','-m','Record fulfillment owning costs and CSV range migration proposal [skip ci]'],check=True)
subprocess.run(['git','push','origin','HEAD'],check=True,timeout=120)
print('R354 evidence committed; selected bounded R355migration, no CPU forecast/full-goal completion.')
