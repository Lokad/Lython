from pathlib import Path
import ast,json,runpy,subprocess
r=Path(__file__).parent;prior=r.parent/'script-stage-r350'
for old,new in [('analyze-invoice.py','analyze-fulfillment.py'),('analyze-native-invoice.py','analyze-native-fulfillment.py')]:
 s=(prior/old).read_text(encoding='utf-8').replace('invoice','fulfillment').replace('Committede235b18b/frozen71ba421c','Committedf5817a15/frozen9cfb7d5b')
 ast.parse(s);(r/new).write_text(s,encoding='utf-8',newline='\n')
for name in ['analyze-fulfillment.py','analyze-native-fulfillment.py']:
 with(r/(name.removesuffix('.py')+'.log')).open('w',encoding='utf-8',newline='\n')as f:
  p=subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/name)],stdout=f,stderr=subprocess.STDOUT,timeout=60)
 assert p.returncode==0,(r/(name.removesuffix('.py')+'.log')).read_text(encoding='utf-8')[-2000:]
a=runpy.run_path(str(r/'analyze-fulfillment.py'))
leaf=dict(samples=a['leaves'].total(),leaves=a['leaves'].most_common(),nearestOwningFrames=a['guest'].most_common(),interpretation='Nearest frames include useful/inlined work. Counts are not removable shares or allocation attribution.')
(r/'leaf-census.json').write_text(json.dumps(leaf,indent=2)+'\n',encoding='utf-8',newline='\n')
d=json.loads((r/'attribution-fulfillment.json').read_text(encoding='utf-8'))
print('Guest samples/unknown/ambiguous',d['samples'],d['unmappedLeafSamples'],d['ambiguousLeafSamples'])
print('Nearest frame families:',d['nearestFrameFamilies'])
for method,count in d['topLeafCpuSamples'][:22]:print(count,method)
native=json.loads((r/'native-body-fulfillment-instruction-groups.json').read_text(encoding='utf-8'))
print('Native body',native['nativeBodyLeafSamples'],'/',native['guestLeafSamples'],'samples;',native['tier1MapBytes'],'bytes')
for block in sorted(native['blocks'],key=lambda v:v['leafSamples'],reverse=True)[:6]:
 print(block['leafSamples'],block['label'],block['instructions'][:1700])
