from pathlib import Path
import hashlib, json, shutil, subprocess, tarfile
lab=Path(__file__).resolve().parent
repo=lab.parents[3]
out=repo/"benchmarks/results/2026-11-24-raw-expression-retirement"
quiet=lab/"comparison/quiet"
def load(path):return json.loads(path.read_text(encoding="utf-8-sig"))
def digest(data):return hashlib.sha256(data).hexdigest()
identity=load(quiet/"identity.json")
patch=subprocess.check_output(["git","diff","--binary","--","src","tests"],cwd=repo)
assert patch==(lab/"candidate.patch").read_bytes()
assert digest(patch)==identity["sourcePatchSHA256"]
terminal=load(quiet/"terminal-status.json")
assert terminal["receipt"]["complete"] and terminal["receipt"]["allWorkersJoined"] and not terminal["fixtures"]
assert digest((out/"quiet-observations.tar.xz").read_bytes())==terminal["receipt"]["archiveSHA256"]
assert load(lab/"call-graph-net10.json")["methods"] == load(lab/"call-graph-net11.json")["methods"]
for role, files in identity["imageFiles"].items():
    assert {p.name:digest(p.read_bytes()) for p in (lab/role).iterdir()}==files
    verify=load(lab/"comparison"/(role+"-verify.json"))
    assert verify["state"]=="Completed" and verify["caseCount"]==3 and verify["launched"]["library"]["sha256"]==files["Lokad.Lython.dll"]
for file in ("windows-public.log","ubuntu-final.log"):
    assert "Passed:  7402" in (lab/file).read_text(encoding="utf-8-sig")
for file in ("windows-white-final.log","ubuntu-final.log"):
    assert "Passed:  1837" in (lab/file).read_text(encoding="utf-8-sig")
for file in ("windows-net10.log","ubuntu-net10.log"):
    assert "Passed:    92" in (lab/file).read_text(encoding="utf-8-sig")
for file in (quiet/"identity.json",lab/"allocation-summary.json"):
    shutil.copyfile(file,out/file.name)
files=["package-evidence.py","candidate.patch","audit/Audit.csproj","audit/Program.cs","call-graph-net10.json","call-graph-net11.json",
    "unused-imports-net10.json","unused-imports-net11.json","remove-audited-methods.py","remove-unused-imports.py","specialize-expansion.py",
    "prepare.py","prepare.log","quiet.py","archive.py","launch.log","retrieve.log","allocations.py",
    "reference-allocation.json","candidate-allocation.json","comparison/reference-verify.json","comparison/candidate-verify.json",
    "test-ubuntu.sh","ubuntu-public.log","windows-white.log","windows-expected-argument.log","windows-white-final.log",
    "windows-public.log","ubuntu-final.log","windows-net10.log","ubuntu-net10.log"]
with tarfile.open(out/"procedures.tar.xz","w:xz") as tar:
    for file in files:tar.add(lab/file,arcname=file,recursive=False)
with tarfile.open(out/"procedures.tar.xz") as tar:
    assert {entry.name:digest(tar.extractfile(entry).read()) for entry in tar}=={name:digest((lab/name).read_bytes()) for name in files}
print("Verified sectioned source audit, live-path checks and exact measured patch.")
