using System.Text.Json;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

var root = Path.GetFullPath(args[0]);
var revision = args[1];
var sources = Directory.EnumerateFiles(Path.Combine(root, "src", "Lokad.Lython"), "*.cs", SearchOption.AllDirectories)
    .Where(path => !Path.GetRelativePath(root, path).Split(Path.DirectorySeparatorChar).Any(part => part is "obj" or "bin"))
    .Append(args[2]).ToArray();
var runtime = args[4];
var references = Directory.EnumerateFiles(runtime, "*.dll").Select(path => MetadataReference.CreateFromFile(path)).ToArray();
var symbols = args[3] == "net11" ? new[] { "NET11_0_OR_GREATER" } : [];
var options = new CSharpParseOptions(LanguageVersion.Preview, preprocessorSymbols: symbols);
var trees = sources.Select(path => CSharpSyntaxTree.ParseText(File.ReadAllText(path), options, path)).ToArray();
var compilation = CSharpCompilation.Create("Lokad.Lython", trees, references,
    new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary, nullableContextOptions: NullableContextOptions.Enable));
var diagnostics = compilation.GetDiagnostics();
var errors = diagnostics.Where(diagnostic => diagnostic.Severity == DiagnosticSeverity.Error).ToArray();
if (errors.Length != 0)
{
    foreach (var error in errors.Take(20)) Console.Error.WriteLine(error);
    return 1;
}

if (args.Length > 5 && args[5] == "imports")
{
    var unused = diagnostics.Where(diagnostic => diagnostic.Id == "CS8019")
        .Select(diagnostic =>
        {
            var location = diagnostic.Location.GetLineSpan();
            var tree = diagnostic.Location.SourceTree!;
            var contents = tree.GetText().ToString(diagnostic.Location.SourceSpan);
            return new { file = Path.GetRelativePath(root, location.Path).Replace(Path.DirectorySeparatorChar, (char)47), directive = contents };
        });
    Console.WriteLine(JsonSerializer.Serialize(unused, new JsonSerializerOptions { WriteIndented = true }));
    return 0;
}

static IMethodSymbol Definition(IMethodSymbol symbol)
{
    var method = (symbol.ReducedFrom ?? symbol).OriginalDefinition;
    return method.PartialDefinitionPart ?? method;
}

var incoming = new Dictionary<IMethodSymbol, HashSet<IMethodSymbol>>(SymbolEqualityComparer.Default);
var outgoing = new Dictionary<IMethodSymbol, HashSet<IMethodSymbol>>(SymbolEqualityComparer.Default);
var outside = new HashSet<IMethodSymbol>(SymbolEqualityComparer.Default);
var declarations = new Dictionary<IMethodSymbol, MethodDeclarationSyntax>(SymbolEqualityComparer.Default);
var targetNames = new HashSet<string>(StringComparer.Ordinal);
foreach (var tree in trees)
{
    var model = compilation.GetSemanticModel(tree);
    foreach (var method in tree.GetRoot().DescendantNodes().OfType<MethodDeclarationSyntax>())
    {
        var symbol = Definition(model.GetDeclaredSymbol(method)!);
        if (!symbol.ContainingType.ToDisplayString().StartsWith("Lokad.Lython.Runtime.LythonRuntime", StringComparison.Ordinal)) continue;
        declarations.TryAdd(symbol, method);
        targetNames.Add(symbol.Name);
    }
}
foreach (var tree in trees)
{
    var model = compilation.GetSemanticModel(tree);
    foreach (var node in tree.GetRoot().DescendantNodes().OfType<SimpleNameSyntax>())
    {
        if (!targetNames.Contains(node.Identifier.ValueText)) continue;
        var info = model.GetSymbolInfo(node);
        foreach (var called in info.Symbol is { } exact ? [exact] : info.CandidateSymbols)
        {
            if (called is not IMethodSymbol method || !declarations.ContainsKey(Definition(method))) continue;
            var callee = Definition(method);
            if (node.FirstAncestorOrSelf<MethodDeclarationSyntax>() is not { } callerSyntax)
            {
                outside.Add(callee);
                continue;
            }
            var caller = Definition(model.GetDeclaredSymbol(callerSyntax)!);
            if (!incoming.TryGetValue(callee, out var callers)) incoming.Add(callee, callers = new(SymbolEqualityComparer.Default));
            callers.Add(caller);
            if (!outgoing.TryGetValue(caller, out var children)) outgoing.Add(caller, children = new(SymbolEqualityComparer.Default));
            children.Add(callee);
        }
    }
}

var entry = declarations.Keys.Single(method => method.Name == "EvaluateExpression" && method.Parameters[0].Type.Name == "ExpressionSyntax");
var parents = new HashSet<IMethodSymbol>(SymbolEqualityComparer.Default) { entry };
var pending = new Queue<IMethodSymbol>(parents);
while (pending.TryDequeue(out var node))
{
    if (!incoming.TryGetValue(node, out var callers)) continue;
    foreach (var caller in callers)
        if (parents.Add(caller)) pending.Enqueue(caller);
}

var survivingBoundary = parents.Where(method => !declarations.ContainsKey(method) || outside.Contains(method)
    || method.DeclaredAccessibility != Accessibility.Private).ToArray();
var closed = new HashSet<IMethodSymbol>(parents, SymbolEqualityComparer.Default);
foreach (var boundary in survivingBoundary)
    if (boundary.ContainingType.ToDisplayString() != "Lokad.Lython.Runtime.LythonRuntime" ||
        boundary.Name != "AssignTarget" || boundary.Parameters[0].Type.Name != "AssignmentTargetSyntax")
    {
        Console.Error.WriteLine($"External or nonprivate entry: {boundary}");
        return 2;
    }

bool added;
do
{
    added = false;
    foreach (var removed in closed.ToArray())
    {
        if (!outgoing.TryGetValue(removed, out var children)) continue;
        foreach (var child in children)
            if (!closed.Contains(child) && child.DeclaredAccessibility == Accessibility.Private && !outside.Contains(child) &&
                (declarations[child].Body is not null || declarations[child].ExpressionBody is not null))
                if (incoming[child].All(closed.Contains)) added |= closed.Add(child);
    }
} while (added);

var rows = closed.Select(method =>
{
    var declaration = declarations[method];
    var range = declaration.GetLocation().GetLineSpan();
    return new
    {
        method = method.ToDisplayString(),
        file = Path.GetRelativePath(root, range.Path).Replace('\\', '/'),
        start = declaration.FullSpan.Start,
        end = declaration.FullSpan.End,
        firstLine = range.StartLinePosition.Line + 1,
        lastLine = range.EndLinePosition.Line + 1,
        reachesSyntax = parents.Contains(method),
        nonPrivate = method.DeclaredAccessibility != Accessibility.Private
    };
}).OrderBy(row => row.file).ThenBy(row => row.start).ToArray();
Console.WriteLine(JsonSerializer.Serialize(new
{
    revision, target = args[3], parsedFiles = trees.Length,
    methods = rows,
    abstractRoots = parents.Where(outside.Contains).Select(method => method.ToDisplayString())
}, new JsonSerializerOptions { WriteIndented = true }));
return 0;



