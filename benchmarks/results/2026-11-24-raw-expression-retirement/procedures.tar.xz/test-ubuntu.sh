set -eu
export DOTNET_ROOT="$HOME/.dotnet"
lab=.git/agent-notes/review-20261031/raw-expression-retirement-20261124/ubuntu
mkdir -p "$lab/probe-tools"
test -x "$HOME/.local/bin/python3.13"
if [ ! -e "$lab/probe-tools/python" ]; then ln -s "$HOME/.local/bin/python3.13" "$lab/probe-tools/python"; fi
export PATH="$PWD/$lab/probe-tools:$DOTNET_ROOT:$PATH"
python --version
dotnet build tools/LythonProbe/LythonProbe.csproj -c Release -f net11.0 --artifacts-path "$lab" -o "$lab/tools/LythonProbe/bin/Release/net11.0" --verbosity quiet
dotnet test tests/Lokad.Lython.PublicApi.Tests -f net11.0 -c Release --artifacts-path "$lab" --filter "(FullyQualifiedName~Call|FullyQualifiedName~Class|FullyQualifiedName~Annotation|FullyQualifiedName~Display|FullyQualifiedName~Comprehension|FullyQualifiedName~Generator|FullyQualifiedName~Match|FullyQualifiedName~Import|FullyQualifiedName~Admission|FullyQualifiedName~Function)&Category!=Stress" --verbosity quiet
dotnet test tests/Lokad.Lython.Tests -f net11.0 -c Release --artifacts-path "$lab" --filter "(FullyQualifiedName~Call|FullyQualifiedName~Dictionary|FullyQualifiedName~Rendering|FullyQualifiedName~TupleDisplay|FullyQualifiedName~Comparison|FullyQualifiedName~Executable|FullyQualifiedName~Admission|FullyQualifiedName~Memory)&Category!=Stress" --verbosity quiet
