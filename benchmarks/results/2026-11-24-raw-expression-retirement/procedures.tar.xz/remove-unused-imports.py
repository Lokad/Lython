from pathlib import Path
from collections import defaultdict
import json, subprocess

root=Path.cwd()
lab=Path(__file__).resolve().parent
paths=set(subprocess.check_output(["git","diff","--name-only","--","src"],text=True).splitlines())
sets=[]
for target in ("net10","net11"):
    items=json.loads((lab/f"unused-imports-{target}.json").read_text(encoding="utf-8-sig"))
    sets.append({(row["file"],row["directive"]) for row in items if row["file"] in paths})
selected=sets[0] & sets[1]
grouped=defaultdict(set)
for name,directive in selected:grouped[name].add(directive)
for name,lines in grouped.items():
    path=root/name
    original=path.read_bytes()
    newline=b"\r\n" if original.count(b"\r\n") > original.count(b"\n")//2 else b"\n"
    body=original.decode("utf-8").splitlines()
    assert all(body.count(line)==1 for line in lines)
    body=[line for line in body if line not in lines]
    if body and not body[0]:body.pop(0)
    path.write_bytes(newline.join(line.encode("utf-8") for line in body)+newline)
print(f"Removed {len(selected)} redundant imports from the edited files.")
