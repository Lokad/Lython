from pathlib import Path
import hashlib, json, os, shutil, subprocess, tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.with_name("shared-literal-decoding-20261124") / "refinement"
previous = donor / "comparison/quiet"
quiet = lab / "comparison/quiet"
quiet.mkdir(parents=True, exist_ok=True)
read = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
digest = lambda data: hashlib.sha256(data.encode("utf-8")).hexdigest()
save = lambda p, v: p.write_text(json.dumps(v, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
base = read(previous / "identity.json")
core = "Lokad.Lython.dll"
head = subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip()
assert head.startswith("9e3e85e44")
assert subprocess.check_output(["git","diff","--binary",base["sourceRevision"],head,"--","src","tests"],cwd=repo)==(donor/"candidate.patch").read_bytes()
reference = base["imageFiles"]["candidate"]
assert {p.name:sha(p) for p in (donor/"candidate").iterdir()} == reference
current = lab/"windows/bin/Lokad.Lython/release_net11.0"/core
images = {"reference": reference, "candidate": reference | {core:sha(current)}}
assert images["candidate"][core] != reference[core]
for role, files in images.items():
    image=lab/role
    image.mkdir(exist_ok=True)
    for name in files:
        shutil.copyfile(current if role=="candidate" and name==core else donor/"candidate"/name,image/name)
    assert len(files)==32 and {p.name:sha(p) for p in image.iterdir()}==files

generic="diagnostic.generic-class-headers"
manifest="scripts.config-manifest.small"
report="diagnostic.text-summary.nonlocal-computed-width.large"
jobs=[[generic,"warm"],[report,"warm"],[generic,"compile-run"],[manifest,"compile-run"]]
catalog=read(previous/"representative.json")
controls=[row for row in catalog["cases"] if row["id"] in {manifest,report}]
assert len(controls)==2
source="""class Base:
    def __init_subclass__(cls, *, tag):
        cls.tag = tag
def tagged(value, *, step):
    return value + step
def factory(seed):
    class Entry[T](*[Base], **{'tag': tagged(*(seed,), **{'step': 11})}):
        payload: tagged(2, step=3)
    return Entry
total = 0
for index in range(96):
    item = factory(index)
    total += item.tag
print(total, item.__annotations__['payload'], item.__type_params__[0].__name__)
"""
python=Path("C:/Python313/python.exe")
golden=subprocess.run([python,"-I","-S","-X","utf8","-"],input=source,encoding="utf-8",capture_output=True,timeout=10,check=True)
assert not golden.stderr and golden.stdout == f"{sum(range(96))+96*11} 5 T\n"
fixture=json.dumps({"size":96,"text":None},separators=(",",":"))
case=dict(id=generic,family="scripts",category="whole-script",scale="small",size=96,source=source,
    fixtureJson=fixture,expectedOutput=golden.stdout,sourceUtf8Bytes=len(source.encode("utf-8")),
    expectedOutputUtf8Bytes=len(golden.stdout.encode("utf-8")),fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,
    sourceSha256=digest(source),fixtureSha256=digest(fixture),expectedOutputSha256=digest(golden.stdout))
catalog["cases"]=[case,*controls]
catalog["fixtureEncoding"]="Canonical base64 file maps in both existing controls. Generic class headers have no file fixture."
expected=quiet/"representative.json"
save(expected,catalog)
save(quiet/"jobs.json",{"warm":jobs})
patch=lab/"candidate.patch"
patch.write_bytes(subprocess.check_output(["git","diff","--binary","--","src","tests"],cwd=repo))
assert b"-    private static object EvaluateExpression(" in patch.read_bytes()
identity=dict(sourceRevision=head,comparisonRevision=head,sourcePatchSHA256=sha(patch),
    purpose="Remove the orphaned syntax evaluator and lower argument expansion directly",
    imageFiles=images,expectedCPythonSHA256=base["expectedCPythonSHA256"],cpythonWorkerSHA256=base["cpythonWorkerSHA256"],
    coreSHA256={role+suffix:files[core] for role,files in images.items() for suffix in ("","-control")},
    catalogs={name:{"sha256":sha(quiet/name)} for name in ("representative.json","jobs.json")})
save(quiet/"identity.json",identity)
collector=(previous/"collect.py").read_text(encoding="utf-8").replace("b1639-fixtures","b1640-fixtures")
compile(collector,"collect.py","exec")
(quiet/"collect.py").write_text(collector,encoding="utf-8",newline="\n")
shutil.copyfile(previous/"run.sh",quiet/"run.sh")
assert b"\r" not in (quiet/"run.sh").read_bytes()
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
worker=repo/"benchmarks/cpython-worker.py"
assert sha(worker)==identity["cpythonWorkerSHA256"]
for role in images:
    output=lab/"comparison"/(role+"-verify.json")
    subprocess.run([dotnet,lab/role/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",expected,
        "--dotnet",dotnet,"--python",python,"--python-worker",worker,"--out",output],env=env,cwd=repo,check=True,timeout=60)
    checked=read(output)
    assert checked["state"]=="Completed" and checked["caseCount"]==3
    assert checked["catalogSha256"]==sha(expected) and checked["launched"]["library"]["sha256"]==images[role][core]
staged=quiet/"payload.tar.gz"
with tarfile.open(staged,"w:gz",compresslevel=3) as archive:
    for name in ("identity.json","jobs.json","representative.json","collect.py","run.sh"):
        archive.add(quiet/name,arcname=name,recursive=False)
    archive.add(lab/"candidate"/core,arcname="candidate-core.dll",recursive=False)
save(quiet/"upload.json",dict(root="raw-expression-retirement-b1640-20261124",
    reference="shared-literal-decoding-b1639-20261124",payloadSHA256=sha(staged),payloadBytes=staged.stat().st_size))
save(lab/"verified-raw-replicas.json",[])
launch=(donor/"quiet.py").read_text(encoding="utf-8")
receipt=read(previous/"terminal-status.json")["receipt"]
assert receipt["complete"] and sha(previous/"observations.tar.xz")==receipt["archiveSHA256"]
assert "24aadf0bcd806af2aeeda2eb04321816ccb79ef4d9ef8ecf0e7b1a3598ed856f" in launch
launch=launch.replace("24aadf0bcd806af2aeeda2eb04321816ccb79ef4d9ef8ecf0e7b1a3598ed856f",receipt["archiveSHA256"])
launch=launch.replace("lython-b1639-shared-literal-decoding","lython-b1640-raw-expression-retirement").replace("b1639-","b1640-")
compile(launch,"quiet.py","exec")
(lab/"quiet.py").write_text(launch,encoding="utf-8",newline="\n")
print("Verified 32 files per image and three complete CPython goldens.")
