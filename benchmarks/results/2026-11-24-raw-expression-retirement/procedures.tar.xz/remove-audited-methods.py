from collections import defaultdict
from pathlib import Path
import json, subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
read = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
net11 = read(lab/"call-graph-net11.json")
net10 = read(lab/"call-graph-net10.json")
assert net11["methods"] == net10["methods"] and len(net11["methods"]) == 27
assert net11["abstractRoots"] == net10["abstractRoots"] == []
assert subprocess.check_output(["git","rev-parse","--short=9","HEAD"],cwd=repo,text=True).strip() == net11["revision"] == net10["revision"]
rows = defaultdict(list)
for method in net11["methods"]: rows[method["file"]].append(method)
for file, methods in rows.items():
    path = repo/file
    original = path.read_bytes()
    baseline = subprocess.check_output(["git","show","HEAD:"+file],cwd=repo)
    assert original.replace(b"\r\n",b"\n") == baseline.replace(b"\r\n",b"\n"), file
    bom = b"\xef\xbb\xbf" if original.startswith(b"\xef\xbb\xbf") else b""
    text = original[len(bom):].decode("utf-8").encode("utf-16-le")
    previous = len(text)
    for method in sorted(methods,key=lambda row:row["start"],reverse=True):
        start, end = method["start"]*2, method["end"]*2
        assert 0 <= start < end <= previous
        name = method["method"].split("(",1)[0].split(".")[-1]
        assert name in text[start:end].decode("utf-16-le")
        text = text[:start]+text[end:]
        previous = start
    path.write_bytes(bom+text.decode("utf-16-le").encode("utf-8"))
print(f"Removed {sum(map(len,rows.values()))} audited methods across {len(rows)} files.")
