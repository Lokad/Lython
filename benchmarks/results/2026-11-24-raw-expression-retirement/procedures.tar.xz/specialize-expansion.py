from pathlib import Path
path = Path("src/Lokad.Lython/Runtime/Calls/CallExpansion.cs")
source = path.read_text(encoding="utf-8")
start = source.index("    public static CallArgumentValue[] ExpandRawArguments(")
end = source.index("    private static CallArgumentValue[] AllocateDirectArguments(", start)
source = source[:start] + '''    public static CallArgumentValue[] ExpandLoweredArguments(IReadOnlyList<LoweredCallArgument> arguments,
        LythonRuntime.ExecutionContext context, object target, MemoryGovernor.TemporaryMemoryReservation storage,
        bool deferSingleStar = true)
    {
        if (!HasStarExpansion(arguments))
        {
            if (arguments.Count == 0) return [];
            var direct = AllocateDirectArguments(arguments.Count, context, arguments[0].Expression.Span, storage);
            for (var i = 0; i < arguments.Count; i++)
            {
                var argument = arguments[i];
                var value = LythonRuntime.EvaluateLoweredExpression(argument.Expression, context);
                direct[i] = CreateDirectArgument(argument.Form, LythonRuntime.RuntimeValue(value));
            }
            return direct;
        }

        using var expanded = new CallArgumentAccumulator(arguments.Count, context, target,
            deferSingleStar: deferSingleStar && HasSingleStarArgument(arguments), storage: storage);
        foreach (var argument in arguments)
        {
            var form = argument.Form;
            var span = argument.Expression.Span;
            switch (form.Kind)
            {
                case CallArgumentKind.Positional:
                    expanded.Add(CallArgumentValue.Positional(LythonRuntime.RuntimeValue(
                        LythonRuntime.EvaluateLoweredExpression(argument.Expression, context))), span);
                    break;
                case CallArgumentKind.Keyword:
                    expanded.Add(CallArgumentValue.Keyword(form.KeywordName, LythonRuntime.RuntimeValue(
                        LythonRuntime.EvaluateLoweredExpression(argument.Expression, context))), span);
                    break;
                case CallArgumentKind.StarredList:
                    expanded.AppendAsync(form, LythonRuntime.EvaluateLoweredExpression(argument.Expression, context),
                        span, false).GetAwaiter().GetResult();
                    break;
                case CallArgumentKind.StarredDictionary:
                    AppendStarredDictionary(LythonRuntime.EvaluateLoweredExpression(argument.Expression, context),
                        span, expanded, target, context);
                    break;
                default:
                    throw new InvalidOperationException($"Unknown call argument kind: {form.Kind}");
            }
        }

        expanded.FinishDeferredStarAsync(false).GetAwaiter().GetResult();
        return expanded.ToArray();
    }

    public static async ValueTask<CallArgumentValue[]> ExpandLoweredArgumentsAsync(IReadOnlyList<LoweredCallArgument> arguments,
        LythonRuntime.ExecutionContext context, object target, MemoryGovernor.TemporaryMemoryReservation storage,
        bool deferSingleStar = true)
    {
        if (!HasStarExpansion(arguments))
        {
            if (arguments.Count == 0) return [];
            var direct = AllocateDirectArguments(arguments.Count, context, arguments[0].Expression.Span, storage);
            for (var i = 0; i < arguments.Count; i++)
            {
                var argument = arguments[i];
                var value = await LythonRuntime.EvaluateLoweredExpressionAsync(argument.Expression, context).ConfigureAwait(false);
                direct[i] = CreateDirectArgument(argument.Form, LythonRuntime.RuntimeValue(value));
            }
            return direct;
        }

        using var expanded = new CallArgumentAccumulator(arguments.Count, context, target,
            deferSingleStar: deferSingleStar && HasSingleStarArgument(arguments), storage: storage);
        foreach (var argument in arguments)
        {
            var form = argument.Form;
            var span = argument.Expression.Span;
            switch (form.Kind)
            {
                case CallArgumentKind.Positional:
                    var positional = await LythonRuntime.EvaluateLoweredExpressionAsync(argument.Expression, context).ConfigureAwait(false);
                    expanded.Add(CallArgumentValue.Positional(LythonRuntime.RuntimeValue(positional)), span);
                    break;
                case CallArgumentKind.Keyword:
                    var keyword = await LythonRuntime.EvaluateLoweredExpressionAsync(argument.Expression, context).ConfigureAwait(false);
                    expanded.Add(CallArgumentValue.Keyword(form.KeywordName, LythonRuntime.RuntimeValue(keyword)), span);
                    break;
                case CallArgumentKind.StarredList:
                    var sequence = await LythonRuntime.EvaluateLoweredExpressionAsync(argument.Expression, context).ConfigureAwait(false);
                    await expanded.AppendAsync(form, sequence, span, true).ConfigureAwait(false);
                    break;
                case CallArgumentKind.StarredDictionary:
                    var mapping = await LythonRuntime.EvaluateLoweredExpressionAsync(argument.Expression, context).ConfigureAwait(false);
                    await AppendStarredDictionaryAsync(mapping, span, expanded, target, context).ConfigureAwait(false);
                    break;
                default:
                    throw new InvalidOperationException($"Unknown call argument kind: {form.Kind}");
            }
        }

        await expanded.FinishDeferredStarAsync(true).ConfigureAwait(false);
        return expanded.ToArray();
    }

''' + source[end:]
source = source.replace("HasSingleStarArgument<TArgument>(IReadOnlyList<TArgument> arguments, Func<TArgument, CallArgumentForm> getForm)",
    "HasSingleStarArgument(IReadOnlyList<LoweredCallArgument> arguments)")
source = source.replace("var kind = getForm(argument).Kind;","var kind = argument.Form.Kind;")
source = source.replace("HasStarExpansion<TArgument>(\n        IReadOnlyList<TArgument> arguments,\n        Func<TArgument, CallArgumentForm> getForm)",
    "HasStarExpansion(IReadOnlyList<LoweredCallArgument> arguments)")
source = source.replace("getForm(arguments[i]).Kind","arguments[i].Form.Kind")
path.write_text(source,encoding="utf-8",newline="\r\n")
