from hashlib import sha256
from pathlib import Path
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / "comparison/quiet"
quiet.mkdir(parents=True, exist_ok=True)
previous = lab.with_name("post-ascii-cpython-20261126")
earlier = previous / "comparison/quiet"
donor = lab.with_name("starmap-frame-inputs-20261126")
donor_quiet = donor / "comparison/quiet"
json_lines = lab.with_name("trim-truth-without-result-20261126") / "comparison/quiet"

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def write(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")

def edit(source, replacements):
    for before, after in replacements:
        assert source.count(before) == 1, before
        source = source.replace(before, after)
    return source

def program(path, source):
    compile(source, path.name, "exec")
    path.write_text(source, encoding="utf-8", newline="\n")

head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo, text=True).strip()
assert head.startswith("cb258fe7f")
assert not subprocess.check_output(["git", "status", "--porcelain", "--", "src"], cwd=repo)
prior = read(donor_quiet / "identity.json")
patch = donor / "candidate.patch"
assert prior["sourcePatchSHA256"] == digest(patch)
subprocess.run(["git", "apply", "--reverse", "--check", str(patch)], check=True, cwd=repo)
changed = subprocess.check_output(["git", "diff", "--name-only", prior["sourceRevision"], head, "--", "src"],
                                  cwd=repo, text=True).splitlines()
assert len(changed) == 3
assert all((repo / path).read_text(encoding="utf-8") == (donor / "source" / path).read_text(encoding="utf-8")
           for path in changed)
image = donor / "local/candidate"
files = prior["imageFiles"]["candidate"]
assert len(files) == 32 and {p.name: digest(p) for p in image.iterdir()} == files
terminal = read(donor_quiet / "terminal-status.json")
receipt = terminal["receipt"]
assert terminal["exitCode"] == "0" and not terminal["live"] and not terminal["fixtures"]
assert all(receipt[key] for key in ("complete", "allWorkersJoined", "guestFixturesRemoved",
                                    "quietBeforeAndAfter", "archivedAndVerifiedUnderLease"))
assert receipt["archiveSHA256"] == digest(donor_quiet / "observations.tar.xz")

catalog = read(earlier / "representative.json")
base_catalog = {row["id"]: row for row in catalog["cases"]}
json_catalog = {row["id"]: row for row in read(json_lines / "representative.json")["cases"]}
shipment_catalog = {row["id"]: row for row in read(donor_quiet / "representative.json")["cases"]}
json_id = "scripts.json-summary-helpers.large"
text_id = "diagnostic.text-summary.nonlocal-computed-width.large"
shipment_id = "diagnostic.shipment-starmap-wide-lists"
ordinary_id = "diagnostic.generated-ordinary-definitions"
assert base_catalog[text_id] == json_catalog[text_id]
catalog["cases"] = [json_catalog[json_id], shipment_catalog[shipment_id], base_catalog[text_id], base_catalog[ordinary_id]]
catalog["performanceQualified"] = False
write(quiet / "representative.json", catalog)
jobs = [[text_id, "warm"], [json_id, "warm"], [ordinary_id, "compile"],
        [shipment_id, "warm-async"], [json_id, "warm-async"], [ordinary_id, "compile-run"]]
write(quiet / "jobs.json", jobs)
for name in ("run.sh", "cpython-worker.py"):
    shutil.copyfile(earlier / name, quiet / name)
assert b"\r" not in (quiet / "run.sh").read_bytes()
assert digest(quiet / "cpython-worker.py") == digest(repo / "benchmarks/cpython-worker.py") == prior["cpythonWorkerSHA256"]
old = read(earlier / "identity.json")
assert old["expectedCPythonSHA256"] == prior["expectedCPythonSHA256"]

remote = "post-starmap-cpython-b1805-20261126"
identity = dict(sourceRevision=head, productionSource=head, candidate=head,
    frozenImage=f"/home/lokad/lython-bench-checks/{remote}/candidate",
    auxiliaryFiles={name: sha for name, sha in files.items() if name != "Lokad.Lython.dll"},
    imageFiles={"candidate": files}, coreSHA256={role: files["Lokad.Lython.dll"] for role in ("candidate", "candidate-control")},
    cpythonWorkerSHA256=prior["cpythonWorkerSHA256"], expectedCPythonSHA256=prior["expectedCPythonSHA256"],
    donorArchiveSHA256=receipt["archiveSHA256"], sourcePatchSHA256=prior["sourcePatchSHA256"],
    catalogs={name: {"sha256": digest(quiet / name)} for name in ("representative.json", "jobs.json")},
    priorExternalSource=old["sourceRevision"],
    purpose="Compare current JSON Lines, a wide shipment, Unicode text and compilation against CPython.")
write(quiet / "identity.json", identity)
program(quiet / "collect.py", edit((earlier / "collect.py").read_text(encoding="utf-8"), [
    ("len(jobs) == 12", "len(jobs) == 6"), ("-started<495", "-started<263"),
    ("lython-b1791-fixtures", "lython-b1805-fixtures"),
]))
program(quiet / "summarize.py", edit((earlier / "summarize.py").read_text(encoding="utf-8"), [
    ('len(raw["jobs"])==12', 'len(raw["jobs"])==6'), ('receipt["warmJobs"]==12', 'receipt["warmJobs"]==6'),
]))
program(lab / "quiet.py", edit((previous / "quiet.py").read_text(encoding="utf-8"), [
    ("lython-b1791-post-ascii-cpython-20261126", "lython-b1805-post-starmap-cpython-20261126"),
    ("json-ascii-character-b1790-20261126-repeat", "starmap-frame-inputs-b1804-20261126"),
    ("json-ascii-character-b1790-20261126", "starmap-frame-inputs-b1804-20261126"),
    ("proof['caseCount']==5", "proof['caseCount']==4"),
    ("RuntimeMaxSec=555", "RuntimeMaxSec=320"), ("seconds=466", "seconds=250"),
]))

sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
verified = quiet / "candidate-verify.json"
subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog", quiet / "representative.json",
    "--dotnet", dotnet, "--python", "C:/Python313/python.exe", "--python-worker", quiet / "cpython-worker.py", "--out", verified],
    cwd=repo, env=dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk)), check=True, timeout=45)
proof = read(verified)
assert proof["state"] == "Completed" and proof["caseCount"] == 4
assert proof["catalogSha256"] == identity["catalogs"]["representative.json"]["sha256"]
assert proof["launched"]["library"]["sha256"] == files["Lokad.Lython.dll"]

names = ("identity.json", "jobs.json", "representative.json", "collect.py", "run.sh", "cpython-worker.py")
payload = quiet / "stage.tar.gz"
with tarfile.open(payload, "w:gz", compresslevel=6) as bundle:
    for name in names:
        bundle.add(quiet / name, arcname=name, recursive=False)
upload = dict(root=remote, payloadSHA256=digest(payload), payloadBytes=payload.stat().st_size,
              expandedBytes=sum((quiet / name).stat().st_size for name in names), minimumAfterStageBytes=4_800_000)
write(quiet / "upload.json", upload)
print(upload)
