from pathlib import Path
import hashlib,json,shutil
root=Path('/home/lokad/lython-bench-checks/runtime-cpython-b260-20261105')
base=Path('/home/lokad/lython-bench-checks/private-csv-refined-b258-20261105/candidate')
previous=Path('/home/lokad/lython-bench-checks/runtime-cpython-b251-20261105/candidate/Lokad.Lython.dll')
for label in ('candidate','reference'):
 folder=root/label;folder.mkdir()
 for f in base.iterdir():
  if f.name=='Lokad.Lython.pdb':continue
  if f.name in ['Lokad.Lython.Benchmarks.dll','Lokad.Lython.Benchmarks.deps.json','Lokad.Lython.Benchmarks.runtimeconfig.json']:
   shutil.copyfile(f,folder/f.name)
  else:
   source=previous if label=='reference' and f.name=='Lokad.Lython.dll' else f
   (folder/f.name).symlink_to(source.resolve(),target_is_directory=source.is_dir())
i=json.loads((root/'identity.json').read_text())
for label in ('candidate','control','reference'):
 folder=root/('candidate' if label=='control' else label)
 assert hashlib.sha256((folder/'Lokad.Lython.dll').read_bytes()).hexdigest()==i['coreSHA256'][label]
 for name,sha in i['auxiliaryFiles'].items():assert hashlib.sha256((folder/name).read_bytes()).hexdigest()==sha
assert shutil.disk_usage(root).free>32*1024*1024
