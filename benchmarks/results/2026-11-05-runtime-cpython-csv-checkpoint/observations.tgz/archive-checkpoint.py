from pathlib import Path
import fcntl,json,subprocess

root=Path('/home/lokad/lython-bench-checks/runtime-cpython-b260-20261105')
status=subprocess.check_output(['systemctl','show','lython-b260-runtime-cpython-20261105','--property=LoadState,ActiveState,MainPID,Result'],text=True)
assert 'ActiveState=inactive' in status and 'MainPID=0' in status and 'Result=success' in status,status
assert (root/'exit-code.txt').read_text().strip()=='0'
data=json.loads((root/'confirmation/confirmation.json').read_text())
assert data['complete'] and len(data['jobs'])==16
(root/'final-service-status.txt').write_text(status,encoding='utf-8')
with (root.parent/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    source=(root/'archive.py').read_text()
    source=source.replace("'source-snapshot.tgz']", "'source-snapshot.tgz','started.utc','stopped.utc','exit-code.txt','final-service-status.txt','run.sh','launch.py','archive-checkpoint.py']")
    (root/'archive-complete.py').write_text(source,encoding='utf-8')
    subprocess.run(['python3',str(root/'archive-complete.py')],check=True)
