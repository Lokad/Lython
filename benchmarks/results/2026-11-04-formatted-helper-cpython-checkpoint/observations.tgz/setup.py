from pathlib import Path
import hashlib,json
root=Path('/home/lokad/lython-bench-checks/current-cpython-b202-20261104')
image='/home/lokad/lython-bench-checks/native-formatted-return-b201-20261104/candidate'
for name in ['candidate','baseline']:
 (root/name).symlink_to(image,target_is_directory=True)
d=json.loads((root/'identity.json').read_text())
for label,folder in [('candidate','candidate'),('control','baseline')]:
 assert hashlib.sha256((root/folder/'Lokad.Lython.dll').read_bytes()).hexdigest()==d['coreSHA256'][label]
