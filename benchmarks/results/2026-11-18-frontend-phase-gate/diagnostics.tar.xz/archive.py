from pathlib import Path
import json,shutil,statistics,tarfile
r=Path(__file__).parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-18-frontend-phase-gate';out.mkdir(exist_ok=False)
result={}
for name in ['phases','decomposition','passes']:
    v=json.loads((r/(name+'.json')).read_text(encoding='utf-8-sig'))
    assert v['coreSha256']=='a5038a280566316898258b4c3c3c8377bee5b8b5bcc6c7cf18ce99cdcf7b29f7'
    shutil.copyfile(r/(name+'.json'),out/(name+'.json'))
    result[name]=[dict(case=row['id'],allocatedBytes=[statistics.median(s['allocatedBytes'][i]for s in row['samples'])for i in range(len(v['phases']))])for row in v['rows']]
(out/'allocation-summary.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
with tarfile.open(out/'diagnostics.tar.xz','w:xz')as a:
    for p in sorted(r.rglob('*')):
        if p.is_file()and not {'bin','obj'}&set(p.relative_to(r).parts):a.add(p,arcname=p.relative_to(r).as_posix())
print(out)
