using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Lokad.Lython;
using Lokad.Lython.Frontend;

using var catalog = JsonDocument.Parse(File.ReadAllText(args[0], Encoding.UTF8));
var rows = new List<object>();
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var id = item.GetProperty("id").GetString()!;
    if (id is not ("scripts.text-normalization.helper-list" or "scripts.json-summary-helpers.large"
        or "scripts.numeric-squared-error.floating.large" or "calls.positional.large"
        or "scripts.csv-invoice.large" or "scripts.report-render.large")) continue;
    var source = item.GetProperty("source").GetString()!;
    if (source.Contains('\r') || source.StartsWith('\uFEFF')) throw new InvalidOperationException("Expected normalized catalog source.");
    for (var warm = 0; warm < 30; warm++)
    {
        var original = LythonFrontend.Compile(source);
        if (original.Diagnostics.Any(d => d.Severity == LythonDiagnosticSeverity.Error)) throw new InvalidOperationException("Original source invalid.");
    }
    var samples = new List<object>();
    for (var sample = 0; sample < 5; sample++)
    {
        var allocated = new long[11];
        var elapsed = new long[11];
        for (var iteration = 0; iteration < 30; iteration++)
        {
            var meter = new PhaseMeter(allocated, elapsed);
            var tokens = PythonTokenization.Read(source);
            meter.Next(0);
            var parsed = new Parser(tokens).Parse();
            meter.Next(1);
            if (parsed.Script is null) throw new InvalidOperationException("Source did not parse.");
            var diagnostics = SyntaxValidityDiagnostics.Analyze(parsed.Script);
            meter.Next(2);
            if (diagnostics.Count != 0) throw new InvalidOperationException(string.Join("; ", diagnostics));
            PostponedAnnotationText.Attach(parsed.Script, source);
            meter.Next(3);
            LexicalScopePreparation.Prepare(parsed.Script);
            meter.Next(4);
            var analysis = new StaticAnalysisContext(parsed.Script);
            meter.Next(5);
            var annotations = AnnotationDiagnostics.Analyze(parsed.Script, analysis).ToArray();
            meter.Next(6);
            StaticScopeDirectiveDiagnostics.Analyze(analysis);
            meter.Next(7);
            StaticAbstractInterpreter.Analyze(analysis);
            meter.Next(8);
            StaticNameBindingDiagnostics.Analyze(analysis);
            meter.Next(9);
            var semantic = analysis.Diagnostics;
            analysis.Dispose();
            meter.Next(10);
            if (annotations.Concat(semantic).Any(d => d.Severity == LythonDiagnosticSeverity.Error))
                throw new InvalidOperationException("Analysis returned errors.");
            GC.KeepAlive(parsed.Script);
        }
        samples.Add(new { allocatedBytes = allocated.Select(v => v / 30.0).ToArray(),
            elapsedMicroseconds = elapsed.Select(v => v * 1e6 / Stopwatch.Frequency / 30).ToArray() });
    }
    rows.Add(new { id, samples });
}
var core = typeof(LythonEngine).Assembly.Location;
File.WriteAllText(args[1], JsonSerializer.Serialize(new
{
    coreSha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(core))).ToLowerInvariant(),
    phases = new[] { "tokenization", "parser", "syntax-validity", "annotation-text", "lexical-facts",
        "analysis-context", "annotation-diagnostics", "scope-directive-diagnostics",
        "abstract-interpretation", "name-binding-diagnostics", "analysis-disposal" },
    boundary = "Local Windows diagnostic decomposition of unchanged qualified core. Normalized valid catalog sources; tokenization/parser/validation/annotation/fact/analysis calls follow frontend order; 30 original-frontend warmups, 5x30 decompositions. Private leading-indentation precheck, normalization, public ownership and pipeline boundary overhead excluded. Stopwatch/GC/tiering and concurrent local test activity limit timings; no controlled CPU/speedup/removable-share claim.",
    rows
}, new JsonSerializerOptions { WriteIndented = true }) + "\n", Encoding.UTF8);

struct PhaseMeter(long[] allocated, long[] elapsed)
{
    private long _bytes = GC.GetAllocatedBytesForCurrentThread();
    private long _ticks = Stopwatch.GetTimestamp();
    internal void Next(int stage)
    {
        var ticks = Stopwatch.GetTimestamp();
        var bytes = GC.GetAllocatedBytesForCurrentThread();
        allocated[stage] += bytes - _bytes;
        elapsed[stage] += ticks - _ticks;
        _bytes = GC.GetAllocatedBytesForCurrentThread();
        _ticks = Stopwatch.GetTimestamp();
    }
}
