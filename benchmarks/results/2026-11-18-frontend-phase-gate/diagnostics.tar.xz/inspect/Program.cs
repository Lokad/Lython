using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Lokad.Lython;
using Lokad.Lython.Frontend;

using var catalog = JsonDocument.Parse(File.ReadAllText(args[0], Encoding.UTF8));
var rows = new List<object>();
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var id = item.GetProperty("id").GetString()!;
    if (id is not ("scripts.text-normalization.helper-list" or "scripts.json-summary-helpers.large"
        or "scripts.numeric-squared-error.floating.large" or "calls.positional.large"
        or "scripts.csv-invoice.large" or "scripts.report-render.large")) continue;
    var source = item.GetProperty("source").GetString()!;
    for (var warm = 0; warm < 30; warm++) Compile();
    var samples = new List<object>();
    for (var sample = 0; sample < 5; sample++)
    {
        var allocated = new long[3];
        var elapsed = new long[3];
        for (var iteration = 0; iteration < 30; iteration++)
        {
            var bytes = GC.GetAllocatedBytesForCurrentThread();
            var ticks = Stopwatch.GetTimestamp();
            var frontend = LythonFrontend.Compile(source);
            elapsed[0] += Stopwatch.GetTimestamp() - ticks;
            allocated[0] += GC.GetAllocatedBytesForCurrentThread() - bytes;
            if (frontend.Diagnostics.Any(d => d.Severity == LythonDiagnosticSeverity.Error))
                throw new InvalidOperationException(string.Join("; ", frontend.Diagnostics));
            bytes = GC.GetAllocatedBytesForCurrentThread(); ticks = Stopwatch.GetTimestamp();
            var lowered = LoweredScript.Lower(frontend.Script!);
            elapsed[1] += Stopwatch.GetTimestamp() - ticks;
            allocated[1] += GC.GetAllocatedBytesForCurrentThread() - bytes;
            bytes = GC.GetAllocatedBytesForCurrentThread(); ticks = Stopwatch.GetTimestamp();
            var executable = ExecutableScript.Compile(lowered);
            elapsed[2] += Stopwatch.GetTimestamp() - ticks;
            allocated[2] += GC.GetAllocatedBytesForCurrentThread() - bytes;
            GC.KeepAlive(executable);
        }
        samples.Add(new { allocatedBytes = allocated.Select(v => v / 30.0).ToArray(),
            elapsedMicroseconds = elapsed.Select(v => v * 1e6 / Stopwatch.Frequency / 30).ToArray() });
    }
    rows.Add(new { id, sourceCharacters = source.Length, samples });

    void Compile()
    {
        var frontend = LythonFrontend.Compile(source);
        if (frontend.Diagnostics.Any(d => d.Severity == LythonDiagnosticSeverity.Error))
            throw new InvalidOperationException(string.Join("; ", frontend.Diagnostics));
        GC.KeepAlive(ExecutableScript.Compile(LoweredScript.Lower(frontend.Script!)));
    }
}
var core = typeof(LythonEngine).Assembly.Location;
File.WriteAllText(args[1], JsonSerializer.Serialize(new
{
    coreSha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(core))).ToLowerInvariant(),
    phases = new[] { "frontend-parse-and-validation", "lowered-tree", "executable-code" },
    boundary = "Local Windows source attribution only; exact qualified core, internal phases, 30 warmups and 5x30 compilations, normal GC/tiering. No public-owner/protocol/run costs, no controlled CPU/speedup or removable-share claim.",
    rows
}, new JsonSerializerOptions { WriteIndented = true }) + "\n", Encoding.UTF8);
