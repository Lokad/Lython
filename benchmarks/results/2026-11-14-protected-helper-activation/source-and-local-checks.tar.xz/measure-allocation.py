from pathlib import Path
import hashlib,json,os,statistics,subprocess,time

r=Path(__file__).parent;frozen=(r/'candidate').resolve()
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert hashlib.sha256((frozen/'Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256']['candidate']
reference=r.parent/'protected-helper-r367'
baseline=json.loads((reference/'allocation.json').read_text(encoding='utf-8'))
baselineSummary=json.loads((reference/'allocation-summary.json').read_text(encoding='utf-8'))
assert baselineSummary['coreSHA256']==identity['coreSHA256']['reference'] and baselineSummary['allGoldensAndSharedBudgetChecksPassed']
assert (r/'allocation-catalog.json').read_bytes()==(reference/'catalog.json').read_bytes()
assert hashlib.sha256((frozen/'Allocation.dll').read_bytes()).hexdigest()==baselineSummary['toolSHA256']
env={k:v for k,v in os.environ.items() if k.upper()!='PATH'}
sdk='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_ROOT']=sdk
env['PATH']=sdk+';'+next(v for k,v in os.environ.items() if k.upper()=='PATH')
fixture=r/'allocation-fixtures';fixture.mkdir();env['TEMP']=str(fixture.resolve());env['TMP']=str(fixture.resolve())
output=r/'candidate-allocation.json';assert not output.exists()
start=time.monotonic()
with (r/'candidate-allocation.log').open('w',encoding='utf-8',newline='\n') as log:
    done=subprocess.run([sdk+'/dotnet.exe',str(frozen/'Allocation.dll'),str(frozen),str((r/'allocation-catalog.json').resolve()),str(output.resolve())],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=60)
assert done.returncode==0,(r/'candidate-allocation.log').read_text(encoding='utf-8')[-2000:]
j=json.loads(output.read_text(encoding='utf-8'));assert len(j['rows'])==4 and all(x['sharedBudgetBaselineRestored'] for x in j['rows'])
assert not list(fixture.iterdir());fixture.rmdir()
rows=[]
for row in baseline['rows']:
    a=statistics.median(row['allocatedBytesPerInvocation'])
    b=statistics.median(next(x for x in j['rows'] if x['id']==row['id'])['allocatedBytesPerInvocation'])
    rows.append(dict(case=row['id'],referenceBytes=a,candidateBytes=b,changePercent=100*(b/a-1)))
summary=dict(coreSHA256=identity['coreSHA256'],toolSHA256=baselineSummary['toolSHA256'],elapsedSeconds=time.monotonic()-start,rows=rows,allGoldensAndSharedBudgetChecksPassed=True,allWorkersJoinedAndFixturesRemoved=True,unchangedReferenceReused='Exact ff2b5d76, tool, catalog/source/fixtures from R367; raw retained there, no repeated unchanged allocation run.',notElapsedOrCpuMeasurement=True,boundary=j['boundary'])
(r/'allocation-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(summary),flush=True)
