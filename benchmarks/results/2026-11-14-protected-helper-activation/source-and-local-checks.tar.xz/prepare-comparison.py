from pathlib import Path
import ast,hashlib,json,tarfile

r=Path(__file__).parent;b=r/'b756';b.mkdir()
old=r.parent/'native-call-transport-r365/b751'
source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==h for n,h in source['sources'].items())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
remote='/home/lokad/lython-bench-checks/protected-activation-b756-20261114';unit='lython-b756-protected-activation-20261114'
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision='R368uncommitted/frozen'+source['coreSHA256']['candidate'][:8]+' vs committed1c5af539/frozenff2b5d76; base full43633423371 GREEN cached',purpose='Successful try/except helper bodies use existing native slots; actual faults transfer at exact PC into existing ordinary pending-exception routing. Remove blanket protected-helper exclusion/eager normal activation. Identical scripts/data across runtime roles, unlike priorR367 source-form diagnostic. No second handler dispatcher or speed forecast.',coreSHA256={k:source['coreSHA256']['candidate' if k.startswith('candidate') else 'reference'] for k in identity['coreSHA256']},catalogSHA256=sha(r/'catalog.json'),fullSourceIdentitySHA256=sha(r/'candidate-identity.json'),sourceFormComparison=False,runtimeComparison=True)
(b/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.csv-invoice.large.protected','warm'],['scripts.csv-invoice.large.protected','compile-run'],['scripts.file-search.large.protected','warm'],['scripts.csv-invoice.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.json-summary-helpers.large','warm'],['diagnostic.loop-helper.short-zero.large','warm'],['scripts.csv-invoice.large.protected','compile']]
for n in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
    s=(old/n).read_text(encoding='utf-8').replace('native-word-loan-b751-20261114','protected-activation-b756-20261114').replace('lython-b751-native-word-loan-20261114',unit).replace('B751','B756')
    if n=='collect.py':
        a=s.index('jobs=');end=s.index('\nenv =',a)
        s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==8 and all(case in cases for case,lane in jobs)\n'+s[end:]
    elif n=='archive-owned.py':s=s.replace("len(raw['jobs'])==7","len(raw['jobs'])==8").replace('jobs=7','jobs=8')
    elif n=='retrieve.py':s=s.replace("['jobs']==7","['jobs']==8").replace('seven-job','eight-job')
    elif n=='summarize.py':s=s.replace("len(raw['jobs'])==7","len(raw['jobs'])==8").replace('jobs=7','jobs=8')
    if n.endswith('.py'):ast.parse(s)
    (b/n).write_text(s,encoding='utf-8',newline='\n')
(b/'prospective.json').write_text(json.dumps(dict(purpose=identity['purpose'],jobs=jobs,bound='One420sowner/350sstartguard;8smallwhole-script/phasejobs,4freshprocesses/job,5sfullrequestwarmups/12stext,5rotating0.5sbatches. Established workers/catalog,normalGC/tiering. Actual input/output/file/memory/image/quiet/join/archive gates.',removed='Blanket native exclusion for try/except and eager normal successful activation. Same final slots/PC/exception regions; one existing injected-exception route handles a fault without replay. Finally/with/generators stay on their existing route.',acceptance='Focused actual11/10 correctness/stack/cancellation/firstrefusal/lifetime passed before freeze,116isolatedCPythoncontrols/16goldens. Compare protectedinvoice warm/fresh/compile and protectedsearch warm; originalinvoice/text/JSON/short controls. Retain or explicit refinement/debt/withdrawal from the whole result, not a fixedpercentage veto. Fullplatform/package/stress follows only retained boundary.',stopping='One usable affected/control runtime comparison; bounded correction/confirmation only if justified, preserving first conditions and adverse controls. Allocation separate using prior exactff2/sourceform baseline, no unchanged repeat. No speedup forecast or universal gain; publication held.'),indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(b/'payload.tgz','w:gz') as t:
    for n in ['identity.json','collect.py','archive-owned.py','run.sh','prospective.json']:t.add(b/n,arcname=n)
    t.add(r/'candidate-core.dll',arcname='candidate-core.dll');t.add(r/'catalog.json',arcname='representative.json')
with tarfile.open(b/'payload.tgz') as t:unpacked=sum(m.size for m in t.getmembers())
config=dict(root=remote,sourceRoot='/home/lokad/lython-bench-checks/native-word-loan-b751-20261114',unit=unit,identity=identity,payloadBytes=(b/'payload.tgz').stat().st_size,payloadSHA256=sha(b/'payload.tgz'),unpackedBytes=unpacked)
s=(old/'launch-command.py').read_text(encoding='utf-8');a=s.index('c=');end=s.index('\nbase=',a);s=s[:a]+'c='+repr(config)+s[end:]
s=s.replace('lython-b751-fixtures','lython-b756-fixtures')
ast.parse(s);(b/'launch-command.py').write_text(s,encoding='utf-8',newline='\n')
(b/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(r.parent/'protected-helper-r367/launch.py').read_text(encoding='utf-8')
s=s.replace("goldens=json.loads((r/'goldens.json')", "goldens=json.loads((r.parent/'goldens.json')")
s=s.replace("r.parent/'invocation-stage-r366/b754/terminal-status.json'", "r.parent.parent/'protected-helper-r367/terminal-status.json'")
s=s.replace('seconds=120','seconds=360').replace('ownerSeconds=180','ownerSeconds=420')
ast.parse(s);(b/'launch.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared B756eight-job milestone; no remote action.',flush=True)
