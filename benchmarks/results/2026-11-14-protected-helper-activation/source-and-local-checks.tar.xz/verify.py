from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,tempfile

r=Path(__file__).parent
frozen=r/'candidate'
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert hashlib.sha256((frozen/'Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256']['candidate']
for name,digest in identity['auxiliaryFiles'].items():assert hashlib.sha256((frozen/name).read_bytes()).hexdigest()==digest
worker=r.parent/'utf8-byte-ownership-r334/b705/retrieved/cpython-worker.py'
spec=importlib.util.spec_from_file_location('protocol',worker)
protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
identity['catalogSHA256']=hashlib.sha256((r/'allocation-catalog.json').read_bytes()).hexdigest()
catalog=(r/'allocation-catalog.json').resolve();cases=json.loads(catalog.read_text(encoding='utf-8'))['cases']
env={k:v for k,v in os.environ.items() if k.upper()!='PATH'}
sdk='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_ROOT']=sdk
env['PATH']=sdk+';'+next(v for k,v in os.environ.items() if k.upper()=='PATH')
rows=[]
for role,command in [('Lython',[sdk+'/dotnet.exe',str((frozen/'Lokad.Lython.Benchmarks.dll').resolve()),'--compare','worker','--catalog',str(catalog)]),('CPython',['C:/Python313/python.exe','-I','-S','-X','utf8',str(worker.resolve()),'--catalog',str(catalog)])]:
    with tempfile.TemporaryDirectory(prefix='lython-comparison-files-') as folder,tempfile.TemporaryFile() as errors:
        p=subprocess.Popen(command,cwd=folder,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=errors)
        try:
            ready=protocol.read_frame(p.stdout)
            assert ready and ready['status']=='Ready' and ready['catalogSha256']==identity['catalogSHA256'],ready
            sequence=0
            for case in cases:
                for lane in ['warm','compile-run']:
                    sequence+=1
                    request={k:case[k]for k in ['sourceSha256','fixtureSha256','expectedOutputSha256']}
                    request.update(protocolVersion=2,requestId=sequence,operation='verify',caseId=case['id'],lane=lane,iterations=2)
                    protocol.write_frame(p.stdin,request);response=protocol.read_frame(p.stdout)
                    rows.append(dict(engine=role,case=case['id'],lane=lane,ready=ready,response=response))
                    (r/'goldens.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
                    assert response and response['status']=='Equivalent',response
                    assert response['actualOutputSha256']==case['expectedOutputSha256']
                    assert response['actualFilesSha256']==case['expectedFilesSha256']
                    print(role,case['id'],lane,'Equivalent; full stdout/files/cleanup.',flush=True)
            protocol.write_frame(p.stdin,dict(protocolVersion=2,requestId=sequence+1,operation='quit'))
            assert protocol.read_frame(p.stdout)['status']=='Closed'
            assert p.wait(timeout=15)==0
            errors.seek(0);assert not errors.read()
        finally:
            if p.poll() is None:p.kill();p.wait()
            p.stdin.close();p.stdout.close()
print('16 independent engine/source/phase goldens; no runtime source change.',flush=True)
