from pathlib import Path
import hashlib,json,shutil,tarfile
lab=Path(__file__).parent; quiet=lab/'comparison/quiet'; external=lab.with_name('default-operand-storage-20261125')/'comparison/quiet'; donor=lab.with_name('zip-unpack-20261125')
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
save=lambda p,d:write(p,json.dumps(d,indent=2)+'\n')
identity=read(quiet/'identity.json'); before=read(external/'identity.json')
assert identity['sourceRevision']=='01f1f61189fe35541045878cb694941da07e0d0a' and identity['imageFiles']['reference']==before['imageFiles']['candidate']
for role,files in identity['imageFiles'].items():assert {p.name:sha(p)for p in (lab/role).iterdir()}==files
terminal=read(external/'terminal-status.json'); assert terminal['exitCode']=='0' and terminal['receipt']['complete'] and sha(external/'observations.tar.xz')==terminal['receipt']['archiveSHA256']
rules='scripts.rule-default-closures'; eager='scripts.annotated-rule-closures'; post='scripts.annotated-rule-closures.nested-factories.postponed'; plain='diagnostic.generated-ordinary-definitions'; invoice='scripts.csv-invoice.method-policy.quoted-control'
save(quiet/'jobs.json',dict(warm=[[plain,'warm'],[rules,'warm'],[invoice,'warm'],['diagnostic.shipment-routing-callbacks','warm'],['diagnostic.shipment-routing-callbacks','warm-async']]))
identity['catalogs']['jobs.json']=dict(sha256=sha(quiet/'jobs.json'));save(quiet/'identity.json',identity)
shutil.copyfile(donor/'comparison/quiet/run.sh',quiet/'run.sh');assert b'\r' not in (quiet/'run.sh').read_bytes()
collector=(donor/'comparison/quiet/collect.py').read_text(encoding='utf-8').replace('targetBatchSeconds=.63','targetBatchSeconds=.82').replace('b1665-fixtures','b1676-fixtures')
compile(collector,'collect.py','exec');write(quiet/'collect.py',collector)
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=3) as bundle:
 for n in ['identity.json','jobs.json','representative.json','run.sh','collect.py']:bundle.add(quiet/n,arcname=n)
 bundle.add(lab/'candidate/Lokad.Lython.dll',arcname='candidate-core.dll')
save(quiet/'upload.json',dict(root='shared-call-entry-b1676-20261125',reference='default-operand-storage-b1670-20261125',payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
save(lab/'verified-raw-replicas.json',[])
launcher=(donor/'quiet.py').read_text(encoding='utf-8').replace('b1665','b1676').replace('lython-b1676-zip-unpack','lython-b1676-shared-call-entry')
launcher=launcher.replace('683fcdfa4dbd7f3c12ffadc461698d86584d2a4fce926626a9c7f08954bef52b',terminal['receipt']['archiveSHA256']).replace('seconds=241','seconds=252').replace('RuntimeMaxSec=305','RuntimeMaxSec=315')
compile(launcher,'quiet.py','exec');write(lab/'quiet.py',launcher)
report=(donor/'archive.py').read_text(encoding='utf-8').replace('2026-11-25-zip-unpack','2026-11-25-shared-call-entry')
compile(report,'archive.py','exec');write(lab/'archive.py',report)
