from pathlib import Path
import hashlib
import json
import os
import subprocess

lab=Path(__file__).resolve().parent
base=lab.parent
repo=Path.cwd()
parent=base/"json-encoder-allocation-r542/final"
image=parent/"frozen/candidate"
identity=json.loads((parent/"frozen-identity.json").read_text(encoding="utf-8"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=identity["imageFiles"]["candidate"]
assert len(files)==32 and files["Lokad.Lython.dll"].startswith("33025cee")
assert all(sha(image/n)==digest for n,digest in files.items())
assert not subprocess.check_output(["git","diff","d9234f876","HEAD","--","src"])
catalog=json.loads((parent/"representative.json").read_text(encoding="utf-8"))
csv=json.loads((base/"numeric-compiler-facts-r532/representative.json").read_text(encoding="utf-8"))
selected=[
    ("large-manifest",next(c for c in catalog["cases"] if c["id"]=="scripts.config-manifest.deep-records")),
    ("small-manifest",next(c for c in catalog["cases"] if c["id"]=="scripts.config-manifest.small")),
    ("csv-invoice",next(c for c in csv["cases"] if c["id"]=="scripts.csv-invoice.large")),
]
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
catalog["performanceQualified"]=False
catalog["cases"]=[case for _,case in selected]
path=lab/"catalog.json"
path.write_text(json.dumps(catalog,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
with (lab/"verify.log").open("w",encoding="utf-8") as log:
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",path,
                    "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",repo/"benchmarks/cpython-worker.py",
                    "--out",lab/"verification.json"],env=env,cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=90)
prior=(base/"json-encoder-allocation-r542/capture.py").read_text(encoding="utf-8-sig")
for name,case in selected:
    folder=lab/name
    folder.mkdir()
    s=prior.replace("prior=r.parent/'native-json-encoding-options-r540'",
                    "prior=r.parent.parent/'json-encoder-allocation-r542/final'")
    s=s.replace("startswith('7170869d')", "startswith('33025cee')")
    s=s.replace("catalog=r/'catalog.json'","catalog=r.parent/'catalog.json'")
    s=s.replace("scripts.config-manifest.deep-records",case["id"])
    s=s.replace("gc-verbose","dotnet-sampled-thread-time").replace("'manifest.nettrace'","'worker.nettrace'")
    s=s.replace("single owned local allocation diagnostic","single owned local sampled-thread diagnostic")
    s=s.replace("One local warmed whole-worker allocation diagnostic, not a quiet elapsed comparison. GC tick sampling includes fixture resets, protocol, validation and cleanup; not exact per-type allocation bytes or removable CPU.",
                "Managed active-stack attribution on a local warmed worker. Thread samples include protocol and I/O and do not constitute CPU or elapsed percentages.")
    s=s.replace("One local allocation capture complete","One local sampled-thread capture complete")
    (folder/"capture.py").write_text(s,encoding="utf-8",newline="\n")
    subprocess.run(["C:/Python313/python.exe","-X","utf8",folder/"capture.py"],cwd=repo,env=env,check=True,timeout=90)
