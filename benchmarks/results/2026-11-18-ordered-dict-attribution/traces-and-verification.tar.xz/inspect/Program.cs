using Microsoft.Diagnostics.Tracing.Etlx;
using System.Text.Json;

var etlx = Path.ChangeExtension(args[0], ".etlx");
if (!File.Exists(etlx)) TraceLog.CreateFromEventPipeDataFile(args[0], etlx, new TraceLogOptions());
using var trace = new TraceLog(etlx);
var kinds = new Dictionary<string, int>();
var stacks = new Dictionary<string, int>();
var annotated = new Dictionary<string, int>();
var counts = new Dictionary<string, int>();
var tupleOrigins = new Dictionary<string, int>();
var managed = 0;
var rooted = 0;
var unresolved = 0;
foreach (var e in trace.Events)
{
    if (e.ProviderName != "Microsoft-DotNETCore-SampleProfiler" || e.EventName != "Thread/Sample") continue;
    var kind = e.PayloadByName("Type")?.ToString() ?? "<unclassified>";
    kinds[kind] = kinds.GetValueOrDefault(kind) + 1;
    if (kind != "Managed") continue;
    managed++;
    var frames = new List<string>();
    for (var stack = e.CallStack(); stack is not null; stack = stack.Caller)
        frames.Add(stack.CodeAddress.FullMethodName);
    var nearest = frames.FirstOrDefault(f => f.StartsWith("Lokad.Lython.", StringComparison.Ordinal));
    if (nearest is null)
    {
        unresolved++;
        continue;
    }
    rooted++;
    stacks[nearest] = stacks.GetValueOrDefault(nearest) + 1;
    if (nearest.Contains("PyTuple.FromIntegerSlots"))
    {
        var path = string.Join(" -> ", frames.Where(f => f.StartsWith("Lokad.Lython.", StringComparison.Ordinal))
            .Take(9).Select(f => f.Split('(')[0]));
        tupleOrigins[path] = tupleOrigins.GetValueOrDefault(path) + 1;
    }
    var layer = new (string Name, Func<string, bool> Match)[]
    {
        ("Native dictionary entries", s => s.Contains("PyDict") && s.Contains("NativeEntries")),
        ("Dictionary version iterator", s => s.Contains("PyDict") && s.Contains("EnumerateItems")),
        ("Native dictionary keys or values", s => s.Contains("PyDict") && (s.Contains("NativeKeys") || s.Contains("NativeValues"))),
        ("All PyDict runtime", s => s.StartsWith("Lokad.Lython.Runtime.PyDict", StringComparison.Ordinal)),
        ("JSON sort and snapshot", s => s.Contains("CollectSortedJsonEntries") || s.Contains("ExecutionSort")),
        ("JSON byte output", s => s.Contains("JsonModule.AppendJson")),
        ("Shared byte builder", s => s.Contains("GovernedByteBuilder")),
        ("JSON iterator", s => s.Contains("JsonEncodeIterator")),
        ("JSON parse", s => s.Contains("ReadJsonValue") || s.Contains("ParseJsonText") || s.Contains("ReadJsonObject")),
        ("CSV reader", s => s.Contains("CsvReader") || s.Contains("CsvParser") || s.Contains("DictReader")),
        ("Host file", s => s.Contains("TextFileHandle") || s.Contains("ComparisonFileHost"))
    };
    foreach (var (name, match) in layer)
    {
        if (frames.Any(match)) counts[name] = counts.GetValueOrDefault(name) + 1;
        if (match(nearest)) annotated[name] = annotated.GetValueOrDefault(name) + 1;
    }
}
var output = new
{
    kinds, managed, rooted, unresolved, inclusiveOverlapping = counts, nearestGroups = annotated,
    tupleOrigins, nearestLython = stacks.OrderByDescending(x => x.Value).ToDictionary(),
    interpretation = "Managed thread samples rooted in a Lython frame; counts overlap. Excludes External samples, does not estimate CPU share or removable latency."
};
File.WriteAllText(args[1], JsonSerializer.Serialize(output, new JsonSerializerOptions { WriteIndented = true }) + "\n");
Console.WriteLine(JsonSerializer.Serialize(new { managed, rooted, unresolved, inclusive = counts, nearest = annotated }));
