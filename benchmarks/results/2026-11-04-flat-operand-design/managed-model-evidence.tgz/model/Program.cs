using System.Collections;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;
const BindingFlags Flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
static object? Get(object o, string n) => o.GetType().GetProperty(n, Flags)!.GetValue(o);
static object[] Items(object o, string n) => ((IEnumerable)Get(o,n)!).Cast<object>().ToArray();
long ArrayStride(Type t) {
    var empty=Array.CreateInstance(t,0);var warm=Array.CreateInstance(t,4096);GC.KeepAlive(warm);
    var start=GC.GetAllocatedBytesForCurrentThread();var a=Array.CreateInstance(t,4096);var large=GC.GetAllocatedBytesForCurrentThread()-start;
    start=GC.GetAllocatedBytesForCurrentThread();var b=Array.CreateInstance(t,0);var small=GC.GetAllocatedBytesForCurrentThread()-start;
    GC.KeepAlive(a);GC.KeepAlive(b);return (large-small)/4096;
}
var asm=typeof(LythonEngine).Assembly;
var shapes=new { actualInstruction=ArrayStride(asm.GetType("Lokad.Lython.Frontend.ExecutableInstruction")!),
    threeOperandModel=ArrayStride(typeof(ThreeOperand)),fourOperandModel=ArrayStride(typeof(FourOperand)),fiveOperandModel=ArrayStride(typeof(FiveOperand)),
    actualNativeNode=ArrayStride(asm.GetType("Lokad.Lython.Frontend.NativeReturnNode")!) };
var result = new List<object>();
if(args[0]=="--json-state")
{
    var json = typeof(LythonEngine).Assembly.GetTypes().Single(t=>t.Name=="JsonModule");
    var states=json.GetMethods(Flags).Where(m=>m.Name is "ReadJsonObjectAsync" or "ReadJsonArrayAsync" or "ReadJsonContainerAsync")
        .Select(m=>new {method=m.Name,fields=m.GetCustomAttribute<System.Runtime.CompilerServices.AsyncStateMachineAttribute>()!
            .StateMachineType.GetFields(Flags).Select(f=>new {f.Name,type=f.FieldType.ToString()}).ToArray()}).ToArray();
    Console.WriteLine(JsonSerializer.Serialize(states,new JsonSerializerOptions{WriteIndented=true}));
    return;
}
using var catalog = JsonDocument.Parse(File.ReadAllBytes(args[0]));
foreach(var item in catalog.RootElement.GetProperty("cases").EnumerateArray().Take(6))
{
    using var script = new LythonEngine().Compile(item.GetProperty("source").GetString()!);
    if(!script.IsValid) throw new InvalidOperationException(JsonSerializer.Serialize(script.Diagnostics));
    var runner = (Delegate)typeof(LythonCompiledScript).GetField("_runner",Flags)!.GetValue(script)!;
    var executable = runner.Target!.GetType().GetField("executableScript",Flags)!.GetValue(runner.Target)!;
    var code = Get(executable,"EntryPoint")!;
    var seen = new HashSet<object>(ReferenceEqualityComparer.Instance);
    var codes = new List<object>();
    Visit(code);
    result.Add(new { id=item.GetProperty("id").GetString(), sourceSHA256=item.GetProperty("sourceSha256").GetString(), codes });
    void Visit(object current)
    {
        if(!seen.Add(current)) return;
        var instructions = Items(current,"Instructions");
        var listing = instructions.Select((v,index) => {
            var op = Get(v,"OpCode")!.ToString()!;
            return new {index,op,span=Get(v,"Span"),
                slot=op is "LoadLocal" or "StoreLocal" ? (int?)Get(v,"LocalSlot"):null,
                target=op is "Jump" or "AbruptJump" or "ForNext" or "JumpIfFalse" or "EndFinally" ? (int?)Get(v,"TargetIndex"):null,
                operation=op=="ApplyOperation" ? Items(current,"Constants")[(int)Get(v,"ConstantIndex")!].GetType().Name:null};
        }).ToArray();
        codes.Add(new { name=Get(current,"Name"),nativeReturn=Get(current,"NativeReturn") is not null,
            locals=Items(current,"LocalNames"), operandCapacity=Get(current,"OperandCapacity"),
            instructionCount=listing.Length,opcodes=listing.GroupBy(x=>x.op).ToDictionary(g=>g.Key,g=>g.Count()),listing,nativeNodeCount=(Get(current,"NativeReturn") as Array)?.Length??0,callSites=Items(current,"CallSites").Select(c=>new{arguments=Get(c,"ArgumentCount"),receiver=Get(c,"HasReceiver"),offset=Get(c,"ArgumentOffset")}).ToArray() });
        foreach(var function in Items(current,"Functions")) Visit(Get(function,"CodeObject")!);
        foreach(var value in Items(current,"Constants"))
            if(value is not null && value.GetType().GetProperty("CodeObject",Flags) is {} prop) Visit(prop.GetValue(value)!);
    }
}
var assembly=typeof(LythonEngine).Assembly.Location;
Console.WriteLine(JsonSerializer.Serialize(new {runtime=System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription,shapes, coreSHA256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(assembly))),cases=result },new JsonSerializerOptions{WriteIndented=true}));

internal readonly record struct ThreeOperand(int Destination,int First,int Second,int Op,LythonSourceSpan Span);
internal readonly record struct FourOperand(int Destination,int First,int Second,int Fourth,int Op,LythonSourceSpan Span);

internal readonly record struct FiveOperand(int Destination,int First,int Second,int Auxiliary,int LiveExtent,int Op,LythonSourceSpan Span);
