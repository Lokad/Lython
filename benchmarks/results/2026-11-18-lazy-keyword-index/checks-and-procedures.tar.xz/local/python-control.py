
class Later:
    def __init__(self, keys):
        self.names = keys
    def keys(self):
        print('keys')
        return self.names
    def __getitem__(self, name):
        print('read', name)
        return 3

def forward(*args, **kwargs):
    print(args, list(kwargs), list(kwargs)[0] is original)

original = ''.join(['café', '_key'])
prefix = {original: 1}
try:
    forward(5, **prefix, **Later(['extra', 'café_key']))
except TypeError:
    print('collision')
forward(6, **prefix, **Later(['extra']))

