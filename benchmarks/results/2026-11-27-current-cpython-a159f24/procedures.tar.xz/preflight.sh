#!/bin/bash
set -euo pipefail
root=/mnt/d/code/Lython/.git/agent-notes/review-20261031
lab="$root/current-checkpoint-b1906-20261127"
image="$root/generator-row-workspace-refined-20261127/comparison/candidate"
quiet="$lab/comparison/quiet"
export DOTNET_ROOT="$HOME/.dotnet"
export TMPDIR=/dev/shm
"$DOTNET_ROOT/dotnet" "$image/Lokad.Lython.Benchmarks.dll" --compare verify --catalog "$quiet/representative.json" \
 --dotnet "$DOTNET_ROOT/dotnet" --python "$root/bench-cpython-3.13.16-runtime/runtime/bin/python3.13" \
 --python-worker "$quiet/cpython-worker.py" --out "$lab/local-verify.json"
