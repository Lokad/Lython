from hashlib import sha256
from pathlib import Path
from shutil import copyfile
import json
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
notes = lab.parent
old = notes / "current-quiet-script-checkpoint-20261127/comparison/quiet"
calls = notes / "generator-row-workspace-refined-20261127/comparison"
donor = calls / "quiet"
filesearch = notes / "current-cpython-checkpoint-20261127/comparison/quiet"
quiet = lab / "comparison/quiet"
quiet.mkdir(parents=True)
read = lambda p: json.loads(p.read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()
def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n",encoding="utf-8",newline="\n")
def catalog(folder):
    p = folder / "representative.json"
    assert digest(p) == read(folder / "identity.json")["catalogs"][p.name]["sha256"]
    return read(p)

base = subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip()
assert base.startswith("a159f24f2")
matched = read(calls / "identity.json")
diff = subprocess.check_output(["git","diff","--binary",matched["sourceRevision"],base,"--","src"],cwd=repo)
assert sha256(diff).hexdigest() == matched["sourcePatchSHA256"]
image = matched["imageFiles"]["candidate"]
assert len(image) == 32 and {p.name:digest(p) for p in (calls / "candidate").iterdir()} == image
assert read(donor / "identity.json")["imageFiles"]["candidate"] == image
terminal = read(donor / "terminal-status.json")
receipt = terminal["receipt"]
assert not terminal["live"] and terminal["exitCode"] == "0" and not terminal["fixtures"]
assert all(receipt[k] for k in ("complete","allWorkersJoined","guestFixturesRemoved","quietBeforeAndAfter","archivedAndVerifiedUnderLease"))
assert digest(donor / "observations.tar.xz") == receipt["archiveSHA256"]
assert digest(old / "cpython-worker.py") == matched["cpythonWorkerSHA256"]
copyfile(old / "cpython-worker.py", quiet / "cpython-worker.py")

selected = catalog(old)
earlier = {case["id"]:case for case in catalog(filesearch)["cases"]}
text_first = "diagnostic.file-search-first-line"
text_later = "scripts.file-search.large"
generated = "diagnostic.generated-ordinary-definitions"
selected["cases"] += [earlier[id] for id in (text_first,text_later,generated)]
write(quiet / "representative.json", selected)
configuration = next(case for case in selected["cases"] if case["id"] == "scripts.config-edit.small")
write(quiet / "fresh-config.json", dict(selected, cases=[configuration]))
shipment, dense, csv = [case["id"] for case in selected["cases"][:3]]
jobs = [[shipment,"warm-async"],[dense,"warm"],[csv,"warm"],[text_first,"warm"],
        [generated,"compile"],[shipment,"warm"],[text_later,"warm"],["scripts.config-edit.small","warm"],
        [generated,"compile-run"],["scripts.config-edit.small","compile-run"]]
write(quiet / "jobs.json",jobs)
stage_name="script-cpython-quiet-b1906-20261127"
identity = dict(sourceRevision=base, productionHead=base, purpose="Current whole-script CPython checkpoint.",
    imageFiles={"candidate":image}, coreSHA256={k:image["Lokad.Lython.dll"] for k in ("candidate","candidate-control")},
    auxiliaryFiles={k:v for k,v in image.items() if k != "Lokad.Lython.dll"},
    frozenImage="/home/lokad/lython-bench-checks/" + stage_name + "/candidate",
    catalogs={name:{"sha256":digest(quiet/name)} for name in ("representative.json","fresh-config.json","jobs.json")},
    expectedCPythonSHA256=matched["expectedCPythonSHA256"],cpythonWorkerSHA256=matched["cpythonWorkerSHA256"],
    donorArchiveSHA256=receipt["archiveSHA256"])
write(quiet / "identity.json",identity)
copyfile(old / "run.sh",quiet / "run.sh")
assert b"\r" not in (quiet / "run.sh").read_bytes()
collect = (old / "collect.py").read_text(encoding="utf-8")
collect=collect.replace("len(jobs) == 6","len(jobs) == 10").replace("started<325","started<450")
collect=collect.replace("lython-b1896-cpython-fixtures","lython-b1906-cpython-fixtures")
collect=collect.replace("    time.sleep(20)",'''    fresh = out/'fresh'
    fresh.mkdir()
    for attempt in range(7):
        receipt = fresh/f'{attempt:02d}.json'
        subprocess.run([dotnet, worker, '--compare', 'smoke-fresh', '--catalog', root/'fresh-config.json',
            '--dotnet', dotnet, '--python', python, '--python-worker', root/'cpython-worker.py', '--out', receipt],
            env=env, check=True, timeout=35)
        observed=json.loads(receipt.read_text())
        assert observed['state']=='Completed' and observed['caseCount']==1
        assert observed['catalogSha256']==identity['catalogs']['fresh-config.json']['sha256']
        assert observed['launched']['python']['sha256']==identity['expectedCPythonSHA256']
        assert observed['launched']['library']['sha256']==identity['coreSHA256']['candidate']
        assert observed['launched']['adapter']['sha256']==identity['imageFiles']['candidate']['Lokad.Lython.Benchmarks.dll']
    time.sleep(20)''')
collect=collect.replace("'representative.json','jobs.json','confirmation'","'representative.json','fresh-config.json','jobs.json','confirmation'")
compile(collect,"collect.py","exec")
(quiet / "collect.py").write_text(collect,encoding="utf-8",newline="\n")
paths={name:quiet/name for name in ("identity.json","representative.json","fresh-config.json","jobs.json","cpython-worker.py","run.sh","collect.py")}
payload=quiet/"stage.tar.gz"
with tarfile.open(payload,"w:gz") as archive:
    for name,path in paths.items(): archive.add(path,arcname=name)
manifest={name:dict(length=p.stat().st_size,sha256=digest(p)) for name,p in paths.items()}
write(quiet/"upload.json",dict(root=stage_name,donor=read(donor/"upload.json")["root"],donorFiles=image,
    donorArchive=receipt["archiveSHA256"],payloadSHA256=digest(payload),files=manifest,
    expandedBytes=sum(row["length"] for row in manifest.values()),minimumAfterStageBytes=12*1024*1024))
vm=(old.parents[1]/"quiet-vm.py").read_text(encoding="utf-8")
vm=vm.replace("lython-b1896-current-cpython","lython-b1906-current-cpython")
vm=vm.replace("proof['caseCount']==4","proof['caseCount']==7").replace("RuntimeMaxSec=355","RuntimeMaxSec=535")
compile(vm,"quiet-vm.py","exec")
(lab / "quiet-vm.py").write_text(vm,encoding="utf-8",newline="\n")
print(base, len(jobs), "warm/compile lanes",sum(row["length"] for row in manifest.values()),"bytes to stage")
