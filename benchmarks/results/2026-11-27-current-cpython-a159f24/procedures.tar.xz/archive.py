from pathlib import Path
from statistics import median, quantiles
import hashlib,json,tarfile
from shutil import copyfile

lab=Path(__file__).resolve().parent
quiet=lab/"comparison/quiet"
read=lambda p:json.loads(p.read_text(encoding="utf-8"))
terminal=read(quiet/"terminal-status.json")
assert not terminal["live"] and not terminal["fixtures"] and terminal["exitCode"]=="0"
receipt=terminal["receipt"]
archive=quiet/"observations.tar.xz"
assert hashlib.sha256(archive.read_bytes()).hexdigest() == receipt["archiveSHA256"]
image=read(quiet/"identity.json")
case_by_id={r["id"]:r for r in read(quiet/"representative.json")["cases"]}
with tarfile.open(archive) as bundle:
    raw=json.load(bundle.extractfile("confirmation/confirmation.json"))
    identity=json.load(bundle.extractfile("identity.json"))
    jobs=json.load(bundle.extractfile("jobs.json"))
    assert all(json.load(bundle.extractfile(f"confirmation/machine-{phase}.json"))["gate"]["quiet"] for phase in ("before","after"))
    for name, expected in image["catalogs"].items():
        assert hashlib.sha256(bundle.extractfile(name).read()).hexdigest()==expected["sha256"]
assert raw["complete"] and len(raw["jobs"])==10 and receipt["warmJobs"]==10
assert all(receipt[k] for k in ["complete","allWorkersJoined","guestFixturesRemoved","quietBeforeAndAfter","archivedAndVerifiedUnderLease"])
assert identity==image and jobs==read(quiet/"jobs.json")
assert [(job["case"], job["lanes"][0]) for job in raw["jobs"]]==[tuple(j) for j in jobs]
rows=[]
pinned=set()
for job in raw["jobs"]:
    case=case_by_id[job["case"]]
    lane,=job["lanes"]
    assert job["workersJoinedAndFixturesRemoved"] and len(job["samples"])==28
    med={};cpu={};iqr={}
    for label,worker in job["identities"].items():
        assert worker["catalogSha256"]==image["catalogs"]["representative.json"]["sha256"]
        if label.startswith("CPython"):
            assert worker["version"].startswith("3.13.16")
            pinned.add(worker["executableSha256"])
        else:
            assert worker["runtimeVersion"]=="11.0.0"
            libraries={Path(entry["path"]).name:entry["sha256"] for entry in worker["libraries"]}
            assert libraries["Lokad.Lython.dll"]==image["coreSHA256"][label]
            assert libraries["Lokad.Lython.Benchmarks.dll"]==image["imageFiles"]["candidate"]["Lokad.Lython.Benchmarks.dll"]
        samples=[s for s in job["samples"]if s["engine"]==label]
        assert len(samples)==7
        times=[];wider=[]
        for sample in samples:
            r=sample["response"]
            assert r["status"]=="Completed" and r["completedInvocations"]>0 and all(r[k]==case[k] for k in ["sourceSha256","fixtureSha256","expectedOutputSha256"])
            assert r["actualOutputSha256"]==(None if lane=="compile" else case["expectedOutputSha256"])
            assert r.get("actualFilesSha256")== (None if lane=="compile" else case.get("expectedFilesSha256"))
            times.append(r["elapsedTicks"]*1000/r["clockFrequency"]/r["completedInvocations"])
            wider.append(sample["externalProcessCpuTicks"]*1000/sample["externalCpuFrequency"]/r["completedInvocations"])
        med[label]=median(times)
        cpu[label]=median(wider)
        q=quantiles(times,n=4,method="inclusive")
        iqr[label]=(q[2]-q[0])*100/med[label]
    span=lambda v,l:[min(v[l],v[l+"-control"]),max(v[l],v[l+"-control"])]
    div=lambda v:sorted(a/b for a in span(v,"candidate") for b in span(v,"CPython"))
    spreads=lambda l:(max(span(med,l))/min(span(med,l))-1)*100
    row=dict(case=case["id"],lane=lane,lythonMs=span(med,"candidate"),cpythonMs=span(med,"CPython"),ratio=[min(div(med)),max(div(med))],widerCpuRatio=[min(div(cpu)),max(div(cpu))],lythonControlPercent=spreads("candidate"),cpythonControlPercent=spreads("CPython"),maxIQRPercent=max(iqr.values()),sourceUtf8Bytes=case["sourceUtf8Bytes"],fixtureSha256=case["fixtureSha256"])
    rows.append(row)
    print(case["id"],lane,"L [",*map(lambda n:f"{n:.5f}",row["lythonMs"]),"] C [",*map(lambda n:f"{n:.5f}",row["cpythonMs"]),"]",*[f"{n:.4f}" for n in row["ratio"]],"spread",*[f"{row[k]:.2f}%" for k in ["lythonControlPercent","cpythonControlPercent"]])
assert pinned == {image["expectedCPythonSHA256"]}
assert sum(len(job["samples"]) for job in raw["jobs"])==280
proof=read(quiet/"candidate-remote-verify.json")
assert proof["state"]=="Completed" and proof["caseCount"]==7
assert proof["launched"]["library"]["sha256"]==image["coreSHA256"]["candidate"]
assert proof["launched"]["adapter"]["sha256"]==image["imageFiles"]["candidate"]["Lokad.Lython.Benchmarks.dll"]
assert proof["launched"]["python"]["sha256"]==image["expectedCPythonSHA256"]
assert proof["catalogSha256"]==image["catalogs"]["representative.json"]["sha256"]
stage=read(quiet/"stage-custody.json")
assert stage["streamed"] and stage["reused"]=={"donor":32}
(quiet/"summary.json").write_text(json.dumps(dict(source=image["sourceRevision"],cpythonVersion="3.13.16",cpythonExecutableSHA256=next(iter(pinned)),elapsedSeconds=raw["elapsedSeconds"],timedBatches=sum(len(job["samples"]) for job in raw["jobs"]),performanceQualified=False,passedQuietCheck=True,rows=rows),indent=2)+"\n",encoding="utf-8",newline="\n")


fresh = {"Lython": [], "CPython": []}
config=read(quiet/"fresh-config.json")["cases"][0]
assert config["id"]=="scripts.config-edit.small"
with tarfile.open(archive) as bundle:
    assert hashlib.sha256(bundle.extractfile("fresh-config.json").read()).hexdigest()==image["catalogs"]["fresh-config.json"]["sha256"]
    for attempt in range(7):
        fresh_run=json.load(bundle.extractfile(f"confirmation/fresh/{attempt:02d}.json"))
        assert fresh_run["state"]=="Completed" and fresh_run["caseCount"]==1
        assert not fresh_run["performanceQualified"]
        assert fresh_run["catalogSha256"]==image["catalogs"]["fresh-config.json"]["sha256"]
        assert fresh_run["launched"]["library"]["sha256"]==image["coreSHA256"]["candidate"]
        assert fresh_run["launched"]["adapter"]["sha256"]==image["imageFiles"]["candidate"]["Lokad.Lython.Benchmarks.dll"]
        assert fresh_run["launched"]["python"]["sha256"]==image["expectedCPythonSHA256"]
        assert [row["engine"] for row in fresh_run["rows"]]==["Lython","CPython"]
        for row in fresh_run["rows"]:
            observed=row["observation"]
            result=observed["response"]
            assert observed["status"]==result["status"]=="Equivalent"
            assert result["completedInvocations"]==1 and result["caseId"]==config["id"]
            assert all(result[k]==config[k] for k in ["sourceSha256","fixtureSha256","expectedOutputSha256"])
            assert result["actualOutputSha256"]==config["expectedOutputSha256"]
            assert result["actualFilesSha256"]==config["expectedFilesSha256"]
            assert observed["clockFrequency"]==fresh_run["parentClock"]["frequency"] and observed["elapsedTicks"]>0
            fresh[row["engine"]].append(observed["elapsedTicks"]*1000/observed["clockFrequency"])
medians={engine:median(times) for engine,times in fresh.items()}
summary=dict(source=image["sourceRevision"],case=config["id"],launchPairs=7,performanceQualified=False,
    timingBoundary=fresh_run["timerBoundary"],elapsedMilliseconds=fresh,mediansMilliseconds=medians,
    medianRatio=medians["Lython"]/medians["CPython"])
(quiet/"fresh-summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8",newline="\n")
print("fresh-process",medians,summary["medianRatio"])

out=lab.parents[3]/"benchmarks/results/2026-11-27-current-cpython-a159f24"
out.mkdir(exist_ok=True)
names=["identity.json","summary.json","observations.tar.xz","archive-receipt.json","stage-custody.json","terminal-status.json","fresh-summary.json"]
for name in names: copyfile(quiet/name,out/name)
paths=[lab/name for name in ["prepare.py","quiet-vm.py","archive.py","preflight.sh","launch-console.log","local-verify.json"]]
paths.extend(quiet/name for name in ["upload.json","candidate-remote-verify.json","launch.log","exit-code.txt"])
with tarfile.open(out/"procedures.tar.xz","w:xz") as output:
    for p in paths:
        output.add(p,arcname=p.relative_to(lab))
with tarfile.open(out/"procedures.tar.xz") as output:
    assert all(output.extractfile(p.relative_to(lab).as_posix()).read()==p.read_bytes() for p in paths)

