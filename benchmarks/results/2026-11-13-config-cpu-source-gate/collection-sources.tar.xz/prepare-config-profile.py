from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent;out=r.parent/'config-startup-r297';out.mkdir();old=r.parent/'direct-range-r293/report-cpu-corrected'
root='/home/lokad/lython-bench-checks/config-cpu-b653-20261113';oldroot='/home/lokad/lython-bench-checks/report-cpu-b650-20261113'
archivePath=Path('benchmarks/results/2026-11-12-utf16-cpython-checkpoint/observations.tgz')
with tarfile.open(archivePath)as archive:
 catalog=json.loads(archive.extractfile('representative.json').read())
 cases=[c for c in catalog['cases']if'config-edit'in c['id']];assert len(cases)==1,[c['id']for c in catalog['cases']]
 case=cases[0];catalog['cases']=cases
(out/'catalog.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8',newline='\n')
identity=json.loads((r/'b652/identity.json').read_text(encoding='utf-8'));identity['sourceRevision']='31d65e01/e34cacaf current complete config edit invocation setup CPU source gate';identity['catalogSHA256']=hashlib.sha256((out/'catalog.json').read_bytes()).hexdigest();identity['purpose']='One current complete config-edit CPU source gate; eight-second199Hz capture, no timing or speed claim'
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
code=(old/'ops-profile.py').read_text(encoding='utf-8').replace(oldroot,root).replace('[("report", "scripts.report-render.large", "warm")]',repr([('config',case['id'],'warm')])).replace('count = 128 #','count = 4096 #')
ast.parse(code);(out/'ops-profile.py').write_text(code,encoding='utf-8',newline='\n')
code=(old/'collect.py').read_text(encoding='utf-8').replace(oldroot,root).replace('profiles/report/','profiles/config/').replace("source='917e01d8/9e53b9fa'","source='31d65e01/e34cacaf'")
ast.parse(code);(out/'collect.py').write_text(code,encoding='utf-8',newline='\n')
(out/'run.sh').write_text('set -eu\nroot='+root+'\ntrap \'result=$?; printf "%s\\n" "$result" > "$root/exit-code.txt"\' EXIT\npython3 "$root/collect.py"\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as archive:
 for name in ['catalog.json','identity.json','collect.py','ops-profile.py','run.sh']:archive.add(out/name,arcname=name)
config=dict(root=root,unit='lython-b653-config-cpu-20261113',sourceRoot='/home/lokad/lython-bench-checks/report-external-b652-20261113',identity=identity,retire=[],payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest())
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
launch=(r.parent/'direct-range-r293/launch-corrected-report.py').read_text(encoding='utf-8').replace("Path(__file__).parent/'report-cpu-corrected'","Path(__file__).parent").replace("  os.link(source/'representative.json',root/'catalog.json')\n",'').replace('lython-b650-fixtures','lython-b653-fixtures')
ast.parse(launch);(out/'launch.py').write_text(launch,encoding='utf-8',newline='\n')
retrieve=(old/'retrieve.py').read_text(encoding='utf-8').replace('report-cpu-b650-20261113','config-cpu-b653-20261113').replace('lython-b650-report-cpu-20261113','lython-b653-config-cpu-20261113')
ast.parse(retrieve);(out/'retrieve.py').write_text(retrieve,encoding='utf-8',newline='\n')
analyze=(old/'analyze.py').read_text(encoding='utf-8').replace('profiles/report/','profiles/config/');ast.parse(analyze);(out/'analyze.py').write_text(analyze,encoding='utf-8',newline='\n')
(out/'source-gate.json').write_text(json.dumps(dict(sourceRevision='31d65e01',coreSHA256=identity['coreSHA256']['candidate'],historicalFixture=archivePath.as_posix()+'!representative.json',caseId=case['id'],sourceSha256=case['sourceSha256'],fixtureSha256=case['fixtureSha256'],hypothesis='Repeated immutable builtin/type/exception graph setup may remain material for complete small config scripts. Already-shared functions/signatures are the baseline; mutable execution-funded namespace caches cannot be shared.',stop='One usable eight-second current-source capture/source review; select a coherent migration only if supported, otherwise proceed without another registry/controller.',performanceComparison=False),indent=2)+'\n',encoding='utf-8',newline='\n')
print('R297 bounded gate:',case['id'],'only;12s warmup/eight-second CPU capture; source unchanged, owner120s plus join margin.',flush=True)
