from pathlib import Path
import base64,datetime,hashlib,json,shutil,subprocess
r=Path(__file__).parent;config=json.loads((r/'config.json').read_text(encoding='utf-8'))
shutil.copyfile(r/'launch.log',r/'launch-manifest-link-failure.log');shutil.copyfile(r/'launch-command.py',r/'launch-manifest-link-failure.py')
specs={name:hashlib.sha256((r/name).read_bytes()).hexdigest()for name in ['catalog.json','identity.json','collect.py','ops-profile.py','run.sh']}
code='''from pathlib import Path
import ast,fcntl,hashlib,json,os,shutil,stat,subprocess
config=CONFIG;specs=SPECS
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['sourceRoot'])
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert root.parent==base and source.parent==base and root.resolve()==root
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not(root/'guest-fixtures').exists()and not(root/'exit-code.txt').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert {p.name for p in root.iterdir()}==set(specs)|{'candidate'}
 for name,sha in specs.items():
  p=root/name;s=p.lstat();assert p.resolve()==p and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and digest(p)==sha
 assert digest(root/'catalog.json')==config['identity']['catalogSHA256']
 assert digest(root/'candidate/Lokad.Lython.dll')==config['identity']['coreSHA256']['candidate']
 for name,sha in config['identity']['auxiliaryFiles'].items():assert digest(root/'candidate'/name)==sha
 for name in ['collect.py','ops-profile.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 assert shutil.disk_usage(root).free>253*1024*1024
 (root/'staging-recovery.json').write_text(json.dumps(dict(freshIdleLease=True,originalFailure='Legacy launcher tried to link the old catalog over the already-staged config-only catalog. Failure preceded mounting or worker launch.',allStagedInputsHashVerified=True,noRowsReplayed=True,freeBytes=shutil.disk_usage(root).free,osFloorMiB=240,evidenceHeadroomMiB=12),indent=2)+'\\n')
 fixture=root/'guest-fixtures';fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b653-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=120','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert'ActiveState=active'in live and'MainPID=0'not in live;print(live)
'''.replace('CONFIG',repr(config)).replace('SPECS',repr(specs))
compile(code,'resume-command.py','exec');(r/'resume-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
encoded=base64.b64encode(code.encode()).decode();command="python3 -c 'import base64;exec(base64.b64decode(\""+encoded+"\"))'"
done=subprocess.run(ssh+[command],capture_output=True);(r/'resume.log').write_bytes(done.stdout+done.stderr);print((done.stdout+done.stderr).decode(),flush=True);assert done.returncode==0
now=datetime.datetime.now(datetime.timezone.utc)
(r/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=180)).isoformat(),ownerSeconds=120,stopSeconds=30,marginSeconds=30),indent=2)+'\n',encoding='utf-8',newline='\n')
