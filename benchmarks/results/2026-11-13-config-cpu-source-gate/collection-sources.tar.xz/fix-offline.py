from pathlib import Path
import shutil,subprocess
r=Path(__file__).parent;p=r/'analyze.py';shutil.copyfile(p,r/'analyze-report-path-failure.py')
s=p.read_text(encoding='utf-8').replace('profiles/report','profiles/config').replace('917e01d8/9e53b9fa','31d65e01/e34cacaf').replace('Report CPU gate:','Config CPU gate:')
p.write_text(s,encoding='utf-8',newline='\n');subprocess.run(['python','-X','utf8',str(p)],check=True)
