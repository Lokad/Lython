R166 closes one material current text CPU-attribution gap before choosing a coherent
whole-script redesign. Reuse the established perf/checked-worker protocol,128-job
warmup requests/64-job capture requests,6s warmup/6s capture, unchanged20s frame
guard, finite120s owner/30s stop/30s margin. No source prototype, elapsed speedup,
new framework or broad ownership/storage campaign. Existing callbacks and output
checks remain in the full script. Whole process includes reset/protocol; classify
guest and host separately. Stop once a usable phase/leaf breakdown identifies actual
work, or retain adverse/missing observations and correct only a demonstrated setup
problem. No automatic design veto. Archive raw/maps before ending the owned run;
join all users and retire RAM/maps only after evidence transfer. Core/workers/catalog
reuse verified persistent B514 images; publication remains postponed.
