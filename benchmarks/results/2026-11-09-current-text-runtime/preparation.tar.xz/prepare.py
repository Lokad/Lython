from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
base=Path(__file__).parent;r=base/'text-runtime-r166';r.mkdir(exist_ok=False)
old=base/'csv-runtime-r162/confirmation';current=base/'json-item-sort-r165/b514'
for n in ['ops-profile.py','analyze-cpu-guest.py','archive.py','attribute.py','run.sh','retrieve.py','launch.py']:
 s=(old/n).read_text(encoding='utf-8').replace('csv-runtime-b512','text-runtime-b515').replace('lython-b512-csv-runtime','lython-b515-text-runtime').replace('/dev/shm/lython-b512','/dev/shm/lython-b515').replace('lython-b512-fixtures','lython-b515-fixtures').replace('csv-warm','text-warm').replace('scripts.csv-validated-records.large','scripts.text-summary-helpers.large')
 if n=='launch.py':
  s=s.replace("base/'config-boundary-b509-20261109/candidate'","base/'shared-comparison-b514-20261109/candidate'")
  s=s.replace("root.mkdir();a.extractall(root,filter='data')","root.mkdir();a.extractall(root,filter='data')\n os.link(source.parent/'representative.json',root/'catalog.json')\n os.link(source.parent/'final-source.json',root/'core-source.json')")
  s=s.replace("proof['coreSHA256']","proof['candidateCoreSHA256']")
 if n.endswith('.py'):compile(s,n,'exec')
 (r/n).write_text(s,encoding='utf-8',newline='\n')
i=json.loads((current/'identity.json').read_text(encoding='utf-8'));i['sourceRevision']='R164/R165 final precommit freeze, production-source equivalent to committed96e534f9; no postcommit binary claim.';i['coreSHA256']=i['coreSHA256']['candidate']
(r/'identity.json').write_text(json.dumps(i,indent=2)+'\n',encoding='utf-8')
src=json.loads((base/'json-item-sort-r165/source.json').read_text(encoding='utf-8'));assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in src['productionSources'].items())
(r/'current-source-delta.json').write_text(json.dumps(dict(productionSourcesIdentical=True,trackedRevision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),coreSHA256=i['coreSHA256'],note=i['sourceRevision']),indent=2)+'\n',encoding='utf-8')
(r/'selection.md').write_text('''R166 closes one material current text CPU-attribution gap before choosing a coherent
whole-script redesign. Reuse the established perf/checked-worker protocol,128-job
warmup requests/64-job capture requests,6s warmup/6s capture, unchanged20s frame
guard, finite120s owner/30s stop/30s margin. No source prototype, elapsed speedup,
new framework or broad ownership/storage campaign. Existing callbacks and output
checks remain in the full script. Whole process includes reset/protocol; classify
guest and host separately. Stop once a usable phase/leaf breakdown identifies actual
work, or retain adverse/missing observations and correct only a demonstrated setup
problem. No automatic design veto. Archive raw/maps before ending the owned run;
join all users and retire RAM/maps only after evidence transfer. Core/workers/catalog
reuse verified persistent B514 images; publication remains postponed.
''',encoding='utf-8')
(r/'sizing.json').write_text(json.dumps(dict(cases=1,warmupRequestJobs=128,captureRequestJobs=64,targetCaptureSeconds=6,frameGuardSeconds=20,ownerSeconds=120,stopSeconds=30,marginSeconds=30),indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'payload.tgz','w:gz')as t:
 for n in ['ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','identity.json','selection.md','sizing.json','current-source-delta.json']:t.add(r/n,arcname=n)
with tarfile.open(r/'payload.tgz')as t:required=sum(((m.size+4095)//4096)*4096for m in t.getmembers())+252*1024*1024
(r/'payload-sizing.json').write_text(json.dumps(dict(requiredFreeBytes=required,payloadBytes=(r/'payload.tgz').stat().st_size),indent=2)+'\n',encoding='utf-8')
s=(current/'recover-space.py').read_text(encoding='utf-8')
a=s.index('for remote,local in ');z=s.index(':\n',a);s=s[:a]+"for remote,local in [('shared-comparison-b514-20261109','2026-11-09-json-item-comparisons'),('prefix-attribution-b507-20261109','2026-11-09-prefix-generated-code')]"+s[z:]
s=s.replace('shared-comparison-b514-space','text-runtime-b515-space').replace("base/'shared-comparison-b514-20261109'","base/'text-runtime-b515-20261109'").replace('270135296',str(required)).replace('Two redundant remote archives','Selected redundant remote archives')
compile(s,'recover-space','exec');(r/'recover-space.py').write_text(s,encoding='utf-8')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')+'\nR166 selected bounded current-text attribution: existing checked worker/perf,6s\ncapture,128/64-job requests, unchanged20s frame guard,120s lease+30sstop/+30smargin.\nReuse B514 persistent core/catalog/worker and identify precommit source equivalence;\nno new core build or timing gain. Stop at usable phase/leaf evidence before design.\n';p.write_text(s,encoding='utf-8',newline='\n')
print('R166 single text capture prepared, required free bytes',required,flush=True)
