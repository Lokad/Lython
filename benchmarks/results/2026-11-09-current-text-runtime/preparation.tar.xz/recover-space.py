from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).parent
spec=[]
for remote,local in [('shared-comparison-b514-20261109','2026-11-09-json-item-comparisons'),('prefix-attribution-b507-20261109','2026-11-09-prefix-generated-code'),('search-runtime-b501-20261109','2026-11-09-search-runtime-attribution')]:
    p=Path('benchmarks/results')/local/'observations.tgz'
    assert subprocess.check_output(['git','ls-files','--',p.as_posix()],text=True).strip()==p.as_posix()
    spec.append(dict(path='/home/lokad/lython-bench-checks/'+remote+'/observations.tgz',sha256=hashlib.sha256(p.read_bytes()).hexdigest(),size=p.stat().st_size,preservedLocal=p.resolve().as_posix(),tracked=True))
script='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks')
spec=SPEC
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not (base/'text-runtime-b515-20261109').exists()
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*')) and not Path('/dev/shm/lython-b512').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 free=shutil.disk_usage(base).free
 if free>264282112:
  print(json.dumps(dict(skipped=True,beforeFreeBytes=free,requiredFreeBytes=264282112,reason='Fresh space sufficient; no mutation')));__import__('sys').exit(0)
 rows=[]
 for entry in spec:
  p=Path(entry['path']);assert p.resolve(strict=True)==p and p.parent.parent==base and p.name=='observations.tgz'
  info=p.lstat();assert stat.S_ISREG(info.st_mode) and info.st_nlink==1 and info.st_uid==os.getuid() and info.st_gid==os.getgid()
  assert info.st_size==entry['size'] and hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256']
  receipt=json.loads((p.parent/'archive-receipt.json').read_text());assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['archiveSHA256']==entry['sha256']
  parents=[]
  for parent in p.parents:
   meta=parent.lstat();assert stat.S_ISDIR(meta.st_mode) and not parent.is_symlink()
   parents.append(dict(path=str(parent),uid=meta.st_uid,gid=meta.st_gid,mode=oct(meta.st_mode)))
  rows.append(dict(**entry,device=info.st_dev,inode=info.st_ino,links=info.st_nlink,uid=info.st_uid,gid=info.st_gid,mode=oct(info.st_mode),parents=parents,allAliases=[str(p)]))
  if free+sum(Path(e['path']).stat().st_blocks*512 for e in rows)>264282112:break
 assert free+sum(Path(e['path']).stat().st_blocks*512 for e in rows)>264282112, ('Exact copies cannot fund unchanged payload/floors; no mutation',dict(freeBytes=free,requiredBytes=264282112,selectedBytes=sum(Path(e['path']).stat().st_blocks*512 for e in rows)))
 plan=dict(requiredFreeBytes=264282112,freshIdleLease=True,beforeFreeBytes=free,osFloorMiB=240,evidenceHeadroomMiB=12,files=rows,operation='Remove only redundant remote compressed archives. Their raw trees, receipts, frozen workers and byte-identical tracked local archives survive.')
 target=base/'text-runtime-b515-space-plan.json'
 with target.open('x') as f:f.write(json.dumps(plan,indent=2)+'\\n');f.flush();os.fsync(f.fileno())
 for entry in rows:
  p=Path(entry['path']);info=p.lstat()
  assert info.st_dev==entry['device'] and info.st_ino==entry['inode'] and info.st_nlink==1 and hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256']
  p.unlink()
 plan['afterFreeBytes']=shutil.disk_usage(base).free
 assert plan['afterFreeBytes']>free and plan['afterFreeBytes']>(240+12)*1024*1024
 (base/'text-runtime-b515-space-receipt.json').write_text(json.dumps(plan,indent=2)+'\\n')
 print(json.dumps(plan))
'''.replace('SPEC',repr(spec))
compile(script,'remote-space-recovery','exec')
(r/'space-recovery-command.py').write_text(script,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=script,text=True,encoding='utf-8',capture_output=True)
(r/'space-recovery.log').write_text(done.stdout+'\n'+done.stderr,encoding='utf-8')
assert done.returncode==0,done.stderr
data=json.loads(done.stdout)
(r/'space-recovery.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print('Selected redundant remote archives removed under fresh idle lease; exact hashes/single aliases/ownership/parents and pre-mutation plan retained; free bytes',data['beforeFreeBytes'],'to',data['afterFreeBytes'])
