from pathlib import Path
import hashlib,json,shutil,subprocess,xml.etree.ElementTree as ET,zipfile
repo=Path.cwd();r=Path(__file__).parent/'dev78-bridge';r.mkdir();old=r.parent.parent/'regex-dev73-r252'
baseline=json.loads((old/'normal-state-before.json').read_text(encoding='utf-8'))
(r/'normal-state-before.json').write_text(json.dumps({name:hashlib.sha256((repo/name).read_bytes()).hexdigest()for name in baseline},indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['Directory.Build.props','Directory.Packages.props','NuGet.Config','CursorAdmissionTests.cs','workflow-fixture-manifest.json','qualify.py']:
    code=(old/name).read_text(encoding='utf-8').replace('D:/code/Lython/.git/agent-notes/review-20261031/regex-dev73-r252',r.resolve().as_posix()).replace('0.5.0-dev.73','0.5.0-dev.78')
    if name=='qualify.py':
        code=code.replace("assert not target.exists();shutil.copytree(source,target)","\n        if not target.exists():shutil.copytree(source,target)\n        else:\n            for filename,digest in files.items():assert hashlib.sha256((target/filename).read_bytes()).hexdigest()==digest")
    (r/name).write_text(code,encoding='utf-8',newline='\n')
code=(old/'Utf8RegexProvider.cs').read_text(encoding='utf-8')
needle='Timeout.InfiniteTimeSpan, cancellationToken), cancellationToken, utf8Pattern: pattern);';assert code.count(needle)==1
code=code.replace(needle,'Timeout.InfiniteTimeSpan, cancellationToken, inputValidation: Utf8InputValidation.AssumeValid), cancellationToken, utf8Pattern: pattern);')
code=code.replace('// PythonRe 0.4 owns only managed objects, with no program Dispose API.\n            // Drop those references and retire their existing funded scope.\n            if (Interlocked.Exchange(ref _regex, null) is null) return;','// Development bridge retains conservative compilation admission locally;\n            // drain all users before retiring both the backend and that owner.\n            var regex = Interlocked.Exchange(ref _regex, null);\n            if (regex is null) return;\n            regex.Dispose();')
(r/'Utf8RegexProvider.cs').write_text(code,encoding='utf-8',newline='\n')
(r/'feed').mkdir();packages={}
for name in ['Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']:
    file=Path(f'D:/code/utf8regex/artifacts/nuget/{name}.0.5.0-dev.78.nupkg');content=file.read_bytes()
    with zipfile.ZipFile(file)as archive:
        xml=ET.fromstring(archive.read(next(p for p in archive.namelist()if p.endswith('.nuspec'))))
        commit=next(e.attrib['commit']for e in xml.iter()if e.tag.endswith('repository'));assert commit.startswith('faa48f57'),commit
        assemblies={tfm:hashlib.sha256(archive.read(f'lib/{tfm}/{name}.dll')).hexdigest()for tfm in ['net11.0','net10.0']}
    shutil.copyfile(file,r/'feed'/file.name);packages[file.name]=dict(sha256=hashlib.sha256(content).hexdigest(),repositoryCommit=commit,assemblies=assemblies)
identity=dict(consumerRevision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),producerVersion='0.5.0-dev.78',packages=packages,bridge='Existing qualified dev73 native-cursor ownership/current-token bridge, with valid-subject AssumeValid selected through the working unfunded compile overload and conservative local compilation admission. Pattern disposal calls the current backend API. No new core/provider API, normal pin/source change or publication.',limitations='Development semantics/ownership/cancellation qualification only. Final single-match owners, UTF8 names and native token-independent preparation remain separate; actual backend performance not established.')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Isolated dev78 bridge prepared from existing tooling; normal core, adapter, packages and outputs stay unchanged.',flush=True)
