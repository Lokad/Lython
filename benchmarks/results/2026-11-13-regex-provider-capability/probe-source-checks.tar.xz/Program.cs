using Lokad.Utf8Regex;
using Lokad.Utf8Regex.PythonRe;
using System.Text.Json;
var allowance = new Allowance();
var strict = Utf8PythonRegex.Compile("a", PythonReCompileOptions.None, Timeout.InfiniteTimeSpan,
    Utf8ResourcePolicy.Unlimited, Utf8ConstructionPolicy.Default, Timeout.InfiniteTimeSpan,
    CancellationToken.None, inputValidation: Utf8InputValidation.AssumeValid);
var funded = Utf8PythonRegex.Compile("a", PythonReCompileOptions.None, Timeout.InfiniteTimeSpan,
    Utf8ResourcePolicy.Unlimited, Utf8ConstructionPolicy.Default, Timeout.InfiniteTimeSpan,
    CancellationToken.None, allowance, inputValidation: Utf8InputValidation.AssumeValid);
var fundedSetting = funded.InputValidation;
var before = allowance.Reserved;
strict.Dispose(); funded.Dispose();
Console.WriteLine(JsonSerializer.Serialize(new { runtime=System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription,
    unfunded=strict.InputValidation.ToString(),funded=fundedSetting.ToString(),reservedDuring=before,reservedAfter=allowance.Reserved,
    callerSettingHonored=fundedSetting==Utf8InputValidation.AssumeValid,
    purpose="Immutable package contract observation only; no Lython adapter promotion or timing" }));
if(allowance.Reserved!=0)throw new InvalidOperationException("Owner did not return to baseline.");
sealed class Allowance : IUtf8MemoryAllowance {
    private readonly object gate=new(); private ulong reserved;
    public ulong Reserved { get { lock(gate)return reserved; } }
    public bool TryReserve(ulong bytes) { lock(gate) { if(bytes>128UL*1024*1024-reserved)return false;reserved+=bytes;return true; } }
    public void Release(ulong bytes) { lock(gate) { if(bytes>reserved)throw new InvalidOperationException("Unfunded release.");reserved-=bytes; } }
}
