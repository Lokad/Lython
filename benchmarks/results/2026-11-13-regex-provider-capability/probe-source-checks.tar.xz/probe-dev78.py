from pathlib import Path
import hashlib,json,os,subprocess,zipfile
r=Path(__file__).parent/'dev78';r.mkdir();packages=[]
for name in ['Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']:
    package=Path(f'D:/code/utf8regex/artifacts/nuget/{name}.0.5.0-dev.78.nupkg')
    packages.append(dict(file=package.name,sha256=hashlib.sha256(package.read_bytes()).hexdigest()))
    with zipfile.ZipFile(package)as z:
        for framework in ['net11.0','net10.0']:
            destination=r/framework;destination.mkdir(exist_ok=True)
            (destination/f'{name}.dll').write_bytes(z.read(f'lib/{framework}/{name}.dll'))
project='''<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><OutputType>Exe</OutputType><TargetFrameworks>net11.0;net10.0</TargetFrameworks><ImplicitUsings>enable</ImplicitUsings><Nullable>enable</Nullable><IsPackable>false</IsPackable><EnableDefaultCompileItems>false</EnableDefaultCompileItems></PropertyGroup><ItemGroup><Compile Include="Program.cs"/><Reference Include="Lokad.Utf8Regex"><HintPath>$(TargetFramework)/Lokad.Utf8Regex.dll</HintPath></Reference><Reference Include="Lokad.Utf8Regex.PythonRe"><HintPath>$(TargetFramework)/Lokad.Utf8Regex.PythonRe.dll</HintPath></Reference></ItemGroup></Project>'''
(r/'probe.csproj').write_text(project,encoding='utf-8',newline='\n')
program='''using Lokad.Utf8Regex;
using Lokad.Utf8Regex.PythonRe;
using System.Text.Json;
var allowance = new Allowance();
var strict = Utf8PythonRegex.Compile("a", PythonReCompileOptions.None, Timeout.InfiniteTimeSpan,
    Utf8ResourcePolicy.Unlimited, Utf8ConstructionPolicy.Default, Timeout.InfiniteTimeSpan,
    CancellationToken.None, inputValidation: Utf8InputValidation.AssumeValid);
var funded = Utf8PythonRegex.Compile("a", PythonReCompileOptions.None, Timeout.InfiniteTimeSpan,
    Utf8ResourcePolicy.Unlimited, Utf8ConstructionPolicy.Default, Timeout.InfiniteTimeSpan,
    CancellationToken.None, allowance, inputValidation: Utf8InputValidation.AssumeValid);
var fundedSetting = funded.InputValidation;
var before = allowance.Reserved;
strict.Dispose(); funded.Dispose();
Console.WriteLine(JsonSerializer.Serialize(new { runtime=System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription,
    unfunded=strict.InputValidation.ToString(),funded=fundedSetting.ToString(),reservedDuring=before,reservedAfter=allowance.Reserved,
    callerSettingHonored=fundedSetting==Utf8InputValidation.AssumeValid,
    purpose="Immutable package contract observation only; no Lython adapter promotion or timing" }));
if(allowance.Reserved!=0)throw new InvalidOperationException("Owner did not return to baseline.");
sealed class Allowance : IUtf8MemoryAllowance {
    private readonly object gate=new(); private ulong reserved;
    public ulong Reserved { get { lock(gate)return reserved; } }
    public bool TryReserve(ulong bytes) { lock(gate) { if(bytes>128UL*1024*1024-reserved)return false;reserved+=bytes;return true; } }
    public void Release(ulong bytes) { lock(gate) { if(bytes>reserved)throw new InvalidOperationException("Unfunded release.");reserved-=bytes; } }
}
'''
(r/'Program.cs').write_text(program,encoding='utf-8',newline='\n')
sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
with(r/'build.log').open('w',encoding='utf-8',newline='\n')as log:done=subprocess.run([str(sdk/'dotnet.exe'),'build',str(r/'probe.csproj'),'-c','Release','--no-incremental'],env=env,stdout=log,stderr=subprocess.STDOUT)
assert done.returncode==0,(r/'build.log').read_text(encoding='utf-8')
observations=[]
for framework in ['net11.0','net10.0']:
    done=subprocess.run([str(sdk/'dotnet.exe'),str(r/f'bin/Release/{framework}/probe.dll')],env=env,capture_output=True,text=True,encoding='utf-8')
    (r/f'{framework}.stdout').write_text(done.stdout,encoding='utf-8');(r/f'{framework}.stderr').write_text(done.stderr,encoding='utf-8')
    assert done.returncode==0,done.stderr
    observations.append(json.loads(done.stdout));print(done.stdout,flush=True)
(r/'result.json').write_text(json.dumps(dict(packages=packages,sourceRevision='5ea22bbd (frozen package source faa48f57)',observations=observations,normalCoreAndAdapterUnchanged=True),indent=2)+'\n',encoding='utf-8',newline='\n')
