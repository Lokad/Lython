from pathlib import Path
import hashlib
import json
import tarfile

base = Path(__file__).resolve().parent
first = base / "quiet"
lab = base / "confirmation"
q = lab / "quiet"
q.mkdir(parents=True)


def read(path):
    return path.read_text(encoding="utf-8")


def load(path):
    return json.loads(read(path))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def emit(path, text):
    if path.suffix == ".py":
        compile(text, str(path), "exec")
    path.write_text(text, encoding="utf-8", newline="\n")


prior = load(first / "config.json")
receipt = load(first / "archive-receipt.json")
assert receipt["complete"] and receipt["allWorkersJoined"] and receipt["guestFixturesRemoved"]
assert receipt["archivedAndVerifiedUnderLease"] and receipt["archiveSHA256"] == sha(first / "observations.tgz")
summary = load(base / "quiet-summary.json")
focus = ("scripts.annotated-rule-closures.observed.postponed", "scripts.csv-invoice.large")
jobs = [(row["case"], row["lane"]) for row in summary["rows"] if row["case"] in focus]
assert jobs == [(name, "warm") for name in focus]
assert all(next(row for row in summary["rows"] if row["case"] == case)["cpuChangePercent"][-1] > 3 for case in focus)
location = "/home/lokad/lython-bench-checks/compiled-annotation-payload-confirm-b1239-20261120"
unit = "lython-b1239-compiled-annotation-payload-confirm-20261120"
emit(q / "identity.json", read(first / "identity.json"))
for name in ("collect.py", "run.sh", "archive-owned.py", "retrieve.py"):
    text = read(first / name).replace(prior["root"], location).replace(prior["unit"], unit)
    if name == "collect.py":
        a = text.index("\njobs = ")
        b = text.index("\nassert len(jobs)", a)
        text = text[:a] + "\njobs = " + repr(jobs) + text[b:]
        text = text.replace("len(jobs)==4", "len(jobs)==2")
        text = text.replace("if job_index % 2 == 0: labels.reverse()", "labels.reverse()")
        text = text.replace("accumulate 15 seconds", "accumulate 22 seconds").replace("warmupSeconds=15", "warmupSeconds=22")
        text = text.replace("min(warmed)<15", "min(warmed)<22").replace("warmed[i]>=15", "warmed[i]>=22")
        text = text.replace("targetBatchSeconds=.8", "targetBatchSeconds=1.0").replace("counts[i]*.8/", "counts[i]/")
    if name in ("archive-owned.py", "retrieve.py"):
        text = text.replace("==4", "==2").replace("jobs=4,", "jobs=2,")
    emit(q / name, text)
assert b"\r" not in (q / "run.sh").read_bytes()
assert "len(raw['jobs'])==2" in read(q / "archive-owned.py")
assert "status['receipt']['jobs']==2" in read(q / "retrieve.py")
parts = ("identity.json", "collect.py", "archive-owned.py", "run.sh")
payload = q / "payload.tgz"
with tarfile.open(payload, "w:gz") as bundle:
    for name in parts:
        bundle.add(q / name, arcname=name)
config = dict(prior, root=location, unit=unit, source=prior["root"], sourceRole="reference",
              sourceFiles=prior["identity"]["imageFiles"]["reference"], sourceCatalogSHA256=prior["catalogSHA256"],
              retireGroups=[], donorArchiveSHA256=receipt["archiveSHA256"],
              payloadBytes=payload.stat().st_size, payloadSHA256=sha(payload),
              unpackedBytes=sum((q / name).stat().st_size for name in parts))
emit(q / "config.json", json.dumps(config, indent=2) + "\n")
text = read(first / "remote-launch.py")
a = text.index("\nc=") + 1
b = text.index("\nb=Path(", a)
text = text[:a] + "c=" + repr(config) + text[b:]
text = text.replace("os.link(source/c['sourceRole']/n,p)", "os.link(source/role/n,p)")
text = text.replace("lython-b1238-fixtures", "lython-b1239-fixtures")
emit(q / "remote-launch.py", text)
emit(lab / "launch.py", read(base / "launch.py").replace("seconds=370", "seconds=260").replace("before 370", "before 260"))
emit(lab / "summarize.py", read(base / "summarize.py").replace("len(raw['jobs'])==4", "len(raw['jobs'])==2"))
print("Prepared the two adverse controls using both exact images.")
