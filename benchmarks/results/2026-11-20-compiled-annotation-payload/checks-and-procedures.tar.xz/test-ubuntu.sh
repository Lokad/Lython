set -eu
root=$PWD
lab=$root/.git/agent-notes/review-20261031/private-compiled-annotation-payload
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
cd "$root/.git/agent-worktrees/private-compiled-annotation-payload"
log="$lab/tests-ubuntu.log"
dotnet test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 -p:RestoreLockedMode=true --filter 'Category!=Stress&(FullyQualifiedName~Annotation|FullyQualifiedName~FunctionDefinitionIsolation|FullyQualifiedName~FunctionAttributeDeletion|FullyQualifiedName~PreparedFunctionDefaults|FullyQualifiedName~GeneratorDefinitionComposition|FullyQualifiedName~ModernTyping|FullyQualifiedName~GovernedMemoryContract)' >"$log" 2>&1 || { tail -n 50 "$log"; exit 1; }
tail -n 7 "$log"
