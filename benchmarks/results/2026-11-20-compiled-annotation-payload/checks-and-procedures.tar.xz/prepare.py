from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
previous = lab.parent / "private-format-map-keys"
template = previous / "refinement/quiet"
q = lab / "quiet"
core = "Lokad.Lython.dll"


def emit(path, text):
    if path.suffix == ".py":
        compile(text, str(path), "exec")
    path.write_text(text, encoding="utf-8", newline="\n")


def read(path):
    return path.read_text(encoding="utf-8")


def load(path):
    return json.loads(read(path))


def sha(value):
    return hashlib.sha256(value).hexdigest()


def file_sha(p):
    return sha(p.read_bytes())


def save(path, value):
    emit(path, json.dumps(value, indent=2) + "\n")


def git(*args):
    return subprocess.check_output(["git", *args], cwd=repo)


def retirement(remote, part):
    local = "benchmarks/results/2026-11-20-prepared-format-map-keys/" + part
    archive = git("cat-file", "blob", "78ad4127d:" + local + "observations.tgz")
    receipt = json.loads(git("cat-file", "blob", "78ad4127d:" + local + "archive-receipt.json"))
    canonical = local + "measured-candidate-core.dll.gz"
    binary = gzip.decompress(git("cat-file", "blob", "78ad4127d:" + canonical))
    assert receipt["complete"] and receipt["allWorkersJoined"] and receipt["guestFixturesRemoved"]
    assert receipt["archivedAndVerifiedUnderLease"] and receipt["archiveSHA256"] == sha(archive)
    return dict(archivePath=f"{remote}/observations.tgz", canonicalArchiveSHA256=sha(archive),
                paths=[f"{remote}/candidate/{core}"], bytes=len(binary), links=1, sha256=sha(binary),
                verifiedCanonicalGitImage=canonical)


index = load(lab / "identity.json")
assert index["reference"].startswith("78ad4127d") and index["candidate"].startswith("b26b50822")
old = load(template / "config.json")
old_receipt = load(template / "archive-receipt.json")
assert old_receipt["complete"] and old_receipt["archivedAndVerifiedUnderLease"]
assert old_receipt["archiveSHA256"] == file_sha(template / "observations.tgz")
reference_donor = old["identity"]["imageFiles"]["reference"]
protocol_sha = old["protocolSHA256"]
assert index["pythonWorkerSHA256"] == protocol_sha
manifest = lab / "representative.json"
manifest_hash = file_sha(manifest)
assert manifest_hash == index["catalogSHA256"]
for role, files in index["imageFiles"].items():
    assert len(files) == len(reference_donor) == 32
    assert {name: file_sha(lab / "frozen" / role / name) for name in files} == files
    verified = load(lab / f"{role}-verify.json")
    assert verified["state"] == "Completed" and verified["catalogSha256"] == manifest_hash
    assert set(files) == set(reference_donor)
    assert [n for n in files if files[n] != reference_donor[n]] == [core]
jobs = [(row["id"], "warm") for row in load(manifest)["cases"]]
assert len(jobs) == 4

root = "/home/lokad/lython-bench-checks/compiled-annotation-payload-b1238-20261120"
unit = "lython-b1238-compiled-annotation-payload-20261120"
q.mkdir()
images = index["imageFiles"]
identity = dict(sourceRevision=index["reference"] + " versus " + index["candidate"],
                purpose="Share immutable postponed annotation values and build the pre-admitted record on observation",
                catalogSHA256=manifest_hash, imageFiles=images, normalAdapterPin="0.4.0",
                coreSHA256={role + suffix: files[core] for role, files in images.items() for suffix in ("", "-control")})
save(q / "identity.json", identity)
for name in ("collect.py", "archive-owned.py", "run.sh", "retrieve.py"):
    text = read(template / name).replace(old["root"], root).replace(old["unit"], unit)
    if name == "collect.py":
        start = text.index("\njobs = ")
        end = text.index("\nassert len(jobs)", start)
        text = text[:start] + "\njobs = " + repr(jobs) + text[end:]
        text = text.replace("len(jobs)==2", "len(jobs)==4").replace("if job_index == 0:", "if job_index % 2 == 0:")
    if name in ("archive-owned.py", "retrieve.py"):
        text = text.replace("==2", "==4").replace("jobs=2,", "jobs=4,")
    emit(q / name, text)
assert b"\r" not in (q / "run.sh").read_bytes()
for role in ("reference", "candidate"):
    (q / role).mkdir()
    shutil.copyfile(lab / "frozen" / role / core, q / role / core)
shutil.copyfile(manifest, q / "representative.json")
parts = ("identity.json", "representative.json", "collect.py", "archive-owned.py", "run.sh",
         "reference/" + core, "candidate/" + core)
with tarfile.open(q / "payload.tgz", "w:gz") as archive:
    for part in parts:
        archive.add(q / part, arcname=part)
retirements = [retirement("format-map-keys-b1236-20261120", ""),
               retirement("format-map-keys-b1237-20261120", "refinement/")]
config = dict(root=root, unit=unit, source=old["root"], sourceRole="reference", sourceFiles=reference_donor,
              sourceCatalogSHA256=old["catalogSHA256"], protocolSHA256=protocol_sha, catalogSHA256=manifest_hash,
              identity=identity, retireGroups=retirements, donorArchiveSHA256=old_receipt["archiveSHA256"],
              payloadBytes=(q / "payload.tgz").stat().st_size, payloadSHA256=file_sha(q / "payload.tgz"),
              unpackedBytes=sum((q / name).stat().st_size for name in parts))
save(q / "config.json", config)
content = read(template / "remote-launch.py")
start = content.index("\nc=") + 1
end = content.index("\nb=Path(", start)
content = (content[:start] + "c=" + repr(config) + content[end:]).replace("lython-b1237-fixtures", "lython-b1238-fixtures")
assert "+64*1024*1024" in content
emit(q / "remote-launch.py", content)
emit(lab / "launch.py", read(previous / "refinement/launch.py").replace("seconds=188", "seconds=370")
     .replace("Format mapping comparison", "Annotation payload comparison").replace("188 seconds", "370 seconds"))
emit(lab / "summarize.py", read(previous / "refinement/summarize.py").replace("len(raw['jobs'])==2", "len(raw['jobs'])==4"))
print("Prepared four lanes for the already verified exact-image pair.")
