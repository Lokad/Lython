set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cpu=$(python3 -c 'import os; print(max(os.sched_getaffinity(0)))')
printf '%s\n' "$cpu" > "$root/affinity.txt"
exec taskset --cpu-list "$cpu" /bin/sh "$root/run.sh"
