from pathlib import Path

lab=Path(__file__).resolve().parent
prior=lab.with_name('declaration-scan-start-20261127')
source=(prior/'prepare.py').read_text(encoding='utf-8')
changes={
    "import json\n": "import base64\nimport copy\nimport json\n",
    "image_base=lab.with_name('staged-list-yield-20261127')/'local'": "image_base=lab.with_name('declaration-scan-start-20261127')/'local'",
    "assert head.startswith('92164d2db')\nassert not subprocess.check_output(['git','diff','489fde50e',head,'--','src'],cwd=repo)":
        "assert head=='e030b8ba508e56cd43390f916b4c97825a7e89d0'",
    "lython-declaration-scan-fixture-": "lython-json-escaped-name-fixture-",
    "[[ordinary,'compile'],[manifest_case,'compile-run'],[rules,'warm'],[manifest_case,'compile'],[ordinary,'compile-run']]":
        "[[escaped_doc,'warm'],[lines,'warm-async'],[escaped_lines,'warm-async'],[document,'warm'],[escaped_doc,'warm-async']]",
    "Start declaration preparation at the first emitted declaration descriptor.":
        "Reuse canonical short escaped JSON property names in complete document and Lines scripts.",
}
for before,after in changes.items():
    assert source.count(before)==1,before
    source=source.replace(before,after)
start=source.index("ordinary=")
end=source.index("for name in",start)
source=source[:start]+"""document='diagnostic.json-service-quantity-totals'
lines='scripts.json-summary-helpers.large'
escaped_doc='diagnostic.json-service-escaped-fields'
escaped_lines='diagnostic.json-lines-escaped-fields'
catalog=read(lab.with_name('json-single-string-pass-20261126')/'local/representative.json')
catalog['cases']=[row for row in catalog['cases'] if row['id'] in {document,lines}]
assert len(catalog['cases'])==2
counts=[]
def translated_case(original,id,names):
    case=copy.deepcopy(original)
    case['id']=id
    fixture=json.loads(case['fixtureJson'])
    file,encoded=next(iter(fixture['inputFiles'].items()))
    text=base64.b64decode(encoded).decode('utf-8')
    info=dict(case=id,fields={})
    for en,localized in names.items():
        original_key=json.dumps(en)
        localized_key=json.dumps(localized,ensure_ascii=True)
        count=text.count(original_key+':')
        assert count>0 and len(localized.encode())<=8
        info['fields'][localized]=count
        text=text.replace(original_key+':',localized_key+':')
        match=f"['{en}']"
        assert match in case['source']
        case['source']=case['source'].replace(match,f"['{localized}']")
    payload=text.encode('utf-8')
    fixture['inputFiles'][file]=base64.b64encode(payload).decode('ascii')
    case['fixtureJson']=json.dumps(fixture,separators=(',',':'),ensure_ascii=True)
    case['fixtureSha256']=sha256(case['fixtureJson'].encode()).hexdigest()
    case['sourceSha256']=sha256(case['source'].encode()).hexdigest()
    case['sourceUtf8Bytes']=len(case['source'].encode())
    info['inputBytes']=len(payload)
    counts.append(info)
    return case
by_id={case['id']:case for case in catalog['cases']}
catalog['cases'] += [
    translated_case(by_id[document],escaped_doc,{'service':'café','quantity':'株数'}),
    translated_case(by_id[lines],escaped_lines,{'kind':'café','amount':'株数'}),
]
write(run/'field-census.json',counts)
write(run/'representative.json',catalog)
"""+source[end:]
(lab/'prepare.py').write_text(source,encoding='utf-8',newline='\n')