using System.Collections;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Numerics;
using System.Reflection;
using System.Text.Json;
using System.Text.Json.Serialization;
using Lokad.Lython;

using var catalog = JsonDocument.Parse(File.ReadAllText(args[0]));
var limits = args.Length == 3 ? JsonSerializer.Deserialize<Dictionary<string, long[]>>(File.ReadAllText(args[2]))! : null;
var sources = catalog.RootElement.GetProperty("cases").EnumerateArray().ToDictionary(
    item => item.GetProperty("id").GetString()!, item => item.GetProperty("source").GetString()!);
sources.Add("capture-after-literal", """
    def create(seed):
        mark = 17
        def read():
            return seed
        return mark, read
    result, read = create(23)
    print(result, read())
    """);
sources.Add("capture-snapshot-overlap", """
    def create():
        first, second = 17, 23
        def read():
            return first + second
        return read
    print(create()())
    """);
sources.Add("signed-constant-boundaries", """
    def boundary(value):
        if value:
            return value + 9223372036854775807
        return value + 9223372036854775808
    def negatives(value):
        return value - 9223372036854775809
    print(boundary(1), boundary(0), negatives(1))
    """);

sources.Add("declaration-in-default", """
    def launch(seed):
        def adjusted(value=(lambda: seed + 1)(), *, extra=3):
            return value + extra + seed
        return adjusted()
    print(launch(5))
    """);
sources.Add("declaration-kinds", """
    def records(data):
        type Scalar = int
        class Label:
            def __init__(self, value):
                self.value = value
        make = lambda number: Label(number)
        yield from (make(number) for number in data)
    print([item.value for item in records([3, 5])])
    """);
var fillers = string.Join("\n", Enumerable.Range(0, 20).Select(i => $"    reserve_{i} = {i}"));
foreach (var (tag, continuation) in new (string, string)[]
{
    ("deferral-through-layout", "    return locals(), live()"),
    ("return-forwarded-local", "    result = lambda a=shift(seed), *, b=shift(seed): a + b\n    return result"),
    ("rebound-definition", "    saved = 5\n    return saved, live()"),
    ("explicit-read-before-forwarding", "    chosen = saved\n    return chosen(), live()"),
    ("scope-not-eligible", "    del saved\n    return live()"),
})
{
    sources.Add(tag, "def shift(n): return n + 1\ndef factory(seed):\n" + fillers +
        "\n    saved = lambda a=shift(seed), *, b=shift(seed): a + b\n" +
        "    def live(a=shift(seed), *, b=shift(seed)): return a + b\n" + continuation);
}
sources.Add("deferred-before-returned-pair", "def factory(seed):\n" + fillers +
    "\n    def unused(a=seed + 1, *, b=seed + 2): return a + b\n" +
    "    def first(a=seed + 4, *, b=3): return a + b\n" +
    "    def second(a=seed + 5, *, b=6): return a + b\n" +
    "    return first, second\n");
sources.Add("namespace-protected-temporaries", """
    class Manager:
        def __enter__(self): return 7
        def __exit__(self, *args): return False
    def factory(manager, first):
        with manager as value:
            result = 0 < first < value
            def read():
                return value, result
            return read, locals()
    print(factory(Manager(), 2)[0]())
    """);
sources.Add("nested-protected-match-and-comprehension", """
    def records(values):
        for number in values:
            match number:
                case int() if 0 < number < 4:
                    yield number
    print(list(records([0, 1, 3, 4])))
    """);
var results = sources.Select(pair =>
{
    var budget = new TracingBudget(null);
    var engine = new LythonEngine();
    WithBudget(engine, pair.Value, budget, script =>
    {
        if (!script.IsValid) throw new InvalidOperationException(string.Join("\n", script.Diagnostics));
        return 0;
    });
    var stablePeak = budget.Peak;
    var growth = budget.Granted.Where(item => item.New > item.Old).ToArray();
    var testLimits = limits is not null && limits.TryGetValue(pair.Key, out var overridden) ? overridden
        : growth.Select(item => item.Total - 1).TakeLast(8).Append(stablePeak - 1).Append(stablePeak).Where(n => n >= 0).Distinct().ToArray();
    var full = new TracingBudget(null);
    var tape = WithBudget(engine, pair.Value, full, script =>
    {
        var code = Read(script, "_executable")!;
        var output = new List<object>();
        ReadCode(Read(code, "EntryPoint")!, output);
        return output;
    });
    var refusals = testLimits.Select(limit =>
    {
        var limited = new TracingBudget(limit);
        return WithBudget(engine, pair.Value, limited, script => new
        {
            limit, script.IsValid, limited.Refused,
            diagnostics = script.Diagnostics.Select(item => new { item.Code, item.Span }).ToArray()
        });
    }).ToArray();
    for (var i = 0; i < 8; i++)
        using (var warm = engine.Compile(pair.Value))
            if (!warm.IsValid) throw new InvalidOperationException("Compilation warmup failed.");
    var allocated = new long[17];
    for (var i = 0; i < allocated.Length; i++)
    {
        var before = GC.GetAllocatedBytesForCurrentThread();
        using (var script = engine.Compile(pair.Value))
            if (!script.IsValid) throw new InvalidOperationException("Compilation diagnostic changed during measurement.");
        allocated[i] = GC.GetAllocatedBytesForCurrentThread() - before;
    }
    return new { id = pair.Key, peak = stablePeak, growth, testLimits, tape, refusals, allocated };
}).ToArray();
var options = new JsonSerializerOptions { WriteIndented = true, IncludeFields = true };
options.Converters.Add(new JsonStringEnumConverter());
File.WriteAllText(args[1], JsonSerializer.Serialize(results, options));
using (var cancellation = new CancellationTokenSource())
{
    const string source = "return 17";
    var engine = new LythonEngine();
    var successful = new TracingBudget(null);
    WithBudget(engine, source, successful, script => script.IsValid ? 0 : throw new InvalidOperationException("Expected a compiled integer."));
    var table = successful.Granted.Last(item => item.New > item.Old);
    if (table.New - table.Old != 48) throw new InvalidOperationException("Expected the one-slot table's admission to be last.");
    var interrupted = new TracingBudget(null)
    {
        Cancel = cancellation,
        CancelAt = table.Total,
    };
    var atReturn = WithBudget(engine, source, interrupted, script =>
    {
        if (script.IsValid || script.Diagnostics.Single().Code != "LA2011")
            throw new InvalidOperationException("Compilation did not report cancellation at the granted table.");
        return interrupted.Root.ReservedBytes;
    });
    if (!cancellation.IsCancellationRequested || atReturn != table.Total - 48)
        throw new InvalidOperationException("The cancelled table's temporary admission was retained.");
    File.WriteAllText(Path.Combine(Path.GetDirectoryName(args[1])!, "cancellation.json"),
        JsonSerializer.Serialize(new { granted = table.Total, afterCancellation = atReturn, afterDispose = interrupted.Root.ReservedBytes }));
}


var diagnosticSources = new Dictionary<string, string>
{
    ["branch-order"] = "def route(flag):\n if flag:\n  value=1\n else:\n  return value\n return value\n",
    ["deleted-binding"] = "def clean(value):\n del value\n return value\n",
    ["handler-exit"] = "def recover():\n try:\n  print('body')\n except ValueError as caught:\n  print(caught)\n return caught\n",
    ["lambda-nested-default"] = "def outer():\n def f(default=lambda: before + (before := 2)): pass\n return f\n",
    ["postponed-annotation"] = "from __future__ import annotations\ndef f(arg: (lambda: before + (before := 2))): pass\n",
    ["comprehension-exit"] = "def collect(values):\n print([late for late in values])\n return late\n late = 4\n",
    ["nested-nonlocal"] = "def owner():\n def bind():\n  nonlocal value\n  value = 2\n bind()\n return value\n value = 3\n",
    ["class-nonlocal"] = "def owner():\n class Bind:\n  nonlocal seed\n  seed = 42\n return seed\n seed = 0\n",
    ["summary-if-no-else"] = "def choose(flag):\n if flag:\n  return 'text'\nchoose(True).find(1)\n",
    ["summary-if-else-no-return"] = "def choose(flag):\n if flag:\n  return 'text'\n else:\n  pass\nchoose(True).find(1)\n",
    ["summary-if-else-both-return"] = "def choose(flag):\n if flag:\n  return 'text'\n else:\n  return 'other'\nchoose(True).find(1)\n",
    ["summary-with-nested-branches"] = "def load(flag):\n with open('/input.txt') as stream:\n  if flag:\n   return stream.read()\n  else:\n   return 'other'\nload(True).find(1)\n",
    ["summary-unsupported-child"] = "def choose(flag):\n if flag:\n  return 'text'\n else:\n  while flag:\n   pass\n  return 'other'\nchoose(True).find(1)\n",
    ["summary-variadic"] = "def choose(*args):\n return 'text'\nchoose(True).find(1)\n",
    ["summary-decorated"] = "def decorate(function):\n return function\n@decorate\ndef choose(flag):\n return 'text'\nchoose(True).find(1)\n",
    ["assignment-duplicate-star"] = "first, (*second, *third) = values\n",
    ["assignment-read-after-store"] = "def update(value, mapping):\n first, mapping[first] = value\n return first\n",
    ["assignment-read-before-store"] = "def update(value, mapping):\n mapping[first], first = value\n return first\n",
    ["assignment-nested-starred-read"] = "def update(value, mapping):\n first, *(second, mapping[second]) = value\n return first+second\n",
    ["assignment-global-after-target"] = "def update(value, mapping):\n (first, (second, mapping[first])) = value\n global first\n",
    ["assignment-member-read-before-local"] = "def update(value):\n entry.result, entry = value\n return entry\n",
    ["large-scope"] = "def many():\n" + string.Concat(Enumerable.Range(0, 144).Select(n => $" local_{n} = {n}\n")) +
        " del local_140\n return local_140\n",
};
var diagnosticsEngine = new LythonEngine();
var diagnostics = diagnosticSources.Select(pair =>
{
    var account = new TracingBudget(null);
    return WithBudget(diagnosticsEngine, pair.Value, account, script => new
    {
        id = pair.Key, script.IsValid, account.Peak, account.Refused,
        diagnostics = script.Diagnostics.Select(item => new { item.Code, item.Span, item.Message, item.Severity }).ToArray(),
    });
}).ToArray();
File.WriteAllText(Path.Combine(Path.GetDirectoryName(args[1])!, "diagnostics.json"), JsonSerializer.Serialize(diagnostics));

static T WithBudget<T>(LythonEngine engine, string source, TracingBudget budget, Func<LythonCompiledScript, T> observe)
{
    T result;
    using (var script = engine.Compile(source, budget, budget.Cancel?.Token ?? default))
        result = observe(script);
    if (budget.Root.ReservedBytes != 0) throw new InvalidOperationException("Compilation scope did not restore allowance.");
    return result;
}

static object? Read(object value, string name)
{
    const BindingFlags Flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
    var type = value.GetType();
    return type.GetProperty(name, Flags)?.GetValue(value) ?? type.GetField(name, Flags)?.GetValue(value);
}

static void ReadCode(object code, List<object> output)
{
    var constants = (object?[])Read(code, "Constants")!;
    var machine = (long?[]?)Read(code, "_machineConstants");
    var instructions = (IEnumerable)Read(code, "Instructions")!;
    var expected = constants.Select(value => value is BigInteger integer &&
        integer >= long.MinValue && integer <= long.MaxValue ? (long?)integer : null).ToArray();
    if (expected.Any(item => item.HasValue) ? machine is null || !machine.SequenceEqual(expected) : machine is not null)
        throw new InvalidOperationException("Machine integer table differs from the original literals.");
    output.Add(new
    {
        name = Read(code, "Name"), machine,
        native = Read(code, "CanRunNativeInstructions"),
        entry = Read(code, "EntryIndex"),
        nativePrefixEnd = Read(code, "NativePrefixEnd"),
        capacity = Read(code, "ValueStorageCapacity"),
        deferred = Read(code, "DeferredDefinitionSites"),
        directReturn = Read(code, "HasDirectOperandReturn"),
        directDefinitionReturn = Read(code, "DirectDefinitionReturn") is { } direct ? Read(Read(direct, "CodeObject")!, "Name") : null,
        directCased = Read(code, "DirectCasedReturnIndex"),
        firstPairCreation = Read(code, "FirstPairedDefaultCreationIndex"),
        captures = Read(code, "CaptureSources") is { } capture ? Read(capture, "Slots") : null,
        byValue = Read(code, "CaptureSources") is { } owner ? Read(owner, "CanCaptureByValue") : null,
        locals = Read(code, "LocalNames"), closureNames = Read(code, "ClosureNames"),
        bindingSlots = Read(code, "LocalNameToSlot"),
        sharesPreparedMap = ReferenceEquals(Read(code, "LocalNameToSlot"),
            Read(Read(code, "ScopeFacts")!, "PreparedLocalSlots")),
        capturedLocals = Read(code, "CapturedLocalSlots"),
        mirrors = Read(code, "RequiresLocalVariableMirroring"), lexical = Read(code, "UsesOnlyLexicalSlots"),
        constants = constants.Select(value => value is BigInteger integer
            ? integer.ToString(CultureInfo.InvariantCulture) : value?.GetType().Name).ToArray(),
        callSites = ((IEnumerable)Read(code, "CallSites")!).Cast<object>().Select(ReadCallSite).ToArray(),
        steps = instructions.Cast<object>().Select(instruction => new
        {
            op = Read(instruction, "OpCode"), span = Read(instruction, "Span"),
            primary = Read(instruction, "_primaryOperand"), secondary = Read(instruction, "_secondaryOperand"),
            input = Read(instruction, "_inputStart"), result = Read(instruction, "_resultSlot"), extent = Read(instruction, "_liveExtent"),
        }).ToArray(),
    });
    foreach (var constant in constants)
    {
        if (constant is null) continue;
        var child = constant.GetType().Name switch
        {
            "ExecutableCreateFunction" or "ExecutableCreateGeneratorExpression" => Read(constant, "CodeObject"),
            "ExecutableCreateClass" => Read(constant, "Body"),
            _ => null,
        };
        if (child is not null) ReadCode(child, output);
    }
}

static object ReadCallSite(object site)
{
    var count = (int)Read(site, "ArgumentCount")!;
    var stored = (Array?)(Read(site, "ArgumentForms") ?? Read(site, "Arguments"));
    var accessor = site.GetType().GetMethod("ArgumentFormAt");
    return new
    {
        argumentCount = count,
        isPositionalOnly = Read(site, "IsPositionalOnly"),
        storageLength = stored?.Length ?? 0,
        hasReceiver = Read(site, "HasReceiver"),
        targetSpan = Read(site, "TargetSpan"),
        callSpan = Read(site, "CallSpan"),
        keywordIndices = Read(site, "KeywordIndices"),
        forms = Enumerable.Range(0, count).Select(index =>
        {
            var form = (accessor is null ? stored!.GetValue(index) : accessor.Invoke(site, [index]))!;
            var kind = Read(form, "Kind")!.ToString();
            return new { kind, keyword = kind == "Keyword" ? Read(form, "KeywordName") : null };
        }).ToArray()
    };
}

internal sealed class TracingBudget(long? limit) : ILythonMemoryBudget
{
    public LythonMemoryBudget Root { get; } = limit is { } ceiling ? new(ceiling) : new();
    public long Peak { get; private set; }
    public CancellationTokenSource? Cancel { get; init; }
    public long CancelAt { get; init; }
    public List<(long Old, long New, long Total)> Granted { get; } = [];
    public (long Old, long New)? Refused { get; private set; }

    public ILythonMemoryScope CreateScope() => new Owner(this, Root.CreateScope());
    public bool TryReserve(long bytes, [NotNullWhen(true)] out ILythonMemoryReservation? reservation)
        => Reserve(Root, bytes, out reservation);

    private bool Reserve(ILythonMemoryBudget owner, long bytes, [NotNullWhen(true)] out ILythonMemoryReservation? reservation)
    {
        if (!owner.TryReserve(bytes, out var actual))
        {
            Refused ??= (0, bytes);
            reservation = null;
            return false;
        }
        Track(0, bytes);
        reservation = new Reservation(this, actual);
        return true;
    }

    private void Track(long old, long next)
    {
        Peak = Math.Max(Peak, Root.ReservedBytes);
        if (old != next) Granted.Add((old, next, Root.ReservedBytes));
        if (next > old && Root.ReservedBytes == CancelAt) Cancel?.Cancel();
        if (Refused is not null && next > old) throw new InvalidOperationException("Admission retried after refusal.");
    }

    private sealed class Owner(TracingBudget root, ILythonMemoryScope owner) : ILythonMemoryScope
    {
        public ILythonMemoryScope CreateScope() => new Owner(root, owner.CreateScope());
        public bool TryReserve(long bytes, [NotNullWhen(true)] out ILythonMemoryReservation? reservation)
            => root.Reserve(owner, bytes, out reservation);
        public void Dispose() => owner.Dispose();
    }

    private sealed class Reservation(TracingBudget root, ILythonMemoryReservation reservation) : ILythonMemoryReservation
    {
        public long Bytes => reservation.Bytes;
        public bool TryResize(long bytes)
        {
            var previous = Bytes;
            if (!reservation.TryResize(bytes))
            {
                root.Refused ??= (previous, bytes);
                return false;
            }
            root.Track(previous, bytes);
            return true;
        }
        public void Dispose() => reservation.Dispose();
    }
}