from hashlib import sha256
from pathlib import Path
from shutil import copyfile, copytree
import json
import subprocess

notes = Path(".git/agent-notes/review-20261031").resolve()
lab = notes / "assignment-target-consolidation-20261127"
lab.mkdir(exist_ok=True)
prior = notes / "lexical-return-summaries-20261127"
original = json.loads((prior / "comparison/identity.json").read_bytes())
digest = lambda p: sha256(p.read_bytes()).hexdigest()
sha = lambda data: sha256(data).hexdigest()
git = lambda *args: subprocess.check_output(["git", *args])
def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")

base = git("rev-parse","HEAD").decode().strip()
assert not git("diff", original["sourceRevision"], base, "--", "src")
patch = git("diff", "--binary", base, "--", "src")
assert patch.count(b"diff --git ") == 12 and b"-internal abstract record UnpackingTargetSyntax" in patch
(lab / "candidate.patch").write_bytes(patch)
pair = lab / "comparison"
pair.mkdir(exist_ok=True)
for role in ("reference", "candidate"):
    copytree(prior / "comparison/reference", pair / role, dirs_exist_ok=True)
    assert {p.name: digest(p) for p in (pair / role).iterdir()} == original["imageFiles"]["reference"]

core = "Lokad.Lython.dll"
fresh = Path("src/Lokad.Lython/bin/Release/net11.0") / core
tested = Path("tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0") / core
assert digest(fresh) == digest(tested) != digest(pair / "reference" / core)
copyfile(fresh, pair / "candidate" / core)
images = {role: {p.name: digest(p) for p in (pair / role).iterdir()} for role in ("reference","candidate")}
assert [name for name, before in images["reference"].items() if images["candidate"][name] != before] == [core]
for name in ("cpython-worker.py", "run.sh"):
    copyfile(prior / "comparison" / name, pair / name)
assert digest(pair / "cpython-worker.py") == original["cpythonWorkerSHA256"]
assert b"\r" not in (pair / "run.sh").read_bytes()

old_catalog = prior / "comparison/representative.json"
assert digest(old_catalog) == original["catalogs"][old_catalog.name]["sha256"]
catalog = json.loads(old_catalog.read_bytes())
ordinary, escaping, guarded, nested, plain = catalog["cases"]
fixture = notes / "assignment-target-source-proof-20261127"
script = (fixture / "transform.py").read_text(encoding="utf-8")
assert digest(fixture / "transform.py") == "611a300a9810e2952e9a0653a00b61d54c6a88402cb742a9ea513dfc66ff5164"
expected = (fixture / "expected.txt").read_text(encoding="utf-8")
for mode in ("sync", "async"):
    assert json.loads((fixture / f"restored-{mode}.json").read_bytes()) == json.loads((fixture / f"consolidated-{mode}.json").read_bytes())
fixture_json = '{"size":2,"text":null}'
transform = dict(ordinary, id="diagnostic.nested-assignment-record-transform", size=2, source=script,
                 fixtureJson=fixture_json, expectedOutput=expected, sourceUtf8Bytes=len(script.encode()),
                 expectedOutputUtf8Bytes=len(expected.encode()), sourceSha256=sha(script.encode()),
                 fixtureSha256=sha(fixture_json.encode()), expectedOutputSha256=sha(expected.encode()))
catalog["cases"].append(transform)
write(pair / "representative.json", catalog)
write(pair / "jobs.json", {"warm": [[transform["id"], "compile"], [ordinary["id"], "compile"],
                                    [transform["id"], "compile-run"], [nested["id"], "warm"]]})
write(pair / "identity.json", dict(sourceRevision=base, sourcePatchSHA256=digest(lab / "candidate.patch"),
    productionReference=base, imageFiles=images, coreSHA256={role+tail: files[core] for role,files in images.items() for tail in ("","-control")},
    cpythonWorkerSHA256=original["cpythonWorkerSHA256"], cpythonPath=original["cpythonPath"],
    expectedCPythonSHA256=original["expectedCPythonSHA256"],
    purpose="Use the original assignment targets throughout parsing, analysis and lowering.",
    catalogs={name: {"sha256":digest(pair/name)} for name in ("representative.json", "jobs.json")}))
collector = (prior / "comparison/collect.py").read_text(encoding="utf-8").replace("lython-lexical-return-summaries-", "lython-assignment-targets-").replace("len(jobs) == 5","len(jobs) == 4")
(pair / "collect.py").write_text(collector, encoding="utf-8", newline="\n")
probe = lab / "probe"
probe.mkdir()
copyfile(prior / "probe/CompilerFacts.csproj",probe / "CompilerFacts.csproj")
source = (prior / "probe/Program.cs").read_text(encoding="utf-8")
source = source.replace('["large-scope"]', r'''["assignment-duplicate-star"] = "first, (*second, *third) = values\n",
    ["assignment-read-after-store"] = "def update(value, mapping):\n first, mapping[first] = value\n return first\n",
    ["assignment-read-before-store"] = "def update(value, mapping):\n mapping[first], first = value\n return first\n",
    ["assignment-nested-starred-read"] = "def update(value, mapping):\n first, *(second, mapping[second]) = value\n return first+second\n",
    ["assignment-global-after-target"] = "def update(value, mapping):\n (first, (second, mapping[first])) = value\n global first\n",
    ["assignment-member-read-before-local"] = "def update(value):\n entry.result, entry = value\n return entry\n",
    ["large-scope"]''')
(probe / "Program.cs").write_text(source,encoding="utf-8",newline="\n")
reader = (prior / "check-compiler.py").read_text(encoding="utf-8").replace("len(diagnostics) == 16", "len(diagnostics) == 22").replace(
    "    assert sha256(core.read_bytes()).hexdigest()", "    assert {p.name: sha256(p.read_bytes()).hexdigest() for p in (run / role).iterdir()} == identity['imageFiles'][role]\n    assert sha256(core.read_bytes()).hexdigest()")
(lab / "check-compiler.py").write_text(reader,encoding="utf-8",newline="\n")
print(base, digest(lab / "candidate.patch"))

