from hashlib import sha256
from pathlib import Path
from statistics import median
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
run = lab / 'comparison'
project = lab/'probe'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')

sdk = Path.home() / '.dotnet11'
dotnet = sdk / 'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
subprocess.run([dotnet, 'build', project/'CompilerFacts.csproj', '-c', 'Release', '-f', 'net11.0'],
               cwd=project,env=env,check=True,timeout=60)
built = project / 'bin/Release/net11.0'
identity = read(run / 'identity.json')
output = {}
for role in ('reference', 'candidate'):
    destination = run / f'probe-{role}'
    destination.mkdir(exist_ok=True)
    for file in built.iterdir():
        if file.is_file():
            shutil.copyfile(file, destination/file.name)
    core = destination / 'Lokad.Lython.dll'
    shutil.copyfile(run / role / core.name, core)
    assert {p.name: sha256(p.read_bytes()).hexdigest() for p in (run / role).iterdir()} == identity['imageFiles'][role]
    assert sha256(core.read_bytes()).hexdigest() == identity['imageFiles'][role][core.name]
    result = destination / 'observed.json'
    command = [dotnet, destination / 'CompilerFacts.dll', run / 'representative.json', result]
    if role == 'candidate':
        command.append(run / 'reference-limits.json')
    subprocess.run(command, cwd=destination, env=env, check=True, timeout=50)
    output[role] = read(result)
    if role == 'reference':
        write(run / 'reference-limits.json', {row['id']: row['testLimits'] for row in output[role]})

reference_cancel = read(run / 'probe-reference/cancellation.json')
assert reference_cancel == read(run / 'probe-candidate/cancellation.json')
assert reference_cancel['afterDispose'] == 0
summary = []
for left, right in zip(output['reference'], output['candidate'], strict=True):
    for key in ('id','peak','growth','testLimits','refusals'):
        assert left[key] == right[key], (left['id'], key)
    assert left['tape']==right['tape'], left['id']
    summary.append(dict(id=left['id'], scopes=len(left['tape']), budgetLevels=len(left['testLimits']),
                        compileClr=[median(left['allocated']),median(right['allocated'])],compiledPeak=left['peak']))
diagnostics = read(run / 'probe-reference/diagnostics.json')
assert diagnostics == read(run / 'probe-candidate/diagnostics.json') and len(diagnostics) == 22
results = {row["id"]: row["IsValid"] for row in diagnostics}
assert results["summary-if-else-no-return"] and results["summary-unsupported-child"]
assert not results["summary-if-else-both-return"] and not results["summary-with-nested-branches"]
write(run / 'compiler-parity.json', dict(cases=summary, cancellation=reference_cancel, diagnostics=diagnostics))
for row in summary[:7]:
    print(row, flush=True)
print(f"{len(summary)} compile cases, {sum(row['budgetLevels'] for row in summary)} budget levels.", flush=True)
