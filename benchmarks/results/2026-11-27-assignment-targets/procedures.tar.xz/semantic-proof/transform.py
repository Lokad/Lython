class Row:
    def __init__(self, value):
        self.value = value

    def __enter__(self):
        return self.value

    def __exit__(self, error_type, error, traceback):
        return False


def key(events, name):
    events.append(name)
    return name


def summarize(rows):
    totals = {}
    copy = {}
    events = []
    for record in rows:
        name, (*adjustments, units), totals[key(events, name)] = record
        snapshot = (upper, copy[key(events, upper)]) = (name.upper(), units)
        with Row((upper, sum(adjustments))) as (label, totals[key(events, label)]):
            totals[label] += snapshot[1]
    return sorted(totals.items()), sorted(copy.items()), events


rows = [('west', (2, 3, 7), 11), ('east', (5, 13), 17)]
print(summarize(rows))
