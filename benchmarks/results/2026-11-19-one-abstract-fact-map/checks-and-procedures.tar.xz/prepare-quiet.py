import ast
import json
from pathlib import Path

lab = Path(__file__).resolve().parent
prior = lab.parent / 'prepared-integer-prefix-r671'
read = lambda p: p.read_text(encoding='utf-8-sig')
load = lambda p: json.loads(read(p))
stage = read(prior / 'stage-quiet.py')
stage = stage.replace('R671 compiler-prepared machine integer continuations', 'R672 single branch-state map for abstract facts')
stage = stage.replace('prepared-integer-prefix-b1103', 'one-abstract-fact-map-b1104')
stage = stage.replace('b1103-prepared-integer-prefix', 'b1104-one-abstract-fact-map').replace('b1103-fixtures','b1104-fixtures')
stage = stage.replace('six-case, seven-job', 'five-case, six-job')
stage = stage.replace('==7', '==6').replace('jobs=7,', 'jobs=6,').replace('398', '347')
stage = stage.replace('len(jobs)==6","len(jobs)==6', 'len(jobs)==6","len(jobs)==6')
stage = stage.replace("}) == 6", "}) == 4")
stage = stage.replace('Compiler-prepared integer prefix source pair', 'Single abstract-fact map source pair')
# Final collector gates use the original six-job template.
jobs = [
    ('scripts.config-generated-guards.medium', 'compile'),
    ('scripts.config-manifest.small', 'compile'),
    ('scripts.annotated-rule-closures', 'compile'),
    ('scripts.config-generated-guards.medium', 'compile-run'),
    ('scripts.config-manifest.small', 'compile-run'),
    ('scripts.report-render.format-selectors.large', 'warm'),
]
a, b = stage.index('        jobs = '), stage.index('        source=source[:a]')
stage = stage[:a] + "        jobs = " + repr(jobs) + "\n" + stage[b:]
assert {case for case,lane in jobs} <= {row['id'] for row in load(lab / 'catalog.json')['cases']}
ast.parse(stage)
(lab / 'stage-quiet.py').write_text(stage, encoding='utf-8', newline='\n')
receipt = load(prior / 'quiet/archive-receipt.json')
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
(lab / 'quiet-space.json').write_text(json.dumps(dict(freeBytes=receipt['freeBytesAfterArchive'], replicas=[])) + '\n', encoding='utf-8', newline='\n')

