from pathlib import Path
import statistics

lab = Path(__file__).resolve().parent
read = lambda p: p.read_text(encoding='utf-8-sig')
old = read(lab.parent / 'keyword-copy-path-r662/archive-r662.py')
prefix = old[:old.index('initial = verify(')]
prefix = prefix.replace('2026-11-19-keyword-copy-path', '2026-11-19-one-abstract-fact-map')
a = prefix.index('    independently_retained = ')
b = prefix.index('\ncases = ')
prefix = prefix[:a] + '    assert not changed(candidate, retained, "src", "tests")\n' + prefix[b:]
exec(compile(prefix, __file__, 'exec'))

summary = verify('quiet', 6, 'quiet-summary.json')
summary['referenceDeliveredSource'] = '80cbf49886ab815be884b5ce989c5aad7c264b69'
assert not subprocess.check_output(['git', 'diff', '--name-only', base, summary['referenceDeliveredSource'], '--', 'src', 'tests'])
summary['warmAllocation'] = []
before, after = (load(lab / f'{role}-allocation.json')['rows'] for role in ('reference', 'candidate'))
for left, right in zip(before, after, strict=True):
    assert left['id'] == right['id'] and left['sharedBudgetBaselineRestored'] and right['sharedBudgetBaselineRestored']
    a, b = (statistics.median(row['allocatedBytesPerInvocation']) for row in (left, right))
    summary['warmAllocation'].append(dict(case=left['id'], allocatedBytes=[a,b], allocatedChangePercent=100*(b/a-1),
        accountedPeak=[left['peakExecutionMemoryBytes'],right['peakExecutionMemoryBytes']]))
summary['compilerAllocation'] = []
before, after = (load(lab / f'{role}-compile-allocation.json')['rows'] for role in ('reference', 'candidate'))
for left, right in zip(before, after, strict=True):
    assert left['id'] == right['id'] and left['characters'] == right['characters']
    a, b = (statistics.median(row['bytes']) for row in (left, right))
    summary['compilerAllocation'].append(dict(case=left['id'], allocatedBytes=[a,b], allocatedChangePercent=100*(b/a-1)))
out.mkdir(exist_ok=False)
save(out / 'summary.json', summary)
quiet = lab / 'quiet'
for name in ('observations.tgz', 'archive-receipt.json', 'terminal-status.json'):
    shutil.copyfile(quiet / name, out / name)
core = lab / 'frozen/candidate/Lokad.Lython.dll'
assert digest(core) == images['candidate'][core.name]
(out / 'measured-core.dll.gz').write_bytes(gzip.compress(core.read_bytes(), mtime=0))
with tarfile.open(out / 'checks-and-procedures.tar.xz', 'w:xz', preset=6) as evidence:
    for name in ('config.json', 'identity.json', 'representative.json', 'remote-launch.py', 'retrieve.py',
                 'observe-not-before.json', 'launch.log', 'collect.py', 'archive-owned.py', 'run.sh'):
        evidence.add(quiet / name, arcname='quiet/' + name)
    for name in ('prepare.py', 'stage-quiet.py', 'launch-quiet.py', 'summarize-quiet.py', 'quiet-space.json', 'preflight.json',
                 'archive.py', 'freeze-and-verify.py', 'frozen-identity.json', 'catalog.json', 'reference-verify.json',
                 'candidate-verify.json', 'reference-allocation.json', 'candidate-allocation.json', 'measured-source.patch',
                 'reference-compile-allocation.json', 'candidate-compile-allocation.json', 'measure-compile-allocation.py',
                 'frozen-win-net11-build.log', 'prepare-quiet.py', 'local-targets.json', 'local-pair.log',
                 'win-whitebox.log', 'win-public.log',
                 'retrieval.log'):
        evidence.add(lab / name, arcname=name)
print('Verified 120 batches, original catalog, both worker images and the archive under lease.')
