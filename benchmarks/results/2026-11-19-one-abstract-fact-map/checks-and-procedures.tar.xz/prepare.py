from pathlib import Path
import ast
import json

lab = Path(__file__).resolve().parent
old = lab.parent / 'prepared-integer-prefix-r671'
earlier = lab.parent / 'child-declaration-preparation-r668'
baseline = lab.parent / 'retained-defaults-cpython-b1102'
read = lambda p: p.read_text(encoding='utf-8-sig')
load = lambda p: json.loads(read(p))
source = load(baseline / 'representative.json')
wanted = {'scripts.rule-default-closures', 'scripts.annotated-rule-closures', 'scripts.config-generated-guards.medium'}
source['cases'] = [case for case in source['cases'] if case['id'] in wanted]
manifest = 'scripts.config-manifest.small'
source['cases'].append(next(case for case in load(earlier / 'catalog.json')['cases'] if case['id'] == manifest))
shipment = 'scripts.report-render.format-selectors.large'
for old_case in (lab.parent / 'combined-operand-preparation-r638').glob('catalog.json'):
    historical = load(old_case)
    print('Historical cases', [case['id'] for case in historical['cases']])
    source['cases'].append(next(case for case in historical['cases'] if case['id'] == shipment))
    break
assert any(case['id'] == shipment for case in source['cases']), shipment
def write(name, data):
    if name.endswith('.py'):
        ast.parse(data)
    (lab / name).write_text(data, encoding='utf-8', newline='\n')

write('catalog.json', json.dumps(source, indent=2, ensure_ascii=False) + '\n')
freeze = read(old / 'freeze-and-verify.py').replace('integer-chain-prefix-r665','one-abstract-fact-map-r672')
freeze = freeze.replace('== 6','== 5').replace('all six','all five')
write('freeze-and-verify.py', freeze)

