using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    private static void ExecuteCasedSplit(ExecutableCasedSplit recipe, PyString receiver, ExecutionContext context,
        out ExecutableResult result, bool consumedByIteration = false)
    {
        context.CheckExecution(recipe.CasingMemberSpan);
        context.CheckExecution(recipe.CasingCallSpan);
        context.CheckExecution(recipe.SplitMemberSpan);
        context.CheckExecution(recipe.SplitCallSpan);
        if (consumedByIteration)
        {
            PyStringOps.PrepareCasedWhitespaceIteration(receiver, recipe.Upper, context, recipe.SplitCallSpan);
            result = new(receiver) { IterationContext = context, CasedSplit = recipe };
        }
        else result = new(PyStringOps.SplitCasedWhitespace(receiver, recipe.Upper,
            context.MemoryGovernor, recipe.SplitCallSpan, context));
    }

    internal sealed partial class ExecutionContext
    {
        private static bool TryExecuteCasedSplit(ref ExecutableWorkState execution, ExecutionContext context,
            ExecutionContext? invocation, ExecutableCallSite call, int start, object target)
        {
            if (call.CasedSplit is not { } recipe || !ReferenceEquals(target, recipe.CasingMethod)
                || execution.Stack[start] is not PyString receiver) return false;
            // Only the fused result inherits the split call's consumer. If the
            // exact native chain is declined, lower() has its own ordinary use
            // as the receiver of the following member access.
            var resultCall = execution.Code.CallSites[
                execution.Code.Instructions[execution.InstructionIndex + 2].CallSiteIndex];
            // The immediate chain stays within this basic block. Original
            // operand layout gives both calls the same result position; publish
            // through the final call, including its local-store continuation.
            try
            {
                ExecutableResult result;
                context.EnterInterpreterFrame(recipe.CasingCallSpan);
                try { ExecuteCasedSplit(recipe, receiver, context, out result, CallResultConsumedByIteration(in execution, resultCall)); }
                catch (Exception error) when (TryTranslateCallableException(error, recipe.SplitCallSpan, out var translated)) { throw translated; }
                finally { context.LeaveInterpreterFrame(); }
                execution.InstructionIndex += 2;
                PublishInstructionResult(ref execution, invocation, execution.Code.Instructions[execution.InstructionIndex], result);
                return true;
            }
            catch { execution.Stack.RetireTo(start); throw; }
        }
    }
}
