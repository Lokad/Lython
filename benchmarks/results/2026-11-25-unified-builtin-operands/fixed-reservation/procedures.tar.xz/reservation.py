from pathlib import Path
root=Path(".git/agent-worktrees/unified-builtin-reservation-20261125/src/Lokad.Lython/Runtime")
def replace(name,old,new):
    p=root/name
    s=p.read_text(encoding="utf-8")
    assert s.count(old)==1,(name,old)
    p.write_text(s.replace(old,new),encoding="utf-8",newline="\n")
replace("LythonRuntime.Calls.cs","ExecutionContext context, MemoryGovernor.TemporaryMemoryReservation? storage = null)",
        "ExecutionContext context, long reservedBytes = 0)")
replace("LythonRuntime.Calls.cs","finally { storage?.Dispose(); }",
        "finally { if (reservedBytes != 0) context.MemoryGovernor.ReleaseReserved(reservedBytes); }")
replace("LythonRuntime.Executable.Binding.cs",
'''    // Small copied packets use minor control headroom. Wider copies are admitted
    // through completion, independently of the original evaluated operands.
    internal static MemoryGovernor.TemporaryMemoryReservation? ReserveCallArgumentStorage(
        int count, ExecutionContext context, LythonSourceSpan span)
        => count <= 3 ? null : context.MemoryGovernor.ReserveTemporary(
            checked(32L + 32L * count), span);''',
'''    // Fund wide packets and final bound values through their last user.
    // Small arrays use the existing minor control headroom.
    private static long CallArgumentStorageBytes(int count)
        => count <= 3 ? 0 : checked(32L + 32L * count);

    internal static MemoryGovernor.TemporaryMemoryReservation? ReserveCallArgumentStorage(
        int count, ExecutionContext context, LythonSourceSpan span)
    {
        var bytes = CallArgumentStorageBytes(count);
        return bytes == 0 ? null : context.MemoryGovernor.ReserveTemporary(bytes, span);
    }''')
replace("LythonRuntime.Executable.Calls.Invoke.cs",
        "            var storage = ReserveCallArgumentStorage(bound.GetOperandBindingCapacity(call), this, span);",
'''            var reservedBytes = CallArgumentStorageBytes(bound.GetOperandBindingCapacity(call));
            if (reservedBytes != 0) MemoryGovernor.Reserve(reservedBytes, span);''')
replace("LythonRuntime.Executable.Calls.Invoke.cs","""                var completion = AwaitBorrowedCall(pending, span, this, storage);
                entered = false;
                storage = null;""","""                var completion = AwaitBorrowedCall(pending, span, this, reservedBytes);
                entered = false;
                reservedBytes = 0;""")
replace("LythonRuntime.Executable.Calls.Invoke.cs","finally { storage?.Dispose(); }",
        "finally { if (reservedBytes != 0) MemoryGovernor.ReleaseReserved(reservedBytes); }")
