from pathlib import Path
import hashlib, json, shutil, tarfile
lab = Path(__file__).resolve().parent
repo=lab.parents[3]
prior = lab.with_name("native-dictionary-prepared-consumers-20261125")
quiet = lab / "comparison/quiet"
donor = prior / "comparison/quiet"
confirmation = donor
read = lambda p: json.loads(p.read_text(encoding="utf-8"))
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def write(path, text):
    path.write_text(text, encoding="utf-8", newline="\n")
def save(path, data):
    write(path, json.dumps(data, indent=2) + "\n")

jobs = {'warm': [['scripts.json-lines-shipment.default-options.large', 'warm'], ['diagnostic.measurement-tolerance.short-options', 'warm'], ['scripts.json-lines-shipment.explicit-options.large', 'warm'], ['scripts.json-lines-shipment.explicit-options.large', 'warm-async'], ['scripts.json-lines-shipment.explicit-wide-options.large', 'warm'], ['diagnostic.generated-ordinary-definitions', 'warm']]}
save(quiet / "jobs.json", jobs)
identity = read(quiet / "identity.json")
assert all(identity["imageFiles"]["reference"][name] == digest(prior/"reference"/name) for name in identity["imageFiles"]["reference"] if name != "Lokad.Lython.dll")
for role, files in identity["imageFiles"].items():
    assert {p.name: digest(p) for p in (lab / role).iterdir()} == files
    verification = read(lab / "comparison" / (role + "-verify.json"))
    assert verification["caseCount"] == 6 and verification["state"] == "Completed"
identity["catalogs"]["jobs.json"] = {"sha256": digest(quiet / "jobs.json")}
save(quiet / "identity.json", identity)
collector = (donor / "collect.py").read_text(encoding="utf-8").replace("b1712b-fixtures","b1714b-fixtures")
compile(collector,"collect.py","exec")
write(quiet/"collect.py",collector)
shutil.copyfile(donor/"run.sh",quiet/"run.sh")
assert b"\r" not in (quiet/"run.sh").read_bytes()
launcher=(prior/"quiet.py").read_text(encoding="utf-8").replace("b1712b","b1714").replace(
    "lython-b1714-native-dictionary-prepared-consumers","lython-b1714b-unified-builtin-reservation").replace(
    "RuntimeMaxSec=333","RuntimeMaxSec=350")
anchor=read(confirmation/"terminal-status.json")["receipt"]
assert anchor["complete"] and digest(confirmation/"observations.tar.xz")==anchor["archiveSHA256"]
a=launcher.index("assert donor['archiveSHA256']=='")
b=launcher.index("\n",a)
launcher=launcher[:a]+"assert donor['archiveSHA256']=="+repr(anchor["archiveSHA256"])+launcher[b:]
compile(launcher, "quiet.py", "exec")
write(lab / "quiet.py", launcher)
retire=[]
for plan in read(lab / "archived-duplicates.json"):
    archive=repo/plan["path"]
    assert archive.is_file() and digest(archive)==plan["sha"] and archive.is_relative_to(repo/"benchmarks/results")
    with tarfile.open(archive) as data:
        member=data.getmember("confirmation/confirmation.json")
        assert member.isfile() and member.size==plan["rawBytes"]
        raw=data.extractfile(member).read()
        assert json.loads(raw)["complete"]
    retire.append(dict(location=plan["run"],archiveSHA256=plan["sha"],bytes=len(raw),rawSHA256=hashlib.sha256(raw).hexdigest()))
save(lab / "verified-raw-replicas.json", retire)
payload = quiet / "payload.tar.gz"
with tarfile.open(payload, "w:gz", compresslevel=3) as out:
    for name in ("identity.json", "jobs.json", "representative.json", "run.sh", "collect.py"):
        out.add(quiet / name, arcname=name)
    out.add(lab / "candidate/Lokad.Lython.dll", arcname="candidate-core.dll")
    out.add(lab / "reference/Lokad.Lython.dll", arcname="reference-core.dll")
save(quiet / "upload.json", dict(root="unified-builtin-reservation-b1714b-20261125",
    reference="native-dictionary-prepared-consumers-b1712b-20261125",
    payloadSHA256=digest(payload), payloadBytes=payload.stat().st_size))
