from pathlib import Path
import shutil
a=Path(".git/agent-notes/review-20261031/unified-builtin-operands-20261125")
b=Path(".git/agent-notes/review-20261031/unified-builtin-reservation-20261125")
for n in ("input-catalog.json","archived-duplicates.json","allocations.py","test-ubuntu.sh"):
    shutil.copyfile(a/n,b/n)
assert b"\r" not in (b/"test-ubuntu.sh").read_bytes()
for n in ("freeze.py","prepare.py","archive.py","package.py"):
    text=(a/n).read_text(encoding="utf-8-sig").replace("unified-builtin-operands-20261125","unified-builtin-reservation-20261125").replace(
        "2026-11-25-unified-builtin-operands","2026-11-25-unified-builtin-operands/fixed-reservation")
    if n=="freeze.py":
        text=text.replace("assert len(changes) == 3","assert len(changes) == 4").replace("Remove the intermediate packet for short builtin operand calls",
              "Keep fixed builtin binding reservations in the existing frame")
    elif n=="prepare.py":
        text=text.replace("b1714-fixtures","b1714b-fixtures").replace("unified-builtin-operands-b1714-20261125","unified-builtin-reservation-b1714b-20261125").replace(
            '"lython-b1714-unified-builtin-operands"','"lython-b1714b-unified-builtin-reservation"')
    elif n=="package.py":
        text=text.replace('"prepare-sources.py",','"reservation.py", "prepare-refinement.py",').replace('"short-math-cpython.stdout",','').replace(
            '"windows-first-whitebox.log",','').replace('"windows-old-binding-admission.log",','')
    compile(text,n,"exec")
    (b/n).write_text(text,encoding="utf-8",newline="\n")
