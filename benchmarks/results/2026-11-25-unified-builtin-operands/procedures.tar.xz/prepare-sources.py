from pathlib import Path
import hashlib
import json
import subprocess

lab=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
write=lambda p,s:p.write_text(s,encoding="utf-8",newline="\n")
def save(name,obj):write(lab/name,json.dumps(obj,ensure_ascii=False,indent=2)+"\n")
donor=lab.with_name("native-dictionary-prepared-consumers-20261125")
ext=lab.with_name("retained-workspace-cpython-20261125")
older=lab.with_name("direct-builtin-operands")/"refined/quiet"
archive=read(older/"representative.json")
cat=read(ext/"external/representative.json")
cases={case["id"]:case for case in archive["cases"]+cat["cases"]}
short="scripts.json-lines-shipment.explicit-options.large"
default="scripts.json-lines-shipment.default-options.large"
wide="scripts.json-lines-shipment.explicit-wide-options.large"
expanded="scripts.json-lines-shipment.expanded-options.large"
ordinary="diagnostic.generated-ordinary-definitions"
math=cases["scripts.measurement-tolerance.explicit-options"].copy()
assert math["source"].count(", rel_tol=0.0002")==1
source=math["source"].replace(", rel_tol=0.0002","")
digest=lambda data:hashlib.sha256(data).hexdigest()
output=subprocess.check_output(["C:/Python313/python.exe","-I","-X","utf8","-c",source],timeout=10)
(lab/"short-math-cpython.stdout").write_bytes(output)
golden=output.replace(b"\r\n",b"\n")
assert b"\r" not in golden
math.update(id="diagnostic.measurement-tolerance.short-options",source=source,sourceUtf8Bytes=len(source.encode("utf-8")),
    sourceSha256=digest(source.encode("utf-8")),expectedOutput=golden.decode("utf-8"),expectedOutputSha256=digest(golden))
cases[math["id"]]=math
cat["cases"]=[cases[key] for key in (short,default,wide,expanded,ordinary,math["id"])]
save("input-catalog.json",cat)
save("archived-duplicates.json",[])
jobs={'warm':[[default,"warm"],[math["id"],"warm"],[short,"warm"],[short,"warm-async"],[wide,"warm"],[ordinary,"warm"]]}
text=(donor/"freeze.py").read_text(encoding="utf-8").replace("native-dictionary-prepared-consumers-20261125","unified-builtin-operands-20261125")
text=text.replace('git("rev-parse", "6934aafb9")','git("rev-parse", "60ecf0d3b")').replace("assert len(changes) == 21","assert len(changes) == 3")
a=text.index('previous = lab.with_name("iteration-')
b=text.index("cores =",a)
text=text[:a]+'''prior = lab.with_name("native-dictionary-prepared-consumers-20261125")
prior_identity = json.loads((prior / "comparison/quiet/identity.json").read_text(encoding="utf-8"))
assert git("diff","--name-only",prior_identity["comparisonRevision"],base,"--","src",*build_inputs)==b""
old = prior_identity["imageFiles"]["reference"]
assert {p.name:sha(p) for p in (prior/"reference").iterdir()}==old
before=json.loads((prior/"comparison/quiet/terminal-status.json").read_text(encoding="utf-8"))["receipt"]
assert before["complete"] and sha(prior/"comparison/quiet/observations.tar.xz")==before["archiveSHA256"]
baseline=prior/"reference/Lokad.Lython.dll"
assert sha(baseline)!=sha(core)
'''+text[b:]
text=text.replace('prior / "candidate" / name','prior / "reference" / name')
text=text.replace("Use prepared tape entries for CSV byte consumers and a single decimal parse","Remove the intermediate packet for short builtin operand calls")
write(lab/"freeze.py",text)
text=(donor/"prepare.py").read_text(encoding="utf-8")
a=text.index("jobs =")
b=text.index("save(quiet",a)
text=text[:a]+"jobs = "+repr(jobs)+"\n"+text[b:]
text=text.replace('prior = lab.with_name("iteration-native-storage-prepared-20261125")','prior = lab.with_name("native-dictionary-prepared-consumers-20261125")')
text=text.replace('digest(prior/"candidate"/name)','digest(prior/"reference"/name)')
a=text.index('collector =')
b=text.index('anchor=read',a)
text=text[:a]+'''collector = (donor / "collect.py").read_text(encoding="utf-8").replace("b1712b-fixtures","b1714-fixtures")
compile(collector,"collect.py","exec")
write(quiet/"collect.py",collector)
shutil.copyfile(donor/"run.sh",quiet/"run.sh")
assert b"\\r" not in (quiet/"run.sh").read_bytes()
launcher=(prior/"quiet.py").read_text(encoding="utf-8").replace("b1712b","b1714").replace(
    "lython-b1714-native-dictionary-prepared-consumers","lython-b1714-unified-builtin-operands").replace(
    "RuntimeMaxSec=333","RuntimeMaxSec=350")
'''+text[b:]
text=text.replace('root="native-dictionary-prepared-consumers-b1712b-20261125"','root="unified-builtin-operands-b1714-20261125"').replace(
    'reference="iteration-native-storage-prepared-b1708b-20261125"','reference="native-dictionary-prepared-consumers-b1712b-20261125"')
write(lab/"prepare.py",text)
text=(donor/"archive.py").read_text(encoding="utf-8").replace("2026-11-25-native-dictionary-slots/prepared","2026-11-25-unified-builtin-operands")
write(lab/"archive.py",text)
text=(donor/"allocations.py").read_text(encoding="utf-8")
write(lab/"allocations.py",text)
for name in ("freeze.py","prepare.py","archive.py","allocations.py"):
    compile((lab/name).read_text(encoding="utf-8"),name,"exec")
