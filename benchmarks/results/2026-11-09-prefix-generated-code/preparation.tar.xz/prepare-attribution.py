from pathlib import Path
r=Path(__file__).parent
old=r.parent/'csv-cost-r86/attribute-jit.py'
s=old.read_text(encoding='utf-8')
s=s.replace("(f/'call-jit.txt')", "(r/'retrieved/profiles/prefix-jit.txt')")
s=s.replace("['ExecuteInstructionPrefix','TryExecuteNativeCall','TryLoadDirectCallReceiver','ExecuteInputInstruction']", "['ExecuteInstructionPrefix']")
s=s.replace(' groups=[]', " assert blocks and int(blocks[0][1],16)==0\n assert all(int(a[1],16)<=int(b[1],16) for a,b in zip(blocks,blocks[1:])), 'Nonmonotonic listing offsets stay unattributed'\n groups=[]")
compile(s,'attribute-jit.py','exec')
(r/'attribute-jit.py').write_text(s,encoding='utf-8')
