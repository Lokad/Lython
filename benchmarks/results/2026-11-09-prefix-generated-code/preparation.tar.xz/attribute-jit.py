from pathlib import Path
import bisect,collections,json,re
r=Path(__file__).resolve().parent;f=r/'retrieved/profiles/text-warm'
record=json.loads((f/'record.json').read_text(encoding='utf-8'));guest=set(record['guestTids'])
ranges=[]
for line in (f/'perf.map').read_text(encoding='utf-8').splitlines():
 start,size,name=line.split(' ',2);ranges.append((int(start,16),int(size,16),name))
text=(r/'retrieved/profiles/prefix-jit.txt').read_text(encoding='utf-8');sections=text.split('; Assembly listing for method ')[1:]
leaves=[]
for line in (f/'perf-leaves.txt').read_text(encoding='utf-8').splitlines():
 m=re.match(r'\s*(\d+)/(\d+)\s+([0-9a-fx]+)\s*(.*)',line)
 if m and m[2]in guest:leaves.append(int(m[3],16))
results={}
for method in ['ExecuteInstructionPrefix']:
 rows=[row for row in ranges if '::'+method+'('in row[2]and '[OptimizedTier1]'in row[2]]
 listings=[section for section in sections if ':'+method+'('in section.splitlines()[0]and '(Tier1)'in section.splitlines()[0]]
 matches=[]
 for row in rows:
  for section in listings:
   size=re.search(r'; Total bytes of code (\d+)',section)
   if size and int(size[1])==row[1]:matches.append((row,section))
 if len(matches)!=1:
  results[method]=dict(mappedTier1Ranges=len(rows),tier1Listings=len(listings),uniqueSizeMatches=len(matches),status='No unambiguous emitted-code identity; do not infer source hotspot.')
  continue
 row,section=matches[0]
 blocks=list(re.finditer(r'G_M\d+_IG\d+:\s*;; offset=0x([0-9A-Fa-f]+)',section))
 assert blocks and int(blocks[0][1],16)==0
 assert all(int(a[1],16)<=int(b[1],16) for a,b in zip(blocks,blocks[1:])), 'Nonmonotonic listing offsets stay unattributed'
 groups=[]
 for index,match in enumerate(blocks):
  offset=int(match[1],16);end=int(blocks[index+1][1],16)if index+1<len(blocks)else row[1]
  block=section[match.start():blocks[index+1].start()if index+1<len(blocks)else len(section)]
  samples=sum(row[0]+offset<=ip<row[0]+end for ip in leaves)
  if samples:groups.append(dict(offset=offset,end=end,samples=samples,assembly=block))
 assert sum(g['samples']for g in groups)==sum(row[0]<=ip<row[0]+row[1]for ip in leaves)
 results[method]=dict(status='Unique method/tier/size match',rangeStart=hex(row[0]),codeBytes=row[1],selfSamples=sum(g['samples']for g in groups),blocks=sorted(groups,key=lambda x:x['samples'],reverse=True))
(r/'generated-code-attribution.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
for method,d in results.items():
 print(method,{k:v for k,v in d.items()if k!='blocks'})
 for b in d.get('blocks',[])[:4]:
  print('offset',hex(b['offset']),'samples',b['samples']);print(b['assembly'][:2600])
