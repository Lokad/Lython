from pathlib import Path
r=Path(__file__).parent
s=(r.parent/'borrowed-call-entry-r151/recover-space.py').read_text(encoding='utf-8')
s=s.replace("[('callback-transport-b504-20261109','2026-11-09-callback-arguments'),('json-runtime-b505-20261109','2026-11-09-json-runtime-attribution')]", "[('borrowed-call-entry-b506-20261109','2026-11-09-borrowed-call-entry')]")
s=s.replace("assert not (base/'borrowed-call-entry-b506-20261109').exists()", "assert not (base/'prefix-attribution-b507-20261109').exists()")
s=s.replace('/dev/shm/lython-b505','/dev/shm/lython-b507')
s=s.replace('borrowed-call-entry-b506-space','prefix-attribution-b507-space')
s=s.replace('Two redundant remote archives', 'One redundant remote archive')
compile(s,'recover-space.py','exec')
(r/'recover-space.py').write_text(s,encoding='utf-8')
