from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-09-prefix-generated-code');out.mkdir(exist_ok=True)
status=json.loads((r/'terminal-status.json').read_text(encoding='utf-8'))
assert status['receipt']['allWorkersJoined'] and not status['remainingWorkers'] and not status['remainingTrace']
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==status['receipt']['archiveSHA256']
a=json.loads((r/'attribution.json').read_text(encoding='utf-8'))[0]
j=json.loads((r/'generated-code-attribution.json').read_text(encoding='utf-8'))['ExecuteInstructionPrefix']
assert j['status']=='Unique method/tier/size match' and sum(b['samples'] for b in j['blocks'])==j['selfSamples']
n=a['groups']['guest']['samples'];blocks={b['offset']:b for b in j['blocks']}
loop=sum(blocks[i]['samples'] for i in [0x10e,0x18b,0x19e]);fetch=blocks[0x136]['samples']
summary=dict(measuredProduction='99844959/core21cf1118, fully qualified42605184549; not HEAD78fd7bb4',
    captureSeconds=status['receipt']['capturedSeconds'],guestSamples=n,guestCpuSeconds=sum(t['seconds']for t in a['threadCpuSeconds']if t['name'].startswith('Lython executio')),
    prefixSelfSamples=j['selfSamples'],prefixSelfPercent=100*j['selfSamples']/n,uniqueTier1CodeBytes=j['codeBytes'],
    observedLoopBoundsAndSwitch=dict(samples=loop,percent=100*loop/n),mixedInstructionFetchAndRequiredChecks=dict(samples=fetch,percent=100*fetch/n),
    phaseShares=a['groups']['guest']['observedPhase'],unknownLeaves=a['groups']['guest']['unknownLeaf'],
    selectedNext='Shared managed bulk ASCII boundary discovery. CollectWhitespaceForward is62 guest leaves; retain Unicode paths, bounded cancellation chunks and existing capacity/ownership. No claimed speedup or automatic percent gate.',
    notSelected='Loop rotation would interact with direct-local publication, pending iterator disposal and protected-region layout. Do not add continuation/target machinery for an assumed saving. Not a permanent design ban.',
    correction='Initial phase classifier treated sibling prefix-jit.txt as a case directory. Original classifier and failure retained; filter directories offline on unchanged raw. No capture restarted.',
    limitations='Same-process method/tier/code-extent uniquely match; block samples include useful inlined operations and sampling skid. Not all dispatch or check work can be removed. Unknown/parent-assigned leaves remain. No elapsed/source-pair/CPython or HEAD performance claim.',
    space='Original read-only free260743168B below original252MiB before payload. Removed only exact single-alias remote B506 compressed duplicate after fresh lease/SHA/metadata/parents/persisted plan; local tracked archive and raw/receipt/workers survive. All floors unchanged.')
(r/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
for name in ['summary.json','attribution.json','generated-code-attribution.json','core-source.json','terminal-status.json','archive-receipt.json','observations.tgz','space-recovery.json']:
    assert not (out/name).exists();shutil.copyfile(r/name,out/name)
with tarfile.open(out/'preparation.tar.xz','w:xz')as archive:
    for p in r.iterdir():
        if p.is_file()and p.name not in ['observations.tgz','payload.tgz']:archive.add(p,arcname=p.name)
print(json.dumps({k:v for k,v in summary.items()if k not in ['phaseShares']},indent=2))
ci=r.parent/'valid-deflate-r155';run=json.loads((ci/'ci-terminal.json').read_text(encoding='utf-8'))
assert run['status']=='completed'and run['conclusion']=='success'and run['headSha'].startswith('78fd7bb4')
assert {j['name']for j in run['jobs']}=={'tests (windows-latest)','tests (ubuntu-latest)'}
for job in run['jobs']:
    steps={s['name']:s['conclusion']for s in job['steps']}
    assert job['conclusion']=='success'and all(steps[name]=='success'for name in ['Test Release (.NET 11)','Test Release (.NET 10 checkpoint)','Verify Release package consumer','Test original stress scales'])
shutil.copyfile(ci/'ci-terminal.json','benchmarks/results/2026-11-09-workspace-capacity/delivery-ci.json')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8-sig')
s=s.replace('Focused832 internal/3184 public per actual11/10; full delivery batch pending.', 'Fully qualified42615908221/source78fd7bb4: bothOS actual11/10, original Stress both and installed consumers.')
s=s.replace('Delivery42615908221 running.', 'Full delivery42615908221 cached success, bothOS actual11/10, original Stress both and installed consumers.')
start=s.index('0. **R155');end=s.index('2. **R156',start)
s=s[:start]+'''1. **R157: managed bulk ASCII whitespace boundary discovery.**
   R156 identifies62/1194 guest leaves in CollectWhitespaceForward; other text work
   and dispatch remain real costs. Replace the scalar ASCII category-run loop with
   standard managed SearchValues searches, forward/reverse, within existing chunks.
   The two fixed character inventories are immutable metadata, no guest cache/pool,
   per-operation backing or new option. Keep Python's29 whitespace scalars, Unicode
   casing/context, maxsplit/rsplit and owned final fragments exactly as today.
   Expected deletion: per-byte ASCII category tests in the shared run scanner;
   no custom SIMD/unsafe/native work, second execution route or quota.
   Acceptance: existing split/casing/cancellation/refusal/alias checks on actual11/10,
   trusted Python boundary cases where missing, one short whole text comparison
   plus CSV/JSON/search and compile controls. Freeze both sources nonincrementally.
   No CPU claim from allocation or desktop uncertainty; allow bounded confirmation
   only when materially useful. Complete by retaining/removing the prototype with
   explicit regression debt; broader performance objective remains open.

''' +s[end:]
s=s.replace('**R156: same-process prefix/JIT attribution, then select the coherent redesign.**','**R156 complete: same-process prefix/JIT attribution.**')
s=s.replace('B507 launched12:33:38UTC; terminal observation after12:36:38UTC.', 'B507 terminal success,6.104s/1194guest samples/6.01guestCPU seconds; no users/RAM remain.')
s=s.replace('with fresh single-alias/SHA/metadata/parents/persisted-plan proof; local tracked', 'after fresh single-alias/SHA/metadata/parents/persisted-plan proof; local tracked')
s=s.replace('   Source/script/core/aux/golden/current-source-delta identities and all original\n   failed conditions retained privately underprefix-attribution-r156.', '''   Unique same-process Tier1 extent14159B/246self samples. Observed loop bounds/
   switch75samples6.28%; mixed instruction fetch/required checks44samples3.69%.
   These are not savings. Prefix includes useful operations; no larger dispatch VM,
   loop-rotation continuation machinery or universal tagged values selected.
   New selected source phase is R157. Original failed classifier and headroom,
   source/script/core/aux/golden/current-source-delta identities retained in
   benchmarks/results/2026-11-09-prefix-generated-code. No repeated capture.''')
s=s.replace('B507 finite attribution lease launched; no elapsed comparison.', 'B507 terminal/cached/localSHA verified; no users/fixtures. No elapsed comparison.')
s=s.replace('R154/R155 delivery42615908221/source78fd7bb4 is active; no publication.', 'R154/R155 delivery42615908221/source78fd7bb4 cached success, all platform/Stress/package gates; never requery. No publication.')
a=s.index('evidence archived. R155 focused checks complete;');s=s[:a]+'''evidence archived. R155 handoff integrated/removed. Full delivery42615908221 terminal
success; never requery. R157 next; no local build/test/timing or VM user running.
'''
p.write_text(s,encoding='utf-8')
