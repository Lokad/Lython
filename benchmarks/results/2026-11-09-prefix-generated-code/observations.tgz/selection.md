R156/B507: resolve interpreter-prefix attribution, not repeat aggregate timing.
One maintained whole text helper script, unchanged fixture/full stdout/files goldens.
Reuse fully qualified R151 core21cf1118/production99844959 and the B506 frozen worker,
adapter/dependencies; do not relabel it as currentHEAD78fd7bb4. No source restore/build.
Dispatch/read bodies are unchanged; subsequent capacity/cleanup and ZIP changes remain
explicit in source-delta.patch. Six-second warmup, one six-second199Hz CPU-clock/fp
window, normal GC/tiering plus existing CLR perf maps and selected JIT disassembly.
Capture listing and sampled IPs in the SAME worker. Associate listings only when
method/tier/extent identify a unique compilation; ambiguity stays unknown. Never
transfer native offsets across processes/revisions or interpret all prefix work as
overhead. One usable capture plus bounded30min offline source attribution; select one
coherent displaced phase or record uncertainty and move the independent boundary.
No CPU speedup, refreshed CPython ratio, new runtime framework or new configuration.
Full Ready/core/auxiliary/quiet/golden/funding/Closed/join/maps/RAM/archive/localSHA gates.
Persistent workers/catalog/raw apart from RAM fixtures.120sowner+30stop+30margin,
original240MiB OS floor and12MiB trace/archive headroom. Fresh read-only preflight
found260743168B, below252MiB even before payload; preserve this original failed
condition. Recover only the exact redundant remote B506 compressed archive after
fresh idle lease, single-alias/hash/metadata/parents/pre-mutation proof. Its raw tree,
receipt, frozen workers and byte-identical Git-tracked local archive all survive.
No lower floor, payload substitution, retiming, unrelated storage sweep or sibling edit.
Cancellation, shared admission, aliases and awaited cleanup remain unchanged.
