from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).parent;assert not(r/'failed-collector-closed.json').exists()
code=r'''from pathlib import Path
import fcntl,hashlib,json,shutil,subprocess,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'representative-stage-b748-20261114';unit='lython-b748-representative-stage-20261114.service'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert(root/'exit-code.txt').read_text().strip()=='1'
 (root/'failed-service-journal.txt').write_text(subprocess.check_output(['journalctl','-u',unit,'--no-pager'],text=True))
 trace=root/'guest-fixtures';assert trace.is_mount()
 files={p.relative_to(trace).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in trace.rglob('*')if p.is_file()}
 with tarfile.open(root/'failed-observations.tgz','w:gz',dereference=True)as t:
  for p in root.iterdir():
   if p.is_file() and p.name!='failed-observations.tgz':t.add(p,arcname=p.name)
  t.add(trace,arcname='guest-fixtures')
 with tarfile.open(root/'failed-observations.tgz')as t:
  for name,sha in files.items():assert hashlib.sha256(t.extractfile('guest-fixtures/'+name).read()).hexdigest()==sha
 subprocess.run(['sudo','-n','umount',str(trace)],check=True);trace.rmdir()
 assert shutil.disk_usage(root).free>252*1024*1024
 d=dict(complete=False,failedBeforeSampling=True,error='KeyError: removed JIT option remained in diagnosticOverrides inventory',noRuntimeOrMeasurementInference=True,allWorkersJoined=True,ramEvidenceArchivedAndVerifiedBeforeUnmount=True,remainingFixtures=False,archiveSHA256=hashlib.sha256((root/'failed-observations.tgz').read_bytes()).hexdigest(),freeBytes=shutil.disk_usage(root).free)
 (root/'failed-collector-closed.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];done=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);assert done.returncode==0,done.stderr;d=json.loads(done.stdout);scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15'];done=subprocess.run(scp+['lokad@20.166.121.73:/home/lokad/lython-bench-checks/representative-stage-b748-20261114/failed-observations.tgz',str(r/'failed-observations.tgz')],capture_output=True,timeout=60);assert done.returncode==0,done.stderr;assert hashlib.sha256((r/'failed-observations.tgz').read_bytes()).hexdigest()==d['archiveSHA256'];(r/'failed-collector-closed.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n');print(d,flush=True)
