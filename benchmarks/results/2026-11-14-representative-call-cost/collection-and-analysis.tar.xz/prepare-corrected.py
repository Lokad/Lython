from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent;assert json.loads((r/'failed-collector-closed.json').read_text(encoding='utf-8'))['ramEvidenceArchivedAndVerifiedBeforeUnmount'];out=r/'b749';out.mkdir()
for name in ['identity.json','ops-profile.py','collect.py','retrieve.py','run.sh','prospective.json','launch.py']:
    code=(r/name).read_text(encoding='utf-8').replace('representative-stage-b748-20261114','representative-stage-b749-20261114').replace('lython-b748-representative-stage-20261114','lython-b749-representative-stage-20261114').replace('B748','B749')
    if name=='ops-profile.py':
        old='["DOTNET_PerfMapEnabled", "DOTNET_JitDisasm", "DOTNET_JitStdOutFile"]';assert old in code;code=code.replace(old,'["DOTNET_PerfMapEnabled"]');assert 'diagnosticOverrides' in code and 'env["DOTNET_JitDisasm"]' not in code
        code=code.replace('        process = subprocess.Popen',"        assert {k for k in env if k.startswith(('DOTNET_', 'COMPlus_'))} == {'DOTNET_ROOT', 'DOTNET_PerfMapEnabled'}\n        process = subprocess.Popen")
    elif name=='launch.py':code=code.replace("r.parent/'range-iteration-r362","r.parent.parent/'range-iteration-r362")
    if name.endswith('.py'):ast.parse(code)
    (out/name).write_text(code,encoding='utf-8',newline='\n')
identity=json.loads((out/'identity.json').read_text(encoding='utf-8'));identity['collectorCorrection']='B748 failed before sampling from removed JIT option still referenced by recorded inventory; original scripts/journal/fixtures archived, all users joined before RAM teardown. B749 fixes only inventory and adds pre-worker exact override preflight; runtime/workloads/capture/settings unchanged.';(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
    for n in ['identity.json','ops-profile.py','collect.py','run.sh','prospective.json']:t.add(out/n,arcname=n)
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
c=json.loads((r/'config.json').read_text(encoding='utf-8'));c.update(root=c['root'].replace('b748','b749'),unit=c['unit'].replace('b748','b749'),identity=identity,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
code=(r/'launch-command.py').read_text(encoding='utf-8');a=code.index('config=');b=code.index('\nbase=',a);code=code[:a]+'config='+repr(c)+code[b:];code=code.replace('lython-b748-fixtures','lython-b749-fixtures');ast.parse(code);(out/'launch-command.py').write_text(code,encoding='utf-8',newline='\n');(out/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Corrected inventory and pre-worker override preflight; all original conditions retained.',flush=True)
