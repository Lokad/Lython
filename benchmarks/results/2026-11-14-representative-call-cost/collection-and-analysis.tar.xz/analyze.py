from pathlib import Path
import ast,json,runpy
r=Path(__file__).parent/'b749';source=r.parent.parent/'frame-primitive-transport-r360/b738/analyze-primitive.py'
for name in ['invoice','search']:
    s=source.read_text(encoding='utf-8').replace('profiles/csv-while','profiles/'+name).replace('R360uncommitted/frozenb9ad2490 complete CSVwhile CPU attribution','Committedfa40d674/frozen73a1b233 representative '+name+' CPU attribution').replace('attribution-primitive.json','attribution-'+name+'.json');ast.parse(s);p=r/('analyze-'+name+'.py');p.write_text(s,encoding='utf-8',newline='\n');d=runpy.run_path(str(p));print(name,flush=True)
    for method,count in d['leaves'].most_common(24):print(count,method,flush=True)
    (r/('leaf-census-'+name+'.json')).write_text(json.dumps(dict(leaves=d['leaves'].most_common(),nearest=d['guest'].most_common(),sampleCount=d['leaves'].total(),interpretation='Owning CPU samples include useful/inlined work; not removable shares or a speed forecast.'),indent=2)+'\n',encoding='utf-8',newline='\n')
