from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
tree = repo / '.git/agent-worktrees/parallel-assignment-operands-20261123'
quiet = lab / 'comparison/quiet'
repeat = lab / 'repeat/comparison/quiet'
refinement = lab / 'refinement'
refined_quiet = refinement / 'comparison/quiet'
dest = repo / 'benchmarks/results/2026-11-23-parallel-assignment-operands'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda data: hashlib.sha256(data).hexdigest()
digest = lambda path: sha(path.read_bytes())
git = lambda *args: subprocess.check_output(['git', *args], cwd=repo)

identity = read(lab / 'comparison/identity.json')
status = read(quiet / 'terminal-status.json')
receipt = status['receipt']
assert not status['live'] and not status['fixtures'] and status['exitCode'] == '0'
assert all(receipt[key] for key in ('complete', 'archivedAndVerifiedUnderLease', 'allWorkersJoined',
    'guestFixturesRemoved', 'quietBeforeAndAfter'))
assert digest(quiet / 'observations.tar.xz') == receipt['archiveSHA256']
assert read(quiet / 'summary.json')['timedBatches'] == 140
confirmation = read(repeat / 'terminal-status.json')
assert not confirmation['live'] and not confirmation['fixtures'] and confirmation['exitCode'] == '0'
confirm_receipt = confirmation['receipt']
assert all(confirm_receipt[key] for key in ('complete', 'archivedAndVerifiedUnderLease', 'allWorkersJoined',
    'guestFixturesRemoved', 'quietBeforeAndAfter'))
assert digest(repeat / 'observations.tar.xz') == confirm_receipt['archiveSHA256']
assert read(repeat / 'summary.json')['timedBatches'] == 84
assert read(repeat / 'identity.json')['imageFiles'] == identity['imageFiles']
refined = read(refinement / 'comparison/identity.json')
assert refined['imageFiles']['reference'] == identity['imageFiles']['reference']
refined_status = read(refined_quiet / 'terminal-status.json')
assert not refined_status['live'] and not refined_status['fixtures'] and refined_status['exitCode'] == '0'
refined_receipt = refined_status['receipt']
assert all(refined_receipt[key] for key in ('complete', 'archivedAndVerifiedUnderLease', 'allWorkersJoined',
    'guestFixturesRemoved', 'quietBeforeAndAfter'))
assert digest(refined_quiet / 'observations.tar.xz') == refined_receipt['archiveSHA256']
assert read(refined_quiet / 'summary.json')['timedBatches'] == 84
for role in ('reference', 'candidate'):
    original = {row['id']: row['codes'] for row in read(lab / (role + '-tape.json'))['rows']}
    rerun = read(refinement / (role + '-tape.json'))['rows']
    assert len(rerun) == 3 and all(original[row['id']] == row['codes'] for row in rerun)
rows = read(lab / 'allocation-summary-six.json')
meter = next(row for row in rows if row['case'] == 'scripts.csv-meter-report.explicit-float')
assert len(rows) == 4 and all(row['peakAdmission'][0] == row['peakAdmission'][1] for row in rows if row != meter)
assert meter['peakAdmission'][0] - meter['peakAdmission'][1] == 4096 * 272
assert meter['allocatedBytes'][0] - meter['allocatedBytes'][1] > 4096 * 140
assert sum(read(lab / 'tape-summary.json')['unchangedControlCodeCount'].values()) == 7
changed = git('diff', '--name-only', identity['candidate'] + '^', identity['candidate'], '--', 'src').decode().splitlines()
assert len(changed) == 7
head = git('rev-parse', 'HEAD').decode().strip()
identity['retainedRevision'] = None if git('diff', '--name-only', head, identity['candidate'], '--', 'src') else head
refined['retainedRevision'] = None if git('diff', '--name-only', head, refined['candidate'], '--', 'src') else head
identity['testRevision'] = (lab / 'test-revision').read_text(encoding='utf-8-sig').strip()
assert not git('diff', '--name-only', identity['testRevision'], identity['candidate'], '--', 'src')
patch = git('diff', '--binary', identity['candidate'] + '^', identity['testRevision'], '--', 'src', 'tests')
(lab / 'comparison.patch').write_bytes(patch)
identity['comparisonPatchSHA256'] = sha(patch)
refined_patch = git('diff', '--binary', identity['candidate'], refined['candidate'], '--', 'src')
(refinement / 'comparison.patch').write_bytes(refined_patch)
refined['comparisonPatchSHA256'] = sha(refined_patch)
dest.mkdir(exist_ok=True)
assert all(path.name == 'README.md' for path in dest.iterdir())
for role, files in identity['imageFiles'].items():
    assert len(files) == 32 and all(digest(lab / role / name) == checksum for name, checksum in files.items())
    core = lab / role / 'Lokad.Lython.dll'
    stored = dest / 'candidate-core.dll.gz' if role == 'candidate' else dest.parent / '2026-11-23-direct-closed-defaults/candidate-core.dll.gz'
    if role == 'candidate':
        stored.write_bytes(gzip.compress(core.read_bytes(), mtime=0))
    assert sha(gzip.decompress(stored.read_bytes())) == files[core.name]
for role, files in refined['imageFiles'].items():
    assert len(files) == 32 and all(digest(refinement / role / name) == checksum for name, checksum in files.items())
refined_core = (refinement / 'candidate/Lokad.Lython.dll').read_bytes()
assert sha(refined_core) == refined['imageFiles']['candidate']['Lokad.Lython.dll']
(dest / 'refined-core.dll.gz').write_bytes(gzip.compress(refined_core, mtime=0))
(dest / 'refined-identity.json').write_text(json.dumps(refined, indent=2) + '\n', encoding='utf-8', newline='\n')
(dest / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8', newline='\n')
for name in ('observations.tar.xz', 'summary.json', 'terminal-status.json'):
    shutil.copyfile(quiet / name, dest / name)
    shutil.copyfile(repeat / name, dest / ('repeat-' + name))
    shutil.copyfile(refined_quiet / name, dest / ('refined-' + name))
for name in ('allocation-summary-six.json', 'tape-summary.json'):
    shutil.copyfile(lab / name, dest / name)
with tarfile.open(dest / 'procedures.tar.xz', 'w:xz') as archive:
    for name in ('archive.py', 'prepare.py', 'stage.py', 'quiet.py', 'comparison.patch', 'summarize.py', 'allocations.py',
        'allocations.log', 'windows-frozen.log', 'windows-target-order.log', 'ubuntu-public.log', 'ubuntu-white.log',
        'ubuntu-target-order.log', 'test-ubuntu.sh', 'test-order-ubuntu.sh',
        'reference-allocation-six.json', 'candidate-allocation-six.json', 'prepare-first.log', 'prepare.log', 'stage.log',
        'first-stage-floor.log', 'launch.log', 'retrieval.log', 'comparison/reference-verify.json',
        'comparison/candidate-verify.json', 'comparison/quiet/observe-not-before',
        'candidate-tape.json', 'reference-tape.json', 'dispatch-jit.py', 'dispatch-jit.log', 'dispatch-code-sizes.json',
        'reference-dispatch.asm', 'candidate-dispatch.asm', 'reference-dispatch-allocation.json',
        'candidate-dispatch-allocation.json', 'prepare-repeat.py', 'repeat-first-stage.log',
        'repeat-launch.log', 'repeat-retrieval.log', 'repeat/quiet.py', 'repeat/summarize.py',
        'repeat/comparison/quiet/observe-not-before'):
        archive.add(lab / name, arcname=name)
    for name in ('prepare-refined.py', 'stage.py', 'quiet.py', 'test-ubuntu.sh', 'comparison.patch',
        'summarize.py', 'dispatch-jit.py', 'dispatch-jit.log', 'dispatch-code-sizes.json',
        'reference-dispatch.asm', 'candidate-dispatch.asm', 'reference-dispatch-allocation.json',
        'candidate-dispatch-allocation.json', 'windows-frozen.log', 'windows-public.log', 'windows-white.log',
        'ubuntu-public.log', 'ubuntu-white.log', 'prepare.log', 'stage-first.log', 'stage.log',
        'allocations.py', 'allocations.log', 'allocation-summary-six.json',
        'reference-allocation-six.json', 'candidate-allocation-six.json', 'early-retrieval.log',
        'first-stage-floor.log', 'launch.log', 'retrieval.log', 'comparison/reference-verify.json',
        'comparison/candidate-verify.json', 'comparison/quiet/observe-not-before',
        'candidate-tape.json', 'reference-tape.json'):
        archive.add(refinement / name, arcname='refinement/' + name)
print(dest, identity['retainedRevision'] or refined['retainedRevision'] or 'private')

