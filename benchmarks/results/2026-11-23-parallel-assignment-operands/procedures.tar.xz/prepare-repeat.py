from pathlib import Path

lab = Path(__file__).resolve().parent
template = lab.parent / 'indexed-regex-projection-20261123/prepare-repeat.py'
source = template.read_text(encoding='utf-8')
start = source.index("runner = runner.replace('  if free < minimum:'")
end = source.rindex("\nrunner = runner.replace", start, source.index("\nold_image", start)) + 1
source = source[:start] + """runner = runner.replace('  # Five bounded lanes write under 1 MiB of receipts. A 98 MiB',
    '  # Three bounded lanes write under 1 MiB of receipts. A 98 MiB')
""" + source[end:]
for old, new in (
    ('b1514', 'b1517'),
    ('indexed-regex-projection', 'parallel-assignment'),
    ("receipt['exitCode'] == '1' and not receipt['fixtures'] and not receipt['receipt']['complete']",
     "receipt['exitCode'] == '0' and not receipt['fixtures'] and receipt['receipt']['complete']"),
    ('[jobs[1], jobs[2], jobs[4]]', '[jobs[2], jobs[3], jobs[0]]'),
    ('bounded confirmation after an idle gate failure', 'reverse workload order and confirm typed meter control'),
    ("reference='retained-call-cpython-b1510-20261123'", "reference='direct-closed-defaults-b1515-20261123'"),
    ("'seconds=236', 'seconds=180'", "'seconds=247', 'seconds=159'"),
    ("'RuntimeMaxSec=350', 'RuntimeMaxSec=235'", "'RuntimeMaxSec=315', 'RuntimeMaxSec=210'"),
):
    assert old in source, old
    source = source.replace(old, new)
exec(compile(source, str(template), 'exec'))

