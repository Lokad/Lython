set -e
export DOTNET_ROOT=/home/vermorel/.dotnet
export DOTNET_ROOT_X64=$DOTNET_ROOT
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/parallel-assignment-operands-20261123
"$DOTNET_ROOT/dotnet" test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter 'FullyQualifiedName~TupleDisplayAssignmentEvaluatesAllValuesBeforeAnyTarget' > "$lab/ubuntu-target-order.log" 2>&1 || { tail -30 "$lab/ubuntu-target-order.log"; exit 1; }
tail -7 "$lab/ubuntu-target-order.log"
