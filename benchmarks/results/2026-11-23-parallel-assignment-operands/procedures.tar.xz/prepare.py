from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
tree = repo / '.git/agent-worktrees/parallel-assignment-operands-20261123'
donor = lab.parent / 'direct-closed-defaults-20261123'
comparison = lab / 'comparison'
comparison.mkdir(exist_ok=True)
dotnet = Path.home() / '.dotnet11/dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
core = 'Lokad.Lython.dll'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda data: hashlib.sha256(data).hexdigest()
digest = lambda path: sha(path.read_bytes())
git = lambda *args: subprocess.check_output(['git', *args], cwd=repo)

def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')

def copy(source, destination):
    if not destination.exists():
        shutil.copyfile(source, destination)
    assert digest(source) == digest(destination)

def adapt(source, target, pairs):
    code = source.read_text(encoding='utf-8')
    for old, new in pairs:
        assert old in code, (source, old)
        code = code.replace(old, new)
    compile(code, str(target), 'exec')
    target.write_text(code, encoding='utf-8', newline='\n')

tracked = 'benchmarks/results/2026-11-23-direct-closed-defaults/'
pushed = lambda name: git('show', 'origin/master:' + tracked + name)
base = json.loads(pushed('identity.json'))
status = json.loads(pushed('terminal-status.json'))['receipt']
assert status['complete'] and status['allWorkersJoined'] and status['archivedAndVerifiedUnderLease']
assert sha(pushed('observations.tar.xz')) == status['archiveSHA256']
candidate = (lab / 'built-revision').read_text(encoding='utf-8-sig').strip()
assert not git('-C', tree, 'status', '--porcelain')
assert candidate == git('-C', tree, 'rev-parse', 'HEAD').decode().strip()
reference = base['retainedRevision']
assert not git('diff', '--name-only', reference, candidate + '^', '--', 'src')
assert not git('diff', '--name-only', reference, base['candidate'], '--', 'src')
catalog = read(lab.parent / 'csv-batched-markers-20261123/comparison/representative.json')
explicit = 'scripts.csv-meter-report.explicit-float'
typed = 'scripts.csv-meter-report.typed-ascii'
quoted = 'scripts.csv-invoice.method-policy.quoted-control'
supplied = 'scripts.ordinary-fully-supplied-helper'
cases = {explicit, typed, quoted}
catalog['cases'] = [row for row in catalog['cases'] if row['id'] in cases]
catalog['cases'] += [row for row in read(donor / 'comparison/representative.json')['cases'] if row['id'] == supplied]
assert {row['id'] for row in catalog['cases']} == cases | {supplied}
write(comparison / 'representative.json', catalog)
write(comparison / 'jobs.json', dict(warm=[[explicit, 'warm'], [explicit, 'compile-run'],
    [typed, 'warm'], [quoted, 'warm'], [supplied, 'warm']]))

protocol = repo / 'benchmarks/cpython-worker.py'
assert digest(protocol) == base['cpythonWorkerSHA256']
files = base['imageFiles']['candidate']
assert len(files) == 32
images = {}
inspector = lab.parent / 'adjacent-integer-results-20261123/reference'
tapes = {}
for role in ('reference', 'candidate'):
    image = lab / role
    image.mkdir(exist_ok=True)
    for name, checksum in files.items():
        source = donor / 'candidate' / name
        assert digest(source) == checksum
        if role == 'candidate' and name == core:
            source = lab / 'frozen/bin/Lokad.Lython/release_net11.0' / core
        copy(source, image / name)
    for name in ('ValidatedAllocation.dll', 'ValidatedAllocation.deps.json', 'ValidatedAllocation.runtimeconfig.json'):
        copy(donor / 'candidate' / name, image / name)
    for name in ('Inspect.dll', 'Inspect.deps.json', 'Inspect.runtimeconfig.json'):
        copy(inspector / name, image / name)
    images[role] = {name: digest(image / name) for name in files}
    verification = comparison / (role + '-verify.json')
    subprocess.run([dotnet, image / 'Lokad.Lython.Benchmarks.dll', '--compare', 'verify', '--catalog',
        comparison / 'representative.json', '--dotnet', dotnet, '--python', 'C:/Python313/python.exe',
        '--python-worker', protocol, '--out', verification], env=env, timeout=90, check=True)
    verified = read(verification)
    assert verified['state'] == 'Completed' and verified['caseCount'] == 4
    assert verified['launched']['library']['sha256'] == images[role][core]
    tape = lab / (role + '-tape.json')
    subprocess.run([dotnet, image / 'Inspect.dll', comparison / 'representative.json', tape],
        env=env, check=True, timeout=35)
    inspected = read(tape)
    assert inspected['coreSHA256'] == images[role][core]
    tapes[role] = {row['id']: row['codes'] for row in inspected['rows']}
    assert all(digest(image / name) == checksum for name, checksum in images[role].items())
assert [name for name in files if images['reference'][name] != images['candidate'][name]] == [core]
assert all(tapes['reference'][control] == tapes['candidate'][control] for control in (typed, quoted, supplied))
old = tapes['reference'][explicit][0]['tape']
new = tapes['candidate'][explicit][0]['tape']
assert len(old) == len(new) + 1
enum_source = (tree / 'src/Lokad.Lython/Frontend/ExecutableScript.cs').read_text(encoding='utf-8')
enum = re.search(r'enum ExecutableOpCode\s*\{([^{}]+)\}', enum_source).group(1)
names = re.findall(r'^\s*(\w+),\s*$', enum, flags=re.M)
assert [names[row['<OpCode>k__BackingField']] for row in old[42:47]] == ['MakeTuple', 'UnpackValues', 'StoreLocal', 'StoreLocal', 'StoreLocal']
assert [names[row['<OpCode>k__BackingField']] for row in new[42:46]] == ['ReverseAssignmentValues', 'StoreLocal', 'StoreLocal', 'StoreLocal']
write(lab / 'tape-summary.json', dict(reference=old[42:47], candidate=new[42:46],
    unchangedControlCodeCount={case:len(tapes['reference'][case]) for case in (typed, quoted, supplied)}))
write(comparison / 'identity.json', dict(sourceRevision=reference, sourceImageRevision=base['candidate'],
    candidate=candidate, purpose='B1517 exact-width tuple display parallel assignment', imageFiles=images,
    coreSHA256={key: rows[core] for role, rows in images.items() for key in (role, role + '-control')},
    cpythonWorkerSHA256=base['cpythonWorkerSHA256'], expectedCPythonSHA256=base['expectedCPythonSHA256'],
    catalogs={name: dict(sha256=digest(comparison / name)) for name in ('representative.json', 'jobs.json')}))

adapt(donor / 'stage.py', lab / 'stage.py', [('direct-closed-defaults-b1515-20261123', 'parallel-assignment-b1517-20261123'),
    ('retained-call-cpython-b1510-20261123', 'direct-closed-defaults-b1515-20261123'),
    ('lython-b1515-fixtures', 'lython-b1517-fixtures'), ('len(jobs) == 7','len(jobs) == 5'), ('< 367,', '< 265,')])
quiet = (donor / 'quiet.py').read_text(encoding='utf-8')
remove = quiet[quiet.index('  if free < minimum:'):quiet.index('  assert free >= minimum')]
adapt(donor / 'quiet.py', lab / 'quiet.py', [(remove, ''),
    ('lython-b1515-direct-closed-defaults-20261123','lython-b1517-parallel-assignment-20261123'),
    ('.+b1515-', '.+b1517-'), ('lython-b1515-stage-', 'lython-b1517-stage-'),
    ('# Seven bounded lanes write under 1 MiB of receipts. A 106 MiB', '# Five bounded lanes write under 1 MiB of receipts. A 99 MiB'),
    ('106 * 1024 * 1024', '99 * 1024 * 1024'), ('3 * 1024 * 1024', '2 * 1024 * 1024'),
    ('RuntimeMaxSec=405', 'RuntimeMaxSec=315'), ('seconds=363', 'seconds=247')])
adapt(donor / 'summarize.py', lab / 'summarize.py', [('== 7\nassert hashlib', '== 5\nassert hashlib'),
    ('len(warm["jobs"])==7', 'len(warm["jobs"])==5'), ('timedBatches=196', 'timedBatches=140')])
shutil.copyfile(donor / 'allocations.py', lab / 'allocations.py')

