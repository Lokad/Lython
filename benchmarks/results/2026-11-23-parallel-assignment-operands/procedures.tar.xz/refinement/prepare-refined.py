from pathlib import Path

lab = Path(__file__).resolve().parent
template = lab.parent / 'prepare.py'
source = template.read_text(encoding='utf-8')
for old, new in (
    ('repo = lab.parents[3]', 'repo = lab.parents[4]'),
    ("donor = lab.parent / 'direct-closed-defaults-20261123'", "donor = lab.parents[1] / 'direct-closed-defaults-20261123'"),
    ("reference, candidate + '^', '--', 'src')", "reference, 'e67ca4033^', '--', 'src')"),
    ("catalog = read(lab.parent / 'csv-batched-markers-20261123", "catalog = read(lab.parents[1] / 'csv-batched-markers-20261123"),
    ("inspector = lab.parent / 'adjacent-integer-results-20261123", "inspector = lab.parents[1] / 'adjacent-integer-results-20261123"),
    ("catalog['cases'] += [row for row in read(donor / 'comparison/representative.json')['cases'] if row['id'] == supplied]\n",""),
    ("== cases | {supplied}", "== cases"),
    ("dict(warm=[[explicit, 'warm'], [explicit, 'compile-run'],\n    [typed, 'warm'], [quoted, 'warm'], [supplied, 'warm']])",
     "dict(warm=[[typed, 'warm'], [explicit, 'warm'], [quoted, 'warm']])"),
    ("verified['caseCount'] == 4", "verified['caseCount'] == 3"),
    ("for control in (typed, quoted, supplied)", "for control in (typed, quoted)"),
    ("for case in (typed, quoted, supplied)", "for case in (typed, quoted)"),
    ("B1517 exact-width tuple display parallel assignment", "B1517 isolated assignment reversal dispatch"),
    ("'parallel-assignment-b1517-20261123'", "'parallel-assignment-refined-b1517-20261123'"),
    ("'lython-b1517-fixtures'", "'lython-b1517-refined-fixtures'"),
    ("'len(jobs) == 5'", "'len(jobs) == 3'"),
    ("'< 265,'", "'< 170,'"),
    ("'lython-b1517-parallel-assignment-20261123'", "'lython-b1517-parallel-assignment-refined-20261123'"),
    ("'.+b1517-'", "'.+b1517-refined-'"),
    ("'lython-b1517-stage-'", "'lython-b1517-refined-stage-'"),
    ("Five bounded lanes write under 1 MiB of receipts. A 99 MiB", "Three bounded lanes write under 1 MiB of receipts. A 92 MiB"),
    ("'99 * 1024 * 1024'", "'92 * 1024 * 1024'"),
    ("'2 * 1024 * 1024'", "'1536 * 1024'"),
    ("'RuntimeMaxSec=315'", "'RuntimeMaxSec=230'"),
    ("'seconds=247'", "'seconds=165'"),
    ("'== 5\\nassert hashlib'", "'== 3\\nassert hashlib'"),
    ("'len(warm[\"jobs\"])==5'", "'len(warm[\"jobs\"])==3'"),
    ("'timedBatches=140'", "'timedBatches=84'"),
):
    assert old in source, old
    source = source.replace(old, new)
exec(compile(source, str(template), 'exec'))

