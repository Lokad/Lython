spaces=[9,10,11,12,13,28,29,30,31,32,133,160,5760,8192,8193,8194,8195,8196,8197,8198,8199,8200,8201,8202,8232,8233,8239,8287,12288]
for cp in spaces:
    value=chr(cp)+'αΟΣ'+chr(cp)+'ßİ café'+chr(cp)
    print(cp,value.split(),value.rsplit())
    for limit in [-2,-1,0,1,2,3,100]:
        print(limit,value.split(None,limit),value.rsplit(None,limit))
    print(value.lower().split(),value.upper().split())
