from pathlib import Path
import datetime,hashlib,json
r=Path(__file__).parent;d=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
for role in ['reference','candidate']:
 expected=dict(d['auxiliaryFiles'][role]);expected['Lokad.Lython.dll']=d['coreSHA256'][role];actual={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in(r/role).iterdir()if p.is_file()};assert actual==expected
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in d['sources'].items())
(r/'image-verification-after-desktop.json').write_text(json.dumps(dict(recordedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),completeRoleFiles={role:len(d['auxiliaryFiles'][role])+1 for role in ['reference','candidate']},allFrozenSourceAndImageHashesUnchanged=True,mutableBuildOutputsWereCopiedNotHardLinked=True,vmWorkerAuxiliarySubsetCheckedSeparatelyBeforeLaunch=True),indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');s=s.replace('   Stop with delivery/debt decision, no wider hashing/value-VM redesign.', '''   Stop with delivery/debt decision, no wider hashing/value-VM redesign.
   Corrected candidatea9d54f99:103internal/484public focused cases per actual11/10,
   plus all three original64MiB construction/cancellation cases per target pass.
   Initial six fixture assumptions and two obsolete inventory-presence assertions
   are preserved. A genuine public rollback regression (extra64MiB committed after
   cancellation) was demonstrated and fixed without weakening its assertion.
   Public output stays temporary until publication; exclusive failed scratch is
   discarded, while private future-word funding remains. One active-context owner
   replaces the duplicate governor parameter. Complete copied image hashes verify.
   Allocation is effectively flat (88B/job saved on each text shape). B713four jobs
   run under360s ownership with12s warmups/five1s batches; observe no earlier than
   2026-11-14T04:01:12UTC. Initial space refusal starts no worker;276exact committed
   archive replicas are later retired under fresh idle lease. All current images,
   canonical evidence and254/252MiB staging/archive floors remain intact. No CPU claim yet.''')
p.write_text(s,encoding='utf-8',newline='\n');print('Current source/full images verified; focused results, rollback correction and live B713recorded without a timing claim.',flush=True)
