from pathlib import Path
r=Path(__file__).parent;s=(r.parent/'native-owned-slots-r339/check-related.py').read_text(encoding='utf-8');a=s.index('filters=');b=s.index("for target in",a)
s=s[:a]+'''filters={'Lokad.Lython.Tests':'FullyQualifiedName~Split|FullyQualifiedName~StringMethod|FullyQualifiedName~CasedWhitespace|FullyQualifiedName~NativeWord|FullyQualifiedName~DictionaryCounting|FullyQualifiedName~WordBuffer|FullyQualifiedName~CasedSplit',
         'Lokad.Lython.PublicApi.Tests':'FullyQualifiedName~Split|FullyQualifiedName~StringMethod|FullyQualifiedName~CasedWhitespace|FullyQualifiedName~NativeWord|FullyQualifiedName~DictionaryCounting|FullyQualifiedName~NativeClosureLifetime|FullyQualifiedName~NativeClosureContinuation'}
'''+s[b:]
(r/'check-related.py').write_text(s,encoding='utf-8',newline='\n')
