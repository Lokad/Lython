def lower_words(value): return value.lower().split()
def upper_words(value): return value.upper().split()
def analyze(value):
    counts={}
    total=0
    word=None
    for word in lower_words(value):
        counts[word]=counts.get(word,0)+1
        total+=1
    return counts,total,word
saved=[]
for value in [' ΑΟΣ ΑΟΣ́ ΟΣ-Α σßİ café 😀 ', 'ﬀ ﬁ ﬂ ﬃ ﬄ ﬅ ﬆ ǰ ΐ 𐐨', '', '   ', 'x'*1000+' ß'*40]:
    print(value.lower().split(),value.upper().split())
    print([word for word in lower_words(value)],[word for word in upper_words(value)])
    saved.append(analyze(value))
print(saved)
