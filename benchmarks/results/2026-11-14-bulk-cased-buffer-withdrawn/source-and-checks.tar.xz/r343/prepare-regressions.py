from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).parent
programs=[('python-whitespace-directions', '''spaces=[9,10,11,12,13,28,29,30,31,32,133,160,5760,8192,8193,8194,8195,8196,8197,8198,8199,8200,8201,8202,8232,8233,8239,8287,12288]
for cp in spaces:
    value=chr(cp)+'αΟΣ'+chr(cp)+'ßİ café'+chr(cp)
    print(cp,value.split(),value.rsplit())
    for limit in [-2,-1,0,1,2,3,100]:
        print(limit,value.split(None,limit),value.rsplit(None,limit))
    print(value.lower().split(),value.upper().split())
'''),('exact-separators-and-empty-parts', '''for value in ['', '::', '::α::β::', 'αééβéé', 'aaa', 'a😀b😀', '  ']:
    for separator in ['::','éé','aa','😀',' ']:
        for limit in [-2,-1,0,1,2,4]:
            print(repr(value),repr(separator),limit,value.split(separator,limit),value.rsplit(separator,limit))
'''),('whole-case-context-and-escaping-words', '''def lower_words(value): return value.lower().split()
def upper_words(value): return value.upper().split()
def analyze(value):
    counts={}
    total=0
    word=None
    for word in lower_words(value):
        counts[word]=counts.get(word,0)+1
        total+=1
    return counts,total,word
saved=[]
for value in [' ΑΟΣ ΑΟΣ\u0301 ΟΣ-Α σßİ café 😀 ', 'ﬀ ﬁ ﬂ ﬃ ﬄ ﬅ ﬆ ǰ ΐ 𐐨', '', '   ', 'x'*1000+' ß'*40]:
    print(value.lower().split(),value.upper().split())
    print([word for word in lower_words(value)],[word for word in upper_words(value)])
    saved.append(analyze(value))
print(saved)
'''),('nested-loans-and-many-parts', '''def words(value): return value.upper().split()
saved=[]
for outer in words('αß café first'):
    for inner in words(' '.join(['ßΣ']*97)):
        if len(saved)<6: saved.append((outer,inner))
    saved.append(outer)
print(saved)
value='  '+'  '.join(['AßΣ']*97)+'  '
print(len(value.split()),len(value.rsplit()),value.split(None,1)[0],value.rsplit(None,1)[-1])
''')]
records=[];rows=[]
for name,source in programs:
 (r/(name+'.py')).write_text(source,encoding='utf-8',newline='\n')
 done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],capture_output=True,text=True,encoding='utf-8',timeout=15)
 (r/(name+'.stdout')).write_text(done.stdout,encoding='utf-8',newline='\n');(r/(name+'.stderr')).write_text(done.stderr,encoding='utf-8',newline='\n');assert done.returncode==0 and not done.stderr,(name,done.stderr)
 records.append(dict(name=name,sourceSHA256=hashlib.sha256(source.encode()).hexdigest(),stdout=done.stdout,exitCode=0));rows.append('        { '+json.dumps(source,ensure_ascii=False)+', '+json.dumps(done.stdout,ensure_ascii=False)+' },')
(r/'python-controls.json').write_text(json.dumps(dict(reference='CPython3.13.2 isolated',programs=records),indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
p=Path('tests/Lokad.Lython.PublicApi.Tests/BulkCasedSplitTests.cs');assert not p.exists()
p.write_text('''using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.PublicApi.Tests;

public sealed class BulkCasedSplitTests
{
    public static TheoryData<string, string> Programs => new()
    {
'''+ '\n'.join(rows)+'''
    };

    [Theory]
    [MemberData(nameof(Programs))]
    public async Task SplitDirectionsUnicodeAndRetainedWordsFollowPython(string source, string expected)
    {
        var budget = new LythonMemoryBudget(8 * 1024 * 1024);
        using (var script = new LythonEngine().Compile(source, budget))
        {
            Assert.True(script.IsValid, string.Join("; ", script.Diagnostics.Select(d => d.Message)));
            var baseline = budget.ReservedBytes;
            foreach (var asynchronous in new[] { false, true })
            {
                using (var result = asynchronous ? await script.RunAsync(new MockLythonHost()) : script.Run(new MockLythonHost()))
                {
                    Assert.True(result.Success, result.Failure?.Message);
                    Assert.Equal(expected, result.StandardOutput);
                }
                Assert.Equal(baseline, budget.ReservedBytes);
            }
        }
        Assert.Equal(0, budget.ReservedBytes);
    }

    [Fact]
    public async Task EscapingWordsKeepIndependentStorageAcrossSharedBudgetExecutions()
    {
        const string source = """
            def words(value): return value.upper().split()
            result=[word for word in words(('ßé'*256)+' saved')]
            return result,result[0]
            """;
        var budget = new LythonMemoryBudget(4 * 1024 * 1024);
        using (var script = new LythonEngine().Compile(source, budget))
        {
            Assert.True(script.IsValid);
            var baseline = budget.ReservedBytes;
            var expected = string.Concat(Enumerable.Repeat("SSÉ", 256));
            using (var first = script.Run(new MockLythonHost()))
            {
                Assert.True(first.Success, first.Failure?.Message);
                var firstParts = Assert.IsAssignableFrom<IReadOnlyList<object>>(first.ReturnValue);
                Assert.Equal(expected, firstParts[1]);
                var retained = budget.ReservedBytes;
                Assert.True(retained > baseline);
                using (var second = await script.RunAsync(new MockLythonHost()))
                {
                    Assert.True(second.Success, second.Failure?.Message);
                    Assert.Equal(expected, firstParts[1]);
                    Assert.Equal(expected, Assert.IsAssignableFrom<IReadOnlyList<object>>(second.ReturnValue)[1]);
                    Assert.True(budget.ReservedBytes > retained);
                }
                Assert.Equal(retained, budget.ReservedBytes);
                Assert.Equal(expected, firstParts[1]);
            }
            Assert.Equal(baseline, budget.ReservedBytes);
        }
        Assert.Equal(0, budget.ReservedBytes);
    }
}
''',encoding='utf-8',newline='\n')
print('Four isolated Python matrices and retained-result/shared-allowance coverage prepared.',flush=True)
