from pathlib import Path
import json,os,subprocess
r=Path(__file__).parent;env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';'+env['PATH'];rows=[]
filters={'Lokad.Lython.Tests':'FullyQualifiedName~CasedSplit|FullyQualifiedName~WordBufferLoan|FullyQualifiedName~DictionaryCountingLoop|FullyQualifiedName~StringSplit|FullyQualifiedName~SeparatedSplit|FullyQualifiedName~WhitespaceSplit', 'Lokad.Lython.PublicApi.Tests':'FullyQualifiedName~BulkCasedSplit|FullyQualifiedName~ImmediateCasedSplit|FullyQualifiedName~WhitespaceSplitBoundary|FullyQualifiedName~SeparatedStringSplit|FullyQualifiedName~DeferredSplitBehavior|FullyQualifiedName~DirectStringSplitExecution'}
for target in ['net11.0','net10.0']:
 for assembly,filter in filters.items():
  filter='('+filter+')&Category!=Stress';log=r/(assembly+'-new-'+target+'.log')
  with log.open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','test',f'tests/{assembly}/{assembly}.csproj','-c','Release','-f',target,'--filter',filter,'--logger','trx','--results-directory',str((r/(assembly+'-new-'+target)).resolve())],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
  print(assembly,target,done.returncode,log.read_text(encoding='utf-8')[-5000:],flush=True);rows.append(dict(assembly=assembly,target=target,returncode=done.returncode,filter=filter,log=log.name));(r/'new-checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n');assert done.returncode==0
