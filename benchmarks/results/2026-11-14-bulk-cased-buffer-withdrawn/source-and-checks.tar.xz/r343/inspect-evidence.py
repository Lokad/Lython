from pathlib import Path
import json,collections
r=Path(__file__).parent
for p in sorted(r.iterdir()):
 if p.is_dir():
  files=[f for f in p.rglob('*') if f.is_file()]
  print(p.name,len(files),sum(f.stat().st_size for f in files))
for name in ['prospective.json','b713/config.json','b713/retirement-proof.json','restored-checks.json']:
 p=r/name
 if p.exists():
  data=json.loads(p.read_text(encoding='utf-8'));print(name, list(data)if isinstance(data,dict)else data)
for p in sorted((r/'b713').iterdir()):print('b713',p.name,p.stat().st_size if p.is_file()else'directory')
