from pathlib import Path
import hashlib,json,os,subprocess
r=Path(__file__).parent;reference=json.loads((r/'reference-identity.json').read_text(encoding='utf-8'));env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';'+env['PATH']
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in reference['sources'].items())
with(r/'restored-build.log').open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','build','Lokad.Lython.slnx','-c','Release','--no-restore','--no-incremental','--disable-build-servers','-m:1'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=240)
assert done.returncode==0,(r/'restored-build.log').read_text(encoding='utf-8')[-4000:];print('Forced nonincremental Release solution build passed.',flush=True)
rows=[]
filters={'Lokad.Lython.Tests':'(FullyQualifiedName~StringWindowOwnership|FullyQualifiedName~WhitespaceStorageOwnership|FullyQualifiedName~NativeTextConstructionRollback|FullyQualifiedName~Split|FullyQualifiedName~StringMethod|FullyQualifiedName~CasedWhitespace|FullyQualifiedName~NativeWord|FullyQualifiedName~DictionaryCounting|FullyQualifiedName~WordBuffer|FullyQualifiedName~CasedSplit)&Category!=Stress', 'Lokad.Lython.PublicApi.Tests':'(FullyQualifiedName~Split|FullyQualifiedName~StringMethod|FullyQualifiedName~CasedWhitespace|FullyQualifiedName~NativeWord|FullyQualifiedName~DictionaryCounting|FullyQualifiedName~NativeClosureLifetime|FullyQualifiedName~NativeClosureContinuation)&Category!=Stress'}
for target in ['net11.0','net10.0']:
 for assembly,filter in list(filters.items())+[('Lokad.Lython.Tests','FullyQualifiedName~NativeTextConstructionRollback')]:
  kind='original-rollback'if filter=='FullyQualifiedName~NativeTextConstructionRollback'else'regular';log=r/(assembly+'-restored-'+kind+'-'+target+'.log')
  with log.open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','test',f'tests/{assembly}/{assembly}.csproj','-c','Release','-f',target,'--no-build','--filter',filter,'--logger','trx','--results-directory',str((r/(assembly+'-restored-'+kind+'-'+target)).resolve())],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
  print(assembly,target,kind,done.returncode,log.read_text(encoding='utf-8')[-1800:],flush=True);rows.append(dict(assembly=assembly,target=target,kind=kind,returncode=done.returncode,log=log.name));(r/'restored-checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n');assert done.returncode==0
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in reference['sources'].items());print('Restored source checks complete; no unchanged full platform/package replay.',flush=True)
