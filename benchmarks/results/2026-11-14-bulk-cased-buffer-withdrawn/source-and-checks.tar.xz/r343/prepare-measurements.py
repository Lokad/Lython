from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent;prior=r.parent/'shared-arithmetic-r341';source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));out=r/'b713';out.mkdir()
aux=json.loads((prior/'b711/identity.json').read_text(encoding='utf-8'))['candidateAuxiliaryFiles'];assert all(source['auxiliaryFiles'][role][name]==sha for role in ['reference','candidate']for name,sha in aux.items())
identity=dict(sourceRevision='R343frozen'+source['coreSHA256']['candidate'][:8]+' vs fully qualified2f606519/frozen53becdb6',purpose='Same-source complete captured/direct text pipeline warm, captured compile-to-result and unchanged fulfillment control; owned bulk cased UTF8 replaces range inventories. No external timing.',coreSHA256={label:source['coreSHA256']['candidate'if label.startswith('candidate')else'reference']for label in ['reference','candidate','reference-control','candidate-control']},candidateAuxiliaryFiles=aux,referenceAuxiliaryFiles=aux,catalogSHA256=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest(),referenceCase='scripts.text-summary-helpers.nonlocal-counter.large',variantCase='scripts.text-summary-helpers.nonlocal-counter.large',controlCases=['scripts.csv-fulfillment.large'],sourceAndScriptDifferIntentionally=False)
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','compile-run'],['scripts.text-summary.inline.large','warm'],['scripts.csv-fulfillment.large','warm']]
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py','launch.py']:
 s=(prior/'b711'/name).read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/shared-arithmetic-b711-20261114','/home/lokad/lython-bench-checks/bulk-cased-buffer-b713-20261114').replace('lython-b711-shared-arithmetic-20261114','lython-b713-bulk-cased-buffer-20261114').replace('B711','B713')
 if name=='collect.py':
  a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==4 and all(case in cases for case,lane in jobs)\n'+s[b:]
  s=s.replace("< 240, 'Reserve60seconds", "< 300, 'Reserve60seconds").replace('warmupSeconds=8, capturedWarmupSeconds=8, compilationWarmupSeconds=8, targetBatchSeconds=.5','warmupSeconds=12, capturedWarmupSeconds=12, compilationWarmupSeconds=12, targetBatchSeconds=1').replace('time.monotonic()+8','time.monotonic()+12').replace('math.ceil(count*.5/','math.ceil(count*1/')
 if name=='launch.py':
  s=s.replace("assert digest(source/'candidate/Lokad.Lython.dll')=='38c0562fdd20b4df2ba0f37806cfdfa1b20a31f9fbabcd522e28c611ea3e8567'", "assert digest(source/'candidate/Lokad.Lython.dll')==config['identity']['coreSHA256']['reference']")
  s=s.replace('RuntimeMaxSec=300','RuntimeMaxSec=360').replace('seconds=240','seconds=300').replace('ownerSeconds=300','ownerSeconds=360')
 if name=='retrieve.py':s=s.replace("['elapsedSeconds']<300", "['elapsedSeconds']<360")
 if name.endswith('.py'):ast.parse(s)
 (out/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
 for name in ['identity.json','collect.py','archive-owned.py','run.sh']:t.add(out/name,arcname=name)
 for name,arc in [('catalog.json','representative.json'),('candidate-core.dll','candidate-core.dll'),('reference-core.dll','reference-core.dll'),('candidate-identity.json','source-identity.json'),('reference-identity.json','reference-source-identity.json')]:t.add(r/name,arcname=arc)
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
config=dict(root='/home/lokad/lython-bench-checks/bulk-cased-buffer-b713-20261114',sourceRoot='/home/lokad/lython-bench-checks/shared-arithmetic-b711-20261114',unit='lython-b713-bulk-cased-buffer-20261114',identity=identity,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['verify-worker.py','measure-allocation.py']:(r/name).write_bytes((prior/name).read_bytes())
for role in ['reference','candidate']:(r/('allocation-'+role+'-catalog.json')).write_bytes((r/'catalog.json').read_bytes())
print('Prepared four-job360s comparison:12s warmups/five1s rounds; no producer or framework changes.',flush=True)
