from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;prior=r.parent/'shared-arithmetic-r341';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
rows=json.loads((r/'focused-checks.json').read_text(encoding='utf-8'));assert len(rows)==4 and all(d['returncode']==0 for d in rows)
rollback=json.loads((r/'rollback-corrected.json').read_text(encoding='utf-8'));assert len(rollback)==2 and all(d['returncode']==0 for d in rollback)
reference=json.loads((r/'reference-identity.json').read_text(encoding='utf-8'));sources={p:sha(p)for p in reference['sources']};changed=[p for p in sources if sources[p]!=reference['sources'][p]]
assert sorted(changed)==['src/Lokad.Lython/Runtime/LythonRuntime.Executable.CasedSplits.cs','src/Lokad.Lython/Runtime/MemoryGovernor.cs','src/Lokad.Lython/Runtime/Text/PyStringOps.Whitespace.cs'],changed
env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';'+env['PATH']
with(r/'candidate-build.log').open('wb')as log:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-restore','--no-incremental','--disable-build-servers','-m:1'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert done.returncode==0,(r/'candidate-build.log').read_text(encoding='utf-8')[-2000:]
assert sources=={p:sha(p)for p in sources}
for role in ['reference','candidate']:
 out=r/role;out.mkdir()
 for p in(prior/'candidate').iterdir():
  if p.is_file():shutil.copyfile(p,out/p.name)
 if role=='candidate':shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',out/'Lokad.Lython.dll')
 shutil.copyfile(out/'Lokad.Lython.dll',r/(role+'-core.dll'))
identity=dict(headBeforeCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),referenceProductionCommit='2f606519',coreSHA256={role:sha(r/role/'Lokad.Lython.dll')for role in ['reference','candidate']},sources=sources,productionFiles=len(sources),changedProductionInputs=changed,removedMechanisms=['range inventories/growth/copy/clear','per-word casing in cased iteration','CompactWordUtf8 copies','duplicate cased-operation governor parameter'],auxiliaryFiles={role:{p.name:sha(p)for p in(r/role).iterdir()if p.is_file()and p.name!='Lokad.Lython.dll'}for role in ['reference','candidate']},qualified=False,sourceAndScriptDifferIntentionally=False)
assert identity['auxiliaryFiles']['reference']==identity['auxiliaryFiles']['candidate']and len(sources)==581
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as t:
 for name in sources:t.add(name,arcname=name)
print('Frozen bulk cased-buffer candidate',identity['coreSHA256'],'581inputs; full copied images/auxiliary hashes recorded.',flush=True)
