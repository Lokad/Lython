from pathlib import Path
import hashlib,json,shutil,tarfile,xml.etree.ElementTree as ET
r=Path(__file__).parent
out=Path('benchmarks/results/2026-11-14-bulk-cased-buffer-withdrawn')
rows=json.loads((r/'restored-checks.json').read_text(encoding='utf-8'))
assert len(rows)==6 and all(v['returncode']==0 for v in rows),rows
reference=json.loads((r/'reference-identity.json').read_text(encoding='utf-8'))
assert len(reference['sources'])==581
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in reference['sources'].items())
status=json.loads((r/'b713/terminal-status.json').read_text(encoding='utf-8'))
assert status['exitCode']=='0' and status['receipt']['allWorkersJoined'] and status['receipt']['archivedAndVerifiedUnderLease']
summary=json.loads((r/'b713/summary.json').read_text(encoding='utf-8'))
counts=[]
for row in rows:
 directory=r/row['log'].removesuffix('.log')
 files=list(directory.glob('*.trx'));assert len(files)==1,files
 root=ET.parse(files[0]).getroot();ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
 count=root.find('t:ResultSummary/t:Counters',ns).attrib
 assert int(count['failed'])==0 and int(count['passed'])>0,count
 counts.append(dict(**row,counters=count))
decision=dict(
 date='2026-11-14',state='withdrawn; qualified production restored exactly',
 qualifiedProductionCommit='2f6065195031f1eb8c09da8febb5e06f611c963b',
 referenceCore=reference['coreSHA256']['reference'],
 candidateCore=summary['identity']['coreSHA256']['candidate'],
 reason='Extra sizing, casing, counting and consumption scans outweigh removed range storage; allocation is effectively flat and elapsed/CPU adversity is clear with a nearly flat CSV control.',
 timing=summary['timing'],
 allocation='88B/job saved on captured and direct text (0.0161% and 0.0197%); fulfillment effectively flat. Not a material reduction.',
 semanticChecks='Corrected candidate and restored baseline each pass 103 internal, 484 public and all 3 original 64MiB rollback cases per actual net11/net10.',
 restoredChecks=counts,
 initialFailures='Six changed range-capacity fixture assumptions, two obsolete range-presence assertions, and one genuine prototype-only 64MiB scratch-retention regression. Original adverse evidence and correction are retained.',
 rollback='A cancellation initially retained 64MiB scratch after unpublished construction. Corrected prototype discarded failed scratch and held output admission until publication. Withdrawal restores the original temporary-construction guarantee; no baseline bug is claimed.',
 retained='Four independent CPython semantic matrices and a shared-budget retained-result test. No slower runtime mechanism, altered architecture-only fixture or new policy remains.',
 future='A changed pipeline would need eliminate extra scans with an explicit ownership/Unicode acceptance milestone. This result does not permanently ban a materially different design. No unchanged retiming or automatic larger redesign is selected.',
 measurementBoundary='Warm includes mediated RAM-fixture I/O, output/file golden checks and prior-result cleanup. Compile-run also includes compilation and script disposal. Excludes process startup and protocol/reset/final cache cleanup; wider CPU includes protocol/reset. Separate desktop allocation diagnostic. No external CPython timing, tail-latency, RSS or universal claim.',
 machine='Quiet Azure F4as_v7 / Ubuntu 24.04.4 / .NET 11; fixed B685 worker, optional adapter 0.4, ordinary GC/tiering. Local semantics reference isolated CPython 3.13.2.',
 environment='First disk-floor refusal started no service/guest. Later exact Git-committed archive replicas were retired under an idle lease; current images, canonical evidence and 254/252MiB staging/archive floors preserved.',
 completedQualification='R341 full green 43548640898 remains valid for exact restored production. No unchanged full-platform/package replay or R343 release qualification.',
 publication='postponed')
(r/'decision.json').write_text(json.dumps(decision,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
(r/'tooling-correction.json').write_text(json.dumps(dict(initialRetirementProposal='assert freed>=100*1024*1024,(freed,len(matches))',outcome='Only 82MiB exact committed archive replicas identified, so local proposal guard failed before mutation.',correction='Check sufficient space for actual unpacked payload under unchanged 254MiB staging floor; no production VM floor or evidence proof weakened.',hardcodedReferenceCorrection='Copied launcher reference check corrected from older 38c0562f to identity manifest 53becdb6 before VM launch.',catalogCorrection='Requested ordinary text ID absent from copied catalog; create explicit inline-script variant with independent Python golden control. Failed preparation started no VM worker.'),indent=2)+'\n',encoding='utf-8',newline='\n')
out.mkdir(exist_ok=True)
for name in ['decision.json','allocation-summary.json','reference-identity.json','candidate-identity.json','worker-verification.json','restoration.json','restored-checks.json','python-controls.json','workload-python-controls.json']:
 shutil.copyfile(r/name,out/name)
for name in ['summary.json','terminal-status.json','archive-receipt.json','observations.tgz']:
 shutil.copyfile(r/'b713'/name,out/name)
archive=out/'source-and-checks.tar.xz'
exclude={'reference','candidate'}
with tarfile.open(archive,'w:xz',preset=6)as tar:
 for p in sorted(r.rglob('*')):
  relative=p.relative_to(r)
  if not p.is_file()or relative.parts[0]in exclude or relative.as_posix()=='b713/payload.tgz':continue
  tar.add(p,arcname='r343/'+relative.as_posix(),recursive=False)
 tar.add('tests/Lokad.Lython.PublicApi.Tests/BulkCasedSplitTests.cs',arcname='retained/BulkCasedSplitTests.cs')
rawsha=hashlib.sha256((out/'observations.tgz').read_bytes()).hexdigest();assert rawsha==status['receipt']['archiveSHA256']
(out/'README.md').write_text('''# Bulk cased UTF8 buffer: withdrawn prototype

2026-11-14, R343/B713. Compare qualified `2f606519` / frozen `53becdb6`
against prototype `a9d54f99`, with identical complete scripts, inputs, goldens,
worker and optional 0.4 adapter. The prototype cases a whole line into an owned
reusable UTF8 buffer, then sizes/scans final words instead of storing ranges.
It removes range growth/copy/clear machinery, but adds complete buffer scans.

| Complete workload | Reference ms | Prototype ms | Elapsed change | Wider CPU change |
| --- | --- | --- | --- | --- |
| Captured text, warm | 1.394–1.413 | 1.531–1.580 | +8.35..+13.41% | +8.59..+12.54% |
| Captured text, compile-to-result | 1.518–1.546 | 1.666–1.707 | +7.72..+12.45% | +7.83..+12.23% |
| Direct text, warm | 0.916–0.979 | 1.101–1.122 | +12.48..+22.58% | +10.85..+21.77% |
| Unchanged fulfillment control, warm | See raw summary | See raw summary | −0.10..+0.48% | −0.88..+1.11% |

Changes compare all fresh-process source pairings, positive means slower.
Two processes per source/job, 12s full-request warmups and five rotating 1s batches
on quiet Azure F4as_v7/Ubuntu24.04.4/.NET11. Captured text uses 3072 lines/35,840B;
direct text uses the same input with the count-only helper explicitly inlined.
Its reference spread is 6.92%, so the precise adverse magnitude is uncertain;
all pairings remain adverse. The CSV control is nearly flat. Separate four-process
desktop allocation checks save only 88B/job on either text shape (0.016/0.020%);
fulfillment is effectively flat. No material allocation reduction is established.

Warm clocks include mediated RAM-fixture I/O, output/file checks and prior-result
cleanup. Compile-to-result adds compilation/script disposal. Startup, protocol/reset
and final cache shutdown are excluded; wider CPU includes protocol/reset. There is
no CPython timing, tail-latency, physical-heap or whole-runtime claim here.

**Decision: withdraw this version.** The extra scans outweigh range storage removal.
All 581 production input bytes are restored exactly to the fully qualified R341
snapshot. No prototype mechanism or modified internal architecture fixture remains.
Four independent CPython3.13.2 semantic matrices and a retained-result/shared-budget
test remain useful public regressions. A materially different pipeline can be
reconsidered if it removes the extra work; unchanged retiming is not justified.

Both corrected prototype and restored baseline pass 103 internal/484 public cases
and all three original 64MiB cancellation/rollback cases per actual11/10. A genuine
prototype-only cancellation bug initially retained 64MiB scratch; its failure,
sources/binary and correction survive. The baseline's original temporary admission
already preserves that guarantee. Six range-capacity fixture failures and two
obsolete inventory-presence assertions also remain in the evidence. Assertions,
stress scales and timeouts were not relaxed. A forced nonincremental Release
solution rebuild precedes restored checks. The existing R341 full Windows/Ubuntu,
stress and installed-consumer delivery remains the production qualification;
unchanged qualification is not repeated for a withdrawn runtime.

Initial disk preflight refused before a service/guest started. Exact Git-committed
archive replicas were subsequently retired under a fresh idle lease; canonical
evidence, current images and 254/252MiB staging/archive floors remain intact.
B713 completes in298.45s under360s ownership; all workers join, RAM fixtures are
removed and the raw archive is verified under the lease. Terminal state is cached.

[Timings](summary.json), [allocation](allocation-summary.json),
[decision/restored checks](decision.json), [raw observations](observations.tgz),
[sources, binaries, initial failures, corrections and tools](source-and-checks.tar.xz).
The large archive omits duplicated auxiliary images/payload; complete image hashes
and worker identity remain recorded. Publication remains postponed.
''',encoding='utf-8',newline='\n')
print('Archived withdrawal, exact restoration and useful regressions:',out,archive.stat().st_size,flush=True)
