from pathlib import Path
import json,os,subprocess
r=Path(__file__).parent;env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';'+env['PATH']
target='net11.0';filter='(FullyQualifiedName~CasedSplit|FullyQualifiedName~WordBufferLoan|FullyQualifiedName~DictionaryCountingLoop|FullyQualifiedName~StringSplit)&Category!=Stress'
with(r/'initial-check.log').open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f',target,'--filter',filter,'--logger','trx','--results-directory',str((r/'initial-check').resolve())],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
print(done.returncode,(r/'initial-check.log').read_text(encoding='utf-8')[-10000:],flush=True)
(r/'initial-check-status.json').write_text(json.dumps(dict(returncode=done.returncode,filter=filter),indent=2)+'\n',encoding='utf-8',newline='\n')
