from pathlib import Path
import json,shutil,subprocess
r=Path(__file__).parent;proof=json.loads((r/'retirement-proof.json').read_text(encoding='utf-8'));config=json.loads((r/'config.json').read_text(encoding='utf-8'))
proof['originalCanonicalMatches']=len(proof['selected']);proof['selected']=list({v['path']:v for v in proof['selected']}.values())
proof['selectedAllocatedBytes']=sum(v['allocated']for v in proof['selected'])
out=r/'first-space-refusal';out.mkdir()
for name in ['launch.py','launch.log','launch-command.py','config.json','space-inspection.json','archive-inspection.json']:shutil.copyfile(r/name,out/name)
code='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
proof=PROOF
config=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not Path(config['root']).exists()
 service=subprocess.run(['systemctl','show',config['unit']+'.service','--property=LoadState,MainPID'],capture_output=True,text=True).stdout
 assert 'LoadState=not-found'in service and 'MainPID=0'in service
 targets=[]
 assert len({v['path']for v in proof['selected']})==len(proof['selected'])
 for row in proof['selected']:
  p=base/row['path'];s=p.lstat()
  assert p.resolve(strict=True)==p and p.is_relative_to(base)and stat.S_ISREG(s.st_mode)and not p.is_symlink()
  assert p.name.endswith(('.tgz','.tar.xz'))and s.st_uid==os.getuid()and s.st_nlink==1 and s.st_size==row['bytes']
  assert hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
  assert not row['path'].startswith(('shared-arithmetic-b711-','captured-loop-ip-b712-','bulk-cased-buffer-b713-'))
  targets.append((p,s.st_blocks*512))
 before=shutil.disk_usage(base).free
 assert before+sum(n for p,n in targets)>254*1024*1024+config['unpackedBytes']
 receipt=dict(beforeFreeBytes=before,canonicalProof=proof,originalUnitMissing=True,complete=False,noImageOrToolchainRetirement=True,vmFloorsUnchanged=True)
 saved=base/'b713-proved-archive-retirement-20261114.json';saved.write_text(json.dumps(receipt,indent=2)+'\\n',encoding='utf-8')
 for p,n in targets:p.unlink()
 after=shutil.disk_usage(base).free;assert after>254*1024*1024+config['unpackedBytes']
 receipt.update(complete=True,afterFreeBytes=after,retiredFiles=len(targets),retiredAllocatedBytes=sum(n for p,n in targets));saved.write_text(json.dumps(receipt,indent=2)+'\\n',encoding='utf-8');print(json.dumps(receipt))
'''.replace('PROOF',repr(proof)).replace('CONFIG',repr(config))
(r/'retirement-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True);assert done.returncode==0,done.stderr
(r/'retirement-receipt.json').write_text(done.stdout,encoding='utf-8',newline='\n');receipt=json.loads(done.stdout);print('Retired only',receipt['retiredFiles'],'proved committed archive replicas; freeBytes',receipt['afterFreeBytes'],'images/floors unchanged.',flush=True)
