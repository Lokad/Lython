from pathlib import Path
import json,subprocess
r=Path(__file__).parent;s=(r/'inspect-archives.py').read_text(encoding='utf-8')
s=s.replace("for n,p,s in files[:12]", "for n,p,s in files").replace("'archive-inspection.json'", "'archive-index.json'").replace('print(done.stdout,flush=True)',"print('Indexed',len(json.loads(done.stdout)['largest']),'owned archives for exact canonical matching.',flush=True)")
(r/'index-archives-run.py').write_text(s,encoding='utf-8',newline='\n')
done=subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'index-archives-run.py')],timeout=90);assert done.returncode==0
rows=json.loads((r/'archive-index.json').read_text(encoding='utf-8'))['largest'];(r/'archive-hashes.txt').write_text('\n'.join(row['sha256']for row in rows)+'\n',encoding='utf-8',newline='\n')
done=subprocess.run(['rg','-l','-F','-f',str(r/'archive-hashes.txt'),'benchmarks/results','-g','*.json'],capture_output=True,text=True,encoding='utf-8');assert done.returncode in [0,1]
(r/'canonical-hash-locations.txt').write_text(done.stdout,encoding='utf-8',newline='\n');print('Canonical hash location files:',len(done.stdout.splitlines()),flush=True)
