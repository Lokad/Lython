from pathlib import Path
import json,subprocess
r=Path(__file__).parent
code='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks')
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 files=[]
 for parent in [base]+[p for p in base.iterdir()if p.is_dir()and not p.is_symlink()]:
  for p in parent.iterdir():
   if p.is_file()and not p.is_symlink()and p.name.endswith(('.tgz','.tar.xz')):
    s=p.stat()
    if s.st_uid==os.getuid()and s.st_nlink==1:files.append((s.st_blocks*512,p,s))
 files.sort(key=lambda row:row[0],reverse=True)
 print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,totalArchives=len(files),allocatedArchiveBytes=sum(row[0]for row in files),largest=[dict(path=p.relative_to(base).as_posix(),bytes=s.st_size,allocated=n,uid=s.st_uid,nlink=s.st_nlink,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for n,p,s in files])))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True);assert done.returncode==0,done.stderr;(r/'archive-index.json').write_text(done.stdout,encoding='utf-8',newline='\n');print('Indexed',len(json.loads(done.stdout)['largest']),'owned archives for exact canonical matching.',flush=True)
