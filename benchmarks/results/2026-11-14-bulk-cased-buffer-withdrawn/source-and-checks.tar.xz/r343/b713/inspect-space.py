from pathlib import Path
import json,subprocess
r=Path(__file__).parent
code='''from pathlib import Path
import fcntl,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks')
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 workers=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True)
 print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,rootExists=(base/'bulk-cased-buffer-b713-20261114').exists(),service=subprocess.run(['systemctl','show','lython-b713-bulk-cased-buffer-20261114.service','--property=LoadState,ActiveState,MainPID'],capture_output=True,text=True).stdout,workers=workers.stdout,files=[dict(name=p.relative_to(base).as_posix(),bytes=p.stat().st_size,allocated=p.stat().st_blocks*512,nlink=p.stat().st_nlink,uid=p.stat().st_uid)for name in ['native-backedges-b708-20261114','native-owned-slots-b709-20261114','native-checkpoint-b710-20261114','shared-arithmetic-b711-20261114','captured-loop-ip-b712-20261114']for p in(base/name).iterdir()if p.is_file() and p.suffix in ['.tgz','.xz','.dll']],disk=subprocess.run(['df','-B1',str(base)],capture_output=True,text=True).stdout)))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True);assert done.returncode==0,done.stderr
(r/'space-inspection.json').write_text(done.stdout,encoding='utf-8',newline='\n');print(done.stdout,flush=True)
