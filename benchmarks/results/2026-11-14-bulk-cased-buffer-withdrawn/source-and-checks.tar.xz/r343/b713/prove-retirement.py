from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).parent;index=json.loads((r/'archive-index.json').read_text(encoding='utf-8'));remote={v['sha256']:v for v in index['largest']}
parents={Path(p).parent for p in(r/'canonical-hash-locations.txt').read_text(encoding='utf-8').splitlines()};matches=[];seen=set()
for parent in parents:
 for p in parent.iterdir():
  if p in seen or not p.is_file()or not p.name.endswith(('.tgz','.tar.xz')):continue
  seen.add(p);sha=hashlib.sha256(p.read_bytes()).hexdigest()
  if sha not in remote:continue
  row=remote[sha]
  if row['path'].startswith(('shared-arithmetic-b711-','captured-loop-ip-b712-','bulk-cased-buffer-b713-')):continue
  matches.append(dict(**row,canonical=p.as_posix()))
matches.sort(key=lambda v:v['allocated'],reverse=True);selected=[];freed=0
for row in matches:
 if freed>=200*1024*1024:break
 data=subprocess.check_output(['git','show','HEAD:'+row['canonical']]);assert len(data)==row['bytes']and hashlib.sha256(data).hexdigest()==row['sha256']
 selected.append(row);freed+=row['allocated']
config=json.loads((r/'config.json').read_text(encoding='utf-8'))
assert index['freeBytes']+freed>254*1024*1024+config['unpackedBytes'],(freed,len(matches))
(r/'retirement-proof.json').write_text(json.dumps(dict(canonicalFilesVerifiedAgainstCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),onlyExactCommittedArchiveReplicas=True,noCurrentImagesOrToolchains=True,selectedAllocatedBytes=freed,selected=selected),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Exact Git-committed replicas eligible:',len(matches),'selected:',len(selected),'allocated bytes:',freed,'largest:',[(v['path'],v['allocated'])for v in selected[:5]],flush=True)
