from pathlib import Path
import json
r=Path(__file__).parent
for p in sorted(r.iterdir()):
 if p.is_file():print(p.name,p.stat().st_size)
for name in ['restored-checks.json','focused-checks.json','rollback-corrected.json','b713/terminal-status.json']:
 p=r/name
 print('\n'+name+'\n'+(p.read_text(encoding='utf-8') if p.exists() else 'not yet present'))
for p in sorted(r.glob('*restored*.log')):print('\n'+p.name+'\n'+p.read_text(encoding='utf-8')[-1200:])
