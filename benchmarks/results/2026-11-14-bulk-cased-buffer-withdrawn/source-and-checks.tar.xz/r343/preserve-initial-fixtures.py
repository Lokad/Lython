from pathlib import Path
import json,shutil
r=Path(__file__).parent;out=r/'initial-fixtures';out.mkdir()
for name in ['CasedSplitOwnershipTests.cs','WordBufferLoanTests.cs','DictionaryCountingLoopAdmissionTests.cs']:shutil.copyfile(Path('tests/Lokad.Lython.Tests')/name,out/name)
(out/'explanation.json').write_text(json.dumps(dict(failed=6,passed=52,reason='Range growth formerly left idle arrays and equal capacities across casing modes. Byte-buffer sizing legitimately changes these fixture conditions. Preserve all funding, first-refusal, cancellation and retry assertions; explicitly prime needed active/idle loans, and distinguish admission refusal from cancellation after admitted capacity. No production correction or timeout relaxation.'),indent=2)+'\n',encoding='utf-8',newline='\n')
