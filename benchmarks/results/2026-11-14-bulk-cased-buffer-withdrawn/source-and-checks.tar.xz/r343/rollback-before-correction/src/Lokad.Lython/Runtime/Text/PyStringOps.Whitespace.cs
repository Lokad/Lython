using System.Buffers;
using System.Text;

namespace Lokad.Lython.Runtime.Text;

internal static partial class PyStringOps
{
    // Python 3.13's 29 whitespace scalars. Keeping this small inventory explicit
    // avoids BCL Unicode-version drift and includes Python's four C0 separators.
    internal static bool IsPythonWhitespace(Rune rune) => rune.Value <= 0x7F
        ? IsAsciiWhitespace((byte)rune.Value)
        : rune.Value is 0x85 or 0xA0 or 0x1680 or >= 0x2000 and <= 0x200A or
            0x2028 or 0x2029 or 0x202F or 0x205F or 0x3000;

    private static bool IsAsciiWhitespace(byte value)
        => value is >= 0x09 and <= 0x0D or >= 0x1C and <= 0x20;

    private static readonly SearchValues<byte> AsciiWhitespaceCharacters = CreateAsciiCharacters(whitespace: true);
    private static readonly SearchValues<byte> AsciiWordCharacters = CreateAsciiCharacters(whitespace: false);

    private static SearchValues<byte> CreateAsciiCharacters(bool whitespace)
    {
        Span<byte> characters = stackalloc byte[128];
        var count = 0;
        for (var value = 0; value < 128; value++)
            if (IsAsciiWhitespace((byte)value) == whitespace) characters[count++] = (byte)value;
        return SearchValues.Create(characters[..count]);
    }

    // The caller has classified the first (or last) ASCII byte. Stop at a
    // category change or any UTF-8 byte, leaving Unicode decoding to the caller.
    private static int AsciiWhitespaceRunLength(ReadOnlySpan<byte> chunk, bool whitespace, bool reverse = false)
    {
        var characters = whitespace ? AsciiWhitespaceCharacters : AsciiWordCharacters;
        if (reverse) return chunk.Length - 1 - chunk[..^1].LastIndexOfAnyExcept(characters);
        var boundary = chunk[1..].IndexOfAnyExcept(characters);
        return boundary < 0 ? chunk.Length : boundary + 1;
    }

    internal static PyList SplitCasedWhitespace(PyString value, bool upper,
        MemoryGovernor governor, LythonSourceSpan span, LythonRuntime.ExecutionContext context)
    {
        using var words = PrepareCasedWhitespaceIteration(value, upper, context, span);
        var bytes = PyList.EstimateCapacityBytes(words.Count);
        using var storage = governor.ReserveTemporary(bytes, span);
        context.CheckExecution(span);
        var parts = words.Count == 0 ? Array.Empty<object>() : new object[words.Count];
        for (var i = 0; i < parts.Length; i++)
        {
            context.CheckExecution(span);
            parts[i] = words.MoveNext().Value!;
        }
        var result = PyList.FromTransferredArray(parts, governor, span);
        context.CheckExecution(span);
        storage.Commit(bytes);
        return result;
    }

    // Case once into the existing owned loan. Preflight every eventual word before
    // the first loop effect; consumption scans final UTF8 without a range inventory.
    internal static CasedWhitespaceIteration PrepareCasedWhitespaceIteration(PyString value, bool upper,
        LythonRuntime.ExecutionContext context, LythonSourceSpan span)
    {
        context.CheckExecution(span);
        var mapping = upper ? CaseMapping.Upper : CaseMapping.Lower;
        var capacity = CaseOutputCapacity(value.Utf8Span, mapping, context, span);
        var prepared = context.MemoryGovernor.RentCasedWords(capacity, span);
        try
        {
            context.CheckExecution(span);
            var written = WriteCaseUtf8(value.Utf8Span, prepared.Bytes, mapping, context, span);
            var source = prepared.Bytes.AsSpan(0, written);
            var scan = new SplitScanState(source.Length, -1, false);
            var count = 0;
            long outputBytes = 0;
            while (TryReadWhitespaceRange(source, ref scan, context, span, out var range))
            {
                count = checked(count + 1);
                outputBytes = checked(outputBytes + PyString.EstimateApproximateBytes(range.End - range.Start));
            }
            context.MemoryGovernor.Reserve(outputBytes, span);
            try
            {
                context.CheckExecution(span);
                prepared.Initialize(written, count, context, span);
                context.MemoryGovernor.Commit(outputBytes);
                var result = prepared;
                prepared = null;
                return result;
            }
            catch { context.MemoryGovernor.ReleaseReserved(outputBytes); throw; }
        }
        finally { if (prepared is not null) context.MemoryGovernor.ReturnCasedWords(prepared); }
    }

    internal sealed class CasedWhitespaceIteration : ExecutableTemporaryValue
    {
        private readonly MemoryGovernor _owner;
        internal readonly byte[] Bytes;
        private LythonRuntime.ExecutionContext? _context;
        private LythonSourceSpan? _span;
        private SplitScanState _scan;
        private int _written;
        private bool _loaned = true;
        internal int Count { get; private set; }
        internal static long EstimateStorageBytes(int capacity) => checked(160L + capacity);
        internal long StorageBytes => EstimateStorageBytes(Bytes.Length);

        internal CasedWhitespaceIteration(MemoryGovernor owner, int capacity)
        {
            _owner = owner;
            Bytes = capacity == 0 ? [] : new byte[capacity];
        }

        internal void BeginLoan() => _loaned = true;

        internal bool EndLoan()
        {
            if (!_loaned) return false;
            _loaned = false;
            _context = null;
            _span = null;
            _written = Count = 0;
            _scan = default;
            return true;
        }

        internal void Initialize(int written, int count, LythonRuntime.ExecutionContext context, LythonSourceSpan span)
        {
            _written = written;
            Count = count;
            _context = context;
            _span = span;
            _scan = new SplitScanState(written, -1, false);
        }

        internal PyIterationResult MoveNext()
        {
            if (!TryReadWhitespaceRange(Bytes.AsSpan(0, _written), ref _scan, _context, _span, out var range))
                return PyIterationResult.End;
            return PyIterationResult.Yield(CreateSplitFragment(Bytes, range, _owner, _span, _context));
        }

        internal MemoryGovernor MemoryGovernor => _owner;

        // This view stays within the loan's active native segment. Publish the
        // final Python binding before returning/reusing the buffer, including unwind.
        internal bool TryReadWord(out CompactWord word)
        {
            word = default;
            if (!TryReadWhitespaceRange(Bytes.AsSpan(0, _written), ref _scan, _context, _span, out var range)) return false;
            word.Utf8 = Bytes.AsMemory(range.Start, range.End - range.Start);
            if (word.Utf8.Length > PyString.InlineUtf8Capacity)
                word.Value = CreateSplitFragment(Bytes, range, _owner, _span, _context);
            return true;
        }

        // All words are already funded. No admission or check may replace a
        // pending failure while the last private binding is published during unwind.
        internal object Materialize(ref CompactWord word)
        {
            if (word.Value is not null) return word.Value;
            var value = PyString.CreateReservedUtf8(word.Utf8.Length, _owner);
            word.Utf8.Span.CopyTo(value.UnpublishedUtf8);
            value.CompleteUnpublishedUtf8(word.Utf8.Length);
            word.Value = value;
            return value;
        }

        public override void Dispose() => _owner.ReturnCasedWords(this);
    }

    internal struct CompactWord
    {
        internal object? Value;
        internal ReadOnlyMemory<byte> Utf8;
    }

    internal static ReadOnlySpan<byte> CompactWordBytes(ref CompactWord word) => word.Utf8.Span;

    private static PyList SplitCore(PyString value, int maxSplit, bool reverse,
        MemoryGovernor? governor, LythonSourceSpan? span, LythonRuntime.ExecutionContext? context,
        PyString? separator = null)
    {
        governor ??= value.OwnerMemoryGovernor;
        span ??= PyStructuralGuard.AmbientSpan;
        context ??= PyStructuralGuard.AmbientContext;
        governor?.ThrowIfAdmissionFailed();
        context?.CheckExecution(span);
        if (separator is { ByteLength: 0 }) throw new InvalidOperationException("empty separator");
        var source = value.Utf8Span;
        var scan = new SplitScanState(source.Length, maxSplit, reverse);
        var count = 0;
        long outputBytes = 0;
        (int Start, int End) onlyRange = default;
        while (TryReadSplitRange(source, separator, reverse, ref scan, context, span, out var range))
        {
            onlyRange = range;
            count = checked(count + 1);
            if (range.End != range.Start)
                outputBytes = checked(outputBytes + PyString.EstimateApproximateBytes(range.End - range.Start));
        }
        var reuseWhole = count == 1 && onlyRange.Start == 0 && onlyRange.End == source.Length
            && ReferenceEquals(governor, value.OwnerMemoryGovernor);
        if (reuseWhole && source.Length != 0) outputBytes -= PyString.EstimateApproximateBytes(source.Length);
        var resultBytes = checked(outputBytes + PyList.EstimateCapacityBytes(count));
        using var output = governor?.ReserveTemporary(resultBytes, span);
        context?.CheckExecution(span);
        var parts = count == 0 ? Array.Empty<object>() : new object[count];
        scan = new SplitScanState(source.Length, maxSplit, reverse);
        for (var index = 0; index < count; index++)
        {
            context?.CheckExecution(span);
            if (!TryReadSplitRange(source, separator, reverse, ref scan, context, span, out var range))
                throw new InvalidOperationException("An immutable split source changed its ranges.");
            parts[reverse ? count - index - 1 : index] = reuseWhole ? value
                : CreateSplitFragment(source, range, governor, span, context);
        }
        var result = PyList.FromTransferredArray(parts, governor, span);
        context?.CheckExecution(span);
        output?.Commit(resultBytes);
        return result;
    }

    private static PyString CreateSplitFragment(ReadOnlySpan<byte> source, (int Start, int End) range,
        MemoryGovernor? governor, LythonSourceSpan? span, LythonRuntime.ExecutionContext? context)
    {
        var length = range.End - range.Start;
        if (length == 0) return PyString.Empty;
        var fragment = PyString.CreateReservedUtf8(length, governor);
        for (var copied = 0; copied < length;)
        {
            context?.CheckExecution(span);
            var chunk = Math.Min(4096, length - copied);
            source.Slice(range.Start + copied, chunk).CopyTo(fragment.UnpublishedUtf8.Slice(copied, chunk));
            copied += chunk;
        }
        fragment.CompleteUnpublishedUtf8(length);
        return fragment;
    }

    // Only offsets survive a scan step; no source span or boundary inventory.
    private struct SplitScanState(int length, int maxSplit, bool reverse)
    {
        internal int Position = reverse ? length : 0;
        internal int NextCheck = reverse ? length : 0;
        internal int Remaining = maxSplit < 0 ? int.MaxValue : maxSplit;
        internal bool Finished;
    }

    private static bool TryReadSplitRange(ReadOnlySpan<byte> source, PyString? separator, bool reverse,
        ref SplitScanState state, LythonRuntime.ExecutionContext? context, LythonSourceSpan? span,
        out (int Start, int End) range)
    {
        if (separator is null) return reverse
            ? TryReadWhitespaceReverse(source, ref state, context, span, out range)
            : TryReadWhitespaceRange(source, ref state, context, span, out range);
        range = default;
        if (state.Finished) return false;
        if (state.Remaining != 0)
        {
            var remaining = reverse ? source[..state.Position] : source[state.Position..];
            var found = LythonRuntime.FindBytes(remaining, separator.Utf8Span, context, span, reverse);
            if (found >= 0)
            {
                if (!reverse) found += state.Position;
                range = reverse ? (found + separator.ByteLength, state.Position) : (state.Position, found);
                state.Position = reverse ? found : found + separator.ByteLength;
                state.Remaining--;
                return true;
            }
        }
        state.Finished = true;
        range = reverse ? (0, state.Position) : (state.Position, source.Length);
        return true;
    }

    private static bool TryReadWhitespaceRange(ReadOnlySpan<byte> source, ref SplitScanState state,
        LythonRuntime.ExecutionContext? context, LythonSourceSpan? span, out (int Start, int End) range)
    {
        var start = -1;
        while (state.Position < source.Length)
        {
            if (state.Position >= state.NextCheck)
            {
                context?.CheckExecution(span);
                state.NextCheck = state.Position + Math.Min(64, source.Length - state.Position);
            }
            var position = state.Position;
            int width;
            bool whitespace;
            if (source[position] < 0x80)
            {
                whitespace = IsAsciiWhitespace(source[position]);
                width = AsciiWhitespaceRunLength(source[position..state.NextCheck], whitespace);
            }
            else
            {
                Rune.DecodeFromUtf8(source[position..], out var rune, out width);
                whitespace = IsPythonWhitespace(rune);
            }
            if (whitespace)
            {
                if (start >= 0)
                {
                    state.Position += width;
                    state.Remaining--;
                    range = (start, position);
                    return true;
                }
            }
            else if (start < 0)
            {
                start = position;
                if (state.Remaining == 0)
                {
                    state.Position = source.Length;
                    range = (start, source.Length);
                    return true;
                }
            }
            state.Position += width;
        }
        range = (start, source.Length);
        return start >= 0;
    }

    private static bool TryReadWhitespaceReverse(ReadOnlySpan<byte> source, ref SplitScanState state,
        LythonRuntime.ExecutionContext? context, LythonSourceSpan? span, out (int Start, int End) range)
    {
        var end = -1;
        while (state.Position > 0)
        {
            if (state.Position <= state.NextCheck)
            {
                context?.CheckExecution(span);
                state.NextCheck = Math.Max(0, state.Position - 64);
            }
            var position = state.Position;
            int width;
            bool whitespace;
            if (source[position - 1] < 0x80)
            {
                whitespace = IsAsciiWhitespace(source[position - 1]);
                width = AsciiWhitespaceRunLength(source[state.NextCheck..position], whitespace, true);
            }
            else
            {
                Rune.DecodeLastFromUtf8(source[..position], out var rune, out width);
                whitespace = IsPythonWhitespace(rune);
            }
            if (whitespace)
            {
                if (end >= 0)
                {
                    state.Position -= width;
                    state.Remaining--;
                    range = (position, end);
                    return true;
                }
            }
            else if (end < 0)
            {
                end = position;
                if (state.Remaining == 0)
                {
                    state.Position = 0;
                    range = (0, end);
                    return true;
                }
            }
            state.Position -= width;
        }
        range = (0, end);
        return end >= 0;
    }
}
