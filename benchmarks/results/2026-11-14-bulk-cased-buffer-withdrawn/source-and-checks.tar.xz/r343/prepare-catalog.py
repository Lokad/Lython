from pathlib import Path
import base64,copy,hashlib,json,shutil,subprocess,tempfile
r=Path(__file__).parent;old=json.loads((r.parent/'native-owned-slots-r339/b710/catalog.json').read_text(encoding='utf-8'))
selected=['scripts.text-summary-helpers.nonlocal-counter.large','scripts.csv-fulfillment.large']
index={c['id']:c for c in old['cases']}
if not all(k in index for k in selected):
 print('Available text scripts:',[k for k in index if 'text-summary'in k]);raise RuntimeError('Select an existing complete ordinary text source before measurement.')
captured=index[selected[0]];inline=copy.deepcopy(captured);source=inline['source']
a=source.index('    processed=0\n');b=source.index('    counts = {}',a);source=source[:a]+source[b:]
source=source.replace('words_from_line(line)','line.lower().split()').replace('    assert processed == 3072\n','')
assert 'processed'not in source and 'words_from_line'not in source
fixture=json.loads(inline['fixtureJson'])
with tempfile.TemporaryDirectory(prefix='inline-text-control-',dir=r.resolve())as folder:
 work=Path(folder).resolve();assert work.parent==r.resolve()
 for name,data in fixture['inputFiles'].items():(work/name).write_bytes(base64.b64decode(data))
 done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],cwd=work,capture_output=True,text=True,encoding='utf-8',timeout=15)
 assert done.returncode==0 and not done.stderr and done.stdout==inline['expectedOutput'],done.stderr
 assert all((work/name).read_bytes()==base64.b64decode(data)for name,data in fixture['outputFiles'].items())
inline.update(id='scripts.text-summary.inline.large',source=source,sourceUtf8Bytes=len(source.encode()),sourceSha256=hashlib.sha256(source.encode()).hexdigest())
old['cases']=[captured,inline,index[selected[1]]];(r/'catalog.json').write_text(json.dumps(old,separators=(',',':'),ensure_ascii=False)+'\n',encoding='utf-8',newline='\n');(r/'inline-text.py').write_text(source,encoding='utf-8',newline='\n')
(r/'workload-python-controls.json').write_text(json.dumps(dict(reference='CPython3.13.2 isolated',case=inline['id'],sourceSHA256=inline['sourceSha256'],fixtureSHA256=inline['fixtureSha256'],exactCapturedFixtureAndGoldensReused=True,sameSourceAcrossRevisions=True),indent=2)+'\n',encoding='utf-8',newline='\n')
(r/'catalog-correction.json').write_text(json.dumps(dict(initialFailure='The B710catalog has only the captured text variant; the requested ordinary helper ID was absent. No worker/image/VM collection was launched.',correction='Inline the existing lower/split expression, remove the nonlocal processed-only helper, and independently verify identical stdout/report under isolated Python. Keep source/fixtures/goldens identical across measured revisions.'),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Existing captured/fulfillment controls plus independently verified direct-inline text source prepared.',flush=True)
