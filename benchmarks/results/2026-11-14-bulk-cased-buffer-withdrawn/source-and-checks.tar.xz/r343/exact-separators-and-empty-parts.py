for value in ['', '::', '::α::β::', 'αééβéé', 'aaa', 'a😀b😀', '  ']:
    for separator in ['::','éé','aa','😀',' ']:
        for limit in [-2,-1,0,1,2,4]:
            print(repr(value),repr(separator),limit,value.split(separator,limit),value.rsplit(separator,limit))
