def words(value): return value.upper().split()
saved=[]
for outer in words('αß café first'):
    for inner in words(' '.join(['ßΣ']*97)):
        if len(saved)<6: saved.append((outer,inner))
    saved.append(outer)
print(saved)
value='  '+'  '.join(['AßΣ']*97)+'  '
print(len(value.split()),len(value.rsplit()),value.split(None,1)[0],value.rsplit(None,1)[-1])
