from pathlib import Path
import json,os,shutil,subprocess
r=Path(__file__).parent;before=r/'before-rollback-correction';before.mkdir()
for name in ['focused-checks.json']+[assembly+'-'+target+'.log'for assembly in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']for target in ['net11.0','net10.0']]:shutil.move(str(r/name),str(before/name))
s=(r/'check-related.py').read_text(encoding='utf-8').replace("'FullyQualifiedName~Split|FullyQualifiedName~StringMethod", "'FullyQualifiedName~StringWindowOwnership|FullyQualifiedName~WhitespaceStorageOwnership|FullyQualifiedName~NativeTextConstructionRollback|FullyQualifiedName~Split|FullyQualifiedName~StringMethod")
(r/'check-related-corrected.py').write_text(s,encoding='utf-8',newline='\n')
done=subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'check-related-corrected.py')],timeout=900);assert done.returncode==0
env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';'+env['PATH'];rows=[]
for target in ['net11.0','net10.0']:
 log=r/('rollback-corrected-'+target+'.log')
 with log.open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f',target,'--no-build','--filter','FullyQualifiedName~NativeTextConstructionRollback','--logger','trx','--results-directory',str((r/('rollback-corrected-'+target)).resolve())],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 print(target,done.returncode,log.read_text(encoding='utf-8')[-2200:],flush=True);rows.append(dict(target=target,returncode=done.returncode,original64MiBScalesPreserved=True));(r/'rollback-corrected.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n');assert done.returncode==0
