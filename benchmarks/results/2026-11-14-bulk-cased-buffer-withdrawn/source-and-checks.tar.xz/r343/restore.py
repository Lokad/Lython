from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;candidate=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));reference=json.loads((r/'reference-identity.json').read_text(encoding='utf-8'))
assert json.loads((r/'b713/terminal-status.json').read_text(encoding='utf-8'))['exitCode']=='0'
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in candidate['sources'].items())
out=r/'candidate-tests';out.mkdir()
tests=['CasedSplitOwnershipTests.cs','DictionaryCountingLoopAdmissionTests.cs','WordBufferLoanTests.cs','NativeTextConstructionRollbackTests.cs','StringWindowOwnershipTests.cs','WhitespaceSplitCancellationTests.cs','WhitespaceStorageOwnershipTests.cs']
for name in tests:shutil.copyfile(Path('tests/Lokad.Lython.Tests')/name,out/name)
with tarfile.open(r/'reference-sources.tar.xz')as t:
 for name in candidate['changedProductionInputs']:
  data=t.extractfile(name).read();assert hashlib.sha256(data).hexdigest()==reference['sources'][name];Path(name).write_bytes(data)
for name in tests:
 path='tests/Lokad.Lython.Tests/'+name;Path(path).write_bytes(subprocess.check_output(['git','show','HEAD:'+path]))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in reference['sources'].items())
(r/'restoration.json').write_text(json.dumps(dict(all581ProductionInputsRestoredExactlyToQualified53=True,restoredProductionInputs=candidate['changedProductionInputs'],candidateCorePreserved=candidate['coreSHA256']['candidate'],newPublicSemanticRegressionsRetained=True,prototypeSpecificInternalFixtureChangesRemoved=True,publicRollbackGuaranteePreservedByOriginalTemporaryConstruction=True,forcedNonincrementalBuildRequiredBeforeChecks=True),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Exact qualified production bytes restored; prototype mechanisms removed, useful public semantic regressions retained. Fresh build required.',flush=True)
