from pathlib import Path
import os,subprocess
r=Path(__file__).parent;env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';'+env['PATH']
with(r/'rollback-initial.log').open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f','net11.0','--no-build','--filter','FullyQualifiedName~NativeTextConstructionRollback','--logger','trx','--results-directory',str((r/'rollback-initial').resolve())],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
print(done.returncode,(r/'rollback-initial.log').read_text(encoding='utf-8')[-6000:],flush=True)
