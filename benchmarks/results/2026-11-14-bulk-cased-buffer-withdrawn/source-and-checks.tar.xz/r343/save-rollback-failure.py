from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).parent;out=r/'rollback-before-correction';out.mkdir()
names=['src/Lokad.Lython/Runtime/MemoryGovernor.cs','src/Lokad.Lython/Runtime/Text/PyStringOps.Whitespace.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.CasedSplits.cs','tests/Lokad.Lython.Tests/WhitespaceStorageOwnershipTests.cs','tests/Lokad.Lython.Tests/NativeTextConstructionRollbackTests.cs']
for name in names:
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(name,p)
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',out/'core.dll')
(out/'prototype.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython']))
(out/'correction.json').write_text(json.dumps(dict(actualRegression='Original64MiB cased-construction cancellation test fails: committed bytes67108994expected vs134218020actual. Other two construction cases pass.',cause='Public eager split reused the private cursor preparation that commits future words and returns failed scratch to its cache. Public construction must keep final output temporary until publication and discard exclusive failed scratch.',correction='Share bulk casing/sizing inside the cursor; keep private future-word commitment, but use one temporary complete-output reservation and explicit scratch discard on public failure. Preserve original assertion, cancellation scales, input ownership and joined canceller.',sourceSHA256={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in names},coreSHA256=hashlib.sha256((out/'core.dll').read_bytes()).hexdigest()),indent=2)+'\n',encoding='utf-8',newline='\n')
