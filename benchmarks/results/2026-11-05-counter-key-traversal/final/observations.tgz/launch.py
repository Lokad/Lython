from pathlib import Path
import tarfile,subprocess
root=Path("/home/lokad/lython-bench-checks/counter-keys-final-b302-20261105");root.mkdir(exist_ok=False)
with tarfile.open('/home/lokad/lython-bench-checks/b302-payload.tgz') as archive:archive.extractall(root,filter='data')
subprocess.run(['python3',str(root/'setup.py')],check=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b302-counter-keys-final-20261105','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=120','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
