Focused186public/104internal per actual11/10, zero-warning/error build. Full preceding source f66427f1 GREEN/all8 cached42113971859, not current Counter changes. Native builtin-key Counter results are equivalent; incorrect callback baselines excluded from performance claims.
Source/core frozen after focused checks; no executable changes during collection.
