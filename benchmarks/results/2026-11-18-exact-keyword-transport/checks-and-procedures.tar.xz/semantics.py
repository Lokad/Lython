key = ''.join(['dé', 'but'])

def mutate(label, **kwargs):
    result = list(kwargs)
    print(label, result, result[0] is key)
    kwargs[key] = 99
    return kwargs

class Receiver:
    def accept(self, label, **kwargs):
        return mutate(label, **kwargs)

source = {key: 1, 'tail': 2}
print(mutate('free', **source), source)
accept = Receiver().accept
print(accept('bound', **source), source)

def note(kind, callback):
    try:
        callback()
    except TypeError as error:
        print(kind, 'keywords must be strings' in str(error))

note('bad key before arity', lambda: mutate('extra', 'operand', **{1: 2}))
note('bad key before duplicate', lambda: mutate('duplicate', **{'label': 1, 2: 3}))

def change_mapping():
    source[key] = 42
    return False

print(mutate('earlier expansion', **source, flag=change_mapping()), source)
