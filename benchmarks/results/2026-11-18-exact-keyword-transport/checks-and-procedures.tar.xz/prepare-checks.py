from pathlib import Path
import hashlib
import json

lab = Path(__file__).resolve().parent
previous = lab.parent / 'executable-definition-inputs-r578'
catalog = json.loads((previous / 'catalog.json').read_text(encoding='utf-8'))
forwarding = next(case for case in catalog['cases'] if case['id'] == 'scripts.report-forwarding.expanded')
sha = lambda value: hashlib.sha256(value.encode('utf-8')).hexdigest()
source = '''class Column:
    def apply(self, label, **fields):
        fields['count'] += label
        return fields

apply = Column().apply
original = ''.join(['dé', 'but'])
row = {original: 'α', 'count': 5, 'priority': 3, 'owner': 'ops', 'service': 'api', 'state': 'ready'}
total = 0
for index in range(1024):
    row['count'] = index
    adjusted = apply(index, **row)
    assert row['count'] == index and next(iter(adjusted)) is original
    total += adjusted['count'] + adjusted['priority']
print(total, row['count'])
'''
expected = f'{sum(2 * i + 3 for i in range(1024))} 1023\n'
case = dict(forwarding, id='scripts.report-forwarding.mutable-bound', source=source,
            sourceUtf8Bytes=len(source.encode('utf-8')), sourceSha256=sha(source), expectedOutput=expected,
            expectedOutputUtf8Bytes=len(expected.encode('utf-8')), expectedOutputSha256=sha(expected))
case.pop('expectedFilesSha256', None)
case.pop('fixtureJson', None)
case.pop('fixtureSha256', None)
fixture = json.dumps({'size': case['size'], 'text': None}, separators=(',', ':'))
case.update(fixtureJson=fixture, fixtureSha256=sha(fixture), fixtureTextUtf8Bytes=0, fixtureTextCodePoints=0)
keep = {'calls.positional.large', 'scripts.report-forwarding.expanded', 'scripts.rule-default-closures'}
catalog['cases'] = [c for c in catalog['cases'] if c['id'] in keep] + [case]
assert len(catalog['cases']) == 4
(lab / 'catalog.json').write_text(json.dumps(catalog, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
template = (previous / 'verify-pair.py').read_text(encoding='utf-8')
template = template.replace("lab.parent / 'direct-function-defaults-r575'", "lab.parent / 'executable-definition-inputs-r578'")
template = template.replace('executable-definition-inputs-r578\'\nsdk', 'exact-keyword-transport-r579\'\nsdk')
template = template.replace("startswith('6c4cb50a')", "startswith('64fd18de')")
template = template.replace("shutil.copyfile(previous / 'catalog.json', catalog)\nassert sha(catalog) == load(previous / 'frozen-identity.json')['casesSHA256']", '')
template = template.replace("referenceCommit='53df08565', candidateBase='7fe127123'", "referenceCommit='2783d3d7f', candidateBase='2783d3d7f'")
assert "work = repo / '.git/agent-worktrees/exact-keyword-transport-r579'" in template
compile(template, 'verify-pair.py', 'exec')
(lab / 'verify-pair.py').write_text(template, encoding='utf-8')
