from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
quiet = lab / 'quiet'
out = Path('benchmarks/results/2026-11-18-exact-keyword-transport')
base = '2783d3d7f08bff4d83d51fa7b1898266b43f01ff'
candidate = '1e7f1d52615d8d1bf5534b59e28a59c92563b353'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
terminal, receipt = [load(quiet / f'{file}.json') for file in ('terminal-status', 'archive-receipt')]
assert terminal['receipt'] == receipt and terminal['exitCode'] == '0'
assert not terminal['remainingWorkers'] and not terminal['remainingTrace']
assert all(receipt[field] for field in ['complete','allWorkersJoined','guestFixturesRemoved',
                                      'quietBeforeAndAfter','archivedAndVerifiedUnderLease'])
assert receipt['jobs'] == 5 and receipt['archiveSHA256'] == sha(quiet / 'observations.tgz')
identity = load(quiet / 'identity.json')
catalog = load(lab / 'catalog.json')
assert sha(lab / 'catalog.json') == identity['catalogSHA256']
cases = {case['id']: case for case in catalog['cases']}
raw = load(quiet / 'retrieved/confirmation/confirmation.json')
assert raw['complete'] and len(raw['jobs']) == 5
for job in raw['jobs']:
    case = cases[job['case']]
    assert job['workersJoinedAndFixturesRemoved'] and len(job['samples']) == 20
    assert set(job['identities']) == set(identity['coreSHA256'])
    for engine, info in job['identities'].items():
        native = next(lib for lib in info['libraries'] if Path(lib['path']).name == 'Lokad.Lython.dll')
        assert native['sha256'].lower() == identity['coreSHA256'][engine]
    for sample in job['samples']:
        response = sample['response']
        assert response['status'] == 'Completed' and response['completedInvocations'] > 0
        assert response['sourceSha256'] == case['sourceSha256'] and response['fixtureSha256'] == case['fixtureSha256']
        expected = case['expectedOutputSha256'] if job['lane'] != 'compile' else None
        assert response.get('actualOutputSha256') == expected
        expected = case.get('expectedFilesSha256') if job['lane'] != 'compile' else None
        assert response.get('actualFilesSha256') == expected
out.mkdir(exist_ok=True)
summary = load(lab / 'quiet-summary.json')
summary.update(referenceRuntime='2783d3d7f', candidateBase=base, measuredPrototype=candidate,
               cores=identity['coreSHA256'], archiveSHA256=receipt['archiveSHA256'])
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8', newline='\n')
for name in ['observations.tgz','archive-receipt.json','terminal-status.json']:
    shutil.copyfile(quiet / name, out / name)
diff = subprocess.check_output(['git','diff','--binary',base,candidate,'--','src','tests'])
assert b'CopyExpandedKeywords' in diff and b'TrailingExactKeywordsKeepAdmissionAtomic' in diff
(lab / 'measured-source.patch').write_bytes(diff)
test_commit = (lab / 'cancellation-test-commit.txt').read_text(encoding='utf-8-sig').strip()
assert subprocess.check_output(['git', 'diff', '--name-only', candidate, test_commit]).decode().splitlines() == [
    'tests/Lokad.Lython.PublicApi.Tests/ExpandedCallExecutionTests.cs']
test_patch = subprocess.check_output(['git', 'diff', '--binary', candidate, test_commit, '--', 'tests'])
(lab / 'post-freeze-cancellation-test.patch').write_bytes(test_patch)
with tarfile.open(out / 'checks-and-procedures.tar.xz','w:xz',preset=6) as archive:
    for name in ['measured-source.patch','verify-pair.py','prepare-checks.py','reference-verify.json',
                 'candidate-verify.json','reference-allocation.json','candidate-allocation.json',
                 'reference-invalid-fixture.log','catalog-invalid-fixture.json','quiet-space.json','prepare-quiet.py',
                 'stage-quiet.py','launch-quiet.py','archive-b1005.py','summarize-quiet.py','first-win-net11.log',
                 'reentry-win-net11.log','reentry-corrected-win-net11.log','focused-wsl-net10.log','freeze-build.log',
                 'semantics.py','sync.json','async.json','candidate-sync.json','candidate-async.json',
                 'suspended-keyword-win-net11.log','post-freeze-cancellation-test.patch']:
        archive.add(lab / name, arcname=name)
    for name in ['config.json','preflight.json','launch.log','retrieve.py','observe-not-before.json']:
        archive.add(quiet / name, arcname='quiet/' + name)
print('Verified B1005 against both hashes, all 100 golden responses, and the measured source patch.')
