from pathlib import Path
import gzip
import hashlib
import json
import subprocess

lab = Path(__file__).resolve().parent
previous = lab.parent / 'executable-definition-inputs-r578'
read = lambda p: p.read_text(encoding='utf-8')
load = lambda p: json.loads(read(p))
sha = lambda data: hashlib.sha256(data).hexdigest()
prior = load(previous / 'quiet-space.json')
proof = next(p for p in prior['replicas'] if p['sha256'].startswith('c0367d98'))
canonical = proof['canonical']
archived = subprocess.check_output(['git', 'show', f'origin/master:{canonical}'])
assert archived == Path(canonical).read_bytes() and sha(archived) == proof['canonicalSHA256']
raw = gzip.decompress(archived)
assert sha(raw) == proof['sha256'] and len(raw) == proof['bytes']
remote = r'''
from pathlib import Path
import fcntl, hashlib, json, os, shutil, stat, subprocess
root = Path('/home/lokad/lython-bench-checks').resolve()
assert root == Path('/home/lokad/lython-bench-checks')
proof = PROOF
with (root / 'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert not subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.13.*cpython-worker.py'], capture_output=True).stdout
    assert not any(os.path.ismount(p) for p in root.glob('*/guest-fixtures'))
    identities = set()
    for name in proof['paths']:
        path = root / name
        info = path.lstat()
        assert path.resolve() == path and path.is_relative_to(root) and stat.S_ISREG(info.st_mode)
        assert info.st_uid == os.getuid() and info.st_nlink == proof['links'] and info.st_size == proof['bytes']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == proof['sha256']
        identities.add((info.st_dev, info.st_ino))
    assert len(identities) == 1 and len(proof['paths']) == proof['links']
    print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free, replicas=[proof])))
'''.replace('PROOF', repr(proof))
ssh = ['C:/Windows/System32/OpenSSH/ssh.exe', '-i', str(Path.home() / '.ssh/id_lython-bench.pem'),
       '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15', 'lokad@20.166.121.73']
space = subprocess.check_output(ssh + ['python3 -'], input=remote.encode(), timeout=30)
assert load(previous / 'quiet/terminal-status.json')['receipt']['complete']
assert json.loads(space)['replicas'] == [proof]
(lab / 'quiet-space.json').write_bytes(space)

stage = read(previous / 'stage-quiet.py')
stage = stage.replace('donor=lab.parent/"direct-function-defaults-r575"','donor=lab.parent/"executable-definition-inputs-r578"')
stage = stage.replace('53df08565 versus executable definition inputs candidate on 7fe127123', '2783d3d7f versus exact keyword transport candidate')
stage = stage.replace('R578 executable function definition inputs', 'R579 exact keyword transport into final kwargs')
stage = stage.replace('root="/home/lokad/lython-bench-checks/executable-definition-inputs-b1004-20261118"',
                      'root="/home/lokad/lython-bench-checks/exact-keyword-transport-b1005-20261118"')
stage = stage.replace('lython-b1004-executable-definition-inputs-20261118', 'lython-b1005-exact-keyword-transport-20261118')
stage = stage.replace('target="scripts.rule-default-closures"', 'target="scripts.report-forwarding.expanded"')
stage = stage.replace('("calls.defaults.medium","warm")', '("scripts.report-forwarding.mutable-bound","warm")')
stage = stage.replace('"Executable definition inputs source pair","Executable definition inputs source pair"',
                      '"Executable definition inputs source pair","Exact keyword transport source pair"')
stage = stage.replace('lython-b1001-fixtures","lython-b1004-fixtures', 'lython-b1004-fixtures","lython-b1005-fixtures')
stage = stage.replace('"seconds=250","seconds=270"', '"seconds=270","seconds=280"')
stage = stage.replace('"before 250 seconds","before 270 seconds"', '"before 270 seconds","before 280 seconds"')
assert 'b1005' in stage and 'mutable-bound' in stage
(lab / 'stage-quiet.py').write_text(stage, encoding='utf-8', newline='\n')
compile(stage, 'stage-quiet.py', 'exec')
