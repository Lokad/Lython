from pathlib import Path
import hashlib
import json
import os
import subprocess

lab = Path(__file__).resolve().parent
repo = Path.cwd()
calls = lab.parent / "direct-function-defaults-r575"
standard = lab.parent / "representative-cpython-r567/representative.json"
read = lambda path: json.loads(path.read_text(encoding="utf-8"))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
catalog = read(standard)
selected = {case["id"]: case for case in catalog["cases"]}
case = next(c for c in read(calls / "catalog.json")["cases"] if c["id"] == "scripts.rule-default-closures")
catalog["cases"].append(case)
assert len(catalog["cases"]) == 5
path = lab / "representative.json"
path.write_text(json.dumps(catalog, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
frozen = calls / "frozen/candidate"
manifest = read(calls / "frozen-identity.json")["images"]["candidate"]
assert len(manifest) == 32 and {name: sha(frozen / name) for name in manifest} == manifest
assert manifest["Lokad.Lython.dll"].startswith("6c4cb50a")
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk),
           PATH=str(sdk) + os.pathsep + os.environ["PATH"])
with (lab / "verify.log").open("w", encoding="utf-8") as target:
    subprocess.run([dotnet, frozen / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog", path,
                    "--dotnet", dotnet, "--python", "C:/Python313/python.exe", "--python-worker",
                    repo / "benchmarks/cpython-worker.py", "--out", lab / "verify.json"],
                   env=env, cwd=repo, stdout=target, stderr=subprocess.STDOUT, check=True, timeout=70)
assert read(lab / "verify.json")["state"] == "Completed"
print("Both actual workers verified all five selected workloads for the retained source", sha(path))
