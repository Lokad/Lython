from pathlib import Path
import gzip, hashlib, io, json, subprocess, tarfile

lab = Path(__file__).resolve().parent
sha = lambda data: hashlib.sha256(data).hexdigest()
def from_origin(path):
    data = subprocess.check_output(["git","show",f"origin/master:{path}"])
    assert data == Path(path).read_bytes()
    return data

cores = []
for folder, digest, aliases in [
    ("borrowed-format-packet", "334f106b2ae9d72419483611619835ca8c5134bcda237a1b580ef360e4136bbe", [
         "borrowed-format-packet-b999-20261118/candidate/Lokad.Lython.dll",
         "borrowed-format-control-b1000-20261118/candidate/Lokad.Lython.dll",
         "direct-function-defaults-b1001-20261118/reference/Lokad.Lython.dll"]),
]:
    path = f"benchmarks/results/2026-11-18-{folder}/candidate-core.dll.gz"
    packed = from_origin(path)
    raw = gzip.decompress(packed)
    assert sha(raw) == digest
    cores.append(dict(paths=aliases,canonical=path,canonicalSHA256=sha(packed),sha256=digest,bytes=len(raw),
                      links=len(aliases),kind="exact archived measured core replica",committedBlobVerified=True))

proofs=[]

remote=r"""
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
root=Path('/home/lokad/lython-bench-checks').resolve()
assert root==Path('/home/lokad/lython-bench-checks')
cores=CORES
with (root/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert not subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.13.*cpython-worker.py'],capture_output=True).stdout
    assert not any(os.path.ismount(p) for p in root.glob('*/guest-fixtures'))
    def verify(p,proof):
        v=p.lstat()
        assert p.resolve()==p and p.is_relative_to(root) and stat.S_ISREG(v.st_mode)
        assert v.st_uid==os.getuid() and v.st_size==proof['bytes'] and v.st_nlink==proof['links']
        assert hashlib.sha256(p.read_bytes()).hexdigest()==proof['sha256']
        return v
    identities={}
    for proof in cores:
        records=[verify(root/p,proof) for p in proof['paths']]
        dev_inode={(x.st_dev,x.st_ino) for x in records}
        assert len(dev_inode)==1
        identities[next(iter(dev_inode))]=[]
    for directory,_,names in os.walk(root):
        for name in names:
            p=Path(directory)/name
            v=p.lstat()
            identity=(v.st_dev,v.st_ino)
            if identity in identities:
                identities[identity].append(p.relative_to(root).as_posix())
    assert sorted(sorted(p) for p in identities.values())==sorted(sorted(p['paths']) for p in cores)
    verified=list(cores)
    for proof in PROOFS:
        path=root/proof['paths'][0]
        if path.exists():
            verify(path,proof)
            verified.append(proof)
    print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free,replicas=verified)))
""".replace("CORES",repr(cores)).replace("PROOFS",repr(proofs))
ssh=["C:/Windows/System32/OpenSSH/ssh.exe","-i",str(Path.home()/".ssh/id_lython-bench.pem"),
     "-o","BatchMode=yes","-o","ConnectTimeout=15","lokad@20.166.121.73"]
response=subprocess.run(ssh+["python3 -"],input=remote.encode(),capture_output=True,check=True,timeout=45)
space=json.loads(response.stdout)
(lab/"quiet-space.json").write_text(json.dumps(space,indent=2)+"\n",encoding="utf-8")
print(space["freeBytes"],"bytes free;",len(space["replicas"]),"exact replicas verified")
