from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess
lab=Path('.git/agent-notes/review-20261031/frontend-regex-capture-storage-20261123')
identity=json.loads((lab/'comparison/identity.json').read_text(encoding='utf-8'))
binary=lab/'allocation/build/bin/RegexCompileAllocation/release'
dotnet=Path.home()/'.dotnet11/dotnet.exe'
output={}
for role, files in reversed(list(identity['imageFiles'].items())):
    image=lab/role
    assert all(hashlib.sha256((image/name).read_bytes()).hexdigest()==sha for name,sha in files.items())
    for name in ('RegexCompileAllocation.dll','RegexCompileAllocation.deps.json','RegexCompileAllocation.runtimeconfig.json'):
        shutil.copyfile(binary/name,image/name)
    raw=subprocess.check_output([dotnet,image/'RegexCompileAllocation.dll',lab/'representative.json'],timeout=65,
                                env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_TieredCompilation='0'))
    (lab/(role+'-compilation-no-tiering.json')).write_bytes(raw)
    data=json.loads(raw)
    assert data['coreSha256']==files['Lokad.Lython.dll']
    output[role]=data['rows']
summary=[]
for a,b in zip(output['reference'],output['candidate'],strict=True):
    assert a['id']==b['id']
    summary.append(dict(case=a['id'],referenceBytes=statistics.median(a['bytes']),candidateBytes=statistics.median(b['bytes'])))
for row in summary:
    print(row)
(lab/'summary-no-tiering.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
