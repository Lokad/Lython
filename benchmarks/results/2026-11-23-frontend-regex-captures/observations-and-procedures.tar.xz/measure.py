from pathlib import Path
import json, os, shutil, subprocess, tarfile, statistics
lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.parent/'fixed-tuple-admission-20261123'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
write=lambda p,t:p.write_text(t,encoding='utf-8',newline='\n')
with tarfile.open(repo/'benchmarks/results/2026-11-23-deferred-regex-coordinates-slots/observations.tgz') as archive:
    catalog=json.load(archive.extractfile('representative.json'))
ids=('diagnostic.regex-prepared-names.many-named-rules','diagnostic.regex-template.file','calls.positional.large')
catalog['cases']=[item for item in catalog['cases'] if item['id'] in ids]
assert len(catalog['cases'])==3
write(lab/'representative.json',json.dumps(catalog,indent=2,ensure_ascii=False)+'\n')
write(lab/'jobs.json',json.dumps({'allocated':ids},indent=2)+'\n')
freeze=prior/'freeze.py'
t=freeze.read_text(encoding='utf-8')
for old, new in (
    ('agent-worktrees/fixed-tuple-admission-20261123','agent-worktrees/frontend-regex-capture-storage-20261123'),
    ('"root-module-lookup-20261123"','"fixed-tuple-admission-20261123"'),
    ('"123b2c894"','"a94f78fc74931c5386f31b8ee9d1f0e04fe1a452"'),
    ('B1477 one fixed reservation for retained tuple storage','B1481 match frontend constant subjects in the existing bounded capture buffer'),
):
    assert old in t
    t=t.replace(old,new)
write(lab/'freeze.py',t)
dotnet=Path.home()/'.dotnet11/dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent))
subprocess.run(['C:/Python313/python.exe','-X','utf8',lab/'freeze.py'],check=True)
allocation=lab.parent/'compiler-instruction-store-r424/allocation/reference'
observations={}
for role in ('reference','candidate'):
    image=lab/role
    for name in ('Allocation.dll','Allocation.deps.json','Allocation.runtimeconfig.json'):
        shutil.copyfile(allocation/name,image/name)
    result=lab/(role+'-allocation.json')
    subprocess.run([dotnet,image/'Allocation.dll',image,lab/'representative.json',result],env=env,check=True,timeout=60)
    observations[role]=read(result)['rows']
rows=[]
for a,b in zip(observations['reference'],observations['candidate'],strict=True):
    assert (a['id'],a['phase'])==(b['id'],b['phase'])
    assert a['sharedBudgetBaselineRestored'] and b['sharedBudgetBaselineRestored']
    med=lambda row:statistics.median(row['allocatedBytesPerInvocation'])
    rows.append(dict(case=a['id'],phase=a['phase'],referenceBytes=med(a),candidateBytes=med(b)))
write(lab/'summary.json',json.dumps(rows,indent=2)+'\n')
print(*rows,sep='\n')
