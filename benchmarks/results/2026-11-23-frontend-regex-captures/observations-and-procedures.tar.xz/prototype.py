from pathlib import Path
lab=Path(__file__).resolve().parent
repo=lab.parents[3]
work=repo/'.git/agent-worktrees/frontend-regex-capture-storage-20261123'
def change(path,pairs):
    path=work/'src/Lokad.Lython'/path
    t=path.read_text(encoding='utf-8')
    for a,b in pairs:
        assert t.count(a)==1,a
        t=t.replace(a,b)
    path.write_text(t,encoding='utf-8',newline='\n')
change('Runtime/LythonRuntime.RegexCompiler.cs',[
    ('using System.Numerics;','using System.Numerics;\nusing System.Runtime.CompilerServices;'),
    ('        internal const int PythonIgnoreCaseFlag = 2;',
    '''        internal const int InlineCaptureCapacity = 8;

        [InlineArray(InlineCaptureCapacity)]
        internal struct InlineCaptureBuffer { private LythonRegexCapture? _first; }

        internal static long CaptureBufferBytes(int count) => checked(32L + 16L * count);

        internal const int PythonIgnoreCaseFlag = 2;'''),
])
change('Runtime/LythonRuntime.RegexMatcher.cs',[
    ('using System.Runtime.CompilerServices;\n',''),
    ('''        private const int InlineMatchCaptureCount = 8;

        [InlineArray(InlineMatchCaptureCount)]
        private struct InlineMatchCaptures { private LythonRegexCapture? _first; }

''',''),
    ('count > InlineMatchCaptureCount\n                ? context.MemoryGovernor.ReserveTemporary(checked(32L + 16L * count), span)',
    'count > RegexCompiler.InlineCaptureCapacity\n                ? context.MemoryGovernor.ReserveTemporary(RegexCompiler.CaptureBufferBytes(count), span)'),
    ('InlineMatchCaptures buffer = default;','RegexCompiler.InlineCaptureBuffer buffer = default;'),
])
change('Frontend/StaticRegexReturnResolver.cs',[
    ('''        using var storage = analysis.MemoryGovernor?.ReserveTemporary(checked(32L + 16L * captureSlotCount), span);
        if (token.IsCancellationRequested) throw RuntimeErrors.Cancelled(span);
        var captures = new LythonRegexCapture?[captureSlotCount];''',
    '''        var useInlineCaptures = captureSlotCount <= LythonRuntime.RegexCompiler.InlineCaptureCapacity;
        using var storage = useInlineCaptures ? null
            : analysis.MemoryGovernor?.ReserveTemporary(LythonRuntime.RegexCompiler.CaptureBufferBytes(captureSlotCount), span);
        if (token.IsCancellationRequested) throw RuntimeErrors.Cancelled(span);
        LythonRuntime.RegexCompiler.InlineCaptureBuffer buffer = default;
        Span<LythonRegexCapture?> captures = buffer;
        captures = useInlineCaptures ? captures[..captureSlotCount] : new LythonRegexCapture?[captureSlotCount];'''),
])
test=(lab.parent/'buffered-csv-read-completion-20261123/test-platform.py').read_text(encoding='utf-8')
import re
test=test.replace('buffered-csv-read-completion-20261123','frontend-regex-capture-storage-20261123')
test=re.sub(r'"Category!=Stress&\(FullyQualifiedName.+?\)"',
            '"Category!=Stress&(FullyQualifiedName~Regex|FullyQualifiedName~Fnmatch|FullyQualifiedName~Glob|FullyQualifiedName~FrontendCompilationBudget)"',test)
(lab/'test-platform.py').write_text(test,encoding='utf-8',newline='\n')
