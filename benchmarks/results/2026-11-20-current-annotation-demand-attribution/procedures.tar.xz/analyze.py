import bisect
from collections import Counter
import gzip
import json
from pathlib import Path
import re

root = Path(__file__).resolve().parent
identity = json.loads((root/'identity.json').read_text(encoding='utf-8'))
receipt = json.loads((root/'archive-receipt.json').read_text(encoding='utf-8'))
terminal = json.loads((root/'terminal-status.json').read_text(encoding='utf-8'))
assert terminal['receipt']==receipt and receipt['quietBeforeAndAfter'] and not terminal['remainingTrace']
catalog = {entry['id']:entry for entry in json.loads((root/'catalog.json').read_text(encoding='utf-8'))['cases']}
phases = {
    'tokenization': ('PythonTokenization::Read','PythonTokenization+Reader::','Tokenizer::'),
    'parser': ('Parser::', 'ParserState::'),
    'syntax validity': ('SyntaxValidityDiagnostics::','GeneratorSyntaxFacts::Validate','ModernTypeSyntaxFacts::Validate'),
    'scope preparation': ('LexicalScopePreparation::','ScopeDirectiveFactsCollector::','ClassCellSyntaxFacts::'),
    'annotation flow': ('AnnotationDiagnostics::','AnnotationDiagnostics+','PostponedAnnotationText::'),
    'abstract interpretation': ('StaticAbstractInterpreter::','StaticAbstractValueResolver::'),
    'block reachability and normalization': ('::RetainReachableBlocks','::PrepareBlockTargets','::ResolveJumpTargets','::NormalizeBlocks','::NormalizeRegions','::RewriteInstructionTargets'),
    'operand layout and linearization': ('ExecutableStackLayout::Prepare','ExecutableStackLayout::Linearize','ExecutableStackLayout::ForwardValues'),
    'call emission': ('::CompileCallExpression','::InternCallSite','ExecutableCallSite::.ctor'),
    'container effect analysis': ('StaticBindingEngine::CollectMutatedReceiverNames',
        'StaticBindingEngine::CallMayMutateContainerFacts'),
    'name-binding diagnostics': ('StaticNameBindingDiagnostics::', 'StaticScopeDirectiveDiagnostics::'),
    'lowering': ('LoweredScript::',),
    'executable construction': ('ExecutableScript::','ExecutableScript+Builder::','ExecutableCodeObject::','ExecutableStackLayout::'),
    'traversal': ('StatementSyntaxTraversal','ExpressionSyntaxTraversal','ScopeDirectiveFactsCollector::Collect'),
    'admission': ('MemoryScope::','MemoryBudget::','MemoryGovernor::','TryResize'),
}
report=[]
for label in ('candidate-eager', 'candidate-dataclass', 'candidate-manifest'):
    area=root/'retrieved/profiles'/label
    record=json.loads((area/'record.json').read_text(encoding='utf-8'))
    assert record['lane']=='compile'
    if record['exitCode']!=0 or record.get('closed',{}).get('status')!='Closed':
        batches=record['warmupBatches']
        report.append(dict(label=label,case=record['workload'],lane='compile',completedCapture=False,
            exitCode=record['exitCode'],warmupBatches=len(batches),warmupSeconds=sum(
                batch['elapsedTicks']/batch['clockFrequency'] for batch in batches)))
        print('Partial warmup', report[-1])
        continue
    case=catalog[record['workload']]
    for check in ('verificationBefore','verificationAfter'):
        assert record[check]['actualOutputSha256']==case['expectedOutputSha256']
        assert record[check].get('actualFilesSha256')==case.get('expectedFilesSha256')
    libraries={Path(v['path']).name:v['sha256'].lower() for v in record['identity']['libraries']}
    measured=identity['imageFiles']['candidate']
    assert libraries['Lokad.Lython.dll']==measured['Lokad.Lython.dll']
    assert all(measured[name]==value for name,value in libraries.items() if name in measured)
    intervals=set()
    malformed=[]
    with gzip.open(area/'perf.map.gz','rt',encoding='utf-8') as symbols:
        for row in symbols:
            parts=row.rstrip().split(' ',2)
            if len(parts)!=3 or not row.endswith('\n'):
                malformed.append(row)
                continue
            address,size,name=parts
            left=int(address,16)
            intervals.add((left,left+int(size,16),name))
    intervals=sorted(intervals)
    starts=[a for a,_,_ in intervals]
    rightmost=[]
    for _,right,_ in intervals:
        rightmost.append(max(right,rightmost[-1] if rightmost else 0))
    def resolve(address,default):
        index=bisect.bisect_right(starts,address)-1
        matches=set()
        while index>=0 and rightmost[index]>address:
            left,right,name=intervals[index]
            if left<=address<right:
                matches.add(name)
            index-=1
        if len(matches)==1:
            return next(iter(matches))
        return '[ambiguous JIT map]' if matches else default
    samples=[]
    thread=None
    with gzip.open(area/'all-thread-stacks.txt.gz','rt',encoding='utf-8') as trace:
        for row in trace:
            header=re.match(r'^.*?\s(\d+)\s+\d+\.\d+:\s+\d+\s+cpu-clock:',row)
            if header:
                thread=header[1]
                stack=[]
                samples.append((thread,stack))
                continue
            frame=re.match(r'^\s+([0-9a-f]+)\s+(.*)$',row)
            if thread is not None and frame:
                stack.append(resolve(int(frame[1],16),frame[2]))
    compiler_ancestry=('LythonEngine::Compile','LythonFrontend::Compile','ExecutableScript::Compile','LoweredScript::Lower')
    def contains(stack,parts):
        return any(any(part in frame.split('(',1)[0] for part in parts) for frame in stack)
    compiler=[(thread,stack) for thread,stack in samples if contains(stack,compiler_ancestry)]
    counts={name:sum(contains(stack,parts) for _,stack in compiler) for name,parts in phases.items()}
    counts['annotation demand discovery'] = sum(
        any('AnnotationDiagnostics' in frame and 'g__Prepare' in frame.split('(',1)[0] for frame in stack)
        for _,stack in compiler)
    nearest=Counter(next((frame for frame in stack if 'Lokad.Lython.Frontend.' in frame),'[no resolved frontend frame]') for _,stack in compiler)
    leaves=Counter(stack[0] if stack else '[empty]' for _,stack in compiler)
    row=dict(label=label,case=record['workload'],lane='compile',completedCapture=True,allThreadStacks=len(samples),identifiedCompilerAncestry=len(compiler),
        samplesByThread=Counter(thread for thread,_ in samples),compilerSamplesByThread=Counter(thread for thread,_ in compiler),
        threadCpuSeconds=record['threadCpuSeconds'],inclusiveCompilerAncestryByPhase=counts,
        compilerLeaves=leaves,nearestFrontend=nearest,malformedMapRows=malformed)
    report.append(row)
    print(label, len(compiler), '/', len(samples), counts)
    print('  nearest',nearest.most_common(7))
(root/'attribution.json').write_text(json.dumps(dict(sourceRevision=identity['sourceRevision'],
    diagnosticOnly=True,inclusivePhasesMayOverlap=True,rows=report),indent=2)+'\n',encoding='utf-8',newline='\n')
