from pathlib import Path
import gzip,hashlib,json,subprocess

lab=Path('.git/agent-notes/review-20261031/direct-default-instructions-20261122').resolve()
repo=lab.parents[3]
base=lab.parent
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def digest(data): return hashlib.sha256(data).hexdigest()
def sha(path): return digest(path.read_bytes())
payload=[]
kept=[]
for name,result,packaged in [
    ('ordered-regex-group-metadata-20261122','2026-11-22-ordered-regex-group-metadata',True),
    ('lexical-binding-order-r563','2026-11-18-lexical-binding-order',False),
]:
    quiet=base/name/'quiet'
    config=read(quiet/'config.json')
    receipt=read(quiet/'archive-receipt.json')
    identity=read(quiet/'identity.json')
    assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['archivedAndVerifiedUnderLease']
    root=Path(config['root']).name
    files=identity['imageFiles']['candidate']
    frozen=base/name/'frozen/candidate'
    assert len(files)==32 and {i:sha(frozen/i) for i in files}==files
    prefix='benchmarks/results/'+result+'/'
    raw_archive=subprocess.check_output(['git','show','origin/master:'+prefix+'observations.tgz'],cwd=repo)
    assert digest(raw_archive)==receipt['archiveSHA256']==sha(quiet/'observations.tgz')
    core=frozen/'Lokad.Lython.dll'
    if packaged:
        raw_core=subprocess.check_output(['git','show','origin/master:'+prefix+'candidate-core.dll.gz'],cwd=repo)
        assert digest(gzip.decompress(raw_core))==files['Lokad.Lython.dll']
    kept.append(dict(root=root,localFrozenImage=files,trackedObservations=prefix+'observations.tgz',
                     localCore=str(core),coreAlsoInGit=packaged))
    payload.append(dict(paths=[root+'/candidate/Lokad.Lython.dll'],bytes=core.stat().st_size,links=1,
                        sha256=files['Lokad.Lython.dll'],archives={root+'/observations.tgz':receipt['archiveSHA256']},optional=False))
remote=r"""
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat
base=Path('/home/lokad/lython-bench-checks')
proofs=PROOFS
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
with (base/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    active=[p for p in base.glob('*/guest-fixtures') if os.path.ismount(p)]
    assert not active
    verified=[]
    for proof in proofs:
        core=base/proof['paths'][0]
        if not core.exists():continue
        info=core.lstat()
        if core.resolve()!=core or not stat.S_ISREG(info.st_mode) or info.st_uid!=os.getuid():continue
        if info.st_nlink!=proof['links'] or info.st_size!=proof['bytes'] or sha(core)!=proof['sha256']:continue
        if all(sha(base/name)==expected for name,expected in proof['archives'].items()):verified.append(proof)
    print(json.dumps(dict(free=shutil.disk_usage(base).free,verified=verified)))
""".replace('PROOFS',repr(payload))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73','python3 -']
output=subprocess.check_output(ssh,input=remote,encoding='utf-8',timeout=35)
(lab/'retire-inventory.json').write_text(output,encoding='utf-8',newline='\n')
(lab/'retained-image-receipts.json').write_text(json.dumps(kept,indent=2)+'\n',encoding='utf-8',newline='\n')
print(output)

