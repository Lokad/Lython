from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
old=lab.parent/'definition-admission-20261122'
donor=lab.parent/'ordered-regex-group-metadata-20261122'/'quiet'
out=lab/'quiet'
def load(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def digest(data): return hashlib.sha256(data).hexdigest()
def sha(path): return digest(path.read_bytes())
def save(path,value): path.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
def emit(path,source):
    if path.suffix=='.py': compile(source,str(path),'exec')
    path.write_text(source,encoding='utf-8',newline='\n')

local=load(lab/'identity.json')
reference,candidate=(subprocess.check_output(['git','rev-parse',local[key]],cwd=repo,text=True).strip()
                     for key in ('reference','candidate'))
assert reference.startswith('2d4fb517b') and candidate.startswith('2aa1b17e2')
core='Lokad.Lython.dll'
images=local['imageFiles']
donor_config=load(donor/'config.json')
donor_receipt=load(donor/'archive-receipt.json')
donor_files=load(donor/'identity.json')['imageFiles']['reference']
assert donor_receipt['complete'] and donor_receipt['archivedAndVerifiedUnderLease']
assert sha(donor/'observations.tgz')==donor_receipt['archiveSHA256']
assert len(donor_files)==32 and {n:sha(donor.parent/'frozen/reference'/n) for n in donor_files}==donor_files
expected=load(lab.parent/'complete-decimal-ascii-20261122/quiet/identity.json')['imageFiles']['candidate']
assert images['reference']==expected
assert digest(gzip.decompress((repo/'benchmarks/results/2026-11-22-complete-decimal-ascii/candidate-core.dll.gz').read_bytes()))==expected[core]
for role,files in images.items():
    assert len(files)==32 and {n:sha(lab/'frozen'/role/n) for n in files}==files
    assert all(donor_files[n]==h for n,h in files.items() if n!=core)
for platform in ('win','ubuntu'):
    for suite,count in (('white',1698),('public',4062)):
        text=(lab/f'{suite}-{platform}.log').read_text(encoding='utf-8-sig')
        assert 'Passed!' in text and f'Passed: {count:5d}, Skipped:' in text
allocation=load(lab/'allocation-summary.json')
assert len(allocation)==7 and all(row['allowanceRestored'] for row in allocation)

case_ids=['scripts.ordinary-fully-supplied-helper', 'scripts.annotated-rule-closures.nested-factories', 'scripts.annotated-rule-closures.literal-positional-dynamic-keyword', 'scripts.factory-observed-defaults', 'scripts.annotated-rule-closures.nested-factories.postponed']
catalog=load(lab/'representative.json')
catalog['cases']=[case for id in case_ids for case in catalog['cases'] if case['id']==id]
assert [case['id'] for case in catalog['cases']]==case_ids
out.mkdir()
manifest=out/'representative.json'
save(manifest,catalog)
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
protocol=repo/'benchmarks/cpython-worker.py'
assert sha(protocol)==donor_config['protocolSHA256']
for role in images:
    image=lab/'frozen'/role
    receipt=lab/f'quiet-{role}-verify.json'
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',manifest,
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',protocol,'--out',receipt],
        check=True,env=env,timeout=95)
    proof=load(receipt)
    assert proof['state']=='Completed' and proof['caseCount']==len(case_ids) and proof['catalogSha256']==sha(manifest)
    core_out=out/role/core
    core_out.parent.mkdir()
    shutil.copyfile(image/core,core_out)
    assert sha(core_out)==images[role][core]
identity=dict(sourceRevision=reference+' versus '+candidate,purpose='Executable instructions for function default staging',
              imageFiles=images,normalAdapterPin='0.4.0',catalogSHA256=sha(manifest),
              coreSHA256={role+suffix:files[core] for role,files in images.items() for suffix in ('','-control')})
save(out/'identity.json',identity)
root='/home/lokad/lython-bench-checks/direct-default-instructions-b1343-20261122'
unit='lython-b1343-direct-default-instructions-20261122'
template=old/'quiet'
template_config=load(template/'config.json')
jobs=[(case,'warm') for case in case_ids]+[(case_ids[2],'compile'),(case_ids[2],'compile-run')]
for name in ('collect.py','archive-owned.py','run.sh','retrieve.py'):
    source=(template/name).read_text(encoding='utf-8').replace(template_config['root'],root).replace(template_config['unit'],unit)
    if name=='collect.py':
        start,end=source.index('\njobs = '),source.index('\nassert len(jobs)')
        source=source[:start]+'\njobs = '+repr(jobs)+source[end:]
    source=source.replace('len(jobs)==6','len(jobs)==7').replace("len(raw['jobs'])==6","len(raw['jobs'])==7").replace("['jobs']==6","['jobs']==7").replace('jobs=6,','jobs=7,')
    if name=='collect.py':
        assert source.count('time.monotonic()-started < 430')==1
        source=source.replace('time.monotonic()-started < 430','time.monotonic()-started < 515')
    emit(out/name,source)
assert b'\r' not in (out/'run.sh').read_bytes()
parts=('identity.json','collect.py','archive-owned.py','run.sh','representative.json',
       'candidate/'+core)
payload=out/'payload.tgz'
with tarfile.open(payload,'w:gz') as archive:
    for name in parts:
        archive.add(out/name,arcname=name)
used=sum((out/name).stat().st_size for name in parts)
minimum=176160768+used+640*1024
ledger=load(lab/'retire-inventory.json')
retire=[]
for proof in ledger['verified']:
    if ledger['free']+sum(p['bytes'] for p in retire)>minimum:break
    retire.append(proof)
assert ledger['free']+sum(group['bytes'] for group in retire)>minimum

stage=dict(root=root,unit=unit,identity=identity,source=donor_config['root'],sourceRole='reference',
    sourceFiles=donor_files,sourceCatalogSHA256=donor_config['catalogSHA256'],donorArchiveSHA256=donor_receipt['archiveSHA256'],
    protocolSource=donor_config['root']+'/cpython-worker.py',protocolSHA256=donor_config['protocolSHA256'],
    payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),retireGroups=retire,
    catalogSHA256=sha(manifest),unpackedBytes=used)
save(out/'config.json',stage)
source=(template/'remote-launch.py').read_text(encoding='utf-8')
start,end=source.index('\nc=')+1,source.index('\nb=Path(')
source=source[:start]+'c='+repr(stage)+source[end:]
source=source.replace('RuntimeMaxSec=540','RuntimeMaxSec=620').replace('lython-b1331-fixtures','lython-b1343-fixtures')
assert "c['unpackedBytes']+640*1024" in source
emit(out/'remote-launch.py',source)
source=(lab.parent/'complete-decimal-ascii-20261122/launch.py').read_text(encoding='utf-8')
emit(lab/'launch.py',source.replace('Short ASCII decimal token comparison','Direct function default instruction comparison').replace('400','540'))
print(f'Seven short lanes, frozen input {used:,} bytes.')

