from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile
import zipfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.with_name('shared-match-bindings-20261124')
previous = donor/'comparison/quiet'
quiet = lab/'comparison/quiet'
quiet.mkdir(parents=True, exist_ok=True)
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')

reference_revision = subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert reference_revision.startswith('132d066c1')
changes = set(subprocess.check_output(['git','diff','--name-only','--','src'],cwd=repo,text=True).splitlines())
assert changes=={'src/Lokad.Lython/Frontend/'+name for name in
                 ('ExecutableScript.cs','ExecutableScript.Infrastructure.cs','ExecutableStackLayout.cs')}
patch = subprocess.check_output(['git','diff','--binary','--','src'],cwd=repo)
assert b'depth -= beforeForwarding - kept;' in patch and b'var shaping' not in patch
(lab/'candidate.patch').write_bytes(patch)
with zipfile.ZipFile(lab/'frozen-source.zip') as archive:
    for name in archive.namelist():
        if name.endswith('/'): continue
        before = archive.read(name)
        assert (lab/'frozen-reference'/name).read_bytes()==before, name
        after = (repo/name).read_bytes() if name in changes else before
        assert (lab/'frozen-candidate'/name).read_bytes()==after, name

base = read(previous/'identity.json')
core = 'Lokad.Lython.dll'
original_image = base['imageFiles']['candidate']
assert len(original_image) == 32 and {p.name:sha(p) for p in (donor/'candidate').iterdir()} == original_image
builds = {role:lab/f'{role}-build/bin/Lokad.Lython/release_net11.0'/core for role in ('reference','candidate')}
images = {role:original_image | {core:sha(path)} for role,path in builds.items()}
assert images['reference'][core] != images['candidate'][core]
for role, files in images.items():
    image = lab/role
    image.mkdir(exist_ok=True)
    for name in files:
        shutil.copyfile(builds[role] if name==core else donor/'candidate'/name,image/name)
    assert {p.name:sha(p) for p in image.iterdir()}==files

expected = quiet/'representative.json'
shutil.copyfile(previous/'representative.json',expected)
classifier,sparse,manifest=[row['id'] for row in read(expected)['cases']]
jobs=[[classifier,'compile'],[sparse,'compile-run'],[manifest,'compile-run'],[classifier,'compile-run'],[manifest,'compile'],[sparse,'compile']]
save(quiet/'jobs.json', {'warm':jobs})
identity = dict(sourceRevision=reference_revision, comparisonRevision=reference_revision,
    sourcePatchSHA256=sha(lab/'candidate.patch'), purpose='Assign final operand locations during forwarding in terminal blocks',
    imageFiles=images,expectedCPythonSHA256=base['expectedCPythonSHA256'],cpythonWorkerSHA256=base['cpythonWorkerSHA256'],
    coreSHA256={role+suffix: files[core] for role,files in images.items() for suffix in ('','-control')},
    catalogs={name:{'sha256':sha(quiet/name)} for name in ('representative.json','jobs.json')})
save(quiet/'identity.json',identity)
collector=(previous/'collect.py').read_text(encoding='utf-8').replace('b1648-fixtures','b1653-fixtures').replace('len(jobs) == 4','len(jobs) == 6')
compile(collector,'collect.py','exec')
(quiet/'collect.py').write_text(collector,encoding='utf-8',newline='\n')
shutil.copyfile(previous/'run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
python=Path('C:/Python313/python.exe')
worker=repo/'benchmarks/cpython-worker.py'
assert sha(worker)==identity['cpythonWorkerSHA256']
for role in images:
    output=lab/'comparison'/f'{role}-verify.json'
    subprocess.run([dotnet,lab/role/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',expected,
        '--dotnet',dotnet,'--python',python,'--python-worker',worker,'--out',output],env=env,cwd=repo,check=True,timeout=60)
    checked=read(output)
    assert checked['state']=='Completed' and checked['caseCount']==3
    assert checked['catalogSha256']==sha(expected) and checked['launched']['library']['sha256']==images[role][core]

payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=3) as package:
    for name in ('identity.json','jobs.json','representative.json','collect.py','run.sh'):
        package.add(quiet/name,arcname=name)
    for role,path in builds.items():
        package.add(path,arcname=f'{role}-core.dll')
save(quiet/'upload.json',dict(root='terminal-backed-operand-layout-b1653-20261124',reference='shared-match-bindings-b1648-20261124',
    payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
