from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
shutil.copyfile(lab.with_name('terminal-instructions-20261124')/'catalog.json', lab/'tape-catalog.json')
reference=lab/'reference/Lokad.Lython.dll'
candidate=lab/'candidate/Lokad.Lython.dll'
identity=read(lab/'comparison/quiet/identity.json')
assert sha(reference)==identity['coreSHA256']['reference'] and sha(candidate)==identity['coreSHA256']['candidate']
roles = {'reference': reference, 'candidate': candidate}
assert sha(reference) != sha(candidate)
sdk = Path.home()/'.dotnet11'
dotnet = sdk/'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
subprocess.run([dotnet,'build',lab/'tape/Tape.csproj','-c','Release','-o',lab/'tape-output'],
               env=env,cwd=repo,check=True,timeout=40)
summary = {}
for role, core in roles.items():
    output = lab/f'tape-{role}'
    output.mkdir(exist_ok=True)
    for path in (lab/'tape-output').glob('Tape.*'):
        shutil.copyfile(path,output/path.name)
    shutil.copyfile(core,output/core.name)
    result = lab/f'tape-{role}.json'
    subprocess.run([dotnet,output/'Tape.dll',lab/'tape-catalog.json',result],env=env,check=True,timeout=40)
    summary[role]=read(result)
    assert summary[role]['coreSHA256']==sha(core)

a,b = (summary[role]['rows'] for role in roles)
for old,new in zip(a,b,strict=True):
    for i,(prior,after) in enumerate(zip(old['objects'],new['objects'],strict=True)):
        for name in prior:
            if prior[name] != after[name]:
                raise AssertionError((old['id'],i,prior['Name'],name,
                    next(((j,x,y) for j,(x,y) in enumerate(zip(prior[name],after[name])) if x!=y),None)
                    if isinstance(prior[name],list) and isinstance(after[name],list) else (prior[name],after[name])))
    assert old==new,(old['id'],old['retainedAdmission'],new['retainedAdmission'])
count=sum(len(row['objects']) for row in a)
instruction_count=sum(len(code['Instructions']) for row in a for code in row['objects'])
print(f'{len(a)} complete sources, {count} code objects, {instruction_count} instructions, identical spans and storage shape')
