from pathlib import Path
import hashlib
import json
import os
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab/'comparison/quiet'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
digest = lambda text: hashlib.sha256(text.encode('utf-8')).hexdigest()
sdk = Path.home()/'.dotnet11'
dotnet = sdk/'dotnet.exe'
python = Path('C:/Python313/python.exe')
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
catalog = read(quiet/'representative.json')
ids = ('protected-and-assert', 'unexecuted-raise-suffix', 'function-default-and-generator', 'rewritten-input-windows')
cases = {row['id']:row for row in read(lab/'tape-catalog.json')['cases'] if row['id'] in ids}
for name, row in cases.items():
    code = row['source']
    golden = subprocess.run([python,'-I','-S','-X','utf8','-'],input=code, encoding='utf-8',capture_output=True,check=True,timeout=15)
    assert not golden.stderr
    fixture = '{"size":1,"text":null}'
    row.update(family='scripts',category='whole-script',scale='small',size=1,fixtureJson=fixture,expectedOutput=golden.stdout,
         sourceUtf8Bytes=len(code.encode('utf-8')),expectedOutputUtf8Bytes=len(golden.stdout.encode('utf-8')),
         fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,sourceSha256=digest(code),fixtureSha256=digest(fixture),
         expectedOutputSha256=digest(golden.stdout))
catalog['cases'] = [cases[name] for name in ids]
manifest = lab/'boundary-catalog.json'
manifest.write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n', encoding='utf-8',newline='\n')
worker = repo/'benchmarks/cpython-worker.py'
identity = read(quiet/'identity.json')
assert sha(worker)==identity['cpythonWorkerSHA256']
for role, expected in identity['imageFiles'].items():
    image = lab/role
    assert {path.name:sha(path) for path in image.iterdir()}==expected
    result = lab/f'{role}-boundary-verification.json'
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',manifest,
        '--dotnet',dotnet,'--python',python,'--python-worker',worker,'--out',result],env=env,cwd=repo,check=True,timeout=60)
    verified=read(result)
    assert verified['state']=='Completed' and verified['caseCount']==len(ids)
    assert verified['catalogSha256']==sha(manifest) and verified['launched']['library']['sha256']==expected['Lokad.Lython.dll']
