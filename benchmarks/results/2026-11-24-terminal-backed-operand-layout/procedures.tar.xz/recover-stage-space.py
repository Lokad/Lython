from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
results=lab.parents[3]/'benchmarks/results'
principal=results/'2026-11-24-single-pass-operand-layout'
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
sha=lambda data:hashlib.sha256(data).hexdigest()
quiet=lab/'comparison/quiet'
payload=quiet/'payload.tar.gz'
with tarfile.open(payload) as archive:
    sizes=[m.size for m in archive.getmembers()]
options=[]
backup=lab/'retired-images'
backup.mkdir(exist_ok=True)
for series,sub in (('b1651',''),('b1652','refined')):
    local_name='single-pass-operand-layout'+('-refined' if sub else '')
    remote_name=local_name+'-'+series+'-20261124'
    source=lab.with_name(local_name+'-20261124')/'candidate/Lokad.Lython.dll'
    folder=principal/sub
    digest=read(folder/'identity.json')['imageFiles']['candidate']['Lokad.Lython.dll']
    target=backup/f'{series}-Lokad.Lython.dll'
    assert sha(source.read_bytes())==digest
    shutil.copyfile(source,target)
    assert sha(target.read_bytes())==digest
    marker=read(folder/'quiet-terminal-status.json')['receipt']
    assert marker['complete'] and marker['allWorkersJoined'] and marker['archivedAndVerifiedUnderLease']
    assert sha((folder/'quiet-observations.tar.xz').read_bytes())==marker['archiveSHA256']
    options.append(dict(location=remote_name,unit=f'lython-{series}-{local_name}-20261124',
        member='candidate/Lokad.Lython.dll',bytes=source.stat().st_size,sha256=digest,archive=marker['archiveSHA256']))

profile=results/'2026-11-24-frontend-phase-profile'
raw=profile/'observations.tar.xz'
marker=read(profile/'terminal-status.json')['receipt']
assert marker['complete'] and sha(raw.read_bytes())==marker['archiveSHA256']
member='profiles/manifest-compile/perf.data'
with tarfile.open(raw) as archive:
    item=archive.getmember(member)
    assert item.isfile()
    options.append(dict(location='frontend-phase-profile-b1650-20261124',unit='lython-b1650-frontend-phase-profile-20261124',
        member=member,bytes=item.size,sha256=sha(archive.extractfile(item).read()),archive=marker['archiveSHA256']))

ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),
     '-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73','python3 -']
script=f'options={options!r}\nsizes={sizes!r}\ncompressed={payload.stat().st_size!r}\n'+'''
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve()
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
with (base/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    free=shutil.disk_usage(base).free
    block=os.statvfs(base).f_frsize
    needed=max(compressed+1400*1024,sum((size+block-1)//block*block for size in sizes)+1912*1024)
    planned=[]
    available=free
    for item in options:
        if available>=needed:break
        root=base/item['location']
        assert root.resolve()==root and not (root/'guest-fixtures').exists()
        status=subprocess.check_output(['systemctl','show',item['unit']+'.service','--property=ActiveState,MainPID'],text=True)
        assert 'ActiveState=inactive' in status and 'MainPID=0' in status
        evidence=root/'observations.tar.xz'
        marker=json.loads((root/'archive-receipt.json').read_text())
        assert marker['complete'] and marker['allWorkersJoined'] and marker['archivedAndVerifiedUnderLease']
        assert marker['archiveSHA256']==item['archive']==digest(evidence)
        target=root/item['member']
        info=target.lstat()
        assert target.resolve()==target and target.is_relative_to(root) and stat.S_ISREG(info.st_mode)
        assert info.st_nlink==1 and info.st_size==item['bytes'] and digest(target)==item['sha256']
        if target.name=='Lokad.Lython.dll':
            identity=json.loads((root/'identity.json').read_text())
            assert identity['imageFiles']['candidate'][target.name]==item['sha256']
        planned.append((item,target,evidence))
        available+=info.st_blocks*512
    assert available>=needed,(free,available,needed)
    for item,target,evidence in planned:
        target.unlink()
        assert digest(evidence)==item['archive']
    free_after=shutil.disk_usage(base).free
    assert free_after>=needed
    print(json.dumps(dict(freeBefore=free,needed=needed,freeAfter=free_after,verifiedDuplicatesRetired=[row[0] for row in planned])))
'''
result=subprocess.run(ssh,input=script,encoding='utf-8',capture_output=True,timeout=35)
if result.returncode!=0:
    print(result.stdout,result.stderr,end='')
    result.check_returncode()
(lab/'retired-stage-custody.json').write_text(result.stdout,encoding='utf-8',newline='\n')
print(result.stdout,end='')
