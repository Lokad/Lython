from pathlib import Path
import json
import shutil

lab=Path(__file__).resolve().parent
old=lab.with_name('single-pass-operand-layout-20261124')
match=lab.with_name('shared-match-bindings-20261124')
donor=match/'comparison/quiet'
receipt=json.loads((donor/'terminal-status.json').read_text(encoding='utf-8'))['receipt']
assert receipt['complete']
quiet=(match/'quiet.py').read_text(encoding='utf-8').replace('b1648','b1653').replace('shared-match-bindings','terminal-backed-operand-layout')
quiet=quiet.replace('5b21ecaea0e6899b270a05b769b19717a9ba2e598cfbeb108dd88c6f5a1a9345',receipt['archiveSHA256'])
quiet=quiet.replace('RuntimeMaxSec=228','RuntimeMaxSec=292').replace('seconds=154','seconds=208')
archive=(old/'archive.py').read_text(encoding='utf-8').replace('2026-11-24-single-pass-operand-layout','2026-11-24-terminal-backed-operand-layout')
tape=(old/'check-tape.py').read_text(encoding='utf-8')
start=tape.index('catalog = read(')
last=tape.index('roles = ', start)
tape=tape[:start]+'''shutil.copyfile(lab.with_name('terminal-instructions-20261124')/'catalog.json', lab/'tape-catalog.json')
reference=lab/'reference/Lokad.Lython.dll'
candidate=lab/'candidate/Lokad.Lython.dll'
identity=read(lab/'comparison/quiet/identity.json')
assert sha(reference)==identity['coreSHA256']['reference'] and sha(candidate)==identity['coreSHA256']['candidate']
'''+tape[last:]
tape='\n'.join(line for line in tape.split('\n') if not line.startswith(('match = ', 'definition = ', 'assert sha(reference) == read(match')))
for name,source in (('quiet.py',quiet),('archive.py',archive),('check-tape.py',tape)):
    compile(source,name,'exec')
    (lab/name).write_text(source,encoding='utf-8',newline='\n')
for name in ('allocations.py','compile-allocation.py','verify-boundaries.py'):
    shutil.copyfile(old/name,lab/name)
(lab/'tape').mkdir(exist_ok=True)
for name in ('Tape.csproj','Program.cs'):
    shutil.copyfile(old/'tape'/name,lab/'tape'/name)
(lab/'verified-raw-replicas.json').write_text('[]\n',encoding='utf-8',newline='\n')
