from pathlib import Path

lab=Path(__file__).resolve().parent
old=lab.with_name('single-pass-operand-layout-20261124')
package=(old/'package-evidence.py').read_text(encoding='utf-8')
package=package.replace('2026-11-24-single-pass-operand-layout','2026-11-24-terminal-backed-operand-layout')
package=package.replace("'candidate.patch','make-prototype.py','prepare.py','prepare.log','frozen-build.log','adapt-collection.py',",
                        "'candidate.patch','prior.patch','prepare.py','prepare.log','reference-build.log','candidate-build.log',\n"
                        "         'adapt-collection.py','recover-stage-space.py','retired-stage-custody.json','debug.log',")
package=package.replace("'initial-windows-white.log','initial-ubuntu-public.log','initial-tape.log','tape.log',",
                        "'initial-tape.log','tape.log',")
assert 'make-prototype.py' not in package and 'frozen-build.log' not in package
exec(compile(package,__file__,'exec'))
