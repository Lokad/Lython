from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
record = repo / 'benchmarks/results/2026-11-24-native-inline-transfer'
record.mkdir(exist_ok=True)
initial = lab / 'comparison/quiet'
repeat = lab / 'repeat'
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read = lambda path: json.loads(path.read_text(encoding='utf-8'))
identity = read(lab / 'comparison/identity.json')
assert identity['candidate'].startswith('29cb3439a') and identity['sourceRevision'].startswith('43688c753')
for role, files in identity['imageFiles'].items():
    assert len(files) == 32 and all(digest(lab / role / name) == sha for name, sha in files.items())
    verified = read(lab / 'comparison' / (role + '-verify.json'))
    assert verified['state'] == 'Completed' and verified['caseCount'] == 4
    assert verified['launched']['library']['sha256'] == files['Lokad.Lython.dll']
for origin, prefix, jobs in ((initial, 'initial', 4), (repeat, 'confirmation', 2)):
    outcome = read(origin / 'terminal-status.json')
    receipt = outcome['receipt']
    assert outcome['exitCode'] == '0' and not outcome['live'] and not outcome['fixtures']
    assert all(receipt[key] for key in ('complete', 'allWorkersJoined', 'guestFixturesRemoved',
        'quietBeforeAndAfter', 'archivedAndVerifiedUnderLease'))
    archive = origin / 'observations.tar.xz'
    assert receipt['warmJobs'] == jobs and digest(archive) == receipt['archiveSHA256']
    summary = read(origin / 'summary.json')
    assert summary['candidate'] == identity['candidate'] and len(summary['rows']) == jobs
    for name in ('summary.json', 'terminal-status.json', 'observations.tar.xz'):
        shutil.copyfile(origin / name, record / (prefix + '-' + name))
core = lab / 'candidate/Lokad.Lython.dll'
(record / 'candidate-core.dll.gz').write_bytes(gzip.compress(core.read_bytes(), mtime=0))
assert gzip.open(record / 'candidate-core.dll.gz', 'rb').read() == core.read_bytes()
shutil.copyfile(lab / 'comparison/identity.json', record / 'identity.json')
shutil.copyfile(lab / 'jit-summary.json', record / 'jit-summary.json')
files = ('setup.py', 'prepare.py', 'prepare-jobs.py', 'stage.py', 'quiet.py', 'summarize.py',
    'prepare-confirmation.py', 'confirm.py', 'summarize-confirmation.py', 'repeat-staging.txt', 'jit-check.py', 'archive.py',
    'verified-replicas.json', 'comparison/quiet/launch.log', 'repeat/launch.log', 'comparison/reference-verify.json',
    'comparison/candidate-verify.json')
patch = subprocess.check_output(['git', 'show', '--binary', '--format=fuller', identity['candidate']], cwd=repo)
with tarfile.open(record / 'procedures.tar.xz', 'w:xz') as bundle:
    for name in files:
        bundle.add(lab / name, arcname=name)
    from io import BytesIO
    entry = tarfile.TarInfo('candidate.patch')
    entry.size = len(patch)
    bundle.addfile(entry, BytesIO(patch))
with tarfile.open(record / 'procedures.tar.xz') as bundle:
    assert set(bundle.getnames()) == set(files) | {'candidate.patch'}
    assert bundle.extractfile('candidate.patch').read() == patch
    assert all(hashlib.sha256(bundle.extractfile(name).read()).hexdigest() == digest(lab / name) for name in files)
