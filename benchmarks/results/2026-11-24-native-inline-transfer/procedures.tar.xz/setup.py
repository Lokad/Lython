from pathlib import Path
import gzip
import hashlib
import json
import subprocess

lab = Path(__file__).resolve().parent
notes = lab.parent
repo = lab.parents[3]
previous = notes / 'marked-cased-split-20261123'
donor = 'combined-cased-split-cpython-20261123'
remote_donor = 'combined-cased-split-cpython-b1539-20261123'
run = 'native-inline-transfer-b1541-20261124'


def write(name, content):
    (lab / name).write_text(content, encoding='utf-8', newline='\n')


def read(name):
    return (previous / name).read_text(encoding='utf-8')


def snapshot(name):
    return subprocess.check_output(['git', 'show', 'origin/master:' + record + name], cwd=repo)


digest = lambda data: hashlib.sha256(data).hexdigest()
record = 'benchmarks/results/2026-11-23-module-failure-bindings/'
proof = json.loads(snapshot('identity.json'))
receipt = json.loads(snapshot('terminal-status.json'))['receipt']
core_sha = proof['imageFiles']['candidate']['Lokad.Lython.dll']
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
assert digest(snapshot('observations.tar.xz')) == receipt['archiveSHA256']
assert digest(gzip.decompress(snapshot('candidate-core.dll.gz'))) == core_sha
write('verified-replicas.json', json.dumps([dict(
    path='module-failure-bindings-b1536-20261123/candidate/Lokad.Lython.dll',
    sha256=core_sha, observationSHA256=receipt['archiveSHA256'], trackedArchive=record,
)], indent=2) + '\n')

prepare = read('prepare.py').replace('early-cased-split-20261123', 'native-inline-transfer-20261123')
prepare = prepare.replace('module-failure-bindings-20261123', donor).replace(
    "donor/'comparison/identity.json'", "donor/'comparison/quiet/identity.json'")
prepare = prepare.replace("'e4392967b'", "'43688c753'")
prepare = prepare.replace("'src/Lokad.Lython/Runtime/LythonRuntime.RegexMatcher.cs', 'src/Lokad.Lython/Runtime/PyTuple.cs'", 
    "'src/Lokad.Lython/Runtime/PyExecutableFunction.cs'")
prepare = prepare.replace("'diff','--name-only',reference,'HEAD'", "'diff','--name-only',reference,candidate")
prepare = prepare.replace("notes/'native-fixed-return-refined-20261122/representative.json'",
    "notes/'terminal-tuple-reads-20261123/comparison/representative.json'").replace(
    "notes/'inline-aggregate-tuples-20261123/comparison/representative.json'",
    "notes/'closed-factory-operand-20261123/comparison/representative.json'")
prepare = prepare.replace("'scripts.csv-invoice.method-policy.quoted-control',", "'scripts.csv-invoice.helper-accumulation',")
prepare = prepare.replace("'diagnostic.text-summary.borrowed-cased-words.mixed-width',", 
    "'scripts.annotated-rule-closures.nested-factories.postponed',")
prepare = prepare[:prepare.index("    for helper in")] + prepare[prepare.index("    actual[role]="):]
prepare = prepare[:prepare.index("    subprocess.run([dotnet,image/'Inspect.dll'")] + prepare[prepare.index("    assert all(digest(image/name)"):]
prepare = prepare[:prepare.index("shutil.copyfile(donor/'allocations.py'")]
prepare = prepare.replace('B1538 isolate the prepared split instruction from ordinary member dispatch',
    'B1541 test deferring native call continuation storage until transfer')
write('prepare.py', prepare)

jobs = read('prepare-jobs.py').replace('quote,short,mixed,supplied', 'invoice,short,factory,supplied').replace(
    "(mixed['id'],'warm'),(quote['id'],'warm'),(supplied['id'],'warm')",
    "(invoice['id'],'warm'),(supplied['id'],'warm'),(factory['id'],'compile-run')")
write('prepare-jobs.py', jobs)

stage = read('stage.py').replace('marked-cased-split-b1538-20261123', run).replace(
    'module-failure-bindings-b1536-20261123', remote_donor).replace('lython-b1538-fixtures', 'lython-b1541-fixtures')
write('stage.py', stage)

quiet = read('quiet.py').replace('b1538-marked-cased-split-20261123', 'b1541-native-inline-transfer-20261124').replace(
    'b1538-', 'b1541-').replace('A 14 MiB', 'A 10 MiB').replace('14 * 1024 * 1024', '10 * 1024 * 1024').replace(
    'seconds=270', 'seconds=220')
write('quiet.py', quiet)
write('summarize.py', read('summarize.py'))
