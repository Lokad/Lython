from pathlib import Path
import hashlib
import json
import tarfile

lab = Path(__file__).resolve().parent
comparison = lab / 'comparison'
initial = comparison / 'quiet'
repeat = lab / 'repeat'
repeat.mkdir(exist_ok=True)
name = 'native-inline-transfer-b1542-20261124'
prior = 'native-inline-transfer-b1541-20261124'
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


jobs = read(comparison / 'jobs.json')['warm']
save(repeat / 'jobs.json', dict(warm=[jobs[-1], jobs[0]]))
proof = read(comparison / 'identity.json')
proof['purpose'] = 'B1542 confirm native transfer cost with reversed order and actual 12-second warmup'
proof['catalogs']['jobs.json']['sha256'] = digest(repeat / 'jobs.json')
save(repeat / 'identity.json', proof)
catalog = comparison / 'representative.json'
assert digest(catalog) == proof['catalogs'][catalog.name]['sha256']
receipt = read(initial / 'terminal-status.json')['receipt']
assert receipt['complete'] and digest(initial / 'observations.tar.xz') == receipt['archiveSHA256']
worker = (initial / 'collect.py').read_text(encoding='utf-8').replace("'candidate':root/'candidate'",
    f"'candidate':root.parent/'{prior}'/'candidate'").replace('len(jobs) == 4', 'len(jobs) == 2')
assert 'while min(warmed)<8:' in worker and 'if warmed[i]>=8:' in worker
worker = worker.replace('while min(warmed)<8:', "while min(warmed)<record['warmupSeconds']:").replace(
    'if warmed[i]>=8:', "if warmed[i]>=record['warmupSeconds']:")
worker = worker.replace('lython-b1541-fixtures', 'lython-b1542-fixtures')
compile(worker, 'collect.py', 'exec')
(repeat / 'collect.py').write_text(worker, encoding='utf-8', newline='\n')
with tarfile.open(repeat / 'payload.tar.gz', 'w:gz') as payload:
    for key in ('identity.json', 'jobs.json', 'collect.py'):
        payload.add(repeat / key, arcname=key)
    payload.add(catalog, arcname='representative.json')
    payload.add(initial / 'run.sh', arcname='run.sh')
assert b'\r' not in (initial / 'run.sh').read_bytes()
payload = repeat / 'payload.tar.gz'
configuration = read(initial / 'upload.json')
configuration.update(root=name, candidate=prior, payloadBytes=payload.stat().st_size,
    payloadSHA256=digest(payload), initialArchiveSHA256=receipt['archiveSHA256'])
save(repeat / 'upload.json', configuration)

launch = (lab / 'quiet.py').read_text(encoding='utf-8').replace('comparison/quiet', 'repeat').replace(
    'b1541-native-inline-transfer-20261124', 'b1542-native-inline-transfer-20261124').replace('b1541-', 'b1542-')
launch = '\n'.join(line for line in launch.split('\n') if 'configuration["duplicates"]' not in line)
start = launch.index('with (base/')
end = launch.index("subprocess.run(['sudo','-n','systemd-run'", start)
launch = launch[:start] + '''candidate=base/configuration['candidate']
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert digest(candidate/'observations.tar.xz')==configuration['initialArchiveSHA256']
 assert payload.parent==base and payload.stat().st_size==configuration['payloadBytes'] and digest(payload)==configuration['payloadSHA256']
 # Two lanes reuse both frozen images. Allow 1 MiB for receipts over the 10 MiB working margin.
 assert shutil.disk_usage(base).free >= 11 * 1024 * 1024
 root.mkdir()
 with tarfile.open(payload) as archive:
  assert {entry.name for entry in archive.getmembers()}=={'identity.json','representative.json','jobs.json','run.sh','collect.py'}
  assert all(entry.isfile() for entry in archive.getmembers())
  archive.extractall(root,filter='data')
 payload.unlink()
 identity=json.loads((root/'identity.json').read_text())
 assert digest(root/'representative.json')==identity['catalogs']['representative.json']['sha256']
 for role,files in identity['imageFiles'].items():
  image=(candidate if role=='candidate' else reference)/'candidate'
  for name,sha in files.items(): assert digest(image/name)==sha,(role,name)
 os.link(reference/'cpython-worker.py',root/'cpython-worker.py')
 assert digest(root/'cpython-worker.py')==identity['cpythonWorkerSHA256']
 assert bytes([13]) not in (root/'run.sh').read_bytes()
 print(json.dumps(dict(reusedVerifiedImages=True,freeBeforeLaunch=shutil.disk_usage(base).free)),flush=True)
''' + launch[end:]
launch = launch.replace('RuntimeMaxSec=345', 'RuntimeMaxSec=225').replace('seconds=220', 'seconds=146')
(lab / 'confirm.py').write_text(launch, encoding='utf-8', newline='\n')
summary = (lab / 'summarize.py').read_text(encoding='utf-8').replace('comparison=lab/"comparison"\nquiet=comparison/"quiet"',
    'comparison=lab/"repeat"\nquiet=comparison').replace('receipt["warmJobs"] == 4', 'receipt["warmJobs"] == 2').replace(
    'len(warm["jobs"])==4', 'len(warm["jobs"])==2').replace('timedBatches=112', 'timedBatches=56')
summary = summary.replace('comparison/"representative.json"', 'lab/"comparison/representative.json"')
(lab / 'summarize-confirmation.py').write_text(summary, encoding='utf-8', newline='\n')
