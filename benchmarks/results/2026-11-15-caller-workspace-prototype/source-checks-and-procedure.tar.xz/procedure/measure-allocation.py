from pathlib import Path
import hashlib,json,os,statistics,subprocess,tempfile,time
r=Path(__file__).parent/'frozen';sdk='C:/Users/JoannesVermorel/.dotnet11';env=dict(os.environ);env['DOTNET_ROOT']=sdk;rows={};start=time.monotonic()
identity=json.loads((r/'identity.json').read_text(encoding='utf-8'))
with tempfile.TemporaryDirectory(prefix='lython-regex-allocation-')as fixture:
 env['TEMP']=fixture;env['TMP']=fixture
 for role in ['reference','candidate']:
  for n,h in identity['images'][role].items():assert hashlib.sha256((r/role/n).read_bytes()).hexdigest()==h,n
  output=r/(role+'-allocation.json');assert not output.exists()
  with(r/(role+'-allocation.log')).open('w',encoding='utf-8')as log:
   p=subprocess.run([sdk+'/dotnet.exe',str(r/role/'Allocation.dll'),str(r/role),str(r/'catalog.json'),str(output)],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
  assert p.returncode==0,(role,(r/(role+'-allocation.log')).read_text(encoding='utf-8')[-2000:])
  rows[role]=json.loads(output.read_text(encoding='utf-8'));print(role,'complete',flush=True)
 assert not list(Path(fixture).iterdir())
out=[]
for v in rows['reference']['rows']:
 a=statistics.median(v['allocatedBytesPerInvocation']);b=statistics.median(next(x for x in rows['candidate']['rows']if x['id']==v['id'])['allocatedBytesPerInvocation'])
 out.append(dict(case=v['id'],baselineBytes=a,nativeBytes=b,changePercent=100*(b/a-1)))
(r/'allocation-summary.json').write_text(json.dumps(dict(rows=out,complete=True,elapsedSeconds=time.monotonic()-start,allGoldensAndBalancesPassed=True,allUsersJoinedAndFixturesRemoved=True,performanceQualified=False,CPUorElapsedClaim=False),indent=2)+'\n',encoding='utf-8',newline='\n');print(out,flush=True)
