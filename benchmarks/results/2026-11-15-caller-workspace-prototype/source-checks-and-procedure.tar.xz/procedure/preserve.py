from pathlib import Path
import hashlib,json,shutil,tarfile,xml.etree.ElementTree as ET
repo=Path.cwd();r=Path(__file__).parent;q=r/'quiet';out=repo/'benchmarks/results/2026-11-15-caller-workspace-prototype';out.mkdir()
restoration=json.loads((r/'restoration.json').read_text(encoding='utf-8'));checks=[]
for suite,expected in [('Lokad.Lython.Tests',97),('Lokad.Lython.PublicApi.Tests',98)]:
 for tfm in ['net11.0','net10.0']:
  p=repo/'tests'/suite/'TestResults'/('r411-restored-'+tfm+'.trx');root=ET.parse(p).getroot();c=next(x for x in root.iter()if x.tag.endswith('}Counters'));assert int(c.attrib['passed'])==expected and int(c.attrib['failed'])==0
  checks.append(dict(suite=suite,framework=tfm,passed=expected,path=p.as_posix(),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
restoration.update(forcedNonincrementalWholeSolutionReleaseBuildPassed=True,actualFrameworkRestorationChecks=checks,requiresForcedNonincrementalActual11And10BuildBeforeNoBuildChecks=False,restoredBuilds={tfm:hashlib.sha256((repo/'src/Lokad.Lython/bin/Release'/tfm/'Lokad.Lython.dll').read_bytes()).hexdigest()for tfm in ['net11.0','net10.0']},rebuiltIdentityIsNotRelabeledAsMeasured0ed=True)
(out/'restoration.json').write_text(json.dumps(restoration,indent=2)+'\n',encoding='utf-8',newline='\n')
for src,name in [(r/'summary.json','summary.json'),(r/'frozen/allocation-summary.json','allocation-summary.json'),(r/'frozen/identity.json','identity.json'),(q/'observations.tgz','observations.tgz'),(q/'archive-receipt.json','archive-receipt.json'),(q/'terminal-status.json','terminal-status.json')]:shutil.copyfile(src,out/name)
with tarfile.open(out/'source-checks-and-procedure.tar.xz','w:xz')as t:
 for n in ['sources-and-checks.tar.xz','reference/Lokad.Lython.dll','candidate/Lokad.Lython.dll','catalog.json','reference-allocation.json','candidate-allocation.json']:t.add(r/'frozen'/n,arcname='frozen/'+n)
 for p in r.glob('*.py'):t.add(p,arcname='procedure/'+p.name)
 t.add(r/'baseline-source.tar',arcname='baseline-source.tar')
 for p in q.iterdir():
  if p.is_file()and p.name not in ['payload.tgz','observations.tgz']:t.add(p,arcname='quiet/'+p.name)
 for v in checks:t.add(repo/v['path'],arcname='restoration-checks/'+v['suite']+'/'+Path(v['path']).name)
(out/'README.md').write_text('''# Borrowed caller workspace — withdrawn

R411,2026-11-15, private6b6cfe6f versus qualified1b82cd46/frozen0edc0c1c.
**Not retained. All586production inputs are restored.** The borrow route, extra
entry/stack helpers and six mechanism-specific tests are removed; no dormant
arena, controller, owner, option or changed contract remains.

The [matched decomposition](../2026-11-15-helper-boundary-decomposition/README.md)
establishes existing caller capacity6slots for a5-slot helper. The prototype lends
only the unused funded tail, preserving operands/unpacked-return windows. Real
continuations obtain independent funded storage before the borrow is cleared.
Fixed managed storage remains when capacity is insufficient. No growth/new pool.
It removes repeated buffer construction but adds routing/common calls and clearing.

Focused103internal/98public each actual11/10 pass, including new borrow guards for
completion/fault/named binding/continuation copying/first refusal, plus stack and
real suspension/cancellation/ownership. Original test evaluation-order failure
(expected AdmissionFailure read before invoking admission) and corrected assertion
are preserved; no assertion is relaxed. No full package qualification is inferred.

| Complete warm script | Elapsed change | Wider process CPU change | Reference / candidate spread |
| --- | --- | --- | --- |
| Captured text helper/counter |−2.39..+4.44%|−3.25..+3.93%|0.04 /6.96%|
| Helper without counter |+1.23..+3.79%|+0.98..+2.91%|1.33 /1.19%|
| CSV invoice |−0.52..+0.77%|−1.92..+0.62%|0.64 /0.65%|
| JSON helpers |+0.49..+1.83%|+0.71..+2.14%|0.49 /0.84%|

Separate local allocation diagnostic is flat: helper447,461.75B each; invoice
4,197,002.5 versus4,197,006B. No allocation reduction claimed.

Withdraw because stable plain-helper/JSON results are adverse, captured text is
uncertain, allocation is flat and added machinery offers no demonstrated benefit.
This cost/complexity decision is not a fixed-percent veto or proof that every
call/frame redesign fails. Clarifying captured variance alone would not remove
stable adverse evidence elsewhere; no unchanged retiming is selected. Different
complete designs remain eligible. The broader performance objective is open.

B803 finishes197.523s on quiet F4as_v7/Ubuntu24.04.4/four EPYC9V45vCPUs,16GiB/
no swap,.NET11RC3 workstation GC/normal tiering. Two processes/source,12s
full-request text warmup/5s controls, five rotated0.5s batches. Every pairing and
adverse control remains. All golden/budget/quiet/Closed/join/archive/cleanup gates
pass; terminal cached, no users/RAM fixtures remain. Warm includes Run/mediated
RAM I/O/goldens/prior-result cleanup; compile/startup/reset/protocol/final cache
teardown excluded. Wider CPU includes reset/protocol. No CPython, pending-I/O,
heap/RSS or embedding-tail claim.

Initial stage refuses unchanged254MiB floor before mutation. Correction omits
unused catalog cases only, preserving the same four jobs/source/input/output/
settings and fresh complete-image proof. Three aliases of one exact committed
archived historical38c0 binary retire after hash/path/UID/link/all-alias proof.
Current images/evidence/toolchains and252MiB archive floor remain. Original
refusal/payload/config are preserved, not relabeled as a passing initial stage.

Restoration force-builds the entire Release solution nonincrementally, then passes
97internal/98public each actual11/10. All586production inputs match committed
HEAD after explicit newline normalization. Fresh build hashes are not relabeled
as measured0ed. Existing fullR408runtime qualification remains applicable; no
repeated full CI or publication follows an abandoned prototype.

[Medians](summary.json),[allocation](allocation-summary.json),[identity](identity.json),
[source/binaries/checks/original failures](source-checks-and-procedure.tar.xz),
[raw](observations.tgz),[restoration](restoration.json).
''',encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as f:f.write('''

[R411 caller-workspace borrowing](results/2026-11-15-caller-workspace-prototype/README.md)
is withdrawn: allocation flat, plain helper+1.23..3.79%elapsed/+0.98..2.91%CPU,
JSON+0.49..1.83%elapsed, captured controls move6.96%. Added routing/clearing is
not justified. B803all gates pass197.523s; original disk-floor refusal/payload
and test evaluation-order failure preserved. All586production inputs restored;
forced Release solution build,97internal/98public each actual11/10 pass. Borrow
helpers/six mechanism-only tests removed. Broader call/frame objective stays open.
''')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');a=s.index('**R411 selected prototype:');b=s.index('\n\n**Next gate:',a)
replacement='**R411 completed, withdrawn:** [source/decision](benchmarks/results/2026-11-15-caller-workspace-prototype/README.md). Existing-tail borrowing removes buffer construction but adds routing/clearing. Allocation flat; stable plain-helper/JSON timing adverse, captured text uncertain. B803all gates pass197.523s/all users cleaned. All586production inputs restored; forced nonincremental Release solution build and97internal/98public each actual11/10 pass. Borrow route/helpers/six mechanism-only tests removed. No unchanged full CI repetition. This closes this storage hypothesis, not all call/frame designs. Next A1 design must eliminate complete entry/body-control work rather than add another buffer/cache/loan route.\n'
s=s[:a]+replacement+s[b:];s=s.replace('| Active prototype | **R409**','| Qualified private development prototype | **R409**');p.write_text(s,encoding='utf-8',newline='\n')
print('Saved R411 adverse evidence and verified complete removal/restoration; broader roadmap remains active.')
