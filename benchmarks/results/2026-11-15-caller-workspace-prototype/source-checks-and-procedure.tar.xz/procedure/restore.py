from pathlib import Path
import hashlib,json,subprocess,tarfile
repo=Path.cwd();r=Path(__file__).parent
with tarfile.open(r/'baseline-source.tar')as t:
 for m in t.getmembers():
  assert m.isfile()and m.name in ['src/Lokad.Lython/Runtime/PyExecutableFunction.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.Calls.Invoke.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs']
  # Explicit byte restoration, no timestamp borrowing for later --no-build.
  (repo/m.name).write_bytes(t.extractfile(m).read())
n='tests/Lokad.Lython.Tests/ComposedNativeCallTests.cs';(repo/n).write_bytes(subprocess.check_output(['git','show','HEAD:'+n]))
files=[]
for n in subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True).splitlines():
 a=(repo/n).read_bytes();b=subprocess.check_output(['git','show','HEAD:'+n]);assert a.replace(b'\r\n',b'\n')==b.replace(b'\r\n',b'\n'),n
 files.append(dict(path=n,sha256=hashlib.sha256(a).hexdigest()))
(r/'restoration.json').write_text(json.dumps(dict(allProductionInputsMatchCommittedHeadAfterExplicitNewlineNormalization=True,head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),productionInputs=len(files),files=files,prototypeAndItsSixArchitectureSpecificTestsRemoved=True,requiresForcedNonincrementalActual11And10BuildBeforeNoBuildChecks=True,broaderPerformanceObjectiveComplete=False),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Restored all',len(files),'production inputs, removed six prototype-only tests; no dormant borrowed-workspace mechanism remains.')
