from pathlib import Path
import json
r=Path(__file__).parent;d=json.loads((r/'quiet/representative.json').read_text(encoding='utf-8'));d['cases']=[c for c in d['cases']if c['id']in ['scripts.helper-boundary.helper','scripts.csv-invoice.large']]
(r/'frozen/catalog.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(r.parent/'regex-producer-050-r409/measure-allocation.py').read_text(encoding='utf-8').replace("parent/'comparison'","parent/'frozen'").replace("'baseline'","'reference'").replace("'native'","'candidate'")
(r/'measure-allocation.py').write_text(s,encoding='utf-8',newline='\n')
