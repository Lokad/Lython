from pathlib import Path
import datetime,hashlib,json,shlex,shutil,subprocess,tarfile
q=Path(__file__).parent/'quiet'
for n in ['launch.log','config.json','payload.tgz']:shutil.copyfile(q/n,q/('original-floor-refusal-'+n))
p=q/'representative.json';d=json.loads(p.read_text(encoding='utf-8'));ids={'scripts.text-summary-helpers.nonlocal-counter.large','scripts.helper-boundary.helper','scripts.csv-invoice.large','scripts.json-summary-helpers.large'};d['cases']=[c for c in d['cases']if c['id']in ids];assert {c['id']for c in d['cases']}==ids
p.write_text(json.dumps(d,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf-8',newline='\n')
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n in ['identity.json','representative.json','collect.py','archive-owned.py','run.sh']:t.add(q/n,arcname=n)
 t.add(q.parent/'frozen/candidate/Lokad.Lython.dll',arcname='candidate/Lokad.Lython.dll')
with tarfile.open(q/'payload.tgz')as t:unpacked=sum(m.size for m in t if m.isfile())
c=json.loads((q/'config.json').read_text(encoding='utf-8'));c.update(payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
code=(q/'remote-launch.py').read_text(encoding='utf-8');a=code.index('c=');b=code.index('\nb=Path',a);code=code[:a]+'c='+repr(c)+code[b:];(q/'remote-launch.py').write_text(code,encoding='utf-8',newline='\n');(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=(q/'payload.tgz').read_bytes(),capture_output=True,timeout=45);(q/'launch.log').write_bytes(done.stdout+done.stderr);assert done.returncode==0,(done.stdout+done.stderr).decode('utf-8','replace')
now=datetime.datetime.now(datetime.timezone.utc);(q/'observe-not-before.json').write_text(json.dumps(dict(launchedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=220)).isoformat()),indent=2)+'\n',encoding='utf-8',newline='\n');print(done.stdout.decode('utf-8'),flush=True)
