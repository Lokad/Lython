from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
repo=Path.cwd();r=Path(__file__).parent;f=r/'frozen';f.mkdir();base=repo/'.git/agent-notes/review-20261031/cased-preparation-r408/refined/candidate';images={}
for role in ['reference','candidate']:
 d=f/role;d.mkdir()
 for p in base.iterdir():
  if p.is_file():shutil.copyfile(p,d/p.name)
 if role=='candidate':shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',d/'Lokad.Lython.dll')
 images[role]={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in d.iterdir()if p.is_file()}
assert images['reference']['Lokad.Lython.dll']=='0edc0c1c5a43852a61d3588a2f61973a0dd9b0b173d78b82e63ece5082383133'
for n in images['reference']:
 if n!='Lokad.Lython.dll':assert images['reference'][n]==images['candidate'][n],n
sources={}
with tarfile.open(f/'sources-and-checks.tar.xz','w:xz')as t:
 paths=subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True).splitlines()+['Directory.Build.props','Directory.Packages.props','global.json','NuGet.Config','tests/Lokad.Lython.Tests/ComposedNativeCallTests.cs']
 for n in paths:
  p=repo/n;sources[n]=hashlib.sha256(p.read_bytes()).hexdigest();t.add(p,arcname=n)
 for suite in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:
  for p in (repo/'tests'/suite/'TestResults').glob('r411-*.trx'):t.add(p,arcname='checks/'+suite+'/'+p.name)
 for n in ['initial-tests.cs','initial-test-failure.trx']:t.add(r/n,arcname='original-test-assertion-failure/'+n)
identity=dict(baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),prototype=True,images=images,sources=sources,focused='103 internal /98 public each actual11/10; new6borrow completion/fault/transfer/refusal checks; initial test evaluation-order failure preserved.',scope='Native helper entire workspace borrows existing caller dead tail; fixed managed storage remains when capacity insufficient. No growth, pool, owner, controller or public options. Existing continuation acquires independent funding before span is cleared.')
(f/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Frozen complete copied images/full source/build/test inputs and corrected/original checks.',{k:v['Lokad.Lython.dll']for k,v in images.items()})
s=(repo/'.git/agent-notes/review-20261031/regex-producer-050-r409/inspect-vm.py').read_text(encoding='utf-8').replace("shared-arithmetic-b711-20261114/reference/Lokad.Lython.dll","native-owned-slots-b709-20261114/candidate/Lokad.Lython.dll")
(r/'inspect-vm.py').write_text(s,encoding='utf-8',newline='\n')
