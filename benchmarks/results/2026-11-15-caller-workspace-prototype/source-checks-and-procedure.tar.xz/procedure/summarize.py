from pathlib import Path
import json,statistics
r=Path(__file__).parent;q=r/'quiet';raw=json.loads((q/'retrieved/confirmation/confirmation.json').read_text(encoding='utf-8'));assert raw['complete']and len(raw['jobs'])==4
rows=[]
for j in raw['jobs']:
 med={};cpu={}
 for label in j['identities']:
  samples=[s for s in j['samples']if s['engine']==label]
  med[label]=statistics.median(s['response']['elapsedTicks']/s['response']['clockFrequency']/s['response']['completedInvocations']*1000 for s in samples)
  cpu[label]=statistics.median(s['externalProcessCpuTicks']/s['externalCpuFrequency']/s['response']['completedInvocations']*1000 for s in samples)
 change=lambda values:sorted(100*(values[a]/values[b]-1)for a in ['candidate','candidate-control']for b in ['reference','reference-control'])
 spread=lambda role:100*(max(med[role],med[role+'-control'])/min(med[role],med[role+'-control'])-1)
 rows.append(dict(case=j['case'],elapsedMilliseconds=med,cpuMilliseconds=cpu,elapsedChangePercent=change(med),cpuChangePercent=change(cpu),referenceSpreadPercent=spread('reference'),candidateSpreadPercent=spread('candidate')))
(r/'summary.json').write_text(json.dumps(dict(complete=True,quietBeforeAndAfter=True,allUsersJoinedAndFixturesRemoved=True,rows=rows,retentionDecisionPending=True,CPythonRefreshed=False),indent=2)+'\n',encoding='utf-8',newline='\n')
for v in rows:print(v['case'],'elapsed',v['elapsedChangePercent'],'CPU',v['cpuChangePercent'],'spreads',v['referenceSpreadPercent'],v['candidateSpreadPercent'])
