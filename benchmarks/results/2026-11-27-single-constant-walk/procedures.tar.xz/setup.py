from pathlib import Path

lab=Path(__file__).resolve().parent
prior=lab.with_name('final-default-slots-20261127')
source=(prior/'prepare.py').read_text(encoding='utf-8')
changes={
    "assert head=='489fde50e0e774162eab5a4db9ec0bffe2210d27'":
        "assert head=='195097918f92c2d917dc67a8b8bc7ce676ce237b'\nassert not subprocess.check_output(['git','diff','489fde50e',head,'--','src'],cwd=repo)",
    "lython-final-default-fixture-": "lython-single-constant-walk-fixture-",
    "[[ordinary,'warm'],[rules,'warm-async'],[ordinary,'warm-async'],[search,'compile'],[ordinary,'compile']]":
        "[[ordinary,'compile'],[manifest_case,'compile-run'],[rules,'warm'],[manifest_case,'compile'],[ordinary,'compile-run']]",
    "Write deferred function defaults directly into their final slots in the native prefix.":
        "Fold exact machine constant preparation into the compiler declaration walk.",
}
for before,after in changes.items():
    assert source.count(before)==1,before
    source=source.replace(before,after)
start=source.index("ordinary=")
end=source.index("for name in",start)
source=source[:start]+"""ordinary='diagnostic.generated-ordinary-definitions'
rules='scripts.rule-default-closures'
invoice='scripts.csv-invoice.large'
manifest_case='scripts.config-manifest.small'
catalog=read(lab.with_name('current-callable-profile-20261126')/'local/representative.json')
manifest_catalog=read(lab.with_name('shared-match-bindings-20261124')/'comparison/quiet/representative.json')
catalog['cases']=[row for row in catalog['cases'] if row['id'] in {ordinary,rules,invoice}]
catalog['cases'] += [row for row in manifest_catalog['cases'] if row['id']==manifest_case]
assert set(row['id'] for row in catalog['cases'])=={ordinary,rules,invoice,manifest_case}
write(run/'representative.json',catalog)
"""+source[end:]
(lab/'prepare.py').write_text(source,encoding='utf-8',newline='\n')