set -eu
cd /home/vermorel/lython-starmap-rows-8066Vm
sdk="$HOME/.dotnet/dotnet"
export DOTNET_ROOT="$HOME/.dotnet"
bin=$(mktemp -d /tmp/lython-probe-python-XXXXXX)
trap 'rm -f -- "$bin/python"; rmdir -- "$bin"' EXIT
ln -s "$HOME/.local/bin/python3.13" "$bin/python"
export PATH="$bin:$DOTNET_ROOT:$PATH"
"$sdk" test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --no-build --filter 'Category!=Stress&(FullyQualifiedName~PythonComparisonPreservesMatchingFailures|FullyQualifiedName~ProbeDiscoveryPrefersMatchingConfiguration)'
