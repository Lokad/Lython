set -eu
cd /home/vermorel/lython-starmap-rows-8066Vm
sdk="$HOME/.dotnet/dotnet"
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
"$sdk" build tools/LythonProbe/LythonProbe.csproj -c Release -f net10.0
"$sdk" test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --no-build --filter 'Category!=Stress&(FullyQualifiedName~PythonComparisonPreservesMatchingFailures|FullyQualifiedName~ProbeDiscoveryPrefersMatchingConfiguration)'
