from pathlib import Path

lab=Path(__file__).resolve().parent
previous=lab.with_name('json-single-string-pass-20261126')

def edit(source, replacements):
    for old,new in replacements:
        assert source.count(old)==1,old
        source=source.replace(old,new)
    return source

def read(root,name):
    return (root/name).read_text(encoding='utf-8')

def write(name,source):
    compile(source,name,'exec')
    (lab/name).write_text(source,encoding='utf-8',newline='\n')

source=edit(read(previous,'prepare-quiet.py'),[
    ("lab=Path('.git/agent-notes/review-20261031/json-single-string-pass-20261126')","lab=Path(__file__).resolve().parent"),
    ("previous=lab.with_name('deferred-site-placement-20261126')","previous=lab.with_name('json-single-string-pass-20261126')"),
    ("verify['caseCount']==5","verify['caseCount']==3"),
    ("jobs['warm']=jobs['warm'][2:]+jobs['warm'][:2]","jobs['warm']=[jobs['warm'][2],jobs['warm'][4],jobs['warm'][0]]"),
    ("('lython-b1795-fixtures','lython-b1796-fixtures'),","('lython-b1796-fixtures','lython-b1799-fixtures'),\n    ('len(jobs) == 4','len(jobs) == 3'),"),
    ("collector=edit((donor/'comparison/quiet/collect.py')","collector=edit((previous/'comparison/quiet/collect.py')"),
    ("root='json-single-string-pass-b1796-20261126'","root='direct-map-result-handoff-b1799-20261126'"),
    ("minimumAfterStageBytes=9_000_000","minimumAfterStageBytes=8_000_000"),
    ("launcher=(donor/'quiet.py').read_text(encoding='utf-8')","launcher=(previous/'quiet.py').read_text(encoding='utf-8')"),
    ("a=launcher.index(\" assets=base/\")\nb=launcher.index(\" assert donor.resolve()\",a)\nlauncher=launcher[:a]+\" donor=base/'starmap-direct-sequence-b1795-20261126'/'candidate'\\n\"+launcher[b:]\na=launcher.index(\" assert donor_receipt['archiveSHA256']\")\nb=launcher.index(\" (root/'candidate').mkdir()\",a)\nlauncher=launcher[:a]+\"\"\" assert donor_receipt['complete'] and donor_receipt['archiveSHA256']==cfg['donorSHA256']==sha(donor.parent/'observations.tar.xz')\n\"\"\"+launcher[b:]\n",""),
    ("('lython-b1795-starmap-direct-sequence-20261126','lython-b1796-json-single-string-pass-20261126'),","('lython-b1796-json-single-string-pass-20261126','lython-b1799-direct-map-result-handoff-20261126'),"),
    ("('len(frames)==4 and len(set(f.name for f in frames))==4','len(frames)==6 and len(set(f.name for f in frames))==6'),","('timedelta(seconds=166)','timedelta(seconds=137)'),"),
    ("(\"verified['caseCount']==4\",\"verified['caseCount']==5\"),","(\"verified['caseCount']==5\",\"verified['caseCount']==3\"),"),
    ("shutil.copyfile(donor/'summarize-quiet.py',lab/'summarize-quiet.py')",""),
])
write('prepare-quiet.py',source)
summary=edit(read(previous,'summarize-quiet.py'),[
    ("receipt['warmJobs'] == 4","receipt['warmJobs'] == 3"),
    ("len(raw['jobs']) == 4","len(raw['jobs']) == 3"),
    ("timedBatches=112","timedBatches=84"),
])
write('summarize-quiet.py',summary)
preserve=edit(read(previous,'preserve-core.py'),[
    ("{target}/quiet-observations.tar.xz","{target}/quiet/observations.tar.xz"),
    ("source='native-dictionary-slots-20261125'","source='json-single-string-pass-20261126'"),
    ("'2026-11-25-native-dictionary-slots'","'2026-11-26-json-single-string-pass'"),
    ("frozen=lab.with_name(source)/'candidate'","frozen=lab.with_name(source)/'local/candidate'"),
])
write('preserve-core.py',preserve)
