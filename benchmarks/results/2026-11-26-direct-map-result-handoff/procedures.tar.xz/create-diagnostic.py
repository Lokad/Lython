from pathlib import Path
import hashlib
import json
import subprocess
import tempfile
import textwrap

lab = Path(__file__).resolve().parent
old = lab.with_name('direct-literal-keyword-metadata-20261126')
previous = lab.with_name('borrowed-loop-iterators-20261126')/'comparison/quiet'

def text(path):
    return path.read_text(encoding='utf-8-sig')

def write(path, value):
    path.write_text(value, encoding='utf-8', newline='\n')

def edit(source, replacements):
    for a, b in replacements:
        assert source.count(a) == 1, a
        source = source.replace(a, b)
    return source

source = edit(text(old/'prepare.py'), [
    ("'src/Lokad.Lython/Frontend/ExecutableScript.Builder.cs',\n    'src/Lokad.Lython/Frontend/ExecutableScript.SuspendingDefinitions.cs',\n    'src/Lokad.Lython/Runtime/LythonRuntime.FunctionDefaults.cs',",
     "'src/Lokad.Lython/Runtime/PyBuiltinIterators.cs',\n    'src/Lokad.Lython/Runtime/PyIteration.cs',\n    'src/Lokad.Lython/Runtime/LythonRuntime.BuiltinIterables.Aggregates.cs',"),
    ("] )]:".replace(' ',''), "]), ('regression.patch',['tests/Lokad.Lython.PublicApi.Tests/IteratorAdapterTests.cs'])]:"),
])
compile(source, 'prepare.py', 'exec')
write(lab/'prepare.py',source)
cases = {
    'diagnostic.shipment-routing-callbacks',
    'diagnostic.shipment-file-fed-map',
    'scripts.file-search.large',
}
catalog = json.loads(text(previous/'representative.json'))
catalog['cases'] = [case for case in catalog['cases'] if case['id'] in cases]
assert {c['id'] for c in catalog['cases']} == cases
write(lab/'representative.json',json.dumps(catalog,indent=2,ensure_ascii=False)+'\n')
source = edit(text(lab/'prepare.py'), [("proof['caseCount']==4","proof['caseCount']==3")])
compile(source,'prepare.py','exec')
write(lab/'prepare.py',source)
source = edit(text(old/'prepare-local.py'), [
    ("prior=lab.with_name('deferred-site-placement-20261126')/'local'","prior=lab.with_name('direct-literal-keyword-metadata-20261126')/'local'"),
    ("    ['scripts.rule-default-closures','compile'],\n    ['diagnostic.generated-ordinary-definitions','compile'],\n    ['scripts.file-search.large','warm'],\n    ['scripts.rule-default-closures','warm-async'],",
     "    ['diagnostic.shipment-routing-callbacks','warm-async'],\n    ['diagnostic.shipment-file-fed-map','warm'],\n    ['scripts.file-search.large','warm'],\n    ['diagnostic.shipment-routing-callbacks','warm'],\n    ['diagnostic.shipment-file-fed-map','warm-async'],"),
    ("Store a single compiled literal keyword initializer by reference.","Pass completed short map rows directly to nested maps and sum."),
    ("assert collector.count('lython-deferred-site-placement-fixture-')==1","assert collector.count('lython-direct-literal-keyword-metadata-fixture-')==1"),
    ("collector=collector.replace('lython-deferred-site-placement-fixture-','lython-direct-literal-keyword-metadata-fixture-')",
     "collector=collector.replace('lython-direct-literal-keyword-metadata-fixture-','lython-direct-map-result-handoff-fixture-')"),
    ("compile(collector,'collect.py','exec')","collector=collector.replace('len(jobs) == 4','len(jobs) == 5')\ncompile(collector,'collect.py','exec')"),
    ("shutil.copyfile(prior.parent/'summarize.py',lab/'summarize.py')",
     "summary=(prior.parent/'summarize.py').read_text(encoding='utf-8').replace(\"receipt['warmJobs'] == 4\", \"receipt['warmJobs'] == 5\").replace(\"len(raw['jobs']) == 4\", \"len(raw['jobs']) == 5\").replace('timedBatches=112','timedBatches=140')\nwrite(lab/'summarize.py',summary)"),
])
compile(source,'prepare-local.py','exec')
write(lab/'prepare-local.py',source)
program = text(lab/'source/tests/Lokad.Lython.PublicApi.Tests/IteratorAdapterTests.cs').split(
    'NestedMapIntoSumRetainsAliasesAndUnwindsWhenWorkSuspends',1)[1]
body = program.split('var source = $$"""\n',1)[1].split('\n            """;',1)[0]
with tempfile.TemporaryDirectory(dir=lab) as folder:
    write(Path(folder)/'pause','1')
    results=[]
    for choice in ('False','True'):
        script=textwrap.dedent(body).replace('{{(pauseInCallback ? "True" : "False")}}',choice)
        output=subprocess.run(['C:/Python313/python.exe','-I','-S','-c',script],
            cwd=folder,check=True,encoding='utf-8',capture_output=True,timeout=30).stdout
        assert output=='1 True\n[9223372036854775807, 9223372036854775808]\n',output
        results.append(choice+'\n'+output)
write(lab/'cpython-regression.log','\n'.join(results))
print('Prepared three catalog cases in five lanes and verified both regression scripts under CPython.')
