set -eu
export DOTNET_ROOT="$HOME/.dotnet"
"$DOTNET_ROOT/dotnet" test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj \
    -c Release -f net10.0 \
    --artifacts-path .git/agent-notes/review-20261031/direct-map-result-handoff-20261126/production-ubuntu \
    --filter FullyQualifiedName~NestedMapIntoSumRetainsAliasesAndUnwindsWhenWorkSuspends
