from pathlib import Path
import hashlib,json,shutil,tarfile

lab=Path(__file__).resolve().parent
first=lab/'comparison/quiet'
repeat=lab.with_name(lab.name+'-confirmation')
quiet=repeat/'comparison/quiet'
quiet.mkdir(parents=True)
template=lab.with_name('converted-update-cpython-20261126')/'quiet.py'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,t:p.write_text(t,encoding='utf-8',newline='\n')
save=lambda p,v:write(p,json.dumps(v,indent=2)+'\n')
terminal=read(first/'terminal-status.json')
receipt=terminal['receipt']
assert terminal['exitCode']=='0' and not terminal['live'] and not terminal['fixtures']
assert receipt['complete'] and receipt['quietBeforeAndAfter'] and receipt['archiveSHA256']==sha(first/'observations.tar.xz')
identity=read(first/'identity.json')
identity['donorArchiveSHA256']=receipt['archiveSHA256']
identity['purpose']='Confirm the remaining timing after the unchanged text control moved adversely.'
for name in ('representative.json','cpython-worker.py','run.sh'):
    shutil.copyfile(first/name,quiet/name)
assert sha(quiet/'representative.json')==identity['catalogs']['representative.json']['sha256']
assert sha(quiet/'cpython-worker.py')==identity['cpythonWorkerSHA256']
doc='diagnostic.json-service-quantity-totals'
lines='scripts.json-summary-helpers.large'
text='diagnostic.text-summary.nonlocal-computed-width.large'
save(quiet/'jobs.json',dict(warm=[[doc,'warm'],[text,'warm'],[lines,'warm-async'],[doc,'warm-async'],[text,'warm']]))
identity['catalogs']['jobs.json']['sha256']=sha(quiet/'jobs.json')
save(quiet/'identity.json',identity)
collector=(first/'collect.py').read_text(encoding='utf-8')
assert collector.count('lython-b1776-fixtures')==1
collector=collector.replace('lython-b1776-fixtures','lython-b1776c-fixtures')
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
root='ready-json-construction-b1776c-20261126'
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=6) as package:
    for name in ('identity.json','jobs.json','representative.json','collect.py','run.sh','cpython-worker.py'):
        package.add(quiet/name,arcname=name,recursive=False)
save(quiet/'upload.json',dict(root=root,payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
launcher=template.read_text(encoding='utf-8')
start=launcher.index(" origin=donor/'candidate'")
end=launcher.index(" python=Path.home()",start)
launcher=launcher[:start]+''' for role,files in image['imageFiles'].items():
  origin=(donor/role).resolve()
  assert origin.is_relative_to(base) and len(files)==32 and {p.name:sha(p) for p in origin.iterdir()}==files
  (root/role).symlink_to(origin,target_is_directory=True)
'''+launcher[end:]
for before,after in [('lython-b1764-converted-update-cpython-20261126','lython-b1776c-ready-json-construction-20261126'),
    ('converted-dictionary-update-b1763-20261126','ready-json-construction-b1776-20261126'),
    ("cfg['payloadBytes']+12*1024*1024","cfg['payloadBytes']+6*1024*1024"),('RuntimeMaxSec=248','RuntimeMaxSec=285')]:
    assert launcher.count(before)==1,before
    launcher=launcher.replace(before,after)
compile(launcher,'quiet.py','exec')
write(repeat/'quiet.py',launcher)
shutil.copyfile(lab/'summarize-quiet.py',repeat/'summarize-quiet.py')
