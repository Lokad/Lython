from pathlib import Path, PurePosixPath
import hashlib
import json
import re
import subprocess
import sys
import tarfile

lab = Path(__file__).resolve().parent
results = lab.parents[3]/'benchmarks/results'

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

assert sys.argv[1:] in (['preview'], ['compact'])
upload = read(lab/'comparison/quiet/upload.json')
minimum = upload['payloadBytes']+upload['expandedBytes']+5*1024*1024+512*1024
archives = []
for directory in sorted(results.glob('2026-11-2*')):
    status_path = directory/'terminal-status.json'
    archive = directory/'observations.tar.xz'
    if not status_path.is_file() or not archive.is_file(): continue
    status = read(status_path)
    receipt = status.get('receipt') or {}
    if status.get('exitCode') != '0' or status.get('live') or status.get('fixtures') or not all(
            receipt.get(name) for name in ('complete','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease')): continue
    journal = status.get('journal','')
    stages = set(re.findall(r'/home/lokad/lython-bench-checks/([a-z0-9-]+)/(?:run\.sh|guest-fixtures)',journal))
    units = set(re.findall(r'lython-b[0-9][a-z0-9-]*\.service',journal))
    if len(stages) != 1 or len(units) != 1: continue
    raw = hashlib.sha256(archive.read_bytes()).hexdigest()
    assert raw == receipt['archiveSHA256']
    files = {}
    with tarfile.open(archive) as packed:
        for member in packed.getmembers():
            relative = PurePosixPath(member.name)
            if member.isfile() and member.size >= 65536 and relative.parts[0] == 'profiles':
                assert len(relative.parts) == 3 and '..' not in relative.parts
                files[member.name] = dict(bytes=member.size, sha256=hashlib.file_digest(packed.extractfile(member),'sha256').hexdigest())
    if files:
        archives.append(dict(stage=stages.pop(),unit=units.pop(),raw=raw,files=files,
                             bytes=sum(claim['bytes'] for claim in files.values())))
archives.sort(key=lambda item: -item['bytes'])
config = dict(archives=archives, threshold=minimum, compact=sys.argv[1]=='compact')
remote = r'''
from pathlib import Path
import fcntl,hashlib,json,shutil,stat,subprocess,tarfile
base=Path('/home/lokad/lython-bench-checks')
assert base.resolve()==base
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 before=shutil.disk_usage(base).free
 target=before
 verified=[]
 for item in cfg['archives']:
  if target>=cfg['threshold']:break
  root=base/item['stage']
  assert root.resolve()==root and root.parent==base
  raw=root/'observations.tar.xz'
  receipt=root/'archive-receipt.json'
  if not raw.is_file() or not receipt.is_file(): continue
  status=subprocess.run(['systemctl','show',item['unit'],'--property=ActiveState,MainPID'],
                        capture_output=True,text=True).stdout.splitlines()
  assert 'ActiveState=inactive' in status and 'MainPID=0' in status,status
  rec=json.loads(receipt.read_text())
  assert rec['complete'] and rec['allWorkersJoined'] and rec['guestFixturesRemoved']
  assert raw.resolve()==raw and rec['archiveSHA256']==item['raw']==sha(raw)
  with tarfile.open(raw) as packed:
   for name,claim in item['files'].items():
    path=root/name
    assert path.resolve()==path and path.is_relative_to(root/'profiles')
    if not path.exists():continue
    info=path.lstat()
    assert stat.S_ISREG(info.st_mode) and info.st_nlink==1 and info.st_size==claim['bytes']
    assert sha(path)==claim['sha256']==hashlib.file_digest(packed.extractfile(name),'sha256').hexdigest()
    verified.append((path,dict(path=str(path.relative_to(base)),bytes=info.st_size,
                               sha256=claim['sha256'],archiveSHA256=item['raw'])))
    target+=info.st_size
    if target>=cfg['threshold']:break
 assert target>=cfg['threshold'],(before,target,cfg['threshold'])
 if cfg['compact']:
  for path,row in verified:path.unlink()
 print(json.dumps(dict(before=before,after=shutil.disk_usage(base).free,minimum=cfg['threshold'],
                       compactionApplied=cfg['compact'],expandableBytes=target-before,
                       duplicateFiles=[row for _,row in verified])))
'''
cmd = ['ssh','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes','-o','ConnectTimeout=12',
       'lokad@20.166.121.73','python3 -']
result = subprocess.run(cmd,input='cfg='+repr(config)+'\n'+remote,encoding='utf-8',capture_output=True,timeout=48)
(lab/f'comparison/quiet/storage-{sys.argv[1]}.log').write_text(result.stdout+result.stderr,encoding='utf-8',newline='\n')
print(result.stderr if result.returncode else json.dumps({k:v for k,v in json.loads(result.stdout).items() if k!='duplicateFiles'}))
result.check_returncode()
