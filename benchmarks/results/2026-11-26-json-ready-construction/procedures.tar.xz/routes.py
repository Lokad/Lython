from pathlib import Path
from difflib import unified_diff
import hashlib,json,os,shutil,subprocess,zipfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
previous=lab.with_name('post-deferral-factory-cpu-20261126')/'routes'
frozen=lab/'frozen/candidate'
quiet=lab/'comparison/quiet'
routes=lab/'routes'
routes.mkdir()
snapshot=routes/'source.zip'
source=routes/'source'
identity=json.loads((quiet/'identity.json').read_text(encoding='utf-8'))
subprocess.run(['git','archive','--format=zip','--output',snapshot,identity['sourceRevision'],'--','src',
                'Directory.Build.props','Directory.Build.targets','Directory.Build.rsp','Directory.Packages.props',
                'global.json','NuGet.Config'],cwd=repo,check=True)
with zipfile.ZipFile(snapshot) as archive:
    assert all(not Path(name).is_absolute() and '..' not in Path(name).parts for name in archive.namelist())
    archive.extractall(source)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(lab/'candidate.patch')==identity['sourcePatchSHA256']
subprocess.run(['git','apply','--whitespace=nowarn',lab/'candidate.patch'],cwd=source,check=True)
name='src/Lokad.Lython/Runtime/LythonRuntime.Json.Construction.cs'
path=source/name
old=path.read_text(encoding='utf-8')
names=['ReadyJsonScalars','ReadyJsonObjectKeys','EstablishedJsonArrayPositions','PendingJsonScalars']
fields=''.join('    internal static int Diagnostic'+counter+';\n' for counter in names)
new=old
for before,after in [
    ('    private sealed partial class JsonModule',fields+'\n    private sealed partial class JsonModule'),
    ('                // Array frames already point past whitespace',
     '                if (!frame.IsObject) Interlocked.Increment(ref DiagnosticEstablishedJsonArrayPositions);\n                // Array frames already point past whitespace'),
    ('                    state.AwaitingContainer = false;',
     '                    Interlocked.Increment(ref DiagnosticPendingJsonScalars);\n                    state.AwaitingContainer = false;'),
    ('                AcceptJsonValue(ref frame, key, scalar, scalarEnd, ref state);',
     '                Interlocked.Increment(ref DiagnosticReadyJsonScalars);\n                if (key is not null) Interlocked.Increment(ref DiagnosticReadyJsonObjectKeys);\n                AcceptJsonValue(ref frame, key, scalar, scalarEnd, ref state);'),
]:
    assert new.count(before)==1,before
    new=new.replace(before,after)
path.write_text(new,encoding='utf-8',newline='\n')
(routes/'diagnostic.patch').write_text(''.join(unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),
    'a/'+name,'b/'+name)),encoding='utf-8',newline='\n')
catalog=json.loads((quiet/'representative.json').read_text(encoding='utf-8-sig'))
catalog['cases']=[case|dict(runAsync=mode) for case in catalog['cases'] for mode in (False,True)]
(routes/'cases.json').write_text(json.dumps(catalog,ensure_ascii=False),encoding='utf-8',newline='\n')
program=(previous/'Program.cs').read_text(encoding='utf-8')
start=program.index('string[] names = ')
stop=program.index(';',start)+1
(routes/'Program.cs').write_text(program[:start]+'string[] names = '+json.dumps(names)+';'+program[stop:],
    encoding='utf-8',newline='\n')
shutil.copyfile(previous/'RouteProbe.csproj',routes/'RouteProbe.csproj')
assert len(identity['imageFiles']['candidate'])==32 and {p.name:sha(p) for p in frozen.iterdir()}==identity['imageFiles']['candidate']
image=routes/'image'
shutil.copytree(frozen,image)
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
def run(args,name):
    with (routes/name).open('wb') as log:
        subprocess.run([dotnet,*args],stdout=log,stderr=subprocess.STDOUT,env=env,cwd=repo,check=True,timeout=150)
run(['build',source/'src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-incremental',
     '-o',routes/'core'],'build-core.log')
shutil.copyfile(routes/'core/Lokad.Lython.dll',image/'Lokad.Lython.dll')
run(['build',routes/'RouteProbe.csproj','-c','Release','-o',routes/'probe'],'build-probe.log')
for file in (routes/'probe').glob('RouteProbe*'): shutil.copyfile(file,image/file.name)
run([image/'RouteProbe.dll',image,routes/'cases.json',routes/'counts.json'],'run.log')
report=json.loads((routes/'counts.json').read_text(encoding='utf-8'))
assert len(report['rows'])==6
for row in report['rows']:
    print(row['id'],row['asynchronous'],row['routes'])
