from pathlib import Path
from statistics import median
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.with_name('direct-signed-argument-20261126')
old=lab.with_name('ready-json-decoder-entry-20261126')
tools=lab.with_name('prepared-machine-constants-20261126')
quiet=lab/'comparison/quiet'
quiet.mkdir(parents=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,t:p.write_text(t,encoding='utf-8',newline='\n')
save=lambda p,v:write(p,json.dumps(v,indent=2,ensure_ascii=False)+'\n')
manifest=lambda path:{p.name:sha(p) for p in path.iterdir()}

head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head.startswith('7045bcb35')
donor=prior/'comparison/quiet'
source=read(donor/'identity.json')
prior_patch=subprocess.check_output(['git','diff','--binary',source['sourceRevision'],head,'--','src'],cwd=repo)
assert hashlib.sha256(prior_patch).hexdigest()==source['sourcePatchSHA256']
receipt=read(donor/'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['quietBeforeAndAfter'] and receipt['archiveSHA256']==sha(donor/'observations.tar.xz')
ref=prior/'local/candidate'
assert len(source['imageFiles']['candidate'])==32 and manifest(ref)==source['imageFiles']['candidate']
patch=subprocess.check_output(['git','diff','--binary','--','src'],cwd=repo)
assert patch.count(b'diff --git ')==1 and b'LythonRuntime.Json.Construction.cs' in patch
(lab/'candidate.patch').write_bytes(patch)
core='Lokad.Lython.dll'
images={}
for role in ('reference','candidate'):
    image=lab/'frozen'/role
    shutil.copytree(ref,image)
    assert manifest(image)==source['imageFiles']['candidate']
    if role=='candidate': shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net11.0'/core,image/core)
    images[role]=manifest(image)
assert {n for n in images['reference'] if images['reference'][n]!=images['candidate'][n]}=={core}

shutil.copyfile(old/'representative.json',quiet/'representative.json')
catalog=read(quiet/'representative.json')
doc='diagnostic.json-service-quantity-totals'
lines='scripts.json-summary-helpers.large'
control=next(case['id'] for case in catalog['cases'] if 'text-summary' in case['id'])
assert {case['id'] for case in catalog['cases']}=={doc,lines,control}
jobs=[[control,'warm'],[doc,'warm-async'],[lines,'warm'],[doc,'warm'],[lines,'warm-async']]
save(quiet/'jobs.json',{'warm':jobs})
shutil.copyfile(repo/'benchmarks/cpython-worker.py',quiet/'cpython-worker.py')
assert sha(quiet/'cpython-worker.py')==source['cpythonWorkerSHA256']
identity=dict(sourceRevision=head,sourcePatchSHA256=sha(lab/'candidate.patch'),imageFiles=images,
    coreSHA256={r+s:v[core] for r,v in images.items() for s in ('','-control')},
    cpythonWorkerSHA256=source['cpythonWorkerSHA256'],expectedCPythonSHA256=source['expectedCPythonSHA256'],
    catalogs={name:{'sha256':sha(quiet/name)} for name in ('representative.json','jobs.json')},
    purpose='Measure keeping ready JSON scalars in the active frame and removing the repeated array whitespace scan.')
save(quiet/'identity.json',identity)
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
allocation_tool=lab.with_name('json-traversal-20261124')/'reference'
allocation={}
for role,files in images.items():
    image=lab/'frozen'/role
    verify=lab/(role+'-verify.json')
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'representative.json',
                    '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',quiet/'cpython-worker.py',
                    '--out',verify],cwd=repo,env=env,check=True,timeout=85)
    proof=read(verify)
    assert proof['state']=='Completed' and proof['caseCount']==3 and proof['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert proof['launched']['library']['sha256'].lower()==files[core]
    path=lab/(role+'-allocated')
    shutil.copytree(image,path)
    assert manifest(path)==files
    for exe in allocation_tool.glob('ValidatedAllocation*'):
        shutil.copyfile(exe,path/exe.name)
    output=lab/(role+'-allocation.json')
    subprocess.run([dotnet,path/'ValidatedAllocation.dll',path,quiet/'representative.json',output],cwd=repo,
                   env=env,check=True,timeout=65)
    allocation[role]=read(output)['rows']
summary=[]
for before,after in zip(allocation['reference'],allocation['candidate'],strict=True):
    assert before['id']==after['id'] and before['sharedBudgetBaselineRestored'] and after['sharedBudgetBaselineRestored']
    summary.append(dict(case=before['id'],bytes=[median(row['allocatedBytesPerInvocation']) for row in (before,after)],
                        peak=[row['peakExecutionMemoryBytes'] for row in (before,after)]))
save(lab/'allocation-summary.json',summary)
print(json.dumps(summary))

collector=(donor/'collect.py').read_text(encoding='utf-8')
assert collector.count('lython-b1775-fixtures')==1 and 'len(jobs) == 5' in collector
collector=collector.replace('lython-b1775-fixtures','lython-b1776-fixtures')
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
shutil.copyfile(donor/'run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
package=quiet/'stage.tar.gz'
entries=[('new-core.dll',lab/'frozen/candidate'/core)]
entries.extend((name,quiet/name) for name in ('identity.json','representative.json','jobs.json','collect.py','run.sh','cpython-worker.py'))
with tarfile.open(package,'w:gz',compresslevel=6) as archive:
    for name,path in entries: archive.add(path,arcname=name,recursive=False)
save(quiet/'upload.json',dict(root='ready-json-construction-b1776-20261126',payloadSHA256=sha(package),
    payloadBytes=package.stat().st_size,expandedBytes=sum(p.stat().st_size for _,p in entries),donorSHA256=receipt['archiveSHA256']))
launcher=(tools/'quiet.py').read_text(encoding='utf-8')
for before,after in [('lython-b1770-prepared-constants-20261126','lython-b1776-ready-json-construction-20261126'),
    ('boolean-increments-b1766-20261126','direct-signed-argument-b1775-20261126'),
    ("verified['caseCount']==4","verified['caseCount']==3"),('RuntimeMaxSec=325','RuntimeMaxSec=285'),('seconds=241','seconds=205')]:
    assert launcher.count(before)==1,before
    launcher=launcher.replace(before,after)
compile(launcher,'quiet.py','exec')
write(lab/'quiet.py',launcher)
shutil.copyfile(prior/'summarize-quiet.py',lab/'summarize-quiet.py')
shutil.copyfile(prior/'compact-for-quiet.py',lab/'compact-for-quiet.py')
