from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / 'comparison/quiet'
out = repo / 'benchmarks/results/2026-11-28-current-mixed-cpython'


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


identity = read(quiet / 'identity.json')
stage = read(quiet / 'stage-custody.json')
summary = read(quiet / 'summary.json')
terminal = read(quiet / 'terminal-status.json')
receipt = terminal['receipt']
frozen = identity['imageFiles']['candidate']
assert identity['sourceRevision'] == summary['source']
assert len(frozen) == 32
assert {path.name: digest(path) for path in (quiet / 'local-image').iterdir()} == frozen
assert summary['timedBatches'] == 112 and summary['passedQuietCheck']
assert len(summary['rows']) == 4 and summary['rows'][-1]['lane'] == 'compile-run'
assert stage['reused'] == {'donor': 32} and stage['streamed']
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode'] == '0'
assert receipt['warmJobs'] == 4 and receipt['archiveSHA256'] == digest(quiet / 'observations.tar.xz')
assert all(receipt[key] for key in ('complete', 'allWorkersJoined', 'guestFixturesRemoved',
    'quietBeforeAndAfter', 'archivedAndVerifiedUnderLease'))

out.mkdir(exist_ok=True)
for name in ('identity.json', 'summary.json', 'observations.tar.xz', 'terminal-status.json'):
    copy2(quiet / name, out / name)
    assert digest(out / name) == digest(quiet / name)

procedures = {name: lab / name for name in ('prepare.py', 'quiet-vm.py', 'verify.sh',
    'summarize.py', 'compact-completed.py', 'compaction.json',
    'compaction-terminal-unit.log', 'publish.py')}
procedures.update({name: quiet / name for name in ('first-launch.log', 'launch.log', 'upload.json', 'stage-custody.json',
    'candidate-local-verify.json', 'candidate-remote-verify.json', 'exit-code.txt', 'archive-receipt.json')})
with tarfile.open(out / 'procedures.tar.xz', 'w:xz') as archive:
    for name, path in procedures.items():
        archive.add(path, arcname=name)
with tarfile.open(out / 'procedures.tar.xz') as archive:
    for name, path in procedures.items():
        assert sha256(archive.extractfile(name).read()).hexdigest() == digest(path)
print('Verified the full worker image, 112 batches, archive and procedure copies.')
