from pathlib import Path
import shutil
lab=Path(__file__).parent; ancestor=lab.with_name('shared-locals-cpython-20261125')
read=lambda p:p.read_text(encoding='utf-8')
write=lambda name,s:(compile(s,name,'exec'),(lab/name).write_text(s,encoding='utf-8',newline='\n'))
source=read(ancestor/'prepare.py')
source=source.replace("baseline=lab.with_name('inline-defaults-cpython-20261124')", "baseline=lab.with_name('shared-locals-cpython-20261125')").replace("shared=lab.with_name('shared-function-local-slots-20261125')", "shared=lab.with_name('zip-unpack-20261125')").replace("callback=lab.with_name('direct-callback-return-20261125')", "callback=lab.with_name('shared-locals-cpython-20261125')")
source=source.replace("'788be8f35'", "'HEAD'").replace("'6b41db7b3',source", "'ac9f9211b',source")
source=source.replace("read(callback/'comparison/quiet/representative.json')", "read(callback/'external/representative.json')").replace("auxiliaryImageReference='B1662'", "auxiliaryImageReference='B1665'")
source=source.replace("baseline/'external/collect.py'", "baseline/'external/collect.py'").replace("b1656-fixtures','b1663-fixtures", "b1663-fixtures','b1669-fixtures").replace('Production CPython checkpoint for shared locals and borrowed callback returns', 'Production CPython checkpoint after direct zip unpacks').replace('shared-locals-cpython-b1663-20261125','post-zip-cpython-b1669-20261125')
source=source.replace("<330,'Leave time", "<330,'Leave time")
start=source.index('save(quiet/\'upload.json\'');end=source.index("compile(launcher,'quiet.py','exec')",start)
source=source[:start]+'''save(quiet/'upload.json',dict(root=location,reference='zip-unpack-b1665-20261125',
    payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
save(lab/'verified-raw-replicas.json',[])
previous=read(shared/'comparison/quiet/terminal-status.json')['receipt']
old_previous=read(baseline.with_name('shared-function-local-slots-20261125')/'comparison/quiet/terminal-status.json')['receipt']
assert previous['complete'] and previous['allWorkersJoined'] and sha(shared/'comparison/quiet/observations.tar.xz')==previous['archiveSHA256']
launcher=(baseline/'quiet.py').read_text(encoding='utf-8').replace('b1663','b1669')
launcher=launcher.replace('lython-b1669-shared-locals-cpython-20261125','lython-b1669-post-zip-cpython-20261125')
launcher=launcher.replace(old_previous['archiveSHA256'],previous['archiveSHA256'])
assert previous['archiveSHA256'] in launcher
'''+source[end:]
write('prepare.py',source)
archive=read(ancestor/'archive.py').replace('2026-11-25-shared-locals-cpython','2026-11-25-post-zip-cpython').replace("'build.log','prepare.log','verified-space.py','verify-and-free-space.py',\n    'verified-space.log','retired-stage-custody.json','launch.log'", "'build.log','prepare.log','prepare-lab.py','launch.log'")
write('archive.py',archive)
