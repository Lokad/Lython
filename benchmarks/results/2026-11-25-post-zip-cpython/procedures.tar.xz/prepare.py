from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
baseline=lab.with_name('shared-locals-cpython-20261125')
shared=lab.with_name('zip-unpack-20261125')
callback=lab.with_name('shared-locals-cpython-20261125')
quiet=lab/'external'
quiet.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
save=lambda p,d:write(p,json.dumps(d,ensure_ascii=False,indent=2)+'\n')
git=lambda args:subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
source=git(['rev-parse','HEAD'])
assert git(['rev-parse','HEAD'])==source
assert not git(['status','--short','--','src','benchmarks','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json'])
assert not git(['diff','--name-only','ac9f9211b',source,'--','benchmarks/Lokad.Lython.Benchmarks','benchmarks/cpython-worker.py',
    'src/Lokad.Lython.Utf8Regex','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json'])
old=read(baseline/'external/identity.json')
donor=read(shared/'comparison/quiet/identity.json')
assert old['auxiliaryFiles']=={n:s for n,s in donor['imageFiles']['candidate'].items() if n!='Lokad.Lython.dll'}
image=lab/'candidate'
image.mkdir(exist_ok=True)
core=lab/'production/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'
for name,digest in old['auxiliaryFiles'].items():
    path=shared/'candidate'/name
    assert sha(path)==digest
    shutil.copyfile(path,image/name)
shutil.copyfile(core,image/core.name)
files=old['auxiliaryFiles']|{core.name:sha(core)}
assert len(files)==32 and {p.name:sha(p) for p in image.iterdir()}==files
location='post-zip-cpython-b1669-20261125'
identity=dict(sourceRevision=source,candidate=source,productionSource=source,
    imageFiles={'candidate':files},frozenImage='/home/lokad/lython-bench-checks/'+location+'/candidate',
    auxiliaryFiles=old['auxiliaryFiles'],coreSHA256=dict(candidate=sha(core),**{'candidate-control':sha(core)}),
    expectedCPythonSHA256=old['expectedCPythonSHA256'],cpythonWorkerSHA256=old['cpythonWorkerSHA256'],
    auxiliaryImageReference='B1665',productionBuild='Fresh Release net11.0 build from the clean committed runtime and pinned SDK')

catalog=read(baseline/'external/representative.json')
routing=next(r for r in read(callback/'external/representative.json')['cases'] if r['id']=='diagnostic.shipment-routing-callbacks')
shipment=routing['id']
rule='scripts.rule-default-closures'
manifest='scripts.config-manifest.small'
invoice='scripts.csv-invoice.method-policy.quoted-control'
cases={r['id']:r for r in catalog['cases']}|{shipment:routing}
catalog['cases']=[cases[k] for k in (shipment,rule,manifest,invoice)]
catalog['fixtureEncoding']='Canonical file maps for the shipment report, manifest and invoice. Rules have no file fixture.'
jobs=[(shipment,'warm'),(rule,'compile'),(invoice,'warm'),(manifest,'warm'),(rule,'warm'),
      (shipment,'compile-run'),(manifest,'compile-run'),(rule,'compile-run')]
save(quiet/'representative.json',catalog)
save(quiet/'jobs.json',jobs)
identity['catalogs']={n:dict(sha256=sha(quiet/n)) for n in ('representative.json','jobs.json')}
save(quiet/'identity.json',identity)
protocol=repo/'benchmarks/cpython-worker.py'
assert sha(protocol)==identity['cpythonWorkerSHA256']
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
dotnet=sdk/'dotnet.exe'
proof=quiet/'candidate-verify.json'
subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'representative.json',
    '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',protocol,'--out',proof],env=env,cwd=repo,
    check=True,timeout=80)
checked=read(proof)
assert checked['state']=='Completed' and checked['caseCount']==4 and checked['catalogSha256']==identity['catalogs']['representative.json']['sha256']
assert checked['launched']['library']['sha256']==identity['coreSHA256']['candidate']
assert {p.name:sha(p) for p in image.iterdir()}==files
shutil.copyfile(baseline/'external/run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
collector=(baseline/'external/collect.py').read_text(encoding='utf-8').replace('b1663-fixtures','b1669-fixtures')
collector=collector.replace('len(jobs) == 9','len(jobs) == 8').replace('* .28','* .38').replace('*.28','*.38')
collector=collector.replace("<308,'Leave time", "<330,'Leave time")
collector=collector.replace('CPython checkpoint for lazy default tuples and consolidated compilation',
    'Production CPython checkpoint after direct zip unpacks')
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
summary=(baseline/'external/summarize.py').read_text(encoding='utf-8').replace('len(raw["jobs"])==9','len(raw["jobs"])==8').replace('receipt["warmJobs"]==9','receipt["warmJobs"]==8')
compile(summary,'summarize.py','exec')
write(quiet/'summarize.py',summary)
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=3) as bundle:
    for name in ('identity.json','jobs.json','representative.json','collect.py','run.sh'):
        bundle.add(quiet/name,arcname=name)
    bundle.add(core,arcname='candidate-core.dll')
assert sha(core)==files[core.name]
save(quiet/'upload.json',dict(root=location,reference='zip-unpack-b1665-20261125',
    payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
save(lab/'verified-raw-replicas.json',[])
previous=read(shared/'comparison/quiet/terminal-status.json')['receipt']
old_previous=read(baseline.with_name('shared-function-local-slots-20261125')/'comparison/quiet/terminal-status.json')['receipt']
assert previous['complete'] and previous['allWorkersJoined'] and sha(shared/'comparison/quiet/observations.tar.xz')==previous['archiveSHA256']
launcher=(baseline/'quiet.py').read_text(encoding='utf-8').replace('b1663','b1669')
launcher=launcher.replace('lython-b1669-shared-locals-cpython-20261125','lython-b1669-post-zip-cpython-20261125')
launcher=launcher.replace(old_previous['archiveSHA256'],previous['archiveSHA256'])
assert previous['archiveSHA256'] in launcher
compile(launcher,'quiet.py','exec')
write(lab/'quiet.py',launcher)
print('Verified the production image on four goldens and prepared eight execution and compilation lanes.')
