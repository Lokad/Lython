from pathlib import Path
import hashlib,json,shutil,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/'external'
out=repo/'benchmarks/results/2026-11-25-post-zip-cpython'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
terminal=read(quiet/'terminal-status.json')
receipt=terminal['receipt']
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode']=='0'
assert receipt['warmJobs']==8 and all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved',
    'quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert sha(quiet/'observations.tar.xz')==receipt['archiveSHA256']
identity=read(quiet/'identity.json')
summary=read(quiet/'summary.json')
assert identity['productionSource']==identity['sourceRevision']==summary['source']
assert summary['timedBatches']==224 and summary['cpythonExecutableSHA256']==identity['expectedCPythonSHA256']
assert [(v['case'],v['lane']) for v in summary['rows']]==list(map(tuple,read(quiet/'jobs.json')))
assert len(identity['imageFiles']['candidate'])==32 and {p.name:sha(p) for p in (lab/'candidate').iterdir()}==identity['imageFiles']['candidate']
with tarfile.open(quiet/'observations.tar.xz') as archive:
    for when in ('before','after'):
        assert json.load(archive.extractfile(f'confirmation/machine-{when}.json'))['gate']['quiet']
out.mkdir(exist_ok=True)
for name in ('identity.json','summary.json','terminal-status.json','observations.tar.xz'):
    shutil.copyfile(quiet/name,out/name)
members=['prepare.py','quiet.py','archive.py','build.log','prepare.log','prepare-lab.py','launch.log','retrieve.log','external/candidate-verify.json',
    'external/collect.py','external/summarize.py','external/run.sh','external/storage-custody.json']
with tarfile.open(out/'procedures.tar.xz','w:xz') as archive:
    for name in members:archive.add(lab/name,arcname=name,recursive=False)
with tarfile.open(out/'procedures.tar.xz') as archive:
    assert all(archive.extractfile(name).read()==(lab/name).read_bytes() for name in members)
