namespace Lokad.Lython.Frontend;

internal static class StateCostProbe
{
    internal static bool Enabled;
    internal static readonly long[] Counts = new long[10];

    internal static void RecordSnapshot(long stamp, int count)
    {
        if (!Enabled) return;
        Counts[0]++;
        Counts[1] += GC.GetAllocatedBytesForCurrentThread() - stamp;
        Counts[2] += count;
    }

    internal static void RecordRewrite()
    {
        if (Enabled) Counts[3]++;
    }

    internal static void RecordClone(long stamp, int bindings, int lengths)
    {
        if (!Enabled) return;
        Counts[4]++;
        Counts[5] += GC.GetAllocatedBytesForCurrentThread() - stamp;
        Counts[6] += bindings + lengths;
    }

    internal static void RecordPartition(long stamp, bool available, int count)
    {
        if (!Enabled) return;
        Counts[7] += GC.GetAllocatedBytesForCurrentThread() - stamp;
        if (available) Counts[8]++;
        Counts[9] += count;
    }
}
