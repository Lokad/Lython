from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess
lab=Path(__file__).resolve().parent
out=lab/"comparison"
probe=lab/"timed-compile"
catalog=probe/"catalog.json"
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
measured=read(out/"images.json")["imageFiles"]
sdk=Path.home()/".dotnet11"
core="Lokad.Lython.dll"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
images={}
for role in measured:
    image=out/("frozen-"+role)
    assert {n:sha(image/n) for n in measured[role]}==measured[role]
    timed=probe/role
    timed.mkdir(exist_ok=True)
    for name in ("CompileAllocation.dll","CompileAllocation.deps.json","CompileAllocation.runtimeconfig.json"):
        shutil.copyfile(probe/"bin/Release/net11.0"/name,timed/name)
    shutil.copyfile(image/core,timed/core)
    assert sha(timed/core)==measured[role][core]
    images[role]=timed
runs={}
for i,role in enumerate(("reference","candidate","candidate","reference")):
    output=probe/f"{i}-{role}.json"
    with output.open("wb") as stream:
        subprocess.run([sdk/"dotnet.exe",images[role]/"CompileAllocation.dll",catalog],env=env,stdout=stream,timeout=160,check=True)
    run=read(output)
    assert run["coreSha256"]==measured[role][core]
    runs.setdefault(role,[]).append(run)
    print("finished",i,role,flush=True)
for i in range(len(runs["reference"][0]["rows"])):
    key=runs["reference"][0]["rows"][i]["id"]
    times={role:[statistics.median(r["rows"][i]["elapsedMicroseconds"]) for r in pair] for role,pair in runs.items()}
    changes=sorted(100*(after/before-1) for before in times["reference"] for after in times["candidate"])
    print(key,times,[round(changes[0],2),round(changes[-1],2)],flush=True)
