from pathlib import Path
import concurrent.futures
import hashlib
import json
import os
import shutil
import statistics
import subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,value):
    p.write_text(json.dumps(value,indent=2,ensure_ascii=False)+"\n",encoding="utf-8",newline="\n")

out=lab/"comparison"
out.mkdir(exist_ok=True)
donor=lab.parent/"histogram-total-slots-20261122/comparison"
known=read(donor/"images.json")
manifest=known["imageFiles"]["reference"]
source=donor/"frozen-reference"
assert {n:sha(source/n) for n in manifest}==manifest
previous=lab.parent/"module-leading-indentation-20261122/comparison"
first=read(previous/"catalog.json")
ordered=lab.parent/"child-declaration-preparation-r668"
controls=read(ordered/"catalog.json")
cases=first["cases"][:4]+[next(c for c in controls["cases"] if c["id"]==key) for key in (
    "scripts.rule-default-closures","scripts.captured-rule-closures","scripts.config-manifest.small")]
inspection=read(ordered/"locals-order.json")
assert len(inspection["cases"])==1
cases+=inspection["cases"]
assert len(cases)==8 and len({c["id"] for c in cases})==8
catalog=out/"catalog.json"
save(catalog,dict(first,cases=cases,performanceQualified=False))
core="Lokad.Lython.dll"
adapter="Lokad.Lython.Utf8Regex.dll"
build={
    "reference":lab/"reference-build/bin/Lokad.Lython/release_net11.0"/core,
    "candidate":lab/"windows/bin/Lokad.Lython/release_net11.0"/core,
}
adapter_source=lab/"reference-build/bin/Lokad.Lython.Utf8Regex/release_net11.0"/adapter
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
protocol=repo/"benchmarks/cpython-worker.py"
assert sha(protocol)==known["protocolSHA256"]

def verify(role):
    image=out/("frozen-"+role)
    image.mkdir(exist_ok=True)
    files={**manifest,core:sha(build[role]),adapter:sha(adapter_source)}
    for name in files:
        path=build[role] if name==core else adapter_source if name==adapter else source/name
        shutil.copyfile(path,image/name)
    assert {p.name:sha(p) for p in image.iterdir()}==files
    proof=out/(role+"-verify.json")
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog,
        "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",proof],
        env=env,cwd=repo,check=True,timeout=100)
    verified=read(proof)
    assert verified["state"]=="Completed" and verified["caseCount"]==8 and verified["catalogSha256"]==sha(catalog)
    assert {p.name:sha(p) for p in image.iterdir()}==files
    return files

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    images=dict(zip(build,pool.map(verify,build),strict=True))
assert {name for name in manifest if images["reference"][name]!=images["candidate"][name]}=={core}
save(out/"images.json",dict(imageFiles=images,catalogSHA256=sha(catalog),protocolSHA256=sha(protocol)))
inspect_source=previous/"inspect-reference"
allocation_source=ordered/"compile-allocation/candidate"
tapes={}
measure={}
for role in build:
    isolated=out/("diagnostic-"+role)
    isolated.mkdir(exist_ok=True)
    for leaf in ("Inspect","CompileAllocation"):
        for ext in (".dll",".deps.json",".runtimeconfig.json"):
            name=leaf+ext
            shutil.copyfile((inspect_source if leaf=="Inspect" else allocation_source)/name,isolated/name)
    shutil.copyfile(out/("frozen-"+role)/core,isolated/core)
    shutil.copyfile(adapter_source,isolated/adapter)
    result=out/(role+"-tapes.json")
    subprocess.run([dotnet,isolated/"Inspect.dll",catalog,result],env=env,check=True,timeout=65)
    report=read(result)
    assert report["coreSHA256"]==images[role][core]
    tapes[role]=report["rows"]
    result=out/(role+"-compile-allocation.json")
    with result.open("wb") as stream:
        subprocess.run([dotnet,isolated/"CompileAllocation.dll",catalog],env=env,stdout=stream,check=True,timeout=100)
    report=read(result)
    assert report["coreSha256"]==images[role][core]
    measure[role]=report["rows"]
assert tapes["reference"]==tapes["candidate"]
print("Matching code objects",sum(len(row["codes"]) for row in tapes["reference"]),flush=True)
for before,after in zip(measure["reference"],measure["candidate"],strict=True):
    assert before["id"]==after["id"]
    left,right=[statistics.median(row["bytes"]) for row in (before,after)]
    print(before["id"],left,right,f"{100*(right/left-1):+.3f}%",flush=True)
