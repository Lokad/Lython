from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
out=Path('benchmarks/results/2026-11-19-prepared-format-selectors')
quiet=lab/'quiet'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda data:hashlib.sha256(data).hexdigest()
write=lambda p,d:p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n')
out.mkdir(exist_ok=False)
cases={c['id']:c for c in load(lab/'catalog.json')['cases']}
evidence=load(lab/'frozen-identity.json')
candidate=evidence['candidateCommit']
base=evidence['referenceCommit']
retained='b8532e0ef'
subprocess.run(['git','diff','--exit-code',candidate,retained,'--','src','tests'],check=True)
images=evidence['images']
terminal=load(quiet/'terminal-status.json')
receipt=load(quiet/'archive-receipt.json')
raw=load(quiet/'retrieved/confirmation/confirmation.json')
identity=load(quiet/'identity.json')
assert identity['catalogSHA256']==sha((lab/'catalog.json').read_bytes()) and identity['imageFiles']==images
assert terminal['receipt']==receipt and terminal['exitCode']=='0'
assert not terminal['remainingWorkers'] and not terminal['remainingTrace']
assert all(receipt[field] for field in ('complete','allWorkersJoined','guestFixturesRemoved',
                                       'quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert receipt['jobs']==7 and receipt['archiveSHA256']==sha((quiet/'observations.tgz').read_bytes())
assert raw['complete'] and len(raw['jobs'])==7
for job in raw['jobs']:
    assert job['workersJoinedAndFixturesRemoved'] and len(job['samples'])==20
    case=cases[job['case']]
    assert set(job['identities'])==set(identity['coreSHA256'])
    for role, worker in job['identities'].items():
        core=next(lib for lib in worker['libraries'] if Path(lib['path']).name=='Lokad.Lython.dll')
        assert core['sha256'].lower()==identity['coreSHA256'][role]
    for sample in job['samples']:
        response=sample['response']
        assert response['status']=='Completed' and response['completedInvocations']>0
        for key in ['sourceSha256','fixtureSha256','expectedOutputSha256']:
            assert response[key]==case[key]
        assert response['actualOutputSha256']==case['expectedOutputSha256']
        assert response.get('actualFilesSha256')==case.get('expectedFilesSha256')
summary=load(lab/'quiet-summary.json')
summary.update(referenceRuntime=base,measuredPrototype=candidate,cores=identity['coreSHA256'],
    archiveSHA256=receipt['archiveSHA256'],retentionDecisionPending=False,retainedCommit=retained,
    limits='Ordinary method format and other warm controls cross zero. Original workstation assembly kept.')
write(out/'summary.json',summary)
for name in ['observations.tgz','archive-receipt.json','terminal-status.json']:
    shutil.copyfile(quiet/name,out/name)
core=(lab/'frozen/candidate/Lokad.Lython.dll').read_bytes()
assert sha(core)==images['candidate']['Lokad.Lython.dll']
(out/'lython-core.dll.gz').write_bytes(gzip.compress(core,mtime=0))
source_patch=subprocess.check_output(['git','diff','--binary',base,candidate,'--','src','tests'])
assert b'+    private static FormatAccess PrepareFormatAccess' in source_patch
(lab/'measured-source.patch').write_bytes(source_patch)
with tarfile.open(out/'checks-and-procedures.tar.xz','w:xz',preset=6) as archive:
    for name in ['measured-source.patch','frozen-identity.json','catalog.json','verify-pair.py',
        'reference-verify.json','candidate-verify.json','reference-allocation.json','candidate-allocation.json',
        'quiet-space.json','canonical-space.py','preflight.json','stage-quiet.py','launch-quiet.py','summarize-quiet.py',
        'final-win-net11.log','final-wsl-net10.log','whitebox-win-net11.log','whitebox-wsl-net10.log',
        'template-win-net11.log','template-wsl-net10.log','focused-win-net11.log','selector-order.py',
        'probe-build-win-net11.log','archive-r598.py']:
        archive.add(lab/name,arcname=name)
    for name in ['config.json','identity.json','remote-launch.py','retrieve.py','retrieve-original.py',
                 'observe-not-before.json','launch.log']:
        archive.add(quiet/name,arcname='quiet/'+name)
    for p in sorted(quiet.glob('observation-*.json')):
        archive.add(p,arcname='quiet/'+p.name)
print('Verified all 140 timed golden batches, archive under lease, exact measured core and retained runtime source.')
