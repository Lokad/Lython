class Value:
    def __getitem__(self, key):
        print('getitem', key)
        return self

    @property
    def attr(self):
        print('attr')
        return 'X'

get = '{0[٢].attr}|{0[word].attr}'.format
bad = '{0[head][999999999999999999999999]}'.format
mixed = '{[head].attr} {1}'.format
for _ in range(2):
    print(get(Value()))
    for method in (bad, mixed):
        try:
            method(Value(), 3)
        except ValueError as exc:
            print(str(exc))
