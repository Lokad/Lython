from hashlib import sha256
from pathlib import Path
from shutil import copy2, copytree
import json
from subprocess import check_output

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.parent / 'private-generator-sum-b1940-20261128'
reference = donor / 'comparison'
pair = lab / 'comparison'
build = lab / 'ubuntu-artifacts/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
files = lambda folder: {path.name: digest(path) for path in folder.iterdir()}

def git(*args):
    return check_output(['git', *args], cwd=repo)

def write(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')

previous = read(reference / 'identity.json')
head = git('rev-parse', 'HEAD').decode().strip()
assert sha256(git('diff', '--binary', previous['sourceRevision'], head, '--', 'src/Lokad.Lython')).hexdigest() == previous['sourcePatchSHA256']
assert not git('diff', '--binary', previous['sourceRevision'], '--', 'src/Lokad.Lython.Utf8Regex', 'Directory.Packages.props')
prior_image = files(reference / 'candidate')
assert len(prior_image) == 32 and prior_image == previous['imageFiles']['candidate']
if not pair.exists():
    pair.mkdir()
    for role in ('reference', 'candidate'):
        copytree(reference / 'candidate', pair / role)
    copy2(build, pair / 'candidate/Lokad.Lython.dll')
images = {role: files(pair / role) for role in ('reference', 'candidate')}
assert images['reference'] == prior_image
assert images['candidate']['Lokad.Lython.dll'] == digest(build)
assert {name for name, checksum in prior_image.items() if images['candidate'][name] != checksum} == {'Lokad.Lython.dll'}
patch = git('diff', '--binary', 'HEAD', '--', 'src/Lokad.Lython')
(lab / 'candidate.patch').write_bytes(patch)
(lab / 'test.patch').write_bytes(git('diff', '--binary', 'HEAD', '--', 'tests'))

assert digest(reference / 'representative.json') == previous['catalogs']['representative.json']['sha256']
catalog = read(reference / 'representative.json')
ordinary = 'diagnostic.shipment-row-generator-reduction'
generic = 'diagnostic.shipment-row-range-generator-reduction'
file_search = 'diagnostic.file-search-first-line'
example = next(case for case in catalog['cases'] if case['id'] == ordinary)
source = example['source']
old = "row[key] == 'yes' for key in ('late', 'hold')"
new = "row[('late', 'hold')[index]] == 'yes' for index in range(2)"
assert source.count(old) == 1
source = source.replace(old, new).encode('utf-8')
control = dict(example, id=generic, source=source.decode('utf-8'),
               sourceSha256=sha256(source).hexdigest(), sourceUtf8Bytes=len(source))
catalog['cases'] = [control if case['id'] == file_search else case for case in catalog['cases']]
write(pair / 'representative.json', catalog)
jobs = read(reference / 'jobs.json')['warm']
jobs = [[generic if case == file_search else case, lane] for case, lane in jobs]
write(pair / 'jobs.json', {'warm': jobs})
write(pair / 'identity.json', dict(sourceRevision=head, sourcePatchSHA256=sha256(patch).hexdigest(), imageFiles=images,
    coreSHA256={label: images[role]['Lokad.Lython.dll'] for role in images for label in (role, role + '-control')},
    catalogs={name: {'sha256': digest(pair / name)} for name in ('representative.json', 'jobs.json')},
    cpythonWorkerSHA256=previous['cpythonWorkerSHA256'], expectedCPythonSHA256=previous['expectedCPythonSHA256'],
    purpose='Use one iterator object for exact Python lists and tuples while preserving live position and hints.'))
for name in ('run.sh', 'collect.py', 'cpython-worker.py'):
    copy2(reference / name, pair / name)
for name in ('summarize.py', 'measure-allocation.py'):
    copy2(donor / name, lab / name)
assert b'\r' not in (pair / 'run.sh').read_bytes()
print(head, len(jobs), 'lanes with exact baseline and candidate images')
