#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython
lab=.git/agent-notes/review-20261031/sequence-iterator-b1941-20261128
export NUGET_PACKAGES=$PWD/.git/agent-notes/review-20261031/regex-released-050-20261127/packages-ubuntu
for suite in white public; do
  if [[ $suite = white ]]; then
    proj=Lokad.Lython.Tests
    filter='Category!=Stress&(FullyQualifiedName~Generator|FullyQualifiedName~PyIteration|FullyQualifiedName~IteratorStorage|FullyQualifiedName~IterationWorkspace)'
  else
    proj=Lokad.Lython.PublicApi.Tests
    filter='Category!=Stress&(FullyQualifiedName~GeneratorExpressionBoundary|FullyQualifiedName~BuiltinIteratorSequence|FullyQualifiedName~OperatorProtocol|FullyQualifiedName~BuiltinIterationCancellation|FullyQualifiedName~IteratorScalarIdentity|FullyQualifiedName~NativeGeneratorSum|FullyQualifiedName~BufferedGeneratorContinuation)'
  fi
  log="$lab/ubuntu-$suite-net11.log"
  ~/.dotnet/dotnet test "tests/$proj/$proj.csproj" -c Release -f net11.0 --artifacts-path "$lab/ubuntu-artifacts" --filter "$filter" > "$log" 2>&1 || { tail -50 "$log"; exit 1; }
  tail -2 "$log"
done