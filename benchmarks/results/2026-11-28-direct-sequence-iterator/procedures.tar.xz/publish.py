from hashlib import sha256
from pathlib import Path
from shutil import copy2
from subprocess import check_output
import json
import re
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
bench = lab / 'comparison'
out = repo / 'benchmarks/results/2026-11-28-direct-sequence-iterator'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
identity = read(bench / 'identity.json')
for part, name in [('src/Lokad.Lython', 'candidate.patch'), ('tests', 'test.patch')]:
    patch = check_output(['git', 'diff', '--binary', identity['sourceRevision'], '--', part], cwd=repo)
    assert patch == (lab / name).read_bytes()
assert digest(lab / 'candidate.patch') == identity['sourcePatchSHA256']
for role, manifest in identity['imageFiles'].items():
    assert len(manifest) == 32 and {p.name: digest(p) for p in (bench / role).iterdir()} == manifest
assert {name for name, expected in identity['imageFiles']['reference'].items()
        if identity['imageFiles']['candidate'][name] != expected} == {'Lokad.Lython.dll'}
assert read(bench / 'summary.json')['verifiedTimedBatches'] == 140
receipt = read(bench / 'archive-receipt.json')
assert all(receipt[key] for key in ('complete', 'allWorkersJoined', 'guestFixturesRemoved', 'archivedAndVerifiedUnderLease'))
assert receipt['archiveSHA256'] == digest(bench / 'observations.tar.xz')
alloc = read(lab / 'allocation/summary.json')
assert len(alloc) == 8 and all(r['compiled'][0] == r['compiled'][1] and r['admittedPeak'][0] == r['admittedPeak'][1] for r in alloc)
expected = {'diagnostic.shipment-row-generator-reduction': -147400,
            'diagnostic.shipment-row-range-generator-reduction': 32768,
            'diagnostic.shipment-file-fed-map': 0}
for row in alloc:
    delta = row['clr'][1] - row['clr'][0]
    if row['case'] in expected:
        assert delta == expected[row['case']], row
    else:
        assert abs(delta) <= 230, row
logs = sorted([*lab.glob('windows-*-net*.log'), *lab.glob('ubuntu-*-net*.log')])
assert len(logs) == 6
for log in logs:
    count = 163 if '-public-' in log.name else 80
    assert re.search(rf'Failed: +0, Passed: +{count}, Skipped: +0', log.read_text(encoding='utf-8-sig')), log
out.mkdir(exist_ok=True)
artifacts = {name: bench / name for name in ('identity.json', 'summary.json', 'observations.tar.xz', 'archive-receipt.json')}
artifacts['allocation.json'] = lab / 'allocation/summary.json'
for name, source in artifacts.items():
    copy2(source, out / name)
    assert digest(out / name) == digest(source)
procedures = {p.name: p for p in logs}
for name in ('candidate.patch', 'test.patch', 'freeze.py', 'test-ubuntu.sh', 'ubuntu-core-build.log',
             'summarize.py', 'measure-allocation.py', 'publish.py', 'initial-freeze.txt'):
    procedures[name] = lab / name
for name in ('collection.log', 'reference-verify.json', 'candidate-verify.json', 'exit-code.txt'):
    procedures[name] = bench / name
procedures.update({f'allocation/{p.name}': p for p in (lab / 'allocation').glob('*.json')})
with tarfile.open(out / 'procedures.tar.xz', 'w:xz') as archive:
    for name, path in procedures.items():
        archive.add(path, arcname=name)
with tarfile.open(out / 'procedures.tar.xz') as archive:
    assert all(digest(path) == sha256(archive.extractfile(name).read()).hexdigest() for name, path in procedures.items())
print('Direct sequence iterator evidence verified.')
