#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython
lab=.git/agent-notes/review-20261031/sequence-iterator-refined-b1942-20261128
export NUGET_PACKAGES=$PWD/.git/agent-notes/review-20261031/regex-released-050-20261127/packages-ubuntu
filter='Category!=Stress&(FullyQualifiedName~GeneratorExpressionBoundary|FullyQualifiedName~ZipCompatibility|FullyQualifiedName~JsonBoundaryContract|FullyQualifiedName~JsonRoundTrip|FullyQualifiedName~OperatorProtocol)'
proj=tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj
log="$lab/final-ubuntu-net11.0.log"
~/.dotnet/dotnet test "$proj" -c Release -f net11.0 --artifacts-path "$lab/ubuntu-artifacts" --filter "$filter" > "$log" 2>&1 || { tail -50 "$log"; exit 1; }
tail -2 "$log"