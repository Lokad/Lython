$lab='.git/agent-notes/review-20261031/sequence-iterator-refined-b1942-20261128'
$sdk=Join-Path $env:USERPROFILE '.dotnet11/dotnet.exe'
$public='Category!=Stress&(FullyQualifiedName~GeneratorExpressionBoundary|FullyQualifiedName~BuiltinIteratorSequence|FullyQualifiedName~OperatorProtocol|FullyQualifiedName~BuiltinIterationCancellation|FullyQualifiedName~IteratorScalarIdentity|FullyQualifiedName~NativeGeneratorSum|FullyQualifiedName~BufferedGeneratorContinuation)'
$white='Category!=Stress&(FullyQualifiedName~Generator|FullyQualifiedName~PyIteration|FullyQualifiedName~IteratorStorage|FullyQualifiedName~IterationWorkspace)'
foreach ($framework in 'net11.0','net10.0') {
    foreach ($suite in 'public','white') {
        $project, $filter = if ($suite -eq 'public') { 'Lokad.Lython.PublicApi.Tests', $public } else { 'Lokad.Lython.Tests', $white }
        $log="$lab/windows-$suite-$($framework -replace '\.0$','').log"
        & $sdk test "tests/$project/$project.csproj" -c Release -f $framework --filter $filter *> $log
        $code=$LASTEXITCODE
        if ($code -ne 0) { Get-Content $log -Encoding utf8 -Tail 50; exit $code }
        Get-Content $log -Encoding utf8 -Tail 2
    }
}
