from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cases={
    'module-prefix': "bad: int = 'x'\nunused = 42\n",
    'semicolon-suite': "def f() -> int: value = 1; return 'x'\nunused = 42\n",
    'dead-branch-return': "def f() -> int:\n if False:\n  return 'x'\n return 1\n",
    'nested-default': "def outer():\n class Example:\n  def test(self, arg: int = 'x'): pass\n ignored = 1\n",
    'postponed-nested': "from __future__ import annotations\ndef outer():\n def f() -> int:\n  return 'x'\n unused = 42\n",
    'class-bound': "class Example:\n age: int = 'x'\n skipped = 0\n",
    'match-return': "def f(value) -> int:\n match value:\n  case 1: return 'x'\n return 1\n",
    'try-finally-return': "def f() -> int:\n try: return 0\n finally: return 'x'\n",
    'scope-reset': "def f() -> int:\n def g(): return 'valid'\n return 1\nprint(f())\n",
    'final-loop-check': "for value in []:\n bad: int = 'x'\ntrailing = 42\n",
    'multi-diagnostic-order': "def f(arg: int = 'x') -> int:\n a: float = 'x'\n return b'x'\nb: str = 1\n",
    'regex-full-flow': "import re as alias\ndef f():\n if False: alias.compile('(')\n",
    'valid-nested': "def f(value: int = 1) -> int:\n if value: return 2\n return 3\nprint(f())\n",
}
pair=load(lab/'frozen-identity.json')
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
reports={}
body=json.dumps(list(cases.values())).encode('utf-8')
for role,files in pair['images'].items():
    source=lab/'frozen'/role
    assert len(files)==32 and {name:sha(source/name) for name in files}==files
    image=lab/'probe'/role
    shutil.copytree(lab/'probe-build/bin/LythonProbe/release_net11.0',image)
    for file in image.glob('Lokad.*.dll'):
        if file.name in files:
            shutil.copyfile(source/file.name,file)
            assert sha(file)==files[file.name]
    for async_mode in (False,True):
        args=[sdk/'dotnet.exe',image/'LythonProbe.dll','--batch-json']
        if async_mode:args.append('--async')
        process=subprocess.run(args,input=body,capture_output=True,timeout=45,env=env)
        assert process.returncode==1,(process.stderr,process.stdout)
        reports[role,async_mode]=[json.loads(line)['Lython'] for line in process.stdout.splitlines()]
        assert len(reports[role,async_mode])==len(cases)
        assert all(not (row['Failure'] or {}).get('ExceptionType','').startswith('CLR:') for row in reports[role,async_mode])
        (lab/f'probe-{role}-{async_mode}.jsonl').write_bytes(process.stdout)
sample=reports['reference',False]
codes={d['Code'] for row in sample for d in row['Diagnostics']}
assert {'LA1080','LA1081','LA1082'}<=codes
fields=('Success','StandardOutput','StandardError','ExitCode','Diagnostics','Failure')
for mode in (False,True):
    for label,before,after in zip(cases,reports['reference',mode],reports['candidate',mode],strict=True):
        assert all(before[key]==after[key] for key in fields),(label,before,after)
print(f'{len(cases)} probes match diagnostic order, failures and output across both images in sync and async modes.')
(lab/'probe-cases.json').write_bytes(body)
