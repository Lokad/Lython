from pathlib import Path
import gzip,hashlib,json,subprocess

lab=Path(__file__).resolve().parent
base='/home/lokad/lython-bench-checks'
wanted={}
for line in (lab/'remote-core-candidates.txt').read_text(encoding='utf-8-sig').splitlines():
    _,inode,size,path=line.split(maxsplit=3)
    assert path.endswith('/Lokad.Lython.dll') and not path.startswith('/')
    wanted.setdefault(inode,(int(size),path))
remote="""
from pathlib import Path
import fcntl,hashlib,json,shutil,os,stat
base=Path(BASE)
with (base/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    known={}
    for size,name in WANTED:
        path=base/name
        assert path.resolve()==path and path.is_relative_to(base)
        info=path.lstat()
        assert stat.S_ISREG(info.st_mode) and info.st_uid==os.getuid() and info.st_size==size
        key=info.st_dev,info.st_ino
        known[key]=dict(bytes=size,links=info.st_nlink,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),paths=[])
    for folder,_,names in os.walk(base):
        for name in names:
            if name!='Lokad.Lython.dll':continue
            path=Path(folder)/name
            info=path.lstat()
            entry=known.get((info.st_dev,info.st_ino))
            if entry is not None:
                assert path.resolve()==path and path.is_relative_to(base)
                entry['paths'].append(str(path.relative_to(base)))
    print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,replicas=[
        {**entry,'paths':sorted(entry['paths'])} for entry in known.values()
        if len(entry['paths'])==entry['links']])))
""".replace('BASE',repr(base)).replace('WANTED',repr(list(wanted.values())))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes',
    '-o','ConnectTimeout=15','lokad@20.166.121.73','python3 -']
result=subprocess.run(ssh,input=remote.encode('utf-8'),capture_output=True,check=True,timeout=45)
state=json.loads(result.stdout)
pair=json.loads((lab/'frozen-identity.json').read_text(encoding='utf-8'))
active={files['Lokad.Lython.dll'] for files in pair['images'].values()}
by_hash={entry['sha256']:entry for entry in state['replicas'] if entry['sha256'] not in active}
paths=dict.fromkeys(p for p in subprocess.check_output(['git','log','-n','105','--pretty=format:','--name-only',
    '--','benchmarks/results/*/*core.dll.gz']).decode().splitlines() if p.endswith('core.dll.gz'))
head=subprocess.check_output(['git','rev-parse','HEAD']).decode().strip()
verified=[]
remaining=state['freeBytes']
target=168*1024*1024+12*1024*1024
with subprocess.Popen(['git','cat-file','--batch'],stdin=subprocess.PIPE,stdout=subprocess.PIPE) as git:
    for path in paths:
        git.stdin.write(f'{head}:{path}\n'.encode('utf-8'))
        git.stdin.flush()
        header=git.stdout.readline().split()
        if len(header)!=3 or header[1]!=b'blob':continue
        packed=git.stdout.read(int(header[2]))
        assert git.stdout.read(1)==b'\n'
        core=gzip.decompress(packed)
        digest=hashlib.sha256(core).hexdigest()
        if digest not in by_hash:continue
        replica=by_hash.pop(digest)
        assert replica['bytes']==len(core)
        verified.append(dict(replica,committedBlobVerified=True,canonicalCommit=head,canonicalPath=path,
            canonicalBlob=header[0].decode()))
        remaining+=replica['bytes']
        if remaining>=target:break
    git.stdin.close()
assert git.returncode==0
report=dict(freeBytes=state['freeBytes'],replicas=verified,provedAvailableBytes=remaining)
(lab/'quiet-space.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
print(f'{len(verified)} byte-identical core replicas archived in Git; {remaining} bytes available if retired.')
