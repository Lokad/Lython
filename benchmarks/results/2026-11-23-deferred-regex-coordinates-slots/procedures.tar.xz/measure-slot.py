from pathlib import Path
import hashlib
import io
import tarfile
import json
import os
import shutil
import statistics
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
tree = repo / ".git/agent-worktrees/regex-byte-capture-20261123"
previous = lab.parent / "borrowed-csv-record-20261123" / "comparison-rebased"
out = lab / "comparison-slot"
out.mkdir()
def read(p): return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(data): return hashlib.sha256(data).hexdigest()
def digest(p): return sha(p.read_bytes())
def save(p, value): p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
def git(*args, cwd=repo): return subprocess.check_output(["git", *args], cwd=cwd)

core = "Lokad.Lython.dll"
published = read(repo / "benchmarks/results/2026-11-23-borrowed-csv-record/source.json")
known = published["imageFiles"]["candidate"]
reference = previous / "frozen-candidate"
assert len(known) == 32 and {n: digest(reference / n) for n in known} == known
base = git("rev-parse", "e8fd8b73f", cwd=tree).decode().strip()
assert not git("diff", "--name-only", published["retainedRevision"], base, "--", "src", "tests")
patch = git("diff", "--binary", base, "--", "src", "tests", cwd=tree)
assert patch.count(b"diff --git ") == 4
(out / "source.patch").write_bytes(patch)
python = Path("C:/Python313/python.exe")

catalog = out / "representative.json"
def archived(name):
    folder=f"benchmarks/results/{name}"
    read_git=lambda f:git("show",f"origin/master:{folder}/{f}")
    receipt=json.loads(read_git("archive-receipt.json"))
    raw=read_git("observations.tgz")
    assert receipt["complete"] and receipt["archivedAndVerifiedUnderLease"] and sha(raw)==receipt["archiveSHA256"]
    with tarfile.open(fileobj=io.BytesIO(raw))as t:
        return json.load(t.extractfile("representative.json"))

catalog_value = archived("2026-11-22-regex-provider-state")
cases = catalog_value["cases"]
template = next(c for c in cases if c["id"] == "scripts.regex-unicode-groups")
control = '''
import re
body = ('é' * 128 + '😀') * 80
pattern = re.compile(r'(é{128}😀)' * 80)
total = 0
for repeat in range(32):
    match = pattern.fullmatch(body)
    total += sum(right - left for left, right in match.regs)
    total += match.start(37) + match.end(40)
print(total)
'''.lstrip()
output = subprocess.check_output([python, "-I", "-S", "-X", "utf8", "-c", control],
    timeout=20).decode("utf-8").replace("\r\n", "\n")
cases.append(dict(template,id="diagnostic.regex-wide-registers",source=control,expectedOutput=output,
    sourceUtf8Bytes=len(control.encode()),sourceSha256=sha(control.encode()),
    expectedOutputUtf8Bytes=len(output.encode()),expectedOutputSha256=sha(output.encode())))
narrow = template["source"].replace("pattern.finditer(text)", "pattern.finditer(text, 1024, len(text)-573)")
narrow = narrow.replace("    total += len(match.group('id')) + len(match.group('state')) + len(match.group('zone'))",
    "    start, end = match.span('zone')\n    total += start + end + len(match.group('id'))")
assert narrow != template["source"] and "match.span" in narrow
output = subprocess.check_output([python, "-I", "-S", "-X", "utf8", "-c", narrow],
    timeout=20).decode("utf-8").replace("\r\n", "\n")
cases.append(dict(template,id="diagnostic.regex-interleaved-narrow-offsets",source=narrow,expectedOutput=output,
    sourceUtf8Bytes=len(narrow.encode()),sourceSha256=sha(narrow.encode()),
    expectedOutputUtf8Bytes=len(output.encode()),expectedOutputSha256=sha(output.encode())))
assert len(cases) == 7
save(catalog, catalog_value)

sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk)+os.pathsep+os.environ["PATH"])
protocol = repo / "benchmarks/cpython-worker.py"
assert digest(protocol) == published["protocolSHA256"]

images, allocation = {}, {}
candidate = tree / "src/Lokad.Lython/bin/Release/net11.0" / core
for role, built in (("reference", reference / core), ("candidate", candidate)):
    image = out / f"frozen-{role}"
    image.mkdir()
    files = {**known, core: digest(built)}
    for name in files:
        shutil.copyfile(built if name == core else reference / name, image / name)
    assert {n: digest(image / n) for n in files} == files
    images[role] = files
    for suffix in (".dll", ".deps.json", ".runtimeconfig.json"):
        name = "ValidatedAllocation" + suffix
        shutil.copyfile(reference / name, image / name)
    proof = out / f"{role}-verify.json"
    subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog", catalog,
        "--dotnet", dotnet, "--python", python, "--python-worker", protocol, "--out", proof],
        env=env, cwd=repo, check=True, timeout=90)
    state = read(proof)
    assert state["state"] == "Completed" and state["catalogSha256"] == digest(catalog) and state["caseCount"] == 7
    report = out / f"{role}-allocation.json"
    subprocess.run([dotnet, image / "ValidatedAllocation.dll", image, catalog, report],
        env=env, cwd=repo, check=True, timeout=85)
    rows = read(report)["rows"]
    assert len(rows) == 7 and all(r["sharedBudgetBaselineRestored"] for r in rows)
    allocation[role] = rows
    assert {n: digest(image / n) for n in files} == files

save(out / "identity.json", dict(reference=base, verifiedReferenceSource=published["candidate"], patchBase=base,
    sourcePatchSHA256=sha(patch), imageFiles=images, protocolSHA256=digest(protocol), catalogSHA256=digest(catalog)))
for before, after in zip(allocation["reference"], allocation["candidate"], strict=True):
    assert before["id"] == after["id"]
    a, b = (statistics.median(x["allocatedBytesPerInvocation"]) for x in (before, after))
    print(before["id"], a, b, b - a, round(100 * (b / a - 1), 3),
        before["peakExecutionMemoryBytes"], after["peakExecutionMemoryBytes"], flush=True)
