from pathlib import Path
import ast,hashlib,json,shutil,tarfile
r=Path(__file__).parent;old=r.parent/'receiver-calls-r464/quiet';q=r/'quiet';q.mkdir(exist_ok=False)
remote='/home/lokad/lython-bench-checks/json-token-scan-b875-20261117'
frozen=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))
jobs=[['scripts.report-render.helper-list','warm'],['scripts.report-render.helper-list','compile-run'],['scripts.json-summary-helpers.large','warm'],['scripts.json-summary-helpers.large','compile-run'],['scripts.text-normalization.helper-list','warm']]
collect=(old/'collect.py').read_text(encoding='utf-8');a=collect.index('jobs=');b=collect.index('\n\nenv =',a)
collect=collect[:a]+'jobs='+repr(jobs)+"\nassert len(jobs)==5 and all(case in cases for case,lane in jobs)"+collect[b:]
(q/'collect.py').write_text(collect,encoding='utf-8',newline='\n')
(q/'archive-owned.py').write_text((old/'archive-owned.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==7","len(raw['jobs'])==5").replace('jobs=7','jobs=5'),encoding='utf-8',newline='\n')
(q/'run.sh').write_text((old/'run.sh').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/receiver-calls-b871-20261117',remote),encoding='utf-8',newline='\n')
reference=frozen['imageFiles']['reference']['Lokad.Lython.dll'];candidate=frozen['imageFiles']['candidate']['Lokad.Lython.dll']
identity=dict(sourceRevision='Qualifiedccf20ba3/frozen7a599347 versus privateR469 basec882e206/frozen'+candidate,purpose='R469 existing JSON decoder bulk ordinary-byte token scanning; complete helper report/JSON-lines warm/fresh with unchanged helper-text control. No second parser or admission/ownership change.',coreSHA256={'reference':reference,'reference-control':reference,'candidate':candidate,'candidate-control':candidate},auxiliaryFiles={n:h for n,h in frozen['imageFiles']['reference'].items()if n!='Lokad.Lython.dll'},imageFiles=frozen['imageFiles'],sourceInputs=frozen['sourceInputs'],productionFiles=frozen['productionFiles'],catalogSHA256=frozen['catalogSHA256'],catalogInitialization=frozen['catalogInitialization'],normalAdapterPin='0.4.0',fullQualification=False,publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(r/'catalog.json',q/'representative.json');(q/'candidate').mkdir();shutil.copyfile(r/'frozen/candidate/Lokad.Lython.dll',q/'candidate/Lokad.Lython.dll')
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for name in ['collect.py','archive-owned.py','run.sh','identity.json','representative.json','candidate/Lokad.Lython.dll']:a.add(q/name,arcname=name)
config=dict(root=remote,unit='lython-b875-json-token-scan-20261117',source='/home/lokad/lython-bench-checks/phase-attribution-b873-20261117',sourceRole='candidate',sourceFiles=frozen['imageFiles']['reference'],sourceCatalogSHA256='273dcea08df5b59a40fb86f71013a0520b210c407cdd0b078e986a463fac9e7c',catalogSHA256=frozen['catalogSHA256'],identity=identity,retireGroups=json.loads((r/'retirement-proof.json').read_text(encoding='utf-8'))['retireGroups'],payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum((q/n).stat().st_size for n in ['collect.py','archive-owned.py','run.sh','identity.json','representative.json','candidate/Lokad.Lython.dll']))
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
launch=(old/'remote-launch.py').read_text(encoding='utf-8');a=launch.index('c=');b=launch.index('\nb=Path(',a);launch=launch[:a]+'c='+repr(config)+launch[b:]
launch=launch.replace('lython-b871-fixtures','lython-b875-fixtures');(q/'remote-launch.py').write_text(launch,encoding='utf-8',newline='\n')
launch=(old.parent/'launch.py').read_text(encoding='utf-8').replace('seconds=220','seconds=180').replace('seconds=200','seconds=180').replace('seconds=230','seconds=180').replace('Seven-job','Five-job').replace('seven-job','five-job')
if 'seconds=180'not in launch:
 import re
 launch=re.sub(r'timedelta\(seconds=\d+\)','timedelta(seconds=180)',launch)
(r/'launch.py').write_text(launch,encoding='utf-8',newline='\n')
(q/'retrieve.py').write_text((old/'retrieve.py').read_text(encoding='utf-8').replace("['jobs']==7","['jobs']==5").replace('B871','B875'),encoding='utf-8',newline='\n')
(r/'summarize.py').write_text((old.parent/'summarize.py').read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
for p in list(q.glob('*.py'))+[r/'launch.py',r/'summarize.py']:ast.parse(p.read_text(encoding='utf-8'))
print('Prepared five-job quiet source pair: unchanged32file worker/adapter except core; payload',config['payloadBytes'],'unpacked',config['unpackedBytes'])
