from pathlib import Path
import gzip,hashlib,json,shutil,tarfile,xml.etree.ElementTree as ET
base=Path('D:/code/Lython');r=Path(__file__).parent;out=base/'benchmarks/results/2026-11-17-json-token-scan';out.mkdir(exist_ok=False)
summary=json.loads((r/'summary.json').read_text(encoding='utf-8'));summary.update(retentionDecisionPending=False,decision='Withdraw bulk-search prototype; retain six independent public boundary cases. No production change.',reason='Representative JSON-lines warm is flat/adverse and fresh consistently slower with supporting CPU; tiny report warm effect does not justify that debt. No fixed-percentage veto or permanent design ban.')
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
receipt=json.loads((r/'quiet/archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['allWorkersJoined']and receipt['guestFixturesRemoved']and receipt['quietBeforeAndAfter']
assert hashlib.sha256((r/'quiet/observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
checks=[]
for p in sorted(r.glob('*.trx')):
 counters=ET.parse(p).getroot().find('.//{*}Counters');assert int(counters.attrib.get('failed','0'))==0
 checks.append(dict(file=p.name,passed=int(counters.attrib['passed'])))
validation=dict(retainedProductionChange=False,withdrawn=True,independentNewPublicCases=6,checks=checks,overlappingFiltersNotSummed=True,eachActualWindowsTargetUnchangedRuntimeBoundaryCases=28,initialPrototypeNet11=dict(internal=213,publicBeforeFinalThreeCases=969),initialPrototypeNet10=dict(internal=213,public=972),frozenGoldenCasesEachImage=12,physicalAllocation='Essentially flat; affected accounted peaks unchanged. Each run returns to compiled baseline and final disposal to zero.',fullPlatformStressPackageQualification='Not repeated for withdrawn runtime; only independent tests retained.',publicationHeld=True)
(out/'validation.json').write_text(json.dumps(validation,indent=2)+'\n',encoding='utf-8',newline='\n')
for source,name in [(r/'quiet/observations.tgz','observations.tgz'),(r/'quiet/archive-receipt.json','archive-receipt.json'),(r/'quiet/terminal-status.json','terminal-status.json'),(r/'frozen/identity.json','identity.json'),(r/'allocation-summary.json','allocation-summary.json'),(r/'candidate-sources.tar.xz','candidate-sources.tar.xz'),(r/'prototype.patch','prototype.patch'),(r/'boundary-cpython.json','boundary-cpython.json')]:shutil.copyfile(source,out/name)
with tarfile.open(out/'procedures-and-checks.tar.xz','w:xz')as a:
 for p in list(r.glob('*.py'))+list(r.glob('*.log'))+list(r.glob('*.trx'))+[r/'catalog.json',r/'catalog11.json',r/'retirement-proof.json',r/'initial11-allocation-summary.json',r/'initial11-preflight-reference.json',r/'initial11-preflight-candidate.json',r/'preflight-reference.json',r/'preflight-candidate.json']:
  a.add(p,arcname=p.relative_to(r).as_posix())
 for p in (r/'quiet').glob('*'):
  if p.is_file()and p.name not in ['payload.tgz','observations.tgz']:a.add(p,arcname=p.relative_to(r).as_posix())
for role in ['reference','candidate']:
 data=(r/'frozen'/role/'Lokad.Lython.dll').read_bytes()
 with gzip.open(out/(role+'-core.dll.gz'),'wb')as f:f.write(data)
 with gzip.open(out/(role+'-core.dll.gz'),'rb')as f:assert f.read()==data
(out/'README.md').write_text('''# Bulk JSON string scan: withdrawn

R469/B875, 2026-11-17 UTC. Qualified ccf20ba3 / frozen 7a599347 versus private
c882e206 + one production-file prototype / frozen 06797383. **Withdraw this shape;
production scanning remains unchanged.** Six useful public boundary cases survive.

The prototype replaces ordinary per-byte token classification with bounded bulk
delimiter/control searches in the existing decoder. It preserves escape handling,
UTF-8 validation, strict/non-strict behavior, scalar errors, ownership/preflights
and the existing 1,024-byte cancellation boundary. No second parser, memory credits,
policy, cache or option. It does not establish a whole-script improvement:

| Complete workload | Phase | Candidate elapsed change | Wider process CPU change | Reference / candidate control spread |
| --- | --- | ---: | ---: | ---: |
| Helper-list report, 3,072 records | Warm | −1.70..−0.39% | −4.51..+0.32% | 1.18 / 0.16% |
| Same report | Compile and execute once | −2.20..+4.54% | −0.56..+7.25% | 0.91 / 5.93% |
| JSON-lines helpers, 4,096 records | Warm | +0.07..+1.04% | −2.14..0.00% | 0.60 / 0.37% |
| Same JSON-lines script | Compile and execute once | +1.20..+3.16% | +1.31..+3.77% | 0.83 / 1.10% |
| Helper-list normalization, unchanged | Warm control | −1.89..+0.41% | −2.41..+0.09% | 0.54 / 1.79% |

All four independent-process median pairings are retained, not confidence
intervals. Report warm has a small favorable elapsed effect and mixed CPU; fresh
is inconclusive with a moving candidate. JSON fresh consistently regresses with
supporting CPU and close controls. Allocation is essentially flat; all accounted
peaks are unchanged. The small report effect does not justify the JSON debt.
Possible short-token search overhead is a hypothesis, not an isolated cause.
No permanent design ban or fixed-percentage veto; a different coherent design
would need different eliminated work. No preferred-sign confirmation or ad hoc
short-string route is introduced. Broader whole-script work continues.

Initial actual Windows net11: 969 public / 213 internal; final 28 escaped/boundary
cases pass. Actual net10: 972 public / 213 internal. Filters overlap and are not
summed. After withdrawing production, the 28 boundary cases pass again on each
actual target. New cases cover escaped Unicode around long-token boundaries and
strict control errors/non-strict values with non-BMP scalar positions; retained
results stay charged and cleanup restores baseline. Local CPython 3.13.2
independently confirms new expected values/positions. No assertion or timeout
relaxed. Full platform/stress/package checks are not replayed for this withdrawal.

Both frozen 32-file images differ only in core; worker and normal optional 0.4
adapter assets are fixed. A nonincremental Release build precedes freezing.
All twelve cases pass actual frozen-worker/local CPython golden verification.
The fixed catalog is the prior eleven cases plus the unchanged existing R461
JSON-lines helper case. Initial eleven-case verification/allocation diagnostics
are preserved separately; they are not this final catalog or quiet comparison.
Natural-GC allocation diagnostics return to the compiled baseline after every run,
and zero after final disposal. Local first-use timings remain diagnostic only.

Five jobs / 153.70 s, quiet existing Azure F4as_v7 / Ubuntu 24.04.4, four EPYC
9V45 vCPUs, 16 GiB/no swap, .NET 11 RC3 normal tiering/workstation GC. Two
independent processes per source, 4 s full-request warmups and five rotated
approximately 0.5 s samples. Warm includes mediated RAM I/O, full stdout/files
and prior-result cleanup; excludes compilation, startup, fixture reset/protocol
and final cache teardown. Fresh adds compilation and compiled-owner disposal.
External CPU includes reset/protocol. No CPython performance refresh, async,
RSS, pending-I/O or embedding-tail claim.

All identities/goldens/quiet/Closed/exit/join/archive gates pass. All users joined
and RAM fixtures removed after persistent evidence verification. Six exact old
committed raw JSON replicas (9,597,649 B) retired after fresh owner/path/SHA,
link-count and all-inode-alias proof. Current images/toolchains/canonicals and
254/252 MiB staging/final floors preserved. Terminal cached permanently; no
unchanged requery, profiling or qualification. Publication/tagging held.

[Summary](summary.json), [allocation](allocation-summary.json),
[validation](validation.json), [raw observations](observations.tgz),
[sources](candidate-sources.tar.xz), [prototype patch](prototype.patch),
[frozen image identities](identity.json), [procedures/checks/original diagnostics](procedures-and-checks.tar.xz),
[independent CPython boundary results](boundary-cpython.json),
[reference core](reference-core.dll.gz), [withdrawn core](candidate-core.dll.gz),
[custody](archive-receipt.json), [terminal](terminal-status.json).
''',encoding='utf-8',newline='\n')
source=base/'.git/agent-worktrees/json-tokens-r469/tests/Lokad.Lython.PublicApi.Tests/EscapedJsonStringTests.cs'
shutil.copyfile(source,base/'tests/Lokad.Lython.PublicApi.Tests/EscapedJsonStringTests.cs')
p=base/'benchmarks/EXPERIMENTS.md'
with p.open('a',encoding='utf-8',newline='\n')as f:f.write('''
[R469/B875 bulk JSON token scanning](results/2026-11-17-json-token-scan/README.md): withdraw06797383 versus qualified7a599347 after5jobs154s/all gates. Report warm elapsed−1.70..−0.39%with mixedCPU;fresh inconclusive/movingcandidate5.93%. JSONwarmflat,fresh+1.20..+3.16%elapsed/+1.31..+3.77%CPU with closecontrols; unchangedtextstraddleszero. Allocation/peaks flat. No fixed threshold or permanent design ban; small report effect does not justify freshJSONdebt. Six independent long Unicode/control/ownership cases retained,28classcases pass actual11/10 again on unchanged runtime. Twelve frozen goldens and focused213internal/969→972public pass; filters overlap. Full qualification not replayed; publication held.
''')
print('Withdrawn source/measurements preserved; six independent tests promoted, unchanged production.')
