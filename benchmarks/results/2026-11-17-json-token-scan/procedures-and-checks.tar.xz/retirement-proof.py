from pathlib import Path
import hashlib,io,json,subprocess,tarfile
base=Path('D:/code/Lython');r=Path(__file__).parent
inventory=json.loads((r.parent/'receiver-calls-r464/vm-idle-raw-inventory.json').read_text(encoding='utf-8'))
desired=['delivery-comparison-b388-','delivery-comparison-b380-','delivery-comparison-b395-','native-inputs-b597-','word-materialization-b595-','flat-operands-b207-','native-call-boundary-b116-','receiver-ops-b602-']
targets={p['bytes']:p for p in inventory if any(part in p['path']for part in desired)}
assert len(targets)==8
tracked=subprocess.check_output(['git','ls-files','-z','--','benchmarks/results'],cwd=base).decode().split('\0')
paths=[
 'benchmarks/results/2026-11-04-executable-storage/initial-observations.tgz',
 'benchmarks/results/2026-11-07-completed-call-cpython/observations.tgz',
 'benchmarks/results/2026-11-07-formatted-cpython/observations.tgz',
 'benchmarks/results/2026-11-07-receiver-cpython/observations.tgz',
 'benchmarks/results/2026-11-12-native-inputs/quiet/observations.tgz',
]+[name for name in tracked if '/2026-11-11-native-word-probing/'in name and name.endswith('observations.tgz')]

proofs=[];scanned=0
for name in paths:
 scanned+=1
 if scanned>140:break
 with tarfile.open(base/name)as a:
  try:member=a.getmember('confirmation/confirmation.json')
  except KeyError:continue
  if member.size not in targets:continue
  data=a.extractfile(member).read()
 original=targets.pop(len(data));blob=(base/name).read_bytes()
 assert subprocess.check_output(['git','show','HEAD:'+name],cwd=base)==blob
 proofs.append(dict(paths=[original['path']],bytes=len(data),links=original['links'],sha256=hashlib.sha256(data).hexdigest(),canonical=name,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='confirmation/confirmation.json',committedBlobVerified=True))
 if sum(p['bytes']for p in proofs)>9500000:break
assert sum(p['bytes']for p in proofs)>9500000,(scanned,proofs)
(r/'retirement-proof.json').write_text(json.dumps(dict(scannedCanonicalArchives=scanned,retireGroups=proofs,totalBytes=sum(p['bytes']for p in proofs),mustRevalidateIdleLeaseOwnerPathsHashesAllInodeAliasesBeforeMutation=True),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Exact committed archive/member proofs:',len(proofs),'raw files,',sum(p['bytes']for p in proofs),'bytes. Fresh VM proof still required.')
for proof in proofs:print(proof['paths'][0],proof['canonical'])
