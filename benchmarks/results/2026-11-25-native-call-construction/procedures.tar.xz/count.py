from pathlib import Path
import hashlib, json, os, shutil, subprocess, tarfile, zipfile

repo=Path.cwd()
base=repo/".git/agent-notes/review-20261031"
lab=base/"native-call-construction-20261125"
lab.mkdir(exist_ok=True)
frozen=lab/"source"
def git(*args):
    return subprocess.check_output(["git",*args],cwd=repo)
def read(path):
    return json.loads(path.read_text(encoding="utf-8"))
def write(path,text):
    path.write_text(text,encoding="utf-8",newline="\n")
def save(path,value): write(path,json.dumps(value,ensure_ascii=False,indent=2)+"\n")
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
base_revision=git("rev-parse","7ed1caa74").decode().strip()
assert git("rev-parse","HEAD").decode().strip()==base_revision
archive=lab/"source.zip"
fields=("global.json","Directory.Build.props","Directory.Build.targets","Directory.Build.rsp","Directory.Packages.props","NuGet.Config")
git("archive","--format=zip",f"--output={archive}",base_revision,"--",*fields,"src/Lokad.Lython")
with zipfile.ZipFile(archive) as bundle:
    bundle.extractall(frozen)
    for name in bundle.namelist():
        if not name.endswith("/"): assert (frozen/name).read_bytes()==bundle.read(name)

names=("DirectScalarReturns","CaptureDefinitions","ComputedDefinitions","DefaultedPairs","CapturedPairs",
       "PositionalWorkspaces","PositionalOperandsCopied","BoundWorkspaces","CallbackWorkspaces",
       "FinishedNativePrefixes","TransferredNativePrefixes","RentedContinuations","ContinuationSlotsCopied")
source=frozen/"src/Lokad.Lython/Runtime/PyExecutableFunction.cs"
original=source.read_text(encoding="utf-8")
s=original
def replace(old,new):
    global s
    assert s.count(old)==1, old
    s=s.replace(old,new)
def count(name):
    return "Interlocked.Increment(ref Diagnostic"+name+");"
replace("internal sealed class PyExecutableFunction : PyFunctionBase\n{\n",
        "internal sealed class PyExecutableFunction : PyFunctionBase\n{\n"+"".join(f"    internal static int Diagnostic{name};\n" for name in names)+"\n")
replace("        if (completePositional)\n        {\n            var first", 
        "        if (completePositional)\n        {\n            "+count("PositionalWorkspaces")+
        "\n            Interlocked.Add(ref DiagnosticPositionalOperandsCopied, arguments.Length + (receiver is null ? 0 : 1));\n            var first")
replace("""        else LythonRuntime.BindFunctionArgumentsInto(values[..ParameterCount],
            [], span, this, context, out _, receiver: receiver, callSite: call, operands: arguments);""",
        """        else
        {
            """+count("BoundWorkspaces")+"""
            LythonRuntime.BindFunctionArgumentsInto(values[..ParameterCount],
                [], span, this, context, out _, receiver: receiver, callSite: call, operands: arguments);
        }""")
replace("                    if (CodeObject.HasDirectCapturedDefinitionPair)\n                        LythonRuntime.CompleteClosedCapturedPair(CodeObject, Closure, integerArgument, destination);\n                    else LythonRuntime.CompleteClosedDefinitionPair(CodeObject, Closure, integerArgument, destination);",
        "                    if (CodeObject.HasDirectCapturedDefinitionPair)\n                    {\n                        "+count("CapturedPairs")+
        "\n                        LythonRuntime.CompleteClosedCapturedPair(CodeObject, Closure, integerArgument, destination);\n                    }\n                    else\n                    {\n                        "+
        count("DefaultedPairs")+"\n                        LythonRuntime.CompleteClosedDefinitionPair(CodeObject, Closure, integerArgument, destination);\n                    }")
replace("                    var function = capturesArgument\n", "                    if (capturesArgument) "+count("CaptureDefinitions")+
        "\n                    else "+count("ComputedDefinitions")+"\n                    var function = capturesArgument\n")
replace("                return LythonRuntime.TryEvaluateDirectOperandReturn(CodeObject, operands, Closure, _closureCells, out result);",
        "                var complete = LythonRuntime.TryEvaluateDirectOperandReturn(CodeObject, operands, Closure, _closureCells, out result);\n                if (complete) "+count("DirectScalarReturns")+"\n                return complete;")
replace("        StartInline(values[..CodeObject.ValueStorageCapacity], null, span, false, default,",
        "        "+count("CallbackWorkspaces")+"\n        StartInline(values[..CodeObject.ValueStorageCapacity], null, span, false, default,")
replace("            if (state.Run(span, out result, unpackedReturn))\n            {\n",
        "            if (state.Run(span, out result, unpackedReturn))\n            {\n                "+count("FinishedNativePrefixes")+"\n")
replace("            state.PrepareTransfer();","            "+count("TransferredNativePrefixes")+"\n            state.PrepareTransfer();")
replace("                values[..state.LiveExtent].CopyTo(owned.Values);","                values[..state.LiveExtent].CopyTo(owned.Values);\n                "+
        count("RentedContinuations")+"\n                Interlocked.Add(ref DiagnosticContinuationSlotsCopied, state.LiveExtent);")
write(source,s)
import difflib
relative=source.relative_to(frozen).as_posix()
write(lab/"diagnostic.patch","".join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),"a/"+relative,"b/"+relative)))
sdk=Path.home()/".dotnet11"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
dotnet=sdk/"dotnet.exe"
def run(*args,cwd=lab,log=None):
    if log:
        with (lab/log).open("wb") as output:
            subprocess.run([dotnet,*args],cwd=cwd,env=env,timeout=120,stdout=output,stderr=subprocess.STDOUT,check=True)
    else:
        subprocess.run([dotnet,*args],cwd=cwd,env=env,timeout=70,check=True)
run("build","src/Lokad.Lython/Lokad.Lython.csproj","-c","Release","-f","net11.0","--no-incremental","--artifacts-path",lab/"core-build",cwd=frozen,log="core-build.log")
donor=base/"retire-clr-cursor-adapter-20261125"
identity=read(donor/"comparison/quiet/identity.json")
assert git("diff","--binary",identity["comparisonRevision"],base_revision,"--","src")== (donor/"candidate.patch").read_bytes()
files=identity["imageFiles"]["candidate"]
assert {p.name:sha(p) for p in (donor/"candidate").iterdir()}==files
image=lab/"image"
image.mkdir(exist_ok=True)
for name in files:
    original=donor/"candidate"/name if name!="Lokad.Lython.dll" else lab/"core-build/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll"
    shutil.copyfile(original,image/name)
new_files={p.name:sha(p) for p in image.iterdir()}
assert {n for n in files if files[n]!=new_files[n]}=={"Lokad.Lython.dll"}
procedure=repo/"benchmarks/results/2026-11-23-native-transition-inventory/procedures.tar.xz"
with tarfile.open(procedure) as retained:
    cs=retained.extractfile("Program.cs").read().decode("utf-8-sig")
    project=retained.extractfile("RouteProbe.csproj").read().decode("utf-8-sig")
cs=cs[:cs.index("string[] names = ")]+f"string[] names = {json.dumps(names)};\n"+cs[cs.index("var runtime ="):]
write(lab/"Program.cs",cs)
write(lab/"RouteProbe.csproj",project)
sources=[
    donor/"input-catalog.json",
    base/"closed-default-evaluation-20261125/input-catalog.json",
]
cases={}
for path in sources:
    cases.update({c["id"]:c for c in read(path)["cases"]})
ids=("diagnostic.generated-ordinary-definitions","scripts.rule-default-closures",
     "scripts.csv-invoice.method-policy.quoted-control","diagnostic.shipment-routing-callbacks",
     "diagnostic.shipment-bound-starmap","diagnostic.shipment-file-fed-map","diagnostic.shipment-generator-over-map")
catalog=read(sources[0])
catalog["cases"]=[cases[key]|{"id":key+(".async" if asynchronous else ""), "runAsync":asynchronous} for key in ids for asynchronous in (False,True)]
save(lab/"cases.json",catalog)
run("build","RouteProbe.csproj","-c","Release","--no-incremental",log="probe-build.log")
for p in (lab/"bin/Release/net11.0").glob("RouteProbe.*"): shutil.copyfile(p,image/p.name)
run(image/"RouteProbe.dll",image,lab/"cases.json",lab/"routes.json")
assert {name:sha(image/name) for name in files}==new_files
save(lab/"identity.json",dict(productionSource=base_revision,images=new_files,onlyCoreChanged=True,sourceCatalogs={p.relative_to(base).as_posix():sha(p) for p in sources},
    diagnosticPatchSHA256=sha(lab/"diagnostic.patch"), casesSHA256=sha(lab/"cases.json"), boundary="route counts only"))
for row in read(lab/"routes.json")["rows"]:
    print(row["id"],row["routes"])
