from pathlib import Path
import os,subprocess
r=Path(__file__).parent;env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';'+env['PATH'];log=r/'initial-check.log'
with log.open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f','net11.0','--no-restore','--disable-build-servers','-m:1','--filter','FullyQualifiedName~CursorDispatchTests|FullyQualifiedName~IterationCancellationTests','--logger','trx','--results-directory',str((r/'initial-check').resolve())],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
print(done.returncode,log.read_text(encoding='utf-8')[-5000:],flush=True);assert done.returncode==0
