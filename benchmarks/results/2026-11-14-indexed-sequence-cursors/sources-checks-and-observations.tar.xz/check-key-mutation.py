from pathlib import Path
import json,os,subprocess,tempfile
r=Path(__file__).parent;source="""items=[1,2,3]
def key(value):
    with open('offset.txt') as source: offset=int(source.read())
    if value==1: items[:]=[1,9,3,7]
    return value+offset
print(max(items,key=key),items)
"""
with tempfile.TemporaryDirectory(prefix='key-mutation-python-',dir=r.resolve())as name:
 folder=Path(name);(folder/'offset.txt').write_text('2',encoding='utf-8')
 done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],cwd=folder,capture_output=True,text=True,encoding='utf-8',timeout=15)
 assert done.returncode==0 and not done.stderr and done.stdout=='9 [1, 9, 3, 7]\n',done
(r/'key-mutation-python.json').write_text(json.dumps(dict(reference='CPython3.13.2 isolated',source=source,stdout=done.stdout),indent=2)+'\n',encoding='utf-8',newline='\n')
env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';'+env['PATH'];rows=[]
for target in ['net11.0','net10.0']:
 log=r/('key-mutation-'+target+'.log')
 with log.open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f',target,'--no-restore','--disable-build-servers','-m:1','--filter','FullyQualifiedName~LiveListCursorSeesReplacementAfterAnAsynchronousKeyCallback','--logger','trx','--results-directory',str((r/('key-mutation-'+target)).resolve())],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 print(target,done.returncode,log.read_text(encoding='utf-8')[-3000:],flush=True);rows.append(dict(target=target,returncode=done.returncode));(r/'key-mutation-checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n');assert done.returncode==0
