from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;prior=r.parent/'native-for-r345';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
rows=json.loads((r/'focused-checks.json').read_text(encoding='utf-8'));assert len(rows)==4 and all(v['returncode']==0 for v in rows)
assert json.loads((prior/'delivery/crlf-restoration.json').read_text(encoding='utf-8'))['restoredExactOriginalLFBytes']
reference=json.loads((r/'reference-identity.json').read_text(encoding='utf-8'));sources={p:sha(p)for p in reference['sources']};changed=[p for p in sources if sources[p]!=reference['sources'][p]]
assert sorted(changed)==['src/Lokad.Lython/Runtime/LythonRuntime.Executable.cs','src/Lokad.Lython/Runtime/PyIteration.cs'],changed
env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';'+env['PATH']
with(r/'candidate-build.log').open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-restore','--no-incremental','--disable-build-servers','-m:1'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
assert done.returncode==0,(r/'candidate-build.log').read_text(encoding='utf-8')[-3500:]
assert sources=={p:sha(p)for p in sources}
shutil.copytree(r/'reference',r/'candidate');shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'candidate/Lokad.Lython.dll');shutil.copyfile(r/'candidate/Lokad.Lython.dll',r/'candidate-core.dll')
identity=dict(headBeforeCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),referenceProductionCommit='3d78d429',referenceQualification='Original CI failed Windows expected-output fixtures only; Ubuntu full green, corrected goldens c9edb0ee pending batched delivery.',coreSHA256={role:sha(r/role/'Lokad.Lython.dll')for role in ['reference','candidate']},sources=sources,productionFiles=len(sources),changedProductionInputs=changed,removedMechanisms=['separate CLR list/tuple cursor enumerator allocation','interface MoveNext/Current for exact private sequences','duplicate executable list/tuple advancement bodies'],auxiliaryFiles={role:{p.name:sha(p)for p in(r/role).iterdir()if p.is_file()and p.name!='Lokad.Lython.dll'}for role in ['reference','candidate']},qualified=False,sourceAndScriptDifferIntentionally=False)
assert identity['auxiliaryFiles']['reference']==identity['auxiliaryFiles']['candidate']and len(sources)==581
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as t:
 for name in sources:t.add(name,arcname=name)
catalog=json.loads((prior/'catalog.json').read_text(encoding='utf-8'));catalog['cases']=[next(c for c in catalog['cases']if c['id']==id)for id in ['scripts.csv-check-digits.for-list.large','scripts.csv-check-digits.for-text.large','scripts.text-summary-helpers.nonlocal-counter.large']]
(r/'catalog.json').write_text(json.dumps(catalog,separators=(',',':'),ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
for role in ['reference','candidate']:(r/('allocation-'+role+'-catalog.json')).write_bytes((r/'catalog.json').read_bytes())
for name in ['verify-worker.py','measure-allocation.py']:(r/name).write_bytes((prior/name).read_bytes())
print('Frozen cursor candidate',identity['coreSHA256'],'581inputs; fixed complete images and unchanged three scripts.',flush=True)
