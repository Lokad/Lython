from pathlib import Path
import json,shutil
r=Path(__file__).parent/'b716';out=r/'preflight-desktop-only-aux';out.mkdir()
for name in ['launch.log','launch-command.py','identity.json','config.json','payload.tgz']:shutil.copyfile(r/name,out/name)
(out/'assessment.json').write_text(json.dumps(dict(failure='The complete desktop image includes Allocation diagnostic helper files; the immutable VM benchmark image intentionally does not.',beforeStagingOrService=True,correction='Use the existing B714 VM worker manifest, verify every required auxiliary hash against both new desktop images, and preserve full desktop hashes separately. No measured worker/provider/core change or relaxed verification.',noMeasurementRestart=True),indent=2)+'\n',encoding='utf-8',newline='\n')
