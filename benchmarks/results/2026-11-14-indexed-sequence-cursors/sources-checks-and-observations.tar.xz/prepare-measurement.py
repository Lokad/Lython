from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent;prior=r.parent/'native-for-r345/b714';out=r/'b716';out.mkdir(exist_ok=True)
assert not(out/'observe-not-before.json').exists()
source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));aux=json.loads((prior/'identity.json').read_text(encoding='utf-8'))['candidateAuxiliaryFiles']
assert all(source['auxiliaryFiles'][role][name]==sha for role in ['reference','candidate']for name,sha in aux.items())
identity=dict(sourceRevision='R346frozen'+source['coreSHA256']['candidate'][:8]+' vs committed3d78d429/frozen8306699f',purpose='Remove exact-sequence CLR enumerators in the existing cursor; identical complete list/text CSV warm and captured text control. Compilation unchanged; no fresh or external timing replay.',coreSHA256={label:source['coreSHA256']['candidate'if label.startswith('candidate')else'reference']for label in ['reference','candidate','reference-control','candidate-control']},candidateAuxiliaryFiles=aux,referenceAuxiliaryFiles=aux,catalogSHA256=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest(),referenceCase='scripts.csv-check-digits.for-list.large',variantCase='scripts.csv-check-digits.for-list.large',controlCases=['scripts.text-summary-helpers.nonlocal-counter.large'],sourceAndScriptDifferIntentionally=False)
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.csv-check-digits.for-list.large','warm'],['scripts.csv-check-digits.for-text.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','warm']]
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py','launch.py']:
 s=(prior/name).read_text(encoding='utf-8').replace('native-for-b714-20261114','indexed-cursor-b716-20261114').replace('lython-b714-native-for-20261114','lython-b716-indexed-cursor-20261114').replace('B714','B716')
 if name=='collect.py':
  a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==3 and all(case in cases for case,lane in jobs)\n'+s[b:]
  s=s.replace("< 360, 'Reserve60seconds","< 240, 'Reserve60seconds").replace('Native for-prefix source comparison','Indexed-cursor source comparison')
 if name in ['archive-owned.py','summarize.py']:s=s.replace("len(raw['jobs'])==5","len(raw['jobs'])==3").replace('jobs=5','jobs=3')
 if name=='retrieve.py':s=s.replace("['jobs']==5","['jobs']==3").replace("['elapsedSeconds']<420","['elapsedSeconds']<300").replace('five-job raw','three-job raw')
 if name=='launch.py':
  needle=" os.link(source/'cpython-worker.py',root/'cpython-worker.py')";assert s.count(needle)==1
  s=s.replace(needle," os.link(source/'candidate/Lokad.Lython.dll',root/'reference-core.dll')\n"+needle)
  s=s.replace('RuntimeMaxSec=420','RuntimeMaxSec=300').replace('seconds=360','seconds=240').replace('ownerSeconds=420','ownerSeconds=300')
 if name.endswith('.py'):ast.parse(s)
 (out/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
 for name in ['identity.json','collect.py','archive-owned.py','run.sh']:t.add(out/name,arcname=name)
 for name,arc in [('catalog.json','representative.json'),('candidate-core.dll','candidate-core.dll'),('candidate-identity.json','source-identity.json'),('reference-identity.json','reference-source-identity.json')]:t.add(r/name,arcname=arc)
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
config=dict(root='/home/lokad/lython-bench-checks/indexed-cursor-b716-20261114',sourceRoot='/home/lokad/lython-bench-checks/native-for-b714-20261114',unit='lython-b716-indexed-cursor-20261114',identity=identity,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Prepared three-job300s source pair; fixed workers,12s warmups/five1s batches, no frontend or CPython replay.',flush=True)
