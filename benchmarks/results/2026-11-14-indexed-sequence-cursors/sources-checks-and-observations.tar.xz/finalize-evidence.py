from pathlib import Path
import hashlib, json, shutil, tarfile

r = Path(__file__).parent
out = Path('benchmarks/results/2026-11-14-indexed-sequence-cursors')
out.mkdir(exist_ok=False)
identity = json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == sha for p, sha in identity['sources'].items())
terminal = json.loads((r/'b716/terminal-status.json').read_text(encoding='utf-8'))
assert terminal['receipt']['complete'] and terminal['receipt']['allWorkersJoined']
assert terminal['receipt']['archivedAndVerifiedUnderLease'] and terminal['receipt']['guestFixturesRemoved']
assert all(x['returncode'] == 0 for x in json.loads((r/'focused-checks.json').read_text(encoding='utf-8')))
assert all(x['returncode'] == 0 for x in json.loads((r/'key-mutation-checks.json').read_text(encoding='utf-8')))
decision = {
 'date':'2026-11-14', 'milestone':'R346', 'decision':'retain; full delivery pending',
 'source':identity['coreSHA256'], 'referenceProductionCommit':'3d78d429',
 'referenceQualification':'Original Windows run failed five CRLF-sensitive test expectations; Ubuntu full delivery passed. Test-only correction c9edb0ee is included in the pending batched qualification.',
 'removed':['Separate exact-list/tuple CLR enumerator inside existing private cursors','Interface MoveNext/Current transport for these sources','Duplicate executable list/tuple advancement bodies'],
 'focusedChecks':{'actualRuntimes':['11','10'],'whiteBoxPerRuntime':149,'publicPerRuntime':1013,'total':2324},
 'allocationPercent':{'listCSV':-1.52999,'textCSV':0.68626,'capturedText':'effectively flat, about16B/job'},
 'timing':'B716: list elapsed -5.20..-3.30%, wider CPU -4.58..-2.63%. Text elapsed -0.11..+0.77%, wider CPU +0.45..+1.74%. Captured-text reference process spread4.85% leaves control neutrality uncertain.',
 'debt':'Retain the small text allocation/CPU adversity for a simpler representation and supported list improvement. No general neutrality, whole-release or CPython gain claim. No unchanged retiming required.',
 'compatibility':'No public API change. Exact sealed builtin sequences retain live index semantics, aliases and sticky EOF. Already acquired/generic/async enumerators retain precedence. Position storage and ownership lifetimes stay in existing mechanisms.',
 'next':'Batch Windows/Ubuntu actual11/10, original stress and installed Release consumers, then continue the complete-script roadmap. Publication stays held.'
}
(r/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
for source,target in [('decision.json','decision.json'),('candidate-identity.json','candidate-identity.json'),('b716/summary.json','timing-summary.json'),('b716/terminal-status.json','terminal-status.json'),('focused-checks.json','focused-checks.json'),('key-mutation-checks.json','key-mutation-checks.json')]:
 shutil.copyfile(r/source,out/target)
with tarfile.open(out/'sources-checks-and-observations.tar.xz','w:xz') as archive:
 for p in sorted(r.rglob('*')):
  if not p.is_file(): continue
  rel=p.relative_to(r)
  if rel.parts[0] in ('reference','candidate') or rel.parts[0]=='delivery': continue
  if p.name=='payload.tgz' and rel.parent==Path('b716'): continue
  archive.add(p,arcname=rel.as_posix(),recursive=False)
with tarfile.open(out/'sources-checks-and-observations.tar.xz') as archive:
 for name,expected in [('candidate-core.dll',identity['coreSHA256']['candidate']),('reference-core.dll',identity['coreSHA256']['reference'])]:
  assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==expected
(out/'README.md').write_text('''# Indexed builtin sequence cursors

2026-11-14, R346: committed runtime `3d78d429`/frozen `8306699f` versus
prototype `8ae1ae5f`. The existing cursor keeps the exact sealed list/tuple's
position directly. Its separate CLR enumerator and interface pull disappear;
ordinary executable storage shares the same live advancement kernel. No pool,
engine, memory policy or public API is added. Generic/acquired enumerators retain
precedence, and sticky exhaustion prevents append from reviving an ended cursor.

Retained pending full delivery. Focused Release checks pass 149 white-box and
1,013 public cases per actual .NET 11/10 (2,324 total). Coverage includes live
replacement/growth/shrink, aliases, Current/Dispose, cancellation, native/ordinary
transfer, admission refusal, awaited cleanup and budget reuse. The final public
case replaces list backing during genuinely asynchronous `max` key callbacks;
its exact output agrees with isolated CPython 3.13.2.

| Complete warm script | Allocated bytes | Elapsed | Wider process CPU |
| --- | ---: | ---: | ---: |
| CSV checksum, list input, 4,096 rows | −1.53% | −5.20..−3.30% | −4.58..−2.63% |
| Same CSV, text input, 4,096 rows | +0.69% | −0.11..+0.77% | +0.45..+1.74% |
| Captured text counter, unchanged control | about +16 B/job, effectively flat | −6.29..+0.21% | −6.51..+0.88% |

Percentages compare candidate with reference for every pair of fresh-process
medians; negative means less. These are Lython source comparisons, not CPython
ratios. The control's reference process spread is 4.85%, so neutrality is
uncertain. List process spreads are 1.92% candidate/0.08% reference; text
0.83%/0.05%. Retain the simpler representation and supported list gain with the
small text allocation/CPU adversity explicit. No general speedup is established.

B716 runs on the quiet Azure F4as_v7 Ubuntu 24.04.4 VM, ordinary .NET tiering/GC,
fixed B685 worker and optional adapter 0.4. Four fresh processes per script use
12-second complete-request warmup and five one-second measured batches. The
226.38-second collection stays inside its 300-second owned service. Warm timing
includes mediated RAM-backed I/O, golden verification and prior result cleanup;
it excludes compilation, startup, fixture reset/protocol and final cache shutdown.
Wider process CPU includes reset/protocol. No new fresh/compilation/CPython timing
was necessary for this representation change. Separate Windows allocation checks
use four processes with exact goldens and budget-baseline checks; their elapsed
clocks are not performance evidence.

All sources/cores, complete auxiliary hashes, raw observations, tools and checks
are in [the archive](sources-checks-and-observations.tar.xz).
[Timing](timing-summary.json), [decision](decision.json) and
[identity](candidate-identity.json) distinguish measurement from delivery.
Raw VM archive SHA256 is
`2489ff87b08a978e6dd7100315530abf86bdd1fbe7c4925500854ece44bb5b20`.
All workers join, guest fixtures disappear and persistent evidence is verified
under the lease. The first staging preflight failed before starting a service
because desktop-only allocation-helper files were absent from the VM manifest;
the corrected manifest verifies every actual VM auxiliary against both frozen
images. The failed manifest/payload survive. Before staging, four hardlinks to
two withdrawn B713 cores were retired only after canonical Git archive/binary
proof; current images, evidence and disk floors were preserved.

The reference's original full CI failed five Windows CRLF-sensitive expected
outputs; Ubuntu completed .NET 11/10, original stress and installed consumers.
Test-only correction `c9edb0ee` uses explicit LF expectations without normalizing
actual output. This candidate includes it and will batch full qualification.
The previous fully qualified runtime remains R341 until that delivery succeeds.
Publication and optional adapter promotion remain held.
''',encoding='utf-8',newline='\n')
print('Archived',out,'bytes',sum(p.stat().st_size for p in out.iterdir() if p.is_file()),flush=True)
