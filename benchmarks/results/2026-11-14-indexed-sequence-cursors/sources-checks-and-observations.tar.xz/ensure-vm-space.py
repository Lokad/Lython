from pathlib import Path
import ast,base64,hashlib,json,subprocess,tarfile
r=Path(__file__).parent;config=json.loads((r/'b716/config.json').read_text(encoding='utf-8'))
archive=Path('benchmarks/results/2026-11-14-bulk-cased-buffer-withdrawn/source-and-checks.tar.xz')
blob=subprocess.check_output(['git','hash-object',str(archive)],text=True).strip();assert blob==subprocess.check_output(['git','rev-parse','HEAD:'+archive.as_posix()],text=True).strip()
identity=json.loads(Path('benchmarks/results/2026-11-14-bulk-cased-buffer-withdrawn/candidate-identity.json').read_text(encoding='utf-8'))
cores={}
with tarfile.open(archive)as t:
 for role in ['reference','candidate']:
  data=t.extractfile('r343/'+role+'-core.dll').read();sha=hashlib.sha256(data).hexdigest();assert sha==identity['coreSHA256'][role]
  cores[role]=dict(sha256=sha,bytes=len(data))
proof=dict(canonicalCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),canonicalArchive=archive.as_posix(),archiveSHA256=hashlib.sha256(archive.read_bytes()).hexdigest(),archiveGitBlob=blob,cores=cores,onlyWithdrawnB713Cores=True,currentB711B714B715Preserved=True)
(r/'retirement-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
code='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
proof=PROOF
required=REQUIRED
base=Path('/home/lokad/lython-bench-checks').resolve();old=base/'bulk-cased-buffer-b713-20261114'
assert old.parent==base and old.resolve()==old
receipt=base/'b716-proved-core-retirement-20261114.json'
assert not receipt.exists()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[d]otnet.*complete-jobs.dll|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 before=shutil.disk_usage(base).free
 result=dict(beforeFreeBytes=before,requiredBytes=required,canonicalProof=proof,freshIdleLease=True,removed=[])
 if before<=required:
  targets=[]
  for role,facts in proof['cores'].items():
   pair=[old/(role+'-core.dll'),old/role/'Lokad.Lython.dll'];infos=[]
   for p in pair:
    assert p.resolve()==p and p.is_relative_to(old)and not p.is_symlink()
    info=p.stat();assert stat.S_ISREG(info.st_mode)and info.st_uid==os.getuid()and info.st_nlink==2 and info.st_size==facts['bytes']
    assert hashlib.sha256(p.read_bytes()).hexdigest()==facts['sha256'];infos.append(info)
   assert(infos[0].st_dev,infos[0].st_ino)==(infos[1].st_dev,infos[1].st_ino)
   targets.extend((p,facts['sha256'])for p in pair)
  for p,sha in targets:
   p.unlink();result['removed'].append(dict(path=str(p),sha256=sha));receipt.write_text(json.dumps(result,indent=2)+'\\n')
 result.update(afterFreeBytes=shutil.disk_usage(base).free,noCurrentImagesOrCanonicalEvidenceRemoved=True)
 receipt.write_text(json.dumps(result,indent=2)+'\\n')
 assert result['afterFreeBytes']>required,result
 print(json.dumps(result))
'''.replace('PROOF',repr(proof)).replace('REQUIRED',repr(254*1024*1024+config['unpackedBytes']+64*1024))
ast.parse(code);(r/'retirement-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
done=subprocess.run(ssh+[command],capture_output=True,text=True,encoding='utf-8',timeout=45)
(r/'retirement.log').write_text(done.stdout+done.stderr,encoding='utf-8',newline='\n');assert done.returncode==0,done.stderr
receipt=json.loads(done.stdout);(r/'retirement-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
print('VM space checked:',receipt['beforeFreeBytes'],'→',receipt['afterFreeBytes'],'bytes; retired',len(receipt['removed']),'proved withdrawn core links; current images/evidence preserved.',flush=True)
