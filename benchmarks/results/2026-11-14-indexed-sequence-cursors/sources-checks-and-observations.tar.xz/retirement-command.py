from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
proof={'canonicalCommit': 'c9edb0ee3206181755acd0fa78f89926526e8c35', 'canonicalArchive': 'benchmarks/results/2026-11-14-bulk-cased-buffer-withdrawn/source-and-checks.tar.xz', 'archiveSHA256': '773e0c99b2a105c9a654b7027cfedef459410fdda0c91e952a365bb78ccf2c86', 'archiveGitBlob': 'e5b52ffee8c0710e685f0aae13656c50e19e9b79', 'cores': {'reference': {'sha256': '53becdb661d8089c0bf76140cc6b6ee84172f4c5718944e279d3f83d6cfbe31e', 'bytes': 5738496}, 'candidate': {'sha256': 'a9d54f99cbb9fad6358541d60a5e3817a6c68870c6d632d2aa1f058e16e54c4a', 'bytes': 5737472}}, 'onlyWithdrawnB713Cores': True, 'currentB711B714B715Preserved': True}
required=272512030
base=Path('/home/lokad/lython-bench-checks').resolve();old=base/'bulk-cased-buffer-b713-20261114'
assert old.parent==base and old.resolve()==old
receipt=base/'b716-proved-core-retirement-20261114.json'
assert not receipt.exists()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[d]otnet.*complete-jobs.dll|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 before=shutil.disk_usage(base).free
 result=dict(beforeFreeBytes=before,requiredBytes=required,canonicalProof=proof,freshIdleLease=True,removed=[])
 if before<=required:
  targets=[]
  for role,facts in proof['cores'].items():
   pair=[old/(role+'-core.dll'),old/role/'Lokad.Lython.dll'];infos=[]
   for p in pair:
    assert p.resolve()==p and p.is_relative_to(old)and not p.is_symlink()
    info=p.stat();assert stat.S_ISREG(info.st_mode)and info.st_uid==os.getuid()and info.st_nlink==2 and info.st_size==facts['bytes']
    assert hashlib.sha256(p.read_bytes()).hexdigest()==facts['sha256'];infos.append(info)
   assert(infos[0].st_dev,infos[0].st_ino)==(infos[1].st_dev,infos[1].st_ino)
   targets.extend((p,facts['sha256'])for p in pair)
  for p,sha in targets:
   p.unlink();result['removed'].append(dict(path=str(p),sha256=sha));receipt.write_text(json.dumps(result,indent=2)+'\n')
 result.update(afterFreeBytes=shutil.disk_usage(base).free,noCurrentImagesOrCanonicalEvidenceRemoved=True)
 receipt.write_text(json.dumps(result,indent=2)+'\n')
 assert result['afterFreeBytes']>required,result
 print(json.dumps(result))
