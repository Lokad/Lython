from pathlib import Path
import json
r=Path(__file__).parent;p=Path('PLAN.md');text=p.read_text(encoding='utf-8');(r/'PLAN-before-implementation.md').write_text(text,encoding='utf-8',newline='\n')
text=text.replace('   cursor position; reference830/commit3d78d429 is copied/frozen. Implementation is\n   not started. Generic acquisition/checkpoint order and sticky EOF are explicit','   cursor position; reference830/commit3d78d429 is copied/frozen. Implementation now\n   shares live indexed advancement with existing executable storage and keeps the\n   position inside the current cursor. It avoids separate sealed-list/tuple CLR\n   enumerators; already-acquired/generic enumerators retain precedence. No timing\n   or allocation gain claimed yet. Generic acquisition/order and sticky EOF remain')
p.write_text(text,encoding='utf-8',newline='\n')
record=json.loads((r/'prospective.json').read_text(encoding='utf-8'));record['state']='prototype implemented; correctness and measurements pending';(r/'implementation.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Existing cursor position replaces duplicate enumerator; shared sequence kernel removes duplicate executable bodies.',flush=True)
