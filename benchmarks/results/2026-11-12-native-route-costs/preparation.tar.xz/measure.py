from pathlib import Path
import hashlib,json,os,shutil,subprocess

r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython')
normal=json.loads((r/'normal-state-before.json').read_text(encoding='utf-8'))
def prove():
    assert all(hashlib.sha256((repo/n).read_bytes()).hexdigest()==h for n,h in normal.items())
prove()
driver=r/'out/complete-jobs/Release/net11.0/complete-jobs.dll';assert driver.is_file()
failed=r/'launcher-path-failure';assert not failed.exists();failed.mkdir()
for name in ['measurements.json','stderr.log']:
    p=r/'warm-sync'/name
    if p.exists():shutil.copyfile(p,failed/name)
dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env['DOTNET_ROOT']=str(dotnet.parent);env['PATH']=str(dotnet.parent)+';C:/Python313;'+env['PATH']
for phase in ['warm-sync','warm-async']:
    folder=r/phase
    if(folder/'measurements.json').exists():assert phase=='warm-sync'
    cmd=[str(dotnet),str(driver),str(r/'images/before/Lokad.Lython.Benchmarks.dll'),str(r/'images/candidate/Lokad.Lython.Benchmarks.dll'),str(r/'catalog.json'),str(folder/'hash-witness.json'),'forward','warm','async'if phase=='warm-async'else'sync']
    with(folder/'measurements.json').open('wb')as f,(folder/'stderr.log').open('wb')as err:p=subprocess.run(cmd,cwd=repo,env=env,stdout=f,stderr=err)
    assert p.returncode==0,(phase,(folder/'stderr.log').read_text(encoding='utf-8'))
    j=json.loads((folder/'measurements.json').read_text(encoding='utf-8-sig'));assert len(j['observations'])==2 and j['allGoldensPassed']and j['allBalancesZero']and j['ownedFixturesRemoved']
    prove();print(phase,'full goldens/balances/cleanup pass; normal state unchanged.',flush=True)
(r/'normal-state-proof.json').write_text(json.dumps({'passed':True,'files':len(normal),'beforeSHA256':normal,'normalSourcePinsAssetsAndOutputsUnchanged':True,'launcherCorrection':'Original tool/bin path failed before any measurements. Actual isolated output is out/complete-jobs; failed stdout/stderr preserved, completed builds reused.'},indent=2)+'\n',encoding='utf-8')
