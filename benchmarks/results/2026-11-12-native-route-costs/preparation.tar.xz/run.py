from pathlib import Path
import hashlib,json,os,shutil,subprocess

r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython')
dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env['DOTNET_ROOT']=str(dotnet.parent);env['PATH']=str(dotnet.parent)+';C:/Python313;'+env['PATH']
normal=json.loads((r/'normal-state-before.json').read_text(encoding='utf-8'))
def prove_normal():
    after={n:hashlib.sha256((repo/n).read_bytes()).hexdigest()for n in normal};assert normal==after
    return len(after)
prove_normal()
def run(label,args):
    log=r/(label+'.log');assert not log.exists()
    with log.open('w',encoding='utf-8')as f:p=subprocess.run([str(dotnet),*args],cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT)
    text=log.read_text(encoding='utf-8');assert p.returncode==0,(label,text[-8000:])
    print(label,'pass',flush=True)
props=['-p:DirectoryBuildPropsPath='+str(r/'Directory.Build.props')]
run('compile-items',['msbuild','src/Lokad.Lython/Lokad.Lython.csproj','-nologo','-v:quiet','-getItem:Compile','-p:TargetFramework=net11.0',*props])
text=(r/'compile-items.log').read_text(encoding='utf-8');items=json.loads(text[text.index('{'):])['Items']['Compile']
paths=[Path(x['FullPath']).resolve()for x in items]
assert (r/'ExecutableScript.cs').resolve()in paths
assert (repo/'src/Lokad.Lython/Frontend/ExecutableScript.cs').resolve()not in paths
run('build-private-core',['build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','--no-incremental','--nologo','--tl:off',*props])
count=prove_normal()
shutil.copyfile(r/'out/Lokad.Lython/Release/net11.0/Lokad.Lython.dll',r/'images/candidate/Lokad.Lython.dll')
shutil.copyfile(r/'out/Lokad.Lython/Release/net10.0/Lokad.Lython.dll',r/'candidate-net10.dll')
tool=r/'tool';tool.mkdir()
old=r.parent/'iteration-returns-r225/tool'
shutil.copyfile(old/'complete-jobs.csproj',tool/'complete-jobs.csproj')
text=(old/'Program.cs').read_text(encoding='utf-8')
needle='if (cases.Length != 6) throw new InvalidDataException("Require two counter variants and four complete-script controls.");'
assert text.count(needle)==1
text=text.replace(needle,'if (cases.Length != 2) throw new InvalidDataException("Require the two unchanged helper scripts.");')
text=text.replace('R225 ordinary return consumption; identical whole scripts and fixed common images; shared ALCs/process GC; precise allocation, desktop elapsed diagnostic only; compile/warm separate','R255 private native-route counterfactual; identical two whole helper scripts and fixed common images; shared ALCs/process GC; allocation and route costs, desktop elapsed diagnostic only; no compile performance claim')
(tool/'Program.cs').write_text(text,encoding='utf-8')
run('build-existing-driver',['build',str(tool/'complete-jobs.csproj'),'-c','Release','--nologo','--tl:off'])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity={'proposal':json.loads((r/'proposal.json').read_text(encoding='utf-8')),'referenceCore':sha(r/'images/before/Lokad.Lython.dll'),'candidateCore':sha(r/'images/candidate/Lokad.Lython.dll'),'candidateNet10Core':sha(r/'candidate-net10.dll'),'baselineProductionSource':json.loads((r.parent/'native-proof-r254/before.json').read_text(encoding='utf-8'))['sourceHashes'],'normalStateFileCount':count,'privateSourceOverrideIsSoleCompilerFile':True,'driverOriginalSHA256':sha(old/'Program.cs'),'driverAdaptedSHA256':sha(tool/'Program.cs'),'driverChanges':'Two-case input validation and purpose text only; measurement, goldens, host, ownership and cleanup logic unchanged.','normalGcAndTiering':True,'performanceQualified':False}
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
for phase in ['warm-sync','warm-async']:
    folder=r/phase;assert not(folder/'measurements.json').exists()
    command=[str(dotnet),str(tool/'bin/Release/net11.0/complete-jobs.dll'),str(r/'images/before/Lokad.Lython.Benchmarks.dll'),str(r/'images/candidate/Lokad.Lython.Benchmarks.dll'),str(r/'catalog.json'),str(folder/'hash-witness.json'),'forward','warm','async'if phase=='warm-async'else'sync']
    with(folder/'measurements.json').open('wb')as f,(folder/'stderr.log').open('wb')as err:p=subprocess.run(command,cwd=repo,env=env,stdout=f,stderr=err)
    assert p.returncode==0,(phase,(folder/'stderr.log').read_text(encoding='utf-8'))
    j=json.loads((folder/'measurements.json').read_text(encoding='utf-8-sig'));assert j['allGoldensPassed']and j['allBalancesZero']and j['ownedFixturesRemoved']
    prove_normal();print(phase,'full goldens/balances/cleanup pass; normal state unchanged.',flush=True)
(r/'normal-state-proof.json').write_text(json.dumps({'passed':True,'files':prove_normal(),'beforeSHA256':normal,'normalSourcePinsAssetsAndOutputsUnchanged':True},indent=2)+'\n',encoding='utf-8')
