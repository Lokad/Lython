from pathlib import Path
import hashlib,json,shutil,tarfile

r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-12-native-route-costs';assert not out.exists();out.mkdir()
normal=json.loads((r/'normal-state-proof.json').read_text(encoding='utf-8'));assert normal['passed']
for n,h in normal['beforeSHA256'].items():assert hashlib.sha256((repo/n).read_bytes()).hexdigest()==h,n
for n in ['proposal.json','identity.json','normal-state-before.json','normal-state-proof.json','catalog.json','compile-items.log','build-private-core.log','build-existing-driver.log']:shutil.copyfile(r/n,out/n)
for phase in ['warm-sync','warm-async']:shutil.copytree(r/phase,out/phase)
with tarfile.open(out/'preparation.tar.xz','w:xz')as a:
    for p in [*r.glob('*.py'),r/'ExecutableScript.cs',r/'Directory.Build.props',r/'tool/Program.cs',r/'tool/complete-jobs.csproj',*list((r/'launcher-path-failure').iterdir())]:a.add(p,arcname=p.relative_to(r).as_posix())
    for p in (r/'locks').glob('*'):a.add(p,arcname='locks/'+p.name)
with tarfile.open(out/'candidate-images.tar.xz','w:xz')as a:
    for tfm,p in [('net11.0',r/'images/candidate/Lokad.Lython.dll'),('net10.0',r/'candidate-net10.dll')]:a.add(p,arcname=tfm+'/Lokad.Lython.dll')
assessment={'reference':'Qualified2ec9d67f/c9829194','counterfactual':'NativeBody discarded after identical preparation, private compiler-file override only; ordinary executable route retained.','results':'Two unchanged complete scripts both APIs pass all goldens/files/balances/cleanup. Search allocates about451100additional bytes/command (~440B/helper call), both APIs. Captured text adds64B/command, not per call. Peak live admission rises only144/160B.','timing':'Desktop mixed/unstable controls; searchRun execution+5.73..+9.64% with3.56%control, searchAsync−10.87..−6.87% with4.48%control. Captured controls15–24%. No general CPU claim or removable-cost forecast.','sourceFacts':['Ordinary function calls already use explicit caller links and a deferred synchronous instruction prefix. Do not propose another generic VM/call arena.','Captured lower/split path already completes without per-call frame allocation.','Ordinary canonical nonzero-argument string receiver calls currently fall through the prefix and require invocation context, unlike zero-argument text methods. Existing native-body helpers already implement safe affix/split/replace for closed argument shapes.'],'next':'Consolidate existing receiver-operation selection, shape eligibility and invocation across native bodies and ordinary prefix. Avoid promotion for exact strings/canonical arguments; preserve protocol/keyword/index/suspension fallback. Validate guarded ordinary helper plus unchanged complete-script controls. No removal of measured native helpers or blanket CanSuspend bypass.'}
(out/'assessment.json').write_text(json.dumps(assessment,indent=2)+'\n',encoding='utf-8')
(out/'README.md').write_text('''# Complete helper-route cost — private counterfactual

2026-11-12. Qualified `2ec9d67f`/`c9829194` versus an isolated diagnostic build that
discards NativeBody after identical preparation/call facts. Normal source, pins,
assets and build outputs remain byte-identical. No public disable switch, shipped
backend, VM collection or compilation-performance claim. [Isolation](normal-state-proof.json).

Both unchanged complete helper scripts pass both APIs, full stdout/files, allowance
balances and joined cleanup. Existing complete-job driver changes only its two-case
validation and purpose text; measurement logic/host/goldens unchanged. First launcher
used the old output path and failed before measurements; original logs survive,
completed builds reused with the correct isolated output path.

| Script | Additional CLR allocation / command | Live peak allowance increase |
| --- | ---: | ---: |
| Keyword-default search, both APIs | ~451,100 B (~440 B per helper call) | 160 B |
| Captured text, both APIs | 64 B per whole command | 144 B |

This does not establish that all ordinary calls allocate a frame. Source confirms
the existing explicit caller chain and deferred synchronous prefix. Captured text
already completes without per-call frame allocation. Canonical nonzero-argument
string calls can still require promotion, while zero-argument operations and native
helper bodies have direct existing services. [Bounded assessment](assessment.json).

Desktop execution clocks are mixed: searchRun+5.73..+9.64% (3.56%control), searchAsync
−10.87..−6.87% (4.48%control), captured controls15–24%. No general CPU attribution,
removable-cost estimate or speed forecast. Allocations are physical CLR traffic;
the much smaller live-allowance deltas show independent lifetime accounting. Do
not confuse cumulative traffic with live protection or multiply these differences
into CPython ratios. Actual admitted roots return to baseline/zero after cleanup.

The next selected milestone shares canonical affix/split/replace eligibility and
invocation between native bodies and ordinary instruction-prefix calls, removing
unnecessary invocation promotion on guarded text helpers. Dynamic protocols,
keywords/expanded calls, coercions, Python errors and real suspension keep their
ordinary frame path. No blanket bypass of CanSuspend or new dispatch framework.
Measured native helper-return optimizations remain. Stop this counterfactual:
no additional unchanged collection or new ownership audit is selected.

[Identity](identity.json), [compile inputs](compile-items.log), [preparation/failure](preparation.tar.xz),
[candidate images](candidate-images.tar.xz), phase summaries/raw observations and
[archive identity](archive-identity.json). Fully qualified production is unchanged;
publication stays postponed.
''',encoding='utf-8')
(out/'archive-identity.json').write_text(json.dumps({p.relative_to(out).as_posix():{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for p in sorted(out.rglob('*'))if p.is_file()and p.name!='archive-identity.json'},indent=2)+'\n',encoding='utf-8')
h=repo/'benchmarks/EXPERIMENTS.md';text=h.read_text(encoding='utf-8');at=text.index('Both [linear native proof forms]')
text=text[:at]+'''[Whole helper-route counterfactual](results/2026-11-12-native-route-costs/README.md)
isolates native-body removal without changing normal production or preparation.
Two complete unchanged scripts pass both APIs/goldens/balances/cleanup. Search
adds~451100B/command (~440B/call), captured text only64B/command; live peaks add
160/144B. Desktop timing mixed, captured controls15–24%; no general CPU inference.
Existing caller chain/deferred prefix already avoid generic frame construction.
Source selects shared canonical receiver operations to avoid unnecessary promotion
for nonzero-argument text calls; preserve native helpers and genuine dynamic paths.
No further counterfactual collection, public switch or VM rewrite selected.

'''+text[at:];h.write_text(text,encoding='utf-8')
print('Bounded complete-call route assessment archived; normal state proved unchanged.')
