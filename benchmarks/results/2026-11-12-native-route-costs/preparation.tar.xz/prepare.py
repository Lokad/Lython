from pathlib import Path
import hashlib,json,shutil,subprocess

repo=Path('D:/code/Lython');r=Path(__file__).resolve().parent
old=r.parent/'native-proof-r254';before=json.loads((old/'before.json').read_text(encoding='utf-8'))
for n,h in before['sourceHashes'].items():assert hashlib.sha256((repo/n).read_bytes()).hexdigest()==h,n
assert not(r/'images').exists()
for role in ['before','candidate']:shutil.copytree(old/'images/before',r/'images'/role)
catalog=json.loads((old/'catalog.json').read_text(encoding='utf-8'))
selected={'scripts.text-summary-helpers.nonlocal-counter.large','scripts.file-search.large'}
catalog['cases']=[c for c in catalog['cases']if c['id']in selected];assert len(catalog['cases'])==2
(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for phase in ['warm-sync','warm-async']:
    (r/phase).mkdir();shutil.copyfile(old/'warm-sync/hash-witness.json',r/phase/'hash-witness.json')
path=repo/'src/Lokad.Lython/Frontend/ExecutableScript.cs';text=path.read_text(encoding='utf-8')
needle='        NativeBody = PrepareNativeBody(blocks, entryBlockIndex, exceptionRegions.Count, callSites);'
assert text.count(needle)==1
replacement='''        // Private diagnostic only: preserve preparation and its call facts,
        // then measure the existing ordinary executable function route.
        _ = PrepareNativeBody(blocks, entryBlockIndex, exceptionRegions.Count, callSites);
        NativeBody = null;'''
(r/'ExecutableScript.cs').write_text(text.replace(needle,replacement),encoding='utf-8')
(r/'Directory.Build.props').write_text(f'''<Project>
  <Import Project="D:/code/Lython/Directory.Build.props" />
  <PropertyGroup>
    <BaseOutputPath>{r.as_posix()}/out/$(MSBuildProjectName)/</BaseOutputPath>
    <BaseIntermediateOutputPath>{r.as_posix()}/obj/$(MSBuildProjectName)/</BaseIntermediateOutputPath>
    <NuGetLockFilePath>{r.as_posix()}/locks/$(MSBuildProjectName).json</NuGetLockFilePath>
    <DefaultItemExcludes>$(DefaultItemExcludes);$(MSBuildProjectDirectory)/bin/**;$(MSBuildProjectDirectory)/obj/**</DefaultItemExcludes>
  </PropertyGroup>
  <PropertyGroup Condition="'$(MSBuildProjectName)' == 'Lokad.Lython'">
    <DefaultItemExcludes>$(DefaultItemExcludes);Frontend/ExecutableScript.cs</DefaultItemExcludes>
  </PropertyGroup>
  <ItemGroup Condition="'$(MSBuildProjectName)' == 'Lokad.Lython'">
    <Compile Include="{r.as_posix()}/ExecutableScript.cs" Link="Frontend/ExecutableScript.cs" />
  </ItemGroup>
</Project>
''',encoding='utf-8')
normal={n:hashlib.sha256((repo/n).read_bytes()).hexdigest()for n in before['sourceHashes']}
for n in ['Directory.Build.props','Directory.Packages.props','src/Lokad.Lython/Lokad.Lython.csproj','src/Lokad.Lython/packages.lock.json','src/Lokad.Lython/obj/project.assets.json']:
    if(repo/n).is_file():normal[n]=hashlib.sha256((repo/n).read_bytes()).hexdigest()
for tfm in ['net11.0','net10.0']:
    for name in ['Lokad.Lython.dll','Lokad.Lython.pdb']:
        n='src/Lokad.Lython/bin/Release/'+tfm+'/'+name
        normal[n]=hashlib.sha256((repo/n).read_bytes()).hexdigest()
(r/'normal-state-before.json').write_text(json.dumps(normal,indent=2)+'\n',encoding='utf-8')
(r/'proposal.json').write_text(json.dumps({'reference':'Fully qualified2ec9d67f/c9829194, current production unchanged.','scope':'One private counterfactual, native helper bodies discarded after identical preparation/call facts. No source/pin/normal-output change or public disable switch. Two unchanged complete helper scripts through both APIs, no VM or compilation performance campaign.','question':'How much work/allocation does the normal executable helper entry add versus the retained closed native route? Inform a coherent complete-call design; do not infer removable native-proof shares or forecast a speedup.','stop':'Stop after both whole-script goldens/balances/cleanup and one diagnostic pass, or preserve concrete failure. Source assessment must name an actual displaced stage before selecting a redesign; no automatic arena/JIT/value-tagging rewrite.','nativeMetadataDiscarded':True,'candidateSourceOverrideSHA256':hashlib.sha256((r/'ExecutableScript.cs').read_bytes()).hexdigest(),'beforeSourceSHA256':hashlib.sha256(path.read_bytes()).hexdigest(),'runtimeDependencies':'Normal unchanged0.4 adapter only; core isolated override build.'},indent=2)+'\n',encoding='utf-8')
print('Prepared isolated two-script call-route counterfactual; normal source/pins/outputs untouched. Build only after restoration checks finish.')
