from pathlib import Path
import json, os, subprocess

lab=Path(__file__).resolve().parent
repo=Path.cwd()
trial=repo/'.git/agent-worktrees/definition-publication-r654'
sdk=Path.home()/'.dotnet11'
python=Path('C:/Python313')
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=os.pathsep.join((str(sdk),str(python),os.environ['PATH'])))
source=[
'''def named(): return 'old'
def decorator(obj):
    print(globals()['named'](), obj())
    return obj
@decorator
def named(): return 'new'
print(named(),globals()['named'] is named)''',
'''def remember():
    def local(): return 'old'
    def decorator(obj):
        print(local(),obj())
        return obj
    @decorator
    def local(): return 'new'
    print(locals()['local']() if 'local' in locals() else 'missing')
remember()''',
'''def outer():
    def selected(n): return 99
    def replace():
        nonlocal selected
        def selected(n): return 0 if n == 0 else 1 + selected(n-1)
    replace()
    return selected
print(outer()(4))''',
'''def outer():
    def value(x): return 9
    def change():
        nonlocal value
        def value(x=(yield 'ready')): return x
        yield value()
    cursor=change()
    print(next(cursor),cursor.send(3),value())
outer()''',
'''from __future__ import annotations
def outer(n):
    def f(x: int = n) -> int: return x
    return f
f=outer(7)
print(f(),f.__annotations__)''',
'''def guard():
    def selected(): return 'prior'
    def broken(replacement):
        print(selected(),replacement())
        raise ValueError('decorator failed')
    try:
        @broken
        def selected(): return 'new'
    except ValueError as e:
        print(str(e),selected())
    finally:
        print(locals()['selected']())
guard()''',
'''def initial(): return 'old'
def factory():
    global initial
    def result(): return 'new'
    def initial(): return result()
    return initial
print(factory()(),globals()['initial']())''',
'''class Box:
    def make(self):
        def inner(value=3): return value
        return inner
print(Box().make()())''',
]
serialized=json.dumps(source,ensure_ascii=False).encode('utf8')
(lab/'semantic-probes.json').write_bytes(serialized)
for role,path in (('reference',repo),('candidate',trial)):
    probe=path/'tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll'
    assert probe.is_file()
    for label,mode in (('sync',[]),('async',['--async'])):
        result=subprocess.run([sdk/'dotnet.exe',probe,'--batch-json','--compare-python',*mode],input=serialized,capture_output=True,
            env=env,timeout=90)
        (lab/f'probes-{role}-{label}.jsonl').write_bytes(result.stdout)
        (lab/f'probes-{role}-{label}.log').write_bytes(result.stderr)
        print(role,label,result.returncode,len(result.stdout.splitlines()))
        if result.stderr: print(result.stderr.decode('utf8',errors='replace')[:800])
