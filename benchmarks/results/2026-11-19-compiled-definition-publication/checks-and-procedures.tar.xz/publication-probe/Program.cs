using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;
using Lokad.Lython.Frontend;

using var catalog = JsonDocument.Parse(File.ReadAllText(args[0]));
var rows = new List<object>();
foreach (var entry in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var syntax = LythonFrontend.Compile(entry.GetProperty("source").GetString()!);
    var code = ExecutableScript.Compile(LoweredScript.Lower(syntax.Script!)).EntryPoint;
    rows.Add(new { id = entry.GetProperty("id").GetString(), code = Describe(code) });
}
Console.WriteLine(JsonSerializer.Serialize(new
{
    coreSha256 = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))),
    rows,
}));

static object Describe(ExecutableCodeObject code)
{
    var definitions = new List<object>();
    var children = new List<object>();
    for (var index = 0; index < code.Instructions.Length; index++)
    {
        var instruction = code.Instructions[index];
        if (instruction.OpCode != ExecutableOpCode.ApplyOperation ||
            code.Constants[instruction.ConstantIndex] is not ExecutableCreateFunction definition) continue;
        definitions.Add(new { definition.Binding.Name, definition.AnnotationsOnStack, instruction.HasResultConsumer,
            next = code.Instructions[index + 1].OpCode.ToString() });
        children.Add(Describe(definition.Binding.CodeObject));
    }
    return new { code.Name, code.ValueStorageCapacity, size = code.Instructions.Length, definitions, children };
}
