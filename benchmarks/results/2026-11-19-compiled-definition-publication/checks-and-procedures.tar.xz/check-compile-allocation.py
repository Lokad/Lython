from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess

lab=Path(__file__).resolve().parent
bins=lab.parent/'prepared-compiler-bindings-r627/compile-allocation/bin/candidate'
sdk=Path.home()/'.dotnet11'; dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
values=[]
for role in ('reference','candidate'):
    target=lab/'compile-allocation'/role; target.mkdir(parents=True,exist_ok=False)
    for name in ('CompileAllocation.dll','CompileAllocation.deps.json','CompileAllocation.runtimeconfig.json'):
        shutil.copyfile(bins/name,target/name)
    core=lab/'frozen'/role/'Lokad.Lython.dll'
    shutil.copyfile(core,target/core.name)
    output=target/'result.json'
    with output.open('wb') as out,(target/'run.log').open('wb') as err:
        subprocess.run([dotnet,target/'CompileAllocation.dll',lab/'catalog.json'],env=env,stdout=out,stderr=err,check=True,timeout=90)
    result=json.loads(output.read_text(encoding='utf8'))
    assert result['coreSha256']==hashlib.sha256(core.read_bytes()).hexdigest()
    values.append(result['rows'])
for left,right in zip(*values,strict=True):
    assert left['id']==right['id']
    a,b=statistics.median(left['bytes']),statistics.median(right['bytes'])
    print(left['id'],int(a),int(b),round(100*(b/a-1),3))
