set -e
cd /mnt/d/code/Lython/.git/agent-worktrees/definition-publication-r654
export PATH="$HOME/.dotnet:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/definition-publication-r654
out="$PWD/tests/artifacts/r654-wsl"
dotnet build tools/LythonProbe/LythonProbe.csproj -c Release -f net10.0 --artifacts-path "$out" > "$logs/probe-wsl-net10.log" 2>&1
expected=tools/LythonProbe/bin/Release/net10.0
mkdir -p "$expected"
cp -R "$out/bin/LythonProbe/release_net10.0/." "$expected"
filter='(FullyQualifiedName~Definition|FullyQualifiedName~NamedFunctionBinding|FullyQualifiedName~Annotation|FullyQualifiedName~AnnotatedHelper|FullyQualifiedName~Import|FullyQualifiedName~Closure|FullyQualifiedName~GlobalNamespace|FullyQualifiedName~BoundLoopNameStorage|FullyQualifiedName~GovernedMemoryContract|FullyQualifiedName~NativeFunctionRefund|FullyQualifiedName~AsyncMidFlightCancellation)&Category!=Stress'
for p in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="$logs/$p-wsl-net10.log"
    dotnet test "tests/$p" -c Release -f net10.0 --artifacts-path "$out" --filter "$filter" > "$log" 2>&1 || (tail -34 "$log"; exit 1)
    tail -5 "$log"
done
