from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tempfile
import time
from statistics import median

root = Path(__file__).resolve().parent
repository = root.parents[4]
source = root.parent / "dfabddb88/source.json"
identity = json.loads(source.read_text(encoding="utf-8"))
declared = json.loads((root / "smoke-fresh.json").read_text(encoding="utf-8"))
original = Path(declared["launched"]["adapter"]["path"]).parent
adapter = Path(declared["launched"]["adapter"]["path"]).name
dotnet = Path(declared["launched"]["dotnet"]["path"])
trace_source = repository / ".git/agent-worktrees/fresh-setup-attribution-20261123"
assembly = trace_source / "benchmarks/Lokad.Lython.Benchmarks/bin/Release/net11.0" / adapter
profile = root / "frozen-traced"
digest = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()
assert {n: digest(original / n) for n in identity["imageFiles"]} == identity["imageFiles"]
profile.mkdir()
for name in identity["imageFiles"]:
    shutil.copyfile((assembly if name == adapter else original / name), profile / name)
profile_files = {n: digest(profile / n) for n in identity["imageFiles"]}
assert [n for n in profile_files if profile_files[n] != identity["imageFiles"][n]] == [adapter]
environment = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
payloads = sorted(Path(declared["payloadDirectory"]).glob("*.json"))
assert len(payloads) == 3
rows, counts = [], {}
for repeat in range(7):
    order = repeat % len(payloads)
    for payload in payloads[order:] + payloads[:order]:
        case, = json.loads(payload.read_text(encoding="utf-8"))["cases"]
        roles = [("original", original), ("timed", profile)]
        for role, folder in roles[::(-1 if repeat % 2 else 1)]:
            with tempfile.TemporaryDirectory(prefix="lython-comparison-files-") as fixture:
                start = time.perf_counter_ns()
                result = subprocess.run([dotnet, folder / adapter, "--compare", "once", "--catalog", payload],
                    cwd=fixture, env=environment, capture_output=True, check=True, timeout=20)
                end = time.perf_counter_ns()
            assert int.from_bytes(result.stdout[:4], "big") == len(result.stdout) - 4
            frame = json.loads(result.stdout[4:])
            response = frame["response"]
            assert response["status"] == "Equivalent" and response["completedInvocations"] == 1
            assert response["actualOutputSha256"] == case["expectedOutputSha256"]
            assert response["actualFilesSha256"] == case["expectedFilesSha256"]
            phases = dict((name, float(ms)) for name, ms in
                (line.split() for line in result.stderr.decode("utf-8").splitlines()))
            assert len(phases) == (9 if role == "timed" else 0)
            elapsed = (end - start) / 1e6
            row = dict(repeat=repeat, workload=case["id"], role=role, parentMs=elapsed, phases=phases)
            rows.append(row)
            counts.setdefault((case["id"], role), []).append(row)
            print(row, flush=True)

summary = {}
for (name, role), rows_for_case in counts.items():
    phases = {key: median(r["phases"][key] for r in rows_for_case) for key in rows_for_case[0]["phases"]}
    summary.setdefault(name, {})[role] = dict(parentMs=median(r["parentMs"] for r in rows_for_case), phases=phases)
    print(name, role, summary[name][role])
(root / "local-attribution.json").write_text(json.dumps(dict(
    boundary="Windows direct worker, Stopwatch milestones in benchmark adapter only; timing diagnostics",
    source=identity["retained"], imageFiles=profile_files, observations=rows, medians=summary
), indent=2) + "\n", encoding="utf-8")
