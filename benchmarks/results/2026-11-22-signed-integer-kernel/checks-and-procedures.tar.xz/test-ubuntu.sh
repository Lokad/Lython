#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/signed-integer-kernel-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
dir=/mnt/d/code/Lython/.git/agent-notes/review-20261031/signed-integer-kernel-20261122
white='Category!=Stress&(FullyQualifiedName~NativeIntegerChain|FullyQualifiedName~ExecutableAugmented|FullyQualifiedName~DirectOperand|FullyQualifiedName~IntegerBinaryAdmission|FullyQualifiedName~IntegerAdditionAdmission|FullyQualifiedName~CounterIntegerAdmission|FullyQualifiedName~IntegerAliasOwnership|FullyQualifiedName~ExecutableAsyncIteratorCleanup)'
public='Category!=Stress&(FullyQualifiedName~SharedIntegerChain|FullyQualifiedName~NativeIntegerChain|FullyQualifiedName~NumericArithmetic|FullyQualifiedName~NumericAugmented|FullyQualifiedName~OperandReadFailure|FullyQualifiedName~IntegerBinarySemantics|FullyQualifiedName~IntegerLocalSemantics|FullyQualifiedName~IntegerPublication|FullyQualifiedName~ExactIntegerAddition|FullyQualifiedName~CapturedScalar|FullyQualifiedName~FloatArithmeticPipeline|FullyQualifiedName~RangeSlotTransport|FullyQualifiedName~AdmissionFailureCommand)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter "$white" --artifacts-path /tmp/lython-signed-integer-b1360 --verbosity quiet > "$dir/white-ubuntu.log" 2>&1 || { tail -45 "$dir/white-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter "$public" --artifacts-path /tmp/lython-signed-integer-b1360 --verbosity quiet > "$dir/public-ubuntu.log" 2>&1 || { tail -55 "$dir/public-ubuntu.log"; exit 1; }
grep -H 'Passed!' "$dir/white-ubuntu.log" "$dir/public-ubuntu.log"