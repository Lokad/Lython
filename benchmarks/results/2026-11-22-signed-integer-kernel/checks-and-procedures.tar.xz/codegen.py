from pathlib import Path
import concurrent.futures, hashlib, json,os,subprocess
lab=Path(".git/agent-notes/review-20261031/signed-integer-kernel-20261122").resolve()
read=lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
catalog=read(lab/"representative.json")
catalog["cases"]=[c for c in catalog["cases"] if c["id"] in ("diagnostic.loop-range.inside.large","scripts.ordinary-fully-supplied-helper")]
target=lab/"codegen-cases.json"
target.write_text(json.dumps(catalog,indent=2)+"\n",encoding="utf-8")
ident=read(lab/"identity.json")
sdk=Path.home()/".dotnet11"
def run(role):
 image=lab/"frozen"/role
 expected=ident["imageFiles"][role]
 assert len(expected)==32 and {file:sha(image/file) for file in expected}==expected
 capture=lab/f"{role}-codegen.txt"
 env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"],
          DOTNET_TieredCompilation="0",
          DOTNET_JitDisasm="*TryMachineBinary*",
          DOTNET_JitStdOutFile=str(capture))
 subprocess.run([sdk/"dotnet.exe",image/"ValidatedAllocation.dll",image,target,lab/f"{role}-codegen-invocations.json"],env=env,check=True,timeout=75)
 report=capture.read_text(encoding="utf-8")
 return role,[l for l in report.splitlines() if l.startswith("; Assembly listing") or l.startswith("; Total bytes")]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for role,lines in pool.map(run,("reference","candidate")):
  print(role)
  for line in lines: print(line)
