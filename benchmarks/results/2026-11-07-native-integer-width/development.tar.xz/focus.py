from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
r=Path(__file__).parent;out=r/(sys.argv[1] if len(sys.argv)>1 else 'attempt1');out.mkdir()
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
filters={'Lokad.Lython.Tests':'Category!=Stress&(FullyQualifiedName~IntegerText|FullyQualifiedName~SimpleFunctionExecutionBoundary|FullyQualifiedName~IntegerAlias|FullyQualifiedName~IntegerProtocol|FullyQualifiedName~IntegerConversionSlot)', 'Lokad.Lython.PublicApi.Tests':'Category!=Stress&(FullyQualifiedName~Utf8IntegerParse|FullyQualifiedName~UnicodeIntegerText|FullyQualifiedName~GeneralIntegerText)'}
checks={}
for t in ['net11.0','net10.0']:
 for project,selection in filters.items():
  name=project+'-'+t+'.log'
  with(out/name).open('w',encoding='utf-8')as log:
   d=subprocess.run([env['DOTNET_HOST_PATH'],'test','tests/'+project+'/'+project+'.csproj','-c','Release','-f',t,'--nologo','--filter',selection,'--logger','console;verbosity=normal','-v','quiet'],env=env,stdout=log,stderr=subprocess.STDOUT)
  text=(out/name).read_text(encoding='utf-8');checks[name]=dict(exitCode=d.returncode,selection=selection,tail=text[-1800:]);print(name,'exit',d.returncode,'\n'+'\n'.join(text.splitlines()[-5:]),flush=True)
  if d.returncode:
   (out/'failed-focused.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8',newline='\n');raise SystemExit(d.returncode)
 folder=out/t;folder.mkdir();shutil.copy2('src/Lokad.Lython/bin/Release/'+t+'/Lokad.Lython.dll',folder/'Lokad.Lython.dll')
identity=dict(checks=checks,coreSHA256={t:hashlib.sha256((out/t/'Lokad.Lython.dll').read_bytes()).hexdigest()for t in ['net11.0','net10.0']},productionSources={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in Path('src/Lokad.Lython').rglob('*.cs')if not any(s in p.parts for s in ['bin','obj'])},fullDeliveryPending=True)
(out/'focused.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n');print('R50 focused source/images frozen; no new full delivery claim.',flush=True)
