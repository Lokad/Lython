from pathlib import Path
import hashlib,json,os,shutil
r=Path(__file__).parent;home=r.parent;old=home/'integer-utf8-r45'
checks=json.loads((r/'attempt1/focused.json').read_text(encoding='utf-8'));before=json.loads((r/'before.json').read_text(encoding='utf-8'))
for name,digest in checks['productionSources'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest
for role,core in [('before',r/'baseline/net11.0/Lokad.Lython.dll'),('candidate',r/'attempt1/net11.0/Lokad.Lython.dll')]:
 target=r/'images'/role;shutil.copytree(home/'module-bindings-r49/images/candidate',target,copy_function=os.link)
 (target/'Lokad.Lython.dll').unlink();shutil.copy2(core,target/'Lokad.Lython.dll')
shutil.copy2(old/'catalog.json',r/'catalog.json')
identity=dict(baselineSource=before['source'],baselineCore=before['cores'],candidateCore=checks['coreSHA256'],productionSources=checks['productionSources'],purpose='R50 one managed UInt128 accumulator: reuse R45 five unchanged fixtures/driver. Native-word promotion/output funding; no frontend change. Warm sync/async only, precise allocation/shared ALCs/CoreLib/hash witness/process GC,32warmups/image,5rotated4job rounds. Desktop clocks diagnostic. No compilation speedup, VM, CPU/RSS/tail or full delivery claim.',fullDeliveryPending=True)
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(home/'module-bindings-r49/measure.py').read_text(encoding='utf-8').replace("[('warm','sync'),('warm','async'),('compile','sync')]","[('warm','sync'),('warm','async')]")
(r/'measure.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'summarize-local.py').read_text(encoding='utf-8').replace("['warm-sync','warm-async','compile-sync']","['warm-sync','warm-async']")
(r/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
print('R50 two affected inputs and three original controls frozen; existing tool reused, no timing yet.')
