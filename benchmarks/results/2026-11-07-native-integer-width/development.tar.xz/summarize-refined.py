from pathlib import Path
import json,statistics
r=Path(__file__).parent;rows=[]
for phase in ['refined-warm-sync','refined-warm-async']:
 d=json.loads((r/phase/'measurements.json').read_text(encoding='utf-8'))
 for item in d['observations']:
  grouped={k:[s for s in item['samples']if s['image']==k]for k in ['before','candidate','before-control']}
  med=lambda role,key:statistics.median(s[key]/s['jobs']for s in grouped[role])
  allocated={k:med(k,'allocatedBytes')for k in grouped};elapsed={k:med(k,'elapsedMilliseconds')for k in grouped}
  row=dict(phase=phase,case=item['caseId'],allocatedBytes=allocated,allocationChangePercent=100*(allocated['candidate']/allocated['before']-1),elapsedMilliseconds=elapsed,elapsedChangePercent={k:100*(elapsed['candidate']/elapsed[k]-1)for k in ['before','before-control']},baselineSpreadPercent=100*(elapsed['before-control']/elapsed['before']-1),peaks=item['admittedPeaks'])
  rows.append(row)
  print(phase,item['caseId'],'allocation',round(row['allocationChangePercent'],3),'desktop elapsed',[round(x,2)for x in row['elapsedChangePercent'].values()],'control',round(row['baselineSpreadPercent'],2))
(r/'refined-local-summary.json').write_text(json.dumps(dict(rows=rows,elapsedQualification=False,limitation='Desktop clocks with shared process GC and isolated ALCs; no CPU/embedding-latency claim.'),indent=2)+'\n',encoding='utf-8',newline='\n')
