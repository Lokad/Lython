from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).parent;env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
checks=json.loads((r/'attempt2/focused.json').read_text(encoding='utf-8'));assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in checks['productionSources'].items())
stress={}
for t in ['net11.0','net10.0']:
 name='refined-real-cancellation-'+t+'.log'
 with(r/name).open('w',encoding='utf-8')as log:
  done=subprocess.run([env['DOTNET_HOST_PATH'],'test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f',t,'--no-build','--nologo','--filter','FullyQualifiedName~IntegerTextCancellationTests.CancellationDuringMagnitudeWorkDrainsBeforeRefund','--logger','console;verbosity=normal','-v','quiet'],env=env,stdout=log,stderr=subprocess.STDOUT)
 text=(r/name).read_text(encoding='utf-8');stress[t]=dict(exitCode=done.returncode,summary=text[-1000:]);print(t,'real in-flight cancellation exit',done.returncode,flush=True);assert done.returncode==0,text[-2500:]
(r/'refined-stress.json').write_text(json.dumps(stress,indent=2)+'\n',encoding='utf-8',newline='\n')
target=r/'images/refined';shutil.copytree(r/'images/candidate',target,copy_function=os.link);(target/'Lokad.Lython.dll').unlink();shutil.copy2(r/'attempt2/net11.0/Lokad.Lython.dll',target/'Lokad.Lython.dll')
s=(r/'measure.py').read_text(encoding='utf-8').replace("folder=r/(phase+'-'+api)","folder=r/('refined-'+phase+'-'+api)").replace("r/'images/candidate/Lokad.Lython.Benchmarks.dll'","r/'images/refined/Lokad.Lython.Benchmarks.dll'")
(r/'measure-refined.py').write_text(s,encoding='utf-8',newline='\n')
s=(r/'summarize.py').read_text(encoding='utf-8').replace("['warm-sync','warm-async']","['refined-warm-sync','refined-warm-async']").replace("r/'local-summary.json'","r/'refined-local-summary.json'")
(r/'summarize-refined.py').write_text(s,encoding='utf-8',newline='\n')
print('Refined semantics and actual in-flight cleanup pass; source/images frozen. Both initial/adverse diagnostics retained.')
