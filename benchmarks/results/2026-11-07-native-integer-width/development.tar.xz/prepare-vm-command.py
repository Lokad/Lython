from pathlib import Path
import ast,hashlib,json,re,shutil,subprocess,tarfile,zipfile
r=Path(__file__).parent;n=r/'b405';n.mkdir();home=r.parent;old=home/'integer-utf8-r45/b399'
checks=json.loads((r/'attempt2/focused.json').read_text(encoding='utf-8'));before=json.loads((r/'before.json').read_text(encoding='utf-8'))
for name,digest in checks['productionSources'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'));core=checks['coreSHA256']['net11.0']
identity.update(sourceRevision='9990d591 plus R50 managed UInt128 parsing; source/patch and exact refined focused core',purpose='R50 native integer width: padded CSV/numeric-string JSON affected and ordinary JSON representative control; two baseline/two current processes',productionSources=checks['productionSources'],qualification=checks,baselineSource='9990d591 baseline, focused actual11/10 and retained B404, full CI pending',coreSHA256={'reference':before['cores']['net11.0'],'reference-control':before['cores']['net11.0'],'candidate':core,'control':core})
def write(name,s):(n/name).write_text(s,encoding='utf-8',newline='\n')
write('identity.json',json.dumps(identity,indent=2)+'\n')
catalog=json.loads((r/'catalog.json').read_text(encoding='utf-8'));ids=['scripts.csv-summary-functions.large-padded-integers','scripts.json-summary-helpers.large-integer-strings','scripts.json-summary-helpers.large'];catalog['cases']=[next(c for c in catalog['cases']if c['id']==i)for i in ids]
write('representative.json',json.dumps(catalog,ensure_ascii=False,indent=2)+'\n')
old_remote='/home/lokad/lython-bench-checks/integer-parsing-b399-20261107';remote='/home/lokad/lython-bench-checks/integer-width-b405-20261107'
jobs=[(i,'warm')for i in ids]
for name in ['collect.py','archive-owned.py','run.sh']:
 s=(old/name).read_text(encoding='utf-8').replace(old_remote,remote).replace('len(jobs)==7','len(jobs)==3').replace("len(r['jobs'])==7","len(r['jobs'])==3").replace('jobs=7','jobs=3')
 if name=='collect.py':
  s=re.sub(r'^jobs=\[.*\]$','jobs='+repr(jobs),s,flags=re.M).replace('started < 230','started < 90').replace('Reserve40 seconds','Reserve30 seconds')
  s=s.replace('R45 integer parsing: affected CSV/JSON warm/compile-run and ordinary controls; two baseline/two current',identity['purpose'])
 if name.endswith('.py'):ast.parse(s)
 write(name,s)
shutil.copy2(r/'attempt2/net11.0/Lokad.Lython.dll',n/'current-core.dll')
write('focused.json',json.dumps(checks,indent=2)+'\n');write('fixture-validation.json',json.dumps(dict(fixturesUnchanged=True,source='Existing B400/B401 maintained manifests and independent goldens; exact source/data/output hashes preserved. No new fixture or CPython timing.'),indent=2)+'\n')
with zipfile.ZipFile(n/'source-current.zip','w',zipfile.ZIP_DEFLATED)as a:
 for name in checks['productionSources']:a.write(name,name)
 for name in ['tests/Lokad.Lython.PublicApi.Tests/Fixtures/IntegerParsing/cases.json','tests/Lokad.Lython.PublicApi.Tests/Fixtures/IntegerParsing/generate.py']:a.write(name,name)
(n/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src','tests']))
contract='R50 native integer-width confirmation. Baseline9990d591/R49 checked frozen core, final R50 UInt128/DivRem core checked on actual.NET11/10:102internal/420public including329CPython cases, plus actual in-flight cancellation Stress bothtargets. R49 full platform/Stress/package CI is independent/pending. One native accumulator, existing chunk growth and explicit admission before native>64bit output conversion; no public value change, JSON parser change, text conversion, quotas or unsafe code. Initial separate quotient/remainder source and adverse desktop clocks retained. Refined precise allocation numeric-string JSON-12.492/-12.487%sync/async; other controls essentially flat. Desktop final timings mixed; no CPU claim. Three unchanged existing warm jobs: padded CSV,40digit numeric-string JSON, ordinary JSON representative control. Same worker7cf37ca5/host/normal optional0.4/GC/tiering;2baseline/2current roles,5swarmup/role/job,7rotated150ms rounds. Warm includes mediated RAM I/O/full goldens/prior-result cleanup, not compile/startup/staging/reset/transport/final cached teardown. Full identity/source/golden/funding/quiet/Closed/exit/join/fixture and persistent archive-under-lease gates.120s owner+30s stop+30s margin, observe after180s; no early service query/restart on observation timeout. Preserve every adverse result; distinguish allocation, elapsed, coarse process CPU and source work. Existing post-promotion growth remains unchanged; no asymptotic or universal integer speedup claim. Publication postponed.'
write('contract.md',contract+'\n');write('setup-contract.json',json.dumps(dict(jobs=3,ownerSeconds=120,stopSeconds=30,marginSeconds=30,observeAfterSeconds=180),indent=2)+'\n')
p=Path('PLAN.md');plan=p.read_text(encoding='utf-8')
plan+='\nR50 active refined prototype:102internal/420public per actual11/10 pass, plus\nreal in-flight cancellation Stress bothtargets. UInt128/DivRem replaces64bit native\naccumulation; native>64bit results admitted before conversion. Numeric-string JSON\nallocation−12.492/12.487% sync/async; other controls flat. Initial source/adverse\nclocks retained; refined desktop clocks mixed. B405 planned:three warm jobs,\n120s owner+30s stop+30s margin; observe after180s. No new full qualification claim.\n'
p.write_text(plan,encoding='utf-8',newline='\n');shutil.copy2(p,n/'pre-measurement-plan.md')
with tarfile.open(n/'payload.tgz','w:gz')as a:
 for name in ['identity.json','representative.json','collect.py','archive-owned.py','run.sh','current-core.dll','source-current.zip','source.patch','focused.json','fixture-validation.json','contract.md','setup-contract.json','pre-measurement-plan.md']:a.add(n/name,arcname=name)
s=(old/'launch.py').read_text(encoding='utf-8').replace("root=base/'integer-parsing-b399-20261107'","root=base/'integer-width-b405-20261107'").replace("reference=base/'receiver-methods-b394-20261107/candidate'","reference=base/'module-bindings-b404-20261107/candidate'")
s=s.replace(" (root/'reference/Lokad.Lython.dll').unlink()\n (root/'baseline-core.dll').replace(root/'reference/Lokad.Lython.dll')\n",'')
s=s.replace("'assert len(jobs)==7 '","'assert len(jobs)==3 '").replace('"len(r[\'jobs\'])==7"','"len(r[\'jobs\'])==3"').replace('allSevenJobsValidated','allThreeJobsValidated').replace('ownerSeconds=270','ownerSeconds=120').replace('RuntimeMaxSec=270','RuntimeMaxSec=120').replace('seconds=330','seconds=180')
s=s.replace('lython-b399-integer-parsing-20261107','lython-b405-integer-width-20261107').replace('integer-parsing-b399-launch.py','integer-width-b405-launch.py')
assert 'baseline-core.dll'not in s and"root=base/'integer-width-b405-20261107'"in s
ast.parse(s);write('launch.py',s)
s=(home/'file-workflows-r47/retrieve.py').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/file-workflows-b401-20261107',remote).replace('lython-b401-file-workflows-20261107','lython-b405-integer-width-20261107').replace("['jobs']==6","['jobs']==3")
ast.parse(s);write('retrieve.py',s)
s=(home/'builtin-methods-r41/summarize-b394.py').read_text(encoding='utf-8').replace("r=Path(__file__).parent","r=Path(__file__).parent")
s=s.replace("'b394/retrieved/confirmation/confirmation.json'","'retrieved/confirmation/confirmation.json'").replace("'refined-comparison-summary.json'","'comparison-summary.json'")
ast.parse(s);write('summarize.py',s)
print('B405 three-job integer-width source-pair conditions/source/images frozen; no VM work yet.')
