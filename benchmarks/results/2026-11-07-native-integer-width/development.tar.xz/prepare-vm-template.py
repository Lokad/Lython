from pathlib import Path
import ast,hashlib,json,re,shutil,subprocess,tarfile,zipfile
r=Path(__file__).parent;n=r/'b404';n.mkdir();home=r.parent;old=home/'integer-utf8-r45/b399'
checks=json.loads((r/'attempt2/focused.json').read_text(encoding='utf-8'));before=json.loads((r/'before.json').read_text(encoding='utf-8'))
for name,digest in checks['productionSources'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'));core=checks['coreSHA256']['net11.0']
identity.update(sourceRevision='b18758e7 plus R49 actual declaration bindings; precommit source snapshot/patch and exact focused core',purpose='R49 declaration binding layout: protected search/text affected, ordinary JSON representative control; two baseline/two current processes',productionSources=checks['productionSources'],qualification=checks,baselineSource='8c9fd0d7 fully qualified production, frozen d3a6c778',coreSHA256={'reference':before['coreSHA256'],'reference-control':before['coreSHA256'],'candidate':core,'control':core})
def write(name,s):(n/name).write_text(s,encoding='utf-8',newline='\n')
write('identity.json',json.dumps(identity,indent=2)+'\n')
catalog=json.loads((r/'catalog.json').read_text(encoding='utf-8'));ids=['scripts.file-search.large','scripts.text-summary-helpers.large','scripts.json-summary-helpers.large'];catalog['cases']=[next(c for c in catalog['cases']if c['id']==i)for i in ids]
write('representative.json',json.dumps(catalog,ensure_ascii=False,indent=2)+'\n')
old_remote='/home/lokad/lython-bench-checks/integer-parsing-b399-20261107';remote='/home/lokad/lython-bench-checks/module-bindings-b404-20261107'
jobs=[(i,'warm')for i in ids]
for name in ['collect.py','archive-owned.py','run.sh']:
 s=(old/name).read_text(encoding='utf-8').replace(old_remote,remote).replace('len(jobs)==7','len(jobs)==3').replace("len(r['jobs'])==7","len(r['jobs'])==3").replace('jobs=7','jobs=3')
 if name=='collect.py':
  s=re.sub(r'^jobs=\[.*\]$','jobs='+repr(jobs),s,flags=re.M).replace('started < 230','started < 90').replace('Reserve40 seconds','Reserve30 seconds')
  s=s.replace('R45 integer parsing: affected CSV/JSON warm/compile-run and ordinary controls; two baseline/two current',identity['purpose'])
 if name.endswith('.py'):ast.parse(s)
 write(name,s)
shutil.copy2(r/'attempt2/net11.0/Lokad.Lython.dll',n/'current-core.dll')
write('focused.json',json.dumps(checks,indent=2)+'\n');write('fixture-validation.json',json.dumps(dict(fixturesUnchanged=True,source='Existing B400/B401 maintained manifests and independent goldens; exact source/data/output hashes preserved. No new fixture or CPython timing.'),indent=2)+'\n')
with zipfile.ZipFile(n/'source-current.zip','w',zipfile.ZIP_DEFLATED)as a:
 for name in checks['productionSources']:a.write(name,name)
 for name in ['tests/Lokad.Lython.PublicApi.Tests/DeclarationNamespaceTests.cs','tests/Lokad.Lython.Tests/OrdinaryFunctionTransportTests.cs']:a.write(name,name)
(n/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src','tests']))
contract='''R49 focused retention comparison: qualified8c9fd0d7/frozen d3a6c778 baseline versus exact b18758e7+R49 source/checked core. No native stack/check/call-body policy changes. Actual declaration slots replace module Name reads, retain backing namespace through frame cleanup. Shared import binding facts remove duplicate branches. Both actual.NET11/10 focused1008internal/2819public plus8CPython-frozen new cases pass; initial29loss-of-namespace failures and fix preserved. Local allocation effectively flat (within0.015%) warm, compile-0.335to+0.029%; desktop text strongly favorable, search/control movement up to36% remains uncertainty. Three existing warm jobs: protected search/text affected, ordinary JSON representative control. Same worker7cf37ca5/host/normal optional0.4/GC/tiering, two baseline/two candidate roles,5s warmup/role/job,7rotated150ms rounds. No fixture changes/new framework. Warm includes mediated RAM I/O, complete goldens and prior-result cleanup; compile/startup/staging/reset/transport/final cached teardown excluded. All Ready/core/aux/source/golden/funding/quiet/Closed/exit/join/fixture/persistent-under-lease archive gates.120s owner+30s stop+30s margin, observe after180s; no early query or restart on observation timeout. Retain all adverse conditions; elapsed/coarse process CPU/allocation/source simplification are distinct, no isolated CPU/RSS/tail claim. Full platform/stress/package qualification later at a coherent retained checkpoint; prior full delivery only baseline. Publication postponed.'''
write('contract.md',contract+'\n');write('setup-contract.json',json.dumps(dict(jobs=3,ownerSeconds=120,stopSeconds=30,marginSeconds=30,observeAfterSeconds=180),indent=2)+'\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');needle='- Validate using existing focused compiler/scope/import/namespace/cancellation/'
addition='''Active R49 prototype: declarations use actual compiled slots and keep module
namespace publication beyond frame cleanup. Initial29white-box failures expose
that lifetime requirement; fixed without weakening assertions. Eight independently
CPython/baseline-frozen namespace/snapshot cases pass;1008internal/2819public per
actual11/10 pass. Removed unused quota-era checkpoint vectors, all useful assertions
kept. Census confirms wanted and imports now use slots; no whole-module dead-name
predeclaration. Warm allocation within0.015%; compilation−0.335to+0.029%. Desktop
text strongly favorable, but search/control variability up to36% prohibits CPU
claims. B404 planned:three warm source-pair jobs, two old/two current roles;
120s owner+30s stop+30s margin, observe after180s. No full qualification repeated.

'''
assert s.count(needle)==1;s=s.replace(needle,addition+needle);p.write_text(s,encoding='utf-8',newline='\n');shutil.copy2(p,n/'pre-measurement-plan.md')
with tarfile.open(n/'payload.tgz','w:gz')as a:
 for name in ['identity.json','representative.json','collect.py','archive-owned.py','run.sh','current-core.dll','source-current.zip','source.patch','focused.json','fixture-validation.json','contract.md','setup-contract.json','pre-measurement-plan.md']:a.add(n/name,arcname=name)
s=(old/'launch.py').read_text(encoding='utf-8').replace("root=base/'integer-parsing-b399-20261107'","root=base/'module-bindings-b404-20261107'").replace("reference=base/'receiver-methods-b394-20261107/candidate'","reference=base/'integer-parsing-b399-20261107/candidate'")
s=s.replace(" (root/'reference/Lokad.Lython.dll').unlink()\n (root/'baseline-core.dll').replace(root/'reference/Lokad.Lython.dll')\n",'')
s=s.replace("'assert len(jobs)==7 '","'assert len(jobs)==3 '").replace('"len(r[\'jobs\'])==7"','"len(r[\'jobs\'])==3"').replace('allSevenJobsValidated','allThreeJobsValidated').replace('ownerSeconds=270','ownerSeconds=120').replace('RuntimeMaxSec=270','RuntimeMaxSec=120').replace('seconds=330','seconds=180')
s=s.replace('lython-b399-integer-parsing-20261107','lython-b404-module-bindings-20261107').replace('integer-parsing-b399-launch.py','module-bindings-b404-launch.py')
assert 'baseline-core.dll'not in s and"root=base/'module-bindings-b404-20261107'"in s
ast.parse(s);write('launch.py',s)
s=(home/'file-workflows-r47/retrieve.py').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/file-workflows-b401-20261107',remote).replace('lython-b401-file-workflows-20261107','lython-b404-module-bindings-20261107').replace("['jobs']==6","['jobs']==3")
ast.parse(s);write('retrieve.py',s)
s=(home/'builtin-methods-r41/summarize-b394.py').read_text(encoding='utf-8').replace("r=Path(__file__).parent","r=Path(__file__).parent")
s=s.replace("'b394/retrieved/confirmation/confirmation.json'","'retrieved/confirmation/confirmation.json'").replace("'refined-comparison-summary.json'","'comparison-summary.json'")
ast.parse(s);write('summarize.py',s)
print('B404 three-job source-pair conditions/source/images frozen; no VM work yet.')
