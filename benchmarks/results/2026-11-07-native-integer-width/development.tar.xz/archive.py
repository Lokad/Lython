from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;b=r/'b405';out=Path('benchmarks/results/2026-11-07-native-integer-width');out.mkdir()
checks=json.loads((r/'attempt2/focused.json').read_text(encoding='utf-8'));assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in checks['productionSources'].items())
for name in ['before.json','identity.json','source-contract.md','refined-stress.json','local-summary.json','refined-local-summary.json']:
 (out/name).write_text((r/name).read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
(out/'focused.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8',newline='\n')
target=out/'b405';target.mkdir()
for name in ['observations.tgz','archive-receipt.json','terminal-status.json','comparison-summary.json']:
 if name.endswith('.json'):(target/name).write_text((b/name).read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
 else:shutil.copy2(b/name,target/name)
receipt=json.loads((b/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['jobs']==3
assert hashlib.sha256((target/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
(r/'final-source.patch').write_bytes(subprocess.check_output(['git','-c','core.autocrlf=false','diff','--binary','--','src','tests','docs','CHANGELOG.md']))
with tarfile.open(out/'development.tar.xz','w:xz')as a:
 for p in r.iterdir():
  if p.is_file()and p.suffix in ['.py','.json','.md','.log','.patch','.cs']:a.add(p,arcname=p.name)
 for folder in ['baseline','attempt1','attempt2','warm-sync','warm-async','refined-warm-sync','refined-warm-async']:
  for p in(r/folder).rglob('*'):
   if p.is_file():a.add(p,arcname=p.relative_to(r))
 for p in b.iterdir():
  if p.is_file()and p.suffix in ['.py','.json','.md','.log','.sh']:a.add(p,arcname=p.relative_to(r))
 for name in ['src/Lokad.Lython/Runtime/LythonRuntime.IntegerParsing.cs','tests/Lokad.Lython.PublicApi.Tests/Fixtures/IntegerParsing/generate.py','tests/Lokad.Lython.PublicApi.Tests/Fixtures/IntegerParsing/cases.json']:a.add(name,arcname='final-source/'+name)
decision=dict(retained=True,baseline='9990d591 production, frozen R49 precommit core; full CI in progress at collection.',source='9990d591 plus preserved R50 single-production-file patch; final DivRem source and cores in focused.json',admittedTradeoff='Padded CSV +0.99to+1.16% elapsed with stable roles; accept this bounded cost for numeric-string JSON allocation-12.492/-12.487% sync/async and controlled warm-10.68to-12.50%. No UInt64 rescue tier or further unchanged retiming.',limitations='Ordinary JSON control variable, no async elapsed/isolated CPU/RSS/tail/asymptotic improvement claim. Post-promotion chunk growth remains. Tiny-budget admission timing may change; every retained >64bit result remains preflighted.',developmentSHA256=hashlib.sha256((out/'development.tar.xz').read_bytes()).hexdigest(),fullDelivery='Pending coherent Windows/Ubuntu actual11/10 Stress/installed consumer qualification for retained source; earlier R49 delivery is independent.')
(out/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
readme='''# Native integer width and admitted promotion — R50

2026-11-07. Baseline9990d591/R49 checked core; candidate9990d591 plus the preserved
single-production-file patch and329-case CPython fixture. Final core/source hashes
are in focused.json. R49's independently active full CI does not qualify this later
source. No new dependency, opcode, owner/cache, public value type or resource policy.

One managed UInt128 accumulator replaces UInt64 in the existing general UTF8 int
kernel. Native prefix/remainder overflow guards avoid per-digit division; larger
values retain the same cancellable radix chunks. Native>64bit final values admit
magnitude/metadata/replacement overlap before conversion to BigInteger. Only retained
payload is committed, scratch refunds after users end. Guest integers remain
BigInteger, byte inputs retain ASCII grammar, Unicode strings use existing decimal
properties. JSON's efficient CLR decimal parser is unchanged; this does not revive
R46's adverse parser consolidation. No decoded text, unsafe code, tiers/knobs, exact
object ledger, retry or collection dependency.

Admission can occur later because no heap magnitude is constructed while the value
fits128bits. Tiny thresholds and error-versus-first-admission timing can therefore
change; explicit refusal remains terminal. No exemption for retained native>64bit
results. Scan/chunk and post-admission cancellation remain. Individual BCL arithmetic
operations remain atomic; post-promotion scaling is unchanged, not a solution to
R46's arbitrary large-decimal allocation gap.

Initial and refined102internal/420public checks per actual.NET11/10 pass.
CPython3.13.2 freezes329cases, including140additional127/128bit, promotion and
negative boundaries across bases2–36. Existing signs/prefix/Unicode/underscore/
whitespace/bytes/errors, first refusal, input/alias/result funding and budget reuse
stay. Actual in-flight1MiB magnitude cancellation Stress passes both runtimes
(observed49/53ms, not a latency guarantee), joins users before refund and retains
the input owner. No timeouts or assertions weakened.

The initial source computes quotient/remainder separately. A supported.NET10/11
DivRem refinement removes that duplicate work, preserving all source/images and
initial adverse clocks. Refined warm allocation for numeric-string JSON falls
12.492%sync/12.487%async; other maintained inputs are within0.009%. Admitted peaks
and retained output funding are separate from GC allocation. There is no frontend
change or compilation improvement claim. The unchanged five-case reflection driver
uses32warmups/image,5rotated rounds*4jobs, isolated before/current/before-control
ALCs sharing CoreLib/hash witness/process GC. Normal GC/tiering. Its old R45 purpose
label is historical; R50's source/catalog identifies these jobs. Desktop clocks are
diagnostic: initial numeric-string sync+3.94–5.44%, final−10.87–11.59%, while
unaffected/control movement is substantial. Preserve every original observation.

## Controlled quiet-VM comparison — B405

Same unchanged fixtures, worker7cf37ca5/host/adapter27211dbe/normal0.4,
two baseline/two identical current processes. Quiet F4as_v7/Ubuntu24.04.4,
four EPYC9V45vCPUs/16GiB/no swap/.NET11RC3 normal GC/tiering.5s warmup/role/job,
7rotated150ms rounds. Three warm jobs complete87.38s,120s owner+30s stop+30s
margin, observed after180s. Full Ready/source/core/aux/golden/funding/quiet/Closed/
exit/join/fixture gates pass. Raw2f2e6618 archived/verified under collection lease
and independently after retrieval; no active users or fixtures.

| Warm input | Baseline ms | Current ms | All role pairings | Current / baseline role spread |
| --- | ---: | ---: | ---: | ---: |
| Padded CSV,191505B |4.290176–4.292434|4.335009–4.339769|+0.99to+1.16%|0.11%/0.05%|
|40-digit numeric-string JSON,278528B|7.555452–7.687586|6.726565–6.748830|−12.50to−10.68%|0.33%/1.72%|
| Ordinary JSON,110592B |3.957616–4.012621|3.976475–4.105685|−0.90to+3.74%|3.25%/1.39%|

Ranges span medians, not confidence intervals. Numeric strings include an explicit
int helper; CSV keeps its maintained source with padded values. Ordinary JSON does
not use this string-int parser and remains a variable control. Coarse process CPU
moves consistently on affected inputs but is not isolated-method CPU. Warm includes
mediated RAM I/O/full stdout/files/prior-result cleanup; compile/startup/staging/
reset/transport/final cached teardown excluded. No CPython remeasurement or cross-run
ratio. Keep the primary source8c9fd0d7 CPython tables historically labelled.

**Retain** lower intermediate magnitude allocation and numeric-string elapsed
improvement. Explicitly accept the measured~1.1%padded-CSV cost; do not add another
native tier merely to rescue it. Ordinary control variation, older regression
debt and larger-input uncertainty remain; no universal or async elapsed claim.
Full platform/Stress/installed-package qualification is pending for the retained
source. Publication remains postponed; the broader objective is active.

[Raw controlled observations](b405/observations.tgz), [four-role summary](b405/comparison-summary.json),
[receipt](b405/archive-receipt.json), [refined allocation/adverse desktop clocks](refined-local-summary.json),
[initial clocks](local-summary.json), [focused source/cores](focused.json),
[real in-flight cancellation](refined-stress.json), [decision](decision.json),
[all source/failure/initial/final/images/contracts](development.tar.xz).
'''
(out/'README.md').write_text(readme,encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');s+='\n## Managed native integer width (2026-11-07)\n\nR50 uses one UInt128 accumulator/DivRem guard, retains arbitrary chunks and funds\nnative>64bit output before conversion.102internal/420public per actual11/10 plus\nreal cancellation pass. Allocation numeric strings−12.492/12.487%; B405warm\n−10.68–12.50%, padded CSV+0.99–1.16% accepted explicitly. Initial/refined adverse\ndesktop/control data remain. No universal CPU/async/scaling claim or JSON-parser\nchange. [Evidence and qualification status](results/2026-11-07-native-integer-width/README.md).\n';p.write_text(s,encoding='utf-8',newline='\n')
print('R50 retained, including explicit padded-case regression; archive SHA256',decision['developmentSHA256'])
