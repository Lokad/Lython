from pathlib import Path
import hashlib,json,os,shutil,subprocess
lab=Path(__file__).resolve().parent
base=lab.parent
repo=lab.parents[3]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
save=lambda p,o:p.write_text(json.dumps(o,indent=2)+'\n',encoding='utf-8',newline='\n')
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
python=Path('C:/Python313/python.exe')
donor=base/'shared-parser-statements-20261124'
core='Lokad.Lython.dll'
last=read(donor/'comparison/identity.json')
reference_files=last['imageFiles']['candidate']
reference_image=donor/'candidate'
assert len(reference_files)==32 and {p.name:sha(p) for p in reference_image.iterdir()}==reference_files
candidate=base/'callable-pair-rollback-20261124/windows/bin/Lokad.Lython/release_net11.0'/core
assert sha(candidate)!=reference_files[core]
images={'reference':reference_files, 'candidate':reference_files|{core:sha(candidate)}}
for role,expected in images.items():
    folder=lab/role
    folder.mkdir(exist_ok=True)
    for name in expected:shutil.copyfile(candidate if role=='candidate' and name==core else reference_image/name,folder/name)
    assert {p.name:sha(p) for p in folder.iterdir()}==expected
old=read(donor/'catalog.json')
other=read(base/'config-phases-r336/rendered-catalog.json')
cases=['scripts.config-manifest.small','scripts.config-generated-guards.medium.bad-0.sparse-lexical',
       'scripts.csv-summary-functions.small','scripts.json-summary-helpers.small']
catalog=lab/'catalog.json'
save(catalog,old|{'cases':[next(item for item in old['cases']+other['cases'] if item['id']==name) for name in cases]})
patch=subprocess.check_output(['git','diff','--binary','--','src','tests'],cwd=repo)
(lab/'candidate.patch').write_bytes(patch)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head.startswith('11429d3e9')
identity=dict(reference=head,sourcePatchSHA256=sha(lab/'candidate.patch'),catalogSHA256=sha(catalog),
    imageFiles=images,pythonSHA256=sha(python),pythonWorkerSHA256=sha(repo/'benchmarks/cpython-worker.py'))
save(lab/'identity.json',identity)
common=['--catalog',catalog,'--dotnet',dotnet,'--python',python,'--python-worker',repo/'benchmarks/cpython-worker.py']
for role,expected in images.items():
    output=lab/f'{role}-verify.json'
    subprocess.run([dotnet,lab/role/'Lokad.Lython.Benchmarks.dll','--compare','verify',*common,'--out',output],
        env=env,cwd=repo,check=True,timeout=75)
    proof=read(output)
    assert proof['state']=='Completed' and proof['caseCount']==len(cases) and proof['catalogSha256']==sha(catalog)
    assert proof['launched']['library']['sha256']==expected[core]
print('Verified four complete CPython goldens on both exact 32-file images.',flush=True)
