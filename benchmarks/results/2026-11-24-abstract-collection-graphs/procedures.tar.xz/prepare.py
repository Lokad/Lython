from pathlib import Path
import json,subprocess
lab=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
origins=['syntax-function-roots-20261124/catalog.json','config-phases-r336/rendered-catalog.json',
         'abstract-state-snapshots-20261123/comparison/representative.json']
ids=['scripts.config-manifest.small','scripts.config-edit.small','scripts.config-generated-guards.medium.bad-0.sparse-lexical',
     'scripts.dataclass-inherited-configuration.generated','scripts.annotated-rule-closures.nested-factories.postponed',
     'scripts.csv-summary-functions.small','scripts.json-summary-helpers.small','diagnostic.text-summary.nonlocal-computed-width.large']
sources=[row for origin in origins for row in read(lab.parent/origin)['cases']]
cases=[{k:next(row[k] for row in sources if row['id']==name) for k in ('id','source')} for name in ids]
cases += [dict(id='diagnostic.immutable-dag',source='proof = 2\n'+'proof = (proof, proof)\n'*36+
              'items = []\nitems.append(1)\nitems.append(2)\ndef summary(v):\n    return len(proof) + v\nprint(summary(0))\n'),
          dict(id='diagnostic.mixed-dag',source='pure = 2\n'+'pure = (pure,pure)\n'*36+
              'items = [0]\nproof = (pure, items)\nitems.append(1)\ndef summary(v):\n    return len(pure) + v\nprint(summary(0),len(proof[1]))\n')]
(lab/'graph-catalog.json').write_text(json.dumps(cases,indent=2)+'\n',encoding='utf-8')
(lab/'source-probe.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src']))
print('Prepared',len(cases),'current compiler probes')
