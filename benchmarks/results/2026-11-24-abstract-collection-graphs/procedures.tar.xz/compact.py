from pathlib import Path
import hashlib,json,subprocess
lab=Path(__file__).resolve().parent
repo=lab.parents[3]
artifact=repo/'benchmarks/results/2026-11-24-shared-parser-statements'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda data:hashlib.sha256(data).hexdigest()
identity=read(artifact/'identity.json')
files=identity['imageFiles']['reference']
ref=lab.with_name('shared-parser-statements-20261124')/'reference'
assert len(files)==32 and {p.name:sha(p.read_bytes()) for p in ref.iterdir()}==files
terminal=read(artifact/'terminal-status.json')
archive=artifact/'observations.tar.xz'
receipt=terminal['receipt']
archive_sha=receipt['archiveSHA256']
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode']=='0'
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['archivedAndVerifiedUnderLease']
assert sha(archive.read_bytes())==sha(subprocess.check_output(['git','show','origin/master:'+archive.relative_to(repo).as_posix()],cwd=repo))==archive_sha
remote='want='+repr(dict(core=files['Lokad.Lython.dll'],archive=archive_sha))+'\n'+'''
from pathlib import Path
import fcntl,hashlib,json,lzma,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve()
run=base/'shared-parser-statements-b1612-20261124'
sha=lambda data:hashlib.sha256(data).hexdigest()
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert run.parent==base and run.resolve()==run and not (run/'guest-fixtures').exists()
 assert subprocess.run(['pgrep','-af',str(run)],capture_output=True).returncode==1
 bounds=json.loads((run/'archive-receipt.json').read_text())
 assert bounds['complete'] and bounds['allWorkersJoined'] and bounds['archivedAndVerifiedUnderLease']
 assert bounds['archiveSHA256']==want['archive'] and sha((run/'observations.tar.xz').read_bytes())==want['archive']
 free=shutil.disk_usage(base).free
 core=run/'reference/Lokad.Lython.dll'
 assert core.resolve()==core and stat.S_ISREG(core.lstat().st_mode) and core.stat().st_nlink==1
 data=core.read_bytes()
 assert sha(data)==want['core']
 encoded=lzma.compress(data,preset=3)
 assert free>=len(encoded)+1048576
 compressed=run/'reference-core.dll.xz'
 with compressed.open('xb') as out:
  out.write(encoded)
  out.flush()
  os.fsync(out.fileno())
 assert lzma.decompress(compressed.read_bytes())==data
 core.unlink()
 print(json.dumps(dict(freeBefore=free,freeAfter=shutil.disk_usage(base).free,stored=str(compressed.relative_to(base)),
       coreSHA256=want['core'], priorArchiveSHA256=want['archive'],compressedSHA256=sha(encoded))))
'''
args=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes',
      '-o','ConnectTimeout=12','lokad@20.166.121.73','python3 -']
result=subprocess.run(args,input=remote.encode('utf-8'),capture_output=True,timeout=50)
print(result.stdout.decode(),end='')
if result.returncode:print(result.stderr.decode(),end='')
result.check_returncode()
(lab/'compaction.json').write_bytes(result.stdout)
