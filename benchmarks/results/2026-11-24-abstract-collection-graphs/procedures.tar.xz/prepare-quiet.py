from pathlib import Path
import hashlib,json,shutil,tarfile
lab=Path(__file__).resolve().parent
base=lab.parent
donor=base/'shared-parser-statements-20261124'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
save=lambda p,o:write(p,json.dumps(o,indent=2)+'\n')
comparison=lab/'comparison'
quiet=comparison/'quiet'
quiet.mkdir(parents=True,exist_ok=True)
shutil.copyfile(lab/'catalog.json',comparison/'representative.json')
selected=('scripts.config-manifest.small','scripts.config-generated-guards.medium.bad-0.sparse-lexical',
          'scripts.csv-summary-functions.small','scripts.json-summary-helpers.small')
jobs=[(case,'compile') for case in selected]+[(selected[1],'compile-run'),(selected[0],'compile-run')]
save(comparison/'jobs.json',{'warm':jobs})
local=read(lab/'identity.json')
prior=read(donor/'comparison/identity.json')
assert prior['imageFiles']['candidate']==local['imageFiles']['reference']
identity=dict(sourceRevision=local['reference'],candidate=local['sourcePatchSHA256'],
    purpose='Skip unused collection analysis using existing value proofs and a binding-state summary',imageFiles=local['imageFiles'],
    coreSHA256={alias:local['imageFiles'][role]['Lokad.Lython.dll'] for role in local['imageFiles'] for alias in (role,role+'-control')},
    catalogs={name:dict(sha256=digest(comparison/name)) for name in ('representative.json','jobs.json')},
    expectedCPythonSHA256=prior['expectedCPythonSHA256'],cpythonWorkerSHA256=local['pythonWorkerSHA256'])
for role,files in identity['imageFiles'].items():
    assert len(files)==32 and {p.name:digest(p) for p in (lab/role).iterdir()}==files
    goldens=read(lab/(role+'-verify.json'))
    assert goldens['caseCount']==4 and goldens['state']=='Completed' and goldens['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert goldens['launched']['library']['sha256']==files['Lokad.Lython.dll']
save(comparison/'identity.json',identity)
collector=(donor/'comparison/quiet/collect.py').read_text(encoding='utf-8')
collector=collector.replace('len(jobs) == 5','len(jobs) == 6').replace('b1608-fixtures','b1613-fixtures').replace('b1612-fixtures','b1613-fixtures')
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
shutil.copyfile(donor/'comparison/quiet/run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=3) as archive:
    for name in ('identity.json','representative.json','jobs.json'):
        archive.add(comparison/name,arcname=name,recursive=False)
    for name in ('collect.py','run.sh'):
        archive.add(quiet/name,arcname=name,recursive=False)
    archive.add(lab/'candidate/Lokad.Lython.dll',arcname='candidate-core.dll',recursive=False)
save(quiet/'upload.json',dict(root='abstract-collection-graphs-b1613-20261124',reference='shared-parser-statements-b1612-20261124',
                           payloadSHA256=digest(payload),payloadBytes=payload.stat().st_size))
save(lab/'verified-raw-replicas.json',[])
launcher=(donor/'quiet.py').read_text(encoding='utf-8')
launcher=launcher.replace('lython-b1612-shared-parser-statements-', 'lython-b1613-abstract-collection-graphs-')
launcher=launcher.replace('b1612-', 'b1613-').replace('seconds=260','seconds=306').replace('RuntimeMaxSec=310','RuntimeMaxSec=368')
launcher=launcher.replace("'collect.py','candidate-core.dll','reference-core.dll'", "'collect.py','candidate-core.dll'")
launcher=launcher.replace("if name=='Lokad.Lython.dll':","if name=='Lokad.Lython.dll' and role=='candidate':")
launcher=launcher.replace('needs two cores, receipts and working room','needs one core, receipts and working room')
launcher=launcher.replace('2560*1024','1400*1024').replace('3584*1024','1912*1024').replace('2560 * 1024','1400 * 1024').replace('+ 1024 * 1024','+ 512 * 1024')
launcher=launcher.replace('Five bounded lanes write under 1 MiB of receipts. A 2.5 MiB','Six bounded lanes write under 1 MiB of receipts. A 1.4 MiB')
expected=read(donor/'comparison/quiet/terminal-status.json')['receipt']['archiveSHA256']
launcher=launcher.replace('a04e360d66a4e071fa0cd7142b5d2a0948999185032311e42b066d44d0b94b88',expected)
compile(launcher,'quiet.py','exec')
write(lab/'quiet.py',launcher)
summarize=(donor/'summarize.py').read_text(encoding='utf-8')
summarize=summarize.replace('receipt["warmJobs"] == 5','receipt["warmJobs"] == 6').replace('timedBatches=140','timedBatches=168')
compile(summarize,'summarize.py','exec')
write(lab/'summarize.py',summarize)
print('Prepared six short quiet lanes and verified both frozen images.',flush=True)
