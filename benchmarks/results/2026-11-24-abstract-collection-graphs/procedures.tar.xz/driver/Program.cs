using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;

using var catalog = JsonDocument.Parse(File.ReadAllBytes(args[0]));
var assembly = typeof(LythonEngine).Assembly;
var counts = (long[])assembly.GetType("Lokad.Lython.Frontend.AbstractState", throwOnError: true)!
    .GetField("GraphProbe", BindingFlags.NonPublic | BindingFlags.Static)!.GetValue(null)!;
var engine = new LythonEngine();
var rows = new List<object>();
foreach (var item in catalog.RootElement.EnumerateArray())
{
    var id = item.GetProperty("id").GetString();
    var source = item.GetProperty("source").GetString()!;
    var budget = new LythonMemoryBudget();
    Array.Clear(counts);
    using (var compiled = engine.Compile(source, budget))
    {
        if (!compiled.IsValid) throw new InvalidOperationException(string.Join("\n", compiled.Diagnostics));
        rows.Add(new { id, counts = counts.ToArray(), bytes = budget.ReservedBytes });
    }
    if (budget.ReservedBytes != 0) throw new InvalidOperationException("Compilation retained allowance.");
}
var core = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(assembly.Location)));
File.WriteAllText(args[1], JsonSerializer.Serialize(new { core, rows }, new JsonSerializerOptions { WriteIndented = true }));
