from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess
lab=Path(__file__).resolve().parent
base=lab.parent
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
save=lambda p,o:p.write_text(json.dumps(o,indent=2)+'\n',encoding='utf-8',newline='\n')
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
identity=read(lab/'identity.json')
core='Lokad.Lython.dll'
measured=[]
for role,assets in identity['imageFiles'].items():
    entry=lab/role/core
    assert sha(entry)==assets[core]
    for group,helper in [('allocation',base/'prepared-closed-defaults-20261124/compiler-owner/reference'),
       ('diagnostics',base/'shared-parser-statements-20261124/diagnostics/bin/Release/net11.0')]:
        folder=lab/f'{role}-{group}'
        folder.mkdir(exist_ok=True)
        for p in helper.iterdir():
            if p.is_file() and p.suffix!='.pdb':shutil.copyfile(entry if p.name==core else p,folder/p.name)
        assert sha(folder/core)==assets[core]
        output=lab/f'{role}-{group}.json'
        if group=='allocation':
            catalog=lab/'allocation-catalog.json'
            save(catalog,{'cases':read(lab/'graph-catalog.json')})
        else:
            catalog=lab/'diagnostic-catalog.json'
            inputs=[]
            for depth in (3,12,24):
                prefix='pure = 1\n'+'pure = (pure, pure)\n'*depth+'items = []\nmixed = (pure, items)\nitems.append(1)\n'
                for result in ('len(mixed[1])','len(mixed[0]'+'[1]'*depth+')','len(pure'+'[0]'*depth+')'):
                    inputs.append(prefix+result+'\n')
            inputs.extend(case['source'] for case in read(lab/'graph-catalog.json'))
            save(catalog,inputs)
        subprocess.run([dotnet,folder/'Inspect.dll',catalog,output],env=env,check=True,timeout=36)
        reply=read(output)
        assert reply['coreSHA256' if group=='allocation' else 'core']==assets[core]
        if group=='allocation':measured.append(reply['rows'])
rows=[]
for a,b in zip(*measured,strict=True):
    assert a['id']==b['id']
    row=dict(case=a['id'],allocationBytes=[statistics.median(item['allocatedBytes']) for item in (a,b)],
        retainedAdmission=[a['retainedAdmission'],b['retainedAdmission']])
    print(row)
    rows.append(row)
save(lab/'allocation-summary.json',rows)
reference=read(lab/'reference-diagnostics.json')['rows']
candidate=read(lab/'candidate-diagnostics.json')['rows']
assert reference[4]['IsValid'] and candidate[4]['Diagnostics'][0]['Code']=='LA3032'
assert all(reference[i]['IsValid'] and candidate[i]['IsValid'] for i in (0,3,6))
assert reference[9:]==candidate[9:] and all(row['IsValid'] for row in candidate[9:])
for i,(before,after) in enumerate(zip(reference,candidate,strict=True)):
    if before!=after: print('diagnostic change',i,before,after)
