from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/'comparison/quiet'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda data:hashlib.sha256(data).hexdigest()
filehash=lambda p:sha(p.read_bytes())
terminal=read(quiet/'terminal-status.json')
receipt=terminal['receipt']
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode']=='0'
assert receipt['warmJobs']==6 and all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert receipt['archiveSHA256']==filehash(quiet/'observations.tar.xz')
local=read(lab/'identity.json')
identity=read(lab/'comparison/identity.json')
summary=read(quiet/'summary.json')
assert identity['candidate']==local['sourcePatchSHA256']==filehash(lab/'candidate.patch')==summary['candidate']
assert identity['sourceRevision']==local['reference']==summary['source']
assert len(summary['rows'])==6 and summary['timedBatches']==168
for role,paths in identity['imageFiles'].items():
    assert len(paths)==32 and {p.name:filehash(p) for p in (lab/role).iterdir()}==paths
    verification=read(lab/f'{role}-verify.json')
    assert verification['caseCount']==4 and verification['state']=='Completed'
    assert verification['launched']['library']['sha256']==paths['Lokad.Lython.dll']
    assert read(lab/f'{role}-diagnostics.json')['core']==paths['Lokad.Lython.dll']
    assert read(lab/f'{role}-allocation.json')['coreSHA256']==paths['Lokad.Lython.dll']
for os in ('windows','ubuntu'):
    for name,count in [('white',32),('public',240),('admission',13)]:
        assert f'Passed: {count:5d}' in (lab/f'{os}-{name}.log').read_text(encoding='utf-8-sig')
counts=read(lab/'graph-counts.json')
after=read(lab/'graph-counts-after.json')
for data,folder in [(counts,'instrumented'),(after,'instrumented-after')]:
    assert data['core']==filehash(lab/folder/'bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll')
    assert len(data['rows'])==10
labels=['invalidationRequests','invalidationBindingVisits','wideningCalls','tupleOrOptionalWideningCalls','immutableTupleOrOptionalCalls',
        'wideningLimit','deferredScopeCopies','deferredBindingVisits','deferredMutableDrops','functionSummaries']
rows=[]
for a,b in zip(counts['rows'],after['rows'],strict=True):
    assert a['id']==b['id'] and a['bytes']==b['bytes']
    row=dict(case=a['id'],retainedAdmission=a['bytes'],counts={label:[before,after] for label,before,after in zip(labels,a['counts'],b['counts'],strict=True)})
    rows.append(row)
out=repo/'benchmarks/results/2026-11-24-abstract-collection-graphs'
out.mkdir(exist_ok=True)
for name in ('observations.tar.xz','terminal-status.json','summary.json','storage-custody.json'):
    shutil.copyfile(quiet/name,out/name)
shutil.copyfile(lab/'comparison/identity.json',out/'identity.json')
for name in ('compaction.json','allocation-summary.json'):
    shutil.copyfile(lab/name,out/name)
(out/'graph-counts.json').write_text(json.dumps(dict(instrumentedCore=[counts['core'],after['core']],rows=rows),indent=2)+'\n',encoding='utf-8')
procedures=['prepare.py','prepare-comparison.py','prepare-quiet.py','quiet.py','local.py','summarize.py','archive.py','compact.py','test-ubuntu.sh',
    'driver/Probe.csproj','driver/Program.cs','graph-catalog.json','graph-counts.json','graph-counts-after.json','driver-build.log',
    'instrumented-build.log','instrumented-after-build.log','source-probe.patch','source-after-probe.patch','candidate.patch','identity.json',
    'allocation-catalog.json','diagnostic-catalog.json','local.log','comparison/representative.json','comparison/jobs.json',
    'comparison/quiet/run.sh','comparison/quiet/collect.py','comparison/quiet/launch.log']
for role in ('reference','candidate'):
    procedures += [f'{role}-{name}.json' for name in ('verify','allocation','diagnostics')]
for os in ('windows','ubuntu'):
    procedures += [f'{os}-{name}.log' for name in ('white','public','admission')]
with tarfile.open(out/'procedures.tar.xz','w:xz') as archive:
    for name in procedures:archive.add(lab/name,arcname=name,recursive=False)
with tarfile.open(out/'procedures.tar.xz') as archive:
    assert {m.name:sha(archive.extractfile(m).read()) for m in archive}=={name:filehash(lab/name) for name in procedures}
print('Archived 168 attested timing batches plus exact diagnostics, work counts and local allocation.')
