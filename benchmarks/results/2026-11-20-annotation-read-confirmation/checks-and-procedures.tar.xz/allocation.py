from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess

lab=Path(__file__).resolve().parent
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
load=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
identity=load(lab/'frozen-identity.json')
for role in ('reference','candidate'):
    image=lab/'frozen'/role
    files=identity['images'][role]
    def verify_image():
        assert len(files)==32 and {name:hashlib.sha256((image/name).read_bytes()).hexdigest()
                                   for name in files}==files
    verify_image()
    for helper in (lab.parent/'method-format-frame/frozen/reference').glob('ValidatedAllocation.*'):
        shutil.copyfile(helper,image/helper.name)
    with (lab/f'{role}-allocation.log').open('wb') as log:
        subprocess.run([sdk/'dotnet.exe',image/'ValidatedAllocation.dll',image,lab/'catalog.json',
                        lab/f'{role}-allocation.json'],env=env,stdout=log,stderr=subprocess.STDOUT,
                       check=True,timeout=65)
    verify_image()
    report=load(lab/f'{role}-allocation.json')
    assert report['assembly'].startswith('Lokad.Lython,')
rows=[]
for reference,candidate in zip(*(load(lab/f'{role}-allocation.json')['rows'] for role in ('reference','candidate')),strict=True):
    assert reference['id']==candidate['id']
    assert reference['sharedBudgetBaselineRestored'] and candidate['sharedBudgetBaselineRestored']
    before,after=[statistics.median(row['allocatedBytesPerInvocation']) for row in (reference,candidate)]
    rows.append(dict(case=reference['id'],referenceBytes=before,candidateBytes=after,changePercent=100*(after/before-1),
                     referencePeak=reference['peakExecutionMemoryBytes'],candidatePeak=candidate['peakExecutionMemoryBytes']))
(lab/'allocation-summary.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
for row in rows: print(row)
