# Lokad.Lython 0.11.0

Updated 2026-11-08. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Another isolated experiment does not finish that objective. Active work below;
historical narratives, rejected designs, original failed conditions and raw data
stay in benchmarks/EXPERIMENTS.md and results. Docs describe current implementation.

## Actual delivery status

| Milestone | Delivery / measurement status |
| --- | --- |
| Shared compiler facts; direct UTF-8 formatting; native helper returns | Committed, fully qualified. Native-return allocation−19.92/−19.31%; original elapsed diagnostic. Formatting allocation−8.67%; controlled B102 elapsed/CPU−5–8%; original15.125ms adverse unexplained and preserved. Do not replay qualification. |
| R62 /70267889; R65/R66 /824fc6bb; R70 /7a81a629; R71 /f88191f7+a34f56b5; R72 /68d5bffe | All committed/fully qualified Windows/Ubuntu actual11/10, original Stress and installed consumers. Compiler/native-call/sequence/tuple/storage simplifications retained; exact receipts and adverse originals cached in results. R71 call-control/arena/wide-carrier lessons remain. R72 mixed text coarseCPU+6.67% remains historical uncertainty. |
| R74 /33b6c191 | Fully qualified CI42431587731: native validated JSON float conversion;2191 CPython bit/grammar cases, allocation neutral, affected elapsed−10–14%. Original36.7% unchanged-control drift and adverse desktop controls retained. |
| R75 /79657355+c384956f | Source gate/failed captures preserved; no prototype or current attribution claim. Setup failure did not permanently reject the design. |
| R76 /38f53c33, prerequisite06651b11 | Fully qualified CI42439532114: inline8/final UTF-8 storage and Unicode-cache cancellation fix. Allocation text−9.4%, CSV−8–9%; modest affected elapsed, sync-text inconclusive. Floatasync+0.9–2.7% accepted debt. All prototype/adverse originals preserved. |
| R77 /104fbe74 | CPython guide refreshed at measured source38f53c33/core903eb346:26jobs539.66s, eight complete scripts, compile/warm/compile-to-result separate plus two numeric-string controls. All gates pass; earlier tables/setup failures retained. Guide names measured source, not today's HEAD. |
| R78 /af481194; positional correction5b9d569a; receipt d60fb4f4 | Fully qualified CI42443700988: both OSes actual11/10, original Stress and installed consumers. Two providers/per-access closures/wrappers/packing removed;48baseline callback failures fixed. Allocation−21.26%; measured045 elapsed−14.5–16.8%sync/−14.3–14.7%async. Final dead-arm cleanup only allocation-checked. Report control inconclusive, original adverse desktop preserved. Eleven method keyword signatures corrected;251public/target and43 independent CPython observations. |
| R79 /913ea550 fully qualified CI42447193207 | Existing native receiver and exact-list/tuple iteration run on owned workstate before full context. Duplicate native ordinary-call branches/premature guards removed; no new name markers/framework/pool/owner. Source18b563e9 passes140internal/326public per actual11/10. Complete ordinary/guarded reports allocate~42%less. B443 six jobs168.441s: ordinary elapsed11.8–14.4%lower sync/14.5–16.1%async, guarded10.5–12.2%lower. CSV+0.25–1.92% elapsed explicitly accepted debt; native control inconclusive(current spread3.70%), reportnear baseline. All source/Ready/golden/quiet/join/fixture/archive gates pass. Full Windows/Ubuntu actual11/10, original Stress and installed consumers pass; cached terminal receipt. |
| Regex /R68 | Exact immutable0.5.0-dev.55/d6067925:86internal/514public per actual11/10, unchanged bridge. Development compatibility only; normal optional0.4 pin/core unchanged. Final released adapter qualification outstanding; no core blocker. |

Latest fully qualified runtime913ea550; all earlier terminal receipts cached.
Never requery/re-dispatch terminal runs or imply that this qualifies later changes.
Allocation reduction, elapsed, coarseCPU and embedding latency are distinct.
R76's float debt and R79's CSV debt are separately accepted; unrelated gains do
not repay them. Preserve native-text/report/control uncertainty and adverse originals.

## Active deliverables

1. R82 retained and committed/pushed91f15a3e; measured source-equivalent core4c072fed.
   Existing prepared member/receiver/iterator/branch operands remove emitted pure
   leaf dispatch/publication; no new view/arena/cache/owner/backend. Allocation
   neutral;332internal/155public per actual11/10 pass including actual suspended
   protocols/cancellation/awaited cleanup/shared-budget reuse. B445 six jobs167.55s,
   all source/Ready/golden/quiet/join/fixture/archive gates pass and locally verified.
   Text elapsed modestly lower with mixed coarseCPU; guarded/CSV near baseline,
   possible CSV+1.50% retained; report inconclusive(current spread5.32%). Earlier
   debt separate; no broad CPU-win claim or further per-opcode refinement series.
   Full boundary dispatched05:40:59UTC for exact91f15a3e; first observation>=
   05:45:59UTC then>=5min spacing. Cache terminal; no duplicate dispatch. Continue
   R83 concurrently, never use earlier913ea550 receipt to qualify this source.
2. R83 combined CPython checkpoint SELECTED: exact91f15a3e/core4c072fed, eight
   maintained complete scripts compile/warm/compile-to-result(24jobs), plus rsplit
   and guarded helper warm cases replacing two historical numeric-string warm
   diagnostics.26jobs total, existing worker/protocol, same CPython3.13.16 and
   quietF4as_v7,5s warmup/role and7rotated150ms rounds;570s owner+30stop+30margin.
   Keep compilation/startup and included mediated I/O/validation/prior cleanup
   explicit. No new framework, repeated source-pair campaign or inferred single-
   change attribution. Preserve prior named-source tables, uncertain/adverse cases
   and all gates/raw failures. One complete checkpoint or explicit partial evidence
   requiring a justified bounded sizing correction; archive underlease/verify locally.
   Afterward choose a substantial complete call/frame/construction phase using
   ordinary-helper evidence: R80's fused-helper profile cannot attribute ordinary
   workstate helper construction. No automatic arena/carrier/tagged-value revival.
3. Continue independent Lython-owned regex work below. Missing producer publication
   defers only the affected final adapter qualification. No publication/tagging.

## Following substantial redesign boundaries

| Boundary | Selection and acceptance |
| --- | --- |
| Remaining calls/operand/scalar dispatch | Indexed operands/native returns/final slots and native workstate dispatch exist. Find a demonstrated complete remaining binding/transport or numeric phase; avoid pools/arenas and duplicated control routes already measured slower. Exact integer promotion, identity/type/projection, callbacks, reentry and alias funding must hold. Machine-integer handling is a hypothesis until current attribution supports its scope; no universal tagged-value replacement. |
| Per-record construction | Current source gate: shared RecordKeys and exclusive funded row-array adoption already remove the old bulk proposal's copying/key phase; it cannot be revived unchanged. Preserve its6–8% improvement/adverse control. Remaining identity checks protect mutable headers and admission reentry; no mutation-version inventory without current measured dominance. Select a genuinely remaining construction phase; preserve hooks/order/escaping aliases. |
| Remaining bulk text/JSON | Direct casing/lower-split/formatting/native parsing, JSON loop/shared scanner and final UTF-8 storage retained. Select a whole remaining conversion/storage phase, preserving Unicode/context/hooks/async I/O. Ordinary R61 JSON has no escaped tokens; do not optimize hypothetical dominance or add a name-marker series. |
| Frontend facts | R55/R58/R62/R65 already remove lexical/graph/validity/module work. Select demonstrated repeated analysis in compile-to-result workloads; preserve class/function/annotation scope and exact diagnostics, then delete displaced analysis. No speculative visitor/cache/parser/JIT project. |

Bounded confirmation/refinement or measurement correction is allowed when evidence
justifies it. Timeout, unstable unchanged control or inconclusive results establish
uncertainty, not a permanently failed design. Keep original failed conditions and
adverse results. Fixed percentages inform judgment, never automatically veto useful
simplification. Temporary regressions require an explicit completion milestone and
retain/correct/reject decision on remaining debt. Batch CPython refreshes at coherent
combined checkpoints with exact source/date/machine and separate compile, warm,
compile-to-result/startup; include I/O/validation/cleanup boundaries and uncertainty.
Current guide accurately names source38f53c33; do not remeasure after every tweak.

## Independent regex deliverable

Core owns Python/native UTF-8 semantics: byte ranges/scalar positions/original
subject windows, flags/captures/replacements/errors, cache ownership/current tokens
and one provider through frontend/runtime/imports. Core has no Utf8Regex dependency;
adapter remains nonpackable. Contract tests, semantic compatibility and actual
backend performance are separate. Immutable development producers/adapter-local
bridges support development; missing publication does not stop independent work.

Exact dev55 gaps: DetailedData lacks separate preparation/working ownership;
native name lookup lacks enumeration; cursor creation retains its token despite
per-move tokens. Both dev55 package SHAs rechecked bit-identical04:45UTC; no
new supplied version or repeat qualification. Existing bridges remain justified. Qualify the final released
package's semantics, managed safety and actual performance when available. Normal
adapter0.4 pin unchanged pending justified promotion. No sibling edits/builds,
producer-CI replay, dialect fallback, quotas, memory subsystem or abandoned matching.

## Lasting constraints / checks

AGENTS.md governs fully managed safety/managed stack admission: no unsafe/Unsafe,
PInvoke/pointers/native probes. Preserve host capabilities, current cancellation,
checked representation bounds, XML depth, bounded I/O chunks and admitted projection.
Borrow shared allowance for coarse capacity/preflight/replacement storage; fund
retained aliases/caches/results and pending users until awaited cleanup. No caps,
hidden allowances/fuel/quotas/tracing/weak reclamation/forced GC. Initial streaming
uses host batches. First refusal is terminal through suppression/finally; never
retry or skip optional storage. Keep native refunds/cleanup available and awaited.

Focused Release iteration; matching probes when needed and explicit Stress exclusion
with custom filters. No overlapping local builds/tests/measurements; force a fresh
build after timestamp-preserving restores. Batch actual11/10 Windows/Ubuntu,
original Stress and installed consumers at retained boundaries. Explicit UTF-8.
Only core explicit Release pack to artifacts/nuget; no adapter packages/publication.
VM lokad@20.166.121.73,key ~/.ssh/id_lython-bench.pem. B443 terminal/archived/
locally verified; no active user/fixture mount, never requery. Persistent evidence
separate from owned RAM; join/unmount/archive under lease and verify locally.
One byte-identical worker DLL was atomically hardlinked, freeing56MB while keeping
all paths/bytes/cores/sources/archives. No future deletion inferred. CI observations
>=5minutes apart; cached terminal runs never requeried or duplicate-dispatched.
