R83 combined checkpoint after retained R78/R79/R82, production91f15a3e/core4c072fed.
Refresh primary CPython account once at this coherent boundary while full platform/
originalStress/installed qualification runs independently. Not another framework
or repeated source-pair campaign. Keep previous named-source tables unchanged as
historical evidence, including missing/adverse conditions and original controls.

Reuse exact maintained eight scripts and existing workers/protocol: compilation,
warm execution, compile-to-result separately (24jobs). Replace the two previously
numeric-string warm diagnostics with complete rsplit and guarded helper text warm
cases already independently golden-checked. Their earlier numeric evidence remains
historical.26jobs total, same expected runtime~540s, owner570s/stop30s/margin30s.
Each job two identical current Lython processes and isolated CPython3.13.16;5s
warmup per role,7rotated150ms rounds, normalGC/tiering, quiet F4as_v7.

Execution includes mediated RAM-file I/O, all stdout/file golden validation and
prior-result cleanup; compilation separately includes construction/disposal.
Exclude startup/staging/reset/protocol/final cached teardown. No attribution of
combined result to a single optimization, async-I/O, RSS/embedding-tail or universal
CPU claim. Do not silently replace the reference Python version or drop variable
cases. Preserve all source/core/auxiliary/actualReady/runtime/golden/quiet/Closed/
exit/join/fixture/archive gates. Catalog/trace/workers persistent; owned128MiB RAM
fixtures released only after users/cleanup finish. Archive underlease and verify
locally. No new VM data deletion or runtime policy. Publication postponed.

Stopping criterion: one complete valid checkpoint or explicit partial/uncertain
evidence needing bounded sizing correction. Use results to choose the next complete
call/frame/construction phase on ordinary helpers; fused NativeBody CPU attribution
alone cannot establish the cost of ordinary workstate helpers. Do not treat another
benchmark or CI completion as completion of the whole-script performance objective.
