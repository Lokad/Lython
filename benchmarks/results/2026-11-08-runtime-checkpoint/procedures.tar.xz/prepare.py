from pathlib import Path
import ast,hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;old=r.parent/'inline-cpython-r77/b440';runtime=r.parent/'operand-consumers-r82'
identity=json.loads((runtime/'identity.json').read_text(encoding='utf-8'));assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['productionSources'].items())
d=json.loads((old/'representative.json').read_text(encoding='utf-8'));extra=json.loads((runtime/'catalog.json').read_text(encoding='utf-8'))
newIds=['scripts.text-summary-rsplit-helpers.large','scripts.text-summary-guarded-helpers.large']
d['cases'] += [c for c in extra['cases']if c['id']in newIds]
assert len({c['id']for c in d['cases']})==len(d['cases'])
for c in d['cases']:
 for field,digest in [('source','sourceSha256'),('fixtureJson','fixtureSha256'),('expectedOutput','expectedOutputSha256')]:assert hashlib.sha256(c[field].encode('utf-8')).hexdigest()==c[digest],(c['id'],digest)
(r/'representative.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
rootOld='inline-cpython-b440-20261108';rootNew='combined-cpython-b446-20261108';unitOld='lython-b440-inline-cpython';unitNew='lython-b446-combined-cpython'
s=(old/'collect.py').read_text(encoding='utf-8');a=s.index('jobs=');z=s.index('\nassert len(jobs)',a)
jobs=ast.literal_eval(s[a+5:z]);jobs=[job for job in jobs if job[0]not in ['scripts.csv-summary-functions.large-padded-integers','scripts.json-summary-helpers.large-integer-strings']]+[[name,'warm']for name in newIds]
assert len(jobs)==26
s=s[:a]+'jobs='+repr(jobs)+s[z:];s=s.replace(rootOld,rootNew).replace('R77 combined 38f53c33 checkpoint: eight complete scripts, separate compile/warm/compile-run and two labeled numeric-string warm controls','R83 combined91f15a3e checkpoint: eight complete scripts compile/warm/compile-run and two ordinary helper text warm cases')
(r/'collect.py').write_text(s,encoding='utf-8',newline='\n');ast.parse(s)
for name in ['run.sh','retrieve.py','summarize.py','table-helpers.py']:
 s=(old/name).read_text(encoding='utf-8').replace(rootOld,rootNew).replace(unitOld,unitNew)
 (r/name).write_text(s,encoding='utf-8',newline='\n')
 if name.endswith('.py'):ast.parse(s)
vm=dict(sourceRevision='91f15a3ea1a00c2a775df83605e19b20cbffa0ef',coreSHA256={role:identity['coreSHA256']['candidate']for role in ['candidate','candidate-control']},auxiliaryFiles=json.loads((runtime/'b445/identity.json').read_text(encoding='utf-8'))['auxiliaryFiles'],productionSources=identity['productionSources'],jobs=jobs,referenceVersion='CPython3.13.16',qualification='332internal/155public per actual11/10 focused Release; full CI dispatched05:40:59UTC, receipt independent/pending. Frozen core informational SourceLink71445454; production inventory matches committed91f15a3e.')
(r/'identity.json').write_text(json.dumps(vm,indent=2)+'\n',encoding='utf-8')
for src,name in [(runtime/'focused-final.json','focused.json'),(runtime/'source.patch','source.patch'),(Path('PLAN.md'),'pre-measurement-plan.md'),(Path('docs/BENCHMARKS.md'),'prior-BENCHMARKS.md')]:shutil.copyfile(src,r/name)
(r/'contract.md').write_text((r/'selection.md').read_text(encoding='utf-8'),encoding='utf-8')
(r/'setup-contract.json').write_text(json.dumps(dict(jobs=jobs,ownerSeconds=570,stopSeconds=30,marginSeconds=30,osFreeFloorMiB=240,evidenceHeadroomMiB=7),indent=2)+'\n',encoding='utf-8')
s=(old/'archive-owned.py').read_text(encoding='utf-8').replace(rootOld,rootNew)
begin=s.index(" for n in [");end=s.index(']:t.add',begin)
names=['confirmation','identity.json','representative.json','collect.py','cpython-worker.py','pre-measurement-plan.md','setup-contract.json','source.patch','focused.json','contract.md','selection.md','prior-BENCHMARKS.md','started.utc','run.sh','archive-owned.py','current-core.dll']
s=s[:begin]+' for n in '+repr(names)+s[end+1:];ast.parse(s);(r/'archive-owned.py').write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(r/'payload.tgz','w:gz')as a:
 for name in ['collect.py','archive-owned.py','run.sh','representative.json','identity.json','focused.json','source.patch','contract.md','selection.md','prior-BENCHMARKS.md','setup-contract.json','pre-measurement-plan.md']:a.add(r/name,arcname=name)
print('Exact26 jobs/catalog hashes/current production inventory checked; unchanged collector protocol and worker reused. No collection started.')
