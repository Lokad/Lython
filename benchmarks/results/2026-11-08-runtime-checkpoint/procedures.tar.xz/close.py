from pathlib import Path
import hashlib,json,re,runpy,shutil,tarfile
r=Path(__file__).resolve().parent
receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'))
assert receipt['complete']and receipt['jobs']==26
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
summary=json.loads((r/'summary.json').read_text(encoding='utf-8'));assert summary['complete']and len(summary['timing'])==26
identity=json.loads((r/'identity.json').read_text(encoding='utf-8'));assert identity['sourceRevision'].startswith('91f15a3e')
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['productionSources'].items())
assert identity['coreSHA256']['candidate'].startswith('4c072fed')
scope=runpy.run_path(str(r/'table-helpers.py'));table,ordinary,affected=[scope[n]for n in ['table','ordinary','affected']]
out=Path('benchmarks/results/2026-11-08-runtime-checkpoint');out.mkdir()
for n in ['summary.json','observations.tgz','archive-receipt.json']:shutil.copyfile(r/n,out/n)
history=(r/'prior-BENCHMARKS.md').read_text(encoding='utf-8').replace('../benchmarks/results/','../').replace('../benchmarks/EXPERIMENTS.md','../../EXPERIMENTS.md').replace('../benchmarks/README.md','../../README.md').replace('../tests/README.md','../../../tests/README.md')
(out/'prior-BENCHMARKS.md').write_text('# Historical guide: measured source38f53c33\n\nThe following guide retains its named measurements and separate later source pairs. It does not describe production91f15a3e.\n\n'+history,encoding='utf-8')
guide=Path('docs/BENCHMARKS.md').read_text(encoding='utf-8');blocks=list(re.finditer(r'\| Workload \|.*?(?=\n\n)',guide,re.S));assert len(blocks)==3
for block,new in reversed(list(zip(blocks,[table('compile-run',ordinary,True).rstrip(),table('warm',ordinary+affected).rstrip(),table('compile',ordinary).rstrip()]))):guide=guide[:block.start()]+new+guide[block.end():]
guide=guide.replace('measured source `38f53c33`','measured source `91f15a3e`')
a=guide.index('Frozen core `903eb346`');z=guide.index('## Warm execution',a)
guide=guide[:a]+'''Frozen core `4c072fed` matches the measured source's production inventory;
informational SourceLink is precommit `71445454`. Focused Release332internal/
155public checks pass per actual .NET11/.NET10. Full Windows/Ubuntu, original
Stress and installed consumers are tracked separately in
[CI42451722109](https://github.com/Lokad/Lython/actions/runs/42451722109);
the benchmark is not that qualification.
The [26-job checkpoint](../benchmarks/results/2026-11-08-runtime-checkpoint/README.md)
records exact identities and verified raw evidence. Optional0.4 adapter/worker
unchanged; no newer producer is certified. The [earlier measured-source38f53c33
guide](../benchmarks/results/2026-11-08-runtime-checkpoint/prior-BENCHMARKS.md)
preserves the previous comparison, including numeric-string warm cases.
These tables describe the recorded source, not later HEAD.

'''+guide[z:]
guide=guide.replace('Warm execution reuses the compiled script. The last two inputs explicitly exercise\ngeneral integer conversion and do not replace ordinary CSV/JSON. Their compilation\nand compile-to-result times were not refreshed in this checkpoint.','Warm execution reuses the compiled script. The last two rows use rsplit and a\nwhitespace guard in small helpers on the same text fixture. Their compilation\nand compile-to-result times were not measured in this checkpoint.')
elapsed=summary['elapsedSeconds'];guide=guide.replace('All26 jobs completed in539.66seconds.',f'All26 jobs completed in{elapsed:.2f}seconds.')
assert '903eb346'not in guide and 'All26 jobs completed in539.66seconds.'not in guide
Path('docs/BENCHMARKS.md').write_text(guide,encoding='utf-8',newline='\n')
intro=f'''# Combined runtime checkpoint against CPython

2026-11-08. Production91f15a3e, frozen4c072fed core, informational SourceLink71445454;
complete production inventory matches committed source. Unchanged worker7cf37ca5,
optional0.4 adapter, CPython3.13.16 and .NET11RC3 on the existing quiet Ubuntu24.04.4
F4as_v7 (four EPYC9V45vCPUs,16GiB/no swap). Normal GC/tiering, five-second warmup
per role/job, seven rotated150ms rounds, two identical Lython processes/one CPython.

26jobs/{elapsed:.3f}seconds: eight maintained complete scripts compile/warm/compile-
to-result, plus two explicit ordinary helper text warm cases. Execution includes
mediated RAM-file I/O, complete stdout/files validation and prior-result cleanup;
compile includes construction/disposal. Startup/staging/reset/protocol/final cache
teardown excluded. Pending-I/O latency, RSS/embedding-tail and individual optimization
CPU attribution remain unmeasured. Imports persist in CPython; Lython execution
modules remain isolated. Filesystem mediation/path checks are included in Lython.

All source/core/auxiliary/actualReady/runtime/golden/quiet/Closed/exit/join/fixture/
archive gates pass. Persistent evidence stays outside owned128MiB RAM fixtures;
workers and cleanup join, then fixtures are removed/unmounted, then archival is
verified under lease and independently locally.570s owner+30stop+30margin, no VM
data deletion. Focused332internal/155public per actual11/10 pass; final source
qualification CI42451722109 remains an independent delivery record.

Ratios are Lython elapsed/CPython elapsed; ranges span two Lython process medians,
not confidence intervals. Variable cases remain visible; labels are diagnostics,
not fixed design vetoes. This checkpoint does not repay earlier source-pair debt.

'''
(out/'README.md').write_text(intro+table('compile-run',ordinary,True)+'\nWarm execution:\n\n'+table('warm',ordinary+affected)+'\nCompilation:\n\n'+table('compile',ordinary)+'\n[Summary](summary.json), [full raw evidence](observations.tgz), [receipt](archive-receipt.json), [historical guide](prior-BENCHMARKS.md).\n',encoding='utf-8')
with tarfile.open(out/'procedures.tar.xz','w:xz')as a:
 for name in ['selection.md','prepare.py','launch.py','launch-command.py','launch.log','observe-not-before.json','terminal-status.json','retrieve.py','summarize.py','table-helpers.py','close.py']:a.add(r/name,arcname=name)
print('Verified26-job checkpoint preserved; primary guide refreshed at exact named source. No universal CPU/per-optimization claim.')
