from pathlib import Path
import json
p=Path(__file__).parent
data=json.loads((p/'summary.json').read_text(encoding='utf-8'));assert data['complete']and len(data['timing'])==26
rows={(r['case'],r['lane']):r for r in data['timing']}
ordinary=[('scripts.csv-validated-records.large','CSV validation/returned records','5,120 records / 68,625 B'),('scripts.csv-summary-functions.large','CSV summary/ordinary helper','4,096 records / 57,361 B'),('scripts.text-summary-helpers.large','Text summary/helpers','3,072 lines / 35,840 B'),('scripts.json-summary-helpers.large','JSON-lines/helpers','4,096 records / 110,592 B'),('scripts.report-render.large','JSON-to-Markdown report','3,072 records / 189,441 B'),('scripts.config-edit.small','Configuration read/edit/write','16 paths / 181 B'),('scripts.file-search.large','Protected file search','2,049 lines; exits after 1,025 / 42,010 B'),('scripts.file-manifest-helpers.large','Two-file copy/checksum/manifest','2 files / 4,107 B')]
affected=[('scripts.text-summary-rsplit-helpers.large','Text summary/rsplit helper','3,072 lines / 35,840 B'),('scripts.text-summary-guarded-helpers.large','Text summary/guarded helper','3,072 lines / 35,840 B')]
def table(lane,cases,inputs=False):
 text='| Workload | '+('Input | 'if inputs else'')+'Lython | CPython | Lython / CPython | Status; control / max IQR |\n'
 text+='| --- | '+('--- | 'if inputs else'')+'---: | ---: | ---: | --- |\n'
 for case,name,size in cases:
  r=rows[(case,lane)];low,high=r['timeRangeMilliseconds'];scale=1000 if high<1 else 1;unit='µs'if scale==1000 else'ms'
  ratios=r['ratioRange'];spread=max(r['iqrPercent'].values())
  text+=f"| {name} | "+(f'{size} | 'if inputs else'')+f"{low*scale:.3f}–{high*scale:.3f} {unit} | {r['medianMilliseconds']['CPython']*scale:.3f} {unit} | {ratios[0]:.2f}–{ratios[1]:.2f}× | {r['status']}; {r['controlPercent']:.2f}% / {spread:.2f}% |\n"
 return text
