from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;old=r.parent/'utf16-cpython-r277';source=r.parent/'captured-slot-ownership-r281';prior=json.loads((source/'b638/config.json').read_text(encoding='utf-8'))
root='/home/lokad/lython-bench-checks/captured-cpython-b640-20261112';unit='lython-b640-cpython-checkpoint-20261112';oldroot='/home/lokad/lython-bench-checks/utf16-cpython-b633-20261112';oldunit='lython-b633-cpython-checkpoint-20261112'
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='9bca1337f02a9acc172c65c141ce626222b847bd'
identity=dict(sourceRevision=head,coreSHA256={k:prior['identity']['coreSHA256']['candidate']for k in ['candidate','candidate-control']},auxiliaryFiles=prior['identity']['auxiliaryFiles'],catalogSHA256=prior['identity']['catalogSHA256'],sourceEvidence='benchmarks/results/2026-11-12-captured-slot-ownership/b638/observations.tgz; committed source9bca1337, full delivery43295336048 pending at launch')
jobs=[['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','compile'],['scripts.text-summary-helpers.nonlocal-counter.large','compile-run'],['scripts.report-render.large','warm'],['scripts.report-render.large','compile-run']]
shutil.copyfile(source/'catalog.json',r/'representative.json')
collect=(old/'collect.py').read_text(encoding='utf-8').replace(oldroot,root)
start=collect.index('jobs=');end=collect.index('\nenv = ',start)
collect=collect[:start]+'jobs='+repr(jobs)+"\nassert len(jobs)==5 and all(case in cases for case,lane in jobs)\n"+collect[end:]
collect=collect.replace("purpose='Qualified 41bd869b representative CPython3.13.16 checkpoint: captured text, UTF16 report, UTF8 control and config; separate compile/warm/compile-to-result; preserve adverse and uncertain outcomes.'","purpose='Committed9bca1337 versusCPython3.13.16: captured text separate compile/warm/fresh and UTF8 report warm/fresh; full delivery pending independently; preserve adverse and uncertain outcomes.'")
collect=collect.replace("< 380, 'Reserve40seconds for final owned work/cleanup.'","< 310, 'Reserve50seconds for final owned work/cleanup.'")
ast.parse(collect);(r/'collect.py').write_text(collect,encoding='utf-8',newline='\n')
for name in ['archive-owned.py','run.sh','remote-launch.py','launch.py','retrieve.py','summarize.py']:
 text=(old/name).read_text(encoding='utf-8').replace(oldroot,root).replace(oldunit,unit)
 if name=='archive-owned.py':text=text.replace('==7 ','==5 ').replace('jobs=7','jobs=5')
 if name=='remote-launch.py':text=text.replace("base/'bulk-utf16-b632-20261112/candidate'","base/'captured-slots-b638-20261112/candidate'").replace('lython-b633-fixtures','lython-b640-fixtures').replace('jobs=7,ownerSeconds=420','jobs=5,ownerSeconds=360').replace('RuntimeMaxSec=420','RuntimeMaxSec=360')
 if name=='launch.py':
  start=text.index("delivery=r.parent/");end=text.index("script=(r/'remote-launch.py')",start)
  text=text[:start]+'''proof=json.loads((r.parent/'captured-slot-ownership-r281/delivery/source-proof.json').read_text(encoding='utf-8'))
assert proof['head']==config['identity']['sourceRevision']and proof['allMatchWithExplicitNewlineNormalization']and proof['sourceCount']==568
# Timing may proceed independently of CI. Do not label this delivery-qualified
# until that exact source's full platform/stress/package run actually succeeds.
'''+text[end:]
  text=text.replace('timedelta(seconds=480)','timedelta(seconds=420)')
 if name=='retrieve.py':text=text.replace("['jobs']==7","['jobs']==5").replace("['elapsedSeconds']<480","['elapsedSeconds']<420").replace('B633 seven-job','B640 five-job')
 if name=='summarize.py':text=text.replace("len(raw['jobs'])==7","len(raw['jobs'])==5").replace('41bd869beee1bb53880da89124d4a1e98b2105df',head)
 if name.endswith('.py'):ast.parse(text.replace('config=CONFIG','config={}'))
 (r/name).write_text(text,encoding='utf-8',newline='\n')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(r/'payload.tgz','w:gz')as t:
 for name in ['collect.py','archive-owned.py','run.sh','representative.json','identity.json']:t.add(r/name,arcname=name)
config=dict(root=root,unit=unit,payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((r/'payload.tgz').read_bytes()).hexdigest(),identity=identity,requiredFreeBytes=264*1024*1024,ownerSeconds=360,stopSeconds=30,marginSeconds=30,jobs=jobs)
(r/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(jobs=jobs,payloadBytes=config['payloadBytes'],existingImageReused=True,fullQualificationClaim=False)))
