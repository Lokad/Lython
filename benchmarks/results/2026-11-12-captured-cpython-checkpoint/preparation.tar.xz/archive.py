from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;summary=json.loads((r/'summary.json').read_text(encoding='utf-8'))
assert summary['complete']and len(summary['timing'])==5
assert json.loads((r/'terminal-status.json').read_text(encoding='utf-8'))['exitCode']=='0'
out=Path('benchmarks/results/2026-11-12-captured-cpython-checkpoint');out.mkdir(exist_ok=True)
for name in ['observations.tgz','archive-receipt.json','summary.json','terminal-status.json','extraction.json']:shutil.copyfile(r/name,out/name)
shutil.copyfile(r.parent/'captured-slot-ownership-r281/delivery/source-proof.json',out/'source-proof.json')
shutil.copyfile('docs/BENCHMARKS.md',out/'prior-BENCHMARKS.md')
with tarfile.open(out/'preparation.tar.xz','w:xz')as t:
 for name in ['prepare.py','remote-launch.py','launch.py','launch.log','config.json','retrieve.py','summarize.py','archive.py','observe-not-before.json']:t.add(r/name,arcname=name)
files={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in out.iterdir()if p.is_file()and p.name not in('manifest.json','README.md')}
(out/'manifest.json').write_text(json.dumps(files,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Five external comparisons/source equivalence/raw controls archived. Core delivery remains independently pending.')
