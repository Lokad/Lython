from pathlib import Path
import json,statistics
r=Path(__file__).parent
raw=json.loads((r/'retrieved/confirmation/confirmation.json').read_text(encoding='utf-8'))
assert raw['complete'] and len(raw['jobs'])==5
rows=[]
for j in raw['jobs']:
 values={k:[1000*s['response']['elapsedTicks']/s['response']['clockFrequency']/s['response']['completedInvocations']for s in j['samples']if s['engine']==k]for k in j['identities']}
 m={k:statistics.median(v)for k,v in values.items()}
 ratios=[m[a]/m[b]for a in ['candidate','candidate-control']for b in ['CPython','CPython-control']]
 controls=dict(Lython=100*abs(m['candidate-control']/m['candidate']-1),CPython=100*abs(m['CPython-control']/m['CPython']-1))
 iqr={k:100*(statistics.quantiles(v,n=4)[2]-statistics.quantiles(v,n=4)[0])/m[k]for k,v in values.items()}
 row=dict(case=j['case'],lane=j['lane'],medianMilliseconds=m,ratioRange=[min(ratios),max(ratios)],controlsPercent=controls,iqrPercent=iqr,allWorkersJoined=j['workersJoinedAndFixturesRemoved']);rows.append(row)
 print(j['case'],j['lane'],m,row['ratioRange'],controls,'maxIQR',max(iqr.values()),flush=True)
(r/'summary.json').write_text(json.dumps(dict(complete=True,elapsedSeconds=raw['elapsedSeconds'],revision='9bca1337f02a9acc172c65c141ce626222b847bd',runtimeBaseline='CPython3.13.16',timing=rows),indent=2)+'\n',encoding='utf-8',newline='\n')
