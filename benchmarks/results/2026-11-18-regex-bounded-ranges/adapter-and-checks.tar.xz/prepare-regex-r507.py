from pathlib import Path
import hashlib,io,json,os,subprocess,tarfile
repo=Path('D:/code/Lython');r=Path(__file__).parent/'regex-range-r507';r.mkdir(exist_ok=False);sibling=Path('D:/code/utf8regex');revision='7e683b2db8c5e2fb1e2a83b3fd4bfeea6e77ffa1'
data=subprocess.check_output(['git','archive','--format=tar',revision,'src','Directory.Build.props','global.json'],cwd=sibling)
(r/'producer-source.tar.xz').write_bytes(b'')
source=r/'producer';source.mkdir()
with tarfile.open(fileobj=io.BytesIO(data))as a:a.extractall(source,filter='data')
with tarfile.open(r/'producer-source.tar.xz','w:xz')as a:
 for p in sorted(source.rglob('*')):
  if p.is_file():a.add(p,arcname=p.relative_to(source).as_posix())
facts=dict(revision=revision,readOnlyCommittedBlobs=True,producerWorktreeNotModified=True,sourceArchiveSHA256=hashlib.sha256((r/'producer-source.tar.xz').read_bytes()).hexdigest(),normalAdapterPin='0.4.0',coreDependenciesUnchanged=True,developmentOnly=True,publicationHeld=True,policy='Scoped Core/PythonRe source has Unsafe.SizeOf calls. No new production dependency/pin or safety certification; build disallows unsafe C#.',remaining=['UTF8 named-group enumeration','creation token detached from later pulls','separate result-stage allowance'],new=['CaptureGroupCount metadata','bounded Search/Match/FullMatch cursor modes','caller capture slots on one-shot Match without completion-order lastindex'])
(r/'source-facts.json').write_text(json.dumps(facts,indent=2)+'\n',encoding='utf-8',newline='\n')
d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
cmd=[str(d),'build',str(source/'src/Lokad.Utf8Regex.PythonRe/Lokad.Utf8Regex.PythonRe.csproj'),'-c','Release','--no-incremental','-p:AllowUnsafeBlocks=false','-p:EnableSourceControlManagerQueries=false']
with(r/'producer-build.log').open('w',encoding='utf-8')as log:p=subprocess.run(cmd,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert p.returncode==0,(r/'producer-build.log').read_text(encoding='utf-8')[-5000:]
print('Pinned7e683b2d producer builds actual11/10, no sibling mutation/normal pin change.',flush=True)
