from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');work=repo/'.git/agent-worktrees/bulk-trim-r506';prior=r.parent/'regex-dev105-r443'
assert 'Build succeeded.'in(r/'producer-build.log').read_text(encoding='utf-8')
project=r/'adapter';project.mkdir(exist_ok=False)
s=(prior/'candidate/Utf8RegexProvider.cs').read_text(encoding='utf-8')
a=s.index('            var data = Backend(() => mode switch');b=s.index('\n            return true;',a)+len('\n            return true;')
s=s[:a]+'''            using var cursor = Backend(() => Pattern.Regex.CreateMatchCursor(Input, _startByte,
                cancellationToken, mode: mode switch
                {
                    LythonRegexMatchMode.Match => Utf8PythonMatchMode.Match,
                    LythonRegexMatchMode.FullMatch => Utf8PythonMatchMode.FullMatch,
                    _ => Utf8PythonMatchMode.Search,
                }, endOffsetInBytes: _window.EndByte), cancellationToken, patternSource: Pattern.Regex);
            try
            {
                if (!cursor.MoveNext(out var data, cancellationToken)) return false;
                CopyCaptures(data, captures, cancellationToken);
                lastIndex = data.LastIndex;
                return true;
            }
            catch (PythonRePatternException error)
            { throw PatternError(error, cancellationToken, patternSource: Pattern.Regex); }
            catch (ArgumentException error)
            { throw new LythonRegexException(LythonRegexFailure.Pattern, error.Message); }'''+s[b:]
a=s.index('        private static void CopyCaptures(Utf8PythonDetailedMatchData');b=s.index('        private static void CopyCaptures(Utf8PythonRangeMatch',a)
s=s[:a]+s[b:]
s=s.replace('CaptureSlotCount = names.Length;','CaptureSlotCount = checked(regex.CaptureGroupCount + 1);')
assert 'DetailedMatchData'not in s and 'MatchDetailedData'not in s
(project/'Utf8RegexProvider.cs').write_text(s,encoding='utf-8',newline='\n')
csproj='''<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFrameworks>net11.0;net10.0</TargetFrameworks><AssemblyName>Lokad.Lython.Utf8Regex</AssemblyName><Version>0.11.0</Version><AssemblyVersion>0.11.0.0</AssemblyVersion><IsPackable>false</IsPackable><AllowUnsafeBlocks>false</AllowUnsafeBlocks><EnableSourceControlManagerQueries>false</EnableSourceControlManagerQueries></PropertyGroup><ItemGroup>'''
for n in ['Lokad.Lython','Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']:
 path=work/'src/Lokad.Lython/bin/Release/$(TargetFramework)/Lokad.Lython.dll'if n=='Lokad.Lython'else r/'producer/src'/n/'bin/Release/$(TargetFramework)'/(n+'.dll')
 csproj+='<Reference Include="'+n+'"><HintPath>'+str(path)+'</HintPath></Reference>'
csproj+='</ItemGroup></Project>\n';(project/'Adapter.csproj').write_text(csproj,encoding='utf-8',newline='\n')
d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
with(r/'adapter-build.log').open('w',encoding='utf-8')as log:p=subprocess.run([str(d),'build',str(project/'Adapter.csproj'),'-c','Release','--no-incremental'],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert p.returncode==0,(r/'adapter-build.log').read_text(encoding='utf-8')[-4500:]
images={};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for tfm in ['net11.0','net10.0']:
 image=r/'consumers'/tfm
 shutil.copytree(work/'tests/Lokad.Lython.PublicApi.Tests/bin/Release'/tfm,image,copy_function=shutil.copyfile)
 for n in ['Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']:
  shutil.copyfile(r/'producer/src'/n/'bin/Release'/tfm/(n+'.dll'),image/(n+'.dll'))
 shutil.copyfile(project/'bin/Release'/tfm/'Lokad.Lython.Utf8Regex.dll',image/'Lokad.Lython.Utf8Regex.dll')
 fixture=image/'tests/Lokad.Lython.WorkerFixture/bin/Release'/tfm
 shutil.copytree(work/'tests/Lokad.Lython.WorkerFixture/bin/Release'/tfm,fixture,copy_function=shutil.copyfile)
 for n in ['Lokad.Lython.dll','Lokad.Lython.Utf8Regex.dll','Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll']:
  shutil.copyfile(image/n,fixture/n);assert (image/n).read_bytes()==(fixture/n).read_bytes()
 (image/'Directory.Build.props').write_text('<Project/>\n',encoding='utf-8',newline='\n')
 shutil.copytree(repo/'tests/Fixtures/Workflows/RegexRewrite',image/'Fixtures/Workflows/RegexRewrite',copy_function=shutil.copyfile,dirs_exist_ok=True)
 images[tfm]={n:sha(image/n)for n in ['Lokad.Lython.dll','Lokad.Lython.Utf8Regex.dll','Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll','Lokad.Lython.PublicApi.Tests.dll']}
(r/'image-identity.json').write_text(json.dumps(dict(images=images,adapterSHA256=sha(project/'Utf8RegexProvider.cs'),parentAndChildImagesIdentical=True,normalPinUnchanged=True,coreDependenciesUnchanged=True),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Modern bounded-range development adapter and exact parent/child images built for both targets.',flush=True)
