using System.Buffers;
using System.Text;
using System.Text.RegularExpressions;
using Lokad.Utf8Regex.Internal.Caching;
using Lokad.Utf8Regex.Internal.Execution;
using Lokad.Utf8Regex.Internal.FrontEnd;
using Lokad.Utf8Regex.Internal.Input;
using Lokad.Utf8Regex.Internal.Planning;

namespace Lokad.Utf8Regex.PythonRe;

/// <summary>Provides a culture-invariant CPython <c>re</c>-compatible surface over well-formed UTF-8 input.</summary>
/// <remarks>The adapter preserves Python operation shaping while exposing UTF-8 byte ranges.</remarks>
public sealed partial class Utf8PythonRegex
{
    /// <summary>Compiles an expression over already-valid UTF-8 text.</summary>
    /// <remarks>A null timeout uses DefaultMatchTimeout. Subject bytes remain caller-valid/unchanged; host text/collections are outside regex controls. Use Compile for separate construction/funding controls.</remarks>
    public Utf8PythonRegex(string pattern, PythonReCompileOptions options = PythonReCompileOptions.None, TimeSpan? matchTimeout = null,
        Utf8ResourcePolicy resourcePolicy = default)
        : this(new Utf8ConstructionPattern(pattern), options, matchTimeout ?? DefaultMatchTimeout, resourcePolicy) { }

    /// <summary>Compiles a strict UTF-8 pattern over already-valid UTF-8 text.</summary>
    /// <remarks>A null timeout uses DefaultMatchTimeout. Subject bytes remain caller-valid/unchanged; host text/collections are outside regex controls. Use Compile for separate construction/funding controls.</remarks>
    public Utf8PythonRegex(ReadOnlySpan<byte> patternUtf8, PythonReCompileOptions options = PythonReCompileOptions.None, TimeSpan? matchTimeout = null,
        Utf8ResourcePolicy resourcePolicy = default)
        : this(new Utf8ConstructionPattern(patternUtf8), options, matchTimeout ?? DefaultMatchTimeout, resourcePolicy) { }

    private readonly record struct PythonReUtf8MatchRange(
        int IndexInBytes,
        int LengthInBytes);

    private ref struct PythonReUtf8MatchRangeBuffer
    {
        private Utf8InvocationResultBuffer<PythonReUtf8MatchRange> _ranges;
        private Utf8SliceInvocation _invocation;
        private Utf8InvocationResultLedger _results;

        internal PythonReUtf8MatchRangeBuffer(Utf8SliceInvocation invocation)
        {
            _invocation = invocation;
            _ranges = default;
            _results = default;
        }

        internal readonly int Count => _ranges.Count;
        internal readonly PythonReUtf8MatchRange this[int index] => _ranges[index];

        internal void Add(PythonReUtf8MatchRange range)
        {
            var breach = _invocation.TryChargeInputStep();
            if (breach != Utf8ExecutionLimitKind.None) throw _invocation.Budget.CreateResourceFailure();
            _ranges.Add(range, ref _invocation);
        }

        internal T[] AllocateResultArray<T>(int count)
            => _results.AllocateArray<T>(count, ref _invocation);

        internal byte[] GetBytes(ReadOnlySpan<byte> input, PythonReUtf8MatchRange range)
        {
            var bytes = AllocateResultArray<byte>(range.LengthInBytes);
            Utf8InvocationOutput.Copy(input.Slice(range.IndexInBytes, range.LengthInBytes), bytes,
                new Utf8InvocationBufferControl(ref _invocation));
            return bytes;
        }

        internal bool HasResourceFailure => _invocation.Budget.LimitBreach != Utf8ExecutionLimitKind.None;
        internal Utf8ResourceLimitExceededException ResourceFailure() => _invocation.Budget.CreateResourceFailure();

        internal void Checkpoint() => Utf8InvocationOutput.Checkpoint(new Utf8InvocationBufferControl(ref _invocation));

        internal void Dispose()
        {
            _ranges.Release(ref _invocation);
            _results.Release(ref _invocation);
            // This private collector owns every Core enumerator copy, and only
            // independent Python data escapes. Its remaining map/table loans
            // cannot outlive publication. Public copied Core cursors keep their
            // separate conservative invocation-long ownership contract.
            if (_invocation.Ledger.HasMemoryAllowance)
                _invocation.Ledger.Release(_invocation.Ledger.ReservedBytes);
        }
    }

    private static TimeSpan s_defaultMatchTimeout = Timeout.InfiniteTimeSpan;
    private readonly Utf8SliceProgram _scalarProgram;
    private readonly Lazy<Utf8SliceProgram> _lazyScalarFullProgram;
    private readonly Utf8Regex? _utf8Regex;
    private readonly PythonReNameEntry[] _nameEntries;
    private readonly byte[][] _nameEntriesUtf8;
    private readonly IReadOnlyDictionary<string, int> _namedGroups;
    private readonly bool _canMatchEmpty;
    private readonly bool _canUseUtf8IterationFastPath;
    private readonly bool _canUseZeroOffsetUtf8SearchValueFastPath;
    private readonly bool _canUseZeroOffsetUtf8ValueFastPath;
    private const int ReplacementPlanCacheCapacity = 16;
    private readonly Utf8BoundedPreparationCache<object, PythonReReplacementPlan> _replacementPlanCache;
    private readonly object _patternSource;

    /// <summary>Shared construction worker. Validates the policy before parsing or preparation.</summary>
    private Utf8PythonRegex(Utf8ConstructionPattern patternSource, PythonReCompileOptions options, TimeSpan matchTimeout, Utf8ResourcePolicy resourcePolicy)
    {
        ValidatePythonRePolicy(resourcePolicy, nameof(resourcePolicy));
        // These argument checks need no pattern conversion or construction
        // allowance. Keep policy errors first, then flags and timeout, for both
        // text and byte entries before acquiring decoded pattern storage.
        PythonReCompileValidator.Validate(options);
        MatchTimeout = Utf8MatchTimeout.Validate(matchTimeout, nameof(matchTimeout));
        ArgumentNullException.ThrowIfNull(patternSource.Text, "pattern");
        using var construction = Utf8ConstructionScope.Enter();
        if (patternSource.IsUtf8)
        {
            PythonReParser.ValidateNativeSource(patternSource.Utf8, construction.Budget);
            // This retained copy also supplies the parser's borrow. Admission
            // precedes allocation; caller reuse after compilation is harmless.
            var bytes = construction.Budget.AllocateArray<byte>(patternSource.Length, false);
            construction.Budget.ChargeWork((ulong)bytes.Length);
            patternSource.Utf8.CopyTo(bytes);
            _patternSource = bytes;
        }
        else _patternSource = patternSource.Text;
        Options = options;
        ResourcePolicy = resourcePolicy;
        HasFiniteExecutionLimits = resourcePolicy.MaxWorkSteps.HasValue || resourcePolicy.MaxDepth.HasValue ||
            resourcePolicy.MaxWorkingBytes.HasValue || resourcePolicy.MaxResultBytes.HasValue;

        var parser = PythonReParser.Create(_patternSource);
        var parseResult = parser.Parse(options);
        EffectiveOptions = (parseResult.Options & PythonReCompileOptions.Ascii) != 0
            ? parseResult.Options
            : parseResult.Options | PythonReCompileOptions.Unicode;
        _canMatchEmpty = PythonReTranslator.CanMatchEmpty(parseResult.Root, parseResult);
        _canUseUtf8IterationFastPath = PythonReTranslator.CanUseUtf8IterationFastPath(parseResult.Root);
        var isExactLiteral = PythonReTranslator.IsExactLiteral(parseResult.Root);
        // Nullable iteration always uses the Python scalar program. Only the
        // exact empty literal has a separate Core value-operation consumer.
        var prepareCore = !_canMatchEmpty || isExactLiteral;
        var translation = PythonReTranslator.Translate(parseResult, prepareCore);
        _scalarProgram = PythonReScalarCompiler.Compile(parseResult);
        // Failed preparation is retryable: a caller's cancellation must not
        // become a permanently cached failure. Concurrent cold callers may each
        // derive under their own construction scope; only one result is kept.
        _lazyScalarFullProgram = new Lazy<Utf8SliceProgram>(() => PythonReScalarCompiler.RequireFullMatch(_scalarProgram), LazyThreadSafetyMode.PublicationOnly);

        _groupNames = GetPublicGroupNames(parseResult.CaptureGroupCount, parseResult.NamedGroups);
        _nameEntries = GetPythonNameEntries(parseResult.NamedGroups);
        _nameEntriesUtf8 = construction.Budget.AllocateArray<byte[]>(_nameEntries.Length, false);
        for (var index = 0; index < _nameEntries.Length; index++)
        {
            construction.Budget.ChargeWork(1);
            _nameEntriesUtf8[index] = construction.Budget.EncodeUtf8(_nameEntries[index].Name.AsSpan());
        }
        // Transfer the parser's admitted immutable name map for replacement
        // lookup without retaining the rest of the parse tree.
        _namedGroups = parseResult.NamedGroups;

        // Other nullable programs use neither Core start hints nor its result
        // lanes. Their operations use Python scalar execution or independent
        // kernels, so avoid rendering/constructing an unused Core program.
        if (prepareCore)
        {
            try
            {
                var core = new Utf8Regex(translation.NativePatternUtf8, translation.NativeRegexOptions, MatchTimeout, resourcePolicy);
                // Preparation can discover useful native result lanes or exact
                // start hints. Discard roots declined by every current consumer;
                // their transient construction remains conservatively admitted.
                if (_canUseUtf8IterationFastPath || core.CanFindNativeLiteralForResult ||
                    PythonReScalarMatchState.CanUseCandidateRegex(_scalarProgram, core))
                    _utf8Regex = core;
            }
            catch (Exception exception) when (IsOptionalUtf8BackendUnavailableException(exception))
            {
                // The optional core fast path may be unavailable; the profile scalar program serves the grammar.
            }
        }

        // Core owns its source/literal copies. Rendering was construction
        // scratch, including when every optional Core consumer declined.
        construction.Budget.ReleaseArray(translation.NativePatternUtf8, false);

        _canUseZeroOffsetUtf8SearchValueFastPath =
            isExactLiteral &&
            _utf8Regex?.Inspection.ExecutionKind is
                NativeExecutionKind.ExactAsciiLiteral or NativeExecutionKind.ExactUtf8Literal;
        _canUseZeroOffsetUtf8ValueFastPath =
            _canUseZeroOffsetUtf8SearchValueFastPath &&
            _utf8Regex?.Inspection.ExecutionKind == NativeExecutionKind.ExactAsciiLiteral;
        _replacementPlanCache = Utf8BoundedPreparationCache<object, PythonReReplacementPlan>.CreateRetained(ReplacementPlanCacheCapacity, PythonReReplacementKeyComparer.Instance);
        construction.Complete();
    }

    private static void ValidatePythonRePolicy(Utf8ResourcePolicy resourcePolicy, string paramName)
        => resourcePolicy.Validate(paramName);

    /// <summary>Gets or sets the timeout used by constructors that do not specify one.</summary>
    /// <remarks>The initial value is an infinite timeout.</remarks>
    public static TimeSpan DefaultMatchTimeout
    {
        get => s_defaultMatchTimeout;
        set => s_defaultMatchTimeout = Utf8MatchTimeout.Validate(value, nameof(value));
    }

    private readonly string[] _groupNames;

    /// <summary>Gets the original Python regular-expression pattern.</summary>
    /// <remarks>Byte compilation owns UTF-8 source. This explicit text projection allocates independently on each native request; the string is not retained by the program.</remarks>
    public string Pattern => _patternSource is string text ? text : Encoding.UTF8.GetString((byte[])_patternSource);

    /// <summary>Gets the compile options supplied by the caller.</summary>
    /// <remarks>Use <see cref="EffectiveOptions"/> for validated global inline flags and implicit Unicode behavior.</remarks>
    public PythonReCompileOptions Options { get; }

    /// <summary>Gets the validated global compile options, including leading inline flags and implicit Unicode behavior.</summary>
    /// <remarks>Scoped flags do not affect this value. Unicode is included unless global ASCII behavior is selected.</remarks>
    public PythonReCompileOptions EffectiveOptions { get; }

    /// <summary>Gets the maximum duration of an individual matching operation.</summary>
    public TimeSpan MatchTimeout { get; }

    /// <summary>Gets the invocation resource policy. Finite work, depth, working and result-capacity limits are supported.</summary>
    public Utf8ResourcePolicy ResourcePolicy { get; }

    /// <summary>Returns the group names in group-number order, including group zero.</summary>
    // returned arrays are caller-owned; never expose the compiled backing storage. Empty entry arrays stay shared: they have no slots to mutate.
    public string[] GetGroupNames() => (string[])_groupNames.Clone();

    internal bool DebugUsesUtf8RegexBackend => _utf8Regex is not null;

    internal int DebugReplacementPlanCacheEntryCount => _replacementPlanCache.Count;
    internal ulong DebugReplacementPlanCachePayloadBytes => _replacementPlanCache.PayloadBytes;

    internal string? DebugUtf8ExecutionKind => _utf8Regex?.Inspection.ExecutionKind.ToString();

    // Exact profile classes and lexical reference lowerings come from the Python
    // AST, independently of residual native selectors or BCL case flags.
    private Utf8SliceProgram ScalarProgram => _scalarProgram;

    /// <summary>Gets the number of capture groups, excluding whole-match group zero.</summary>
    /// <remarks>The count comes from the validated grammar and does not depend on match participation.</remarks>
    public int CaptureGroupCount => _scalarProgram.GroupCount;

    private bool HasFiniteExecutionLimits { get; }

    private Utf8ExecutionLimits InvocationLimits => new(ResourcePolicy.MaxWorkSteps ?? 0, ResourcePolicy.MaxDepth ?? 0, ResourcePolicy.MaxWorkingBytes ?? 0, ResourcePolicy.MaxResultBytes ?? 0);

    private RegexMatchTimeoutException CreateMatchTimeoutException(ReadOnlySpan<byte> input, string pattern)
        => _programMemory is not null
            ? new RegexMatchTimeoutException(string.Empty, pattern, MatchTimeout)
            : Utf8Regex.CreateMatchTimeoutException(input, pattern, MatchTimeout, InvocationLimits);

    internal bool DebugUsesZeroOffsetUtf8ValueFastPath => _canUseZeroOffsetUtf8ValueFastPath;

    internal bool DebugUsesZeroOffsetUtf8SearchValueFastPath =>
        _canUseZeroOffsetUtf8SearchValueFastPath;

    internal bool DebugIsScalarFullProgramValueCreated => _lazyScalarFullProgram.IsValueCreated;

    internal static bool IsOptionalUtf8BackendUnavailableException(Exception exception)
        => exception is ArgumentException or NotSupportedException;

    private void ValidateStartOffset(ReadOnlySpan<byte> input, int startOffsetInBytes)
    {
        if ((uint)startOffsetInBytes > (uint)input.Length)
        {
            throw new ArgumentOutOfRangeException(nameof(startOffsetInBytes));
        }

        if (startOffsetInBytes < input.Length &&
            (input[startOffsetInBytes] & 0xC0) == 0x80)
        {
            throw new ArgumentOutOfRangeException(
                nameof(startOffsetInBytes),
                startOffsetInBytes,
                "The requested byte offset is not aligned to a UTF-8 scalar boundary.");
        }

    }

    // Public names follow Python slot order; the optional core route has its own slot permutation.
    private static string[] GetPublicGroupNames(int captureGroupCount, IReadOnlyDictionary<string, int> namedGroups)
    {
        using var construction = Utf8ConstructionScope.Enter();
        var budget = construction.Budget;
        var names = budget.AllocateArray<string>(checked(captureGroupCount + 1), false);
        foreach (var pair in namedGroups)
        {
            budget.ChargeWork(1);
            names[pair.Value] = pair.Key;
        }

        names[0] = "0";
        Span<char> digits = stackalloc char[11];
        for (var pythonGroup = 1; pythonGroup <= captureGroupCount; pythonGroup++)
        {
            budget.ChargeWork(1);
            if (names[pythonGroup] is not null) continue;
            budget.ChargeWork((ulong)digits.Length);
            pythonGroup.TryFormat(digits, out var written, provider: System.Globalization.CultureInfo.InvariantCulture);
            // Admit the actual decimal text extent before ToString, retaining
            // its existing small-number sharing instead of forcing a new copy.
            budget.ChargeWork((ulong)written + 1);
            budget.ReserveBytes(Utf8ConstructionBudget.StringBytes(written));
            names[pythonGroup] = pythonGroup.ToString(System.Globalization.CultureInfo.InvariantCulture);
        }

        construction.Complete();
        return names;
    }

    // name entries carry Python slot numbers; the managed numbers they replaced were only valid when no named group preceded an unnamed one.
    private static PythonReNameEntry[] GetPythonNameEntries(IReadOnlyDictionary<string, int> namedGroups)
    {
        using var construction = Utf8ConstructionScope.Enter();
        var entries = construction.Budget.AllocateArray<PythonReNameEntry>(namedGroups.Count, false);
        var index = 0;
        foreach (var pair in namedGroups)
        {
            construction.Budget.ChargeWork(1);
            entries[index++] = new PythonReNameEntry
            {
                Name = pair.Key,
                Number = pair.Value
            };
        }

        construction.Complete();
        return entries;
    }

}
