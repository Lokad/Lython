namespace Lokad.Utf8Regex.PythonRe;

/// <summary>Maps a Python named group to its numeric capture slot.</summary>
public readonly struct PythonReNameEntry
{
    /// <summary>Gets the group name.</summary>
    public string Name { get; init; }

    /// <summary>Gets the capture group number, starting at one; group zero is the whole match.</summary>
    public int Number { get; init; }
}

internal readonly struct PythonReGroupData
{
    public int Number { get; init; }

    public bool Success { get; init; }

    public int StartOffsetInBytes { get; init; }

    public int EndOffsetInBytes { get; init; }


}

/// <summary>Provides a stack-only match view over the original UTF-8 input.</summary>
/// <remarks>The view and returned spans must not outlive the input supplied to the matching operation.</remarks>
public readonly ref struct Utf8PythonValueMatch
{
    private readonly ReadOnlySpan<byte> _input;
    private readonly PythonReGroupData _data;

    internal Utf8PythonValueMatch(ReadOnlySpan<byte> input, PythonReGroupData data)
    {
        _input = input;
        _data = data;
    }

    /// <summary>Gets whether the operation found a match.</summary>
    public bool Success => _data.Success;

    /// <summary>Gets the match start as a zero-based byte offset, or zero after no match.</summary>
    public int StartOffsetInBytes => _data.StartOffsetInBytes;

    /// <summary>Gets the exclusive match end as a zero-based byte offset, or zero after no match.</summary>
    public int EndOffsetInBytes => _data.EndOffsetInBytes;

    /// <summary>Gets the match value from the original UTF-8 input.</summary>
    /// <returns>An empty span after no match.</returns>
    public ReadOnlySpan<byte> GetValueBytes()
    {
        if (!Success)
        {
            return ReadOnlySpan<byte>.Empty;
        }

        return _input[StartOffsetInBytes..EndOffsetInBytes];
    }

    internal static Utf8PythonValueMatch Create(ReadOnlySpan<byte> input, PythonReGroupData data) => new(input, data);
}

/// <summary>Describes CPython <c>findall</c> result shaping from the pattern's capture count.</summary>
public enum Utf8PythonFindAllShape
{
    /// <summary>Each item is the entire match because the pattern has no capture groups.</summary>
    FullMatch,

    /// <summary>Each item is the sole capture because the pattern has one capture group.</summary>
    SingleGroup,

    /// <summary>Each item is a capture tuple because the pattern has multiple capture groups.</summary>
    GroupTuple,
}

/// <summary>Contains owned UTF-8 values returned with CPython <c>findall</c> shaping.</summary>
public readonly struct Utf8PythonFindAllUtf8Result
{
    /// <summary>Gets whether each result is a scalar or capture tuple.</summary>
    public Utf8PythonFindAllShape Shape { get; init; }

    /// <summary>Gets full-match or single-group UTF-8 values for a scalar result shape.</summary>
    public byte[][] ScalarValues { get; init; }

    /// <summary>Gets UTF-8 capture tuples for the tuple result shape.</summary>
    public byte[][][] TupleValues { get; init; }

    /// <summary>Gets the number of matches represented by the active result collection.</summary>
    public int Count => Shape == Utf8PythonFindAllShape.GroupTuple
        ? TupleValues?.Length ?? 0
        : ScalarValues?.Length ?? 0;
}

/// <summary>Contains the UTF-8 result and replacement count from a CPython <c>subn</c> operation.</summary>
public readonly struct Utf8PythonSubnUtf8Result
{
    /// <summary>Gets the replaced text as owned UTF-8 bytes.</summary>
    public byte[] ResultBytes { get; init; }

    /// <summary>Gets the number of substitutions performed.</summary>
    public int ReplacementCount { get; init; }
}

