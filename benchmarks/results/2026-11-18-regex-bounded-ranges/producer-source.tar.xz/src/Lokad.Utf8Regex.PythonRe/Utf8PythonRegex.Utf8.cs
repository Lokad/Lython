using System.Text;
using System.Text.RegularExpressions;
using Lokad.Utf8Regex.Internal.Execution;
using Lokad.Utf8Regex.Internal.Input;
using Lokad.Utf8Regex.Internal.Planning;

namespace Lokad.Utf8Regex.PythonRe;

// UTF-8 backend engines, split from the Python facade along the backend ownership boundary.
/// <summary>UTF-8 backend engines for <see cref="Utf8PythonRegex"/>.</summary>
public sealed partial class Utf8PythonRegex
{
    // One exact, capture-free literal has no alternative end or capture state.
    // Its complete finder can serve FullMatch after both endpoints are checked.
    private bool CanUseLiteralFullMatch => _scalarProgram.GroupCount == 0 && !_scalarProgram.IgnoreCase &&
        (_canUseZeroOffsetUtf8SearchValueFastPath ||
         _utf8Regex?.CanFindNativeLiteralForResult == true &&
         _utf8Regex.Inspection.ExecutionKind is NativeExecutionKind.ExactAsciiLiteral or NativeExecutionKind.ExactUtf8Literal);

    // Optional Core owns the equivalent prepared exact family, while the caller's
    // invocation supplies every limit. Other controlled bulk paths remain scalar.
    private bool HasPreparedExactLiteralFamily =>
        _utf8Regex?.Inspection.ExecutionKind is NativeExecutionKind.ExactUtf8Literals;

    private Utf8PythonValueMatch MatchLiteralRepeatFullValue(ReadOnlySpan<byte> input,
        int startOffsetInBytes, CancellationToken cancellationToken)
    {
        // Capture the original deadline before the bounded proof or cold fallback
        // preparation. A declined proof must not create a second invocation.
        var invocation = CreateInvocation(cancellationToken);
        // At most 60 scalar instructions survive the structural proof. This
        // fixed stack scratch, like scalar locals, needs no heap/program loan.
        Span<byte> encoded = stackalloc byte[240];
        if (!TryGetFullMatchLiteralRepeat(encoded, out var literal, out var suffix, out var minimum, out var maximum))
        {
            var program = GetScalarFullProgram(input, invocation.Budget.Deadline, cancellationToken);
            var cursor = new PythonReScalarMatchCursor(input, program, startOffsetInBytes,
                MatchTimeout, _utf8Regex, this, invocation, prepareSearch: false);
            try
            {
                var result = cursor.MatchAtCurrentPosition()
                    ? Utf8PythonValueMatch.Create(input, cursor.SnapshotValueData()) : default;
                cursor.Checkpoint();
                return result;
            }
            catch (InvalidOperationException error) when (error is not Utf8ResourceLimitExceededException &&
                cursor.WorkingInvocation.Budget.LimitBreach != Utf8ExecutionLimitKind.None)
            { throw cursor.WorkingInvocation.Budget.CreateResourceFailure(); }
            catch (Utf8ExecutionDeadlineExpiredException)
            { throw cursor.TimeoutFailure(); }
            finally { cursor.Dispose(); }
        }
        try
        {
            Utf8InvocationOutput.Checkpoint(new Utf8InvocationBufferControl(ref invocation));
            if (invocation.TryReserveWorking(0) != Utf8ExecutionLimitKind.None)
                throw new InvalidOperationException("Literal repeat exceeded the working budget.");
            var control = new Utf8InvocationBufferControl(ref invocation);
            Utf8InvocationOutput.Checkpoint(control);
            // FullMatch fixes both endpoints. Removing a fixed tail leaves
            // exactly one possible repetition count, even when tail and period overlap.
            var length = input.Length - startOffsetInBytes - suffix.Length;
            var repetitions = length < 0 ? 0 : length / literal.Length;
            var matched = length >= 0 && length % literal.Length == 0 &&
                repetitions >= minimum && repetitions <= maximum &&
                input[^suffix.Length..].SequenceEqual(suffix);
            var position = startOffsetInBytes;
            var periodEnd = input.Length - suffix.Length;
            var perBlock = Math.Min(64, 2048 / literal.Length);
            while (matched && position < periodEnd)
            {
                Utf8InvocationOutput.Checkpoint(control);
                var end = position + Math.Min(perBlock, (periodEnd - position) / literal.Length) * literal.Length;
                for (; position < end; position += literal.Length)
                    if (!input.Slice(position, literal.Length).SequenceEqual(literal))
                    { matched = false; break; }
            }
            Utf8InvocationOutput.Checkpoint(control);
            if (!matched) return default;
            var completed = Utf8PythonValueMatch.Create(input, new PythonReGroupData
            {
                Number = 0,
                Success = true,
                StartOffsetInBytes = startOffsetInBytes,
                EndOffsetInBytes = input.Length
            });
            Utf8InvocationOutput.Checkpoint(control);
            return completed;
        }
        catch (InvalidOperationException error) when (error is not Utf8ResourceLimitExceededException &&
            invocation.Budget.LimitBreach != Utf8ExecutionLimitKind.None)
        { throw invocation.Budget.CreateResourceFailure(); }
        catch (Utf8ExecutionDeadlineExpiredException)
        { throw CreateMatchTimeoutException(input, Pattern); }
    }

    private bool TryGetFullMatchLiteralRepeat(Span<byte> encoded,
        out ReadOnlySpan<byte> literal, out ReadOnlySpan<byte> suffix, out long minimum, out long maximum)
    {
        literal = suffix = default; minimum = maximum = 0;
        var program = _scalarProgram;
        var code = program.Instructions;
        var repeat = code[0];
        if (program.IgnoreCase || program.RightToLeft || program.IsNonBacktracking || program.RepeatCount != 1 ||
            repeat.B != 0 || repeat.A < 3 || repeat.A > code.Length - 2 || repeat.RepeatMinimum < 1 ||
            repeat.RepeatMaximum < repeat.RepeatMinimum ||
            code[repeat.A - 1] is not { Kind: Utf8SliceInstructionKind.RepeatEnd, A: 0 } ||
            code[repeat.A] is not { Kind: Utf8SliceInstructionKind.RepeatExit, A: 0 } ||
            code[^1].Kind != Utf8SliceInstructionKind.Accept)
            return false;
        var offset = 0;
        var literalLength = 0;
        for (var index = 1; index < code.Length - 1; index++)
        {
            if (index == repeat.A - 1)
            {
                literalLength = offset;
                index++; // Skip the proved RepeatEnd and RepeatExit.
                continue;
            }
            if (code[index] is not { Kind: Utf8SliceInstructionKind.Literal, B: 0 } atom ||
                !Rune.TryCreate(atom.A, out var scalar) ||
                !scalar.TryEncodeToUtf8(encoded[offset..], out var width))
                return false;
            offset += width;
        }
        if (literalLength == 0) return false;
        literal = encoded[..literalLength]; suffix = encoded[literalLength..offset];
        minimum = repeat.RepeatMinimum; maximum = repeat.RepeatMaximum;
        return true;
    }

    private int CountPreparedLiteral(Utf8Regex prepared, ReadOnlySpan<byte> input, int startOffsetInBytes, CancellationToken cancellationToken)
    {
        var invocation = CreateInvocation(cancellationToken);
        try
        {
            var count = prepared.CountForResult(input, startOffsetInBytes, ref invocation);
            Utf8InvocationOutput.Checkpoint(new Utf8InvocationBufferControl(ref invocation));
            return count;
        }
        catch (InvalidOperationException error) when (error is not Utf8ResourceLimitExceededException &&
            invocation.Budget.LimitBreach != Utf8ExecutionLimitKind.None)
        {
            throw invocation.Budget.CreateResourceFailure();
        }
        catch (Utf8ExecutionDeadlineExpiredException)
        {
            throw CreateMatchTimeoutException(input, Pattern);
        }
    }

    private bool TryCollectUtf8MatchRanges(
        ReadOnlySpan<byte> input,
        int startOffsetInBytes,
        CancellationToken cancellationToken,
        out PythonReUtf8MatchRangeBuffer ranges)
    {
        // Generic Core enumeration rents fresh attempt scratch per value.
        // The existing Python cursor reuses its admitted workspace. Keep real
        // native enumerators, including direct families classified as fallback.
        if (_utf8Regex is null ||
            _utf8Regex.Inspection.ExecutionKind == NativeExecutionKind.FallbackRegex &&
            _utf8Regex.Inspection.PreparedRegex.AnchoredLiteral.Kind == Utf8AnchoredLiteralKind.None)
        {
            ranges = default;
            return false;
        }

        ranges = default;
        var invocation = default(Utf8SliceInvocation);
        try
        {
            Utf8ValueMatchEnumerator enumerator;
            if (_programMemory is null && startOffsetInBytes == 0 && !HasFiniteExecutionLimits &&
                !cancellationToken.CanBeCanceled && MatchTimeout == Timeout.InfiniteTimeSpan)
                enumerator = _utf8Regex.EnumerateMatches(input);
            else
            {
                invocation = CreateInvocation(cancellationToken);
                enumerator = _utf8Regex.EnumerateMatchesForResult(input, startOffsetInBytes, ref invocation);
            }

            ranges = new PythonReUtf8MatchRangeBuffer(enumerator.ExportWorkingInvocation());
            while (enumerator.MoveNext())
            {
                var match = enumerator.Current;
                var indexInBytes = match.StartOffsetInBytes;
                var lengthInBytes = (match.EndOffsetInBytes - match.StartOffsetInBytes);
                if (!match.Success)
                {
                    ranges.Dispose();
                    ranges = default;
                    return false;
                }

                ranges.Add(new PythonReUtf8MatchRange(
                    indexInBytes,
                    lengthInBytes));
            }

            return true;
        }
        catch (InvalidOperationException error) when (error is not Utf8ResourceLimitExceededException && ranges.HasResourceFailure)
        {
            var failure = ranges.ResourceFailure();
            ranges.Dispose();
            ReleaseFailedCollection(ref invocation);
            ranges = default;
            throw failure;
        }
        catch (Utf8ExecutionDeadlineExpiredException)
        {
            ranges.Dispose();
            ReleaseFailedCollection(ref invocation);
            ranges = default;
            throw CreateMatchTimeoutException(input, Pattern);
        }
        catch (RegexMatchTimeoutException) when (_programMemory is not null)
        {
            ranges.Dispose();
            ReleaseFailedCollection(ref invocation);
            ranges = default;
            // Core's enumeration wrapper uses its translated pattern. Bound
            // Python operations retain their original diagnostic authority.
            throw CreateMatchTimeoutException(input, Pattern);
        }
        catch
        {
            ranges.Dispose();
            ReleaseFailedCollection(ref invocation);
            ranges = default;
            throw;
        }
    }

    private static void ReleaseFailedCollection(ref Utf8SliceInvocation invocation)
    {
        // Enumeration setup can fail before a range buffer takes the borrowed
        // invocation. No enumerator/value alias is ever published on this path.
        if (invocation.Ledger.HasMemoryAllowance)
            invocation.Ledger.Release(invocation.Ledger.ReservedBytes);
    }

    private bool TryReplaceViaUtf8Literal(
        ReadOnlySpan<byte> input, PythonReReplacementPlan plan, int count, int startOffsetInBytes,
        ref Utf8SliceInvocation invocation, out byte[] resultBytes, out int replacementCount,
        out Utf8PythonRetainedSubnResult? retained, bool retain = false)
    {
        resultBytes = [];
        replacementCount = 0;
        retained = null;
        if (_canMatchEmpty || count < 0 || startOffsetInBytes != 0 ||
            !_canUseZeroOffsetUtf8ValueFastPath || _utf8Regex is null ||
            !plan.TryGetLiteralUtf8(out var literalBytes)) return false;

        Utf8InvocationResultLedger results = default;
        try
        {
            var bytes = _utf8Regex.ReplaceExactLiteralForResult(input, literalBytes,
                count == 0 ? int.MaxValue : count, ref invocation, ref results, out var replaced);
            if (bytes is null)
            {
                bytes = results.AllocateArray<byte>(input.Length, ref invocation);
                Utf8InvocationOutput.Copy(input, bytes, new Utf8InvocationBufferControl(ref invocation));
            }
            Utf8InvocationOutput.Checkpoint(new Utf8InvocationBufferControl(ref invocation));
            resultBytes = bytes;
            replacementCount = replaced;
            if (retain)
            {
                var receipt = results.AllocateObject((Result: new Utf8PythonSubnUtf8Result { ResultBytes = resultBytes, ReplacementCount = replaced },
                    Allowance: invocation.Ledger.MemoryAllowance!), static state => new Utf8PythonRetainedSubnResult(state.Result, state.Allowance), ref invocation);
                Utf8InvocationOutput.Checkpoint(new Utf8InvocationBufferControl(ref invocation));
                receipt.SetTransferredBytes(results.TransferSince(0, ref invocation));
                retained = receipt;
            }
            return true;
        }
        catch (InvalidOperationException error) when (error is not Utf8ResourceLimitExceededException && invocation.Budget.LimitBreach != Utf8ExecutionLimitKind.None)
        { throw invocation.Budget.CreateResourceFailure(); }
        catch (Utf8ExecutionDeadlineExpiredException)
        {
            throw CreateMatchTimeoutException(input, Pattern);
        }
        finally { results.Release(ref invocation); }
    }

    internal Utf8PythonValueMatch MaterializeNativeMatchValue(ReadOnlySpan<byte> input, int startOffsetInBytes,
        int kind, scoped ref Utf8SliceInvocation invocation)
    {
        try
        {
            var control = new Utf8InvocationBufferControl(ref invocation);
            if (!TryDiscoverNativeMatch(input, startOffsetInBytes, kind, ref invocation,
                out var start, out var end))
            {
                Utf8InvocationOutput.Checkpoint(control);
                return default;
            }
            // Discovery already proved the selected scalar byte endpoints.
            Utf8InvocationOutput.Checkpoint(control);
            return Utf8PythonValueMatch.Create(input, new PythonReGroupData
            {
                Number = 0,
                Success = true,
                StartOffsetInBytes = start,
                EndOffsetInBytes = end
            });
        }
        catch (InvalidOperationException error) when (error is not Utf8ResourceLimitExceededException &&
            invocation.Budget.LimitBreach != Utf8ExecutionLimitKind.None)
        {
            throw invocation.Budget.CreateResourceFailure();
        }
        catch (Utf8ExecutionDeadlineExpiredException)
        {
            throw CreateMatchTimeoutException(input, Pattern);
        }
    }

    private bool TryDiscoverNativeMatch(ReadOnlySpan<byte> input, int startOffsetInBytes, int kind,
        ref Utf8SliceInvocation invocation, out int start, out int end)
    {
        ValidateScalarStartOffset(input, startOffsetInBytes);
        var control = new Utf8InvocationBufferControl(ref invocation);
        // The caller supplies valid, unchanged UTF-8 text.
        // Consumers derive text sizing or coordinates only for a selected range.
        Utf8InvocationOutput.Checkpoint(new Utf8InvocationBufferControl(ref invocation));
        start = end = -1;
        if (_utf8Regex is null) throw new InvalidOperationException("Native result discovery requires its prepared core.");
        if (_utf8Regex.Inspection.PreparedRegex.LiteralUtf8 is { Length: 0 })
        {
            start = end = startOffsetInBytes;
            return kind != 2 || end == input.Length;
        }
        if (kind != 0 && _utf8Regex.Inspection.ExecutionKind is
            NativeExecutionKind.ExactAsciiLiteral or NativeExecutionKind.ExactUtf8Literal)
        {
            ref readonly var search = ref _utf8Regex.Inspection.PreparedRegex.SearchPlan;
            if (!search.HasBoundaryRequirements && !search.HasTrailingLiteralRequirement &&
                search.LiteralSearch is { IgnoreCase: false, Needle: { Length: >= 1 and <= 256 } literal })
            {
                // A required start permits one bounded comparison of the complete
                // literal, within the profile's existing 256-byte comparison
                // block. The caller guarantees valid, unchanged subject text.
                var remaining = input.Length - startOffsetInBytes;
                if (remaining < literal.Length || kind == 2 && remaining != literal.Length) return false;
                Utf8InvocationOutput.Checkpoint(control);
                if (!input.Slice(startOffsetInBytes, literal.Length).SequenceEqual(literal)) return false;
                start = startOffsetInBytes;
                end = start + literal.Length;
                return true;
            }
        }
        if (!_utf8Regex.TryFindNativeLiteralForResult(input, startOffsetInBytes, ref invocation,
            out var found, out start, out end))
            throw new InvalidOperationException("Prepared literal discovery declined its eligible route.");
        return found && (kind == 0 || start == startOffsetInBytes && (kind != 2 || end == input.Length));
    }
}
