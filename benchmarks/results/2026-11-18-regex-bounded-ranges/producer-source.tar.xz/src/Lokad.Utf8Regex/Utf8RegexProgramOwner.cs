using Lokad.Utf8Regex.Internal;
using System.Buffers;

namespace Lokad.Utf8Regex;

/// <summary>Owns caller-funded Core compilation, matching calls and persistent range cursors.</summary>
/// <remarks>Dispose closes new operations and refunds compilation after active calls finish. The underlying expression stays private. Temporary matching storage uses the program allowance unless a separate working allowance is supplied. Borrowed input and fixed invocation metadata remain outside modeled storage.</remarks>
public sealed class Utf8RegexProgramOwner : IDisposable
{

    private Utf8Regex? _regex;
    private readonly Utf8FundedStorage _storage;

    internal Utf8RegexProgramOwner(Utf8Regex regex, Utf8FundedStorage storage)
    { _regex = regex; _storage = storage; }

    /// <summary>Gets the number of defined capture slots, excluding whole-match group zero.</summary>
    /// <remarks>Rejects access after close. Sparse numbers and shared declarations retain their validated slot identities.</remarks>
    public int CaptureGroupCount
    {
        get
        {
            var regex = Volatile.Read(ref _regex) ?? throw new ObjectDisposedException(nameof(Utf8RegexProgramOwner));
            using var use = _storage.Enter();
            return regex.CaptureGroupCount;
        }
    }

    /// <inheritdoc cref="Utf8Regex.GroupNumberFromCaptureSlot" />
    /// <remarks>Retains program admission during this allocation-free metadata lookup and rejects access after close.</remarks>
    public int GroupNumberFromCaptureSlot(int captureSlot)
    {
        var regex = Volatile.Read(ref _regex) ?? throw new ObjectDisposedException(nameof(Utf8RegexProgramOwner));
        using var use = _storage.Enter();
        return regex.GroupNumberFromCaptureSlot(captureSlot);
    }

    /// <inheritdoc cref="Utf8Regex.GroupNumberFromUtf8Name" />
    /// <remarks>Retains program admission during access and rejects calls after close.</remarks>
    public int GroupNumberFromUtf8Name(ReadOnlySpan<byte> nameUtf8, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var regex = Volatile.Read(ref _regex) ?? throw new ObjectDisposedException(nameof(Utf8RegexProgramOwner));
        using var use = _storage.Enter();
        return regex.GroupNumberFromUtf8Name(nameUtf8, cancellationToken);
    }

    /// <inheritdoc cref="Utf8Regex.TryCopyPatternUtf8" />
    /// <remarks>Holds program admission during the copy and rejects calls after close. The destination belongs to the caller and remains valid after owner disposal; no borrowed program-storage alias is exposed. Access uses the existing managed use lease; it allocates no source/output buffer.</remarks>
    public OperationStatus TryCopyPatternUtf8(Span<byte> destination, out int bytesRequired,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var regex = Volatile.Read(ref _regex) ?? throw new ObjectDisposedException(nameof(Utf8RegexProgramOwner));
        using var use = _storage.Enter();
        return regex.TryCopyPatternUtf8(destination, out bytesRequired, cancellationToken);
    }

    /// <summary>Tests for a match with caller-funded temporary storage.</summary>
    /// <remarks>Null workingMemoryAllowance uses the program allowance; otherwise working storage uses the supplied separate owner. Numeric invocation limits still apply. A refused acquisition is terminal.</remarks>
    public bool IsMatch(ReadOnlySpan<byte> input, CancellationToken cancellationToken = default,
        IUtf8MemoryAllowance? workingMemoryAllowance = null)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var regex = Volatile.Read(ref _regex) ?? throw new ObjectDisposedException(nameof(Utf8RegexProgramOwner));
        using var use = _storage.Enter();
        return regex.IsMatch(input, cancellationToken, workingMemoryAllowance ?? _storage.Allowance);
    }

    /// <summary>Finds a match into caller-owned byte capture slots with funded temporary storage.</summary>
    /// <remarks>Slots follow Core group-number order including zero. Null working allowance uses program funding; entry cancellation or a closed owner leaves output unchanged. Returned ranges remain valid after owner disposal.</remarks>
    public Utf8CaptureRange Match(ReadOnlySpan<byte> input, int startOffsetInBytes,
        Span<Utf8CaptureRange> captures, CancellationToken cancellationToken = default,
        IUtf8MemoryAllowance? workingMemoryAllowance = null, int? endOffsetInBytes = null)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var regex = Volatile.Read(ref _regex) ?? throw new ObjectDisposedException(nameof(Utf8RegexProgramOwner));
        using var use = _storage.Enter();
        return regex.Match(input, startOffsetInBytes, captures, cancellationToken,
            workingMemoryAllowance ?? _storage.Allowance, endOffsetInBytes);
    }

    /// <summary>Counts matches with caller-funded temporary storage.</summary>
    /// <remarks>Null workingMemoryAllowance uses the program allowance; otherwise working storage uses the supplied separate owner. Numeric invocation limits still apply. Covered temporary storage refunds synchronously on success, failure or interruption.</remarks>
    public int Count(ReadOnlySpan<byte> input, CancellationToken cancellationToken = default,
        IUtf8MemoryAllowance? workingMemoryAllowance = null)
    {
        cancellationToken.ThrowIfCancellationRequested();
        // Capture before Enter: a successfully entered use retains this local
        // root across Close; a concurrent closed gate rejects the call.
        var regex = Volatile.Read(ref _regex) ?? throw new ObjectDisposedException(nameof(Utf8RegexProgramOwner));
        using var use = _storage.Enter();
        return regex.Count(input, cancellationToken, workingMemoryAllowance ?? _storage.Allowance);
    }

    /// <summary>Creates a persistent range cursor, retaining program admission until its EOF, failure or disposal.</summary>
    /// <remarks>The cursor borrows unchanged memory and survives awaits. Null start selects the direction's default; null working allowance uses program funding. Closing this owner rejects new cursors but existing cursors remain usable.</remarks>
    public Utf8RegexMatchCursor CreateMatchCursor(ReadOnlyMemory<byte> input, int? startOffsetInBytes = null,
        CancellationToken cancellationToken = default, IUtf8MemoryAllowance? workingMemoryAllowance = null)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var regex = Volatile.Read(ref _regex) ?? throw new ObjectDisposedException(nameof(Utf8RegexProgramOwner));
        var use = _storage.Enter();
        try
        {
            var cursor = regex.CreateMatchCursor(input, startOffsetInBytes, cancellationToken,
                workingMemoryAllowance ?? _storage.Allowance);
            cursor.AttachProgramUse(use);
            return cursor;
        }
        catch { use.Dispose(); throw; }
    }

    /// <summary>Replaces matches using a strict UTF-8 template into caller-owned destination storage.</summary>
    /// <remarks>Null working allowance uses program funding. Cold preparation and output scratch share live working admission; cached plans remain covered by the program's conservative cache allowance. Uses the controlled scalar replacement route, preserving captures, RTL and NonBacktracking. Covered temporary loans refund synchronously. An insufficient destination remains unchanged and reports zero bytes written. Caller-owned output remains valid after owner disposal.</remarks>
    public OperationStatus TryReplace(ReadOnlySpan<byte> input, ReadOnlySpan<byte> replacementUtf8,
        Span<byte> destination, out int bytesWritten, CancellationToken cancellationToken = default,
        IUtf8MemoryAllowance? workingMemoryAllowance = null)
    {
        cancellationToken.ThrowIfCancellationRequested();
        var regex = Volatile.Read(ref _regex) ?? throw new ObjectDisposedException(nameof(Utf8RegexProgramOwner));
        using var use = _storage.Enter();
        return regex.TryReplaceFunded(input, replacementUtf8, destination, out bytesWritten, cancellationToken,
            workingMemoryAllowance ?? _storage.Allowance);
    }

    /// <summary>Closes new uses and releases compilation after its last active call finishes.</summary>
    public void Dispose()
    {
        // Drop the owner's payload before a synchronous final refund callback.
        // In-flight calls already hold their local root and storage-use lease.
        Interlocked.Exchange(ref _regex, null);
        _storage.Close();
    }
}
