from pathlib import Path
import json,hashlib,shutil
root=Path("/home/lokad/lython-bench-checks/borrowed-native-arguments-b192-20261104");before=Path("/home/lokad/lython-bench-checks/whole-script-cpu-b191-20261104/candidate");candidate=root/'candidate'
for file in before.iterdir():
 if file.name=='Lokad.Lython.dll':continue
 if file.name in ['Lokad.Lython.Benchmarks.dll','Lokad.Lython.Benchmarks.deps.json','Lokad.Lython.Benchmarks.runtimeconfig.json']:shutil.copyfile(file,candidate/file.name)
 else:(candidate/file.name).symlink_to(file.resolve(),target_is_directory=file.is_dir())
assert hashlib.sha256((candidate/'Lokad.Lython.dll').read_bytes()).hexdigest()==json.loads((root/'identity.json').read_text())['coreSHA256']['candidate']
