from hashlib import sha256
from pathlib import Path
from statistics import median
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
notes = lab.parent
repo = lab.parents[3]
prior = notes/'abstract-binding-identifier-cache-20261127'
workers = lab/'comparison/local'
workers.mkdir(parents=True)
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
write = lambda p, value: p.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')
sha = lambda p: sha256(p.read_bytes()).hexdigest()
image = lambda p: {f.name: sha(f) for f in p.iterdir()}
core = 'Lokad.Lython.dll'
worker = 'Lokad.Lython.Benchmarks.dll'
python = Path('C:/Python313/python.exe')
sdk = Path.home() / '.dotnet11'
dotnet = sdk / 'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
pinned = read(repo/'benchmarks/results/2026-11-27-abstract-binding-identifier-cache/identity.json')
base = subprocess.check_output(['git','rev-parse','ab50fad4b'],cwd=repo,text=True).strip()
assert not subprocess.check_output(['git','diff','--name-only',base,'HEAD','--','src'],cwd=repo)
assert sha256(subprocess.check_output(['git','diff','--binary',pinned['sourceRevision'],base,'--','src'],cwd=repo)).hexdigest()==pinned['sourcePatchSHA256']
patch=subprocess.check_output(['git','diff','--binary','HEAD','--','src'],cwd=repo)
assert b'OrdinaryPositionalCount' in patch and b'TryPartitionArguments' in patch
assert not subprocess.check_output(['git','diff','--name-only','HEAD','--','src',':(exclude)src/Lokad.Lython/Frontend'],cwd=repo)
(lab/'candidate.patch').write_bytes(patch)
original=prior/'comparison/local'
assert image(original/'candidate')==pinned['imageFiles']['candidate']
for role in ('reference','candidate'):
    shutil.copytree(original/'candidate',workers/role)
fresh=repo/'src/Lokad.Lython/bin/Release/net11.0'/core
assert sha(fresh)!=sha(workers/'reference'/core)
shutil.copyfile(fresh,workers/'candidate'/core)
images={role:image(workers/role) for role in ('reference','candidate')}
assert [name for name, digest in images['reference'].items() if images['candidate'][name]!=digest]==[core]

for name in ('cpython-worker.py','run.sh'):
    shutil.copyfile(original/name,workers/name)
assert b'\r' not in (workers/'run.sh').read_bytes()
catalog=read(original/'representative.json')
assert sha(original/'representative.json')==pinned['catalogs']['representative.json']['sha256']
ordinary, escaping, guarded, nested = catalog['cases']
assert ordinary['id']=='diagnostic.generated-ordinary-definitions' and escaping['id']=='diagnostic.generated-escaping-definitions'
def create_case(use_expansion):
    call="scale(*args, **options)" if use_expansion else "scale(seed, factor=2, offset=1)"
    fixture="    args = (seed,)\n    options = {'factor': 2, 'offset': 1}\n" if use_expansion else ''
    code="def scale(value, *, factor, offset):\n    return value * factor + offset\n\ndef render(seed):\n"+fixture
    code+="    return (\n"+('        '+call+',\n')*96+"    )\nvalues = render(11)\nprint(len(values), sum(values), values[0], values[-1])\n"
    output=subprocess.check_output([python,'-I','-X','utf8','-c',code],cwd=repo,timeout=10).decode('utf-8').replace('\r\n','\n')
    assert output=='96 2208 23 23\n'
    return dict(ordinary,id='diagnostic.static-expansion-form' if use_expansion else 'diagnostic.static-keyword-form',
        source=code,sourceUtf8Bytes=len(code.encode()),sourceSha256=sha256(code.encode()).hexdigest(),
        expectedOutput=output,expectedOutputUtf8Bytes=len(output.encode()),expectedOutputSha256=sha256(output.encode()).hexdigest())
keyword=create_case(False)
expanded=create_case(True)
catalog['cases'] += [keyword, expanded]
write(workers/'representative.json',catalog)
jobs=[(ordinary['id'],'compile'),(expanded['id'],'compile'),(escaping['id'],'compile'),
      (keyword['id'],'compile-run'),(nested['id'],'warm')]
write(workers/'jobs.json',{'warm':jobs})
identity=dict(sourceRevision=base,sourcePatchSHA256=sha(lab/'candidate.patch'),productionReference=base,imageFiles=images,
    coreSHA256={role+suffix:files[core] for role,files in images.items() for suffix in ('','-control')},
    comparisonHostRevision=pinned['comparisonHostRevision'],cpythonWorkerSHA256=sha(workers/'cpython-worker.py'),
    independentCPythonVersion=subprocess.check_output([python,'--version'],text=True).strip(),verificationPythonSHA256=sha(python),
    purpose='Borrow the parser-owned positional prefix during static analysis. Compare definitions, ordinary keyword calls, expansions and a nested JSON control.')
identity['catalogs']={name:{'sha256':sha(workers/name)} for name in ('representative.json','jobs.json')}
write(workers/'identity.json',identity)
collector=(original/'collect.py').read_text(encoding='utf-8').replace('lython-b1876-abstract-binding-fixture-','lython-b1877-static-call-prefix-fixture-')
compile(collector,'collect.py','exec')
(workers/'collect.py').write_text(collector,encoding='utf-8',newline='\n')
for role, files in images.items():
    report=workers/f'{role}-verify.json'
    subprocess.run([dotnet,workers/role/worker,'--compare','verify','--catalog',workers/'representative.json',
        '--dotnet',dotnet,'--python',python,'--python-worker',workers/'cpython-worker.py','--out',report],env=env,check=True,timeout=75)
    proof=read(report)
    assert proof['state']=='Completed' and proof['caseCount']==6
    assert proof['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert proof['launched']['adapter']['sha256']==files[worker] and proof['launched']['library']['sha256']==files[core]
