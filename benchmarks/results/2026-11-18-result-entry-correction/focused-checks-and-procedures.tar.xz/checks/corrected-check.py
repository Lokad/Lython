from pathlib import Path
import os,subprocess,json
r=Path('D:/code/Lython/.git/agent-notes/review-20261031/discarded-results-r516'); repo=Path('D:/code/Lython')
d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
with(r/'corrected-solution-build.log').open('w',encoding='utf-8')as log:p=subprocess.run([str(d),'build','Lokad.Lython.slnx','-c','Release','--no-incremental','-v','quiet'],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
assert p.returncode==0,(r/'corrected-solution-build.log').read_text(encoding='utf-8');print('Nonincremental Release solution build passed.',flush=True)
filters={'internal':['InstructionFailureRouting','LoweringArchitectureSubsystem','ExecutableOperandStack','FunctionBodyTemporaryLifetime','OrdinaryFunctionTransport','NativeTextConstructionRollback','KnownDrainOwnership','DrainCleanupOwnership','CasedSplitOwnership','TemporaryReservationOwnership'], 'public':['NativeReceiverPipeline','HelperLocalLifetime','ClosedBuiltinResult','ProtectedHelperExecution','BufferedGeneratorContinuation','BulkGeneratorConsumption','GovernedMemoryContract','MemoryDenialAttribution','ContainerDisplayPipeline']}
rows=[]
for tfm in ['net11.0','net10.0']:
 for kind,parts in filters.items():
  project='Lokad.Lython.Tests'if kind=='internal'else'Lokad.Lython.PublicApi.Tests';cmd=[str(d),'test',f'tests/{project}/{project}.csproj','-c','Release','-f',tfm,'--no-build','--filter','('+'|'.join('FullyQualifiedName~'+s for s in parts)+')&Category!=Stress']
  file=r/('corrected-focused-'+kind+'-'+tfm+'.log')
  with file.open('w',encoding='utf-8')as log:p=subprocess.run(cmd,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
  rows.append(dict(kind=kind,framework=tfm,command=cmd,exitCode=p.returncode));(r/'corrected-checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
  output=file.read_text(encoding='utf-8');assert p.returncode==0,output;print(kind,tfm,output.splitlines()[-1],flush=True)
