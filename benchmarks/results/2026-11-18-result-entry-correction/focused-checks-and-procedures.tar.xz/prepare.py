from pathlib import Path
import gzip,hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');prior=r.parent/'discarded-results-r516'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert len(json.loads((prior/'corrected-checks.json').read_text(encoding='utf-8')))==4
base=json.loads((prior/'frozen/identity.json').read_text(encoding='utf-8')); frozen=r/'frozen';frozen.mkdir(exist_ok=False);images={}
for role in ['reference','candidate']:
 image=frozen/role;image.mkdir()
 for n,h in base['imageFiles']['candidate'].items():
  assert sha(prior/'frozen/candidate'/n)==h;shutil.copyfile(prior/'frozen/candidate'/n,image/n)
 if role=='candidate':shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',image/'Lokad.Lython.dll')
 images[role]={n:sha(image/n)for n in base['imageFiles']['candidate']}
 for p in (prior/'frozen/candidate').glob('ValidatedAllocation.*'):shutil.copyfile(p,image/p.name)
assert [n for n in images['reference']if images['reference'][n]!=images['candidate'][n]]==['Lokad.Lython.dll']
names=list(base['sourceInputs']);hashes={n:sha(repo/n)for n in names};assert len(names)==2390
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as a:
 for n in names:a.add(repo/n,arcname=n)
changed=subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=repo,text=True).splitlines();production=[n for n in changed if n.startswith('src/Lokad.Lython/')];assert len(production)==4,production
(r/'correction.patch.gz').write_bytes(gzip.compress(subprocess.check_output(['git','diff','HEAD','--']+production+['tests/Lokad.Lython.Tests/InstructionFailureRoutingTests.cs'],cwd=repo),mtime=0))
identity=dict(referenceSource='Committed7db1de02/frozenc0367d98, full44247104176 failed original failure-routing regressions; not qualified',candidateSource='Correct interrupted local/discard result consumer routing through original instruction entry; shared existing cancellation/refusal predicate, no new authority. Both145internal/78public focused per framework. Full delivery pending.',imageFiles=images,sourceInputs=hashes,sourceInputsArchiveSHA256=sha(r/'candidate-sources.tar.xz'),productionFiles=587,changedProductionFiles=production,normalAdapterPin='0.4.0',publicationHeld=True)
(frozen/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
for n in ['catalog.json','measurement-catalog.json','candidate-allocation.json','candidate-preflight.json','candidate-measurement-preflight.json']:
 dest=n.replace('candidate-','reference-')if n.startswith('candidate-')else n;shutil.copyfile(prior/n,r/dest)
d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
for kind,cmd in [('preflight',[str(d),str(frozen/'candidate/Lokad.Lython.Benchmarks.dll'),'--compare','verify','--catalog',str(r/'catalog.json'),'--dotnet',str(d),'--python','C:/Python313/python.exe','--python-worker',str(repo/'benchmarks/cpython-worker.py'),'--out',str(r/'candidate-preflight.json')]),('allocation',[str(d),str(frozen/'candidate/ValidatedAllocation.dll'),str(frozen/'candidate'),str(r/'catalog.json'),str(r/'candidate-allocation.json')]),('measurement-preflight',[str(d),str(frozen/'candidate/Lokad.Lython.Benchmarks.dll'),'--compare','verify','--catalog',str(r/'measurement-catalog.json'),'--dotnet',str(d),'--python','C:/Python313/python.exe','--python-worker',str(repo/'benchmarks/cpython-worker.py'),'--out',str(r/'candidate-measurement-preflight.json')])]:
 with(r/('candidate-'+kind+'.log')).open('w',encoding='utf-8')as log:p=subprocess.run(cmd,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
 assert p.returncode==0,(r/('candidate-'+kind+'.log')).read_text(encoding='utf-8');print(kind,'passed',flush=True)
print('Frozen corrected source:',images['candidate']['Lokad.Lython.dll'],flush=True)
