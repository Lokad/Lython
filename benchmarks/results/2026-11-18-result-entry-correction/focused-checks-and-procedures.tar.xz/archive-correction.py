from pathlib import Path
import gzip,json,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');prior=r.parent/'discarded-results-r516';out=repo/'benchmarks/results/2026-11-18-result-entry-correction';out.mkdir(exist_ok=False)
for n in ['candidate-sources.tar.xz','correction.patch.gz','candidate-allocation.json','candidate-preflight.json','candidate-measurement-preflight.json']:shutil.copyfile(r/n,out/n)
shutil.copyfile(r/'frozen/identity.json',out/'frozen-identity.json')
(out/'candidate-core.dll.gz').write_bytes(gzip.compress((r/'frozen/candidate/Lokad.Lython.dll').read_bytes(),mtime=0))
failed=out/'failed-delivery';failed.mkdir()
for n in ['terminal.json','inputs.json','inputs.tar.xz','failed-run-logs.zip']:shutil.copyfile(prior/'delivery'/n,failed/n)
(failed/'README.md').write_text('''# Original full qualification failure

Run 44247104176, committed 7db1de02, Windows/Ubuntu: eight existing
InstructionFailureRoutingTests failed on each platform. Cancellation/admission
raised by the next instruction entry incorrectly acquired producer-operation
Python context when result forwarding performed that check inside the producer.
Full downstream qualification did not run; this run is never treated as green.
Inputs and complete logs are retained; no assertions were weakened.
''',encoding='utf-8',newline='\n')
with tarfile.open(out/'focused-checks-and-procedures.tar.xz','w:xz')as a:
 for p in sorted(r.rglob('*')):
  if p.is_file()and not any(x in p.relative_to(r).parts for x in ['frozen','quiet'])and p.suffix in ['.py','.log','.json']:a.add(p,arcname=p.relative_to(r).as_posix())
 for p in prior.glob('corrected-*'):a.add(p,arcname='checks/'+p.name)
(out/'README.md').write_text('''# Result-consumer entry failure correction

R518, 2026-11-18 UTC. Corrected frozen **84b1a159** versus failed full-delivery
**7db1de02 / c0367d98**. Both local stores and discarded results use the existing
consumer continuation when cancellation/refusal is already pending. The normal
instruction entry reports the error outside the producer's operation handler.
Running consumers use the same nonthrowing predicate; no new authority/counter.
Pending cleanup, first refusal identity, origin/context and side-effect order remain.

Original full failure is retained in [failed-delivery](failed-delivery/README.md).
Assigned-result cases now join the existing discarded-result regressions. Both
actual .NET 11/10 pass 145 internal / 78 public focused Release checks, including
24 routing cases per framework. Nonincremental solution build, 13 independent
goldens/allocation/budget reuse and the exact four timed-case goldens pass.
Full replacement delivery and the short affected/control timing comparison are
pending. This correctness repair has no performance claim. No public API change.

[Exact source](candidate-sources.tar.xz), [identity](frozen-identity.json),
[patch](correction.patch.gz), [checks/procedures](focused-checks-and-procedures.tar.xz).
Earlier c036 timings remain specific to that revision. Publication postponed.
''',encoding='utf-8',newline='\n')
print('Archived corrected source/focused checks and original failed full run; no full qualification inferred.')
