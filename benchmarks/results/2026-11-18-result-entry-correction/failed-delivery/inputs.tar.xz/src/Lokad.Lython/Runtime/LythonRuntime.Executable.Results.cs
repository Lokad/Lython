using Lokad.Lython.Frontend;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal sealed partial class ExecutionContext
    {
        private void PublishInstructionResult(in ExecutableInstruction instruction, object value)
            => PublishInstructionResult(ref _execution, this, instruction, value);

        private void PublishInstructionResult(in ExecutableInstruction instruction, ExecutableSlot value)
            => PublishInstructionResult(ref _execution, this, instruction, value);

        private static void PublishInstructionResult(ref ExecutableWorkState execution,
            ExecutionContext? invocation, in ExecutableInstruction instruction, object value)
            => PublishInstructionResult(ref execution, invocation, instruction, ExecutableSlot.FromObject(value));

        private static void PublishInstructionResult(ref ExecutableWorkState execution,
            ExecutionContext? invocation, in ExecutableInstruction instruction, ExecutableSlot value)
        {
            if (!instruction.HasResultConsumer)
            {
                execution.Stack.PublishSlot(instruction.ResultSlot, instruction.LiveExtent, value);
            }
            else CompleteResultConsumer(ref execution, invocation, instruction, value);
        }

        private static void CompleteResultConsumer(ref ExecutableWorkState execution,
            ExecutionContext? invocation, in ExecutableInstruction instruction, ExecutableSlot value)
        {
            // Preserve the original input retirement and its disposal order.
            // Pending cleanup must finish before the consumer becomes visible;
            // the unchanged driver and following consumer already implement that.
            if (instruction.LiveExtent < execution.Stack.LiveExtent) execution.Stack.RetireTo(instruction.LiveExtent);
            if (execution.Stack.HasPendingDisposals)
            {
                execution.Stack.PublishSlot(instruction.ResultSlot, instruction.LiveExtent, value);
                return;
            }

            execution.Stack.ForgetResultInput(instruction.ResultSlot);
            ref readonly var consumer = ref execution.Code.Instructions[execution.InstructionIndex + 1];
            execution.Stack.CheckExecution(consumer.Span);
            if (consumer.OpCode == ExecutableOpCode.StoreLocal)
                StoreLocalValue(execution.Code, execution.Locals, invocation, consumer.LocalSlot, value, consumer.Span);
            else if (consumer.OpCode != ExecutableOpCode.PopTop)
                throw new InvalidOperationException("Invalid prepared result consumer.");
            // Discarded calls cannot return private iteration loans. No
            // publication or scalar materialization is needed for their result.
            else if (value.IsUnassigned) _ = value.Object.RequireNotNull();
            execution.InstructionIndex++;
        }
    }
}
