from pathlib import Path
lab=Path(__file__).resolve().parent
donor=lab.parent/'class-delivery-cpython'
def make(name, replacements):
    text=(donor/name).read_text(encoding='utf-8-sig')
    for before,after in replacements:
        assert before in text,before
        text=text.replace(before,after)
    compile(text,name,'exec')
    (lab/name).write_text(text,encoding='utf-8',newline='\n')
make('prepare.py', [
    ("'executable-class-suites/reuse-confirmation'","'single-lexical-class-cells'"),
    ('53d3b45d5','f65be4da5'), ('class-delivery-cpython','lexical-delivery-cpython'),
    ('Executable class delivery against stock CPython','Lexical class-cell delivery against stock CPython'),
    ('1196','1200'), ("seconds=225","seconds=225"),
])
make('archive.py',[
    ('2026-11-20-cpython-executable-classes','2026-11-20-cpython-lexical-class-cells'),
    ('2026-11-20-executable-class-suites/refinement','2026-11-20-lexical-class-cells'),
    ('B1196','B1200'),
])
