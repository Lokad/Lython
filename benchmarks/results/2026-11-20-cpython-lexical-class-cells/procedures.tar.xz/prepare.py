from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
trial=lab.parent/'single-lexical-class-cells'
quiet=trial/'quiet'
template=lab.parent/'named-shipment-cpython'
read=lambda p:p.read_text(encoding='utf-8-sig')
load=lambda p:json.loads(read(p))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],encoding='utf-8').strip()
root='/home/lokad/lython-bench-checks/lexical-delivery-cpython-b1200-20261120'
unit='lython-b1200-lexical-delivery-cpython-20261120'
def write(name,s):
    if name.endswith('.py'):ast.parse(s)
    (lab/name).write_text(s,encoding='utf-8',newline='\n')
def save(name,v):write(name,json.dumps(v,indent=2)+'\n')
pair=load(trial/'frozen-identity.json')
commit=git('rev-parse','HEAD')
assert commit.startswith('f65be4da5')
assert not git('diff','--name-only',pair['candidateCommit'],commit,'--','src','tests','benchmarks/Lokad.Lython.Benchmarks',
               'benchmarks/cpython-worker.py','global.json','Directory.Build.props','Directory.Packages.props')
files=pair['images']['candidate']
image=lab/'frozen/candidate'
image.mkdir(parents=True,exist_ok=False)
for n in files:shutil.copyfile(trial/'frozen/candidate'/n,image/n)
assert len(files)==32 and {n:sha(image/n)for n in files}==files
donor=load(quiet/'config.json')
receipt=load(quiet/'archive-receipt.json')
assert receipt['complete']and receipt['archivedAndVerifiedUnderLease']and sha(quiet/'observations.tgz')==receipt['archiveSHA256']
assert files==donor['identity']['imageFiles']['candidate']
for source,target in [(trial/'catalog.json','representative.json'),(trial/'candidate-verify.json','verify.json'),
                      (Path('benchmarks/cpython-worker.py'),'cpython-worker.py')]:
    shutil.copyfile(source,lab/target)
catalog_sha=sha(lab/'representative.json')
worker_sha=sha(lab/'cpython-worker.py')
assert load(lab/'verify.json')['state']=='Completed'
assert catalog_sha==pair['casesSHA256']==load(lab/'verify.json')['catalogSha256']
assert worker_sha==donor['protocolSHA256']
core=files['Lokad.Lython.dll']
ids=['scripts.dataclass-inherited-configuration.generated','scripts.annotated-rule-closures','scripts.csv-invoice.large']
assert all(case in {v['id'] for v in load(lab/'representative.json')['cases']}for case in ids)
identity=dict(sourceRevision=commit,imageSource=pair['candidateCommit'],purpose='Lexical class-cell delivery against stock CPython',
    imageFiles={'candidate':files},auxiliaryFiles={n:h for n,h in files.items()if n!='Lokad.Lython.dll'},
    coreSHA256={label:core for label in ('candidate','candidate-control')},catalogSHA256=catalog_sha,
    cpythonWorkerSHA256=worker_sha)
save('identity.json',identity)
save('build-revision.json',dict(sourceRevision=commit,imageSource=pair['candidateCommit'],coreSHA256=core))
old=load(template/'config.json')
for name in ('collect.py','archive-owned.py','launch.py','retrieve.py','run.sh'):
    s=read(template/name).replace(old['root'],root).replace(old['unit'],unit).replace('B1190','B1200')
    if name=='collect.py':
        a=s.index('    for case_id,diagnostic in ');b=s.index('\n',a)
        s=s[:a]+f'    for case_id,diagnostic in {[(key,False) for key in ids]!r}:'+s[b:]
        s=s.replace('if case_id == "scripts.csv-invoice.large"','if case_id != "scripts.dataclass-inherited-configuration.generated"')
        s=s.replace('(3 if lane==\'compile\' else 6 if lane==\'warm\' else 4)',
                    '(4 if lane==\'compile\' else 8 if lane==\'warm\' else 6)')
        s=s.replace('n*.25/max','n*.4/max')
    if name=='launch.py':
        s=s.replace('seconds=220','seconds=225').replace('before 220','before 225').replace('shipment report comparison','class delivery comparison')
    write(name,s)
assert b'\r' not in (lab/'run.sh').read_bytes()
members=('identity.json','collect.py','archive-owned.py','run.sh','cpython-worker.py')
with tarfile.open(lab/'payload.tgz','w:gz')as archive:
    for name in members:archive.add(lab/name,arcname=name)
config=dict(root=root,unit=unit,source=donor['root'],sourceRole='candidate',sourceFiles=files,
    sourceCatalogSHA256=donor['catalogSHA256'],catalogSHA256=catalog_sha,identity=identity,retireGroups=[],
    donorArchiveSHA256=receipt['archiveSHA256'],payloadBytes=(lab/'payload.tgz').stat().st_size,
    payloadSHA256=sha(lab/'payload.tgz'),unpackedBytes=sum((lab/n).stat().st_size for n in members),
    cpythonWorkerSHA256=worker_sha)
save('config.json',config)
s=read(template/'remote-launch.py')
a=s.index('\nc=')+1;b=s.index('\nb=Path(')
s=s[:a]+'c='+repr(config)+s[b:]
s=s.replace('lython-b1190-fixtures','lython-b1200-fixtures')
s=s.replace('+1835008,(before','+64*1024*1024,(before')
write('remote-launch.py',s)
print('Verified current-source 32-file image, original catalog and CPython goldens.')
