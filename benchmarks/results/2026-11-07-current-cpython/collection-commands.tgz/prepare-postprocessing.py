from pathlib import Path
import ast,shutil
root=Path(__file__).parent;old=root.parent/'delivery-comparison-b367'
s=(old/'retrieve.py').read_text(encoding='utf-8').replace('delivery-comparison-b367-20261106','delivery-comparison-b373-20261107').replace('lython-b367-delivery-comparison-20261106','lython-b373-delivery-comparison-20261107')
ast.parse(s);(root/'retrieve.py').write_text(s,encoding='utf-8')
for name in ['summarize.py','representative.json']:shutil.copyfile(old/name,root/name)
