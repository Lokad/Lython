from pathlib import Path
import json,subprocess
root=Path(__file__).parent
s=(root/'retire-expanded-command.py').read_text(encoding='utf-8')
s=s[:s.index(' targets=[]')]+''' rows=[]
 for relative,check in checks.items():
  p=root/relative
  rows.append(dict(path=relative,exists=p.exists(),isSymlink=p.is_symlink(),links=p.stat().st_nlink if p.exists() else None,bytes=p.stat().st_size if p.exists() else None,resolved=str(p.resolve())))
 print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,files=rows),indent=2))
'''
(root/'inspect-retirement-command.py').write_text(s,encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run([*ssh,'python3 -'],input=s,text=True,encoding='utf-8',capture_output=True)
(root/'retirement-inspection.json').write_text(p.stdout,encoding='utf-8');assert p.returncode==0,p.stderr
r=json.loads(p.stdout);print('Free',r['freeBytes']);print([(v['path'],v['exists'],v['links'],v['bytes']) for v in r['files']],flush=True)
