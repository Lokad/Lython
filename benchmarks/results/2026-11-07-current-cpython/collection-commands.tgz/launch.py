from pathlib import Path
import fcntl,hashlib,io,json,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=Path('/home/lokad/lython-bench-checks/delivery-comparison-b373-20261107');prior=Path('/home/lokad/lython-bench-checks/csv-record-values-b372-20261107')
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(38927+1);assert len(payload)==38927 and hashlib.sha256(payload).hexdigest()=='87a79d821dea0cc3921d3f17e19e75890eefe250f2ede31b19d7ee46985f9a56'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  assert shutil.disk_usage(base).free>sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+128*1024+8*1024*1024
  root.mkdir();a.extractall(root,filter='data')
 for name in ['candidate','cpython-worker.py','source.patch']:(root/name).symlink_to(prior/name,target_is_directory=(prior/name).is_dir())
 (root/'representative.json').symlink_to(base/'delivery-comparison-b367-20261106/representative.json')
 identity=json.loads((root/'identity.json').read_text())
 assert hashlib.sha256((root/'candidate/Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256']['candidate']
 for name,digest in identity['auxiliaryFiles'].items():assert hashlib.sha256((root/'candidate'/name).read_bytes()).hexdigest()==digest
 cases={c['id'] for c in json.loads((root/'representative.json').read_text())['cases']}
 assert cases=={'scripts.csv-summary-functions.large','scripts.text-summary-helpers.large','scripts.json-summary-helpers.large','scripts.report-render.large','scripts.config-edit.small'}
 for name in ['collect.py','archive-owned.py']:compile((root/name).read_text(),str(root/name),'exec')
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,allFifteenJobsValidated=True,coreSHA256=identity['coreSHA256']['candidate'])),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b373-delivery-comparison-20261107','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=420','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
