from pathlib import Path
import ast,datetime,hashlib,json,shutil,subprocess,tarfile
root=Path(__file__).parent;prior_local=root.parent/'delivery-comparison-b367';recent=root.parent/'csv-record-values-r25/b372'
remote='/home/lokad/lython-bench-checks/delivery-comparison-b373-20261107';prior='/home/lokad/lython-bench-checks/csv-record-values-b372-20261107'
def write(name,s):
    (root/name).write_text(s,encoding='utf-8',newline='\n')
identity=json.loads((recent/'identity.json').read_text(encoding='utf-8'))
actual={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('src/Lokad.Lython').rglob('*.cs') if not {'bin','obj'}.intersection(p.parts)}
assert actual==identity['sourceSHA256']
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='01aedc3b144ac26f56aae1ee1a3fc9be987f6d8f'
identity.update(sourceRevision=head+'; frozen measured core0933d540 from identical production source',purpose='Representative CPython checkpoint after R22/R23/R25; compile/warm/fresh separated, not causal per-change attribution')
identity['coreSHA256']={k:identity['coreSHA256'][k] for k in ['candidate','control']};identity.pop('referenceSourceRevision',None)
primary=json.loads((prior_local/'representative.json').read_text(encoding='utf-8'))
current={c['id']:c for c in json.loads((recent/'representative.json').read_text(encoding='utf-8'))['cases']}
assert len(primary['cases'])==5
for case in primary['cases']:
    for key in ['sourceSha256','fixtureSha256','expectedOutputSha256','expectedFilesSha256']:
        assert case.get(key)==current[case['id']].get(key),(case['id'],key)
write('identity.json',json.dumps(identity,indent=2)+'\n');shutil.copyfile('PLAN.md',root/'pre-measurement-plan.md')
write('contract.md','Existing fifteen compile/warm/compile-to-result jobs, five complete scripts, CPython3.13.16/current/identical current, normal GC/tiering.5s warmups/role, seven rotated150ms rounds. Exact Ready images, full goldens, quiet endpoints, terminal budgets, Closed/joins, fixture cleanup and verified persistent under-lease archive required. Compile excludes execution/I/O. Warm/fresh include mediated RAM I/O, validation and prior-result cleanup; fresh adds compilation/program disposal. Startup/staging/reset/final cached teardown excluded. No startup/RSS/suspended-I/O claim, subtraction of independent medians or causal per-change gain. Source01aedc3b: focused and installed consumers pass, R25 platform/Stress delivery42319704404 pending.420sowner+30sstop+10smargin: no SSH before460s after acknowledged launch. Preserve adverse/missing/failed evidence. No new benchmark framework or producer qualification.\n')
write('setup-contract.json',json.dumps(dict(image=prior+'/candidate',jobs=15,ownerSeconds=420,stopSeconds=30,observeAfterSeconds=460,previousCheckpointRawBytes=2517160,reason='Material completed CSV storage plus provider/builtin ownership changes since4fad63c5. Reuse existing catalog/images; primary guide remains historical until actual results and qualification are recorded.'),indent=2)+'\n')
for name in ['collect.py','archive-owned.py','run.sh']:
    s=(prior_local/name).read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/delivery-comparison-b367-20261106',remote)
    if name=='collect.py':
        start=s.index("purpose='")+len("purpose='");end=s.index("',",start);s=s[:start]+identity['purpose']+s[end:]
    if name.endswith('.py'):ast.parse(s)
    write(name,s)
with tarfile.open(root/'payload.tgz','w:gz') as a:
    for name in ['identity.json','pre-measurement-plan.md','setup-contract.json','contract.md','collect.py','archive-owned.py','run.sh']:a.add(root/name,arcname=name)
payload=(root/'payload.tgz').read_bytes()
script=r'''from pathlib import Path
import fcntl,hashlib,io,json,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=Path('REMOTE');prior=Path('PRIOR')
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(PAYLOADBYTES+1);assert len(payload)==PAYLOADBYTES and hashlib.sha256(payload).hexdigest()=='PAYLOADHASH'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  assert shutil.disk_usage(base).free>sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+128*1024+8*1024*1024
  root.mkdir();a.extractall(root,filter='data')
 for name in ['candidate','cpython-worker.py','source.patch']:(root/name).symlink_to(prior/name,target_is_directory=(prior/name).is_dir())
 (root/'representative.json').symlink_to(base/'delivery-comparison-b367-20261106/representative.json')
 identity=json.loads((root/'identity.json').read_text())
 assert hashlib.sha256((root/'candidate/Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256']['candidate']
 for name,digest in identity['auxiliaryFiles'].items():assert hashlib.sha256((root/'candidate'/name).read_bytes()).hexdigest()==digest
 cases={c['id'] for c in json.loads((root/'representative.json').read_text())['cases']}
 assert cases=={'scripts.csv-summary-functions.large','scripts.text-summary-helpers.large','scripts.json-summary-helpers.large','scripts.report-render.large','scripts.config-edit.small'}
 for name in ['collect.py','archive-owned.py']:compile((root/name).read_text(),str(root/name),'exec')
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 print(json.dumps(dict(freeBytes=shutil.disk_usage(base).free,allFifteenJobsValidated=True,coreSHA256=identity['coreSHA256']['candidate'])),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b373-delivery-comparison-20261107','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=420','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
'''.replace('REMOTE',remote).replace('PRIOR',prior).replace('PAYLOADBYTES',str(len(payload))).replace('PAYLOADHASH',hashlib.sha256(payload).hexdigest())
ast.parse(script);write('launch.py',script)
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15']
p=subprocess.run(['C:/Windows/System32/OpenSSH/scp.exe',*ssh[1:],str(root/'launch.py'),'lokad@20.166.121.73:/home/lokad/lython-bench-checks/b373-launch.py'],capture_output=True);assert p.returncode==0,p.stderr
p=subprocess.run([*ssh,'lokad@20.166.121.73','python3 /home/lokad/lython-bench-checks/b373-launch.py'],input=payload,capture_output=True)
(root/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode('utf-8')
bound=datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(seconds=460)
write('observe-not-before.json',json.dumps(dict(utc=bound.isoformat(),delayAfterAcknowledgementSeconds=460),indent=2)+'\n')
print((p.stdout+p.stderr).decode('utf-8'),flush=True);print('No VM access before',bound.isoformat(),flush=True)
