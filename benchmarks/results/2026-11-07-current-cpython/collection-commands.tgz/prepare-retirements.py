from pathlib import Path
import ast
root=Path(__file__).parent;original=(root.parent/'csv-record-values-r25/retire-expanded-profile.py').read_text(encoding='utf-8')
cases=[('b370','benchmarks/results/2026-11-07-current-script-cpu/b370-failed-observations.tgz','current-cpu-b370-20261107','perf/','perf','failed-observations.tgz'),
       ('b372','benchmarks/results/2026-11-07-csv-record-values/b372-observations.tgz','csv-record-values-b372-20261107','confirmation/','confirmation','observations.tgz')]
for name,archive,remote,prefix,folder,remote_archive in cases:
    target=root/(name+'-retirement');target.mkdir()
    s=original.replace('benchmarks/results/2026-11-07-current-script-cpu/observations.tgz',archive).replace('current-cpu-b371-20261107',remote)
    s=s.replace("member.name.startswith('perf/')",f"member.name.startswith('{prefix}')").replace("root/'perf' in p.parents",f"root/'{folder}' in p.parents")
    s=s.replace("(root/'observations.tgz').read_bytes()",f"(root/'{remote_archive}').read_bytes()")
    ast.parse(s);(target/'retire-expanded-profile.py').write_text(s,encoding='utf-8')
