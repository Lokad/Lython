from pathlib import Path
import fcntl,hashlib,json,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks');root=base/'current-cpu-b370-20261107';checks={'perf/text-warm/perf.map': {'bytes': 1351680, 'sha256': 'e1f75744d73f654067b89e15d6b541f409c1fed349ffb6265d26f2e714a014e3'}, 'perf/text-warm/worker.stderr': {'bytes': 0, 'sha256': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'}, 'perf/text-warm/perf.data': {'bytes': 178248, 'sha256': '584da3d6b43918c05b32bf64003da1a8d986ca20d625f314a7fe9a43a69901a1'}, 'perf/text-warm/perf-report.txt': {'bytes': 143, 'sha256': '548cbcc85bb9a40d0bd1ef8c96e05825b124eafd59299ae4dbc3d20c5d8c4cb7'}, 'perf/text-warm/collector.log': {'bytes': 237, 'sha256': '43b08566bb182022572970b319dc84b38e428a6e50e9ce3b3634be3e889f4175'}, 'perf/text-warm/record.json': {'bytes': 904635, 'sha256': '389e4cc8f62d289d00119630e40c20b41eb0670d65510a98c80b01dc0d737a50'}, 'perf/text-warm/stop': {'bytes': 0, 'sha256': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'}}
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert hashlib.sha256((root/'failed-observations.tgz').read_bytes()).hexdigest()=='addaf2e3f50fd3c8647e6b8c0c62f354ba0b2eb0926704604903fdb13e5c9a88'
 targets=[]
 for relative,check in checks.items():
  p=root/relative
  assert p.resolve()==p and root/'perf' in p.parents and p.is_file() and p.stat().st_nlink==1
  assert p.stat().st_size==check['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==check['sha256']
  targets.append(p)
 assert not [p for p in base.rglob('*') if p.is_symlink() and p.resolve() in targets]
 # Retire exact expanded regular files only, after both independent archives,
 # every hash and all dependencies/users have been verified. Keep raw archive.
 for p in targets:p.unlink()
 print(json.dumps(dict(retiredExpandedFiles=checks,independentCommittedArchive='benchmarks/results/2026-11-07-current-script-cpu/b370-failed-observations.tgz',archiveSHA256='addaf2e3f50fd3c8647e6b8c0c62f354ba0b2eb0926704604903fdb13e5c9a88',allUsersEnded=True,noSymlinkDependencies=True,freeBytes=shutil.disk_usage(base).free),indent=2))
