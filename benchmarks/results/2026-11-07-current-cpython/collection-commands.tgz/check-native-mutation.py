from pathlib import Path
import os,subprocess
root=Path(__file__).parent.parent/'native-single-pass-r26';root.mkdir(exist_ok=True)
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
project='tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj'
with (root/'mutation-probe-build.log').open('w',encoding='utf-8') as output:
    p=subprocess.run([env['DOTNET_HOST_PATH'],'build',project,'-c','Release','--no-restore','--nologo','--tl:off'],env=env,stdout=output,stderr=subprocess.STDOUT)
assert p.returncode==0,(root/'mutation-probe-build.log').read_text(encoding='utf-8')[-1800:]
with (root/'mutation-probe-net11.0.log').open('w',encoding='utf-8') as output:
    p=subprocess.run([env['DOTNET_HOST_PATH'],'test',project,'-c','Release','-f','net11.0','--no-build','--no-restore','--nologo','--tl:off','--filter','FullyQualifiedName~FormattedHelperReadsAnUpdatedMethodReceiverAfterAdmission'],env=env,stdout=output,stderr=subprocess.STDOUT)
print(p.returncode,(root/'mutation-probe-net11.0.log').read_text(encoding='utf-8')[-2200:],flush=True)
raise SystemExit(p.returncode)
