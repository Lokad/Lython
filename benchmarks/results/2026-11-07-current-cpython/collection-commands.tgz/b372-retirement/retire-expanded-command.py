from pathlib import Path
import fcntl,hashlib,json,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks');root=base/'csv-record-values-b372-20261107';checks={'confirmation/confirmation.json': {'bytes': 576569, 'sha256': 'bab2475a0218b88d9a54a6adea841664e82c6fb1d8741ec0daf3c9a67944516a'}, 'confirmation/fixture-filesystem.txt': {'bytes': 78, 'sha256': 'f2007fcedaf0603f0b911e6574d2a8ca03d21e11df56f506e422238b2cc9fb04'}, 'confirmation/machine-after.json': {'bytes': 11099, 'sha256': '1d44f37216ef9b722b66355b00bcf05e51ef3776d0f3ae91ac88b7af65d8ab11'}, 'confirmation/machine-before.json': {'bytes': 11117, 'sha256': '79bcbf21a232b89b6f41adf0d53fddd3e6f97b2f9b145f2e48590276eae97df0'}}
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest()=='a2959012c78c445f04f3b8d259d8d753c3e8f0a7bcadf47d0d44a15f27ef8676'
 targets=[]
 for relative,check in checks.items():
  p=root/relative
  assert p.resolve()==p and root/'confirmation' in p.parents and p.is_file() and p.stat().st_nlink==1
  assert p.stat().st_size==check['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==check['sha256']
  targets.append(p)
 assert not [p for p in base.rglob('*') if p.is_symlink() and p.resolve() in targets]
 # Retire exact expanded regular files only, after both independent archives,
 # every hash and all dependencies/users have been verified. Keep raw archive.
 for p in targets:p.unlink()
 print(json.dumps(dict(retiredExpandedFiles=checks,independentCommittedArchive='benchmarks/results/2026-11-07-csv-record-values/b372-observations.tgz',archiveSHA256='a2959012c78c445f04f3b8d259d8d753c3e8f0a7bcadf47d0d44a15f27ef8676',allUsersEnded=True,noSymlinkDependencies=True,freeBytes=shutil.disk_usage(base).free),indent=2))
