from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess
r=Path(__file__).resolve().parent/'refined';old=r.parent.parent/'scalar-index-r453'
dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe')
env=os.environ.copy();env['DOTNET_ROOT']=str(dotnet.parent);env['DOTNET_ROOT_X64']=str(dotnet.parent);env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
identity=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))
for role in ['reference','candidate']:
 image=r/'frozen'/role
 for n,h in identity['imageFiles'][role].items():assert hashlib.sha256((image/n).read_bytes()).hexdigest()==h,n
 out=r/f'preflight-{role}.json';assert not out.exists()
 command=[str(dotnet),str(image/'Lokad.Lython.Benchmarks.dll'),'--compare','verify','--catalog',str(r/'catalog.json'),'--dotnet',str(dotnet),'--python','C:/Python313/python.exe','--python-worker',str(old/'quiet/retrieved/cpython-worker.py'),'--out',str(out)]
 with (r/f'preflight-{role}.log').open('w',encoding='utf-8')as log:done=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT)
 assert done.returncode==0,(role,(r/f'preflight-{role}.log').read_text(encoding='utf-8'))
 print(role,'six-case supervised CPython verification passed',flush=True)
for role in ['reference','candidate']:
 image=r/'allocation-short'/role;image.mkdir(parents=True,exist_ok=False)
 for p in (r/'frozen'/role).iterdir():shutil.copy2(p,image/p.name)
 for p in (old/'allocation-short/reference').glob('ValidatedAllocation.*'):shutil.copy2(p,image/p.name)
 out=r/'allocation-short'/f'{role}.json'
 with (r/'allocation-short'/f'{role}.log').open('w',encoding='utf-8')as log:done=subprocess.run([str(dotnet),str(image/'ValidatedAllocation.dll'),str(image),str(r/'catalog.json'),str(out)],env=env,stdout=log,stderr=subprocess.STDOUT)
 assert done.returncode==0,(role,(r/'allocation-short'/f'{role}.log').read_text(encoding='utf-8'))
 print(role,'six-case natural-GC allocation diagnostics completed',flush=True)
reference=json.loads((r/'allocation-short/reference.json').read_text(encoding='utf-8'));candidate=json.loads((r/'allocation-short/candidate.json').read_text(encoding='utf-8'))
rows=[]
for a,b in zip(reference['rows'],candidate['rows']):
 assert a['id']==b['id']and a['sharedBudgetBaselineRestored']and b['sharedBudgetBaselineRestored']
 av=statistics.median(a['allocatedBytesPerInvocation']);bv=statistics.median(b['allocatedBytesPerInvocation'])
 rows.append(dict(id=a['id'],referenceBytes=av,candidateBytes=bv,changePercent=100*(bv/av-1),referencePeak=a['peakExecutionMemoryBytes'],candidatePeak=b['peakExecutionMemoryBytes']))
(r/'allocation-summary.json').write_text(json.dumps(dict(rows=rows,boundary=reference['boundary'],CPUOrElapsedClaim=False),indent=2)+'\n',encoding='utf-8')
print(json.dumps(rows,indent=2))
