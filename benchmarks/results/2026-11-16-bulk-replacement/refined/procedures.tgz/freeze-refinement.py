from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
repo=Path('D:/code/Lython');w=repo/'.git/agent-worktrees/bulk-replacement-r455';r=Path(__file__).resolve().parent;out=r/'refined';f=out/'frozen';f.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert '0 Error(s)'in(out/'nonincremental-core.log').read_text(encoding='utf-8')
old=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))
for role in ['reference','candidate']:
 (f/role).mkdir()
 for n,h in old['imageFiles']['reference'].items():
  p=r/'frozen/reference'/n;assert sha(p)==h;shutil.copy2(p,f/role/n)
core=w/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll';h=sha(core)
for project in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:assert sha(w/'tests'/project/'bin/Release/net11.0/Lokad.Lython.dll')==h,project
shutil.copy2(core,f/'candidate/Lokad.Lython.dll')
paths=subprocess.check_output(['git','ls-files','src','tests','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','NuGet.Config','global.json','Lokad.Lython.slnx'],cwd=w,text=True,encoding='utf-8').splitlines()
inputs={p:sha(w/p)for p in paths};production={p:h for p,h in inputs.items()if p.startswith('src/Lokad.Lython/')};assert len(production)==585
images={role:{p.name:sha(p)for p in(f/role).iterdir()}for role in ['reference','candidate']};assert[n for n in images['reference']if images['reference'][n]!=images['candidate'][n]]==['Lokad.Lython.dll']
identity=dict(referenceSource=old['referenceSource'],candidateSource='Private single-pass R455 refinement at9ee6552d+archived shared construction; original two-pass adversity preserved separately',imageFiles=images,sourceInputs=inputs,productionFiles=len(production),catalogSHA256=sha(r/'catalog.json'),normalAdapterPin='0.4.0',fullQualification=False,publicationHeld=True)
(f/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8');shutil.copy2(r/'catalog.json',out/'catalog.json')
with tarfile.open(out/'candidate-sources.tar.xz','w:xz')as a:
 for p in paths:a.add(w/p,arcname=p)
patch=subprocess.check_output(['git','diff','--','src','tests'],cwd=w);(out/'prototype.patch').write_bytes(patch)
print(json.dumps(dict(candidateCore=h,productionFiles=len(production),allInputs=len(inputs),onlyCoreDiffers=True)))
