from pathlib import Path
import ast,hashlib,io,json,subprocess,tarfile
repo=Path('D:/code/Lython');r=Path(__file__).resolve().parent/'refined';old=r.parent.parent/'scalar-index-r453';q=r/'quiet'
q.mkdir(exist_ok=False)
root='/home/lokad/lython-bench-checks/bulk-replacement-b859-20261116';unit='lython-b859-bulk-replacement-20261116'
frozen=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));c=json.loads((old/'quiet/config.json').read_text(encoding='utf-8'));base=frozen['imageFiles']['reference']
mappings=[(x['path'],x['canonical'],x['member'])for x in json.loads((r/'retirement-candidates.json').read_text(encoding='utf-8'))]+[('bulk-replacement-b858-20261116/confirmation/confirmation.json','benchmarks/results/2026-11-16-bulk-replacement/observations.tgz','confirmation/confirmation.json')]
proofs=[]
for path,canonical,member in mappings:
 blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes()
 data=blob
 if member:
  with tarfile.open(fileobj=io.BytesIO(blob))as a:data=a.extractfile(member).read()
 proofs.append(dict(paths=[path],bytes=len(data),links=1,sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True))
(r/'retirement-proof.json').write_text(json.dumps(proofs,indent=2)+'\n',encoding='utf-8')
identity=dict(sourceRevision='Fully qualified be176ed0/642f reference; private single-pass R455 at9ee6552d+archived refinement/'+frozen['imageFiles']['candidate']['Lokad.Lython.dll'][:8],purpose='R455 single-pass shared replacement construction refinement: complete text and binary normalization warm/fresh plus ordinary-call control. Allocation and CPU are separate claims.',imageFiles=frozen['imageFiles'],coreSHA256={label:frozen['imageFiles']['candidate'if label.startswith('candidate')else'reference']['Lokad.Lython.dll']for label in ['reference','reference-control','candidate','candidate-control']},auxiliaryFiles={n:h for n,h in base.items()if n!='Lokad.Lython.dll'},catalogSHA256=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest(),normalAdapterPin='0.4.0')
c.update(root=root,unit=unit,source='/home/lokad/lython-bench-checks/bulk-replacement-b858-20261116',sourceRole='reference',sourceFiles=base,sourceCatalogSHA256=identity['catalogSHA256'],catalogSHA256=identity['catalogSHA256'],retireGroups=proofs,identity=identity)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
jobs=[['scripts.text-normalization.large','warm'],['scripts.text-normalization.large','compile-run'],['scripts.binary-normalization.large','warm'],['scripts.binary-normalization.large','compile-run'],['calls.positional.large','warm']]
for name in ['collect.py','archive-owned.py','run.sh']:
 s=(old/'quiet'/name).read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/scalar-index-b856-20261116',root)
 if name=='collect.py':
  lines=s.splitlines();i=next(i for i,line in enumerate(lines)if line.startswith('jobs='));lines[i]='jobs='+repr(jobs);s='\n'.join(lines)+'\n';s=s.replace('len(jobs)==4','len(jobs)==5')
 if name=='archive-owned.py':s=s.replace("len(raw['jobs'])==4","len(raw['jobs'])==5").replace('jobs=4','jobs=5')
 (q/name).write_text(s,encoding='utf-8',newline='\n')
 if name.endswith('.py'):ast.parse(s)
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for name in ['collect.py','archive-owned.py','run.sh','identity.json']:a.add(q/name,arcname=name)
 a.add(r/'catalog.json',arcname='representative.json');a.add(r/'frozen/candidate/Lokad.Lython.dll',arcname='candidate/Lokad.Lython.dll')
with tarfile.open(q/'payload.tgz')as a:c['unpackedBytes']=sum(m.size for m in a.getmembers())
c.update(payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest());(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
s=(old/'quiet/remote-launch.py').read_text(encoding='utf-8');tree=ast.parse(s);node=next(n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='c'for t in n.targets));lines=s.splitlines(keepends=True);lines[node.lineno-1:node.end_lineno]=['c='+repr(c)+'\n'];s=''.join(lines).replace('lython-b856-fixtures','lython-b859-fixtures')
s=s.replace("os.link(source/'representative.json',root/'representative.json')","assert (root/'representative.json').is_file()  # New six-case catalog supplied in verified payload.")
ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'quiet/retrieve.py').read_text(encoding='utf-8').replace("['jobs']==4","['jobs']==5").replace('B856','B859');(q/'retrieve.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'launch.py').read_text(encoding='utf-8').replace('seconds=150','seconds=180').replace('150seconds','180seconds').replace('Four-job scalar-index','Five-job bulk replacement').replace('B856','B859');(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'summarize.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==4","len(raw['jobs'])==5");(r/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(dict(prepared=True,jobs=jobs,retiredBytesProved=sum(p['bytes']for p in proofs),unpackedBytes=c['unpackedBytes'],payloadBytes=c['payloadBytes'],onlyCoreChanges=True)))
