from pathlib import Path
import os,subprocess
r=Path(__file__).resolve().parent/'refined';w=Path('D:/code/Lython/.git/agent-worktrees/bulk-replacement-r455')
dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env['DOTNET_ROOT']=str(dotnet.parent);env['DOTNET_ROOT_X64']=str(dotnet.parent);env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
for label,project in [('public','Lokad.Lython.PublicApi.Tests'),('internal','Lokad.Lython.Tests')]:
 log=r/f'{label}-net10.log';assert not log.exists()
 command=[str(dotnet),'test',str(w/'tests'/project/(project+'.csproj')),'-c','Release','-f','net10.0','--filter',(r.parent/f'{label}-filter.txt').read_text(encoding='utf-8'),'--logger',f'trx;LogFileName=replacement-{label}-net10.trx','--results-directory',str(r)]
 with log.open('w',encoding='utf-8')as f:done=subprocess.run(command,cwd=w,env=env,stdout=f,stderr=subprocess.STDOUT)
 print(label,log.read_text(encoding='utf-8')[-1300:],flush=True);assert done.returncode==0
