from pathlib import Path
import base64,copy,hashlib,json,struct
r=Path(__file__).resolve().parent;old=r.parent/'scalar-index-r453'
assert not(r/'catalog.json').exists()
catalog=json.loads((old/'catalog.json').read_text(encoding='utf-8'))
template=next(c for c in catalog['cases']if c['id']=='scripts.text-normalization.large')
sha=lambda b:hashlib.sha256(b).hexdigest()
def digest(files):
 h=hashlib.sha256();h.update(struct.pack('>i',len(files)))
 for name,data in sorted(files.items()):
  key=name.encode('utf-8');h.update(struct.pack('>i',len(key)));h.update(key);h.update(struct.pack('>i',len(data)));h.update(data)
 return h.hexdigest()
fixture=json.loads(template['fixtureJson'])
assert digest({n:base64.b64decode(v)for n,v in fixture['outputFiles'].items()})==template['expectedFilesSha256']
data=base64.b64decode(fixture['inputFiles']['input.txt']);output=data.replace(b'\r\n',b'\n').replace(b'\r',b'\n')
c=copy.deepcopy(template)
source="with open('input.bin', 'rb') as source:\n    data = source.read()\ndata = data.replace(b'\\r\\n', b'\\n').replace(b'\\r', b'\\n')\nwith open('normalized.bin', 'wb') as target:\n    target.write(data)\nprint(len(data))\n"
f=dict(size=4096,text=None,inputFiles={'input.bin':base64.b64encode(data).decode('ascii')},outputFiles={'normalized.bin':base64.b64encode(output).decode('ascii')})
fj=json.dumps(f,ensure_ascii=False,separators=(',',':'));expected=str(len(output))+'\n'
c.update(id='scripts.binary-normalization.large',category='file-processing',scale='4096-lines',size=4096,source=source,fixtureJson=fj,expectedOutput=expected,sourceUtf8Bytes=len(source.encode('utf-8')),expectedOutputUtf8Bytes=len(expected.encode('utf-8')),fixtureTextUtf8Bytes=len(data),fixtureTextCodePoints=len(data.decode('utf-8')),sourceSha256=sha(source.encode('utf-8')),fixtureSha256=sha(fj.encode('utf-8')),expectedOutputSha256=sha(expected.encode('utf-8')),expectedFilesSha256=digest({'normalized.bin':output}))
catalog['cases'].append(c)
(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(r/'catalog-preparation.json').write_text(json.dumps(dict(newCase=c['id'],basis='Existing exact normalization fixture bytes; binary open/replace/write source; both frozen workers must verify against CPython before timing',inputBytes=len(data),outputBytes=len(output),records=4096,unchangedOriginalCases=5,catalogSHA256=sha((r/'catalog.json').read_bytes()),fullGoldens=True),indent=2)+'\n',encoding='utf-8')
print((r/'catalog-preparation.json').read_text(encoding='utf-8'))
