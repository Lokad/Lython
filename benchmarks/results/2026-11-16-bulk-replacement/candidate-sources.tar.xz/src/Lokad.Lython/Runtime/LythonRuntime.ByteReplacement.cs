namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    // Measure immutable input before admitting the one final result. Strings
    // insert at UTF-8 scalar boundaries; bytes insert between individual bytes.
    internal static int MeasureByteReplacement(ReadOnlySpan<byte> source, ReadOnlySpan<byte> oldValue,
        int newLength, int count, bool scalarBoundaries, ExecutionContext? context, LythonSourceSpan? span,
        out long replacements, out int firstMatch)
    {
        context?.CheckExecution(span);
        var limit = count < 0 ? long.MaxValue : count;
        replacements = 0;
        firstMatch = -1;
        if (oldValue.IsEmpty)
        {
            if (!scalarBoundaries) replacements = Math.Min((long)source.Length + 1, limit);
            else if (limit > 0)
            {
                replacements = 1;
                for (var offset = 0; offset < source.Length && replacements < limit; replacements++)
                {
                    context?.CheckExecution(span);
                    offset += ReplacementScalarWidth(source[offset]);
                }
            }
        }
        else
        {
            for (var offset = 0; replacements < limit;)
            {
                var found = FindBytes(source[offset..], oldValue, context, span);
                if (found < 0) break;
                if (firstMatch < 0) firstMatch = offset + found;
                offset += found + oldValue.Length;
                replacements++;
            }
        }
        context?.CheckExecution(span);
        var length = checked(source.Length + replacements * ((long)newLength - oldValue.Length));
        if (length > int.MaxValue)
            throw RuntimeErrors.Runtime(scalarBoundaries ? "string allocation is too large."
                : "byte buffer allocation is too large.", span);
        if ((ulong)length > (ulong)Array.MaxLength)
            throw RuntimeErrors.Memory("replacement result exceeds supported capacity", span);
        return (int)length;
    }

    internal static void WriteByteReplacement(ReadOnlySpan<byte> source, ReadOnlySpan<byte> oldValue,
        ReadOnlySpan<byte> newValue, Span<byte> output, long replacements, int firstMatch,
        bool scalarBoundaries, ExecutionContext? context, LythonSourceSpan? span)
    {
        var offset = 0;
        var written = 0;
        for (long index = 0; index < replacements; index++)
        {
            context?.CheckExecution(span);
            if (!oldValue.IsEmpty)
            {
                var found = index == 0 ? firstMatch : FindBytes(source[offset..], oldValue, context, span);
                if (found < 0) throw new InvalidOperationException("Replacement input changed after measurement.");
                CopyReplacementPart(source.Slice(offset, found), output, ref written, context, span);
                offset += found + oldValue.Length;
            }
            CopyReplacementPart(newValue, output, ref written, context, span);
            if (oldValue.IsEmpty && index + 1 < replacements)
            {
                var width = scalarBoundaries ? ReplacementScalarWidth(source[offset]) : 1;
                CopyReplacementPart(source.Slice(offset, width), output, ref written, context, span);
                offset += width;
            }
        }
        CopyReplacementPart(source[offset..], output, ref written, context, span);
        context?.CheckExecution(span);
        if (written != output.Length)
            throw new InvalidOperationException("Replacement output differs from its measured length.");
    }

    private static int ReplacementScalarWidth(byte lead)
        => lead < 0x80 ? 1 : lead < 0xe0 ? 2 : lead < 0xf0 ? 3 : 4;

    private static void CopyReplacementPart(ReadOnlySpan<byte> source, Span<byte> output, ref int written,
        ExecutionContext? context, LythonSourceSpan? span)
    {
        while (source.Length > 16384)
        {
            context?.CheckExecution(span);
            source[..16384].CopyTo(output[written..]);
            written += 16384;
            source = source[16384..];
        }
        source.CopyTo(output[written..]);
        written += source.Length;
    }
}
