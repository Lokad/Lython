using System.Numerics;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed class PyRange : IPyIterableValue, IPySliceableValue, IPySubscriptableValue, IPyRenderableValue, IPyTruthyValue, IPyHashableValue
{
    private readonly MemoryGovernor? _memoryGovernor;
    private readonly LythonSourceSpan? _allocationSpan;

    public PyRange(BigInteger start, BigInteger stop, BigInteger step)
    {
        Start = start;
        Stop = stop;
        Step = step;
    }

    public PyRange(BigInteger start,BigInteger stop,BigInteger step,MemoryGovernor governor,LythonSourceSpan? allocationSpan)
    {
        Start = start;
        Stop = stop;
        Step = step;
        _memoryGovernor = governor;
        _allocationSpan = allocationSpan;
    }

    public BigInteger Start { get; }
    public BigInteger Stop { get; }
    public BigInteger Step { get; }

    // Shell storage charge matching the range() factory below: the object slot plus
    // heap payloads of the retained bound limbs.
    internal long CommittedStorageBytes => 64L + BoundMagnitudeBytes(Start) + BoundMagnitudeBytes(Stop) + BoundMagnitudeBytes(Step);

    private static long BoundMagnitudeBytes(BigInteger bound)
        => RuntimeMemoryEstimates.GetMagnitudeBitLength(bound) > 64
            ? RuntimeMemoryEstimates.EstimateBigIntegerBytes(bound)
            : 0;

    private object OwnYield(BigInteger value)
    {
        object box = value;
        if (_memoryGovernor is not null)
        {
            LythonRuntime.OwnFreshInteger(box, _memoryGovernor, _allocationSpan);
        }

        return box;
    }
    public BigInteger Length => Step > 0
        ? Stop <= Start ? 0 : (Stop - Start - 1) / Step + 1
        : Stop >= Start ? 0 : (Start - Stop - 1) / -Step + 1;

    public bool IsTruthy() => Length != 0;

    // Equal ranges share length, start and (past singletons) step, so
    // hash exactly those components and nothing else.
    public int GetPyHashCode()
    {
        var hash = new HashCode();
        hash.Add(Length);
        if (!Length.IsZero)
        {
            hash.Add(Start);
            if (Length != BigInteger.One)
            {
                hash.Add(Step);
            }
        }

        return hash.ToHashCode();
    }

    public IEnumerable<object> Iterate() => new RangeValues(this);

    internal Enumerator GetEnumerator() => new(this);

    private sealed class RangeValues(PyRange range) : IEnumerable<object>
    {
        public IEnumerator<object> GetEnumerator() => range.GetEnumerator();
        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator() => GetEnumerator();
    }

    // One position serves ordinary object pulls and native machine pulls. Only
    // observing Current boxes a machine value; wider yields retain their eager
    // admission and publication. Each enumeration owns independent state.
    internal sealed class Enumerator : IEnumerator<object>
    {
        private readonly PyRange _range;
        private readonly long _machineStep;
        private long _machineValue;
        private ulong _remaining;
        private BigInteger _value;
        private object? _current;
        private bool _started;
        private bool _finished;

        internal Enumerator(PyRange range)
        {
            _range = range;
            HasMachineBounds = !range.Step.IsZero && range.Start.GetByteCount() <= sizeof(long)
                && range.Stop.GetByteCount() <= sizeof(long) && range.Step.GetByteCount() <= sizeof(long);
            if (HasMachineBounds)
            {
                _machineValue = (long)range.Start;
                _machineStep = (long)range.Step;
                // The distance between signed machine bounds fits UInt64.
                _remaining = (ulong)range.Length;
            }
        }

        internal bool HasMachineBounds { get; }
        internal long MachineValue => _machineValue;

        public object Current => !_started ? null! : _current ??= _range.OwnYield((BigInteger)_machineValue);
        object System.Collections.IEnumerator.Current => Current;
        public void Reset() => throw new NotSupportedException();
        public void Dispose() => _finished = true;

        public bool MoveNext()
        {
            if (_finished) return false;
            // Like the generated iterator's executing state, this also makes
            // reentrant pulls during major-yield admission terminal and prevents
            // retrying a failed pull. Publish only after admission succeeds.
            _finished = true;
            if (HasMachineBounds)
            {
                if (_remaining == 0) return false;
                if (_started) _machineValue = unchecked(_machineValue + _machineStep);
                // A successor exists only while it remains within the original
                // signed bounds. Do not compute a final out-of-range successor.
                _remaining--;
                _current = null;
            }
            else
            {
                var next = _started ? _value + _range.Step : _range.Start;
                if (_range.Step > 0 ? next >= _range.Stop : next <= _range.Stop) return false;
                var current = _range.OwnYield(next);
                _value = next;
                _current = current;
            }
            _started = true;
            _finished = false;
            return true;
        }
    }

    public object GetSubscript(object index, LythonSourceSpan span)
    {
        if (!Numbers.PyNumberOps.TryAsInteger(index, out var integer))
        {
            throw new LythonRuntimeException("TypeError", "range indices must be integers", span);
        }

        if (integer < 0)
        {
            integer += Length;
        }

        if (integer < 0 || integer >= Length)
        {
            throw new LythonRuntimeException("IndexError", "range object index out of range", span);
        }

        return OwnYield(Start + integer * Step);
    }

    public object GetSlice(object? start, object? end, object? step, LythonSourceSpan span)
    {
        var sliceStep = Bound(step, BigInteger.One, span);
        if (sliceStep == 0)
        {
            throw new LythonRuntimeException("ValueError", "slice step cannot be zero", span);
        }

        if (sliceStep < 0)
        {
            var sliceFrom = AdjustNegativeStart(start, span);
            var sliceTo = AdjustNegativeStop(end, span);
            var sliceLength = sliceFrom > sliceTo ? (sliceFrom - sliceTo - 1) / (-sliceStep) + 1 : BigInteger.Zero;
            var sliceNewStart = Start + sliceFrom * Step;
            return SliceRange(sliceNewStart, sliceNewStart + sliceLength * Step * sliceStep, Step * sliceStep);
        }

        if (sliceStep < 0)
        {
            throw new LythonRuntimeException("NotImplementedError", "negative range slice steps are not supported", span);
        }

        var from = Bound(start, BigInteger.Zero, span);
        var to = Bound(end, Length, span);
        if (from < 0) from = BigInteger.Max(BigInteger.Zero, from + Length);
        if (to < 0) to = BigInteger.Max(BigInteger.Zero, to + Length);
        from = BigInteger.Min(from, Length);
        to = BigInteger.Min(to, Length);
        var newStart = Start + from * Step;
        var newStop = Start + BigInteger.Max(from, to) * Step;
        return SliceRange(newStart, newStop, Step * sliceStep);
    }

    private PyRange SliceRange(BigInteger newStart, BigInteger newStop, BigInteger newStep)
    {
        if (_memoryGovernor is null)
        {
            return new PyRange(newStart, newStop, newStep);
        }

        var bytes = 64L + BoundMagnitudeBytes(newStart) + BoundMagnitudeBytes(newStop) + BoundMagnitudeBytes(newStep);
        _memoryGovernor.Reserve(bytes, _allocationSpan);
        _memoryGovernor.Commit(bytes);
        var child = new PyRange(newStart,newStop,newStep,_memoryGovernor,_allocationSpan);
        return child;
    }

    private BigInteger AdjustNegativeStart(object? value, LythonSourceSpan span)
    {
        // Mirror CPython slice.indices for negative steps: omitted starts
        // begin past the end, out-of-range values clamp inside.
        var bound = value is null || value is PyNone ? Length - 1 : Bound(value, BigInteger.Zero, span);
        if (bound < 0)
        {
            bound += Length;
        }

        if (bound < 0)
        {
            return BigInteger.MinusOne;
        }

        if (bound >= Length)
        {
            return Length - 1;
        }

        return bound;
    }

    private BigInteger AdjustNegativeStop(object? value, LythonSourceSpan span)
    {
        // Omitted stops end before the beginning for negative steps.
        if (value is null || value is PyNone)
        {
            return BigInteger.MinusOne;
        }

        var bound = Bound(value, BigInteger.Zero, span);
        if (bound < 0)
        {
            bound += Length;
        }

        if (bound < 0)
        {
            return BigInteger.MinusOne;
        }

        if (bound >= Length)
        {
            return Length - 1;
        }

        return bound;
    }

    public PyString RenderPython(PyRenderingContext context)
    {
        _ = context;
        var text = Step == 1
            ? "range(" + Start + ", " + Stop + ")"
            : "range(" + Start + ", " + Stop + ", " + Step + ")";
        return PyString.FromString(text);
    }

    public PyString RenderInterpolated(PyRenderingContext context) => RenderPython(context);

    private static BigInteger Bound(object? value, BigInteger fallback, LythonSourceSpan span)
        => value is null || value is PyNone
            ? fallback
            : Numbers.PyNumberOps.TryAsInteger(value, out var integer)
                ? integer
                : throw new LythonRuntimeException("TypeError", "slice indices must be integers", span);
}

internal sealed class PyEnumerateIterator : PyIteratorBase
{
    private readonly MemoryGovernor _governor;
    private readonly LythonSourceSpan _span;
    private readonly PyIteration.Cursor _cursor;
    private BigInteger _index;

    public PyEnumerateIterator(object iterable, BigInteger start, LythonSourceSpan span, LythonRuntime.ExecutionContext context)
    {
        _cursor = PyIteration.Cursor.Create(iterable, span, context);
        _governor = context.MemoryGovernor;
        _span = span;
        _index = start;
        ChargeIteratorValue(context.MemoryGovernor, span);
    }

    public override PyIterationResult TryMoveNext()
    {
        if (!(_cursor.TryMoveNext() is { HasValue: true, Value: var item }))
        {
            return PyIterationResult.End;
        }

        object indexBox = _index;
        // The item has been consumed. Advance before tuple admission so a
        // refused result cannot reuse its index for the following item.
        AdvanceIndex();
        var produced = new PyTuple([indexBox, item], _governor, _span);
        return PyIterationResult.Yield(produced);
    }

    public override async ValueTask<PyIterationResult> TryMoveNextAsync()
    {
        var (hasValue, item) = await _cursor.TryMoveNextAsync().ConfigureAwait(false);
        if (!hasValue)
        {
            return PyIterationResult.End;
        }

        // Same fresh-tuple ownership as the sync path above.
        object indexBox = _index;
        AdvanceIndex();
        var produced = new PyTuple([indexBox, item], _governor, _span);
        return PyIterationResult.Yield(produced);
    }

    private void AdvanceIndex()
    {
        // The tuple owns its exposed old index. Fund the next retained magnitude
        // before addition allocates; ordinary counters need no extra result box.
        if (_index.GetByteCount() < 8) _index++;
        else _index = (BigInteger)LythonRuntime.AddExactIntegers(_index, BigInteger.One, _governor, _span);
    }

    public override PyString RenderPython(PyRenderingContext context) => PyString.FromString("<enumerate object>");
}

internal sealed class PyZipIterator : PyIteratorBase
{
    private PyIteration.Cursor[] _cursors;
    private readonly MemoryGovernor _governor;
    private readonly bool _strict;
    private readonly LythonSourceSpan _span;
    private bool _finished;
    private long _storageBytes;

    internal long CommittedStorageBytes => _storageBytes;

    public PyZipIterator(object[] iterables, bool strict, LythonSourceSpan span, LythonRuntime.ExecutionContext context)
        : this(iterables.Length, strict, span, context)
    {
        try { InitializeCursors(iterables, context); }
        catch { DiscardUnpublishedStorage(); throw; }
    }

    // Allocate the actual owner and preflight its cursor storage before any
    // source __iter__ can run.
    internal PyZipIterator(int count, bool strict, LythonSourceSpan span, LythonRuntime.ExecutionContext context)
    {
        _governor = context.MemoryGovernor;
        _strict = strict;
        _span = span;
        var bytes = checked(IteratorValueBytes + 32L + 256L * count);
        _governor.Reserve(bytes, span);
        try { _cursors = new PyIteration.Cursor[count]; }
        catch { _governor.ReleaseReserved(bytes); throw; }
        _governor.Commit(bytes);
        _storageBytes = bytes;
    }

    internal void InitializeCursors(object[] iterables, LythonRuntime.ExecutionContext context)
    {
        for (var i = 0; i < iterables.Length; i++)
            _cursors[i] = PyIteration.Cursor.Create(iterables[i], _span, context);
    }

    internal void InitializeCursors(CallArgumentValue[] arguments, LythonRuntime.ExecutionContext context)
    {
        var index = 0;
        foreach (var argument in arguments)
            if (argument.IsPositional) _cursors[index++] = PyIteration.Cursor.Create(argument.Value, _span, context);
    }

    internal void DiscardUnpublishedStorage()
    {
        _cursors = [];
        var bytes = _storageBytes;
        _storageBytes = 0;
        _governor.Release(bytes);
    }

    public override PyIterationResult TryMoveNext()
    {
        if (_finished || _cursors.Length == 0)
        {
            return PyIterationResult.End;
        }

        var funding = checked(32L + 80L * _cursors.Length);

        _governor.Reserve(funding, _span);
        try
        {
            var items = new object[_cursors.Length];

            for (var i = 0; i < _cursors.Length; i++)
            {
                if ((_cursors[i].TryMoveNext() is { HasValue: true, Value: var item }))
                {
                    items[i] = item;
                    continue;
                }

                _finished = true;
                if (_strict)
                {
                    // Like CPython, an exhausted cursor behind earlier yielders
                    // is shorter; only the first cursor peeks ahead for a longer
                    // tail, naming the first diverging argument.
                    if (i > 0)
                    {
                        throw new LythonRuntimeException("ValueError", "zip() argument " + (i + 1) + " is shorter than " + StrictOthers(i), _span);
                    }

                    for (var j = i + 1; j < _cursors.Length; j++)
                    {
                        if (_cursors[j].TryMoveNext().HasValue)
                        {
                            throw new LythonRuntimeException("ValueError", "zip() argument " + (j + 1) + " is longer than " + StrictOthers(j), _span);
                        }
                    }
                }

                return PyIterationResult.End;
            }

            var produced = PyTuple.FromOwnedArray(items, _governor, _span);
            return PyIterationResult.Yield(produced);
        }
        finally
        {

            _governor.ReleaseReserved(funding);
        }
    }

    public override async ValueTask<PyIterationResult> TryMoveNextAsync()
    {
        if (_finished || _cursors.Length == 0)
        {
            return PyIterationResult.End;
        }

        var funding = checked(32L + 80L * _cursors.Length);

        _governor.Reserve(funding, _span);
        try
        {
            var items = new object[_cursors.Length];

            for (var i = 0; i < _cursors.Length; i++)
            {
                var (hasValue, item) = await _cursors[i].TryMoveNextAsync().ConfigureAwait(false);
                if (hasValue)
                {
                    items[i] = item;
                    continue;
                }

                _finished = true;
                if (_strict)
                {
                    // Same strict tail-peeking as the sync path above.
                    if (i > 0)
                    {
                        throw new LythonRuntimeException("ValueError", "zip() argument " + (i + 1) + " is shorter than " + StrictOthers(i), _span);
                    }

                    for (var j = i + 1; j < _cursors.Length; j++)
                    {
                        var (laterHasValue, _) = await _cursors[j].TryMoveNextAsync().ConfigureAwait(false);
                        if (laterHasValue)
                        {
                            throw new LythonRuntimeException("ValueError", "zip() argument " + (j + 1) + " is longer than " + StrictOthers(j), _span);
                        }
                    }
                }

                return PyIterationResult.End;
            }

            // Same fresh-tuple ownership as the sync path above.
            var produced = PyTuple.FromOwnedArray(items, _governor, _span);
            return PyIterationResult.Yield(produced);
        }
        finally
        {

            _governor.ReleaseReserved(funding);
        }
    }

    private static string StrictOthers(int index)
        => index == 1 ? "argument 1" : "arguments 1-" + index;

    public override PyString RenderPython(PyRenderingContext context) => PyString.FromString("<zip object>");
}
