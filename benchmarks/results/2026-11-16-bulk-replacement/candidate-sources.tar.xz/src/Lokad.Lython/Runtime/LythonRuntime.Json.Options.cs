using System.Globalization;
using System.Numerics;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal sealed record JsonLoadOptions(
        object? ObjectHook,
        object? ParseFloat,
        object? ParseInt,
        object? ParseConstant,
        object? ObjectPairsHook, object Strict, bool Prepared = false)
    {
        // Fixed runtime metadata: no guest callbacks, values or execution owners.
        internal static readonly JsonLoadOptions Default = new(null, null, null, null, null, true, Prepared: true);

        internal static JsonLoadOptions Create(object? objectHook, object? parseFloat,
            object? parseInt, object? parseConstant, object? objectPairsHook, object strict)
            => objectHook is null && parseFloat is null && parseInt is null
                && parseConstant is null && objectPairsHook is null && strict is true
                ? Default
                : new(objectHook, parseFloat, parseInt, parseConstant, objectPairsHook, strict);

        internal async ValueTask<JsonLoadOptions> PrepareAsync(ExecutionContext context, LythonSourceSpan span, bool asynchronous)
        {
            if (Prepared) return this;
            var floating = ParseFloat is not null && await JsonOptionTruthAsync(ParseFloat, context, span, asynchronous).ConfigureAwait(false) ? ParseFloat : null;
            var integer = ParseInt is not null && await JsonOptionTruthAsync(ParseInt, context, span, asynchronous).ConfigureAwait(false) ? ParseInt : null;
            var constant = ParseConstant is not null && await JsonOptionTruthAsync(ParseConstant, context, span, asynchronous).ConfigureAwait(false) ? ParseConstant : null;
            return this with { ParseFloat = floating, ParseInt = integer, ParseConstant = constant,
                Strict = await JsonOptionTruthAsync(Strict, context, span, asynchronous).ConfigureAwait(false), Prepared = true };
        }
    }

    internal sealed record JsonDumpOptions(
        object SkipKeys,
        bool EnsureAscii,
        bool CheckCircular,
        object AllowNan,
        PyString? IndentUnit,
        PyString ItemSeparator,
        PyString KeySeparator,
        object? DefaultCallable,
        object SortKeys)
    {
        // Immutable builtin metadata; no guest values, receiver or execution owner.
        internal static readonly JsonDumpOptions Default = new(false, true, true, true,
            null, PyString.FromString(", "), PyString.FromString(": "), BoundCallable.Create(JsonEncoderObject.Default,
                LythonKnownCallableSignatures.JsonEncoderDefault), false);
    }

    internal readonly record struct JsonSeparators(object ItemSeparator, object KeySeparator);

    private static ValueTask<bool> JsonOptionTruthAsync(object value, ExecutionContext context, LythonSourceSpan span, bool asynchronous)
        => value is bool flag ? new(flag) : asynchronous ? IsTruthyAsync(value, context, span) : new(IsTruthy(value, context, span));

    private sealed partial class JsonModule : PyModule
    {
        // Builds the catchable JSONDecodeError value (msg/doc/pos/lineno/colno)
        // for an explicit message and original-document byte position. Token scans,
        // truncation, trailing data, strict violations and index bounds all use
        // the same original UTF-8 coordinates; no backend remapping is needed.
        private static LythonRuntimeException NewJsonDecodeFailure(PyString document, string message, int bytePosition, LythonSourceSpan span, ExecutionContext context)
        {
            var position = document.ByteIndexToRuneIndex(bytePosition);
            var location = ComputeJsonErrorLocation(document, bytePosition, context, span);
            var payload = new PyDict(context.MemoryGovernor, span);
            var errorMessage = CreateString(message, context, span);
            payload.SetItem(PyString.FromString("msg"), errorMessage);
            payload.SetItem(PyString.FromString("doc"), document);
            payload.SetItem(PyString.FromString("pos"), new BigInteger(position));
            payload.SetItem(PyString.FromString("lineno"), new BigInteger(location.Line));
            payload.SetItem(PyString.FromString("colno"), new BigInteger(location.Column));
            var summary = string.Create(CultureInfo.InvariantCulture,
                $"{message}: line {location.Line} column {location.Column} (char {position})");
            return new LythonRuntimeException(ModuleException("json", "JSONDecodeError"), summary, span, innerException: null, payload);
        }

        // Builds the catchable JSONDecodeError for an explicit Python string
        // index (used when the index lies past the end, where no parse byte
        // position maps to it). Lines and columns count like the byte path.
        private static LythonRuntimeException NewJsonDecodeFailureAtRune(PyString input, string message, long runePosition, LythonSourceSpan span, ExecutionContext context)
        {
            var location = ComputeJsonRuneLocation(input, runePosition);
            var payload = new PyDict(context.MemoryGovernor, span);
            var errorMessage = CreateString(message, context, span);
            payload.SetItem(PyString.FromString("msg"), errorMessage);
            payload.SetItem(PyString.FromString("doc"), input);
            payload.SetItem(PyString.FromString("pos"), new BigInteger(runePosition));
            payload.SetItem(PyString.FromString("lineno"), new BigInteger(location.Line));
            payload.SetItem(PyString.FromString("colno"), new BigInteger(location.Column));
            var summary = string.Create(CultureInfo.InvariantCulture,
                $"{message}: line {location.Line} column {location.Column} (char {runePosition})");
            return new LythonRuntimeException(ModuleException("json", "JSONDecodeError"), summary, span, innerException: null, payload);
        }

        // Reports a prefix index past the end with CPython coordinates: every
        // newline in the document precedes it.
        private static LythonRuntimeException CreateJsonExpectingErrorAtRune(PyString input, long runePosition, LythonSourceSpan span, ExecutionContext context)
            => NewJsonDecodeFailureAtRune(input, "Expecting value", runePosition, span, context);

        private static JsonSourceLocation ComputeJsonRuneLocation(PyString document, long runePosition)
        {
            var line = 1;
            var lineStart = 0L;
            var index = 0L;
            foreach (var rune in document.EnumerateRunes())
            {
                if (index >= runePosition)
                {
                    break;
                }

                // Newlines are single-byte, so no multi-byte sequence can
                // start with this byte.
                if (rune.Utf8Span[0] == (byte)'\n')
                {
                    line++;
                    lineStart = index + 1;
                }

                index++;
            }

            return new JsonSourceLocation(line, (int)(runePosition - lineStart + 1));
        }

        private static JsonSourceLocation ComputeJsonErrorLocation(PyString document, int bytePosition,
            ExecutionContext context, LythonSourceSpan span)
        {
            var line = 1;
            var lineStart = 0;
            var bytes = document.Utf8Span;
            for (var position = 0; position < Math.Min(bytePosition, bytes.Length); position++)
            {
                if ((position & 1023) == 0) context.CheckExecution(span);
                if (bytes[position] == (byte)'\n')
                {
                    line++;
                    lineStart = position + 1;
                }
            }

            var column = document.ByteIndexToRuneIndex(bytePosition) - document.ByteIndexToRuneIndex(lineStart) + 1;
            return new JsonSourceLocation(line, column);
        }

        internal static object InvokeJsonCallback(object callable, object argument, ExecutionContext context, LythonSourceSpan span)
        {
            var result = InvokeCallableTarget(callable, span, span, context, [CallArgumentValue.Positional(argument)]);
            return result;
        }

        // The parser/encoder caller owns frame and scratch cleanup through its
        // await. This helper forwards the operation without another state machine.
        internal static ValueTask<object> InvokeJsonCallbackCoreAsync(object callable, object argument, ExecutionContext context, LythonSourceSpan span, bool asynchronous)
            => asynchronous
                ? InvokeCallableTargetAsync(callable, span, span, context,
                    () => ValueTask.FromResult(new[] { CallArgumentValue.Positional(argument) }))
                : new(InvokeJsonCallback(callable, argument, context, span));

        internal static object? OptionalJsonValue(object value) => value is PyNone ? null : value;

        internal static PyString? ParseJsonIndent(object value, LythonSourceSpan span, ExecutionContext context)
        {
            if (ReferenceEquals(value, PyNone.Instance))
            {
                return null;
            }

            if (PyStringOps.TryAsString(value, out var text)) return text;

            // R18: Python bools are integers (True == 1); accept them exactly
            // like their numeric value instead of rejecting them outright.
            if (value is bool boolean)
            {
                return boolean ? JsonIndentSpace : PyString.Empty;
            }

            if (value is BigInteger integer)
            {
                if (integer <= BigInteger.Zero)
                {
                    return PyString.Empty;
                }

                if (integer > int.MaxValue)
                {
                    throw new LythonRuntimeException("OverflowError", "json indentation exceeds string capacity.", span);
                }

                var builder = new GovernedByteBuilder(context.MemoryGovernor, span);
                try
                {
                    var remaining = (int)integer;
                    while (remaining > 0)
                    {
                        context.CheckExecution(span);
                        var count = Math.Min(remaining, 4096);
                        builder.AppendRepeated((byte)' ', count);
                        remaining -= count;
                    }
                    return builder.ToPyStringAndRelease();
                }
                finally { builder.Release(); }
            }

            throw new LythonRuntimeException("TypeError", "json.dumps(indent=...) expects an integer, string, or None.", span);
        }

        private static readonly PyString JsonIndentSpace = PyString.FromString(" ");

        internal static readonly PyString PrettyItemSeparator = PyString.FromString(",");

        internal static PyString RequireJsonSeparator(object value, LythonSourceSpan span)
            => PyStringOps.TryAsString(value, out var text) ? text : throw RuntimeErrors.Type("JSON separator must be a string", span);

        internal static async ValueTask<JsonSeparators> ParseJsonSeparatorsAsync(object value, LythonSourceSpan span, ExecutionContext context, bool asynchronous)
        {
            using var values = value is PyTuple ? MaterializeUnpackingSequence(value, span, context, maximumItems: 3)
                : asynchronous
                ? new UnpackingValues(await PyIteration.MaterializeLeasedAsync(value, span, context, maximumItems: 3).ConfigureAwait(false))
                : MaterializeUnpackingSequence(value, span, context, maximumItems: 3);
            if (values.Items.Count != 2) throw new LythonRuntimeException("ValueError", DescribeLoopArityMismatch(2, values.Items.Count), span);
            return new(values.Items[0], values.Items[1]);
        }

        private static object GetOptional(object[] arguments, int index)
            => index < arguments.Length ? arguments[index] : PyNone.Instance;


        private enum JsonDumpCallForm
        {
            Dump,
            Dumps
        }


        private readonly record struct JsonSourceLocation(int Line, int Column);


        private sealed class UnsupportedJsonClassFactory : ICallable, INamedRuntimeCallable, IPyRenderableValue
        {
            public UnsupportedJsonClassFactory(string name)
            {
                Name = name;
            }

            public string Name { get; }

            public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
            {
                _ = arguments;
                context.CheckExecution(span);
                throw new LythonRuntimeException("NotImplementedError", $"{Name} custom classes are not supported by Lython's JSON subset.", span);
            }

            public PyString RenderPython(PyRenderingContext context)
            {
                _ = context;
                return PyString.FromString("<class '" + Name + "'>");
            }

            public PyString RenderInterpolated(PyRenderingContext context) => RenderPython(context);
        }

    }
}
