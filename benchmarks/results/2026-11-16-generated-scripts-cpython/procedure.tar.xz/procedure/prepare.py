from pathlib import Path
import ast,base64,hashlib,io,json,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');old=r.parent/'cased-word-stream-r440/refined/quiet';prior=r.parent/'checkpoint-r437/phase-1';q=r/'quiet';q.mkdir(exist_ok=True);assert not any(q.iterdir());sha=lambda b:hashlib.sha256(b).hexdigest()
catalog=json.loads((r.parent/'checkpoint-r437/catalog.json').read_text(encoding='utf-8'));generated=json.loads((r/'all-catalog.json').read_text(encoding='utf-8'))
selected=[c for c in generated['cases']if c['id']in ['scripts.config-edit.large','scripts.report-render.large']and c['size']==1024];assert len(selected)==2
catalog['cases']+=selected;assert len(catalog['cases'])==6
details=[]
for c in catalog['cases']:
 for key,field in [('sourceSha256','source'),('fixtureSha256','fixtureJson'),('expectedOutputSha256','expectedOutput')]:assert sha(c[field].encode())==c[key],(c['id'],key)
 fixture=json.loads(c['fixtureJson']);assert fixture['size']==c['size']and(fixture['text']is None or isinstance(fixture['text'],str))
 if c in selected:details.append(dict(id=c['id'],size=c['size'],sourceUtf8Bytes=len(c['source'].encode()),inputBytes=sum(len(base64.b64decode(x))for x in fixture['inputFiles'].values()),inputFiles=list(fixture['inputFiles']),outputFiles=list(fixture['outputFiles'])))
raw=(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n').encode();(q/'representative.json').write_bytes(raw)
before=json.loads((old/'config.json').read_text(encoding='utf-8'));files=before['sourceFiles'];root='/home/lokad/lython-bench-checks/generated-scripts-b847-20261116';unit='lython-b847-generated-scripts-20261116'
jobs=[[c['id'],lane]for c in selected for lane in ['compile','warm','compile-run']]
identity=dict(sourceRevision='Qualified312f5911/measured0443b5cf,production source unchangedthroughc18babe9',purpose='R444 configuration-edit/report-render checkpoint against CPython3.13.16. Compile,warm and compile-once/run-once separated; no earlier-source causal claim.',coreSHA256={n:files['Lokad.Lython.dll']for n in ['candidate','candidate-control']},auxiliaryFiles={n:h for n,h in files.items()if n!='Lokad.Lython.dll'},imageFiles={'reference':files,'candidate':files},catalogSHA256=sha(raw),catalogInitialization='Same fixed six-case catalog in all workers; original R437four plus config/report. Only two new cases measured,no retiming of four unchanged cases.',newCases=details,qualification='Runtime source qualified43828954661; cumulative fixture/ownership43869939863active,611inputs frozen.',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for n in ['collect.py','archive-owned.py']:
 s=(prior/n).read_text(encoding='utf-8')
 if n=='collect.py':
  s=s.replace("root = Path('/home/lokad/lython-bench-checks/representative-b835-20261116')",'root = Path(__file__).resolve().parent');a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+"\nassert len(jobs)==6 and all(case in cases for case,lane in jobs)\n"+s[b:]
 else:s=s.replace("r=Path('/home/lokad/lython-bench-checks/representative-b835-20261116')",'r=Path(__file__).resolve().parent')
 assert 'representative-b835'not in s;ast.parse(s);(q/n).write_text(s,encoding='utf-8',newline='\n')
s=(old/'run.sh').read_text(encoding='utf-8').replace('root='+before['root'],'root='+root);assert 'root='+root in s;(q/'run.sh').write_text(s,encoding='utf-8',newline='\n')
s=(old/'retrieve.py').read_text(encoding='utf-8').replace("['jobs']==7","['jobs']==6").replace('B843','B847');ast.parse(s);(q/'retrieve.py').write_text(s,encoding='utf-8',newline='\n')
payload={n:(q/n).read_bytes()for n in ['identity.json','representative.json','collect.py','archive-owned.py','run.sh']}
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n,b in payload.items():m=tarfile.TarInfo(n);m.size=len(b);t.addfile(m,io.BytesIO(b))
c=dict(root=root,unit=unit,source=before['root'],sourceFiles=files,sourceCatalogSHA256=before['catalogSHA256'],catalogSHA256=sha(raw),identity=identity,retireGroups=[],payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha((q/'payload.tgz').read_bytes()),unpackedBytes=sum(map(len,payload.values())))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path',a);s=s[:a]+'c='+repr(c)+s[b:];s=s.replace('lython-b843-fixtures','lython-b847-fixtures').replace(" os.link(source/'representative.json',root/'representative.json')\n",'');ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(r.parent/'cased-word-stream-r440/refined/launch-quiet.py').read_text(encoding='utf-8').replace('Seven-job cased-word comparison','Six-phase config/report checkpoint');ast.parse(s);(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
for n in ['collect.py','archive-owned.py']:assert 'Path(__file__).resolve().parent'in(q/n).read_text(encoding='utf-8')and '/home/lokad/lython-bench-checks/'not in(q/n).read_text(encoding='utf-8')
assert "config=json.loads((r/'config.json')"in(q/'retrieve.py').read_text(encoding='utf-8')
with tarfile.open(q/'payload.tgz')as t:
 for n,b in payload.items():assert t.extractfile(n).read()==b
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');needle='**Remaining development.**';a=s.index(needle);s=s[:a]+'''**R444 bounded measurement selected.** Refresh existing1024-record configuration
editing and report rendering against CPython at this coherent delivery. Their
current guide figures are historical; R437covered four other scripts. One six-
phase collection separates compilation,warm and compile-once/run-once for these
two cases,using one fixed six-case catalog in every process. Do not rerun the four
unchanged cases or infer causal cross-collection gains. Exact full images/goldens/
quiet/join/archive and local existing-command verification precede VM staging.
Stop after usable six-phase observations,then record remaining setup/formatting/
execution gaps and a whole-stage design decision. No new benchmark framework or
open-ended qualification campaign. Persistent evidence and existing254/252MiB
floors apply; publication held. Current runtime remains qualified0443.

'''+s[a:];p.write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(dict(jobs=jobs,newCases=details,catalogCases=6,catalogSHA256=sha(raw),unpackedBytes=c['unpackedBytes'],noNewImagesOrRetirement=True,allConcretePathsValidated=True)))
