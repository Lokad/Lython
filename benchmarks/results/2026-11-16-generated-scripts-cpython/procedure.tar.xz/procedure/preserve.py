from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');q=r/'quiet';out=repo/'benchmarks/results/2026-11-16-generated-scripts-cpython';out.mkdir()
receipt=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'));summary=json.loads((r/'summary.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['jobs']==6 and summary['complete'];assert hashlib.sha256((q/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for n in ['identity.json','observations.tgz','archive-receipt.json','terminal-status.json']:shutil.copyfile(q/n,out/n)
shutil.copyfile(r/'summary.json',out/'summary.json')
with tarfile.open(out/'procedure.tar.xz','w:xz')as t:
 for p in r.glob('*.py'):t.add(p,arcname='procedure/'+p.name)
 for n in ['preflight.json','preflight.log']:t.add(r/n,arcname=n)
 for p in q.iterdir():
  if p.is_file()and p.name not in ['observations.tgz','payload.tgz']:t.add(p,arcname='quiet/'+p.name)
labels={'scripts.config-edit.large':'Configuration edit','scripts.report-render.large':'Report rendering'}
inputs={'scripts.config-edit.large':'1,024 paths / 7,177 B','scripts.report-render.large':'1,024 records / 189,441 B'}
span=lambda x,a,b:f'{min(x[a],x[b]):.3f}–{max(x[a],x[b]):.3f}'
ratio=lambda x:f'{min(x["ratioRange"]):.2f}–{max(x["ratioRange"]):.2f}×'
status=lambda x:f'Diagnostic; controls L/C {x["lythonControlPercent"]:.2f}/{x["cpythonControlPercent"]:.2f}%; IQR≤{x["maxIqrPercent"]:.2f}%'
warm=[];phases=[];allrows=[]
for x in summary['timing']:
 m=x['medianMilliseconds'];s=f'{span(m,"candidate","candidate-control")} ms | {span(m,"CPython","CPython-control")} ms | {ratio(x)} | {status(x)} |'
 if x['lane']=='warm':warm.append(f'| {labels[x["case"]]} | {inputs[x["case"]]} | '+s)
 else:phases.append(f'| {labels[x["case"]]} | '+('Compilation only'if x['lane']=='compile'else'Compile and execute once')+' | '+s)
 allrows.append(f'| {labels[x["case"]]} | {x["lane"]} | '+s)
(out/'README.md').write_text('''# Generated configuration/report CPython checkpoint

R444/B847,2026-11-16UTC,qualified312f5911/frozen0443b5cf versus stockCPython3.13.16.
Runtime source is unchanged throughc18babe9. Configuration edits a7,177BJSON file
with1,024paths and writes it back. Reporting reads189,441BJSON/1,024records,calls
a small formatting helper and writes Markdown. Existing catalog scripts and CLR
goldens; frozen-worker/CPython protocol verification passes before VM staging.

| Script | Phase | Lython | CPython | Lython / CPython | Status |
| --- | --- | ---: | ---: | ---: | --- |
'''+ '\n'.join(allrows)+'''

Above one means Lython is slower. All four independent process-median ratio
pairings are retained; ranges are not confidence intervals. Configuration is
near CPython with1.92–2.10%Lython control movement. Report execution remains about
18–22%slower; fresh-report IQR4.04%stays visible. Compilation is around1.04–1.06×,
so a heavier compiler is not justified by these observations. Prepared f-string
layouts and receiver arguments already exist in current source; do not add
duplicate metadata caches or call packets from historical review assumptions.
These are diagnostic external ratios,not causal earlier-source gains.

One identical six-case catalog36c0a528in all processes: original R437four cases
plus configuration/report. Only these two new cases are timed,not four unchanged
retests. Catalog initialization differs from R437and stays explicit. QuietF4as_v7/
Ubuntu24.04.4,fourEPYC9V45vCPUs,16GiB/no swap,.NET11RC3normal tiering/workstation
GC,CPython GIL/GC. Six phases200.960s,5s full-request warmups,five rotated roughly
0.5s batches. Full-image/golden/quiet/Closed/join/archive gates pass.

Warm includes Run,mediated RAM I/O,stdout/file goldens and prior-result cleanup;
excludes compilation/startup,fixture reset/protocol and final cache teardown.
Compilation includes compiled-owner disposal; compile-to-result includes compilation,
one execution and compiled-owner disposal. Independently warmed medians are not
additive. Wider process CPU includes reset/protocol. CPython native buffered files
do not provide equivalent capability/budget containment. No startup,pending-I/O,
heap/RSS,contention or embedding-tail measurement. All users joined and RAM fixtures
removed; archive SHAverified under lease,terminal cached. No retirement/floor change.

Current guide adds these six phases without changing R437observations. Original
historical guide is preserved below. The initial local catalog-generation attempt
used a stripped frozen image without RepresentativeScripts and failed before
producing any catalog or observations; generation uses the actual built tool/data,
then the frozen measured image verifies the concrete selected catalog. No timing
from that setup is discarded. User-facing runtime code is unchanged; publication
held and remaining text/search execution gaps stay open.

[Raw](observations.tgz),[phases/controls](summary.json),[identities](identity.json),
[procedure/catalog/preflight](procedure.tar.xz),[preceding guide](prior-BENCHMARKS.md).
''',encoding='utf-8',newline='\n')
guide=repo/'docs/BENCHMARKS.md';shutil.copyfile(guide,out/'prior-BENCHMARKS.md');s=guide.read_text(encoding='utf-8')
needle='\n\n**Ratio =';a=s.index(needle);s=s[:a]+'\n'+'\n'.join(warm)+s[a:]
old='''Every worker loads the same four-case catalog, SHA43b7c6b0; initialization and
startup are outside the clocks. Two six-job collections use5s full-request warmup
and five rotated approximately0.5s rounds; all image/golden/quiet/join/archive gates
pass. [Raw results, identities and procedure](../benchmarks/results/2026-11-16-representative-cpython-checkpoint/README.md).'''
new='''The first four rows use the fixed four-case R437catalog43b7c6b0; the configuration/
report rows use R444catalog36c0a528with all six cases. Every engine/control within
each collection loads identical catalog bytes; initialization/startup stay outside
the clocks. Three bounded six-phase collections use5s full-request warmups and
five rotated approximately0.5s rounds. All image/golden/quiet/join/archive gates
pass. [CSV/text/JSON/search evidence](../benchmarks/results/2026-11-16-representative-cpython-checkpoint/README.md),
[configuration/report evidence](../benchmarks/results/2026-11-16-generated-scripts-cpython/README.md).
Different collection initialization is explicit; no causal source-change gain is inferred.'''
assert old in s;s=s.replace(old,new)
needle='\n\nCompilation includes compiled-owner disposal';a=s.index(needle);s=s[:a]+'\n'+'\n'.join(phases)+s[a:]
s=s.replace('Compilation is not the main gap in these measured scripts; text normalization','Compilation is not the main gap in these measured scripts; configuration is near\nCPython and report execution remains18–22%slower. Text normalization')
guide.write_text(s,encoding='utf-8',newline='\n')
p=repo/'benchmarks/EXPERIMENTS.md';s=p.read_text(encoding='utf-8');a=s.index('[R443/B846 immutable dev105]');s=s[:a]+'''[R444/B847 generated scripts against CPython](results/2026-11-16-generated-scripts-cpython/README.md)
adds existing configuration-edit/report workloads at qualified0443:compile,warm,
compile-once/run-once separated,six-phase200.960s/all gates. Config fresh0.94–0.96×,
report1.20–1.22×CPython; compile1.04–1.06×. Moving controls/IQRand six-case catalog
initialization are explicit; no causal earlier-source gain. Local actual-worker/
CPython preflight passes; no four-case retest or new framework. Current guide adds
these rows,prior guide preserved. Prepared f-string layouts/direct receiver arguments
already exist; remaining normalization/search costs need actual displaced stages.

'''+s[a:];p.write_text(s,encoding='utf-8',newline='\n')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');a=s.index('**R444 bounded measurement selected.**');b=s.index('**Remaining development.**',a)
s=s[:a]+'''**R444 complete.** [Config/report checkpoint](benchmarks/results/2026-11-16-generated-scripts-cpython/README.md)
adds six phases on qualified0443/CPython3.13.16. Config fresh0.94–0.96×,report
1.20–1.22×; compilation1.04–1.06×. Source/control/IQRand changed six-case catalog
initialization remain explicit. All gates/local actual-worker verification pass,
all users joined/RAM fixtures gone. Current guide adds the rows; prior evidence
preserved,no unchanged four-case retest or causal source gain. Prepared f-string
layouts and direct receiver argument views already exist; do not recreate them.

**R445 next source gate: complete generator construction/resumption.** Current
normalization remains2.21–2.30×CPython; earlier sampled generator groups overlap
useful text and are not removable shares. Determine whether synchronous generator
construction/resumption still duplicates continuation/argument/dispatch work that
can disappear as one stage in the existing executable engine. No new native block
compiler,controller,owner or narrow join-only fusion is selected by this hypothesis.
Map current source/actual workloads first; do not repeat unchanged profile captures.
Preserve generator identities,scoping/evaluation order,send/throw/close/yield-from,
StopIteration values,real hosted I/O,exact fault positions,current cancellation,
terminal first refusal,managed stack and pending/escaped ownership. One bounded
source/evidence pass selects a coherent displacement/prototype and one controlled
whole-script comparison,or records unresolved feasibility and moves on. Remove
the displaced route at a retained delivery; R438/R439negative lessons still apply.

'''+s[b:];s=s.replace('Updated2026-11-16UTC(R443development-qualified/cumulative-delivery-active).','Updated2026-11-16UTC(R444recorded/R445source-gate/cumulative-delivery-active).');p.write_text(s,encoding='utf-8',newline='\n')
print('Six representative workloads now have named current external measurements; source-change gain is not inferred,remaining text/search gaps preserved.')
