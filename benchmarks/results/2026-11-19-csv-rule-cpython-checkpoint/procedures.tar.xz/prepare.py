from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys

lab = Path(__file__).resolve().parent
previous = lab.parent / 'postfix-cpython-b1130'
donor = lab.parent / 'integer-transport-cpython-b1136'
rules = lab.parent / 'retained-lexical-cpython-b1122'
invoice = lab.parent / 'retained-return-cpython-b1114'
load = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()

source, target = sys.argv[1:3]
assert target in ('invoice','invoice-rules')
assert subprocess.run(['git','merge-base','--is-ancestor', source, 'HEAD'],check=True).returncode==0
assert not subprocess.check_output(['git','diff','--name-only',source,'HEAD','--','src','benchmarks/Lokad.Lython.Benchmarks','benchmarks/cpython-worker.py'])
core = 'Lokad.Lython.dll'
original = load(donor / 'identity.json')
files = original['imageFiles']['candidate'].copy()
before = donor/'frozen/candidate'
after = lab/'frozen/candidate'
after.mkdir(parents=True,exist_ok=True)
assert len(files)==32 and {name:sha(before/name) for name in files}==files
measured = lab/'build/bin/Lokad.Lython/release_net11.0'/core
for name in files:
    shutil.copyfile(measured if name==core else before/name, after/name)
files[core] = sha(measured)
assert files[core] != original['imageFiles']['candidate'][core]
assert {name:sha(after/name) for name in files}==files
def save(name, value):
    (lab/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')

catalog = load(invoice/'representative.json')
catalog['cases'] = [next(case for case in catalog['cases'] if case['id']=='scripts.csv-invoice.large')]
if target == 'invoice-rules':
    catalog['cases'].append(next(case for case in load(rules/'representative.json')['cases']
                                 if case['id']=='scripts.annotated-rule-closures'))
save('representative.json',catalog)
shutil.copyfile(donor/'cpython-worker.py',lab/'cpython-worker.py')
identity = original.copy()
identity.update(sourceRevision=source,imageSource=source,purpose='B1143 retained CSV and binding checkpoint against CPython',
    imageFiles={'candidate':files},coreSHA256={'candidate':files[core],'candidate-control':files[core]},
    catalogSHA256=sha(lab/'representative.json'))
save('identity.json',identity)
save('build-revision.json',dict(sourceRevision=source,imageSource=source,coreSHA256=files[core]))
sdk = Path.home()/'.dotnet11'
dotnet = sdk/'dotnet.exe'
env = dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
with (lab/'verify.log').open('wb') as log:
    subprocess.run([dotnet,after/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',lab/'representative.json',
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',lab/'cpython-worker.py',
        '--out',lab/'verify.json'], env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
result=load(lab/'verify.json')
assert result['state']=='Completed' and result['catalogSha256']==identity['catalogSHA256']
assert {name:sha(after/name) for name in files}==files
print('Verified complete source image and relevant CPython goldens.')
