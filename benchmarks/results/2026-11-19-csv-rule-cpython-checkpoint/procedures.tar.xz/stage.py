from pathlib import Path
import json
import subprocess
import sys

lab = Path(__file__).resolve().parent
previous = lab.parent / 'postfix-cpython-b1130'
donor = lab.parent / 'integer-transport-cpython-b1136'
binding = lab.parent / 'function-binding-inline-r712'
cases = len(json.loads((lab/'representative.json').read_text(encoding='utf-8'))['cases'])
assert cases in (1,2)
stage = (previous/'prepare-quiet.py').read_text(encoding='utf-8')
stage = stage.replace('postfix-statement-r699/quiet','integer-transport-cpython-b1136')
stage = stage.replace('postfix-cpython-b1130','csv-rule-cpython-b1143')
stage = stage.replace('lython-b1130-postfix-cpython','lython-b1143-csv-rule-cpython')
stage = stage.replace('lython-b1130-fixtures','lython-b1143-fixtures').replace('B1130','B1143')
stage = stage.replace("old['identity']['imageFiles']['reference']", "old['identity']['imageFiles']['candidate']")
stage = stage.replace("sourceRole='reference'", "sourceRole='candidate'")
if cases == 1:
    stage = stage.replace('assert len(jobs)==2','assert len(jobs)==1')
    stage = stage.replace("==2\").replace('jobs=2,","==1\").replace('jobs=1,")
    stage = stage.replace("['jobs']==2","['jobs']==1")
    stage = stage.replace('181','105').replace('started<195','started<130')
    stage = stage.replace('RuntimeMaxSec=255','RuntimeMaxSec=170')
    stage = stage.replace('Staged two unchanged workloads, six lanes','Staged invoice, three lanes')
else:
    stage = stage.replace('Staged two unchanged workloads, six lanes','Staged invoice and annotated rules, six lanes')
assert "arcname='candidate/'+core" in stage
proof = (binding/'prove-quiet-space.py').read_text(encoding='utf-8')
start = proof.index('pairs = ')
end = proof.index('\n',start)
pairs = [('function-binding-inline-r712/quiet','2026-11-19-inline-function-binding-state','reference','reference-core.dll.gz'),
         ('function-binding-inline-r712/quiet','2026-11-19-inline-function-binding-state','candidate','measured-core.dll.gz')]
proof = proof[:start] + 'pairs = ' + repr(pairs) + proof[end:]
archive = (previous/'collect-evidence.py').read_text(encoding='utf-8')
archive = archive.replace('2026-11-19-postfix-cpython-checkpoint','2026-11-19-csv-rule-cpython-checkpoint').replace('B1130','B1143')
if cases == 1:
    archive = archive.replace('receipt["jobs"] == 2','receipt["jobs"] == 1').replace('len(cases) == 2','len(cases) == 1')
    archive = archive.replace('len(rows) == 6','len(rows) == 3').replace('verifiedBatches=120','verifiedBatches=60')
for name,value in [('prove-quiet-space.py',proof),('prepare-quiet.py',stage),('collect-evidence.py',archive)]:
    (lab/name).write_text(value,encoding='utf-8',newline='\n')
for name in ('prove-quiet-space.py','prepare-quiet.py'):
    subprocess.run([sys.executable,'-X','utf8',lab/name],check=True)
