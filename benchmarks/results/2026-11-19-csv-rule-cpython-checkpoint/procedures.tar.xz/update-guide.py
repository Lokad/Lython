from pathlib import Path
import json

evidence = Path('benchmarks/results/2026-11-19-csv-rule-cpython-checkpoint')
data = json.loads((evidence/'summary.json').read_text(encoding='utf-8'))
assert len(data['rows']) == 6 and data['verifiedBatches'] == 120
source, core = data['source'][:9], data['coreSHA256'][:8]
cases = {'scripts.csv-invoice.large':('CSV invoice','B1114'),
         'scripts.annotated-rule-closures':('Annotated rule closures','B1122')}
labels = {'compile':'Compilation only','compile-run':'Compile-to-result'}
def format_range(values, places):
    left,right=(f'{item:.{places}f}' for item in values)
    return left if left == right else f'{left}–{right}'
def status(row):
    text = ('B1143 diagnostic. Controls L/C '
        f"{row['lythonControlPercent']:.2f} / {row['cpythonControlPercent']:.2f}%. "
        f"IQR ≤{row['maxIQRPercent']:.2f}%.")
    if max(row['lythonControlPercent'], row['cpythonControlPercent']) > 3:
        text += ' Gap size uncertain.'
    return text

path=Path('docs/BENCHMARKS.md')
guide=path.read_text(encoding='utf-8')
current, history = guide.split('## Earlier measured workloads',1)
current_lines=current.splitlines()
before_warm, before_fresh = [], []
for row in data['rows']:
    name,old_id=cases[row['case']]
    lane=row['lane']
    found=[]
    for index,line in enumerate(current_lines):
        if line.startswith(f'| {name} |') and old_id in line:
            fields=[field.strip() for field in line[1:-1].split('|')]
            if lane == 'warm' and fields[1] not in labels.values() or lane != 'warm' and fields[1] == labels[lane]:
                found.append((index,line,fields))
    (index,line,fields),=found
    (before_warm if lane=='warm' else before_fresh).append(line)
    places = 5 if lane=='compile' else 3
    fields[2:] = [format_range(row['lythonMs'],places)+' ms',format_range(row['cpythonMs'],places)+' ms',
                  format_range(row['ratio'],2)+'×',status(row)]
    current_lines[index]='| '+' | '.join(fields)+' |'
current='\n'.join(current_lines)+'\n'
old='''B1122 measures the three rule scripts at **0d16f8307 / frozen 99840bea**. B1114 measures the CSV invoice at **2841f6ac2 /
frozen a2ec3ec4**. B1109 measures expanded forwarding and retained'''
new=f'''B1143 measures the CSV invoice and annotated rules at **{source} / frozen {core}**.
B1122 measures unannotated and captured rules at **0d16f8307 / frozen 99840bea**.
B1109 measures expanded forwarding and retained'''
assert old in current
current=current.replace(old,new)
current=current.replace('[B1136 observations]', '[B1143 observations](../'+str(evidence.as_posix())+'/README.md) ·\n[B1136 observations]',1)
old_header='| --- | --- | ---: | ---: | ---: | --- |\n'
from_index=history.index(old_header)+len(old_header)
history=history[:from_index]+'\n'.join(before_warm)+'\n'+history[from_index:]
second_table='| Workload | Phase | Lython | CPython | Lython / CPython | Measurement status |\n'
from_index=history.index(second_table)+len(second_table)+len(old_header)
history=history[:from_index]+'\n'.join(before_fresh)+'\n'+history[from_index:]
path.write_text(current+'\n## Earlier measured workloads'+history,encoding='utf-8',newline='\n')
for row in data['rows']:
    print(row['case'],row['lane'],format_range(row['ratio'],2),status(row))

