from pathlib import Path
import ast
import json

lab = Path(__file__).resolve().parent
previous = lab.parent / 'keyword-copy-path-r662'
donor = lab.parent / 'retained-runtime-cpython-r661'

def read(path):
    return path.read_text(encoding='utf-8-sig')

def write(path, source):
    if path.suffix == '.py':
        ast.parse(source)
    path.write_text(source, encoding='utf-8', newline='\n')

source_catalog = json.loads(read(donor / 'representative.json'))
rules = ['scripts.rule-default-closures', 'scripts.annotated-rule-closures', 'scripts.captured-rule-closures']
control = 'scripts.report-forwarding.expanded'
selected = rules + [control]
source_catalog['cases'] = [case for case in source_catalog['cases'] if case['id'] in selected]
assert {case['id'] for case in source_catalog['cases']} == set(selected)
write(lab / 'catalog.json', json.dumps(source_catalog, indent=2, ensure_ascii=False) + '\n')

freeze = read(previous / 'freeze-and-verify.py').replace('keyword-copy-path-r662', 'integer-chain-prefix-r665')
start, end = freeze.index('\noriginal='), freeze.index('\npython=')
freeze = freeze[:start] + '\nassert len(load(catalog_path)["cases"]) == 4' + freeze[end:]
write(lab / 'freeze-and-verify.py', freeze.replace('all five', 'all four'))

stage = read(previous / 'stage-quiet.py')
start, end = stage.index('        jobs = ['), stage.index('        source=source[:a]')
jobs = [(case, lane) for lane in ('warm', 'compile-run') for case in selected]
stage = stage[:start] + '        jobs = ' + repr(jobs) + '\n' + stage[end:]
stage = (stage.replace('R662 select native keyword copy before traversal', 'R665 publish completed machine integer prefix')
         .replace('keyword-copy-path-b1092-20261119', 'integer-chain-prefix-b1094-confirmation-20261119')
         .replace('lython-b1092-keyword-copy-path-20261119', 'lython-b1094-integer-chain-prefix-20261119')
         .replace('lython-b1092-fixtures', 'lython-b1094-fixtures')
         .replace('quiet = lab / "quiet"', 'quiet = lab / "quiet-confirmation"')
         .replace('Prepared binding diagnostics source pair', 'Completed machine integer prefix')
         .replace('Inline keyword mapping', 'Completed machine integer prefix'))
stage = (stage.replace('len(jobs)==9', 'len(jobs)==6').replace("len(raw['jobs'])==9", "len(raw['jobs'])==6")
         .replace("['jobs']==9", "['jobs']==6").replace('jobs=9,', 'jobs=6,')
         .replace('==9","==6', '==6","==8').replace('==6","==6', '==6","==8')
         .replace('jobs=6,","jobs=6,', 'jobs=6,","jobs=8,')
         .replace('"474","323"', '"323","420"')
         .replace('five-case, six-job', 'four-case, eight-job'))
write(lab / 'stage-quiet.py', stage)

def fix_local_scripts():
    quiet = lab / 'quiet-confirmation'
    runner = read(lab / 'launch-quiet.py').replace("/'quiet'", "/'quiet-confirmation'")
    runner = runner.replace('diagnostics source pair', 'source pair')
    write(lab / 'launch-quiet.py', runner)
    summary = read(lab / 'summarize-quiet.py').replace("'quiet/", "'quiet-confirmation/")
    write(lab / 'summarize-quiet.py', summary)
    collector = read(quiet / 'collect.py')
    catalog_assignments = [line for line in collector.splitlines() if line.startswith('jobs = ')]
    assert ast.literal_eval(catalog_assignments[0].split('=', 1)[1].strip()) == jobs
    assert 'assert len(jobs)==8' in collector
    assert "len(raw['jobs'])==8" in read(quiet / 'archive-owned.py')
    assert 'jobs=8,' in read(quiet / 'archive-owned.py')
    assert "['jobs']==8" in read(quiet / 'retrieve.py')
    assert "len(raw['jobs'])==8" in summary and 'timedelta(seconds=420)' in runner

write(lab / 'check-staged.py', read(Path(__file__)).split('\ndef fix_local_scripts():')[0].split('\nsource_catalog = ')[0]
      + '\njobs = ' + repr(jobs) + '\n\ndef fix_local_scripts():'
      + read(Path(__file__)).split('\ndef fix_local_scripts():')[1].split('\nwrite(lab / \'check-staged.py\',')[0]
      + '\nfix_local_scripts()\n')
