set -eu
cd /mnt/d/code/Lython/.git/agent-worktrees/integer-chain-prefix-r665
notes=/mnt/d/code/Lython/.git/agent-notes/review-20261031/integer-chain-prefix-r665
filter='FullyQualifiedName~IntegerChain|FullyQualifiedName~ArithmeticPrecedence|FullyQualifiedName~IntegerBinarySemantics|FullyQualifiedName~CounterIntegerAdmission|FullyQualifiedName~FloatArithmeticPipeline|FullyQualifiedName~FrameIntegerLifetime|FullyQualifiedName~AugmentedIntegerCompatibility|FullyQualifiedName~ExactInteger'
status=0
for suite in Tests PublicApi.Tests; do
    log="$notes/ubuntu-net10-$suite.log"
    if ! ~/.dotnet/dotnet test "tests/Lokad.Lython.$suite" -c Release -f net10.0 --artifacts-path ~/lython-r665-artifacts --filter "$filter" > "$log" 2>&1; then
        status=1
    fi
    tail -n 7 "$log"
done
exit "$status"
