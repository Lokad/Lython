from pathlib import Path
import ast
import json

lab = Path(__file__).resolve().parent
previous = lab.parent / 'keyword-copy-path-r662'
donor = lab.parent / 'retained-runtime-cpython-r661'

def read(path):
    return path.read_text(encoding='utf-8-sig')

def write(path, source):
    if path.suffix == '.py':
        ast.parse(source)
    path.write_text(source, encoding='utf-8', newline='\n')

jobs = [('scripts.rule-default-closures', 'warm'), ('scripts.annotated-rule-closures', 'warm'), ('scripts.captured-rule-closures', 'warm'), ('scripts.report-forwarding.expanded', 'warm'), ('scripts.rule-default-closures', 'compile-run'), ('scripts.annotated-rule-closures', 'compile-run'), ('scripts.captured-rule-closures', 'compile-run'), ('scripts.report-forwarding.expanded', 'compile-run')]

def fix_local_scripts():
    quiet = lab / 'quiet-confirmation'
    runner = read(lab / 'launch-quiet.py').replace("/'quiet'", "/'quiet-confirmation'")
    runner = runner.replace('diagnostics source pair', 'source pair')
    write(lab / 'launch-quiet.py', runner)
    summary = read(lab / 'summarize-quiet.py').replace("'quiet/", "'quiet-confirmation/")
    write(lab / 'summarize-quiet.py', summary)
    collector = read(quiet / 'collect.py')
    catalog_assignments = [line for line in collector.splitlines() if line.startswith('jobs = ')]
    assert ast.literal_eval(catalog_assignments[0].split('=', 1)[1].strip()) == jobs
    assert 'assert len(jobs)==8' in collector
    assert "len(raw['jobs'])==8" in read(quiet / 'archive-owned.py')
    assert 'jobs=8,' in read(quiet / 'archive-owned.py')
    assert "['jobs']==8" in read(quiet / 'retrieve.py')
    assert "len(raw['jobs'])==8" in summary and 'timedelta(seconds=420)' in runner

fix_local_scripts()
