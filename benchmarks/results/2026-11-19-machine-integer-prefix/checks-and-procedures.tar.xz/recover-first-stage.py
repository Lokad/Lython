from pathlib import Path
import json
import shutil
import subprocess

lab = Path(__file__).resolve().parent
quiet = lab / 'quiet'
first = lab / 'first-stage'
first.mkdir(exist_ok=False)
for name in ['config.json', 'launch.log', 'remote-launch.py', 'collect.py', 'archive-owned.py', 'retrieve.py']:
    shutil.copyfile(quiet / name, first / name)
config = json.loads((quiet / 'config.json').read_text(encoding='utf-8'))
code = '''from pathlib import Path
import fcntl, json, os, subprocess
config = CONFIG
root = Path(config['root'])
assert root.name == 'integer-chain-prefix-b1094-20261119'
with (root.parent / 'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    service = subprocess.check_output(['systemctl', 'show', config['unit'] + '.service',
        '--property=ActiveState,MainPID,Result,ExecMainStatus'], text=True)
    journal = subprocess.check_output(['journalctl', '-u', config['unit'] + '.service', '-n', '18', '--no-pager'], text=True)
    assert 'MainPID=0' in service and 'Result=exit-code' in service and 'assert len(jobs)==6' in journal
    worker = subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'], capture_output=True, text=True)
    assert not worker.stdout
    exit_code = (root / 'exit-code.txt').read_text().strip()
    assert exit_code == '1' and not list((root / 'confirmation').iterdir())
    ram = root / 'guest-fixtures'
    filesystem = subprocess.check_output(['findmnt','--mountpoint',str(ram),'-n','-o','FSTYPE,SOURCE'], text=True).split()
    assert filesystem == ['tmpfs','lython-b1094-fixtures'] and os.path.ismount(ram) and not list(ram.iterdir())
    subprocess.run(['sudo','-n','umount',str(ram)],check=True)
    ram.rmdir()
    assert not ram.exists()
    print(json.dumps(dict(config=config, service=service, journal=journal, exitCode=exit_code,
        workerStarted=False, timedSamples=0, joinedAndEmptyFixtureRemoved=True)))
'''.replace('CONFIG', repr(config))
ssh = ['C:/Windows/System32/OpenSSH/ssh.exe', '-i', str(Path.home() / '.ssh/id_lython-bench.pem'),
       '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15', 'lokad@20.166.121.73']
done = subprocess.run(ssh + ['python3 -'], input=code, text=True, encoding='utf-8', capture_output=True, timeout=30)
(first / 'terminal.log').write_text(done.stdout + done.stderr, encoding='utf-8', newline='\n')
assert done.returncode == 0, done.stdout + done.stderr
print('Initial guard failed before any worker or sample. The owned empty fixture mount was released under the lease.')
