from pathlib import Path
import ast

lab = Path(__file__).resolve().parent
stage = (lab / 'stage-quiet.py').read_text(encoding='utf-8')
stage = stage.replace('quiet-confirmation', 'quiet-repeat').replace('b1094', 'b1095')
stage = stage.replace('prefix-b1095-confirmation', 'prefix-b1095-repeat')
stage = stage.replace('==8', '==5').replace('jobs=8,', 'jobs=5,').replace('eight-job', 'five-job')
stage = stage.replace('"323","420"', '"323","340"')
start, end = stage.index('        jobs = ['), stage.index('        source=source[:a]')
jobs = [
    ('scripts.rule-default-closures','warm'),
    ('scripts.annotated-rule-closures','warm'),
    ('scripts.captured-rule-closures','compile-run'),
    ('scripts.rule-default-closures','compile-run'),
    ('scripts.report-forwarding.expanded','warm'),
]
stage = stage[:start] + '        jobs = ' + repr(jobs) + '\n' + stage[end:]
start = stage.index('    if name == "archive-owned.py":')
stage = stage[:start] + '''    if name == "collect.py":
        source = source.replace('warmupSeconds=8', 'warmupSeconds=12')
        source = source.replace('accumulate8seconds', 'accumulate12seconds')
        source = source.replace('min(warmed)<8', 'min(warmed)<12').replace('warmed[i]>=8', 'warmed[i]>=12')
        source = source.replace('if job_index >= 2: labels.reverse()',
                                'if job_index % 2 == 0: labels.reverse()')
        assert 'assert len(jobs)==5' in source and 'min(warmed)<12' in source
    if name == "archive-owned.py":
        assert "len(raw['jobs'])==5" in source and 'jobs=5,' in source
    if name == "retrieve.py":
        assert "['jobs']==5" in source
''' + stage[start:]
stage = stage.replace('"launch-quiet.py", read(template', '"launch-repeat.py", read(template')
stage = stage.replace('"summarize-quiet.py", read(template', '"summarize-repeat.py", read(template')
stage += '''
for filename in ('launch-repeat.py', 'summarize-repeat.py'):
    path = lab / filename
    script = read(path).replace("/'quiet'", "/'quiet-repeat'").replace("'quiet/", "'quiet-repeat/")
    if filename.startswith('launch'):
        assert 'timedelta(seconds=340)' in script
    else:
        assert "len(raw['jobs'])==5" in script
        script = script.replace("'quiet-summary.json'", "'repeat-summary.json'")
    write(path, script)
'''
ast.parse(stage)
(lab / 'stage-repeat.py').write_text(stage, encoding='utf-8', newline='\n')
