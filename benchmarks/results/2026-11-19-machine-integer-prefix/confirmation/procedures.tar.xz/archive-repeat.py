from pathlib import Path

lab = Path(__file__).resolve().parent
original = (lab / 'archive-r665.py').read_text(encoding='utf-8')
prefix = original[:original.index('initial = verify(')]
prefix = prefix.replace('2026-11-19-machine-integer-prefix")', '2026-11-19-machine-integer-prefix/confirmation")')
exec(compile(prefix, __file__, 'exec'))

summary = verify('quiet-repeat', 5, 'repeat-summary.json')
raw = load(lab / 'quiet-repeat/retrieved/confirmation/confirmation.json')
assert raw['warmupSeconds'] == 12 and raw['rounds'] == 5
summary['warmupSeconds'] = raw['warmupSeconds']
summary['launchOrderReversedForFirstWorkload'] = next(iter(raw['jobs'][0]['identities'])) == 'candidate'
assert summary['launchOrderReversedForFirstWorkload']
out.mkdir(exist_ok=False)
save(out / 'summary.json', summary)
quiet = lab / 'quiet-repeat'
for name in ('observations.tgz', 'archive-receipt.json', 'terminal-status.json'):
    shutil.copyfile(quiet / name, out / name)
with tarfile.open(out / 'procedures.tar.xz', 'w:xz') as evidence:
    for name in ('config.json', 'identity.json', 'representative.json', 'remote-launch.py', 'retrieve.py',
                 'observe-not-before.json', 'launch.log', 'collect.py', 'archive-owned.py', 'run.sh'):
        evidence.add(quiet / name, arcname='quiet-repeat/' + name)
    for name in ('prepare-confirmation.py', 'stage-repeat.py', 'launch-repeat.py', 'summarize-repeat.py',
                 'archive-repeat.py', 'archive-r665.py', 'repeat-retrieval.log'):
        evidence.add(lab / name, arcname=name)
print('Verified 100 golden batches, pre/post gates, full images and the archived lease receipt.')
