import ast
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
prior = lab.parent / "current-frame-costs-r606"
donor = lab.parent / "prepared-definition-text-r611"
def read(path):
    return path.read_text(encoding="utf-8-sig")
def load(path):
    return json.loads(read(path))
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def write(name, text):
    if name.endswith(".py"):
        ast.parse(text)
    (lab/name).write_text(text, encoding="utf-8", newline="\n")
def save(name, value):
    write(name, json.dumps(value,ensure_ascii=False,indent=2)+"\n")

stage = load(donor/"quiet/config.json")
image = donor/"frozen/candidate"
files = stage["identity"]["imageFiles"]["candidate"]
assert len(files) == 32 and {name: sha(image/name) for name in files} == files
assert not subprocess.check_output(["git","diff","--name-only","0a69dd9bc","aa29c019e","--","src","tests"])
retained = load(Path("benchmarks/results/2026-11-19-prepared-definition-text/summary.json"))
assert retained["retainedCommit"] == subprocess.check_output(["git", "rev-parse", "aa29c019e"], text=True).strip() and retained["cores"]["candidate"] == files["Lokad.Lython.dll"]
catalog = load(lab.parent/"retained-runtime-cpython-r610/representative.json")
labels=["forwarding","invoice","selectors"]
variants=("scripts.report-forwarding.expanded","scripts.csv-invoice.large","scripts.report-render.format-selectors.large")
catalog["cases"] = [next(c for c in catalog["cases"] if c["id"] == case) for case in variants]
save("catalog.json",catalog)
catalog_path=lab/"catalog.json"
identity=dict(sourceRevision="aa29c019e",purpose="Retained record and text workload attribution",
    coreSHA256=dict(candidate=files["Lokad.Lython.dll"]),imageFiles=dict(candidate=files),
    catalogSHA256=sha(catalog_path),diagnosticOnly=True,publicationHeld=True)
save("identity.json",identity)

old=load(prior/"config.json")
root="/home/lokad/lython-bench-checks/current-record-text-costs-b1044-20261119"
unit="lython-b1044-current-record-text-costs-20261119"
jobs=[(label,case,"warm") for label,case in zip(labels,variants,strict=True)]
profile=read(prior/"ops-profile.py").replace(old["root"],root)
a,b=profile.index("[('rules',"),profile.index(")]",profile.index("[('rules',"))+2
profile=profile[:a]+repr(jobs)+profile[b:]
profile=profile
write("ops-profile.py",profile)
collect=read(prior/"collect.py").replace(old["root"],root).replace("['rules', 'annotated', 'forwarding']",repr(labels))
collect=re.sub(r"source='R606/B1033[^']+'", f"source='R614/B1044 aa29c019e/{files['Lokad.Lython.dll'][:8]} record and text attribution'",collect)
write("collect.py",collect)
write("run.sh",read(prior/"run.sh").replace(old["root"],root))
write("launch.py",read(prior/"launch.py").replace("Current frame attribution","Current record and text attribution"))
write("retrieve.py",read(prior/"retrieve.py"))
analyze=read(prior/"analyze.py").replace("['rules', 'annotated', 'forwarding']",repr(labels))
analyze=analyze.replace(" focused={", """ focus.update({
     'CSV row parsing': ('CsvRecordParser','CsvInput','CsvReader','TryAdoptRecord','CsvDictReader'),
     'JSON load and conversion': ('JsonDeserialize','DeserializeJson','Utf8JsonReader','ReadJsonString','AppendJsonString'),
     'prepared format selectors': ('AppendTemplateAsync','AppendNativeFormat','MethodFormatOperation','ResolvePreparedSelector'),
     'direct positional text format': ('JoinPreparedPositionalText','CopyJoinBytes'),
     'private split operands': ('SplitForUnpack','SplitFixed','CreateSplitFragment'),
     'text trim and view': ('TrimPrepared','TrimCore','RStrip','CopyOrBorrowUtf8Range','ScanWhitespaceSuffix'),
     'integer conversion and arithmetic': ('TryParseInteger','ConvertInteger','TryIntegerChain','TryExecuteBuiltinArithmetic'),
     'per-record tuple and dictionary construction': ('BuildFixedTuple','SetRecordItem','CreateRecord','MakeRecord','BuildFixedFunctionKeywords'),
 })
 focused={""")
write("analyze.py",analyze)
names=["identity.json","catalog.json","ops-profile.py","collect.py","run.sh"]
payload=lab/"payload.tgz"
with tarfile.open(payload,"w:gz") as stream:
    for name in names:
        stream.add(lab/name,arcname=name)
size=sum((lab/name).stat().st_size for name in names)
space=load(lab/"quiet-space.json")
available=space["freeBytes"]; reserve=254*1024*1024+524288+size
selected=[]
for proof in space["replicas"]:
    if available > reserve+98304:
        break
    assert proof["committedBlobVerified"]
    selected.append(proof); available+=proof["bytes"]
assert available > reserve
config=dict(root=root,unit=unit,source=stage["root"],sourceFiles=files,sourceCatalogSHA256=stage["catalogSHA256"],
    catalogSHA256=sha(catalog_path),identity=identity,retireGroups=selected,payloadBytes=payload.stat().st_size,
    payloadSHA256=sha(payload),unpackedBytes=size)
save("config.json",config)
launcher=read(prior/"remote-launch.py")
a,b=launcher.index("\nc=")+1,launcher.index("\nb=Path(")
write("remote-launch.py",re.sub(r"lython-b[0-9]+(?:-annotated)?-fixtures","lython-b1044-fixtures",
    launcher[:a]+"c="+repr(config)+launcher[b:]))
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
with (lab/"verify.log").open("wb") as log:
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog_path,
        "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",Path.cwd()/"benchmarks/cpython-worker.py",
        "--out",lab/"verify.json"],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90,check=True)
verification=load(lab/"verify.json")
assert verification["state"]=="Completed" and verification["catalogSha256"]==sha(catalog_path)
assert {name:sha(image/name) for name in files}==files
print("Verified current retained image and all three published workload goldens.")
