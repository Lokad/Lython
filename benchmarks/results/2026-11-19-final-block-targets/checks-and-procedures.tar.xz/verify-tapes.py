from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
donor=lab.parent/'reachable-block-map-r652/tape-probe/bin/Release/net11.0'
root=Path.home()/'.dotnet11'
root_env=dict(os.environ,DOTNET_ROOT=str(root),DOTNET_ROOT_X64=str(root))
identity=json.loads((lab/'frozen-identity.json').read_text(encoding='utf-8'))
reports={}
name='Lokad.Lython.WhiteBox.Tests'
for role in ('reference','candidate'):
    work=lab/'tape-probe'/role
    work.mkdir(parents=True,exist_ok=True)
    for suffix in ('.dll','.deps.json','.runtimeconfig.json'):
        file=name+suffix
        shutil.copyfile(donor/file,work/file)
    core=lab/'frozen'/role/'Lokad.Lython.dll'
    assert hashlib.sha256(core.read_bytes()).hexdigest()==identity['images'][role][core.name]
    shutil.copyfile(core,work/core.name)
    generated=subprocess.check_output([root/'dotnet.exe',work/(name+'.dll'),lab/'catalog.json'],env=root_env)
    (lab/(role+'-tapes.json')).write_bytes(generated)
    data=json.loads(generated)
    assert data['coreSha256']==identity['images'][role][core.name]
    reports[role]=data['tapes']
assert len(reports['reference'])==6 and reports['reference']==reports['candidate']
print('Six complete instruction and protected-region inventories are identical across the exact images.')
