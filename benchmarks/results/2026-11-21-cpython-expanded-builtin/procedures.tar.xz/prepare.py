from pathlib import Path
import gzip, hashlib, json, shutil, subprocess, tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
source=lab.parent/'expanded-builtin-span'
template=lab.parent/'normalize-json-cpython'
q=lab/'quiet'
previous=template/'confirmation/quiet'
def read(p): return p.read_text(encoding='utf-8')
def load(p): return json.loads(read(p))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def emit(p,s):
    if p.suffix=='.py': compile(s,str(p),'exec')
    p.write_text(s,encoding='utf-8',newline='\n')
def save(p,v): emit(p,json.dumps(v,indent=2,ensure_ascii=False)+'\n')
index=load(source/'identity.json')
revision=index['candidate']
assert revision.startswith('3ab6f6c81')
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=repo/'.git/agent-worktrees/expanded-builtin-span')
verified=load(source/'candidate-verify.json')
assert index['candidate']==revision and verified['state']=='Completed'
files=index['imageFiles']['candidate']
image=source/'frozen/candidate'
assert len(files)==32 and {n:sha(image/n) for n in files}==files
assert verified['catalogSha256']==index['catalogSHA256']==sha(source/'representative.json')
assert index['pythonWorkerSHA256']==sha(repo/'benchmarks/cpython-worker.py')
staging=load(source/'quiet/config.json')
receipt=load(source/'quiet/archive-receipt.json')
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
assert receipt['archiveSHA256']==sha(source/'quiet/observations.tgz')
q.mkdir()
identity=dict(sourceRevision=revision,imageSource=revision,purpose='JSON Lines export with expanded encoding options against stock CPython',
              imageFiles=dict(candidate=files),catalogSHA256=index['catalogSHA256'],cpythonWorkerSHA256=index['pythonWorkerSHA256'],
              auxiliaryFiles={name:digest for name,digest in files.items() if name!='Lokad.Lython.dll'},
              coreSHA256={name:files['Lokad.Lython.dll'] for name in ('candidate','candidate-control')})
save(q/'identity.json',identity)
shutil.copyfile(repo/'benchmarks/cpython-worker.py',q/'cpython-worker.py')

prior=load(previous/'config.json')
root='/home/lokad/lython-bench-checks/expanded-builtin-span-cpython-b1261-20261121'
unit='lython-b1261-expanded-builtin-span-cpython-20261121'
normalize='scripts.json-normalized-records.large'
validator='scripts.config-generated-guards.medium.bad-0'
for name in ('collect.py','archive-owned.py','retrieve.py','run.sh'):
    s=read(previous/name).replace(prior['root'],root).replace(prior['unit'],unit).replace('B1253','B1261')
    if name == 'collect.py':
        begin=s.index("    for case_id,lane in ")
        end=s.index("        assert time.monotonic()",begin)
        case='scripts.json-lines-shipment.expanded-options.large'
        s=s[:begin]+f"    for case_id,lane in [({case!r},'warm'),({case!r},'compile-run'),({case!r},'compile')]:\n"+s[end:]
        s=s.replace('+16',"+(4 if lane=='compile' else 12)")
    if name in ('archive-owned.py','retrieve.py'):
        s=s.replace("==2","==3").replace("jobs=2,","jobs=3,")
    if name == 'run.sh':
        assert '\r' not in s
    emit(q/name,s)
assert b'\r' not in (q/'run.sh').read_bytes()
parts=('identity.json','collect.py','archive-owned.py','run.sh','cpython-worker.py')
archive=q/'payload.tgz'
with tarfile.open(archive,'w:gz') as f:
    for n in parts: f.add(q/n,arcname=n)
config=dict(root=root,unit=unit,identity=identity,source=staging['root'],sourceRole='candidate',
            sourceFiles=files,sourceCatalogSHA256=identity['catalogSHA256'],catalogSHA256=identity['catalogSHA256'],
            cpythonWorkerSHA256=identity['cpythonWorkerSHA256'],retireGroups=[],donorArchiveSHA256=receipt['archiveSHA256'],
            payloadBytes=archive.stat().st_size,payloadSHA256=sha(archive),unpackedBytes=sum((q/n).stat().st_size for n in parts))
save(q/'config.json',config)
s=read(previous/'remote-launch.py')
a,b=s.index('\nc=')+1,s.index('\nb=Path(')
s=(s[:a]+'c='+repr(config)+s[b:]).replace('lython-b1253-fixtures','lython-b1261-fixtures')
s=s.replace("176160768+c['unpackedBytes']+32*1024*1024","176160768+c['unpackedBytes']+16*1024*1024")
emit(q/'remote-launch.py',s)
launch=read(template/'confirmation/launch.py').replace("parent/'quiet-space-verified'","parent/'quiet'")
emit(lab/'launch.py',launch.replace("B1253 JSON normalization confirmation","B1261 expanded builtin JSON Lines report"))
