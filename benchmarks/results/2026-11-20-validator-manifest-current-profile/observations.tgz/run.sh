set -eu
root=/home/lokad/lython-bench-checks/validator-manifest-current-profile-b1245-20261120
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
