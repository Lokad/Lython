using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed class PyTuple : IPySequenceValue, IPyIndexableValue, IPyTruthyValue, IPyIterableValue, IPyRenderableValue, IPyHashableValue, IPyOwnershipSnapshot
{
    private readonly Array _items;
    private readonly MemoryGovernor? _memoryGovernor;
    private readonly LythonSourceSpan? _allocationSpan;
    private readonly long _committedBytes;


    public static readonly PyTuple Empty = new([], takeOwnership: true);

    public PyTuple(IEnumerable<object> items)
    {
        _items = items.ToArray();
    }

    public PyTuple(IEnumerable<object> items, MemoryGovernor governor) : this(items, governor, null) { }

    public PyTuple(IEnumerable<object> items, MemoryGovernor governor, LythonSourceSpan? allocationSpan)
    {
        _memoryGovernor = governor;
        _allocationSpan = allocationSpan;
        _items = MaterializeGovernedItems(items, governor, allocationSpan, out _committedBytes);
    }

    public PyTuple(ReadOnlySpan<object> items)
    {
        _items = items.ToArray();
    }

    public PyTuple(ReadOnlySpan<object> items, MemoryGovernor governor) : this(items, governor, null) { }

    public PyTuple(ReadOnlySpan<object> items, MemoryGovernor governor, LythonSourceSpan? allocationSpan,
        LythonRuntime.ExecutionContext? context = null)
    {
        _memoryGovernor = governor;
        _allocationSpan = allocationSpan;
        _items = CopyGovernedItems(items, governor, allocationSpan, out _committedBytes, context);
    }

    private PyTuple(object[] items, bool takeOwnership)
    {
        _items = takeOwnership ? items : [.. items];
    }

    private PyTuple(object[] items, MemoryGovernor governor, LythonSourceSpan? allocationSpan, long committedBytes)
    {
        _items = items;
        _memoryGovernor = governor;
        _allocationSpan = allocationSpan;
        _committedBytes = committedBytes;
    }

    private PyTuple(LythonRuntime.ExecutableSlot[] items, MemoryGovernor governor,
        LythonSourceSpan span, long committedBytes)
    {
        _items = items;
        _memoryGovernor = governor;
        _allocationSpan = span;
        _committedBytes = committedBytes;
    }

    internal static PyTuple FromIntegerSlots(ReadOnlySpan<LythonRuntime.ExecutableSlot> values,
        LythonRuntime.ExecutionContext context, LythonSourceSpan span)
    {
        // Admit the wider backing, metadata and every eventual scalar box.
        var bytes = checked(64L + 24L * values.Length
            + RuntimeMemoryEstimates.ScalarStorageBytes * values.Length);
        using var storage = context.MemoryGovernor.ReserveTemporary(bytes, span);
        context.CheckExecution(span);
        var items = new LythonRuntime.ExecutableSlot[values.Length];
        for (var offset = 0; offset < values.Length;)
        {
            context.CheckExecution(span);
            var count = Math.Min(1024, values.Length - offset);
            values.Slice(offset, count).CopyTo(items.AsSpan(offset));
            offset += count;
        }
        var tuple = new PyTuple(items, context.MemoryGovernor, span, bytes);
        storage.Commit(bytes);
        return tuple;
    }

    internal bool TryReadInteger(int index, out long value)
    {
        if (_items is LythonRuntime.ExecutableSlot[] items) return items[index].TryGetInteger(out value);
        value = 0;
        return false;
    }

    internal bool TryBorrowInteger(long index, out LythonRuntime.ExecutableSlot value)
    {
        value = default;
        if (_items is not LythonRuntime.ExecutableSlot[] items) return false;
        if (index < 0) index += items.Length;
        if ((ulong)index >= (uint)items.Length) return false;
        if (items[(int)index].IsUnpublishedInteger) value.BorrowTupleInteger(this, (int)index);
        else value.Object = items[(int)index].Reference;
        return true;
    }

    public MemoryGovernor? OwnerMemoryGovernor => _memoryGovernor;

    bool IPyOwnershipSnapshot.TrySnapshotOwnership(out long chargeBytes) =>
        OwnershipSnapshot.Owned(OwnerMemoryGovernor, CommittedStorageBytes, out chargeBytes);

    public LythonSourceSpan? AllocationSpan => _allocationSpan;

    internal static long EstimateApproximateBytes(int count) => 32L + (16L * count);

    internal long CommittedStorageBytes => _committedBytes;

    internal static PyTuple FromOwnedArray(object[] items) => new(items, takeOwnership: true);

    internal static PyTuple Repeat(IReadOnlyList<object> source, int count, int length,
        LythonRuntime.ExecutionContext context, LythonSourceSpan span)
    {
        long scalarBytes = 0;
        for (var i = 0; i < source.Count; i++)
        {
            if ((i & 1023) == 0) context.CheckExecution(span);
            scalarBytes = checked(scalarBytes + RuntimeMemoryEstimates.EstimateScalarStorageBytes(source[i]));
        }
        var bytes = checked(EstimateApproximateBytes(length) + scalarBytes * count);
        using var storage = context.MemoryGovernor.ReserveTemporary(bytes, span);
        context.CheckExecution(span);
        var items = new object[length];
        for (var i = 0; i < source.Count; i++)
        {
            if ((i & 1023) == 0) context.CheckExecution(span);
            items[i] = source[i];
        }
        PySequenceMaterialization.FillRepeated<object>(items.AsSpan(0, source.Count), items, context, span);
        var result = new PyTuple(items, context.MemoryGovernor, span, bytes);
        storage.Commit(bytes);
        return result;
    }

    internal static PyTuple FromPositionalArguments(ReadOnlySpan<CallArgumentValue> arguments,
        MemoryGovernor governor, LythonSourceSpan span, LythonRuntime.ExecutionContext context)
    {
        var count = 0;
        long scalars = 0;
        for (var i = 0; i < arguments.Length; i++)
        {
            if ((i & 1023) == 0) context.CheckExecution(span);
            if (!arguments[i].IsPositional) continue;
            count++;
            scalars = checked(scalars + RuntimeMemoryEstimates.EstimateScalarStorageBytes(arguments[i].Value));
        }
        var bytes = checked(EstimateApproximateBytes(count) + scalars);
        governor.Reserve(bytes, span);
        try
        {
            context.CheckExecution(span);
            var items = count == 0 ? Array.Empty<object>() : new object[count];
            var written = 0;
            for (var i = 0; i < arguments.Length; i++)
            {
                if ((i & 1023) == 0) context.CheckExecution(span);
                if (arguments[i].IsPositional) items[written++] = arguments[i].Value;
            }
            var result = new PyTuple(items, governor, span, bytes);
            context.CheckExecution(span);
            governor.Commit(bytes);
            return result;
        }
        catch { governor.ReleaseReserved(bytes); throw; }
    }

    internal static PyTuple FromOwnedArray(object[] items, MemoryGovernor governor, LythonSourceSpan? allocationSpan)
    {
        // Ownership transfer lets collection-expression callers avoid a second
        // backing-array copy. The caller must not retain or mutate the array.
        // Box identities are only read, so the transfer proof is unaffected.
        var bytes = EstimateStorageBytes(items);
        governor.Reserve(bytes, allocationSpan);
        governor.Commit(bytes);
        return new PyTuple(items, governor, allocationSpan, bytes);
    }

    // The caller already admitted the private backing before allocation.
    // Transfer that funding without refunding a still-live array. Scalar estimates
    // supplement the backing estimate before publishing the tuple shell.
    // Callers may already have admitted scalar headroom as part of this output's
    // storage; it is separate from any live construction scratch in the lease.
    internal static PyTuple FromReservedOwnedArray(object[] items, MemoryGovernor governor,
        LythonSourceSpan? span, MemoryGovernor.TemporaryMemoryReservation storage, long reservedScalarBytes = 0)
    {
        var bytes = EstimateStorageBytes(items);
        storage.Grow(bytes - EstimateApproximateBytes(items.Length) - reservedScalarBytes, span);
        var tuple = new PyTuple(items, governor, span, bytes);
        storage.Commit(bytes);
        return tuple;
    }

    internal static long EstimateStorageBytes(ReadOnlySpan<object> items,
        LythonRuntime.ExecutionContext? context = null, LythonSourceSpan? span = null)
    {
        context ??= PyStructuralGuard.AmbientContext;
        var bytes = EstimateApproximateBytes(items.Length);
        for (var i = 0; i < items.Length; i++)
        {
            if (i != 0 && (i & 1023) == 0) context?.CheckExecution(span);
            bytes = checked(bytes + RuntimeMemoryEstimates.EstimateScalarStorageBytes(items[i]));
        }
        return bytes;
    }

    // Completed references need one admission before copying and no funding helper
    // allocation. Named tuples share this same storage construction rule.
    internal static object[] CopyGovernedItems(ReadOnlySpan<object> items, MemoryGovernor governor,
        LythonSourceSpan? span, out long bytes, LythonRuntime.ExecutionContext? context = null)
    {
        context ??= PyStructuralGuard.AmbientContext;
        bytes = EstimateStorageBytes(items, context, span);
        governor.Reserve(bytes, span);
        object[] result;
        try
        {
            context?.CheckExecution(span);
            result = new object[items.Length];
            for (var offset = 0; offset < items.Length;)
            {
                if (offset != 0) context?.CheckExecution(span);
                var count = Math.Min(4096, items.Length - offset);
                items.Slice(offset, count).CopyTo(result.AsSpan(offset));
                offset += count;
            }
        }
        catch
        {
            governor.ReleaseReserved(bytes);
            throw;
        }
        governor.Commit(bytes);
        return result;
    }

    internal static object[] MaterializeGovernedItems(IEnumerable<object> items, MemoryGovernor governor,
        LythonSourceSpan? allocationSpan, out long bytes, int? expectedCount = null)
    {
        if (items is object[] array)
        {
            ValidateCount(array.Length);
            return CopyGovernedItems(array, governor, allocationSpan, out bytes);
        }

        var capacity = items switch
        {
            PyIteration.Cursor cursor => cursor.KnownCount.GetValueOrDefault(),
            ICollection<object> collection => collection.Count,
            IReadOnlyCollection<object> collection => collection.Count,
            _ => 0,
        };
        // Fixed records know their necessary result capacity even when their
        // source is a generator. This is admission, not an iteration cutoff.
        capacity = Math.Max(capacity, expectedCount.GetValueOrDefault());
        using var metadata = governor.ReserveTemporary(PyList.EstimateCapacityBytes(0), allocationSpan);
        var builder = new PyList(capacity, governor, allocationSpan);
        try
        {
            var context = PyStructuralGuard.AmbientContext;
            builder.AppendItems(items, context, allocationSpan);
            ValidateCount(builder.Count);
            return builder.TakeConstructorStorage(out bytes, context, allocationSpan);
        }
        finally { builder.DiscardUnpublishedStorage(); }

        void ValidateCount(int count)
        {
            if (expectedCount is { } expected && count != expected)
                throw new LythonRuntimeException("TypeError", $"Expected {expected} arguments, got {count}", allocationSpan);
        }
    }

    internal static async ValueTask<PyTuple> CreateAsync(object source,
        LythonRuntime.ExecutionContext context, LythonSourceSpan span)
    {
        var governor = context.MemoryGovernor;
        using var metadata = governor.ReserveTemporary(PyList.EstimateCapacityBytes(0), span);
        var builder = new PyList(source is IReadOnlyCollection<object> known ? known.Count : 0, governor, span);
        try
        {
            await builder.AppendItemsAsync(PyIteration.Cursor.ForAsyncEnumeration(source, span, context), context, span).ConfigureAwait(false);
            var items = builder.TakeConstructorStorage(out var bytes, context, span);
            return new PyTuple(items, governor, span, bytes);
        }
        finally { builder.DiscardUnpublishedStorage(); }
    }

    public int Count => _items.Length;

    public int Length => _items.Length;

    public object this[int index] => _items is object[] objects ? objects[index]
        : ((LythonRuntime.ExecutableSlot[])_items)[index].PublishSharedInteger();

    public IEnumerator<object> GetEnumerator() => _items is object[] objects
        ? ((IEnumerable<object>)objects).GetEnumerator() : EnumerateIntegers().GetEnumerator();

    private IEnumerable<object> EnumerateIntegers()
    {
        for (var i = 0; i < Count; i++) yield return this[i];
    }

    public object GetItem(int index) => this[index];

    public object CreateSlice(IEnumerable<object> items) => _memoryGovernor is null ? new PyTuple(items) : new PyTuple(items, _memoryGovernor, _allocationSpan);

    public object GetIndex(int index) => this[index];

    internal PyTuple Slice(PyIndexing.SliceBounds bounds, LythonRuntime.ExecutionContext context, LythonSourceSpan span)
        => LythonRuntime.CreateTuple(bounds.Count,
            index => this[(int)(bounds.Start + (long)index * bounds.Step)], context, span);

    public object GetSlice(IEnumerable<int> indices)
    {
        var items = PySequenceMaterialization.MaterializeSlice(this, indices, _memoryGovernor, _allocationSpan);
        return _memoryGovernor is null
            ? PyTuple.FromOwnedArray(items)
            : PyTuple.FromOwnedArray(items, _memoryGovernor, _allocationSpan);
    }

    System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator() => GetEnumerator();

    public object[] ToArray()
    {
        var bytes = EstimateApproximateBytes(_items.Length);
        using var storage = _memoryGovernor?.ReserveTemporary(bytes, _allocationSpan);
        var result = this.ToArrayCore();
        storage?.Commit(bytes);
        return result;
    }

    private object[] ToArrayCore()
    {
        if (_items is object[] objects) return objects.ToArray();
        var result = new object[Count];
        for (var i = 0; i < result.Length; i++)
        {
            if ((i & 1023) == 0) PyStructuralGuard.AmbientContext?.CheckExecution(_allocationSpan);
            result[i] = this[i];
        }
        return result;
    }

    public bool IsTruthy() => Count != 0;

    public IEnumerable<object> Iterate() => this;

    public int GetPyHashCode() => PyTupleLike.ComputeHashCode(this);

    public PyString RenderPython(PyRenderingContext context)
        => PyRendering.ToReprPyString(this, context);

    public PyString RenderInterpolated(PyRenderingContext context)
        => PyRendering.ToReprPyString(this, context);

}
