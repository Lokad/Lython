from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).resolve().parent;old=r/'quiet';q=r/'async';q.mkdir();c=json.loads((old/'config.json').read_text(encoding='utf-8'));source=c['root'];root='/home/lokad/lython-bench-checks/sequence-async-b867-20261117';unit='lython-b867-sequence-async-20261117'
c.update(root=root,unit=unit,source=source,sourceRole='reference',sourceCatalogSHA256=c['catalogSHA256'],retireGroups=[])
c['identity']['purpose']='Execution-boundary correction: actual warm-async lane invokes RunAsync for tuple report, generator-list and CSV control. Same immutable sources/images; no async compile-to-result claim.'
(q/'identity.json').write_text(json.dumps(c['identity'],indent=2)+'\n',encoding='utf-8');jobs=[['scripts.report-render.tuple.async','warm-async'],['generators.drain.large','warm-async'],['scripts.csv-invoice.large','warm-async']]
for n in ['collect.py','archive-owned.py','run.sh']:
 s=(old/n).read_text(encoding='utf-8').replace(source,root)
 if n=='collect.py':
  lines=s.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('jobs='));lines[i]='jobs='+repr(jobs);s='\n'.join(lines)+'\n';s=s.replace('len(jobs)==7','len(jobs)==3')
 if n=='archive-owned.py':s=s.replace("len(raw['jobs'])==7","len(raw['jobs'])==3").replace('jobs=7','jobs=3')
 if n=='run.sh':assert 'root='+root in s
 (q/n).write_text(s,encoding='utf-8',newline='\n')
 if n.endswith('.py'):ast.parse(s)
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n in ['collect.py','archive-owned.py','run.sh','identity.json']:t.add(q/n,arcname=n)
with tarfile.open(q/'payload.tgz')as t:c['unpackedBytes']=sum(m.size for m in t.getmembers())
c.update(payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest());(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
s=(old/'remote-launch.py').read_text(encoding='utf-8');tree=ast.parse(s);n=next(n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='c'for t in n.targets));lines=s.splitlines(keepends=True);lines[n.lineno-1:n.end_lineno]=['c='+repr(c)+'\n'];s=''.join(lines).replace('lython-b866-fixtures','lython-b867-fixtures').replace("os.link(source/c['sourceRole']/n,p)","os.link(source/role/n,p)").replace("assert (root/'representative.json').is_file()","os.link(source/'representative.json',root/'representative.json')");ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8')
(q/'retrieve.py').write_text((old/'retrieve.py').read_text(encoding='utf-8').replace("['jobs']==7","['jobs']==3").replace('B866','B867'),encoding='utf-8')
s=(r/'launch.py').read_text(encoding='utf-8').replace("Path(__file__).parent/'quiet'","Path(__file__).parent/'async'").replace('seconds=230','seconds=140').replace('230seconds','140seconds').replace('Seven-job sequence construction','Three-job actual RunAsync');(r/'launch-async.py').write_text(s,encoding='utf-8')
s=(r/'summarize.py').read_text(encoding='utf-8').replace("r=Path(__file__).resolve().parent","r=Path(__file__).resolve().parent/'async'").replace("r/'quiet/retrieved/confirmation/confirmation.json'","r/'retrieved/confirmation/confirmation.json'").replace("len(raw['jobs'])==7","len(raw['jobs'])==3");(r/'summarize-async.py').write_text(s,encoding='utf-8');print('Prepared actual warm-async API checks; same sources, no new core copy or retirement.')
