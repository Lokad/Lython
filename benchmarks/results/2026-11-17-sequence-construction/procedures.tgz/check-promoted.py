from pathlib import Path
import ast,json,subprocess,os
r=Path('D:/code/Lython/.git/agent-notes/review-20261031/sequence-construction-r460');w=Path('D:/code/Lython');dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env['DOTNET_ROOT']=str(dotnet.parent);env['DOTNET_ROOT_X64']=str(dotnet.parent);env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
merged={}
for p in [r/'check-initial.py',r/'check-construction.py']:
 tree=ast.parse(p.read_text(encoding='utf-8-sig'));node=next(n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='jobs'for t in n.targets))
 for label,project,classes in ast.literal_eval(node.value):merged.setdefault((label,project),set()).update(classes)
merged[('internal','Lokad.Lython.Tests')].add('SequenceConstructionOwnershipTests')
(r/'final-filter-classes.json').write_text(json.dumps({label:sorted(classes)for(label,project),classes in merged.items()},indent=2)+'\n',encoding='utf-8')
for framework in ['net11.0','net10.0']:
 for (label,project),classes in merged.items():
  log=r/('promoted-'+label+'-'+framework+'.log');assert not log.exists();condition='Category!=Stress&('+'|'.join('FullyQualifiedName~.'+c+'.'for c in sorted(classes))+')'
  with log.open('w',encoding='utf-8')as f:p=subprocess.run([str(dotnet),'test',str(w/'tests'/project/(project+'.csproj')),'-c','Release','-f',framework,'--no-build','--filter',condition,'--logger','trx;LogFileName=promoted-'+label+'-'+framework+'.trx','--results-directory',str(r)],cwd=w,env=env,stdout=f,stderr=subprocess.STDOUT)
  print(framework,label,p.returncode,log.read_text(encoding='utf-8')[-500:],flush=True)
  if p.returncode:raise SystemExit(p.returncode)
