from pathlib import Path
import os,subprocess
r=Path('D:/code/Lython/.git/agent-notes/review-20261031/sequence-construction-r460');w=Path('D:/code/Lython/.git/agent-worktrees/generator-batches-r458');dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe')
env=os.environ.copy();env['DOTNET_ROOT']=str(dotnet.parent);env['DOTNET_ROOT_X64']=str(dotnet.parent);env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
jobs=[('public','Lokad.Lython.PublicApi.Tests',['BulkGeneratorConsumptionTests','StringJoinIterationTests','GeneratorExpressionBoundaryTests','GeneratorExpressionBoundaryLifetimeTests','GeneratorStorageSemanticsTests','GeneratorSemanticsScenarioTests','GeneratorFunctionScenarioTests','RenderJoinLifetimeScenarioTests','BytesJoinExecutionTests','AsyncMaterializationScenarioTests','GeneratorCleanupCompositionTests']),('internal','Lokad.Lython.Tests',['SynchronousGeneratorAdvanceTests','CompiledGeneratorExpressionTests','GeneratorExpressionAdmissionTests','StringJoinCleanupTests','StringJoinAccountingTests','CursorDispatchTests','IterationCancellationTests','DirectStringJoinTests'])]
for label,project,classes in jobs:
 condition='Category!=Stress&('+'|'.join('FullyQualifiedName~.'+c+'.' for c in classes)+')'
 log=r/('target10-'+label+'-net10.log');assert not log.exists()
 command=[str(dotnet),'test',str(w/'tests'/project/(project+'.csproj')),'-c','Release','-f','net10.0','--filter',condition,'--logger','trx;LogFileName=target10-'+label+'-net10.trx','--results-directory',str(r)]
 with log.open('w',encoding='utf-8') as f:p=subprocess.run(command,cwd=w,env=env,stdout=f,stderr=subprocess.STDOUT)
 print(label,p.returncode,log.read_text(encoding='utf-8')[-3000:],flush=True)
 if p.returncode:raise SystemExit(p.returncode)
