from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile,xml.etree.ElementTree as E
repo=Path('D:/code/Lython');r=Path(__file__).resolve().parent;w=repo/'.git/agent-worktrees/generator-batches-r458';old=r.parent/'generator-batches-r458/guarded';f=r/'frozen';f.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert '0 Error(s)'in(r/'nonincremental-measured-core.log').read_text(encoding='utf-8');previous=json.loads((old/'frozen/identity.json').read_text(encoding='utf-8'))
for role in ['reference','candidate']:
 (f/role).mkdir()
 for n,h in previous['imageFiles']['reference'].items():
  p=old/'frozen/reference'/n;assert sha(p)==h;shutil.copy2(p,f/role/n)
core=w/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'
for project in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:assert sha(w/'tests'/project/'bin/Release/net11.0/Lokad.Lython.dll')==sha(core),project
shutil.copy2(core,f/'candidate/Lokad.Lython.dll')
paths=subprocess.check_output(['git','ls-files','src','tests','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','NuGet.Config','global.json','Lokad.Lython.slnx'],cwd=w,text=True,encoding='utf-8').splitlines()
paths+=['tests/Lokad.Lython.PublicApi.Tests/BulkGeneratorConsumptionTests.cs','tests/Lokad.Lython.PublicApi.Tests/SequenceConstructionPipelineTests.cs','tests/Lokad.Lython.Tests/SequenceConstructionOwnershipTests.cs'];assert len(paths)==len(set(paths))
images={role:{p.name:sha(p)for p in(f/role).iterdir()}for role in ['reference','candidate']};assert [n for n in images['reference']if images['reference'][n]!=images['candidate'][n]]==['Lokad.Lython.dll']
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};checks=[]
for p in sorted(r.glob('*.trx')):checks.append(dict(file=p.name,**E.parse(p).find('t:ResultSummary/t:Counters',ns).attrib))
assert all(c['failed']=='0'for c in checks if c['file'].startswith('final-'))
status=dict(checks=checks,finalNet11=dict(public=277,internal=172),finalNet10=dict(public=277,internal=172),originalChargeAndAuthorityFailuresPreserved=True,overlappingFiltersNotSummed=True)
(r/'focused-status.json').write_text(json.dumps(status,indent=2)+'\n',encoding='utf-8')
identity=dict(referenceSource='Fully qualified9e8d1cf5/e92d9598; later root commits only preserve evidence',candidateSource='PrivateR460 at82e45812 + R458 guarded integration + shared private sequence builder/constructor buffering + matching-state authority guard',imageFiles=images,sourceInputs={p:sha(w/p)for p in paths},productionFiles=sum(p.startswith('src/Lokad.Lython/')for p in paths),catalogSHA256=sha(r/'catalog.json'),normalAdapterPin='0.4.0',focusedStatus=status,fullQualification=False,publicationHeld=True)
(f/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as t:
 for p in paths:t.add(w/p,arcname=p)
(r/'prototype.patch').write_bytes(subprocess.check_output(['git','diff','--','src','tests'],cwd=w))
a=r/'allocation-short';a.mkdir()
for n in ['Program.cs','Allocation.csproj']:shutil.copy2(old/'allocation-short'/n,a/n)
s=(old/'validate-images.py').read_text(encoding='utf-8').replace("old=r.parent.parent/'scalar-index-r453'","old=r.parent/'scalar-index-r453'");(r/'validate-images.py').write_text(s,encoding='utf-8')
print(json.dumps(dict(core=sha(core),sourceInputs=len(paths),production=identity['productionFiles'],cases=9)))
