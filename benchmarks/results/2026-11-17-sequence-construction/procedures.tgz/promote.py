from pathlib import Path
import json,subprocess,hashlib,shutil
repo=Path('D:/code/Lython');w=repo/'.git/agent-worktrees/generator-batches-r458';r=repo/'.git/agent-notes/review-20261031/sequence-construction-r460'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
files=subprocess.check_output(['git','diff','--name-only','--','src','tests'],cwd=w,text=True,encoding='utf-8').splitlines()+['tests/Lokad.Lython.PublicApi.Tests/BulkGeneratorConsumptionTests.cs','tests/Lokad.Lython.PublicApi.Tests/SequenceConstructionPipelineTests.cs','tests/Lokad.Lython.Tests/SequenceConstructionOwnershipTests.cs']
for name in files:
 target=repo/name
 if target.exists():
  original=subprocess.check_output(['git','show','82e45812:'+name],cwd=repo)
  assert target.read_text(encoding='utf-8-sig').replace('\r\n','\n')==original.decode('utf-8-sig').replace('\r\n','\n'),name
 shutil.copy2(w/name,target)
identity=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))
for name,h in identity['sourceInputs'].items():
 if name.startswith('src/Lokad.Lython/'):
  assert hashlib.sha256((repo/name).read_bytes()).hexdigest()==h or (repo/name).read_text(encoding='utf-8-sig')==(w/name).read_text(encoding='utf-8-sig'),name
p=repo/'docs/RUNTIME.md';s=p.read_text(encoding='utf-8');key='## Shared memory ownership';i=s.index(key)
s=s[:i]+'''Native iterable constructors share one governed sequence builder. Tuples adopt
exact-sized backing or admit a trim copy while the old capacity remains funded.
Per-capacity scalar headroom replaces per-item reservation growth; larger scalar
payload estimates remain funded before publication. With a supplied allowance,
this conservative working and retained storage can reject some tuples earlier.
Input effects and aliases remain ordinary Python behavior; failed private builders
refund their storage after iterator cleanup.

Native sequence consumers buffer generator yields only while writing admitted
capacity under the same execution authority. Growth, pending disposal and consumer
callbacks return through the ordinary boundary. Other execution authorities keep
per-pull consumer checks. Both APIs preserve current cancellation and awaited cleanup.

'''+s[i:];p.write_text(s,encoding='utf-8')
p=repo/'tests/README.md';s=p.read_text(encoding='utf-8');i=s.index('\n\n');s=s[:i]+'''

[Sequence construction](Lokad.Lython.PublicApi.Tests/SequenceConstructionPipelineTests.cs)
checks exact/grown/trimmed containers, retained aliases, late iterator errors,
live target mutation and real asynchronous cancellation/cleanup.
[Ownership regressions](Lokad.Lython.Tests/SequenceConstructionOwnershipTests.cs)
check final-array refusal before allocation, other owners' funding, terminal refusal
and cancellation when a source has a different execution authority.
[Bulk consumption](Lokad.Lython.PublicApi.Tests/BulkGeneratorConsumptionTests.cs)
preserves exception state, bounded unpacking, reentry and delegated return values.
'''+s[i:];p.write_text(s,encoding='utf-8')
p=repo/'CHANGELOG.md';s=p.read_text(encoding='utf-8');key='## 0.11.0 - Unreleased\n';s=s.replace(key,key+'''
- Share governed native sequence construction and buffer admitted generator output
  through the existing engine. Remove async tuple staging and per-item scalar
  reservation growth. Preserve aliases, active cancellation, terminal refusal and
  awaited cleanup; conservative tuple headroom can reject earlier under a supplied
  memory allowance.
''',1);p.write_text(s,encoding='utf-8')
p=repo/'docs/BENCHMARKS.md';s=p.read_text(encoding='utf-8');key='| --- | --- | --- |\n';index=s.index(key,s.index('## Improvements within Lython'))+len(key);s=s[:index]+'''| Shared native sequence construction / complete normalization and tuple-report | Warm normalization9–12%lower elapsed, async report2–5%lower/warm and about4.7–4.8%lower compile-to-result, with supporting CPU; generator-list diagnostic also favorable | Allocation essentially flat; report accounted peak12%higher. Numeric control uncertain with moving references, CSVroughly flat. [Exact sources, original adversity and checks](../benchmarks/results/2026-11-17-sequence-construction/README.md). |
'''+s[index:];p.write_text(s,encoding='utf-8')
(r/'promoted-paths.json').write_text(json.dumps(files,indent=2)+'\n',encoding='utf-8');print('Promoted measured production text and semantic tests; full delivery qualification next.')
