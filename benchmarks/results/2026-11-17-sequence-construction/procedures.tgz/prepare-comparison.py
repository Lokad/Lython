from pathlib import Path
import ast,hashlib,io,json,subprocess,tarfile
repo=Path('D:/code/Lython');r=Path(__file__).resolve().parent;template=r.parent/'generator-batches-r458/guarded/quiet';q=r/'quiet';q.mkdir();frozen=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));c=json.loads((template/'config.json').read_text(encoding='utf-8'));template_root=c['root'];source=template_root;root='/home/lokad/lython-bench-checks/sequence-construction-b866-20261116';unit='lython-b866-sequence-construction-20261116'
canonical='benchmarks/results/2026-11-16-generator-batches/refined/measured-cores.tar.xz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes()
with tarfile.open(fileobj=io.BytesIO(blob))as t:data=t.extractfile('generator-batches-4fcfcc71.dll').read()
proofs=[dict(paths=['generator-batches-b863-20261116/candidate/Lokad.Lython.dll'],bytes=len(data),links=1,sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='generator-batches-4fcfcc71.dll',committedBlobVerified=True)]
(r/'retirement-proof.json').write_text(json.dumps(proofs,indent=2)+'\n',encoding='utf-8');base=frozen['imageFiles']['reference'];oldCatalogSHA=c['catalogSHA256']
identity=dict(sourceRevision='Qualified9e8d1cf5/e92d9598 vs privateR460/'+frozen['imageFiles']['candidate']['Lokad.Lython.dll'][:8],purpose='Shared sequence builder/native constructor buffering. Complete JSON tuple-report async warm/fresh, generator-list warm/fresh, normalization/numeric/CSV warm controls. No performance claim before collection.',imageFiles=frozen['imageFiles'],coreSHA256={label:frozen['imageFiles']['candidate'if label.startswith('candidate')else'reference']['Lokad.Lython.dll']for label in ['reference','reference-control','candidate','candidate-control']},auxiliaryFiles={n:h for n,h in base.items()if n!='Lokad.Lython.dll'},catalogSHA256=frozen['catalogSHA256'],normalAdapterPin='0.4.0',focusedStatus=dict(net11=dict(public=277,internal=172),net10=dict(public=277,internal=172)))
c.update(root=root,unit=unit,source=source,sourceRole='reference',sourceFiles=base,sourceCatalogSHA256=oldCatalogSHA,catalogSHA256=frozen['catalogSHA256'],retireGroups=proofs,identity=identity)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8');(q/'representative.json').write_bytes((r/'catalog.json').read_bytes())
jobs=[['scripts.text-normalization.large','warm'],['scripts.report-render.tuple.async','warm'],['scripts.report-render.tuple.async','compile-run'],['generators.drain.large','warm'],['generators.drain.large','compile-run'],['scripts.numeric-squared-error.large','warm'],['scripts.csv-invoice.large','warm']]
for n in ['collect.py','archive-owned.py','run.sh']:
 s=(template/n).read_text(encoding='utf-8').replace(template_root,root);assert template_root not in s
 if n=='collect.py':
  lines=s.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('jobs='));lines[i]='jobs='+repr(jobs);s='\n'.join(lines)+'\n';s=s.replace('len(jobs)==5','len(jobs)==7').replace('end=time.monotonic()+6','end=time.monotonic()+4')
 if n=='archive-owned.py':s=s.replace("len(raw['jobs'])==5","len(raw['jobs'])==7").replace('jobs=5','jobs=7')
 if n=='run.sh':assert 'root='+root in s
 (q/n).write_text(s,encoding='utf-8',newline='\n')
 if n.endswith('.py'):ast.parse(s)
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n in ['collect.py','archive-owned.py','run.sh','identity.json','representative.json']:t.add(q/n,arcname=n)
 t.add(r/'frozen/candidate/Lokad.Lython.dll',arcname='candidate/Lokad.Lython.dll')
with tarfile.open(q/'payload.tgz')as t:c['unpackedBytes']=sum(m.size for m in t.getmembers())
c.update(payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest());(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
s=(template/'remote-launch.py').read_text(encoding='utf-8');tree=ast.parse(s);n=next(n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='c'for t in n.targets));lines=s.splitlines(keepends=True);lines[n.lineno-1:n.end_lineno]=['c='+repr(c)+'\n'];s=''.join(lines).replace('lython-b865-fixtures','lython-b866-fixtures').replace("os.link(source/'representative.json',root/'representative.json')","assert (root/'representative.json').is_file()");ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8')
(q/'retrieve.py').write_text((template/'retrieve.py').read_text(encoding='utf-8').replace('B865','B866').replace("['jobs']==5","['jobs']==7"),encoding='utf-8')
(r/'launch.py').write_text((r.parent/'generator-batches-r458/guarded/launch.py').read_text(encoding='utf-8').replace('Five-job generator batches','Seven-job sequence construction'),encoding='utf-8')
(r/'summarize.py').write_text((r.parent/'generator-batches-r458/guarded/summarize.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==5","len(raw['jobs'])==7"),encoding='utf-8')
print(json.dumps(dict(jobs=7,unpackedBytes=c['unpackedBytes'],provedRetirementBytes=sum(p['bytes']for p in proofs),onlyCoreChanges=True,catalogCases=9)))
