from pathlib import Path
import json,shutil,tarfile,hashlib,xml.etree.ElementTree as E
repo=Path('D:/code/Lython');r=repo/'.git/agent-notes/review-20261031/sequence-construction-r460';out=repo/'benchmarks/results/2026-11-17-sequence-construction';out.mkdir()
for n in ['summary.json','allocation-summary.json','prototype.patch','candidate-sources.tar.xz','initial-construction-sources.tar.xz','authority-before-sources.tar.xz','design.md','catalog-notes.md','focused-status.json']:shutil.copy2(r/n,out/n)
shutil.copy2(r/'frozen/identity.json',out/'identity.json');shutil.copy2(r/'quiet/observations.tgz',out/'observations.tgz')
core=r/'frozen/candidate/Lokad.Lython.dll';assert hashlib.sha256(core.read_bytes()).hexdigest()=='aaef443f0ffdb1308f83cddf8f475d88226a42cbabd1be0828eed3fa4ee1814d'
with tarfile.open(out/'measured-core.tar.xz','w:xz')as t:t.add(core,arcname='sequence-construction-aaef443f.dll')
with tarfile.open(out/'focused-checks.tgz','w:gz')as t:
 for p in r.iterdir():
  if p.is_file()and p.suffix in ['.log','.trx']:t.add(p,arcname=p.name)
 for p in(r/'allocation-short').glob('*.json'):t.add(p,arcname='allocation-short/'+p.name)
with tarfile.open(out/'procedures.tgz','w:gz')as t:
 for folder in [r,r/'quiet']:
  for p in folder.iterdir():
   if p.is_file()and(p.suffix in ['.py','.sh']or p.name in ['config.json','terminal-status.json','archive-receipt.json','retirement-proof.json','observe-not-before.json']or p.name.startswith('observation-')):t.add(p,arcname=p.relative_to(r).as_posix())
for role in ['reference','candidate']:
 v=json.loads((r/f'preflight-{role}.json').read_text(encoding='utf-8'));assert v['caseCount']==9
validation=dict(retained=True,productionTextMatchesFrozen=True,binaryEqualityInferred=False,focusedActualWindowsNet11=dict(public=277,internal=172),focusedActualWindowsNet10=dict(public=277,internal=172),supervisedGoldenCases=9,firstChargeExpectationFailures=2,foreignAuthorityRegressionFailedBeforeAndPassesAfter=True,fullQualificationPending=True,allocationReductionEstablished=False,reportedTuplePeakIncreasePercent=100*(4000049/3577427-1),remainingDebt='Numeric elapsed/CPU uncertain with moving controls; CSV roughly flat; do not claim no regression or add gains across source pairs.',timingCorrection='B866 warm and compile-run use Run; catalog runAsync metadata did not select timed execution. Allocation diagnostics explicitly call both APIs. Supplemental warm-async qualification is separate.',publicationHeld=True)
(out/'validation.json').write_text(json.dumps(validation,indent=2)+'\n',encoding='utf-8')
(out/'README.md').write_text('''# Shared sequence construction and native generator consumption

R460/B866, completed2026-11-17UTC; started2026-11-16UTC. Qualified9e8d1cf5/e92d9598
versus retained private82e45812 plus archivedaaef443f, now promoted with matching
production text. Full delivery qualification is pending; publication remains held.

One existing PyList builder now supplies iterable tuple construction. Exact-sized
backing transfers its funding; a trim copy admits full overlap. Async tuple staging,
the separate array-growth/per-item scalar-reservation loop and duplicate append
loops are removed. Native consumers share the existing generator engine and only
buffer into admitted capacity under the same execution authority. Final Add ends
the borrow before growth; live list mutation, exception state and awaited cleanup
are preserved. No arena, ledger, policy, universal value layout or new interpreter.

| Complete workload | Boundary | Elapsed change | Wider CPU change |
| --- | --- | ---: | ---: |
| Normalization,4,096lines/52,224B | Warm Run | −12.47..−8.98% | −11.26..−5.92% |
| JSON-to-tuple-to-Markdown report | Warm Run | −5.32..−1.99% | −6.80..−2.78% |
| Same tuple report | Compile and Run once | −4.84..−4.67% | −4.85..−2.69% |
| Generator/list/render,16,384values | Warm Run | −15.72..−5.96% | −13.19..−8.05% |
| Same generator/list script | Compile and Run once | −9.28..−5.19% | −12.67..−6.22% |
| Numeric report control,4,096records | Warm Run | −0.81..+6.65% | −2.79..+6.90% |
| CSV invoice control,4,096rows | Warm Run | −0.53..+1.63% | −0.87..+0.88% |

All four pairings of two process medians/source retained; negative means faster.
Normalization/report/generator outcomes favor the candidate with supporting CPU.
Numeric reference/candidate movement4.96/2.44%limits attribution; do not claim
absence of regression. Generator warm controls move5.53/5.73%, so precise magnitude
is uncertain. CSVroughly flat. Retain the coherent storage/engine simplification
and affected-script gains with that explicit uncertainty; no further unchanged
retiming. Earlier partial shapes and adverse controls remain [preserved](../2026-11-16-generator-batches/README.md).

Allocation is essentially flat (largest absolute change<0.03%). Conservative
per-capacity scalar headroom raises the tuple-report accounted peak3,577,427→
4,000,049B (11.81%). Larger scalar estimates remain funded. Some supplied allowances
can refuse earlier; no default cap, new configuration or exact tiny-budget contract.
Private builder metadata, retained capacity and replacement overlap stay admitted;
cleanup restores the shared allowance independently of physical CLR collection.

The report variant materializes tuple(render(record) for record in records) before
writing its existing header/lines. Input JSON, renderer, stdout and file goldens
are reused and checked with CPython. This is an ordinary additional script shape,
not a causal comparison to the old script's streaming error order. B866 requests
warm/compile-run, which invoke **Run**. The case name ending.async and runAsync
catalog metadata did not change that worker lane. Initial async timing labels
were corrected before commitment; allocation diagnostics explicitly call both
APIs. Use the existing warm-async lane for the separate supplemental check; no
new worker protocol/framework is needed. No async compile-to-result timing claimed.

Quiet AzureF4as_v7 Ubuntu24.04.4,four EPYC9V45vCPUs,16GiB/no swap,.NET11RC3,
normal tiering/natural workstation GC. Seven jobs214.280s;4s full-request warmup,
five rotated~0.5s samples/process. Warm includes Run, mediated RAM I/O, full stdout/
file goldens and prior-result cleanup; excludes compile/startup/reset/protocol/
final-cache teardown. Fresh includes compilation and compiled-owner disposal;
CPU clocks are wider. All identity/golden/quiet/Closed/exit/join/archive gates pass.
Evidence SHA-verified persistently under lease before RAM teardown; no users remain.
Terminal cached permanently. Only an exact committed superseded4fc worker core
was retired after fresh ownership/path/hash/all-inode-alias proof; selected images,
toolchains/canonical evidence and254/252MiB staging/final floors preserved.
No new CPython timing/RSS/embedding-tail claim.

Actual Windows.NET11/10 each277public/172internal focused cases pass before and
after promotion; full nonincremental Release solution builds with zero warnings/
errors. Nine frozen-worker/CPython goldens pass. New cases cover aliases, late errors,
exact/grown/trimmed storage, live list backing mutation and actual delayed I/O.
Final-array refusal occurs before allocation while another owner's funding remains
intact. A foreign generator previously ran a visible after effect despite consumer
cancellation; the same-authority eligibility guard now preserves per-pull checks
and leaves that independent source usable. Both original failing rows are retained.

Two exact-charge assertions were updated to require the old payload floor, bounded
linear headroom, exact balances and aliases; tight positive factory tests/refusal
checks remain. No timeout or containment assertion relaxed. Original charge failures,
new test compile corrections and constructor-overload ambiguity are archived.

[Results](summary.json),[allocation](allocation-summary.json),[decision/checks](validation.json),
[frozen inputs/images](identity.json),[source](candidate-sources.tar.xz),
[exact core](measured-core.tar.xz),[raw evidence](observations.tgz),
[all focused logs/failures](focused-checks.tgz),[procedures/custody](procedures.tgz).
''',encoding='utf-8')
p=repo/'docs/BENCHMARKS.md';s=p.read_text(encoding='utf-8').replace('async report2–5%lower/warm','tuple report2–5%lower/warm');p.write_text(s,encoding='utf-8')
p=repo/'benchmarks/EXPERIMENTS.md';s=p.read_text(encoding='utf-8');s+='\n[R460 shared sequence construction/B866](results/2026-11-17-sequence-construction/README.md):\nretainedaaef443f removes async tuple staging/separate growth-scalar loop and shares\nexisting native capacity/rollback and generator consumption. Normalization warm9–12%,\ntuple report2–5%warm/4.7–4.8%fresh and generator-list6–16%warm/5–9%fresh lower elapsed\nwith CPU support. All timings use Run; catalog async flag did not select timed API,\nlabels corrected and supplemental warm-async check separate. Allocation flat; tuple\naccounted peak+11.81%, numeric uncertain/moving, CSVroughly flat. Each actualWindows\n11/10 focused277public/172internal pass; foreign cancellation regression and final\ntrim refusal covered; all gates/join/archive pass. Full platform/stress/package\ndelivery next, no publication or claim that the broader objective is complete.\n';p.write_text(s,encoding='utf-8')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');a=s.index('## Active R458:');b=s.index('## Other independent redesign decisions',a)
s=s[:a]+'''## Current retained milestone: R458/R460 sequence construction

The partial R458 shapes remain historical evidence, not separate deliveries.
R460 completes the existing native sequence builder and shared generator-consumer
path: async tuple staging, separate growth/per-item scalar admissions and duplicate
append loops are removed. Exact buffers/funding transfer; trim copies admit full
overlap. Same-authority batching preserves current tokens, reentry, mutation,
exception state, terminal refusal and awaited cleanup. No new owner/controller.

[Retained source and evidence](benchmarks/results/2026-11-17-sequence-construction/README.md):
aaef443f against qualifiede92d, B866 seven jobs214s. Warm Run normalization9–12%,
tuple report2–5%, generator/list6–16%lower elapsed with CPU support; report fresh
about4.7–4.8%lower. Allocation flat; tuple accounted peak+11.81% is the documented
conservative-headroom tradeoff. Numeric uncertain with moving controls; CSVroughly
flat. Accept this explicit debt, not a universal speedup or absence-of-regression
claim. No unchanged retiming. Both actualWindows targets focused277public/172internal
pass before/after promotion; full nonincremental Release solution clean.

Next delivery work: commit and batch full Windows/Ubuntu actual.NET11/10, original
stress and installed Release consumers once; cache terminal/logs permanently.
Complete a small warm-async supplemental check: B866's catalog async flag did not
select the timed API, so all its timing labels are corrected to Run. Reuse the
existing warm-async lane without a new protocol. Then refresh representative
CPython compilation/warm/fresh comparisons at this coherent checkpoint, keeping
I/O/cleanup boundaries and moving/adverse evidence explicit. Publication held.
Continue the independent call/frame/frontend roadmap after this delivery boundary.

'''+s[b:];p.write_text(s,encoding='utf-8')
print('Retained evidence/current contracts recorded with synchronous timing correction.')
