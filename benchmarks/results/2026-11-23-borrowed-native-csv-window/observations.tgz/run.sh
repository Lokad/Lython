set -eu
root=/home/lokad/lython-bench-checks/borrowed-native-csv-window-b1448-20261123
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
