from pathlib import Path

tree = Path(".git/agent-worktrees/csv-read-lifetime-20261123/src/Lokad.Lython/Runtime")
def edit(name, change):
    p = tree/name
    raw=p.read_bytes()
    value=raw.decode("utf-8").replace("\r\n","\n")
    changed=change(value)
    assert value!=changed
    p.write_bytes(changed.replace("\n","\r\n" if b"\r\n" in raw else "\n").encode("utf-8"))
def replace(text,old,new,count=1):
    assert text.count(old)==count, (old[:100],text.count(old))
    return text.replace(old,new)

def source(s):
    s=replace(s, """                var before = _parser.InputBuffer.Length;
                bool read;
                try { read = file.ReadLineInto(_parser.InputBuffer); }
                catch { _parser.ResetRecord(); throw; }
                if (!read) return FinishUnpackedAsync(destination).GetAwaiter().GetResult();
                var count = UnpackNativeLine(before, destination.Span);
""","""                int count;
                try { count = file.ReadCsvLine(this, destination, asynchronous: false).GetAwaiter().GetResult(); }
                catch { _parser.ResetRecord(); throw; }
                if (count == EndOfNativeInput) return FinishUnpackedAsync(destination).GetAwaiter().GetResult();
""")
    s=replace(s, """                var before = _parser.InputBuffer.Length;
                bool read;
                try { read = await file.ReadLineIntoAsync(_parser.InputBuffer).ConfigureAwait(false); }
                catch { _parser.ResetRecord(); throw; }
                if (!read) return await FinishUnpackedAsync(destination).ConfigureAwait(false);
                var count = UnpackNativeLine(before, destination.Span);
""","""                int count;
                try { count = await file.ReadCsvLine(this, destination, asynchronous: true).ConfigureAwait(false); }
                catch { _parser.ResetRecord(); throw; }
                if (count == EndOfNativeInput) return await FinishUnpackedAsync(destination).ConfigureAwait(false);
""")
    s=replace(s, """                    var before = _parser.InputBuffer.Length;
                    bool read;
                    try { read = await _nativeFile.ReadLineIntoAsync(_parser.InputBuffer).ConfigureAwait(false); }
                    catch { _parser.ResetRecord(); throw; }
                    if (!read) await FinishExhaustedAsync().ConfigureAwait(false);
                    else FeedNativeLine(before);
""","""                    int count;
                    try { count = await _nativeFile.ReadCsvLine(this, null, asynchronous: true).ConfigureAwait(false); }
                    catch { _parser.ResetRecord(); throw; }
                    if (count == EndOfNativeInput) await FinishExhaustedAsync().ConfigureAwait(false);
""")
    s=replace(s, """                var before = _parser.InputBuffer.Length;
                bool read;
                try { read = _nativeFile.ReadLineInto(_parser.InputBuffer); }
                catch { _parser.ResetRecord(); throw; }
                if (!read) FinishExhausted();
                else FeedNativeLine(before);
""","""                int count;
                try { count = _nativeFile.ReadCsvLine(this, null, asynchronous: false).GetAwaiter().GetResult(); }
                catch { _parser.ResetRecord(); throw; }
                if (count == EndOfNativeInput) FinishExhausted();
""")
    a,b=s.index("        private void FeedNativeLine"),s.index("        private void FeedPulledLine")
    s=s[:a]+"""        internal const int EndOfNativeInput = -2;
        internal GovernedByteBuilder NativeLineBuffer => _parser.InputBuffer;
        internal bool CanBorrowNativeLine => _parser.CanDescribeLiteralRecord;

        internal int ConsumeStagedNativeLine(int before, Memory<ExecutableSlot>? destination)
        {
            _context.CheckExecution(_span);
            PhysicalLineCount++;
            return _parser.ConsumeStagedLine(before, destination);
        }

        internal int ConsumeBorrowedNativeLine(ReadOnlySpan<byte> line, Memory<ExecutableSlot>? destination)
        {
            _context.CheckExecution(_span);
            PhysicalLineCount++;
            return _parser.ConsumeBorrowedLine(line, destination);
        }

"""+s[b:]
    s=replace(s, """        internal void FeedOwnedLine(int before)
        {
            if (DescribeOwnedLine(before)) EmitRecord(_record.WrittenSpan);
        }

        internal int UnpackOwnedLine(int before, Span<ExecutableSlot> destination)
            => DescribeOwnedLine(before) ? UnpackRecord(destination) : -1;
""","""        internal int ConsumeStagedLine(int before, Memory<ExecutableSlot>? destination)
            => DescribeOwnedLine(before) ? PublishRecord(_record.WrittenSpan, destination) : -1;

        private int PublishRecord(ReadOnlySpan<byte> source, Memory<ExecutableSlot>? destination)
        {
            if (destination is { } slots) return UnpackRecord(source, slots.Span);
            EmitRecord(source);
            return -1;
        }
""")
    s=replace(s,"        private bool CanDescribeLiteralRecord","        internal bool CanDescribeLiteralRecord")
    a,b=s.index("        internal void Feed(PyString text)"),s.index("        private bool DescribeLine")
    old=s[a:b]
    old_prefix=old[:old.index("            // Retain only")]
    assert "EmitRecord(line);" in old_prefix
    old_tail=old[old.index("            // Retain only"):]
    old_tail=replace(old_tail,
        "            if (ResumeRecordAtField(line, nextField)) EmitRecord(_record.WrittenSpan);",
        "            return ResumeRecordAtField(line, nextField) ? PublishRecord(_record.WrittenSpan, destination) : -1;")
    s=s[:a]+"""        internal void Feed(PyString text)
        {
            if (CanDescribeLiteralRecord) _ = ConsumeBorrowedLine(text.Utf8Span, null);
            else Feed(text.Utf8Span);
        }

        internal int ConsumeBorrowedLine(ReadOnlySpan<byte> line, Memory<ExecutableSlot>? destination)
        {
            if (TryDescribeLiteralRecord(line, out var nextField)) return PublishRecord(line, destination);

"""+old_tail+s[b:]
    s=replace(s,"=> DescribeEndOfInput() ? UnpackRecord(destination) : -1;",
                 "=> DescribeEndOfInput() ? UnpackRecord(_record.WrittenSpan, destination) : -1;")
    s=replace(s,"private int UnpackRecord(Span<ExecutableSlot> destination)",
                 "private int UnpackRecord(ReadOnlySpan<byte> source, Span<ExecutableSlot> destination)")
    return replace(s,"                    var source = _record.WrittenSpan;\n","")

def handle(s):
    a,b=s.index("            internal bool ReadLineInto("),s.index("            public PyList ReadLines()")
    return s[:a]+"""            internal ValueTask<int> ReadCsvLine(CsvRecordSource source, Memory<ExecutableSlot>? destination, bool asynchronous)
            {
                EnsureOpen();
                return RequireReader().ReadCsvLine(source, destination, asynchronous);
            }

"""+s[b:]

def reader(s):
    a,b=s.index("            // Native consumers own their destination"),s.index("            private ValueTask<PyString> ReadLineCore")
    return s[:a]+"""            internal async ValueTask<int> ReadCsvLine(CsvRecordSource source, Memory<ExecutableSlot>? destination, bool asynchronous)
            {
                var buffer = source.NativeLineBuffer;
                var before = buffer.Length;
                BeginRead();
                var failed = true;
                try
                {
                    if (before == 0 && source.CanBorrowNativeLine && TryConsumeBufferedCsvLine(source, destination, out var fields))
                    {
                        failed = false;
                        return fields;
                    }
                    var read = ReadLineCore(-1, asynchronous, buffer);
                    if (asynchronous) _ = await read.ConfigureAwait(false);
                    else _ = read.GetAwaiter().GetResult();
                    failed = false;
                }
                finally
                {
                    if (asynchronous) await EndReadAsync(failed).ConfigureAwait(false);
                    else EndRead(failed);
                }

                return buffer.Length == before ? CsvRecordSource.EndOfNativeInput : source.ConsumeStagedNativeLine(before, destination);
            }

            private bool TryConsumeBufferedCsvLine(CsvRecordSource source, Memory<ExecutableSlot>? destination, out int fields)
            {
                fields = -1;
                var start = _windowConsumed;
                var bytes = _window.Span;
                if (start == bytes.Length) return false;
                var end = TextLineScanning.FindLineEndByte(bytes, start, _newline);
                if (end == bytes.Length && !EndsWithTerminator()) return false;

                // The active read defers window cleanup through parsing and
                // admission. Retained fields still receive independent payload.
                Advance(end);
                _services.CheckExecution(null);
                fields = source.ConsumeBorrowedNativeLine(bytes[start..end], destination);
                return true;
            }

"""+s[b:]
edit("LythonRuntime.CsvModule.cs",source)
edit("LythonRuntime.TextFileHandle.cs",handle)
edit("LythonRuntime.TextFileHandle.Read.cs",reader)
