from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[4]
tree=repo/".git/agent-worktrees/csv-native-borrow-probe-20261123"
source=tree/"src/Lokad.Lython/Runtime"
prev=lab.parent.parent/"csv-inline-descriptors-20261123/comparison-qualified"
known=json.loads((repo/"benchmarks/results/2026-11-23-csv-inline-descriptors/source.json").read_text(encoding="utf-8"))["imageFiles"]["reference"]
image=lab/"image"
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),DOTNET_HOST_PATH=str(dotnet),PATH=str(sdk)+os.pathsep+os.environ["PATH"])

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,s): p.write_text(s,encoding="utf-8",newline="\n")
def git(*args,cwd=tree): return subprocess.check_output(["git",*args],cwd=cwd)
def run(args,cwd,log):
    with (lab/log).open("w",encoding="utf-8") as out:
        subprocess.run(args,cwd=cwd,env=env,stdout=out,stderr=subprocess.STDOUT,check=True,timeout=100)

assert not git("status","--porcelain")
assert git("rev-parse","--short=9","HEAD").decode().strip()=="57654f61a"

files=[source/"LythonRuntime.CsvModule.cs",source/"LythonRuntime.TextFileHandle.Read.cs"]
original={p:p.read_bytes() for p in files}
counters=("NativeCompleteWindows","NativeIncompleteWindows","NativeCopiedBytes",
          "NativeLiteralComplete","NativeLiteralResume","NativeNoLiteral","BorrowedDecoderLines","BorrowedDecoderBytes","BorrowedLiteralComplete","BorrowedPrefixBytesCopied")
def edit(p,changes):
    s=original[p].decode("utf-8").replace("\r\n","\n")
    for old,new in changes:
        assert s.count(old)==1,(p.name,old)
        s=s.replace(old,new)
    write(p,s)

try:
    edit(files[0], [
        ("internal sealed partial class LythonRuntime\n{","internal sealed partial class LythonRuntime\n{\n"+
         "\n".join("    internal static long Diagnostic"+name+";" for name in counters)),
        ("return TryDescribeLiteralRecord(line, out var nextField) || ResumeRecordAtField(line, nextField);",
         """if (TryDescribeLiteralRecord(line, out var nextField))
                {
                    DiagnosticNativeLiteralComplete++;
                    return true;
                }
                DiagnosticNativeLiteralResume++;
                return ResumeRecordAtField(line, nextField);"""),
        ("            _record.Truncate(before);", "            DiagnosticNativeNoLiteral++;\n            _record.Truncate(before);"),
        ("if (TryDescribeLiteralRecord(line, out var nextField)) return PublishRecord(line, destination);",
         "if (TryDescribeLiteralRecord(line, out var nextField)) { DiagnosticBorrowedLiteralComplete++; return PublishRecord(line, destination); }"),
        ("                _record.Advance(prefix.Length);", "                DiagnosticBorrowedPrefixBytesCopied += prefix.Length;\n                _record.Advance(prefix.Length);"),
    ])
    edit(files[1], [
        ("                fields = source.ConsumeBorrowedNativeLine(bytes[start..end], destination);",
         "                DiagnosticBorrowedDecoderLines++;\n                DiagnosticBorrowedDecoderBytes += end - start;\n"
         "                fields = source.ConsumeBorrowedNativeLine(bytes[start..end], destination);"),
        ("if (end < bytes.Length || EndsWithTerminator() || remaining == 0)\n                {",
         """if (end < bytes.Length || EndsWithTerminator() || remaining == 0)
                {
                    if (!ownsBuilder)
                    {
                        DiagnosticNativeCompleteWindows++;
                        DiagnosticNativeCopiedBytes += end - _windowConsumed;
                    }"""),
        ("                builder ??= new GovernedByteBuilder(_services.MemoryGovernor, null);\n                AppendRange(builder, _windowConsumed, bytes.Length);",
         """                if (!ownsBuilder)
                {
                    DiagnosticNativeIncompleteWindows++;
                    DiagnosticNativeCopiedBytes += bytes.Length - _windowConsumed;
                }
                builder ??= new GovernedByteBuilder(_services.MemoryGovernor, null);
                AppendRange(builder, _windowConsumed, bytes.Length);"""),
    ])
    (lab/"instrumentation.patch").write_bytes(git("diff","--binary","--","src"))
    run([dotnet,"build","src/Lokad.Lython/Lokad.Lython.csproj","-c","Release","-f","net11.0","--no-incremental",
         "--artifacts-path",lab/"build"],tree,"build.log")
finally:
    for p,b in original.items(): p.write_bytes(b)
assert not git("status","--porcelain")
ref=prev/"frozen-reference"
assert len(known)==32 and {name:sha(ref/name) for name in known}==known
image.mkdir(exist_ok=True)
for name in known:
    shutil.copyfile(lab/"build/bin/Lokad.Lython/release_net11.0"/name if name=="Lokad.Lython.dll" else ref/name,image/name)
actual={name:sha(image/name) for name in known}
assert [name for name in known if known[name]!=actual[name]]==["Lokad.Lython.dll"]
write(lab/"image.json",json.dumps(actual,indent=2)+"\n")

runner=lab/"runner"
template=lab.parent.parent/"text-target-publication-20261122/counter/Program.cs"
text=template.read_text(encoding="utf-8")
text=text.replace("var rows = new List<object>();", """var rows = new List<object>();
var names = new[] { %s };
var runtime = typeof(LythonEngine).Assembly.GetType("Lokad.Lython.Runtime.LythonRuntime", true)!;
var fields = names.Select(name => runtime.GetField("Diagnostic" + name, all)!).ToArray();
""" % ", ".join(json.dumps(name) for name in counters))
text=text.replace("        Run();", "        foreach (var field in fields) field.SetValue(null, 0L);\n        Run();")
a,b=text.index("        var type"),text.index("        script.Dispose();")
text=text[:a]+"""        rows.Add(new { id = item.GetProperty("id").GetString(), asynchronous, peakExecutionMemoryBytes,
            compiledReservedBytes = baseline, sharedBudgetBaselineRestored = true,
            counts = names.Zip(fields).ToDictionary(pair => pair.First, pair => (long)pair.Second.GetValue(null)!),
            coreSha256 = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(
                File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))).ToLowerInvariant() });
""" + text[b:]
text=text.replace("    script.Dispose();", "    script.Dispose();")
text=text.replace("One verified complete run. Scratch instrumented core counts prepared-loop entries and normal final-word publications. No comparative timings.","One golden-verified execution per case. Count text-window copies and CSV parser boundaries. No timing comparison.")
write(runner/"Program.cs",text)
write(runner/"CsvWindowProbe.csproj",'''<Project Sdk="Microsoft.NET.Sdk">
<PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net11.0</TargetFramework><ImplicitUsings>enable</ImplicitUsings><Nullable>enable</Nullable></PropertyGroup>
<ItemGroup>
<Reference Include="Lokad.Lython"><HintPath>../image/Lokad.Lython.dll</HintPath></Reference>
<Reference Include="Lokad.Lython.Utf8Regex"><HintPath>../image/Lokad.Lython.Utf8Regex.dll</HintPath></Reference>
<Reference Include="Lokad.Utf8Regex.PythonRe"><HintPath>../image/Lokad.Utf8Regex.PythonRe.dll</HintPath></Reference>
</ItemGroup></Project>
''')
run([dotnet,"build",runner/"CsvWindowProbe.csproj","-c","Release","--no-incremental"],runner,"runner-build.log")
for p in (runner/"bin/Release/net11.0").glob("CsvWindowProbe.*"): shutil.copyfile(p,image/p.name)
run([dotnet,image/"CsvWindowProbe.dll",image,prev/"representative.json",lab/"counts.json"],repo,"run.log")
assert {name:sha(image/name) for name in known}==actual
print((lab/"counts.json").read_text(encoding="utf-8"))
