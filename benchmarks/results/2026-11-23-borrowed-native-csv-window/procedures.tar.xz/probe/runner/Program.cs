using System.Reflection;
using System.Diagnostics;
using System.Text;
using System.Text.Json;
using Lokad.Lython;
using Lokad.Lython.Utf8Regex;

// Existing complete scripts and comparison host; allocation counters only.
// This tool performs no collection and does not claim local elapsed/CPU evidence.
var image = Path.GetFullPath(args[0]);
var catalogPath = Path.GetFullPath(args[1]);
var output = Path.GetFullPath(args[2]);
if (File.Exists(output)) throw new IOException("Preserve original observations.");
var assembly = Assembly.LoadFrom(Path.Combine(image, "Lokad.Lython.Benchmarks.dll"));
const BindingFlags all = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;
var fixtureType = assembly.GetType("Lokad.Lython.Benchmarks.Comparison.ComparisonFileFixture", true)!;
var hostType = assembly.GetType("Lokad.Lython.Benchmarks.Comparison.ComparisonFileHost", true)!;
var plainHostType = assembly.GetType("Lokad.Lython.Benchmarks.Comparison.ComparisonHost", true)!;
var parse = fixtureType.GetMethod("Parse", all)!;
var reset = hostType.GetMethod("Reset", all)!;
var check = hostType.GetMethod("ReadOutputs", all)!;
var digest = fixtureType.GetMethod("Digest", all)!;
using var catalog = JsonDocument.Parse(File.ReadAllText(catalogPath, Encoding.UTF8));
var rows = new List<object>();
var names = new[] { "NativeCompleteWindows", "NativeIncompleteWindows", "NativeCopiedBytes", "NativeLiteralComplete", "NativeLiteralResume", "NativeNoLiteral", "BorrowedDecoderLines", "BorrowedDecoderBytes", "BorrowedLiteralComplete", "BorrowedPrefixBytesCopied" };
var runtime = typeof(LythonEngine).Assembly.GetType("Lokad.Lython.Runtime.LythonRuntime", true)!;
var fields = names.Select(name => runtime.GetField("Diagnostic" + name, all)!).ToArray();

foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var source = item.GetProperty("source").GetString()!;
    var asynchronous = item.TryGetProperty("runAsync", out var mode) && mode.GetBoolean();
    var expected = item.GetProperty("expectedOutput").GetString()!;
    var fixture = parse.Invoke(null, [item.GetProperty("fixtureJson").GetString()]);
    var folder = Path.Combine(Path.GetTempPath(), "lython-comparison-files-" + Guid.NewGuid().ToString("N"));
    var budget = new LythonMemoryBudget(256L * 1024 * 1024);
    var host = fixture is null ? (ILythonHost)Activator.CreateInstance(plainHostType, nonPublic: true)!
        : (ILythonHost)Activator.CreateInstance(hostType, all, null, [fixture, folder], null)!;
    try
    {
        var compileBefore = GC.GetTotalAllocatedBytes(precise: true);
        var compileStarted = Stopwatch.GetTimestamp();
        using var script = new LythonEngine(Utf8RegexProvider.Instance).Compile(source, budget);
        var compilationMillisecondsDiagnostic = Stopwatch.GetElapsedTime(compileStarted).TotalMilliseconds;
        var compilationAllocatedBytesDiagnostic = GC.GetTotalAllocatedBytes(precise: true) - compileBefore;
        if (!script.IsValid) throw new InvalidOperationException(string.Join("|", script.Diagnostics));
        var baseline = budget.ReservedBytes;
        long peakExecutionMemoryBytes = 0;
        void Run()
        {
            if (fixture is not null) reset.Invoke(host, null);
            using (var result = asynchronous ? script.RunAsync(host).GetAwaiter().GetResult() : script.Run(host))
            {
                if (!result.Success || result.StandardOutput != expected || result.StandardError != "")
                    throw new InvalidDataException(result.Failure?.Message ?? result.StandardOutput);
                peakExecutionMemoryBytes = Math.Max(peakExecutionMemoryBytes, result.PeakExecutionMemoryBytes);
                if (fixture is not null)
                {
                var files = check.Invoke(host, null);
                var actualFiles = (string)digest.Invoke(null, [files])!;
                if (actualFiles != item.GetProperty("expectedFilesSha256").GetString())
                    throw new InvalidDataException("File golden mismatch.");
                }
            }
            if (budget.ReservedBytes != baseline) throw new InvalidOperationException("Ownership did not return to compilation baseline.");
        }
        foreach (var field in fields) field.SetValue(null, 0L);
        Run();
        rows.Add(new { id = item.GetProperty("id").GetString(), asynchronous, peakExecutionMemoryBytes,
            compiledReservedBytes = baseline, sharedBudgetBaselineRestored = true,
            counts = names.Zip(fields).ToDictionary(pair => pair.First, pair => (long)pair.Second.GetValue(null)!),
            coreSha256 = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(
                File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))).ToLowerInvariant() });
        script.Dispose();
        if (budget.ReservedBytes != 0) throw new InvalidOperationException("Compiled owner retained allowance.");
    }
    finally
    {
        (host as IDisposable)?.Dispose();
        var full = Path.GetFullPath(folder);
        if (Path.GetDirectoryName(full) != Path.GetFullPath(Path.GetTempPath()).TrimEnd(Path.DirectorySeparatorChar) ||
            !Path.GetFileName(full).StartsWith("lython-comparison-files-", StringComparison.Ordinal))
            throw new InvalidOperationException("Unexpected owned fixture path.");
        if (Directory.Exists(full)) Directory.Delete(full, recursive: true);
    }
}
File.WriteAllText(output, JsonSerializer.Serialize(new { assembly = typeof(LythonEngine).Assembly.FullName, rows,
    boundary = "One golden-verified execution per case. Count text-window copies and CSV parser boundaries. No timing comparison." }, new JsonSerializerOptions { WriteIndented = true }), new UTF8Encoding(false));

