from pathlib import Path
import base64, hashlib, importlib.util, itertools, json, os, subprocess, tempfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
pair=lab/"comparison"
out=lab/"semantics"
out.mkdir()
def read(p): return json.loads(p.read_text(encoding="utf-8"))
def sha(data): return hashlib.sha256(data).hexdigest()
def digest(p): return sha(p.read_bytes())
def save(p,value): p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
protocol=repo/"benchmarks/cpython-worker.py"
spec=importlib.util.spec_from_file_location("proto",protocol)
proto=importlib.util.module_from_spec(spec)
spec.loader.exec_module(proto)
identity=read(pair/"identity.json")
assert digest(protocol)==identity["protocolSHA256"]
catalog=read(pair/"representative.json")
template=catalog["cases"][0]
python=Path("C:/Python313/python.exe")

fields=["a","","8","\"a,b\"","\"a\"\"b\"","\"a\"x","\"a","🌷","٠.٢٥","space ","“a,b“"]
combinations=list(itertools.product(fields,fields[:7],("\n","\r\n","\r")))
matrix={}
for index,(head,tail,terminator) in enumerate(combinations):
    suffix="end\"\n" if index%3==0 else "\"tail\n" if index%3==1 else "last,cell"
    text='\"prime\",0'+terminator+head+","+tail+terminator+suffix
    matrix[f"row-{index}.csv"]=text.encode("utf-8")
assert len(matrix)==231
matrix_source="""import csv
options = [{}, {"strict": True}, {"quotechar": "“"}, {"quoting": csv.QUOTE_NONNUMERIC},
    {"doublequote": False, "escapechar": "\\\\"}, {"skipinitialspace": True}]
for item in range(@START@, @END@):
    for setting in options:
        with open("row-" + str(item) + ".csv", newline="") as file:
            reader = csv.reader(file, **setting)
            for step in range(3):
                try:
                    print(next(reader), reader.line_num)
                except (csv.Error, ValueError, StopIteration) as error:
                    print(type(error).__name__, reader.line_num)
"""
aligned=(
    "first,head\r\nretained " + "é😀"*20 + ",value\r\n" +
    "cross,\""+ "μ"*9500 + "\r\ncontinued\"\r\nbefore,tail\r\nlast,no-newline")
boundary={"window.csv":aligned.encode("utf-8")}
boundary_source="""import csv
with open("window.csv", newline="") as file:
    reader = csv.reader(file)
    print(next(reader), reader.line_num)
    saved = next(reader)
    print(len(saved[0]), saved[1], reader.line_num)
    for left, right in reader:
        print(left, len(right), right.endswith("continued"), reader.line_num)
    print(file.readline() == "")
print(saved[0], saved[1])
"""
cases=[]
specimens=[]
for start in range(0,len(matrix),64):
    end=min(len(matrix),start+64)
    source=matrix_source.replace("@START@",str(start)).replace("@END@",str(end))
    specimens.append((f"native-grammar-{start}",source,{f"row-{i}.csv":matrix[f"row-{i}.csv"] for i in range(start,end)}))
specimens.append(("native-window-boundaries",boundary_source,boundary))
for name, source, files in specimens:
    with tempfile.TemporaryDirectory(prefix="lython-native-csv-verify-") as tmp:
        root=Path(tmp)
        for name_in,content in files.items(): (root/name_in).write_bytes(content)
        (root/"script.py").write_text(source,encoding="utf-8",newline="\n")
        result=subprocess.run([python,"-I","-S","-X","utf8","script.py"],cwd=root,capture_output=True,
                              check=True,timeout=20)
        assert not result.stderr
    output=result.stdout.decode("utf-8").replace("\r\n","\n")
    size=sum(map(len,files.values()))
    fixture=json.dumps(dict(size=size,text=None,inputFiles={n:base64.b64encode(v).decode("ascii") for n,v in files.items()},
                        outputFiles={}),separators=(",",":"))
    cases.append(dict(template,id="diagnostic."+name,size=size,source=source,fixtureJson=fixture,
            expectedOutput=output,sourceUtf8Bytes=len(source.encode("utf-8")),expectedOutputUtf8Bytes=len(output.encode("utf-8")),
            sourceSha256=sha(source.encode("utf-8")),fixtureSha256=sha(fixture.encode("utf-8")),
            expectedOutputSha256=sha(output.encode("utf-8")),expectedFilesSha256=proto.file_digest({})))
    print(name,len(files),"files",len(output.splitlines()),"observable outcomes",flush=True)
path=out/"catalog.json"
save(path,{**catalog,"cases":cases})
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
for role, files in identity["imageFiles"].items():
    image=pair/("frozen-"+role)
    assert {n:digest(image/n)for n in files}==files
    proof=out/f"{role}-verify.json"
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",path,
        "--dotnet",dotnet,"--python",python,"--python-worker",protocol,"--out",proof],check=True,cwd=repo,
        env=env,timeout=90)
    result=read(proof)
    assert result["state"]=="Completed" and result["caseCount"]==len(specimens) and result["catalogSha256"]==digest(path)
    assert {n:digest(image/n)for n in files}==files
