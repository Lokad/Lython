from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,tarfile,textwrap

r=Path(__file__).parent
old=r.parent/'protected-activation-r368'
base=json.loads((r/'baseline.json').read_text(encoding='utf-8'))
checks=json.loads((r/'focused-checks.json').read_text(encoding='utf-8'))
assert len(checks)==4 and all(x['exitCode']==0 for x in checks)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
sources={n:sha(n) for n in base['sources']}
changed=[n for n in sources if sources[n]!=base['sources'][n]]
assert changed==['src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs']
env={k:v for k,v in os.environ.items() if k.upper()!='PATH'}
sdk='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_ROOT']=sdk
env['PATH']=sdk+';C:/Python313;'+next(v for k,v in os.environ.items() if k.upper()=='PATH')
with (r/'freeze-build.log').open('w',encoding='utf-8',newline='\n') as log:
    done=subprocess.run([sdk+'/dotnet.exe','build','tools/LythonProbe/LythonProbe.csproj','-c','Release','-f','net11.0','--no-restore','--no-incremental','--disable-build-servers','-m:1','-v','quiet'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert done.returncode==0 and all(sha(n)==h for n,h in sources.items())
for role in ['reference','candidate']:shutil.copytree(old/'candidate',r/role)
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'candidate/Lokad.Lython.dll')
shutil.copyfile(r/'candidate/Lokad.Lython.dll',r/'candidate-core.dll')
assert sha(r/'reference/Lokad.Lython.dll')==base['coreSHA256']
oldIdentity=json.loads((old/'b756/identity.json').read_text(encoding='utf-8'))
assert all(sha(r/role/n)==h for role in ['reference','candidate'] for n,h in oldIdentity['auxiliaryFiles'].items())
identity=dict(headBeforeCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),runtimeBaseCommit='1c5af53928a2675994ad83f913496154405c7c31',sources=sources,productionFiles=len(sources),changedProductionInputs=changed,coreSHA256={role:sha(r/role/'Lokad.Lython.dll') for role in ['reference','candidate']},auxiliaryFiles=oldIdentity['auxiliaryFiles'],frozenFiles={role:{p.name:sha(p) for p in (r/role).iterdir() if p.is_file()} for role in ['reference','candidate']},removedWork='One repeated physical stack check inside NativeExecution.Run after immediate synchronous StartInline function admission.',preserved='Existing managed stack checks on actual function/interpreter/continuation entries, logical recursion/nesting bounds, first refusal/cancellation, ownership and exact-fault transfer. No new mode or stack API.',qualified=False)
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz') as t:
    for n in sources:t.add(n,arcname=n)
catalog=json.loads((old/'catalog.json').read_text(encoding='utf-8'))
protected=json.loads((r.parent/'protected-helper-r367/catalog.json').read_text(encoding='utf-8'))
seen={c['id'] for c in catalog['cases']}
catalog['cases'] += [c for c in protected['cases'] if c['id'] not in seen]
(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
(r/'allocation-catalog.json').write_bytes((r.parent/'protected-helper-r367/catalog.json').read_bytes())
# Adapt the established semantic worker verifier to the newly frozen image.
code=(r.parent/'protected-helper-r367/verify.py').read_text(encoding='utf-8')
code=code.replace("frozen=r.parent/'native-call-transport-r365/candidate'", "frozen=r/'candidate'").replace("identity.json", "candidate-identity.json")
code=code.replace("catalog=(r/'catalog.json').resolve()", "identity['catalogSHA256']=hashlib.sha256((r/'allocation-catalog.json').read_bytes()).hexdigest()\ncatalog=(r/'allocation-catalog.json').resolve()")
(r/'verify.py').write_text(code,encoding='utf-8',newline='\n')
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'verify.py')],env=env,check=True)
controls=json.loads((old/'python-control-sources.json').read_text(encoding='utf-8'))
test=Path('tests/Lokad.Lython.PublicApi.Tests/ProtectedHelperExecutionTests.cs').read_text(encoding='utf-8')
added=[textwrap.dedent(s)+'\n' for s in re.findall(r'yield return \["[^"]+", """\n(.*?)\n\s*""",',test,re.S)]
assert len(added)==11,len(added)
controls += [value for value in added if value not in controls]
(r/'python-control-sources.json').write_text(json.dumps(controls,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
probe=Path('tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll').resolve()
assert sha(probe.parent/'Lokad.Lython.dll')==identity['coreSHA256']['candidate']
records=[]
for asynchronous in [False,True]:
    done=subprocess.run([sdk+'/dotnet.exe',str(probe),'--batch-json','--compare-python','--python','C:/Python313/python.exe']+(['--async'] if asynchronous else []),input=json.dumps(controls).encode('utf-8'),capture_output=True,env=env,timeout=60)
    (r/('python-controls-'+str(asynchronous)+'.jsonl')).write_bytes(done.stdout)
    (r/('python-controls-'+str(asynchronous)+'.stderr')).write_bytes(done.stderr)
    assert done.returncode==0,(done.stdout+done.stderr).decode('utf-8')[-2500:]
    records.append(dict(asynchronous=asynchronous,cases=len(controls),matched=True))
    print(asynchronous,len(controls),'isolated CPython controls match',flush=True)
(r/'python-controls.json').write_text(json.dumps(dict(complete=True,coreSHA256=identity['coreSHA256']['candidate'],controls=records,python='Isolated CPython3.13.2'),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Frozen active R369 prototype; qualification/retention still pending.',identity['coreSHA256'],flush=True)
