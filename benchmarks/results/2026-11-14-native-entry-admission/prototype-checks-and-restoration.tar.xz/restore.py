from pathlib import Path
import hashlib,json,os,shutil,subprocess,xml.etree.ElementTree as ET

r=Path(__file__).parent
baseline=json.loads((r/'baseline.json').read_text(encoding='utf-8'))
candidate=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==h for n,h in candidate['sources'].items())
Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs').write_bytes((r/'NativePrefix-original.cs').read_bytes())
assert all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==h for n,h in baseline['sources'].items())
proof=dict(restoredRuntime='3994dfda/frozenb5a6426e source',all582ProductionInputsExactlyRestored=True,withdrawnCore=candidate['coreSHA256']['candidate'],retained='Real low-stack native function invocation case in ManagedStackGuardTests; no guard-count or exact-checkpoint assertion.',decision='Withdraw optional one-check deletion: whole-script CPU effect uncertain, no complete packaging/activation bridge removed, existing body-level physical guard remains self-contained. Search6.06%reference spread/short CPU -.25..+4.20% and all controls retained. No inherent-regression claim or permanent design ban.',forceBuildAndFocusedChecksPending=True)
(r/'restoration.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
env={k:v for k,v in os.environ.items() if k.upper()!='PATH'};sdk='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_ROOT']=sdk;env['PATH']=sdk+';C:/Python313;'+next(v for k,v in os.environ.items() if k.upper()=='PATH')
checks=[]
for framework in ['net11.0','net10.0']:
    log=r/('restored-build-'+framework+'.log')
    with log.open('w',encoding='utf-8',newline='\n') as f:done=subprocess.run([sdk+'/dotnet.exe','build','tools/LythonProbe/LythonProbe.csproj','-c','Release','-f',framework,'--no-restore','--no-incremental','--disable-build-servers','-m:1','-v','quiet'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
    assert done.returncode==0,log.read_text(encoding='utf-8')[-2000:]
    name='r369-restored-'+framework+'.trx';log=r/('restored-checks-'+framework+'.log')
    with log.open('w',encoding='utf-8',newline='\n') as f:done=subprocess.run([sdk+'/dotnet.exe','test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f',framework,'--no-restore','--filter','(Category!=Stress)&(FullyQualifiedName~ManagedStackGuardTests|FullyQualifiedName~CasedSplitOwnershipTests)','--logger','trx;LogFileName='+name,'-v','quiet'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=120)
    p=Path('tests/Lokad.Lython.Tests/TestResults')/name;counts=ET.parse(p).find('.//{*}Counters').attrib if p.exists() else None
    if p.exists():shutil.copyfile(p,r/name)
    checks.append(dict(framework=framework,exitCode=done.returncode,counters=counts))
    (r/'restored-checks.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8',newline='\n')
    assert done.returncode==0,log.read_text(encoding='utf-8')[-2500:]
    print(framework,'forced restored build and',counts['passed'],'stack/cancellation/cleanup checks pass',flush=True)
assert all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==h for n,h in baseline['sources'].items())
proof.update(forceBuildAndFocusedChecksPending=False,checks=checks,priorRuntimeQualificationReused=True,noUnchangedTimingRepeat=True)
(r/'restoration.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
print('B5runtime restored exactly; independent new low-stack regression retained.',flush=True)
