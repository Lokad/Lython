# Lokad.Lython 0.11.0

Updated 2026-11-14. Git-ignored: never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance,
including compile-once/run-once. Individual experiments do not close this objective.
Current contracts belong in docs; historical evidence and rejected designs belong
in [EXPERIMENTS](benchmarks/EXPERIMENTS.md) and its immutable results.

## Actual delivery status

| Status | Delivered behavior and limits |
| --- | --- |
| Completed foundations | Shared compiler facts/nonlocal correction; lowered-tree retention cleanup; direct UTF8 formatting/storage; native helper returns; final argument slots/linear continuations; immutable plain builtins; native/owned loops and tuple returns; primitive working storage/shared arithmetic; CSV adoption/shared keys; UTF8 JSON/incremental XML. Preserve their fixes and cached qualification. |
| Closed earlier measurement gaps | Native returns: about 19–20% less allocation; original elapsed results remain diagnostic. Formatting: allocation −8.67%; [controlled confirmation](benchmarks/results/2026-11-02-formatting-confirmation/README.md) supports report elapsed/CPU −5–8%. Original adverse 15.125ms remains unexplained. Historical revisions, not HEAD claims. |
| Latest fully qualified baseline | `1c5af539` / frozen `ff2b5d76`, [43633423371 GREEN](benchmarks/results/2026-11-14-native-integer-workspace/delivery/README.md). Windows/Ubuntu actual .NET11/10, 4,775 internal +17,822 public ordinary and original 13/406 stress each; installed Release consumers. 582-input proof/16 summaries/full logs cached. Never requery terminal runs or repeat unchanged qualification. |
| Latest retained allocation change | [R365 workspace reuse](benchmarks/results/2026-11-14-native-integer-workspace/completion/README.md) removes per-wide-call arrays/reservation objects using the existing one-idle-cache policy. Fulfillment allocation −14.57%; warm CPU mixed, fresh modestly lower. Short calls retain elapsed +0.62–2.91%/CPU +1.22–2.71% debt. Cleanup refinement was completely withdrawn. No substantial CPU or embedding-latency claim. |
| Prior retained range work | R361/R362 keep per-run constructors and one explicit range state. [R362](benchmarks/results/2026-11-14-range-iteration-stage/refined/README.md): counter warm/fresh about 28–31% lower, allocation −99.52%; materialization allocation +1.26%. Original text +12.91% and bounded confirmation remain visible; cause unresolved. No neutrality, universal or cumulative claim. |
| External comparison | [B747 guide](docs/BENCHMARKS.md), exact earlier qualified `fa40d674`/`73a1b233` versus stock CPython3.13.16: invoice warm 1.26–1.31×, compile 1.07–1.09×, fresh 1.24–1.26×; text 1.45–1.50×, JSON 0.83–0.86×, search 1.61–1.69× variable, report 1.21–1.23× variable, fulfillment 1.26–1.29×, for-CSV 1.29–1.33×. Compilation, warm execution, mediated RAM I/O and cleanup boundaries explicit. Do not relabel these as today's HEAD. |
| Current source assessment | [R366/B754](benchmarks/results/2026-11-14-invocation-stage/README.md) finds host filesystem work dominates tiny config edits; no dominant removable builtin or scheduling stage established. Search retains material call/dispatch/iteration work. Direct iterator slots/shared decoded windows already exist. This assessment introduced no runtime change. |
| New whole-script source evidence | [R367/B755](benchmarks/results/2026-11-14-protected-helper-cost/README.md): on the same image/data, defensive try/except helpers add invoice elapsed 21.1–21.4% with stable controls/supporting CPU; search 63–78% with 7.87% protected-process spread. Separate allocation +41.23%/+294.91%; 16 independent source/phase goldens. Whole syntax cost, not isolated frame attribution. Evidence committed in `a4be4783`; R368 retained below, full delivery pending. |
| Current committed runtime | `3994dfda` / frozen `b5a6426e`, retained R368. Full **43640155007 active**; all 582 source inputs match committed bytes. One explicit stress-enabled run; push-trigger duplication skipped. [Source-pair evidence](benchmarks/results/2026-11-14-protected-helper-activation/README.md). B757 targeted CPython checkpoint complete; full runtime qualification still pending. |
| Withdrawn, not dormant | R360 frame scalar arrays, R364 merged activation, R365 cleanup refinement and R355 raw CSV ranges are removed. Keep adverse controls, independent semantics/lifetime/refusal fixes and contextual decisions. No permanent design ban; do not replay slower call arenas/controllers or the same R268 single-engine design unchanged. |

## Prioritized deliverables

1. **R368: remove eager activation from successful protected helpers.** R367's
   same-image complete-script comparison establishes material cost for eligible
   helpers containing try/except. Stable invoice controls suffice to select this
   stage; do not rerun merely to narrow variable search's magnitude. Compilation,
   fresh-script CPU and exceptional inputs remain unmeasured by that diagnostic.

   Keep final slots and existing exception regions. Permit the synchronous native
   prefix through normal try/except bodies; handler-only instructions need not
   disqualify the normal body. Transfer an actual fault at its exact PC to the
   existing pending-exception/handler path, without replaying the operation.
   Finally/with/generators keep their existing route in this bounded migration.
   Delete the blanket exception-region exclusion and its successful-path eager
   context/backing allocation. No second handler dispatcher, frame controller,
   fallback policy or new option. Preserve visible compiler defects. Do not
   repeat R268's wider single-engine migration or lose R361/R362/R365 benefits.
   **Retain b5a6426e** after [B756](benchmarks/results/2026-11-14-protected-helper-activation/README.md):
   protected invoice warm17–18.5%lower, fresh16–19%lower; search41–43%lower,
   supporting widerCPU; allocation−29.19%/−74.65%. Accept short+.48..+3.38%
   elapsed/+.74..+2.75%CPU debt for this milestone, preserve text uncertainty
   and final0.11debt decision. Actual11/10 each181internal+306public focused;
   final16protected checks each,124independentPythoncontrols/16goldens.
   Initial compile corrections/static-scope fixture rejection stay in evidence.
   No production changes after freeze. Commit `3994dfda` pushed; full **43640155007 active**,582-input proof cached;
   [B757](benchmarks/results/2026-11-14-protected-cpython-checkpoint/README.md)
   closes the targeted external gap: protected invoice warm1.24–1.28×CPython,
   compile1.05–1.07×,fresh1.24–1.25×; search1.64–1.66×. Fourjobs137.673s,
   all output/ownership/custody/quiet gates pass. Existing text/JSON/report/CSV
   rows retain fa40 explicitly; config retains cdd9. No current-HEAD relabeling,
   no publication and no whole-objective completion claim. Continue delivery
   without repeating the unchanged earlier nine-job collection.

   Acceptance: defaults/keywords/receivers and live default mutation, closures,
   aliases/is, exact integers/overflow, original evaluation/error order, handler
   context, return/break/finally cleanup, exact transfer PC, actual asynchronous
   callbacks, cancellation, managed stack and first-refusal propagation. Retained
   aliases and pending operations stay funded through awaited cleanup. A bounded
   complete affected/control before/after decides retention and explicit debt or
   full withdrawal. Temporary setbacks need a completion milestone, not an
   indefinite alternate backend. Preserve the evidence even if no design is selected.

2. **Continue the substantial execution/collection roadmap from evidence.**
   **R369 bounded entry-contract source gate:** current NativeExecution.Run checks
   the managed stack after the same synchronous StartInline path has just called
   EnterFunctionCall, which also checks it. Assess all native/bound entry callers
   and the actual managed safety boundary before proposing deletion of that
   duplicate check. Keep the supported managed policy, every genuine nesting and
   continuation admission, logical recursion/interpreter counts, cancellation and
   refusal. No native telemetry, unsafe code, new switch or guard-count policy.
   Source presence does not establish CPU dominance or permission to weaken safety.
   Stop at a supported required-guard explanation, or a concrete simplification
   validated by existing managed stack/recursion cases and one bounded complete
   search/protected-invoice/short/control comparison. Do not repeat R268/R364.
   This source gate may proceed while R368's CI runs; no blind broad frame rewrite.
   Source gate: the only production NativeExecution construction/Run caller is
   StartInline. Its EnterFunctionCall checks the same DefinitionContext before
   Run, with no suspension or guest operation between them. Direct/bound/native
   caller routes converge there. The synthetic CasedSplit ownership fixture
   directly drives Run only to model cancellation after kernel completion.
   R369 now prototypes deletion of Run's duplicate physical check; keep every
   logical nesting/recursion and continuation check. This is a small admission
   simplification, not a substitute for the substantial representative roadmap.
   VM now has267,259,904B free: another core image cannot fit above the unchanged
   254MiB staging floor. Before an actual prototype upload, retire only proven
   archived withdrawn-image aliases under the idle lease or expand storage;
   current b5/ff2 images, catalogs and toolchains must survive. No cleanup campaign
   is needed merely to perform this read-only gate.

   Call/frame work is selected only for a complete bridge removed. Final local
   and operand storage already shares one array; direct positional binding,
   receiver-independent methods, shared lookup caches and deferred contexts exist.
   Native operands materialize before helper binding, but invoice has only two
   private computed inputs; returned/aliased values are observable. Do not infer
   four inputs, missing slot transport or a universal tagged-value requirement.

   Bulk CSV's historical 6–8% observations missed rigid thresholds, not Python
   correctness. Current parser already bulk-admits fields/rows and adopts keys/
   storage. [R355 reassessment](benchmarks/results/2026-11-14-owned-csv-field-ranges/README.md)
   withdrew raw-field ranges for limited whole-script benefit and extra state/
   scratch retention; keep control regression and escaped/borrowed evidence. A
   revised per-record design must remove an actual remaining construction/copy
   stage without heuristics, retaining malformed-record timing, wide rows,
   aliases, cancellation, construction overlap and terminal refusal. Do not
   automatically promote the old prototype or repeat the same form unchanged.

   Remaining text/JSON conversions require an identified whole conversion/build
   stage and affected script. Current final tuple backing, UTF8 output, decoded
   file windows and bulk managed UTF16 transcoding already remove proposed copies.
   Preserve Unicode/context/expansion, hooks and reentry. Frontend shared facts
   and retention cleanup are complete; invoice compile around 0.1ms versus 7–8ms
   execution does not justify claiming analysis dominates. Select frontend work
   from a genuinely costly fresh-script shape, sharing facts rather than adding
   passes. No heavyweight JIT or new benchmark framework without owning evidence.

3. **Make a coherent 0.11 performance/debt decision.** Architectural simplification,
   allocation reduction and demonstrated CPU gains are separate deliverables.
   R359/R361/R365 short-helper debt and R362 materialization/text uncertainty stay
   open until an explicit final decision. New measurements must address changed
   source or a material unresolved question. Refresh representative CPython at the
   next substantial retained CPU milestone; reuse B747 until then. State exact
   source, reference/runtime/machine/date, compilation, startup, mediated I/O,
   validation and result/cache cleanup. Do not repeat an unchanged nine-job run.
   Quiet-VM complete scripts plus source/semantic acceptance decide useful
   retention; a fixed percentage cannot automatically veto a coherent design.

4. **Keep regex implementation independent.** The core owns Python semantics,
   native UTF8/original-subject windows, byte/scalar coordinates, captures/errors,
   explicit ownership and the current token. Development producers/adapter-local
   bridges are allowed; distinguish contract tests, semantic checks and backend
   performance. Optional adapter stays non-packable at0.4; completed dev80 checks
   are cached. [Assessment through 8af3a569](benchmarks/results/2026-11-14-regex-provider-capabilities/README.md)
   records only final released-adapter gaps: separate one-match scratch/escaping
   result owners, native UTF8 group-name enumeration/copy, and token-independent
   cursor creation with cancellable preparation. Search filtering cannot replace
   anchored/fullmatch. Cached state must not retain prior tokens. Missing producer
   APIs defer only affected final adapter qualification; no blanket stopping rule,
   unchanged producer qualification or core dependency/pin promotion.

## Evidence, validation and lasting constraints

Timeouts, unstable unchanged controls and inconclusive measurements establish
uncertainty, not a failed design. Bounded confirmation/refinement/measurement
correction is allowed when evidence justifies it. Preserve original failed
conditions and every adverse point. No one-attempt/no-retiming/permanent-closure
rule and no open-ended campaign. Finish each milestone with retention/debt,
supported withdrawal or explicit uncertainty; the whole-script objective continues.

Use focused Release correctness/cancellation/ownership checks during iteration.
Batch full Windows/Ubuntu, actual11/10, original stress and installed-package
consumers at meaningful retained boundaries. Force nonincremental builds after
restoration, freeze copies and prove source/image identity. Cache terminal CI;
space live queries240s apart. Verify persistent raw evidence under its lease before
RAM teardown. Preserve current images/catalog/toolchain and254/252MiB floors.
Startup, pending-I/O latency, contention, heap/RSS peaks and embedding tail latency
remain unmeasured; fewer allocations or full collections do not establish them.

[AGENTS.md](AGENTS.md) remains binding: fully managed/memory-safe; no unsafe,
Unsafe APIs, pointers, P/Invoke or native probes. Keep managed stack/recursion
admission, host mediation, original paths/contained Cwd, cooperative cancellation,
cycle detection/XML depth, checked representation bounds and bounded I/O chunks.
No fuel/quotas, independent caps/default allowance, regex work/time policy, tracing,
weak reclamation, forced GC or abandoned users. Borrowed allowance funds major
capacity, replacement overlap, retained aliases/results/caches and pending borrows.
First refused admission fails the command with its original origin; never retry.
Await cleanup. Long streaming uses bounded host commands. Only core is packaged;
the adapter stays in-repo and non-packable. Publication remains postponed.
