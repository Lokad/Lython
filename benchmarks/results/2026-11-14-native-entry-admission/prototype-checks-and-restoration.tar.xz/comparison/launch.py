from pathlib import Path
import base64,datetime,json,subprocess

r=Path(__file__).parent
assert not (r/'launch-attempt.json').exists(),'Do not automatically restart a collection.'
goldens=json.loads((r.parent/'goldens.json').read_text(encoding='utf-8'))
assert len(goldens)==16 and all(x['response']['status']=='Equivalent' for x in goldens)
prior=json.loads((r.parent.parent/'protected-activation-r368/b757/terminal-status.json').read_text(encoding='utf-8'))
assert prior['receipt']['complete'] and not prior['remainingWorkers'] and not prior['remainingTrace']
now=datetime.datetime.now(datetime.timezone.utc)
(r/'launch-attempt.json').write_text(json.dumps(dict(attemptedUTC=now.isoformat(),neverAutomaticallyRelaunch=True))+'\n',encoding='utf-8')
code=(r/'launch-command.py').read_bytes()
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code).decode()+"\"))'"
done=subprocess.run(ssh+[command],input=(r/'payload.tgz').read_bytes(),capture_output=True,timeout=60)
(r/'launch.log').write_bytes(done.stdout+done.stderr)
assert done.returncode==0,(done.stdout+done.stderr).decode()
now=datetime.datetime.now(datetime.timezone.utc)
(r/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=180)).isoformat(),ownerSeconds=240),indent=2)+'\n',encoding='utf-8',newline='\n')
print(done.stdout.decode(),flush=True)
print('Earliest observation',(now+datetime.timedelta(seconds=180)).isoformat(),flush=True)
