from pathlib import Path
import ast,hashlib,json,tarfile

r=Path(__file__).parent;b=r/'b758';b.mkdir()
old=r.parent/'protected-activation-r368/b756'
source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert all(sha(n)==h for n,h in source['sources'].items())
assert sha(r/'catalog.json')==sha(r.parent/'protected-activation-r368/catalog.json')
remote='/home/lokad/lython-bench-checks/native-entry-b758-20261114';unit='lython-b758-native-entry-20261114'
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision='R369uncommitted/frozen'+source['coreSHA256']['candidate'][:8]+' vs qualified3994dfda/frozenb5a6426e; full43640155007 GREEN cached',purpose='Consolidate native helper physical stack admission at the immediate synchronous EnterFunctionCall; remove only duplicate NativeExecution.Run check. No nesting/recursion limit or continuation guard removed. Same complete search/protectedinvoice/short/JSON scripts and normal worker settings. No performance forecast.',coreSHA256={k:source['coreSHA256']['candidate' if k.startswith('candidate') else 'reference'] for k in identity['coreSHA256']},catalogSHA256=sha(r/'catalog.json'),fullSourceIdentitySHA256=sha(r/'candidate-identity.json'),sourceFormComparison=False,runtimeComparison=True)
(b/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.file-search.large.protected','warm'],['scripts.csv-invoice.large.protected','warm'],['diagnostic.loop-helper.short-zero.large','warm'],['scripts.json-summary-helpers.large','warm']]
for n in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
    s=(old/n).read_text(encoding='utf-8').replace('protected-activation-b756-20261114','native-entry-b758-20261114').replace('lython-b756-protected-activation-20261114',unit).replace('B756','B758')
    if n=='collect.py':
        a=s.index('jobs=');end=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==4 and all(case in cases for case,lane in jobs)\n'+s[end:]
        s=s.replace('started < 350','started < 180').replace('Reserve70seconds','Reserve60seconds')
    elif n=='archive-owned.py':s=s.replace("len(raw['jobs'])==8","len(raw['jobs'])==4").replace('jobs=8','jobs=4')
    elif n=='retrieve.py':s=s.replace("['jobs']==8","['jobs']==4").replace("['elapsedSeconds']<420","['elapsedSeconds']<240").replace('eight-job','four-job')
    elif n=='summarize.py':s=s.replace("len(raw['jobs'])==8","len(raw['jobs'])==4").replace('jobs=8','jobs=4')
    if n.endswith('.py'):ast.parse(s)
    (b/n).write_text(s,encoding='utf-8',newline='\n')
(b/'prospective.json').write_text(json.dumps(dict(purpose=identity['purpose'],jobs=jobs,bound='One240sowner/180sstartguard,4wholewarmjobs,4freshprocesses/job,5sfullrequestwarmups,5rotating0.5sbatches; normalGC/tiering, same images/worker/catalog/protocol. Every image/golden/file/budget/quiet/join/archive gate.',sourceProof='Only production NativeExecution.Run is called directly after same-thread StartInline.EnterFunctionCall with no suspension/guest operation between them. Existing nesting/recursion/continuation admission retained. Actual low-stack native call case and existing deep/async/owned/handler/cancellation/refusal coverage pass on actual11/10.',stopping='One usable affected/control comparison or justified bounded measurement correction/refinement, retaining every adverse/control/initial condition. No allocation/startup/embedding-latency measurement or external refresh. Retain/debt or supported withdrawal; whole-script goal stays active, publicationheld.',storage='Initial b9retirement assumption fails missing-path preflight before mutation; targeted observation finds already absent. Corrected805initial-range DLL matches committed archive and all paths/UID/inode/link/hash checks before twoalias retirement. Currentb5ff2/catalogs/toolchains/floors preserved. Reuse existingcatalog, upload only newcore/scripts.'),indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(b/'payload.tgz','w:gz') as t:
    for n in ['identity.json','collect.py','archive-owned.py','run.sh','prospective.json']:t.add(b/n,arcname=n)
    t.add(r/'candidate-core.dll',arcname='candidate-core.dll')
with tarfile.open(b/'payload.tgz') as t:unpacked=sum(m.size for m in t.getmembers())
config=dict(root=remote,sourceRoot='/home/lokad/lython-bench-checks/protected-activation-b756-20261114',unit=unit,identity=identity,payloadBytes=(b/'payload.tgz').stat().st_size,payloadSHA256=sha(b/'payload.tgz'),unpackedBytes=unpacked)
s=(old/'launch-command.py').read_text(encoding='utf-8');a=s.index('c=');end=s.index('\nbase=',a);s=s[:a]+'c='+repr(config)+s[end:]
s=s.replace("assert sha(root/'candidate-core.dll')==c['identity']['coreSHA256']['candidate'] and sha(root/'representative.json')==c['identity']['catalogSHA256']", "assert sha(root/'candidate-core.dll')==c['identity']['coreSHA256']['candidate'] and sha(source/'representative.json')==c['identity']['catalogSHA256']\n os.link(source/'representative.json',root/'representative.json')")
s=s.replace('lython-b756-fixtures','lython-b758-fixtures').replace('RuntimeMaxSec=420','RuntimeMaxSec=240')
s=s.replace('noRetirement=True,currentImagesCatalogsToolchainsPreserved=True','stagingOnlyNoRetirement=True,priorRetirementProof="b758-proved-withdrawn-prototype-retirement.json",currentImagesCatalogsToolchainsPreserved=True')
ast.parse(s);(b/'launch-command.py').write_text(s,encoding='utf-8',newline='\n')
(b/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'launch.py').read_text(encoding='utf-8').replace("r.parent.parent/'protected-helper-r367/terminal-status.json'", "r.parent.parent/'protected-activation-r368/b757/terminal-status.json'").replace('seconds=360','seconds=180').replace('ownerSeconds=420','ownerSeconds=240')
ast.parse(s);(b/'launch.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared B758four-job native entry diagnostic; no remote action.',flush=True)
