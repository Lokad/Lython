from pathlib import Path
import hashlib,io,json,subprocess,tarfile

r=Path(__file__).parent
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
name='benchmarks/results/2026-11-14-range-iteration-stage/initial/sources-checks-and-observations.tar.xz'
blob=subprocess.check_output(['git','show',head+':'+name])
assert hashlib.sha256(blob).digest()==hashlib.sha256(Path(name).read_bytes()).digest()
with tarfile.open(fileobj=io.BytesIO(blob),mode='r:xz') as t:body=t.extractfile('candidate-core.dll').read()
expected='8056823e53a66dd202010c067484c57312f8d5ca3faf33e8265f04687f7c567c'
assert hashlib.sha256(body).hexdigest()==expected
proof=dict(commit=head,canonicalArchive=name,canonicalArchiveSHA256=hashlib.sha256(blob).hexdigest(),member='candidate-core.dll',bytes=len(body),sha256=expected,paths=['range-iteration-b744-20261114/candidate-core.dll','range-iteration-b744-20261114/candidate/Lokad.Lython.dll'],expectedLinks=2)
(r/'range-retirement-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
code=r'''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
proof=PROOF
base=Path('/home/lokad/lython-bench-checks').resolve()
with(base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(p.is_mount() for p in base.glob('*/guest-fixtures'))
 paths=[base/n for n in proof['paths']]
 metadata=[p.lstat() for p in paths]
 observations=[dict(path=str(p),inode=s.st_ino,links=s.st_nlink,uid=s.st_uid,bytes=s.st_size) for p,s in zip(paths,metadata)]
 print(json.dumps(dict(preflight=observations)),flush=True)
 assert all(p.resolve()==p and p.is_relative_to(base) and stat.S_ISREG(s.st_mode) and s.st_uid==os.getuid() and s.st_nlink==proof['expectedLinks'] and s.st_size==proof['bytes'] for p,s in zip(paths,metadata))
 assert len({(s.st_dev,s.st_ino) for s in metadata})==1
 assert all(hashlib.sha256(p.read_bytes()).hexdigest()==proof['sha256'] for p in paths)
 before=shutil.disk_usage(base).free
 assert before+proof['bytes']>254*1024*1024+6*1024*1024+65536
 for p in paths:p.unlink()
 receipt=dict(proof=proof,allMetadataHashesVerifiedBeforeMutation=True,freshIdleLease=True,retiredOnly=[str(p) for p in paths],beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,currentb5ff2AllCatalogsAuxiliariesAndToolchainsPreserved=True,floorsUnchanged=True)
 (base/'b758-proved-withdrawn-prototype-retirement.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt),flush=True)
'''.replace('PROOF',repr(proof))
(r/'range-retirement-command.py').write_text(code,encoding='utf-8',newline='\n')
done=subprocess.run(['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73','python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=30)
(r/'range-retirement-result.log').write_text(done.stdout+done.stderr,encoding='utf-8',newline='\n')
assert done.returncode==0,done.stdout+done.stderr
receipt=json.loads(done.stdout.splitlines()[-1]);(r/'range-retirement-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(retiredAliases=receipt['retiredOnly'],afterFreeBytes=receipt['afterFreeBytes'],allProofsPassed=True)),flush=True)
