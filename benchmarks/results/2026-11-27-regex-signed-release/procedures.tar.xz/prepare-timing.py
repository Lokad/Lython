from base64 import b64decode
from hashlib import sha256
from pathlib import Path
from statistics import median
import json
import os
import shutil
import subprocess
import tarfile
import tempfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
notes=lab.parent
previous=notes/'direct-prepared-inserts-20261127'
local_base=previous/'local'
donor=previous/'comparison/quiet'
local=lab/'local'
quiet=lab/'comparison/quiet'
local.mkdir()
(quiet/'candidate').mkdir(parents=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
write=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
sha=lambda p:sha256(p.read_bytes()).hexdigest()
manifest=lambda p:{f.name:sha(f) for f in p.iterdir()}
core='Lokad.Lython.dll'
checkout=lab/'checkout'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=checkout,text=True).strip()
assert head.startswith('ec1ce857c')
assert not subprocess.check_output(['git','diff','9cee6f423',head,'--','src'],cwd=repo)
patch=subprocess.check_output(['git','diff','--binary','HEAD'],cwd=checkout)
(local/'candidate.patch').write_bytes(patch)
assert b'Version="0.5.0"' in patch and not subprocess.check_output(['git','diff','--exit-code','HEAD','--','src/Lokad.Lython'],cwd=checkout)
pin=read(donor/'identity.json')
assert subprocess.check_output(['git','diff','--binary','4919f6748','9cee6f423','--','src'],cwd=repo)==(local_base/'candidate.patch').read_bytes()
assert sha(local_base/'candidate.patch')==pin['sourcePatchSHA256']
files=pin['imageFiles']['candidate']
assert len(files)==32 and manifest(local_base/'candidate')==files
receipt=read(donor/'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['quietBeforeAndAfter'] and receipt['archiveSHA256']==sha(donor/'observations.tar.xz')
for role in ('reference','candidate'):
    shutil.copytree(local_base/'candidate',local/role)
new=checkout/'tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0'
changed=('Lokad.Lython.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll','Lokad.Utf8Regex.dll')
for name in changed:
    shutil.copyfile(new/name,local/'candidate'/name)
    shutil.copyfile(new/name,quiet/'candidate'/name)
images={role:manifest(local/role) for role in ('reference','candidate')}
assert images['reference']==files
assert {k for k,h in files.items() if h!=images['candidate'][k]}==set(changed)
from zipfile import ZipFile
pins={}
for name in changed[1:]:
    package=lab/(name[:-4].lower()+'.0.5.0.nupkg')
    with ZipFile(package) as signed:
        assert sha256(signed.read('lib/net11.0/'+name)).hexdigest()==images['candidate'][name]
    pins[name]=sha(package)

catalog=read(notes/'regex-050-funded-allocation-20261125'/'comparison/quiet/representative.json')
compiled='scripts.regex-log-search.compiled'
module='scripts.regex-log-search.module'
invoice='scripts.csv-invoice.method-policy.quoted-control'
all_cases={row['id']:row for row in catalog['cases']}
catalog['cases']=[all_cases[k] for k in (compiled,module,invoice)]
write(quiet/'representative.json',catalog)
write(quiet/'jobs.json',{'warm':[[compiled,'warm'],[module,'warm'],[invoice,'warm'],[compiled,'compile-run']]})
for name in ('cpython-worker.py','run.sh'):
    shutil.copyfile(donor/name,quiet/name)
assert sha(quiet/'cpython-worker.py')==pin['cpythonWorkerSHA256'] and b'\r' not in (quiet/'run.sh').read_bytes()
identity=dict(sourceRevision=head,sourcePatchSHA256=sha(local/'candidate.patch'),imageFiles=images,
    coreSHA256={role+suffix:items[core] for role,items in images.items() for suffix in ('','-control')},
    catalogs={name:{'sha256':sha(quiet/name)} for name in ('representative.json','jobs.json')},
    comparisonHostRevision=pin['comparisonHostRevision'],cpythonWorkerSHA256=pin['cpythonWorkerSHA256'],
    expectedCPythonSHA256=pin['expectedCPythonSHA256'],donorArchiveSHA256=receipt['archiveSHA256'],
    signedPackageSHA256=pins, producerSource='61228b20fa7103910c7e247eb72b7c4592a4085f',
    purpose='Compare the signed 0.5.0 adapter candidate with 0.4.0 on the same delivered Lython library and comparison worker.')
write(quiet/'identity.json',identity)
collector=(donor/'collect.py').read_text(encoding='utf8').replace('len(jobs) == 5','len(jobs) == 4').replace('lython-b1847-fixtures','lython-regex-release-20261127-fixtures')
compile(collector,'collect.py','exec')
(quiet/'collect.py').write_text(collector,encoding='utf8',newline='\n')
ssh=(previous/'quiet-vm.py').read_text(encoding='utf8').replace('lython-b1847-direct-prepared-inserts-20261127','lython-regex-release-20261127')
ssh=ssh.replace('--property=RuntimeMaxSec=245','--property=RuntimeMaxSec=215').replace("proof['caseCount']==4","proof['caseCount']==3")
ssh=ssh.replace("name=='Lokad.Lython.dll'", 'name in '+repr(changed))
compile(ssh,'quiet-vm.py','exec')
(lab/'quiet-vm.py').write_text(ssh,encoding='utf8',newline='\n')
summary=(previous/'summarize-quiet.py').read_text(encoding='utf8').replace("receipt['warmJobs'] == 5","receipt['warmJobs'] == 4")
summary=summary.replace("len(raw['jobs']) == 5","len(raw['jobs']) == 4").replace('timedBatches=140','timedBatches=112')
(lab/'summarize-quiet.py').write_text(summary,encoding='utf8',newline='\n')

sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
for role,fileset in images.items():
    folder=local/role
    report=local/f'{role}-verify.json'
    subprocess.run([dotnet,folder/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'representative.json',
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',quiet/'cpython-worker.py','--out',report],env=env,check=True,timeout=65)
    proof=read(report)
    assert proof['state']=='Completed' and proof['caseCount']==3 and proof['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert proof['launched']['adapter']['sha256']==fileset['Lokad.Lython.Benchmarks.dll']
    assert proof['launched']['library']['sha256']==fileset[core]
    allocated=local/f'{role}-allocated'
    shutil.copytree(folder,allocated)
    for p in (local_base/'candidate-allocated').glob('ValidatedAllocation*'): shutil.copyfile(p,allocated/p.name)
    assert all(sha(allocated/name)==h for name,h in fileset.items())

names=['identity.json','representative.json','jobs.json','cpython-worker.py','run.sh','collect.py']+[f'candidate/{name}' for name in changed]
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz') as archive:
    for name in names:archive.add(quiet/name,arcname=name)
staged={name:dict(length=(quiet/name).stat().st_size,sha256=sha(quiet/name)) for name in names}
write(quiet/'upload.json',dict(root='regex-release-b1855-20261127',donor=read(donor/'upload.json')['root'],donorFiles=images['reference'],
    donorArchive=identity['donorArchiveSHA256'],payloadSHA256=sha(payload),files=staged,
    expandedBytes=sum(x['length'] for x in staged.values()),minimumAfterStageBytes=6*1024*1024))

rows=[]
for mode in ('sync','async'):
    for case in catalog['cases']:case['runAsync']=mode=='async'
    selection=local/f'{mode}-allocation-catalog.json'
    write(selection,catalog)
    pair=[]
    for role in images:
        folder=local/f'{role}-allocated'
        report=local/f'{role}-{mode}-allocation.json'
        subprocess.run([dotnet,folder/'ValidatedAllocation.dll',folder,selection,report],env=env,check=True,timeout=75)
        pair.append(read(report)['rows'])
    for before,after in zip(*pair,strict=True):
        assert before['id']==after['id'] and before['sharedBudgetBaselineRestored'] and after['sharedBudgetBaselineRestored']
        change=dict(case=before['id'],mode=mode,clr=[median(r['allocatedBytesPerInvocation']) for r in (before,after)],
                    peak=[r['peakExecutionMemoryBytes'] for r in (before,after)])
        rows.append(change)
        print(change,flush=True)
write(local/'allocation-summary.json',rows)
