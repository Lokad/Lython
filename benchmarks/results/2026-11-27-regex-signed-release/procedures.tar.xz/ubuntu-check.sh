#!/bin/bash
set -euo pipefail
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/regex-released-050-20261127
export NUGET_PACKAGES="$lab/packages-ubuntu"
cd "$lab/checkout"
project=tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj
dotnet restore "$project" --locked-mode --artifacts-path "$lab/ubuntu" --source https://api.nuget.org/v3/index.json 2>&1 | tee "$lab/ubuntu-restore.log"
for framework in net10.0 net11.0; do
    dotnet test "$project" -c Release -f "$framework" --no-restore --artifacts-path "$lab/ubuntu" --filter 'Category!=Stress&FullyQualifiedName~Regex' 2>&1 | tee "$lab/ubuntu-$framework.log"
done
