import ast
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
prior = lab.parent / "current-rule-costs-r600"
donor = lab.parent / "definition-record-construction-r604"
def read(path):
    return path.read_text(encoding="utf-8-sig")
def load(path):
    return json.loads(read(path))
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def write(name, text):
    if name.endswith(".py"):
        ast.parse(text)
    (lab/name).write_text(text, encoding="utf-8", newline="\n")
def save(name, value):
    write(name, json.dumps(value,ensure_ascii=False,indent=2)+"\n")

stage = load(donor/"quiet/config.json")
image = donor/"frozen/candidate"
files = stage["identity"]["imageFiles"]["candidate"]
assert len(files) == 32 and {name: sha(image/name) for name in files} == files
assert not subprocess.check_output(["git","diff","--name-only","c5ff4542d","HEAD","--","src","tests"])
retained = load(Path("benchmarks/results/2026-11-19-direct-definition-records/summary.json"))
assert retained["retainedCommit"] == "e93356adc" and retained["cores"]["candidate"] == files["Lokad.Lython.dll"]
catalog = load(donor/"catalog.json")
labels=["rules","annotated","forwarding"]
variants=("scripts.rule-default-closures","scripts.annotated-rule-closures","scripts.report-forwarding.expanded")
catalog["cases"] = [next(c for c in catalog["cases"] if c["id"] == case) for case in variants]
save("catalog.json",catalog)
catalog_path=lab/"catalog.json"
identity=dict(sourceRevision="e93356adc",purpose="Post-R604 rule and forwarding frame attribution",
    coreSHA256=dict(candidate=files["Lokad.Lython.dll"]),imageFiles=dict(candidate=files),
    catalogSHA256=sha(catalog_path),diagnosticOnly=True,publicationHeld=True)
save("identity.json",identity)

old=load(prior/"config.json")
root="/home/lokad/lython-bench-checks/current-frame-costs-b1033-20261119"
unit="lython-b1033-current-frame-costs-20261119"
jobs=[(label,case,"warm") for label,case in zip(labels,variants,strict=True)]
profile=read(prior/"ops-profile.py").replace(old["root"],root)
a,b=profile.index("[('rules',"),profile.index(")]",profile.index("[('rules',"))+2
profile=profile[:a]+repr(jobs)+profile[b:]
profile=profile.replace("total_capture_seconds > 20","total_capture_seconds > 30").replace("Combined two-profile","Combined three-profile")
write("ops-profile.py",profile)
collect=read(prior/"collect.py").replace(old["root"],root).replace("['rules', 'annotated']",repr(labels)).replace("len(records)==2","len(records)==3")
collect=re.sub(r"source='R600/B1027[^']+'", f"source='R606/B1033 e93356adc/{files['Lokad.Lython.dll'][:8]} frame and rule attribution'",collect)
write("collect.py",collect)
write("run.sh",read(prior/"run.sh").replace(old["root"],root))
write("launch.py",read(prior/"launch.py").replace("Current rule closure attribution","Current frame attribution").replace("seconds=58","seconds=83").replace("before 58 seconds","before 83 seconds"))
write("retrieve.py",read(prior/"retrieve.py"))
write("analyze.py",read(prior/"analyze.py").replace("['rules', 'annotated']",repr(labels)))
names=["identity.json","catalog.json","ops-profile.py","collect.py","run.sh"]
payload=lab/"payload.tgz"
with tarfile.open(payload,"w:gz") as stream:
    for name in names:
        stream.add(lab/name,arcname=name)
size=sum((lab/name).stat().st_size for name in names)
space=load(lab/"quiet-space.json")
available=space["freeBytes"]; reserve=254*1024*1024+524288+size
selected=[]
for proof in space["replicas"]:
    if available > reserve+98304:
        break
    assert proof["committedBlobVerified"]
    selected.append(proof); available+=proof["bytes"]
assert available > reserve
config=dict(root=root,unit=unit,source=stage["root"],sourceFiles=files,sourceCatalogSHA256=stage["catalogSHA256"],
    catalogSHA256=sha(catalog_path),identity=identity,retireGroups=selected,payloadBytes=payload.stat().st_size,
    payloadSHA256=sha(payload),unpackedBytes=size)
save("config.json",config)
launcher=read(prior/"remote-launch.py")
a,b=launcher.index("\nc=")+1,launcher.index("\nb=Path(")
write("remote-launch.py",re.sub(r"lython-b[0-9]+(?:-annotated)?-fixtures","lython-b1033-fixtures",
    launcher[:a]+"c="+repr(config)+launcher[b:]))
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
with (lab/"verify.log").open("wb") as log:
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog_path,
        "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",Path.cwd()/"benchmarks/cpython-worker.py",
        "--out",lab/"verify.json"],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90,check=True)
verification=load(lab/"verify.json")
assert verification["state"]=="Completed" and verification["catalogSha256"]==sha(catalog_path)
assert {name:sha(image/name) for name in files}==files
print("Verified current retained image and all three published workload goldens.")
