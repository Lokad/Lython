from pathlib import Path
import hashlib,json,shutil
r=Path('/home/lokad/lython-bench-checks/text-fresh-confirm-b241-20261105');b=Path('/home/lokad/lython-bench-checks/runtime-cpython-b240-20261105')
assert shutil.disk_usage(r).free>64*1024*1024
for name in ['candidate','reference']:(r/name).symlink_to((b/name).resolve(),target_is_directory=True)
i=json.loads((r/'identity.json').read_text())
for name in ['candidate','reference']:assert hashlib.sha256((r/name/'Lokad.Lython.dll').read_bytes()).hexdigest()==i['coreSHA256'][name]
