# Lokad.Lython 0.11.0

Updated 2026-11-07. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Completing one experiment or qualification checkpoint does not complete this objective.

## Delivery status

- **Fully qualified through `5fb25354`:** terminal GREEN `42365045704` covers Windows/Ubuntu,
  actual .NET 11/10, original Stress and installed core-package consumers. Includes
  R43, R40 scalar cursor, R41 shared receiver methods and prior compiler/UTF-8/helper
  milestones. Receipt beside R43 evidence; earlier R41 receipt `42357660230`
  remains cached. Never query terminal runs again.
- **R43 committed/pushed `5fb25354`, fully qualified:** fewer operand loads and
  one physical-layout pass; original spans/aliases/native helpers preserved.
  No frame cache or extra charge. B397 setup failure and all intermediate/adverse
  data are archived; corrected B398 passes all gates. Retain consolidation without
  a substantial CPU claim. Full details live in its benchmark evidence.
- **Committed/pushed R44 `77703a42`:** twelve immediate duplicate entry checks
  deleted, 103 internal / 862 public actual11 focused checks pass. Full qualification
  of this later source is batched with the next runtime milestone; R43 CI excludes it.
- **Committed/pushed R45 `8c9fd0d7`:** general UTF-8 integer parsing and bounded
  promotion; focused actual11/10 and in-flight cancellation pass. Combined R44/R45
  full Windows/Ubuntu, actual11/10, Stress and installed consumers dispatched
  12:14 UTC; status pending, separate from R43 qualification.
- **Current external comparison:** B395 exact production `fba865ef`, frozen
  `5d2ca8e1`, CPython 3.13.16/.NET 11 RC3, quiet F4as_v7 Ubuntu VM. Warm ratios:
  CSV 1.19–1.23x, text 1.75–1.79x, JSON 1.04x, report 1.36–1.38x, config 1.25x.
  Compile 42–68 us separately; fresh ratios 1.03–1.74x across those scripts.
  Variable controls remain explicit. See docs/BENCHMARKS.md for boundaries/status.
- **Independent regex:** core remains decoupled; normal optional, nonpackable
  adapter pinned 0.4.0. Earlier immutable dev48/source f6b2175e passed 85 internal /
  488 public checks per target on R30; this is not current-HEAD, final safety or
  backend performance certification.

## Established evidence and unresolved debt

| Work | Established result | Limits / decision |
| --- | --- | --- |
| Shared compiler facts | Corrected shared inferred-value traversal eliminates exponential analysis; fully qualified | Preserve callback correction; no warm CPU claim. |
| Native helper returns | Allocation −19.92/−19.31%; fully qualified | Earlier elapsed gains remain diagnostic. No unchanged requalification. |
| Direct UTF-8 formatting/storage | Allocation −8.67%; controlled B102 elapsed/CPU −5–8% supports retention | Original adverse 15.125 ms remains unexplained and preserved. |
| R20/R25 records | Shared keys, independent values, completed CSV storage transfer; allocation −7.31/−6.55%, native warm −7.72–8.04% | Selectively replaces the old rigidly rejected 6–8% bulk-record attempt; controls mixed. |
| R35/R38 | Dynamic report allocation ~−15.35%, quiet warm −10–13%; compile allocation −4.38–8.94% | CSV possible debt +0.13–2.36%; R38 required full regex analysis preserved after three initial failures. |
| R40/R41 | Unicode cursor scaling −31–79%; shared receiver methods remove ten markers/guards and closures, regex allocation ~−29.47%, warm −8.64–10.80% | Not broad CPU/parity claims; ASCII and original CSV adverse controls remain possible debt. Fully qualified. |
| R42 cost gate | Text: 1,089 CPU samples, 44 unknown; prefix 229 self / 1,056 inclusive; scalar add 41 self | Self includes inlined work; inclusive totals overlap. No universal scalar rewrite or saved-CPU forecast. |
| R43 ordinary operands | Fewer instructions/smaller immutable payload; compile allocation +0.20–0.87%; full delivery green | Text warm −1.37 to +1.11%, fresh −2.23 to −0.15%; CSV variable, JSON −2.37 to +6.81%/6.66% identical-current spread, report −2.19 to −0.73%/3.92% IQR. No substantial CPU claim; debt stays. |

History, original failed conditions, rejected designs and complete qualification
live in benchmarks/EXPERIMENTS.md and immutable benchmarks/results/. R43 development
evidence stays outside docs/. Do not repeat unchanged completed qualification.

## Priority 1 — close the coherent R44/R45 delivery checkpoint

R45 is committed8c9fd0d7: deletes decoded copies/UTF-16 general parsing, uses
native accumulation then admitted radix chunks, fixes Unicode decimal semantics,
and checks cancellation during scanning/promotion. Small scalar headroom remains;
three conservative magnitudes fund large construction overlap. Exact thresholds
change; no tracing, cumulative allocation counting or new allowances. General
integers in bytes retain ASCII grammar. Individual BCL BigInteger operations are
not preemptible. Source-literal parsing remains a separate frontend input path.

Broad160internal/776public per actual11/10 and final41internal/280public per
target pass. Original admission-cancellation regressions fail before the fix.
Actual in-flight Stress passes54/60ms; not a latency guarantee. One old decoded-copy
refusal fixture now denies actual magnitude construction after text work, retaining
origin, alias and cleanup assertions. Initial complete-job allocations fall
14.70/13.35% for padded CSV and62.99/62.98% for numeric-string JSON, sync/async;
ordinary controls within0.007%, compilation flat. Final refinement only removes
one duplicate check; allocation was not replayed. No comparable RSS/tail claim.

B399 completed196.49s/all seven gates, archived/verified3f988c52: padded CSV
warm−12.49–13.41%, compile-run−13.14–20.72% (baseline spread6.75%); JSON numeric
strings warm−41.43–41.98%, compile-run−40.99–42.47%. Ordinary CSV−0.46to+0.89%,
JSON−0.31to+1.29%, text−5.65to+1.61%/4.83% identical-current spread. Retain
simplification, correctness, allocation and affected elapsed improvements; no
ordinary-input or isolated-CPU claim. Evidence: benchmarks/results/2026-11-07-integer-parsing/.

R44 deleted twelve checks immediately after checked managed frame entry. Its
allocation/peaks are unchanged and clocks variable; no CPU gain. Wider opcode
hoisting lacks proof and is not selected. Batch full R44/R45 qualification, already
requested, rather than rerun completed R43. Then record actual delivery status.

B400 representative CPython refresh:21existing jobs, five ordinary scripts plus
the two explicit affected integer fixtures. CPython3.13.16 and two identical
frozen d3a6c778 Lython processes, exact committed8c9fd0d7 production inventory,
precommit SourceLink3480aa55. Compile, warm and compile-to-result separately;
mediated RAM I/O, validation and prior-result cleanup included in execution.
540s owner+30s stop+30s margin; observe after600s. Preserve controls and uncertainty,
archive/verify under lease. This checkpoint does not finish the performance goal;
select the next coherent removable phase from the remaining roadmap below.

## Next redesign boundaries

Select a real dominant phase from current evidence; do not accumulate narrow cases.
For each selected milestone record the hypothesis, eliminated work/storage and
displaced code, affected scripts, semantic gates, bounded comparison and controls.

| Boundary | Evidence / acceptance / stopping criterion |
| --- | --- |
| Complete calls/frames | R39 CSV helper-inclusive totals are useful work, not proof of binding dominance. Existing borrowed operands/final slots/lazy contexts/native helpers stay. Select only a real removable phase; preserve binding, defaults, closures, exceptions, genuine I/O and owners. Slower call-arena/control designs require new evidence, not automatic retry. |
| Operand transport | R43 retained smaller code and fewer instructions, with CPU improvement unproved. No further leaf-specific rewrite without materially new evidence. |
| Completed-instruction guards | R44 completes twelve provably immediate duplicates. Wider opcode hoisting lacks a complete cancellation/refusal/error-order proof and is not selected. R42 prefix self is not guard CPU. Keep meaningful checkpoints; no replacement counters/quotas or weaker containment. |
| Per-record collections | Shared keys/R25 transfer and synchronous JSON already exist. Reassess bulk construction only where an actual extra copy/capacity phase remains; preserve hook/order/reentry/alias/overlap semantics. Original control regressions remain evidence. |
| Scalars and text | R42 scalar add alone is insufficient for universal tagged values. Bulk UTF-8 and prepared helpers already exist. R28 already tested newly owned packed split storage: allocation −6.94%, text variable, report +0.91–4.97% after refinement; withdrawn. Do not rediscover it as a new design or indiscriminately share refundable input windows. Select materially different remaining work; preserve promotion, identity, Unicode, hashes and cancellation. |
| Frontend/setup | Shared lexical/class/parameter facts, R38 demand pruning, shared builtins and executable imports already exist. Remove actual repeated analysis/storage; preserve dead-scope diagnostics, fresh mutable state and regex analysis. Compile separately, and include compile-to-result for config/new scripts. |

A justified redesign may temporarily regress. Its completion milestone must state
whether remaining debt is accepted, corrected or withdrawn. A source simplification,
an allocation reduction and a CPU improvement are distinct results.

## Independent regex track

Continue Lython-owned Python/native UTF-8 semantics: byte ranges, scalar positions,
original-subject windows, captures/replacements/errors/cache ownership and current
tokens through actual work. Development producers and adapter-local bridges may
support contract/semantic work; missing released capabilities defer only affected
final adapter qualification. They do not stop core or independent performance work.

Current precise producer gaps: DetailedData lacks a separate Prepare working owner;
native names lack enumeration; cursors mix creation/current token authority. Exact
dev48 supplies no documented removal of these limits. Keep conservative preflight,
adapter-local conversion and the qualified cancellation bridge where needed.
Qualify immutable released inputs and managed safety separately. No silent dialect
fallback, work/time quotas, sibling edits, abandoned matching or publication gate
on Lython development. Existing R40/R41 work needs no new producer release.

## Experimental and delivery policy

Timeouts, unstable unchanged controls and inconclusive observations establish
uncertainty, not permanent design rejection. Permit bounded justified confirmation,
refinement or measurement correction; never repeat until favorable. Size observations
for the quiet VM, preserve original conditions/adverse results and source/binary
provenance. Percentages inform decisions rather than automatically vetoing useful
simplification. Use focused correctness/cancellation/ownership checks while iterating;
batch full actual11/10 Windows/Ubuntu, original Stress and installed consumers at
meaningful retained delivery checkpoints. Publication remains postponed.

## Constraints / resources

AGENTS.md governs: fully managed/memory-safe, managed stack/nesting, host mediation,
current cancellation, borrowed shared allowance/preflights/overlap/escaping aliases
and awaited cleanup. First refused admission terminates the command. No unsafe,
tracing, weak reclamation, forced GC, fuel/quotas/caps or hidden allowance. Bounded
host-driven batches; XML depth constraint retained. No overlapping local tests,
builds or measurements. PLAN stays ignored; docs describe only current releases.

VM: lokad@20.166.121.73, key ~/.ssh/id_lython-bench.pem. B385–B396 are terminal and
archived: never service-query again. B397 terminal exit1, no workers/fixtures;
failed archive `837f6923` verified under lease. Never service-query it again.
B398 terminal green/all five gates, archive `1b2cf2d5` verified under lease and
locally; no workers/fixtures. Never service-query again. About 70 MB free at launch.
Full combined R44/R45 CI is active; B400 is prepared, not yet started. R43 full delivery `42365045704` is terminal green
on exact `5fb25354`, observed 11:09 UTC and cached; never query again. R44 is
committed77703a42 with focused actual11 checks only. R45 committed8c9fd0d7; focused checks
and diagnostics complete; final source is frozen. B399 terminal green, all
seven jobs/quiet/image/golden/funding/Closed/join/archive gates pass; never query
again.53.2MB free at launch. Record future observation bounds; no restart on timeout.
Full R44+R45 platform/Stress/package qualification was dispatched12:14UTC, pending. Persistent
evidence; archive/verify RAM traces under lease before removal. Record owner/stop/
margin before observing, never restart after observation timeout. Earlier duplicate
image/evidence retirements have exact committed backups and receipts; do not use
those incomplete old images without restoration.
