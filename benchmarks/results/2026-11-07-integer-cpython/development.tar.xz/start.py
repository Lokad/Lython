from pathlib import Path
import datetime,json,shlex,subprocess
root=Path(__file__).parent
script=(root/'launch.py').read_bytes();payload=(root/'payload.tgz').read_bytes()
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
stage='/home/lokad/lython-bench-checks/delivery-comparison-b400-launch.py'
code='from pathlib import Path; import sys; p=Path('+repr(stage)+'); assert not p.exists(); p.write_bytes(sys.stdin.buffer.read())'
done=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=script,capture_output=True);assert done.returncode==0,done.stderr
done=subprocess.run(ssh+['python3 '+stage],input=payload,capture_output=True)
(root/'launch.log').write_bytes(done.stdout+b'\n'+done.stderr);print((done.stdout+done.stderr).decode('utf-8'),flush=True)
assert done.returncode==0
now=datetime.datetime.now(datetime.timezone.utc)
(root/'observe-not-before.json').write_text(json.dumps(dict(acknowledgedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=600)).isoformat(),ownerSeconds=540,stopSeconds=30,marginSeconds=30),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Observe after '+(now+datetime.timedelta(seconds=600)).isoformat(),flush=True)
