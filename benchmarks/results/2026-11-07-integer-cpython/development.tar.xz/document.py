from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent
summary=json.loads((r/'summary.json').read_text(encoding='utf-8'))
assert summary['complete'] and len(summary['timing'])==21
receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'))
assert receipt['complete'] and receipt['jobs']==21
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
out=Path('benchmarks/results/2026-11-07-integer-cpython');out.mkdir()
for name in ['identity.json','summary.json','archive-receipt.json','terminal-status.json']:
    (out/name).write_text((r/name).read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
shutil.copy2(r/'observations.tgz',out/'observations.tgz')
with tarfile.open(out/'development.tar.xz','w:xz') as a:
    for p in r.iterdir():
        if p.is_file() and p.suffix in ['.py','.json','.log','.sh','.md']:a.add(p,arcname=p.name)
    a.add(r.parent/'prepare-b400.py',arcname='prepare-b400.py')
rows=summary['timing'];names={
    'scripts.csv-summary-functions.large':'CSV summary/ordinary helper',
    'scripts.text-summary-helpers.large':'Text summary/helpers',
    'scripts.json-summary-helpers.large':'JSON-lines/helpers',
    'scripts.report-render.large':'JSON-to-Markdown report',
    'scripts.config-edit.small':'Configuration read/edit/write',
    'scripts.csv-summary-functions.large-padded-integers':'CSV with padded numeric fields',
    'scripts.json-summary-helpers.large-integer-strings':'JSON with numeric strings'}
counts={k:('4,096 records' if any(t in k for t in ['csv-','json-summary']) else '3,072 lines' if 'text-' in k else '3,072 records' if 'report-' in k else '16 paths')for k in names}
def value(ms,unit='ms'):
    return f'{ms*1000:.3f}' if unit=='µs' else f'{ms:.3f}'
def table(lane,input_column=False,all_ms=False):
    header='| Workload | '+('Input | ' if input_column else '')+'Lython | CPython | Lython / CPython | Status; control / Lython IQR |\n'
    header+='| --- | '+('--- | 'if input_column else '')+'---: | ---: | ---: | --- |\n'
    for row in rows:
        if row['lane']!=lane:continue
        case=row['case'];low,high=row['timeRangeMilliseconds'];ref=row['medianMilliseconds']['CPython']
        unit='ms' if all_ms or low>=1 else 'µs'
        spread=max(row['iqrPercent'][l]for l in ['candidate','control'])
        header+='| '+names[case]+' | '+(f'{counts[case]} / {row["inputBytes"]:,} B | 'if input_column else '')+f'{value(low,unit)}–{value(high,unit)} {unit} | {value(ref,unit)} {unit} | {row["ratioRange"][0]:.2f}–{row["ratioRange"][1]:.2f}× | {row["status"]}; {row["controlPercent"]:.2f}% / {spread:.2f}% |\n'
    return header
readme='''# Representative CPython checkpoint after R45 — B400

2026-11-07, committed8c9fd0d7 production. Frozen d3a6c778 has the exact checked
560-source inventory with precommit SourceLink3480aa55. Core/auxiliary/source
identities are in identity.json; worker7cf37ca5/adapter27211dbe/normal PythonRe0.4
are reused. No development producer or new benchmark framework. Full combined
R44/R45 CI42371564043 was pending at setup and at this evidence collection; the
later terminal receipt, when present, establishes its actual delivery status.

Five unchanged maintained scripts plus two explicit affected inputs. Padded CSV
changes only its fixture (191505B); the637-character source is identical. Numeric
JSON strings change the helper to call int, and use278528B input. These are
separate workloads, not a replacement baseline or a causal CPU attribution.
Both engines run identical source/data and validate complete stdout/file digests.

Quiet AzureStandard_F4as_v7/Ubuntu24.04.4, four AMD EPYC9V45 vCPUs,16GiB/no swap.
.NET11RC3 normal GC/tiering; CPython3.13.16 GCC13.3 PGO/LTO, normal GIL/GC,
no JIT/debug, -I -S -X utf8. One CPython and two identical Lython processes/job,
5s warmup/role/job,7rotated150ms rounds.21jobs completed ELAPSEDs;540s owner,
30s stop/30s margin, observed after600s. All Ready/image/source/aux/golden/funding/
quiet/Closed/exit/join/fixture gates pass. Raw observations archived/verified under
the collection lease, then independently hash-verified locally; no workers remain.

Warm includes mediated RAM-file I/O, complete guest work, full validation and
prior-result cleanup. Compile-to-result adds compilation/program disposal; compile
alone excludes execution/I/O. Startup, staging/reset, transport and final cached
program/result/process teardown are excluded. CPython retains imported modules;
Lython isolates execution imports. No subtraction of independent medians, startup,
RSS, pending-I/O, embedding-tail or per-change saved-CPU claim. Ratio above1 means
slower. Ranges are two role medians, not confidence intervals. Control is absolute
role difference/candidate; IQR is the larger Lython-role value. Variable results
remain visible; labels are measurement descriptions, not design veto thresholds.

## Compilation plus one execution

'''.replace('ELAPSED',f'{summary["elapsedSeconds"]:.2f}')+table('compile-run',True)
readme+='\n## Warm execution\n\n'+table('warm',True)+'\n## Compilation/program disposal only\n\n'+table('compile')
readme+='''
[Raw observations](observations.tgz), [summary](summary.json), [source/images](identity.json),
[receipt](archive-receipt.json), [terminal state](terminal-status.json) and
[predeclared conditions/commands](development.tar.xz). The immutable raw archive
also preserves catalog, source patch, machine gates, setup plan and complete
warmups/samples. Historical B395 and all adverse source-pair results remain.
Publication is postponed; this checkpoint does not complete the performance goal.
'''
(out/'README.md').write_text(readme,encoding='utf-8',newline='\n')
p=Path('docs/BENCHMARKS.md');old=p.read_text(encoding='utf-8');tail=old[old.index('## Improvements within Lython'):]
tail=tail.replace('The later [general integer parser]','The [general integer parser]').replace('later source are separate from the primary CPython table above.','source-pair results are separate from the external CPython table above.').replace('The later [ordinary-operation transport consolidation]','The [ordinary-operation transport consolidation]')
guide='# Performance against CPython\n\n'+table('compile-run',True)
guide+='''
**2026-11-07; 0.11 development source `8c9fd0d7`; CPython3.13.16; .NET11RC3.**
These are **compilation plus one execution in an already-running host**, including
mediated RAM-file I/O, complete validation and prior-result cleanup. Startup and
fixture staging/reset are excluded. **Ratio=Lython elapsed/CPython elapsed; above
one means slower.** Ranges span two independent identical-build process medians,
not confidence intervals. Control is their absolute difference/candidate; IQR is
the larger Lython-role interquartile range/median. Diagnostic/Variable describe
short observations; they are not design acceptance thresholds.

The first five workloads retain the maintained ordinary inputs. The final two
explicitly exercise general integer conversion: padded CSV keeps the same source;
numeric-string JSON calls int in its helper. They do not replace the ordinary
baseline. Frozen core `d3a6c778` matches the recorded production inventory with
precommit SourceLink3480aa55. Combined Windows/Ubuntu, actual.NET11/10, original
Stress and installed-consumer CI42371564043 is pending; focused checks pass.
The normal optional0.4 adapter is unchanged. No new producer certification.
[Inputs, observations and delivery status](../benchmarks/results/2026-11-07-integer-cpython/README.md).

## Warm execution, compilation and startup

Same source/input and execution/I/O/validation/cleanup boundary, reusing compiled code:

'''+table('warm')
guide+='\nCompilation/program disposal only; execution and I/O excluded. Do not subtract\nwarm and compile-to-result medians to infer compilation; these are separate jobs.\n\n'+table('compile')
guide+='''
**Startup, genuinely suspended-I/O latency, heap/RSS and embedding latency remain
unmeasured.** Variable controls and IQRs stay visible. This combined checkpoint
does not repay historical CSV debt, explain earlier adverse controls or isolate
each change's CPU benefit. It describes the recorded source, not future HEAD.
[Previous primary comparison, sourcefba865ef](../benchmarks/results/2026-11-07-receiver-cpython/README.md).

## Machine, included work and fairness

Dedicated AzureStandard_F4as_v7, Ubuntu24.04.4 x86-64, four AMD EPYC9V45 vCPUs,
one thread/core,16GiB/no swap. CPython GCC13.3 PGO/LTO, ordinary GIL/GC,
no JIT/debug, -I -S -X utf8. SDK/runtime11.0.100-rc.3.26522.148 /
11.0.0-rc.3.26522.148. Independent sequential processes, normal GC/tiering,
quiet endpoints;5s warmup per role/job, seven rotated150ms rounds.21jobs completed
ELAPSEDs; all workers joined and fixtures removed. Source/images/conditions are
preserved with the raw observations.

Both engines run identical scripts/fixtures and check complete output/file digests
on every invocation. Efficient host overrides mediate Lython file access. RAM
fixtures include reads/writes; staging/reset are outside elapsed clocks. Warm
includes invocation and prior-result cleanup; compile includes construction/disposal.
Protocol transport and final cached teardown are excluded. CPython retains imported
modules; Lython isolates execution imports. This is an embedding comparison, not
a claim of identical implementations. These tables use synchronous Run; historical
async comparisons use completed mediated I/O, not pending-I/O latency.
[Historical async evidence](../benchmarks/results/2026-11-06-native-read-cpython/README.md)
preserves its distinct sources and adverse controls.

'''.replace('ELAPSED',f'{summary["elapsedSeconds"]:.2f}')+tail
p.write_text(guide,encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');s+='\n## Representative CPython checkpoint after R45 (2026-11-07)\n\nB400 records21 compile/warm/compile-run jobs on8c9fd0d7, five ordinary scripts and\ntwo explicit affected integer inputs. All gates/archive verification pass; variable\ncontrols remain visible. Full combined delivery is independent and pending.\n[Evidence and boundaries](results/2026-11-07-integer-cpython/README.md).\n';p.write_text(s,encoding='utf-8',newline='\n')
print('Preserved B400 and refreshed primary CPython tables; CI still pending, no runtime/CPU attribution added.')
