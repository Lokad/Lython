from pathlib import Path
import ast, datetime, hashlib, json, re, shutil, subprocess, tarfile

home=Path(__file__).parent
old=home/'delivery-comparison-b395'
root=home/'delivery-comparison-b400';root.mkdir()
prior=home/'integer-utf8-r45/b399'
old_remote='/home/lokad/lython-bench-checks/delivery-comparison-b395-20261107'
remote='/home/lokad/lython-bench-checks/delivery-comparison-b400-20261107'
image='/home/lokad/lython-bench-checks/integer-parsing-b399-20261107'
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head=='8c9fd0d7e9fdbe57d42cf0a3c100b369a7079beb'
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
identity=json.loads((prior/'identity.json').read_text(encoding='utf-8'))
for name,digest in identity['productionSources'].items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
identity['coreSHA256']={k:identity['coreSHA256'][k] for k in ['candidate','control']}
identity.update(sourceRevision=head+'; exact frozen production d3a6c778, precommit SourceLink3480aa55',
    purpose='Representative CPython R43/R44/R45 checkpoint; ordinary inputs and explicit affected integer inputs, compile/warm/compile-run separated',
    delivery=json.loads((home/'integer-utf8-r45/ci-request.json').read_text(encoding='utf-8')))
identity.pop('baselineSource',None);identity.pop('baselineQualification',None)
def write(name,s):(root/name).write_text(s,encoding='utf-8',newline='\n')
write('identity.json',json.dumps(identity,indent=2)+'\n')
catalog=json.loads((old/'representative.json').read_text(encoding='utf-8'))
affected=json.loads((home/'integer-utf8-r45/catalog.json').read_text(encoding='utf-8'))
ordinary={c['id']:c for c in catalog['cases']}
for c in affected['cases']:
    if c['id'] in ordinary:
        assert c==ordinary[c['id']]
    else:catalog['cases'].append(c)
assert len(catalog['cases'])==7
write('representative.json',json.dumps(catalog,ensure_ascii=False,indent=2)+'\n')
jobs=[(c['id'],lane) for c in catalog['cases'] for lane in ['compile','warm','compile-run']]
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
    s=(old/name).read_text(encoding='utf-8').replace(old_remote,remote).replace('lython-b395-delivery-comparison-20261107','lython-b400-delivery-comparison-20261107')
    s=s.replace('len(jobs)==15','len(jobs)==21').replace("len(r['jobs'])==15","len(r['jobs'])==21").replace('jobs=15','jobs=21').replace("['jobs']==15","['jobs']==21")
    s=s.replace('started < 360','started < 480')
    if name=='collect.py':
        s=re.sub(r'^jobs=\[.*\]$', 'jobs='+repr(jobs),s,flags=re.M)
        s=s.replace('Representative CPython checkpoint after R36/R38/R40/R41; compile/warm/fresh separated, not causal per-change attribution',identity['purpose'])
    if name.endswith('.py'):ast.parse(s)
    write(name,s)
contract='''R43/R44/R45 checkpoint, committed8c9fd0d7 exact560-source inventory matching already frozen d3a6c778 production, precommit SourceLink3480aa55. Reuse existing comparison workers/host and optional0.4; no new framework. Ordinary five maintained scripts plus explicitly affected padded CSV191505B and numeric-string JSON278528B. The CSV source is unchanged; the JSON helper explicitly converts numeric strings. Same script, data, full output and files in CPython3.13.16 and both identical Lython roles. Three separate lanes: compilation/program disposal only, warm execution, compile-to-result. Warm and compile-to-result include mediated RAM-file I/O, full validation and prior-result cleanup; startup, fixture staging/reset, protocol transport and final cached teardown excluded. Normal GC/tiering,5s warmup/role/job,7rotated150ms rounds;21jobs. Quiet endpoints, all Ready/hash/golden/funding/Closed/exit/join/fixture gates and under-lease persistent archive required.540s owner+30s stop+30s margin; observe after600s. No early service query, no restart on timeout. Preserve adverse and missing observations; no median subtraction, universal speedup, isolated-CPU, startup, RSS or embedding-tail claim. Full combined CI requested separately; source snapshot says pending at setup. Primary tables update only after observations; qualification status follows actual receipt. Publication postponed.'''
write('contract.md',contract+'\n')
write('setup-contract.json',json.dumps(dict(image=image+'/candidate',jobs=21,ownerSeconds=540,stopSeconds=30,marginSeconds=30,observeAfterSeconds=600,reason=identity['purpose']),indent=2)+'\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')
s=s.replace('- **Current external comparison:**','- **Committed/pushed R45 `8c9fd0d7`:** general UTF-8 integer parsing and bounded\n  promotion; focused actual11/10 and in-flight cancellation pass. Combined R44/R45\n  full Windows/Ubuntu, actual11/10, Stress and installed consumers dispatched\n  12:14 UTC; status pending, separate from R43 qualification.\n- **Current external comparison:**')
start=s.index('## Priority 1 — R45')
end=s.index('## Next redesign boundaries',start)
s=s[:start]+'''## Priority 1 — close the coherent R44/R45 delivery checkpoint

R45 is committed8c9fd0d7: deletes decoded copies/UTF-16 general parsing, uses
native accumulation then admitted radix chunks, fixes Unicode decimal semantics,
and checks cancellation during scanning/promotion. Small scalar headroom remains;
three conservative magnitudes fund large construction overlap. Exact thresholds
change; no tracing, cumulative allocation counting or new allowances. General
integers in bytes retain ASCII grammar. Individual BCL BigInteger operations are
not preemptible. Source-literal parsing remains a separate frontend input path.

Broad160internal/776public per actual11/10 and final41internal/280public per
target pass. Original admission-cancellation regressions fail before the fix.
Actual in-flight Stress passes54/60ms; not a latency guarantee. One old decoded-copy
refusal fixture now denies actual magnitude construction after text work, retaining
origin, alias and cleanup assertions. Initial complete-job allocations fall
14.70/13.35% for padded CSV and62.99/62.98% for numeric-string JSON, sync/async;
ordinary controls within0.007%, compilation flat. Final refinement only removes
one duplicate check; allocation was not replayed. No comparable RSS/tail claim.

B399 completed196.49s/all seven gates, archived/verified3f988c52: padded CSV
warm−12.49–13.41%, compile-run−13.14–20.72% (baseline spread6.75%); JSON numeric
strings warm−41.43–41.98%, compile-run−40.99–42.47%. Ordinary CSV−0.46to+0.89%,
JSON−0.31to+1.29%, text−5.65to+1.61%/4.83% identical-current spread. Retain
simplification, correctness, allocation and affected elapsed improvements; no
ordinary-input or isolated-CPU claim. Evidence: benchmarks/results/2026-11-07-integer-parsing/.

R44 deleted twelve checks immediately after checked managed frame entry. Its
allocation/peaks are unchanged and clocks variable; no CPU gain. Wider opcode
hoisting lacks proof and is not selected. Batch full R44/R45 qualification, already
requested, rather than rerun completed R43. Then record actual delivery status.

B400 representative CPython refresh:21existing jobs, five ordinary scripts plus
the two explicit affected integer fixtures. CPython3.13.16 and two identical
frozen d3a6c778 Lython processes, exact committed8c9fd0d7 production inventory,
precommit SourceLink3480aa55. Compile, warm and compile-to-result separately;
mediated RAM I/O, validation and prior-result cleanup included in execution.
540s owner+30s stop+30s margin; observe after600s. Preserve controls and uncertainty,
archive/verify under lease. This checkpoint does not finish the performance goal;
select the next coherent removable phase from the remaining roadmap below.

''' +s[end:]
s=s.replace('No active VM collection or CI.','Full combined R44/R45 CI is active; B400 is prepared, not yet started.')
s=s.replace('R45 prototype/focused checks\nand diagnostics complete; final refinement is frozen.','R45 committed8c9fd0d7; focused checks\nand diagnostics complete; final source is frozen.')
s=s.replace('Full R44+R45 platform/Stress/package qualification remains pending.','Full R44+R45 platform/Stress/package qualification was dispatched12:14UTC, pending.')
p.write_text(s,encoding='utf-8',newline='\n');shutil.copy2(p,root/'pre-measurement-plan.md')
(root/'source.patch').write_bytes(subprocess.check_output(['git','diff','fba865ef',head,'--binary','--','src','tests']))
with tarfile.open(root/'payload.tgz','w:gz') as t:
    for name in ['identity.json','representative.json','pre-measurement-plan.md','setup-contract.json','contract.md','collect.py','archive-owned.py','run.sh','source.patch']:t.add(root/name,arcname=name)
payload=(root/'payload.tgz').read_bytes()
s=(old/'launch.py').read_text(encoding='utf-8').replace(old_remote,remote).replace('/home/lokad/lython-bench-checks/receiver-methods-b394-20261107',image).replace('lython-b395-delivery-comparison-20261107','lython-b400-delivery-comparison-20261107')
s=re.sub(r"payload=sys.stdin.buffer.read\(\d+\+1\);assert len\(payload\)==\d+ and hashlib.sha256\(payload\).hexdigest\(\)=='[0-9a-f]+'",'payload=sys.stdin.buffer.read('+str(len(payload))+"+1);assert len(payload)=="+str(len(payload))+" and hashlib.sha256(payload).hexdigest()=='"+hashlib.sha256(payload).hexdigest()+"'",s)
s=re.sub(r' assert cases==\{.*\}', ' assert cases=='+repr({c['id'] for c in catalog['cases']}),s)
s=s.replace('allFifteenJobsValidated','allTwentyOneJobsValidated').replace('RuntimeMaxSec=420','RuntimeMaxSec=540')
assert str(len(payload))+'+1' in s and 'RuntimeMaxSec=540' in s
ast.parse(s);write('launch.py',s)
s=(home/'builtin-methods-r41/launch-b395.py').read_text(encoding='utf-8')
s=s.replace("root=Path(__file__).parent.parent/'delivery-comparison-b395'","root=Path(__file__).parent")
s=s.replace('delivery-comparison-b395-launch','delivery-comparison-b400-launch').replace('seconds=480','seconds=600').replace('ownerSeconds=420','ownerSeconds=540')
ast.parse(s);write('start.py',s)
print('Prepared B400; exact560-source check,21jobs, frozen core/auxiliary images reused; no collection started.')
