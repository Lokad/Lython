using System.Text.Json;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.CodeAnalysis.Operations;

var root = Path.GetFullPath(args[0]);
var parse = new CSharpParseOptions(LanguageVersion.Preview, preprocessorSymbols: ["NET11_0_OR_GREATER"]);
var files = Directory.EnumerateFiles(root, "*.cs", SearchOption.AllDirectories)
    .Where(p => !p.Contains(Path.DirectorySeparatorChar + "obj" + Path.DirectorySeparatorChar)
        && !p.Contains(Path.DirectorySeparatorChar + "bin" + Path.DirectorySeparatorChar))
    .Append(Path.Combine(root,"obj/Release/net11.0/Lokad.Lython.GlobalUsings.g.cs"));
var trees = files.Select(p => CSharpSyntaxTree.ParseText(File.ReadAllText(p), parse, p)).ToArray();
var references = ((string)AppContext.GetData("TRUSTED_PLATFORM_ASSEMBLIES")!).Split(Path.PathSeparator)
    .Select(p => MetadataReference.CreateFromFile(p));
var compilation = CSharpCompilation.Create("LythonBooleanSourceGate", trees, references,
    new CSharpCompilationOptions(OutputKind.DynamicallyLinkedLibrary, nullableContextOptions: NullableContextOptions.Enable));
var errors = compilation.GetDiagnostics().Where(d => d.Severity == DiagnosticSeverity.Error).ToArray();
if(errors.Length != 0) throw new Exception(string.Join("\n", errors.Select(e=>e.ToString()).Take(30)));
var sites = new List<object>();
foreach(var tree in trees.Where(t => args.Skip(2).Contains(Path.GetFileName(t.FilePath))))
{
    var model = compilation.GetSemanticModel(tree);
    var visitor = new Boxes(model, sites);
    foreach(var method in tree.GetRoot().DescendantNodes().OfType<BaseMethodDeclarationSyntax>())
        if(model.GetOperation(method) is { } operation) visitor.Visit(operation);
}
File.WriteAllText(args[1], JsonSerializer.Serialize(sites, new JsonSerializerOptions {WriteIndented=true}));
Console.WriteLine($"Validated {trees.Length} source trees; {sites.Count} typed Boolean-to-object conversions in selected result boundaries.");

sealed class Boxes(SemanticModel model, List<object> sites) : OperationWalker
{
    public override void VisitConversion(IConversionOperation operation)
    {
        if(operation.Type?.SpecialType == SpecialType.System_Object
            && operation.Operand.Type?.SpecialType == SpecialType.System_Boolean)
        {
            var syntax = operation.Syntax;
            var expression = operation.Operand.Syntax;
            sites.Add(new {file=syntax.SyntaxTree.FilePath,
                member=model.GetEnclosingSymbol(syntax.SpanStart)?.ToDisplayString(),
                line=syntax.GetLocation().GetLineSpan().StartLinePosition.Line+1,
                start=syntax.SpanStart,length=syntax.Span.Length,
                expression=expression.ToString(),original=syntax.ToString(),implicitConversion=operation.IsImplicit});
        }
        base.VisitConversion(operation);
    }
}
