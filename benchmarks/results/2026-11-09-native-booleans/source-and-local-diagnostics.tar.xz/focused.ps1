$env:DOTNET_ROOT='C:/Users/JoannesVermorel/.dotnet11'
$env:DOTNET_HOST_PATH="$env:DOTNET_ROOT/dotnet.exe"
$env:PATH="$env:DOTNET_ROOT;C:/Python313;$env:PATH"
$logs='.git/agent-notes/review-20261031/native-booleans-r135'
$internal='(Category!=Stress)&(FullyQualifiedName~ComparisonResultRoute|FullyQualifiedName~ComparisonBranchOwnership|FullyQualifiedName~ComparisonEvaluationOrder|FullyQualifiedName~ChainedComparisonObservation|FullyQualifiedName~NativeTruthEntry|FullyQualifiedName~NativeScalarDispatchBoundary|FullyQualifiedName~RuntimeProtocolSubsystem|FullyQualifiedName~IdentityAdmission|FullyQualifiedName~IdentityRegistryAccounting|FullyQualifiedName~JsonBooleanOwnership|FullyQualifiedName~FunctionWorkspaceOwnership|FullyQualifiedName~ReentrantAdmissionOwnership)'
$public='(Category!=Stress)&(FullyQualifiedName~BooleanIdentity|FullyQualifiedName~NativeTruth|FullyQualifiedName~RichComparisonSemantics|FullyQualifiedName~ComparisonValue|FullyQualifiedName~ComparisonBranchTests|FullyQualifiedName~ChainedComparisonScenario|FullyQualifiedName~OperatorProtocol|FullyQualifiedName~OperatorModuleFunction|FullyQualifiedName~NumericProtocolContract|FullyQualifiedName~TruthTypeSlot|FullyQualifiedName~NativeProtocolContract|FullyQualifiedName~ContainmentProtocolScenario|FullyQualifiedName~SetOrderingProtocol|FullyQualifiedName~JsonBooleanOption|FullyQualifiedName~ExactIntegerOperator|FullyQualifiedName~OrdinaryFunctionCall)'
foreach($target in @('net11.0','net10.0')) {
 dotnet test tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj -c Release -f $target --no-restore --filter $internal *> "$logs/internal-final-$target.log"
 if($LASTEXITCODE){Get-Content "$logs/internal-final-$target.log" -Tail 35 -Encoding utf8;exit $LASTEXITCODE}
 Get-Content "$logs/internal-final-$target.log" -Tail 2 -Encoding utf8
 dotnet test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f $target --no-restore --filter $public *> "$logs/public-final-$target.log"
 if($LASTEXITCODE){Get-Content "$logs/public-final-$target.log" -Tail 35 -Encoding utf8;exit $LASTEXITCODE}
 Get-Content "$logs/public-final-$target.log" -Tail 2 -Encoding utf8
}
