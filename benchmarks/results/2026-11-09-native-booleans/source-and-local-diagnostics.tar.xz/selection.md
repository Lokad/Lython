2. **R134 gate complete; active R135 native Boolean result storage.** The unchanged
   D36 collector on9db/core36fd sampled7170text/18178CSV ticks, zero lost,512checked
   captures each after256warmups; allgoldens/Closed/joins/fixtures pass. TextPyString
   35.13%/BigInteger24.63%; CSV PyString26.56%/BigInteger23.66%/Boolean9.05% associations.
   Boolean samples are24B objects on the same OS thread as guest-specific PyString.
   This is statistical attribution, not exact typebytes or CPU dominance; raw threads
   survive. Source finds native comparison/truth exits implicitly boxing bool into
   object. Select canonical native Boolean results before a universal scalar rewrite.
   Reuse RuntimeValue with typedbool entry/twoimmutableboxes. Replace native box
   construction at the complete core comparison/truth result boundary; preserve raw
   custom/reflected/NotImplemented protocol results and current bool/int semantics,
   host identity handling and numeric representation. No value hierarchy, owner,
   registry, public option or independent policy. Inspect IL/source first (~20min).
   Focused actual11/10: identity/type/hash/arithmetic/nested structures, genuineasync
   coercion/order, cancellation/first refusal and retained aliases/sharedbudget reuse.
   Then separate compile/warm allocation and one bounded quiet source-pair comparison
   for validatedCSV plus unaffected text/report/JSON controls. Decide retention/debt
   from observations; assume no9% gain. Cold module exits are an explicit later scope,
   not a claim that every CLR Boolean box disappears. Preserve failed integer/text/
   window designs; no new profiling campaign, forcedGC, heaptracing or ownerledger.
