from pathlib import Path
r=Path(__file__).resolve().parent;p=Path('D:/code/Lython/PLAN.md');s=p.read_text(encoding='utf-8');(r/'PLAN-before-condense.md').write_text(s,encoding='utf-8',newline='\n')
a=s.index('| Active private prototype |');b=s.index('\n',a)
s=s[:a]+'''| Committed; full delivery pending | R499ea8e9f91: constant string-key displays transport values only/reuse RecordKeys and existing lookup owners. Measured privatecf847936 production matches committed source. Both targets401internal/58public plus90dictionary/506public(overlap), later11class suspension/cold+warmed-refusal cases pass; sixgoldens/allocation/reuse. B924229.03s: record warm12–14%lower/fresh9–12%lower elapsed/supportingCPU, allocation14.67%lower/peak17%lower; text/JSON controls flat, floating12.91%candidate spread uncertain. Full44192474928 at exactea8 running, first observe22:46:22UTC; no inherited qualification. |
| Active source assessment | R500/B925 currentcf847936 text/floating sampled CPU, two5s captures after8s warmup, diagnostic perf maps only. Whole-worker CPU includes I/O/protocol/reset/cleanup; distinguish these from execution clocks. Actual32image hashes/catalog/goldens preserved. Decide one coherent redesign from current costs; no speedup forecast from leaf shares. |'''+s[b:]
a=s.index('## Next coherent runtime milestone:');b=s.index('## Following substantial deliverables',a)
s=s[:a]+'''## Completed construction milestones

R498 removes the whole-code native opcode whitelist and duplicate list/dict/set
construction loops. Existing lexical/storage admission,16slot ABI and cleanup
frontiers stay. Unsupported operations hand off at the untouched actualPC without
replaying effects. Shared final-slot kernels admit maximum capacity(including
duplicates), refund unpublished failure and keep aliases funded. Final large bound
key proofs remain cancellable. Full44187816311 and final5dsource agree on585inputs.
[Source conditions, failures, controls and delivery](benchmarks/results/2026-11-17-function-container-construction/README.md).

R499 removes per-record constant-key operands, hash insertion and private tables
from ordinary string-key displays. Immutable key tuples use existing compilation
funding; runtime RecordKeys/lookup owners retain layout charges. Value effects,
duplicate/first-key identity, mutation promotion, suspension, cold/warmed refusal
and escaping aliases remain covered. General keys/unpacking retain their path.
[Changed-source pair/decision](benchmarks/results/2026-11-17-constant-record-keys/README.md).
The first projected-CLR-identity fixture mistake and every adverse/control/source
condition remain linked, without repeating unchanged qualification.

## Immediate deliverables

1. Finish44192474928 platform/actual11&10/stress/installed-package verification;
   expected each4,831internal/18,035public ordinary,14/406stress,2,385inputs and
   585production. Cache terminal/logs once. This qualifies R499 only when verified.
2. Finish B925 current text/floating attribution with actual goldens, allowance
   reuse, all CPU threads/unknown samples, joined users and SHA-verified archive
   before RAM teardown. Stop the assessment with a concrete work/deletion map and
   one selected redesign, or a precise reason existing evidence is insufficient.
   Profile samples are wider than warm clocks, never removable-time forecasts.
3. Implement that coherent redesign with Python semantics, cancellation, first
   refusal, pending users/overlap and retained aliases intact. Focused both-target
   regressions/actual worker goldens/allocation/reuse, then one bounded affected
   complete script/control source pair. Decide remaining debt; no threshold veto,
   speculative frame arena or opcode/field reshuffling after R495's adverse forms.

''' + s[b:]
a=s.index('Selected R499 bounded prototype,');b=s.index('\n| Milestone',a)
s=s[:a]+s[b:]
s=s.replace("| Per-record CSV/JSON construction | After R498's debt decision, assess constant-key dictionary displays using existing RecordKeys and lookup-cache owners. Hypothesis: avoid per-record key tables/hashes/emitted key operands, extending the existing CSV/JSON final-storage design rather than duplicating it. Preserve duplicate keys/first-key identity/value effects, mutation, protocol order, owner/reentry/refusal and replacements. Prove remaining work, delete displaced construction; one affected complete script/control pair. No new cache subsystem, tracing or identity ledger. |", "| Complete activation/operand transport | R498/R499 construction completed as above. Use B925 current text/floating source costs before selecting further complete call/frame/transport work; earlier R494/R495 native generator/shared-runner forms stay isolated/adverse. Remove displaced stages on retention, rather than adding another controller/arena. Preserve callbacks/suspension/aliases/diagnostics and one whole-script/control pair. |")
p.write_text(s,encoding='utf-8',newline='\n');print('Active plan condensed to delivery, current-cost decision and implementation; history linked separately.')
