from pathlib import Path
r=Path(__file__).resolve().parent
s=(r.parent/'shared-kernel-r439/analyze-attribution.py').read_text(encoding='utf-8')
s=s.replace("['reference','candidate']", "['text','floating']").replace("r/'profile/retrieved/profiles'", "r/'retrieved/profiles'")
s=s.replace("'closed instruction execution':['NativeExecution','ExecutableKernel']", "'closed instruction execution':['NativeExecution','ExecutableKernel','ExecuteInstructionPrefix']")
s=s.replace("'cooperative checks':['CheckExecution','CheckCancellation']", "'cooperative checks':['CheckExecution','CheckCancellation'],'text/bulk':['PyStringOps','GovernedByteBuilder','StringJoin','AppendField'],'JSON':['Json','Utf8Json'],'iteration':['Generator','TryBufferYield','PyIteration','Cursor.Move']")
s=s.replace('Matched complete captured-script sampled CPU;', 'Current complete text/floating whole-worker sampled CPU; selected active threads retain all-thread raw data/counts;')
(r/'analyze.py').write_text(s,encoding='utf-8',newline='\n')
exec(compile(s,str(r/'analyze.py'),'exec'),dict(__file__=str(r/'analyze.py')))
