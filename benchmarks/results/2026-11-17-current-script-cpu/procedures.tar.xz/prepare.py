from pathlib import Path
import ast,hashlib,io,json,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');old=r.parent/'shared-kernel-r439/profile';current=r.parent/'constant-record-r499'
f=json.loads((current/'frozen/identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((current/'frozen'/role/n).read_bytes()).hexdigest()==h for role,files in f['imageFiles'].items()for n,h in files.items())
identity=dict(sourceRevision='Committedea8e9f91 production equals frozen privateR499/cf847936; .NET11RC3, normalGC/tiering plus perf maps only.',purpose='One bounded current text and floating whole-worker CPU attribution, not an elapsed/source comparison. Separate useful operations, call/frame/transport and I/O/cleanup work before selecting a coherent redesign.',imageFiles=f['imageFiles'],coreSHA256={role:files['Lokad.Lython.dll']for role,files in f['imageFiles'].items()},catalogSHA256=f['catalogSHA256'],sourceInputsArchiveSHA256=f['sourceInputsArchiveSHA256'],publicationHeld=True)
name='current-script-cpu-b925-20261117';unit='lython-b925-current-script-cpu-20261117';remote='/home/lokad/lython-bench-checks/'+name
for n in ['ops-profile.py','collect.py','run.sh','retrieve.py']:
 s=(old/n).read_text(encoding='utf-8').replace('shared-kernel-attribution-b839-20261116',name).replace('lython-b839-shared-kernel-profile-20261116',unit).replace('lython-b839-fixtures','lython-b925-fixtures')
 if n=='ops-profile.py':
  s=s.replace("[('reference','scripts.text-summary-helpers.nonlocal-counter.large','warm'),('candidate','scripts.text-summary-helpers.nonlocal-counter.large','warm')]", "[('text','scripts.text-normalization.large','warm'),('floating','scripts.numeric-squared-error.floating.large','warm')]")
  s=s.replace('tree / name /','tree / "candidate" /').replace("['imageFiles'][name]", "['imageFiles']['candidate']").replace('candidate/name/filename','candidate/"candidate"/filename').replace("['coreSHA256'][name]", "['coreSHA256']['candidate']")
  s=s.replace('count = 256','count = 64')
 if n=='collect.py':
  s=s.replace("['reference','candidate']", "['text','floating']").replace('R439/B839 matched source attribution,91ca4a41 versus0443b5cf; elapsed not comparable with unprofiled B838','R500/B925 committedea8e9f91 production/frozencf847936 current text and floating attribution, no elapsed comparison')
 if n=='retrieve.py':s=s.replace('Paired CPU profiles','Current CPU profiles')
 if n=='launch.py':s=s.replace('seconds=130','seconds=110')
 (r/n).write_text(s,encoding='utf-8',newline='\n')
s=(current/'launch.py').read_text(encoding='utf-8').replace("Path(__file__).parent/'quiet'",'Path(__file__).parent').replace('seconds=280','seconds=110').replace('before280seconds','before110seconds').replace('Six-job constant-record source pair','Current text/floating CPU attribution')
(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
subjects=[];canonical='benchmarks/results/2026-11-17-constant-record-keys/observations.tgz'
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes()
with tarfile.open(fileobj=io.BytesIO(blob))as a:
 for member in ['confirmation/confirmation.json','whole-archive']:
  data=blob if member=='whole-archive'else a.extractfile(member).read()
  subjects.append(dict(kind='completed-replica',path='constant-record-b924-20261117/'+('observations.tgz'if member=='whole-archive'else member),bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True))
s=(r.parent/'json-scalars-r492/prepare-quiet.py').read_text(encoding='utf-8');a=s.index("code = '''")+len("code = '''");b=s.index("'''.replace",a)
code=s[a:b].replace('SUBJECTS',repr(subjects)).replace("else[b/'numeric-json-cost-b909-20261117/observations.tgz']","else[b/item['path']]").replace('json-cpython-b908-20261117','constant-record-b924-20261117')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);assert p.returncode==0,p.stdout+p.stderr
groups=json.loads(p.stdout);(r/'retirement-candidates.json').write_text(p.stdout,encoding='utf-8')
names=['ops-profile.py','collect.py','run.sh','identity.json']
with tarfile.open(r/'payload.tgz','w:gz')as a:
 for n in names:a.add(r/n,arcname=n)
c=dict(root=remote,unit=unit,source='/home/lokad/lython-bench-checks/constant-record-b924-20261117',sourceFiles=f['imageFiles']['reference'],sourceCatalogSHA256=f['catalogSHA256'],catalogSHA256=f['catalogSHA256'],identity=identity,retireGroups=groups,payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((r/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum((r/n).stat().st_size for n in names))
(r/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:];s=s.replace('lython-b839-fixtures','lython-b925-fixtures')
(r/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
for p in r.glob('*.py'):ast.parse(p.read_text(encoding='utf-8'))
assert 'RuntimeMaxSec=150'in s
print('Prepared two current CPU profiles; existing32file image/catalog proof, current images retained,150s service cap.')
