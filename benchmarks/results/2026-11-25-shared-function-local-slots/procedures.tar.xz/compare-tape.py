from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
build=lab/'windows/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'
prepared=lab/'tape-candidate'
prepared.mkdir(exist_ok=True)
for f in (lab/'tape').glob('Tape.*'):shutil.copyfile(f,prepared/f.name)
shutil.copyfile(build,prepared/build.name)
assert sha(build)==sha(prepared/build.name)
subprocess.run([sdk/'dotnet.exe',prepared/'Tape.dll',lab/'catalog.json',lab/'tape-candidate.json'],check=True,env=env,cwd=repo,timeout=40)
old,new=(read(lab/f'tape{suffix}.json')for suffix in ('','-candidate'))
assert new['coreSHA256']==sha(build) and new['coreSHA256']!=old['coreSHA256']
summary=[]
for before,after in zip(old['rows'],new['rows'],strict=True):
    assert before['id']==after['id'] and before['retainedAdmission']==after['retainedAdmission']
    slots=0
    for a,b in zip(before['objects'],after['objects'],strict=True):
        old_declarations,new_declarations=(item.pop('LocalBindingOrder')for item in (a,b))
        assert a==b,(before['id'],a['Name'],next(field for field in a if a[field]!=b[field]))
        assert set(old_declarations)==set(new_declarations)
        if b['IsFunctionScope'] and b['Name']!='<genexpr>':
            assert b['LocalNames'][:len(new_declarations)]==new_declarations
            slots+=len(new_declarations)
    row=dict(case=before['id'],tapes=len(before['objects']),instructions=sum(len(o['Instructions'])for o in before['objects']),
             preparedSlots=slots,retainedAdmission=before['retainedAdmission'])
    print(row)
    summary.append(row)
(lab/'tape-summary.json').write_text(json.dumps(dict(reference=old['coreSHA256'],candidate=new['coreSHA256'],rows=summary),indent=2)+'\n',
    encoding='utf-8',newline='\n')
