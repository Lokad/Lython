from pathlib import Path
import hashlib, json, os, shutil, subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
donor=lab.with_name('direct-callback-return-20261125')
previous=lab.with_name('direct-operand-return-20261124')
profile=repo/'benchmarks/results/2026-11-24-frontend-phase-profile/observations.tar.xz'
read=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
write=lambda f,s:f.write_text(s,encoding='utf-8',newline='\n')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=read(donor/'comparison/quiet/identity.json')
image=donor/'candidate'
assert {p.name:sha(p) for p in image.iterdir()}==identity['imageFiles']['candidate']

import tarfile
with tarfile.open(profile) as archive:
    cases=json.load(archive.extractfile('catalog.json'))['cases']
by_id={r['id']:r['source'] for r in (*cases,*read(donor/'comparison/quiet/representative.json')['cases'])}
cases=[dict(id=case,source=source)for case,source in by_id.items()]
cases.append(dict(id='slot-order-and-implicit-scope',source='''def f(arg, /, ordinary, *extra, keyword=7, **named):
    from math import sqrt
    inner = lambda value: value + keyword
    if ordinary:
        for index in extra:
            result = sqrt(index)
        return inner(1)
    return (key for key in named)
'''))
write(lab/'catalog.json',json.dumps(dict(cases=cases),ensure_ascii=False)+'\n')
project=(previous/'tape/Tape.csproj').read_text(encoding='utf-8').replace('../reference/',image.as_posix()+'/')
source=(previous/'tape/Program.cs').read_text(encoding='utf-8')
source=source.replace('        shape.Add("DirectOperandReturn", Read(code, args[2]));',
    '''        shape.Add("IsFunctionScope", Read(code, "IsFunctionScope"));
        shape.Add("LocalBindingOrder", Encode(Read(Read(code, "ScopeFacts")!, "LocalBindingOrder")));''')
assert 'shape.Add("LocalBindingOrder"' in source
write(lab/'Tape.csproj',project)
write(lab/'Program.cs',source)
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
dotnet=sdk/'dotnet.exe'
subprocess.run([dotnet,'build',lab/'Tape.csproj','-c','Release','-o',lab/'tape'],check=True,env=env,cwd=repo,timeout=60)
assert sha(lab/'tape/Lokad.Lython.dll')==sha(image/'Lokad.Lython.dll')
subprocess.run([dotnet,lab/'tape/Tape.dll',lab/'catalog.json',lab/'tape.json'],check=True,env=env,cwd=repo,timeout=35)
tape=read(lab/'tape.json')
assert tape['coreSHA256']==sha(image/'Lokad.Lython.dll')
for row in tape['rows']:
    scopes=[obj for obj in row['objects'] if obj['IsFunctionScope']]
    named=sum(len(o['LocalBindingOrder']) for o in scopes)
    dynamic=[(o['Name'],o['LocalNames'],o['LocalBindingOrder'])for o in scopes if o['LocalNames']!=o['LocalBindingOrder']]
    print(row['id'],len(scopes),'function code objects;',named,'predeclared entries;',len(dynamic),'different slot lists')
    for name,slots,declared in dynamic[:2]:print(' ',name,repr(slots),repr(declared))
