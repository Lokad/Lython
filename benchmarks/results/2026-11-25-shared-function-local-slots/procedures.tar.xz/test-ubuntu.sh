set -eu
lab="$PWD/.git/agent-notes/review-20261031/shared-function-local-slots-20261125"
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
filter='FullyQualifiedName~ExecutableArchitecture|FullyQualifiedName~ParameterLocalOrder|FullyQualifiedName~SyntaxValidity|FullyQualifiedName~ScopeDirective|FullyQualifiedName~ComprehensionLambda|FullyQualifiedName~NativeReturnFunction|FullyQualifiedName~GeneratorDefinition|FullyQualifiedName~CompiledGeneratorExpression|FullyQualifiedName~ClassMethodCompatibility|FullyQualifiedName~MatchGuardScope|FullyQualifiedName~StaticFactCancellation|FullyQualifiedName~AdmissionFailureCommand'
for target in net11.0 net10.0; do
 for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="$lab/ubuntu-$target-$suite.log"
    if "$DOTNET_ROOT/dotnet" test "tests/$suite/$suite.csproj" -c Release -f "$target" --artifacts-path "$lab/ubuntu" --filter "$filter" > "$log" 2>&1; then
        tail -3 "$log"
    else
        tail -48 "$log"
        exit 1
    fi
 done
done
