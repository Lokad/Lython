from pathlib import Path

lab=Path(__file__).resolve().parent
previous=lab.with_name('direct-callback-return-20261125')
script=(previous/'verify-and-free-space.py').read_text(encoding='utf-8')
script=script.replace("source=pair/'candidate'/core", "source=operand/'candidate'/core")
script=script.replace('verified-b1658-candidate.dll','verified-b1659-candidate.dll')
start=script.index('stages=(')
end=script.index('copies=[]',start)
script=script[:start]+'''callback=lab.with_name('direct-callback-return-20261125')
layout=lab.with_name('terminal-backed-operand-layout-20261124')
stages=(
    ('direct-operand-return-b1659-20261124','b1659-direct-operand-return-20261124','candidate',operand/'comparison/quiet'),
    ('direct-operand-confirmation-b1659-20261124','b1659-direct-operand-confirmation-20261124','candidate',operand/'confirmation'),
    ('defaulted-rule-phase-split-b1660-20261125','b1660-defaulted-rule-phase-split-20261125','candidate',split/'confirmation'),
    ('direct-callback-return-b1661-20261125','b1661-direct-callback-return-20261125','reference',callback/'comparison/quiet'),
)
replicas=(stages[-1],
    ('terminal-backed-operand-layout-b1653-20261124','b1653-terminal-backed-operand-layout-20261124','candidate',layout/'comparison/quiet'))
'''+script[end:]
script=script.replace('for stage,label,_,folder in stages[2:]:','for stage,label,_,folder in replicas:')
file=lab/'verify-and-free-space.py'
compile(script,str(file),'exec')
file.write_text(script,encoding='utf-8',newline='\n')
