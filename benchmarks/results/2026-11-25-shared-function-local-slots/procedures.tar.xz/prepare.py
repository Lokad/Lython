from pathlib import Path
import json

lab=Path(__file__).resolve().parent
prior=lab.with_name('direct-callback-return-20261125')
operand=lab.with_name('direct-operand-return-20261124')
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
write=lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
receipt=read(prior/'comparison/quiet/terminal-status.json')['receipt']
ref=read(operand/'comparison/quiet/terminal-status.json')['receipt']
script=(prior/'verify-and-stage.py').read_text(encoding='utf-8')
script=script.replace("donor=lab.with_name('direct-operand-return-20261124')", "donor=lab.with_name('direct-callback-return-20261125')")
script=script.replace('e32e2817b','d28266d7b')
start=script.index('rows=2048')
end=script.index('shutil.copyfile',start)
script=script[:start]+'''with tarfile.open(repo/'benchmarks/results/2026-11-24-frontend-phase-profile/observations.tar.xz') as archive:
    frontend=json.load(archive.extractfile('catalog.json'))
rule='scripts.rule-default-closures'
invoice='scripts.csv-invoice.method-policy.quoted-control'
classifier='diagnostic.generated-record-classifier'
manifest='scripts.config-manifest.small'
validator='scripts.config-generated-guards.medium.bad-0.sparse-lexical'
catalog=read(prior/'representative.json')
cases={r['id']:r for r in (*frontend['cases'],*catalog['cases'])}
catalog['cases']=[cases[key] for key in (rule,manifest,validator,classifier,invoice)]
save(quiet/'representative.json',catalog)
save(quiet/'jobs.json',{'warm':[[rule,'compile'],[validator,'compile'],[invoice,'warm'],[manifest,'compile'],[classifier,'compile'],[rule,'compile-run']]})
'''+script[end:]
script=script.replace("referencePatchSHA256=old['sourcePatchSHA256']", "referencePatchSHA256=[old['referencePatchSHA256'],old['sourcePatchSHA256']]")
script=script.replace('Borrow existing operands for complete short positional callbacks that satisfy the direct operand-return proof','Share lexical declarations with emitted function locals and extend only when synthetic names are added')
start=script.index('collector=')
end=script.index("compile(collector",start)
script=script[:start]+'''collector=(prior/'collect.py').read_text(encoding='utf-8').replace('b1661-fixtures','b1662-fixtures').replace('len(jobs) == 5','len(jobs) == 6').replace('targetBatchSeconds=.60','targetBatchSeconds=.56')
'''+script[end:]
script=script.replace("checked['caseCount']==3", "checked['caseCount']==5")
script=script.replace("root='direct-callback-return-b1661-20261125',reference='direct-operand-return-b1659-20261124'", "root='shared-function-local-slots-b1662-20261125',reference='direct-callback-return-b1661-20261125'")
script=script.replace('three complete workload goldens','five complete workload goldens')
compile(script,'verify-and-stage.py','exec')
write(lab/'verify-and-stage.py',script)
launcher=(prior/'quiet.py').read_text(encoding='utf-8').replace(ref['archiveSHA256'],receipt['archiveSHA256'])
launcher=launcher.replace('b1661-','b1662-').replace('direct-callback-return-20261125','shared-function-local-slots-20261125')
launcher=launcher.replace('seconds=232','seconds=251').replace('RuntimeMaxSec=295','RuntimeMaxSec=320')
assert receipt['archiveSHA256'] in launcher
compile(launcher,'quiet.py','exec')
write(lab/'quiet.py',launcher)
report=(prior/'archive.py').read_text(encoding='utf-8').replace('2026-11-25-direct-callback-return','2026-11-25-shared-function-local-slots')
report=report.replace('receipt["warmJobs"]==5','receipt["warmJobs"]==6').replace('timedBatches=140,lanes=5','timedBatches=168,lanes=6')
compile(report,'archive.py','exec')
write(lab/'archive.py',report)
