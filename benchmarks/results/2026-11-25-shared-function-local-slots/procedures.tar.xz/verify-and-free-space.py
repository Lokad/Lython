from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
quiet=lab/'comparison/quiet'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda data:hashlib.sha256(data).hexdigest()
sha=lambda p:digest(p.read_bytes())
pair=lab.with_name('pair-owned-defaults-20261124')
operand=lab.with_name('direct-operand-return-20261124')
split=lab.with_name('defaulted-rule-phase-split-20261125')
core='Lokad.Lython.dll'
source=operand/'candidate'/core
backup=lab/'verified-b1659-candidate.dll'
shutil.copyfile(source,backup)
assert sha(source)==sha(backup)

def archive_info(folder):
    receipt=read(folder/'terminal-status.json')['receipt']
    assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
    assert sha(folder/'observations.tar.xz')==receipt['archiveSHA256']
    return receipt['archiveSHA256']

callback=lab.with_name('direct-callback-return-20261125')
layout=lab.with_name('terminal-backed-operand-layout-20261124')
stages=(
    ('direct-operand-return-b1659-20261124','b1659-direct-operand-return-20261124','candidate',operand/'comparison/quiet'),
    ('direct-operand-confirmation-b1659-20261124','b1659-direct-operand-confirmation-20261124','candidate',operand/'confirmation'),
    ('defaulted-rule-phase-split-b1660-20261125','b1660-defaulted-rule-phase-split-20261125','candidate',split/'confirmation'),
    ('direct-callback-return-b1661-20261125','b1661-direct-callback-return-20261125','reference',callback/'comparison/quiet'),
)
replicas=(stages[-1],
    ('terminal-backed-operand-layout-b1653-20261124','b1653-terminal-backed-operand-layout-20261124','candidate',layout/'comparison/quiet'))
copies=[]
for stage,label,role,folder in stages:
    assert read(folder/'identity.json')['imageFiles'][role][core]==sha(backup)
    copies.append(dict(stage=stage,unit='lython-'+label,archive=archive_info(folder),member=role+'/'+core,role=role))
raw=[]
for stage,label,_,folder in replicas:
    checksum=archive_info(folder)
    name='confirmation/confirmation.json'
    with tarfile.open(folder/'observations.tar.xz') as archive:
        member=archive.getmember(name)
        assert member.isfile()
        raw.append(dict(stage=stage,unit='lython-'+label,archive=checksum,member=name,
             bytes=member.size,sha=digest(archive.extractfile(member).read())))

payload=quiet/'payload.tar.gz'
assert sha(payload)==read(quiet/'upload.json')['payloadSHA256']
with tarfile.open(payload) as bundle: sizes=[m.size for m in bundle.getmembers()]
script=f'copies={copies!r}\nraw={raw!r}\ncore_hash={sha(backup)!r}\ncore_size={backup.stat().st_size}\nsizes={sizes!r}\ncompressed={payload.stat().st_size}\n'+'''
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def checked(record):
    root=base/record['stage']
    assert root.resolve()==root and not (root/'guest-fixtures').exists()
    status=subprocess.check_output(['systemctl','show',record['unit']+'.service','-p','ActiveState,MainPID'],text=True)
    assert 'ActiveState=inactive' in status and 'MainPID=0' in status, status
    marker=json.loads((root/'archive-receipt.json').read_text())
    assert marker['complete'] and marker['allWorkersJoined'] and marker['archivedAndVerifiedUnderLease']
    assert marker['archiveSHA256']==record['archive']==sha(root/'observations.tar.xz')
    target=root/record['member']
    assert target.resolve()==target and target.is_relative_to(root)
    return root,target
with (base/'comparison-vm.lock').open('a') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    free=shutil.disk_usage(base).free
    block=os.statvfs(base).f_frsize
    required=max(compressed+1400*1024,sum((n+block-1)//block*block for n in sizes)+1912*1024)
    available=free
    selected=[]
    if available<required:
        links=[]
        for record in copies:
            root,target=checked(record)
            info=target.lstat()
            assert stat.S_ISREG(info.st_mode) and info.st_nlink==len(copies) and info.st_size==core_size
            assert json.loads((root/'identity.json').read_text())['imageFiles'][record['role']][target.name]==core_hash==sha(target)
            links.append((record,target,info))
        assert len({(info.st_dev,info.st_ino) for _,_,info in links})==1
        selected.extend(links)
        available+=links[0][2].st_blocks*512
    for record in raw:
        if available>=required:break
        root,target=checked(record)
        if not target.exists():continue
        info=target.lstat()
        assert stat.S_ISREG(info.st_mode) and info.st_nlink==1 and info.st_size==record['bytes'] and sha(target)==record['sha']
        selected.append((record,target,info))
        available+=info.st_blocks*512
    assert available>=required,(free,available,required)
    for record,target,_ in selected:
        target.unlink()
        assert sha(base/record['stage']/'observations.tar.xz')==record['archive']
    after=shutil.disk_usage(base).free
    assert after>=required
    print(json.dumps(dict(freeBefore=free,required=required,freeAfter=after,verifiedDuplicatesRetired=[record for record,_,_ in selected],coreHash=core_hash)))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73','python3 -']
result=subprocess.run(ssh,input=script,encoding='utf-8',capture_output=True,timeout=35)
print(result.stdout,result.stderr,end='')
result.check_returncode()
(lab/'retired-stage-custody.json').write_text(result.stdout,encoding='utf-8',newline='\n')