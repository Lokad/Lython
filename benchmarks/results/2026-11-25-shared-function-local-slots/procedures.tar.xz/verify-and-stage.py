from pathlib import Path
import base64,hashlib,importlib.util,json,os,shutil,subprocess,tarfile,tempfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
donor=lab.with_name('direct-callback-return-20261125')
prior=donor/'comparison/quiet'
quiet=lab/'comparison/quiet'
quiet.mkdir(parents=True,exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
digest=lambda s:hashlib.sha256(s.encode('utf-8')).hexdigest()
write=lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
save=lambda p,d:write(p,json.dumps(d,ensure_ascii=False,indent=2)+'\n')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head.startswith('d28266d7b')
patch=lab/'candidate.patch'
assert subprocess.check_output(['git','diff','--binary','--','src'],cwd=repo)==patch.read_bytes()
old=read(prior/'identity.json')
base=old['sourceRevision']
assert old['sourcePatchSHA256']==sha(donor/'candidate.patch')
core='Lokad.Lython.dll'
reference=old['imageFiles']['candidate']
assert len(reference)==32 and {p.name:sha(p) for p in (donor/'candidate').iterdir()}==reference
candidate=lab/'candidate-build/bin/Lokad.Lython/release_net11.0'/core
images={'reference':reference,'candidate':reference | {core:sha(candidate)}}
assert images['candidate'][core]!=reference[core]
for role,files in images.items():
    folder=lab/role
    folder.mkdir(exist_ok=True)
    for name in files:
        shutil.copyfile(candidate if role=='candidate' and name==core else donor/'candidate'/name,folder/name)
    assert {p.name:sha(p) for p in folder.iterdir()}==files

path=repo/'benchmarks/cpython-worker.py'
assert sha(path)==old['cpythonWorkerSHA256']
spec=importlib.util.spec_from_file_location('protocol',path)
protocol=importlib.util.module_from_spec(spec)
spec.loader.exec_module(protocol)
python=Path('C:/Python313/python.exe')
with tarfile.open(repo/'benchmarks/results/2026-11-24-frontend-phase-profile/observations.tar.xz') as archive:
    frontend=json.load(archive.extractfile('catalog.json'))
rule='scripts.rule-default-closures'
invoice='scripts.csv-invoice.method-policy.quoted-control'
classifier='diagnostic.generated-record-classifier'
manifest='scripts.config-manifest.small'
validator='scripts.config-generated-guards.medium.bad-0.sparse-lexical'
catalog=read(prior/'representative.json')
cases={r['id']:r for r in (*frontend['cases'],*catalog['cases'])}
catalog['cases']=[cases[key] for key in (rule,manifest,validator,classifier,invoice)]
save(quiet/'representative.json',catalog)
save(quiet/'jobs.json',{'warm':[[rule,'compile'],[validator,'compile'],[invoice,'warm'],[manifest,'compile'],[classifier,'compile'],[rule,'compile-run']]})
shutil.copyfile(prior/'run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
identity=dict(sourceRevision=base,validationSourceRevision=head,comparisonRevision=base,referencePatchSHA256=[old['referencePatchSHA256'],old['sourcePatchSHA256']],sourcePatchSHA256=sha(patch),
    purpose='Share lexical declarations with emitted function locals and extend only when synthetic names are added',
    imageFiles=images,expectedCPythonSHA256=old['expectedCPythonSHA256'],cpythonWorkerSHA256=old['cpythonWorkerSHA256'],
    coreSHA256={role+suffix:files[core] for role,files in images.items() for suffix in ('','-control')},
    catalogs={name:{'sha256':sha(quiet/name)} for name in ('representative.json','jobs.json')})
save(quiet/'identity.json',identity)
collector=(prior/'collect.py').read_text(encoding='utf-8').replace('b1661-fixtures','b1662-fixtures').replace('len(jobs) == 5','len(jobs) == 6').replace('targetBatchSeconds=.60','targetBatchSeconds=.56')
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
sdk=Path.home()/'.dotnet11'
for role,files in images.items():
    output=lab/f'comparison/{role}-verify.json'
    subprocess.run([sdk/'dotnet.exe',lab/role/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'representative.json',
        '--dotnet',sdk/'dotnet.exe','--python',python,'--python-worker',path,'--out',output],cwd=repo,
        env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk)),check=True,timeout=75)
    checked=read(output)
    assert checked['state']=='Completed' and checked['caseCount']==5 and checked['launched']['library']['sha256']==files[core]
    assert checked['catalogSha256']==identity['catalogs']['representative.json']['sha256']
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=3) as bundle:
    for name in ('identity.json','jobs.json','representative.json','collect.py','run.sh'):
        bundle.add(quiet/name,arcname=name)
    bundle.add(candidate,arcname='candidate-core.dll')
save(quiet/'upload.json',dict(root='shared-function-local-slots-b1662-20261125',reference='direct-callback-return-b1661-20261125',
    payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
save(lab/'verified-raw-replicas.json',[])
print('Verified five complete workload goldens on each exact image.')
