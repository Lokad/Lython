set -e
cd /mnt/d/code/Lython/.git/agent-worktrees/split-range-reuse-r655
export PATH="$HOME/.dotnet:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/split-range-reuse-r655
out="$PWD/tests/artifacts/r655-wsl"
filter='(FullyQualifiedName~Split|FullyQualifiedName~Unpack|FullyQualifiedName~Trim|FullyQualifiedName~CasedString|FullyQualifiedName~DelayedTextFile)&Category!=Stress'
for p in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="$logs/$p-wsl-net10.log"
    dotnet test "tests/$p" -c Release -f net10.0 --artifacts-path "$out" --filter "$filter" > "$log" 2>&1 || (tail -26 "$log"; exit 1)
    tail -5 "$log"
done
