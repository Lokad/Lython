from collections import Counter
from pathlib import Path
import base64, hashlib, json, struct, tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
archive = repo / "benchmarks/results/2026-11-23-reusable-private-word-admission/observations.tgz"
with tarfile.open(archive) as items:
    catalog = json.load(items.extractfile("representative.json"))
cases = {row["id"]: row for row in catalog["cases"]}

def required_word_count(case):
    encoded = json.loads(case["fixtureJson"])["inputFiles"]["input.txt"]
    rows = base64.b64decode(encoded).decode("utf-8").splitlines()
    counts = Counter(word for row in rows for word in row.lower().split())
    return sum(count - 1 for word, count in counts.items() if 8 < len(word.encode("utf-8")) <= 4096)

mixed = cases["diagnostic.text-summary.ordinary-histogram.large"].copy()
wide = cases["diagnostic.text-summary.materialized-wide"].copy()
rewrites = [
    (mixed, "diagnostic.text-summary.borrowed-cased-words.mixed-width",
     ("for words in map(words_from_line, source):", "for line in source:"), ("for word in words:", "for word in words_from_line(line):")),
    (wide, "diagnostic.text-summary.borrowed-cased-words.repeated-unicode",
     ("            words = words_from_line(line)\n", ""), ("for word in words:", "for word in words_from_line(line):")),
]
for case, name, *changes in rewrites:
    case["id"] = name
    source = case["source"]
    for old, new in changes:
        assert source.count(old) == 1, old
        source = source.replace(old, new)
    case["source"] = source
    utf8 = source.encode("utf-8")
    case["sourceUtf8Bytes"] = len(utf8)
    case["sourceSha256"] = hashlib.sha256(utf8).hexdigest()
    print(name, required_word_count(case))
unique = mixed.copy()
unique["id"] = "diagnostic.text-summary.borrowed-cased-words.unique-medium"
words = [f"REGION{n:04d}SECTOR" for n in range(2048)]
text = "".join(" ".join(words[start:start + 8]) + "\n" for start in range(0, len(words), 8))
report = "".join(word.lower() + "=1\n" for word in words).encode("utf-8")
output = f"{len(words)}\n"
fixture = json.dumps({"size": len(words), "text": None,
    "inputFiles": {"input.txt": base64.b64encode(text.encode("utf-8")).decode("ascii")},
    "outputFiles": {"report.txt": base64.b64encode(report).decode("ascii")}}, separators=(",", ":"))
report_name = b"report.txt"
digest = hashlib.sha256
unique.update(size=len(words), fixtureJson=fixture, expectedOutput=output,
    fixtureSha256=digest(fixture.encode("utf-8")).hexdigest(),
    expectedOutputUtf8Bytes=len(output.encode("utf-8")), expectedOutputSha256=digest(output.encode("utf-8")).hexdigest(),
    expectedFilesSha256=digest(struct.pack(">ii", 1, len(report_name)) + report_name + struct.pack(">i", len(report)) + report).hexdigest())
controls = [cases[name] for name in (
    "diagnostic.text-summary.nonlocal-computed-width.large",
    "diagnostic.text-summary.materialized-ordinary-split",
    "scripts.csv-invoice.method-policy.quoted-control",
)]
catalog["cases"] = [mixed, wide, unique, *controls]
catalog["performanceQualified"] = False
for name, data in (
        ("representative.json", catalog),
        ("jobs.json", {"warm": [[case["id"], "warm"] for case in catalog["cases"]]})):
    (lab / name).write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8", newline="\n")
