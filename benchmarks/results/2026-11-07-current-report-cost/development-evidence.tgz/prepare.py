from pathlib import Path
import ast, hashlib, json, subprocess, tarfile

root = Path(__file__).parent
prior = root.parent / 'execution-transport-r29'
remote = '/home/lokad/lython-bench-checks/report-cost-b385-20261107'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert head == '2f1f271548b7671fd1177e41bb0cb89e9f928c69'
assert not subprocess.check_output(['git', 'diff', '--name-only', '--', 'src'], text=True).strip()
core = Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll')
digest = hashlib.sha256(core.read_bytes()).hexdigest()
focused = json.loads((root.parent/'cold-string-hash-r33/focused-initial.json').read_text(encoding='utf-8-sig'))
assert digest == focused['coreSHA256']['net11.0'] == '07a6530e13a7a681c2de48d756c7490765ebce7195b59a734f6de1ac84745b92'
identity = json.loads((prior/'identity.json').read_text(encoding='utf-8-sig'))
identity['files']['Lokad.Lython.dll'] = digest
identity['sourceRevision'] = head
identity['sourceSHA256'] = {str(p).replace('\\','/'): hashlib.sha256(p.read_bytes()).hexdigest()
    for p in Path('src/Lokad.Lython').rglob('*.cs') if 'obj' not in p.parts and 'bin' not in p.parts}
(root/'identity.json').write_text(json.dumps(identity, indent=2)+'\n', encoding='utf-8')
catalog = prior/'comparison-catalog.json'
data = json.loads(catalog.read_text(encoding='utf-8-sig'))
cases = [c['id'] for c in data['cases'] if 'report-render' in c['id']]
assert 'scripts.report-render.large' in cases, cases
(root/'catalog.json').write_bytes(catalog.read_bytes())
profile = (prior/'ops-profile.py').read_text(encoding='utf-8-sig')
profile = profile.replace('/home/lokad/lython-bench-checks/execution-transport-b377-20261107', remote)
profile = profile.replace('("text-warm", "scripts.text-summary-helpers.large", "warm")', '("report-warm", "scripts.report-render.large", "warm")')
# CPU attribution needs no generated-code listing this time. Keep raw stacks,
# actual guest TIDs, all unknowns, output/funding checks and the existing protocol.
profile = profile.replace('        env["DOTNET_JitDisasm"]="ExecuteInstructionPrefix CompleteLocalResult StoreExecutableLocal"\n', '')
profile = profile.replace('        env["DOTNET_JitStdOutFile"]=str(folder/"prefix-jit.txt")\n', '')
profile = profile.replace('["DOTNET_PerfMapEnabled","DOTNET_JitDisasm","DOTNET_JitStdOutFile"]', '["DOTNET_PerfMapEnabled"]')
profile = profile.replace('output = pathlib.Path(sys.argv[1]).resolve()', 'output = pathlib.Path(sys.argv[1]).resolve()')
assert 'scripts.text-summary-helpers.large' not in profile
(root/'ops-profile.py').write_text(profile, encoding='utf-8', newline='\n')
analyze = (prior/'analyze-cpu-guest.py').read_text(encoding='utf-8-sig')
(root/'analyze-cpu-guest.py').write_text(analyze, encoding='utf-8', newline='\n')
archive = (prior/'archive.py').read_text(encoding='utf-8-sig').replace('/home/lokad/lython-bench-checks/execution-transport-b377-20261107', remote).replace('text-warm', 'report-warm')
# The raw RAM trace is explicitly included, validated and persistently archived
# under the lease; it must not be the sole evidence after fixture cleanup.
archive = archive.replace("root/'perf'/case/'record.json'", "Path('/dev/shm/lython-report-cost-b385')/case/'record.json'")
archive = archive.replace("root/'perf'/case/'worker.stderr'", "Path('/dev/shm/lython-report-cost-b385')/case/'worker.stderr'")
archive = archive.replace("with tarfile.open(root/'observations.tgz','w:gz',dereference=True) as a:", "with tarfile.open(root/'observations.tgz','w:gz',dereference=True) as a:\n a.add('/dev/shm/lython-report-cost-b385',arcname='perf')")
(root/'archive.py').write_text(archive, encoding='utf-8', newline='\n')
run = (prior/'run.sh').read_text(encoding='utf-8-sig').replace('/home/lokad/lython-bench-checks/execution-transport-b377-20261107', remote).replace('"$root/perf"', '"/dev/shm/lython-report-cost-b385"').replace('text-warm','report-warm').replace('"$root/perf/$case"', '"/dev/shm/lython-report-cost-b385/$case"').replace('"$root/perf/report-warm/perf.data"', '"/dev/shm/lython-report-cost-b385/report-warm/perf.data"')
run += "python3 - <<'PY'\nfrom pathlib import Path\nimport shutil\np=Path('/dev/shm/lython-report-cost-b385')\nassert p.is_dir() and not p.is_symlink() and p.resolve()==p\nshutil.rmtree(p)\nPY\n"
(root/'run.sh').write_text(run, encoding='utf-8', newline='\n')
for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py']:ast.parse((root/name).read_text(encoding='utf-8'))
contract = '''# R34 bounded current report cost gate

One existing complete report-render.large warm script, current committed2f1f2715
production source/focused07a6530e image. No runtime prototype or timing comparison.
Six-second guest warmup, two-second settling, one six-second CPU-clock capture at
199Hz, normal GC/tiering; existing checked worker and optional0.4 adapter unchanged.
Include mediated RAM I/O, full goldens and prior-result cleanup; exclude compile,
startup, staging/reset and final teardown. Preserve raw stacks, every actual guest
TID and unknown leaf. Diagnostic clocks do not establish uninstrumented performance.

Question: after the delivered context/return/record/UTF8 changes, is remaining
report cost concentrated in call/frame transport, per-record construction or text
format/storage? Existing text B377 attribution cannot establish this for report.
No second profile merely for a favorable distribution. At completion select one
source-backed deletion milestone, or state the missing proof and next alternative.
Preserve cancellation, first refusal, alias funding and actual-user cleanup.

Existing source gates already rule out per-small-add admission, general completed
JSON token state machines, ordinary per-character casing strings and late mutable
global native proofs. They already have delivered guards/fast paths; no prototypes
for those proposed absent costs. Do not claim their source inspection is CPU proof.

Existing VM lease/Ready/goldens/quiet/funding/Closed/joins/archive gates apply.
120s owner+30s stop+30s margin, recorded before observing. Persistent inputs/logs/
verified archive, RAM raw trace with under-lease archive and removal after users join.
No sole evidence in RAM. Retire only independently committed hash-verified redundant
expanded data before staging; keep all historical adverse/failure conditions.
'''
(root/'source-contract.md').write_text(contract,encoding='utf-8',newline='\n')
with tarfile.open(root/'payload.tgz','w:gz') as a:
    for name in ['identity.json','catalog.json','ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','source-contract.md']:
        a.add(root/name,arcname=name)
    a.add(core,arcname='current-core.dll')
print(json.dumps(dict(head=head,coreSHA256=digest,cases=cases,payloadBytes=(root/'payload.tgz').stat().st_size)))
