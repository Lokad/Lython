from pathlib import Path
import hashlib, json, os, shutil, subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
notes=lab.parent
tree=repo/'.git/agent-worktrees/plain-class-module-slots-20261123'
donor=notes/'terminal-tuple-reads-20261123'
comparison=lab/'comparison'
comparison.mkdir(exist_ok=True)
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):
    path.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
git=lambda *args,cwd=repo:subprocess.check_output(['git',*args],cwd=cwd).decode().strip()
reference,candidate=git('rev-parse','48bf2bc2f'),git('rev-parse','HEAD',cwd=tree)
assert reference.startswith('48bf2bc2f') and not git('status','--porcelain',cwd=tree)
assert not git('diff','--name-only',reference,'HEAD','--','src','tests')
proof=read(donor/'comparison/identity.json')
files=proof['imageFiles']['candidate']
assert len(files)==32 and all(digest(donor/'candidate'/name)==expected for name,expected in files.items())
catalog=read(notes/'supplied-lexical-call-20261123/comparison/representative.json')
pool=(
    read(notes/'native-fixed-return-refined-20261122/representative.json'),
    read(notes/'inline-aggregate-tuples-20261123/comparison/representative.json'),
    catalog,
)
lookup={item['id']:item for source in pool for item in source['cases']}
cases=(
    'scripts.csv-invoice.method-policy.quoted-control',
    'scripts.csv-invoice.helper-accumulation',
    'scripts.csv-invoice.large',
    'scripts.csv-meter-report.explicit-float.observe-tuple',
    'scripts.csv-meter-report.explicit-float',
    'scripts.ordinary-fully-supplied-helper.local-function',
    'scripts.config-manifest.small',
)
catalog['cases']=[lookup[name] for name in cases]
write(comparison/'representative.json',catalog)
runtime=Path.home()/'.dotnet11'
dotnet=runtime/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(runtime),DOTNET_ROOT_X64=str(runtime))
protocol=repo/'benchmarks/cpython-worker.py'
assert digest(protocol)==proof['cpythonWorkerSHA256']
core='Lokad.Lython.dll'
actual={}
for role in ('reference','candidate'):
    image=lab/role
    image.mkdir(exist_ok=True)
    for name in files:
        source=lab/'frozen/bin/Lokad.Lython/release_net11.0'/core if role=='candidate' and name==core else donor/'candidate'/name
        shutil.copyfile(source,image/name)
    for helper in ('ValidatedAllocation','Inspect'):
        for suffix in ('.dll','.deps.json','.runtimeconfig.json'):
            name=helper+suffix
            shutil.copyfile(donor/'candidate'/name,image/name)
    actual[role]={name:digest(image/name) for name in files}
    verified=comparison/(role+'-verify.json')
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',comparison/'representative.json',
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',protocol,'--out',verified],
        env=env,check=True,timeout=85)
    result=read(verified)
    assert result['state']=='Completed' and result['caseCount']==len(cases)
    assert result['launched']['library']['sha256']==actual[role][core]
    subprocess.run([dotnet,image/'Inspect.dll',comparison/'representative.json',lab/(role+'-tape.json')],
        env=env,check=True,timeout=30)
    assert all(digest(image/name)==expected for name,expected in actual[role].items())
assert [name for name in files if actual['reference'][name]!=actual['candidate'][name]]==[core]
write(comparison/'identity.json',dict(sourceRevision=reference,candidate=candidate,
    purpose='B1533 keep owned slots for a plain class while preserving reusable namespaces',
    imageFiles=actual,cpythonWorkerSHA256=proof['cpythonWorkerSHA256'],expectedCPythonSHA256=proof['expectedCPythonSHA256'],
    catalogs={'representative.json':{'sha256':digest(comparison/'representative.json')}}))
shutil.copyfile(donor/'allocations.py',lab/'allocations.py')
