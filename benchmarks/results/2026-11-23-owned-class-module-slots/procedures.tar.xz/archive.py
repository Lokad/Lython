from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
dest = repo / 'benchmarks/results/2026-11-23-owned-class-module-slots'
quiet = lab / 'comparison/quiet'
identity = json.loads((lab / 'comparison/identity.json').read_text(encoding='utf-8'))
status = json.loads((quiet / 'terminal-status.json').read_text(encoding='utf-8'))
receipt = status['receipt']


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo)


retained = git('rev-parse', '0112138c1').decode().strip()
assert not git('diff', '--name-only', retained, identity['candidate'], '--', 'src', 'tests')
assert status['exitCode'] == '0' and not status['live'] and not status['fixtures']
assert all(receipt[key] for key in ('complete', 'allWorkersJoined', 'guestFixturesRemoved',
                                   'quietBeforeAndAfter', 'archivedAndVerifiedUnderLease'))
assert sha((quiet / 'observations.tar.xz').read_bytes()) == receipt['archiveSHA256']
assert json.loads((quiet / 'summary.json').read_text(encoding='utf-8'))['timedBatches'] == 84
dest.mkdir(exist_ok=True)
assert all(path.name == 'README.md' for path in dest.iterdir())
for role, files in identity['imageFiles'].items():
    assert len(files) == 32
    assert all(sha((lab / role / name).read_bytes()) == expected for name, expected in files.items())
patch = git('diff', '--binary', identity['sourceRevision'], retained, '--', 'src', 'tests')
(lab / 'comparison.patch').write_bytes(patch)
identity['retainedRevision'] = retained
identity['comparisonPatchSHA256'] = sha(patch)
identity['verifiedReplicasRetired'] = json.loads((quiet / 'launch.log').read_text(encoding='utf-8'))['verifiedDuplicateRetired']
(dest / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8', newline='\n')
(dest / 'candidate-core.dll.gz').write_bytes(gzip.compress((lab / 'candidate/Lokad.Lython.dll').read_bytes(), mtime=0))
shutil.copyfile(lab / 'allocation-summary-six.json', dest / 'allocation-summary.json')
for name in ('observations.tar.xz', 'summary.json', 'terminal-status.json'):
    shutil.copyfile(quiet / name, dest / name)
with tarfile.open(dest / 'procedures.tar.xz', 'w:xz') as bundle:
    for name in ('archive.py', 'configure.py', 'prepare.py', 'prepare-jobs.py', 'stage.py', 'quiet.py', 'summarize.py',
                 'allocations.py', 'test-ubuntu.sh', 'comparison.patch', 'reference-tape.json', 'candidate-tape.json',
                 'windows-public.log', 'windows-white.log', 'ubuntu-public.log', 'ubuntu-white.log',
                 'windows-initial-namespace-fix.log', 'initial-staging.txt', 'windows-build.log',
                 'reference-allocation-six.json', 'candidate-allocation-six.json', 'comparison/reference-verify.json',
                 'comparison/candidate-verify.json', 'comparison/quiet/launch.log', 'verified-replicas.json'):
        bundle.add(lab / name, arcname=name)
print(dest)
