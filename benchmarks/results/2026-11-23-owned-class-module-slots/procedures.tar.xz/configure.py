from pathlib import Path
import gzip
import hashlib
import json
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.with_name('plain-class-checkpoint-20261123')


def adapt(name, substitutions):
    src = (prior / name).read_text(encoding='utf-8')
    for before, after in substitutions:
        assert src.count(before) == 1, (name, before)
        src = src.replace(before, after)
    compile(src, str(lab / name), 'exec')
    (lab / name).write_text(src, encoding='utf-8', newline='\n')


adapt('prepare.py', (
    ("git('rev-parse','HEAD^',cwd=tree)", "git('rev-parse','48bf2bc2f')"),
    ('B1532 keep module slots for a plain class and reuse fixed integer return transport',
     'B1533 keep owned slots for a plain class while preserving reusable namespaces'),
))
adapt('prepare-jobs.py', (
    ("jobs=[(quote['id'],'warm'),(quote['id'],'compile-run'),(nested['id'],'warm'),\n    (manifest['id'],'compile-run'),(supplied['id'],'warm')]",
     "jobs=[(quote['id'],'warm'),(quote['id'],'compile-run'),(manifest['id'],'compile-run')]"),
))
adapt('stage.py', (
    ('plain-class-module-slots-b1532-20261123', 'plain-class-namespace-b1533-20261123'),
    ('lython-b1532-fixtures', 'lython-b1533-fixtures'),
    ('len(jobs) == 5', 'len(jobs) == 3'),
    ('< 270,', '< 190,'),
))
adapt('quiet.py', (
    ('lython-b1532-plain-class-module-slots-20261123', 'lython-b1533-plain-class-namespace-20261123'),
    ('.+b1532-', '.+b1533-'),
    ('lython-b1532-stage-', 'lython-b1533-stage-'),
    ('Five bounded lanes', 'Three bounded lanes'),
    ('RuntimeMaxSec=320', 'RuntimeMaxSec=230'),
    ('seconds=248', 'seconds=150'),
    ('configuration["unit"]=unit',
     '''configuration["unit"]=unit
configuration["duplicates"]=json.loads((lab/"verified-replicas.json").read_text(encoding="utf-8"))'''),
    ("  assert free >= minimum,(free,'needs one core, receipts and working room')",
     """  retired=[]
  if free < minimum:
   verified=[]
   available=free
   for saved in configuration['duplicates']:
    replica=base/saved['path']
    archive=replica.parent.parent/'observations.tar.xz'
    assert replica.resolve()==replica and replica.is_file() and replica.stat().st_nlink==1
    assert digest(replica)==saved['sha256'] and digest(archive)==saved['observationSHA256']
    verified.append((replica,saved))
    available+=replica.stat().st_blocks*512
    if available>=minimum: break
   assert available>=minimum,(available,minimum)
   for replica,saved in verified:
    replica.unlink()
    retired.append(saved)
   free=shutil.disk_usage(base).free
  assert free >= minimum,(free,'needs one core, receipts and working room')"""),
    ('freeBefore=free,freeBeforeLaunch=', 'verifiedDuplicateRetired=retired,freeBefore=free,freeBeforeLaunch='),
))
adapt('summarize.py', (
    ('== 5\nassert hashlib', '== 3\nassert hashlib'),
    ('len(warm["jobs"])==5', 'len(warm["jobs"])==3'),
    ('timedBatches=140', 'timedBatches=84'),
))

def sha(data):
    return hashlib.sha256(data).hexdigest()


def verify_replica(directory, remote, role):
    archive = 'benchmarks/results/' + directory + '/'

    def fetch(name):
        return subprocess.check_output(['git', 'show', 'origin/master:' + archive + name], cwd=repo)

    identity = json.loads(fetch('identity.json'))
    receipt = json.loads(fetch('terminal-status.json'))['receipt']
    assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
    assert sha(fetch('observations.tar.xz')) == receipt['archiveSHA256']
    backup_name = role + '-core.dll.gz'
    backup = gzip.decompress(fetch(backup_name))
    assert sha(backup) == identity['imageFiles'][role]['Lokad.Lython.dll']
    return dict(path=remote + '/' + role + '/Lokad.Lython.dll', sha256=sha(backup),
                observationSHA256=receipt['archiveSHA256'], trackedArchive=archive + backup_name)


replicas = [
    verify_replica('2026-11-23-terminal-tuple-reads', 'terminal-tuple-reads-b1531-20261123', 'reference'),
    verify_replica('2026-11-23-plain-class-module-slots', 'plain-class-module-slots-b1532-20261123', 'candidate'),
]
(lab / 'verified-replicas.json').write_text(json.dumps(replicas, indent=2) + '\n', encoding='utf-8', newline='\n')
