from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.parent / "sparse-lexical-work-20261122"
donor = prior / "quiet"
template = lab.parent / "native-only-method-lookup-20261121/quiet"
template_config = json.loads((template / "config.json").read_text(encoding="utf-8"))
out = lab / "quiet"
out.mkdir()

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()

def sha(path):
    return sha_bytes(path.read_bytes())

def emit(path, source):
    if path.suffix == ".py":
        compile(source, str(path), "exec")
    path.write_text(source, encoding="utf-8", newline="\n")

def save(path, value):
    emit(path, json.dumps(value, indent=2) + "\n")

proof = load(lab / "retire-proof.json")
retire = proof["proof"]
prior_config = load(donor / "config.json")
prior_receipt = load(donor / "archive-receipt.json")
prior_identity = load(donor / "identity.json")
reference_donor = prior_identity["imageFiles"]["candidate"]
assert prior_receipt["complete"] and prior_receipt["archivedAndVerifiedUnderLease"]
assert len(reference_donor) == 32 and reference_donor == {name:sha(prior / "frozen/candidate" / name) for name in reference_donor}

manifest = out / "representative.json"
catalog = load(lab / "representative.json")
cases = ['scripts.annotated-rule-closures.literal-positional-dynamic-keyword', 'scripts.annotated-rule-closures.literal-positional-only', 'scripts.annotated-rule-closures.nested-factories.postponed', 'scripts.ordinary-fully-supplied-helper']
catalog["cases"] = [case for id in cases for case in catalog["cases"] if case["id"] == id]
assert [c["id"] for c in catalog["cases"]] == cases
save(manifest, catalog)
local = load(lab / "identity.json")
reference, candidate = (subprocess.check_output(["git", "rev-parse", local[key]], cwd=repo, text=True).strip()
                       for key in ("reference", "candidate"))
assert reference.startswith("8c81fb8d2") and candidate.startswith("072ab6065")
image_files = local["imageFiles"]
core = "Lokad.Lython.dll"
for role, hashes in image_files.items():
    image = lab / "frozen" / role
    assert len(hashes) == 32 and {name: sha(image / name) for name in hashes} == hashes
    assert all(reference_donor[name] == value for name, value in hashes.items() if name != core)
    if role == "reference":
        assert hashes == reference_donor
    for suite, count in (("white", 631), ("public", 2363), ("retained-defaults-stress", 4)):
        for platform in ("win", "ubuntu"):
            log = (lab / f"{suite}-{platform}.log").read_text(encoding="utf-8-sig")
            assert "Passed!" in log and f"Passed: {count:5d}, Skipped:" in log
    sdk = Path.home() / ".dotnet11"
    dotnet = sdk / "dotnet.exe"
    env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk) + os.pathsep + os.environ["PATH"])
    receipt = lab / f"quiet-{role}-verify.json"
    protocol = repo / "benchmarks/cpython-worker.py"
    assert sha(protocol) == prior_config["protocolSHA256"]
    subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify",
        "--catalog", manifest, "--dotnet", dotnet, "--python", "C:/Python313/python.exe",
        "--python-worker", protocol, "--out", receipt], check=True, env=env, timeout=95)
    proof = load(receipt)
    assert proof["state"] == "Completed" and proof["caseCount"] == 4 and proof["catalogSha256"] == sha(manifest)

identity = dict(sourceRevision=reference + " versus " + candidate, purpose="Compiler-owned literal positional default tuples with independent keyword defaults",
                imageFiles=image_files, normalAdapterPin="0.4.0", catalogSHA256=sha(manifest),
                coreSHA256={role + suffix: hashes[core] for role, hashes in image_files.items() for suffix in ("", "-control")})
save(out / "identity.json", identity)
root = "/home/lokad/lython-bench-checks/compiled-literal-defaults-b1324-20261122"
unit = "lython-b1324-compiled-literal-defaults-20261122"
jobs = [(case, "warm") for case in cases] + [(cases[0], "compile-run")]
for name in ("collect.py", "archive-owned.py", "run.sh", "retrieve.py"):
    original = (template / name).read_text(encoding="utf-8").replace(template_config["root"], root).replace(template_config["unit"], unit)
    if name == "run.sh":
        original = original.replace("regex-local","inline-keyword-default")
    if name == "collect.py":
        start, end = original.index("\njobs = "), original.index("\nassert len(jobs)")
        original = (original[:start] + "\njobs = " + repr(jobs) + original[end:]).replace("len(jobs)==3", "len(jobs)==5")
        original = original.replace("warmupSeconds=8", "warmupSeconds=12")
        original = original.replace("min(warmed)<8", "min(warmed)<12").replace("warmed[i]>=8", "warmed[i]>=12")
        original = original.replace("accumulate 8 seconds", "accumulate 12 seconds")
    if name == "archive-owned.py":
        original = original.replace("jobs=3,", "jobs=5,").replace("len(raw['jobs'])==3", "len(raw['jobs'])==5")
    if name == "retrieve.py":
        original = original.replace("['jobs']==3", "['jobs']==5")
    emit(out / name, original)
assert b"\r" not in (out / "run.sh").read_bytes()
for role in image_files:
    (out / role).mkdir()
    shutil.copyfile(lab / "frozen" / role / core, out / role / core)
    assert sha(out / role / core) == image_files[role][core]
parts = ("identity.json", "collect.py", "archive-owned.py", "run.sh", "representative.json",
         "candidate/" + core)
payload = out / "payload.tgz"
with tarfile.open(payload, "w:gz") as file:
    for name in parts:
        file.add(out / name, arcname=name)
stage = dict(root=root, unit=unit, identity=identity, source=prior_config["root"], sourceRole="candidate",
             sourceFiles=reference_donor, sourceCatalogSHA256=prior_config["catalogSHA256"],
             donorArchiveSHA256=prior_receipt["archiveSHA256"], protocolSource=prior_config["root"] + "/cpython-worker.py",
             protocolSHA256=prior_config["protocolSHA256"], payloadBytes=payload.stat().st_size,
             payloadSHA256=sha(payload), retireGroups=retire, catalogSHA256=sha(manifest),
             unpackedBytes=sum((out / name).stat().st_size for name in parts))
save(out / "config.json", stage)
source = (template / "remote-launch.py").read_text(encoding="utf-8")
start, end = source.index("\nc=") + 1, source.index("\nb=Path(")
source = source[:start] + "c=" + repr(stage) + source[end:]
source = source.replace("lython-b1297-fixtures", "lython-b1324-fixtures")
assert "c['unpackedBytes']+640*1024" in source
emit(out / "remote-launch.py", source)
emit(lab / "launch.py", (lab.parent / "regex-local-one-shot-20261121/launch.py").read_text(encoding="utf-8")
     .replace("All-width single-match regex scratch comparison", "Compiler-owned literal positional defaults comparison").replace("300", "385"))
emit(lab / "summarize.py", (lab.parent / "regex-local-one-shot-20261121/summarize.py").read_text(encoding="utf-8").replace("len(raw['jobs'])==4", "len(raw['jobs'])==5"))
print(f"Prepared five lanes with {stage['unpackedBytes']} bytes of persistent working data.")
