from hashlib import sha256
from pathlib import Path
from shutil import copyfile, copytree
import json
import os
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
notes = lab.parent
previous = notes / "current-checkpoint-b1921-20261128/comparison/quiet"
current = notes / "direct-lexical-binding-slots-b1925-20261128/comparison"
quiet = lab / "comparison/quiet"
quiet.mkdir(parents=True)
core = "Lokad.Lython.dll"

def read(path):
    return json.loads(path.read_bytes())

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def manifest(folder):
    return {p.name:digest(p) for p in folder.iterdir()}

def write(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")

def catalog(folder):
    p = folder / "representative.json"
    assert digest(p) == read(folder / "identity.json")["catalogs"][p.name]["sha256"]
    return read(p)

def git(*args):
    return subprocess.check_output(["git", *args], cwd=repo)

head = git("rev-parse", "HEAD").decode().strip()
assert not git("status", "--porcelain")
measured = read(current / "identity.json")
patch = git("diff", "--binary", measured["sourceRevision"], head, "--", "src")
assert sha256(patch).hexdigest() == measured["sourcePatchSHA256"]
image = measured["imageFiles"]["candidate"]
assert len(image) == 32 and manifest(current / "candidate") == image
copytree(current / "candidate", quiet / "local-image")
assert manifest(quiet / "local-image") == image

donor = read(previous / "identity.json")["imageFiles"]["candidate"]
donor_state = read(previous / "terminal-status.json")
assert not donor_state["live"] and not donor_state["fixtures"] and donor_state["exitCode"] == "0"
donor_receipt = donor_state["receipt"]
gates = ("complete", "allWorkersJoined", "guestFixturesRemoved", "quietBeforeAndAfter", "archivedAndVerifiedUnderLease")
assert all(donor_receipt[key] for key in gates)
assert digest(previous / "observations.tar.xz") == donor_receipt["archiveSHA256"]
assert {name for name, checksum in image.items() if donor[name] != checksum} == {core}

selected = catalog(previous)
shipment, dense, csv, config, first, generated = [case["id"] for case in selected["cases"]]
assert shipment == "diagnostic.shipment-starmap-iterable-rows" and dense == "diagnostic.nested-json-document"
selected["cases"] = [case for case in selected["cases"] if case["id"] != csv]
assert len(selected["cases"]) == 5
write(quiet / "representative.json", selected)
jobs = [[shipment,"warm-async"],[generated,"compile"],[shipment,"warm"],
        [dense,"warm-async"],[first,"warm"],[config,"compile-run"]]
write(quiet / "jobs.json", jobs)

for name in ("cpython-worker.py","run.sh"):
    copyfile(previous / name, quiet / name)
assert b"\r" not in (quiet / "run.sh").read_bytes()
assert digest(quiet / "cpython-worker.py") == measured["cpythonWorkerSHA256"]
stage_name = "script-cpython-quiet-b1926-20261128"
identity = dict(sourceRevision=head, productionHead=head, purpose="Whole-script CPython comparison after generator admission, argument binding and lexical slots.",
                imageFiles={"candidate":image},
                coreSHA256={k:image[core] for k in ("candidate","candidate-control")},
                auxiliaryFiles={k:v for k,v in image.items() if k != core},
                frozenImage="/home/lokad/lython-bench-checks/" + stage_name + "/candidate",
                catalogs={name:{"sha256":digest(quiet / name)} for name in ("representative.json","jobs.json")},
                expectedCPythonSHA256=measured["expectedCPythonSHA256"], cpythonWorkerSHA256=measured["cpythonWorkerSHA256"],
                donorArchiveSHA256=donor_receipt["archiveSHA256"])
write(quiet / "identity.json", identity)

collect = (previous / "collect.py").read_text(encoding="utf-8")
collect = collect.replace("lython-b1921-cpython-fixtures", "lython-b1926-cpython-fixtures").replace("len(jobs) == 8", "len(jobs) == 6")
compile(collect, "collect.py", "exec")
(quiet / "collect.py").write_text(collect, encoding="utf-8", newline="\n")

paths = {name:quiet / name for name in ("identity.json","representative.json","jobs.json","cpython-worker.py","run.sh","collect.py")}
paths["candidate/" + core] = quiet / "local-image" / core
payload = quiet / "stage.tar.gz"
with tarfile.open(payload, "w:gz") as output:
    for name, path in paths.items(): output.add(path, arcname=name)
files = {name:dict(length=path.stat().st_size, sha256=digest(path)) for name,path in paths.items()}
write(quiet / "upload.json", dict(root=stage_name, donor=read(previous / "upload.json")["root"],
    donorFiles=donor, donorArchive=donor_receipt["archiveSHA256"], payloadSHA256=digest(payload), files=files,
    expandedBytes=sum(row["length"] for row in files.values()), minimumAfterStageBytes=5*1024*1024))
