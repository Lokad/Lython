from pathlib import Path
from statistics import median, quantiles
import hashlib,json,tarfile
from shutil import copyfile
import subprocess

lab=Path(__file__).resolve().parent
quiet=lab/"comparison/quiet"
read=lambda p:json.loads(p.read_text(encoding="utf-8"))
terminal=read(quiet/"terminal-status.json")
assert not terminal["live"] and not terminal["fixtures"] and terminal["exitCode"]=="0"
receipt=terminal["receipt"]
archive=quiet/"observations.tar.xz"
assert hashlib.sha256(archive.read_bytes()).hexdigest() == receipt["archiveSHA256"]
image=read(quiet/"identity.json")
assert image["sourceRevision"] == subprocess.check_output(["git","rev-parse","486b6bb60"], text=True).strip()
exact_image={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (quiet/"local-image").iterdir()}
assert exact_image==image["imageFiles"]["candidate"] and len(exact_image)==32
case_by_id={r["id"]:r for r in read(quiet/"representative.json")["cases"]}
with tarfile.open(archive) as bundle:
    raw=json.load(bundle.extractfile("confirmation/confirmation.json"))
    identity=json.load(bundle.extractfile("identity.json"))
    jobs=json.load(bundle.extractfile("jobs.json"))
    assert all(json.load(bundle.extractfile(f"confirmation/machine-{phase}.json"))["gate"]["quiet"] for phase in ("before","after"))
    for name, expected in image["catalogs"].items():
        assert hashlib.sha256(bundle.extractfile(name).read()).hexdigest()==expected["sha256"]
assert raw["complete"] and len(raw["jobs"])==6 and receipt["warmJobs"]==6
assert all(receipt[k] for k in ["complete","allWorkersJoined","guestFixturesRemoved","quietBeforeAndAfter","archivedAndVerifiedUnderLease"])
assert identity==image and jobs==read(quiet/"jobs.json")
assert [(job["case"], job["lanes"][0]) for job in raw["jobs"]]==[tuple(j) for j in jobs]
rows=[]
pinned=set()
for job in raw["jobs"]:
    case=case_by_id[job["case"]]
    lane,=job["lanes"]
    assert job["workersJoinedAndFixturesRemoved"] and len(job["samples"])==28
    med={};cpu={};iqr={}
    for label,worker in job["identities"].items():
        assert worker["catalogSha256"]==image["catalogs"]["representative.json"]["sha256"]
        if label.startswith("CPython"):
            assert worker["version"].startswith("3.13.16")
            pinned.add(worker["executableSha256"])
        else:
            assert worker["runtimeVersion"]=="11.0.0"
            libraries={Path(entry["path"]).name:entry["sha256"] for entry in worker["libraries"]}
            assert libraries["Lokad.Lython.dll"]==image["coreSHA256"][label]
            assert libraries["Lokad.Lython.Benchmarks.dll"]==image["imageFiles"]["candidate"]["Lokad.Lython.Benchmarks.dll"]
        samples=[s for s in job["samples"]if s["engine"]==label]
        assert len(samples)==7
        times=[];wider=[]
        for sample in samples:
            r=sample["response"]
            assert r["status"]=="Completed" and r["completedInvocations"]>0 and all(r[k]==case[k] for k in ["sourceSha256","fixtureSha256","expectedOutputSha256"])
            assert r["actualOutputSha256"]==(None if lane=="compile" else case["expectedOutputSha256"])
            assert r.get("actualFilesSha256")== (None if lane=="compile" else case.get("expectedFilesSha256"))
            times.append(r["elapsedTicks"]*1000/r["clockFrequency"]/r["completedInvocations"])
            wider.append(sample["externalProcessCpuTicks"]*1000/sample["externalCpuFrequency"]/r["completedInvocations"])
        med[label]=median(times)
        cpu[label]=median(wider)
        q=quantiles(times,n=4,method="inclusive")
        iqr[label]=(q[2]-q[0])*100/med[label]
    span=lambda v,l:[min(v[l],v[l+"-control"]),max(v[l],v[l+"-control"])]
    div=lambda v:sorted(a/b for a in span(v,"candidate") for b in span(v,"CPython"))
    spreads=lambda l:(max(span(med,l))/min(span(med,l))-1)*100
    row=dict(case=case["id"],lane=lane,lythonMs=span(med,"candidate"),cpythonMs=span(med,"CPython"),ratio=[min(div(med)),max(div(med))],widerCpuRatio=[min(div(cpu)),max(div(cpu))],lythonControlPercent=spreads("candidate"),cpythonControlPercent=spreads("CPython"),maxIQRPercent=max(iqr.values()),sourceUtf8Bytes=case["sourceUtf8Bytes"],fixtureSha256=case["fixtureSha256"])
    rows.append(row)
    print(case["id"],lane,"L [",*map(lambda n:f"{n:.5f}",row["lythonMs"]),"] C [",*map(lambda n:f"{n:.5f}",row["cpythonMs"]),"]",*[f"{n:.4f}" for n in row["ratio"]],"spread",*[f"{row[k]:.2f}%" for k in ["lythonControlPercent","cpythonControlPercent"]])
assert pinned == {image["expectedCPythonSHA256"]}
assert sum(len(job["samples"]) for job in raw["jobs"])==168
proof=read(quiet/"candidate-remote-verify.json")
assert proof["state"]=="Completed" and proof["caseCount"]==5
assert proof["launched"]["library"]["sha256"]==image["coreSHA256"]["candidate"]
assert proof["launched"]["adapter"]["sha256"]==image["imageFiles"]["candidate"]["Lokad.Lython.Benchmarks.dll"]
assert proof["launched"]["python"]["sha256"]==image["expectedCPythonSHA256"]
assert proof["catalogSha256"]==image["catalogs"]["representative.json"]["sha256"]
stage=read(quiet/"stage-custody.json")
assert stage["streamed"] and stage["reused"]=={"donor":31}
assert stage["afterStaging"] >= 5*1024*1024 and not stage["deduplicated"]
for retired in stage["deduplicated"]:
    assert hashlib.sha256((lab.parents[3]/retired["localImage"]/"Lokad.Lython.dll").read_bytes()).hexdigest()==retired["sha256"]
(quiet/"summary.json").write_text(json.dumps(dict(source=image["sourceRevision"],cpythonVersion="3.13.16",cpythonExecutableSHA256=next(iter(pinned)),elapsedSeconds=raw["elapsedSeconds"],timedBatches=sum(len(job["samples"]) for job in raw["jobs"]),performanceQualified=False,passedQuietCheck=True,rows=rows),indent=2)+"\n",encoding="utf-8",newline="\n")


out=lab.parents[3]/"benchmarks/results/2026-11-28-current-cpython-compiler-checkpoint"
out.mkdir(exist_ok=True)
names=["identity.json","summary.json","observations.tar.xz","archive-receipt.json","stage-custody.json","terminal-status.json"]
for name in names: copyfile(quiet/name,out/name)
matched=lab/"comparison/matched-compiler"
matchedIdentity=read(matched/"identity.json")
matchedSummary=read(matched/"summary.json")
matchedReceipt=read(matched/"archive-receipt.json")
assert matchedSummary["quietMachine"] is False and matchedSummary["verifiedTimedBatches"]==84
assert all(matchedReceipt[key] for key in ("complete","allWorkersJoined","guestFixturesRemoved","archivedAndVerifiedUnderLease"))
assert hashlib.sha256((matched/"observations.tar.xz").read_bytes()).hexdigest()==matchedReceipt["archiveSHA256"]
assert matchedIdentity["imageFiles"]["candidate"]==exact_image
initial=read(lab.parent/"direct-lexical-binding-slots-b1925-20261128/comparison/identity.json")
assert matchedIdentity["imageFiles"]==initial["imageFiles"]
assert matchedSummary["candidatePatchSHA256"]==initial["sourcePatchSHA256"]
matchedOut=out/"matched-compiler"
matchedOut.mkdir(exist_ok=True)
for name in ("identity.json","summary.json","observations.tar.xz"):
    copyfile(matched/name,matchedOut/name)
paths=[lab/name for name in ["prepare.py","quiet-vm.py","archive.py","launch-console.log","local-verify.json",
                            "prepare-matched-compiler.py","summarize-matched-compiler.py"]]
paths.extend(matched/name for name in ["run.sh","collect.py","archive-receipt.json","collection.log","exit-code.txt",
                                      "reference-verify.json","candidate-verify.json","jobs.json","representative.json"])
paths.extend(quiet/name for name in ["upload.json","candidate-remote-verify.json","launch.log","exit-code.txt"])
fresh=lab/"fresh-startup"
startup=read(fresh/"receipt.json")
assert startup["state"]=="Completed" and startup["performanceQualified"] is False
assert startup["caseCount"]==1 and startup["catalogSha256"]==hashlib.sha256((fresh/"config.json").read_bytes()).hexdigest()
assert startup["launched"]["library"]["sha256"]==exact_image["Lokad.Lython.dll"]
assert {row["engine"]:row["observation"]["status"] for row in startup["rows"]}=={"Lython":"Equivalent","CPython":"Equivalent"}
paths.extend(fresh/name for name in ["config.json","receipt.json"])

with tarfile.open(out/"procedures.tar.xz","w:xz") as output:
    for p in paths:
        output.add(p,arcname=p.relative_to(lab))
with tarfile.open(out/"procedures.tar.xz") as output:
    assert all(output.extractfile(p.relative_to(lab).as_posix()).read()==p.read_bytes() for p in paths)

