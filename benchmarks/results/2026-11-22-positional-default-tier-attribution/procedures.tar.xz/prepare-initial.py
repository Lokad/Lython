from pathlib import Path
import hashlib
import json
import shlex
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
donor=lab.parent/"json-direct-mapping-20261122"
current=donor/"confirmation"
template=lab.parent/"retained-call-cpu-profile-20261122"
base="/home/lokad/lython-bench-checks"
root=base+"/positional-default-tier-b1380-20261122"
unit="lython-b1380-positional-default-tier-20261122"

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write(path, data):
    if path.suffix==".py":compile(data,str(path),"exec")
    path.write_text(data,encoding="utf-8",newline="\n")

def save(path, data):
    write(path,json.dumps(data,indent=2)+"\n")

def pushed(path):
    return subprocess.check_output(["git","show","origin/master:"+str(path.as_posix())],cwd=repo)

available={}
for path in sorted(repo.glob("benchmarks/results/**/observations.tgz")):
    if path.stat().st_size < 450_000:continue
    relative=path.relative_to(repo)
    try:
        receipt=json.loads((path.parent/"archive-receipt.json").read_text(encoding="utf-8-sig"))
    except FileNotFoundError:
        continue
    if not all(receipt.get(k) for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease")):continue
    if receipt.get("archiveSHA256") != sha(path.read_bytes()):continue
    available.setdefault(path.stat().st_size,[]).append((receipt["archiveSHA256"],relative.as_posix()))

ssh=["C:/Windows/System32/OpenSSH/ssh.exe","-i",str(Path.home()/".ssh/id_lython-bench.pem"),
     "-o","BatchMode=yes","-o","ConnectTimeout=15","lokad@20.166.121.73"]
probe="""
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat
b=Path(BASE);expected=EXPECTED
with (b/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not any(p.is_mount() for p in b.glob('*/guest-fixtures'))
 matches=[]
 for p in b.glob('*/observations.tgz'):
  s=p.lstat()
  if s.st_size not in expected or s.st_nlink!=1 or not stat.S_ISREG(s.st_mode) or p.resolve()!=p or s.st_uid!=os.getuid():continue
  h=hashlib.sha256(p.read_bytes()).hexdigest()
  for digest,archive in expected[s.st_size]:
   if h==digest:matches.append(dict(path=str(p.relative_to(b)),archive=archive,bytes=s.st_size,sha256=h))
 print(json.dumps(dict(free=shutil.disk_usage(b).free,matches=matches)))
""".replace("BASE",repr(base)).replace("EXPECTED",repr(available))
remote=subprocess.run(ssh+["python3 -c "+shlex.quote(probe)],capture_output=True,check=True,timeout=40)
(lab/"inventory.json").write_bytes(remote.stdout)
inventory=json.loads(remote.stdout)

config=read(current/"config.json")
receipt=read(current/"archive-receipt.json")
assert all(receipt[k] for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease"))
assert sha((current/"observations.tgz").read_bytes())==receipt["archiveSHA256"]
identity=read(current/"identity.json")
files=identity["imageFiles"]
assert all(len(m)==32 for m in files.values())
for role,expected in files.items():
    assert {n:sha((donor/"frozen"/role/n).read_bytes()) for n in expected}==expected
    proof=read(donor/f"{role}-positional.json")
    assert proof["state"]=="Completed" and proof["catalogSha256"]==identity["catalogs"]["positional.json"]["sha256"]
identity["purpose"]="Match default-tier positional CPU stacks and generated code across both images"
identity["coreSHA256"]={role:m["Lokad.Lython.dll"] for role,m in files.items()}
save(lab/"identity.json",identity)
old=read(template/"config.json")
jobs=[(name,"calls.positional.large","warm") for name in
      ("candidate-positional","reference-positional","reference-repeat","candidate-repeat")]
for n in ("ops-profile.py","collect.py","run.sh","retrieve.py","launch.py"):
    text=(template/n).read_text(encoding="utf-8").replace(old["root"],root).replace(old["unit"],unit).replace("B1370","B1380")
    if n=="ops-profile.py":
        start,end=text.index("    for name, case_id, lane in "),text.index("\n        role = ")
        text=text[:start]+f"    for name, case_id, lane in {jobs!r}:"+text[end:]
        text=text.replace('        fixture = tempfile.',"""        env["DOTNET_JitDisasm"] = "ExecuteInstructionPrefix ExecuteOrdinaryCall TryExecuteNativeCall StartNativeCall TryStartDirectIntegerReturn TryEvaluateDirectIntegerReturn"
        env["DOTNET_JitStdOutFile"] = str(folder / "codegen.txt")
        fixture = tempfile.""")
        text=text.replace('else 512','else 128')
        text=text.replace('["DOTNET_PerfMapEnabled"]}', '["DOTNET_PerfMapEnabled", "DOTNET_JitDisasm", "DOTNET_JitStdOutFile"]}')
        text=text.replace('            record["identity"] = frame()','            record["identity"] = frame()\n'
              '            assert record["identity"]["catalogSha256"] == expected_image["catalogs"]["positional.json"]["sha256"]')
        text=text.replace('            if operation != "quit":','            if operation != "quit":\n'
              '                assert response["completedInvocations"] == count, response')
    if n=="collect.py":
        text=text.replace("['reference-mixed', 'candidate-function-helper', 'candidate-mixed']",repr([n for n,_,_ in jobs]))
        text=text.replace("len(records)==3","len(records)==4").replace(old["identity"]["purpose"],identity["purpose"])
    if n=="launch.py":
        text=text.replace("seconds=95","seconds=116").replace("95 seconds","116 seconds")
        text=text.replace("Mixed first-use and function-helper attribution","Default-tier positional CPU and JIT capture")
    write(lab/n,text)
assert b"\r" not in (lab/"run.sh").read_bytes()
parts=("identity.json","collect.py","ops-profile.py","run.sh")
payload=lab/"payload.tgz"
with tarfile.open(payload,"w:gz") as a:
    for part in parts:a.add(lab/part,arcname=part)
unpacked=sum((lab/n).stat().st_size for n in parts)
threshold=176160768+unpacked+4*1024*1024
free=inventory["free"]
retire=[]
for option in sorted(inventory["matches"],key=lambda r:-r["bytes"]):
    if free>threshold:break
    archive=Path(option["archive"])
    canonical=pushed(archive)
    final=json.loads(pushed(archive.parent/"archive-receipt.json"))
    assert all(final[k] for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease"))
    assert len(canonical)==option["bytes"] and sha(canonical)==option["sha256"]==final["archiveSHA256"]
    retire.append(dict(paths=[option["path"]],archives={},links=1,bytes=option["bytes"],sha256=option["sha256"]))
    free+=option["bytes"]
assert free>threshold,(free,threshold)
stage=dict(root=root,unit=unit,identity=identity,source=config["root"],sourceFiles=files,
           catalogSHA256=identity["catalogs"]["positional.json"]["sha256"],
           donorArchive=receipt["archiveSHA256"],retireGroups=retire,payloadBytes=payload.stat().st_size,
           payloadSHA256=sha(payload.read_bytes()),unpackedBytes=unpacked)
save(lab/"config.json",stage)
text=(template/"remote-launch.py").read_text(encoding="utf-8").replace("lython-b1370-fixtures","lython-b1380-fixtures")
start,end=text.index("\nc=")+1,text.index("\nb=Path(")
text=text[:start]+"c="+repr(stage)+text[end:]
text=text.replace(" assert sha(source/'representative.json')==c['sourceCatalogSHA256']\n","")
text=text.replace("os.link(source/'representative.json',root/'catalog.json')","os.link(source/'positional.json',root/'catalog.json')")
write(lab/"remote-launch.py",text)
print(f"Verified source pair and catalog. Staging can reclaim {len(retire)} exact archived replicas under the lease.")
