from pathlib import Path
import bisect
import collections
import gzip
import json
import re

lab=Path(__file__).resolve().parent
methods=("ExecuteInstructionPrefix","ExecuteOrdinaryCall","TryExecuteNativeCall","StartNativeCall",
         "TryStartDirectIntegerReturn","TryEvaluateDirectIntegerReturn")
header=re.compile(r"^.*?\s(\d+)\s+\d+\.\d+:\s+\d+\s+cpu-clock:")
frame=re.compile(r"^\s+([0-9a-f]+)\s+(.*)$")

def short(name):
    m=re.search(r"::([^\s(]+)\(",name)
    return m[1] if m else name

def summarize(folder):
    record=json.loads((folder/"record.json").read_text(encoding="utf-8"))
    assert record["closed"]["status"]=="Closed" and record["exitCode"]==0
    candidates=set()
    unparsed=0
    with gzip.open(folder/"perf.map.gz","rt",encoding="utf-8") as lines:
        for line in lines:
            columns=line.rstrip().split(" ",2)
            if len(columns)!=3:
                unparsed+=1
                continue
            start,size,name=columns
            start,size=int(start,16),int(size,16)
            candidates.add((start,start+size,name))
    entries=sorted(candidates)
    starts=[a for a,b,n in entries]
    prefix=[]
    for a,b,n in entries:prefix.append(max(b,prefix[-1] if prefix else 0))

    def resolve(address,fallback):
        pos=bisect.bisect_right(starts,address)-1
        variants=set()
        while pos>=0 and prefix[pos]>address:
            a,b,n=entries[pos]
            if a<=address<b:variants.add((n,b-a,address-a))
            pos-=1
        if len(variants)==1:return variants.pop()
        return ("[ambiguous JIT map]" if variants else fallback,0,0)

    samples=[]
    current=None
    with gzip.open(folder/"all-thread-stacks.txt.gz","rt",encoding="utf-8") as lines:
        for line in lines:
            match=header.match(line)
            if match:
                current=[]
                samples.append(current)
                continue
            match=frame.match(line)
            if match and current is not None:
                current.append(resolve(int(match[1],16),match[2]))
    assert len(samples)>500 and any(samples)
    leaves=collections.Counter()
    offsets=collections.defaultdict(collections.Counter)
    nearest=collections.Counter()
    ancestry=collections.Counter()
    for stack in samples:
        if not stack:continue
        name,size,offset=stack[0]
        category=short(name)
        leaves[category]+=1
        if category in methods:offsets[category][f"{size}:{offset}"]+=1
        group=next((short(n) for n,_,_ in stack if "Lokad.Lython.Runtime." in n),"[no Lython runtime]")
        nearest[group]+=1
        for part in {short(n) for n,_,_ in stack if "Lokad.Lython.Runtime." in n}:ancestry[part]+=1
    generated=collections.defaultdict(list)
    for block in (folder/"codegen.txt").read_text(encoding="utf-8").split("; Assembly listing for method ")[1:]:
        head=block.splitlines()[0]
        name=next((method for method in methods if f":{method}(" in head),None)
        if name is None:continue
        size=re.search(r"; Total bytes of code (\d+)",block)
        assert size and " (" in head
        ops=[]
        for line in block.splitlines()[1:]:
            if line.startswith("       "):
                ops.append(re.sub(r"(?i)(?:0x|\b)[0-9a-f]{9,}h?\b","<address>",line.strip()))
        import hashlib
        generated[name].append(dict(tier=head.rsplit(" (",1)[1].rstrip(")"),codeBytes=int(size[1]),
             instructionsHash=hashlib.sha256("\n".join(ops).encode()).hexdigest()))
    result=record["response"]
    elapsed=result["elapsedTicks"]/result["clockFrequency"]
    count=result["completedInvocations"]
    assert all(m in generated for m in ("ExecuteInstructionPrefix","TryExecuteNativeCall","StartNativeCall"))
    snapshot=dict(label=folder.name, samples=len(samples), unmatchedLeaf=leaves["[ambiguous JIT map]"], 
                  unparsedMapRows=unparsed, operations=count, guestElapsedMilliseconds=1000*elapsed/count,
                  processCpuMsPerInvocation=1000*sum(t["seconds"] for t in record["threadCpuSeconds"])/count,
                  hotMethods={m:dict(leaf=leaves[m], nearest=nearest[m], ancestry=ancestry[m],
                         leafLocations=offsets[m].most_common(12), generated=generated[m]) for m in methods},
                  nearestRuntime=nearest.most_common(18), leaves=leaves.most_common(20))
    return snapshot

rows=[summarize(lab/"retrieved/profiles"/name) for name in
      ("candidate-positional","reference-positional","reference-repeat","candidate-repeat")]
assert len(rows)==4
for row in rows:
    print(row["label"],row["guestElapsedMilliseconds"],row["processCpuMsPerInvocation"],row["samples"],
          row["nearestRuntime"][:8],[(m,[g['codeBytes'] for g in v['generated']]) for m,v in row['hotMethods'].items()])
summary=dict(rows=rows, timingQualification=False, scopesOverlap=True)
(lab/"attribution.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8",newline="\n")
