from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
bench=lab.with_name('csv-combined-record-admission-20261125')/'comparison/quiet'
manifest=lab.with_name('map-slots-refined-20261125')/'comparison/quiet/representative.json'
donor=lab.with_name('regex-constant-subject-20261125')
quiet=lab/'comparison/quiet'
quiet.mkdir(parents=True,exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=repo)
def save(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
head=git('rev-parse','HEAD').decode().strip()
assert head.startswith('6c6445cee')
assert git('diff','8fb548c75',head,'--','src')==b''
original=read(donor/'identity.json')
assert git('diff','--binary',original['sourceRevision'],head,'--','src')==(donor/'candidate.patch').read_bytes()
base=original['imageFiles']['candidate']
assert len(base)==32 and {p.name:sha(p) for p in (donor/'candidate').iterdir()}==base
core=repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'
assert sha(core)==sha(repo/'tools/LythonProbe/bin/Release/net11.0/Lokad.Lython.dll')
patch=git('diff','--binary','HEAD','--','src')
assert patch.count(b'diff --git ')==4
(lab/'candidate.patch').write_bytes(patch)
(lab/'tests.patch').write_bytes(git('diff','--binary','HEAD','--','tests'))
images=dict(reference=base,candidate=base|{core.name:sha(core)})
for role,files in images.items():
    image=lab/role
    image.mkdir(exist_ok=True)
    for name in files:
        shutil.copyfile(core if role=='candidate' and name==core.name else donor/'candidate'/name,image/name)
    assert {p.name:sha(p)for p in image.iterdir()}==files
catalog=read(bench/'representative.json')
rows={c['id']:c for c in catalog['cases']}
rows.update({c['id']:c for c in read(manifest)['cases'] if c['id']=='diagnostic.shipment-native-map-control'})
jobs=[['diagnostic.shipment-routing-callbacks','warm'],['diagnostic.shipment-file-fed-map','warm-async'],
    ['diagnostic.shipment-native-map-control','warm'],['diagnostic.shipment-routing-callbacks','warm-async'],
    ['diagnostic.text-summary.nonlocal-computed-width.large','warm']]
catalog['cases']=[rows[id] for id in dict.fromkeys(v[0] for v in jobs)]
save(quiet/'representative.json',catalog)
save(quiet/'jobs.json',{'warm':jobs})
script=repo/'benchmarks/cpython-worker.py'
shutil.copyfile(script,quiet/'cpython-worker.py')
ref=read(bench/'identity.json')
assert sha(script)==ref['cpythonWorkerSHA256']
identity=dict(sourceRevision=head,sourcePatchSHA256=sha(lab/'candidate.patch'),
    imageFiles=images, coreSHA256={label:images[label.removesuffix('-control')][core.name] for label in
        ('reference','reference-control','candidate','candidate-control')},
    cpythonWorkerSHA256=ref['cpythonWorkerSHA256'],expectedCPythonSHA256=ref['expectedCPythonSHA256'],
    catalogs={name:{'sha256':sha(quiet/name)} for name in ('jobs.json','representative.json')},
    purpose='Measure direct native sources in ordered composed iterators while preserving admitted ownership.')
save(quiet/'identity.json',identity)
shutil.copyfile(bench/'run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
(quiet/'collect.py').write_text((bench/'collect.py').read_text(encoding='utf-8').replace('lython-b1738-fixtures','lython-b1742-fixtures'),encoding='utf-8',newline='\n')
sdk=Path.home()/'.dotnet11'; dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
for role,files in images.items():
    evidence=lab/f'{role}-verify.json'
    subprocess.run([dotnet,lab/role/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'representative.json',
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',script,'--out',evidence],
        cwd=repo,env=env,check=True,timeout=80)
    checked=read(evidence)
    assert checked['state']=='Completed' and checked['caseCount']==len(catalog['cases'])
    assert checked['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert checked['launched']['library']['sha256']==files[core.name]
with tarfile.open(quiet/'stage.tar.gz','w:gz',compresslevel=6) as bundle:
    for name in ('collect.py','run.sh','representative.json','jobs.json','identity.json','cpython-worker.py'):
        bundle.add(quiet/name,arcname=name,recursive=False)
    for role in images:
        for name in images[role]: bundle.add(lab/role/name,arcname=f'{role}/{name}',recursive=False)
save(quiet/'upload.json',dict(root='composed-native-inputs-b1742-20261125',
    payloadSHA256=sha(quiet/'stage.tar.gz'),payloadBytes=(quiet/'stage.tar.gz').stat().st_size))
print('Both complete images verify under four goldens.')
