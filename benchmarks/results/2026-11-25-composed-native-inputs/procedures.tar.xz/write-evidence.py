from pathlib import Path
from statistics import median
import hashlib,json,re,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/'comparison/quiet'
out=repo/'benchmarks/results/2026-11-25-composed-native-inputs'
out.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=repo)
def write(p,value):p.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
identity=read(quiet/'identity.json')
assert sha(lab/'candidate.patch')==identity['sourcePatchSHA256']
assert git('diff','--binary','HEAD','--','src')==(lab/'candidate.patch').read_bytes()
(lab/'final-tests.patch').write_bytes(git('diff','--binary','HEAD','--','tests'))
for role,files in identity['imageFiles'].items():
    assert len(files)==32 and {p.name:sha(p)for p in (lab/role).iterdir()}==files
    verify=read(lab/f'{role}-verify.json')
    assert verify['state']=='Completed' and verify['caseCount']==4 and verify['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert verify['launched']['library']['sha256']==files['Lokad.Lython.dll']
status=read(quiet/'terminal-status.json')
assert not status['live'] and status['exitCode']=='0' and not status['fixtures']
receipt=status['receipt']
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
assert receipt['quietBeforeAndAfter'] and receipt['archivedAndVerifiedUnderLease']
assert receipt['archiveSHA256']==sha(quiet/'observations.tar.xz')
with tarfile.open(quiet/'observations.tar.xz') as archive:
    data=json.load(archive.extractfile('confirmation/confirmation.json'))
    for p in ('identity.json','jobs.json','representative.json'): assert archive.extractfile(p).read()==(quiet/p).read_bytes()
assert data['complete'] and data['sourceRevision']==identity['sourceRevision'] and len(data['jobs'])==5
summary=[]
for job in data['jobs']:
    assert job['workersJoinedAndFixturesRemoved'] and len(job['samples'])==28
    execution={}
    for label,observed in job['identities'].items():
        core=next(v for v in observed['libraries'] if Path(v['path']).name=='Lokad.Lython.dll')
        assert core['sha256'].lower()==identity['coreSHA256'][label]
        rows=[x for x in job['samples'] if x['engine']==label]
        assert len(rows)==7 and all(pair['response']['status']=='Completed' for pair in rows)
        elapsed=lambda o:o['response']['elapsedTicks']/o['response']['clockFrequency']/o['response']['completedInvocations']
        cpu=lambda o:o['externalProcessCpuTicks']/o['externalCpuFrequency']/o['response']['completedInvocations']
        execution[label]=[median(1e6*get(o) for o in rows)for get in (elapsed,cpu)]
    labels=('elapsed','cpu')
    lo,hi={},{}
    spreads={}
    for i,metric in enumerate(labels):
        ref=[execution[x][i]for x in ('reference','reference-control')]
        new=[execution[x][i]for x in ('candidate','candidate-control')]
        differences=[100*(a/b-1)for a in new for b in ref]
        lo[metric]=min(differences);hi[metric]=max(differences)
        spreads[metric]=[100*(max(s)/min(s)-1)for s in (ref,new)]
    summary.append(dict(case=job['case'],lane=job['lane'],processMedianUs=execution,percentChange={m:[lo[m],hi[m]]for m in labels},sameSourceSpreadPercent=spreads))
for log,n in [('windows-public.log',1492),('windows-internal.log',546),('Lokad.Lython.PublicApi.Tests-ubuntu10.log',1492),
    ('Lokad.Lython.Tests-ubuntu10.log',546),('windows-targeted.log',3),('ubuntu-targeted.log',3)]:
    assert re.search(rf'Failed:\s+0, Passed:\s+{n},',(lab/log).read_text(encoding='utf-8-sig'))
alloc=read(lab/'allocation-summary.json')
assert len(alloc)==4 and all(a['peakAdmission'][0]==a['peakAdmission'][1]for a in alloc)
for name in ('identity.json','terminal-status.json','observations.tar.xz'):shutil.copyfile(quiet/name,out/name)
shutil.copyfile(lab/'allocation-summary.json',out/'allocation-summary.json')
write(out/'quiet-summary.json',dict(sourceRevision=identity['sourceRevision'],sourcePatchSHA256=identity['sourcePatchSHA256'],
    timedBatches=140,collectionSeconds=data['elapsedSeconds'],rows=summary))
with tarfile.open(out/'procedures.tar.xz','w:xz') as bundle:
    for p in ('prepare.py','quiet.py','allocations.py','write-evidence.py','candidate.patch','tests.patch','final-tests.patch',
        'windows-build.log','windows-public.log','windows-internal.log','windows-targeted.log','ubuntu-targeted.log',
        'Lokad.Lython.PublicApi.Tests-ubuntu10.log','Lokad.Lython.Tests-ubuntu10.log','test-ubuntu.sh','target-ubuntu.sh',
        'reference-verify.json','candidate-verify.json','reference-allocation-final.json','candidate-allocation-final.json',
        'prepare.log','allocations.log','stage.log','retrieve.log'):
        bundle.add(lab/p,arcname=p)
    custody=read(lab.parent/'vm-source-custody-20261125/custody.json')
    write(lab/'vm-source-archive-custody.json',{name:custody[name]for name in ('date','snapshots','phase','move')})
    bundle.add(lab/'vm-source-archive-custody.json',arcname='vm-source-archive-custody.json')
for row in summary:
    print(row['case'], row['lane'],row['percentChange'],row['sameSourceSpreadPercent'])
