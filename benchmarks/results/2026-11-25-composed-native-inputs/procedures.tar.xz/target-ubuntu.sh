set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab="$PWD/.git/agent-notes/review-20261031/composed-native-inputs-20261125"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --no-restore --filter '(FullyQualifiedName~CancelledZipUnpack|FullyQualifiedName~MapRowRetains)&Category!=Stress' > "$lab/ubuntu-targeted.log" 2>&1
