from pathlib import Path
import hashlib,json

base=Path(__file__).parent;r=base/'owned-metadata-refinement';r.mkdir(exist_ok=False)
prior=json.loads((base/'boundary-refinement/candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==h for n,h in prior['sources'].items())
prospective=dict(reference='716176a8',initialShared='99d16dc4',routingRefinement='fc905405',
 hypothesis='Borrowed calls still initialize/carry array/cache/iteration/disposal/ownership fields in the shared value-storage struct. Move fields serving actual owned storage into one admitted owner; keep a small live-extent/bounds/owner view for the single existing prefix.',
 displacement='Owned-only fields disappear from every shared operand view; no replacement opcode loop, interface/controller, policy or global cache. Existing borrowed stack entry, actual continuation and default null/cleanup contracts stay.',
 tradeoff='One conservative128B metadata admission and object for actual owned storage, before construction. Extra owned-frame allocation is real; compare complete scripts/control shapes. Borrowed calls create no metadata object. No hidden allowance or cumulative charging.',
 validation='Focused default/cleared state, aliases, pending cursor cleanup, actual async/cancellation, terminal refusal, retained cache and construction rollback on11/10; source-frozen short complete warm/fresh/control comparison before retain/debt or withdrawal. All original adverse images and measurements preserved.',publicationHeld=True)
(r/'prospective.json').write_text(json.dumps(prospective,indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.cs');s=p.read_text(encoding='utf-8')
a=s.index('    internal struct ExecutableValueStorage\n');b=s.index('\n    public LythonExecutionResult Run(',a)
old=s[a:b];(r/'before-storage.cs').write_text(old,encoding='utf-8',newline='\n')
start=old.index('        private ExecutableSlot[]? _items;');end=old.index('        public ExecutableValueStorage(',start)
fields='''        // Array/cache/disposal metadata exists only for an actually owned
        // frame. A borrowed prefix needs its function owner and live slot bounds.
        private sealed class OwnedStorage(ExecutionState state, object? lookupOwner, long bytes)
        {
            internal const long MetadataBytes = 128;
            internal readonly ExecutionState State = state;
            internal ExecutableSlot[] Items = [];
            internal int[]? IterationPositions;
            internal object? LookupStorage = lookupOwner;
            internal long StorageBytes = bytes;
            internal PyIteration.Cursor? PendingHead, PendingTail;
            internal bool DeferDisposal;
        }

        private OwnedStorage? _owned;
        private readonly PyExecutableFunction? _borrowedOwner;
        private readonly int _firstTemporarySlot;
        private readonly int _lastOwnedTemporarySlot;

        internal bool DeferAsyncDisposal
        {
            readonly get => _owned?.DeferDisposal == true;
            set { if (_owned is { } owned) owned.DeferDisposal = value; }
        }
        internal readonly bool HasPendingDisposals => _owned?.PendingHead is not null;

'''
new=old[:start]+fields+old[end:]
start=new.index('        public ExecutableValueStorage(');end=new.index('        // A synchronous prefix',start)
ctor='''        public ExecutableValueStorage(int capacity, int firstTemporarySlot, int lastOwnedTemporarySlot, ExecutionContext context,
            LythonSourceSpan? allocationSpan, long frameStorageBytes, ExecutableSlot[]? borrowedValues,
            PyExecutableFunction? lookupOwner)
        {
            _firstTemporarySlot = firstTemporarySlot;
            _lastOwnedTemporarySlot = lastOwnedTemporarySlot;
            var bytes = checked(OwnedStorage.MetadataBytes + frameStorageBytes
                + (borrowedValues is null ? ExecutableSlotsBytes(capacity) : 0));
            var governor = context.MemoryGovernor;
            governor.Reserve(bytes, allocationSpan);
            try
            {
                context.CheckExecution(allocationSpan);
                _owned = new OwnedStorage(context.State, lookupOwner, bytes)
                    { Items = borrowedValues ?? new ExecutableSlot[capacity] };
                governor.Commit(bytes);
            }
            catch { governor.ReleaseReserved(bytes); throw; }
            LiveExtent = firstTemporarySlot;
        }

'''
new=new[:start]+ctor+new[end:]
new=new.replace('''            _items = null;
            _state = context.State;''','''            _borrowedOwner = lookupOwner;''')
new=new.replace('            _lookupStorage = lookupOwner;\n','')
new=new.replace('internal readonly bool BorrowsSlotSpan => _items is null && _state is not null;',
 'internal readonly bool BorrowsSlotSpan => _borrowedOwner is not null;')
new=new.replace('internal readonly ExecutableSlot[] Values => _items!;', 'internal readonly ExecutableSlot[] Values => _owned?.Items!;')
new=new.replace('internal readonly void CheckExecution(LythonSourceSpan span) => _state.CheckExecution(span);',
 'internal readonly void CheckExecution(LythonSourceSpan span)\n            => (_owned?.State ?? _borrowedOwner!.DefinitionContext.State).CheckExecution(span);')
start=new.index('        internal void ReleaseStorage()');end=new.index('        internal ExecutableLookupCache[] GetLookupCaches(',start)
release='''        internal void ReleaseStorage()
        {
            if (_owned is not { } owned) return;
            if (owned.PendingHead is not null)
                throw new InvalidOperationException("Pending native disposal must finish before value storage closes.");
            // End ownership before a host refund can reenter this frame.
            owned.Items = [];
            owned.IterationPositions = null;
            owned.LookupStorage = null;
            var bytes = owned.StorageBytes;
            owned.StorageBytes = 0;
            _owned = null;
            owned.State.MemoryGovernor.Release(bytes);
        }

'''
new=new[:start]+release+new[end:]
start=new.index('        internal ExecutableLookupCache[] GetLookupCaches(');end=new.index('        public int LiveExtent',start)
lookup='''        internal ExecutableLookupCache[] GetLookupCaches(int count, LythonSourceSpan span)
        {
            if (_borrowedOwner is { } borrowed) return borrowed.GetLookupCaches(span);
            var owned = _owned!;
            if (owned.LookupStorage is PyExecutableFunction owner) return owner.GetLookupCaches(span);
            if (owned.LookupStorage is ExecutableLookupCache[] existing) return existing;
            var bytes = LookupCacheBytes(count);
            var ownedBytes = checked(owned.StorageBytes + bytes);
            var governor = owned.State.MemoryGovernor;
            governor.Reserve(bytes, span);
            try
            {
                owned.State.CheckExecution(span);
                if (owned.StorageBytes == 0) throw new InvalidOperationException("Value storage ended during cache admission.");
                var caches = new ExecutableLookupCache[count];
                governor.Commit(bytes);
                owned.StorageBytes = ownedBytes;
                owned.LookupStorage = caches;
                return caches;
            }
            catch { governor.ReleaseReserved(bytes); throw; }
        }

        internal void ClearLookupCache(int index)
        {
            if (_borrowedOwner is { } borrowed) borrowed.ClearLookupCache(index);
            else if (_owned?.LookupStorage is PyExecutableFunction owner) owner.ClearLookupCache(index);
            else if (_owned?.LookupStorage is ExecutableLookupCache[] caches) caches[index] = default;
        }

        internal PyIteration.Cursor? TakePendingDisposal()
        {
            if (_owned is not { PendingHead: { } cursor } owned) return null;
            owned.PendingHead = cursor.NextPendingDisposal;
            cursor.NextPendingDisposal = null;
            if (owned.PendingHead is null) owned.PendingTail = null;
            return cursor;
        }

'''
new=new[:start]+lookup+new[end:]
start=new.index('        internal bool TryPrepareNativeIteration(');end=new.index('        public Memory<ExecutableSlot> Slice',start)
chunk=new[start:end].replace('            if (_nativeIterationPositions is null)','            var owned = _owned!;\n            if (owned.IterationPositions is null)')
chunk=chunk.replace('_nativeIterationPositions','owned.IterationPositions').replace('_ownedStorageBytes','owned.StorageBytes').replace('_state.MemoryGovernor','owned.State.MemoryGovernor')
chunk=chunk.replace('''                using var storage = owned.State.MemoryGovernor.ReserveTemporary(bytes, span);
                var positions''','''                using var storage = owned.State.MemoryGovernor.ReserveTemporary(bytes, span);
                owned.State.CheckExecution(span);
                if (owned.StorageBytes == 0) throw new InvalidOperationException("Value storage ended during iteration admission.");
                var positions''')
chunk=chunk.replace('ref owned.IterationPositions![slot - _firstTemporarySlot]','ref _owned!.IterationPositions![slot - _firstTemporarySlot]')
new=new[:start]+chunk+new[end:]
new=new.replace('''                    if (_pendingDisposalTail is null) _pendingDisposalHead = cursor;
                    else _pendingDisposalTail.NextPendingDisposal = cursor;
                    _pendingDisposalTail = cursor;''','''                    var owned = _owned!;
                    if (owned.PendingTail is null) owned.PendingHead = cursor;
                    else owned.PendingTail.NextPendingDisposal = cursor;
                    owned.PendingTail = cursor;''')
for name in ['_items','_state','_lookupStorage','_ownedStorageBytes','_nativeIterationPositions','_pendingDisposalHead','_pendingDisposalTail']:
 assert name not in new,name
p.write_text(s[:a]+new+s[b:],encoding='utf-8',newline='\n')
print('Moved owned-only metadata out of the common value view; actual owned storage preflights128Bmetadata plus existing capacity. Borrowed entry retains no metadata object. Prototype unqualified/unmeasured.')
