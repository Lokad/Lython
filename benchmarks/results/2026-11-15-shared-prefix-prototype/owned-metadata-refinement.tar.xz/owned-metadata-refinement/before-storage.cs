    internal struct ExecutableValueStorage
    {
        private ExecutableSlot[]? _items;
        private int[]? _nativeIterationPositions;
        // One reference holds private invocation storage or the existing
        // function definition that owns shared facts. Do not widen every frame
        // with a second owner slot, including frames that never use a cache.
        private object? _lookupStorage;
        private readonly ExecutionState _state;
        private long _ownedStorageBytes;
        private readonly int _firstTemporarySlot;
        private readonly int _lastOwnedTemporarySlot;
        private PyIteration.Cursor? _pendingDisposalHead, _pendingDisposalTail;
        internal bool DeferAsyncDisposal;
        internal readonly bool HasPendingDisposals => _pendingDisposalHead is not null;

        public ExecutableValueStorage(int capacity, int firstTemporarySlot, int lastOwnedTemporarySlot, ExecutionContext context,
            LythonSourceSpan? allocationSpan, long frameStorageBytes, ExecutableSlot[]? borrowedValues,
            PyExecutableFunction? lookupOwner)
        {
            _state = context.State;
            _firstTemporarySlot = firstTemporarySlot;
            _lastOwnedTemporarySlot = lastOwnedTemporarySlot;
            _nativeIterationPositions = null;
            _lookupStorage = lookupOwner;
            var bytes = checked(frameStorageBytes + (borrowedValues is null ? ExecutableSlotsBytes(capacity) : 0));
            var governor = context.MemoryGovernor;
            governor.Reserve(bytes, allocationSpan);
            try { _items = borrowedValues ?? new ExecutableSlot[capacity]; governor.Commit(bytes); }
            catch { governor.ReleaseReserved(bytes); throw; }
            _ownedStorageBytes = bytes;
            LiveExtent = firstTemporarySlot;
        }

        // A synchronous prefix borrows its caller's admitted slots. No backing,
        // reservation or persistent frame is constructed for that borrow.
        internal ExecutableValueStorage(ExecutableCodeObject code, ExecutionContext context, PyExecutableFunction lookupOwner)
        {
            _items = null;
            _state = context.State;
            _firstTemporarySlot = code.FirstTemporarySlot;
            _lastOwnedTemporarySlot = code.LastOwnedTemporarySlot;
            _lookupStorage = lookupOwner;
            LiveExtent = code.FirstTemporarySlot;
        }

        internal readonly bool BorrowsSlotSpan => _items is null && _state is not null;

        // Cleared/default frame storage deliberately retains the existing null
        // sentinel. Active borrowed prefixes use their explicit span instead.
        internal readonly ExecutableSlot[] Values => _items!;

        internal readonly void CheckExecution(LythonSourceSpan span) => _state.CheckExecution(span);

        internal void ReleaseStorage()
        {
            _items = [];
            _nativeIterationPositions = null;
            _lookupStorage = null;
            var bytes = _ownedStorageBytes;
            _ownedStorageBytes = 0;
            _state.MemoryGovernor.Release(bytes);
        }

        internal ExecutableLookupCache[] GetLookupCaches(int count, LythonSourceSpan span)
        {
            if (_lookupStorage is PyExecutableFunction owner) return owner.GetLookupCaches(span);
            if (_lookupStorage is ExecutableLookupCache[] existing) return existing;
            var bytes = LookupCacheBytes(count);
            var ownedBytes = checked(_ownedStorageBytes + bytes);
            var governor = _state.MemoryGovernor;
            governor.Reserve(bytes, span);
            try
            {
                _state.CheckExecution(span);
                var caches = new ExecutableLookupCache[count];
                governor.Commit(bytes);
                _ownedStorageBytes = ownedBytes;
                _lookupStorage = caches;
                return caches;
            }
            catch { governor.ReleaseReserved(bytes); throw; }
        }

        internal void ClearLookupCache(int index)
        {
            if (_lookupStorage is PyExecutableFunction owner) owner.ClearLookupCache(index);
            else if (_lookupStorage is ExecutableLookupCache[] caches) caches[index] = default;
        }

        internal PyIteration.Cursor? TakePendingDisposal()
        {
            var cursor = _pendingDisposalHead;
            if (cursor is null) return null;
            _pendingDisposalHead = cursor.NextPendingDisposal;
            cursor.NextPendingDisposal = null;
            if (_pendingDisposalHead is null) _pendingDisposalTail = null;
            return cursor;
        }

        public int LiveExtent { get; private set; }

        internal void RestoreNativeExtent(int liveExtent) => LiveExtent = liveExtent;

        public object this[int index]
        {
            get => Values[index].Object.RequireNotNull();
            set => Values[index].Object = value;
        }

        internal void PublishValue(int resultSlot, int liveExtent, object result)
            => PublishSlot(resultSlot, liveExtent, ExecutableSlot.FromObject(result));

        internal void PublishValue(Span<ExecutableSlot> values, int resultSlot, int liveExtent, object result)
            => PublishSlot(values, resultSlot, liveExtent, ExecutableSlot.FromObject(result));

        internal void PublishSlot(int resultSlot, int liveExtent, ExecutableSlot result)
            => PublishSlot(Values, resultSlot, liveExtent, result);

        internal void PublishSlot(Span<ExecutableSlot> values, int resultSlot, int liveExtent, ExecutableSlot result)
        {
            // Inputs and their owner stay live through callbacks/suspension.
            // Retire only after success, preserving failed-disposal behavior.
            if (liveExtent < LiveExtent) RetireTo(values, liveExtent);
            values[resultSlot] = result;
            LiveExtent = liveExtent;
        }

        internal object TakeValue(int inputSlot, int liveExtent)
            => TakeValue(Values, inputSlot, liveExtent);

        internal object TakeValue(Span<ExecutableSlot> values, int inputSlot, int liveExtent)
        {
            var value = values[inputSlot].Object.RequireNotNull();
            values[inputSlot].Object = null!;
            LiveExtent = liveExtent;
            return value;
        }

        internal ExecutableSlot TakeSlotValue(Span<ExecutableSlot> values, int inputSlot, int liveExtent)
        {
            var value = values[inputSlot];
            if (value.IsUnassigned) _ = value.Object.RequireNotNull();
            values[inputSlot] = default;
            LiveExtent = liveExtent;
            return value;
        }

        // The completed operation consumed this input, as PublishValue would
        // overwrite it. Its result goes directly to a binding instead.
        internal void ForgetResultInput(Span<ExecutableSlot> values, int resultSlot)
        {
            values[resultSlot].Object = null!;
            LiveExtent = resultSlot;
        }

        internal bool TryPrepareNativeIteration(Span<ExecutableSlot> values, object source, int slot, int liveExtent, LythonSourceSpan span)
        {
            if (source is PyStringOps.CasedWhitespaceIteration)
            {
                PublishValue(values, slot, liveExtent, source);
                return true;
            }
            if (BorrowsSlotSpan || source is not (PyList or PyTuple)) return false;
            if (_nativeIterationPositions is null)
            {
                // The existing private operand keeps the source alive. One
                // admitted position array replaces repeated native cursor and
                // enumerator objects; it shares this frame's storage lifetime.
                var bytes = checked(32L + 4L * (values.Length - _firstTemporarySlot));
                var frameBytes = checked(_ownedStorageBytes + bytes);
                using var storage = _state.MemoryGovernor.ReserveTemporary(bytes, span);
                var positions = new int[values.Length - _firstTemporarySlot];
                storage.Commit(bytes);
                _nativeIterationPositions = positions;
                _ownedStorageBytes = frameBytes;
            }
            _nativeIterationPositions[slot - _firstTemporarySlot] = 0;
            PublishValue(values, slot, liveExtent, source);
            return true;
        }

        internal bool TryAdvanceNativeIteration(Span<ExecutableSlot> values, int slot, out PyIterationResult next)
        {
            switch (values[slot].Object)
            {
                case PyStringOps.CasedWhitespaceIteration words:
                    next = words.MoveNext();
                    return true;
                case PyList or PyTuple:
                    next = PyIteration.AdvanceBuiltinSequence(values[slot].Object!, ref _nativeIterationPositions![slot - _firstTemporarySlot]);
                    return true;
                default:
                    next = PyIterationResult.End;
                    return false;
            }
        }

        public Memory<ExecutableSlot> Slice(int start, int count) => Values.AsMemory(start, count);

        internal readonly bool CanRetireWithoutCleanup(ReadOnlySpan<ExecutableSlot> values, int liveExtent)
        {
            if (HasPendingDisposals) return false;
            for (var i = Math.Min(LiveExtent - 1, _lastOwnedTemporarySlot); i >= liveExtent; i--)
                if (values[i].Reference is PyIteration.Cursor or ExecutableTemporaryValue) return false;
            return true;
        }

        public void RetireTo(int liveExtent)
            => RetireTo(Values, liveExtent);

        internal void RetireTo(Span<ExecutableSlot> values, int liveExtent)
        {
            if (liveExtent == LiveExtent)
            {
                return;
            }

            var newCount = liveExtent;
            // Compiler-owned wrappers cannot occur above this conservative bound.
            // Still clear every retired guest reference after private cleanup.
            for (var i = Math.Min(LiveExtent - 1, _lastOwnedTemporarySlot); i >= newCount; i--)
            {
                if (DeferAsyncDisposal && values[i].Reference is PyIteration.Cursor cursor)
                {
                    if (_pendingDisposalTail is null) _pendingDisposalHead = cursor;
                    else _pendingDisposalTail.NextPendingDisposal = cursor;
                    _pendingDisposalTail = cursor;
                    // Ownership moved to the pending chain. A later synchronous
                    // disposal can fail; retrying the trim must not enqueue twice.
                    values[i].Object = null!;
                }
                else if (values[i].Reference is ExecutableTemporaryValue temporary)
                {
                    // Ownership leaves this slot before cleanup can reenter or
                    // fail, just as on the native and asynchronous paths. A retry
                    // must not dispose a returned loan that now has another user.
                    values[i].Object = null!;
                    temporary.Dispose();
                }
            }
            // Private synchronous slots remain funded until their borrow ends.
            // Clear their dead tail once before transfer; owned frames clear now.
            if (!BorrowsSlotSpan) values.Slice(newCount, LiveExtent - newCount).Clear();
            LiveExtent = newCount;
        }
    }
