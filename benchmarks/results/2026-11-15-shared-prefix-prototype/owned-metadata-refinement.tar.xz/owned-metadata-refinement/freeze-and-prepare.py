from pathlib import Path
import ast,hashlib,json,os,shutil,subprocess,tarfile

r=Path(__file__).parent;parent=r.parent
assert not(r/'candidate-identity.json').exists()
for name,count in [('public-net11.log',1669),('internal-net11.log',448)]:
 s=(r/name).read_text(encoding='utf-8');assert 'Passed!'in s and ('Passed: '+str(count))in s.replace('  ',' ').replace('  ',' '),s[-1500:]
names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','--','src/Lokad.Lython'],text=True).splitlines()
names=sorted(set(n for n in names if Path(n).is_file()));assert len(names)==585
names+=['Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
sources={n:sha(n)for n in names}
sdk='C:/Users/JoannesVermorel/.dotnet11';env={k:v for k,v in os.environ.items()if k.casefold()!='path'}
env['DOTNET_ROOT']=sdk;env['PATH']=sdk+';C:/Python313;'+next(v for k,v in os.environ.items()if k.casefold()=='path')
with(r/'freeze-build.log').open('w',encoding='utf-8',newline='\n')as log:
 done=subprocess.run([sdk+'/dotnet.exe','build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-restore','--no-incremental','-m:1','-v','quiet'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert done.returncode==0,(r/'freeze-build.log').read_text(encoding='utf-8')
assert all(sha(n)==h for n,h in sources.items())
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as t:
 for n in sources:t.add(n,arcname=n)
for role,source in [('reference','reference'),('initial','candidate'),('candidate','candidate')]:shutil.copytree(parent/'boundary-refinement'/source,r/role)
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'candidate/Lokad.Lython.dll');shutil.copyfile(r/'candidate/Lokad.Lython.dll',r/'candidate-core.dll')
old=json.loads((parent/'boundary-refinement/candidate-identity.json').read_text(encoding='utf-8'))
assert sha(r/'reference/Lokad.Lython.dll')==old['coreSHA256']['reference']and sha(r/'initial/Lokad.Lython.dll')==old['coreSHA256']['candidate']
for name,h in old['auxiliaryFiles'].items():
 for role in ['reference','initial','candidate']:assert sha(r/role/name)==h
shutil.copyfile(parent/'catalog.json',r/'catalog.json')
identity=dict(headBeforeCommit=old['headBeforeCommit'],productionInputs=585,additionalBuildInputs=4,sources=sources,
 coreSHA256={role:sha(r/role/'Lokad.Lython.dll')for role in ['reference','initial','candidate']},
 auxiliaryFiles=old['auxiliaryFiles'],frozenFiles={role:{p.name:sha(p)for p in(r/role).iterdir()if p.is_file()}for role in ['reference','initial','candidate']},
 catalogSHA256=sha(r/'catalog.json'),prototype=True,focusedNet11=dict(internal=448,public=1669),net10RefinementPending=True,fullQualificationPending=True,publicationHeld=True)
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
# Reuse the checked initial protocol/worker driver; add two preserved initial
# source processes rather than infer the refinement effect across collections.
script=(parent/'local-screen.py').read_text(encoding='utf-8')
script=script.replace("role='candidate'if label.startswith('candidate')else'reference'", "role='candidate'if label.startswith('candidate')else'initial'if label.startswith('initial')else'reference'")
script=script.replace("['reference','candidate','candidate-control','reference-control']", "['reference','initial','candidate','candidate-control','initial-control','reference-control']")
script=script.replace('time.monotonic()-started<220','time.monotonic()-started<300')
script=script.replace('range(4)', 'range(6)').replace('%4','%6')
needle=" result['allWorkersJoinedAndFixturesRemoved']=True;out['jobs'].append(result);save();print(caseId,lane,med,result['changePercent'],flush=True)"
assert script.count(needle)==1
script=script.replace(needle," result['changeVersusInitialPercent']=sorted(100*(med[a]/med[b]-1)for a in ['candidate','candidate-control']for b in ['initial','initial-control'])\n"+needle)
script=script.replace('Initial complete-script source-pair diagnostic.', 'Controlled original/routing/slim-metadata complete-script diagnostic. Preserved initial source runs concurrently as a role, not cross-collection attribution.')
ast.parse(script);(r/'local-screen.py').write_text(script,encoding='utf-8',newline='\n')
print('Frozen3sources',identity['coreSHA256'],'585+4inputs; 448internal/1669public net11. One controlled refinement comparison prepared; noCPUqualification.',flush=True)
