from pathlib import Path
import json, os, re, subprocess

notes=Path(__file__).parent; sdk='C:/Users/JoannesVermorel/.dotnet11'
env={k:v for k,v in os.environ.items() if k.casefold()!='path'}
env['DOTNET_ROOT']=sdk;env['PATH']=sdk+';'+next(v for k,v in os.environ.items()if k.casefold()=='path')
filters={
 'Lokad.Lython.Tests':'(FullyQualifiedName~ExecutableValueTransferTests|FullyQualifiedName~ExecutableCallTransferTests|FullyQualifiedName~FunctionWorkspaceOwnershipTests|FullyQualifiedName~CasedSplitOwnershipTests|FullyQualifiedName~WordBufferLoanTests|FullyQualifiedName~FunctionLookupLifetimeTests|FullyQualifiedName~DeferredFunctionOwnershipTests|FullyQualifiedName~CompletedHelperCallOwnershipTests|FullyQualifiedName~IterationCancellationTests)&Category!=Stress',
 'Lokad.Lython.PublicApi.Tests':'(FullyQualifiedName~AdmissionFailureCommandTests|FullyQualifiedName~NativeStorageTransferTests|FullyQualifiedName~CooperativeCancellationTests|FullyQualifiedName~AsyncMidFlightCancellationTests|FullyQualifiedName~OrderedFunctionContinuationTests|FullyQualifiedName~ProtectedHelperExecutionTests)&Category!=Stress'
}
rows=[]
for framework in ['net11.0','net10.0']:
 for project,filter_text in filters.items():
    log=notes/('restored-'+project+'-'+framework+'.log');assert not log.exists()
    with log.open('w',encoding='utf-8',newline='\n') as stream:
        result=subprocess.run([sdk+'/dotnet.exe','test','tests/'+project+'/'+project+'.csproj','-c','Release','-f',framework,'--no-restore','--nologo','--filter',filter_text],env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=180)
    summaries=[s for s in log.read_text(encoding='utf-8').splitlines() if 'Passed!' in s or 'Failed!' in s]
    print(project,framework,result.returncode,summaries,flush=True)
    assert result.returncode==0 and len(summaries)==1 and 'Failed:     0' in summaries[0]
    rows.append(dict(project=project,framework=framework,passed=int(re.search(r'Passed:\s+(\d+),',summaries[0])[1]),log=log.name))
(notes/'restored-checks.json').write_text(json.dumps(dict(complete=True,checks=rows,source='Restored qualified a7ab41f5; forced Release builds precede these checks',fullQualificationNotRepeated=True),indent=2)+'\n',encoding='utf-8',newline='\n')
