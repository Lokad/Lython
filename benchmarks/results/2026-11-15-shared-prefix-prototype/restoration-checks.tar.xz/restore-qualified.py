from pathlib import Path
import hashlib, json, os, subprocess, tarfile

root=Path.cwd(); notes=Path(__file__).parent
qualified={}
with tarfile.open(notes/'baseline-sources.tar.xz') as tar:
    for member in tar.getmembers(): qualified[member.name]=tar.extractfile(member).read()
assert len(qualified)==589
changed=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
assert all(n in qualified or n=='tests/Lokad.Lython.Tests/CasedSplitOwnershipTests.cs' for n in changed)
blob_data=subprocess.check_output(['git','cat-file','--batch'],input=''.join('HEAD:'+name+'\n' for name in qualified).encode('utf-8'))
offset=0
for name,data in qualified.items():
    end=blob_data.index(b'\n',offset); header=blob_data[offset:end].split()
    assert header[1]==b'blob'
    size=int(header[2]);committed=blob_data[end+1:end+1+size];offset=end+size+2
    assert committed.replace(b'\r\n',b'\n')==data.replace(b'\r\n',b'\n'),name
assert offset==len(blob_data)
# The baseline source archive uses LF. Restore that exact representation too,
# rather than confusing harmless checkout newlines with a source mismatch.
for name,data in qualified.items():
    if not (root/name).is_file() or (root/name).read_bytes()!=data: (root/name).write_bytes(data)
borrowed=root/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Borrowed.cs'
assert borrowed.resolve().is_relative_to(root.resolve()/'src/Lokad.Lython/Runtime')
frozen=json.loads((notes/'owned-metadata-refinement/candidate-identity.json').read_text(encoding='utf-8'))
if borrowed.exists():
    assert hashlib.sha256(borrowed.read_bytes()).hexdigest()==frozen['sources'][borrowed.relative_to(root).as_posix()]
    borrowed.unlink()
subprocess.run(['git','restore','--','tests/Lokad.Lython.Tests/CasedSplitOwnershipTests.cs'],check=True)
assert all((root/n).read_bytes()==data for n,data in qualified.items())
assert not subprocess.check_output(['git','diff','--name-only','--','src/Lokad.Lython','tests/Lokad.Lython.Tests/CasedSplitOwnershipTests.cs'],text=True).strip()
(notes/'restored-source-proof.json').write_text(json.dumps(dict(runtime='a7ab41f5',frozen='716176a8',verifiedInputs=len(qualified),productionInputs=585,additionalInputs=4,testRestored=True,prototypeRemoved=True,forcedBuildsNext=True),indent=2)+'\n',encoding='utf-8',newline='\n')
sdk='C:/Users/JoannesVermorel/.dotnet11'
env={k:v for k,v in os.environ.items() if k.casefold()!='path'}
env['DOTNET_ROOT']=sdk;env['PATH']=sdk+';'+next(v for k,v in os.environ.items()if k.casefold()=='path')
for framework in ['net11.0','net10.0']:
    with (notes/('restored-build-'+framework+'.log')).open('w',encoding='utf-8') as log:
        result=subprocess.run([sdk+'/dotnet.exe','build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f',framework,'--no-restore','--no-incremental','-m:1','-v','quiet'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=150)
    assert result.returncode==0,(framework,result.returncode)
    print('Qualified source restored and forced Release build complete:',framework,flush=True)
print('All589inputs exactly restored; no prototype runtime/test machinery remains.',flush=True)
