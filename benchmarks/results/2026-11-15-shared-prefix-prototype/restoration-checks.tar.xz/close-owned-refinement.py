from pathlib import Path
import hashlib, json, subprocess, tarfile

root = Path.cwd()
notes = Path(__file__).parent
stage = notes / 'owned-metadata-refinement'
out = root / 'benchmarks/results/2026-11-15-shared-prefix-prototype'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
run = json.loads((stage/'local-screen.json').read_text(encoding='utf-8'))
identity = json.loads((stage/'candidate-identity.json').read_text(encoding='utf-8'))
assert run['complete'] and run['allGoldensAndBudgetsPassed'] and run['allUsersJoined']
assert len(run['jobs']) == 8
for name, digest in identity['sources'].items():
    assert sha(name) == digest, name
for role, files in identity['frozenFiles'].items():
    for name, digest in files.items():
        assert sha(stage/role/name) == digest, (role, name)
assert sha(stage/'catalog.json') == identity['catalogSHA256']
for name, count in [('internal-net11.log',448),('public-net11.log',1669)]:
    log=(stage/name).read_text(encoding='utf-8')
    assert 'Passed!' in log and str(count) in log
with tarfile.open(stage/'candidate-sources.tar.xz') as archive:
    assert len(archive.getmembers()) == 589
    for name, digest in identity['sources'].items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == digest
summary = dict(
    decision='Withdraw this implementation after bounded construction refinements; no permanent architectural ban.',
    reason='Repeated short/observed-helper adversity remains after two changed refinements. Mixed whole-script controls do not establish CPU recovery. Do not carry this debt into retained 0.11 runtime.',
    retainedRuntime='a7ab41f5 / 716176a8',
    prototype=identity['coreSHA256'],
    focusedNet11=dict(internal=448,public=1669),
    net10AndFullQualification='Not run for withdrawn final variant; initial variant has focused actual11/10 results.',
    complete=True, allUsersJoined=True, allGoldensAndBudgetsPassed=True,
    elapsedSeconds=run['elapsedSeconds'],
    boundary=run['elapsedBoundary'],
    limits='Local Windows elapsed diagnostics; no quiet-VM, portable CPU, allocation, CPython, heap, RSS or tail claim.',
    outcomes=[dict(case=j['case'],phase=j['lane'],newVsReferencePercent=j['changePercent'],newVsRoutingPercent=j['changeVersusInitialPercent'],processMedianMilliseconds=j['medianMilliseconds']) for j in run['jobs']],
    sourceInputsVerified=589, allFrozenImagesVerified=True, publicationHeld=True)
(out/'owned-metadata-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
(notes/'withdrawal-decision.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
# Include exact binaries, source, successful checks, every observation and driver.
# No live workers remain and no mutable build output is linked into these images.
files=sorted(p for p in stage.iterdir() if p.is_file())
# The three images differ only in their core. Keep unchanged auxiliaries once,
# reference preceding cores in the already committed archive, and retain the
# complete per-image manifests so every measured byte can be reconstructed.
files += sorted(p for p in (stage/'reference').iterdir() if p.is_file() and p.name != 'Lokad.Lython.dll')
extra=[notes/'slim-owned-metadata.py',notes/'withdrawal-decision.json']
patch=subprocess.check_output(['git','diff','--binary','--','src/Lokad.Lython','tests/Lokad.Lython.Tests/CasedSplitOwnershipTests.cs'])
(notes/'withdrawn-prototype.patch').write_bytes(patch)
extra.append(notes/'withdrawn-prototype.patch')
archive=out/'owned-metadata-refinement.tar.xz'
if archive.exists():
    previous=notes/'owned-metadata-full-image-archive.tar.xz'
    assert not previous.exists()
    archive.rename(previous)
with tarfile.open(archive,'w:xz') as tar:
    for p in files+extra:
        tar.add(p,arcname=p.relative_to(notes).as_posix())
with tarfile.open(archive) as tar:
    for p in files+extra:
        name=p.relative_to(notes).as_posix()
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==sha(p),name
print(json.dumps(dict(archivedFiles=len(files+extra),archiveBytes=archive.stat().st_size,archiveSHA256=sha(archive),allSourcesAndFrozenImagesVerified=True,decision=summary['decision']),indent=2))
