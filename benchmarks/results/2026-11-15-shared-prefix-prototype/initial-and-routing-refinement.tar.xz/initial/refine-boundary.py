from pathlib import Path
import json

r=Path(__file__).parent/'boundary-refinement'
r.mkdir(exist_ok=False)
parent=r.parent
screen=json.loads((parent/'local-screen.json').read_text(encoding='utf-8'))
assert screen['complete']and screen['allUsersJoined']
prospective=dict(initialCore='99d16dc4f4d023852406d73277dcb491dacedbd20ddb2b4e04957bd9914d6a26',referenceCore='716176a8',
 demonstrated='Initial local complete source pair125s/allgoldens/owners/close:fulfillment+8.83..11.63%warm/+4.20..6.33%fresh,short+20.59..25.37%,observed+10.19..15.66%,report+2.18..4.03%,text+3.33..7.10%.Filemixed/JSONlarge moving controls. No portableCPUclaim.',
 hypothesis='The shared prefix introduces the ordinary per-instruction try/catch into formerly single-boundary borrowed bodies. Move the same routing outside one shared inner loop, removing that exception region from its hot body without restoring a duplicate engine.',
 semantics='Retain the original guard/routing span even when fused operations advancePC. Entry cancellation/refusal stays outside guest routing via null routingSpan before guards. Handled errors/returns/controls resume exactly once, pending disposal drains before another instruction, no host operation abandoned. Preserve all focused ownership/alias/stack checks.',
 comparison='One bounded refined/original/initial source comparison with unchanged complete warm/fresh controls; all original/adverse observations retained. Do not infer causality from separate collections or auto-promote allocation/simplification as CPU.',
 fullQualificationPending=True,publicationHeld=True)
(r/'prospective.json').write_text(json.dumps(prospective,indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs')
s=p.read_text(encoding='utf-8');(r/'before-dispatch.cs').write_text(s,encoding='utf-8',newline='\n')
start=s.index('        internal static InstructionPause ExecuteInstructionPrefix(ref ExecutableWorkState execution, Span<ExecutableSlot> values,')
body=s.index('\n        {',start)
end=s.index('\n        private static InstructionPause PauseOperation',body)
old=s[start:end]
header=old[:old.index('\n        {')]
core=old.replace('internal static InstructionPause ExecuteInstructionPrefix(', 'private static InstructionPause ExecuteInstructionPrefixCore(',1)
core=core.replace('out ValueTask<ExecutionContext?> nextCall, out int unpackedTupleStart)',
 'out ValueTask<ExecutionContext?> nextCall, out int unpackedTupleStart, out LythonSourceSpan? routingSpan)',1)
core=core.replace('            unpackedTupleStart = -1;', '            unpackedTupleStart = -1;\n            routingSpan = null;',1)
needle='''                scope.State.CheckExecution(instruction.Span);
                try
                {
                    switch (instruction.OpCode)'''
assert core.count(needle)==1
core=core.replace(needle,'''                routingSpan = null;
                scope.State.CheckExecution(instruction.Span);
                routingSpan = instruction.Span;
                switch (instruction.OpCode)''')
catchStart=core.index('''                catch (ReturnSignal signal)''')
after=core.index('''                if (asynchronous && execution.Stack.HasPendingDisposals)''',catchStart)
switchPart=core[:catchStart]
assert switchPart.endswith('''                }
''')
# Remove the old try's closing brace; retain the switch's closing brace.
switchPart=switchPart[:-len('                }\n')]
core=switchPart+core[after:]
# Deindent the existing switch body only; no opcode/ordering change.
a=core.index('                switch (instruction.OpCode)');b=core.index('\n                if (asynchronous && execution.Stack.HasPendingDisposals)',a)
lines=core[a:b].splitlines()
core=core[:a]+lines[0]+'\n'+'\n'.join(line[4:] if line.startswith('    ')else line for line in lines[1:])+core[b:]
wrapper=header+'''
        {
            pending = default;
            pendingSpan = null;
            nextCall = default;
            unpackedTupleStart = -1;
            while (true)
            {
                LythonSourceSpan? routingSpan = null;
                try
                {
                    return ExecuteInstructionPrefixCore(ref execution, values, scope, invocation, asynchronous, unpackedReturnCount,
                        out pending, out pendingSpan, out nextCall, out unpackedTupleStart, out routingSpan);
                }
                catch (ReturnSignal signal)
                {
                    if (invocation is null) throw;
                    if (!invocation.TryRouteReturn(signal, routingSpan.RequireNotNull())) return InstructionPause.Boundary;
                }
                catch (ControlSignal signal)
                {
                    if (invocation is null || !invocation.TryRouteControl(signal, routingSpan.RequireNotNull())) throw;
                }
                catch (LythonRuntimeException error)
                {
                    // Admission/cancellation guards never select guest handlers.
                    if (routingSpan is null) throw;
                    if (invocation is null)
                    {
                        var previous = scope.State.CurrentException;
                        if (previous is not null && !ReferenceEquals(error.OriginalPythonException, previous)) error.PythonContext ??= previous;
                        throw;
                    }
                    if (!invocation.TryRouteRuntimeException(error, routingSpan)) throw;
                }
                // Routing has installed its nextPC. Settle retired native users
                // before another instruction/handler, without incrementingPC.
                if (asynchronous && execution.Stack.HasPendingDisposals)
                {
                    pending = new(true);
                    return InstructionPause.Disposal;
                }
            }
        }

'''
p.write_text(s[:start]+wrapper+core+s[end:],encoding='utf-8',newline='\n')
print('Moved existing routing outside the one shared hot loop; retained guard/operation spans and disposal transition. Initial source/binary/adverse screen unchanged.')
