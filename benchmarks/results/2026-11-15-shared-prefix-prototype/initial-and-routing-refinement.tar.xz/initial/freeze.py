from pathlib import Path
import hashlib,io,json,os,shutil,subprocess,tarfile

r=Path(__file__).parent
assert not (r/'candidate-identity.json').exists() and not (r/'candidate').exists()
d=json.loads((r/'focused-completion.json').read_text(encoding='utf-8'))
assert sorted((x['framework'],x['passed'])for x in d['checks'])==sorted([('net11.0',437),('net10.0',437),('net11.0',1759),('net10.0',1759)])
names=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','--','src/Lokad.Lython'],text=True).splitlines()
names=sorted(set(p for p in names if Path(p).is_file()))
assert len(names)==585,len(names)
sources={name:hashlib.sha256(Path(name).read_bytes()).hexdigest()for name in names}
sources.update({name:hashlib.sha256(Path(name).read_bytes()).hexdigest()for name in ['Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json']})
sdk='C:/Users/JoannesVermorel/.dotnet11'
env={k:v for k,v in os.environ.items()if k.casefold()!='path'}
env['DOTNET_ROOT']=sdk;env['PATH']=sdk+';C:/Python313;'+next(v for k,v in os.environ.items()if k.casefold()=='path')
with (r/'freeze-build.log').open('w',encoding='utf-8',newline='\n')as log:
 p=subprocess.run([sdk+'/dotnet.exe','build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-restore','--no-incremental','-m:1','-v','quiet'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert p.returncode==0,(r/'freeze-build.log').read_text(encoding='utf-8')
assert all(hashlib.sha256(Path(name).read_bytes()).hexdigest()==sha for name,sha in sources.items())
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as t:
 for name in sources:t.add(name,arcname=name)
shutil.copytree(r/'reference',r/'candidate')
core=Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll')
shutil.copyfile(core,r/'candidate/Lokad.Lython.dll');shutil.copyfile(core,r/'candidate-core.dll')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
ref=json.loads((r/'baseline.json').read_text(encoding='utf-8'))
for name,h in ref['referenceFiles'].items():
 assert sha(r/'reference'/name)==h
 if name!='Lokad.Lython.dll':assert sha(r/'candidate'/name)==h
catalog=r.parent/'csv-final-payload-r379/catalog.json';shutil.copyfile(catalog,r/'catalog.json')
identity=dict(headBeforeCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 referenceRuntimeCommit=ref['runtimeCommit'],referenceFullQualification='43675539106GREENterminalcached',
 sources=sources,productionInputs=585,additionalBuildInputs=4,
 coreSHA256={'reference':sha(r/'reference/Lokad.Lython.dll'),'candidate':sha(r/'candidate/Lokad.Lython.dll')},
 auxiliaryFiles={n:h for n,h in ref['referenceFiles'].items()if n!='Lokad.Lython.dll'},
 frozenFiles={role:{p.name:sha(p)for p in(r/role).iterdir()if p.is_file()}for role in ['reference','candidate']},
 catalogSHA256=sha(r/'catalog.json'),
 semanticChecks=d['checks'],prototype=True,fullQualificationPending=True,publicationHeld=True,
 architecture='One existing span-based executable prefix; borrowed small calls retain stack storage, only actual transfer owns a continuation. Removed native opcode/read-publish/format-call loop and orphaned helpers. No new policy/controller/arena/dependency.')
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Frozen',identity['coreSHA256'],'585production+4build inputs; all auxiliaries identical; source stable through forced build. No performance/qualification claim.',flush=True)
