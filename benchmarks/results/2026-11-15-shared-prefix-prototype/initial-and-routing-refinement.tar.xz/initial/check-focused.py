from pathlib import Path
import datetime,hashlib,json,re,subprocess

r=Path(__file__).parent
assert not (r/'focused-completion.json').exists()
dotnet='C:/Users/JoannesVermorel/.dotnet11/dotnet.exe'
internal='(FullyQualifiedName~Executable|FullyQualifiedName~CasedSplitOwnershipTests|FullyQualifiedName~FunctionWorkspaceOwnershipTests|FullyQualifiedName~FunctionBodyTemporaryLifetimeTests|FullyQualifiedName~CapturedScalarObservationTests|FullyQualifiedName~CompletedHelperCallOwnershipTests|FullyQualifiedName~DeferredFunctionOwnershipTests|FullyQualifiedName~ComposedNativeCallTests)&Category!=Stress'
public='(FullyQualifiedName~Native|FullyQualifiedName~PrefixCallCompatibilityTests|FullyQualifiedName~PositionalCallSemanticsTests|FullyQualifiedName~PreparedCallArgumentTests|FullyQualifiedName~OrdinaryFunctionCallTests|FullyQualifiedName~OrdinaryMethodCallTests|FullyQualifiedName~OrderedFunctionContinuationTests|FullyQualifiedName~DeferredFunctionContextTests|FullyQualifiedName~FunctionInputLifetimeTests|FullyQualifiedName~CallInputLifetimeTests|FullyQualifiedName~CapturedScalarExecutionTests|FullyQualifiedName~TransitiveClosureCompatibilityTests|FullyQualifiedName~StackGuardScenarioTests|FullyQualifiedName~RenderingStackAdmissionTests|FullyQualifiedName~AdmissionFailureCommandTests)&Category!=Stress'
rows=[]
for project,framework,filtertext,label in [
 ('Lokad.Lython.Tests','net10.0',internal,'shared-prefix-internal-completed-net10'),
 ('Lokad.Lython.PublicApi.Tests','net10.0',public,'shared-prefix-public-expanded-net10'),
 ('Lokad.Lython.Tests','net11.0',internal,'shared-prefix-internal-completed-net11'),
]:
 logfile=r/(label+'.log');assert not logfile.exists()
 args=[dotnet,'test','tests/'+project+'/'+project+'.csproj','-c','Release','-f',framework,'--no-restore','--nologo','--filter',filtertext]
 with logfile.open('w',encoding='utf-8',newline='\n')as log:
  result=subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=240)
 text=logfile.read_text(encoding='utf-8');summaries=[s for s in text.splitlines()if 'Passed!'in s or 'Failed!'in s]
 print(label,result.returncode,summaries,flush=True)
 assert result.returncode==0 and len(summaries)==1 and 'Failed:     0' in summaries[0],text[-7000:]
 passed=int(re.search(r'Passed:\s+(\d+),',summaries[0])[1]);rows.append(dict(project=project,framework=framework,passed=passed,summary=summaries[0],log=logfile.name))
# These previously completed public checks used the same current runtime bytes.
p=r/'shared-prefix-public-expanded-net11.log';s=p.read_text(encoding='utf-8');assert 'Passed:  1699'in s
rows.append(dict(project='Lokad.Lython.PublicApi.Tests',framework='net11.0',passed=1699,log=p.name))
for framework in ['net11.0','net10.0']:
 core=Path('src/Lokad.Lython/bin/Release')/framework/'Lokad.Lython.dll'
 print(framework,'completed core',hashlib.sha256(core.read_bytes()).hexdigest(),flush=True)
(r/'focused-completion.json').write_text(json.dumps(dict(completedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),checks=rows,fullQualificationPending=True,performanceNotMeasured=True,publicationHeld=True),indent=2)+'\n',encoding='utf-8',newline='\n')
