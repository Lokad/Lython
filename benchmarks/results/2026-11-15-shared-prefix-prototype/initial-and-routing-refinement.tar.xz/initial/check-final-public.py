from pathlib import Path
import datetime,json,re,subprocess

r=Path(__file__).parent
old=r/'focused-completion.json'
d=json.loads(old.read_text(encoding='utf-8'))
assert not(r/'focused-completion-before-final-public.json').exists()
(r/'focused-completion-before-final-public.json').write_bytes(old.read_bytes())
prior=[x for x in d['checks']if x['project'].endswith('PublicApi.Tests')]
d['checks']=[x for x in d['checks']if not x['project'].endswith('PublicApi.Tests')]
d['supersededPublicChecks']=prior
filtertext='(FullyQualifiedName~Native|FullyQualifiedName~PrefixCallCompatibilityTests|FullyQualifiedName~PositionalCallSemanticsTests|FullyQualifiedName~PreparedCallArgumentTests|FullyQualifiedName~OrdinaryFunctionCallTests|FullyQualifiedName~OrdinaryMethodCallTests|FullyQualifiedName~OrderedFunctionContinuationTests|FullyQualifiedName~DeferredFunctionContextTests|FullyQualifiedName~FunctionInputLifetimeTests|FullyQualifiedName~CallInputLifetimeTests|FullyQualifiedName~CapturedScalarExecutionTests|FullyQualifiedName~TransitiveClosureCompatibilityTests|FullyQualifiedName~StackGuardScenarioTests|FullyQualifiedName~RenderingStackAdmissionTests|FullyQualifiedName~AdmissionFailureCommandTests|FullyQualifiedName~LargeHelperExecutionTests|FullyQualifiedName~ForHelperExecutionTests|FullyQualifiedName~WhileHelperExecutionTests|FullyQualifiedName~BuiltinScalarPublicationTests|FullyQualifiedName~ProtectedHelperExecutionTests)&Category!=Stress'
for framework in ['net11.0','net10.0']:
 logfile=r/('shared-prefix-public-final-'+framework+'.log');assert not logfile.exists()
 with logfile.open('w',encoding='utf-8',newline='\n')as log:
  p=subprocess.run(['C:/Users/JoannesVermorel/.dotnet11/dotnet.exe','test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f',framework,'--no-restore','--nologo','--filter',filtertext],stdout=log,stderr=subprocess.STDOUT,timeout=240)
 text=logfile.read_text(encoding='utf-8');lines=[x for x in text.splitlines()if 'Passed!'in x or 'Failed!'in x]
 print(framework,p.returncode,lines,flush=True)
 assert p.returncode==0 and len(lines)==1 and 'Failed:     0'in lines[0],text[-7000:]
 d['checks'].append(dict(project='Lokad.Lython.PublicApi.Tests',framework=framework,passed=int(re.search(r'Passed:\s*(\d+),',lines[0])[1]),log=logfile.name,summary=lines[0]))
d['completedUTC']=datetime.datetime.now(datetime.timezone.utc).isoformat()
d['originalFailure']='21post-cleanup inspection failures after an unnecessary Values guard rejected default/cleared storage. Preserve logs and original assertions; defaultnull sentinel restored, active borrowed view distinguished by its nonnull executionstate. Public checks rerun on both current runtimes.'
old.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Both current public target-framework checks complete; original failures/adverse conditions preserved. Full delivery and performance still pending.',flush=True)
