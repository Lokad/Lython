from pathlib import Path
import hashlib,io,json,shutil,subprocess,tarfile

r=Path(__file__).parent
assert subprocess.check_output(['git','status','--porcelain'],text=True)==''
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head.startswith('400101ae')
assert not (r/'baseline.json').exists()
old=r.parent/'csv-final-payload-r379/candidate'
core=old/'Lokad.Lython.dll'
sha=hashlib.sha256(core.read_bytes()).hexdigest()
assert sha=='716176a82b2a350fee8a9f4224fa00e167929050ca2ce255e9a3704c5ec7e85c'
production=subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True).splitlines()
assert len(production)==585,len(production)
files=production+['Directory.Build.props','Directory.Build.targets','Directory.Packages.props','global.json']
with tarfile.open(r/'baseline-sources.tar.xz','w:xz') as t:
 for name in files:
  data=subprocess.check_output(['git','show',head+':'+name])
  assert Path(name).read_bytes().decode('utf-8-sig').replace('\r\n','\n')==data.decode('utf-8-sig').replace('\r\n','\n'),name
  info=tarfile.TarInfo(name);info.size=len(data);t.addfile(info,io.BytesIO(data))
shutil.copytree(old,r/'reference')
identity=dict(runtimeCommit='a7ab41f5ad9b579759ad63c7cff8721364221374',head=head,core=sha,
 productionInputs=len(production),additionalBuildInputs=4,fullyQualifiedRun='43675539106',
 referenceFiles={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in (r/'reference').iterdir()if p.is_file()},
 purpose='Complete shared slot-span prefix prototype, not an entry reroute or new dispatch controller.',
 expectedDeletion='Separate native opcode loop, native read/publish/format/call dispatch and integer-wrapper partial; retain small stack-backed entry and actual transfer/cleanup invariants.',
 stage='Prototype active; no qualification or performance result claimed.',
 acceptance='Python order/errors/protocols/closures/protected context/generators/actual suspension, managed body stack checks, current cancellation, terminal refusal, retained alias funding and joined cleanup. FocusedRelease first; bounded warm/fresh whole-script pair plus unchangedCSV/text/JSON/short/observed controls; allocation separate from CPU. Remove obsolete driver at completion, no dormant route.',
 publicationHeld=True)
(r/'baseline.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Copied qualified7161 reference;585committed inputs matched and archived. Shared-prefix prototype active, no runtime result claimed.')
