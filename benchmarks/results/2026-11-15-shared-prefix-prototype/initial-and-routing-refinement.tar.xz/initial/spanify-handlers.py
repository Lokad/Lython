from pathlib import Path
import json,re

r=Path(__file__).parent
assert not(r/'span-handlers-applied.json').exists()
root=Path('src/Lokad.Lython/Runtime')
changes={}

def method(path,name,transform,indent=8):
 p=root/path;s=p.read_text(encoding='utf-8')
 pattern=r'^'+(' '*indent)+r'private static [^\n]*\b'+name+r'\('
 found=list(re.finditer(pattern,s,re.M));assert len(found)==1,(path,name,len(found))
 a=found[0].start();body=s.index('\n'+(' '*indent)+'{',a)
 b=s.index('\n'+(' '*indent)+'}',body)+indent+2
 old=s[a:b];new=transform(old)
 assert old!=new,(path,name,'unchanged')
 p.write_text(s[:a]+new+s[b:],encoding='utf-8',newline='\n')
 changes.setdefault(path,[]).append(name)

spanCalls=['ReadOperand','TakeOperand','TakeReturnOperand','PublishInstructionResult',
 'StoreExecutableLocal','TryLoadDirectCallReceiver','ExecuteStackTransfer',
 'ExecuteControlFlow','TryExecuteFormattedInstruction','ExecuteComparisonInstruction',
 'CompleteComparisonBranch','TryExecuteNativeCall','PrepareUnpackedCallReturn',
 'CompleteUnpackedCallReturn','TryExecuteCasedSplit','ExecuteInputInstruction','TryStoreClosure']

def spanBody(s):
 s=s.replace('execution.Stack.Values.AsSpan(', 'values.Slice(')
 s=s.replace('execution.Stack.Values','values')
 s=re.sub(r'execution\.Stack\.Slice\(([^\n;]+?)\)\.Span',r'values.Slice(\1)',s)
 # Keep original null/unbound invariants for temporary-slot reads.
 s=re.sub(r'execution\.Stack\[([^\]\n]+)\](\s*=)',r'values[\1].Object\2',s)
 s=re.sub(r'execution\.Stack\[([^\]\n]+)\]',r'values[\1].Object.RequireNotNull()',s)
 for name in ['TakeValue','TakeSlotValue','PublishValue','PublishSlot','RetireTo','ForgetResultInput','CanRetireWithoutCleanup']:
  s=s.replace('execution.Stack.'+name+'(', 'execution.Stack.'+name+'(values, ')
 for name in spanCalls:s=s.replace(name+'(ref execution,',name+'(ref execution, values,')
 return s

def convert(s):
 a=s.index('\n'+re.match(r' *',s)[0]+'{')
 header=s[:a].replace('ref ExecutableWorkState execution,','ref ExecutableWorkState execution, Span<ExecutableSlot> values,')
 return header+spanBody(s[a:])

for name in ['TryLoadDirectCallReceiver','TakeReturnOperand','ExecuteStackTransfer','ExecuteControlFlow']:
 method('LythonRuntime.Executable.Interpreter.cs',name,convert)
method('LythonRuntime.Executable.Binding.cs','TryStoreClosure',convert,4)
method('LythonRuntime.Executable.PreparedOperations.cs','TryExecuteFormattedInstruction',convert)
method('LythonRuntime.Executable.Inputs.cs','ExecuteInputInstruction',convert)
method('LythonRuntime.Executable.Comparisons.cs','ExecuteComparisonInstruction',convert)
method('LythonRuntime.Executable.CasedSplits.cs','TryExecuteCasedSplit',convert)
method('LythonRuntime.Executable.Calls.Invoke.cs','TryExecuteNativeCall',convert)

def addWrapper(name,arguments):
 def change(old):
  a=old.index('\n        {');header=old[:a]
  return header+'\n            => '+name+'(ref execution, execution.Stack.Values, '+arguments+');\n\n'+convert(old)
 return change
method('LythonRuntime.Executable.Comparisons.cs','CompleteComparisonBranch',
 addWrapper('CompleteComparisonBranch','context, instruction, truth'))
method('LythonRuntime.Executable.Calls.Invoke.cs','PrepareUnpackedCallReturn',
 addWrapper('PrepareUnpackedCallReturn','call, start, out originalExtent'))
method('LythonRuntime.Executable.Calls.Invoke.cs','CompleteUnpackedCallReturn',
 addWrapper('CompleteUnpackedCallReturn','scope, start, count'))

def prefix(old):
 new=convert(old)
 new=new.replace('LoadLocal(execution.Code, execution.Locals,','LoadLocal(execution.Code, values,')
 new=new.replace('CreateListFromStack(ref execution.Stack,','CreateListFromStack(values, ref execution.Stack,')
 new=new.replace('CreateTupleFromStack(ref execution.Stack,','CreateTupleFromStack(values, ref execution.Stack,')
 new=new.replace('execution.Stack.TryAdvanceNativeIteration(', 'execution.Stack.TryAdvanceNativeIteration(values, ')
 new=new.replace('execution.Stack.TryPrepareNativeIteration(', 'execution.Stack.TryPrepareNativeIteration(values, ')
 new=new.replace('TryExecuteDictionaryLoop(ref execution, scope, invocation, instruction)',
  '!execution.Stack.BorrowsSlotSpan && TryExecuteDictionaryLoop(ref execution, scope, invocation, instruction)')
 a=old.index('\n        {');header=old[:a]
 wrapper=header+'\n            => ExecuteInstructionPrefix(ref execution, execution.Stack.Values, scope, invocation, asynchronous, out pending, out pendingSpan, out nextCall);\n\n'
 return wrapper+new
method('LythonRuntime.Executable.Interpreter.Dispatch.cs','ExecuteInstructionPrefix',prefix)

def makeList(old):
 s=old.replace('CreateListFromStack(ref ExecutableValueStorage stack,','CreateListFromStack(Span<ExecutableSlot> values, ref ExecutableValueStorage stack,')
 s=s.replace('items[i] = stack[start + i];','if ((i & 1023) == 0) context.CheckExecution(span);\n            items[i] = values[start + i].Object.RequireNotNull();')
 return s.replace('stack.RetireTo(start)','stack.RetireTo(values, start)')
method('LythonRuntime.Executable.Operations.cs','CreateListFromStack',makeList,4)
method('LythonRuntime.Executable.Operations.cs','CreateTupleFromStack',lambda s:
 s.replace('CreateTupleFromStack(ref ExecutableValueStorage stack,','CreateTupleFromStack(Span<ExecutableSlot> values, ref ExecutableValueStorage stack,')
 .replace('stack.Values.AsSpan(', 'values.Slice(').replace('stack.RetireTo(start)','stack.RetireTo(values, start)'),4)

p=root/'LythonRuntime.Executable.cs';s=p.read_text(encoding='utf-8')
s=s.replace('internal bool TryPrepareNativeIteration(object source,','internal bool TryPrepareNativeIteration(Span<ExecutableSlot> values, object source,')
s=s.replace('internal bool TryAdvanceNativeIteration(int slot,','internal bool TryAdvanceNativeIteration(Span<ExecutableSlot> values, int slot,')
a=s.index('        internal bool TryPrepareNativeIteration(');b=s.index('\n        public Memory<ExecutableSlot>',a)
chunk=s[a:b].replace('PublishValue(', 'PublishValue(values, ').replace('_items.Length','values.Length').replace('_items[slot]','values[slot]')
s=s[:a]+chunk+s[b:]
needle='''        internal void PublishSlot(int resultSlot, int liveExtent, ExecutableSlot result)'''
assert needle in s
s=s.replace(needle,'''        internal void PublishValue(Span<ExecutableSlot> values, int resultSlot, int liveExtent, object result)
            => PublishSlot(values, resultSlot, liveExtent, ExecutableSlot.FromObject(result));

'''+needle)
p.write_text(s,encoding='utf-8',newline='\n')
# Array-only helpers below are reached only with an actual owned invocation.
# Keep their array identity; they do not receive the private native span.
(r/'span-handlers-applied.json').write_text(json.dumps(changes,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Existing prefix/handlers now take explicit values; owned entry wrapper retained for actual async/normal callers. Borrowed execution not switched yet.')
