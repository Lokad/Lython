from pathlib import Path
import json

r=Path(__file__).parent
assert not(r/'borrowed-prefix-connected.json').exists()
root=Path('src/Lokad.Lython/Runtime')
data={}
def get(name):
 if name not in data:data[name]=(root/name).read_text(encoding='utf-8')
 return data[name]
def replace(name,old,new):
 s=get(name);assert s.count(old)==1,(name,old[:100],s.count(old));data[name]=s.replace(old,new)

f='LythonRuntime.Executable.Interpreter.Dispatch.cs'
replace(f,'private enum InstructionPause','internal enum InstructionPause')
replace(f,'=> ExecuteInstructionPrefix(ref execution, execution.Stack.Values, scope, invocation, asynchronous, out pending, out pendingSpan, out nextCall);',
 '=> ExecuteInstructionPrefix(ref execution, execution.Stack.Values, scope, invocation, asynchronous, 0, out pending, out pendingSpan, out nextCall, out _);')
replace(f,'''        private static InstructionPause ExecuteInstructionPrefix(ref ExecutableWorkState execution, Span<ExecutableSlot> values, ExecutionContext scope,
            ExecutionContext? invocation, bool asynchronous, out ValueTask<bool> pending, out LythonSourceSpan? pendingSpan,
            out ValueTask<ExecutionContext?> nextCall)''','''        internal static InstructionPause ExecuteInstructionPrefix(ref ExecutableWorkState execution, Span<ExecutableSlot> values, ExecutionContext scope,
            ExecutionContext? invocation, bool asynchronous, int unpackedReturnCount,
            out ValueTask<bool> pending, out LythonSourceSpan? pendingSpan,
            out ValueTask<ExecutionContext?> nextCall, out int unpackedTupleStart)''')
replace(f,'            pending = default;\n            pendingSpan = default;\n            nextCall = default;',
 '            pending = default;\n            pendingSpan = default;\n            nextCall = default;\n            unpackedTupleStart = -1;')
replace(f,'''                        case ExecutableOpCode.MakeTuple:
                            PublishInstructionResult''','''                        case ExecutableOpCode.MakeTuple:
                            if (TryPrepareUnpackedTupleReturn(ref execution, values, unpackedReturnCount, instruction, scope))
                            {
                                unpackedTupleStart = instruction.InputStart;
                                return InstructionPause.Boundary;
                            }
                            PublishInstructionResult''')
needle='''                        case ExecutableOpCode.ForNext:
                            if (execution.Stack.TryAdvanceNativeIteration(values, instruction.InputStart, out var nativeNext))'''
replace(f,needle,'''                        case ExecutableOpCode.ForNext:
                            if (execution.Stack.BorrowsSlotSpan)
                            {
                                if (!TryAdvanceBorrowedIteration(values[instruction.InputStart].Object.RequireNotNull(),
                                    out var hasNext, out var nextValue)) return InstructionPause.ContextRequired;
                                if (hasNext) PublishInstructionResult(ref execution, values, invocation, instruction, nextValue);
                                else
                                {
                                    execution.Stack.RetireTo(values, instruction.InputStart);
                                    execution.InstructionIndex = instruction.TargetIndex;
                                    jumped = true;
                                }
                            }
                            else if (execution.Stack.TryAdvanceNativeIteration(values, instruction.InputStart, out var nativeNext))''')
replace(f,'''                        case ExecutableOpCode.GetIter:
                            if (execution.Stack.TryPrepareNativeIteration(values, 
                                ReadOperand(ref execution, values, instruction.InputStart, scope, 0),
                                instruction.ResultSlot, instruction.LiveExtent, instruction.Span)) break;''','''                        case ExecutableOpCode.GetIter:
                            var source = ReadOperand(ref execution, values, instruction.InputStart, scope, 0);
                            if (execution.Stack.TryPrepareNativeIteration(values, source,
                                instruction.ResultSlot, instruction.LiveExtent, instruction.Span)) break;
                            if (execution.Stack.BorrowsSlotSpan && source is PyList or PyTuple or PyRange or PyBytes or PyString or PyDict or PySet)
                            {
                                PublishInstructionResult(ref execution, values, invocation, instruction,
                                    PyIteration.Cursor.Create(source, instruction.Span, scope));
                                break;
                            }''')
replace(f,'''instruction.OpCode is not (ExecutableOpCode.Jump or ExecutableOpCode.Return or ExecutableOpCode.ReturnNone))''',
 '''instruction.OpCode is not (ExecutableOpCode.Jump or ExecutableOpCode.Return or ExecutableOpCode.ReturnNone)
                                && !(execution.Stack.BorrowsSlotSpan && instruction.OpCode == ExecutableOpCode.AbruptJump))''')

f='LythonRuntime.Executable.cs'
replace(f,'            if (source is not (PyList or PyTuple)) return false;',
 '            if (BorrowsSlotSpan || source is not (PyList or PyTuple)) return false;')

f='LythonRuntime.Executable.Interpreter.cs'
replace(f,'if (execution.Code.ExceptionRegions.Count != 0 || source < 0',
 'if (!execution.Stack.BorrowsSlotSpan && execution.Code.ExceptionRegions.Count != 0 || source < 0')
replace(f,'if (execution.Code.ExceptionRegions.Count != 0 &&\n                TryHandleAbrupt',
 'if (invocation is not null && execution.Code.ExceptionRegions.Count != 0 &&\n                TryHandleAbrupt')
replace(f,'''                case ExecutableOpCode.AbruptJump:
                    return invocation!.DeliverJump(new PendingJump(instruction.TargetIndex, instruction.DiscardIterator), instruction.Span);''','''                case ExecutableOpCode.AbruptJump:
                    if (invocation is not null)
                        return invocation.DeliverJump(new PendingJump(instruction.TargetIndex, instruction.DiscardIterator), instruction.Span);
                    // A borrowed prefix has not entered an exception handler,
                    // and its admission excludes finally/context-manager regions.
                    if (instruction.DiscardIterator) execution.Stack.RetireTo(values, execution.Stack.LiveExtent - 1);
                    execution.InstructionIndex = instruction.TargetIndex;
                    return true;''')

f='LythonRuntime.Executable.Calls.Invoke.cs'
replace(f,'using Lokad.Lython.Frontend;','using System.Numerics;\nusing Lokad.Lython.Frontend;')
replace(f,'if (function is not null && function.CanStartInline && invocation is not null)',
 '''if (function is not null && function.CanStartInline
                && (invocation is not null || execution.Stack.BorrowsSlotSpan && scope.State.CurrentRecursionDepth < NativeCallDepth))''')
replace(f,'''                    var unpackedReturn = PrepareUnpackedCallReturn(ref execution, values, call, start, out var originalExtent);''',
 '''                    var originalExtent = execution.Stack.LiveExtent;
                    var unpackedReturn = execution.Stack.BorrowsSlotSpan ? default
                        : PrepareUnpackedCallReturn(ref execution, values, call, start, out originalExtent);''')
replace(f,'''                            frame.EnterExecutableSlots();
                            invocation.AttachPreparedCall(frame, call, start, call.CallSpan, CallCompletion.Call, function.DefinitionContext.MemoryGovernor);''',
 '''                            if (invocation is not null)
                            {
                                frame.EnterExecutableSlots();
                                invocation.AttachPreparedCall(frame, call, start, call.CallSpan, CallCompletion.Call, function.DefinitionContext.MemoryGovernor);
                            }''')
needle='''            // These existing native receiver operations need execution services,'''
insert='''            if (!call.HasReceiver && call.IsPositionalOnly && IsRangeBuiltin(target))
            {
                if (!TryInvokeNativeRange(values.Slice(start + call.ArgumentOffset, call.ArgumentCount),
                    call.CallSpan, scope, out var range)) return false;
                PublishInstructionResult(ref execution, values, invocation, execution.Code.Instructions[execution.InstructionIndex], range);
                return true;
            }

'''
replace(f,needle,insert+needle)
replace(f,'''                if (nativeGet && call.AccumulatesDictionary && TryExecuteDictionaryAccumulation(''',
 '''                if (!execution.Stack.BorrowsSlotSpan && nativeGet && call.AccumulatesDictionary && TryExecuteDictionaryAccumulation(''')
old='''                var result = nativeGet
                    ? InvokeDictionaryGet(dictionary!, argument!, call.ArgumentCount == 2
                        ? values[start + call.ArgumentOffset + 1].Object.RequireNotNull() : PyNone.Instance, call.CallSpan, scope)
                    : InvokeSingleInput(argument!, unary!, call.CallSpan, scope);'''
new='''                ExecutableSlot result = default;
                if (nativeGet)
                    result.Object = InvokeDictionaryGet(dictionary!, argument!, call.ArgumentCount == 2
                        ? values[start + call.ArgumentOffset + 1].Object.RequireNotNull() : PyNone.Instance, call.CallSpan, scope);
                else if (unary is Func<object, LythonSourceSpan, ExecutionContext, BigInteger> integerOperation)
                {
                    var integer = InvokeSingleInput(argument!, integerOperation, call.CallSpan, scope);
                    if (TryMachineInteger(integer, out var small)) result.SetInteger(small);
                    else result.Object = integer;
                }
                else result.Object = InvokeSingleInput(argument!, unary!, call.CallSpan, scope);'''
replace(f,old,new)

# Preserve canonical Python local errors in the now-shared format operand read.
f='LythonRuntime.Executable.PreparedOperations.cs'
replace(f,'if (!IsImmediateFormattedValue(values[source].Object.RequireNotNull())) return false;',
 'if (!IsImmediateFormattedValue(ReadOperand(ref execution, values, source, context, 0))) return false;')

f='LythonRuntime.Executable.Comparisons.cs'
needle='''            var first = ReadOperand(ref execution, values, instruction.InputStart, scope, 0);'''
replace(f,needle,'''            if (IsScalarComparison(instruction.BinaryOperator)
                && TryReadMachineOperand(execution.Code, values, instruction.InputStart, out var left)
                && TryReadMachineOperand(execution.Code, values, instruction.SecondInput, out var right))
            {
                scope.CheckExecution(instruction.Span);
                pending = new(CompleteComparisonBranch(ref execution, values, scope, instruction,
                    CompareOrderedResult(instruction.BinaryOperator, left.CompareTo(right))));
                return InstructionPause.Continue;
            }
'''+needle)

old=get('LythonRuntime.Executable.NativePrefix.cs')
tail=old[old.index('    internal static ExecutionContext CreateNativeContinuation'):]
bridge='''using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal const int NativeValueCapacity = 16;
    private const int NativeCallDepth = 8;

    // This lifetime borrows slots until actual suspension/protocol work needs
    // an owned frame. All instructions use the ordinary executable prefix.
    internal ref struct BorrowedExecutableInvocation
    {
        private readonly Span<ExecutableSlot> _values;
        private readonly ExecutionContext _scope;
        private readonly int _unpackedReturnCount;
        private ExecutableWorkState _work;
        private int _unpackedTupleStart;
        private bool _transferred;
        private ExecutionContext? _preparedChild;
        internal LythonRuntimeException? Failure { get; private set; }
        internal readonly bool ReturnedUnpacked => _unpackedTupleStart >= 0;
        internal readonly ExecutableCodeObject Code => _work.Code;
        internal int Index { readonly get => _work.InstructionIndex; set => _work.InstructionIndex = value; }
        internal int LiveExtent { readonly get => _work.Stack.LiveExtent; set => _work.Stack.RestoreNativeExtent(value); }

        internal BorrowedExecutableInvocation(PyExecutableFunction function, Span<ExecutableSlot> values,
            bool consumedByIteration, int unpackedReturnCount)
        {
            _values = values;
            _scope = function.DefinitionContext;
            _unpackedReturnCount = unpackedReturnCount;
            _unpackedTupleStart = -1;
            _work = new ExecutableWorkState
            {
                Code = function.CodeObject,
                ClosureCells = function.ClosureCells,
                Stack = new ExecutableValueStorage(function.CodeObject, _scope, function),
                InstructionIndex = function.CodeObject.EntryIndex,
                ReturnConsumedByIteration = consumedByIteration
            };
        }

        internal bool Run(LythonSourceSpan entrySpan, out ExecutableSlot result, Span<ExecutableSlot> unpackedReturn = default)
        {
            ExecutionState.EnsureInterpreterStack(entrySpan);
            var previous = _scope.State.CurrentException;
            try
            {
                var pause = ExecutionContext.ExecuteInstructionPrefix(ref _work, _values, _scope, null, false,
                    _unpackedReturnCount, out _, out _, out var nextCall, out _unpackedTupleStart);
                result = _work.ReturnValue.IsUnassigned ? ExecutableSlot.FromObject(PyNone.Instance) : _work.ReturnValue;
                if (pause == ExecutionContext.InstructionPause.ContextRequired) return false;
                if (pause == ExecutionContext.InstructionPause.Call)
                {
                    _preparedChild = nextCall.GetAwaiter().GetResult()
                        ?? throw new InvalidOperationException("A borrowed child transition requires its prepared frame.");
                    return false;
                }
                if (pause != ExecutionContext.InstructionPause.Boundary)
                    throw new InvalidOperationException("A borrowed executable prefix cannot suspend.");
                if (ReturnedUnpacked)
                {
                    _values.Slice(_unpackedTupleStart, _unpackedReturnCount).CopyTo(unpackedReturn);
                    _work.Stack.RetireTo(_values, Code.FirstTemporarySlot);
                    _scope.CheckExecution(Code.Instructions[Index + 1].Span);
                }
                return true;
            }
            catch (LythonRuntimeException error)
            {
                if (previous is not null && !ReferenceEquals(error.OriginalPythonException, previous)) error.PythonContext ??= previous;
                if (Code.ExceptionRegions.Count == 0) throw;
                _scope.CheckExecution(entrySpan);
                Failure = error;
                result = ExecutableSlot.FromObject(PyNone.Instance);
                return false;
            }
            finally { _scope.State.SetCurrentException(previous); }
        }

        internal void PrepareTransfer() => _values[LiveExtent..].Clear();

        internal void TransferOwnership(ExecutionContext frame)
        {
            if (_preparedChild is { } child)
            {
                var call = Code.CallSites[Code.Instructions[Index].CallSiteIndex];
                frame.AdoptPreparedNativeChild(child, call, Code.Instructions[Index].InputStart, child.MemoryGovernor);
                _preparedChild = null;
            }
            _transferred = true;
        }

        internal void Dispose()
        {
            if (_transferred) return;
            try
            {
                if (_preparedChild is { } child)
                {
                    _preparedChild = null;
                    try { ExecutionContext.AbortPreparedNativeCall(child, child.MemoryGovernor); }
                    finally { _scope.LeaveInterpreterFrame(); }
                }
            }
            finally
            {
                // A fused return may own a private cursor without GetIter.
                // Retire all actual temporaries before ending this borrow.
                for (var i = LiveExtent - 1; i >= Code.FirstTemporarySlot; i--)
                    if (_values[i].Reference is ExecutableTemporaryValue owned)
                    { _values[i].Object = null!; owned.Dispose(); }
                LiveExtent = Code.FirstTemporarySlot;
            }
        }
    }

    private static bool TryAdvanceBorrowedIteration(object iterator, out bool hasNext, out ExecutableSlot value)
    {
        value = default;
        if (iterator is PyIteration.Cursor cursor)
        {
            if (cursor.TryMoveNextInteger(out hasNext, out var integer))
            { if (hasNext) value.SetInteger(integer); return true; }
            hasNext = cursor.TryMoveNext(out var item);
            if (hasNext) value.Object = item;
            return true;
        }
        if (iterator is PyStringOps.CasedWhitespaceIteration words)
        {
            var next = words.MoveNext(); hasNext = next.HasValue;
            if (hasNext) value.Object = next.Value;
            return true;
        }
        hasNext = false;
        return false;
    }

    private static bool TryPrepareUnpackedTupleReturn(ref ExecutableWorkState execution, Span<ExecutableSlot> values,
        int count, in ExecutableInstruction instruction, ExecutionContext context)
    {
        var index = execution.InstructionIndex;
        if (count == 0 || instruction.ItemCount != count || instruction.HasLocalResult
            || index + 1 >= execution.Code.Instructions.Length) return false;
        ref readonly var next = ref execution.Code.Instructions[index + 1];
        if (next.OpCode != ExecutableOpCode.Return || next.InputStart != instruction.ResultSlot) return false;
        var bytes = SlotTupleBytes(values.Slice(instruction.InputStart, count), context, instruction.Span);
        context.MemoryGovernor.Reserve(bytes, instruction.Span);
        try { context.CheckExecution(instruction.Span); context.MemoryGovernor.Commit(bytes); }
        catch { context.MemoryGovernor.ReleaseReserved(bytes); throw; }
        return true;
    }

'''+tail
data['LythonRuntime.Executable.Borrowed.cs']=bridge
f='LythonRuntime.Executable.Integers.cs';s=get(f);cut=s.index('    internal ref partial struct NativeExecution')
data[f]=s[:cut]+'}\n'
f='PyExecutableFunction.cs';replace(f,'new LythonRuntime.NativeExecution(', 'new LythonRuntime.BorrowedExecutableInvocation(')

# Validate every replacement above before writing any part of this transition.
for name,s in data.items():
 if name=='LythonRuntime.Executable.NativePrefix.cs':continue
 (root/name).write_text(s,encoding='utf-8',newline='\n')
p=root/'LythonRuntime.Executable.NativePrefix.cs'
assert p.resolve().parent==root.resolve()
p.unlink()
p=Path('tests/Lokad.Lython.Tests/CasedSplitOwnershipTests.cs')
s=p.read_text(encoding='utf-8');assert s.count('new LythonRuntime.NativeExecution(')==1
p.write_text(s.replace('new LythonRuntime.NativeExecution(', 'new LythonRuntime.BorrowedExecutableInvocation('),encoding='utf-8',newline='\n')
(r/'borrowed-prefix-connected.json').write_text(json.dumps(dict(stage='Active prototype; not yet built/qualified/measured',removed='NativeExecution opcode driver/operand-format-call methods and integer-wrapper partial',files=list(data)),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Connected borrowed entry to the existing shared span prefix; deleted the separate native driver. Prototype requires build/regression checks, no performance claim.')
