from pathlib import Path
import ast,hashlib,json

r=Path(__file__).parent
assert (r/'candidate-identity.json').exists()
assert not(r/'local-screen.py').exists()
old=r.parent/'unified-helper-entry-r378/freeze-and-screen.py'
s=old.read_text(encoding='utf-8')
a=s.index('class Worker:');b=s.index('started=time.monotonic();save()',a)
worker=s[a:b]
worker=worker.replace('def __init__(self,label,case,stack):','def __init__(self,label,case,lane,stack):')
worker=worker.replace('self.label,self.case,self.seq,self.process=label,case,0,None','self.label,self.case,self.lane,self.seq,self.process=label,case,lane,0,None')
worker=worker.replace("lane='warm'","lane=self.lane")
prefix='''from pathlib import Path
import contextlib,hashlib,importlib.util,json,math,os,statistics,subprocess,tempfile,time
r=Path(__file__).parent;sdk='C:/Users/JoannesVermorel/.dotnet11'
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert not(r/'local-screen.json').exists()
env={k:v for k,v in os.environ.items()if k.casefold()!='path'};env['DOTNET_ROOT']=sdk;env['PATH']=sdk+';C:/Python313;'+next(v for k,v in os.environ.items()if k.casefold()=='path')
assert not any(k.startswith(('DOTNET_','COMPlus_'))and k!='DOTNET_ROOT'for k in env)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('protocol','benchmarks/cpython-worker.py');protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
catalog=(r/'catalog.json').resolve();cases={c['id']:c for c in json.loads(catalog.read_text(encoding='utf-8'))['cases']}
out=dict(complete=False,identityCoreSHA256=identity['coreSHA256'],identityFile='candidate-identity.json',location='Local Windows development box; no quiet-machine or portable CPU claim. Initial complete-script source-pair diagnostic.',warmupBoundary='full request wall time',elapsedBoundary='Unchanged command-v2 warm: mediated filesystem I/O/full stdout-file validation/prior-result cleanup; excludes compile/startup/reset/protocol/final cache. Fresh adds compile/compiled-owner disposal. No CPU/heap/tail claim.',jobs=[])
def save():(r/'local-screen.json').write_text(json.dumps(out,indent=2)+'\\n',encoding='utf-8',newline='\\n')
'''
suffix='''started=time.monotonic();save()
jobs=[('scripts.file-search.large.protected','warm'),('scripts.report-render.large','warm'),('scripts.csv-fulfillment.large','warm'),('scripts.csv-fulfillment.large','compile-run'),('scripts.text-summary-helpers.nonlocal-counter.large','warm'),('scripts.json-summary-helpers.large','warm'),('diagnostic.loop-helper.short-zero.large','warm'),('diagnostic.loop-helper.observed.large','warm')]
for caseId,lane in jobs:
 assert time.monotonic()-started<220,'Bounded source screen ended; preserve observations and joined cleanup.'
 with contextlib.ExitStack()as stack:
  workers=[Worker(label,cases[caseId],lane,stack)for label in ['reference','candidate','candidate-control','reference-control']]
  counts=[];warmups=[]
  for w in workers:
   assert not w.ready['serverGc']
   count=1;end=time.monotonic()+2.5;rows=[]
   while time.monotonic()<end:
    rows.append(w.request('batch',count));count=max(1,min(100000,math.ceil(count*.15/max(w.lastSeconds,.000001))))
   counts.append(count);warmups.append(rows)
  samples=[]
  for round in range(5):
   for i in [(round+offset)%4 for offset in range(4)]:samples.append(dict(round=round,label=workers[i].label,response=workers[i].request('batch',counts[i])))
  med={w.label:statistics.median(1000*x['response']['elapsedTicks']/x['response']['clockFrequency']/x['response']['completedInvocations']for x in samples if x['label']==w.label)for w in workers}
  result=dict(case=caseId,lane=lane,identities={w.label:w.ready for w in workers},counts=counts,warmups=warmups,samples=samples,medianMilliseconds=med,changePercent=sorted(100*(med[a]/med[b]-1)for a in ['candidate','candidate-control']for b in ['reference','reference-control']))
 result['allWorkersJoinedAndFixturesRemoved']=True;out['jobs'].append(result);save();print(caseId,lane,med,result['changePercent'],flush=True)
out.update(complete=True,elapsedSeconds=time.monotonic()-started,allGoldensAndBudgetsPassed=True,allUsersJoined=True,portablePerformanceClaim=False);save()
print('Completed bounded local source screen; all processes joined and fixtures closed. Diagnostic elapsed only; no CPU or quietVM qualification.',flush=True)
'''
script=prefix+worker+suffix;ast.parse(script)
(r/'local-screen.py').write_text(script,encoding='utf-8',newline='\n')
(r/'screen-prospective.json').write_text(json.dumps(dict(referenceCore='716176a8',candidateCore=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))['coreSHA256']['candidate'],scope='Eight complete warm/fresh jobs,4freshprocesses/job,2.5sfullrequestwarmups,5rotating~0.15s batches. Existing command-v2 goldens/ownership/close protocol; local diagnostic only.',hypothesis='Shared executable prefix removes duplicate native instruction/operand/call/format dispatch without eager owned caller arrays. Architecture simplification, allocation and CPU are separate; no predicted gain.',affected='Protected file search, JSON report, CSV fulfillment warm/fresh; unchanged text/JSON/short/observed controls.',decision='Retain every adverse/unstable observation. Stable material adversity can justify source refinement before VM; unstable or inconclusive elapsed is uncertainty, not failure. No fixed percentage veto or unchanged automatic repetition.',reusedWorkerProcedureSHA256=hashlib.sha256(old.read_bytes()).hexdigest(),publicationHeld=True),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Prepared existing-worker local screen with explicit warm/fresh phases and controls; no new benchmark framework.')
