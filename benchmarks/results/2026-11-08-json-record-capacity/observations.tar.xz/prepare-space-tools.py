from pathlib import Path
r=Path(__file__).parent
s=(r.parents[1]/'conditional-checkpoint-r109/prepare-space.py').read_text(encoding='utf8').replace('r109','r110-refinement')
s=s.replace("('0873ec4624d2','6c6697991864','547825f9dfe5','137b563ac198')","('0873ec4624d2','6c6697991864','547825f9dfe5','137b563ac198','df206f479ab6','520b3eb0a5d7','67f841962f56','0050f188b079','43fdf658f44b','4c072fed1bad')")
s=s.replace('r.parent/','r.parents[1]/')
s=s.replace('assert len(groups)==4','assert len(groups)==10')
s=s.replace('four known immutable groups','ten known immutable groups')
(r/'prepare-space.py').write_text(s,encoding='utf8')
