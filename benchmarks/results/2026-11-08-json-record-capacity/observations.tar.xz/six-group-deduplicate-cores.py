from pathlib import Path
import json,shlex,subprocess
r=Path(__file__).parent
inventory=json.loads((r/'space-inventory.json').read_text())
groups=[];freed=0
for digest,rows in inventory['groups'].items():
    inodes={row['inode']:[p for p in rows if p['inode']==row['inode']]for row in rows}
    if len(inodes)<2:continue
    canonical=rows[0]
    selected=[canonical]
    for inode,paths in inodes.items():
        if inode==canonical['inode'] or len(paths)!=paths[0]['links']:continue
        selected.extend(paths);freed+=paths[0]['bytes']
        if freed>=48*1024*1024:break
    if len(selected)>1:groups.append(dict(sha256=digest,paths=selected))
    if freed>=48*1024*1024:break
assert 48*1024*1024<=freed<=56*1024*1024
remote='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve()
groups=GROUPS
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]ollector.dll|[p]erf record'],capture_output=True).returncode==1
 before=shutil.disk_usage(base).free
 aliases=ALIASES
 # Validate the complete bounded operation before touching any path.
 for group in groups:
  for row in group['paths']:
   p=Path(row['path']);assert p.resolve()==p and base in p.parents and p.name in ('Lokad.Lython.dll','baseline-core.dll','current-core.dll')
   stat=p.stat();assert stat.st_ino==row['inode']and stat.st_size==row['bytes']
   assert hashlib.sha256(p.read_bytes()).hexdigest()==group['sha256']
 for group in groups:
  canonical=Path(group['paths'][0]['path'])
  for row in group['paths'][1:]:
   p=Path(row['path']);assert not p.samefile(canonical)
   temporary=p.with_name(p.name+'.r110-refinement-identical-link');assert not temporary.exists()
   os.link(canonical,temporary);os.replace(temporary,p)
  for row in group['paths']:
   p=Path(row['path']);assert p.samefile(canonical)and hashlib.sha256(p.read_bytes()).hexdigest()==group['sha256']
 for name,row in aliases.items():
  p=Path(name);assert str(p.resolve())==row['path'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
 receipt=dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,groups=groups,allPathsAndBytesPreserved=True,archivesUntouched=True,allOriginalAliasesVerified=True)
 proof=base/'r110-refinement-core-dedup-proof.json';assert not proof.exists();proof.write_text(json.dumps(receipt,indent=2)+'\\n')
 print(json.dumps(receipt))
'''.replace('GROUPS',repr(groups)).replace('ALIASES',repr(inventory['aliases']))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -c '+shlex.quote(remote)],capture_output=True)
(r/'dedup.stdout').write_bytes(done.stdout);(r/'dedup.stderr').write_bytes(done.stderr)
assert done.returncode==0,done.stderr
receipt=json.loads(done.stdout);(r/'dedup-proof.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print('Exact-byte core hardlinks preserve',sum(len(g['paths'])for g in groups),'paths;',receipt['afterFreeBytes']-receipt['beforeFreeBytes'],'bytes freed. Archive bytes untouched.')
