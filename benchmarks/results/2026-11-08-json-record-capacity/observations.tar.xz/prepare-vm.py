from pathlib import Path
import ast,hashlib,json,shutil,tarfile
r=Path(__file__).parent;old=r.parent/'b468';b=r/'b469';b.mkdir()
source=json.loads((r/'identity.json').read_text(encoding='utf8'));prior=json.loads((old/'identity.json').read_text(encoding='utf8'));jobs=prior['jobs']
identity={**prior,'sourceRevision':source['candidateSource'],'baselineSource':source['baselineSource'],'coreSHA256':{role:source['coreSHA256']['before'if role.startswith('reference')else'candidate']for role in ['reference','reference-control','candidate','candidate-control']},'productionSources':source['productionSources'],'qualification':source['qualification']}
(b/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf8')
catalogSHA=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest();assert catalogSHA==hashlib.sha256((old/'representative.json').read_bytes()).hexdigest()
for name in ['collect.py','run.sh','retrieve.py','assess-vm.py','archive-owned.py','launch.py']:
 s=(old/name).read_text(encoding='utf8').replace('json-record-capacity-b468-20261108','refined-record-capacity-b469-20261108').replace('lython-b468-json-record-capacity','lython-b469-refined-record-capacity').replace('json-record-capacity-b468-launch.py','refined-record-capacity-b469-launch.py').replace('lython-b468-fixtures','lython-b469-fixtures')
 if name=='collect.py':s=s.replace('R110 known-layout capacity;','Refined R110 ordered-record growth capacity;')
 if name=='launch.py':
  needle="  root.mkdir();a.extractall(root,filter='data')\n identity="
  assert needle in s
  s=s.replace(needle,"  root.mkdir();a.extractall(root,filter='data')\n catalog=base/'json-record-capacity-b468-20261108/representative.json'\n assert hashlib.sha256(catalog.read_bytes()).hexdigest()=='"+catalogSHA+"'\n os.link(catalog,root/'representative.json')\n identity=")
 (b/name).write_text(s,encoding='utf8',newline='\n')
 if name.endswith('.py'):ast.parse(s)
for src,name in [(r/'images/candidate/Lokad.Lython.dll','current-core.dll'),(r/'identity.json','focused.json'),(r/'source.patch','source.patch'),(r/'pre-measurement-plan.md','pre-measurement-plan.md'),(old/'setup-contract.json','setup-contract.json')]:shutil.copyfile(src,b/name)
contract='''One bounded R110 refinement after observed initialeb14 alternating allocation+14.7%/controlled elapsed+4.3to+10.8%; preserve initial source/raw/adverse conditions. Only shared ordered-prefix value growth sizing changes: initial JSON4slotseed restored byte-exactly, growth uses already-authoritative layout.Count. Eight-record report21->7replacement admissions, fullgoldens/balance0; initialeb14had0growth but excess short-row capacity.897public/193internal peractual11/10 pass. New prefixes can still conservatively retain extra slots/deny earlier if they outgrow initial backing; all capacity/overlap funded. No new threshold/cache/predictor/owner/dispatch/options, ordinary changed shapes and CSV actual-width/adoption remain.
Same exact five-case catalog and six-job matrix, complete3072record24field report bothAPIs/alternating24and3field sync, unchanged short-report/CSV/JSON controls, sameworker7cf/normaloptional0.4/normalGC/tiering. Independent CPython full stdout/filegoldens, 5swarmup/role/job,7rotated150msrounds, two processes/core; coarse CPU separate.210sowner+30stop+30margin; complete mediated RAM I/O/fullvalidation/priorresultcleanup included, compilation/startup/staging/finalcacheteardown excluded. No new frontend/external/producer/heap/tail claim. One same-matrix before/after then decide retention/debt; original source qualification independent.
240MiBOSfloor+7MiBevidence+actualpayloadpreflight. Reuse archivedB4651aa/aux via verifiedhardlinks; reuse exact large B468catalog through one fresh SHA-proven hardlink instead of another physical copy, every original path/byte/archive preserved. Uploadonly1310core/scripts/newidentity; persistent raw and owned128MiBRAM fixtures, all Ready/source/core/aux/golden/quiet/Closed/exit/join/unmount/archive/local gates. No maintenance/deletion/new framework.\n'''
(b/'contract.md').write_text(contract,encoding='utf8')
(b/'catalog-source.json').write_text(json.dumps(dict(remote='json-record-capacity-b468-20261108/representative.json',sha256=catalogSHA,allOriginalBytesAndPathsPreserved=True),indent=2)+'\n',encoding='utf8')
with tarfile.open(b/'payload.tgz','w:gz')as a:
 for n in ['collect.py','run.sh','current-core.dll','identity.json','pre-measurement-plan.md','setup-contract.json','contract.md','focused.json','source.patch','archive-owned.py','catalog-source.json']:a.add(b/n,arcname=n)
print('Refined six-job matrix prepared, exact catalog reused through verified hardlink; no evidence deletion.')
