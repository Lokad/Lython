from pathlib import Path
import json,tarfile
r=Path(__file__).parent;d=json.loads((r/'space-inventory.json').read_text())
eligible=[]
for digest,rows in d['groups'].items():
 inodes={}
 for row in rows:inodes.setdefault(row['inode'],[]).append(row)
 size=sum(paths[0]['bytes']for inode,paths in inodes.items()if inode!=rows[0]['inode']and len(paths)==paths[0]['links'])
 eligible.append((digest[:12],size))
with tarfile.open(r/'b469/payload.tgz')as a:payload=sum(((m.size+4095)//4096)*4096 for m in a.getmembers())
required=(240+32)*1024*1024+payload
print('Eligible exact-byte savings',eligible,'total',sum(v for _,v in eligible),'free',d['freeBytes'],'required with32MiBheadroom',required)
assert d['freeBytes']+sum(v for _,v in eligible)>required
p=r/'deduplicate-cores.py';s=p.read_text(encoding='utf8').replace('48*1024*1024','40*1024*1024').replace('56*1024*1024','48*1024*1024');p.write_text(s,encoding='utf8')
