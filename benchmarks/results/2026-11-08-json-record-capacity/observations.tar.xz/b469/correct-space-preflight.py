from pathlib import Path
import json,math,shutil,tarfile
r=Path(__file__).parent;f=r.parent;old=f.parent/'b468'
shutil.copyfile(r/'launch.log',r/'initial-space-refusal.log')
raw=sum((p.stat().st_size+4095)//4096*4096 for p in(old/'retrieved').rglob('*')if p.is_file())
archive=(old/'observations.tgz').stat().st_size;estimate=math.ceil((raw+archive)*1.5);assert estimate<32*1024*1024
(r/'sizing.json').write_text(json.dumps(dict(priorWideRawRoundedBytes=raw,priorWideArchiveBytes=archive,estimateWith50PercentHeadroom=estimate,evidenceHeadroomBytes=32*1024*1024,osFloorBytes=240*1024*1024,allOriginalEvidencePreserved=True,noServiceOrWorkerStartedByOriginalRefusal=True),indent=2)+'\n',encoding='utf8')
p=r/'launch.py';s=p.read_text(encoding='utf8').replace('(240+7)','(240+32)').replace('evidenceHeadroomMiB=7','evidenceHeadroomMiB=32').replace('refined-record-capacity-b469-launch.py','refined-record-capacity-b469-space-corrected-launch.py');(r/'launch-corrected.py').write_text(s,encoding='utf8')
p=r/'setup-contract.json';d=json.loads(p.read_text(encoding='utf8'));d['evidenceHeadroomMiB']=32;p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf8')
p=r/'contract.md';s=p.read_text(encoding='utf8').replace('240MiBOSfloor+7MiBevidence','240MiBOSfloor+32MiBevidence')+'\nInitial preflight refused before root/service/worker creation; original log/source preserved. Re-estimated from completed wide B468 raw+archive plus50% headroom (<32MiB). Fresh bounded exact-byte17-path core hardlinks recovered44736512B, every original alias/path/content/archive retained; full local proof included. No threshold relaxation or timed retry.\n';p.write_text(s,encoding='utf8')
shutil.copyfile(f/'dedup-proof.json',r/'dedup-proof.json')
with tarfile.open(r/'payload.tgz','w:gz')as a:
 for n in ['collect.py','run.sh','current-core.dll','identity.json','pre-measurement-plan.md','setup-contract.json','contract.md','focused.json','source.patch','archive-owned.py','catalog-source.json','sizing.json','dedup-proof.json']:a.add(r/n,arcname=n)
print('Wide evidence footprint+50% fits32MiB headroom; original preflight preserved, fresh exact-byte space proof retained.')
