from pathlib import Path
import os,subprocess
r=Path(__file__).parent;env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+env['PATH']
for name,project,framework,filter in [
 ('public11','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','net11.0','(FullyQualifiedName~Json|FullyQualifiedName~RepresentativeScriptTests)&Category!=Stress'),
 ('public10','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','net10.0','(FullyQualifiedName~Json|FullyQualifiedName~RepresentativeScriptTests)&Category!=Stress'),
 ('internal11','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','net11.0','(FullyQualifiedName~Json|FullyQualifiedName~RecordKeyOwnershipTests|FullyQualifiedName~CsvRecordValueOwnershipTests|FullyQualifiedName~CsvPrivateRecordOwnershipTests)&Category!=Stress'),
 ('internal10','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','net10.0','(FullyQualifiedName~Json|FullyQualifiedName~RecordKeyOwnershipTests|FullyQualifiedName~CsvRecordValueOwnershipTests|FullyQualifiedName~CsvPrivateRecordOwnershipTests)&Category!=Stress')]:
 with(r/(name+'.log')).open('w',encoding='utf8')as log:done=subprocess.run([env['DOTNET_HOST_PATH'],'test',project,'-c','Release','-f',framework,'--filter',filter],stdout=log,stderr=subprocess.STDOUT,env=env)
 text=(r/(name+'.log')).read_text(encoding='utf8')
 if done.returncode:print(text[-8000:],flush=True);raise SystemExit(done.returncode)
 print(name,text.strip().splitlines()[-1],flush=True)
