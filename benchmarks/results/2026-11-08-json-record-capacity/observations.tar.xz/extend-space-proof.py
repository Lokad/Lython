from pathlib import Path
import shutil
r=Path(__file__).parent
for n in ['prepare-space.py','space-inventory.json','deduplicate-cores.py']:
 shutil.copyfile(r/n,r/('six-group-'+n))
p=r/'prepare-space-tools.py';s=p.read_text(encoding='utf8')
s=s.replace("'df206f479ab6','520b3eb0a5d7')\")","'df206f479ab6','520b3eb0a5d7','67f841962f56','0050f188b079','43fdf658f44b','4c072fed1bad')\")")
s=s.replace("'assert len(groups)==6'","'assert len(groups)==10'")
s=s.replace("(r/'prepare-space.py').write_text(s,encoding='utf8')","s=s.replace('four known immutable groups','ten known immutable groups')\n(r/'prepare-space.py').write_text(s,encoding='utf8')")
p.write_text(s,encoding='utf8')
