from pathlib import Path
import json,shlex,subprocess
r=Path(__file__).parent;prior=r.parents[1]/'shared-cased-split-r92'
old=json.loads((prior/'space-inventory.json').read_text(encoding='utf-8'))['groups']
groups={k:[row['path']for row in v]for k,v in old.items()if k.startswith(('0873ec4624d2','6c6697991864','547825f9dfe5','137b563ac198','df206f479ab6','520b3eb0a5d7'))};assert len(groups)==6
remote='''from pathlib import Path
import fcntl,hashlib,json,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve();groups=GROUPS
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]ollector.dll|[p]erf record'],capture_output=True).returncode==1
 result=dict(freeBytes=shutil.disk_usage(base).free,groups={},aliases={})
 for digest,paths in groups.items():
  rows=[]
  for name in paths:
   p=Path(name).resolve();assert base in p.parents
   result['aliases'][name]=dict(path=str(p),sha256=digest)
   if any(row['path']==str(p)for row in rows):continue
   stat=p.stat();assert hashlib.sha256(p.read_bytes()).hexdigest()==digest
   rows.append(dict(path=str(p),inode=stat.st_ino,bytes=stat.st_size,links=stat.st_nlink))
  result['groups'][digest]=rows
 print(json.dumps(result,indent=2))
'''.replace('GROUPS',repr(groups))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -c '+shlex.quote(remote)],capture_output=True);assert done.returncode==0,done.stderr
(r/'space-inventory.json').write_bytes(done.stdout)
script=(r.parents[1]/'direct-comparison-r95/deduplicate-cores.py').read_text(encoding='utf-8').replace('r95-core-dedup-proof.json','r110-refinement-core-dedup-proof.json').replace('.r95-identical-link','.r110-refinement-identical-link')
script=script.replace("before=shutil.disk_usage(base).free","before=shutil.disk_usage(base).free\n aliases=ALIASES")
script=script.replace("receipt=dict(beforeFreeBytes",'''for name,row in aliases.items():
  p=Path(name);assert str(p.resolve())==row['path'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256']
 receipt=dict(beforeFreeBytes''')
script=script.replace("archivesUntouched=True)","archivesUntouched=True,allOriginalAliasesVerified=True)")
script=script.replace(".replace('GROUPS',repr(groups))",".replace('GROUPS',repr(groups)).replace('ALIASES',repr(inventory['aliases']))")
compile(script,'deduplicate','exec');(r/'deduplicate-cores.py').write_text(script,encoding='utf-8')
d=json.loads(done.stdout);print('Fresh idle-lease inventory of four known immutable groups;',sum(len(v)for v in d['groups'].values()),'canonical paths; freeBytes',d['freeBytes'],'no mutation yet.')
