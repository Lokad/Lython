from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;b=r/'b469';i=json.loads((r/'identity.json').read_text(encoding='utf8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in i['productionSources'].items())
receipt=json.loads((b/'archive-receipt.json').read_text(encoding='utf8'));assert receipt['complete']and receipt['jobs']==6
assert hashlib.sha256((b/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
with tarfile.open(b/'observations.tgz')as a:assert hashlib.sha256(a.extractfile('current-core.dll').read()).hexdigest()==i['coreSHA256']['candidate']
out=Path('benchmarks/results/2026-11-08-json-record-capacity');out.mkdir()
decision='''Retain refined R110/core13107e6b. One shared ordered-record value-capacity expression replaces repeated geometric replacements with immutable layout.Count on actual growth; baseline JSON construction seed restored exactly. No new owner/cache/predictor/policy/engine/options. Native/private growth, checked bounds, replacement overlap, current cancellation and terminal refusal retained. Eight-record complete report replacement admissions21->7; initial record funding512B unchanged, fullgoldens/balance0.897public/193internal focused peractual11/10 pass, nine new semantic/pending-user/retained/shared-budget/refusal/cancellation cases with independent CPython full goldens.
Wide report allocation-8.56to-8.58%bothAPIs; alternating/three controls neutral. Desktop elapsed variable/adverse retained. B469 six jobs170.447s, all source/core/aux/Ready/golden/quiet/Closed/exit/join/fixture/archive/local gates pass; no users/fixtures. Controlled wide sync-3.80to-10.29%, async-6.05to-7.53%, coarseCPU-5.56to-10.80 supports workload-specific gain. Sync baseline4.01%/candidate3.01%spread limits precision. Alternating elapsed-1.59to-4.20%, coarseCPUflat/slightlylower; originaleb14+4.31to+10.82%/allocation+14.7% does not recur; old source/data preserved. Short report nearbaseline, CSV baseline8.67%spread inconclusive, JSON nearbaseline/coarseCPUflat. No unrelated old-debt repayment or updated CPython ratio.
Prefixes beyond initial backing can still retain excess capacity or deny earlier after a wider layout; all retained/replacement storage charged. Existing changing-shape promotion remains. Initial preflight7MiB headroom refused before root/service/worker creation; actual priorwide raw+archive plus50% now fits32MiB. Exact-byte17path hardlinks recovered44736512B preserving every original alias/path/content/archive; original failed conditions preserved. Same catalog reused via SHA-proven hardlink, no evidence deletion. Exact retained-source full qualification next once at committed source; source726 cached green independent. Publication/regex unchanged, broader objective remains active.
'''
(r/'decision.md').write_text(decision,encoding='utf8')
with tarfile.open(out/'observations.tar.xz','w:xz')as a:
 for p in sorted(r.iterdir()):
  if p.name in ['images','growth-tool']:continue
  if p.name=='b469':
   for q in sorted(p.iterdir()):
    if q.name not in ['retrieved','current-core.dll','payload.tgz']:a.add(q,arcname='b469/'+q.name)
  else:a.add(p,arcname=p.name)
 for p in ['tests/Lokad.Lython.PublicApi.Tests/JsonRecordShapeTests.cs','tests/Lokad.Lython.PublicApi.Tests/JsonReadContinuationTests.cs']:a.add(p,arcname='tests/'+Path(p).name)
with tarfile.open(out/'observations.tar.xz')as a:assert hashlib.sha256(a.extractfile('b469/observations.tgz').read()).hexdigest()==receipt['archiveSHA256']
for src,name in [(r/'identity.json','identity.json'),(r/'assessment-local.json','allocation-and-local.json'),(b/'assessment.json','controlled-comparison.json')]:shutil.copyfile(src,out/name)
status=dict(status='Refined R110 retained, focused/controlled checks pass; exact committed-source full qualification pending independently.',coreSHA256=i['coreSHA256'],focusedChecks=i['focusedChecks'],archiveSHA256=hashlib.sha256((out/'observations.tar.xz').read_bytes()).hexdigest(),controlledArchiveSHA256=receipt['archiveSHA256'],noRemainingVMUsersOrFixtures=True,referenceGuideSource='7265538c')
(out/'status.json').write_text(json.dumps(status,indent=2)+'\n',encoding='utf8')
(out/'README.md').write_text('''# Known-layout JSON record value growth

Retain core `13107e6b`: one existing value-growth capacity choice uses immutable
record-layout width instead of geometric intermediate widths. Initial JSON object
seeding is unchanged. No new builder, owner, cache, predictor, dispatch or option.
Ordinary shape mutation and CSV actual-width/owned-array construction remain.
Baseline: fully qualified `7265538c`, core `1aa68ce9`. Candidate is the archived
one-file patch over metadata HEADdea4504d; exact source inventory and binary are
preserved. Full retained-source platform qualification is independently pending.

An eight-record complete report proves replacement admissions **21→7**, while
initial record reservations stay512B. Full stdout/file goldens and final allowance
baseline pass. Diagnostic stack capture is never timed. 897 public /193 internal
focused Release checks pass per actual .NET11/.NET10, including nine new public
Python value/order/duplicate/nested/error/real-async-hook/retained-result/shared-
allowance/cancellation/refusal/awaited-cleanup cases. No runtime semantic test failed.

| Complete script | Controlled elapsed, four median pairings | Coarse CPU |
| --- | ---: | ---: |
| Repeated 24-field report, warm sync | −3.80 to −10.29% | −5.56 to −10.53% |
| Repeated 24-field report, warm async API | −6.05 to −7.53% | −5.56 to −10.80% |
| Alternating 24-/3-field report, warm sync | −1.59 to −4.20% | 0 to −0.95% |
| Original short report, warm control | −0.46 to +1.11% | −4.35 to 0% |
| CSV summary, warm control | −8.78 to +0.16% | −5.19 to 0% |
| JSON summary, warm control | −0.78 to +1.88% | flat |

Repeated-wide allocation falls **8.56–8.58% across both APIs**. Alternating and
three unchanged controls are neutral (less than0.02% diagnostic differences).
Desktop elapsed includes adverse/variable observations: old controls up to16.43%
spread, async wide +2.29to+4.93%; these are not controlled CPU results. Quiet-VM
wide sync baseline4.01%/candidate3.01% spread limits precision, while all pairings
and coarse CPU support a workload-specific gain. Alternating elapsed is favorable,
CPU nearly flat; do not predict a universal speedup. CSV control is inconclusive
with8.67% baseline spread. JSON and short-report controls are near baseline; no
demonstrated material new debt. Earlier independent debts remain separate.

The [initial construction prototype](../2026-11-08-json-record-capacity-initial/README.md)
reserved the full hint at startup: wide allocation−11%, alternating **+14.7%**,
controlled alternating elapsed **+4.31to+10.82%**. One bounded refinement moved the
same decision to actual growth; that regression does not recur here. Initial source,
binaries, all adverse results and failed fixture/build conditions are preserved.
No unchanged favorable retiming or fixed-percentage acceptance rule.

The hint remains conservative. A shorter ordered prefix keeps its initial backing;
a narrower prefix that does grow may reserve spare layout slots or be denied
earlier. Existing shape promotion remains available; every retained capacity and
replacement overlap stays funded. Refusal is terminal, with no smaller-buffer retry.

Both affected scripts use the unchanged complete report source and3072 original
rows, adding21 unused numeric fields to all rows or alternating rows. Complete
formatting/output is retained, with independently generated CPython3.13 full
stdout/file goldens. Three report/CSV/JSON controls are byte-identical to the old
catalog. New fixture bytes/hashes are archived; no CPython timing claim for them.

Same worker7cf37ca5/optional0.4, Ubuntu24.04.4/AzureF4as_v7/four EPYC9V45vCPUs/
16GiB/no swap/.NET11 RC3, normalGC/tiering. Five-second warmup per role/job,
two independent processes/core, seven rotated150msrounds. Six jobs170.447s.
Warm command-v2 includes execution, mediated RAM I/O, full validation and prior
result cleanup. Compilation/startup/staging/final cached teardown excluded.
Local allocation includes host reset/full validation/cleanup; its clocks measure
Run only. No startup/RSS/embedding-tail/pending-I/O or new external-ratio claim.

All source/core/aux/Ready/golden/quiet/Closed/exit/join/fixture/archive/local gates
pass. B469 is terminal; users joined and owned RAM unmounted before archive.
Initial disk preflight refused before a root/service/worker was created. Prior
wide raw+archive plus50% headroom now fits32MiB above the unchanged240MiBOSfloor.
Fresh exact-byte17-path core hardlinks recovered44736512B, preserving every original
alias/path/content/archive. The same large catalog uses a verified hardlink.
Original refusal/local preparation failures and all proofs remain; no evidence
was deleted, no disk guard relaxed and no timed collection restarted.

[Controlled comparison](controlled-comparison.json), [allocation/local](allocation-and-local.json),
[identity](identity.json), [status](status.json), [source, binary, tests, failures and raw](observations.tar.xz).
''',encoding='utf8')
p=Path('benchmarks/results/2026-11-08-json-record-capacity-initial/README.md');s=p.read_text(encoding='utf8');s=s.replace('Historical initial core `eb144463`','Superseded by the [retained growth refinement](../2026-11-08-json-record-capacity/README.md).\n\nHistorical initial core `eb144463`',1);p.write_text(s,encoding='utf8')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf8')+'''
## Known-layout record value capacity (2026-11-08)

[Initial R110/B468](results/2026-11-08-json-record-capacity-initial/README.md)
uses full layout capacity at construction: wide allocation−11%, alternating+14.7%
and elapsed+4.31to+10.82%. One [retained refinement/B469](results/2026-11-08-json-record-capacity/README.md)
moves the existing capacity decision to actual ordered-prefix growth, removing
intermediate arrays without a new owner/cache/predictor/policy. Eight-record full
report replacement admissions21→7, initial reservations unchanged.897public/
193internal peractual11/10 pass, independent full Python shapes/order plus actual
async/cancellation/refusal/shared/retained ownership checks. Wide allocation−8.56–8.58%
both APIs; controlled elapsed−3.80to−10.29%sync/−6.05to−7.53%async, coarseCPU supports.
Alternating regression does not recur; allocation neutral, elapsed−1.59to−4.20%,
CPUnearflat. CSVcontrol8.67%baseline spread inconclusive, JSON/shortreport nearbaseline.
All original/adverse/desktop conditions preserved; no unrelated debt repayment.
170.447s/sixjobs/all gates/archive/local pass, no users/fixtures. Initial disk
preflight stopped before workers; actual wide evidence footprint+50% now uses32MiB
headroom with unchanged240MiBfloor, exact-byte hardlinks preserve all evidence.
Exact retained-source full delivery pending independently; primary CPython guide
continues to name726. Publication/regex unchanged; broader objective stays active.
''';p.write_text(s,encoding='utf8')
p=Path('docs/BENCHMARKS.md');s=p.read_text(encoding='utf8');needle='| Native acyclic helper returns';a=s.index(needle);s=s[:a]+'| Known-layout record value growth / wide JSON report | Allocation −8.6% both APIs; controlled elapsed −4–10% sync/−6–8% async, coarse CPU supports | New 24-field fixtures; alternating records neutral allocation, ordinary controls uncertain. Full qualification pending. [R110](../benchmarks/results/2026-11-08-json-record-capacity/README.md) |\n'+s[a:];p.write_text(s,encoding='utf8')
print('Retained refined R110:',json.dumps(status,indent=2))
