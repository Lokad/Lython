from pathlib import Path
import hashlib,json,os,re,shutil,subprocess
r=Path(__file__).parent;old=r.parent;b=json.loads((old/'baseline.json').read_text(encoding='utf8'))
sources={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in b['productionSources']}
assert {p for p,h in sources.items()if h!=b['productionSources'][p]}=={'src/Lokad.Lython/Runtime/PyDict.Records.cs'}
counts={}
for name in ['public11','public10','internal11','internal10']:
 s=(r/(name+'.log')).read_text(encoding='utf8');m=re.search(r'Passed!.*Failed:\s+0, Passed:\s+(\d+),',s);assert m;counts[name]=int(m[1])
copies=[Path(p)/'Lokad.Lython.dll'for p in ['src/Lokad.Lython/bin/Release/net11.0','tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0','tests/Lokad.Lython.Tests/bin/Release/net11.0']]
assert len({hashlib.sha256(p.read_bytes()).hexdigest()for p in copies})==1
images=r/'images';images.mkdir()
for role in ['before','candidate']:shutil.copytree(old/'images/before',images/role,copy_function=os.link)
core=images/'candidate/Lokad.Lython.dll';core.unlink();shutil.copyfile(copies[0],core)
identity=dict(baselineSource='Fully qualified7265538c/core1aa68ce9, cached CI42496463028',candidateSource='dea4504d plus shared ordered-record value-growth sizing; initial JSON construction seeding restored exactly',coreSHA256={role:hashlib.sha256((images/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']},productionSources=sources,focusedChecks=counts,qualification='897public/193internal peractual11/10 pass; exact-source full qualification pending independently.',controls='Same initial five-case catalog/six-job matrix, normal worker/host/optional0.4/settings; no new frontend measurement.')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf8')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython/Runtime/PyDict.Records.cs']))
for name in ['catalog.json','growth-catalog.json']:shutil.copyfile(old/name,r/name)
shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
tool=r/'growth-tool';shutil.copytree(old/'growth-tool/out',tool,copy_function=os.link);p=tool/'Lokad.Lython.dll';p.unlink();shutil.copyfile(core,p)
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+';'+env['PATH']
with(r/'growth.json').open('w',encoding='utf8')as output:subprocess.run([env['DOTNET_HOST_PATH'],str(tool/'growth.dll'),str(images/'candidate'),str(r/'growth-catalog.json')],env=env,stdout=output,check=True)
proof=json.loads((r/'growth.json').read_text(encoding='utf8'));assert proof['fullGoldensPassed']and proof['balance']==0 and len(proof['growthAdmissions'])==7 and proof['recordAdmissions']==[512]*7
assert proof['coreSHA256']==identity['coreSHA256']['candidate']
for name in ['measure.py','assess-local.py']:
 s=(old/name).read_text(encoding='utf8')
 if name=='measure.py':s=s.replace("old=r.parent/'integer-utf8-r45'","old=r.parents[1]/'integer-utf8-r45'")
 else:s=s.replace('R110 existing','Refined R110 existing')
 (r/name).write_text(s,encoding='utf8')
print('Refined R110 frozen',identity['coreSHA256'],counts,'growth admissions21->7; initial seeding unchanged.',flush=True)
