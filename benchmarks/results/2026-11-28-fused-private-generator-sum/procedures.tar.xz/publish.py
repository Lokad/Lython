from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import tarfile

lab = Path(__file__).resolve().parent
out = lab.parents[3] / 'benchmarks/results/2026-11-28-fused-private-generator-sum'
pair = lab / 'comparison'
quiet = pair / 'quiet'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()

identity = read(quiet / 'identity.json')
assert identity['sourcePatchSHA256'] == digest(lab / 'candidate.patch')
assert identity['imageFiles'] == read(pair / 'identity.json')['imageFiles']
for role, files in identity['imageFiles'].items():
    assert {path.name: digest(path) for path in (pair / role).iterdir()} == files
    assert read(pair / f'{role}-verify.json')['caseCount'] == 5
summary = read(quiet / 'summary.json')
assert summary['verifiedTimedBatches'] == 84 and summary['quietGates']
receipt = read(quiet / 'archive-receipt.json')
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
assert receipt['archiveSHA256'] == digest(quiet / 'observations.tar.xz')

allocation = read(lab / 'allocation/summary.json')
admission = read(lab / 'admission/summary.json')
assert len(allocation) == len(admission) == 10
assert all(row['compiled'][0] == row['compiled'][1] for row in allocation)
assert all(row['requests'][0] == row['requests'][1] for row in admission)
for row in allocation:
    matched = next(item for item in admission if item['case'] == row['case'] and item['asynchronous'] == (row['mode'] == 'async'))
    assert matched['peak'] == row['admittedPeak']
    first, last = row['clr']
    if 'explicit' in row['case']:
        assert abs(first - last) <= 12
    elif 'retained' in row['case']:
        assert 22_000 < first - last < 23_000
    else:
        assert 360_000 < first - last < 361_000
for target in ('windows-net10.0', 'windows-net11.0', 'ubuntu-net11.0'):
    for suite, count in (('public', 411), ('whitebox', 41)):
        log = lab / f'{target}-{suite}.log'
        assert f'Passed: {count:5d}' in log.read_text(encoding='utf-8')
        assert 'Failed:     0' in log.read_text(encoding='utf-8')

out.mkdir(exist_ok=True)
public = {name: quiet / name for name in ('identity.json', 'summary.json', 'observations.tar.xz', 'terminal-status.json')}
public.update({f'{name}-summary.json': lab / name / 'summary.json' for name in ('allocation', 'admission')})
for name, path in public.items():
    copy2(path, out / name)
    assert digest(out / name) == digest(path)

procedures = {path.name: path for path in lab.iterdir() if path.is_file()
    and path.suffix in ('.log', '.py', '.patch', '.sh') and path.name not in ('summarize.py',)
    and not path.name.endswith(('PublicApi.Tests.log', '-Tests.log'))}
for root in (pair, quiet):
    location = 'local' if root == pair else 'quiet'
    procedures.update({f'{location}/{path.name}': path for path in root.iterdir() if path.name.endswith('-verify.json')})
for kind in ('allocation', 'admission'):
    procedures.update({f'{kind}/{path.name}': path for path in (lab / kind).glob('*.json')})
for name in ('archive-receipt.json', 'stage-custody.json', 'launch.log'):
    procedures[f'quiet/{name}'] = quiet / name
with tarfile.open(out / 'procedures.tar.xz', 'w:xz') as archive:
    for name, path in procedures.items():
        archive.add(path, arcname=name)
with tarfile.open(out / 'procedures.tar.xz') as archive:
    for name, path in procedures.items():
        assert sha256(archive.extractfile(name).read()).hexdigest() == digest(path)
print('Verified allocation, admission, six focused suites, two 32-file images and 84 quiet batches.')