from hashlib import sha256
from pathlib import Path
from shutil import copy2, copytree
from subprocess import check_output
import json

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.parent / 'sequence-slot-generator-b1969-20261128/comparison'
profile = lab.parent / 'current-generator-profile-b1971-20261128'
baseline = profile / 'comparison/quiet'
pair = lab / 'comparison'
core = 'Lokad.Lython.dll'
build = lab / 'ubuntu-artifacts/bin/Lokad.Lython/release_net11.0' / core
read = lambda path: json.loads(path.read_bytes())
digest = lambda data: sha256(data).hexdigest()
hash_file = lambda path: digest(path.read_bytes())
hashes = lambda directory: {path.name: hash_file(path) for path in directory.iterdir()}


def git(*args):
    return check_output(['git', *args], cwd=repo)


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')


old = read(profile / 'attribution/profile/identity.json')
reference = old['sourceRevision']
head = git('rev-parse', 'HEAD').decode().strip()
assert reference.startswith('6ae6f2fa8') and head.startswith('3bc32973a')
assert not git('diff', reference, head, '--', 'src', 'tests', 'Directory.Build.props', 'Directory.Packages.props')
assert not git('ls-files', '--others', '--exclude-standard', '--', 'src', 'tests')
patch = git('diff', '--binary', reference, '--', 'src', 'tests')
assert patch.count(b'diff --git ') >= 4
(lab / 'candidate.patch').write_bytes(patch)

frozen = old['imageFiles']['candidate']
assert len(frozen) == 32 and hashes(baseline / 'local-image') == frozen
pair.mkdir()
for role in ('reference', 'candidate'):
    copytree(baseline / 'local-image', pair / role)
copy2(build, pair / 'candidate' / core)
assert not (pair / 'candidate' / core).samefile(build)
images = {role: hashes(pair / role) for role in ('reference', 'candidate')}
assert images['reference'] == frozen
assert {name for name in frozen if frozen[name] != images['candidate'][name]} == {core}

catalog_path = prior / 'representative.json'
prior_manifest = read(prior / 'identity.json')
assert hash_file(catalog_path) == prior_manifest['catalogs'][catalog_path.name]['sha256']
catalog = read(catalog_path)
tuple_id = 'diagnostic.shipment-row-generator-reduction'
list_id = 'diagnostic.shipment-row-list-generator-reduction'
control_id = 'diagnostic.shipment-row-explicit-reduction'
control = next(case for case in read(baseline / 'representative.json')['cases'] if case['id'] == control_id)
assert control['expectedOutput'] == catalog['cases'][0]['expectedOutput']
assert control['fixtureSha256'] == catalog['cases'][0]['fixtureSha256']
catalog['cases'].append(control)
save(pair / 'representative.json', catalog)
save(pair / 'jobs.json', {'warm': [[case, 'warm-async'] for case in (tuple_id, list_id, control_id)]})
for name in ('cpython-worker.py', 'collect.py', 'run.sh'):
    copy2(prior / name, pair / name)
assert hash_file(pair / 'cpython-worker.py') == prior_manifest['cpythonWorkerSHA256']
assert b'\r' not in (pair / 'run.sh').read_bytes()
save(pair / 'identity.json', dict(sourceRevision=head, referenceRevision=reference,
    sourcePatchSHA256=digest(patch), imageFiles=images,
    coreSHA256={role + suffix: image[core] for role, image in images.items() for suffix in ('', '-control')},
    expectedCPythonSHA256=prior_manifest['expectedCPythonSHA256'], cpythonWorkerSHA256=prior_manifest['cpythonWorkerSHA256'],
    catalogs={name: {'sha256': hash_file(pair / name)} for name in ('representative.json', 'jobs.json')},
    purpose='Compare stack-local private sum reduction against operand handoff. The explicit loop controls for dispatch effects.'))
print('Froze exact 32-file images and five CPython goldens.')