#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-notes/review-20261031/fused-private-sum-b1972-20261128/attribution/profile
unset DOTNET_BUNDLE_EXTRACT_BASE_DIR
export DOTNET_ROOT="$HOME/.dotnet"
bash run.sh
for role in generator-async explicit-async; do
  "$HOME/.dotnet/tools/dotnet-trace" convert "$role/run.nettrace" --format Speedscope
done
python3 analyze-managed.py