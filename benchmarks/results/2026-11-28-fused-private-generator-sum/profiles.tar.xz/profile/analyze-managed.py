from collections import Counter
from pathlib import Path
import json


ROOT = Path(__file__).resolve().parent
ROLES = ('generator-async', 'explicit-async')
REGIONS = {'ordinary map': ('PyMapIterator',), 'generator construction': ('PyGenerator+<CreateExpressionAsync>', 'PyGenerator.CreateExpressionAsync', 'PyGeneratorFunction.CreateBoundGenerator'), 'generator advancement': ('PyGenerator.Advance', 'PyGenerator+<AdvanceFrameAsync>'), 'generator exception/stack entry': ('PyGenerator.EnterFrame', 'ResumeGeneratorException', 'EnterInterpreterFrame', 'EnterFunctionCall'), 'generator outer iteration': ('AcquireGeneratorOuter', 'ExecutableValueStorage.TryPrepareNativeIteration'), 'callback entry': ('StartIterationCallback', 'TryStartPositionalCallback', 'StartInline'), 'argument binding/storage': ('BindFunctionArgumentsInto', 'RentFunctionArgumentStorage', 'ReturnBoundArguments'), 'sum calls': ('<SumAsync>', 'SumBuiltin'), 'closure charge': ('ChargeClosureRetention',), 'numeric reduction': ('SumState', 'SumBuiltin', 'SumCore', 'DrainGeneratorForSum', 'TryAppendBufferedYield'), 'native arithmetic': ('TryExecuteBuiltinArithmetic', 'TryEvaluateBuiltinArithmetic', 'TryExecuteNativeCall'), 'subscript and dictionary': ('Subscript', 'PyDict.TryGetValue', 'TryReadNative'), 'memory reservation': ('MemoryGovernor.Reserve', 'MemoryGovernor.ReserveTemporary'), 'memory refund': ('MemoryGovernor.Release',), 'CSV record': ('CsvRecordParser', 'CsvDictReader'), 'mediated text file': ('OpenedByteFile', 'TextFileHandle', 'ChunkedTextFileReadState'), 'async iterator move': ('ExecuteForNextAsync',), 'generator frame setup': ('InitializeGeneratorExecution', 'InitializeFreshOwned', 'DetachGeneratorExecution', 'SeedGeneratorOuter', 'ReleaseGeneratorTemporaries'), 'starmap row': ('PyStarmapIterator',), 'instruction prefix': ('ExecuteInstructionPrefix', 'RunNativePrefix', 'NativeExecution.Run')}

REGIONS.update({
    'borrowed operand preparation': ('PreparePrivateGenerator',),
    'borrowed generator prefix': ('RunPrivateGeneratorPrefix',),
    'borrowed generator reduction': ('ExecutePreparedGeneratorSum',),
    'parent callback binding': ('TryStartPositionalCallback', 'StartBorrowedInvocation', 'StartInline'),
    'executable frame construction': ('InitializeExecutableWorkState', 'InitializeExecutableFrame', 'EnterInvocationFrame'),
    'short yield accumulation': ('TryAddBorrowedInteger', 'TryAccumulateSumInteger'),
    'record cell reads': ('TryReadRecordValue', 'TryExecuteClosureArithmetic', 'TryExecuteSequenceIndex'),
    'CSV row construction': ('CreateRecordRow', 'BuildRecord', 'AdoptRecord', 'ReadRow'),
})

WAIT_FRAMES = ('WaitSubsystem+ThreadWaitInfo.Wait', 'LowLevelThreadBlocker.TimedWait', 'PollGCWorker', 'SynchronousWorkItem.Wait')


def analyze(role):
    capture = json.loads((ROOT / role / 'run.speedscope.json').read_bytes())
    frames = [frame['name'].split('(', 1)[0].split('!', 1)[-1] for frame in capture['shared']['frames']]
    nearest = Counter()
    row_nearest = Counter()
    region = Counter()
    runtime = 0
    for profile in capture['profiles']:
        assert profile['unit'] == 'milliseconds' and profile['type'] == 'evented'
        stack = []
        previous = profile['startValue']
        for event in profile['events']:
            elapsed = event['at'] - previous
            active = [frame for frame in stack if frame.startswith(('Lokad.Lython.Runtime.', 'Lokad.Lython.Frontend.', 'Lokad.Lython.LythonEngine', 'Lokad.Lython.Utf8Regex.', 'Lokad.Utf8Regex.'))]
            if elapsed > 0 and active and stack[-1] != 'UNMANAGED_CODE_TIME' and not any(mark in frame for frame in stack for mark in WAIT_FRAMES):
                runtime += elapsed
                nearest[active[-1]] += elapsed
                if any(mark in frame for frame in active for mark in REGIONS['borrowed generator reduction'] + REGIONS['borrowed operand preparation']):
                    row_nearest[active[-1]] += elapsed
                for label, marks in REGIONS.items():
                    if any(mark in frame for frame in active for mark in marks):
                        region[label] += elapsed
            if event['type'] == 'O':
                stack.append(frames[event['frame']])
            else:
                assert stack.pop() == frames[event['frame']]
            previous = event['at']
        assert not stack
    return dict(role=role, runtimeThreadMilliseconds=runtime, inclusiveRegionsMilliseconds=region,
                nearestLythonMethods=nearest.most_common(35), nearestIterableMethods=row_nearest.most_common(35))


rows = [analyze(role) for role in ROLES]
(ROOT / 'managed-attribution.json').write_text(json.dumps(rows, indent=2) + '\n', encoding='utf-8', newline='\n')
for row in rows:
    runtime = row['runtimeThreadMilliseconds']
    print(row['role'], round(runtime, 1))
    for name, elapsed in row['inclusiveRegionsMilliseconds'].most_common():
        print(f'  {100 * elapsed / runtime:5.1f}% {name}')
    for name, elapsed in (row['nearestIterableMethods'] or row['nearestLythonMethods'])[:8]:
        print(f'  {100 * elapsed / runtime:5.1f}% {name}')
