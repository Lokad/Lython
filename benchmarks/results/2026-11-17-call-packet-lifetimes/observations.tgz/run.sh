set -eu
root=/home/lokad/lython-bench-checks/call-packet-lifetimes-b905-20261117
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
