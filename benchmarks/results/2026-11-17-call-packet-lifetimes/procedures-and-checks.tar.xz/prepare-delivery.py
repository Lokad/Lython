from pathlib import Path
import json,subprocess
r=Path(__file__).parent;root=Path('D:/code/Lython')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
(r/'retained-head.json').write_text(json.dumps(dict(head=head))+'\n',encoding='utf-8')
s=(r.parent/'copied-call-ownership-r486/start-delivery.py').read_text(encoding='utf-8').replace('ordinaryInternal=4828','ordinaryInternal=4830')
(r/'start-delivery.py').write_text(s,encoding='utf-8',newline='\n')
print('Dispatch prepared for exact committed head',head)
