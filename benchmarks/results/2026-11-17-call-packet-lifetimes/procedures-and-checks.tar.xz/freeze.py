from pathlib import Path
import copy,hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;notes=r.parent;repo=Path('D:/code/Lython');reference=notes/'utf8-width-r483/refined';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
catalog=json.loads((notes/'generator-sum-r475/catalog.json').read_text(encoding='utf-8'));original=catalog['cases'];case=copy.deepcopy(next(c for c in original if c['id']=='calls.positional.large'))
case.update(id='calls.bound-wide.cleanup', category='bound-copy-ownership-diagnostic', scale='1024-calls', size=1024, source='class Greatest:\n    def __gt__(self, other): return True\nclass C:\n    select = classmethod(max)\nvalue = Greatest()\nselect = C.select\nassert select(value, value, value, value, value, value, value) is value\ntotal = 0\nfor i in range(1024):\n    assert select(value, value, value, value, value, value, value) is value\n    total += 1\nprint(total)\n', fixtureJson='{"size":1024,"text":null}', expectedOutput='1024\n', fixtureTextUtf8Bytes=0, fixtureTextCodePoints=0)
case['sourceUtf8Bytes']=len(case['source'].encode());case['expectedOutputUtf8Bytes']=len(case['expectedOutput'].encode())
for source,key in [('source','sourceSha256'),('fixtureJson','fixtureSha256'),('expectedOutput','expectedOutputSha256')]:case[key]=hashlib.sha256(case[source].encode()).hexdigest()
catalog['cases']=[case,next(c for c in original if c['id']=='scripts.json-summary-helpers.large')];(r/'catalog.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8')
files=json.loads((reference/'frozen/identity.json').read_text(encoding='utf-8'))['imageFiles']['candidate'];frozen=r/'frozen';frozen.mkdir(exist_ok=False)
for role in ['reference','candidate']:
 image=frozen/role;image.mkdir()
 for n,h in files.items():assert sha(reference/'frozen/candidate'/n)==h;shutil.copyfile(reference/'frozen/candidate'/n,image/n)
 if role=='candidate':shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',image/'Lokad.Lython.dll')
 for p in(reference/'frozen/candidate').glob('ValidatedAllocation.*'):shutil.copyfile(p,image/p.name)
images={role:{n:sha(frozen/role/n)for n in files}for role in ['reference','candidate']};assert[n for n in files if images['reference'][n]!=images['candidate'][n]]==['Lokad.Lython.dll']
old=json.loads((reference/'frozen/identity.json').read_text(encoding='utf-8'));inputs={n:sha(repo/n)for n in sorted(list(old['sourceInputs'])+['tests/Lokad.Lython.Tests/CallablePacketOwnershipTests.cs'])};assert len(inputs)==2382
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as a:
 for n in inputs:a.add(repo/n,arcname=n)
with tarfile.open(reference/'candidate-sources.tar.xz')as a:
 changed=[n for n in inputs if n.startswith('src/Lokad.Lython/')and(repo/n).read_text(encoding='utf-8-sig')!=a.extractfile(n).read().decode('utf-8-sig').replace('\r\n','\n')]
assert sorted(changed)==sorted(['src/Lokad.Lython/Runtime/LythonRuntime.Calls.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.Binding.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.Calls.Invoke.cs','src/Lokad.Lython/Runtime/PyBoundMethod.cs']),changed
identity=dict(referenceSource='Qualifieddbdf8262/frozena95ff2a4 GREEN44080812207',candidateSource='R489 ordinary caller-owned scratch through completion; major fresh bound prefixes retained under existing execution/result owner; existing minor packet headroom preserved; correction on00adcc8a',imageFiles=images,sourceInputs=inputs,productionFiles=585,changedProductionFiles=changed,catalogSHA256=sha(r/'catalog.json'),normalAdapterPin='0.4.0',publicationHeld=True)
(frozen/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent));env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
for role in ['reference','candidate']:
 image=frozen/role
 for label,cmd in [('preflight',[str(dotnet),str(image/'Lokad.Lython.Benchmarks.dll'),'--compare','verify','--catalog',str(r/'catalog.json'),'--dotnet',str(dotnet),'--python','C:/Python313/python.exe','--python-worker',str(repo/'benchmarks/cpython-worker.py'),'--out',str(r/(role+'-preflight.json'))]),('allocation',[str(dotnet),str(image/'ValidatedAllocation.dll'),str(image),str(r/'catalog.json'),str(r/(role+'-allocation.json'))])]:
  with(r/(role+'-'+label+'.log')).open('w',encoding='utf-8')as log:p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
  assert p.returncode==0,(r/(role+'-'+label+'.log')).read_text(encoding='utf-8');print(role,label,'pass',flush=True)
print('Final four-file funding-only source and copied32file images/585production/2382inputs verified; candidate',images['candidate']['Lokad.Lython.dll'],flush=True)

