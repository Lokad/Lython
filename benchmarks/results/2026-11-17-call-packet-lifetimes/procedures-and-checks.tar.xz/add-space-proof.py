from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).parent;root=Path('D:/code/Lython');q=r/'quiet'
code="""from pathlib import Path
import fcntl,hashlib,json,os,stat
b=Path('/home/lokad/lython-bench-checks')
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 ps=sorted((p for p in b.glob('*/observations.tgz')if p.lstat().st_size>=524288 and p.lstat().st_uid==os.getuid()and p.lstat().st_nlink==1 and stat.S_ISREG(p.lstat().st_mode)),key=lambda p:p.stat().st_size)
 print(json.dumps([dict(path=str(p.relative_to(b)),bytes=p.stat().st_size,links=p.stat().st_nlink,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in ps[:3]]))
"""
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,check=True,timeout=45)
(r/'fresh-archive-candidates.json').write_text(p.stdout,encoding='utf-8')
choice=None
for item in json.loads(p.stdout):
 matches=[p for p in(root/'benchmarks/results').rglob('observations.tgz')if p.stat().st_size==item['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']]
 if len(matches)==1:choice=item;canonical=matches[0].relative_to(root).as_posix();break
assert choice is not None,p.stdout
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=root);assert blob==(root/canonical).read_bytes()
c=json.loads((q/'config.json').read_text(encoding='utf-8'))
c['retireGroups'].append(dict(paths=[choice['path']],bytes=choice['bytes'],links=choice['links'],sha256=choice['sha256'],canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='whole-archive',committedBlobVerified=True))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(q/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:]
(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
print('Additional fresh exact committed-replica proof:',choice['path'],choice['bytes'],canonical,flush=True)
