from pathlib import Path
Path('D:/code/Lython/PLAN.md').write_text('''# Lokad.Lython 0.11.0

Updated 2026-11-17 UTC. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance,
including compile-once/run-once inside a warm host. An isolated experiment does
not finish the objective. Current contracts: docs/. History: benchmarks/EXPERIMENTS.md.

## Delivery status

| State | Actual delivery and remaining limits |
| --- | --- |
| Committed / fully qualified | Shared compiler-fact/callback correction61237f58 and native helper returns8f07764a. Allocation−19–20%; original elapsed gains remain diagnostic. No unchanged qualification pending. |
| Committed / fully qualified | Direct UTF-8 formatting/storage: allocation−8.67%; controlled report elapsed/CPU5–8%lower supports retention. Original adverse15.125ms remains preserved/unexplained. |
| Committed / fully qualified | Prepared binding/direct operands, executable generators, shared builtin metadata/reused async workers, UTF-8 backing/casing, sequence constructionR460, receiver pipelineccf20ba3, floating transportdc480d38, generator-sum lifetimeabcbd9fd, unary result transportd8611c85. |
| Latest fully qualified runtime | Bulk UTF-8 scalar/UTF16 widthsdbdf8262/frozena95ff2a4. GREEN44080812207: Windows/Ubuntu actual11/10, original stress and installed Release consumers;16summaries/2381inputs/585production verified. Commits through9d9fd1e9 then only change evidence/docs. |
| Committed / failed delivery | f2cb4008/frozen384327c2 cleared retainable bound prefixes: failed44091209377. Subsequent00adcc8a/frozen6c808cd8 universally retained ordinary packets: failed44098253722,25internal/2public each platform. Both sources/logs/adverse measurements preserved. Neither is qualified. |
| Active correction / focused validated | R489/frozendfc4c83c: ordinary caller-owned scratch restored; fresh major bound prefixes retained under execution/result owner. Final nonincremental build; actual11/10each all4830nonstressinternal +200focusedpublic pass, existing regressions unchanged. Actual copied32file goldens/allocation reuse pass. Final affected comparison/full delivery pending. |
| Active isolated prototype / held | R488 uses System.Threading.Lock for the private default allowance gate. Actual11/10each56internal/76public pass on00ad baseline, which is now known invalid. No promotion/timing until R489 closes; no replacement memory policy or capacity cache. |
| Withdrawn / no dormant alternative | R469JSON scan,R470call operands,R473module metadata,R474subscript entry,R479global binding,R481caller windows,R485wider binding view. Independent regressions survive. |
| Independent regex | Core Python/native UTF-8 contract delivered; immutabledev105 focused checks complete. Normal optional/non-packable adapter0.4.0. Missing producer capabilities postpone affected final adapter qualification only. |

[Completed delivery](benchmarks/results/2026-11-17-utf8-widths/refined/delivery/README.md),
[first call failure](benchmarks/results/2026-11-17-call-copy-ownership/delivery-first-failure/README.md),
[second call failure](benchmarks/results/2026-11-17-owned-call-contract/delivery-failure/README.md),
[experimental history](benchmarks/EXPERIMENTS.md).

## First: close R489's two real packet lifetimes

The general array entry is caller-owned through completion, not universal ownership
transfer. Ordinary copied/wide packets retain references/admission through actual
asynchronous users and cleanup, then clear/refund. Prepared constructors retain
this scratch through their stages; existing initializer code copies real escapes.
Small packets use existing minor control headroom. Fresh non-function bound-method
receiver prefixes may be retained: major capacity is admitted before copying and
kept with the execution/result owner after success, fault or cancellation.

Keep exact Python behavior and first-refusal terminality. Conservative retention
of fresh bound prefixes can deny earlier; ordinary cache hits/caught invalid
factories must remain bounded. No new owner layer, tracing, per-object ledger,
retry, fallback or hidden allowance. Keep the real borrowed-completion wrapper;
remove blanket retained-copy allocation from ordinary entry and unnecessary
bound-prefix pending-owner flags. Do not revive the R485 view/bridge.

Acceptance: unchanged existing retention, packet-clear, scratch/refund, cache-hit,
factory-failure, constructor, alias and admission-order regressions. Six independent
copy cases cover major refusal before effects, pending cleanup, temporary refunds,
retained bound storage and owner-end reuse. Delete only new tests imposing the
discarded universal-retention/exact-small-admission architecture. Both actual targets
pass all4830internal and200focusedpublic; no existing failing assertion relaxed.

One short final-source bound-wide warm/fresh pair + complete JSON-lines control;
separate allocation/retained peak/CPU/elapsed. Prior B903/B904 describe failed
sources only. Then one corrected Windows/Ubuntu actual11/10, original stress and
installed explicit Release package checkpoint. Preserve both failed source inputs,
logs and stage-floor conditions; do not replay unchanged R483 qualification.

## Continue the substantial redesign roadmap

| Deliverable / scripts | Work/storage removed, semantic acceptance and bounded decision |
| --- | --- |
| Complete call/frame/operand transport: numeric helpers, search, reports | Normal helpers already borrow/defer frames and fused locals carry slots. R485 still built packet entries per read, widening the ABI without substantial benefit. Identify a whole remaining stage to remove and its displaced binder/frame/transport code. Preserve defaults/keywords/cells/identity/effect/error order and real suspension without replay. Name scripts/control before prototype; no renamed arenas/controllers/windows. |
| Per-record construction: CSV/JSON aggregates, manifests | Earlier6–8%CSV work is integrated as aggregate admission/shared keys/final rows; R482 confirms funded-row adoption. JSON already shares cross-load layouts/default options and iterates construction. Revised storage must displace real work without a duplicate cache; preserve duplicate/short/wide rows, hooks, aliases, replacement peaks and terminal refusal. One controlled whole-script pair before retention. |
| Scalar/text publication: normalization, numeric reports | R483 removes scalar-width walking; R471/R477 remove boxing boundaries. Mutable slots need canonical aliases under withdrawal/mutation and displace direct-array adoption. Text reads already share immutable UTF-8 windows. Select actual conversions/storage removed; preserve Unicode/arithmetic/hooks/cancellation/ownership. No universal tagged values or identity ledger from allocation estimates alone. |
| Frontend/setup: generated configuration/helper scripts | Shared binding facts/prepared metadata already exist. Compilation is not the dominant measured gap. Prove repeated analysis/retention before consolidation, remove displaced passes/representations, preserve spans/classes/cells/lazy annotations and admitted/cancellable compile-to-result. Heavyweight JIT remains lower confidence. |

R488 reuses R484's986samples/60unknown, with no new capture. Raw nearest instruction
prefix147 has zero visible helper activations; total visible helper52. Counts do
not identify an exclusive frame-construction share. Monitor enter/exit66leaves,
57 beneath Reserve, identify real shared-allowance synchronization cost. Existing
governor/default-budget sources match measured qualifieda95. The isolated typed-lock
prototype removes compiler Monitor entry/exit without new accounting/cache state.
Preserve shared execution/concurrency/reentry/disposal, exact admission/refunds,
cancellation and terminal refusal. After baseline correction, use complete JSON,
CSV and text with controls; decide source simplicity + measured result. This
bounded refinement does not replace the substantial roadmap or finish the objective.

R484 source corrections: spans are shared references; JSON scalar conversion is
already synchronous; layouts persist across loads. R469 bulk delimiter scanning
regressed JSON fresh with close controls; another same-shape scanner removes no
new stage. Structural guard context is ThreadStatic with throttled checks, not
an established per-character full checkpoint cost. Preserve all original evidence.

Every selected redesign records hypothesis, eliminated implementation, complete
scripts, semantic/cancellation/ownership acceptance and a bounded source pair with
unchanged controls. Temporary setbacks require an explicit completion milestone
and regression-debt decision. Close investigations with a design decision or named
remaining uncertainty; no broad ownership audit or open-ended capture campaign.

## Measurement gaps and debt

CPython is primary; source labels never automatically mean HEAD. R483 text:
warm1.75–1.81×,fresh1.66–1.67×,compile0.94–0.96× versus3.13.16 (warm CPython
controls3.40%). R477numeric CSV: warm0.89–0.92×,fresh0.92–0.95×,compile1.25–1.27×.
R475floating JSON: warm1.95–2.00×,fresh1.83–1.88×. Refresh affected JSON-lines
compile/warm/fresh at the next retained coherent checkpoint; state included
mediated I/O, goldens and prior-result cleanup. Phase medians are not additive;
cross-collection ratios are not causal gains. [Guide/boundaries](docs/BENCHMARKS.md).

Retain R471integer regression, R460tuple peak+11.81%/asyncCSV+0.1–3.6%, R481
corrected helper/text regressions and withdrawn R485 mixed results. R483 first
CountAny dense+28%elapsed/+23%CPU was removed; refined ASCII/dense reference
movement7.17/6.77% limits magnitude. Failed R487's synthetic retained-peak and CPU
cost remains historical; no corrected-source gain/cost is inferred from it.

Moving controls, timeouts and inconclusive results establish uncertainty, not
failed designs. Allow bounded justified confirmation/refinement/measurement repair;
preserve original failed/adverse conditions. Distinguish architectural simplification,
allocation reduction and demonstrated CPU improvement. Percentages inform decisions,
never automatically veto a coherent useful change.

## Independent regex

Continue the core-owned Python UTF-8 contract: original-subject byte ranges/scalar
windows, flags/names/captures/effective frontend analysis, explicit owners and
current tokens through actual provider/import/helper work. No core backend types
or dialect fallback. Development producers/adapter bridges support implementation;
distinguish contract tests, semantics and actual backend performance.

Read-only sibling0bd59e18 retires backend shortcuts/overlays; its facade diff adds
none of the missing capabilities: UTF-8 group-name enumeration, creation/preparation
token lifetime independent of retained cursors, separately funded per-match staging.
Keep detached later-pull bridge; effective flags do not replace initial Verbose
parsing. No pin change/unchanged requalification for unrelated changes. Qualify a
changed immutable final package for semantics/windows/errors/flags, actual in-flight
interruption/unwind, aliases/reuse/dependencies and one affected pair. Only affected
final adapter qualification waits on publication.

## Delivery and lasting constraints

Focused Release checks while iterating; batch full platform/stress/installed-package
at meaningful retained boundaries. Cache terminal/logs; live CI observations≥240s.
Never requery terminal44080812207,44050323147,44041981387,44022750002,44072440304,
failed44067803913/44091209377/44098253722. Publication/tagging held.

[AGENTS](AGENTS.md)/[RUNTIME](docs/RUNTIME.md) bind all work: fully managed and
memory-safe; no unsafe/Unsafe/pointers/PInvoke/native probing. Preserve managed
stack, host capabilities, cancellation, shared borrowed admission, overlap and
retained aliases/caches/pending users through awaited cleanup. First refusal
terminal. No fuel/quotas/hidden caps/allowances/tracing/weak reclamation/forced GC/
abandoned work. Bounded host-driven streaming remains.

Freeze copied complete images after nonincremental builds; verify actual catalog
workers before staging. Join/SHA-archive RAM before unmount. Retire only exact
committed replicas with fresh lease/path/UID/hash/link/all-alias proof; preserve
qualified images/toolchains/canonicals and254/252MiB floors. Quiet VM:
lokad@20.166.121.73,~/.ssh/id_lython-bench.pem. Only core Release packages through
pack.ps1 into artifacts/nuget/; adapter stays non-packable.
''',encoding='utf-8',newline='\n')
