from pathlib import Path
r=Path(__file__).parent;old=r.parent/'copied-call-contract-r487'
s=(old/'freeze.py').read_text(encoding='utf-8').replace('R487 owned callable arrays retained under existing execution/result owner; borrowed wide scratch reclaimed after actual completion; correction onf2cb4008','R489 ordinary caller-owned scratch through completion; major fresh bound prefixes retained under existing execution/result owner; existing minor packet headroom preserved; correction on00adcc8a')
(r/'freeze.py').write_text(s,encoding='utf-8',newline='\n')
