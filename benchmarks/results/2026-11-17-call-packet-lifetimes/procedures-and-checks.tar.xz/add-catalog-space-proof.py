from pathlib import Path
import hashlib,io,json,subprocess,tarfile
r=Path(__file__).parent;root=Path('D:/code/Lython');q=r/'quiet'
canonical='benchmarks/results/2026-11-17-borrowed-binding/observations.tgz'
archive_blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=root)
assert archive_blob==(root/canonical).read_bytes()
with tarfile.open(fileobj=io.BytesIO(archive_blob))as archive:blob=archive.extractfile('representative.json').read()
relative='borrowed-binding-b902-20261117/representative.json';digest=hashlib.sha256(blob).hexdigest()
code="""from pathlib import Path
import fcntl,hashlib,json,os,stat
b=Path('/home/lokad/lython-bench-checks');p=b/RELATIVE
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 m=p.lstat();assert p.resolve()==p and stat.S_ISREG(m.st_mode)and m.st_uid==os.getuid()
 assert m.st_size==SIZE and hashlib.sha256(p.read_bytes()).hexdigest()==DIGEST
 aliases=[]
 for base,dirs,names in os.walk(b):
  for name in names:
   target=Path(base)/name;v=target.lstat()
   if(v.st_dev,v.st_ino)==(m.st_dev,m.st_ino):aliases.append(str(target.relative_to(b)))
 assert len(aliases)==m.st_nlink
 print(json.dumps(dict(paths=aliases,bytes=m.st_size,links=m.st_nlink,sha256=DIGEST)))
""".replace('RELATIVE',repr(relative)).replace('SIZE',str(len(blob))).replace('DIGEST',repr(digest))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=45);assert p.returncode==0,p.stdout+p.stderr
proof=json.loads(p.stdout)|dict(canonical=canonical,canonicalSHA256=hashlib.sha256(archive_blob).hexdigest(),member='representative.json',committedBlobVerified=True)
c=json.loads((q/'config.json').read_text(encoding='utf-8'));c['retireGroups'].append(proof)
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(q/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:]
(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
print('Exact committed withdrawn catalog:',proof,flush=True)
