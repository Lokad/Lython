from pathlib import Path
import json,os,subprocess,time
r=Path(__file__).parent;r.mkdir(exist_ok=True);root=Path('D:/code/Lython')
dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent));env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
commands=[('build',[str(dotnet),'build','Lokad.Lython.slnx','-c','Release','--no-incremental'])]
for framework in ['net11.0','net10.0']:
 commands.append(('internal-'+framework,[str(dotnet),'test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f',framework,'--no-build','--logger','console;verbosity=minimal']))
 classes=['CacheKeyAccountingScenarioTests','DataclassOwnershipContractTests','GovernedMemoryContractTests','AdmissionFailureCommandTests','AsyncInvocationOwnershipTests','ConstructorLifetimeTests','OrdinaryFunctionCallTests','NativeCallbackArgumentsTests','NativeCallbackUnwindTests','WrapperOwnershipLifetimeTests','RepresentativeProtocolCancellationTests']
 filt='('+'|'.join('FullyQualifiedName~'+c for c in classes)+')&Category!=Stress'
 commands.append(('public-'+framework,[str(dotnet),'test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f',framework,'--no-build','--filter',filt,'--logger','console;verbosity=minimal']))
records=[]
for name,command in commands:
 start=time.monotonic()
 with(r/(name+'.log')).open('w',encoding='utf-8')as log:p=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 records.append(dict(name=name,command=command,exitCode=p.returncode,seconds=time.monotonic()-start))
 (r/'checks.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n')
 output=(r/(name+'.log')).read_text(encoding='utf-8');print(name,output.splitlines()[-1],flush=True);assert p.returncode==0,output[-10000:]
