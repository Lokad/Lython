from pathlib import Path
import ast
r=Path(__file__).parent;old=r.parent/'copied-call-contract-r487'
s=(old/'prepare-quiet.py').read_text(encoding='utf-8').replace("old=notes/'copied-call-ownership-r486'","old=notes/'copied-call-contract-r487'")
s=s.replace('benchmarks/results/2026-11-17-call-copy-ownership/candidate-core.dll.gz','benchmarks/results/2026-11-17-owned-call-contract/candidate-core.dll.gz')
a=s.index('for canonical,prefix,members in ');b=s.index(':\n blob=',a)
s=s[:a]+"for canonical,prefix,members in [('benchmarks/results/2026-11-17-owned-call-contract/observations.tgz','owned-call-contract-b904-20261117',['confirmation/confirmation.json','whole-archive'])]"+s[b:]
s=s.replace("remote='/home/lokad/lython-bench-checks/owned-call-contract-b904-20261117'","remote='/home/lokad/lython-bench-checks/call-packet-lifetimes-b905-20261117'")
s=s.replace("unit='lython-b904-owned-call-contract-20261117'","unit='lython-b905-call-packet-lifetimes-20261117'")
s=s.replace("'lython-b903-fixtures','lython-b904-fixtures'","'lython-b904-fixtures','lython-b905-fixtures'")
s=s.replace('FailedR486384327c2','FailedR4876c808cd8').replace('Four-fileR487onf2cb4008','Four-fileR489on00adcc8a').replace('R487 owned callable contract','R489 caller scratch and retained bound prefixes')
s=s.replace('Owned callable copies retained under execution/result owner; actual borrowed wide scratch clears/refunds after completion. First R486 failure preserved. Existing retainability plus10 focused ownership cases.','Caller-owned packets restored through completion; major fresh bound receiver prefixes retain execution ownership. Existing small control headroom preserved. Both failed attempts preserved; all4830original/internal plus6 focused copy cases pass on11/10.')
(r/'prepare-quiet.py').write_text(s,encoding='utf-8',newline='\n');ast.parse(s)
