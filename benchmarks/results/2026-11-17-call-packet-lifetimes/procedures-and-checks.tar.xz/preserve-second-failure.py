from pathlib import Path
import json,shutil
root=Path('D:/code/Lython');prior=Path(__file__).parent.parent/'copied-call-contract-r487';evidence=root/'benchmarks/results/2026-11-17-owned-call-contract';dest=evidence/'delivery-failure';dest.mkdir(exist_ok=False)
terminal=json.loads((prior/'delivery/terminal.json').read_text(encoding='utf-8'));assert terminal['databaseId']==44098253722 and terminal['conclusion']=='failure'
for name in ['terminal.json','inputs.json','inputs.tar.xz','dispatch.json']:
 shutil.copyfile(prior/'delivery'/name,dest/name)
for p in(prior/'delivery').glob('failed-job-*-raw.log'):shutil.copyfile(p,dest/p.name)
(dest/'README.md').write_text('''# Blanket packet retention: failed qualification

CI44098253722 at00adcc8a failed on both platforms:25internal/2public cases each.
The broad ownership inference was wrong. Ordinary packets are caller-owned
scratch through completion; universally retaining them caused real bounded-cache
and caught-invalid-factory failures, plus cleanup/refund regressions. Bound wrappers
separately promise fresh retainable receiver-prefix arrays. Their genuine major
storage needs existing execution ownership; that does not transfer every packet.

Keep all existing failing regressions unchanged. Restore ordinary temporary lifetimes,
prepared-constructor behavior and existing minor packet headroom. Delete only the
new assertions enforcing universal retention/exact-small-admission architecture.
Preserve independent bound retention/major-copy preflight/pending-funding coverage.

Exact committed inputs, terminal status and completed-job logs are cached here.
Never requery this run. No .NET10/stress/package success is claimed. B904 timings
describe6c808cd8 only; they do not qualify the corrected lifetime distinction.
''',encoding='utf-8',newline='\n')
decision=evidence/'decision.json';original=evidence/'first-decision.json';shutil.copyfile(decision,original)
d=json.loads(decision.read_text(encoding='utf-8'));d.update(retain=False,fullDeliveryPending=False,qualification='Failed44098253722,25internal/2public each platform. Ordinary scratch incorrectly retained; cache/factory boundedness and cleanup regressions.',replacement='R489 restores caller-owned temporary packets, prepared constructors and minor headroom; major fresh bound prefixes remain execution-owned. Existing regressions unchanged.')
decision.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n')
p=evidence/'README.md';s=p.read_text(encoding='utf-8');s=s.replace('R487/B904,2026-11-17UTC. Corrects the','**Invalidated by full CI44098253722:**25internal/2public failures on both\nplatforms. Universal retention broke bounded cache hits and ordinary packet\ncleanup. See [failed delivery and contract correction](delivery-failure/README.md).\nThis page and its measurements are historical6c808cd8, not the corrected source.\n\nR487/B904,2026-11-17UTC. Attempted to correct the');p.write_text(s,encoding='utf-8',newline='\n')
print('Second failed source/qualification and all existing failure assertions preserved; no CI query.')
