from hashlib import file_digest
from pathlib import Path, PurePosixPath
import json
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
target_name = 'class-subscription-d170539e-public-api-test-bin'
archive = lab / f'{target_name}.tar.gz'
key = Path.home() / '.ssh/id_lython-bench.pem'
ssh = ['ssh', '-i', str(key), '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=8', 'lokad@20.166.121.73']
remote = r"""
from hashlib import file_digest
from pathlib import Path
import fcntl
import json
import os
import shutil
import subprocess
import sys

base = Path('/home/lokad/lython-bench-checks')
checkout = base / 'class-subscription-d170539e'
target = checkout / 'tests/Lokad.Lython.PublicApi.Tests/bin'
assert target.is_dir() and target.resolve() == target
assert checkout.resolve() == checkout and checkout.parent == base
assert target.stat().st_dev == base.stat().st_dev
command = ['tar', '--sort=name', '--numeric-owner', '-C', str(target.parent), '-czf', '-', target.name]
with (base / 'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    for process in Path('/proc').iterdir():
        if not process.name.isdigit() or process.name == str(os.getpid()):
            continue
        try:
            cwd = (process / 'cwd').readlink()
        except OSError:
            cwd = None
        try:
            commandline = (process / 'cmdline').read_bytes()
        except OSError:
            commandline = b''
        assert cwd is None or not cwd.is_relative_to(checkout), f'Old checkout still in use by {process.name}'
        assert bytes(checkout) not in commandline, f'Old checkout still in use by {process.name}'
    if sys.argv[1] == 'archive':
        subprocess.run(command, check=True)
    else:
        expected = sys.argv[2]
        with subprocess.Popen(command, stdout=subprocess.PIPE) as process:
            assert process.stdout is not None
            observed = file_digest(process.stdout, 'sha256').hexdigest()
            assert process.wait() == 0
        assert observed == expected
        before = shutil.disk_usage(base).free
        shutil.rmtree(target)
        after = shutil.disk_usage(base).free
        assert not target.exists()
        print(json.dumps(dict(archivedDirectory=str(target), archiveSHA256=observed,
                              rootAvailableBefore=before, rootAvailableAfter=after)))
"""
with archive.open('xb') as output:
    subprocess.run([*ssh, 'python3 - archive'], input=remote.encode('utf-8'), stdout=output, check=True, timeout=90)
with archive.open('rb') as downloaded:
    digest = file_digest(downloaded, 'sha256').hexdigest()
with tarfile.open(archive) as bundle:
    contents = bundle.getmembers()
    assert contents and contents[0].name == 'bin' and contents[0].isdir()
    assert len({member.name for member in contents}) == len(contents)
    for member in contents:
        path = PurePosixPath(member.name)
        assert not path.is_absolute() and path.parts[0] == 'bin' and '..' not in path.parts
        assert member.isdir() or member.isfile()
        if member.isfile():
            with bundle.extractfile(member) as content:
                assert content is not None and len(content.read()) == member.size
receipt = subprocess.check_output([*ssh, 'python3 - release ' + digest], input=remote.encode('utf-8'), timeout=90)
status = json.loads(receipt)
assert status['archiveSHA256'] == digest
status.update(archive=archive.name, archiveBytes=archive.stat().st_size, memberCount=len(contents))
(lab / 'recovery.json').write_text(json.dumps(status, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(status, indent=2))
