from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
quiet = lab / 'comparison/quiet'
old = quiet / 'attempt-initial'
state = json.loads((quiet / 'terminal-status.json').read_bytes())
assert not state['live'] and not state['fixtures'] and state['exitCode'] == '1'
assert state['receipt']['warmJobs'] is None
digest = sha256((quiet / 'observations.tar.xz').read_bytes()).hexdigest()
assert digest == state['receipt']['archiveSHA256']
with tarfile.open(quiet / 'observations.tar.xz') as archive:
    gate = json.load(archive.extractfile('confirmation/machine-before.json'))['gate']
assert not gate['quiet'] and gate['reasons'] == ['Idle CPU exceeds three-percent median or five-percent maximum.']
old.mkdir()
for name in ('observations.tar.xz','terminal-status.json','archive-receipt.json','exit-code.txt','launch.log'):
    copy2(quiet / name, old / name)
assert sha256((old / 'observations.tar.xz').read_bytes()).hexdigest() == digest
copy2(lab / 'quiet-vm.py', old / 'quiet-vm.py')

key = Path.home() / '.ssh/id_lython-bench.pem'
ssh = ['ssh', '-i', str(key), '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=8', 'lokad@20.166.121.73']
command = r"""
from hashlib import sha256
from pathlib import Path
import fcntl
import json
import shutil
import subprocess
import sys

base = Path('/home/lokad/lython-bench-checks')
root = base / 'script-cpython-quiet-b1937-20261128'
stage = 'lython-b1937-current-cpython'
digest = lambda p: sha256(p.read_bytes()).hexdigest()
with (base / 'comparison-vm.lock').open('r') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert root.resolve() == root and not (root/'guest-fixtures').exists()
    service = subprocess.check_output(['systemctl','show',stage+'.service','-p','ActiveState,MainPID,Result'],text=True)
    assert all(s in service for s in ('ActiveState=failed','MainPID=0','Result=exit-code'))
    assert digest(root/'observations.tar.xz') == sys.argv[1]
    for name, sha in json.loads((root/'identity.json').read_bytes())['imageFiles']['candidate'].items():
        assert digest(root/'candidate'/name) == sha
    for name, schema in json.loads((root/'identity.json').read_bytes())['catalogs'].items():
        assert digest(root/name) == schema['sha256']
    assert shutil.disk_usage(root).free >= 16*1024*1024
    archive = root/'attempt-initial'
    archive.mkdir()
    for name in ('observations.tar.xz','confirmation','archive-receipt.json','exit-code.txt'):
        (root/name).rename(archive/name)
    assert digest(archive/'observations.tar.xz') == sys.argv[1]
subprocess.run(['sudo','-n','systemd-run','--unit='+stage+'-retry','--property=User=lokad',
    '--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=535','--property=TimeoutStopSec=20',
    '--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
"""
subprocess.run([*ssh, 'python3 - ' + digest], input=command.encode('utf-8'), check=True, timeout=25)
text = (lab/'quiet-vm.py').read_text(encoding='utf-8')
assert text.count("'lython-b1937-current-cpython'")==1
(lab/'quiet-vm.py').write_text(text.replace("'lython-b1937-current-cpython'","'lython-b1937-current-cpython-retry'"),
    encoding='utf-8',newline='\n')
print('Archived the first gate failure and started one retry with identical inputs and gates.')
