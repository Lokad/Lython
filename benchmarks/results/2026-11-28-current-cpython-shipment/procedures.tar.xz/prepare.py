from hashlib import sha256
from pathlib import Path
from shutil import copy2, copytree
import json
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
source = lab.parent / 'staged-generator-activation-refined-b1936-20261128/comparison'
old = lab.parent / 'current-checkpoint-b1932-20261128'
donor = old / 'comparison/quiet'
quiet = lab / 'comparison/quiet'
core = 'Lokad.Lython.dll'
stage = 'script-cpython-quiet-b1937-20261128'

def read(path):
    return json.loads(path.read_bytes())
def digest(path):
    return sha256(path.read_bytes()).hexdigest()
def files(folder):
    return {path.name: digest(path) for path in folder.iterdir()}
def write(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8', newline='\n')
def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo)
def save_script(path, content):
    path.write_text(content, encoding='utf-8', newline='\n')
    assert b'\r' not in path.read_bytes()

head = git('rev-parse', 'HEAD').decode().strip()
assert head.startswith('e036d6597')
assert not git('status', '--porcelain')
measured = read(source / 'identity.json')
assert sha256(git('diff', '--binary', measured['sourceRevision'], head, '--', 'src/Lokad.Lython')).hexdigest() == measured['sourcePatchSHA256']
assert not git('diff', measured['sourceRevision'], head, '--', 'src/Lokad.Lython.Utf8Regex', 'Directory.Packages.props')
image = measured['imageFiles']['candidate']
assert len(image) == 32 and files(source / 'candidate') == image
donor_id = read(donor / 'identity.json')
donor_files = donor_id['imageFiles']['candidate']
assert files(donor / 'local-image') == donor_files and len(donor_files) == 32
old_state = read(donor / 'terminal-status.json')
assert not old_state['live'] and not old_state['fixtures'] and old_state['exitCode'] == '0'
receipt = old_state['receipt']
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['quietBeforeAndAfter']
assert digest(donor / 'observations.tar.xz') == receipt['archiveSHA256']
assert {name for name, checksum in image.items() if donor_files[name] != checksum} == {core}
quiet.mkdir(parents=True)
copytree(source / 'candidate', quiet / 'local-image')
assert files(quiet / 'local-image') == image
assert all(not path.samefile(source / 'candidate' / path.name) for path in (quiet / 'local-image').iterdir())
for name in ('representative.json', 'cpython-worker.py'):
    copy2(source / name, quiet / name)
assert digest(quiet / 'cpython-worker.py') == measured['cpythonWorkerSHA256']
goldens = read(source / 'candidate-verify.json')
assert goldens['state'] == 'Completed' and goldens['caseCount'] == 4
assert goldens['catalogSha256'] == digest(quiet / 'representative.json')
assert goldens['launched']['library']['sha256'] == image[core]
assert goldens['launched']['adapter']['sha256'] == image['Lokad.Lython.Benchmarks.dll']
assert goldens['launched']['python']['sha256'] == measured['expectedCPythonSHA256']
jobs = read(source / 'jobs.json')['warm']
assert len(jobs) == 5
write(quiet / 'jobs.json', jobs)
identity = dict(sourceRevision=head, productionHead=head, sourcePatchSHA256=measured['sourcePatchSHA256'],
    purpose='Quiet CPython comparison for both shipment APIs after private generator activation delivery.',
    imageFiles={'candidate': image}, coreSHA256={role: image[core] for role in ('candidate', 'candidate-control')},
    auxiliaryFiles={name: sha for name, sha in image.items() if name != core},
    frozenImage=f'/home/lokad/lython-bench-checks/{stage}/candidate',
    catalogs={name:{'sha256':digest(quiet / name)} for name in ('representative.json', 'jobs.json')},
    expectedCPythonSHA256=measured['expectedCPythonSHA256'], cpythonWorkerSHA256=measured['cpythonWorkerSHA256'],
    donorArchiveSHA256=receipt['archiveSHA256'])
write(quiet / 'identity.json', identity)

collect = (donor / 'collect.py').read_text(encoding='utf-8')
assert collect.count('len(jobs) == 8') == 1
collect = collect.replace('len(jobs) == 8', 'len(jobs) == 5').replace('lython-b1932-cpython-fixtures', 'lython-b1937-cpython-fixtures')
compile(collect, 'collect.py', 'exec')
save_script(quiet / 'collect.py', collect)
save_script(quiet / 'run.sh', (donor / 'run.sh').read_text(encoding='utf-8'))

paths = {name: quiet / name for name in ('identity.json', 'representative.json', 'jobs.json', 'cpython-worker.py', 'run.sh', 'collect.py')}
paths[f'candidate/{core}'] = quiet / 'local-image' / core
payload = quiet / 'stage.tar.gz'
with tarfile.open(payload, 'w:gz') as archive:
    for name, path in paths.items():
        archive.add(path, arcname=name)
with tarfile.open(payload) as archive:
    assert all(archive.extractfile(name).read() == path.read_bytes() for name, path in paths.items())
manifest = {name: dict(length=path.stat().st_size, sha256=digest(path)) for name, path in paths.items()}
write(quiet / 'upload.json', dict(root=stage, donor=read(donor / 'upload.json')['root'], donorFiles=donor_files,
    donorArchive=receipt['archiveSHA256'], payloadSHA256=digest(payload), files=manifest,
    expandedBytes=sum(row['length'] for row in manifest.values()), minimumAfterStageBytes=16 * 1024 * 1024, caseCount=4))

launch = (old / 'quiet-vm.py').read_text(encoding='utf-8')
launch = launch[:launch.index('retry_code=')] + launch[launch.index("if sys.argv[1]=='launch':"):]
launch = launch[:launch.index("elif sys.argv[1]=='retry':")] + launch[launch.index("else:\n    assert sys.argv[1]=='retrieve'"):]
launch = launch[:launch.index(' deduplicated=[]')] + launch[launch.index(' assert cleared>=floor'):]
launch = launch.replace(' assert cleared>=floor,(cleared,floor)', ' assert before>=floor,(before,floor)')
launch = launch.replace('afterReclaim=cleared','afterReclaim=before').replace('deduplicated=deduplicated','deduplicated=[]')
launch = launch.replace("'lython-b1932-current-cpython'+('-retry' if sys.argv[1] in ('retry','retrieve') else '')",
                        "'lython-b1937-current-cpython'")
compile(launch, 'quiet-vm.py', 'exec')
save_script(lab / 'quiet-vm.py', launch)

summary = (old / 'summarize.py').read_text(encoding='utf-8')
assert '2ef73bd71' in summary and '==224' in summary
summary = summary.replace('2ef73bd71', head).replace('==8', '==5').replace('==224', '==140')
compile(summary, 'summarize.py', 'exec')
save_script(lab / 'summarize.py', summary)
print(head, stage, len(jobs), 'lanes')
