from hashlib import sha256
from pathlib import Path
from shutil import copy2
from subprocess import check_output
import json
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / 'comparison/quiet'
out = repo / 'benchmarks/results/2026-11-28-current-cpython-shipment'
recovery = lab.parent / 'staged-generator-activation-refined-b1936-20261128/quiet-space'
def digest(path):
    return sha256(path.read_bytes()).hexdigest()
def read(path):
    return json.loads(path.read_bytes())

identity = read(quiet/'identity.json')
proof = read(quiet/'summary.json')
revision = check_output(['git','rev-parse','e036d6597'],cwd=repo,text=True).strip()
assert revision == identity['sourceRevision'] == proof['source']
assert proof['passedQuietCheck'] and proof['timedBatches'] == 140
assert len(proof['rows']) == 5
image = identity['imageFiles']['candidate']
assert len(image) == 32 and {p.name:digest(p) for p in (quiet/'local-image').iterdir()} == image
out.mkdir(exist_ok=True)
for name in ('identity.json','summary.json','observations.tar.xz','terminal-status.json','stage-custody.json'):
    copy2(quiet/name,out/name)
    assert digest(quiet/name) == digest(out/name)
receipt = read(recovery/'recovery.json')
assert digest(recovery/receipt['archive']) == receipt['archiveSHA256']
procedures = {name:quiet/name for name in ('candidate-remote-verify.json','launch.log','archive-receipt.json','upload.json')}
procedures.update({f'attempt-initial/{p.name}':p for p in (quiet/'attempt-initial').iterdir()})
procedures.update({name:lab/name for name in ('prepare.py','quiet-vm.py','retry.py','summarize.py','publish.py')})
procedures.update({f'quiet-disk/{name}':recovery/name for name in ('recovery.json','archive-old-build.py')})
with tarfile.open(out/'procedures.tar.xz','w:xz') as archive:
    for name,path in procedures.items():
        archive.add(path,arcname=name)
with tarfile.open(out/'procedures.tar.xz') as archive:
    assert all(digest(path)==sha256(archive.extractfile(name).read()).hexdigest() for name,path in procedures.items())
print('Shipment checkpoint and initial gate evidence verified.')
