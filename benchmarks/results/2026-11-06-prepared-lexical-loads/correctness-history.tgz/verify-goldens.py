from pathlib import Path
import json, re, subprocess, textwrap

root=Path(__file__).resolve().parent
source=Path('tests/Lokad.Lython.PublicApi.Tests/PreparedGlobalLookupTests.cs').read_text(encoding='utf-8')
cases=re.findall(r'yield return \["([^"]+)", """\n(.*?)\n\s*""", ("(?:[^"\\]|\\.)*")\];',source,re.S)
assert len(cases)==6
results=[]
for name,script,quoted in cases:
 script=textwrap.dedent(script)+'\n';expected=json.loads(quoted)
 process=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',script],capture_output=True,text=True,encoding='utf-8',timeout=5)
 assert process.returncode==0 and not process.stderr and process.stdout==expected,(name,process.returncode,process.stdout,process.stderr,expected)
 results.append(dict(name=name,source=script,expected=expected,actual=process.stdout,exitCode=process.returncode))
(root/'independent-goldens.json').write_text(json.dumps(dict(python='CPython3.13.2 -I -S -X utf8',cases=results),indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print('Six independent CPython goldens passed.')
