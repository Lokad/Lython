from pathlib import Path
import fcntl,json,subprocess

root=Path('/home/lokad/lython-bench-checks/lexical-loads-b311-20261106')
status=subprocess.check_output(['systemctl','show','lython-b311-lexical-loads-20261106','--property=LoadState,ActiveState,MainPID,Result'],text=True)
assert 'ActiveState=inactive' in status and 'MainPID=0' in status and 'Result=success' in status,status
assert (root/'exit-code.txt').read_text().strip()=='0'
data=json.loads((root/'confirmation/confirmation.json').read_text())
assert data['complete'] and len(data['jobs'])==4
(root/'final-service-status.txt').write_text(status,encoding='utf-8')
with (root.parent/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    subprocess.run(['python3',str(root/'archive.py')],check=True)
