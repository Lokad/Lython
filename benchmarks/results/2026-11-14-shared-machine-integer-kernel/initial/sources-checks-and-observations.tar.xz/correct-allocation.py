from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).parent;root=(r/'allocation-fixtures').resolve();assert root.parent==r.resolve()and root.name=='allocation-fixtures'
inventory=[]
for p in root.iterdir():
 assert p.resolve()==p and p.parent==root and p.is_dir()and p.name.startswith('lython-comparison-files-')
 files=[dict(path=v.relative_to(root).as_posix(),bytes=v.stat().st_size,sha256=hashlib.sha256(v.read_bytes()).hexdigest())for v in p.rglob('*')if v.is_file()]
 inventory.extend(files);shutil.rmtree(p)
assert not list(root.iterdir());root.rmdir()
failure=dict(kind='Local allocation tool30second process bound exceeded on original four-case catalog; subprocess.run killed and joined process; no final result was written, no allocation or elapsed claim.',originalCatalogSHA256=hashlib.sha256((r/'allocation-reference-catalog.json').read_bytes()).hexdigest(),retainedFixtureInventory=inventory,cleanup='Resolved owned comparison directories verified before removal; no remaining local fixture directory.',correction='Narrow existing tool to complete loop and fulfillment, retain same binary/counts/warmup/30second process bound/four fresh processes. Invoice/text CPU controls remain in B731.',notRuntimeFailure=True)
(r/'initial-allocation-timeout.json').write_text(json.dumps(failure,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(r/'measure-allocation.py',r/'initial-four-case-measure-allocation.py');shutil.copyfile(r/'allocation-reference-catalog.json',r/'initial-four-case-allocation-catalog.json')
for role in ['reference','candidate']:
 catalog=json.loads((r/('allocation-'+role+'-catalog.json')).read_text(encoding='utf-8'));catalog['cases']=[c for c in catalog['cases']if c['id']in ['diagnostic.loop-range.inside.large','scripts.csv-fulfillment.large']];assert len(catalog['cases'])==2
 (r/('allocation-'+role+'-catalog.json')).write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8',newline='\n')
log=r/'reference-allocation-0.log';assert log.exists();log.rename(r/'initial-four-case-allocation-timeout.log')
print('Original four-case timeout and footprint preserved; users joined/owned files removed; corrected two-case allocation catalog ready.')
