from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile,xml.etree.ElementTree as ET
r=Path(__file__).parent;prior=r.parent/'owned-tuple-return-r353';reference=json.loads((prior/'candidate-identity.json').read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
checks=[]
for project,label in [('Lokad.Lython.Tests','internal'),('Lokad.Lython.PublicApi.Tests','public')]:
 for framework in ['11','10']:
  name=('r357-corrected-'if label=='public'else'r357-')+label+framework+'.trx';path=Path('tests')/project/'TestResults'/name
  root=ET.parse(path);ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};count=root.find('.//t:Counters',ns).attrib;assert count['failed']=='0'and count['passed']==('931'if label=='public'else'114')
  shutil.copyfile(path,r/name);checks.append(dict(project=project,framework=framework,counters=count,sha256=sha(path)))
(r/'focused-checks.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8',newline='\n')
sources={p:sha(p)for p in reference['sources']};changed=[p for p in sources if sources[p]!=reference['sources'][p]];assert len(changed)==3,changed
env={k:v for k,v in os.environ.items()if k.lower()!='path'};env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+os.environ.get('PATH','')
with(r/'candidate-build.log').open('w',encoding='utf-8',newline='\n')as f:
 done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-restore','--no-incremental','--disable-build-servers','-m:1'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
assert done.returncode==0 and sources=={p:sha(p)for p in sources}
for role in ['reference','candidate']:shutil.copytree(prior/'candidate',r/role)
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'candidate/Lokad.Lython.dll');shutil.copyfile(r/'candidate/Lokad.Lython.dll',r/'candidate-core.dll')
identity=dict(headBeforeCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),referenceProductionCommit='f5817a15',referenceQualification='GREEN43583650094; exact production source at24cdc5b4; all581inputs/16summaries cached',coreSHA256={role:sha(r/role/'Lokad.Lython.dll')for role in ['reference','candidate']},sources=sources,productionFiles=len(sources),changedProductionInputs=changed,removedWork=['general BigInteger limb arithmetic and major-estimation path for checked int64 individual results','executable-only placement of shared scalar arithmetic kernel'],unchanged='Boxed BigInteger publication, existing caller/argument/frame storage, exact promotion and major-result/working-overlap preflight, owners/refusal/cancellation; no new value format or policy.',auxiliaryFiles={role:{p.name:sha(p)for p in(r/role).iterdir()if p.is_file()and p.name!='Lokad.Lython.dll'}for role in ['reference','candidate']},qualified=False)
assert identity['auxiliaryFiles']['reference']==identity['auxiliaryFiles']['candidate'];(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as t:
 for p in sources:t.add(p,arcname=p)
catalog=json.loads((prior/'catalog.json').read_text(encoding='utf-8'));loop=json.loads((r.parent/'loop-boundary-r356/representative.json').read_text(encoding='utf-8'))['cases'][0];catalog['cases']=[loop]+catalog['cases'];assert len(catalog['cases'])==4
(r/'catalog.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8',newline='\n')
for role in ['reference','candidate']:shutil.copyfile(r/'catalog.json',r/('allocation-'+role+'-catalog.json'))
shutil.copyfile(prior/'measure-allocation.py',r/'measure-allocation.py')
s=(prior/'verify-worker.py').read_text(encoding='utf-8').replace('for index in range(3)','for index in range(4)');(r/'verify-worker.py').write_text(s,encoding='utf-8',newline='\n')
print('Frozen',identity['coreSHA256'],'2,090focused actual11/10checks pass; three production inputs.',flush=True)
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'verify-worker.py')],check=True,env=env)
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'measure-allocation.py')],check=True,env=env)
