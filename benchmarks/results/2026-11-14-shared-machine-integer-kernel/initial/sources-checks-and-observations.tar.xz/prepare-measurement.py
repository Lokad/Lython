from pathlib import Path
import ast,base64,datetime,hashlib,io,json,subprocess,tarfile
r=Path(__file__).parent;old=r.parent/'loop-boundary-r356';out=r/'b731';out.mkdir(exist_ok=False)
source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert all(sha(p)==v for p,v in source['sources'].items())
aux=json.loads((old/'identity.json').read_text(encoding='utf-8'))['auxiliaryFiles'];assert all(source['auxiliaryFiles'][role][n]==v for role in ['reference','candidate']for n,v in aux.items())
identity=dict(sourceRevision='R357 uncommitted/frozen'+source['coreSHA256']['candidate'][:8]+' vs fully qualifiedf5817a15/frozen9cfb7d5b',purpose='Shared checked machine-integer kernel: same-source100kloop/fulfillment/invoice/text source pair. Compilation excluded, output/file validation/result cleanup included; no file IO for numeric loop. Allocation separate; no CPython or startup speedup claim.',coreSHA256={label:source['coreSHA256']['candidate'if label.startswith('candidate')else'reference']for label in ['reference','candidate','reference-control','candidate-control']},auxiliaryFiles=aux,catalogSHA256=sha(r/'catalog.json'),publicationHeld=True)
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n');(out/'source-identity.json').write_text(json.dumps(source,separators=(',',':'))+'\n',encoding='utf-8',newline='\n')
root='/home/lokad/lython-bench-checks/machine-kernel-b731-20261114';unit='lython-b731-machine-kernel-20261114'
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=(old/name).read_text(encoding='utf-8').replace('loop-boundary-b729-20261114','machine-kernel-b731-20261114').replace('lython-b729-loop-boundary-20261114',unit).replace('B729','B731')
 if name=='collect.py':
  start=s.index('jobs=');end=s.index('\nenv =',start);cases=json.loads((r/'catalog.json').read_text(encoding='utf-8'))['cases'];s=s[:start]+'jobs='+repr([[c['id'],'warm']for c in cases])+"\nassert len(jobs)==4 and all(case in cases for case,lane in jobs)\n"+s[end:]
  s=s.replace("labels=['candidate','CPython','candidate-control','CPython-control']","labels=['reference','candidate','reference-control','candidate-control']").replace('started < 120','started < 240')
  assert 'control_catalog'not in s and "labels=['reference','candidate','reference-control','candidate-control']"in s
 elif name=='archive-owned.py':s=s.replace("len(raw['jobs'])==2","len(raw['jobs'])==4").replace('jobs=2','jobs=4').replace("'current-core.dll','reference-core.dll'","'current-core.dll','reference-core.dll','candidate-core.dll'")
 elif name=='retrieve.py':s=s.replace("['jobs']==2","['jobs']==4").replace("['elapsedSeconds']<180","['elapsedSeconds']<300")
 elif name=='summarize.py':s=s.replace("len(raw['jobs'])==2","len(raw['jobs'])==4").replace('jobs=2','jobs=4').replace("externalBaseline='CPython3.13.16'","externalBaseline=None")
 if name.endswith('.py'):ast.parse(s)
 (out/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
 for name in ['identity.json','source-identity.json','collect.py','archive-owned.py','run.sh']:t.add(out/name,arcname=name)
 t.add(r/'catalog.json',arcname='representative.json');t.add(r/'candidate-core.dll',arcname='candidate-core.dll')
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
canonical=Path('benchmarks/results/2026-11-14-owned-csv-field-ranges/initial/sources-checks-and-failed-observations.tar.xz');head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();blob=subprocess.check_output(['git','show',head+':'+canonical.as_posix()]);assert hashlib.sha256(blob).hexdigest()==sha(canonical)
with tarfile.open(fileobj=io.BytesIO(blob),mode='r:xz')as t:body=t.extractfile('candidate-core.dll').read()
proof=dict(commit=head,canonicalArchive=canonical.as_posix(),archiveSHA256=sha(canonical),member='candidate-core.dll',coreSHA256=hashlib.sha256(body).hexdigest(),bytes=len(body),reason='Retire only withdrawn R355 frozen510a working-core aliases, exact bytes preserved in canonical Git; all current9cfb/new69d9 images, auxiliaries, catalogs, toolchains and254/252MiBfloors preserved.')
config=dict(root=root,sourceRoot='/home/lokad/lython-bench-checks/loop-boundary-b729-20261114',unit=unit,identity=identity,proof=proof,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=sha(out/'payload.tgz'),unpackedBytes=unpacked)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n');(out/'retirement-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
code='''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
c=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(c['root']);source=Path(c['sourceRoot']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert root.parent==base and source.parent==base and not root.exists()and source.resolve()==source
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(os.path.ismount(p)for p in base.glob('*/guest-fixtures'))
 assert(source/'exit-code.txt').read_text().strip()=='0'and json.loads((source/'archive-receipt.json').read_text())['complete']
 for name,digest in dict(c['identity']['auxiliaryFiles'],**{'Lokad.Lython.dll':c['identity']['coreSHA256']['reference']}).items():assert sha(source/'candidate'/name)==digest
 payload=sys.stdin.buffer.read(c['payloadBytes']+1);assert len(payload)==c['payloadBytes']and hashlib.sha256(payload).hexdigest()==c['payloadSHA256']
 proof=c['proof'];aliases=[]
 for p in base.rglob('*.dll'):
  if p.name not in {'Lokad.Lython.dll','candidate-core.dll','current-core.dll','reference-core.dll'}:continue
  info=p.lstat()
  if info.st_size!=proof['bytes']or sha(p)!=proof['coreSHA256']:continue
  assert p.resolve()==p and p.is_relative_to(base)and stat.S_ISREG(info.st_mode)and info.st_uid==os.getuid();aliases.append(p)
 assert aliases and len({(p.stat().st_dev,p.stat().st_ino)for p in aliases})==1
 assert all(p.stat().st_nlink==len(aliases)for p in aliases)
 before=shutil.disk_usage(base).free;assert before+proof['bytes']>254*1024*1024+c['unpackedBytes']+32768
 for p in aliases:p.unlink()
 receipt=dict(proof=proof,retiredOnly=[str(p)for p in aliases],allPathsUidsHashesAndCompleteAliasesProvedBeforeMutation=True,freshIdleLease=True,beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free)
 (base/'b731-proved-withdrawn-core-retirement-20261114.json').write_text(json.dumps(receipt,indent=2)+'\\n')
 assert shutil.disk_usage(base).free>254*1024*1024+c['unpackedBytes']+32768;root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as t:t.extractall(root,filter='data')
 assert sha(root/'candidate-core.dll')==c['identity']['coreSHA256']['candidate']
 for role in ['reference','candidate']:
  (root/role).mkdir()
  for name in c['identity']['auxiliaryFiles']:os.link(source/'candidate'/name,root/role/name)
  os.link(source/'candidate/Lokad.Lython.dll'if role=='reference'else root/'candidate-core.dll',root/role/'Lokad.Lython.dll')
 os.link(source/'cpython-worker.py',root/'cpython-worker.py')
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture=root/'guest-fixtures';fixture.mkdir();assert shutil.disk_usage(base).free>254*1024*1024
 (root/'space-preflight.json').write_text(json.dumps(dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,floorsUnchanged=True,retirementReceipt=receipt))+'\\n')
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b731-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+c['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=300','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print('R357 four-job source pair launched under300second owner; current source/auxiliaries verified.')
'''.replace('CONFIG',repr(config));ast.parse(code);(out/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
done=subprocess.run(ssh+[command],input=(out/'payload.tgz').read_bytes(),capture_output=True,timeout=45);(out/'launch.log').write_bytes(done.stdout+done.stderr);assert done.returncode==0,(done.stdout+done.stderr).decode()
now=datetime.datetime.now(datetime.timezone.utc);(out/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=240)).isoformat(),ownerSeconds=300),indent=2)+'\n',encoding='utf-8',newline='\n')
print(done.stdout.decode(),flush=True);print('Observe after',(now+datetime.timedelta(seconds=240)).isoformat(),flush=True)
