from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-14-shared-machine-integer-kernel/initial');out.mkdir(parents=True,exist_ok=False)
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));assert identity['coreSHA256']['candidate'].startswith('69d936e1')
assert json.loads((r/'b731/terminal-status.json').read_text(encoding='utf-8'))['receipt']['complete']
decision=dict(status='Initial measured prototype, superseded by a justified nonthrowing-kernel refinement; not committed runtime or fully qualified.',source=identity['coreSHA256']['candidate'],reference=identity['coreSHA256']['reference'],checks='114internal/931public per actual11/10,2090total; all8frozen source/case golden and budget checks pass.',allocation='Complete loop flat; complete fulfillment+3.875B/invocation effectively flat. Four fresh processes, unchanged counters and ownership checks.',timing='B731fourjobs167.976s/allgates. Complete loop elapsed−14.73..−13.29%/CPU−14.16..−13.27%. Invoice−2.59..+1.98%/CPU−1.92..+1.54%; fulfillment−1.66..+0.35%/CPU−3.56..−0.26%; text−4.04..+1.36%/CPU−2.64..+1.82%. Representative CPU benefit remains limited/uncertain; no objective-completion claim.',refinement='Shared machine kernel currently signals overflow by exception. Ordinary repeated within-int64 inputs producing wider products can now throw on each probe. Replace this with exact Int128 intermediates/explicit bounds and min/-1 rules; delete overflow catches in chains/cells. Preserve69d9all original timing/allocation/failure evidence. Recheck semantics and make one bounded source-pair confirmation of final code.',failures=['New boundary fixture initially passed a typed BigInteger[] where supported host ingress expects object[];2public failures per target retained. Correction changes fixture only;2090focused checks then pass.','Initial local allocation run exceeded unchanged30second process bound on four cases; process killed/joined and original footprint archived before resolved owned-directory cleanup. Corrected two affected workloads preserve binary/counts/warmup/bound; all4fresh processes pass.','Source-pair summarizer initially still expected CPython labels; corrected to reference labels with raw data unchanged.'],publicationHeld=True,performanceObjectiveStillActive=True)
(r/'initial-decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['initial-decision.json','prospective.json','candidate-identity.json','focused-checks.json','allocation-summary.json','initial-allocation-timeout.json','worker-verification.json']:shutil.copyfile(r/name,out/name)
shutil.copyfile(r/'b731/summary.json',out/'timing-summary.json')
with tarfile.open(out/'sources-checks-and-observations.tar.xz','w:xz')as t:
 for p in sorted(r.iterdir()):
  if p.is_file()and(p.suffix in ['.py','.json','.log','.trx','.xz']or p.name=='candidate-core.dll'):t.add(p,arcname=p.name)
 for p in sorted((r/'b731').iterdir()):
  if p.is_file()and p.suffix in ['.py','.json','.log','.tgz','.sh']:t.add(p,arcname='b731/'+p.name)
(out/'README.md').write_text('''# Initial checked machine-integer prototype

R357,2026-11-14. Frozen69d936e1 vs fully qualifiedf5817a15/frozen9cfb.
2,090focused actual11/10checks pass. Individual exact arithmetic reuses the
existing machine kernel; boxed BigInteger publication and major admission remain.

B731fourjobs167.976s/allgates: complete100kloop elapsed−14.73..−13.29%and
wider CPU−14.16..−13.27%; allocation flat. Complete fulfillment elapsed
−1.66..+0.35%/CPU−3.56..−0.26%; invoice−2.59..+1.98%/CPU−1.92..+1.54%;
text−4.04..+1.36%/CPU−2.64..+1.82%, with process spreads. Representative
benefits remain limited/uncertain. These are same-source warm comparisons,
excluding compile/startup/reset/protocol/final cache disposal and including
mediated I/O, output/file validation and result cleanup. No CPython gain inferred.

This implementation is superseded before delivery: expected machine overflow
would throw on each probe of repeated wider products. A nonthrowing shared kernel
using exact Int128 intermediates/explicit bounds should remove that path and
three overflow-catching boundaries across ordinary arithmetic, chains and cells.
Final code must be independently checked/timed. No initial result is discarded.

Preserved failures: typed BigInteger[] test ingress corrected to supported
object[]; original2failed cases per target retained. A four-case local allocation
process exceeded30seconds; killed/joined and owned footprint retained before
cleanup. Narrowing to two affected workloads kept the30second bound, counts,
warmup and images; four fresh processes pass. Postprocessing initially expected
CPython labels and was corrected to reference labels; raw observations unchanged.

[Decision](initial-decision.json),[timing](timing-summary.json),
[allocation](allocation-summary.json),[all sources/binary/checks/tools/raw](sources-checks-and-observations.tar.xz).
''',encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');anchor='| Withdrawn / unresolved |';s=s.replace(anchor,'| R356, completed source gate | Committed e9681c76; two-case stockCPython diagnostic/B729 and same-process owning profile/B730 are complete. Range boundary8–9%secondary to numeric work; no runtime-source speedup claim. [Evidence](benchmarks/results/2026-11-14-numeric-loop-boundary/README.md). |\n| R357, active refinement | Initial69d936e1 passes2,090focused checks; B731all4jobs/gates. Numeric loop warm−13.29..−14.73%withCPU support/allocation flat; representative controls small/uncertain. Replace expected-overflow exceptions with one nonthrowing shared kernel before delivery; original source/binary/timings/typed-fixture and allocation-timeout failures preserved. [Initial evidence](benchmarks/results/2026-11-14-shared-machine-integer-kernel/initial/README.md). |\n'+anchor,1);s=s.replace('   Before wider scalar storage, consolidate','   Initial69d9source pair completes: loop−13–15%CPU/elapsed, allocation flat;\n   representative results limited/uncertain. Refine shared kernel to nonthrowing\n   Int128intermediates/explicit fit checks; remove existing overflow catches in\n   cells/chains. Focused checks and one bounded final source pair follow.\n   Before wider scalar storage, consolidate',1);p.write_text(s,encoding='utf-8',newline='\n')
print('Initial69d9source/binary/checks/timings/failures immutable; nonthrowing refinement remains active.')
