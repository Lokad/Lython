from pathlib import Path
r=Path(__file__).parent.resolve();out=r/'nonthrowing/b732';target=r/'nonthrowing/b732-staging-failed-before-mutation'
assert out.resolve().is_relative_to(r)and target.resolve().is_relative_to(r)and not target.exists()
out.rename(target)
print('Preserved failed B732 staging: source candidate image selected where baseline reference image was required; identity guard failed before payload/mutation/launch.')
