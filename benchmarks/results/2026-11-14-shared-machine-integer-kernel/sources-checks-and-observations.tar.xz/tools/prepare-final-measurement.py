from pathlib import Path
import ast,base64,datetime,hashlib,io,json,subprocess,tarfile
r=Path(__file__).parent;final=r/'nonthrowing';out=final/'b732';out.mkdir(exist_ok=False);old=r/'b731';source=json.loads((final/'candidate-identity.json').read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert all(sha(p)==v for p,v in source['sources'].items())
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'));identity.update(sourceRevision='R357 refined uncommitted/frozencbb254be vs fully qualifiedf5817a15/frozen9cfb7d5b',purpose='Nonthrowing shared machine-integer kernel final source pair; same four scripts/warmup/protocol/cases as initial69d9comparison. Exact result publication remains, allocation is separate; no inferred CPython/startup improvement.',coreSHA256={label:source['coreSHA256']['candidate'if label.startswith('candidate')else'reference']for label in ['reference','candidate','reference-control','candidate-control']},fullSourceIdentitySHA256=sha(final/'candidate-identity.json'))
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n');root='/home/lokad/lython-bench-checks/machine-kernel-b732-20261114';unit='lython-b732-machine-kernel-20261114'
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=(old/name).read_text(encoding='utf-8').replace('machine-kernel-b731-20261114','machine-kernel-b732-20261114').replace('lython-b731-machine-kernel-20261114',unit).replace('B731','B732')
 if name.endswith('.py'):ast.parse(s)
 if name=='collect.py':assert 'control_catalog'not in s
 (out/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
 for name in ['identity.json','collect.py','archive-owned.py','run.sh']:t.add(out/name,arcname=name)
 t.add(final/'candidate-core.dll',arcname='candidate-core.dll')
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
def canonical(path,member=None):
 p=Path(path);blob=subprocess.check_output(['git','show',head+':'+p.as_posix()]);assert hashlib.sha256(blob).hexdigest()==sha(p)
 if member:
  with tarfile.open(fileobj=io.BytesIO(blob),mode='r:xz')as t:body=t.extractfile(member).read()
 else:body=blob
 return dict(commit=head,canonicalArchive=p.as_posix(),archiveSHA256=sha(p),member=member,bytes=len(body),sha256=hashlib.sha256(body).hexdigest())
proof=canonical('benchmarks/results/2026-11-14-shared-machine-integer-kernel/initial/sources-checks-and-observations.tar.xz','candidate-core.dll');proof.update(coreSHA256=proof['sha256'],reason='Only superseded69d9prototype working-core aliases; source/binary/observations preserved in canonical Git. Current9cfb baseline/newcbb2, all auxiliaries/catalogs/toolchains preserved.')
duplicates=[]
for path,member,remote in [
 ('benchmarks/results/2026-11-14-fulfillment-stage-attribution/observations.tgz',None,'fulfillment-stage-b726-20261114/observations.tgz'),
 ('benchmarks/results/2026-11-14-numeric-loop-boundary/tools-catalogs-and-observations.tar.xz','owning-profile/observations.tgz','loop-stage-b730-20261114/observations.tgz'),
 ('benchmarks/results/2026-11-14-numeric-loop-boundary/tools-catalogs-and-observations.tar.xz','diagnostic/observations.tgz','loop-boundary-b729-20261114/observations.tgz'),
 ('benchmarks/results/2026-11-14-shared-machine-integer-kernel/initial/sources-checks-and-observations.tar.xz','b731/observations.tgz','machine-kernel-b731-20261114/observations.tgz')]:
  item=canonical(path,member);item['remote']=remote;duplicates.append(item)
config=dict(root=root,sourceRoot='/home/lokad/lython-bench-checks/machine-kernel-b731-20261114',unit=unit,identity=identity,proof=proof,duplicates=duplicates,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=sha(out/'payload.tgz'),unpackedBytes=unpacked)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
code=(old/'launch-command.py').read_text(encoding='utf-8');start=code.index('c=');end=code.index('\nbase=',start);code=code[:start]+'c='+repr(config)+code[end:]
needle="before=shutil.disk_usage(base).free;assert before+proof['bytes']>254*1024*1024+c['unpackedBytes']+32768";assert needle in code
code=code.replace(needle,"""duplicate_paths=[]
 for item in c['duplicates']:
  p=base/item['remote'];info=p.lstat();assert p.resolve()==p and p.is_relative_to(base)and stat.S_ISREG(info.st_mode)and info.st_uid==os.getuid()and info.st_nlink==1
  assert info.st_size==item['bytes']and sha(p)==item['sha256'];duplicate_paths.append(p)
 before=shutil.disk_usage(base).free;assert before+proof['bytes']+sum(v['bytes']for v in c['duplicates'])>254*1024*1024+c['unpackedBytes']+32768
 for p in duplicate_paths:p.unlink()""")
code=code.replace("retiredOnly=[str(p)for p in aliases]","retiredOnly=[str(p)for p in aliases+duplicate_paths],duplicateProof=c['duplicates']")
code=code.replace("os.link(source/'cpython-worker.py',root/'cpython-worker.py')","os.link(source/'cpython-worker.py',root/'cpython-worker.py');os.link(source/'representative.json',root/'representative.json');assert sha(root/'representative.json')==c['identity']['catalogSHA256']")
code=code.replace('b731-proved-withdrawn-core-retirement-20261114','b732-proved-superseded-core-retirement-20261114').replace('lython-b731-fixtures','lython-b732-fixtures').replace('R357 four-job','R357 final four-job')
code=code.replace("source/'candidate'", "source/'reference'").replace("source/'candidate/Lokad.Lython.dll'", "source/'reference/Lokad.Lython.dll'")
ast.parse(code);(out/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
done=subprocess.run(ssh+[command],input=(out/'payload.tgz').read_bytes(),capture_output=True,timeout=45);(out/'launch.log').write_bytes(done.stdout+done.stderr);assert done.returncode==0,(done.stdout+done.stderr).decode()
now=datetime.datetime.now(datetime.timezone.utc);(out/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=240)).isoformat(),ownerSeconds=300),indent=2)+'\n',encoding='utf-8',newline='\n')
print(done.stdout.decode(),flush=True);print('Observe after',(now+datetime.timedelta(seconds=240)).isoformat(),flush=True)
