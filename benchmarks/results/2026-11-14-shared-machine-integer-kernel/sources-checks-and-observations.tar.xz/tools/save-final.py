from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;final=r/'nonthrowing';out=Path('benchmarks/results/2026-11-14-shared-machine-integer-kernel');identity=json.loads((final/'candidate-identity.json').read_text(encoding='utf-8'));summary=json.loads((final/'b732/summary.json').read_text(encoding='utf-8'));allocation=json.loads((final/'allocation-summary.json').read_text(encoding='utf-8'))
assert identity['coreSHA256']['candidate'].startswith('cbb254be')and summary['complete']and allocation['complete']
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==v for p,v in identity['sources'].items())
decision=dict(status='Retained nonthrowing shared kernel; focused-qualified, final source pair complete, full platform/stress/installed-consumer qualification pending.',source=identity['coreSHA256']['candidate'],reference=identity['coreSHA256']['reference'],productionInputs=581,changedProductionInputs=identity['changedProductionInputs'],focusedChecks='114internal/962public per actual11/10,2152total;6isolated CPython3.13.2 controls match exactcbb2core; all8frozen Ready/golden/files/budget checks pass.',removed='Executable-only placement of machine arithmetic and exception-based overflow probing in ordinary calls/chains/cells. Checked int64 results bypass general BigInteger limb arithmetic and repeated major-estimation routing.',unchanged='Published BigInteger objects and identities/aliases, exact wider promotion, bool/protocol/errors, managed stack/cancellation/current admission and terminal refusal, major storage/working-overlap funding/cleanup. No new value format, owner, array, arena, cache or policy.',allocation='Numeric loop flat; fulfillment−3.875..0B/invocation effectively flat; four fresh processes/reversed roles, same counts/warmup and30second bound after narrowing original timed-out batch.',timing='B732fourjobs168.213s/allgates: numeric loop elapsed−20.72..−19.67%/widerCPU−21.41..−19.67%; invoice−0.62..+1.48%/CPU0..+2.45%; fulfillment−0.38..+2.49%/CPU0..+2.24%; text−12.52..+5.01%/CPU−13.83..+5.13%, unstable.',regressionDebt='Retain coherent shared/no-exception kernel and measured complete numeric benefit. Invoice/fulfillment small adverse CPU direction is explicit unresolved debt, not neutrality. Text reference10.73%/candidate6.68%process spreads prevent attribution. No unchanged retiming requested: these controls do not establish a regression magnitude, and the broader representative objective remains active. Revisit with new owning evidence/coherent redesign.',failedConditions='Initial69d9all code/timing/allocation/failures preserved separately. Final B732staging initially selected source candidate69d9where reference9cfbwas required; guard failed before payload/mutation/launch. Corrected reference selection keeps finalcbb2data/settings. Original failed config/script/log preserved.',next='Batch full Windows/Ubuntu actual11/10, original stress and installed Release consumers once. Continue a bounded scalar-publication/operand-transport design gate using the remaining substantial allocation and representative profiles. No tagged VM or native-reentry framework automatically selected; exact identity/promotion/ownership and displaced work required.',publicationHeld=True,performanceObjectiveStillActive=True)
(final/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['decision.json','prospective.json','candidate-identity.json','focused-checks.json','allocation-summary.json','python-controls.json','worker-verification.json']:shutil.copyfile(final/name,out/name)
shutil.copyfile(final/'b732/summary.json',out/'timing-summary.json')
with tarfile.open(out/'sources-checks-and-observations.tar.xz','w:xz')as t:
 for folder,prefix in [(final,'nonthrowing'),(final/'b732','b732'),(final/'b732-staging-failed-before-mutation','failed-staging')]:
  for p in sorted(folder.iterdir()):
   if p.is_file()and(p.suffix in ['.py','.json','.log','.trx','.xz','.jsonl','.stderr','.sh']or p.name in ['candidate-core.dll','observations.tgz']):t.add(p,arcname=prefix+'/'+p.name)
 for p in sorted(r.glob('*.py')):t.add(p,arcname='tools/'+p.name)
(out/'README.md').write_text('''# Shared nonthrowing machine-integer arithmetic

2026-11-14UTC, R357. Retained frozen`cbb254be` vs fully qualifiedf5817a15/
frozen`9cfb7d5b`, four changed production inputs. Focused qualification and
source-pair comparison complete; full delivery qualification is pending.

Share the existing checked machine kernel with individual exact add/subtract/
multiply/floor-divide/modulo operations. Int128intermediates/explicit fit checks
remove expected-overflow exceptions from ordinary probes, chains and captured
cells. Exact int64results bypass general BigInteger limb arithmetic and repeated
major-estimation routing. Published values remain BigInteger objects, retaining
identities/aliases and exact wider promotion. Major allocation/workspace admission,
terminal refusal, cancellation and cleanup remain. No new value format/owner/
array/cache/arena/policy. This is a coherent kernel step, not completion of the
broader scalar or representative whole-script objective.

Quiet AzureF4as_v7, Ubuntu24.04.4, .NET11RC3; unchanged command-v2workers/data/
auxiliaries. Four fresh processes/job,5sfull-request warmup (12sfor captured text),
five0.5srotating batches, normal GC/tiering. Warm clocks include mediated RAMI/O,
stdout/file validation and result cleanup; exclude compilation/startup/reset/
protocol/final cache disposal. Wider CPU includes reset/protocol. No CPython,
startup, tail-latency or cross-collection speedup is claimed.

| Complete workload | Candidate warm ms | Elapsed change vs reference | Wider CPU change |
| --- | ---: | ---: | ---: |
|100,000-add numeric helper |4.114–4.136|−20.72..−19.67%|−21.41..−19.67%|
|4,096-row invoice |7.459–7.516|−0.62..+1.48%|0..+2.45%|
|4,096-row fulfillment |8.388–8.545|−0.38..+2.49%|0..+2.24%|
|3,072-line captured text |1.269–1.360|−12.52..+5.01%|−13.83..+5.13%|

Numeric-loop allocation is flat (~7.52MB/run); fulfillment is effectively flat
(−3.875..0B/run). This avoids arithmetic work, not boxed result publication.
Invoice/fulfillment show small adverse CPU direction: retain it as unresolved
regression debt, not neutrality. Text reference10.73%/candidate6.68%process
spreads prevent attribution. Retain the useful shared kernel without claiming
representative improvement or automatically retiming unchanged controls.

2,152focused cases pass:114internal/962public per actual .NET11/10. Signed
machine-boundary cross-products preserve promotion, Python signs/zero errors,
bool/reflected/in-place protocols, aliases, cancellation, terminal refusal and
retained-result/budget cleanup. Six isolated CPython3.13.2controls match the exact
frozen core; all8worker/source/case goldens and balance checks pass. B732completes
all4jobs in168.213s with identity/output/budget/quiet/join/archive gates. All
workers and owned RAM fixtures are gone; terminal results cached.

[Initial69d9prototype](initial/README.md) preserves its13–15%numeric benefit,
uncertain controls, typed-ingress fixture failures and four-case allocation
timeout/correction. Final staging initially selected the old candidate image where
the baseline reference was required; the identity guard failed before mutation/
launch. Corrected selection retains the samecbb2core/data/settings. Full original
scripts/config/logs survive. Only canonical-Git-proven obsolete prototype hardlinks
and duplicate completed raw archives were retired on the VM; current images,
catalogs, auxiliaries, toolchains and254/252MiBfloors remain.

[Decision/remaining work](decision.json),[timing](timing-summary.json),
[allocation](allocation-summary.json),[focused checks](focused-checks.json),
[independent Python](python-controls.json),[all sources/binary/checks/tools/raw](sources-checks-and-observations.tar.xz).
Publication remains postponed.
''',encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');s+='''
## R357 — shared nonthrowing machine-integer arithmetic

[Retainedcbb254be](results/2026-11-14-shared-machine-integer-kernel/README.md)
shares the machine kernel across ordinary exact operations/chains/cells, deleting
expected-overflow catches and general BigInteger arithmetic for checked int64
results.2,152focused actual11/10checks/6isolated CPython controls pass. B732four
jobs168.213s/allgates: complete numeric loop−19.7..−20.7%elapsed/CPU support,
allocation flat. Invoice/fulfillment small adverse CPU direction remains debt;
text10.73%reference/6.68%candidate spread is uncertain. Initial69d9source/timing
and every fixture/timeout/staging failure remain. Full delivery qualification
pending; shared publication/operand redesign and representative gains remain
active. No inferred CPython improvement; publication held.
''';p.write_text(s,encoding='utf-8',newline='\n')
print('Retainedcbb2source/binary/focused checks, final and initial adverse data preserved; full delivery pending.')
