from pathlib import Path
import hashlib,json,os,subprocess
r=Path(__file__).parent/'nonthrowing';sdk='C:/Users/JoannesVermorel/.dotnet11/dotnet.exe';probe=Path('tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll').resolve()
source='''def calculate(a,b):
    x=a+b
    old=x
    alias=[x,x]
    x+=b
    assert alias[0] is alias[1] and alias[0]==old
    return a+b,a-b,a*b,a//b,a%b,x
values=[-9223372036854775809,-9223372036854775808,-9223372036854775807,-7,-1,1,7,9223372036854775806,9223372036854775807,9223372036854775808]
print([calculate(a,b) for a in values for b in values])
'''
snippets=[source,'''for a in [-9223372036854775808,0,9223372036854775807]:
    for op in [lambda:a//0,lambda:a%0]:
        try:op()
        except ZeroDivisionError as error:print(type(error).__name__,str(error))
''','''class Right:
    def __radd__(self,x):return ('add',x)
    def __rmul__(self,x):return ('mul',x)
    def __rfloordiv__(self,x):return ('floor',x)
    def __rmod__(self,x):return ('mod',x)
r=Right()
print(9223372036854775807+r,9223372036854775807*r,9223372036854775807//r,9223372036854775807%r)
print(True+True,True*9223372036854775807,False-9223372036854775807)
''']
(r/'python-control-sources.json').write_text(json.dumps(snippets,indent=2)+'\n',encoding='utf-8',newline='\n')
env={k:v for k,v in os.environ.items()if k.lower()!='path'};env['PATH']=os.environ.get('PATH','');env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11'
rows=[]
for asynchronous in [False,True]:
 command=[sdk,str(probe),'--batch-json','--compare-python','--python','C:/Python313/python.exe']+(['--async']if asynchronous else[])
 done=subprocess.run(command,input=json.dumps(snippets).encode(),capture_output=True,env=env,timeout=30)
 (r/('python-controls-'+str(asynchronous)+'.jsonl')).write_bytes(done.stdout);(r/('python-controls-'+str(asynchronous)+'.stderr')).write_bytes(done.stderr)
 assert done.returncode==0,(done.stdout+done.stderr).decode('utf-8');rows.append(dict(asynchronous=asynchronous,comparedCases=3,matched=True,exitCode=done.returncode,outputSHA256=hashlib.sha256(done.stdout).hexdigest()))
(r/'python-controls.json').write_text(json.dumps(dict(complete=True,python='Isolated stockCPython3.13.2',cases=rows,sourceSHA256=hashlib.sha256((r/'python-control-sources.json').read_bytes()).hexdigest(),coreSHA256=hashlib.sha256((probe.parent/'Lokad.Lython.dll').read_bytes()).hexdigest()),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Six isolated CPython controls match both execution APIs: full boundary matrix, zero errors, aliases/bools/reflected protocols.')
