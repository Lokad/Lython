from pathlib import Path
import ast,hashlib,json,os,shutil,subprocess,tarfile,xml.etree.ElementTree as ET
r=Path(__file__).parent;out=r/'nonthrowing';out.mkdir(exist_ok=False);old=r.parent/'owned-tuple-return-r353';reference=json.loads((old/'candidate-identity.json').read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
checks=[]
for project,label in [('Lokad.Lython.Tests','internal'),('Lokad.Lython.PublicApi.Tests','public')]:
 for framework in ['11','10']:
  path=Path('tests')/project/'TestResults'/('r357-final-'+label+framework+'.trx');root=ET.parse(path);ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};count=root.find('.//t:Counters',ns).attrib;assert count['failed']=='0'and count['passed']==('962'if label=='public'else'114');shutil.copyfile(path,out/path.name);checks.append(dict(project=project,framework=framework,counters=count,sha256=sha(path)))
(out/'focused-checks.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8',newline='\n')
sources={p:sha(p)for p in reference['sources']};changed=[p for p in sources if sources[p]!=reference['sources'][p]];assert len(changed)==4,changed
env={k:v for k,v in os.environ.items()if k.lower()!='path'};env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+os.environ.get('PATH','')
with(out/'candidate-build.log').open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-restore','--no-incremental','--disable-build-servers','-m:1'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
assert done.returncode==0 and sources=={p:sha(p)for p in sources}
for role in ['reference','candidate']:shutil.copytree(old/'candidate',out/role)
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',out/'candidate/Lokad.Lython.dll');shutil.copyfile(out/'candidate/Lokad.Lython.dll',out/'candidate-core.dll')
identity=dict(headBeforeCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),referenceProductionCommit='f5817a15',referenceQualification='GREEN43583650094 at production-identical24cdc5b4; all581source inputs/16summaries cached',coreSHA256={role:sha(out/role/'Lokad.Lython.dll')for role in ['reference','candidate']},sources=sources,productionFiles=len(sources),changedProductionInputs=changed,removedWork=['general BigInteger limb arithmetic and major-estimation path for checked int64 individual results','three overflow-catching boundaries across ordinary probes/chains/cells','executable-only placement of common scalar kernel'],unchanged='Boxed BigInteger publication; exact wider promotion; admitted major storage/working overlap; owners, cancellation and terminal refusal. No value format/array/cache/owner/policy added.',auxiliaryFiles={role:{p.name:sha(p)for p in(out/role).iterdir()if p.is_file()and p.name!='Lokad.Lython.dll'}for role in ['reference','candidate']},qualified=False)
(out/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'candidate-sources.tar.xz','w:xz')as t:
 for p in sources:t.add(p,arcname=p)
shutil.copyfile(r/'catalog.json',out/'catalog.json')
for role in ['reference','candidate']:shutil.copyfile(r/('allocation-'+role+'-catalog.json'),out/('allocation-'+role+'-catalog.json'))
verify=(r/'verify-worker.py').read_text(encoding='utf-8').replace("r.parent/'utf8-byte-ownership-r334","r.parent.parent/'utf8-byte-ownership-r334");ast.parse(verify);(out/'verify-worker.py').write_text(verify,encoding='utf-8',newline='\n');shutil.copyfile(r/'measure-allocation.py',out/'measure-allocation.py')
(out/'prospective.json').write_text(json.dumps(dict(reason='Refine measured69d9kernel to avoid expected overflow exceptions in ordinary repeated products; shared Int128 fit checks/explicit division edges delete catches from existing chains and cells.',semantics='Exact signed arithmetic and zero errors/overflow promotion, identity/aliases/protocols unchanged; no admission or publication before deciding fit, original major preflights/terminal refusal/cleanup retained.',validation='2152focused actual11/10checks pass; independent13x13boundary C#BigInteger results, both APIs. One same-source final four-job confirmation, preserving all69d9evidence. Allocation separate.',publicationHeld=True),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Frozen final',identity['coreSHA256'],'2152focused checks/four production changes.',flush=True)
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(out/'verify-worker.py')],check=True,env=env)
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(out/'measure-allocation.py')],check=True,env=env)
