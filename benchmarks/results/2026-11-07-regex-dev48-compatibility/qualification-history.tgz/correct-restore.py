from pathlib import Path
p=Path('.git/agent-notes/review-20261031/regex-dev48/qualify.py');s=p.read_text(encoding='utf-8')
s=s.replace("f'-p:RestoreConfigFile={root}/NuGet.Config']", "f'-p:RestoreConfigFile={root}/NuGet.Config','-p:RestoreNoCache=true','-p:RestoreForce=true']")
s=s.replace("log=root/(label+'-corrected.log')", "log=root/(label+'-cache-corrected.log')")
p.write_text(s,encoding='utf-8',newline='\n')
