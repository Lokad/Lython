from pathlib import Path
p=Path('.git/agent-notes/review-20261031/regex-dev48/qualify.py');s=p.read_text(encoding='utf-8').replace("'-p:RestoreForce=true'","'-p:RestoreForce=true','-p:RestoreForceEvaluate=true'").replace("label+'-cache-corrected.log'","label+'-lock-corrected.log'")
p.write_text(s,encoding='utf-8',newline='\n')
