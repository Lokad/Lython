from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile
base=Path('.git/agent-notes/review-20261031');root=base/'regex-dev48'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
packages={}
for item in json.loads((base/'dev48-package-inspection.json').read_text(encoding='utf-8')):
    source=Path('D:/code/utf8regex/artifacts/package-candidates/0.5.0-dev.48/feed')/Path(item['path']).name
    assert sha(source)==item['sha256'],'Replacement location must contain exact inspected bytes'
    target=root/'feed'/source.name;assert not target.exists();shutil.copyfile(source,target);assert sha(target)==item['sha256']
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
        libraries={name:hashlib.sha256(z.read(name)).hexdigest() for name in z.namelist() if name.endswith('.dll')}
    packages[item['package']]=dict(version=item['version'],revision=item['repository']['commit'],sha256=item['sha256'],libraries=libraries,addedMembers=item['addedMembers'],removedMembers=item['removedMembers'],copiedFrom=str(source))
normal=[Path('Directory.Packages.props'),Path('src/Lokad.Lython.Utf8Regex/Utf8RegexProvider.cs'),Path('src/Lokad.Lython.Utf8Regex/Lokad.Lython.Utf8Regex.csproj')]
identity=dict(consumerHead=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),consumerPrototype='R30 prepared class own-cell fact; same source as focused-initial checks',developmentOnly=True,normalPin='0.4.0 unchanged',normalInputs={str(p):sha(p) for p in normal},packages=packages,baseProviderSHA256=sha(root/'Utf8RegexProvider.cs'),preparationCorrection='Producer moved exact inspected packages out of attempt directory; initial empty-feed restore failed before compilation, original log retained; all package hashes identical at candidate path')
(root/'consumer.patch').write_bytes(subprocess.check_output(['git','-c','core.safecrlf=false','diff','--','src']))
(root/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Exact inspected dev48 bytes copied and verified',flush=True)
