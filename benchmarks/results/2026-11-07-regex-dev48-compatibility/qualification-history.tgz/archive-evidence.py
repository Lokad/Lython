from pathlib import Path
import hashlib,json,shutil,tarfile
root=Path('.git/agent-notes/review-20261031/regex-dev48');out=Path('benchmarks/results/2026-11-07-regex-dev48-compatibility');out.mkdir()
i=json.loads((root/'identity.json').read_text(encoding='utf-8'));q=json.loads((root/'qualification.json').read_text(encoding='utf-8'))
for name,digest in i['normalInputs'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest
for framework in ['net11.0','net10.0']:
    assert q['checks']['Lokad.Lython.Tests-'+framework]['passed']==85
    assert q['checks']['Lokad.Lython.PublicApi.Tests-'+framework]['passed']==488
for name in ['identity.json','qualification.json']:shutil.copyfile(root/name,out/name)
with tarfile.open(out/'qualification-history.tgz','w:gz') as a:
    for p in root.iterdir():
        if p.is_file():a.add(p,arcname=p.name)
    for p in (root/'locks').glob('*.json'):a.add(p,arcname='locks/'+p.name)
    for name in ['prepare-dev48.py','correct-dev48-preparation.py','dev48-package-inspection.json']:
        a.add(root.parent/name,arcname=name)
archive=out/'qualification-history.tgz'
(out/'sha256.json').write_text(json.dumps({archive.name:hashlib.sha256(archive.read_bytes()).hexdigest()},indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Immutable regex development package compatibility — dev48

2026-11-07. The isolated optional adapter consumes exact0.5.0-dev.48 Core/PythonRe
packages fromf6b2175ea1715e12fcab0e6fa7dcd556ddbe5f40. Package and loaded DLL hashes
are recorded in identity.json/qualification.json. Consumer source is e9b55acd plus
the R30 prepared-class-fact prototype recorded in the history patch; this is not
full qualification of that runtime prototype. Normal0.4.0 pin, production adapter
source/project and central versions are hash-verified unchanged. Core stays free
of backend dependencies, adapter nonpackable. No sibling sources are modified.

The existing U04 development adapter is unchanged from dev46. Documented member
identities are unchanged; the producer's scalar matching refinement does not
remove the outstanding API limits. No new bridge or framework is introduced.

Release builds pass with zero warnings/errors. Per actual.NET11/.NET10,
85internal/488public selected tests pass: regex/fnmatch/glob, UTF8/scalar windows,
captures, in-flight cancellation, terminal admission refusal, retained caches and
native cursor working ownership/refund/reuse. The six extra public cases relative
to the earlier dev46 receipt are the already-delivered R29 ownership tests picked
up by the existing filter; this does not requalify old dev46 binaries.

DetailedData still lacks an independent preparation working owner; native group
names lack enumeration; cursor creation/current tokens retain mixed authority.
Conservative preflight, adapter-local conversions and the qualified CTS bridge
remain. No real-backend CPU gain, whole-script comparison, released-package
promotion or final managed-safety certification is claimed. These limits do not
block independent core development.

The producer moved the original attempt directory during preparation. Exact
previously inspected package bytes were found at its candidate location and
hash-verified before copying. The initial empty-feed restore failed; stale restore
state continued to fail until force evaluation. Every original failure, corrected
commands, private lockfile and successful log is preserved in the history archive.
No normal project output or dependency pin was changed by those corrections.
''',encoding='utf-8',newline='\n')
with Path('benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n') as f:f.write('''
## Immutable regex development compatibility (2026-11-07)

[Dev48](results/2026-11-07-regex-dev48-compatibility/README.md) consumes exact
producerf6b2175e packages in isolation:85internal/488public checks per actual
runtime pass. Normal0.4 pin/adapter unchanged. The documented API is unchanged;
working-owner/name-enumeration/cursor-token limitations remain. Preparation and
stale-restore failures are preserved. This is compatibility, not backend CPU,
release promotion or full runtime-prototype qualification.
''')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8').replace('Qualify exact packages privately on existing\nsemantic/cancellation/refusal suites, keep0.4 pin and nonpackable adapter unchanged.', 'Exact packages privately qualify85internal/488public per actual11/10 on existing\nsemantic/cancellation/refusal suites. Keep0.4 pin and nonpackable adapter unchanged.\nEvidence2026-11-07-regex-dev48-compatibility preserves original restore failures.')
p.write_text(s,encoding='utf-8',newline='\n')
print('Dev48 compatibility evidence archived; normal inputs verified unchanged.',flush=True)
