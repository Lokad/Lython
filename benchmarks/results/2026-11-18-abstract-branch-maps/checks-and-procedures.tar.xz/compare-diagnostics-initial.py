from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess

repo = Path.cwd()
work = repo / ".git/agent-worktrees/directive-presence-r547"
lab = repo / ".git/agent-notes/review-20261031/branch-state-r548"
base = lab.parent / "directive-presence-r547/frozen/candidate/Lokad.Lython.dll"
tool = work / "tools/LythonProbe/bin/Release/net11.0"
sdk = Path.home() / ".dotnet11"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk),
           PATH=str(sdk) + os.pathsep + os.environ["PATH"])
candidate = tool / "Lokad.Lython.dll"
assert hashlib.sha256(base.read_bytes()).hexdigest().startswith("643f3980")
sources = [
    """if False:
    result: int = 'bad'
    def use():
        return local
        local = 1
def outer():
    nonlocal missing
""",
    """data = []
if unknown:
    data = [1]
else:
    data = []
print(data[0])
""",
]
for name in ["ClassScopeDirectiveTests", "ScopeDirectiveCompatibilityTests",
             "ShortCircuitRefinementTests", "SequenceLengthRefinementTests", "AnnotationFlowBoundaryTests"]:
    source = (repo / "tests/Lokad.Lython.PublicApi.Tests" / f"{name}.cs").read_text(encoding="utf-8")
    for text in re.findall(r'\[InlineData\(("(?:[^"\\]|\\.)*")', source):
        try:
            decoded = json.loads(text)
        except json.JSONDecodeError:
            continue
        sources.append(decoded)
        assert len(decoded) < 5000
sources = list(dict.fromkeys(sources))
assert len(sources) > 20
request = json.dumps(sources, ensure_ascii=False)
(lab / "probe-inputs.json").write_text(request, encoding="utf-8")
for mode in ["sync", "async"]:
    results = []
    for role, code in [("reference", base), ("candidate", candidate)]:
        image = lab / f"probe-{mode}-{role}"
        shutil.copytree(tool, image)
        shutil.copyfile(code, image / code.name)
        assert hashlib.sha256((image/code.name).read_bytes()).digest() == hashlib.sha256(code.read_bytes()).digest()
        args = [sdk/"dotnet.exe", image/"LythonProbe.dll", "--batch-json"]
        if mode == "async":
            args.append("--async")
        run = subprocess.run(args, input=request, text=True, encoding="utf-8", capture_output=True, env=env, timeout=30)
        (lab / f"probe-{mode}-{role}.jsonl").write_text(run.stdout, encoding="utf-8")
        assert run.returncode in (0, 1) and not run.stderr, (run.returncode, run.stderr)
        responses = [json.loads(line) for line in run.stdout.splitlines()]
        assert len(responses) == len(sources) and "diagnostics" in responses[0], responses[0]
        results.append(responses)
    differences = [(index,a["diagnostics"],b["diagnostics"]) for index,(a,b) in enumerate(zip(*results))
                   if a["diagnostics"] != b["diagnostics"]]
    assert not differences, differences
    print(mode, len(sources), "identical ordered diagnostic probes")

