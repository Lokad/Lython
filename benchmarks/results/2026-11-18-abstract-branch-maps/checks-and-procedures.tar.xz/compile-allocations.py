from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(".git/agent-notes/review-20261031/branch-state-r548").resolve()
donor = lab.parent / "frontend-dispatch-r527"
project = lab / "compile-allocation"
project.mkdir(exist_ok=False)
for name in ["Program.cs", "compile-allocation.csproj", "packages.lock.json"]:
    shutil.copyfile(donor / "compile-allocation" / name, project / name)
program = project / "Program.cs"
s = program.read_text(encoding="utf-8")
i = s.index("    if (id is not ")
j = s.index("    var source = ", i)
program.write_text(s[:i] + s[j:], encoding="utf-8", newline="\n")
dotnet = Path.home()/".dotnet11"/"dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent),
           PATH=str(dotnet.parent) + os.pathsep + os.environ["PATH"])
identity = json.loads((lab / "frozen-identity.json").read_text(encoding="utf-8"))
catalog = lab / "representative.json"
core = "Lokad.Lython.dll"
with (lab / "compile-allocation-build.log").open("w", encoding="utf-8") as log:
    subprocess.run([dotnet, "build", project / "compile-allocation.csproj", "-c", "Release",
                    "--no-incremental", f"-p:InspectionCorePath={str(lab/'frozen/reference'/core)}"],
                   env=env, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=90)
source = project / "bin/Release/net11.0"
for role in ["reference", "candidate"]:
    code = lab / "frozen" / role / core
    assert hashlib.sha256(code.read_bytes()).hexdigest() == identity["imageFiles"][role][core]
    output = lab / f"compile-{role}"
    shutil.copytree(source, output)
    shutil.copyfile(code, output / core)
    result = lab / f"{role}-compile-allocation.json"
    subprocess.run([dotnet, output / "compile-allocation.dll", catalog, result], env=env, check=True, timeout=60)
    data = json.loads(result.read_text(encoding="utf-8-sig"))
    assert data["coreSha256"] == identity["imageFiles"][role][core]
    assert len(data["rows"]) == 4 and all(row["allowanceBaselineRestored"] for row in data["rows"])
    print(role, [(row["id"], row["allocatedBytesPerCompilation"]) for row in data["rows"]])

