from pathlib import Path
import hashlib, json, shutil, subprocess, tarfile

lab = Path(__file__).resolve().parent
out = Path("benchmarks/results/2026-11-21-explicit-utf8-ownership")
def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

identity = load(lab/"identity-final.json")
assert identity["reference"].startswith("3a6accc97")
diff = subprocess.check_output(["git", "diff", "HEAD", "--", "src", "tests"])
assert diff == (lab/"measured.patch").read_bytes()
assert hashlib.sha256(diff).hexdigest() == identity["candidateSourcePatchSha256"]
for role, files in identity["imageFiles"].items():
    assert len(files) == 32 and {n:sha(lab/"frozen"/role/n) for n in files} == files
    proof = load(lab / f"{role}-verify-final.json")
    assert proof["state"] == "Completed" and proof["caseCount"] == 3
    assert proof["catalogSha256"] == identity["catalogSHA256"] == sha(lab/"representative.json")
for platform in ("win", "ubuntu"):
    for suite, count in (("white", 501), ("public", 2397)):
        log = (lab / f"{suite}-{platform}.log").read_text(encoding="utf-8-sig")
        assert "Passed!" in log and f"Passed: {count:5d}, Skipped:" in log
allocation = load(lab/"allocation-summary-final.json")
assert len(allocation)==3 and all(case["allowanceRestored"] for case in allocation)
out.mkdir(exist_ok=True)
shutil.copyfile(lab/"README.md", out/"README.md")
shutil.copyfile(lab/"allocation-summary-final.json", out/"allocation-summary.json")
with tarfile.open(out/"checks-and-procedures.tar.xz", "w:xz", preset=6) as archive:
    for folder in (lab, lab/"pre-immutable-bytes-fix"):
        for path in sorted(folder.iterdir()):
            if path.is_file() and path.suffix not in {".dll", ".xz"}:
                archive.add(path, arcname=path.relative_to(lab).as_posix())
print("Six workload verifications, exact source patch and focused Release checks verified.")
