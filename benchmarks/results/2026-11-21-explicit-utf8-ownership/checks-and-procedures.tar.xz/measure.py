from pathlib import Path
import hashlib
import json
import os
import shutil
import statistics
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.parent / "inline-keyword-default-20261121"
dotnet = Path.home() / ".dotnet11/dotnet.exe"
python = Path("C:/Python313/python.exe")
protocol = repo / "benchmarks/cpython-worker.py"
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent),
           PATH=str(dotnet.parent) + os.pathsep + os.environ["PATH"])

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def sha_bytes(content):
    return hashlib.sha256(content).hexdigest()

def load(p):
    return json.loads(p.read_text(encoding="utf-8-sig"))

def save(p, value):
    p.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8", newline="\n")

reference = subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip()
assert reference.startswith("3a6accc97")
patch = subprocess.check_output(["git", "diff", "HEAD", "--", "src", "tests"], cwd=repo)
assert patch
(lab / "measured.patch").write_bytes(patch)
catalog = load(donor / "representative.json")
template = catalog["cases"][0]
json_prefix = """import json
values = [str(123456789012345678 + i) for i in range(768)]
document = '[' + ','.join(values) + ']'
"""
cases = [
    ("scripts.json.numeric-callback-retained", json_prefix+"""seen = []
def convert(token):
    seen.append(token)
    return int(token[-3:])
result = json.loads(document, parse_int=convert)
print(len(result), sum(result), seen[0], seen[-1])
"""),
    ("scripts.textwrap.indent-predicate-retained", """import textwrap
line = 'identifier température on sensor 12345678901234567890\\n'
document = line * 768
seen = []
def select(value):
    seen.append(value)
    return len(seen) % 2 == 0
result = textwrap.indent(document, '> ', select)
print(len(result), len(seen), len(seen[-1]), result.count('> '))
"""),
    ("scripts.json.numeric-default-control", json_prefix+"""result = json.loads(document)
print(len(result), sum(result), result[0], result[-1])
"""),
]
catalog["cases"] = []
for case_id, code in cases:
    outcome = subprocess.run([python, "-X", "utf8", "-I", "-c", code], check=True, capture_output=True, timeout=15)
    stdout = outcome.stdout.replace(b"\r\n", b"\n")
    assert not outcome.stderr
    fixture = json.loads(template["fixtureJson"])
    fixture["size"] = 768
    fixture_json = json.dumps(fixture, separators=(",", ":"))
    catalog["cases"].append(dict(template, id=case_id, size=768, source=code, sourceUtf8Bytes=len(code.encode("utf-8")),
        sourceSha256=sha_bytes(code.encode("utf-8")), expectedOutput=stdout.decode("utf-8"),
        expectedOutputUtf8Bytes=len(stdout), expectedOutputSha256=sha_bytes(stdout),
        fixtureJson=fixture_json, fixtureSha256=sha_bytes(fixture_json.encode("utf-8"))))
manifest = lab / "representative.json"
save(manifest, catalog)

identity = load(donor / "identity.json")["imageFiles"]["reference"]
donated = donor / "frozen/reference"
assert len(identity) == 32 and {name: sha(donated / name) for name in identity} == identity
images = {}
core = "Lokad.Lython.dll"
for role in ("reference", "candidate"):
    image = lab / "frozen" / role
    image.mkdir(parents=True, exist_ok=True)
    for name in identity:
        origin = repo / "src/Lokad.Lython/bin/Release/net11.0" / name if role == "candidate" and name == core else donated / name
        shutil.copyfile(origin, image / name)
    images[role] = {name: sha(image / name) for name in identity}
    for path in donated.glob("ValidatedAllocation.*"):
        shutil.copyfile(path, image / path.name)
    receipt = lab / f"{role}-verify-final.json"
    subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog", manifest,
         "--dotnet", dotnet, "--python", python, "--python-worker", protocol, "--out", receipt],
         env=env, check=True, timeout=70)
    proof = load(receipt)
    assert proof["state"] == "Completed" and proof["caseCount"] == len(cases) and proof["catalogSha256"] == sha(manifest)
    subprocess.run([dotnet, image / "ValidatedAllocation.dll", image, manifest, lab / f"{role}-allocation-final.json"],
                   env=env, check=True, timeout=90)
    assert {name: sha(image / name) for name in identity} == images[role]
assert [name for name in identity if images["reference"][name] != images["candidate"][name]] == [core]
save(lab / "identity-final.json", dict(reference=reference, candidateSourcePatchSha256=sha_bytes(patch),
     catalogSHA256=sha(manifest), imageFiles=images))
before, after = [load(lab / f"{role}-allocation-final.json")["rows"] for role in ("reference", "candidate")]
result = []
for left, right in zip(before, after, strict=True):
    assert left["id"] == right["id"] and left["sharedBudgetBaselineRestored"] and right["sharedBudgetBaselineRestored"]
    start, end = [statistics.median(row["allocatedBytesPerInvocation"]) for row in (left, right)]
    result.append(dict(case=left["id"], reference=start, candidate=end, allocationChangePercent=100*(end/start-1),
                       referenceAccountedPeak=left["peakExecutionMemoryBytes"], candidateAccountedPeak=right["peakExecutionMemoryBytes"],
                       allowanceRestored=True))
    print(result[-1], flush=True)
save(lab / "allocation-summary-final.json", result)
