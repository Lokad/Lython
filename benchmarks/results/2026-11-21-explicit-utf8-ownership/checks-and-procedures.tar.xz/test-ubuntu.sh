set -euo pipefail
cd /mnt/d/code/Lython
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/explicit-utf8-ownership-20261121
filter='Category!=Stress&(FullyQualifiedName~String|FullyQualifiedName~Textwrap|FullyQualifiedName~Urllib|FullyQualifiedName~RegexReplacement|FullyQualifiedName~Json|FullyQualifiedName~Typing|FullyQualifiedName~TextCodec|FullyQualifiedName~Stdin|FullyQualifiedName~SysModuleFunction|FullyQualifiedName~Utf8ByteDecode)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter "$filter" --verbosity quiet > "$logs/white-ubuntu.log" 2>&1
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter "$filter" --verbosity quiet > "$logs/public-ubuntu.log" 2>&1
grep 'Passed!' "$logs/white-ubuntu.log" "$logs/public-ubuntu.log"
