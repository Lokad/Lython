from pathlib import Path
import gzip, hashlib, json, shutil, subprocess, tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
source=lab.parent/'native-dict-item-cursor'
template=lab.parent/'native-text-dict-keys-cpython'
q=lab/'quiet'
previous=template/'quiet-space-verified'
def read(p): return p.read_text(encoding='utf-8')
def load(p): return json.loads(read(p))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def emit(p,s):
    if p.suffix=='.py': compile(s,str(p),'exec')
    p.write_text(s,encoding='utf-8',newline='\n')
def save(p,v): emit(p,json.dumps(v,indent=2,ensure_ascii=False)+'\n')
index=load(source/'identity.json')
revision=index['candidate']
assert revision.startswith('5901c06bd')
assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=repo/'.git/agent-worktrees/native-dict-item-cursor')
verified=load(source/'candidate-verify.json')
assert index['candidate']==revision and verified['state']=='Completed'
files=index['imageFiles']['candidate']
image=source/'frozen/candidate'
assert len(files)==32 and {n:sha(image/n) for n in files}==files
assert verified['catalogSha256']==index['catalogSHA256']==sha(source/'representative.json')
assert index['pythonWorkerSHA256']==sha(repo/'benchmarks/cpython-worker.py')
staging=load(source/'quiet/config.json')
receipt=load(source/'quiet/archive-receipt.json')
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
assert receipt['archiveSHA256']==sha(source/'quiet/observations.tgz')
q.mkdir()
identity=dict(sourceRevision=revision,imageSource=revision,purpose='JSON normalization after the dictionary cursor against stock CPython',
              imageFiles=dict(candidate=files),catalogSHA256=index['catalogSHA256'],cpythonWorkerSHA256=index['pythonWorkerSHA256'],
              auxiliaryFiles={name:digest for name,digest in files.items() if name!='Lokad.Lython.dll'},
              coreSHA256={name:files['Lokad.Lython.dll'] for name in ('candidate','candidate-control')})
save(q/'identity.json',identity)
shutil.copyfile(repo/'benchmarks/cpython-worker.py',q/'cpython-worker.py')

prior=load(previous/'config.json')
root='/home/lokad/lython-bench-checks/normalize-json-cpython-b1252-20261120'
unit='lython-b1252-normalize-json-cpython-20261120'
normalize='scripts.json-normalized-records.large'
validator='scripts.config-generated-guards.medium.bad-0'
for name in ('collect.py','archive-owned.py','retrieve.py','run.sh'):
    s=read(previous/name).replace(prior['root'],root).replace(prior['unit'],unit).replace('B1248','B1252')
    if name == 'collect.py':
        s=s.replace(validator,normalize).replace('scripts.report-render.alternating-records',validator)
        s=s.replace('n*.4/', 'n*.65/')
    if name == 'run.sh':
        assert '\r' not in s
    emit(q/name,s)
assert b'\r' not in (q/'run.sh').read_bytes()
parts=('identity.json','collect.py','archive-owned.py','run.sh','cpython-worker.py')
archive=q/'payload.tgz'
with tarfile.open(archive,'w:gz') as f:
    for n in parts: f.add(q/n,arcname=n)
config=dict(root=root,unit=unit,identity=identity,source=staging['root'],sourceRole='candidate',
            sourceFiles=files,sourceCatalogSHA256=identity['catalogSHA256'],catalogSHA256=identity['catalogSHA256'],
            cpythonWorkerSHA256=identity['cpythonWorkerSHA256'],retireGroups=[],donorArchiveSHA256=receipt['archiveSHA256'],
            payloadBytes=archive.stat().st_size,payloadSHA256=sha(archive),unpackedBytes=sum((q/n).stat().st_size for n in parts))
save(q/'config.json',config)
s=read(previous/'remote-launch.py')
a,b=s.index('\nc=')+1,s.index('\nb=Path(')
s=(s[:a]+'c='+repr(config)+s[b:]).replace('lython-b1248-fixtures','lython-b1252-fixtures')
s=s.replace("176160768+c['unpackedBytes']+64*1024*1024","176160768+c['unpackedBytes']+32*1024*1024")
emit(q/'remote-launch.py',s)
launch=read(template/'launch-space-verified.py').replace("parent/'quiet-space-verified'","parent/'quiet'")
emit(lab/'launch.py',launch.replace('Corrected B1248 validator and shipment','B1252 JSON normalization and validator'))
