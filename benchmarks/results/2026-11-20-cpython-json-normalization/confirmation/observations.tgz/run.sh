set -eu
root=/home/lokad/lython-bench-checks/normalize-json-cpython-confirm-b1253-20261120
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
