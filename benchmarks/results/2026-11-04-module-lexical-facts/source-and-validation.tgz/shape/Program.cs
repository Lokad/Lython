using System.Collections;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;
const BindingFlags Flags=BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic;
static object? Get(object o,string name)=>o.GetType().GetProperty(name,Flags)!.GetValue(o);
static object[] Items(object o,string name)=>((IEnumerable)Get(o,name)!).Cast<object>().ToArray();
static long Stride(Type t) {
    _=Array.CreateInstance(t,4096);
    var start=GC.GetAllocatedBytesForCurrentThread();var a=Array.CreateInstance(t,4096);var large=GC.GetAllocatedBytesForCurrentThread()-start;
    start=GC.GetAllocatedBytesForCurrentThread();var b=Array.CreateInstance(t,0);var small=GC.GetAllocatedBytesForCurrentThread()-start;
    GC.KeepAlive(a);GC.KeepAlive(b);return (large-small)/4096;
}
var asm=typeof(LythonEngine).Assembly;
if(asm.GetType("Lokad.Lython.Frontend.NativeReturnNode") is not null)throw new InvalidOperationException("obsolete native graph type remains");
var instructionBytes=Stride(asm.GetType("Lokad.Lython.Frontend.ExecutableInstruction")!);
var syntaxArgumentBytes=Stride(asm.GetType("Lokad.Lython.Frontend.CallArgumentForm")!);
var executableArgumentBytes=Stride(asm.GetType("Lokad.Lython.Frontend.ExecutableCallArgument")!);
using var catalog=JsonDocument.Parse(File.ReadAllBytes(args[0]));var cases=new List<object>();
foreach(var item in catalog.RootElement.GetProperty("cases").EnumerateArray()) {
    using var script=new LythonEngine().Compile(item.GetProperty("source").GetString()!);
    if(!script.IsValid)throw new InvalidOperationException(JsonSerializer.Serialize(script.Diagnostics));
    var runner=(Delegate)typeof(LythonCompiledScript).GetField("_runner",Flags)!.GetValue(script)!;
    var executable=runner.Target!.GetType().GetField("executableScript",Flags)!.GetValue(runner.Target)!;
    var codes=new List<object>();var seen=new HashSet<object>(ReferenceEqualityComparer.Instance);Visit(Get(executable,"EntryPoint")!);
    cases.Add(new{id=item.GetProperty("id").GetString(),codes});
    void Visit(object code) {
        if(!seen.Add(code))return;var instructions=Items(code,"Instructions");var root=(int?)Get(code,"NativeReturnRoot");
        var listing=instructions.Select((op,index)=>new {index,op=Get(op,"OpCode")!.ToString(),inputStart=Get(op,"InputStart"),resultSlot=Get(op,"ResultSlot"),liveExtent=Get(op,"LiveExtent"),nativeFirst=(int)Get(op,"NativeFirst")!,nativeSecond=(int)Get(op,"NativeSecond")!}).ToArray();
        var packets=new List<object>();
        if(root is int r && r>=0)foreach(var row in listing) {
            if(row.nativeFirst>=row.index || row.nativeSecond>=row.index)throw new InvalidOperationException("forward native edge");
            if(row.op!="Call")continue;
            var site=Items(code,"CallSites")[(int)Get(instructions[row.index],"CallSiteIndex")!];
            var arguments=Items(site,"Arguments").Select(a=>(int)Get(a,"NativeSourceInstruction")!).ToArray();
            if(arguments.Any(a=>a<0 || a>=row.index))throw new InvalidOperationException("bad native argument edge");
            packets.Add(new{row.index,arguments});
        }
        var shape=new{scopeFacts=Get(code,"ScopeFacts"),isFunctionScope=Get(code,"IsFunctionScope"),entryIndex=Get(code,"EntryIndex"),regions=Items(code,"ExceptionRegions"),localNames=Items(code,"LocalNames"),closureNames=Items(code,"ClosureNames"),capturedSlots=Items(code,"CapturedLocalSlots"),fields=instructions.Select(op=>op.GetType().GetFields(Flags).ToDictionary(field=>field.Name,field=>root is null && (field.Name is "_nativeFirst" or "_nativeSecond")?(object)(-1):field.GetValue(op))).ToArray(),arguments=Items(code,"CallSites").Select(site=>Items(site,"Arguments").Select(arg=>arg.GetType().GetFields(Flags).ToDictionary(field=>field.Name,field=>root is null && field.Name.Contains("NativeSourceInstruction",StringComparison.Ordinal)?(object)(-1):field.GetValue(arg))).ToArray()).ToArray()};
        codes.Add(new{shape,name=Get(code,"Name"),nativeReturnRoot=root,instructionCount=listing.Length,locals=Items(code,"LocalNames").Length,operandCapacity=Get(code,"OperandCapacity"),listing,packets});
        foreach(var function in Items(code,"Functions"))Visit(Get(function,"CodeObject")!);
        foreach(var statement in Items(code,"StatementFallbacks"))VisitClass(statement);
        foreach(var value in Items(code,"Constants"))if(value is not null && value.GetType().GetProperty("CodeObject",Flags) is {} c)Visit(c.GetValue(value)!);
        void VisitClass(object statement) {
            if(statement.GetType().Name!="LoweredClassDefinitionStatement")return;
            foreach(var child in Items(statement,"Body")) {
                if(child.GetType().Name=="LoweredFunctionDefinitionStatement")Visit((Get(child,"PreparedCode")??Get(child,"GeneratorCode"))!);
                else VisitClass(child);
            }
        }
    }
}
Console.WriteLine(JsonSerializer.Serialize(new{runtime=System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription,coreSHA256=Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(asm.Location))),instructionBytes,syntaxArgumentBytes,executableArgumentBytes,cases},new JsonSerializerOptions{WriteIndented=true}));
