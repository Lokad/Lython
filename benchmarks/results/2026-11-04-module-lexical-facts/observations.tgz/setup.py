from pathlib import Path
import hashlib
root=Path('/home/lokad/lython-bench-checks/lexical-module-b211-20261104')
base=Path('/home/lokad/lython-bench-checks/analysis-cache-b210-20261104/candidate')
(root/'baseline').symlink_to(base,target_is_directory=True)
for path in base.iterdir():
 if path.name in ('Lokad.Lython.dll','Lokad.Lython.pdb'):continue
 (root/'candidate'/path.name).symlink_to(path.resolve(),target_is_directory=path.is_dir())
