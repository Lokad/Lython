from pathlib import Path
import json,os,subprocess,xml.etree.ElementTree as ET,shutil
r=Path(__file__).parent;env={k:v for k,v in os.environ.items()if k.lower()!='path'};env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+os.environ.get('PATH','');sdk=env['DOTNET_ROOT']+'/dotnet.exe';rows=[]
with(r/'probe10-build.log').open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([sdk,'build','tools/LythonProbe/LythonProbe.csproj','-c','Release','-f','net10.0','--no-restore','--disable-build-servers','-m:1','-v','quiet'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
assert done.returncode==0,(r/'probe10-build.log').read_text(encoding='utf-8')[-2000:]
for framework in ['net11.0','net10.0']:
 for project,selection in [('Lokad.Lython.Tests','FullyQualifiedName~CasedSplitOwnershipTests'),('Lokad.Lython.PublicApi.Tests','FullyQualifiedName~RecursionDepthScenarioTests|FullyQualifiedName~RepeatedWideHelpersReleaseWorkingStorage')]:
  name='r359-extra-'+project+'-'+framework+'.trx';log=r/(name+'.log')
  with log.open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([sdk,'test','tests/'+project+'/'+project+'.csproj','-c','Release','-f',framework,'--no-restore','--filter',selection,'--logger','trx;LogFileName='+name,'-v','quiet'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
  assert done.returncode==0,log.read_text(encoding='utf-8')[-3000:]
  trx=Path('tests')/project/'TestResults'/name;ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};counts=ET.parse(trx).find('.//t:Counters',ns).attrib;assert counts['failed']=='0'and int(counts['passed'])>0;shutil.copyfile(trx,r/name);rows.append(dict(framework=framework,project=project,counters=counts));(r/'extra-checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n');print(project,framework,counts['passed'],'additional checks pass',flush=True)
