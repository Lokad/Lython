from pathlib import Path
import os,re,json,subprocess,textwrap,hashlib
r=Path(__file__).parent
p=r/'verify-worker.py';s=p.read_text(encoding='utf-8').replace("r.parent.parent/'utf8-byte-ownership-r334", "r.parent/'utf8-byte-ownership-r334");p.write_text(s,encoding='utf-8',newline='\n')
env={k:v for k,v in os.environ.items()if k.lower()!='path'};env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+os.environ.get('PATH','')
for name in ['verify-worker.py','measure-allocation.py']:subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/name)],check=True,env=env)
snippets=json.loads((r.parent/'loop-local-storage-r358/python-control-sources.json').read_text(encoding='utf-8'))
body=Path('tests/Lokad.Lython.PublicApi.Tests/IntegerPublicationTests.cs').read_text(encoding='utf-8');extra=[textwrap.dedent(s)+'\n'for s in re.findall(r'yield return \["""\n(.*?)\n\s*"""\];',body,re.S)];assert len(extra)==6;snippets+=extra
(r/'python-control-sources.json').write_text(json.dumps(snippets,indent=2)+'\n',encoding='utf-8',newline='\n');probe=Path('tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll').resolve();rows=[]
for asynchronous in [False,True]:
 done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe',str(probe),'--batch-json','--compare-python','--python','C:/Python313/python.exe']+(['--async']if asynchronous else[]),input=json.dumps(snippets).encode(),capture_output=True,env=env,timeout=30)
 (r/('python-controls-'+str(asynchronous)+'.jsonl')).write_bytes(done.stdout);(r/('python-controls-'+str(asynchronous)+'.stderr')).write_bytes(done.stderr);assert done.returncode==0,(done.stdout+done.stderr).decode('utf-8');rows.append(dict(asynchronous=asynchronous,cases=16,matched=True,exitCode=0))
(r/'python-controls.json').write_text(json.dumps(dict(complete=True,python='Isolated stock CPython3.13.2',cases=rows,coreSHA256=hashlib.sha256((probe.parent/'Lokad.Lython.dll').read_bytes()).hexdigest()),indent=2)+'\n',encoding='utf-8',newline='\n')
print('32 independent Python controls match both APIs.',flush=True)
