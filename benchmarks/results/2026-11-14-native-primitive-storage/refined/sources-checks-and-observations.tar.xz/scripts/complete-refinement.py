from pathlib import Path
import ast
r=Path(__file__).parent
s=(r/'refine.py').read_text(encoding='utf-8').replace("out=r/'publication'","out=r/'complete'")
s=s.replace("assert changed==['src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeIntegers.cs']","assert set(changed)=={'src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeIntegers.cs','src/Lokad.Lython/Runtime/PyExecutableFunction.cs','src/Lokad.Lython/Frontend/ExecutableScript.cs'}")
s=s.replace('FullyQualifiedName~Integer|FullyQualifiedName~NumericArithmetic','FullyQualifiedName~Native|FullyQualifiedName~Integer|FullyQualifiedName~NumericArithmetic')
s=s.replace("identity.update(sources=sources,coreSHA256=", "identity.update(sources=sources,changedProductionInputs=[n for n in sources if sources[n]!=__import__('json').loads((r.parent/'machine-integer-kernel-r357/nonthrowing/candidate-identity.json').read_text(encoding='utf-8'))['sources'].get(n)],coreSHA256=")
s=s.replace('Primitive publication now calls the authoritative Publish path, removing duplicated retirement/store-checkpoint/PC logic. Original6c35 measurements and regression debt retained; one bounded affected-workload confirmation, not another general campaign.','Primitive publication shares authoritative Publish; compiler eligibility scan also computes required primitive capacity, eliminating working storage for helpers that cannot write it. No additional analysis pass or skip after refusal. Original6c35 measurements/debt and untimed ca82publication-only variant preserved. One bounded affected-workload confirmation.')
ast.parse(s);p=r/'run-complete-refinement.py';assert not p.exists();p.write_text(s,encoding='utf-8',newline='\n')
exec(compile(s,str(p),'exec'))
