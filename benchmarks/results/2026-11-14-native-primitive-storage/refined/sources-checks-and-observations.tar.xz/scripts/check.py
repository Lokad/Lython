from pathlib import Path
import json,os,subprocess,xml.etree.ElementTree as ET,shutil
r=Path(__file__).parent
env={k:v for k,v in os.environ.items()if k.lower()!='path'};env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+os.environ.get('PATH','');sdk=env['DOTNET_ROOT']+'/dotnet.exe';records=[]
filters={
 'internal':'FullyQualifiedName~CapturedScalar|FullyQualifiedName~NativeIntegerChainTests|FullyQualifiedName~IntegerBinaryAdmissionTests|FullyQualifiedName~ExecutableAugmentedIntegerBoundaryTests|FullyQualifiedName~Stack',
 'public':'(Category!=Stress)&(FullyQualifiedName~Integer|FullyQualifiedName~NumericArithmetic|FullyQualifiedName~CounterArithmetic|FullyQualifiedName~ForHelperExecutionTests|FullyQualifiedName~WhileHelperExecutionTests|FullyQualifiedName~LargeHelperExecutionTests|FullyQualifiedName~OperatorProtocol|FullyQualifiedName~CapturedScalarExecutionTests|FullyQualifiedName~NativeTupleReturnTests|FullyQualifiedName~LoopLocalValueTests|FullyQualifiedName~UnboundLocalVariableTests|FullyQualifiedName~Stack)'}
for framework in ['net11.0','net10.0']:
 for label in ['internal','public']:
  project='Lokad.Lython.Tests'if label=='internal'else'Lokad.Lython.PublicApi.Tests';name='r359-'+label+framework+'.trx'
  command=[sdk,'test','tests/'+project+'/'+project+'.csproj','-c','Release','-f',framework,'--no-restore','--filter',filters[label],'--logger','trx;LogFileName='+name,'-v','quiet']
  with(r/(label+'-'+framework+'.log')).open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run(command,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
  assert done.returncode==0,(r/(label+'-'+framework+'.log')).read_text(encoding='utf-8')[-4000:]
  trx=Path('tests')/project/'TestResults'/name;ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};counts=ET.parse(trx).find('.//t:Counters',ns).attrib;shutil.copyfile(trx,r/name)
  assert counts['failed']=='0'and int(counts['passed'])>0;records.append(dict(framework=framework,label=label,counters=counts));(r/'focused-checks.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n');print(label,framework,counts['passed'],'pass',flush=True)
