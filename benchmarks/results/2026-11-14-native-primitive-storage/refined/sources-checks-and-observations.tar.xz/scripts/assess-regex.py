from pathlib import Path
import hashlib,json,subprocess
repo=Path('D:/code/utf8regex');out=Path('benchmarks/results/2026-11-14-regex-provider-capabilities');base=json.loads((out/'source-update-e8b20aa5.json').read_text(encoding='utf-8'))
run=lambda *args:subprocess.check_output(['git','-C',str(repo),*args])
head=run('rev-parse','HEAD').decode().strip();assert head.startswith('70ea16b2')
prefix='src/Lokad.Utf8Regex.PythonRe/'
files={name:hashlib.sha256(run('show',head+':'+prefix+name)).hexdigest()for name in base['integrationFiles']}
prior={name:hashlib.sha256(run('show',base['sourceHead']+':'+prefix+name)).hexdigest()for name in files}
assert files==prior
diff=run('diff',base['sourceHead'],head,'--',prefix).decode('utf-8')
publicChanges=[s for s in diff.splitlines()if s.startswith(('+','-'))and not s.startswith(('+++','---'))and 'public 'in s]
assert not publicChanges,publicChanges
names=run('diff','--name-only',base['sourceHead'],head,'--',prefix).decode().splitlines()
cursor=run('show',head+':'+prefix+'Utf8PythonMatchCursor.cs').decode('utf-8');assert 'ExchangeCancellationToken' in cursor
text='''\nRead-only [70ea16b2/dev90 source inspection](source-update-70ea16b2.json) finds\ncoordinate preparation/publication changes in nine integration files. The three\nAPI entry files remain byte-identical; the precise ownership, UTF8 group-name\nenumeration and cursor-construction cancellation gaps remain. This is not a\npackage, semantics, interruption, performance or safety qualification. Independent\nLython development and adapter-local bridges remain available.\n'''
data=dict(dateUTC='2026-11-14',sourceHead=head,baseline=base['sourceHead'],integrationFiles=files,hashBoundary='Git blob bytes, not earlier Windows CRLF worktree hashes; compared like-for-like with baseline Git blobs.',baselineIntegrationFiles=prior,changedIntegrationFiles=names,integrationProjectSourceDiffEmpty=False,changedPublicDeclarationLines=publicChanges,remainingIntegrationGaps=base['remainingIntegrationGaps'],qualification='Read-only source/API comparison. Coordinate preparation/publication implementations changed. No producer build/package/source equivalence, semantics, interruption latency, performance or managed-safety qualification. Completed dev80 qualification not repeated.',coreDependencyChanged=False,normalAdapterPinChanged=False,affectedFinalAdapterQualificationOnly=True)
(out/'source-update-70ea16b2.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8',newline='\n')
p=out/'README.md';s=p.read_text(encoding='utf-8');assert text not in s;p.write_text(s+text,encoding='utf-8',newline='\n');print('Precisely recorded changed implementation and unchanged API gaps; no sibling edits or dependency promotion.')
