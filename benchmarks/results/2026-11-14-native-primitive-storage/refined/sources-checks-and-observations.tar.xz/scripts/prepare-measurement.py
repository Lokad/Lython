from pathlib import Path
import ast,base64,datetime,hashlib,io,json,subprocess,tarfile
r=Path(__file__).parent;out=r/'b734';out.mkdir(exist_ok=False);old=r.parent/'loop-local-storage-r358/refined/b733'
source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert all(sha(p)==v for p,v in source['sources'].items())
allocation=json.loads((r/'allocation-summary.json').read_text(encoding='utf-8'));assert allocation['complete']and allocation['allWorkersJoinedAndFixturesRemoved'];assert json.loads((r/'python-controls.json').read_text(encoding='utf-8'))['complete']
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'));identity.update(sourceRevision='R359uncommitted/frozen'+source['coreSHA256']['candidate'][:8]+' vs fully qualified47df7e19/frozencbb254be',purpose='Native primitive working storage without private heap cells/grants: complete counter/CSVwhile warm/fresh, fulfillment/text/JSON and short-zero/observed controls. Same source/data per runtime; normal GC. Allocation separate, no CPython/startup/tail claim.',coreSHA256={label:source['coreSHA256']['candidate'if label.startswith('candidate')else'reference']for label in ['reference','candidate','reference-control','candidate-control']},catalogSHA256=sha(r/'catalog.json'),fullSourceIdentitySHA256=sha(r/'candidate-identity.json'),publicationHeld=True)
assert all(source['auxiliaryFiles'][role][n]==v for role in ['reference','candidate']for n,v in identity['auxiliaryFiles'].items())
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
root='/home/lokad/lython-bench-checks/primitive-storage-b734-20261114';unit='lython-b734-primitive-storage-20261114'
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=(old/name).read_text(encoding='utf-8').replace('loop-locals-b733-20261114','primitive-storage-b734-20261114').replace('lython-b733-loop-locals-20261114',unit).replace('B733','B734').replace('Owned B724','Owned B734')
 if name.endswith('.py'):ast.parse(s)
 (out/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
 for n in ['identity.json','collect.py','archive-owned.py','run.sh']:t.add(out/n,arcname=n)
 t.add(r/'candidate-core.dll',arcname='candidate-core.dll');t.add(r/'catalog.json',arcname='representative.json')
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();p=Path('benchmarks/results/2026-11-14-loop-local-cells/sources-checks-and-observations.tar.xz');blob=subprocess.check_output(['git','show',head+':'+p.as_posix()]);assert hashlib.sha256(blob).hexdigest()==sha(p)
with tarfile.open(fileobj=io.BytesIO(blob),mode='r:xz')as t:
 member='refined/candidate-core.dll';body=t.extractfile(member).read()
proof=dict(commit=head,canonicalArchive=p.as_posix(),archiveSHA256=sha(p),member=member,bytes=len(body),sha256=hashlib.sha256(body).hexdigest());assert proof['sha256'].startswith('97f5ecc1');proof.update(coreSHA256=proof['sha256'],reason='Retire only withdrawn97f5 working-core hardlinks after exact committed canonical source/binary proof. Preserve fully qualifiedcbb2/current6c35 and all auxiliaries/catalog/toolchain/254and252MiBfloors.')
config=dict(root=root,sourceRoot='/home/lokad/lython-bench-checks/machine-kernel-b732-20261114',unit=unit,identity=identity,proof=proof,duplicates=[],payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=sha(out/'payload.tgz'),unpackedBytes=unpacked)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
code=(old/'launch-command.py').read_text(encoding='utf-8');start=code.index('c=');end=code.index('\nbase=',start);code=code[:start]+'c='+repr(config)+code[end:]
code=code.replace('b733-proved-superseded-working-copy-retirement-20261114','b734-proved-withdrawn-working-copy-retirement-20261114').replace('lython-b733-fixtures','lython-b734-fixtures').replace('R358eight-job source pair launched','R359eight-job source pair launched');ast.parse(code);(out/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
(out/'prospective.json').write_text(json.dumps(dict(purpose=identity['purpose'],source=identity['sourceRevision'],bound='One420sowner/360sjob-startguard,8jobs/fourfreshprocesses,5sfull-requestwarmup/12scapturedtext,five0.5srotatingbatches. Existing workers/protocol/normalGC/tiering.',retirement=proof,stopping='Usable source pair or supported uncertainty. Decide coherent transport/refinement/regression debt; no percentage veto. No automatic restart. Full delivery only after retention; publication held.',earlierExperiment='R358heapcells withdrawn for short-zero/observedhelper and fulfillmentregressions. This replaces per-callheapcells/grants, not retiming the same code.'),indent=2)+'\n',encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
done=subprocess.run(ssh+[command],input=(out/'payload.tgz').read_bytes(),capture_output=True,timeout=60);(out/'launch.log').write_bytes(done.stdout+done.stderr);assert done.returncode==0,(done.stdout+done.stderr).decode()
now=datetime.datetime.now(datetime.timezone.utc);(out/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=360)).isoformat(),ownerSeconds=420),indent=2)+'\n',encoding='utf-8',newline='\n')
print(done.stdout.decode(),flush=True);print('Earliest observation',(now+datetime.timedelta(seconds=360)).isoformat(),flush=True)
