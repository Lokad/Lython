from pathlib import Path
import ast,hashlib,json,os,shutil,subprocess,tarfile,xml.etree.ElementTree as ET
r=Path(__file__).parent;out=r/'complete';out.mkdir();old=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
sources={n:sha(n)for n in old['sources']};changed=[n for n in sources if sources[n]!=old['sources'][n]];assert set(changed)=={'src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeIntegers.cs','src/Lokad.Lython/Runtime/PyExecutableFunction.cs','src/Lokad.Lython/Frontend/ExecutableScript.cs'}
env={k:v for k,v in os.environ.items()if k.lower()!='path'};env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+os.environ.get('PATH','');sdk=env['DOTNET_ROOT']+'/dotnet.exe';rows=[]
for framework in ['net11.0','net10.0']:
 project='Lokad.Lython.PublicApi.Tests';name='r359-publication-'+framework+'.trx';log=out/(framework+'.log')
 with log.open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([sdk,'test','tests/'+project+'/'+project+'.csproj','-c','Release','-f',framework,'--no-restore','--filter','(Category!=Stress)&(FullyQualifiedName~Native|FullyQualifiedName~Integer|FullyQualifiedName~NumericArithmetic|FullyQualifiedName~ForHelperExecutionTests|FullyQualifiedName~WhileHelperExecutionTests|FullyQualifiedName~LargeHelperExecutionTests|FullyQualifiedName~NativeTupleReturnTests|FullyQualifiedName~LoopLocalValueTests|FullyQualifiedName~Stack|FullyQualifiedName~RecursionDepthScenarioTests)','--logger','trx;LogFileName='+name,'-v','quiet'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 assert done.returncode==0,log.read_text(encoding='utf-8')[-3000:]
 trx=Path('tests')/project/'TestResults'/name;counts=ET.parse(trx).find('.//{http://microsoft.com/schemas/VisualStudio/TeamTest/2010}Counters').attrib;assert counts['failed']=='0';shutil.copyfile(trx,out/name);rows.append(dict(framework=framework,counters=counts));print(framework,counts['passed'],'refined focused checks pass',flush=True)
(out/'focused-checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
with(out/'freeze-build.log').open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([sdk,'build','tools/LythonProbe/LythonProbe.csproj','-c','Release','-f','net11.0','--no-restore','--no-incremental','--disable-build-servers','-m:1','-v','quiet'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
assert done.returncode==0 and sources=={n:sha(n)for n in sources}
for role in ['reference','candidate']:shutil.copytree(r/'reference',out/role)
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',out/'candidate/Lokad.Lython.dll');shutil.copyfile(out/'candidate/Lokad.Lython.dll',out/'candidate-core.dll')
identity=dict(old);identity.update(sources=sources,changedProductionInputs=[n for n in sources if sources[n]!=__import__('json').loads((r.parent/'machine-integer-kernel-r357/nonthrowing/candidate-identity.json').read_text(encoding='utf-8'))['sources'].get(n)],coreSHA256={role:sha(out/role/'Lokad.Lython.dll')for role in ['reference','candidate']},qualified=False,refinement='Primitive publication shares authoritative Publish; compiler eligibility scan also computes required primitive capacity, eliminating working storage for helpers that cannot write it. No additional analysis pass or skip after refusal. Original6c35 measurements/debt and untimed ca82publication-only variant preserved. One bounded affected-workload confirmation.')
(out/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'candidate-sources.tar.xz','w:xz')as t:
 for n in sources:t.add(n,arcname=n)
for name in ['catalog.json','allocation-reference-catalog.json','allocation-candidate-catalog.json','measure-allocation.py']:shutil.copyfile(r/name,out/name)
shutil.copyfile(r/'verify-worker.py',out/'verify-worker.py');p=out/'verify-worker.py';s=p.read_text(encoding='utf-8').replace("r.parent/'utf8-byte-ownership-r334","r.parent.parent/'utf8-byte-ownership-r334");p.write_text(s,encoding='utf-8',newline='\n');ast.parse(s)
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(out/'verify-worker.py')],check=True,env=env)
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(out/'measure-allocation.py')],check=True,env=env)
print('Frozen simplified publication',identity['coreSHA256'],flush=True)
