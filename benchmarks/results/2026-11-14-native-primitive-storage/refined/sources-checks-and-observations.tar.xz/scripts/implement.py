from pathlib import Path
import hashlib,json,subprocess

root=Path(__file__).parent
names=['Runtime/PyExecutableFunction.cs','Runtime/LythonRuntime.Executable.NativePrefix.cs','Runtime/LythonRuntime.Executable.IntegerChains.cs']
base=root/'baseline';base.mkdir(exist_ok=True)
for name in names:
 p=Path('src/Lokad.Lython')/name;q=base/name;q.parent.mkdir(parents=True,exist_ok=True);assert not q.exists();q.write_bytes(p.read_bytes())
(root/'base.json').write_text(json.dumps(dict(revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),sources={n:hashlib.sha256((base/n).read_bytes()).hexdigest()for n in names}),indent=2)+'\n',encoding='utf-8')
def change(name,old,new):
 p=Path('src/Lokad.Lython')/name;s=p.read_text(encoding='utf-8');assert s.count(old)==1,(name,old[:120],s.count(old));p.write_text(s.replace(old,new),encoding='utf-8',newline='\n')

change(names[0],'''        var state = new LythonRuntime.NativeExecution(this, values, consumedByIteration, unpackedReturn.Length);''','''        // Only this synchronous prefix can borrow primitive working storage.
        // Publication/transfer materializes stable guest objects before escape.
        // The common fixed buffer has a bounded managed stack cost; larger
        // bound calls admit their complete working capacity before allocation.
        Span<long> fixedIntegers = stackalloc long[LythonRuntime.NativeValueCapacity];
        using var integerStorage = values.Length > LythonRuntime.NativeValueCapacity
            ? Closure.MemoryGovernor.ReserveTemporary(checked(32L + sizeof(long) * (long)values.Length), span) : null;
        if (integerStorage is not null) Closure.CheckExecution(span);
        Span<long> integers = values.Length <= LythonRuntime.NativeValueCapacity
            ? fixedIntegers[..values.Length] : new long[values.Length];
        var state = new LythonRuntime.NativeExecution(this, values, integers, consumedByIteration, unpackedReturn.Length);''')

change(names[1],'''    internal ref partial struct NativeExecution(PyExecutableFunction function, Span<object> values,
        bool consumedByIteration, int unpackedReturnCount)''','''    internal ref partial struct NativeExecution(PyExecutableFunction function, Span<object> values,
        Span<long> integers, bool consumedByIteration, int unpackedReturnCount)''')
change(names[1],'''        internal readonly Span<object> Values = values;''','''        internal readonly Span<object> Values = values;
        private readonly Span<long> _integers = integers;
        private bool _hasIntegers;''')
change(names[1],'''                        var first = Read(instruction.InputStart, 0);
                        var second = Read(instruction.SecondInput, 1);
                        var augmented = instruction.OpCode == ExecutableOpCode.Augmented;
                        if (!augmented && TryIntegerChain(Code, Values, Index, first, second, _scope, out var end, out var integerResult))
                        {
                            Index = end;
                            Publish(Code.Instructions[end], (System.Numerics.BigInteger)integerResult);
                            break;
                        }''','''                        if (TryIntegerOperation(instruction)) break;
                        var first = Read(instruction.InputStart, 0);
                        var second = Read(instruction.SecondInput, 1);
                        var augmented = instruction.OpCode == ExecutableOpCode.Augmented;''')
change(names[1],'''                        var first = Read(instruction.InputStart, 0);
                        var second = Read(instruction.SecondInput, 1);
                        if (!TryEvaluateScalarComparison(instruction.BinaryOperator, first, second, _scope, instruction.Span, out var truth)) return false;
                        Trim(instruction.LiveExtent);''','''                        bool truth;
                        if (!TryIntegerComparison(instruction, out truth))
                        {
                            var first = Read(instruction.InputStart, 0);
                            var second = Read(instruction.SecondInput, 1);
                            if (!TryEvaluateScalarComparison(instruction.BinaryOperator, first, second, _scope, instruction.Span, out truth)) return false;
                        }
                        Trim(instruction.LiveExtent);''')
change(names[1],'''                        if (TryReturnUnpackedTuple(instruction)) return true;
                        var tuple''','''                        MaterializeRange(instruction.InputStart, instruction.ItemCount);
                        if (TryReturnUnpackedTuple(instruction)) return true;
                        var tuple''')
change(names[1],'''                        var items = Values.Slice(instruction.InputStart, instruction.ItemCount).ToArray();''','''                        MaterializeRange(instruction.InputStart, instruction.ItemCount);
                        var items = Values.Slice(instruction.InputStart, instruction.ItemCount).ToArray();''')
change(names[1],'''            var value = Values[source];
            Values[source] = null!;
            Trim(liveExtent);''','''            var value = Read(source, 0);
            Values[source] = null!;
            Trim(liveExtent);''')
change(names[1],'''            var start = instruction.InputStart;
            var target = Values[start + call.TargetOffset];''','''            var start = instruction.InputStart;
            MaterializeRange(start, call.ArgumentOffset + call.ArgumentCount);
            var target = Values[start + call.TargetOffset];''')
change(names[1],'''            var value = Values[source];
            if (value is null && source < Code.FirstTemporarySlot)''','''            var value = Materialize(source);
            if (value is null && source < Code.FirstTemporarySlot)''')
change(names[1],'''        private object ReadLocal(int slot, LythonSourceSpan span) => Values[slot]''','''        private object ReadLocal(int slot, LythonSourceSpan span) => Materialize(slot)''')
change(names[1],'''        internal void PrepareTransfer() => Values[LiveExtent..].Clear();''','''        internal void PrepareTransfer()
        {
            // No primitive marker or borrowed working span enters a heap frame.
            MaterializeRange(0, LiveExtent);
            Values[LiveExtent..].Clear();
        }''')

change(names[2],'''        end = index;
        result = 0;
        ref readonly var first = ref code.Instructions[index];''','''        if (TryMachineInteger(left, out var a) && TryMachineInteger(right, out var b))
            return TryIntegerChain(code, values, default, index, a, b, scope, out end, out result);
        end = index;
        result = 0;
        return false;
    }

    private static bool TryIntegerChain(ExecutableCodeObject code, ReadOnlySpan<object> values,
        ReadOnlySpan<long> integers, int index, long left, long right, ExecutionContext scope,
        out int end, out long result)
    {
        end = index;
        result = 0;
        ref readonly var first = ref code.Instructions[index];''')
change(names[2],'''            || !ContinuesIntegerChain(code, code.Instructions[index + 1], first.ResultSlot)
            || !TryMachineInteger(left, out var a) || !TryMachineInteger(right, out var b)) return false;

        long accumulator;
        if (!TryMachineBinary(first.BinaryOperator, a, b, out accumulator)) return false;''','''            || !ContinuesIntegerChain(code, code.Instructions[index + 1], first.ResultSlot)) return false;

        long accumulator;
        if (!TryMachineBinary(first.BinaryOperator, left, right, out accumulator)) return false;''')
change(names[2],'''            var other = otherSlot < 0 ? code.Constants[~otherSlot] : values[otherSlot];
            if (!TryMachineInteger(other, out var operand)) return false;
            a = next.InputStart == first.ResultSlot ? accumulator : operand;
            b = next.SecondInput == first.ResultSlot ? accumulator : operand;''','''            if (!TryReadMachineOperand(code, values, integers, otherSlot, out var operand)) return false;
            var a = next.InputStart == first.ResultSlot ? accumulator : operand;
            var b = next.SecondInput == first.ResultSlot ? accumulator : operand;''')

p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeIntegers.cs');assert not p.exists();p.write_text('''using System.Numerics;
using Lokad.Lython.Frontend;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    // This sentinel exists only in a synchronous native prefix. Its primitive
    // payload is in that activation's borrowed working span, never a guest cell.
    private static readonly object NativeInteger = new();

    private static bool TryReadMachineOperand(ExecutableCodeObject code, ReadOnlySpan<object> values,
        ReadOnlySpan<long> integers, int source, out long value)
    {
        var stored = source < 0 ? code.Constants[~source] : values[source];
        if (ReferenceEquals(stored, NativeInteger))
        {
            value = integers[source];
            return true;
        }
        return TryMachineInteger(stored, out value);
    }

    internal ref partial struct NativeExecution
    {
        private bool TryIntegerOperation(in ExecutableInstruction instruction)
        {
            if (!TryReadMachineOperand(Code, Values, _integers, instruction.InputStart, out var left)
                || !TryReadMachineOperand(Code, Values, _integers, instruction.SecondInput, out var right)) return false;
            if (instruction.OpCode == ExecutableOpCode.Binary)
            {
                if (TryIntegerComparison(instruction.BinaryOperator, left, right, instruction.Span, out var truth))
                { Publish(instruction, RuntimeValue(truth)); return true; }
                if (TryIntegerChain(Code, Values, _integers, Index, left, right, _scope, out var end, out var chained))
                {
                    Index = end;
                    PublishInteger(Code.Instructions[end], chained);
                    return true;
                }
            }
            var operation = instruction.OpCode == ExecutableOpCode.Augmented
                ? AugmentedBinaryOperator(instruction.AugmentedOperator) : instruction.BinaryOperator;
            if (!TryMachineBinary(operation, left, right, out var result)) return false;
            // A declined chain can have inspected a successful prefix, but has
            // neither published it nor advanced the current instruction.
            PublishInteger(instruction, result);
            return true;
        }

        private bool TryIntegerComparison(in ExecutableInstruction instruction, out bool result)
        {
            result = false;
            return TryReadMachineOperand(Code, Values, _integers, instruction.InputStart, out var left)
                && TryReadMachineOperand(Code, Values, _integers, instruction.SecondInput, out var right)
                && TryIntegerComparison(instruction.BinaryOperator, left, right, instruction.Span, out result);
        }

        private bool TryIntegerComparison(BinaryOperatorSyntax operation, long left, long right,
            LythonSourceSpan span, out bool result)
        {
            result = false;
            if (!IsScalarComparison(operation)) return false;
            _scope.CheckExecution(span);
            result = CompareOrderedResult(operation, left.CompareTo(right));
            return true;
        }

        private void PublishInteger(in ExecutableInstruction instruction, long value)
        {
            var slot = instruction.ResultSlot;
            if (instruction.HasLocalResult)
            {
                if (instruction.LiveExtent < LiveExtent) Trim(instruction.LiveExtent);
                Values[slot] = null!;
                LiveExtent = slot;
                ref readonly var store = ref Code.Instructions[Index + 1];
                _scope.CheckExecution(store.Span);
                slot = store.LocalSlot;
                Index++;
            }
            else
            {
                if (instruction.LiveExtent < LiveExtent) Trim(instruction.LiveExtent);
                LiveExtent = instruction.LiveExtent;
            }
            _integers[slot] = value;
            Values[slot] = NativeInteger;
            _hasIntegers = true;
        }

        private object? Materialize(int slot)
        {
            var value = Values[slot];
            if (ReferenceEquals(value, NativeInteger))
            {
                // Cache the immutable object before any alias can observe it.
                // Machine values use the same minor-storage headroom as the
                // ordinary kernel; larger magnitudes retain its major preflight.
                value = (BigInteger)_integers[slot];
                Values[slot] = value;
            }
            return value;
        }

        private void MaterializeRange(int start, int count)
        {
            if (!_hasIntegers) return;
            for (var i = start; i < start + count; i++) _ = Materialize(i);
        }
    }
}
''',encoding='utf-8',newline='\n')

plan=Path('PLAN.md');s=plan.read_text(encoding='utf-8');s=s.replace('private machine integers beside those slots: bounded managed native working\n   storage, and substantial frame capacity admitted through the existing owner.','private machine integers beside those slots: fixed managed native working\n   storage and an admitted temporary array for larger bound calls. Materialize\n   before ordinary frame transfer; no working span or marker survives suspension.');s=s.replace('Source gate identifies seven local-read occurrences including their common','Active private prototype: stable materialization at native observation/copy/\n   call/return/ordinary-frame transfer. No ordinary-frame representation change.\n   Source gate identified seven local-read occurrences including their common');plan.write_text(s,encoding='utf-8',newline='\n')
print('R359 native primitive transport prototype written; no ordinary-frame or call-ABI change.',flush=True)
