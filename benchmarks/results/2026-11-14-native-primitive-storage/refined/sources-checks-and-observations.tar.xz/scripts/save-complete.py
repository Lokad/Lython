from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;stage=r/'complete';root=Path('benchmarks/results/2026-11-14-native-primitive-storage');out=root/'refined';out.mkdir();identity=json.loads((stage/'candidate-identity.json').read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert all(sha(p)==v for p,v in identity['sources'].items())
status=json.loads((stage/'b735/terminal-status.json').read_text(encoding='utf-8'));assert status['exitCode']=='0'and status['receipt']['complete']and not status['remainingWorkers']and not status['remainingFixtures']and not status['remainingTrace'];assert sha(stage/'b735/observations.tgz')==status['receipt']['archiveSHA256']
checks=json.loads((stage/'focused-checks.json').read_text(encoding='utf-8'))+json.loads((stage/'internal-checks.json').read_text(encoding='utf-8'));assert sum(int(v['counters']['passed'])for v in checks)==6086;assert json.loads((stage/'python-controls.json').read_text(encoding='utf-8'))['complete']
decision=dict(status='Retain coherent native primitive transport; full delivery qualification pending',frozenCore=identity['coreSHA256']['candidate'],reference='Fully qualified47df7e19/frozencbb254be',productionInputs=582,changedInputs=identity['changedProductionInputs'],removed=['Per-update machine boxes until observation','New duplicated retirement/store-checkpoint/PC logic; publication shares existing path','Unused working storage for helpers that cannot write primitive slots, identified during existing eligibility pass','Original Native-only object-chain packaging; shared checked arithmetic/chain kernel retained'],contract='Final object-array argument spans and ordinary frames unchanged. Stable immutable materialization before aliases/calls/collections/returns/frame transfer. Fixed128B managed working buffer, or fully admitted temporary major capacity for larger bound helpers. Working allowance held uncommitted through users/cleanup; no marker/span across suspension. Earlier admission denial acceptable and documented, always terminal. No private heap cells/pools/hotness settings/heap tracing/new guest numeric type.',validation='6086focused actual11/10checks and32isolatedPythoncontrols; all14frozenworker goldens, budget cleanup, four allocationprocesses/reversedroles, B735all5jobs175.171s/allidentity/golden/quiet/join/archivegates.',evidence='CSVwarm21.07–22.99percentfaster/compile-run21.21–21.90percentfaster, widerCPU supports; allocation40.868percentless. No universal gain or CPython-ratio attribution.',regressionDebt='Retain short-zero3.70–10.19percentelapsed/CPU5.69–11.36 and observed2.29–3.97elapsed/CPU1.87–4.51 adverse. JSONelapsed−0.03..+1.93percent, CPU+0.69..+4.13 adverse. Text remains uncertain from initialB734; not remeasured. No claim these costs are resolved.',debtDecision='Accept documented call-heavy/observed-value cost for this bounded representation milestone and substantial complete CSVgain; do not add cell pools/hotness policies or automatic unchanged retiming. Continue complete-call/frame/operand source gate and representative external checkpoint; decide final0.11regression debt explicitly before release. Ordinary frames still box after promotion, including inside-range counter.',untimedIntermediate='ca82publication-only source/focused/allocation evidence retained; no elapsed/CPU claim.',remaining='Full Windows/Ubuntu actual11/10, original stress and installed consumers at delivery, then representative CPython refresh and next substantial roadmap. Independent regex three precise final adapter gaps only.',publicationHeld=True)
(out/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['candidate-identity.json','focused-checks.json','internal-checks.json','allocation-summary.json','python-controls.json']:shutil.copyfile(stage/name,out/name)
shutil.copyfile(stage/'b735/summary.json',out/'timing-summary.json')
with tarfile.open(out/'sources-checks-and-observations.tar.xz','w:xz')as t:
 for folder,prefix in [(stage,'refined'),(r/'publication','publication-only')]:
  for p in sorted(folder.iterdir()):
   if p.is_file()and p.suffix in {'.py','.json','.jsonl','.stderr','.trx','.log','.xz','.dll'}:t.add(p,arcname=prefix+'/'+p.name)
 for p in sorted((stage/'b735').rglob('*')):
  if p.is_file():t.add(p,arcname='b735/'+p.relative_to(stage/'b735').as_posix())
 for p in sorted(r.glob('*.py')):t.add(p,arcname='scripts/'+p.name)
 for p in ['tests/Lokad.Lython.PublicApi.Tests/IntegerPublicationTests.cs','tests/Lokad.Lython.Tests/CasedSplitOwnershipTests.cs']:t.add(p,arcname=p)
shutil.copyfile(root/'README.md',root/'initial-README.md')
prior=(root/'README.md').read_text(encoding='utf-8');(root/'README.md').write_text('''# Native primitive working storage: retained, full delivery pending

2026-11-14 UTC, R359. Refined frozen `a4bfbfd8` versus fully qualified
`47df7e19` / frozen `cbb254be`; five changed production inputs. **Runtime retained;
full Windows/Ubuntu, stress and installed-consumer qualification is pending.**
Publication/tagging remain postponed. The complete
[initial comparison](initial-README.md), including every adverse result, remains.

The final object-array call interface and ordinary frame representation stay intact.
Native prefixes keep private machine values beside those slots, materializing and
caching a stable immutable identity before aliases, calls, collections, returns or
ordinary-frame transfer. No marker or working span survives suspension. Small
prefixes borrow at most 128 bytes of managed working storage; larger bound helpers
preflight temporary capacity and keep it reserved until all users/cleanup finish.
The existing eligibility scan computes storage need, so helpers that cannot write
this representation allocate none. Primitive/object publication share the same
retirement, store checkpoint and instruction advancement. No private heap cells,
cell pools, adaptive thresholds, argument repackaging or second evaluator.

## Bounded completion comparison

Same quiet F4as_v7, Ubuntu 24.04.4, EPYC 9V45, .NET 11 RC3, unchanged workers/
auxiliaries/catalog and normal GC/tiering as B734. Four fresh processes/job,
5-second full-request warmups, five rotating 0.5-second batches. B735 finishes
all five affected-workload jobs in 175.171 seconds, with all image/output/file/
budget/quiet/join/archive gates. No remaining workers or RAM fixtures. Raw SHA256
`6884b92cf22a9a2d20dd5699423d53bcbbcea1a059fa0b5a1a5cd47a76ce6d7b`.

| Complete script | Elapsed change | Wider CPU change |
| --- | ---: | ---: |
| 4,096-row CSV while validator, warm | −22.99..−21.07% | −22.43..−21.50% |
| Same CSV, compile-to-result | −21.90..−21.21% | −21.00..−19.22% |
| JSON helper summary | −0.03..+1.93% | +0.69..+4.13% |
| Repeated short/zero helpers | +3.70..+10.19% | +5.69..+11.36% |
| Helpers exposing each intermediate | +2.29..+3.97% | +1.87..+4.51% |

Ranges span all process-median pairings, not confidence intervals. Short-helper
process spread is 3.75% candidate / 2.37% reference; uncertainty does not erase its
adverse direction. JSON elapsed is near flat to adverse, with adverse wider CPU.
Text remains uncertain from B734 and was not remeasured. No universal gain,
resolved call overhead, cross-algorithm or refreshed CPython-ratio claim.

Warm clocks include mediated RAM-file I/O, full validation and result cleanup;
exclude compile/startup, fixture reset/protocol and final cache disposal.
Compile-to-result adds compilation/compiled-owner disposal; wider CPU includes
reset/protocol. Startup, pending I/O, contention, heap peaks and embedding tail
latency remain unmeasured. CSV uses the identical diagnostic while algorithm in
both runtimes, not a comparison against the different maintained for-loop source.

Four fresh allocation processes/reversed order show CSV allocation down 40.868%
(5,131,710.625 to 3,034,475.125–3,034,479 B/run), counter allocation flat. The
inside-range counter promotes before its loop; ordinary frames still box values.
6,086 focused actual .NET 11/10 checks and 32 independent CPython 3.13.2 controls
pass, including aliases/overflow/protocols, real asynchronous I/O/cancellation,
stack/recursion, terminal refusal, retained funding and budget cleanup. All 14
frozen worker goldens match. No timeout/assertion weakened. The intermediate
`ca82b162` publication-only variant is preserved with focused/allocation checks,
but has no CPU/elapsed comparison. A local pre-SSH preparation error used the
wrong member path for old canonical evidence; inventory correction preceded any
remote launch or measurement.

**Decision:** accept the recorded short/observed-helper and small JSON CPU debt
for this coherent representation milestone and substantial CSV gain. Do not hide
the costs behind pools, hotness settings or unchanged retiming. Full qualification
and a representative external checkpoint follow; the complete-call/frame/operand
roadmap remains active and final 0.11 regression debt needs an explicit decision.
Earlier denial from genuinely required larger temporary storage is documented;
refusal remains terminal and cleanup returns working allowance independently of GC.

[Decision/debt](refined/decision.json), [timing](refined/timing-summary.json),
[allocation](refined/allocation-summary.json), [exact sources/identity](refined/candidate-identity.json),
[public checks](refined/focused-checks.json), [internal checks](refined/internal-checks.json),
[sources/binaries/variants/tools/raw/failures](refined/sources-checks-and-observations.tar.xz).
''',encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');p.write_text(p.read_text(encoding='utf-8')+'''
R359 [refined completion](results/2026-11-14-native-primitive-storage/README.md)
retains `a4bfbfd8`: shared publication removes duplicate retirement/store/PC logic;
existing eligibility scan removes unused primitive storage. B735 five jobs complete
175.171 s/all gates; CSV warm 21–23% / compile-to-result 21–22% faster with CPU
support and 40.868% less allocation. Accept recorded short/zero 3.7–10.2%, observed
2.3–4.0% and small JSON CPU regression debt for this milestone; no universal gain
or resolved helper-overhead claim. 6,086 focused actual 11/10 checks and 32 Python
controls pass. Initial adverse data and untimed publication-only variant preserved.
Full delivery and external checkpoint follow; wider roadmap remains active.
''',encoding='utf-8',newline='\n')
print('Refined runtime retained with explicit regression debt; all sources/variants/raw preserved, full delivery pending.',flush=True)
