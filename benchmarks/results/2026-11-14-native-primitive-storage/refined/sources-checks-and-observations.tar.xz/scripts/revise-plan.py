from pathlib import Path
r=Path(__file__).parent;p=Path('PLAN.md');(r/'PLAN-before-readable-refresh.md').write_bytes(p.read_bytes())
p.write_text('''# Lokad.Lython 0.11.0

Updated 2026-11-14. Git-ignored; never force-add. Publication and tagging remain
postponed. The objective is coherent simplification and substantial complete-script
performance, including compile-once/run-once generated scripts. Closing one
experiment does not complete that objective. Current contracts belong in `docs/`;
experimental history belongs in [EXPERIMENTS](benchmarks/EXPERIMENTS.md) and linked
immutable evidence. Earlier plans are saved privately.

## Actual delivery status

| State | Result and limits |
| --- | --- |
| Completed and qualified | Shared compiler facts/nonlocal correction and lowered-tree retention cleanup; direct UTF-8 formatting/storage; native helper returns; final argument slots and linear continuations; immutable builtins; native loops/owned helpers; shared arithmetic; CSV array adoption/shared keys; UTF-8 JSON and incremental XML. Preserve their correctness fixes and cached qualification. |
| Important historical distinctions | Helper-return allocation fell approximately 19–20%; its original elapsed results remain diagnostic. Formatting allocation fell 8.67%; [controlled confirmation](benchmarks/results/2026-11-02-formatting-confirmation/README.md) supports report elapsed/CPU improvements of approximately 5–8%. The original adverse 15.125 ms observation remains unexplained and preserved. Neither result predicts today's HEAD. |
| Current fully qualified runtime | `47df7e19` / frozen `cbb254be`, production-identical through `d7d416d5`. The nonthrowing shared machine-integer kernel improves the complete numeric loop approximately 19.7–20.7%, with CPU support and flat allocation. Small adverse invoice/fulfillment CPU direction and variable text remain debt. [Full delivery](benchmarks/results/2026-11-14-shared-machine-integer-kernel/delivery/README.md): GREEN `43593185490`, Windows/Ubuntu, actual .NET 11/10, original stress and installed consumers. All 581 production inputs and 16 summaries cached; never requery the terminal run. |
| Latest external checkpoint | [CPython guide](docs/BENCHMARKS.md): exact historical `7e2f7cac` / frozen `72c9`, stock CPython 3.13.16, separate warm/compile/compile-to-result clocks. Nine jobs complete with all gates. Refresh after a material retained checkpoint; do not attribute later source-pair gains to these ratios. |
| Withdrawn, evidence and useful tests retained | R355 CSV raw-field ranges did not justify scratch/state costs. [R358 heap cells](benchmarks/results/2026-11-14-loop-local-cells/README.md) improved counters/CSV but regressed short helpers about 40–43% and ordinary workloads. All runtime changes removed; 581 source hashes restored, forced rebuilds/82 restored checks passed. Evidence and 12 independent public cases committed as `d7d416d5`; the discarded cell-admission architecture test was deleted. |
| Active private prototype, not delivered | R359 native primitive working storage, frozen `6c35b043` against `cbb254be`: four production inputs, 2,416 focused checks across actual .NET 11/10, 32 isolated CPython controls, all seven worker goldens and cleanup balances pass. CSV while-validator allocation falls approximately 40.9%; the inside-range counter remains flat because it promotes before its loop. B734's eight-job quiet-VM comparison is running; no CPU claim or full qualification yet. |

## Prioritized deliverables

1. **Finish R359's coherent primitive-storage decision.** Keep the existing final
   object-array argument/local slots and direct call spans. Private native machine
   integers use a fixed 128-byte managed buffer; larger bound calls admit their
   temporary array before allocation. No private heap cells, cell pool or per-call
   small-buffer grant. Stable immutable objects are cached before alias copies,
   calls, collection construction, returns and ordinary-frame transfer. No marker
   or working span survives suspension; ordinary frames retain their representation.

   Eliminate unobserved update boxes and displaced native arithmetic transport,
   sharing the checked arithmetic/chain kernel. Preserve exact overflow, bool/float
   distinctions, unbound errors, protocols, closures, generators, evaluation order,
   cancellation, terminal refusal, retained aliases and awaited cleanup. Larger
   working reservations remain uncommitted until scope exit; do not accumulate
   working charges. Validate the fixed stack cost against managed admission.

   **Completion:** inspect B734's complete counter/CSV/text/JSON and short/zero/
   observed-helper controls, with CSV compile-to-result separate. Decide retention,
   bounded refinement or withdrawal, and explicitly resolve any regression debt.
   Simplify duplicated publication logic if retained, removing the displaced path.
   Focused semantics/ownership/cancellation precede one coherent delivery boundary
   with Windows/Ubuntu, both runtimes, original stress and installed consumers.
   A useful prototype is not yet a released or fully qualified runtime.

2. **Continue the substantial roadmap after that decision.** Select whole stages
   supported by owning profiles and representative scripts, rather than accumulating
   call-site exceptions. Each selected milestone must state its hypothesis, removed
   work/storage/code, semantic/ownership acceptance, bounded source-pair controls
   and a final decision on temporary regression debt.

   | Area / scripts | Candidate work to eliminate; acceptance |
   | --- | --- |
   | Calls, frames and operand transport / helpers, search, invoices | Redundant activation/storage beyond delivered final slots/native prefixes. Preserve receiver/default/keyword errors, closure identity, managed stack admission and genuine suspension. R350/R354 did not establish a dominant removable full activation; do not revive the slower call-arena or call-control designs unchanged. |
   | Record construction / CSV/JSON aggregates and reports | A complete intermediate representation, copy or pass beyond current array adoption/shared keys. The earlier roughly 6–8% result merited reassessment, not automatic promotion; R355's later range design was withdrawn with adverse controls retained. Require callback, mutation/alias, pre-effect admission and replacement-overlap coverage, and delete the superseded constructor. |
   | Text / summaries, search and reports | A whole conversion/build stage. Preserve Unicode expansion/context, hooks/errors, cancellation and funded output. Earlier casing inventories expose scan/storage tradeoffs; reuse that evidence before another design. |
   | Frontend / fresh scripts | Demonstrated repeated facts or retained IR. Preserve scopes/nonlocals, diagnostics, cancellation and admission. Invoice compile is approximately 0.1 ms versus 7–8 ms execution: pass count alone does not establish dominance. |

   Imports already use executable code; bindings retain declarations and mirroring
   is demand-driven. Build on completed work. After a material retained milestone,
   refresh representative CPython comparisons with compilation, warm execution,
   I/O, validation, result cleanup and compiled/cache disposal boundaries explicit.

3. **Keep regex development independent.** The core owns Python semantics, native
   UTF-8, original-subject windows, byte/scalar coordinates, captures/errors,
   explicit owners and the current cancellation token. Development producers and
   adapter-local bridges remain acceptable; no core backend dependency. The normal
   optional non-packable adapter remains pinned to 0.4, with completed dev80 checks
   cached. [Latest source assessment](benchmarks/results/2026-11-14-regex-provider-capabilities/README.md)
   records changed coordinate/publication implementation at `70ea16b2`, without
   inferring package equivalence, safety, semantics or performance qualification.

   Only affected final released-adapter qualification waits for: separately funded
   one-match scratch/escaping results; native UTF-8 group-name enumeration/copy;
   token-independent cursor creation with cancellable preparation. Search filtering
   cannot implement anchored/fullmatch semantics. Cached patterns/cursors must not
   retain an earlier caller's token. None of these gaps stops independent Lython
   implementation, contract tests, semantic tests or performance investigation.

## Measurement and delivery rules

Architectural simplification, allocation reduction and demonstrated CPU improvement
are separate outcomes. A timeout, unstable unchanged control or inconclusive result
establishes uncertainty. Allow bounded confirmation, refinement or measurement
correction when justified; preserve all adverse samples and original failed
conditions. Percentages inform decisions, not automatic vetoes. No blanket
one-attempt, no-retiming or permanent-rejection rule; no open-ended campaign.

Use short focused Release checks during iteration and batch full qualification at
coherent retention checkpoints. Do not repeat cached checks. Force nonincremental
builds after restoration; freeze copies and verify the entire measured image.
Persist and verify evidence before owned RAM teardown. Preserve current images,
catalogs/toolchains and the existing 254/252 MiB VM floors. Startup, pending-I/O
latency, shared-budget contention, RSS/heap peaks and embedding tail latency remain
unmeasured. Publication/tagging stay postponed.

## Lasting constraints

[AGENTS.md](AGENTS.md) remains binding. Fully managed and memory-safe; no unsafe,
Unsafe APIs, pointers, P/Invoke or native probing. Preserve managed stack admission,
host mediation/original paths plus contained Cwd, cooperative cancellation, cycles,
XML depth, checked representation bounds and bounded I/O chunks. No fuel/quotas,
hidden caps/default allowance, regex work/time policy, tracing, weak reclamation,
forced GC or abandoned users. Borrowed allowance funds capacity, overlap, retained
aliases/results/caches and pending users. First refusal is terminal with its original
structured origin; await cleanup and never retry. Long streams use bounded host
commands. Only core is packaged; the optional adapter remains non-packable.
''',encoding='utf-8',newline='\n')
print('Readable 0.11.0 plan refreshed: qualified baseline, active R359, bounded decisions, independent regex and full roadmap.')
