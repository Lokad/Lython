from pathlib import Path
import ast,hashlib,json,re,shutil,tarfile

lab=Path(__file__).resolve().parent
prior=lab.parent/'prepared-format-selectors-r598'
previous=prior/'quiet'
quiet=lab/'quiet'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
read=lambda p:p.read_text(encoding='utf-8')
def write(path,source):
    if path.suffix=='.py':ast.parse(source)
    path.write_text(source,encoding='utf-8',newline='\n')
def save(path,data):write(path,json.dumps(data,ensure_ascii=False,indent=2)+'\n')

old=load(previous/'config.json')
screen=load(lab/'frozen-identity.json')
space=load(lab/'quiet-space.json')
catalog=lab/'catalog.json'
images=screen['images']
source_files=old['identity']['imageFiles']['candidate']
core='Lokad.Lython.dll'
assert screen['casesSHA256']==sha(catalog) and source_files==images['reference']
for role,files in images.items():
    assert len(files)==32 and files==source_files|{core:files[core]}
    assert {name:sha(lab/'frozen'/role/name) for name in files}==files
    verify=load(lab/f'{role}-verify.json')
    assert verify['state']=='Completed' and verify['catalogSha256']==sha(catalog)
candidate=lab/'frozen/candidate'/core
available=space['freeBytes']
need=254*1024*1024+candidate.stat().st_size+catalog.stat().st_size+524288+32000
selected=[]
for proof in sorted(space['replicas'],key=lambda p:-p['bytes']):
    if available>=need+49152:break
    assert proof['committedBlobVerified']
    available+=proof['bytes']
    selected.append(proof)
save(lab/'preflight.json',dict(available=available,need=need,withoutRetirement=space['freeBytes'],selected=selected))
assert available>=need,(available,need)

quiet.mkdir(exist_ok=False)
(quiet/'candidate').mkdir()
shutil.copyfile(candidate,quiet/'candidate'/core)
identity=dict(sourceRevision=screen['referenceCommit']+' versus '+screen['candidateCommit'],
              purpose='R599 expanded executable call runner',
              imageFiles=images,catalogSHA256=sha(catalog),normalAdapterPin='0.4.0',
              coreSHA256={label:images[role][core] for role in images for label in (role,role+'-control')})
root='/home/lokad/lython-bench-checks/expanded-call-runner-b1026-20261119'
unit='lython-b1026-expanded-call-runner-20261119'
jobs=[('scripts.report-forwarding.expanded', 'warm'), ('scripts.report-forwarding.expanded', 'compile-run'), ('scripts.report-forwarding.mutable-bound', 'warm'), ('scripts.report-forwarding.mutable-bound', 'compile-run'), ('scripts.report-render.large', 'warm'), ('calls.positional.large', 'warm')]
assert all(name in {case["id"] for case in load(catalog)["cases"]} for name,lane in jobs)
runner=read(previous/'collect.py').replace('< 300', '< 360').replace('Prepared format selectors source pair','Expanded executable calls source pair')
a=runner.index('\njobs = ')
b=runner.index('\nassert len(jobs)',a)
write(quiet/'collect.py',(runner[:a]+'\njobs = '+repr(jobs)+runner[b:]).replace('len(jobs)==7','len(jobs)==6'))
write(quiet/'archive-owned.py',read(previous/'archive-owned.py').replace("len(raw['jobs'])==7","len(raw['jobs'])==6").replace('jobs=7,','jobs=6,'))
write(quiet/'run.sh',read(previous/'run.sh').replace(old['root'],root))
save(quiet/'identity.json',identity)
shutil.copyfile(catalog,quiet/'representative.json')
names=['collect.py','archive-owned.py','run.sh','identity.json','representative.json','candidate/'+core]
payload=quiet/'payload.tgz'
with tarfile.open(payload,'w:gz') as out:
    for name in names:out.add(quiet/name,arcname=name)
expanded=sum((quiet/name).stat().st_size for name in names)
assert available>254*1024*1024+expanded+524288
config=dict(root=root,unit=unit,source=old['root'],sourceRole='candidate',sourceFiles=source_files,
            sourceCatalogSHA256=old['catalogSHA256'],catalogSHA256=sha(catalog),identity=identity,
            retireGroups=selected,payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),unpackedBytes=expanded)
save(quiet/'config.json',config)
launch=read(previous/'remote-launch.py')
a=launch.index('\nc=')+1
b=launch.index('\nb=Path(')
write(quiet/'remote-launch.py',re.sub(r'lython-b[0-9]+-fixtures','lython-b1026-fixtures',launch[:a]+'c='+repr(config)+launch[b:]))
write(lab/'launch-quiet.py',read(prior/'launch-quiet.py').replace('Prepared format selectors source pair','Expanded executable calls source pair').replace('345','295'))
write(quiet/'retrieve.py',read(previous/'retrieve.py').replace("==7","==6").replace('Prepared format selectors source pair','Expanded executable calls source pair'))
write(lab/'summarize-quiet.py',read(prior/'summarize-quiet.py').replace('==7','==6'))
print('Verified both full images and six jobs; bytes over staging floor:', available-254*1024*1024-expanded-524288)
