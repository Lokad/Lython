from pathlib import Path
import copy,hashlib,json,os,shutil,subprocess
lab=Path(__file__).resolve().parent
prior=lab.parent/'prepared-format-selectors-r598'
work=Path.cwd()/'.git/agent-worktrees/expanded-call-runner-r599'
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=load(prior/'frozen-identity.json')
reference=prior/'frozen/candidate'
core='Lokad.Lython.dll'
worker='Lokad.Lython.Benchmarks.dll'
reference_files=old['images']['candidate']
assert len(reference_files)==32 and all(sha(reference/name)==digest for name,digest in reference_files.items())
catalog=lab/'catalog.json'
inputs=load(lab.parent/'trailing-keyword-operands-r587/catalog.json')
assert len(inputs['cases'])==4,[x['id'] for x in inputs['cases']]
noncall=next(case for case in load(prior/'catalog.json')['cases'] if case['id']=='scripts.report-render.large')
inputs['cases'].append(noncall)
catalog.write_text(json.dumps(inputs,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')

def run(args, output):
    with (lab/output).open('wb') as log:
        subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=115,check=True)

images={}
for role in ['reference','candidate']:
    image=lab/'frozen'/role
    image.mkdir(parents=True,exist_ok=False)
    for name in reference_files:
        source=work/'src/Lokad.Lython/bin/Release/net11.0'/core if name==core and role=='candidate' else reference/name
        shutil.copyfile(source,image/name)
    for source in reference.glob('ValidatedAllocation.*'):shutil.copyfile(source,image/source.name)
    images[role]={name:sha(image/name) for name in reference_files}
    assert all(digest==reference_files[name] for name,digest in images[role].items() if name!=core)
    assert (images[role][core]!=reference_files[core])==(role=='candidate')
    run([dotnet,image/worker,'--compare','verify','--catalog',catalog,'--dotnet',dotnet,
         '--python','C:/Python313/python.exe','--python-worker',Path.cwd()/'benchmarks/cpython-worker.py',
         '--out',lab/(role+'-verify.json')],role+'-verify.log')
    verified=load(lab/(role+'-verify.json'))
    assert verified['state']=='Completed' and verified['catalogSha256']==sha(catalog)
    run([dotnet,image/'ValidatedAllocation.dll',image,catalog,lab/(role+'-allocation.json')],role+'-allocation.log')
    assert all(sha(image/name)==digest for name,digest in images[role].items())
candidate=subprocess.check_output(['git','-C',str(work),'rev-parse','HEAD'],text=True).strip()
identity=dict(referenceCommit='b8532e0ef',candidateCommit=candidate,
              casesSHA256=sha(catalog),images=images)
(lab/'frozen-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
print('Both full images and five script cases verified, including CPython goldens and scoped allocation.')
