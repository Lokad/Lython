from pathlib import Path
import base64,datetime,hashlib,io,json,subprocess,tarfile
r=Path(__file__).parent;config=json.loads((r/'config.json').read_text(encoding='utf-8'))
canonical=Path('benchmarks/results/2026-11-14-compiled-literal-tuples/initial/sources-checks-and-failed-observations.tar.xz');commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();blob=subprocess.check_output(['git','show',commit+':'+canonical.as_posix()]);assert hashlib.sha256(blob).digest()==hashlib.sha256(canonical.read_bytes()).digest()
with tarfile.open(canonical)as t:raw=t.extractfile('b722/failed-observations.tgz').read()
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz')as t:data=t.extractfile('collect.py').read()
proof=dict(canonicalCommit=commit,canonicalArchive=canonical.as_posix(),canonicalSHA256=hashlib.sha256(blob).hexdigest(),nestedMember='b722/failed-observations.tgz/collect.py',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),reason='One duplicate tool from closed failed B722; exact canonical bytes retained. B724 staging reached its final254MiBguard before mount/service start. Preserve that failure, revalidate same staged inputs and floor; no measurement restart or lowered guard.')
(r/'staging-correction-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
code=r'''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
config=CONFIG;proof=PROOF
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['sourceRoot']);digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert root.resolve()==root and root.parent==base
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 service=subprocess.run(['systemctl','show',config['unit']+'.service','--property=ActiveState,LoadState,MainPID'],capture_output=True,text=True).stdout
 assert'LoadState=not-found'in service and'MainPID=0'in service,service
 fixture=root/'guest-fixtures';assert fixture.is_dir()and not fixture.is_symlink()and not os.path.ismount(fixture)and not list(fixture.iterdir())
 assert json.loads((root/'identity.json').read_text())==config['identity']
 assert digest(root/'candidate/Lokad.Lython.dll')==config['identity']['coreSHA256']['candidate']
 for name,sha in config['identity']['auxiliaryFiles'].items():assert digest(root/'candidate'/name)==sha
 assert digest(root/'representative.json')==config['identity']['catalogSHA256']
 old=base/'literal-tuples-b722-20261114';p=old/'collect.py';s=p.lstat()
 assert json.loads((old/'failed-closure.json').read_text())['guestFixturesRemoved']and not(old/'guest-fixtures').exists()
 assert p.resolve()==p and p.is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_nlink==1
 assert s.st_size==proof['bytes']and digest(p)==proof['sha256']
 before=shutil.disk_usage(base).free;assert before+s.st_size>254*1024*1024+4096,(before,s.st_size)
 p.unlink();after=shutil.disk_usage(base).free;assert after>254*1024*1024
 receipt=dict(originalStagingStoppedBeforeMountOrService=True,originalFreeBytes=before,afterFreeBytes=after,retiredOnly=str(p),proof=proof,freshIdleLease=True,allStagedImagesCatalogsVerified=True,floorsUnchanged=True)
 (root/'space-preflight.json').write_text(json.dumps(receipt,indent=2)+'\n');assert shutil.disk_usage(base).free>254*1024*1024
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b724-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=480','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True))
'''.replace('CONFIG',repr(config)).replace('PROOF',repr(proof));compile(code,'finish-staging','exec');(r/'finish-staging-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=45);(r/'finish-staging.log').write_text(done.stdout+done.stderr,encoding='utf-8',newline='\n');assert done.returncode==0,done.stderr
now=datetime.datetime.now(datetime.timezone.utc);(r/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=360)).isoformat(),ownerSeconds=480,stopSeconds=30),indent=2)+'\n',encoding='utf-8',newline='\n')
(r/'prospective.json').write_text(json.dumps(dict(purpose='Changed coherent source checkpoint against CPython; same nine-job catalog/workers/toolchain and phase boundaries asB717, with full revision/qualification status.',source='7e2f7cac/frozen72c9a1e5',sourceProofCommit=config['identity']['sourceProofCommit'],sourceProofSHA256=config['identity']['sourceProofSHA256'],qualification='43579225278pending independently',bound='One480sowner;5sfull-request warmups,12s captured/report, five0.5srotating batches/four fresh processes per job. No cross-collection attribution.',staging='Original final254MiBguard stopped before mount/service. Failure preserved, one canonical-proven duplicate failed-collection tool retired, same staged hashes and unchanged floor verified. No measurement restart.',stopping='One usable current external snapshot, raw controls/adverse data and all ownership/quiet/cleanup gates. Qualification status stays distinct; no broad new benchmark campaign.',publicationHeld=True),indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');anchor='3. **Develop regex independently.**';assert anchor in s
s=s.replace(anchor,'''3. **R352 current CPython checkpoint active.** Committed7e2/frozen72c9 reuses
   the established nine-job catalog/workers/toolchains: representative CSV, text,
   JSON, search, report and for-loop validation, with invoice warm/compile/fresh
   separate. One480sowner; earliest observation'''+(now+datetime.timedelta(seconds=360)).strftime('%H:%M:%S')+'''UTC. No source-pair attribution.
   Qualify43579225278 independently; keep every variable/adverse control visible.
   First staging stopped at254MiBguard before mount/service; preserve failure.
   One canonical-proven duplicate old tool retired, same staged hashes/floor pass.
   No measurement restart/new image/catalog upload. Current images/catalogs,
   toolchain and254/252MiBfloors preserved. Update current guide with exact
   revision/status and I/O/cleanup boundaries after owned collection finishes.

4. **Develop regex independently.**''',1);p.write_text(s,encoding='utf-8',newline='\n')
print(done.stdout,flush=True);print('Observe after',(now+datetime.timedelta(seconds=360)).isoformat(),flush=True)
