from pathlib import Path
import ast,base64,datetime,hashlib,io,json,subprocess,tarfile
r=Path(__file__).parent;prior=r.parent/'iteration-checkpoint-r347/b717';runtime=r.parent/'literal-tuples-r351';stage=runtime/'corrected'
source=json.loads((stage/'candidate-identity.json').read_text(encoding='utf-8'));old=json.loads((prior/'identity.json').read_text(encoding='utf-8'))
identity=dict(sourceRevision='7e2f7cac/frozen72c9a1e5; full CI43579225278 pending',purpose='Coherent captured-cell/literal-construction checkpoint: refresh representative CPython comparisons and separate invoice compilation/compile-to-result. No cross-collection attribution; unchanged catalog/workers/toolchains.',coreSHA256={k:source['coreSHA256']['candidate']for k in ['reference','reference-control','candidate','candidate-control']},auxiliaryFiles=old['auxiliaryFiles'],catalogSHA256=old['catalogSHA256'],sourceIdentitySHA256=hashlib.sha256((stage/'candidate-identity.json').read_bytes()).hexdigest(),sourceProofSHA256=hashlib.sha256((runtime/'delivery/source-proof.json').read_bytes()).hexdigest(),sourceArchiveSHA256=hashlib.sha256((stage/'candidate-sources.tar.xz').read_bytes()).hexdigest(),sourceProofCommit='7e2f7cac0d69b833e94e7bc8cbf1450f9d044464',publicationHeld=True)
assert all(source['auxiliaryFiles']['candidate'][n]==sha for n,sha in identity['auxiliaryFiles'].items())
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=(prior/name).read_text(encoding='utf-8').replace('iteration-checkpoint-b717-20261114','literal-checkpoint-b724-20261114').replace('lython-b717-iteration-checkpoint-20261114','lython-b724-literal-checkpoint-20261114').replace('B717','B724')
 if name.endswith('.py'):ast.parse(s)
 (r/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(r/'payload.tgz','w:gz')as t:
 for name in ['identity.json','collect.py','archive-owned.py','run.sh']:t.add(r/name,arcname=name)
with tarfile.open(r/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
canonical=Path('benchmarks/results/2026-11-14-compiled-literal-tuples/sources-checks-and-observations.tar.xz');commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();blob=subprocess.check_output(['git','show',commit+':'+canonical.as_posix()]);assert hashlib.sha256(blob).digest()==hashlib.sha256(canonical.read_bytes()).digest()
with tarfile.open(canonical)as t:raw=t.extractfile('b723/observations.tgz').read()
names=['confirmation/confirmation.json','source-identity.json','identity.json','space-preflight.json','collect.py','archive-owned.py','run.sh']
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz')as t:data={n:t.extractfile(n).read()for n in names}
data['observations.tgz']=raw
proof=dict(canonicalCommit=commit,canonicalArchive=canonical.as_posix(),canonicalSHA256=hashlib.sha256(blob).hexdigest(),rawMember='b723/observations.tgz',files=[dict(path=name,bytes=len(value),sha256=hashlib.sha256(value).hexdigest())for name,value in data.items()],reason='Only duplicate completed B723 observations and their serialized metadata/tool copies, all immutable in canonical Git. Preserve current72c9/71ba/8ae images, all catalogs and toolchains. No new core upload or production change.')
(r/'retirement-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
config=dict(root='/home/lokad/lython-bench-checks/literal-checkpoint-b724-20261114',sourceRoot='/home/lokad/lython-bench-checks/literal-tuples-b723-20261114',catalogRoot='/home/lokad/lython-bench-checks/iteration-checkpoint-b717-20261114',unit='lython-b724-literal-checkpoint-20261114',identity=identity,proof=proof,payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((r/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(r/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
code=r'''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
config=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['sourceRoot']);catalog=Path(config['catalogRoot']);digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert root.parent==base and all(p.parent==base and p.resolve()==p for p in [source,catalog])and not root.exists()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert(source/'exit-code.txt').read_text().strip()=='0'and not(source/'guest-fixtures').exists()and json.loads((source/'archive-receipt.json').read_text())['complete']
 assert digest(source/'candidate/Lokad.Lython.dll')==config['identity']['coreSHA256']['candidate']
 for name,sha in config['identity']['auxiliaryFiles'].items():assert digest(source/'candidate'/name)==sha
 assert digest(catalog/'representative.json')==config['identity']['catalogSHA256']
 payload=sys.stdin.buffer.read(config['payloadBytes']+1);assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 paths=[]
 for entry in config['proof']['files']:
  p=source/entry['path'];s=p.lstat();assert p.resolve()==p and p.is_relative_to(source)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_nlink==1
  assert s.st_size==entry['bytes']and digest(p)==entry['sha256'];paths.append(p)
 before=shutil.disk_usage(base).free;assert before+sum(e['bytes']for e in config['proof']['files'])>254*1024*1024+config['unpackedBytes']
 for p in paths:p.unlink()
 receipt=dict(proof=config['proof'],freshIdleLease=True,allPathsUidsHashesProvedBeforeMutation=True,retiredOnly=[str(p)for p in paths],beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,allCurrentImagesCatalogsAndToolchainPreserved=True,floorsUnchanged=True)
 (base/'b724-proved-duplicate-retirement-20261114.json').write_text(json.dumps(receipt,indent=2)+'\n')
 assert shutil.disk_usage(base).free>254*1024*1024+config['unpackedBytes'];root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as t:t.extractall(root,filter='data')
 (root/'candidate').mkdir()
 for name in [*config['identity']['auxiliaryFiles'],'Lokad.Lython.dll']:os.link(source/'candidate'/name,root/'candidate'/name)
 os.link(catalog/'representative.json',root/'representative.json');os.link(source/'cpython-worker.py',root/'cpython-worker.py')
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture=root/'guest-fixtures';fixture.mkdir();assert shutil.disk_usage(base).free>254*1024*1024
 (root/'space-preflight.json').write_text(json.dumps(dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,noNewImageOrCatalogUpload=True,floorsUnchanged=True,retirementReceipt=receipt))+'\n')
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b724-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=480','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True))
'''.replace('CONFIG',repr(config));ast.parse(code);(r/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
done=subprocess.run(ssh+[command],input=(r/'payload.tgz').read_bytes(),capture_output=True,timeout=45);(r/'launch.log').write_bytes(done.stdout+done.stderr);assert done.returncode==0,(done.stdout+done.stderr).decode()
now=datetime.datetime.now(datetime.timezone.utc);(r/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=360)).isoformat(),ownerSeconds=480,stopSeconds=30),indent=2)+'\n',encoding='utf-8',newline='\n')
(r/'prospective.json').write_text(json.dumps(dict(purpose='Coherent new-runtime external checkpoint required by0.11plan, not another source-pair attribution or unchanged replay.',core='7e2f7cac/frozen72c9',qualification='CI43579225278pending independently',cases=9,bound='One480s owner, established5sfull-request warmups/12s captured and report, five0.5srotating batches/four processes. Separate invoice warm/compile/fresh; includeCSV/text/JSON/search/report/for-loop validation.',stopping='Finish one usable current external snapshot with raw controls and all failed/adverse conditions; no inferred speedup between collections and no broad extra qualification campaign.',publicationHeld=True),indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');anchor='3. **Develop regex independently.**';assert anchor in s
s=s.replace(anchor,'''3. **R352 current CPython checkpoint active.** Committed7e2/frozen72c9 reuses
   the established nine-job catalog/workers/toolchains: representative CSV, text,
   JSON, search, report and for-loop validation, with invoice warm/compile/fresh
   separate. One480sowner; earliest observation'''+(now+datetime.timedelta(seconds=360)).strftime('%H:%M:%S')+'''UTC. No source-pair attribution.
   Qualify43579225278 independently, keep every variable/adverse control explicit,
   update current guide only with exact revision/status and I/O/cleanup boundaries.
   No new image/catalog upload; only canonical-proven duplicate completed data/tool
   copies retired. Current images/catalogs/toolchain and254/252MiBfloors preserved.

4. **Develop regex independently.**''',1);p.write_text(s,encoding='utf-8',newline='\n')
print((done.stdout+done.stderr).decode(),flush=True);print('Observe after',(now+datetime.timedelta(seconds=360)).isoformat(),flush=True)
