from pathlib import Path
import hashlib, json, shutil, subprocess, tarfile

r = Path(__file__).parent
s = json.loads((r/'summary.json').read_text(encoding='utf-8'))
receipt = json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'))
assert s['complete'] and s['jobs'] == 9
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest() == receipt['archiveSHA256']
assert all(receipt[k] for k in ('allWorkersJoined', 'guestFixturesRemoved', 'quietBeforeAndAfter', 'archivedAndVerifiedUnderLease'))
assert s['identity']['sourceProofCommit'] == '7e2f7cac0d69b833e94e7bc8cbf1450f9d044464'
out = Path('benchmarks/results/2026-11-14-literal-cpython-checkpoint')
out.mkdir(exist_ok=False)
for name in ('summary.json', 'identity.json', 'archive-receipt.json', 'terminal-status.json', 'observations.tgz', 'prospective.json'):
    shutil.copyfile(r/name, out/name)
with tarfile.open(out/'collection-tools.tar.xz', 'w:xz') as archive:
    for p in sorted(r.iterdir()):
        if p.is_file() and p.suffix in ('.py', '.sh', '.json', '.log'):
            archive.add(p, arcname=p.name)
guide = Path('docs/BENCHMARKS.md')
prior = guide.read_text(encoding='utf-8')
(out/'prior-BENCHMARKS.md').write_text(prior, encoding='utf-8', newline='\n')
rows = {(v['case'], v['lane']): v for v in s['timing']}
cases = [
    ('scripts.csv-invoice.large', 'CSV invoice / pricing helpers', '4,096 records /127,031 B'),
    ('scripts.text-summary-helpers.nonlocal-counter.large', 'Text / captured helper and counter', '3,072 lines /35,840 B'),
    ('scripts.json-summary-helpers.large', 'JSON-lines / aggregation helpers', '4,096 records /110,592 B'),
    ('scripts.file-search.large', 'File search / keyword-default helper', '2,049 lines /42,010 B; stop after1,025'),
    ('scripts.report-render.large', 'JSON-to-Markdown report', '3,072 records /189,441 B'),
    ('scripts.csv-fulfillment.large', 'CSV fulfillment / pricing and validation', '4,096 records /126,821 B'),
    ('scripts.csv-check-digits.for-text.large', 'CSV validation / for-loop checksum', '4,096 records /49,163 B'),
]
def times(row, prefix):
    values = [v for k,v in row['medianMilliseconds'].items() if k.startswith(prefix)]
    factor, unit = (1000,'µs') if max(values) < 1 else (1,'ms')
    return f'{min(values)*factor:.3f}–{max(values)*factor:.3f} {unit}'
def ratio(row):
    return f"{min(row['ratioRange']):.2f}–{max(row['ratioRange']):.2f}×"
def status(row):
    label = 'Variable' if max(row['lythonControlPercent'],row['cpythonControlPercent'],row['maxIqrPercent']) > 3 else 'Diagnostic'
    return f"{label}; spreads{row['lythonControlPercent']:.2f}/{row['cpythonControlPercent']:.2f}%; maxIQR{row['maxIqrPercent']:.2f}%"
table = '| Representative workload, warm execution | Input | Lython | CPython | Lython / CPython | Measurement status |\n| --- | --- | ---: | ---: | ---: | --- |\n'
for case,label,size in cases:
    v = rows[case,'warm']
    table += f'| {label} |{size}|{times(v,"candidate")}|{times(v,"CPython")}|{ratio(v)}|{status(v)}|\n'
table += next(line for line in prior.splitlines() if line.startswith('| Configuration JSON edit'))+'\n'
start = prior.index('**Ratio =')
end = prior.index('The96 B configuration row')
description = '''**Ratio = Lython elapsed / CPython elapsed; above one means slower.** These are
complete embedding measurements, not isolated interpreter CPU. Spreads are the
Lython/CPython process-median differences; moving controls and IQRs remain visible.

First seven rows measured2026-11-14UTC: **7e2f7cac / frozen72c9a1e5**,
against stock**CPython3.13.16**. Focused actual .NET11/10 checks pass;
full Windows/Ubuntu, original stress and installed-package qualification43579225278
is pending. [Source/delivery status](../benchmarks/results/2026-11-14-compiled-literal-tuples/README.md).
[Exact sources, raw/wider CPU and controls](../benchmarks/results/2026-11-14-literal-cpython-checkpoint/README.md).
Report process spread4.16%/maximumIQR6.20% remains inconclusive stability.
The prior measured revision and adverse conditions stay in linked evidence;
cross-collection differences do not attribute individual changes.
'''
current = '# Performance against CPython\n\n'+table+'\n'+description+prior[end:]
for phase,label in (('compile','Invoice compilation alone'),('compile-run','Invoice compile and execute once')):
    v = rows['scripts.csv-invoice.large',phase]
    old = next(line for line in current.splitlines() if line.startswith('| '+label+'|'))
    new = f'| {label}|{times(v,"candidate")}|{times(v,"CPython")}|{ratio(v)}|{status(v)}|'
    current = current.replace(old,new)
current = current.replace('[Previous checkpoint and all adverse observations](../benchmarks/results/2026-11-13-current-cpython-checkpoint/README.md)', '[Previous checkpoint and all adverse observations](../benchmarks/results/2026-11-14-iteration-cpython-checkpoint/README.md)')
current = current.replace('These\n  measurements do not update the CPython rows.', 'These\n  source-pair measurements remain distinct from the refreshed CPython rows.')
guide.write_text(current,encoding='utf-8',newline='\n')
detail = '| Complete script / phase | Lython ms | CPython ms | Lython / CPython | Lython/CPython process spread | Max IQR |\n| --- | ---: | ---: | ---: | ---: | ---: |\n'
for v in s['timing']:
    med = v['medianMilliseconds']
    a = [n for k,n in med.items() if k.startswith('candidate')]
    b = [n for k,n in med.items() if k.startswith('CPython')]
    detail += f"|{v['case'].removeprefix('scripts.')} /{v['lane']}|{min(a):.6f}–{max(a):.6f}|{min(b):.6f}–{max(b):.6f}|{ratio(v)}|{v['lythonControlPercent']:.2f}/{v['cpythonControlPercent']:.2f}%|{v['maxIqrPercent']:.2f}%|\n"
(out/'README.md').write_text(f'''# Literal-storage CPython checkpoint

2026-11-14UTC, R352/B724: committed `7e2f7cac` / frozen `72c9a1e5`,
581production inputs, stockCPython3.13.16. Focused actual11/10 checks pass;
full43579225278qualification is pending independently at collection.
[Source and subsequent delivery](../2026-11-14-compiled-literal-tuples/README.md).
Publication/tagging and optional-adapter promotion remain held.

{detail}
Ratio = Lython elapsed / CPython elapsed, above one means slower. Ranges pair
two fresh process medians per engine in all four combinations, not confidence
intervals. Report process spread4.16% and maximumIQR6.20% remain uncertainty.
Earlier unchanged/adverse controls and original failed conditions survive; no
causal gain is inferred by subtracting earlier collections.

Quiet AzureF4as_v7, Ubuntu24.04.4, four EPYC9V45vCPUs/16GiB/no swap,
.NET11RC3 ordinary workstation GC/tiering and CPython GIL/GC. Existing B685workers,
optional nonpackable0.4adapter and unchanged B717nine-job catalog/goldens. Each job:
four fresh processes, five-second full-request warmup (12s captured text/report),
five rotating0.5s batches sized by full-request wall time. Guest clocks unchanged.

Warm execution includes mediated RAM-file I/O, stdout/file validation and prior
result cleanup; excludes compile/startup, fixture staging/reset, protocol and final
cache shutdown. Compilation alone includes compiled-owner disposal. Compile-to-
result adds compilation/disposal to execution. Wider process CPU includes reset/
protocol. Independently warmed phases cannot be subtracted for attribution.
No startup, shared-contention, pending-I/O, RSS/heap or embedding-tail claim.

Nine jobs complete{s['elapsedSeconds']:.3f}s within one480sowner. All exact image/
auxiliary/golden/budget/quiet/join/archive gates pass. No remaining workers or RAM
fixtures. First staging stopped at the unchanged254MiBguard before mount/service;
failure is preserved. One canonical-proven duplicate old tool was retired, identical
staged hashes and floor verified, and the first measurement owner started. No
measurement restart. Current images/catalogs and254/252MiBfloors remain intact.

Persistent raw SHA256: `{receipt['archiveSHA256']}`.
[Summary/identities](summary.json), [raw](observations.tgz),
[collection tools and staging correction](collection-tools.tar.xz),
[previous guide](prior-BENCHMARKS.md). Exact source/core and focused checks are in
the [R351archive](../2026-11-14-compiled-literal-tuples/sources-checks-and-observations.tar.xz).
This checkpoint informs the continuing whole-script roadmap; it does not complete
the performance objective or demonstrate a uniform speedup.
''',encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md')
with p.open('a',encoding='utf-8',newline='\n') as f:
    f.write('''\n## R352 — literal-storage external checkpoint\n\n[B724](results/2026-11-14-literal-cpython-checkpoint/README.md) refreshes the\nunchanged nine-job catalog at7e2f7cac/frozen72c9 against stockCPython3.13.16.\n360.499s/all image/output/budget/quiet/join/archive gates pass. Invoice warm\n1.19–1.24×/compile1.09–1.10×/fresh1.21–1.24×; captured text1.42–1.49×,\nJSON0.83–0.84×, search1.63–1.69×, report1.19–1.25×, fulfillment1.27–1.29×,\nfor-loopCSV1.27–1.29×. Report4.16%spread/6.20%maximumIQR remains uncertainty.\nStaging refusal/remedy and all adverse data survive; no measurement restart,\nsource-pair attribution or objective-completion claim. Full43579225278qualification\nis independent. Publication remains held.\n''')
print('Saved refreshed external evidence and updated authoritative performance guide.')
