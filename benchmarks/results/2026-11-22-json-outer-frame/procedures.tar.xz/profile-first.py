from pathlib import Path
import json,hashlib,importlib.util,os,subprocess,time
lab=Path(__file__).resolve().parent
repo=lab.parents[3]
donor=lab.parent/"native-direct-integer-return-refined-20261122"
image=donor/"frozen/candidate"
catalog=donor/"representative.json"
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
identity=read(donor/"identity.json")
assert identity["candidate"].startswith("7d323d40f")
assert sha(catalog)==identity["catalogSHA256"]
files=identity["imageFiles"]["candidate"]
assert len(files)==32 and {n:sha(image/n) for n in files}==files
spec=importlib.util.spec_from_file_location("profile_protocol",repo/"benchmarks/cpython-worker.py")
protocol=importlib.util.module_from_spec(spec)
spec.loader.exec_module(protocol)
assert sha(repo/"benchmarks/cpython-worker.py")==read(donor/"quiet/config.json")["protocolSHA256"]
case=next(c for c in read(catalog)["cases"] if c["id"]=="scripts.json-lines-shipment.expanded-options.large")
profile=lab/"json-lines.nettrace"
sdk=Path.home()/".dotnet11"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
folder=lab/"local-guest-fixture"
folder.mkdir()
record=dict(case=case["id"],lane="warm",source="e152d1ceb",identity=identity,profile="dotnet-sampled-thread-time",
            platform="Windows local EventPipe",samplesAreTimingComparison=False,warmup=[],captured=[])
with (lab/"worker.stderr").open("xb")as errors:
    worker=subprocess.Popen([sdk/"dotnet.exe",image/"Lokad.Lython.Benchmarks.dll","--compare","worker","--catalog",catalog],stdin=subprocess.PIPE,
                             stdout=subprocess.PIPE,stderr=errors,cwd=folder,env=env)
    trace=None
    def request(op,count):
        nonlocal_status="Equivalent" if op=="verify" else "Completed"
        request.id+=1
        fields={n:case[n] for n in ("sourceSha256","fixtureSha256","expectedOutputSha256")}
        protocol.write_frame(worker.stdin,dict(fields,protocolVersion=2,requestId=request.id,operation=op,caseId=case["id"],lane="warm",iterations=count))
        response=protocol.read_frame(worker.stdout)
        assert response["status"]==nonlocal_status and response["completedInvocations"]==count,None if not response else response["status"]
        assert response["actualOutputSha256"]==case["expectedOutputSha256"]
        assert response["actualFilesSha256"]==case["expectedFilesSha256"]
        return response
    request.id=0
    try:
        ready=protocol.read_frame(worker.stdout)
        record["worker"]=ready
        assert ready["status"]=="Ready" and ready["catalogSha256"]==sha(catalog)
        core=next(x for x in ready["libraries"] if Path(x["path"]).name=="Lokad.Lython.dll")
        assert core["sha256"].lower()==files["Lokad.Lython.dll"]
        record["verifyBefore"]=request("verify",2)
        until=time.monotonic()+7
        while time.monotonic()<until:
            record["warmup"].append(request("batch",64))
        tool=Path.home()/".dotnet/tools/dotnet-trace.exe"
        with (lab/"trace.log").open("xb")as tracing:
            trace=subprocess.Popen([tool,"collect","--process-id",str(worker.pid),"--profile","dotnet-sampled-thread-time",
                "--duration","00:00:00:08","--buffersize","64","--format","Speedscope","--output",profile],
                stdout=tracing,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,env=env)
            stop=time.monotonic()+18
            while trace.poll() is None and time.monotonic()<stop:
                record["captured"].append(request("batch",64))
            assert trace.wait(timeout=5)==0
        record["verifyAfter"]=request("verify",2)
        protocol.write_frame(worker.stdin,dict(protocolVersion=2,requestId=request.id+1,operation="quit"))
        record["closed"]=protocol.read_frame(worker.stdout)
        assert record["closed"]["status"]=="Closed" and worker.wait(timeout=7)==0
    finally:
        if trace is not None and trace.poll() is None:trace.kill();trace.wait()
        if worker.poll() is None:worker.kill();worker.wait()
        worker.stdin.close();worker.stdout.close()
        (lab/"profile-receipt.json").write_text(json.dumps(record,indent=2)+"\n",encoding="utf-8",newline="\n")
assert not (lab/"worker.stderr").stat().st_size and profile.stat().st_size>0
print("Matched the local frozen worker, golden output and files before and after the trace.")
