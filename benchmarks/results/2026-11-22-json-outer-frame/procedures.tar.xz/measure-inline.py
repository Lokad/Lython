from pathlib import Path
import hashlib
import json
import os
import shutil
import statistics
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
notes = lab.parent
donor = notes / "native-direct-integer-return-refined-20261122"
catalog_flat = notes / "expanded-builtin-span/representative.json"
catalog_nested = notes / "native-json-encoding-options-r540/representative.json"
reference = donor / "frozen/candidate"
core = "Lokad.Lython.dll"
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk),
           PATH=str(sdk) + os.pathsep + os.environ["PATH"])

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def save(path, contents):
    path.write_text(json.dumps(contents, indent=2) + "\n", encoding="utf-8", newline="\n")

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

base = load(catalog_flat)
nested = load(catalog_nested)
assert base["cases"][0]["id"] == "scripts.json-lines-shipment.expanded-options.large"
assert base["cases"][1]["id"] == "scripts.json-lines-shipment.explicit-options.large"
assert nested["cases"][1]["id"] == "scripts.config-manifest.small"
assert nested["cases"][2]["id"] == "calls.positional.large"
base["cases"] = base["cases"][:2] + nested["cases"][1:3]
catalog = lab / "inline-catalog.json"
save(catalog, base)
protocol = repo / "benchmarks/cpython-worker.py"
source = load(donor / "identity.json")
previous = source["imageFiles"]["candidate"]
assert len(previous) == 32 and {name: sha(reference / name) for name in previous} == previous
trial = repo / ".git/agent-worktrees/json-ascii-emission-20261122"
revision = subprocess.check_output(["git", "-C", trial, "rev-parse", "HEAD"], text=True).strip()
parent = subprocess.check_output(["git", "-C", trial, "rev-parse", "HEAD^"], text=True).strip()
assert parent.startswith("e152d1ceb")
assert not subprocess.check_output(["git", "-C", trial, "status", "--porcelain", "--untracked-files=no"])
candidate = trial / "src/Lokad.Lython/bin/Release/net11.0" / core
frozen = {}
for role in ("reference", "candidate"):
    image = lab / "inline-frozen" / role
    image.mkdir(parents=True)
    for name in previous:
        source_file = candidate if name == core and role == "candidate" else reference / name
        shutil.copyfile(source_file, image / name)
    for extra in reference.glob("ValidatedAllocation.*"):
        shutil.copyfile(extra, image / extra.name)
    hashes = {name: sha(image / name) for name in previous}
    verified = lab / f"inline-{role}-verification.json"
    subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog", catalog,
                    "--dotnet", dotnet, "--python", "C:/Python313/python.exe", "--python-worker", protocol,
                    "--out", verified], check=True, env=env, timeout=100)
    proof = load(verified)
    assert proof["state"] == "Completed" and proof["catalogSha256"] == sha(catalog)
    allocation = lab / f"inline-{role}-allocation.json"
    subprocess.run([dotnet, image / "ValidatedAllocation.dll", image, catalog, allocation],
                   check=True, env=env, timeout=100)
    assert all(row["sharedBudgetBaselineRestored"] for row in load(allocation)["rows"])
    assert {name: sha(image / name) for name in previous} == hashes
    frozen[role] = hashes
assert frozen["reference"] == previous
assert [name for name in previous if frozen["reference"][name] != frozen["candidate"][name]] == [core]
save(lab / "inline-images.json", dict(imageFiles=frozen, reference=parent, candidate=revision, catalogSHA256=sha(catalog), protocolSHA256=sha(protocol),
                                    sourcePatchSHA256=sha(lab / "inline-frame.patch")))
rows = []
left, right = [load(lab / f"inline-{role}-allocation.json")["rows"] for role in ("reference", "candidate")]
for before, after in zip(left, right, strict=True):
    assert before["id"] == after["id"]
    a, b = [statistics.median(row["allocatedBytesPerInvocation"]) for row in (before, after)]
    p, q = [row["peakExecutionMemoryBytes"] for row in (before, after)]
    rows.append(dict(case=before["id"], allocatedBefore=a, allocatedAfter=b, allocationChange=100 * (b / a - 1),
                     admittedBefore=p, admittedAfter=q, budgetReturnedToBaseline=True))
save(lab / "inline-allocation-summary.json", rows)
for row in rows:
    print(row, flush=True)
