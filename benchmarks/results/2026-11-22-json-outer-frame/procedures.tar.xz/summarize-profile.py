from pathlib import Path
import json

lab = Path(__file__).resolve().parent
trace = json.loads((lab/"json-lines.speedscope.json").read_text(encoding="utf-8"))
names = [f["name"] for f in trace["shared"]["frames"]]
stages = ("ExecutionThreads+Worker.Run", "ComparisonFileHost", "ExecuteInstructionPrefix",
          "JsonModule+", "JsonEncodeIterator", "AppendJsonString", "GrowFrameStorage",
          "AppendStarredDictionaryCore", "BindNamedArgumentsCore", "InvokeBoundEncoderAsync")
threads = []
for profile in trace["profiles"]:
    assert profile["type"] == "evented"
    stack = []
    previous = profile["startValue"]
    times = dict.fromkeys(stages, 0.0)
    cpu_marked = dict.fromkeys(stages, 0.0)
    for event in profile["events"]:
        when = event["at"]
        elapsed = when - previous
        if stack and elapsed > 0:
            rendered = "|".join(names[i] for i in stack)
            for stage in stages:
                if stage not in rendered:
                    continue
                times[stage] += elapsed
                if names[stack[-1]] == "CPU_TIME":
                    cpu_marked[stage] += elapsed
        if event["type"] == "O":
            stack.append(event["frame"])
        else:
            assert stack.pop() == event["frame"]
        previous = when
    if times["ExecutionThreads+Worker.Run"]:
        threads.append(dict(name=profile["name"], unit=profile["unit"],
                            inclusiveSampledThreadTime=times, cpuMarkedInclusiveTime=cpu_marked))
assert len(threads) == 1, [t["name"] for t in threads]
record = dict(profilingOnly=True, overlappingAncestry=True, workloadsCompared=1, workers=threads)
(lab/"inline-profile-attribution.json").write_text(json.dumps(record,indent=2)+"\n",encoding="utf-8",newline="\n")
print(json.dumps(record,indent=2))
