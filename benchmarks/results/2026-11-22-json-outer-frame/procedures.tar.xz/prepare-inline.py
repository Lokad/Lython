from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.parent/"native-direct-integer-return-refined-20261122"
template = prior/"quiet"
out = lab/"quiet"

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def write(path, content):
    if path.suffix == ".py":
        compile(content, str(path), "exec")
    path.write_text(content, encoding="utf-8", newline="\n")

def digest(data):
    return hashlib.sha256(data).hexdigest()

def sha(path):
    return digest(path.read_bytes())

def pushed(path):
    return subprocess.check_output(["git", "show", "origin/master:benchmarks/results/" + path], cwd=repo)

inventory = load(lab/"inline-inventory.json")
archives = {
    "mixed-factory-boundaries-b1374-20261122": "2026-11-22-mixed-factory-boundaries",
    "native-direct-integer-return-b1371-20261122": "2026-11-22-native-direct-integer-return",
    "native-direct-integer-return-refined-b1372-20261122": "2026-11-22-native-direct-integer-return-refined",
    "native-fixed-return-refined-b1368-20261122": "2026-11-22-native-fixed-returns-refined",
    "retained-call-profile-b1370-20261122": "2026-11-22-retained-call-cpu-profile",
    "retained-call-transport-cpython-b1369-20261122": "2026-11-22-retained-call-transport-cpython",
}
assert set(inventory["archives"]) == {name + "/observations.tgz" for name in archives}
for name, result in archives.items():
    raw = digest(pushed(result + "/observations.tgz"))
    receipt = json.loads(pushed(result + "/archive-receipt.json"))
    assert raw == inventory["archives"][name+"/observations.tgz"] == receipt["archiveSHA256"]
    assert receipt["complete"] and receipt["allWorkersJoined"]
    assert receipt.get("archivedAndVerifiedUnderLease") or receipt.get("persistentTraceArchivedAndVerifiedBeforeUnmount")
canonical = gzip.decompress(pushed(archives["native-fixed-return-refined-b1368-20261122"]+"/candidate-core.dll.gz"))
assert digest(canonical) == inventory["sha256"] and len(canonical) == inventory["bytes"]
retire = {name:inventory[name] for name in ("paths","links","bytes","sha256","archives")}

config = load(template/"config.json")
receipt = load(template/"archive-receipt.json")
assert all(receipt[n] for n in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease"))
assert sha(template/"observations.tgz") == receipt["archiveSHA256"]
verified = load(lab/"inline-images.json")
files = verified["imageFiles"]
core = "Lokad.Lython.dll"
assert files["reference"] == config["identity"]["imageFiles"]["candidate"]
assert files["reference"][core] == inventory["current"]
for role, expected in files.items():
    assert len(expected) == 32
    assert {name:sha(lab/"inline-frozen"/role/name) for name in expected} == expected
    proof = load(lab/f"inline-{role}-verification.json")
    assert proof["state"] == "Completed" and proof["caseCount"] == 4 and proof["catalogSha256"] == verified["catalogSHA256"]
catalog = lab/"inline-catalog.json"
assert sha(catalog) == verified["catalogSHA256"]
assert verified["protocolSHA256"] == config["protocolSHA256"]

out.mkdir()
root = "/home/lokad/lython-bench-checks/json-outer-frame-b1375-20261122"
unit = "lython-b1375-json-outer-frame-20261122"
identity = dict(sourceRevision=verified["reference"]+" versus "+verified["candidate"],
                purpose="Remove flat record traversal backing in JSON output",
                imageFiles=files, normalAdapterPin="0.4.0", catalogSHA256=sha(catalog),
                coreSHA256={role+suffix: hashes[core] for role,hashes in files.items() for suffix in ("","-control")})
write(out/"identity.json", json.dumps(identity, indent=2)+"\n")
shutil.copyfile(catalog, out/"representative.json")
jobs = [(x["id"],"warm") for x in load(catalog)["cases"]]
for name in ("collect.py","archive-owned.py","run.sh","retrieve.py"):
    source = (template/name).read_text(encoding="utf-8").replace(config["root"],root).replace(config["unit"],unit)
    source = source.replace("B1372","B1375")
    if name == "collect.py":
        start,end = source.index("\njobs = "), source.index("\nassert len(jobs)")
        source = source[:start]+"\njobs = "+repr(jobs)+source[end:]
        source = source.replace("len(jobs)==5","len(jobs)==4").replace("started < 300","started < 245")
    elif name in ("archive-owned.py","retrieve.py"):
        source = source.replace("jobs=5,","jobs=4,").replace("['jobs']==5","['jobs']==4").replace("len(raw['jobs'])==5","len(raw['jobs'])==4")
    write(out/name, source)
assert b"\r" not in (out/"run.sh").read_bytes()
(out/"candidate").mkdir()
shutil.copyfile(lab/"inline-frozen/candidate"/core, out/"candidate"/core)
parts = ("identity.json","collect.py","archive-owned.py","run.sh","candidate/"+core,"representative.json")
payload = out/"payload.tgz"
with tarfile.open(payload, "w:gz") as archive:
    for name in parts:
        archive.add(out/name,arcname=name)
unpacked = sum((out/name).stat().st_size for name in parts)
assert inventory["free"]+retire["bytes"]>176160768+unpacked+640*1024
stage = dict(root=root,unit=unit,identity=identity,source=config["root"],sourceRole="candidate",
             sourceFiles=files["reference"],sourceCatalogSHA256=config["catalogSHA256"],
             donorArchiveSHA256=receipt["archiveSHA256"],protocolSource=config["root"]+"/cpython-worker.py",
             protocolSHA256=config["protocolSHA256"],payloadBytes=payload.stat().st_size,
             payloadSHA256=sha(payload),retireGroups=[retire],catalogSHA256=sha(catalog),unpackedBytes=unpacked)
write(out/"config.json", json.dumps(stage,indent=2)+"\n")
remote = (template/"remote-launch.py").read_text(encoding="utf-8")
start,end = remote.index("\nc=")+1,remote.index("\nb=Path(")
remote = remote[:start]+"c="+repr(stage)+remote[end:]
start,end = remote.index(" catalog_donor=Path("),remote.index(" payload=sys.stdin")
remote = remote[:start]+remote[end:]
remote = remote.replace(" os.link(catalog_donor/'representative.json',root/'representative.json')\n","")
remote = remote.replace("RuntimeMaxSec=335","RuntimeMaxSec=295").replace("lython-b1372-fixtures","lython-b1375-fixtures")
assert "catalog_donor" not in remote
write(out/"remote-launch.py", remote)
write(lab/"launch-inline.py", (prior/"launch.py").read_text(encoding="utf-8")
      .replace("Direct arithmetic return with original call entry","JSON outer frame comparison").replace("315","255"))
write(lab/"summarize-inline.py", (prior/"summarize.py").read_text(encoding="utf-8").replace("len(raw['jobs'])==5","len(raw['jobs'])==4"))
print("Verified an exact archive for every older alias, and staged both hashes and four complete-script checks.")
