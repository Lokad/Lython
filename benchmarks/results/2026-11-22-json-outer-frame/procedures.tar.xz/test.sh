#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/json-ascii-emission-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
dir=/mnt/d/code/Lython/.git/agent-notes/review-20261031/json-ascii-emission-20261122
filter='FullyQualifiedName~Json&Category!=Stress'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter "$filter" --nologo > "$dir/white-ubuntu.log" 2>&1 || { tail -70 "$dir/white-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter "$filter" --nologo > "$dir/public-ubuntu.log" 2>&1 || { tail -70 "$dir/public-ubuntu.log"; exit 1; }
awk '/Passed!/{count++;print} END{exit count!=2}' "$dir/white-ubuntu.log" "$dir/public-ubuntu.log"
