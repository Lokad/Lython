from pathlib import Path
import json
import shlex
import subprocess

lab = Path(__file__).resolve().parent
ssh = ["C:/Windows/System32/OpenSSH/ssh.exe", "-i", str(Path.home()/".ssh/id_lython-bench.pem"),
       "-o", "BatchMode=yes", "-o", "ConnectTimeout=15", "lokad@20.166.121.73"]

source = """
from pathlib import Path
import fcntl, hashlib, json, os, shutil, stat
base = Path('/home/lokad/lython-bench-checks')
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
with (base/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert not any(p.is_mount() for p in base.glob('*/guest-fixtures'))
    canonical=base/'native-direct-integer-return-refined-b1372-20261122/reference/Lokad.Lython.dll'
    current=base/'native-direct-integer-return-refined-b1372-20261122/candidate/Lokad.Lython.dll'
    old=canonical.lstat()
    paths=[]
    for p in base.glob('*/*/Lokad.Lython.dll'):
        info=p.lstat()
        if (old.st_dev, old.st_ino) == (info.st_dev, info.st_ino):
            assert p.resolve()==p and stat.S_ISREG(info.st_mode) and info.st_uid==os.getuid()
            paths.append(str(p.relative_to(base)))
    assert len(paths)==old.st_nlink
    archives={name+ '/observations.tgz': sha(base/name/'observations.tgz') for name in {p.split('/')[0] for p in paths}}
    print(json.dumps(dict(free=shutil.disk_usage(base).free, bytes=old.st_size, paths=sorted(paths),
        links=old.st_nlink, sha256=sha(canonical), archives=archives, current=sha(current))))
"""
result = subprocess.run(ssh+["python3 -c "+shlex.quote(source)], capture_output=True, timeout=45)
assert result.returncode == 0, result.stderr.decode()
receipt = json.loads(result.stdout)
(lab/"inline-inventory.json").write_text(json.dumps(receipt, indent=2)+"\n", encoding="utf-8", newline="\n")
print(json.dumps(receipt,indent=2))
