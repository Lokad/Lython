set -eu
root=/home/lokad/lython-bench-checks/json-outer-frame-b1375-20261122
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
