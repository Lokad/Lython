from pathlib import Path
import json,os,subprocess
r=Path(__file__).parent
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+';'+env['PATH']
with (r/'metadata-build.log').open('w',encoding='utf8') as log:
    p=subprocess.run([env['DOTNET_HOST_PATH'],'build',str(r/'metadata-tool/Metadata.csproj'),'-c','Release'],env=env,stdout=log,stderr=subprocess.STDOUT)
assert p.returncode==0,(r/'metadata-build.log').read_text(encoding='utf8')
p=subprocess.run([env['DOTNET_HOST_PATH'],str(r/'metadata-tool/bin/Release/net11.0/Metadata.dll'),str((r/'images/before/Lokad.Lython.dll').resolve()),str((r/'images/candidate/Lokad.Lython.dll').resolve())],env=env,capture_output=True,check=True)
(r/'metadata-size.json').write_bytes(p.stdout)
for row in json.loads(p.stdout):print(Path(row['image']).parent.name,row['type'],row['elementBytes'],'managed array bytes/element',flush=True)
