from pathlib import Path
r=Path(__file__).parent
s=(r.parent/'primitive-helpers-r113/prepare-space-inodes.py').read_text(encoding='utf8')
s=s.replace('r113-core-dedup-proof.json','r114-core-dedup-proof.json').replace('.r113-identical-link','.r114-identical-link').replace('saved>=4*1024*1024','saved>=9*1024*1024').replace('4*1024*1024<=saved<=8*1024*1024','9*1024*1024<=saved<=14*1024*1024')
(r/'prepare-space-bounded.py').write_text(s,encoding='utf8')
exec(compile(s,str(r/'prepare-space-bounded.py'),'exec'))
