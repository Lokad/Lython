from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;i=json.loads((r/'identity.json').read_text(encoding='utf8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in i['productionSources'].items())
a=json.loads((r/'b474/archive-receipt.json').read_text(encoding='utf8'))
assert a['complete'] and a['jobs']==8 and a['allWorkersJoined'] and a['quietBeforeAndAfter'] and not a['guestFixtureDirectories']
assert hashlib.sha256((r/'b474/observations.tgz').read_bytes()).hexdigest()==a['archiveSHA256']
status=dict(status='Intermediate prototype; not committed or fully qualified. R115 shared primitive numeric proof is the bounded correction before coherent delivery.',architecture='Native proof owns immutable instruction descriptors/return/member spans, ordinary forwarding always enabled. Runtime source/return/member instruction offsets and mutual exclusion removed. No new engine/owner/arena/cache/options.',tradeoffs='NativeReturnValue32to72B, ExecutableInstruction32B unchanged; incremental compile allocation+1.07–1.09%accounting/+0.59%text/report unchanged, desktop CPU uncertain. Warm allocation neutral. Coarse compilation estimate unchanged, deliberate headroom.',measurement='Against qualified1310: integer CSVelapsed−2.94to−6.33%sync/−5.10to−9.96%async; JSON−0.85to−6.41%sync/−5.78to−7.44%async. Supporting asynchronousCPU, syncCSV/JSON controls variable. FloatCSVsync−0.09to+1.18%, async+4.14to+6.29%/CPU0to+9.09%adverse. Text−0.29to−5.00%withsupportingCPU, report−2.50to+1.46%/CPU0to+2.38%uncertain. All roles retained.',correction='Generalize common exact CLR primitive shapes BigInteger/double/bool, preserving canonical arithmetic, not add native arithmetic implementations. Share one pure result-shape fact with compiler to reject permanently unsupported binary proofs. Keep dynamic protocols ordinary, explicitly measure their guard-miss control. Existing repeated probes may contribute but are not isolated CPU proof; no call-control carrier revival.',measurementLimit='Applied launch command configured270s and acknowledged; setup/observer descriptive owner field mistakenly210. Scheduled boundary330s retained. Terminal transient unit reports RuntimeMaxUSec=infinity, not proof of its earlier live bound; original files/results retained. Collection223.498s, joined/unmounted/archived/locallyverified, no workers. No retroactive timeout verification claim or requery.')
(r/'status.json').write_text(json.dumps(status,indent=2)+'\n',encoding='utf8')
out=Path('benchmarks/results/2026-11-08-independent-native-proof');out.mkdir()
with tarfile.open(out/'observations.tar.xz','w:xz') as t:
    for p in sorted(r.iterdir()):
        if p.name=='images':
            for role in ['before','candidate','qualified']:t.add(p/role/'Lokad.Lython.dll',arcname='images/'+role+'/Lokad.Lython.dll')
        elif p.name=='b474':
            for q in sorted(p.iterdir()):
                if q.name not in ['retrieved','payload.tgz']:t.add(q,arcname='b474/'+q.name)
        elif p.name=='metadata-tool':
            for q in sorted(p.iterdir()):
                if q.is_file():t.add(q,arcname='metadata-tool/'+q.name)
        else:t.add(p,arcname=p.name)
with tarfile.open(out/'observations.tar.xz') as t:assert hashlib.sha256(t.extractfile('b474/observations.tgz').read()).hexdigest()==a['archiveSHA256']
for src,name in [(r/'identity.json','identity.json'),(r/'status.json','status.json'),(r/'b474/assessment.json','assessment.json'),(r/'assessment-local.json','incremental-allocation.json'),(r/'compile-assessment.json','incremental-compilation.json'),(r/'metadata-size.json','metadata-size.json'),(r/'b474/archive-receipt.json','archive-receipt.json')]:shutil.copyfile(src,out/name)
(out/'README.md').write_text('''# Independent native proof, intermediate

2026-11-08. Combined R113/R114 core a383d084 over9b61264b, compared with fully
qualified05790317/core13107e6b. Incremental local diagnostics compare with R113
core d8d2a6fb; do not subtract percentages across those different runs.

Existing proof nodes now own immutable opcode metadata and member/return spans;
ordinary operand forwarding runs independently, including failed native guards.
Runtime source/return/member instruction offsets and the native/forwarding mutual
exclusion are removed. No new evaluator/backend/owner/cache/arena/public option.
Native nodes grow32→72B; ordinary instructions remain32B. Incremental compilation
allocation+1.07–1.09%accounting/+0.59%text, report unchanged; warm allocation neutral.
1524public/104internal focused peractual11/10 pass before conservative casing
block-bound refinement, exact final63public/51internal pertarget pass afterward.
Full qualification pending; this is an intermediate prototype.

B474: same quiet F4as_v7/frozen7cf worker/optional0.4/normal GC/tiering,
two isolated roles/core,5swarmup,7rotated150msrounds. Eight jobs223.498s; complete
goldens, budget baselines, Ready/image/quiet/Closed/join/fixture/archive/local
verification pass. No users/ownedRAM remain. Warm includes invocation, mediated
RAM I/O, full validation and prior-result cleanup; compile/startup/staging/final
cache teardown excluded. New accounting variations have independent CPython
semantic goldens; this is not a refreshed external performance comparison.

| Script / API | Elapsed change, all pairings | CPU change |
| --- | ---: | ---: |
| Integer CSV / sync |−6.33% to−2.94%|−6.25% to+2.99%|
| Integer CSV / async |−9.96% to−5.10%|−10.71% to−1.23%|
| Integer JSON / sync |−6.41% to−0.85%|−7.14% to0%|
| Integer JSON / async |−7.44% to−5.78%|−7.69% to−3.85%|
| Float CSV / sync |−0.09% to+1.18%|−6.25% to+4.17%|
| Float CSV / async |+4.14% to+6.29%|0% to+9.09%|
| Unchanged text / sync |−5.00% to−0.29%|−2.44% to−1.22%|
| Unchanged report / sync |−2.50% to+1.46%|0% to+2.38%|

Negative is faster. Synchronous integer controls vary; async float is adverse
and requires a bounded correction. Generalize the same proof to ordinary primitive
float/bool arithmetic using canonical operators and one shared compiler/runtime
shape fact. Keep custom protocols ordinary and measure a genuine guard-miss control.
Repeated proof attempts are source-visible, not an isolated explanation of all CPU.
Do not revive slower call-control/arena carriers or silently waive the regression.

Original metadata error: setup/observer says owner210, preplanned contract and
applied acknowledged launch command configure270s; collector reserves final work
after240s, scheduled observation+330s. The terminal transient unit reports infinity,
so its earlier live limit is not independently verified. All original files are
preserved; no retrospective timeout-enforcement claim, requery or duplicate run.
Bounded exact-byte hardlinks recovered11.09MB with fresh idle-lease identity/alias
proof, no archive/path/content deletion or relaxed free-space guard.

[Status](status.json), [all roles](assessment.json), [identity](identity.json),
[incremental allocation](incremental-allocation.json), [compilation](incremental-compilation.json),
[managed metadata size](metadata-size.json), [receipt](archive-receipt.json),
[all sources/binaries/corrections/raw archive](observations.tar.xz).
''',encoding='utf8')
p=Path('benchmarks/EXPERIMENTS.md');p.write_text(p.read_text(encoding='utf8')+'''
## Independent native proof, intermediate (2026-11-08)

[R114/B474](results/2026-11-08-independent-native-proof/README.md) removes runtime
source offsets/native-forwarding exclusion; immutable descriptor nodes32→72B,
ordinary instructions32B. Allocation neutral, incremental compiler+0.59–1.09%.
Eight jobs223.498s/all output/ownership/quiet/cleanup/archive gates. Integer scripts
improve, async floatCSV+4.14–6.29%adverse; text mildly faster, report uncertain.
Intermediate, no full qualification. R115 bounded correction shares primitive
integer/float/bool proof with compiler; canonical operations, custom protocols
ordinary and explicitly measured. Original limit metadata210 vs configured270/
terminal infinity retained; no claim of independently observed earlier live limit.
''',encoding='utf8')
print('R114 intermediate and adverse async-float result preserved; no users/fixtures, continue coherent bounded numeric proof correction.')
