using System.Runtime.Loader;
using System.Text.Json;

var rows = new List<object>();
foreach (var path in args)
{
    var context = new AssemblyLoadContext(Path.GetFileName(Path.GetDirectoryName(path))!, true);
    var assembly = context.LoadFromAssemblyPath(Path.GetFullPath(path));
    foreach (var name in new[] { "NativeReturnValue", "ExecutableInstruction" })
    {
        var type = assembly.GetType("Lokad.Lython.Frontend." + name, true)!;
        _ = Array.CreateInstance(type, 1);
        long Allocate(int count)
        {
            var before = GC.GetAllocatedBytesForCurrentThread();
            var array = Array.CreateInstance(type, count);
            var bytes = GC.GetAllocatedBytesForCurrentThread() - before;
            GC.KeepAlive(array);
            return bytes;
        }
        var small = Allocate(1);
        var large = Allocate(1025);
        rows.Add(new { image = path, type = name, small, large, elementBytes = (large - small) / 1024 });
    }
    context.Unload();
}
Console.WriteLine(JsonSerializer.Serialize(rows, new JsonSerializerOptions { WriteIndented = true }));
