from pathlib import Path
import base64,copy,hashlib,json,struct,subprocess,tempfile
r=Path(__file__).parent;d=json.loads((r/'catalog.json').read_text(encoding='utf8'))
c=copy.deepcopy(d['cases'][0]);assert c['id']=='scripts.csv-integer-accounting.large'
c['id']='scripts.csv-float-accounting.large';c['source']=c['source'].replace("quantity=int(record['quantity'])","quantity=float(record['quantity'])")
f=json.loads(c['fixtureJson'])
with tempfile.TemporaryDirectory(prefix='lython-r114-cpython-') as folder:
    folder=Path(folder)
    for name,value in f['inputFiles'].items():(folder/name).write_bytes(base64.b64decode(value))
    p=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',c['source']],cwd=folder,capture_output=True,check=True);assert not p.stderr
    output=(folder/'report.csv').read_bytes();stdout=p.stdout.replace(b'\r\n',b'\n')
f['outputFiles']['report.csv']=base64.b64encode(output).decode()
digest=hashlib.sha256();key=b'report.csv'
for part in [struct.pack('>I',1),struct.pack('>I',len(key)),key,struct.pack('>I',len(output)),output]:digest.update(part)
c.update(fixtureJson=json.dumps(f,separators=(',',':')),sourceUtf8Bytes=len(c['source'].encode()),sourceSha256=hashlib.sha256(c['source'].encode()).hexdigest(),expectedOutput=stdout.decode(),expectedOutputUtf8Bytes=len(stdout),expectedOutputSha256=hashlib.sha256(stdout).hexdigest(),expectedFilesSha256=digest.hexdigest())
c['fixtureSha256']=hashlib.sha256(c['fixtureJson'].encode()).hexdigest()
assert d['cases'][2]['id']=='scripts.csv-summary-functions.large';d['cases'][2]=c
(r/'catalog.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(r/'float-accounting.py').write_text(c['source'],encoding='utf8')
(r/'workload-contract.md').write_text('''R114 five existing-driver complete file cases: R113 integer CSV/JSON accounting unchanged, one same4096-row CSV variation converts quantity with float so the exact-integer native guard fails, unchanged text/report controls. Independent isolated CPython full stdout/report goldens, original protocol file digest. Float case checks restored ordinary forwarding, not new floating-point arithmetic or native eligibility. Local before is archived intermediate d8d2a6fb, candidate independent descriptors/forwarding; final controlled pair uses fully qualified13107e6b against combined R113/R114. Distinguish incremental diagnostics from combined controlled outcomes and do not subtract percentages across runs. No new framework or CPython performance refresh.\n''',encoding='utf8')
print('Failed-proof float accounting golden',stdout.decode().strip(),output.decode().strip(),flush=True)
