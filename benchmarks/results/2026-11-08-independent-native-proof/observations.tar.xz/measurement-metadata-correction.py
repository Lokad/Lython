from pathlib import Path
r=Path(__file__).parent;b=r/'b474'
p=b/'retrieve.py';s=p.read_text(encoding='utf8');assert not (b/'terminal-status.json').exists()
assert 'Result,ExecMainStatus' in s;s=s.replace('Result,ExecMainStatus','Result,ExecMainStatus,RuntimeMaxUSec');p.write_text(s,encoding='utf8')
(r/'measurement-metadata-correction.md').write_text('''B474 preplanned eight-job bound is270s+30stop+30margin. Staged exact launch-command.py passed systemd RuntimeMaxSec=270 and collect.py uses <240s final-work admission; observe-not-before is acknowledged+330s. A template replacement left ownerSeconds=210 in setup.json and the descriptive field of observe-not-before.json. These are metadata errors, not the applied limit. Original files retained; final single scheduled terminal observation also captures RuntimeMaxUSec. No running files modified, no new dispatch or relaxed failed condition. Setup-contract/contract correctly state270.\n''',encoding='utf8')
print('Original owner metadata error retained; applied270s command and330s observation boundary explicit. Final observation will capture actual systemd bound.')
