from pathlib import Path
import hashlib,json,re,shutil,subprocess
r=Path(__file__).parent;b=json.loads((r/'baseline.json').read_text(encoding='utf8'))
sources={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in b['productionSources']}
expected={'src/Lokad.Lython/Frontend/ExecutableNativeBody.cs','src/Lokad.Lython/Frontend/ExecutableScript.NativeReturns.cs','src/Lokad.Lython/Frontend/ExecutableScript.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeReturn.cs'}
assert {p for p,h in sources.items() if h!=b['productionSources'][p]}==expected
counts={}
for prefix in ['', 'final-']:
    for name in ['publicnet11.0','internalnet11.0','publicnet10.0','internalnet10.0']:
        s=(r/(prefix+name+'.log')).read_text(encoding='utf8');m=re.search(r'Passed!.*Failed:\s+0, Passed:\s+(\d+),',s);assert m,prefix+name;counts[prefix+name]=int(m[1])
for framework in ['net11.0','net10.0']:
    ps=[Path(p)/'bin/Release'/framework/'Lokad.Lython.dll' for p in ['src/Lokad.Lython','tests/Lokad.Lython.PublicApi.Tests','tests/Lokad.Lython.Tests']]
    assert len({hashlib.sha256(p.read_bytes()).hexdigest() for p in ps})==1
p=r/'images/candidate/Lokad.Lython.dll';p.unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',p)
i=dict(baselineSource='Intermediate R113 over9b61264b/core d8d2a6fb; focused and controlled, not fully qualified',controlledReference='Fully qualified05790317/core13107e6b, cached CI42502610937',candidateSource='9b61264b plus combined R113 exact integer Binary and R114 independent native instruction descriptors/ordinary forwarding',coreSHA256={role:hashlib.sha256((r/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest() for role in ['before','candidate','qualified']},productionSources=sources,focusedChecks=counts,qualification='1524public/104internal peractual11/10 passed initial descriptors/forwarding; after conservative casing block-upper-bound refinement, exact-source final native/branch/async/ordinary-call regressions pass both targets. Full retained-source platform/Stress/installed-core pending.',controls='Local incremental R113 toR114, final controlled qualified1310 tocombinedR113/R114. Frozenworker7cf/host/normaloptional0.4/normalGC/tiering. Native-success integer CSV/JSON and guard-failing floatCSV, unchanged text/report. Independent complete CPython goldens, no CPython timing refresh.')
(r/'identity.json').write_text(json.dumps(i,indent=2)+'\n',encoding='utf8')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src','tests']))
shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
for name in ['measure.py','assess-local.py','compile-diagnostic.py']:
    s=(r.parent/'primitive-helpers-r113'/name).read_text(encoding='utf8')
    if name=='assess-local.py':
        a=s.index("out['limitations']=");z=s.index("\n(r/'assessment-local",a);s=s[:a]+"out['limitations']='R114 incremental normal-settings same-process ALC diagnostic from intermediate d8d2a6fb to independent descriptors/forwarding. Two integer accounting scripts, guard-failing floatCSV, unchanged text/report, both APIs. Allocations include fixture reset/full validation/prior-result cleanup; warm Run-only clocks desktop diagnostic. Final controlled pair uses qualified1310, separate from these incremental deltas.'"+s[z:]
    if name=='compile-diagnostic.py':s=s.replace("s['executionMilliseconds']/s['jobs']","s['elapsedMilliseconds']/s['jobs']")
    (r/name).write_text(s,encoding='utf8')
print('R114 frozen',i['coreSHA256'],counts,flush=True)
