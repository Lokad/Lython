from pathlib import Path
import ast,hashlib,json,shutil,tarfile
r=Path(__file__).parent;old=r.parent/'primitive-helpers-r113/b473';b=r/'b474';b.mkdir()
sour=json.loads((r/'identity.json').read_text(encoding='utf8'));prior=json.loads((old/'identity.json').read_text(encoding='utf8'))
jobs=[[case,lane] for case in ['scripts.csv-integer-accounting.large','scripts.json-integer-accounting.large','scripts.csv-float-accounting.large'] for lane in ['warm','warm-async']]+[['scripts.text-summary-helpers.large','warm'],['scripts.report-render.large','warm']]
identity={**prior,'sourceRevision':sour['candidateSource'],'baselineSource':sour['controlledReference'],'coreSHA256':{role:sour['coreSHA256']['qualified' if role.startswith('reference') else 'candidate'] for role in ['reference','reference-control','candidate','candidate-control']},'productionSources':sour['productionSources'],'qualification':sour['qualification'],'jobs':jobs}
(b/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf8')
for name in ['collect.py','run.sh','retrieve.py','assess-vm.py','archive-owned.py','launch.py']:
    s=(old/name).read_text(encoding='utf8').replace('primitive-helpers-b473-20261108','independent-proof-b474-20261108').replace('lython-b473-primitive-helpers','lython-b474-independent-proof').replace('primitive-helpers-b473-launch.py','independent-proof-b474-launch.py').replace('lython-b473-fixtures','lython-b474-fixtures')
    s=s.replace('len(jobs)==6','len(jobs)==8').replace("len(r['jobs'])==6","len(r['jobs'])==8").replace("len(d['jobs'])==6","len(d['jobs'])==8").replace("['jobs']==6","['jobs']==8").replace('jobs=6','jobs=8').replace('allSixJobsValidated','allEightJobsValidated').replace('ownerSeconds=270','ownerSeconds=270').replace('RuntimeMaxSec=210','RuntimeMaxSec=270').replace('seconds=270','seconds=330').replace('time.monotonic()-started < 180','time.monotonic()-started < 240')
    if name=='collect.py':
        a=s.index('jobs=');z=s.index('\nassert len(jobs)',a);s=s[:a]+'jobs='+repr(jobs)+s[z:]
        a=s.index("purpose='");z=s.index("',\n",a);s=s[:a]+"purpose='R114 coherent exact-integer native proof plus independent immutable source descriptors and ordinary forwarding, qualified1310 reference; complete integerCSV/JSON and failed-proof floatCSV bothAPIs, unchanged text/report"+s[z:]
    if name=='archive-owned.py':
        duplicate='assert shutil.disk_usage(root).free>240*1024*1024\nassert shutil.disk_usage(root).free>240*1024*1024\n'
        s=s.replace(duplicate,'assert shutil.disk_usage(root).free>240*1024*1024\n')
    (b/name).write_text(s,encoding='utf8',newline='\n')
    if name.endswith('.py'):ast.parse(s)
for src,name in [(r/'images/candidate/Lokad.Lython.dll','current-core.dll'),(r/'catalog.json','representative.json'),(r/'identity.json','focused.json'),(r/'source.patch','source.patch'),(r/'pre-measurement-plan.md','pre-measurement-plan.md')]:shutil.copyfile(src,b/name)
shutil.copyfile(old/'baseline-source.json',b/'baseline-source.json')
dynamic=sum((p.stat().st_size+4095)//4096*4096 for p in (old/'retrieved/confirmation').rglob('*') if p.is_file())
estimate=(dynamic*8/6+(old/'observations.tgz').stat().st_size+(r/'catalog.json').stat().st_size)*1.5
assert estimate<12*1024*1024
(b/'sizing.json').write_text(json.dumps(dict(priorRoundedDynamicBytes=dynamic,priorFullArchiveBytes=(old/'observations.tgz').stat().st_size,newCatalogBytes=(r/'catalog.json').stat().st_size,estimateWith50PercentHeadroom=estimate,evidenceHeadroomBytes=12*1024*1024,osFloorBytes=240*1024*1024,baselineArchiveReused=True,noEvidenceDeleted=True),indent=2)+'\n',encoding='utf8')
(b/'setup-contract.json').write_text(json.dumps(dict(jobs=jobs,ownerSeconds=270,stopSeconds=30,marginSeconds=30,evidenceHeadroomMiB=12,osFloorMiB=240),indent=2)+'\n',encoding='utf8')
contract='''R114 combined coherent source pair qualified1310/current exact hashes identity. Existing native proof owns immutable32B instruction descriptors and member/return spans instead of runtime source offsets; ordinary operand forwarding always applies, including failed guards. No new engine/owner/arena/cache/flags or second source instruction array. Generalizes Add-only native integer binary proof through canonical evaluator. Preserve all source checks, preflights/rollback/current cancellation, evaluation order/spans/context, admission reentry, async protocols and cleanup. Additional prepared-node metadata vs fewer ordinary loads measured, no free-storage claim.1524public/104internal peractual11/10 initial checks and final63public/51internal pertarget after bounded compiler adjacency refinement. Initial/source/hash/assertion failures preserved in linked prior evidence, no relaxed protections.
Eight jobs: complete4096-row integerCSV/JSON and failed-proof floatCSV both hostAPIs, unchanged text/report controls. Independent CPython full stdout/file goldens, no new external timing campaign. Same frozenworker7cf/host/optional0.4/normalGC/tiering; two isolated roles/core,5swarmup,7rotated150msrounds.270sowner+30stop+30margin sized before first run for8jobs, no timed-out condition relaxed. Warm includes invocation/mediated RAM I/O/full validation/prior-result cleanup, excludes compile/startup/staging/final cache teardown. Compilation/resident metadata measured separately.
All Ready/core/aux/quiet/golden/baseline/Closed/exit/join/unmount/archive/local gates; persistent evidence, owned128MiB RAMfixtures. OS240MiB+evidence12MiB+actualpayload guard, prior completed8/6scaled dynamic+archive+new catalog+50% fitsheadroom. Baseline archive reused, no historical path/byte/archive removed. Full combined platform/Stress/installed-core at retained decision; R113 intermediate separate. Regex/publication unchanged.
'''
(b/'contract.md').write_text(contract,encoding='utf8')
with tarfile.open(b/'payload.tgz','w:gz') as t:
    for name in ['collect.py','run.sh','current-core.dll','representative.json','identity.json','pre-measurement-plan.md','setup-contract.json','contract.md','focused.json','source.patch','archive-owned.py','baseline-source.json','sizing.json']:t.add(b/name,arcname=name)
print('B474 eight controlled combined-source jobs prepared; unchanged protection/quiet/source gates, no repeated old CI.')
