set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
repo=/mnt/d/code/Lython
lab="$repo/.git/agent-notes/review-20261031/fixed-list-display-admission-20261126"
snapshot=$(mktemp -d "$HOME/lython-list-admission-XXXXXX")
tar -xf "$lab/test-source.tar" -C "$snapshot"
for file in src/Lokad.Lython/Runtime/LythonRuntime.Executable.Slot.cs src/Lokad.Lython/Runtime/PyList.cs; do
    cp "$lab/source/$file" "$snapshot/$file"
    cmp "$lab/source/$file" "$snapshot/$file"
done
printf '%s\n' "$snapshot" > "$lab/ubuntu-source.txt"
cd "$snapshot"
filter='Category!=Stress&(FullyQualifiedName~List|FullyQualifiedName~Csv|FullyQualifiedName~Split|FullyQualifiedName~Starmap|FullyQualifiedName~SimpleFunctionExecutionBoundary|FullyQualifiedName~AdmissionFailureCommand)'
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="$lab/$suite-ubuntu10.log"
    if dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --filter "$filter" > "$log" 2>&1; then
        tail -8 "$log"
    else
        tail -33 "$log"
        exit 1
    fi
done
