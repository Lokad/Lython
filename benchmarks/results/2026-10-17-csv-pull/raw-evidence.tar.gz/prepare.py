import hashlib,json,subprocess,os,fcntl
from pathlib import Path
from datetime import datetime,timezone
stage=Path('/home/lokad/lython-bench-checks/csv-pull-584b09d1')
baseline=Path('/home/lokad/lython-bench-checks/csv-warm-async-1b6a1531/source-candidate')
dotnet='/home/lokad/lython-bench-toolchains/dotnet/10.0.401/dotnet'
revision='1b6a15318b00ec056af02e23b72fa64f861964df'
status={'state':'Starting','baseRevision':revision,'startedUtc':datetime.now(timezone.utc).isoformat(),'candidateKind':'one frozen runtime file on immutable base; not an immutable candidate build'}
def save(): (stage/'preparation.json').write_text(json.dumps(status,indent=2)+'\n')
def run(args,log=None,cwd=None):
    result=subprocess.run(args,cwd=cwd,env=env,capture_output=True,text=True)
    if log:(stage/log).write_text(result.stdout+result.stderr)
    if result.returncode:raise RuntimeError(str(args[:2])+':'+(result.stderr or result.stdout)[-1800:])
    return result.stdout.strip()
env=dict(os.environ,DOTNET_ROOT=str(Path(dotnet).parent),DOTNET_NOLOGO='1',DOTNET_CLI_TELEMETRY_OPTOUT='1',MSBUILDDISABLENODEREUSE='1',DOTNET_CLI_USE_MSBUILD_SERVER='0',GIT_TERMINAL_PROMPT='0')
save()
try:
    with Path('/home/lokad/lython-bench-checks/comparison-vm.lock').open('a+') as lease:
        fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
        assert run(['git','-C',str(baseline),'rev-parse','HEAD'])==revision
        assert not run(['git','-C',str(baseline),'status','--porcelain'])
        root=stage/'candidate';assert not root.exists()
        status['state']='Checkout';save()
        run(['git','clone','--shared','--no-checkout',str(baseline),str(root)],log='clone.log')
        run(['git','-C',str(root),'remote','set-url','origin','https://github.com/Lokad/Lython.git'])
        run(['git','-C',str(root),'config','core.sparseCheckout','true'])
        (root/'.git/info/sparse-checkout').write_bytes((baseline/'.git/info/sparse-checkout').read_bytes())
        run(['git','-C',str(root),'checkout','--detach',revision],log='checkout.log')
        assert not run(['git','-C',str(root),'status','--porcelain'])
        expected=json.loads((stage/'frozen-source.json').read_text())
        relative='src/Lokad.Lython/Runtime/LythonRuntime.CsvModule.cs'
        candidate=(stage/'candidate-CsvModule.cs').read_bytes();assert hashlib.sha256(candidate).hexdigest()==expected['canonicalSha256']
        (root/relative).write_bytes(candidate)
        assert run(['git','-C',str(root),'diff','--name-only'])==relative
        status.update(state='Building',root=str(root),sourceFile=relative,sourceSha256=expected['canonicalSha256'],sourceStatus=run(['git','-C',str(root),'status','--porcelain']))
        save()
        launch=stage/'build-launch';launch.mkdir();(launch/'global.json').write_text(json.dumps({'sdk':{'version':'10.0.401','rollForward':'disable'}}))
        run([dotnet,'build',str(root/'benchmarks/Lokad.Lython.Benchmarks/Lokad.Lython.Benchmarks.csproj'),'-c','Release','-v','minimal','-nodeReuse:false'],cwd=launch,log='build.log')
        worker=root/'benchmarks/Lokad.Lython.Benchmarks/bin/Release/net10.0/Lokad.Lython.Benchmarks.dll'
        patch=run(['git','-C',str(root),'diff','--',relative]);(stage/'candidate.patch').write_text(patch+'\n')
        assert run(['git','-C',str(root),'diff','--name-only'])==relative
        assert hashlib.sha256((root/relative).read_bytes()).hexdigest()==expected['canonicalSha256']
        assert not run(['git','-C',str(baseline),'status','--porcelain'])
        status.update(state='Completed',completedUtc=datetime.now(timezone.utc).isoformat(),buildSdk='10.0.401',worker=str(worker),workerSha256=hashlib.sha256(worker.read_bytes()).hexdigest(),librarySha256=hashlib.sha256(worker.with_name('Lokad.Lython.dll').read_bytes()).hexdigest(),catalog='/home/lokad/lython-bench-checks/csv-warm-async-1b6a1531/catalog.json',baselineWorker=str(baseline/'benchmarks/Lokad.Lython.Benchmarks/bin/Release/net10.0/Lokad.Lython.Benchmarks.dll'),sourceStatusAfter=run(['git','-C',str(root),'status','--porcelain']))
        save()
except BaseException as error:
    status.update(state='Failed',error=repr(error),completedUtc=datetime.now(timezone.utc).isoformat());save();raise
