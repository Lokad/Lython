from pathlib import Path
import base64, hashlib, importlib.util, json, subprocess, tempfile

lab=Path(__file__).resolve().parent
notes=lab.parent
repo=lab.parents[3]
def load(path): return json.loads(path.read_text(encoding='utf-8'))
def sha(value): return hashlib.sha256(value.encode('utf-8')).hexdigest()

catalog=load(notes/'direct-native-text-dict-keys/representative.json')
cases={case['id']:case for case in catalog['cases']}
shipment=cases['scripts.report-render.named-format-selectors.large']
input_names=json.loads(shipment['fixtureJson'])['inputFiles']
incoming=base64.b64decode(input_names['records.json'])
count=len(json.loads(incoming))
assert count==3072
source="""import json

def normalize(row):
    return {"name": row["name"].strip(), "state": row["state"].upper(), "amount": row["amount"]}

with open("records.json", encoding="utf-8") as source:
    records = json.load(source)
normalized = [normalize(row) for row in records]
with open("normalized.json", "w", encoding="utf-8", newline="") as target:
    target.write(json.dumps(normalized, ensure_ascii=False, separators=(",", ":")))
print(len(normalized), sum(row["amount"] for row in normalized))
"""
with tempfile.TemporaryDirectory(prefix='lython-reference-normalization-') as root:
    folder=Path(root)
    (folder/'records.json').write_bytes(incoming)
    completed=subprocess.run(['C:/Python313/python.exe','-I','-X','utf8','-c',source],cwd=root,check=True,
                             capture_output=True,encoding='utf-8',timeout=20)
    expected=completed.stdout
    output=(folder/'normalized.json').read_bytes()
    assert len(json.loads(output))==count
spec=importlib.util.spec_from_file_location('protocol',repo/'benchmarks/cpython-worker.py')
protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
fixture=json.dumps(dict(size=count,text=None,inputFiles=input_names,
    outputFiles={'normalized.json':base64.b64encode(output).decode('ascii')}),separators=(',',':'))
case=dict(shipment,id='scripts.json-normalized-records.large',family='scripts',category='json-record-construction',
    scale='large',size=count,source=source,fixtureJson=fixture,expectedOutput=expected,
    sourceUtf8Bytes=len(source.encode('utf-8')),expectedOutputUtf8Bytes=len(expected.encode('utf-8')),
    fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,sourceSha256=sha(source),fixtureSha256=sha(fixture),
    expectedOutputSha256=sha(expected),expectedFilesSha256=protocol.file_digest({'normalized.json':output}))
catalog['cases']=[case,cases['scripts.config-manifest.helper-guards'],cases['scripts.config-generated-guards.medium.bad-0']]
(lab/'representative.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(count,len(incoming),len(output),expected.strip())
