import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile
from pathlib import Path

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
template = lab.parent / "private-callsite-preparation/rebased/quiet"
donor = lab.parent / "direct-native-text-dict-keys/quiet"
q = lab / "quiet"
core = "Lokad.Lython.dll"


def read(path):
    return path.read_text(encoding="utf-8")


def load(path):
    return json.loads(read(path))


def emit(path, text):
    if path.suffix == ".py":
        compile(text, str(path), "exec")
    path.write_text(text, encoding="utf-8", newline="\n")


def save(path, value):
    emit(path, json.dumps(value, indent=2) + "\n")


def sha(content):
    return hashlib.sha256(content).hexdigest()


def file_sha(path):
    return sha(path.read_bytes())


def committed(path):
    return subprocess.check_output(["git", "cat-file", "blob", "39b6400f7:" + path], cwd=repo)


def retire(canonical, expected_sha, cases):
    image = gzip.decompress(committed(canonical))
    assert sha(image) == expected_sha
    archives = {}
    paths = []
    for remote, role, result in cases:
        results = f"benchmarks/results/{result}"
        receipt = json.loads(committed(f"{results}/archive-receipt.json"))
        content = committed(f"{results}/observations.tgz")
        assert all(receipt[key] for key in ("complete", "allWorkersJoined", "guestFixturesRemoved", "archivedAndVerifiedUnderLease"))
        assert receipt["archiveSHA256"] == sha(content)
        archives[f"{remote}/observations.tgz"] = receipt["archiveSHA256"]
        paths.append(f"{remote}/{role}/{core}")
    return dict(archives=archives, paths=paths, bytes=len(image), links=len(paths),
                sha256=expected_sha, verifiedCanonicalGitImage=canonical)


index = load(lab / "identity.json")
assert index["reference"].startswith("c62457d49") and index["candidate"].startswith("6c964a71b")
old = load(template / "config.json")
donor_config = load(donor / "config.json")
donor_receipt = load(donor / "archive-receipt.json")
assert donor_receipt["complete"] and donor_receipt["archivedAndVerifiedUnderLease"]
assert donor_receipt["archiveSHA256"] == file_sha(donor / "observations.tgz")
source_files = donor_config["identity"]["imageFiles"]["candidate"]
protocol_root = lab.parent / "private-stable-parameter-captures/quiet"
protocol_config = load(protocol_root / "config.json")
protocol = protocol_config["protocolSHA256"]
assert index["pythonWorkerSHA256"] == protocol
manifest = lab / "representative.json"
assert file_sha(manifest) == index["catalogSHA256"]
for role, files in index["imageFiles"].items():
    assert len(files) == len(source_files) == 32
    assert set(files) == set(source_files)
    assert [n for n in files if files[n] != source_files[n]] == ([core] if role == "candidate" else [])
    assert {n: file_sha(lab / "frozen" / role / n) for n in files} == files
    verification = load(lab / f"{role}-verify.json")
    assert verification["state"] == "Completed"
    assert verification["catalogSha256"] == index["catalogSHA256"]

older = load(lab.parent / "postponed-annotation-cpython/quiet/identity.json")
proposals = [retire("benchmarks/results/2026-11-20-cpython-postponed-annotation-payload/measured-core.dll.gz",
    older["coreSHA256"]["candidate"],[
        ("annotation-shipment-cpython-b1240-20261120","candidate","2026-11-20-cpython-postponed-annotation-payload"),
        ("callsite-preparation-b1241-20261120","reference","2026-11-20-callsite-preparation"),
        ("callsite-preparation-confirm-b1242-20261120","reference","2026-11-20-callsite-preparation/confirmation"),
    ])]
root = "/home/lokad/lython-bench-checks/compiled-literal-record-keys-b1249-20261120"
unit = "lython-b1249-compiled-literal-record-keys-20261120"
q.mkdir()
images = index["imageFiles"]
identity = dict(sourceRevision=index["reference"] + " versus " + index["candidate"],
                purpose="Compile unique literal key tables and fill final private records directly",
                catalogSHA256=index["catalogSHA256"], imageFiles=images, normalAdapterPin="0.4.0",
                coreSHA256={role + suffix: names[core] for role, names in images.items() for suffix in ("", "-control")})
save(q / "identity.json", identity)
jobs = [("scripts.json-normalized-records.large","warm"), ("scripts.config-manifest.helper-guards","warm"),
        ("scripts.config-manifest.helper-guards","compile-run"), ("scripts.config-generated-guards.medium.bad-0","compile-run")]
assert len(jobs) == 4 and {case for case,lane in jobs} == {r["id"] for r in load(manifest)["cases"]}
for name in ("collect.py", "archive-owned.py", "run.sh", "retrieve.py"):
    content = read(template / name).replace(old["root"], root).replace(old["unit"], unit)
    if name == "collect.py":
        start = content.index("\njobs = ")
        end = content.index("\nassert len(jobs)", start)
        content = content[:start] + "\njobs = " + repr(jobs) + content[end:]
    emit(q / name, content)
assert b"\r" not in (q / "run.sh").read_bytes()

parts = ["identity.json", "representative.json", "collect.py", "archive-owned.py", "run.sh"]
shutil.copyfile(manifest, q / "representative.json")
for role in ("candidate",):
    (q / role).mkdir()
    shutil.copyfile(lab / "frozen" / role / core, q / role / core)
    parts.append(f"{role}/{core}")
with tarfile.open(q / "payload.tgz", "w:gz") as payload:
    for part in parts:
        payload.add(q / part, arcname=part)
config = dict(root=root, unit=unit, source=donor_config["root"], sourceRole="candidate", sourceFiles=source_files,
              sourceCatalogSHA256=donor_config["catalogSHA256"], protocolSHA256=protocol, protocolSource=protocol_config["root"] + "/cpython-worker.py", catalogSHA256=index["catalogSHA256"],
              identity=identity, retireGroups=proposals, donorArchiveSHA256=donor_receipt["archiveSHA256"],
              payloadBytes=(q / "payload.tgz").stat().st_size, payloadSHA256=file_sha(q / "payload.tgz"),
              unpackedBytes=sum((q / part).stat().st_size for part in parts))
save(q / "config.json", config)
content = read(template / "remote-launch.py")
start = content.index("\nc=") + 1
end = content.index("\nb=Path(", start)
content = (content[:start] + "c=" + repr(config) + content[end:]).replace("lython-b1241-fixtures", "lython-b1249-fixtures")
assert "proof['archives']" in content and "176160768+c['unpackedBytes']+64*1024*1024" in content

content = content.replace("source/'cpython-worker.py'", "Path(c['protocolSource'])")
assert "protocolSource" in content and "assert sha(source/'representative.json')" in content
assert not (q / "reference").exists()
emit(q / "remote-launch.py", content)
launch = read(template.parent / "launch.py").replace("Call-site preparation comparison", "Compiled literal record keys comparison")
emit(lab / "launch.py", launch)
