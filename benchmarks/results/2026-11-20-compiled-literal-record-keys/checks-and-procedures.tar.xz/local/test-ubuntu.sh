#!/usr/bin/env bash
set -euo pipefail
repo=/mnt/d/code/Lython
cd "$repo/.git/agent-worktrees/compiled-literal-record-keys"
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs="$repo/.git/agent-notes/review-20261031/compiled-literal-record-keys"
dotnet test tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj -c Release -f net10.0 --filter '(FullyQualifiedName~Record|FullyQualifiedName~CompilationOwnership|FullyQualifiedName~ExecutableOperand)&Category!=Stress' -v quiet 2>&1 | tee "$logs/white-ubuntu.log"
dotnet test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --filter '(FullyQualifiedName~Dict|FullyQualifiedName~Manifest|FullyQualifiedName~Record|FullyQualifiedName~Ownership|FullyQualifiedName~CallExpansion)&Category!=Stress' -v quiet 2>&1 | tee "$logs/public-ubuntu.log"
