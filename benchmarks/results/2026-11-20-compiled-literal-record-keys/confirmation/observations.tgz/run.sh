set -eu
root=/home/lokad/lython-bench-checks/compiled-literal-record-keys-confirm-b1250-20261120
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
