No classification change in E3a; previous E1/E2 source and qualification remain independent.
