using System.Numerics;
using Lokad.Lython.Runtime.Numbers;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed class PyValueComparer : IEqualityComparer<object>
{
    public static readonly PyValueComparer Instance = new();

    // Native table probes already carry their caller. Keep CLR comparer callbacks
    // context-free while forwarding explicit cancellation through long text scans.
    internal bool Equals(object? x, object? y, LythonRuntime.ExecutionContext? context, LythonSourceSpan? span)
    {
        // Identity never scans storage; preserve the original table shortcut.
        if (ReferenceEquals(x, y)) return x is not null;
        return context is not null && x is PyString leftText && y is PyString rightText
            ? leftText.Equals(rightText, context, span) : Equals(x, y);
    }

    public new bool Equals(object? x, object? y)
    {
        // Key probing accepts identity even for non-reflexive values such as
        // NaN. Ordinary value equality retains its separate numeric rules.
        if (ReferenceEquals(x, y)) return x is not null;

        // Sealed UTF-8 strings cannot invoke guest code or recurse structurally.
        if (x is PyString leftText && y is PyString rightText)
            return leftText.Equals(rightText);

        // R13: comparer callbacks stay context-free even when reached under an
        // ambient comparison (for example a dict lookup inside __eq__): nested
        // structural positions observe the suppression and never dispatch
        // guest code through comparer internals.
        using (PyStructuralGuard.SuppressGuestDispatch())
        {
            return x is not null && y is not null && PyEquality.AreEqual(x, y);
        }
    }

    public int GetHashCode(object obj)
    {
        var hash = obj switch
        {
            IPyHashableValue hashable => hashable.GetPyHashCode(),
            _ when PyNumberOps.TryAsNumber(obj, out var numeric) => PyNumberOps.GetHashCode(numeric),
            _ => throw new PyUnhashableException(obj)
        };
        return NormalizeHash(hash);
    }

    internal static int NormalizeHash(int hash) => hash == -1 ? -2 : hash;
}
