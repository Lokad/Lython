from pathlib import Path
r=Path(__file__).parent
s=(r/'measure.py').read_text(encoding='utf-8')
p=r/'refined';p.mkdir()
s=s.replace('r=Path(__file__).parent;repo=', 'base=Path(__file__).parent.parent;r=Path(__file__).parent;repo=')
s=s.replace("prior=r.parent/'native-construction-r167'", "prior=base.parent/'native-construction-r167'")
s=s.replace("r.parent/'bulk-whitespace-r157/tool/out/complete-jobs.dll'", "base.parent/'bulk-whitespace-r157/tool/out/complete-jobs.dll'")
compile(s,'refined/measure.py','exec')
(p/'measure.py').write_text(s,encoding='utf-8')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')+'''
R172 original27internal/837public each11/10 pass, with long public Stress cases
selected inadvertently; preserve them, exclude Stress explicitly in later focused
public filters. One diagnostic all goldens/balances: async config+6.76..10.22%,
textsync−0.98..+6.46% and drifting controls. Preserve original source/raw. Refine
by keeping the context-free comparer body unchanged; explicit context overload
only handles native text probes. One changed-source check/comparison justified,
no causal CPU/JIT claim. Full R167 retry42667400495 independent.
''';p.write_text(s,encoding='utf-8',newline='\n')
