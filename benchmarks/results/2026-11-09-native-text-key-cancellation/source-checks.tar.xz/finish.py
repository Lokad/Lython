from pathlib import Path
r=Path(__file__).parent
p=r/'final';p.mkdir()
(p/'measure.py').write_bytes((r/'refined/measure.py').read_bytes())
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')+'''
R172 refined27internal/825public each11/10 pass; public now explicitly excludes
Stress. Changed-source desktop: configsync−1.42..+2.00/async−3.86..+0.77%, but
CSVsync+9.21..10.96/async+6.15..6.51%. Source review finds the explicit overload
lost the original identity shortcut and checks cancellation even for the same key.
Restore constant-time identity before contextual text scanning. Final focused
checks and one final short comparison; preserve both prior attempts and decide
remaining regression debt. No more retiming at this boundary absent new defects.
''';p.write_text(s,encoding='utf-8',newline='\n')
