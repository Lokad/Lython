from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess
base=Path(__file__).parent.parent;r=Path(__file__).parent;repo=Path('D:/code/Lython');prior=base.parent/'native-construction-r167'
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
dotnet=env['DOTNET_ROOT']+'/dotnet.exe'
with (r/'nonincremental-build.log').open('w',encoding='utf-8') as log:
    run=subprocess.run([dotnet,'build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-restore','--no-incremental'],env=env,stdout=log,stderr=subprocess.STDOUT)
assert run.returncode==0
shutil.copytree(prior/'final/images/candidate',r/'images/before')
shutil.copytree(r/'images/before',r/'images/candidate')
shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'images/candidate/Lokad.Lython.dll')
assert all(p.read_bytes()==(r/'images/candidate'/p.name).read_bytes()for p in (r/'images/before').iterdir()if p.is_file()and p.name!='Lokad.Lython.dll')
shutil.copyfile(prior/'catalog.json',r/'catalog.json')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src/Lokad.Lython','tests','CHANGELOG.md','docs/RUNTIME.md']))
(r/'identity.json').write_text(json.dumps(dict(baseline='43350e4f-equivalent R167 freeze, no R172 source; test/docs commits change no runtime',purpose='R172 current-context native text-key equality; reused R157 five-script complete-job desktop driver, diagnostic only',cores={n:hashlib.sha256((r/f'images/{n}/Lokad.Lython.dll').read_bytes()).hexdigest()for n in ['before','candidate']},productionSources={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in (repo/'src/Lokad.Lython').rglob('*.cs')if 'obj'not in p.parts},driverSHA256=hashlib.sha256((base.parent/'bulk-whitespace-r157/tool/out/complete-jobs.dll').read_bytes()).hexdigest()),indent=2)+'\n',encoding='utf-8')
summary={}
for api in ['sync','async']:
    folder=r/('warm-'+api);folder.mkdir()
    witness=folder/'hash-witness.json';witness.write_text(json.dumps(dict(source="return [hash('Lython-é😀'), hash((1, 2.0, True))]\n"),ensure_ascii=False)+'\n',encoding='utf-8')
    with (folder/'measurements.json').open('w',encoding='utf-8')as out,(folder/'stderr.txt').open('w',encoding='utf-8')as err:
        run=subprocess.run([dotnet,str(base.parent/'bulk-whitespace-r157/tool/out/complete-jobs.dll'),str(r/'images/before/Lokad.Lython.Benchmarks.dll'),str(r/'images/candidate/Lokad.Lython.Benchmarks.dll'),str(r/'catalog.json'),str(witness),'reverse','warm',api],env=env,stdout=out,stderr=err,timeout=120)
    assert run.returncode==0,(folder/'stderr.txt').read_text(encoding='utf-8')[-2000:]
    data=json.loads((folder/'measurements.json').read_text(encoding='utf-8'))
    assert all(data[k]for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
    entries=[]
    for case in data['observations']:
        groups={role:[s for s in case['samples']if s['image']==role]for role in ['before','before-control','candidate']}
        values={role:dict(elapsedMs=statistics.median(s['elapsedMilliseconds']/s['jobs']for s in samples),executionMs=statistics.median(s['executionMilliseconds']/s['jobs']for s in samples),allocatedBytes=statistics.median(s['allocatedBytes']/s['jobs']for s in samples))for role,samples in groups.items()}
        change={metric:[100*(values['candidate'][metric]/values[role][metric]-1)for role in ['before','before-control']]for metric in ['elapsedMs','allocatedBytes']}
        entries.append(dict(case=case['caseId'],roles=values,changePercent=change))
    summary[api]=entries;print(api,'goldens/funding/cleanup passed',[(v['case'],v['changePercent'])for v in entries],flush=True)
(r/'desktop.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
