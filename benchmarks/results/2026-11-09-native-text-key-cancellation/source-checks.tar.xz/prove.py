from pathlib import Path
import hashlib,json,os,shutil,subprocess
root=Path(__file__).parent;repo=Path('D:/code/Lython');old=root.parent/'native-construction-r167/final/images/candidate/Lokad.Lython.dll'
assert old.exists()
folder=root/'frozen-old';shutil.copytree(repo/'tests/Lokad.Lython.Tests/bin/Release/net11.0',folder)
shutil.copyfile(old,folder/'Lokad.Lython.dll')
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
with (root/'frozen-old.log').open('w',encoding='utf-8') as log:
    run=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','test',str(folder/'Lokad.Lython.WhiteBox.Tests.dll'),'--filter','FullyQualifiedName~NativeTextKeyCancellationTests&Category=Stress'],env=env,stdout=log,stderr=subprocess.STDOUT)
text=(root/'frozen-old.log').read_text(encoding='utf-8');print(text[-2400:])
assert run.returncode!=0 and text.count('Text-key probe returned after cancellation was requested.')==2
assert 'Failed:     2' in text
(root/'regression-proof.json').write_text(json.dumps(dict(baselineRevision='43350e4f-equivalent final R167 precommit freeze',coreSHA256=hashlib.sha256(old.read_bytes()).hexdigest(),assemblySHA256=hashlib.sha256((folder/'Lokad.Lython.WhiteBox.Tests.dll').read_bytes()).hexdigest(),failed=2,condition='Actual existing dictionary read/write entry points with precomputed equal-key hashes; no ambient context. The same new test assembly passes against current core. No source restore or test-only checkpoint.'),indent=2)+'\n',encoding='utf-8')
