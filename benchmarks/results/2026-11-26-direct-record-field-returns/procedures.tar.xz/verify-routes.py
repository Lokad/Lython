from pathlib import Path

lab=Path(__file__).resolve().parent
template=lab.with_name('arithmetic-operand-borrows-20261126')/'verify-routes.py'
source=template.read_text(encoding='utf-8')
source=source.replace("fields = ['Borrow','IntegerHead','Floating','ObjectRead','Fallback','Global']",
                      "fields = ['DirectFieldReturns','NativeFieldBodies','BorrowedIterationPrefixes']")
start=source.index("    head='    private static bool CanBorrowForwardedInteger'")
end=source.index("    (variant/'diagnostic.patch').write_text",start)
body=r"""    fields_source=''.join(f'    internal static int Diagnostic{name};\n' for name in fields)+'\n'
    head='    private static bool CanBorrowForwardedInteger'
    replace('Operands',head,fields_source+head)
    old='        private bool RunCore(out ExecutableSlot result)\n        {'
    replace('NativePrefix',old,old+'''
            if (Code.Name is "quantity" or "energy") Interlocked.Increment(ref DiagnosticNativeFieldBodies);''')
    if role=='candidate':
        old='''        if (value.Reference is LythonRuntimeException failure) throw failure;

        scope.CheckExecution(code.Instructions[3].Span);
        return true;'''
        replace('IntegerChains',old,old.replace('        return true;',
            '        Interlocked.Increment(ref DiagnosticDirectFieldReturns);\n        return true;'))
    name='src/Lokad.Lython/Runtime/PyExecutableFunction.cs'
    path=source/name
    original=path.read_text(encoding='utf-8')
    old='            StartInline(storage, null, span, false, default, out _, out result, out frame, out owned);'
    assert original.count(old)==1
    revised=original.replace(old,'            Interlocked.Increment(ref LythonRuntime.DiagnosticBorrowedIterationPrefixes);\n'+old)
    path.write_text(revised,encoding='utf-8',newline='\n')
    patches.extend(unified_diff(original.splitlines(keepends=True),revised.splitlines(keepends=True),'a/'+name,'b/'+name))
"""
source=source[:start]+body+source[end:]
exec(compile(source,str(template),'exec'),{'__file__':str(lab/'verify-routes.py')})