from difflib import unified_diff
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import zipfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
templates = lab.with_name('shipment-integer-store-20261126')
identity = json.loads((lab/'identity.json').read_text(encoding='utf-8'))
def git(*args):
    return subprocess.check_output(['git',*args],cwd=repo)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert git('diff','--binary','--','src') == (lab/'candidate.patch').read_bytes()
assert sha(lab/'candidate.patch') == identity['sourcePatchSHA256']
work = lab/'instrumented'
work.mkdir()
archive = work/'source.zip'
git('archive','--format=zip','--output',str(archive),identity['sourceRevision'],'--','src','Directory.Build.props',
    'Directory.Build.targets','Directory.Build.rsp','Directory.Packages.props','global.json','NuGet.Config')
changed = git('diff','--name-only','--','src').decode().splitlines()
program = (templates/'Program.cs').read_text(encoding='utf-8')
fields = ['Borrow','IntegerHead','Floating','ObjectRead','Fallback','Global']
program = program.replace('["IntegerStoreCandidates", "IntegerStoreExisting", "IntegerStoreNativePrefix", "IntegerStorePackedKeys"]',json.dumps(fields))
program = program.replace('Lokad.Lython.Runtime.LythonRuntime+ExecutionContext','Lokad.Lython.Runtime.LythonRuntime')
catalog = json.loads((lab/'representative.json').read_text(encoding='utf-8'))
catalog['cases']=[case|dict(runAsync=mode) for case in catalog['cases'] for mode in (False,True)]
(work/'cases.json').write_text(json.dumps(catalog,ensure_ascii=False),encoding='utf-8',newline='\n')

def do(role):
    variant = work/role
    variant.mkdir()
    source = variant/'source'
    with zipfile.ZipFile(archive) as frozen:
        assert all(not Path(name).is_absolute() and '..' not in Path(name).parts for name in frozen.namelist())
        frozen.extractall(source)
    if role=='candidate':
        for name in changed:
            shutil.copyfile(repo/name,source/name)
    patches=[]
    prefix='src/Lokad.Lython/Runtime/LythonRuntime.Executable.'
    def replace(name, old, new):
        relative=prefix+name+'.cs'
        path=source/relative
        original=path.read_text(encoding='utf-8')
        assert original.count(old)==1,(name,old,original.count(old))
        changed=original.replace(old,new)
        path.write_text(changed,encoding='utf-8',newline='\n')
        patches.extend(unified_diff(original.splitlines(keepends=True),changed.splitlines(keepends=True),'a/'+relative,'b/'+relative))

    head='    private static bool CanBorrowForwardedInteger'
    statics=''.join(f'    internal static int Diagnostic{field};\n' for field in fields)+'\n'
    replace('Operands',head,statics+head)
    var='        var name = code.Names[nameIndex];\n        var globalContext = GetGlobalContext(context);'
    replace('Binding',var,'        Interlocked.Increment(ref DiagnosticGlobal);\n'+var)
    if role=='reference':
        probe='''    private static bool ProbeArithmeticInteger(ExecutableCodeObject code, ReadOnlySpan<ExecutableSlot> values,
        int source, ExecutionContext scope, out long value, ExecutableCaptures captures)
    {
        Interlocked.Increment(ref DiagnosticIntegerHead);
        return TryReadMachineOperand(code, values, source, scope, out value, captures);
    }

'''
        anchor='    private static bool TryEvaluateIntegerInstruction'
        replace('Integers',anchor,probe+anchor)
        old='''            || !TryReadMachineOperand(code, values, instruction.InputStart, context, out var left, captures)
            || !TryReadMachineOperand(code, values, instruction.SecondInput, context, out var right, captures)) return false;'''
        replace('Integers',old,old.replace('TryReadMachineOperand','ProbeArithmeticInteger'))
        old='        if (source >= 0) return values[source].TryGetDouble(out value);'
        replace('Operands',old,'        Interlocked.Increment(ref DiagnosticFloating);\n'+old)
        for index in ('first','second'):
            old=f'        var {index} = ReadExecutableOperand'
            replace('Arithmetic',old,'        Interlocked.Increment(ref DiagnosticObjectRead);\n'+old)
        old='            var retained = instruction.OpCode == ExecutableOpCode.Subscript && invocation?._preparedCallValue is not null;'
        replace('Inputs',old,'''            if (instruction.OpCode is ExecutableOpCode.Binary or ExecutableOpCode.Augmented or ExecutableOpCode.Unary)
                Interlocked.Add(ref DiagnosticFallback, instruction.OpCode == ExecutableOpCode.Unary ? 1 : 2);
'''+old)
    else:
        old='        ExecutableCell? cell;\n        if (source >= 0)'
        replace('Operands',old,'        Interlocked.Increment(ref DiagnosticBorrow);\n'+old)
        old='            first ??= retained ? execution.Stack[instruction.ResultSlot]'
        replace('Inputs',old,'''            if (first is null && instruction.OpCode is ExecutableOpCode.Binary or ExecutableOpCode.Augmented or ExecutableOpCode.Unary)
                Interlocked.Add(ref DiagnosticFallback, instruction.OpCode == ExecutableOpCode.Unary ? 1 : 2);
'''+old)
    (variant/'diagnostic.patch').write_text(''.join(patches),encoding='utf-8',newline='\n')
    image = variant/'image'
    image.mkdir()
    for name,digest in identity['imageFiles'][role].items():
        origin=lab/role/name
        assert sha(origin)==digest
        shutil.copyfile(origin,image/name)
    (variant/'Program.cs').write_text(program,encoding='utf-8',newline='\n')
    shutil.copyfile(templates/'RouteProbe.csproj',variant/'RouteProbe.csproj')
    sdk=Path.home()/'.dotnet11'
    dotnet=sdk/'dotnet.exe'
    env=dict(os.environ,DOTNET_ROOT=str(sdk))
    def run(args, log):
        with (variant/log).open('wb') as output:
            subprocess.run([dotnet,*args],stdout=output,stderr=subprocess.STDOUT,cwd=repo,env=env,check=True,timeout=150)
    run(['build',source/'src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-incremental','-o',variant/'core'],'core.log')
    shutil.copyfile(variant/'core/Lokad.Lython.dll',image/'Lokad.Lython.dll')
    run(['build',variant/'RouteProbe.csproj','-c','Release','-o',variant/'probe'],'probe.log')
    for p in (variant/'probe').glob('RouteProbe*'):
        shutil.copyfile(p,image/p.name)
    run([image/'RouteProbe.dll',image,work/'cases.json',variant/'routes.json'],'verification.log')
    for row in json.loads((variant/'routes.json').read_text(encoding='utf-8'))['rows']:
        print(role,row['id'],row['asynchronous'],row['routes'],flush=True)

for role in ('reference','candidate'):
    do(role)