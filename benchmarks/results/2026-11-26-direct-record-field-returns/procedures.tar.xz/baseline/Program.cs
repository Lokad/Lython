using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Text;

using var manifest = JsonDocument.Parse(File.ReadAllText(args[0]));
var workload = manifest.RootElement.GetProperty("cases").EnumerateArray()
    .Single(row => row.GetProperty("id").GetString() == args[1]);
var frontend = LythonFrontend.Compile(workload.GetProperty("source").GetString()!);
if (frontend.Script is null) throw new InvalidOperationException("The text fixture did not compile.");
var root = ExecutableScript.Compile(frontend.Script).EntryPoint;
var codes = new List<object>();
var visited = new HashSet<ExecutableCodeObject>(ReferenceEqualityComparer.Instance);
Inspect(root);
var core = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))).ToLowerInvariant();
Console.WriteLine(JsonSerializer.Serialize(new { core, sourceSHA256 = workload.GetProperty("sourceSha256").GetString(), codes },
    new JsonSerializerOptions { WriteIndented = true }));

void Inspect(ExecutableCodeObject code)
{
    if (!visited.Add(code)) return;
    codes.Add(new
    {
        code.Name, code.EntryIndex, code.NativePrefixEnd, code.HasDirectOperandReturn, code.DirectCasedReturnIndex,
        code.CanRunNativeInstructions, code.ValueStorageCapacity, code.FirstTemporarySlot, code.Names,
        constants = code.Constants.Select(value => value is PyString text ? text.AsString() : value?.GetType().Name),
        calls = code.CallSites.Select(call => new {call.ArgumentCount, call.ArgumentOffset, call.HasReceiver,
            call.IsPositionalOnly, call.ConsumedByIteration, call.ReturnedDirectly,
            call.AccumulatesDictionary, split = call.SplitPrefix?.GetType().Name }),
        instructions = code.Instructions.Select(step => new { op = step.OpCode.ToString(), step.InputStart,
            step.SecondInput, step.ResultSlot, step.LiveExtent, step.HasResultConsumer, forwarded = step.OpCode == ExecutableOpCode.Call && step.HasForwardedCallOperands, cache = step.OpCode == ExecutableOpCode.Subscript ? step.LookupCacheIndex : -1,
            member = step.OpCode is ExecutableOpCode.LoadCallMember or ExecutableOpCode.LoadCasedSplit ?
                code.Names[step.NameIndex] : null })
    });
    foreach (var child in code.Constants.OfType<ExecutableCreateFunction>()) Inspect(child.CodeObject);
}
