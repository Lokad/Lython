from pathlib import Path
import hashlib
import json
import os
import subprocess

lab=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
confirmed=lab.with_name('identity-comparisons-confirmation-20261126')/'comparison/quiet'
initial=lab.with_name('identity-comparisons-20261126')
trial=lab.with_name('arithmetic-operand-borrows-20261126')
confirmation_identity=read(confirmed/'identity.json')
trial_quiet=trial/'comparison/quiet'
trial_identity=read(trial_quiet/'identity.json')
for location, parent, identity in [(confirmed,initial,confirmation_identity),(trial_quiet,trial,trial_identity)]:
    receipt=read(location/'terminal-status.json')['receipt']
    assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
    assert sha(location/'observations.tar.xz')==receipt['archiveSHA256']
    expected=identity['imageFiles']['candidate']
    assert len(expected)==32 and {p.name:sha(p) for p in (parent/'candidate').iterdir()}==expected
staged=read(lab/'comparison/quiet/upload.json')
settings={
    'minimum':13*1024*1024+staged['payloadBytes']+128*1024,
    'confirmation':confirmation_identity['imageFiles']['candidate'],
    'trial':trial_identity['imageFiles']['candidate'],
    'confirmationArchive':sha(confirmed/'observations.tar.xz'),
    'trialArchive':sha(trial_quiet/'observations.tar.xz'),
}
remote='cfg='+repr(settings)+'''
from pathlib import Path
import fcntl, hashlib, json, os, shutil, subprocess
base=Path('/home/lokad/lython-bench-checks')
assert base.resolve()==base
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def finished(name, unit, digest):
    root=base/name
    assert root.resolve()==root and root.parent==base
    state=subprocess.run(['systemctl','show',unit+'.service','--property=ActiveState,MainPID'],
                         capture_output=True,text=True,check=True).stdout.splitlines()
    assert 'ActiveState=inactive' in state and 'MainPID=0' in state,state
    receipt=json.loads((root/'archive-receipt.json').read_text())
    assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
    assert receipt['archiveSHA256']==digest==sha(root/'observations.tar.xz')
    assert not (root/'guest-fixtures').exists()
    role=root/'candidate'
    assert role.resolve()==role
    return role
def image(folder, expected):
    assert len(expected)==32 and {p.name:sha(p) for p in folder.iterdir()}==expected
def regular(file,digest):
    assert file.resolve()==file and file.is_file() and file.stat().st_nlink==1 and sha(file)==digest
before=shutil.disk_usage(base).free
actions=[]
if before <= cfg['minimum']:
    with (base/'comparison-vm.lock').open('a') as lease:
        fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
        confirmed=finished('identity-comparisons-confirmation-b1756-20261126',
                           'lython-b1756-identity-comparisons-confirmation-20261126', cfg['confirmationArchive'])
        canonical=base/'identity-comparisons-b1756-20261126'/'candidate'
        assert canonical.resolve()==canonical
        image(confirmed,cfg['confirmation'])
        image(canonical,cfg['confirmation'])
        trial=finished('arithmetic-operand-borrows-b1758-20261126',
                       'lython-b1758-arithmetic-operand-borrows-20261126',cfg['trialArchive'])
        image(trial,cfg['trial'])
        redundant=[name for name in cfg['confirmation']
                   if name=='Lokad.Lython.dll' or name.startswith('Lokad.Lython.Benchmarks.')]
        assert set(redundant)=={'Lokad.Lython.dll','Lokad.Lython.Benchmarks.dll',
                                'Lokad.Lython.Benchmarks.deps.json','Lokad.Lython.Benchmarks.runtimeconfig.json'}
        old_core=trial/'Lokad.Lython.dll'
        regular(old_core,cfg['trial'][old_core.name])
        for name in redundant:
            regular(confirmed/name,cfg['confirmation'][name])
            assert not (confirmed/(name+'.stage-link')).exists()
        collapsed=sum((confirmed/name).stat().st_size for name in redundant)
        retire_trial=before+collapsed <= cfg['minimum']
        assert before+collapsed+(old_core.stat().st_size if retire_trial else 0)>cfg['minimum']
        for name in redundant:
            staged=confirmed/(name+'.stage-link')
            staged.symlink_to(canonical/name)
            os.replace(staged,confirmed/name)
            actions.append(dict(action='reference-identical-remote-copy',name=str((confirmed/name).relative_to(base)),
                                sha256=cfg['confirmation'][name]))
        image(confirmed,cfg['confirmation'])
        if retire_trial:
            old_core.unlink()
            actions.append(dict(action='retire-remote-stage-copy-retained-in-verified-local-image',
                                name=str(old_core.relative_to(base)),sha256=cfg['trial'][old_core.name]))
after=shutil.disk_usage(base).free
assert after>cfg['minimum'],after
print(json.dumps(dict(freeBeforeBytes=before,freeAfterBytes=after,requiredBytes=cfg['minimum'],actions=actions)))
'''
command=['ssh','-i',os.environ['LYTHON_BENCH_IDENTITY'],'-o','BatchMode=yes','-o','ConnectTimeout=12',
          os.environ['LYTHON_BENCH_HOST'],'python3 -']
out=subprocess.check_output(command,input=remote,encoding='utf-8',timeout=45)
receipt=json.loads(out)
(lab/'stage-replica-custody.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(receipt))