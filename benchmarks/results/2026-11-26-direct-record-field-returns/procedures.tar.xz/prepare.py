from pathlib import Path

lab = Path(__file__).resolve().parent
template = lab.with_name('json-magnitude-utf8-20261126') / 'prepare.py'
body = template.read_text(encoding='utf-8')
changed = [
    'src/Lokad.Lython/Frontend/ExecutableScript.NativeSegments.cs',
    'src/Lokad.Lython/Runtime/LythonRuntime.Executable.IntegerChains.cs',
    'src/Lokad.Lython/Runtime/PyExecutableFunction.cs',
]
catalog_code = """catalog=read(prior/'representative.json')
choices={case['id']:case for case in catalog['cases']}
meter=dict(choices['scripts.csv-meter-report.explicit-float'])
source=meter['source']
assert source.count('import csv\\n')==1
source=source.replace('import csv\\n', "import csv\\ndef energy(row): return float(row['kwh'])\\n")
old='''    rows = csv.reader(source)
    next(rows)
    for site, kwh, peak, price, note in rows:
        kwh, peak, price = float(kwh), float(peak), float(price)'''
new='''    for row in csv.DictReader(source):
        site = row['site']
        kwh, peak, price = energy(row), float(row['peak']), float(row['price'])'''
assert source.count(old)==1
source=source.replace(old,new)
fixture=json.loads(meter['fixtureJson'])
fixture['size']=4096
fixture_json=json.dumps(fixture,ensure_ascii=False,separators=(',',':'))
meter.update(id='diagnostic.csv-meter-field-helper',size=4096,source=source,fixtureJson=fixture_json,
             fixtureSha256=hashlib.sha256(fixture_json.encode('utf-8')).hexdigest(),
             sourceUtf8Bytes=len(source.encode('utf-8')),sourceSha256=hashlib.sha256(source.encode('utf-8')).hexdigest())
catalog['cases']=[choices['diagnostic.shipment-file-fed-map'],meter,choices['diagnostic.shipment-routing-callbacks']]
assert len(catalog['cases'])==3"""
substitutions = {
    "baseline = lab.parent/'short-path-cpython-20261126'": "baseline = lab.parent/'identity-comparisons-20261126'",
    "prior = lab.parent/'json-integer-r46'": "prior = lab.parent/'arithmetic-operand-outlining-20261126'",
    "assert revision.startswith('0a0e32c16')": "assert revision.startswith('e554c19a5')",
    "== ['src/Lokad.Lython/Runtime/LythonRuntime.Json.Deserialize.cs']": "== " + repr(changed),
    "assert before['sourceRevision']==revision and len(reference)==32":
        "assert git('diff','--binary',before['sourceRevision'],revision,'--','src') == (baseline/'candidate.patch').read_bytes()\n"
        "assert len(reference)==32",
    "catalog=read(prior/'catalog.json')\ncatalog['cases']=[case for case in catalog['cases'] if case['id'].startswith('scripts.json-summary-helpers.')]\nassert len(catalog['cases'])==3":
        catalog_code,
    "f'{role}-refined-allocation.json'": "f'{role}-allocation.json'",
}
for old, new in substitutions.items():
    assert body.count(old)==1, old
    body=body.replace(old,new)
exec(compile(body,str(template),'exec'),{'__file__':str(lab/'prepare.py')})