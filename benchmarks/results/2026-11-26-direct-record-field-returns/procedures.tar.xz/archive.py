from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
baseline=lab.with_name('direct-record-helper-tape-20261126')
quiet=lab/'comparison/quiet'
out=repo/'benchmarks/results/2026-11-26-direct-record-field-returns'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
def git(*args):
    return subprocess.check_output(['git',*args],cwd=repo)
identity=read(quiet/'identity.json')
assert git('rev-parse','HEAD').decode().strip()==identity['sourceRevision']
patch=git('diff','--binary','--','src')
assert patch==(lab/'candidate.patch').read_bytes() and hashlib.sha256(patch).hexdigest()==identity['sourcePatchSHA256']
(lab/'tests.patch').write_bytes(git('diff','--binary','--','tests'))
terminal=read(quiet/'terminal-status.json')
receipt=terminal['receipt']
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode']=='0'
assert all(receipt[field] for field in ('complete','allWorkersJoined','quietBeforeAndAfter',
                                       'guestFixturesRemoved','archivedAndVerifiedUnderLease'))
assert receipt['archiveSHA256']==sha(quiet/'observations.tar.xz')
roles=('reference','candidate')
runs={role:read(lab/'instrumented'/role/'routes.json')['rows'] for role in roles}
out.mkdir()
table=[]
for old,new in zip(*runs.values(),strict=True):
    assert old['id']==new['id'] and old['asynchronous']==new['asynchronous']
    assert all(row['allowanceReturned'] for row in (old,new))
    table.append(dict(case=old['id'],asynchronous=old['asynchronous'],
                      admittedPeaks=[old['peakExecutionMemoryBytes'],new['peakExecutionMemoryBytes']],
                      reference=old['routes'],candidate=new['routes']))
(out/'routes.json').write_text(json.dumps(table,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ('summary.json','allocation-summary.json','stage-replica-custody.json'):
    shutil.copyfile(lab/name,out/name)
for name in ('identity.json','terminal-status.json','observations.tar.xz'):
    shutil.copyfile(quiet/name,out/name)
local=('archive.py','prepare.py','prepare-quiet.py','reclaim-stage.py','verify-routes.py','quiet.py','summarize.py',
       'candidate.patch','tests.patch','reference-verify.json','candidate-verify.json',
       'reference-allocation.json','candidate-allocation.json','catalog-first-attempt.log','catalog-first-attempt.json',
       'frozen-build.log','test-ubuntu.sh','Lokad.Lython.Tests-win11.log','Lokad.Lython.PublicApi.Tests-win11.log',
       'Lokad.Lython.Tests-ubuntu10.log','Lokad.Lython.PublicApi.Tests-ubuntu10.log','instrumented/cases.json',
       'verify-routes.log')
with tarfile.open(out/'procedures.tar.xz','w:xz') as archive:
    for name in local: archive.add(lab/name,arcname=name)
    for role in roles:
        for name in ('diagnostic.patch','Program.cs','RouteProbe.csproj','routes.json','core.log','probe.log','verification.log'):
            relative=f'instrumented/{role}/{name}'
            archive.add(lab/relative,arcname=relative)
    for name in ('launch.log','collect.py','run.sh','jobs.json','representative.json','cpython-worker.py'):
        archive.add(quiet/name,arcname='quiet/'+name)
    for name in ('diagnostic.shipment-file-fed-map.json','Program.cs','Inspect.csproj',
                 'instrumented/routes.json','instrumented/identity.json'):
        archive.add(baseline/name,arcname='baseline/'+name)
    template=lab.with_name('json-magnitude-utf8-20261126')
    for name in ('prepare.py','quiet.py'): archive.add(template/name,arcname='template/'+name)
    archive.add(lab.with_name('ready-shipment-rows-20261126')/'prepare-quiet.py',arcname='template/prepare-quiet.py')
    archive.add(lab.with_name('arithmetic-operand-borrows-20261126')/'verify-routes.py',arcname='template/verify-routes.py')
with tarfile.open(out/'procedures.tar.xz') as archive:
    assert archive.extractfile('candidate.patch').read()==patch