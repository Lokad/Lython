from pathlib import Path
import json


out = Path("benchmarks/results/2026-11-22-compiler-csv-cpython")
summary = json.loads((out / "summary.json").read_text(encoding="utf-8"))
names = {
    "scripts.config-generated-guards.medium.bad-0.sparse-lexical": "Generated validator with an error-counting generator",
    "scripts.dataclass-inherited-configuration.generated": "Inherited dataclass configuration",
    "scripts.csv-meter-report.typed-ascii": "Typed ASCII CSV meter report",
    "scripts.csv-invoice.method-policy.quoted-control": "Quote-heavy CSV policy invoice",
}
boundaries = {"warm": "Warm", "compile": "Compilation", "compile-run": "Compile to result"}


def extent(values, digits):
    first, last = (f"{value:.{digits}f}" for value in values)
    return first if first == last else f"{first}–{last}"


rows = [
    "| Complete script | Boundary | Lython | CPython | Lython / CPython | Controls L/C | Maximum IQR |",
    "| --- | --- | ---: | ---: | ---: | ---: | ---: |",
]
for row in summary["rows"]:
    digits = {"compile": 5, "warm": 4, "compile-run": 3}[row["lane"]]
    controls = f"{row['lythonControlPercent']:.2f} / {row['cpythonControlPercent']:.3f}%"
    rows.append(f"| {names[row['case']]} | {boundaries[row['lane']]} | "
                f"{extent(row['lythonMs'], digits)} ms | {extent(row['cpythonMs'], digits)} ms | "
                f"{extent(row['ratio'], 3)}× | {controls} | {row['maxIQRPercent']:.2f}% |")
report = f"""# B1316 Compiler and CSV checkpoint against CPython

Measured November 22, 2026 UTC on the quiet Azure F4as_v7 with Ubuntu
24.04.4 and .NET 11 RC3. The frozen Lython image is
`{summary['source'][:9]}`, with production-equivalent source at
`{summary['retainedSource'][:9]}`. The external baseline is stock
CPython 3.13.16. The validator reads 96 fields from a 1,714-byte
configuration and counts errors with a generator. The dataclass
script is 3,978 source bytes and needs no input file. Both CSV
reports process 4,096 data records. The ASCII meter input is
139,299 bytes and the quote-heavy invoice input is 174,147 bytes.

"""
report += "\n".join(rows)
report += f"""

Ratios divide Lython elapsed by CPython elapsed and span all pairings
of two process medians per engine. Above one means Lython takes longer.
Two workers per engine and phase warmed for at least eight seconds
and supplied seven rotated timed batches each. Controls show the spread
of the two process medians for each engine.

Warm execution includes mediated RAM-backed input and output, captured
stdout, golden verification and prior-result disposal.
Compile-only timing includes code-owner cleanup. Time to result covers
both compilation and execution with their cleanup. Process startup and
final teardown have separate boundaries.

All 168 timed batches and both quiet gates passed in
{summary['elapsedSeconds']:.0f} seconds. Stdout and output files matched their CPython goldens. The 32-file Lython image and both CPython worker identities
verified. Every worker joined and the persistent archive was checked
before releasing the VM lease.

[Phase summary](summary.json) · [Raw observations](observations.tgz) ·
[Compiler source pair](../2026-11-22-sparse-lexical-preparation/README.md) ·
[CSV source pair](../2026-11-22-csv-quoted-ranges/README.md)
· [Image verification and procedures](procedures.tar.xz).
"""
(out / "README.md").write_text(report, encoding="utf-8", newline="\n")
