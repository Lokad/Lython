using System.Runtime.ExceptionServices;
using Lokad.Lython.Frontend;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal sealed partial class ExecutableFrameInterpreter
    {
        // One driver retains saved callers and their funded operand windows.
        private ExecutableCallSite? _pendingCallSite;
        private PyExecutableFunction? _pendingFunction;
        private object? _pendingReceiver;
        private int _pendingCallStart;
        private object? _completedCallValue;
        private Exception? _completedCallError;
        private enum CallCompletion { Call, TypeGetter, TypeSubscription }
        private CallCompletion _callCompletion;
        private LythonSourceSpan? _protocolCallSpan;
        private object? _preparedTypeSubscription;
        private bool HasPendingCall => _pendingCallSite is not null || _protocolCallSpan is not null;
        private LythonSourceSpan PendingCallSpan => _pendingCallSite?.CallSpan ?? _protocolCallSpan!;

        public void Execute()
        {
            try
            {
                while (true)
                {
                    Exception? failure = null;
                    try { ExecuteUntilCall(); }
                    catch (Exception error) { failure = error; }
                    if (!AdvanceCallFrames(failure)) return;
                }
            }
            finally { if (!HasYield) ReleaseCallStorage(); }
        }

        public async ValueTask ExecuteAsync()
        {
            try
            {
                while (true)
                {
                    Exception? failure = null;
                    try { await ExecuteUntilCallAsync().ConfigureAwait(false); }
                    catch (Exception error) { failure = error; }
                    if (!AdvanceCallFrames(failure)) return;
                }
            }
            finally { if (!HasYield) ReleaseCallStorage(); }
        }

        private bool TrySuspendForExecutableCall(ExecutableInstruction instruction)
        {
            var site = _codeObject.CallSites[instruction.CallSiteIndex];
            if (!site.IsPositionalOnly) return false;
            var start = ReadExecutableCallTarget(site, ref _stack, out var target);
            var function = target as PyExecutableFunction;
            object? receiver = null;
            if (target is PyBoundMethod { Function: PyExecutableFunction method } bound)
            {
                function = method;
                receiver = bound.Receiver;
            }
            if (function is not { SupportsDirectPositional: true }) return false;
            _pendingCallSite = site;
            _pendingFunction = function;
            _pendingReceiver = receiver;
            _pendingCallStart = start;
            return true;
        }

        // Type subscription has at most two calls: a raw descriptor getter,
        // then its callable result. Both use the existing admitted frame runner.
        private bool TrySuspendForTypeSubscription(ExecutableInstruction instruction)
        {
            var start = _stack.Count - 2;
            if (_preparedTypeSubscription is { } prepared)
            {
                if (!TryPrepareSubscriptionCallable(prepared, instruction.Span, start)) return false;
                _preparedTypeSubscription = null;
                return true;
            }
            if (_stack[start] is not PyType type ||
                !type.TryLookupInMro("__class_getitem__", 0, out var raw, out _)) return false;
            if (raw is PyInstance descriptor &&
                descriptor.Type.TryLookupInMro("__get__", 0, out var getter, out _) &&
                getter is PyExecutableFunction { SupportsDirectPositional: true } function)
            {
                // Match raw ternary invocation: prefix self through the binder,
                // retaining the original receiver and key in their current slots.
                _stack.Push(PyNone.Instance);
                _stack.Push(type);
                _pendingFunction = function;
                _pendingReceiver = descriptor;
                _pendingCallStart = start;
                _protocolCallSpan = instruction.Span;
                _callCompletion = CallCompletion.TypeGetter;
                return true;
            }
            if (raw is not (PyClassMethod or PyStaticMethod or PyExecutableFunction)) return false;
            var member = PyAttributeLookup.BindForType(type, raw, _context, instruction.Span);
            if (TryPrepareSubscriptionCallable(member, instruction.Span, start)) return true;
            _preparedTypeSubscription = member;
            return false;
        }

        private bool TryPrepareSubscriptionCallable(object callable, LythonSourceSpan span, int start)
        {
            var function = callable as PyExecutableFunction;
            object? receiver = null;
            if (callable is PyBoundMethod { Function: PyExecutableFunction method } bound)
            {
                function = method;
                receiver = bound.Receiver;
            }
            if (function is not { SupportsDirectPositional: true }) return false;
            _pendingFunction = function;
            _pendingReceiver = receiver;
            _pendingCallStart = start;
            _protocolCallSpan = span;
            _callCompletion = CallCompletion.TypeSubscription;
            return true;
        }

        private ValueTask<object> InvokePreparedTypeSubscription(object index, LythonSourceSpan span, bool asynchronous)
        {
            var member = _preparedTypeSubscription!;
            _preparedTypeSubscription = null;
            return InvokeTypeSubscriptionMemberAsync(member, index, _context, span, asynchronous);
        }

        private bool AdvanceCallFrames(Exception? failure)
        {
            if (failure is null && _pendingFunction is not null)
            {
                BeginPendingCall();
                return true;
            }
            if (_callDepth == 0)
            {
                if (failure is not null) ExceptionDispatchInfo.Throw(failure);
                return false;
            }

            var result = HasFrameReturn ? FrameReturnValue : PyNone.Instance;
            try { CloseInvocation(failure); }
            catch (Exception error) { failure = error; }
            var parent = _callFrames[--_callDepth];
            _callFrames[_callDepth] = default;
            LoadActivation(parent);
            CompletePendingCall(result, failure);
            return true;
        }

        private void BeginPendingCall()
        {
            var function = _pendingFunction!;
            var span = PendingCallSpan;
            var callerContext = _context;
            var ordinaryCall = _callCompletion == CallCompletion.Call;
            var argumentStart = ordinaryCall ? _pendingCallStart + _pendingCallSite!.ArgumentOffset
                : _pendingCallStart + (_callCompletion == CallCompletion.TypeGetter ? 2 : 1);
            var argumentCount = ordinaryCall ? _pendingCallSite!.ArgumentCount
                : _callCompletion == CallCompletion.TypeGetter ? 2 : 1;
            BoundCallArguments bound = default;
            ExecutionContext? frame = null;
            var callEntered = false;
            var transferred = false;
            long auxiliaryBytes = 0;
            var auxiliaryCommitted = false;
            var auxiliaryReserved = false;
            var arenaBase = _callStorage?.Used ?? 0;
            try
            {
                if (ordinaryCall)
                {
                    callerContext.EnterInterpreterFrame(span);
                    callEntered = true;
                }
                callerContext.CheckExecution(span);
                var code = function.CodeObject;
                // Keep the measured small-return route, including its dynamic
                // eligibility checks. It never needs a reusable call arena.
                if (code.SimpleReturn != ExecutableSimpleReturn.None)
                {
                    bound = function.BindPositionalOperands(
                        _stack.Slice(argumentStart, argumentCount).Span, span, callerContext, _pendingReceiver);
                    frame = function.EnterInvocationFrame(bound, span);
                    if (TryExecuteSimpleReturn(code, frame, bound, span, out var value))
                    {
                        CompletePendingCall(value, null);
                        return;
                    }
                }

                EnsureCallFrames(span);
                var arena = _callStorage ??= new ExecutableCallStorage(callerContext.MemoryGovernor);
                var operandCapacity = Math.Max(8, code.LocalNames.Count);
                var operandOffset = checked(arenaBase + code.LocalNames.Count);
                arena.EnsureValues(checked(operandOffset + operandCapacity), span);
                var locals = new ExecutableLocalSlots(arena, arenaBase, code.LocalNames.Count);
                locals.Span.Fill(UninitializedLocal);
                // Destination admission may replace the arena. Obtain the source
                // span afterwards, and consume it before any suspension/reentry.
                if (bound.Values is null)
                    function.BindPositionalOperandsInto(_stack.Slice(argumentStart, argumentCount).Span,
                        locals.Span, span, callerContext, _pendingReceiver);
                else bound.Values.AsSpan(0, bound.Assigned.Length).CopyTo(locals.Span);
                frame ??= function.EnterInvocationFrame(default, span);

                auxiliaryBytes = EstimateExecutableAuxiliaryBytes(code);
                callerContext.MemoryGovernor.Reserve(auxiliaryBytes, span);
                auxiliaryReserved = true;
                var cells = CreateExecutableLocalCells(code, frame, locals);
                var caches = code.MemberCacheCount == 0 ? [] : new ExecutableMemberCache?[code.MemberCacheCount];
                var depths = code.ExceptionRegions.Count == 0 ? [] : new int?[code.Blocks.Count];
                callerContext.MemoryGovernor.Commit(auxiliaryBytes);
                auxiliaryCommitted = true;
                var stack = new ExecutableValueStack(arena, operandOffset, operandCapacity, frame, span, auxiliaryBytes);
                var child = new SavedActivation
                {
                    _codeObject = code, _locals = locals, _localCells = cells,
                    _closureCells = function.ClosureCells, _context = frame, _stack = stack,
                    _currentBlockIndex = code.EntryBlockIndex,
                    _entryActiveException = frame.State.CurrentException,
                    _memberCaches = caches, _blockEntryStackDepths = depths,
                    _sentValue = PyNone.Instance, YieldValue = PyNone.Instance, _arenaBase = arenaBase
                };
                _callFrames[_callDepth++] = SaveActivation();
                LoadActivation(child);
                arena.Used = checked(operandOffset + operandCapacity);
                frame.EnterExecutableSlots(this, _callDepth, code.RequiresLocalVariableMirroring);
                transferred = true;
            }
            catch (Exception error)
            {
                if (TryTranslateCallableException(error, span, out var translated)) error = translated;
                if (frame is not null && error is LythonRuntimeException runtimeError)
                    PyFunctionBinding.AnnotateException(runtimeError, frame, function.Name, span);
                CompletePendingCall(null, error);
            }
            finally
            {
                if (bound.Values is not null) ReturnBoundArguments(bound);
                if (!transferred)
                {
                    if (_callStorage is { } arena)
                    {
                        Array.Clear(arena.Values, arenaBase, arena.Values.Length - arenaBase);
                        arena.Used = arenaBase;
                    }
                    if (auxiliaryReserved)
                    {
                        if (auxiliaryCommitted) callerContext.MemoryGovernor.Release(auxiliaryBytes);
                        else callerContext.MemoryGovernor.ReleaseReserved(auxiliaryBytes);
                    }
                    try { frame?.LeaveFunctionCall(); }
                    finally { if (callEntered) callerContext.LeaveInterpreterFrame(); }
                }
            }
        }

        private void CloseInvocation(Exception? failure)
        {
            ref var caller = ref _callFrames[_callDepth - 1];
            var span = caller._pendingCallSite?.CallSpan ?? caller._protocolCallSpan!;
            _context.LeaveExecutableSlots(null);
            try
            {
                if (failure is LythonRuntimeException runtimeError)
                    PyFunctionBinding.AnnotateException(runtimeError, _context, _context.FunctionName!, span);
            }
            finally
            {
                try
                {
                    _context.LeaveFunctionCall();
                    var arena = _callStorage!;
                    Array.Clear(arena.Values, _arenaBase, arena.Used - _arenaBase);
                    arena.Used = _arenaBase;
                }
                finally
                {
                    if (caller._callCompletion == CallCompletion.Call) caller._context.LeaveInterpreterFrame();
                }
            }
        }

        private void CompletePendingCall(object? value, Exception? failure)
        {
            _completedCallValue = value;
            _completedCallError = failure;
            _pendingFunction = null;
            _pendingReceiver = null;
        }

        private void ResumePendingCall()
        {
            if (!HasPendingCall) return;
            if (_pendingFunction is not null) throw new InvalidOperationException("Executable call has not completed.");
            var start = _pendingCallStart;
            var value = _completedCallValue;
            var failure = _completedCallError;
            var completion = _callCompletion;
            var span = PendingCallSpan;
            _pendingCallSite = null;
            _protocolCallSpan = null;
            _callCompletion = CallCompletion.Call;
            _completedCallValue = null;
            _completedCallError = null;
            if (completion == CallCompletion.TypeGetter)
            {
                _stack.RemoveTail(_stack.Count - start - 2);
                _context.CheckExecution(span);
                if (failure is LythonRuntimeException { ExceptionType: "AttributeError" })
                {
                    failure = null;
                    value = PyNone.Instance;
                }
                if (failure is null)
                {
                    if (value is not PyNone)
                    {
                        _preparedTypeSubscription = value;
                        return; // Resume this subscript without rebinding.
                    }
                    failure = new LythonRuntimeException("TypeError",
                        $"type '{((PyType)_stack[start]).Name}' is not subscriptable", span);
                }
            }
            if (completion == CallCompletion.TypeSubscription) _context.CheckExecution(span);
            if (failure is not null)
            {
                _stack.RemoveTail(_stack.Count - start);
                if (failure is LythonRuntimeException runtimeError) _injectedException = runtimeError;
                else ExceptionDispatchInfo.Throw(failure);
            }
            else
            {
                CompleteExecutableValueTransfer(ref _stack, start, RuntimeValue(value));
                _instructionIndex++;
            }
        }
    }
}
