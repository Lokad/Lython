using Lokad.Lython.Frontend;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    // Local windows retain an owner and offset, not a replaceable backing array.
    // Standalone root/protocol entries keep the existing bound-argument owner.
    internal readonly struct ExecutableLocalSlots
    {
        private readonly object[]? _standalone;
        private readonly ExecutableCallStorage? _arena;
        private readonly int _offset;
        public int Length { get; }
        public ExecutableLocalSlots(ExecutableCallStorage arena, int offset, int length)
        { _standalone = null; _arena = arena; _offset = offset; Length = length; }
        private ExecutableLocalSlots(object[] values)
        { _standalone = values; _arena = null; _offset = 0; Length = values.Length; }
        public object this[int index]
        {
            get => (_arena?.Values ?? _standalone!)[_offset + index]!;
            set => (_arena?.Values ?? _standalone!)[_offset + index] = value;
        }
        internal Span<object> Span => (_arena?.Values ?? _standalone!).AsSpan(_offset, Length)!;
        public static implicit operator ExecutableLocalSlots(object[] values) => new(values);
    }

    // Capacity belongs to the driver through actual completion, including yield
    // and native suspension. Popping a call clears references, never refunds a
    // backing array that subsequent calls still reuse.
    internal sealed class ExecutableCallStorage
    {
        internal object?[] Values = [];
        internal int Used;
        private readonly MemoryGovernor _governor;
        internal ExecutableCallStorage(MemoryGovernor governor) => _governor = governor;
        internal void EnsureValues(int required, LythonSourceSpan? span)
        {
            if (required <= Values.Length) return;
            var capacity = Math.Max(required, checked(Math.Max(8, Values.Length) * 2));
            var bytes = EstimateObjectArrayBytes(capacity);
            var previous = Values.Length == 0 ? 0 : EstimateObjectArrayBytes(Values.Length);
            _governor.Reserve(bytes, span);
            try { Array.Resize(ref Values, capacity); _governor.Commit(bytes); }
            catch { _governor.ReleaseReserved(bytes); throw; }
            _governor.Release(previous);
        }
        internal void Dispose()
        {
            var bytes = Values.Length == 0 ? 0 : EstimateObjectArrayBytes(Values.Length);
            Values = [];
            Used = 0;
            _governor.Release(bytes);
        }
    }

    internal sealed partial class ExecutableFrameInterpreter
    {
        private ExecutableCallStorage? _callStorage;
        private SavedActivation[] _callFrames = [];
        private long _callFramesBytes;
        private int _callDepth, _arenaBase;

        internal bool RequiresLocalVariableMirroring => _codeObject.RequiresLocalVariableMirroring;

        internal ExecutableFrameState GetFrameView(int depth)
        {
            if (depth == _callDepth)
                return new(_codeObject, _locals, _localCells, _closureCells);
            ref var saved = ref _callFrames[depth];
            return new(saved._codeObject, saved._locals, saved._localCells, saved._closureCells);
        }

        private void EnsureCallFrames(LythonSourceSpan span)
        {
            if (_callDepth < _callFrames.Length) return;
            var capacity = _callFrames.Length == 0 ? 1 : checked(_callFrames.Length * 2);
            // Conservative complete activation capacity, admitted with overlap.
            var bytes = checked(32L + 512L * capacity);
            var governor = _context.MemoryGovernor;
            governor.Reserve(bytes, span);
            try { Array.Resize(ref _callFrames, capacity); governor.Commit(bytes); }
            catch { governor.ReleaseReserved(bytes); throw; }
            governor.Release(_callFramesBytes);
            _callFramesBytes = bytes;
        }

        private void ReleaseCallStorage()
        {
            _callStorage?.Dispose();
            _callStorage = null;
            _callFrames = [];
            _context.MemoryGovernor.Release(_callFramesBytes);
            _callFramesBytes = 0;
        }

        private struct SavedActivation
        {
            internal ExecutableCodeObject _codeObject;
            internal ExecutableLocalSlots _locals;
            internal ExecutableCell?[]? _localCells;
            internal IReadOnlyList<ExecutableCell>? _closureCells;
            internal ExecutionContext _context;
            internal ExecutableValueStack _stack;
            internal int _currentBlockIndex;
            internal PendingAbruptSignal? _pendingAbrupt;
            internal int _instructionIndex;
            internal bool _waitingForSend;
            internal object _sentValue;
            internal LythonRuntimeException? _injectedException;
            internal GeneratorDelegation? _delegation;
            internal bool HasYield;
            internal object YieldValue;
            internal object? _frameReturnValue;
            internal bool _hasFrameReturn;
            internal Stack<ActiveExceptionSave>? _savedActiveExceptions;
            internal PyException? _entryActiveException;
            internal ExecutableMemberCache?[] _memberCaches;
            internal int?[] _blockEntryStackDepths;
            internal ExecutableCallSite? _pendingCallSite;
            internal PyExecutableFunction? _pendingFunction;
            internal object? _pendingReceiver;
            internal int _pendingCallStart;
            internal object? _completedCallValue;
            internal Exception? _completedCallError;
            internal CallCompletion _callCompletion;
            internal LythonSourceSpan? _protocolCallSpan;
            internal object? _preparedTypeSubscription;
            internal int _arenaBase;
        }

        private SavedActivation SaveActivation() => new()
        {
            _codeObject = _codeObject,
            _locals = _locals,
            _localCells = _localCells,
            _closureCells = _closureCells,
            _context = _context,
            _stack = _stack,
            _currentBlockIndex = _currentBlockIndex,
            _pendingAbrupt = _pendingAbrupt,
            _instructionIndex = _instructionIndex,
            _waitingForSend = _waitingForSend,
            _sentValue = _sentValue,
            _injectedException = _injectedException,
            _delegation = _delegation,
            HasYield = HasYield,
            YieldValue = YieldValue,
            _frameReturnValue = _frameReturnValue,
            _hasFrameReturn = _hasFrameReturn,
            _savedActiveExceptions = _savedActiveExceptions,
            _entryActiveException = _entryActiveException,
            _memberCaches = _memberCaches,
            _blockEntryStackDepths = _blockEntryStackDepths,
            _pendingCallSite = _pendingCallSite,
            _pendingFunction = _pendingFunction,
            _pendingReceiver = _pendingReceiver,
            _pendingCallStart = _pendingCallStart,
            _completedCallValue = _completedCallValue,
            _completedCallError = _completedCallError,
            _callCompletion = _callCompletion,
            _protocolCallSpan = _protocolCallSpan,
            _preparedTypeSubscription = _preparedTypeSubscription,
            _arenaBase = _arenaBase,
        };

        private void LoadActivation(in SavedActivation saved)
        {
            _codeObject = saved._codeObject;
            _locals = saved._locals;
            _localCells = saved._localCells;
            _closureCells = saved._closureCells;
            _context = saved._context;
            _stack = saved._stack;
            _currentBlockIndex = saved._currentBlockIndex;
            _pendingAbrupt = saved._pendingAbrupt;
            _instructionIndex = saved._instructionIndex;
            _waitingForSend = saved._waitingForSend;
            _sentValue = saved._sentValue;
            _injectedException = saved._injectedException;
            _delegation = saved._delegation;
            HasYield = saved.HasYield;
            YieldValue = saved.YieldValue;
            _frameReturnValue = saved._frameReturnValue;
            _hasFrameReturn = saved._hasFrameReturn;
            _savedActiveExceptions = saved._savedActiveExceptions;
            _entryActiveException = saved._entryActiveException;
            _memberCaches = saved._memberCaches;
            _blockEntryStackDepths = saved._blockEntryStackDepths;
            _pendingCallSite = saved._pendingCallSite;
            _pendingFunction = saved._pendingFunction;
            _pendingReceiver = saved._pendingReceiver;
            _pendingCallStart = saved._pendingCallStart;
            _completedCallValue = saved._completedCallValue;
            _completedCallError = saved._completedCallError;
            _callCompletion = saved._callCompletion;
            _protocolCallSpan = saved._protocolCallSpan;
            _preparedTypeSubscription = saved._preparedTypeSubscription;
            _arenaBase = saved._arenaBase;
        }
    }
}
