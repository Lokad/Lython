using System.Numerics;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    /// <summary>
    /// Owns the mutable stack, caches, and control-flow state for one executable
    /// code-object invocation. Keeping this state together makes opcode handlers
    /// independently reviewable without extending the runtime entry-point method.
    /// </summary>
    internal sealed partial class ExecutableFrameInterpreter
    {

        private ExecutionContext _context;
        private ExecutableCodeObject _codeObject;
        private ExecutableLocalSlots _locals;
        private ExecutableCell?[]? _localCells;
        private IReadOnlyList<ExecutableCell>? _closureCells;

        private bool TryLoadDirectCallReceiver(ExecutableInstruction instruction)
        {
            if (instruction.OpCode != ExecutableOpCode.LoadCallReceiver) return false;
            var name = _codeObject.Names[instruction.NameIndex];
            var operation = _stack[_stack.Count - 1] switch
            {
                PyList when name == "append" => DirectListAppend,
                ExecutionContext.TextFileHandle or ExecutionContext.BinaryFileHandle when name == "write" => DirectFileWrite,
                CsvWriterObject when name == "writerow" => DirectCsvWriterow,
                PyDict when name == "get" => DirectDictionaryGet,
                PyDict when name == "setdefault" => DirectDictionarySetDefault,
                PyDict => DictMembers.GetNoArgumentsOperation(name),
                Text.PyString when name == "startswith" => DirectStringStartsWith,
                Text.PyString when name == "endswith" => DirectStringEndsWith,
                Text.PyString when name == "replace" => DirectStringReplace,
                Text.PyString when name == "split" => DirectStringSplit,
                Text.PyString when name == "join" => DirectStringJoin,
                Text.PyString => StringMembers.GetNoArgumentsOperation(name),
                _ => null
            };
            if (operation is null) return false;
            // Keep the evaluated receiver, then append the immutable operation.
            // Arguments are evaluated afterwards and can rebind the source name.
            _stack.Push(operation);
            return true;
        }

        public ExecutableFrameInterpreter(
            ExecutableCodeObject codeObject,
            ExecutionContext context,
            ExecutableLocalSlots locals,
            ExecutableCell?[]? localCells,
            IReadOnlyList<ExecutableCell>? closureCells,
            ExecutableValueStack stack)
        {
            _context = context;
            _codeObject = codeObject;
            _locals = locals;
            _localCells = localCells;
            _closureCells = closureCells;
            _currentBlockIndex = codeObject.EntryBlockIndex;
            _entryActiveException = context.State.CurrentException;
            _memberCaches = codeObject.MemberCacheCount == 0 ? Array.Empty<ExecutableMemberCache?>() : new ExecutableMemberCache?[codeObject.MemberCacheCount];
            _blockEntryStackDepths = codeObject.ExceptionRegions.Count == 0 ? Array.Empty<int?>() : new int?[codeObject.Blocks.Count];
            // The factory retains ownership until every construction allocation
            // succeeds. No throwing work follows this transfer.
            _stack = stack;
        }

        // The mutable stack lives in this interpreter, including across generator
        // suspension. Helpers must borrow it by reference rather than copy it.
        private ExecutableValueStack _stack;
        private int _currentBlockIndex;
        private PendingAbruptSignal? _pendingAbrupt;
        private int _instructionIndex;
        private bool _waitingForSend;
        private object _sentValue = PyNone.Instance;
        private LythonRuntimeException? _injectedException;
        private GeneratorDelegation? _delegation;
        internal bool HasYield { get; private set; }
        internal object YieldValue { get; private set; } = PyNone.Instance;
        internal LythonSourceSpan? CurrentInstructionSpan
            => _instructionIndex < _codeObject.Blocks[_currentBlockIndex].InstructionArray.Length
                ? _codeObject.Blocks[_currentBlockIndex].InstructionArray[_instructionIndex].Span : null;

        internal void SeedGeneratorOuter(object iterator, PyIteration.Cursor cursor)
        {
            _locals[_codeObject.LocalNameToSlot[".0"]] = iterator;
            _stack.Push(cursor);
        }

        internal async ValueTask ReleaseGeneratorTemporariesAsync(bool asynchronous)
        {
            _stack.DeferAsyncDisposal = asynchronous;
            try
            {
                _stack.RemoveTail(_stack.Count);
                try { if (_stack.HasPendingDisposals) await DrainPendingDisposalsAsync().ConfigureAwait(false); }
                finally { _stack.ReleaseStorage(); ReleaseCallStorage(); }
            }
            finally { _stack.DeferAsyncDisposal = false; }
        }

        internal void Resume(object sent, LythonRuntimeException? injected)
        {
            // A retained closure can write a cell while this generator is
            // suspended. Refresh only captured slots, including direct-call inputs.
            for (var index = 0; index < _codeObject.CapturedLocalSlots.Count; index++)
            {
                var slot = _codeObject.CapturedLocalSlots[index];
                _locals[slot] = _localCells![slot]!.Value;
            }
            HasYield = false;
            _sentValue = sent;
            _injectedException = injected;
            if (_waitingForSend)
            {
                _waitingForSend = false;
                if (injected is null) _stack.Push(sent);
                _sentValue = PyNone.Instance;
            }
        }
        private object? _frameReturnValue;
        private bool _hasFrameReturn;
        // Handler-save chain, created on first except-route push: plain calls
        // never touch it, so the per-frame Stack box is skipped.
        private Stack<ActiveExceptionSave>? _savedActiveExceptions;

        private Stack<ActiveExceptionSave> SavedActiveExceptions() => _savedActiveExceptions ??= new();

        private PyException? _entryActiveException;

        private sealed class ActiveExceptionSave(PyException? savedException, int? suiteStartBlockIndex, int? suiteEndBlockIndex, PendingAbruptSignal? savedPendingAbrupt = null)
        {

            public PyException? SavedException { get; set; } = savedException;
            public int? SuiteStartBlockIndex { get; } = suiteStartBlockIndex;
            public int? SuiteEndBlockIndex { get; } = suiteEndBlockIndex;
            public PendingAbruptSignal? SavedPendingAbrupt { get; } = savedPendingAbrupt;
        }

        internal bool HasActiveHandler => _savedActiveExceptions is { Count: > 0 };
        internal void SetCallerException(PyException? exception)
        {
            _entryActiveException = exception;
            if (_savedActiveExceptions is { Count: > 0 } saves)
            {
                ActiveExceptionSave? outermost = null;
                foreach (var save in saves) outermost = save;
                outermost!.SavedException = exception;
            }
        }

        // Abandoning the frame drops its saved handler chain and restores the
        // active exception from frame entry, like CPython deleting handler
        // names and restoring the previous exception on frame exit.
        private void AbandonFrame(LythonSourceSpan span)
        {
            _stack.RemoveTail(_stack.Count);
            _savedActiveExceptions?.Clear();
            AbandonActiveHandlerVars(_context, span);
            _context.State.SetCurrentException(_entryActiveException);
        }

        // Pops saves for suites this propagation abandoned: a handler stays
        // live exactly while execution resumes inside its suite. Entries
        // without a suite range are kept, erring toward a stale value rather
        // than dropping a live save.
        private bool PendingCleanupContains(PendingAbruptSignal? pending, int block)
        {
            if (pending?.CleanupId is not int id) return false;
            for (var i = 0; i < _codeObject.ExceptionRegions.Count; i++)
            {
                var region = _codeObject.ExceptionRegions[i];
                if (region.CleanupId == id && region.SuiteStartBlockIndex is int start &&
                    region.SuiteEndBlockIndex is int end && block >= start && block <= end) return true;
            }
            return false;
        }

        private void RestoreSuppressedCompletion()
        {
            var saved = _savedActiveExceptions is { Count: > 0 } saves ? saves.Pop() : null;
            _pendingAbrupt = saved?.SavedPendingAbrupt;
            _context.State.SetCurrentException(saved?.SavedException);
        }

        private void UnwindAbandonedHandlers(int targetBlockIndex)
        {
            while (_savedActiveExceptions is { Count: > 0 } saves &&
                saves.Peek() is { SuiteStartBlockIndex: int start, SuiteEndBlockIndex: int end } &&
                (targetBlockIndex < start || targetBlockIndex > end))
            {
                _context.State.SetCurrentException(saves.Pop().SavedException);
            }
        }

        // Empty cache tables are shared: no instruction can name an index the
        // compiler never emitted (any such access already throws today).
        private ExecutableMemberCache?[] _memberCaches;
        // Depth entries are recorded per block visit but only read when a
        // region matches, so region-free frames share the empty table.
        private int?[] _blockEntryStackDepths;

        // Stores through the same cell-mirroring and host-mirroring policy as
        // StoreLocal, so synthetic slots (chain, match, with) behave exactly
        // like compiler-issued stores.
        private static void StoreLocalValue(
            ExecutableCodeObject codeObject,
            ExecutableLocalSlots locals,
            ExecutableCell?[]? localCells,
            ExecutionContext context,
            int slot,
            object value,
            LythonSourceSpan span)
        {
            var name = codeObject.LocalNames[slot];
            var guestName = !name.StartsWith('<');
            if (context.GlobalNamespace is not null && guestName)
            {
                StoreGlobalNamespaceName(context, name, value);
                return;
            }
            locals[slot] = value;
            if (localCells?[slot] is ExecutableCell localCell)
            {
                localCell.Value = value;
            }

            if (guestName && (codeObject.RequiresLocalVariableMirroring || context.MirrorLocalStores))
            {
                context.Variables[name] = value;
            }
        }

        // Pop's returned reference belongs to this completed transfer, rather
        // than the long-running dispatch loop. Keep the CLR temporary here so
        // deleting a slot can make its payload collectible before frame exit.
        [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
        private void StoreLocalFromStack(int slot, LythonSourceSpan span)
            => StoreLocalValue(_codeObject, _locals, _localCells, _context, slot, Pop(ref _stack, span), span);

        private void ExecuteDefinitionOrFallback(in ExecutableInstruction instruction)
        {
            switch (instruction.OpCode)
            {
                case ExecutableOpCode.Import:
                    ExecuteExecutableImport(_codeObject, _codeObject.Imports[instruction.ImportIndex], _locals, _localCells, _context);
                    break;

                case ExecutableOpCode.DefineFunction:
                    ExecuteExecutableFunctionDefinitionAsync(_codeObject, _codeObject.Functions[instruction.FunctionIndex],
                        _locals, _localCells, _context, false).GetAwaiter().GetResult();
                    break;

                case ExecutableOpCode.ExecuteFallbackStatement:
                    DispatchLoweredStatementAsync(
                        _codeObject.StatementFallbacks[instruction.StatementFallbackIndex],
                        _context,
                        SynchronousLoweredStatementExecution.Instance).GetAwaiter().GetResult();
                    SyncExecutableLocalsFromContext(_codeObject, _locals, _localCells, _context);
                    break;
            }
        }

        private void ExecuteStackTransfer(in ExecutableInstruction instruction)
        {
            switch (instruction.OpCode)
            {
                case ExecutableOpCode.LoadConst:
                    var constant = RuntimeValue(_codeObject.Constants[instruction.ConstantIndex]);
                    _stack.Push(constant);
                    break;

                case ExecutableOpCode.LoadLocal:
                    _stack.Push(LoadLocal(_codeObject, _locals, instruction.LocalSlot, instruction.Span, _context));
                    break;

                case ExecutableOpCode.LoadClosure:
                    _stack.Push(LoadClosure(_codeObject, _context, instruction.ClosureSlot, instruction.Span));
                    break;

                case ExecutableOpCode.LoadGlobal:
                    _stack.Push(ResolveExecutableGlobal(_codeObject.Names[instruction.NameIndex], instruction.Span, _context));
                    break;

                case ExecutableOpCode.LoadName:
                    _stack.Push(ResolveExecutableName(_codeObject.Names[instruction.NameIndex], instruction.Span, _context));
                    break;


                case ExecutableOpCode.LoadCallReceiver:
                    if (TryLoadDirectCallReceiver(instruction)) break;
                    goto case ExecutableOpCode.LoadCallMember;
                case ExecutableOpCode.LoadMember:
                case ExecutableOpCode.LoadCallMember:
                    var target = Pop(ref _stack, instruction.Span);
                    var memberName = _codeObject.Names[instruction.NameIndex];
                    var cachedMember = _memberCaches[instruction.MemberCacheIndex];
                    object memberValue;
                    if (cachedMember is not null && ReferenceEquals(cachedMember.Target, target))
                    {
                        // Identity is required: equal mutable Python values can expose different
                        // instance members, while cacheable builtin targets have stable lookup rules.
                        memberValue = cachedMember.Value;
                    }
                    else
                    {
                        if (!TryResolveRuntimeMember(target, memberName, _context, instruction.Span, out var resolvedMember))
                        {
                            throw PyMemberAccess.CreateMissingMemberError(target, memberName, instruction.Span, _context);
                        }

                        memberValue = resolvedMember;
                        _memberCaches[instruction.MemberCacheIndex] = CanCacheRuntimeMemberValue(target, memberValue,
                            instruction.OpCode is ExecutableOpCode.LoadCallMember or ExecutableOpCode.LoadCallReceiver)
                            ? new ExecutableMemberCache(target, memberValue)
                            : null;
                    }
                    if (instruction.OpCode == ExecutableOpCode.LoadCallReceiver) _stack.Push(PyNone.Instance);
                    _stack.Push(memberValue);
                    break;

                case ExecutableOpCode.PreloadImplicitSuperArguments:
                    PreloadImplicitSuperArguments(_context, instruction.Span);
                    break;

                case ExecutableOpCode.StoreLocal:
                    StoreLocalFromStack(instruction.LocalSlot, instruction.Span);
                    break;

                case ExecutableOpCode.StoreClosure:
                    StoreExecutableClosure(
                        _codeObject,
                        _context,
                        instruction.ClosureSlot,
                        Pop(ref _stack, instruction.Span),
                        instruction.Span);
                    break;

                case ExecutableOpCode.StoreGlobal:
                    StoreName(
                        _codeObject.Names[instruction.NameIndex],
                        Pop(ref _stack, instruction.Span),
                        _context,
                        instruction.Span);
                    break;

                case ExecutableOpCode.StoreName:
                    AssignExecutableBoundName(
                        _codeObject,
                        _locals,
                        _localCells,
                        _codeObject.Names[instruction.NameIndex],
                        Pop(ref _stack, instruction.Span),
                        _context,
                        instruction.Span);
                    break;

                case ExecutableOpCode.Dup:
                    _stack.Push(Peek(ref _stack, instruction.Span));
                    break;

                case ExecutableOpCode.PopTop:
                    _ = Peek(ref _stack, instruction.Span);
                    _stack.RemoveTail(1);
                    break;
            }
        }

        private bool ExecuteStructure(in ExecutableInstruction instruction)
        {
            switch (instruction.OpCode)
            {
                case ExecutableOpCode.MakeList:
                    _stack.Push(CreateListFromStack(ref _stack, instruction.ItemCount, instruction.Span, _context));
                    break;

                case ExecutableOpCode.MakeTuple:
                    _stack.Push(CreateTupleFromStack(ref _stack, instruction.ItemCount, instruction.Span, _context));
                    break;

                case ExecutableOpCode.MakeSet:
                    _stack.Push(ExecuteExecutableMakeSet(ref _stack, instruction.ItemCount, instruction.Span, _context));
                    break;

                case ExecutableOpCode.MakeDict:
                    _stack.Push(ExecuteExecutableMakeDict(ref _stack, instruction.PairCount, instruction.Span, _context));
                    break;

                case ExecutableOpCode.ResolveContextManager:
                    var managerValue = Pop(ref _stack, instruction.Span);
                    _stack.Push(PyContextManagers.Resolve(managerValue, instruction.Span, _context));
                    break;

                case ExecutableOpCode.EnterContextManager:
                    var enteringManager = PopContextManager(ref _stack, instruction.Span);
                    _stack.Push(enteringManager.Enter());
                    break;

                case ExecutableOpCode.ExitContextManager:
                    var exitingManager = PopContextManager(ref _stack, instruction.Span);
                    // Only exceptions are suppressible. Return/break/continue
                    // are normal exits to __exit__ and remain pending afterward.
                    if (_pendingAbrupt is PendingException { Exception: var exception } pendingException &&
                        (pendingException.CleanupId ?? -1) == instruction.CleanupId)
                    {
                        if (exitingManager.Exit(
                                ResolvePythonExceptionType(exception, _context),
                                CreatePythonExceptionInstance(exception),
                                PyNone.Instance))
                        {
                            RestoreSuppressedCompletion();
                        }
                    }
                    else
                    {
                        _ = exitingManager.Exit(PyNone.Instance, PyNone.Instance, PyNone.Instance);
                    }
                    break;

                case ExecutableOpCode.MatchCase:
                    var subject = Pop(ref _stack, instruction.Span);
                    if (!TryExecuteExecutableMatchCase(
                            _codeObject.MatchCases[instruction.MatchCaseIndex],
                            subject,
                            _context,
                            _locals,
                            _localCells))
                    {
                        _currentBlockIndex = instruction.FailureBlockIndex;
                        return true;
                    }
                    break;
            }

            return false;
        }

        private bool ExecuteForNext(in ExecutableInstruction instruction)
        {
            var iterator = PeekIterator(ref _stack, instruction.Span);
            if (!iterator.MoveNext())
            {
                _ = Pop(ref _stack, instruction.Span);
                _currentBlockIndex = instruction.TargetBlockIndex;
                return true;
            }

            _stack.Push(iterator.Current);
            return false;
        }

        private void ExecuteValueOperation(in ExecutableInstruction instruction)
        {
            switch (instruction.OpCode)
            {
                case ExecutableOpCode.GetIter:
                    var iterableSlot = _stack.Count - 1;
                    try { _stack[iterableSlot] = ToSequence(_stack[iterableSlot], instruction.Span, _context).GetEnumerator(); }
                    catch { _stack.RemoveTail(_stack.Count - iterableSlot); throw; }
                    break;

                case ExecutableOpCode.Call:
                    ExecuteExecutableCall(
                        _codeObject.CallSites[instruction.CallSiteIndex],
                        ref _stack,
                        _context);
                    break;

                case ExecutableOpCode.Subscript:
                case ExecutableOpCode.Slice:
                case ExecutableOpCode.Binary:
                case ExecutableOpCode.Augmented:
                case ExecutableOpCode.Unary:
                    ExecuteOperandValueOperation(instruction);
                    break;

                case ExecutableOpCode.MakeSlice:
                    var (start, stop, step) = PopExecutableSliceBounds(ref _stack, instruction.SliceParts, instruction.Span);
                    _stack.Push(CreateSliceValue(start, stop, step, instruction.Span, _context));
                    break;

            }

        }

        private static int ValueOperationInputCount(in ExecutableInstruction instruction) => instruction.OpCode switch
        {
            ExecutableOpCode.Unary => 1,
            ExecutableOpCode.Slice => 1 + System.Numerics.BitOperations.PopCount((uint)instruction.SliceParts),
            _ => 2,
        };

        private void ExecuteOperandValueOperation(in ExecutableInstruction instruction)
        {
            var first = _stack.Count - ValueOperationInputCount(instruction);
            try
            {
                // Borrow the actual operands through callback reentry. Completion
                // reuses their first slot before result admission; no extra extent.
                var result = instruction.OpCode switch
                {
                    ExecutableOpCode.Subscript => _preparedTypeSubscription is not null
                        ? InvokePreparedTypeSubscription(_stack[first + 1], instruction.Span, false).GetAwaiter().GetResult()
                        : ReadSubscriptValue(_stack[first], _stack[first + 1], instruction.Span, _context),
                    ExecutableOpCode.Slice => ExecuteExecutableSlice(ref _stack, instruction.SliceParts, instruction.Span, _context),
                    ExecutableOpCode.Binary => EvaluateBinaryOperator(instruction.BinaryOperator,
                        _stack[first], _stack[first + 1], _context, instruction.Span),
                    ExecutableOpCode.Augmented => EvaluateExecutableAugmented(instruction.AugmentedOperator,
                        _stack[first], _stack[first + 1], _context, instruction.Span),
                    ExecutableOpCode.Unary => EvaluateExecutableUnary(instruction.UnaryOperator, _stack[first], _context, instruction.Span),
                    _ => throw new InvalidOperationException("Unexpected value operation."),
                };
                CompleteExecutableValueTransfer(ref _stack, first, result);
            }
            catch { _stack.RemoveTail(_stack.Count - first); throw; }
        }

        // Ordinary returns deliver without throwing: a cleanup that handles
        // them in-frame routes through TryHandleAbrupt, otherwise the frame
        // records the value and exits normally (the Execute loop-end picks up
        // the flags). Frames without protected regions skip the routing scan
        // (and its per-return signal box) entirely. Propagated signals from
        // nested calls still arrive through the per-instruction catch below,
        // which stays as the routing backstop.
        private bool DeliverReturn(object value, LythonSourceSpan span)
        {
            if (_codeObject.ExceptionRegions.Count != 0 &&
                TryHandleAbrupt(_codeObject, _context, ref _stack, _blockEntryStackDepths, _currentBlockIndex, new PendingReturn(value), span, ref _pendingAbrupt, ref _currentBlockIndex, out _))
            {
                return true;
            }

            AbandonFrame(span);
            _frameReturnValue = value;
            _hasFrameReturn = true;
            return true;
        }

        private bool DeliverJump(PendingJump jump, LythonSourceSpan span)
        {
            var previous = ReferenceEquals(_pendingAbrupt, jump) ? jump.SavedPendingAbrupt : _pendingAbrupt;
            jump.SavedPendingAbrupt = PendingCleanupContains(previous, jump.TargetBlock) ? previous : null;
            _pendingAbrupt = jump.SavedPendingAbrupt;
            if (TryHandleAbrupt(_codeObject, _context, ref _stack, _blockEntryStackDepths, _currentBlockIndex, jump, span, ref _pendingAbrupt, ref _currentBlockIndex, out _)) return true;
            if (jump.DiscardIterator) _stack.RemoveTail(1);
            UnwindAbandonedHandlers(jump.TargetBlock);
            UnwindAbandonedHandlerVars(_context, span, jump.TargetBlock);
            _currentBlockIndex = jump.TargetBlock;
            return true;
        }

        private bool ExecuteControlFlow(in ExecutableInstruction instruction)
        {
            switch (instruction.OpCode)
            {
                case ExecutableOpCode.AbruptJump:
                    return DeliverJump(new PendingJump(instruction.TargetBlockIndex, instruction.DiscardIterator), instruction.Span);

                case ExecutableOpCode.JumpIfFalse:
                    if (!IsTruthy(Pop(ref _stack, instruction.Span), _context, instruction.Span))
                    {
                        _currentBlockIndex = instruction.TargetBlockIndex;
                        return true;
                    }
                    return false;

                case ExecutableOpCode.Jump:
                    _currentBlockIndex = instruction.TargetBlockIndex;
                    return true;

                case ExecutableOpCode.ClearException:
                    if (instruction.ExceptionNameIndex >= 0)
                    {
                        _ = DeleteName(_codeObject.Names[instruction.ExceptionNameIndex], _context, instruction.Span);
                        if (_context.ActiveHandlerVariables is { Count: > 0 } activeHandlers)
                        {
                            activeHandlers.Pop();
                        }
                    }
                    if (_savedActiveExceptions is { Count: > 0 } saves)
                    {
                        var saved = saves.Pop();
                        _context.State.SetCurrentException(saved.SavedException);
                        _pendingAbrupt = saved.SavedPendingAbrupt;
                    }
                    else _context.State.SetCurrentException(null);
                    return false;

                case ExecutableOpCode.MatchException:
                    var active = _context.State.CurrentException
                        ?? throw new InvalidOperationException("Exception selection requires an active exception.");
                    _stack.Push(MatchesCaughtExceptionValue(Pop(ref _stack, instruction.Span), active.Identity, _context, instruction.Span));
                    return false;

                case ExecutableOpCode.BindException:
                    var bound = _context.State.CurrentException
                        ?? throw new InvalidOperationException("Exception binding requires an active exception.");
                    bound.Adopt(_context, instruction.Span);
                    var name = _codeObject.Names[instruction.NameIndex];
                    AssignExecutableBoundName(_codeObject, _locals, _localCells, name, bound, _context, instruction.Span);
                    var suite = SavedActiveExceptions().Peek();
                    _context.ActiveHandlerVariables ??= new();
                    _context.ActiveHandlerVariables.Push((name, suite.SuiteStartBlockIndex ?? 0, suite.SuiteEndBlockIndex ?? int.MaxValue));
                    return false;

                case ExecutableOpCode.ReraiseException:
                    ThrowReraisedException(instruction.Span, _context);
                    return false;

                case ExecutableOpCode.EndFinally:
                    if (_pendingAbrupt is not null && (_pendingAbrupt.CleanupId ?? -1) != instruction.CleanupId)
                    {
                        // Normal nested cleanup leaves the outer completion pending.
                        _currentBlockIndex = instruction.TargetBlockIndex;
                        return true;
                    }
                    if (_pendingAbrupt is PendingJump pendingJump) return DeliverJump(pendingJump, instruction.Span);
                    if (_pendingAbrupt is PendingException)
                    {
                        // An exception-routed finally suite exits: restore the
                        // active exception saved when the suite was entered.
                        _context.State.SetCurrentException(
                            _savedActiveExceptions is { Count: > 0 } restored ? restored.Pop().SavedException : null);
                    }

                    if (_pendingAbrupt is not null)
                    {
                        PropagatePendingAbrupt(_pendingAbrupt);
                    }

                    _currentBlockIndex = instruction.TargetBlockIndex;
                    return true;

                case ExecutableOpCode.Return:
                    return DeliverReturn(Pop(ref _stack, instruction.Span), instruction.Span);

                case ExecutableOpCode.ReturnNone:
                    return DeliverReturn(PyNone.Instance, instruction.Span);

                default:
                    throw new InvalidOperationException($"Unknown executable opcode: {instruction.OpCode}");
            }
        }

        internal bool HasFrameReturn => _hasFrameReturn;

        internal object FrameReturnValue => _frameReturnValue.RequireNotNull();

        private async ValueTask DrainPendingDisposalsAsync()
        {
            System.Runtime.ExceptionServices.ExceptionDispatchInfo? failure = null;
            while (_stack.TakePendingDisposal() is { } cursor)
            {
                try { await cursor.DisposeAsync().ConfigureAwait(false); }
                catch (Exception exception)
                {
                    // A failed inner disposal must not strand an outer native
                    // enumerator. Preserve the first cleanup failure afterwards.
                    failure ??= System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(exception);
                }
            }
            failure?.Throw();
        }

        private async ValueTask ExecuteUntilCallAsync()
        {
            _stack.DeferAsyncDisposal = true;
            try
            {
                ResumePendingCall();
                if (_stack.HasPendingDisposals) await DrainPendingDisposalsAsync().ConfigureAwait(false);
                // Remember protected-entry depths for abrupt handler restoration.
                // Code without exception regions needs no depth array. Finally
                // routing remains separate from ordinary control-flow edges.
                while (true)
                {
                    var block = _codeObject.Blocks[_currentBlockIndex];
                    if (_blockEntryStackDepths.Length != 0)
                    {
                        _blockEntryStackDepths[_currentBlockIndex] ??= _stack.Count;
                    }
                    var jumped = false;

                    var instructions = block.InstructionArray;
                    for (; _instructionIndex < instructions.Length; _instructionIndex++)
                    {
                        var instruction = instructions[_instructionIndex];
                        _context.State.CheckExecution(instruction.Span);

                        try
                        {
                            if (_injectedException is not null && _delegation is null)
                            {
                                var injected = _injectedException;
                                _injectedException = null;
                                throw injected;
                            }
                            switch (instruction.OpCode)
                            {
                                case ExecutableOpCode.ApplyOperation:
                                    await ExecutePreparedOperationAsync((ExecutableOperation)_codeObject.Constants[instruction.ConstantIndex]!, instruction.Span, true).ConfigureAwait(false);
                                    break;
                                case ExecutableOpCode.Yield:
                                    YieldValue = Pop(ref _stack, instruction.Span);
                                    HasYield = true;
                                    _waitingForSend = true;
                                    _instructionIndex++;
                                    return;
                                case ExecutableOpCode.YieldFrom:
                                    if (_delegation is null)
                                    {
                                        var source = Pop(ref _stack, instruction.Span);
                                        var iterator = await IterAsync([source], instruction.Span, _context).ConfigureAwait(false);
                                        _delegation = new GeneratorDelegation(iterator, _context, instruction.Span);
                                    }
                                    var delegated = await _delegation.AdvanceAsync(_sentValue, _injectedException, true).ConfigureAwait(false);
                                    _sentValue = PyNone.Instance;
                                    _injectedException = null;
                                    if (delegated.HasValue)
                                    {
                                        YieldValue = delegated.Value;
                                        HasYield = true;
                                        return;
                                    }
                                    _stack.Push(_delegation.ReturnValue);
                                    _delegation = null;
                                    break;
                                case ExecutableOpCode.Import or
                                     ExecutableOpCode.DefineFunction or
                                     ExecutableOpCode.ExecuteFallbackStatement:
                                    await ExecuteDefinitionOrFallbackAsync(instruction).ConfigureAwait(false);
                                    break;

                                case ExecutableOpCode.LoadConst or
                                     ExecutableOpCode.LoadLocal or
                                     ExecutableOpCode.LoadClosure or
                                     ExecutableOpCode.LoadGlobal or
                                     ExecutableOpCode.LoadName or
                                     ExecutableOpCode.LoadMember or
                                     ExecutableOpCode.LoadCallMember or
                                     ExecutableOpCode.LoadCallReceiver or
                                     ExecutableOpCode.PreloadImplicitSuperArguments or
                                     ExecutableOpCode.StoreLocal or
                                     ExecutableOpCode.StoreClosure or
                                     ExecutableOpCode.StoreGlobal or
                                     ExecutableOpCode.StoreName or
                                     ExecutableOpCode.Dup or
                                     ExecutableOpCode.PopTop:
                                    if (instruction.OpCode is ExecutableOpCode.LoadMember or ExecutableOpCode.LoadCallMember or ExecutableOpCode.LoadCallReceiver)
                                    {
                                        if (TryLoadDirectCallReceiver(instruction)) break;
                                        var target = Pop(ref _stack, instruction.Span);
                                        var name = _codeObject.Names[instruction.NameIndex];
                                        var member = await TryResolveRuntimeMemberAsync(target, name, _context, instruction.Span).ConfigureAwait(false);
                                        if (!member.Found) throw PyMemberAccess.CreateMissingMemberError(target, name, instruction.Span, _context);
                                        if (instruction.OpCode == ExecutableOpCode.LoadCallReceiver) _stack.Push(PyNone.Instance);
                                        _stack.Push(member.Value);
                                    }
                                    else ExecuteStackTransfer(instruction);
                                    break;

                                case ExecutableOpCode.MakeList or
                                     ExecutableOpCode.MakeTuple or
                                     ExecutableOpCode.MakeSet or
                                     ExecutableOpCode.MakeDict or
                                     ExecutableOpCode.ResolveContextManager or
                                     ExecutableOpCode.EnterContextManager or
                                     ExecutableOpCode.ExitContextManager or
                                     ExecutableOpCode.MatchCase:
                                    jumped = await ExecuteStructureAsync(instruction).ConfigureAwait(false);
                                    break;

                                case ExecutableOpCode.Binary:
                                case ExecutableOpCode.Augmented:
                                    // Exact builtin operands cannot invoke guest protocols. Share the
                                    // synchronous transfer/admission path before creating any
                                    // operation-helper state machine; never retry a guest call.
                                    if ((_stack[_stack.Count - 2] is BigInteger or double or bool &&
                                         _stack[_stack.Count - 1] is BigInteger or double or bool) ||
                                        (_stack[_stack.Count - 2] is PyString && _stack[_stack.Count - 1] is PyString))
                                        ExecuteOperandValueOperation(instruction);
                                    else
                                        await ExecuteOperandValueOperationAsync(instruction).ConfigureAwait(false);
                                    break;

                                case ExecutableOpCode.Unary:
                                    if (_stack[_stack.Count - 1] is BigInteger or double or bool)
                                        ExecuteOperandValueOperation(instruction);
                                    else
                                        await ExecuteOperandValueOperationAsync(instruction).ConfigureAwait(false);
                                    break;

                                case ExecutableOpCode.Subscript:
                                    if (TrySuspendForTypeSubscription(instruction)) return;
                                    // Check after evaluating the key: it may have added or
                                    // withdrawn protocol keys while the receiver stayed on stack.
                                    if ((_stack[_stack.Count - 1] is BigInteger &&
                                         _stack[_stack.Count - 2] is PyList or PyTuple or PyBytes or PyString or PyRange) ||
                                        (_stack[_stack.Count - 1] is PyString &&
                                         _stack[_stack.Count - 2] is PyDict { HasProtocolKeys: false }))
                                        ExecuteOperandValueOperation(instruction);
                                    else
                                        await ExecuteOperandValueOperationAsync(instruction).ConfigureAwait(false);
                                    break;

                                case ExecutableOpCode.ForNext:
                                {
                                    // Cursor movement already has a synchronous prefix. Await it
                                    // here rather than entering another operation state machine.
                                    var iterator = (PyIteration.Cursor)Peek(ref _stack, instruction.Span);
                                    var advanced = await iterator.TryMoveNextAsync().ConfigureAwait(false);
                                    if (!advanced.HasValue)
                                    {
                                        _ = Pop(ref _stack, instruction.Span);
                                        await iterator.DisposeAsync().ConfigureAwait(false);
                                        _currentBlockIndex = instruction.TargetBlockIndex;
                                        jumped = true;
                                    }
                                    else _stack.Push(advanced.Value);
                                    break;
                                }

                                case ExecutableOpCode.Call:
                                    if (TrySuspendForExecutableCall(instruction)) return;
                                    await ExecuteValueOperationAsync(instruction).ConfigureAwait(false);
                                    break;

                                case ExecutableOpCode.GetIter:
                                    await ExecuteValueOperationAsync(instruction).ConfigureAwait(false);
                                    break;

                                case ExecutableOpCode.Slice:
                                    await ExecuteOperandValueOperationAsync(instruction).ConfigureAwait(false);
                                    break;

                                case ExecutableOpCode.MakeSlice:
                                    ExecuteValueOperation(instruction);
                                    break;

                                case ExecutableOpCode.JumpIfFalse:
                                    if (_stack[_stack.Count - 1] is not PyInstance)
                                        jumped = ExecuteControlFlow(instruction);
                                    else if (!await IsTruthyAsync(Pop(ref _stack, instruction.Span), _context, instruction.Span).ConfigureAwait(false))
                                    {
                                        _currentBlockIndex = instruction.TargetBlockIndex;
                                        jumped = true;
                                    }
                                    break;

                                case ExecutableOpCode.AbruptJump or ExecutableOpCode.Jump or
                                     ExecutableOpCode.MatchException or
                                     ExecutableOpCode.BindException or
                                     ExecutableOpCode.ReraiseException or
                                     ExecutableOpCode.ClearException or
                                     ExecutableOpCode.EndFinally or
                                     ExecutableOpCode.Return or
                                     ExecutableOpCode.ReturnNone:
                                    jumped = ExecuteControlFlow(instruction);
                                    break;

                                default:
                                    throw new InvalidOperationException($"Unknown executable opcode: {instruction.OpCode}");
                            }
                        }
                        catch (ReturnSignal signal)
                        {
                            if (!TryRouteReturn(signal, instruction.Span)) return;
                            jumped = true;
                        }
                        catch (ControlSignal signal)
                        {
                            if (!TryRouteControl(signal, instruction.Span)) throw;
                            jumped = true;
                        }
                        catch (LythonRuntimeException ex)
                        {
                            if (!TryRouteRuntimeException(ex, instruction.Span)) throw;
                            jumped = true;
                        }

                        // Shared abrupt routing trims the stack synchronously. The
                        // removed cursors finish disposal before a handler/finally
                        // or another guest instruction can execute.
                        if (_stack.HasPendingDisposals) await DrainPendingDisposalsAsync().ConfigureAwait(false);
                        if (jumped)
                        {
                            _instructionIndex = 0;
                            break;
                        }
                    }

                    if (_hasFrameReturn)
                    {
                        return;
                    }

                    if (!jumped)
                    {
                        return;
                    }
                }
            }
            finally
            {
                try
                {
                    // Yield retains active iterators. Every terminal route,
                    // including cancellation outside opcode routing, relinquishes
                    // native temporaries before this frame leaves its owner.
                    if (!HasYield && !HasPendingCall)
                    {
                        _preparedTypeSubscription = null;
                        _stack.RemoveTail(_stack.Count);
                    }
                    try { if (_stack.HasPendingDisposals) await DrainPendingDisposalsAsync().ConfigureAwait(false); }
                    finally { if (!HasYield && !HasPendingCall) _stack.ReleaseStorage(); }
                }
                finally { _stack.DeferAsyncDisposal = false; }
            }
        }
    }
}
