from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.parent / "native-only-method-lookup-20261121"
donor = prior / "quiet"
out = lab / "quiet"
out.mkdir()

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()

def sha(path):
    return sha_bytes(path.read_bytes())

def emit(path, source):
    if path.suffix == ".py":
        compile(source, str(path), "exec")
    path.write_text(source, encoding="utf-8", newline="\n")

def save(path, value):
    emit(path, json.dumps(value, indent=2) + "\n")

def tracked(path):
    return subprocess.check_output(["git", "show", "origin/master:" + path], cwd=repo)

def recoverable(artifact, paths, links, expected_sha, archives):
    base = "benchmarks/results/"
    binary = gzip.decompress(tracked(base + artifact))
    assert sha_bytes(binary) == expected_sha
    checked = {}
    for remote, (published, digest) in archives.items():
        assert sha_bytes(tracked(base + published)) == digest
        checked[remote + "/observations.tgz"] = digest
    return dict(paths=paths, links=links, bytes=len(binary), sha256=expected_sha, archives=checked, optional=False)

paths = {
    "direct-positional-methods-b1294-20261121/candidate": "2026-11-21-direct-positional-methods/observations.tgz",
    "native-method-lookup-b1295-20261121/reference": "2026-11-21-native-method-lookup/observations.tgz",
    "direct-method-control-b1296-20261121/reference": "2026-11-21-native-method-lookup/confirmation/observations.tgz",
    "native-only-method-lookup-b1297-20261121/reference": "2026-11-21-native-only-method-lookup/observations.tgz",
}
history = "2026-11-21-direct-positional-methods/candidate-core.dll.gz"
image_hash = load(donor / "identity.json")["imageFiles"]["reference"]["Lokad.Lython.dll"]
retire = [recoverable(history, [role + "/Lokad.Lython.dll" for role in paths], 4, image_hash,
    {role.split("/")[0]: (published, sha_bytes(tracked("benchmarks/results/" + published)))
     for role, published in paths.items()})]

from io import BytesIO
member = "confirmation/confirmation.json"
for remote, published in (
    ("native-callback-entry-confirm-b1257-20261121", "2026-11-21-native-callback-entry/confirmation/observations.tgz"),
    ("native-callback-text-cpython-b1258-20261121", "2026-11-21-cpython-callback-text/observations.tgz"),
):
    stored = tracked("benchmarks/results/" + published)
    with tarfile.open(fileobj=BytesIO(stored), mode="r:gz") as archive:
        info = archive.getmember(member)
        assert info.isfile()
        copy = archive.extractfile(info).read()
        assert len(copy) == info.size and json.loads(copy)["complete"]
    retire.append(dict(paths=[remote + "/" + member], links=1, bytes=len(copy), sha256=sha_bytes(copy),
        archives={remote + "/observations.tgz": sha_bytes(stored)}, optional=False))

prior_config = load(donor / "config.json")
prior_receipt = load(donor / "archive-receipt.json")
prior_identity = load(donor / "identity.json")
reference_donor = prior_identity["imageFiles"]["candidate"]
assert prior_receipt["complete"] and prior_receipt["archivedAndVerifiedUnderLease"]
assert len(reference_donor) == 32 and reference_donor == {name:sha(prior / "frozen/candidate" / name) for name in reference_donor}

manifest = out / "representative.json"
catalog = load(lab / "representative.json")
cases = ["scripts.regex.single-match-records", "scripts.regex.cursor-records", "scripts.regex.wide-single-match"]
catalog["cases"] = [case for id in cases for case in catalog["cases"] if case["id"] == id]
assert [c["id"] for c in catalog["cases"]] == cases
save(manifest, catalog)
local = load(lab / "identity.json")
reference, candidate = (subprocess.check_output(["git", "rev-parse", local[key]], cwd=repo, text=True).strip()
                       for key in ("reference", "candidate"))
assert reference.startswith("d51891009") and candidate.startswith("168cdf7a4")
image_files = local["imageFiles"]
core = "Lokad.Lython.dll"
for role, hashes in image_files.items():
    image = lab / "frozen" / role
    assert len(hashes) == 32 and {name: sha(image / name) for name in hashes} == hashes
    assert all(reference_donor[name] == value for name, value in hashes.items() if name != core)
    for suite, count in (("white", 67), ("public", 422)):
        log = (lab / f"{suite}-win.log").read_text(encoding="utf-8-sig")
        assert "Passed!" in log and f"Passed: {count:5d}, Skipped:" in log
    sdk = Path.home() / ".dotnet11"
    dotnet = sdk / "dotnet.exe"
    env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk) + os.pathsep + os.environ["PATH"])
    receipt = lab / f"quiet-{role}-verify.json"
    protocol = repo / "benchmarks/cpython-worker.py"
    assert sha(protocol) == prior_config["protocolSHA256"]
    subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify",
        "--catalog", manifest, "--dotnet", dotnet, "--python", "C:/Python313/python.exe",
        "--python-worker", protocol, "--out", receipt], check=True, env=env, timeout=95)
    proof = load(receipt)
    assert proof["state"] == "Completed" and proof["caseCount"] == 3 and proof["catalogSha256"] == sha(manifest)

identity = dict(sourceRevision=reference + " versus " + candidate, purpose="Inline scratch for small regex matches and two controls",
                imageFiles=image_files, normalAdapterPin="0.4.0", catalogSHA256=sha(manifest),
                coreSHA256={role + suffix: hashes[core] for role, hashes in image_files.items() for suffix in ("", "-control")})
save(out / "identity.json", identity)
root = "/home/lokad/lython-bench-checks/regex-inline-single-b1300-20261121"
unit = "lython-b1300-regex-inline-single-20261121"
jobs = [(case, "warm") for case in cases]
for name in ("collect.py", "archive-owned.py", "run.sh", "retrieve.py"):
    original = (donor / name).read_text(encoding="utf-8").replace(prior_config["root"], root).replace(prior_config["unit"], unit)
    if name == "collect.py":
        start, end = original.index("\njobs = "), original.index("\nassert len(jobs)")
        original = (original[:start] + "\njobs = " + repr(jobs) + original[end:]).replace("len(jobs)==3", "len(jobs)==3")
    if name == "archive-owned.py":
        original = original.replace("jobs=3,", "jobs=3,")
    if name == "retrieve.py":
        original = original.replace("['jobs']==3", "['jobs']==3")
    emit(out / name, original)
assert b"\r" not in (out / "run.sh").read_bytes()
for role in image_files:
    (out / role).mkdir()
    shutil.copyfile(lab / "frozen" / role / core, out / role / core)
    assert sha(out / role / core) == image_files[role][core]
parts = ("identity.json", "collect.py", "archive-owned.py", "run.sh", "representative.json",
         "candidate/" + core)
payload = out / "payload.tgz"
with tarfile.open(payload, "w:gz") as file:
    for name in parts:
        file.add(out / name, arcname=name)
stage = dict(root=root, unit=unit, identity=identity, source=prior_config["root"], sourceRole="candidate",
             sourceFiles=reference_donor, sourceCatalogSHA256=prior_config["catalogSHA256"],
             donorArchiveSHA256=prior_receipt["archiveSHA256"], protocolSource=prior_config["root"] + "/cpython-worker.py",
             protocolSHA256=prior_config["protocolSHA256"], payloadBytes=payload.stat().st_size,
             payloadSHA256=sha(payload), retireGroups=retire, catalogSHA256=sha(manifest),
             unpackedBytes=sum((out / name).stat().st_size for name in parts))
save(out / "config.json", stage)
source = (donor / "remote-launch.py").read_text(encoding="utf-8")
start, end = source.index("\nc=") + 1, source.index("\nb=Path(")
source = source[:start] + "c=" + repr(stage) + source[end:]
source = source.replace("lython-b1297-fixtures", "lython-b1300-fixtures")
assert "c['unpackedBytes']+640*1024" in source
emit(out / "remote-launch.py", source)
emit(lab / "launch.py", (prior / "launch.py").read_text(encoding="utf-8")
     .replace("Native-only method lookup comparison", "Inline single-match regex comparison"))
emit(lab / "summarize.py", (prior / "summarize.py").read_text(encoding="utf-8"))
print(f"Prepared three lanes with {stage['unpackedBytes']} bytes of persistent working data.")
