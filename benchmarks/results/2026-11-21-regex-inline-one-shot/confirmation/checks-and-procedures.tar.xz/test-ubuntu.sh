set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/regex-shared-group-utf8-20261121
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/regex-inline-one-shot-20261121
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter 'FullyQualifiedName~Regex&Category!=Stress' | tee "$logs/white-ubuntu.log"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Regex|FullyQualifiedName~ReversedAnchored)&Category!=Stress' | tee "$logs/public-ubuntu.log"
