a=12345
b=6789
values=[]
for c in [-7,-1,1,7]:
    value=(a*b+5000)//c
    alias=value
    values.append((value,alias is value,(a-b+17)%c))
print(values)
