using System.Reflection;
using System.Diagnostics;
using System.Text;
using System.Text.Json;
using Lokad.Lython;
using Lokad.Lython.Utf8Regex;

// Existing complete scripts and comparison host; allocation counters only.
// This tool performs no collection and does not claim local elapsed/CPU evidence.
var image = Path.GetFullPath(args[0]);
var catalogPath = Path.GetFullPath(args[1]);
var output = Path.GetFullPath(args[2]);
if (File.Exists(output)) throw new IOException("Preserve original observations.");
var assembly = Assembly.LoadFrom(Path.Combine(image, "Lokad.Lython.Benchmarks.dll"));
const BindingFlags all = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;
var fixtureType = assembly.GetType("Lokad.Lython.Benchmarks.Comparison.ComparisonFileFixture", true)!;
var hostType = assembly.GetType("Lokad.Lython.Benchmarks.Comparison.ComparisonFileHost", true)!;
var parse = fixtureType.GetMethod("Parse", all)!;
var reset = hostType.GetMethod("Reset", all)!;
var check = hostType.GetMethod("ReadOutputs", all)!;
using var catalog = JsonDocument.Parse(File.ReadAllText(catalogPath, Encoding.UTF8));
var rows = new List<object>();
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var source = item.GetProperty("source").GetString()!;
    var expected = item.GetProperty("expectedOutput").GetString()!;
    var fixture = parse.Invoke(null, [item.GetProperty("fixtureJson").GetString()])!;
    var folder = Path.Combine(Path.GetTempPath(), "lython-comparison-files-" + Guid.NewGuid().ToString("N"));
    var budget = new LythonMemoryBudget(256L * 1024 * 1024);
    var host = (ILythonHost)Activator.CreateInstance(hostType, all, null, [fixture, folder], null)!;
    try
    {
        using var script = new LythonEngine(Utf8RegexProvider.Instance).Compile(source, budget);
        if (!script.IsValid) throw new InvalidOperationException(string.Join("|", script.Diagnostics));
        var baseline = budget.ReservedBytes;
        void Run()
        {
            reset.Invoke(host, null);
            using (var result = script.Run(host))
            {
                if (!result.Success || result.StandardOutput != expected || result.StandardError != "")
                    throw new InvalidDataException(result.Failure?.Message ?? result.StandardOutput);
                check.Invoke(host, null);
            }
            if (budget.ReservedBytes != baseline) throw new InvalidOperationException("Ownership did not return to compilation baseline.");
        }
        var warm = Stopwatch.StartNew();
        for (var i = 0; i < 128 || warm.Elapsed < TimeSpan.FromSeconds(4); i++) Run();
        var batches = new List<double>();
        for (var block = 0; block < 5; block++)
        {
            var before = GC.GetTotalAllocatedBytes(precise: true);
            for (var i = 0; i < 64; i++) Run();
            batches.Add((GC.GetTotalAllocatedBytes(precise: true) - before) / 64.0);
        }
        rows.Add(new { id = item.GetProperty("id").GetString(), allocatedBytesPerInvocation = batches, sharedBudgetBaselineRestored = true });
        script.Dispose();
        if (budget.ReservedBytes != 0) throw new InvalidOperationException("Compiled owner retained allowance.");
    }
    finally
    {
        (host as IDisposable)?.Dispose();
        var full = Path.GetFullPath(folder);
        if (Path.GetDirectoryName(full) != Path.GetFullPath(Path.GetTempPath()).TrimEnd(Path.DirectorySeparatorChar) ||
            !Path.GetFileName(full).StartsWith("lython-comparison-files-", StringComparison.Ordinal))
            throw new InvalidOperationException("Unexpected owned fixture path.");
        if (Directory.Exists(full)) Directory.Delete(full, recursive: true);
    }
}
File.WriteAllText(output, JsonSerializer.Serialize(new { assembly = typeof(LythonEngine).Assembly.FullName, rows,
    boundary = "Complete warm runs including mediated I/O/reset, all output/file checks and result cleanup; compilation/startup/final cache teardown excluded. Process-wide CLR allocation counters, no forced GC; no timing comparison." }, new JsonSerializerOptions { WriteIndented = true }), new UTF8Encoding(false));
