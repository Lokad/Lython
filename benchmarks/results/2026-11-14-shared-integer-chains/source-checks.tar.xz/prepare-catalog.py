from pathlib import Path
import copy,hashlib,json,subprocess,tempfile
r=Path(__file__).parent;prior=r.parent/'native-owned-slots-r339'
original=json.loads((prior/'catalog.json').read_text(encoding='utf-8'))
helper=next(c for c in original['cases']if c['id']=='scripts.csv-fulfillment.large')
source=helper['source'];body=source[source.index("    sku=row['sku']"):source.index('\n    return sku,True,gross,total_grams,packs')]
invalid="    if quantity<=0 or pack_size<=0 or quantity>available:\n        return sku,False,0,0,0"
assert invalid in body
body=body.replace(invalid,"    if quantity<=0 or pack_size<=0 or quantity>available:\n        invalid+=1\n        continue")
body='\n'.join('    '+line for line in body.splitlines())+'\n'
source='''import csv

def main():
    totals={}
    invalid=0
    count=0
    with open('input.csv',newline='') as source:
        for row in csv.DictReader(source):
            count+=1
'''+ '\n'.join('    '+line for line in body.splitlines())+'''
            prior=totals.get(sku,(0,0,0))
            totals[sku]=(prior[0]+gross,prior[1]+total_grams,prior[2]+packs)
    with open('report.csv','w',newline='') as target:
        writer=csv.writer(target,lineterminator='\\n')
        writer.writerow(['sku','gross_cents','grams','packs'])
        for sku in sorted(totals): writer.writerow([sku,*totals[sku]])
    print(count,invalid)

main()
'''
import base64
fixture=json.loads(helper['fixtureJson'])
with tempfile.TemporaryDirectory(prefix='shared-arithmetic-',dir=r.resolve())as folder:
 work=Path(folder).resolve();assert work.parent==r.resolve()
 for name,value in fixture['inputFiles'].items():(work/name).write_bytes(base64.b64decode(value))
 done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],cwd=work,capture_output=True,text=True,encoding='utf-8',timeout=15)
 assert done.returncode==0 and not done.stderr,done.stderr
 assert done.stdout==helper['expectedOutput']
 assert all((work/name).read_bytes()==base64.b64decode(value)for name,value in fixture['outputFiles'].items())
c=copy.deepcopy(helper);c.update(id='scripts.csv-fulfillment.inline.large',source=source,sourceUtf8Bytes=len(source.encode()),sourceSha256=hashlib.sha256(source.encode()).hexdigest())
old=json.loads((prior/'b710/catalog.json').read_text(encoding='utf-8'));text=next(c for c in old['cases']if c['id']=='scripts.text-summary-helpers.nonlocal-counter.large')
original['cases']=[c,helper,text];(r/'catalog.json').write_text(json.dumps(original,separators=(',',':'),ensure_ascii=False)+'\n',encoding='utf-8',newline='\n');(r/'inline-fulfillment.py').write_text(source,encoding='utf-8',newline='\n')
(r/'workload-python-controls.json').write_text(json.dumps(dict(reference='CPython3.13.2 isolated',case=c['id'],sourceSHA256=c['sourceSha256'],fixtureSHA256=c['fixtureSha256'],goldensIdenticalToHelperForm=True,sameSourceAcrossMeasuredRevisions=True,stdout=done.stdout),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Complete inline fulfillment uses unchanged fixtures/goldens; helper and captured-text controls preserved.',flush=True)
