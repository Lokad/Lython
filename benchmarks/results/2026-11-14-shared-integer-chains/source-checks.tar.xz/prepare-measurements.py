from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent;prior=r.parent/'native-owned-slots-r339'
source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
out=r/'b711';out.mkdir()
aux=json.loads((prior/'b709/identity.json').read_text(encoding='utf-8'))['candidateAuxiliaryFiles']
assert all(source['auxiliaryFiles'][role][name]==sha for role in ['reference','candidate']for name,sha in aux.items())
identity=dict(sourceRevision='R341frozen'+source['coreSHA256']['candidate'][:8]+' vs committed1778c30d/frozen38c0562f',purpose='Same-source complete inline CSV fulfillment warm/compile-run with native-helper and captured-text controls; one shared closed arithmetic kernel, no external timing.',coreSHA256={label:source['coreSHA256']['candidate'if label.startswith('candidate')else'reference']for label in ['reference','candidate','reference-control','candidate-control']},candidateAuxiliaryFiles=aux,referenceAuxiliaryFiles=aux,catalogSHA256=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest(),referenceCase='scripts.csv-fulfillment.inline.large',variantCase='scripts.csv-fulfillment.inline.large',controlCases=['scripts.csv-fulfillment.large','scripts.text-summary-helpers.nonlocal-counter.large'],sourceAndScriptDifferIntentionally=False)
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.csv-fulfillment.inline.large','warm'],['scripts.csv-fulfillment.inline.large','compile-run'],['scripts.csv-fulfillment.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','warm']]
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py','launch.py']:
 s=(prior/'b709'/name).read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/native-owned-slots-b709-20261114','/home/lokad/lython-bench-checks/shared-arithmetic-b711-20261114').replace('lython-b709-native-owned-slots-20261114','lython-b711-shared-arithmetic-20261114').replace('B709','B711')
 if name=='collect.py':
  a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==4 and all(case in cases for case,lane in jobs)\n'+s[b:]
 if name in ['archive-owned.py','retrieve.py','summarize.py']:s=s.replace("==3", "==4").replace('jobs=3','jobs=4')
 if name=='launch.py':s=s.replace('798edc1d2a6a080a44feafda0b21f699129c5ee6a349dc30a5c0f756b99ebd4d',source['coreSHA256']['reference'])
 if name.endswith('.py'):ast.parse(s)
 (out/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
 for name in ['identity.json','collect.py','archive-owned.py','run.sh']:t.add(out/name,arcname=name)
 for name,arc in [('catalog.json','representative.json'),('candidate-core.dll','candidate-core.dll'),('reference-core.dll','reference-core.dll'),('candidate-identity.json','source-identity.json'),('reference-identity.json','reference-source-identity.json')]:t.add(r/name,arcname=arc)
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
config=dict(root='/home/lokad/lython-bench-checks/shared-arithmetic-b711-20261114',sourceRoot='/home/lokad/lython-bench-checks/native-checkpoint-b710-20261114',unit='lython-b711-shared-arithmetic-20261114',identity=identity,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(prior/'verify-worker.py').read_text(encoding='utf-8').replace("[('reference',0),('candidate',0),('reference',1),('candidate',1)]", "[(role,index)for index in range(3)for role in ['reference','candidate']]")
(r/'verify-worker.py').write_text(s,encoding='utf-8',newline='\n')
for role in ['reference','candidate']:(r/('allocation-'+role+'-catalog.json')).write_bytes((r/'catalog.json').read_bytes())
(r/'measure-allocation.py').write_bytes((prior/'measure-allocation.py').read_bytes())
print('Prepared four-job300s fixed-worker source pair plus separate short allocation comparison.',flush=True)
