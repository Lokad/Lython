# Lokad.Lython 0.11.0

Updated2026-11-14. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance,
including newly generated scripts. A green delivery or isolated experiment is a
checkpoint, not completion of this objective. Experimental history belongs in
[EXPERIMENTS](benchmarks/EXPERIMENTS.md), immutable results and saved plan history.

## Actual delivery status

| State | Evidence and limits |
| --- | --- |
| Latest fully qualified runtime | R335cdd92944/frozenf4c4f027,581inputs, GREEN43536449801: Windows/Ubuntu actual11/10, original stress and installed consumers;16summaries/source proof cached. Incremental mediated/borrowed XML shares one tree builder. Early exit avoids unused records; parser/graph growth stays conservatively command-owned. [Delivery](benchmarks/results/2026-11-14-incremental-xml/delivery/README.md). Do not repeat unchanged qualification. |
| Committed, focused qualified; combined full delivery running | R338c48c93ae/e2482e0b removes backward-edge exclusion; R3391778c30d/38c0562f separates native eligibility from16-slot private transport.637internal/1562public per actual11/10; full[43545993574](https://github.com/Lokad/Lython/actions/runs/43545993574)runs. CSV check-digit warm−17..−19.5%/fresh−14.8..−16.8%, allocation flat. Fulfillment warm−12.88..−13.73%/fresh−14.57..−16.09%, allocation−9.84%. Wider CPU supports both affected results; control uncertainty remains. [R338](benchmarks/results/2026-11-14-native-backedges/README.md),[R339](benchmarks/results/2026-11-14-native-owned-slots/README.md). |
| Active runtime prototypes | None. Native eligibility changes are committed; no speculative frame/arena/value redesign is selected. |
| Published external comparison | R332/B704d90dd5fe/frozen798,2026-11-13, stockCPython3.13.16/quietF4as_v7: invoice warm1.25–1.26×, compile1.08–1.10×, fresh1.23–1.27×; captured text1.51–1.54×, search1.65–1.69×, JSON0.82–0.85×, report1.21–1.22×. R336B70796B config at qualifiedcdd/f4: compile1.06–1.09×, warm1.26–1.28×, fresh1.10–1.13×. Describe these sources, not HEAD. [Boundaries/evidence](docs/BENCHMARKS.md). |
| Remaining uncertainty | Historical formatting15.125ms adversity remains unexplained; two controlled confirmations support retention. Original native-return elapsed is diagnostic. R334 XML cost, earlier report/search controls, R338invoice and R339small-helper controls remain explicit debt. Do not infer release-wide neutrality or add percentages across source pairs. |

## Completed foundations

- Shared compiler facts/nonlocal correction, annotation demand and lowered-tree
  retention cleanup are delivered. [Compiler evidence](benchmarks/results/2026-11-02-shared-compiler-facts/README.md).
- Direct UTF8 formatting/storage: original allocation−8.67%, later pair−8.59%;
  two controlled report CPU/elapsed blocks support−5..−8%on those sources. Keep
  original adverse clocks/failed conditions. [Evidence](benchmarks/results/2026-11-02-formatting-confirmation/README.md).
- Native helper returns: historical whole-run allocation−19.92%CSVhelpers and
  −19.31%JSONhelpers, separate from diagnostic elapsed. Corrected full delivery
  8f07764a complete. [Evidence](benchmarks/results/2026-11-02-native-function-returns/README.md).
- Revised bulk CSV already selectively revisited the6–8%opportunity and shipped
  admitted array adoption/shared keys. R308/R314 alternatives remain withdrawn
  with useful lifetime regressions retained. [Evidence](benchmarks/results/2026-11-02-native-csv-records/README.md).
- Calls share final slots/linear continuations/native prefixes across Run/RunAsync.
  Integer chains/counters avoid many boxes. Tuple transport, immutable builtin
  definitions, positional ZIP and native UTF8 JSON input are delivered. R335adds
  incremental XML/shared construction. Keep real suspension and stack handoff.
- Slower call-arena/control designs remain lessons. R325/R327 do not establish a
  dominant removable packet/frame; all46native-entry samples resolve against
  same-process Tier1 code. Default dictionary work is actual work. R338's initial
  frame-allocation explanation was corrected: ordinary bound prefixes already
  defer contexts. No large frame/storage removal is claimed for eligibility alone.
- R328exact frozen316 initial CI failure remains a historical failure. Descendant
  qualification does not rewrite it. All failed/adverse evidence survives.

## Prioritized deliverables

1. **Close combined R338/R339 delivery without waiting idle.** Full43545993574
   covers both committed eligibility changes. Cache terminal/source proof/logs;
   query at least four minutes apart. Preserve637internal/1562public focused
   evidence, actual pending formatting/I/O, admission-before-effects, retained
   aliases, joined cleanup, budget reuse, empty-loop cancellation and recursion.
   No unchanged focused reruns. Accept measured affected gains with explicit
   invoice/small-helper control uncertainty; no universal/external gain claim.

2. **R340: refresh representative external evidence at this coherent checkpoint.**
   Use exact committed1778c30d/frozen38c0562f and unchanged workers/optional adapter,
   stockCPython3.13.16. Existing five warm scripts plus invoice compile/compile-run;
   add the now-representative complete CSV fulfillment script. Keep source/fixtures/
   goldens, I/O, validation and cleanup boundaries identical per engine. Two fresh
   processes/engine, rotating short batches/full-request warmups; size the single
   bounded owner for eight usable jobs on the quiet VM. No startup/RSS/tail claim.
   Keep adverse/unstable controls; stop with usable ratios or explicit uncertainty.
   Update the primary table only with exact measured identity and delivery status.
   This refresh is evidence for choosing the next design, not a new framework.

3. **Select a substantial next redesign from owning work.** Reuse existing evidence
   first; if current-source evidence cannot choose, one bounded source attribution
   capture targets the largest representative gap after R340. Preserve unknown
   samples; do not substitute generic call names for owning work. R336's short
   config phases establish no compiler cliff or removable dominant setup stage;
   independent medians cannot be subtracted as attribution. Do not repeat unchanged
   phase collection. No blind visitor/cache/metadata prototype.

   | Area | Work/storage to eliminate; semantic acceptance and displacement |
   | --- | --- |
   | Complete calls/frames and operand transport | Existing final slots/native bound spans remove repackaging and unnecessary eligibility limits. Select a remaining full activation/storage stage only with owning evidence; remove its displaced route, no new arena/control backend. Preserve live defaults/receivers/closures, Python errors, pending transfers and awaited cleanup. Assess native iteration's remaining unsupported opcodes without assuming frame allocation. |
   | Per-record construction | CSV adopted/shared-key rows, native counters and iterative JSON are present; XML now avoids unused records. Next change must remove an actual representation/copy/pass in complete scripts and retire the constructor. Preserve mapping callbacks, mutation, aliases and admission-before-effect; do not relabel R308/R314. |
   | Scalar dispatch | Native integer chains/counter slots already reduce boxes. Object-valued operands remain. Establish remaining boxing/transport dominance before choosing a wider representation; exact promotion, identity and aliases are mandatory. A universal tagged-value VM is unselected. |
   | Bulk text conversion | ASCII casing/UTF8 word probes/direct formatting exist. Remove a remaining complete conversion/build stage, not isolated scalar tweaks. Preserve Unicode expansion/context, error order and actual callback suspension; delete superseded conversion code. |
   | Frontend analysis | Duplicate-name modeling accounted for only0.41–0.95%allocation on the studied source. Consolidate proven repeated facts/retained IR with diagnostics/scopes/nonlocals/cancellation and budget cleanup intact; multiple visitors alone do not prove dominance. |

   Before a selected prototype, record hypothesis, eliminated work/storage, affected
   complete scripts, semantic/cancellation/ownership acceptance, implementation to
   delete, bounded before/after/control comparison and regression-debt decision.
   Temporary setbacks are acceptable in a justified redesign with an explicit
   completion milestone. Stop an investigation once it can select or reject that
   bounded change; do not turn uncertainty into an open-ended audit.

4. **Regex develops independently.** Core owns Python-specific nativeUTF8/original
   windows/byte-scalar/capture/flag/error/current-token contract and existing owners/
   caches. Dev producers and adapter-local bridges remain permitted. Core has no
   backend edge. Completed dev80/15b248dc88internal/534public per11/10 checks are not
   rerun; normal29inputs/binaries/optional0.4nonpackable adapter remain unchanged.
   Read-only dev84worktreeae463cb4 and immutable package834162df are distinct source
   identities. Missing capabilities: separate one-match work/result owners, native
   UTF8group-name enumeration/copy, token-independent cursor construction with
   cancellable preparation. Only affected final adapter qualification defers.
   Select the next concrete change from changed Lython code/contract or new producer
   capability; no sibling mutation/pin promotion or repeated unchanged qualification.
   [Assessment](benchmarks/results/2026-11-14-regex-provider-capabilities/README.md).
   Distinguish contract tests, semantics and real backend performance/safety.

## Evidence policy and lasting constraints

Separate simplification, allocation reduction and demonstrated CPU improvement.
Percentages inform decisions, not automatic vetoes. Timeouts, unstable unchanged
controls and inconclusive observations establish uncertainty. Permit bounded
confirmation/refinement/measurement correction for an explicit reason, retaining
original failed conditions and all adverse points. No blanket one-attempt,
no-retiming or permanently-closed rule.

Use focused Release correctness/cancellation/ownership checks during iteration;
batch Windows/Ubuntu actual11/10, original stress and installed Release consumers
at coherent checkpoints. Remain fully managed/memory-safe; no unsafe compilation/
C#/APIs, pointers, P/Invoke or native probing. Preserve managed stack admission,
host capabilities/original paths+Cwd, cancellation, cycles/XML depth, checked
representation bounds and bounded I/O chunks. No fuel/quotas, hidden caps/default
allowance, regex work/time policy, heap tracing, weak reclamation, forced GC or
abandoned users. Borrowed allowance funds capacity/overlap, aliases/results/caches
and pending users. First refusal is terminal through suppression/finally; preserve
its origin, await cleanup, never retry. Long streams use bounded host executions.
Force nonincremental builds after restoration; copy/verify frozen sources/bits and
auxiliary worker/adapter. Persist evidence, join users, preserve VM floors/current
images. Current docs stay concise/Lython-centric. See[AGENTS](AGENTS.md).
