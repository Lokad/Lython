import csv

def main():
    totals={}
    invalid=0
    count=0
    with open('input.csv',newline='') as source:
        for row in csv.DictReader(source):
            count+=1
            sku=row['sku']
            quantity=int(row['quantity'])
            unit_cents=int(row['unit_cents'])
            discount_bps=int(row['discount_bps'])
            tax_bps=int(row['tax_bps'])
            available=int(row['available'])
            pack_size=int(row['pack_size'])
            grams_per_unit=int(row['grams_per_unit'])
            shipping_cents=int(row['shipping_cents'])
            if quantity<=0 or pack_size<=0 or quantity>available:
                invalid+=1
                continue
            base=quantity*unit_cents
            discount=(base*discount_bps+5000)//10000
            net=base-discount
            tax=(net*tax_bps+5000)//10000
            packs=(quantity+pack_size-1)//pack_size
            shipping=packs*shipping_cents
            total_grams=quantity*grams_per_unit
            gross=net+tax+shipping
            prior=totals.get(sku,(0,0,0))
            totals[sku]=(prior[0]+gross,prior[1]+total_grams,prior[2]+packs)
    with open('report.csv','w',newline='') as target:
        writer=csv.writer(target,lineterminator='\n')
        writer.writerow(['sku','gross_cents','grams','packs'])
        for sku in sorted(totals): writer.writerow([sku,*totals[sku]])
    print(count,invalid)

main()
