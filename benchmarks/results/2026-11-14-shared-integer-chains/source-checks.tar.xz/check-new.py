from pathlib import Path
import os,subprocess
r=Path(__file__).parent;env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';'+env['PATH']
for target in ['net11.0','net10.0']:
 log=r/('new-'+target+'.log')
 with log.open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f',target,'--filter','FullyQualifiedName~SharedIntegerChain','--logger','trx','--results-directory',str((r/('new-'+target)).resolve())],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 print(target,done.returncode,log.read_text(encoding='utf-8')[-2500:],flush=True);assert done.returncode==0
