def values(a,b):
    result=[]
    try:
        for c in [-7,-1,1,7]: result.append(((a*b+5)//c,(a-b+17)%c))
    finally: print('finished')
    return result
for a in [-9223372036854775808,-9,0,9,9223372036854775807]:
    print(values(a,7))
