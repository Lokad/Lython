from pathlib import Path
import json,os,subprocess
r=Path(__file__).parent
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.IntegerChains.cs');s=p.read_text(encoding='utf-8');lines=s.splitlines();a=next(i for i,l in enumerate(lines)if 'end = index;'in l);b=next(i for i,l in enumerate(lines)if l=='    }'and i>a)
for i in range(a,b):
 if lines[i].startswith('    '):lines[i]=lines[i][4:]
for i in range(b+1,len(lines)-1):
 if lines[i].startswith('    '):lines[i]=lines[i][4:]
p.write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n')
env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';'+env['PATH']
for assembly in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:
 log=r/(assembly+'-initial-net11.log')
 with log.open('w',encoding='utf-8',newline='\n')as f:
  done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','test',f'tests/{assembly}/{assembly}.csproj','-c','Release','-f','net11.0','--filter','FullyQualifiedName~NativeIntegerChain','--logger','trx','--results-directory',str((r/(assembly+'-initial-net11')).resolve())],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 print(assembly,done.returncode,log.read_text(encoding='utf-8')[-1300:],flush=True)
 assert done.returncode==0
