from pathlib import Path
import hashlib,json,re,shutil,tarfile
r=Path(__file__).parent;identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in identity['sources'].items())
allocation=json.loads((r/'allocation-summary.json').read_text(encoding='utf-8'));timing=json.loads((r/'b711/summary.json').read_text(encoding='utf-8'));receipt=json.loads((r/'b711/archive-receipt.json').read_text(encoding='utf-8'));decision=json.loads((r/'decision.json').read_text(encoding='utf-8'))
assert timing['complete']and timing['jobs']==4 and receipt['allWorkersJoined']and receipt['guestFixturesRemoved']
assert hashlib.sha256((r/'b711/observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
counts={}
for assembly in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:
 for target in ['net11.0','net10.0']:
  name=assembly+'-'+target+'.log';s=(r/name).read_text(encoding='utf-8');match=re.search(r'Passed!.*?Failed:\s+0, Passed:\s+(\d+)',s);assert match,name;counts[name]=int(match[1])
assert list(counts.values())==[927,927,1871,1871]
out=Path('benchmarks/results/2026-11-14-shared-integer-chains');out.mkdir()
for name in ['candidate-identity.json','reference-identity.json','workload-python-controls.json','python-controls.json','worker-verification.json','inspection.json','allocation-summary.json','focused-checks.json','prospective.json','decision.json']:shutil.copyfile(r/name,out/name)
for name in ['summary.json','archive-receipt.json','terminal-status.json','observations.tgz']:shutil.copyfile(r/'b711'/name,out/name)
with tarfile.open(out/'source-checks.tar.xz','w:xz')as t:
 for name in ['PLAN-before-r341.md','reference-core.dll','reference-sources.tar.xz','freeze-candidate.py','candidate-build.log','candidate-core.dll','candidate-sources.tar.xz','prepare-regressions.py','prepare-catalog.py','catalog.json','inline-fulfillment.py','format-and-check.py','check-new.py','prepare-focused.py','check-related.py','inspect.py','prepare-measurements.py','verify-worker.py','measure-allocation.py','allocation-reference-catalog.json','allocation-candidate-catalog.json','save-fixture-failure.py','initial-missing-fixture','save.py']+list(counts):t.add(r/name,arcname=name)
 for pattern in ['*.stdout','*.stderr','new-*.log','*-initial-net11.log','probe-build-*.log','reference-allocation-*.*','candidate-allocation-*.*']:
  for p in r.glob(pattern):t.add(p,arcname=p.name)
 for p in r.glob('**/*.trx'):t.add(p,arcname=p.relative_to(r).as_posix())
 for p in r.glob('*.py'):
  if p.name in {v['name']+'.py'for v in json.loads((r/'python-controls.json').read_text(encoding='utf-8'))['programs']}:t.add(p,arcname=p.name)
 t.add('tests/Lokad.Lython.PublicApi.Tests/SharedIntegerChainTests.cs',arcname='tests/SharedIntegerChainTests.cs')
 for name in ['identity.json','config.json','collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py','launch.py','launch-command.py','launch.log','observe-not-before.json','extraction.json']:t.add(r/'b711'/name,arcname='b711/'+name)
 for name in ['Program.cs','Allocation.csproj']:t.add(r.parent/'word-buffer-loan-r324/allocation'/name,arcname='allocation-tool/'+name)
 for p in(r/'reference').glob('Allocation.*'):t.add(p,arcname='allocation-tool/'+p.name)
table='| Complete script / phase | Elapsed change | Wider CPU change | Process spread candidate/reference | Max IQR |\n| --- | ---: | ---: | ---: | ---: |\n'
for row in timing['timing']:
 elapsed=row['lythonSourcePairElapsedPercent'];cpu=row['lythonSourcePairWiderCpuPercent'];table+=f"|{row['case'].removeprefix('scripts.')} /{row['lane']}|{min(elapsed):+.2f}..{max(elapsed):+.2f}%|{min(cpu):+.2f}..{max(cpu):+.2f}%|{row['candidateProcessSpreadPercent']:.2f}/{row['referenceProcessSpreadPercent']:.2f}%|{max(row['iqrPercent'].values()):.2f}%|\n"
(out/'README.md').write_text(f'''# Shared closed integer-chain execution

2026-11-14UTC, R341frozen53becdb6 over fully qualified1778c30d/frozen38c0562f.
Decision: **{decision['status']}**. {decision['reason']}

Move the native-only arithmetic scanner/evaluator into one checked kernel shared
by native and ordinary executable input operations. Both callers publish through
their existing lifetime machinery. Intermediate exact machine integers stay in a
local accumulator; only the final value is boxed. Overflow, unsupported operands/
operations and Python protocols keep exact ordinary arithmetic. Cancellation uses
the active token through the sequence. No tagged VM, shadow slots, pool, owner,
public API or new execution route. The displaced native-only file is removed.

Ordinary execution declines combined publication if pending disposal or owned
temporaries require per-op retirement. Published local/namespace stores, identity,
handler state, admission-before-effects and first refusal remain observable.
927internal/1871public focused Release cases pass each actual.NET11/10. Twelve new
public cases cover module/class/closure/loop/generator/handler arithmetic, exact
signs/overflow, aliases, error order, actual asynchronous numeric protocols without
replay, funding through awaited cleanup, terminal refusal despite suppression/
finally returns, CPU-loop cancellation and shared-allowance reuse. Six isolated
CPython3.13.2 controls supply independent expectations. Original two missing warm
file fixtures failed; corrected fixtures are seeded identically, with original
source/log/TRX retained and no production fix or assertion relaxation.

The complete4096-row fulfillment validation/pricing/aggregation/report script keeps
arithmetic inside an ordinary loop body. Source/fixtures/outputs are identical
across revisions and independently checked by CPython. Frozen inspection shows
the same37slots/170instructions, native=False before/after. Native helper and
captured-text controls keep their exact sources. Each frozen worker independently
verifies goldens and shared-budget reuse before timing.

Four desktop allocation processes show7,425,525 B versus6,649,560 B per affected
invocation, **−10.45%**; native-helper7,107,982 B and captured-text546,078 B controls
are flat. This includes reset/checks/cleanup; no forced GC or local timing claim.
Allocation reduction is separate from CPU and elapsed observations.

{table}
B711four jobs finish{timing['elapsedSeconds']:.3f}s under one300s owner on the quiet
AzureF4as_v7/Ubuntu24.04.4/.NET11RC3. Ordinary workstation GC/tiering; unchanged
B685worker/optional0.4adapter, two fresh processes per revision/job, eight-second
full-request warmups and five rotating0.5s wall batches. Warm clocks include
mediated RAM-file I/O, complete stdout/file validation and prior-result cleanup;
compilation/startup, reset/protocol and final cache teardown are excluded.
Compile-to-result adds compilation/compiled-owner disposal. Wider CPU includes
reset/protocol. Process-median ranges are not confidence intervals. No CPython
timing, RSS/heap, embedding-tail or universal speedup is inferred. All adverse and
inconclusive controls survive; see the explicit[debt decision](decision.json).

All image/source/golden/allowance/quiet/join/archive gates pass; no workers or RAM
fixtures remain. RawSHA{receipt['archiveSHA256']}. No VM floor relaxation, evidence
retirement or producer change. Full retained platform/stress/installed-consumer
delivery remains separate. Publication held; this milestone does not complete the
whole-script performance objective.

[Timing/wider CPU](summary.json),[allocation](allocation-summary.json),
[exact frozen sources/bits, initial failure and focused checks](source-checks.tar.xz),
[raw](observations.tgz).
''',encoding='utf-8',newline='\n')
print('Archived shared kernel source removal, focused checks, initial fixture failure and independent bounded evidence.',flush=True)
