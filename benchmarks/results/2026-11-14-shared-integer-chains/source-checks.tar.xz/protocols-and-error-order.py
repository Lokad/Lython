def value(a,b):
    if False: missing=1
    try: return (a//b)+missing
    finally: print('finally')
for divisor in [0,1]:
    try: value(2,divisor)
    except ZeroDivisionError: print('zero first')
    except UnboundLocalError: print('local later')
class Value:
    def __mul__(self,other):
        print('multiply',other)
        return 11
def calculate(a,b):
    for n in [1]: return a*b+7
print(calculate(Value(),3))
