class Values:
    a=50000
    b=50000
    result=(a*b+5)//3
    alias=result
    observed=locals()['result']
print(Values.result,Values.alias is Values.result,Values.observed is Values.result)
