from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).parent
programs=[
('module-loop-values', '''a=12345
b=6789
values=[]
for c in [-7,-1,1,7]:
    value=(a*b+5000)//c
    alias=value
    values.append((value,alias is value,(a-b+17)%c))
print(values)
'''),
('protected-loop-exact-promotion', '''def values(a,b):
    result=[]
    try:
        for c in [-7,-1,1,7]: result.append(((a*b+5)//c,(a-b+17)%c))
    finally: print('finished')
    return result
for a in [-9223372036854775808,-9,0,9,9223372036854775807]:
    print(values(a,7))
'''),
('class-namespace-stores', '''class Values:
    a=50000
    b=50000
    result=(a*b+5)//3
    alias=result
    observed=locals()['result']
print(Values.result,Values.alias is Values.result,Values.observed is Values.result)
'''),
('generator-unwind', '''events=[]
def values(a,b):
    try:
        for n in [1,2,3]:
            value=(a*b+5000)//10000+n
            reply=yield value
            if reply is not None: a=reply
    finally: events.append('finished')
g=values(12345,6789)
print(next(g),g.send(30000))
try: g.throw(ValueError('stop'))
except ValueError: print(events)
'''),
('closure-and-observable-final-values', '''def outer(a,b):
    result=0
    def read(): return result
    for n in [1,2]:
        result=(a*b+5000)//10000+n
        assert read()==result
    return read
read=outer(12345,6789)
print(read(),read())
'''),
('protocols-and-error-order', '''def value(a,b):
    if False: missing=1
    try: return (a//b)+missing
    finally: print('finally')
for divisor in [0,1]:
    try: value(2,divisor)
    except ZeroDivisionError: print('zero first')
    except UnboundLocalError: print('local later')
class Value:
    def __mul__(self,other):
        print('multiply',other)
        return 11
def calculate(a,b):
    for n in [1]: return a*b+7
print(calculate(Value(),3))
''')]
records=[];rows=[]
for name,source in programs:
 (r/(name+'.py')).write_text(source,encoding='utf-8',newline='\n')
 done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],capture_output=True,text=True,encoding='utf-8',timeout=15)
 (r/(name+'.stdout')).write_text(done.stdout,encoding='utf-8',newline='\n');(r/(name+'.stderr')).write_text(done.stderr,encoding='utf-8',newline='\n')
 assert done.returncode==0 and not done.stderr,(name,done.stderr)
 records.append(dict(name=name,sourceSHA256=hashlib.sha256(source.encode()).hexdigest(),stdout=done.stdout,exitCode=0))
 rows.append('        { '+json.dumps(source,ensure_ascii=False)+', '+json.dumps(done.stdout,ensure_ascii=False)+' },')
(r/'python-controls.json').write_text(json.dumps(dict(reference='CPython3.13.2 isolated',programs=records),indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
path=Path('tests/Lokad.Lython.PublicApi.Tests/SharedIntegerChainTests.cs');assert not path.exists()
path.write_text('''using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.PublicApi.Tests;

public sealed class SharedIntegerChainTests
{
    public static TheoryData<string, string> Programs => new()
    {
'''+ '\n'.join(rows)+'''
    };

    [Theory]
    [MemberData(nameof(Programs))]
    public async Task ArithmeticPreservesPublishedValuesScopesProtocolsAndUnwind(string source, string expected)
    {
        var budget = new LythonMemoryBudget(4 * 1024 * 1024);
        using (var script = new LythonEngine().Compile(source, budget))
        {
            Assert.True(script.IsValid, string.Join("; ", script.Diagnostics.Select(d => d.Message)));
            var baseline = budget.ReservedBytes;
            foreach (var asynchronous in new[] { false, true })
            {
                using (var result = asynchronous ? await script.RunAsync(new MockLythonHost()) : script.Run(new MockLythonHost()))
                {
                    Assert.True(result.Success, result.Failure?.Message);
                    Assert.Equal(expected, result.StandardOutput);
                }
                Assert.Equal(baseline, budget.ReservedBytes);
            }
        }
        Assert.Equal(0, budget.ReservedBytes);
    }
}
''',encoding='utf-8',newline='\n')
print('Six independently checked Python scopes/loop/protocol/error/generator regressions generated.',flush=True)
