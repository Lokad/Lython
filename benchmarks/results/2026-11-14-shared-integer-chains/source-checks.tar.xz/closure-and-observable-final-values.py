def outer(a,b):
    result=0
    def read(): return result
    for n in [1,2]:
        result=(a*b+5000)//10000+n
        assert read()==result
    return read
read=outer(12345,6789)
print(read(),read())
