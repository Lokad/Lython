from pathlib import Path
import json,shutil
r=Path(__file__).parent;out=r/'initial-missing-fixture';out.mkdir()
for name in ['new-net11.0.log','new-net11.0']:shutil.move(str(r/name),str(out/name))
shutil.copyfile('tests/Lokad.Lython.PublicApi.Tests/SharedIntegerChainTests.cs',out/'SharedIntegerChainTests.cs')
(out/'correction.json').write_text(json.dumps(dict(failed=2,passed=10,reason='Warm false-loop branch still opens input.txt, but the warm host had no seeded file. Seed the same input as the cancellation execution. No production change or assertion relaxation.'),indent=2)+'\n',encoding='utf-8',newline='\n')
p=r/'prospective.json';d=json.loads(p.read_text(encoding='utf-8'));d['evidenceLabelCorrection']='The R331 label on the prior invoice-chain evidence was imprecise; use the native integer-chain evidence linked by BENCHMARKS.md, not a claim that R331 introduced it.';p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n')
