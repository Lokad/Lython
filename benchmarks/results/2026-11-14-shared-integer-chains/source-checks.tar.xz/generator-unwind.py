events=[]
def values(a,b):
    try:
        for n in [1,2,3]:
            value=(a*b+5000)//10000+n
            reply=yield value
            if reply is not None: a=reply
    finally: events.append('finished')
g=values(12345,6789)
print(next(g),g.send(30000))
try: g.throw(ValueError('stop'))
except ValueError: print(events)
