from pathlib import Path
r=Path(__file__).parent
s=(r.parent/'native-owned-slots-r339/check-related.py').read_text(encoding='utf-8')
s=s.replace("FullyQualifiedName~Native|FullyQualifiedName~ExecutableCall", "FullyQualifiedName~Native|FullyQualifiedName~Integer|FullyQualifiedName~Generator|FullyQualifiedName~FormattedString|FullyQualifiedName~ExecutableCall")
s=s.replace("'FullyQualifiedName~LargeHelper|", "'FullyQualifiedName~SharedInteger|FullyQualifiedName~Generator|FullyQualifiedName~FormattedString|FullyQualifiedName~LargeHelper|")
(r/'check-related.py').write_text(s,encoding='utf-8',newline='\n')
