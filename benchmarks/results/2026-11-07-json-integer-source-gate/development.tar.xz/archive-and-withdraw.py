from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-07-json-integer-source-gate');out.mkdir()
files=['src/Lokad.Lython/Runtime/LythonRuntime.Builtins.cs','src/Lokad.Lython/Runtime/LythonRuntime.IntegerParsing.cs','src/Lokad.Lython/Runtime/LythonRuntime.Json.Deserialize.cs','src/Lokad.Lython/Runtime/LythonRuntime.Operations.cs','tests/Lokad.Lython.Tests/IntegerTextAdmissionTests.cs','tests/Lokad.Lython.Tests/JsonNumberTokenStorageTests.cs']
assert set(subprocess.check_output(['git','diff','--name-only'],text=True).splitlines())==set(files)
(r/'prototype.patch').write_bytes(subprocess.check_output(['git','-c','core.autocrlf=false','diff','--binary','--',*files]))
for name in ['source-gate.json','fixture-validation.json','identity.json','focused.json','local-summary.json','failed-focused.json']:
 (out/name).write_text((r/name).read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
with tarfile.open(out/'development.tar.xz','w:xz')as a:
 for p in r.iterdir():
  if p.is_file()and p.suffix in ['.py','.cs','.json','.log','.patch']:a.add(p,arcname=p.name)
 for folder in ['candidate','warm-sync','warm-async']:
  for p in(r/folder).rglob('*'):
   if p.is_file():a.add(p,arcname=p.relative_to(r))
 for f in files:a.add(f,arcname='prototype-source/'+f)
decision=dict(retained=False,reason='The BCL decimal parser materially reduces intermediate arithmetic and allocation. Sharing the R45 radix-chunk kernel regresses complete JSON allocation even after removing its decoded string. No new universal parser, threshold route or hidden generic UTF8 conversion bridge is retained.',allocation=dict(decimal40Percent=[10.51515844174309,10.511],decimal4096Percent=[2753.905,2748.787]),checks='208internal/986public per actual.NET11/10, all goldens/funding/isolation/cleanup in both five-case short diagnostics; desktop elapsed variable, adverse outcomes retained.',sourceRestoration='Exact four production/two test files restored to HEADad74fa41; frozen precommit images and full patch retained. Nonincremental rebuild required before any future local no-build tests or image freeze.',developmentSHA256=hashlib.sha256((out/'development.tar.xz').read_bytes()).hexdigest(),sourceStatus='No delivered runtime change. No VM collection or new platform qualification requested for withdrawn code.')
(out/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
subprocess.run(['git','restore','--source=HEAD','--',*files],check=True)
identity=json.loads((r.parent/'delivery-comparison-b400/identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['productionSources'].items())
readme='''# JSON integer construction source gate — R46

2026-11-07, baseline8c9fd0d7/frozen d3a6c778, prototype on metadataad74fa41.
**Withdrawn. No runtime change is delivered.** This bounded decision prevents
extending the standalone int kernel into a materially more efficient decimal
parser solely to remove source duplication.

JSON already parses Int64 tokens from UTF-8 and gives hooks independently funded
raw text. Its large default still reserves magnitudes and decoded working text,
uses CLR BigInteger.Parse, then funds its retained result. The prototype replaced
that with the R45 native accumulator/radix chunks, deleting decoded copies, a
sole-production-caller preflight helper and its old infrastructure-only test use.
Small JSON and all Python int forms shared one admission/commit path. JSON grammar
remained validated separately. No collector, quota, new allowance or unsafe code.

Focused Release208internal/986public checks per actual.NET11/10 pass, including
JSON grammar/raw_decode, hooks/suspension, cancellation/refusal/ownership and
standalone integer semantics. An initial pair of new funding assertions incorrectly
compared balances across execution-frame cleanup (expected59B, observed−133B).
The fixture now observes result funding before frame cleanup; both failures and
the original test source remain. This was a test correction, not a runtime fix.

Reuse the existing unchanged five-case reflection driver/normal GC/tiering:
three separate ALCs sharing CoreLib/process GC/hash witness,32warmups/image,
five rotated rounds*4complete jobs. Two explicit numeric JSON fixtures keep the
maintained source unchanged:4096records of40-digit values and16records of4096-digit
values, plus ordinary CSV/text/JSON controls. Isolated CPython3.13.2 independently
validates full output/files. Separate sync/async diagnostics include mediated I/O,
goldens, result disposal and fixture handling; compilation/startup excluded.

| Input | Sync allocation | Async allocation | Diagnostic elapsed vs two baseline roles |
| --- | ---: | ---: | --- |
|40-digit JSON values|+10.515%|+10.511%|sync−5.11to+2.19%; async+4.95to+12.39%|
|4096-digit JSON values|+2753.905%|+2748.787%|sync+6.98to+11.67%; async+15.44to+21.95%|

Ordinary allocation is within0.007%; unchanged desktop elapsed controls move up
to9%. Clocks are diagnostic, not a CPU/VM improvement claim. The precise large
allocation regression is sufficient to withdraw this representation, rather than
repeat quiet timing or hide the adverse condition behind the40-digit case. The
CLR parser uses materially fewer arithmetic intermediates than radix-chunk
accumulation here. R45's separate comparison against its old per-digit Python int
parser remains valid; it is not evidence against CLR's decimal parser.

Supported.NET10/11 reference assemblies expose BigInteger.Parse for char spans,
not a direct public byte-span overload. A generic numeric-interface bridge is not
adopted as proof of native parsing or removal of its internal conversion. Future
work may revisit this boundary with a materially different bulk algorithm or
supported backend capability; this is not a permanent prohibition or fixed-percent
veto. Do not introduce a thresholded second parser merely to rescue this attempt.

All goldens, funding, image isolation and cleanup gates pass. Original/core/test
snapshots, failed assertions, scripts, precise allocation and raw adverse clocks
are preserved. Exact production/source restoration checked against B400's560-file
inventory. Restored local binaries need a nonincremental build before reuse.
No new VM/platform/package campaign or publication. The broader text/report/call/
collection/frontend performance objective remains active.

[Raw development/source/images](development.tar.xz), [decision](decision.json),
[complete-job summary](local-summary.json), [focused checks](focused.json),
[original failed assertions](failed-focused.json), [source gate](source-gate.json),
[independent fixture goldens](fixture-validation.json) and [identity](identity.json).
'''
(out/'README.md').write_text(readme,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');a=s.index('## Priority 2 — R46');b=s.index('## Next redesign boundaries',a)
s=s[:a]+'''## Priority 2 — continue whole-script redesign selection after the R46 gate

R46 is withdrawn and fully archived: sharing R45's radix-chunk integer kernel
with default JSON removes decoded text but raises complete-job allocation10.515/
10.511% on40-digit records and2753.905/2748.787% on4096-digit records, sync/async.
Desktop clocks also include adverse outcomes and moving unchanged controls. CLR
decimal parsing already eliminates many arithmetic intermediates.208internal/
986public per actual11/10 and every diagnostic golden/ownership gate pass; this
does not rescue the storage regression. Exact production is restored to8c9fd0d7;
force a nonincremental local build before future no-build checks/freezing workers.
No speculative shared parser, null-source invariant, replacement guard or revised
architecture-only test remains. History: benchmarks/results/2026-11-07-json-integer-source-gate/.

Do not treat R45 as proof that all int conversions should use the same algorithm.
Keep JSON's current decoded/BCL path until materially different bulk evidence
justifies replacing it; supported public BigInteger.Parse has no byte-span overload.
No thresholded second parser or generic bridge is selected merely to hide the
conversion. Reconsideration remains possible with new evidence/capability.

Next gate: inspect the maintained file-search/file-manifest helper scripts against
the current architecture and existing evidence. These complete early-exit/copy/
manifest workflows broaden representative file-processing coverage; native UTF-8
paths, byte summation, list/tuple iteration and fused cased splitting already exist.
Use a bounded missing-phase observation only if it can identify real removable
work; preserve host-mediated I/O, original path requests, cleanup, current tokens
and admitted output/storage. Do not open another general profiling campaign or
invent a new framework. Calls, transport, collections and frontend boundaries below
remain independent; completion of this gate does not complete performance work.

''' +s[b:];p.write_text(s,encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');s+='\n## JSON integer construction source gate (2026-11-07)\n\nR46 is withdrawn: shared radix chunks raise whole-job allocation10.5% for40-digit\nJSON values and roughly27.5x additional allocation for4096-digit values. Focused\nsemantics/ownership pass, clocks remain diagnostic/adverse; CLR decimal parsing\nkeeps its current path. No speculative runtime code survives.\n[Evidence, failed fixture and source restoration](results/2026-11-07-json-integer-source-gate/README.md).\n';p.write_text(s,encoding='utf-8',newline='\n')
print('R46 adverse evidence archived and prototype fully removed; exact560-production inventory restored. Local rebuild required.')
