from pathlib import Path
import base64,copy,hashlib,importlib.util,json,os,shutil,subprocess,sys,tempfile
r=Path(__file__).parent;old=r.parent/'integer-utf8-r45';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checks=json.loads((r/'focused.json').read_text(encoding='utf-8'))
for name,digest in checks['productionSources'].items():assert sha(Path(name))==digest
baseline=old/'refined/net11.0/Lokad.Lython.dll'
assert sha(baseline)=='d3a6c77800093e69135a949d07b6f1fc765c689a566c8c904954908009d693e2'
for role,core in [('before',baseline),('candidate',r/'candidate/net11.0/Lokad.Lython.dll')]:
 target=r/'images'/role;shutil.copytree(old/'images/before',target,copy_function=os.link)
 (target/'Lokad.Lython.dll').unlink();shutil.copy2(core,target/'Lokad.Lython.dll')
catalog=json.loads((r.parent/'delivery-comparison-b395/representative.json').read_text(encoding='utf-8'))
original=next(c for c in catalog['cases']if c['id']=='scripts.json-summary-helpers.large')
spec=importlib.util.spec_from_file_location('existing_protocol',r.parent/'delivery-comparison-b400/retrieved/cpython-worker.py');protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
affected=[];validation=[]
for digits,count in [(40,4096),(4096,16)]:
 case=copy.deepcopy(original);case['id']=f'scripts.json-summary-helpers.decimal-{digits}-digits'
 fixture=json.loads(case['fixtureJson']);lines=[];records=0
 for line in base64.b64decode(fixture['inputFiles']['input.jsonl']).decode('utf-8').splitlines():
  if not line.strip():lines.append('');continue
  if records==count:break
  record=json.loads(line);value=record['amount'];magnitude=10**(digits-1)+abs(value)
  record['amount']=-magnitude if value<0 else magnitude
  lines.append(json.dumps(record,ensure_ascii=False,separators=(',',':')));records+=1
 assert records==count
 fixture['size']=count;fixture['inputFiles']['input.jsonl']=base64.b64encode(('\n'.join(lines)+'\n').encode('utf-8')).decode('ascii')
 folder=r/f'validate-{digits}';folder.mkdir()
 outputs={}
 with tempfile.TemporaryDirectory(prefix='owned-',dir=folder)as work:
  for name,data in fixture['inputFiles'].items():
   p=Path(work)/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(base64.b64decode(data))
  done=subprocess.run([sys.executable,'-I','-S','-X','utf8','-c',case['source']],cwd=work,capture_output=True,text=True,encoding='utf-8')
  assert done.returncode==0 and not done.stderr,done.stderr
  outputs={name:(Path(work)/name).read_bytes()for name in fixture['outputFiles']}
 fixture['outputFiles']={name:base64.b64encode(data).decode('ascii')for name,data in outputs.items()}
 case['size']=count;case['fixtureJson']=json.dumps(fixture,ensure_ascii=False,separators=(',',':'));case['expectedOutput']=done.stdout
 for key,field in [('sourceSha256','source'),('fixtureSha256','fixtureJson'),('expectedOutputSha256','expectedOutput')]:case[key]=hashlib.sha256(case[field].encode('utf-8')).hexdigest()
 case['expectedOutputUtf8Bytes']=len(done.stdout.encode('utf-8'));case['expectedFilesSha256']=protocol.file_digest(outputs)
 assert case['source']==original['source']
 affected.append(case);validation.append(dict(case=case['id'],records=count,inputBytes=sum(len(base64.b64decode(v))for v in fixture['inputFiles'].values()),sourceUnchanged=True,expectedOutput=done.stdout,cpython=sys.version,expectedFilesSHA256=case['expectedFilesSha256']))
catalog['cases']=affected+[c for c in catalog['cases']if c['id']in ['scripts.csv-summary-functions.large','scripts.text-summary-helpers.large','scripts.json-summary-helpers.large']]
assert len(catalog['cases'])==5
(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
(r/'fixture-validation.json').write_text(json.dumps(validation,indent=2)+'\n',encoding='utf-8',newline='\n')
identity=dict(source='ad74fa41 plus R46 shared JSON/runtime integer conversion prototype',baselineProduction='8c9fd0d7',baselineCoreSHA256=sha(baseline),candidateCoreSHA256=checks['coreSHA256'],sources=checks['productionSources'],fixtureValidation=validation,workerSHA256=sha(r/'images/before/Lokad.Lython.Benchmarks.dll'),toolSHA256=sha(old/'tool/out/complete-jobs.dll'),conditions='Reuse R45 five-case reflection driver unchanged, normal GC/tiering,32warmups/image,5rotated rounds*4jobs, three ALCs sharing CoreLib/hash witness/process GC; allocation precise, desktop elapsed diagnostic. Original purpose label belongs to reused R45 driver; these are R46 JSON inputs. No VM collection or final delivery claim.')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Prepared two independently CPython-validated JSON magnitudes and three ordinary controls; no timing yet.',flush=True)
