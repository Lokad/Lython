from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-07-json-integer-source-gate')
identity=json.loads((r.parent/'delivery-comparison-b400/identity.json').read_text(encoding='utf-8'))
fixed=[]
for name,digest in identity['productionSources'].items():
 p=Path(name);data=p.read_bytes()
 if hashlib.sha256(data).hexdigest()!=digest:
  data=data.replace(b'\r\n',b'\n');assert hashlib.sha256(data).hexdigest()==digest,name
  p.write_bytes(data);fixed.append(name)
test=Path('tests/Lokad.Lython.Tests/IntegerTextAdmissionTests.cs')
test.write_bytes(subprocess.check_output(['git','show','HEAD:'+test.as_posix()]))
assert not subprocess.check_output(['git','diff','--name-only'],text=True).strip()
(r/'restoration-note.json').write_text(json.dumps(dict(initialAssertion='git restore honored core.autocrlf and changed two production files bytewise LF→CRLF; semantic git diff was empty.',normalizedOnlyMatchingOriginalHashes=fixed,all560OriginalHashesMatch=True,restoredBinariesRequireNonincrementalBuild=True),indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'development.tar.xz','w:xz')as a:
 for p in r.iterdir():
  if p.is_file()and p.suffix in ['.py','.cs','.json','.log','.patch']:a.add(p,arcname=p.name)
 for folder in ['candidate','warm-sync','warm-async']:
  for p in(r/folder).rglob('*'):
   if p.is_file():a.add(p,arcname=p.relative_to(r))
 # The full patch and original initial test are preserved; exact candidate core
 # and source hashes establish the corrected prototype without restoring it.
decision=json.loads((out/'decision.json').read_text(encoding='utf-8'));decision['developmentSHA256']=hashlib.sha256((out/'development.tar.xz').read_bytes()).hexdigest()
(out/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(r/'archive-and-withdraw.py').read_text(encoding='utf-8');start=s.index('readme=')
exec(compile(s[start:],str(r/'finish-documentation.py'),'exec'),dict(__file__=str(r/'finish-documentation.py'),r=r,out=out,Path=Path))
