from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).parent
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
checks={};selection='Category!=Stress&(FullyQualifiedName~Json|FullyQualifiedName~IntegerText|FullyQualifiedName~GeneralIntegerText|FullyQualifiedName~UnicodeIntegerText)'
for target in ['net11.0','net10.0']:
 for project in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:
  name=project+'-'+target+'.log'
  with (r/name).open('w',encoding='utf-8') as out:
   d=subprocess.run([env['DOTNET_HOST_PATH'],'test','tests/'+project+'/'+project+'.csproj','-c','Release','-f',target,'--nologo','--filter',selection,'-v','quiet'],env=env,stdout=out,stderr=subprocess.STDOUT)
  log=(r/name).read_text(encoding='utf-8');checks[name]=dict(exitCode=d.returncode,selection=selection,tail=log[-2400:])
  print(name,'exit',d.returncode,log[-550:],flush=True)
  if d.returncode:
   (r/'failed-focused.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8',newline='\n');raise SystemExit(d.returncode)
 folder=r/'candidate'/target;folder.mkdir(parents=True)
 shutil.copy2('src/Lokad.Lython/bin/Release/'+target+'/Lokad.Lython.dll',folder/'Lokad.Lython.dll')
identity=dict(checks=checks,coreSHA256={t:hashlib.sha256((r/'candidate'/t/'Lokad.Lython.dll').read_bytes()).hexdigest()for t in ['net11.0','net10.0']},productionSources={str(p):hashlib.sha256(p.read_bytes()).hexdigest()for p in Path('src/Lokad.Lython').rglob('*.cs')if not any(s in p.parts for s in ['bin','obj'])},fullDeliveryPending=True)
(r/'focused.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
