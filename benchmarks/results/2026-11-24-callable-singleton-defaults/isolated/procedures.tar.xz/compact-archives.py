from pathlib import Path
import hashlib
import json
import subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
root='/home/lokad/lython-bench-checks'
prior=lab.with_name('callable-singleton-defaults-20261124')
results=repo/'benchmarks/results'
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
def recorded_archive(result,archive_name):
    terminal=read(result/'terminal-status.json')
    receipt=terminal['receipt']
    assert terminal['exitCode']=='0' and receipt['complete'] and receipt['allWorkersJoined'] and receipt['archivedAndVerifiedUnderLease']
    path=result/archive_name
    assert sha(path.read_bytes())==receipt['archiveSHA256']
    assert sha(subprocess.check_output(['git','show','origin/master:'+path.relative_to(repo).as_posix()],cwd=repo))==receipt['archiveSHA256']
    return receipt['archiveSHA256']

recent=results/'2026-11-24-callable-singleton-defaults'
recent_identity=read(recent/'identity.json')
recent_files=recent_identity['imageFiles']['candidate']
assert len(recent_files)==32 and {path.name:sha(path.read_bytes()) for path in (prior/'candidate').iterdir()}==recent_files
recent_spec=dict(name='callable-singleton-defaults-b1610-20261124',core=recent_files['Lokad.Lython.dll'],
    archive=recorded_archive(recent,'observations.tar.xz'))

historical=results/'2026-11-07-retained-checkpoint'
historical_core=read(historical/'identity.json')['coreSHA256']['candidate']
historical_profile=results/'2026-11-07-report-execution-cost'
profile=lab.with_name('report-cost-r52')
assert read(profile/'identity.json')['files']['Lokad.Lython.dll']==historical_core
profile_archive=historical_profile/'observations.tgz'
profile_receipt=read(historical_profile/'archive-receipt.json')
assert profile_receipt['complete'] and profile_receipt['allWorkersJoined']
assert sha(subprocess.check_output(['git','show','origin/master:'+profile_archive.relative_to(repo).as_posix()],cwd=repo))==profile_receipt['archiveSHA256']
historical_spec=dict(name='delivery-comparison-b406-20261107',core=historical_core,
    consumers={'retained-cpython-b409-20261107':recorded_archive(historical,'observations.tgz'),
               'report-cost-b410-20261107':profile_receipt['archiveSHA256']})
host='lokad@20.166.121.73'
common=['-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes','-o','ConnectTimeout=14']
scp=['C:/Windows/System32/OpenSSH/scp.exe',*common]
ssh=['C:/Windows/System32/OpenSSH/ssh.exe',*common,host,'python3 -']
backup=lab/'historical-b406-core.dll'
if not backup.exists():
    original=f"{host}:{root}/{historical_spec['name']}/candidate/Lokad.Lython.dll"
    subprocess.run(scp+[original,backup],timeout=35,check=True)
assert sha(backup.read_bytes())==historical_core

remote='specs='+repr((recent_spec,historical_spec))+'\n'+'''
from pathlib import Path
import fcntl, hashlib, json, lzma, os, shutil, stat, subprocess
root=Path('/home/lokad/lython-bench-checks').resolve()
sha=lambda data:hashlib.sha256(data).hexdigest()
def inactive(run):
    assert run.resolve()==run and run.parent==root
    assert not (run/'guest-fixtures').exists() and subprocess.run(['pgrep','-af',str(run)],capture_output=True).returncode==1
def verify_receipt(run,expected):
    inactive(run)
    receipt=json.loads((run/'archive-receipt.json').read_text())
    assert receipt['archiveSHA256']==expected and receipt['complete'] and receipt['allWorkersJoined']
with (root/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    print(json.dumps(dict(freeBefore=shutil.disk_usage(root).free)),flush=True)
    for item in specs:
        if shutil.disk_usage(root).free >= 12*1024*1024:break
        run=root/item['name']
        inactive(run)
        core=run/'candidate/Lokad.Lython.dll'
        if 'archive' in item:
            verify_receipt(run,item['archive'])
            assert sha((run/'observations.tar.xz').read_bytes())==item['archive']
        else:
            for consumer,expected in item['consumers'].items():
                verify_receipt(root/consumer,expected)
                assert (root/consumer/'candidate/Lokad.Lython.dll').resolve()==core
        assert core.resolve()==core and stat.S_ISREG(core.lstat().st_mode) and core.stat().st_nlink==1
        data=core.read_bytes()
        assert sha(data)==item['core']
        encoded=lzma.compress(data,preset=3)
        assert shutil.disk_usage(root).free>=len(encoded)+1048576
        stored=run/'candidate-core.dll.xz'
        with stored.open('xb') as package:
            package.write(encoded)
            package.flush()
            os.fsync(package.fileno())
        assert lzma.decompress(stored.read_bytes())==data
        core.unlink()
        print(json.dumps(dict(coreSHA256=item['core'],compressedSHA256=sha(encoded),stored=str(stored.relative_to(root)),
              freeAfter=shutil.disk_usage(root).free)),flush=True)
    assert shutil.disk_usage(root).free>=10*1024*1024
'''
result=subprocess.run(ssh,input=remote.encode('utf-8'),capture_output=True,timeout=55)
(lab/'compaction.jsonl').write_bytes(result.stdout)
print(result.stdout.decode(),end='')
if result.returncode:print(result.stderr.decode(),end='')
result.check_returncode()
