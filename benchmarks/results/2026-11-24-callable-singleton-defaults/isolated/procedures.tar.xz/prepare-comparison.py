from pathlib import Path
import shutil

lab=Path(__file__).resolve().parent
prior=lab.with_name('callable-singleton-defaults-20261124')
prepare=(prior/'prepare.py').read_text(encoding='utf-8')
prepare=prepare.replace("source = lab / 'source'","source = lab.with_name('callable-singleton-defaults-20261124') / 'source'")
prepare=prepare.replace('fd1d8fce4','14b982071')
prepare=prepare.replace("assert 'Passed: 206' in (lab/'windows-public.log')","assert 'Passed:   201' in (lab/'windows-public.log')")
prepare=prepare.replace('Keep fully admitted singleton positional defaults on the closed pair callable until metadata observation',
    'Keep prepaid singleton defaults in a separate callable layout with ordinary callable size preserved')
prepare=prepare.replace('callable-singleton-defaults-b1610-20261124','callable-singleton-defaults-isolated-b1611-20261124')
prepare=prepare.replace('b1610-fixtures','b1611-fixtures')
start=prepare.index('launcher=(donor/'); end=prepare.index('for name in (\'prepare-allocation.py',start)
prepare=prepare[:start]+'''prior=lab.with_name('callable-singleton-defaults-20261124')
launcher=(prior/'quiet.py').read_text(encoding='utf-8')
launcher=launcher.replace('lython-b1610-callable-singleton-defaults-','lython-b1611-callable-singleton-defaults-isolated-')
launcher=launcher.replace('b1610-', 'b1611-')
compile(launcher,'quiet.py','exec')
write(lab/'quiet.py',launcher)
shutil.copyfile(prior/'summarize.py',lab/'summarize.py')
'''+prepare[end:]
compile(prepare,'prepare.py','exec')
(lab/'prepare.py').write_text(prepare,encoding='utf-8',newline='\n')
shutil.copyfile(prior/'oracle.py',lab/'oracle.py')
