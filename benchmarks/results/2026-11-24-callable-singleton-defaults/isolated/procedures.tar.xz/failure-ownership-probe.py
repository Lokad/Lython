from pathlib import Path
import json
import os
import subprocess

lab = Path(__file__).resolve().parent
sdk = Path.home() / '.dotnet11'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
template = '''def make(seed):
    def first(value=FIRST, /, *, factor=seed%5+1): return value
    second = lambda value=SECOND, /, *, factor=2: value
    return first, second

def run():
    count = 0
    for i in range(ATTEMPTS):
        try: first, second = make(0)
        except ZeroDivisionError: count += 1
    print(count)

run()
'''
cases = [template.replace('FIRST', first).replace('SECOND', second).replace('ATTEMPTS', str(attempts))
         for first, second in [('12//seed', 'seed+23'), ('seed*3', '12//seed')] for attempts in (1, 64)]
for role in ('reference', 'candidate'):
    probe = lab / f'probe-{role}' / 'LythonProbe.dll'
    for mode in ('sync', 'async'):
        mode_args = ['--async'] if mode == 'async' else []
        command = [sdk/'dotnet.exe', probe, '--batch-json', '--compare-python', '--python', 'C:/Python313/python.exe', *mode_args]
        result = subprocess.run(command, input=json.dumps(cases), capture_output=True, text=True, encoding='utf-8', env=env, timeout=40)
        assert result.returncode == 0, (result.stdout, result.stderr)
        rows = [json.loads(line) for line in result.stdout.splitlines()]
        assert len(rows) == len(cases) and all(row['Compared'] and row['Matches'] and row['Lython']['Success'] for row in rows), rows
        name = f'failure-ownership-{role}-{mode}.jsonl'
        (lab/name).write_text(result.stdout, encoding='utf-8', newline='\n')
        print(role, mode, [row['Lython']['PeakExecutionMemoryBytes'] for row in rows])
        limit_cases = [case.replace('range(64)', 'range(256)') for case in cases]
        limit = subprocess.run(command + ['--max-memory-bytes', '96000'], input=json.dumps(limit_cases), capture_output=True,
                               text=True, encoding='utf-8', env=env, timeout=40)
        limited = [json.loads(line) for line in limit.stdout.splitlines()]
        (lab/f'failure-ownership-{role}-{mode}-limited.jsonl').write_text(limit.stdout, encoding='utf-8', newline='\n')
        assert len(limited) == 4, (limit.stdout, limit.stderr)
        assert [row['Lython']['Success'] for row in limited] == [True, True, True, False], limited
        refusal = limited[-1]['Lython']
        assert refusal['DeniedReservationBytes'] > 0 and refusal['Failure']['ExceptionType'] == 'MemoryError', refusal
        print(role, mode, 'refused', refusal['DeniedReservationBytes'])
        route = lab / f'failure-ownership-{role}-{mode}.asm'
        route.unlink(missing_ok=True)
        route_env = dict(env, DOTNET_TieredCompilation='0', DOTNET_JitDisasm='CompleteClosedDefinitionPair',
                         DOTNET_JitStdOutFile=str(route))
        observed = subprocess.run(command, input=json.dumps([cases[3]]), capture_output=True, text=True,
                                  encoding='utf-8', env=route_env, timeout=40)
        assert observed.returncode == 0 and json.loads(observed.stdout)['Matches'], observed.stdout
        assert 'Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:CompleteClosedDefinitionPair' in route.read_text(encoding='utf-8-sig')
