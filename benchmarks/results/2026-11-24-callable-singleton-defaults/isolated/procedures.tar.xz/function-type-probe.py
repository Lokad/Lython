from pathlib import Path
import json
import os
import subprocess

lab = Path(__file__).resolve().parent
sdk = Path.home() / '.dotnet11'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
source = '''def make(seed):
    def first(value=seed*3, /, *, factor=seed%5+1): return value
    second = lambda value=seed+19, /, *, factor=2: value
    return first, second

def run():
    first, second = make(10003)
    print(type(first) is type(second), isinstance(second, type(run)), callable(first), first.__name__, second.__name__)
    hash_before = hash(first)
    table = {first: 'one', second: 'two'}
    first_value, first_tuple = first(), first.__defaults__
    print(hash(first) == hash_before, table[first], table[second], first_value is first_tuple[0])
    second.__defaults__ = first_tuple
    print(second() is first_value, second.__defaults__ is first.__defaults__)
    del first.__defaults__
    try: first()
    except TypeError: print(first.__defaults__, second() is first_value, first_tuple[0] is first_value)

run()
'''
for role in ('reference', 'candidate'):
    probe = lab / f'probe-{role}' / 'LythonProbe.dll'
    for mode in ('sync', 'async'):
        mode_args = ['--async'] if mode == 'async' else []
        command = [sdk/'dotnet.exe', probe, '--batch-json', '--compare-python', '--python', 'C:/Python313/python.exe', *mode_args]
        result = subprocess.run(command, input=json.dumps([source]), capture_output=True, text=True, encoding='utf-8', env=env, timeout=40)
        assert result.returncode == 0, (result.stdout, result.stderr)
        row = json.loads(result.stdout)
        assert row['Compared'] and row['Matches'] and row['Lython']['Success'], row
        name = f'function-type-{role}-{mode}.jsonl'
        (lab/name).write_text(result.stdout, encoding='utf-8', newline='\n')
        print(role, mode, 'matched')
