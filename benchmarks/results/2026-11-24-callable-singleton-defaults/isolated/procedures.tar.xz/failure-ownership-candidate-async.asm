; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:CompleteClosedDefinitionPair(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,long,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]) (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 9 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 72
       xor      eax, eax
       mov      qword ptr [rsp+0x40], rax
       mov      rsi, rcx
       mov      rbx, rdx
       mov      rdi, r8
 
G_M000_IG02:                ;; offset=0x0020
       mov      rbp, bword ptr [r9]
       mov      r14d, dword ptr [r9+0x08]
       lea      r9, [rsp+0x40]
       mov      rcx, rsi
       mov      rdx, rbx
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateClosedPairMember(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,long,byref):Lokad.Lython.Runtime.PyFunctionBase]
       mov      r15, rax
       mov      r13, gword ptr [rsi+0x98]
       mov      ecx, dword ptr [rsp+0x40]
       mov      eax, dword ptr [rsp+0x40]
       inc      eax
       mov      dword ptr [rsp+0x40], eax
       mov      r12d, dword ptr [r13+0x08]
       cmp      ecx, r12d
       jae      G_M000_IG10
       shl      rcx, 5
       mov      rax, gword ptr [r13+rcx+0x10]
       mov      gword ptr [rsp+0x38], rax
       mov      rdx, gword ptr [rbx+0xA0]
       mov      gword ptr [rsp+0x30], rdx
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0089
       mov      rcx, gword ptr [rsp+0x30]
       mov      rdx, gword ptr [rsp+0x38]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG04:                ;; offset=0x0099
       lea      r9, [rsp+0x40]
       mov      rcx, rsi
       mov      rdx, rbx
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateClosedPairMember(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,long,byref):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rsi, rax
       cmp      dword ptr [rsp+0x40], r12d
       jge      SHORT G_M000_IG08
 
G_M000_IG05:                ;; offset=0x00B7
       cmp      dword ptr [rsp+0x40], r12d
       jae      G_M000_IG10
       mov      ecx, dword ptr [rsp+0x40]
       shl      rcx, 5
       mov      rdi, gword ptr [r13+rcx+0x10]
       mov      rax, gword ptr [rbx+0xA0]
       mov      gword ptr [rsp+0x28], rax
       cmp      byte  ptr [rax], al
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x00EA
       mov      rcx, gword ptr [rsp+0x28]
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG07:                ;; offset=0x00F8
       mov      ecx, dword ptr [rsp+0x40]
       inc      ecx
       mov      dword ptr [rsp+0x40], ecx
       cmp      dword ptr [rsp+0x40], r12d
       jl       SHORT G_M000_IG05
 
G_M000_IG08:                ;; offset=0x0109
       cmp      r14d, 1
       jbe      SHORT G_M000_IG10
       lea      rbx, bword ptr [rbp+0x10]
       mov      rcx, rbx
       mov      rdx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rbx+0x08], rcx
       mov      rcx, rbp
       mov      rdx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      eax, eax
       mov      qword ptr [rbp+0x08], rax
 
G_M000_IG09:                ;; offset=0x0135
       add      rsp, 72
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG10:                ;; offset=0x0146
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 332

