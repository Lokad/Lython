#!/bin/bash
set -euo pipefail
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/callable-singleton-defaults-isolated-20261124
cd /mnt/d/code/Lython/.git/agent-notes/review-20261031/callable-singleton-defaults-20261124/source
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
white='Category!=Stress&(FullyQualifiedName~ExecutableDefinitionPair|FullyQualifiedName~ExecutableCall|FullyQualifiedName~FunctionDefault|FullyQualifiedName~ManagedStackGuard)'
public='Category!=Stress&(FullyQualifiedName~NativeDefinitionPair|FullyQualifiedName~NativeReturnFunction|FullyQualifiedName~PreparedFunctionDefaults|FullyQualifiedName~FunctionDefaultMetadata|FullyQualifiedName~SharedExecutionBudget|FullyQualifiedName~CooperativeCancellation)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net11.0 --filter "$white" --artifacts-path "$lab/ubuntu" --nologo > "$lab/ubuntu-white.log" 2>&1 || { tail -45 "$lab/ubuntu-white.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net11.0 --filter "$public" --artifacts-path "$lab/ubuntu" --nologo > "$lab/ubuntu-public.log" 2>&1 || { tail -45 "$lab/ubuntu-public.log"; exit 1; }
awk '/Passed!/{count++;print} END{exit count!=2}' "$lab/ubuntu-white.log" "$lab/ubuntu-public.log"
