from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
comparison=lab/'comparison'
quiet=comparison/'quiet'
isolated='isolated' in lab.name
out=repo/'benchmarks/results/2026-11-24-callable-singleton-defaults'
if isolated:out=out/'isolated'
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
sha=lambda data:hashlib.sha256(data).hexdigest()
digest=lambda path:sha(path.read_bytes())
terminal=read(quiet/'terminal-status.json')
receipt=terminal['receipt']
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode']=='0'
assert receipt['warmJobs']==7 and all(receipt[key] for key in (
    'complete','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert receipt['archiveSHA256']==digest(quiet/'observations.tar.xz')
identity=read(comparison/'identity.json')
summary=read(quiet/'summary.json')
assert summary['source']==identity['sourceRevision'] and summary['candidate']==identity['candidate']
assert summary['timedBatches']==196
assert [(row['case'],row['lane']) for row in summary['rows']]==[tuple(job) for job in read(comparison/'jobs.json')['warm']]
for role,files in identity['imageFiles'].items():
    assert len(files)==32 and {path.name:digest(path) for path in (lab/role).iterdir()}==files
    verified=read(comparison/(role+'-verify.json'))
    assert verified['caseCount']==6 and verified['state']=='Completed'
    assert verified['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert verified['launched']['library']['sha256']==files['Lokad.Lython.dll']
    for mode in ('sync','async'):
        rows=[json.loads(line) for line in (lab/f'oracle-{role}-{mode}.jsonl').read_text(encoding='utf-8').splitlines()]
        assert len(rows)==6 and all(row['Compared'] and row['Matches'] and row['Lython']['Success'] for row in rows)
for platform in ('windows','ubuntu'):
    assert 'Passed:    47' in (lab/(platform+'-white.log')).read_text(encoding='utf-8-sig')
    count='Passed: 206' if platform=='windows' and not isolated else 'Passed:   201'
    assert count in (lab/(platform+'-public.log')).read_text(encoding='utf-8-sig')
patch=subprocess.check_output(['git','diff','--binary',identity['sourceRevision'],identity['candidate'],'--','src','tests'],cwd=repo)
assert patch and patch.count(b'diff --git ')==7
(lab/'measured.patch').write_bytes(patch)
out.mkdir(exist_ok=True)
names=['identity.json','summary.json','terminal-status.json','observations.tar.xz','storage-custody.json']
for name in names:
    path=(comparison if name=='identity.json' else quiet)/name
    shutil.copyfile(path,out/name)
for name in ('allocation-summary-six.json','jit-summary.json', 'compaction.jsonl' if isolated else 'compaction.json'):
    shutil.copyfile(lab/name,out/name)
procedures=['prepare-comparison.py','prepare.py','quiet.py','summarize.py','archive.py','test-ubuntu.sh',
    'oracle.py','oracle-input.json','oracle-reference-sync.jsonl','oracle-reference-async.jsonl',
    'oracle-candidate-sync.jsonl','oracle-candidate-async.jsonl','measured.patch',
    'windows-white.log','windows-public.log','ubuntu-white.log','ubuntu-public.log','windows-frozen-build.log',
    'prepare-allocation.py','inspect-jit.py','candidate-runtime.asm','reference-runtime.asm',
    'comparison/candidate-verify.json','comparison/reference-verify.json',
    'comparison/quiet/collect.py','comparison/quiet/run.sh','comparison/quiet/launch.log']
if isolated:
    procedures+=['compact-archives.py','function-type-probe.py','failure-ownership-probe.py',
                 'failure-ownership-65536.log','failure-ownership-65536.jsonl','failure-ownership.log']
    for role in ('reference','candidate'):
        for mode in ('sync','async'):
            procedures += [f'function-type-{role}-{mode}.jsonl',f'failure-ownership-{role}-{mode}.jsonl',
                           f'failure-ownership-{role}-{mode}-limited.jsonl',f'failure-ownership-{role}-{mode}.asm']
else:procedures+=['compact-b412.py','recover-space.py','recover-space-missing-remote-archive.log',
                  'recover-space-identity.log','launch-first-condition.log','launch-resume-helper.log']
with tarfile.open(out/'procedures.tar.xz','w:xz') as archive:
    for name in procedures:archive.add(lab/name,arcname=name,recursive=False)
with tarfile.open(out/'procedures.tar.xz') as archive:
    assert {member.name:sha(archive.extractfile(member).read()) for member in archive} == {
        name:digest(lab/name) for name in procedures}
print(f'Archived B{1611 if isolated else 1610} with 196 attested batches and exact patch.')
