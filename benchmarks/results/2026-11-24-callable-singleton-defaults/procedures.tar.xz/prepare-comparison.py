from pathlib import Path

lab=Path(__file__).resolve().parent
previous=lab.with_name('closed-line-helper-20261124')
prepare=(previous/'prepare.py').read_text(encoding='utf-8')
prepare=prepare.replace("donor = lab.with_name('closed-capture-pair-seeded-20261124')",
    "donor = lab.with_name('closed-line-helper-20261124')\nseeded = lab.with_name('closed-capture-pair-seeded-20261124')")
prepare=prepare.replace('aa8064b1c','6c4287df3').replace('46c967257','fd1d8fce4')
start=prepare.index("for host in ('windows','ubuntu'):"); end=prepare.index('core = lab',start)
prepare=prepare[:start]+'''assert 'Passed:    47' in (lab/'windows-white.log').read_text(encoding='utf-8-sig')
assert 'Passed:    47' in (lab/'ubuntu-white.log').read_text(encoding='utf-8-sig')
assert 'Passed: 206' in (lab/'windows-public.log').read_text(encoding='utf-8-sig')
assert 'Passed:   201' in (lab/'ubuntu-public.log').read_text(encoding='utf-8-sig')
'''+prepare[end:]
start=prepare.index("catalog=read(donor/"); end=prepare.index('identity = dict(',start)
prepare=prepare[:start]+'''shutil.copyfile(seeded/'comparison/representative.json', comparison/'representative.json')
assert digest(comparison/'representative.json')==read(seeded/'comparison/identity.json')['catalogs']['representative.json']['sha256']
jobs=read(seeded/'comparison/jobs.json')
assert len(jobs['warm'])==7
jobs['warm'][-1]=['scripts.rule-default-closures','compile-run']
save(comparison/'jobs.json',jobs)
'''+prepare[end:]
prepare=prepare.replace('Complete the cased text helper and any proved length update without a native workspace',
    'Keep fully admitted singleton positional defaults on the closed pair callable until metadata observation')
prepare=prepare.replace('closed-line-helper-b1608-20261124','callable-singleton-defaults-b1610-20261124')
prepare=prepare.replace("reference='closed-capture-seeded-b1603-20261124'", "reference='closed-line-helper-b1608-20261124'")
prepare=prepare.replace('lython-b1608-closed-line-helper','lython-b1610-callable-singleton-defaults')
prepare=prepare.replace("'b1608-'","'b1610-'").replace('b1608-fixtures','b1610-fixtures')
prepare=prepare.replace("sources=read(donor/'verified-raw-replicas.json')", "sources=read(seeded/'verified-raw-replicas.json')")
compile(prepare,'prepare.py','exec')
(lab/'prepare.py').write_text(prepare,encoding='utf-8',newline='\n')
