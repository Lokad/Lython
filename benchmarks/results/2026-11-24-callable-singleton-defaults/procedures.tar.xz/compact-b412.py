from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
evidence=repo/'benchmarks/results/2026-11-07-json-input-windows/b412'
archive=evidence/'observations.tgz'
sha=lambda data:hashlib.sha256(data).hexdigest()
terminal=json.loads((evidence/'terminal-status.json').read_text(encoding='utf-8'))
receipt=terminal['receipt']
assert terminal['exitCode']=='0' and not terminal['remainingFixtures'] and not terminal['remainingWorkers']
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['archivedAndVerifiedUnderLease']
assert sha(archive.read_bytes())==receipt['archiveSHA256']
assert sha(subprocess.check_output(['git','show','origin/master:'+archive.relative_to(repo).as_posix()],cwd=repo))==receipt['archiveSHA256']
with tarfile.open(archive) as packed:
    expected=json.load(packed.extractfile('identity.json'))['coreSHA256']['reference']
assert sha((lab.with_name('json-input-storage-r54')/'b412/before-core.dll').read_bytes())==expected
source='expected='+repr(expected)+'\narchive_digest='+repr(receipt['archiveSHA256'])+'\n'+'''
from pathlib import Path
import fcntl, hashlib, json, lzma, os, shutil, stat, subprocess
root=Path('/home/lokad/lython-bench-checks').resolve()
archive=root/'json-input-storage-b412-20261107'
raw=archive/'reference/Lokad.Lython.dll'
stored=archive/'reference-core.dll.xz'
sha=lambda data:hashlib.sha256(data).hexdigest()
with (root/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert archive.resolve()==archive and raw.resolve()==raw and raw.is_relative_to(archive)
    assert (archive/'exit-code.txt').read_text().strip()=='0' and not (archive/'guest-fixtures').exists()
    receipt=json.loads((archive/'archive-receipt.json').read_text())
    assert receipt['archiveSHA256']==archive_digest and receipt['complete'] and receipt['allWorkersJoined']
    assert subprocess.run(['pgrep','-af',str(archive)],capture_output=True).returncode==1
    assert stat.S_ISREG(raw.lstat().st_mode) and raw.stat().st_nlink==1
    data=raw.read_bytes(); assert sha(data)==expected
    encoded=lzma.compress(data,preset=3)
    free=shutil.disk_usage(root).free
    assert free>=len(encoded)+1048576
    with stored.open('xb') as output:
        output.write(encoded)
        output.flush()
        os.fsync(output.fileno())
    assert lzma.decompress(stored.read_bytes())==data
    raw.unlink()
    print(json.dumps(dict(freeBefore=free,freeAfter=shutil.disk_usage(root).free,
          coreSHA256=expected,archiveSHA256=archive_digest,compressedSHA256=sha(encoded),stored=str(stored.relative_to(root)))))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),
     '-o','BatchMode=yes','-o','ConnectTimeout=14','lokad@20.166.121.73','python3 -']
result=subprocess.run(ssh,input=source.encode('utf-8'),capture_output=True,timeout=50)
(lab/'compaction.json').write_bytes(result.stdout)
if result.returncode:print(result.stderr.decode(),end='')
result.check_returncode()
print(result.stdout.decode(),end='')
