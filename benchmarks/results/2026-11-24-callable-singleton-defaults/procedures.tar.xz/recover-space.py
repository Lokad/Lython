from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
results=repo/'benchmarks/results'
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
def receipt(path):
    data=read(path/'archive-receipt.json')
    assert data['complete'] and data['allWorkersJoined'] and data['archivedAndVerifiedUnderLease']
    archive=path/'observations.tgz'
    assert sha(archive.read_bytes())==data['archiveSHA256']
    tracked=subprocess.check_output(['git','show','origin/master:'+archive.relative_to(repo).as_posix()],cwd=repo)
    assert sha(tracked)==data['archiveSHA256']
    return data['archiveSHA256']
old=results/'2026-11-07-retained-checkpoint'
profile=results/'2026-11-07-report-execution-cost'
input_windows=results/'2026-11-07-json-input-windows/b412'
same_core=read(old/'identity.json')['coreSHA256']['candidate']
assert same_core==read(lab.with_name('report-cost-r52')/'identity.json')['files']['Lokad.Lython.dll']
with tarfile.open(input_windows/'observations.tgz') as archive:
    data=json.load(archive.extractfile('identity.json'))
old_reference=data['coreSHA256']['reference']
assert sha((lab.with_name('json-input-storage-r54')/'b412/before-core.dll').read_bytes())==old_reference
previous={
    'retained-cpython-b409-20261107':receipt(old),
    'report-cost-b410-20261107':receipt(profile),
    'json-input-storage-b412-20261107':receipt(input_windows),
}
remote='checks='+repr(previous)+'\nsame_core='+repr(same_core)+'\nold_reference='+repr(old_reference)+'\n'+'''
from pathlib import Path
import fcntl, hashlib, json, lzma, os, shutil, stat, subprocess
root=Path('/home/lokad/lython-bench-checks').resolve()
sha=lambda data:hashlib.sha256(data).hexdigest()
def core(directory,role,expected):
    run=root/directory
    assert run.resolve()==run and run.parent==root
    assert not (run/'guest-fixtures').exists()
    receipt=json.loads((run/'archive-receipt.json').read_text())
    assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['archivedAndVerifiedUnderLease']
    assert receipt['archiveSHA256']==checks[directory]
    archive=run/'observations.tgz'
    if archive.is_file(): assert sha(archive.read_bytes())==checks[directory]
    assert subprocess.run(['pgrep','-af',str(run)],capture_output=True).returncode==1
    path=run/role/'Lokad.Lython.dll'
    assert path.resolve()==path and stat.S_ISREG(path.lstat().st_mode)
    assert sha(path.read_bytes())==expected
    return path
with (root/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    before=shutil.disk_usage(root).free
    print(json.dumps(dict(freeBefore=before)),flush=True)
    a=core('retained-cpython-b409-20261107','candidate',same_core)
    b=core('report-cost-b410-20261107','candidate',same_core)
    if a.stat().st_ino!=b.stat().st_ino:
        info_a,info_b=a.stat(),b.stat()
        assert info_a.st_nlink==1 and (info_a.st_mode,info_a.st_uid,info_a.st_gid)==(info_b.st_mode,info_b.st_uid,info_b.st_gid)
        link=a.with_name('verified-core.link')
        os.link(b,link)
        try:os.replace(link,a)
        finally:link.unlink(missing_ok=True)
        assert sha(a.read_bytes())==same_core
        print(json.dumps(dict(deduplicated=str(a.relative_to(root)),source=str(b.relative_to(root)),
            sha256=same_core,freeAfter=shutil.disk_usage(root).free)),flush=True)
    if shutil.disk_usage(root).free<12582912:
        old=core('json-input-storage-b412-20261107','reference',old_reference)
        assert old.stat().st_nlink==1
        data=old.read_bytes()
        encoded=lzma.compress(data,preset=3)
        assert shutil.disk_usage(root).free>=len(encoded)+1048576
        stored=old.parent.parent/'reference-core.dll.xz'
        with stored.open('xb') as package:
            package.write(encoded)
            package.flush()
            os.fsync(package.fileno())
        assert lzma.decompress(stored.read_bytes())==data
        old.unlink()
        print(json.dumps(dict(compressed=str(stored.relative_to(root)),coreSHA256=old_reference,
            compressedSHA256=sha(encoded),storedBytes=len(encoded),freeAfter=shutil.disk_usage(root).free)),flush=True)
    assert shutil.disk_usage(root).free>=11534336
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),
     '-o','BatchMode=yes','-o','ConnectTimeout=14','lokad@20.166.121.73','python3 -']
result=subprocess.run(ssh,input=remote.encode('utf-8'),capture_output=True,timeout=55)
(lab/'space-recovery.jsonl').write_bytes(result.stdout)
print(result.stdout.decode(),end='')
if result.returncode: print(result.stderr.decode(),end='')
result.check_returncode()
