from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
config={'payloadBytes': 3776756, 'payloadSHA256': '74caa3e236730b2fe900f18578c2ac3321897a385c2ffe8ade6ff11fdc066f87', 'required': 276713472, 'coresToRetire': [{'knownPath': 'bound-borrow-b564-20261110/candidate/Lokad.Lython.dll', 'canonical': 'benchmarks/results/2026-11-10-bound-native-arguments/quiet/observations.tgz', 'member': 'current-core.dll', 'bytes': 5665792, 'sha256': '2f9b100e5411f9e0580a65160088b45117593965e3586d0f1dee3ec5492c6561'}], 'expectedCores': {'reference': 'c27160d53d66489976b181fb425b2f46c927fa85156433b80dc6f5477a3e5506', 'reference-control': 'c27160d53d66489976b181fb425b2f46c927fa85156433b80dc6f5477a3e5506', 'candidate': '6e7e9ada556d68be1b58aa04c0a93814d45214b063e72e4199e39bad1969ee9f', 'candidate-control': '6e7e9ada556d68be1b58aa04c0a93814d45214b063e72e4199e39bad1969ee9f'}, 'exactCopies': [{'path': 'bound-borrow-b564-20261110/observations.tgz', 'canonical': 'benchmarks/results/2026-11-10-bound-native-arguments/quiet/observations.tgz', 'bytes': 3804031, 'sha256': '47bc3643bbb6ea2d38fd43fdb8d5c7f86b75727396e1a27db67c6eaee5868a3b'}, {'path': 'bound-calls-b563-20261110/observations.tgz', 'canonical': 'benchmarks/results/2026-11-10-bound-native-arguments/profile/observations.tgz', 'bytes': 2166797, 'sha256': 'df094555fc51ffe60a839b3fb8cdc521d7e577f4ebee51e473f452434bf4178b'}, {'path': 'bound-calls-b563-20261110/profiles/class-report-warm/perf.map', 'canonical': 'benchmarks/results/2026-11-10-bound-native-arguments/profile/observations.tgz', 'member': 'profiles/class-report-warm/perf.map', 'bytes': 1489214, 'sha256': '5e47da1205f2049bafeef2995e6c0c9036a91df072e366e24cf936a860b9000a'}, {'path': 'bound-calls-b563-20261110/profiles/class-report-warm/perf-stacks.txt', 'canonical': 'benchmarks/results/2026-11-10-bound-native-arguments/profile/observations.tgz', 'member': 'profiles/class-report-warm/perf-stacks.txt', 'bytes': 749482, 'sha256': 'a19da37bc2e2999435142e7bfe60b1a440fdb22b207ed766bc5a059203298005'}, {'path': 'bound-calls-b563-20261110/profiles/class-report-warm/perf-leaves.txt', 'canonical': 'benchmarks/results/2026-11-10-bound-native-arguments/profile/observations.tgz', 'member': 'profiles/class-report-warm/perf-leaves.txt', 'bytes': 56489, 'sha256': 'ae1e5bc7db8b5b2eee4bf6d76bba48af2673158477ebfc7a6d5960df887ecc78'}, {'path': 'bound-calls-b563-20261110/profiles/class-report-warm/perf.data', 'canonical': 'benchmarks/results/2026-11-10-bound-native-arguments/profile/observations.tgz', 'member': 'profiles/class-report-warm/perf.data', 'bytes': 333680, 'sha256': '37ab0b40c5c3e47bd46218f0401a1d5c9a52b0a0a7cf49abed5dc2a3ddcc31f0'}, {'path': 'bound-borrow-b564-20261110/confirmation/confirmation.json', 'canonical': 'benchmarks/results/2026-11-10-bound-native-arguments/quiet/observations.tgz', 'member': 'confirmation/confirmation.json', 'bytes': 188640, 'sha256': '90f856fa37b534fd452833a9ce97b727eefbc86b80b23038337d04391370d2b8'}]}
base=Path('/home/lokad/lython-bench-checks').resolve();root=base/'json-string-b565-20261111';source=base/'construction-cpython-b561-20261110/candidate';fixture=root/'guest-fixtures'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists()and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[c]omplete-jobs.dll'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(config['payloadBytes']+1);assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:
  for name,role in [('baseline-core.dll','reference'),('current-core.dll','candidate')]:
   assert hashlib.sha256(a.extractfile(name).read()).hexdigest()==config['expectedCores'][role]
 assert hashlib.sha256((source/'Lokad.Lython.dll').read_bytes()).hexdigest()=='0e2bc55bac5ebfafd9d30014e34e2afb3e9776bbe6b5d83a53cc710c0d99c492'
 stable=source/'Lokad.Lython.dll'
 assert hashlib.sha256(stable.read_bytes()).hexdigest()=='0e2bc55bac5ebfafd9d30014e34e2afb3e9776bbe6b5d83a53cc710c0d99c492'
 protocol=base/'prepared-call-layout-b384-20261107/cpython-worker.py'
 assert hashlib.sha256(protocol.read_bytes()).hexdigest()=='02ca606af6b937a5bec8da744da36e6dbea45ef14ee7207732f34da052ad32f1'
 before=shutil.disk_usage(base).free;retired=[];reclaim=0
 if before<=config['required']:
  for proof in config['coresToRetire']:
   firstPath=base/proof['knownPath'];first=firstPath.lstat();key=(first.st_dev,first.st_ino)
   assert first.st_size==proof['bytes']and hashlib.sha256(firstPath.read_bytes()).hexdigest()==proof['sha256']
   aliases=[]
   for folder,dirs,files in os.walk(base):
    for name in files:
     path=Path(folder)/name;st=path.lstat()
     if(st.st_dev,st.st_ino)!=key:continue
     assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(st.st_mode)and st.st_uid==os.getuid()
     aliases.append(path.relative_to(base).as_posix())
   assert len(aliases)==first.st_nlink and aliases and proof['knownPath']in aliases
   assert proof['sha256']not in[config['expectedCores']['reference'],'0e2bc55bac5ebfafd9d30014e34e2afb3e9776bbe6b5d83a53cc710c0d99c492']
   reclaim+=first.st_blocks*512;retired.append(dict(proof,paths=aliases,allocatedBytes=first.st_blocks*512,allHardlinkAliasesVerified=True))
  for exact in config['exactCopies']:
   path=base/exact['path'];st=path.lstat()
   assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(st.st_mode)and st.st_uid==os.getuid()and st.st_nlink==1
   assert st.st_size==exact['bytes']and hashlib.sha256(path.read_bytes()).hexdigest()==exact['sha256']
   reclaim+=st.st_blocks*512;retired.append(dict(exact,paths=[exact['path']],allocatedBytes=st.st_blocks*512,allHardlinkAliasesVerified=True))
  assert before+reclaim>config['required'],(before,reclaim,config['required'])
  for proof in retired:
   for path in proof['paths']:(base/path).unlink()
 assert hashlib.sha256(stable.read_bytes()).hexdigest()=='0e2bc55bac5ebfafd9d30014e34e2afb3e9776bbe6b5d83a53cc710c0d99c492'
 assert hashlib.sha256((source/'Lokad.Lython.dll').read_bytes()).hexdigest()=='0e2bc55bac5ebfafd9d30014e34e2afb3e9776bbe6b5d83a53cc710c0d99c492'
 assert shutil.disk_usage(base).free>config['required']
 beforeExtractionFreeBytes=shutil.disk_usage(base).free
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:root.mkdir();a.extractall(root,filter='data')
 recovery=dict(beforeFreeBytes=before,afterRecoveryFreeBytes=beforeExtractionFreeBytes,postExtractionFreeBytes=shutil.disk_usage(base).free,requiredFreeBytes=config['required'],freshIdleLease=True,verifiedReplacementInPayload=True,files=retired,osFloorMiB=240,evidenceHeadroomMiB=12,fullyQualified0ePreserved=True)
 (root/'space-recovery.json').write_text(json.dumps(recovery,indent=2)+'\n')
 shutil.copyfile(protocol,root/'cpython-worker.py')
 for role in ['reference','candidate']:
  shutil.copytree(source,root/role,copy_function=os.link)
  (root/role/'Lokad.Lython.dll').unlink();os.link(root/('baseline-core.dll'if role=='reference'else'current-core.dll'),root/role/'Lokad.Lython.dll')
 identity=json.loads((root/'identity.json').read_text())
 for role in ['reference','candidate']:
  for name,digest in{**identity['auxiliaryFiles'],'Lokad.Lython.dll':identity['coreSHA256'][role]}.items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==digest,(role,name)
 assert hashlib.sha256((root/'representative.json').read_bytes()).hexdigest()==identity['catalogSHA256']
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b565-fixtures',str(fixture)],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,imagesVerified=True,jobs=3,ownerSeconds=150,stopSeconds=30,marginSeconds=30,osFloorMiB=240,evidenceHeadroomMiB=12)
 assert setup['freeBytes']>252*1024*1024
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
try:
 subprocess.run(['sudo','-n','systemd-run','--unit=lython-b565-json-string-20261111','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=150','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show','lython-b565-json-string-20261111.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert'ActiveState=active'in live and'MainPID=0'not in live;print(live,flush=True)
