from pathlib import Path

root=Path(__file__).resolve().parent;repo=Path('D:/code/Lython')
p=repo/'src/Lokad.Lython/Runtime/LythonRuntime.Json.Deserialize.cs'
s=p.read_text(encoding='utf-8')
a=s.index('        private static (PyString Value, int End) ReadJsonString(')
b=s.index('        // Keys share the enclosing decoder admission',a)
s=s[:a]+(root/'decoder.txt').read_text(encoding='utf-8')+s[b:]
for name in ['text','document']:
    old='''            catch (JsonException ex)
            {
                throw CreateJsonDecodeError('''+name+''', ex, span, context);
            }
'''
    assert s.count(old)==1
    s=s.replace(old,'')
s=s.replace('using System.Text.Json;\n','')
p.write_text(s,encoding='utf-8',newline='\n')
p=repo/'src/Lokad.Lython/Runtime/LythonRuntime.Json.Options.cs';s=p.read_text(encoding='utf-8')
a=s.index('        private static LythonRuntimeException CreateJsonDecodeError(')
b=s.index('        // Builds the catchable JSONDecodeError',a)
s=s[:a]+s[b:]
a=s.index('        private static int ComputeJsonErrorBytePosition(')
b=s.index('        private static JsonSourceLocation ComputeJsonErrorLocation(',a)
s=s[:a]+s[b:]
for name in ['IsAsciiLetter','IsJsonNumberTokenByte']:
    a=s.index('        private static bool '+name+'(')
    b=s.index('\n\n',a)+2
    s=s[:a]+s[b:]
s=s.replace('using System.Text.Json;\n','')
s=s.replace('// for an explicit message and parse-space byte position: used both for\n        // backend errors above and for positions the core detects itself\n        // (truncation, trailing data, strict violations, index bounds). Positions\n        // always refer to the original document; token-local backend errors\n        // are translated before reaching this shared payload builder.', '// for an explicit message and original-document byte position. Token scans,\n        // truncation, trailing data, strict violations and index bounds all use\n        // the same original UTF-8 coordinates; no backend remapping is needed.')
p.write_text(s,encoding='utf-8',newline='\n')
print('Replaced complete JSON string backend phase and removed orphaned error machinery.')
