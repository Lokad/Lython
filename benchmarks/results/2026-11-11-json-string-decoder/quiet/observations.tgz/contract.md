# R217 complete JSON string decoder — quiet confirmation

Three existing complete file-backed workloads: plain report, the identical report
with Python-default escaped Unicode input, and unchanged ordinary text control.
Fresh b8b05ccc/qualified696 reference versus JSON-only candidate; four independent
source roles,5s warmup,7rotated400msrounds,normalGC/tiering. Warm sync only; desktop
async/compile/allocation and every adverse result remain separate. No fixed gain
threshold; decide retain/refine/withdraw from simplification, semantics and debt.
150s owner/30stop/30margin. Full mediated RAM I/O, per-invocation output validation
and prior-result cleanup included; compile/reset/separate verification/protocol/
startup/final cached teardown excluded. No CPython or embedding-tail claim.
