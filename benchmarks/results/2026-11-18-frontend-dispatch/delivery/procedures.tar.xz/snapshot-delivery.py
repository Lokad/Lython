from pathlib import Path
import datetime,hashlib,io,json,re,subprocess,tarfile

notes=Path(__file__).parent;root=Path('D:/code/Lython');delivery=notes/'delivery'
assert delivery.is_dir()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True).strip()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head=='925397f650b61c8a7578a3466d53d00a23bee846'
assert subprocess.check_output(['git','rev-parse','origin/master'],cwd=root,text=True).strip()==head
old=json.loads((notes.parent/'entry-result-routing-r518/delivery/inputs.json').read_text(encoding='utf-8'))
names=sorted(n.replace('Frontend/StaticAbstractInterpreter.ExpressionAnalyzers.cs','Frontend/StaticAbstractInterpreter.ExpressionChecks.cs')for n in old['inputs'])
assert len(names)==2390
batch=subprocess.check_output(['git','cat-file','--batch'],cwd=root,input=''.join('HEAD:'+name+'\n'for name in names).encode('utf-8'))
offset=0;inputs={};contents={}
for name in names:
    end=batch.index(b'\n',offset);header=batch[offset:end].decode('ascii').split();assert header[1]=='blob'
    size=int(header[2]);data=batch[end+1:end+1+size];assert len(data)==size and batch[end+1+size:end+2+size]==b'\n'
    offset=end+2+size;inputs[name]=hashlib.sha256(data).hexdigest();contents[name]=data
    working=(root/name).read_bytes()
    # Fixtures include intentionally binary/non-UTF8 sources. Compare those
    # exactly; normalize only differing text line endings in this Windows tree.
    assert working==data or working.decode('utf-8-sig').replace('\r\n','\n')==data.decode('utf-8-sig').replace('\r\n','\n'),name
assert offset==len(batch)
production=[name for name in names if name.startswith('src/Lokad.Lython/')];assert len(production)==587
assert delivery.is_dir()
with tarfile.open(delivery/'inputs.tar.xz','w:xz')as archive:
    for name,data in contents.items():
        entry=tarfile.TarInfo(name);entry.size=len(data);entry.mode=0o644;archive.addfile(entry,io.BytesIO(data))
(delivery/'inputs.json').write_text(json.dumps(dict(head=head,count=len(inputs),production=len(production),
    boundary='Exact committed Git blob bytes, matching current working text; direct abstract validation dispatch delivery, no frozen performance equality inferred.',
    inputs=inputs),indent=2)+'\n',encoding='utf-8',newline='\n')
print("Recorded2390 exact committed inputs/587production files for dispatched925397f65; no second dispatch.")
