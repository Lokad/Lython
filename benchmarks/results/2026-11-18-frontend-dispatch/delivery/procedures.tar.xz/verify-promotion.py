from pathlib import Path
import json,tarfile
r=Path(__file__).parent;repo=Path('D:/code/Lython');count=0;endings=[]
with tarfile.open(r/'candidate-sources.tar.xz')as t:
 for m in t.getmembers():
  if not m.isfile()or not m.name.startswith('src/Lokad.Lython/'):continue
  expected=t.extractfile(m).read();actual=(repo/m.name).read_bytes()
  assert actual.replace(b'\r\n',b'\n')==expected.replace(b'\r\n',b'\n'),m.name
  if actual!=expected:endings.append(m.name)
  count+=1
assert count==587,count
v=dict(productionInputsVerified=count,lineEndingOnlyDifferences=endings,
    measuredCore='2c6b304be4c81e2c70d4b0e0e89b71fb26e33521a561405255b939c2716d8226',
    boundary='Main production source matches frozen measured source with only CRLF normalization; no rebuilt binary equality or inherited full qualification implied.')
(r/'promoted-source.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
print('Main matches all587 measured production inputs;',len(endings),'line-ending-only differences.')
