from pathlib import Path
import datetime,json,subprocess
r=Path(__file__).parent/'delivery';r.mkdir(exist_ok=False)
repo=Path('D:/code/Lython');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head.startswith('925397f65'),head
p=subprocess.run(['C:/Program Files/GitHub CLI/gh.exe','workflow','run','ci.yml','--ref','master','-f','stress=true'],cwd=repo,capture_output=True,text=True,encoding='utf-8',timeout=60)
(r/'dispatch.log').write_text(p.stdout+p.stderr,encoding='utf-8');assert p.returncode==0,p.stdout+p.stderr
now=datetime.datetime.now(datetime.timezone.utc)
v=dict(head=head,workflow='ci.yml',stress=True,recordedAtUTC=now.isoformat(),
    doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=240)).isoformat(),
    expectedEachPlatformTarget=dict(ordinaryInternal=4863,ordinaryPublic=18052,stressInternal=14,stressPublic=406),
    publicationHeld=True,measuredCore='2c6b304be4c81e2c70d4b0e0e89b71fb26e33521a561405255b939c2716d8226')
(r/'dispatch.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
print(p.stdout,p.stderr);print('One full Windows/Ubuntu actual11/10, original stress and installed Release package delivery dispatched; no status observation before240seconds.')
