from pathlib import Path
import datetime,json,re,subprocess
r=Path(__file__).parent/'delivery';terminal=r/'terminal.json'
if terminal.exists():
 print('Terminal CI result already cached; no API request.');raise SystemExit(0)
d=json.loads((r/'dispatch.json').read_text(encoding='utf-8'));now=datetime.datetime.now(datetime.timezone.utc)
bound=datetime.datetime.fromisoformat(d['doNotObserveBeforeUTC'])
if(r/'next-observation.json').exists():bound=max(bound,datetime.datetime.fromisoformat(json.loads((r/'next-observation.json').read_text(encoding='utf-8'))['notBeforeUTC']))
assert now>=bound,(now,bound)
run=int(re.search(r'/runs/(\d+)',(r/'dispatch.log').read_text(encoding='utf-8')).group(1))
p=subprocess.run(['C:/Program Files/GitHub CLI/gh.exe','run','view',str(run),'--json','status,conclusion,headSha,jobs,url'],cwd='D:/code/Lython',capture_output=True,text=True,encoding='utf-8',timeout=60)
assert p.returncode==0,p.stderr
v=json.loads(p.stdout);assert v['headSha']==d['head'],v['headSha']
(r/('observation-'+now.strftime('%Y%m%dT%H%M%SZ')+'.json')).write_text(p.stdout,encoding='utf-8')
(r/'next-observation.json').write_text(json.dumps(dict(notBeforeUTC=(now+datetime.timedelta(seconds=240)).isoformat()),indent=2)+'\n',encoding='utf-8')
d.update(run=run,url=v['url']);(r/'dispatch.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
if v['status']=='completed':terminal.write_text(p.stdout,encoding='utf-8')
print(json.dumps(dict(run=run,status=v['status'],conclusion=v['conclusion'],jobs=[dict(name=j['name'],status=j['status'],conclusion=j['conclusion'])for j in v['jobs']]),indent=2))
