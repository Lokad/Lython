from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).parent;d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy()
env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
with(r/'ir-build.log').open('w',encoding='utf-8')as log:
 p=subprocess.run([str(d),'build',str(r/'ir-inspect/inspect.csproj'),'-c','Release','--no-incremental',
    '-p:InspectionCorePath='+str(r/'frozen/reference/Lokad.Lython.dll')],cwd='D:/code/Lython',env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert p.returncode==0,(r/'ir-build.log').read_text(encoding='utf-8')
identity=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));values={}
for role in ['reference','candidate']:
 image=r/('ir-'+role);shutil.copytree(r/'ir-inspect/bin/Release/net11.0',image)
 shutil.copyfile(r/'frozen'/role/'Lokad.Lython.dll',image/'Lokad.Lython.dll')
 with(r/(role+'-ir.log')).open('w',encoding='utf-8')as log:
  p=subprocess.run([str(d),str(image/'Lokad.Lython.WhiteBox.Tests.dll'),str(r/'catalog.json'),str(r/(role+'-ir.json'))],cwd='D:/code/Lython',env=env,stdout=log,stderr=subprocess.STDOUT,timeout=60)
 assert p.returncode==0,(r/(role+'-ir.log')).read_text(encoding='utf-8')
 v=json.loads((r/(role+'-ir.json')).read_text(encoding='utf-8-sig'))
 assert v['CoreSha256']==identity['imageFiles'][role]['Lokad.Lython.dll']and len(v['Workloads'])==13
 values[role]=v
mismatches=[a['Id']for a,b in zip(values['reference']['Workloads'],values['candidate']['Workloads'])if a!=b]
report=dict(passed=not mismatches,cases=13,changedWorkloads=mismatches,
    coreSHA256={role:values[role]['CoreSha256']for role in values},
    boundary='Existing exact-IR diagnostic: compared emitted code/instructions/storage/name/global-location and receiver-definition facts from each actual frozen core. No guest execution, CPU measurement or proof beyond these representative valid scripts.')
(r/'ir-comparison.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
assert not mismatches,report
print(json.dumps(report),flush=True)
