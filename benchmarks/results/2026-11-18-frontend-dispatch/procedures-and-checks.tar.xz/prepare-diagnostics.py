from pathlib import Path
import shutil
r=Path(__file__).parent;old=r.parent/'prepared-names-r525';project=r/'compile-allocation';project.mkdir(exist_ok=False)
for name in ['compile-allocation.csproj','Program.cs']:shutil.copyfile(old/'compile-allocation'/name,project/name)
p=project/'Program.cs';s=p.read_text(encoding='utf-8')
assert 'or "calls.positional.large"))'in s
s=s.replace('or "calls.positional.large"))','or "calls.positional.large" or "scripts.csv-invoice.large"))')
p.write_text(s,encoding='utf-8',newline='\n')
s=(old/'run-compile-allocation.py').read_text(encoding='utf-8').replace("len(v['rows'])==4","len(v['rows'])==5")
(r/'run-compile-allocation.py').write_text(s,encoding='utf-8',newline='\n')
project=r/'ir-inspect';project.mkdir(exist_ok=False)
for name in ['inspect.csproj','Program.cs']:shutil.copyfile(r.parent/'name-preparation-r524/inspect'/name,project/name)
print('Existing allocation and exact-IR diagnostics reused; no production hooks or new framework.')
