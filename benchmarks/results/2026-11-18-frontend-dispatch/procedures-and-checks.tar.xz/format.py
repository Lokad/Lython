from pathlib import Path
r=Path('D:/code/Lython/.git/agent-worktrees/prepared-names-r525/src/Lokad.Lython/Frontend')
for p in r.glob('StaticAbstractInterpreter*.cs'):
    s=p.read_text(encoding='utf-8')
    s=s.replace('namespace Lokad.Lython.Frontend;\ninternal', 'namespace Lokad.Lython.Frontend;\n\ninternal')
    lines=[]
    for line in s.splitlines():
        if line.startswith('    private static ')and len(line)>100 and line.endswith(')'):
            head,tail=line.split('(',1)
            parameters=tail[:-1].split(', ')
            assert all('<'not in v or v.count('<')==v.count('>')for v in parameters),line
            lines.append(head+'(')
            lines.extend('        '+p+(','if i+1<len(parameters)else')')for i,p in enumerate(parameters))
        else:lines.append(line)
    p.write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n')
print('Restored namespace spacing and readable semantic-helper signatures; no production code generator or dependency added.')
