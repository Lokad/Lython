from pathlib import Path
r=Path(__file__).parent
s=(r.parent/'prepared-names-r525/freeze.py').read_text(encoding='utf-8')
s=s.replace("names=list(base['sourceInputs']);", "names=[n.replace('Frontend/StaticAbstractInterpreter.ExpressionAnalyzers.cs','Frontend/StaticAbstractInterpreter.ExpressionChecks.cs') for n in base['sourceInputs']];")
s=s.replace("['git','diff','HEAD','--name-only']", "['git','diff','HEAD','--no-renames','--name-only']")
s=s.replace('assert len(production)==13,production','assert len(production)==5,production')
a=s.index('identity=dict(');b=s.index("(frozen/'identity.json')",a)
s=s[:a]+'''identity=dict(referenceSource='Fully qualified3f873227/frozena5038a28 GREEN44256409242 cached',
    candidateSource='Private R527 direct abstract statement/expression syntax selection. Delete two private interfaces/arrays, seven singleton families and boolean refusal. Preserve semantic bodies/binding updates; capturing local helpers become explicit static calls. Four logical frontend files including ExpressionAnalyzers-to-ExpressionChecks rename. Both actual11/10 pass106internal/564public focused, including shared compiler facts/diagnostics/scopes/short-circuit/regex analysis/cancellation/refusal/ownership. Source audit preserves all other semantic invocation targets/counts and diagnostic text; no new production framework/cache/policy/option/dependency or predicted CPU gain.',
    imageFiles=images,sourceInputs=hashes,sourceInputsArchiveSHA256=sha(r/'candidate-sources.tar.xz'),productionFiles=587,
    changedProductionFiles=production,normalAdapterPin='0.4.0',publicationHeld=True)
''' +s[b:]
(r/'freeze.py').write_text(s,encoding='utf-8',newline='\n')
print('Existing freeze/golden/reuse diagnostic reused; retained source path map follows the one frontend rename.')
