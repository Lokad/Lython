from pathlib import Path
r=Path(__file__).parent
s=(r.parent/'prepared-names-r525/prepare-quiet.py').read_text(encoding='utf-8')
a=s.index('subjects=[]');b=s.index('\ntemplate=',a)
s=s[:a]+'''subjects=[]
canonical='benchmarks/results/2026-11-18-prepared-name-pool/candidate-core.dll.gz'
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();data=gzip.decompress(blob)
assert hashlib.sha256(data).hexdigest()=='f96cd8a99ed882759b3c5ca0887bd07a3d6125bedf85f9995b617e3c54e0a8db'
subjects.append(dict(kind='withdrawn-prototype-core',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='gzip-payload',committedBlobVerified=True,knownPath='prepared-names-b956-20261118/candidate/Lokad.Lython.dll'))
for canonical,folder,raw,whole in [
 ('benchmarks/results/2026-11-18-prepared-name-pool/observations.tgz','prepared-names-b956-20261118',True,True),
 ('benchmarks/results/2026-11-18-prepared-module-bindings/initial/observations.tgz','module-bindings-b949-20261118',True,False),
 ('benchmarks/results/2026-11-18-prepared-module-bindings/confirmation/observations.tgz','module-bindings-confirm-b951-20261118',True,False),
 ('benchmarks/results/2026-11-18-bindings-cpython-checkpoint/observations.tgz','bindings-cpython-b952-20261118',False,True),
 ('benchmarks/results/2026-11-18-native-index-context/confirmation/observations.tgz','native-index-confirm-b955-20261118',True,True)]:
 blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();member='confirmation/confirmation.json'
 if raw:
  with tarfile.open(fileobj=io.BytesIO(blob))as a:data=a.extractfile(member).read()
  subjects.append(dict(kind='archived-raw-observation-replica',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True,knownPath=folder+'/'+member))
 if whole:
  subjects.append(dict(kind='archived-whole-observation-replica',sha256=hashlib.sha256(blob).hexdigest(),bytes=len(blob),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='whole-file',committedBlobVerified=True,knownPath=folder+'/observations.tgz'))
''' + s[b:]
a=s.index('identity=dict(');b=s.index("(q/'identity.json')",a)
s=s[:a]+'''identity=dict(sourceRevision='Qualified3f873227/frozena5038a28 GREEN44256409242 versus privateR527/2c6b304b; both106internal/564public actual11/10; unpromoted.',
 purpose='Remove two closed abstract-analysis interfaces/arrays/seven singleton families and repeated boolean family routing; direct syntax selection retains semantic bodies and explicit static helper inputs. No new cache/framework/policy/option/owner/dependency. Compile/fresh helper text and complete CSV invoice plus warm floating/call controls; no predicted gain. All original name-pool adversity and earlier call-controller lessons preserved.',
 coreSHA256={role:f['imageFiles']['candidate'if role.startswith('candidate')else'reference']['Lokad.Lython.dll']for role in ['reference','reference-control','candidate','candidate-control']},imageFiles=f['imageFiles'],sourceInputsArchiveSHA256=sha(r/'candidate-sources.tar.xz'),productionFiles=587,catalogSHA256=sha(r/'combined-catalog.json'),normalAdapterPin='0.4.0',publicationHeld=True)
''' +s[b:]
a=s.index('jobs=');b=s.index('\ns=(old/',a)
jobs=[[case,phase]for case in ['scripts.text-normalization.helper-list','scripts.csv-invoice.large']for phase in ['compile','compile-run']]+[['scripts.numeric-squared-error.floating.large','warm'],['calls.positional.large','warm']]
s=s[:a]+'jobs='+repr(jobs)+s[b:]
s=s.replace("remote='/home/lokad/lython-bench-checks/prepared-names-b956-20261118';unit='lython-b956-prepared-names-20261118'", "remote='/home/lokad/lython-bench-checks/frontend-dispatch-b957-20261118';unit='lython-b957-frontend-dispatch-20261118'")
s=s.replace("'lython-b956-fixtures'", "'lython-b957-fixtures'")
s=s.replace('Six-job prepared-name source pair','Six-job frontend-dispatch source pair')
s=s.replace("print('Six-job R525 pair prepared;", "print('Six-job R527 pair prepared;")
(r/'prepare-quiet.py').write_text(s,encoding='utf-8',newline='\n')
print('Existing six-job quiet-VM collector reused; only exact committed withdrawn/raw replica candidates, current images preserved.')
