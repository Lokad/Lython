from pathlib import Path
import ast,hashlib,io,json,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');prior=r.parent/'module-bindings-r520';old=prior/'quiet';q=r/'quiet';q.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));assert all(sha(r/'frozen'/role/n)==h for role,files in f['imageFiles'].items()for n,h in files.items())
import gzip
subjects=[]
canonical='benchmarks/results/2026-11-18-prepared-name-pool/candidate-core.dll.gz'
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();data=gzip.decompress(blob)
assert hashlib.sha256(data).hexdigest()=='f96cd8a99ed882759b3c5ca0887bd07a3d6125bedf85f9995b617e3c54e0a8db'
subjects.append(dict(kind='withdrawn-prototype-core',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='gzip-payload',committedBlobVerified=True,knownPath='prepared-names-b956-20261118/candidate/Lokad.Lython.dll'))
for canonical,folder,raw,whole in [
 ('benchmarks/results/2026-11-18-prepared-name-pool/observations.tgz','prepared-names-b956-20261118',True,True),
 ('benchmarks/results/2026-11-18-prepared-module-bindings/initial/observations.tgz','module-bindings-b949-20261118',True,False),
 ('benchmarks/results/2026-11-18-prepared-module-bindings/confirmation/observations.tgz','module-bindings-confirm-b951-20261118',True,False),
 ('benchmarks/results/2026-11-18-bindings-cpython-checkpoint/observations.tgz','bindings-cpython-b952-20261118',False,True),
 ('benchmarks/results/2026-11-18-native-index-context/confirmation/observations.tgz','native-index-confirm-b955-20261118',True,True)]:
 blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();member='confirmation/confirmation.json'
 if raw:
  with tarfile.open(fileobj=io.BytesIO(blob))as a:data=a.extractfile(member).read()
  subjects.append(dict(kind='archived-raw-observation-replica',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True,knownPath=folder+'/'+member))
 if whole:
  subjects.append(dict(kind='archived-whole-observation-replica',sha256=hashlib.sha256(blob).hexdigest(),bytes=len(blob),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='whole-file',committedBlobVerified=True,knownPath=folder+'/observations.tgz'))

template=(r.parent/'known-drain-r515/prove-space.py').read_text(encoding='utf-8');a=template.index("code='''")+len("code='''");b=template.index("'''.replace('SUBJECTS',repr(subjects))",a);code=template[a:b].replace('SUBJECTS',repr(subjects))
code=code.replace("for key,proof in keys.items():assert sorted(aliases[key])==proof['paths']and len(aliases[key])==proof['links']", "for key,proof in keys.items():\n  assert len(aliases[key])==proof['links']\n  for name in aliases[key]:\n   p=b/name;v=p.lstat();assert p.resolve()==p and p.is_relative_to(b)and stat.S_ISREG(v.st_mode)and v.st_uid==os.getuid()and(v.st_dev,v.st_ino)==key and v.st_size==proof['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==proof['sha256']\n  proof['paths']=sorted(aliases[key])")
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);(r/'retirement-proof.log').write_text(p.stdout+p.stderr,encoding='utf-8',newline='\n');assert p.returncode==0,p.stdout+p.stderr;proofs=json.loads(p.stdout)['proofs'];(r/'retirement-candidates.json').write_text(p.stdout,encoding='utf-8',newline='\n')
identity=dict(sourceRevision='Qualified3f873227/frozena5038a28 GREEN44256409242 versus privateR527/2c6b304b; both106internal/564public actual11/10; unpromoted.',
 purpose='Remove two closed abstract-analysis interfaces/arrays/seven singleton families and repeated boolean family routing; direct syntax selection retains semantic bodies and explicit static helper inputs. No new cache/framework/policy/option/owner/dependency. Compile/fresh helper text and complete CSV invoice plus warm floating/call controls; no predicted gain. All original name-pool adversity and earlier call-controller lessons preserved.',
 coreSHA256={role:f['imageFiles']['candidate'if role.startswith('candidate')else'reference']['Lokad.Lython.dll']for role in ['reference','reference-control','candidate','candidate-control']},imageFiles=f['imageFiles'],sourceInputsArchiveSHA256=sha(r/'candidate-sources.tar.xz'),productionFiles=587,catalogSHA256=sha(r/'combined-catalog.json'),normalAdapterPin='0.4.0',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.text-normalization.helper-list', 'compile'], ['scripts.text-normalization.helper-list', 'compile-run'], ['scripts.csv-invoice.large', 'compile'], ['scripts.csv-invoice.large', 'compile-run'], ['scripts.numeric-squared-error.floating.large', 'warm'], ['calls.positional.large', 'warm']]
s=(old/'collect.py').read_text(encoding='utf-8');a=s.index('jobs=');b=s.index('\nassert len(jobs)',a);s=s[:a]+'jobs='+repr(jobs)+s[b:];s=s.replace('len(jobs)==5','len(jobs)==6').replace('started < 210','started < 300');(q/'collect.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'archive-owned.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==5","len(raw['jobs'])==6").replace('jobs=5','jobs=6');(q/'archive-owned.py').write_text(s,encoding='utf-8',newline='\n')
remote='/home/lokad/lython-bench-checks/frontend-dispatch-b957-20261118';unit='lython-b957-frontend-dispatch-20261118';previous=json.loads((old/'config.json').read_text(encoding='utf-8'))
(q/'run.sh').write_text((old/'run.sh').read_text(encoding='utf-8').replace(previous['root'],remote),encoding='utf-8',newline='\n');assert b'\r'not in(q/'run.sh').read_bytes()
(q/'candidate').mkdir();shutil.copyfile(r/'frozen/candidate/Lokad.Lython.dll',q/'candidate/Lokad.Lython.dll');shutil.copyfile(r/'combined-catalog.json',q/'representative.json');names=['representative.json','collect.py','archive-owned.py','run.sh','identity.json','candidate/Lokad.Lython.dll']
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for n in names:a.add(q/n,arcname=n)
c=dict(root=remote,unit=unit,source=previous['root'],sourceRole='candidate',sourceFiles=f['imageFiles']['reference'],sourceCatalogSHA256=sha(r/'measurement-catalog.json'),catalogSHA256=identity['catalogSHA256'],identity=identity,retireGroups=proofs,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha(q/'payload.tgz'),unpackedBytes=sum((q/n).stat().st_size for n in names));(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:];s=s.replace('lython-b949-fixtures','lython-b957-fixtures').replace('RuntimeMaxSec=330','RuntimeMaxSec=400').replace("os.link(source/'representative.json',root/'representative.json')","if not(root/'representative.json').exists():os.link(source/'representative.json',root/'representative.json')");(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
(q/'retrieve.py').write_text((old/'retrieve.py').read_text(encoding='utf-8').replace("['jobs']==5","['jobs']==6"),encoding='utf-8',newline='\n')
(r/'launch.py').write_text((prior/'launch.py').read_text(encoding='utf-8').replace('seconds=280','seconds=340').replace('before280seconds','before340seconds').replace('Four-job discarded-result consumer source pair','Six-job frontend-dispatch source pair'),encoding='utf-8',newline='\n')
(r/'summarize.py').write_text((prior/'summarize.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==5","len(raw['jobs'])==6"),encoding='utf-8',newline='\n')
for p in q.glob('*.py'):ast.parse(p.read_text(encoding='utf-8'))
print('Six-job R527 pair prepared; both actual five-case goldens, all32image hashes, LF verified; only exact committed withdrawn-core/raw replicas eligible; current images/floors preserved.')
