using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Lokad.Lython;

using var catalog = JsonDocument.Parse(File.ReadAllText(args[0], Encoding.UTF8));
var engine = new LythonEngine();
var budget = new LythonMemoryBudget(16 * 1024 * 1024);
var rows = new List<object>();
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var id = item.GetProperty("id").GetString()!;
    if (id is not ("scripts.text-normalization.helper-list" or "scripts.json-summary-helpers.large"
        or "scripts.numeric-squared-error.floating.large" or "calls.positional.large" or "scripts.csv-invoice.large")) continue;
    var source = item.GetProperty("source").GetString()!;
    for (var warm = 0; warm < 20; warm++) CompileAndDispose();
    var samples = new List<double>();
    for (var sample = 0; sample < 5; sample++)
    {
        var before = GC.GetAllocatedBytesForCurrentThread();
        for (var iteration = 0; iteration < 20; iteration++) CompileAndDispose();
        samples.Add((GC.GetAllocatedBytesForCurrentThread() - before) / 20.0);
    }
    rows.Add(new { id, allocatedBytesPerCompilation = samples, allowanceBaselineRestored = budget.ReservedBytes == 0 });

    void CompileAndDispose()
    {
        using (var compiled = engine.Compile(source, budget))
            if (!compiled.IsValid) throw new InvalidOperationException(string.Join("; ", compiled.Diagnostics));
        if (budget.ReservedBytes != 0) throw new InvalidOperationException("Compilation owner did not return the allowance.");
    }
}
var core = typeof(LythonEngine).Assembly.Location;
File.WriteAllText(args[1], JsonSerializer.Serialize(new
{
    coreSha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(core))).ToLowerInvariant(),
    boundary = "Synchronous Compile(source, borrowed budget) plus compiled-owner disposal on the current thread; 20 warmups, 5x20 compilations; no execution, elapsed measurement, forced GC or runtime overrides.",
    rows
}, new JsonSerializerOptions { WriteIndented = true }) + "\n", Encoding.UTF8);
