from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).parent;project=r/'compile-allocation';d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe')
env=os.environ.copy();env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
with(r/'compile-allocation-build.log').open('w',encoding='utf-8')as log:
 p=subprocess.run([str(d),'build',str(project/'compile-allocation.csproj'),'-c','Release','--no-incremental','-p:InspectionCorePath='+str(r/'frozen/reference/Lokad.Lython.dll')],cwd='D:/code/Lython',env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert p.returncode==0,(r/'compile-allocation-build.log').read_text(encoding='utf-8')
out=project/'bin/Release/net11.0';identity=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))
for role in ['reference','candidate']:
 assert hashlib.sha256((r/'frozen'/role/'Lokad.Lython.dll').read_bytes()).hexdigest()==identity['imageFiles'][role]['Lokad.Lython.dll']
 image=r/('compile-'+role);shutil.copytree(out,image)
 shutil.copyfile(r/'frozen'/role/'Lokad.Lython.dll',image/'Lokad.Lython.dll')
 p=subprocess.run([str(d),str(image/'compile-allocation.dll'),str(r/'catalog.json'),str(r/(role+'-compile-allocation.json'))],cwd='D:/code/Lython',env=env,capture_output=True,text=True,encoding='utf-8',timeout=60)
 assert p.returncode==0,p.stdout+p.stderr
 v=json.loads((r/(role+'-compile-allocation.json')).read_text(encoding='utf-8-sig'))
 assert v['coreSha256']==identity['imageFiles'][role]['Lokad.Lython.dll']and len(v['rows'])==5
 print(role,[(v['id'],v['allocatedBytesPerCompilation'])for v in v['rows']],flush=True)
