using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using static Microsoft.CodeAnalysis.CSharp.SyntaxFactory;

var root = Path.GetFullPath(args[0]);
var frontend = Path.Combine(root, "src/Lokad.Lython/Frontend");
if (args.Length > 1 && args[1] == "--audit")
{
    Audit();
    return;
}
var sources = new Dictionary<string, CompilationUnitSyntax>();
foreach (var name in new[] { "StaticAbstractInterpreter.cs", "StaticAbstractInterpreter.Expressions.cs",
    "StaticAbstractInterpreter.Statements.cs", "StaticAbstractInterpreter.ExpressionAnalyzers.cs" })
    sources[name] = ParseCompilationUnit(File.ReadAllText(Path.Combine(frontend, name), System.Text.Encoding.UTF8));

var statementMembers = Flatten(Find(sources["StaticAbstractInterpreter.Statements.cs"]),
    "AnalyzeStatement", "StatementSyntax", "statement", 4);
var expressionMembers = Flatten(Find(sources["StaticAbstractInterpreter.ExpressionAnalyzers.cs"]),
    "AnalyzeExpression", "ExpressionSyntax", "expression", 3);
Rewrite("StaticAbstractInterpreter.cs", m => !(m is InterfaceDeclarationSyntax i && i.Identifier.ValueText == "IStatementAnalyzer")
    && !(m is FieldDeclarationSyntax field && field.Declaration.Variables.Any(v => v.Identifier.ValueText == "StatementAnalyzers")),
    "AnalyzeStatement");
Rewrite("StaticAbstractInterpreter.Expressions.cs", m => !(m is InterfaceDeclarationSyntax i && i.Identifier.ValueText == "IExpressionAnalyzer")
    && !(m is FieldDeclarationSyntax field && field.Declaration.Variables.Any(v => v.Identifier.ValueText == "ExpressionAnalyzers")),
    "AnalyzeExpression");
Replace("StaticAbstractInterpreter.Statements.cs", statementMembers);
Replace("StaticAbstractInterpreter.ExpressionAnalyzers.cs", expressionMembers);
foreach (var (name, unit) in sources)
{
    if (unit.GetDiagnostics().Any(d => d.Severity == DiagnosticSeverity.Error)) throw new InvalidOperationException("Rewrite syntax invalid: " + name);
    File.WriteAllText(Path.Combine(frontend, name), unit.NormalizeWhitespace(indentation: "    ", eol: "\n").ToFullString() + "\n", new System.Text.UTF8Encoding(false));
}
File.Move(Path.Combine(frontend, "StaticAbstractInterpreter.ExpressionAnalyzers.cs"),
    Path.Combine(frontend, "StaticAbstractInterpreter.ExpressionChecks.cs"));
Console.WriteLine("Removed two interfaces/arrays and seven singleton families; one syntax switch per entry, explicit static inputs for lifted helpers.");

ClassDeclarationSyntax Find(CompilationUnitSyntax unit)
    => unit.DescendantNodes().OfType<ClassDeclarationSyntax>().First(c => c.Identifier.ValueText == "StaticAbstractInterpreter");
void Rewrite(string name, Func<MemberDeclarationSyntax, bool> keep, string removeMethod)
{
    var original = Find(sources[name]);
    // Keep unrelated semantic helpers verbatim; the old bool-family entry disappears.
    var members = original.Members.Where(m => keep(m) && !(m is MethodDeclarationSyntax method && method.Identifier.ValueText == removeMethod)).ToList();
    sources[name] = sources[name].ReplaceNode(original, original.WithMembers(List(members)));
}
void Replace(string name, IEnumerable<MemberDeclarationSyntax> members)
{
    var original = Find(sources[name]);
    sources[name] = sources[name].ReplaceNode(original, original.WithMembers(List(members)));
}

List<MemberDeclarationSyntax> Flatten(ClassDeclarationSyntax original, string entryName, string syntaxType, string parameterName, int expected)
{
    var families = original.Members.OfType<ClassDeclarationSyntax>().ToArray();
    if (families.Length != expected) throw new InvalidOperationException("Unexpected analyzer families.");
    var sections = new List<SwitchSectionSyntax>();
    var helpers = new List<MemberDeclarationSyntax>();
    foreach (var family in families)
    {
        var method = family.Members.OfType<MethodDeclarationSyntax>().Single(m => m.Identifier.ValueText == "TryAnalyze");
        var selection = method.Body!.Statements.OfType<SwitchStatementSyntax>().Single();
        var locals = method.Body.Statements.OfType<LocalFunctionStatementSyntax>().ToArray();
        var captures = new Dictionary<string, string[]>();
        foreach (var local in locals)
        {
            if (local.Modifiers.Any(SyntaxKind.AsyncKeyword)) throw new InvalidOperationException("Unexpected async analysis helper.");
            var identifiers = local.DescendantNodes().OfType<IdentifierNameSyntax>().Select(n => n.Identifier.ValueText).ToHashSet();
            captures[local.Identifier.ValueText] = local.Modifiers.Any(SyntaxKind.StaticKeyword) ? []
                : method.ParameterList.Parameters.Where(p => identifiers.Contains(p.Identifier.ValueText)
                    && !local.ParameterList.Parameters.Any(own => own.Identifier.ValueText == p.Identifier.ValueText))
                    .Select(p => p.Identifier.ValueText).ToArray();
        }
        var calls = new CapturedCalls(captures);
        foreach (var section in selection.Sections)
        {
            if (section.Labels.Any(l => l is DefaultSwitchLabelSyntax)) continue;
            var body = Block(section.Statements.Select(s => (StatementSyntax)calls.Visit(new CompletedReturns().Visit(s))!));
            sections.Add(section.WithStatements(SingletonList<StatementSyntax>(body)));
        }
        foreach (var local in locals)
        {
            var parameters = local.ParameterList.Parameters;
            foreach (var capture in captures[local.Identifier.ValueText])
                parameters = parameters.Add(method.ParameterList.Parameters.Single(p => p.Identifier.ValueText == capture));
            var helper = MethodDeclaration(local.ReturnType, local.Identifier)
                .WithModifiers(TokenList(Token(SyntaxKind.PrivateKeyword), Token(SyntaxKind.StaticKeyword)))
                .WithTypeParameterList(local.TypeParameterList).WithConstraintClauses(local.ConstraintClauses)
                .WithParameterList(ParameterList(parameters)).WithBody((BlockSyntax?)calls.Visit(local.Body))
                .WithExpressionBody((ArrowExpressionClauseSyntax?)calls.Visit(local.ExpressionBody))
                .WithSemicolonToken(local.SemicolonToken);
            helpers.Add(helper);
        }
        helpers.AddRange(family.Members.OfType<MethodDeclarationSyntax>().Where(m => m.Identifier.ValueText != "TryAnalyze"));
    }
    var entry = (MethodDeclarationSyntax)ParseMemberDeclaration($"private static void {entryName}({syntaxType} {parameterName}, List<LythonDiagnostic> diagnostics, AbstractState bindings) {{ }}")!;
    entry = entry.WithBody(Block(SwitchStatement(IdentifierName(parameterName)).WithSections(List(sections))));
    var output = new List<MemberDeclarationSyntax> { entry };
    output.AddRange(helpers);
    output.AddRange(original.Members.Where(m => m is not ClassDeclarationSyntax));
    return output;
}

void Audit()
{
    var originals = new List<CompilationUnitSyntax>();
    foreach (var name in new[] { "StaticAbstractInterpreter.cs", "StaticAbstractInterpreter.Expressions.cs",
        "StaticAbstractInterpreter.Statements.cs", "StaticAbstractInterpreter.ExpressionAnalyzers.cs" })
    {
        var start = new System.Diagnostics.ProcessStartInfo("git")
        {
            UseShellExecute = false, RedirectStandardOutput = true, RedirectStandardError = true,
            StandardOutputEncoding = System.Text.Encoding.UTF8
        };
        foreach (var arg in new[] { "-C", root, "show", "HEAD:src/Lokad.Lython/Frontend/" + name }) start.ArgumentList.Add(arg);
        using var process = System.Diagnostics.Process.Start(start)!;
        var text = process.StandardOutput.ReadToEnd(); process.WaitForExit();
        if (process.ExitCode != 0) throw new InvalidOperationException(process.StandardError.ReadToEnd());
        originals.Add(ParseCompilationUnit(text));
    }
    var current = Directory.GetFiles(frontend, "StaticAbstractInterpreter*.cs")
        .Select(p => ParseCompilationUnit(File.ReadAllText(p, System.Text.Encoding.UTF8))).ToArray();
    if (current.Length != 4) throw new InvalidOperationException("Unexpected partial files.");
    var methods = originals.SelectMany(u => u.DescendantNodes().OfType<MethodDeclarationSyntax>())
        .Where(m => m.Identifier.ValueText == "TryAnalyze" && m.Body is not null).ToArray();
    if (methods.Length != 7) throw new InvalidOperationException("Unexpected families.");
    foreach (var method in methods)
        if (method.Body!.Statements.Any(s => s is not SwitchStatementSyntax and not LocalFunctionStatementSyntax
            && s is not ReturnStatementSyntax { Expression: LiteralExpressionSyntax { RawKind: (int)SyntaxKind.TrueLiteralExpression } }))
            throw new InvalidOperationException("Semantic work outside family switch: " + method);
    string[] Strings(IEnumerable<CompilationUnitSyntax> units) => units.SelectMany(u => u.DescendantTokens())
        .Where(t => t.IsKind(SyntaxKind.StringLiteralToken) || t.IsKind(SyntaxKind.InterpolatedStringTextToken))
        .Select(t => t.ValueText).Order(StringComparer.Ordinal).ToArray();
    if (!Strings(originals).SequenceEqual(Strings(current))) throw new InvalidOperationException("Diagnostic string/text changed.");
    Dictionary<string,int> Calls(IEnumerable<CompilationUnitSyntax> units) => units
        .SelectMany(u => u.DescendantNodes().OfType<InvocationExpressionSyntax>())
        .GroupBy(n => n.Expression.WithoutTrivia().NormalizeWhitespace().ToFullString())
        .ToDictionary(g => g.Key, g => g.Count());
    var before = Calls(originals); var after = Calls(current);
    if (!before.Remove("analyzer.TryAnalyze", out var familyCalls) || familyCalls != 2) throw new InvalidOperationException("Unexpected dispatch callers.");
    if (before.Count != after.Count || before.Any(pair => !after.TryGetValue(pair.Key, out var count) || count != pair.Value))
        throw new InvalidOperationException("Semantic invocation inventory changed.");
    Console.WriteLine(System.Text.Json.JsonSerializer.Serialize(new
    {
        passed = true, originalFamilies = 7, originalInterfaces = 2, dispatchInvocationsRemoved = 2,
        allOtherInvocationTargetsAndCountsPreserved = true, diagnosticStringsAndInterpolatedTextPreserved = true,
        noDroppedSemanticTailStatements = true,
        boundary = "One-off source audit, not behavioral proof or a permanent architecture test. Runtime semantic/cancellation/ownership tests remain required."
    }, new System.Text.Json.JsonSerializerOptions { WriteIndented = true }));
}

sealed class CompletedReturns : CSharpSyntaxRewriter
{
    public override SyntaxNode? VisitLocalFunctionStatement(LocalFunctionStatementSyntax node) => node;
    public override SyntaxNode? VisitSimpleLambdaExpression(SimpleLambdaExpressionSyntax node) => node;
    public override SyntaxNode? VisitParenthesizedLambdaExpression(ParenthesizedLambdaExpressionSyntax node) => node;
    public override SyntaxNode? VisitReturnStatement(ReturnStatementSyntax node)
    {
        if (node.Expression is not LiteralExpressionSyntax literal || !literal.IsKind(SyntaxKind.TrueLiteralExpression))
            throw new InvalidOperationException("Unexpected return inside a handled syntax section: " + node);
        return node.WithExpression(null);
    }
}
sealed class CapturedCalls(Dictionary<string, string[]> captures) : CSharpSyntaxRewriter
{
    public override SyntaxNode? VisitInvocationExpression(InvocationExpressionSyntax node)
    {
        var visited = (InvocationExpressionSyntax)base.VisitInvocationExpression(node)!;
        if (visited.Expression is not IdentifierNameSyntax name || !captures.TryGetValue(name.Identifier.ValueText, out var extra) || extra.Length == 0) return visited;
        return visited.WithArgumentList(visited.ArgumentList.AddArguments(extra.Select(n => Argument(IdentifierName(n))).ToArray()));
    }
}
