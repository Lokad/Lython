from pathlib import Path
import gzip,hashlib,json,shutil,statistics,tarfile
r=Path(__file__).parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-18-frontend-dispatch'
out.mkdir(exist_ok=False)
for name in ['candidate-sources.tar.xz','checks.json','candidate-preflight.json','candidate-allocation.json','reference-allocation.json',
    'reference-combined-preflight.json','candidate-combined-preflight.json','summary.json','allocation-summary.json',
    'reference-compile-allocation.json','candidate-compile-allocation.json','ir-comparison.json','semantic-audit.json']:
    shutil.copyfile(r/name,out/name)
shutil.copyfile(r/'frozen/identity.json',out/'frozen-identity.json')
shutil.copyfile(r/'correction.patch.gz',out/'change.patch.gz')
for name in ['identity.json','terminal-status.json','archive-receipt.json','observations.tgz']:
    shutil.copyfile(r/'quiet'/name,out/name)
assert hashlib.sha256((out/'observations.tgz').read_bytes()).hexdigest()==json.loads((out/'archive-receipt.json').read_text(encoding='utf-8'))['archiveSHA256']
(out/'candidate-core.dll.gz').write_bytes(gzip.compress((r/'frozen/candidate/Lokad.Lython.dll').read_bytes(),mtime=0))
a=json.loads((r/'reference-compile-allocation.json').read_text(encoding='utf-8-sig'))
b=json.loads((r/'candidate-compile-allocation.json').read_text(encoding='utf-8-sig'))
rows=[]
for x,y in zip(a['rows'],b['rows']):
    assert x['id']==y['id']and x['allowanceBaselineRestored']and y['allowanceBaselineRestored']
    before=statistics.median(x['allocatedBytesPerCompilation']);after=statistics.median(y['allocatedBytesPerCompilation'])
    rows.append(dict(case=x['id'],referenceBytes=before,candidateBytes=after,changePercent=100*(after/before-1),allowanceBaselineRestored=True))
(out/'compile-allocation-summary.json').write_text(json.dumps(dict(boundary=a['boundary'],rows=rows),indent=2)+'\n',encoding='utf-8')
with tarfile.open(out/'procedures-and-checks.tar.xz','w:xz')as t:
    for p in sorted(r.rglob('*')):
        if not p.is_file()or {'frozen','retrieved','bin','obj','candidate','reference','compile-reference','compile-candidate','ir-reference','ir-candidate'}&set(p.relative_to(r).parts):continue
        if p.name in {'payload.tgz','candidate-sources.tar.xz','observations.tgz','correction.patch.gz'}:continue
        t.add(p,arcname=p.relative_to(r).as_posix())
print(out)
