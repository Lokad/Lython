from pathlib import Path
import json,os,subprocess
r=Path(__file__).parent;work=Path('D:/code/Lython/.git/agent-worktrees/prepared-names-r525')
d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy()
env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
filters={
 'internal':['Static','ParserCancellation','PostponedAnnotation','Abstract','CallBindingSubsystem',
     'ClassMethodExecutionBoundary','ExecutableLocalImportBinding','NativeClosureSequence'],
 'public':['StaticErrorDiagnostics','StaticRuntimeArityAgreement','Diagnostic','ScopeDirective',
     'ShortCircuit','ComprehensionEffect','SharedCompilerFact','CompilerCancellation',
     'GovernedMemoryContract','MemoryDenialAttribution','ClassAnnotationExecution',
     'NativeReceiverPipeline','RegexAnalysisBinding','AnnotationCompatibility'],
}
rows=[]
for tfm in ['net11.0','net10.0']:
 for kind,parts in filters.items():
  project='Lokad.Lython.Tests'if kind=='internal'else'Lokad.Lython.PublicApi.Tests'
  cmd=[str(d),'test',f'tests/{project}/{project}.csproj','-c','Release','-f',tfm,'--no-build',
      '--filter','('+'|'.join('FullyQualifiedName~'+n for n in parts)+')&Category!=Stress']
  path=r/(kind+'-'+tfm+'.log')
  with path.open('w',encoding='utf-8')as log:p=subprocess.run(cmd,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
  rows.append(dict(kind=kind,framework=tfm,command=cmd,exitCode=p.returncode))
  (r/'checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
  output=path.read_text(encoding='utf-8');assert p.returncode==0,output
  print(kind,tfm,output.splitlines()[-1],flush=True)
