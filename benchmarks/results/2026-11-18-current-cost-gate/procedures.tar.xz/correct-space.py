from pathlib import Path
import hashlib,io,json,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');assert 'AssertionError: (266141696'in(r/'launch.log').read_text(encoding='utf-8')
canonical='benchmarks/results/2026-11-18-bulk-trim/observations.tgz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();subjects=[]
with tarfile.open(fileobj=io.BytesIO(blob))as a:
 for member in ['confirmation/confirmation.json','whole-archive','confirmation/machine-before.json','confirmation/machine-after.json','collect.py','identity.json','__pycache__/cpython-worker.cpython-312.pyc']:
  data=blob if member=='whole-archive'else a.extractfile(member).read();subjects.append(dict(kind='completed-replica',path='bulk-trim-b930-20261118/'+('observations.tgz'if member=='whole-archive'else member),bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True))
s=(r.parent/'bulk-trim-r506/prove-space.py').read_text(encoding='utf-8');a=s.index("code='''")+len("code='''");b=s.index("'''.replace",a);code=s[a:b].replace('SUBJECTS',repr(subjects)).replace('generator-facts-b928-20261117','bulk-trim-b930-20261118')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);assert p.returncode==0,p.stdout+p.stderr;groups=json.loads(p.stdout)
(r/'first-space-guard.log').write_bytes((r/'launch.log').read_bytes())
(r/'first-config.json').write_bytes((r/'config.json').read_bytes())
c=json.loads((r/'config.json').read_text(encoding='utf-8'));c['retireGroups']=groups
(r/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
(r/'retirement-candidates.json').write_text(p.stdout,encoding='utf-8')
s=(r/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:];(r/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
(r/'launch.log').rename(r/'first-launch.log')
print(json.dumps(dict(eligibleBytes=sum(p['bytes']for p in groups),groups=len(groups),originalSpaceGuardUnchanged=True,previousFailureBeforeMutation=True)))
