from pathlib import Path
r=Path(__file__).resolve().parent
s=(r.parent/'current-cpu-r500/analyze.py').read_text(encoding='utf-8')
s=s.replace("['text','floating']","['floating','configuration']").replace('Current complete text/floating','Current complete floating warm/configuration compile-to-result')
s=s.replace("groups={'function", "groups={'frontend':['LythonFrontend','Parser','Lexer','ExecutableScript','ExecutableStackLayout','LoweredScript'],'invocation setup':['CreateBuiltinVariables','ExecutionState','CreateRoot','CreateModuleVariables'],'function")
(r/'analyze.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared reused attribution parser; retain all threads, unknowns and overlapping inclusive groups.')
