from pathlib import Path
r=Path(__file__).resolve().parent
s=(r/'analyze.py').read_text(encoding='utf-8').replace("['floating','configuration']","['floating']").replace("r/'retrieved/profiles'","r/'failed-retrieved/failed-guest-fixtures/profiles'")
s=s.replace('Current complete floating warm/configuration compile-to-result','Partial completed floating warm; configuration missing and original end quiet gate absent')
s=s.replace("r/'attribution.json'","r/'partial-attribution.json'")
exec(compile(s,str(r/'analyze-partial.py'),'exec'),dict(__file__=str(r/'analyze-partial.py')))
