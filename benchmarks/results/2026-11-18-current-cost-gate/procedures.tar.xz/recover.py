from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).resolve().parent
assert not(r/'failed-observations.tgz').exists()
code=r'''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess,tarfile,time
root=Path('/home/lokad/lython-bench-checks/current-costs-b931-20261118');unit='lython-b931-current-costs-20261118'
assert root.resolve()==root and root.parent==Path('/home/lokad/lython-bench-checks')
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 service=subprocess.check_output(['systemctl','show',unit+'.service','--property=ActiveState,MainPID,Result'],text=True)
 assert 'MainPID=0'in service and 'ActiveState=failed'in service
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert(root/'guest-fixtures').is_mount()
 (root/'failed-journal.txt').write_text(subprocess.check_output(['journalctl','-u',unit+'.service','--no-pager'],text=True))
 time.sleep(3)
 dotnet='/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet'
 env=os.environ.copy();env['DOTNET_ROOT']=str(Path(dotnet).parent)
 subprocess.run([dotnet,str(root/'candidate/Lokad.Lython.Benchmarks.dll'),'--compare','check-machine','--out',str(root/'recovery-machine.json')],env=env,check=True,stdout=subprocess.DEVNULL)
 assert json.loads((root/'recovery-machine.json').read_text())['gate']['quiet']
 trace=root/'guest-fixtures';raw={p.relative_to(trace).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in trace.rglob('*')if p.is_file()}
 archive=root/'failed-observations.tgz';assert not archive.exists()
 with tarfile.open(archive,'w:gz',dereference=True)as a:
  for p in sorted(root.iterdir()):
   if p.is_file()and p!=archive:a.add(p,arcname=p.name)
  a.add(trace,arcname='failed-guest-fixtures')
 with tarfile.open(archive)as a:
  for n,h in raw.items():assert hashlib.sha256(a.extractfile('failed-guest-fixtures/'+n).read()).hexdigest()==h
 subprocess.run(['sudo','-n','umount',str(trace)],check=True);trace.rmdir()
 assert shutil.disk_usage(root).free>252*1024*1024
 receipt=dict(complete=False,archivalRecovery=True,sourceFailure='configuration warmup exhausted reused fixed iteration cap before8seconds',floatingProfileCompleted=True,configurationProfileMissing=True,allUsersJoined=True,archivedAndVerifiedUnderLease=True,allRamFilesVerifiedBeforeUnmount=True,guestFixturesRemoved=True,quietAtRecovery=True,originalEndGateMissing=True,archiveSHA256=hashlib.sha256(archive.read_bytes()).hexdigest(),regularRamFiles=len(raw),freeBytes=shutil.disk_usage(root).free)
 (root/'recovery-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60)
(r/'recovery.log').write_text(p.stdout+p.stderr,encoding='utf-8');assert p.returncode==0,p.stdout+p.stderr
receipt=json.loads(p.stdout);(r/'recovery-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
p=subprocess.run(scp+['lokad@20.166.121.73:/home/lokad/lython-bench-checks/current-costs-b931-20261118/failed-observations.tgz',str(r/'failed-observations.tgz')],capture_output=True,timeout=60);assert p.returncode==0,p.stderr
assert hashlib.sha256((r/'failed-observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
out=r/'failed-retrieved';out.mkdir()
with tarfile.open(r/'failed-observations.tgz')as a:
 regular=[m for m in a.getmembers()if m.isfile()or m.isdir()];assert all(m.isfifo()and m.size==0 for m in a.getmembers()if m not in regular);a.extractall(out,members=regular,filter='data')
print(json.dumps(receipt));print('Partial/failure evidence SHA-verified locally, users joined and RAM torn down; no completed campaign claim.')
