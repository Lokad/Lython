from pathlib import Path
import json,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-18-current-cost-gate';out.mkdir(exist_ok=False)
for n in ['identity.json','preflight.json','recovery-receipt.json','failed-observations.tgz','configuration-failed.perf.map.gz','partial-attribution.json']:shutil.copyfile(r/n,out/n)
with tarfile.open(out/'procedures.tar.xz','w:xz')as a:
 a.add(r.parent/'prepare-cpu-r508.py',arcname='prepare-cpu-r508.py')
 for p in sorted(r.iterdir()):
  if p.is_file()and p.suffix in ['.py','.json','.log','.sh']:a.add(p,arcname=p.name)
(out/'README.md').write_text('''# Current whole-script cost gate: partial evidence

R508/B931,2026-11-18, committed60da2cf4/frozen65fcf7d0, normal optional adapter0.4.
All32actual-image hashes and existing three-case catalog verification/goldens pass.
This is sampled CPU/source evidence, not an elapsed comparison or removable-share
forecast. The two-profile collection is incomplete; configuration capture is missing.

Floating warm completed its5s capture, goldens and Closed acknowledgment after8s
warmup. Selected active threads940samples/67unknown; all-thread counts/raw retained.
Leaves include primary prefix131, transfer79, sequence-index54, JSON construction53,
UTF8double parsing45, generic inputs41, native prefix39, sum37 and native-call33.
Inclusive function entry/binding/retirement134includes useful/inlined work. These
do not isolate frame allocation or authorize another selector reshuffle. The
original collection's end quiet gate was skipped after the later failure; recovery
quiet is separate, not substituted. Keep group counts diagnostic: substring matches
can include parameter type names and overlap, rather than exact subsystem time.

Configuration compile-to-result used the reused64invocation batch/128warmup-batch
cap. It exhausted that count before accumulating8guest seconds. The worker joined
through the failure path; its incomplete run is not an adverse runtime/design result.
One configuration-only correction will size batches1024for the existing8s target,
retaining the128batch bound/service timeout. No floating retiming is required.

Initial staging failed the unchanged254MiBguard before mutation; extra exact
committed B930metadata replicas were freshly proved alongside raw/archive bytes.
Recovery archived/verified every RAM file before teardown, then caught the252MiB
floor. The failed worker's1884160Btemporary JIT map explains additional storage:
its exact pid comes from recorded worker identity. After join, regular-file/UID/
link/path/immutable-stat/hash checks, it was gzip-preserved/verified before retiring
that same collection's temporary. First stat comparison accidentally included read
atime; correction compares immutable identity/size/mtime, preserving the failure.
All traces/maps are locally SHA-verified; no live workers/RAM mount remain. Original
conditions/logs are retained; no unrelated deletion or lowered guard.

[Partial attribution](partial-attribution.json),[failed raw](failed-observations.tgz),
[failed configuration map](configuration-failed.perf.map.gz),
[recovery](recovery-receipt.json),[source/image facts](identity.json),
[actual-image verification](preflight.json),[procedures/failures](procedures.tar.xz).
Full runtime qualification is independently pending44211082563; publication held.
''',encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as a:
 a.write('\nR508/B931 [partial current-cost gate](results/2026-11-18-current-cost-gate/README.md):60da/65fc floating capture940selected samples/67unknown, configuration warmup exhausted128x64invocations before8seconds. No runtime/design failure verdict or elapsed/removable-share claim. Goldens/Closed for floating, original end quiet missing; recovery quiet separate. All RAM/raw/failure/native JIT map archived/SHAverified, users joined; initial staging/recovery-floor/stat-atime failures retained, no unrelated cleanup or guard relaxation. One config-only1024batch sizing correction selected; core/performance work and independent44211082563qualification remain active.\n')
print('Partial source evidence and every failure/recovery condition archived without a completed campaign claim.')
