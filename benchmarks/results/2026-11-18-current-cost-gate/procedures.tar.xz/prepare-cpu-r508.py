from pathlib import Path
import ast,hashlib,io,json,os,re,subprocess,tarfile
repo=Path('D:/code/Lython');base=Path(__file__).parent;r=base/'current-cpu-r508';r.mkdir(exist_ok=False);old=base/'current-cpu-r500';current=base/'bulk-trim-r506'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((current/'frozen/identity.json').read_text(encoding='utf-8'));image=current/'frozen/candidate';assert all(sha(image/n)==h for n,h in f['imageFiles']['candidate'].items())
catalog=base/'invocation-cost-r505/catalog.json';catalogsha=sha(catalog);d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
cmd=[str(d),str(image/'Lokad.Lython.Benchmarks.dll'),'--compare','verify','--catalog',str(catalog),'--dotnet',str(d),'--python','C:/Python313/python.exe','--python-worker',str(repo/'benchmarks/cpython-worker.py'),'--out',str(r/'preflight.json')]
with(r/'preflight.log').open('w',encoding='utf-8')as log:p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert p.returncode==0,(r/'preflight.log').read_text(encoding='utf-8');print('Actual65fc image verifies the existing three-case catalog before VM staging.',flush=True)
identity=dict(sourceRevision='Committed60da2cf4 production/frozen65fcf7d0; qualification dispatched at0691d64f, pending. NormalGC/tiering plus perf maps only.',purpose='Current floating warm after generator-field correction and config compile-to-result CPU attribution. Separate remaining helper lifecycle/dispatch/operations/JSON/setup before one substantial design; not an elapsed or removable-share comparison.',imageFiles=f['imageFiles'],coreSHA256={role:files['Lokad.Lython.dll']for role,files in f['imageFiles'].items()},catalogSHA256=catalogsha,sourceInputsArchiveSHA256=f['sourceInputsArchiveSHA256'],publicationHeld=True)
name='current-costs-b931-20261118';unit='lython-b931-current-costs-20261118';remote='/home/lokad/lython-bench-checks/'+name
for n in ['ops-profile.py','collect.py','run.sh','retrieve.py']:
 s=(old/n).read_text(encoding='utf-8').replace('current-script-cpu-b925-20261117',name).replace('lython-b925-current-script-cpu-20261117',unit).replace('lython-b925-fixtures','lython-b931-fixtures')
 if n=='ops-profile.py':
  s=s.replace("[('text','scripts.text-normalization.large','warm'),('floating','scripts.numeric-squared-error.floating.large','warm')]","[('floating','scripts.numeric-squared-error.floating.large','warm'),('configuration','scripts.config-edit.small','compile-run')]")
 if n=='collect.py':
  s=s.replace("['text','floating']","['floating','configuration']").replace('R500/B925 committedea8e9f91 production/frozencf847936 current text and floating attribution','R508/B931 committed60da production/frozen65fc current floating/configuration attribution')
 (r/n).write_text(s,encoding='utf-8',newline='\n')
s=(old/'launch.py').read_text(encoding='utf-8').replace('Current text/floating CPU attribution','Current floating/configuration CPU attribution');(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
canonical='benchmarks/results/2026-11-18-bulk-trim/observations.tgz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();subjects=[]
with tarfile.open(fileobj=io.BytesIO(blob))as a:
 for member in ['confirmation/confirmation.json','whole-archive']:
  data=blob if member=='whole-archive'else a.extractfile(member).read();subjects.append(dict(kind='completed-replica',path='bulk-trim-b930-20261118/'+('observations.tgz'if member=='whole-archive'else member),bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True))
s=(current/'prove-space.py').read_text(encoding='utf-8');a=s.index("code='''")+len("code='''");b=s.index("'''.replace",a);code=s[a:b].replace('SUBJECTS',repr(subjects)).replace('generator-facts-b928-20261117','bulk-trim-b930-20261118')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);assert p.returncode==0,p.stdout+p.stderr;groups=json.loads(p.stdout);(r/'retirement-candidates.json').write_text(p.stdout,encoding='utf-8')
names=['ops-profile.py','collect.py','run.sh','identity.json']
with tarfile.open(r/'payload.tgz','w:gz')as a:
 for n in names:a.add(r/n,arcname=n)
c=dict(root=remote,unit=unit,source='/home/lokad/lython-bench-checks/bulk-trim-b930-20261118',sourceFiles=f['imageFiles']['reference'],sourceCatalogSHA256=f['catalogSHA256'],catalogSource='/home/lokad/lython-bench-checks/agent-checkpoint-b929-20261118/representative.json',catalogSHA256=catalogsha,identity=identity,retireGroups=groups,payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=sha(r/'payload.tgz'),unpackedBytes=sum((r/n).stat().st_size for n in names))
(r/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:]
needle=" os.link(source/'catalog.json' if (source/'catalog.json').exists() else source/'representative.json',root/'catalog.json')";assert needle in s
s=s.replace(needle," catalogSource=Path(c['catalogSource']);assert catalogSource.resolve()==catalogSource and catalogSource.is_relative_to(b)and sha(catalogSource)==c['catalogSHA256']\n os.link(catalogSource,root/'catalog.json')").replace('lython-b925-fixtures','lython-b931-fixtures');(r/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
for p in r.glob('*.py'):ast.parse(p.read_text(encoding='utf-8'))
assert "('configuration','scripts.config-edit.small','compile-run')"in(r/'ops-profile.py').read_text(encoding='utf-8')and "['floating','configuration']"in(r/'collect.py').read_text(encoding='utf-8')and 'RuntimeMaxSec=150'in s
print('Two current attribution captures prepared; full image/catalog checked,150s service cap and original space floors unchanged.',flush=True)
