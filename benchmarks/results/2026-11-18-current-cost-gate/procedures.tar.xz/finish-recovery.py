from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).resolve().parent
code=r'''from pathlib import Path
import fcntl,gzip,hashlib,json,os,shutil,stat,subprocess,tarfile
root=Path('/home/lokad/lython-bench-checks/current-costs-b931-20261118')
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not(root/'guest-fixtures').exists()
 archive=root/'failed-observations.tgz'
 with tarfile.open(archive)as a:
  record=json.loads(a.extractfile('failed-guest-fixtures/profiles/configuration/record.json').read())
  pid=record['identity']['processId'];assert record['exitCode']!=0 and not Path('/proc/'+str(pid)).exists()
 maps=[]
 for prefix in ['perf','perfinfo']:
  temporary=Path('/tmp')/(prefix+'-'+str(pid)+'.map')
  if not temporary.exists():continue
  m=temporary.lstat();assert temporary.resolve()==temporary and stat.S_ISREG(m.st_mode)and m.st_uid==os.getuid()and m.st_nlink==1
  raw=temporary.read_bytes();rawsha=hashlib.sha256(raw).hexdigest();retained=root/('configuration-failed.'+prefix+'.map.gz')
  if not retained.exists():
   with gzip.open(retained,'wb')as a:a.write(raw)
  with gzip.open(retained,'rb')as a:assert hashlib.sha256(a.read()).hexdigest()==rawsha
  current=temporary.lstat()
  assert all(getattr(current,n)==getattr(m,n)for n in ['st_dev','st_ino','st_mode','st_uid','st_nlink','st_size','st_mtime_ns'])and hashlib.sha256(temporary.read_bytes()).hexdigest()==rawsha
  temporary.unlink()
  maps.append(dict(pid=pid,path=str(temporary),bytes=len(raw),sha256=rawsha,retained=retained.name,retainedSHA256=hashlib.sha256(retained.read_bytes()).hexdigest(),ownedWorkerJoined=True,originalVerifiedBeforeTemporaryRetirement=True))
 assert maps
 free=shutil.disk_usage(root).free;assert free>252*1024*1024
 receipt=dict(complete=False,archivalRecovery=True,sourceFailure='configuration warmup exhausted128batches before8seconds',floatingProfileCompleted=True,configurationProfileMissing=True,allUsersJoined=True,archivedAndVerifiedUnderLease=True,allRamFilesVerifiedBeforeUnmount=True,guestFixturesRemoved=True,quietAtRecovery=True,originalEndGateMissing=True,firstRecoveryFloorGuardFailedAfterVerifiedRamTeardown=True,initialFreeBytes=264171520,configurationTemporaryMaps=maps,archiveSHA256=hashlib.sha256(archive.read_bytes()).hexdigest(),freeBytes=free)
 (root/'recovery-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
if(r/'finish-recovery.log').exists()and not(r/'first-stat-atime-check.log').exists():(r/'first-stat-atime-check.log').write_bytes((r/'finish-recovery.log').read_bytes())
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);(r/'finish-recovery.log').write_text(p.stdout+p.stderr,encoding='utf-8');assert p.returncode==0,p.stdout+p.stderr
receipt=json.loads(p.stdout);(r/'recovery-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for n in ['failed-observations.tgz']+[x['retained']for x in receipt['configurationTemporaryMaps']]:
 p=subprocess.run(scp+['lokad@20.166.121.73:/home/lokad/lython-bench-checks/current-costs-b931-20261118/'+n,str(r/n)],capture_output=True,timeout=60);assert p.returncode==0,p.stderr
 expected=receipt['archiveSHA256']if n=='failed-observations.tgz'else next(x['retainedSHA256']for x in receipt['configurationTemporaryMaps']if x['retained']==n)
 assert hashlib.sha256((r/n).read_bytes()).hexdigest()==expected
out=r/'failed-retrieved';out.mkdir()
with tarfile.open(r/'failed-observations.tgz')as a:
 regular=[m for m in a.getmembers()if m.isfile()or m.isdir()];assert all(m.isfifo()and m.size==0 for m in a.getmembers()if m not in regular);a.extractall(out,members=regular,filter='data')
print(json.dumps(receipt));print('All failed evidence persisted/SHA verified; no live users or RAM traces. Space floor restored through exact owned-worker temporary map archival, no unrelated deletion.')
