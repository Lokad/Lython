from pathlib import Path
r=Path(__file__).resolve().parent
s=(r.parent/'current-cpu-r508/analyze.py').read_text(encoding='utf-8')
s=s.replace("['floating','configuration']","['configuration']")
s=s.replace("current=[]if header[1]in record['activeCpuTids']else None","current=[]")
# Classify the executing method, not return/parameter type mentions. Counts
# still overlap and do not isolate compilation clocks or removable work.
s=s.replace("inclusive={name:sum(any(any(part in method for part in parts)for method in stack)for stack in samples)for name,parts in groups.items()}","def method_key(method):\n  head=method.split('(',1)[0]\n  if '::' not in head:return head\n  owner,name=head.rsplit('::',1);return owner.split()[-1]+'::'+name\n inclusive={name:sum(any(any(part in method_key(method)for part in parts)for method in stack)for stack in samples)for name,parts in groups.items()}")
s=s.replace('Current complete floating warm/configuration compile-to-result whole-worker sampled CPU; selected active threads retain all-thread raw data/counts;', 'Configuration compile-to-result ALL-thread sampled CPU; activeCpuTids is the collector guest subset only, sample tables include every thread; method owners exclude return/parameter types;')
exec(compile(s,str(r/'analyze.py'),'exec'),dict(__file__=str(r/'analyze.py')))
