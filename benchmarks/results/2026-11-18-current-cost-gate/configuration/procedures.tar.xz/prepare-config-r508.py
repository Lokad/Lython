from pathlib import Path
import ast,hashlib,json,tarfile
repo=Path('D:/code/Lython');base=Path(__file__).parent;r=base/'config-cost-r508';r.mkdir(exist_ok=False);old=base/'current-cpu-r508';f=json.loads((base/'bulk-trim-r506/frozen/identity.json').read_text(encoding='utf-8'));files=f['imageFiles']['candidate']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
image=base/'bulk-trim-r506/frozen/candidate';assert all(sha(image/n)==h for n,h in files.items())
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'));identity.update(sourceRevision='Qualified0691d64f production/frozen65fcf7d0; normalGC/tiering plus perf maps only.',purpose='One configuration compile-to-result profile after correcting warmup batch sizing1024. Original failed128x64condition and floating partial evidence retained; no elapsed/source comparison.',imageFiles={role:files for role in ['reference','candidate']},coreSHA256={role:files['Lokad.Lython.dll']for role in ['reference','candidate']})
name='config-cost-b932-20261118';unit='lython-b932-config-cost-20261118';remote='/home/lokad/lython-bench-checks/'+name
for n in ['ops-profile.py','collect.py','run.sh','retrieve.py']:
 s=(old/n).read_text(encoding='utf-8').replace('current-costs-b931-20261118',name).replace('lython-b931-current-costs-20261118',unit).replace('lython-b931-fixtures','lython-b932-fixtures')
 if n=='ops-profile.py':
  s=s.replace("[('floating','scripts.numeric-squared-error.floating.large','warm'),('configuration','scripts.config-edit.small','compile-run')]","[('configuration','scripts.config-edit.small','compile-run')]").replace('count = 64','count = 1024')
  # A joined failed worker owns its temporary maps too. Preserve those bytes
  # before removing that collection's temporary, rather than leaking /tmp maps.
  a=s.index('            if process.returncode == 0:\n');b=s.index('            record["redundantTemporaryMapsRetiredAfterJoin"]',a)
  block=s[a:b].splitlines();s=s[:a]+'\n'.join(line[4:]for line in block[1:])+'\n'+s[b:]
 if n=='collect.py':s=s.replace("['floating','configuration']","['configuration']").replace('R508/B931 committed60da production/frozen65fc current floating/configuration attribution','R508/B932 qualified0691 production/frozen65fc configuration attribution, warmup1024correction')
 (r/n).write_text(s,encoding='utf-8',newline='\n')
s=(old/'launch.py').read_text(encoding='utf-8').replace('Current floating/configuration CPU attribution','Configuration-only CPU attribution with corrected batch sizing');(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
names=['ops-profile.py','collect.py','run.sh','identity.json']
with tarfile.open(r/'payload.tgz','w:gz')as a:
 for n in names:a.add(r/n,arcname=n)
previous=json.loads((old/'config.json').read_text(encoding='utf-8'))
c=dict(root=remote,unit=unit,source=previous['source'],sourceFiles=files,sourceCatalogSHA256=previous['sourceCatalogSHA256'],catalogSource=previous['catalogSource'],catalogSHA256=previous['catalogSHA256'],identity=identity,retireGroups=json.loads((old/'reference-retirement-proof.json').read_text(encoding='utf-8'))['proofs'],payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=sha(r/'payload.tgz'),unpackedBytes=sum((r/n).stat().st_size for n in names))
(r/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:]
s=s.replace("sha(source/'reference'/n)","sha(source/'candidate'/n)").replace('os.link(source/role/n,p)',"os.link(source/'candidate'/n,p)").replace('lython-b931-fixtures','lython-b932-fixtures');(r/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
for p in r.glob('*.py'):ast.parse(p.read_text(encoding='utf-8'))
s=(r/'ops-profile.py').read_text(encoding='utf-8');assert 'range(128)'in s and 'if elapsed >= 8' in s and 'count = 1024'in s and 'if process.returncode == 0:'not in s
assert "['configuration']"in(r/'collect.py').read_text(encoding='utf-8')and 'RuntimeMaxSec=150'in(r/'remote-launch.py').read_text(encoding='utf-8')
print('One configuration-only corrected profile prepared; current65fc preserved, exact superseded5ae aliases only retire. Warmup/service/space bounds unchanged.')
