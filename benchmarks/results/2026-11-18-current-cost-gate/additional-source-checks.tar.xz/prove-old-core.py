from pathlib import Path
import gzip,hashlib,json,subprocess
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');subjects=[]
for suffix in ['flat-operations/','lean/','']:
 canonical='benchmarks/results/2026-11-17-completed-instruction-runner/'+suffix+'candidate-core.dll.gz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();data=gzip.decompress(blob)
 subjects.append(dict(kind='superseded-core',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='gzip-payload',committedBlobVerified=True))
current=json.loads((r.parent/'bulk-trim-r506/frozen/identity.json').read_text(encoding='utf-8'));assert all(x['sha256']not in [f['Lokad.Lython.dll']for f in current['imageFiles'].values()]for x in subjects)
code='''from pathlib import Path
import fcntl,hashlib,json,os,stat,subprocess
b=Path('/home/lokad/lython-bench-checks');subjects=SUBJECTS
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not any(os.path.ismount(p)for p in b.glob('*/guest-fixtures'))
 wanted={x['sha256']:x for x in subjects};matches={}
 for p in b.glob('*/*/Lokad.Lython.dll'):
  m=p.lstat()
  if m.st_size not in [x['bytes']for x in subjects]:continue
  digest=hashlib.sha256(p.read_bytes()).hexdigest()
  if digest in wanted:matches.setdefault(digest,[]).append(p)
 selected=next((x for x in subjects if x['sha256']in matches),None);assert selected,dict(missing=[x['sha256']for x in subjects])
 ps=matches[selected['sha256']];m=ps[0].lstat();key=(m.st_dev,m.st_ino)
 for p in ps:
  v=p.lstat();assert p.resolve()==p and p.is_relative_to(b)and stat.S_ISREG(v.st_mode)and v.st_uid==os.getuid()and v.st_nlink==m.st_nlink and(v.st_dev,v.st_ino)==key
 aliases=[]
 for base,dirs,names in os.walk(b):
  for n in names:
   p=Path(base)/n;v=p.lstat()
   if(v.st_dev,v.st_ino)==key:aliases.append(str(p.relative_to(b)))
 assert len(aliases)==m.st_nlink and sorted(aliases)==sorted(str(p.relative_to(b))for p in ps)
 print(json.dumps(dict(proofs=[selected|dict(paths=aliases,links=m.st_nlink)],bytes=m.st_size,readOnly=True,current65fcAnd5aeImagesPreserved=True)))
'''.replace('SUBJECTS',repr(subjects))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);(r/'old-core-proof.log').write_text(p.stdout+p.stderr,encoding='utf-8');assert p.returncode==0,p.stdout+p.stderr
(r/'old-core-proof.json').write_text(p.stdout,encoding='utf-8');print(p.stdout)
