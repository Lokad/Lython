set -e
cd /mnt/d/code/Lython/.git/agent-worktrees/direct-literal-record-r644
export PATH="$HOME/.dotnet:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/direct-literal-record-r644
filter='(FullyQualifiedName~RecordFieldLookup|FullyQualifiedName~DictionaryConstruction|FullyQualifiedName~DictionaryLiteral|FullyQualifiedName~DictionaryExpansion|FullyQualifiedName~JsonWindow|FullyQualifiedName~JsonPropertyName|FullyQualifiedName~FunctionAttributeAccounting|FullyQualifiedName~FunctionDefaults|FullyQualifiedName~CsvDictReader|FullyQualifiedName~GovernedMemoryContract)&Category!=Stress'
for project in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="$logs/$project-wsl-net10.log"
    code=0
    dotnet test "tests/$project" -c Release -f net10.0 --artifacts-path "$PWD/tests/artifacts/r644-wsl" --filter "$filter" > "$log" 2>&1 || code=$?
    if [ "$code" != 0 ]; then tail -23 "$log"; exit "$code"; fi
    tail -4 "$log"
done
