import base64
import tempfile
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
tree=repo
donor=lab.with_name('exact-unicode-float-20261124')
comparison=lab/'comparison'
comparison.mkdir(exist_ok=True)


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path,value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')


metadata=read(donor/'comparison/identity.json')
reference=metadata['candidate']
assert reference.startswith('5d54f7afb')
subprocess.run(['git','diff','--exit-code',reference,'HEAD^','--','src','tests'],cwd=repo,check=True)
assert not subprocess.check_output(['git','status','--porcelain','--','src','tests'],cwd=tree)
candidate=subprocess.check_output(['git','rev-parse','HEAD'],cwd=tree,text=True).strip()
assert candidate!=reference

catalog=read(lab.with_name('grouped-lexical-cells-compact-20261124')/'comparison/representative.json')
quote=catalog['cases'][-1]
size=3072
input_data=''.join(
    (f'WARN: AB{index} délai dépassé\n' if index % 3 == 0 else
     f'INFO: AB{index} démarrage normal\n' if index % 3 == 1 else
     f'ERROR: XY{index} panne 😀\n')
    for index in range(size)
).encode('utf-8')
fixture=json.dumps(dict(size=size,text=None,inputFiles={'events.log':base64.b64encode(input_data).decode('ascii')},outputFiles={}),
    ensure_ascii=False,separators=(',',':'))
setup="""import re
rule = r'(?:WARN|ERROR): ([A-Z]{2}[0-9]+)'
"""
body="""matched = 0
characters = 0
with open('events.log',encoding='utf-8') as lines:
    for line in lines:
        match = {call}
        if match is not None:
            matched += 1
            characters += len(match.group(1))
print(matched,characters)
"""
cases=[]
for kind, initialization, call in [
    ('compiled', 'pattern = re.compile(rule)\n', 'pattern.search(line)'),
    ('bound', 'find = re.compile(rule).search\n', 'find(line)'),
    ('module', '', 're.search(rule,line)'),
]:
    source=setup+initialization+body.format(call=call)
    with tempfile.TemporaryDirectory() as work:
        Path(work,'events.log').write_bytes(input_data)
        result=subprocess.run(['C:/Python313/python.exe','-I','-X','utf8','-c',source],
            cwd=work,capture_output=True,check=True,timeout=10)
    assert not result.stderr
    output=result.stdout.replace(b'\r\n',b'\n').decode('utf-8')
    assert output == f'{size * 2 // 3} {sum(2+len(str(i)) for i in range(size) if i % 3 != 1)}\n',output
    hash_text=lambda value:hashlib.sha256(value.encode('utf-8')).hexdigest()
    cases.append(dict(id='scripts.regex-log-search.'+kind,family='scripts',category='whole-script',
        scale='medium',size=size,source=source,fixtureJson=fixture,expectedOutput=output,
        sourceUtf8Bytes=len(source.encode('utf-8')),expectedOutputUtf8Bytes=len(output.encode('utf-8')),
        fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,sourceSha256=hash_text(source),
        fixtureSha256=hash_text(fixture),expectedOutputSha256=hash_text(output),
        expectedFilesSha256=hashlib.sha256(bytes(4)).hexdigest()))
catalog['cases']=[*cases,quote]
representative=comparison/'representative.json'
save(representative,catalog)
save(comparison/'jobs.json',{'warm':[[case['id'],'warm'] for case in catalog['cases']]})
files=metadata['imageFiles']['candidate']
runtime=Path.home()/'.dotnet11'
dotnet=runtime/'dotnet.exe'
protocol=repo/'benchmarks/cpython-worker.py'
assert digest(protocol)==metadata['cpythonWorkerSHA256']
env=dict(os.environ,DOTNET_ROOT=str(runtime),DOTNET_ROOT_X64=str(runtime))
assert len(files)==32 and all(digest(donor/'candidate'/name)==expected for name,expected in files.items())
core='Lokad.Lython.dll'
images={}
helpers={}
for role in ('reference','candidate'):
    image=lab/role
    image.mkdir(exist_ok=True)
    for name in files:
        source=lab/'frozen/bin/Lokad.Lython/release_net11.0'/core if role=='candidate' and name==core else donor/'candidate'/name
        shutil.copyfile(source,image/name)
    for suffix in ('.dll','.deps.json','.runtimeconfig.json'):
        helper='ValidatedAllocation'+suffix
        shutil.copyfile(donor/'candidate'/helper,image/helper)
        helpers[helper]=digest(image/helper)
    observed={name:digest(image/name) for name in files}
    result=comparison/(role+'-verify.json')
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',
        representative,'--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',
        protocol,'--out',result],env=env,check=True,timeout=90)
    proof=read(result)
    assert proof['state']=='Completed' and proof['caseCount']==4 and proof['launched']['library']['sha256']==observed[core]
    assert all(digest(image/name)==expected for name,expected in observed.items())
    assert all(digest(image/name)==expected for name,expected in helpers.items())
    images[role]=observed
assert files==images['reference']
assert [name for name in files if images['reference'][name]!=images['candidate'][name]]==[core]
save(comparison/'identity.json',dict(sourceRevision=reference,candidate=candidate,
    purpose='B1564 call compiled regex pattern methods through the existing shared receiver path',
    imageFiles=images,helperFiles=helpers,cpythonWorkerSHA256=metadata['cpythonWorkerSHA256'],
    expectedCPythonSHA256=metadata['expectedCPythonSHA256'],
    catalogs={name:dict(sha256=digest(comparison/name)) for name in ('representative.json','jobs.json')},
    coreSHA256={label:images[role][core] for role in images for label in (role,role+'-control')}))
shutil.copyfile(donor/'allocations.py',lab/'allocations.py')
