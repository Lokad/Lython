from pathlib import Path
import datetime,hashlib,json,shlex,shutil,subprocess,tarfile
h=Path(__file__).parent;p=h/'b541';p.mkdir();old=h.parent/'complete-transport-r189/b537'
for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','retrieve.py']:
 s=(old/name).read_text(encoding='utf-8').replace('current-work-b537-20261110','prefix-code-b541-20261110').replace('lython-b537-current-work-20261110','lython-b541-prefix-code-20261110').replace('lython-b537','lython-b541')
 if name=='ops-profile.py':
  needle='        folder.mkdir()\n'
  assert needle in s;s=s.replace(needle,needle+'''        env["DOTNET_JitDisasm"] = "*ExecuteInstructionPrefix*"
        env["DOTNET_JitDisasmWithCodeBytes"] = "1"
        env["DOTNET_JitStdOutFile"] = str(folder / "prefix-jit.txt")
''',1)
  s=s.replace('["DOTNET_PerfMapEnabled"]},','["DOTNET_PerfMapEnabled","DOTNET_JitDisasm","DOTNET_JitDisasmWithCodeBytes","DOTNET_JitStdOutFile"]},')
  s=s.replace("{'DOTNET_PerfMapEnabled','DOTNET_JitDisasm','DOTNET_JitStdOutFile'}", "{'DOTNET_PerfMapEnabled','DOTNET_JitDisasm','DOTNET_JitDisasmWithCodeBytes','DOTNET_JitStdOutFile'}")
 if name=='archive.py':
  s=s.replace("assert (p/'perf.map').stat().st_size>0", "assert (p/'perf.map').stat().st_size>0\n assert (p/'prefix-jit.txt').stat().st_size>0")
 if name=='retrieve.py':
  s=s.replace('import json,subprocess\nroot=', 'import fcntl,json,subprocess\nroot=',1)
  s=s.replace("service=subprocess.run(['systemctl'", "lease=(root.parent/'comparison-vm.lock').open('a');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)\nservice=subprocess.run(['systemctl'",1)
 assert 'b537'not in s and 'current-work-'not in s,name
 (p/name).write_text(s,encoding='utf-8',newline='\n')
previous=h.parent/'receiver-native-entry-r192/b540'
frozen=json.loads((previous/'identity.json').read_text(encoding='utf-8'))
source=json.loads((h.parent/'receiver-native-entry-r192/diagnostic/identity.json').read_text(encoding='utf-8'))
identity=dict(sourceRevision='Committed1a83c64f; measured precommitac6edb6f, all567production sources normalize equal. Full CI42792541280 pending, focused/quiet source gates pass.',
 coreSHA256=frozen['coreSHA256']['candidate'],auxiliaryFiles=frozen['auxiliaryFiles'],
 catalogSHA256=hashlib.sha256((previous/'representative.json').read_bytes()).hexdigest(),performanceQualified=False,
 diagnosticOverrides=['DOTNET_PerfMapEnabled=3','DOTNET_JitDisasm=*ExecuteInstructionPrefix*','DOTNET_JitDisasmWithCodeBytes=1','DOTNET_JitStdOutFile=per-workload persisted file'],gcTieringOverrides=False)
(p/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
(p/'core-source.json').write_text(json.dumps({'sourceRevision':identity['sourceRevision'],'coreSHA256':identity['coreSHA256'],'nonincrementalBuildRecorded':True},indent=2)+'\n',encoding='utf-8')
for a,b in [(previous/'representative.json',p/'catalog.json'),(previous/'final-source.json',p/'frozen-core-source.json'),
 (Path('benchmarks/results/2026-11-10-receiver-native-entry/source-promotion-proof.json'),p/'source-equivalence.json'),
 (h/'milestone.md',p/'contract.md'),(Path('PLAN.md'),p/'pre-measurement-plan.md')]:shutil.copyfile(a,b)
(p/'current-source-delta.json').write_text(json.dumps({'source':'1a83c64f committed; current source still equals frozenac6 after EOL normalization.','noPrototypeEditsForCapture':True},indent=2)+'\n',encoding='utf-8')
names=['ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','identity.json','core-source.json','catalog.json','frozen-core-source.json','source-equivalence.json','contract.md','pre-measurement-plan.md','current-source-delta.json']
with tarfile.open(p/'payload.tgz','w:gz')as a:
 for name in names:a.add(p/name,arcname=name)
payload=(p/'payload.tgz').read_bytes()
with tarfile.open(p/'payload.tgz')as a:required=sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+(240+12)*1024*1024+65536
archive=Path('benchmarks/results/2026-11-10-receiver-native-entry/observations.tgz')
assert hashlib.sha256(archive.read_bytes()).hexdigest()==json.loads((previous/'archive-receipt.json').read_text(encoding='utf-8'))['archiveSHA256']
copies=[dict(path='receiver-native-b540-20261110/observations.tgz',bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),canonical=archive.as_posix())]
with tarfile.open(archive)as a:
 for name in ['source-checks.tar.xz','confirmation/confirmation.json']:
  b=a.extractfile(name).read();copies.append(dict(path='receiver-native-b540-20261110/'+name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),canonical=archive.as_posix()+':'+name))
(p/'exact-copies.json').write_text(json.dumps(copies,indent=2)+'\n',encoding='utf-8')
script=r'''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks').resolve();root=base/'prefix-code-b541-20261110'
source=base/'receiver-native-b540-20261110/candidate'
copies=COPIES
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists()and not Path('/dev/shm/lython-b541').exists()
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(PAYLOADPLUS);assert len(payload)==PAYLOADSIZE and hashlib.sha256(payload).hexdigest()=='PAYLOADSHA'
 before=shutil.disk_usage(base).free;required=REQUIRED
 receipts=[]
 if before<=required:
  reclaim=0
  for c in copies:
   path=base/c['path'];assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(path.lstat().st_mode)
   s=path.stat();assert s.st_uid==os.getuid()and s.st_nlink==1 and s.st_size==c['bytes']
   assert hashlib.sha256(path.read_bytes()).hexdigest()==c['sha256'];reclaim+=s.st_blocks*512
   receipts.append(dict(c,allocatedBytes=s.st_blocks*512,allAliases=[str(path)]))
  assert before+reclaim>required,(before,reclaim,required)
  for c in copies:(base/c['path']).unlink()
 assert shutil.disk_usage(base).free>required
 recovery=dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,requiredFreeBytes=required,files=receipts,
  freshIdleLease=True,osFloorMiB=240,evidenceHeadroomMiB=12,operation='Exact canonical B540 terminal copies only; currentac6 and last-qualifiede364 images retained.')
 assert hashlib.sha256((base/'receiver-native-b540-20261110/current-core.dll').read_bytes()).hexdigest()=='ac6edb6fc361dba9195d973830a5ca02caac10b62cc6d041f134ce31ef9a10d3'
 assert hashlib.sha256((base/'dictionary-cpython-b539-20261110/current-core.dll').read_bytes()).hexdigest()=='e364e4d94ad8015fc8492760cad235475b5943aa6687d681edbb14692e4956f0'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:root.mkdir();a.extractall(root,filter='data')
 (root/'space-recovery.json').write_text(json.dumps(recovery,indent=2)+'\n')
 os.link(source/'Lokad.Lython.dll',root/'current-core.dll');shutil.copytree(source,root/'candidate',copy_function=os.link)
 identity=json.loads((root/'identity.json').read_text())
 for name,digest in {**identity['auxiliaryFiles'],'Lokad.Lython.dll':identity['coreSHA256']}.items():
  assert hashlib.sha256((root/'candidate'/name).read_bytes()).hexdigest()==digest,name
 for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture=Path('/dev/shm/lython-b541');fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b541-fixtures',str(fixture)],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndAuxiliaryImagesVerified=True,ownerSeconds=120,stopSeconds=30,
  observationMarginSeconds=30,osFloorMiB=240,traceArchiveHeadroomMiB=12,diagnosticOnly=True)
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
try:
 subprocess.run(['sudo','-n','systemd-run','--unit=lython-b541-prefix-code-20261110','--property=User=lokad',
  '--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=120','--property=TimeoutStopSec=30',
  '--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show','lython-b541-prefix-code-20261110.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert 'ActiveState=active'in live and 'MainPID=0'not in live
print(live,flush=True)
'''.replace('COPIES',repr(copies)).replace('PAYLOADPLUS',str(len(payload)+1)).replace('PAYLOADSIZE',str(len(payload))).replace('PAYLOADSHA',hashlib.sha256(payload).hexdigest()).replace('REQUIRED',str(required))
(p/'launch-command.py').write_text(script,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
stage='/home/lokad/lython-bench-checks/prefix-jit-b541-launch.py'
code='from pathlib import Path;import sys;p=Path('+repr(stage)+');assert not p.exists();p.write_bytes(sys.stdin.buffer.read())'
r=subprocess.run([*ssh,'python3 -c '+shlex.quote(code)],input=script.encode('utf-8'),capture_output=True);assert r.returncode==0,r.stderr
r=subprocess.run([*ssh,'python3 '+stage],input=payload,capture_output=True)
(p/'launch.log').write_bytes(r.stdout+b'\n'+r.stderr);assert r.returncode==0,r.stderr.decode('utf-8')
assert b'ActiveState=active'in r.stdout and b'MainPID=0'not in r.stdout
now=datetime.datetime.now(datetime.timezone.utc)
(p/'observe-not-before.json').write_text(json.dumps(dict(acknowledgedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=180)).isoformat(),ownerSeconds=120,stopSeconds=30,marginSeconds=30),indent=2)+'\n',encoding='utf-8')
print(r.stdout.decode('utf-8'));print('Observe after',(now+datetime.timedelta(seconds=180)).isoformat(),flush=True)
