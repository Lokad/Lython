from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks').resolve();root=base/'prefix-code-b541-20261110'
source=base/'receiver-native-b540-20261110/candidate'
copies=[{'path': 'receiver-native-b540-20261110/observations.tgz', 'bytes': 4055722, 'sha256': 'a38831276d7c09e8ef6d996ac440b9643c8ae3f07c37dc0c1d66631a1bf893ff', 'canonical': 'benchmarks/results/2026-11-10-receiver-native-entry/observations.tgz'}, {'path': 'receiver-native-b540-20261110/source-checks.tar.xz', 'bytes': 48980, 'sha256': '3b599da1905a0f5d8ce3fc6fc761715365739ea248216d1739283f3cd1c816d6', 'canonical': 'benchmarks/results/2026-11-10-receiver-native-entry/observations.tgz:source-checks.tar.xz'}, {'path': 'receiver-native-b540-20261110/confirmation/confirmation.json', 'bytes': 279483, 'sha256': '7faf22f9c88f2d1c25694f693d2a48cf6694c4861b4158e6bf78b0b8c1d1f7a2', 'canonical': 'benchmarks/results/2026-11-10-receiver-native-entry/observations.tgz:confirmation/confirmation.json'}, {'path': 'receiver-native-b540-20261110/representative.json', 'bytes': 711275, 'sha256': 'a8841a9ce2fe3ca3add6da045d83c05277197f237ca71aa3d0f8c524416b1f62', 'canonical': 'benchmarks/results/2026-11-10-receiver-native-entry/observations.tgz:representative.json'}]
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists()and not Path('/dev/shm/lython-b541').exists()
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(55832);assert len(payload)==55831 and hashlib.sha256(payload).hexdigest()=='fffc5578d087936ceb80e7b300fd0921c2c31f0b147c4e130fb169d96847c0be'
 before=shutil.disk_usage(base).free;required=265170944
 receipts=[]
 if before<=required:
  reclaim=0
  for c in copies:
   path=base/c['path'];assert path.resolve(strict=True).is_relative_to(base)and stat.S_ISREG(path.lstat().st_mode)
   s=path.stat();assert s.st_uid==os.getuid()and s.st_nlink==1 and s.st_size==c['bytes']
   assert hashlib.sha256(path.read_bytes()).hexdigest()==c['sha256'];reclaim+=s.st_blocks*512
   receipts.append(dict(c,allocatedBytes=s.st_blocks*512,allAliases=[str(path)]))
  assert before+reclaim>required,(before,reclaim,required)
  for c in copies:(base/c['path']).unlink()
 assert shutil.disk_usage(base).free>required
 recovery=dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,requiredFreeBytes=required,files=receipts,
  freshIdleLease=True,osFloorMiB=240,evidenceHeadroomMiB=12,operation='Exact canonical B540 terminal copies only; currentac6 and last-qualifiede364 images retained.')
 assert hashlib.sha256((base/'receiver-native-b540-20261110/current-core.dll').read_bytes()).hexdigest()=='ac6edb6fc361dba9195d973830a5ca02caac10b62cc6d041f134ce31ef9a10d3'
 assert hashlib.sha256((base/'dictionary-cpython-b539-20261110/current-core.dll').read_bytes()).hexdigest()=='e364e4d94ad8015fc8492760cad235475b5943aa6687d681edbb14692e4956f0'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:root.mkdir();a.extractall(root,filter='data')
 (root/'space-recovery.json').write_text(json.dumps(recovery,indent=2)+'\n')
 os.link(source/'Lokad.Lython.dll',root/'current-core.dll');shutil.copytree(source,root/'candidate',copy_function=os.link)
 identity=json.loads((root/'identity.json').read_text())
 for name,digest in {**identity['auxiliaryFiles'],'Lokad.Lython.dll':identity['coreSHA256']}.items():
  assert hashlib.sha256((root/'candidate'/name).read_bytes()).hexdigest()==digest,name
 for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture=Path('/dev/shm/lython-b541');fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b541-fixtures',str(fixture)],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndAuxiliaryImagesVerified=True,ownerSeconds=120,stopSeconds=30,
  observationMarginSeconds=30,osFloorMiB=240,traceArchiveHeadroomMiB=12,diagnosticOnly=True)
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
try:
 subprocess.run(['sudo','-n','systemd-run','--unit=lython-b541-prefix-code-20261110','--property=User=lokad',
  '--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=120','--property=TimeoutStopSec=30',
  '--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show','lython-b541-prefix-code-20261110.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert 'ActiveState=active'in live and 'MainPID=0'not in live
print(live,flush=True)
