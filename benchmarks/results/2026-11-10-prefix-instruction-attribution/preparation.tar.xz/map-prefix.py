from pathlib import Path
import bisect,collections,json,re

h=Path(__file__).parent;p=h/'b541/retrieved'
def methods(path):
 result=[]
 for chunk in re.split(r'(?=; Assembly listing for method )',path.read_text(encoding='utf-8')):
  if not chunk.startswith('; Assembly')or'ExecuteInstructionPrefix('not in chunk.splitlines()[0]:continue
  header=chunk.splitlines()[0];position=0;groups=[];current=None;errors=[]
  for line in chunk.splitlines():
   group=re.match(r'^(G_M\d+_IG\d+):\s*;; offset=0x([0-9A-Fa-f]+)',line)
   if group:
    offset=int(group[2],16)
    if offset!=position:errors.append(dict(label=group[1],declared=offset,counted=position))
    current=dict(label=group[1],offset=offset,instructions=[]);groups.append(current)
   if m:=re.match(r'^\s+([0-9A-F]{2,30})\s+([a-z].*)$',line):
    if len(m[1])%2 or current is None:errors.append(dict(invalidInstruction=line));continue
    current['instructions'].append(dict(offset=position,codeBytes=m[1],assembly=m[2]));position+=len(m[1])//2
  declared=[int(v)for v in re.findall(r'; Total bytes of code (\d+)',chunk)]
  if declared!=[position]:errors.append(dict(declaredSize=declared,counted=position))
  tier='OptimizedTier1OSR'if'Tier1-OSR'in header else'OptimizedTier1'if'Tier1'in header else'InstrumentedTier'if'Instrumented Tier0'in header else'QuickJitted'
  result.append(dict(header=header,tier=tier,bytes=position,groups=groups,valid=not errors,errors=errors))
 return result

all_rows=[]
for case in ['csv-warm','text-warm']:
 folder=p/'profiles'/case;record=json.loads((folder/'record.json').read_text(encoding='utf-8'))
 parsed=methods(folder/'prefix-jit.txt')
 maps=[]
 for line in(folder/'perf.map').read_text(encoding='utf-8').splitlines():
  parts=line.split(' ',2)
  if len(parts)==3 and'::ExecuteInstructionPrefix('in parts[2]:
   start,size,name=parts;maps.append(dict(start=int(start,16),size=int(size,16),name=name,tier=re.search(r'\[([^\]]+)\]$',name)[1]))
 mappings=[]
 for m in maps:
  candidates=[(i,v)for i,v in enumerate(parsed)if v['valid']and v['bytes']==m['size']and v['tier']==m['tier']]
  mappings.append(dict(m,unique=len(candidates)==1,matchedHeader=candidates[0][1]['header']if len(candidates)==1 else None,matchedIndex=candidates[0][0]if len(candidates)==1 else None))
 guest=set(record['guestTids']);counts=collections.Counter();prefix=unknown=total=0
 for line in(folder/'perf-leaves.txt').read_text(encoding='utf-8').splitlines():
  r=re.match(r'\s*(\d+)/(\d+)\s+([0-9a-fx]+)\s*(.*)',line)
  if not r or r[2]not in guest:continue
  total+=1;address=int(r[3],16)
  ranges=[m for m in mappings if m['start']<=address<m['start']+m['size']]
  if not ranges:continue
  prefix+=1
  if len(ranges)!=1 or not ranges[0]['unique']:unknown+=1;continue
  m=ranges[0];body=parsed[m['matchedIndex']];offset=address-m['start']
  index=bisect.bisect_right([g['offset']for g in body['groups']],offset)-1
  if index<0:unknown+=1;continue
  group=body['groups'][index]
  if not any(i['offset']<=offset<i['offset']+len(i['codeBytes'])//2 for i in group['instructions']):unknown+=1;continue
  counts[(m['matchedIndex'],group['label'])]+=1
 top=[]
 for(index,label),count in counts.most_common():
  body=parsed[index];header=body['header'];group=next(g for g in body['groups']if g['label']==label)
  top.append(dict(samples=count,shareOfGuestSamples=100*count/total,header=header,methodIndex=index,methodCodeBytes=body['bytes'],**group))
 row=dict(case=case,totalGuestSamples=total,prefixLeafSamples=prefix,unknownPrefixSamples=unknown,matchedPrefixSamples=prefix-unknown,
  parsedMethods=[{k:v for k,v in m.items()if k!='groups'}for m in parsed],mapMatches=mappings,topGroups=top,
  limitation='Exact code-size/tier and instruction/group-offset checks; group samples include useful operations. No dispatch tax or CPU gain inferred.')
 all_rows.append(row)
 print(case,'guest',total,'prefix',prefix,'matched',prefix-unknown,'unknown',unknown,
       'methods',[(m['tier'],m['bytes'],m['valid'])for m in parsed],flush=True)
 print('top groups',[(r['samples'],r['label'],r['instructions'][:2])for r in top[:5]],flush=True)
(h/'prefix-mapping.json').write_text(json.dumps(all_rows,indent=2)+'\n',encoding='utf-8',newline='\n')
