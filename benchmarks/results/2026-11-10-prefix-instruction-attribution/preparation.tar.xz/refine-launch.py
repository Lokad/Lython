from pathlib import Path
import datetime,hashlib,json,shlex,shutil,subprocess,tarfile
p=Path(__file__).parent/'b541'
assert not(p/'observe-not-before.json').exists()
for name in ['launch-command.py','launch.log']:shutil.copyfile(p/name,p/('first-'+name))
old=json.loads((p/'exact-copies.json').read_text(encoding='utf-8'));new=list(old)
archive=Path('benchmarks/results/2026-11-10-receiver-native-entry/observations.tgz')
with tarfile.open(archive)as a:b=a.extractfile('representative.json').read()
new.append(dict(path='receiver-native-b540-20261110/representative.json',bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),canonical=archive.as_posix()+':representative.json'))
(p/'exact-copies-refined.json').write_text(json.dumps(new,indent=2)+'\n',encoding='utf-8')
script=(p/'launch-command.py').read_text(encoding='utf-8');assert'copies='+repr(old)in script
script=script.replace('copies='+repr(old),'copies='+repr(new),1)
(p/'launch-refined-command.py').write_text(script,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
stage='/home/lokad/lython-bench-checks/prefix-jit-b541-refined-launch.py'
code='from pathlib import Path;import sys;p=Path('+repr(stage)+');assert not p.exists();p.write_bytes(sys.stdin.buffer.read())'
r=subprocess.run([*ssh,'python3 -c '+shlex.quote(code)],input=script.encode('utf-8'),capture_output=True);assert r.returncode==0,r.stderr
r=subprocess.run([*ssh,'python3 '+stage],input=(p/'payload.tgz').read_bytes(),capture_output=True)
(p/'launch-refined.log').write_bytes(r.stdout+b'\n'+r.stderr);assert r.returncode==0,r.stderr.decode('utf-8')
assert b'ActiveState=active'in r.stdout and b'MainPID=0'not in r.stdout
now=datetime.datetime.now(datetime.timezone.utc)
(p/'observe-not-before.json').write_text(json.dumps(dict(acknowledgedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=180)).isoformat(),ownerSeconds=120,stopSeconds=30,marginSeconds=30),indent=2)+'\n',encoding='utf-8')
print(r.stdout.decode('utf-8'));print('Observe after',(now+datetime.timedelta(seconds=180)).isoformat(),flush=True)
