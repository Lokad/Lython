from pathlib import Path
import hashlib,json,shutil,tarfile
root=Path('D:/code/Lython');h=Path(__file__).parent;p=h/'b541';d=root/'benchmarks/results/2026-11-10-prefix-instruction-attribution';d.mkdir()
receipt=json.loads((p/'archive-receipt.json').read_text(encoding='utf-8'))
assert receipt['complete']and hashlib.sha256((p/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
rows=json.loads((h/'prefix-mapping.json').read_text(encoding='utf-8'))
assert[(r['prefixLeafSamples'],r['matchedPrefixSamples'],r['unknownPrefixSamples'])for r in rows]==[(168,168,0),(269,269,0)]
assessment=[]
for r,labels in zip(rows,[['G_M000_IG07','G_M000_IG08','G_M000_IG09'],['G_M000_IG09','G_M000_IG11','G_M000_IG12']]):
 groups=[g for g in r['topGroups']if g['label']in labels];count=sum(g['samples']for g in groups)
 assessment.append(dict(case=r['case'],guestSamples=r['totalGuestSamples'],prefixLeafSamples=r['prefixLeafSamples'],
  commonFetchCheckDispatchEntrySamples=count,commonShareOfGuestSamples=100*count/r['totalGuestSamples'],groups=groups,
  interpretation='Observed common loop/fetch/check/dispatch-entry blocks, including required cancellation/admission checks; not removable-cost or speedup estimates.'))
(d/'assessment.json').write_text(json.dumps(assessment,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['observations.tgz','archive-receipt.json','terminal-status.json','identity.json','core-source.json','source-equivalence.json','extraction.json','exact-copies-refined.json']:
 shutil.copyfile(p/name,d/name)
for name in ['prefix-mapping.json','mapping-correction.json','milestone.md','format-check.json','format-byte-counts.json','format-byte-counts-corrected.json']:
 shutil.copyfile(h/name,d/name)
shutil.copyfile(p/'retrieved/space-recovery.json',d/'space-recovery.json')
with tarfile.open(d/'preparation.tar.xz','w:xz')as a:
 for item in h.iterdir():
  if item.is_file()and item.suffix in ['.py','.md','.json','.txt']:a.add(item,arcname=item.name)
 for item in p.iterdir():
  if item.is_file()and item.suffix in ['.py','.md','.json','.log']and item.name not in ['catalog.json','pre-measurement-plan.md']:
   a.add(item,arcname='b541/'+item.name)
(d/'README.md').write_text('''# Executable-prefix instruction attribution — R193

2026-11-10, committed1a83c64f-equivalent frozenac6edb6f; R192 focused/quiet gates
pass, full deliveryCI42792541280 is pending separately. Same complete maintained
CSV/text scripts, worker/adapter0.4/dependencies/goldens. F4as_v7 Ubuntu24.04.4,
actual.NET11RC3, ordinaryGC/tiering plus explicit perf-map/JIT-output diagnostics.
Two6second warmups/captures;12.033execution seconds, no elapsed comparison.

| Complete script | Guest samples | Prefix leaves | Mapped prefix leaves | Three common fetch/check/dispatch-entry blocks |
| --- | ---: | ---: | ---: | ---: |
| Validated CSV | 1217 | 168 | 168 | 100 (8.22%guest) |
| Text summary | 1149 | 269 | 269 | 116 (10.10%guest) |

Every mapped sample matches a unique method version by tier and exact code size,
then a validated native instruction/group offset. All group offsets and code-byte
sums match the JIT's declared sizes. Mapping ambiguity is zero for these prefix
leaves; this does not claim zero unknowns in the wider profile. Selected methods
are final Tier1,10822/13657bytes. Required checks and useful work remain inside
these shares; no dispatch tax or speedup follows from inclusive categories.

The common blocks reload the current position/array bounds, form the instruction,
check admission/cancellation, and enter opcode dispatch. The loop's jumped local
is stored/read on the stack across the per-instruction exception boundary. This
supports assessing a continuous instruction run with cold exception routing and
unchanged per-instruction failure checks. It does not prove the exception region
causes every reload/spill or that changing it will improve CPU. Native call/input
groups still perform useful work; don't replace the existing engine with an arena
or routing protocol on the basis of these samples.

Bounded source checks reject absent costs: module facts already share preparation,
native CSV feeds its owned parser buffer, valid JSON strings already avoid CLR
string roundtrips, and short split fragments already use inline storage. No product
code changed for this attribution. No cancellation check/frequency change selected.

The installed SDK's local format check uses the documented
[JIT disassembly options](https://github.com/dotnet/runtime/blob/main/docs/design/coreclr/jit/viewing-jit-dumps.md).
Its first byte counter accidentally counted lowercase jump-table dd directives as
hex bytes; the same output validates after a parser correction, without rerunning.
The mapping subsequently uses exact compilation indexes: two OSR bodies can share
a header but differ in size. All observed sampled groups/instructions are unchanged
by this correction. Both originals and corrections remain.

Identity/output/ownership/quiet checks, Closed/joined workers, temporary-map retirement,
RAM removal, archive-under-lease and localSHA pass. TerminalB541 cached. Initial
staging refused28KiB-short predicted free space without mutation; exact additional
archived catalog-copy retirement fixes sizing, preserving currentac6/qualifiede364.
No measurement restarted, active image or sole evidence retired. Publication off.

[Assessment](assessment.json), [exact mapping/assembly groups](prefix-mapping.json),
[raw samples/maps/JIT output](observations.tgz), [receipt](archive-receipt.json),
[source proof](source-equivalence.json), [prospective scope](milestone.md),
[tooling/original failures/corrections](preparation.tar.xz), [retirement receipt](space-recovery.json).
''',encoding='utf-8',newline='\n')
f=root/'benchmarks/EXPERIMENTS.md';s=f.read_text(encoding='utf-8');i=s.index('The [R192 receiver-aware native entry]')
s=s[:i]+'''The [R193 instruction attribution](results/2026-11-10-prefix-instruction-attribution/README.md)
maps all168CSV/269text prefix leaves to validated code-size/tier/native offsets.
Three common fetch/check/dispatch-entry blocks contain8.22/10.10%guest samples,
including required checks; no removable-tax or speedup estimate follows. It selects
a bounded exception-boundary/loop-bookkeeping assessment, not another call arena or
routing framework. Original parser/setup conditions and corrections remain.

'''+s[i:];f.write_text(s,encoding='utf-8',newline='\n')
f=root/'.gitattributes';s=f.read_text(encoding='utf-8');s+='\nbenchmarks/results/2026-11-10-prefix-instruction-attribution/** -text whitespace=cr-at-eol\n';f.write_text(s,encoding='utf-8',newline='\n')
f=root/'PLAN.md';s=f.read_text(encoding='utf-8');a=s.index('**Next bounded R193 attribution:**');b=s.index('**Bounded text-storage assessment:**',a)
s=s[:a]+'''**R193 attribution complete:** two existing CSV/text captures,12.033s; all gates/
SHA pass, all168/269prefix leaves map exactly by code size/tier/native offsets.
Common fetch/check/dispatch-entry blocks contain100/1217CSV (8.22%) and116/1149text
(10.10%)samples, including required checks. No removable-tax or speedup estimate.
Evidence: benchmarks/results/2026-11-10-prefix-instruction-attribution/. No further
unchanged collection is selected. Module facts/CSV input/valid JSON conversions
already share/directly construct storage; those absent costs do not justify work.

'''+s[b:];f.write_text(s,encoding='utf-8',newline='\n')
print('R193 evidence/source gates recorded; no product changes or speedup claim.')
