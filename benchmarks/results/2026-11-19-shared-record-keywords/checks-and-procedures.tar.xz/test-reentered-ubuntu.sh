export DOTNET_ROOT=~/.dotnet
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/shared-record-keywords-r693
~/.dotnet/dotnet test tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter FullyQualifiedName~TrailingExactKeywordsKeepAdmissionAtomic >"$lab/reentered-ubuntu.log" 2>&1
result=$?
tail -n 13 "$lab/reentered-ubuntu.log"
exit "$result"