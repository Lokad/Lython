from pathlib import Path

lab = Path(__file__).resolve().parent
template = lab.parent / 'parallel-assignment-cpython-20261123/prepare.py'
source = template.read_text(encoding='utf-8')
for old,new in (
    ("tracked = 'benchmarks/results/2026-11-23-parallel-assignment-operands/'",
     "tracked = 'benchmarks/results/2026-11-23-short-csv-utf8-slots/'"),
    ("proof = json.loads(pushed('identity.json'))\nprefix = ''\nif proof['retainedRevision'] is None:\n    proof = json.loads(pushed('refined-identity.json'))\n    prefix = 'refined-'\n    donor = donor / 'refinement'",
     "prefix = 'typed-reader-'\nproof = json.loads(pushed(prefix + 'identity.json'))"),
    ("parallel-assignment-operands-20261123", "csv-short-utf8-20261123/typed-reader"),
    ("names = {explicit, typed}", "names = {explicit}"),
    (", [typed, 'warm']", ""),
    ("verified['caseCount'] == 2", "verified['caseCount'] == 1"),
    ("parallel-assignment-cpython-b1518-resolved-20261123", "short-csv-utf8-cpython-b1521-20261123"),
    ("'len(jobs) == 4'", "'len(jobs) == 3'"),
    ("'<220,'", "'<175,'"),
    ("lython-b1518-fixtures", "lython-b1521-fixtures"),
    ("CPython checkpoint after direct assignment lowering", "CPython checkpoint after deferred CSV fields"),
    ("'len(raw[\\\"jobs\\\"])==4'", "'len(raw[\\\"jobs\\\"])==3'"),
    ("'receipt[\\\"warmJobs\\\"]==4'", "'receipt[\\\"warmJobs\\\"]==3'"),
    ("original=('parallel-assignment-refined-b1517-20261123' if prefix else 'parallel-assignment-b1517-20261123')",
     "original='csv-short-utf8-typed-reader-b1520-20261123'"),
    ("\"reference='direct-closed-defaults-b1515-20261123'\"", "\"reference='parallel-assignment-refined-b1517-20261123'\""),
    ("lython-b1518-parallel-assignment-cpython-20261123", "lython-b1521-short-csv-utf8-cpython-20261123"),
    (".+b1518-", ".+b1521-"),
    ("lython-b1518-stage-", "lython-b1521-stage-"),
    ("'Seven bounded lanes'\", \"'Four bounded lanes'", "'Seven bounded lanes'\", \"'Three bounded lanes'"),
    ("89 * 1024 * 1024", "65 * 1024 * 1024"),
    ("An 89 MiB", "A 65 MiB"),
    ("RuntimeMaxSec=260", "RuntimeMaxSec=210"),
    ("seconds=210", "seconds=157"),
):
    assert source.count(old)==1,old
    source = source.replace(old,new)
exec(compile(source, str(template), 'exec'))

