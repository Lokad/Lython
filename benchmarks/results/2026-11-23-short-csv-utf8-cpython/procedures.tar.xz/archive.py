from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile


lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / 'comparison/quiet'
dest = repo / 'benchmarks/results/2026-11-23-short-csv-utf8-cpython'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
sha = lambda data: hashlib.sha256(data).hexdigest()
digest = lambda path: sha(path.read_bytes())
git = lambda *args: subprocess.check_output(['git', *args], cwd=repo)
identity = read(quiet / 'identity.json')
status = read(quiet / 'terminal-status.json')
receipt = status['receipt']
assert not status['live'] and not status['fixtures'] and status['exitCode'] == '0'
assert all(receipt[key] for key in ('complete', 'archivedAndVerifiedUnderLease', 'allWorkersJoined', 'guestFixturesRemoved', 'quietBeforeAndAfter'))
assert digest(quiet / 'observations.tar.xz') == receipt['archiveSHA256']
assert read(quiet / 'summary.json')['timedBatches'] == 84
assert not git('diff', '--name-only', identity['sourceRevision'], identity['candidate'], '--', 'src')
assert not git('diff', '--name-only', identity['sourceRevision'], identity['deliveryRevision'], '--', 'src')
changed = git('diff','--name-only',identity['sourceRevision'],'origin/master','--','src').decode().splitlines()
assert set(changed) <= {
    'src/Lokad.Lython/Runtime/LythonRuntime.RegexCompiler.cs',
    'src/Lokad.Lython/Runtime/LythonRuntime.RegexObjects.cs',
}
image = lab.parent / 'csv-short-utf8-20261123/typed-reader/candidate'
files = identity['imageFiles']['candidate']
assert len(files) == 32 and all(digest(image / name) == expected for name, expected in files.items())
core = dest.parent / '2026-11-23-short-csv-utf8-slots/typed-reader-core.dll.gz'
assert sha(gzip.decompress(core.read_bytes())) == files['Lokad.Lython.dll']
dest.mkdir(exist_ok=True)
assert all(path.name == 'README.md' for path in dest.iterdir())
for name in ('observations.tar.xz', 'identity.json', 'summary.json', 'terminal-status.json'):
    shutil.copyfile(quiet / name, dest / name)
with tarfile.open(dest / 'procedures.tar.xz', 'w:xz') as tar:
    for name in ('archive.py', 'prepare.py', 'quiet.py', 'prepare.log', 'prepare-first.log', 'launch.log', 'retrieval.log',
        'comparison/quiet/observe-not-before', 'comparison/quiet/candidate-verify.json', 'comparison/quiet/summarize.py'):
        tar.add(lab / name, arcname=name)
print(dest)
