"""One-off R467 attribution: unchanged worker semantics, added clocks and natural-GC observations; not elapsed qualification."""
from pathlib import Path
import builtins,gc,importlib.util,json,sys,time
spec=importlib.util.spec_from_file_location('worker',Path(__file__).with_name('cpython-worker.py'))
w=importlib.util.module_from_spec(spec);spec.loader.exec_module(w)
totals={name:0 for name in ['compileNs','invokeNs','execNs','resetNs','validationNs','gcNs','gcCollections0','gcCollections1','gcCollections2','invocations','compilations']}
previous=totals.copy();gc_start={}
def on_gc(phase,info):
 generation=info['generation']
 if phase=='start':gc_start[generation]=time.perf_counter_ns()
 else:
  start=gc_start.pop(generation,None)
  if start is not None:totals['gcNs']+=time.perf_counter_ns()-start
  totals['gcCollections'+str(generation)]+=1
gc.callbacks.append(on_gc)
def wrap(name,counter,count=None):
 original=getattr(w,name)
 def measured(*args,**kwargs):
  start=time.perf_counter_ns()
  try:return original(*args,**kwargs)
  finally:
   totals[counter]+=time.perf_counter_ns()-start
   if count:totals[count]+=1
 setattr(w,name,measured)
wrap('compile_case','compileNs','compilations');wrap('invoke','invokeNs','invocations');wrap('reset_files','resetNs');wrap('read_file_outputs','validationNs')
def measured_exec(code,namespace):
 start=time.perf_counter_ns()
 try:return builtins.exec(code,namespace)
 finally:totals['execNs']+=time.perf_counter_ns()-start
w.exec=measured_exec
original_response=w.response
def response(*args,**kwargs):
 global previous
 r=original_response(*args,**kwargs)
 r['phaseDiagnostics']={k:v-previous[k]for k,v in totals.items()};previous=totals.copy()
 return r
w.response=response
raise SystemExit(w.main())
