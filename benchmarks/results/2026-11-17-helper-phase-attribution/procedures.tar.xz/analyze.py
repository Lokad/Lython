from pathlib import Path
import json,statistics

root=Path(__file__).parent
raw=json.loads((root/'retrieved/confirmation/confirmation.json').read_text(encoding='utf-8'))
assert raw['complete']and len(raw['jobs'])==4
median=statistics.median
rows=[]
for job in raw['jobs']:
    engines={}
    for engine in job['identities']:
        phases={}
        for lane in ['warm','compile-run']:
            samples=[s for s in job['samples']if s['engine']==engine and s['lane']==lane]
            assert len(samples)==5
            guest=[s['response']['elapsedTicks']/s['response']['clockFrequency']/s['response']['completedInvocations']*1000 for s in samples]
            cpu=[s['externalProcessCpuTicks']/s['externalCpuFrequency']/s['response']['completedInvocations']*1000 for s in samples]
            phases[lane]=dict(guestMedianMs=median(guest),allGuestMs=guest,processCpuMedianMs=median(cpu),allProcessCpuMs=cpu,requestMedianMs=median(s['requestSeconds']/s['response']['completedInvocations']*1000 for s in samples))
            if job['diagnostic']:
                components={key:median(s['response']['phaseDiagnostics'][key]/s['response']['completedInvocations']/1e6 for s in samples)for key in ['compileNs','invokeNs','execNs','resetNs','validationNs','gcNs']}
                collections={key:sum(s['response']['phaseDiagnostics'][key]for s in samples)for key in ['gcCollections0','gcCollections1','gcCollections2']}
                phases[lane].update(instrumentedComponentsMs=components,naturalGcCollections=collections)
        phases['sameProcessFreshOverWarm']=phases['compile-run']['guestMedianMs']/phases['warm']['guestMedianMs']
        phases['sameProcessCpuFreshOverWarm']=phases['compile-run']['processCpuMedianMs']/phases['warm']['processCpuMedianMs']
        engines[engine]=phases
    rows.append(dict(case=job['case'],instrumented=job['diagnostic'],engines=engines))
summary=dict(source='ccf20ba3/frozen7a599347, fully qualified runtime; no production changes',collection='R467/B873',elapsedSeconds=raw['elapsedSeconds'],complete=True,rows=rows,limits=['Same-process alternating phases differ from independently warmed published lanes; original B872 results remain unchanged.','Instrumented Python component clocks and GC callbacks add work; no overhead subtraction or source-performance claim.','Component clocks are inclusive and overlap natural GC; no sum/subtraction of separately warmed medians.','External CPU includes fixture reset/protocol; coarse process tick observations remain raw.'])
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
for row in rows:
 print(row['case'],'instrumented',row['instrumented'])
 for engine,p in row['engines'].items():
  print(engine,'warm',round(p['warm']['guestMedianMs'],4),'fresh',round(p['compile-run']['guestMedianMs'],4),'ratio',round(p['sameProcessFreshOverWarm'],4),'CPUratio',round(p['sameProcessCpuFreshOverWarm'],4))
  if row['instrumented']:
   for lane in ['warm','compile-run']:print(lane,p[lane]['instrumentedComponentsMs'],p[lane]['naturalGcCollections'])
