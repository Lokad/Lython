from pathlib import Path
import json
import subprocess
import sys

lab = Path(__file__).resolve().parent
prior = lab.parent / 'source-annotation-mode-r714'
load = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
catalog = load(lab.parent / 'function-binding-inline-r712' / 'catalog.json')
reused = next(case for case in load(lab.parent / 'grouped-definition-admission-r607' / 'catalog.json')['cases']
              if case['id'] == 'calls.defaults.medium')
catalog['cases'].append(reused)
assert len(catalog['cases']) == 6
(lab / 'catalog.json').write_text(json.dumps(catalog, indent=2, ensure_ascii=False) + '\n',
                                encoding='utf-8', newline='\n')
freeze = (prior / 'freeze-and-verify.py').read_text(encoding='utf-8')
freeze = freeze.replace('source-annotation-mode-r714', 'keyword-default-record-r715').replace("'802c7130e'", "'c76c59159'")
assert "git('rev-parse','c76c59159')" in freeze and '["cases"]) == 6' in freeze
(lab / 'freeze-and-verify.py').write_text(freeze, encoding='utf-8', newline='\n')
subprocess.run([sys.executable, '-X', 'utf8', lab / 'freeze-and-verify.py'], check=True)
allocation = lab.parent / 'postfix-statement-r699' / 'measure-compile-allocation.py'
subprocess.run([sys.executable, '-X', 'utf8', allocation, lab], check=True)
