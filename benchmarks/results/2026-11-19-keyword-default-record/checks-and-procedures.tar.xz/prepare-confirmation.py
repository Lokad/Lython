from pathlib import Path
import subprocess
import sys

lab = Path(__file__).resolve().parent
template = lab.parent / 'function-binding-inline-r712' / 'prepare-confirmation.py'
source = template.read_text(encoding='utf-8')
source = source.replace('function-binding-inline-b1142-confirmation-corrected', 'keyword-default-record-b1147')
source = source.replace('lython-b1142-function-binding-inline-confirmation-corrected', 'lython-b1147-keyword-default-record')
source = source.replace('lython-b1142-control-fixtures', 'lython-b1147-control-fixtures')
start = source.index('jobs = [')
end = source.index('\nassert all(case', start)
jobs = [('scripts.csv-invoice.large','warm'), ('scripts.annotated-rule-closures','warm'),
        ('calls.defaults.medium','warm')]
source = source[:start] + 'jobs = ' + repr(jobs) + source[end:]
source = source.replace('# All three original jobs used the reversed worker order.',
                        '# Reverse the order of each input relative to its B1146 lane.')
source = source.replace("code=code.replace('            if job_index >= 2: labels.reverse()\\n','')",
                        "code=code.replace('            if job_index >= 2: labels.reverse()\\n','            if job_index == 1: labels.reverse()\\n')")
assert 'if job_index == 1: labels.reverse()' in source
(lab / 'build-confirmation.py').write_text(source, encoding='utf-8', newline='\n')
subprocess.run([sys.executable, '-X', 'utf8', lab / 'build-confirmation.py'], check=True)
