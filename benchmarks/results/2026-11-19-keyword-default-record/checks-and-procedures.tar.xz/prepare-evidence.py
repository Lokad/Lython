from pathlib import Path
import subprocess
import sys

lab = Path(__file__).resolve().parent
prior = lab.parent / 'source-annotation-mode-r714'
archive = (prior / 'archive-evidence.py').read_text(encoding='utf-8')
archive = archive.replace('2026-11-19-source-annotation-mode', '2026-11-19-keyword-default-record')
archive = archive.replace("'public-ubuntu.log', 'white-ubuntu.log', 'source-pair.log',",
                          "'public-ubuntu.log', 'white-ubuntu.log', 'source-pair.log', 'alias-cpython.txt',")
archive = archive.replace('initial = verify("quiet", 6, "quiet-summary.json")',
    'initial = verify("quiet", 6, "quiet-summary.json")\n'
    'confirmation = verify("confirmation-corrected", 3, "confirmation-summary.json")')
archive = archive.replace("save(out / 'summary.json', initial)",
    """save(out / 'summary.json', initial)
(out / 'confirmation').mkdir()
save(out / 'confirmation/summary.json', confirmation)
for name in ('observations.tgz', 'archive-receipt.json', 'terminal-status.json'):
    shutil.copyfile(lab / 'confirmation-corrected' / name, out / 'confirmation' / name)
""")
archive = archive.replace("'prepare-evidence.py', 'archive-evidence.py',",
    "'prepare-evidence.py', 'archive-evidence.py', 'prepare-confirmation.py', 'build-confirmation.py',\n"
    "        'launch-confirmation.py', 'summarize-confirmation.py', 'confirmation-preflight.log', 'confirmation-retrieval.log',")
archive = archive.replace("print('Archived six lanes, complete image identities and all staging conditions.')",
    """    for name in ('config.json', 'identity.json', 'remote-launch.py', 'retrieve.py', 'observe-not-before.json',
                 'launch.log', 'collect.py', 'archive-owned.py', 'run.sh'):
        tar.add(lab / 'confirmation-corrected' / name, arcname='confirmation/' + name)
print('Archived nine diagnostic lanes and both complete frozen image identities.')
""")
(lab / 'archive-evidence.py').write_text(archive, encoding='utf-8', newline='\n')
subprocess.run([sys.executable, '-X', 'utf8', lab / 'archive-evidence.py', sys.argv[1]], check=True)
