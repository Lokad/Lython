from pathlib import Path
import json
import subprocess
import sys

lab = Path(__file__).resolve().parent
prior = lab.parent / 'source-annotation-mode-r714'
stage = (prior / 'stage-quiet.py').read_text(encoding='utf-8')
stage = stage.replace('source-annotation-mode-b1145', 'keyword-default-record-b1146')
stage = stage.replace('lython-b1145-source-annotation-mode', 'lython-b1146-keyword-default-record')
stage = stage.replace('lython-b1145-fixtures', 'lython-b1146-fixtures')
stage = stage.replace('R714 source-selected annotation mode', 'R715 live keyword-default record slots')
stage = stage.replace('Source-selected annotation mode', 'Live keyword-default record slots')
start = stage.index('        jobs = [')
end = stage.index('\n', start)
annotated = 'scripts.annotated-rule-closures'
jobs = [('scripts.rule-default-closures', 'warm'), (annotated, 'warm'),
        ('calls.defaults.medium','warm'), ('scripts.captured-rule-closures', 'warm'),
        ('scripts.csv-invoice.large', 'warm'), (annotated, 'compile-run')]
cases = {row['id'] for row in json.loads((lab / 'catalog.json').read_text(encoding='utf-8'))['cases']}
assert all(name in cases for name, _ in jobs)
stage = stage[:start] + '        jobs = ' + repr(jobs) + stage[end:]
stage = stage.replace('four-case, six-job', 'five-case, six-job').replace('}) == 4', '}) == 5')
proof = (prior / 'prove-quiet-space.py').read_text(encoding='utf-8')
for name,value in [('prove-quiet-space.py',proof),('stage-quiet.py',stage)]:
    (lab / name).write_text(value, encoding='utf-8', newline='\n')
    subprocess.run([sys.executable, '-X', 'utf8', lab / name], check=True)
