from pathlib import Path
import ast
import datetime
import json
import subprocess

out=Path(__file__).parent/'hosting-attribution-r389'
config=json.loads((out/'config.json').read_text(encoding='utf-8'))
assert not(out/'launch-attempt.json').exists()
previous=json.loads((out.parent/'hosting-whole-r388/terminal-status.json').read_text(encoding='utf-8'))
assert previous['receipt']['complete'] and not previous['remainingWorkers'] and not previous['remainingTrace']
code=r'''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
config=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['sourceRoot'])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert root.parent==base and not root.exists()and source.parent==base and source.resolve()==source
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(os.path.ismount(p)for p in base.glob('*/guest-fixtures'))
 state=subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=LoadState,MainPID'],text=True)
 assert 'LoadState=not-found'in state and 'MainPID=0'in state
 assert sha(source/'candidate/Lokad.Lython.dll')==config['identity']['coreSHA256']['candidate']
 for name,h in config['identity']['auxiliaryFiles'].items():assert sha(source/'candidate'/name)==h
 assert sha(source/'catalog.json')==config['identity']['catalogSHA256']
 payload=sys.stdin.buffer.read(config['payloadBytes']+1)
 assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 before=shutil.disk_usage(base).free;retired=[]
 for proof in config['custody']:
  parent=base/proof['root'];path=parent/proof['path']
  assert parent.parent==base and parent.resolve()==parent and path.resolve()==path and path.is_relative_to(parent)
  metadata=path.lstat()
  assert stat.S_ISREG(metadata.st_mode)and metadata.st_uid==os.getuid()and metadata.st_nlink==1 and metadata.st_size==proof['bytes']
  assert not(parent/'guest-fixtures').exists()and(parent/'exit-code.txt').read_text().strip()=='0'
  assert json.loads((parent/'archive-receipt.json').read_text())['complete']
  assert sha(parent/'observations.tgz')==proof['archiveSHA256']and sha(path)==proof['rawSHA256']
  with tarfile.open(parent/'observations.tgz')as archive:assert hashlib.sha256(archive.extractfile(proof['path']).read()).hexdigest()==proof['rawSHA256']
  retired.append(path)
 assert before+sum(p.stat().st_size for p in retired)>254*1024*1024+config['unpackedBytes']+65536
 for path in retired:path.unlink()
 assert shutil.disk_usage(base).free>254*1024*1024+config['unpackedBytes']+65536
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as archive:archive.extractall(root,filter='data')
 (root/'candidate').mkdir()
 for name in [*config['identity']['auxiliaryFiles'],'Lokad.Lython.dll']:os.link(source/'candidate'/name,root/'candidate'/name)
 os.link(source/'catalog.json',root/'catalog.json')
 (root/'retirement-receipt.json').write_text(json.dumps(dict(retiredOnly=[str(p)for p in retired],custody=config['custody'],allProofsCheckedBeforeMutation=True,freshIdleLease=True,payloadVerifiedBeforeRetirement=True,archivesImagesCatalogsWorkersToolchainsAndFloorsPreserved=True,freeBeforeBytes=before,freeAfterBytes=shutil.disk_usage(base).free),indent=2)+chr(10))
 for name in ['ops-profile.py','collect.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture=root/'guest-fixtures';fixture.mkdir();assert shutil.disk_usage(base).free>254*1024*1024
 (root/'space-preflight.json').write_text(json.dumps(dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,noImageOrCatalogUpload=True,floorsUnchanged=True))+chr(10))
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b776-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=120','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True))
'''.replace('CONFIG',repr(config))
ast.parse(code)
(out/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
import base64
command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
now=datetime.datetime.now(datetime.timezone.utc)
(out/'launch-attempt.json').write_text(json.dumps(dict(attemptedUTC=now.isoformat(),neverAutomaticallyRelaunch=True))+'\n',encoding='utf-8')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
result=subprocess.run(ssh+[command],input=(out/'payload.tgz').read_bytes(),capture_output=True,timeout=60)
(out/'launch.log').write_bytes(result.stdout+result.stderr)
assert result.returncode==0,(result.stdout+result.stderr).decode('utf-8')
now=datetime.datetime.now(datetime.timezone.utc)
(out/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=65)).isoformat(),ownerSeconds=120),indent=2)+'\n',encoding='utf-8',newline='\n')
print(result.stdout.decode('utf-8'));print('Earliest observation',(now+datetime.timedelta(seconds=65)).isoformat(),flush=True)
