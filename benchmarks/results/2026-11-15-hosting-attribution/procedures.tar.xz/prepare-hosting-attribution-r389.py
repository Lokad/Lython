from pathlib import Path
import ast
import hashlib
import json
import subprocess
import tarfile

notes = Path(__file__).parent
old = notes / 'entry-stage-r385'
out = notes / 'hosting-attribution-r389'
out.mkdir(exist_ok=False)
sha = lambda data: hashlib.sha256(data).hexdigest()
custody = []
for local, remote, committed in [
    ('fresh-config-r386', 'fresh-config-b774-20261115', '2026-11-15-config-manifest-phases'),
    ('hosting-whole-r388', 'hosting-whole-b775-20261115', '2026-11-15-whole-script-hosting')]:
    archive = Path('benchmarks/results') / committed / 'observations.tgz'
    committed_bytes = subprocess.check_output(['git', 'show', 'HEAD:' + archive.as_posix()])
    assert sha(committed_bytes) == sha(archive.read_bytes())
    with tarfile.open(archive) as tar: raw = tar.extractfile('confirmation/confirmation.json').read()
    local_raw = notes / local / 'retrieved/confirmation/confirmation.json'
    assert raw == local_raw.read_bytes()
    custody.append(dict(root=remote, path='confirmation/confirmation.json', bytes=len(raw),
                        rawSHA256=sha(raw), archiveSHA256=sha(committed_bytes),
                        committedArchive=archive.as_posix(), custodyCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()))
identity = json.loads((notes/'hosting-whole-r388/identity.json').read_text(encoding='utf-8'))
identity['purpose'] = 'Current captured-text Run/RunAsync CPU attribution before redesign; same source, paired bounded captures, no timing comparison.'
remote = '/home/lokad/lython-bench-checks/hosting-attribution-b776-20261115'
unit = 'lython-b776-hosting-attribution-20261115'
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'custody.json').write_text(json.dumps(custody,indent=2)+'\n',encoding='utf-8',newline='\n')
prospective = dict(question='Which current captured-text CPU work distinguishes completed-I/O RunAsync from Run?',
                   hypotheses=['Per-line async file/iteration machinery','Completed builtin/protocol setup and disposal','Invocation/result scheduling'],
                   source='810379be/frozen8fbfa3f0', captures=[['sync','warm'],['async','warm-async']],
                   captureSecondsEach=5, guestWarmupSeconds=8, event='cpu-clock/fp199Hz',
                   acceptance='Current exact core/aux/catalog identity, full goldens, quiet-before/after, shared-balance/Closed/join, all-thread CPU/stacks, verified RAM archive before unmount under lease.',
                   stoppingCriterion='Select a coherent displaced stage only if current source and attribution identify distinct dominant avoidable work; otherwise keep uncertainty and progress common operand/iteration assessment without repeated unchanged captures.',
                   retiredOnly='Two exact working confirmation.json copies, each proved in a SHA-verified Git-committed archive; preserve all archives/images/catalogs/toolchains and254/252MiBfloors.',
                   performanceComparison=False,publicationHeld=True)
(out/'prospective.json').write_text(json.dumps(prospective,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['ops-profile.py','collect.py','run.sh','retrieve.py']:
    text = (old/name).read_text(encoding='utf-8').replace('entry-stage-b773-20261115','hosting-attribution-b776-20261115').replace('lython-b773-entry-stage-20261115',unit)
    if name == 'ops-profile.py':
        text = text.replace("[('file','scripts.file-search.large.protected','warm')]", "[('sync','scripts.text-summary-helpers.nonlocal-counter.large','warm'),('async','scripts.text-summary-helpers.nonlocal-counter.large','warm-async')]")
        text = text.replace("        env['DOTNET_JitDisasm']='*StartNativeCall*'\n        env['DOTNET_JitStdOutFile']=str(folder/'native-entry.asm')\n", '')
        text = text.replace('["DOTNET_PerfMapEnabled", "DOTNET_JitDisasm", "DOTNET_JitStdOutFile"]', '["DOTNET_PerfMapEnabled"]')
        needle="        with gzip.open(folder/'perf-stacks.txt.gz','wb') as compressed:compressed.write(stacks)"
        assert text.count(needle)==1
        text = text.replace(needle, needle+"\n        all_stacks = subprocess.check_output(['perf','script','-i',str(folder/'perf.data')],stderr=subprocess.STDOUT,timeout=15)\n        with gzip.open(folder/'all-thread-stacks.txt.gz','wb') as compressed:compressed.write(all_stacks)")
    elif name == 'collect.py':
        text = text.replace("['file']", "['sync','async']")
        text = text.replace('R385 protected file-search native-entry attribution', 'R389 captured-text API CPU attribution')
    elif name == 'retrieve.py':
        text = text.replace('One CPU profile', 'Paired CPU profiles')
    if name.endswith('.py'): ast.parse(text)
    (out/name).write_text(text,encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz') as archive:
    for name in ['identity.json','custody.json','prospective.json','ops-profile.py','collect.py','run.sh']:
        archive.add(out/name,arcname=name)
with tarfile.open(out/'payload.tgz') as archive: unpacked=sum(m.size for m in archive.getmembers())
config=dict(root=remote,unit=unit,sourceRoot='/home/lokad/lython-bench-checks/entry-stage-b773-20261115',
            identity=identity,custody=custody,payloadBytes=(out/'payload.tgz').stat().st_size,
            payloadSHA256=sha((out/'payload.tgz').read_bytes()),unpackedBytes=unpacked)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(prepared=True,retirementCustody=custody,payloadBytes=config['payloadBytes'],unpackedBytes=unpacked)))
