from pathlib import Path
import hashlib
import json
import shutil
import tarfile

notes=Path(__file__).parent;source=notes/'hosting-attribution-r389'
target=Path('benchmarks/results/2026-11-15-hosting-attribution');target.mkdir(exist_ok=False)
receipt=json.loads((source/'archive-receipt.json').read_text(encoding='utf-8'))
assert receipt['complete']and receipt['ramTraceArchivedAndVerifiedBeforeUnmount']and receipt['allWorkersJoined']
assert hashlib.sha256((source/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for name in ['identity.json','prospective.json','custody.json','attribution.json','archive-receipt.json','terminal-status.json','observations.tgz']:
    shutil.copyfile(source/name,target/name)
with tarfile.open(target/'procedures.tar.xz','w:xz')as archive:
    for name in ['prepare-hosting-attribution-r389.py','launch-hosting-attribution-r389.py','analyze-hosting-attribution-r389.py','save-hosting-attribution-r389.py']:
        archive.add(notes/name,arcname=name)
    for name in ['config.json','launch-command.py','launch-attempt.json','launch.log','retrieve.py','observe-not-before.json']:
        archive.add(source/name,arcname='local/'+name)
print(json.dumps(dict(saved=str(target),archiveSHA256=receipt['archiveSHA256'],freeBytes=receipt['freeBytes'])))
