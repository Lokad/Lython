from pathlib import Path
import hashlib
import importlib.util
import json
import os
import queue
import subprocess
import tarfile
import tempfile
import threading
import time

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
data=repo/"benchmarks/results"
notes=lab.parent
reference=lab.with_name("exact-unicode-float-20261124")
proof=json.loads((lab/'external/identity.json').read_text(encoding='utf-8'))
proof['revision']=proof['candidate']
proof['protocolSHA256']=proof['cpythonWorkerSHA256']
image=reference/'candidate'
expected=proof["imageFiles"]["candidate"]
def sha(b):return hashlib.sha256(b).hexdigest()
def checked_image():assert len(expected)==32 and {n:sha((image/n).read_bytes()) for n in expected}==expected
def save(path,value):path.write_text(json.dumps(value,indent=2)+"\n",encoding="utf-8",newline="\n")
checked_image()
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
trace=Path.home()/".dotnet/tools/dotnet-trace.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
protocol_path=repo/"benchmarks/cpython-worker.py"
assert sha(protocol_path.read_bytes())==proof["protocolSHA256"]
spec=importlib.util.spec_from_file_location("bench_protocol",protocol_path)
protocol=importlib.util.module_from_spec(spec)
spec.loader.exec_module(protocol)
catalog=json.loads((lab/'external/representative.json').read_text(encoding='utf-8'))
cases=catalog['cases']
assert [case['id'] for case in cases]==['scripts.rule-default-closures','scripts.annotated-rule-closures','scripts.captured-rule-closures']
catalog["performanceQualified"]=False
save(lab/"catalog.json",catalog)
digest=sha((lab/"catalog.json").read_bytes())
worker=image/"Lokad.Lython.Benchmarks.dll"
subprocess.run([dotnet,worker,"--compare","verify","--catalog",lab/"catalog.json","--dotnet",dotnet,
                "--python","C:/Python313/python.exe","--python-worker",protocol_path,"--out",lab/"verification.json"],
               env=env,check=True,timeout=90)
verification=json.loads((lab/"verification.json").read_text(encoding="utf-8"))
assert verification["state"]=="Completed" and verification["caseCount"]==3 and verification["catalogSha256"]==digest
diagnostic=[]
for role,case in zip(('default-rule','annotated-rule','captured-rule'),cases,strict=True):
    observations=lab/role
    observations.mkdir()
    with tempfile.TemporaryDirectory(prefix="lython-comparison-files-")as fixture, (observations/"worker.stderr").open("wb")as errors:
        command=[dotnet,worker,"--compare","worker","--catalog",lab/"catalog.json"]
        child=subprocess.Popen(command,cwd=fixture,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=errors)
        seq=0
        def read_frame():
            result=queue.Queue()
            def receive():
                try:result.put(protocol.read_frame(child.stdout))
                except BaseException as error:result.put(error)
            thread=threading.Thread(target=receive)
            thread.start()
            try:response=result.get(timeout=18)
            except queue.Empty:
                child.kill()
                child.wait(timeout=8)
                raise
            finally:thread.join()
            if isinstance(response,BaseException):raise response
            assert response is not None
            return response
        def request(action,count):
            global seq
            seq+=1
            payload=dict(protocolVersion=2,requestId=seq,operation=action)
            if action!="quit":
                payload.update(caseId=case["id"],lane="warm",iterations=count,
                               **{key:case[key] for key in ("sourceSha256","fixtureSha256","expectedOutputSha256")})
            protocol.write_frame(child.stdin,payload)
            response=read_frame()
            assert response["requestId"]==seq and response["status"]=={"verify":"Equivalent","batch":"Completed","quit":"Closed"}[action]
            if action!="quit":assert response["completedInvocations"]==count
            if action=="batch":assert response["actualOutputSha256"]==case["expectedOutputSha256"] and response.get("actualFilesSha256")==case.get("expectedFilesSha256")
            return response
        attached=None
        try:
            identity=read_frame()
            assert identity["status"]=="Ready" and identity["catalogSha256"]==digest
            assert any(n["sha256"].lower()==expected["Lokad.Lython.dll"] for n in identity["libraries"])
            before=request("verify",2)
            count=32
            end=time.monotonic()+4
            while time.monotonic()<end:request("batch",count)
            recording=observations/"warm.nettrace"
            with (observations/"capture.log").open("wb")as trace_log:
                attached=subprocess.Popen([trace,"collect","--process-id",str(child.pid),
                           "--profile","gc-verbose","--buffersize","32",
                           "--duration","00:00:00:06","--output",recording],
                           env=env,stdin=subprocess.DEVNULL,stdout=trace_log,stderr=subprocess.STDOUT)
                sample=[]
                started=time.monotonic()
                while attached.poll() is None and time.monotonic()-started < 18:sample.append(request("batch",count))
                assert attached.wait(timeout=5)==0 and sample
            after=request("verify",2)
            closed=request("quit",0)
            assert child.wait(timeout=6)==0
        finally:
            if attached is not None and attached.poll() is None:attached.kill();attached.wait(timeout=5)
            if child.poll() is None:child.kill();child.wait(timeout=5)
            child.stdin.close()
            child.stdout.close()
        slot=dict(role=role,workload=case["id"],batches=sample,identity=identity,before=before,after=after,
                  closed=closed,allProcessesJoined=True,coreSha=expected["Lokad.Lython.dll"],nettraceSha=sha(recording.read_bytes()),
                  profile="Windows EventPipe sampled allocation ticks")
        diagnostic.append(slot)
        save(observations/"record.json",slot)
        inspect=notes/"text-allocation-r512/inspect/bin/Release/net11.0/inspect.dll"
        output=subprocess.check_output([dotnet,inspect,recording,observations/"sampled-allocation.json"],
            env=env,timeout=40)
        (observations/"allocation.log").write_bytes(output)
        print(role,len(sample),sum(b["completedInvocations"]for b in sample),slot["nettraceSha"],flush=True)
checked_image()
save(lab/"run-summary.json",dict(sourceRevision=proof["revision"],retainedSource=proof["revision"],
                                runtime=diagnostic[0]["identity"]["runtime"],catalogSha=digest,
                                allProcessesJoined=True,totalVerifiedBatches=sum(len(item["batches"])for item in diagnostic),
                                timingQualification=False))
