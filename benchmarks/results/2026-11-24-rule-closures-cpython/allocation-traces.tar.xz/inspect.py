from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab=Path(__file__).resolve().parent
notes=lab.parent
root=lab.parents[3]
expected=json.loads((lab/'external/identity.json').read_text(encoding='utf-8'))['imageFiles']['candidate']
donor=notes/'exact-unicode-float-20261124/candidate'
inspection=notes/'plain-class-fixed-20261123/candidate'
image=lab/'local-inspection'
image.mkdir(exist_ok=True)
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,sha in expected.items():
    assert digest(donor/name)==sha
    shutil.copyfile(donor/name,image/name)
    assert digest(image/name)==sha
helpers={}
for suffix in ('.dll','.deps.json','.runtimeconfig.json'):
    name='Inspect'+suffix
    shutil.copyfile(inspection/name,image/name)
    helpers[name]=digest(image/name)
dotnet=Path.home()/'.dotnet11/dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent))
subprocess.run([dotnet,image/'Inspect.dll',lab/'external/representative.json',lab/'tapes.json'],env=env,check=True,timeout=35)
(lab/'inspector-identity.json').write_text(json.dumps(helpers,indent=2)+'\n',encoding='utf-8',newline='\n')
assert all(digest(image/name)==sha for name,sha in expected.items())

