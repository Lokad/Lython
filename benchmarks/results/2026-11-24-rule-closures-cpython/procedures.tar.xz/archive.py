from pathlib import Path
import hashlib
import json
import shutil
import sys
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
external = lab/'external'
output = repo/'benchmarks/results/2026-11-24-rule-closures-cpython'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
terminal = read(external/'terminal-status.json')
receipt = terminal['receipt']
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode']=='0'
assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved',
    'quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert receipt['warmJobs']==5 and digest(external/'observations.tar.xz')==receipt['archiveSHA256']
identity=read(external/'identity.json')
summary=read(external/'summary.json')
assert identity['candidate']==summary['source']
assert summary['timedBatches']==140 and summary['cpythonExecutableSHA256']==identity['expectedCPythonSHA256']
assert [item['lane'] for item in summary['rows']]==['warm','warm','warm','compile-run','compile']
assert [row['case'] for row in summary['rows'][:3]]==['scripts.rule-default-closures','scripts.annotated-rule-closures','scripts.captured-rule-closures']
assert all(item['case']=='scripts.captured-rule-closures' for item in summary['rows'][3:])
local = read(external/'candidate-verify.json')
assert local['state']=='Completed' and local['caseCount']==3
assert local['catalogSha256']==identity['catalogs']['representative.json']['sha256']
assert local['launched']['library']['sha256']==identity['coreSHA256']['candidate']
donor = sys.argv[1]
files = identity['imageFiles']['candidate']
assert len(files)==32 and all(digest(lab.parent/donor/'candidate'/name)==expected for name,expected in files.items())
output.mkdir(exist_ok=True)
for item in ('identity.json','terminal-status.json','observations.tar.xz','summary.json'):
    shutil.copyfile(external/item,output/item)
inputs=('external.py','prepare.py','archive.py','external/summarize.py',
    'external/launch.log','external/candidate-verify.json')
with tarfile.open(output/'procedures.tar.xz','w:xz') as bundle:
    for item in inputs: bundle.add(lab/item,arcname=item)
with tarfile.open(output/'procedures.tar.xz') as bundle:
    assert set(bundle.getnames())==set(inputs)
    assert all(bundle.extractfile(item).read()==(lab/item).read_bytes() for item in inputs)

from collections import Counter
import re

profile = read(lab/'run-summary.json')
assert profile['sourceRevision'] == identity['candidate']
assert profile['allProcessesJoined']
tapes = read(lab/'tapes.json')
assert tapes['coreSHA256']==identity['coreSHA256']['candidate']
assert [row['id'] for row in tapes['rows']]==[row['case'] for row in summary['rows'][:3]]
traces = ('default-rule','annotated-rule','captured-rule')
allocation = dict(revision=profile['sourceRevision'], kind='Windows EventPipe allocation tick weights', rows=[])
bundle_files = {name:lab/name for name in ('profile-allocation.py','run-summary.json','catalog.json','verification.json',
    'tapes.json','inspect.py','inspector-identity.json')}
inspector=lab.with_name('retained-meter-allocation-20261123')/'inspect-stack'
for name in ('Program.cs','InspectStacks.csproj','packages.lock.json'):
    bundle_files['stack-inspector/'+name]=inspector/name
for role in traces:
    observed=lab/role
    record=read(observed/'record.json')
    assert record['allProcessesJoined'] and record['nettraceSha']==digest(observed/'warm.nettrace')
    assert record['coreSha']==identity['coreSHA256']['candidate']
    assert record['before']['status']==record['after']['status']=='Equivalent' and record['closed']['status']=='Closed'
    stacks=read(observed/'allocation-stacks.json')
    aggregates=read(observed/'sampled-allocation.json')
    total=sum(row['Weight'] for row in stacks)
    assert total==aggregates['TotalSampleWeight']
    types=Counter()
    sites=Counter()
    for row in stacks:
        types[row['Type']]+=row['Weight']
        method=re.split(r'\(| <- ',row['Stack'])[0] or '<unresolved>'
        sites[method]+=row['Weight']
    allocation['rows'].append(dict(case=record['workload'],invocations=sum(sample['completedInvocations'] for sample in record['batches']),
        ticks=sum(row['Count'] for row in stacks),weight=total,types=types.most_common(),sites=sites.most_common()))
    for name in ('warm.nettrace','capture.log','record.json','sampled-allocation.json','allocation-stacks.json','stacks.log'):
        bundle_files[role+'/'+name]=observed/name
(output/'allocation-profile.json').write_text(json.dumps(allocation,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(output/'allocation-traces.tar.xz','w:xz') as bundle:
    for name,path in bundle_files.items(): bundle.add(path,arcname=name)
with tarfile.open(output/'allocation-traces.tar.xz') as bundle:
    assert set(bundle.getnames())==set(bundle_files)
    assert all(hashlib.sha256(bundle.extractfile(name).read()).hexdigest()==digest(path) for name,path in bundle_files.items())

initial = lab/'initial'
problem = read(initial/'terminal-status.json')
assert not problem['live'] and not problem['fixtures'] and problem['exitCode']=='1'
assert "KeyError: 'auxiliaryFiles'" in problem['journal']
assert digest(initial/'observations.tar.xz')==problem['receipt']['archiveSHA256']
assert read(initial/'identity.json')['imageFiles']==identity['imageFiles']
assert "no worker processes remain" in (initial/'join-check.log').read_text(encoding='utf-8')
with tarfile.open(output/'initial-launch.tar.xz','w:xz') as bundle:
    for item in ('observations.tar.xz','terminal-status.json','identity.json','launch.log','join-check.log'):
        bundle.add(initial/item,arcname=item)

