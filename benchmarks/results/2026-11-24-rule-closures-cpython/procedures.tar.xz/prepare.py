from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.with_name('json-text-cpython-20261124')
output=lab/'external'
output.mkdir(exist_ok=True)
(profile_donor,remote_donor)=sys.argv[1:]
assert profile_donor in ('direct-match-expand-20261124','exact-unicode-float-20261124')
assert remote_donor in ('direct-match-expand-b1558-20261124','exact-unicode-float-b1560-20261124')
donor=lab.with_name(profile_donor)
collection=donor/'comparison/quiet'


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, source):
    path.write_text(source,encoding='utf-8',newline='\n')


def save(path, data):
    write(path,json.dumps(data,indent=2,ensure_ascii=False)+'\n')


metadata=read(donor/'comparison/identity.json')
proof=read(collection/'terminal-status.json')['receipt']
assert proof['complete'] and proof['archivedAndVerifiedUnderLease']
assert digest(collection/'observations.tar.xz')==proof['archiveSHA256']
production=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
subprocess.run(['git','diff','--exit-code',metadata['candidate'],production,'--','src','tests'],cwd=repo,check=True)
identity=dict(sourceRevision=metadata['candidate'],candidate=metadata['candidate'],productionSource=production,
    imageFiles={'candidate':metadata['imageFiles']['candidate']},
    frozenImage='/home/lokad/lython-bench-checks/current-rule-closures-cpython-b1561-20261124-corrected/candidate',
    auxiliaryFiles={name:sha for name,sha in metadata['imageFiles']['candidate'].items() if name!='Lokad.Lython.dll'},
    coreSHA256={role:metadata['coreSHA256']['candidate'] for role in ('candidate','candidate-control')},
    expectedCPythonSHA256=metadata['expectedCPythonSHA256'], cpythonWorkerSHA256=metadata['cpythonWorkerSHA256'])
assert len(identity['imageFiles']['candidate'])==32
assert all(digest(donor/'candidate'/name)==expected for name,expected in identity['imageFiles']['candidate'].items())

catalog=read(donor/'comparison/representative.json')
with tarfile.open(repo/'benchmarks/results/2026-11-19-retained-return-cpython/observations.tgz') as archived:
    historical=json.load(archived.extractfile('representative.json'))
catalog['cases']=historical['cases'][:3]
cases=[case['id'] for case in catalog['cases']]
assert cases==['scripts.rule-default-closures','scripts.annotated-rule-closures','scripts.captured-rule-closures']
jobs=[[case_id,'warm'] for case_id in cases]+[[cases[-1],boundary] for boundary in ('compile-run','compile')]
save(output/'representative.json',catalog)
save(output/'jobs.json',jobs)
identity['catalogs']={name:{'sha256':digest(output/name)} for name in ('representative.json','jobs.json')}
save(output/'identity.json',identity)

dotnet=Path.home()/'.dotnet11/dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent))
protocol=repo/'benchmarks/cpython-worker.py'
assert digest(protocol)==identity['cpythonWorkerSHA256']
subprocess.run([dotnet,donor/'candidate/Lokad.Lython.Benchmarks.dll','--compare','verify',
    '--catalog',output/'representative.json','--dotnet',dotnet,'--python','C:/Python313/python.exe',
    '--python-worker',protocol,'--out',output/'candidate-verify.json'],env=env,check=True,timeout=90)
verified=read(output/'candidate-verify.json')
assert verified['state']=='Completed' and verified['caseCount']==3
assert verified['catalogSha256']==identity['catalogs']['representative.json']['sha256']
assert verified['launched']['library']['sha256']==identity['coreSHA256']['candidate']

collector=(prior/'external/collect.py').read_text(encoding='utf-8').replace('b1555-','b1561-').replace('len(jobs) == 4','len(jobs) == 5').replace('started<220','started<300')
collector=collector.replace('CPython checkpoint for expanded JSON and short nonlocal text','CPython checkpoint for generated rule closures')
compile(collector,'collect.py','exec')
write(output/'collect.py',collector)
summary=(prior/'external/summarize.py').read_text(encoding='utf-8').replace('len(raw["jobs"])==4 and receipt["warmJobs"]==4',
    'len(raw["jobs"])==5 and receipt["warmJobs"]==5')
write(output/'summarize.py',summary)

launch=(prior/'external.py').read_text(encoding='utf-8')
launch=launch.replace('b1555-json-text-cpython-20261124','b1561-current-rule-closures-cpython-20261124-corrected')
launch=launch.replace('json-text-cpython-b1555-20261124','current-rule-closures-cpython-b1561-20261124-corrected')
launch=launch.replace('json-encoding-flags-20261124',profile_donor).replace('json-encoding-flags-b1553-20261124',remote_donor)
launch=launch.replace('seconds=215','seconds=257').replace('RuntimeMaxSec=285','RuntimeMaxSec=335')
compile(launch,'external.py','exec')
write(lab/'external.py',launch)
