from pathlib import Path
import json
import subprocess
import textwrap

lab=Path(__file__).resolve().parent
before=lab.with_name('native-segments-at-emission-20261126')
json_lab=lab.with_name('json-single-string-pass-20261126')/'local'

def read(path):
    return path.read_text(encoding='utf-8-sig')

def write(name,source):
    (lab/name).write_text(source,encoding='utf-8',newline='\n')

def edit(source, pairs):
    for old,new in pairs:
        assert source.count(old)==1,old
        source=source.replace(old,new)
    return source

source=edit(read(before/'prepare.py'),[
    ("reference=lab.with_name('starmap-direct-sequence-packet-20261126')",
     "reference=lab.with_name('native-segments-at-emission-20261126')"),
    ("'src/Lokad.Lython/Frontend/ExecutableScript.cs',\n    'src/Lokad.Lython/Frontend/ExecutableScript.NativeSegments.cs',\n    'src/Lokad.Lython/Frontend/ExecutableStackLayout.cs',",
     "'src/Lokad.Lython/Runtime/LythonRuntime.Executable.PrivateStringResults.cs',\n    'src/Lokad.Lython/Runtime/LythonRuntime.StringMembers.Segmentation.cs',\n    'src/Lokad.Lython/Runtime/Text/PyStringOps.Helpers.cs',"),
    ("] )]:".replace(' ',''),"]), ('regression.patch',['tests/Lokad.Lython.PublicApi.Tests/StringStripCallTests.cs'])]:"),
    ("assert ready==['src/Lokad.Lython/Runtime/PyItertools.Transforms.cs']",
     "assert ready==['src/Lokad.Lython/Frontend/ExecutableScript.NativeSegments.cs', 'src/Lokad.Lython/Frontend/ExecutableScript.cs', 'src/Lokad.Lython/Frontend/ExecutableStackLayout.cs']"),
    ("proof['caseCount']==5","proof['caseCount']==4"),
])
compile(source,'prepare.py','exec')
write('prepare.py',source)
catalog=json.loads(read(json_lab/'representative.json'))
picked={'scripts.json-summary-helpers.large','diagnostic.json-service-quantity-totals',
        'diagnostic.text-summary.nonlocal-computed-width.large'}
catalog['cases']=[case for case in catalog['cases'] if case['id'] in picked]
assert len(catalog['cases'])==3
before_catalog=json.loads(read(before/'local/representative.json'))
catalog['cases'].extend(case for case in before_catalog['cases'] if case['id']=='scripts.file-search.large')
assert len(catalog['cases'])==4
assert sum('line.strip()' in case['source'] for case in catalog['cases'])==1
write('representative.json',json.dumps(catalog,indent=2,ensure_ascii=False)+'\n')
source=edit(read(before/'prepare-local.py'),[
    ("prior=lab.with_name('direct-map-result-handoff-20261126')/'local'","prior=lab.with_name('native-segments-at-emission-20261126')/'local'"),
    ("source=lab.with_name('starmap-direct-sequence-packet-20261126')/'comparison/quiet'",
     "source=lab.with_name('native-segments-at-emission-20261126')/'comparison/quiet'"),
    ("    ['diagnostic.generated-ordinary-definitions','compile'],\n    ['scripts.rule-default-closures','compile'],\n    ['diagnostic.text-summary.nonlocal-computed-width.large','warm'],\n    ['diagnostic.generated-ordinary-definitions','compile-run'],\n    ['scripts.file-search.large','warm'],",
     "    ['scripts.json-summary-helpers.large','warm-async'],\n    ['diagnostic.json-service-quantity-totals','warm'],\n    ['diagnostic.text-summary.nonlocal-computed-width.large','warm'],\n    ['scripts.json-summary-helpers.large','warm'],\n    ['scripts.file-search.large','warm'],"),
    ("Prepare native arithmetic and dictionary segments at their final tape endings.",
     "Test default whitespace trimming directly when the result feeds only truth."),
    ("assert collector.count('lython-direct-map-result-handoff-fixture-')==1","assert collector.count('lython-native-segments-at-emission-fixture-')==1"),
    ("collector=collector.replace('lython-direct-map-result-handoff-fixture-','lython-native-segments-at-emission-fixture-')",
     "collector=collector.replace('lython-native-segments-at-emission-fixture-','lython-trim-truth-without-result-fixture-')"),
])
compile(source,'prepare-local.py','exec')
write('prepare-local.py',source)

program=read(lab/'source/tests/Lokad.Lython.PublicApi.Tests/StringStripCallTests.cs')
first=program.index('            def count(value):')
last=program.index('            """,',first)
fixture=textwrap.dedent(program[first:last])
expected="[0, 0, 0, 3, 3]\ncustom\n'x' ''\ndynamic strip\ntruth callback\ndynamic false\n"
output=subprocess.run(['C:/Python313/python.exe','-X','utf8','-I','-S','-c',fixture],check=True,
    capture_output=True,encoding='utf-8',timeout=20).stdout
assert output==expected,output
write('cpython-regression.log',output)
