from datetime import datetime,timedelta,timezone
from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
quiet=lab/'comparison/quiet'
first=quiet/'first-attempt'
first.mkdir()
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
terminal=read(quiet/'terminal-status.json')
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode']=='1'
receipt=terminal['receipt']
assert receipt['archivedAndVerifiedUnderLease'] and receipt['warmJobs'] is None
assert receipt['archiveSHA256']==sha(quiet/'observations.tar.xz')
assert 'Keep space for persistent lane evidence' in terminal['journal']
for name in ('terminal-status.json','observations.tar.xz','observe-not-before'):
    (quiet/name).replace(first/name)
old='lython-b1802-trim-truth-without-result-20261126'
new='lython-b1802-trim-truth-without-result-retry-20261126'
source=(lab/'quiet.py').read_text(encoding='utf-8')
assert source.count(old)==1
(lab/'quiet-retry.py').write_text(source.replace(old,new),encoding='utf-8',newline='\n')
cfg=dict(root=read(quiet/'upload.json')['root'],old=old,new=new,failedArchive=receipt['archiveSHA256'],
         identity=read(quiet/'identity.json'))
remote=r'''
from pathlib import Path
import fcntl,hashlib,json,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks')
root=base/cfg['root']
assert root.resolve()==root and root.parent==base
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with (base/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    status=subprocess.check_output(['systemctl','show',cfg['old']+'.service','--property=ActiveState,MainPID'],text=True)
    assert 'ActiveState=failed' in status and 'MainPID=0' in status,status
    assert not (root/'guest-fixtures').exists()
    assert shutil.disk_usage(root).free>=5_800_000,shutil.disk_usage(root).free
    failed=json.loads((root/'archive-receipt.json').read_text())
    assert not failed['complete'] and failed['warmJobs'] is None and failed['guestFixturesRemoved']
    assert sha(root/'observations.tar.xz')==failed['archiveSHA256']==cfg['failedArchive']
    identity=json.loads((root/'identity.json').read_text())
    assert identity==cfg['identity']
    for role,files in identity['imageFiles'].items():
        assert len(files)==32 and {p.name:sha(p) for p in (root/role).iterdir()}==files
    for name,record in identity['catalogs'].items(): assert sha(root/name)==record['sha256']
    assert sha(root/'cpython-worker.py')==identity['cpythonWorkerSHA256']
    failed_path=root/'first-attempt'
    assert failed_path.resolve()==failed_path and not failed_path.exists()
    failed_path.mkdir()
    for name in ('archive-receipt.json','observations.tar.xz','confirmation','exit-code.txt'):
        path=root/name
        assert path.resolve()==path and path.exists()
        path.rename(failed_path/name)
    assert sha(failed_path/'observations.tar.xz')==cfg['failedArchive']
    print(json.dumps(dict(freeBeforeRetry=shutil.disk_usage(root).free,failedArchive=cfg['failedArchive'])),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit='+cfg['new'],'--property=User=lokad','--property=WorkingDirectory='+str(root),
 '--property=RuntimeMaxSec=255','--property=TimeoutStopSec=20','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
'''
args=['ssh','-i',os.environ['LYTHON_BENCH_IDENTITY'],'-o','BatchMode=yes','-o','ConnectTimeout=12',
      os.environ['LYTHON_BENCH_HOST'],'python3 -']
run=subprocess.run(args,input='cfg='+repr(cfg)+'\n'+remote,text=True,encoding='utf-8',capture_output=True,timeout=55)
(quiet/'retry-launch.log').write_text(run.stdout+run.stderr,encoding='utf-8')
print(run.stdout+run.stderr)
run.check_returncode()
(quiet/'observe-not-before').write_text((datetime.now(timezone.utc)+timedelta(seconds=178)).isoformat(),encoding='utf-8')
