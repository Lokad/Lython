from pathlib import Path

lab=Path(__file__).resolve().parent
before=lab.with_name('native-segments-at-emission-20261126')

def edit(source,pairs):
    for old,new in pairs:
        assert source.count(old)==1,old
        source=source.replace(old,new)
    return source

def read(path): return path.read_text(encoding='utf-8')

def write(name,source):
    compile(source,name,'exec')
    (lab/name).write_text(source,encoding='utf-8',newline='\n')

source=edit(read(before/'prepare-quiet.py'),[
    ("donor=lab.with_name('starmap-direct-sequence-packet-20261126')","donor=lab.with_name('native-segments-at-emission-20261126')"),
    ("previous=lab.with_name('json-single-string-pass-20261126')","previous=lab.with_name('native-segments-at-emission-20261126')"),
    ("verify['caseCount']==5","verify['caseCount']==4"),
    ("jobs['warm']=[jobs['warm'][4],jobs['warm'][3],jobs['warm'][1],jobs['warm'][0]]",
     "jobs['warm']=[jobs['warm'][4],jobs['warm'][0],jobs['warm'][2],jobs['warm'][3]]"),
    ("quiet.mkdir(parents=True)","quiet.mkdir(parents=True,exist_ok=True)"),
    ("('lython-b1796-fixtures','lython-b1800-fixtures'),","('lython-b1800-fixtures','lython-b1802-fixtures'),"),
    ("root='native-segments-at-emission-b1800-20261126'","root='trim-truth-without-result-b1802-20261126'"),
    ("minimumAfterStageBytes=7_500_000","minimumAfterStageBytes=2_500_000"),
    ("('lython-b1796-json-single-string-pass-20261126','lython-b1800-native-segments-at-emission-20261126'),",
     """('lython-b1800-native-segments-at-emission-20261126','lython-b1802-trim-truth-without-result-20261126'),
    ("verified['caseCount']==5","verified['caseCount']==4"),
    ('starmap-direct-sequence-b1795-20261126','native-segments-at-emission-b1800-20261126'),"""),
])
write('prepare-quiet.py',source)
write('summarize-quiet.py',read(before/'summarize-quiet.py'))
