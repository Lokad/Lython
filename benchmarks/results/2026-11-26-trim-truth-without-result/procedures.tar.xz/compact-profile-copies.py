from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/'comparison/quiet'
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
digest=lambda data:hashlib.sha256(data).hexdigest()
assert len(sys.argv)==2 and sys.argv[1] in ('preview','compact')
mode=sys.argv[1]
runs=(
    ('current-json-construction-profile-20261126','2026-11-26-current-json-construction-profile'),
    ('current-async-iterator-profile-20261126','2026-11-26-current-async-iterator-profile'),
)
claims=[]
for directory,artifact in runs:
    root=lab.with_name(directory)/'comparison/quiet'
    terminal=read(root/'terminal-status.json')
    receipt=terminal['receipt']
    assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode']=='0'
    assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
    published=subprocess.check_output(['git','show','origin/master:benchmarks/results/'+artifact+'/observations.tar.xz'],cwd=repo)
    sha=receipt['archiveSHA256']
    assert digest(published)==sha==digest((root/'observations.tar.xz').read_bytes())
    unit,=set(re.findall(r'lython-b[a-z0-9-]+\.service',terminal['journal']))
    claims.append(dict(root=read(root/'upload.json')['root'],unit=unit,sha=sha))

# Both images are staged. Leave headroom over the collector's 5 MB floor.
need=5_800_000
config=dict(mode=mode,claims=claims,need=need)
remote=r'''
from pathlib import Path
import fcntl, hashlib, json, os, shutil, stat, subprocess, tarfile
base=Path('/home/lokad/lython-bench-checks')
assert base.resolve()==base
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with (base/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert not any(p.is_mount() for p in base.glob('*/guest-fixtures'))
    candidates=[]
    checks=[]
    for claim in cfg['claims']:
        root=base/claim['root']
        assert root.is_dir() and root.resolve()==root and root.parent==base
        archive=root/'observations.tar.xz'
        profiles=root/'profiles'
        assert archive.resolve()==archive and sha(archive)==claim['sha']
        receipt=json.loads((root/'archive-receipt.json').read_text())
        assert receipt['complete'] and receipt['archiveSHA256']==claim['sha'] and receipt['allWorkersJoined']
        status=subprocess.check_output(['systemctl','show',claim['unit'],'--property=ActiveState,MainPID'],
                                       text=True).splitlines()
        assert 'ActiveState=inactive' in status and 'MainPID=0' in status,status
        if not profiles.exists():
            checks.append(dict(root=claim['root'],alreadyCompacted=True))
            continue
        assert profiles.resolve()==profiles and profiles.is_dir() and not profiles.is_mount()
        with tarfile.open(archive) as bundle:
            records={item.name:hashlib.sha256(bundle.extractfile(item).read()).hexdigest()
                     for item in bundle if item.isfile() and item.name.startswith('profiles/')}
        actual={}
        bytes_free=0
        for path in profiles.rglob('*'):
            meta=path.lstat()
            assert path.resolve()==path and not path.is_mount(),str(path)
            if not stat.S_ISREG(meta.st_mode):
                continue
            assert meta.st_nlink==1,str(path)
            key=path.relative_to(root).as_posix()
            actual[key]=sha(path)
            bytes_free+=meta.st_blocks*512
        assert all(records.get(file)==fingerprint for file,fingerprint in actual.items()),claim['root']
        if not actual:
            checks.append(dict(root=claim['root'],alreadyCompacted=True))
            continue
        candidates.append((root,tuple(actual),archive,claim['sha'],bytes_free))
        checks.append(dict(root=claim['root'],files=len(actual),physicalBytes=bytes_free,archiveSHA256=claim['sha']))
        if shutil.disk_usage(base).free+sum(entry[4] for entry in candidates)>=cfg['need']:
            break
    free=shutil.disk_usage(base).free
    recover=sum(entry[4] for entry in candidates)
    assert free+recover>=cfg['need'],(free,recover,cfg['need'])
    if cfg['mode']=='compact':
        # Preserve auxiliary non-file entries and the archived record.
        for root,files,archive,fingerprint,_ in candidates:
            for file in files:
                (root/file).unlink()
            assert sha(archive)==fingerprint
    print(json.dumps(dict(mode=cfg['mode'],before=free,after=shutil.disk_usage(base).free,
                          recoverablePhysicalBytes=recover,need=cfg['need'],checks=checks)))
'''
if mode=='compact':
    preview=read(quiet/'profile-space-preview.json')
    assert preview['config']==dict(config,mode='preview')
args=['ssh','-i',os.environ['LYTHON_BENCH_IDENTITY'],'-o','BatchMode=yes','-o','ConnectTimeout=12',
      os.environ['LYTHON_BENCH_HOST'],'python3 -']
r=subprocess.run(args,input='cfg='+repr(config)+'\n'+remote,encoding='utf-8',capture_output=True,timeout=54)
if r.returncode:
    print(r.stderr)
    r.check_returncode()
result=dict(config=config,result=json.loads(r.stdout))
(quiet/('profile-space-'+mode+'.json')).write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(r.stdout)
