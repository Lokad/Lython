from pathlib import Path
import gzip
import hashlib
import json
import re
import subprocess
import sys

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/'comparison/quiet'
read=lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
digest=lambda data:hashlib.sha256(data).hexdigest()
sha=lambda path:digest(path.read_bytes())
assert sys.argv[1:] in (['preview'],['reclaim'])
mode=sys.argv[1]
backup_root=lab/'preserved-cores'
backup_root.mkdir(exist_ok=True)

def archive_claim(directory, target, role, phase='quiet', root=None):
    prior=lab.with_name(directory)
    run=prior/'comparison'/phase
    status=read(run/'terminal-status.json')
    receipt=status['receipt']
    assert status['exitCode']=='0' and not status['live'] and not status['fixtures']
    assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
    archive=f'benchmarks/results/{target}/quiet-observations.tar.xz'
    published=subprocess.check_output(['git','show','origin/master:'+archive],cwd=repo)
    assert digest(published)==receipt['archiveSHA256']==sha(run/'observations.tar.xz')
    unit,=set(re.findall(r'lython-b[a-z0-9-]+\.service',status['journal']))
    image=read(run/'identity.json')['imageFiles'][role]
    assert len(image)==32
    return dict(root=root or read(run/'upload.json')['root'],role=role,unit=unit,image=image,
                archive=archive,archiveSHA256=receipt['archiveSHA256'])

source='closed-definition-construction-20261124'
claims=[archive_claim(source,'2026-11-24-closed-definition-construction','candidate')]
copies=[]
for source,claims in [(source,claims)]:
    frozen=lab.with_name(source)/'candidate'
    core=frozen/'Lokad.Lython.dll'
    assert {p.name:sha(p) for p in frozen.iterdir()}==claims[0]['image']
    assert all(c['image']['Lokad.Lython.dll']==claims[0]['image']['Lokad.Lython.dll'] for c in claims)
    backup=backup_root/(source+'.dll.gz')
    if mode=='preview' and not backup.exists():
        backup.write_bytes(gzip.compress(core.read_bytes(),mtime=0))
    assert digest(gzip.decompress(backup.read_bytes()))==sha(core)
    copies.append(dict(claims=claims,bytes=core.stat().st_size,backup=str(backup),
                       localImage=str(frozen)))
upload=read(quiet/'upload.json')
proof=dict(copies=copies,need=upload["minimumAfterStageBytes"]+upload["payloadBytes"]+upload["expandedBytes"]+upload["coreBytes"]+300000)
if mode=='reclaim':
    preview=read(quiet/'duplicate-core-preview.json')
    assert preview['proof']==proof and preview['result']['mode']=='preview'

script=r"""
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks')
assert base.resolve()==base
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
with (base/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert not any(p.is_mount() for p in base.glob('*/guest-fixtures'))
    references={}
    selected=[]
    for copy in cfg['copies']:
        first=copy['claims'][0]
        root=base/first['root']
        core=root/first['role']/'Lokad.Lython.dll'
        assert root.parent==base and root.resolve()==root and core.resolve()==core
        resolved=sorted(str(p.relative_to(base)) for role in ('candidate','reference')
                        for p in base.glob('*/'+role+'/Lokad.Lython.dll') if p.resolve()==core)
        expected=[]
        for claim in copy['claims']:
            stage=base/claim['root']
            image=stage/claim['role']
            assert stage.parent==base and stage.resolve()==stage
            assert (image/'Lokad.Lython.dll').resolve()==core
            assert {file.name:sha(file) for file in image.iterdir()}==claim['image']
            state=subprocess.check_output(['systemctl','show',claim['unit'],'--property=ActiveState,MainPID'],text=True).splitlines()
            assert 'ActiveState=inactive' in state and 'MainPID=0' in state,state
            receipt=json.loads((stage/'archive-receipt.json').read_text())
            assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
            assert receipt['archiveSHA256']==claim['archiveSHA256']==sha(stage/'observations.tar.xz')
            expected.append(str((image/'Lokad.Lython.dll').relative_to(base)))
        assert resolved==sorted(expected),resolved
        info=core.lstat()
        assert stat.S_ISREG(info.st_mode) and info.st_size==copy['bytes'] and info.st_nlink==1 and info.st_uid==os.getuid()
        selected.append((core,info.st_blocks*512))
        references[str(core.relative_to(base))]=resolved
    free=shutil.disk_usage(base).free
    recover=sum(bytes for core,bytes in selected)
    assert len({core for core,_ in selected})==1 and free+recover>=cfg['need']
    if mode=='reclaim':
        for core,_ in selected:core.unlink()
        for copy in cfg['copies']:
            for claim in copy['claims']:
                archive=base/claim['root']/'observations.tar.xz'
                assert sha(archive)==claim['archiveSHA256']
    print(json.dumps(dict(mode=mode,before=free,after=shutil.disk_usage(base).free,physicalBytes=recover,
                         need=cfg['need'],archiveDependencies=references)))
"""
key=Path.home()/'.ssh/id_lython-bench.pem'
result=subprocess.run(['ssh','-i',str(key),'-o','BatchMode=yes','-o','ConnectTimeout=12',
    'lokad@20.166.121.73','python3 -'],input='cfg='+repr(proof)+'\nmode='+repr(mode)+'\n'+script,
    encoding='utf-8',capture_output=True,timeout=54)
if result.returncode:
    print(result.stderr)
    result.check_returncode()
report=dict(result=json.loads(result.stdout),proof=proof)
(quiet/('duplicate-core-'+mode+'.json')).write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(result.stdout)
