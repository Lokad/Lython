from pathlib import Path
import json,subprocess

lab=Path(__file__).resolve().parent
ssh=["C:/Windows/System32/OpenSSH/ssh.exe","-i",str(Path.home()/".ssh/id_lython-bench.pem"),
     "-o","BatchMode=yes","-o","ConnectTimeout=12","lokad@20.166.121.73"]
query=r"""
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat
r=Path('/home/lokad/lython-bench-checks')
with (r/'comparison-vm.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not any(p.is_mount() for p in r.glob('*/guest-fixtures'))
 files={}
 for p in r.glob('*/candidate/Lokad.Lython.dll'):
  v=p.lstat()
  if p.resolve()!=p or not stat.S_ISREG(v.st_mode) or v.st_uid!=os.getuid():continue
  files[str(p.relative_to(r))]=dict(bytes=v.st_size,links=v.st_nlink,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 print(json.dumps(dict(free=shutil.disk_usage(r).free,files=files)))
"""
result=json.loads(subprocess.check_output(ssh+["python3 -"],input=query.encode(),timeout=33))
(lab/"remote-inventory.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8",newline="\n")
print(json.dumps(result,indent=2))
