from pathlib import Path
import json,gzip,hashlib,re,subprocess
lab=Path(__file__).resolve().parent
repo=lab.parents[3]
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda data:hashlib.sha256(data).hexdigest()
files={data["sha256"]:dict(path=name,**data) for name,data in read(lab/"remote-inventory.json")["files"].items()
       if data["links"]==1 and "factory-text-attribution" not in name}
tracked=set(subprocess.check_output(["git","ls-tree","-r","--name-only","origin/master","benchmarks/results"],cwd=repo,text=True).splitlines())
name_filter=re.compile(r"^[0-9a-f]{64}$")
matched=[]
for receipt in sorted((repo/"benchmarks/results").rglob("archive-receipt.json"),reverse=True):
    d=receipt.parent
    observations=d/"observations.tgz"
    if not observations.is_file() or observations.relative_to(repo).as_posix() not in tracked:continue
    try:
        info=read(receipt)
        if not info.get("complete") or not info.get("archivedAndVerifiedUnderLease"):continue
        outputs=[d/n for n in ("source.json","identity.json") if (d/n).is_file()]
        keys={h for path in outputs for h in re.findall(r'(?<![0-9a-f])[0-9a-f]{64}(?![0-9a-f])',path.read_text(encoding="utf-8-sig"))}&set(files)
        if not keys:continue
        for p in sorted(d.glob("*core.dll.gz")):
            if p.relative_to(repo).as_posix() not in tracked:continue
            blob=gzip.decompress(p.read_bytes())
            h=sha(blob)
            if h not in keys:continue
            identity=files[h]
            if len(blob)!=identity["bytes"]:continue
            row=dict(**identity,artifact=p.relative_to(repo).as_posix(),receipt=receipt.relative_to(repo).as_posix(),
                     observations=observations.relative_to(repo).as_posix(),archiveSHA256=info["archiveSHA256"])
            matched.append(row)
    except (OSError,ValueError,KeyError):continue
(lab/"matches.json").write_text(json.dumps(matched,indent=2)+"\n",encoding="utf-8",newline="\n")
for row in matched[:15]:print(row["path"],row["artifact"],row["archiveSHA256"],flush=True)
assert len(matched)>=2
