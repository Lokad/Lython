#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/immediate-definition-depth-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
export DOTNET_HOST_PATH="$DOTNET_ROOT/dotnet"
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/immediate-definition-depth-20261122
filter='Category!=Stress&(FullyQualifiedName~Function|FullyQualifiedName~Lambda|FullyQualifiedName~Closure|FullyQualifiedName~Default|FullyQualifiedName~Capture|FullyQualifiedName~Generator|FullyQualifiedName~Stack|FullyQualifiedName~Recursion|FullyQualifiedName~Refusal|FullyQualifiedName~Reentry|FullyQualifiedName~Definition|FullyQualifiedName~Annotation|FullyQualifiedName~Cancellation)'
dotnet build tools/LythonProbe/LythonProbe.csproj -c Release -f net10.0 --no-incremental --artifacts-path "$lab/ubuntu" > "$lab/build-ubuntu.log" 2>&1 || { tail -35 "$lab/build-ubuntu.log"; exit 1; }
probe="$lab/tools/LythonProbe/bin/Release/net10.0"
mkdir -p "$probe"
cp "$lab"/ubuntu/bin/LythonProbe/release_net10.0/* "$probe"
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$lab/white-ubuntu.log" 2>&1 || { tail -45 "$lab/white-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$lab/public-ubuntu.log" 2>&1 || { tail -45 "$lab/public-ubuntu.log"; exit 1; }
awk '/Passed!/{count++;print} END{exit count!=2}' "$lab/white-ubuntu.log" "$lab/public-ubuntu.log"