from pathlib import Path
import gzip,hashlib,json,subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
matches={"call-arena-b69-20261101":"2026-11-01-call-arena-rejected",
         "regex-errors-b60-20261101":"2026-11-01-pattern-error-metadata"}
inv=json.loads((lab/"remote-inventory.json").read_text(encoding="utf-8"))
out=lab/"remote-custody"
out.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
scp=["C:/Windows/System32/OpenSSH/scp.exe","-i",str(Path.home()/".ssh/id_lython-bench.pem"),
     "-o","BatchMode=yes","-o","ConnectTimeout=12"]
rows=[]
for root,history in matches.items():
    history=f"benchmarks/results/{history}/candidate-identity.json"
    pinned=subprocess.check_output(["git","show","origin/master:"+history],cwd=repo)
    proof=json.loads(pinned)
    path=root+"/candidate/Lokad.Lython.dll"
    identity=inv["files"][path]
    assert identity["sha256"]==proof["coreSHA256"] and identity["links"]==1
    binary=out/(root+".dll")
    subprocess.run(scp+["lokad@20.166.121.73:/home/lokad/lython-bench-checks/"+path,str(binary)],check=True,timeout=48,capture_output=True)
    data=binary.read_bytes()
    assert len(data)==identity["bytes"] and sha(data)==identity["sha256"]
    copy=out/(root+".dll.gz")
    copy.write_bytes(gzip.compress(data,compresslevel=9,mtime=0))
    assert sha(gzip.decompress(copy.read_bytes()))==identity["sha256"]
    rows.append(dict(paths=[path],**identity,archives={},copy=copy.name,oldIdentity=history,
                     oldIdentitySHA256=sha(pinned)))
    print(path,identity["bytes"],"storage copy verified",flush=True)
(out/"custody.json").write_text(json.dumps(rows,indent=2)+"\n",encoding="utf-8",newline="\n")
