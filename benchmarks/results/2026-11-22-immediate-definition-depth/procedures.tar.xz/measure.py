from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.parent/"factory-and-text-attribution-20261122"
fixtures=lab.parent/"function-diagnostic-identity-20261122/comparison"
out=lab/"comparison"
out.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
def save(p,value):p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
protocol=repo/"benchmarks/cpython-worker.py"
base_manifest=read(prior/"identity.json")
donor=base_manifest["imageFiles"]["candidate"]
frozen=prior/"frozen"
assert len(donor)==32 and {n:sha(frozen/n) for n in donor}==donor
assert sha(protocol)==base_manifest["protocolSHA256"]
control=read(fixtures/"representative.json")
source={row["id"]:row for row in (control["cases"]+read(lab.parent/"direct-lexical-keyword-default-20261122/representative.json")["cases"])}
postponed="scripts.annotated-rule-closures.nested-factories.postponed"
eager="scripts.annotated-rule-closures.nested-factories"
mixed=next((n for n in source if "literal" in n and "rule-closures" in n),None)
assert mixed is not None,list(source)
mixed_case=source[mixed]
ids=[postponed,eager,mixed,"scripts.factory-observed-defaults","scripts.ordinary-fully-supplied-helper",
     "scripts.csv-invoice.method-policy.quoted-control"]
control["cases"]=[source[n] for n in ids]
control["performanceQualified"]=False
catalog=out/"representative.json"
save(catalog,control)
save(out/"jobs.json",[(postponed,"warm"),(postponed,"compile-run"),*((n,"warm")for n in ids[1:])])
core="Lokad.Lython.dll"
candidate=lab/"windows/bin/Lokad.Lython/release_net11.0"/core
tree=repo/".git/agent-worktrees/immediate-definition-depth-20261122"
head=subprocess.check_output(["git","rev-parse","HEAD"],cwd=tree,text=True).strip()
assert head.startswith("e0ff18b00")
assert not subprocess.check_output(["git","diff",base_manifest["revision"],head,"--","src","tests"],cwd=repo)
patch=subprocess.check_output(["git","diff","--binary","HEAD","--","src"],cwd=tree)
assert patch.count(b"diff --git ")==2
(out/"source.patch").write_bytes(patch)
assert sha(candidate)!=donor[core]
with (lab/"probe-build.log").open("wb") as log:
    subprocess.run([dotnet,"build",lab/"Probe.csproj","-c","Release",f"-p:InspectionCorePath={candidate}"],
                   cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=70)
allocation=lab.parent/"deferred-word-binding-20261122/comparison/frozen-reference"
manifests={}
results={}
admissions={}
for role in ("reference","candidate"):
    image=out/("frozen-"+role)
    image.mkdir(exist_ok=True)
    for n in donor:shutil.copyfile(candidate if n==core and role=="candidate" else frozen/n,image/n)
    manifest={**donor,core:sha(candidate) if role=="candidate" else donor[core]}
    manifests[role]=manifest
    assert {n:sha(image/n) for n in manifest}==manifest
    for suffix in (".dll",".deps.json",".runtimeconfig.json"):
        n="ValidatedAllocation"+suffix
        shutil.copyfile(allocation/n,image/n)
        n="Probe"+suffix
        shutil.copyfile(lab/"bin/Release/net11.0"/n,image/n)
    receipt=out/(role+"-verify.json")
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog,
        "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",receipt],
        env=env,cwd=repo,check=True,timeout=90)
    check=read(receipt)
    assert check["state"]=="Completed" and check["caseCount"]==len(ids) and check["catalogSha256"]==sha(catalog)
    report=out/(role+"-allocation.json")
    subprocess.run([dotnet,image/"ValidatedAllocation.dll",image,catalog,report],env=env,cwd=repo,check=True,timeout=85)
    rows=read(report)["rows"]
    assert len(rows)==len(ids) and all(r["sharedBudgetBaselineRestored"] for r in rows)
    results[role]=rows
    report=out/(role+"-admission.json")
    with report.open("wb") as handle:
        subprocess.run([dotnet,image/"Probe.dll",catalog],env=env,cwd=repo,stdout=handle,check=True,timeout=45)
    admissions[role]=read(report)
    assert len(admissions[role])==5
    assert {n:sha(image/n) for n in manifest}==manifest
save(out/"identity.json",dict(reference=base_manifest["revision"],patchBase=head,imageFiles=manifests,
    protocolSHA256=sha(protocol),catalogSHA256=sha(catalog),sourcePatchSHA256=sha(out/"source.patch")))
for before,after in zip(results["reference"],results["candidate"],strict=True):
    assert before["id"]==after["id"] and before["peakExecutionMemoryBytes"]==after["peakExecutionMemoryBytes"]
    a,b=(statistics.median(x["allocatedBytesPerInvocation"]) for x in (before,after))
    print(before["id"],a,b,b-a,before["peakExecutionMemoryBytes"],flush=True)
for before,after in zip(admissions["reference"],admissions["candidate"],strict=True):
    assert (before["id"],before["Growths"],before["baseline"])==(after["id"],after["Growths"],after["baseline"])
    print("admission growths",before["id"],before["Growths"],flush=True)
