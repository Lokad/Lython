from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prev=lab.parent/"future-annotations-single-walk-20261122"/"comparison"
reference=lab.parent/"factory-and-text-attribution-20261122"
out=lab/"comparison"
quiet=out/"quiet"
core="Lokad.Lython.dll"
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda data:hashlib.sha256(data).hexdigest()
def h(p):return sha(p.read_bytes())
def git(*args):return subprocess.check_output(["git",*args],cwd=repo)
def write(p,s):
    if p.suffix==".py":compile(s,str(p),"exec")
    p.write_text(s,encoding="utf-8",newline="\n")
def save(p,obj):write(p,json.dumps(obj,indent=2)+"\n")
def committed(p):return git("show","origin/master:"+p)

p=read(prev/"quiet/config.json")
donor=read(reference/"quiet/config.json")
base="benchmarks/results/2026-11-22-factory-text-attribution/"
past=json.loads(committed(base+"identity.json"))
donation=json.loads(committed(base+"archive-receipt.json"))
assert donation["complete"] and donation["archivedAndVerifiedUnderLease"]
assert sha(committed(base+"observations.tgz"))==donation["archiveSHA256"]
assert past==donor["identity"] and donor["source"]!=donor["root"]
identity=read(out/"identity.json")
assert past["imageFiles"]["candidate"]==identity["imageFiles"]["reference"]
assert not git("diff",identity["reference"],identity["patchBase"],"--","src","tests")
tree=repo/".git/agent-worktrees/immediate-definition-depth-20261122"
candidate=git("-C",str(tree),"rev-parse","HEAD").decode().strip()
assert candidate.startswith("94deffb1c") and not git("-C",str(tree),"status","--porcelain")
patch=git("diff","--binary",identity["patchBase"],candidate,"--","src")
assert sha(patch)==identity["sourcePatchSHA256"] and patch==(out/"source.patch").read_bytes()
files=identity["imageFiles"]
assert [n for n,d in files["reference"].items() if files["candidate"][n]!=d]==[core]
catalog=out/"representative.json"
ids=[r["id"] for r in read(catalog)["cases"]]
jobs=[tuple(j)for j in read(out/"jobs.json")]
assert len(jobs)==7 and len(ids)==6
for role in files:
    assert len(files[role])==32 and {n:h(out/f"frozen-{role}"/n)for n in files[role]}==files[role]
    proof=read(out/f"{role}-verify.json")
    assert proof["catalogSha256"]==h(catalog) and proof["state"]=="Completed" and proof["caseCount"]==len(ids)
retire=read(lab/"remote-custody/custody.json")
assert len(retire)==2
for row in retire:
    assert sha(committed(row["oldIdentity"]))==row["oldIdentitySHA256"]
    assert sha(gzip.decompress((lab/"remote-custody"/row["copy"]).read_bytes()))==row["sha256"]
    data=json.loads(committed(row["oldIdentity"]))
    assert data["coreSHA256"]==row["sha256"] and row["links"]==1
    assert row["sha256"] not in (files["reference"][core],files["candidate"][core])
identity.update(sourceRevision=identity["reference"]+" versus "+candidate,candidate=candidate,
                testedRevision=candidate,purpose="Remove transient interpreter depth for immediate lexical definition construction",
                normalAdapterPin="0.4.0",coreSHA256={role+suffix:m[core]for role,m in files.items()for suffix in ("","-control")},
                catalogs={"representative.json":{"sha256":h(catalog)}})
root="/home/lokad/lython-bench-checks/immediate-definition-depth-b1423-20261122"
unit="lython-b1423-immediate-definition-depth-20261122"
quiet.mkdir(exist_ok=False)
save(quiet/"identity.json",identity)
shutil.copyfile(catalog,quiet/"representative.json")
(quiet/"candidate").mkdir()
shutil.copyfile(out/"frozen-candidate"/core,quiet/"candidate"/core)
for leaf in ("collect.py","run.sh","archive-owned.py","retrieve.py"):
    s=(prev/"quiet"/leaf).read_text(encoding="utf-8").replace(p["root"],root).replace(p["unit"],unit)
    s=s.replace("len(jobs)==6","len(jobs)==7").replace("len(raw['jobs'])==6","len(raw['jobs'])==7")
    s=s.replace("jobs=6,","jobs=7,").replace("['jobs']==6","['jobs']==7").replace("started < 345","started < 397")
    if leaf=="collect.py":
        a,b=s.index("\njob_catalog ="),s.index("\nassert len(jobs)")
        s=s[:a]+"\njob_catalog = "+repr({id:"representative.json"for id,_ in jobs})+"\njobs = "+repr(jobs)+s[b:]
    s=s.replace("Future validation","Immediate definition")
    write(quiet/leaf,s)
assert b"\r" not in (quiet/"run.sh").read_bytes()
parts=("identity.json","representative.json","collect.py","run.sh","archive-owned.py","candidate/"+core)
payload=quiet/"payload.tgz"
with tarfile.open(payload,"w:gz") as a:
    for n in parts:a.add(quiet/n,arcname=n)
cfg={**p,"root":root,"unit":unit,"identity":identity,"source":donor["root"],"sourceRole":"candidate",
     "sourceFiles":files["reference"],"sourceCatalogSHA256":past["catalogs"]["representative.json"]["sha256"],
     "donorArchiveSHA256":donation["archiveSHA256"],"retireGroups":retire,
     "payloadBytes":payload.stat().st_size,"payloadSHA256":h(payload),"unpackedBytes":sum((quiet/n).stat().st_size for n in parts)}
save(quiet/"config.json",cfg)
s=(prev/"quiet/remote-launch.py").read_text(encoding="utf-8")
a,b=s.index("\nc=")+1,s.index("\nb=Path(")
write(quiet/"remote-launch.py",(s[:a]+"c="+repr(cfg)+s[b:]).replace("b1421-fixtures","b1423-fixtures").replace("RuntimeMaxSec=425","RuntimeMaxSec=490"))
s=(prev/"launch.py").read_text(encoding="utf-8").replace("Future validation","Immediate definition")
write(out/"launch.py",s.replace("seconds=380","seconds=430").replace("before 380 seconds","before 430 seconds"))
s=(prev/"summarize.py").read_text(encoding="utf-8")
write(out/"summarize.py",s.replace("len(raw['jobs'])==6","len(raw['jobs'])==7"))
print(candidate,root,cfg["unpackedBytes"],flush=True)
