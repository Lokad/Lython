from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile,xml.etree.ElementTree as E
r=Path(__file__).parent;base=r.parent/'completed-async-r433';f=r/'frozen';f.mkdir();v=json.loads((base/'frozen/identity.json').read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
images={}
for role in ['reference','candidate']:
 shutil.copytree(base/'frozen/reference',f/role)
 for n,h in v['images']['reference'].items():assert sha(f/role/n)==h,n
 if role=='candidate':shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',f/role/'Lokad.Lython.dll')
 images[role]={p.name:sha(p)for p in(f/role).iterdir()if p.is_file()}
assert all(images['candidate'][n]==h for n,h in images['reference'].items()if n!='Lokad.Lython.dll')
paths=list(v['sources'])+['tests/Lokad.Lython.Tests/SubtextOwnershipTests.cs'];assert len(set(paths))==602
with tarfile.open(f/'sources-and-checks.tar.xz','w:xz')as a:
 for n in paths:a.add(n,arcname=n)
 a.add(r/'checks',arcname='checks');a.add(r/'build.log',arcname='build.log')
v.update(buildSourceCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),prototype=True,images=images,sources={n:sha(Path(n))for n in paths},contracts='Existing immutable same-owner UTF8 windows shared by ordinary slices and aggregate split output. Source backing/header remain with existing owner; transformed/foreign/unowned fragments copied, short values inline. No new owner/cache/trace/policy. Terminal refusal and aggregate preflight retained. Full qualification pending.')
(f/'identity.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};checks=[dict(file=p.name,**E.parse(p).find('t:ResultSummary/t:Counters',ns).attrib)for p in sorted((r/'checks').glob('*.trx'))];assert sorted(int(x['passed'])for x in checks)==[88,88,703,703]and all(x['failed']=='0'for x in checks)
(r/'focused-checks.json').write_text(json.dumps(dict(checks=checks,nonincrementalReleaseBuild=True,fullQualificationPending=True),indent=2)+'\n',encoding='utf-8',newline='\n')
d=r/'allocation-short';d.mkdir()
for n in ['Allocation.csproj','Program.cs','catalog.json']:shutil.copyfile(base/'allocation-short'/n,d/n)
shutil.copyfile(base/'measure-allocation.py',r/'measure-allocation.py');shutil.copyfile(base/'catalog.json',r/'catalog.json');shutil.copyfile(base/'extra.json',r/'extra.json')
print(json.dumps(dict(coreSHA256=images['candidate']['Lokad.Lython.dll'],inputs=len(paths),checks=sorted(int(x['passed'])for x in checks))))
