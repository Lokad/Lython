from pathlib import Path
import ast,hashlib,io,json,subprocess,tarfile
r=Path(__file__).parent;q=r/'quiet';c=json.loads((q/'config.json').read_text(encoding='utf-8'));c['retireGroups']=c['retireGroups'][:3];commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
for root,archive in [('completed-async-b830-20261116','benchmarks/results/2026-11-16-completed-async-entry/observations.tgz'),('normalization-cost-b831-20261116','benchmarks/results/2026-11-16-subtext-attribution/observations.tgz')]:
 raw=Path(archive).read_bytes();assert raw==subprocess.check_output(['git','show',commit+':'+archive])
 with tarfile.open(fileobj=io.BytesIO(raw))as a:
  for m in a.getmembers():
   if not m.isfile()or m.name in ['catalog.json','representative.json','additional.json','cpython-worker.py','observations.tgz']:continue
   if '/'in m.name and not(m.name.startswith('__pycache__/')or m.name in ['confirmation/machine-before.json','confirmation/machine-after.json','confirmation/fixture-filesystem.txt']):continue
   data=a.extractfile(m).read();c['retireGroups'].append(dict(sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),links=1,paths=[root+'/'+m.name],custody=dict(commit=commit,archive=archive,archiveSHA256=hashlib.sha256(raw).hexdigest(),member=m.name)))
assert len({p for g in c['retireGroups']for p in g['paths']})==len(c['retireGroups'])
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(q/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path',a);s=s[:a]+'c='+repr(c)+s[b:];ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
(q/'launch.log').unlink()
print(json.dumps(dict(retireOnlyCommittedCompletedWorkingEvidence=True,bytes=sum(g['bytes']for g in c['retireGroups']),minimumFreeBefore=254*1024*1024+c['unpackedBytes']+65536-sum(g['bytes']for g in c['retireGroups']),proofs=len(c['retireGroups']))))
