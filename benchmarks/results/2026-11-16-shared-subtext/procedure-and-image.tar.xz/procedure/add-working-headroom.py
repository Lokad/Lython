from pathlib import Path
import ast,hashlib,io,json,shutil,subprocess,tarfile
r=Path(__file__).parent;q=r/'quiet';original=r/'original-floor-stage';original.mkdir()
for p in q.iterdir():
 if p.is_file():shutil.copyfile(p,original/p.name)
c=json.loads((q/'config.json').read_text(encoding='utf-8'));archive='benchmarks/results/2026-11-16-line-construction/confirmation/observations.tgz';raw=Path(archive).read_bytes();commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert raw==subprocess.check_output(['git','show',commit+':'+archive])
with tarfile.open(fileobj=io.BytesIO(raw))as a:
 for m in a.getmembers():
  if not m.isfile()or '/'in m.name or m.name in ['observations.tgz','representative.json','additional.json','cpython-worker.py']:continue
  data=a.extractfile(m).read();c['retireGroups'].append(dict(sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),links=1,paths=['line-confirm-b828-20261116/'+m.name],custody=dict(commit=commit,archive=archive,archiveSHA256=hashlib.sha256(raw).hexdigest(),member=m.name)))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n');s=(q/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path',a);s=s[:a]+'c='+repr(c)+s[b:];ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n');(q/'launch.log').unlink()
print('Additional verified completed-controller replicas only;254/252MiB floors unchanged.')
