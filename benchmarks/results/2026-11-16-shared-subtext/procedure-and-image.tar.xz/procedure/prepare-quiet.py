from pathlib import Path
import ast,hashlib,io,json,subprocess,tarfile
r=Path(__file__).parent;q=r/'quiet';q.mkdir();old=r.parent/'completed-async-r433/quiet';original=json.loads((old/'config.json').read_text(encoding='utf-8'));frozen=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));files=original['sourceFiles'];images={role:{n:frozen['images'][role][n]for n in files}for role in ['reference','candidate']};assert images['reference']==files
sha=lambda b:hashlib.sha256(b).hexdigest();commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();proofs=[]
def proof(archive,member,path):
 raw=Path(archive).read_bytes();assert raw==subprocess.check_output(['git','show',commit+':'+archive])
 with tarfile.open(fileobj=io.BytesIO(raw))as a:data=a.extractfile(member).read()if member else raw
 proofs.append(dict(sha256=sha(data),bytes=len(data),links=1,paths=[path],custody=dict(commit=commit,archive=archive,archiveSHA256=sha(raw),member=member)))
archive='benchmarks/results/2026-11-16-completed-async-entry/observations.tgz';proof(archive,'confirmation/confirmation.json','completed-async-b830-20261116/confirmation/confirmation.json');proof(archive,None,'completed-async-b830-20261116/observations.tgz')
proof('benchmarks/results/2026-11-16-subtext-attribution/observations.tgz',None,'normalization-cost-b831-20261116/observations.tgz')
proof('benchmarks/results/2026-11-16-current-call-attribution/observations.tgz',None,'current-calls-b815-20261115/observations.tgz')
remote='/home/lokad/lython-bench-checks/subtext-storage-b832-20261116';unit='lython-b832-subtext-storage-20261116'
identity=dict(sourceRevision='R435 prototype'+images['candidate']['Lokad.Lython.dll'][:8]+' versus qualified86d9344e/ecd9e956',purpose='One complete-script immutable-subtext storage source pair: normalization warm/fresh, JSON-lines warm, unchanged compilation control; no prior CPU gain assumed.',coreSHA256={label:images['candidate'if label.startswith('candidate')else'reference']['Lokad.Lython.dll']for label in ['reference','reference-control','candidate','candidate-control']},imageFiles=images,prototype=True,publicationHeld=True,referenceQualification='43805966777GREEN Windows/Ubuntu actual11/10 ordinary/stress/installed Release consumers; terminal cached.',candidateFocusedChecks=json.loads((r/'focused-checks.json').read_text(encoding='utf-8')),candidateSourceIdentitySHA256=sha((r/'frozen/identity.json').read_bytes()))
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py']:
 s=(old/name).read_text(encoding='utf-8').replace(original['root'],remote).replace(original['unit'],unit).replace('B830','B832')
 if name=='collect.py':
  s=s.replace("cases.update({c['id']:c for c in json.loads((root/'extra.json').read_text())['cases']})\n",'')
  start=s.index('jobs=');end=s.index('\nassert len(jobs)',start)
  s=s[:start]+"jobs=[['scripts.text-normalization.large','warm'],['scripts.text-normalization.large','compile-run'],['scripts.json-summary-helpers.large','warm'],['scripts.text-normalization.large','compile']]"+s[end:]
  s=s.replace("catalog = root/('extra.json'if case_id=='scripts.file-search.large.protected'else'representative.json')","catalog = root/'representative.json'")
 if name.endswith('.py'):ast.parse(s)
 (q/name).write_text(s,encoding='utf-8',newline='\n')
payload={n:(q/n).read_bytes()for n in ['identity.json','collect.py','archive-owned.py','run.sh']};payload['candidate/Lokad.Lython.dll']=(r/'frozen/candidate/Lokad.Lython.dll').read_bytes()
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for name,data in payload.items():
  member=tarfile.TarInfo(name);member.size=len(data);a.addfile(member,io.BytesIO(data))
c=dict(root=remote,unit=unit,source=original['source'],sourceFiles=files,sourceCatalogSHA256=original['sourceCatalogSHA256'],catalogSHA256=original['catalogSHA256'],identity=identity,retireGroups=proofs,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha((q/'payload.tgz').read_bytes()),unpackedBytes=sum(len(b)for b in payload.values()))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path',a);s=s[:a]+'c='+repr(c)+s[b:];s=s.replace('lython-b830-fixtures','lython-b832-fixtures');ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(r.parent/'completed-async-r433/launch-quiet.py').read_text(encoding='utf-8');(r/'launch-quiet.py').write_text(s,encoding='utf-8',newline='\n')
s=(r.parent/'completed-async-r433/summarize.py').read_text(encoding='utf-8');(r/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(dict(candidate=images['candidate']['Lokad.Lython.dll'],retireBytes=sum(p['bytes']for p in proofs),unpackedBytes=c['unpackedBytes'],jobs=4)))
