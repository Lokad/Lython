from pathlib import Path
import hashlib,json,tarfile,xml.etree.ElementTree as E
r=Path(__file__).parent;old=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));out=r/'source-qualification';out.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
drift=[n for n,h in old['sources'].items()if sha(Path(n))!=h];assert drift==['tests/Lokad.Lython.Tests/SubtextOwnershipTests.cs'],drift
assert sha(Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'))==old['images']['candidate']['Lokad.Lython.dll']
v=dict(old);v['sources']={n:sha(Path(n))for n in old['sources']};v.update(testOnlyCorrection='The new ownership test originally kept a thread-local ambient scope across await, contaminating later white-box tests. Scope now ends before actual suspension. All runtime sources/core unchanged; original failed run/source preserved.',runtimeImageUnchangedAfterTestBuild=True,fullQualificationPending=True)
(out/'identity.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};rows=[]
for kind in ['corrected-internal','broader-public']:
 for tfm in ['net11.0','net10.0']:
  p=r/'checks'/(kind+'-'+tfm+'.trx');rows.append(dict(file=p.name,**E.parse(p).find('t:ResultSummary/t:Counters',ns).attrib))
assert sorted(int(x['passed'])for x in rows)==[548,548,3619,3619]and all(x['failed']=='0'for x in rows)
(out/'focused-checks.json').write_text(json.dumps(dict(checks=rows,runtimeImageUnchanged=True,originalFailedAmbientFixturePreserved=True,fullQualificationPending=True),indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'sources-and-checks.tar.xz','w:xz')as a:
 for n in v['sources']:a.add(n,arcname=n)
 a.add(r/'checks',arcname='checks');a.add(r/'original-ambient-fixture',arcname='original-ambient-fixture');a.add(r/'build.log',arcname='build.log')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');needle='| Latest external baseline |';idx=s.index(needle);s=s[:idx]+'''| Active uncommitted runtime prototype | **R435 /1c8e1be5**, shared immutable UTF8 subtext. Existing JSON window representation now funds same-owner slices/split fragments without per-fragment arrays/copies; foreign/transformed/short cases remain independent/inline. Nonincremental Release;548internal/3,619public focused eachactual11/10. Test-only ambient-scope correction preserves assertions; failed run/source retained, core unchanged. Whole-job allocation normalization−19.8%/JSON-lines−11.3%, accounting peaks lower; B832warm/fresh/JSON/compile-control pair active. No CPU/retention/full-delivery claim yet. |
'''+s[idx:];s=s.replace('including newly generated scripts compiled and run once.', 'including newly generated scripts compiled and run once.')
s=s.replace('   JSON/CSV controls; Unicode/scalar boundaries, nested trims/splits, mutation/identity,', '   JSON-lines and CSV, compilation control; Unicode/scalar boundaries, nested trims/splits, mutation/identity,')
p.write_text(s,encoding='utf-8',newline='\n');print('602corrected source inputs;548internal/3619public eachactual11/10; runtime1c8eunchanged.')
