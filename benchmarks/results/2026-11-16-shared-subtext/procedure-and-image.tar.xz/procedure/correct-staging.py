from pathlib import Path
import ast,hashlib,io,json,shutil,subprocess,tarfile
r=Path(__file__).parent;q=r/'quiet';old=r/'original-failed-stage';old.mkdir()
for p in q.iterdir():
 if p.is_file():shutil.copyfile(p,old/p.name)
identity=json.loads(Path('benchmarks/results/2026-11-16-compiler-instruction-store/identity.json').read_text(encoding='utf-8'));core=identity['images']['candidate']['Lokad.Lython.dll']
s=(r.parent/'completed-async-r433/inspect-vm.py').read_text(encoding='utf-8').replace('line-construction-b827-20261116/reference/Lokad.Lython.dll','compiler-store-b820-20261116/candidate/Lokad.Lython.dll').replace('efd8270751e008587042c729869e214f000f1730a4e05683ae6ed4c6351f62db',core)
(r/'inspect-obsolete-compiler-core.py').write_text(s,encoding='utf-8',newline='\n');print('Original staging failure preserved before correction; inspect only obsolete9d aliases, no mutation.')
