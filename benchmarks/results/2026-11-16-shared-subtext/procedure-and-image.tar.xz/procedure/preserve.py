from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;q=r/'quiet';out=Path('benchmarks/results/2026-11-16-shared-subtext');out.mkdir()
receipt=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['quietBeforeAndAfter']and receipt['allWorkersJoined'];assert hashlib.sha256((q/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
v=json.loads((r/'summary.json').read_text(encoding='utf-8'));v.update(retentionDecisionPending=False,retained=True,fullQualificationPending=True,decision='Retain existing-window subtext storage. Remove independent UTF8 payload arrays/copies for same-owner immutable slices/split fragments, retaining aggregate admission and backing/header funding. Normalization allocation−19.8%, JSON-lines−11.3%; supporting warm/fresh CPU evidence with process-control movement explicit. No new owner/cache/ledger, broad async/CPython/startup or embedding-latency claim. Conservative sibling retention until owner cleanup is intentional.');(out/'summary.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
for n in ['identity.json','archive-receipt.json','terminal-status.json','observations.tgz']:shutil.copyfile(q/n,out/n)
shutil.copyfile(r/'allocation-summary.json',out/'allocation-summary.json');shutil.copyfile(r/'source-qualification/focused-checks.json',out/'focused-checks.json');shutil.copyfile(r/'source-qualification/identity.json',out/'source-identity.json');shutil.copyfile(r/'source-qualification/sources-and-checks.tar.xz',out/'sources-and-checks.tar.xz')
with tarfile.open(out/'procedure-and-image.tar.xz','w:xz')as a:
 for n in ['identity.json','candidate/Lokad.Lython.dll']:a.add(r/'frozen'/n,arcname='frozen/'+n)
 for p in r.glob('*.py'):a.add(p,arcname='procedure/'+p.name)
 a.add(r/'original',arcname='original-production');a.add(r/'build.log',arcname='build.log')
 for folder in ['quiet','original-failed-stage','original-floor-stage']:
  for p in (r/folder).iterdir():
   if p.is_file()and p.name not in ['observations.tgz','payload.tgz']:a.add(p,arcname=folder+'/'+p.name)
 for n in ['Program.cs','Allocation.csproj','reference.json','candidate.json','image-hashes.json','catalog.json','build.log']:a.add(r/'allocation-short'/n,arcname='allocation/'+n)
(out/'README.md').write_text('''# Shared immutable subtext storage

R435/B832,2026-11-16UTC, retained **1c8e1be5** versus qualified
**86d9344e /ecd9e956**. Full delivery pending; publication held.

Ordinary slices and split fragments now use the same admitted immutable UTF8
window representation as JSON. This removes their independent payload arrays and
copies. Aggregate split construction admits list/fragments/header together before
allocation; source backing/header stay funded after private shell cleanup. Short
inline values, transformed output and foreign/unowned input keep independent
construction. No new owner, cache, tracing, ledger or execution route.

**Tradeoff:** a small surviving view conservatively keeps the whole backing until
its existing owner ends. Earlier rejection from sibling retention is acceptable;
no exact tiny-budget compatibility. Source sharing metadata can stay charged after
an interrupted private construction; all scope cleanup still returns to baseline.
No retained backing is refunded while an alias or pending user can access it.

| Complete workload / phase | Elapsed candidate/reference | Wider CPU | Ref/candidate process-median spreads |
| --- | ---: | ---: | ---: |
| Normalization warm | −4.62..−1.84% | −6.02..−0.95% | 0.05/2.86% |
| Normalization compile-to-result | −4.97..−1.15% | −4.30..−0.13% | 3.37/0.63% |
| JSON-lines helpers warm | −5.57..−2.86% | −5.56..−1.59% | 1.40/1.45% |
| Unchanged normalization compilation control | −1.99..+0.67% | −2.64..−0.14% | 1.52/1.18% |

All four process pairings, not confidence intervals. Five rotated approximately
0.5s batches after5s full-request warmup(8s compile), two processes/source;
151.601s/all image/golden/quiet/Closed/exit/join/archive gates. IQR≤1.65%.
Fresh reference moves3.37%; exact magnitudes remain diagnostic. No compiler gain
is attributed to unchanged frontend code. Source-pair gains cannot be added to
earlier experiments or inferred from the separate CPython collections.

Local natural-GC whole-job allocation: normalization **−19.8%**(both hosting APIs),
JSON-lines **−11.3%**, protected search unchanged. Accounted peaks fall2,515,196→
2,324,834B and4,060,103→3,954,823B respectively; these are conservative estimates,
not physical heap/RSS. JSON-lines is affected through ordinary line subtext, not
an unchanged workload control. No async CPU/startup/embedding-tail claim.

Same F4as_v7/Ubuntu24.04.4,four EPYC9V45vCPUs,16GiB/no swap,.NET11RC3
normal tiering/workstation GC. Warm includes mediated RAM I/O, full stdout/file
goldens and prior-result cleanup; excludes compilation/startup, reset/protocol and
final cache teardown. Fresh includes compilation/compiled-owner disposal; wider
process CPU includes reset/protocol. Separate phase medians are not additive.

Focused actual.NET11/10 each **548internal/3,619public** pass. Coverage includes
Unicode/scalar boundaries, nested slices/splits/trims, hashing, retained backing,
foreign-owner copies, terminal refusal, current cancellation, suspended users and
cleanup/budget reuse. Original new-test ambient scope incorrectly spanned await,
contaminating later white-box tests; correct it to end before suspension, preserving
all assertions. Original5failures/source retained, measured core unchanged after
test-only builds.602corrected production/build/test inputs frozen; original staged
identity retained separately. No unchanged runtime measurement repeated.

Original staging failures stopped before mutation/capture: already-retired old
working archive, a rejected old-core read, Windows command length and unchanged
disk headroom. Correct transport and retire only exact committed completed working
replicas with fresh path/UID/hash/all-alias proof; no floor lowered. Both current
images/catalogs/toolchains retained. Persistent evidence verified before RAM teardown,
all users joined, terminal cached. Broad call/frame/operand work remains open.

[All controls](summary.json),[allocation](allocation-summary.json),
[raw](observations.tgz),[focused checks](focused-checks.json),
[corrected source identity](source-identity.json),[source/TRX/original failure](sources-and-checks.tar.xz),
[exact image/procedures/staging conditions](procedure-and-image.tar.xz).
Baseline auxiliary image is unchanged from
[line construction](../2026-11-16-line-construction/README.md).
''',encoding='utf-8',newline='\n')
p=Path('docs/RUNTIME.md');s=p.read_text(encoding='utf-8');old='''separators, using the active execution context. Final list capacity and independent
fragments are admitted together before allocation. A whole unchanged same-owner
input can remain an alias. Existing range-loan capacity stays funded when cached;
working overlap and conservative capacity can cause earlier rejection.''';new='''separators, using the active execution context. Final list capacity, fragment shells
and any shared-backing header are admitted together before allocation. Ordinary
long fragments and slices share immutable UTF-8 backing already funded by the same
owner. Short inline values, transformed output and foreign/unowned input retain
independent construction. A whole unchanged same-owner input can remain an alias.
Relinquishing a private source shell never refunds its shared backing: a small view
can keep the entire capacity charged until owner cleanup. This conservative sibling
retention, cached range capacity and replacement overlap can cause earlier rejection;
exact tiny-budget thresholds are not a compatibility contract.''';assert old in s;s=s.replace(old,new);p.write_text(s,encoding='utf-8',newline='\n')
p=Path('CHANGELOG.md');s=p.read_text(encoding='utf-8');s=s.replace('## 0.11.0 - Unreleased\n','''## 0.11.0 - Unreleased

- Share admitted immutable UTF-8 backing across ordinary slices and split fragments,
  removing independent payload arrays and copies. Preserve aggregate admission and
  funding for retained aliases; small views can conservatively retain full source
  capacity until ownership cleanup. Foreign and transformed input remains independent.
''',1);p.write_text(s,encoding='utf-8',newline='\n')
p=Path('docs/BENCHMARKS.md');s=p.read_text(encoding='utf-8');needle='| --- | --- | ---: | --- |';assert s.count(needle)==1;s=s.replace(needle,needle+'\n| Shared immutable subtext / complete normalization and JSON-lines | Normalization warm1.8–4.6%lower/fresh1.1–5.0%lower; JSON warm2.9–5.6%lower, supporting CPU | −19.8% /−11.3% | Retained1c8e1be5/ecd9e956; whole backing remains funded, fresh reference moves3.37%. [Evidence/limits](../benchmarks/results/2026-11-16-shared-subtext/README.md); full delivery pending. |',1);p.write_text(s,encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');s+='\n\n[R435/B832 shared immutable subtext retained](results/2026-11-16-shared-subtext/README.md):1c8e1be5/ecd9e956,151.601s/all gates. Normalization allocation−19.8%/JSON-lines−11.3%, accounted peaks lower; warm/fresh elapsed/CPU lower with3.37%moving fresh reference explicit. Existing JSON windows replace ordinary slice/split payload copies; full source backing/header stays funded, foreign/transformed input independent.548internal/3619public eachactual11/10; new-test-only ambient-scope correction preserves assertions/runtime image, original failure retained. Original staging/transport/floor failures retained. Full602input delivery next; broader performance objective open.\n';p.write_text(s,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');a=s.index('| Active uncommitted runtime prototype | **R435');b=s.index('\n| Latest external baseline |',a);s=s[:a]+'''| Retained, awaiting commit/full qualification | **R435 /1c8e1be5**, [shared immutable subtext](benchmarks/results/2026-11-16-shared-subtext/README.md).602corrected inputs,548internal/3,619public eachactual11/10; original test-only ambient failure retained/core unchanged. B832151.601s/all gates: normalization allocation−19.8%, JSON-lines−11.3%, accounted peaks lower. Warm/fresh elapsed/CPU lower; moving3.37%fresh reference retained. Conservative full-backing retention explicit; no CPython/async-CPU/embedding-tail claim. |'''+s[b:];s=s.replace('4. **R434 attribution complete; R435 selected: shared immutable subtext storage.**','4. **R434/R435 implementation and measurement complete; combined delivery next.**');a=s.index('   **Affected scripts/acceptance:**');b=s.index('\nR429retains',a);s=s[:a]+'''   **Outcome:** retained shared storage; normalization allocation−19.8%, JSON-lines
   −11.3%, accounting peaks lower. Warm/fresh/JSON elapsed and wider CPU lower in
   B832;3.37%moving fresh reference and original staging conditions explicit.602
   corrected inputs,548internal/3619public eachactual11/10. Test-only ambient scope
   ends before await; all assertions remain, original failure/source preserved and
   runtime image unchanged. Commit, then one full Windows/Ubuntu actual11/10,
   original stress plus line case, installed Release consumer checkpoint. No new
   external CPython/async CPU/embedding-tail claim or repeated unchanged timings.
   Whole backing stays charged for surviving views; foreign input copied.

5. **Resume complete call/frame/operand design after dispatching delivery.** R433's
   extra entry layers were withdrawn, not generalized. R434's instruction-loop
   exclusive119/926samples is useful evidence, while531inclusive generator samples
   overlap work and do not justify a second backend. Investigate whether one managed
   operand execution kernel can serve stack-local calls and persistent frames,
   eliminating a complete duplicate dispatch/transfer stage. First map exception,
   callback, suspension, cursor and owner lifetimes; do not add an adapter view or
   widen every reference-only row without a concrete removal/completion design.
   Preserve current semantics, native completed paths, cancellation/admission and
   managed stack. Stop source feasibility with a concrete phased replacement and
   semantic/performance gates, or explicit unsolved invariants. Regressed R403/R411
   controls remain lessons. Independent regex development stays available; missing
   producer capabilities defer only affected final adapter qualification.
'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n');print('Shared subtext retained; docs/contracts/evidence/PLAN updated.602input full delivery next.')
