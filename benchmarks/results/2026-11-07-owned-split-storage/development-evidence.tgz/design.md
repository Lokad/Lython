# R28 bounded owned split-result storage gate

Current R26 source fully qualified, no runtime edit yet. New allocation evidence
supports investigating text final storage, not a claimed CPU cause. Earlier shared
windows added8B/string and measured slower. This design must keep56B strings and
no new lifetime/refcount/identity ledger, cache, pool or policy.

Delete separate hash-computed flag. Volatile nonzero hash is its own published
cache value; zero may recompute correctly. Add offset in the recovered metadata
space. Owning strings retain offset marker0; shared-result words use complemented
offset, allowing offset-zero views to distinguish metadata-only ownership.
Every direct backing read/copy must use the actual byte window; Unicode/scalar
offset caches remain window-relative. Measure actual object footprint before
promotion; no raw pointers, Unsafe APIs or unsafe compilation.

Ownership gate rejects arbitrary existing source slices. TextFileHandle.Read
captures decoded.CommittedOwnedBytes into _windowCharge and explicitly releases
it as working input ends. Governor identity therefore does not prove backing
can escape. Do not introduce a shared-source flag or audit/refactor all those
owners. Restrict sharing to one NEW immutable split-result payload, its capacity
committed directly to the execution owner before creating any word views. Word
snapshots/refunds account only metadata and their own rune-index cache; they
never refund that shared capacity. Existing same-batch/result owner retains it
until all users/results/cleanup end. This trades conservative retention for no
reference counting or arbitrary reference-withdrawal recovery.

Before allocation reserve checked aggregate backing+metadata+list capacity with
headroom. Reuse current working reservation. Keep scratch/replacement overlap,
long-loop token checks and first terminal refusal. Sharing only if there are
multiple nonempty words and combined backing is representable as one CLR array;
single-word/unrepresentable combined shapes keep required owned construction.
These are representation cases, not quotas or tuning knobs. Casing writes each
word into its conservative range of that one payload, retaining expansion/context
and whitespace boundaries. No repeated reserve/refund of live backing.

Semantic gate: indexing/stepped slices/concat/repeat/iteration/format/repr/hash/
equality, UTF8 provider byte windows/scalar offsets, Unicode final sigma and full
expansions, split/rsplit/maxsplit, aliases and retained-result funding. Existing
file-window cleanup must remain unchanged. Metadata-only private-word withdrawal
cannot refund data used by another word. Refusal precedes output publication;
cancel/error cleanup restores temporary balances, and owner disposal returns
the root to baseline only after users finish.

Use focused actual11/10 Release, existing eight-case exact allocation both APIs,
then one short text/report source pair with CSV/JSON controls if source/ownership
gates pass. Decide remaining R26/regression debt explicitly. Retain all adverse
results and old rejected conditions. VM near-full preflight is an external
staging limitation, not a reason to stop independent source/local checks or
silently remove raw archives/binaries. Publication remains postponed.
