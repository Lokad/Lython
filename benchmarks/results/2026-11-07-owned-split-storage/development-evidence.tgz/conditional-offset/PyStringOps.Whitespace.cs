using System.Text;

namespace Lokad.Lython.Runtime.Text;

internal static partial class PyStringOps
{
    // Python 3.13's 29 whitespace scalars. Keeping this small inventory explicit
    // avoids BCL Unicode-version drift and includes Python's four C0 separators.
    internal static bool IsPythonWhitespace(Rune rune) => rune.Value <= 0x7F
        ? IsAsciiWhitespace((byte)rune.Value)
        : rune.Value is 0x85 or 0xA0 or 0x1680 or >= 0x2000 and <= 0x200A or
            0x2028 or 0x2029 or 0x202F or 0x205F or 0x3000;

    private static bool IsAsciiWhitespace(byte value)
        => value is >= 0x09 and <= 0x0D or >= 0x1C and <= 0x20;

    // The caller has classified the first (or last) ASCII byte. Stop at a
    // category change or any UTF-8 byte, leaving Unicode decoding to the caller.
    private static int AsciiWhitespaceRunLength(ReadOnlySpan<byte> chunk, bool whitespace, bool reverse = false)
    {
        var width = 1;
        while (width < chunk.Length)
        {
            var value = chunk[reverse ? chunk.Length - width - 1 : width];
            if (value >= 0x80 || IsAsciiWhitespace(value) != whitespace) break;
            width++;
        }
        return width;
    }

    internal static PyList SplitCasedWhitespace(PyString value, bool upper,
        MemoryGovernor governor, LythonSourceSpan span, LythonRuntime.ExecutionContext context)
        => SplitWhitespaceCore(value, -1, false, governor, span, context,
            upper ? CaseMapping.Upper : CaseMapping.Lower);

    private static PyList SplitWhitespaceCore(PyString value, int maxSplit, bool reverse,
        MemoryGovernor? governor, LythonSourceSpan? span, LythonRuntime.ExecutionContext? context,
        CaseMapping? casing = null)
    {
        governor ??= value.OwnerMemoryGovernor;
        span ??= PyStructuralGuard.AmbientSpan;
        context ??= PyStructuralGuard.AmbientContext;
        governor?.ThrowIfAdmissionFailed();
        context?.CheckExecution(span);
        var source = value.Utf8Bytes.Span;
        // Fixed, memory-safe stack scratch; larger results admit their backing
        // through the existing reservation before allocating a replacement.
        Span<(int Start, int End, int Capacity)> ranges = stackalloc (int, int, int)[8];
        var count = 0;
        long outputBytes = 0, scratchBytes = 0;
        MemoryGovernor.TemporaryMemoryReservation? scratch = null;
        try
        {
            if (reverse)
                CollectWhitespaceReverse(source, maxSplit, ref ranges, ref count, ref outputBytes,
                    ref scratchBytes, ref scratch, governor, span, context);
            else
                CollectWhitespaceForward(source, maxSplit, ref ranges, ref count, ref outputBytes,
                    ref scratchBytes, ref scratch, governor, span, context, casing);

            // A new immutable payload belongs to this result's execution owner,
            // not the possibly temporary input window. Word metadata can retire
            // independently without refunding another word's backing.
            var payloadBytes = outputBytes - count * PyString.EstimateApproximateBytes(0);
            var sharePayload = count > 1 && payloadBytes <= Array.MaxLength;
            var listBytes = PyList.EstimateCapacityBytes(count);
            // Each word's existing estimate includes buffer-header headroom.
            // Any retained word funds that metadata; charge payload capacity
            // independently, without adding another header to the whole result.
            var outputCharge = checked(outputBytes + listBytes);
            using var output = governor?.ReserveTemporary(outputCharge, span);
            context?.CheckExecution(span);
            var parts = count == 0 ? Array.Empty<object>() : new object[count];
            var payload = sharePayload ? new byte[(int)payloadBytes] : null;
            var payloadOffset = 0;
            for (var index = 0; index < count; index++)
            {
                context?.CheckExecution(span);
                var range = ranges[reverse ? count - index - 1 : index];
                var bytes = payload ?? new byte[range.Capacity];
                var offset = payload is null ? 0 : payloadOffset;
                var destination = bytes.AsSpan(offset, range.Capacity);
                var written = destination.Length;
                if (casing is { } mapping)
                {
                    // Whitespace is case-stable and breaks final-sigma context.
                    // Write final words without materializing a cased source.
                    written = WriteCaseUtf8(source[range.Start..range.End], destination, mapping, context, span);
                }
                else
                    for (var copied = 0; copied < destination.Length;)
                    {
                        context?.CheckExecution(span);
                        var chunk = Math.Min(4096, destination.Length - copied);
                        source.Slice(range.Start + copied, chunk).CopyTo(destination.Slice(copied, chunk));
                        copied += chunk;
                    }
                var fragment = payload is not null ? PyString.FromSharedResultUtf8(payload, offset, written, governor)
                    : governor is null ? PyString.FromReservedUtf8(bytes, written, null, span)
                    : PyString.FromOwnedUtf8(bytes, governor, span, output!, written);
                parts[index] = fragment;
                if (payload is not null) payloadOffset = checked(payloadOffset + range.Capacity);
            }
            context?.CheckExecution(span);
            var result = PyList.FromTransferredArray(parts, governor, span);
            // Shared output stays private and wholly reserved until complete;
            // failure refunds it without traversing partially constructed words.
            output?.Commit(payload is null ? listBytes : outputCharge);
            return result;
        }
        finally { scratch?.Dispose(); }
    }

    private static void CollectWhitespaceForward(ReadOnlySpan<byte> source, int maxSplit,
        scoped ref Span<(int Start, int End, int Capacity)> ranges, ref int count, ref long outputBytes, ref long scratchBytes,
        ref MemoryGovernor.TemporaryMemoryReservation? scratch, MemoryGovernor? governor,
        LythonSourceSpan? span, LythonRuntime.ExecutionContext? context, CaseMapping? casing)
    {
        // Each chunk decodes at most 64 complete scalars; a final scalar may
        // cross the byte boundary by at most three bytes. No shared work counter.
        var start = -1;
        var remaining = maxSplit < 0 ? int.MaxValue : maxSplit;
        var maximumCaseWidth = casing is null ? 0 : casing == CaseMapping.Lower ? 4 : Math.Max(4, MaxCaseExpansionUtf8Bytes);
        long extraCapacity = 0;
        for (var position = 0; position < source.Length;)
        {
            context?.CheckExecution(span);
            var chunkEnd = position + Math.Min(64, source.Length - position);
            do
            {
                int width;
                bool whitespace;
                if (source[position] < 0x80)
                {
                    whitespace = IsAsciiWhitespace(source[position]);
                    width = AsciiWhitespaceRunLength(source[position..chunkEnd], whitespace);
                }
                else
                {
                    Rune.DecodeFromUtf8(source[position..], out var rune, out width);
                    whitespace = IsPythonWhitespace(rune);
                    if (!whitespace && maximumCaseWidth != 0) extraCapacity += maximumCaseWidth - width;
                }
                if (whitespace)
                {
                    if (start >= 0)
                    {
                        AppendWhitespaceRange(ref ranges, ref count, start, position, ref outputBytes,
                            ref scratchBytes, ref scratch, governor, span, context,
                            maximumCaseWidth == 0 ? null : CheckCaseOutputCapacity(position - start + extraCapacity, span));
                        start = -1;
                        extraCapacity = 0;
                        remaining--;
                    }
                }
                else if (start < 0)
                {
                    start = position;
                    if (remaining == 0)
                    {
                        AppendWhitespaceRange(ref ranges, ref count, start, source.Length, ref outputBytes,
                            ref scratchBytes, ref scratch, governor, span, context);
                        return;
                    }
                }
                position += width;
            } while (position < chunkEnd);
        }
        if (start >= 0)
            AppendWhitespaceRange(ref ranges, ref count, start, source.Length, ref outputBytes,
                ref scratchBytes, ref scratch, governor, span, context,
                maximumCaseWidth == 0 ? null : CheckCaseOutputCapacity(source.Length - start + extraCapacity, span));
    }

    private static void CollectWhitespaceReverse(ReadOnlySpan<byte> source, int remaining,
        scoped ref Span<(int Start, int End, int Capacity)> ranges, ref int count, ref long outputBytes, ref long scratchBytes,
        ref MemoryGovernor.TemporaryMemoryReservation? scratch, MemoryGovernor? governor,
        LythonSourceSpan? span, LythonRuntime.ExecutionContext? context)
    {
        var end = -1;
        for (var position = source.Length; position > 0;)
        {
            context?.CheckExecution(span);
            var chunkStart = Math.Max(0, position - 64);
            do
            {
                int width;
                bool whitespace;
                if (source[position - 1] < 0x80)
                {
                    whitespace = IsAsciiWhitespace(source[position - 1]);
                    width = AsciiWhitespaceRunLength(source[chunkStart..position], whitespace, reverse: true);
                }
                else
                {
                    Rune.DecodeLastFromUtf8(source[..position], out var rune, out width);
                    whitespace = IsPythonWhitespace(rune);
                }
                if (whitespace)
                {
                    if (end >= 0)
                    {
                        AppendWhitespaceRange(ref ranges, ref count, position, end, ref outputBytes,
                            ref scratchBytes, ref scratch, governor, span, context);
                        end = -1;
                        remaining--;
                    }
                }
                else if (end < 0)
                {
                    end = position;
                    if (remaining == 0)
                    {
                        AppendWhitespaceRange(ref ranges, ref count, 0, end, ref outputBytes,
                            ref scratchBytes, ref scratch, governor, span, context);
                        return;
                    }
                }
                position -= width;
            } while (position > chunkStart);
        }
        if (end >= 0)
            AppendWhitespaceRange(ref ranges, ref count, 0, end, ref outputBytes,
                ref scratchBytes, ref scratch, governor, span, context);
    }

    private static void AppendWhitespaceRange(scoped ref Span<(int Start, int End, int Capacity)> ranges,
        ref int count, int start, int end, ref long outputBytes, ref long scratchBytes,
        ref MemoryGovernor.TemporaryMemoryReservation? scratch, MemoryGovernor? governor, LythonSourceSpan? span,
        LythonRuntime.ExecutionContext? context, int? casedCapacity = null)
    {
        if (count == ranges.Length)
        {
            var capacity = checked(ranges.Length * 2);
            var bytes = checked(32L + 16L * capacity);
            if (governor is not null)
            {
                scratch ??= governor.ReserveTemporary(0, span);
                scratch.Grow(bytes, span);
            }
            try
            {
                context?.CheckExecution(span);
                var replacement = new (int Start, int End, int Capacity)[capacity];
                ranges[..count].CopyTo(replacement);
                ranges = replacement;
            }
            catch { scratch?.Shrink(bytes); throw; }
            scratch?.Shrink(scratchBytes);
            scratchBytes = bytes;
        }
        var outputCapacity = casedCapacity ?? end - start;
        ranges[count++] = (start, end, outputCapacity);
        outputBytes = checked(outputBytes + PyString.EstimateApproximateBytes(outputCapacity));
    }
}
