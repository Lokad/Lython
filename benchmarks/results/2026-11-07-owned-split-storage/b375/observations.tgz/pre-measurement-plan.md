# Lokad.Lython 0.11.0

Updated2026-11-07. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent design simplification and substantial complete-script
performance. An isolated experiment/checkpoint does not finish it.

## Actual delivery

- Fully qualifiedc4729a9f R26: GREEN42324522730/all eight Windows/Ubuntu ordinary
  actual.NET11/10, original Stress and installed-package gates.01aedc3b R25,
  ec134e8c R23 and41c25958 R22 likewise fully qualified. Terminal receipts cached
  under their benchmark evidence; never query them or repeat unchanged checks.
- Committed/pushed14366ac7: B373 representative CPython refresh on exact01aedc3b
  source/frozen0933d540, all15jobs/312s/goldens/quiet/funding/joins/archive pass.
  Primary docs/BENCHMARKS.md measures this source, before R26. Compile44–72us is
  separate; warm text1.81–1.83x, CSV1.20–1.22x, JSON1.08x CPython. Fresh JSON/
  report/config vary. Includes mediated RAM I/O/checks/prior-result cleanup;
  excludes startup/staging/reset/final teardown. No subtraction of medians.
- R27 source/JIT and bounded text/report allocation gates are committed/pushed;
  source-only evidence does not repeat R26 qualification. R28's two-file owned
  split-payload/hash-cache prototype is active and unqualified; focused checks
  are starting. No timing/allocation or footprint claim yet.
- Open: whole-script text gap/possible R20/R26 debt, mixed CSV coarse CPU,
  startup, genuinely suspended-I/O latency, heap/RSS/embedding tails and affected
  final adapter capabilities. R26 allocation flat; adverse timing is not parity.

Current guides belong in docs/. History/raw evidence stays under benchmarks/results/
and benchmarks/EXPERIMENTS.md; detailed plans/source gates also survive under
.git/agent-notes/review-20261031/. Do not repeat qualification to refresh its date.

## Completed milestones / evidence decisions

Preserve shared compiler-fact correction, direct UTF8 formatting/storage, final
call/local slots, executable imports/lambdas, genuine suspension, fixed builtin
metadata and reusable sync/async startup workers. Worker release on actual I/O
already exists. Keep K01/F02–F05/Q01/Q02/R02–R14 and delivered ownership/protection
simplifications; do not propose them as missing.

| Milestone | Established outcome | Remaining limits / evidence |
| --- | --- | --- |
| Native helper returns | Allocation−19.92/−19.31%; delivered | Elapsed diagnostic. Do not transfer percentages to HEAD. |
| UTF8 formatting | Allocation−8.67%; controlledB102 elapsed/CPU−5–8% supports retention | Original adverse15.125ms unexplained/preserved; completed question, no unchanged retiming scheduled without new evidence. |
| R20 record layout | Canonical shared keys/independent values, no coupled entries/sorted JSON hint/set values. JSON allocation~−15%, report~−9.4%; warm JSON−10.9–12.5%, report−5.4–8.8% | CSV modest/mixed CPU. Text confirmation−1.21% to+5.53%: possible regression accepted debt, not parity. Fully delivered; record-layout evidence retains every failure/adverse condition. |
| R21 frame resume | Delete per-instruction pending-error/return polling; preserve guards/spans/cleanup | Allocation flat, modest warm text; unchanged compile also moves. Fully delivered; no general CPU gain or closure of R20 debt. |
| R22 builtin setup | Fixed functions/signatures prepared once; per-run mutable type/exception/namespace isolation. Factory−2,688B | Whole scripts mostly<0.2%allocation, config~1.17%. Config warm−1.13–2.44%, fresh−1.43% to+0.13%. Fully delivered; text controls variable. |
| U04 capture ownership | Caller spans/retained ranges replace carriers/arrays. Direct cursor allocation−20.34%; complete extraction warm−3.62–5.17%/fresh−4.58–6.40% | Fully delivered; distinct from R23, no backend CPU attribution. |
| R23 validated programs | Eliminate duplicate frontend/runtime provider compilation; native UTF8 request keys, per-run wrappers/names/purge/current tokens | B36989s extraction warm−8.34–9.64%, fresh−6.47–6.53%. Probe compiled funding39,397→105,481B until script disposal: explicit retention/earlier-denial tradeoff. Fully delivered; moving controls limit CPU attribution. |
| R25 CSV values | Transfer final funded arrays for exact header identities; no second values allocation/per-field publication on that path | Allocation−7.31/−6.55%sync/async. B372109s native warm−7.72–8.04%, ordinary warm−4.13–4.78%; text spread2.52%, coarse CPU mixed. Fully delivered. |

R25 revisits earlier6–8% bulk CSV rejection through a different completed-array
transfer model enabled by shared keys, not automatic promotion of the old design.
Header revalidation, original headroom, retained Clear capacity and corrected
test assumptions remain documented. R26 fixes demonstrated InvalidCastException
after admission changes a later receiver, deletes full native formatted proof/
evaluation and keeps real async cleanup funded. Primitive native returns remain.
Its retained possible ~3% async/text debt needs a decision at the next coherent
execution delivery. Both milestones' original failed/adverse conditions survive.

## Priority1 — R28 owned UTF8 split-result storage

R27's bounded current-source allocation profile supports final text storage:
sampled PyString31.74%,Byte[]26.76%,boxed BigInteger23.71%,PyList9.01%. These
are allocation-tick diagnostics including request reset/I/O/checks/cleanup, not
exact type totals or CPU dominance. Both1024-job text/report captures pass all
goldens, zero lost events, Closed/joins/private fixture cleanup. No new runtime
instrumentation, forced collection, rundown or heap inventory.

Hypothesis: replace common per-word UTF8 arrays with one immutable split-result
payload while retaining56B PyString objects. Unlike the earlier slower shared
windows (+8B/string), delete the separate hash-cache flag and use zero as uncached
hash, making room for offset metadata. Zero hashes can be recomputed correctly.
Use one existing execution owner for backing and each word's metadata; commit
capacity before publishing windows. No new owner/refcount/ledger/pool/configuration.

Do not share arbitrary input slices: decoded file windows have explicit refunds,
so identical governor identity alone does not prove retained backing. First
migration constructs only a new split-result payload, committed to the execution
owner independently of word metadata. Refunding a private word cannot refund
backing still used by another word. General slicing/private input ownership stays
outside this bounded change; no wider ownership audit or tracing.

Expected disappearance: separate hash-cache flag/publication and common per-word
byte-array construction/transfer; canonical string operations must all honor the
window's byte range. Keep normal single-word/unrepresentable combined-array paths
where representation requires them, not an arbitrary policy threshold. Preserve
capacity/metadata overlap, first refusal before allocation and funded aliases.

Acceptance: Python Unicode casing/expansion/context and whitespace/maxsplit,
indexing/slicing/repr/hash/equality, native UTF8/regex offsets, independent words,
source lifetime, retained results, cancellation/refusal and final budget reuse.
Prove every byte access/ownership snapshot before prototype. Then focused Release
both targets, precise existing eight-case sync/async allocation and one short
controlled text/report comparison with CSV/JSON controls. Measure actual object
footprint; no predicted speedup or automatic promotion. If ownership needs a new
ledger or old8B footprint returns, stop this bounded design and state the missing
proof/alternative. Decide R26/remaining regression debt at coherent delivery.

## R27 completed source gate / broader roadmap

Current mixed-prefix21% leaf share includes necessary inlined work. Calls~2% and
integer addition~3% do not establish dominant removable costs. Windows Tier1
inspection10,091B/3,000 checked text jobs is not Linux perf attribution. Reused
D36 allocation collector:1024 checked text/report jobs each,15,873/26,720ticks,
zero lost; all goldens/Closed/joins/fixtures pass. Includes request reset/I/O/
validation/cleanup. Sampling is neither exact per-type allocation nor CPU cost.
Report54.8%Byte[] includes host/reset/output capacity; do not call it all avoidable.

| Area | Existing evidence / hypothesis | Selected work and displaced implementation | Acceptance / decision |
| --- | --- | --- | --- |
| Complete call/frame construction | R24 ordinary binding/calls~2%; native proofs/evaluation~16% report before R26, only~3.5% text | R26 closes duplicated formatted-body execution. Assess remaining whole-call ownership/argument/frame transitions before any replacement. Do not revive slower B61/B69 arenas/control. | Same defaults/keywords/receivers/locals/closures, evaluation order, error frames, actual suspension, cancellation and funded aliases. Proceed only for demonstrated remaining work. |
| Operand transport | Prefix~21% text includes inlined useful work; pure-dispatch fraction unproven | Inspect current fixed-slot instructions and read/publication/retirement together. A coherent representation may eliminate redundant transport and its old paths; no narrow fusion/hint series or new dispatcher alongside old. | Original read/error/effect order, dynamic promotion without replay, source spans, local cells, temporary disposal and admission. Stop before a runtime prototype if safe producer/use ownership needs a wider compiler rewrite unsupported by evidence. |
| Per-record construction | R20/R25 eliminate shared-key duplication and final CSV values copy | Delivered. Remaining report JSON~10% samples includes needed parsing; select another construction change only with concrete intermediate storage to delete. | Mutation/order/protocols, short/rest records, retained results and replacement peaks; no parser-specific second dictionary. |
| Remaining text conversion/storage | Text split/casing/lookup costs visible; casing and split final UTF8 output already direct | Inspect current final representation, not revive slower shared windows (+8B/string) or per-character CLR conversion already removed. No speculative pooling/cache layer. | Python Unicode expansion/context, identity/captured operands, all public formats, cancellation and capacity admission. |
| Repeated frontend analysis | Compile44–72us vs CPython35–60us; lexical facts already shared | Consolidate only a demonstrated duplicate walk/retained representation; use comprehension/helper compile-to-result controls. Main text warm gap remains independent. | Existing shared-fact correction, scoping/class cells/annotations and Python diagnostics; eliminate displaced collector/walk, not another cache. |

Select R28's distinct final-storage design first. Preserve slower B61/B69 arena/
call-control lessons and R24 unknowns/export/prelaunch/observer-delay deviation.
No broad dispatcher/scalar rewrite or native-wrapper prototype follows merely
from aggregate prefix samples. Evidence2026-11-07-execution-source-gate retains
all raw/source/failed staging conditions; no duplicate qualification scheduled.

## Independent regex track

Core Python semantics/native UTF8/byte ranges/scalar original windows, captures/
replacements/errors, ownership and current cancellation keep advancing without a
producer release. U04/R23 delivered. Normal adapter pin0.4/nonpackable; core has
zero backend dependency/type edges. Dev46 immutable source6957b35a compatibility
passed85internal/482public per actual target, same U04 bridge as44; evidence
2026-11-06-regex-dev46-compatibility. No production promotion/requalification replay.

Only affected final adapter qualification waits for missing producer capabilities:
DetailedData lacks independent Prepare working owner (conservative preflight);
native names cannot be enumerated (adapter-local conversion); native cursors mix
creation/per-operation tokens (qualified CTS bridge already provides current-token
semantics; removal is simplification, not a core blocker). Normal0.4 reversed
windows fail explicitly. Development producers/adapter-local bridges support
testing; qualify final released immutable package/managed safety separately.
No sibling edits, silent dialect fallback or work/time quotas.

## Working contract

Timeouts/unstable controls/inconclusive results establish uncertainty, not failed
design. Bounded confirmation/refinement/measurement correction is allowed when
justified; preserve original failed conditions/adverse data. Percentages inform
decisions, not automatic vetoes or permanent closures. Separate architecture,
allocation, elapsed and demonstrated CPU. Temporary debt needs a completion
milestone and decision on remaining regression, not indefinite acceptance.

Follow AGENTS.md: fully managed/memory-safe; no unsafe/Unsafe/pointers/PInvoke/
native probing. Preserve managed stack/recursion, host mediation/contained paths,
cycles, host cancellation, shared allowance/capacity/replacement/escaping aliases
and awaited cleanup. First admission refusal fails the command; never retry.
No fuel/quotas/hidden caps/default allowance/tracing/weak reclamation/forced GC.
Initial streaming uses bounded host executions; XML depth constraint remains.

Focused Release iteration, no overlapping local builds/tests. Nonincremental build
after timestamp-preserving restore. Batch actual11/10/Windows/Ubuntu/original
Stress/installed consumers at coherent boundaries; no repeated terminal CI probes.
Quiet VM lokad@20.166.121.73,key~/.ssh/id_lython-bench.pem: exclusive owned lease,
Ready hashes, controls/quiet/goldens/funding/joins and verified persistent archives.
Observe only after owner+stop+margin; record conservative UTC bound after launch.
Disk near full: retire only exact redundant expanded files after independent
committed backup and all user/dependency checks. Keep raw evidence. Continue
after individual experiments/checkpoints; publication and tagging stay postponed.
