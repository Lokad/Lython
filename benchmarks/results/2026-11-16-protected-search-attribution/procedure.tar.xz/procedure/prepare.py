from pathlib import Path
import ast,hashlib,io,json,shutil,subprocess,tarfile

r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');old=r.parent/'shared-kernel-r439/profile';previous=r.parent/'cased-word-stream-r440/refined';q=r/'profile';q.mkdir()
before=json.loads((previous/'quiet/config.json').read_text(encoding='utf-8'));sha=lambda b:hashlib.sha256(b).hexdigest()
root='/home/lokad/lython-bench-checks/protected-search-costs-b844-20261116';unit='lython-b844-protected-search-costs-20261116'
files=before['identity']['imageFiles']['reference']
identity=dict(sourceRevision='Qualified312f5911/measured0443b5cf,unchanged production throughd6a79009',purpose='R441 complete protected-file-search CPU attribution. One qualified source,not a speedup comparison. Select a complete displaced stage or record unresolved dominance.',coreSHA256={'reference':files['Lokad.Lython.dll'],'candidate':files['Lokad.Lython.dll']},imageFiles={'reference':files,'candidate':files},referenceQualification='Cached GREEN43828954661;607inputs/16summaries. No repeated qualification.',publicationHeld=True,diagnosticOnly=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n');shutil.copyfile(previous/'quiet/representative.json',q/'catalog.json')
s=(old/'ops-profile.py').read_text(encoding='utf-8')
s=s.replace('candidate = pathlib.Path("/home/lokad/lython-bench-checks/shared-kernel-attribution-b839-20261116")','candidate = pathlib.Path(__file__).resolve().parent')
s=s.replace("env[\"TMPDIR\"]='/home/lokad/lython-bench-checks/shared-kernel-attribution-b839-20261116/guest-fixtures'", "env[\"TMPDIR\"]=str(candidate/'guest-fixtures')")
s=s.replace("[('reference','scripts.text-summary-helpers.nonlocal-counter.large','warm'),('candidate','scripts.text-summary-helpers.nonlocal-counter.large','warm')]", "[('reference','scripts.file-search.large.protected','warm')]")
s=s.replace('Same complete captured script per source','Complete protected early-exit search')
assert 'shared-kernel-attribution' not in s and 'text-summary-helpers' not in s
ast.parse(s);(q/'ops-profile.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'collect.py').read_text(encoding='utf-8')
s=s.replace("root=Path('/home/lokad/lython-bench-checks/shared-kernel-attribution-b839-20261116')",'root=Path(__file__).resolve().parent')
s=s.replace("['reference','candidate']","['reference']")
s=s.replace('R439/B839 matched source attribution,91ca4a41 versus0443b5cf; elapsed not comparable with unprofiled B838','R441/B844 protected-search attribution,qualified0443b5cf; no controlled CPU/elapsed comparison')
assert 'shared-kernel-attribution' not in s and 'B839' not in s
ast.parse(s);(q/'collect.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'run.sh').read_text(encoding='utf-8');s=s.replace('root=/home/lokad/lython-bench-checks/shared-kernel-attribution-b839-20261116','root='+root)
assert 'root='+root in s;(q/'run.sh').write_text(s,encoding='utf-8',newline='\n')
s=(old/'retrieve.py').read_text(encoding='utf-8').replace('Paired CPU profiles','Protected-search CPU profile');ast.parse(s);(q/'retrieve.py').write_text(s,encoding='utf-8',newline='\n')
head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip();proofs=[]
for archive,member,paths in [
 ('benchmarks/results/2026-11-16-cased-word-stream/refined/procedure-and-image.tar.xz','frozen/candidate/Lokad.Lython.dll',['cased-word-ranges-b843-20261116/candidate/Lokad.Lython.dll']),
 ('benchmarks/results/2026-11-16-cased-word-stream/refined/observations.tgz',None,['cased-word-ranges-b843-20261116/observations.tgz']),
 ('benchmarks/results/2026-11-16-cased-word-stream/refined/observations.tgz','confirmation/confirmation.json',['cased-word-ranges-b843-20261116/confirmation/confirmation.json'])]:
 raw=(repo/archive).read_bytes();assert raw==subprocess.check_output(['git','-C',str(repo),'show',head+':'+archive])
 if member:
  with tarfile.open(fileobj=io.BytesIO(raw))as t:content=t.extractfile(member).read()
 else:content=raw
 proofs.append(dict(bytes=len(content),sha256=sha(content),links=len(paths),paths=paths,custody=dict(commit=head,archive=archive,archiveSHA256=sha(raw),member=member)))
payload={n:(q/n).read_bytes()for n in ['identity.json','collect.py','ops-profile.py','run.sh']}
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n,b in payload.items():m=tarfile.TarInfo(n);m.size=len(b);t.addfile(m,io.BytesIO(b))
c=dict(root=root,unit=unit,source=before['root'],sourceFiles=files,sourceCatalogSHA256=before['catalogSHA256'],catalogSHA256=before['catalogSHA256'],identity=identity,retireGroups=proofs,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha((q/'payload.tgz').read_bytes()),unpackedBytes=sum(map(len,payload.values())))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path',a);s=s[:a]+'c='+repr(c)+s[b:]
s=s.replace("os.link(source/role/n,p)","os.link(source/'reference'/n,p)")
s=s.replace('lython-b839-fixtures','lython-b844-fixtures');ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(r.parent/'shared-kernel-r439/launch-attribution.py').read_text(encoding='utf-8').replace('Two-source CPU attribution','One-source protected-search CPU attribution').replace('seconds=90','seconds=60').replace('before90seconds','before60seconds')
ast.parse(s);(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
# Check concrete roots,units,schemas and archived payload before remote mutation.
for n in ['collect.py','ops-profile.py']:assert '/home/lokad/lython-bench-checks/'not in(q/n).read_text(encoding='utf-8'),n
assert 'root='+root in(q/'run.sh').read_text(encoding='utf-8')
assert "config=json.loads((r/'config.json')"in(q/'retrieve.py').read_text(encoding='utf-8')
assert "['imageFiles'][name]"in(q/'ops-profile.py').read_text(encoding='utf-8')
assert 'source/role'not in(q/'remote-launch.py').read_text(encoding='utf-8')
with tarfile.open(q/'payload.tgz')as t:
 for n,b in payload.items():assert t.extractfile(n).read()==b
print(json.dumps(dict(core=files['Lokad.Lython.dll'],profiles=1,catalogUnchanged=True,fullImageHashes=len(files),allConcretePathsValidated=True,retireBytes=sum(p['bytes']for p in proofs),unpackedBytes=c['unpackedBytes'])))
