from pathlib import Path
import bisect,collections,gzip,json,re
r=Path(__file__).parent;rows=[]
for label in ['reference','execution-thread','protocol-thread']:
 f=r/'profile/retrieved/profiles/reference';record=json.loads((f/'record.json').read_text(encoding='utf-8'));ranges=[];malformed=[];targetTids=record['activeCpuTids']if label=='reference'else[row['tid']for row in record['threadCpuSeconds']if row['tid']in record['activeCpuTids']and(row['name'].startswith('Lython')if label=='execution-thread'else not row['name'].startswith('Lython'))]
 for line in gzip.open(f/'perf.map.gz','rt',encoding='utf-8').read().splitlines(keepends=True):
  parts=line.rstrip().split(' ',2)
  if len(parts)!=3 or not line.endswith('\n'):malformed.append(line);continue
  start,size,name=parts;ranges.append((int(start,16),int(size,16),name))
 ranges=sorted(set(ranges));starts=[x[0]for x in ranges];prefix=[]
 for start,size,name in ranges:prefix.append(max(start+size,prefix[-1]if prefix else 0))
 def symbol(address,fallback):
  index=bisect.bisect_right(starts,address)-1;matches=set()
  while index>=0 and prefix[index]>address:
   start,size,name=ranges[index]
   if start<=address<start+size:matches.add(name)
   index-=1
  return next(iter(matches))if len(matches)==1 else'[ambiguous] '+repr(sorted(matches))if matches else fallback
 samples=[];current=None;allThreads=collections.Counter()
 for line in gzip.open(f/'all-thread-stacks.txt.gz','rt',encoding='utf-8').read().splitlines():
  header=re.match(r'^.*?\s(\d+)\s+\d+\.\d+:\s+\d+\s+cpu-clock:',line)
  if header:
   allThreads[header[1]]+=1;current=[]if header[1]in targetTids else None
   if current is not None:samples.append(current)
   continue
  frame=re.match(r'^\s+([0-9a-f]+)\s+(.*)$',line)
  if current is not None and frame:current.append(symbol(int(frame[1],16),frame[2]))
 leaves=collections.Counter(s[0]for s in samples if s);nearest=collections.Counter(next((n for n in s if'Lokad.Lython.'in n),'[no Lython frame]')for s in samples if s)
 groups={'function entry/binding/retirement':['StartNativeCall','StartInline','TryStartBoundInvocation','EnterFunctionCall','LeaveFunctionCall','BindFunctionArgumentsInto','ReturnBoundArguments'],'closed instruction execution':['NativeExecution','ExecutableKernel'],'file iteration and text':['TextFileHandle','PyFileObject','Readline','ReadLine','ReadGoverned','InvokeStringAffix','StartsWith','FileFixture'],'dictionary accumulation':['DictionaryLoop','TryAccumulate','NativeTextIndex'],'cooperative checks':['CheckExecution','CheckCancellation']}
 inclusive={name:sum(any(any(part in method for part in parts)for method in stack)for stack in samples)for name,parts in groups.items()}
 rows.append(dict(label=label,case=record['workload'],activeCpuTids=targetTids,allThreadSamples=allThreads,threadCpuSeconds=record['threadCpuSeconds'],sampleCount=len(samples),unmappedLeafSamples=sum(v for k,v in leaves.items()if'[unknown]'in k),ambiguousLeafSamples=sum(v for k,v in leaves.items()if k.startswith('[ambiguous]')),inclusiveOverlappingGroups=inclusive,nearestLythonFrames=nearest.most_common(),allLeaves=leaves.most_common(),malformedMapLines=malformed,invocations=record['response']['completedInvocations'],guestClockSeconds=record['response']['elapsedTicks']/record['response']['clockFrequency']))
(r/'attribution.json').write_text(json.dumps(dict(kind='Complete protected-search sampled CPU; inclusive groups overlap useful/inlined work and are not removable shares or a controlled elapsed/CPU speedup comparison. Different invocation counts must remain explicit.',rows=rows),indent=2)+'\n',encoding='utf-8',newline='\n')
for x in rows:
 print(x['label'],x['sampleCount'],'samples',x['unmappedLeafSamples'],'unknown',x['inclusiveOverlappingGroups']);print('nearest',x['nearestLythonFrames'][:12]);print('leaves',x['allLeaves'][:12])
