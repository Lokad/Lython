from pathlib import Path
import json
r=Path(__file__).resolve().parent
for row in json.loads((r/'attribution.json').read_text(encoding='utf-8'))['rows']:
 print(row['label'],row['sampleCount'],'samples',row['unmappedLeafSamples'],'unknown',row['inclusiveOverlappingGroups'])
 print('nearest',[(name.split('::')[-1].split('(')[0],count)for name,count in row['nearestLythonFrames'][:15]])
 print('leaves',[(name.split('::')[-1].split('(')[0],count)for name,count in row['allLeaves'][:15]])
