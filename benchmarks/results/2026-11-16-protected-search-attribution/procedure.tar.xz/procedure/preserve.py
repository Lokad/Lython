from pathlib import Path
import hashlib,json,shutil,tarfile

r=Path(__file__).resolve().parent;q=r/'profile';repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-16-protected-search-attribution';out.mkdir()
receipt=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'))
assert receipt['complete']and receipt['allWorkersJoined']and receipt['ramTraceArchivedAndVerifiedBeforeUnmount']
assert hashlib.sha256((q/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
rows=json.loads((r/'attribution.json').read_text(encoding='utf-8'))['rows'];assert [x['sampleCount']for x in rows]==[947,749,198]
for n in ['identity.json','observations.tgz','archive-receipt.json','terminal-status.json']:shutil.copyfile(q/n,out/n)
shutil.copyfile(r/'attribution.json',out/'attribution.json')
record=json.loads((q/'retrieved/profiles/reference/record.json').read_text(encoding='utf-8'))
decision=dict(assessmentComplete=True,sourceUnchanged=True,wholeActiveSamples=947,executionThreadSamples=749,executionThreadUnknownLeaves=140,protocolResetThreadSamples=198,protocolResetUnknownLeaves=179,entryBindingRetirementInclusiveSamples=251,closedExecutionInclusiveSamples=149,groupsOverlapAndAreNotRemovableShares=True,speedupClaim=False,nextDesign='Bounded complete-call/frame design assessment. Compare direct consumed-operand reuse and managed executable-block compilation against prior call-arena/control/shared-kernel failures. Reject replay, unsafe storage, abandoned users, extra lifetime carriers or unbounded per-script compilation. Select an actual displaced stage only if its whole-script compile-to-result tradeoff is credible; otherwise record unresolved feasibility. No new engine or switch approved merely from inclusive samples.',physicalStackPolicyUnchanged=True,publicationHeld=True)
(out/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'procedure.tar.xz','w:xz')as t:
 for p in r.glob('*.py'):t.add(p,arcname='procedure/'+p.name)
 for p in q.iterdir():
  if p.is_file()and p.name not in ['observations.tgz','payload.tgz']:t.add(p,arcname='profile/'+p.name)
 for p in r.glob('*.log'):t.add(p,arcname=p.name)
(out/'README.md').write_text(f'''# Protected file-search CPU attribution

R441/B844,2026-11-16UTC,qualified312f5911/frozen0443b5cf. One bounded199Hz
cpu-clock/frame-pointer capture after8guest-seconds warmup. Same seven-case
catalog as B842/B843; only the protected early-exit search executes. All images,
stdout/file goldens,quiet gates and joined cleanup pass. This is attribution,
not a controlled speedup comparison. PerfMap is an explicit diagnostic override.

| Sample boundary | Active samples | Unknown leaves |
| --- | ---: | ---: |
| All selected active worker threads | 947 | 319 |
| Lython execution thread | 749 | 140 |
| Protocol/reset thread | 198 | 179 |

Fixture Reset is the nearest managed frame for146protocol samples and ReadOutputs
for35. They belong to the wider batch,not the guest execution timer. Execution-
thread host path resolution/opening and kernel work are still real mediated I/O.
Do not attribute the full CPU sample set or the CPython elapsed gap to dispatch.

On the execution thread,entry/binding/retirement has251inclusive samples; closed
instruction execution has149. These groups overlap useful guest work and each
other. Nearest frames include prefix102,StartNativeCall50,native RunCore44,
ForNext44,arithmetic39,native-call selection38 and Reserve38. StartNativeCall
has49exclusive leaves. Inlining obscures finer attribution; zero explicit
checkpoint leaves does not mean checking is free. Unknown/kernel leaves remain.
No dominant removable call/frame stage is established by these counts.

The capture completes{record['response']['completedInvocations']}invocations/
{record['response']['elapsedTicks']/record['response']['clockFrequency']:.3f}guest seconds.
One current source and fixed order cannot establish causality or a speedup. Normal
tiering/workstation GC on quiet F4as_v7/.NET11RC3. Full worker CPU also includes
reset/protocol/validation; the existing unprofiled warm comparison includes Run,
mediated RAM I/O,output/file goldens and prior-result cleanup,but excludes reset,
compilation/startup and final cache teardown. CPython uses native buffered I/O
without equivalent host containment. All raw stacks/maps/thread CPU are retained.

Close this bounded attribution with unresolved dominance. Preserve the measured
native engine; do not resurrect a call carrier or remove managed stack checks
from these samples. Next is a bounded complete-call/frame design assessment:
identify a genuinely eliminated stage and compile-to-result tradeoff before a
prototype. Consumed-operand reuse must address the prior slower tail-loan/arena;
managed block compilation must justify its one-shot preparation cost and complete
replacement scope. Neither is selected for implementation by this profile alone.
No broad sampling campaign or unchanged retiming. Publication remains held and
regex development independent; the broader performance objective remains open.

All users joined; every RAM byte archived and SHA-verified under the lease before
unmount. Terminal cached. Only exact committed B843 working replicas were retired
after fresh UID/path/hash/inode/all-alias proof; canonical evidence,current0443
images and254/252MiBfloors preserved. No runtime or qualification change.

[Attribution](attribution.json),[raw/maps](observations.tgz),
[decision](decision.json),[procedure](procedure.tar.xz).
''',encoding='utf-8',newline='\n')
p=repo/'benchmarks/EXPERIMENTS.md';s=p.read_text(encoding='utf-8');a=s.index('[R440 bulk-snapshot refinement]');s=s[:a]+'''[R441/B844 protected-search attribution](results/2026-11-16-protected-search-attribution/README.md)
uses qualified0443/current fixed catalog.947active samples separate749execution/
140unknown from198protocol-reset/179unknown. Reset146nearest samples is outside
the guest timer.251inclusive call-entry/binding overlaps149closed execution and
useful work; no dominant removable stage or speedup established. All gates/joins/
RAM archive verification pass. Close bounded attribution; assess complete calls/
frames against prior slower carriers and one-shot preparation costs before another
prototype. No runtime/full qualification change; broader objective remains open.

'''+s[a:];p.write_text(s,encoding='utf-8',newline='\n')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8').replace('Updated2026-11-16UTC(R440withdrawal/R441selected).','Updated2026-11-16UTC(R440withdrawal/R441closed/R442design).')
s=s.replace('Independent four ownership cases retained;28internal eachactual11/10 pass on qualified production,original range-growth fixture preserved.','Independent four ownership cases committed/pushedd6a79009;28internal eachactual11/10 pass on qualified production,original range-growth fixture preserved.')
needle='| Independent adapter prototype |';a=s.index(needle);s=s[:a]+'''| Completed bounded attribution | [R441/B844](benchmarks/results/2026-11-16-protected-search-attribution/README.md),qualified0443.947active samples:749execution/140unknown,198protocol-reset/179unknown. Entry/binding251inclusive overlaps useful closed execution149; no dominant removable stage established. All gates/joins/archived RAM proof pass. No runtime or speedup/full-qualification change. |
'''+s[a:]
a=s.index('### 1. R441:');b=s.index('### 2. Remaining substantial roadmap',a)
s=s[:a]+'''### 1. R442: complete call/frame design assessment before another prototype

**Completed checkpoint.** R440both shapes withdrawn; sources,memory savings,
adverse CPU,controls and original staging refusal are immutable. Four independent
ownership cases committed/pushedd6a79009;28focused eachactual11/10 pass. R441's
one protected-search capture is complete:749execution-thread samples/140unknown,
198protocol-reset/179unknown. Call-entry/binding251inclusive overlaps149closed
execution/useful work; no dominant removable stage established. Fixture reset is
outside the guest timer. No repeated sampling/full qualification for unchanged
production. Import execution already consolidated(840621405); stale later item
removed. Current external checkpoint remains R437,no new ratio inferred.

**Bounded next design.** Assess complete call/frame construction from current
StartNativeCall/StartInline,ordinary binder and operand storage,not another narrow
instruction fusion. Compare two concrete possibilities: reuse consumed caller
operands as actual callee slots,or compile an executable block into managed code
so dispatch disappears. Neither is approved for implementation merely from sample
totals. Reuse must explain what differs from the slower R411tail-loan/arena and
R403controller; block compilation must account for generated-script compile-once/
run-once latency and displace a complete route,not add a dormant backend/cache.
Do not spend a campaign proving an unchanged rejected carrier again.

**Acceptance/stop.** One source/previous-evidence design pass,then select a coherent
prototype with actual work/storage eliminated,affected search/text/report scripts,
semantic gate and short controlled source pair,or explicitly record unresolved
feasibility and move on. No JIT/dependency/switch,unsafe storage or new lifetime
carrier without a justified complete replacement. Preserve Python identities,
defaults/closures,exact faults and PC,normal protocols/genuine I/O,no replay,
terminal refusal,current token,pending funding,managed stack and cleanup. Retain
the qualified native engine until its replacement meets a named completion gate.
Temporary regression needs an explicit remaining-debt decision. Full platform/
stress/installed consumers at retained delivery. Performance objective remains
open; publication held and regex track independent.

'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(dict(complete=True,profiles=1,runtimeUnchanged=True,allUsersJoined=True,dominantRemovableStageUnresolved=True,publicationHeld=True)))
