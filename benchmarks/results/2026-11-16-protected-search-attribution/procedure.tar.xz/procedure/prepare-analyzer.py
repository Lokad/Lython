from pathlib import Path
import ast
r=Path(__file__).resolve().parent
s=(r.parent/'shared-kernel-r439/analyze-attribution.py').read_text(encoding='utf-8')
s=s.replace("for label in ['reference','candidate']:","for label in ['reference']:")
s=s.replace("for label in ['reference']:","for label in ['reference','execution-thread','protocol-thread']:")
s=s.replace("f=r/'profile/retrieved/profiles'/label", "f=r/'profile/retrieved/profiles/reference'")
s=s.replace("ranges=[];malformed=[]", "ranges=[];malformed=[];targetTids=record['activeCpuTids']if label=='reference'else[row['tid']for row in record['threadCpuSeconds']if row['tid']in record['activeCpuTids']and(row['name'].startswith('Lython')if label=='execution-thread'else not row['name'].startswith('Lython'))]")
s=s.replace("header[1]in record['activeCpuTids']", "header[1]in targetTids ")
s=s.replace("activeCpuTids=record['activeCpuTids']", "activeCpuTids=targetTids")
s=s.replace('Matched complete captured-script sampled CPU','Complete protected-search sampled CPU')
s=s.replace("'iteration and cased preparation':['Cased','CaseMapped','Whitespace','PyFileObject','StringWordCursor']","'file iteration and text':['TextFileHandle','PyFileObject','Readline','ReadLine','ReadGoverned','InvokeStringAffix','StartsWith','FileFixture']")
ast.parse(s);(r/'analyze.py').write_text(s,encoding='utf-8',newline='\n')
print('One-source analyzer prepared; no fresh timing inference.')
