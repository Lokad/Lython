from pathlib import Path
from hashlib import sha256
import json,shutil,subprocess
root=Path(__file__).resolve().parent
notes=root.parent
repo=notes.parents[2]
donor=notes/'wsl-current-cpython-json-paired-20261127'
wide=notes/'post-ready-insertion-cpython-20261127/comparison/quiet'
iterable=notes/'iterable-starmap-cpython-20261127/comparison/quiet'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(p,value):p.write_text(json.dumps(value,indent=2)+'\n',encoding='utf-8',newline='\n')
def wsl(p):return '/mnt/'+p.drive[0].lower()+'/'+p.relative_to(p.anchor).as_posix()
identity=read(donor/'identity.json')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert not subprocess.check_output(['git','diff','--name-only',identity['sourceRevision'],head,'--','src'],cwd=repo)
assert not subprocess.check_output(['git','status','--porcelain','--','src'],cwd=repo)
for base in (wide,iterable):
 assert digest(base/'representative.json')==read(base/'identity.json')['catalogs']['representative.json']['sha256']
baseline=read(wide/'representative.json')
cases={c['id']:c for c in baseline['cases']}
general={c['id']:c for c in read(iterable/'representative.json')['cases']}
map_id='diagnostic.shipment-file-fed-map'
assert cases[map_id]==general[map_id]
wide_id='diagnostic.shipment-starmap-wide-lists'
iterable_id='diagnostic.shipment-starmap-iterable-rows'
baseline['cases']=[cases[wide_id],cases[map_id],general[iterable_id]]
write(root/'representative.json',baseline)
write(root/'jobs.json',[[wide_id,'paired'],[map_id,'warm-async'],[iterable_id,'paired']])
shutil.copytree(donor/'candidate',root/'candidate')
assert {p.name:digest(p) for p in (root/'candidate').iterdir()}==identity['imageFiles']['candidate']
runtime=notes/'bench-cpython-3.13.16-runtime'
python=read(runtime/'identity.json')
assert {p.relative_to(runtime/'runtime').as_posix():digest(p) for p in (runtime/'runtime').rglob('*') if p.is_file()}==python['files']
assert identity['expectedCPythonSHA256']==python['source']['sha256']
for name in ('cpython-worker.py','collect.py','run.sh'):
 shutil.copyfile(donor/name,root/name)
assert digest(root/'cpython-worker.py')==identity['cpythonWorkerSHA256']
identity.update(frozenImage=wsl(root/'candidate'),inspectedHead=head,
    purpose='Current wide and generic iterable shipment scripts against CPython with paired APIs and a file-fed map control.',
    catalogs={name:{'sha256':digest(root/name)} for name in ('representative.json','jobs.json')})
write(root/'identity.json',identity)
p=root/'collect.py'
s=p.read_text(encoding='utf-8')
s=s.replace('assert len(jobs) == 1','assert len(jobs) == 3').replace('lanes = ["warm", "warm-async"]','lanes = ["warm", "warm-async"] if lane == "paired" else [lane]')
s=s.replace("prefix='lython-b1880-paired-guest-'","prefix='lython-b1881-shipment-guest-'")
compile(s,str(p),'exec')
p.write_text(s,encoding='utf-8',newline='\n')
p=root/'run.sh'
s=p.read_text(encoding='utf-8')
p.write_text(s,encoding='utf-8',newline='\n')
assert b'\r' not in p.read_bytes()
