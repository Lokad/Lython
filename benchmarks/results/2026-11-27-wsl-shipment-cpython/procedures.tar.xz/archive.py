from pathlib import Path
from statistics import median, quantiles
import hashlib,json,tarfile

quiet=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text(encoding="utf-8"))
assert (quiet/"exit-code.txt").read_text().strip()=="0"
receipt=read(quiet/"archive-receipt.json")
assert receipt["quietBeforeAndAfter"] is None
proof=read(quiet/"verification.json")
assert proof["state"]=="Completed" and proof["caseCount"]==3
archive=quiet/"observations.tar.xz"
assert hashlib.sha256(archive.read_bytes()).hexdigest() == receipt["archiveSHA256"]
image=read(quiet/"identity.json")
case_by_id={r["id"]:r for r in read(quiet/"representative.json")["cases"]}
with tarfile.open(archive) as bundle:
    raw=json.load(bundle.extractfile("confirmation/confirmation.json"))
    identity=json.load(bundle.extractfile("identity.json"))
    jobs=json.load(bundle.extractfile("jobs.json"))
    machine=json.load(bundle.extractfile("confirmation/machine-local.json"))
    assert machine["affinity"]==[27] and machine["fixtureFilesystem"]=="tmpfs"
    assert not machine["performanceQualified"]
    for name,expected in image["catalogs"].items():
        assert hashlib.sha256(bundle.extractfile(name).read()).hexdigest()==expected["sha256"]
assert raw["complete"] and len(raw["jobs"])==3 and receipt["warmJobs"]==3
assert all(receipt[k] for k in ["complete","allWorkersJoined","guestFixturesRemoved","archivedAndVerifiedUnderLease"])
assert identity==image and jobs==read(quiet/"jobs.json")
assert proof["catalogSha256"]==image["catalogs"]["representative.json"]["sha256"]
assert proof["launched"]["library"]["sha256"]==image["coreSHA256"]["candidate"]
assert proof["launched"]["python"]["sha256"]==image["expectedCPythonSHA256"]
split=[]
for row,(case,lane) in zip(raw["jobs"],jobs,strict=True):
    lanes=["warm","warm-async"] if lane=="paired" else [lane]
    assert row["case"]==case and row["lanes"]==lanes
    assert len(row["samples"])==28*len(lanes)
    for mode in lanes:
        split.append(dict(row,lanes=[mode],samples=[item for item in row["samples"] if item["lane"]==mode]))
raw["jobs"]=split
rows=[]
pinned=set()
for job in raw["jobs"]:
    case=case_by_id[job["case"]]
    lane,=job["lanes"]
    assert job["workersJoinedAndFixturesRemoved"] and len(job["samples"])==28
    med={};cpu={};iqr={}
    for label,worker in job["identities"].items():
        assert worker["catalogSha256"]==image["catalogs"]["representative.json"]["sha256"]
        if label.startswith("CPython"):
            assert worker["version"].startswith("3.13.16")
            pinned.add(worker["executableSha256"])
        else:
            assert worker["runtimeVersion"]=="11.0.0"
            libraries={Path(v["path"]).name:v["sha256"].lower() for v in worker["libraries"]}
            assert libraries["Lokad.Lython.dll"]==image["coreSHA256"][label]
        samples=[s for s in job["samples"]if s["engine"]==label]
        assert len(samples)==7
        times=[];wider=[]
        for sample in samples:
            r=sample["response"]
            assert r["status"]=="Completed" and r["completedInvocations"]>0 and all(r[k]==case[k] for k in ["sourceSha256","fixtureSha256","expectedOutputSha256"])
            assert r.get("actualOutputSha256")==(None if lane=="compile" else case["expectedOutputSha256"])
            assert r.get("actualFilesSha256")== (None if lane=="compile" else case.get("expectedFilesSha256"))
            times.append(r["elapsedTicks"]*1000/r["clockFrequency"]/r["completedInvocations"])
            wider.append(sample["externalProcessCpuTicks"]*1000/sample["externalCpuFrequency"]/r["completedInvocations"])
        med[label]=median(times)
        cpu[label]=median(wider)
        q=quantiles(times,n=4,method="inclusive")
        iqr[label]=(q[2]-q[0])*100/med[label]
    span=lambda v,l:[min(v[l],v[l+"-control"]),max(v[l],v[l+"-control"])]
    div=lambda v:sorted(a/b for a in span(v,"candidate") for b in span(v,"CPython"))
    spreads=lambda l:(max(span(med,l))/min(span(med,l))-1)*100
    row=dict(case=case["id"],lane=lane,lythonMs=span(med,"candidate"),cpythonMs=span(med,"CPython"),ratio=[min(div(med)),max(div(med))],widerCpuRatio=[min(div(cpu)),max(div(cpu))],lythonControlPercent=spreads("candidate"),cpythonControlPercent=spreads("CPython"),maxIQRPercent=max(iqr.values()),sourceUtf8Bytes=case["sourceUtf8Bytes"],fixtureSha256=case["fixtureSha256"])
    rows.append(row)
    print(case["id"],lane,"L [",*map(lambda n:f"{n:.5f}",row["lythonMs"]),"] C [",*map(lambda n:f"{n:.5f}",row["cpythonMs"]),"]",*[f"{n:.4f}" for n in row["ratio"]],"spread",*[f"{row[k]:.2f}%" for k in ["lythonControlPercent","cpythonControlPercent"]])
assert pinned == {image["expectedCPythonSHA256"]}
(quiet/"summary.json").write_text(json.dumps(dict(source=image["sourceRevision"],cpythonVersion="3.13.16",cpythonExecutableSHA256=next(iter(pinned)),elapsedSeconds=raw["elapsedSeconds"],timedBatches=sum(len(job["samples"]) for job in raw["jobs"]),performanceQualified=False,rows=rows),indent=2)+"\n",encoding="utf-8",newline="\n")


from shutil import copyfile
repo=quiet.parents[3]
artifacts=repo/"benchmarks/results/2026-11-27-wsl-shipment-cpython"
artifacts.mkdir(exist_ok=True)
for name in ("observations.tar.xz","summary.json","identity.json","archive-receipt.json"):
    copyfile(quiet/name,artifacts/name)
files={name:quiet/name for name in ("prepare.py","collect.py","run.sh","archive.py","verification.json","collection.log","exit-code.txt")}
with tarfile.open(artifacts/"procedures.tar.xz","w:xz") as t:
    for name,path in files.items():t.add(path,arcname=name)
with tarfile.open(artifacts/"procedures.tar.xz") as t:
    assert all(t.extractfile(name).read()==path.read_bytes() for name,path in files.items())
