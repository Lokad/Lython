from hashlib import sha256
from pathlib import Path
from shutil import copy2, copytree
from subprocess import check_output
import json

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior_lab = lab.parent / 'private-outer-owner-b1962-20261128'
prior = prior_lab / 'comparison'
baseline = lab.parent / 'short-frontend-cpython-b1968-20261128/comparison/quiet'
pair = lab / 'comparison'
core = 'Lokad.Lython.dll'
build = lab / 'ubuntu-artifacts/bin/Lokad.Lython/release_net11.0' / core
read = lambda path: json.loads(path.read_bytes())
digest = lambda data: sha256(data).hexdigest()
hash_file = lambda path: digest(path.read_bytes())
hashes = lambda directory: {path.name: hash_file(path) for path in directory.iterdir()}


def git(*args):
    return check_output(['git', *args], cwd=repo)


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')


old = read(baseline / 'identity.json')
reference = old['sourceRevision']
head = git('rev-parse', 'HEAD').decode().strip()
assert reference.startswith('83042273c') and head.startswith('197e83a1e')
assert not git('diff', reference, head, '--', 'src', 'tests', 'Directory.Build.props', 'Directory.Packages.props')
assert not git('ls-files', '--others', '--exclude-standard', '--', 'src', 'tests')
patch = git('diff', '--binary', reference, '--', 'src', 'tests')
assert patch.count(b'diff --git ') == 5
(lab / 'candidate.patch').write_bytes(patch)

frozen = old['imageFiles']['candidate']
assert len(frozen) == 32 and hashes(baseline / 'local-image') == frozen
pair.mkdir()
for role in ('reference', 'candidate'):
    copytree(baseline / 'local-image', pair / role)
copy2(build, pair / 'candidate' / core)
assert not (pair / 'candidate' / core).samefile(build)
images = {role: hashes(pair / role) for role in ('reference', 'candidate')}
assert images['reference'] == frozen
assert {name for name, checksum in images['candidate'].items() if frozen[name] != checksum} == {core}

catalog_path = prior / 'representative.json'
prior_manifest = read(prior / 'identity.json')
assert hash_file(catalog_path) == prior_manifest['catalogs'][catalog_path.name]['sha256']
catalog = read(catalog_path)
by_id = {case['id']: case for case in catalog['cases']}
tuple_id = 'diagnostic.shipment-row-generator-reduction'
list_id = 'diagnostic.shipment-row-list-generator-reduction'
range_id = 'diagnostic.shipment-row-range-generator-reduction'
alias_id = 'diagnostic.sum-retained-outer-aliases'
tuple_case = by_id[tuple_id]
assert tuple_case['source'].count("in ('late', 'hold'))") == 1
list_source = tuple_case['source'].replace("in ('late', 'hold'))", "in ['late', 'hold'])")
by_id[list_id] = dict(tuple_case, id=list_id, source=list_source,
    sourceUtf8Bytes=len(list_source.encode('utf-8')), sourceSha256=digest(list_source.encode('utf-8')))
catalog['cases'] = [by_id[case] for case in (tuple_id, list_id, range_id, alias_id)]
save(pair / 'representative.json', catalog)
save(pair / 'jobs.json', {'warm': [[case, 'warm-async'] for case in (tuple_id, list_id, range_id)]})
for name in ('cpython-worker.py', 'collect.py', 'run.sh'):
    copy2(prior / name, pair / name)
assert hash_file(pair / 'cpython-worker.py') == old['cpythonWorkerSHA256']
assert b'\r' not in (pair / 'run.sh').read_bytes()
save(pair / 'identity.json', dict(sourceRevision=head, referenceRevision=reference,
    sourcePatchSHA256=digest(patch), imageFiles=images,
    coreSHA256={role + suffix: image[core] for role, image in images.items() for suffix in ('', '-control')},
    expectedCPythonSHA256=old['expectedCPythonSHA256'], cpythonWorkerSHA256=old['cpythonWorkerSHA256'],
    catalogs={name: {'sha256': hash_file(pair / name)} for name in ('representative.json', 'jobs.json')},
    purpose='Keep an exact outer sequence position in its private generator operand and materialize once on promotion.'))
copy2(prior_lab / 'check-admission.py', lab / 'check-admission.py')
for name in ('measure-allocation.py', 'summarize.py'):
    source = (prior_lab / name).read_text(encoding='utf-8').replace("['cases'])==5", "['cases'])==4").replace('["caseCount"] == 5', '["caseCount"] == 4')
    (lab / name).write_text(source, encoding='utf-8', newline='\n')
print('Copied two exact images for three timing lanes and one retained-owner witness.')
