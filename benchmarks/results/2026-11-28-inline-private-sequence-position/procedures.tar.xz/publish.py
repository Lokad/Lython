from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import tarfile

lab = Path(__file__).resolve().parent
out = lab.parents[3] / 'benchmarks/results/2026-11-28-inline-private-sequence-position'
pair = lab / 'comparison'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()

identity = read(pair / 'identity.json')
repeat = lab / 'repeat'
for root in (pair, repeat):
    image = read(root / 'identity.json')
    assert image['sourcePatchSHA256'] == digest(lab / 'candidate.patch')
    assert image['imageFiles'] == identity['imageFiles']
    for role, files in image['imageFiles'].items():
        assert {path.name: digest(path) for path in (root / role).iterdir()} == files
    assert read(root / 'summary.json')['verifiedTimedBatches'] == 84
    receipt = read(root / 'archive-receipt.json')
    assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
    assert receipt['archiveSHA256'] == digest(root / 'observations.tar.xz')
allocation = read(lab / 'allocation/summary.json')
admission = read(lab / 'admission/summary.json')
assert len(allocation) == len(admission) == 8
assert all(row['admittedPeak'][0] == row['admittedPeak'][1] and row['compiled'][0] == row['compiled'][1]
    for row in allocation)
assert all(row['requests'][0] == row['requests'][1] and row['peak'][0] == row['peak'][1] for row in admission)
assert all(row['clr'][0] == row['clr'][1] for row in allocation if 'retained' in row['case'])
for target in ('windows-net10.0', 'windows-net11.0', 'ubuntu-net11.0'):
    for suite, count in (('public', 411), ('whitebox', 41)):
        log = lab / f'{target}-{suite}.log'
        assert f'Passed: {count:5d}' in log.read_text(encoding='utf-8')
        assert 'Failed:     0' in log.read_text(encoding='utf-8')

out.mkdir(exist_ok=True)
published = {name: pair / name for name in ('identity.json', 'summary.json', 'observations.tar.xz')}
published.update({f'repeat-{name}': repeat / name for name in ('identity.json', 'summary.json', 'observations.tar.xz')})
published.update({f'{name}-summary.json': lab / name / 'summary.json' for name in ('allocation', 'admission')})
for name, path in published.items():
    copy2(path, out / name)
    assert digest(out / name) == digest(path)

procedures = {path.name: path for path in lab.iterdir() if path.is_file()
    and path.suffix in ('.log', '.py', '.patch', '.sh')}
procedures.update({name: pair / name for name in ('reference-verify.json', 'candidate-verify.json',
    'exit-code.txt', 'archive-receipt.json')})
procedures.update({f'repeat/{name}': repeat / name for name in ('reference-verify.json', 'candidate-verify.json',
    'exit-code.txt', 'archive-receipt.json')})
for kind in ('allocation', 'admission'):
    procedures.update({f'{kind}/{path.name}': path for path in (lab / kind).glob('*.json')})
prototype = lab / 'before-post-entry-guard'
for name in ('candidate.patch','allocation.log','admission.log','comparison/identity.json',
    'allocation/summary.json','admission/summary.json'):
    procedures[f'before-post-entry-guard/{name}'] = prototype / name
with tarfile.open(out / 'procedures.tar.xz', 'w:xz') as archive:
    for name, path in procedures.items():
        archive.add(path, arcname=name)
with tarfile.open(out / 'procedures.tar.xz') as archive:
    for name, path in procedures.items():
        assert sha256(archive.extractfile(name).read()).hexdigest() == digest(path)
print('Verified both images in both collections, 168 batches, release checks and matched admission.')
