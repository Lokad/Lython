from hashlib import sha256
from pathlib import Path
from shutil import copy2, copytree
import json

lab = Path(__file__).resolve().parent
first = lab / 'comparison'
repeat = lab / 'repeat'
repeat.mkdir()
digest = lambda path: sha256(path.read_bytes()).hexdigest()
identity = json.loads((first / 'identity.json').read_bytes())

for role, files in identity['imageFiles'].items():
    assert {p.name: digest(p) for p in (first / role).iterdir()} == files
    copytree(first / role, repeat / role)
    assert {p.name: digest(p) for p in (repeat / role).iterdir()} == files
for name in ('representative.json', 'cpython-worker.py'):
    copy2(first / name, repeat / name)
    assert digest(repeat / name) == digest(first / name)

collector = (first / 'collect.py').read_text(encoding='utf-8')
old_labels = "labels=['reference-control','candidate-control','reference','candidate']"
assert collector.count(old_labels) == 1
collector = collector.replace(old_labels, "labels=['candidate','reference','candidate-control','reference-control']")
(repeat / 'collect.py').write_text(collector, encoding='utf-8', newline='\n')
runner = (first / 'run.sh').read_text(encoding='utf-8')
assert runner.count('taskset -c 27') == 1
(repeat / 'run.sh').write_text(runner.replace('taskset -c 27', 'taskset -c 25'), encoding='utf-8', newline='\n')
assert b'\r' not in (repeat / 'run.sh').read_bytes()
jobs = json.loads((first / 'jobs.json').read_bytes())
jobs['warm'].reverse()
(repeat / 'jobs.json').write_text(json.dumps(jobs, indent=2) + '\n', encoding='utf-8', newline='\n')
identity['catalogs']['jobs.json']['sha256'] = digest(repeat / 'jobs.json')
(repeat / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8', newline='\n')
summary = (lab / 'summarize.py').read_text(encoding='utf-8')
assert summary.count('else "comparison"') == 1
(lab / 'summarize-repeat.py').write_text(summary.replace('else "comparison"', 'else "repeat"'),
    encoding='utf-8', newline='\n')
