from pathlib import Path
import hashlib, json, os, subprocess

lab = Path(__file__).resolve().parent
previous = lab.parent / 'retained-closure-profile-r582'
donor = lab.parent / 'function-metadata-slots-r584'
repo = Path.cwd()
load = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
save = lambda name,data: (lab/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
sha = lambda data: hashlib.sha256(data).hexdigest()
source = load(lab.parent / 'exact-keyword-transport-r579/catalog.json')
ids = {'scripts.report-forwarding.expanded','scripts.report-forwarding.mutable-bound'}
source['cases'] = [c for c in source['cases'] if c['id'] in ids]
assert len(source['cases']) == 2
save('requested-catalog.json', source)
image = donor/'frozen/candidate'
sdk = Path.home()/'.dotnet11'
dotnet = sdk/'dotnet.exe'
env = dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
manifest = load(donor/'frozen-identity.json')['images']['candidate']
assert len(manifest)==32 and all(sha((image/name).read_bytes())==h for name,h in manifest.items())
with (lab/'candidate-verify.log').open('wb') as out:
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',lab/'requested-catalog.json',
                    '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',repo/'benchmarks/cpython-worker.py',
                    '--out',lab/'candidate-verify.json'],env=env,stdout=out,stderr=subprocess.STDOUT,check=True,timeout=75)
checked = load(lab/'candidate-verify.json')
assert checked['state']=='Completed' and checked['catalogSha256']==sha((lab/'requested-catalog.json').read_bytes())

code = (previous/'prepare.py').read_text(encoding='utf-8')
code = code.replace("donor = lab.parent / 'function-annotation-inputs-r581'", "donor = lab.parent / 'function-metadata-slots-r584'")
code = code.replace("startswith('62665014')", "startswith('d1b9f71b')")
code = code.replace("catalog = (donor/'catalog.json').read_bytes()","catalog = (lab/'requested-catalog.json').read_bytes()")
code = code.replace("source['catalogSHA256'] == sha(catalog) == load(donor/'candidate-verify.json')['catalogSha256']",
                    "sha(catalog) == load(lab/'candidate-verify.json')['catalogSha256']")
code = code.replace("load(donor/'candidate-verify.json')","load(lab/'candidate-verify.json')")
code = code.replace("head.startswith('0547e5489')", "head.startswith('2215ec040')")
code = code.replace("'8cfa31043',head,'--','src','tests'", "'57ed0b1e8',head,'--','src'")
code = code.replace('retained-closure-profile-b1008-20261118','post-transport-attribution-b1011-20261118')
code = code.replace('lython-b1008-retained-closure-profile-20261118','lython-b1011-post-transport-attribution-20261118')
code = code.replace('Closure factories after retained definition changes','Expanded forwarding after direct trailing keyword transport')
code = code.replace("jobs = [('rules', 'scripts.rule-default-closures', 'warm'), ('annotated', 'scripts.annotated-rule-closures', 'warm')]",
                    "jobs = [('forwarding', 'scripts.report-forwarding.expanded', 'warm'), ('mutable', 'scripts.report-forwarding.mutable-bound', 'warm')]")
code = code.replace("['rules', 'annotated']", "['forwarding', 'mutable']")
code = code.replace('R582/B1008 {head}/62665014 closure CPU attribution','R586/B1011 {head}/d1b9f71b forwarding CPU attribution')
code = code.replace("assert 'B1008' in collect","assert 'B1011' in collect")
code = code.replace('Retained closure CPU attribution','Post-transport forwarding CPU attribution')
i = code.index('inventory=load')
j = code.index('cfg=dict',i)
code = code[:i] + code[j:]
code = code.replace("retireGroups=[retire]", "retireGroups=[]")
code = code.replace("sourceCatalogSHA256=sha(catalog)", "sourceCatalogSHA256=source['catalogSHA256']")
code = code.replace("lython-b1008-fixtures", "lython-b1011-fixtures")
signature = """     'split and unpack':('SplitText','SplitUtf8','SplitOnce','SplitCollector','CountSplits','BuildSplit','UnpackValue','UnpackExact','CopyUnpack','SplitSearch'),"""
code = code.replace("     'closure retention':",signature+"\n     'closure retention':")
compile(code,'prepare.py','exec')
(lab/'prepare.py').write_text(code,encoding='utf-8',newline='\n')
subprocess.run(['C:/Python313/python.exe','-X','utf8',lab/'prepare.py'],check=True)
print('Verified current profiling image and custom forwarding catalog.')
