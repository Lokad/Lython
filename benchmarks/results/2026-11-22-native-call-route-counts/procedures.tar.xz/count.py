from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
tree=repo/".git/agent-worktrees/native-call-selection-single-proof-20261122"
out=lab/"diagnostic"
out.mkdir(exist_ok=False)
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])

def git(*args):
    return subprocess.check_output(["git",*args],cwd=tree)

def run(command,cwd=repo,**kwargs):
    subprocess.run(command,cwd=cwd,env=env,timeout=90,check=True,**kwargs)

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def write(path,text):
    path.write_text(text,encoding="utf-8",newline="\n")

def save(path,value):
    write(path,json.dumps(value,ensure_ascii=False,indent=2)+"\n")

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def insert_after(text,anchor,replacement):
    assert text.count(anchor)==1,anchor
    return text.replace(anchor,anchor+replacement,1)

revision=git("rev-parse","HEAD").decode().strip()
target="76b7934f7"
assert revision.startswith("b5f0c0c18") and not git("status","--porcelain")
assert not git("diff",target,"HEAD","--","src/Lokad.Lython")
runtime=tree/"src/Lokad.Lython/Runtime"
call_path=runtime/"LythonRuntime.Executable.Calls.cs"
native_path=runtime/"LythonRuntime.Executable.Calls.Invoke.cs"
nested_path=runtime/"LythonRuntime.Executable.NativePrefix.cs"
paths=(call_path,native_path,nested_path)
original={p:p.read_bytes() for p in paths}
counters=("FramedCandidates","FramedNative","FramedFallback","DeferredLeaf","NestedNative")
try:
    calls=call_path.read_text(encoding="utf-8")
    calls=insert_after(calls,"internal sealed partial class ExecutionContext\n    {\n",
        "\n".join(f"        internal static int Diagnostic{name};" for name in counters)+"\n\n")
    calls=insert_after(calls,"            if (function is null) return false;\n            next = BeginFunctionCall(function, receiver, site, start, site.CallSpan,\n","")
    calls=insert_after(calls,"            if (function is null) return false;\n",
                       "            Interlocked.Increment(ref DiagnosticFramedFallback);\n")
    calls=insert_after(calls,"                !function.HasCompletePositionalSupply(site.ArgumentCount, null))\n                return false;\n",
                       "            Interlocked.Increment(ref DiagnosticDeferredLeaf);\n")
    write(call_path,calls)
    native=native_path.read_text(encoding="utf-8")
    native=insert_after(native,"            if (function is not null && invocation is not null)\n            {\n",
                       "                Interlocked.Increment(ref DiagnosticFramedCandidates);\n")
    native=insert_after(native,"                if (!function.TrySelectNativeCall(call, functionReceiver, out var completePositional)) return false;\n",
                       "                Interlocked.Increment(ref DiagnosticFramedNative);\n")
    write(native_path,native)
    nested=nested_path.read_text(encoding="utf-8")
    nested=insert_after(nested,"            if (function is null || !function.TrySelectNativeCall(call, receiver, out var completePositional)) return false;\n",
                        "            Interlocked.Increment(ref ExecutionContext.DiagnosticNestedNative);\n")
    write(nested_path,nested)
    (out/"diagnostic.patch").write_bytes(git("diff","--binary","--","src"))
    with (out/"core-build.log").open("w",encoding="utf-8") as log:
        run([dotnet,"build","src/Lokad.Lython/Lokad.Lython.csproj","-c","Release","-f","net11.0",
             "--no-incremental","--artifacts-path",out/"artifacts","--nologo"],cwd=tree,stdout=log,stderr=subprocess.STDOUT)
finally:
    for path,data in original.items():path.write_bytes(data)
assert not git("status","--porcelain")

base=lab.parent/"native-call-selection-single-proof-20261122/comparison"
donor=base/"frozen-candidate"
info=read(base/"quiet/identity.json")
manifest=info["imageFiles"]["candidate"]
assert len(manifest)==32 and {name:sha(donor/name) for name in manifest}==manifest
catalog_path=base/"quiet/representative.json"
assert sha(catalog_path)==info["catalogs"][catalog_path.name]["sha256"]
catalog=read(catalog_path)
assert len(catalog["cases"])==6
catalog["cases"]=[{**c,"id":c["id"]+(".async" if asynchronous else ""), "runAsync":asynchronous}
                  for c in catalog["cases"] for asynchronous in (False,True)]
case_path=out/"cases.json"
save(case_path,catalog)
image=out/"image"
image.mkdir()
for name in manifest:shutil.copyfile(donor/name,image/name)
shutil.copyfile(out/"artifacts/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll",image/"Lokad.Lython.dll")
hashes={name:sha(image/name) for name in manifest}
assert [n for n in hashes if hashes[n]!=manifest[n]]==["Lokad.Lython.dll"]

recipe=repo/"benchmarks/results/2026-11-22-native-operand-call-loan/route-procedures.tar.xz"
with tarfile.open(recipe) as recipes:
    cs=recipes.extractfile("Program.cs").read().decode("utf-8-sig")
    project=recipes.extractfile("RouteProbe.csproj").read().decode("utf-8-sig")
start=cs.index("var entries =")
end=cs.index("foreach (var item",start)
names=json.dumps(counters)
cs=cs[:start]+f'''string[] names = {names};
var runtime = typeof(LythonEngine).Assembly.GetType("Lokad.Lython.Runtime.LythonRuntime+ExecutionContext", true)!;
var fields = names.Select(name => runtime.GetField("Diagnostic" + name, all)!).ToArray();
'''+cs[end:]
start=cs.index("        entries.SetValue")
end=cs.index("        script.Dispose();",start)
cs=cs[:start]+'''        foreach (var field in fields) field.SetValue(null, 0);
        Run();
        rows.Add(new { id = item.GetProperty("id").GetString(), asynchronous,
            routes = names.Zip(fields, (name, field) => (name, value: (int)field.GetValue(null)!))
                .ToDictionary(item => item.name, item => item.value),
            peakExecutionMemoryBytes, allowanceReturned = true });
'''+cs[end:]
write(out/"Program.cs",cs)
write(out/"RouteProbe.csproj",project)
with (out/"probe-build.log").open("w",encoding="utf-8") as log:
    run([dotnet,"build",out/"RouteProbe.csproj","-c","Release","--no-incremental","--nologo"],stdout=log,stderr=subprocess.STDOUT)
for path in (out/"bin/Release/net11.0").glob("RouteProbe.*"):shutil.copyfile(path,image/path.name)
report=out/"routes.json"
run([dotnet,image/"RouteProbe.dll",image,case_path,report])
assert {n:sha(image/n) for n in hashes}==hashes
save(out/"identity.json",dict(equivalentCoreSource=target,instrumentedBaseRevision=revision,imageHashes=hashes,
                            stagedWorkerHashes=manifest,sourceCatalogSHA256=sha(catalog_path),
                            projectedCatalogSHA256=sha(case_path),instrumentationSHA256=sha(out/"diagnostic.patch")))
for row in read(report)["rows"]:
    print(row["id"],row["routes"],row["peakExecutionMemoryBytes"],flush=True)
