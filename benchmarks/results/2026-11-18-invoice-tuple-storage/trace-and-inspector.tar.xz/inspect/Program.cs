using Microsoft.Diagnostics.Tracing.Etlx;
using System.Text.Json;

var tracePath = Path.ChangeExtension(args[0], ".etlx");
TraceLog.CreateFromEventPipeDataFile(args[0], tracePath, new TraceLogOptions());
using var trace = new TraceLog(tracePath);
var all = 0;
long totalWeight = 0;
var unresolved = 0;
var tuples = new Dictionary<string, (int Count, long Weight, long ObjectBytes)>();
var totalTypes = new Dictionary<string, (int Count, long Weight)>();
foreach (var e in trace.Events)
{
    if (!e.EventName.Contains("AllocationTick", StringComparison.Ordinal)) continue;
    all++;
    long Number(string field) => e.PayloadNames.Contains(field) ? Convert.ToInt64(e.PayloadByName(field)) : 0;
    var type = e.PayloadByName("TypeName")?.ToString() ?? "<unknown>";
    var weight = Number("AllocationAmount64");
    totalWeight += weight;
    var tally = totalTypes.GetValueOrDefault(type);
    totalTypes[type] = (tally.Count + 1, tally.Weight + weight);
    var frames = new List<string>();
    for (var stack = e.CallStack(); stack is not null; stack = stack.Caller) frames.Add(stack.CodeAddress.FullMethodName);
    if (!frames.Any(f => f.StartsWith("Lokad.Lython.Runtime.", StringComparison.Ordinal))) unresolved++;
    if (!frames.Any(f => f.Contains("PyTuple.FromIntegerSlots"))) continue;
    var below = frames.Any(f => f.Contains("ExecuteInitializedFrame")) ? "initialized frame" : "module path";
    var key = $"{type} / {below}";
    var group = tuples.GetValueOrDefault(key);
    tuples[key] = (group.Count + 1, group.Weight + weight, group.ObjectBytes + Number("ObjectSize"));
}
var result = new
{
    all, totalWeight, unresolved,
    totalTypes = totalTypes.OrderByDescending(pair => pair.Value.Count).Select(pair => new { type = pair.Key, pair.Value.Count, pair.Value.Weight }),
    tupleOrigins = tuples.OrderByDescending(pair => pair.Value.Count).Select(pair => new { path = pair.Key, pair.Value.Count, pair.Value.Weight, pair.Value.ObjectBytes }),
    limits = "Sample types and inclusive stacks attribute trigger allocations approximately. Counters can miss allocations, including inlined ancestry. Weights are neither exact per-type bytes nor removable CPU."
};
File.WriteAllText(args[1], JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }) + "\n");
Console.WriteLine(JsonSerializer.Serialize(new { all, unresolved, totalWeight, result.tupleOrigins }));
