; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 97 single block inlinees; 29 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 344
       lea      rbp, [rsp+0x190]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x120], xmm4
       vmovdqa  xmmword ptr [rbp-0x110], xmm4
       mov      rax, -192
 
G_M000_IG132:                ;; offset=0x0039
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG132
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x28], r9
       mov      rsi, r8
       mov      rbx, r9
       mov      eax, dword ptr [rbp+0x30]
       mov      rdi, gword ptr [rbp+0x38]
       mov      r14, bword ptr [rbp+0x40]
 
G_M000_IG02:                ;; offset=0x0072
       xor      r8, r8
       mov      gword ptr [r14], r8
       test     rdi, rdi
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x007D
       mov      r8, 0x7FF9CD0A0048
       cmp      qword ptr [rdi], r8
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x008C
       mov      gword ptr [rbp-0x128], rdi
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0095
       xor      r8, r8
       mov      gword ptr [rbp-0x128], r8
 
G_M000_IG06:                ;; offset=0x009F
       cmp      byte  ptr [rbx+0x30], 0
       je       SHORT G_M000_IG09
 
G_M000_IG07:                ;; offset=0x00A5
       mov      r8, gword ptr [rcx+0x20]
       cmp      eax, dword ptr [r8+0x08]
       jae      G_M000_IG118
       mov      r10d, eax
       shl      r10, 4
       lea      rcx, bword ptr [r8+r10+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9CD0A1B40
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       test     rax, rax
       je       SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x00DD
       mov      rcx, 0x7FF9CCF77AF8
       cmp      qword ptr [rax], rcx
       jne      SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x00EC
       mov      rcx, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rbp+0x30]
       xor      r15, r15
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x00F8
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rcx+0x20]
       mov      eax, dword ptr [rbp+0x30]
       cmp      eax, dword ptr [r8+0x08]
       jae      G_M000_IG118
       mov      r10d, eax
       shl      r10, 4
       lea      rcx, bword ptr [r8+r10+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9CD0A1B40
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r15, rax
 
G_M000_IG11:                ;; offset=0x0135
       test     rdi, rdi
       je       SHORT G_M000_IG16
 
G_M000_IG12:                ;; offset=0x013A
       mov      r8, 0x7FF9CD0C78F0
       cmp      qword ptr [rdi], r8
       jne      SHORT G_M000_IG16
 
G_M000_IG13:                ;; offset=0x0149
       mov      r8, gword ptr [rdi+0x10]
       test     r8, r8
       je       SHORT G_M000_IG16
 
G_M000_IG14:                ;; offset=0x0152
       mov      rdx, 0x7FF9CD0A0048
       cmp      qword ptr [r8], rdx
       jne      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0161
       mov      gword ptr [rbp-0x128], r8
       mov      r15, gword ptr [rdi+0x08]
 
G_M000_IG16:                ;; offset=0x016C
       cmp      gword ptr [rbp-0x128], 0
       je       SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0176
       test     rsi, rsi
       jne      G_M000_IG82
 
G_M000_IG18:                ;; offset=0x017F
       cmp      byte  ptr [rbx+0x30], 0
       je       SHORT G_M000_IG19
       cmp      byte  ptr [rbx+0x34], 0
       jne      G_M000_IG32
 
G_M000_IG19:                ;; offset=0x018F
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       je       SHORT G_M000_IG20
       lea      rdx, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
       jmp      SHORT G_M000_IG21
 
G_M000_IG20:                ;; offset=0x01A6
       xor      rdx, rdx
       xor      r8d, r8d
 
G_M000_IG21:                ;; offset=0x01AB
       mov      bword ptr [rbp-0x100], rdx
       mov      dword ptr [rbp-0xF8], r8d
       mov      rdx, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rdx
       test     rsi, rsi
       setne    r8b
       movzx    r8, r8b
       mov      dword ptr [rsp+0x28], r8d
       lea      r8, [rbp-0xC0]
       mov      qword ptr [rsp+0x30], r8
       lea      r8, [rbp-0x100]
       mov      rdx, rdi
       mov      rcx, rbx
       mov      r9d, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeBuiltinFromSlots(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG30
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, 0x7FF9CCD66808
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       test     rdi, rdi
       jne      G_M000_IG28
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rcx]
       mov      r9, gword ptr [r9+0x98]
       mov      edx, dword ptr [rcx+0x10]
       cmp      edx, dword ptr [r9+0x08]
       jae      G_M000_IG31
       shl      rdx, 5
       lea      r8, bword ptr [r9+rdx+0x10]
       mov      rdi, gword ptr [rbp-0xC0]
       mov      r14, qword ptr [rbp-0xB8]
       mov      ebx, dword ptr [r8+0x18]
       test     ebx, ebx
       jge      SHORT G_M000_IG22
       mov      gword ptr [rbp-0x110], rdi
       mov      qword ptr [rbp-0x108], r14
       lea      r9, [rbp-0x110]
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      SHORT G_M000_IG29
 
G_M000_IG22:                ;; offset=0x0279
       lea      rsi, bword ptr [rcx+0x20]
       mov      edx, dword ptr [r8+0x1C]
       cmp      edx, 51
       ja       SHORT G_M000_IG25
 
G_M000_IG23:                ;; offset=0x0286
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x0296
       mov      r15d, ebx
       jmp      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x029B
       mov      r15d, dword ptr [r8+0x14]
 
G_M000_IG26:                ;; offset=0x029F
       cmp      ebx, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG27
       mov      rcx, rsi
       mov      edx, ebx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG27:                ;; offset=0x02AF
       mov      rdx, gword ptr [rsi]
       cmp      r15d, dword ptr [rdx+0x08]
       jae      SHORT G_M000_IG31
       mov      eax, r15d
       shl      rax, 4
       lea      r15, bword ptr [rdx+rax+0x10]
       mov      rcx, r15
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r15+0x08], r14
       mov      dword ptr [rsi+0x40], ebx
       jmp      SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x02D8
       mov      rcx, bword ptr [rbp+0x10]
       add      rcx, 32
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, r14
       mov      rdx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG29:                ;; offset=0x02F4
       mov      eax, 1
       jmp      G_M000_IG115
 
G_M000_IG30:                ;; offset=0x02FE
       xor      eax, eax
       jmp      G_M000_IG115
 
G_M000_IG31:                ;; offset=0x0305
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG32:                ;; offset=0x030B
       test     rdi, rdi
       je       G_M000_IG116
 
G_M000_IG33:                ;; offset=0x0314
       mov      rcx, 0x7FF9CD0C7BF0
       cmp      qword ptr [rdi], rcx
       jne      G_M000_IG116
 
G_M000_IG34:                ;; offset=0x0327
       mov      r9, gword ptr [rbx+0x20]
       test     r9, r9
       je       SHORT G_M000_IG37
 
G_M000_IG35:                ;; offset=0x0330
       mov      rcx, 0x7FF9CD0C7EF8
       cmp      qword ptr [r9], rcx
       jne      SHORT G_M000_IG37
 
G_M000_IG36:                ;; offset=0x033F
       mov      gword ptr [rsp+0x20], rbx
       mov      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x28], eax
       mov      gword ptr [rsp+0x30], rdi
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteTrimmedSplit(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableTrimmedSplit,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object):bool]
       test     eax, eax
       jne      G_M000_IG76
 
G_M000_IG37:                ;; offset=0x0369
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx]
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       je       SHORT G_M000_IG38
       lea      r9, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
       jmp      SHORT G_M000_IG39
 
G_M000_IG38:                ;; offset=0x0383
       xor      r9, r9
       xor      r8d, r8d
 
G_M000_IG39:                ;; offset=0x0389
       lea      rax, bword ptr [rcx+0x10]
       mov      r10, rsi
       test     r10, r10
       cmove    r10, gword ptr [rbp+0x18]
       mov      bword ptr [rbp-0x120], r9
       mov      dword ptr [rbp-0x118], r8d
       mov      gword ptr [rsp+0x20], rbx
       mov      r11d, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x28], r11d
       mov      gword ptr [rsp+0x30], r10
       lea      r8, [rbp-0xA8]
       mov      qword ptr [rsp+0x38], r8
       lea      r8, [rbp-0x120]
       mov      rcx, rdi
       mov      r9, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:TryConsumePrivateStringResult(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG69
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x20]
       mov      r11d, dword ptr [rbp+0x30]
       cmp      r11d, dword ptr [rax+0x08]
       jae      G_M000_IG81
       mov      edx, r11d
       shl      rdx, 4
       lea      rcx, bword ptr [rax+rdx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9CD0A1B40
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r14, rax
       mov      rcx, bword ptr [rbp+0x10]
       lea      rdx, bword ptr [rcx+0x20]
       cmp      byte  ptr [rbx+0x30], 0
       setne    al
       movzx    rax, al
       mov      r11d, dword ptr [rbp+0x30]
       lea      r15d, [r11+rax+0x01]
       mov      r13d, dword ptr [rbx+0x28]
       mov      rdx, gword ptr [rdx]
       test     rdx, rdx
       je       G_M000_IG77
       mov      eax, r15d
       mov      r8d, r13d
       add      rax, r8
       mov      r8d, dword ptr [rdx+0x08]
       cmp      rax, r8
       ja       G_M000_IG77
       mov      rax, rdx
       xor      r12, r12
       xor      r8d, r8d
       test     rax, rax
 
G_M000_IG40:                ;; offset=0x046B
       je       SHORT G_M000_IG43
       mov      rdx, qword ptr [rax]
       test     dword ptr [rdx], 0xFFFFFFFF80000000
       jne      SHORT G_M000_IG41
       lea      rdx, [rbp-0xF0]
       mov      rcx, rax
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x28]System.Buffers.MemoryManager`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:GetSpan():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this
       mov      r8d, dword ptr [rbp-0xE8]
       mov      r12, bword ptr [rbp-0xF0]
       mov      eax, r8d
       jmp      SHORT G_M000_IG42
 
G_M000_IG41:                ;; offset=0x049F
       lea      r12, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
 
G_M000_IG42:                ;; offset=0x04A6
       and      r15d, 0x7FFFFFFF
       mov      edx, r15d
       mov      r8d, r13d
       add      r8, rdx
       mov      eax, eax
       cmp      r8, rax
       ja       G_M000_IG77
       shl      rdx, 4
       add      r12, rdx
       mov      dword ptr [rbp-0xDC], r13d
       mov      r8d, dword ptr [rbp-0xDC]
 
G_M000_IG43:                ;; offset=0x04D6
       cmp      dword ptr [rbx+0x2C], 0
       je       G_M000_IG47
       test     byte  ptr [(reloc 0x7ff9cd0c82b8)], 1
       je       G_M000_IG78
 
G_M000_IG44:                ;; offset=0x04ED
       mov      rdx, 0x140F6401F48
       cmp      rdi, gword ptr [rdx]
       jne      SHORT G_M000_IG47
       test     r14, r14
       je       SHORT G_M000_IG47
 
G_M000_IG45:                ;; offset=0x0501
       mov      rdx, 0x7FF9CCE2B588
       cmp      qword ptr [r14], rdx
       jne      SHORT G_M000_IG47
 
G_M000_IG46:                ;; offset=0x0510
       cmp      r8d, 2
       jg       SHORT G_M000_IG47
       mov      r11d, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x20], r11d
       mov      gword ptr [rsp+0x28], r14
       mov      bword ptr [rbp-0x120], r12
       mov      dword ptr [rbp-0xDC], r8d
       mov      dword ptr [rbp-0x118], r8d
       lea      rdx, [rbp-0x120]
       mov      qword ptr [rsp+0x30], rdx
       mov      rdx, rsi
       mov      r8, gword ptr [rbp+0x18]
       mov      r9, rbx
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSplitUnpack(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):bool]
       test     eax, eax
       mov      r8d, dword ptr [rbp-0xDC]
       jne      G_M000_IG76
 
G_M000_IG47:                ;; offset=0x0568
       cmp      byte  ptr [rbx+0x33], 0
       jne      SHORT G_M000_IG49
 
G_M000_IG48:                ;; offset=0x056E
       mov      dword ptr [rbp-0xDC], r8d
       jmp      G_M000_IG61
 
G_M000_IG49:                ;; offset=0x057A
       cmp      r8d, 1
       je       SHORT G_M000_IG51
       mov      dword ptr [rbp-0xDC], r8d
       cmp      r8d, 2
       jne      G_M000_IG61
 
G_M000_IG50:                ;; offset=0x0591
       mov      r8d, dword ptr [rbp-0xDC]
 
G_M000_IG51:                ;; offset=0x0598
       test     byte  ptr [(reloc 0x7ff9cd0c82b8)], 1
       je       G_M000_IG79
 
G_M000_IG52:                ;; offset=0x05A5
       mov      rax, 0x140F6401F18
       cmp      rdi, gword ptr [rax]
       je       SHORT G_M000_IG54
 
G_M000_IG53:                ;; offset=0x05B4
       mov      dword ptr [rbp-0xDC], r8d
       jmp      G_M000_IG61
 
G_M000_IG54:                ;; offset=0x05C0
       test     r14, r14
       je       G_M000_IG60
 
G_M000_IG55:                ;; offset=0x05C9
       mov      rax, 0x7FF9CCEB8C08
       cmp      qword ptr [r14], rax
       jne      SHORT G_M000_IG59
 
G_M000_IG56:                ;; offset=0x05D8
       mov      dword ptr [rbp-0xDC], r8d
       test     r8d, r8d
       je       G_M000_IG81
       mov      r15, r12
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.PyDict:CanReadKeySynchronously(System.Object):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG61
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       test     rdx, rdx
       je       SHORT G_M000_IG58
 
G_M000_IG57:                ;; offset=0x0615
       mov      rcx, 0x7FF9CCE2B588
       cmp      qword ptr [rdx], rcx
       jne      G_M000_IG80
 
G_M000_IG58:                ;; offset=0x0628
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, rbx
       mov      r9d, dword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], r14
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryAccumulation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.PyDict,Lokad.Lython.Runtime.Text.PyString):bool]
       test     eax, eax
       je       SHORT G_M000_IG61
       jmp      G_M000_IG76
 
G_M000_IG59:                ;; offset=0x0650
       mov      dword ptr [rbp-0xDC], r8d
       jmp      SHORT G_M000_IG61
 
G_M000_IG60:                ;; offset=0x0659
       mov      dword ptr [rbp-0xDC], r8d
 
G_M000_IG61:                ;; offset=0x0660
       mov      r9, gword ptr [rbx+0x18]
       mov      rdx, rsi
       test     rdx, rdx
       cmove    rdx, gword ptr [rbp+0x18]
       mov      bword ptr [rbp-0x100], r12
       mov      r8d, dword ptr [rbp-0xDC]
       mov      dword ptr [rbp-0xF8], r8d
       mov      gword ptr [rsp+0x20], rdx
       lea      r8, [rbp-0xB0]
       mov      qword ptr [rsp+0x28], r8
       lea      r8, [rbp-0x100]
       mov      rdx, r14
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG68
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rcx]
       mov      r9, gword ptr [r9+0x98]
       mov      edx, dword ptr [rcx+0x10]
       cmp      edx, dword ptr [r9+0x08]
       jae      G_M000_IG81
       shl      rdx, 5
       lea      r8, bword ptr [r9+rdx+0x10]
       mov      rbx, gword ptr [rbp-0xB0]
       mov      edi, dword ptr [r8+0x18]
       test     edi, edi
       jge      SHORT G_M000_IG62
       mov      gword ptr [rbp-0x110], rbx
       xor      r9d, r9d
       mov      qword ptr [rbp-0x108], r9
       lea      r9, [rbp-0x110]
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG76
 
G_M000_IG62:                ;; offset=0x0709
       lea      rsi, bword ptr [rcx+0x20]
       mov      edx, dword ptr [r8+0x1C]
       cmp      edx, 51
       ja       SHORT G_M000_IG65
 
G_M000_IG63:                ;; offset=0x0716
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG65
 
G_M000_IG64:                ;; offset=0x0726
       mov      r14d, edi
       jmp      SHORT G_M000_IG66
 
G_M000_IG65:                ;; offset=0x072B
       mov      r14d, dword ptr [r8+0x14]
 
G_M000_IG66:                ;; offset=0x072F
       cmp      edi, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG67
       mov      rcx, rsi
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG67:                ;; offset=0x073F
       mov      rdx, gword ptr [rsi]
       cmp      r14d, dword ptr [rdx+0x08]
       jae      G_M000_IG81
       mov      eax, r14d
       shl      rax, 4
       lea      r14, bword ptr [rdx+rax+0x10]
       mov      rcx, r14
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       xor      eax, eax
       mov      qword ptr [r14+0x08], rax
       mov      dword ptr [rsi+0x40], edi
       jmp      G_M000_IG76
 
G_M000_IG68:                ;; offset=0x0771
       xor      eax, eax
       jmp      G_M000_IG115
 
G_M000_IG69:                ;; offset=0x0778
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rcx]
       mov      r9, gword ptr [r9+0x98]
       mov      edx, dword ptr [rcx+0x10]
       cmp      edx, dword ptr [r9+0x08]
       jae      G_M000_IG81
       shl      rdx, 5
       lea      r8, bword ptr [r9+rdx+0x10]
       mov      rbx, gword ptr [rbp-0xA8]
       mov      rdi, qword ptr [rbp-0xA0]
       mov      r14d, dword ptr [r8+0x18]
       test     r14d, r14d
       jge      SHORT G_M000_IG70
       mov      gword ptr [rbp-0x110], rbx
       mov      qword ptr [rbp-0x108], rdi
       lea      r9, [rbp-0x110]
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      SHORT G_M000_IG76
 
G_M000_IG70:                ;; offset=0x07D3
       lea      rsi, bword ptr [rcx+0x20]
       mov      edx, dword ptr [r8+0x1C]
       cmp      edx, 51
       ja       SHORT G_M000_IG73
 
G_M000_IG71:                ;; offset=0x07E0
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG73
 
G_M000_IG72:                ;; offset=0x07F0
       mov      r15d, r14d
       jmp      SHORT G_M000_IG74
 
G_M000_IG73:                ;; offset=0x07F5
       mov      r15d, dword ptr [r8+0x14]
 
G_M000_IG74:                ;; offset=0x07F9
       cmp      r14d, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG75
       mov      rcx, rsi
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG75:                ;; offset=0x080B
       mov      rdx, gword ptr [rsi]
       cmp      r15d, dword ptr [rdx+0x08]
       jae      G_M000_IG81
       mov      eax, r15d
       shl      rax, 4
       lea      r15, bword ptr [rdx+rax+0x10]
       mov      rcx, r15
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r15+0x08], rdi
       mov      dword ptr [rsi+0x40], r14d
 
G_M000_IG76:                ;; offset=0x0837
       mov      eax, 1
       jmp      G_M000_IG115
 
G_M000_IG77:                ;; offset=0x0841
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG78:                ;; offset=0x0848
       mov      dword ptr [rbp-0xDC], r8d
       mov      rcx, 0x7FF9CD0C8250
       call     CORINFO_HELP_GET_GCSTATIC_BASE
       mov      r8d, dword ptr [rbp-0xDC]
       jmp      G_M000_IG44
 
G_M000_IG79:                ;; offset=0x086A
       mov      dword ptr [rbp-0xDC], r8d
       mov      rcx, 0x7FF9CD0C8250
       call     CORINFO_HELP_GET_GCSTATIC_BASE
       mov      r8d, dword ptr [rbp-0xDC]
       jmp      G_M000_IG52
 
G_M000_IG80:                ;; offset=0x088C
       mov      rdx, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG81:                ;; offset=0x0895
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG82:                ;; offset=0x089B
       lea      r9, [rbp-0x40]
       mov      rcx, gword ptr [rbp-0x128]
       mov      rdx, rbx
       mov      r8, r15
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this]
       test     eax, eax
       je       G_M000_IG116
       xor      ecx, ecx
       mov      dword ptr [rbp-0x44], ecx
 
G_M000_IG83:                ;; offset=0x08BF
       mov      rdx, gword ptr [rbx+0x18]
       mov      rax, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rax+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x44], 1
       mov      rdi, gword ptr [rbx+0x18]
       mov      rax, gword ptr [rbp+0x18]
       mov      r13, gword ptr [rax+0xA0]
       cmp      byte  ptr [r13], r13b
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG84
       mov      rcx, r13
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG84:                ;; offset=0x0909
       mov      rcx, bword ptr [rbp+0x10]
       lea      rdx, bword ptr [rcx+0x20]
       cmp      byte  ptr [rbx+0x30], 0
       setne    al
       movzx    rax, al
       mov      r11d, dword ptr [rbp+0x30]
       lea      edi, [r11+rax+0x01]
       mov      r13d, dword ptr [rbx+0x28]
       mov      rdx, gword ptr [rdx]
       test     rdx, rdx
       je       SHORT G_M000_IG85
       mov      eax, edi
       mov      r8d, r13d
       add      rax, r8
       mov      r8d, dword ptr [rdx+0x08]
       cmp      rax, r8
       ja       G_M000_IG113
       mov      rax, rdx
       jmp      SHORT G_M000_IG86
 
G_M000_IG85:                ;; offset=0x094A
       mov      eax, edi
       or       eax, r13d
       jne      G_M000_IG113
       xor      rax, rax
       xor      edi, edi
       xor      r13d, r13d
 
G_M000_IG86:                ;; offset=0x095C
       xor      r12, r12
       xor      r8d, r8d
       test     rax, rax
       je       SHORT G_M000_IG89
       mov      rdx, qword ptr [rax]
       test     dword ptr [rdx], 0xFFFFFFFF80000000
       jne      SHORT G_M000_IG87
       lea      rdx, [rbp-0xD8]
       mov      rcx, rax
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x28]System.Buffers.MemoryManager`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:GetSpan():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this
       mov      r8d, dword ptr [rbp-0xD0]
       mov      r12, bword ptr [rbp-0xD8]
       mov      eax, r8d
       jmp      SHORT G_M000_IG88
 
G_M000_IG87:                ;; offset=0x0999
       lea      r12, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
 
G_M000_IG88:                ;; offset=0x09A0
       and      edi, 0x7FFFFFFF
       mov      edx, edi
       mov      r9d, r13d
       add      r9, rdx
       mov      eax, eax
       cmp      r9, rax
       ja       G_M000_IG113
       shl      rdx, 4
       add      r12, rdx
       mov      eax, r13d
       mov      r8d, eax
 
G_M000_IG89:                ;; offset=0x09C6
       cmp      byte  ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG91
 
G_M000_IG90:                ;; offset=0x09CC
       mov      dword ptr [rbp-0xC4], r8d
       jmp      SHORT G_M000_IG92
 
G_M000_IG91:                ;; offset=0x09D5
       mov      bword ptr [rbp-0x120], r12
       mov      dword ptr [rbp-0xC4], r8d
       mov      dword ptr [rbp-0x118], r8d
       lea      rdx, [rbp-0x58]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0x120]
       mov      r9, gword ptr [rbx+0x18]
       mov      rcx, gword ptr [rbp-0x128]
       mov      r8, r15
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartSuppliedIntegerReturn(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG109
 
G_M000_IG92:                ;; offset=0x0A16
       lea      rcx, [rbp-0x70]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0x68]
       mov      rdx, bword ptr [rbp+0x10]
       mov      r8, rbx
       mov      r9d, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PrepareUnpackedCallReturn(byref,Lokad.Lython.Frontend.ExecutableCallSite,int,byref):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      r8, gword ptr [rbx+0x18]
       cmp      byte  ptr [rbx+0x31], 0
       je       SHORT G_M000_IG93
       mov      r9d, 1
       jmp      SHORT G_M000_IG95
 
G_M000_IG93:                ;; offset=0x0A46
       mov      rdx, bword ptr [rbp+0x10]
       cmp      byte  ptr [rdx+0x14], 0
       jne      SHORT G_M000_IG94
       xor      r9d, r9d
       jmp      SHORT G_M000_IG95
 
G_M000_IG94:                ;; offset=0x0A55
       movzx    r9, byte  ptr [rbx+0x32]
 
G_M000_IG95:                ;; offset=0x0A5A
       mov      bword ptr [rbp-0x120], r12
       mov      r13d, dword ptr [rbp-0xC4]
       mov      dword ptr [rbp-0x118], r13d
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      gword ptr [rsp+0x28], r8
       mov      dword ptr [rsp+0x30], r9d
       movzx    r9, byte  ptr [rbp-0x40]
 
G_M000_IG96:                ;; offset=0x0A87
       vmovdqu  xmm0, xmmword ptr [rbp-0x68]
       vmovdqu  xmmword ptr [rbp-0x100], xmm0
 
G_M000_IG97:                ;; offset=0x0A94
       lea      r8, [rbp-0x78]
       mov      qword ptr [rsp+0x48], r8
       lea      r8, [rbp-0x88]
       mov      qword ptr [rsp+0x50], r8
       lea      r8, [rbp-0x90]
       mov      qword ptr [rsp+0x58], r8
       lea      r8, [rbp-0x120]
       mov      dword ptr [rsp+0x38], r9d
       lea      r9, [rbp-0x100]
       mov      qword ptr [rsp+0x40], r9
       mov      r9, r15
       mov      rdx, rbx
       mov      rcx, gword ptr [rbp-0x128]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       cmp      byte  ptr [rbp-0x78], 0
       jne      SHORT G_M000_IG98
       mov      rdx, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rdx+0x20]
       mov      eax, dword ptr [rbp-0x70]
       mov      dword ptr [rcx+0x40], eax
 
G_M000_IG98:                ;; offset=0x0AF4
       cmp      gword ptr [rbp-0x90], 0
       jne      G_M000_IG106
       mov      rax, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rax+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
       xor      r9d, r9d
       mov      dword ptr [rbp-0x44], r9d
       cmp      byte  ptr [rbp-0x78], 0
       jne      G_M000_IG105
       mov      rdx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rdx]
       mov      r9, gword ptr [r9+0x98]
       mov      r8d, dword ptr [rdx+0x10]
       cmp      r8d, dword ptr [r9+0x08]
       jae      G_M000_IG114
       shl      r8, 5
       lea      r8, bword ptr [r9+r8+0x10]
       mov      r14, gword ptr [rbp-0x88]
       mov      rdi, qword ptr [rbp-0x80]
       mov      r15d, dword ptr [r8+0x18]
       test     r15d, r15d
       jge      SHORT G_M000_IG99
       mov      gword ptr [rbp-0x110], r14
       mov      qword ptr [rbp-0x108], rdi
       lea      r9, [rbp-0x110]
       mov      rdx, rsi
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG112
 
G_M000_IG99:                ;; offset=0x0B86
       mov      rdx, bword ptr [rbp+0x10]
       lea      rsi, bword ptr [rdx+0x20]
       mov      ecx, dword ptr [r8+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG102
 
G_M000_IG100:                ;; offset=0x0B97
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jb       SHORT G_M000_IG102
 
G_M000_IG101:                ;; offset=0x0BA7
       mov      r13d, r15d
       jmp      SHORT G_M000_IG103
 
G_M000_IG102:                ;; offset=0x0BAC
       mov      r13d, dword ptr [r8+0x14]
 
G_M000_IG103:                ;; offset=0x0BB0
       cmp      r15d, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG104
       mov      rcx, rsi
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG104:                ;; offset=0x0BC2
       mov      rcx, gword ptr [rsi]
       cmp      r13d, dword ptr [rcx+0x08]
       jae      G_M000_IG114
       mov      eax, r13d
       shl      rax, 4
       lea      r13, bword ptr [rcx+rax+0x10]
       mov      rcx, r13
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r13+0x08], rdi
       mov      dword ptr [rsi+0x40], r15d
       jmp      G_M000_IG112
 
G_M000_IG105:                ;; offset=0x0BF3
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8d, dword ptr [rbp+0x30]
       mov      r9d, dword ptr [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteUnpackedCallReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,int)]
       jmp      G_M000_IG112
 
G_M000_IG106:                ;; offset=0x0C0E
       mov      rcx, gword ptr [rbp-0x90]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterExecutableSlots():this]
       mov      rdi, gword ptr [rbp-0x90]
       mov      rcx, gword ptr [rbp-0x128]
       mov      rcx, gword ptr [rcx+0x28]
       mov      rcx, gword ptr [rcx+0xA0]
       mov      r15, gword ptr [rcx+0x88]
       lea      rcx, bword ptr [rsi+0x30]
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       xor      rcx, rcx
       mov      gword ptr [rsi+0x40], rcx
       mov      r9d, dword ptr [rbp+0x30]
       mov      dword ptr [rsi+0xF0], r9d
 
G_M000_IG107:                ;; offset=0x0C5A
       mov      dword ptr [rsi+0xF4], ecx
       lea      rcx, bword ptr [rdi+0x20]
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [rdi+0x28]
       mov      rdx, r15
       call     CORINFO_HELP_ASSIGN_REF
       nop      
 
G_M000_IG108:                ;; offset=0x0C79
       mov      rdx, gword ptr [rbp-0x90]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      dword ptr [rbp-0x44], ecx
       jmp      SHORT G_M000_IG112
 
G_M000_IG109:                ;; offset=0x0C8F
       mov      rdx, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rdx+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
       xor      r9d, r9d
       mov      dword ptr [rbp-0x44], r9d
 
G_M000_IG110:                ;; offset=0x0CA9
       vmovdqu  xmm0, xmmword ptr [rbp-0x58]
       vmovdqu  xmmword ptr [rbp-0x110], xmm0
 
G_M000_IG111:                ;; offset=0x0CB6
       lea      r9, [rbp-0x110]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, rsi
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishDirectIntegerCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
 
G_M000_IG112:                ;; offset=0x0CCE
       mov      eax, 1
       jmp      SHORT G_M000_IG115
 
G_M000_IG113:                ;; offset=0x0CD5
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG114:                ;; offset=0x0CDC
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG115:                ;; offset=0x0CE2
       add      rsp, 344
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG116:                ;; offset=0x0CF6
       xor      eax, eax
 
G_M000_IG117:                ;; offset=0x0CF8
       add      rsp, 344
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG118:                ;; offset=0x0D0C
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG119:                ;; offset=0x0D12
       sub      rsp, 104
 
G_M000_IG120:                ;; offset=0x0D16
       mov      r14, gword ptr [rbp-0x90]
       mov      rcx, gword ptr [rbp-0x128]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      rdx, rax
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AbortPreparedCall(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.MemoryGovernor)]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG121:                ;; offset=0x0D47
       sub      rsp, 104
 
G_M000_IG122:                ;; offset=0x0D4B
       mov      rbx, rcx
       mov      rcx, bword ptr [rbp+0x10]
       cmp      byte  ptr [rcx], cl
       add      rcx, 32
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       lea      r8, [rbp-0x98]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG123
       mov      rcx, gword ptr [rbp-0x98]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG123:                ;; offset=0x0D8F
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG124:                ;; offset=0x0D95
       sub      rsp, 104
 
G_M000_IG125:                ;; offset=0x0D99
       cmp      dword ptr [rbp-0x44], 0
       je       SHORT G_M000_IG126
       mov      rdx, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rdx+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
 
G_M000_IG126:                ;; offset=0x0DB2
       nop      
 
G_M000_IG127:                ;; offset=0x0DB3
       add      rsp, 104
       ret      
 
G_M000_IG128:                ;; offset=0x0DB8
       sub      rsp, 104
 
G_M000_IG129:                ;; offset=0x0DBC
       mov      rcx, bword ptr [rbp+0x10]
       cmp      byte  ptr [rcx], cl
       add      rcx, 32
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG130:                ;; offset=0x0DD5
       sub      rsp, 104
 
G_M000_IG131:                ;; offset=0x0DD9
       mov      rcx, bword ptr [rbp+0x10]
       cmp      byte  ptr [rcx], cl
       add      rcx, 32
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 3570

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; partially interruptible
; No PGO data
; 1 inlinees with PGO data; 25 single block inlinees; 7 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 520
       lea      rbp, [rsp+0x240]
       xor      eax, eax
       mov      qword ptr [rbp-0x1D8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x1D0], xmm4
       mov      rax, -384
 
G_M000_IG22:                ;; offset=0x003A
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG22
       mov      qword ptr [rbp-0x40], rax
       mov      rbx, rcx
       mov      rdi, rdx
       mov      rsi, r9
       mov      r14, gword ptr [rbp+0x38]
       mov      r15, bword ptr [rbp+0x60]
 
G_M000_IG02:                ;; offset=0x0067
       mov      r13, bword ptr [r8]
       mov      r12d, dword ptr [r8+0x08]
       test     rsi, rsi
       sete     r8b
       movzx    r8, r8b
       movzx    rax, byte  ptr [rbp+0x48]
       mov      dword ptr [rbp-0x1DC], eax
       test     r8d, eax
       je       SHORT G_M000_IG06
 
G_M000_IG03:                ;; offset=0x0088
       cmp      r12d, 1
       jne      SHORT G_M000_IG06
       mov      r8, gword ptr [rbx+0x40]
       mov      rdx, gword ptr [r8+0x58]
       test     rdx, rdx
       je       SHORT G_M000_IG06
       mov      r8, gword ptr [rbx+0x28]
       cmp      byte  ptr [r8+0x105], 0
       jne      SHORT G_M000_IG06
 
G_M000_IG04:                ;; offset=0x00A9
       vmovdqu  xmm0, xmmword ptr [r13]
       vmovdqu  xmmword ptr [rbp-0x1A8], xmm0
 
G_M000_IG05:                ;; offset=0x00B7
       mov      bword ptr [rsp+0x20], r15
       lea      r8, [rbp-0x1A8]
       mov      rcx, rbx
       mov      r9, r14
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryReturnDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG15
 
G_M000_IG06:                ;; offset=0x00D7
       cmp      dword ptr [rbp-0x1DC], 0
       jne      G_M000_IG08
       test     rsi, rsi
       jne      G_M000_IG08
       mov      rcx, gword ptr [rbx+0x40]
       cmp      byte  ptr [rcx+0xF6], 0
       je       G_M000_IG08
       xor      ecx, ecx
       mov      qword ptr [r15], rcx
       mov      qword ptr [r15+0x08], rcx
       cmp      byte  ptr [rdi+0x34], 0
       je       G_M000_IG08
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x08]
       mov      rdx, gword ptr [rbx+0x40]
       cmp      ecx, dword ptr [rdx+0xD8]
       jne      G_M000_IG08
       mov      rcx, rbx
       mov      edx, r12d
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(int):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG08
       mov      rax, gword ptr [rbp+0x30]
       mov      rdx, gword ptr [rax+0xA0]
       mov      gword ptr [rbp-0x1E8], rdx
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG07
       mov      rcx, gword ptr [rbp-0x1E8]
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG07:                ;; offset=0x016D
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rbp-0x190], rbx
       mov      gword ptr [rbp-0x188], rdx
       mov      bword ptr [rbp-0x180], r13
       mov      dword ptr [rbp-0x178], r12d
       lea      rdx, [rbp-0x190]
       mov      rcx, rbx
       mov      r8, r14
       mov      r9, r15
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG15
 
G_M000_IG08:                ;; offset=0x01AB
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x138], ymm0
       vmovdqu  ymmword ptr [rbp-0x118], ymm0
       vmovdqu  ymmword ptr [rbp-0xF8], ymm0
       vmovdqu  ymmword ptr [rbp-0xD8], ymm0
       vmovdqu  ymmword ptr [rbp-0xB8], ymm0
       vmovdqu  ymmword ptr [rbp-0x98], ymm0
       vmovdqu  ymmword ptr [rbp-0x78], ymm0
       vmovdqu  ymmword ptr [rbp-0x58], ymm0
       mov      rcx, gword ptr [rbx+0x40]
       mov      r10d, dword ptr [rcx+0xE8]
       mov      dword ptr [rbp-0x194], r10d
       cmp      r10d, 16
       ja       G_M000_IG17
       cmp      dword ptr [rbp-0x1DC], 0
       jne      G_M000_IG11
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x08]
       cmp      ecx, r10d
       ja       G_M000_IG17
       lea      rdx, bword ptr [rbp-0x138]
       mov      bword ptr [rbp-0x1B8], rdx
       mov      dword ptr [rbp-0x1B0], ecx
       xor      rcx, rcx
       mov      bword ptr [rbp-0x1C8], rcx
 
G_M000_IG09:                ;; offset=0x0243
       mov      dword ptr [rbp-0x1C0], ecx
       mov      rcx, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rcx
       xor      ecx, ecx
       mov      dword ptr [rsp+0x28], ecx
       mov      gword ptr [rsp+0x30], rsi
       mov      gword ptr [rsp+0x38], rdi
       mov      bword ptr [rbp-0x1D8], r13
       mov      dword ptr [rbp-0x1D0], r12d
       lea      rcx, [rbp-0x1B8]
       lea      rdx, [rbp-0x1C8]
       lea      r9, [rbp-0x1D8]
       mov      qword ptr [rsp+0x40], r9
       mov      r9, rbx
       mov      r8, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG10:                ;; offset=0x0296
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x170], ymm0
       lea      rdx, bword ptr [rbp-0x138]
       mov      bword ptr [rbp-0x1B8], rdx
       mov      esi, dword ptr [rbp-0x194]
       mov      dword ptr [rbp-0x1B0], esi
       movzx    rdx, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x20], edx
       mov      rsi, bword ptr [rbp+0x50]
       mov      bword ptr [rsp+0x28], rsi
       mov      rsi, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x30], rsi
       mov      bword ptr [rsp+0x38], r15
       mov      rdi, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x40], rdi
       lea      rdx, [rbp-0x150]
       mov      qword ptr [rsp+0x48], rdx
       lea      rdx, [rbp-0x1B8]
       lea      r8, [rbp-0x170]
       mov      rcx, rbx
       mov      r9, r14
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       jmp      SHORT G_M000_IG16
 
G_M000_IG11:                ;; offset=0x030C
       xor      eax, eax
       test     rsi, rsi
       je       SHORT G_M000_IG12
       mov      eax, 1
       test     r10d, r10d
       je       G_M000_IG21
       mov      gword ptr [rbp-0x138], rsi
       xor      ecx, ecx
       mov      qword ptr [rbp-0x130], rcx
 
G_M000_IG12:                ;; offset=0x0331
       cmp      eax, r10d
       ja       SHORT G_M000_IG17
       lea      rcx, bword ptr [rbp-0x138]
       mov      edx, eax
       shl      rdx, 4
       add      rcx, rdx
       mov      edx, r10d
       sub      edx, eax
       cmp      r12d, edx
       ja       SHORT G_M000_IG20
 
G_M000_IG13:                ;; offset=0x0350
       mov      r8d, r12d
       shl      r8, 4
       cmp      r8, 0x4000
       ja       SHORT G_M000_IG19
 
G_M000_IG14:                ;; offset=0x0360
       mov      rdx, r13
       call     System.Buffer:BulkMoveWithWriteBarrierInternal(byref,byref,nuint)
       cmp      dword ptr [(reloc 0x7ffa2c8f2aa8)], 0
       je       G_M000_IG10
       jmp      SHORT G_M000_IG18
 
G_M000_IG15:                ;; offset=0x0377
       mov      rsi, bword ptr [rbp+0x58]
       mov      byte  ptr [rsi], 0
       xor      rax, rax
       mov      rdi, bword ptr [rbp+0x68]
       mov      gword ptr [rdi], rax
 
G_M000_IG16:                ;; offset=0x0387
       add      rsp, 520
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG17:                ;; offset=0x039B
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG18:                ;; offset=0x03A2
       call     CORINFO_HELP_POLL_GC
       jmp      G_M000_IG10
 
G_M000_IG19:                ;; offset=0x03AC
       mov      rdx, r13
       call     [System.Buffer:BulkMoveWithWriteBarrierBatch(byref,byref,nuint)]
       jmp      G_M000_IG10
 
G_M000_IG20:                ;; offset=0x03BA
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG21:                ;; offset=0x03C1
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 967

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref,byref):bool:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 33 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 200
       lea      rbp, [rsp+0x100]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x80], ymm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      rbx, rcx
       mov      rsi, rdx
       mov      edi, r8d
       mov      r14, r9
       mov      r15, bword ptr [rbp+0x30]
       mov      r13, bword ptr [rbp+0x38]
 
G_M000_IG02:                ;; offset=0x0047
       mov      rcx, 0x140F64016E8
       mov      rdx, gword ptr [rcx]
       mov      rcx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r15+0x08], rcx
       mov      byte  ptr [r13], 0
       mov      rcx, gword ptr [rbx+0x10]
       mov      rcx, gword ptr [rcx+0xA0]
       cmp      qword ptr [rcx+0x158], 8
       jge      G_M000_IG35
       test     r14, r14
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x0085
       mov      rcx, 0x7FF9CD0A0048
       cmp      qword ptr [r14], rcx
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x0094
       mov      r12, r14
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0099
       xor      r12, r12
 
G_M000_IG06:                ;; offset=0x009C
       cmp      byte  ptr [rsi+0x30], 0
       je       SHORT G_M000_IG08
       lea      rcx, bword ptr [rbx+0x48]
       cmp      edi, dword ptr [rcx+0x08]
       jae      G_M000_IG37
       mov      eax, edi
       shl      rax, 4
       mov      qword ptr [rbp-0x88], rax
       mov      rdx, rax
       add      rdx, bword ptr [rcx]
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       test     rax, rax
       je       SHORT G_M000_IG09
 
G_M000_IG07:                ;; offset=0x00D0
       mov      rcx, 0x7FF9CCF77AF8
       cmp      qword ptr [rax], rcx
       jne      SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x00DF
       xor      rax, rax
       jmp      SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x00E3
       lea      rcx, bword ptr [rbx+0x48]
       cmp      edi, dword ptr [rcx+0x08]
       jae      G_M000_IG37
       mov      rax, qword ptr [rbp-0x88]
       add      rax, bword ptr [rcx]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
 
G_M000_IG10:                ;; offset=0x0103
       test     r14, r14
       je       SHORT G_M000_IG15
 
G_M000_IG11:                ;; offset=0x0108
       mov      r9, 0x7FF9CD0C78F0
       cmp      qword ptr [r14], r9
       jne      SHORT G_M000_IG15
 
G_M000_IG12:                ;; offset=0x0117
       mov      r9, gword ptr [r14+0x10]
       test     r9, r9
       je       SHORT G_M000_IG15
 
G_M000_IG13:                ;; offset=0x0120
       mov      rcx, 0x7FF9CD0A0048
       cmp      qword ptr [r9], rcx
       jne      SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x012F
       mov      r12, r9
       mov      rax, gword ptr [r14+0x08]
 
G_M000_IG15:                ;; offset=0x0136
       test     r12, r12
       je       G_M000_IG35
       lea      r9, [rbp-0x40]
       mov      rcx, r12
       mov      rdx, rsi
       mov      gword ptr [rbp-0x90], rax
       mov      r8, rax
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this]
       test     eax, eax
       je       G_M000_IG35
       mov      rcx, gword ptr [rbx+0x10]
       mov      rdx, gword ptr [rsi+0x18]
       mov      rcx, gword ptr [rcx+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x44], 1
 
G_M000_IG16:                ;; offset=0x017F
       lea      rdx, bword ptr [rbx+0x48]
       cmp      byte  ptr [rsi+0x30], 0
       setne    r9b
       movzx    r9, r9b
       lea      r9d, [rdi+r9+0x01]
       mov      r14d, dword ptr [rsi+0x28]
       mov      ecx, r9d
       mov      r8d, r14d
       add      rcx, r8
       mov      r8d, dword ptr [rdx+0x08]
       cmp      rcx, r8
       ja       G_M000_IG29
       mov      eax, r9d
       shl      rax, 4
       add      rax, bword ptr [rdx]
       mov      bword ptr [rbp-0x98], rax
       cmp      byte  ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x01C5
       jmp      SHORT G_M000_IG19
 
G_M000_IG18:                ;; offset=0x01C7
       mov      bword ptr [rbp-0x70], rax
       mov      dword ptr [rbp-0x68], r14d
       mov      bword ptr [rsp+0x20], r15
       lea      rdx, [rbp-0x70]
       mov      r9, gword ptr [rsi+0x18]
       mov      rcx, r12
       mov      r8, gword ptr [rbp-0x90]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartSuppliedIntegerReturn(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG28
 
G_M000_IG19:                ;; offset=0x01F4
       cmp      byte  ptr [rsi+0x31], 0
       je       SHORT G_M000_IG20
       mov      r13d, 1
       jmp      SHORT G_M000_IG22
 
G_M000_IG20:                ;; offset=0x0202
       cmp      byte  ptr [rbx+0x40], 0
       jne      SHORT G_M000_IG21
       xor      r13d, r13d
       jmp      SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x020D
       movzx    r13, byte  ptr [rsi+0x32]
 
G_M000_IG22:                ;; offset=0x0212
       cmp      dword ptr [rsi+0x2C], 0
       je       SHORT G_M000_IG23
       mov      r8, gword ptr [rbx+0x08]
       cmp      dword ptr [r8+0xDC], edi
       jl       SHORT G_M000_IG25
 
G_M000_IG23:                ;; offset=0x0225
       mov      r8, gword ptr [rbx+0x10]
       mov      rcx, gword ptr [rsi+0x18]
       movzx    r9, byte  ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x98]
       mov      bword ptr [rbp-0x70], rdi
       mov      dword ptr [rbp-0x68], r14d
       mov      gword ptr [rsp+0x20], r8
       mov      gword ptr [rsp+0x28], rcx
       mov      dword ptr [rsp+0x30], r13d
       mov      dword ptr [rsp+0x38], r9d
       xor      r8, r8
       mov      bword ptr [rbp-0x80], r8
 
G_M000_IG24:                ;; offset=0x025C
       mov      dword ptr [rbp-0x78], r8d
       lea      r8, [rbp-0x60]
       mov      qword ptr [rsp+0x48], r8
       mov      bword ptr [rsp+0x50], r15
       lea      r8, [rbp-0x50]
       mov      qword ptr [rsp+0x58], r8
       lea      r8, [rbp-0x70]
       lea      rcx, [rbp-0x80]
       mov      qword ptr [rsp+0x40], rcx
       mov      rcx, r12
       mov      r9, gword ptr [rbp-0x90]
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       jmp      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x0299
       mov      r9, bword ptr [rbp-0x98]
       mov      bword ptr [rbp-0x70], r9
       mov      dword ptr [rbp-0x68], r14d
       mov      r14, gword ptr [rbp-0x90]
       mov      gword ptr [rsp+0x20], r14
       mov      dword ptr [rsp+0x28], edi
       mov      dword ptr [rsp+0x30], r13d
       movzx    r9, byte  ptr [rbp-0x40]
       mov      dword ptr [rsp+0x38], r9d
       mov      bword ptr [rsp+0x40], r15
       lea      r9, [rbp-0x50]
       mov      qword ptr [rsp+0x48], r9
       lea      r9, [rbp-0x70]
       mov      rdx, r12
       mov      r8, rsi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StartNativeFixedReturn(Lokad.Lython.Runtime.PyExecutableFunction,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,int,bool,bool,byref,byref):this]
 
G_M000_IG26:                ;; offset=0x02E8
       cmp      gword ptr [rbp-0x50], 0
       je       SHORT G_M000_IG30
       mov      rax, gword ptr [rbp-0x50]
       mov      gword ptr [rbx+0x18], rax
       mov      rax, gword ptr [r12+0x28]
       mov      rax, gword ptr [rax+0xA0]
       mov      rax, gword ptr [rax+0x88]
       mov      gword ptr [rbx+0x20], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x44], eax
 
G_M000_IG27:                ;; offset=0x0313
       mov      dword ptr [rbp-0x54], eax
       jmp      SHORT G_M000_IG32
 
G_M000_IG28:                ;; offset=0x0318
       mov      byte  ptr [r13], 1
       mov      dword ptr [rbp-0x54], 1
       jmp      SHORT G_M000_IG32
 
G_M000_IG29:                ;; offset=0x0326
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG30:                ;; offset=0x032D
       mov      rsi, gword ptr [rbx+0x10]
       mov      rcx, gword ptr [rsi+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
       mov      eax, 1
 
G_M000_IG31:                ;; offset=0x0345
       add      rsp, 200
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG32:                ;; offset=0x0359
       call     G_M000_IG38
       nop      
 
G_M000_IG33:                ;; offset=0x035F
       mov      eax, dword ptr [rbp-0x54]
 
G_M000_IG34:                ;; offset=0x0362
       add      rsp, 200
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG35:                ;; offset=0x0376
       xor      eax, eax
 
G_M000_IG36:                ;; offset=0x0378
       add      rsp, 200
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG37:                ;; offset=0x038C
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG38:                ;; offset=0x0392
       sub      rsp, 104
 
G_M000_IG39:                ;; offset=0x0396
       cmp      dword ptr [rbp-0x44], 0
       je       SHORT G_M000_IG40
       mov      rbx, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [rbx+0x10]
       mov      rcx, gword ptr [rsi+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
 
G_M000_IG40:                ;; offset=0x03B3
       nop      
 
G_M000_IG41:                ;; offset=0x03B4
       add      rsp, 104
       ret      
 
; Total bytes of code 953

