; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 103 single block inlinees; 34 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 328
       lea      rbp, [rsp+0x180]
       xor      eax, eax
       mov      qword ptr [rbp-0x118], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x110], xmm4
       mov      rax, -192
 
G_M000_IG135:                ;; offset=0x003A
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG135
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x28], r9
       mov      rsi, r8
       mov      rbx, r9
       mov      eax, dword ptr [rbp+0x30]
       mov      rdi, gword ptr [rbp+0x38]
       mov      r14, bword ptr [rbp+0x40]
 
G_M000_IG02:                ;; offset=0x0073
       xor      r8, r8
       mov      gword ptr [r14], r8
       test     rdi, rdi
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x007E
       mov      r8, 0x7FF9CD0A0048
       cmp      qword ptr [rdi], r8
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x008D
       mov      gword ptr [rbp-0x120], rdi
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0096
       xor      r8, r8
       mov      gword ptr [rbp-0x120], r8
 
G_M000_IG06:                ;; offset=0x00A0
       cmp      byte  ptr [rbx+0x30], 0
       je       SHORT G_M000_IG09
 
G_M000_IG07:                ;; offset=0x00A6
       mov      r8, gword ptr [rcx+0x20]
       cmp      eax, dword ptr [r8+0x08]
       jae      G_M000_IG121
       mov      r10d, eax
       shl      r10, 4
       lea      rcx, bword ptr [r8+r10+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9CD0A1B40
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       test     rax, rax
       je       SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x00DE
       mov      rcx, 0x7FF9CCF77AF8
       cmp      qword ptr [rax], rcx
       jne      SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x00ED
       mov      rcx, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rbp+0x30]
       xor      r15, r15
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x00F9
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rcx+0x20]
       mov      eax, dword ptr [rbp+0x30]
       cmp      eax, dword ptr [r8+0x08]
       jae      G_M000_IG121
       mov      r10d, eax
       shl      r10, 4
       lea      rcx, bword ptr [r8+r10+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9CD0A1B40
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r15, rax
 
G_M000_IG11:                ;; offset=0x0136
       test     rdi, rdi
       je       SHORT G_M000_IG16
 
G_M000_IG12:                ;; offset=0x013B
       mov      r8, 0x7FF9CD0C78F0
       cmp      qword ptr [rdi], r8
       jne      SHORT G_M000_IG16
 
G_M000_IG13:                ;; offset=0x014A
       mov      r8, gword ptr [rdi+0x10]
       test     r8, r8
       je       SHORT G_M000_IG16
 
G_M000_IG14:                ;; offset=0x0153
       mov      rdx, 0x7FF9CD0A0048
       cmp      qword ptr [r8], rdx
       jne      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x0162
       mov      gword ptr [rbp-0x120], r8
       mov      r15, gword ptr [rdi+0x08]
 
G_M000_IG16:                ;; offset=0x016D
       cmp      gword ptr [rbp-0x120], 0
       je       SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0177
       test     rsi, rsi
       jne      G_M000_IG82
 
G_M000_IG18:                ;; offset=0x0180
       cmp      byte  ptr [rbx+0x30], 0
       je       SHORT G_M000_IG19
       cmp      byte  ptr [rbx+0x34], 0
       jne      G_M000_IG32
 
G_M000_IG19:                ;; offset=0x0190
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       je       SHORT G_M000_IG20
       lea      rdx, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
       jmp      SHORT G_M000_IG21
 
G_M000_IG20:                ;; offset=0x01A7
       xor      rdx, rdx
       xor      r8d, r8d
 
G_M000_IG21:                ;; offset=0x01AC
       mov      bword ptr [rbp-0xF8], rdx
       mov      dword ptr [rbp-0xF0], r8d
       mov      rdx, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rdx
       test     rsi, rsi
       setne    r8b
       movzx    r8, r8b
       mov      dword ptr [rsp+0x28], r8d
       lea      r8, [rbp-0xB8]
       mov      qword ptr [rsp+0x30], r8
       lea      r8, [rbp-0xF8]
       mov      rdx, rdi
       mov      rcx, rbx
       mov      r9d, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeBuiltinFromSlots(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG30
       mov      rdx, gword ptr [rbp-0xB8]
       mov      rcx, 0x7FF9CCD66808
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       test     rdi, rdi
       jne      G_M000_IG28
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rcx]
       mov      r9, gword ptr [r9+0x98]
       mov      edx, dword ptr [rcx+0x10]
       cmp      edx, dword ptr [r9+0x08]
       jae      G_M000_IG31
       shl      rdx, 5
       lea      r8, bword ptr [r9+rdx+0x10]
       mov      rdi, gword ptr [rbp-0xB8]
       mov      r14, qword ptr [rbp-0xB0]
       mov      ebx, dword ptr [r8+0x18]
       test     ebx, ebx
       jge      SHORT G_M000_IG22
       mov      gword ptr [rbp-0x108], rdi
       mov      qword ptr [rbp-0x100], r14
       lea      r9, [rbp-0x108]
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      SHORT G_M000_IG29
 
G_M000_IG22:                ;; offset=0x027A
       lea      rsi, bword ptr [rcx+0x20]
       mov      edx, dword ptr [r8+0x1C]
       cmp      edx, 51
       ja       SHORT G_M000_IG25
 
G_M000_IG23:                ;; offset=0x0287
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x0297
       mov      r15d, ebx
       jmp      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x029C
       mov      r15d, dword ptr [r8+0x14]
 
G_M000_IG26:                ;; offset=0x02A0
       cmp      ebx, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG27
       mov      rcx, rsi
       mov      edx, ebx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG27:                ;; offset=0x02B0
       mov      rdx, gword ptr [rsi]
       cmp      r15d, dword ptr [rdx+0x08]
       jae      SHORT G_M000_IG31
       mov      eax, r15d
       shl      rax, 4
       lea      r15, bword ptr [rdx+rax+0x10]
       mov      rcx, r15
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r15+0x08], r14
       mov      dword ptr [rsi+0x40], ebx
       jmp      SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x02D9
       mov      rcx, bword ptr [rbp+0x10]
       add      rcx, 32
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, r14
       mov      rdx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG29:                ;; offset=0x02F5
       mov      eax, 1
       jmp      G_M000_IG118
 
G_M000_IG30:                ;; offset=0x02FF
       xor      eax, eax
       jmp      G_M000_IG118
 
G_M000_IG31:                ;; offset=0x0306
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG32:                ;; offset=0x030C
       test     rdi, rdi
       je       G_M000_IG119
 
G_M000_IG33:                ;; offset=0x0315
       mov      rcx, 0x7FF9CD0C7BF0
       cmp      qword ptr [rdi], rcx
       jne      G_M000_IG119
 
G_M000_IG34:                ;; offset=0x0328
       mov      r9, gword ptr [rbx+0x20]
       test     r9, r9
       je       SHORT G_M000_IG37
 
G_M000_IG35:                ;; offset=0x0331
       mov      rcx, 0x7FF9CD0C7EF8
       cmp      qword ptr [r9], rcx
       jne      SHORT G_M000_IG37
 
G_M000_IG36:                ;; offset=0x0340
       mov      gword ptr [rsp+0x20], rbx
       mov      eax, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x28], eax
       mov      gword ptr [rsp+0x30], rdi
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteTrimmedSplit(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableTrimmedSplit,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object):bool]
       test     eax, eax
       jne      G_M000_IG76
 
G_M000_IG37:                ;; offset=0x036A
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx]
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       je       SHORT G_M000_IG38
       lea      r9, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
       jmp      SHORT G_M000_IG39
 
G_M000_IG38:                ;; offset=0x0384
       xor      r9, r9
       xor      r8d, r8d
 
G_M000_IG39:                ;; offset=0x038A
       lea      rax, bword ptr [rcx+0x10]
       mov      r10, rsi
       test     r10, r10
       cmove    r10, gword ptr [rbp+0x18]
       mov      bword ptr [rbp-0x118], r9
       mov      dword ptr [rbp-0x110], r8d
       mov      gword ptr [rsp+0x20], rbx
       mov      r11d, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x28], r11d
       mov      gword ptr [rsp+0x30], r10
       lea      r8, [rbp-0xA0]
       mov      qword ptr [rsp+0x38], r8
       lea      r8, [rbp-0x118]
       mov      rcx, rdi
       mov      r9, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:TryConsumePrivateStringResult(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG69
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x20]
       mov      r11d, dword ptr [rbp+0x30]
       cmp      r11d, dword ptr [rax+0x08]
       jae      G_M000_IG81
       mov      edx, r11d
       shl      rdx, 4
       lea      rcx, bword ptr [rax+rdx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9CD0A1B40
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r14, rax
       mov      rcx, bword ptr [rbp+0x10]
       lea      rdx, bword ptr [rcx+0x20]
       cmp      byte  ptr [rbx+0x30], 0
       setne    al
       movzx    rax, al
       mov      r11d, dword ptr [rbp+0x30]
       lea      r15d, [r11+rax+0x01]
       mov      r13d, dword ptr [rbx+0x28]
       mov      rdx, gword ptr [rdx]
       test     rdx, rdx
       je       G_M000_IG77
       mov      eax, r15d
       mov      r8d, r13d
       add      rax, r8
       mov      r8d, dword ptr [rdx+0x08]
       cmp      rax, r8
       ja       G_M000_IG77
       mov      rax, rdx
       xor      r12, r12
       xor      r8d, r8d
       test     rax, rax
 
G_M000_IG40:                ;; offset=0x046C
       je       SHORT G_M000_IG43
       mov      rdx, qword ptr [rax]
       test     dword ptr [rdx], 0xFFFFFFFF80000000
       jne      SHORT G_M000_IG41
       lea      rdx, [rbp-0xE8]
       mov      rcx, rax
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x28]System.Buffers.MemoryManager`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:GetSpan():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this
       mov      r8d, dword ptr [rbp-0xE0]
       mov      r12, bword ptr [rbp-0xE8]
       mov      eax, r8d
       jmp      SHORT G_M000_IG42
 
G_M000_IG41:                ;; offset=0x04A0
       lea      r12, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
 
G_M000_IG42:                ;; offset=0x04A7
       and      r15d, 0x7FFFFFFF
       mov      edx, r15d
       mov      r8d, r13d
       add      r8, rdx
       mov      eax, eax
       cmp      r8, rax
       ja       G_M000_IG77
       shl      rdx, 4
       add      r12, rdx
       mov      dword ptr [rbp-0xD4], r13d
       mov      r8d, dword ptr [rbp-0xD4]
 
G_M000_IG43:                ;; offset=0x04D7
       cmp      dword ptr [rbx+0x2C], 0
       je       G_M000_IG47
       test     byte  ptr [(reloc 0x7ff9cd0c82b8)], 1
       je       G_M000_IG78
 
G_M000_IG44:                ;; offset=0x04EE
       mov      rdx, 0x1FEC0401F48
       cmp      rdi, gword ptr [rdx]
       jne      SHORT G_M000_IG47
       test     r14, r14
       je       SHORT G_M000_IG47
 
G_M000_IG45:                ;; offset=0x0502
       mov      rdx, 0x7FF9CCE2B5A0
       cmp      qword ptr [r14], rdx
       jne      SHORT G_M000_IG47
 
G_M000_IG46:                ;; offset=0x0511
       cmp      r8d, 2
       jg       SHORT G_M000_IG47
       mov      r11d, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x20], r11d
       mov      gword ptr [rsp+0x28], r14
       mov      bword ptr [rbp-0x118], r12
       mov      dword ptr [rbp-0xD4], r8d
       mov      dword ptr [rbp-0x110], r8d
       lea      rdx, [rbp-0x118]
       mov      qword ptr [rsp+0x30], rdx
       mov      rdx, rsi
       mov      r8, gword ptr [rbp+0x18]
       mov      r9, rbx
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSplitUnpack(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.Text.PyString,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):bool]
       test     eax, eax
       mov      r8d, dword ptr [rbp-0xD4]
       jne      G_M000_IG76
 
G_M000_IG47:                ;; offset=0x0569
       cmp      byte  ptr [rbx+0x33], 0
       jne      SHORT G_M000_IG49
 
G_M000_IG48:                ;; offset=0x056F
       mov      dword ptr [rbp-0xD4], r8d
       jmp      G_M000_IG61
 
G_M000_IG49:                ;; offset=0x057B
       cmp      r8d, 1
       je       SHORT G_M000_IG51
       mov      dword ptr [rbp-0xD4], r8d
       cmp      r8d, 2
       jne      G_M000_IG61
 
G_M000_IG50:                ;; offset=0x0592
       mov      r8d, dword ptr [rbp-0xD4]
 
G_M000_IG51:                ;; offset=0x0599
       test     byte  ptr [(reloc 0x7ff9cd0c82b8)], 1
       je       G_M000_IG79
 
G_M000_IG52:                ;; offset=0x05A6
       mov      rax, 0x1FEC0401F18
       cmp      rdi, gword ptr [rax]
       je       SHORT G_M000_IG54
 
G_M000_IG53:                ;; offset=0x05B5
       mov      dword ptr [rbp-0xD4], r8d
       jmp      G_M000_IG61
 
G_M000_IG54:                ;; offset=0x05C1
       test     r14, r14
       je       G_M000_IG60
 
G_M000_IG55:                ;; offset=0x05CA
       mov      rax, 0x7FF9CCEB8C08
       cmp      qword ptr [r14], rax
       jne      SHORT G_M000_IG59
 
G_M000_IG56:                ;; offset=0x05D9
       mov      dword ptr [rbp-0xD4], r8d
       test     r8d, r8d
       je       G_M000_IG81
       mov      r15, r12
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.PyDict:CanReadKeySynchronously(System.Object):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG61
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       test     rdx, rdx
       je       SHORT G_M000_IG58
 
G_M000_IG57:                ;; offset=0x0616
       mov      rcx, 0x7FF9CCE2B5A0
       cmp      qword ptr [rdx], rcx
       jne      G_M000_IG80
 
G_M000_IG58:                ;; offset=0x0629
       mov      gword ptr [rsp+0x28], rdx
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, rbx
       mov      r9d, dword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], r14
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryAccumulation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.PyDict,Lokad.Lython.Runtime.Text.PyString):bool]
       test     eax, eax
       je       SHORT G_M000_IG61
       jmp      G_M000_IG76
 
G_M000_IG59:                ;; offset=0x0651
       mov      dword ptr [rbp-0xD4], r8d
       jmp      SHORT G_M000_IG61
 
G_M000_IG60:                ;; offset=0x065A
       mov      dword ptr [rbp-0xD4], r8d
 
G_M000_IG61:                ;; offset=0x0661
       mov      r9, gword ptr [rbx+0x18]
       mov      rdx, rsi
       test     rdx, rdx
       cmove    rdx, gword ptr [rbp+0x18]
       mov      bword ptr [rbp-0xF8], r12
       mov      r8d, dword ptr [rbp-0xD4]
       mov      dword ptr [rbp-0xF0], r8d
       mov      gword ptr [rsp+0x20], rdx
       lea      r8, [rbp-0xA8]
       mov      qword ptr [rsp+0x28], r8
       lea      r8, [rbp-0xF8]
       mov      rdx, r14
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG68
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rcx]
       mov      r9, gword ptr [r9+0x98]
       mov      edx, dword ptr [rcx+0x10]
       cmp      edx, dword ptr [r9+0x08]
       jae      G_M000_IG81
       shl      rdx, 5
       lea      r8, bword ptr [r9+rdx+0x10]
       mov      rbx, gword ptr [rbp-0xA8]
       mov      edi, dword ptr [r8+0x18]
       test     edi, edi
       jge      SHORT G_M000_IG62
       mov      gword ptr [rbp-0x108], rbx
       xor      r9d, r9d
       mov      qword ptr [rbp-0x100], r9
       lea      r9, [rbp-0x108]
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG76
 
G_M000_IG62:                ;; offset=0x070A
       lea      rsi, bword ptr [rcx+0x20]
       mov      edx, dword ptr [r8+0x1C]
       cmp      edx, 51
       ja       SHORT G_M000_IG65
 
G_M000_IG63:                ;; offset=0x0717
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG65
 
G_M000_IG64:                ;; offset=0x0727
       mov      r14d, edi
       jmp      SHORT G_M000_IG66
 
G_M000_IG65:                ;; offset=0x072C
       mov      r14d, dword ptr [r8+0x14]
 
G_M000_IG66:                ;; offset=0x0730
       cmp      edi, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG67
       mov      rcx, rsi
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG67:                ;; offset=0x0740
       mov      rdx, gword ptr [rsi]
       cmp      r14d, dword ptr [rdx+0x08]
       jae      G_M000_IG81
       mov      eax, r14d
       shl      rax, 4
       lea      r14, bword ptr [rdx+rax+0x10]
       mov      rcx, r14
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       xor      eax, eax
       mov      qword ptr [r14+0x08], rax
       mov      dword ptr [rsi+0x40], edi
       jmp      G_M000_IG76
 
G_M000_IG68:                ;; offset=0x0772
       xor      eax, eax
       jmp      G_M000_IG118
 
G_M000_IG69:                ;; offset=0x0779
       mov      rcx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rcx]
       mov      r9, gword ptr [r9+0x98]
       mov      edx, dword ptr [rcx+0x10]
       cmp      edx, dword ptr [r9+0x08]
       jae      G_M000_IG81
       shl      rdx, 5
       lea      r8, bword ptr [r9+rdx+0x10]
       mov      rbx, gword ptr [rbp-0xA0]
       mov      rdi, qword ptr [rbp-0x98]
       mov      r14d, dword ptr [r8+0x18]
       test     r14d, r14d
       jge      SHORT G_M000_IG70
       mov      gword ptr [rbp-0x108], rbx
       mov      qword ptr [rbp-0x100], rdi
       lea      r9, [rbp-0x108]
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      SHORT G_M000_IG76
 
G_M000_IG70:                ;; offset=0x07D4
       lea      rsi, bword ptr [rcx+0x20]
       mov      edx, dword ptr [r8+0x1C]
       cmp      edx, 51
       ja       SHORT G_M000_IG73
 
G_M000_IG71:                ;; offset=0x07E1
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rdx
       jb       SHORT G_M000_IG73
 
G_M000_IG72:                ;; offset=0x07F1
       mov      r15d, r14d
       jmp      SHORT G_M000_IG74
 
G_M000_IG73:                ;; offset=0x07F6
       mov      r15d, dword ptr [r8+0x14]
 
G_M000_IG74:                ;; offset=0x07FA
       cmp      r14d, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG75
       mov      rcx, rsi
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG75:                ;; offset=0x080C
       mov      rdx, gword ptr [rsi]
       cmp      r15d, dword ptr [rdx+0x08]
       jae      G_M000_IG81
       mov      eax, r15d
       shl      rax, 4
       lea      r15, bword ptr [rdx+rax+0x10]
       mov      rcx, r15
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r15+0x08], rdi
       mov      dword ptr [rsi+0x40], r14d
 
G_M000_IG76:                ;; offset=0x0838
       mov      eax, 1
       jmp      G_M000_IG118
 
G_M000_IG77:                ;; offset=0x0842
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG78:                ;; offset=0x0849
       mov      dword ptr [rbp-0xD4], r8d
       mov      rcx, 0x7FF9CD0C8250
       call     CORINFO_HELP_GET_GCSTATIC_BASE
       mov      r8d, dword ptr [rbp-0xD4]
       jmp      G_M000_IG44
 
G_M000_IG79:                ;; offset=0x086B
       mov      dword ptr [rbp-0xD4], r8d
       mov      rcx, 0x7FF9CD0C8250
       call     CORINFO_HELP_GET_GCSTATIC_BASE
       mov      r8d, dword ptr [rbp-0xD4]
       jmp      G_M000_IG52
 
G_M000_IG80:                ;; offset=0x088D
       mov      rdx, rax
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG81:                ;; offset=0x0896
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG82:                ;; offset=0x089C
       lea      r9, [rbp-0x40]
       mov      rcx, gword ptr [rbp-0x120]
       mov      rdx, rbx
       mov      r8, r15
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this]
       test     eax, eax
       je       G_M000_IG119
       xor      ecx, ecx
       mov      dword ptr [rbp-0x44], ecx
 
G_M000_IG83:                ;; offset=0x08C0
       mov      rdx, gword ptr [rbx+0x18]
       mov      rax, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rax+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x44], 1
       mov      rdi, gword ptr [rbx+0x18]
       mov      rax, gword ptr [rbp+0x18]
       mov      r13, gword ptr [rax+0xA0]
       cmp      byte  ptr [r13], r13b
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG84
       mov      rcx, r13
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG84:                ;; offset=0x090A
       mov      rcx, bword ptr [rbp+0x10]
       lea      rdx, bword ptr [rcx+0x20]
       cmp      byte  ptr [rbx+0x30], 0
       setne    al
       movzx    rax, al
       mov      r11d, dword ptr [rbp+0x30]
       lea      edi, [r11+rax+0x01]
       mov      r13d, dword ptr [rbx+0x28]
       mov      rdx, gword ptr [rdx]
       test     rdx, rdx
       je       SHORT G_M000_IG85
       mov      eax, edi
       mov      r8d, r13d
       add      rax, r8
       mov      r8d, dword ptr [rdx+0x08]
       cmp      rax, r8
       ja       G_M000_IG116
       mov      rax, rdx
       jmp      SHORT G_M000_IG86
 
G_M000_IG85:                ;; offset=0x094B
       mov      eax, edi
       or       eax, r13d
       jne      G_M000_IG116
       xor      rax, rax
       xor      edi, edi
       xor      r13d, r13d
 
G_M000_IG86:                ;; offset=0x095D
       xor      r12, r12
       xor      r8d, r8d
       test     rax, rax
       je       SHORT G_M000_IG89
       mov      rdx, qword ptr [rax]
       test     dword ptr [rdx], 0xFFFFFFFF80000000
       jne      SHORT G_M000_IG87
       lea      rdx, [rbp-0xD0]
       mov      rcx, rax
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x28]System.Buffers.MemoryManager`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:GetSpan():System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this
       mov      r8d, dword ptr [rbp-0xC8]
       mov      r12, bword ptr [rbp-0xD0]
       mov      eax, r8d
       jmp      SHORT G_M000_IG88
 
G_M000_IG87:                ;; offset=0x099A
       lea      r12, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
 
G_M000_IG88:                ;; offset=0x09A1
       and      edi, 0x7FFFFFFF
       mov      r8d, edi
       mov      edx, r13d
       add      rdx, r8
       mov      eax, eax
       cmp      rdx, rax
       ja       G_M000_IG116
       shl      r8, 4
       add      r12, r8
       mov      eax, r13d
       mov      r8d, eax
 
G_M000_IG89:                ;; offset=0x09C8
       mov      bword ptr [rbp-0x118], r12
       mov      dword ptr [rbp-0xBC], r8d
       mov      dword ptr [rbp-0x110], r8d
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       movzx    rdx, byte  ptr [rbp-0x40]
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp-0x58]
       mov      qword ptr [rsp+0x30], rdx
       lea      rdx, [rbp-0x60]
       mov      qword ptr [rsp+0x38], rdx
       lea      r8, [rbp-0x118]
       mov      rdx, rbx
       mov      rcx, gword ptr [rbp-0x120]
       mov      r9, r15
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryCompleteNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG106
       lea      rcx, [rbp-0x78]
       mov      qword ptr [rsp+0x20], rcx
       lea      rcx, [rbp-0x70]
       mov      rdx, bword ptr [rbp+0x10]
       mov      r8, rbx
       mov      r9d, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PrepareUnpackedCallReturn(byref,Lokad.Lython.Frontend.ExecutableCallSite,int,byref):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      r8, gword ptr [rbx+0x18]
       cmp      byte  ptr [rbx+0x31], 0
       je       SHORT G_M000_IG90
       mov      r9d, 1
       jmp      SHORT G_M000_IG92
 
G_M000_IG90:                ;; offset=0x0A52
       mov      rdx, bword ptr [rbp+0x10]
       cmp      byte  ptr [rdx+0x14], 0
       jne      SHORT G_M000_IG91
       xor      r9d, r9d
       jmp      SHORT G_M000_IG92
 
G_M000_IG91:                ;; offset=0x0A61
       movzx    r9, byte  ptr [rbx+0x32]
 
G_M000_IG92:                ;; offset=0x0A66
       mov      bword ptr [rbp-0x118], r12
       mov      r13d, dword ptr [rbp-0xBC]
       mov      dword ptr [rbp-0x110], r13d
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      gword ptr [rsp+0x28], r8
       mov      dword ptr [rsp+0x30], r9d
       movzx    r9, byte  ptr [rbp-0x40]
 
G_M000_IG93:                ;; offset=0x0A93
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
 
G_M000_IG94:                ;; offset=0x0AA0
       lea      r8, [rbp-0x80]
       mov      qword ptr [rsp+0x48], r8
       lea      r8, [rbp-0x58]
       mov      qword ptr [rsp+0x50], r8
       lea      r8, [rbp-0x88]
       mov      qword ptr [rsp+0x58], r8
       lea      r8, [rbp-0x118]
       mov      dword ptr [rsp+0x38], r9d
       lea      r9, [rbp-0xF8]
       mov      qword ptr [rsp+0x40], r9
       mov      r9, r15
       mov      rdx, rbx
       mov      rcx, gword ptr [rbp-0x120]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       cmp      byte  ptr [rbp-0x80], 0
       jne      SHORT G_M000_IG95
       mov      rdx, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rdx+0x20]
       mov      eax, dword ptr [rbp-0x78]
       mov      dword ptr [rcx+0x40], eax
 
G_M000_IG95:                ;; offset=0x0AFD
       cmp      gword ptr [rbp-0x88], 0
       jne      G_M000_IG103
       mov      rax, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rax+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
       xor      r9d, r9d
       mov      dword ptr [rbp-0x44], r9d
       cmp      byte  ptr [rbp-0x80], 0
       jne      G_M000_IG102
       mov      rdx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rdx]
       mov      r9, gword ptr [r9+0x98]
       mov      r8d, dword ptr [rdx+0x10]
       cmp      r8d, dword ptr [r9+0x08]
       jae      G_M000_IG117
       shl      r8, 5
       lea      r8, bword ptr [r9+r8+0x10]
       mov      r14, gword ptr [rbp-0x58]
       mov      rdi, qword ptr [rbp-0x50]
       mov      r15d, dword ptr [r8+0x18]
       test     r15d, r15d
       jge      SHORT G_M000_IG96
       mov      gword ptr [rbp-0x108], r14
       mov      qword ptr [rbp-0x100], rdi
       lea      r9, [rbp-0x108]
       mov      rdx, rsi
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG115
 
G_M000_IG96:                ;; offset=0x0B8C
       mov      rdx, bword ptr [rbp+0x10]
       lea      rsi, bword ptr [rdx+0x20]
       mov      ecx, dword ptr [r8+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG99
 
G_M000_IG97:                ;; offset=0x0B9D
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jb       SHORT G_M000_IG99
 
G_M000_IG98:                ;; offset=0x0BAD
       mov      r13d, r15d
       jmp      SHORT G_M000_IG100
 
G_M000_IG99:                ;; offset=0x0BB2
       mov      r13d, dword ptr [r8+0x14]
 
G_M000_IG100:                ;; offset=0x0BB6
       cmp      r15d, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG101
       mov      rcx, rsi
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG101:                ;; offset=0x0BC8
       mov      rcx, gword ptr [rsi]
       cmp      r13d, dword ptr [rcx+0x08]
       jae      G_M000_IG117
       mov      eax, r13d
       shl      rax, 4
       lea      r13, bword ptr [rcx+rax+0x10]
       mov      rcx, r13
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r13+0x08], rdi
       mov      dword ptr [rsi+0x40], r15d
       jmp      G_M000_IG115
 
G_M000_IG102:                ;; offset=0x0BF9
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8d, dword ptr [rbp+0x30]
       mov      r9d, dword ptr [rbp-0x68]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteUnpackedCallReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,int)]
       jmp      G_M000_IG115
 
G_M000_IG103:                ;; offset=0x0C14
       mov      rcx, gword ptr [rbp-0x88]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterExecutableSlots():this]
       mov      rdi, gword ptr [rbp-0x88]
       mov      rcx, gword ptr [rbp-0x120]
       mov      rcx, gword ptr [rcx+0x28]
       mov      rcx, gword ptr [rcx+0xA0]
       mov      r15, gword ptr [rcx+0x88]
       lea      rcx, bword ptr [rsi+0x30]
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       xor      rcx, rcx
       mov      gword ptr [rsi+0x40], rcx
       mov      r9d, dword ptr [rbp+0x30]
       mov      dword ptr [rsi+0xF0], r9d
 
G_M000_IG104:                ;; offset=0x0C60
       mov      dword ptr [rsi+0xF4], ecx
       lea      rcx, bword ptr [rdi+0x20]
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       lea      rcx, bword ptr [rdi+0x28]
       mov      rdx, r15
       call     CORINFO_HELP_ASSIGN_REF
       nop      
 
G_M000_IG105:                ;; offset=0x0C7F
       mov      rdx, gword ptr [rbp-0x88]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      dword ptr [rbp-0x44], ecx
       jmp      G_M000_IG115
 
G_M000_IG106:                ;; offset=0x0C98
       mov      rdx, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rdx+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
       xor      r9d, r9d
       mov      dword ptr [rbp-0x44], r9d
       cmp      byte  ptr [rbp-0x60], 0
       jne      G_M000_IG113
       mov      rdx, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rdx]
       mov      r9, gword ptr [r9+0x98]
       mov      r8d, dword ptr [rdx+0x10]
       cmp      r8d, dword ptr [r9+0x08]
       jae      G_M000_IG117
       shl      r8, 5
       lea      r8, bword ptr [r9+r8+0x10]
       mov      rdi, gword ptr [rbp-0x58]
       mov      r14, qword ptr [rbp-0x50]
       mov      r15d, dword ptr [r8+0x18]
       test     r15d, r15d
       jge      SHORT G_M000_IG107
       mov      gword ptr [rbp-0x108], rdi
       mov      qword ptr [rbp-0x100], r14
       lea      r9, [rbp-0x108]
       mov      rdx, rsi
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG115
 
G_M000_IG107:                ;; offset=0x0D19
       mov      rdx, bword ptr [rbp+0x10]
       lea      rsi, bword ptr [rdx+0x20]
       mov      ecx, dword ptr [r8+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG110
 
G_M000_IG108:                ;; offset=0x0D2A
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jb       SHORT G_M000_IG110
 
G_M000_IG109:                ;; offset=0x0D3A
       mov      r13d, r15d
       jmp      SHORT G_M000_IG111
 
G_M000_IG110:                ;; offset=0x0D3F
       mov      r13d, dword ptr [r8+0x14]
 
G_M000_IG111:                ;; offset=0x0D43
       cmp      r15d, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG112
       mov      rcx, rsi
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG112:                ;; offset=0x0D55
       mov      rcx, gword ptr [rsi]
       cmp      r13d, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG117
       mov      eax, r13d
       shl      rax, 4
       lea      r13, bword ptr [rcx+rax+0x10]
       mov      rcx, r13
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r13+0x08], r14
       mov      dword ptr [rsi+0x40], r15d
       jmp      SHORT G_M000_IG115
 
G_M000_IG113:                ;; offset=0x0D7F
       vmovdqu  xmm0, xmmword ptr [rbp-0x58]
       vmovdqu  xmmword ptr [rbp-0x108], xmm0
 
G_M000_IG114:                ;; offset=0x0D8C
       lea      r9, [rbp-0x108]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, rsi
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishDirectIntegerCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
 
G_M000_IG115:                ;; offset=0x0DA4
       mov      eax, 1
       jmp      SHORT G_M000_IG118
 
G_M000_IG116:                ;; offset=0x0DAB
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG117:                ;; offset=0x0DB2
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG118:                ;; offset=0x0DB8
       add      rsp, 328
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG119:                ;; offset=0x0DCC
       xor      eax, eax
 
G_M000_IG120:                ;; offset=0x0DCE
       add      rsp, 328
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG121:                ;; offset=0x0DE2
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG122:                ;; offset=0x0DE8
       sub      rsp, 104
 
G_M000_IG123:                ;; offset=0x0DEC
       mov      r14, gword ptr [rbp-0x88]
       mov      rcx, gword ptr [rbp-0x120]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:get_DefinitionContext():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      rdx, rax
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AbortPreparedCall(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.MemoryGovernor)]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG124:                ;; offset=0x0E1D
       sub      rsp, 104
 
G_M000_IG125:                ;; offset=0x0E21
       mov      rbx, rcx
       mov      rcx, bword ptr [rbp+0x10]
       cmp      byte  ptr [rcx], cl
       add      rcx, 32
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       lea      r8, [rbp-0x90]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG126
       mov      rcx, gword ptr [rbp-0x90]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG126:                ;; offset=0x0E65
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG127:                ;; offset=0x0E6B
       sub      rsp, 104
 
G_M000_IG128:                ;; offset=0x0E6F
       cmp      dword ptr [rbp-0x44], 0
       je       SHORT G_M000_IG129
       mov      rdx, gword ptr [rbp+0x18]
       mov      rcx, gword ptr [rdx+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
 
G_M000_IG129:                ;; offset=0x0E88
       nop      
 
G_M000_IG130:                ;; offset=0x0E89
       add      rsp, 104
       ret      
 
G_M000_IG131:                ;; offset=0x0E8E
       sub      rsp, 104
 
G_M000_IG132:                ;; offset=0x0E92
       mov      rcx, bword ptr [rbp+0x10]
       cmp      byte  ptr [rcx], cl
       add      rcx, 32
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG133:                ;; offset=0x0EAB
       sub      rsp, 104
 
G_M000_IG134:                ;; offset=0x0EAF
       mov      rcx, bword ptr [rbp+0x10]
       cmp      byte  ptr [rcx], cl
       add      rcx, 32
       mov      edx, dword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 3784

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:TryCompleteNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref,byref):bool:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; partially interruptible
; No PGO data
; 0 inlinees with PGO data; 17 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 104
       xor      eax, eax
       mov      qword ptr [rsp+0x28], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x30], ymm4
       vmovdqa  xmmword ptr [rsp+0x50], xmm4
       mov      qword ptr [rsp+0x60], rax
       mov      rbx, rcx
       mov      rsi, rdx
       mov      rdi, r9
       mov      rbp, bword ptr [rsp+0xE0]
       mov      r14, bword ptr [rsp+0xE8]
 
G_M000_IG02:                ;; offset=0x0045
       mov      r15, bword ptr [r8]
       mov      r13d, dword ptr [r8+0x08]
       xor      edx, edx
       mov      qword ptr [rbp], rdx
       mov      qword ptr [rbp+0x08], rdx
       movzx    r12, byte  ptr [rsp+0xD8]
       test     r12d, r12d
       jne      SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0064
       xor      eax, eax
       jmp      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x0068
       mov      bword ptr [rsp+0x38], r15
       mov      dword ptr [rsp+0x40], r13d
       mov      bword ptr [rsp+0x20], rbp
       lea      rdx, [rsp+0x38]
       mov      r9, gword ptr [rsi+0x18]
       mov      rcx, rbx
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartSuppliedIntegerReturn(System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.LythonSourceSpan,byref):bool:this]
 
G_M000_IG05:                ;; offset=0x008C
       mov      byte  ptr [r14], al
       cmp      byte  ptr [r14], 0
       jne      G_M000_IG17
 
G_M000_IG06:                ;; offset=0x0099
       test     rdi, rdi
       jne      SHORT G_M000_IG10
       test     r12d, r12d
       je       SHORT G_M000_IG09
       cmp      r13d, 1
       jne      SHORT G_M000_IG10
       mov      r8, gword ptr [rbx+0x40]
       mov      rdx, gword ptr [r8+0x58]
       test     rdx, rdx
       je       SHORT G_M000_IG10
       mov      r8, gword ptr [rbx+0x28]
       cmp      byte  ptr [r8+0x105], 0
       jne      SHORT G_M000_IG10
 
G_M000_IG07:                ;; offset=0x00C4
       vmovdqu  xmm0, xmmword ptr [r15]
       vmovdqu  xmmword ptr [rsp+0x28], xmm0
 
G_M000_IG08:                ;; offset=0x00CF
       mov      bword ptr [rsp+0x20], rbp
       lea      r8, [rsp+0x28]
       mov      r9, gword ptr [rsi+0x18]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryReturnDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       jmp      G_M000_IG15
 
G_M000_IG09:                ;; offset=0x00EB
       mov      rax, gword ptr [rbx+0x40]
       cmp      byte  ptr [rax+0xF6], 0
       jne      SHORT G_M000_IG12
 
G_M000_IG10:                ;; offset=0x00F8
       xor      eax, eax
 
G_M000_IG11:                ;; offset=0x00FA
       add      rsp, 104
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG12:                ;; offset=0x010B
       mov      rdi, gword ptr [rsi+0x18]
       xor      ecx, ecx
       mov      qword ptr [rbp], rcx
       mov      qword ptr [rbp+0x08], rcx
       cmp      byte  ptr [rsi+0x34], 0
       je       G_M000_IG14
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x08]
       mov      rdx, gword ptr [rbx+0x40]
       cmp      ecx, dword ptr [rdx+0xD8]
       jne      SHORT G_M000_IG14
       mov      rcx, rbx
       mov      edx, r13d
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:HasPreparedOmittedArguments(int):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG14
       mov      rsi, gword ptr [rsp+0xD0]
       mov      rsi, gword ptr [rsi+0xA0]
       cmp      byte  ptr [rsi], sil
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG13
       mov      rcx, rsi
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG13:                ;; offset=0x0175
       mov      rdx, gword ptr [rbx+0x58]
       mov      gword ptr [rsp+0x48], rbx
       mov      gword ptr [rsp+0x50], rdx
       mov      bword ptr [rsp+0x58], r15
       mov      dword ptr [rsp+0x60], r13d
       lea      rdx, [rsp+0x48]
       mov      rcx, rbx
       mov      r8, rdi
       mov      r9, rbp
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryStartDirectIntegerReturn[Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands](Lokad.Lython.Runtime.LythonRuntime+DefaultIntegerOperands,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       jmp      SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x01A3
       xor      eax, eax
 
G_M000_IG15:                ;; offset=0x01A5
       movzx    rax, al
 
G_M000_IG16:                ;; offset=0x01A8
       add      rsp, 104
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG17:                ;; offset=0x01B9
       mov      eax, 1
 
G_M000_IG18:                ;; offset=0x01BE
       add      rsp, 104
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
; Total bytes of code 463

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; partially interruptible
; No PGO data
; 1 inlinees with PGO data; 11 single block inlinees; 5 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 440
       lea      rbp, [rsp+0x1E0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x190], xmm4
       mov      rax, -336
 
G_M000_IG16:                ;; offset=0x002D
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG16
       mov      qword ptr [rbp-0x30], rax
       mov      rbx, rcx
       mov      rdi, gword ptr [rbp+0x38]
       mov      rsi, bword ptr [rbp+0x50]
 
G_M000_IG02:                ;; offset=0x0054
       mov      rax, bword ptr [r8]
       mov      r14d, dword ptr [r8+0x08]
       mov      rcx, gword ptr [rbx+0x40]
       mov      r15d, dword ptr [rcx+0xE8]
       cmp      r15d, 16
       ja       G_M000_IG11
       cmp      byte  ptr [rbp+0x48], 0
       jne      G_M000_IG07
 
G_M000_IG03:                ;; offset=0x007A
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x08]
       cmp      ecx, r15d
       ja       G_M000_IG11
       lea      r8, bword ptr [rbp-0x128]
       mov      bword ptr [rbp-0x170], r8
       mov      dword ptr [rbp-0x168], ecx
       xor      rcx, rcx
       mov      bword ptr [rbp-0x180], rcx
 
G_M000_IG04:                ;; offset=0x00AB
       mov      dword ptr [rbp-0x178], ecx
       mov      rcx, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rcx
       xor      ecx, ecx
       mov      dword ptr [rsp+0x28], ecx
       mov      gword ptr [rsp+0x30], r9
       mov      gword ptr [rsp+0x38], rdx
       mov      bword ptr [rbp-0x190], rax
       mov      dword ptr [rbp-0x188], r14d
       lea      rcx, [rbp-0x170]
       lea      rdx, [rbp-0x180]
       lea      r9, [rbp-0x190]
       mov      qword ptr [rsp+0x40], r9
       mov      r9, rbx
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG05:                ;; offset=0x00FE
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x160], ymm0
       lea      rdx, bword ptr [rbp-0x128]
       mov      bword ptr [rbp-0x170], rdx
       mov      dword ptr [rbp-0x168], r15d
       movzx    rdx, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x20], edx
       mov      bword ptr [rsp+0x28], rsi
       mov      rsi, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x30], rsi
       mov      rsi, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x38], rsi
       mov      rsi, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x40], rsi
       lea      rdx, [rbp-0x140]
       mov      qword ptr [rsp+0x48], rdx
       lea      rdx, [rbp-0x170]
       lea      r8, [rbp-0x160]
       mov      rcx, rbx
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG06:                ;; offset=0x016E
       add      rsp, 440
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x017E
       xor      ecx, ecx
       test     r9, r9
       je       SHORT G_M000_IG08
       mov      ecx, 1
       test     r15d, r15d
       je       G_M000_IG15
       mov      gword ptr [rbp-0x128], r9
       xor      edx, edx
       mov      qword ptr [rbp-0x120], rdx
 
G_M000_IG08:                ;; offset=0x01A3
       cmp      ecx, r15d
       ja       SHORT G_M000_IG11
       lea      rdx, bword ptr [rbp-0x128]
       mov      r8d, ecx
       shl      r8, 4
       add      r8, rdx
       mov      edx, r15d
       sub      edx, ecx
       cmp      r14d, edx
       ja       SHORT G_M000_IG14
 
G_M000_IG09:                ;; offset=0x01C3
       mov      ecx, r14d
       shl      rcx, 4
       mov      r10, rcx
       cmp      r10, 0x4000
       ja       SHORT G_M000_IG13
 
G_M000_IG10:                ;; offset=0x01D6
       mov      rcx, r8
       mov      rdx, rax
       mov      r8, r10
       call     System.Buffer:BulkMoveWithWriteBarrierInternal(byref,byref,nuint)
       cmp      dword ptr [(reloc 0x7ffa2c8f2aa8)], 0
       je       G_M000_IG05
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x01F3
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG12:                ;; offset=0x01FA
       call     CORINFO_HELP_POLL_GC
       jmp      G_M000_IG05
 
G_M000_IG13:                ;; offset=0x0204
       mov      rcx, r8
       mov      rdx, rax
       mov      r8, r10
       call     [System.Buffer:BulkMoveWithWriteBarrierBatch(byref,byref,nuint)]
       jmp      G_M000_IG05
 
G_M000_IG14:                ;; offset=0x0218
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG15:                ;; offset=0x021F
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 549

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref,byref):bool:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 32 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 200
       lea      rbp, [rsp+0x100]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x80], ymm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      rbx, rcx
       mov      rsi, rdx
       mov      edi, r8d
       mov      r14, r9
       mov      r15, bword ptr [rbp+0x30]
       mov      r13, bword ptr [rbp+0x38]
 
G_M000_IG02:                ;; offset=0x0047
       mov      rcx, 0x1FEC04016E8
       mov      rdx, gword ptr [rcx]
       mov      rcx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r15+0x08], rcx
       mov      byte  ptr [r13], 0
       mov      rcx, gword ptr [rbx+0x10]
       mov      rcx, gword ptr [rcx+0xA0]
       cmp      qword ptr [rcx+0x158], 8
       jge      G_M000_IG32
       test     r14, r14
       je       SHORT G_M000_IG05
 
G_M000_IG03:                ;; offset=0x0085
       mov      rcx, 0x7FF9CD0A0048
       cmp      qword ptr [r14], rcx
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x0094
       mov      r12, r14
       jmp      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0099
       xor      r12, r12
 
G_M000_IG06:                ;; offset=0x009C
       cmp      byte  ptr [rsi+0x30], 0
       je       SHORT G_M000_IG08
       lea      rcx, bword ptr [rbx+0x48]
       cmp      edi, dword ptr [rcx+0x08]
       jae      G_M000_IG34
       mov      eax, edi
       shl      rax, 4
       mov      qword ptr [rbp-0x88], rax
       mov      rdx, rax
       add      rdx, bword ptr [rcx]
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       test     rax, rax
       je       SHORT G_M000_IG09
 
G_M000_IG07:                ;; offset=0x00D0
       mov      rcx, 0x7FF9CCF77AF8
       cmp      qword ptr [rax], rcx
       jne      SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x00DF
       xor      rax, rax
       jmp      SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x00E3
       lea      rcx, bword ptr [rbx+0x48]
       cmp      edi, dword ptr [rcx+0x08]
       jae      G_M000_IG34
       mov      rax, qword ptr [rbp-0x88]
       add      rax, bword ptr [rcx]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
 
G_M000_IG10:                ;; offset=0x0103
       test     r14, r14
       je       SHORT G_M000_IG15
 
G_M000_IG11:                ;; offset=0x0108
       mov      r9, 0x7FF9CD0C78F0
       cmp      qword ptr [r14], r9
       jne      SHORT G_M000_IG15
 
G_M000_IG12:                ;; offset=0x0117
       mov      r9, gword ptr [r14+0x10]
       test     r9, r9
       je       SHORT G_M000_IG15
 
G_M000_IG13:                ;; offset=0x0120
       mov      rcx, 0x7FF9CD0A0048
       cmp      qword ptr [r9], rcx
       jne      SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x012F
       mov      r12, r9
       mov      rax, gword ptr [r14+0x08]
 
G_M000_IG15:                ;; offset=0x0136
       test     r12, r12
       je       G_M000_IG32
       lea      r9, [rbp-0x40]
       mov      rcx, r12
       mov      rdx, rsi
       mov      gword ptr [rbp-0x90], rax
       mov      r8, rax
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this]
       test     eax, eax
       je       G_M000_IG32
       mov      rcx, gword ptr [rbx+0x10]
       mov      rdx, gword ptr [rsi+0x18]
       mov      rcx, gword ptr [rcx+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       mov      dword ptr [rbp-0x44], 1
 
G_M000_IG16:                ;; offset=0x017F
       lea      r8, bword ptr [rbx+0x48]
       cmp      byte  ptr [rsi+0x30], 0
       setne    dl
       movzx    rdx, dl
       lea      edx, [rdi+rdx+0x01]
       mov      r14d, dword ptr [rsi+0x28]
       mov      ecx, edx
       mov      r9d, r14d
       add      rcx, r9
       mov      r9d, dword ptr [r8+0x08]
       cmp      rcx, r9
       ja       G_M000_IG26
       mov      eax, edx
       shl      rax, 4
       add      rax, bword ptr [r8]
       mov      bword ptr [rbp-0x98], rax
       mov      bword ptr [rbp-0x70], rax
       mov      dword ptr [rbp-0x68], r14d
       mov      r8, gword ptr [rbx+0x10]
       mov      gword ptr [rsp+0x20], r8
       movzx    r8, byte  ptr [rbp-0x40]
       mov      dword ptr [rsp+0x28], r8d
       mov      bword ptr [rsp+0x30], r15
       mov      bword ptr [rsp+0x38], r13
       lea      r8, [rbp-0x70]
       mov      rdx, rsi
       mov      rcx, r12
       mov      r9, gword ptr [rbp-0x90]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryCompleteNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG25
       cmp      byte  ptr [rsi+0x31], 0
       je       SHORT G_M000_IG17
       mov      r13d, 1
       jmp      SHORT G_M000_IG19
 
G_M000_IG17:                ;; offset=0x020C
       cmp      byte  ptr [rbx+0x40], 0
       jne      SHORT G_M000_IG18
       xor      r13d, r13d
       jmp      SHORT G_M000_IG19
 
G_M000_IG18:                ;; offset=0x0217
       movzx    r13, byte  ptr [rsi+0x32]
 
G_M000_IG19:                ;; offset=0x021C
       cmp      dword ptr [rsi+0x2C], 0
       je       SHORT G_M000_IG20
       mov      r8, gword ptr [rbx+0x08]
       cmp      dword ptr [r8+0xDC], edi
       jl       SHORT G_M000_IG22
 
G_M000_IG20:                ;; offset=0x022F
       mov      r8, gword ptr [rbx+0x10]
       mov      rcx, gword ptr [rsi+0x18]
       movzx    r9, byte  ptr [rbp-0x40]
       mov      rdi, bword ptr [rbp-0x98]
       mov      bword ptr [rbp-0x70], rdi
       mov      dword ptr [rbp-0x68], r14d
       mov      gword ptr [rsp+0x20], r8
       mov      gword ptr [rsp+0x28], rcx
       mov      dword ptr [rsp+0x30], r13d
       mov      dword ptr [rsp+0x38], r9d
       xor      r8, r8
       mov      bword ptr [rbp-0x80], r8
 
G_M000_IG21:                ;; offset=0x0266
       mov      dword ptr [rbp-0x78], r8d
       lea      r8, [rbp-0x60]
       mov      qword ptr [rsp+0x48], r8
       mov      bword ptr [rsp+0x50], r15
       lea      r8, [rbp-0x50]
       mov      qword ptr [rsp+0x58], r8
       lea      r8, [rbp-0x70]
       lea      rcx, [rbp-0x80]
       mov      qword ptr [rsp+0x40], rcx
       mov      rcx, r12
       mov      r9, gword ptr [rbp-0x90]
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this]
       jmp      SHORT G_M000_IG23
 
G_M000_IG22:                ;; offset=0x02A3
       mov      r9, bword ptr [rbp-0x98]
       mov      bword ptr [rbp-0x70], r9
       mov      dword ptr [rbp-0x68], r14d
       mov      r14, gword ptr [rbp-0x90]
       mov      gword ptr [rsp+0x20], r14
       mov      dword ptr [rsp+0x28], edi
       mov      dword ptr [rsp+0x30], r13d
       movzx    r9, byte  ptr [rbp-0x40]
       mov      dword ptr [rsp+0x38], r9d
       mov      bword ptr [rsp+0x40], r15
       lea      r9, [rbp-0x50]
       mov      qword ptr [rsp+0x48], r9
       lea      r9, [rbp-0x70]
       mov      rdx, r12
       mov      r8, rsi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StartNativeFixedReturn(Lokad.Lython.Runtime.PyExecutableFunction,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,int,bool,bool,byref,byref):this]
 
G_M000_IG23:                ;; offset=0x02F2
       cmp      gword ptr [rbp-0x50], 0
       je       SHORT G_M000_IG27
       mov      rax, gword ptr [rbp-0x50]
       mov      gword ptr [rbx+0x18], rax
       mov      rax, gword ptr [r12+0x28]
       mov      rax, gword ptr [rax+0xA0]
       mov      rax, gword ptr [rax+0x88]
       mov      gword ptr [rbx+0x20], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x44], eax
 
G_M000_IG24:                ;; offset=0x031D
       mov      dword ptr [rbp-0x54], eax
       jmp      SHORT G_M000_IG29
 
G_M000_IG25:                ;; offset=0x0322
       mov      dword ptr [rbp-0x54], 1
       jmp      SHORT G_M000_IG29
 
G_M000_IG26:                ;; offset=0x032B
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG27:                ;; offset=0x0332
       mov      rsi, gword ptr [rbx+0x10]
       mov      rcx, gword ptr [rsi+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
       mov      eax, 1
 
G_M000_IG28:                ;; offset=0x034A
       add      rsp, 200
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG29:                ;; offset=0x035E
       call     G_M000_IG35
       nop      
 
G_M000_IG30:                ;; offset=0x0364
       mov      eax, dword ptr [rbp-0x54]
 
G_M000_IG31:                ;; offset=0x0367
       add      rsp, 200
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG32:                ;; offset=0x037B
       xor      eax, eax
 
G_M000_IG33:                ;; offset=0x037D
       add      rsp, 200
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG34:                ;; offset=0x0391
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG35:                ;; offset=0x0397
       sub      rsp, 104
 
G_M000_IG36:                ;; offset=0x039B
       cmp      dword ptr [rbp-0x44], 0
       je       SHORT G_M000_IG37
       mov      rbx, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [rbx+0x10]
       mov      rcx, gword ptr [rsi+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
 
G_M000_IG37:                ;; offset=0x03B8
       nop      
 
G_M000_IG38:                ;; offset=0x03B9
       add      rsp, 104
       ret      
 
; Total bytes of code 958

