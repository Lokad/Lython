from pathlib import Path
import ast
import gzip
import hashlib
import json
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
text_read = lab.with_name('decoded-ascii-file-values-20261124')
donor = lab.with_name('regex-wrapper-cache-20261124')
core = 'Lokad.Lython.dll'


def write(path, body):
    path.write_text(body, encoding='utf-8', newline='\n')


def save(path, value):
    write(path, json.dumps(value, indent=2) + '\n')


def script(path, contents):
    compile(contents, str(path), 'exec')
    write(path, contents)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def tracked(path):
    return subprocess.check_output(['git', 'show', 'origin/master:benchmarks/results/'+path], cwd=repo)


prepare = (text_read/'prepare.py').read_text(encoding='utf-8')
prepare = prepare.replace("agent-worktrees/decoded-ascii-file-values-20261124", "agent-worktrees/regex-wrapper-cache-20261124")
prepare = prepare.replace("lab.with_name('regex-flag-continuations-20261124')", "lab.with_name('regex-wrapper-cache-20261124')")
prepare = prepare.replace("'f01360b7f'", "'840eba2a7'")
start = prepare.index('original=lab.with_name')
end = prepare.index("assert len(catalog['cases'])==5", start)
prepare = prepare[:start] + """original=lab.with_name('native-callable-definition-20261124')/'comparison'
representative=comparison/'representative.json'
catalog=read(original/'representative.json')
nested=read(lab.with_name('closed-definition-return-20261123')/'representative.json')
postponed,=[case for case in nested['cases'] if case['id']=='scripts.annotated-rule-closures.nested-factories.postponed']
catalog['cases']=[case for case in catalog['cases'] if case['id']!='scripts.annotated-rule-closures']
catalog['cases'].insert(0,postponed)
""" + prepare[end:]
prepare = prepare.replace('B1580 reuse existing immutable ASCII values in decoded text reads',
                          'B1582 complete proven native calls before workspace setup')
script(lab/'prepare.py', prepare)

stage = (text_read/'stage.py').read_text(encoding='utf-8')
start = stage.index('replicas=[]')
end = stage.index('original=donor/', start)
stage = stage[:start] + """replicas=json.loads((lab/'verified-replicas.json').read_text(encoding='utf-8'))
""" + stage[end:]
stage = stage.replace("root='decoded-ascii-file-values-b1580-20261124'",
                      "root='native-completed-call-workspace-b1582-20261124'")
stage = stage.replace(".replace('b1578-','b1580-')", ".replace('b1578-','b1582-')")
stage = stage.replace("'b1580-decoded-ascii-file-values'", "'b1582-native-completed-call-workspace'")
stage = stage.replace("start=launch.index('  retired=[]')", """launch=launch.replace('minimum_active = 10 * 1024 * 1024','minimum_active = 8 * 1024 * 1024')
launch=launch.replace('A 10 MiB','An 8 MiB')
start=launch.index('  retired=[]')""")
script(lab/'stage.py', stage)

groups = [
    ('2026-11-24-decoded-ascii-file-values','decoded-ascii-file-values-b1580-20261124','reference'),
    ('2026-11-24-regex-wrapper-cache','regex-wrapper-cache-b1581-20261124','candidate'),
]
replicas = []
for result, remote, role in groups:
    archive = f'{result}/{role}-core.dll.gz'
    binary = sha(gzip.decompress(tracked(archive)))
    receipt = json.loads(tracked(f'{result}/terminal-status.json'))['receipt']
    assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
    assert sha(tracked(f'{result}/observations.tar.xz')) == receipt['archiveSHA256']
    assert json.loads(tracked(f'{result}/identity.json'))['imageFiles'][role][core] == binary
    replicas.append(dict(sha256=binary, coreArchive=archive, aliases=[
        dict(path=f'{remote}/{role}/{core}', observationSHA256=receipt['archiveSHA256'], source=result)]))
save(lab/'verified-replicas.json', replicas)
