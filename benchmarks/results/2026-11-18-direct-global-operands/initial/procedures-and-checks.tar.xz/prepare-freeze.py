from pathlib import Path
r=Path(__file__).resolve().parent;prior=r.parent/'bulk-trim-r506'
s=(prior/'freeze.py').read_text(encoding='utf-8')
s=s.replace("work=repo/'.git/agent-worktrees/bulk-trim-r506';prior=r.parent/'generator-facts-r503'","work=repo/'.git/agent-worktrees/direct-global-r509';prior=r.parent/'bulk-trim-r506'")
a=s.index("inputs=json.loads(");b=s.index('\nhashes=',a)
s=s[:a]+'''inputs=json.loads((prior/'delivery/inputs.json').read_text(encoding='utf-8'))
names=list(inputs['inputs'])+['src/Lokad.Lython/Runtime/LythonRuntime.Executable.Operands.cs','tests/Lokad.Lython.PublicApi.Tests/DirectGlobalOperandTests.cs'];assert len(names)==2388'''+s[b:]
s=s.replace('assert len(production)==1,production','assert len(production)==10,production')
s=s.replace("referenceSource='Qualified62786960 production/frozen5ae019db; generator field facts'","referenceSource='Qualified0691d64f production/frozen65fcf7d0; shared bulk trim'")
a=s.index("candidateSource='");b=s.index("',imageFiles=",a)
s=s[:a]+"candidateSource='PrivateR509 on7664a04d: adjacent globals use the existing constant/name immediate union; remove producer instructions/temp transport, centralize native/resumable/numeric reads and preserve cold source spans. No cache/owner/opcode/policy. Seven public ordering/protocol/realIO/cancellation/retained-result/reuse cases. Only core DLL changes in measured image"+s[b:]
s=s.replace('productionFiles=585','productionFiles=586')
(r/'freeze.py').write_text(s,encoding='utf-8',newline='\n');print('Prepared copied32file image freeze,2388inputs/586production and actual-worker goldens/reuse.')
