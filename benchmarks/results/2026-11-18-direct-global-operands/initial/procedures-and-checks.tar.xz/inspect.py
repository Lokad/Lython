from pathlib import Path
import hashlib,json,os,subprocess
r=Path(__file__).resolve().parent;prior=r.parent/'activation-source-r504';project=r/'inspect';project.mkdir(exist_ok=True)
if(r/'reference-inspect.log').exists()and not(r/'first-invalid-run-option.log').exists():(r/'first-invalid-run-option.log').write_bytes((r/'reference-inspect.log').read_bytes())
(project/'Program.cs').write_bytes((prior/'inspect/Program.cs').read_bytes())
s=(prior/'inspect/inspect.csproj').read_text(encoding='utf-8');a=s.index('<HintPath>');b=s.index('</HintPath>',a);s=s[:a]+'<HintPath>$(InspectionCorePath)'+s[b:];(project/'inspect.csproj').write_text(s,encoding='utf-8',newline='\n')
d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))
for role in ['reference','candidate']:
 core=r/'frozen'/role/'Lokad.Lython.dll';cmd=[str(d),'build',str(project/'inspect.csproj'),'-c','Release','-f','net11.0','--no-incremental','-p:InspectionCorePath='+str(core)]
 with(r/(role+'-inspect-build.log')).open('w',encoding='utf-8')as log:p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
 assert p.returncode==0,(r/(role+'-inspect-build.log')).read_text(encoding='utf-8')
 cmd=[str(d),str(project/'bin/Release/net11.0/Lokad.Lython.WhiteBox.Tests.dll'),str(r/'catalog.json'),str(r/(role+'-ir.json'))]
 with(r/(role+'-inspect.log')).open('w',encoding='utf-8')as log:p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
 assert p.returncode==0,(r/(role+'-inspect.log')).read_text(encoding='utf-8')
 v=json.loads((r/(role+'-ir.json')).read_text(encoding='utf-8-sig'));assert v['CoreSha256']==f['imageFiles'][role]['Lokad.Lython.dll']
 for w in v['Workloads']:
  for c in w['Codes']:
   if c['IsFunctionScope']:print(role,w['Id'],c['Name'],'slots',c['ValueStorageCapacity'],'opcodes',c['OpcodeCounts'],flush=True)
