from pathlib import Path
import json,subprocess
r=Path(__file__).resolve().parent
code='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
b=Path('/home/lokad/lython-bench-checks')
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 assert not any(os.path.ismount(p)for p in b.glob('*/guest-fixtures'))
 groups={};ineligible=[]
 for p in b.glob('*/*/Lokad.Lython.dll'):
  m=p.lstat()
  if p.resolve()!=p or not stat.S_ISREG(m.st_mode)or m.st_uid!=os.getuid():
   ineligible.append(dict(path=str(p.relative_to(b)),uid=m.st_uid,regular=stat.S_ISREG(m.st_mode),resolved=str(p.resolve())));continue
  k=(m.st_dev,m.st_ino)
  if k not in groups:groups[k]=dict(sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=m.st_size,allocatedBytes=m.st_blocks*512,links=m.st_nlink,paths=[])
  groups[k]['paths'].append(str(p.relative_to(b)))
 print(json.dumps(dict(readOnly=True,idleLease=True,freeBytes=shutil.disk_usage(b).free,coreImages=list(groups.values()),ineligiblePreserved=ineligible)))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);assert p.returncode==0,p.stdout+p.stderr
(r/'space-inspection.json').write_text(p.stdout,encoding='utf-8');v=json.loads(p.stdout);print(json.dumps(dict(freeBytes=v['freeBytes'],coreImages=[dict(sha256=x['sha256'],bytes=x['bytes'],allocated=x['allocatedBytes'],aliases=len(x['paths']),example=x['paths'][0])for x in v['coreImages']]),indent=2))
