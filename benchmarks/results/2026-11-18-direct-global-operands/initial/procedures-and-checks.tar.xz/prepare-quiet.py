from pathlib import Path
import ast,hashlib,json,re,shutil,tarfile
r=Path(__file__).resolve().parent;prior=r.parent/'bulk-trim-r506';old=prior/'quiet';q=r/'quiet';q.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))
assert all(sha(r/'frozen'/role/n)==h for role,files in f['imageFiles'].items()for n,h in files.items())
identity=dict(sourceRevision='Qualified0691d64f production/65fcf7d0 versus privateR509/'+f['imageFiles']['candidate']['Lokad.Lython.dll'][:8],purpose='Direct adjacent global operands eliminate producer instructions/temp publication; current live lookup and native/resumable paths remain. Complete floating warm/fresh, text/call controls. Untimed cbfe source condition retained; no predicted gain.',coreSHA256={role:f['imageFiles']['candidate'if role.startswith('candidate')else'reference']['Lokad.Lython.dll']for role in ['reference','reference-control','candidate','candidate-control']},imageFiles=f['imageFiles'],auxiliaryFiles={n:h for n,h in f['imageFiles']['reference'].items()if n!='Lokad.Lython.dll'},sourceInputsArchiveSHA256=sha(r/'candidate-sources.tar.xz'),productionFiles=586,catalogSHA256=f['catalogSHA256'],normalAdapterPin='0.4.0',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.numeric-squared-error.floating.large','warm'],['scripts.numeric-squared-error.floating.large','compile-run'],['scripts.text-normalization.large','warm'],['calls.positional.large','warm']]
s=(old/'collect.py').read_text(encoding='utf-8');a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==4 and all(case in cases for case,lane in jobs)\n'+s[b:];s=re.sub(r'time.monotonic\(\)-started < \d+','time.monotonic()-started < 210',s);(q/'collect.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'archive-owned.py').read_text(encoding='utf-8');s=re.sub(r"len\(raw\['jobs'\]\)==\d+","len(raw['jobs'])==4",s);s=re.sub(r'jobs=\d+','jobs=4',s);(q/'archive-owned.py').write_text(s,encoding='utf-8',newline='\n')
remote='/home/lokad/lython-bench-checks/direct-globals-b933-20261118';unit='lython-b933-direct-globals-20261118';previous=json.loads((old/'config.json').read_text(encoding='utf-8'))
(q/'run.sh').write_text((old/'run.sh').read_text(encoding='utf-8').replace(previous['root'],remote),encoding='utf-8',newline='\n')
(q/'candidate').mkdir();shutil.copyfile(r/'frozen/candidate/Lokad.Lython.dll',q/'candidate/Lokad.Lython.dll');names=['collect.py','archive-owned.py','run.sh','identity.json','candidate/Lokad.Lython.dll']
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for n in names:a.add(q/n,arcname=n)
c=dict(root=remote,unit=unit,source=previous['root'],sourceRole='candidate',sourceFiles=f['imageFiles']['reference'],sourceCatalogSHA256=f['catalogSHA256'],catalogSHA256=f['catalogSHA256'],identity=identity,retireGroups=json.loads((r/'retirement-candidates.json').read_text(encoding='utf-8'))['proofs'],payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha(q/'payload.tgz'),unpackedBytes=sum((q/n).stat().st_size for n in names))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:];s=re.sub(r'RuntimeMaxSec=\d+','RuntimeMaxSec=270',s);s=re.sub('lython-b[0-9]+-fixtures','lython-b933-fixtures',s);(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(prior/'launch.py').read_text(encoding='utf-8');s=re.sub(r'seconds=\d+','seconds=230',s).replace('before165seconds','before230seconds').replace('Two-job bulk-trim source pair','Four-job direct-global source pair');(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'retrieve.py').read_text(encoding='utf-8');s=re.sub(r"\['jobs'\]==\d+","['jobs']==4",s).replace('B930','B933');(q/'retrieve.py').write_text(s,encoding='utf-8',newline='\n')
s=(prior/'summarize.py').read_text(encoding='utf-8');s=re.sub(r"len\(raw\['jobs'\]\)==\d+","len(raw['jobs'])==4",s);(r/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
for p in list(q.glob('*.py'))+[r/'launch.py',r/'summarize.py']:ast.parse(p.read_text(encoding='utf-8'))
actual=next(ast.literal_eval(n.value)for n in ast.parse((q/'collect.py').read_text(encoding='utf-8')).body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='jobs'for t in n.targets));assert actual==jobs
assert "['jobs']==4"in(q/'retrieve.py').read_text(encoding='utf-8')and "len(raw['jobs'])==4"in(r/'summarize.py').read_text(encoding='utf-8')and "len(raw['jobs'])==4"in(q/'archive-owned.py').read_text(encoding='utf-8')
print(json.dumps(dict(prepared=True,jobs=4,cap=210,serviceCap=270,unpackedBytes=c['unpackedBytes'],exactArchivedSupersededCoreBytes=sum(p['bytes']for p in c['retireGroups']),current65fcPreserved=True)))
