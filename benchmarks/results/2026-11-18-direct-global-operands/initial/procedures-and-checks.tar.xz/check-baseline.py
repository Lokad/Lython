from pathlib import Path
import hashlib,json,os,shutil,subprocess,xml.etree.ElementTree as E
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');work=repo/'.git/agent-worktrees/direct-global-r509';prior=repo/'.git/agent-worktrees/bulk-trim-r506';f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe')
env=os.environ.copy();env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH'];rows=[]
for tfm in ['net11.0','net10.0']:
 baseline=prior/'src/Lokad.Lython/bin/Release'/tfm/'Lokad.Lython.dll'
 if tfm=='net11.0':assert hashlib.sha256(baseline.read_bytes()).hexdigest()==f['imageFiles']['reference']['Lokad.Lython.dll']
 image=r/'baseline-public'/tfm;shutil.copytree(work/'tests/Lokad.Lython.PublicApi.Tests/bin/Release'/tfm,image,copy_function=shutil.copyfile);shutil.copyfile(baseline,image/'Lokad.Lython.dll')
 out=r/'baseline-checks'/tfm;out.mkdir(parents=True)
 with(out/'test.log').open('w',encoding='utf-8')as log:p=subprocess.run([str(d),'vstest',str(image/'Lokad.Lython.PublicApi.Tests.dll'),'--TestCaseFilter:FullyQualifiedName~DirectGlobalOperand&Category!=Stress','--Logger:trx;LogFileName=baseline.trx','--ResultsDirectory:'+str(out)],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
 trx=E.parse(out/'baseline.trx');counts=trx.find('{http://microsoft.com/schemas/VisualStudio/TeamTest/2010}ResultSummary/{http://microsoft.com/schemas/VisualStudio/TeamTest/2010}Counters').attrib
 rows.append(dict(framework=tfm,exitCode=p.returncode,coreSHA256=hashlib.sha256(baseline.read_bytes()).hexdigest(),counts=counts));(r/'baseline-checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
 assert p.returncode==0 and counts['passed']=='7',(out/'test.log').read_text(encoding='utf-8');print(tfm,'7existing-semantic cases pass unchanged qualified source.',flush=True)
