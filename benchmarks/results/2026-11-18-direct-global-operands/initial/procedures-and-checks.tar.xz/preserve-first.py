from pathlib import Path
import gzip,json,shutil
r=Path(__file__).resolve().parent;out=r/'before-probe-refinement';out.mkdir()
for n in ['frozen','candidate-sources.tar.xz','prototype.patch.gz','candidate-preflight.json','candidate-preflight.log','candidate-allocation.json','candidate-allocation.log','candidate-ir.json','reference-ir.json']:
 p=r/n
 if p.is_dir():p.rename(out/n)
 else:shutil.move(str(p),str(out/n))
(out/'reason.json').write_text(json.dumps(dict(measured=False,core='cbfe82db',reason='Before timing, source review found the integer-index probe resolves a global receiver before rejecting a string field key, forcing duplicate global resolution in the ordinary input path. Probe a key without reporting missing-name errors first; generic read still selects the first operand error. Preserve first source/build/goldens/allocation condition; no elapsed measurement to relabel.'),indent=2)+'\n',encoding='utf-8')
print('First untimed source cbfe preserved before required probe-read refinement.')
