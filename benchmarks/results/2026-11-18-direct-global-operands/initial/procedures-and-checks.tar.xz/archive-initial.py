from pathlib import Path
import gzip,json,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-18-direct-global-operands/initial';out.mkdir(parents=True,exist_ok=False)
for n in ['summary.json','allocation-summary.json','candidate-allocation.json','candidate-preflight.json','candidate-sources.tar.xz','prototype.patch.gz','checks.json','baseline-checks.json','candidate-ir.json','reference-ir.json']:
 shutil.copyfile(r/n,out/n)
for n in ['observations.tgz','archive-receipt.json','terminal-status.json']:shutil.copyfile(r/'quiet'/n,out/n)
shutil.copyfile(r/'frozen/identity.json',out/'identity.json')
(out/'candidate-core.dll.gz').write_bytes(gzip.compress((r/'frozen/candidate/Lokad.Lython.dll').read_bytes(),mtime=0))
with tarfile.open(out/'procedures-and-checks.tar.xz','w:xz')as a:
 for p in sorted(r.rglob('*')):
  if not p.is_file()or any(x in p.relative_to(r).parts for x in ['frozen','retrieved','baseline-public','bin','obj']):continue
  if p.suffix not in ['.py','.json','.log','.sh','.cs','.csproj','.trx']:continue
  a.add(p,arcname=p.relative_to(r).as_posix())
 # Original cbfe source condition is untimed, with goldens/allocation but no
 # source-pair elapsed claim. Include its immutable source/patch explicitly.
 for n in ['candidate-sources.tar.xz','prototype.patch.gz']:
  a.add(r/'before-probe-refinement'/n,arcname='before-probe-refinement/'+n)
(out/'README.md').write_text('''# Direct global operands: initial measured source

R509/B933, private9e184cc7 on7664a04d versus qualified0691d64f/core65fcf7d0.
Adjacent global reads join constants in the existing complemented source-index
space; names resolve live, with cold original spans. No guest marker/cache/owner/
opcode/policy. Remove producer instructions/publication/retirement, centralize
native/resumable/numeric readers and preserve constant-only aggregate proofs.
The numeric-index probe rejects inapplicable keys before unused receiver resolution.

Actual11/10 each400internal/113public focused pass; seven new ordering/protocol/
real-I/O/cancellation/retained-result/reuse cases also pass unchanged qualified
source. Six exact-worker goldens/allocation/reuse pass. Static actual-core IR
removes two floating-gen loads(15→13instructions), storage remains9slots. Allocation
and peaks effectively flat; do not claim storage capacity or allocation reduction.

Quiet F4as_v7/Ubuntu24.04.4/.NET11RC3, normalGC/tiering, fourjobs154.96s/six-second
warmups/five rotated rounds/two processes per source:

| Complete script/phase | Elapsed change | Wider CPU change | Ref/candidate spread |
| --- | ---: | ---: | ---: |
| Floating warm |−17.40..−4.15%|−16.57..−3.25%|14.20/1.62%|
| Floating compile-to-result |+3.22..+6.89%|+3.12..+8.89%|0.04/3.52%|
| Text warm |−1.51..−0.20%|−1.35..+0.59%|0.72/0.60%|
| Positional calls warm |+1.07..+3.21%|+1.22..+3.29%|1.43/0.67%|

Keep private/unpromoted: warm reference instability limits magnitude, while fresh
and calls are adverse. Removing genuine VM work does not establish CPU improvement.
One changed-source refinement will remove immediate-pool interface dispatch and
the extra generic probe layer while retaining the same semantics. No unchanged
retiming, permanent design veto, rigid threshold or source-condition subtraction.

Warm includes Run, mediated RAM I/O, goldens and prior-result cleanup; fresh adds
compile/compiled-owner disposal. Startup/reset/protocol/final cache teardown
excluded, processCPU wider. All32image hashes/catalog/quiet/join/archive/localSHA/
RAM teardown pass. Exact archived old5e7core aliases alone retire; current65fc/
catalogs/toolchains/unmatched evidence preserved,254/252MiBguards unchanged.

Original static-type-rejected fixture, missing sparse workflow input and invalid
inspector CLI option are retained; these are local preparation errors, not runtime
or elapsed failures. Untimedcbfe is preserved before probe-read correction. Final
source was nonincrementally rebuilt before checks/freezing; all measured files
copied/hashed, not hard-linked to mutable build outputs.

[Summary](summary.json),[raw](observations.tgz),[identity](identity.json),
[source](candidate-sources.tar.xz),[patch](prototype.patch.gz),
[checks/failures/procedures](procedures-and-checks.tar.xz).
No production promotion/full qualification/publication; whole-script objective active.
''',encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as a:a.write('\nR509/B933 [initial direct-global operands](results/2026-11-18-direct-global-operands/initial/README.md),9e184cc7 versus65fc: eliminate2floating-gen producers(15→13ops), slots9/allocation/peaksflat; both targets400internal/113public,7newcasesalso baseline,sixgoldens/reuse pass. Fourjobs154.96s warmfloating−17.40..−4.15%with14.20%reference spread; fresh+3.22..+6.89%/calls+1.07..+3.21%adverse, textCPUstraddleszero. Keep unpromoted; one changed-source immediate-pool/extra probe-layer consolidation selected, no unchanged retiming/source subtraction/permanent veto. Localfixture/sparse/CLI errors and untimedcbfe condition retained; all users joined/SHAarchive/guards pass, current65fc preserved.\n')
print('Initial measured source and all adverse results archived; not promoted, one coherent pool-read refinement selected.')
