from pathlib import Path
import json
r=Path(__file__).resolve().parent
d=json.loads((r/'delivery/dispatch.json').read_text(encoding='utf-8'))
s=(r.parent/'bulk-trim-r506/finish-delivery.py').read_text(encoding='utf-8')
s=s.replace('44211082563',str(d['run'])).replace('0691d64fb2e74ff693f405191dd502ef93a89238',d['head'])
s=s.replace('2386','2388').replace('585','586').replace('18039','18046')
s=s.replace('all586ProductionInputsMatchMeasured65fcf7d0','all586ProductionInputsMatchMeasuredAbab8760')
s=s.replace('benchmarks/results/2026-11-18-bulk-trim/delivery','benchmarks/results/2026-11-18-direct-global-operands/refined/delivery')
(r/'finish-delivery.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared 16-summary / 2,388-input / 586-production verifier; awaits actual GREEN.')
