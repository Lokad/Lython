set -eu
root=/home/lokad/lython-bench-checks/direct-globals-refined-b934-20261118
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
