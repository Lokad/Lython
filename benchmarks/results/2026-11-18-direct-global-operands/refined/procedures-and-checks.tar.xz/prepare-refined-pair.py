from pathlib import Path
import json
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython')
s=(r/'prove-space.py').read_text(encoding='utf-8')
s=s.replace('2026-11-17-completed-instruction-runner/reference-core.dll.gz','2026-11-18-direct-global-operands/initial/candidate-core.dll.gz').replace('5e7058a313bf77859192c6bbabcf97f33b657561586fe1f7709bc281a2d28658','9e184cc74662e089690ffd304fb429721115b5d1344747080b266f3332d0233b')
(r/'prove-refined-space.py').write_text(s,encoding='utf-8',newline='\n')
s=(r/'prepare-quiet.py').read_text(encoding='utf-8').replace('direct-globals-b933-20261118','direct-globals-refined-b934-20261118').replace('lython-b933-direct-globals-20261118','lython-b934-direct-globals-20261118').replace('lython-b933-fixtures','lython-b934-fixtures').replace("'lython-b933-fixtures'","'lython-b934-fixtures'").replace("'lython-b933-fixtures'","'lython-b934-fixtures'").replace('B933','B934')
s=s.replace("'lython-b933-fixtures'","'lython-b934-fixtures'")
s=s.replace('Four-job direct-global source pair','Four-job refined direct-global source pair')
s=s.replace('Untimed cbfe source condition retained; no predicted gain.', 'Initial9e measured adversity and untimedcbfe retained; immutable pools expose arrays and no generic probe layer, no predicted gain or source-condition subtraction.')
(r/'prepare-refined-quiet.py').write_text(s,encoding='utf-8',newline='\n')
p=r/'frozen/identity.json';v=json.loads(p.read_text(encoding='utf-8'));v['candidateSource']+='; refined constant/name pools use existing owned immutable arrays directly, without generic immediate probe';p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Prepared changed-source refinement using same four whole-script/control jobs; only archived old9e prototype retires, current65fc stays.')
