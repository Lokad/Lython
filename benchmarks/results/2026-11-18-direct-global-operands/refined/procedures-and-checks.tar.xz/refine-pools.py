from pathlib import Path
r=Path(__file__).resolve().parent;work=Path('D:/code/Lython/.git/agent-worktrees/direct-global-r509')
for tree in ['src','tests']:
 for p in (work/tree).rglob('*.cs'):
  if any(n in p.parts for n in ['obj','bin']):continue
  s=p.read_text(encoding='utf-8-sig');t=s.replace('.Constants.Count','.Constants.Length').replace('.Names.Count','.Names.Length')
  if t!=s:p.write_text(t,encoding='utf-8',newline='\n')
# Preserve every first measured artifact and its worker image. The refinement
# is a new source condition, never a relabelled earlier measurement.
out=r/'measured-initial';out.mkdir()
for n in ['frozen','quiet','candidate-sources.tar.xz','prototype.patch.gz','candidate-preflight.json','candidate-preflight.log','candidate-allocation.json','candidate-allocation.log','candidate-ir.json','reference-ir.json','summary.json','allocation-summary.json']:
 (r/n).rename(out/n)
print('Refined existing pool arrays and removed generic probe; initial measured condition preserved.')
