from pathlib import Path
import json,os,subprocess
r=Path(__file__).resolve().parent;work=Path('D:/code/Lython/.git/agent-worktrees/direct-global-r509');d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe')
env=os.environ.copy();env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH'];rows=[]
for tfm in ['net11.0','net10.0']:
 cmd=[str(d),'test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f',tfm,'--no-build','--filter','FullyQualifiedName~LoweringArchitectureSubsystem&Category!=Stress']
 path=r/('pool-metadata-'+tfm+'.log')
 with path.open('w',encoding='utf-8')as log:p=subprocess.run(cmd,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=90)
 rows.append(dict(framework=tfm,exitCode=p.returncode,command=cmd));(r/'pool-metadata-checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
 assert p.returncode==0,path.read_text(encoding='utf-8');print(tfm,path.read_text(encoding='utf-8').splitlines()[-1],flush=True)
