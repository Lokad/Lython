from pathlib import Path
r=Path(__file__).resolve().parent;prior=r.parent/'current-cpu-r508'
s=(prior/'prove-old-core.py').read_text(encoding='utf-8')
a=s.index('for suffix in ');b=s.index('current=json.loads',a)
s=s[:a]+'''canonical='benchmarks/results/2026-11-18-direct-global-operands/initial/candidate-core.dll.gz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();data=gzip.decompress(blob)
assert hashlib.sha256(data).hexdigest()=='9e184cc74662e089690ffd304fb429721115b5d1344747080b266f3332d0233b'
subjects.append(dict(kind='superseded-core',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='gzip-payload',committedBlobVerified=True))
'''+s[b:]
s=s.replace('current65fcAnd5aeImagesPreserved=True','current65fcPreserved=True').replace("r/'old-core-proof.log'","r/'retirement-proof.log'").replace("r/'old-core-proof.json'","r/'retirement-candidates.json'")
exec(compile(s,str(r/'prove-space.py'),'exec'),dict(__file__=str(r/'prove-space.py')))
