from pathlib import Path
import hashlib,json,re,tarfile
root=Path.cwd(); private=Path(__file__).parent; src=private/'cpu-gate'
out=root/'benchmarks/results/2026-11-13-captured-current-cpu'
out.mkdir(exist_ok=True)
for name in ['attribution.json','archive-receipt.json','terminal-status.json','observations.tgz','observations-first.tgz']:
 (out/name).write_bytes((src/name).read_bytes())
with tarfile.open(out/'collection-sources.tar.xz','w:xz')as archive:
 for p in sorted(private.iterdir()):
  if p.is_file()and('cpu' in p.name)and p.suffix=='.py':archive.add(p,arcname=p.name)
 for p in sorted(src.iterdir()):
  if p.is_file()and p.suffix in ['.py','.json','.log','.txt']:
   archive.add(p,arcname='preparation/'+p.name)
d=json.loads((src/'attribution.json').read_text(encoding='utf-8'))
assert d['samples']==1518 and not d['malformedMapLines'] and not d['ambiguousLeafSamples']
assert hashlib.sha256((out/'observations.tgz').read_bytes()).hexdigest()=='88128828856d27242c5a06a330def86f6ea6804a60cf669a64ce76e3aee44c3b'
rows=[]
for name,count in d['topLeafCpuSamples'][:15]:
 match=re.search(r'(?:Lokad\.Lython\.[^ ]+|System\.[^ ]+)::[^ (]+',name)
 label=match[0].split('::')[-1]if match else 'Unmapped CLR leaf'
 rows.append(f'| {label} | {count} / {100*count/d["samples"]:.2f}% |')
readme='''# Current captured-text CPU attribution — R292 / B647

2026-11-13; fully qualified source **2d91eb1a**, frozen core SHA256
`161cd935023fd95a08488cbf7cfa3ee02ea4b88c69c0ba1231299b6ef0d80447`.
Same fixed fec79 benchmark worker, adapter0.4, stock .NET11RC3 on the quiet
F4as_v7 / Ubuntu24.04.4 VM. The complete captured-helper/nonlocal text script
reads 3,072 lines /35,840B and validates its full stdout and files.

Twelve-second warmup; eight-second CPU-clock capture at199Hz with frame pointers.
Selected guest thread consumed7.64 CPU seconds; execution clocks total7.776941s.
**1,518 samples**,97 unmapped leaves(6.39%),0 ambiguous leaves,0 malformed CLR map
lines and0 reported lost samples. Normal GC/tiering; PerfMap is the only diagnostic
runtime override. CLR symbols are resolved against the saved IP intervals;
overlaps are not guessed. Full all-thread CPU and native/managed raw stacks survive.
This is CPU attribution, not a wall-time, allocation or before/after comparison.

| Selected leaf (including inlined useful work) | Samples / share |
| --- | --- |
'''+ '\n'.join(rows)+'''

Nearest Lython frame attributes8.23% to MemoryGovernor.Reserve and3.82% to
EnsureInterpreterStack; those include runtime/monitor work below their callers.
They are not independently additive to the leaf rows or removable shares.

## Source gate and next decision

This repeats the broad cost distribution of R272 on the **new** ordered-slot
implementation. It does not show a remaining duplicate argument array or prove
that universal tagged values, a new call controller, or frontend passes dominate.
The dictionary loop does useful probing, exact arithmetic and Python binding;
the previous segment-entry/frame-hoisting variants already measured slower and
remain withdrawn. Existing case writing is UTF-8/bulk ASCII, not per-character
CLR string conversion. Do not infer a new casing-conversion project from the name.

The next source gate is **per-record text construction and admission**: cased
iteration currently collects ranges into stack/growing scratch, rents its final
range backing, copies the inventory, then admits eventual word storage. Assess
whether one directly owned construction buffer can replace that staging/copy
across split consumers without creating another pool or per-object ledger.
This is a concrete elimination hypothesis, not a speed forecast from the9.09%
preparation leaf. Admission is an observable callback: preserve allocation peaks,
first refusal before loop effects, mutation after reentry, final-sigma/expansions,
retained strings, early exit and pending async cleanup. Native/guarded search and
CSV are controls; captured/native text are affected scripts. First stop is a
source/ownership design plus existing regressions showing whether staging is
removable. A prototype then needs compile/warm/compile-to-result controls and a
delivery debt decision. If the common replacement cannot simplify ownership,
record that result and proceed to the call/frame roadmap; do not add a second
construction framework merely to remove a copy.

No new runtime prototype is retained by this capture. The performance objective
remains open; accepted native-search debt and uncertain guarded timings remain
in the ordered-slot evidence. Compilation/front-end consolidation remains a
later whole-pipeline milestone, with compile-to-result controls required.

## Failure preservation and custody

The first private collector substituted a placeholder inside DOTNET_ROOT. Its AST
gate stopped before RAM mounting or worker start; corrected source is retained.
The valid capture completed, verified goldens/balances and quiet gates, joined all
users and unmounted fixtures. The service then exited1 because root-owned
perf.data could not be archived. Under a fresh idle lease, only that verified
regular task-owned file had ownership corrected; inode and bytes were unchanged.
The complete archive was rebuilt and independently SHA-verified, without repeating
samples. The original partial archive and journal are preserved. Report the
original failed service condition separately from successful evidence recovery.
Last owned VM free space265224192B; no active users or RAM fixture mounts.

[Attribution](attribution.json), [raw recovered capture](observations.tgz),
[original partial archive](observations-first.tgz), [recovery](archive-receipt.json),
[cached terminal state](terminal-status.json),
[collection and analysis sources](collection-sources.tar.xz).
'''
(out/'README.md').write_text(readme,encoding='utf-8',newline='\n')
p=root/'benchmarks/EXPERIMENTS.md';p.write_text(p.read_text(encoding='utf-8')+'''

## R292 — current captured-text CPU source gate

[Qualified2d91 CPU capture](results/2026-11-13-captured-current-cpu/README.md):
1,518 selected samples /7.64 guest CPU seconds. Dictionary loop17.39%, cased-range
preparation9.09%, instruction prefix7.77%; inlined useful work is included and no
removable shares or speedup are inferred. Original collector/archive failures,
all raw frames and the exact-byte recovery are preserved. No samples repeated.
Next bounded gate assesses direct per-record range/storage construction with
observable admission and retained-alias semantics; no new runtime prototype yet.
''',encoding='utf-8',newline='\n')
p=root/'PLAN.md';plan=p.read_text(encoding='utf-8')
start=plan.index('    - Bounded next gate:') if '    - Bounded next gate:'in plan else plan.index('   - Bounded next gate:')
end=plan.index('   - Before another prototype,',start)
plan=plan[:start]+'''   - Completed current-source CPU gate R292:1,518 samples/7.64 guest CPU s;
     dictionary17.39%, cased preparation9.09%, dispatch7.77%. Useful/inlined work
     included; no removable-share forecast. [Raw/limitations/source gate](benchmarks/results/2026-11-13-captured-current-cpu/README.md).
     It does not justify new scalar wrappers/controllers or replaying slower frame
     hoisting. All collection/archive failure conditions and exact recovery survive.
   - Next coherent source gate: direct per-record text range/storage construction.
     Hypothesis: remove scratch inventory -> final range copy and overlapping
     staging, using the existing execution-owned buffer policy across split
     consumers. Affected captured/native text; controls CSV/guarded search.
     Preserve eager admission before effects, replacement peaks, reentrant host
     mutation, Unicode/context, aliases, early exits and awaited cleanup.
     Stop after the ownership design/existing regressions establish whether a
     shared replacement deletes machinery. No extra pool, ledger or framework.
     If staging is essential, record why and move on without another timing run.
'''+plan[end:]
plan=plan.replace('floors; last terminal VMfree267366400B','floors; last terminal VMfree265224192B')
plan=plan.replace('2. **D03 — independent regex/provider development.**','''2. **D02 follow-on roadmap — complete pipelines, not isolated tweaks.**
   - Call/frame/operand transport: after the record gate, inspect remaining native
     entry -> final slots -> ordinary handoff as one lifecycle. Only replace a
     demonstrated duplicated stage, retiring its old controller/metadata; source
     proof and native/captured/CSV controls precede broader representation changes.
     Preserve defaults once, closures, dynamic protocols, suspension and stack depth.
   - Frontend consolidation: reuse shared scope/binding facts and remove a retained
     intermediate only when all consumers use the shared facts. Config, helper and
     report compile-to-result are acceptance workloads; warm-only wins do not pass.
     Current near-CPython compile controls make this lower priority than execution.
   - Delivered record adoption, UTF8 formatting/casing and JSON windows are the
     baseline. Any further collection/text redesign names its displaced copy or
     representation and proves projection/alias/refusal semantics before timing.

3. **D03 — independent regex/provider development.**''')
p.write_text(plan,encoding='utf-8',newline='\n')
print('CPU evidence and source-gated roadmap recorded; no runtime changes.',flush=True)
