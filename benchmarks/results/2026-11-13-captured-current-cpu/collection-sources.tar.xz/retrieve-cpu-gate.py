from pathlib import Path
import datetime,hashlib,json,subprocess,tarfile
r=Path(__file__).parent/'cpu-gate';assert not(r/'terminal-status.json').exists();config=json.loads((r/'config.json').read_text(encoding='utf-8'));bound=json.loads((r/'observe-not-before.json').read_text(encoding='utf-8'));assert datetime.datetime.now(datetime.timezone.utc)>=datetime.datetime.fromisoformat(bound['doNotObserveBeforeUTC'])
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
script='''from pathlib import Path
import fcntl,json,subprocess
root=Path(ROOT)
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 print(json.dumps(dict(service=subprocess.check_output(['systemctl','show',UNIT,'--property=ActiveState,SubState,Result,ExecMainStatus,MainPID'],text=True),exitCode=(root/'exit-code.txt').read_text().strip(),receipt=json.loads((root/'archive-receipt.json').read_text())if(root/'archive-receipt.json').exists()else None,remainingWorkers=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True,text=True).stdout,remainingFixture=(root/'guest-fixtures').exists(),journal=subprocess.check_output(['journalctl','-u',UNIT,'--no-pager','-o','cat'],text=True))))
'''.replace('Path(ROOT)','Path('+repr(config['root'])+')').replace('UNIT',repr(config['unit']+'.service'))
done=subprocess.run(ssh+['python3 -'],input=script,text=True,encoding='utf-8',capture_output=True);(r/'observation.json').write_text(done.stdout,encoding='utf-8');assert done.returncode==0,done.stderr
data=json.loads(done.stdout);print(json.dumps(data),flush=True)
assert data['exitCode']=='0'and data['receipt']['complete']and not data['remainingWorkers']and not data['remainingFixture']
(r/'terminal-status.json').write_text(done.stdout,encoding='utf-8')
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for name in ['observations.tgz','archive-receipt.json']:
 done=subprocess.run(scp+['lokad@20.166.121.73:'+config['root']+'/'+name,str(r/name)],capture_output=True,text=True,encoding='utf-8');assert done.returncode==0,done.stderr
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==data['receipt']['archiveSHA256']
out=r/'retrieved';out.mkdir()
with tarfile.open(r/'observations.tgz')as archive:archive.extractall(out,filter='data')
print('Owned CPU capture/archive verified; terminal cached, no users or RAM fixture remain.',flush=True)
