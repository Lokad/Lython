from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).parent/'cpu-gate';config=json.loads((r/'config.json').read_text(encoding='utf-8'))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
script='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess,tarfile
root=Path(ROOT)
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not(root/'guest-fixtures').exists()and subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 record=json.loads((root/'profiles/captured-text/record.json').read_text());assert record['exitCode']==0 and record['closed']['status']=='Closed'
 assert all(json.loads((root/name).read_text())['gate']['quiet']for name in ['machine-before.json','machine-after.json'])
 journal=subprocess.check_output(['journalctl','-u',UNIT,'--no-pager','-o','cat'],text=True);(root/'original-archive-failure.txt').write_text(journal)
 raw=root/'profiles/captured-text/perf.data';info=raw.lstat();assert raw.resolve(strict=True)==raw and raw.is_relative_to(root)and stat.S_ISREG(info.st_mode)and info.st_uid==0
 before=subprocess.check_output(['sudo','-n','sha256sum',str(raw)],text=True).split()[0]
 subprocess.run(['sudo','-n','chown','--no-dereference',str(os.getuid())+':'+str(os.getgid()),str(raw)],check=True)
 assert(raw.stat().st_dev,raw.stat().st_ino)==(info.st_dev,info.st_ino)and hashlib.sha256(raw.read_bytes()).hexdigest()==before
 (root/'observations.tgz').rename(root/'observations-first.tgz')
 with tarfile.open(root/'observations.tgz','w:gz',dereference=True)as archive:
  for p in sorted(root.rglob('*')):
   if p.is_file()and p.name not in ['observations.tgz','observations-first.tgz']and not{'candidate'}&set(p.relative_to(root).parts):archive.add(p,arcname=p.relative_to(root).as_posix())
 with tarfile.open(root/'observations.tgz')as archive:assert hashlib.sha256(archive.extractfile('profiles/captured-text/perf.data').read()).hexdigest()==before
 assert shutil.disk_usage(root).free>252*1024*1024
 receipt=dict(complete=True,originalServiceExit='1',archiveRecoveredAfterRootOwnedPerfData=True,noMeasurementRepeated=True,allWorkersJoined=True,guestFixturesRemoved=True,quietBeforeAndAfter=True,archivedAndVerifiedUnderLease=True,source='2d91eb1a/161cd935',archiveSHA256=hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest(),rawPerfSHA256=before,freeBytes=shutil.disk_usage(root).free,performanceComparison=False)
 (root/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\\n');print(json.dumps(receipt))
'''.replace('Path(ROOT)','Path('+repr(config['root'])+')').replace('UNIT',repr(config['unit']+'.service'))
done=subprocess.run(ssh+['python3 -'],input=script,text=True,encoding='utf-8',capture_output=True);(r/'recovery.stdout').write_text(done.stdout,encoding='utf-8');(r/'recovery.stderr').write_text(done.stderr,encoding='utf-8');assert done.returncode==0,done.stderr
receipt=json.loads(done.stdout);print(json.dumps(receipt),flush=True)
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for name in ['observations.tgz','archive-receipt.json','observations-first.tgz']:
 done=subprocess.run(scp+['lokad@20.166.121.73:'+config['root']+'/'+name,str(r/name)],capture_output=True,text=True,encoding='utf-8');assert done.returncode==0,done.stderr
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
out=r/'retrieved';out.mkdir()
with tarfile.open(r/'observations.tgz')as archive:archive.extractall(out,filter='data')
(r/'terminal-status.json').write_text(json.dumps(dict(terminal=True,originalServiceExit='1',captureAndArchiveComplete=True,recovery=receipt,noRemainingUsersOrRamFixtures=True),indent=2)+'\n',encoding='utf-8',newline='\n')
