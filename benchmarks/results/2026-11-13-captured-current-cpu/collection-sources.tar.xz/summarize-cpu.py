from pathlib import Path
import json,re
p=Path(__file__).parent/'cpu-gate/attribution.json'
d=json.loads(p.read_text(encoding='utf-8'))
for key in ['source','samples','guestCpuSeconds','timedExecutionSeconds','unmappedLeafSamples','ambiguousLeafSamples','nearestFrameFamilies']:
 print(key, d[key])
for key in ['topLeafCpuSamples','nearestLythonFrame']:
 print('\n'+key)
 for name,count in d[key][:18]:
  match=re.search(r'(?:Lokad\.Lython\.[^ ]+|System\.[^ ]+)::[^ (]+',name)
  if match: name=match[0]
  print(count,round(100*count/d['samples'],2),name[:220])
