from pathlib import Path
import ast,hashlib,json,subprocess,tarfile
r=Path(__file__).parent/'cpu-gate';r.mkdir();old=r.parent.parent/'record-call-r267/b615'
root='/home/lokad/lython-bench-checks/captured-cpu-b647-20261112'
code=(old/'ops-profile.py').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/record-call-profile-b615-20261112',root)
code='\n'.join(line for line in code.split('\n')if not line.startswith('env["DOTNET_Jit'))
code=code.replace('["DOTNET_PerfMapEnabled","DOTNET_JitDisasm","DOTNET_JitStdOutFile"]','["DOTNET_PerfMapEnabled"]')
start=code.index('    for name, case_id, lane in ');end=code.index('\n',start)
code=code[:start]+'''    for name, case_id, lane in [("captured-text", "scripts.text-summary-helpers.nonlocal-counter.large", "warm")]:'''+code[end:]
start=code.index('        count = ');end=code.index('\n',start);code=code[:start]+'        count = 128 # Existing complete script; bounded warmed CPU attribution, not a timing comparison.'+code[end:]
code=code.replace('for _ in range(64):','for _ in range(128):').replace('if elapsed >= 6:break','if elapsed >= 12:break').replace('deadline=time.monotonic()+6','deadline=time.monotonic()+8').replace('if total_capture_seconds > 16:','if total_capture_seconds > 10:')
needle='            record["verificationAfter"] = request("verify")';assert needle in code
code=code.replace(needle,'''            with (folder/'perf-stacks.txt').open('w') as stacks:
                subprocess.run(['sudo','-n','perf','script','-i',str(folder/'perf.data'),'--tid',active_tid], stdout=stacks,stderr=subprocess.STDOUT,check=True,timeout=15)
'''+needle)
ast.parse(code);(r/'ops-profile.py').write_text(code,encoding='utf-8',newline='\n')
identity=json.loads((r.parent/'final/b646/identity.json').read_text(encoding='utf-8'));identity['purpose']='R292 one eight-second real cpu-clock/fp attribution of current qualified complete captured-text script;12s warmup; only PerfMap diagnostic override; no timing/CPU-share-as-removable claim'
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
collect='''from pathlib import Path
import fcntl,json,os,subprocess,time,tarfile,hashlib,shutil
root=Path(ROOT)
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 env=os.environ.copy();env['DOTNET_ROOT']='/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148'
 worker=root/'candidate/Lokad.Lython.Benchmarks.dll';dotnet=env['DOTNET_ROOT']+'/dotnet'
 time.sleep(3)
 subprocess.run([dotnet,str(worker),'--compare','check-machine','--out',str(root/'machine-before.json')],env=env,check=True)
 assert json.loads((root/'machine-before.json').read_text())['gate']['quiet']
 subprocess.run(['python3',str(root/'ops-profile.py'),str(root/'profiles')],check=True)
 time.sleep(3)
 subprocess.run([dotnet,str(worker),'--compare','check-machine','--out',str(root/'machine-after.json')],env=env,check=True)
 assert json.loads((root/'machine-after.json').read_text())['gate']['quiet']
 assert not list((root/'guest-fixtures').iterdir())
 record=json.loads((root/'profiles/captured-text/record.json').read_text());assert record['exitCode']==0 and record['closed']['status']=='Closed'
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 subprocess.run(['sudo','-n','umount',str(root/'guest-fixtures')],check=True);(root/'guest-fixtures').rmdir()
 with tarfile.open(root/'observations.tgz','w:gz',dereference=True)as archive:
  for p in sorted(root.rglob('*')):
   if p.is_file()and p.name!='observations.tgz'and not{'candidate'}&set(p.relative_to(root).parts):archive.add(p,arcname=p.relative_to(root).as_posix())
 with tarfile.open(root/'observations.tgz')as archive:assert json.loads(archive.extractfile('profiles/captured-text/record.json').read())['exitCode']==0
 assert shutil.disk_usage(root).free>252*1024*1024
 receipt=dict(complete=True,allWorkersJoined=True,quietBeforeAndAfter=True,guestFixturesRemoved=True,archivedAndVerifiedUnderLease=True,freeBytes=shutil.disk_usage(root).free,archiveSHA256=hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest(),source='2d91eb1a/161cd935',performanceComparison=False)
 (root/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\\n');print(json.dumps(receipt))
'''.replace('ROOT',repr(root))
(r/'collect.py').write_text(collect,encoding='utf-8',newline='\n')
run='''set -eu
root=ROOT
trap 'result=$?; printf "%s\\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
'''.replace('ROOT',root)
(r/'run.sh').write_text(run,encoding='utf-8',newline='\n')
canonical=Path('benchmarks/results/2026-11-12-captured-slot-ownership/b638/observations.tgz');blob=subprocess.check_output(['git','show','HEAD:'+canonical.as_posix()]);assert blob==canonical.read_bytes()
config=dict(root=root,unit='lython-b647-current-captured-cpu-20261112',sourceRoot='/home/lokad/lython-bench-checks/compile-result-b646-20261112',identity=identity,retire=dict(knownPath='/home/lokad/lython-bench-checks/captured-slots-b638-20261112/observations.tgz',bytes=len(blob),sha256=hashlib.sha256(blob).hexdigest(),canonical=canonical.as_posix()))
with tarfile.open(r/'payload.tgz','w:gz')as archive:
 for name in ['ops-profile.py','collect.py','run.sh','identity.json']:archive.add(r/name,arcname=name)
config.update(payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((r/'payload.tgz').read_bytes()).hexdigest())
(r/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
print('One eight-second CPU attribution,12s warmup, existing perf worker;120s owner/30s stop/30s margin; fully managed runtime unchanged.',flush=True)
