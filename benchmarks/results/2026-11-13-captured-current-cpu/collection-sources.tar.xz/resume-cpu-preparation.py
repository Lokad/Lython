from pathlib import Path
import ast,datetime,hashlib,json,shlex,subprocess
r=Path(__file__).parent/'cpu-gate';config=json.loads((r/'config.json').read_text(encoding='utf-8'));p=r/'collect.py';old=p.read_bytes();(r/'collect-first.py').write_bytes(old)
new=old.decode('utf-8').replace('DOTNET_'+repr(config['root']),'DOTNET_ROOT');ast.parse(new);p.write_text(new,encoding='utf-8',newline='\n')
script='''from pathlib import Path
import ast,fcntl,hashlib,json,os,subprocess,sys
config=CONFIG
root=Path(config['root']);fixture=root/'guest-fixtures'
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not fixture.exists()and subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 current=root/'collect.py';old=current.read_bytes();assert hashlib.sha256(old).hexdigest()==EXPECTED
 (root/'collect-first.py').write_bytes(old);current.write_bytes(sys.stdin.buffer.read());ast.parse(current.read_text());ast.parse((root/'ops-profile.py').read_text())
 assert hashlib.sha256((root/'candidate/Lokad.Lython.dll').read_bytes()).hexdigest()==config['identity']['coreSHA256']['candidate']
 fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b647-fixtures',str(fixture)],check=True)
 (root/'setup.json').write_text(json.dumps(dict(source='2d91eb1a/161cd935',freshIdleLease=True,preparationCorrection='Placeholder substitution had changed DOTNET_ROOT; detected before fixture mount/worker start. Original script retained.',previousExactArchivedDuplicate=config['retire'],osFloorMiB=240,evidenceHeadroomMiB=12,freeBytes=__import__('shutil').disk_usage(root).free,ownerSeconds=120,stopSeconds=30,marginSeconds=30),indent=2)+'\\n')
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=120','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True);assert'ActiveState=active'in live and'MainPID=0'not in live;print(live)
'''.replace('config=CONFIG','config='+repr(config)).replace('==EXPECTED','=='+repr(hashlib.sha256(old).hexdigest()))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
stage='/home/lokad/lython-bench-checks/captured-cpu-b647-resume.py';write='from pathlib import Path;import sys;p=Path('+repr(stage)+');assert not p.exists();p.write_bytes(sys.stdin.buffer.read())'
done=subprocess.run(ssh+['python3 -c '+shlex.quote(write)],input=script.encode('utf-8'),capture_output=True);assert done.returncode==0,done.stderr.decode('utf-8')
done=subprocess.run(ssh+['python3 '+stage],input=p.read_bytes(),capture_output=True);(r/'resume.log').write_bytes(done.stdout+b'\n'+done.stderr);assert done.returncode==0,done.stderr.decode('utf-8')
now=datetime.datetime.now(datetime.timezone.utc);bound=dict(acknowledgedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=180)).isoformat(),ownerSeconds=120,stopSeconds=30,marginSeconds=30)
(r/'observe-not-before.json').write_text(json.dumps(bound,indent=2)+'\n',encoding='utf-8',newline='\n');print(done.stdout.decode('utf-8'));print(json.dumps(bound),flush=True)
