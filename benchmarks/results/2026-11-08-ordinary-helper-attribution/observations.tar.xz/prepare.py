from pathlib import Path
import ast,gzip,hashlib,json,math,shutil,tarfile
r=Path(__file__).resolve().parent;old=r.parent/'cost-r80';runtime=r.parent/'operand-consumers-r82';checkpoint=r.parent/'combined-cpython-r83'
source=json.loads((runtime/'identity.json').read_text(encoding='utf-8'));assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in source['productionSources'].items())
d=json.loads((checkpoint/'representative.json').read_text(encoding='utf-8'));d['cases']=[c for c in d['cases']if c['id']=='scripts.text-summary-rsplit-helpers.large'];assert len(d['cases'])==1
(r/'catalog.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
receipt=json.loads((checkpoint/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']
assert hashlib.sha256((checkpoint/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
with tarfile.open(checkpoint/'observations.tgz')as a:assert hashlib.sha256(a.extractfile('current-core.dll').read()).hexdigest()==source['coreSHA256']['candidate']
coreSource=dict(vmArchive='combined-cpython-b446-20261108/observations.tgz',archiveSHA256=receipt['archiveSHA256'],member='current-core.dll',coreSHA256=source['coreSHA256']['candidate'],immutableLocalArtifact='benchmarks/results/2026-11-08-runtime-checkpoint/observations.tgz')
(r/'core-source.json').write_text(json.dumps(coreSource,indent=2)+'\n',encoding='utf-8')
identity=dict(sourceRevision='91f15a3e',files={'Lokad.Lython.dll':source['coreSHA256']['candidate']},auxiliaryFiles=json.loads((checkpoint/'identity.json').read_text(encoding='utf-8'))['auxiliaryFiles'],productionSources=source['productionSources'],qualification='Full Windows/Ubuntu actual.NET11/10, originalStress and installed core consumer CI42451722109 green/cached.',purpose='One bounded ordinary-helper whole-script CPU attribution; no normal-settings timing or source-pair speedup claim.')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8');shutil.copyfile(runtime/'source.patch',r/'source.patch');shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md');shutil.copyfile(r/'selection.md',r/'contract.md')
for name in ['ops-profile.py','analyze-cpu-guest.py','retrieve.py','run.sh','archive.py','launch.py']:
 s=(old/name).read_text(encoding='utf-8').replace('native-cost-b444','ordinary-helper-cost-b447').replace('lython-b444-native-cost','lython-b447-ordinary-helper-cost').replace('lython-b444','lython-b447')
 if name=='ops-profile.py':s=s.replace('scripts.text-summary-helpers.large','scripts.text-summary-rsplit-helpers.large')
 if name=='archive.py':
  s=s.replace(" a.add(root/'candidate/Lokad.Lython.dll',arcname='current-core.dll')",' # Exact core already preserved in verified immutable B446 archive (core-source.json).')
  s=s.replace("record=json.loads((root/'profiles/text-warm/record.json').read_text())", "assert __import__('shutil').disk_usage(root).free>240*1024*1024\nrecord=json.loads((root/'profiles/text-warm/record.json').read_text())")
 if name=='launch.py':
  s=s.replace("source=(base/'native-workstate-b443-20261108/candidate').resolve()","source=(base/'combined-cpython-b446-20261108/candidate').resolve()")
  s=s.replace('+256*1024*1024','+(240+8)*1024*1024')
  needle=" shutil.copytree(source,root/'candidate',copy_function=os.link)"
  assert needle in s
  s=s.replace(needle,""" proof=json.loads((root/'core-source.json').read_text());archive=base/proof['vmArchive']
 assert hashlib.sha256(archive.read_bytes()).hexdigest()==proof['archiveSHA256']
 with tarfile.open(archive)as a:assert hashlib.sha256(a.extractfile(proof['member']).read()).hexdigest()==proof['coreSHA256']
"""+needle)
  s=s.replace('ownerSeconds=120,stopSeconds=30,observationMarginSeconds=30)','ownerSeconds=120,stopSeconds=30,observationMarginSeconds=30,osFloorMiB=240,traceArchiveHeadroomMiB=8)')
 (r/name).write_text(s,encoding='utf-8',newline='\n')
 if name.endswith('.py'):ast.parse(s)
raw=sum((p.stat().st_size+4095)//4096*4096 for p in (old/'retrieved').rglob('*')if p.is_file()and p.name!='current-core.dll')
with tarfile.open(old/'observations.tgz')as a:oldCoreCompressed=len(gzip.compress(a.extractfile('current-core.dll').read()))
estimate=math.ceil((raw-(old/'catalog.json').stat().st_size+(r/'catalog.json').stat().st_size+(old/'observations.tgz').stat().st_size-oldCoreCompressed)*1.25)
assert estimate<8*1024*1024,estimate
(r/'sizing.json').write_text(json.dumps(dict(priorRoundedRawBytes=raw,priorArchiveBytes=(old/'observations.tgz').stat().st_size,priorCoreCompressedBytes=oldCoreCompressed,newCatalogBytes=(r/'catalog.json').stat().st_size,conservativeTraceArchiveEstimateBytes=estimate,reservedHeadroomBytes=8*1024*1024,osFloorBytes=240*1024*1024,noEvidenceDeleted=True,archivedCoreReused=True),indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'payload.tgz','w:gz')as a:
 for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','catalog.json','identity.json','source.patch','contract.md','selection.md','sizing.json','core-source.json','pre-measurement-plan.md']:a.add(r/name,arcname=name)
print('One ordinary-helper profile prepared; historical peak+25% fits8MiB headroom with one-case catalog and verified existing core archive. No evidence removed.')
