from pathlib import Path
import hashlib,json,tarfile
r=Path(__file__).resolve().parent;out=Path('benchmarks/results/2026-11-08-ordinary-helper-attribution');out.mkdir(exist_ok=True)
identity=json.loads((r/'identity.json').read_text(encoding='utf-8'));qualified=json.loads(Path('benchmarks/results/2026-11-08-prepared-consumers/assessment.json').read_text(encoding='utf-8'))
assert identity['productionSources']==qualified['source']['productionSources']
receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
with tarfile.open(out/'observations.tar.xz','w:xz')as a:
 for p in sorted(r.rglob('*')):
  if p.is_file() and not any(part in ['retrieved','__pycache__']for part in p.relative_to(r).parts)and p.name!='payload.tgz':a.add(p,arcname=p.relative_to(r).as_posix())
with tarfile.open(out/'observations.tar.xz')as a:
 for m in a.getmembers():assert m.isfile()and hashlib.sha256(a.extractfile(m).read()).digest()==hashlib.sha256((r/m.name).read_bytes()).digest()
print('Ordinary-helper source/CPU/unknowns/sizing/core-provenance archive verified:',(out/'observations.tar.xz').stat().st_size)
