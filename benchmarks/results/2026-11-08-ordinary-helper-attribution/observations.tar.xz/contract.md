R84: ordinary string-helper call/frame versus conversion attribution.
Current qualified production91f15a3e (docs HEAD87862247), frozen4c072fed core.
R83 ordinary rsplit helper warm2.18–2.23xCPython, guarded2.12–2.16x; fused straight
helper1.57–1.63x. Different paths/algorithms preclude attributing the gap to frames.

One existing six-second CPU-clock/FP capture, synchronous complete rsplit-helper
script,199Hz,6guest-second warmup(max64x1024),2s settle. Diagnostic PerfMap3/JIT
listings only; no normal timing or source-pair CPU claim. All raw stacks/maps and
unknowns, actual guest CPU denominator, pre/post complete goldens, core/auxiliary/
source/Ready/runtime/Closed/exit/join/quiet/fixture/archive checks remain required.
No local build/test/measurement overlap.120s owner+30stop+30observation margin.

Source gate: ordinary zero-argument string calls use both typed delegates and
ReceiverMethod; native-helper preparation has a separate method-kind selection.
Possible coherent consolidation removes duplicate callable routes/selection, not
another per-name kernel. Preserve measured fusion, Python callable metadata and
binding/errors, Unicode, dynamic protocols, evaluation order, source spans,
cancellation, admission refusal, borrowed/retained owners and awaited cleanup.
Workspace reuse/direct local slots/inline presence bits already exist. No new
arena/pool, value representation or memory subsystem without dominant evidence.

Storage sizing before collection: VM has260,993,024free bytes. R80 raw snapshot
uses6,316,032 rounded bytes and2,260,274archive bytes including an already archived
core. Use one-case catalog and reference the verified immutable B446 core archive
instead of duplicating its core in this trace archive. Preserve every raw trace,
map, log and sample. Reserve240MiB OS floor+8MiB trace/archive headroom; verify
historical measured sizing, source archive and current exact payload before launch.
All working data stays persistent; RAM is only owned guest fixtures/temporary CLR
maps copied and verified before cleanup. No VM evidence deletion/retirement.

Stop at a justified complete removable phase or explicit insufficient evidence.
Then record a bounded coherent redesign with displaced code, affected scripts,
semantic/ownership checks and one source pair with controls. No automatic native
proof expansion, carrier revival, fixed percentage veto or performance-objective
closure. Regex development remains independent; publication postponed.
