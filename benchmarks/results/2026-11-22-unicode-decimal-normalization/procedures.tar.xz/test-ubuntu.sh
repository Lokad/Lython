#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
dir=/mnt/d/code/Lython/.git/agent-notes/review-20261031/record-and-text-profile-20261122
white='Category!=Stress&(FullyQualifiedName~Csv|FullyQualifiedName~Float|FullyQualifiedName~IntegerParsing|FullyQualifiedName~Format)'
public='Category!=Stress&(FullyQualifiedName~Csv|FullyQualifiedName~Float|FullyQualifiedName~Format|FullyQualifiedName~NumericText|FullyQualifiedName~NumericWork|FullyQualifiedName~IntegerParsing)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter "$white" --nologo > "$dir/white-ubuntu.log" 2>&1 || { tail -75 "$dir/white-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter "$public" --nologo > "$dir/public-ubuntu.log" 2>&1 || { tail -75 "$dir/public-ubuntu.log"; exit 1; }
awk '/Passed!/{count++;print} END{exit count!=2}' "$dir/white-ubuntu.log" "$dir/public-ubuntu.log"
