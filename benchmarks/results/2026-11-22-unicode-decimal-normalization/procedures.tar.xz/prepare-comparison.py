from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import statistics
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
notes=lab.parent
template=notes/"native-regex-indices-20261122"
base="/home/lokad/lython-bench-checks"
root=base+"/unicode-decimal-b1383-20261122"
unit="lython-b1383-unicode-decimal-20261122"
quiet=lab/"comparison"/"quiet"
quiet.mkdir(parents=True,exist_ok=True)
out=quiet.parent
core="Lokad.Lython.dll"
def read(path): return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(blob): return hashlib.sha256(blob).hexdigest()
def write(path,text):
    if path.suffix==".py":compile(text,str(path),"exec")
    path.write_text(text,encoding="utf-8",newline="\n")
def save(path,value): write(path,json.dumps(value,indent=2)+"\n")
def pushed(name): return subprocess.check_output(["git","show","origin/master:benchmarks/results/"+name],cwd=repo)

previous=read(template/"quiet/config.json")
proof=json.loads(pushed("2026-11-22-regex-native-indices/archive-receipt.json"))
assert all(proof[k] for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease"))
assert sha(pushed("2026-11-22-regex-native-indices/observations.tgz"))==proof["archiveSHA256"]
source=template/"frozen/candidate"
reference_hashes=previous["identity"]["imageFiles"]["candidate"]
assert len(reference_hashes)==32 and reference_hashes=={name:sha((source/name).read_bytes())for name in reference_hashes}
donor_hash=previous["catalogs"]["representative.json"]["sha256"]
catalog=lab/"catalog.json"
verified_catalog=sha(catalog.read_bytes())
shutil.copyfile(catalog,quiet/"representative.json")
catalog_data=read(catalog)
ids=[case["id"]for case in catalog_data["cases"]]
jobs=[(case,"warm")for case in ids]+[(ids[2],"compile-run")]
assert len(jobs)==5 and ids[2]=="scripts.csv-meter-report.typed-unicode"
tree=repo/".git/agent-worktrees/unicode-decimal-normalization-20261122"
def git(*args):return subprocess.check_output(["git","-C",tree,*args]).strip()
reference=git("rev-parse","HEAD^").decode()
candidate=git("rev-parse","HEAD").decode()
assert reference==read(lab/"identity.json")["sourceRevision"] and not git("status","--porcelain")
diff=subprocess.check_output(["git","-C",tree,"diff","HEAD^","HEAD","--","src"])
assert diff==(lab/"decimal-normalization.patch").read_bytes()
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
protocol=repo/"benchmarks/cpython-worker.py"
assert sha(protocol.read_bytes())==previous["protocolSHA256"]
dll=lab/"decimal-build/bin/Lokad.Lython/release_net11.0"/core
candidate_image=out/"frozen-candidate"
candidate_image.mkdir(exist_ok=True)
for name in reference_hashes:shutil.copyfile(dll if name==core else source/name,candidate_image/name)
for f in source.glob("ValidatedAllocation.*"):shutil.copyfile(f,candidate_image/f.name)
files={"reference":reference_hashes,"candidate":dict(reference_hashes,**{core:sha(dll.read_bytes())})}
assert files["candidate"]=={name:sha((candidate_image/name).read_bytes())for name in reference_hashes}
alloc={}
for role,image in (("reference",source),("candidate",candidate_image)):
    receipt=out/(role+"-verify.json")
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog,
                    "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",receipt],
                   env=env,check=True,timeout=100)
    data=read(receipt)
    assert data["state"]=="Completed" and data["caseCount"]==4 and data["catalogSha256"]==verified_catalog
    raw=out/(role+"-allocation.json")
    if not raw.exists():
        subprocess.run([dotnet,image/"ValidatedAllocation.dll",image,catalog,raw],env=env,check=True,timeout=100)
    alloc[role]=read(raw)["rows"]
    assert all(row["sharedBudgetBaselineRestored"] for row in alloc[role])
    assert files[role]=={name:sha((image/name).read_bytes())for name in reference_hashes}
summary=[]
for ref,trial in zip(alloc["reference"],alloc["candidate"],strict=True):
    assert ref["id"]==trial["id"]
    a,b=[statistics.median(row["allocatedBytesPerInvocation"])for row in (ref,trial)]
    summary.append(dict(case=ref["id"],reference=a,candidate=b,allocationChangePercent=100*(b/a-1),
                        admittedReference=ref["peakExecutionMemoryBytes"],admittedCandidate=trial["peakExecutionMemoryBytes"]))
save(out/"allocation-summary.json",summary)
for row in summary: print(row,flush=True)
identity=dict(sourceRevision=reference+" versus "+candidate,reference=reference,candidate=candidate,
              purpose="Normalize short numeric tokens in one pass and share managed decimal value lookup",
              sourcePatchSHA256=sha(diff),normalAdapterPin="0.4.0",imageFiles=files,
              catalogs={"representative.json":{"sha256":verified_catalog}},
              coreSHA256={role+suffix:values[core] for role,values in files.items() for suffix in ("","-control")})
save(quiet/"identity.json",identity)
for name in ("collect.py","archive-owned.py","run.sh","retrieve.py"):
    data=(template/"quiet"/name).read_text(encoding="utf-8").replace(previous["root"],root).replace(previous["unit"],unit).replace("B1381","B1383")
    if name=="collect.py":
        a,b=data.index("\njob_catalog = "),data.index("\nassert len(jobs)")
        data=data[:a]+"\njob_catalog = "+repr({case:"representative.json"for case in ids})+"\njobs = "+repr(jobs)+data[b:]
    write(quiet/name,data)
assert b"\r" not in (quiet/"run.sh").read_bytes()
(quiet/"candidate").mkdir(exist_ok=True)
shutil.copyfile(dll,quiet/"candidate"/core)
parts=("identity.json","representative.json","collect.py","archive-owned.py","run.sh","candidate/"+core)
payload=quiet/"payload.tgz"
with tarfile.open(payload,"w:gz")as a:
    for name in parts:a.add(quiet/name,arcname=name)
unpacked=sum((quiet/name).stat().st_size for name in parts)
threshold=176160768+unpacked+640*1024

archive_dir="2026-11-22-json-direct-mapping"
historical=json.loads(pushed(archive_dir+"/source.json"))
reference_to_retire=gzip.decompress(pushed(archive_dir+"/candidate-core.dll.gz"))
retired_hash=sha(reference_to_retire)
assert retired_hash==historical["imageFiles"]["candidate"][core]
assert retired_hash!=files["reference"][core]
ssh=["C:/Windows/System32/OpenSSH/ssh.exe","-i",str(Path.home()/".ssh/id_lython-bench.pem"),"-o","BatchMode=yes","-o","ConnectTimeout=15","lokad@20.166.121.73"]
inventory_script=f"""
from pathlib import Path
import fcntl, hashlib, json, os, shutil, stat
base = Path({base!r})
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not any(p.is_mount() for p in base.glob('*/guest-fixtures'))
 target=base/'json-direct-mapping-b1376-20261122/candidate/Lokad.Lython.dll'
 stat_target=target.lstat()
 fingerprint=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
 assert fingerprint(target)=={retired_hash!r}
 paths=[]
 for directory,dirs,names in os.walk(base):
  for name in names:
   p=Path(directory)/name
   m=p.lstat()
   if (m.st_dev,m.st_ino)==(stat_target.st_dev,stat_target.st_ino):
    assert p.resolve()==p and p.name==target.name and stat.S_ISREG(m.st_mode) and m.st_uid==os.getuid()
    paths.append(str(p.relative_to(base)))
 assert len(paths)==stat_target.st_nlink
 archived_owners={{p.split('/')[0] for p in paths}}
 receipts={{owner:json.loads((base/owner/'archive-receipt.json').read_text())['archiveSHA256'] for owner in archived_owners}}
 archives={{owner+'/observations.tgz':fingerprint(base/owner/'observations.tgz') for owner in archived_owners if (base/owner/'observations.tgz').is_file()}}
 assert all(receipts[name.split('/')[0]]==digest for name,digest in archives.items())
 print(json.dumps(dict(free=shutil.disk_usage(base).free,bytes=stat_target.st_size,links=stat_target.st_nlink,sha256=fingerprint(target),paths=sorted(paths),archives=archives,receipts=receipts)))
"""
inventory=json.loads(subprocess.check_output(ssh+["python3 -"],input=inventory_script.encode("utf-8"),timeout=37))
save(out/"retire-inventory.json",inventory)
history={
    "json-direct-mapping-b1376-20261122":"2026-11-22-json-direct-mapping",
    "json-positional-control-b1377-20261122":"2026-11-22-json-positional-control",
    "json-positional-fixed-tier-b1379-20261122":"2026-11-22-json-positional-fixed-tier",
    "positional-default-tier-b1380-20261122":"2026-11-22-positional-default-tier-attribution",
    "regex-inline-indices-b1381-20261122":"2026-11-22-regex-native-indices",
    "json-delivery-cpython-b1378-20261122":"2026-11-22-json-delivery-cpython",
}
for remote,remote_hash in inventory["receipts"].items():
    archived=history[remote]
    info=json.loads(pushed(archived+"/archive-receipt.json"))
    assert all(info[k] for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease"))
    assert remote_hash==info["archiveSHA256"]==sha(pushed(archived+"/observations.tgz"))
assert inventory["bytes"]==len(reference_to_retire)and inventory["sha256"]==retired_hash
retire={key:inventory[key]for key in ("paths","links","bytes","sha256","archives")}
assert inventory["free"]+retire["bytes"]>threshold,(inventory["free"],threshold)
stage=dict(root=root,unit=unit,identity=identity,source=previous["root"],sourceRole="candidate",
           sourceFiles=files["reference"],sourceCatalogSHA256=donor_hash,
           donorArchiveSHA256=proof["archiveSHA256"],protocolSource=previous["protocolSource"],
           protocolSHA256=previous["protocolSHA256"],payloadBytes=payload.stat().st_size,
           payloadSHA256=sha(payload.read_bytes()),retireGroups=[retire],unpackedBytes=unpacked)
save(quiet/"config.json",stage)
data=(template/"quiet/remote-launch.py").read_text(encoding="utf-8").replace("lython-b1381-fixtures","lython-b1383-fixtures")
a,b=data.index("\nc=")+1,data.index("\nb=Path(")
data=data[:a]+"c="+repr(stage)+data[b:]
data=data.replace("sha(source/'expansion.json')","sha(source/'representative.json')")
a,b=data.index(" for leaf,witness in c['catalogs'].items():"),data.index(" for n in ['collect.py','archive-owned.py']")
data=data[:a]+" assert sha(root/'representative.json')==c['identity']['catalogs']['representative.json']['sha256']\n"+data[b:]
data=data.replace(" subprocess.run(['/bin/sh','-n'"," assert b'\\r' not in (root/'run.sh').read_bytes()\n subprocess.run(['/bin/sh','-n'")
write(quiet/"remote-launch.py",data)
write(out/"launch.py",(template/"launch.py").read_text(encoding="utf-8").replace("Native named-index","Unicode decimal normalization"))
write(out/"summarize.py",(template/"summarize.py").read_text(encoding="utf-8"))
print("Verified the two complete source images, four CPython goldens and exact redundant-image retirement.",flush=True)
