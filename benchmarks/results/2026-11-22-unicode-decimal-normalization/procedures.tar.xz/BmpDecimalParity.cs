using System;
using System.Globalization;
using System.Text;

var scalars = 0;
var decimals = 0;
for (var value = 0; value <= char.MaxValue; value++)
{
    if (!Rune.TryCreate(value, out var rune)) continue;
    var expected = Rune.GetUnicodeCategory(rune) == UnicodeCategory.DecimalDigitNumber
        ? (int)Rune.GetNumericValue(rune) : -1;
    var actual = CharUnicodeInfo.GetDecimalDigitValue((char)value);
    if (actual != expected)
        throw new InvalidOperationException($"U+{value:X4}: {expected} versus {actual}");
    scalars++;
    if (actual >= 0) decimals++;
}
Console.WriteLine($"{scalars} BMP scalars, including {decimals} decimal digits, match the previous rule.");
