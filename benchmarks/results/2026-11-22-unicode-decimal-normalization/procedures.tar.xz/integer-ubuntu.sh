#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
dir=/mnt/d/code/Lython/.git/agent-notes/review-20261031/record-and-text-profile-20261122
filter='Category!=Stress&(FullyQualifiedName~IntegerText|FullyQualifiedName~IntegerConversion)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter "$filter" --nologo > "$dir/integer-white-ubuntu.log" 2>&1 || { tail -75 "$dir/integer-white-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter "$filter" --nologo > "$dir/integer-public-ubuntu.log" 2>&1 || { tail -75 "$dir/integer-public-ubuntu.log"; exit 1; }
awk '/Passed!/{count++;print} END{exit count!=2}' "$dir/integer-white-ubuntu.log" "$dir/integer-public-ubuntu.log"
