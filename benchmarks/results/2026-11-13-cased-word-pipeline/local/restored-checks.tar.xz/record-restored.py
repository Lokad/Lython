from pathlib import Path
import hashlib, json, re, shutil, tarfile
r = Path(__file__).parent
reference = json.loads((r / 'reference-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == sha for p, sha in reference['sources'].items())
for name in ['restored-net11.0.log', 'restored-net10.0.log']:
 text = (r / name).read_text(encoding='utf-8')
 assert 'Failed:     0' in text and 'Passed:    34' in text
assert 'Build succeeded.' in (r / 'restored-build.log').read_text(encoding='utf-8')
assemblyInfo = Path('src/Lokad.Lython/obj/Release/net11.0/Lokad.Lython.AssemblyInfo.cs').read_text(encoding='utf-8')
current = Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll')
def informational(data):
 found = re.findall(rb'0\.11\.0\+[0-9a-f]{40}', data)
 return sorted(set(x.decode('ascii') for x in found))
assert informational(current.read_bytes()) == ['0.11.0+44ee719e313a54b0884b07d64521e01f0595ff92']
out = Path('benchmarks/results/2026-11-13-cased-word-pipeline/local')
proof = dict(all571ProductionSourcesExactlyRestored=True, sourceRuntimeCommit='d413392c', restoredHead='44ee719e', nonincrementalReleaseSolutionBuildPassed=True, retainedRegressionsPerActualTarget=34, originalReferenceCoreSHA256=reference['coreSHA256'], restoredCoreSHA256=hashlib.sha256(current.read_bytes()).hexdigest(), originalInformationalVersion=informational((r / 'reference/Lokad.Lython.dll').read_bytes()), restoredInformationalVersion=informational(current.read_bytes()), binaryIdentityNotExpectedEqual='The earlier source-matched runtime binary was built at a different Git revision. Generated informational version and source-link metadata include that revision; a private equality assertion after successful build/tests was invalid. No binary equivalence or new timing is inferred.', fullUnchangedQualificationNotRepeated=True)
(out / 'restoration.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8')
with tarfile.open(out / 'restored-checks.tar.xz', 'w:xz') as archive:
 for name in ['restored-build.log', 'restored-net11.0.log', 'restored-net10.0.log', 'check-restored.py', 'record-restored.py', 'withdraw.py']:
  archive.add(r / name, arcname=name)
 archive.add('src/Lokad.Lython/obj/Release/net11.0/Lokad.Lython.AssemblyInfo.cs', arcname='generated-AssemblyInfo.cs')
 archive.add(current, arcname='restored-core.dll')
print(json.dumps(proof, indent=2), flush=True)
