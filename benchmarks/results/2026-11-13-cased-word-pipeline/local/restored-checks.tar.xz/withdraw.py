from pathlib import Path
import hashlib, json, shutil, subprocess
r = Path(__file__).parent
candidate = json.loads((r / 'candidate-identity.json').read_text(encoding='utf-8'))
reference = json.loads((r / 'reference-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == sha for p, sha in candidate['sources'].items())
summary = json.loads((r / 'b655/summary.json').read_text(encoding='utf-8'))
assert summary['complete'] and summary['jobs'] == 5
for row in summary['timing'][:2]: assert min(row['changePercentRange']) > 10 and min(row['processCpuChangePercentRange']) > 10
for name in ['Runtime/Text/PyStringOps.Whitespace.cs', 'Runtime/Text/PyString.cs', 'Runtime/MemoryGovernor.cs', 'Runtime/LythonRuntime.Executable.DictionaryAccumulation.cs', 'Runtime/PyDict.Accumulation.cs']:
 p = Path('src/Lokad.Lython') / name
 original = (r / (p.name + '.before')).read_bytes()
 assert hashlib.sha256(original).hexdigest() == reference['sources'][p.as_posix()]
 p.write_bytes(original)
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == sha for p, sha in reference['sources'].items())
out = Path('benchmarks/results/2026-11-13-cased-word-pipeline/b655'); out.mkdir()
for name in ['observations.tgz', 'archive-receipt.json', 'terminal-status.json', 'summary.json', 'identity.json', 'launch.log', 'launch-command.py', 'config.json', 'collect.py', 'archive-owned.py', 'retrieve.py', 'summarize.py', 'extraction.json', 'observe-not-before.json']:
 shutil.copyfile(r / 'b655' / name, out / name)
for name in ['core-retirement-canonical.json', 'core-retirement-inspection.json']:
 shutil.copyfile(r / name, out / name)
validation = Path('benchmarks/results/2026-11-13-cased-word-pipeline/local/validation.json')
data = json.loads(validation.read_text(encoding='utf-8'))
data.update(finalDecisionPending=False, decision='Withdraw complete runtime prototype: material controlled CPU/elapsed and allocation regression; preserve independently useful long-word ownership and size-independent refund reentry regressions.', restoredProductionMatchesQualifiedReference=True, restoredProductionFiles=len(reference['sources']))
validation.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
print('Entire runtime prototype withdrawn; all571 production files exactly match qualified d413392c. B655/original source and controls preserved.', flush=True)
