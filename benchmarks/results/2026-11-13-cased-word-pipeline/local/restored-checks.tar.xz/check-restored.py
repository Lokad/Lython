from pathlib import Path
import hashlib, json, os, subprocess
r = Path(__file__).parent
sdk = Path('C:/Users/JoannesVermorel/.dotnet11')
env = os.environ.copy(); env['DOTNET_ROOT'] = str(sdk); env['PATH'] = str(sdk) + ';C:/Python313;' + env['PATH']
source = json.loads((r / 'reference-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == sha for p, sha in source['sources'].items())
jobs = [('build', [str(sdk / 'dotnet.exe'), 'build', 'Lokad.Lython.slnx', '-c', 'Release', '--no-incremental', '--disable-build-servers'])]
for framework in ['net11.0', 'net10.0']:
 jobs.append((framework, [str(sdk / 'dotnet.exe'), 'test', 'tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj', '-c', 'Release', '-f', framework, '--no-build', '--disable-build-servers', '--filter', 'FullyQualifiedName~CasedSplitOwnershipTests|FullyQualifiedName~DictionaryCountingLoopAdmissionTests']))
for label, args in jobs:
 p = r / ('restored-' + label + '.log'); assert not p.exists()
 with p.open('w', encoding='utf-8', newline='\n') as log: done = subprocess.run(args, env=env, stdout=log, stderr=subprocess.STDOUT)
 output = p.read_text(encoding='utf-8'); print(label, 'exit', done.returncode, output[-1500:], flush=True)
 assert done.returncode == 0 and 'No test matches' not in output
assert hashlib.sha256(Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll').read_bytes()).hexdigest() == source['coreSHA256']
print('Restored nonincremental core hash equals qualified d7b2ddaf; new independent regressions pass both targets.', flush=True)
