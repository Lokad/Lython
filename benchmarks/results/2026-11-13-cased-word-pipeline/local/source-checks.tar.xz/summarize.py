from pathlib import Path
import runpy
r=Path(__file__).parent
source=(r.parent/'direct-range-r293/builder-refined/summarize.py').read_text(encoding='utf-8')
exec(compile(source,str(r/'summarize.py'),'exec'),{'__file__':str(r/'summarize.py')})
