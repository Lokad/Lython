from pathlib import Path
import hashlib, json, os, shutil, subprocess, tarfile
r = Path(__file__).parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
sources = {p: sha(p) for p in subprocess.check_output(['git', 'ls-files', 'src/Lokad.Lython'], text=True).splitlines()}
assert len(sources) == 571
shutil.copytree(r / 'reference', r / 'candidate', copy_function=os.link)
(r / 'candidate/Lokad.Lython.dll').unlink()
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll', r / 'candidate/Lokad.Lython.dll')
shutil.copyfile(r / 'candidate/Lokad.Lython.dll', r / 'candidate-core.dll')
identity = dict(head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(), description='R300 one cased-text/range pipeline prototype', sources=sources, coreSHA256=sha(r / 'candidate-core.dll'), referenceSHA256=sha(r / 'reference/Lokad.Lython.dll'))
(r / 'candidate-identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8', newline='\n')
with tarfile.open(r / 'candidate-sources.tar.xz', 'w:xz') as archive:
 for p in sources: archive.add(p, arcname=p)
for name in ['diagnostic.py', 'summarize.py']:
 shutil.copyfile(r.parent / 'formatted-prefix-r296' / name, r / name)
print('R300 candidate frozen', identity['coreSHA256'], 'qualified reference', identity['referenceSHA256'], flush=True)
