from pathlib import Path
r=Path(__file__).parent
p=Path('src/Lokad.Lython/Runtime/Text/PyStringOps.Whitespace.cs');s=p.read_text(encoding='utf-8')
start=s.index('    internal static PyList SplitCasedWhitespace');end=s.index('    private static PyList SplitCore',start)
s=s[:start]+'''    internal static PyList SplitCasedWhitespace(PyString value, bool upper,
        MemoryGovernor governor, LythonSourceSpan span, LythonRuntime.ExecutionContext context)
    {
        var source = MapCase(value, upper ? CaseMapping.Upper : CaseMapping.Lower, context, span);
        PyList? result = null;
        try { return result = SplitCore(source, -1, false, governor, span, context); }
        finally
        {
            // A whole-word split may return this fresh cased string itself.
            if (result is null || result.Count != 1 || !ReferenceEquals(result[0], source))
                governor.RefundUnpublishedValue(source);
        }
    }

    // Case once into ordinary governed text, then share the plain range scanner.
    // Every eventual Python word and the borrowed backing header are prepaid
    // before any loop effect. No word borrow outlives its cursor.
    internal static CasedWhitespaceIteration PrepareCasedWhitespaceIteration(PyString value, bool upper,
        LythonRuntime.ExecutionContext context, LythonSourceSpan span)
    {
        context.CheckExecution(span);
        var governor = context.MemoryGovernor;
        var prepared = governor.RentWordRanges(8, span);
        PyString? source = null;
        var count = 0;
        try
        {
            source = MapCase(value, upper ? CaseMapping.Upper : CaseMapping.Lower, context, span);
            Span<(int Start, int End)> ranges = prepared;
            long outputBytes = 0;
            CollectWhitespaceForward(source.Utf8Span, -1, ref ranges, ref count, ref outputBytes,
                ref prepared, governor, span, context);
            var bytes = checked(160 + outputBytes); // cursor, one backing header and all eventual words
            using var storage = governor.ReserveTemporary(bytes, span);
            context.CheckExecution(span);
            var result = new CasedWhitespaceIteration(source, context, span, prepared!, count);
            storage.Commit(bytes);
            source = null;
            prepared = null;
            return result;
        }
        finally
        {
            try { if (prepared is not null) governor.ReturnWordRanges(prepared, count); }
            finally { if (source is not null) governor.RefundUnpublishedValue(source); }
        }
    }

    internal sealed class CasedWhitespaceIteration : ExecutableTemporaryValue
    {
        private PyString? _source;
        private readonly LythonRuntime.ExecutionContext _context;
        private readonly LythonSourceSpan _span;
        private (int Start, int End)[]? _ranges;
        private readonly int _count;
        private int _position;

        internal CasedWhitespaceIteration(PyString source,
            LythonRuntime.ExecutionContext context, LythonSourceSpan span,
            (int Start, int End)[] ranges, int count)
        {
            _source = source;
            _context = context;
            _span = span;
            _ranges = ranges;
            _count = count;
        }

        internal PyIterationResult MoveNext()
        {
            if (_position == _count) return PyIterationResult.End;
            var range = _ranges![_position++];
            return PyIterationResult.Yield(CreateSplitFragment(_source!.Utf8Span, range,
                _context.MemoryGovernor, _span, _context));
        }

        internal MemoryGovernor MemoryGovernor => _context.MemoryGovernor;

        // The native histogram borrows final UTF8, without a small-word buffer or
        // an eager Python value. Other consumers still receive ordinary strings.
        internal bool TryReadWord(out PreparedWord word)
        {
            word = default;
            if (_position == _count) return false;
            var range = _ranges![_position++];
            word.Source = _source;
            word.Start = range.Start;
            word.Length = range.End - range.Start;
            return true;
        }

        // Native unwind must publish the last binding without admission, a large
        // copy or a cancellation check that could replace the original failure.
        internal object Materialize(ref PreparedWord word)
            => word.Value ??= word.Source!.CreateReservedUtf8Range(word.Start, word.Length, _context.MemoryGovernor);

        public override void Dispose()
        {
            var ranges = _ranges;
            var source = _source;
            _ranges = null;
            _source = null;
            // Publish the relinquished owners before either refund can reenter.
            try { if (ranges is not null) _context.MemoryGovernor.ReturnWordRanges(ranges, _count); }
            finally { if (source is not null) _context.MemoryGovernor.RefundUnpublishedValue(source); }
        }
    }

    internal struct PreparedWord
    {
        internal object? Value;
        internal PyString? Source;
        internal int Start, Length;
    }

    internal static ReadOnlySpan<byte> PreparedWordBytes(ref PreparedWord word)
        => word.Source!.Utf8Span.Slice(word.Start, word.Length);

'''+s[end:]
s=s.replace('(int Start, int End, int Capacity)','(int Start, int End)').replace('stackalloc (int, int, int)[8]','stackalloc (int, int)[8]')
s=s.replace('        CaseMapping? casing = null, PyString? separator = null)','        PyString? separator = null)')
s=s.replace('ref prepared, governor, span, context, casing);','ref prepared, governor, span, context);')
s=s.replace('var reuseWhole = casing is null && count == 1','var reuseWhole = count == 1').replace('ranges[0].Capacity != 0','ranges[0].End != ranges[0].Start').replace('PyString.EstimateApproximateBytes(ranges[0].Capacity)','PyString.EstimateApproximateBytes(ranges[0].End - ranges[0].Start)')
s=s.replace('CreateSplitFragment(source, range, casing, governor, span, context)','CreateSplitFragment(source, range, governor, span, context)')
start=s.index('    private static PyString CreateSplitFragment');end=s.index('    private static void CollectSeparatedRanges',start)
s=s[:start]+'''    private static PyString CreateSplitFragment(ReadOnlySpan<byte> source,
        (int Start, int End) range, MemoryGovernor? governor, LythonSourceSpan? span,
        LythonRuntime.ExecutionContext? context)
    {
        var length = range.End - range.Start;
        if (length == 0) return PyString.Empty;
        var fragment = PyString.CreateReservedUtf8(length, governor);
        var bytes = fragment.UnpublishedUtf8;
        for (var copied = 0; copied < length;)
        {
            context?.CheckExecution(span);
            var chunk = Math.Min(4096, length - copied);
            source.Slice(range.Start + copied, chunk).CopyTo(bytes.Slice(copied, chunk));
            copied += chunk;
        }
        fragment.CompleteUnpublishedUtf8(length);
        return fragment;
    }

'''+s[end:]
s=s.replace('private struct WhitespaceRangeState(int maxSplit, CaseMapping? casing)','private struct WhitespaceRangeState(int maxSplit)')
s=s.replace('        internal readonly int MaximumCaseWidth = casing is null ? 0\n            : casing == CaseMapping.Lower ? 4 : Math.Max(4, MaxCaseExpansionUtf8Bytes);\n','')
s=s.replace('LythonSourceSpan? span, LythonRuntime.ExecutionContext? context, CaseMapping? casing)','LythonSourceSpan? span, LythonRuntime.ExecutionContext? context)')
s=s.replace('var state = new WhitespaceRangeState(maxSplit, casing);','var state = new WhitespaceRangeState(maxSplit);')
s=s.replace('ref prepared, governor, span, context, range.Capacity);','ref prepared, governor, span, context);')
s=s.replace('        long extraCapacity = 0;\n','')
s=s.replace('                if (!whitespace && state.MaximumCaseWidth != 0)\n                    extraCapacity += state.MaximumCaseWidth - width;\n','')
s=s.replace('range = (start, position, state.MaximumCaseWidth == 0 ? position - start\n                        : CheckCaseOutputCapacity(position - start + extraCapacity, span));','range = (start, position);')
s=s.replace('range = (start, source.Length, source.Length - start);','range = (start, source.Length);')
s=s.replace('range = (start, source.Length, state.MaximumCaseWidth == 0 ? source.Length - start\n                : CheckCaseOutputCapacity(source.Length - start + extraCapacity, span));','range = (start, source.Length);')
s=s.replace('LythonRuntime.ExecutionContext? context, int? casedCapacity = null)','LythonRuntime.ExecutionContext? context)')
s=s.replace('var outputCapacity = casedCapacity ?? end - start;','var outputCapacity = end - start;').replace('ranges[count++] = (start, end, outputCapacity);','ranges[count++] = (start, end);')
assert not any(x in s for x in ['CompactWord','MaximumCaseWidth','extraCapacity','CaseMapping? casing','range.Capacity','int Capacity)'])
p.write_text(s,encoding='utf-8',newline='\n')
p=Path('src/Lokad.Lython/Runtime/MemoryGovernor.cs');s=p.read_text(encoding='utf-8').replace('(int Start, int End, int Capacity)','(int Start, int End)');p.write_text(s,encoding='utf-8',newline='\n')
for name in ['src/Lokad.Lython/Runtime/LythonRuntime.Executable.DictionaryAccumulation.cs','src/Lokad.Lython/Runtime/PyDict.Accumulation.cs']:
 p=Path(name);s=p.read_text(encoding='utf-8').replace('CompactWord','PreparedWord').replace('TryAccumulateInlineWord','TryAccumulateUtf8Word');p.write_text(s,encoding='utf-8',newline='\n')
p=Path('src/Lokad.Lython/Runtime/Text/PyString.cs');s=p.read_text(encoding='utf-8');needle='    // Plain decoded text may share immutable storage already funded by this\n'
code='''    // The caller prepays the word shell and, once per source, the backing
    // header. Long ranges share that same owner's immutable array; short ranges
    // copy at most the inline capacity. This remains usable during native unwind.
    internal PyString CreateReservedUtf8Range(int start, int length, MemoryGovernor governor)
    {
        var content = Utf8Span.Slice(start, length);
        if (length == 0) return Empty;
        if (!ReferenceEquals(OwnerMemoryGovernor, governor))
            throw new InvalidOperationException("A reserved range must retain its source owner.");
        if (length <= InlineUtf8Capacity)
        {
            var inline = CreateReservedUtf8(length, governor);
            content.CopyTo(inline.UnpublishedUtf8);
            inline.CompleteUnpublishedUtf8(length);
            return inline;
        }
        var offset = _inlineCapacity == WindowStorage ? checked((int)_inlineUtf8[0]) : 0;
        var result = CreateReservedUtf8Window(_utf8!, checked(offset + start), length, governor);
        // Once an alias exists, source retirement relinquishes only its shell.
        // Full backing remains conservatively funded until this command ends.
        _inlineUtf8[0] = offset;
        _inlineCapacity = WindowStorage;
        return result;
    }

'''
assert s.count(needle)==1;s=s.replace(needle,code+needle)
s=s.replace('                _inlineUtf8[0] = 0;\n                _inlineCapacity = WindowStorage;\n','')
s=s.replace('var result = CreateReservedUtf8Window(_utf8!, checked((int)_inlineUtf8[0] + start), length, governor);','var result = CreateReservedUtf8Range(start, length, governor);')
p.write_text(s,encoding='utf-8',newline='\n')
print('Unified cased source/plain ranges; per-word casing, inline word buffer/cutoff and range capacity removed; existing funded windows reused.',flush=True)
