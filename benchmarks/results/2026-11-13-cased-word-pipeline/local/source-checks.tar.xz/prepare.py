from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;old=r.parent/'formatted-prefix-r296';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert subprocess.check_output(['git','status','--porcelain'],text=True)==''
sources={name:sha(name)for name in subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True).splitlines()};assert len(sources)==571
baseline=Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll');assert sha(baseline)=='d7b2ddafb1e5ff7c00152cfaa182d12c057a967a0910015d2ab80beecff9089b'
shutil.copytree(old/'candidate',r/'reference',copy_function=os.link);(r/'reference/Lokad.Lython.dll').unlink();shutil.copyfile(baseline,r/'reference/Lokad.Lython.dll')
for name in ['catalog.json']:shutil.copyfile(old/name,r/name)
shutil.copytree(old/'tool',r/'tool',copy_function=os.link)
with tarfile.open(r/'reference-sources.tar.xz','w:xz')as archive:
 for name in sources:archive.add(name,arcname=name)
(r/'reference-identity.json').write_text(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),runtimeCommit='d413392c',coreSHA256=sha(baseline),sources=sources),indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['src/Lokad.Lython/Runtime/Text/PyStringOps.Whitespace.cs','src/Lokad.Lython/Runtime/Text/PyString.cs','src/Lokad.Lython/Runtime/MemoryGovernor.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.DictionaryAccumulation.cs','src/Lokad.Lython/Runtime/PyDict.Accumulation.cs']:
 shutil.copyfile(name,r/(Path(name).name+'.before'))
print('Qualified d413392c/d7b2ddaf source/binary baseline frozen before edits; fixed seven-script worker reused.',flush=True)
