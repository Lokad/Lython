from pathlib import Path
import os, subprocess, sys
r = Path(__file__).parent
sdk = Path('C:/Users/JoannesVermorel/.dotnet11')
env = os.environ.copy()
env['DOTNET_ROOT'] = str(sdk)
env['PATH'] = str(sdk) + ';C:/Python313;' + env['PATH']
phase, label = sys.argv[1:]
names = {
 'internal': ['CasedSplitOwnership', 'WhitespaceStorageOwnership', 'DictionaryCountingLoopAdmission', 'NativeClosure', 'NativeReturn', 'StringStorage', 'StringWindowOwnership', 'WhitespaceSplitCancellation', 'DirectStringSplit', 'DirectStringLower', 'DirectStringUpper', 'StringBuilderAdmission', 'ByteBuilderOwnershipTransaction'],
 'public': ['ReturnedIteration', 'NativeClosureLifetime', 'OrderedFunctionContinuation', 'HelperContinuationLifetime', 'UnicodeString', 'SigmaContextBoundary', 'CasedWhitespacePipeline', 'CooperativeCancellation', 'StringLowerCall', 'StringUpperCall', 'SeparatedStringSplit', 'StringOwnershipAdmission', 'TextWindowValue', 'PythonWhitespace', 'RepresentativeScript']
}
if phase == 'stress':
 names = {'internal': ['NativeTextConstructionRollbackTests']}
jobs = []
for framework in (['net11.0'] if phase == 'quick' else ['net11.0', 'net10.0']):
 for suite, selected in names.items():
  project = 'Lokad.Lython.Tests' if suite == 'internal' else 'Lokad.Lython.PublicApi.Tests'
  filt = ('Category=Stress&(' if phase == 'stress' else 'Category!=Stress&(') + '|'.join('FullyQualifiedName~' + name for name in selected) + ')'
  jobs.append((suite + '-' + framework, [str(sdk / 'dotnet.exe'), 'test', f'tests/{project}/{project}.csproj', '-c', 'Release', '-f', framework, '--no-build', '--disable-build-servers', '--filter', filt]))
for name, args in jobs:
 p = r / f'{phase}-{name}-{label}.log'
 assert not p.exists()
 with p.open('w', encoding='utf-8', newline='\n') as log:
  done = subprocess.run(args, env=env, stdout=log, stderr=subprocess.STDOUT)
 output = p.read_text(encoding='utf-8')
 print(p.name, 'exit', done.returncode, flush=True)
 print(output[-14000:], flush=True)
 if done.returncode or 'No test matches' in output:
  sys.exit(done.returncode or 1)
