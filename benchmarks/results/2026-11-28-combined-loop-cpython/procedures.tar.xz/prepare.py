from hashlib import sha256
from pathlib import Path
from shutil import copy2, copytree
from subprocess import check_output
import json
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
previous = lab.parent/'current-shipment-checkpoint-b1943-20261128'
goldens = previous/'comparison/quiet'
measured = lab.parent/'direct-loop-position-b1953-20261128/comparison'
donor = measured/'quiet'
quiet = lab/'comparison/quiet'
core = 'Lokad.Lython.dll'
stage = 'script-cpython-quiet-b1954-20261128-retry'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
files = lambda path: {p.name:digest(p) for p in path.iterdir()}

def git(*args):
    return check_output(['git', *args], cwd=repo)

def save(path, data):
    path.write_text(data, encoding='utf-8', newline='\n')
    assert b'\r' not in path.read_bytes()

def write(path, data):
    save(path, json.dumps(data, indent=2) + '\n')

head = git('rev-parse', 'HEAD').decode().strip()
assert not git('status', '--porcelain')
identity = read(measured/'identity.json')
assert sha256(git('diff','--binary',identity['sourceRevision'],head,'--','src/Lokad.Lython','tests')).hexdigest()==identity['sourcePatchSHA256']
assert read(measured/'summary.json')['verifiedTimedBatches']==140
image = identity['imageFiles']['candidate']
assert len(image)==32 and files(measured/'candidate')==image
old = read(donor/'identity.json')
donor_files = old['imageFiles']['candidate']
assert len(donor_files)==32 and image==donor_files
terminal = read(donor/'terminal-status.json')
receipt = terminal['receipt']
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode']=='0'
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['quietBeforeAndAfter']
assert digest(donor/'observations.tar.xz')==receipt['archiveSHA256']
quiet.mkdir(parents=True)
copytree(measured/'candidate',quiet/'local-image')
assert files(quiet/'local-image')==image
assert all(not p.samefile(measured/'candidate'/p.name) for p in (quiet/'local-image').iterdir())
copy2(goldens/'cpython-worker.py',quiet/'cpython-worker.py')
assert digest(quiet/'cpython-worker.py')==identity['cpythonWorkerSHA256']==old['cpythonWorkerSHA256']
assert identity['expectedCPythonSHA256']==old['expectedCPythonSHA256']
assert digest(goldens/'representative.json')==read(goldens/'identity.json')['catalogs']['representative.json']['sha256']
assert digest(measured/'representative.json')==identity['catalogs']['representative.json']['sha256']
catalog=read(goldens/'representative.json')
ordinary='diagnostic.shipment-row-generator-reduction'
iterable='diagnostic.shipment-starmap-iterable-rows'
file_map='diagnostic.shipment-file-fed-map'
explicit='diagnostic.shipment-row-explicit-reduction'
report='scripts.report-render.large'
rows={r['id']:r for r in catalog['cases']}
for row in read(measured/'representative.json')['cases']:
    if row['id'] in rows: assert row==rows[row['id']]
    rows[row['id']]=row
jobs=[(ordinary,'warm'),(ordinary,'warm-async'),(iterable,'warm-async'),
      (explicit,'warm-async'),(report,'warm-async'),(file_map,'warm-async')]
catalog['cases']=[rows[key] for key in dict.fromkeys(key for key,_ in jobs)]
write(quiet/'representative.json',catalog)
write(quiet/'jobs.json',jobs)
write(quiet/'identity.json',dict(sourceRevision=head,productionHead=head,
    purpose='Refresh warm shipment, report and streaming comparisons after lookup, admission and loop-state consolidation.',
    imageFiles={'candidate':image},coreSHA256={role:image[core] for role in ('candidate','candidate-control')},
    auxiliaryFiles={name:checksum for name,checksum in image.items() if name!=core},
    frozenImage=f'/home/lokad/lython-bench-checks/{stage}/candidate',
    catalogs={name:{'sha256':digest(quiet/name)} for name in ('representative.json','jobs.json')},
    expectedCPythonSHA256=identity['expectedCPythonSHA256'],cpythonWorkerSHA256=identity['cpythonWorkerSHA256'],
    donorArchiveSHA256=receipt['archiveSHA256']))
collector=(goldens/'collect.py').read_text(encoding='utf-8')
assert collector.count('lython-b1943-cpython-fixtures')==1
save(quiet/'collect.py',collector.replace('lython-b1943-cpython-fixtures','lython-b1954-cpython-fixtures-retry'))
copy2(goldens/'run.sh',quiet/'run.sh')
paths={name:quiet/name for name in ('identity.json','representative.json','jobs.json','cpython-worker.py','run.sh','collect.py')}
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz') as archive:
    for name,path in paths.items(): archive.add(path,arcname=name)
with tarfile.open(payload) as archive:
    assert all(sha256(archive.extractfile(name).read()).hexdigest()==digest(path) for name,path in paths.items())
manifest={name:dict(length=path.stat().st_size,sha256=digest(path)) for name,path in paths.items()}
write(quiet/'upload.json',dict(root=stage,donor=read(donor/'upload.json')['root'],donorFiles=donor_files,
    donorArchive=receipt['archiveSHA256'],payloadSHA256=digest(payload),files=manifest,
    expandedBytes=sum(row['length'] for row in manifest.values()),minimumAfterStageBytes=16*1024*1024,
    caseCount=len(catalog['cases'])))
launch=(previous/'quiet-vm.py').read_text(encoding='utf-8')
assert launch.count('lython-b1943-current-cpython')==1
save(lab/'quiet-vm.py',launch.replace('lython-b1943-current-cpython','lython-b1954-combined-loop-cpython-retry'))
verify=(previous/'verify.sh').read_text(encoding='utf-8')
save(lab/'verify.sh',verify.replace(previous.name,lab.name))
summary=(previous/'summarize.py').read_text(encoding='utf-8')
save(lab/'summarize.py',summary.replace('bf10eeaead97185fa58ab558082b14f7e2ce6f1e',head)
     .replace('proof["caseCount"]==4','proof["caseCount"]==5').replace('{"donor":30}','{"donor":32}'))
print(head,len(jobs),'quiet lanes with',len(catalog['cases']),'expected output and file goldens')
