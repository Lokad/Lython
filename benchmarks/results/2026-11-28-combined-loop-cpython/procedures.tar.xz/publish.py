from hashlib import sha256
from pathlib import Path
from shutil import copy2
from subprocess import check_output
import json
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/'comparison/quiet'
initial=lab/'comparison/initial'
out=repo/'benchmarks/results/2026-11-28-combined-loop-cpython'
read=lambda path:json.loads(path.read_bytes())
digest=lambda path:sha256(path.read_bytes()).hexdigest()
identity=read(quiet/'identity.json')
summary=read(quiet/'summary.json')
revision=check_output(['git','rev-parse','2806d7d75'],cwd=repo,text=True).strip()
assert revision==identity['sourceRevision']==summary['source']
assert summary['passedQuietCheck'] and summary['timedBatches']==168 and len(summary['rows'])==6
image=identity['imageFiles']['candidate']
assert len(image)==32 and {p.name:digest(p) for p in (quiet/'local-image').iterdir()}==image
local=read(quiet/'candidate-local-verify.json')
assert local['state']=='Completed' and local['caseCount']==5
assert local['catalogSha256']==identity['catalogs']['representative.json']['sha256']
assert local['launched']['library']['sha256']==image['Lokad.Lython.dll']
assert local['launched']['adapter']['sha256']==image['Lokad.Lython.Benchmarks.dll']
assert local['launched']['python']['sha256']==identity['expectedCPythonSHA256']
failed=read(initial/'terminal-status.json')
assert not failed['live'] and not failed['fixtures'] and failed['exitCode']=='1'
assert "KeyError: 'auxiliaryFiles'" in failed['journal']
assert digest(initial/'observations.tar.xz')==failed['receipt']['archiveSHA256']
assert read(initial/'identity.json')['imageFiles']==identity['imageFiles']
assert digest(initial/'representative.json')==digest(quiet/'representative.json')
assert digest(initial/'jobs.json')==digest(quiet/'jobs.json')
out.mkdir()
for name in ('identity.json','summary.json','observations.tar.xz','terminal-status.json','stage-custody.json'):
    copy2(quiet/name,out/name)
    assert digest(quiet/name)==digest(out/name)
procedures={name:lab/name for name in ('prepare.py','quiet-vm.py','verify.sh','summarize.py','publish.py',
    'compact-reference.py','reference-compaction.json')}
for name in ('candidate-local-verify.json','candidate-remote-verify.json','launch.log','archive-receipt.json','upload.json'):
    procedures[name]=quiet/name
for name in ('identity.json','terminal-status.json','observations.tar.xz','stage-custody.json','collect.py','launch.log','quiet-vm.py'):
    procedures[f'initial/{name}']=initial/name
with tarfile.open(out/'procedures.tar.xz','w:xz') as archive:
    for name,path in procedures.items(): archive.add(path,arcname=name)
with tarfile.open(out/'procedures.tar.xz') as archive:
    assert all(digest(path)==sha256(archive.extractfile(name).read()).hexdigest() for name,path in procedures.items())
print('B1954 comparison and preserved staging receipts verified.')
