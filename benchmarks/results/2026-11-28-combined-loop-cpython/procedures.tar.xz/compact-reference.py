from hashlib import sha256
from pathlib import Path
import json
import shlex
import subprocess

lab=Path(__file__).resolve().parent
source=lab.parent/'direct-loop-position-b1953-20261128/comparison'
terminal=json.loads((source/'quiet/terminal-status.json').read_bytes())
receipt=terminal['receipt']
identity=json.loads((source/'quiet/identity.json').read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
assert not terminal['live'] and terminal['exitCode']=='0' and not terminal['fixtures']
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['archivedAndVerifiedUnderLease']
assert digest(source/'quiet/observations.tar.xz')==receipt['archiveSHA256']
assert {p.name:digest(p) for p in (source/'reference').iterdir()}==identity['imageFiles']['reference']
root='/home/lokad/lython-bench-checks/script-loop-position-repeat-b1953-20261128'
expected=identity['imageFiles']['reference']['Lokad.Lython.dll']
code=f'root_name={root!r}\nexpected={expected!r}\narchive={receipt["archiveSHA256"]!r}\n'+r'''
from hashlib import sha256
from pathlib import Path
import fcntl, gzip, json, os, shutil, subprocess

root=Path(root_name)
origin=root/'reference/Lokad.Lython.dll'
backup=root/'packed-reference-core.dll.gz'
assert root.resolve()==root and origin.resolve()==origin
assert origin.parent==root/'reference' and origin.stat().st_nlink==1
assert not (root/'guest-fixtures').exists()
digest=lambda p:sha256(p.read_bytes()).hexdigest()
with (root.parent/'comparison-vm.lock').open('r') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    state=subprocess.check_output(['systemctl','show','lython-b1953-loop-position.service','--property=ActiveState,Result'],text=True).splitlines()
    assert 'ActiveState=inactive' in state and 'Result=success' in state
    assert digest(root/'observations.tar.xz')==archive
    assert digest(origin)==expected
    before=shutil.disk_usage(root).free
    length=origin.stat().st_size
    with origin.open('rb') as source,backup.open('xb') as target:
        with gzip.GzipFile(filename='',mode='wb',fileobj=target,mtime=0) as compressed:
            shutil.copyfileobj(source,compressed)
        target.flush()
        os.fsync(target.fileno())
    with gzip.open(backup,'rb') as stored:
        assert sha256(stored.read()).hexdigest()==expected
    assert backup.stat().st_size<length
    origin.unlink()
    record=dict(archiveSHA256=archive,referenceCoreSHA256=expected,compressedSHA256=digest(backup),
        originalBytes=length,compressedBytes=backup.stat().st_size,before=before,after=shutil.disk_usage(root).free)
    (root/'reference-compaction.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(record))
'''
compile(code,'<verified reference compaction>','exec')
command=['ssh','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes','-o','IdentitiesOnly=yes',
         '-o','ConnectTimeout=12','-o','StrictHostKeyChecking=yes','lokad@20.166.121.73','python3 -c '+shlex.quote(code)]
result=subprocess.check_output(command,timeout=35)
record=json.loads(result)
assert record['referenceCoreSHA256']==expected and record['after']>record['before']
(lab/'reference-compaction.json').write_bytes(result)
print(result.decode('utf-8').strip())
