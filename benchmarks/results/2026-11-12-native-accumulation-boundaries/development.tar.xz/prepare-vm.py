from pathlib import Path
import ast,hashlib,json,shutil,tarfile
r=Path(__file__).parent;out=r/'b636';out.mkdir();old=r.parent/'json-existing-windows-r279/b634'
oldroot='/home/lokad/lython-bench-checks/json-existing-windows-b634-20261112'
root='/home/lokad/lython-bench-checks/native-boundaries-b636-20261112';unit='lython-b636-native-boundaries-20261112';oldunit='lython-b634-json-existing-windows-20261112'
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
config=json.loads((old/'config.json').read_text(encoding='utf-8'));config.update(root=root,unit=unit,retire=[])
config['identity'].update(sourceRevision=identity['head']+'; R280 native boundaries;1826focused actual-target checks; desktop phases separate',coreSHA256={k:identity['referenceSHA256'if k.startswith('reference')else'coreSHA256']for k in ['reference','reference-control','candidate','candidate-control']})
jobs=[['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','warm-async'],['scripts.csv-validated-records.large','warm'],['scripts.csv-validated-records.large','warm-async'],['scripts.report-render.large','warm']]
collect=(old/'collect.py').read_text(encoding='utf-8').replace(oldroot,root)
start=collect.index('jobs=');end=collect.index('\nenv = ',start)
collect=collect[:start]+'jobs='+repr(jobs)+"\nassert len(jobs)==5 and all(case in cases for case,lane in jobs)\n"+collect[end:]
collect=collect.replace("purpose='R279 JSON plain-token windows using existing string representation; report/JSON affected, captured-text/CSV controls; all adverse and uncertain results retained.'","purpose='R280 native accumulation boundary deletion; captured-text/CSV both APIs and report control; same stack admission/normal runtime; preserve all adversity.'")
collect=collect.replace("< 260, 'Reserve40seconds for final owned work/cleanup.'","< 310, 'Reserve50seconds for final owned work/cleanup.'")
ast.parse(collect);(out/'collect.py').write_text(collect,encoding='utf-8',newline='\n')
for name in ['archive-owned.py','run.sh','remote-launch.py','launch.py','retrieve.py','summarize.py']:
    text=(old/name).read_text(encoding='utf-8').replace(oldroot,root).replace(oldunit,unit)
    if name=='archive-owned.py':text=text.replace("==4 ","==5 ").replace('jobs=4','jobs=5')
    if name=='remote-launch.py':text=text.replace("base/'bulk-utf16-b632-20261112/candidate'","base/'json-existing-windows-b634-20261112/candidate'").replace('lython-b634-fixtures','lython-b636-fixtures').replace('jobs=4,ownerSeconds=300','jobs=5,ownerSeconds=360').replace('RuntimeMaxSec=300','RuntimeMaxSec=360')
    if name=='launch.py':text=text.replace('json-existing-windows-b634-launch.py','native-boundaries-b636-launch.py').replace('timedelta(seconds=360)','timedelta(seconds=420)').replace('ownerSeconds=300','ownerSeconds=360')
    if name=='retrieve.py':text=text.replace("['jobs']==4","['jobs']==5").replace("['elapsedSeconds']<360","['elapsedSeconds']<420").replace('B634 four-job','B636 five-job')
    if name=='summarize.py':text=text.replace("len(raw['jobs'])==4","len(raw['jobs'])==5").replace('jobs=4','jobs=5')
    if name.endswith('.py'):ast.parse(text.replace('config=CONFIG','config={}').replace('inventoryOnly=INVENTORY_ONLY','inventoryOnly=True'))
    (out/name).write_text(text,encoding='utf-8',newline='\n')
for source,target in [(r/'candidate-core.dll',out/'current-core.dll'),(r/'candidate-identity.json',out/'source-identity.json'),(r/'candidate-sources.tar.xz',out/'candidate-sources.tar.xz'),(r/'catalog.json',out/'representative.json')]:shutil.copyfile(source,target)
(out/'identity.json').write_text(json.dumps(config['identity'],indent=2)+'\n',encoding='utf-8',newline='\n')
assert hashlib.sha256((out/'representative.json').read_bytes()).hexdigest()==config['identity']['catalogSHA256']
with tarfile.open(out/'payload.tgz','w:gz')as t:
    for name in ['collect.py','archive-owned.py','run.sh','current-core.dll','source-identity.json','candidate-sources.tar.xz','representative.json','identity.json']:t.add(out/name,arcname=name)
config.update(payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest())
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(jobs=jobs,ownerSeconds=360,payloadBytes=config['payloadBytes'],sameWorkerAdapterRuntime=True)))
