from pathlib import Path
import ast,hashlib,json,shutil,tarfile
r=Path(__file__).parent;old=r/'first-form/b636';out=r/'b637';out.mkdir()
oldroot='/home/lokad/lython-bench-checks/native-boundaries-b636-20261112'
root='/home/lokad/lython-bench-checks/native-boundaries-b637-20261112';unit='lython-b637-native-kernel-boundary-20261112';oldunit='lython-b636-native-boundaries-20261112'
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
config=json.loads((old/'config.json').read_text(encoding='utf-8'));config.update(root=root,unit=unit,retire=[])
config['identity'].update(sourceRevision=identity['head']+'; R280 kernel-only refinement restores loop publication checks;1826focused checks/desktop phases separate',coreSHA256={k:identity['referenceSHA256'if k.startswith('reference')else'coreSHA256']for k in ['reference','reference-control','candidate','candidate-control']})
jobs=[['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.report-render.large','warm']]
collect=(old/'collect.py').read_text(encoding='utf-8').replace(oldroot,root)
start=collect.index('jobs=');end=collect.index('\nenv = ',start)
collect=collect[:start]+'jobs='+repr(jobs)+"\nassert len(jobs)==2 and all(case in cases for case,lane in jobs)\n"+collect[end:]
collect=collect.replace("purpose='R280 native accumulation boundary deletion; captured-text/CSV both APIs and report control; same stack admission/normal runtime; preserve all adversity.'","purpose='R280 kernel-only refinement: loop publication checks restored; original capturedRun/report adversity preserved; no source-independent retiming.'")
collect=collect.replace("< 310, 'Reserve50seconds for final owned work/cleanup.'","< 145, 'Reserve35seconds for final owned work/cleanup.'")
ast.parse(collect);(out/'collect.py').write_text(collect,encoding='utf-8',newline='\n')
for name in ['archive-owned.py','run.sh','remote-launch.py','launch.py','retrieve.py','summarize.py']:
    text=(old/name).read_text(encoding='utf-8').replace(oldroot,root).replace(oldunit,unit)
    if name=='archive-owned.py':text=text.replace("==5 ","==2 ").replace('jobs=5','jobs=2')
    if name=='remote-launch.py':text=text.replace('lython-b636-fixtures','lython-b637-fixtures').replace('jobs=5,ownerSeconds=360','jobs=2,ownerSeconds=180').replace('RuntimeMaxSec=360','RuntimeMaxSec=180')
    if name=='launch.py':text=text.replace('native-boundaries-b636-launch.py','native-boundaries-b637-launch.py').replace('timedelta(seconds=420)','timedelta(seconds=240)').replace('ownerSeconds=360','ownerSeconds=180')
    if name=='retrieve.py':text=text.replace("['jobs']==5","['jobs']==2").replace("['elapsedSeconds']<420","['elapsedSeconds']<240").replace('B636 five-job','B637 two-job')
    if name=='summarize.py':text=text.replace("len(raw['jobs'])==5","len(raw['jobs'])==2").replace('jobs=5','jobs=2')
    if name.endswith('.py'):ast.parse(text.replace('config=CONFIG','config={}').replace('inventoryOnly=INVENTORY_ONLY','inventoryOnly=True'))
    (out/name).write_text(text,encoding='utf-8',newline='\n')
for source,target in [(r/'candidate-core.dll',out/'current-core.dll'),(r/'candidate-identity.json',out/'source-identity.json'),(r/'candidate-sources.tar.xz',out/'candidate-sources.tar.xz'),(r/'catalog.json',out/'representative.json')]:shutil.copyfile(source,target)
(out/'identity.json').write_text(json.dumps(config['identity'],indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
    for name in ['collect.py','archive-owned.py','run.sh','current-core.dll','source-identity.json','candidate-sources.tar.xz','representative.json','identity.json']:t.add(out/name,arcname=name)
config.update(payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest())
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Two-job kernel-only source refinement prepared; first-form evidence retained unchanged.')
