from pathlib import Path
import ast
r=Path(__file__).parent;old=r.parent/'json-existing-windows-r279'
text=(old/'freeze.py').read_text(encoding='utf-8')
text=text.replace("old=r.parent/'bulk-utf16-r276/refined'","old=r.parent/'json-existing-windows-r279'")
text=text.replace("['src/Lokad.Lython/Runtime/LythonRuntime.Json.Deserialize.cs','src/Lokad.Lython/Runtime/Text/PyString.cs']","['src/Lokad.Lython/Runtime/LythonRuntime.Executable.DictionaryAccumulation.cs','src/Lokad.Lython/Runtime/PyDict.Accumulation.cs']")
text=text.replace('f0b736b209218dec877fc55afe58d2f881b9ddde14022b2cf9383a662f4d305d','4f57ca332a6d83b36427a37934e1d2f112089d089ad0e9aee86d4cd5ce9af941')
start=text.index('code=(old/');end=text.index("\n(tool/'Program.cs')",start)
text=text[:start]+"code=(old/'tool/Program.cs').read_text(encoding='utf-8').replace('R279 JSON tokens reuse existing immutable UTF8 windows; only same-owner plain tokens share;', 'R280 native accumulation boundary consolidation; four redundant checks and store-span transport removed;')"+text[end:]
text=text.replace('plus R279 uncommitted','plus R280 uncommitted')
ast.parse(text);(r/'freeze.py').write_text(text,encoding='utf-8',newline='\n')
for name in ['diagnostic.py','run-diagnostics.py','summarize.py']:
    text=(old/name).read_text(encoding='utf-8');ast.parse(text);(r/name).write_text(text,encoding='utf-8',newline='\n')
print('Existing snapshot/complete-script tooling adapted; fixed hash witness and worker-DLL entry retained.')
