from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent
decision=json.loads((r/'decision.json').read_text(encoding='utf-8'))
out=Path('benchmarks/results/2026-11-12-native-accumulation-boundaries');out.mkdir(exist_ok=True)
for name in ['candidate-identity.json','source-gate.md','decision.json']:shutil.copyfile(r/name,out/name)
shutil.copyfile(r/'refined-implementation.patch',r/'implementation.patch')
with tarfile.open(out/'development.tar.xz','w:xz')as t:
    for path in sorted(r.iterdir()):
        if path.is_file()and path.suffix in('.py','.log','.json','.patch','.md','.dll','.xz'):t.add(path,arcname=path.name)
    for phase in ['warm-sync','warm-async','compile','fresh']:t.add(r/phase,arcname=phase)
    for name in ['Program.cs','complete-jobs.csproj','packages.lock.json']:t.add(r/'tool'/name,arcname='tool/'+name)
    first=r/'first-form'
    for path in sorted(first.iterdir()):
        if path.is_file()and path.suffix in('.log','.json','.dll','.xz'):t.add(path,arcname='first-form/'+path.name)
    for phase in ['warm-sync','warm-async','compile','fresh']:t.add(first/phase,arcname='first-form/'+phase)
    for name in ['Program.cs','complete-jobs.csproj','packages.lock.json']:t.add(first/'tool'/name,arcname='first-form/tool/'+name)
for source,name in [(r/'first-form/b636','b636'),(r/'b637','b637')]:
    target=out/name;target.mkdir(exist_ok=True)
    for filename in ['observations.tgz','archive-receipt.json','summary.json','terminal-status.json','inventory.json','extraction.json']:shutil.copyfile(source/filename,target/filename)
    with tarfile.open(target/'preparation.tar.xz','w:xz')as t:
        for filename in ['collect.py','archive-owned.py','remote-launch.py','launch.py','launch-command.py','launch.log','retrieve.py','summarize.py','config.json','observe-not-before.json']:t.add(source/filename,arcname=filename)
files={p.relative_to(out).as_posix():dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())for p in out.rglob('*')if p.is_file()and p.name not in('manifest.json','README.md')}
(out/'manifest.json').write_text(json.dumps(files,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Source/cores/commands/focused checks/desktop adversity and controlled observations archived.')
