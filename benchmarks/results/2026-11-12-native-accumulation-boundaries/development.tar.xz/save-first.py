from pathlib import Path
import shutil
r=Path(__file__).parent.resolve();workspace=Path('D:/code/Lython').resolve();out=(r/'first-form').resolve()
assert r.is_relative_to(workspace)and out.parent==r
out.mkdir()
for path in list(r.iterdir()):
    if path.name=='first-form':continue
    if path.name in ['reference','candidate','tool','warm-sync','warm-async','compile','fresh','b636']or path.is_file()and path.suffix in('.dll','.xz','.json','.log'):
        target=(out/path.name).resolve();assert path.resolve().parent==r and target.parent==out
        shutil.move(str(path),str(target))
print('First source/core/diagnostics/controlled adversity preserved; no VM users remain.')
