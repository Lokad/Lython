from pathlib import Path
p=Path('PLAN.md');text=p.read_text(encoding='utf-8')
start=text.index('| Fully qualified production |');end=text.index('\n',start)
text=text[:start]+'| Fully qualified production | `b3369e3e`, GREEN43281710944: Windows/Ubuntu, actual.NET11/10, original stress, installed Release consumers. All568 frozen measured sources match. Includes R269–R279; [latest delivery](benchmarks/results/2026-11-12-json-existing-windows/delivery/README.md). Later R280 prototypes are not qualified by this run. |'+text[end:]
text=text.replace('| R279 committed; delivery active |','| R279 delivered |').replace('Full delivery43281710944 dispatched; fully qualified base remains41bd869b.','Full delivery43281710944 passes; original uncertainties remain.')
start=text.index('1. **R279 retained-source delivery.**');end=text.index('2. **R280 native accumulation',start)
text=text[:start]+text[end:]
text=text.replace('2. **R280 native accumulation','1. **R280 native accumulation').replace('3. **R278 redesign','2. **R278 redesign').replace('4. **Independent regex','3. **Independent regex')
text=text.replace('after retention; don\'t wait for the independent R279 CI.','after retention; R279 CI is now terminal GREEN and cached.')
text=text.replace('  Reader/range and R276encoder stages delivered; preserve','  Reader/range, R276encoder and R279token-storage stages delivered; preserve')
p.write_text(text,encoding='utf-8',newline='\n')
print('PLAN records exact R279 qualification, independent of current R280 prototype.')
