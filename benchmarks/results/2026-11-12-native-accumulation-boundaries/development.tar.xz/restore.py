from pathlib import Path
import hashlib,io,json,os,subprocess,tarfile
r=Path(__file__).parent;workspace=Path('D:/code/Lython').resolve()
paths=['src/Lokad.Lython/Runtime/LythonRuntime.Executable.DictionaryAccumulation.cs','src/Lokad.Lython/Runtime/PyDict.Accumulation.cs','tests/Lokad.Lython.Tests/DictionaryIntegerValueTests.cs']
(r/'refined-implementation.patch').write_bytes(subprocess.check_output(['git','diff','--',*paths]))
for name in paths:
    target=(workspace/name).resolve();assert target.is_relative_to(workspace)and target.is_file()
    target.write_bytes(subprocess.check_output(['git','show','HEAD:'+name]))
archive=subprocess.check_output(['git','archive','HEAD','src/Lokad.Lython']);rows=[]
with tarfile.open(fileobj=io.BytesIO(archive))as t:
    for m in t.getmembers():
        if not m.isfile()or not m.name.endswith('.cs'):continue
        actual=Path(m.name).read_bytes();committed=t.extractfile(m).read()
        assert actual.replace(b'\r\n',b'\n')==committed.replace(b'\r\n',b'\n'),m.name
        rows.append(dict(path=m.name,currentSHA256=hashlib.sha256(actual).hexdigest(),committedNormalizedSHA256=hashlib.sha256(committed.replace(b'\r\n',b'\n')).hexdigest()))
assert len(rows)==568
(r/'restoration.json').write_text(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),sourceCount=len(rows),allMatchWithExplicitNewlineNormalization=True,sources=rows),indent=2)+'\n',encoding='utf-8',newline='\n')
sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
commands=[('restored-build',[str(sdk/'dotnet.exe'),'build','Lokad.Lython.slnx','-c','Release','--no-incremental'])]
for framework in ['net11.0','net10.0']:
    for label,project,filter in [('internal','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','Category!=Stress&(FullyQualifiedName~DictionaryIntegerValue|FullyQualifiedName~DictionaryCountingLoopAdmission)'),('public','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','Category!=Stress&(FullyQualifiedName~DictionaryCountingLoopTests|FullyQualifiedName~CooperativeCancellationTests)')]:
        commands.append(('restored-'+label+'-'+framework,[str(sdk/'dotnet.exe'),'test',project,'-c','Release','-f',framework,'--no-build','--filter',filter]))
for label,args in commands:
    log=r/(label+'.log');assert not log.exists()
    with log.open('w',encoding='utf-8',newline='\n')as output:done=subprocess.run(args,env=env,stdout=output,stderr=subprocess.STDOUT)
    print('\n'.join(log.read_text(encoding='utf-8').splitlines()[-6:]),flush=True)
    assert done.returncode==0,label
print('Exact qualified production restored, nonincrementally rebuilt and focused checks passed; no dormant prototype.',flush=True)
