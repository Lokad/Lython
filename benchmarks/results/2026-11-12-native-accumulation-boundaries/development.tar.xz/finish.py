from pathlib import Path
import hashlib,json,re,subprocess
r=Path(__file__).parent
proof=json.loads((r/'restoration.json').read_text(encoding='utf-8'))
assert proof['allMatchWithExplicitNewlineNormalization'] and proof['sourceCount']==568
for name,count in [('internal',13),('public',50)]:
    for framework in ['net11.0','net10.0']:
        text=(r/f'restored-{name}-{framework}.log').read_text(encoding='utf-8')
        assert re.search(r'Failed:\s+0, Passed:\s+'+str(count)+r',',text)
assert '0 Error(s)' in (r/'restored-build.log').read_text(encoding='utf-8')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')
start=s.index('1. **R280 native accumulation boundary consolidation.**')
end=s.index('2. **R278 redesign selection:',start)
s=s[:start]+s[end:]
s=s.replace('2. **R278 redesign selection:', '1. **Whole-script redesign selection:')
s=s.replace('3. **Independent regex development/qualification.**','2. **Independent regex development/qualification.**')
line='| R280 withdrawn | Both native accumulator check/span forms restored to qualified production. Initial captured-text elapsed+3..6%/CPU+2..5%; narrower confirmation remains inconclusive, allocation flat. No larger mechanism removed, so retention is not justified. 1826focused checks per form; restored-source build and126checks pass. [Original adversity and refinement](benchmarks/results/2026-11-12-native-accumulation-boundaries/README.md). No permanent design ban. |\n'
s=s.replace('| External checkpoint complete |',line+'| External checkpoint complete |')
p.write_text(s,encoding='utf-8',newline='\n')
p=Path('benchmarks/results/2026-11-12-native-accumulation-boundaries/README.md')
s=p.read_text(encoding='utf-8').replace('31.74% and compilation','+31.74% and compilation')
s=s.replace('focused restored-source checks are recorded','126 focused restored-source checks (13internal/50public per actual target) are recorded')
p.write_text(s,encoding='utf-8',newline='\n')
subprocess.run(['python','-X','utf8',str(r/'archive.py')],check=True)
for directory in [Path('benchmarks/results/2026-11-12-native-accumulation-boundaries'),Path('benchmarks/results/2026-11-12-json-existing-windows/delivery')]:
    data=json.loads((directory/'manifest.json').read_text(encoding='utf-8'))
    for name,item in data.items():
        path=directory/name
        assert path.stat().st_size==item['bytes'],name
        assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256'],name
    print(directory,': verified',len(data),'files')
print('Qualified source restored, 126 checks passed; active plan condensed.')
