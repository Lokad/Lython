from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;old=r.parent/'json-existing-windows-r279'
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
baseline=json.loads((old/'candidate-identity.json').read_text(encoding='utf-8'))
assert len(baseline['sources'])==568
source={p:digest(Path(p))for p in baseline['sources']}
changed=[p for p,h in source.items()if Path(p).read_bytes().replace(b'\r\n',b'\n')!=subprocess.check_output(['git','show','HEAD:'+p]).replace(b'\r\n',b'\n')]
assert sorted(changed)==['src/Lokad.Lython/Runtime/LythonRuntime.Executable.DictionaryAccumulation.cs','src/Lokad.Lython/Runtime/PyDict.Accumulation.cs'],changed
for name in ['reference','candidate']:
    assert not(r/name).exists();shutil.copytree(old/'candidate',r/name,copy_function=os.link)
assert digest(r/'reference/Lokad.Lython.dll')=='4f57ca332a6d83b36427a37934e1d2f112089d089ad0e9aee86d4cd5ce9af941'
(r/'candidate/Lokad.Lython.dll').unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'candidate/Lokad.Lython.dll')
shutil.copyfile(r/'reference/Lokad.Lython.dll',r/'before-core.dll')
shutil.copyfile(r/'candidate/Lokad.Lython.dll',r/'candidate-core.dll')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as t:
    for p in source:t.add(p,arcname=p)
(r/'candidate-identity.json').write_text(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()+' plus R280 uncommitted',sources=source,coreSHA256=digest(r/'candidate-core.dll'),referenceSHA256=digest(r/'before-core.dll'),changed=changed),indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(old/'catalog.json',r/'catalog.json')
tool=r/'tool';tool.mkdir()
for name in ['complete-jobs.csproj','packages.lock.json']:shutil.copyfile(old/'tool'/name,tool/name)
code=(old/'tool/Program.cs').read_text(encoding='utf-8').replace('R279 JSON tokens reuse existing immutable UTF8 windows; only same-owner plain tokens share;', 'R280 kernel-only boundary refinement; two repeated checks/store-span transport removed; loop publication boundaries retained;')
(tool/'Program.cs').write_text(code,encoding='utf-8',newline='\n')
env=os.environ.copy();sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
with(r/'build-driver.log').open('w',encoding='utf-8',newline='\n')as log:
    done=subprocess.run([str(sdk/'dotnet.exe'),'build',str(tool/'complete-jobs.csproj'),'-c','Release','-f','net11.0','--no-incremental'],env=env,stdout=log,stderr=subprocess.STDOUT)
assert done.returncode==0,(r/'build-driver.log').read_text(encoding='utf-8')
assert all(digest(Path(p))==h for p,h in source.items())
print(json.dumps(dict(sources=len(source),changed=changed,core=digest(r/'candidate-core.dll'),baseline=digest(r/'before-core.dll'),driverBuilt=True)))
