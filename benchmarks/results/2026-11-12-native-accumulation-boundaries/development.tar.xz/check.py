from pathlib import Path
import os,subprocess,sys
r=Path(__file__).parent;sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
dotnet=str(sdk/'dotnet.exe');label=sys.argv[1]
if label=='build':args=[dotnet,'build','Lokad.Lython.slnx','-c','Release','--no-incremental']
else:
    suite,framework=label.split('-');assert suite in ('internal','public')and framework in ('net11.0','net10.0')
    project='tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj'if suite=='internal'else'tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj'
    names='Dictionary|NativeWord|NativeInteger|NativeIteration|CasedWhitespace|CooperativeCancellation|ReturnedIteration|NativeCallbackUnwind'
    filter='Category!=Stress&('+ '|'.join('FullyQualifiedName~'+name for name in names.split('|'))+')'
    args=[dotnet,'test',project,'-c','Release','-f',framework,'--no-build','--filter',filter]
p=r/(label+'.log');assert not p.exists()
with p.open('w',encoding='utf-8',newline='\n')as log:done=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
print('\n'.join(p.read_text(encoding='utf-8').splitlines()[-24:]),flush=True);raise SystemExit(done.returncode)
