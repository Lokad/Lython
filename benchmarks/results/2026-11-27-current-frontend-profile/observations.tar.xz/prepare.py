from hashlib import sha256
from pathlib import Path
import json
import os
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
notes = lab.parent
repo = lab.parents[3]
quiet = lab / 'comparison/quiet'
quiet.mkdir(parents=True)
template = notes / 'current-json-read-export-profile-20261127'
donor_lab = notes / 'csv-dictwriter-native-validation-20261127'
donor = donor_lab / 'comparison/quiet-cpython'
donor_name = 'csv-dictwriter-cpython-b1869-20261127'
unit = 'lython-b1875-current-frontend-profile-20261127'
root_name = 'current-frontend-profile-b1875-20261127'
python = Path('C:/Python313/python.exe')
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: sha256(p.read_bytes()).hexdigest()
write = lambda p, contents: p.write_text(contents, encoding='utf-8', newline='\n')
save = lambda p, value: write(p, json.dumps(value, ensure_ascii=False, indent=2) + '\n')

head = subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
measured = subprocess.check_output(['git','rev-parse','6e59cd41e'],cwd=repo,text=True).strip()
changed = subprocess.check_output(['git','diff','--name-only',measured,head,'--','src','benchmarks/scripts'],cwd=repo,text=True).splitlines()
assert changed == ['src/Lokad.Lython/Runtime/LythonRuntime.CsvDictWriter.cs',
                   'src/Lokad.Lython/Runtime/LythonRuntime.Json.Encoder.cs']
assert not subprocess.check_output(['git','status','--porcelain','--','src','benchmarks/scripts'],cwd=repo)
donor_id = read(donor / 'identity.json')
receipt = read(donor / 'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['quietBeforeAndAfter']
assert sha(donor / 'observations.tar.xz') == receipt['archiveSHA256']
patch = subprocess.check_output(['git','diff','--binary',donor_id['sourceRevision'],measured,'--','src'],cwd=repo)
assert sha256(patch).hexdigest() == donor_id['sourcePatchSHA256']
files = donor_id['imageFiles']['candidate']
image = donor_lab / 'comparison/local/candidate'
assert len(files) == 32 and {p.name:sha(p) for p in image.iterdir()} == files

catalog = read(notes / 'private-compiler-slots-20261127/representative.json')
ordinary = next(case for case in catalog['cases'] if case['id']=='diagnostic.generated-ordinary-definitions')
guard = next(case for case in catalog['cases'] if case['id']=='diagnostic.generated-guarded-report')
escaped = dict(ordinary)
verbs = ('    return rule_0, rule_48, rule_95\n', '    first, middle, last = build(offset)\n')
changed_source = ordinary['source']
assert all(changed_source.count(marker)==1 for marker in verbs)
changed_source = changed_source.replace(verbs[0], '    return (' + ', '.join(f'rule_{i}' for i in range(96)) + ')\n')
changed_source = changed_source.replace(verbs[1], '    rules = build(offset)\n    first, middle, last = rules[0], rules[48], rules[95]\n')
escaped.update(id='diagnostic.generated-escaping-definitions',source=changed_source,
    sourceSha256=sha256(changed_source.encode()).hexdigest(),sourceUtf8Bytes=len(changed_source.encode()))
for case in (ordinary,escaped,guard):
    output = subprocess.check_output([python,'-I','-X','utf8','-c',case['source']],cwd=repo,timeout=15).decode('utf-8').replace('\r\n','\n')
    assert output==case['expectedOutput'] and sha256(output.encode()).hexdigest()==case['expectedOutputSha256']
worker = donor_lab / 'comparison/local/cpython-worker.py'
assert sha(worker)==donor_id['cpythonWorkerSHA256']
catalog['cases'] = [ordinary,escaped,guard]
save(quiet/'catalog.json',catalog)
profiles = [['ordinary-definitions-compile',ordinary['id'],'candidate'],
    ['escaping-definitions-compile',escaped['id'],'candidate'],
    ['guarded-report-through',guard['id'],'candidate']]
identity = dict(sourceRevision=measured,inspectedHead=head,sourceDifference=changed,imageFiles={'candidate':files},
    coreSHA256={'candidate':files['Lokad.Lython.dll']},donorArchiveSHA256=receipt['archiveSHA256'],
    profileCatalogSHA256=sha(quiet/'catalog.json'),profiles=profiles,
    cases=[{'id':c['id'], 'sourceBytes':c['sourceUtf8Bytes'], 'definitions':c['size']} for c in catalog['cases']],
    verificationPythonVersion=subprocess.check_output([python,'--version'],text=True).strip(),
    verificationPythonSHA256=sha(python),
    purpose='Find an eliminable frontend pass or representation on generated script compilation.')
save(quiet/'identity.json',identity)
for name in ('collect.py','ops-profile.py','run.sh','analyze.py'):
    source=(template/'comparison/quiet'/name).read_text(encoding='utf-8')
    if name=='collect.py':
        assert source.count(donor_name)==2
        source=source.replace('b1871-fixtures','b1875-fixtures')
    if name.endswith('.py'): compile(source,name,'exec')
    write(quiet/name,source)
assert b'\r' not in (quiet/'run.sh').read_bytes()
source=(template/'quiet.py').read_text(encoding='utf-8')
source=source.replace('lython-b1871-current-json-read-export-profile-20261127',unit)
assert unit in source
compile(source,'quiet.py','exec')
write(lab/'quiet.py',source)
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
proof=quiet/'verification.json'
subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'catalog.json',
    '--dotnet',dotnet,'--python',python,'--python-worker',worker,'--out',proof],
    cwd=repo,env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk)),check=True,timeout=65)
report=read(proof)
assert report['state']=='Completed' and report['caseCount']==3
assert report['catalogSha256']==identity['profileCatalogSHA256'] and report['launched']['library']['sha256']==files['Lokad.Lython.dll']
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz') as package:
    for name in ('identity.json','catalog.json','collect.py','ops-profile.py','run.sh'):
        package.add(quiet/name,arcname=name,recursive=False)
save(quiet/'upload.json',dict(root=root_name,payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size,
    expectedDonorArchiveSHA256=receipt['archiveSHA256']))
print(identity['cases'], payload.stat().st_size)
