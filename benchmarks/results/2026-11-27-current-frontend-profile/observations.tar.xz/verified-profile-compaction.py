from pathlib import Path,PurePosixPath
import hashlib,json,re,subprocess,tarfile

lab=Path(__file__).resolve().parent
results=lab.parents[3]/'benchmarks/results'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
checks=('current-json-read-export-profile','current-shipment-cpu','current-short-script-profile',
        'paired-shipment-api-cpu','post-cpython-shipment-cpu','direct-regex-cpu')
archives=[]
for check in checks:
    root=results/('2026-11-27-'+check)
    status=read(root/'terminal-status.json')
    receipt=status['receipt']
    source=root/'observations.tar.xz'
    raw=hashlib.sha256(source.read_bytes()).hexdigest()
    assert status['exitCode']=='0' and not status['live'] and not status['fixtures']
    assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
    assert raw==receipt['archiveSHA256']
    journal=status.get('journal','')
    stage,=set(re.findall(r'/home/lokad/lython-bench-checks/([a-z0-9-]+)/(?:run\.sh|guest-fixtures)',journal))
    unit,=set(re.findall(r'lython-b[0-9][a-z0-9-]*\.service',journal))
    with tarfile.open(source) as packed:
        files={}
        for m in packed.getmembers():
            relative=PurePosixPath(m.name)
            if m.isfile() and m.size>=32768 and relative.parts[0]=='profiles':
                assert len(relative.parts)==3 and '..' not in relative.parts
                files[m.name]=dict(bytes=m.size,sha256=hashlib.file_digest(packed.extractfile(m),'sha256').hexdigest())
    archives.append(dict(stage=stage,unit=unit,raw=raw,files=files))
# Leave space for ext4 directory and journal growth as well as the raw trace.
config=dict(archives=archives,threshold=12*1024*1024)
remote=r'''
from pathlib import Path
import fcntl,hashlib,json,shutil,stat,subprocess,tarfile
base=Path('/home/lokad/lython-bench-checks')
assert base.resolve()==base
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 before=shutil.disk_usage(base).free
 target=before
 verified=[]
 for item in cfg['archives']:
  if target>=cfg['threshold']:break
  root=base/item['stage']
  assert root.resolve()==root and root.parent==base
  status=subprocess.run(['systemctl','show',item['unit'],'--property=ActiveState,MainPID'],
                        capture_output=True,text=True).stdout.splitlines()
  assert 'ActiveState=inactive' in status and 'MainPID=0' in status,status
  rec=json.loads((root/'archive-receipt.json').read_text())
  assert rec['complete'] and rec['allWorkersJoined'] and rec['guestFixturesRemoved']
  raw=root/'observations.tar.xz'
  assert raw.resolve()==raw and rec['archiveSHA256']==item['raw']==sha(raw)
  with tarfile.open(raw) as packed:
   for name,claim in item['files'].items():
    path=root/name
    assert path.resolve()==path and path.is_relative_to(root/'profiles')
    if not path.exists():continue
    st=path.lstat()
    assert stat.S_ISREG(st.st_mode) and st.st_nlink==1 and st.st_size==claim['bytes']
    assert sha(path)==claim['sha256']==hashlib.file_digest(packed.extractfile(name),'sha256').hexdigest()
    verified.append((path,dict(path=str(path.relative_to(base)),bytes=st.st_size,
                               sha256=claim['sha256'],archiveSHA256=item['raw'])))
    target+=st.st_size
    if target>=cfg['threshold']:break
 assert target>=cfg['threshold'],(before,target,cfg['threshold'])
 for path,row in verified:path.unlink()
 print(json.dumps(dict(before=before,after=shutil.disk_usage(base).free,minimum=cfg['threshold'],
                       compacted=[row for _,row in verified])))
'''
cmd=['ssh','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes','-o','ConnectTimeout=12',
     'lokad@20.166.121.73','python3 -']
result=subprocess.run(cmd,input='cfg='+repr(config)+'\n'+remote,encoding='utf-8',capture_output=True,timeout=48)
(lab/'comparison/quiet/storage-custody.log').write_text(result.stdout+result.stderr,encoding='utf-8')
print(result.stderr if result.returncode else json.dumps({k:v for k,v in json.loads(result.stdout).items() if k!='compacted'}))
result.check_returncode()
