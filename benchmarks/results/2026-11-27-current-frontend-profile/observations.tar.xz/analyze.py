from collections import Counter
from pathlib import Path
import json

phases=(
    ("executable emission and finalization", ("ExecutableScript","ExecutableStackLayout","ExecutableCodeObject")),
    ("parsing", ("Frontend.Parser",)),
    ("tokenization", ("PythonTokenization.Read","TokenizedSource","Lexer","TokenScanner")),
    ("syntax validation", ("SyntaxValidityDiagnostics",)),
    ("lexical preparation", ("LexicalScopePreparation","ScopeDirectiveFactsCollector")),
    ("annotation analysis", ("AnnotationDiagnostics",)),
    ("abstract analysis", ("StaticAbstractInterpreter",)),
    ("name binding diagnostics", ("StaticNameBindingDiagnostics",)),
    ("other static analysis", ("StaticAnalyzer","StaticAnalysisContext","StaticScopeDirectiveDiagnostics")),
)

lab=Path(__file__).resolve().parent
roots=("LythonFrontend.Compile(","LythonEngine.Compile(","ExecutableScript.Compile(","LythonEngine.CompileWith")
def symbol(name):return name.split("(",1)[0].split("!",1)[-1]

def describe(path):
    data=json.loads(path.read_text(encoding="utf-8-sig"))
    names=[row["name"]for row in data["shared"]["frames"]]
    active=0.0
    intervals=0
    function=Counter()
    exclusive=Counter()
    collections=Counter()
    partition=Counter()
    phase_nearest={}
    other=0.0
    for profile in data["profiles"]:
        assert profile["unit"]=="milliseconds"and profile["type"]=="evented"
        frames=[]
        last=profile["startValue"]
        for event in profile["events"]:
            now=event["at"]
            elapsed=now-last
            if elapsed>0 and frames and not any(any(mark in name for mark in roots)for name in frames):
                other+=elapsed
            if elapsed>0 and frames and any(any(mark in name for mark in roots)for name in frames):
                active+=elapsed
                intervals+=1
                exclusive[symbol(frames[-1])]+=elapsed
                frontend=[symbol(name) for name in frames if "Lokad.Lython.Frontend." in name]
                phase=next((phase for phase,marks in phases if any(mark in frame for frame in frontend for mark in marks)),
                           "other compilation")
                partition[phase]+=elapsed
                if frontend: phase_nearest.setdefault(phase,Counter())[frontend[-1]]+=elapsed
                function.update({symbol(name):elapsed for name in set(frames)if "Lokad.Lython.Frontend."in name})
                for i,name in enumerate(frames):
                    if "HashSet" in name and "ConstructFrom" in name:
                        caller=next((symbol(f)for f in reversed(frames[:i])if "Lokad.Lython.Frontend."in f),"unresolved")
                        collections[caller]+=elapsed
            if event["type"]=="O":frames.append(names[event["frame"]])
            else:assert frames.pop()==names[event["frame"]]
            last=now
        assert not frames
    return dict(script=path.parent.name,managedCompileThreadMilliseconds=active,intervals=intervals,
                compilerAncestry=function.most_common(40),exclusive=exclusive.most_common(25),
                hashSetCopyCallers=collections.most_common(12), phases=partition.most_common(),
                nearestFrontendByPhase={phase: methods.most_common(25) for phase,methods in phase_nearest.items()},
                representedThreadMillisecondsOutsideCompilation=other)

rows=[describe(lab/role/"compile.speedscope.json")for role,_,_ in json.loads((lab/"identity.json").read_bytes())["profiles"]]
(lab/"attribution.json").write_text(json.dumps(dict(rows=rows,comparisonQualified=False),indent=2)+"\n",encoding="utf-8",newline="\n")
for row in rows:
    print(row["script"],round(row["managedCompileThreadMilliseconds"],1),row["intervals"])
    print("  phases",[(phase,round(ms,1)) for phase,ms in row["phases"]])
    for n,v in row["compilerAncestry"][:10]:print("  ",round(v,1),n)
    print("  copies",row["hashSetCopyCallers"])
