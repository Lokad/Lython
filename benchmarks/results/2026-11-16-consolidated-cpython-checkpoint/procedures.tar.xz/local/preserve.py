from pathlib import Path
import hashlib,json,shutil,tarfile

r=Path(__file__).resolve().parent; repo=Path('D:/code/Lython'); q=r/'quiet'
out=repo/'benchmarks/results/2026-11-16-consolidated-cpython-checkpoint'
summary=json.loads((r/'summary.json').read_text(encoding='utf-8'))
receipt=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'))
raw=json.loads((q/'retrieved/confirmation/confirmation.json').read_text(encoding='utf-8'))
assert summary['complete'] and receipt['jobs']==12 and len(raw['jobs'])==12
assert receipt['quietBeforeAndAfter'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved'] and receipt['archivedAndVerifiedUnderLease']
assert hashlib.sha256((q/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
assert hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest()=='36c0a5284b7a9301cf835367fbd7ba0c2c57bbc45f886692e6a3f94a41e26055'
for job in raw['jobs']:
 assert job['workersJoinedAndFixturesRemoved']
 for label,i in job['identities'].items():
  assert i['catalogSha256']=='36c0a5284b7a9301cf835367fbd7ba0c2c57bbc45f886692e6a3f94a41e26055'
  if label.startswith('CPython'): assert i['version'].startswith('3.13.16') and i['gcEnabled'] and i['gilEnabled']
out.mkdir(exist_ok=False)
for n in ['identity.json','observations.tgz','archive-receipt.json','terminal-status.json']: shutil.copyfile(q/n,out/n)
shutil.copyfile(r/'summary.json',out/'summary.json')
guide=repo/'docs/BENCHMARKS.md'; shutil.copyfile(guide,out/'prior-BENCHMARKS.md')
with tarfile.open(out/'procedures.tar.xz','w:xz') as a:
 for p in sorted(r.iterdir()):
  if p.is_file() and p.name!='catalog.json': a.add(p,arcname='local/'+p.name)
 for p in sorted(q.iterdir()):
  if p.is_file() and p.name not in ['observations.tgz','payload.tgz']: a.add(p,arcname='quiet/'+p.name)
 a.add(r/'catalog.json',arcname='catalog.json')
labels={'scripts.csv-invoice.large':'CSV invoice','scripts.text-normalization.large':'Text normalization','scripts.json-summary-helpers.large':'JSON-lines aggregation','scripts.file-search.large.protected':'File search / defensive helper'}
inputs={'scripts.csv-invoice.large':'4,096 records / 127,031 B','scripts.text-normalization.large':'4,096 lines / 52,224 B','scripts.json-summary-helpers.large':'4,096 records / 110,592 B','scripts.file-search.large.protected':'2,049 lines / 42,010 B; stop at 1,025'}
span=lambda m,a,b:f'{min(m[a],m[b]):.3f}–{max(m[a],m[b]):.3f}'
status=lambda x:f'Diagnostic; controls L/C {x["lythonControlPercent"]:.2f}/{x["cpythonControlPercent"]:.2f}%; IQR≤{x["maxIqrPercent"]:.2f}%'
tail=lambda x:f'{span(x["medianMilliseconds"],"candidate","candidate-control")} ms | {span(x["medianMilliseconds"],"CPython","CPython-control")} ms | {min(x["ratioRange"]):.2f}–{max(x["ratioRange"]):.2f}× | {status(x)} |'
warm=[];phases=[];allrows=[]
for x in summary['timing']:
 if x['lane']=='warm': warm.append(f'| {labels[x["case"]]} | {inputs[x["case"]]} | '+tail(x))
 else: phases.append(f'| {labels[x["case"]]} | '+('Compilation only' if x['lane']=='compile' else 'Compile and execute once')+' | '+tail(x))
 allrows.append(f'| {labels[x["case"]]} | {x["lane"]} | '+tail(x))
(out/'README.md').write_text('''# Consolidated-runtime representative CPython checkpoint

R451/B854,2026-11-16UTC,committed R45081f60210/frozen a44f65a8 versus stock
CPython3.13.16. Production source matches the final cursor-consolidation snapshot;
its full delivery qualification is recorded separately. Complete CSV,text,JSON
and early-exit file scripts use the existing six-case catalog36c0a528. Only these
four cases are measured; configuration/report retain their named earlier evidence.
Both frozen-worker and CPython preflight pass all six cases before staging.

| Script | Phase | Lython | CPython | Lython / CPython | Status |
| --- | --- | ---: | ---: | ---: | --- |
'''+ '\n'.join(allrows)+'''

Above one means Lython is slower. Four independent-process median combinations
are ranges,not confidence intervals. Normalization CPython copies move10.85%,
making the precise warm ratio uncertain; both still show a substantial gap.
CSV remains slower and JSON faster in this fixture; search has2.79/2.98%control
movement. JSON fresh CPython moves3.22%,normalization fresh Lython3.48%.
All adverse pairings,IQRs,raw observations and earlier measurements are retained.
These are external ratios,not causal gains from previous Lython source revisions.

Twelve jobs400.971s,two independent processes per engine,5s full-request warmups
and five rotated approximately0.5s samples. Identical catalog bytes in all jobs;
candidate image32files frozen after nonincremental build,corea44f65a8,normal
optional adapter0.4.0. Reused immutable image verified before/after; no worker or
fixture change. Quiet AzureF4as_v7/Ubuntu24.04.4,four AMD EPYC9V45vCPUs,16GiB/no
swap,.NET11RC3normal tiering/workstation GC,CPython GIL/GC. Image/Ready/golden/
quiet/Closed/exit/join/archive gates pass. No runtime changes for this checkpoint.

Warm includes synchronous Run,mediated RAM I/O,complete stdout/file checks and
prior-result cleanup. Excludes compilation/startup,fixture reset/protocol and
final cache teardown. Compile includes construction/compiled-owner disposal;
compile-to-result adds one execution and disposal. Independently warmed phases
are not additive. Wider process CPU includes reset/protocol. CPython uses native
buffered files without equivalent host-capability/shared-budget containment.
No startup,pending-I/O,heap/RSS,contention or embedding-tail claim.

All users joined/RAM fixtures removed; archive SHAverified persistently under
lease before teardown. Terminal cached forever. Only B852/B853working raw JSON
replicas,total978,877B,were retired after equality to committed canonical archive
members plus fresh UID/path/hash/nlink/all-alias proof. All adverse canonicals,
selected images/toolchains and254/252MiB staging/final floors remain.

The current guide refreshes four workloads and their phases. Earlier config/report
rows remain identified as312f5911/0443b5cf. Earlier normalization CPython0.73→0.50ms
shift remains unexplained; this collection's moving unchanged CPython control is
additional uncertainty,not its explanation. No automatic repeat to obtain a
preferred sign. Performance work continues; publication/tagging remain held.

[Summary](summary.json),[exact images/conditions](identity.json),
[all raw observations](observations.tgz),[procedures/preflight/custody](procedures.tar.xz),
[preceding guide](prior-BENCHMARKS.md),[runtime source/evidence](../2026-11-16-native-consumer-consolidation/README.md).
''',encoding='utf-8',newline='\n')
s=guide.read_text(encoding='utf-8');lines=s.splitlines()
for row in warm:
 prefix=' | '.join(row.split(' | ')[:2])+' | '
 matches=[i for i,line in enumerate(lines) if line.startswith(prefix)]
 assert len(matches)==1,(prefix,matches)
 lines[matches[0]]=row
for row in phases:
 prefix=' | '.join(row.split(' | ')[:2])+' | '
 matches=[i for i,line in enumerate(lines) if line.startswith(prefix)]
 assert len(matches)==1,(prefix,matches)
 lines[matches[0]]=row
for i,line in enumerate(lines):
 if line.startswith('| Configuration edit |') or line.startswith('| Report rendering |'):
  lines[i]=line.replace('Diagnostic;','Earlier312f/0443; diagnostic;')
s='\n'.join(lines)+'\n'
a=s.index('Measured **2026-11-16 UTC**');b=s.index('\nWarm includes',a)
s=s[:a]+'''Measured **2026-11-16 UTC**: the first four workloads use committed
**81f60210 / frozen a44f65a8** versus stock **CPython3.13.16**. Configuration/report
remain earlier **312f5911 / frozen0443b5cf** measurements, identified per row.
Quiet Azure F4as_v7 / Ubuntu24.04.4, four AMD EPYC9V45vCPUs,16GiB/no swap;
.NET11RC3 natural workstation GC/normal tiering, CPython GIL/GC. The fixed six-case
catalog36c0a528 is identical in every process within each collection. Two processes
per engine,5s full-request warmups,five rotated approximately0.5s samples; startup
is outside the clocks. Latest twelve jobs400.971s,all correctness/quiet/join/archive
gates pass. Normalization's **10.85%CPython control movement** makes its precise
warm ratio uncertain. No causal gain is inferred across source collections.
[Latest CSV/text/JSON/search evidence](../benchmarks/results/2026-11-16-consolidated-cpython-checkpoint/README.md),
[earlier configuration/report evidence](../benchmarks/results/2026-11-16-generated-scripts-cpython/README.md).
Tables describe named measured sources; later changes require their own evidence.
''' + s[b:]
s=s.replace('This checkpoint fixes catalog\nand initialization within its twelve jobs; it does not explain the earlier shift.','This checkpoint fixes catalog\nand initialization within its twelve jobs; it does not explain the earlier shift\nor the latest10.85%CPython normalization-control movement.')
guide.write_text(s,encoding='utf-8',newline='\n')
p=repo/'benchmarks/EXPERIMENTS.md'
with p.open('a',encoding='utf-8',newline='\n') as f:
 f.write('''
[R451/B854 consolidated-runtime CPython checkpoint](results/2026-11-16-consolidated-cpython-checkpoint/README.md):
81f60210/frozena44f versus CPython3.13.16,four complete maintained scripts and
compile/warm/fresh phases. Twelve jobs400.971s/all gates,all users joined and
archive SHAverified under lease. Warm CSV1.12–1.13×,normalization2.00–2.24×,
JSON0.84–0.85×,search1.56–1.65×. Normalization CPython controls move10.85%,
precise ratio uncertain; both show substantial gap. Earlier config/report remain
named312f/0443measurements. No causal source gain or RSS/tail claim. Original
adversity/control movement retained,not automatically retimed. Guide refreshed;
whole-script redesign objective continues. Publication/tagging held.
''')
print(json.dumps(dict(saved=str(out),jobs=12,elapsedSeconds=receipt['elapsedSeconds'],allGates=True,publicationHeld=True)))
