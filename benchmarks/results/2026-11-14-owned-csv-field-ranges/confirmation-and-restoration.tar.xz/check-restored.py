from pathlib import Path
import hashlib,json,os,subprocess
r=Path(__file__).parent;reference=json.loads((r/'reference-state.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in reference['sourceSHA256'].items())
env=dict(os.environ);old=next(v for k,v in env.items()if k.casefold()=='path');env={k:v for k,v in env.items()if k.casefold()!='path'}
env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+old
sdk=env['DOTNET_ROOT']+'/dotnet.exe';checks=[]
for target in ['net11.0','net10.0']:
 for project,filter_ in [('Lokad.Lython.Tests','FullyQualifiedName~CsvDenialOwnershipTests'),('Lokad.Lython.PublicApi.Tests','FullyQualifiedName~CsvOwnedRangeTests')]:
  label=project+'-restored-'+target
  with(r/(label+'-build.log')).open('w',encoding='utf-8',newline='\n')as f:
   p=subprocess.run([sdk,'build',f'tests/{project}/{project}.csproj','-c','Release','-f',target,'--no-restore','--no-incremental','--disable-build-servers','-m:1'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
  assert p.returncode==0,label
  with(r/(label+'.log')).open('w',encoding='utf-8',newline='\n')as f:
   p=subprocess.run([sdk,'test',f'tests/{project}/{project}.csproj','-c','Release','-f',target,'--no-build','--filter',filter_,'--logger','trx','--results-directory',str((r/label).resolve())],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
  checks.append(dict(project=project,target=target,filter=filter_,forcedNonincrementalBuild=True,returncode=p.returncode))
  (r/'restored-checks.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8',newline='\n')
  print(label,(r/(label+'.log')).read_text(encoding='utf-8')[-900:],flush=True);assert p.returncode==0,label
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in reference['sourceSHA256'].items())
