from pathlib import Path
import ast,base64,datetime,hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;prior=r/'b727';out=r/'b728';out.mkdir(exist_ok=False)
closed=json.loads((prior/'failed-closure.json').read_text(encoding='utf-8'));assert closed['allWorkersJoined']and closed['guestFixturesRemoved']
source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in source['sources'].items())
identity=json.loads((prior/'identity.json').read_text(encoding='utf-8'))
identity.update(purpose='Same510a/9cfb CSV range confirmation after removing stale control-catalog routing. Original B727two partial phases/failure preserved; diagnostic borrowed/escaped cases run first. No external timing.',originalFailedCollection='B727,288b1fe049564df3727d1afea42b6ba5936e159d95781dacdf57329c40d39e2f',sourceAndCatalogUnchanged=True)
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(prior/'source-identity.json',out/'source-identity.json')
jobs=[['diagnostic.csv-fulfillment.borrowed.large','warm'],['diagnostic.csv-fulfillment.escaped.large','warm'],['scripts.csv-fulfillment.large','warm'],['scripts.csv-fulfillment.large','compile-run'],['scripts.text-summary-helpers.nonlocal-counter.large','warm']]
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=(prior/name).read_text(encoding='utf-8').replace('csv-ranges-b727-20261114','csv-ranges-b728-20261114').replace('lython-b727-csv-ranges-20261114','lython-b728-csv-ranges-20261114').replace('B727','B728')
 if name=='collect.py':
  old='self.catalog = control_catalog if case["id"].startswith("diagnostic.") else catalog';assert old in s
  s=s.replace(old,'self.catalog = catalog')
  a=s.index('jobs=');z=s.index('\nassert len(jobs)',a);s=s[:a]+'jobs='+repr(jobs)+s[z:]
  assert not any(isinstance(n,ast.Name)and n.id=='control_catalog'for n in ast.walk(ast.parse(s)))
 if name.endswith('.py'):ast.parse(s)
 (out/name).write_text(s,encoding='utf-8',newline='\n')
reason=dict(reason='Correct stale collector diagnostic routing to the one supplied catalog. Same frozen source/bits/data/protocol/timing settings; original partial normal warm/fresh lack final gate and remain diagnostic. Run borrowed/escaped first to validate the actual previously failing constructor path before normal phases.',sourceAndCatalogUnchanged=True,changedOnlyCollectorRoutingAndCaseOrder=True,fullQualificationOfCandidateStillPending=True,noAutomaticRestart=True,originalFailedCollectionClosed=True,originalFailureAndAdverseEvidencePreserved=True,publicationHeld=True)
(out/'prospective.json').write_text(json.dumps(reason,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
 for name in ['identity.json','source-identity.json','collect.py','archive-owned.py','run.sh','prospective.json']:t.add(out/name,arcname=name)
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
config=dict(root='/home/lokad/lython-bench-checks/csv-ranges-b728-20261114',sourceRoot='/home/lokad/lython-bench-checks/csv-ranges-b727-20261114',unit='lython-b728-csv-ranges-20261114',identity=identity,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
code=r'''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
config=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['sourceRoot']);digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert root.parent==base and not root.exists()and source.parent==base and source.resolve()==source
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(os.path.ismount(p)for p in base.glob('*/guest-fixtures'))
 state=subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=LoadState,MainPID'],text=True)
 assert 'LoadState=not-found'in state and 'MainPID=0'in state
 closure=json.loads((source/'failed-closure.json').read_text());assert closure['allWorkersJoined']and closure['guestFixturesRemoved']and digest(source/'failed-observations.tgz')==closure['rawSHA256']
 for role in ['reference','candidate']:
  assert digest(source/role/'Lokad.Lython.dll')==config['identity']['coreSHA256'][role]
  for name,sha in config['identity'][role+'AuxiliaryFiles'].items():assert digest(source/role/name)==sha
 assert digest(source/'representative.json')==config['identity']['catalogSHA256']
 payload=sys.stdin.buffer.read(config['payloadBytes']+1)
 assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 before=shutil.disk_usage(base).free;assert before>254*1024*1024+config['unpackedBytes']+32768
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as t:t.extractall(root,filter='data')
 for role in ['reference','candidate']:
  (root/role).mkdir()
  for name in [*config['identity'][role+'AuxiliaryFiles'],'Lokad.Lython.dll']:os.link(source/role/name,root/role/name)
 os.link(source/'representative.json',root/'representative.json');os.link(source/'cpython-worker.py',root/'cpython-worker.py')
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 assert 'control_catalog'not in(root/'collect.py').read_text()
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture=root/'guest-fixtures';fixture.mkdir();assert shutil.disk_usage(base).free>254*1024*1024
 (root/'space-preflight.json').write_text(json.dumps(dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,noNewImageOrCatalogUpload=True,noRetirement=True,floorsUnchanged=True))+chr(10))
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b728-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=480','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True))
'''.replace('CONFIG',repr(config));ast.parse(code)
(out/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
launch_result=subprocess.run(ssh+[command],input=(out/'payload.tgz').read_bytes(),capture_output=True,timeout=45)
(out/'launch.log').write_bytes(launch_result.stdout+launch_result.stderr);assert launch_result.returncode==0,(launch_result.stdout+launch_result.stderr).decode()
now=datetime.datetime.now(datetime.timezone.utc)
(out/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=420)).isoformat(),ownerSeconds=480,stopSeconds=30),indent=2)+'\n',encoding='utf-8',newline='\n')
plan_path=Path('PLAN.md');s=plan_path.read_text(encoding='utf-8');(out/'PLAN-before-confirmation.md').write_text(s,encoding='utf-8',newline='\n')
a=s.index('   B727active:');z=s.index('   R353full43583650094',a)
s=s[:a]+'''   B727failed in copied collector routing before diagnostic cases: control_catalog
   was removed but a Worker branch still referenced it. Two completed normal phases
   remain diagnostic without final gates. All workers joined; empty RAM mount and
   raw evidence archived/verified/closed. Original code/log/failed condition survive.
   Correct to one supplied catalog and run diagnostics first. B728same frozen510a/
   qualified9cfb is active, same5jobs/settings/480sowner; earliest observation'''+(now+datetime.timedelta(seconds=420)).strftime('%H:%M:%S')+'''UTC.
   No new core/catalog upload, retirement, source/data change or floor relaxation.
   Allocation remains flat; decide CPU/scratch/complexity debt from usable evidence.
   Earlier list-digit control and source-member/local metadata errors also persist.
   Full delivery follows coherent retention; no automatic restart or premature claim.
'''+s[z:];plan_path.write_text(s,encoding='utf-8',newline='\n')
print((launch_result.stdout+launch_result.stderr).decode(),flush=True)
print('Observe B728after',(now+datetime.timedelta(seconds=420)).isoformat(),flush=True)
