from pathlib import Path
import datetime,json
r=Path(__file__).parent;out=r/'b728'
bound=json.loads((out/'observe-not-before.json').read_text(encoding='utf-8'))
launch=(out/'launch.log').read_text(encoding='utf-8');assert 'ActiveState=active'in launch and 'MainPID=0'not in launch
plan_path=Path('PLAN.md');s=plan_path.read_text(encoding='utf-8');a=s.index('   B727active:');z=s.index('\n2. **Advance',a)
stamp=datetime.datetime.fromisoformat(bound['doNotObserveBeforeUTC']).strftime('%H:%M:%S')
s=s[:a]+'''   B727failed in copied collector routing before diagnostic cases: control_catalog
   was removed but a Worker branch still referenced it. Two completed normal phases
   remain diagnostic without final gates. All workers joined; empty RAM mount and
   raw evidence archived/verified/closed. Original code/log/failed condition survive.
   Correct to one supplied catalog and run diagnostic cases first. B728same frozen
   510a/qualified9cfb is active, same5jobs/settings/480sowner; earliest observation'''+stamp+'''UTC.
   No new core/catalog upload, retirement, source/data change or floor relaxation.
   Allocation remains flat; decide CPU/scratch/complexity debt from usable evidence.
   Earlier list-digit control and source-member/local metadata errors also persist.
   B728local plan-anchor update failed after launch; local repair only, same owner.
   Full delivery follows coherent retention; no automatic restart or premature claim.
   R353full43583650094 remains GREEN/cached atf581/9cfb; it excludes this prototype.
   Current CPython table remains separately measured7e2/frozen72.
'''+s[z:]
plan_path.write_text(s,encoding='utf-8',newline='\n')
(out/'local-plan-correction.json').write_text(json.dumps(dict(failure='Local PLAN anchor ValueError after successful first B728launch',correction='Use the next numbered deliverable boundary; metadata/observer/source/catalog already written and unchanged. No remote calls/restart.',bound=bound),indent=2)+'\n',encoding='utf-8',newline='\n')
print('B728same first owner; local plan repaired; observe after',bound['doNotObserveBeforeUTC'])
