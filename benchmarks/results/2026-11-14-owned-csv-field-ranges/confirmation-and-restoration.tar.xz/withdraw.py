from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).parent
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in identity['sources'].items())
s=json.loads((r/'b728/summary.json').read_text(encoding='utf-8'));assert s['complete']and s['jobs']==5
for name in identity['changedProductionInputs']:
 original=r/'original'/name;assert original.exists();shutil.copyfile(original,name)
reference=json.loads((r/'reference-state.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in reference['sourceSHA256'].items())
decision=dict(decision='Withdraw runtime proposal; retain independent public CPython/lifetime and strengthened refusal-prefix regression coverage',
 candidate='510a3f866c8a2a94fd014abdbdfb39827f0fd71dcfcf2be15594f4e7854916d8',restoredSource='f5817a15/frozen9cfb7d5b;581production inputs exactly match reference inventory',
 reason='Allocation is flat. Borrowed CSV is effectively flat and escaped CSV has only~0.5–1%elapsed direction/uncertain CPU. Normal warm is mixed while fresh improves1.4–2.6%. Extra field-end bookkeeping, a copy-within primitive and retained raw-syntax scratch/earlier-denial tradeoff are not justified by this limited useful benefit. This is not a fixed-percentage veto or proof of inherent CPU regression.',
 uncertainty='Untouched captured text is adverse and candidate processes vary. Original partial B727normal phases lack final gates; corrected B728all gates pass with the same source/data and revised collector routing/case order. Preserve every adverse point; no large/universal gain or neutral-control claim.',
 removedAfterWithdrawal=['raw-record field-end bookkeeping','CopyWithinWritten primitive used only by this proposal','borrowed-line pre-copy staging and raw retention contract change'],
 preserved=['qualified9cfb runtime and all delivered allocation/ownership/native execution fixes','16native/borrowed independent CPython-golden cases and2actual-I/O multiline lifetime cases','refusal tests asserting actual prefix/capacity/funding instead of fixed private decoded layout'],
 laterReconsideration='New owning evidence or a representation that removes the extra scratch/state can justify bounded refinement; no unchanged timing replay is needed to decide this proposal.',
 fullQualification='Restored production source is already qualified43583650094; newly retained tests require focused checks after a forced nonincremental rebuild, with broader test qualification batched later.',publicationHeld=True,performanceObjectiveStillActive=True)
(r/'withdrawal-decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('PLAN.md');text=p.read_text(encoding='utf-8');(r/'PLAN-before-withdrawal.md').write_text(text,encoding='utf-8',newline='\n')
a=text.index('| R355, active prototype |');z=text.index('\n',a)
text=text[:a]+'''| R355, runtime withdrawn; tests retained | Corrected B728same510a/9cfb completes5jobs/375.423s/all gates. Allocation flat; borrowed effectively flat, escaped−0.54..−1.02%elapsed/CPUuncertain, normal warm−2.39..+0.71%/fresh−1.39..−2.57%. Text+0.50..+3.09%/CPU+1.19..+3.05%, variable. Extra field-end state/copy primitive/raw scratch are not justified by limited benefit. Restored all581production inputs to qualifiedf581/9cfb;18new public cases/stronger prefix assertions retained, forced rebuild/focused verification next. Original B727failure/partial data survive. |'''+text[z:]
a=text.index('1. **Decide/deliver R355owned CSV field ranges.**');z=text.index('2. **Advance a substantial',a)
text=text[:a]+'''1. **Close R355withdrawal and preserve useful regressions.** Source510a prototype
   withdrawn after usable B728same-bit comparison/all gates, not because uncertainty
   proves a bad design. No allocation reduction; borrowed/escaped benefit limited,
   normal warm mixed and fresh modest; text adversity remains. Added field-end state,
   copy-within API and raw-syntax retention/earlier-denial contract cost outweigh the
   demonstrated useful benefit. Remove them; all581production inputs now match
   qualifiedf581/9cfb. Keep16native/borrowed CPython goldens,2actual-I/O multiline
   lifetime cases and strengthened actual prefix/capacity/funding refusal checks.
   Force nonincremental actual11/10 builds and focused checks after restoration.
   Preserve B727NameError/partial phases, all setup corrections and B728adverse data.
   No permanent ban/fixed percentage veto; new owning evidence or less costly
   representation can justify refinement. No unchanged timing replay needed here.
   Current CPython table remains separately measured7e2/frozen72; publication held.

'''+text[z:]
a=text.index('   **R354 source gate complete;');z=text.index('   | Area / representative scripts |',a)
text=text[:a]+'''   R354's bounded fulfillment source gate selected the actual CSV copy stage;
   R355tested/withdrew that representation and preserves the evidence. Move to a
   different coherent boundary. Ordinary loops and helper execution after a first
   general call are the next source question: native prefix recognizes only selected
   builtins, so range construction or a real callback can promote the whole remaining
   body. Establish whether this creates a material ordinary-script cliff before
   changing execution/value machinery. Inspect existing route/history and compare
   identical numeric work with range inside/outside a helper, using short focused
   diagnostics and current CPython controls. Keep compilation/warm/cleanup boundaries
   explicit; source/data variants are diagnostics, not source-pair speedup proof.
   Stop at a supported selection/rejection; don't add individual builtin exceptions
   or a tagged VM without a displaced stage and alias/promotion/ownership contract.
   Imports already execute code, bindings retain declarations and module mirroring
   is demand-driven; don't duplicate those delivered removals.

'''+text[z:];p.write_text(text,encoding='utf-8',newline='\n')
print('Removed510a runtime proposal;581inputs match qualified reference. New tests retained; forced rebuild next.')
