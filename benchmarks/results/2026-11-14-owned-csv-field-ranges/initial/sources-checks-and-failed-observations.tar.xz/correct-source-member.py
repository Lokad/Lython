from pathlib import Path
import ast,json,subprocess
r=Path(__file__).parent
original=(r/'prepare-measurement.py').read_text(encoding='utf-8')
tail=original[original.index("head=identity['parentHead'];canonical="):]
tail=tail.replace("extractfile('candidate-core.dll')","extractfile('corrected/candidate-core.dll')").replace("member='candidate-core.dll'","member='corrected/candidate-core.dll'")
prefix='''from pathlib import Path
import ast,base64,datetime,hashlib,io,json,subprocess,tarfile
r=Path(__file__).parent;out=r/'b727'
assert out.is_dir()and not(out/'launch.log').exists()
identity=json.loads((out/'identity.json').read_text(encoding='utf-8'))
source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in source['sources'].items())
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
'''
code=prefix+tail;ast.parse(code)
(r/'resume-preparation.py').write_text(code,encoding='utf-8',newline='\n')
(r/'b727/staging-correction.json').write_text(json.dumps(dict(original='prepare-measurement.py',failure='KeyError looking for candidate-core.dll in canonical R351archive',correctMember='corrected/candidate-core.dll',boundary='Local archive lookup, before any VM query/mutation/mount/service. Original script/payload/identities retained.',measurementNotStarted=True,sourceAndCatalogUnchanged=True),indent=2)+'\n',encoding='utf-8',newline='\n')
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'resume-preparation.py')],check=True)
