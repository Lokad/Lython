from pathlib import Path
import json,os,subprocess
r=Path(__file__).parent
env=dict(os.environ);old=next(v for k,v in env.items()if k.casefold()=='path');env={k:v for k,v in env.items()if k.casefold()!='path'}
env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+old
sdk=env['DOTNET_ROOT']+'/dotnet.exe';checks=[]
for framework in ['net11.0','net10.0']:
 with(r/('probe-build-'+framework+'.log')).open('w',encoding='utf-8',newline='\n')as f:
  p=subprocess.run([sdk,'build','tools/LythonProbe/LythonProbe.csproj','-c','Release','-f',framework],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 assert p.returncode==0
 for project in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:
  filter_='(FullyQualifiedName~Csv|FullyQualifiedName~CsvReader|FullyQualifiedName~GovernedMemoryContract|FullyQualifiedName~MemoryDenialAttribution|FullyQualifiedName~CooperativeCancellation)&Category!=Stress'
  label=project+'-'+framework
  with(r/(label+'.log')).open('w',encoding='utf-8',newline='\n')as f:
   p=subprocess.run([sdk,'test',f'tests/{project}/{project}.csproj','-c','Release','-f',framework,'--filter',filter_,'--logger','trx','--results-directory',str((r/label).resolve())],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=240)
  checks.append(dict(project=project,target=framework,filter=filter_,returncode=p.returncode))
  (r/'focused-checks.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8',newline='\n')
  print(label,(r/(label+'.log')).read_text(encoding='utf-8')[-2400:],flush=True)
  assert p.returncode==0,label
