from pathlib import Path
import hashlib,json,shutil,statistics,subprocess,tarfile
r=Path(__file__).parent;b=r/'b727'
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in identity['sources'].items())
closure=json.loads((b/'failed-closure.json').read_text(encoding='utf-8'))
assert closure['allWorkersJoined']and closure['guestFixturesRemoved']and hashlib.sha256((b/'failed-observations.tgz').read_bytes()).hexdigest()==closure['rawSHA256']
raw=json.loads((b/'retrieved-failed/confirmation/confirmation.json').read_text(encoding='utf-8'));assert not raw['complete']and len(raw['jobs'])==2
rows=[]
for job in raw['jobs']:
 labels=list(job['identities'])
 med={k:statistics.median(1000*s['response']['elapsedTicks']/s['response']['clockFrequency']/s['response']['completedInvocations']for s in job['samples']if s['engine']==k)for k in labels}
 cpu={k:statistics.median(1000*s['externalProcessCpuTicks']/s['externalCpuFrequency']/s['response']['completedInvocations']for s in job['samples']if s['engine']==k)for k in labels}
 row=dict(case=job['case'],lane=job['lane'],medianMilliseconds=med,processCpuMedianMilliseconds=cpu,elapsedPercent=sorted(100*(med[a]/med[z]-1)for a in ['candidate','candidate-control']for z in ['reference','reference-control']),cpuPercent=sorted(100*(cpu[a]/cpu[z]-1)for a in ['candidate','candidate-control']for z in ['reference','reference-control']))
 rows.append(row)
partial=dict(complete=False,completedJobs=2,finalQuietGateMissing=True,diagnosticOnly=True,timing=rows,originalFailure=closure['failure'],noRuntimeFailureEstablished=True)
(b/'partial-summary.json').write_text(json.dumps(partial,indent=2)+'\n',encoding='utf-8',newline='\n')
out=Path('benchmarks/results/2026-11-14-owned-csv-field-ranges/initial');out.mkdir(parents=True,exist_ok=False)
for name in ['candidate-identity.json','focused-checks.json','added-checks.json','allocation-summary.json','python-range-controls.json','control-correction.json','control-verification.json']:
 shutil.copyfile(r/name,out/name)
for name in ['failed-closure.json','partial-summary.json']:shutil.copyfile(b/name,out/name)
with tarfile.open(out/'sources-checks-and-failed-observations.tar.xz','w:xz')as t:
 for p in sorted(r.iterdir()):
  if p.is_file()and p.suffix in ['.py','.json','.log','.dll','.xz']:t.add(p,arcname=p.name)
 for p in sorted(b.iterdir()):
  if p.is_file()and p.suffix in ['.py','.json','.log','.sh','.tgz']:t.add(p,arcname='b727/'+p.name)
 for p in sorted(r.glob('*/*.trx')):t.add(p,arcname='checks/'+str(p.relative_to(r)))
 for p in ['tests/Lokad.Lython.PublicApi.Tests/CsvOwnedRangeTests.cs','tests/Lokad.Lython.Tests/CsvDenialOwnershipTests.cs']:t.add(p,arcname='regressions/'+Path(p).name)
 for p in (r/'original').rglob('*.cs'):t.add(p,arcname='original/'+str(p.relative_to(r/'original')))
 for name in ['Allocation.dll','Allocation.deps.json','Allocation.runtimeconfig.json']:t.add(r/'candidate'/name,arcname='allocation-tool/'+name)
 for name in ['Allocation.csproj','Program.cs']:t.add(r.parent/'word-buffer-loan-r324/allocation'/name,arcname='allocation-tool/source/'+name)
table='| Completed diagnostic phase | Elapsed change | Wider CPU change |\n| --- | ---: | ---: |\n'
for v in rows:table+=f"|{v['case']} /{v['lane']}|{min(v['elapsedPercent']):+.2f}..{max(v['elapsedPercent']):+.2f}%|{min(v['cpuPercent']):+.2f}..{max(v['cpuPercent']):+.2f}%|\n"
(out/'README.md').write_text(f'''# Initial owned CSV range prototype and incomplete comparison

2026-11-14, R355/frozen510a3f86, two uncommitted production inputs changed from
qualifiedf5817a15/frozen9cfb. One parser uses ranges into owned raw input instead
of compacting ordinary field bytes before copying final independent values.
Borrowed strings first copy in bounded cancellable chunks; native files already
fill the admitted buffer. Only escapes rewrite within a field. No new owner,
backend, policy or raw-pointer borrowing. Raw syntax stays admitted until record
completion, which can require more scratch/earlier denial for escaped/multiline
or malformed borrowed input. No promotion or full delivery claim here.

1,116focused actual11/10 checks pass (119internal/421public plus18new each target),
including16native/borrowed CPython3.13.2 goldens and escaped multiline fields
across actual I/O/buffer reuse. Existing refusal checks preserve actual prefix/
capacity/funding rather than assuming a decoded private layout. Whole invoice,
fulfillment and unchanged text allocation are effectively flat (at most a few B).

B727is TERMINAL FAILED in copied measurement code: Worker routed diagnostic
IDs through undefined control_catalog, even though every case belongs in the one
supplied catalog. Two normal phases completed; later controls/final quiet gate
are missing. These values are diagnostic only, regardless of direction:

{table}
All original bits/source/checks, failed condition, raw partial observations and
adverse points are retained. All workers joined and the empty RAM fixture was
archived/verified and unmounted. Failed raw SHA256: `{closure['rawSHA256']}`.
This is measurement uncertainty, not evidence that the runtime design failed.

Earlier setup corrections also survive: the first proposed list-digit control
was not borrowed CSV input and was replaced before timing; real borrowed rows and
escaped-SKU data were independently verified by isolated CPython and both actual
frozen workers. A wrong local canonical-archive member lookup stopped before VM
work; a local omitted-jobs metadata error occurred after first launch and was
repaired without restarting it. Historical72c9 aliases were retired only after
canonical Git/path/UID/full-alias/byte proof; current9cfb/510a and all auxiliary
images/catalogs/toolchains/floors remain.

A bounded confirmation may remove only stale collector routing and run diagnostic
cases first, reusing exactly510a/9cfb/data/settings under a new owner. It must
preserve this failed collection and independently obtain all final gates before
deciding CPU/scratch/complexity tradeoffs. No automatic restart, broad campaign,
external-baseline update or performance-objective completion. Publication held.

[Partial timings](partial-summary.json),[failed closure](failed-closure.json),
[source/core/tools/checks/failed raw archive](sources-checks-and-failed-observations.tar.xz).
''',encoding='utf-8',newline='\n')
assert not subprocess.check_output(['git','diff','--cached','--name-only'],text=True).strip()
subprocess.run(['git','add','--',str(out)],check=True);subprocess.run(['git','diff','--cached','--check'],check=True)
assert all(p.startswith(str(out).replace('\\','/'))for p in subprocess.check_output(['git','diff','--cached','--name-only'],text=True).splitlines())
subprocess.run(['git','commit','-m','Preserve CSV range prototype and incomplete comparison conditions [skip ci]'],check=True)
subprocess.run(['git','push','origin','HEAD'],check=True,timeout=120)
for row in rows:print(row['lane'],'diagnostic elapsed',row['elapsedPercent'],'CPU',row['cpuPercent'])
print('Original failed B727/source evidence immutable; runtime prototype still uncommitted/unqualified.')
