from pathlib import Path
import ast,datetime,json
r=Path(__file__).parent;out=r/'b727'
bound=json.loads((out/'observe-not-before.json').read_text(encoding='utf-8'))
identity=json.loads((out/'identity.json').read_text(encoding='utf-8'))
tree=ast.parse((out/'collect.py').read_text(encoding='utf-8'))
node=next(n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='jobs'for t in n.targets))
jobs=ast.literal_eval(node.value);assert len(jobs)==5
assert 'MainPID=3696548'in(out/'launch.log').read_text(encoding='utf-8')
record=dict(purpose=identity['purpose'],jobs=jobs,bound=bound,recordedAfterLaunchUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 designAndJobsFrozenInPayloadBeforeLaunch=True,
 controls='True borrowed-row and escaped-SKU cases independently verified under isolatedCPython3.13.2 and both actual frozen workers. Original mistaken list-digit control corrected before timing, evidence retained.',
 corrections=['Initial local canonical archive-member lookup stopped before any VM query or mutation; corrected to corrected/candidate-core.dll with original payload/identity unchanged.',
 'First measurement owner launched successfully, then local prospective metadata write raised NameError for jobs omitted by the resume wrapper. Repair only local metadata using the frozen collector AST; no VM query/relaunch/input/source change. Original wrappers and failure conditions preserved.'],
 firstOwner='lython-b727-csv-ranges-20261114.service;MainPID3696548atlaunch',
 retirement='Only canonical-proven historical72c9 core hardlinks; current9cfb/new510a and all auxiliaries/catalogs/toolchains/floors preserved.',
 stopping='One usable bounded source pair. Allocation flat separately; preserve every adverse observation and decide CPU/scratch/complexity tradeoffs. Full delivery follows retention; no external timing claim.',publicationHeld=True)
(out/'prospective.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
plan_path=Path('PLAN.md');s=plan_path.read_text(encoding='utf-8');(out/'PLAN-before-timing.md').write_text(s,encoding='utf-8',newline='\n')
old='   Next: bounded CSV warm/fresh and borrowed-row timing with unchanged text control,'
assert old in s
stamp=datetime.datetime.fromisoformat(bound['doNotObserveBeforeUTC']).strftime('%H:%M:%S')
s=s.replace(old,'   B727active: fulfillment warm/fresh, true borrowed rows, escaped-SKU CSV and\n   unchanged text;480sowner/420sjob-startguard; earliest observation'+stamp+'UTC.\n   Both new controls pass isolatedPython/actual workers. Mistaken list-digit control\n   corrected before timing; original catalog/verification preserved. Local archive-\n   member lookup failed before VM work; after first launch, omitted local jobs\n   metadata was repaired from frozen collector AST without VM restart. All failures\n   survive. Only canonical-proven historical72c9 aliases retired; current9cfb/new510a\n   and all auxiliaries/catalogs/toolchains/floors preserved. Keep')
s=s.replace('Allocation/CPU/full delivery unqualified.', 'Whole-script allocation effectively flat; B727CPU comparison active/full delivery unqualified.')
plan_path.write_text(s,encoding='utf-8',newline='\n')
print('Local metadata repaired; same B727owner. Observe no earlier than',bound['doNotObserveBeforeUTC'])
