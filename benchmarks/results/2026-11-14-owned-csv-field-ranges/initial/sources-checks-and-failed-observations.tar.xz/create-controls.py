from pathlib import Path
import base64,copy,csv,hashlib,importlib.util,io,json,shutil,subprocess,tempfile
r=Path(__file__).parent
catalog=json.loads((r/'catalog.json').read_text(encoding='utf-8'));assert len(catalog['cases'])==4
assert catalog['cases'][-1]['id']=='scripts.csv-check-digits.for-list.large'
shutil.copyfile(r/'catalog.json',r/'catalog-before-control-correction.json')
catalog['cases']=catalog['cases'][:3]
normal=next(c for c in catalog['cases']if c['id']=='scripts.csv-fulfillment.large')
borrowed=copy.deepcopy(normal);assert 'csv.DictReader(source)'in borrowed['source']
borrowed['source']=borrowed['source'].replace('csv.DictReader(source)','csv.DictReader(source.readlines())')
borrowed.update(id='diagnostic.csv-fulfillment.borrowed.large',sourceUtf8Bytes=len(borrowed['source'].encode()),sourceSha256=hashlib.sha256(borrowed['source'].encode()).hexdigest())
escaped=copy.deepcopy(normal);escaped['id']='diagnostic.csv-fulfillment.escaped.large'
fixture=json.loads(escaped['fixtureJson']);assert list(fixture['inputFiles'])==['input.csv']
data=base64.b64decode(fixture['inputFiles']['input.csv']).decode('utf-8')
rows=list(csv.reader(io.StringIO(data,newline='')));assert len(rows)==4097 and rows[0][0]=='sku'
for row in rows[1:]:row[0]+=' "boxed",😀'
out=io.StringIO(newline='');csv.writer(out,quoting=csv.QUOTE_ALL,lineterminator='\n').writerows(rows)
fixture['inputFiles']['input.csv']=base64.b64encode(out.getvalue().encode()).decode()
spec=importlib.util.spec_from_file_location('protocol',r.parent/'utf8-byte-ownership-r334/b705/retrieved/cpython-worker.py')
protocol=importlib.util.module_from_spec(spec);spec.loader.exec_module(protocol)
controls=[]
for case,item in [(borrowed,json.loads(borrowed['fixtureJson'])),(escaped,fixture)]:
 with tempfile.TemporaryDirectory(prefix='csv-ranges-python-',dir=r.resolve())as name:
  folder=Path(name)
  for path,payload in item['inputFiles'].items():(folder/path).write_bytes(base64.b64decode(payload))
  p=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',case['source']],cwd=folder,capture_output=True,text=True,encoding='utf-8',timeout=15)
  assert p.returncode==0 and not p.stderr and p.stdout==normal['expectedOutput'],(p.returncode,p.stdout,p.stderr)
  outputs={path:(folder/path).read_bytes()for path in item['outputFiles']}
  if case is borrowed:assert all(outputs[path]==base64.b64decode(payload)for path,payload in item['outputFiles'].items())
  item['outputFiles']={path:base64.b64encode(payload).decode()for path,payload in outputs.items()}
  case.update(fixtureJson=json.dumps(item,separators=(',',':'),ensure_ascii=False),expectedOutput=p.stdout,expectedOutputUtf8Bytes=len(p.stdout.encode()),expectedOutputSha256=hashlib.sha256(p.stdout.encode()).hexdigest(),expectedFilesSha256=protocol.file_digest(outputs))
  case['fixtureSha256']=hashlib.sha256(case['fixtureJson'].encode()).hexdigest()
  assert all((folder/path).read_bytes()==base64.b64decode(payload)for path,payload in item['inputFiles'].items())
  controls.append(dict(id=case['id'],source=case['source'],sourceSha256=case['sourceSha256'],fixtureSha256=case['fixtureSha256'],expectedOutput=p.stdout,expectedFilesSha256=case['expectedFilesSha256'],inputBytes=sum(len(base64.b64decode(v))for v in item['inputFiles'].values()),reference='CPython3.13.2 isolated -I -S',allFilesAndInputUnchangedVerified=True))
catalog['cases']+=[borrowed,escaped]
(r/'catalog.json').write_text(json.dumps(catalog,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
(r/'control-correction.json').write_text(json.dumps(dict(reason='The reused for-list checksum case still fed CSV from a native file; it did not exercise borrowed CSV input. Corrected before any VM timing. Original catalog/worker verification and unchanged three-case allocation evidence survive.',newControls=controls,sameSourceAndFixtureAcrossRuntimeRoles=True,normalAndBorrowedAlgorithmsIntentionallyDiffer=True,noTimingClaim=True),indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
s=(r/'verify-worker.py').read_text(encoding='utf-8').replace('range(4)','range(3,5)').replace('worker-verification.json','control-verification.json')
(r/'verify-controls.py').write_text(s,encoding='utf-8',newline='\n')
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'verify-controls.py')],check=True)
print('True borrowed-row and escaped-SKU controls independently verified under CPython and both frozen comparison workers.')
