from pathlib import Path
import fcntl,json,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 p=base/'literal-tuples-b723-20261114/candidate/Lokad.Lython.dll';s=p.stat();aliases=[]
 for pattern in ['*/candidate-core.dll','*/reference-core.dll','*/candidate/Lokad.Lython.dll','*/reference/Lokad.Lython.dll']:
  for q in base.glob(pattern):
   v=q.stat()
   if(v.st_dev,v.st_ino)==(s.st_dev,s.st_ino):aliases.append(str(q.relative_to(base)))
 print(json.dumps(dict(readOnly=True,freshIdleLease=True,source=str(p),bytes=s.st_size,links=s.st_nlink,aliases=sorted(set(aliases)),freeBytes=shutil.disk_usage(base).free)))
