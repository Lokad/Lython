from pathlib import Path
import base64,json,subprocess
r=Path(__file__).parent
code='''from pathlib import Path
import json,os,subprocess
root=Path('/home/lokad/lython-bench-checks/csv-ranges-b727-20261114')
p=root/'confirmation/confirmation.json'
d=json.loads(p.read_text())if p.exists()else None
print(json.dumps(dict(log=(root/'collection.log').read_text()[-10000:],partial=None if d is None else dict(complete=d['complete'],jobs=[(j['case'],j['lane'])for j in d['jobs']]),fixtureMounted=os.path.ismount(root/'guest-fixtures'),fixtureEntries=[q.name for q in(root/'guest-fixtures').iterdir()]if(root/'guest-fixtures').exists()else[],remainingWorkers=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True).stdout)))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
p=subprocess.run(ssh+[command],capture_output=True,text=True,encoding='utf-8',timeout=30);assert p.returncode==0,p.stderr
(r/'failure-inspection.json').write_text(p.stdout,encoding='utf-8',newline='\n');print(p.stdout)
