from pathlib import Path
import base64,hashlib,json,subprocess,tarfile
r=Path(__file__).parent
code='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess,tarfile
root=Path('/home/lokad/lython-bench-checks/csv-ranges-b727-20261114')
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 state=subprocess.check_output(['systemctl','show','lython-b727-csv-ranges-20261114.service','--property=MainPID,ActiveState,Result'],text=True)
 assert 'MainPID=0'in state and 'ActiveState=failed'in state
 assert(root/'exit-code.txt').read_text().strip()=='1'
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 fixture=root/'guest-fixtures';assert os.path.ismount(fixture)and not any(fixture.iterdir())
 data=json.loads((root/'confirmation/confirmation.json').read_text());assert not data['complete']and len(data['jobs'])==2
 raw=root/'failed-observations.tgz';assert not raw.exists()
 files=[p for p in root.rglob('*')if p.is_file()and p.name not in ['candidate-core.dll','failed-observations.tgz']and not {'candidate','reference','guest-fixtures'}&set(p.relative_to(root).parts)]
 checks={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in files}
 with tarfile.open(raw,'w:gz',dereference=True)as archive:
  for p in sorted(files):archive.add(p,arcname=p.relative_to(root).as_posix())
 with tarfile.open(raw)as archive:
  assert all(hashlib.sha256(archive.extractfile(name).read()).hexdigest()==sha for name,sha in checks.items())
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir()
 assert shutil.disk_usage(root).free>252*1024*1024
 receipt=dict(complete=False,completedJobs=2,failure='Stale control_catalog routing in Worker constructor before third diagnostic job; not a runtime failure',allWorkersJoined=True,guestFixturesRemoved=True,archivedAndVerifiedUnderLease=True,finalQuietGateMissing=True,rawSHA256=hashlib.sha256(raw.read_bytes()).hexdigest(),freeBytes=shutil.disk_usage(root).free,noRestart=True)
 (root/'failed-closure.json').write_text(json.dumps(receipt,indent=2)+chr(10));print(json.dumps(receipt))
'''
(r/'archive-failure-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
p=subprocess.run(ssh+[command],capture_output=True,text=True,encoding='utf-8',timeout=45);assert p.returncode==0,p.stderr
(r/'failed-closure.json').write_text(p.stdout,encoding='utf-8',newline='\n')
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
p2=subprocess.run(scp+['lokad@20.166.121.73:/home/lokad/lython-bench-checks/csv-ranges-b727-20261114/failed-observations.tgz',str(r/'failed-observations.tgz')],capture_output=True,timeout=45)
assert p2.returncode==0,p2.stderr
assert hashlib.sha256((r/'failed-observations.tgz').read_bytes()).hexdigest()==json.loads(p.stdout)['rawSHA256']
out=r/'retrieved-failed';out.mkdir(exist_ok=False)
with tarfile.open(r/'failed-observations.tgz')as archive:archive.extractall(out,filter='data')
print(p.stdout);print('Original failed B727closed, all users joined and empty RAM fixture archived/closed. No final timing claim.')
