from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess,tarfile
root=Path('/home/lokad/lython-bench-checks/csv-ranges-b727-20261114')
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 state=subprocess.check_output(['systemctl','show','lython-b727-csv-ranges-20261114.service','--property=MainPID,ActiveState,Result'],text=True)
 assert 'MainPID=0'in state and 'ActiveState=failed'in state
 assert(root/'exit-code.txt').read_text().strip()=='1'
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 fixture=root/'guest-fixtures';assert os.path.ismount(fixture)and not any(fixture.iterdir())
 data=json.loads((root/'confirmation/confirmation.json').read_text());assert not data['complete']and len(data['jobs'])==2
 raw=root/'failed-observations.tgz';assert not raw.exists()
 files=[p for p in root.rglob('*')if p.is_file()and p.name not in ['candidate-core.dll','failed-observations.tgz']and not {'candidate','reference','guest-fixtures'}&set(p.relative_to(root).parts)]
 checks={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in files}
 with tarfile.open(raw,'w:gz',dereference=True)as archive:
  for p in sorted(files):archive.add(p,arcname=p.relative_to(root).as_posix())
 with tarfile.open(raw)as archive:
  assert all(hashlib.sha256(archive.extractfile(name).read()).hexdigest()==sha for name,sha in checks.items())
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir()
 assert shutil.disk_usage(root).free>252*1024*1024
 receipt=dict(complete=False,completedJobs=2,failure='Stale control_catalog routing in Worker constructor before third diagnostic job; not a runtime failure',allWorkersJoined=True,guestFixturesRemoved=True,archivedAndVerifiedUnderLease=True,finalQuietGateMissing=True,rawSHA256=hashlib.sha256(raw.read_bytes()).hexdigest(),freeBytes=shutil.disk_usage(root).free,noRestart=True)
 (root/'failed-closure.json').write_text(json.dumps(receipt,indent=2)+chr(10));print(json.dumps(receipt))
