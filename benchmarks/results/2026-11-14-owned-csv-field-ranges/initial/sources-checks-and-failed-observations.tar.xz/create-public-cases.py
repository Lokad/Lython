from pathlib import Path
import csv,io,json,sys
r=Path(__file__).parent
records=[['alpha','','a,b','a"b','😀','tail'],['last','line\nnext','back\\slash','é','','end']]
formats=[dict(),dict(doublequote=False,escapechar='\\'),dict(delimiter='🦊',quotechar='😀',escapechar='💥'),dict(skipinitialspace=True),dict(quotechar=None,quoting=csv.QUOTE_NONE,escapechar='\\'),dict(quoting=csv.QUOTE_ALL),dict(delimiter='\t',quotechar="'",escapechar='\\')]
cases=[]
for index,fmt in enumerate(formats):
 output=io.StringIO(newline='');csv.writer(output,lineterminator='\r\n'if index==5 else'\n',**fmt).writerows(records)
 text=output.getvalue()
 if index==3:text='  alpha,  ,"a,b","a""b",😀, tail \n'
 expected=list(csv.reader(io.StringIO(text,newline=''),**fmt))
 kwargs=', '.join(k+'='+repr(v)for k,v in fmt.items())or "delimiter=','"
 cases.append(dict(text=text,arguments=kwargs,expected=expected))
text='\n,,\n"",""\n';cases.append(dict(text=text,arguments="delimiter=','",expected=list(csv.reader(io.StringIO(text,newline='')))))
(r/'python-range-controls.json').write_text(json.dumps(dict(version=sys.version,stdlib='csv.reader/StringIO(newline="")',cases=cases),indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
literal=lambda x:json.dumps(x,ensure_ascii=False)
data='\n'.join('        { '+', '.join([literal(c['text']),literal(c['arguments']),literal(json.dumps(c['expected'],ensure_ascii=False)),str(borrowed).lower()])+' },'for c in cases for borrowed in [False,True])
source='''using System.Text.Json;
using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.PublicApi.Tests;

public sealed class CsvOwnedRangeTests
{
    // Independent CPython 3.13.2 csv.reader goldens; native and borrowed inputs.
    public static TheoryData<string, string, string, bool> Cases => new()
    {
@DATA@
    };

    [Theory]
    [MemberData(nameof(Cases))]
    public async Task NativeAndBorrowedRowsPreserveValuesAndInput(string input, string arguments,
        string expectedJson, bool borrowed)
    {
        var source = "import csv\\nwith open('/input.csv', newline='') as stream:\\n    "
            + (borrowed ? "lines=stream.readlines()\\n    " : "")
            + $"rows=list(csv.reader({(borrowed ? "lines" : "stream")}, {arguments}))\\n"
            + (borrowed ? "return rows, ''.join(lines)" : "return rows, None");
        var expected = JsonSerializer.Deserialize<string[][]>(expectedJson)!;
        var budget = new LythonMemoryBudget(1024 * 1024);
        using (var script = new LythonEngine().Compile(source, budget))
        {
            Assert.True(script.IsValid, string.Join("; ", script.Diagnostics));
            var baseline = budget.ReservedBytes;
            var host = new MockLythonHost();
            host.SeedFile("/input.csv", input);
            using (var result = script.Run(host)) Check(result);
            Assert.Equal(baseline, budget.ReservedBytes);
            var delayed = new DelayedLythonHost();
            delayed.SeedFile("/input.csv", input);
            using (var result = await script.RunAsync(delayed)) Check(result);
            Assert.True(delayed.CompletedAsynchronously > 0);
            Assert.Equal(1, delayed.ClosedFileCount);
            Assert.Equal(baseline, budget.ReservedBytes);
        }
        Assert.Equal(0, budget.ReservedBytes);

        void Check(LythonExecutionResult result)
        {
            Assert.True(result.Success, result.Failure?.Message);
            var returned = Assert.IsAssignableFrom<IReadOnlyList<object?>>(result.ReturnValue);
            var rows = Assert.IsAssignableFrom<IReadOnlyList<object?>>(returned[0]);
            Assert.Equal(expected.Length, rows.Count);
            for (var i = 0; i < expected.Length; i++)
            {
                var row = Assert.IsAssignableFrom<IReadOnlyList<object?>>(rows[i]);
                Assert.Equal(expected[i], row.Select(value => Assert.IsType<string>(value)));
            }
            if (borrowed) Assert.Equal(input, returned[1]);
            else Assert.Null(returned[1]);
        }
    }

    [Theory]
    [InlineData(15)]
    [InlineData(4095)]
    public async Task EscapedMultilineFieldSurvivesBufferReuseAndActualIo(int prefixLength)
    {
        var field = new string('x', prefixLength) + "\\\"😀\\ny";
        var input = "\\\"" + field.Replace("\\\"", "\\\"\\\"") + "\\\",tail\\nend,last\\n";
        const string source = """
            import csv
            with open('/input.csv', newline='') as stream:
                reader=csv.reader(stream)
                first=next(reader)
                second=next(reader)
            return first,second
            """;
        var budget = new LythonMemoryBudget(1024 * 1024);
        using (var script = new LythonEngine().Compile(source, budget))
        {
            Assert.True(script.IsValid, string.Join("; ", script.Diagnostics));
            var baseline = budget.ReservedBytes;
            var host = new DelayedLythonHost();
            host.SeedFile("/input.csv", input);
            using (var result = await script.RunAsync(host))
            {
                Assert.True(result.Success, result.Failure?.Message);
                var rows = Assert.IsAssignableFrom<IReadOnlyList<object?>>(result.ReturnValue);
                Assert.Equal(new object?[] { field, "tail" }, Assert.IsAssignableFrom<IReadOnlyList<object?>>(rows[0]));
                Assert.Equal(new object?[] { "end", "last" }, Assert.IsAssignableFrom<IReadOnlyList<object?>>(rows[1]));
                Assert.True(budget.ReservedBytes > baseline);
            }
            Assert.True(host.CompletedAsynchronously > 0);
            Assert.Equal(1, host.ClosedFileCount);
            Assert.Equal(baseline, budget.ReservedBytes);
        }
        Assert.Equal(0, budget.ReservedBytes);
    }
}
'''.replace('@DATA@',data)
Path('tests/Lokad.Lython.PublicApi.Tests/CsvOwnedRangeTests.cs').write_text(source,encoding='utf-8',newline='\n')
print('Generated16native/borrowed CPython-golden cases and2escaped multiline lifetime cases.')
