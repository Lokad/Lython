from pathlib import Path
import json,os,subprocess
r=Path(__file__).parent;env=dict(os.environ);old=next(v for k,v in env.items()if k.casefold()=='path');env={k:v for k,v in env.items()if k.casefold()!='path'}
env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+old
rows=[]
for target in ['net11.0','net10.0']:
 label='added-'+target
 with(r/(label+'.log')).open('w',encoding='utf-8',newline='\n')as f:
  p=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f',target,'--filter','FullyQualifiedName~CsvOwnedRangeTests','--logger','trx','--results-directory',str((r/label).resolve())],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 rows.append(dict(target=target,returncode=p.returncode));(r/'added-checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
 print(label,(r/(label+'.log')).read_text(encoding='utf-8')[-2000:],flush=True)
 assert p.returncode==0,label
