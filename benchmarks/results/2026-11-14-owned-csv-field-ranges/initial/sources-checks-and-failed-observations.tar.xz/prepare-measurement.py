from pathlib import Path
import ast,base64,datetime,hashlib,io,json,subprocess,tarfile
r=Path(__file__).parent;out=r/'b727';out.mkdir(exist_ok=False)
prior=r.parent/'owned-tuple-return-r353/b725'
source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in source['sources'].items())
assert json.loads((r/'control-verification.json').read_text(encoding='utf-8'))
assert json.loads((r/'allocation-summary.json').read_text(encoding='utf-8'))['complete']
identity=json.loads((prior/'identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision='R355uncommitted/frozen510a3f86 vs qualifiedf5817a15/frozen9cfb7d5b',
 purpose='Owned CSV field ranges: complete fulfillment warm/fresh, true borrowed-row and escaped-SKU variants, unchanged captured-text control. Allocation flat separately; no external timing.',
 coreSHA256={label:source['coreSHA256']['candidate'if label.startswith('candidate')else'reference']for label in ['reference','candidate','reference-control','candidate-control']},
 catalogSHA256=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest(),
 referenceQualification='GREEN43583650094 Windows/Ubuntu actual11/10, original stress and installed Release consumers; sourcef581/frozen9cfb',
 referenceCase='scripts.csv-fulfillment.large',variantCase='scripts.csv-fulfillment.large',
 sourceArchiveSHA256=hashlib.sha256((r/'candidate-sources.tar.xz').read_bytes()).hexdigest(),
 sourceProofCommit=None,parentHead=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 normalBorrowedAndEscapedCasesIntentionallyDiffer=True,sameSourceAndFixtureAcrossRuntimeRoles=True)
identity.pop('sourceProofSHA256',None)
assert all(source['auxiliaryFiles'][role][name]==sha for role in ['reference','candidate']for name,sha in identity[role+'AuxiliaryFiles'].items())
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'source-identity.json').write_text(json.dumps(source,separators=(',',':'))+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.csv-fulfillment.large','warm'],['scripts.csv-fulfillment.large','compile-run'],['diagnostic.csv-fulfillment.borrowed.large','warm'],['diagnostic.csv-fulfillment.escaped.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','warm']]
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=(prior/name).read_text(encoding='utf-8').replace('owned-return-b725-20261114','csv-ranges-b727-20261114').replace('lython-b725-owned-return-20261114','lython-b727-csv-ranges-20261114').replace('B725','B727')
 if name=='collect.py':
  a=s.index('jobs=');z=s.index('\nassert len(jobs)',a);s=s[:a]+'jobs='+repr(jobs)+s[z:]
  s=s.replace('len(jobs)==4','len(jobs)==5').replace('started < 300','started < 420')
 elif name=='archive-owned.py':s=s.replace("len(raw['jobs'])==4","len(raw['jobs'])==5").replace('jobs=4','jobs=5')
 elif name=='retrieve.py':s=s.replace("['jobs']==4","['jobs']==5").replace("['elapsedSeconds']<360","['elapsedSeconds']<480").replace('four-job','five-job')
 elif name=='summarize.py':s=s.replace("len(raw['jobs'])==4","len(raw['jobs'])==5").replace('jobs=4','jobs=5')
 if name.endswith('.py'):ast.parse(s)
 (out/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
 for name in ['identity.json','source-identity.json','collect.py','archive-owned.py','run.sh']:t.add(out/name,arcname=name)
 t.add(r/'candidate-core.dll',arcname='candidate-core.dll');t.add(r/'catalog.json',arcname='representative.json')
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
head=identity['parentHead'];canonical=Path('benchmarks/results/2026-11-14-compiled-literal-tuples/sources-checks-and-observations.tar.xz')
blob=subprocess.check_output(['git','show',head+':'+canonical.as_posix()]);assert hashlib.sha256(blob).digest()==hashlib.sha256(canonical.read_bytes()).digest()
with tarfile.open(fileobj=io.BytesIO(blob),mode='r:xz')as t:body=t.extractfile('candidate-core.dll').read()
coreSha=hashlib.sha256(body).hexdigest();assert coreSha=='72c9a1e5787eeaaaceae43abc521be95b2b0a1a6ead5e30f9986e42bf6ac69ee'
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
def remote(code,payload=b''):
 command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
 return subprocess.run(ssh+[command],input=payload,capture_output=True,timeout=45)
inspect='''from pathlib import Path
import fcntl,json,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 p=base/'literal-tuples-b723-20261114/candidate/Lokad.Lython.dll';s=p.stat();aliases=[]
 for pattern in ['*/candidate-core.dll','*/reference-core.dll','*/candidate/Lokad.Lython.dll','*/reference/Lokad.Lython.dll']:
  for q in base.glob(pattern):
   v=q.stat()
   if(v.st_dev,v.st_ino)==(s.st_dev,s.st_ino):aliases.append(str(q.relative_to(base)))
 print(json.dumps(dict(readOnly=True,freshIdleLease=True,source=str(p),bytes=s.st_size,links=s.st_nlink,aliases=sorted(set(aliases)),freeBytes=shutil.disk_usage(base).free)))
'''
(out/'space-inspection-command.py').write_text(inspect,encoding='utf-8',newline='\n')
p=remote(inspect);assert p.returncode==0,p.stderr
(out/'space-inspection.json').write_bytes(p.stdout);d=json.loads(p.stdout)
assert d['links']==len(d['aliases'])and d['bytes']==len(body)
proof=[dict(canonicalCommit=head,canonicalArchive=canonical.as_posix(),canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='candidate-core.dll',coreSHA256=coreSha,bytes=len(body),aliases=d['aliases'],reason='Only historical72c9 working hardlinks; exact bytes remain immutable in Git. Keep qualified9cfb reference/new510a candidate, auxiliaries/catalogs/toolchains/floors.')]
(out/'retirement-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
config=dict(root='/home/lokad/lython-bench-checks/csv-ranges-b727-20261114',sourceRoot='/home/lokad/lython-bench-checks/owned-return-b725-20261114',catalogRoot='/home/lokad/lython-bench-checks/iteration-checkpoint-b717-20261114',unit='lython-b727-csv-ranges-20261114',identity=identity,proof=proof,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
template=(r.parent/'owned-tuple-return-r353/prepare-measurement.py').read_text(encoding='utf-8')
code=template.split("code=r'''",1)[1].split("'''.replace('CONFIG'",1)[0]
code=code.replace(" assert not any(base.glob('*/guest-fixtures'))"," assert not any(os.path.ismount(p) for p in base.glob('*/guest-fixtures'))")
code=code.replace(" assert digest(catalog/'representative.json')==config['identity']['catalogSHA256']\n",'')
old=" os.link(catalog/'representative.json',root/'representative.json');os.link(source/'cpython-worker.py',root/'cpython-worker.py')"
assert old in code
code=code.replace(old," assert digest(root/'representative.json')==config['identity']['catalogSHA256']\n os.link(source/'cpython-worker.py',root/'cpython-worker.py')")
code=code.replace('b725-proved-core-retirement','b727-proved-core-retirement').replace('lython-b725-fixtures','lython-b727-fixtures').replace('RuntimeMaxSec=360','RuntimeMaxSec=480').replace('current72c9ReferenceAndAllAuxiliariesCatalogsToolchainsPreserved','current9cfbReferenceAndAllAuxiliariesCatalogsToolchainsPreserved')
code=code.replace('CONFIG',repr(config));ast.parse(code)
(out/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
p=remote(code,(out/'payload.tgz').read_bytes());(out/'launch.log').write_bytes(p.stdout+p.stderr)
assert p.returncode==0,(p.stdout+p.stderr).decode()
now=datetime.datetime.now(datetime.timezone.utc)
(out/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=420)).isoformat(),ownerSeconds=480,stopSeconds=30),indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'prospective.json').write_text(json.dumps(dict(purpose=identity['purpose'],jobs=jobs,bound='One480sowner/420sjob-startguard;12sfull-request warmups,five1srotatingbatches,four fresh processes/job. No automatic restart.',controls='Borrowed DictReader(source.readlines()) and escaped-SKU quoted CSV independently verified by isolatedCPython3.13.2 and actual both frozen workers before launch. Old for-list digit control was not borrowed CSV and was corrected before timing; original catalog/verification preserved.',retirement='Only canonical-proven historical72c9 hardlinks, exact full alias/path/UID/SHA proof; current9cfb/new510a, all auxiliaries/catalogs/toolchains/floors preserved.',stopping='One usable complete-script source pair; preserve all adverse controls and decide representation/CPU/scratch-retention tradeoff. Allocation remains flat; no external speedup forecast or broad campaign.',publicationHeld=True),indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');(out/'PLAN-before-timing.md').write_text(s,encoding='utf-8',newline='\n')
s=s.replace('   Next: bounded CSV warm/fresh and borrowed-row timing with unchanged text control,','   B727active: fulfillment warm/fresh, true borrowed rows, escaped-SKU CSV and\n   unchanged text;480sowner/420sjob-startguard, earliest observation'+(now+datetime.timedelta(seconds=420)).strftime('%H:%M:%S')+'UTC.\n   Controls pass isolatedPython/actual workers. Earlier list-digit case did not feed\n   CSV borrowed rows; original catalog/verification preserved, corrected before timing.\n   Only canonical-proven historical72c9 aliases retired; current9cfb/new510a and all\n   auxiliaries/catalogs/toolchains/floors preserved. No automatic restart. Keep')
p.write_text(s,encoding='utf-8',newline='\n')
print((p.stdout+p.stderr).decode()if hasattr(p,'stdout')else'B727first measurement owner launched.',flush=True)
print('Observe after',(now+datetime.timedelta(seconds=420)).isoformat(),flush=True)
