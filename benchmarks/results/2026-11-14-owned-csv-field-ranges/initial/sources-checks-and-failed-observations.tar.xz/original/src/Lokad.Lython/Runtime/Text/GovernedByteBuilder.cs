using System.Text;
using Lokad.Lython.Runtime;

namespace Lokad.Lython.Runtime.Text;

/// <summary>
/// Accumulates arbitrary bytes while charging its retained capacity to an optional execution
/// governor. Callers that finish with a value should use a consuming conversion or
/// <see cref="Release"/> so the mutable capacity is not retained in the execution budget.
/// </summary>
internal sealed class GovernedByteBuilder : ExecutableTemporaryValue
{
    private static readonly UTF8Encoding Utf8 = new(encoderShouldEmitUTF8Identifier: false, throwOnInvalidBytes: true);

    private byte[] _buffer;
    private int _length;
    private long _committedCapacity;
    private readonly MemoryGovernor? _memoryGovernor;
    private readonly LythonSourceSpan? _allocationSpan;

    public GovernedByteBuilder() : this(0) { }

    public GovernedByteBuilder(int capacity)
    {
        _buffer = capacity > 0 ? new byte[capacity] : [];
    }

    public GovernedByteBuilder(MemoryGovernor governor) : this(governor, null, 0) { }

    public GovernedByteBuilder(MemoryGovernor governor, LythonSourceSpan? allocationSpan) : this(governor, allocationSpan, 0) { }

    public GovernedByteBuilder(MemoryGovernor governor, LythonSourceSpan? allocationSpan, int capacity,
        CancellationToken cancellationToken = default)
    {
        _memoryGovernor = governor;
        _allocationSpan = allocationSpan;
        if (capacity <= 0)
        {
            _buffer = [];
        }
        else
        {

            _memoryGovernor.ThrowIfAdmissionFailed();
            cancellationToken.ThrowIfCancellationRequested();
            _memoryGovernor.Reserve(capacity, allocationSpan);
            try
            {
                _memoryGovernor.ThrowIfAdmissionFailed();
                cancellationToken.ThrowIfCancellationRequested();
                _buffer = new byte[capacity];
                _memoryGovernor.Commit(capacity);
                _committedCapacity = capacity;
            }
            catch
            {
                _memoryGovernor.ReleaseReserved(capacity);
                throw;
            }
        }
    }

    public int Length => _length;

    // Nonconsuming conversions copy; consuming conversions detach before reuse.
    internal void Clear() => _length = 0;

    internal long CommittedCapacity => _committedCapacity;
    internal int AvailableCapacity => _buffer.Length - _length;

    public ReadOnlyMemory<byte> WrittenMemory => _buffer.AsMemory(0, _length);

    public ReadOnlySpan<byte> WrittenSpan => _buffer.AsSpan(0, _length);

    // Admission precedes the host's write borrow. Do not resize/release until
    // that actual operation completes, then publish only its validated count.
    internal Memory<byte> GetWriteWindow(int count)
    {
        EnsureAdditionalCapacity(count);
        return _buffer.AsMemory(_length, count);
    }

    internal void Advance(int count)
    {
        if ((uint)count > (uint)(_buffer.Length - _length)) throw new ArgumentOutOfRangeException(nameof(count));
        _length += count;
    }

    internal void Truncate(int length)
    {
        if ((uint)length > (uint)_length) throw new ArgumentOutOfRangeException(nameof(length));
        _length = length;
    }

    public void Append(byte value)
    {
        EnsureAdditionalCapacity(1);
        _buffer[_length++] = value;
    }

    public void Append(ReadOnlySpan<byte> bytes)
    {
        if (bytes.Length == 0)
        {
            return;
        }

        EnsureAdditionalCapacity(bytes.Length);
        bytes.CopyTo(_buffer.AsSpan(_length));
        _length += bytes.Length;
    }

    public void Append(PyString value) => Append(value.Utf8Span);

    public void Append(Rune value)
    {
        EnsureAdditionalCapacity(value.Utf8SequenceLength);
        _length += value.EncodeToUtf8(_buffer.AsSpan(_length));
    }

    public void AppendRepeated(byte value, int count)
    {
        if (count <= 0)
        {
            return;
        }

        EnsureAdditionalCapacity(count);
        _buffer.AsSpan(_length, count).Fill(value);
        _length += count;
    }

    public void AppendAscii(string text)
    {
        if (text.Length == 0)
        {
            return;
        }

        EnsureAdditionalCapacity(text.Length);
        for (var i = 0; i < text.Length; i++)
        {
            _buffer[_length + i] = (byte)text[i];
        }

        _length += text.Length;
    }

    public void AppendString(string text)
    {
        if (text.Length == 0)
        {
            return;
        }

        var byteCount = Utf8.GetByteCount(text);
        EnsureAdditionalCapacity(byteCount);
        _length += Utf8.GetBytes(text.AsSpan(), _buffer.AsSpan(_length));
    }

    public PyString ToPyString()
    {
        if (_length == 0) return PyString.Empty;
        using var storage = _memoryGovernor?.ReserveTemporary(PyString.EstimateApproximateBytes(_length), _allocationSpan);
        var exact = WrittenSpan.ToArray();
        return _memoryGovernor is null ? PyString.FromOwnedUtf8(exact)
            : PyString.FromOwnedUtf8(exact, _memoryGovernor, _allocationSpan, storage!);
    }

    public PyString ToPyStringAndRelease()
    {
        if (_length == 0)
        {
            Release();
            return PyString.Empty;
        }
        var result = PyString.FromTransferredUtf8(_buffer, _length, _memoryGovernor, _allocationSpan);
        // No refund: the immutable string now owns the already committed capacity.
        // A failed metadata admission leaves this builder intact and funded.
        _buffer = [];
        _length = 0;
        _committedCapacity = 0;
        return result;
    }

    public byte[] ToArrayAndRelease()
    {
        if (_length == 0)
        {
            Release();
            return [];
        }
        var bytes = PyBytes.EstimateApproximateBytes(_length);
        using var storage = _memoryGovernor?.ReserveTemporary(bytes, _allocationSpan);
        var exact = GetFinalBytes();
        storage?.Commit(bytes);
        Release();
        return exact;
    }

    // Consume the builder into a funded value, transferring the final-copy
    // reservation instead of charging the same backing again in a factory.
    public PyBytes ToPyBytesAndRelease()
    {
        try
        {
            if (_memoryGovernor is null) return new PyBytes(GetFinalBytes());
            using var storage = _memoryGovernor.ReserveTemporary(PyBytes.EstimateApproximateBytes(_length), _allocationSpan);
            var exact = GetFinalBytes();
            return new PyBytes(exact, _memoryGovernor, _allocationSpan, storage);
        }
        finally { Release(); }
    }

    // Only consuming callers may take the mutable backing. Release detaches it
    // before another append, while partial buffers still produce an exact copy.
    private byte[] GetFinalBytes() => _length == _buffer.Length ? _buffer : WrittenSpan.ToArray();

    public void Release()
    {
        var retired = _committedCapacity;
        _buffer = [];
        _length = 0;
        _committedCapacity = 0;
        // A refund can reenter or fail. Publish the empty owner first so later
        // cleanup never refunds another value's still-retained storage.
        _memoryGovernor?.Release(retired);
    }

    public override void Dispose() => Release();

    private void EnsureAdditionalCapacity(int additionalBytes)
    {
        if (additionalBytes <= 0)
        {
            return;
        }

        if (_length > int.MaxValue - additionalBytes)
        {
            throw RuntimeErrors.Runtime("byte buffer allocation is too large.", _allocationSpan);
        }

        var requiredCapacity = _length + additionalBytes;


        if (requiredCapacity <= _buffer.Length)
        {
            return;
        }

        Grow(requiredCapacity);
    }

    private void Grow(int requiredCapacity)
    {
        var doubledCapacity = _buffer.Length == 0
            ? 8L
            : (long)_buffer.Length * 2L;
        var newCapacityLong = Math.Max(doubledCapacity, requiredCapacity);

        if (newCapacityLong > int.MaxValue)
        {
            throw RuntimeErrors.Runtime("byte buffer allocation is too large.", _allocationSpan);
        }

        var newCapacity = (int)newCapacityLong;

        if (_memoryGovernor is not null)
        {
            _memoryGovernor.Reserve(newCapacity, _allocationSpan);
        }

        byte[] expanded;
        try
        {
            expanded = new byte[newCapacity];
            _buffer.AsSpan(0, _length).CopyTo(expanded);
            _memoryGovernor?.Commit(newCapacity);
        }
        catch { _memoryGovernor?.ReleaseReserved(newCapacity); throw; }

        var retired = _committedCapacity;
        _buffer = expanded;
        _committedCapacity = _memoryGovernor is null ? 0 : newCapacity;
        // Both backings were funded during construction. The replacement now
        // survives even if retiring the old backing invokes a failing callback.
        _memoryGovernor?.Release(retired);
    }

}
