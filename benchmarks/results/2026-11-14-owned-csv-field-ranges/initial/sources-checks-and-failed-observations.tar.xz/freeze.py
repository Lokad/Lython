from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;prior=r.parent/'owned-tuple-return-r353'
reference=json.loads((prior/'candidate-identity.json').read_text(encoding='utf-8'))
checks=json.loads((r/'focused-checks.json').read_text(encoding='utf-8'));added=json.loads((r/'added-checks.json').read_text(encoding='utf-8'))
assert len(checks)==4 and len(added)==2 and all(v['returncode']==0 for v in checks+added)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
sources={p:sha(p)for p in reference['sources']};changed=[p for p in sources if sources[p]!=reference['sources'][p]]
assert len(changed)==2,changed
env=dict(os.environ);old=next(v for k,v in env.items()if k.casefold()=='path');env={k:v for k,v in env.items()if k.casefold()!='path'}
env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+old
with(r/'candidate-build.log').open('w',encoding='utf-8',newline='\n')as f:
 p=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-restore','--no-incremental','--disable-build-servers','-m:1'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
assert p.returncode==0 and sources=={p:sha(p)for p in sources}
assert sha(prior/'candidate/Lokad.Lython.dll')=='9cfb7d5b41c02fb0ebe503d51f9ad21619b8faddb73691c7331df4c76c464030'
for role in ['reference','candidate']:shutil.copytree(prior/'candidate',r/role)
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'candidate/Lokad.Lython.dll')
shutil.copyfile(r/'candidate/Lokad.Lython.dll',r/'candidate-core.dll')
identity=dict(headBeforeCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),referenceProductionCommit='f5817a15',referenceQualification='43583650094pending independently at preparation; previous7e2/frozen72 fully qualified43579225278',
 coreSHA256={role:sha(r/role/'Lokad.Lython.dll')for role in ['reference','candidate']},sources=sources,productionFiles=len(sources),changedProductionInputs=changed,
 removedMechanisms=['decoded compacted whole-record representation','truncate-then-reappend native input transformation','per-chunk/per-marker builder Append during CSV parsing'],
 newStorage='Existing owned raw-record builder/field descriptors. Ordinary bytes remain in place; bounded escapes rewrite inside their field. Borrowed strings copy once in cancellable chunks, then use the same parser. Final strings remain independent and eagerly funded. Raw syntax stays admitted until record completion; escaped/multiline or malformed borrowed input can need more capacity/earlier denial. No new policy/owner/backend.',
 auxiliaryFiles={role:{p.name:sha(p)for p in(r/role).iterdir()if p.is_file()and p.name!='Lokad.Lython.dll'}for role in ['reference','candidate']},qualified=False,sourceAndScriptDifferIntentionally=False)
assert identity['auxiliaryFiles']['reference']==identity['auxiliaryFiles']['candidate']
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as t:
 for p in sources:t.add(p,arcname=p)
catalog=json.loads((prior/'catalog.json').read_text(encoding='utf-8'))
for role in ['reference','candidate']:(r/('allocation-'+role+'-catalog.json')).write_text(json.dumps(catalog,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
list_catalog=json.loads((r.parent/'native-for-r345/catalog.json').read_text(encoding='utf-8'))
extra=[c for c in list_catalog['cases']if c['id']=='scripts.csv-check-digits.for-list.large'];assert len(extra)==1
catalog['cases']+=extra
(r/'catalog.json').write_text(json.dumps(catalog,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(prior/'measure-allocation.py',r/'measure-allocation.py')
verify=(prior/'verify-worker.py').read_text(encoding='utf-8').replace('for index in range(3)','for index in range(4)')
assert 'range(3)'not in verify
(r/'verify-worker.py').write_text(verify,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');anchor='| Withdrawn / unresolved |';assert anchor in s
s=s.replace(anchor,'| R355, active prototype | Frozen'+identity['coreSHA256']['candidate'][:8]+', two production inputs changed fromf581/9cfb. Owned raw-field ranges replace native compaction/per-marker Append.1,116focused actual11/10checks pass, including16native/borrowed CPython-golden cases and2escaped multiline lifetime cases. Raw-syntax retention/earlier-denial tradeoff explicit. Allocation/CPU/full delivery unqualified. |\n'+anchor,1)
s=s.replace('   First focused actual11/10 plus allocation/representative storage diagnostics;', '   Prototype implemented in two runtime files;1,116focused actual11/10checks pass.\n   Frozen'+identity['coreSHA256']['candidate'][:8]+'; existing committed-record/refusal tests preserve actual\n   bytes/capacity/funding instead of assuming decoded layout. New16Python-golden\n   native/borrowed cases and2actual-I/O lifetime cases pass each target.\n   Allocation/representative storage diagnostics next;')
p.write_text(s,encoding='utf-8',newline='\n')
print('Frozen CSV owned ranges',identity['coreSHA256'],'581inputs/2changed,1116focused pass.',flush=True)
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'verify-worker.py')],check=True,env=env)
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'measure-allocation.py')],check=True,env=env)
