from pathlib import Path
import hashlib
import json
import os
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab/'comparison/quiet'
quiet.mkdir(parents=True)
template = lab.with_name('post-update-shipment-profile-20261126')
corrected = lab.with_name('current-callable-profile-20261126')/'comparison/quiet'
baseline = lab.with_name('starmap-frame-inputs-20261126')
verified = baseline/'comparison/quiet'
retained = 'cb258fe7f07a3a4dbac0dde47f080ceff4522b21'
donor_name = 'starmap-frame-inputs-b1804-20261126'
root_name = 'current-wide-shipment-profile-b1807-20261126'
unit = 'lython-b1807-current-wide-shipment-profile-20261126'

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, value):
    path.write_text(value, encoding='utf-8', newline='\n')

def save(path, value):
    write(path, json.dumps(value, indent=2, ensure_ascii=False)+'\n')

def edit(source, replacements):
    for old, new in replacements:
        assert source.count(old) == 1, old
        source = source.replace(old, new)
    return source

head = subprocess.check_output(['git','rev-parse','HEAD'], cwd=repo, text=True).strip()
assert not subprocess.check_output(['git','diff','--name-only',retained,head,'--','src','benchmarks/scripts'], cwd=repo)
assert not subprocess.check_output(['git','status','--porcelain','--','src','benchmarks/scripts'], cwd=repo)
donor = read(verified/'identity.json')
receipt = read(verified/'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['quietBeforeAndAfter']
assert sha(verified/'observations.tar.xz') == receipt['archiveSHA256']
assert sha(baseline/'candidate.patch') == donor['sourcePatchSHA256']
image = baseline/'local/candidate'
files = donor['imageFiles']['candidate']
assert len(files) == 32 and {p.name:sha(p) for p in image.iterdir()} == files
changed = subprocess.check_output(['git','diff','--name-only',donor['sourceRevision'],retained,'--','src'], cwd=repo, text=True).splitlines()
assert changed == [
    'src/Lokad.Lython/Runtime/LythonRuntime.Calls.cs',
    'src/Lokad.Lython/Runtime/PyExecutableFunction.cs',
    'src/Lokad.Lython/Runtime/PyItertools.Transforms.cs',
]
for file in changed:
    actual = subprocess.check_output(['git','show',retained+':'+file], cwd=repo).decode()
    assert actual == (baseline/'source'/file).read_text(encoding='utf-8')
catalog = read(baseline/'local/representative.json')
profiles = [
    ['current-wide-shipment-async','diagnostic.shipment-starmap-wide-lists','candidate'],
]
cases = {profile[1] for profile in profiles}
catalog['cases'] = [case for case in catalog['cases'] if case['id'] in cases]
assert len(catalog['cases']) == 1
save(quiet/'catalog.json', catalog)
identity = dict(sourceRevision=retained, inspectedHead=head, sourceDifference=[],
    imageFiles={'candidate':files}, coreSHA256={'candidate': files['Lokad.Lython.dll']},
    donorArchiveSHA256=receipt['archiveSHA256'], profileCatalogSHA256=sha(quiet/'catalog.json'),
    profiles=profiles, purpose='Locate remaining costs in the delivered five-item asynchronous shipment report.')
save(quiet/'identity.json',identity)
for name in ('collect.py','ops-profile.py','run.sh'):
    source = (template/'comparison/quiet'/name).read_text(encoding='utf-8')
    if name == 'collect.py':
        assert source.count('converted-dictionary-update-b1763-20261126') == 2
        source = source.replace('converted-dictionary-update-b1763-20261126',donor_name)
        source = edit(source, [('b1765-fixtures','b1807-fixtures'),('12*1024*1024-256*1024','4_700_000')])
    if name.endswith('.py'):
        compile(source,name,'exec')
    write(quiet/name,source)
assert b'\r' not in (quiet/'run.sh').read_bytes()
source = (corrected/'analyze.py').read_text(encoding='utf-8')
compile(source,'analyze.py','exec')
write(quiet/'analyze.py',source)
source = edit((template/'quiet.py').read_text(encoding='utf-8'),[
    ('lython-b1765-post-update-shipment-profile-20261126',unit),
    ('converted-dictionary-update-b1763-20261126',donor_name),
    ("cfg['payloadBytes']+12*1024*1024","cfg['payloadBytes']+cfg['expandedBytes']+4_700_000"),
    ('expanded+4*1024*1024','expanded+4_700_000'),
])
compile(source,'quiet.py','exec')
write(lab/'quiet.py',source)
worker = baseline/'local/cpython-worker.py'
assert sha(worker) == donor['cpythonWorkerSHA256']
sdk = Path.home()/'.dotnet11'
dotnet = sdk/'dotnet.exe'
env = dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
proof = quiet/'verification.json'
subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'catalog.json',
    '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',worker,'--out',proof],
    cwd=repo,env=env,check=True,timeout=70)
report = read(proof)
assert report['state'] == 'Completed' and report['caseCount'] == 1
assert report['catalogSha256'] == identity['profileCatalogSHA256']
assert report['launched']['library']['sha256'] == files['Lokad.Lython.dll']
payload = quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=6) as package:
    for name in ('identity.json','catalog.json','collect.py','ops-profile.py','run.sh'):
        package.add(quiet/name,arcname=name,recursive=False)
save(quiet/'upload.json',dict(root=root_name,payloadSHA256=sha(payload),
    payloadBytes=payload.stat().st_size,
    expandedBytes=sum((quiet/name).stat().st_size for name in ('identity.json','catalog.json','collect.py','ops-profile.py','run.sh')),
    expectedDonorArchiveSHA256=receipt['archiveSHA256']))
