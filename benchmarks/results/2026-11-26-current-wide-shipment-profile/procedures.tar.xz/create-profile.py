from pathlib import Path

lab = Path(__file__).resolve().parent
previous = lab.with_name("current-json-construction-profile-20261126")
source = (previous / "prepare.py").read_text(encoding="utf-8")
for before, after in (
    ("baseline = lab.with_name('native-segments-at-emission-20261126')",
     "baseline = lab.with_name('starmap-frame-inputs-20261126')"),
    ("29e078ddd8ba14299c7837d322427423070c42ed", "cb258fe7f07a3a4dbac0dde47f080ceff4522b21"),
    ("native-segments-at-emission-b1800-20261126", "starmap-frame-inputs-b1804-20261126"),
    ("current-json-construction-profile-b1801-20261126", "current-wide-shipment-profile-b1807-20261126"),
    ("lython-b1801-current-json-construction-profile-20261126", "lython-b1807-current-wide-shipment-profile-20261126"),
    ("    'src/Lokad.Lython/Frontend/ExecutableScript.NativeSegments.cs',\n"
     "    'src/Lokad.Lython/Frontend/ExecutableScript.cs',\n"
     "    'src/Lokad.Lython/Frontend/ExecutableStackLayout.cs',",
     "    'src/Lokad.Lython/Runtime/LythonRuntime.Calls.cs',\n"
     "    'src/Lokad.Lython/Runtime/PyExecutableFunction.cs',\n"
     "    'src/Lokad.Lython/Runtime/PyItertools.Transforms.cs',"),
    ("catalog = read(lab.with_name('json-single-string-pass-20261126')/'local/representative.json')",
     "catalog = read(baseline/'local/representative.json')"),
    ("    ['current-service-totals','diagnostic.json-service-quantity-totals','candidate'],\n"
     "    ['current-json-lines-async','scripts.json-summary-helpers.large','candidate'],",
     "    ['current-wide-shipment-async','diagnostic.shipment-starmap-wide-lists','candidate'],"),
    ("assert len(catalog['cases']) == 2", "assert len(catalog['cases']) == 1"),
    ("Locate current JSON scan, record construction and aggregation costs.",
     "Locate remaining costs in the delivered five-item asynchronous shipment report."),
    ("('b1765-fixtures','b1801-fixtures'),('12*1024*1024-256*1024','6*1024*1024-256*1024')",
     "('b1765-fixtures','b1807-fixtures'),('12*1024*1024-256*1024','4_700_000')"),
    ('"cfg[\'payloadBytes\']+12*1024*1024","cfg[\'payloadBytes\']+6*1024*1024"',
     '"cfg[\'payloadBytes\']+12*1024*1024","cfg[\'payloadBytes\']+cfg[\'expandedBytes\']+4_700_000"'),
    ("    (\"cfg['payloadBytes']+12*1024*1024\",\"cfg['payloadBytes']+cfg['expandedBytes']+4_700_000\"),",
     "    (\"cfg['payloadBytes']+12*1024*1024\",\"cfg['payloadBytes']+cfg['expandedBytes']+4_700_000\"),\n"
     "    ('expanded+4*1024*1024','expanded+4_700_000'),"),
    ("report['caseCount'] == 2", "report['caseCount'] == 1"),
    ("payloadBytes=payload.stat().st_size,expectedDonorArchiveSHA256=receipt['archiveSHA256']))",
     "payloadBytes=payload.stat().st_size,\n"
     "    expandedBytes=sum((quiet/name).stat().st_size for name in ('identity.json','catalog.json','collect.py','ops-profile.py','run.sh')),\n"
     "    expectedDonorArchiveSHA256=receipt['archiveSHA256']))"),
):
    assert source.count(before) == 1, before
    source = source.replace(before, after)
compile(source, "prepare.py", "exec")
(lab / "prepare.py").write_text(source, encoding="utf-8", newline="\n")
