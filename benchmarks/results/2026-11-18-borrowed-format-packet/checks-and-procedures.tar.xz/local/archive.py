from pathlib import Path
import hashlib,json,shutil,tarfile

lab=Path(__file__).resolve().parent
quiet=lab/"quiet"
out=Path("benchmarks/results/2026-11-18-borrowed-format-packet")
read=lambda file:json.loads(file.read_text(encoding="utf-8-sig"))
sha=lambda file:hashlib.sha256(file.read_bytes()).hexdigest()
status=read(quiet/"terminal-status.json")
receipt=read(quiet/"archive-receipt.json")
assert status["receipt"]==receipt and status["exitCode"]=="0"
assert not status["live"] and not status["remainingWorkers"] and not status["remainingTrace"]
assert receipt["jobs"]==6 and all(receipt[k] for k in ("complete","allWorkersJoined","guestFixturesRemoved",
         "quietBeforeAndAfter","archivedAndVerifiedUnderLease"))
archive=quiet/"observations.tgz"
assert sha(archive)==receipt["archiveSHA256"]
identity=read(lab/"method-format-allocation-summary.json")["identity"]
for role,mapping in identity["images"].items():
    assert len(mapping)==32 and read(lab/f"method-format-{role}-verify.json")["state"]=="Completed"
    assert {name:sha(lab/"frozen"/role/name) for name in mapping}==mapping
for framework in ("net11.0","net10.0"):
    for prefix,count in (("compact-win",735),("compact-wsl",22)):
        assert f"Passed: {count:5d}" in (lab/f"{prefix}-{framework}.log").read_text(encoding="utf-8-sig")
summary=read(lab/"quiet-summary.json")
summary.pop("retentionDecisionPending",None)
summary["retained"]=True
summary["images"]=identity
summary["allocation"]=read(lab/"method-format-allocation-summary.json")["rows"]
summary["sourcePatchSHA256"]=sha(lab/"rebased-source.patch")
summary["focusedChecksPerFramework"]=dict(windowsPublic=735,ubuntuWhiteBox=22)
(out/"summary.json").write_text(json.dumps(summary,indent=2,ensure_ascii=False)+"\n", encoding="utf-8")
shutil.copyfile(archive,out/archive.name)
with tarfile.open(out/"checks-and-procedures.tar.xz","w:xz") as procedure:
    for path,prefix in ((lab,"local"),(quiet,"quiet")):
        for p in sorted(path.iterdir()):
            if p.is_file() and p.suffix in (".sh",".py",".json",".log",".patch"):
                procedure.add(p,arcname=f"{prefix}/{p.name}")
assert sha(out/archive.name)==receipt["archiveSHA256"]
print("Verified six jobs, both worker images, focused Release results and source patch.")
