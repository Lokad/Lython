from pathlib import Path
import gzip, hashlib, io, json, subprocess, tarfile

lab = Path(__file__).resolve().parent
sha = lambda data: hashlib.sha256(data).hexdigest()
def from_origin(path):
    data = subprocess.check_output(["git","show",f"origin/master:{path}"])
    assert data == Path(path).read_bytes()
    return data

cores = []
for folder, digest, aliases in [
    ("compact-keyword-layout", "bde27322db4d109914f956ff48a73ddea6a6f5a788cf8cf94ded7d76aa2dd289", [
         "utf8-keyword-binding-b997-20261118/reference/Lokad.Lython.dll",
         "compact-keyword-layout-b998-20261118/reference/Lokad.Lython.dll"]),
]:
    path = f"benchmarks/results/2026-11-18-{folder}/reference-core.dll.gz"
    packed = from_origin(path)
    raw = gzip.decompress(packed)
    assert sha(raw) == digest
    cores.append(dict(paths=aliases,canonical=path,canonicalSHA256=sha(packed),sha256=digest,bytes=len(raw),
                      links=len(aliases),kind="exact archived measured core replica",committedBlobVerified=True))

proofs = []
for remote, folder, member_names in [
    ("compact-keyword-layout-b998-20261118", "compact-keyword-layout",
        [None,"confirmation/confirmation.json","identity.json","collect.py","archive-owned.py","run.sh"]),
    ("utf8-keyword-binding-b997-20261118", "utf8-guest-keyword-binding",
        [None,"representative.json"]),
    ("lazy-keyword-index-b996-20261118", "lazy-keyword-index", [None,"representative.json"]),
    ("fixed-list-unpack-b994-20261118", "fixed-list-unpack", [None,"representative.json"]),
    ("expanded-call-b992-20261118", "borrowed-expanded-call", [None,"representative.json"]),
    ("retained-cpython-b993-20261118", "retained-cpython-checkpoint", [None,"representative.json"]),
    ("expanded-report-cpu-b995-20261118", "expanded-report-attribution", [None,"identity.json","ram-manifest.json"]),
]:
    path=f"benchmarks/results/2026-11-18-{folder}/observations.tgz"
    packed=from_origin(path)
    with tarfile.open(fileobj=io.BytesIO(packed),mode="r:gz") as archive:
        for member in member_names:
            raw=packed if member is None else archive.extractfile(member).read()
            proofs.append(dict(paths=[remote+"/"+(member or "observations.tgz")], canonical=path,
                               canonicalSHA256=sha(packed), member=member, sha256=sha(raw), bytes=len(raw),
                               links=1, kind="exact archived observation replica", committedBlobVerified=True))
prior=json.loads((lab.parent/"borrowed-expanded-call-r566/quiet-space.json").read_text(encoding="utf-8"))
for source in prior["replicas"]:
    path=source["canonical"]
    if not path.startswith(("benchmarks/results/2026-11-16-","benchmarks/results/2026-11-17-")): continue
    packed=from_origin(path)
    assert source["links"]==len(source["paths"])==1 and sha(packed)==source["sha256"] and len(packed)==source["bytes"]
    proofs.append(source)

remote=r"""
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
root=Path('/home/lokad/lython-bench-checks').resolve()
assert root==Path('/home/lokad/lython-bench-checks')
cores=CORES
with (root/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert not subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.13.*cpython-worker.py'],capture_output=True).stdout
    assert not any(os.path.ismount(p) for p in root.glob('*/guest-fixtures'))
    def verify(p,proof):
        v=p.lstat()
        assert p.resolve()==p and p.is_relative_to(root) and stat.S_ISREG(v.st_mode)
        assert v.st_uid==os.getuid() and v.st_size==proof['bytes'] and v.st_nlink==proof['links']
        assert hashlib.sha256(p.read_bytes()).hexdigest()==proof['sha256']
        return v
    identities={}
    for proof in cores:
        records=[verify(root/p,proof) for p in proof['paths']]
        dev_inode={(x.st_dev,x.st_ino) for x in records}
        assert len(dev_inode)==1
        identities[next(iter(dev_inode))]=[]
    for directory,_,names in os.walk(root):
        for name in names:
            p=Path(directory)/name
            v=p.lstat()
            identity=(v.st_dev,v.st_ino)
            if identity in identities:
                identities[identity].append(p.relative_to(root).as_posix())
    assert sorted(sorted(p) for p in identities.values())==sorted(sorted(p['paths']) for p in cores)
    verified=list(cores)
    for proof in PROOFS:
        path=root/proof['paths'][0]
        if path.exists():
            verify(path,proof)
            verified.append(proof)
    print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free,replicas=verified)))
""".replace("CORES",repr(cores)).replace("PROOFS",repr(proofs))
ssh=["C:/Windows/System32/OpenSSH/ssh.exe","-i",str(Path.home()/".ssh/id_lython-bench.pem"),
     "-o","BatchMode=yes","-o","ConnectTimeout=15","lokad@20.166.121.73"]
response=subprocess.run(ssh+["python3 -"],input=remote.encode(),capture_output=True,check=True,timeout=45)
space=json.loads(response.stdout)
(lab/"quiet-space.json").write_text(json.dumps(space,indent=2)+"\n",encoding="utf-8")
print(space["freeBytes"],"bytes free;",len(space["replicas"]),"exact replicas verified")
