from pathlib import Path
import ast, hashlib, json, shutil, tarfile

lab=Path(__file__).resolve().parent
donor=lab.parent/"borrowed-format-packet-r574"
previous=donor/"quiet"
quiet=lab/"quiet"
quiet.mkdir(exist_ok=False)
load=lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
sha=lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,source):
    if path.suffix==".py": ast.parse(source)
    path.write_text(source,encoding="utf-8",newline="\n")
def save(path,data): write(path,json.dumps(data,ensure_ascii=False,indent=2)+"\n")

prior=load(previous/"config.json")
screen=load(donor/"method-format-allocation-summary.json")["identity"]
space=load(lab/"quiet-space.json")
catalog=donor/"method-format-catalog.json"
images=screen["images"]
source_files=prior["identity"]["imageFiles"]["candidate"]
core="Lokad.Lython.dll"
assert screen["casesSHA256"]==sha(catalog)
for role,files in images.items():
    assert len(files)==32 and files==source_files|{core:files[core]}
    assert {name:sha(donor/"frozen"/role/name) for name in files}==files
    verified=load(donor/f"method-format-{role}-verify.json")
    assert verified["state"]=="Completed" and verified["catalogSha256"]==sha(catalog)
    (quiet/role).mkdir()

target="scripts.report-forwarding.expanded"
jobs=[("calls.positional.large","warm"),("strings.method-format-report.medium","warm")]
count=len(jobs)
identity=dict(sourceRevision="604dc52db versus 0cf1156c8",
              purpose="R574 unchanged-image positional control confirmation",
              imageFiles=images,catalogSHA256=sha(catalog),normalAdapterPin="0.4.0",
              coreSHA256={label:images[role][core] for role in images for label in (role,role+"-control")})
root="/home/lokad/lython-bench-checks/borrowed-format-control-b1000-20261118"
unit="lython-b1000-borrowed-format-control-20261118"
read=lambda path:path.read_text(encoding="utf-8")
def rename(source):
    return source.replace("Fixed-list unpack source pair","Borrowed format source pair").replace("Compact UTF-8 keyword source pair","Borrowed format source pair")

runner=rename(read(previous/"collect.py")).replace("labels=['candidate','reference','candidate-control','reference-control']", "labels=['reference-control','candidate-control','reference','candidate']")
a=runner.index("\njobs = ")
b=runner.index("\nassert len(jobs)",a)
runner=runner[:a]+"\njobs = "+repr(jobs)+runner[b:]
write(quiet/"collect.py",runner.replace("assert len(jobs)==6",f"assert len(jobs)=={count}"))
archive=read(previous/"archive-owned.py").replace("len(raw['jobs'])==6",f"len(raw['jobs'])=={count}").replace("jobs=6,",f"jobs={count},")
write(quiet/"archive-owned.py",archive)
write(quiet/"run.sh",read(previous/"run.sh").replace(prior["root"],root))
assert b"\r" not in (quiet/"run.sh").read_bytes()
save(quiet/"identity.json",identity)
names=["collect.py","archive-owned.py","run.sh","identity.json",]
payload=quiet/"payload.tgz"
with tarfile.open(payload,"w:gz") as out:
    for name in names: out.add(quiet/name,arcname=name)
expanded=sum((quiet/name).stat().st_size for name in names)
need=254*1024*1024+expanded+512*1024
available=space["freeBytes"]
selected=[]
for proof in sorted(space["replicas"],key=lambda p:-p["bytes"]):
    if available>=need: break
    available+=proof["bytes"]
    selected.append(proof)
save(quiet/"preflight.json",dict(available=available,need=need,withoutRetirement=space["freeBytes"],selected=selected))
assert available>=need,(available,need)
config=dict(root=root,unit=unit,source=prior["root"],sourceRole="candidate",sourceFiles=source_files,
            sourceCatalogSHA256=prior["catalogSHA256"],catalogSHA256=sha(catalog),identity=identity,
            retireGroups=selected,payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),unpackedBytes=expanded)
save(quiet/"config.json",config)
launcher=read(previous/"remote-launch.py")
a=launcher.index("\nc=")+1
b=launcher.index("\nb=Path(")
launcher=launcher[:a]+"c="+repr(config)+launcher[b:]
launcher=launcher.replace("os.link(source/c['sourceRole']/n,p)", "os.link(source/role/n,p)")
launcher=launcher.replace(" for n,h in c['sourceFiles'].items():assert sha(source/c['sourceRole']/n)==h,n",
                          " for role,files in c['identity']['imageFiles'].items():\n  for n,h in files.items():assert sha(source/role/n)==h,n")
write(quiet/"remote-launch.py",launcher.replace("lython-b999-fixtures","lython-b1000-fixtures").replace("RuntimeMaxSec=330","RuntimeMaxSec=540"))
retrieve=rename(read(previous/"retrieve.py")).replace("['jobs']==6",f"['jobs']=={count}")
write(quiet/"retrieve.py",retrieve)
launch=rename(read(donor/"launch-quiet.py")).replace("seconds=295","seconds=120").replace("before 295 seconds","before 120 seconds")
write(lab/"launch-quiet.py",launch)
summary=read(donor/"summarize-quiet.py").replace("len(raw['jobs'])==6","len(raw['jobs'])==2")
summary=summary[:summary.index("reference=json.loads")]
write(lab/"summarize-quiet.py",summary)
print("Verified both complete images and",count,"jobs, with",available-need,"bytes above the staging requirement")
