set -eu
root=/home/lokad/lython-bench-checks/csv-compiled-unpack-b1325-20261122
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
