from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.parent/"cpython-checkpoint-20261123/comparison"
donor=lab.parent/"materialized-cased-split-20261123/comparison-bounded"
comparison=lab/"comparison"
quiet=comparison/"quiet"
quiet.mkdir(parents=True)
core="Lokad.Lython.dll"
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(b):return hashlib.sha256(b).hexdigest()
def h(p):return sha(p.read_bytes())
def git(*args):return subprocess.check_output(["git",*args],cwd=repo)
def get(path,name):return git("show",f"origin/master:benchmarks/results/{path}/{name}")
def write(p,s):
    if p.suffix==".py":compile(s,str(p),"exec")
    p.write_text(s,encoding="utf-8",newline="\n")
def save(p,o):write(p,json.dumps(o,ensure_ascii=False,indent=2)+"\n")
accepted="2026-11-23-materialized-cased-split-bounded"
source=json.loads(get(accepted,"source.json"))
receipt=json.loads(get(accepted,"archive-receipt.json"))
assert all(receipt[k] for k in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease"))
assert sha(get(accepted,"observations.tgz"))==receipt["archiveSHA256"]
proof=read(lab/"verify.json")
catalog=quiet/"representative.json"
shutil.copyfile(lab/"representative.json",catalog)
files=source["imageFiles"]["candidate"]
assert len(files)==32 and {n:h(donor/"frozen-candidate"/n)for n in files}==files
assert not git("diff","--name-only",source["retainedRevision"],"HEAD","--","src","tests")
assert proof["state"]=="Completed" and proof["caseCount"]==7 and proof["catalogSha256"]==h(catalog)
assert proof["launched"]["library"]["sha256"]==files[core]
prev=read(prior/"quiet/config.json")
old=read(prior/"quiet/retrieved/confirmation/confirmation.json")
assert old["complete"] and len(old["jobs"])==8
python,={meta["executableSha256"] for j in old["jobs"] for name,meta in j["identities"].items() if name.startswith("CPython")}
jobs=[(j["case"],j["lanes"][0])for j in old["jobs"]]
jobs += [("diagnostic.text-summary.materialized-wide","warm")]
save(comparison/"jobs.json",jobs)
root="/home/lokad/lython-bench-checks/integrated-current-cpython-b1438-20261123"
unit="lython-b1438-integrated-current-cpython-20261123"
identity={**prev["identity"],"sourceRevision":source["retainedRevision"],"candidate":source["retainedRevision"],
    "purpose":"Refresh CPython after retained compiler, argument and materialized text changes.",
    "imageFiles":{"candidate":files},"coreSHA256":{role:files[core]for role in ("candidate","candidate-control")},
    "auxiliaryFiles":{n:x for n,x in files.items()if n!=core},
    "catalogs":{"representative.json":{"sha256":h(catalog)}},
    "B1429CatalogSHA256":prev["identity"]["catalogs"]["representative.json"]["sha256"],
    "expectedCPythonSHA256":python}
save(quiet/"identity.json",identity)
for name in ("collect.py","run.sh","archive-owned.py","retrieve.py"):
    s=(prior/"quiet"/name).read_text(encoding="utf-8").replace(prev["root"],root).replace(prev["unit"],unit).replace("B1429","B1438")
    if name=="collect.py":
        a,b=s.index("    for case_id,lane in ["),s.index("        assert time.monotonic()-started<480")
        s=s[:a]+"    for case_id,lane in "+repr(jobs)+":\n"+s[b:]
        s=s.replace("started<480","started<525")
        s=s.replace("== hashlib.sha256(python.read_bytes()).hexdigest()",
                    "== hashlib.sha256(python.read_bytes()).hexdigest() == identity['expectedCPythonSHA256']")
        s=s.replace("['CPython-control','candidate-control','CPython','candidate']",
                    "['candidate','CPython','candidate-control','CPython-control']")
    if name=="archive-owned.py":
        s=s.replace("len(raw['jobs'])==8","len(raw['jobs'])==9").replace("jobs=8,elapsed","jobs=9,elapsed")
    if name=="retrieve.py":
        s=s.replace("status['receipt']['jobs']==8","status['receipt']['jobs']==9")
    write(quiet/name,s)
assert b"\r" not in (quiet/"run.sh").read_bytes()
parts=("identity.json","representative.json","collect.py","run.sh","archive-owned.py")
payload=quiet/"payload.tgz"
with tarfile.open(payload,"w:gz")as tar:
    for n in parts:tar.add(quiet/n,arcname=n)
donor_config=read(donor/"quiet/config.json")
cfg={**prev,"root":root,"unit":unit,"identity":identity,"source":donor_config["root"],
    "sourceRole":"candidate","sourceFiles":files,"sourceCatalogSHA256":source["catalogs"]["representative.json"]["sha256"],
    "donorArchiveSHA256":receipt["archiveSHA256"],"retireGroups":[],"payloadBytes":payload.stat().st_size,
    "payloadSHA256":h(payload),"unpackedBytes":sum((quiet/n).stat().st_size for n in parts)}
save(quiet/"config.json",cfg)
s=(prior/"quiet/remote-launch.py").read_text(encoding="utf-8")
a,b=s.index("\nc=")+1,s.index("\nb=Path(")
s=(s[:a]+"c="+repr(cfg)+s[b:]).replace("b1429-fixtures","b1438-fixtures").replace("RuntimeMaxSec=525","RuntimeMaxSec=555")
s=s.replace("640*1024","2*1024*1024")
write(quiet/"remote-launch.py",s)
launch=(prior/"launch.py").read_text(encoding="utf-8")
write(comparison/"launch.py",launch.replace("seconds=470","seconds=525").replace("before 470 seconds","before 525 seconds"))
print(root,cfg["unpackedBytes"],source["retainedRevision"])
