
from pathlib import Path
import gzip
import hashlib
import json
import shutil
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/"comparison/quiet"
dest=repo/"benchmarks/results/2026-11-23-integrated-cpython-checkpoint"
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+"\n",encoding="utf-8",newline="\n")
previous=repo/"benchmarks/results/2026-11-23-retained-cpython-checkpoint"
identity=read(quiet/"identity.json")
assert identity==read(quiet/"retrieved/identity.json")
files=identity["imageFiles"]["candidate"]
old=read(previous/"source.json")["imageFiles"]["candidate"]
core="Lokad.Lython.dll"
assert [n for n,d in files.items()if d!=old[n]]==[core]
frozen=lab.parent/"materialized-cased-split-20261123/comparison-bounded/frozen-candidate"
assert files=={name:h(frozen/name) for name in files}
proof=read(lab/"verify.json")
assert proof["state"]=="Completed" and proof["caseCount"]==7
assert proof["catalogSha256"]==h(quiet/"representative.json")==identity["catalogs"]["representative.json"]["sha256"]
receipt=read(quiet/"archive-receipt.json")
summary=read(quiet/"summary.json")
assert receipt["archiveSHA256"]==h(quiet/"observations.tgz") and summary["timedBatches"]==252
assert summary["source"]==identity["candidate"]
assert summary["cpythonExecutableSHA256"]==read(previous/"summary.json")["cpythonExecutableSHA256"]
identity["localImageVerificationSHA256"]=h(lab/"verify.json")
identity["changedImageFiles"]=[core]
original=repo/"benchmarks/results/2026-11-23-materialized-cased-split-bounded/candidate-core.dll.gz"
assert hashlib.sha256(gzip.decompress(original.read_bytes())).hexdigest()==files[core]
identity["coreArchive"]="../2026-11-23-materialized-cased-split-bounded/candidate-core.dll.gz"

dest.mkdir()
save(dest/"source.json",identity)
for name in ("archive-receipt.json","observations.tgz","terminal-status.json","summary.json"):
    shutil.copyfile(quiet/name,dest/name)
with tarfile.open(dest/"procedures.tar.xz","w:xz") as t:
    for n in ("stage.py","archive.py","report-data.py","verify.json","comparison/jobs.json","comparison/launch.py","comparison/quiet/config.json",
              "comparison/quiet/remote-launch.py","comparison/quiet/retrieve.py","comparison/quiet/observe-not-before.json",
              "comparison/quiet/launch.log","comparison/quiet/collect.py","comparison/quiet/archive-owned.py"):
        t.add(lab/n,arcname=n,recursive=False)
