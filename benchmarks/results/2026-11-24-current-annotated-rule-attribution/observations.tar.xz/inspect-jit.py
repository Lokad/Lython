from pathlib import Path
import hashlib
import json
import os
import re
import subprocess

lab=Path(__file__).resolve().parent
source=lab.parent/'decoded-closed-defaults-20261124'
identity=json.loads((source/'comparison/identity.json').read_text(encoding='utf-8-sig'))
image=source/'candidate'
expected=identity['imageFiles']['candidate']|identity['helperFiles']
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert {p.name:sha(p) for p in image.iterdir()}==expected
sdk=Path.home()/'.dotnet11'
log=lab/'native-entry.asm'
out=lab/'jit-observation.json'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),DOTNET_TieredCompilation='0',
    DOTNET_JitDisasm='StartNativeCall StartInline TryReturnDefinition TryStartForwardedComputedDefinition TryPrepareFixedTupleReturn',
    DOTNET_JitStdOutFile=str(log))
subprocess.run([sdk/'dotnet.exe',image/'ValidatedAllocation.dll',image,lab/'catalog.json',out],env=env,timeout=45,check=True)
assert all(row['sharedBudgetBaselineRestored'] for row in json.loads(out.read_text(encoding='utf-8-sig'))['rows'])
records=[]
for fragment in log.read_text(encoding='utf-8-sig').split('; Assembly listing for method ')[1:]:
    signature,asm=fragment.split('\n',1)
    if 'Lokad.Lython.Runtime.' not in signature:continue
    method=signature.split(':',1)[-1].split('(',1)[0]
    frame=re.search(r'\bsub\s+rsp,\s*(\d+)\b',asm)
    length=re.search(r'Total bytes of code (\d+)',asm)
    records.append(dict(method=method,signature=signature,stackFrameBytes=int(frame[1]) if frame else None,generatedBytes=int(length[1])))
assert any(method['method']=='StartNativeCall' for method in records)
(lab/'jit-summary.json').write_text(json.dumps(dict(methods=records,imageFiles=expected),indent=2)+'\n',encoding='utf-8')
for method in records:print(method['method'],method['stackFrameBytes'],method['generatedBytes'])
