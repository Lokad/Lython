from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab=Path(__file__).resolve().parent
root=lab.parents[3]
out=root/'benchmarks/results/2026-11-24-current-annotated-rule-attribution'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
meta=read(lab.parent/'annotated-factories-cpython-20261124/external/identity.json')
summary=read(lab/'run-summary.json')
codes=read(lab/'factory-shapes.json')
assert summary['allProcessesJoined'] and not summary['timingQualification']
assert summary['sourceRevision']==meta['candidate'] and summary['retainedSource']==meta['productionSource']
assert summary['catalogSha']==sha(lab/'catalog.json')
assert read(lab/'verification.json')['caseCount']==4 and len(codes['rows'])==4
assert read(lab/'factory-tapes.json')['coreSHA256']==meta['coreSHA256']['candidate']
assert read(lab/'jit-summary.json')['imageFiles']['Lokad.Lython.dll']==meta['coreSHA256']['candidate']
roles=('eager-factories','postponed-factories','captured-factories','defaulted-factories')
for role,code in zip(roles,codes['rows'],strict=True):
    record=read(lab/role/'record.json')
    assert record['workload']==code['case'] and record['allProcessesJoined']
    assert sha(lab/role/'warm.nettrace')==record['nettraceSha'] and record['coreSha']==meta['coreSHA256']['candidate']
    assert record['before']['status']==record['after']['status']=='Equivalent'
    assert record['closed']['status']=='Closed'
out.mkdir(exist_ok=True)
for item in ('attribution.json','factory-shapes.json','run-summary.json','jit-summary.json'):
    shutil.copyfile(lab/item,out/item)
items=['archive.py','warm-trace.py','analyze.py','shapes.py','inspect-jit.py','catalog.json','verification.json','factory-tapes.json',
       'native-entry.asm','jit-observation.json','inspect/Inspect.dll','inspect/Inspect.deps.json','inspect/Inspect.runtimeconfig.json']
items += [f'{role}/{name}' for role in roles for name in ('record.json','warm.nettrace','warm.speedscope.json','worker.stderr','capture.log')]
with tarfile.open(out/'observations.tar.xz','w:xz',preset=4) as archive:
    for item in items:archive.add(lab/item,arcname=item)
with tarfile.open(out/'observations.tar.xz') as archive:
    for item in archive:assert hashlib.sha256(archive.extractfile(item).read()).hexdigest()==sha(lab/item.name)
print('Verified four exact traces, compiled tapes and the dedicated JIT listing')
