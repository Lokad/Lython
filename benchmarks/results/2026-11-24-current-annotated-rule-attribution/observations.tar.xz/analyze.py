from collections import Counter
from pathlib import Path
import json

lab=Path(__file__).resolve().parent
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
labels=('eager-factories','postponed-factories','captured-factories','defaulted-factories')
classes={
 'entry and operands':('StartNativeCall','StartInline','TryStartBoundInvocation','EnterFunctionCall','LeaveFunctionCall','TryExecuteNativeCall','PrepareExecutableCallArguments','SlowNativeArguments','StackWindow','ReadExecutableOperand','TakeOperand','PublishInstructionResult','ExecutableCallWorkspace'),
 'dispatch':('ExecuteInstructionPrefix','ExecuteNative','ExecuteSingleInstruction','ExecutableInstruction'),
 'binding':('ExecutableCaptures','ExecutableCell','LoadLocal','LoadClosure','CaptureExecutable','FunctionDefault','BindIntoSlots'),
 'definitions and metadata':('CreateClosedComputedDefinition','CreateClosedFunctionDefinition','CreateInlineDefinition','AllocateExecutableDefaults','TryCompleteDirectDefinition','TryCreateDirectDefinition','ReadEagerFunctionAnnotations','AttachAdmittedAnnotations','EvaluateClosedDefault','CreateExecutableFunction','PyExecutableFunction..ctor','PyFunctionBase..ctor','CreatePreparedPositionalDefaults'),
 'admission and cleanup':('MemoryGovernor','MemoryScope','MemoryBudget','RetireTo','CloseResources','DisposeTemporary','RefundUnpublished'),
 'arithmetic':('TryMachineBinary','EvaluateBinaryOperator','TryEvaluateDirectIntegerReturn','EvaluateInteger','TryIntegerChain'),
}
def symbol(name):
    return name.split('(',1)[0].split('!',1)[-1]

def describe(label):
    path=lab/label
    record=read(path/'record.json')
    raw=read(path/'warm.speedscope.json')
    names=[row['name'] for row in raw['shared']['frames']]
    threads=Counter()
    inclusive=Counter()
    nearest=Counter()
    native_leaf=Counter()
    reservation_paths=Counter()
    total_intervals=0
    for profile in raw['profiles']:
        assert profile['unit']=='milliseconds' and profile['type']=='evented'
        frames=[]
        last=profile['startValue']
        for event in profile['events']:
            now=event['at']
            delta=now-last
            if delta>0:
                runtime=[symbol(frame) for frame in frames if 'Lokad.Lython.Runtime.' in frame]
                if runtime and frames[-1] == "CPU_TIME":
                    total_intervals+=1
                    threads[profile['name']]+=delta
                    nearest[runtime[-1]]+=delta
                    inclusive.update({name:delta for name in set(runtime)})
                    native_leaf[symbol(frames[-1])]+=delta
                    if 'MemoryGovernor' in runtime[-1] and len(runtime)>1:
                        context=next((key for key in reversed(runtime[:-1]) if 'MemoryGovernor' not in key),None)
                        if context: reservation_paths[context]+=delta
            if event['type']=='O':frames.append(names[event['frame']])
            else:assert names[event['frame']]==frames.pop()
            last=now
        assert not frames
    total=sum(nearest.values())
    groups=Counter()
    for name,delta in nearest.items():
        match='unresolved under native entry' if name.endswith('.StartNativeCall') else next(
            (key for key,patterns in classes.items() if any(value in name for value in patterns)),'other')
        groups[match]+=delta
    assert abs(sum(groups.values())-total)<0.001
    return dict(case=record['workload'],profile=label,verifiedInvocations=sum(b['completedInvocations'] for b in record['batches']),
        totalRuntimeAncestryMs=total,runtimeIntervals=total_intervals,threadTimesMs=threads,
        exclusiveNearestRuntimeMs=groups,nearestRuntimeMs=nearest.most_common(35),runtimeAncestryMs=inclusive.most_common(55),
        nearestAdmissionCallersMs=reservation_paths.most_common(22),leavesUnderRuntimeMs=native_leaf.most_common(22))
rows=[describe(label) for label in labels]
for row in rows:
    print(row['case'],row['verifiedInvocations'],'runs',round(row['totalRuntimeAncestryMs'],1),'ms')
    print({name:round(value,1) for name,value in row['exclusiveNearestRuntimeMs'].items()})
    print('nearest',[(name,round(value,1)) for name,value in row['nearestRuntimeMs'][:11]])
    print('admission callers',[(name,round(value,1)) for name,value in row['nearestAdmissionCallersMs'][:6]])
(lab/'attribution.json').write_text(json.dumps(dict(rows=rows,diagnostic=True),indent=2)+'\n',encoding='utf-8',newline='\n')
