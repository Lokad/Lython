; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:TryStartForwardedComputedDefinition(Lokad.Lython.Frontend.ExecutableCallSite,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 11 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 64
       lea      rbp, [rsp+0x70]
       xor      eax, eax
       mov      qword ptr [rbp-0x38], rax
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x28], r9
       mov      rsi, rcx
       mov      rbx, r8
       mov      rdi, bword ptr [rbp+0x30]
 
G_M000_IG02:                ;; offset=0x002F
       xor      ecx, ecx
       mov      qword ptr [rdi], rcx
       mov      qword ptr [rdi+0x08], rcx
       mov      rcx, gword ptr [rsi+0x40]
       mov      r14, gword ptr [rcx+0x58]
       test     r14, r14
       je       G_M000_IG08
 
G_M000_IG03:                ;; offset=0x0049
       mov      rcx, r14
       call     [Lokad.Lython.Frontend.ExecutableCreateFunction:get_InputCount():int:this]
       test     eax, eax
       jle      G_M000_IG08
       lea      r9, [rbp-0x38]
       mov      rcx, rsi
       mov      rdx, gword ptr [rbp+0x18]
       xor      r8, r8
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TrySelectNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,byref):bool:this]
       test     eax, eax
       je       G_M000_IG08
       cmp      byte  ptr [rbp-0x38], 0
       je       G_M000_IG08
       mov      rax, gword ptr [rbp+0x18]
       mov      rdx, gword ptr [rax+0x18]
       mov      r9, gword ptr [rbp+0x28]
       mov      rcx, gword ptr [r9+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG04:                ;; offset=0x009C
       mov      rax, gword ptr [rbp+0x18]
       mov      r15, gword ptr [rax+0x18]
       mov      r9, gword ptr [rbp+0x28]
       mov      r13, gword ptr [r9+0xA0]
       cmp      byte  ptr [r13], r13b
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG05
       mov      rcx, r13
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG05:                ;; offset=0x00CC
       mov      bword ptr [rsp+0x20], rdi
       mov      rax, gword ptr [rbp+0x18]
       mov      r9, gword ptr [rax+0x18]
       mov      rcx, rsi
       mov      rdx, r14
       mov      r8, rbx
       call     [Lokad.Lython.Runtime.PyExecutableFunction:TryReturnDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       mov      ebx, eax
 
G_M000_IG06:                ;; offset=0x00EA
       mov      r9, gword ptr [rbp+0x28]
       mov      rcx, gword ptr [r9+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
       mov      eax, ebx
 
G_M000_IG07:                ;; offset=0x00FF
       add      rsp, 64
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG08:                ;; offset=0x010E
       xor      eax, eax
 
G_M000_IG09:                ;; offset=0x0110
       add      rsp, 64
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG10:                ;; offset=0x011F
       sub      rsp, 40
 
G_M000_IG11:                ;; offset=0x0123
       mov      rdx, rcx
       mov      rcx, 0x7FF9D0F51770
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rbx, rax
       test     rbx, rbx
       jne      SHORT G_M000_IG12
       xor      eax, eax
       jmp      SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x0141
       mov      rcx, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       lea      r8, [rbp-0x40]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       setne    al
       movzx    rax, al
 
G_M000_IG13:                ;; offset=0x0163
       add      rsp, 40
       ret      
 
G_M000_IG14:                ;; offset=0x0168
       sub      rsp, 40
 
G_M000_IG15:                ;; offset=0x016C
       mov      rcx, gword ptr [rbp-0x40]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG16:                ;; offset=0x0176
       sub      rsp, 40
 
G_M000_IG17:                ;; offset=0x017A
       mov      r9, gword ptr [rbp+0x28]
       mov      rcx, gword ptr [r9+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveInterpreterFrame():this]
       nop      
 
G_M000_IG18:                ;; offset=0x018E
       add      rsp, 40
       ret      
 
; Total bytes of code 403

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:TryReturnDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan,byref):bool:this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 29 single block inlinees; 3 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 72
       lea      rbp, [rsp+0x70]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x40], xmm4
       xor      eax, eax
       mov      qword ptr [rbp-0x30], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x28], r9
       mov      rbx, rdx
       mov      rsi, bword ptr [rbp+0x30]
 
G_M000_IG02:                ;; offset=0x002F
       mov      rdi, gword ptr [r8]
       mov      r14, qword ptr [r8+0x08]
       xor      eax, eax
       mov      qword ptr [rsi], rax
       mov      qword ptr [rsi+0x08], rax
 
G_M000_IG03:                ;; offset=0x003F
       xor      r15, r15
       mov      rcx, rbx
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCreateFunction:get_InputCount():int:this]
       test     eax, eax
       je       G_M000_IG19
 
G_M000_IG04:                ;; offset=0x0055
       mov      rdx, 0x2080A801C40
       cmp      rdi, gword ptr [rdx]
       je       SHORT G_M000_IG10
       test     r14, r14
       jle      SHORT G_M000_IG05
       mov      rdx, rdi
       mov      rcx, 0x7FF9D1461478
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0080
       lea      rdx, [rbp-0x30]
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG07
 
G_M000_IG06:                ;; offset=0x008F
       lea      edx, [r14-0x01]
       lea      r8, [rbp-0x30]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.PyTuple:TryReadInteger(int,byref):bool:this]
 
G_M000_IG07:                ;; offset=0x00A0
       test     eax, eax
       jne      SHORT G_M000_IG11
 
G_M000_IG08:                ;; offset=0x00A4
       xor      eax, eax
 
G_M000_IG09:                ;; offset=0x00A6
       add      rsp, 72
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG10:                ;; offset=0x00B3
       mov      qword ptr [rbp-0x30], r14
 
G_M000_IG11:                ;; offset=0x00B7
       mov      rcx, gword ptr [rbp+0x10]
       mov      r11, gword ptr [rcx+0x40]
       mov      rcx, gword ptr [r11+0x80]
       mov      r11, 0x7FF9D0E51DA0
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       test     eax, eax
       je       SHORT G_M000_IG19
       mov      rcx, gword ptr [rbp+0x10]
       lea      rdx, bword ptr [rcx+0x58]
       mov      rax, gword ptr [rdx]
       test     rax, rax
       je       SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x00E7
       mov      r8, 0x7FF9D14F22B8
       cmp      qword ptr [rax], r8
       je       SHORT G_M000_IG16
 
G_M000_IG13:                ;; offset=0x00F6
       test     rax, rax
       je       SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x00FB
       mov      r8, 0x7FF9D151FF20
       xor      r10, r10
       cmp      qword ptr [rax], r8
       cmovne   rax, r10
 
G_M000_IG15:                ;; offset=0x010F
       test     rax, rax
       je       SHORT G_M000_IG17
 
G_M000_IG16:                ;; offset=0x0114
       xor      r15, r15
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x0119
       mov      r15, gword ptr [rdx]
 
G_M000_IG18:                ;; offset=0x011C
       test     r15, r15
       je       SHORT G_M000_IG08
 
G_M000_IG19:                ;; offset=0x0121
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x28]
       mov      rcx, gword ptr [rdx+0xA0]
       mov      rdx, gword ptr [rbp+0x28]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterFunctionCall(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x28]
       mov      rax, gword ptr [rax+0xA0]
       mov      rdx, gword ptr [rax+0x148]
       mov      gword ptr [rbp-0x48], rdx
 
G_M000_IG20:                ;; offset=0x0156
       mov      rcx, rbx
       call     [Lokad.Lython.Frontend.ExecutableCreateFunction:get_InputCount():int:this]
       test     eax, eax
       jne      SHORT G_M000_IG21
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x28]
       mov      gword ptr [rbp-0x40], rdi
       mov      qword ptr [rbp-0x38], r14
       mov      r8, gword ptr [rcx+0x40]
       mov      r8, gword ptr [r8+0x98]
       cmp      dword ptr [r8+0x08], 0
       jbe      G_M000_IG24
       mov      r9, gword ptr [r8+0x10]
       lea      r8, [rbp-0x40]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateClosedFunctionDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rdi, rax
       jmp      SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x019F
       mov      gword ptr [rsp+0x20], r15
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rcx+0x28]
       mov      rdx, gword ptr [rcx+0x40]
       mov      rcx, rbx
       mov      r9, qword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateClosedComputedDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,long,System.Object):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rdi, rax
 
G_M000_IG22:                ;; offset=0x01C0
       mov      rcx, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x28]
       mov      rdx, gword ptr [rcx+0x40]
       mov      rdx, gword ptr [rdx+0x98]
       mov      r8d, dword ptr [rdx+0x08]
       lea      r10d, [r8-0x01]
       cmp      r10d, r8d
       jae      SHORT G_M000_IG24
       mov      r8d, r10d
       shl      r8, 5
       mov      rbx, gword ptr [rdx+r8+0x10]
       mov      r14, gword ptr [rax+0xA0]
       cmp      byte  ptr [r14], r14b
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG23
       mov      rcx, r14
       mov      rdx, rbx
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG23:                ;; offset=0x020F
       mov      rcx, rsi
       mov      rdx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rsi+0x08], rcx
       jmp      SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x0222
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG25:                ;; offset=0x0228
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x28]
       mov      rsi, gword ptr [rdx+0xA0]
       mov      rbx, rsi
       lea      rcx, bword ptr [rbx+0x148]
       mov      rdx, gword ptr [rbp-0x48]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveFunctionCall():this]
       nop      
 
G_M000_IG26:                ;; offset=0x0254
       mov      eax, 1
 
G_M000_IG27:                ;; offset=0x0259
       add      rsp, 72
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG28:                ;; offset=0x0266
       sub      rsp, 40
 
G_M000_IG29:                ;; offset=0x026A
       mov      rbx, rcx
       cmp      gword ptr [rbp-0x48], 0
       je       SHORT G_M000_IG30
       mov      rcx, rbx
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntimeException:get_OriginalPythonException():Lokad.Lython.Runtime.PyException:this]
       cmp      rax, gword ptr [rbp-0x48]
       je       SHORT G_M000_IG30
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntimeException:get_PythonContext():Lokad.Lython.Runtime.PyException:this]
       test     rax, rax
       jne      SHORT G_M000_IG30
       mov      rcx, rbx
       mov      rdx, gword ptr [rbp-0x48]
       call     [Lokad.Lython.Runtime.LythonRuntimeException:set_PythonContext(Lokad.Lython.Runtime.PyException):this]
 
G_M000_IG30:                ;; offset=0x02A0
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG31:                ;; offset=0x02A6
       sub      rsp, 40
 
G_M000_IG32:                ;; offset=0x02AA
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x28]
       mov      rbx, gword ptr [rdx+0xA0]
       lea      rcx, bword ptr [rbx+0x148]
       mov      rdx, gword ptr [rbp-0x48]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, gword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x28]
       mov      rcx, gword ptr [rax+0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:LeaveFunctionCall():this]
       nop      
 
G_M000_IG33:                ;; offset=0x02E1
       add      rsp, 40
       ret      
 
G_M000_IG34:                ;; offset=0x02E6
       sub      rsp, 40
 
G_M000_IG35:                ;; offset=0x02EA
       mov      rbx, rcx
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Closure():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rsi, rax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Name():System.String:this]
       mov      r8, rax
       mov      rdx, rsi
       mov      rcx, rbx
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.PyFunctionBinding:AnnotateException(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.String,Lokad.Lython.LythonSourceSpan)]
       call     CORINFO_HELP_RETHROW
       int3     
 
; Total bytes of code 797

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref):this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; partially interruptible
; No PGO data
; 1 inlinees with PGO data; 11 single block inlinees; 5 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 440
       lea      rbp, [rsp+0x1E0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x190], xmm4
       mov      rax, -336
 
G_M000_IG16:                ;; offset=0x002D
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x10], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG16
       mov      qword ptr [rbp-0x30], rax
       mov      rbx, rcx
       mov      rdi, gword ptr [rbp+0x38]
       mov      rsi, bword ptr [rbp+0x50]
 
G_M000_IG02:                ;; offset=0x0054
       mov      rax, bword ptr [r8]
       mov      r14d, dword ptr [r8+0x08]
       mov      rcx, gword ptr [rbx+0x40]
       mov      r15d, dword ptr [rcx+0xE8]
       cmp      r15d, 16
       ja       G_M000_IG11
       cmp      byte  ptr [rbp+0x48], 0
       jne      G_M000_IG07
 
G_M000_IG03:                ;; offset=0x007A
       mov      rcx, gword ptr [rbx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x08]
       cmp      ecx, r15d
       ja       G_M000_IG11
       lea      r8, bword ptr [rbp-0x128]
       mov      bword ptr [rbp-0x170], r8
       mov      dword ptr [rbp-0x168], ecx
       xor      rcx, rcx
       mov      bword ptr [rbp-0x180], rcx
 
G_M000_IG04:                ;; offset=0x00AB
       mov      dword ptr [rbp-0x178], ecx
       mov      rcx, gword ptr [rbp+0x30]
       mov      gword ptr [rsp+0x20], rcx
       xor      ecx, ecx
       mov      dword ptr [rsp+0x28], ecx
       mov      gword ptr [rsp+0x30], r9
       mov      gword ptr [rsp+0x38], rdx
       mov      bword ptr [rbp-0x190], rax
       mov      dword ptr [rbp-0x188], r14d
       lea      rcx, [rbp-0x170]
       lea      rdx, [rbp-0x180]
       lea      r9, [rbp-0x190]
       mov      qword ptr [rsp+0x40], r9
       mov      r9, rbx
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int]
 
G_M000_IG05:                ;; offset=0x00FE
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x160], ymm0
       lea      rdx, bword ptr [rbp-0x128]
       mov      bword ptr [rbp-0x170], rdx
       mov      dword ptr [rbp-0x168], r15d
       movzx    rdx, byte  ptr [rbp+0x40]
       mov      dword ptr [rsp+0x20], edx
       mov      bword ptr [rsp+0x28], rsi
       mov      rsi, bword ptr [rbp+0x58]
       mov      bword ptr [rsp+0x30], rsi
       mov      rsi, bword ptr [rbp+0x60]
       mov      bword ptr [rsp+0x38], rsi
       mov      rsi, bword ptr [rbp+0x68]
       mov      bword ptr [rsp+0x40], rsi
       lea      rdx, [rbp-0x140]
       mov      qword ptr [rsp+0x48], rdx
       lea      rdx, [rbp-0x170]
       lea      r8, [rbp-0x160]
       mov      rcx, rbx
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this]
       nop      
 
G_M000_IG06:                ;; offset=0x016E
       add      rsp, 440
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x017E
       xor      ecx, ecx
       test     r9, r9
       je       SHORT G_M000_IG08
       mov      ecx, 1
       test     r15d, r15d
       je       G_M000_IG15
       mov      gword ptr [rbp-0x128], r9
       xor      edx, edx
       mov      qword ptr [rbp-0x120], rdx
 
G_M000_IG08:                ;; offset=0x01A3
       cmp      ecx, r15d
       ja       SHORT G_M000_IG11
       lea      rdx, bword ptr [rbp-0x128]
       mov      r8d, ecx
       shl      r8, 4
       add      r8, rdx
       mov      edx, r15d
       sub      edx, ecx
       cmp      r14d, edx
       ja       SHORT G_M000_IG14
 
G_M000_IG09:                ;; offset=0x01C3
       mov      ecx, r14d
       shl      rcx, 4
       mov      r10, rcx
       cmp      r10, 0x4000
       ja       SHORT G_M000_IG13
 
G_M000_IG10:                ;; offset=0x01D6
       mov      rcx, r8
       mov      rdx, rax
       mov      r8, r10
       call     System.Buffer:BulkMoveWithWriteBarrierInternal(byref,byref,nuint)
       cmp      dword ptr [(reloc 0x7ffa30e42aa8)], 0
       je       G_M000_IG05
       jmp      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x01F3
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG12:                ;; offset=0x01FA
       call     CORINFO_HELP_POLL_GC
       jmp      G_M000_IG05
 
G_M000_IG13:                ;; offset=0x0204
       mov      rcx, r8
       mov      rdx, rax
       mov      r8, r10
       call     [System.Buffer:BulkMoveWithWriteBarrierBatch(byref,byref,nuint)]
       jmp      G_M000_IG05
 
G_M000_IG14:                ;; offset=0x0218
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG15:                ;; offset=0x021F
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 549

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],System.Nullable`1[Lokad.Lython.Runtime.BoundFunctionArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,byref,byref,byref):this (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 4 inlinees with PGO data; 29 single block inlinees; 7 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 216
       lea      rbp, [rsp+0x110]
       xor      eax, eax
       mov      qword ptr [rbp-0xC8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xC0], ymm4
       vmovdqu  ymmword ptr [rbp-0xA0], ymm4
       vmovdqu  ymmword ptr [rbp-0x80], ymm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x28], r9
       mov      rbx, rdx
       mov      rsi, r8
       mov      r14, bword ptr [rbp+0x38]
       mov      r12, bword ptr [rbp+0x40]
       mov      r15, bword ptr [rbp+0x48]
       mov      r13, bword ptr [rbp+0x50]
       mov      rdi, bword ptr [rbp+0x58]
 
G_M000_IG02:                ;; offset=0x0068
       mov      byte  ptr [r12], 0
       mov      rdx, 0x2080A801268
       mov      rdx, gword ptr [rdx]
       mov      rcx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       xor      r8d, r8d
       mov      qword ptr [r15+0x08], r8
 
G_M000_IG03:                ;; offset=0x0089
       mov      gword ptr [r13], r8
 
G_M000_IG04:                ;; offset=0x008D
       mov      qword ptr [rdi], r8
       mov      qword ptr [rdi+0x08], r8
       mov      qword ptr [rdi+0x10], r8
 
G_M000_IG05:                ;; offset=0x0098
       vmovdqu  xmm0, xmmword ptr [rbx]
       vmovdqu  xmmword ptr [rbp-0xC8], xmm0
 
G_M000_IG06:                ;; offset=0x00A4
       mov      r8d, dword ptr [r14+0x08]
       mov      dword ptr [rsp+0x20], r8d
       lea      r8, [rbp-0xC8]
       movzx    rax, byte  ptr [rbp+0x30]
       mov      dword ptr [rbp-0xCC], eax
       mov      r9d, eax
       lea      rcx, [rbp-0x98]
       mov      rdx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:.ctor(Lokad.Lython.Runtime.PyExecutableFunction,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,int):this]
 
G_M000_IG07:                ;; offset=0x00D2
       vmovdqu  xmm0, xmmword ptr [rsi+0x08]
       vmovdqu  xmmword ptr [rbp-0xB0], xmm0
       mov      rcx, qword ptr [rsi+0x18]
       mov      qword ptr [rbp-0xA0], rcx
 
G_M000_IG08:                ;; offset=0x00EA
       xor      ecx, ecx
       mov      dword ptr [rbp-0xB4], ecx
 
G_M000_IG09:                ;; offset=0x00F2
       lea      rcx, [rbp-0x98]
       mov      rdx, gword ptr [rbp+0x28]
       mov      r8, r15
       mov      r9, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Run(Lokad.Lython.LythonSourceSpan,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):bool:this]
       test     eax, eax
       jne      G_M000_IG19
       mov      rcx, bword ptr [rbp-0x50]
       mov      edx, dword ptr [rbp-0x48]
       mov      eax, dword ptr [rbp-0x5C]
       cmp      eax, edx
       ja       G_M000_IG20
       mov      r8d, eax
       shl      r8, 4
       add      rcx, r8
       sub      edx, eax
       add      rdx, rdx
       call     [System.SpanHelpers:ClearWithReferences(byref,nuint)]
       cmp      byte  ptr [rsi], 0
       jne      G_M000_IG18
 
G_M000_IG10:                ;; offset=0x0141
       mov      rdx, gword ptr [rbp+0x10]
       mov      r12, gword ptr [rdx+0x28]
       mov      rcx, gword ptr [rdx+0x40]
       mov      r8d, dword ptr [rcx+0xE8]
       mov      rcx, gword ptr [r12+0xA0]
       mov      rsi, gword ptr [rcx+0x88]
       mov      rcx, gword ptr [rdx+0x08]
       mov      rcx, gword ptr [rcx+0x08]
       mov      r14d, dword ptr [rcx+0x08]
       cmp      r8d, r14d
       jge      SHORT G_M000_IG12
 
G_M000_IG11:                ;; offset=0x0174
       mov      ecx, r8d
       mov      edx, r14d
       mov      r8, 0x228311F6878
       call     [System.ArgumentOutOfRangeException:ThrowLess[int](int,int,System.String)]
       int3     
 
G_M000_IG12:                ;; offset=0x018B
       cmp      byte  ptr [rsi], sil
       mov      gword ptr [rsp+0x20], r12
       lea      rcx, bword ptr [rsi+0x50]
       mov      rdx, rsi
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.MemoryGovernor+WorkspaceCache:Rent(Lokad.Lython.Runtime.MemoryGovernor,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0xB0], rax
       mov      gword ptr [rbp-0xA8], rsi
       mov      dword ptr [rbp-0xA0], r14d
       mov      dword ptr [rbp-0xB4], 1
       mov      esi, dword ptr [rbp-0x5C]
       cmp      esi, dword ptr [rbx+0x08]
       ja       G_M000_IG20
 
G_M000_IG13:                ;; offset=0x01CF
       mov      rdx, bword ptr [rbx]
       mov      rax, gword ptr [rbp-0xB0]
       test     rax, rax
       je       SHORT G_M000_IG14
       lea      rcx, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
       jmp      SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x01E7
       xor      rcx, rcx
       xor      eax, eax
 
G_M000_IG15:                ;; offset=0x01EB
       cmp      esi, eax
       ja       G_M000_IG23
 
G_M000_IG16:                ;; offset=0x01F3
       mov      r8d, esi
       shl      r8, 4
       cmp      r8, 0x4000
       ja       G_M000_IG22
 
G_M000_IG17:                ;; offset=0x0207
       call     System.Buffer:BulkMoveWithWriteBarrierInternal(byref,byref,nuint)
       cmp      dword ptr [(reloc 0x7ffa30e42aa8)], 0
       jne      G_M000_IG21
 
G_M000_IG18:                ;; offset=0x0219
       mov      edx, dword ptr [rbp-0x5C]
       mov      dword ptr [rsp+0x20], edx
       mov      ebx, dword ptr [rbp-0xCC]
       mov      dword ptr [rsp+0x28], ebx
       mov      rdx, gword ptr [rbp-0x70]
       mov      gword ptr [rsp+0x30], rdx
       lea      rdx, [rbp-0xB0]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x28]
       mov      r9d, dword ptr [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateNativeContinuation(Lokad.Lython.Runtime.PyExecutableFunction,byref,Lokad.Lython.LythonSourceSpan,int,int,bool,Lokad.Lython.Runtime.LythonRuntimeException):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      rdx, rax
       mov      rcx, r13
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, gword ptr [r13]
       lea      rcx, [rbp-0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:TransferOwnership(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):this]
       mov      rdx, gword ptr [rbp-0xB0]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       lea      rcx, bword ptr [rdi+0x08]
       mov      rdx, gword ptr [rbp-0xA8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      eax, dword ptr [rbp-0xA0]
       mov      dword ptr [rdi+0x10], eax
       jmp      SHORT G_M000_IG24
 
G_M000_IG19:                ;; offset=0x0292
       cmp      dword ptr [rbp-0x64], 0
       setge    cl
       mov      byte  ptr [r12], cl
       jmp      SHORT G_M000_IG24
 
G_M000_IG20:                ;; offset=0x029F
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG21:                ;; offset=0x02A6
       call     CORINFO_HELP_POLL_GC
       jmp      G_M000_IG18
 
G_M000_IG22:                ;; offset=0x02B0
       call     [System.Buffer:BulkMoveWithWriteBarrierBatch(byref,byref,nuint)]
       jmp      G_M000_IG18
 
G_M000_IG23:                ;; offset=0x02BB
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG24:                ;; offset=0x02C2
       call     G_M000_IG33
       nop      
 
G_M000_IG25:                ;; offset=0x02C8
       add      rsp, 216
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG26:                ;; offset=0x02DC
       sub      rsp, 56
 
G_M000_IG27:                ;; offset=0x02E0
       mov      rbx, rcx
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Closure():Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:this]
       mov      rsi, rax
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_Name():System.String:this]
       mov      r8, rax
       mov      rdx, rsi
       mov      rcx, rbx
       mov      r9, gword ptr [rbp+0x28]
       call     [Lokad.Lython.Runtime.PyFunctionBinding:AnnotateException(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.String,Lokad.Lython.LythonSourceSpan)]
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG28:                ;; offset=0x0313
       sub      rsp, 56
 
G_M000_IG29:                ;; offset=0x0317
       cmp      dword ptr [rbp-0xB4], 0
       je       SHORT G_M000_IG31
       cmp      byte  ptr [rbp-0x56], 0
       jne      SHORT G_M000_IG31
       mov      r8, gword ptr [rbp-0xB0]
       mov      rdx, gword ptr [rbp-0xA8]
       mov      rcx, gword ptr [rbp+0x10]
       mov      rcx, gword ptr [rcx+0x40]
       mov      r9d, dword ptr [rcx+0xE8]
       test     rdx, rdx
       je       SHORT G_M000_IG30
       lea      rcx, bword ptr [rdx+0x50]
       call     [Lokad.Lython.Runtime.MemoryGovernor+WorkspaceCache:Return(Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int):this]
       jmp      SHORT G_M000_IG31
 
G_M000_IG30:                ;; offset=0x0354
       mov      rcx, r8
       call     [System.Array:Clear(System.Array)]
 
G_M000_IG31:                ;; offset=0x035D
       nop      
 
G_M000_IG32:                ;; offset=0x035E
       add      rsp, 56
       ret      
 
G_M000_IG33:                ;; offset=0x0363
       sub      rsp, 56
 
G_M000_IG34:                ;; offset=0x0367
       lea      rcx, [rbp-0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Dispose():this]
       nop      
 
G_M000_IG35:                ;; offset=0x0375
       call     G_M000_IG28
       nop      
 
G_M000_IG36:                ;; offset=0x037B
       add      rsp, 56
       ret      
 
; Total bytes of code 896

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:TryPrepareFixedTupleReturn(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 17 single block inlinees; 8 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 184
       lea      rbp, [rsp+0xF0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       mov      rbx, rcx
       mov      rsi, r8
       mov      r14d, r9d
       mov      r15d, dword ptr [rbp+0x30]
       mov      rdi, gword ptr [rbp+0x38]
 
G_M000_IG02:                ;; offset=0x003A
       mov      r13, bword ptr [rdx]
       mov      r12d, dword ptr [rdx+0x08]
       mov      rcx, gword ptr [rbx+0x98]
       mov      rax, rcx
       mov      edx, dword ptr [rsi]
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG41
       shl      rdx, 5
       mov      eax, dword ptr [rax+rdx+0x1C]
       mov      dword ptr [rbp-0x3C], eax
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG41
       mov      edx, eax
       shl      rdx, 5
       lea      rdx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x80], rdx
       mov      rcx, rdx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       cmp      eax, r15d
       jne      G_M000_IG38
 
G_M000_IG03:                ;; offset=0x008B
       mov      rax, bword ptr [rbp-0x80]
       cmp      r14d, dword ptr [rax+0x10]
       jne      G_M000_IG38
       mov      ecx, r14d
       mov      edx, r15d
       add      rcx, rdx
       mov      edx, r12d
       cmp      rcx, rdx
       ja       G_M000_IG40
       mov      ecx, r14d
       shl      rcx, 4
       add      rcx, r13
       mov      bword ptr [rbp-0xA8], rcx
       mov      dword ptr [rbp-0x58], r15d
       xor      edx, edx
       mov      dword ptr [rbp-0x40], edx
 
G_M000_IG04:                ;; offset=0x00C8
       xor      r14d, r14d
 
G_M000_IG05:                ;; offset=0x00CB
       xor      edx, edx
       test     r15d, r15d
       je       G_M000_IG31
 
G_M000_IG06:                ;; offset=0x00D6
       mov      r8, gword ptr [rbx+0x98]
       mov      qword ptr [rbp-0x78], rdx
       mov      r10d, edx
       add      r10d, dword ptr [rsi]
       cmp      r10d, dword ptr [r8+0x08]
       jae      G_M000_IG33
       shl      r10, 5
       lea      r8, bword ptr [r8+r10+0x10]
       mov      bword ptr [rbp-0x88], r8
       mov      r10, gword ptr [r8]
       mov      gword ptr [rbp-0x90], r10
       mov      r9, gword ptr [rdi+0xA0]
       mov      gword ptr [rbp-0x98], r9
       cmp      byte  ptr [r9], r9b
       mov      rcx, r9
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x0129
       mov      rcx, gword ptr [rbp-0x98]
       mov      rdx, gword ptr [rbp-0x90]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG08:                ;; offset=0x013D
       mov      rax, bword ptr [rbp-0x88]
       cmp      dword ptr [rax+0x1C], 46
       je       G_M000_IG25
 
G_M000_IG09:                ;; offset=0x014E
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, r12d
       jae      G_M000_IG33
       mov      edx, eax
       shl      rdx, 4
       add      rdx, r13
       mov      rax, gword ptr [rdx]
       mov      r8, qword ptr [rdx+0x08]
       mov      qword ptr [rbp-0x60], r8
       test     r8, r8
       jne      SHORT G_M000_IG16
       test     rax, rax
       je       SHORT G_M000_IG16
       mov      rdx, 0x7FF9D14F2F18
       cmp      qword ptr [rax], rdx
       je       SHORT G_M000_IG16
       mov      gword ptr [rbp-0xB0], rax
       mov      rdx, rax
       mov      rcx, 0x7FF9D14D7FC0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x01AB
       mov      rax, gword ptr [rbp-0xB0]
       jmp      SHORT G_M000_IG16
 
G_M000_IG11:                ;; offset=0x01B4
       mov      rdx, 0x2080A801C40
       mov      rax, gword ptr [rdx]
       mov      r8, gword ptr [rbp-0xB0]
       cmp      r8, rax
       jne      SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x01CD
       mov      rax, r8
       jmp      SHORT G_M000_IG16
 
G_M000_IG13:                ;; offset=0x01D2
       mov      rdx, 0x2080A801C48
       cmp      r8, gword ptr [rdx]
       mov      gword ptr [rbp-0xC0], rax
       je       SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x01E8
       mov      rdx, r8
       jmp      G_M000_IG26
 
G_M000_IG15:                ;; offset=0x01F0
       mov      rax, r8
 
G_M000_IG16:                ;; offset=0x01F3
       mov      rdx, 0x2080A801C40
       mov      rdx, gword ptr [rdx]
       mov      r10, rdx
       mov      gword ptr [rbp-0xC0], r10
       cmp      rax, r10
       je       G_M000_IG24
       cmp      qword ptr [rbp-0x60], 0
       jle      SHORT G_M000_IG18
       mov      gword ptr [rbp-0xB0], rax
       mov      rdx, rax
       mov      rcx, 0x7FF9D1461478
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG19
 
G_M000_IG17:                ;; offset=0x0238
       mov      rax, gword ptr [rbp-0xB0]
 
G_M000_IG18:                ;; offset=0x023F
       lea      rdx, [rbp-0x50]
       mov      gword ptr [rbp-0xB0], rax
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       jmp      SHORT G_M000_IG22
 
G_M000_IG19:                ;; offset=0x0255
       mov      r9, rax
       mov      r8, qword ptr [rbp-0x60]
       lea      r11d, [r8-0x01]
       mov      dword ptr [rbp-0x54], r11d
       mov      gword ptr [rbp-0xA0], r9
       mov      rdx, gword ptr [r9+0x08]
       mov      rcx, 0x7FF9D0F12560
       call     CORINFO_HELP_ISINSTANCEOFARRAY
       test     rax, rax
       je       SHORT G_M000_IG21
       xor      ecx, ecx
       mov      qword ptr [rbp-0x50], rcx
 
G_M000_IG20:                ;; offset=0x0289
       xor      eax, eax
       jmp      SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x028D
       mov      rcx, gword ptr [rbp-0xA0]
       mov      edx, dword ptr [rbp-0x54]
       call     [Lokad.Lython.Runtime.PyTuple:WritableValueSlot(int):byref:this]
       mov      rcx, rax
       lea      rdx, [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
 
G_M000_IG22:                ;; offset=0x02AA
       test     eax, eax
       mov      rdx, gword ptr [rbp-0xB0]
       jne      SHORT G_M000_IG26
 
G_M000_IG23:                ;; offset=0x02B5
       xor      ebx, ebx
       jmp      G_M000_IG35
 
G_M000_IG24:                ;; offset=0x02BC
       mov      r8, qword ptr [rbp-0x60]
       mov      qword ptr [rbp-0x50], r8
       mov      qword ptr [rbp-0x60], r8
       mov      rdx, rax
       jmp      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x02CD
       mov      bword ptr [rbp-0x70], r13
       mov      dword ptr [rbp-0x68], r12d
       lea      rdx, [rbp-0x48]
       mov      qword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0x70]
       mov      rcx, rbx
       mov      r8, rax
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryEvaluatePreparedBinary(Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG23
       mov      r8, qword ptr [rbp-0x48]
       mov      rcx, 0x2080A801C40
       mov      r10, gword ptr [rcx]
       mov      rax, r10
       mov      gword ptr [rbp-0xC0], rax
       mov      rcx, rax
       mov      rdx, rcx
       mov      qword ptr [rbp-0x60], r8
 
G_M000_IG26:                ;; offset=0x031A
       mov      r10, qword ptr [rbp-0x78]
       mov      r9, r10
       shl      r9, 4
       add      r9, bword ptr [rbp-0xA8]
       mov      rcx, r9
       mov      bword ptr [rbp-0xB8], rcx
       mov      gword ptr [rbp-0xB0], rdx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, bword ptr [rbp-0xB8]
       mov      rcx, qword ptr [rbp-0x60]
       mov      qword ptr [rdx+0x08], rcx
       mov      rax, gword ptr [rbp-0xB0]
       mov      rdx, gword ptr [rbp-0xC0]
       cmp      rax, rdx
       je       SHORT G_M000_IG28
 
G_M000_IG27:                ;; offset=0x0364
       mov      rdx, 0x2080A801C48
       cmp      rax, gword ptr [rdx]
       je       SHORT G_M000_IG28
       test     rcx, rcx
       jle      SHORT G_M000_IG29
       mov      gword ptr [rbp-0xB0], rax
       mov      rdx, rax
       mov      rcx, 0x7FF9D1461478
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       mov      rax, gword ptr [rbp-0xB0]
       je       SHORT G_M000_IG29
 
G_M000_IG28:                ;; offset=0x039D
       mov      eax, 64
       jmp      SHORT G_M000_IG30
 
G_M000_IG29:                ;; offset=0x03A4
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.RuntimeMemoryEstimates:EstimateScalarStorageBytes(System.Object):long]
 
G_M000_IG30:                ;; offset=0x03AD
       add      r14, rax
       jo       SHORT G_M000_IG34
       mov      rcx, qword ptr [rbp-0x78]
       inc      ecx
       cmp      ecx, r15d
       mov      rdx, rcx
       jl       G_M000_IG06
 
G_M000_IG31:                ;; offset=0x03C4
       mov      ebx, dword ptr [rbp-0x3C]
       mov      dword ptr [rsi], ebx
       mov      rbx, gword ptr [rdi+0xA0]
       mov      rsi, bword ptr [rbp-0x80]
       mov      r13, gword ptr [rsi]
       cmp      byte  ptr [rbx], bl
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG32
       mov      rcx, rbx
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG32:                ;; offset=0x03F2
       mov      r8, gword ptr [rsi]
       mov      rcx, r14
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:AdmitUnpackedReturnScalars(long,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      dword ptr [rbp-0x40], 1
       mov      ebx, 1
       jmp      SHORT G_M000_IG35
 
G_M000_IG33:                ;; offset=0x040F
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG34:                ;; offset=0x0415
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG35:                ;; offset=0x041B
       cmp      dword ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG36
       mov      edx, r15d
       add      rdx, rdx
       mov      rcx, bword ptr [rbp-0xA8]
       call     [System.SpanHelpers:ClearWithReferences(byref,nuint)]
 
G_M000_IG36:                ;; offset=0x0434
       mov      eax, ebx
 
G_M000_IG37:                ;; offset=0x0436
       add      rsp, 184
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG38:                ;; offset=0x044A
       xor      eax, eax
 
G_M000_IG39:                ;; offset=0x044C
       add      rsp, 184
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG40:                ;; offset=0x0460
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG41:                ;; offset=0x0467
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG42:                ;; offset=0x046D
       sub      rsp, 40
 
G_M000_IG43:                ;; offset=0x0471
       cmp      dword ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG44
       mov      edx, dword ptr [rbp-0x58]
       add      rdx, rdx
       mov      rcx, bword ptr [rbp-0xA8]
       call     [System.SpanHelpers:ClearWithReferences(byref,nuint)]
 
G_M000_IG44:                ;; offset=0x048A
       nop      
 
G_M000_IG45:                ;; offset=0x048B
       add      rsp, 40
       ret      
 
; Total bytes of code 1168

