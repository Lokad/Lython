import hashlib
import json
import re
from pathlib import Path

lab=Path(__file__).resolve().parent
root=lab.parents[3]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
proof=read(lab/'factory-tapes.json')
meta=read(lab.parent/'annotated-factories-cpython-20261124/external/identity.json')
assert proof['coreSHA256']==meta['coreSHA256']['candidate']
code=(root/'src/Lokad.Lython/Frontend/ExecutableScript.cs').read_text(encoding='utf-8')
raw=re.search(r'enum ExecutableOpCode\s*\{(.*?)\}',code,re.S).group(1)
opcodes=[word.strip() for word in re.sub(r'//[^\n]*','',raw).split(',') if word.strip()]
rows=[]
for case in proof['rows']:
    bodies=[]
    for compiled in case['codes']:
        if compiled['name']=='<module>':continue
        tape=[opcodes[instruction['<OpCode>k__BackingField']] for instruction in compiled['tape']]
        bodies.append({name:compiled[name] for name in ('name','capacity','native','closures','captured','locals','regions')} | {'opcodes':tape})
    rows.append({'case':case['id'],'bodies':bodies})
inspect=lab/'inspect'
image={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(inspect.iterdir())}
assert image['Lokad.Lython.dll']==proof['coreSHA256']
(lab/'factory-shapes.json').write_text(json.dumps(dict(inspectorImage=image,rows=rows),indent=2)+'\n',encoding='utf-8',newline='\n')
