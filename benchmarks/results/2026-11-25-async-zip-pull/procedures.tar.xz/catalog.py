from pathlib import Path
import hashlib
import json

lab = Path(__file__).resolve().parent
prior = lab.with_name("async-map-prefix-20261125")
read = lambda path: json.loads(path.read_text(encoding="utf-8"))
catalog = read(prior / "input-catalog.json")
names = {
    "scripts.rule-default-closures",
    "scripts.csv-invoice.method-policy.quoted-control",
    "diagnostic.shipment-routing-callbacks",
    "diagnostic.shipment-file-fed-map",
}
catalog["cases"] = [entry for entry in catalog["cases"] if entry["id"] in names]
assert len(catalog["cases"]) == 4
retained = read(lab.with_name("zip-unpack-20261125") / "comparison/quiet/representative.json")
catalog["cases"].append(next(entry for entry in retained["cases"] if entry["id"] == "diagnostic.shipment-retained-zip"))
shipment = next(entry for entry in catalog["cases"] if entry["id"] == "diagnostic.shipment-routing-callbacks")
assert shipment["source"].count("zip(rows, results)") == 1
strict = shipment["source"].replace("zip(rows, results)", "zip(rows, results, strict=True)")
payload = strict.encode("utf-8")
catalog["cases"].append(shipment | dict(id="diagnostic.shipment-strict-zip", source=strict,
    sourceUtf8Bytes=len(payload), sourceSha256=hashlib.sha256(payload).hexdigest()))
(lab / "input-catalog.json").write_text(json.dumps(catalog, ensure_ascii=False, indent=2) + "\n",
                                        encoding="utf-8", newline="\n")
