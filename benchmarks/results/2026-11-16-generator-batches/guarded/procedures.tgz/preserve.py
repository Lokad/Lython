from pathlib import Path
import json,shutil,tarfile,hashlib,xml.etree.ElementTree as E
repo=Path('D:/code/Lython');notes=repo/'.git/agent-notes/review-20261031';r=notes/'generator-batches-r458/guarded';out=repo/'benchmarks/results/2026-11-16-generator-batches/guarded';out.mkdir()
for n in ['summary.json','allocation-summary.json','prototype.patch','candidate-sources.tar.xz','new-test-cpython.json','design.md']:shutil.copy2(r/n,out/n)
shutil.copy2(r/'frozen/identity.json',out/'identity.json');shutil.copy2(r/'quiet/observations.tgz',out/'observations.tgz');shutil.copy2(notes/'regex-source-r459/assessment.json',out/'provider-source-assessment.json');shutil.copy2(notes/'sequence-construction-r460/assessment.json',out/'sequence-construction-assessment.json')
checks=[];ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
for p in r.glob('*.trx'):
 v=E.parse(p).find('t:ResultSummary/t:Counters',ns).attrib;assert v['failed']=='0';checks.append(dict(file=p.name,**v))
(out/'validation.json').write_text(json.dumps(dict(checks=checks,overlappingFiltersNotSummed=True,completeGoldenScripts=7,independentCPythonPrograms=5,fullQualification=False,retained=False,decision='Keep private pending coherent sequence-construction integration and explicit representative CPU-debt decision. No further unchanged retiming.',publicationHeld=True),indent=2)+'\n',encoding='utf-8')
with tarfile.open(out/'focused-checks.tgz','w:gz')as t:
 for p in r.iterdir():
  if p.is_file()and p.suffix in ['.trx','.log']:t.add(p,arcname=p.name)
 for p in(r/'allocation-short').glob('*.json'):t.add(p,arcname='allocation-short/'+p.name)
with tarfile.open(out/'procedures.tgz','w:gz')as t:
 for folder in [r,r/'quiet']:
  for p in folder.iterdir():
   if p.is_file()and(p.suffix in ['.py','.sh']or p.name in ['config.json','launch.log','observe-not-before.json','terminal-status.json','archive-receipt.json','retirement-proof.json']or p.name.startswith('observation-')):t.add(p,arcname=p.relative_to(r).as_posix())
core=r/'frozen/candidate/Lokad.Lython.dll';assert hashlib.sha256(core.read_bytes()).hexdigest()=='8dd7eda16934522a28bfafb6b10f2e6726cd0c761b71820e8cc7ed472dd5df61'
with tarfile.open(out/'measured-core.tar.xz','w:xz')as t:t.add(core,arcname='generator-batches-8dd7eda1.dll')
(out/'README.md').write_text('''# Guarded bulk-yield engine: private pending constructor consolidation

R458/B865,2026-11-16UTC. Qualified9e8d1cf5/e92d9598 versus private82e45812 plus
archived8dd7eda1. The inactive bulk helper is checked at its three callers; ordinary
Advance/AdvanceAsync remain original. **No production promotion or full qualification.**

| Complete workload | Phase | Elapsed change | Wider CPU change |
| --- | --- | ---: | ---: |
| Normalization,4,096lines/52,224B | Warm | −17.31..−11.69% | −15.76..−10.62% |
| Same normalization | Compile and run once | −15.39..−8.20% | −14.86..−7.04% |
| Ordinary generator/list/render control,16,384values | Warm | +3.51..+13.16% | +3.66..+13.56% |
| Numeric report,4,096records | Warm | −4.21..+14.21% | −3.56..+13.50% |
| CSV invoice control,4,096rows | Warm | −0.60..+0.67% | −0.58..0% |

All four pairings of two process medians/source retained. Negative means faster.
Normalization is consistently favorable across the archived shapes, but ordinary
generator consumption remains adverse here. Its candidate spread6.70%limits
magnitude. Numeric reference spread15.22%is inconclusive, not proof of failure or
absence of regression. Normalization reference/candidate spreads1.54/5.17%warm,
3.78/4.55%fresh. Allocation differs by only32B per affected invocation (<0.006%);
accounted peaks/compiled allowance unchanged. This is neither an allocation gain
nor a universal CPU improvement. All adverse originals remain [linked](../README.md).

Decision: do not ship the partial drain-only integration yet. Next bounded
construction milestone assesses existing PyList private capacity/rollback as one
sequence builder, removes the async tuple staging list/separate per-item growth
route, and shares native buffering with constructor consumers. It must retain
Python identities/order, mutation, real suspension, first terminal refusal and
funded aliases. Conservative capacity/scalar headroom can deny earlier and must
be documented/tested on useful budgets. No ledger, arena, controller, wider value
representation or replacement execution backend. A changed-source whole-script
comparison must decide remaining CPU debt before retention; no unchanged retiming.

Quiet AzureF4as_v7 Ubuntu24.04.4,.NET11RC3 normal tiering/workstation GC,two
processes/source,6s full-request warmup,five rotated~0.5s samples/process. Five
jobs192.911s; maximum within-process IQR2.24%. Warm includes Run, mediated RAM I/O,
all stdout/file goldens and prior-result cleanup; excludes compile/startup/reset/
protocol/final-cache teardown. Fresh adds compilation and compiled-owner disposal;
CPU clocks are wider. No new CPython timing/RSS/embedding-tail claim. All identity/
quiet/Closed/exit/join/archive gates pass; evidence SHA-verified persistently under
lease before RAM teardown. No users remain; terminal cached permanently. Only
exact committed older prototype-core replicas retired with fresh ownership/path/
hash/all-inode-alias proof; current images/toolchains/canonical evidence preserved.

Focused actual Windows.NET11/10 each167public/59internal pass, including seven
semantic/refusal rows per target. Seven frozen-worker/CPython goldens and five
independent semantic programs agree. Refused admission inside a generator cannot
be suppressed and sequential executions restore the shared allowance baseline.
An initial local verification path referred to the wrong copied helper directory;
that setup failure and correction are preserved, with no runtime assertion relaxed.
Full platform/stress/installed-package qualification waits for a retained design.

Independent regex source refresh records00e7905d removing UTF16 result coordinates;
both local dev105 package hashes remain unchanged. Cursor creation-token retention
still justifies the existing bridge. No producer source build, package promotion,
new qualification or safety certification; core remains decoupled, normal adapter0.4.
Missing published producer capabilities defer only affected final qualification.

[Results](summary.json),[allocation](allocation-summary.json),[validation](validation.json),
[frozen inputs/images](identity.json),[source](candidate-sources.tar.xz),
[exact core](measured-core.tar.xz),[raw evidence](observations.tgz),
[focused checks](focused-checks.tgz),[procedures/custody](procedures.tgz),
[next source gate](sequence-construction-assessment.json),
[provider source/package distinction](provider-source-assessment.json).
Publication and tagging remain held; the whole-script objective stays active.
''',encoding='utf-8')
p=repo/'benchmarks/EXPERIMENTS.md';s=p.read_text(encoding='utf-8');s+='\n[R458 guarded engine/B865](results/2026-11-16-generator-batches/guarded/README.md):\n8dd7eda1 normalization warm11.7–17.3%lower elapsed/fresh8.2–15.4%lower with CPU\nsupport; ordinary generator3.5–13.2%adverse, numeric reference moves15.2%, CSV\nroughly flat. Private pending coherent sequence-construction integration, not\npromoted or fully qualified. Focused actual11/10 each167public/59internal, all\ngoldens/refusal/cleanup gates pass; exact source/core/results persisted, all users\njoined. No unchanged retiming or objective completion. Independent producer source\n00e7905d differs from unchanged dev105 assets; core development remains independent.\n';p.write_text(s,encoding='utf-8')
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');s=s.replace('B865 five-job warm/fresh comparison is active; no result or promotion assumed.\nSource changes and controls must decide remaining CPU debt before retention.','[B865 complete](benchmarks/results/2026-11-16-generator-batches/guarded/README.md):\nnormalization warm11.7–17.3%lower elapsed/fresh8.2–15.4%lower with CPU support;\nordinary generator3.5–13.2%adverse, numeric reference moves15.2%, CSVroughly flat.\nKeep private; no unchanged retiming or partial production promotion. Complete the\nconstructor milestone below and decide remaining CPU debt before retention.')
s=s.replace('## Next coherent construction milestone (after the R458 decision)','## Next active construction milestone: R460')
s=s.replace('Select a concrete design before coding: final-capacity adoption versus a funded\ntrim copy; charge retained capacity, scalar headroom and replacement overlap.','Design from the existing private PyList capacity/rollback path, keeping native\ninteger-tuple construction. Adopt only exact final capacity; retain a funded trim\ncopy when count differs, without adding a tuple-count representation. Share native\nbuffering with these constructor consumers and remove the displaced async staging\nand duplicate scalar/growth loops. Transfer surviving funding before relinquishing\nthe private builder. Charge scalar headroom and replacement overlap.')
p.write_text(s,encoding='utf-8')
print('Guarded source/results preserved; coherent construction milestone next; production unchanged.')
