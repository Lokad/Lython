from pathlib import Path
import ast,hashlib,io,json,subprocess,tarfile
repo=Path('D:/code/Lython');r=Path(__file__).resolve().parent;template=r.parent/'refined/quiet';q=r/'quiet';q.mkdir();frozen=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));c=json.loads((template/'config.json').read_text(encoding='utf-8'));template_root=c['root'];root='/home/lokad/lython-bench-checks/generator-batches-b865-20261116';unit='lython-b865-generator-batches-20261116';source=template_root
canonical='benchmarks/results/2026-11-16-generator-batches/refined/measured-cores.tar.xz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();proofs=[]
with tarfile.open(fileobj=io.BytesIO(blob))as t:
 for name,paths in [('native-blocks-477e1d92.dll',['native-blocks-b860-20261116/candidate/Lokad.Lython.dll']),('generator-batches-99e6554d.dll',['generator-batches-b861-20261116/candidate/Lokad.Lython.dll','generator-batches-b862-20261116/candidate/Lokad.Lython.dll'])]:
  data=t.extractfile(name).read();proofs.append(dict(paths=paths,bytes=len(data),links=len(paths),sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=name,committedBlobVerified=True))
(r/'retirement-proof.json').write_text(json.dumps(proofs,indent=2)+'\n',encoding='utf-8')
base=frozen['imageFiles']['reference'];identity=dict(sourceRevision='Qualified9e8d1cf5/e92d9598 vs guarded privateR458/'+frozen['imageFiles']['candidate']['Lokad.Lython.dll'][:8],purpose='Guard inactive bulk-yield helper on ordinary paths; complete normalization warm/fresh, ordinary generator/numeric/CSV controls. No performance or qualification claim in advance.',imageFiles=frozen['imageFiles'],coreSHA256={label:frozen['imageFiles']['candidate'if label.startswith('candidate')else'reference']['Lokad.Lython.dll']for label in ['reference','reference-control','candidate','candidate-control']},auxiliaryFiles={n:h for n,h in base.items()if n!='Lokad.Lython.dll'},catalogSHA256=frozen['catalogSHA256'],normalAdapterPin='0.4.0',focusedStatus=frozen['focusedStatus'])
c.update(root=root,unit=unit,source=source,sourceRole='reference',sourceFiles=base,sourceCatalogSHA256=frozen['catalogSHA256'],catalogSHA256=frozen['catalogSHA256'],retireGroups=proofs,identity=identity)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
for n in ['collect.py','archive-owned.py','run.sh']:
 s=(template/n).read_text(encoding='utf-8').replace(template_root,root);assert template_root not in s
 if n=='run.sh':assert ('root='+root)in s
 (q/n).write_text(s,encoding='utf-8',newline='\n')
 if n.endswith('.py'):ast.parse(s)
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n in ['collect.py','archive-owned.py','run.sh','identity.json']:t.add(q/n,arcname=n)
 t.add(r/'frozen/candidate/Lokad.Lython.dll',arcname='candidate/Lokad.Lython.dll')
with tarfile.open(q/'payload.tgz')as t:c['unpackedBytes']=sum(m.size for m in t.getmembers())
c.update(payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest());(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
s=(template/'remote-launch.py').read_text(encoding='utf-8');tree=ast.parse(s);n=next(n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='c'for t in n.targets));lines=s.splitlines(keepends=True);lines[n.lineno-1:n.end_lineno]=['c='+repr(c)+'\n'];s=''.join(lines).replace('lython-b863-fixtures','lython-b865-fixtures').replace("assert (root/'representative.json').is_file()","os.link(source/'representative.json',root/'representative.json')");ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8')
(q/'retrieve.py').write_text((template/'retrieve.py').read_text(encoding='utf-8').replace('B863','B865'),encoding='utf-8')
(r/'launch.py').write_text((r.parent/'refined/launch.py').read_text(encoding='utf-8').replace('Seven-job','Five-job'),encoding='utf-8')
(r/'summarize.py').write_text((r.parent/'refined/summarize.py').read_text(encoding='utf-8'),encoding='utf-8')
print(json.dumps(dict(candidate=frozen['imageFiles']['candidate']['Lokad.Lython.dll'],retiredPhysicalBytes=sum(v['bytes']for v in proofs),jobs=5,warmupSeconds=6,onlyCoreChanges=True)))
