from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile,os
repo=Path('D:/code/Lython');r=repo/'.git/agent-notes/review-20261031/generator-batches-r458/guarded';w=repo/'.git/agent-worktrees/generator-batches-r458';old=r.parent.parent/'native-blocks-r456';f=r/'frozen';f.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert '0 Error(s)'in(r/'nonincremental-measured-core.log').read_text(encoding='utf-8')
previous=json.loads((old/'frozen/identity.json').read_text(encoding='utf-8'))
for role in ['reference','candidate']:
 (f/role).mkdir()
 for n,h in previous['imageFiles']['reference'].items():
  p=old/'frozen/reference'/n;assert sha(p)==h;shutil.copy2(p,f/role/n)
core=w/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'
for project in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:assert sha(w/'tests'/project/'bin/Release/net11.0/Lokad.Lython.dll')==sha(core),project
shutil.copy2(core,f/'candidate/Lokad.Lython.dll')
paths=subprocess.check_output(['git','ls-files','src','tests','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','NuGet.Config','global.json','Lokad.Lython.slnx'],cwd=w,text=True,encoding='utf-8').splitlines();paths.append('tests/Lokad.Lython.PublicApi.Tests/BulkGeneratorConsumptionTests.cs');assert len(paths)==len(set(paths))
images={role:{p.name:sha(p)for p in(f/role).iterdir()}for role in ['reference','candidate']};assert [n for n in images['reference']if images['reference'][n]!=images['candidate'][n]]==['Lokad.Lython.dll']
catalog=json.loads((old/'catalog.json').read_text(encoding='utf-8'));extra=json.loads((r.parent.parent/'materialization-r438/quiet/representative.json').read_text(encoding='utf-8'));catalog['cases'].append(next(c for c in extra['cases']if c['id']=='generators.drain.large'))
(r/'catalog.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8')
identity=dict(referenceSource='Fully qualified9e8d1cf5/e92d9598; root82e45812 production text unchanged',candidateSource='PrivateR458 at82e45812 plus archived admitted-capacity generator advancement',imageFiles=images,sourceInputs={p:sha(w/p)for p in paths},productionFiles=sum(p.startswith('src/Lokad.Lython/')for p in paths),catalogSHA256=sha(r/'catalog.json'),normalAdapterPin='0.4.0',focusedStatus=dict(net11=dict(public=167,internal=59,finalBulk=7),net10=dict(public=167,internal=59,finalBulk=7)),fullQualification=False,publicationHeld=True)
(f/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as t:
 for p in paths:t.add(w/p,arcname=p)
(r/'prototype.patch').write_bytes(subprocess.check_output(['git','diff','--','src'],cwd=w))
a=r/'allocation-short';a.mkdir()
for name in ['Program.cs','Allocation.csproj']:shutil.copy2(old/'allocation-short'/name,a/name)
s=(old/'validate-images.py').read_text(encoding='utf-8').replace('six-case','seven-case');(r/'validate-images.py').write_text(s,encoding='utf-8')
print(json.dumps(dict(core=sha(core),production=identity['productionFiles'],inputs=len(paths),cases=len(catalog['cases']))))
