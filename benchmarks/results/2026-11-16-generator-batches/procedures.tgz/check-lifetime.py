from pathlib import Path
import os,subprocess
r=Path('D:/code/Lython/.git/agent-notes/review-20261031/generator-batches-r458');w=Path('D:/code/Lython/.git/agent-worktrees/generator-batches-r458');dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env['DOTNET_ROOT']=str(dotnet.parent);env['DOTNET_ROOT_X64']=str(dotnet.parent);env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
classes=['MemoryAdmissionTerminalTests','SharedMemoryBudgetTests','MemoryOwnershipTests','MemoryAdmissionPropagationTests','RefusedAdmissionCleanupTests','AdmittedProjectionTests','GeneratorValueAccountingScenarioTests','BytesJoinExecutionTests','CooperativeCancellationTests','RenderJoinLifetimeScenarioTests']
# Discover names so the focused log never implies nonexistent test coverage.
classes=[c for c in classes if (w/'tests/Lokad.Lython.PublicApi.Tests'/(c+'.cs')).exists()];print('Focused classes',classes,flush=True)
condition='Category!=Stress&('+'|'.join('FullyQualifiedName~.'+c+'.'for c in classes)+')';log=r/'lifetime-public-net10.log'
with log.open('w',encoding='utf-8')as f:p=subprocess.run([str(dotnet),'test',str(w/'tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj'),'-c','Release','-f','net10.0','--no-build','--filter',condition,'--logger','trx;LogFileName=lifetime-public-net10.trx','--results-directory',str(r)],cwd=w,env=env,stdout=f,stderr=subprocess.STDOUT)
print(log.read_text(encoding='utf-8')[-1000:],flush=True);raise SystemExit(p.returncode)
