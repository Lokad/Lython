from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).resolve().parent;old=r/'quiet';q=r/'confirmation';q.mkdir();c=json.loads((old/'config.json').read_text(encoding='utf-8'));source=c['root'];root='/home/lokad/lython-bench-checks/generator-batches-b862-20261116';unit='lython-b862-generator-batches-20261116'
c.update(root=root,unit=unit,source=source,sourceRole='reference',sourceCatalogSHA256=c['catalogSHA256'],retireGroups=[])
c['identity']['purpose']='Bounded same-source confirmation: eight-second warmup for complete normalization and ordinary generator controls; preserve original moving reference conditions. No source refinement.'
(q/'identity.json').write_text(json.dumps(c['identity'],indent=2)+'\n',encoding='utf-8')
jobs=[['scripts.text-normalization.large','warm'],['generators.drain.large','warm'],['generators.drain.large','compile-run']]
for name in ['collect.py','archive-owned.py','run.sh']:
 s=(old/name).read_text(encoding='utf-8').replace(source,root)
 if name=='collect.py':
  lines=s.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('jobs='));lines[i]='jobs='+repr(jobs);s='\n'.join(lines)+'\n';s=s.replace('len(jobs)==7','len(jobs)==3').replace('end=time.monotonic()+4','end=time.monotonic()+8')
 if name=='archive-owned.py':s=s.replace("len(raw['jobs'])==7","len(raw['jobs'])==3").replace('jobs=7','jobs=3')
 (q/name).write_text(s,encoding='utf-8',newline='\n')
 if name.endswith('.py'):ast.parse(s)
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n in ['collect.py','archive-owned.py','run.sh','identity.json']:t.add(q/n,arcname=n)
with tarfile.open(q/'payload.tgz')as t:c['unpackedBytes']=sum(m.size for m in t.getmembers())
c.update(payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest());(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
s=(old/'remote-launch.py').read_text(encoding='utf-8');tree=ast.parse(s);n=next(n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='c'for t in n.targets));lines=s.splitlines(keepends=True);lines[n.lineno-1:n.end_lineno]=['c='+repr(c)+'\n'];s=''.join(lines).replace('lython-b861-fixtures','lython-b862-fixtures').replace("os.link(source/c['sourceRole']/n,p)","os.link(source/role/n,p)").replace("assert (root/'representative.json').is_file()","os.link(source/'representative.json',root/'representative.json')")
ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'retrieve.py').read_text(encoding='utf-8').replace("['jobs']==7","['jobs']==3").replace('B861','B862');(q/'retrieve.py').write_text(s,encoding='utf-8')
s=(r/'launch.py').read_text(encoding='utf-8').replace("r=Path(__file__).parent/'quiet'","r=Path(__file__).parent/'confirmation'").replace('seconds=230','seconds=180').replace('230seconds','180seconds').replace('Seven-job generator batches','Three-job generator confirmation');(r/'launch-confirmation.py').write_text(s,encoding='utf-8')
s=(r/'summarize.py').read_text(encoding='utf-8').replace("r=Path(__file__).resolve().parent","r=Path(__file__).resolve().parent/'confirmation'").replace("r/'quiet/retrieved/confirmation/confirmation.json'","r/'retrieved/confirmation/confirmation.json'").replace("len(raw['jobs'])==7","len(raw['jobs'])==3");(r/'summarize-confirmation.py').write_text(s,encoding='utf-8')
print('Same frozen sources/images; three jobs with8s warmup; no retired files or new core copy.')
