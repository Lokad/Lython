from pathlib import Path
import subprocess,os,json,re,textwrap
r=Path('D:/code/Lython/.git/agent-notes/review-20261031/generator-batches-r458');w=Path('D:/code/Lython/.git/agent-worktrees/generator-batches-r458');dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env['DOTNET_ROOT']=str(dotnet.parent);env['DOTNET_ROOT_X64']=str(dotnet.parent);env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
s=(w/'tests/Lokad.Lython.PublicApi.Tests/BulkGeneratorConsumptionTests.cs').read_text(encoding='utf-8');rows=[]
for source in re.findall(r'"""\n(.*?)\n\s*"""',s,re.S):
 source=textwrap.dedent(source);code='def run():\n'+textwrap.indent(source,'    ')+'\nassert run() == "ok"\n';p=subprocess.run(['C:/Python313/python.exe','-X','utf8','-I','-S','-c',code],capture_output=True,text=True);rows.append(dict(source=source,exitCode=p.returncode,stdout=p.stdout,stderr=p.stderr));assert p.returncode==0,p.stderr
(r/'new-test-cpython.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8');print('Four new semantic programs agree with isolated CPython3.13.',flush=True)
classes=['GeneratorStatementCompositionTests','GeneratorDefinitionCompositionTests','GeneratorTargetCompositionTests','GeneratorNamespaceMutationTests','GeneratorExpressionCompositionTests','GeneratorConstructionScenarioTests','GeneratorAugmentedSliceBoundaryTests','GeneratorDefinitionMetadataTests','BuiltinIterationCancellationTests','GeneratorValueAccountingScenarioTests','FunctionNamespaceLifetimeTests','CooperativeCancellationTests','StarmapMaterializationParityTests','RepresentativeProtocolCancellationTests']
condition='Category!=Stress&('+'|'.join('FullyQualifiedName~.'+c+'.' for c in classes)+')';log=r/'broader-public-net11.log'
with log.open('w',encoding='utf-8')as f:p=subprocess.run([str(dotnet),'test',str(w/'tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj'),'-c','Release','-f','net11.0','--no-build','--filter',condition,'--logger','trx;LogFileName=broader-public-net11.trx','--results-directory',str(r)],cwd=w,env=env,stdout=f,stderr=subprocess.STDOUT)
print(log.read_text(encoding='utf-8')[-1200:],flush=True);raise SystemExit(p.returncode)
