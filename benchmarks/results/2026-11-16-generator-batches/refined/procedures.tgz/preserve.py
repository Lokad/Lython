from pathlib import Path
import json,hashlib,tarfile,shutil,xml.etree.ElementTree as E
repo=Path('D:/code/Lython');base=repo/'.git/agent-notes/review-20261031';r=base/'generator-batches-r458/refined';out=repo/'benchmarks/results/2026-11-16-generator-batches/refined';out.mkdir()
for n in ['summary.json','allocation-summary.json','prototype.patch','candidate-sources.tar.xz','new-test-cpython.json']:shutil.copy2(r/n,out/n)
shutil.copy2(r/'frozen/identity.json',out/'identity.json');shutil.copy2(r/'quiet/observations.tgz',out/'observations.tgz')
ns={'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'};checks=[]
for p in r.glob('*.trx'):
 v=E.parse(p).find('t:ResultSummary/t:Counters',ns).attrib;assert v['failed']=='0';checks.append(dict(file=p.name,**v))
(out/'validation.json').write_text(json.dumps(dict(checks=checks,overlappingFiltersNotSummed=True,completeGoldenScripts=7,independentCPythonPrograms=5,fullQualification=False,retained=False,remainingCorrection='Guard the inactive bulk helper before entry on ordinary yields; no further measured source yet',publicationHeld=True),indent=2)+'\n',encoding='utf-8')
with tarfile.open(out/'focused-checks.tgz','w:gz')as t:
 for p in r.iterdir():
  if p.is_file()and p.suffix in ['.log','.trx','.txt']:t.add(p,arcname=p.name)
 for p in(r/'allocation-short').glob('*.json'):t.add(p,arcname='allocation-short/'+p.name)
with tarfile.open(out/'procedures.tgz','w:gz')as t:
 for folder in [r,r/'quiet',r/'quiet/failed-launch']:
  for p in folder.iterdir():
   if p.is_file()and(p.suffix in ['.py','.sh']or p.name in ['config.json','launch.log','corrected-launch.log','observe-not-before.json','terminal-status.json','archive-receipt.json','retirement-proof.json']or p.name.startswith('observation-')):t.add(p,arcname=p.relative_to(r).as_posix())
cores=[(base/'native-blocks-r456/frozen/candidate/Lokad.Lython.dll','native-blocks-477e1d92.dll','477e1d921cb2c52d12afafee313e70823b04929bb6e47ac1752416d0d3405d80'),(base/'generator-batches-r458/frozen/candidate/Lokad.Lython.dll','generator-batches-99e6554d.dll','99e6554d13c58675f4787d0aeeddb8c2f2155d1d50191d3d47ed6a32c575e694'),(r/'frozen/candidate/Lokad.Lython.dll','generator-batches-4fcfcc71.dll','4fcfcc71c1ad5b6a021d782e72ad34111907592334c11b2cda32b7596c253711')]
with tarfile.open(out/'measured-cores.tar.xz','w:xz')as t:
 for p,name,h in cores:
  assert hashlib.sha256(p.read_bytes()).hexdigest()==h;t.add(p,arcname=name)
(out/'README.md').write_text('''# Buffered yields inside the existing engine: correction pending

R458 refined4fcfcc71 versus qualified9e8d1cf5/e92d9598,2026-11-16UTC.
**Private, not promoted.** Single-item Advance/AdvanceAsync are restored; the existing
instruction loop consumes private yields into admitted list capacity. One borrowed
destination/limit ends before observation, growth or cleanup. Pending disposal
returns through the existing awaited path. No second interpreter/owner/policy.

| Complete workload | Phase | Elapsed change | Wider CPU change |
| --- | --- | ---: | ---: |
| Normalization,4,096lines/52,224B | Warm | −14.83..−11.57% | −14.60..−10.68% |
| Same normalization | Compile and run once | −10.47..−7.71% | −10.92..−8.01% |
| Ordinary generator/list/render control,16,384values | Warm | −2.98..+2.52% | −3.08..+2.47% |
| Numeric report,4,096records | Warm | +5.34..+13.33% | +6.84..+14.13% |
| CSV invoice,4,096rows | Warm | +0.30..+1.71% | +0.56..+2.62% |

All four process-median pairings retained; negative means faster. Numeric reference
moves5.82%, but all elapsed/CPU pairings are adverse. Generator candidate moves4.59%;
normalization reference/candidate0.07/3.75%. Allocation adds only32B per affected
invocation (<0.006%), accounted peaks and compiled allowance unchanged. Neither
absence of regression nor a universal CPU gain is established.

Source still calls TryBufferYield for ordinary yields with an inactive destination.
A bounded correction will guard that cold helper at its callers, preserving the
single-item engine and borrowed bulk destination. No further timing or production
promotion is claimed here. Original99e placement and its longer-warmup control
adversity remain in [the parent](../README.md). No fixed-percentage veto or permanent
ban; a useful final design must decide its remaining representative regression debt.

B864 five jobs193.464s: quietF4as_v7 Ubuntu24.04.4,.NET11RC3 normal tiering/natural
workstation GC,two processes/source,6s full-request warmup and five rotated~0.5s
samples/process. Warm includes Run, mediated RAM I/O, full goldens and prior-result
cleanup; excludes compile/startup/reset/protocol/final caches. Fresh includes compile
and compiled-owner disposal; CPU clocks are wider. All identity/quiet/Closed/exit/
join/archive gates pass. Persistent archive SHA-verified before RAM teardown; no
users remain and terminal cached. No fresh CPython/RSS/embedding-tail claim.

Original B863 launcher had a stale B860 root and exited before benchmark workers,
producing no timing. Its trap changed B860's completion-marker file; that marker
was restored to zero from the immutable cached original terminal. Original scripts,
journal, failure and correction remain archived. B864 reuses the same verified
working image/root with the corrected launcher; source and measurement protocol
remain frozen. Only exactly proved committed replicas were retired; selected images,
toolchains and canonical evidence preserved. Staging254MiB/final252MiB floors hold.

Focused actual Windows.NET11/10 each166public/59internal pass, plus seven final
semantic/refusal rows each and183additional public.NET11 cases (overlap not summed).
Seven frozen worker/CPython goldens and five independent semantic programs pass.
The diagnostic extractor initially included the separate refusal fixture and made
an incorrect CPython return assertion; the scoped extractor correction and original
failure are preserved. No runtime test failed or assertion/budget was relaxed.
Full platform/stress/installed-package qualification waits for a retained design.

[Results](summary.json),[allocation](allocation-summary.json),[validation](validation.json),
[frozen inputs/images](identity.json),[source](candidate-sources.tar.xz),
[raw evidence](observations.tgz),[focused checks](focused-checks.tgz),
[original failure/correction/procedures](procedures.tgz),
[exact measured prototype cores](measured-cores.tar.xz).
The core archive preserves original477e, initial99e and refined4fc bytes against their
recorded SHA256 values; these are unpublished benchmark snapshots, not release packages.
''',encoding='utf-8')
p=repo/'benchmarks/EXPERIMENTS.md';s=p.read_text(encoding='utf-8');s+='\n[R458 existing-loop refinement](results/2026-11-16-generator-batches/refined/README.md):\n4fcfcc71/B864 normalization warm11.6–14.8%lower elapsed/fresh7.7–10.5%lower,\nordinary-generator control mixed, numeric5.3–13.3%adverse with CPU support/moving\nreference. Private, not promoted; guard inactive bulk helper before another source\ncomparison. Allocation+32B (<0.006%), peaks unchanged. All gates/join/archive pass;\nfailed B863 stale launcher and diagnostic extractor preserved/corrected. Full\nqualification waits for retained design; whole-script roadmap remains open.\n';p.write_text(s,encoding='utf-8')
print('Refined adverse results, failures and exact prototype cores preserved.')
