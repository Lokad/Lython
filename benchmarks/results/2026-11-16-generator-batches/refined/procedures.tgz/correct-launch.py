from pathlib import Path
import datetime,hashlib,json,shlex,shutil,subprocess
r=Path(__file__).resolve().parent;q=r/'quiet';failed=q/'failed-launch';failed.mkdir()
for n in ['config.json','run.sh','launch.log','observe-not-before.json']:
 shutil.copy2(q/n,failed/n)
for p in q.glob('observation-*.json'):shutil.copy2(p,failed/p.name)
c=json.loads((q/'config.json').read_text(encoding='utf-8'));root=c['root'];unit='lython-b864-generator-batches-20261116';bad=(q/'run.sh').read_bytes();good=bad.replace(b'/home/lokad/lython-bench-checks/native-blocks-b860-20261116',root.encode());assert good!=bad and root.encode()in good
code=r'''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
c=CONFIG
root=Path(c['root']);b=root.parent;fixture=root/'guest-fixtures';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert root.resolve()==root and root.parent==Path('/home/lokad/lython-bench-checks')
 assert not(root/'confirmation').exists()and not(root/'exit-code.txt').exists()
 workers=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True).stdout
 assert not workers,workers
 assert os.path.ismount(fixture)and not any(fixture.iterdir())
 assert not any(os.path.ismount(p)for p in b.glob('*/guest-fixtures')if p!=fixture)
 failed=subprocess.check_output(['systemctl','show',c['unit']+'.service','--property=ActiveState,MainPID,Result,ExecMainStatus'],text=True);assert 'MainPID=0'in failed and 'ExecMainStatus=1'in failed
 fresh=subprocess.check_output(['systemctl','show',NEWUNIT+'.service','--property=LoadState,MainPID'],text=True);assert 'LoadState=not-found'in fresh and 'MainPID=0'in fresh
 p=root/'run.sh';assert p.is_file()and not p.is_symlink()and p.stat().st_uid==os.getuid()and p.read_bytes()==BAD
 for role,files in c['identity']['imageFiles'].items():
  for n,h in files.items():assert sha(root/role/n)==h
 assert sha(root/'representative.json')==c['catalogSHA256']
 for n in ['collect.py','archive-owned.py']:assert '/home/lokad/lython-bench-checks/native-blocks-b860-20261116'not in(root/n).read_text()
 # The bad trap changed only this old completion marker. Its immutable cached
 # terminal and archive receipt prove the completed original result was zero.
 marker=b/'native-blocks-b860-20261116/exit-code.txt';assert marker.resolve()==marker and marker.is_file()and not marker.is_symlink()and marker.stat().st_uid==os.getuid()and marker.read_bytes()==b'1\n'
 assert json.loads((marker.parent/'archive-receipt.json').read_text())['complete']
 marker.write_bytes(b'0\n')
 shutil.copyfile(p,root/'run.failed-b863.sh');p.write_bytes(GOOD)
 subprocess.run(['/bin/sh','-n',str(p)],check=True)
 receipt=dict(failedBeforeWorkers=True,service=failed,originalRunSHA256=hashlib.sha256(BAD).hexdigest(),correctedRunSHA256=sha(p),allFrozenImagesVerified=True,emptyFixtureVerified=True,oldCompletionMarkerRestoredFromCachedTerminal=True,correctedUnit=NEWUNIT)
 (root/'launch-failure.json').write_text(json.dumps(receipt,indent=2)+'\n')
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();fixture.mkdir()
 assert shutil.disk_usage(b).free>254*1024*1024
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=32m,mode=0700,uid=lokad,gid=lokad','lython-b864-fixtures',str(fixture)],check=True)
 subprocess.run(['sudo','-n','systemd-run','--unit='+NEWUNIT,'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=240','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(p)],check=True)
 print(json.dumps(dict(launched=True,unit=NEWUNIT,root=str(root),receipt=receipt,freeBytes=shutil.disk_usage(b).free)))
'''.replace('CONFIG',repr(c)).replace('NEWUNIT',repr(unit)).replace('BAD',repr(bad)).replace('GOOD',repr(good))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);(q/'corrected-launch.log').write_text(p.stdout+p.stderr,encoding='utf-8');assert p.returncode==0,p.stdout+p.stderr
c['unit']=unit;(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8');(q/'run.sh').write_bytes(good)
now=datetime.datetime.now(datetime.timezone.utc);(q/'observe-not-before.json').write_text(json.dumps(dict(launchedAtUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=230)).isoformat()),indent=2)+'\n',encoding='utf-8');print(p.stdout,flush=True)
