from pathlib import Path
import ast,hashlib,io,json,subprocess,tarfile
repo=Path('D:/code/Lython');r=Path(__file__).resolve().parent;old=r.parent.parent/'native-blocks-r456';template=old/'quiet';q=r/'quiet';q.mkdir()
root='/home/lokad/lython-bench-checks/generator-batches-b863-20261116';unit='lython-b863-generator-batches-20261116';source='/home/lokad/lython-bench-checks/generator-batches-b861-20261116'
frozen=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));c=json.loads((template/'config.json').read_text(encoding='utf-8'));base=frozen['imageFiles']['reference'];proofs=[]
for mapping in json.loads((r/'retirement-candidates.json').read_text(encoding='utf-8')):
 blob=subprocess.check_output(['git','show','HEAD:'+mapping['canonical']],cwd=repo);assert blob==(repo/mapping['canonical']).read_bytes()
 if mapping['member']:
  with tarfile.open(fileobj=io.BytesIO(blob))as t:data=t.extractfile(mapping['member']).read()
 else:data=blob
 proofs.append(dict(paths=[mapping['path']],bytes=len(data),links=1,sha256=hashlib.sha256(data).hexdigest(),canonical=mapping['canonical'],canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=mapping['member'],committedBlobVerified=True,optional=mapping.get('optional',False)))
(r/'retirement-proof.json').write_text(json.dumps(proofs,indent=2)+'\n',encoding='utf-8')
identity=dict(sourceRevision='Qualified9e8d1cf5/e92d9598 vs privateR458/'+frozen['imageFiles']['candidate']['Lokad.Lython.dll'][:8],purpose='Existing-engine admitted-capacity generator batches: complete normalization and generator consumption warm/fresh, CSV/report/numeric controls. No speedup or full qualification claim.',imageFiles=frozen['imageFiles'],coreSHA256={label:frozen['imageFiles']['candidate'if label.startswith('candidate')else'reference']['Lokad.Lython.dll']for label in ['reference','reference-control','candidate','candidate-control']},auxiliaryFiles={n:h for n,h in base.items()if n!='Lokad.Lython.dll'},catalogSHA256=frozen['catalogSHA256'],normalAdapterPin='0.4.0',focusedStatus=frozen['focusedStatus'])
c.update(root=root,unit=unit,source=source,sourceRole='reference',sourceFiles=base,sourceCatalogSHA256=frozen['catalogSHA256'],catalogSHA256=identity['catalogSHA256'],retireGroups=proofs,identity=identity)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8');(q/'representative.json').write_bytes((r/'catalog.json').read_bytes())
jobs=[['scripts.text-normalization.large','warm'],['scripts.text-normalization.large','compile-run'],['generators.drain.large','warm'],['scripts.numeric-squared-error.large','warm'],['scripts.csv-invoice.large','warm']]
for name in ['collect.py','archive-owned.py','run.sh']:
 s=(template/name).read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/native-blocks-b860-20261116',root)
 if name=='collect.py':
  lines=s.splitlines();i=next(i for i,l in enumerate(lines)if l.startswith('jobs='));lines[i]='jobs='+repr(jobs);s='\n'.join(lines)+'\n';s=s.replace('len(jobs)==7','len(jobs)==5').replace('end=time.monotonic()+4','end=time.monotonic()+6')
 if name=='archive-owned.py':s=s.replace("len(raw['jobs'])==7","len(raw['jobs'])==5").replace('jobs=7','jobs=5')
 (q/name).write_text(s,encoding='utf-8',newline='\n')
 if name.endswith('.py'):ast.parse(s)
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n in ['collect.py','archive-owned.py','run.sh','identity.json','representative.json']:t.add(q/n,arcname=n)
 t.add(r/'frozen/candidate/Lokad.Lython.dll',arcname='candidate/Lokad.Lython.dll')
with tarfile.open(q/'payload.tgz')as t:c['unpackedBytes']=sum(m.size for m in t.getmembers())
c.update(payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest());(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
s=(template/'remote-launch.py').read_text(encoding='utf-8');tree=ast.parse(s);n=next(n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='c'for t in n.targets));lines=s.splitlines(keepends=True);lines[n.lineno-1:n.end_lineno]=['c='+repr(c)+'\n'];s=''.join(lines).replace('lython-b860-fixtures','lython-b863-fixtures').replace("os.link(source/'representative.json',root/'representative.json')","assert (root/'representative.json').is_file()")
ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
for n in ['retrieve.py']:(q/n).write_text((template/n).read_text(encoding='utf-8').replace('B860','B863').replace("['jobs']==7","['jobs']==5"),encoding='utf-8',newline='\n')
(r/'launch.py').write_text((old/'launch.py').read_text(encoding='utf-8').replace('complete native blocks','generator batches').replace('B860','B863').replace("['jobs']==7","['jobs']==5"),encoding='utf-8',newline='\n')
(r/'summarize.py').write_text((old/'summarize.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==7","len(raw['jobs'])==5"),encoding='utf-8')
print(json.dumps(dict(jobs=jobs,provedRetirementBytes=sum(p['bytes']for p in proofs),unpackedBytes=c['unpackedBytes'],payloadBytes=c['payloadBytes'])))
