from collections import Counter
from pathlib import Path
import json


ROOT = Path(__file__).resolve().parent
ROLES = ('iterable-async', 'document-sync', 'compiled-log-sync')
REGIONS = {
    'iterable row': ('InvokeIterableRowAsync','InvokeGeneratorRowAsync'),
    'argument buffer allocation': ('CallArgumentAccumulator..ctor',),
    'argument buffer disposal': ('CallArgumentAccumulator.Dispose',),
    'argument buffer expansion': ('AppendPositionalIterableAsync',),
    'buffered generator advancement': ('AdvanceBuffered','InvokeGeneratorRowAsync'),
    'generator advancement': ('PyGenerator.Advance', 'PyGenerator+<AdvanceAsync>'),
    'binding': ('BindFunctionArgumentsInto', 'TryStartPositionalCallback'),
    'memory reservation': ('MemoryGovernor.Reserve',),
    'memory refund': ('MemoryGovernor.Release',),
    'CSV record': ('CsvRecordParser',),
    'sum': ('SumState',),
    'compilation': ('LythonEngine.Compile',),
    'abstract analysis': ('StaticAbstractInterpreter', 'StaticNameBindingDiagnostics'),
    'parsing': ('Frontend.Parser', 'PythonTokenization'),
    'emission': ('ExecutableScript.Compile', 'ExecutableScript+Builder'),
    'frame entry': ('PyGenerator.EnterFrame', 'EnterInterpreterFrame', 'EnterFunctionCall'),
    'generator resume': ('ExecutionContext.Resume', 'TryAppendBufferedYield'),
    'instruction prefix': ('ExecuteInstructionPrefix', 'RunNativePrefix'),
    'starmap': ('PyStarmapIterator',),
    'direct iteration callback': ('StartIterationCallback', 'TryStartPositionalCallback'),
    'native value storage': ('ExecutableValueStorage..ctor', 'RentFunctionArgumentStorage'),
    'generator construction': ('PyGenerator.Create', 'EnterInvocationFrame'),
    'host file': ('OpenedByteFile', 'TextFileReadState'),
    'JSON construction': ('ContinueJsonConstruction','ReadJsonContainerAsync'),
    'JSON record': ('PushJsonContainer','RecordKeys.CreateRecord','PyDict..ctor'),
    'JSON string': ('ReadJsonString','WriteEscapedJsonString'),
    'JSON UTF-8 copy or borrow': ('PyString.CopyOrBorrowUtf8Range','PyString.CopyFromUtf8'),
    'regex adapter': ('Lokad.Lython.Utf8Regex.',),
    'regex producer': ('Lokad.Utf8Regex.',),
    'regex runtime': ('RegexMatcher','PyRegexPattern','RegexFind'),
    'text file': ('TextFileHandle','ChunkedTextFileReadState'),
    'JSON': ('JsonDeserialize', 'JsonSerialize', 'JsonConstruction', 'WriteJson'),

}
WAIT_FRAMES = ('WaitSubsystem+ThreadWaitInfo.Wait', 'LowLevelThreadBlocker.TimedWait', 'PollGCWorker')


def analyze(role):
    capture = json.loads((ROOT / role / 'run.speedscope.json').read_bytes())
    frames = [frame['name'].split('(', 1)[0].split('!', 1)[-1] for frame in capture['shared']['frames']]
    nearest = Counter()
    row_nearest = Counter()
    region = Counter()
    runtime = 0
    for profile in capture['profiles']:
        assert profile['unit'] == 'milliseconds' and profile['type'] == 'evented'
        stack = []
        previous = profile['startValue']
        for event in profile['events']:
            elapsed = event['at'] - previous
            active = [frame for frame in stack if frame.startswith(('Lokad.Lython.Runtime.', 'Lokad.Lython.Frontend.', 'Lokad.Lython.LythonEngine', 'Lokad.Lython.Utf8Regex.', 'Lokad.Utf8Regex.'))]
            if elapsed > 0 and active and not any(mark in frame for frame in stack for mark in WAIT_FRAMES):
                runtime += elapsed
                nearest[active[-1]] += elapsed
                if any('InvokeIterableRowAsync' in frame or 'InvokeGeneratorRowAsync' in frame for frame in active):
                    row_nearest[active[-1]] += elapsed
                for label, marks in REGIONS.items():
                    if any(mark in frame for frame in active for mark in marks):
                        region[label] += elapsed
            if event['type'] == 'O':
                stack.append(frames[event['frame']])
            else:
                assert stack.pop() == frames[event['frame']]
            previous = event['at']
        assert not stack
    return dict(role=role, runtimeThreadMilliseconds=runtime, inclusiveRegionsMilliseconds=region,
                nearestLythonMethods=nearest.most_common(35), nearestIterableMethods=row_nearest.most_common(35))


rows = [analyze(role) for role in ROLES]
(ROOT / 'attribution.json').write_text(json.dumps(rows, indent=2) + '\n', encoding='utf-8', newline='\n')
for row in rows:
    runtime = row['runtimeThreadMilliseconds']
    print(row['role'], round(runtime, 1))
    for name, elapsed in row['inclusiveRegionsMilliseconds'].most_common():
        print(f'  {100 * elapsed / runtime:5.1f}% {name}')
    for name, elapsed in (row['nearestIterableMethods'] or row['nearestLythonMethods'])[:8]:
        print(f'  {100 * elapsed / runtime:5.1f}% {name}')
