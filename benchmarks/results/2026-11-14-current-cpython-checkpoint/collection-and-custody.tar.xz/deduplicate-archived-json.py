from pathlib import Path
import hashlib,io,json,subprocess,tarfile

r=Path(__file__).parent
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
proof=[]
for canonical,remote in [('benchmarks/results/2026-11-14-native-entry-admission/observations.tgz','native-entry-b758-20261114')]:
    blob=subprocess.check_output(['git','show',head+':'+canonical])
    assert blob==Path(canonical).read_bytes()
    with tarfile.open(fileobj=io.BytesIO(blob),mode='r:gz')as a:body=a.extractfile('confirmation/confirmation.json').read()
    proof.append(dict(commit=head,canonicalArchive=canonical,remoteRoot=remote,archiveSHA256=hashlib.sha256(blob).hexdigest(),member='confirmation/confirmation.json',bytes=len(body),sha256=hashlib.sha256(body).hexdigest()))
config=json.loads((r/'config.json').read_text(encoding='utf-8'))
code=r'''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess,tarfile
proof=PROOF
required=REQUIRED
base=Path('/home/lokad/lython-bench-checks').resolve()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(p.is_mount()for p in base.glob('*/guest-fixtures'))
 paths=[];observations=[]
 for item in proof:
  root=base/item['remoteRoot'];p=root/item['member'];archive=root/'observations.tgz'
  assert root.resolve()==root and p.resolve()==p and archive.resolve()==archive and p.is_relative_to(base)
  s=p.lstat();assert stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_nlink==1 and s.st_size==item['bytes']
  assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
  assert hashlib.sha256(archive.read_bytes()).hexdigest()==item['archiveSHA256']
  with tarfile.open(archive)as a:assert hashlib.sha256(a.extractfile(item['member']).read()).hexdigest()==item['sha256']
  assert(root/'exit-code.txt').read_text().strip()=='0'and json.loads((root/'archive-receipt.json').read_text())['complete']
  paths.append(p);observations.append(dict(path=str(p),uid=s.st_uid,inode=s.st_ino,links=s.st_nlink,bytes=s.st_size,archiveStillPresent=str(archive)))
 before=shutil.disk_usage(base).free
 assert before+sum(item['bytes']for item in proof)>254*1024*1024+required+32768
 for p in paths:p.unlink()
 receipt=dict(committedProof=proof,metadata=observations,allPathsMetadataAndRawArchiveHashesVerifiedBeforeMutation=True,idleLease=True,retiredOnlyDuplicateJson=[str(p)for p in paths],beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,compressedRawArchivesAndLocalGitEvidenceRetained=True,currentImagesCatalogsToolchainsAndFloorsUnchanged=True)
 (base/'b761-proved-archived-json-deduplication.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(receipt),flush=True)
'''.replace('PROOF',repr(proof)).replace('REQUIRED',repr(config['unpackedBytes']))
(r/'deduplication-command.py').write_text(code,encoding='utf-8',newline='\n')
done=subprocess.run(['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73','python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=30)
(r/'deduplication-result.log').write_text(done.stdout+done.stderr,encoding='utf-8',newline='\n')
assert done.returncode==0,done.stdout+done.stderr
receipt=json.loads(done.stdout);(r/'deduplication-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(dict(exactArchivedJsonCopiesDeduplicated=receipt['retiredOnlyDuplicateJson'],afterFreeBytes=receipt['afterFreeBytes'],evidenceRetained=True)),flush=True)
