from pathlib import Path
import hashlib,json,shutil,tarfile

r=Path(__file__).parent
summary=json.loads((r/'summary.json').read_text(encoding='utf-8'))
receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'))
assert summary['complete']and summary['jobs']==5 and receipt['complete']and receipt['allWorkersJoined']and receipt['quietBeforeAndAfter']
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
ci=json.loads((r.parent/'scalar-results-r370/delivery/ci-terminal.json').read_text(encoding='utf-8'))
assert ci['conclusion']=='success'and ci['headSha']=='4beb9ecf96769af57f937d72fba33363b57bac35'
out=Path('benchmarks/results/2026-11-14-current-cpython-checkpoint');out.mkdir()
for name in ['observations.tgz','summary.json','archive-receipt.json','identity.json','prospective.json']:shutil.copyfile(r/name,out/name)
shutil.copyfile('docs/BENCHMARKS.md',out/'prior-BENCHMARKS.md')
with tarfile.open(out/'collection-and-custody.tar.xz','w:xz')as t:
    for p in sorted(r.iterdir()):
        if p.is_file()and p.name not in ['observations.tgz','payload.tgz']:t.add(p,arcname=p.name)
rows={(x['case'],x['lane']):x for x in summary['timing']}
fulfill='scripts.csv-fulfillment.large';invoice='scripts.csv-invoice.large';text='scripts.text-summary-helpers.nonlocal-counter.large'
def timing(row,engine,micro=False):
    values=[v for name,v in row['medianMilliseconds'].items()if name.startswith(engine)]
    factor=1000 if micro else 1
    return '–'.join(f'{x*factor:.3f}'for x in [min(values),max(values)])+(' µs'if micro else' ms')
def ratio(row):
    values=[f'{x:.2f}'for x in [min(row['ratioRange']),max(row['ratioRange'])]]
    return ('–'.join(values)if values[0]!=values[1]else values[0])+'×'
def status(row,variable=False):return ('Variable'if variable else'Diagnostic')+f" 4beb; spreads {row['lythonControlPercent']:.2f}/{row['cpythonControlPercent']:.2f}%; max IQR {row['maxIqrPercent']:.2f}%"
table=[]
for case,lane in [(fulfill,'warm'),(fulfill,'compile'),(fulfill,'compile-run'),(invoice,'warm'),(text,'warm')]:
    row=rows[case,lane];table.append('|'+case+' /'+lane+'|'+timing(row,'candidate',lane=='compile')+'|'+timing(row,'CPython',lane=='compile')+'|'+ratio(row)+'|'+status(row,case==text or case==fulfill and lane=='warm')+'|')
(out/'README.md').write_text('''# Current complete-script CPython checkpoint

R372/B761, 2026-11-14 UTC. Committed source `4beb9ecf` / frozen `bed6e57e`
against stockCPython3.13.16. [Full43649993181passes](../2026-11-14-builtin-scalar-publication/delivery/README.md):
Windows/Ubuntu actual11/10, originalstress/installedRelease consumers;582-input
source proof. The image was frozen before commit at0ceb with the five production
changes; all source bytes map to4beb with explicit newline normalization. Independent
rebuilt binary identity is not inferred. Same fixed worker/adapter0.4/catalog and
trusted Python scripts/data. Core remains decoupled; publication held.

| Complete script /phase | Lython | CPython | Lython /CPython | Status |
| --- | ---: | ---: | ---: | --- |
'''+ '\n'.join(table)+'''

Above one means Lython slower. Ranges span independent process medians and ratios
all four engine pairings; they are not confidence intervals. Fulfillment's Lython
processes vary2.53%; text4.46%while CPython varies0.06%. Retain those uncertain
rows and all IQRs, wider CPU and warmups. Invoice is stable within this collection.
This refresh does not attribute changes across older collections to R370, erase
its invoice regression debt, or predict embedding latency. Fulfillment compilation
is about.13ms versus~8ms execution; analysis is not a demonstrated dominant cost.

One five-job200.366s collection, quiet AzureF4as_v7/Ubuntu24.04.4/fourEPYC9V45/
16GiB/no swap/.NET11RC3, normal workstationGC/tiering and PythonGIL/GC. Two fresh
processes per engine/job,5sfull-request warmups/12stext,5rotating.5sbatches.
Warm clocks include mediated RAM-file I/O, full stdout/file validation and prior-
result cleanup. Exclude startup/compile/fixture staging/reset/protocol and final
cache teardown. Fresh adds per-invocation compilation and compiled-owner disposal.
Compile alone excludes execution. Wider process CPU also includes reset/protocol.
Lython compiles/validates its supported subset; CPython uses its normal compiler.
Startup, pending-I/O latency, contention, heap/RSS peaks and embedding tails remain
unmeasured. Diagnostic profiling overrides were absent from this collection.

Every library/catalog/source/golden/output/file/budget/stockPython/quiet/join/archive
gate passes. No new core/catalog uploaded; current images/auxiliaries/toolchains
are hardlinked from the already-verified image. One exact duplicate B758rawJSON
is removed only after committed/local/remote archive member SHA and path/UID/link
proof under idle lease. Original compressed archive/localGit evidence survives.
254/252MiB floors unchanged; final free265,969,664B. Raw persists and verifies
under lease before RAM teardown; no users/fixtures remain. SHA256:
`0f2a451f35b07799a1fc29d6b8b6c842c9670f0ec6b76442d33a6cd0e86c3690`.

The primary guide updates these changed-source rows; protected search and the
other historical workloads retain their exact earlier images. No unchanged
nine-job rerun. The remaining whole-script objective and explicit debt decisions
continue independently of final regex adapter producer publication.

[All timings/controls/CPU](summary.json),[exact worker/image identity](identity.json),
[raw](observations.tgz),[collection/custody](collection-and-custody.tar.xz),
[previous guide](prior-BENCHMARKS.md).
''',encoding='utf-8',newline='\n')

q=Path('docs/BENCHMARKS.md');guide=q.read_text(encoding='utf-8')
replacements={
    '| CSV invoice / defensive pricing helper |':('| CSV invoice / ordinary pricing helper |4,096 records /127,031 B|',rows[invoice,'warm'],False),
    '| Text / captured helper and counter|':('| Text / captured helper and counter|3,072 lines /35,840 B|',rows[text,'warm'],True),
    '| CSV fulfillment / pricing and validation|':('| CSV fulfillment / pricing and validation|4,096 records /126,821 B|',rows[fulfill,'warm'],True),
}
lines=guide.splitlines()
for i,line in enumerate(lines):
    for prefix,(label,row,variable)in replacements.items():
        if line.startswith(prefix):lines[i]=label+timing(row,'candidate')+'|'+timing(row,'CPython')+'|'+ratio(row)+'|'+status(row,variable)+'|'
guide='\n'.join(lines)+'\n'
a=guide.index('Defensive invoice and file-search rows measured');b=guide.index('The96 B configuration row',a)
guide=guide[:a]+'''Invoice, fulfillment and captured-text rows measured2026-11-14UTC at
**4beb9ecf / frozenbed6e57e**, against stock **CPython3.13.16**.
[Full platform/stress/installed-consumer qualification passes](../benchmarks/results/2026-11-14-builtin-scalar-publication/delivery/README.md).
[Exact scripts, phases, raw CPU and controls](../benchmarks/results/2026-11-14-current-cpython-checkpoint/README.md).
Fulfillment varies2.53%between Lython processes; text4.46%. Those rows remain
variable. This is current source evidence, not a causal comparison across collections.
File search retains earlier **3994dfda / b5a6426e**, also2026-11-14 and fully
[qualified](../benchmarks/results/2026-11-14-protected-helper-activation/delivery/README.md);
[B757](../benchmarks/results/2026-11-14-protected-cpython-checkpoint/README.md) also
preserves its defensive-invoice source and phases. JSON/report/for-validator
retain earlier **fa40d674 / 73a1b233**; [qualified B747](../benchmarks/results/2026-11-14-range-cpython-checkpoint/README.md)
keeps their exact sources and every adverse/variable observation. These older
rows do not claim today's HEAD, and counter microbenchmarks do not predict them.
''' +guide[b:]
guide=guide.replace('The current defensive invoice and earlier96 B configuration sources separate\nfrontend cost from execution:', 'Current fulfillment and earlier defensive invoice/configuration sources separate\ncompilation from execution:')
needle='| --- | ---: | ---: | ---: | --- |\n'
phase=[]
for label,lane in [('Fulfillment compilation alone','compile'),('Fulfillment compile and execute once','compile-run')]:
    row=rows[fulfill,lane];phase.append('| '+label+' |'+timing(row,'candidate',lane=='compile')+'|'+timing(row,'CPython',lane=='compile')+'|'+ratio(row)+'|'+status(row)+'|')
section=guide.index('## Compilation, compile-to-result and startup')
insert=guide.index(needle,section)+len(needle)
guide=guide[:insert]+'\n'.join(phase)+'\n'+guide[insert:]
guide=guide.replace('|Diagnostic 3994; spreads','|Earlier3994; Diagnostic; spreads')
guide=guide.replace('Publication remains postponed.','').replace('observations.  \n','observations.\n')
q.write_text('\n'.join(line.rstrip()for line in guide.splitlines())+'\n',encoding='utf-8',newline='\n')
q=Path('benchmarks/EXPERIMENTS.md');q.write_text(q.read_text(encoding='utf-8')+'''
## R372 — coherent current CPython checkpoint

[B761](results/2026-11-14-current-cpython-checkpoint/README.md), qualified4beb/bed,
five jobs200.366s/all gates: ordinary invoice1.23×CPython; fulfillment1.15–1.19×warm,
1.19–1.20×fresh,1.11×compile; text1.46–1.53×with4.46%Lythonspread. Fulfillment warm
Lythonspread2.53%; keep both variable rows and every adverse/IQR/CPU observation.
Compile.128ms versus~8msexecution does not establish frontend dominance. Updated
guide keeps other workload rows at named older revisions. No cross-collection
attribution, R370debt erasure or embedding-latency claim. No new core/catalog upload;
one archived rawJSON duplicate deduplicates with exact custody proof/floors unchanged.
All users/RAMclosed; substantive performance/debt/regex objectives continue.
''',encoding='utf-8',newline='\n')
print('Current CPython guide/evidence updated; source-pair debt and variable rows retained.',flush=True)
