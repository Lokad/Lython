from pathlib import Path
import ast,hashlib,json,subprocess,tarfile

r=Path(__file__).parent;old=r.parent/'protected-activation-r368/b757';source=r.parent/'scalar-results-r370'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
frozen=json.loads((source/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(sha(n)==h for n,h in frozen['sources'].items())
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
core=frozen['coreSHA256']['candidate']
remote='/home/lokad/lython-bench-checks/current-cpython-b761-20261114';unit='lython-b761-current-cpython-20261114'
jobs=[['scripts.csv-fulfillment.large','warm'],['scripts.csv-fulfillment.large','compile'],['scripts.csv-fulfillment.large','compile-run'],['scripts.csv-invoice.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','warm']]
purpose='Coherent retained4beb/bed checkpoint after workspace and typed-result changes: refresh complete fulfillment warm/compile/fresh, ordinary invoice warm and text control versus stockCPython3.13.16. Existing worker/data; no unchanged nine-job rerun or source-pair causal attribution. Keep debt and every unstable/adverse control.'
identity=dict(sourceRevision=head+'/frozen'+core[:8],purpose=purpose,coreSHA256={role:core for role in ['reference','reference-control','candidate','candidate-control']},auxiliaryFiles=frozen['auxiliaryFiles'],catalogSHA256=sha(source/'catalog.json'),publicationHeld=True,fullSourceIdentitySHA256=sha(source/'candidate-identity.json'),committedSourceProofSHA256=sha(source/'delivery/source-proof.json'),runtimeCommit=head,qualification='43649993181 in progress independently; all582committed inputs match frozen source. Do not infer independent build binary identity.')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
    code=(old/name).read_text(encoding='utf-8').replace('protected-cpython-b757-20261114','current-cpython-b761-20261114').replace('lython-b757-protected-cpython-20261114',unit).replace('B757','B761')
    # Existing root names are verified below, not inferred from a filename.
    code=code.replace('protected-external-b757-20261114','current-cpython-b761-20261114')
    if name=='collect.py':
        a=code.index('jobs=');end=code.index('\nenv =',a);code=code[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==5 and all(case in cases for case,lane in jobs)\n'+code[end:]
        code=code.replace('started < 180','started < 240')
    elif name=='archive-owned.py':code=code.replace("len(raw['jobs'])==4","len(raw['jobs'])==5").replace('jobs=4','jobs=5')
    elif name=='retrieve.py':code=code.replace("['jobs']==4","['jobs']==5").replace("['elapsedSeconds']<240","['elapsedSeconds']<300").replace('four-job','five-job')
    elif name=='summarize.py':code=code.replace("len(raw['jobs'])==4","len(raw['jobs'])==5").replace('jobs=4','jobs=5')
    # Use the old config's actual root/unit, so all templates move consistently.
    prior=json.loads((old/'config.json').read_text(encoding='utf-8'))
    code=code.replace(prior['root'],remote).replace(prior['unit'],unit)
    assert 'b757'not in code.lower(),name
    if name.endswith('.py'):ast.parse(code)
    (r/name).write_text(code,encoding='utf-8',newline='\n')
(r/'prospective.json').write_text(json.dumps(dict(purpose=purpose,jobs=jobs,bound='One300sowner/240sstartguard,5phasejobs,2freshprocesses/engine/job,5sfullrequestwarmup/12stext,5rotating0.5sbatches. NormalGC/tiering/GIL; fixed images/workers/catalog/toolchains.',acceptance='All library/source/catalog/golden/files/budget, stockPython/GIL/GC, quiet/join/archive gates. Separate compilation/warm/fresh, includedI/O/validation/result and cache cleanup, widerCPU. Keep all controls/IQR/uncertainty.',stopping='One usable material changed-source external update or justified bounded correction; no broad framework/unchanged nine-job campaign. No source-pair attribution or performance forecast. FullCI independent; publicationheld.',storage='Hardlink currentbed/aux/catalog/worker. No new core/catalog upload. Deduplicate only one exact committed/verified prior rawJSON duplicate, retaining original compressed archive and Git/local bytes;254/252MiB floors unchanged.'),indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(r/'payload.tgz','w:gz')as t:
    for name in ['identity.json','prospective.json','collect.py','archive-owned.py','run.sh']:t.add(r/name,arcname=name)
with tarfile.open(r/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
config=dict(prior,root=remote,sourceRoot='/home/lokad/lython-bench-checks/scalar-results-b759-20261114',catalogRoot='/home/lokad/lython-bench-checks/scalar-results-b759-20261114',unit=unit,identity=identity,payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=sha(r/'payload.tgz'),unpackedBytes=unpacked)
code=(old/'launch-command.py').read_text(encoding='utf-8');a=code.index('config=');end=code.index('\nbase=',a);code=code[:a]+'config='+repr(config)+code[end:]
code=code.replace('lython-b757-fixtures','lython-b761-fixtures').replace('RuntimeMaxSec=240','RuntimeMaxSec=300')
code=code.replace('noRetirement=True,allCurrentImagesCatalogsAndToolchainPreserved=True','priorRawDeduplication="b761-proved-archived-json-deduplication.json",allCurrentImagesCatalogsAndToolchainPreserved=True')
ast.parse(code);(r/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
(r/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
dedup=(r.parent/'call-publication-r371/deduplicate-archived-json.py').read_text(encoding='utf-8')
a=dedup.index('for canonical,remote in ');end=dedup.index(':\n',a)
dedup=dedup[:a]+"for canonical,remote in [('benchmarks/results/2026-11-14-native-entry-admission/observations.tgz','native-entry-b758-20261114')]"+dedup[end:]
dedup=dedup.replace('b760-proved-archived-json-deduplication.json','b761-proved-archived-json-deduplication.json')
ast.parse(dedup);(r/'deduplicate-archived-json.py').write_text(dedup,encoding='utf-8',newline='\n')
print(json.dumps(dict(prepared=True,jobs=jobs,unpackedBytes=unpacked,core=core)),flush=True)
