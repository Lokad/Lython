from pathlib import Path
import subprocess
r=Path(__file__).parent
args=['C:/Users/JoannesVermorel/.dotnet11/dotnet.exe','test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f','net11.0','--filter','(FullyQualifiedName~CasedSplitOwnership|FullyQualifiedName~WordBufferLoan|FullyQualifiedName~WhitespaceStorageOwnership|FullyQualifiedName~WhitespaceSplitCancellation|FullyQualifiedName~PythonWhitespaceInventory)&Category!=Stress','--logger','trx','--results-directory',str(r/'initial-check')]
with(r/'initial-check.log').open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
print((r/'initial-check.log').read_text(encoding='utf-8')[-12000:],flush=True)
raise SystemExit(done.returncode)
