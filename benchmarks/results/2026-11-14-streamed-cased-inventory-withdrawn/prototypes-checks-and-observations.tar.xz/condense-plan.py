from pathlib import Path
import shutil
r=Path(__file__).parent;p=Path('PLAN.md');shutil.copyfile(p,r/'PLAN-history-before-condensing.md')
s=p.read_text(encoding='utf-8')
lines=s.splitlines()
obsolete=['| Previous fully qualified runtime |','| Preceding qualified runtime |','| Retained tests/evidence |','| Retained runtime candidate |']
s='\n'.join(line for line in lines if not any(line.startswith(prefix)for prefix in obsolete))+'\n'
anchor='| Current external comparison |'
row='| Active prototype | R348 frozen4311a053 removes private cased-word inventories; one changed production file.127internal/162public focused cases per actual11/10 pass (578total). Allocation effectively flat. Coarse first variant withdrawn for excessive working-set denial; exact preflight refinement retains baseline admission. B718 interrupted by unexplained service stop/restart; failed evidence archived, users joined/mount removed. One fresh same-bit B719 comparison is running,240swork/300sowner; earliest06:44:43UTC. No CPU gain/full qualification claimed. |\n'
s=s.replace(anchor,row+anchor)
anchor='## Prioritized deliverables'
completed='''- R338/R339/R341 native eligibility/final storage/shared integer arithmetic are
  fully delivered. R345/R346 builtin for/cursor changes and retained R343 tests now
  pass combined43563853239; all581inputs/16summaries are cached. R345 text CSV
  allocation−25.31%, warm−14.71..−20.25%, confirmed compile-to-result−17.84..−19.94%;
  list-input gains time with+4.24%allocation. R346list allocation−1.53%, elapsed
  −3.30..−5.20%, CPU−2.63..−4.58%; text allocation+0.69%/small CPU adversity and
  control uncertainty remain accepted debt. Original R345Windows CRLF failure
  43560252672 remains failed; corrected descendant delivery does not rewrite it.
  [R339](benchmarks/results/2026-11-14-native-owned-slots/delivery/README.md),
  [R341](benchmarks/results/2026-11-14-shared-integer-chains/delivery/README.md),
  [R345](benchmarks/results/2026-11-14-native-for-prefixes/README.md),
  [R346](benchmarks/results/2026-11-14-indexed-sequence-cursors/README.md).
- R342maps all168dictionary-loop IPs; mixed useful work does not prove a dominant
  removable packet. R343full-cased-buffer is withdrawn after CPU adversity/flat
  allocation; rollback fix/public semantics remain. Current profiles and earlier
  slower arenas/control records are evidence, not permanent bans. Full experimental
  history and prior plans remain separately archived.
  [R342](benchmarks/results/2026-11-14-captured-loop-attribution/README.md),
  [R343](benchmarks/results/2026-11-14-bulk-cased-buffer-withdrawn/README.md).

'''
s=s.replace(anchor,completed+anchor)
a=s.index('1. **Qualified baseline');b=s.index('   | Area |',a)
s=s[:a]+'''1. **Close R348 with a measured design decision.** Eliminate private cased-word
   range population/growth/copy/clear and count/index state, keeping ordinary split
   inventories where they have real callers. Reuse the existing scanner/writer,
   cursor loan, owners and compact-word transport; no new pool or execution backend.
   Coarse input-length admission is withdrawn:20,002B/two words asks1,360,136B and
   fails the existing1MiB working-set case. Preserve source/core and7failed/43passed
   checks. Refine to exact aggregate preflight and a second original-byte scan;
   delete coarse bound/remainder/refund machinery. Baseline eager admission, error
   order and retention remain; no complete cased buffer or extra casing stage.
   Focused semantics/cancellation/refusal/aliases/suspension/cache cleanup pass;
   the retirement fixture independently passes qualified8ae with actual idle reuse
   ended before its refund callback. No containment assertions/timeouts relaxed.
   Compare complete captured/direct text and fulfillment control, keeping allocation,
   elapsed/CPU and working set separate. B718's unexplained60sstop/restart supplies
   no complete jobs; raw/tools/journal are archived and RAM mount closed. B719 is
   one bounded same-bit correction, not an unchanged design retry. End with a
   retention/refinement/withdrawal and explicit debt decision; batch full delivery
   only if retained. No provisional inheritance from43563853239. Current images/
   catalogs/floors stay protected; superseded830links/two old catalogs were retired
   only after canonical Git/SHA/all-alias proof. Publication remains held.

2. **Select the next substantial redesign from owning evidence.** Text/search gaps
   remain material. Existing call-entry samples include useful live defaults,
   protection and binding; ordinary bound prefixes already defer contexts. Do not
   relabel delivered row adoption, shared keys, UTF8 formatting or final slots as
   new work. B717 is the current external checkpoint; no unchanged catalog replay.

'''+s[b:]
p.write_text(s,encoding='utf-8',newline='\n')
print('Condensed plan:',len(s.encode('utf-8')),'bytes; prior history preserved separately.')
