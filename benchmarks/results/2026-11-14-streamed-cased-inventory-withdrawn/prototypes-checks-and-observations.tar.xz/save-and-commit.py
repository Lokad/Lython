from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-14-streamed-cased-inventory-withdrawn');out.mkdir(exist_ok=False)
assert len(json.loads((r/'restored-checks.json').read_text(encoding='utf-8')))==2
assert all(x['returncode']==0 for x in json.loads((r/'restored-checks.json').read_text(encoding='utf-8')))
reference=json.loads((r/'reference-identity.json').read_text(encoding='utf-8'));assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in reference['sources'].items())
subprocess.run(['git','diff','--exit-code','009d236a','--','src'],check=True)
for source,target in [('decision.json','decision.json'),('candidate-identity.json','candidate-identity.json'),('b719/summary.json','timing-summary.json'),('b719/terminal-status.json','terminal-status.json'),('restoration.json','restoration.json'),('restored-checks.json','restored-checks.json'),('retirement-test-baseline-proof.json','retirement-test-baseline-proof.json')]:shutil.copyfile(r/source,out/target)
with tarfile.open(out/'prototypes-checks-and-observations.tar.xz','w:xz')as t:
 for p in sorted(r.rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(r)
  if rel.parts[0]in ['reference','candidate']or p.name in ['payload.tgz','retirement-test-original-core.dll']:continue
  t.add(p,arcname=rel.as_posix(),recursive=False)
with tarfile.open(out/'prototypes-checks-and-observations.tar.xz')as t:
 assert hashlib.sha256(t.extractfile('candidate-core.dll').read()).hexdigest()=='4311a05351160129dc52edcec033c1c511a3f3a7f7cf63a64f618a6f6725acae'
(out/'README.md').write_text('''# Private cased-word inventory removal — withdrawn

2026-11-14, R348: qualified `009d236a` / frozen `8ae1ae5f` versus prototype
`4311a053`. The first form admits a worst-case input-length bound, eliminating
the preparatory scan and inventory. It rejects a20,002B/two-word input under1MiB
(1,360,136B output estimate):7failed/43passed focused checks. This is an excessive
working-set tradeoff, not an observed containment escape. Original source/core
and failures survive; budgets and semantic assertions were not relaxed.

A bounded refinement deletes the coarse estimate/remainder/refund machinery.
It preflights exact eventual word capacities with the existing scanner, then
rescans immutable input during consumption. Private range writes/growth/copy/
clearing and count/index state disappear; ordinary split inventories retain real
callers.127internal/162public per actual .NET11/10 pass (578total), including
Unicode, admission before effects, cancellation, actual suspension, retained
aliases, cache shutdown and cleanup. Allocation is flat, about+8B/text job.

| Complete warm script | Elapsed candidate/reference change | Wider CPU change |
| --- | ---: | ---: |
| Captured text counter,3,072lines /35,840B | +3.39..+11.19% | +2.86..+10.67% |
| Same input, direct text loop | +7.97..+17.52% | +7.59..+17.78% |
| CSV fulfillment,4,096records /126,821B, control | −0.86..+1.43% | −0.99..+0.89% |

Ranges compare every fresh-process median pairing; positive means more/slower.
Captured process spreads are3.65%candidate/3.75%reference; direct3.99/4.31%,
control1.96/0.35%. Magnitude is diagnostic, but every affected pairing is adverse
with CPU support and no useful allocation reduction. Withdraw the refinement;
stored ranges are faster here. No unchanged retiming is required for this decision,
and it does not prohibit a materially different pipeline redesign.

B719 uses the quiet F4as_v7/Ubuntu24.04.4/.NET11RC3 VM, ordinary GC/tiering,
unchanged B685worker/optional0.4adapter and identical complete scripts/goldens.
Four fresh processes/job,12s complete-request warmup, five1s batches. Warm clocks
include mediated RAM I/O, output validation and prior-result cleanup; exclude
compilation/startup, reset/protocol and final cache shutdown. Wider CPU includes
reset/protocol. No CPython timing, heap peak or embedding-tail claim.
224.83s stays inside the300s owner; all image/output/budget/quiet/join/archive
gates pass, no workers or RAM fixtures remain. Raw SHA256:
`debba5afe1dca14637ce65991a6f324e2c84ea1a5cc2ffad3c1cea9d5d71358b`.

B718 was stopped and explicitly restarted after60s despite300sRuntimeMax,
Restart=no/NRestarts=0. Origin is unresolved. The restart refuses an existing
confirmation directory; no complete jobs supply comparison evidence. Configuration,
journal, partial data and recovery are preserved. Users join and the remaining
RAM mount is archived/verified before unmount. B719 is the justified fresh same-bit
measurement correction; the original uncertainty remains visible.

Before staging, only five aliases to superseded830core bytes and two superseded
catalog copies were retired after canonical Git/SHA/path/UID/all-alias proof.
Current images/evidence/floors stayed protected. Initial missing-root preflight
failed before deletion and is retained. No broader storage campaign or floor change.

All581production inputs are restored exactly to qualified009d. Forced
nonincremental Release rebuilds precede35focused checks per actual11/10, all pass.
The useful retirement regression remains: end idle reuse before arming an actual
refund callback, independent of buffer capacity. Its retry/alias/cleanup assertions
stay intact and also pass the exact frozen8ae baseline. No new runtime mechanism
remains and no unchanged full platform/package qualification is repeated.
The original full source qualification is [43563853239](../2026-11-14-indexed-sequence-cursors/delivery/README.md);
the test-only fixture adjustment remains focused-qualified pending a later batch.

[Decision](decision.json), [timing](timing-summary.json),
[complete source/core/tools/checks/failed conditions](prototypes-checks-and-observations.tar.xz).
Publication stays held; substantial complete-script work remains active.
''',encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');anchor='[R347 iteration CPython checkpoint]';s=s.replace(anchor,'''[R348 private cased-word inventory](results/2026-11-14-streamed-cased-inventory-withdrawn/README.md)
is withdrawn. Coarse admission rejects reasonable sparse text; exact-preflight
refinement passes578focused cases but adds a second source scan. Allocation is
flat while captured text elapsed worsens3–11% and direct text8–18%, with CPU
support and nearly neutral CSV control. B718interruption remains unresolved;
B719same-bit correction completes all gates. Exact qualified009d source is restored;
the independent retirement regression remains. No broader goal completion claimed.

'''+anchor,1);p.write_text(s,encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');a=s.index('| Active prototype |');b=s.index('\n| Current external comparison',a);s=s[:a]+'''| Latest withdrawn work | R348's coarse form rejects20KB/two words under1MiB; refined4311 removes inventories but is3–11%slower captured/8–18%direct with CPU support and flat allocation. B718interruption remains explicit uncertainty; B719same-bit correction passes all gates. All581qualified009d inputs restored exactly;35focused checks per actual11/10 pass after forced rebuild. Independent retirement fixture retained, full delivery deferred to a later batch. [Evidence](benchmarks/results/2026-11-14-streamed-cased-inventory-withdrawn/README.md). |'''+s[b:]
a=s.index('1. **Close R348');b=s.index('\n2. **Select the next',a);s=s[:a]+'''1. **R348 closed; advance a different representation.** Both inventory-removal
   forms are withdrawn: coarse headroom is unusable for sparse text; exact
   preflight/consuming rescans cost3–18%more time with CPU support and flat allocation.
   Preserve original failures and B718unexplained stop/restart; B719corrected
   measurement is complete. Qualified009dsource is restored, no VM users/mounts
   remain, and only the independent retirement test fixture stays changed.
   Do not select another unchanged range/full-cased-buffer rewrite or repeat full
   qualification of restored production. Continue the substantial source gate below.
   [Decision/evidence](benchmarks/results/2026-11-14-streamed-cased-inventory-withdrawn/README.md).
'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
assert not subprocess.check_output(['git','diff','--cached','--name-only'],text=True).strip()
subprocess.run(['git','add','--',str(out),'benchmarks/EXPERIMENTS.md','tests/Lokad.Lython.Tests/WordBufferLoanTests.cs'],check=True)
subprocess.run(['git','diff','--cached','--check'],check=True)
subprocess.run(['git','commit','-m','Retain inventory-removal evidence and independent retirement regression [skip ci]'],check=True)
subprocess.run(['git','push','origin','HEAD'],check=True,timeout=120)
print('R348 withdrawn and archived; production restored, test-only change committed. Goal remains active.',flush=True)
