# Lokad.Lython 0.11.0

Updated2026-11-14. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance,
including newly generated scripts. A green delivery or isolated experiment is a
checkpoint, not completion of this objective. Experimental history belongs in
[EXPERIMENTS](benchmarks/EXPERIMENTS.md), immutable results and saved plan history.

## Actual delivery status

| State | Evidence and limits |
| --- | --- |
| Latest fully qualified runtime | R346 009d236a/frozen8ae1ae5f removes separate exact-sequence CLR enumerators, sharing live indexed advancement.2,324focused actual11/10 cases pass. B716list allocation−1.53%, warm−3.30..−5.20%, wider CPU−2.63..−4.58%. Text allocation+0.69%/small CPU adversity and control uncertainty are explicit debt. GREEN43563853239: Windows/Ubuntu actual11/10, original stress and installed consumers.581inputs/16summaries cached, including fixture correction. [Delivery](benchmarks/results/2026-11-14-indexed-sequence-cursors/delivery/README.md). [Evidence](benchmarks/results/2026-11-14-indexed-sequence-cursors/README.md). |
| Active prototype | R348 frozen4311a053 removes private cased-word inventories; one changed production file.127internal/162public focused cases per actual11/10 pass (578total). Allocation effectively flat. Coarse first variant withdrawn for excessive working-set denial; exact preflight refinement retains baseline admission. B718 interrupted by unexplained service stop/restart; failed evidence archived, users joined/mount removed. One fresh same-bit B719 comparison is running,240swork/300sowner; earliest06:44:43UTC. No CPU gain/full qualification claimed. |
| Current external comparison | R347/B717runtime009d236a/frozen8ae1ae5f,2026-11-14, stockCPython3.13.16: invoice warm1.26–1.31×, compile1.08–1.10×, fresh1.21–1.24×; captured text1.48–1.59×, search1.66–1.76×, JSON0.83×, report1.19–1.21×, fulfillment1.30–1.31×, for-loop CSV1.28–1.29×. Invoice/search/text process spread3.47/4.05/6.57%remains uncertainty. Nine jobs finish360.55s; all source/image/golden/balance/quiet/join/archive gates pass. CI43563853239 passes full delivery. Config retains its qualifiedcdd/f4 source. No cross-collection attribution. [Boundaries/evidence](docs/BENCHMARKS.md). |
| Remaining uncertainty | Historical formatting15.125ms adversity remains unexplained; two controlled confirmations support retention. Original native-return elapsed is diagnostic. R334 XML cost, earlier report/search controls, R338invoice and R339small-helper controls remain explicit debt. Do not infer release-wide neutrality or add percentages across source pairs. |

## Completed foundations

- Shared compiler facts/nonlocal correction, annotation demand and lowered-tree
  retention cleanup are delivered. [Compiler evidence](benchmarks/results/2026-11-02-shared-compiler-facts/README.md).
- Direct UTF8 formatting/storage: original allocation−8.67%, later pair−8.59%;
  two controlled report CPU/elapsed blocks support−5..−8%on those sources. Keep
  original adverse clocks/failed conditions. [Evidence](benchmarks/results/2026-11-02-formatting-confirmation/README.md).
- Native helper returns: historical whole-run allocation−19.92%CSVhelpers and
  −19.31%JSONhelpers, separate from diagnostic elapsed. Corrected full delivery
  8f07764a complete. [Evidence](benchmarks/results/2026-11-02-native-function-returns/README.md).
- Revised bulk CSV already selectively revisited the6–8%opportunity and shipped
  admitted array adoption/shared keys. R308/R314 alternatives remain withdrawn
  with useful lifetime regressions retained. [Evidence](benchmarks/results/2026-11-02-native-csv-records/README.md).
- Calls share final slots/linear continuations/native prefixes across Run/RunAsync.
  Integer chains/counters avoid many boxes. Tuple transport, immutable builtin
  definitions, positional ZIP and native UTF8 JSON input are delivered. R335adds
  incremental XML/shared construction. Keep real suspension and stack handoff.
- Slower call-arena/control designs remain lessons. R325/R327 do not establish a
  dominant removable packet/frame; all46native-entry samples resolve against
  same-process Tier1 code. Default dictionary work is actual work. R338's initial
  frame-allocation explanation was corrected: ordinary bound prefixes already
  defer contexts. No large frame/storage removal is claimed for eligibility alone.
- R328exact frozen316 initial CI failure remains a historical failure. Descendant
  qualification does not rewrite it. All failed/adverse evidence survives.

- R338/R339/R341 native eligibility/final storage/shared integer arithmetic are
  fully delivered. R345/R346 builtin for/cursor changes and retained R343 tests now
  pass combined43563853239; all581inputs/16summaries are cached. R345 text CSV
  allocation−25.31%, warm−14.71..−20.25%, confirmed compile-to-result−17.84..−19.94%;
  list-input gains time with+4.24%allocation. R346list allocation−1.53%, elapsed
  −3.30..−5.20%, CPU−2.63..−4.58%; text allocation+0.69%/small CPU adversity and
  control uncertainty remain accepted debt. Original R345Windows CRLF failure
  43560252672 remains failed; corrected descendant delivery does not rewrite it.
  [R339](benchmarks/results/2026-11-14-native-owned-slots/delivery/README.md),
  [R341](benchmarks/results/2026-11-14-shared-integer-chains/delivery/README.md),
  [R345](benchmarks/results/2026-11-14-native-for-prefixes/README.md),
  [R346](benchmarks/results/2026-11-14-indexed-sequence-cursors/README.md).
- R342maps all168dictionary-loop IPs; mixed useful work does not prove a dominant
  removable packet. R343full-cased-buffer is withdrawn after CPU adversity/flat
  allocation; rollback fix/public semantics remain. Current profiles and earlier
  slower arenas/control records are evidence, not permanent bans. Full experimental
  history and prior plans remain separately archived.
  [R342](benchmarks/results/2026-11-14-captured-loop-attribution/README.md),
  [R343](benchmarks/results/2026-11-14-bulk-cased-buffer-withdrawn/README.md).

## Prioritized deliverables

1. **Close R348 with a measured design decision.** Eliminate private cased-word
   range population/growth/copy/clear and count/index state, keeping ordinary split
   inventories where they have real callers. Reuse the existing scanner/writer,
   cursor loan, owners and compact-word transport; no new pool or execution backend.
   Coarse input-length admission is withdrawn:20,002B/two words asks1,360,136B and
   fails the existing1MiB working-set case. Preserve source/core and7failed/43passed
   checks. Refine to exact aggregate preflight and a second original-byte scan;
   delete coarse bound/remainder/refund machinery. Baseline eager admission, error
   order and retention remain; no complete cased buffer or extra casing stage.
   Focused semantics/cancellation/refusal/aliases/suspension/cache cleanup pass;
   the retirement fixture independently passes qualified8ae with actual idle reuse
   ended before its refund callback. No containment assertions/timeouts relaxed.
   Compare complete captured/direct text and fulfillment control, keeping allocation,
   elapsed/CPU and working set separate. B718's unexplained60sstop/restart supplies
   no complete jobs; raw/tools/journal are archived and RAM mount closed. B719 is
   one bounded same-bit correction, not an unchanged design retry. End with a
   retention/refinement/withdrawal and explicit debt decision; batch full delivery
   only if retained. No provisional inheritance from43563853239. Current images/
   catalogs/floors stay protected; superseded830links/two old catalogs were retired
   only after canonical Git/SHA/all-alias proof. Publication remains held.

2. **Select the next substantial redesign from owning evidence.** Text/search gaps
   remain material. Existing call-entry samples include useful live defaults,
   protection and binding; ordinary bound prefixes already defer contexts. Do not
   relabel delivered row adoption, shared keys, UTF8 formatting or final slots as
   new work. B717 is the current external checkpoint; no unchanged catalog replay.

   | Area | Work/storage to eliminate; semantic acceptance and displacement |
   | --- | --- |
   | Complete calls/frames and operand transport | Existing final slots/native bound spans remove repackaging and unnecessary eligibility limits. Select a remaining full activation/storage stage only with owning evidence; remove its displaced route, no new arena/control backend. Preserve live defaults/receivers/closures, Python errors, pending transfers and awaited cleanup. Assess native iteration's remaining unsupported opcodes without assuming frame allocation. |
   | Per-record construction | CSV adopted/shared-key rows, native counters and iterative JSON are present; XML now avoids unused records. Next change must remove an actual representation/copy/pass in complete scripts and retire the constructor. Preserve mapping callbacks, mutation, aliases and admission-before-effect; do not relabel R308/R314. |
   | Scalar dispatch | Native integer chains/counter slots already reduce boxes. Object-valued operands remain. Establish remaining boxing/transport dominance before choosing a wider representation; exact promotion, identity and aliases are mandatory. A universal tagged-value VM is unselected. |
   | Bulk text conversion | ASCII casing/UTF8 word probes/direct formatting exist. Remove a remaining complete conversion/build stage, not isolated scalar tweaks. Preserve Unicode expansion/context, error order and actual callback suspension; delete superseded conversion code. |
   | Frontend analysis | Duplicate-name modeling accounted for only0.41–0.95%allocation on the studied source. Consolidate proven repeated facts/retained IR with diagnostics/scopes/nonlocals/cancellation and budget cleanup intact; multiple visitors alone do not prove dominance. |

   Before a selected prototype, record hypothesis, eliminated work/storage, affected
   complete scripts, semantic/cancellation/ownership acceptance, implementation to
   delete, bounded before/after/control comparison and regression-debt decision.
   Temporary setbacks are acceptable in a justified redesign with an explicit
   completion milestone. Stop an investigation once it can select or reject that
   bounded change; do not turn uncertainty into an open-ended audit.

3. **Regex develops independently.** Core owns Python-specific nativeUTF8/original
   windows/byte-scalar/capture/flag/error/current-token contract and existing owners/
   caches. Dev producers and adapter-local bridges remain permitted. Core has no
   backend edge. Completed dev80/15b248dc88internal/534public per11/10 checks are not
   rerun; normal29inputs/binaries/optional0.4nonpackable adapter remain unchanged.
   Read-only producer06ef69e4 (dev86 Core search changes) leaves all three public integration files byte-identical
   toae463cb4; immutable dev84 package834162df remains a separate identity. Missing capabilities: separate one-match work/result owners, native
   UTF8group-name enumeration/copy, token-independent cursor construction with
   cancellable preparation. Only affected final adapter qualification defers.
   Select the next concrete change from changed Lython code/contract or new producer
   capability; no sibling mutation/pin promotion or repeated unchanged qualification.
   [Assessment](benchmarks/results/2026-11-14-regex-provider-capabilities/README.md).
   Distinguish contract tests, semantics and real backend performance/safety.

## Evidence policy and lasting constraints

Separate simplification, allocation reduction and demonstrated CPU improvement.
Percentages inform decisions, not automatic vetoes. Timeouts, unstable unchanged
controls and inconclusive observations establish uncertainty. Permit bounded
confirmation/refinement/measurement correction for an explicit reason, retaining
original failed conditions and all adverse points. No blanket one-attempt,
no-retiming or permanently-closed rule.

Use focused Release correctness/cancellation/ownership checks during iteration;
batch Windows/Ubuntu actual11/10, original stress and installed Release consumers
at coherent checkpoints. Remain fully managed/memory-safe; no unsafe compilation/
C#/APIs, pointers, P/Invoke or native probing. Preserve managed stack admission,
host capabilities/original paths+Cwd, cancellation, cycles/XML depth, checked
representation bounds and bounded I/O chunks. No fuel/quotas, hidden caps/default
allowance, regex work/time policy, heap tracing, weak reclamation, forced GC or
abandoned users. Borrowed allowance funds capacity/overlap, aliases/results/caches
and pending users. First refusal is terminal through suppression/finally; preserve
its origin, await cleanup, never retry. Long streams use bounded host executions.
Force nonincremental builds after restoration; copy/verify frozen sources/bits and
auxiliary worker/adapter. Persist evidence, join users, preserve VM floors/current
images. Current docs stay concise/Lython-centric. See[AGENTS](AGENTS.md).
