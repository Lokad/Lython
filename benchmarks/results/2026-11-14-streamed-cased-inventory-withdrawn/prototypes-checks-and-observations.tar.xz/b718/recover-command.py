from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess,tarfile
r=Path('/home/lokad/lython-bench-checks/streamed-cased-b718-20261114');ram=r/'guest-fixtures'
receipt=r/'failed-closure.json';assert not receipt.exists()
with(r.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert (r/'exit-code.txt').read_text().strip()=='1'
 assert r.resolve()==r and ram.resolve()==ram and ram.is_dir()
 evidence={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest()for p in ram.rglob('*')if p.is_file()}
 archive=r/'failed-observations.tgz';assert not archive.exists()
 with tarfile.open(archive,'w:gz',dereference=True)as t:
  for p in sorted(r.rglob('*')):
   if not p.is_file()or p==archive or p.name in ['candidate-core.dll','reference-core.dll']or {'candidate','reference','__pycache__'}&set(p.relative_to(r).parts):continue
   assert p.resolve()==p and p.is_relative_to(r)and p.stat().st_uid==os.getuid()
   t.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
 with tarfile.open(archive)as t:
  assert not json.loads(t.extractfile('confirmation/confirmation.json').read())['complete']
  assert all(hashlib.sha256(t.extractfile(name).read()).hexdigest()==sha for name,sha in evidence.items())
 assert shutil.disk_usage(r).free>252*1024*1024
 subprocess.run(['sudo','-n','umount',str(ram)],check=True)
 assert not list(ram.iterdir());ram.rmdir()
 record=dict(originalServiceFailure=True,completePerformanceComparison=False,reason='Service stopped and explicitly restarted after60s despite300s RuntimeMax, Restart=no andNRestarts=0. Restart refuses existing confirmation directory. Stop/restart origin is unresolved; no source-pair conclusion.',allUsersJoined=True,ramEvidenceSHA256=evidence,persistentArchiveSHA256=hashlib.sha256(archive.read_bytes()).hexdigest(),archiveVerifiedBeforeUnmount=True,guestFixturesRemoved=True,freeBytes=shutil.disk_usage(r).free,sourceImagesPreserved=True)
 receipt.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
