from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).parent
code=r'''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess,tarfile
r=Path('/home/lokad/lython-bench-checks/streamed-cased-b718-20261114');ram=r/'guest-fixtures'
receipt=r/'failed-closure.json';assert not receipt.exists()
with(r.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert (r/'exit-code.txt').read_text().strip()=='1'
 assert r.resolve()==r and ram.resolve()==ram and ram.is_dir()
 evidence={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest()for p in ram.rglob('*')if p.is_file()}
 archive=r/'failed-observations.tgz';assert not archive.exists()
 with tarfile.open(archive,'w:gz',dereference=True)as t:
  for p in sorted(r.rglob('*')):
   if not p.is_file()or p==archive or p.name in ['candidate-core.dll','reference-core.dll']or {'candidate','reference','__pycache__'}&set(p.relative_to(r).parts):continue
   assert p.resolve()==p and p.is_relative_to(r)and p.stat().st_uid==os.getuid()
   t.add(p,arcname=p.relative_to(r).as_posix(),recursive=False)
 with tarfile.open(archive)as t:
  assert not json.loads(t.extractfile('confirmation/confirmation.json').read())['complete']
  assert all(hashlib.sha256(t.extractfile(name).read()).hexdigest()==sha for name,sha in evidence.items())
 assert shutil.disk_usage(r).free>252*1024*1024
 subprocess.run(['sudo','-n','umount',str(ram)],check=True)
 assert not list(ram.iterdir());ram.rmdir()
 record=dict(originalServiceFailure=True,completePerformanceComparison=False,reason='Service stopped and explicitly restarted after60s despite300s RuntimeMax, Restart=no andNRestarts=0. Restart refuses existing confirmation directory. Stop/restart origin is unresolved; no source-pair conclusion.',allUsersJoined=True,ramEvidenceSHA256=evidence,persistentArchiveSHA256=hashlib.sha256(archive.read_bytes()).hexdigest(),archiveVerifiedBeforeUnmount=True,guestFixturesRemoved=True,freeBytes=shutil.disk_usage(r).free,sourceImagesPreserved=True)
 receipt.write_text(json.dumps(record,indent=2)+'
');print(json.dumps(record))
'''
code=code.replace("+'\n');print", "+'\\n');print");compile(code,'recover','exec')
(r/'recover-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=40)
(r/'failed-recovery.log').write_text(done.stdout+done.stderr,encoding='utf-8',newline='\n');assert done.returncode==0,done.stderr
(r/'failed-closure.json').write_text(done.stdout,encoding='utf-8',newline='\n');receipt=json.loads(done.stdout)
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
done=subprocess.run(scp+['lokad@20.166.121.73:/home/lokad/lython-bench-checks/streamed-cased-b718-20261114/failed-observations.tgz',str(r/'failed-observations.tgz')],capture_output=True,text=True,encoding='utf-8',timeout=40);assert done.returncode==0,done.stderr
assert hashlib.sha256((r/'failed-observations.tgz').read_bytes()).hexdigest()==receipt['persistentArchiveSHA256']
print(json.dumps(receipt),flush=True)
