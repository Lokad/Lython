from pathlib import Path
import json,subprocess
r=Path(__file__).parent
script="""from pathlib import Path
import hashlib,json
r=Path('/home/lokad/lython-bench-checks/streamed-cased-b718-20261114')
names=['collection.log','run.sh','collect.py','space-preflight.json']
print(json.dumps({name:dict(sha256=hashlib.sha256((r/name).read_bytes()).hexdigest(),text=(r/name).read_text())for name in names},indent=2))
"""
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=script,text=True,encoding='utf-8',capture_output=True,timeout=30);assert done.returncode==0,done.stderr
(r/'failed-files.json').write_text(done.stdout,encoding='utf-8',newline='\n')
d=json.loads(done.stdout)
for name in ['collection.log','run.sh','space-preflight.json']:print(name,d[name]['text'],flush=True)
print('collect.py remote hash',d['collect.py']['sha256'])
