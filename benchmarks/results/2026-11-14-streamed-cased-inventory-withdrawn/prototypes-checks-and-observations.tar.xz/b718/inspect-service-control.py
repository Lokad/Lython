from pathlib import Path
import json,subprocess
r=Path(__file__).parent
code="""import json,subprocess
commands=[['systemctl','cat','lython-b718-streamed-cased-20261114.service'],['systemctl','show','lython-b718-streamed-cased-20261114.service','--property=Restart,NRestarts,RuntimeMaxUSec,FragmentPath,DropInPaths,TriggeredBy,WatchdogUSec,JobTimeoutUSec'],['journalctl','SYSLOG_IDENTIFIER=sudo','--since','2026-11-14 06:29:00 UTC','--until','2026-11-14 06:30:25 UTC','--no-pager','-n','35']]
print(json.dumps([dict(command=c,returncode=(d:=subprocess.run(c,text=True,capture_output=True)).returncode,stdout=d.stdout,stderr=d.stderr)for c in commands],indent=2))
"""
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=30);assert done.returncode==0,done.stderr
(r/'failed-service-control.json').write_text(done.stdout,encoding='utf-8',newline='\n')
for x in json.loads(done.stdout):print(x['command'],x['stdout'],x['stderr'])
