from pathlib import Path
import json,subprocess
r=Path(__file__).parent
code='''from pathlib import Path
import json,subprocess
r=Path('/home/lokad/lython-bench-checks/streamed-cased-b718-20261114')
print(json.dumps(dict(journal=subprocess.run(['journalctl','-u','lython-b718-streamed-cased-20261114.service','--no-pager','-n','45'],capture_output=True,text=True).stdout,files=[dict(path=str(p.relative_to(r)),size=p.stat().st_size)for p in r.rglob('*')if p.is_file()and not {'candidate','reference'}&set(p.relative_to(r).parts)],collectorTail=(r/'confirmation/confirmation.json').read_text()[-10000:]if(r/'confirmation/confirmation.json').exists()else None),indent=2))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=30)
(r/'failed-inspection.json').write_text(done.stdout,encoding='utf-8',newline='\n');assert done.returncode==0,done.stderr
d=json.loads(done.stdout);print(d['journal']);print('Files:',[(p['path'],p['size'])for p in d['files']]);print('Collector tail:',d['collectorTail'][-2000:]if d['collectorTail']else None)
