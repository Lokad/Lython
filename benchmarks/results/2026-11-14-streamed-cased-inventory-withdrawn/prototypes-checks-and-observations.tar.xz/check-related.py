from pathlib import Path
import json,shutil,subprocess
r=Path(__file__).parent
shutil.copyfile(r/'initial-check.log',r/'exact-preflight-original-fixture.log')
dotnet='C:/Users/JoannesVermorel/.dotnet11/dotnet.exe'
jobs=[('Lokad.Lython.Tests','(FullyQualifiedName~CasedSplit|FullyQualifiedName~WordBuffer|FullyQualifiedName~Whitespace|FullyQualifiedName~PythonWhitespace|FullyQualifiedName~DictionaryCounting|FullyQualifiedName~NativeFunction|FullyQualifiedName~SimpleFunctionExecutionBoundary|FullyQualifiedName~NativeClosure)&Category!=Stress'),('Lokad.Lython.PublicApi.Tests','(FullyQualifiedName~CasedSplit|FullyQualifiedName~BulkCased|FullyQualifiedName~ImmediateCased|FullyQualifiedName~DictionaryCounting|FullyQualifiedName~ComposedHelper|FullyQualifiedName~NativeClosure|FullyQualifiedName~ForHelper|FullyQualifiedName~WhileHelper|FullyQualifiedName~FunctionBinding|FullyQualifiedName~StringCase)&Category!=Stress')]
checks=[]
for framework in ['net11.0','net10.0']:
 with(r/('probe-build-'+framework+'.log')).open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([dotnet,'build','tools/LythonProbe/LythonProbe.csproj','-c','Release','-f',framework],stdout=f,stderr=subprocess.STDOUT)
 assert done.returncode==0
 for project,filter_ in jobs:
  label=project+'-'+framework
  with(r/(label+'.log')).open('w',encoding='utf-8',newline='\n')as f:
   done=subprocess.run([dotnet,'test',f'tests/{project}/{project}.csproj','-c','Release','-f',framework,'--filter',filter_,'--logger','trx','--results-directory',str(r/label)],stdout=f,stderr=subprocess.STDOUT)
  checks.append(dict(project=project,target=framework,returncode=done.returncode,filter=filter_))
  (r/'focused-checks.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8',newline='\n')
  print((r/(label+'.log')).read_text(encoding='utf-8')[-1800:],flush=True)
  assert done.returncode==0,label
