from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).parent;identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
output=Path('tests/Lokad.Lython.Tests/bin/Release/net11.0/Lokad.Lython.dll')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(output)==identity['coreSHA256']['candidate']
backup=r/'retirement-test-original-core.dll';shutil.copyfile(output,backup)
try:
 shutil.copyfile(r/'reference-core.dll',output);assert sha(output)==identity['coreSHA256']['reference']
 with(r/'retirement-test-on-baseline.log').open('w',encoding='utf-8',newline='\n')as f:
  done=subprocess.run(['C:/Users/JoannesVermorel/.dotnet11/dotnet.exe','test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f','net11.0','--no-build','--no-restore','--filter','FullyQualifiedName~FailedReentrantRetirementDoesNotDisposeTheNewBorrowerOnRetry','--logger','trx','--results-directory',str(r/'retirement-test-on-baseline')],stdout=f,stderr=subprocess.STDOUT)
 assert done.returncode==0,(r/'retirement-test-on-baseline.log').read_text(encoding='utf-8')
finally:
 shutil.copyfile(backup,output);assert sha(output)==identity['coreSHA256']['candidate']
(r/'retirement-test-baseline-proof.json').write_text(json.dumps(dict(baselineCoreSHA256=identity['coreSHA256']['reference'],candidateTestOutputCoreSHA256=identity['coreSHA256']['candidate'],independentReentrantRetirementCasePassed=True,originalTestOutputRestoredExactly=True,productionSourceUnchanged=True,onlyTestFixtureEndsReuseBeforeArmingActualRefund=True),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Retirement fixture also passes exact qualified8ae runtime; test output core restored exactly.',flush=True)
