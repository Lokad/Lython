from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;prior=r.parent/'native-for-r346';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
checks=json.loads((r/'focused-checks.json').read_text(encoding='utf-8'));assert len(checks)==4 and all(x['returncode']==0 for x in checks)
reference=json.loads((r/'reference-identity.json').read_text(encoding='utf-8'));sources={p:sha(p)for p in reference['sources']}
changed=[p for p in sources if sources[p]!=reference['sources'][p]]
assert changed==['src/Lokad.Lython/Runtime/Text/PyStringOps.Whitespace.cs'],changed
env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';'+env['PATH']
with(r/'candidate-build.log').open('w',encoding='utf-8',newline='\n')as f:
 done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-restore','--no-incremental','--disable-build-servers','-m:1'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
assert done.returncode==0,(r/'candidate-build.log').read_text(encoding='utf-8')[-3500:]
assert sources=={p:sha(p)for p in sources}
shutil.copytree(r/'reference',r/'candidate');shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'candidate/Lokad.Lython.dll');shutil.copyfile(r/'candidate/Lokad.Lython.dll',r/'candidate-core.dll')
identity=dict(headBeforeCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),referenceProductionCommit='009d236a',referenceQualification='CI43563853239: Ubuntu full passed, Windows ordinaryactual11/10 and installed consumers passed; Windows stress pending at freeze.',coreSHA256={role:sha(r/role/'Lokad.Lython.dll')for role in ['reference','candidate']},sources=sources,productionFiles=len(sources),changedProductionInputs=changed,removedMechanisms=['private cased-word range inventory population/growth/copy/clear','private inventory count/index state','coarse-bound prototype remainder/refund mechanism'],retained='Exact aggregate preflight and original ownership; a second original-subject scan replaces stored word ranges. Ordinary split range buffers keep their real callers.',auxiliaryFiles={role:{p.name:sha(p)for p in(r/role).iterdir()if p.is_file()and p.name!='Lokad.Lython.dll'}for role in ['reference','candidate']},qualified=False,sourceAndScriptDifferIntentionally=False)
assert identity['auxiliaryFiles']['reference']==identity['auxiliaryFiles']['candidate']and len(sources)==581
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as t:
 for name in sources:t.add(name,arcname=name)
shutil.copyfile(r.parent/'bulk-cased-buffer-r343/catalog.json',r/'catalog.json')
for role in ['reference','candidate']:(r/('allocation-'+role+'-catalog.json')).write_bytes((r/'catalog.json').read_bytes())
for name in ['verify-worker.py','measure-allocation.py']:shutil.copyfile(prior/name,r/name)
print('Frozen refined R348',identity['coreSHA256'],'581sources, one changed production file; copied worker/auxiliary bytes.',flush=True)
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'verify-worker.py')],check=True)
subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'measure-allocation.py')],check=True)
