from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
items=[{'canonicalCommit': '36d6cdcd', 'canonicalArchive': 'benchmarks/results/2026-11-14-native-cpython-checkpoint/observations.tgz', 'canonicalSHA256': '4f8b7cc929a5db73d07e4e40ca39c43996be5885e67fbc9ab78ff746110f3078', 'member': 'representative.json', 'relativePath': 'native-checkpoint-b710-20261114/representative.json', 'size': 1058534, 'sha256': '1a853d963ac108ad0476489553a24ec89ddb57ee53be4f0dda2a95d99341e430'}, {'canonicalCommit': '36d6cdcd', 'canonicalArchive': 'benchmarks/results/2026-11-14-native-for-prefixes/source-and-checks.tar.xz', 'canonicalSHA256': 'c34e26bd137a10b54e6e6cdebe2455b4f01d9b7fcffa46ec58b4f9d1c9d97fad', 'member': 'r345/catalog.json', 'relativePath': 'native-for-b714-20261114/representative.json', 'size': 357079, 'sha256': 'e6fe9eb74b83320d7b21a22d92bf050a9c8fa640961653f8b337ce3a96201130'}]
base=Path('/home/lokad/lython-bench-checks').resolve();receipt=base/'b719-proved-catalog-retirement-20261114.json';assert not receipt.exists()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 paths=[]
 for item in items:
  p=base/item['relativePath'];s=p.lstat()
  assert p.resolve()==p and p.is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_nlink==1
  assert s.st_size==item['size']and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
  assert not(p.parent/'guest-fixtures').exists()
  paths.append(p)
 before=shutil.disk_usage(base).free
 for p in paths:p.unlink()
 record=dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,retiredOnly=items,currentB717B718CatalogsAndImagesPreserved=True,canonicalCopiesVerified=True,floorsUnchanged=True)
 receipt.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
