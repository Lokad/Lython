from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).parent;items=[]
for path,member,remote in [
 ('benchmarks/results/2026-11-14-native-cpython-checkpoint/observations.tgz','representative.json','native-checkpoint-b710-20261114/representative.json'),
 ('benchmarks/results/2026-11-14-native-for-prefixes/source-and-checks.tar.xz','r345/catalog.json','native-for-b714-20261114/representative.json')]:
 p=Path(path);committed=subprocess.check_output(['git','show','36d6cdcd:'+path]);assert hashlib.sha256(committed).digest()==hashlib.sha256(p.read_bytes()).digest()
 with tarfile.open(p)as t:payload=t.extractfile(member).read()
 items.append(dict(canonicalCommit='36d6cdcd',canonicalArchive=path,canonicalSHA256=hashlib.sha256(committed).hexdigest(),member=member,relativePath=remote,size=len(payload),sha256=hashlib.sha256(payload).hexdigest()))
(r/'catalog-retirement-proof.json').write_text(json.dumps(items,indent=2)+'\n',encoding='utf-8',newline='\n')
code=r'''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
items=ITEMS
base=Path('/home/lokad/lython-bench-checks').resolve();receipt=base/'b719-proved-catalog-retirement-20261114.json';assert not receipt.exists()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 paths=[]
 for item in items:
  p=base/item['relativePath'];s=p.lstat()
  assert p.resolve()==p and p.is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_nlink==1
  assert s.st_size==item['size']and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
  assert not(p.parent/'guest-fixtures').exists()
  paths.append(p)
 before=shutil.disk_usage(base).free
 for p in paths:p.unlink()
 record=dict(beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free,retiredOnly=items,currentB717B718CatalogsAndImagesPreserved=True,canonicalCopiesVerified=True,floorsUnchanged=True)
 receipt.write_text(json.dumps(record,indent=2)+'
');print(json.dumps(record))
'''.replace('ITEMS',repr(items));code=code.replace("+'\n');print", "+'\\n');print");compile(code,'retire','exec')
(r/'catalog-retirement-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=30)
(r/'catalog-retirement.log').write_text(done.stdout+done.stderr,encoding='utf-8',newline='\n');assert done.returncode==0,done.stderr
(r/'catalog-retirement-receipt.json').write_text(done.stdout,encoding='utf-8',newline='\n');print(done.stdout)
