from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
proof={'canonicalCommit': '009d236a', 'canonicalArchive': 'benchmarks/results/2026-11-14-indexed-sequence-cursors/sources-checks-and-observations.tar.xz', 'archiveSHA256': '43a660f68d0ea492b657a691ca06ae6820293319c9a9d855a80b4d18731c7a87', 'member': 'reference-core.dll', 'retiredCoreSHA256': '8306699f6ad07d4688cd84bd36b6aa878f5eeb39871005d9346b475cf056067f', 'retiredCoreBytes': 5739008, 'reason': 'Superseded R345830 working cores only. Full009d/8ae delivery43563853239 now green; current B716/B7178ae images and local frozen references stay protected.', 'sourceOfAuthorization': 'Owned benchmark working storage, immutable source/core evidence retained; no publication or sibling mutation.'}
base=Path('/home/lokad/lython-bench-checks').resolve();receipt=base/'b718-proved-core-retirement-20261114.json'
assert not receipt.exists()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 roots=['native-for-b714-20261114','native-for-b715-20261114','indexed-cursor-b716-20261114','iteration-checkpoint-b717-20261114']
 # Confirm the fixed B715 root from its known completed collection; no directory scan.
 assert all((base/n).is_dir()and(base/n).resolve()==base/n and not(base/n/'guest-fixtures').exists()for n in roots)
 assert all((base/n/'exit-code.txt').read_text().strip()=='0'for n in roots)
 paths=[base/'native-for-b714-20261114/candidate-core.dll',base/'native-for-b714-20261114/candidate/Lokad.Lython.dll',base/'native-for-b715-20261114/candidate/Lokad.Lython.dll',base/'indexed-cursor-b716-20261114/reference-core.dll',base/'indexed-cursor-b716-20261114/reference/Lokad.Lython.dll']
 original=[]
 for p in paths:
  s=p.lstat();assert p.resolve()==p and p.is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()
  assert s.st_size==proof['retiredCoreBytes']and hashlib.sha256(p.read_bytes()).hexdigest()==proof['retiredCoreSHA256']
  original.append(dict(path=str(p),inode=s.st_ino,device=s.st_dev,links=s.st_nlink,size=s.st_size,sha256=proof['retiredCoreSHA256']))
 assert len({(x['device'],x['inode'])for x in original})==1
 assert all(x['links']==len(paths)for x in original), original
 before=shutil.disk_usage(base).free
 for p in paths:p.unlink()
 after=shutil.disk_usage(base).free;assert after>before
 record=dict(proof=proof,freshIdleLease=True,allAliasesProved=True,retiredOnly=original,beforeFreeBytes=before,afterFreeBytes=after,current8aeImagesAndToolchainPreserved=True,canonicalEvidencePreserved=True,floorsUnchanged=True)
 receipt.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
