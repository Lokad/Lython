from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent;prior=r.parent/'native-for-r346/b716';out=r/'b718';out.mkdir(exist_ok=False)
source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));aux=json.loads((prior/'identity.json').read_text(encoding='utf-8'))['candidateAuxiliaryFiles']
assert all(source['auxiliaryFiles'][role][name]==sha for role in ['reference','candidate']for name,sha in aux.items())
identity=dict(sourceRevision='R348frozen4311a053 vs qualified009d236a/frozen8ae1ae5f',purpose='Remove private cased-word inventory while preserving exact eager preflight and reusing the forward scanner for consumption. Identical captured/direct text and fulfillment control; no CPython or frontend replay.',coreSHA256={label:source['coreSHA256']['candidate'if label.startswith('candidate')else'reference']for label in ['reference','candidate','reference-control','candidate-control']},candidateAuxiliaryFiles=aux,referenceAuxiliaryFiles=aux,catalogSHA256=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest(),referenceCase='scripts.text-summary-helpers.nonlocal-counter.large',variantCase='scripts.text-summary-helpers.nonlocal-counter.large',controlCases=['scripts.csv-fulfillment.large'],sourceAndScriptDifferIntentionally=False)
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.text-summary.inline.large','warm'],['scripts.csv-fulfillment.large','warm']]
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py','launch.py']:
 s=(prior/name).read_text(encoding='utf-8').replace('indexed-cursor-b716-20261114','streamed-cased-b718-20261114').replace('lython-b716-indexed-cursor-20261114','lython-b718-streamed-cased-20261114').replace('B716','B718')
 if name=='collect.py':
  a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==3 and all(case in cases for case,lane in jobs)\n'+s[b:]
 if name.endswith('.py'):ast.parse(s)
 (out/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
 for name in ['identity.json','collect.py','archive-owned.py','run.sh']:t.add(out/name,arcname=name)
 for name,arc in [('catalog.json','representative.json'),('candidate-core.dll','candidate-core.dll'),('candidate-identity.json','source-identity.json'),('reference-identity.json','reference-source-identity.json')]:t.add(r/name,arcname=arc)
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
config=dict(root='/home/lokad/lython-bench-checks/streamed-cased-b718-20261114',sourceRoot='/home/lokad/lython-bench-checks/iteration-checkpoint-b717-20261114',unit='lython-b718-streamed-cased-20261114',identity=identity,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
print('B718 prepared:',unpacked,'staging bytes. Need fresh idle/floor proof before launch.')
