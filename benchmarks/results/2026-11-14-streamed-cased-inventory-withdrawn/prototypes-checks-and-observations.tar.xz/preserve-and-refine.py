from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;v=r/'coarse-bound-refused';v.mkdir(exist_ok=False)
path=Path('src/Lokad.Lython/Runtime/Text/PyStringOps.Whitespace.cs')
shutil.copyfile(path,v/path.name);shutil.copyfile(r/'initial-check.log',v/'initial-check.log');shutil.copytree(r/'initial-check',v/'initial-check')
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',v/'prototype-core.dll')
result=dict(state='withdraw coarse input-length admission before timing',failed=7,passed=43,problem='N=20,002 bytes /2words estimates1,360,136 output bytes and fails a1MiB allowance before the intended semantic/cancellation/refusal checks. One additional failure is an obsolete exact refund assertion caused by the new unused-headroom return; tests were not altered.',producerCoreSHA256=hashlib.sha256((v/'prototype-core.dll').read_bytes()).hexdigest(),changedSourceSHA256=hashlib.sha256(path.read_bytes()).hexdigest(),runtimeSafety='Managed compilation succeeds. No unsupported storage was published; the issue is unusable conservative headroom, not a proven containment escape.',refinement='Validate/count exact per-word capacity in the shared forward scanner, without a range inventory. Consume via the same scanner a second time. Retain all eventual word charges like the baseline; delete the coarse bound/remainder/refund mechanism instead of wrapping it. Earlier representation/error order and prior memory thresholds remain. This does not claim CPU benefit; compare the added scan with removed inventory work.',noTiming=True,noVmStarted=True,testsUnchanged=True)
(v/'decision.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');a=s.index('   **Active R348:');b=s.index('   | Area |',a)
s=s[:a]+'''   **Active R348 refinement: remove private cased-word inventory.** Coarse
   input-length admission is withdrawn before timing:20,002B/two words asks for
   1,360,136B and rejects the existing1MiB reasonable-working-set regression.
   Preserve its source/core and7failed/43passed focused cases; no test relaxation.
   Refine to an exact aggregate preflight using the existing forward scanner,
   then scan original UTF8 again during consumption. Remove private range writes,
   growth/copy/clear and count/index state; preserve the preparatory validation
   scan and ordinary split inventories. Delete the coarse estimate/remainder/refund
   machinery. Baseline eager word admission, retention and error ordering remain.
   No whole-cased buffer/extra casing stage; slower R343 remains evidence.
   The extra scan can cost CPU; compare complete captured/direct text and CSV
   control, with allocation and working-set checks separate. Stop with a measured
   retention/refinement/withdrawal and debt decision; no new pool/ledger/engine.
   Full009d delivery is independent and does not qualify this prototype.

'''+s[b:];p.write_text(s,encoding='utf-8',newline='\n')
print('Initial variant archived, tests unchanged; refinement recorded before mutation.')
