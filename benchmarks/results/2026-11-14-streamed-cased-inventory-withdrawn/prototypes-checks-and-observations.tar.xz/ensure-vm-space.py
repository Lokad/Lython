from pathlib import Path
import base64,hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent
if (r/'retirement.log').exists() and not (r/'retirement-receipt.json').exists():
 failed=r/'retirement-preflight-missing-root';failed.mkdir(exist_ok=False)
 for name in ['retirement.log','retirement-command.py','retirement-proof.json']:shutil.copyfile(r/name,failed/name)
canonical=Path('benchmarks/results/2026-11-14-indexed-sequence-cursors/sources-checks-and-observations.tar.xz')
committed=subprocess.check_output(['git','show','009d236a:'+canonical.as_posix()]);assert hashlib.sha256(committed).hexdigest()==hashlib.sha256(canonical.read_bytes()).hexdigest()
with tarfile.open(canonical)as t:old=t.extractfile('reference-core.dll').read()
proof=dict(canonicalCommit='009d236a',canonicalArchive=canonical.as_posix(),archiveSHA256=hashlib.sha256(committed).hexdigest(),member='reference-core.dll',retiredCoreSHA256=hashlib.sha256(old).hexdigest(),retiredCoreBytes=len(old),reason='Superseded R345830 working cores only. Full009d/8ae delivery43563853239 now green; current B716/B7178ae images and local frozen references stay protected.',sourceOfAuthorization='Owned benchmark working storage, immutable source/core evidence retained; no publication or sibling mutation.')
assert proof['retiredCoreSHA256']=='8306699f6ad07d4688cd84bd36b6aa878f5eeb39871005d9346b475cf056067f'
(r/'retirement-proof.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
code=r'''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
proof=PROOF
base=Path('/home/lokad/lython-bench-checks').resolve();receipt=base/'b718-proved-core-retirement-20261114.json'
assert not receipt.exists()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 roots=['native-for-b714-20261114','native-for-b715-20261114','indexed-cursor-b716-20261114','iteration-checkpoint-b717-20261114']
 # Confirm the fixed B715 root from its known completed collection; no directory scan.
 assert all((base/n).is_dir()and(base/n).resolve()==base/n and not(base/n/'guest-fixtures').exists()for n in roots)
 assert all((base/n/'exit-code.txt').read_text().strip()=='0'for n in roots)
 paths=[base/'native-for-b714-20261114/candidate-core.dll',base/'native-for-b714-20261114/candidate/Lokad.Lython.dll',base/'native-for-b715-20261114/candidate/Lokad.Lython.dll',base/'indexed-cursor-b716-20261114/reference-core.dll',base/'indexed-cursor-b716-20261114/reference/Lokad.Lython.dll']
 original=[]
 for p in paths:
  s=p.lstat();assert p.resolve()==p and p.is_relative_to(base)and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()
  assert s.st_size==proof['retiredCoreBytes']and hashlib.sha256(p.read_bytes()).hexdigest()==proof['retiredCoreSHA256']
  original.append(dict(path=str(p),inode=s.st_ino,device=s.st_dev,links=s.st_nlink,size=s.st_size,sha256=proof['retiredCoreSHA256']))
 assert len({(x['device'],x['inode'])for x in original})==1
 assert all(x['links']==len(paths)for x in original), original
 before=shutil.disk_usage(base).free
 for p in paths:p.unlink()
 after=shutil.disk_usage(base).free;assert after>before
 record=dict(proof=proof,freshIdleLease=True,allAliasesProved=True,retiredOnly=original,beforeFreeBytes=before,afterFreeBytes=after,current8aeImagesAndToolchainPreserved=True,canonicalEvidencePreserved=True,floorsUnchanged=True)
 receipt.write_text(json.dumps(record,indent=2)+'
');print(json.dumps(record))
'''.replace('PROOF',repr(proof))
# Keep the remote literal a Python newline escape after the raw outer string.
code=code.replace("+'\n');print", "+'\\n');print")
compile(code,'retirement-command','exec')
(r/'retirement-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=45)
(r/'retirement.log').write_text(done.stdout+done.stderr,encoding='utf-8',newline='\n');assert done.returncode==0,done.stderr
(r/'retirement-receipt.json').write_text(done.stdout,encoding='utf-8',newline='\n')
print(done.stdout,flush=True)
