from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).parent;prior=r.parent/'native-for-r346';identity=json.loads((prior/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in identity['sources'].items())
shutil.copytree(prior/'candidate',r/'reference')
for src,dst in [('candidate-core.dll','reference-core.dll'),('candidate-sources.tar.xz','reference-sources.tar.xz'),('candidate-identity.json','reference-identity.json')]:shutil.copyfile(prior/src,r/dst)
record=dict(date='2026-11-14',sourceCommit='009d236a',coreSHA256=identity['coreSHA256']['candidate'],status='selected bounded prototype; not implemented or measured',hypothesis='Private immediate cased-word iteration can replace its complete preparatory scan and per-word range inventory with one coarse output admission followed by the existing forward scanner at consumption. R342 preparation94/963leaf samples motivates this stage but does not predict its removable CPU share.',removed=['private iteration CollectWhitespaceForward/AppendSplitRange walk','private per-word inventory writes/growth/copy/clear','private count/position over the inventory'],retained=['ordinary split/rsplit range buffers and existing loan cache, because they still have real callers','same UTF8 scanner/case writer and compact-word transport','same owner, current-token polls, immutable source borrow and awaited cleanup'],contract='Before first loop effects reserve checked conservative total word headers plus maximum case-byte output from input length. Actual produced words keep independent existing execution-owner funding. A single aggregate unused-output remainder belongs to the cursor and returns at its actual end, never refunding yielded or logically consumed values. Earlier refusal for sparse/long text is explicit; there is no hidden allowance, per-object ledger or GC. Inputs whose worst-case case width cannot fit the representation need a validation-only scan before effects, preserving supported large split inputs and error ordering.',risks=['single long/sparse input can require much greater transient headroom; bound and report it','one extra root refund per cursor can offset removed scan work','no extension of the earlier slower whole-cased-buffer design: no complete-buffer casing/resizing/rescanning'],acceptance=['Python whitespace/Unicode expansion/final-sigma/long-word/split-direction behavior remains exact','same eager admission before body effects, first refusal terminal and current cancellation during long scanning/casing','retained aliases and suspended users stay funded; early exit refunds only unused conservative output; cache shutdown/reentry remains correct','representative line-driven text remains usable under a reasonable bounded shared budget; no cumulative worst-case counting'],comparison='Reuse complete captured and ordinary3072-line text plus unchanged CSV control; same frozen worker/goldens, separate short allocation and one bounded quiet-VM source pair. Record input/output admission high water independently of physical allocation. No unchanged CPython or full delivery replay.',stopping='Retain/refine/withdraw after focused semantics/ownership and complete-workload comparison. Explicitly decide remaining transient-headroom or CPU debt; no fixed percentage veto or new pool/VM/control layer.')
(r/'prospective.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('PLAN.md');shutil.copyfile(p,r/'PLAN-before-prototype.md');s=p.read_text(encoding='utf-8')
needle='   **Next selection gate:**';a=s.index(needle);b=s.index('   | Area |',a)
s=s[:a]+'''   **Active R348: remove private cased-word preflight/inventory.** Current text
   remains1.48–1.59×CPython, with unstable processes. R342 preparation94/963leaves
   motivates a complete stage, not a predicted removable percentage. Prototype one
   coarse output admission and one consuming UTF8 scan, using the current scanner,
   writer, cursor loan and owners. Delete private preparatory range collection,
   growth/copy/clear; keep ordinary split inventories where they have real callers.
   No whole-cased buffer or extra case/output scan; slower R343 remains evidence.
   Contract tradeoff: earlier refusal for sparse/long text. Track a cursor-owned
   aggregate unused bound and refund it only when actual users end; produced/aliased
   words stay funded. Guard representation/error order for exceptionally large
   inputs without imposing another string cap. Measure transient headroom and the
   extra refund lock, preserving cancellation, eager refusal, suspension and cache
   cleanup. Focus existing whitespace/case/loan/histogram regressions, then complete
   captured/direct text and CSV control with separate allocation and CPU evidence.
   Stop with retention/refinement/withdrawal and a debt decision; no new pool,
   ownership ledger, tracing or unconditional full qualification. Full009d delivery
   remains independent; the prototype will not inherit its qualification.

'''+s[b:]
p.write_text(s,encoding='utf-8',newline='\n')
print('R348 selected, contracts/tradeoffs recorded; immutable009d/8ae reference copied.')
