from pathlib import Path
import ast,base64,datetime,hashlib,json,subprocess,tarfile
r=Path(__file__).parent;prior=r/'b718';out=r/'b719';out.mkdir(exist_ok=False)
assert json.loads((prior/'failed-closure.json').read_text(encoding='utf-8'))['guestFixturesRemoved']
identity=json.loads((prior/'identity.json').read_text(encoding='utf-8'))
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=(prior/name).read_text(encoding='utf-8').replace('streamed-cased-b718-20261114','streamed-cased-b719-20261114').replace('lython-b718-streamed-cased-20261114','lython-b719-streamed-cased-20261114').replace('B718','B719')
 if name.endswith('.py'):ast.parse(s)
 (out/name).write_text(s,encoding='utf-8',newline='\n')
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'reason.json').write_text(json.dumps(dict(reason='B718 interrupted by an unexplained stop/restart after60s, with no complete jobs. All failed evidence persists and mounts are closed. One bounded fresh comparison uses identical frozen4311/8ae, workers, catalog, normal tiering/GC and12s warmups/five1s rounds. This is measurement correction, not evidence of a failed runtime design.',workSeconds=240,ownerSeconds=300,stopSeconds=30,noRepeatedCorrectnessOrQualification=True),indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
 for name in ['collect.py','archive-owned.py','run.sh','identity.json']:t.add(out/name,arcname=name)
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
config=dict(root='/home/lokad/lython-bench-checks/streamed-cased-b719-20261114',sourceRoot='/home/lokad/lython-bench-checks/streamed-cased-b718-20261114',unit='lython-b719-streamed-cased-20261114',identity=identity,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
code=r'''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
config=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();source=Path(config['sourceRoot']);root=Path(config['root']);digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert source.parent==base and source.resolve()==source and root.parent==base and not root.exists()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert json.loads((source/'failed-closure.json').read_text())['guestFixturesRemoved']and not(source/'guest-fixtures').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 for role in ['reference','candidate']:
  assert digest(source/role/'Lokad.Lython.dll')==config['identity']['coreSHA256'][role]
  for name,sha in config['identity'][role+'AuxiliaryFiles'].items():assert digest(source/role/name)==sha
 assert digest(source/'representative.json')==config['identity']['catalogSHA256']
 payload=sys.stdin.buffer.read(config['payloadBytes']+1);assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 before=shutil.disk_usage(base).free;assert before>254*1024*1024+config['unpackedBytes']
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as t:
  assert set(t.getnames())=={'collect.py','archive-owned.py','run.sh','identity.json'};t.extractall(root,filter='data')
 for name in ['representative.json','cpython-worker.py','source-identity.json','reference-source-identity.json']:os.link(source/name,root/name)
 for role in ['reference','candidate']:
  (root/role).mkdir()
  for name in [*config['identity'][role+'AuxiliaryFiles'],'Lokad.Lython.dll']:os.link(source/role/name,root/role/name)
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 after=shutil.disk_usage(base).free;assert after>254*1024*1024
 (root/'space-preflight.json').write_text(json.dumps(dict(beforeFreeBytes=before,afterFreeBytes=after,freshIdleLease=True,onlyFrozenImageHardlinks=True,floorsUnchanged=True))+'
')
 fixture=root/'guest-fixtures';fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b719-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=300','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True))
'''.replace('CONFIG',repr(config));code=code.replace("+'\n')", "+'\\n')");ast.parse(code)
(out/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
done=subprocess.run(ssh+[command],input=(out/'payload.tgz').read_bytes(),capture_output=True,timeout=45)
(out/'launch.log').write_bytes(done.stdout+done.stderr);assert done.returncode==0,(done.stdout+done.stderr).decode()
now=datetime.datetime.now(datetime.timezone.utc)
(out/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=240)).isoformat(),ownerSeconds=300,stopSeconds=30),indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8').replace('B718 is running:240swork/300sowner, earliest observation06:33:12UTC.', 'B718 is inconclusive: unexplained stop/restart after60s; no complete jobs.\n   Failed source/tools/journal/partial data are archived and the RAM mount closed.\n   One fresh B719 comparison uses identical4311/8ae images/conditions;240swork/300sowner,\n   earliest observation'+(now+datetime.timedelta(seconds=240)).strftime('%H:%M:%S')+'UTC. Only two superseded catalogs\n   were retired after canonical Git/SHA proof; current images/catalogs remain.');p.write_text(s,encoding='utf-8',newline='\n')
print((done.stdout+done.stderr).decode(),flush=True);print('Observe after',(now+datetime.timedelta(seconds=240)).isoformat(),flush=True)
