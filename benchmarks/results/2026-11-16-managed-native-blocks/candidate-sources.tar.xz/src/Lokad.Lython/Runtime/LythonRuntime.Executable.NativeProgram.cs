using System.Linq.Expressions;
using System.Reflection;
using System.Runtime.CompilerServices;
using Lokad.Lython.Frontend;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal delegate bool NativeProgram(ref NativeExecution execution, out ExecutableSlot result);

    // Preparation belongs to the existing code owner, never the first caller.
    // Only ordinary immutable code metadata is captured by the completed delegate.
    internal static NativeProgram? CompileNativeProgram(ExecutableCodeObject code,
        MemoryGovernor? governor, CancellationToken cancellationToken)
    {
        for (var index = 0; index < code.NativePrefixEnd; index++)
        {
            PythonTokenization.CheckCancellation(cancellationToken, 0);
            if (NativeHandler(code.Instructions[index].OpCode) is null && !HandlerOnly(index)) return null;
        }
        if (!RuntimeFeature.IsDynamicCodeSupported || !RuntimeFeature.IsDynamicCodeCompiled)
            throw new NotSupportedException("Native block preparation requires managed dynamic code compilation.");

        // Deliberate headroom for expression nodes, compiler work and retained
        // delegate/native-code metadata. Logical ownership does not assert that
        // the CLR physically reclaims code as soon as its owner relinquishes it.
        var retained = checked(32768L + 1024L * code.NativePrefixEnd);
        var scratch = checked(16384L + 2048L * code.NativePrefixEnd);
        var span = code.Instructions[code.EntryIndex].Span;
        using var storage = governor?.ReserveTemporary(checked(retained + scratch), span);
        governor?.ThrowIfAdmissionFailed();
        PythonTokenization.CheckCancellation(cancellationToken, 0);

        var state = Expression.Parameter(typeof(NativeExecution).MakeByRefType(), "state");
        var result = Expression.Parameter(typeof(ExecutableSlot).MakeByRefType(), "result");
        var condition = Expression.Variable(typeof(bool), "condition");
        var finish = Expression.Label(typeof(bool), "finished");
        var labels = new LabelTarget[code.NativePrefixEnd];
        for (var i = 0; i < labels.Length; i++) labels[i] = Expression.Label("instruction" + i);
        var expressions = new List<Expression>(checked(labels.Length * 4 + 4))
        {
            Expression.Assign(result, Expression.Constant(ExecutableSlot.FromObject(PyNone.Instance))),
            Go(code.EntryIndex)
        };
        var indexField = Expression.Field(state, nameof(NativeExecution.Index));
        for (var i = 0; i < labels.Length; i++)
        {
            PythonTokenization.CheckCancellation(cancellationToken, 0);
            ref readonly var instruction = ref code.Instructions[i];
            expressions.Add(Expression.Label(labels[i]));
            expressions.Add(Invoke(nameof(NativeExecution.BlockEnter), i));
            var handler = NativeHandler(instruction.OpCode);
            if (handler is null)
            {
                // Handler-only instructions have no valid native entry. A bad
                // branch must expose a compiler defect, not select another engine.
                expressions.Add(Fault("Unexpected inline opcode: " + instruction.OpCode));
                continue;
            }
            var next = i + (instruction.HasLocalResult ? 2 : 1);
            switch (instruction.OpCode)
            {
                case ExecutableOpCode.Complete:
                case ExecutableOpCode.ReturnNone:
                    expressions.Add(Expression.Return(finish, Invoke(handler, i)));
                    break;
                case ExecutableOpCode.Return:
                    expressions.Add(Expression.Return(finish, Invoke(handler, i, result)));
                    break;
                case ExecutableOpCode.Jump:
                case ExecutableOpCode.AbruptJump:
                    expressions.Add(Require(Invoke(handler, i)));
                    expressions.Add(Go(instruction.TargetIndex));
                    break;
                case ExecutableOpCode.CompareJumpIfFalse:
                case ExecutableOpCode.JumpIfFalse:
                    expressions.Add(Require(Invoke(handler, i, condition)));
                    expressions.Add(Expression.IfThenElse(condition, Go(i + 1), Go(instruction.TargetIndex)));
                    break;
                case ExecutableOpCode.ForNext:
                    expressions.Add(Invoke(handler, i, condition));
                    expressions.Add(Expression.IfThenElse(condition, Go(next), Go(instruction.TargetIndex)));
                    break;
                case ExecutableOpCode.MakeTuple:
                    expressions.Add(Invoke(handler, i, condition));
                    expressions.Add(Expression.IfThen(condition, Expression.Return(finish, Expression.Constant(true))));
                    expressions.Add(Go(next));
                    break;
                case ExecutableOpCode.Call:
                case ExecutableOpCode.LoadClosure:
                case ExecutableOpCode.Binary:
                case ExecutableOpCode.Augmented:
                    expressions.Add(Require(Invoke(handler, i)));
                    expressions.Add(Advance(i, instruction));
                    break;
                default:
                    expressions.Add(Require(Invoke(handler, i)));
                    expressions.Add(Go(next));
                    break;
            }
        }
        expressions.Add(Expression.Label(finish, Expression.Constant(false)));
        // This framework call is synchronous. Checks before/after are not a
        // claim of cooperative interruption inside framework compilation/JIT.
        var program = Expression.Lambda<NativeProgram>(Expression.Block([condition], expressions), state, result).Compile();
        governor?.ThrowIfAdmissionFailed();
        PythonTokenization.CheckCancellation(cancellationToken, 0);
        storage?.Commit(retained);
        return program;

        bool HandlerOnly(int index)
        {
            foreach (var region in code.ExceptionRegions)
                if (region.ExceptIndex is not null && index >= region.SuiteStartIndex && index <= region.SuiteEndIndex) return true;
            return false;
        }

        Expression Invoke(string name, int index, params Expression[] outputs)
            => Expression.Call(state, typeof(NativeExecution).GetMethod(name, BindingFlags.Instance | BindingFlags.NonPublic)!,
                new Expression[] { Expression.Constant(index) }.Concat(outputs));

        Expression Require(Expression eligible)
            => Expression.IfThen(Expression.Not(eligible), Expression.Return(finish, Expression.Constant(false)));

        Expression Go(int target)
        {
            if ((uint)target < (uint)labels.Length) return Expression.Goto(labels[target]);
            return Expression.Block(Expression.Assign(Expression.Field(state, nameof(NativeExecution.Index)), Expression.Constant(target)),
                Expression.Return(finish, Expression.Constant(target >= code.Instructions.Length)));
        }

        Expression Advance(int index, in ExecutableInstruction instruction)
        {
            var positions = new HashSet<int> { index + (instruction.HasLocalResult ? 1 : 0) };
            if (instruction.OpCode == ExecutableOpCode.LoadClosure && instruction.HasClosureArithmetic) positions.Add(index + 2);
            if (instruction.OpCode == ExecutableOpCode.Call && index + 2 < code.Instructions.Length
                && code.CallSites[instruction.CallSiteIndex].CasedSplit is { } recipe
                && code.Instructions[index + 2].OpCode == ExecutableOpCode.Call
                && ReferenceEquals(recipe, code.CallSites[code.Instructions[index + 2].CallSiteIndex].CasedSplit))
            {
                ref readonly var last = ref code.Instructions[index + 2];
                positions.Add(index + 2 + (last.HasLocalResult ? 1 : 0));
            }
            if (instruction.OpCode == ExecutableOpCode.Binary && !instruction.HasLocalResult)
            {
                var end = index;
                while (end + 1 < code.Instructions.Length && ContinuesIntegerChain(code, code.Instructions[end + 1], instruction.ResultSlot))
                {
                    end++;
                    if (code.Instructions[end].HasLocalResult) break;
                }
                positions.Add(end + (code.Instructions[end].HasLocalResult ? 1 : 0));
            }
            if (positions.Count == 1) return Go(positions.Single() + 1);
            return Expression.Switch(indexField, Fault("Unexpected compiled native successor."),
                positions.Select(position => Expression.SwitchCase(Go(position + 1), Expression.Constant(position))).ToArray());
        }

        static Expression Fault(string message)
            => Expression.Throw(Expression.New(typeof(InvalidOperationException).GetConstructor([typeof(string)])!, Expression.Constant(message)));
    }

    // One preparation inventory serves eligibility and emission. There is no
    // second runtime opcode router or separately maintained frontend whitelist.
    private static string? NativeHandler(ExecutableOpCode code) => code switch
    {
        ExecutableOpCode.Complete or ExecutableOpCode.ReturnNone => nameof(NativeExecution.BlockComplete),
        ExecutableOpCode.Return => nameof(NativeExecution.BlockReturn),
        ExecutableOpCode.LoadConst => nameof(NativeExecution.BlockLoadConst),
        ExecutableOpCode.LoadLocal => nameof(NativeExecution.BlockLoadLocal),
        ExecutableOpCode.LoadGlobal => nameof(NativeExecution.BlockLoadGlobal),
        ExecutableOpCode.LoadClosure => nameof(NativeExecution.BlockLoadClosure),
        ExecutableOpCode.StoreClosure => nameof(NativeExecution.BlockStoreClosure),
        ExecutableOpCode.StoreLocal => nameof(NativeExecution.BlockStoreLocal),
        ExecutableOpCode.LoadCallMember => nameof(NativeExecution.BlockLoadCallMember),
        ExecutableOpCode.Call => nameof(NativeExecution.BlockCall),
        ExecutableOpCode.Subscript => nameof(NativeExecution.BlockSubscript),
        ExecutableOpCode.Binary or ExecutableOpCode.Augmented or ExecutableOpCode.Unary => nameof(NativeExecution.BlockArithmetic),
        ExecutableOpCode.CompareJumpIfFalse => nameof(NativeExecution.BlockCompare),
        ExecutableOpCode.JumpIfFalse => nameof(NativeExecution.BlockTruth),
        ExecutableOpCode.Jump => nameof(NativeExecution.BlockJump),
        ExecutableOpCode.AbruptJump => nameof(NativeExecution.BlockAbruptJump),
        ExecutableOpCode.GetIter => nameof(NativeExecution.BlockGetIter),
        ExecutableOpCode.ForNext => nameof(NativeExecution.BlockForNext),
        ExecutableOpCode.MakeTuple => nameof(NativeExecution.BlockMakeTuple),
        ExecutableOpCode.MakeList => nameof(NativeExecution.BlockMakeList),
        ExecutableOpCode.StartFormattedString or ExecutableOpCode.AppendFormattedText or ExecutableOpCode.FinishFormattedString
            or ExecutableOpCode.ConvertFormattedValue or ExecutableOpCode.FormatField => nameof(NativeExecution.BlockFormat),
        ExecutableOpCode.Dup => nameof(NativeExecution.BlockDup),
        ExecutableOpCode.PopTop => nameof(NativeExecution.BlockPop),
        _ => null
    };
}
