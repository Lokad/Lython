using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal ref partial struct NativeExecution
    {
        internal void BlockEnter(int position)
        {
            Index = position;
            _scope.State.CheckExecution(Code.Instructions[position].Span);
        }

        internal bool BlockComplete(int position)
        {
            if (Code.NativePrefixEnd != Code.Instructions.Length) return false;
            Trim(Code.FirstTemporarySlot);
            return true;
        }

        internal bool BlockReturn(int position, out ExecutableSlot result)
        {
            result = ExecutableSlot.FromObject(PyNone.Instance);
            if (Code.NativePrefixEnd != Code.Instructions.Length) return false;
            ref readonly var instruction = ref Code.Instructions[position];
            result = ReadReturnSlot(instruction.InputStart);
            if (instruction.InputStart >= Code.FirstTemporarySlot) Values[instruction.InputStart].Object = null!;
            Trim(Code.FirstTemporarySlot);
            return true;
        }

        internal bool BlockLoadConst(int position)
        {
            ref readonly var instruction = ref Code.Instructions[position];
            Publish(instruction, RuntimeValue(Code.Constants[instruction.ConstantIndex]));
            return true;
        }

        internal bool BlockLoadLocal(int position)
        {
            ref readonly var instruction = ref Code.Instructions[position];
            Publish(instruction, Read(instruction.LocalSlot, 0));
            return true;
        }

        internal bool BlockLoadGlobal(int position)
        {
            ref readonly var instruction = ref Code.Instructions[position];
            Publish(instruction, ResolveExecutableGlobal(Code.Names[instruction.NameIndex], instruction.Span, _scope));
            return true;
        }

        internal bool BlockLoadClosure(int position)
        {
            ref readonly var instruction = ref Code.Instructions[position];
            if (TryExecuteClosureArithmetic(Code, _cells, Index, LiveExtent, _scope))
            { Index += 2; return true; }
            if (!TryCell(instruction.ClosureSlot, out var cell) || cell.Value is not { } captured) return false;
            Publish(instruction, captured);
            return true;
        }

        internal bool BlockStoreClosure(int position)
        {
            ref readonly var instruction = ref Code.Instructions[position];
            if (!TryCell(instruction.ClosureSlot, out var cell) || !cell.CanStoreThroughOwner) return false;
            cell.Value = Take(instruction);
            return true;
        }

        internal bool BlockStoreLocal(int position)
        {
            ref readonly var instruction = ref Code.Instructions[position];
            Values[instruction.LocalSlot].Object = Take(instruction);
            return true;
        }

        internal bool BlockLoadCallMember(int position)
        {
            ref readonly var instruction = ref Code.Instructions[position];
            var receiver = Read(instruction.InputStart, 0);
            var name = Code.Names[instruction.NameIndex];
            var method = receiver is PyString ? StringMembers.GetMethod(name)
                : receiver is PyDict ? DictMembers.GetMethod(name) : null;
            if (method is null) return false;
            Put(instruction.ResultSlot, instruction.ResultSlot + 1, receiver);
            Put(instruction.ResultSlot + 1, instruction.LiveExtent, method);
            return true;
        }

        internal bool BlockCall(int position) => Call(Code.Instructions[position]);

        internal bool BlockSubscript(int position)
        {
            ref readonly var instruction = ref Code.Instructions[position];
            var target = Read(instruction.InputStart, 0);
            if (TryReadMachineOperand(Code, Values, instruction.SecondInput, out var index)
                && PyIndexing.TryReadSequenceIndex(target, index, instruction.Span, _scope, out var item))
            {
                Publish(instruction, item);
                return true;
            }
            var key = Read(instruction.SecondInput, 1);
            if (target is not PyDict { HasProtocolKeys: false } dictionary || key is not PyString field) return false;
            if (instruction.LookupCacheIndex >= 0 && dictionary.HasSharedRecordKeys)
            {
                var caches = _function.GetLookupCaches(instruction.Span);
                if (dictionary.TryReadRecordValue(field, ref caches[instruction.LookupCacheIndex], _scope,
                    instruction.Span, out var cached))
                { Publish(instruction, cached); return true; }
            }
            if (dictionary.HasProtocolKeys) return false;
            Publish(instruction, ReadSubscriptValue(dictionary, field, instruction.Span, _scope));
            return true;
        }

        internal bool BlockArithmetic(int position)
        {
            ref readonly var instruction = ref Code.Instructions[position];
            if (instruction.OpCode is ExecutableOpCode.Binary or ExecutableOpCode.Augmented && TryIntegerOperation()) return true;
            if (!TryEvaluateBuiltinArithmetic(Code, Values, Index, _scope, out var arithmetic)) return false;
            Publish(instruction, arithmetic);
            return true;
        }

        internal bool BlockCompare(int position, out bool truth)
        {
            ref readonly var instruction = ref Code.Instructions[position];
            if (!TryIntegerComparison(instruction, out truth))
            {
                var first = Read(instruction.InputStart, 0);
                var second = Read(instruction.SecondInput, 1);
                if (!TryEvaluateScalarComparison(instruction.BinaryOperator, first, second, _scope, instruction.Span, out truth)) return false;
            }
            Trim(instruction.LiveExtent);
            _scope.CheckExecution(instruction.Span);
            return true;
        }

        internal bool BlockTruth(int position, out bool truth)
        {
            truth = false;
            ref readonly var instruction = ref Code.Instructions[position];
            var value = Read(instruction.InputStart, 0);
            if (!CanUseNativeTruth(value)) return false;
            _ = Take(instruction);
            truth = IsTruthy(value, _scope, instruction.Span);
            return true;
        }

        internal bool BlockJump(int position)
        {
            Index = Code.Instructions[position].TargetIndex;
            return true;
        }

        internal bool BlockAbruptJump(int position)
        {
            // Transfer before the ordinary frame retires protected inputs.
            if (Code.NativePrefixEnd != Code.Instructions.Length) return false;
            ref readonly var instruction = ref Code.Instructions[position];
            if (instruction.DiscardIterator) Trim(LiveExtent - 1);
            Index = instruction.TargetIndex;
            return true;
        }

        internal bool BlockGetIter(int position)
        {
            ref readonly var instruction = ref Code.Instructions[position];
            var source = Read(instruction.InputStart, 0);
            if (source is PyStringOps.CasedWhitespaceIteration) Publish(instruction, source);
            else if (source is PyList or PyTuple or PyRange or PyBytes or PyString or PyDict or PySet)
                Publish(instruction, PyIteration.Cursor.Create(source, instruction.Span, _scope));
            else return false;
            return true;
        }

        internal void BlockForNext(int position, out bool hasValue)
        {
            ref readonly var instruction = ref Code.Instructions[position];
            var iterator = Values[instruction.InputStart].Object.RequireNotNull();
            var next = iterator is PyStringOps.CasedWhitespaceIteration words ? words.MoveNext()
                : ((PyIteration.Cursor)iterator).TryMoveNext();
            hasValue = next.HasValue;
            if (!hasValue)
            {
                Trim(instruction.InputStart);
                Index = instruction.TargetIndex;
            }
            else Publish(instruction, next.TakeSlotValue());
        }

        internal void BlockMakeTuple(int position, out bool returned)
        {
            ref readonly var instruction = ref Code.Instructions[position];
            returned = TryReturnUnpackedTuple(instruction);
            if (returned) return;
            var tuple = instruction.ItemCount == 0 ? PyTuple.Empty
                : CreateSlotTuple(Values.Slice(instruction.InputStart, instruction.ItemCount), _scope, instruction.Span);
            Trim(instruction.InputStart);
            Publish(instruction, tuple);
        }

        internal bool BlockMakeList(int position)
        {
            ref readonly var instruction = ref Code.Instructions[position];
            var list = CreateSlotList(Values.Slice(instruction.InputStart, instruction.ItemCount), _scope, instruction.Span);
            Trim(instruction.InputStart);
            Publish(instruction, list);
            return true;
        }

        internal bool BlockFormat(int position) => Format(Code.Instructions[position]);

        internal bool BlockDup(int position)
        {
            ref readonly var instruction = ref Code.Instructions[position];
            Put(instruction.ResultSlot + 1, instruction.LiveExtent, Read(instruction.InputStart, 0));
            return true;
        }

        internal bool BlockPop(int position)
        {
            ref readonly var instruction = ref Code.Instructions[position];
            _ = Read(instruction.InputStart, 0);
            Trim(instruction.LiveExtent);
            return true;
        }
    }
}
