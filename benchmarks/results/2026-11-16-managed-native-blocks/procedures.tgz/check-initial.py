from pathlib import Path
import os,subprocess
repo=Path('D:/code/Lython');r=Path(__file__).resolve().parent;w=repo/'.git/agent-worktrees/native-blocks-r456';dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe')
env=os.environ.copy();env['DOTNET_ROOT']=str(dotnet.parent);env['DOTNET_ROOT_X64']=str(dotnet.parent);env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
jobs=[('initial','Lokad.Lython.Tests',['NativeIntegerChainTests','SimpleFunctionExecutionBoundaryTests']),
 ('internal','Lokad.Lython.Tests',['PreparedFunctionExecutionTests','NativeClosureSequenceTests','ComposedNativeCallTests','NativeTupleReturnTests','NativeFunctionRefundTests','ExecutableFunctionInvocationBoundaryTests','OrdinaryFunctionTransportTests','FunctionDefaultConstructionTests','FunctionClassCellBoundaryTests','NativeTruthEntryTests','NativeUnaryReentryTests','NativeTextConstructionRollbackTests']),
 ('public','Lokad.Lython.PublicApi.Tests',['FramedFunctionExecutionTests','ProtectedHelperExecutionTests','FrameIntegerLifetimeTests','AsyncFunctionHostingTests','FunctionSlotBindingTests','FunctionBindingLifetimeTests','FunctionDefaultMetadataTests','FunctionStringAdmissionTests'])]
for label,project,classes in jobs:
 log=r/f'{label}-net11.log';assert not log.exists()
 command=[str(dotnet),'test',str(w/'tests'/project/(project+'.csproj')),'-c','Release','-f','net11.0','--filter','|'.join('FullyQualifiedName~.'+name+'.'for name in classes),'--logger',f'trx;LogFileName={label}-net11.trx','--results-directory',str(r)]
 with log.open('w',encoding='utf-8')as f:p=subprocess.run(command,cwd=w,env=env,stdout=f,stderr=subprocess.STDOUT)
 print(label,log.read_text(encoding='utf-8')[-2500:],flush=True)
 if p.returncode:raise SystemExit(p.returncode)
