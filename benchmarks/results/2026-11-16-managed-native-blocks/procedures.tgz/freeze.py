from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
repo=Path('D:/code/Lython');w=repo/'.git/agent-worktrees/native-blocks-r456';r=Path(__file__).resolve().parent;old=r.parent/'bulk-replacement-r455/refined';f=r/'frozen';f.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert '0 Error(s)'in(r/'nonincremental-measured-core.log').read_text(encoding='utf-8')
oldIdentity=json.loads((old/'frozen/identity.json').read_text(encoding='utf-8'))
with tarfile.open(old/'candidate-sources.tar.xz')as a:
 production=[m for m in a.getmembers()if m.isfile()and m.name.startswith('src/Lokad.Lython/')];assert len(production)==585
 for m in production:
  baseline=a.extractfile(m).read();current=(repo/m.name).read_bytes();assert baseline==current or baseline.decode('utf-8-sig').replace('\r\n','\n')==current.decode('utf-8-sig').replace('\r\n','\n'),m.name
for role in ['reference','candidate']:
 (f/role).mkdir()
 for n,h in oldIdentity['imageFiles']['candidate'].items():
  p=old/'frozen/candidate'/n;assert sha(p)==h;shutil.copy2(p,f/role/n)
core=w/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'
for project in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:assert sha(w/'tests'/project/'bin/Release/net11.0/Lokad.Lython.dll')==sha(core),project
shutil.copy2(core,f/'candidate/Lokad.Lython.dll')
paths=subprocess.check_output(['git','ls-files','src','tests','Directory.Build.props','Directory.Build.targets','Directory.Packages.props','NuGet.Config','global.json','Lokad.Lython.slnx'],cwd=w,text=True,encoding='utf-8').splitlines()
inputs={p:sha(w/p)for p in paths};production={p:h for p,h in inputs.items()if p.startswith('src/Lokad.Lython/')};assert len(production)==587 and len(inputs)==2373
images={role:{p.name:sha(p)for p in(f/role).iterdir()}for role in ['reference','candidate']};assert[n for n in images['reference']if images['reference'][n]!=images['candidate'][n]]==['Lokad.Lython.dll']
shutil.copy2(old/'catalog.json',r/'catalog.json')
identity=dict(referenceSource='Fully qualified9e8d1cf5/e92d9598; GREEN43950899310. Rootd1468043 has identical production text.',candidateSource='PrivateR456 at9e8d1cf5 plus archived complete managed native blocks; old switch/whitelist removed; corrected recipe successor; no hypothetical target guard',imageFiles=images,sourceInputs=inputs,productionFiles=len(production),catalogSHA256=sha(r/'catalog.json'),normalAdapterPin='0.4.0',focusedStatus=json.loads((r/'focused-status.json').read_text(encoding='utf-8')),fullQualification=False,publicationHeld=True)
(f/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as a:
 for p in paths:a.add(w/p,arcname=p)
(r/'prototype.patch').write_bytes(subprocess.check_output(['git','diff','--','src','tests'],cwd=w))
print(json.dumps(dict(candidateCore=sha(core),productionFiles=len(production),allInputs=len(inputs),onlyCoreDiffers=True,qualificationIncomplete=True)))
