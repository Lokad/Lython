from pathlib import Path
import re
w=Path('D:/code/Lython/.git/agent-worktrees/native-blocks-r456')
def edit(name,transform):
 p=w/name;s=p.read_text(encoding='utf-8-sig');t=transform(s);assert t!=s,name;p.write_text(t,encoding='utf-8',newline='\n')
def lowering(s):
 s='using Lokad.Lython.Runtime;\n\n'+s
 s=s.replace('Lower(ScriptSyntax syntax)','Lower(ScriptSyntax syntax, MemoryGovernor? governor = null, CancellationToken cancellationToken = default)')
 s=s.replace('statements, bool classScope = false)','statements, bool classScope = false, MemoryGovernor? governor = null, CancellationToken cancellationToken = default)')
 s=s.replace('LowerStatement(StatementSyntax statement, bool classScope)','LowerStatement(StatementSyntax statement, bool classScope, MemoryGovernor? governor, CancellationToken cancellationToken)')
 s=s.replace('LowerStatement(statement, classScope)','LowerStatement(statement, classScope, governor, cancellationToken)')
 s=s.replace('CompileClassFunction(function)','CompileClassFunction(function, governor, cancellationToken)')
 s=re.sub(r'LowerStatements\(([\w.]+)(, classScope(?:: true)?)?\)',lambda m:'LowerStatements('+m[1]+(m[2]or'')+', governor: governor, cancellationToken: cancellationToken)',s)
 return s
edit('src/Lokad.Lython/Frontend/LoweredScript.cs',lowering)
def builder(s):
 s=s.replace('Compile(LoweredScript lowered)','Compile(LoweredScript lowered, MemoryGovernor? governor = null, CancellationToken cancellationToken = default)')
 s=s.replace('completeLexicalParent: true)','completeLexicalParent: true, governor: governor, cancellationToken: cancellationToken)')
 s=s.replace('CompileNamespaceLambda(lambda);','CompileNamespaceLambda(lambda, governor, cancellationToken);')
 s=s.replace('true, GeneratorFacts(generator))','true, GeneratorFacts(generator), governor, cancellationToken)')
 s=s.replace('CompileNamespaceLambda(LoweredLambdaExpression lambda)','CompileNamespaceLambda(LoweredLambdaExpression lambda, MemoryGovernor? governor, CancellationToken cancellationToken)')
 s=s.replace('lambda.IsGenerator, lambda.ScopeFacts)','lambda.IsGenerator, lambda.ScopeFacts, governor, cancellationToken)')
 s=s.replace('CompileClassFunction(LoweredFunctionDefinitionStatement function)','CompileClassFunction(LoweredFunctionDefinitionStatement function, MemoryGovernor? governor = null, CancellationToken cancellationToken = default)')
 s=s.replace('function.Syntax.IsGenerator, function.ScopeFacts)','function.Syntax.IsGenerator, function.ScopeFacts, governor, cancellationToken)')
 s=s.replace('private readonly FunctionParameterLayout? _parameterLayout;','private readonly FunctionParameterLayout? _parameterLayout;\n        private readonly MemoryGovernor? _governor;\n        private readonly CancellationToken _cancellationToken;')
 s=s.replace('bool generator, ScopeDirectiveFacts scopeFacts)\n            : this(parameterLayout, null, scopeFacts)', 'bool generator, ScopeDirectiveFacts scopeFacts, MemoryGovernor? governor = null, CancellationToken cancellationToken = default)\n            : this(parameterLayout, null, scopeFacts, governor: governor, cancellationToken: cancellationToken)')
 s=s.replace('bool completeLexicalParent = false)','bool completeLexicalParent = false, MemoryGovernor? governor = null, CancellationToken cancellationToken = default)')
 s=s.replace('_scopeFacts = scopeFacts;', '_scopeFacts = scopeFacts;\n            _governor = governor;\n            _cancellationToken = cancellationToken;')
 s=s.replace('initialOperandDepth: generatorExpression is null ? 0 : 1);','initialOperandDepth: generatorExpression is null ? 0 : 1,\n                governor: _governor, cancellationToken: _cancellationToken);')
 return s
edit('src/Lokad.Lython/Frontend/ExecutableScript.Builder.cs',builder)
edit('src/Lokad.Lython/Frontend/ExecutableScript.Infrastructure.cs',lambda s:s.replace('completeLexicalParent: _completeLexicalParent && typeParameters is not { Count: > 0 })','completeLexicalParent: _completeLexicalParent && typeParameters is not { Count: > 0 },\n                governor: _governor, cancellationToken: _cancellationToken)'))
edit('src/Lokad.Lython/Frontend/ExecutableScript.Comprehensions.cs',lambda s:s.replace('completeLexicalParent: _completeLexicalParent)', 'completeLexicalParent: _completeLexicalParent, governor: _governor, cancellationToken: _cancellationToken)'))
def code(s):
 s=s.replace('int initialOperandDepth)\n', 'int initialOperandDepth, MemoryGovernor? governor = null, CancellationToken cancellationToken = default)\n')
 old='CanRunNativeInstructions = IsFunctionScope && !RequiresLocalVariableMirroring && capturedLocalSlots.Count == 0\n            && EntryIndex < NativePrefixEnd\n            && SupportsNativeInstructions();';assert old in s
 s=s.replace(old,'NativeProgram = IsFunctionScope && !RequiresLocalVariableMirroring && capturedLocalSlots.Count == 0\n            && EntryIndex < NativePrefixEnd\n            ? LythonRuntime.CompileNativeProgram(this, governor, cancellationToken) : null;')
 s=s.replace('public bool CanRunNativeInstructions { get; }','public bool CanRunNativeInstructions => NativeProgram is not null;\n\n    public LythonRuntime.NativeProgram? NativeProgram { get; }')
 a=s.index('    private bool SupportsNativeInstructions()');b=s.index('    private bool CrossesExceptionBoundary(',a);s=s[:a]+s[b:]
 a=s.index('    private static bool IsInlineInstruction(');b=s.index(';',a)+1;s=s[:a]+s[b:]
 return s
edit('src/Lokad.Lython/Frontend/ExecutableScript.cs',code)
def native(s):
 s=s.replace('var completed = RunCore(out result);','var completed = Code.NativeProgram.RequireNotNull().Invoke(ref this, out result);')
 a=s.index('        private bool RunCore(');b=s.index('        private bool Format(',a);return s[:a]+s[b:]
edit('src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs',native)
edit('src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeProgram.cs',lambda s:s.replace('cancellationToken.ThrowIfCancellationRequested();','PythonTokenization.CheckCancellation(cancellationToken, 0);'))
edit('src/Lokad.Lython/Public/LythonEngine.cs',lambda s:s.replace('LoweredScript.Lower(script);','LoweredScript.Lower(script, governor, cancellationToken);').replace('ExecutableScript.Compile(loweredScript);','ExecutableScript.Compile(loweredScript, governor, cancellationToken);'))
edit('src/Lokad.Lython/Runtime/LythonRuntime.Imports.cs',lambda s:s.replace('ExecutableScript.Compile(LoweredScript.Lower(frontend.Script));','ExecutableScript.Compile(LoweredScript.Lower(frontend.Script, context.MemoryGovernor, context.State.CancellationToken),\n            context.MemoryGovernor, context.State.CancellationToken);'))
print('Integrated private complete native replacement, explicit compiler ownership/token through class/lambda/import paths; old switch/whitelist removed.')
