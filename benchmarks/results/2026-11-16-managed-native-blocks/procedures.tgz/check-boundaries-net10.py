from pathlib import Path
import os,subprocess
repo=Path('D:/code/Lython');r=Path(__file__).resolve().parent;w=repo/'.git/agent-worktrees/native-blocks-r456';dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe')
env=os.environ.copy();env['DOTNET_ROOT']=str(dotnet.parent);env['DOTNET_ROOT_X64']=str(dotnet.parent);env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
jobs=[('internal','Lokad.Lython.Tests',['MethodBodyCompilationBoundaryTests','ExecutableCompilationLifetimeTests','DeferredFunctionOwnershipTests','OwnedTupleReturnTests','DirectOperandOwnershipTests','FormattedStringExecutableTests','IntegerProtocolAsyncTests','ExecutableOperandStackBoundaryTests','NativeClosureSequenceTests','NativeIntegerChainTests','NativeTupleReturnTests','ExecutableCallFrameTests','NestedFrameLifetimeTests']),
 ('public','Lokad.Lython.PublicApi.Tests',['CompilerCancellationTests','GovernedImportAdmissionTests','ExecutableLocalImportTests','FileImportLifecycleTests','ImportedCodeRetentionScenarioTests','FunctionNamespaceLifetimeTests','FunctionDefinitionIsolationTests','CompiledModuleAnnotationTests','FunctionValueAccountingScenarioTests','FramedFunctionExecutionTests','ProtectedHelperExecutionTests','FrameIntegerLifetimeTests','AsyncFunctionHostingTests','FunctionSlotBindingTests','FunctionBindingLifetimeTests','FunctionDefaultMetadataTests','FunctionStringAdmissionTests'])]
for framework in ['net10.0']:
 for label,project,classes in jobs:
  log=r/f'boundary-{label}-{framework}.log';assert not log.exists()
  condition='Category!=Stress&('+ '|'.join('FullyQualifiedName~.'+name+'.'for name in classes)+')'
  command=[str(dotnet),'test',str(w/'tests'/project/(project+'.csproj')),'-c','Release','-f',framework,'--filter',condition,'--logger',f'trx;LogFileName=boundary-{label}-{framework}.trx','--results-directory',str(r)]
  with log.open('w',encoding='utf-8')as f:p=subprocess.run(command,cwd=w,env=env,stdout=f,stderr=subprocess.STDOUT)
  print(framework,label,log.read_text(encoding='utf-8')[-2500:],flush=True)
  if p.returncode:raise SystemExit(p.returncode)
