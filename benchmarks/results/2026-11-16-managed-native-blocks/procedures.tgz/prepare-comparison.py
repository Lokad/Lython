from pathlib import Path
import ast,hashlib,io,json,subprocess,tarfile
repo=Path('D:/code/Lython');r=Path(__file__).resolve().parent;old=r.parent/'bulk-replacement-r455/refined';template=old/'quiet';q=r/'quiet';q.mkdir(exist_ok=False)
root='/home/lokad/lython-bench-checks/native-blocks-b860-20261116';unit='lython-b860-native-blocks-20261116'
source='/home/lokad/lython-bench-checks/bulk-replacement-b859-20261116'
frozen=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));c=json.loads((template/'config.json').read_text(encoding='utf-8'));base=frozen['imageFiles']['reference']
mappings=[(x['path'],x['canonical'],x['member'])for x in json.loads((r/'retirement-candidates.json').read_text(encoding='utf-8'))]+[('bulk-replacement-b859-20261116/confirmation/confirmation.json','benchmarks/results/2026-11-16-bulk-replacement/refined/observations.tgz','confirmation/confirmation.json')]
proofs=[]
for path,canonical,member in mappings:
 blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes()
 with tarfile.open(fileobj=io.BytesIO(blob))as a:data=a.extractfile(member).read()
 proofs.append(dict(paths=[path],bytes=len(data),links=1,sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True))
(r/'retirement-proof.json').write_text(json.dumps(proofs,indent=2)+'\n',encoding='utf-8')
identity=dict(sourceRevision='Fully qualified9e8d1cf5/e92d9598 reference; privateR456 complete native blocks/'+frozen['imageFiles']['candidate']['Lokad.Lython.dll'][:8],purpose='Complete native-block replacement: numeric/report warm/fresh, report compilation, affected call diagnostic and normalization control. Includes all new-script compilation costs; no prediction or qualification claim.',imageFiles=frozen['imageFiles'],coreSHA256={label:frozen['imageFiles']['candidate'if label.startswith('candidate')else'reference']['Lokad.Lython.dll']for label in ['reference','reference-control','candidate','candidate-control']},auxiliaryFiles={n:h for n,h in base.items()if n!='Lokad.Lython.dll'},catalogSHA256=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest(),normalAdapterPin='0.4.0',qualificationDebt=frozen['focusedStatus'])
c.update(root=root,unit=unit,source=source,sourceRole='candidate',sourceFiles=base,sourceCatalogSHA256=identity['catalogSHA256'],catalogSHA256=identity['catalogSHA256'],retireGroups=proofs,identity=identity)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
jobs=[['scripts.numeric-squared-error.large','warm'],['scripts.numeric-squared-error.large','compile-run'],['scripts.report-render.large','warm'],['scripts.report-render.large','compile-run'],['scripts.report-render.large','compile'],['calls.positional.large','warm'],['scripts.text-normalization.large','warm']]
for name in ['collect.py','archive-owned.py','run.sh']:
 s=(template/name).read_text(encoding='utf-8').replace(source,root)
 if name=='collect.py':
  lines=s.splitlines();i=next(i for i,line in enumerate(lines)if line.startswith('jobs='));lines[i]='jobs='+repr(jobs);s='\n'.join(lines)+'\n';s=s.replace('len(jobs)==5','len(jobs)==7')
  s=s.replace("        self.request('verify', 2)","        self.request('verify', 2)\n        self.first_verification_seconds = self.last_request_seconds")
  s=s.replace("counts=counts,warmups=warmups,samples=samples)","counts=counts,warmups=warmups,samples=samples, firstVerificationSeconds={w.label:w.first_verification_seconds for w in workers}, firstVerificationBoundary='first full verification request includes one compilation and two complete runs, fixtures/goldens/protocol; not an isolated compilation or process-startup clock')")
 if name=='archive-owned.py':s=s.replace("len(raw['jobs'])==5","len(raw['jobs'])==7").replace('jobs=5','jobs=7')
 (q/name).write_text(s,encoding='utf-8',newline='\n')
 if name.endswith('.py'):ast.parse(s)
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for name in ['collect.py','archive-owned.py','run.sh','identity.json']:a.add(q/name,arcname=name)
 a.add(r/'frozen/candidate/Lokad.Lython.dll',arcname='candidate/Lokad.Lython.dll')
with tarfile.open(q/'payload.tgz')as a:c['unpackedBytes']=sum(m.size for m in a.getmembers())
c.update(payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest());(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
s=(template/'remote-launch.py').read_text(encoding='utf-8');tree=ast.parse(s);node=next(n for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='c'for t in n.targets));lines=s.splitlines(keepends=True);lines[node.lineno-1:node.end_lineno]=['c='+repr(c)+'\n'];s=''.join(lines).replace('lython-b859-fixtures','lython-b860-fixtures')
line="assert (root/'representative.json').is_file()  # New six-case catalog supplied in verified payload.";assert line in s;s=s.replace(line,"os.link(source/'representative.json',root/'representative.json')")
ast.parse(s);(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(template/'retrieve.py').read_text(encoding='utf-8').replace("['jobs']==5","['jobs']==7").replace('B859','B860');(q/'retrieve.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'launch.py').read_text(encoding='utf-8').replace('seconds=180','seconds=230').replace('180seconds','230seconds').replace('Five-job bulk replacement','Seven-job complete native blocks').replace('B859','B860');(r/'launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'summarize.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==5","len(raw['jobs'])==7");(r/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(dict(prepared=True,jobs=jobs,retiredBytesProved=sum(p['bytes']for p in proofs),unpackedBytes=c['unpackedBytes'],payloadBytes=c['payloadBytes'],onlyCoreChanges=True,qualificationIncomplete=True)))
