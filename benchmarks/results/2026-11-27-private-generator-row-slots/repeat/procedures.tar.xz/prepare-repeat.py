from hashlib import sha256
from pathlib import Path
from shutil import copyfile, copytree
import json

lab = Path(__file__).resolve().parent
first = lab / "comparison"
repeat = first / "repeat"
repeat.mkdir()
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8", newline="\n")

setup = read(first / "identity.json")
assert read(first / "archive-receipt.json")["archiveSHA256"] == digest(first / "observations.tar.xz")
assert read(first / "summary.json")["verifiedTimedBatches"] == 112
for role, contents in setup["imageFiles"].items():
    assert {file.name: digest(file) for file in (first / role).iterdir()} == contents
    copytree(first / role, repeat / role)
for name in ("representative.json", "cpython-worker.py", "run.sh"):
    copyfile(first / name, repeat / name)
assert b"\r" not in (repeat / "run.sh").read_bytes()
jobs = read(first / "jobs.json")["warm"]
write(repeat / "jobs.json", {"warm": [jobs[3], jobs[2], jobs[1]]})
setup["catalogs"]["jobs.json"]["sha256"] = digest(repeat / "jobs.json")
setup["purpose"] = "Same images with reversed worker placement to resolve first-block async and bound uncertainty."
write(repeat / "identity.json", setup)
collector = (first / "collect.py").read_text(encoding="utf-8").replace("len(jobs) == 4", "len(jobs) == 3").replace("job_index % 2 == 0", "job_index % 2 != 0")
compile(collector, "collect.py", "exec")
(repeat / "collect.py").write_text(collector, encoding="utf-8", newline="\n")
summary = (lab / "summarize.py").read_text(encoding="utf-8").replace('else "comparison")','else "comparison/repeat")').replace('if mode == "quiet" else 4','if mode == "quiet" else 3').replace('if mode == "quiet" else 112','if mode == "quiet" else 84')
compile(summary, "summarize-repeat.py", "exec")
(lab / "summarize-repeat.py").write_text(summary, encoding="utf-8", newline="\n")
