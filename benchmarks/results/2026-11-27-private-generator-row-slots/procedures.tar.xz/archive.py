from hashlib import sha256
from pathlib import Path
from shutil import copyfile
import io
import json
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
pair = lab / "comparison"
report = repo / "benchmarks/results/2026-11-27-private-generator-row-slots"
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
identity = read(pair / "identity.json")
summary = read(pair / "summary.json")
receipt = read(pair / "archive-receipt.json")

for tree, file in (("src", "candidate.patch"), ("tests", "test.patch")):
    patch = subprocess.check_output(["git", "diff", "--binary", identity["sourceRevision"], "--", tree], cwd=repo)
    assert patch == (lab / file).read_bytes(), tree
assert digest(lab / "candidate.patch") == identity["sourcePatchSHA256"] == summary["candidatePatchSHA256"]
assert summary["verifiedTimedBatches"] == 112 and summary["quietMachine"] is False
assert all(receipt[key] for key in ("complete", "allWorkersJoined", "guestFixturesRemoved", "archivedAndVerifiedUnderLease"))
assert receipt["archiveSHA256"] == digest(pair / "observations.tar.xz")
for role, expected in identity["imageFiles"].items():
    assert len(expected) == 32
    assert {x.name: digest(x) for x in (pair / role).iterdir()} == expected
    verification = read(pair / (role + "-verify.json"))
    assert verification["state"] == "Completed" and verification["caseCount"] == 3
reference, candidate = (identity["imageFiles"][role] for role in ("reference", "candidate"))
assert {name for name in reference if reference[name] != candidate[name]} == {"Lokad.Lython.dll"}

report.mkdir(exist_ok=True, parents=True)
for name in ("summary.json", "identity.json", "observations.tar.xz"):
    copyfile(pair / name, report / name)
copyfile(lab / "allocation/summary.json", report / "allocation-summary.json")

files = [
    *[(lab / name, name) for name in ("archive.py", "prepare.py", "prepare.log", "candidate.patch", "test.patch",
                                    "summarize.py", "extract-regression.py", "cpython-regression.py", "cpython-regression.log", "test-ubuntu.sh", "test-windows.ps1")],
    *[(pair / name, name) for name in ("run.sh", "collect.py", "archive-receipt.json", "collection.log",
                                     "exit-code.txt", "reference-verify.json", "candidate-verify.json", "jobs.json", "representative.json")],
    *[(path, "allocation/" + path.name) for path in sorted((lab / "allocation").glob("*.json"))],
    *[(path, path.name) for path in sorted(lab.glob("*net*.log"))],
]
with tarfile.open(report / "procedures.tar.xz", "w:xz") as bundle:
    for path, name in files:
        payload = path.read_bytes()
        info = tarfile.TarInfo(name)
        info.size = len(payload)
        bundle.addfile(info, io.BytesIO(payload))
with tarfile.open(report / "procedures.tar.xz") as bundle:
    assert all(bundle.extractfile(name).read() == path.read_bytes() for path, name in files)
assert digest(report / "observations.tar.xz") == receipt["archiveSHA256"]
print(f"{len(files)} procedure files verified, {sum(path.stat().st_size for path in report.iterdir())} evidence bytes")
repeat = pair / "repeat"
repeat_report = report / "repeat"
repeat_report.mkdir(exist_ok=True)
repeat_identity = read(repeat / "identity.json")
repeat_summary = read(repeat / "summary.json")
repeat_receipt = read(repeat / "archive-receipt.json")
assert repeat_identity["imageFiles"] == identity["imageFiles"]
assert repeat_summary["verifiedTimedBatches"] == 84 and repeat_summary["quietMachine"] is False
assert repeat_summary["candidatePatchSHA256"] == identity["sourcePatchSHA256"]
assert all(repeat_receipt[key] for key in ("complete", "allWorkersJoined", "guestFixturesRemoved", "archivedAndVerifiedUnderLease"))
assert repeat_receipt["archiveSHA256"] == digest(repeat / "observations.tar.xz")
for role, expected in identity["imageFiles"].items():
    assert {x.name: digest(x) for x in (repeat / role).iterdir()} == expected
for name in ("summary.json", "identity.json", "observations.tar.xz"):
    copyfile(repeat / name, repeat_report / name)
repeat_files = [
    *[(lab / name, name) for name in ("prepare-repeat.py", "summarize-repeat.py")],
    *[(repeat / name, name) for name in ("run.sh", "collect.py", "jobs.json", "archive-receipt.json",
                                        "collection.log", "exit-code.txt", "reference-verify.json", "candidate-verify.json")],
]
with tarfile.open(repeat_report / "procedures.tar.xz", "w:xz") as bundle:
    for path, name in repeat_files:
        payload = path.read_bytes()
        info = tarfile.TarInfo(name)
        info.size = len(payload)
        bundle.addfile(info, io.BytesIO(payload))
with tarfile.open(repeat_report / "procedures.tar.xz") as bundle:
    assert all(bundle.extractfile(name).read() == path.read_bytes() for path, name in repeat_files)
assert digest(repeat_report / "observations.tar.xz") == repeat_receipt["archiveSHA256"]
print("Repeat archive verified")
