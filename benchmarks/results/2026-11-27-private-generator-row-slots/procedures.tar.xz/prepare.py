from hashlib import sha256
from pathlib import Path
from shutil import copyfile, copytree
from statistics import median
import json
import os
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
pair = lab / "comparison"
notes = lab.parent
prior = notes / "isolated-inline-json-record-b1909-20261127/comparison"
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
git = lambda *args: subprocess.check_output(["git", *args], cwd=repo)
def image(folder):
    return {p.name: digest(p) for p in folder.iterdir()}
def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8", newline="\n")

base = git("rev-parse", "HEAD").decode().strip()
original = read(prior / "identity.json")
assert sha256(git("diff", "--binary", original["sourceRevision"], base, "--", "src")).hexdigest() == original["sourcePatchSHA256"]
patch = git("diff", "--binary", base, "--", "src")
assert patch.count(b"diff --git ") == 4 and b"StartBoundIterationFunction" in patch
(lab / "candidate.patch").write_bytes(patch)
(lab / "test.patch").write_bytes(git("diff", "--binary", base, "--", "tests"))
pair.mkdir()
assert image(prior / "candidate") == original["imageFiles"]["candidate"]
for role in ("reference", "candidate"):
    copytree(prior / "candidate", pair / role)
core = "Lokad.Lython.dll"
fresh = repo / "src/Lokad.Lython/bin/Release/net11.0" / core
assert digest(fresh) == digest(repo / "tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0" / core) != original["imageFiles"]["candidate"][core]
copyfile(fresh, pair / "candidate" / core)
images = {role: image(pair / role) for role in ("reference", "candidate")}
assert [name for name, before in images["reference"].items() if images["candidate"][name] != before] == [core]
for name in ("cpython-worker.py", "run.sh"):
    copyfile(prior / name, pair / name)
assert digest(pair / "cpython-worker.py") == original["cpythonWorkerSHA256"]
assert b"\r" not in (pair / "run.sh").read_bytes()

def verified_catalog(folder):
    path = folder / "representative.json"
    assert digest(path) == read(folder / "identity.json")["catalogs"][path.name]["sha256"]
    return read(path)

cache = notes / "generator-definition-cache-20261127"
catalog = verified_catalog(notes / "generator-row-workspace-refined-20261127/comparison")
keep = {"diagnostic.shipment-starmap-iterable-rows", "diagnostic.shipment-bound-starmap", "diagnostic.shipment-file-fed-map"}
catalog["cases"] = [case for case in catalog["cases"] if case["id"] in keep]
iterable, bound, file_fed = catalog["cases"]
assert [case["id"] for case in (iterable, bound, file_fed)] == [
    "diagnostic.shipment-starmap-iterable-rows", "diagnostic.shipment-bound-starmap", "diagnostic.shipment-file-fed-map"]
write(pair / "representative.json", catalog)
jobs = [[iterable["id"], "warm"], [bound["id"], "warm-async"], [file_fed["id"], "warm-async"], [iterable["id"], "warm-async"]]
write(pair / "jobs.json", {"warm": jobs})
identity = dict(sourceRevision=base, sourcePatchSHA256=digest(lab / "candidate.patch"),
                productionReference=base, imageFiles=images,
                coreSHA256={role + suffix: hashes[core] for role, hashes in images.items() for suffix in ("", "-control")},
                cpythonWorkerSHA256=original["cpythonWorkerSHA256"], cpythonPath=original["cpythonPath"],
                expectedCPythonSHA256=original["expectedCPythonSHA256"],
                purpose="Transfer the generator row and ready callback result in their existing slots.",
                catalogs={name: {"sha256": digest(pair / name)} for name in ("representative.json", "jobs.json")})
write(pair / "identity.json", identity)
collector = (prior / "collect.py").read_text(encoding="utf-8").replace("lython-isolated-inline-json-record-", "lython-private-generator-row-slots-").replace("len(jobs) == 5", "len(jobs) == 4")
compile(collector, "collect.py", "exec")
(pair / "collect.py").write_text(collector, encoding="utf-8", newline="\n")
print("Frozen", base, identity["sourcePatchSHA256"], flush=True)

allocation = lab / "allocation"
allocation.mkdir()
witness = cache / "allocation/candidate"
for role, files in images.items():
    folder = allocation / role
    copytree(pair / role, folder)
    for file in witness.glob("ValidatedAllocation*"):
        copyfile(file, folder / file.name)
    assert (folder / "ValidatedAllocation.dll").is_file()
    assert all(digest(folder / name) == checksum for name, checksum in files.items())
sdk = Path.home() / ".dotnet11"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
rows = []
for mode in ("sync", "async"):
    for case in catalog["cases"]:
        case["runAsync"] = mode == "async"
    selection = allocation / f"{mode}-catalog.json"
    write(selection, catalog)
    comparisons = []
    for role in images:
        folder = allocation / role
        report = allocation / f"{role}-{mode}.json"
        subprocess.run([sdk / "dotnet.exe", folder / "ValidatedAllocation.dll", folder, selection, report], env=env, check=True, timeout=90)
        comparisons.append(read(report)["rows"])
    for before, after in zip(*comparisons, strict=True):
        assert before["id"] == after["id"]
        assert before["sharedBudgetBaselineRestored"] and after["sharedBudgetBaselineRestored"]
        row = dict(case=before["id"], mode=mode, clr=[median(r["allocatedBytesPerInvocation"]) for r in (before, after)],
                   peak=[r["peakExecutionMemoryBytes"] for r in (before, after)],
                   compiled=[r["compiledReservedBytes"] for r in (before, after)])
        rows.append(row)
        print(row, flush=True)
write(allocation / "summary.json", rows)



