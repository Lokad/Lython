from pathlib import Path
import re
import textwrap

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
suite = repo / "tests/Lokad.Lython.PublicApi.Tests/StarmapMaterializationParityTests.cs"
source = suite.read_text(encoding="utf-8").split("Task GeneratorRowsPreservePublishedScalarAliases", 1)[1]
body = textwrap.dedent(re.search(r'const string source = """\n(.*?)\n\s*""";', source, re.S).group(1))
(lab / "cpython-regression.py").write_text(body + "\n", encoding="utf-8", newline="\n")
