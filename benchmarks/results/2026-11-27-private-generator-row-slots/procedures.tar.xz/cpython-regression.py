from itertools import starmap
def row(step):
    yield marker
    yield marker
    yield 1000 + step
    yield 1000.0 + step
def choose(first, second, integer, floating):
    if first is second and integer == floating:
        return first
    return -1
marker = int('9001')
values = list(starmap(choose, [row(2)]))
print(values[0] is marker, values)
