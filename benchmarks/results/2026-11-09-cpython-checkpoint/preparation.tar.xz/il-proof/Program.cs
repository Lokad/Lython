using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Reflection.Metadata;
using System.Reflection.PortableExecutable;
using System.Security.Cryptography;
using System.Text.Json;

using var left = new PEReader(File.OpenRead(args[0]));
using var right = new PEReader(File.OpenRead(args[1]));
var a = left.GetMetadataReader(); var b = right.GetMetadataReader();
if (a.MethodDefinitions.Count != b.MethodDefinitions.Count) throw new Exception("Method count changed.");
var policies = new List<string>(); var checkedBodies = 0;
foreach (var handle in a.MethodDefinitions)
{
    var x = a.GetMethodDefinition(handle); var y = b.GetMethodDefinition(handle);
    var name = a.GetString(x.Name);
    if (name != b.GetString(y.Name) || x.GetDeclaringType() != y.GetDeclaringType() ||
        x.Attributes != y.Attributes || !a.GetBlobBytes(x.Signature).SequenceEqual(b.GetBlobBytes(y.Signature)))
        throw new Exception("Signature or method identity changed: " + name);
    if (x.ImplAttributes != y.ImplAttributes)
    {
        if ((x.ImplAttributes & MethodImplAttributes.NoInlining) == 0 ||
            (x.ImplAttributes & ~MethodImplAttributes.NoInlining) != y.ImplAttributes)
            throw new Exception("Unexpected implementation policy: " + name);
        policies.Add(name);
    }
    if (x.RelativeVirtualAddress == 0 || y.RelativeVirtualAddress == 0)
    {
        if (x.RelativeVirtualAddress != y.RelativeVirtualAddress) throw new Exception("Body presence changed.");
        continue;
    }
    var p = left.GetMethodBody(x.RelativeVirtualAddress); var q = right.GetMethodBody(y.RelativeVirtualAddress);
    if (!p.GetILBytes()!.SequenceEqual(q.GetILBytes()!) || p.MaxStack != q.MaxStack ||
        p.LocalSignature != q.LocalSignature || p.LocalVariablesInitialized != q.LocalVariablesInitialized ||
        !p.ExceptionRegions.SequenceEqual(q.ExceptionRegions))
        throw new Exception("Executable IL/body metadata changed: " + name);
    checkedBodies++;
}
var expected = Array.Empty<string>();
if (!policies.Order().SequenceEqual(expected.Order())) throw new Exception("Unexpected removed policies.");
Console.WriteLine(JsonSerializer.Serialize(new
{
    methodCount = a.MethodDefinitions.Count, identicalExecutableBodies = checkedBodies,
    changedImplementationPolicies = policies,
    allMethodSignaturesAttributesAndBodyMetadataEqual = true,
    beforeSHA256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[0]))),
    candidateSHA256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(args[1]))),
    limitation = "IL identity is not JIT-code identity or platform/performance qualification. Assembly/PDB/source revision metadata may differ."
}));
