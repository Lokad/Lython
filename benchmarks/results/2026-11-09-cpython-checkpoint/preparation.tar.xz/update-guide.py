from pathlib import Path
import json,re
r=Path(__file__).parent;data=json.loads((r/'summary.json').read_text(encoding='utf8'));rows={(x['case'],x['lane']):x for x in data['timing']}
names={'scripts.csv-validated-records.large':'CSV validation/helper calls','scripts.text-summary-helpers.large':'Text summary/helpers','scripts.report-render.large':'JSON-to-Markdown report'}
reverse={v:k for k,v in names.items()}
lines=(r/'prior-BENCHMARKS.md').read_text(encoding='utf8').splitlines();table=0;result=[]
for line in lines:
 if line.startswith('| Workload |'):table+=1
 if table in [1,2,3]and line.startswith('| ')and line.split('|')[1].strip()in reverse:
  cells=line.split('|');case=reverse[cells[1].strip()];lane={1:'compile-run',2:'warm',3:'compile'}[table];d=rows[case,lane];factor=1000 if lane=='compile'else 1;unit='µs'if lane=='compile'else'ms';a,b=d['timeRangeMilliseconds'];py=d['medianMilliseconds']['CPython'];lo,hi=d['ratioRange'];status=f"{d['status']}; {d['controlPercent']:.2f}% /{max(d['iqrPercent'].values()):.2f}%"
  prefix=f'| {names[case]} | '+(cells[2].strip()+' | 'if table==1 else'')
  times=f'{a*factor:.1f}–{b*factor:.1f} {unit}'if lane=='compile'else f'{a:.3f}–{b:.3f} ms';pyt=f'{py*factor:.1f} {unit}'if lane=='compile'else f'{py:.3f} ms'
  line=prefix+f'{times} | {pyt} | {lo:.2f}–{hi:.2f}× | `6d73` | {status} |'
 result.append(line)
s='\n'.join(result)+'\n'
s=s.replace('**Sources: `6f76` = `6f76f99d`, 2026-11-08; `4598` = `459813a3`, 2026-11-09.**\nBoth use', '**Sources: `6d73` = `6d73c742`, 2026-11-09; `4598` = `459813a3`, 2026-11-09;\n`6f76` = `6f76f99d`, 2026-11-08.** All use')
a=s.index('Each row describes its named runtime source');b=s.index('## Warm execution, compilation and startup',a)
s=s[:a]+f"""Each row reports a fixed source checkpoint, rather than arbitrary later HEAD.
Source `6d73` uses a fresh post-commit Release core `ea65554e`, with executable IL
identical to the focused Boolean candidate. Focused semantic/cancellation/ownership
checks pass on both target frameworks; full delivery qualification is pending.
Earlier `4598` and `6f76` sources have completed platform/stress/package checks.
Qualification and performance evidence are separate; no individual optimization
speedup can be inferred from ratios across these checkpoints.

The [current checkpoint](../benchmarks/results/2026-11-09-cpython-checkpoint/README.md)
refreshes validated CSV, text helpers and report: nine jobs /{data['elapsedSeconds']:.3f}s,
using the same external scripts/fixtures/goldens and execution boundary. All quiet,
output, ownership, cleanup and archive gates pass. The
[prior guide](../benchmarks/results/2026-11-09-cpython-checkpoint/prior-BENCHMARKS.md)
retains every displaced row and its source. The other five rows remain explicitly
historical. Full original observations and adverse results stay linked from the
checkpoint evidence; short variable observations remain visible here.

"""+s[b:]
s=s.replace('Frozen worker7cf/optional0.4\nadapter unchanged. This checkpoint certifies no newer regex producer.', 'Fresh worker22331/coreea65 for6d73; older rows use worker7cf. Worker source changes\nonly default catalog construction; the supplied external catalog, host operations,\nprotocol and timing boundary are unchanged. Optional adapter remains0.4; no newer\nregex producer is qualified by these non-regex workloads.')
s=s.replace('The eight rows use two explicit source checkpoints.', 'The eight rows use three explicit source checkpoints. Three current main-script\nrows use6d73; unchanged CSV/JSON rows remain6f76 and config/file rows remain4598.')
needle='| Literal construction / compilation |';at=s.index(needle)
addition="""| Native Boolean results / CSV and search | Actual warm allocation −9.09% /−11.54–11.66%; id()/is singleton consistency corrected | No general CPU gain; report +0.11–2.44% possible elapsed debt, controls variable. [R135](../benchmarks/results/2026-11-09-native-booleans/README.md) |
| Shared static call syntax / compilation | Allocation −2.59–4.14% across five scripts | CPU/complete-config elapsed inconclusive; wider process CPU has possible debt. [R133](../benchmarks/results/2026-11-09-static-call-shape/README.md) |
| Direct native inputs / search | Consumed nodes/read dispatch removed; controlled syncsearch elapsed −2.45–3.40% | No general CPU/neutrality claim; text CPU/control uncertainty retained. [R132](../benchmarks/results/2026-11-09-native-inputs/README.md) |
"""
s=s[:at]+addition+s[at:]
Path('docs/BENCHMARKS.md').write_text(s,encoding='utf8',newline='\n')
# Independently check all tables, links and exactly three current rows per boundary.
for block in re.findall(r'(?:^\|.*\n)+',s,re.M):
 counts={len(x.split('|'))for x in block.strip().splitlines()};assert len(counts)==1,counts
for target in re.findall(r'\]\(([^)]+)\)',s):
 if not target.startswith(('http:','https:','#')):assert (Path('docs')/target.split('#')[0]).exists(),target
assert s.count(' | `6d73` |')==9
print('Updated three comparison tables with current6d73; historical rows, links and table columns verified')
