from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'cpython-checkpoint-b496-20261109';reference=base/'native-booleans-b495-20261109/candidate'
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]ollector.dll|[p]erf record'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(2073441+1);assert len(payload)==2073441 and hashlib.sha256(payload).hexdigest()=='8527f6097788b3a5691f794eb7fbd90ff6590f9c265ed3e72b14c138bce827c3'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:
  payloadRequired=sum(((m.size+4095)//4096)*4096 for m in a.getmembers());assert payloadRequired<12582912
  required=251658240+12582912+payloadRequired
  assert shutil.disk_usage(base).free>required,(shutil.disk_usage(base).free,required)
  root.mkdir();a.extractall(root,filter='data')
 identity=json.loads((root/'identity.json').read_text());assert set(identity['coreSHA256'])=={'candidate','candidate-control'}
 updates=json.loads((root/'updates.json').read_text())
 shutil.copytree(reference,root/'candidate',copy_function=os.link)
 for rel,digest in updates.items():
  incoming=root/'updates'/rel;target=root/'candidate'/rel
  assert incoming.is_file() and not incoming.is_symlink() and hashlib.sha256(incoming.read_bytes()).hexdigest()==digest
  assert root/'candidate' in target.parents and root/'updates' in incoming.parents
  target.parent.mkdir(parents=True,exist_ok=True)
  if target.exists():target.unlink()
  os.link(incoming,target)
 os.link(root/'candidate/Lokad.Lython.dll',root/'current-core.dll')
 catalog_source=reference.parent/'representative.json'
 assert catalog_source.is_file() and not catalog_source.is_symlink() and catalog_source.stat().st_uid==os.geteuid() and os.access(catalog_source.parent,os.W_OK)
 assert hashlib.sha256(catalog_source.read_bytes()).hexdigest()==identity['catalogSHA256']
 os.link(catalog_source,root/'representative.json')
 assert hashlib.sha256((root/'current-core.dll').read_bytes()).hexdigest()==identity['coreSHA256']['candidate']
 assert identity['coreSHA256']['candidate']==identity['coreSHA256']['candidate-control']
 for n,h in identity['auxiliaryFiles'].items():assert hashlib.sha256((root/'candidate'/n).read_bytes()).hexdigest()==h
 (root/'cpython-worker.py').symlink_to(base/'prepared-call-layout-b384-20261107/cpython-worker.py')
 for n in ['collect.py','archive-owned.py']:ast.parse((root/n).read_text())
 assert 'assert len(jobs)==9 'in(root/'collect.py').read_text()and"len(r['jobs'])==9"in(root/'archive-owned.py').read_text()
 assert "labels=['CPython','candidate','candidate-control']"in(root/'collect.py').read_text()
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 fixture=root/'guest-fixtures';fixture.mkdir();subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b490-fixtures',str(fixture)],check=True)
 try:
  setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndEveryAuxiliaryVerified=True,all9JobsValidated=True,ownerSeconds=270,stopSeconds=30,marginSeconds=30,osFreeFloorMiB=240,totalEvidenceAllowanceBytes=12582912,payloadRoundedBytes=payloadRequired)
  assert setup['freeBytes']>251658240+12582912
  (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
  fcntl.flock(lease,fcntl.LOCK_UN)
  subprocess.run(['sudo','-n','systemd-run','--unit=lython-b496-cpython-checkpoint-20261109','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=270','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
 except BaseException:
  subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
