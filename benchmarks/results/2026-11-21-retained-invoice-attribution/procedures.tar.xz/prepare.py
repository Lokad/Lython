from io import BytesIO
from pathlib import Path
import hashlib
import json
import os
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.parent/"native-only-method-lookup-20261121"
donor=prior/"quiet"
stage_lab=lab.parent/"regex-inline-one-shot-20261121"
template=lab/"template"
root="/home/lokad/lython-bench-checks/retained-invoice-attribution-b1301-20261121"
unit="lython-b1301-retained-invoice-attribution-20261121"
label="candidate-policy-invoice"
case_id="scripts.csv-invoice.method-policy"
def load(p):
    return json.loads(p.read_text(encoding="utf-8-sig"))
def hash_bytes(v):
    return hashlib.sha256(v).hexdigest()
def sha(p):
    return hash_bytes(p.read_bytes())
def emit(name,value):
    path=lab/name
    if path.suffix==".py":compile(value,str(path),"exec")
    path.write_text(value,encoding="utf-8",newline="\n")
def save(name,value):
    emit(name,json.dumps(value,indent=2)+"\n")
def archive_member(remote,relative):
    packed=subprocess.check_output(["git","show","origin/master:benchmarks/results/"+relative],cwd=repo)
    path="confirmation/confirmation.json"
    with tarfile.open(fileobj=BytesIO(packed),mode="r:gz") as f:
        member=f.getmember(path)
        assert member.isfile()
        data=f.extractfile(member).read()
        assert len(data)==member.size and json.loads(data)["complete"]
    return dict(paths=[remote+"/"+path],links=1,bytes=len(data),sha256=hash_bytes(data),
        archives={remote+"/observations.tgz":hash_bytes(packed)},optional=False)

stage=load(donor/"config.json")
receipt=load(donor/"archive-receipt.json")
terminal=load(stage_lab/"quiet/terminal-status.json")
assert terminal["exitCode"]=="0" and terminal["receipt"]["complete"] and not terminal["remainingWorkers"]
assert receipt["complete"] and receipt["archivedAndVerifiedUnderLease"]
retire=[
    archive_member("cpython-method-invoice-b1298-20261121","2026-11-21-cpython-method-invoice/observations.tgz"),
    archive_member("native-callback-entry-b1256-20261121-space-audited","2026-11-21-native-callback-entry/observations.tgz"),
]
summary=load(stage_lab/"quiet/config.json")
frozen=prior/"frozen/candidate"
files=stage["identity"]["imageFiles"]["candidate"]
assert len(files)==32 and {n:sha(frozen/n) for n in files}==files
revision=stage["identity"]["sourceRevision"].split()[-1]
assert revision.startswith("8f210d967")
catalog=load(prior/"representative.json")
catalog["cases"]=[c for c in catalog["cases"] if c["id"]==case_id]
assert len(catalog["cases"])==1
save("representative.json",catalog)
manifest=lab/"representative.json"
protocol=repo/"benchmarks/cpython-worker.py"
assert sha(protocol)==stage["protocolSHA256"]
dotnet=Path.home()/".dotnet11/dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent),PATH=str(dotnet.parent)+os.pathsep+os.environ["PATH"])
subprocess.run([dotnet,frozen/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",manifest,
    "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",lab/"verify.json"],
    check=True,cwd=repo,env=env,timeout=90)
proof=load(lab/"verify.json")
assert proof["state"]=="Completed" and proof["caseCount"]==1 and proof["catalogSha256"]==sha(manifest)
identity=dict(sourceRevision=revision,productionEquivalent="d51891009",purpose="Retained CSV policy invoice CPU attribution",
    coreSHA256=dict(candidate=files["Lokad.Lython.dll"]),imageFiles=dict(candidate=files),catalogSHA256=sha(manifest),diagnosticOnly=True)
save("identity.json",identity)
old="current-runtime-costs-b1262-20261121"
names=("ops-profile.py","collect.py","analyze.py","retrieve.py","run.sh")
jobs=[(label,case_id,"warm")]
for name in names:
    text=(template/name).read_text(encoding="utf-8").replace(old,"retained-invoice-attribution-b1301-20261121")
    text=text.replace("Current factory and validator CPU attribution","Retained CSV policy invoice CPU attribution")
    text=text.replace('candidate / "catalog.json"', 'candidate / "representative.json"')
    if name=="ops-profile.py":
        a=text.index("    for name, case_id, lane in ")
        b=text.index("\n",a)
        text=text[:a]+"    for name, case_id, lane in "+repr(jobs)+":"+text[b:]
        text=text.replace('count = 512 if name.endswith("nested") else 2048','count = 128')
        assert "count = 128" in text
    elif name in {"collect.py","analyze.py"}:
        text=text.replace("['candidate-postponed-nested', 'candidate-validator', 'candidate-validator-compile']",repr([label]))
        text=text.replace("len(records)==3","len(records)==1")
        if name=="analyze.py":
            text=text.replace("     'row finalization':", """     'text line acquisition': ('ReadLineInto', 'ReadLineCore', 'TryReadLineWindow', 'FindLineEndByte'),
     'row finalization':""")
    emit(name,text)
assert b"\r" not in (lab/"run.sh").read_bytes()

parts=("identity.json","representative.json","ops-profile.py","collect.py","run.sh")
payload=lab/"payload.tgz"
with tarfile.open(payload,"w:gz") as out:
    for name in parts:out.add(lab/name,arcname=name)
config=dict(root=root,unit=unit,identity=identity,source=stage["root"],sourceRole="candidate",
    sourceFiles=files,sourceCatalogSHA256=stage["catalogSHA256"],donorArchiveSHA256=receipt["archiveSHA256"],
    protocolSource=stage["root"]+"/cpython-worker.py",protocolSHA256=sha(protocol),retireGroups=retire,
    catalogSHA256=sha(manifest),payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),
    unpackedBytes=sum((lab/n).stat().st_size for n in parts))
save("config.json",config)
source=(stage_lab/"quiet/remote-launch.py").read_text(encoding="utf-8")
a,b=source.index("\nc=")+1,source.index("\nb=Path(")
source=source[:a]+"c="+repr(config)+source[b:]
source=source.replace("['reference','candidate']","['candidate']").replace("('collect.py','archive-owned.py')","('collect.py','ops-profile.py')")
source=source.replace("c['unpackedBytes']+640*1024","c['unpackedBytes']+512*1024").replace("lython-b1300-fixtures","lython-b1301-fixtures").replace("RuntimeMaxSec=540","RuntimeMaxSec=120")
emit("remote-launch.py",source)
text=(stage_lab/"launch.py").read_text(encoding="utf-8")
text=text.replace("Path(__file__).parent/'quiet'","Path(__file__).parent").replace("Inline single-match regex comparison","CSV invoice CPU attribution").replace("225","75")
emit("launch.py",text)
