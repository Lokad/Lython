from pathlib import Path
import datetime, hashlib, json, subprocess

lab=Path(__file__).resolve().parent
c=json.loads((lab/"config.json").read_text(encoding="utf-8"))
parts=["identity.json","representative.json","ops-profile.py","collect.py","run.sh"]
proof={name:hashlib.sha256((lab/name).read_bytes()).hexdigest() for name in parts}
code=r"""
from pathlib import Path
import ast,fcntl,hashlib,json,os,shutil,subprocess
c=CONFIG
proof=PROOFS
b=Path('/home/lokad/lython-bench-checks').resolve(); root=Path(c['root'])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert root.is_dir() and root.resolve()==root and root.parent==b
with (b/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 actual=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True).stdout
 own={str(os.getpid()),str(os.getppid())};assert all(line.split(maxsplit=1)[0] in own for line in actual.splitlines()),actual
 assert not any(os.path.ismount(p) for p in b.glob('*/guest-fixtures'))
 result=subprocess.check_output(['systemctl','show',c['unit']+'.service','--property=LoadState,MainPID'],text=True)
 assert 'LoadState=not-found' in result and 'MainPID=0' in result
 assert not (root/'guest-fixtures').exists() and not(root/'observations.tgz').exists()
 assert {n:sha(root/n) for n in proof}==proof
 assert {p.name:sha(p) for p in (root/'candidate').iterdir()}==c['sourceFiles']
 assert sha(root/'cpython-worker.py')==c['protocolSHA256']
 assert sha(Path(c['source'])/'observations.tgz')==c['donorArchiveSHA256']
 for group in c['retireGroups']:
  assert all(not(b/n).exists() for n in group['paths'])
  assert all(sha(b/n)==digest for n,digest in group['archives'].items())
 for name in ('collect.py','ops-profile.py'): ast.parse((root/name).read_text())
 assert b'\r' not in (root/'run.sh').read_bytes()
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 free=shutil.disk_usage(root).free
 assert free>176160768+512*1024,free
 (root/'retirement-receipt.json').write_text(json.dumps(dict(recoveredPrelaunchValidation=True,freshIdleLease=True,
   completeStagedImageAndPersistentArchivesVerified=True,retiredOnFirstStage=c['retireGroups'],freeAfterBytes=free),indent=2)+'\n')
 fixture=root/'guest-fixtures';fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=32m,mode=0700,uid=lokad,gid=lokad',
   'lython-b1301-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+c['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),
 '--property=RuntimeMaxSec=120','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(json.dumps(dict(launched=True,unit=c['unit'],root=str(root),freeBytes=free)))
""".replace("CONFIG",repr(c)).replace("PROOFS",repr(proof))
ssh=["C:/Windows/System32/OpenSSH/ssh.exe","-i",str(Path.home()/".ssh/id_lython-bench.pem"),"-o","BatchMode=yes",
     "-o","ConnectTimeout=15","lokad@20.166.121.73","python3 -"]
run=subprocess.run(ssh,input=code,capture_output=True,text=True,encoding="utf-8",timeout=60)
(lab/"launch-recovered.log").write_text(run.stdout+run.stderr,encoding="utf-8",newline="\n")
assert run.returncode==0,run.stderr
now=datetime.datetime.now(datetime.timezone.utc)
(lab/"observe-not-before.json").write_text(json.dumps(dict(launchedAtUTC=now.isoformat(),
 doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=75)).isoformat()),indent=2)+"\n",encoding="utf-8",newline="\n")
print(run.stdout)
