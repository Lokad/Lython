using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Lokad.Lython;
using Lokad.Lython.Utf8Regex;

using var catalog = JsonDocument.Parse(File.ReadAllText(args[0], Encoding.UTF8));
var engine = new LythonEngine(Utf8RegexProvider.Instance);
var budget = new LythonMemoryBudget(32 * 1024 * 1024);
var rows = new List<object>();
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var id = item.GetProperty("id").GetString()!;
    var source = item.GetProperty("source").GetString()!;
    long retained = -1;
    const int warmup = 6;
    long[] samples = new long[11];
    // Use an active, uncancelled compile token for the long-input encoding path.
    using var cancellation = new CancellationTokenSource();
    for (var i = 0; i < warmup + samples.Length; i++)
    {
        var before = GC.GetAllocatedBytesForCurrentThread();
        using (var script = engine.Compile(source, budget, cancellation.Token))
        {
            if (!script.IsValid) throw new InvalidDataException(string.Join("\n", script.Diagnostics));
            if (retained < 0) retained = budget.ReservedBytes;
            if (budget.ReservedBytes != retained) throw new InvalidDataException("Unexpected owner balance.");
        }
        var bytes = GC.GetAllocatedBytesForCurrentThread() - before;
        if (i >= warmup) samples[i - warmup] = bytes;
        if (budget.ReservedBytes != 0) throw new InvalidOperationException("Compilation owner did not return to baseline.");
    }
    rows.Add(new { id, retainedAdmission = retained, samples });
}
var core = typeof(LythonEngine).Assembly.Location;
var evidence = new { coreSHA256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(core))).ToLowerInvariant(), rows };
Console.WriteLine(JsonSerializer.Serialize(evidence, new JsonSerializerOptions { WriteIndented = true }));
