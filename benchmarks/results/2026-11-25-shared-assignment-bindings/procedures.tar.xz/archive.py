from pathlib import Path
import hashlib, json, re, shutil, subprocess, tarfile
from statistics import median

repo = Path.cwd()
lab = repo / '.git/agent-notes/review-20261031/shared-assignment-bindings-20261125'
pinned = lab / 'local-confirmation'
out = repo / 'benchmarks/results/2026-11-25-shared-assignment-bindings'
out.mkdir(exist_ok=True)

read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
identity = read(lab/'identity.json')
assert sha(lab/'representative.json') == identity['catalogSHA256']
assert sha(lab/'candidate.patch') == identity['sourcePatchSHA256']
for path, patch in (('src', 'candidate.patch'), ('tests', 'tests.patch')):
    assert subprocess.check_output(['git','diff','--binary','HEAD','--',path]) == (lab/patch).read_bytes()
assert read(pinned/'archive-receipt.json')['archiveSHA256'] == sha(pinned/'observations.tar.xz')
for role, files in identity['imageFiles'].items():
    for run in (lab, pinned):
        assert {p.name:sha(p) for p in (run/role).iterdir()} == files and len(files) == 32
    verified=read(lab/f'{role}-verify.json')
    assert verified['state']=='Completed' and verified['caseCount']==6 and verified['catalogSha256']==identity['catalogSHA256']
    assert verified['launched']['library']['sha256']==identity['coreSHA256'][role]

allocation=[]
for a,b in zip(*(read(lab/f'{role}-allocations.json')['rows'] for role in ('reference','candidate')),strict=True):
    assert a['id']==b['id'] and a['retainedAdmission']==b['retainedAdmission']
    assert len(a['samples'])==len(b['samples'])==11
    allocation.append(dict(case=a['id'],allocationBytes=[median(a['samples']),median(b['samples'])],retainedAdmission=a['retainedAdmission']))
raw=read(pinned/'confirmation/confirmation.json')
assert raw['complete'] and len(raw['jobs'])==4
ranges=[]
for j in raw['jobs']:
    assert j['workersJoinedAndFixturesRemoved']
    pairs={}
    for metric in ('cpu', 'elapsed'):
        timings={}
        for role in j['identities']:
            samples=sorted((o for o in j['samples'] if o['engine']==role),key=lambda o:o['round'])
            assert len(samples)==7
            timings[role]=[(o['externalProcessCpuTicks']/o['externalCpuFrequency'] if metric=='cpu' else
                o['response']['elapsedTicks']/o['response']['clockFrequency'])/o['response']['completedInvocations'] for o in samples]
        pairs[metric]={}
        for left,right in (('candidate','reference'),('candidate-control','candidate'),('reference-control','reference')):
            changes=[100*(a/b-1) for a,b in zip(timings[left],timings[right],strict=True)]
            entry=dict(medianPercent=median(changes),minPercent=min(changes),maxPercent=max(changes))
            assert entry['minPercent']<0<entry['maxPercent']
            pairs[metric][f'{left} / {right}']=entry
    ranges.append(dict(case=j['case'],lane=j['lane'],**pairs))
assert all(row['complete'] for row in [raw])
for suite,platform,expected,log in (
    ('public','windows-11',1293,'.git/agent-notes/frontend-bindings-final-public-20261125.log'),
    ('internal','windows-11',388,'.git/agent-notes/frontend-bindings-final-white-20261125.log'),
    ('public','ubuntu-10',1293,lab/'Lokad.Lython.PublicApi.Tests-ubuntu10.log'),
    ('internal','ubuntu-10',388,lab/'Lokad.Lython.Tests-ubuntu10.log')):
    original=Path(log)
    assert re.search(rf'Failed:\s+0, Passed:\s+{expected},',original.read_text(encoding='utf-8-sig'))
    shutil.copyfile(original,lab/f'{platform}-{suite}.log')
summary=dict(allocation=allocation,pinnedPairedTiming=ranges,elapsedCollectionSeconds=raw['elapsedSeconds'])
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(lab/'identity.json',out/'identity.json')
shutil.copyfile(pinned/'observations.tar.xz',out/'pinned-observations.tar.xz')
with tarfile.open(out/'procedures.tar.xz','w:xz') as archive:
    names=['candidate.patch','tests.patch','prepare.py','archive.py','prepare.log','representative.json','reference-verify.json',
        'candidate-verify.json','reference-allocations.json','candidate-allocations.json','Program.cs','RouteProbe.csproj','test-ubuntu.sh']
    names.extend(p.name for p in sorted(lab.glob('*-compile*.json')))
    names.extend(p.name for p in sorted(lab.glob('*-11-*.log')))
    names.extend(p.name for p in sorted(lab.glob('*-10-*.log')))
    for name in names: archive.add(lab/name,arcname=name)
    archive.add(pinned/'archive-receipt.json',arcname='local-archive-receipt.json')
print('Verified six goldens per image, 1,681 checks per platform, two exact patches and both timing diagnostics.')
