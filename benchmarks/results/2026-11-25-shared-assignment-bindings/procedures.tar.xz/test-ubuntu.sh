set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab="$PWD/.git/agent-notes/review-20261031/shared-assignment-bindings-20261125"
public='(FullyQualifiedName~Lambda|FullyQualifiedName~Comprehension|FullyQualifiedName~SyntaxValidity|FullyQualifiedName~ScopeDirective|FullyQualifiedName~Annotations|FullyQualifiedName~TypeAlias|FullyQualifiedName~MatchExecution|FullyQualifiedName~GeneratorExpression|FullyQualifiedName~NameBinding|FullyQualifiedName~Import|FullyQualifiedName~Cancellation)&Category!=Stress'
white='(FullyQualifiedName~Compiler|FullyQualifiedName~Lexical|FullyQualifiedName~Static|FullyQualifiedName~Annotation|FullyQualifiedName~Comprehension|FullyQualifiedName~Generator|FullyQualifiedName~Cancellation)&Category!=Stress'
for suite in Lokad.Lython.PublicApi.Tests Lokad.Lython.Tests; do
 filter=$white
 if [ "$suite" = "Lokad.Lython.PublicApi.Tests" ]; then filter=$public; fi
 log="$lab/$suite-ubuntu10.log"
 if dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$log" 2>&1; then
  tail -5 "$log"
 else
  tail -60 "$log"
  exit 1
 fi
done
