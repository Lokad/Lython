from pathlib import Path
import hashlib,json,os,shutil,subprocess
lab=Path(__file__).resolve().parent
repo=lab.parents[3]
b1740=lab.with_name('regex-constant-subject-20261125')
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
digest=lambda s:hashlib.sha256(s.encode('utf-8')).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=repo)
def save(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
head=git('rev-parse','HEAD').decode().strip()
assert head.startswith('8fb548c75')
ref=read(b1740/'identity.json')
assert git('diff','--binary',ref['sourceRevision'],head,'--','src')==(b1740/'candidate.patch').read_bytes()
base=ref['imageFiles']['candidate']
assert len(base)==32 and {p.name:sha(p)for p in (b1740/'candidate').iterdir()}==base
core=repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'
assert sha(core)==sha(repo/'tools/LythonProbe/bin/Release/net11.0/Lokad.Lython.dll')
patch=git('diff','--binary','HEAD','--','src')
assert patch.count(b'diff --git ')==5
(lab/'candidate.patch').write_bytes(patch)
(lab/'tests.patch').write_bytes(git('diff','--binary','HEAD','--','tests'))
images=dict(reference=base,candidate=base|{core.name:sha(core)})
for role,files in images.items():
    path=lab/role
    path.mkdir(exist_ok=True)
    for name in files:
        shutil.copyfile(core if role=='candidate' and name==core.name else b1740/'candidate'/name,path/name)
    assert {p.name:sha(p)for p in path.iterdir()}==files

cases=[]
for walrus in (False, True):
    definitions = []
    for k in range(64):
        expression = (f"((amount := row['quantity'] * row['price']), amount + {k}, amount % 7)[1]"
            if walrus else f"row['quantity'] * row['price'] + {k}")
        definitions.append(f"def score{k}(rows): return [(lambda: {expression})() for row in rows if row['quantity'] > 0]")
    source = '\n'.join(definitions) + "\nrows=[{'quantity':i,'price':i+2} for i in range(10)]\nprint(score0(rows),score28(rows),score63(rows))\n"
    result = subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-'],input=source,
        encoding='utf-8',capture_output=True,check=True,timeout=10).stdout
    fixture = json.dumps(dict(size=64,text=None),separators=(',',':'))
    target = 'bindings' if walrus else 'no-bindings'
    cases.append(dict(id='diagnostic.generated-record-rules-'+target,family='diagnostic.generated-record-rules',category='scripts',
        scale='small',size=64,source=source,fixtureJson=fixture,expectedOutput=result,sourceUtf8Bytes=len(source.encode('utf-8')),
        expectedOutputUtf8Bytes=len(result.encode('utf-8')),fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,
        sourceSha256=digest(source),fixtureSha256=digest(fixture),expectedOutputSha256=digest(result)))
catalog=read(b1740/'representative.json')
sparse=read(lab.with_name('shared-comprehension-facts-20261124')/'comparison/quiet/representative.json')
controls=('scripts.file-manifest.small','diagnostic.generated-ordinary-definitions','diagnostic.shipment-routing-callbacks')
catalog['cases']=cases+[next(item for item in catalog['cases'] if item['id']==name) for name in controls]+[
    next(item for item in sparse['cases'] if item['id']=='scripts.config-generated-guards.medium.bad-0.sparse-lexical')]
save(lab/'representative.json',catalog)
identity=dict(sourceRevision=head,sourcePatchSHA256=sha(lab/'candidate.patch'),
    catalogSHA256=sha(lab/'representative.json'),imageFiles=images,
    coreSHA256={role:files[core.name]for role,files in images.items()},cpythonWorkerSHA256=ref['cpythonWorkerSHA256'])
save(lab/'identity.json',identity)
sdk=Path.home()/'.dotnet11'; dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
worker=repo/'benchmarks/cpython-worker.py'
assert sha(worker)==identity['cpythonWorkerSHA256']
for role,files in images.items():
    image=lab/role
    evidence=lab/(role+'-verify.json')
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',lab/'representative.json',
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',worker,'--out',evidence],
        cwd=repo,env=env,check=True,timeout=80)
    checked=read(evidence)
    assert checked['state']=='Completed' and checked['caseCount']==6
    assert checked['catalogSha256']==identity['catalogSHA256']
    assert checked['launched']['library']['sha256']==files[core.name]
print('Verified all six independent CPython goldens per image.')
