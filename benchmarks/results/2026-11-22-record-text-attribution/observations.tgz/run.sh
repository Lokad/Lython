set -eu
root=/home/lokad/lython-bench-checks/record-and-text-profile-b1382-20261122
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
