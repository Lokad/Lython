from pathlib import Path
import hashlib
import json
import os
import shutil
import statistics
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
baseline = "3a6accc97"
candidate = "da45b3bf2"
worktree = repo / ".git/agent-worktrees/dead-block-shape-20261121"
donor = lab.parent / "native-only-method-lookup-20261121"
source_owner = lab.parent / "observed-regex-coordinates/frozen/reference"
dotnet = Path.home() / ".dotnet11/dotnet.exe"
python = Path("C:/Python313/python.exe")
protocol = repo / "benchmarks/cpython-worker.py"
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent),
           PATH=str(dotnet.parent) + os.pathsep + os.environ["PATH"])

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(p):
    return json.loads(p.read_text(encoding="utf-8-sig"))

def save(p, value):
    p.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8", newline="\n")

for root, revision in ((repo, baseline), (worktree, candidate)):
    assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).startswith(revision)
    assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=root)

with tarfile.open(repo/"benchmarks/results/2026-11-21-compound-function-defaults/checks-and-procedures.tar.xz") as archive:
    catalog = json.load(archive.extractfile("representative.json"))
cases = [
    "scripts.annotated-rule-closures.nested-factories",
    "scripts.annotated-rule-closures.nested-factories.postponed",
    "scripts.factory-observed-defaults",
    "scripts.ordinary-fully-supplied-helper",
    "scripts.csv-invoice.large",
]
catalog["cases"] = [case for name in cases for case in catalog["cases"] if case["id"] == name]
assert [case["id"] for case in catalog["cases"]] == cases
manifest = lab / "representative.json"
save(manifest, catalog)

identity = load(donor / "quiet/identity.json")["imageFiles"]["candidate"]
reference = donor / "frozen/candidate"
assert len(identity) == 32 and {name: sha(reference / name) for name in identity} == identity
images = {}
core = "Lokad.Lython.dll"
for role, root in (("reference", repo), ("candidate", worktree)):
    image = lab / "frozen" / role
    image.mkdir(parents=True, exist_ok=True)
    for name in identity:
        origin = root / "src/Lokad.Lython/bin/Release/net11.0" / name if name == core else reference / name
        shutil.copyfile(origin, image / name)
    images[role] = {name: sha(image / name) for name in identity}
    for path in source_owner.glob("ValidatedAllocation.*"):
        shutil.copyfile(path, image / path.name)
    receipt = lab / f"{role}-verify.json"
    subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog", manifest,
         "--dotnet", dotnet, "--python", python, "--python-worker", protocol, "--out", receipt],
         env=env, check=True, timeout=90)
    proof = load(receipt)
    assert proof["state"] == "Completed" and proof["caseCount"] == len(cases) and proof["catalogSha256"] == sha(manifest)
    subprocess.run([dotnet, image / "ValidatedAllocation.dll", image, manifest, lab / f"{role}-allocation.json"],
                   env=env, check=True, timeout=90)
    assert {name: sha(image / name) for name in identity} == images[role]
assert [name for name in identity if images["reference"][name] != images["candidate"][name]] == [core]
save(lab / "identity.json", dict(reference=baseline, candidate=candidate,
     catalogSHA256=sha(manifest), imageFiles=images))
before, after = [load(lab / f"{role}-allocation.json")["rows"] for role in ("reference", "candidate")]
result = []
for left, right in zip(before, after, strict=True):
    assert left["id"] == right["id"] and left["sharedBudgetBaselineRestored"] and right["sharedBudgetBaselineRestored"]
    start, end = [statistics.median(row["allocatedBytesPerInvocation"]) for row in (left, right)]
    result.append(dict(case=left["id"], reference=start, candidate=end, allocationChangePercent=100*(end/start-1),
                       referenceAccountedPeak=left["peakExecutionMemoryBytes"], candidateAccountedPeak=right["peakExecutionMemoryBytes"],
                       allowanceRestored=True))
    print(result[-1], flush=True)
save(lab / "allocation-summary.json", result)
