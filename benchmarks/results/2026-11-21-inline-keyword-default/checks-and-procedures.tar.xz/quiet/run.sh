set -eu
root=/home/lokad/lython-bench-checks/inline-keyword-default-b1305-20261121
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
