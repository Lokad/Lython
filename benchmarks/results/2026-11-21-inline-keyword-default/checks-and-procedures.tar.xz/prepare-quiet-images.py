from pathlib import Path
import hashlib
import json
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
work = repo / ".git/agent-worktrees/dead-block-shape-20261121"
donor = lab.parent / "native-only-method-lookup-20261121"
prior = json.loads((donor / "quiet/identity.json").read_text(encoding="utf-8"))
hashes = prior["imageFiles"]["candidate"]
assert len(hashes) == 32

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

reference = subprocess.check_output(["git", "rev-parse", "d51891009"], cwd=repo, text=True).strip()
candidate = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=work, text=True).strip()
assert candidate.startswith("55826c73f")
patch_paths = subprocess.check_output(["git", "diff", "--name-only", reference, candidate], cwd=repo, text=True).splitlines()
assert len(patch_paths) == 8
subprocess.run(["git", "diff", "--exit-code", "da45b3bf2", candidate, "--", *patch_paths], cwd=repo, check=True)
source = donor / "frozen/candidate"
candidate_core = work / "src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll"
known = {}
for role in ("reference", "candidate"):
    folder = lab / "quiet-workers" / role
    folder.mkdir(parents=True)
    for name, digest in hashes.items():
        original = source / name
        assert sha(original) == digest
        if name == "Lokad.Lython.dll" and role == "candidate":
            original = candidate_core
        shutil.copyfile(original, folder / name)
        assert sha(folder / name) == sha(original)
    known[role] = {path.name: sha(path) for path in folder.iterdir()}
(lab / "quiet-images.json").write_text(json.dumps(dict(reference=reference, candidate=candidate, imageFiles=known),indent=2)+"\n",encoding="utf-8",newline="\n")

source = (lab.parent/"tape-block-layout-20261121/prepare-quiet-rebased.py").read_text(encoding="utf-8")
source = source.replace('("regex-local-single-b1303-20261121", "2026-11-21-regex-local-one-shot", "regex-local-one-shot-20261121")',
                        '("direct-tape-layout-b1304-20261121", "2026-11-21-direct-tape-layout", "tape-block-layout-20261121")')
source = source.replace('catalog = load(lab / "catalog.json")','catalog = load(lab / "representative.json")')
source = source.replace('["scripts.config-generated-guards.medium.bad-0", "scripts.annotated-rule-closures.nested-factories.postponed", "scripts.dataclass-inherited-configuration.generated"]',
                      '["scripts.annotated-rule-closures.nested-factories", "scripts.annotated-rule-closures.nested-factories.postponed", "scripts.factory-observed-defaults", "scripts.ordinary-fully-supplied-helper"]')
source = source.replace('("white", 385), ("public", 1250)','("white", 322), ("public", 2185)')
source = source.replace('proof["caseCount"] == 3','proof["caseCount"] == 4')
source = source.replace('Write checked operand layout directly to the tape','Remove the array holding a single keyword-only default')
source = source.replace('checks/direct-tape-layout-b1304-20261121"', 'checks/inline-keyword-default-b1305-20261121"')
source = source.replace('lython-b1304-direct-tape-layout-20261121','lython-b1305-inline-keyword-default-20261121')
source = source.replace('lython-b1304-fixtures','lython-b1305-fixtures')
source = source.replace('jobs = [(cases[0], "compile"), (cases[0], "compile-run"), (cases[1], "compile"), (cases[2], "compile")]',
                        'jobs = [(case, "warm") for case in cases] + [(cases[1], "compile-run")]')
source = source.replace('len(jobs)==4','len(jobs)==5').replace('jobs=4,','jobs=5,')
source = source.replace("len(raw['jobs'])==4", "len(raw['jobs'])==5").replace("['jobs']==4", "['jobs']==5")
source = source.replace('"regex-local","direct-tape-layout"','"regex-local","inline-keyword-default"')
source = source.replace('"Direct tape layout phase comparison"))',
                        '"Inline keyword default comparison").replace("300", "345"))')
source = source.replace('emit(lab / "summarize.py", (lab.parent / "regex-local-one-shot-20261121/summarize.py").read_text(encoding="utf-8"))',
                        'emit(lab / "summarize.py", (lab.parent / "regex-local-one-shot-20261121/summarize.py").read_text(encoding="utf-8").replace("len(raw[\\\'jobs\\\'])==4", "len(raw[\\\'jobs\\\'])==5"))')
source = source.replace('Prepared four lanes','Prepared five lanes')
compile(source, str(lab / "prepare-quiet.py"), "exec")
(lab / "prepare-quiet.py").write_text(source, encoding="utf-8", newline="\n")
