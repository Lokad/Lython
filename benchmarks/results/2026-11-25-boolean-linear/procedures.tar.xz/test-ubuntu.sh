set -eu
lab="$PWD/.git/agent-notes/review-20261031/boolean-linear-20261125"
worktree="$PWD/.git/agent-worktrees/boolean-linear-20261125"
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
filter='(FullyQualifiedName~ArithmeticPrecedence|FullyQualifiedName~CompilerCancellation|FullyQualifiedName~SyntaxValidity|FullyQualifiedName~SyntaxCorpus|FullyQualifiedName~ParserCompatibility|FullyQualifiedName~PostponedAnnotation|FullyQualifiedName~ManagedStack|FullyQualifiedName~AdmissionFailureCommand|FullyQualifiedName~GovernedMemoryContract|FullyQualifiedName~CallArgumentEvaluation|FullyQualifiedName~GeneratorExpression|FullyQualifiedName~Comprehension|FullyQualifiedName~FString|FullyQualifiedName~ComparisonChain|FullyQualifiedName~BranchCondition|FullyQualifiedName~Lexer)&Category!=Stress'
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
 log="$lab/ubuntu-net10-$suite.log"
 if "$DOTNET_ROOT/dotnet" test "$worktree/tests/$suite/$suite.csproj" -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$log" 2>&1; then
     tail -3 "$log"
 else
     tail -48 "$log"
     exit 1
 fi
done