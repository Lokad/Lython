from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.with_name('compiled-entry-20261125')
quiet=lab/'comparison/quiet'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
identity=read(quiet/'identity.json')
selected=read(quiet/'representative.json')['cases']
write(lab/'tape-catalog.json',json.dumps(dict(cases=[{k:c[k] for k in ('id','source')} for c in selected]),ensure_ascii=False)+'\n')
driver=prior/'tape'
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
rows={}
for role,files in identity['imageFiles'].items():
    image=lab/role
    assert {p.name:sha(p) for p in image.iterdir()}==files
    prepared=lab/f'tape-{role}'
    prepared.mkdir(exist_ok=True)
    for p in driver.glob('Tape.*'):shutil.copyfile(p,prepared/p.name)
    shutil.copyfile(image/'Lokad.Lython.dll',prepared/'Lokad.Lython.dll')
    result=lab/f'tape-{role}.json'
    subprocess.run([dotnet,prepared/'Tape.dll',lab/'tape-catalog.json',result],cwd=repo,env=env,check=True,timeout=40)
    checked=read(result)
    assert checked['coreSHA256']==files['Lokad.Lython.dll']
    rows[role]=checked['rows']
assert rows['reference']==rows['candidate']
summary=[]
for row in rows['candidate']:
    n=sum(len(o['Instructions'])for o in row['objects'])
    summary.append(dict(case=row['id'],tapes=len(row['objects']),instructions=n,retainedAdmission=row['retainedAdmission']))
write(lab/'tape-summary.json',json.dumps(summary,indent=2)+'\n')
print(summary)
