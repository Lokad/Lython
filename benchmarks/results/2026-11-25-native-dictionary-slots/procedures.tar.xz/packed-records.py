import csv
def classify(row):
    return row['flag'] == 'yes', int(row['quantity'])
def identity(value):
    return value

source = ['flag,quantity,extra','no,3,café','yes,-17,😀','no,1_2,kept','yes,err,last']
reader = csv.DictReader(source)
next(reader)
row = next(reader)
print(classify(row))
saved = row.copy()
print(saved['extra'] is row['extra'], saved['quantity'] is row['quantity'])
del row['flag']
row['changed'] = 1
print(saved, row)
row = next(reader)
print(classify(row))
int = identity
print(classify(row)[1] is row['quantity'])
print(next(reader.reader))
