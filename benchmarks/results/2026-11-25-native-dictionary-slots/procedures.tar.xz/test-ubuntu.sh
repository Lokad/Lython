set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab="$1"
worktree="$2"
filter='(FullyQualifiedName~Csv|FullyQualifiedName~Dict|FullyQualifiedName~SetCopy|FullyQualifiedName~Defaults|FullyQualifiedName~Annotation|FullyQualifiedName~Regex|FullyQualifiedName~MemoryGovernor|FullyQualifiedName~Ownership|FullyQualifiedName~ArgumentBinding)&Category!=Stress'
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
  log="$lab/ubuntu-net10-$suite.log"
  if dotnet test "$worktree/tests/$suite/$suite.csproj" -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$log" 2>&1; then
    tail -4 "$log"
  else
    tail -55 "$log"
    exit 1
  fi
done
