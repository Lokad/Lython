from pathlib import Path
import hashlib, json, shutil, subprocess, tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
out=repo/"benchmarks/results/2026-11-25-native-dictionary-slots"
wt=repo/".git/agent-worktrees/native-dictionary-slots-20261125"
quiet=lab/"comparison/quiet"
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=read(quiet/"identity.json")
source=subprocess.check_output(["git","-C",wt,"diff","--binary","--","src"])
assert source==(lab/"candidate.patch").read_bytes() and hashlib.sha256(source).hexdigest()==identity["sourcePatchSHA256"]
(lab/"test.patch").write_bytes(subprocess.check_output(["git","-C",wt,"diff","--binary","--","tests"]))
for role, files in identity["imageFiles"].items():
    assert {p.name:sha(p) for p in (lab/role).iterdir()}==files
for name in ("identity.json","storage-custody.json"):
    shutil.copyfile(quiet/name,out/name)
for name in ("allocation-summary.json","reference-layout.json","candidate-layout.json"):
    shutil.copyfile(lab/name,out/name)
routes=lab/"routes/route-summary.json"
assert read(routes)["measuredSourcePatchSHA256"]==identity["sourcePatchSHA256"]
shutil.copyfile(routes,out/routes.name)
with tarfile.open(out/"procedures.tar.xz","w:xz") as archive:
    for name in (
        "candidate.patch","test.patch","freeze.py","prepare.py","quiet.py","archive.py","package.py",
        "allocations.py","layout/Layout.csproj","layout/Program.cs","layout-build.log",
        "routes/Program.cs","routes/RouteProbe.csproj","routes/instrumented-build.log","routes/probe-build.log",
        "routes/LythonRuntime.CsvModule.cs","routes/LythonRuntime.Executable.NativeCalls.cs",
        "routes/LythonRuntime.Executable.Slot.cs","routes/route-summary.json","packed-records.py",
        "packed-records.cpython.txt","windows-test-fixture-signatures.log","storage-build.log",
        "windows-base-Lokad.Lython.Tests.log","windows-Lokad.Lython.Tests.log",
        "windows-Lokad.Lython.PublicApi.Tests.log","windows-source-alias.log","test-ubuntu.sh",
        "ubuntu-net10-Lokad.Lython.Tests.log","ubuntu-net10-Lokad.Lython.PublicApi.Tests.log",
        "candidate-build.log","reference-build.log","comparison/candidate-verify.json",
        "comparison/reference-verify.json","candidate-allocation-final.json","reference-allocation-final.json",
        "comparison/quiet/storage-custody.json","comparison/quiet/launch.log","retrieve.log"
    ):
        assert (lab/name).is_file(),name
        archive.add(lab/name,arcname=name,recursive=False)
