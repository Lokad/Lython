using System.Reflection;
using System.Text.Json;

var assembly = Assembly.LoadFrom(Path.GetFullPath(args[0]));
var dict = assembly.GetType("Lokad.Lython.Runtime.PyDict", true)!;
var nativeKeys = dict.GetField("_nativeItems", BindingFlags.Instance | BindingFlags.NonPublic)!.FieldType.GetElementType()!;
var nativeValues = dict.GetField("_nativeValues", BindingFlags.Instance | BindingFlags.NonPublic)!.FieldType.GetElementType()!;
var keys = ElementBytes(nativeKeys);
var values = ElementBytes(nativeValues);
Console.WriteLine(JsonSerializer.Serialize(new { keys, values, combined = keys + values }));

static long ElementBytes(Type element)
{
    _ = Array.CreateInstance(element, 1);
    _ = Allocated(element, 1);
    const int length = 65536;
    var difference = Allocated(element, length + 1) - Allocated(element, 1);
    if (difference % length != 0) throw new InvalidOperationException($"Unexpected size for {element}: {difference}");
    return difference / length;
}

static long Allocated(Type element, int length)
{
    var before = GC.GetAllocatedBytesForCurrentThread();
    var array = Array.CreateInstance(element, length);
    var after = GC.GetAllocatedBytesForCurrentThread();
    GC.KeepAlive(array);
    return after - before;
}
