using System.Numerics;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal enum NativeStringOperation { Split, Replace, StartsWith, EndsWith }

    // Exact bounds cannot run Python protocols. Share the ordinary range factory
    // without packaging arguments or promoting the rest of a native helper.
    // Declining this path performs no operation or admission.
    private static bool TryInvokeNativeRange(Span<ExecutableSlot> arguments,
        LythonSourceSpan span, ExecutionContext context, out object result)
    {
        result = PyNone.Instance;
        foreach (var argument in arguments)
            if (argument.Reference is not (BigInteger or bool) && !argument.TryGetInteger(out _)) return false;
        context.EnterInterpreterFrame(span);
        try { result = Range(arguments.Length, arguments.Length > 0 ? arguments[0].Object : null,
            arguments.Length > 1 ? arguments[1].Object : null, arguments.Length > 2 ? arguments[2].Object : null, span, context); }
        catch (Exception error) when (TryTranslateCallableException(error, span, out var translated)) { throw translated; }
        finally { context.LeaveInterpreterFrame(); }
        return true;
    }

    // Conditional branches and unary not need the same closed truth contract.
    // Other values may run Python protocols and require their invocation frame.
    private static bool CanUseNativeTruth(object value)
        => value is PyNone or bool or BigInteger or double or PyString or PyBytes
            or PyList or PyTuple or PyDict or PySet or PyRange;

    // Both execution forms select operations from actual evaluated operands.
    // Other arities/keywords/protocol values keep ordinary binding.
    internal static NativeStringOperation? SelectNativeStringOperation(object? target, int argumentCount)
        => ReferenceEquals(target, ReceiverMethods.StringSplit) && argumentCount is 1 or 2 ? NativeStringOperation.Split
            : ReferenceEquals(target, ReceiverMethods.StringReplace) && argumentCount is 2 or 3 ? NativeStringOperation.Replace
            : ReferenceEquals(target, ReceiverMethods.StringStartsWith) && argumentCount == 1 ? NativeStringOperation.StartsWith
            : ReferenceEquals(target, ReceiverMethods.StringEndsWith) && argumentCount == 1 ? NativeStringOperation.EndsWith
            : null;

    private static bool CanUseNativeStringCall(NativeStringOperation operation, object? first, object? second, object? third)
        => operation switch
        {
            NativeStringOperation.Split => first is null or PyNone or PyString && second is null or PyNone or BigInteger or bool,
            NativeStringOperation.Replace => first is PyString && second is PyString && third is null or PyNone or BigInteger or bool,
            NativeStringOperation.StartsWith or NativeStringOperation.EndsWith => first is PyString,
            _ => throw new InvalidOperationException("Unknown native string operation."),
        };

    private static object InvokeNativeStringOperation(NativeStringOperation operation, PyString receiver,
        object? first, object? second, object? third, LythonSourceSpan span, ExecutionContext context)
        => operation switch
        {
            NativeStringOperation.Split => InvokeStringSplit(receiver, first, second, span, context),
            NativeStringOperation.Replace => InvokeStringReplace(receiver, first!, second!, third, span, context),
            NativeStringOperation.StartsWith or NativeStringOperation.EndsWith =>
                InvokeStringAffix(receiver, first!, span, context, operation == NativeStringOperation.StartsWith),
            _ => throw new InvalidOperationException("Unknown prepared string operation."),
        };

    // Fresh integer results share the same private result convention as
    // floating parses. Large results keep their existing admitted object owner.
    private static ExecutableSlot NativeIntegerResult(BigInteger value)
        => TryMachineInteger(value, out var small) ? ExecutableSlot.FromInteger(small)
            : ExecutableSlot.FromObject(value);

    // A function call keeps the existing argument slot. Only builtin
    // candidates have an object operand for selecting this operation.
    private static bool TryInvokeBuiltinFromSlots(ExecutableCallSite call, object target, Span<ExecutableSlot> values,
        int start, ExecutionContext scope, bool allowProtocol, out ExecutableSlot result)
    {
        result = default;
        if (!call.IsPositionalOnly || call.HasReceiver) return false;
        if (call.ArgumentCount > 1 && target is MinMaxCallable extremum)
            return extremum.TryInvokeNumericOperands(values.Slice(start + call.ArgumentOffset, call.ArgumentCount),
                call.CallSpan, scope, out result);
        if (call.ArgumentCount != 1 || target is not BuiltinCallable builtin) return false;

        var value = values[start + call.ArgumentOffset].Object;
        return TryInvokeUnaryBuiltin(builtin, value, call.CallSpan, scope, allowProtocol, out result);
    }

    private static readonly Func<long, LythonSourceSpan, ExecutionContext, ExecutableSlot> ShortUtf8FloatOperation
        = static (packed, span, context) =>
        {
            Span<byte> buffer = stackalloc byte[sizeof(long)];
            var value = ParseFloatText(ExecutableSlot.UnpackShortUtf8(packed, buffer), context, span);
            ExecutableSlot result = default;
            result.SetDouble(value);
            return result;
        };

    private static bool TryInvokeShortUtf8Float(long packed, object callee,
        LythonSourceSpan span, ExecutionContext scope, out ExecutableSlot result)
    {
        if (callee is BuiltinCallable { Name: "float" })
        {
            result = InvokeSingleInput(packed, ShortUtf8FloatOperation, span, scope);
            return true;
        }
        result = default;
        return false;
    }

    internal static int DiagnosticPackedDictionaryFields;
    internal static int DiagnosticPackedComparisonReads;
    internal static int DiagnosticPackedIntegerReads;
    internal static int DiagnosticPublishedPackedFields;
    internal static int DiagnosticConsumedPreparedRecordIntegers;

    // The only users of a private result are the immediate consumer and
    // terminal cleanup. Evaluate a decimal once using the already loaded int
    // callable. A rebinding or unsupported decimal leaves the original value.
    private static ExecutableSlot ReadRecordOperand(ref ExecutableSlot slot, ExecutableCodeObject code,
        ReadOnlySpan<ExecutableSlot> values, int index, int limit)
    {
        if (code.Instructions[index].ReadsPackedRecord && index + 1 < limit &&
            slot.TryGetShortUtf8(out var packed))
        {
            ref readonly var consumer = ref code.Instructions[index + 1];
            if (consumer.OpCode == ExecutableOpCode.Binary)
            {
                Interlocked.Increment(ref DiagnosticPackedComparisonReads);
                return slot;
            }

            var call = code.CallSites[consumer.CallSiteIndex];
            if (values[consumer.ResultSlot + call.TargetOffset].Reference is BuiltinCallable { Name: "int" })
            {
                Span<byte> bytes = stackalloc byte[sizeof(long)];
                if (TryParseShortDecimal(ExecutableSlot.UnpackShortUtf8(packed, bytes), out var integer))
                {
                    Interlocked.Increment(ref DiagnosticPackedIntegerReads);
                    return ExecutableSlot.FromInteger(integer);
                }
            }
        }
        return ExecutableSlot.FromObject(slot.Object);
    }

    private static bool TryConsumePreparedRecordInteger(ExecutableCallSite call, object target, ReadOnlySpan<ExecutableSlot> values,
        int start, ExecutionContext scope, out ExecutableSlot result)
    {
        result = default;
        if (target is not BuiltinCallable { Name: "int" }) return false;
        var argument = values[start + call.ArgumentOffset];
        if (!argument.IsUnpublishedInteger) return false;
        scope.EnterInterpreterFrame(call.CallSpan);
        try { Interlocked.Increment(ref DiagnosticConsumedPreparedRecordIntegers); result = argument; return true; }
        finally { scope.LeaveInterpreterFrame(); }
    }

    private static bool TryInvokeUnaryBuiltin(BuiltinCallable builtin, object? value,
        LythonSourceSpan span, ExecutionContext scope, bool allowProtocol, out ExecutableSlot result)
    {
        result = default;
        var operation = SelectNativeUnaryOperation(builtin, value, allowProtocol);
        if (operation is null) return false;
        result = InvokeSingleInput(value!, operation, span, scope);
        return true;
    }

    // Ordinary framed calls retain len's broader error/protocol behavior.
    private static Func<object, LythonSourceSpan, ExecutionContext, ExecutableSlot>? SelectNativeUnaryOperation(
        BuiltinCallable builtin, object? value, bool allowProtocol)
    {
        switch (builtin.Name)
        {
            case "int" when value is PyString or PyBytes:
                return IntegerTextOperation;
            case "float" when value is PyString or PyBytes:
                return FloatTextOperation;
            case "str" when value is BigInteger or PyString:
                return NativeStrOperation;
            case "abs" when ExecutionContext.IsAbsoluteBuiltin(builtin) &&
                value is BigInteger or double or bool:
                return AbsoluteOperation;
            case "sum" when ExecutionContext.IsSumBuiltin(builtin) && value is PyBytes:
                return SumBytesOperation;
            case "len" when ExecutionContext.IsLengthBuiltin(builtin):
                if (value is PyString or PyBytes or PyList or PyTuple or PyDict or PySet or PyRange or PyDeque)
                {
                    return LengthOperation;
                }
                return allowProtocol && value is not null and not PyInstance ? LengthOperation : null;
            default:
                return null;
        }
    }
}
