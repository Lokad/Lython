import json
import hashlib
import os
import shutil
import subprocess
from pathlib import Path
lab=Path(__file__).resolve().parent
run=lab/"routes"
donor=lab.with_name("native-dictionary-slots-20261125")/"routes"
source=run/"source"
frozen=lab/"frozen-candidate"
instrumented={"LythonRuntime.CsvModule.cs","LythonRuntime.Executable.NativeCalls.cs","LythonRuntime.Executable.Slot.cs"}
for base in ("src/Lokad.Lython","src/Lokad.Lython.Utf8Regex"):
    for p in (frozen/base).rglob("*.cs"):
        relative=p.relative_to(frozen)
        if "obj" not in relative.parts and p.name not in instrumented:
            shutil.copyfile(p,source/relative)
            assert p.read_bytes()==(source/relative).read_bytes(),relative
for name in instrumented:
    assert (run/name).read_bytes()==(source/"src/Lokad.Lython/Runtime"/name).read_bytes()
program=(donor/"Program.cs").read_text(encoding="utf-8")
program=program.replace('"PublishedPackedFields"];','"PublishedPackedFields", "ConsumedPreparedRecordIntegers"];')
(run/"Program.cs").write_text(program, encoding="utf-8", newline="\n")
sdk=Path.home()/".dotnet11"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
exe=sdk/"dotnet.exe"
def run_cmd(args,cwd,log,timeout=180):
    with (run/log).open("wb") as f:
        subprocess.run([exe,*args],cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=timeout)
run_cmd(["build","src/Lokad.Lython/Lokad.Lython.csproj","-c","Release","-f","net11.0","--no-incremental","--artifacts-path",run/"build"],source,"instrumented-build.log")
image=run/"candidate-image"
image.mkdir(exist_ok=True)
for p in (lab/"candidate").iterdir(): shutil.copyfile(p,image/p.name)
dll="Lokad.Lython.dll"
build=run/"build/bin/Lokad.Lython/release_net11.0"/dll
shutil.copyfile(build,image/dll)
run_cmd(["build","RouteProbe.csproj","-c","Release","--no-incremental"],run,"probe-build.log")
out=run/"route-summary.json"
assert not out.exists()
run_cmd([run/"bin/Release/net11.0/RouteProbe.dll",image,run/"cases.json",out],run,"probe.log",120)
summary=json.loads(out.read_text(encoding="utf-8"))
summary["instrumentedSHA256"]=hashlib.sha256(build.read_bytes()).hexdigest()
summary["measuredSourcePatchSHA256"]=hashlib.sha256((lab/"candidate.patch").read_bytes()).hexdigest()
assert all(row["routes"]["ConsumedPreparedRecordIntegers"]==row["routes"]["PackedIntegerReads"] for row in summary["rows"])
out.write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8",newline="\n")
print(out.read_text(encoding="utf-8"))
