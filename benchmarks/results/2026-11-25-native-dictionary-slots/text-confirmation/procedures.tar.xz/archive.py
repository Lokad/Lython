from pathlib import Path
import hashlib
import json
from statistics import median
import shutil
import tarfile

lab=Path(__file__).resolve().parent
out=lab.parents[3]/"benchmarks/results/2026-11-25-native-dictionary-slots/text-confirmation"
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
identity=read(lab/"identity.json")
terminal=read(lab/"terminal-status.json")
receipt=terminal["receipt"]
bundle=lab/"observations.tar.xz"
assert hashlib.sha256(bundle.read_bytes()).hexdigest()==receipt["archiveSHA256"]
assert not terminal["live"] and not terminal["fixtures"]
completed=terminal["exitCode"]=="0" and receipt["complete"]
paths=["identity.json","terminal-status.json","observations.tar.xz"]
if completed:
    assert all(receipt[k] for k in ["guestFixturesRemoved","allWorkersJoined","quietBeforeAndAfter","archivedAndVerifiedUnderLease"])
    with tarfile.open(bundle) as tf:
        raw=json.load(tf.extractfile("confirmation/confirmation.json"))
        assert json.load(tf.extractfile("identity.json"))==identity
        for item in ("before","after"):
            assert json.load(tf.extractfile(f"confirmation/machine-{item}.json"))["gate"]["quiet"]
    assert raw["complete"] and receipt["warmJobs"]==2
    assert [job["warmupSeconds"] for job in raw["jobs"]]==[5,16]
    case=read(lab/"catalog.json")["cases"][0]
    rows=[]
    for job in raw["jobs"]:
        labels=set(identity["coreSHA256"])
        assert job["case"]==case["id"] and job["workersJoinedAndFixturesRemoved"]
        assert set(job["initialWarmup"])==labels and all(v>=job["warmupSeconds"] for v in job["initialWarmup"].values())
        assert len(job["samples"])==42
        elapsed,cpu={},{}
        for label in sorted(labels):
            process=job["identities"][label]
            role=label.removesuffix("-control")
            assert process["catalogSha256"]==identity["catalogs"]["catalog.json"]["sha256"]
            assert process["runtimeVersion"]=="11.0.0" and not process["serverGc"] and not any(process["runtimeOverrides"].values())
            for library in process["libraries"]:
                file=Path(library["path"]).name
                expected=identity["imageFiles"][role].get(file)
                if expected is not None: assert library["sha256"]==expected
            samples=[s for s in job["samples"] if s["engine"]==label]
            assert len(samples)==7
            for sample in samples:
                data=sample["response"]
                assert data["status"]=="Completed" and data["actualOutputSha256"]==case["expectedOutputSha256"]
                assert data["actualFilesSha256"]==case["expectedFilesSha256"]
            elapsed[label]=median(s["response"]["elapsedTicks"]*1000/s["response"]["clockFrequency"]/s["response"]["completedInvocations"] for s in samples)
            cpu[label]=median(s["externalProcessCpuTicks"]*1000/s["externalCpuFrequency"]/s["response"]["completedInvocations"] for s in samples)
        def comparison(a,b,m):
            values=[(m[a+x]/m[b+y]-1)*100 for x in ["","-control"] for y in ["","-control"]]
            return [min(values),max(values)]
        spread={metric:{r:(max(m[r],m[r+"-control"])/min(m[r],m[r+"-control"])-1)*100 for r in identity["imageFiles"]}
                for metric,m in [("elapsed",elapsed),("cpu",cpu)]}
        changes={a+" vs "+b:{which:comparison(a,b,m) for which,m in [("elapsed",elapsed),("cpu",cpu)]}
                 for a,b in [("layout","reference"),("prepared","reference"),("prepared","layout")]}
        rows.append(dict(warmupSeconds=job["warmupSeconds"],elapsedMediansMs=elapsed,cpuMediansMs=cpu,workerSpreadPercent=spread,changesPercent=changes))
        print(rows[-1])
    summary=dict(source=identity["sourceRevision"],runSeconds=raw["elapsedSeconds"],timedBatches=84,rows=rows)
    (lab/"summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8",newline="\n")
    paths.append("summary.json")
out.mkdir(exist_ok=True)
for name in paths:
    shutil.copyfile(lab/name,out/name)
names=["prepare.py","quiet.py","archive.py","collect.py","catalog.json","reference-verification.json","layout-verification.json","prepared-verification.json",
       "run.sh","launch.log","observe-not-before","retrieve.log","verified-raw-replicas.json"]
with tarfile.open(out/"procedures.tar.xz","w:xz") as tf:
    for name in names:
        assert (lab/name).is_file(),name
        tf.add(lab/name,arcname=name,recursive=False)
with tarfile.open(out/"procedures.tar.xz") as tf:
    assert all(tf.extractfile(name).read()==(lab/name).read_bytes() for name in names)
