from pathlib import Path
import hashlib,json,shutil
lab=Path(__file__).resolve().parent
attribution=lab.with_name("native-dictionary-text-attribution-20261125")
donor=lab.with_name("native-dictionary-prepared-consumers-20261125")
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
def write(name,src):
    (lab/name).write_text(src,encoding="utf-8",newline="\n")
def save(name,obj):
    write(name,json.dumps(obj,ensure_ascii=False,indent=2)+"\n")
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
proof=read(attribution/"identity.json")
shutil.copyfile(attribution/"catalog.json",lab/"catalog.json")
assert sha(lab/"catalog.json")==proof["profileCatalogSHA256"]
case=read(lab/"catalog.json")["cases"][0]["id"]
proof.update(sourceRevision=proof["sourceProofs"]["reference"]["sourceRevision"], purpose="Verify equivalent text workload at two accumulated warmup depths with three exact images",
    catalogs={"catalog.json":{"sha256":sha(lab/"catalog.json")}}, expectedCPythonSHA256=read(donor/"comparison/quiet/identity.json")["expectedCPythonSHA256"],
    coreSHA256={k+suffix:v for k,v in proof["coreSHA256"].items()for suffix in ("","-control")})
save("identity.json",proof)
for role in proof["imageFiles"]:
    name=f"{role}-verification.json"
    shutil.copyfile(attribution/name,lab/name)
save("verified-raw-replicas.json",[])
shutil.copyfile(attribution/"run.sh",lab/"run.sh")
assert b"\r" not in (lab/"run.sh").read_bytes()
text=(donor/"comparison/quiet/collect.py").read_text(encoding="utf-8")
a=text.index("catalog = root /")
b=text.index("out = root /",a)
text=text[:a]+'''catalog = root / 'catalog.json'
identity = json.loads((root / 'identity.json').read_text())
images = {role: root.parent / path for role, path in identity['remoteRoleLocations'].items()}
worker = images['reference'] / 'Lokad.Lython.Benchmarks.dll'
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
spec = importlib.util.spec_from_file_location('protocol', root / 'cpython-worker.py')
protocol = importlib.util.module_from_spec(spec); spec.loader.exec_module(protocol)
cases = {c['id']: c for c in json.loads(catalog.read_text())['cases']}
assert len(cases)==1
manifest_hash = digest(catalog)
assert manifest_hash==identity['catalogs'][catalog.name]['sha256']
'''+text[b:]
a=text.index("jobs = json.loads")
b=text.index("env = os.environ",a)
text=text[:a]+text[b:]
text=text.replace("images['candidate' if label.startswith('candidate') else 'reference']","images[label.removesuffix('-control')]")
text=text.replace("identity['imageFiles']['candidate'if label.startswith('candidate')else'reference']","identity['imageFiles'][label.removesuffix('-control')]")
text=text.replace("    assert digest(python)==identity['expectedCPythonSHA256']","""    assert digest(python)==identity['expectedCPythonSHA256']
    for run, expected in identity['donorArchives'].items():
        assert digest(root.parent / run / 'observations.tar.xz')==expected""")
a=text.index("def warm():")
b=text.index("\n\ndef archive(",a)
text=text[:a]+'''def warm():
    started = time.monotonic()
    record = dict(sourceRevision=identity['sourceRevision'], purpose=identity['purpose'],
        warmupBoundary="Accumulated full request seconds per warmed process, including previous verified sample batches",
        batchSizingBoundary="Full request wall time, unchanged command-v2 guest timing",
        targetBatchSeconds=.46, rounds=7, jobs=[], complete=False)
    def save():
        temporary=out/'confirmation.json.tmp'
        temporary.write_text(json.dumps(record,indent=2)+'\\n')
        temporary.replace(out/'confirmation.json')
    save()
    case = next(iter(cases.values()))
    with contextlib.ExitStack() as stack:
        labels = ['layout', 'reference-control', 'prepared', 'layout-control', 'reference', 'prepared-control']
        workers=[Worker(label,case,'warm',stack) for label in labels]
        counts=[1]*len(workers)
        warmed=[0.0]*len(workers)
        turn=0
        for window in (5, 16):
            warmups=[[] for _ in workers]
            while min(warmed)<window:
                for offset in range(len(workers)):
                    i=(turn+offset)%len(workers)
                    if warmed[i]>=window: continue
                    worker_response=workers[i].request('batch',counts[i])
                    warmups[i].append(worker_response)
                    seconds=workers[i].last_request_seconds
                    warmed[i]+=seconds
                    counts[i]=max(1,min(100000,math.ceil(counts[i]*record['targetBatchSeconds']/max(seconds,.000001))))
                turn+=1
            initial_depth=dict(zip(labels,warmed))
            time.sleep(1)
            samples=[]
            for round in range(record['rounds']):
                for offset in range(len(workers)):
                    i=(round+turn+offset)%len(workers) if round%2==0 else (round+turn-offset)%len(workers)
                    response=workers[i].request('batch',counts[i])
                    samples.append(dict(round=round,engine=workers[i].label,response=response,
                        externalProcessCpuTicks=workers[i].last_cpu_ticks,externalCpuFrequency=cpu_frequency))
                    warmed[i]+=workers[i].last_request_seconds
            observation=dict(warmupSeconds=window,initialWarmup=initial_depth,case=case['id'],lane='warm',
                identities={w.label:w.identity for w in workers}, counts=counts.copy(),warmups=warmups,samples=samples)
            record['jobs'].append(observation)
            save()
            print('text samples after',window,'full-request seconds complete',flush=True)
        for case_worker in workers: case_worker.request('verify',2)
    for observation in record['jobs']: observation['workersJoinedAndFixturesRemoved']=True
    time.sleep(20)
    subprocess.run([str(dotnet),str(worker),'--compare','check-machine','--out',str(out/'machine-after.json')],env=env,check=True)
    assert json.loads((out/'machine-after.json').read_text())['gate']['quiet']
    record.update(complete=True,elapsedSeconds=time.monotonic()-started);save()
    return record
'''+text[b:]
text=text.replace("('identity.json','representative.json','jobs.json','confirmation','collect.py','run.sh')","('identity.json','catalog.json','confirmation','collect.py','run.sh')")
text=text.replace("lython-b1712b-fixtures","lython-b1712d-fixtures")
compile(text,"collect.py","exec")
write("collect.py",text)
launch=(attribution/"quiet.py").read_text(encoding="utf-8")
launch=launch.replace("native-dictionary-text-attribution-b1712c-20261125","native-dictionary-text-confirmation-b1712d-20261125").replace(
    "lython-b1712c-native-dictionary-text-attribution-20261125","lython-b1712d-native-dictionary-text-confirmation-20261125")
launch=launch.replace(',"ops-profile.py"', '').replace(",'ops-profile.py'","")
launch=launch.replace("import fcntl,hashlib,io,json,shutil,subprocess,sys,tarfile", "import fcntl,hashlib,io,json,shutil,subprocess,sys,tarfile")
at="  archive.extractall(root,filter='data')"
extra="""\n proof=json.loads((root/'identity.json').read_text())
 donor=root.parent/'native-dictionary-prepared-consumers-b1712b-20261125'
 worker=root/'cpython-worker.py'
 shutil.copyfile(donor/'cpython-worker.py',worker)
 assert hashlib.sha256(worker.read_bytes()).hexdigest()==proof['cpythonWorkerSHA256']
"""
assert launch.count(at)==1
launch=launch.replace(at,at+extra).replace("seconds=95","seconds=153").replace("RuntimeMaxSec=175","RuntimeMaxSec=218")
launch=launch.replace("Staged three text profiles","Staged six frozen-worker text confirmation")
compile(launch,"quiet.py","exec")
write("quiet.py",launch)
