from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab=Path(__file__).resolve().parent
out=lab.parents[3]/"benchmarks/results/2026-11-25-native-dictionary-slots/text-attribution"
terminal=json.loads((lab/"terminal-status.json").read_text(encoding="utf-8"))
fail=terminal["exitCode"]!="0" or not terminal["receipt"]["complete"]
files=["identity.json","terminal-status.json","observations.tar.xz"]
if not fail: files+=["attribution.json","profile-summary.json"]
assert not terminal["live"] and not terminal["fixtures"]
assert hashlib.sha256((lab/"observations.tar.xz").read_bytes()).hexdigest()==terminal["receipt"]["archiveSHA256"]
out.mkdir(exist_ok=True)
for name in files:
    shutil.copyfile(lab/name,out/name)
with tarfile.open(out/"procedures.tar.xz","w:xz") as archive:
    for name in ("prepare.py","quiet.py","analyze.py","summarize.py","archive.py","catalog.json","collect.py","ops-profile.py",
                 "run.sh","launch.log","observe-not-before","retrieve.log","reference-verification.json","layout-verification.json",
                 "prepared-verification.json","verified-raw-replicas.json"):
        file=lab/name
        assert file.is_file()
        archive.add(file,arcname=name,recursive=False)
with tarfile.open(out/"procedures.tar.xz") as archive:
    for name in archive.getnames():
        assert archive.extractfile(name).read()==(lab/name).read_bytes()
