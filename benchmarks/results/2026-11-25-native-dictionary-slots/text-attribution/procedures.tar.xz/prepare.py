from pathlib import Path
import hashlib,json,os,shutil,subprocess
lab=Path(__file__).resolve().parent
repo=lab.parents[3]
before=lab.with_name("current-workspace-cpu-retry-20261125")
prepared=lab.with_name("native-dictionary-prepared-consumers-20261125")
layout=lab.with_name("native-dictionary-layout-only-20261125")
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,txt):
    (lab/name).write_text(txt,encoding="utf-8",newline="\n")
def save(name,o):
    write(name,json.dumps(o,indent=2,ensure_ascii=False)+"\n")
files,locations,archives,proofs,local={},{},{},{},{}
for role,pair,kind in (("reference",prepared,"reference"),("layout",layout,"candidate"),("prepared",prepared,"candidate")):
    q=pair/"comparison/quiet"
    observed=read(q/"identity.json")
    receipt=read(q/"terminal-status.json")["receipt"]
    assert receipt["complete"] and receipt["quietBeforeAndAfter"]
    assert sha(q/"observations.tar.xz")==receipt["archiveSHA256"]
    run=read(q/"upload.json")["root"]
    files[role]=observed["imageFiles"][kind]
    locations[role]=f"{run}/{kind}"
    archives[run]=receipt["archiveSHA256"]
    local[role]=pair/kind
    assert len(files[role])==32 and {p.name:sha(p) for p in local[role].iterdir()}==files[role]
    proofs[role]=dict(sourceRevision=observed["comparisonRevision"],sourcePatchSHA256=observed["sourcePatchSHA256"] if kind=="candidate" else None)
assert len({file["Lokad.Lython.dll"] for file in files.values()})==3
assert all({n:v for n,v in f.items() if n!="Lokad.Lython.dll"}=={n:v for n,v in files["reference"].items() if n!="Lokad.Lython.dll"}
           for f in files.values())
catalog=read(prepared/"comparison/quiet/representative.json")
case="diagnostic.text-summary.nonlocal-computed-width.large"
catalog["cases"]=[match for match in catalog["cases"] if match["id"]==case]
assert len(catalog["cases"])==1
save("catalog.json",catalog)
worker=repo/"benchmarks/cpython-worker.py"
assert sha(worker)==observed["cpythonWorkerSHA256"]
proof=dict(profiles=[[f"{role}-text",case,role] for role in files],imageFiles=files,coreSHA256={k:v["Lokad.Lython.dll"] for k,v in files.items()},
    sourceProofs=proofs,remoteRoleLocations=locations,donorArchives=archives,profileCatalogSHA256=sha(lab/"catalog.json"),
    cpythonWorkerSHA256=sha(worker))
save("identity.json",proof)
sdk=Path.home()/".dotnet11"
exe=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
for role,image in local.items():
    report=lab/(role+"-verification.json")
    subprocess.run([exe,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",lab/"catalog.json","--dotnet",exe,
                    "--python","C:/Python313/python.exe","--python-worker",worker,"--out",report], cwd=repo,env=env,check=True,timeout=35)
    result=read(report)
    assert result["state"]=="Completed" and result["caseCount"]==1
    assert result["catalogSha256"]==proof["profileCatalogSHA256"] and result["launched"]["library"]["sha256"]==proof["coreSHA256"][role]
    assert {p.name:sha(p) for p in image.iterdir()}==files[role]
collector=(before/"collect.py").read_text(encoding="utf-8")
collector=collector.replace('image = root.parent / "iteration-native-storage-prepared-b1708b-20261125/candidate"','image = root.parent / "native-dictionary-prepared-consumers-b1712b-20261125/reference"')
collector=collector.replace("frozen = image.parent / role",'frozen = root.parent / identity["remoteRoleLocations"][role]')
collector=collector.replace("    assert digest(image.parent/'observations.tar.xz') == json.loads((root/'identity.json').read_text())['donorArchiveSHA256']",
    '    for donor, expected in identity["donorArchives"].items():\n        assert digest(root.parent / donor / "observations.tar.xz") == expected')
collector=collector.replace('root/"profiles",image.parent','root/"profiles",root.parent').replace("b1709-fixtures","b1712-text-fixtures")
ops=(before/"ops-profile.py").read_text(encoding="utf-8").replace("Current retained call CPU attribution","Packed dictionary text-control attribution").replace(
    "        tree = images / role", '        tree = images / json.loads((root/"identity.json").read_text())["remoteRoleLocations"][role]')
ops=ops.replace("time.monotonic()+6","time.monotonic()+8")
launch=(before/"quiet.py").read_text(encoding="utf-8").replace("current-workspace-cpu-b1709b-20261125","native-dictionary-text-attribution-b1712c-20261125").replace(
    "lython-b1709b-current-workspace-cpu-20261125","lython-b1712c-native-dictionary-text-attribution-20261125")
launch=launch.replace("        image=lab.parent/'iteration-native-storage-prepared-20261125'/role",
    '        run,variant=proof["remoteRoleLocations"][role].split("/")\n        donor=("native-dictionary-layout-only-20261125" if role=="layout" else "native-dictionary-prepared-consumers-20261125")\n        image=lab.parent/donor/variant')
launch=launch.replace('checked["caseCount"]==3','checked["caseCount"]==1').replace(
    '"identity.json","candidate-verification.json","ops-profile.py"', '"identity.json","reference-verification.json","layout-verification.json","prepared-verification.json","ops-profile.py"').replace(
    "'identity.json','candidate-verification.json','ops-profile.py'","'identity.json','reference-verification.json','layout-verification.json','prepared-verification.json','ops-profile.py'").replace(
    "seconds=120","seconds=95").replace("Staged three profiles","Staged three text profiles")
analysis=(before/"analyze.py").read_text(encoding="utf-8")
assert 'foreach' not in analysis
for name,src in (("collect.py",collector),("ops-profile.py",ops),("quiet.py",launch),("analyze.py",analysis)):
    compile(src,name,"exec")
    write(name,src)
shutil.copyfile(before/"run.sh",lab/"run.sh")
assert b"\r" not in (lab/"run.sh").read_bytes()
save("verified-raw-replicas.json",[])
