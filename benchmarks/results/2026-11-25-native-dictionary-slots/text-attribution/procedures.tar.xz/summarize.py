from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
proof=read(lab/"identity.json")
terminal=read(lab/"terminal-status.json")
receipt=terminal["receipt"]
archive=lab/"observations.tar.xz"
assert hashlib.sha256(archive.read_bytes()).hexdigest()==receipt["archiveSHA256"]
assert not terminal["live"] and not terminal["fixtures"] and terminal["exitCode"]=="0"
assert all(receipt[name] for name in ("complete","quietBeforeAndAfter","guestFixturesRemoved","allWorkersJoined","archivedAndVerifiedUnderLease"))
with tarfile.open(archive) as bundle:
    assert json.load(bundle.extractfile("identity.json"))==proof
    for name in ("before-machine.json","after-machine.json"):
        assert json.load(bundle.extractfile(name))["gate"]["quiet"]
    for label, case, role in proof["profiles"]:
        record=json.load(bundle.extractfile(f"profiles/{label}/record.json"))
        assert record["workload"]==case and record["role"]==role and record["warmupSeconds"]>=8
        for message in ("verificationBefore","verificationAfter"):
            assert record[message]["status"]=="Equivalent"
        for binary in record["identity"]["libraries"]:
            file=Path(binary["path"]).name
            if file in proof["imageFiles"][role]:
                assert binary["sha256"]==proof["imageFiles"][role][file]
data=read(lab/"attribution.json")
rows=[]
for observation in data["rows"]:
    nearest=observation["nearestRuntimeMethods"]
    groups={
        "word preparation": ("Cased", "Whitespace", "StringWordCursor"),
        "dictionary accumulate": ("TryAccumulate", "FindNativeTextIndex", "DictionaryLoop"),
        "executable dispatch": ("ExecuteInstructionPrefix", "NativeExecution::RunCore", "NativeExecution::Call", "ReadNativeOperand"),
        "resource accounting": ("MemoryGovernor::","MemoryReservation","MemoryBudget","DisposeSources","RetireTo","RetireTemporary"),
    }
    bins={label:0 for label in groups}
    bins["other managed runtime"]=0
    for method, count in nearest:
        group=next((label for label,fragments in groups.items() if any(fragment in method for fragment in fragments)), "other managed runtime")
        bins[group]+=count
    assert sum(bins.values())==observation["guestRuntimeAncestry"]
    rows.append(dict(role=observation["role"], invocations=observation["invocations"], total=observation["sampleCount"],
        resolvedRuntime=observation["guestRuntimeAncestry"],exclusiveNearest=bins,
        samplesPer1000Invocations={label:round(1000*count/observation["invocations"],2) for label,count in bins.items()},
        totalSamplesPer1000Invocations=round(1000*observation["sampleCount"]/observation["invocations"],2),
        unresolvedLeafs=observation["unmappedLeafSamples"],topMethods=nearest[:20]))
summary=dict(kind="Profiles of one warmed worker per image with perf map enabled. Per-invocation sample counts are diagnostic and incomplete.",rows=rows)
print(json.dumps(summary,indent=2))
(lab/"profile-summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8",newline="\n")
