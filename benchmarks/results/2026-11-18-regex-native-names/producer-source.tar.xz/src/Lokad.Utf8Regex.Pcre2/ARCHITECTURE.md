# Managed PCRE2 execution architecture

`Lokad.Utf8Regex.Pcre2` is a managed UTF-8 companion, not a mode of
`Utf8Regex` and not a native PCRE2 binding. Its semantic front end and runtime
remain removable with the companion project. The base library retains its
strict UTF-8 Unicode-scalar contract and its useful .NET-shaped grammar/API.

## Directional flow

Compilation is one-way:

`Pcre2CompileRequest -> validation -> parser/semantic tree -> lowering -> Pcre2CompiledProgram`

Invocation is one-way:

`caller-valid, unchanged UTF-8 subject -> operation program -> runner/cursor -> public projection`

Backtracking Count and search keep frame/repeat journals and lazily acquired
fixed vectors under one lexical owner. Candidate attempts borrow and reset that
storage; assertions own separate vectors while parent capacity stays admitted.
The fixed workspace stores no budget reference. Acquisition and finally release
receive the owner's actual budget explicitly, preserving original interruption
and aggregate capacity. Copied public cursors retain no owned scratch field;
their individual advances use a lexical scope. Reuse reduces actual rentals,
without changing instruction metering or adding a pool, lease or execution mode.

Replacement consumes matches from the same compiled operation program and
global cursor used by the other operations. It does not parse patterns, choose
a backend, or implement an independent matching loop. Partial probing has a
separate, curated program because PCRE2 partial matching is not an ordinary
successful match.

`Utf8Pcre2Regex` owns one immutable `Pcre2CompiledProgram` plus a bounded,
thread-safe replacement-plan cache. The facade validates public arguments,
creates an operation-local subject context, delegates once, and projects the
result. It does not classify complete pattern strings or select fixture-shaped
execution methods.

## Compiled-program ownership

The compiled program owns:

- the normalized compile request and immutable group/name metadata;
- semantic syntax trees retained only when a curated partial-probe program consumes them;
- one typed program for each public operation;
- the candidate-search program; and
- an optional partial-probe program derived from semantic nodes.

Direct operation programs are closed variants: a PCRE2 literal/character/backtracking program, or a
specialized operation program such as an ASCII search or DFA verifier.
`Pcre2ProgramInvariant` checks common-program and fallback ownership. The
specializations retain the owned general route for option combinations they
cannot execute. Literal, character, and backtracking programs cover the admitted
syntax; no complete-pattern classifier or legacy match/replacement router remains.

Bounded literal windows can cross zero-width word boundaries within an ASCII
consuming prefix. The original scalar VM still verifies boundaries and captures;
the window only excludes starts that cannot reach the required literal.

The anchored ASCII boolean optimizer emits flat class and repeated-class steps,
start/end anchors and acceptance. Its DFA partitions overlapping input classes
and unions their NFA targets before closure. Nested programs and text alternatives
are not a second internal input language. Major construction capacity, state and
work ceilings and original interruption checks remain; capture/option-dependent
operations retain the owned VM.

Core delegation requires a successful owned PCRE2 parse and an existing
common-scalar eligibility proof. There is no unrestricted Core-grammar fallback;
if every profile compiler declines, construction refuses. PCRE2-only
constructs stay with the PCRE2 compiler and runtime. There is no shipped BCL
`Regex` matcher or result dependency. BCL option/timeout metadata does not
execute subjects; finite-language rendering uses admitted owned text. Semantic and differential fixtures check
the supported delegation boundaries; they do not establish complete PCRE2 parity.

Development after RC1 builds literal and character operation programs directly,
with canonical group-zero metadata and no unused Core owner. Literal Rune staging
is admitted, temporary and released after encoding runtime UTF-8 bytes. Character
token/class/property buffers admit capacity and growth/final-copy overlap before
allocation, with token instruction admission and bounded work/checkpoints.
Literal and character programs have no marker syntax trees. A typed optional
ProbeRoot retains backtracking syntax only when the curated partial-probe program
consumes it; other programs drop that root after operation selection.
Lowered option fallbacks remain owned independently. Core-backed specializations retain their
real owners after profile parsing; Core capture-name copies are not authoritative.
Option eligibility omits unneeded Core preparation, and final operation selection
drops unused original owners. Finite languages retain their derived Core owner.
Shared slice slots own the same immutable scalar payload and profile fallback
directly; their ownership does not require the unused Core facade to survive.
The optional Core owner is a nullable reference, without empty/populated wrapper
objects. Operation selection precedes one complete program publication. There is no
injected legacy-foundation factory, dummy syntax tree or no-operation program.
Optional finite/ASCII expansion admits major state/buffers and bounded work
through the original construction owner; fixed shape caps alone are insufficient.

## Invocation and global progress

Public value enumeration carries only the existing direct or shared-slice cursor
and the current projection. A default cursor is empty. Obsolete materialized,
deferred-array and hard-coded example-generator implementations are removed;
real execution can still report deferred failures. Copies keep independent
positions and their original shared finite authority and absolute deadline.
Named-slot copying scans immutable entries directly into the caller's span,
preserving pattern order, duplicates and truncation without temporary collections.

Capture slots, undo journals, backtracking/call frames, resource counters,
timeout state, UTF-8 projection state, and global progress are invocation
local. Compiled regex instances retain none of those buffers and can be used
concurrently.

The backtracking runtime keeps consumed and reported ranges distinct. `\K`
changes the reported start but not the consumed range used for restart and
empty-match detection. Global cursors apply PCRE2's empty retry at the same
position, then advance by one valid UTF-8 scalar only when that retry fails.
Count, enumeration and substitution share this progression
machinery, with an operation-specific disposition for non-monotone results and
reset-empty substitution.

`Pcre2ResourceBudget` meters candidate work, backtracking, depth, heap, and
managed timeout independently. A public zero limit retains its documented
engine-default or unlimited meaning. Stack-like transient state uses pooled
storage with deterministic return; result arrays and caller-requested output
remain ordinary owned allocations.

## Partial probing

`Probe` is deliberately smaller than normal matching. The compiler recognizes
the curated partial profile from character/backtracking semantic trees and
emits a typed `Pcre2PartialProbeProgram`. Fixed semantic recognizers inspect only
the portions needed by the existing curated profile; unrelated trees are not
serialized or traversed. Character literal operands admit exact storage before
encoding, and bounded token scans retain original construction interruption.
This preparation now consumes construction work/depth and major-storage allowance
and can refuse earlier. It does not affect normal matching selection; requests
without partial matching use the ordinary runner. Unsupported partial shapes
still fail explicitly.

## Reuse from `Lokad.Utf8Regex`

The companion reuses only flavor-neutral mechanics:

- UTF-8 validation and operation-local byte/UTF-16 projection;
- prepared search kernels and byte-set carriers;
- transactional UTF-8 output writing;
- pooled stack storage;
- timeout polling; and
- adjacent-scalar access.

Every necessary core hook is tagged `PCRE2-INTEGRATION-POINT`. PCRE2 syntax,
options, compile errors, Unicode policy, capture rules, empty-match policy, and
replacement grammar remain in the companion. No generic flavor framework or
PCRE2 mode enters the core.

The only product friendship is the reviewed core-to-companion access needed
for these internal mechanics. Test and benchmark friendships expose internal
diagnostics only; no `InternalsVisibleTo` declaration appears in a project
file.

## Removability and dependency boundary

All PCRE2 production types and files live under
`src/Lokad.Utf8Regex.Pcre2/`. The package targets `net10.0`, depends only on
the BCL and `Lokad.Utf8Regex`, and contains no P/Invoke, native loader, RID
asset, external matcher, or generated native payload. Removing the companion
project and the explicitly tagged core hooks leaves the Core scalar library
and its .NET-style grammar intact.

The [profile README](README.md#delivery-evidence) links frozen delivery evidence.
The specification defines current admission and ownership; historical receipts
retain their original source, package, runtime and performance scope.
