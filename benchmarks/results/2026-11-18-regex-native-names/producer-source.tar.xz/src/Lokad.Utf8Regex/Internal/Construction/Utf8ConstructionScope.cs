namespace Lokad.Utf8Regex.Internal;

/// <summary>Shares scalar-program capacity admission across synchronous nested
/// construction. Scalar tree conversion/lowering arrays share byte admission;
/// instruction arrays also share instruction-slot admission. Adapter byte-pattern
/// decoding admits its retained text in the same owner before acquisition.
/// Structural linear instructions/steps share instruction and byte admission;
/// fixed-width checks and generated scalar group names share byte admission.
/// Covered scans, parser/conversion loops, vectors/maps/sorts and preparation
/// resumes share cumulative work admission; core/Python parser, preparation and
/// byte-safe DFA frames share live depth admission. DFA/NFA state vectors,
/// edges, closures, bucket maps and covered helper state share capacity admission.
/// Owned dynamic emission also admits IL/fixup/local/token/stack buffers,
/// runtime managed copies, dispatch/lowering tables and complete wrapper state.
/// Serialized IL byte capacity conservatively counts as instruction capacity.
/// Speculative failure never refunds admitted work.
/// Covered tree/AST/helper objects use numeric conservative charges; no object
/// registry keeps discarded helpers alive. Covered text and arrays have separate
/// length-based admission. Failed scopes restore numeric capacity without
/// invalidating caller-held objects. Unqualified acquisitions, CLR/JIT metadata
/// and complete lazy cache retention remain outside this partial backstop.</summary>
internal sealed class Utf8ConstructionScope : IDisposable
{
    // Preserve a bounded backstop while replacing the former per-program silent
    // BCL decline. A final safe default needs the full resource/corpus qualification.
    internal const ulong DefaultInstructionCapacity = 1_048_576;
    internal const ulong DefaultBufferBytes = 64 * 1024 * 1024;
    internal const ulong DefaultWorkSteps = 64 * 1024 * 1024;
    internal const ulong DefaultDepth = 65536;
    [ThreadStatic] private static Utf8ConstructionScope? s_current;
    private readonly Utf8ConstructionScope? _previous;
    private readonly ulong _checkpoint;
    private readonly ulong _byteCheckpoint;
    private readonly ulong _depthCheckpoint;
    private bool _disposed;
    private bool _completed;
    private bool _restrictedBytes;
    private ulong _previousByteMaximum;
    private ulong _previousBytePeak;
    private readonly bool _ownsFunding;

    internal Utf8ConstructionScope(ulong maximum)
        : this(maximum, DefaultBufferBytes)
    {
    }

    internal Utf8ConstructionScope(ulong maximum, ulong maximumBytes)
        : this(maximum, maximumBytes, DefaultWorkSteps, DefaultDepth)
    {
    }

    internal Utf8ConstructionScope(ulong maximum, ulong maximumBytes, ulong maximumWorkSteps, ulong maximumDepth)
        : this(maximum, maximumBytes, maximumWorkSteps, maximumDepth, null)
    {
    }

    private Utf8ConstructionScope(ulong maximum, ulong maximumBytes, ulong maximumWorkSteps, ulong maximumDepth,
        IUtf8MemoryAllowance? memoryAllowance)
    {
        _previous = s_current;
        Budget = _previous?.Budget ?? new Utf8ConstructionBudget(maximum, maximumBytes, maximumWorkSteps, maximumDepth, memoryAllowance);
        _ownsFunding = _previous is null && memoryAllowance is not null;
        _checkpoint = Budget.Reserved;
        _byteCheckpoint = Budget.ReservedBytes;
        _depthCheckpoint = Budget.Depth;
        s_current = this;
    }

    internal Utf8ConstructionBudget Budget { get; }
    internal static bool IsActive => s_current is not null;
    internal static void ChargeWork(ulong steps) => s_current?.Budget.ChargeWork(steps);
    internal static Utf8ConstructionBudget CurrentBudget => s_current?.Budget
        ?? throw new InvalidOperationException("No construction owner is active.");

    // Constructor and lowerer entry points are synchronous. Nested core/adaptor
    // construction inherits the owner instead of resetting its capacity counter.
    internal static Utf8ConstructionScope Enter() => new(DefaultInstructionCapacity);

    // Public factories start one eager construction owner. Synchronous nested
    // compilation shares it; factories cannot silently replace an active owner.
    internal static Utf8ConstructionScope Enter(Utf8ConstructionPolicy policy,
        TimeSpan timeout, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (s_current is not null)
            throw new InvalidOperationException("An explicit compilation cannot replace an active construction owner.");
        var scope = new Utf8ConstructionScope(
            Math.Min(policy.MaxInstructionCapacity ?? DefaultInstructionCapacity, DefaultInstructionCapacity),
            Math.Min(policy.MaxBytes ?? DefaultBufferBytes, DefaultBufferBytes),
            Math.Min(policy.MaxWorkSteps ?? DefaultWorkSteps, DefaultWorkSteps),
            Math.Min(policy.MaxDepth ?? DefaultDepth, DefaultDepth));
        scope.Budget.CancellationToken = cancellationToken;
        scope.Budget.Deadline = Lokad.Utf8Regex.Internal.Execution.Utf8ExecutionDeadline.Start(timeout);
        return scope;
    }

    internal static Utf8ConstructionScope Enter(Utf8ConstructionPolicy policy,
        TimeSpan timeout, CancellationToken cancellationToken, IUtf8MemoryAllowance memoryAllowance)
    {
        cancellationToken.ThrowIfCancellationRequested();
        if (s_current is not null)
            throw new InvalidOperationException("An explicit compilation cannot replace an active construction owner.");
        var scope = new Utf8ConstructionScope(
            Math.Min(policy.MaxInstructionCapacity ?? DefaultInstructionCapacity, DefaultInstructionCapacity),
            policy.MaxBytes ?? ulong.MaxValue,
            Math.Min(policy.MaxWorkSteps ?? DefaultWorkSteps, DefaultWorkSteps),
            Math.Min(policy.MaxDepth ?? DefaultDepth, DefaultDepth), memoryAllowance);
        scope.Budget.CancellationToken = cancellationToken;
        scope.Budget.Deadline = Lokad.Utf8Regex.Internal.Execution.Utf8ExecutionDeadline.Start(timeout);
        return scope;
    }

    // PCRE2-INTEGRATION-POINT: reuse this numeric owner and its allocation
    // admissions, restoring both the parent limit and historical peak on exit.
    internal static Utf8ConstructionScope RestrictAdditionalBytes(ulong additional)
    {
        var scope = Enter();
        scope._restrictedBytes = true;
        scope._previousByteMaximum = scope.Budget.MaximumBytes;
        scope._previousBytePeak = scope.Budget.PeakBytes;
        scope.Budget.RestrictAdditionalBytes(additional);
        return scope;
    }

    internal void Complete() => _completed = true;

    /// <summary>Restores the enclosing construction owner; scopes must close in lexical order.</summary>
    public void Dispose()
    {
        if (_disposed) return;
        if (!ReferenceEquals(s_current, this))
            throw new InvalidOperationException("Construction scopes must close in lexical order.");
        if (!_completed) Budget.Rollback(_checkpoint, _byteCheckpoint, _depthCheckpoint);
        if (_ownsFunding) Budget.ReleaseBytes(Budget.ReservedBytes);
        if (_restrictedBytes) Budget.RestoreByteLimit(_previousByteMaximum, _previousBytePeak);
        s_current = _previous;
        _disposed = true;
    }
}
