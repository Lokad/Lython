namespace Lokad.Utf8Regex.Internal.Diagnostics;

internal sealed class Utf8SearchDiagnosticsSession
{
    [ThreadStatic]
    private static Utf8SearchDiagnosticsSession? t_current;

    private readonly Utf8SearchDiagnosticsSession? _previous;

    private Utf8SearchDiagnosticsSession(Utf8SearchDiagnosticsSession? previous, Action<ulong>? sliceCheckpointHook)
    {
        _previous = previous;
        SliceCheckpointHook = sliceCheckpointHook;
    }

    public static Utf8SearchDiagnosticsSession Start() => Start(null);

    public static Utf8SearchDiagnosticsSession Start(Action<ulong>? sliceCheckpointHook)
    {
        var session = new Utf8SearchDiagnosticsSession(t_current, sliceCheckpointHook);
        t_current = session;
        return session;
    }

    public static Utf8SearchDiagnosticsSession? Current => t_current;

    // Snapshot into each invocation so deterministic public-operation tests
    // can cancel at an actual VM checkpoint. Nested sessions restore their
    // predecessor, and ordinary calls retain a null hook.
    internal Action<ulong>? SliceCheckpointHook { get; }

    public int SearchCandidates { get; private set; }

    public int FixedCheckRejects { get; private set; }

    public int VerifierInvocations { get; private set; }

    public int VerifierMatches { get; private set; }

    public int PrefilterWindows { get; private set; }

    public int PrefilterSkippedWindows { get; private set; }

    public int PrefilterPromotedWindows { get; private set; }

    public int PrefilterSkippedBytes { get; private set; }

    public int PrefilterPromotedBytes { get; private set; }

    public int EngineDemotions { get; private set; }

    public Utf8ExecutionRoute ExecutionRoute { get; private set; }

    public void CountSearchCandidate()
    {
        SearchCandidates++;
    }

    public void CountFixedCheckReject()
    {
        FixedCheckRejects++;
    }

    public void CountVerifierInvocation()
    {
        VerifierInvocations++;
    }

    public void CountVerifierMatch()
    {
        VerifierMatches++;
    }

    public void CountPrefilterWindow(bool promoted, int byteCount)
    {
        PrefilterWindows++;
        if (promoted)
        {
            PrefilterPromotedWindows++;
            PrefilterPromotedBytes += byteCount;
        }
        else
        {
            PrefilterSkippedWindows++;
            PrefilterSkippedBytes += byteCount;
        }
    }

    public void CountEngineDemotion()
    {
        EngineDemotions++;
    }

    public void MarkExecutionRoute(Utf8ExecutionRoute route)
    {
        if (ExecutionRoute == Utf8ExecutionRoute.None)
        {
            ExecutionRoute = route;
        }
    }

    public void Complete()
    {
        if (ReferenceEquals(t_current, this))
        {
            t_current = _previous;
        }
    }
}
