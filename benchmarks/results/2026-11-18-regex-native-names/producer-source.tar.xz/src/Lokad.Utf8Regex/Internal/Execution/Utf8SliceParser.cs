using Lokad.Utf8Regex.Internal.FrontEnd;

namespace Lokad.Utf8Regex.Internal.Execution;

/// <summary>Compiles the scalar UTF-8 VM from the authoritative owned tree.
/// Raw-pattern callers use the same front end as production preparation;
/// prepared callers reuse their tree and resolved capture catalog. Remaining
/// unsupported grammar can decline to residual routing. Lowering instruction
/// and buffer-capacity exhaustion throws an owned resource failure before
/// acquisition; pattern parsing and IR preparation still require separate admission.</summary>
internal static class Utf8SliceParser
{
    private readonly record struct FlatFrame(Utf8TreeNode Node, int NextChild, bool Entered);

    internal static Utf8SliceProgram? TryParse(string pattern, RegexOptions options)
    {
        if (pattern is null) return null;
        using var construction = Utf8ConstructionScope.Enter();
        var program = TryParse(options, Utf8OwnedTreeParser.TryParse(pattern, options));
        if (program is not null) construction.Complete();
        return program;
    }

    internal static Utf8SliceProgram? TryParse(RegexOptions options, Utf8OwnedRegexTree? tree)
    {
        if (tree is null) return null;
        if ((options & RegexOptions.NonBacktracking) != 0 &&
            Utf8NonBacktrackingGrammar.FindUnsupportedConstruct(tree.Root) is not null) return null;
        return Utf8OwnedTreeSliceLowerer.TryLower(tree, options);
    }

    internal static bool IsNonBacktrackingFlatGraph(Utf8OwnedRegexTree? tree)
    {
        if (tree is null) return false;
        // No consuming loop, assertion recursion, reference, conditional or
        // atomic choice enters this admission. Candidate work is bounded by
        // the cached finite graph, independent of subject length. This proof
        // limits native discovery only; general graphs use the owned scalar NFA.
        using var construction = Utf8ConstructionScope.Enter();
        var budget = construction.Budget;
        using (var frames = Utf8ConstructionFrames<FlatFrame>.Create(budget, new(tree.Root, 0, false)))
        {
            while (frames.Count != 0)
            {
                budget.ChargeWork(1);
                var index = frames.Count - 1;
                var frame = frames[index];
                var node = frame.Node;
                if (!frame.Entered)
                {
                    if (node.Kind is not (Utf8TreeNodeKind.One or Utf8TreeNodeKind.Set or
                        Utf8TreeNodeKind.Multi or Utf8TreeNodeKind.Empty or Utf8TreeNodeKind.Nothing or
                        Utf8TreeNodeKind.Capture or Utf8TreeNodeKind.Group or Utf8TreeNodeKind.Concatenate or Utf8TreeNodeKind.Alternate or
                        Utf8TreeNodeKind.Bol or Utf8TreeNodeKind.Eol or Utf8TreeNodeKind.Beginning or Utf8TreeNodeKind.EndZ or Utf8TreeNodeKind.End or
                        Utf8TreeNodeKind.Boundary or Utf8TreeNodeKind.NonBoundary or Utf8TreeNodeKind.ECMABoundary or Utf8TreeNodeKind.NonECMABoundary))
                        return false;
                    if (node.Kind == Utf8TreeNodeKind.Capture &&
                        (node.N >= 0 || node.M == 0 && !ReferenceEquals(node, tree.Root))) return false;
                    if (node.Kind == Utf8TreeNodeKind.Set && node.ScalarClass is null ||
                        node.Kind == Utf8TreeNodeKind.Multi && node.Str is null) return false;
                    frame = frame with { Entered = true, NextChild = node.ChildCount };
                }
                if (frame.NextChild == 0) { frames.Pop(); continue; }
                frames[index] = frame with { NextChild = frame.NextChild - 1 };
                frames.Push(new(node.Child(frame.NextChild - 1), 0, false));
            }
        }
        // Aliased declarations can write a public slot more than once even
        // without loops. Their NonBacktracking capture-history rule is separate.
        // These are authoritative tree/catalog facts, not a reason to compile
        // and discard a second scalar program during native eligibility.
        if (tree.CaptureCatalog is not { HasSharedCaptureDeclarations: false }) return false;
        construction.Complete();
        return true;
    }
}
