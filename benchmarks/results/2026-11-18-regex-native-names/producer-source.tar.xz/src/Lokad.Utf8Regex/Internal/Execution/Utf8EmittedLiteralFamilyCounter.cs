using Lokad.Utf8Regex.Internal.Planning;
using Lokad.Utf8Regex.Internal.Search;
using System.Numerics;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Intrinsics;

namespace Lokad.Utf8Regex.Internal.Execution;

internal sealed class Utf8EmittedLiteralFamilyCounter
{
    internal delegate int CountDelegate(Utf8EmittedLiteralFamilyCounter counter, ReadOnlySpan<byte> input);
    internal delegate bool IsMatchDelegate(Utf8EmittedLiteralFamilyCounter counter, ReadOnlySpan<byte> input);
    internal delegate bool TryMatchDelegate(
        Utf8EmittedLiteralFamilyCounter counter,
        ReadOnlySpan<byte> input,
        out int index,
        out int matchedLength);

    private static readonly ConstructorInfo s_scanStateCtor =
        typeof(PreparedMultiLiteralScanState).GetConstructor([typeof(int), typeof(int), typeof(int)])
        ?? throw new MissingMethodException(typeof(PreparedMultiLiteralScanState).FullName, ".ctor");

    private static readonly MethodInfo s_tryFindNextNonOverlappingLengthMethod =
        typeof(Utf8EmittedLiteralFamilyCounter).GetMethod(nameof(TryFindNextNonOverlappingLength), BindingFlags.Static | BindingFlags.NonPublic)
        ?? throw new MissingMethodException(typeof(Utf8EmittedLiteralFamilyCounter).FullName, nameof(TryFindNextNonOverlappingLength));

    private static readonly MethodInfo s_confirmMethod =
        typeof(Utf8EmittedLiteralFamilyCounter).GetMethod(nameof(Confirm), BindingFlags.Static | BindingFlags.NonPublic)
        ?? throw new MissingMethodException(typeof(Utf8EmittedLiteralFamilyCounter).FullName, nameof(Confirm));

    private static readonly MethodInfo s_confirmFirstMatchMethod =
        typeof(Utf8EmittedLiteralFamilyCounter).GetMethod(nameof(ConfirmFirstMatch), BindingFlags.Static | BindingFlags.NonPublic)
        ?? throw new MissingMethodException(typeof(Utf8EmittedLiteralFamilyCounter).FullName, nameof(ConfirmFirstMatch));

    private static readonly MethodInfo s_confirmAsciiBoundaryOnlyMethod =
        typeof(Utf8EmittedLiteralFamilyCounter).GetMethod(nameof(ConfirmAsciiBoundaryOnly), BindingFlags.Static | BindingFlags.NonPublic)
        ?? throw new MissingMethodException(typeof(Utf8EmittedLiteralFamilyCounter).FullName, nameof(ConfirmAsciiBoundaryOnly));

    private static readonly MethodInfo s_resetAfterRejectedCandidateMethod =
        typeof(Utf8EmittedLiteralFamilyCounter).GetMethod(nameof(ResetAfterRejectedCandidate), BindingFlags.Static | BindingFlags.NonPublic)
        ?? throw new MissingMethodException(typeof(Utf8EmittedLiteralFamilyCounter).FullName, nameof(ResetAfterRejectedCandidate));

    private static readonly MethodInfo s_findNextCandidate2Method =
        typeof(Utf8EmittedLiteralFamilyCounter).GetMethod(nameof(FindNextCandidate2), BindingFlags.Static | BindingFlags.NonPublic)
        ?? throw new MissingMethodException(typeof(Utf8EmittedLiteralFamilyCounter).FullName, nameof(FindNextCandidate2));

    private static readonly MethodInfo s_findNextCandidate3Method =
        typeof(Utf8EmittedLiteralFamilyCounter).GetMethod(nameof(FindNextCandidate3), BindingFlags.Static | BindingFlags.NonPublic)
        ?? throw new MissingMethodException(typeof(Utf8EmittedLiteralFamilyCounter).FullName, nameof(FindNextCandidate3));

    private static readonly MethodInfo s_findNextCandidate1Method =
        typeof(Utf8EmittedLiteralFamilyCounter).GetMethod(nameof(FindNextCandidate1), BindingFlags.Static | BindingFlags.NonPublic)
        ?? throw new MissingMethodException(typeof(Utf8EmittedLiteralFamilyCounter).FullName, nameof(FindNextCandidate1));

    private static readonly MethodInfo s_findNextAsciiCandidate1Method =
        typeof(Utf8EmittedLiteralFamilyCounter).GetMethod(nameof(FindNextAsciiCandidate1), BindingFlags.Static | BindingFlags.NonPublic)
        ?? throw new MissingMethodException(typeof(Utf8EmittedLiteralFamilyCounter).FullName, nameof(FindNextAsciiCandidate1));

    private static readonly MethodInfo s_spanLengthMethod =
        typeof(ReadOnlySpan<byte>).GetProperty(nameof(ReadOnlySpan<byte>.Length))?.GetMethod
        ?? throw new MissingMethodException(typeof(ReadOnlySpan<byte>).FullName, "get_Length");

    private static readonly MethodInfo s_spanItemMethod =
        typeof(ReadOnlySpan<byte>).GetProperty("Item")?.GetMethod
        ?? throw new MissingMethodException(typeof(ReadOnlySpan<byte>).FullName, "get_Item");

    private readonly Utf8EmittedDelegate<CountDelegate> _count;
    private readonly Utf8EmittedDelegate<CountDelegate>? _asciiValidatedCount;
    private readonly Utf8EmittedDelegate<IsMatchDelegate> _isMatch;
    private readonly Utf8EmittedDelegate<TryMatchDelegate> _tryMatch;
    private readonly Utf8SearchPlan _plan;
    private readonly Utf8SearchOperationPlan _countProgram;
    private readonly Utf8SearchOperationPlan _firstMatchProgram;
    private readonly Utf8BoundaryRequirement _leadingBoundary;
    private readonly Utf8BoundaryRequirement _trailingBoundary;

    private readonly record struct ConstructionState(Utf8SearchPlan Plan,
        Utf8SearchOperationPlan CountProgram, Utf8SearchOperationPlan FirstMatchProgram,
        Utf8BoundaryRequirement LeadingBoundary, Utf8BoundaryRequirement TrailingBoundary,
        Utf8EmittedDelegate<CountDelegate> Count, Utf8EmittedDelegate<CountDelegate>? AsciiValidatedCount, Utf8EmittedDelegate<IsMatchDelegate> IsMatch, Utf8EmittedDelegate<TryMatchDelegate> TryMatch);

    private Utf8EmittedLiteralFamilyCounter(ConstructionState state)
    {
        _plan = state.Plan; _countProgram = state.CountProgram; _firstMatchProgram = state.FirstMatchProgram;
        _leadingBoundary = state.LeadingBoundary; _trailingBoundary = state.TrailingBoundary;
        _count = state.Count; _asciiValidatedCount = state.AsciiValidatedCount;
        _isMatch = state.IsMatch; _tryMatch = state.TryMatch;
    }

    internal static bool CanCreate(Utf8SearchPlan plan, Utf8SearchOperationPlan countProgram, Utf8SearchOperationPlan firstMatchProgram)
    {
        // The generic emitted loop crosses a DynamicMethod helper for every accepted
        // candidate. With no confirmation to fuse, the prepared loop is cheaper.
        var isUnconstrainedIgnoreCaseFamily =
            plan.Kind == Utf8SearchKind.AsciiFoldedByteLiterals &&
            !countProgram.Confirmation.HasValue &&
            !firstMatchProgram.Confirmation.HasValue;
        return RuntimeFeature.IsDynamicCodeSupported && plan.HasPreparedSearcher &&
            plan.PreparedSearcher.Kind == PreparedSearcherKind.MultiLiteral &&
            !plan.HasTrailingLiteralRequirement &&
            !isUnconstrainedIgnoreCaseFamily &&
            (!plan.HasAlternateLiteralPrefixOverlap ||
             (!countProgram.Confirmation.HasValue && !firstMatchProgram.Confirmation.HasValue)) &&
            countProgram.HasValue &&
            firstMatchProgram.HasValue;
    }

    internal static bool TryCreate(
        Utf8SearchPlan plan,
        Utf8SearchOperationPlan countProgram,
        Utf8SearchOperationPlan firstMatchProgram,
        out Utf8EmittedLiteralFamilyCounter? counter)
    {
        using var scope = Utf8ConstructionScope.Enter();
        var budget = scope.Budget;
        budget.EnterDepth();
        byte[][]? singleLiteralBuckets = null;
        try
        {
            counter = null;
            if (!CanCreate(plan, countProgram, firstMatchProgram))
            {
                return false;
            }

            var canUseFastConfirmation = CanUseAsciiBoundaryOnlyFastConfirmation(plan, countProgram, firstMatchProgram);
            singleLiteralBuckets = TryGetSmallSingleLiteralBuckets(plan, out var loweredLiterals) ? loweredLiterals : null;
            var singleBucketPrefixFamily = TryGetSmallSingleBucketPrefixFamily(plan, out var commonPrefix, out var prefixLiterals)
                ? (CommonPrefix: commonPrefix, Literals: prefixLiterals)
                : ((byte[] CommonPrefix, byte[][] Literals)?)null;
            counter = budget.AllocateObject(new ConstructionState(
                plan,
                countProgram,
                firstMatchProgram,
                plan.LeadingBoundary,
                plan.TrailingBoundary,
                CompileCount(
                    countProgram.Confirmation.HasValue,
                    canUseFastConfirmation,
                    plan.HasAlternateLiteralProperStartOverlap,
                    singleLiteralBuckets,
                    singleBucketPrefixFamily),
                canUseFastConfirmation &&
                singleBucketPrefixFamily is { } fusedPrefixFamily &&
                CanFuseAsciiValidation(fusedPrefixFamily.CommonPrefix, fusedPrefixFamily.Literals)
                    ? CompileAsciiValidatedSingleBucketPrefixCount(
                        fusedPrefixFamily.CommonPrefix,
                        fusedPrefixFamily.Literals)
                    : null,
                CompileIsMatch(
                    firstMatchProgram.Confirmation.HasValue,
                    canUseFastConfirmation,
                    plan.HasAlternateLiteralProperStartOverlap,
                    singleLiteralBuckets,
                    singleBucketPrefixFamily),
                CompileTryMatch(
                    firstMatchProgram.Confirmation.HasValue,
                    canUseFastConfirmation,
                    plan.HasAlternateLiteralProperStartOverlap,
                    singleLiteralBuckets,
                    singleBucketPrefixFamily)), static state => new Utf8EmittedLiteralFamilyCounter(state));
            scope.Complete();
            return true;
        }
        finally
        {
            if (singleLiteralBuckets is not null) budget.ReleaseArray(singleLiteralBuckets, false);
            budget.LeaveDepth();
        }
    }

    internal int Count(ReadOnlySpan<byte> input) => _count.Callback(this, input);

    internal bool SupportsAsciiValidatedCount => _asciiValidatedCount is not null;

    internal bool TryCountAndValidateAscii(ReadOnlySpan<byte> input, out int count)
    {
        if (_asciiValidatedCount is null || input.Length < Vector256<byte>.Count)
        {
            count = 0;
            return false;
        }

        var result = _asciiValidatedCount.Value.Callback(this, input);
        count = Math.Max(result, 0);
        return result >= 0;
    }

    internal bool IsMatch(ReadOnlySpan<byte> input) => _isMatch.Callback(this, input);

    internal bool TryMatch(ReadOnlySpan<byte> input, out int index, out int matchedLength) => _tryMatch.Callback(this, input, out index, out matchedLength);

    private static bool TryFindNextNonOverlappingLength(
        Utf8EmittedLiteralFamilyCounter counter,
        ReadOnlySpan<byte> input,
        ref PreparedMultiLiteralScanState state,
        out int index,
        out int matchedLength)
    {
        return counter._plan.PreparedSearcher.TryFindNextNonOverlappingLength(input, ref state, out index, out matchedLength);
    }

    private static bool Confirm(Utf8EmittedLiteralFamilyCounter counter, ReadOnlySpan<byte> input, int index, int matchedLength)
    {
        return Utf8ConfirmationExecutor.IsMatch(counter._plan, counter._countProgram.Confirmation, input, index, matchedLength);
    }

    private static bool ConfirmFirstMatch(Utf8EmittedLiteralFamilyCounter counter, ReadOnlySpan<byte> input, int index, int matchedLength)
    {
        return Utf8ConfirmationExecutor.IsMatch(counter._plan, counter._firstMatchProgram.Confirmation, input, index, matchedLength);
    }

    private static bool ConfirmAsciiBoundaryOnly(Utf8EmittedLiteralFamilyCounter counter, ReadOnlySpan<byte> input, int index, int matchedLength) =>
        Utf8ScalarWordBoundary.MatchesRequirement(counter._leadingBoundary, input, index) &&
        Utf8ScalarWordBoundary.MatchesRequirement(counter._trailingBoundary, input, index + matchedLength);

    private static void ResetAfterRejectedCandidate(ref PreparedMultiLiteralScanState state, int candidateIndex)
    {
        var nextStart = candidateIndex + 1;
        state = new PreparedMultiLiteralScanState(nextStart, nextStart, 0);
    }

    private static int FindNextCandidate2(ReadOnlySpan<byte> input, int startIndex, byte firstByte0, byte firstByte1)
    {
        if ((uint)startIndex >= (uint)input.Length)
        {
            return -1;
        }

        var relative = input[startIndex..].IndexOfAny(firstByte0, firstByte1);
        return relative < 0 ? -1 : startIndex + relative;
    }

    private static int FindNextCandidate3(ReadOnlySpan<byte> input, int startIndex, byte firstByte0, byte firstByte1, byte firstByte2)
    {
        if ((uint)startIndex >= (uint)input.Length)
        {
            return -1;
        }

        var relative = input[startIndex..].IndexOfAny(firstByte0, firstByte1, firstByte2);
        return relative < 0 ? -1 : startIndex + relative;
    }

    private static int FindNextCandidate1(ReadOnlySpan<byte> input, int startIndex, byte firstByte0)
    {
        if ((uint)startIndex >= (uint)input.Length)
        {
            return -1;
        }

        var relative = input[startIndex..].IndexOf(firstByte0);
        return relative < 0 ? -1 : startIndex + relative;
    }

    private static int FindNextAsciiCandidate1(ReadOnlySpan<byte> input, int startIndex, byte firstByte0)
    {
        const int nonAscii = -2;
        if ((uint)startIndex >= (uint)input.Length)
        {
            return -1;
        }

        var blocks = MemoryMarshal.Cast<byte, Vector256<byte>>(input[startIndex..]);
        var firstByteVector = Vector256.Create(firstByte0);
        for (var blockIndex = 0; blockIndex < blocks.Length; blockIndex++)
        {
            var values = blocks[blockIndex];
            var candidateBits = Vector256.Equals(values, firstByteVector).ExtractMostSignificantBits();
            var nonAsciiBits = values.ExtractMostSignificantBits();
            if ((candidateBits | nonAsciiBits) != 0)
            {
                var candidateOffset = candidateBits == 0
                    ? int.MaxValue
                    : BitOperations.TrailingZeroCount(candidateBits);
                var nonAsciiOffset = nonAsciiBits == 0
                    ? int.MaxValue
                    : BitOperations.TrailingZeroCount(nonAsciiBits);
                return nonAsciiOffset < candidateOffset
                    ? nonAscii
                    : startIndex + blockIndex * Vector256<byte>.Count + candidateOffset;
            }
        }

        var index = startIndex + blocks.Length * Vector256<byte>.Count;
        for (; index < input.Length; index++)
        {
            var value = input[index];
            if (value >= 0x80)
            {
                return nonAscii;
            }

            if (value == firstByte0)
            {
                return index;
            }
        }

        return -1;
    }

    private static bool CanFuseAsciiValidation(ReadOnlySpan<byte> commonPrefix, ReadOnlySpan<byte[]> literals)
    {
        // A capitalized shared prefix is a selective anchor on the source-style
        // workloads this emitted shape targets. Keep dense lowercase families and
        // small alternations on the independently tuned validator/search passes.
        return Vector256.IsHardwareAccelerated &&
            commonPrefix.Length >= 3 &&
            literals.Length >= 4 &&
            commonPrefix[0] is >= (byte)'A' and <= (byte)'Z';
    }

    private static bool CanUseAsciiBoundaryOnlyFastConfirmation(
        Utf8SearchPlan plan,
        Utf8SearchOperationPlan countProgram,
        Utf8SearchOperationPlan firstMatchProgram)
    {
        return plan.HasBoundaryRequirements &&
            !plan.HasTrailingLiteralRequirement &&
            countProgram.Confirmation.Kind == Utf8ConfirmationKind.BoundaryRequirements &&
            firstMatchProgram.Confirmation.Kind == Utf8ConfirmationKind.BoundaryRequirements;
    }

    private static bool TryGetSmallSingleLiteralBuckets(Utf8SearchPlan plan, out byte[][] literals)
    {
        using var scope = Utf8ConstructionScope.Enter();
        var budget = scope.Budget;
        budget.EnterDepth();
        try
        {
            literals = [];

            if (plan.Kind is not (Utf8SearchKind.ExactAsciiLiterals or Utf8SearchKind.ExactUtf8Literals) ||
                !plan.AlternateLiteralSearch.HasValue ||
                plan.MultiLiteralSearch.Kind is not (PreparedMultiLiteralKind.ExactDirect or PreparedMultiLiteralKind.ExactEarliest))
            {
                return false;
            }

            var search = plan.AlternateLiteralSearch.Value;
            if (search.Strategy != PreparedLiteralSetStrategy.SingleLiteralBuckets)
            {
                return false;
            }

            var buckets = search.SearchData.Buckets;
            if (buckets.Length is < 2 or > 3)
            {
                return false;
            }

            foreach (var bucket in buckets)
            {
                budget.ChargeWork(1);
                if (bucket.Literals.Length != 1) return false;
            }
            literals = budget.AllocateArray<byte[]>(buckets.Length, false);
            for (var i = 0; i < buckets.Length; i++)
            {
                budget.ChargeWork(1);
                literals[i] = buckets[i].Literals[0];
            }

            scope.Complete();
            return true;
        }
        finally
        {
            budget.LeaveDepth();
        }
    }

    private static bool TryGetSmallSingleBucketPrefixFamily(Utf8SearchPlan plan, out byte[] commonPrefix, out byte[][] literals)
    {
        commonPrefix = [];
        literals = [];

        if (plan.Kind is not (Utf8SearchKind.ExactAsciiLiterals or Utf8SearchKind.ExactUtf8Literals) ||
            !plan.AlternateLiteralSearch.HasValue)
        {
            return false;
        }

        var search = plan.AlternateLiteralSearch.Value;
        if (search.Strategy != PreparedLiteralSetStrategy.SingleBucketPrefix)
        {
            return false;
        }

        var buckets = search.SearchData.Buckets;
        if (buckets.Length != 1)
        {
            return false;
        }

        var bucket = buckets[0];
        if (bucket.CommonPrefix.Length < 2 || !bucket.PrefixDiscriminator.HasValue || bucket.Literals.Length is < 2 or > 6)
        {
            return false;
        }

        commonPrefix = bucket.CommonPrefix;
        literals = bucket.Literals;
        return true;
    }

    private static Utf8EmittedDelegate<CountDelegate> CompileCount(
        bool requiresConfirmation,
        bool useAsciiBoundaryOnlyFastConfirmation,
        bool retryOverlappingAfterRejection,
        byte[][]? singleLiteralBuckets,
        (byte[] CommonPrefix, byte[][] Literals)? singleBucketPrefixFamily)
    {
        if (singleLiteralBuckets is { Length: >= 2 and <= 3 })
        {
            return CompileSingleLiteralBucketCount(useAsciiBoundaryOnlyFastConfirmation, singleLiteralBuckets);
        }

        if (singleBucketPrefixFamily is { } prefixFamily)
        {
            return CompileSingleBucketPrefixCount(useAsciiBoundaryOnlyFastConfirmation, prefixFamily.CommonPrefix, prefixFamily.Literals);
        }

        return CompileGenericCount(requiresConfirmation, useAsciiBoundaryOnlyFastConfirmation, retryOverlappingAfterRejection);
    }

    private static Utf8EmittedDelegate<IsMatchDelegate> CompileIsMatch(
        bool requiresConfirmation,
        bool useAsciiBoundaryOnlyFastConfirmation,
        bool retryOverlappingAfterRejection,
        byte[][]? singleLiteralBuckets,
        (byte[] CommonPrefix, byte[][] Literals)? singleBucketPrefixFamily)
    {
        if (singleLiteralBuckets is { Length: >= 2 and <= 3 })
        {
            return CompileSingleLiteralBucketIsMatch(useAsciiBoundaryOnlyFastConfirmation, singleLiteralBuckets);
        }

        if (singleBucketPrefixFamily is { } prefixFamily)
        {
            return CompileSingleBucketPrefixIsMatch(useAsciiBoundaryOnlyFastConfirmation, prefixFamily.CommonPrefix, prefixFamily.Literals);
        }

        return CompileGenericIsMatch(requiresConfirmation, useAsciiBoundaryOnlyFastConfirmation, retryOverlappingAfterRejection);
    }

    private static Utf8EmittedDelegate<TryMatchDelegate> CompileTryMatch(
        bool requiresConfirmation,
        bool useAsciiBoundaryOnlyFastConfirmation,
        bool retryOverlappingAfterRejection,
        byte[][]? singleLiteralBuckets,
        (byte[] CommonPrefix, byte[][] Literals)? singleBucketPrefixFamily)
    {
        if (singleLiteralBuckets is { Length: >= 2 and <= 3 })
        {
            return CompileSingleLiteralBucketTryMatch(useAsciiBoundaryOnlyFastConfirmation, singleLiteralBuckets);
        }

        if (singleBucketPrefixFamily is { } prefixFamily)
        {
            return CompileSingleBucketPrefixTryMatch(useAsciiBoundaryOnlyFastConfirmation, prefixFamily.CommonPrefix, prefixFamily.Literals);
        }

        return CompileGenericTryMatch(requiresConfirmation, useAsciiBoundaryOnlyFastConfirmation, retryOverlappingAfterRejection);
    }

    private static Utf8EmittedDelegate<CountDelegate> CompileGenericCount(
        bool requiresConfirmation,
        bool useAsciiBoundaryOnlyFastConfirmation,
        bool retryOverlappingAfterRejection)
    {
        using var dynamicMethod = Utf8DynamicIlBuilder.Create("Utf8Regex_EmitLiteralFamilyCount", typeof(int), typeof(Utf8EmittedLiteralFamilyCounter), typeof(Utf8EmittedLiteralFamilyCounter), typeof(ReadOnlySpan<byte>));

        var il = dynamicMethod;
        var stateLocal = il.DeclareLocal(typeof(PreparedMultiLiteralScanState));
        var indexLocal = il.DeclareLocal(typeof(int));
        var matchedLengthLocal = il.DeclareLocal(typeof(int));
        var countLocal = il.DeclareLocal(typeof(int));

        var loopLabel = il.DefineLabel();
        var incrementLabel = il.DefineLabel();
        var returnLabel = il.DefineLabel();

        il.Emit(OpCodes.Ldc_I4_0);
        il.Emit(OpCodes.Ldc_I4_0);
        il.Emit(OpCodes.Ldc_I4_0);
        il.Emit(OpCodes.Newobj, s_scanStateCtor);
        il.Emit(OpCodes.Stloc, stateLocal);

        il.Emit(OpCodes.Ldc_I4_0);
        il.Emit(OpCodes.Stloc, countLocal);

        il.MarkLabel(loopLabel);
        il.Emit(OpCodes.Ldarg_0);
        il.Emit(OpCodes.Ldarg_1);
        il.Emit(OpCodes.Ldloca_S, stateLocal);
        il.Emit(OpCodes.Ldloca_S, indexLocal);
        il.Emit(OpCodes.Ldloca_S, matchedLengthLocal);
        il.Emit(OpCodes.Call, s_tryFindNextNonOverlappingLengthMethod);
        il.Emit(OpCodes.Brfalse, returnLabel);

        if (requiresConfirmation)
        {
            il.Emit(OpCodes.Ldarg_0);
            il.Emit(OpCodes.Ldarg_1);
            il.Emit(OpCodes.Ldloc, indexLocal);
            il.Emit(OpCodes.Ldloc, matchedLengthLocal);
            il.Emit(OpCodes.Call, useAsciiBoundaryOnlyFastConfirmation ? s_confirmAsciiBoundaryOnlyMethod : s_confirmFirstMatchMethod);
            il.Emit(OpCodes.Brtrue, incrementLabel);
            if (retryOverlappingAfterRejection)
            {
                il.Emit(OpCodes.Ldloca_S, stateLocal);
                il.Emit(OpCodes.Ldloc, indexLocal);
                il.Emit(OpCodes.Call, s_resetAfterRejectedCandidateMethod);
            }
            il.Emit(OpCodes.Br, loopLabel);
        }

        il.MarkLabel(incrementLabel);
        il.Emit(OpCodes.Ldloc, countLocal);
        il.Emit(OpCodes.Ldc_I4_1);
        il.Emit(OpCodes.Add);
        il.Emit(OpCodes.Stloc, countLocal);
        il.Emit(OpCodes.Br, loopLabel);

        il.MarkLabel(returnLabel);
        il.Emit(OpCodes.Ldloc, countLocal);
        il.Emit(OpCodes.Ret);

        return dynamicMethod.CreateDelegate<CountDelegate>();
    }

    private static Utf8EmittedDelegate<IsMatchDelegate> CompileGenericIsMatch(
        bool requiresConfirmation,
        bool useAsciiBoundaryOnlyFastConfirmation,
        bool retryOverlappingAfterRejection)
    {
        using var dynamicMethod = Utf8DynamicIlBuilder.Create("Utf8Regex_EmitLiteralFamilyIsMatch", typeof(bool), typeof(Utf8EmittedLiteralFamilyCounter), typeof(Utf8EmittedLiteralFamilyCounter), typeof(ReadOnlySpan<byte>));

        var il = dynamicMethod;
        var stateLocal = il.DeclareLocal(typeof(PreparedMultiLiteralScanState));
        var indexLocal = il.DeclareLocal(typeof(int));
        var matchedLengthLocal = il.DeclareLocal(typeof(int));

        var loopLabel = il.DefineLabel();
        var successLabel = il.DefineLabel();
        var returnFalseLabel = il.DefineLabel();

        il.Emit(OpCodes.Ldc_I4_0);
        il.Emit(OpCodes.Ldc_I4_0);
        il.Emit(OpCodes.Ldc_I4_0);
        il.Emit(OpCodes.Newobj, s_scanStateCtor);
        il.Emit(OpCodes.Stloc, stateLocal);

        il.MarkLabel(loopLabel);
        il.Emit(OpCodes.Ldarg_0);
        il.Emit(OpCodes.Ldarg_1);
        il.Emit(OpCodes.Ldloca_S, stateLocal);
        il.Emit(OpCodes.Ldloca_S, indexLocal);
        il.Emit(OpCodes.Ldloca_S, matchedLengthLocal);
        il.Emit(OpCodes.Call, s_tryFindNextNonOverlappingLengthMethod);
        il.Emit(OpCodes.Brfalse, returnFalseLabel);

        if (requiresConfirmation)
        {
            il.Emit(OpCodes.Ldarg_0);
            il.Emit(OpCodes.Ldarg_1);
            il.Emit(OpCodes.Ldloc, indexLocal);
            il.Emit(OpCodes.Ldloc, matchedLengthLocal);
            il.Emit(OpCodes.Call, useAsciiBoundaryOnlyFastConfirmation ? s_confirmAsciiBoundaryOnlyMethod : s_confirmMethod);
            il.Emit(OpCodes.Brtrue, successLabel);
            if (retryOverlappingAfterRejection)
            {
                il.Emit(OpCodes.Ldloca_S, stateLocal);
                il.Emit(OpCodes.Ldloc, indexLocal);
                il.Emit(OpCodes.Call, s_resetAfterRejectedCandidateMethod);
            }
            il.Emit(OpCodes.Br, loopLabel);
        }

        il.MarkLabel(successLabel);
        il.Emit(OpCodes.Ldc_I4_1);
        il.Emit(OpCodes.Ret);

        il.MarkLabel(returnFalseLabel);
        il.Emit(OpCodes.Ldc_I4_0);
        il.Emit(OpCodes.Ret);

        return dynamicMethod.CreateDelegate<IsMatchDelegate>();
    }

    private static Utf8EmittedDelegate<TryMatchDelegate> CompileGenericTryMatch(
        bool requiresConfirmation,
        bool useAsciiBoundaryOnlyFastConfirmation,
        bool retryOverlappingAfterRejection)
    {
        using var dynamicMethod = Utf8DynamicIlBuilder.Create("Utf8Regex_EmitLiteralFamilyTryMatch", typeof(bool), typeof(Utf8EmittedLiteralFamilyCounter), typeof(Utf8EmittedLiteralFamilyCounter), typeof(ReadOnlySpan<byte>), typeof(int).MakeByRefType(), typeof(int).MakeByRefType());

        var il = dynamicMethod;
        var stateLocal = il.DeclareLocal(typeof(PreparedMultiLiteralScanState));
        var indexLocal = il.DeclareLocal(typeof(int));
        var matchedLengthLocal = il.DeclareLocal(typeof(int));

        var loopLabel = il.DefineLabel();
        var successLabel = il.DefineLabel();
        var returnFalseLabel = il.DefineLabel();

        il.Emit(OpCodes.Ldc_I4_0);
        il.Emit(OpCodes.Ldc_I4_0);
        il.Emit(OpCodes.Ldc_I4_0);
        il.Emit(OpCodes.Newobj, s_scanStateCtor);
        il.Emit(OpCodes.Stloc, stateLocal);

        il.MarkLabel(loopLabel);
        il.Emit(OpCodes.Ldarg_0);
        il.Emit(OpCodes.Ldarg_1);
        il.Emit(OpCodes.Ldloca_S, stateLocal);
        il.Emit(OpCodes.Ldloca_S, indexLocal);
        il.Emit(OpCodes.Ldloca_S, matchedLengthLocal);
        il.Emit(OpCodes.Call, s_tryFindNextNonOverlappingLengthMethod);
        il.Emit(OpCodes.Brfalse, returnFalseLabel);

        if (requiresConfirmation)
        {
            il.Emit(OpCodes.Ldarg_0);
            il.Emit(OpCodes.Ldarg_1);
            il.Emit(OpCodes.Ldloc, indexLocal);
            il.Emit(OpCodes.Ldloc, matchedLengthLocal);
            il.Emit(OpCodes.Call, useAsciiBoundaryOnlyFastConfirmation ? s_confirmAsciiBoundaryOnlyMethod : s_confirmFirstMatchMethod);
            il.Emit(OpCodes.Brtrue, successLabel);
            if (retryOverlappingAfterRejection)
            {
                il.Emit(OpCodes.Ldloca_S, stateLocal);
                il.Emit(OpCodes.Ldloc, indexLocal);
                il.Emit(OpCodes.Call, s_resetAfterRejectedCandidateMethod);
            }
            il.Emit(OpCodes.Br, loopLabel);
        }

        il.MarkLabel(successLabel);
        il.Emit(OpCodes.Ldarg_2);
        il.Emit(OpCodes.Ldloc, indexLocal);
        il.Emit(OpCodes.Stind_I4);
        il.Emit(OpCodes.Ldarg_3);
        il.Emit(OpCodes.Ldloc, matchedLengthLocal);
        il.Emit(OpCodes.Stind_I4);
        il.Emit(OpCodes.Ldc_I4_1);
        il.Emit(OpCodes.Ret);

        il.MarkLabel(returnFalseLabel);
        il.Emit(OpCodes.Ldarg_2);
        il.Emit(OpCodes.Ldc_I4_M1);
        il.Emit(OpCodes.Stind_I4);
        il.Emit(OpCodes.Ldarg_3);
        il.Emit(OpCodes.Ldc_I4_0);
        il.Emit(OpCodes.Stind_I4);
        il.Emit(OpCodes.Ldc_I4_0);
        il.Emit(OpCodes.Ret);

        return dynamicMethod.CreateDelegate<TryMatchDelegate>();
    }

    private static Utf8EmittedDelegate<CountDelegate> CompileSingleLiteralBucketCount(bool useAsciiBoundaryOnlyFastConfirmation, byte[][] literals)
    {
        using var dynamicMethod = Utf8DynamicIlBuilder.Create("Utf8Regex_EmitLiteralFamilyBucketCount", typeof(int), typeof(Utf8EmittedLiteralFamilyCounter), typeof(Utf8EmittedLiteralFamilyCounter), typeof(ReadOnlySpan<byte>));

        var il = dynamicMethod;
        var e = new Utf8IlEmitter(il, s_spanLengthMethod, s_spanItemMethod);
        EmitSingleLiteralBucketBody(
            e,
            literals,
            useAsciiBoundaryOnlyFastConfirmation ? s_confirmAsciiBoundaryOnlyMethod : s_confirmFirstMatchMethod,
            returnOnFirstMatch: false,
            countMatches: true,
            storeMatchResult: false);
        return dynamicMethod.CreateDelegate<CountDelegate>();
    }

    private static Utf8EmittedDelegate<IsMatchDelegate> CompileSingleLiteralBucketIsMatch(bool useAsciiBoundaryOnlyFastConfirmation, byte[][] literals)
    {
        using var dynamicMethod = Utf8DynamicIlBuilder.Create("Utf8Regex_EmitLiteralFamilyBucketIsMatch", typeof(bool), typeof(Utf8EmittedLiteralFamilyCounter), typeof(Utf8EmittedLiteralFamilyCounter), typeof(ReadOnlySpan<byte>));

        var il = dynamicMethod;
        var e = new Utf8IlEmitter(il, s_spanLengthMethod, s_spanItemMethod);
        EmitSingleLiteralBucketBody(
            e,
            literals,
            useAsciiBoundaryOnlyFastConfirmation ? s_confirmAsciiBoundaryOnlyMethod : s_confirmMethod,
            returnOnFirstMatch: true,
            countMatches: false,
            storeMatchResult: false);
        return dynamicMethod.CreateDelegate<IsMatchDelegate>();
    }

    private static Utf8EmittedDelegate<TryMatchDelegate> CompileSingleLiteralBucketTryMatch(bool useAsciiBoundaryOnlyFastConfirmation, byte[][] literals)
    {
        using var dynamicMethod = Utf8DynamicIlBuilder.Create("Utf8Regex_EmitLiteralFamilyBucketTryMatch", typeof(bool), typeof(Utf8EmittedLiteralFamilyCounter), typeof(Utf8EmittedLiteralFamilyCounter), typeof(ReadOnlySpan<byte>), typeof(int).MakeByRefType(), typeof(int).MakeByRefType());

        var il = dynamicMethod;
        var e = new Utf8IlEmitter(il, s_spanLengthMethod, s_spanItemMethod);
        EmitSingleLiteralBucketBody(
            e,
            literals,
            useAsciiBoundaryOnlyFastConfirmation ? s_confirmAsciiBoundaryOnlyMethod : s_confirmFirstMatchMethod,
            returnOnFirstMatch: true,
            countMatches: false,
            storeMatchResult: true);
        return dynamicMethod.CreateDelegate<TryMatchDelegate>();
    }

    private static Utf8EmittedDelegate<CountDelegate> CompileSingleBucketPrefixCount(bool useAsciiBoundaryOnlyFastConfirmation, byte[] commonPrefix, byte[][] literals)
    {
        using var dynamicMethod = Utf8DynamicIlBuilder.Create("Utf8Regex_EmitLiteralFamilyPrefixCount", typeof(int), typeof(Utf8EmittedLiteralFamilyCounter), typeof(Utf8EmittedLiteralFamilyCounter), typeof(ReadOnlySpan<byte>));

        var e = new Utf8IlEmitter(dynamicMethod, s_spanLengthMethod, s_spanItemMethod);
        EmitSingleBucketPrefixBody(
            e,
            commonPrefix,
            literals,
            useAsciiBoundaryOnlyFastConfirmation ? s_confirmAsciiBoundaryOnlyMethod : s_confirmFirstMatchMethod,
            returnOnFirstMatch: false,
            countMatches: true,
            storeMatchResult: false,
            validateAscii: false);
        return dynamicMethod.CreateDelegate<CountDelegate>();
    }

    private static Utf8EmittedDelegate<CountDelegate> CompileAsciiValidatedSingleBucketPrefixCount(byte[] commonPrefix, byte[][] literals)
    {
        using var dynamicMethod = Utf8DynamicIlBuilder.Create("Utf8Regex_EmitAsciiValidatedLiteralFamilyPrefixCount", typeof(int), typeof(Utf8EmittedLiteralFamilyCounter), typeof(Utf8EmittedLiteralFamilyCounter), typeof(ReadOnlySpan<byte>));

        var e = new Utf8IlEmitter(dynamicMethod, s_spanLengthMethod, s_spanItemMethod);
        EmitSingleBucketPrefixBody(
            e,
            commonPrefix,
            literals,
            s_confirmAsciiBoundaryOnlyMethod,
            returnOnFirstMatch: false,
            countMatches: true,
            storeMatchResult: false,
            validateAscii: true);
        return dynamicMethod.CreateDelegate<CountDelegate>();
    }

    private static Utf8EmittedDelegate<IsMatchDelegate> CompileSingleBucketPrefixIsMatch(bool useAsciiBoundaryOnlyFastConfirmation, byte[] commonPrefix, byte[][] literals)
    {
        using var dynamicMethod = Utf8DynamicIlBuilder.Create("Utf8Regex_EmitLiteralFamilyPrefixIsMatch", typeof(bool), typeof(Utf8EmittedLiteralFamilyCounter), typeof(Utf8EmittedLiteralFamilyCounter), typeof(ReadOnlySpan<byte>));

        var e = new Utf8IlEmitter(dynamicMethod, s_spanLengthMethod, s_spanItemMethod);
        EmitSingleBucketPrefixBody(
            e,
            commonPrefix,
            literals,
            useAsciiBoundaryOnlyFastConfirmation ? s_confirmAsciiBoundaryOnlyMethod : s_confirmMethod,
            returnOnFirstMatch: true,
            countMatches: false,
            storeMatchResult: false,
            validateAscii: false);
        return dynamicMethod.CreateDelegate<IsMatchDelegate>();
    }

    private static Utf8EmittedDelegate<TryMatchDelegate> CompileSingleBucketPrefixTryMatch(bool useAsciiBoundaryOnlyFastConfirmation, byte[] commonPrefix, byte[][] literals)
    {
        using var dynamicMethod = Utf8DynamicIlBuilder.Create("Utf8Regex_EmitLiteralFamilyPrefixTryMatch", typeof(bool), typeof(Utf8EmittedLiteralFamilyCounter), typeof(Utf8EmittedLiteralFamilyCounter), typeof(ReadOnlySpan<byte>), typeof(int).MakeByRefType(), typeof(int).MakeByRefType());

        var e = new Utf8IlEmitter(dynamicMethod, s_spanLengthMethod, s_spanItemMethod);
        EmitSingleBucketPrefixBody(
            e,
            commonPrefix,
            literals,
            useAsciiBoundaryOnlyFastConfirmation ? s_confirmAsciiBoundaryOnlyMethod : s_confirmFirstMatchMethod,
            returnOnFirstMatch: true,
            countMatches: false,
            storeMatchResult: true,
            validateAscii: false);
        return dynamicMethod.CreateDelegate<TryMatchDelegate>();
    }

    private static void EmitSingleLiteralBucketBody(
        Utf8IlEmitter e,
        byte[][] literals,
        MethodInfo confirmMethod,
        bool returnOnFirstMatch,
        bool countMatches,
        bool storeMatchResult)
    {
        var searchFromLocal = e.DeclareLocal<int>();
        var inputLengthLocal = e.DeclareLocal<int>();
        var candidateLocal = e.DeclareLocal<int>();
        var currentByteLocal = e.DeclareLocal<int>();
        Utf8IlLocal? countLocal = countMatches ? e.DeclareLocal<int>() : null;

        e.LoadInputLength();
        e.StoreLocal(inputLengthLocal);
        e.LdcI4(0);
        e.StoreLocal(searchFromLocal);
        if (countMatches)
        {
            e.LdcI4(0);
            e.StoreLocal(RequireCountLocal(countLocal));
        }

        var loopLabel = e.DefineLabel();
        var returnLabel = e.DefineLabel();
        var retryLabel = e.DefineLabel();
        var successLabel = e.DefineLabel();
        var failureReturnLabel = e.DefineLabel();
        var nextCandidateLabel = e.DefineLabel();
        var perLiteralLabels = e.AllocateScratch<Utf8IlLabel>(literals.Length);
        var confirmLabels = e.AllocateScratch<Utf8IlLabel>(literals.Length);
        for (var i = 0; i < perLiteralLabels.Length; i++)
        {
            perLiteralLabels[i] = e.DefineLabel();
            confirmLabels[i] = e.DefineLabel();
        }

        e.MarkLabel(loopLabel);
        e.LoadArg(1);
        e.LoadLocal(searchFromLocal);
        e.LdcI4(literals[0][0]);
        e.LdcI4(literals[1][0]);
        if (literals.Length == 2)
        {
            e.Emit(OpCodes.Call, s_findNextCandidate2Method);
        }
        else
        {
            e.LdcI4(literals[2][0]);
            e.Emit(OpCodes.Call, s_findNextCandidate3Method);
        }

        e.StoreLocal(candidateLocal);
        e.LoadLocal(candidateLocal);
        e.LdcI4(0);
        e.Emit(OpCodes.Blt, returnLabel);

        e.LoadInputByte(candidateLocal);
        e.StoreLocal(currentByteLocal);
        var firstBytes = e.AllocateScratch<byte>(literals.Length);
        for (var index = 0; index < literals.Length; index++)
        {
            e.ChargeWork(1);
            firstBytes[index] = literals[index][0];
        }
        e.EmitByteDispatch(currentByteLocal, firstBytes, perLiteralLabels, retryLabel);

        for (var i = 0; i < literals.Length; i++)
        {
            var literal = literals[i];
            var literalMatchedLabel = e.DefineLabel();
            e.MarkLabel(perLiteralLabels[i]);

            e.EmitEnsureAvailable(candidateLocal, inputLengthLocal, literal.Length, literalMatchedLabel, retryLabel);
            e.MarkLabel(literalMatchedLabel);
            e.EmitSpanLiteralEquals(candidateLocal, literal, 1, successLabel, retryLabel);
        }

        e.MarkLabel(retryLabel);
        e.LoadLocal(candidateLocal);
        e.LdcI4(1);
        e.Emit(OpCodes.Add);
        e.StoreLocal(searchFromLocal);
        e.Emit(OpCodes.Br, nextCandidateLabel);

        e.MarkLabel(successLabel);
        EmitMatchedLengthDispatch(e, literals, candidateLocal, currentByteLocal, confirmMethod, returnOnFirstMatch, countMatches, storeMatchResult, countLocal, searchFromLocal, retryLabel, failureReturnLabel, nextCandidateLabel);

        e.MarkLabel(nextCandidateLabel);
        e.Emit(OpCodes.Br, loopLabel);

        e.MarkLabel(failureReturnLabel);
        if (storeMatchResult)
        {
            e.LoadArg(2);
            e.LdcI4(-1);
            e.Emit(OpCodes.Stind_I4);
            e.LoadArg(3);
            e.LdcI4(0);
            e.Emit(OpCodes.Stind_I4);
        }

        e.LdcI4(0);
        e.Emit(OpCodes.Ret);

        e.MarkLabel(returnLabel);
        if (countMatches)
        {
            e.LoadLocal(RequireCountLocal(countLocal));
            e.Emit(OpCodes.Ret);
        }

        if (returnOnFirstMatch)
        {
            if (storeMatchResult)
            {
                e.LoadArg(2);
                e.LdcI4(-1);
                e.Emit(OpCodes.Stind_I4);
                e.LoadArg(3);
                e.LdcI4(0);
                e.Emit(OpCodes.Stind_I4);
            }

            e.LdcI4(0);
            e.Emit(OpCodes.Ret);
        }
    }

    private static void EmitMatchedLengthDispatch(
        Utf8IlEmitter e,
        byte[][] literals,
        Utf8IlLocal candidateLocal,
        Utf8IlLocal currentByteLocal,
        MethodInfo confirmMethod,
        bool returnOnFirstMatch,
        bool countMatches,
        bool storeMatchResult,
        Utf8IlLocal? countLocal,
        Utf8IlLocal searchFromLocal,
        Utf8IlLabel retryLabel,
        Utf8IlLabel failureReturnLabel,
        Utf8IlLabel continueLabel)
    {
        var confirmedLabels = e.AllocateScratch<Utf8IlLabel>(literals.Length);
        for (var i = 0; i < confirmedLabels.Length; i++)
        {
            confirmedLabels[i] = e.DefineLabel();
            e.EmitEqualityBranch(currentByteLocal, literals[i][0], confirmedLabels[i]);
        }

        e.Emit(OpCodes.Br, retryLabel);

        for (var i = 0; i < literals.Length; i++)
        {
            var literal = literals[i];
            e.MarkLabel(confirmedLabels[i]);
            e.LoadArg(0);
            e.LoadArg(1);
            e.LoadLocal(candidateLocal);
            e.LdcI4(literal.Length);
            e.Emit(OpCodes.Call, confirmMethod);
            e.Emit(OpCodes.Brfalse, retryLabel);
            if (countMatches)
            {
                e.LoadLocal(RequireCountLocal(countLocal));
                e.LdcI4(1);
                e.Emit(OpCodes.Add);
                e.StoreLocal(RequireCountLocal(countLocal));
                e.LoadLocal(candidateLocal);
                e.LdcI4(literal.Length);
                e.Emit(OpCodes.Add);
                e.StoreLocal(searchFromLocal);
                e.Emit(OpCodes.Br, continueLabel);
            }

            if (returnOnFirstMatch)
            {
                if (!storeMatchResult)
                {
                    e.LdcI4(1);
                    e.Emit(OpCodes.Ret);
                }
                else
                {
                    e.LoadArg(2);
                    e.LoadLocal(candidateLocal);
                    e.Emit(OpCodes.Stind_I4);
                    e.LoadArg(3);
                    e.LdcI4(literal.Length);
                    e.Emit(OpCodes.Stind_I4);
                    e.LdcI4(1);
                    e.Emit(OpCodes.Ret);
                }
            }

            e.Emit(OpCodes.Br, failureReturnLabel);
        }
    }

    private static void EmitSingleBucketPrefixBody(
        Utf8IlEmitter e,
        byte[] commonPrefix,
        byte[][] literals,
        MethodInfo confirmMethod,
        bool returnOnFirstMatch,
        bool countMatches,
        bool storeMatchResult,
        bool validateAscii)
    {
        var searchFromLocal = e.DeclareLocal<int>();
        var inputLengthLocal = e.DeclareLocal<int>();
        var candidateLocal = e.DeclareLocal<int>();
        var currentByteLocal = e.DeclareLocal<int>();
        Utf8IlLocal? countLocal = countMatches ? e.DeclareLocal<int>() : null;

        e.LoadInputLength();
        e.StoreLocal(inputLengthLocal);
        e.LdcI4(0);
        e.StoreLocal(searchFromLocal);
        if (countMatches)
        {
            e.LdcI4(0);
            e.StoreLocal(RequireCountLocal(countLocal));
        }

        var loopLabel = e.DefineLabel();
        var returnLabel = e.DefineLabel();
        var retryLabel = e.DefineLabel();
        var prefixMatchedLabel = e.DefineLabel();
        var successLabel = e.DefineLabel();
        var failureReturnLabel = e.DefineLabel();
        var invalidAsciiReturnLabel = e.DefineLabel();
        var perLiteralLabels = e.AllocateScratch<Utf8IlLabel>(literals.Length);
        var confirmLabels = e.AllocateScratch<Utf8IlLabel>(literals.Length);
        for (var i = 0; i < perLiteralLabels.Length; i++)
        {
            perLiteralLabels[i] = e.DefineLabel();
            confirmLabels[i] = e.DefineLabel();
        }

        e.MarkLabel(loopLabel);
        e.LoadArg(1);
        e.LoadLocal(searchFromLocal);
        e.LdcI4(commonPrefix[0]);
        e.Emit(OpCodes.Call, validateAscii ? s_findNextAsciiCandidate1Method : s_findNextCandidate1Method);
        e.StoreLocal(candidateLocal);
        if (validateAscii)
        {
            e.LoadLocal(candidateLocal);
            e.LdcI4(-2);
            e.Emit(OpCodes.Beq, invalidAsciiReturnLabel);
        }

        e.LoadLocal(candidateLocal);
        e.LdcI4(0);
        e.Emit(OpCodes.Blt, returnLabel);

        e.EmitEnsureAvailable(candidateLocal, inputLengthLocal, commonPrefix.Length + 1, prefixMatchedLabel, retryLabel);
        e.MarkLabel(prefixMatchedLabel);
        e.EmitSpanLiteralEquals(candidateLocal, commonPrefix, 1, successLabel, retryLabel);

        e.MarkLabel(successLabel);
        e.LoadInputByte(candidateLocal, commonPrefix.Length);
        e.StoreLocal(currentByteLocal);
        EmitPrefixDiscriminatorDispatch(e, commonPrefix, literals, currentByteLocal, perLiteralLabels, retryLabel);

        for (var i = 0; i < literals.Length; i++)
        {
            var literal = literals[i];
            var literalMatchedLabel = e.DefineLabel();
            e.MarkLabel(perLiteralLabels[i]);
            e.EmitEnsureAvailable(candidateLocal, inputLengthLocal, literal.Length, literalMatchedLabel, retryLabel);
            e.MarkLabel(literalMatchedLabel);
            e.EmitSpanLiteralEquals(candidateLocal, literal, commonPrefix.Length + 1, successLabel: confirmLabels[i], failureLabel: retryLabel);

            e.MarkLabel(confirmLabels[i]);
            e.LoadArg(0);
            e.LoadArg(1);
            e.LoadLocal(candidateLocal);
            e.LdcI4(literal.Length);
            e.Emit(OpCodes.Call, confirmMethod);
            e.Emit(OpCodes.Brfalse, retryLabel);

            if (countMatches)
            {
                e.LoadLocal(RequireCountLocal(countLocal));
                e.LdcI4(1);
                e.Emit(OpCodes.Add);
                e.StoreLocal(RequireCountLocal(countLocal));
                e.LoadLocal(candidateLocal);
                e.LdcI4(literal.Length);
                e.Emit(OpCodes.Add);
                e.StoreLocal(searchFromLocal);
                e.Emit(OpCodes.Br, loopLabel);
            }

            if (!storeMatchResult)
            {
                e.LdcI4(1);
                e.Emit(OpCodes.Ret);
            }

            e.LoadArg(2);
            e.LoadLocal(candidateLocal);
            e.Emit(OpCodes.Stind_I4);
            e.LoadArg(3);
            e.LdcI4(literal.Length);
            e.Emit(OpCodes.Stind_I4);
            e.LdcI4(1);
            e.Emit(OpCodes.Ret);
        }

        e.MarkLabel(retryLabel);
        e.LoadLocal(candidateLocal);
        e.LdcI4(1);
        e.Emit(OpCodes.Add);
        e.StoreLocal(searchFromLocal);
        e.Emit(OpCodes.Br, loopLabel);

        e.MarkLabel(failureReturnLabel);
        if (storeMatchResult)
        {
            e.LoadArg(2);
            e.LdcI4(-1);
            e.Emit(OpCodes.Stind_I4);
            e.LoadArg(3);
            e.LdcI4(0);
            e.Emit(OpCodes.Stind_I4);
        }

        e.LdcI4(0);
        e.Emit(OpCodes.Ret);

        e.MarkLabel(invalidAsciiReturnLabel);
        e.LdcI4(-1);
        e.Emit(OpCodes.Ret);

        e.MarkLabel(returnLabel);
        if (countMatches)
        {
            e.LoadLocal(RequireCountLocal(countLocal));
            e.Emit(OpCodes.Ret);
            return;
        }

        if (returnOnFirstMatch)
        {
            if (storeMatchResult)
            {
                e.LoadArg(2);
                e.LdcI4(-1);
                e.Emit(OpCodes.Stind_I4);
                e.LoadArg(3);
                e.LdcI4(0);
                e.Emit(OpCodes.Stind_I4);
            }

            e.LdcI4(0);
            e.Emit(OpCodes.Ret);
            return;
        }

        e.Emit(OpCodes.Br, failureReturnLabel);
    }

    private static Utf8IlLocal RequireCountLocal(Utf8IlLocal? countLocal)
    {
        return countLocal ?? throw new InvalidOperationException("A count program requires a count local.");
    }

    private static void EmitPrefixDiscriminatorDispatch(
        Utf8IlEmitter e,
        byte[] commonPrefix,
        byte[][] literals,
        Utf8IlLocal currentByteLocal,
        ReadOnlySpan<Utf8IlLabel> labels,
        Utf8IlLabel retryLabel)
    {
        for (var i = 0; i < literals.Length; i++)
        {
            if (literals[i].Length <= commonPrefix.Length)
            {
                continue;
            }

            e.EmitEqualityBranch(currentByteLocal, literals[i][commonPrefix.Length], labels[i]);
        }

        e.Emit(OpCodes.Br, retryLabel);
    }
}
