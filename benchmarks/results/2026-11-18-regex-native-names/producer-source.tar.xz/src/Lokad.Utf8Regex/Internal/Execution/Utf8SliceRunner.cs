using System.Buffers;
using System.Globalization;
using System.Runtime.CompilerServices;
using Lokad.Utf8Regex.Internal.Input;
using Lokad.Utf8Regex.Internal.Planning;

namespace Lokad.Utf8Regex.Internal.Execution;

/// <summary>Resume actions for explicit slice backtrack frames.</summary>
internal enum Utf8SliceResumeKind : byte
{
    Alternation = 0,
    RepeatUnwind = 1,
    RepeatContinue = 2,
    Assertion = 3,
    Atomic = 4,
}

internal struct Utf8SliceFrame
{
    internal Utf8SliceResumeKind ResumeKind;
    internal int Target;
    internal int InputIndex;
    internal int TrailCount;
    internal int Aux;
    internal int Count;
    internal int JournalCount;
}

internal struct Utf8SliceTrailEntry
{
    internal int Slot;
    internal int OldValue;
    internal int NewValue;
    // Keep the journal entry at sixteen bytes as capture markers are added.
    private byte _flags;
    internal bool IsStart { readonly get => (_flags & 1) != 0; set => _flags = (byte)(value ? _flags | 1 : _flags & ~1); }
    internal bool IsHead { readonly get => (_flags & 2) != 0; set => _flags = (byte)(value ? _flags | 2 : _flags & ~2); }
    internal bool IsRestore { readonly get => (_flags & 4) != 0; set => _flags = (byte)(value ? _flags | 4 : _flags & ~4); }
    internal bool IsOpening { readonly get => (_flags & 8) != 0; set => _flags = (byte)(value ? _flags | 8 : _flags & ~8); }
    internal bool IsClosing { readonly get => (_flags & 16) != 0; set => _flags = (byte)(value ? _flags | 16 : _flags & ~16); }
}

internal struct Utf8SliceBalanceEntry
{
    internal int Start;
    internal int End;
    internal int Prev;
}

internal struct Utf8SliceCountMutation
{
    internal int RepeatId;
    internal int OldCount;
    internal int OldPosition;
}

internal readonly struct Utf8SliceMatchOutcome
{
    // Expose field stores in hot repeat/capture return paths.
    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    internal Utf8SliceMatchOutcome(bool isMatch, int endIndex, Utf8ExecutionLimitKind breach, int[][]? captureStarts, int[][]? captureLengths)
    {
        IsMatch = isMatch;
        EndIndex = endIndex;
        Breach = breach;
        CaptureStarts = captureStarts;
        CaptureLengths = captureLengths;
    }

    internal bool IsMatch { get; }
    internal int EndIndex { get; }
    internal Utf8ExecutionLimitKind Breach { get; }
    internal int[][]? CaptureStarts { get; }
    internal int[][]? CaptureLengths { get; }
}

internal readonly struct Utf8SliceSlots
{
    internal Utf8SliceSlots(int[] starts, int[] ends)
    {
        Starts = starts;
        Ends = ends;
    }

    internal int[] Starts { get; }
    internal int[] Ends { get; }
}

internal readonly struct Utf8SliceSearchOutcome
{
    internal Utf8SliceSearchOutcome(
        bool found, int startByte, int endByte,
        int[][]? captureStarts, int[][]? captureLengths, Utf8ExecutionLimitKind breach)
    {
        Found = found;
        StartByte = startByte;
        EndByte = endByte;
        CaptureStarts = captureStarts;
        CaptureLengths = captureLengths;
        Breach = breach;
    }

    internal bool Found { get; }
    internal int StartByte { get; }
    internal int EndByte { get; }
    internal int[][]? CaptureStarts { get; }
    internal int[][]? CaptureLengths { get; }
    internal Utf8ExecutionLimitKind Breach { get; }
}

internal readonly struct Utf8SliceCountOutcome
{
    internal Utf8SliceCountOutcome(int count, Utf8ExecutionLimitKind breach)
    {
        Count = count;
        Breach = breach;
    }

    internal int Count { get; }
    internal Utf8ExecutionLimitKind Breach { get; }
}

/// <summary>Explicit-frame backtracking runner over immutable slice programs.
/// One budgeted step per visited instruction; depth is the live frame count.
/// Repeat count/position writes go through a mutation journal so backtracking
/// past one repeat restores sibling repeats to their push-time state; frames,
/// trail chunks, journal chunks, tables, counts, and capture slots are
/// ledger-admitted before acquisition and released on every return path,
/// including breach, cancellation, and disposal. Capture slot pairs hold
/// start/end input indexes, -1 when unset; the trail journal restores them.</summary>
internal static partial class Utf8SliceRunner
{
    internal const int FrameChunkCapacity = 16;
    internal const int TrailChunkCapacity = 8;
    internal const int JournalChunkCapacity = 32;
    internal const int BalanceChunkCapacity = 128;
    internal const int ChunkTableCapacity = 4;

    internal static int FrameReserveBytes => checked((int)Utf8ConstructionBudget.ArrayBytes<Utf8SliceFrame>(FrameChunkCapacity));
    internal static int TrailReserveBytes => checked((int)Utf8ConstructionBudget.ArrayBytes<Utf8SliceTrailEntry>(TrailChunkCapacity));
    internal static int JournalReserveBytes => checked((int)Utf8ConstructionBudget.ArrayBytes<Utf8SliceCountMutation>(JournalChunkCapacity));
    internal static int BalanceReserveBytes => checked((int)Utf8ConstructionBudget.ArrayBytes<Utf8SliceBalanceEntry>(BalanceChunkCapacity));

    internal static Utf8SliceSlots RentSlots(int groups, ref Utf8SliceInvocation invocation)
    {
        if (TryRentSlots(groups, ref invocation, out var slots) != Utf8ExecutionLimitKind.None)
            throw new InvalidOperationException("Owned slice capture slots exceeded the invocation storage budget.");
        return slots;
    }

    internal static Utf8ExecutionLimitKind TryRentSlots(int groups, ref Utf8SliceInvocation invocation, out Utf8SliceSlots slots)
    {
        slots = default;
        if (groups == 0)
        {
            slots = new Utf8SliceSlots(Array.Empty<int>(), Array.Empty<int>());
            return Utf8ExecutionLimitKind.None;
        }

        var bytes = checked(Utf8ConstructionBudget.ArrayBytes<int>(groups) * 2);
        var breach = invocation.TryReserveWorking(bytes);
        if (breach != Utf8ExecutionLimitKind.None)
        {
            return breach;
        }

        try
        {
            var starts = new int[groups];
            var ends = new int[groups];
            Array.Fill(starts, -1);
            Array.Fill(ends, -1);
            slots = new Utf8SliceSlots(starts, ends);
            return Utf8ExecutionLimitKind.None;
        }
        catch
        {
            invocation.Ledger.Release(bytes);
            throw;
        }
    }

    internal static void ReleaseSlots(Utf8SliceSlots slots, ref Utf8SliceInvocation invocation)
    {
        if (slots.Starts.Length != 0)
        {
            invocation.Ledger.Release(checked(Utf8ConstructionBudget.ArrayBytes<int>(slots.Starts.Length)
                + Utf8ConstructionBudget.ArrayBytes<int>(slots.Ends.Length)));
        }
    }

    internal static void ReleaseHistory(int[][]? starts, int[][]? lengths, ref Utf8SliceInvocation invocation)
    {
        if (starts is null || lengths is null)
        {
            return;
        }

        invocation.Ledger.Release(Utf8ConstructionBudget.ArrayBytes<int[]>(starts.Length));
        invocation.Ledger.Release(Utf8ConstructionBudget.ArrayBytes<int[]>(lengths.Length));
        for (var group = 0; group < starts.Length && group < lengths.Length; group++)
        {
            if (starts[group].Length != 0)
            {
                invocation.Ledger.Release(Utf8ConstructionBudget.ArrayBytes<int>(starts[group].Length));
            }

            if (lengths[group].Length != 0)
            {
                invocation.Ledger.Release(Utf8ConstructionBudget.ArrayBytes<int>(lengths[group].Length));
            }
        }
    }

    // Width of the scalar ending at rightEdge (validated input): ASCII is
    // one byte, longer scalars measure back from their lead. Mid-scalar
    // edges and out-of-range positions fail closed so mirrored right-to-left
    // attempts cannot report unaligned starts. Shared by the mirrored consuming arms.
    private static bool TryGetScalarWidthEndingAt(ReadOnlySpan<byte> input, int rightEdge, out int width)
    {
        width = 0;
        if (rightEdge <= 0 || rightEdge > input.Length)
        {
            return false;
        }

        var leadIndex = rightEdge - 1;
        if (input[leadIndex] < 0x80)
        {
            width = 1;
            return true;
        }

        var steps = 0;
        while ((input[leadIndex] & 0xC0) == 0x80)
        {
            leadIndex--;
            steps++;
            if (leadIndex < 0 || steps > 3)
            {
                return false;
            }
        }

        var lead = input[leadIndex];
        if (lead < 0xC2 || lead >= 0xF5)
        {
            return false;
        }

        width = lead < 0xE0 ? 2 : lead < 0xF0 ? 3 : 4;
        return leadIndex + width == rightEdge;
    }

    private static bool TryReadScalar(ReadOnlySpan<byte> input, int edge, bool rightToLeft, out Rune scalar, out int width)
    {
        scalar = default;
        width = 0;
        if (rightToLeft)
        {
            if (!TryGetScalarWidthEndingAt(input, edge, out width)) return false;
            edge -= width;
        }
        if ((uint)edge >= (uint)input.Length) return false;
        if (Rune.DecodeFromUtf8(input.Slice(edge), out scalar, out var decodedWidth) != OperationStatus.Done) return false;
        if (rightToLeft && decodedWidth != width) return false;
        width = decodedWidth;
        return true;
    }

    private static bool IsWordScalarStartingAt(Utf8SliceProgram program, in Utf8SliceInstruction instruction,
        ReadOnlySpan<byte> input, int index)
        => TryReadScalar(input, index, false, out var scalar, out _) &&
            Utf8SliceScalarClasses.IsBoundaryWord(scalar, program, instruction);

    private static bool MatchesBoundary(Utf8SliceProgram program, in Utf8SliceInstruction instruction,
        ReadOnlySpan<byte> input, int index)
    {
        // Callers have checked the scalar-aligned position. The VM and its
        // complete boundary root classify the same two complete neighbors.
        var beforeWord = false;
        if (index > 0)
        {
            var previous = index - 1;
            while (previous > 0 && (input[previous] & 0xC0) == 0x80) previous--;
            beforeWord = IsWordScalarStartingAt(program, instruction, input, previous);
        }
        var afterWord = index < input.Length && IsWordScalarStartingAt(program, instruction, input, index);
        return (beforeWord != afterWord) == (instruction.A != 0);
    }

    internal static Utf8SliceMatchOutcome TryMatchAt(
        Utf8SliceProgram program,
        ReadOnlySpan<byte> input,
        int start,
        int[] captureStarts,
        int[] captureEnds,
        bool startIsScalarBoundary,
        ref Utf8SliceInvocation invocation)
    {
        return TryMatchAt(program, input, start, captureStarts, captureEnds, false, startIsScalarBoundary, ref invocation);
    }

    internal static Utf8SliceMatchOutcome TryMatchAt(
        Utf8SliceProgram program,
        ReadOnlySpan<byte> input,
        int start,
        int[] captureStarts,
        int[] captureEnds,
        bool collectHistory,
        bool startIsScalarBoundary,
        ref Utf8SliceInvocation invocation)
    {
        return TryMatchAt(program, input, start, captureStarts, captureEnds, collectHistory, false, startIsScalarBoundary, ref invocation);
    }

    internal static Utf8SliceMatchOutcome TryMatchAt(
        Utf8SliceProgram program,
        ReadOnlySpan<byte> input,
        int start,
        int[] captureStarts,
        int[] captureEnds,
        bool collectHistory,
        bool requireNonEmpty,
        bool startIsScalarBoundary,
        ref Utf8SliceInvocation invocation)
    {
        if (program.IsNonBacktracking)
        {
            if (!startIsScalarBoundary || (uint)start > (uint)input.Length ||
                start < input.Length && (input[start] & 0xC0) == 0x80)
                return new(false, -1, Utf8ExecutionLimitKind.None, null, null);
            var outcome = RunNonBacktracking(program, input, start, captureStarts, captureEnds,
                collectHistory, true, requireNonEmpty, ref invocation);
            return new(outcome.Found, outcome.EndByte, outcome.Breach, outcome.CaptureStarts, outcome.CaptureLengths);
        }
        var workspace = new AttemptWorkspace();
        try
        {
            return TryMatchAt(program, input, start, captureStarts, captureEnds,
                collectHistory, requireNonEmpty, startIsScalarBoundary, ref workspace, ref invocation);
        }
        finally { workspace.Release(ref invocation); }
    }

    internal static Utf8SliceMatchOutcome TryMatchAt(
        Utf8SliceProgram program,
        ReadOnlySpan<byte> input,
        int start,
        int[] captureStarts,
        int[] captureEnds,
        bool collectHistory,
        bool requireNonEmpty,
        bool startIsScalarBoundary,
        ref AttemptWorkspace workspace,
        ref Utf8SliceInvocation invocation)
    {
        // Profile cursors can reuse this admitted workspace across candidate
        // attempts while preserving their own empty-match and anchor progress.
        if (program.IsNonBacktracking)
            return TryMatchAt(program, input, start, captureStarts, captureEnds,
                collectHistory, requireNonEmpty, startIsScalarBoundary, ref invocation);
        if (!startIsScalarBoundary || (uint)start > (uint)input.Length ||
            start < input.Length && (input[start] & 0xC0) == 0x80)
            return new Utf8SliceMatchOutcome(false, -1, Utf8ExecutionLimitKind.None, null, null);

        if (!workspace.Initialized)
        {
            var breach = workspace.Initialize(program, ref invocation);
            if (breach != Utf8ExecutionLimitKind.None)
                return new(false, -1, breach, null, null);
        }
        var counts = workspace.Counts;
        var positions = workspace.Positions;
        var heads = workspace.Heads;
        if (counts.Length != 0) Array.Fill(counts, -1);
        if (positions.Length != 0) Array.Fill(positions, -1);
        if (captureStarts.Length != 0) Array.Fill(captureStarts, -1);
        if (captureEnds.Length != 0) Array.Fill(captureEnds, -1);
        if (heads.Length != 0) Array.Fill(heads, -1);
        workspace.Stacks.ResetAttempt();
        var completed = false;
        try
        {
            Utf8SliceMatchOutcome attempt;
            if (!collectHistory && TryRunTerminalCaptureRoot(program, input, start,
                captureStarts, captureEnds, ref workspace.Stacks, ref invocation, out attempt))
            {
                // A proved complete root has no continuation or capture rollback.
            }
            else if (!collectHistory && program.GroupCount == 0 && !program.RightToLeft &&
                program.Assertions.Length == 0 && program.Instructions is { Length: 2 } boundaryCode &&
                boundaryCode[0].Kind == Utf8SliceInstructionKind.Boundary &&
                boundaryCode[1].Kind == Utf8SliceInstructionKind.Accept)
            {
                // Keep initial workspace admission and reset above. This complete
                // root has no continuation or consuming nonempty alternative. Preserve
                // VM step/deadline cadence; callers retain final publication checks.
                var breach = invocation.TryChargeStep();
                invocation.Budget.ThrowIfCancellationRequested();
                if (breach != Utf8ExecutionLimitKind.None)
                    return new(false, -1, breach, null, null);
                var matched = !requireNonEmpty && MatchesBoundary(program, boundaryCode[0], input, start);
                breach = invocation.TryChargeStep();
                invocation.Budget.ThrowIfCancellationRequested();
                attempt = new(matched && breach == Utf8ExecutionLimitKind.None,
                    matched && breach == Utf8ExecutionLimitKind.None ? start : -1, breach, null, null);
            }
            else if (!collectHistory && CanRunTerminalClassRepeat(program))
            {
                // This complete repeat has no assertion continuation to drive.
                attempt = RunTerminalClassRepeat(program, input, start, requireNonEmpty, ref invocation);
            }
            else if (!collectHistory && program.Assertions.Length == 0)
            {
                // This root cannot suspend or publish capture history. Execute
                // the same VM without the unused assertion-continuation driver.
                var current = new AssertionCursor(program, start, counts, positions,
                    requireNonEmpty, startIsScalarBoundary, workspace.Stacks.FrameCount);
                try
                {
                    attempt = RunSegment(input, captureStarts, captureEnds, heads, ref current,
                        false, preserveCaptureTrail: false, ref workspace.Stacks, ref invocation, out _);
                }
                finally
                {
                    workspace.Counts = current.Counts;
                    workspace.Positions = current.Positions;
                }
            }
            else
                attempt = RunFrom(program, input, start, captureStarts, captureEnds, ref workspace.Counts, ref workspace.Positions, heads, collectHistory, requireNonEmpty, startIsScalarBoundary, ref workspace.Stacks, ref invocation);
            if (attempt.IsMatch && program.RightToLeft)
            {
                // Mirrored runs record right edges at capture starts and left
                // edges at capture ends; projection and backreferences read
                // normalized spans while the trail stays raw and consistent.
                for (var slot = 0; slot < captureStarts.Length; slot++)
                {
                    if (captureStarts[slot] >= 0 && captureEnds[slot] >= 0 && captureEnds[slot] < captureStarts[slot])
                    {
                        var normalizedStart = captureEnds[slot];
                        captureEnds[slot] = captureStarts[slot];
                        captureStarts[slot] = normalizedStart;
                    }
                }
            }

            completed = attempt.IsMatch;
            return attempt;
        }
        finally
        {
            if (!completed)
            {
                // A committed positive assertion still belongs to this attempt;
                // failure or cancellation must not publish its capture slots.
                if (captureStarts.Length != 0) Array.Fill(captureStarts, -1);
                if (captureEnds.Length != 0) Array.Fill(captureEnds, -1);
            }
        }
    }

    // Callers supply valid UTF-8. Candidates and results use original byte
    // coordinates; no validity pass or subject coordinate map is required.
    internal static Utf8SliceSearchOutcome TryFindFirst(
        Utf8SliceProgram program, ReadOnlySpan<byte> input, int fromByte,
        int[] captureStarts, int[] captureEnds, bool collectHistory,
        ref Utf8SliceInvocation invocation, in Utf8SearchPlan candidatePlan = default)
    {
        var workspace = new AttemptWorkspace();
        try
        {
            return TryFindFirst(program, input, fromByte, captureStarts, captureEnds,
                collectHistory, ref workspace, ref invocation, candidatePlan);
        }
        finally { workspace.Release(ref invocation); }
    }

    // Repeated searches for one program/invocation can keep their admitted
    // scratch. The caller releases it; each attempt still resets all VM state.
    internal static Utf8SliceSearchOutcome TryFindFirst(
        Utf8SliceProgram program, ReadOnlySpan<byte> input, int fromByte,
        int[] captureStarts, int[] captureEnds, bool collectHistory,
        ref AttemptWorkspace workspace, ref Utf8SliceInvocation invocation, in Utf8SearchPlan candidatePlan = default)
    {
        invocation.Budget.ThrowIfCancellationRequested();
        if ((uint)fromByte > (uint)input.Length ||
            fromByte < input.Length && (input[fromByte] & 0xC0) == 0x80)
            return new(false, -1, -1, null, null, Utf8ExecutionLimitKind.None);
        if (program.IsNonBacktracking)
            return RunNonBacktracking(program, input, fromByte, captureStarts, captureEnds,
                collectHistory, false, false, ref invocation);
        var first = program.Instructions[0];
        var seekBeginning = !program.RightToLeft && first.Kind == Utf8SliceInstructionKind.Anchor &&
            first.A == (int)Utf8SliceAnchorKind.Beginning;
        byte leadingLast = 0, secondLast = 0;
        var second = -1;
        // Borrow Count's bounded necessary-start proof. Every survivor still
        // executes the VM; empty/contiguous/mirrored/folded roots stay unchanged.
        var leading = !seekBeginning && !program.RightToLeft && !program.IgnoreCase &&
            !program.CanMatchEmpty && !program.HasContiguousAnchor
            ? GetLeadingAsciiCandidate(program, out leadingLast, out second, out secondLast) : -1;
        // Keep the cheaper existing head proof when available. Prepared prefix
        // search fills its gaps, including multi-alternative and UTF-8 starts.
        var seekLiteral = leading < 0 && !seekBeginning && CanSeekExactPrefix(program, candidatePlan);
        if (leading >= 0 || seekLiteral)
        {
            // A miss can avoid local scratch, but not an enclosing storage loan.
            var admission = invocation.TryReserveWorking(0);
            if (admission != Utf8ExecutionLimitKind.None)
                return new(false, -1, -1, null, null, admission);
        }
        for (var position = fromByte; position >= 0; position = AdvancePastScalar(input, position, program.RightToLeft))
        {
            if (seekLiteral)
            {
                var seekBreach = TrySeekExactPrefix(candidatePlan, input, ref position, ref invocation);
                if (seekBreach != Utf8ExecutionLimitKind.None)
                    return new(false, -1, -1, null, null, seekBreach);
                if (position < 0)
                    return new(false, -1, -1, null, null,
                        new Utf8InvocationBufferControl(ref invocation).TryChargeWorkspaceStep());
            }
            if (leading >= 0 && ((uint)position >= (uint)input.Length ||
                (uint)(input[position] - leading) > (uint)(leadingLast - leading)))
            {
                var seekBreach = TrySeekAsciiCandidate(input, ref position, (byte)leading, leadingLast, ref invocation);
                if (seekBreach != Utf8ExecutionLimitKind.None)
                    return new(false, -1, -1, null, null, seekBreach);
                if (position < 0)
                    return new(false, -1, -1, null, null,
                        new Utf8InvocationBufferControl(ref invocation).TryChargeWorkspaceStep());
            }
            if (seekBeginning)
            {
                var seekBreach = TrySeekBeginning(program, input, ref position, ref invocation);
                if (seekBreach != Utf8ExecutionLimitKind.None)
                    return new(false, -1, -1, null, null, seekBreach);
                if (position < 0) break;
            }
            var breach = invocation.TryChargeInputStep();
            if (breach != Utf8ExecutionLimitKind.None)
                return new(false, -1, -1, null, null, breach);
            invocation.Budget.ThrowIfCancellationRequested();
            // Charge even rejected neighbours: dense false heads must retain
            // bounded work and the original interruption authority.
            if (leading >= 0 && second >= 0 && ((uint)(position + 1) >= (uint)input.Length ||
                (uint)(input[position + 1] - second) > (uint)(secondLast - second)))
                continue;
            var outcome = TryMatchAt(program, input, position, captureStarts, captureEnds, collectHistory, false, true, ref workspace, ref invocation);
            if (outcome.Breach != Utf8ExecutionLimitKind.None)
                return new(false, -1, -1, null, null, outcome.Breach);
            if (outcome.IsMatch)
                return new(true, Math.Min(position, outcome.EndIndex), Math.Max(position, outcome.EndIndex),
                    outcome.CaptureStarts, outcome.CaptureLengths, Utf8ExecutionLimitKind.None);
        }
        return new(false, -1, -1, null, null, Utf8ExecutionLimitKind.None);
    }

    // -1 is the exhausted sentinel in either direction; avoid Length + 1 overflow.
    internal static int AdvancePastScalar(ReadOnlySpan<byte> input, int position, bool reverse)
        => TryReadScalar(input, position, reverse, out _, out var width)
            ? position + (reverse ? -width : width) : -1;

    // Count and primary matching share the same necessary-prefix proof. Every
    // candidate is still verified by the scalar VM under the original invocation.
    private static bool CanSeekExactPrefix(Utf8SliceProgram program, in Utf8SearchPlan candidatePlan)
        => !program.RightToLeft && !program.CanMatchEmpty &&
            !program.HasContiguousAnchor && !program.IgnoreCase && candidatePlan.CanGuideFallbackStarts &&
            candidatePlan.Distance == 0 && candidatePlan.Kind is
                Utf8SearchKind.ExactAsciiLiteral or
                Utf8SearchKind.ExactAsciiLiterals or Utf8SearchKind.ExactUtf8Literals;

    private static Utf8ExecutionLimitKind TrySeekExactPrefix(in Utf8SearchPlan candidatePlan,
        ReadOnlySpan<byte> input, ref int position, ref Utf8SliceInvocation invocation)
    {
        if (candidatePlan.LiteralSearch is { Length: > 0 } literal)
            return Utf8SearchExecutor.TryFindLiteralCandidate(literal, input, position,
                input.Length - literal.Length, false, ref invocation, out position);
        var breach = Utf8SearchExecutor.TryFindLiteralFamilyCandidate(
            candidatePlan.AlternateLiteralsUtf8 ?? [], false, input, position, input.Length,
            false, ref invocation, out var candidate, out var found);
        position = found ? candidate.Index : -1;
        return breach;
    }

    // Only an initial mandatory anchor proves that other starts cannot match.
    // Callers establish LTR/backtracking eligibility. An immediate exact ASCII
    // literal can also reject a start before capture reset/workspace acquisition.
    // LF is one byte and cannot occur inside a scalar. The caller establishes
    // valid UTF-8; this filter neither restricts a match's end nor its body.
    internal static Utf8ExecutionLimitKind TrySeekBeginning(Utf8SliceProgram program,
        ReadOnlySpan<byte> input, ref int position, ref Utf8SliceInvocation invocation)
    {
        var multiline = program.Instructions[0].B != 0;
        var leadingLiteral = !program.IgnoreCase && !program.CanMatchEmpty &&
            program.Instructions.Length > 1 &&
            program.Instructions[1] is { Kind: Utf8SliceInstructionKind.Literal, B: 0 } leading &&
            (uint)leading.A < 0x80 ? leading.A : -1;
        if (multiline && leadingLiteral >= 0)
        {
            var breach = invocation.TryChargeInputStep();
            if (breach != Utf8ExecutionLimitKind.None) return breach;
            invocation.Budget.ThrowIfCancellationRequested();
            if (position < input.Length && (position == 0 || input[position - 1] == (byte)'\n') &&
                input[position] == leadingLiteral) return Utf8ExecutionLimitKind.None;

            // The same required first scalar admits a checked byte-pair search.
            // Only candidate discovery changes; the original VM verifies each
            // survivor. One-byte overlap preserves pairs crossing block edges.
            Span<byte> pair = stackalloc byte[2];
            pair[0] = (byte)'\n';
            pair[1] = (byte)leadingLiteral;
            while (input.Length - position >= 2)
            {
                breach = invocation.TryChargeInputStep();
                if (breach != Utf8ExecutionLimitKind.None) return breach;
                var length = Math.Min(2048, input.Length - position);
                var relative = input.Slice(position, length).IndexOf(pair);
                invocation.Budget.ThrowIfCancellationRequested();
                if (relative >= 0)
                { position += relative + 1; return Utf8ExecutionLimitKind.None; }
                position += length - 1;
            }
            position = -1;
            return Utf8ExecutionLimitKind.None;
        }
        while (true)
        {
            if (position != 0 && !multiline) { position = -1; return Utf8ExecutionLimitKind.None; }
            if (position != 0 && input[position - 1] != (byte)'\n')
            {
                while (position < input.Length)
                {
                    var seekBreach = invocation.TryChargeInputStep();
                    if (seekBreach != Utf8ExecutionLimitKind.None) return seekBreach;
                    var length = Math.Min(2048, input.Length - position);
                    var newline = input.Slice(position, length).IndexOf((byte)'\n');
                    position += newline >= 0 ? newline + 1 : length;
                    if (newline >= 0) break;
                }
                // A trailing LF still admits the final empty line for patterns
                // without a mandatory literal; exhaustion elsewhere does not.
                if (position == input.Length && input[position - 1] != (byte)'\n')
                { position = -1; return Utf8ExecutionLimitKind.None; }
            }
            if (leadingLiteral < 0) return Utf8ExecutionLimitKind.None;
            // A mandatory first literal rejects this line start before VM state
            // acquisition. This is necessary only; survivors still run the VM.
            var breach = invocation.TryChargeInputStep();
            if (breach != Utf8ExecutionLimitKind.None) return breach;
            invocation.Budget.ThrowIfCancellationRequested();
            if (position == input.Length) { position = -1; return Utf8ExecutionLimitKind.None; }
            if (input[position] == leadingLiteral) return Utf8ExecutionLimitKind.None;
            position = AdvancePastScalar(input, position, false);
            if (position < 0) return Utf8ExecutionLimitKind.None;
        }
    }

    internal static Utf8SliceMatchOutcome IsMatch(
        Utf8SliceProgram program, ReadOnlySpan<byte> input,
        int[] captureStarts, int[] captureEnds, ref Utf8SliceInvocation invocation)
    {
        var start = program.RightToLeft ? input.Length : 0;
        invocation.AnchorOriginByte = start;
        var outcome = TryFindFirst(program, input, start, captureStarts, captureEnds, false, ref invocation);
        return new(outcome.Found, outcome.EndByte, outcome.Breach, null, null);
    }

    // Count receives caller-valid text and needs no coordinate map:
    // attempts, successful endpoints and empty progress are all byte boundaries.
    internal static Utf8SliceCountOutcome CountFromBytes(
        Utf8SliceProgram program,
        ReadOnlySpan<byte> input,
        int fromByte,
        int[] captureStarts,
        int[] captureEnds,
        ref Utf8SliceInvocation invocation)
        => CountFromBytes(program, input, fromByte, captureStarts, captureEnds, ref invocation, default);

    internal static Utf8SliceCountOutcome CountFromBytes(
        Utf8SliceProgram program,
        ReadOnlySpan<byte> input,
        int fromByte,
        int[] captureStarts,
        int[] captureEnds,
        ref Utf8SliceInvocation invocation,
        in Utf8SearchPlan candidatePlan)
    {
        invocation.Budget.ThrowIfCancellationRequested();
        if ((uint)fromByte > (uint)input.Length ||
            fromByte < input.Length && (input[fromByte] & 0xC0) == 0x80)
            return new Utf8SliceCountOutcome(0, Utf8ExecutionLimitKind.None);
        var count = 0;
        var position = fromByte;
        invocation.AnchorOriginByte = fromByte;
        // Nullable roots retain the caller's empty-match progression below.
        if (TryCountTerminalClassRepeat(program, input, fromByte, ref invocation, out var terminal))
            return terminal;
        if (program.IsNonBacktracking)
        {
            Array.Fill(captureStarts, -1);
            Array.Fill(captureEnds, -1);
            if (TryCountAnchoredLine(program, input, fromByte, ref invocation, out var lineCount))
                return lineCount;
            var breach = Utf8NonBacktrackingSearchState.TryCreate(program, input, ref invocation, out var batch);
            if (breach != Utf8ExecutionLimitKind.None) return new(0, breach);
            if (batch is null) throw new InvalidOperationException("NonBacktracking preparation returned no state.");
            try
            {
                var boundary = batch.ResolveByteOffset(fromByte);
                while (true)
                {
                    var found = batch.FindFirst(program, ref boundary, captureStarts, captureEnds, false, ref invocation);
                    if (found.Breach != Utf8ExecutionLimitKind.None) return new(count, found.Breach);
                    if (!found.Found) break;
                    count++;
                }
                return new(count, Utf8ExecutionLimitKind.None);
            }
            finally { batch.Release(ref invocation); }
        }
        var first = program.Instructions[0];
        var seekBeginning = !program.RightToLeft && first.Kind == Utf8SliceInstructionKind.Anchor &&
            first.A == (int)Utf8SliceAnchorKind.Beginning;
        var seekVeryEnd = program.RightToLeft && first.Kind == Utf8SliceInstructionKind.Anchor &&
            first.A == (int)Utf8SliceAnchorKind.VeryEnd;
        // A distance-zero exact prefix is necessary, never sufficient. The scalar
        // VM still verifies every candidate; stateful/empty/casefold starts decline.
        var seekLiteral = CanSeekExactPrefix(program, candidatePlan);
        byte leadingAsciiLast = 0;
        var leadingAsciiSecond = -1;
        byte leadingAsciiSecondLast = 0;
        // A direct beginning anchor already owns bounded line/prefix discovery.
        // Keep one candidate search rather than scanning its prefix twice.
        var leadingAsciiFirst = !seekLiteral && !seekBeginning && !program.RightToLeft && !program.IgnoreCase &&
            !program.CanMatchEmpty && !program.HasContiguousAnchor
            ? GetLeadingAsciiCandidate(program, out leadingAsciiLast, out leadingAsciiSecond, out leadingAsciiSecondLast) : -1;
        var leadingClass = -1;
        var whitespaceLiteralIndex = -1;
        long whitespaceGapMaximum = 0;
        var whitespaceLiteral = !seekLiteral && !program.RightToLeft && !program.IgnoreCase &&
            !program.HasContiguousAnchor && input.Length - fromByte >= 256
            ? GetLeadingWhitespaceLiteral(program, out leadingClass, out whitespaceLiteralIndex, out whitespaceGapMaximum) : -1;
        if (whitespaceLiteral >= 0 && leadingClass >= 0 && whitespaceLiteralIndex != leadingClass + 3 &&
            (candidatePlan.LiteralSearch is not { IgnoreCase: false } classSearch ||
                !LiteralStartsAtInstruction(program, whitespaceLiteralIndex, classSearch.Needle)))
            whitespaceLiteral = -1;
        var whitespaceWindowEnd = -1;
        var workspace = new AttemptWorkspace();
        try
        {
            while (true)
            {
                if (leadingAsciiFirst >= 0)
                {
                    var seekBreach = TrySeekAsciiCandidate(input, ref position, (byte)leadingAsciiFirst, leadingAsciiLast, ref invocation);
                    if (seekBreach != Utf8ExecutionLimitKind.None) return new(count, seekBreach);
                    if (position < 0)
                        return new(count, new Utf8InvocationBufferControl(ref invocation).TryChargeWorkspaceStep());
                    if ((leadingAsciiSecond >= 0 && ((uint)(position + 1) >= (uint)input.Length ||
                        (uint)(input[position + 1] - leadingAsciiSecond) > (uint)(leadingAsciiSecondLast - leadingAsciiSecond))) ||
                        !MatchesStraightAsciiPrefix(program, input, position, 0))
                    {
                        // Rejecting a necessary prefix advances one admitted ASCII
                        // scalar. Reuse the bounded filter, which stops at control
                        // effects; the next search keeps the original work authority.
                        position++;
                        continue;
                    }
                }
                while (whitespaceLiteral >= 0 && position > whitespaceWindowEnd)
                {
                    if (leadingClass >= 0)
                    {
                        var search = candidatePlan.LiteralSearch.GetValueOrDefault();
                        Utf8ExecutionLimitKind seekBreach;
                        if (whitespaceLiteralIndex == leadingClass + 3)
                        {
                            whitespaceWindowEnd = position;
                            seekBreach = TrySeekAsciiCandidate(input, ref whitespaceWindowEnd,
                                (byte)whitespaceLiteral, (byte)whitespaceLiteral, ref invocation);
                        }
                        else
                            seekBreach = Utf8SearchExecutor.TryFindLiteralCandidate(search, input, position,
                                input.Length - search.Length, false, ref invocation, out whitespaceWindowEnd);
                        if (seekBreach != Utf8ExecutionLimitKind.None) return new(count, seekBreach);
                        var floor = position;
                        position = whitespaceWindowEnd;
                        if (position >= 0)
                        {
                            seekBreach = TryRewindClassWhitespace(program, input, floor, leadingClass,
                                whitespaceGapMaximum, ref position, ref invocation);
                            if (seekBreach != Utf8ExecutionLimitKind.None) return new(count, seekBreach);
                        }
                    }
                    else
                    {
                        var seekBreach = TrySeekLeadingWhitespaceLiteral(program, input, ref position,
                            whitespaceLiteralIndex, ref invocation, out whitespaceWindowEnd);
                        if (seekBreach != Utf8ExecutionLimitKind.None) return new(count, seekBreach);
                    }
                    if (position < 0)
                    {
                        return new(count, new Utf8InvocationBufferControl(ref invocation).TryChargeWorkspaceStep());
                    }
                }
                // A mandatory initial strict-end anchor admits only EOF, even
                // after an empty match. Keep original terminal authority when
                // an offset or the preceding match has moved below that start.
                if (seekVeryEnd && position != input.Length)
                    return new(count, new Utf8InvocationBufferControl(ref invocation).TryChargeWorkspaceStep());
                if (seekLiteral)
                {
                    var seekBreach = TrySeekExactPrefix(candidatePlan, input, ref position, ref invocation);
                    if (seekBreach != Utf8ExecutionLimitKind.None) return new(count, seekBreach);
                    // Keep the final charge and recheck the original token after
                    // its diagnostic hook before publishing any accumulated count.
                    if (position < 0)
                        return new(count, new Utf8InvocationBufferControl(ref invocation).TryChargeWorkspaceStep());
                }
                if (seekBeginning)
                {
                    var seekBreach = TrySeekBeginning(program, input, ref position, ref invocation);
                    if (seekBreach != Utf8ExecutionLimitKind.None) return new(count, seekBreach);
                    if (position < 0) break;
                }
                var breach = invocation.TryChargeInputStep();
                if (breach != Utf8ExecutionLimitKind.None)
                    return new Utf8SliceCountOutcome(count, breach);
                invocation.Budget.ThrowIfCancellationRequested();
                var outcome = TryMatchAt(program, input, position, captureStarts, captureEnds, false, false, true, ref workspace, ref invocation);
                if (outcome.Breach != Utf8ExecutionLimitKind.None)
                    return new Utf8SliceCountOutcome(count, outcome.Breach);
                invocation.Budget.ThrowIfCancellationRequested();
                if (outcome.IsMatch)
                {
                    count++;
                    invocation.AnchorOriginByte = outcome.EndIndex;
                    if (outcome.EndIndex != position)
                    {
                        position = outcome.EndIndex;
                        continue;
                    }
                }
                // Presence in one alternative does not anchor other branches.
                // Only a mandatory initial \G proves later starts impossible.
                else if (program.RightToLeft && first.Kind == Utf8SliceInstructionKind.Anchor &&
                    first.A == (int)Utf8SliceAnchorKind.Contiguous)
                    break;
                position = AdvancePastScalar(input, position, program.RightToLeft);
                if (position < 0) break;
            }
            return new Utf8SliceCountOutcome(count, Utf8ExecutionLimitKind.None);
        }

        finally { workspace.Release(ref invocation); }
    }

    internal static Utf8SliceCountOutcome Count(
        Utf8SliceProgram program,
        ReadOnlySpan<byte> input,
        int[] captureStarts,
        int[] captureEnds,
        ref Utf8SliceInvocation invocation)
    {
        return CountFromBytes(program, input, program.RightToLeft ? input.Length : 0, captureStarts, captureEnds, ref invocation);
    }

    private static Utf8SliceMatchOutcome RunSegment(
        ReadOnlySpan<byte> input, int[] captureStarts, int[] captureEnds, int[] balanceHeads,
        ref AssertionCursor cursor, bool resumeFailure, bool preserveCaptureTrail,
        ref ChunkedStacks stacks, ref Utf8SliceInvocation invocation, out bool suspended)
    {
        suspended = false;
        var program = cursor.Program;
        var start = cursor.Start;
        var counts = cursor.Counts;
        var positions = cursor.Positions;
        var requireNonEmpty = cursor.RequireNonEmpty;
        var startIsScalarBoundary = cursor.Aligned;
        var frameBase = cursor.FrameBase;
        var instructions = program.Instructions;
        var programIndex = cursor.ProgramIndex;
        var inputIndex = cursor.InputIndex;
        Utf8ExecutionLimitKind failure;
        while (true)
        {
            var failed = resumeFailure;
            if (resumeFailure)
            {
                resumeFailure = false;
                goto Backtrack;
            }
            var stepBreach = invocation.TryChargeStep();
            if (stepBreach != Utf8ExecutionLimitKind.None)
            {
                failure = stepBreach;
                goto Failure;
            }

            var instruction = instructions[programIndex];
            switch (instruction.Kind)
            {
                case Utf8SliceInstructionKind.Literal:
                    // Adjacent exact ASCII literals share this checked byte loop.
                    // Each keeps its original instruction charge; effects and
                    // wider/folded/mirrored atoms return to normal dispatch.
                    if (!program.RightToLeft && instruction.B == 0 && (uint)instruction.A < 128)
                    {
                        while (true)
                        {
                            if ((uint)inputIndex >= (uint)input.Length || input[inputIndex] != instruction.A)
                            { failed = true; break; }
                            inputIndex++;
                            instruction = instructions[++programIndex];
                            if (instruction.Kind != Utf8SliceInstructionKind.Literal || instruction.B != 0 ||
                                (uint)instruction.A >= 128) break;
                            var literalBreach = invocation.TryChargeStep();
                            if (literalBreach != Utf8ExecutionLimitKind.None)
                                { failure = literalBreach; goto Failure; }
                        }
                        break;
                    }
                    // Literal atoms consume one complete scalar in either direction.
                    var literalIndex = inputIndex;
                    var literalWidth = 0;
                    if (program.RightToLeft)
                    {
                        if (TryGetScalarWidthEndingAt(input, inputIndex, out literalWidth))
                            literalIndex -= literalWidth;
                    }
                    else if (inputIndex < input.Length && (input[inputIndex] & 0xC0) != 0x80)
                    {
                        var lead = input[inputIndex];
                        literalWidth = lead < 0x80 ? 1 : lead < 0xE0 ? 2 : lead < 0xF0 ? 3 : 4;
                    }

                    if (literalWidth == 0)
                    {
                        failed = true;
                        break;
                    }

                    var literalLead = input[literalIndex];
                    bool literalMatches;
                    if (literalLead < 0x80 && instruction.A < 0x80)
                    {
                        // Retain the byte-only ASCII fast path.
                        literalMatches = instruction.B == 0
                            ? literalLead == instruction.A
                            : program.CaseBehavior == Utf8ScalarCaseBehavior.Turkic &&
                                ((literalLead | 0x20) == 'i' || (instruction.A | 0x20) == 'i')
                                ? literalLead == instruction.A
                            : Internal.Search.AsciiSearch.FoldCase(literalLead) ==
                                Internal.Search.AsciiSearch.FoldCase((byte)instruction.A);
                    }
                    else
                    {
                        if (Rune.DecodeFromUtf8(input.Slice(literalIndex), out var literalScalar, out _) != OperationStatus.Done)
                        {
                            failed = true;
                            break;
                        }

                        literalMatches = literalScalar.Value == instruction.A;
                        if (!literalMatches && instruction.B != 0)
                        {
                            literalMatches = Rune.IsValid(instruction.A) &&
                                Utf8SliceCaseEquivalences.ScalarsEquivalent(literalScalar, new Rune(instruction.A), program.CaseBehavior);
                        }
                    }

                    if (literalMatches)
                    {
                        inputIndex += program.RightToLeft ? -literalWidth : literalWidth;
                        programIndex++;
                    }
                    else
                    {
                        failed = true;
                    }
                    break;
                case Utf8SliceInstructionKind.Set:
                    if (TryReadScalar(input, inputIndex, program.RightToLeft, out var setScalar, out var setWidth) &&
                        Utf8SliceScalarClasses.MatchesMask(setScalar, program.SetMasks[instruction.A], instruction.C != 0, program.CaseBehavior) != (instruction.B != 0))
                    {
                        inputIndex += program.RightToLeft ? -setWidth : setWidth;
                        programIndex++;
                    }
                    else failed = true;
                    break;

                case Utf8SliceInstructionKind.Fork:
                    // A required exact ASCII literal can disprove a branch
                    // before its frame/rollback storage is needed. Reuse the
                    // bounded capture-marker proof; opaque branches keep frames.
                    if (instruction.B == 0 && !program.RightToLeft && !program.HasBalancing)
                    {
                        if (TryGetLiteralAfterCaptureMarkers(instructions, programIndex + 1, out var forkFirstScalar) &&
                            (uint)forkFirstScalar < 0x80 &&
                            (inputIndex >= input.Length || input[inputIndex] != forkFirstScalar))
                        {
                            programIndex = instruction.A;
                            break;
                        }
                        if (TryGetLiteralAfterCaptureMarkers(instructions, instruction.A, out var forkOtherScalar) &&
                            (uint)forkOtherScalar < 0x80 &&
                            (inputIndex >= input.Length || input[inputIndex] != forkOtherScalar))
                        {
                            programIndex++;
                            break;
                        }
                    }
                    if (!stacks.PushFrame(
                        new Utf8SliceFrame
                        {
                            ResumeKind = instruction.B == 0 ? Utf8SliceResumeKind.Alternation : instruction.B == 1 ? Utf8SliceResumeKind.Assertion : Utf8SliceResumeKind.Atomic,
                            Target = instruction.A,
                            InputIndex = inputIndex,
                            TrailCount = stacks.TrailCount,
                            JournalCount = stacks.JournalCount
                        },
                        ref invocation))
                    {
                        failure = stacks.Breach;
                        goto Failure;
                    }

                    programIndex++;
                    break;
                case Utf8SliceInstructionKind.Jump:
                    programIndex = instruction.A;
                    break;
                case Utf8SliceInstructionKind.RepeatGreedy:
                case Utf8SliceInstructionKind.RepeatLazy:
                case Utf8SliceInstructionKind.RepeatGreedyAfterMinimum:
                case Utf8SliceInstructionKind.RepeatLazyAfterMinimum:
                    {
                        var repeatId = instruction.B;
                        // Counts store unsigned bits. Only an inactive repeat has
                        // both UINT_MAX and position -1; active body starts are
                        // nonnegative scalar boundaries, including RTL execution.
                        var count = counts.Length == 0 ? 0 : (long)unchecked((uint)counts[repeatId]);
                        if (counts.Length == 0 || counts[repeatId] == -1 && positions[repeatId] == -1)
                        {
                            count = 0;
                            if (TryRunClassRepeatWithoutRewind(program, programIndex, input, inputIndex, cursor.RequiredEnd,
                                ref invocation, out var repeated))
                            {
                                if (repeated.Breach != Utf8ExecutionLimitKind.None) return repeated;
                                if (repeated.IsMatch)
                                {
                                    inputIndex = repeated.EndIndex;
                                    // Fusion never activates the repeat counters.
                                    // Its proof validates RepeatExit, whose reset
                                    // would only journal their unchanged values.
                                    programIndex = instruction.A + 1;
                                }
                                else failed = true;
                                break;
                            }
                            if (counts.Length == 0)
                            {
                                var breach = stacks.TryRentRepeatTables(program.RepeatCount, ref invocation,
                                    out counts, out positions);
                                if (breach != Utf8ExecutionLimitKind.None)
                                    { failure = breach; goto Failure; }
                                cursor.Counts = counts;
                                cursor.Positions = positions;
                            }
                            if (!SetRepeat(counts, positions, repeatId, 0, -1, ref stacks, ref invocation))
                            {
                                failure = stacks.Breach;
                                goto Failure;
                            }
                        }

                        var madeNoProgress = count > 0 && positions[repeatId] == inputIndex;
                        var minimum = instruction.RepeatMinimum;
                        var maximum = instruction.RepeatMaximum;
                        var greedy = instruction.Kind is Utf8SliceInstructionKind.RepeatGreedy or Utf8SliceInstructionKind.RepeatGreedyAfterMinimum;
                        // Repetition counts atom iterations, independently of UTF-8 or UTF-16 width.
                        if (count < minimum)
                        {
                            if (!SetRepeat(counts, positions, repeatId, count + 1, inputIndex, ref stacks, ref invocation))
                            {
                                failure = stacks.Breach;
                                goto Failure;
                            }

                            programIndex++;
                            break;
                        }

                        if (count >= maximum || madeNoProgress && (count > minimum ||
                            instruction.Kind is Utf8SliceInstructionKind.RepeatGreedy or Utf8SliceInstructionKind.RepeatLazy))
                        {
                            programIndex = instruction.A;
                            break;
                        }

                        // Finite repeats retain their exact iteration count. An
                        // unbounded optional phase only distinguishes min from
                        // min+1; later totals cannot affect any repeat decision.
                        // This also supports a UINT_MAX-1 minimum without growing
                        // every program's counter, frame or rollback record.
                        var nextCount = maximum == long.MaxValue ? minimum + 1 : count + 1;

                        var frame = new Utf8SliceFrame
                        {
                            InputIndex = inputIndex,
                            TrailCount = stacks.TrailCount,
                            JournalCount = stacks.JournalCount,
                            Aux = repeatId
                        };
                        if (greedy)
                        {
                            frame.ResumeKind = Utf8SliceResumeKind.RepeatUnwind;
                            frame.Target = instruction.A;
                            frame.Count = unchecked((int)count);
                        }
                        else
                        {
                            frame.ResumeKind = Utf8SliceResumeKind.RepeatContinue;
                            frame.Target = programIndex + 1;
                            frame.Count = unchecked((int)nextCount);
                        }

                        if (!stacks.PushFrame(frame, ref invocation))
                        {
                            failure = stacks.Breach;
                            goto Failure;
                        }

                        if (greedy)
                        {
                            if (!SetRepeat(counts, positions, repeatId, nextCount, inputIndex, ref stacks, ref invocation))
                            {
                                failure = stacks.Breach;
                                goto Failure;
                            }

                            programIndex++;
                        }
                        else
                        {
                            programIndex = instruction.A;
                        }

                        break;
                    }

                case Utf8SliceInstructionKind.RepeatEnd:
                    programIndex = instruction.A;
                    break;
                case Utf8SliceInstructionKind.RepeatExit:
                    if (!SetRepeat(counts, positions, instruction.A, -1, -1, ref stacks, ref invocation))
                    {
                        failure = stacks.Breach;
                        goto Failure;
                    }

                    programIndex++;
                    break;
                case Utf8SliceInstructionKind.CaptureStart:
                    // Empty buffers mean the caller proved these values are
                    // unobserved. The instruction still spends its normal work.
                    if (captureStarts.Length == 0) { programIndex++; break; }
                    if (program.UsesCaptureOpeningJournal)
                    {
                        if (!stacks.PushTrailEntry(new Utf8SliceTrailEntry { Slot = instruction.A, NewValue = inputIndex, IsOpening = true }, ref invocation))
                        { failure = stacks.Breach; goto Failure; }
                        programIndex++;
                        break;
                    }
                    // The assertion/history driver retains every entry. In an
                    // assertion-free latest-value root, a plain start slot needs
                    // undo only while a frame can return to an earlier value.
                    // Closing entries still preserve multi-group completion order.
                    if ((preserveCaptureTrail || balanceHeads.Length != 0 || stacks.FrameCount != 0) &&
                        !stacks.PushTrail(instruction.A, captureStarts[instruction.A], inputIndex, true, ref invocation))
                    {
                        failure = stacks.Breach;
                        goto Failure;
                    }

                    captureStarts[instruction.A] = inputIndex;
                    programIndex++;
                    break;
                case Utf8SliceInstructionKind.CaptureEnd:
                    if (captureStarts.Length == 0) { programIndex++; break; }
                    if (program.UsesCaptureOpeningJournal)
                    {
                        // An opening capture does not overwrite the last completed one.
                        // This preserves nested aliases and references inside their bodies.
                        if (!stacks.TryFindCaptureOpening(instruction.A, ref invocation, out var opening, out var openingBreach))
                            { failure = openingBreach; goto Failure; }
                        if (!stacks.PushRestoreTrail(instruction.A, captureStarts[instruction.A], opening, captureEnds[instruction.A], inputIndex, ref invocation) ||
                            !stacks.PushTrailEntry(new Utf8SliceTrailEntry { Slot = instruction.A, OldValue = opening, NewValue = inputIndex, IsClosing = true }, ref invocation))
                        { failure = stacks.Breach; goto Failure; }
                        captureStarts[instruction.A] = opening;
                        captureEnds[instruction.A] = inputIndex;
                    }
                    else
                    {
                        if ((preserveCaptureTrail || captureStarts.Length != 1 || balanceHeads.Length != 0 || stacks.FrameCount != 0) &&
                            !stacks.PushTrail(instruction.A, captureEnds[instruction.A], inputIndex, false, ref invocation))
                        {
                            failure = stacks.Breach;
                            goto Failure;
                        }
                        captureEnds[instruction.A] = inputIndex;
                    }
                    if (program.HasBalancing)
                    {
                        // Balancing stacks mirror every capture so pops can
                        // restore previous tops; the head journal makes the
                        // push vanish on backtrack like any trail write.
                        if (!stacks.PushBalance(captureStarts[instruction.A], inputIndex, balanceHeads[instruction.A], ref invocation) ||
                            !stacks.PushHeadTrail(instruction.A, balanceHeads[instruction.A], stacks.BalanceCount - 1, ref invocation))
                        {
                            failure = stacks.Breach;
                            goto Failure;
                        }

                        balanceHeads[instruction.A] = stacks.BalanceCount - 1;
                    }

                    programIndex++;
                    break;
                case Utf8SliceInstructionKind.Dot:
                    // Mirrored dots consume the scalar ending at the attempt edge.
                    if (program.RightToLeft)
                    {
                        if (TryGetScalarWidthEndingAt(input, inputIndex, out var rtlDotWidth) &&
                            (instruction.A != 0 || input[inputIndex - 1] != (byte)'\n'))
                        {
                            inputIndex -= rtlDotWidth;
                            programIndex++;
                        }
                        else
                        {
                            failed = true;
                        }

                        break;
                    }

                    // Dots consume one scalar: ASCII and BMP leads take
                    // their scalar, astral leads take all four bytes.
                    // Continuation bytes fail the attempt, so byte-stepping
                    // drivers cannot report unaligned starts. Inputs are
                    // validated before execution, hence lead widths stay
                    // in bounds without revalidation here.
                    if (inputIndex < input.Length &&
                        (instruction.A != 0 || input[inputIndex] != (byte)'\n') &&
                        (input[inputIndex] & 0xC0) != 0x80)
                    {
                        var lead = input[inputIndex];
                        if (lead < 0x80)
                        {
                            inputIndex++;
                        }
                        else if (lead < 0xE0)
                        {
                            inputIndex += 2;
                        }
                        else if (lead < 0xF0)
                        {
                            inputIndex += 3;
                        }
                        else
                        {
                            inputIndex += 4;
                        }

                        programIndex++;
                    }
                    else
                    {
                        failed = true;
                    }

                    break;
                case Utf8SliceInstructionKind.Anchor:
                    // Zero-width edges: beginning holds at the input origin
                    // or (multiline `^`) just after a line feed; lax end
                    // (`$`, `\Z`) holds at the input end, before a trailing
                    // line feed, or (multiline `$`) just before any line
                    // feed; strict end (`\z`) holds only at the input end.
                    // Line feeds are single bytes, so these checks are
                    // encoding-indifferent and need no astral routing.
                    // Guards order short-circuit before any indexing.
                    var anchorMultiline = instruction.B != 0;
                    bool anchorHolds;
                    if (instruction.A == 0)
                    {
                        // Origin assertions require a scalar-aligned attempt.
                        anchorHolds = (inputIndex == 0 && startIsScalarBoundary) ||
                            (anchorMultiline && inputIndex > 0 && input[inputIndex - 1] == (byte)'\n');
                    }
                    else if (instruction.A == 2)
                    {
                        anchorHolds = inputIndex == input.Length;
                    }
                    else if (instruction.A == 3)
                    {
                        // Contiguous matches pin to the scan start (BCL startat),
                        // defaulting to the attempt start when no driver set an origin.
                        var origin = invocation.AnchorOriginByte;
                        anchorHolds = inputIndex == (origin < 0 ? start : origin);
                    }
                    else if (inputIndex == input.Length)
                    {
                        anchorHolds = true;
                    }
                    else if (anchorMultiline)
                    {
                        anchorHolds = input[inputIndex] == (byte)'\n';
                    }
                    else
                    {
                        anchorHolds = inputIndex + 1 == input.Length && input[inputIndex] == (byte)'\n';
                    }

                    if (anchorHolds)
                    {
                        programIndex++;
                    }
                    else
                    {
                        failed = true;
                    }

                    break;
                case Utf8SliceInstructionKind.Boundary:
                    // Zero-width word edges: `\b` holds on a word/non-word
                    // transition, `\B` where both sides agree. Both require
                    // scalar-aligned positions and classify complete neighbors.
                    if (!startIsScalarBoundary)
                    {
                        failed = true;
                    }
                    else if (inputIndex <= input.Length &&
                        (inputIndex == input.Length || (input[inputIndex] & 0xC0) != 0x80))
                    {
                        if (MatchesBoundary(program, instruction, input, inputIndex))
                        {
                            programIndex++;
                        }
                        else
                        {
                            failed = true;
                        }
                    }
                    else
                    {
                        failed = true;
                    }

                    break;
                case Utf8SliceInstructionKind.Shorthand:
                case Utf8SliceInstructionKind.CategorySet:
                case Utf8SliceInstructionKind.Hybrid:
                    {
                        if (!TryReadScalar(input, inputIndex, program.RightToLeft, out var classScalar, out var classWidth))
                        {
                            failed = true;
                            break;
                        }

                        var classBreach = TryMatchScalarClass(program, instruction, classScalar,
                            ref invocation, out var classHit);
                        if (classBreach != Utf8ExecutionLimitKind.None)
                            { failure = classBreach; goto Failure; }

                        if (classHit)
                        {
                            inputIndex += program.RightToLeft ? -classWidth : classWidth;
                            programIndex++;
                        }
                        else failed = true;
                        break;
                    }

                case Utf8SliceInstructionKind.Backref:
                    {
                        var referenced = RunBackreference(program, instruction, input,
                            captureStarts, captureEnds, inputIndex, ref invocation);
                        if (referenced.Breach != Utf8ExecutionLimitKind.None) return referenced;
                        if (referenced.IsMatch)
                        {
                            inputIndex = referenced.EndIndex;
                            programIndex++;
                        }
                        else failed = true;
                        break;
                    }
                case Utf8SliceInstructionKind.TestGroup:
                    // One-shot group test (BCL IsMatched: participated, even empty;
                    // in-progress and unset groups test false, group zero never matches):
                    // jump to the no-branch on false, fall into yes on true. Downstream
                    // failure never retries the other branch (BCL commits to the test).
                    // Direction-free: mirrored runs record inverted spans, but both ends
                    // stay non-negative exactly when the group participated.
                    if (instruction.A < 0 || captureStarts[instruction.A] < 0 || captureEnds[instruction.A] < 0)
                    {
                        programIndex = instruction.B;
                    }
                    else
                    {
                        programIndex++;
                    }

                    break;
                case Utf8SliceInstructionKind.Fail:
                    failed = true;
                    break;
                case Utf8SliceInstructionKind.AtomicCommit:
                    {
                        // Possessive commit: discard every frame up to and
                        // including the atomic fork (a surviving body must not
                        // resume its alternatives), keeping input, captures,
                        // and repeat state.
                        var foundAtomic = false;
                        while (stacks.FrameCount > frameBase && stacks.PopFrame(out var committed))
                        {
                            if (committed.ResumeKind == Utf8SliceResumeKind.Atomic)
                            {
                                foundAtomic = true;
                                break;
                            }
                        }

                        if (!foundAtomic)
                        {
                            failed = true;
                            break;
                        }

                        programIndex++;
                        break;
                    }
                case Utf8SliceInstructionKind.Commit:
                    {
                        // Assertion commit: discard every frame up to and
                        // including the assertion fork (a surviving body must
                        // not resume its alternatives), rewind to the
                        // assertion position (zero width), restore repeat
                        // state to the fork mark, and keep capture writes.
                        var journalMark = -1;
                        var rewindTo = -1;
                        while (stacks.FrameCount > frameBase && stacks.PopFrame(out var committed))
                        {
                            if (committed.ResumeKind == Utf8SliceResumeKind.Assertion)
                            {
                                journalMark = committed.JournalCount;
                                rewindTo = committed.InputIndex;
                                break;
                            }
                        }

                        if (journalMark < 0)
                        {
                            failed = true;
                            break;
                        }

                        inputIndex = rewindTo;
                        stacks.TruncateJournal(journalMark, counts, positions);
                        programIndex++;
                        break;
                    }
                case Utf8SliceInstructionKind.Lookbehind:
                case Utf8SliceInstructionKind.Lookahead:
                {
                    // Side-effect-free literal assertions use the same bounded
                    // evaluator without leaving and re-entering this segment.
                    if (TryRunAsciiLiteralAssertion(program.Assertions[instruction.A], input, inputIndex,
                        (uint)stacks.FrameCount + 1, ref invocation, out var matched, out var assertionBreach))
                    {
                        if (assertionBreach != Utf8ExecutionLimitKind.None)
                            { failure = assertionBreach; goto Failure; }
                        failed = matched != (instruction.B != 0);
                        if (!failed) programIndex++;
                        break;
                    }
                    // The driver owns child arrays and saves this exact edge;
                    // returning here suspends, rather than recursively entering,
                    // the assertion's independent instruction stream.
                    cursor.ProgramIndex = programIndex;
                    cursor.InputIndex = inputIndex;
                    suspended = true;
                    return default;
                }
                case Utf8SliceInstructionKind.BalanceStart:
                    // Retain the body's opening without testing its source yet:
                    // the body can establish the capture popped at successful close.
                    if (!stacks.PushTrailEntry(new Utf8SliceTrailEntry {
                        Slot = instruction.B,
                        NewValue = inputIndex,
                        IsOpening = true
                    }, ref invocation))
                    { failure = stacks.Breach; goto Failure; }
                    programIndex++;
                    break;

                case Utf8SliceInstructionKind.BalancePop:
                    {
                        // Check at successful close: the body may have consumed
                        // the source through a nested balancing group. Pop its
                        // current completed capture, then project the interval
                        // against the completed body independently of direction.
                        var popSlot = instruction.A;
                        var captureSlot = instruction.B;
                        if (balanceHeads[popSlot] < 0)
                        {
                            failed = true;
                            break;
                        }
                        var top = stacks.BalanceEntryAt(balanceHeads[popSlot]);
                        var previousStart = -1;
                        var previousEnd = -1;
                        if (top.Prev >= 0)
                        {
                            var below = stacks.BalanceEntryAt(top.Prev);
                            previousStart = below.Start;
                            previousEnd = below.End;
                        }
                        if (!stacks.PushRestoreTrail(popSlot, captureStarts[popSlot], previousStart,
                                captureEnds[popSlot], previousEnd, ref invocation) ||
                            !stacks.PushHeadTrail(popSlot, balanceHeads[popSlot], top.Prev, ref invocation))
                            { failure = stacks.Breach; goto Failure; }
                        captureStarts[popSlot] = previousStart;
                        captureEnds[popSlot] = previousEnd;
                        balanceHeads[popSlot] = top.Prev;
                        if (captureSlot >= 0)
                        {
                            if (!stacks.TryFindCaptureOpening(captureSlot, ref invocation,
                                    out var opening, out var openingBreach))
                                { failure = openingBreach; goto Failure; }
                            var sourceStart = Math.Min(top.Start, top.End);
                            var sourceEnd = Math.Max(top.Start, top.End);
                            var gapStart = Math.Min(opening, inputIndex);
                            var gapEnd = Math.Max(opening, inputIndex);
                            // Capture the gap for disjoint spans or their
                            // intersection when the body overlaps its source.
                            if (gapStart >= sourceEnd)
                            {
                                gapEnd = gapStart;
                                gapStart = sourceEnd;
                            }
                            else if (gapEnd <= sourceStart)
                            {
                                gapStart = gapEnd;
                                gapEnd = sourceStart;
                            }
                            else
                            {
                                gapStart = Math.Max(gapStart, sourceStart);
                                gapEnd = Math.Min(gapEnd, sourceEnd);
                            }
                            if (!stacks.PushRestoreTrail(captureSlot, captureStarts[captureSlot], gapStart,
                                    captureEnds[captureSlot], gapEnd, ref invocation) ||
                                !stacks.PushTrailEntry(new Utf8SliceTrailEntry {
                                    Slot = captureSlot,
                                    OldValue = gapStart,
                                    NewValue = gapEnd,
                                    IsClosing = true
                                }, ref invocation) ||
                                !stacks.PushBalance(gapStart, gapEnd, balanceHeads[captureSlot], ref invocation) ||
                                !stacks.PushHeadTrail(captureSlot, balanceHeads[captureSlot], stacks.BalanceCount - 1, ref invocation))
                                { failure = stacks.Breach; goto Failure; }
                            captureStarts[captureSlot] = gapStart;
                            captureEnds[captureSlot] = gapEnd;
                            balanceHeads[captureSlot] = stacks.BalanceCount - 1;
                        }
                        programIndex++;
                        break;
                    }

                case Utf8SliceInstructionKind.Accept:
                    if (requireNonEmpty && inputIndex == start)
                    {
                        failed = true;
                        break;
                    }

                    // Publication belongs to RunFrom after assertion continuations
                    // close, so metadata denial cannot strand owned history roots.
                    return new Utf8SliceMatchOutcome(true, inputIndex, Utf8ExecutionLimitKind.None, null, null);
                default:
                    throw new InvalidOperationException($"Unsupported slice instruction {instruction.Kind}.");
            }

        Backtrack:
            if (failed)
            {
                if (stacks.FrameCount == frameBase || !stacks.PopFrame(out var popped))
                {
                    failure = Utf8ExecutionLimitKind.None;
                    goto Failure;
                }

                stacks.TruncateJournal(popped.JournalCount, counts, positions);
                stacks.TruncateTrail(popped.TrailCount, captureStarts, captureEnds, balanceHeads);
                switch (popped.ResumeKind)
                {
                    case Utf8SliceResumeKind.Alternation:
                    case Utf8SliceResumeKind.Assertion:
                    case Utf8SliceResumeKind.Atomic:
                        inputIndex = popped.InputIndex;
                        programIndex = popped.Target;
                        break;
                    case Utf8SliceResumeKind.RepeatUnwind:
                        if (!SetRepeat(counts, positions, popped.Aux, popped.Count, popped.InputIndex, ref stacks, ref invocation))
                        {
                            failure = stacks.Breach;
                            goto Failure;
                        }

                        inputIndex = popped.InputIndex;
                        programIndex = popped.Target;
                        break;
                    default:
                        if (!SetRepeat(counts, positions, popped.Aux, popped.Count, popped.InputIndex, ref stacks, ref invocation))
                        {
                            failure = stacks.Breach;
                            goto Failure;
                        }

                        inputIndex = popped.InputIndex;
                        programIndex = popped.Target;
                        break;
                }
            }
        }
    Failure:
        return new(false, -1, failure, null, null);
    }

    private static bool SetRepeat(
        int[] counts,
        int[] positions,
        int repeatId,
        long count,
        int position,
        ref ChunkedStacks stacks,
        ref Utf8SliceInvocation invocation)
    {
        if (!stacks.PushJournal(repeatId, counts[repeatId], positions[repeatId], ref invocation))
        {
            return false;
        }

        counts[repeatId] = unchecked((int)count);
        positions[repeatId] = position;
        return true;
    }

    // One search/Count call retains its admitted scratch between candidates.
    // State is reset for each attempt; no workspace escapes or crosses invocations.
    internal struct AttemptWorkspace
    {
        internal int[] Counts;
        internal int[] Positions;
        internal int[] Heads;
        internal ChunkedStacks Stacks;
        internal bool Initialized;
        private ulong _reservation;

        public AttemptWorkspace()
        {
            Counts = [];
            Positions = [];
            Heads = [];
            Stacks = default;
            Initialized = false;
            _reservation = 0;
        }

        internal Utf8ExecutionLimitKind Initialize(Utf8SliceProgram program, ref Utf8SliceInvocation invocation)
        {
            // Fused repeats use scalar locals. Root repeat vectors are acquired
            // by the existing stack owner only when a repeat needs mutable state.
            // Lowering propagates the same balancing requirement to assertion
            // bodies. Only balancing captures produce or restore head entries.
            var balanceGroups = program.HasBalancing ? program.GroupCount : 0;
            var bytes = Utf8ConstructionBudget.ArrayBytes<int>(balanceGroups);
            var breach = invocation.TryReserveWorking(bytes);
            if (breach != Utf8ExecutionLimitKind.None) return breach;
            _reservation = bytes;
            if (balanceGroups != 0)
            {
                breach = invocation.TryChargeInputStep();
                if (breach != Utf8ExecutionLimitKind.None) return breach;
                Heads = new int[balanceGroups];
            }
            Initialized = true;
            return Utf8ExecutionLimitKind.None;
        }

        internal void Release(ref Utf8SliceInvocation invocation)
        {
            Stacks.ReleaseAll(ref invocation);
            invocation.Ledger.Release(_reservation);
            _reservation = 0;
            Heads = [];
            Positions = [];
            Counts = [];
            Initialized = false;
        }
    }

    internal struct ChunkedStacks
    {
        private Utf8SliceFrame[][] _frameTables;
        private Utf8SliceTrailEntry[][] _trailTables;
        private Utf8SliceCountMutation[][] _journalTables;
        private Utf8SliceBalanceEntry[][] _balanceTables;
        private int _frameCount;
        private int _trailCount;
        private int _journalCount;
        private int _balanceCount;
        private ulong _reservedBytes;
        internal Utf8ExecutionLimitKind Breach;

        internal int FrameCount => _frameCount;
        internal int TrailCount => _trailCount;
        internal int JournalCount => _journalCount;
        internal int BalanceCount => _balanceCount;

        // These root arrays share this workspace's reservation lifetime and are
        // retained between attempts. Assertion children keep their own leases.
        internal Utf8ExecutionLimitKind TryRentRepeatTables(int repeats, ref Utf8SliceInvocation invocation,
            out int[] counts, out int[] positions)
        {
            counts = positions = [];
            var bytes = checked(Utf8ConstructionBudget.ArrayBytes<int>(repeats) * 2);
            var reserved = checked(_reservedBytes + bytes);
            var breach = invocation.TryReserveWorking(bytes);
            if (breach != Utf8ExecutionLimitKind.None) return breach;
            // The workspace releases this reservation even on partial allocation
            // or interruption, just as it releases partially acquired stack chunks.
            _reservedBytes = reserved;
            breach = invocation.TryChargeInputStep();
            if (breach != Utf8ExecutionLimitKind.None) return breach;
            counts = new int[repeats];
            breach = invocation.TryChargeInputStep();
            if (breach != Utf8ExecutionLimitKind.None) return breach;
            positions = new int[repeats];
            for (var offset = 0; offset < repeats;)
            {
                breach = invocation.TryChargeInputStep();
                if (breach != Utf8ExecutionLimitKind.None) return breach;
                var length = Math.Min(2048, repeats - offset);
                counts.AsSpan(offset, length).Fill(-1);
                positions.AsSpan(offset, length).Fill(-1);
                offset += length;
            }
            return Utf8ExecutionLimitKind.None;
        }

        // Capture end writes and explicit close markers already survive exactly
        // the chosen path. Reuse their order; no completion history is allocated.
        internal Utf8ExecutionLimitKind FindLastClosedSlot(ref Utf8SliceInvocation invocation, out int slot)
        {
            slot = -1;
            for (var index = _trailCount - 1; index >= 0; index--)
            {
                if ((index & 63) == 0 || index == _trailCount - 1)
                {
                    var breach = invocation.TryChargeInputStep();
                    if (breach != Utf8ExecutionLimitKind.None) return breach;
                }
                var entry = _trailTables[index / TrailChunkCapacity][index % TrailChunkCapacity];
                if (entry.IsClosing || !entry.IsStart && !entry.IsHead && !entry.IsRestore && !entry.IsOpening)
                { slot = entry.Slot; break; }
            }
            return Utf8ExecutionLimitKind.None;
        }

        internal bool PushFrame(Utf8SliceFrame frame, ref Utf8SliceInvocation invocation)
        {
            // Admit the prospective live depth before a frame table/chunk can
            // grow. Assertion, fork and repeat callers share this one rule.
            Breach = invocation.Budget.TryNoteDepth((uint)_frameCount + 1);
            if (Breach != Utf8ExecutionLimitKind.None) return false;
            return Push(ref _frameTables, ref _frameCount, FrameChunkCapacity, frame, ref invocation, ref _reservedBytes, out Breach);
        }

        internal bool PushTrail(int slot, int oldValue, int newValue, bool isStart, ref Utf8SliceInvocation invocation)
        {
            return Push(ref _trailTables, ref _trailCount, TrailChunkCapacity,
                new Utf8SliceTrailEntry { Slot = slot, OldValue = oldValue, NewValue = newValue, IsStart = isStart }, ref invocation, ref _reservedBytes, out Breach);
        }

        internal bool PushTrailEntry(Utf8SliceTrailEntry entry, ref Utf8SliceInvocation invocation)
        {
            return Push(ref _trailTables, ref _trailCount, TrailChunkCapacity,
                entry, ref invocation, ref _reservedBytes, out Breach);
        }

        internal bool TryFindCaptureOpening(int slot, ref Utf8SliceInvocation invocation, out int opening, out Utf8ExecutionLimitKind breach)
        {
            var closed = 0;
            opening = -1;
            breach = Utf8ExecutionLimitKind.None;
            for (var index = _trailCount - 1; index >= 0; index--)
            {
                breach = invocation.TryChargeStep();
                if (breach != Utf8ExecutionLimitKind.None) return false;
                var entry = TrailEntryAt(index);
                if (entry.Slot != slot) continue;
                if (entry.IsClosing) closed++;
                else if (entry.IsOpening)
                {
                    if (closed != 0) closed--;
                    else
                    {
                        opening = entry.NewValue;
                        return true;
                    }
                }
            }
            throw new InvalidOperationException("Capture close has no surviving opening marker.");
        }

        internal bool PushRestoreTrail(int slot, int oldStart, int newStart, int oldEnd, int newEnd, ref Utf8SliceInvocation invocation)
        {
            // Balance-pop slot restores: live slot state for backtrack
            // truncation, but no capture record (the popped capture
            // drains through its head entry; the restored top stays
            // recorded from its own capture time).
            return Push(ref _trailTables, ref _trailCount, TrailChunkCapacity,
                new Utf8SliceTrailEntry { Slot = slot, OldValue = oldStart, NewValue = newStart, IsStart = true, IsRestore = true }, ref invocation, ref _reservedBytes, out Breach) &&
                Push(ref _trailTables, ref _trailCount, TrailChunkCapacity,
                new Utf8SliceTrailEntry { Slot = slot, OldValue = oldEnd, NewValue = newEnd, IsStart = false, IsRestore = true }, ref invocation, ref _reservedBytes, out Breach);
        }

        internal bool PushJournal(int repeatId, int oldCount, int oldPosition, ref Utf8SliceInvocation invocation)
        {
            return Push(ref _journalTables, ref _journalCount, JournalChunkCapacity,
                new Utf8SliceCountMutation { RepeatId = repeatId, OldCount = oldCount, OldPosition = oldPosition }, ref invocation, ref _reservedBytes, out Breach);
        }

        internal bool PushBalance(int start, int end, int prev, ref Utf8SliceInvocation invocation)
        {
            return Push(ref _balanceTables, ref _balanceCount, BalanceChunkCapacity,
                new Utf8SliceBalanceEntry { Start = start, End = end, Prev = prev }, ref invocation, ref _reservedBytes, out Breach);
        }

        internal bool PushHeadTrail(int slot, int oldHead, int newHead, ref Utf8SliceInvocation invocation)
        {
            return Push(ref _trailTables, ref _trailCount, TrailChunkCapacity,
                new Utf8SliceTrailEntry { Slot = slot, OldValue = oldHead, NewValue = newHead, IsStart = false, IsHead = true }, ref invocation, ref _reservedBytes, out Breach);
        }

        internal Utf8SliceBalanceEntry BalanceEntryAt(int index)
        {
            return _balanceTables[index / BalanceChunkCapacity][index % BalanceChunkCapacity];
        }

        internal bool PopFrame(out Utf8SliceFrame frame)
        {
            if (_frameCount == 0)
            {
                frame = default;
                return false;
            }

            _frameCount--;
            frame = _frameTables[_frameCount / FrameChunkCapacity][_frameCount % FrameChunkCapacity];
            return true;
        }

        internal Utf8SliceTrailEntry TrailEntryAt(int index)
        {
            return _trailTables[index / TrailChunkCapacity][index % TrailChunkCapacity];
        }

        internal void TruncateTrail(int count, int[] captureStarts, int[] captureEnds, int[] balanceHeads)
        {
            while (_trailCount > count)
            {
                _trailCount--;
                var entry = _trailTables[_trailCount / TrailChunkCapacity][_trailCount % TrailChunkCapacity];
                if (entry.IsOpening || entry.IsClosing) continue;
                if (entry.IsHead)
                {
                    balanceHeads[entry.Slot] = entry.OldValue;
                }
                else if (entry.IsStart)
                {
                    captureStarts[entry.Slot] = entry.OldValue;
                }
                else
                {
                    captureEnds[entry.Slot] = entry.OldValue;
                }
            }
        }

        internal void TruncateJournal(int count, int[] counts, int[] positions)
        {
            while (_journalCount > count)
            {
                _journalCount--;
                var entry = _journalTables[_journalCount / JournalChunkCapacity][_journalCount % JournalChunkCapacity];
                counts[entry.RepeatId] = entry.OldCount;
                positions[entry.RepeatId] = entry.OldPosition;
            }
        }

        internal Utf8ExecutionLimitKind MaterializeHistory(int groups,
            ref Utf8SliceInvocation invocation, out int[][] captureStarts, out int[][] captureLengths)
        {
            captureStarts = [];
            captureLengths = [];
            if (groups == 0) return Utf8ExecutionLimitKind.None;
            var ownedBytes = checked(Utf8ConstructionBudget.ArrayBytes<int[]>(groups) * 2);
            var temporaryBytes = checked(Utf8ConstructionBudget.ArrayBytes<int>(groups) * 2);
            var resultAdmission = invocation.Budget.TryChargeResultBytes(checked(ownedBytes + temporaryBytes));
            if (resultAdmission != Utf8ExecutionLimitKind.None) return resultAdmission;
            var breach = invocation.TryReserveWorking(checked(ownedBytes + temporaryBytes));
            if (breach != Utf8ExecutionLimitKind.None) return breach;
            int[]? rentedCounts = null;
            int[]? rentedOpen = null;
            var retain = invocation.HasUnlimitedWorkingMemory;
            var published = false;
            try
            {
                breach = invocation.TryChargeInputStep();
                if (breach != Utf8ExecutionLimitKind.None) return breach;
                captureStarts = new int[groups][];
                captureLengths = new int[groups][];
                var counts = Utf8ExactStatePool<int>.Rent(groups, retain);
                rentedCounts = counts;
                breach = invocation.TryChargeInputStep();
                if (breach != Utf8ExecutionLimitKind.None) return breach;
                var open = Utf8ExactStatePool<int>.Rent(groups, retain);
                rentedOpen = open;
                for (var offset = 0; offset < groups;)
                {
                    breach = invocation.TryChargeInputStep();
                    if (breach != Utf8ExecutionLimitKind.None) return breach;
                    var count = Math.Min(2048, groups - offset);
                    counts.AsSpan(offset, count).Clear();
                    offset += count;
                }
                var sawBalanceDrain = false;
                for (var entry = 0; entry < _trailCount; entry++)
                {
                    if ((entry & 255) == 0 && (breach = invocation.TryChargeInputStep()) != Utf8ExecutionLimitKind.None) return breach;
                    var item = _trailTables[entry / TrailChunkCapacity][entry % TrailChunkCapacity];
                    if (item.IsRestore || item.IsOpening) continue;
                    if (item.IsHead)
                    {
                        if (item.NewValue < item.OldValue) sawBalanceDrain = true;
                    }
                    else if (!item.IsStart) counts[item.Slot]++;
                }
                ulong captureBytes = 0;
                for (var group = 0; group < groups; group++)
                {
                    if ((group & 255) == 0 && (breach = invocation.TryChargeInputStep()) != Utf8ExecutionLimitKind.None) return breach;
                    captureBytes = checked(captureBytes + Utf8ConstructionBudget.ArrayBytes<int>(counts[group]) * 2);
                }
                breach = invocation.Budget.TryChargeResultBytes(captureBytes);
                if (breach != Utf8ExecutionLimitKind.None) return breach;
                breach = invocation.TryReserveWorking(captureBytes);
                if (breach != Utf8ExecutionLimitKind.None) return breach;
                ownedBytes = checked(ownedBytes + captureBytes);
                for (var group = 0; group < groups; group++)
                {
                    if ((group & 255) == 0 && (breach = invocation.TryChargeInputStep()) != Utf8ExecutionLimitKind.None) return breach;
                    open[group] = -1;
                    captureStarts[group] = counts[group] == 0 ? [] : new int[counts[group]];
                    captureLengths[group] = counts[group] == 0 ? [] : new int[counts[group]];
                    counts[group] = 0;
                }
                for (var entry = 0; entry < _trailCount; entry++)
                {
                    if ((entry & 255) == 0 && (breach = invocation.TryChargeInputStep()) != Utf8ExecutionLimitKind.None) return breach;
                    var item = _trailTables[entry / TrailChunkCapacity][entry % TrailChunkCapacity];
                    if (item.IsRestore || item.IsOpening) continue;
                    if (item.IsHead)
                    {
                        if (item.NewValue < item.OldValue) counts[item.Slot]--;
                    }
                    else if (item.IsStart) open[item.Slot] = item.NewValue;
                    else
                    {
                        // Histories normalize mirrored capture edges; the trail
                        // itself retains its original rollback representation.
                        var left = item.IsClosing ? item.OldValue : open[item.Slot];
                        var right = item.NewValue;
                        captureStarts[item.Slot][counts[item.Slot]] = Math.Min(left, right);
                        captureLengths[item.Slot][counts[item.Slot]] = Math.Abs(right - left);
                        counts[item.Slot]++;
                    }
                }
                if (sawBalanceDrain)
                {
                    for (var group = 0; group < groups; group++)
                    {
                        if ((group & 255) == 0 && (breach = invocation.TryChargeInputStep()) != Utf8ExecutionLimitKind.None) return breach;
                        if (counts[group] == captureStarts[group].Length) continue;
                        var oldBytes = checked(Utf8ConstructionBudget.ArrayBytes<int>(captureStarts[group].Length) * 2);
                        var bytes = checked(Utf8ConstructionBudget.ArrayBytes<int>(counts[group]) * 2);
                        // Admit both replacement arrays while old capacity is
                        // held. Copy in bounded blocks, then transfer ownership.
                        breach = invocation.Budget.TryChargeResultBytes(bytes);
                        if (breach != Utf8ExecutionLimitKind.None) return breach;
                        breach = invocation.TryReserveWorking(bytes);
                        if (breach != Utf8ExecutionLimitKind.None) return breach;
                        ownedBytes += bytes;
                        var starts = counts[group] == 0 ? [] : new int[counts[group]];
                        var lengths = counts[group] == 0 ? [] : new int[counts[group]];
                        for (var offset = 0; offset < counts[group];)
                        {
                            breach = invocation.TryChargeInputStep();
                            if (breach != Utf8ExecutionLimitKind.None) return breach;
                            var count = Math.Min(512, counts[group] - offset);
                            captureStarts[group].AsSpan(offset, count).CopyTo(starts.AsSpan(offset, count));
                            captureLengths[group].AsSpan(offset, count).CopyTo(lengths.AsSpan(offset, count));
                            offset += count;
                        }
                        captureStarts[group] = starts;
                        captureLengths[group] = lengths;
                        invocation.Ledger.Release(oldBytes);
                        ownedBytes -= oldBytes;
                    }
                }
                published = true;
                return Utf8ExecutionLimitKind.None;
            }
            finally
            {
                if (rentedOpen is not null) Utf8ExactStatePool<int>.Return(rentedOpen, retain);
                if (rentedCounts is not null) Utf8ExactStatePool<int>.Return(rentedCounts, retain);
                invocation.Ledger.Release(temporaryBytes);
                if (!published)
                {
                    invocation.Ledger.Release(ownedBytes);
                    captureStarts = [];
                    captureLengths = [];
                }
            }
        }

        internal void ResetAttempt()
        {
            _frameCount = 0;
            _trailCount = 0;
            _journalCount = 0;
            _balanceCount = 0;
        }

        internal void ReleaseAll(ref Utf8SliceInvocation invocation)
        {
            if (_reservedBytes != 0)
            {
                invocation.Ledger.Release(_reservedBytes);
                _reservedBytes = 0;
            }

            _frameTables = Array.Empty<Utf8SliceFrame[]>();
            _trailTables = Array.Empty<Utf8SliceTrailEntry[]>();
            _journalTables = Array.Empty<Utf8SliceCountMutation[]>();
            _balanceTables = Array.Empty<Utf8SliceBalanceEntry[]>();
            _frameCount = 0;
            _trailCount = 0;
            _journalCount = 0;
            _balanceCount = 0;
        }

        private static bool Push<T>(ref T[][] tables, ref int count, int chunkCapacity,
            T value, ref Utf8SliceInvocation invocation, ref ulong reservedBytes, out Utf8ExecutionLimitKind breach)
            where T : struct
        {
            breach = Utf8ExecutionLimitKind.None;
            if (count == int.MaxValue) { breach = Utf8ExecutionLimitKind.WorkingBytes; return false; }
            var chunk = count / chunkCapacity;
            var slot = count % chunkCapacity;
            if (slot == 0 && (tables is null || chunk >= tables.Length || tables[chunk] is null))
            {
                var replaceTable = tables is null || chunk >= tables.Length;
                var oldCapacity = tables?.Length ?? 0;
                var capacity = oldCapacity == 0 ? ChunkTableCapacity :
                    oldCapacity <= Array.MaxLength / 2 ? oldCapacity * 2 : Array.MaxLength;
                if (replaceTable && capacity <= chunk) { breach = Utf8ExecutionLimitKind.WorkingBytes; return false; }
                var tableBytes = replaceTable ? Utf8ConstructionBudget.ArrayBytes<T[]>(capacity) : 0;
                var bytes = checked(tableBytes + Utf8ConstructionBudget.ArrayBytes<T>(chunkCapacity));
                breach = invocation.TryReserveWorking(bytes);
                if (breach != Utf8ExecutionLimitKind.None) return false;
                var adopted = false;
                try
                {
                    breach = invocation.TryChargeInputStep();
                    if (breach != Utf8ExecutionLimitKind.None) return false;
                    var candidate = replaceTable ? new T[capacity][] : tables ?? throw new InvalidOperationException("Live slice stack table is missing.");
                    if (replaceTable && tables is not null)
                    {
                        for (var offset = 0; offset < oldCapacity;)
                        {
                            breach = invocation.TryChargeInputStep();
                            if (breach != Utf8ExecutionLimitKind.None) return false;
                            var length = Math.Min(256, oldCapacity - offset);
                            tables.AsSpan(offset, length).CopyTo(candidate.AsSpan(offset, length));
                            offset += length;
                        }
                    }
                    breach = invocation.TryChargeInputStep();
                    if (breach != Utf8ExecutionLimitKind.None) return false;
                    var leaf = new T[chunkCapacity];
                    // Publish only after acquisition and copy complete. Failed growth
                    // leaves the original table, count and parent reservation intact.
                    var oldBytes = replaceTable ? Utf8ConstructionBudget.ArrayBytes<T[]>(oldCapacity) : 0;
                    candidate[chunk] = leaf;
                    tables = candidate;
                    invocation.Ledger.Release(oldBytes);
                    reservedBytes = checked(reservedBytes + bytes - oldBytes);
                    adopted = true;
                }
                finally { if (!adopted) invocation.Ledger.Release(bytes); }
            }
            tables[chunk][slot] = value;
            count++;
            return true;
        }
    }

    private static Utf8SliceMatchOutcome RunBackreference(Utf8SliceProgram program,
        in Utf8SliceInstruction instruction, ReadOnlySpan<byte> input,
        int[] captureStarts, int[] captureEnds, int inputIndex, ref Utf8SliceInvocation invocation)
    {
        // ECMAScript permits a defined group that has not completed a capture
        // yet to match an empty reference. Other unmatched references fail.
        if (captureStarts[instruction.A] < 0 || captureEnds[instruction.A] < 0)
            return new(instruction.C != 0, instruction.C != 0 ? inputIndex : -1,
                Utf8ExecutionLimitKind.None, null, null);

        var referStart = Math.Min(captureStarts[instruction.A], captureEnds[instruction.A]);
        var referEnd = Math.Max(captureStarts[instruction.A], captureEnds[instruction.A]);
        var referLength = referEnd - referStart;
        if (program.RightToLeft)
        {
            // Mirrored captures record their right edge at opening and left
            // edge at closing. Compare both spans from their own scalar ends.
            if (instruction.B != 0)
            {
                var capIndex = referEnd;
                var backIndex = inputIndex;
                while (capIndex > referStart)
                {
                    var charge = invocation.TryChargeStep();
                    if (charge != Utf8ExecutionLimitKind.None) return new(false, -1, charge, null, null);
                    if (backIndex <= 0 ||
                        !TryReadScalar(input, capIndex, true, out var captureScalar, out var capWidth) ||
                        capIndex - capWidth < referStart ||
                        !TryReadScalar(input, backIndex, true, out var inputScalar, out var inWidth) ||
                        !BackreferenceScalarsEqual(program, instruction, captureScalar, inputScalar))
                        return new(false, -1, Utf8ExecutionLimitKind.None, null, null);
                    capIndex -= capWidth;
                    backIndex -= inWidth;
                }
                return new(true, backIndex, Utf8ExecutionLimitKind.None, null, null);
            }
            if (referLength > inputIndex) return new(false, -1, Utf8ExecutionLimitKind.None, null, null);
            for (var compared = 0; compared < referLength; compared++)
            {
                var charge = invocation.TryChargeStep();
                if (charge != Utf8ExecutionLimitKind.None) return new(false, -1, charge, null, null);
                if (input[referEnd - 1 - compared] != input[inputIndex - 1 - compared])
                    return new(false, -1, Utf8ExecutionLimitKind.None, null, null);
            }
            return new(true, inputIndex - referLength, Utf8ExecutionLimitKind.None, null, null);
        }

        if (instruction.B != 0)
        {
            // Each side advances by its own UTF-8 scalar width (for example k
            // versus Kelvin), using the same existing profile equivalence.
            var capIndex = referStart;
            var backIndex = inputIndex;
            while (capIndex < referEnd)
            {
                var charge = invocation.TryChargeStep();
                if (charge != Utf8ExecutionLimitKind.None) return new(false, -1, charge, null, null);
                if (backIndex >= input.Length ||
                    !TryReadScalar(input, capIndex, false, out var captureScalar, out var capWidth) ||
                    capIndex + capWidth > referEnd ||
                    !TryReadScalar(input, backIndex, false, out var inputScalar, out var inWidth) ||
                    !BackreferenceScalarsEqual(program, instruction, captureScalar, inputScalar))
                    return new(false, -1, Utf8ExecutionLimitKind.None, null, null);
                capIndex += capWidth;
                backIndex += inWidth;
            }
            return new(true, backIndex, Utf8ExecutionLimitKind.None, null, null);
        }
        // A scalar-aligned capture has one strict UTF-8 encoding. Retain the
        // original work charge before every ordinal byte comparison.
        if (referLength > input.Length - inputIndex) return new(false, -1, Utf8ExecutionLimitKind.None, null, null);
        for (var compared = 0; compared < referLength; compared++)
        {
            var charge = invocation.TryChargeStep();
            if (charge != Utf8ExecutionLimitKind.None) return new(false, -1, charge, null, null);
            if (input[referStart + compared] != input[inputIndex + compared])
                return new(false, -1, Utf8ExecutionLimitKind.None, null, null);
        }
        return new(true, inputIndex + referLength, Utf8ExecutionLimitKind.None, null, null);
    }

    private static bool BackreferenceScalarsEqual(Utf8SliceProgram program,
        Utf8SliceInstruction instruction, Rune captured, Rune input)
    {
        if (instruction.D == 0) return Utf8SliceCaseEquivalences.ScalarsEquivalent(captured, input, program.CaseBehavior);
        var lower = program.BackreferenceLowerings[instruction.D - 1];
        return lower(captured.Value) == lower(input.Value);
    }

}
