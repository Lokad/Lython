using Lokad.Utf8Regex.Internal.Diagnostics;
using Lokad.Utf8Regex.Internal.Planning;
using Lokad.Utf8Regex.Internal.Search;

namespace Lokad.Utf8Regex.Internal.Execution;

internal static class Utf8SearchPortfolioRuntime
{
    private const int LargeAutomatonEarliestHybridChunkBytes = 512;
    private const int LargeAutomatonEarliestHybridNegativeProbeBytes = 2048;
    private const int LargeAutomatonHybridDemotionWindowCount = 16;
    private const int LargeAutomatonHybridMinSkippedWindows = 4;

    public static bool TryFindNextLiteralFamilyMatch(
        in Utf8SearchPlan plan,
        in Utf8SearchOperationPlan program,
        ReadOnlySpan<byte> input,
        ref PreparedMultiLiteralScanState state,
        Utf8ExecutionDeadline budget,
        out PreparedSearchMatch match)
    {
        match = default;
        if (!plan.HasPreparedSearcher)
        {
            return false;
        }

        while (true)
        {
            budget.Step();
            if (!plan.PreparedSearcher.TryFindNextNonOverlappingMatch(input, ref state, out match))
            {
                return false;
            }

            if (program.Confirmation.Kind == Utf8ConfirmationKind.None &&
                program.Kind is Utf8SearchOperationKind.DirectSearch or Utf8SearchOperationKind.HybridSearch)
            {
                return true;
            }

            if (Utf8ConfirmationExecutor.IsMatch(in plan, program.Confirmation, input, match.Index, match.Length))
            {
                return true;
            }
        }
    }

    public static bool TryFindNextOverlappingLiteralFamilyMatch(
        in Utf8SearchPlan plan,
        in Utf8SearchOperationPlan program,
        ReadOnlySpan<byte> input,
        ref PreparedMultiLiteralScanState state,
        Utf8ExecutionDeadline budget,
        out PreparedSearchMatch match)
    {
        match = default;
        if (!plan.HasPreparedSearcher)
        {
            return false;
        }

        while (true)
        {
            budget.Step();
            if (!plan.PreparedSearcher.TryFindNextNonOverlappingMatch(input, ref state, out match))
            {
                return false;
            }

            if (program.Confirmation.Kind == Utf8ConfirmationKind.None &&
                program.Kind is Utf8SearchOperationKind.DirectSearch or Utf8SearchOperationKind.HybridSearch)
            {
                return true;
            }

            if (Utf8ConfirmationExecutor.IsMatch(in plan, program.Confirmation, input, match.Index, match.Length))
            {
                return true;
            }

            if (plan.HasAlternateLiteralPrefixOverlap &&
                Utf8ConfirmationExecutor.TryFindConfirmedAlternateAtSameStart(
                    in plan,
                    program.Confirmation,
                    input,
                    in match,
                    out var confirmedMatch))
            {
                match = confirmedMatch;
                state = new PreparedMultiLiteralScanState(
                    match.Index + match.Length,
                    match.Index + match.Length,
                    0);
                return true;
            }

            if (plan.HasAlternateLiteralProperStartOverlap)
            {
                ResetAfterRejectedCandidate(ref state, match.Index);
            }
        }
    }

    public static bool IsMatchLiteralFamily(
        Utf8SearchPlan plan,
        Utf8SearchOperationPlan program,
        ReadOnlySpan<byte> input,
        Utf8ExecutionDeadline budget,
        bool rightToLeft)
    {
        if (!budget.IsInfinite || Utf8SearchDiagnosticsSession.Current?.SliceCheckpointHook is not null)
        {
            var invocation = new Utf8SliceInvocation(Utf8ExecutionLimits.Unlimited, budget, CancellationToken.None);
            var breach = Utf8SearchExecutor.TryFindLiteralFamily(plan, input, 0, input.Length,
                rightToLeft, ref invocation, out _, out var found);
            if (breach != Utf8ExecutionLimitKind.None)
                throw new InvalidOperationException($"Native literal-family execution exceeded {breach}.");
            return found;
        }
        if (!plan.HasPreparedSearcher)
        {
            return false;
        }

        if (rightToLeft)
        {
            budget.Step();
            return Utf8SearchExecutor.TryFindLastMatch(plan, input, input.Length, out _);
        }

        if (program.Confirmation.Kind == Utf8ConfirmationKind.None &&
            program.Kind is Utf8SearchOperationKind.DirectSearch or Utf8SearchOperationKind.HybridSearch)
        {
            budget.Step();
            return plan.PreparedSearcher.TryFindFirstMatch(input, out _);
        }

        var state = new PreparedSearchScanState(0, default);
        while (true)
        {
            budget.Step();
            if (!plan.PreparedSearcher.TryFindNextOverlappingMatch(input, ref state, out var match))
            {
                return false;
            }

            if (Utf8ConfirmationExecutor.IsMatch(plan, program.Confirmation, input, match.Index, match.Length))
            {
                return true;
            }

            if (plan.HasAlternateLiteralPrefixOverlap &&
                Utf8ConfirmationExecutor.TryFindConfirmedAlternateAtSameStart(
                    in plan,
                    program.Confirmation,
                    input,
                    in match,
                    out _))
            {
                return true;
            }
        }
    }

    public static int CountLiteralFamily(
        Utf8SearchPlan plan,
        Utf8SearchOperationPlan program,
        ReadOnlySpan<byte> input,
        Utf8ExecutionDeadline budget)
    {
        if (!budget.IsInfinite || Utf8SearchDiagnosticsSession.Current?.SliceCheckpointHook is not null)
        {
            var invocation = new Utf8SliceInvocation(Utf8ExecutionLimits.Unlimited, budget, CancellationToken.None);
            var breach = Utf8BackendInstructionExecutor.TryCountNativeLiteralMatches(plan, input, false, ref invocation, out var count);
            if (breach != Utf8ExecutionLimitKind.None)
                throw new InvalidOperationException($"Native literal-family execution exceeded {breach}.");
            return count;
        }
        if (!plan.HasPreparedSearcher)
        {
            return 0;
        }

        if (budget.IsInfinite &&
            program.Confirmation.Kind == Utf8ConfirmationKind.None &&
            program.Kind == Utf8SearchOperationKind.HybridSearch &&
            plan.MultiLiteralSearch.Kind == PreparedMultiLiteralKind.ExactAutomaton)
        {
            Utf8SearchDiagnosticsSession.Current?.MarkExecutionRoute(Utf8ExecutionRoute.LiteralFamilyHybridEarliestAutomaton);
            return CountLargeAutomatonFamilyViaEarliestHybrid(plan.MultiLiteralSearch, input, program.ObservabilityKind);
        }

        if (program.Confirmation.Kind == Utf8ConfirmationKind.None)
        {
            Utf8SearchDiagnosticsSession.Current?.MarkExecutionRoute(Utf8ExecutionRoute.LiteralFamilyPreparedNonOverlapping);
            var count = 0;
            var state = new PreparedMultiLiteralScanState(0, 0, 0);
            while (true)
            {
                budget.Step();
                if (!plan.PreparedSearcher.TryFindNextNonOverlappingLength(input, ref state, out _, out _))
                {
                    return count;
                }

                count++;
            }
        }

        if (plan.PreparedSearcher.Kind == PreparedSearcherKind.MultiLiteral &&
            !plan.HasAlternateLiteralPrefixOverlap &&
            !plan.HasAlternateLiteralProperStartOverlap)
        {
            Utf8SearchDiagnosticsSession.Current?.MarkExecutionRoute(Utf8ExecutionRoute.LiteralFamilyPreparedWithRequirementsLengthOnly);
            return budget.IsInfinite
                ? CountPreparedWithRequirementsLengthOnlyNoBudget(plan, program.Confirmation, input)
                : CountPreparedWithRequirementsLengthOnly(input, plan, program.Confirmation, budget);
        }

        Utf8SearchDiagnosticsSession.Current?.MarkExecutionRoute(Utf8ExecutionRoute.LiteralFamilyPreparedWithRequirementsMatch);
        return budget.IsInfinite
            ? CountPreparedWithRequirementsNoBudget(plan, program.Confirmation, input)
            : CountPreparedWithRequirements(input, plan, program.Confirmation, budget);
    }

    private static int CountPreparedWithRequirements(ReadOnlySpan<byte> input, Utf8SearchPlan plan, Utf8ConfirmationPlan confirmation, Utf8ExecutionDeadline budget)
    {
        var count = 0;
        var state = new PreparedMultiLiteralScanState(0, 0, 0);
        while (true)
        {
            budget.Step();
            if (!plan.PreparedSearcher.TryFindNextNonOverlappingMatch(input, ref state, out var match))
            {
                return count;
            }

            if (Utf8ConfirmationExecutor.IsMatch(plan, confirmation, input, match.Index, match.Length))
            {
                count++;
                continue;
            }

            if (plan.HasAlternateLiteralPrefixOverlap &&
                Utf8ConfirmationExecutor.TryFindConfirmedAlternateAtSameStart(
                    in plan,
                    confirmation,
                    input,
                    in match,
                    out var confirmedMatch))
            {
                state = new PreparedMultiLiteralScanState(
                    confirmedMatch.Index + confirmedMatch.Length,
                    confirmedMatch.Index + confirmedMatch.Length,
                    0);
                count++;
                continue;
            }

            if (plan.HasAlternateLiteralProperStartOverlap)
            {
                ResetAfterRejectedCandidate(ref state, match.Index);
            }
        }
    }

    private static int CountPreparedWithRequirementsLengthOnly(ReadOnlySpan<byte> input, Utf8SearchPlan plan, Utf8ConfirmationPlan confirmation, Utf8ExecutionDeadline budget)
    {
        var count = 0;
        var state = new PreparedMultiLiteralScanState(0, 0, 0);
        while (true)
        {
            budget.Step();
            if (!plan.PreparedSearcher.TryFindNextNonOverlappingLength(input, ref state, out var index, out var matchedLength))
            {
                return count;
            }

            if (Utf8ConfirmationExecutor.IsMatch(plan, confirmation, input, index, matchedLength))
            {
                count++;
            }
        }
    }

    private static int CountPreparedWithRequirementsLengthOnlyNoBudget(Utf8SearchPlan plan, Utf8ConfirmationPlan confirmation, ReadOnlySpan<byte> input)
    {
        var count = 0;
        var state = new PreparedMultiLiteralScanState(0, 0, 0);
        while (true)
        {
            if (!plan.PreparedSearcher.TryFindNextNonOverlappingLength(input, ref state, out var index, out var matchedLength))
            {
                return count;
            }

            if (Utf8ConfirmationExecutor.IsMatch(plan, confirmation, input, index, matchedLength))
            {
                count++;
            }
        }
    }

    private static int CountPreparedWithRequirementsNoBudget(Utf8SearchPlan plan, Utf8ConfirmationPlan confirmation, ReadOnlySpan<byte> input)
    {
        var count = 0;
        var state = new PreparedMultiLiteralScanState(0, 0, 0);
        while (true)
        {
            if (!plan.PreparedSearcher.TryFindNextNonOverlappingMatch(input, ref state, out var match))
            {
                return count;
            }

            if (Utf8ConfirmationExecutor.IsMatch(plan, confirmation, input, match.Index, match.Length))
            {
                count++;
                continue;
            }

            if (plan.HasAlternateLiteralPrefixOverlap &&
                Utf8ConfirmationExecutor.TryFindConfirmedAlternateAtSameStart(
                    in plan,
                    confirmation,
                    input,
                    in match,
                    out var confirmedMatch))
            {
                state = new PreparedMultiLiteralScanState(
                    confirmedMatch.Index + confirmedMatch.Length,
                    confirmedMatch.Index + confirmedMatch.Length,
                    0);
                count++;
                continue;
            }

            if (plan.HasAlternateLiteralProperStartOverlap)
            {
                ResetAfterRejectedCandidate(ref state, match.Index);
            }
        }
    }

    private static void ResetAfterRejectedCandidate(ref PreparedMultiLiteralScanState state, int candidateIndex)
    {
        var nextStart = candidateIndex + 1;
        state = new PreparedMultiLiteralScanState(nextStart, nextStart, 0);
    }

    private static int CountLargeAutomatonFamilyViaEarliestHybrid(
        PreparedMultiLiteralSearch search,
        ReadOnlySpan<byte> input,
        Utf8SearchObservabilityKind observabilityKind)
    {
        var earliest = search.EarliestSearch;
        var automaton = search.AutomatonSearch;
        if (earliest.ShortestLength == int.MaxValue || earliest.LongestLength == 0)
        {
            return 0;
        }

        var negativeProbeLength = Math.Min(input.Length, LargeAutomatonEarliestHybridNegativeProbeBytes);
        if (negativeProbeLength >= earliest.ShortestLength)
        {
            var initialProbe = input[..negativeProbeLength];
            var initialState = new PreparedMultiLiteralScanState(0, 0, 0);
            if (!earliest.TryFindNextNonOverlappingLength(initialProbe, ref initialState, out _, out _))
            {
                if (observabilityKind == Utf8SearchObservabilityKind.Effectiveness)
                {
                    Utf8SearchDiagnosticsSession.Current?.CountPrefilterWindow(promoted: false, input.Length);
                }

                return CountLargeAutomatonFamilyViaEarliest(search, input);
            }
        }

        var count = 0;
        var position = 0;
        var windows = 0;
        var skippedWindows = 0;
        while (position <= input.Length - earliest.ShortestLength)
        {
            var chunkEnd = Math.Min(input.Length, position + LargeAutomatonEarliestHybridChunkBytes);
            var probeEnd = Math.Min(input.Length, chunkEnd + earliest.LongestLength - 1);
            var probeWindow = input[position..probeEnd];
            var chunkByteCount = chunkEnd - position;
            var probeState = new PreparedMultiLiteralScanState(0, 0, 0);
            if (!earliest.TryFindNextNonOverlappingLength(probeWindow, ref probeState, out var probeIndex, out _) ||
                probeIndex >= chunkEnd - position)
            {
                if (observabilityKind == Utf8SearchObservabilityKind.Effectiveness)
                {
                    Utf8SearchDiagnosticsSession.Current?.CountPrefilterWindow(promoted: false, chunkByteCount);
                }
                windows++;
                skippedWindows++;
                position = chunkEnd;
                continue;
            }

            if (observabilityKind == Utf8SearchObservabilityKind.Effectiveness)
            {
                Utf8SearchDiagnosticsSession.Current?.CountPrefilterWindow(promoted: true, chunkByteCount);
            }
            windows++;
            if (windows >= LargeAutomatonHybridDemotionWindowCount &&
                skippedWindows < LargeAutomatonHybridMinSkippedWindows)
            {
                if (observabilityKind == Utf8SearchObservabilityKind.Effectiveness)
                {
                    Utf8SearchDiagnosticsSession.Current?.CountEngineDemotion();
                }
                return count + CountLargeAutomatonFamilyViaAutomatonFrom(search, input, position);
            }

            var state = new PreparedMultiLiteralScanState(0, 0, 0);
            var nextPosition = chunkEnd;
            while (automaton.TryFindNextNonOverlappingMatch(probeWindow, ref state, out var matchIndex, out _, out _))
            {
                if (matchIndex >= chunkEnd - position)
                {
                    nextPosition = position + matchIndex;
                    break;
                }

                count++;
                nextPosition = Math.Max(chunkEnd, position + state.NextStart);
            }

            position = nextPosition;
        }

        return count;
    }

    private static int CountLargeAutomatonFamilyViaEarliest(PreparedMultiLiteralSearch search, ReadOnlySpan<byte> input)
    {
        var count = 0;
        var state = new PreparedMultiLiteralScanState(0, 0, 0);
        while (search.EarliestSearch.TryFindNextNonOverlappingLength(input, ref state, out _, out _))
        {
            count++;
        }

        return count;
    }

    private static int CountLargeAutomatonFamilyViaAutomatonFrom(PreparedMultiLiteralSearch search, ReadOnlySpan<byte> input, int position)
    {
        if ((uint)position >= (uint)input.Length)
        {
            return 0;
        }

        var count = 0;
        var state = new PreparedMultiLiteralScanState(position, position, 0);
        while (search.AutomatonSearch.TryFindNextNonOverlappingMatch(input, ref state, out _, out _, out _))
        {
            count++;
        }

        return count;
    }

}
