using Lokad.Utf8Regex.Internal.Search;
using Lokad.Utf8Regex.Internal.Diagnostics;
using System.Globalization;
using System.Numerics;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Intrinsics;
using System.Text;

namespace Lokad.Utf8Regex.Internal.Execution;

// PCRE2-INTEGRATION-POINT: flavor-neutral category counting over caller-valid UTF-8.
internal static class Utf8UnicodeCategoryExecutor
{
    // ASCII categories are fixed scalar facts. Borrow the compiler's embedded
    // 128-byte data instead of acquiring a runtime category-map array.
    private static ReadOnlySpan<byte> AsciiCategoryMap =>
    [
        14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14,
        14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14,
        11, 24, 24, 24, 26, 24, 24, 24, 20, 21, 24, 25, 24, 19, 24, 24,
        8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 24, 24, 25, 25, 25, 24,
        24, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 20, 24, 21, 27, 18,
        27, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
        1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 20, 25, 21, 25, 14,
    ];
    private static readonly PreparedByteSetState s_asciiMathSymbols = PreparedByteSetState.FromValues("+<=>|~"u8);

    // The caller supplies a complete single-category language proof. Each
    // admitted primitive sees at most 4096 bytes, ending on a validated scalar
    // boundary. Keep the existing SIMD algorithm and charge even unlimited calls.
    internal static Utf8ExecutionLimitKind TryCountValidated(ReadOnlySpan<byte> input,
        UnicodeCategory category,
        ref Utf8SliceInvocation invocation, out int count)
    {
        count = 0;

        for (var offset = 0; offset < input.Length;)
        {
            var breach = invocation.TryChargeInputStep();
            invocation.Budget.ThrowIfCancellationRequested();
            if (breach != Utf8ExecutionLimitKind.None) return breach;
            var length = Utf8SliceBufferWork.Utf8BlockLength(input[offset..]);
            count += CountCategory(input.Slice(offset, length), category);
            offset += length;
        }
        var publication = invocation.TryChargeInputStep();
        invocation.Budget.ThrowIfCancellationRequested();
        return publication;
    }

    public static int CountCategory(
        ReadOnlySpan<byte> input,
        UnicodeCategory category)
    {
        if (category == UnicodeCategory.MathSymbol)
        {
            return CountMathSymbols(input);
        }

        var count = 0;
        var index = 0;
        var categoryByte = (byte)category;
        while (index < input.Length)
        {
            var first = input[index];
            if (first < 0x80)
            {
                if (AsciiCategoryMap[first] == categoryByte)
                {
                    count++;
                }

                index++;
                continue;
            }

            if ((first & 0xE0) == 0xC0)
            {
                var ch = (char)(((first & 0x1F) << 6) | (input[index + 1] & 0x3F));
                if (char.GetUnicodeCategory(ch) == category)
                {
                    count++;
                }

                index += 2;
                continue;
            }

            if ((first & 0xF0) == 0xE0)
            {
                var ch = (char)(((first & 0x0F) << 12) |
                                ((input[index + 1] & 0x3F) << 6) |
                                (input[index + 2] & 0x3F));
                if (char.GetUnicodeCategory(ch) == category)
                {
                    count++;
                }

                index += 3;
                continue;
            }

            var scalar = ((first & 0x07) << 18) |
                         ((input[index + 1] & 0x3F) << 12) |
                         ((input[index + 2] & 0x3F) << 6) |
                         (input[index + 3] & 0x3F);
            if (Rune.GetUnicodeCategory(new Rune(scalar)) == category)
            {
                count++;
            }

            index += 4;
        }

        return count;
    }

    private static int CountMathSymbols(ReadOnlySpan<byte> input)
    {
        // UTF-8 lead/continuation bytes are >=128 and cannot equal an ASCII
        // symbol. Count all such bytes once, instead of resetting the SIMD
        // counter and tail search for every intervening ASCII fragment.
        var count = CountAsciiMathSymbols(input);
        var index = 0;
        while (index < input.Length)
        {
            var nextNonAscii = input[index..].IndexOfAnyExceptInRange((byte)0x00, (byte)0x7F);
            if (nextNonAscii < 0)
            {
                break;
            }

            index += nextNonAscii;
            var first = input[index];
            if ((first & 0xE0) == 0xC0)
            {
                var ch = (char)(((first & 0x1F) << 6) | (input[index + 1] & 0x3F));
                if (char.GetUnicodeCategory(ch) == UnicodeCategory.MathSymbol)
                {
                    count++;
                }

                index += 2;
            }
            else if ((first & 0xF0) == 0xE0)
            {
                var ch = (char)(((first & 0x0F) << 12) |
                                ((input[index + 1] & 0x3F) << 6) |
                                (input[index + 2] & 0x3F));
                if (char.GetUnicodeCategory(ch) == UnicodeCategory.MathSymbol)
                {
                    count++;
                }

                index += 3;
            }
            else
            {
                var scalar = ((first & 0x07) << 18) |
                             ((input[index + 1] & 0x3F) << 12) |
                             ((input[index + 2] & 0x3F) << 6) |
                             (input[index + 3] & 0x3F);
                if (Rune.GetUnicodeCategory(new Rune(scalar)) == UnicodeCategory.MathSymbol)
                {
                    count++;
                }

                index += 4;
            }
        }

        return count;
    }

    private static int CountAsciiMathSymbols(ReadOnlySpan<byte> input)
    {
        var count = 0;
        var index = 0;
        if (Vector256.IsHardwareAccelerated && input.Length >= Vector256<byte>.Count)
        {
            count += CountAsciiMathSymbolsVector256(input, ref index);
        }
        else if (Vector128.IsHardwareAccelerated && input.Length >= Vector128<byte>.Count)
        {
            count += CountAsciiMathSymbolsVector128(input, ref index);
        }

        while (index < input.Length)
        {
            var relative = s_asciiMathSymbols.IndexOf(input[index..]);
            if (relative < 0)
            {
                break;
            }

            count++;
            index += relative + 1;
        }

        return count;
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    private static int CountAsciiMathSymbolsVector256(ReadOnlySpan<byte> input, ref int index)
    {
        var count = 0;
        var plus = Vector256.Create((byte)'+');
        var less = Vector256.Create((byte)'<');
        var equal = Vector256.Create((byte)'=');
        var greater = Vector256.Create((byte)'>');
        var pipe = Vector256.Create((byte)'|');
        var tilde = Vector256.Create((byte)'~');

        var vectors = MemoryMarshal.Cast<byte, Vector256<byte>>(input[index..]);
        for (var block = 0; block < vectors.Length; block++)
        {
            var current = vectors[block];
            var matches = Vector256.Equals(current, plus);
            matches = Vector256.BitwiseOr(matches, Vector256.Equals(current, less));
            matches = Vector256.BitwiseOr(matches, Vector256.Equals(current, equal));
            matches = Vector256.BitwiseOr(matches, Vector256.Equals(current, greater));
            matches = Vector256.BitwiseOr(matches, Vector256.Equals(current, pipe));
            matches = Vector256.BitwiseOr(matches, Vector256.Equals(current, tilde));
            count += BitOperations.PopCount(matches.ExtractMostSignificantBits());
        }

        index += vectors.Length * Vector256<byte>.Count;

        return count;
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    private static int CountAsciiMathSymbolsVector128(ReadOnlySpan<byte> input, ref int index)
    {
        var count = 0;
        var plus = Vector128.Create((byte)'+');
        var less = Vector128.Create((byte)'<');
        var equal = Vector128.Create((byte)'=');
        var greater = Vector128.Create((byte)'>');
        var pipe = Vector128.Create((byte)'|');
        var tilde = Vector128.Create((byte)'~');

        var vectors = MemoryMarshal.Cast<byte, Vector128<byte>>(input[index..]);
        for (var block = 0; block < vectors.Length; block++)
        {
            var current = vectors[block];
            var matches = Vector128.Equals(current, plus);
            matches = Vector128.BitwiseOr(matches, Vector128.Equals(current, less));
            matches = Vector128.BitwiseOr(matches, Vector128.Equals(current, equal));
            matches = Vector128.BitwiseOr(matches, Vector128.Equals(current, greater));
            matches = Vector128.BitwiseOr(matches, Vector128.Equals(current, pipe));
            matches = Vector128.BitwiseOr(matches, Vector128.Equals(current, tilde));
            count += BitOperations.PopCount(matches.ExtractMostSignificantBits());
        }

        index += vectors.Length * Vector128<byte>.Count;

        return count;
    }
}
