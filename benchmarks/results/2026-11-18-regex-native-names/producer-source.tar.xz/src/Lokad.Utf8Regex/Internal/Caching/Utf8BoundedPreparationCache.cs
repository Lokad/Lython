using System.Runtime.ExceptionServices;
using Lokad.Utf8Regex.Internal.FrontEnd;

namespace Lokad.Utf8Regex.Internal.Caching;

/// <summary>Owns bounded preparation-entry metadata. Pending entries share one
/// preparation without retaining its factory, state or invocation controls.
/// Immutable payload charges have a separate conservative capacity bound.
/// Shared storage across entries is
/// charged repeatedly; no retained manifests or global identity registry.
/// These modeled cache charges do not bound total program/process memory;
/// public invocation and construction policies have their own documented scope.
/// PCRE2-INTEGRATION-POINT</summary>
internal sealed class Utf8BoundedPreparationCache<TKey, TValue> where TKey : notnull
{
    internal const ulong DefaultMaximumMetadataBytes = 64 * 1024;
    internal const ulong DefaultMaximumPayloadBytes = 4 * 1024 * 1024;
    private CacheEntry? _first;
    private CacheEntry? _last;
    private readonly IEqualityComparer<TKey> _comparer;
    private int _capacity;
    private int _count;
    private readonly ulong _maximumMetadataBytes;
    private long _generation;
    private readonly ulong _maximumPayloadBytes;
    private ulong _payloadBytes;
    private IUtf8MemoryAllowance? _memoryAllowance;

    private Utf8BoundedPreparationCache(IEqualityComparer<TKey> comparer, int capacity, ulong maximumMetadataBytes,
        ulong maximumPayloadBytes)
    { _comparer = comparer; _capacity = capacity; _maximumMetadataBytes = maximumMetadataBytes; _maximumPayloadBytes = maximumPayloadBytes; }

    internal static ulong ObjectBytes => Utf8ConstructionBudget.ObjectBytes<
        (CacheEntry?, CacheEntry?, IEqualityComparer<TKey>, int, int, ulong, long, ulong, ulong, IUtf8MemoryAllowance?)>();
    internal static ulong EntryBytes => Utf8ConstructionBudget.ObjectBytes<
        (TKey, ValueTuple<TValue>, Exception?, CacheEntry?, int, int, int, ulong, Utf8FundedStorage?)>();
    private ulong BaseMetadataBytes => ObjectBytes;

    internal static Utf8BoundedPreparationCache<TKey, TValue> CreateRetained(int capacity, IEqualityComparer<TKey> comparer)
        => CreateRetained(capacity, comparer, DefaultMaximumMetadataBytes, DefaultMaximumPayloadBytes);

    internal static Utf8BoundedPreparationCache<TKey, TValue> CreateRetained(int capacity,
        IEqualityComparer<TKey> comparer, ulong maximumMetadataBytes, ulong maximumPayloadBytes)
    {
        ArgumentOutOfRangeException.ThrowIfZero(maximumPayloadBytes);
        ArgumentOutOfRangeException.ThrowIfNegative(capacity);
        if (maximumMetadataBytes < ObjectBytes) throw new ArgumentOutOfRangeException(nameof(maximumMetadataBytes));
        using var owner = Utf8ConstructionScope.Enter();
        var result = owner.Budget.AllocateObject(
            (First: (CacheEntry?)null, Last: (CacheEntry?)null, Comparer: comparer, Capacity: capacity, Count: 0, Maximum: maximumMetadataBytes, Generation: 0L, MaximumPayload: maximumPayloadBytes, PayloadBytes: 0UL, Funding: (IUtf8MemoryAllowance?)null),
            static state => new Utf8BoundedPreparationCache<TKey, TValue>(state.Comparer, state.Capacity, state.Maximum, state.MaximumPayload));
        owner.Complete();
        return result;
    }

    internal int Count { get { lock (this) return _count; } }
    internal ulong MetadataBytes { get { lock (this) return BaseMetadataBytes + (ulong)_count * EntryBytes; } }
    internal ulong MaximumMetadataBytes => _maximumMetadataBytes;
    internal ulong PayloadBytes { get { lock (this) return _payloadBytes; } }
    internal ulong MaximumPayloadBytes => _maximumPayloadBytes;

    // Set once before the containing program is published. Funded callers must
    // acquire an explicit use so removal cannot refund an active immutable plan.
    internal void EnableFunding(IUtf8MemoryAllowance allowance)
    {
        lock (this)
        {
            if (_memoryAllowance is not null || _count != 0)
                throw new InvalidOperationException("Funding must be configured on an unpublished empty cache.");
            _memoryAllowance = allowance;
        }
    }
    internal int Capacity
    {
        get => Volatile.Read(ref _capacity);
        set
        {
            ArgumentOutOfRangeException.ThrowIfNegative(value);
            lock (this)
            {
                if (value < _capacity) _generation++;
                _capacity = value;
                while (_count > value && _first is { } first) Remove(first);
            }
        }
    }

    // Controls, storage probes and key comparers are closed non-mutating
    // implementations. Factories alone execute outside the owner lock.
    internal bool TryGet<TLookup, TState, TControl>(TLookup lookup, TState state,
        Func<TKey, TLookup, TState, bool> matches, TControl control,
        out TValue value, out Utf8FundedStorage.Use? memoryUse)
        where TLookup : allows ref struct
        where TControl : struct, IUtf8ConstructionTextControl
    {
        memoryUse = null;
        try
        {
            lock (this)
            {
                control.Check();
                // A borrowed query never enters retained storage. Reuse Read
                // for ready/pending entries, including its existing active use
                // before a wait releases the lock or eviction detaches a value.
                if (_capacity != 0)
                    for (var entry = _first; entry is not null; entry = entry.Next)
                    {
                        control.Check();
                        if (!matches(entry.Key, lookup, state)) continue;
                        value = Read(entry, control, ref memoryUse);
                        return true;
                    }
            }
            control.Check();
            value = default!;
            return false;
        }
        catch { memoryUse?.Dispose(); memoryUse = null; throw; }
    }

    internal TValue GetOrAdd<TState, TControl, TStorage>(TKey key, TState state,
        Func<TKey, TState, TValue> factory, TControl control, TStorage storage)
        where TControl : struct, IUtf8ConstructionTextControl
        where TStorage : struct, IUtf8RetainedStorage<TKey, TValue>
    {
        if (_memoryAllowance is not null)
            throw new InvalidOperationException("Funded cache values require an explicit active use.");
        return GetOrAdd(key, state, factory, control, storage, out _);
    }

    internal TValue GetOrAdd<TState, TControl, TStorage>(TKey key, TState state,
        Func<TKey, TState, TValue> factory, TControl control, TStorage storage,
        out Utf8FundedStorage.Use? memoryUse)
        where TControl : struct, IUtf8ConstructionTextControl
        where TStorage : struct, IUtf8RetainedStorage<TKey, TValue>
    {
        memoryUse = null;
        using var funding = EnterFunding(control);
        try
        {
            var value = GetOrAddCore(key, state, factory, control, storage, funding, ref memoryUse);
            funding?.Complete();
            return value;
        }
        catch { memoryUse?.Dispose(); throw; }
    }

    // A foreign pending owner's interruption must not become this caller's
    // authority. Prepare exactly once under its own controls, without retention.
    internal TValue PrepareForUse<TState, TControl>(TKey key, TState state,
        Func<TKey, TState, TValue> factory, TControl control, out Utf8FundedStorage.Use? memoryUse)
        where TControl : struct, IUtf8ConstructionTextControl
    {
        memoryUse = null;
        using var funding = EnterFunding(control);
        try
        {
            var value = PrepareUncached(key, state, factory, control);
            value = Complete(null, value, funding, null, control, ref memoryUse);
            funding?.Complete();
            return value;
        }
        catch { memoryUse?.Dispose(); throw; }
    }

    private Utf8ConstructionScope? EnterFunding<TControl>(TControl control)
        where TControl : struct, IUtf8ConstructionTextControl
        => _memoryAllowance is { } allowance ? EnterFunding(allowance, control) : null;

    private static Utf8ConstructionScope EnterFunding<TControl>(IUtf8MemoryAllowance allowance, TControl control)
        where TControl : struct, IUtf8ConstructionTextControl
    {
        var scope = Utf8ConstructionScope.Enter(default, Timeout.InfiniteTimeSpan, default, allowance);
        try { scope.Budget.CheckpointHook = _ => control.Check(); return scope; }
        catch { scope.Dispose(); throw; }
    }

    private TValue GetOrAddCore<TState, TControl, TStorage>(TKey key, TState state,
        Func<TKey, TState, TValue> factory, TControl control, TStorage storage,
        Utf8ConstructionScope? funding, ref Utf8FundedStorage.Use? memoryUse)
        where TControl : struct, IUtf8ConstructionTextControl
        where TStorage : struct, IUtf8RetainedStorage<TKey, TValue>
    {
        Utf8ConstructionScope? cleanup = null;
        try
        {
            control.Check();
            if (Capacity == 0) return Complete(null, PrepareUncached(key, state, factory, control), funding, null, control, ref memoryUse);
            var keyCharge = storage.GetKeyCharge(key);
            if (keyCharge > _maximumPayloadBytes)
            {
                // This immutable owner can never retain the key. Do not hash or
                // compare its text before the factory's construction admission.
                using var oversized = Utf8ConstructionScope.Enter();
                oversized.Budget.ChargeWork(1);
                return Complete(oversized, PrepareUncached(key, state, factory, control), funding, null, control, ref memoryUse);
            }
            var hash = _comparer.GetHashCode(key);
            CacheEntry? entry = null;
            long generation;
            Utf8ConstructionScope preparation;
            lock (this)
            {
                generation = _generation;
                var existing = Find(key, hash, control);
                if (existing is not null) return Read(existing, control, ref memoryUse);
                preparation = Utf8ConstructionScope.Enter();
                cleanup = preparation;
                control.Check();
                preparation.Budget.ChargeWork(1);
                if (CanAdd())
                {
                    try
                    {
                        entry = Acquire(key, default, null, 0, Environment.CurrentManagedThreadId, hash, keyCharge, keyCharge, funding, ref memoryUse);
                        control.Check();
                        if (!PublishCharge(entry, null, keyCharge, false, generation, control))
                        {
                            entry.Memory?.Close(); memoryUse?.Dispose(); memoryUse = null; entry = null;
                        }
                    }
                    catch { entry?.Memory?.Close(); throw; }
                }
            }
            // A full cache does not evict a useful value before knowing that a new
            // preparation succeeds. No pending metadata is acquired in this lane.
            if (entry is null)
            {
                var value = PrepareUncached(key, state, factory, control);
                lock (this)
                {
                    control.Check();
                    if (_generation != generation) return Complete(preparation, value, funding, null, control, ref memoryUse);
                    var existing = Find(key, hash, control);
                    if (existing is not null) return Read(existing, control, ref memoryUse);
                    if (_capacity == 0 || EntryBytes > _maximumMetadataBytes - BaseMetadataBytes) return Complete(preparation, value, funding, null, control, ref memoryUse);
                    CacheEntry? victim = null;
                    if (!CanAdd())
                    {
                        victim = _first;
                        while (victim is not null && victim.Status == 0) { control.Check(); victim = victim.Next; }
                        if (victim is null) return Complete(preparation, value, funding, null, control, ref memoryUse);
                    }
                    var charge = CollectCharge(keyCharge, value, storage, control, out var fits);
                    if (!fits) return Complete(preparation, value, funding, null, control, ref memoryUse);
                    var completed = Acquire(key, new(value), null, 1, 0, hash, charge, keyCharge, funding, ref memoryUse);
                    try
                    {
                        Complete(preparation, value, funding, completed, control, ref memoryUse);
                        if (!PublishCharge(completed, null, charge, true, generation, control)) completed.Memory?.Close();
                    }
                    catch { completed.Memory?.Close(); throw; }
                }
                preparation.Complete();
                return value;
            }
            try
            {
                var value = PrepareUncached(key, state, factory, control);
                lock (this)
                {
                    var present = Contains(entry);
                    var fits = false;
                    var charge = present ? CollectCharge(keyCharge, value, storage, control, out fits) : 0;
                    Complete(preparation, value, funding, entry, control, ref memoryUse);
                    if (present)
                    {
                        if (!fits || !PublishCharge(entry, entry, charge, true, generation, control)) Remove(entry);
                    }
                    else entry.Memory?.Close();
                    entry.Value = new(value); entry.OwnerThread = 0; entry.Status = 1;
                    // A detached generation can satisfy its existing waiters, but
                    // never repopulates the list after Clear or a capacity shrink.
                    Monitor.PulseAll(this);
                }
                preparation.Complete();
                return value;
            }
            catch (Exception failure)
            {
                lock (this)
                {
                    entry.Error = failure; entry.OwnerThread = 0; entry.Status = 2;
                    Remove(entry);
                    entry.Memory?.Close();
                    Monitor.PulseAll(this);
                }
                throw;
            }
        }
        finally { cleanup?.Dispose(); }
    }

    private TValue Complete<TControl>(Utf8ConstructionScope? owner, TValue value,
        Utf8ConstructionScope? funding, CacheEntry? entry, TControl control, ref Utf8FundedStorage.Use? memoryUse)
        where TControl : struct, IUtf8ConstructionTextControl
    {
        if (funding is null) { owner?.Complete(); return value; }
        // Mark the nested scope before transferring the root's bytes: later
        // publication interruption must not roll back to a pre-transfer checkpoint.
        owner?.Complete();
        var memory = entry?.Memory;
        if (memory is null)
        {
            memory = NewMemory(funding.Budget);
            memoryUse = memory.Enter();
        }
        control.Check();
        memory.Retain(funding.Budget.TransferFundedBytes());
        if (entry is null) memory.Close();
        return value;
    }

    private Utf8FundedStorage NewMemory(Utf8ConstructionBudget budget) => budget.AllocateObject(_memoryAllowance!,
        static allowance => new Utf8FundedStorage(allowance, "prepared storage"));

    private static TValue PrepareUncached<TState, TControl>(TKey key, TState state, Func<TKey, TState, TValue> factory, TControl control)
        where TControl : struct, IUtf8ConstructionTextControl
    {
        control.Check();
        var value = factory(key, state);
        control.Check();
        return value;
    }

    private bool CanAdd() => _count < _capacity && EntryBytes <= _maximumMetadataBytes - BaseMetadataBytes - (ulong)_count * EntryBytes;

    private ulong CollectCharge<TStorage, TControl>(ulong keyCharge, TValue value, TStorage storage,
        TControl control, out bool fits)
        where TControl : struct, IUtf8ConstructionTextControl
        where TStorage : struct, IUtf8RetainedStorage<TKey, TValue>
    {
        if (keyCharge > _maximumPayloadBytes) { fits = false; return 0; }
        var remaining = _maximumPayloadBytes - keyCharge;
        fits = storage.TryGetValueCharge(value, remaining, control, out var valueCharge) && valueCharge <= remaining;
        // The provider admits value capacity against the remainder, so this sum
        // cannot overflow. Key/value sharing intentionally earns no discount.
        return fits ? keyCharge + valueCharge : 0;
    }

    private bool Contains(CacheEntry target)
    {
        for (var entry = _first; entry is not null; entry = entry.Next)
            if (ReferenceEquals(entry, target)) return true;
        return false;
    }

    // Closed controls/providers may interrupt, but never mutate this cache under
    // its lock. The outside-lock factory may reenter or race Clear/shrink; its
    // captured generation still prevents stale publication. Plan before eviction
    // so interruption leaves ready values and their aliases intact.
    private bool PublishCharge<TControl>(CacheEntry candidate, CacheEntry? replacing,
        ulong charge, bool mayEvict, long generation, TControl control)
        where TControl : struct, IUtf8ConstructionTextControl
    {
        control.Check();
        Utf8ConstructionScope.ChargeWork(1);
        if (charge > _maximumPayloadBytes || _generation != generation ||
            replacing is not null && !Contains(replacing)) return false;
        var bytes = _payloadBytes - (replacing?.PayloadCharge ?? 0);
        var retained = _count - (replacing is null ? 0 : 1);
        var victims = 0;
        for (var entry = _first; entry is not null; entry = entry.Next)
        {
            if (HasRoomForCharge(bytes, retained, charge)) break;
            control.Check();
            Utf8ConstructionScope.ChargeWork(1);
            if (!mayEvict || ReferenceEquals(entry, replacing) || entry.Status != 1) continue;
            bytes -= entry.PayloadCharge;
            retained--;
            victims++;
        }
        control.Check();
        if (!HasRoomForCharge(bytes, retained, charge)) return false;
        // No allocation, callback or fallible arithmetic remains after this point.
        for (var entry = _first; entry is not null && victims > 0;)
        {
            var next = entry.Next;
            if (!ReferenceEquals(entry, replacing) && entry.Status == 1) { Remove(entry); victims--; }
            entry = next;
        }
        _payloadBytes -= replacing?.PayloadCharge ?? 0;
        candidate.PayloadCharge = charge;
        _payloadBytes += charge;
        if (replacing is null) Append(candidate);
        return true;
    }

    private bool HasRoomForCharge(ulong bytes, int retained, ulong charge) =>
        bytes <= _maximumPayloadBytes - charge && retained < _capacity &&
        (ulong)(retained + 1) * EntryBytes <= _maximumMetadataBytes - BaseMetadataBytes;

    private CacheEntry? Find<TControl>(TKey key, int hash, TControl control)
        where TControl : struct, IUtf8ConstructionTextControl
    {
        for (var entry = _first; entry is not null; entry = entry.Next)
        { control.Check(); if (entry.Hash == hash && _comparer.Equals(entry.Key, key)) return entry; }
        return null;
    }

    private TValue Read<TControl>(CacheEntry entry, TControl control, ref Utf8FundedStorage.Use? memoryUse)
        where TControl : struct, IUtf8ConstructionTextControl
    {
        // Acquire while still under the cache lock, including before a pending
        // wait. Clear/eviction can then detach the entry without invalidating
        // waiters or refunding its future completed charge ahead of its users.
        memoryUse = entry.Memory?.Enter();
        while (entry.Status == 0)
        {
            control.Check();
            if (entry.OwnerThread == Environment.CurrentManagedThreadId)
                throw new InvalidOperationException("A preparation cannot recursively acquire its own cache entry.");
            // Waiting releases the cache lock. Invocation controls stay on the
            // caller's stack and can abort a follower without removing the owner.
            Monitor.Wait(this, 20);
        }
        control.Check();
        if (entry.Error is not null) ExceptionDispatchInfo.Throw(entry.Error);
        return entry.Value.Item1;
    }

    private CacheEntry Acquire(TKey key, ValueTuple<TValue> value, Exception? error, int status, int ownerThread, int hash,
        ulong charge, ulong keyCharge, Utf8ConstructionScope? funding, ref Utf8FundedStorage.Use? memoryUse)
    {
        using var owner = Utf8ConstructionScope.Enter();
        Utf8FundedStorage? memory = null;
        try
        {
            if (funding is not null)
            {
                owner.Budget.ReserveBytes(keyCharge);
                memory = NewMemory(owner.Budget);
                memoryUse = memory.Enter();
            }
            var result = owner.Budget.AllocateObject((key, value, error, Next: (CacheEntry?)null, status, ownerThread, hash, charge, memory),
                static state => new CacheEntry(state.key, state.value, state.error, state.status, state.ownerThread, state.hash, state.charge, state.memory));
            owner.Complete();
            return result;
        }
        catch { memory?.Close(); throw; }
    }

    private void Append(CacheEntry entry)
    {
        if (_last is null) _first = entry; else _last.Next = entry;
        _last = entry; _count++;
    }

    private void Remove(CacheEntry target)
    {
        CacheEntry? previous = null;
        for (var entry = _first; entry is not null; previous = entry, entry = entry.Next)
        {
            if (!ReferenceEquals(entry, target)) continue;
            if (previous is null) _first = entry.Next; else previous.Next = entry.Next;
            if (ReferenceEquals(_last, entry)) _last = previous;
            _payloadBytes -= entry.PayloadCharge;
            entry.Next = null; entry.PayloadCharge = 0; _count--;
            entry.Memory?.Close();
            return;
        }
    }

    internal void Clear()
    {
        lock (this)
        {
            _generation++;
            while (_first is not null) Remove(_first);
        }
    }

    private sealed class CacheEntry(TKey key, ValueTuple<TValue> value, Exception? error, int status, int ownerThread, int hash,
        ulong charge, Utf8FundedStorage? memory)
    {
        internal readonly TKey Key = key;
        internal ValueTuple<TValue> Value = value;
        internal Exception? Error = error;
        internal CacheEntry? Next;
        internal int Status = status;
        internal int OwnerThread = ownerThread;
        internal readonly int Hash = hash;
        internal ulong PayloadCharge = charge;
        internal readonly Utf8FundedStorage? Memory = memory;
    }
}
