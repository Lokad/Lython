from pathlib import Path
r=Path(__file__).parent
old=(r.parent/'regex-refresh-r521/finish-adapter.py').read_text(encoding='utf-8')
tail=old[old.index('images={};'):]
header="from pathlib import Path\nimport hashlib,json,shutil\nr=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');work=repo;project=r/'adapter'\n"
(r/'copy-consumers.py').write_text(header+tail,encoding='utf-8',newline='\n')
(r/'qualify.py').write_text((r.parent/'regex-refresh-r521/qualify.py').read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
print('Existing exact parent/subprocess consumer qualification reused; no repeated adapter build.')
