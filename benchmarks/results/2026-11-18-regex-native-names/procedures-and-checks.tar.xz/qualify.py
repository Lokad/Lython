from pathlib import Path
import hashlib,json,os,subprocess,time,xml.etree.ElementTree as E
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe')
env=os.environ.copy();env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent),DOTNET_HOST_PATH=str(d));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
identity=json.loads((r/'image-identity.json').read_text(encoding='utf-8'));rows=[]
for tfm in ['net11.0','net10.0']:
 image=r/'consumers'/tfm;fixture=image/'tests/Lokad.Lython.WorkerFixture/bin/Release'/tfm
 for n,h in identity['images'][tfm].items():assert hashlib.sha256((image/n).read_bytes()).hexdigest()==h
 for n in ['Lokad.Lython.dll','Lokad.Lython.Utf8Regex.dll','Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll']:assert(image/n).read_bytes()==(fixture/n).read_bytes()
 results=r/'checks'/tfm;results.mkdir(parents=True,exist_ok=False);start=time.monotonic()
 with(results/'test.log').open('w',encoding='utf-8')as log:p=subprocess.run([str(d),'vstest',str(image/'Lokad.Lython.PublicApi.Tests.dll'),'--TestCaseFilter:Category!=Stress&FullyQualifiedName~Regex','--Logger:trx;LogFileName=regex.trx','--ResultsDirectory:'+str(results)],env=env,cwd=repo,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 trx=E.parse(results/'regex.trx');counts=trx.find('{http://microsoft.com/schemas/VisualStudio/TeamTest/2010}ResultSummary/{http://microsoft.com/schemas/VisualStudio/TeamTest/2010}Counters').attrib
 row=dict(framework=tfm,exitCode=p.returncode,elapsedSeconds=time.monotonic()-start,counts=counts,parentAndChildHashesVerified=True);rows.append(row)
 (r/'checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n');print(row,flush=True)
 assert p.returncode==0,(results/'test.log').read_text(encoding='utf-8')[-4500:]
print('Changed bounded cursor modes pass semantics/cancellation/refusal/ownership in both actual frameworks. No normal pin/release qualification inferred.',flush=True)
