from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-18-regex-native-names';out.mkdir(exist_ok=False)
checks=json.loads((r/'checks.json').read_text(encoding='utf-8'))
assert len(checks)==2 and all(row['exitCode']==0 and row['counts']['passed']=='363'for row in checks)
probes=json.loads((r/'name-probes.json').read_text(encoding='utf-8'))
assert len(probes)==4 and all(row['exitCode']==0 for row in probes)
for name in ['producer-source.tar.xz','source-facts.json','image-identity.json','checks.json','name-probes.json','names.py']:
    shutil.copyfile(r/name,out/name)
identity=json.loads((r/'image-identity.json').read_text(encoding='utf-8'))
with tarfile.open(out/'qualified-libraries.tar.xz','w:xz')as a:
    for tfm,files in identity['images'].items():
        for name,h in files.items():
            p=r/'consumers'/tfm/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==h
            a.add(p,arcname=tfm+'/'+name)
        child=r/'consumers'/tfm/'tests/Lokad.Lython.WorkerFixture/bin/Release'/tfm
        for name in ['Lokad.Lython.WorkerFixture.dll','Lokad.Lython.WorkerFixture.deps.json','Lokad.Lython.WorkerFixture.runtimeconfig.json']:
            a.add(child/name,arcname=tfm+'/worker/'+name)
with tarfile.open(out/'procedures-and-checks.tar.xz','w:xz')as a:
    for p in sorted(r.rglob('*')):
        if not p.is_file()or {'producer','consumers','probes','bin','obj'}&set(p.relative_to(r).parts):continue
        if p.name=='producer-source.tar.xz':continue
        a.add(p,arcname=p.relative_to(r).as_posix())
    a.add(r.parent/'prepare-regex-r528.py',arcname='prepare-regex-r528.py')
facts=dict(coreSource='925397f65; full source platform delivery recorded separately',
 producer='7be8240f31901e9fb96c278759b96d2ee4267df9',
 localPython=subprocess.check_output(['C:/Python313/python.exe','-X','utf8','--version'],text=True,encoding='utf-8').strip(),
 actualTargets=['net11.0','net10.0'],regexChecksPerTarget=363,pythonProbeRuns=4,developmentOnly=True,
 normalAdapterPin='0.4.0',coreDependenciesUnchanged=True,noProducerSafetyCertification=True,noPerformanceClaim=True,publicationHeld=True)
(out/'qualification.json').write_text(json.dumps(facts,indent=2)+'\n',encoding='utf-8')
print(out)
