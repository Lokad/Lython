from pathlib import Path
import hashlib,io,json,os,subprocess,tarfile
repo=Path('D:/code/Lython');r=Path(__file__).parent/'regex-native-names-r528';r.mkdir(exist_ok=False)
sibling=Path('D:/code/utf8regex')
revision=subprocess.check_output(['git','rev-parse','7be8240f'],cwd=sibling,text=True).strip()
data=subprocess.check_output(['git','archive','--format=tar',revision,'src','Directory.Build.props','global.json'],cwd=sibling)
source=r/'producer';source.mkdir()
with tarfile.open(fileobj=io.BytesIO(data))as a:a.extractall(source,filter='data')
with tarfile.open(r/'producer-source.tar.xz','w:xz')as a:
 for p in sorted(source.rglob('*')):
  if p.is_file():a.add(p,arcname=p.relative_to(source).as_posix())
facts=dict(revision=revision,readOnlyCommittedBlobs=True,producerWorktreeNotModified=True,
 sourceArchiveSHA256=hashlib.sha256((r/'producer-source.tar.xz').read_bytes()).hexdigest(),
 normalAdapterPin='0.4.0',coreDependenciesUnchanged=True,developmentOnly=True,publicationHeld=True,
 policy='Producer source retains Unsafe.SizeOf APIs; no safety certification or new production dependency. Disallow unsafe C# for this development build.',
 resolved=['Native per-slot UTF8 capture-name copying; GetGroupNames/name entries on results removed'],
 remaining=['creation/preparation token detached from later pulls','separate result-stage allowance'])
(r/'source-facts.json').write_text(json.dumps(facts,indent=2)+'\n',encoding='utf-8',newline='\n')
d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy()
env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
cmd=[str(d),'build',str(source/'src/Lokad.Utf8Regex.PythonRe/Lokad.Utf8Regex.PythonRe.csproj'),'-c','Release','--no-incremental','-p:AllowUnsafeBlocks=false','-p:EnableSourceControlManagerQueries=false']
with(r/'producer-build.log').open('w',encoding='utf-8')as log:p=subprocess.run(cmd,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
assert p.returncode==0,(r/'producer-build.log').read_text(encoding='utf-8')[-5000:]
print('Committed producer',revision,'builds both actual targets; sibling worktree untouched, normal pin/core dependencies unchanged.',flush=True)
