from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).parent;repo=Path('D:/code/Lython');d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe')
source=r/'names.py'
source.write_text(r'''import re
p=re.compile(r"(?P<x>a)(b)(?P<ééééééééé名>c)(?P<abcdefghijklmnopqrstuvwxyz_abcdef>d)")
m=p.fullmatch('abcd')
assert p.groups==4
assert list(p.groupindex.items())==[('x',1),('ééééééééé名',3),('abcdefghijklmnopqrstuvwxyz_abcdef',4)]
assert m.groups()==('a','b','c','d')
assert m.group('ééééééééé名')=='c'
assert m.lastindex==4 and m.lastgroup=='abcdefghijklmnopqrstuvwxyz_abcdef'
assert m.expand(r'\g<x>:\g<ééééééééé名>:\g<abcdefghijklmnopqrstuvwxyz_abcdef>')=='a:c:d'
re.purge()
assert m.groupdict()=={'x':'a','ééééééééé名':'c','abcdefghijklmnopqrstuvwxyz_abcdef':'d'}
assert not re.compile('(a)(b)').groupindex
assert re.compile('(a)(b)').fullmatch('ab').groupdict()=={}
assert re.compile('abcd').groups==0
assert re.compile('abcd').fullmatch('abcd').groupdict()=={}
n=re.fullmatch(r'(?P<outer>(?P<ééééééééé名>a))','a')
assert n.lastindex==1 and n.lastgroup=='outer'
print('native names: short, unnamed, long ASCII, long UTF-8, aliases, closure order')
''',encoding='utf-8',newline='\n')
env=os.environ.copy();env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
rows=[]
for tfm in ['net11.0','net10.0']:
    image=r/'probes'/tfm;shutil.copytree(repo/'tools/LythonProbe/bin/Release'/tfm,image,copy_function=shutil.copyfile)
    for name in ['Lokad.Lython.dll','Lokad.Lython.Utf8Regex.dll','Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll']:
        shutil.copyfile(r/'consumers'/tfm/name,image/name)
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in image.glob('*.dll')}
    for asynchronous in [False,True]:
        assert all(hashlib.sha256((image/n).read_bytes()).hexdigest()==h for n,h in hashes.items())
        cmd=[str(d),str(image/'LythonProbe.dll'),str(source),'--json','--compare-python','--python','C:/Python313/python.exe','--max-memory-bytes','4194304']
        if asynchronous:cmd.append('--async')
        p=subprocess.run(cmd,cwd=repo,env=env,capture_output=True,text=True,encoding='utf-8',timeout=60)
        log=r/(tfm+('-async'if asynchronous else'-sync')+'-names.json')
        log.write_text(p.stdout,encoding='utf-8');(r/(log.stem+'.stderr')).write_text(p.stderr,encoding='utf-8')
        rows.append(dict(framework=tfm,asynchronous=asynchronous,exitCode=p.returncode,hashes=hashes))
        (r/'name-probes.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8')
        assert p.returncode==0,p.stdout+p.stderr
        print(tfm,'async'if asynchronous else'sync','matches actual CPython for native-name boundaries and retained aliases.',flush=True)
