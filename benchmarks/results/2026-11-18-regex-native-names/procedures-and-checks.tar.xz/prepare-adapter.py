from pathlib import Path
import os,subprocess
r=Path(__file__).parent;repo=Path('D:/code/Lython');old=r.parent/'regex-refresh-r521/adapter/Utf8RegexProvider.cs'
project=r/'adapter';project.mkdir(exist_ok=False)
s=old.read_text(encoding='utf-8').replace('using System.Text;','using System.Buffers;\nusing System.Text;')
s=s.replace('        var owner = memoryOwner.CreateScope();\n        try','        var owner = memoryOwner.CreateScope();\n        Utf8PythonRegex? compiled = null;\n        try',1)
s=s.replace('            var regex = Backend(() => Utf8PythonRegex.Compile(', '            compiled = Backend(() => Utf8PythonRegex.Compile(',1)
s=s.replace('''            return new Pattern(regex, EffectiveFlags(pattern.Span, options, cancellationToken), pattern.Length, owner, cancellationToken);
        }
        catch { owner.Dispose(); throw; }''','''            var prepared = new Pattern(compiled, EffectiveFlags(pattern.Span, options, cancellationToken), pattern.Length, owner, cancellationToken);
            cancellationToken.ThrowIfCancellationRequested();
            compiled = null; // The completed pattern now owns backend cleanup.
            return prepared;
        }
        catch
        {
            try { compiled?.Dispose(); }
            finally { owner.Dispose(); }
            throw;
        }''',1)
before='''            var names = regex.GetGroupNames();
            CaptureSlotCount = checked(regex.CaptureGroupCount + 1);
            var named = new List<LythonRegexNamedGroup>();
            for (var i = 0; i < names.Length; i++)
            {
                token.ThrowIfCancellationRequested();
                if (!int.TryParse(names[i], out _)) named.Add(new(Encoding.UTF8.GetBytes(names[i]), i));
            }
            _namedGroups = named.AsReadOnly();'''
after='''            CaptureSlotCount = checked(regex.CaptureGroupCount + 1);
            var named = new List<LythonRegexNamedGroup>();
            byte[]? scratch = null;
            // Existing coarse pattern admission funds this bounded scratch,
            // retained name bytes/list capacity and construction overlap.
            for (var slot = 1; slot < CaptureSlotCount; slot++)
            {
                token.ThrowIfCancellationRequested();
                scratch ??= new byte[16];
                var status = regex.TryCopyGroupNameUtf8(slot, scratch, out var required, token);
                byte[] name;
                if (status == OperationStatus.Done && required > 0 && required <= scratch.Length)
                {
                    // Unnamed slots have ASCII decimal names. Python named
                    // captures are identifiers, so none can begin with a digit.
                    if (scratch[0] is >= (byte)'0' and <= (byte)'9') continue;
                    name = scratch.AsSpan(0, required).ToArray();
                }
                else if (status == OperationStatus.DestinationTooSmall && required > scratch.Length)
                {
                    // Longer identifiers go straight into their final storage;
                    // the small scratch is a chunk, never a name-size ceiling.
                    name = new byte[required];
                    if (regex.TryCopyGroupNameUtf8(slot, name, out var copied, token) != OperationStatus.Done || copied != required)
                        throw new InvalidOperationException("Regex producer returned inconsistent UTF-8 capture-name metadata.");
                }
                else throw new InvalidOperationException("Regex producer could not supply UTF-8 capture-name metadata.");
                token.ThrowIfCancellationRequested();
                named.Add(new(name, slot));
            }
            _namedGroups = named.AsReadOnly();'''
assert before in s
s=s.replace(before,after)
assert 'GetGroupNames'not in s and 'Encoding.UTF8.GetBytes'not in s and 'return new Pattern(regex'not in s
(project/'Utf8RegexProvider.cs').write_text(s,encoding='utf-8',newline='\n')
csproj='''<Project Sdk="Microsoft.NET.Sdk"><PropertyGroup><TargetFrameworks>net11.0;net10.0</TargetFrameworks><AssemblyName>Lokad.Lython.Utf8Regex</AssemblyName><Version>0.11.0</Version><AssemblyVersion>0.11.0.0</AssemblyVersion><IsPackable>false</IsPackable><AllowUnsafeBlocks>false</AllowUnsafeBlocks><EnableSourceControlManagerQueries>false</EnableSourceControlManagerQueries></PropertyGroup><ItemGroup>'''
for name in ['Lokad.Lython','Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']:
    path=repo/'src/Lokad.Lython/bin/Release/$(TargetFramework)/Lokad.Lython.dll'if name=='Lokad.Lython'else r/'producer/src'/name/'bin/Release/$(TargetFramework)'/(name+'.dll')
    csproj+='<Reference Include="'+name+'"><HintPath>'+str(path)+'</HintPath></Reference>'
csproj+='</ItemGroup></Project>\n';(project/'Adapter.csproj').write_text(csproj,encoding='utf-8',newline='\n')
d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy()
env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
with(r/'adapter-build.log').open('w',encoding='utf-8')as log:p=subprocess.run([str(d),'build',str(project/'Adapter.csproj'),'-c','Release','--no-incremental'],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
assert p.returncode==0,(r/'adapter-build.log').read_text(encoding='utf-8')[-5000:]
print('Native capture names replace CLR metadata/re-encoding; unpublished backend cleanup precedes refund on failure; both targets build. Normal adapter/pin unchanged.',flush=True)
