from pathlib import Path
import json
r=Path(__file__).parent;old=r.parent/'private-construction-r480'
s=(old/'analyze.py').read_text(encoding='utf-8');s=s[:s.index(' leaves=')]
s=s.replace("r=Path(__file__).parent;rows=[]",'r=Path('+repr(str(old))+');rows=[]')
s+=''' histogram=collections.Counter()
 for stack in samples:
  for index,name in enumerate(stack):
   if 'PyString::GetRuneLength('in name:
    histogram[next((frame for frame in stack[index+1:]if 'Lokad.Lython.'in frame),'[no mapped managed caller]')]+=1
    break
 rows.append(dict(label=label,case=record['workload'],samples=len(samples),scalarWidthCallers=histogram.most_common()))
'''
scope={};exec(compile(s,str(__file__),'exec'),scope)
v=dict(source='ExistingR480/B894 d8611c85/frozen0315de0a; reclassify saved stacks only, no new capture or current-HEAD timing claim.',rows=scope['rows'])
(r/'existing-stack-callers.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8')
for row in v['rows']:print(json.dumps(row))
