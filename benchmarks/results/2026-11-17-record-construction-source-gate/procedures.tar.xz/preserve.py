from pathlib import Path
import json,shutil,tarfile
r=Path(__file__).parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-17-record-construction-source-gate';out.mkdir(exist_ok=False)
shutil.copyfile(r/'source-gate.json',out/'source-gate.json')
width=r.parent/'utf8-width-r483';shutil.copyfile(width/'existing-stack-callers.json',out/'width-source-candidates.json')
with tarfile.open(out/'procedures.tar.xz','w:xz')as a:
    for p in [r/'gate.py',r/'preserve.py',width/'inspect-existing-stacks.py']:a.add(p,arcname=p.name)
(out/'README.md').write_text('''# Record-construction source gate

R482, 2026-11-17 UTC. Source checked at 34d2e393; these CSV/dictionary files are
unchanged from qualified d8611c85. No runtime prototype, new timing or repeated
qualification. Earlier 6–8% bulk row work is already integrated as governed record
bytes/descriptors, aggregate final admission, shared windows and direct funded-row
adoption under shared keys. Ordinary native integer updates already defer boxing.

Unused CSV columns still construct string shells. Deferring them needs offsets,
pending/deleted/materialized presence, canonical caching and changes to dictionary
mutation/copy/views/projection and direct array adoption. Source does not establish
a lower-cost complete representation or its whole-script magnitude. No magic
metadata slots, universal lazy-container framework, identity ledger or automatic
prototype is added. This is remaining uncertainty, not a permanent rejection.

The next source candidate is existing UTF-8 scalar/UTF16 width counting. Reusing
saved R480 stacks, 57/59 and 33/34 sampled GetRuneLength calls have ordinary call
completion as the next mapped Lython frame. Inlining prevents precise attribution;
this is no current-HEAD profile or predicted removable percentage. Current counting
still walks scalar widths; pinned .NET10/11 reference metadata confirms managed
CountAny(SearchValues<byte>) availability. A bounded byte-classification proposal
must validate Unicode density, scalar-boundary windows, projection/refusal/current
tokens and whole-script effects before retention. No new capture or unsafe API.

[Record source findings](source-gate.json), [saved-stack reclassification](width-source-candidates.json),
[original full text evidence](../2026-11-17-text-construction-gate/README.md),
[procedures](procedures.tar.xz). Publication held; broader work continues.
''',encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as stream:stream.write('''

R482 [record source gate](results/2026-11-17-record-construction-source-gate/README.md): integrated bulk admission/windows/direct funded-row adoption verified, unused-column string shells remain but deferred state/canonical identity/mutation/copy costs do not establish a coherent lower-cost replacement. No runtime prototype or new capture. Saved R480 stack reclassification motivates assessing existing scalar/UTF16 width loops separately, without a removable-percentage claim. Bounded gate complete; no universal lazy-container framework or automatic promotion, publicationheld.
''')
print('R482 bounded source gate/evidence preserved; no production changes or unchanged qualification.')
