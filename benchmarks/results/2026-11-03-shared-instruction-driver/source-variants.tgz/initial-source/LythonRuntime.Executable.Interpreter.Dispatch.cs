using System.Numerics;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    private sealed partial class ExecutableFrameInterpreter
    {
        private enum InstructionPause { Boundary, Operation, Disposal }

        // Both APIs execute completed instructions here, outside an async state
        // machine. An incomplete operation leaves its instruction/span current.
        // The async driver owns the pending value and all disposal until resume.
        private InstructionPause ExecuteInstructionPrefix(bool asynchronous, out ValueTask<bool> pending)
        {
            pending = default;
            var instructions = _codeObject.Instructions;
            while (_instructionIndex < instructions.Length)
            {
                var jumped = false;
                ref readonly var instruction = ref instructions[_instructionIndex];
                _context.State.CheckExecution(instruction.Span);
                try
                {
                    if (_injectedException is not null && _delegation is null)
                    {
                        var injected = _injectedException;
                        _injectedException = null;
                        throw injected;
                    }
                    switch (instruction.OpCode)
                    {
                        case ExecutableOpCode.Complete:
                            return InstructionPause.Boundary;
                        case ExecutableOpCode.LoadLocal:
                            _stack.Push(LoadLocal(_codeObject, _locals, instruction.LocalSlot, instruction.Span, _context));
                            break;
                        case ExecutableOpCode.StoreLocal:
                            StoreLocalFromStack(instruction.LocalSlot, instruction.Span);
                            break;
                        case ExecutableOpCode.ApplyOperation:
                            var operation = (ExecutableOperation)_codeObject.Constants[instruction.ConstantIndex]!;
                            if (!asynchronous)
                                ExecutePreparedOperationAsync(operation, instruction.Span, false).GetAwaiter().GetResult();
                            else
                            {
                                pending = WithoutJump(ExecutePreparedOperationAsync(operation, instruction.Span, true));
                                if (!pending.IsCompletedSuccessfully) return InstructionPause.Operation;
                                _ = ConsumeOperation(ref pending);
                            }
                            break;
                        case ExecutableOpCode.Yield:
                            YieldValue = Pop(ref _stack, instruction.Span);
                            HasYield = true;
                            _waitingForSend = true;
                            _instructionIndex++;
                            return InstructionPause.Boundary;
                        case ExecutableOpCode.YieldFrom:
                            if (asynchronous)
                            {
                                pending = ExecuteDelegationAsync(instruction);
                                if (!pending.IsCompletedSuccessfully) return InstructionPause.Operation;
                                _ = ConsumeOperation(ref pending);
                            }
                            else
                            {
                                if (_delegation is null)
                                {
                                    var source = Pop(ref _stack, instruction.Span);
                                    _delegation = new GeneratorDelegation(Iter([source], instruction.Span, _context), _context, instruction.Span);
                                }
                                CompleteDelegatedStep(_delegation.Advance(_sentValue, _injectedException));
                            }
                            break;
                        case ExecutableOpCode.Import or ExecutableOpCode.DefineFunction or ExecutableOpCode.ExecuteFallbackStatement:
                            if (!asynchronous) ExecuteDefinitionOrFallback(instruction);
                            else
                            {
                                pending = WithoutJump(ExecuteDefinitionOrFallbackAsync(instruction));
                                if (!pending.IsCompletedSuccessfully) return InstructionPause.Operation;
                                _ = ConsumeOperation(ref pending);
                            }
                            break;
                        case ExecutableOpCode.LoadMember or ExecutableOpCode.LoadCallMember or ExecutableOpCode.LoadCallReceiver:
                            if (!asynchronous) ExecuteStackTransfer(instruction);
                            else if (!TryLoadDirectCallReceiver(instruction))
                            {
                                pending = ExecuteMemberLoadAsync(instruction);
                                if (!pending.IsCompletedSuccessfully) return InstructionPause.Operation;
                                _ = ConsumeOperation(ref pending);
                            }
                            break;
                        case ExecutableOpCode.LoadConst or ExecutableOpCode.LoadClosure or ExecutableOpCode.LoadGlobal or
                             ExecutableOpCode.LoadName or ExecutableOpCode.PreloadImplicitSuperArguments or
                             ExecutableOpCode.StoreClosure or ExecutableOpCode.StoreGlobal or ExecutableOpCode.StoreName or
                             ExecutableOpCode.Dup or ExecutableOpCode.PopTop:
                            ExecuteStackTransfer(instruction);
                            break;
                        case ExecutableOpCode.MakeList or ExecutableOpCode.MakeTuple or ExecutableOpCode.MakeSet or
                             ExecutableOpCode.MakeDict or ExecutableOpCode.MatchCase:
                            jumped = ExecuteStructure(instruction);
                            break;
                        case ExecutableOpCode.ResolveContextManager or ExecutableOpCode.EnterContextManager or ExecutableOpCode.ExitContextManager:
                            if (!asynchronous) jumped = ExecuteStructure(instruction);
                            else
                            {
                                pending = ExecuteContextManagerAsync(instruction);
                                if (!pending.IsCompletedSuccessfully) return InstructionPause.Operation;
                                jumped = ConsumeOperation(ref pending);
                            }
                            break;
                        case ExecutableOpCode.Binary or ExecutableOpCode.Augmented:
                            if (!asynchronous ||
                                (_stack[_stack.Count - 2] is BigInteger or double or bool &&
                                 _stack[_stack.Count - 1] is BigInteger or double or bool) ||
                                (_stack[_stack.Count - 2] is PyString && _stack[_stack.Count - 1] is PyString))
                                ExecuteOperandValueOperation(instruction);
                            else
                            {
                                pending = WithoutJump(ExecuteOperandValueOperationAsync(instruction));
                                if (!pending.IsCompletedSuccessfully) return InstructionPause.Operation;
                                _ = ConsumeOperation(ref pending);
                            }
                            break;
                        case ExecutableOpCode.Unary:
                            if (!asynchronous || _stack[_stack.Count - 1] is BigInteger or double or bool)
                                ExecuteOperandValueOperation(instruction);
                            else
                            {
                                pending = WithoutJump(ExecuteOperandValueOperationAsync(instruction));
                                if (!pending.IsCompletedSuccessfully) return InstructionPause.Operation;
                                _ = ConsumeOperation(ref pending);
                            }
                            break;
                        case ExecutableOpCode.Subscript:
                            if (TrySuspendForTypeSubscription(instruction)) return InstructionPause.Boundary;
                            // Evaluate the key before inspecting protocol-key state.
                            if (!asynchronous || (_stack[_stack.Count - 1] is BigInteger &&
                                 _stack[_stack.Count - 2] is PyList or PyTuple or PyBytes or PyString or PyRange) ||
                                (_stack[_stack.Count - 1] is PyString && _stack[_stack.Count - 2] is PyDict { HasProtocolKeys: false }))
                                ExecuteOperandValueOperation(instruction);
                            else
                            {
                                pending = WithoutJump(ExecuteOperandValueOperationAsync(instruction));
                                if (!pending.IsCompletedSuccessfully) return InstructionPause.Operation;
                                _ = ConsumeOperation(ref pending);
                            }
                            break;
                        case ExecutableOpCode.ForNext:
                            if (!asynchronous) jumped = ExecuteForNext(instruction);
                            else
                            {
                                pending = ExecuteForNextAsync(instruction);
                                if (!pending.IsCompletedSuccessfully) return InstructionPause.Operation;
                                jumped = ConsumeOperation(ref pending);
                            }
                            break;
                        case ExecutableOpCode.Call:
                            if (TrySuspendForExecutableCall(instruction)) return InstructionPause.Boundary;
                            goto case ExecutableOpCode.GetIter;
                        case ExecutableOpCode.GetIter:
                            if (!asynchronous) ExecuteValueOperation(instruction);
                            else
                            {
                                pending = WithoutJump(ExecuteValueOperationAsync(instruction));
                                if (!pending.IsCompletedSuccessfully) return InstructionPause.Operation;
                                _ = ConsumeOperation(ref pending);
                            }
                            break;
                        case ExecutableOpCode.Slice:
                            if (!asynchronous) ExecuteValueOperation(instruction);
                            else
                            {
                                pending = WithoutJump(ExecuteOperandValueOperationAsync(instruction));
                                if (!pending.IsCompletedSuccessfully) return InstructionPause.Operation;
                                _ = ConsumeOperation(ref pending);
                            }
                            break;
                        case ExecutableOpCode.MakeSlice:
                            ExecuteValueOperation(instruction);
                            break;
                        case ExecutableOpCode.JumpIfFalse:
                            if (!asynchronous || _stack[_stack.Count - 1] is not PyInstance)
                                jumped = ExecuteControlFlow(instruction);
                            else
                            {
                                pending = ExecuteConditionalJumpAsync(instruction);
                                if (!pending.IsCompletedSuccessfully) return InstructionPause.Operation;
                                jumped = ConsumeOperation(ref pending);
                            }
                            break;
                        case ExecutableOpCode.AbruptJump or ExecutableOpCode.Jump or ExecutableOpCode.MatchException or
                             ExecutableOpCode.BindException or ExecutableOpCode.ReraiseException or ExecutableOpCode.ClearException or
                             ExecutableOpCode.EndFinally or ExecutableOpCode.Return or ExecutableOpCode.ReturnNone:
                            jumped = ExecuteControlFlow(instruction);
                            break;
                        default:
                            throw new InvalidOperationException($"Unknown executable opcode: {instruction.OpCode}");
                    }
                }
                catch (ReturnSignal signal)
                {
                    if (!TryRouteReturn(signal, instruction.Span)) return InstructionPause.Boundary;
                    jumped = true;
                }
                catch (ControlSignal signal)
                {
                    if (!TryRouteControl(signal, instruction.Span)) throw;
                    jumped = true;
                }
                catch (LythonRuntimeException error)
                {
                    if (!TryRouteRuntimeException(error, instruction.Span)) throw;
                    jumped = true;
                }

                if (asynchronous && _stack.HasPendingDisposals)
                {
                    pending = new(jumped);
                    return InstructionPause.Disposal;
                }
                if (_hasFrameReturn || HasYield) return InstructionPause.Boundary;
                if (!jumped) _instructionIndex++;
            }
            return InstructionPause.Boundary;
        }

        private static bool ConsumeOperation(ref ValueTask<bool> pending)
        {
            var operation = pending;
            pending = default;
            return operation.GetAwaiter().GetResult();
        }

        private static ValueTask<bool> WithoutJump(ValueTask operation)
        {
            if (operation.IsCompletedSuccessfully)
            {
                operation.GetAwaiter().GetResult();
                return new(false);
            }
            return AwaitOperation(operation);

            static async ValueTask<bool> AwaitOperation(ValueTask pending)
            {
                await pending.ConfigureAwait(false);
                return false;
            }
        }
    }
}
