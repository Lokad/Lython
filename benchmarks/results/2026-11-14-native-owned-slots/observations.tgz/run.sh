cd /home/lokad/lython-bench-checks/native-owned-slots-b709-20261114
python3 -u collect.py > collection.log 2>&1
code=$?
printf "%s\n" "$code" > exit-code.txt
exit "$code"
