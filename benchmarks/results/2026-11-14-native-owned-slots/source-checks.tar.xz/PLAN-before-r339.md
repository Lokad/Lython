# Lokad.Lython 0.11.0

Updated2026-11-14. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance,
including newly generated scripts. A green delivery or isolated experiment is
a checkpoint, not completion of the performance objective.

## Delivery status

| State | Evidence and limits |
| --- | --- |
| Committed, fully qualified | Previous full runtime d888ee47/frozen0b2929ca, combined R333/R334 GREEN43530265063: Windows/Ubuntu actual11/10, original stress and installed consumers;578production inputs/16step summaries cached. Includes contextual XML key protocols and shared strict-UTF8 byte funding. Binary XML allocation−1.87..−1.88%; automatic warm CPU/elapsed adversity remains accepted debt. [Delivery/evidence](benchmarks/results/2026-11-13-utf8-byte-ownership/README.md). |
| Committed, latest fully qualified | R335cdd92944/frozenf4c4f027,581inputs: incremental mediated/borrowed XML and one shared tree builder.35internal/106public focused XML cases each Release11/10, plus strengthened joined-cleanup cases, independent Python controls and exact frozen-worker verification. B706three jobs/140.181s/all gates: first-record lookup~0.081ms vs25–26ms with intentionally different algorithms; identical-source XML control−3.21..−4.13%elapsed with wider CPU support. No external speedup or allocation percentage. GREEN43536449801: both platforms/actual11/10, original stress and installed consumers;581inputs/16summaries cached. [Delivery](benchmarks/results/2026-11-14-incremental-xml/delivery/README.md). [Evidence/limits](benchmarks/results/2026-11-14-incremental-xml/README.md). |
| Current external comparison, fully qualified measured source | R332/B704 uses d90dd5fe/frozen798,2026-11-13, stockCPython3.13.16/quietF4as_v7;7jobs/294.095s/all gates. Invoice warm1.25–1.26×, compile1.08–1.10×, fresh1.23–1.27×; captured text1.51–1.54×, search1.65–1.69×, JSON0.82–0.85×, report1.21–1.22×. Controls/IQR uncertainty explicit. These describe the measured revision, not today's HEAD. [Boundaries/evidence](docs/BENCHMARKS.md). |
| Committed, focused qualified; full checkpoint pending | R338c48c93ae/e2482e0b over qualifiedf4 removes native backedge exclusion.637internal/1551public focused cases each actual11/10; B708three jobs/141.481s/all gates. CSV validation warm−17..−19.5%, fresh−14.8..−16.8%, wider CPU support; allocation effectively flat. Invoice control−0.48..+1.63% remains uncertainty. Full delivery pending coherent eligibility checkpoint. [Evidence](benchmarks/results/2026-11-14-native-backedges/README.md). |
| Remaining measurement debt | Historical formatting15.125ms adversity remains unexplained; two bounded confirmation blocks support retention without reproducing it. Original native-return elapsed remains diagnostic. R334 small CPU cost and earlier report/search controls remain explicit; do not infer release-wide neutrality or add source-pair percentages. |

## Completed foundations; do not redevelop or repeat unchanged qualification

- [Shared compiler facts/nonlocal correction](benchmarks/results/2026-11-02-shared-compiler-facts/README.md),
  annotation demand and lowered-tree retention cleanup are delivered.
- [Direct UTF8 formatting/storage](benchmarks/results/2026-11-02-formatting-confirmation/README.md):
  original allocation−8.67%, current-pair−8.59%; controlled report CPU/elapsed−5..−8%
  is source-specific. Original adverse clocks and failed conditions survive.
- [Native helper returns](benchmarks/results/2026-11-02-native-function-returns/README.md):
  allocation−19.92%CSVhelpers/−19.31%JSONhelpers is separate from diagnostic elapsed/adverse
  text. Corrected full delivery8f07764a is complete; no missing unchanged qualification.
- [Revised bulk CSV](benchmarks/results/2026-11-02-native-csv-records/README.md)
  already selectively revisited the6–8%opportunity and shipped. Funded rows adopt
  arrays/share keys. Later R308/R314 alternatives stay withdrawn with useful lifetime
  regressions retained. JSON construction is iterative; XML now shares one builder.
- Executable calls already share final slots/linear continuations, native prefixes,
  member caching and compiled functions across Run/RunAsync. Integer chains avoid
  temporary boxes; native dictionary counters already store machine integers.
  Tuple transport, immutable builtin metadata, positional ZIP and native UTF8 JSON
  input are delivered. Preserve real suspension and managed small-stack handoff.
- Slower call-arena/control designs remain lessons. R325/R327 current-source gates
  do not establish a dominant removable packet/frame; all46native-entry samples
  resolve against same-process Tier1 code. Default dictionary work is real work,
  not proof of removable frame overhead. [Attribution](benchmarks/results/2026-11-13-native-entry-instructions/README.md).
- R328's exact frozen316 initial CI failure remains a historical failure, even
  though later descendants qualify. No missing/adverse evidence is relabelled green.

Detailed completed milestones, sources, qualification and rejected designs live in
[EXPERIMENTS](benchmarks/EXPERIMENTS.md), immutable results and saved plan history.

## Prioritized deliverables

1. **R335 delivery complete; continue the construction/transport roadmap.**
   Terminal full CI/logs/source proof are cached; do not repeat the green matrix. Accept the useful early-exit capability/shared builder,
   not a universal speedup. Parser/name/token storage can grow with supplied input;
   published graphs stay conservatively command-owned. Bounded host executions remain
   the long-stream contract. No general streaming owner/tracer is planned.

2. **R338 retained; focused qualified: remove the blanket backward-branch exclusion from native prefixes.**
   Source proves NativeExecution already executes Jump/JumpIfFalse/CompareJump and
   checks current cancellation/refusal on every instruction, but CanInlineInstructions
   rejects every backward branch. Correct the initial allocation explanation:
   BeginBoundCall already runs these loops through the deferred instruction prefix
   without materializing a call frame. Four allocation processes show only72–76B
   saved per whole4096-row job, effectively flat. Candidate instead selects the
   smaller native instruction dispatch and avoids ordinary work/cache preparation;
   timing must decide its value. No complete activation/storage removal is proved.
   No new loop optimizer/arena, typed-value VM or numeric special case. Delete the
   separate backward-edge eligibility scan; keep opcode/value-capacity/exception/
   closure restrictions, logical calls, managed-stack admission and exact promotion.
   Native-prefix dispatch remains object-valued; no unboxed-local representation is
   selected. No speedup forecast follows from source alone.
   Acceptance: while/else/break/continue, loop-carried locals and big-integer promotion,
   unbound/error order, aliases, closure/nonlocal writes, real async host work reached
   after iterations without replay, cancellation of nonallocating loops, terminal
   memory refusal and cleanup/shared-budget reuse. Existing small-stack/recursion
   regressions remain. Compare complete CSV check-digit/validation warm and compile-
   to-result jobs against the exact qualified f4 reference with unchanged invoice
   control, fixed workers/two fresh processes and all file/stdout/allowance gates.
   Use existing short allocation diagnostics only if needed to quantify the eliminated
   frame storage. Preserve all adverse observations. Stop after usable semantic,
   ownership, cancellation and affected/control evidence plus a debt decision; do not
   add support for unrelated opcodes or expand the prefix into a new engine. Batch
   full platform/stress/package qualification at the coherent eligibility delivery.
   B708complete141.481s/all gates: CSV warm−17..−19.5%, fresh−14.8..−16.8% with
   wider CPU support. Allocation flat. Invoice−0.48..+1.63%/candidate spread1.75%
   remains uncertainty.637internal/1551public per actual11/10 pass. Retain deletion
   with explicit control debt; no external or large-storage improvement claim.

3. **R336 phase gate complete; choose further removals from owning work.**
   B707three jobs/101.301s/all gates, committedcdd/f4, same96B config edit vs stock
   CPython3.13.16: compile1.06–1.09×, warm1.26–1.28×, fresh1.10–1.13×. Both current
   phase/source identities, actual I/O/checks/cleanup and adverse controls persist.
   These independently warmed medians cannot be added/subtracted as attribution.
   No compiler cliff or dominant removable setup stage is established. Historical
   R297 shows prominent mediated resolution/open work and unknown kernel leaves;
   do not bypass capabilities or call that core interpreter cost. Current lexical
   facts are already shared. No blind visitor/metadata/cache prototype is selected.
   Stop this phase collection with its usable uncertainty; do not repeat it without
   a changed source/question. [Evidence](benchmarks/results/2026-11-14-config-phases/README.md).
   Resume the substantial call/operand/construction roadmap below. Any next owning-
   source capture must target a concrete remaining phase and preserve unknowns;
   use one bounded capture only if existing evidence cannot select the removal.
   This measurement does not complete a redesign or the performance objective.

4. **Select substantive redesigns from remaining work, not another argument-form tweak.**

   | Area | Current assessment; work to eliminate; acceptance |
   | --- | --- |
   | Complete calls/frames and operand transport | Existing final slots/native prefix already remove repackaging and duplicate execution routes. Select a remaining complete activation/storage phase only with owning-source evidence. Remove its displaced route at delivery; no new arena/control backend. Preserve live defaults/receivers/closures, errors, real pending transfers and awaited cleanup. |
   | Per-record collections | CSV adopted/shared-key rows, native counter slots and iterative JSON are present. R335 removes unused XML-tree construction. Any next redesign must remove an actual row representation/copy/pass across a representative script, retire its old constructor and preserve mapping callbacks, mutation, aliases and allocation-before-effect admission. Do not revive R308/R314 merely under a new label. |
   | Scalar dispatch | Integer chains and counter storage already avoid many boxes. General object-valued operands remain; a tagged-value VM is a larger, unselected commitment. First prove remaining transport/boxing dominance and exact-promotion/identity/alias semantics. No isolated constant-argument rewrite. |
   | Text conversion | ASCII casing is already bulk; word counters already use compact UTF8 probes. Inspect remaining whole conversion/build stages rather than recreate these paths. Preserve Unicode expansion/context, error order and callback suspension; remove superseded conversion code. |
   | Frontend analysis | Duplicate-name modeling explains only0.41–0.95%allocation on the studied source. R336 determines short-script relevance; consolidate proven repeated facts/retained IR, not visitors on sight. Preserve Python diagnostics/scopes/nonlocals, cancellation and budget cleanup. |

   Each selected milestone must name hypothesis, eliminated work/storage, affected
   complete scripts, semantic acceptance, displaced implementation, bounded
   before/after/control comparison and explicit regression-debt decision. Temporary
   setbacks are acceptable within a justified redesign with a completion milestone.
   Refresh representative CPython rows at a coherent qualified checkpoint, not every
   commit. Keep compile, warm, I/O and cleanup boundaries explicit.

5. **Regex is an independent development track.** The Lython-owned Python-specific
   UTF8 contract, original windows, byte/scalar positions, captures/flags/errors,
   current-token work and existing ownership/cache integration are implemented.
   Dev producers and adapter-local bridges remain permitted; core has no backend
   dependency. Dev80/15b248dc changed-source88internal/534public per11/10 checks are
   complete; normal29inputs/binaries and optional0.4/nonpackable adapter are unchanged.
   Read-only dev84/ae463cb4 plus immutable package metadata still lack separate
   one-match work/result owners, native
   UTF8 group-name enumeration/copy and token-independent cursor construction with
   cancellable preparation. Only the affected final adapter qualification defers.
   Use a changed contract/implementation or new producer capability to select the
   next concrete step. [Current capability assessment](benchmarks/results/2026-11-14-regex-provider-capabilities/README.md)
   records package source revisions separately from the newer worktree; no pin change
   or semantic requalification is inferred. Distinguish tests, semantics and backend performance/
   safety. Do not mutate the sibling or repeat unchanged producer qualification.

## Evidence policy and lasting constraints

Distinguish simplification, allocation reduction and demonstrated CPU improvement.
Percentages inform decisions, not automatic vetoes. Timeouts, unstable controls and
inconclusive observations establish uncertainty. Allow bounded confirmation,
refinement or measurement correction for an explicit reason, retaining originals
and adverse points. No blanket one-attempt/no-retiming/permanently-closed rules.
Use focused Release correctness/cancellation/ownership checks during iteration;
batch Windows/Ubuntu actual11/10, original stress and installed Release consumers
at coherent delivery boundaries. Keep CI queries minutes apart and cache terminals.

Remain fully managed/memory-safe: no unsafe compilation/C#/APIs, pointers, P/Invoke
or native probing. Preserve managed stack admission, cancellation, capabilities/
original paths+Cwd, cycles/XML depth, checked bounds and bounded I/O chunks. No
fuel/quotas, hidden caps/default allowance, regex work/time policy, heap tracing,
weak reclamation, forced GC or abandoned users. Borrowed allowance funds capacity/
overlap, aliases/results/caches and pending users. First refusal remains terminal
through suppression/finally; preserve its origin, await cleanup, never retry.
Force nonincremental builds after restoration; copy/verify frozen source/bits and
every auxiliary worker/adapter. Persist evidence, join users, preserve VM floors
and current images. Current docs stay concise/Lython-centric. See[AGENTS](AGENTS.md).
