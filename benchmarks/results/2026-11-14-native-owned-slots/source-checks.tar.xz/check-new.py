from pathlib import Path
import os,subprocess
r=Path(__file__).parent
env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';'+env['PATH']
for target in ['net11.0','net10.0']:
    path=r/('new-'+target+'.log')
    with path.open('wb')as log:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f',target,'--no-restore','--filter','FullyQualifiedName~LargeHelperExecutionTests','--logger','trx;LogFileName=new-'+target+'.trx','--results-directory',str((r/('new-'+target)).resolve())],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=150)
    print(target,done.returncode,path.read_text(encoding='utf-8')[-2600:],flush=True)
    assert done.returncode==0
