from pathlib import Path
import base64,copy,csv,hashlib,io,json,struct,subprocess,tempfile
r=Path(__file__).parent
old=json.loads((r.parent/'native-backedges-r338/catalog.json').read_text(encoding='utf-8'))
control=next(c for c in old['cases']if c['id']=='scripts.csv-check-digits.large')
buffer=io.StringIO(newline='');writer=csv.writer(buffer,lineterminator='\n')
writer.writerow(['sku','quantity','unit_cents','discount_bps','tax_bps','available','pack_size','grams_per_unit','shipping_cents'])
for i in range(4096):
    quantity=i%17;available=12+i%9;pack=0 if i%29==0 else 1+i%5
    writer.writerow(['sku'+str(i%8),quantity,119+i%300,250*(i%5),500+100*(i%4),available,pack,25+i%80,90+i%30])
data=buffer.getvalue().encode()
source="""import csv

def price(row):
    sku=row['sku']
    quantity=int(row['quantity'])
    unit_cents=int(row['unit_cents'])
    discount_bps=int(row['discount_bps'])
    tax_bps=int(row['tax_bps'])
    available=int(row['available'])
    pack_size=int(row['pack_size'])
    grams_per_unit=int(row['grams_per_unit'])
    shipping_cents=int(row['shipping_cents'])
    if quantity<=0 or pack_size<=0 or quantity>available:
        return sku,False,0,0,0
    base=quantity*unit_cents
    discount=(base*discount_bps+5000)//10000
    net=base-discount
    tax=(net*tax_bps+5000)//10000
    packs=(quantity+pack_size-1)//pack_size
    shipping=packs*shipping_cents
    total_grams=quantity*grams_per_unit
    gross=net+tax+shipping
    return sku,True,gross,total_grams,packs

totals={}
invalid=0
count=0
with open('input.csv',newline='') as source:
    for row in csv.DictReader(source):
        sku,valid,gross,grams,packs=price(row)
        count+=1
        if not valid:
            invalid+=1
            continue
        prior=totals.get(sku,(0,0,0))
        totals[sku]=(prior[0]+gross,prior[1]+grams,prior[2]+packs)
with open('report.csv','w',newline='') as target:
    writer=csv.writer(target,lineterminator='\\n')
    writer.writerow(['sku','gross_cents','grams','packs'])
    for sku in sorted(totals): writer.writerow([sku,*totals[sku]])
print(count,invalid)
"""
with tempfile.TemporaryDirectory(prefix='owned-slots-control-',dir=r.resolve())as folder:
    work=Path(folder).resolve();assert work.parent==r.resolve()
    (work/'input.csv').write_bytes(data)
    done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],cwd=work,capture_output=True,text=True,encoding='utf-8',timeout=15)
    assert done.returncode==0 and not done.stderr,done.stderr
    output=(work/'report.csv').read_bytes();assert(work/'input.csv').read_bytes()==data
fixture=dict(size=4096,text=None,inputFiles={'input.csv':base64.b64encode(data).decode()},outputFiles={'report.csv':base64.b64encode(output).decode()})
c=copy.deepcopy(control);c.update(id='scripts.csv-fulfillment.large',size=4096,source=source,fixtureJson=json.dumps(fixture,separators=(',',':'),ensure_ascii=False),expectedOutput=done.stdout,sourceUtf8Bytes=len(source.encode()),expectedOutputUtf8Bytes=len(done.stdout.encode()),fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,sourceSha256=hashlib.sha256(source.encode()).hexdigest(),expectedOutputSha256=hashlib.sha256(done.stdout.encode()).hexdigest())
c['fixtureSha256']=hashlib.sha256(c['fixtureJson'].encode()).hexdigest()
name=b'report.csv';c['expectedFilesSha256']=hashlib.sha256(struct.pack('>i',1)+struct.pack('>i',len(name))+name+struct.pack('>i',len(output))+output).hexdigest()
old['cases']=[c,control]
(r/'catalog.json').write_text(json.dumps(old,separators=(',',':'),ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
(r/'workload-python-controls.json').write_text(json.dumps(dict(reference='CPython3.13.2 isolated',case=c['id'],sourceSHA256=c['sourceSha256'],fixtureSHA256=c['fixtureSha256'],inputBytes=len(data),stdout=done.stdout,outputBytes=len(output),unchangedInput=True,control=control['id'],sameSourcesAcrossRevisions=True),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Complete4096-row fulfillment/pricing validation/report and unchanged small-while control match CPython goldens.',flush=True)
