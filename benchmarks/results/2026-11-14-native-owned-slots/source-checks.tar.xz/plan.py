from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).parent
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')
(r/'PLAN-before-r339.md').write_bytes(p.read_bytes())
marker='3. **R336 phase gate complete; choose further removals from owning work.**'
assert marker in s
s=s.replace(marker,'''3. **R339 active: separate native instruction eligibility from private buffer transport.**
   CanInlineInstructions currently mixes semantic/opcode eligibility with a16-slot
   stack-buffer constraint. Bound calls already admit their entire locals/operand
   array before binding, but larger closed helpers still use ordinary deferred
   dispatch. Hypothesis: reuse that admitted array in the existing native prefix,
   extending R338's demonstrated dispatch benefit to realistic larger validation/
   pricing helpers. No materialized-frame or large allocation-saving claim: the
   ordinary prefix already defers contexts. No new engine, array pool, copy, owner,
   public option or unboxed/tagged-value representation.
   Move the16-slot predicate to the actual private-buffer call entry; keep native
   binding/argument constraints there. Rename the immutable compiler fact and share
   existing lexical guards across private and already-bound entries. TryStartBound-
   Invocation may use native instructions with the actual owned bound span. Remove
   obsolete universal16-reference lifetime wording; all backing/retained references
   remain funded until normal cleanup. Preserve namespace/capture/exception/opcode
   restrictions and managed native-call depth; no new opcode support is selected.
   Acceptance: large locals and positional/keyword/default bindings, aliases/tuple/
   formatting results, real asynchronous promotion after completed work, terminal
   refusal and pending borrows, two executions sharing allowance, cleanup/budget
   reuse, CPU-loop cancellation and managed-stack/recursion controls. Inspect source
   and frozen IR to prove the representative closed helper is excluded solely by
   capacity before and eligible after; private entry must still reject >16 slots.
   Compare complete CSV fulfillment/pricing validation warm/fresh with unchanged
   small-while control from e248, fixed workers/two processes and all goldens. Keep
   allocation claims separate. Stop after focused checks, one bounded affected/
   control comparison and a debt decision. If this requires a new storage/frame
   subsystem, stop expansion and record the obstacle instead. Batch full R338/R339
   platform/stress/installed qualification at this coherent eligibility boundary;
   if R339 is withdrawn, qualify retained R338. Publication remains held.

4. **R336 phase gate complete; choose further removals from owning work.**''')
s=s.replace('4. **Select substantive redesigns','5. **Select substantive redesigns').replace('5. **Regex is an independent','6. **Regex is an independent')
p.write_text(s,encoding='utf-8',newline='\n')
prior=r.parent/'native-backedges-r338'
identity=json.loads((prior/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in identity['sources'].items())
for name in ['candidate-core.dll','candidate-sources.tar.xz']:shutil.copyfile(prior/name,r/name.replace('candidate','reference'))
shutil.copytree(prior/'candidate',r/'reference')
reference=dict(head='c48c93aec43bf00bce95cfa4ca26a394da0a2a40',coreSHA256=identity['coreSHA256']['candidate'],sources=identity['sources'],productionFiles=len(identity['sources']),auxiliaryFiles=identity['auxiliaryFiles']['candidate'],qualified=False,qualification='R338focused637internal/1551public per actual11/10; B708141.481s/all gates. Full qualification pending combined R338/R339; last full source is R335/f4.')
(r/'reference-identity.json').write_text(json.dumps(reference,indent=2)+'\n',encoding='utf-8',newline='\n')
print('R339pre-code design recorded; exact R338/e248 reference copied. Stack buffer remains16; existing owned locals only.',flush=True)
