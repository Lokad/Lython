from pathlib import Path
import json,os,subprocess
r=Path(__file__).parent
env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';'+env['PATH']
rows=[]
filters={'Lokad.Lython.Tests':'FullyQualifiedName~Native|FullyQualifiedName~ExecutableCall|FullyQualifiedName~ExecutableFrame|FullyQualifiedName~ManagedStackGuard|FullyQualifiedName~ExecutableStackAdmission|FullyQualifiedName~FunctionBinding|FullyQualifiedName~FunctionExecutionBoundary',
         'Lokad.Lython.PublicApi.Tests':'FullyQualifiedName~LargeHelper|FullyQualifiedName~WhileHelper|FullyQualifiedName~Native|FullyQualifiedName~StackGuardScenario|FullyQualifiedName~RecursionDepthScenario|FullyQualifiedName~FunctionBinding|FullyQualifiedName~ArgumentBinding'}
for target in ['net11.0','net10.0']:
    with(r/('probe-build-'+target+'.log')).open('wb')as log:built=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','build','tools/LythonProbe/LythonProbe.csproj','-c','Release','-f',target,'--no-restore'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
    assert built.returncode==0,(r/('probe-build-'+target+'.log')).read_text(encoding='utf-8')[-2000:]
    for assembly,filter in filters.items():
        filter='('+filter+')&Category!=Stress'
        path=r/(assembly+'-'+target+'.log')
        with path.open('wb')as log:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','test','tests/'+assembly+'/'+assembly+'.csproj','-c','Release','-f',target,'--no-restore','--filter',filter,'--logger','trx;LogFileName=related-'+target+'.trx','--results-directory',str((r/(assembly+'-'+target)).resolve())],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
        text=path.read_text(encoding='utf-8');print(assembly,target,done.returncode,text[-2200:],flush=True)
        rows.append(dict(assembly=assembly,target=target,returncode=done.returncode,filter=filter,log=path.name))
        (r/'focused-checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
        assert done.returncode==0
