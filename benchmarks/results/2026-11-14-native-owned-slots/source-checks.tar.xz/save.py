from pathlib import Path
import hashlib,json,re,shutil,tarfile
r=Path(__file__).parent
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in identity['sources'].items())
allocation=json.loads((r/'allocation-summary.json').read_text(encoding='utf-8'))
timing=json.loads((r/'b709/summary.json').read_text(encoding='utf-8'))
receipt=json.loads((r/'b709/archive-receipt.json').read_text(encoding='utf-8'))
assert timing['complete'] and timing['jobs']==3 and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
assert hashlib.sha256((r/'b709/observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
counts={}
for assembly in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:
 for target in ['net11.0','net10.0']:
  name=assembly+'-'+target+'.log';s=(r/name).read_text(encoding='utf-8')
  match=re.search(r'Passed!.*?Failed:\s+0, Passed:\s+(\d+)',s);assert match,name
  counts[name]=int(match[1])
assert list(counts.values())==[637,637,1562,1562]
out=Path('benchmarks/results/2026-11-14-native-owned-slots');out.mkdir()
for name in ['candidate-identity.json','reference-identity.json','workload-python-controls.json','worker-verification.json','inspection.json','allocation-summary.json','focused-checks.json']:shutil.copyfile(r/name,out/name)
for name in ['summary.json','archive-receipt.json','terminal-status.json','observations.tgz']:shutil.copyfile(r/'b709'/name,out/name)
with tarfile.open(out/'source-checks.tar.xz','w:xz')as t:
 for name in ['plan.py','PLAN-before-r339.md','reference-core.dll','reference-sources.tar.xz','freeze-candidate.py','candidate-build.log','candidate-core.dll','candidate-sources.tar.xz','prepare-catalog.py','catalog.json','check-new.py','check-related.py','inspect.py','prepare-measurements.py','verify-worker.py','measure-allocation.py','allocation-reference-catalog.json','allocation-candidate-catalog.json','rename-tests.py','save.py']+list(counts):t.add(r/name,arcname=name)
 for pattern in ['new-*.log','probe-build-*.log','reference-allocation-*.*','candidate-allocation-*.*']:
  for p in r.glob(pattern):t.add(p,arcname=p.name)
 for p in r.glob('**/*.trx'):t.add(p,arcname=p.relative_to(r).as_posix())
 for name in ['inspection/Program.cs','inspection/Inspection.csproj','initial-expression-chain-fixture']:t.add(r/name,arcname=name)
 for p in [Path('tests/Lokad.Lython.PublicApi.Tests/LargeHelperExecutionTests.cs')]+[Path('tests/Lokad.Lython.Tests')/n for n in ['FormattedStringExecutableTests.cs','NativeClosureSequenceTests.cs','NativeFunctionRefundTests.cs','SimpleFunctionExecutionBoundaryTests.cs']]:t.add(p,arcname=p.as_posix())
 for name in ['identity.json','config.json','collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py','launch.py','launch-command.py','launch.log','observe-not-before.json','extraction.json']:t.add(r/'b709'/name,arcname='b709/'+name)
 for name in ['Program.cs','Allocation.csproj']:t.add(r.parent/'word-buffer-loan-r324/allocation'/name,arcname='allocation-tool/'+name)
 for p in(r/'reference').glob('Allocation.*'):t.add(p,arcname='allocation-tool/'+p.name)
table='| Complete script / phase | Elapsed change | Wider CPU change | Process spread candidate/reference | Max IQR |\n| --- | ---: | ---: | ---: | ---: |\n'
for row in timing['timing']:
 elapsed=row['lythonSourcePairElapsedPercent'];cpu=row['lythonSourcePairWiderCpuPercent']
 table+=f"|{row['case'].removeprefix('scripts.')} /{row['lane']}|{min(elapsed):+.2f}..{max(elapsed):+.2f}%|{min(cpu):+.2f}..{max(cpu):+.2f}%|{row['candidateProcessSpreadPercent']:.2f}/{row['referenceProcessSpreadPercent']:.2f}%|{max(row['iqrPercent'].values()):.2f}%|\n"
(out/'README.md').write_text(f'''# Native instructions over admitted bound storage

2026-11-14UTC, R339frozen38c0562f over R338c48c93ae/frozene2482e0b.
**Retain the eligibility/transport separation.** 637internal/1562public focused
Release cases pass per actual.NET11/10. Full combined R338/R339 platform, original
stress and installed-consumer delivery is pending; the last full source remains
R335cdd92944/frozenf4c4f027. Publication/tagging remain postponed.

The previous compiler fact mixed native-opcode eligibility with the sixteen-slot
private call-buffer capacity. Bound calls already admit their complete locals and
operand array. Separate the predicates and run eligible larger bodies directly
over that existing span. The private stack buffer, argument-binding restrictions,
lexical/exception/opcode guards and managed nesting limits remain unchanged.
No new allocator, copy, pool, owner, value representation, execution route or
public option. The ordinary deferred instruction prefix remains necessary for
unsupported operations. Transfers preserve the exact PC, live values and owners.

This does not remove a materialized frame: the prior ordinary prefix already
defers contexts. It broadens use of the existing native dispatch and arithmetic
chain helpers. Four desktop allocation processes, ordinary GC/no forced collection,
show **7,883,991 B versus7,108,022–7,108,026 B per complete fulfillment script,
−9.84%**. The small-while control stays5,131,647 B. Counters include fixture reset,
checks and cleanup. Allocation, CPU and elapsed are separate observations; no
heap/RSS, process-tail or universal speedup follows.

## Acceptance

The representative4096-row CSV validates nine fields, applies quantity/availability/
pack rules, computes prices/discount/tax/shipping, aggregates eight SKUs and writes
a checked CSV report. CPython3.13.2 independently supplies exact stdout/file
goldens. Frozen-core inspection proves its price helper has the same85instructions
and23slots before/after: old native=False, candidate=True. The small while helper's
facts are unchanged. Physical backward block edges are not a claim about Python
loop count. Both sources independently pass frozen-worker output and budget reuse.

Eleven new public cases cover20locals,20/80arguments, dynamic keywords/live defaults,
binding errors, aliases, retained formatted results sharing an allowance, actual
asynchronous file work without replay, cancellation of empty nonallocating loops,
terminal refusal before body effects and pending file cleanup. A partial formatting
builder survives a custom __format__ callback that suspends; cancelled cleanup
returns to baseline after joining. Related managed-stack/recursion controls remain.
Initial80-term fixture failed the existing64-operand frontend guard: split the
fixture expression into40-term groups, leaving the guard unchanged. Original
source/log/TRX remain in the archive; no runtime failure is relabelled.

## One bounded whole-script comparison

{table}
B709three jobs finish{timing['elapsedSeconds']:.3f}s under one300s owner, quiet
AzureF4as_v7/Ubuntu24.04.4/.NET11RC3, ordinary workstation GC/tiering. Fixed B685
worker and optional0.4adapter are identical; two fresh processes per revision/job,
eight-second full-request wall warmups, five rotating0.5s wall-sized batches.
The complete fulfillment script runs12.88–13.73%faster warm and14.57–16.09%faster
compile-to-result, with wider CPU support. Retain this source-specific result.

The small-helper control spans−2.57..+1.50%elapsed and−4.65..+1.37%wider CPU;
reference process spread3.79%limits attribution. Preserve this control uncertainty
and every adverse point, rather than claim neutrality or repeat unchanged timing.
The strong affected result plus source simplification and allocation reduction
justify retention. No external baseline was timed in this collection.

Warm guest clocks include mediated RAM-file I/O, full stdout/file validation and
prior-result cleanup; compilation/startup, fixture reset/protocol and final cache
teardown are excluded. Compile-to-result adds compilation/compiled-owner disposal.
Wider CPU includes reset/protocol. Ranges span process medians, not confidence
intervals. All identity/golden/balance/quiet/join/archive gates pass. Persistent
rawSHA{receipt['archiveSHA256']}; no workers or RAM fixtures remain. No evidence or
current image was retired and no VM floor relaxed. These two useful eligibility
milestones do not complete the whole-script performance objective.

[Timing/wider CPU](summary.json), [allocation](allocation-summary.json),
[IR/source inspection](inspection.json), [raw](observations.tgz),
[exact frozen sources/bits, initial failure and focused checks](source-checks.tar.xz).
''',encoding='utf-8',newline='\n')
with Path('benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as f:f.write('''
## R339 — native instructions over admitted bound storage

[Retained source pair](results/2026-11-14-native-owned-slots/README.md) separates
native semantic eligibility from the16-slot private call-buffer constraint.
Existing funded bound arrays serve larger closed helpers; no new storage or
execution subsystem.637internal/1562public focused cases pass each actual11/10,
including real suspension, partial formatting, cancellation, refusal and retained
owners. Initial excessive-expression fixture and its correction remain archived.
B709three jobs/142.262s/all gates: complete4096-row fulfillment/pricing/report warm
−13.73..−12.88%, compile-to-result−16.09..−14.57%, with wider CPU support; allocation
−9.84%. Small-helper control−2.57..+1.50% and3.79%reference spread remain uncertainty.
Full combined eligibility delivery is pending. No universal/CPython speedup or
materialized-frame removal claim; publication held, broader roadmap active.
''')
print('Saved exact R339 sources, failed fixture, focused qualification and bounded retention evidence.',flush=True)
