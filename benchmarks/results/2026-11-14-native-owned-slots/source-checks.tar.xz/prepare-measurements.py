from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent;prior=r.parent/'native-backedges-r338'
source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert json.loads((r/'inspection.json').read_text(encoding='utf-8'))['unchangedSmallWhileFacts']
(r/'verify-worker.py').write_bytes((prior/'verify-worker.py').read_bytes())
for role in ['reference','candidate']:(r/('allocation-'+role+'-catalog.json')).write_bytes((r/'catalog.json').read_bytes())
(r/'measure-allocation.py').write_bytes((prior/'measure-allocation.py').read_bytes())
out=r/'b709';out.mkdir()
aux=json.loads((prior/'b708/identity.json').read_text(encoding='utf-8'))['candidateAuxiliaryFiles']
assert all(source['auxiliaryFiles'][role][name]==sha for role in ['reference','candidate']for name,sha in aux.items())
identity=dict(sourceRevision='R339 frozen'+source['coreSHA256']['candidate'][:8]+' vs focusedR338/c48c93ae frozene2482e0b; last full delivery R335/f4',purpose='Same-source complete CSV fulfillment/pricing validation/report: warm and compile-to-result, unchanged small-while control. Separate native instruction eligibility from private-buffer transport; no external timing claim.',coreSHA256={label:source['coreSHA256']['candidate'if label.startswith('candidate')else'reference']for label in ['reference','candidate','reference-control','candidate-control']},candidateAuxiliaryFiles=aux,referenceAuxiliaryFiles=aux,catalogSHA256=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest(),referenceCase='scripts.csv-fulfillment.large',variantCase='scripts.csv-fulfillment.large',controlCase='scripts.csv-check-digits.large',sourceAndScriptDifferIntentionally=False)
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
oldroot='/home/lokad/lython-bench-checks/native-backedges-b708-20261114'
root='/home/lokad/lython-bench-checks/native-owned-slots-b709-20261114'
unit='lython-b709-native-owned-slots-20261114'
jobs=[['scripts.csv-fulfillment.large','warm'],['scripts.csv-fulfillment.large','compile-run'],['scripts.csv-check-digits.large','warm']]
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py','launch.py']:
    s=(prior/'b708'/name).read_text(encoding='utf-8').replace(oldroot,root).replace('lython-b708-native-backedges-20261114',unit).replace('B708','B709')
    if name=='collect.py':
        a=s.index('jobs=');b=s.index('\nenv =',a)
        s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==3 and all(case in cases for case,lane in jobs)\n'+s[b:]
    if name.endswith('.py'):ast.parse(s)
    (out/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
    for name in ['identity.json','collect.py','archive-owned.py','run.sh']:t.add(out/name,arcname=name)
    for name,arc in [('catalog.json','representative.json'),('candidate-core.dll','candidate-core.dll'),('reference-core.dll','reference-core.dll'),('candidate-identity.json','source-identity.json'),('reference-identity.json','reference-source-identity.json')]:t.add(r/name,arcname=arc)
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
config=dict(root=root,sourceRoot='/home/lokad/lython-bench-checks/current-external-b704-20261113',unit=unit,identity=identity,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Prepared three-job300s owner, identical scripts and fixed workers; larger helper and unchanged small-while control.',flush=True)
