from pathlib import Path
paths=['FormattedStringExecutableTests.cs','NativeClosureSequenceTests.cs','NativeFunctionRefundTests.cs','SimpleFunctionExecutionBoundaryTests.cs']
for name in paths:
    path=Path('tests/Lokad.Lython.Tests')/name
    s=path.read_text(encoding='utf-8');assert'CanInlineInstructions'in s
    path.write_text(s.replace('CanInlineInstructions','CanRunNativeInstructions'),encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')
anchor='| Remaining measurement debt |'
at=s.index(anchor)
s=s[:at]+'| Active uncommitted runtime prototype | R339 separates native instruction eligibility from the16-slot private call buffer. Existing admitted bound arrays serve larger closed helpers; guards and lifetimes remain under focused qualification. No speedup/allocation claim yet. |\n'+s[at:]
p.write_text(s,encoding='utf-8',newline='\n')
print('Renamed existing semantic/ownership precondition checks; no architecture-only test added or deleted.',flush=True)
