using System.Collections;
using System.Reflection;
using System.Text.Json;
using Lokad.Lython;

const BindingFlags flags=BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic;
object? Get(object value,string name)=>value.GetType().GetProperty(name,flags)!.GetValue(value);
bool Native(object code)=>(bool)(code.GetType().GetProperty("CanRunNativeInstructions",flags)??code.GetType().GetProperty("CanInlineInstructions",flags))!.GetValue(code)!;
var rows=new List<object>();
using var catalog=JsonDocument.Parse(File.ReadAllBytes(args[0]));
foreach(var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    using var script=new LythonEngine().Compile(item.GetProperty("source").GetString()!);
    if(!script.IsValid)throw new InvalidDataException(string.Join(";",script.Diagnostics.Select(d=>d.Message)));
    var runner=(Delegate)typeof(LythonCompiledScript).GetField("_runner",flags)!.GetValue(script)!;
    var executable=runner.Target!.GetType().GetField("executableScript",flags)!.GetValue(runner.Target)!;
    var entry=Get(executable,"EntryPoint")!;
    var pending=new Stack<object>();pending.Push(entry);
    var functions=new List<object>();
    while(pending.TryPop(out var code))
    {
        if(!ReferenceEquals(code,entry))
        {
            var instructions=((IEnumerable)Get(code,"Instructions")!).Cast<object>().ToArray();
            var edges=instructions.Select((instruction,index)=>new{instruction,index})
                .Where(row=>Get(row.instruction,"OpCode")!.ToString() is "Jump" or "JumpIfFalse" or "CompareJumpIfFalse"
                    && (int)Get(row.instruction,"TargetIndex")!<=row.index).Count();
            functions.Add(new{name=Get(code,"Name"),native=Native(code),slots=Get(code,"ValueStorageCapacity"),instructionCount=instructions.Length,backwardBranches=edges});
        }
        foreach(var binding in (IEnumerable)Get(code,"Functions")!)pending.Push(Get(binding!,"CodeObject")!);
    }
    rows.Add(new{id=item.GetProperty("id").GetString(),sourceSha256=item.GetProperty("sourceSha256").GetString(),functions});
}
Console.WriteLine(JsonSerializer.Serialize(rows,new JsonSerializerOptions{WriteIndented=true}));
