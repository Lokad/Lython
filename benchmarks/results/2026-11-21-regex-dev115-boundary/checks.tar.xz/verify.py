from pathlib import Path
import hashlib,json,os,shutil,subprocess,zipfile

lab=Path(__file__).resolve().parent
previous=lab.parent/'regex-dev109-verification'
version='0.5.0-dev.115'
producer=Path('D:/code/utf8regex/artifacts')
candidate=producer/'package-candidates'/version
host=producer/'package-acceptance'/version
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda value:hashlib.sha256(value).hexdigest()
manifest=load(candidate/'candidate.json')
assert manifest['SourceRevision'].startswith('050c51480') and manifest['PackageVersion']==version
assert manifest['CleanSource'] and manifest['Configuration']=='Release' and not manifest['Published']
shutil.copyfile(candidate/'candidate.json',lab/'producer-candidate.json')
shutil.copyfile(host/'host-inputs.json',lab/'producer-host-inputs.json')
shutil.copyfile(host/'windows-original-hosts.log',lab/'producer-windows-lython.log')
shutil.copyfile(host/'linux-launcher.log',lab/'producer-linux-launcher.log')
if (host/'ci-green.json').exists(): shutil.copyfile(host/'ci-green.json',lab/'producer-ci.json')
managed=subprocess.run(['git','-C','D:/code/Utf8Regex','grep','-n','Unsafe.SizeOf<T>',manifest['SourceRevision'],
    '--','src/Lokad.Utf8Regex/Internal/Construction/Utf8ConstructionBudget.cs'],check=True,capture_output=True)
assert b'Unsafe.SizeOf<T>' in managed.stdout
(lab/'producer-managed-scan.txt').write_bytes(managed.stdout)
shutil.copytree(previous/'DirectProbe',lab/'DirectProbe',ignore=shutil.ignore_patterns('bin','obj'))
assemblies={}
for item in manifest['Packages']:
    if item['Id'] not in ('Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe'): continue
    framework=item['TargetFramework']
    package=candidate/item['RelativePath']
    assert sha(package.read_bytes())==item['PackageSha256'].lower()
    assembly=item['Id']+'.dll'
    with zipfile.ZipFile(package) as archive:
        payload=archive.read('lib/'+framework+'/'+assembly)
    digest=sha(payload)
    assert digest==item['AssemblySha256'].lower()
    out=lab/'probes'/framework
    out.mkdir(parents=True,exist_ok=True)
    (out/assembly).write_bytes(payload)
    assemblies.setdefault(framework,{})[assembly]=digest
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
with (lab/'build.log').open('wb')as log:
    subprocess.run([dotnet,'build',lab/'DirectProbe/DirectProbe.csproj','-c','Release'],stdout=log,stderr=subprocess.STDOUT,env=env,check=True,timeout=75)
for framework,files in assemblies.items():
    run=subprocess.run([dotnet,lab/'DirectProbe/bin/Release'/framework/'DirectProbe.dll'],env=env,check=True,capture_output=True,text=True,timeout=20)
    (lab/(framework+'.log')).write_text(run.stdout,encoding='utf-8',newline='\n')
    assert all(digest in run.stdout.lower() for digest in files.values())
    assert 'Reversed cursor refuses startOffsetInBytes' in run.stdout
raw=subprocess.run(['C:/Python313/python.exe','-I','-X','utf8',previous/'reversed-window.py'],check=True,capture_output=True,text=True)
assert raw.stdout.strip()=='(((2, 2), (2, 2)), 1, 2, 1)'
(lab/'cpython.log').write_text(raw.stdout,encoding='utf-8',newline='\n')
print('Direct dev.115 package hashes matched. UTF-8 group names and normal anchored match passed. Reversed anchored start refused on both targets.')
