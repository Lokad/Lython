from pathlib import Path
import hashlib
import json
import shutil
import tarfile


lab = Path(__file__).resolve().parent
comparison = lab / 'comparison'
first = comparison / 'quiet'
repeat = lab / 'repeat'
quiet = repeat / 'comparison/quiet'
quiet.mkdir(parents=True)
read = lambda path: json.loads(path.read_text(encoding='utf-8'))
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')


receipt = read(first / 'terminal-status.json')
assert receipt['exitCode'] == '1' and not receipt['fixtures'] and not receipt['receipt']['complete']
assert digest(first / 'observations.tar.xz') == receipt['receipt']['archiveSHA256']
identity = read(comparison / 'identity.json')
for role, files in identity['imageFiles'].items():
    assert len(files) == 32 and all(digest(lab / role / name) == expected for name, expected in files.items())
shutil.copyfile(comparison / 'representative.json', quiet / 'representative.json')
jobs = read(comparison / 'jobs.json')['warm']
write(quiet / 'jobs.json', dict(warm=[jobs[1], jobs[2], jobs[4]]))
identity['purpose'] += ' bounded confirmation after an idle gate failure'
identity['catalogs']['jobs.json']['sha256'] = digest(quiet / 'jobs.json')
write(quiet / 'identity.json', identity)
collector = (first / 'collect.py').read_text(encoding='utf-8')
collector = collector.replace('assert len(jobs) == 5', 'assert len(jobs) == 3')
collector = collector.replace('lython-b1514-fixtures', 'lython-b1514-repeat-fixtures')
compile(collector, 'collect.py', 'exec')
(quiet / 'collect.py').write_text(collector, encoding='utf-8', newline='\n')
shutil.copyfile(first / 'run.sh', quiet / 'run.sh')
assert b'\r' not in (quiet / 'run.sh').read_bytes()
for name in ('representative.json', 'jobs.json', 'identity.json'):
    shutil.copyfile(quiet / name, repeat / 'comparison' / name)
payload = quiet / 'payload.tar.gz'
with tarfile.open(payload, 'w:gz') as bundle:
    for name in ('identity.json', 'representative.json', 'jobs.json', 'run.sh', 'collect.py'):
        bundle.add(quiet / name, arcname=name)
write(quiet / 'upload.json', dict(root='indexed-regex-projection-b1514-repeat-20261123',
    reference='retained-call-cpython-b1510-20261123', original='indexed-regex-projection-b1514-20261123',
    originalArchive=receipt['receipt']['archiveSHA256'], payloadBytes=payload.stat().st_size, payloadSHA256=digest(payload)))

runner = (lab / 'quiet.py').read_text(encoding='utf-8')
runner = runner.replace('lython-b1514-indexed-regex-projection-20261123', 'lython-b1514-indexed-regex-projection-repeat-20261123')
runner = runner.replace('.+b1514-', '.+b1514-repeat-')
runner = runner.replace("'lython-b1514-stage-'", "'lython-b1514-repeat-stage-'")
runner = runner.replace('  if free < minimum:' + runner.split('  if free < minimum:', 1)[1].split('  assert free >= minimum', 1)[0], '')
runner = runner.replace('  # Five bounded lanes write under 1 MiB of receipts. A 106 MiB',
    '  # Three bounded lanes write under 1 MiB of receipts. A 106 MiB')
runner = runner.replace(",\'candidate-core.dll\'", '')
old_image = runner[runner.index(" image=root/'candidate';image.mkdir()") : runner.index(" os.link(reference/'cpython-worker.py'")]
runner = runner.replace(old_image, """ original=base/configuration['original']
 assert not (original/'guest-fixtures').exists()
 assert digest(original/'observations.tar.xz')==configuration['originalArchive']
 image=root/'candidate';image.mkdir()
 for name,sha in identity['imageFiles']['reference'].items():
  assert digest(reference/'candidate'/name)==sha, name
  donor=original/'candidate'/name
  assert digest(donor)==identity['imageFiles']['candidate'][name], name
  os.link(donor,image/name)
""")
runner = runner.replace('seconds=236', 'seconds=180').replace('RuntimeMaxSec=350', 'RuntimeMaxSec=235')
compile(runner, 'quiet.py', 'exec')
(repeat / 'quiet.py').write_text(runner, encoding='utf-8', newline='\n')
summary = (lab / 'summarize.py').read_text(encoding='utf-8')
summary = summary.replace('== 5', '== 3').replace('==5','==3').replace('timedBatches=140','timedBatches=84')
(repeat / 'summarize.py').write_text(summary, encoding='utf-8', newline='\n')
