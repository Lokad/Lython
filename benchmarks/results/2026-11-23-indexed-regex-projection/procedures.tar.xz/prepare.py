from pathlib import Path
import json
import shutil


lab = Path(__file__).resolve().parent
previous = lab.parent / 'adjacent-integer-results-20261123'
template = (previous / 'prepare.py').read_text(encoding='utf-8')
prefix = template[:template.index('base = read(')]
prefix = prefix.replace('adjacent-integer-results-20261123', 'indexed-regex-projection-20261123')
prefix = prefix.replace("prior = lab.parent / 'csv-batched-markers-20261123'", "prior = lab.parent / 'adjacent-integer-results-20261123'")
exec(compile(prefix, str(previous / 'prepare.py'), 'exec'))

base = read(source / 'identity.json')
candidate = (lab / 'built-revision').read_text(encoding='utf-8-sig').strip()
assert not git('-C', tree, 'status', '--porcelain')
assert candidate == git('-C', tree, 'rev-parse', 'HEAD').decode().strip()
assert not git('diff', '--name-only', base['sourceRevision'], candidate + '^', '--', 'src')
window = lab.parent / 'regex-indexed-cursor-window-20261123/representative.json'
catalog = read(window)
ids = ('scripts.regex-bounded-cursor.indexed', 'scripts.regex-indexed-cursor-capture-spans',
    'scripts.regex-unindexed-cursor-control', 'scripts.regex-ascii-cursor-control',
    'scripts.regex-unicode-wide-registers.indexed')
catalog['cases'] = [row for row in catalog['cases'] if row['id'] in ids]
wide = next(row for row in read(lab.parent / 'observed-regex-coordinates/shared/quiet/representative.json')['cases']
    if row['id'] == 'scripts.regex-unicode-wide-registers')
wide['id'] += '.indexed'
assert wide['source'].count('pattern =') == 1
wide['source'] = wide['source'].replace('pattern =', "assert text[2] == '😀'\npattern =")
source_bytes = wide['source'].encode('utf-8')
wide.update(sourceSha256=hash_bytes(source_bytes), sourceUtf8Bytes=len(source_bytes))
catalog['cases'].append(wide)
assert {row['id'] for row in catalog['cases']} == set(ids)
write(comparison / 'representative.json', catalog)
write(comparison / 'jobs.json', dict(warm=[[case, 'warm'] for case in ids]))

verification = template[template.index('protocol = repo'):template.index('tracked = ')]
verification = verification.replace("proof['caseCount'] == 4", "proof['caseCount'] == 5")
verification = verification.replace('B1513 adjacent integer argument publication', 'B1514 project regex captures through an existing index')
exec(compile(verification, str(previous / 'prepare.py'), 'exec'))

# Stage only after the original experiment is archived on origin. Its sole
# old VM core replica can be retired under the same lease if space is short.
tracked = 'benchmarks/results/2026-11-23-adjacent-integer-results/'
pushed = lambda name: git('show', 'origin/master:' + tracked + name)
status = json.loads(pushed('terminal-status.json'))['receipt']
assert status['complete'] and status['allWorkersJoined'] and status['archivedAndVerifiedUnderLease']
assert hash_bytes(pushed('observations.tar.xz')) == status['archiveSHA256']
files = json.loads(pushed('identity.json'))['imageFiles']['candidate']
assert len(files) == 32 and all(digest(previous / 'candidate' / name) == expected for name, expected in files.items())
replica = gzip.decompress(pushed('candidate-core.dll.gz'))
assert hash_bytes(replica) == files[core]
retirement = dict(core=hash_bytes(replica), size=len(replica), archive=status['archiveSHA256'])
old_launch = (previous / 'quiet.py').read_text(encoding='utf-8')
old_retirement = old_launch[old_launch.index('   proof='):old_launch.index('   replica.unlink()')]
new_retirement = old_retirement[old_retirement.index('   earlier='):].replace(
    'csv-batched-markers-b1511-20261123', 'adjacent-integer-results-b1513-20261123')
adapt('quiet.py', [(old_retirement, f'   proof={retirement!r}\n' + new_retirement),
    ('lython-b1513-adjacent-integer-results-20261123', 'lython-b1514-indexed-regex-projection-20261123'),
    ('.+b1513-', '.+b1514-'), ('lython-b1513-stage-', 'lython-b1514-stage-')])
adapt('stage.py', [('adjacent-integer-results-b1513-20261123', 'indexed-regex-projection-b1514-20261123'),
    ('lython-b1513-fixtures', 'lython-b1514-fixtures')])
for name in ('allocations.py', 'summarize.py'):
    shutil.copyfile(previous / name, lab / name)
