from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile


lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / 'comparison/quiet'
repeat = lab / 'repeat/comparison/quiet'
dest = repo / 'benchmarks/results/2026-11-23-indexed-regex-projection'
read = lambda path: json.loads(path.read_text(encoding='utf-8'))
sha = lambda data: hashlib.sha256(data).hexdigest()
digest = lambda path: sha(path.read_bytes())
git = lambda *args: subprocess.check_output(['git', *args], cwd=repo)
identity = read(lab / 'comparison/identity.json')
status = read(quiet / 'terminal-status.json')
receipt = status['receipt']
assert not status['live'] and not status['fixtures'] and status['exitCode'] == '1'
assert receipt['archivedAndVerifiedUnderLease'] and receipt['guestFixturesRemoved'] and not receipt['quietBeforeAndAfter']
assert digest(quiet / 'observations.tar.xz') == receipt['archiveSHA256']
assert read(quiet / 'initial-diagnostic-summary.json')['timedBatches'] == 140
later = read(repeat / 'terminal-status.json')
assert not later['live'] and not later['fixtures'] and later['exitCode'] == '0'
assert all(later['receipt'][key] for key in ('complete', 'archivedAndVerifiedUnderLease', 'allWorkersJoined', 'guestFixturesRemoved', 'quietBeforeAndAfter'))
assert digest(repeat / 'observations.tar.xz') == later['receipt']['archiveSHA256']
assert read(repeat / 'summary.json')['timedBatches'] == 84
rows = read(lab / 'allocation-summary-six.json')
assert len(rows) == 5 and sum(row['peakAdmission'][1] < row['peakAdmission'][0] for row in rows) == 3
changed = git('diff', '--name-only', identity['candidate'] + '^', identity['candidate'], '--', 'src', 'tests').decode().splitlines()
assert len(changed) == 2 and sum(file.startswith('src/') for file in changed) == 1
head = git('rev-parse', 'HEAD').decode().strip()
identity['retainedRevision'] = None if git('diff', '--name-only', head, identity['candidate'], '--', 'src') else head
identity['retainedTestRevision'] = None if git('diff', '--name-only', head, identity['candidate'], '--', changed[1]) else head
patch = git('diff', '--binary', identity['candidate'] + '^', identity['candidate'], '--', *changed)
(lab / 'comparison.patch').write_bytes(patch)
identity['comparisonPatchSHA256'] = sha(patch)
dest.mkdir(exist_ok=True)
assert {path.name for path in dest.iterdir()} <= {
    'README.md', 'candidate-core.dll.gz', 'identity.json', 'initial-observations.tar.xz', 'initial-terminal-status.json',
    'observations.tar.xz', 'summary.json', 'terminal-status.json', 'initial-diagnostic-summary.json',
    'allocation-summary-six.json', 'procedures.tar.xz',
}
for role, files in identity['imageFiles'].items():
    assert len(files) == 32 and all(digest(lab / role / name) == expected for name, expected in files.items())
    core = lab / role / 'Lokad.Lython.dll'
    image = dest / 'candidate-core.dll.gz' if role == 'candidate' else dest.parent / '2026-11-23-retained-call-cpython/candidate-core.dll.gz'
    if role == 'candidate':
        image.write_bytes(gzip.compress(core.read_bytes(), mtime=0))
    assert sha(gzip.decompress(image.read_bytes())) == files[core.name]
(dest / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8', newline='\n')
for name in ('observations.tar.xz', 'terminal-status.json'):
    shutil.copyfile(quiet / name, dest / ('initial-' + name))
for name in ('observations.tar.xz', 'summary.json', 'terminal-status.json'):
    shutil.copyfile(repeat / name, dest / name)
shutil.copyfile(quiet / 'initial-diagnostic-summary.json', dest / 'initial-diagnostic-summary.json')
shutil.copyfile(lab / 'allocation-summary-six.json', dest / 'allocation-summary-six.json')
with tarfile.open(dest / 'procedures.tar.xz', 'w:xz') as archive:
    for name in (
        'archive.py', 'prepare.py', 'prepare-repeat.py', 'stage.py', 'quiet.py', 'comparison.patch',
        'summarize.py', 'summarize-initial.py', 'allocations.py', 'allocations.log',
        'windows-frozen.log', 'windows-public.log', 'ubuntu-public.log', 'reference-allocation-six.json', 'candidate-allocation-six.json',
        'prepare.log', 'stage.log', 'launch.log', 'retrieval.log', 'comparison/reference-verify.json', 'comparison/candidate-verify.json',
        'comparison/quiet/observe-not-before', 'repeat-launch.log', 'repeat-retrieval.log', 'repeat/quiet.py',
        'repeat/summarize.py', 'repeat/comparison/quiet/observe-not-before'):
        archive.add(lab / name, arcname=name)
    for name in ('windows-retained.log', 'ubuntu-retained.log', 'retained-regression.patch'):
        if (lab / name).is_file():
            archive.add(lab / name, arcname=name)
print(dest, identity['retainedRevision'] or 'private')
