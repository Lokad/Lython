from pathlib import Path


lab = Path(__file__).resolve().parent
script = (lab / 'summarize.py').read_text(encoding='utf-8')
script = script.replace('and status["exitCode"]=="0"', 'and status["exitCode"]=="1"')
script = script.replace('assert all(receipt[k] for k in ["complete","allWorkersJoined","guestFixturesRemoved","quietBeforeAndAfter","archivedAndVerifiedUnderLease"])',
    'assert receipt["guestFixturesRemoved"] and receipt["archivedAndVerifiedUnderLease"] and not receipt["quietBeforeAndAfter"]')
script = script.replace('assert receipt["warmJobs"] == 5\n', '')
script = script.replace('assert warm["complete"] and len(warm["jobs"])==5',
    'assert not warm["complete"] and len(warm["jobs"])==5\n'
    '    assert packed("confirmation/machine-before.json")["gate"]["quiet"]\n'
    '    failed_gate=packed("confirmation/machine-after.json")["gate"]\n'
    '    assert not failed_gate["quiet"] and "Idle CPU exceeds" in failed_gate["reasons"][0]')
script = script.replace('(quiet/"summary.json")', '(quiet/"initial-diagnostic-summary.json")')
script = script.replace('elapsedSeconds=warm["elapsedSeconds"],',
    'measurementStatus="diagnostic; terminal idle gate failed", failedQuietGate=failed_gate,')
exec(compile(script, str(lab / 'summarize.py'), 'exec'))
