from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
source_lab = lab.parent / sys.argv[1]
template = lab.parent / "retained-csv-cpython-20261122"
quiet = lab / "quiet"
core = "Lokad.Lython.dll"
def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path, content):
    if path.suffix == ".py":
        compile(content,str(path),"exec")
    path.write_text(content, encoding="utf-8", newline="\n")

source = source_lab/"quiet"
config = read(source/"config.json")
assert read(source/"terminal-status.json")["exitCode"] == "0"
receipt = read(source/"archive-receipt.json")
assert receipt["complete"] and receipt["quietBeforeAndAfter"] and receipt["archivedAndVerifiedUnderLease"]
assert sha(source/"observations.tgz") == receipt["archiveSHA256"]
donor_revision = config["identity"]["sourceRevision"].split()[-1]
revision = subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip()
assert revision == subprocess.check_output(["git","rev-parse","origin/master"],cwd=repo,text=True).strip()
assert revision == "72e1131b975e41523c95e71ca43a7c37ada59001"
assert donor_revision.startswith("3bbc7a416")
measured = revision
assert sha(lab/"frozen-candidate-core.dll") != config["identity"]["imageFiles"]["candidate"][core]
assert not subprocess.check_output(["git","status","--porcelain"],cwd=repo)
source_files = config["identity"]["imageFiles"]["candidate"]
source_image = source_lab/"frozen/candidate"
assert len(source_files) == 32 and {name:sha(source_image/name) for name in source_files} == source_files
protocol = repo/"benchmarks/cpython-worker.py"
assert sha(protocol) == config["protocolSHA256"]

catalog = read(template/"quiet/representative.json")
with tarfile.open(repo/"benchmarks/results/2026-11-21-cpython-expanded-builtin/observations.tgz") as archive:
    json_catalog = json.load(archive.extractfile("representative.json"))
meter = "scripts.csv-meter-report.typed-ascii"
factory = "scripts.annotated-rule-closures.literal-positional-dynamic-keyword"
report = "scripts.json-lines-shipment.expanded-options.large"
json_cases = [c for c in json_catalog["cases"] if c["id"] == report]
assert len(json_cases) == 1
catalog["cases"] = [c for c in catalog["cases"] if c["id"] in {meter,factory}] + json_cases
assert len(catalog["cases"]) == 3
jobs = [(meter,"warm"),(factory,"warm"),(report,"warm"),
        (factory,"compile"),(meter,"compile-run"),(factory,"compile-run")]

image = lab/"frozen"
image.mkdir()
for name in source_files:
    shutil.copyfile(lab/"frozen-candidate-core.dll" if name==core else source_image/name,image/name)
files = {name:sha(image/name) for name in source_files}
assert [name for name in files if files[name] != source_files[name]] == [core]
quiet.mkdir()
manifest = quiet/"representative.json"
write(manifest,json.dumps(catalog,ensure_ascii=False,separators=(",",":"))+"\n")
dotnet = Path.home()/".dotnet11/dotnet.exe"
env = dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent),
    PATH=str(dotnet.parent)+os.pathsep+os.environ["PATH"])
proof_path = lab/"verify.json"
subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",manifest,
    "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",proof_path],
    env=env,check=True,timeout=95)
proof = read(proof_path)
assert proof["state"]=="Completed" and proof["caseCount"]==3 and proof["catalogSha256"]==sha(manifest)
assert {name:sha(image/name) for name in files} == files
identity = dict(sourceRevision=measured,productionEquivalent=revision,imageSource=measured,
    purpose="Current mixed factory, typed ASCII meter and JSON Lines export against stock CPython",
    imageFiles=dict(candidate=files),catalogSHA256=sha(manifest),
    cpythonWorkerSHA256=sha(protocol),auxiliaryFiles={n:h for n,h in files.items() if n!=core},
    coreSHA256={label:files[core] for label in ("candidate","candidate-control")})
write(quiet/"identity.json",json.dumps(identity,indent=2)+"\n")
root = "/home/lokad/lython-bench-checks/post-range-cpython-b1351-20261122"
unit = "lython-b1351-post-range-cpython-20261122"
old = read(template/"quiet/config.json")
for name in ("collect.py","archive-owned.py","run.sh","retrieve.py"):
    content = (template/"quiet"/name).read_text(encoding="utf-8").replace(old["root"],root).replace(old["unit"],unit)
    if name == "collect.py":
        begin = content.index("    for case_id,lane in ")
        end = content.index("        assert time.monotonic()",begin)
        content = content[:begin] + f"    for case_id,lane in {jobs!r}:\n" + content[end:]
        content = content.replace("time.monotonic()-started<460","time.monotonic()-started<345")
    elif name == "archive-owned.py":
        content = content.replace("len(raw['jobs'])==7","len(raw['jobs'])==6").replace("jobs=7,","jobs=6,")
    elif name == "retrieve.py":
        content = content.replace("['jobs']==7","['jobs']==6")
    write(quiet/name,content.replace("B1327","B1351"))
assert b"\r" not in (quiet/"run.sh").read_bytes()
(quiet/"candidate").mkdir()
shutil.copyfile(image/core, quiet/"candidate"/core)
assert sha(quiet/"candidate"/core)==files[core]
parts = ("identity.json","representative.json","collect.py","archive-owned.py","run.sh","candidate/"+core)
payload = quiet/"payload.tgz"
with tarfile.open(payload,"w:gz") as archive:
    for name in parts:
        archive.add(quiet/name,arcname=name)
stage = dict(root=root,unit=unit,identity=identity,source=config["root"],sourceRole="candidate",
    sourceFiles=source_files,sourceCatalogSHA256=config["catalogSHA256"],donorArchiveSHA256=receipt["archiveSHA256"],
    catalogSHA256=identity["catalogSHA256"],retireGroups=read(lab/"retire-proof.json")["proof"],cpythonWorkerSHA256=sha(protocol),
    payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),
    unpackedBytes=sum((quiet/name).stat().st_size for name in parts))
write(quiet/"config.json",json.dumps(stage,indent=2)+"\n")
content = (template/"quiet/remote-launch.py").read_text(encoding="utf-8")
begin, end = content.index("\nc=")+1, content.index("\nb=Path(")
content = content[:begin]+"c="+repr(stage)+content[end:]
write(quiet/"remote-launch.py",content.replace("lython-b1327-fixtures","lython-b1351-fixtures").replace("RuntimeMaxSec=510","RuntimeMaxSec=385"))
content = (template/"launch.py").read_text(encoding="utf-8")
write(lab/"launch.py",content.replace("B1327 retained CSV checkpoint against CPython","B1351 retained factory, CSV and JSON checkpoint against CPython").replace("435","365"))
print("Prepared six short lanes after verifying exact current source and three CPython goldens.")
