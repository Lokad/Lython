from pathlib import Path

lab = Path(__file__).resolve().parent
template = lab.parent / "numeric-extrema-standalone-20261122" / "prepare-quiet-owned.py"
source = template.read_text(encoding="utf-8")
source = source.replace('prior = lab.parent / "csv-numeric-slot-ingress-20261122"',
                        'prior = lab.parent / "numeric-extrema-standalone-20261122"')
source = source.replace('prior_identity["imageFiles"]["reference"]', 'prior_identity["imageFiles"]["candidate"]')
source = source.replace('prior / "frozen" / "reference"', 'prior / "frozen" / "candidate"')
source = source.replace('sourceRole="reference"', 'sourceRole="candidate"')
source = source.replace('reference.startswith("52eeb328e") and candidate.startswith("b6dd01aee")',
                        'reference.startswith("e961df912") and candidate.startswith("ed5e4b527")')
source = source.replace('(("white", 590), ("public", 776))', '(("white", 67), ("public", 425))')
start, end = source.index('cases = ['), source.index('\ncatalog["cases"]')
source = source[:start] + '''cases = ["diagnostic.regex-prepared-names.many-named-rules", "diagnostic.regex-prepared-names.many-unnamed-rules",
         "scripts.regex-unicode-groups", "scripts.regex-ascii-groups"]''' + source[end:]
source = source.replace('"run.sh",\n         "candidate/"', '"run.sh", "representative.json",\n         "candidate/"')
source = source.replace('assert sha(manifest) == prior_config["catalogSHA256"]\n', '')
source = source.replace('numeric-extrema-b1335', 'regex-prepared-group-b1337')
source = source.replace('b1335-numeric-extrema', 'b1337-regex-prepared-group')
source = source.replace('b1335-fixtures', 'b1337-fixtures')
source = source.replace('Positional numeric extrema consume existing executable operands', 'Reuse validated named-group metadata from the compiled handle')
source = source.replace('Positional numeric extrema comparison', 'Prepared regex group metadata comparison')
assert 'sourceRole="candidate"' in source and '"run.sh", "representative.json"' in source
target = lab / "prepare-quiet-owned.py"
target.write_text(source, encoding="utf-8", newline="\n")
exec(compile(source, str(target), "exec"))
