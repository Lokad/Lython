from pathlib import Path
import shutil

lab = Path(__file__).resolve().parent
prior = lab.parent / "regex-prepared-group-metadata-20261122"
shutil.copyfile(prior / "representative.json", lab / "representative.json")
source = (prior / "measure.py").read_text(encoding="utf-8")
source = source.replace("regex-prepared-group-metadata-20261122", lab.name)
source = source.replace('baseline = "52eeb328e"', 'baseline = "e961df912"')
source = source.replace('"direct-jump-layout-20261122"', '"numeric-extrema-standalone-20261122"')
source = source.replace('        subprocess.run(["git", "diff", "--exit-code", revision, candidate + "^", "--", "src", "tests"], cwd=root, check=True)',
                        '        subprocess.run(["git", "diff", "--exit-code", revision, "HEAD", "--", "src", "tests"], cwd=root, check=True)\n'
                        '        subprocess.run(["git", "merge-base", "--is-ancestor", revision, candidate], cwd=root, check=True)')
target = lab / "measure.py"
compile(source, str(target), "exec")
target.write_text(source, encoding="utf-8", newline="\n")

source = (prior / "test-ubuntu.sh").read_text(encoding="utf-8").replace(prior.name, lab.name)
start = source.index('dotnet test tests/Lokad.Lython.PublicApi.Tests')
white = source[start:source.index("\ngrep", start)].replace('tests/Lokad.Lython.PublicApi.Tests', 'tests/Lokad.Lython.Tests').replace('public-ubuntu.log', 'white-ubuntu.log')
source = source[:start] + white + '\n' + source[start:]
source = source.replace('grep \'Passed!\'', 'grep -H \'Passed!\'').replace('grep -H \'Passed!\' "$logs/public-ubuntu.log"', 'grep -H \'Passed!\' "$logs/white-ubuntu.log" "$logs/public-ubuntu.log"')
(lab / "test-ubuntu.sh").write_text(source, encoding="utf-8", newline="\n")
assert b"\r" not in (lab / "test-ubuntu.sh").read_bytes()

template = lab.parent / "numeric-extrema-standalone-20261122" / "prove-retirement.py"
source = template.read_text(encoding="utf-8")
start, end = source.index('for artifact, old_name'), source.index('    old = lab.parent / old_name')
source = source[:start] + '''for artifact, old_name, catalog, core in (
    ("2026-11-22-joint-definition-admission", "definition-admission-20261122", False, True),
    ("2026-11-22-fused-executable-finalization", "fused-executable-finalization-20261122", False, True),
    ("2026-11-22-single-positional-default", "single-positional-default-20261122", False, True),
    ("2026-11-22-numeric-tuple-slots", "numeric-tuple-slots-20261122", True, True),
    ("2026-11-21-native-only-method-lookup", "native-only-method-lookup-20261121", True, False),
):
''' + source[end:]
target = lab / "prove-retirement.py"
compile(source, str(target), "exec")
target.write_text(source, encoding="utf-8", newline="\n")
