from pathlib import Path
import gzip
import hashlib
import json
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
inventory_path = lab / "retire-inventory.json"
inventory = json.loads(inventory_path.read_text(encoding="utf-8"))

def sha(data):
    return hashlib.sha256(data).hexdigest()

proofs = []
for artifact, local, role, filename in (
    ("2026-11-22-direct-jump-layout", "direct-jump-layout-20261122/quiet", "candidate", "candidate-core.dll.gz"),
    ("2026-11-22-retained-csv-cpython", "retained-csv-cpython-20261122/quiet", "candidate", "measured-core.dll.gz"),
):
    config = json.loads((lab.parent / local / "config.json").read_text(encoding="utf-8"))
    prefix = f"benchmarks/results/{artifact}/"
    binary = subprocess.check_output(["git", "show", "origin/master:" + prefix + filename], cwd=repo)
    observation = subprocess.check_output(["git", "show", "origin/master:" + prefix + "observations.tgz"], cwd=repo)
    assert sha(binary) == sha((repo / prefix / filename).read_bytes())
    digest = sha(gzip.decompress(binary))
    assert digest == config["identity"]["imageFiles"][role]["Lokad.Lython.dll"]
    base = Path(config["root"]).name
    proofs.append(dict(origin=base + f"/{role}/Lokad.Lython.dll", bytes=len(gzip.decompress(binary)), sha256=digest,
                       canonicalArchive=prefix + filename, archives={base + "/observations.tgz": sha(observation)}, optional=False))

remote = r'''
from pathlib import Path
import fcntl, hashlib, json, os, shutil, stat
base = Path('/home/lokad/lython-bench-checks').resolve()
proofs = PROOFS
def sha(path):
  with path.open('rb') as source: return hashlib.file_digest(source,'sha256').hexdigest()
with (base/'comparison-vm.lock').open('a') as lease:
  fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
  assert not any(os.path.ismount(p) for p in base.glob('*/guest-fixtures'))
  originals = {}
  for proof in proofs:
    path = base/proof['origin']
    if not path.is_file(): continue
    info=path.lstat()
    if not (stat.S_ISREG(info.st_mode) and info.st_uid==os.getuid() and path.resolve()==path): continue
    if info.st_size!=proof['bytes'] or sha(path)!=proof['sha256']: continue
    if not all(sha(base/name)==checksum for name,checksum in proof['archives'].items()): continue
    proof.update(paths=[],links=info.st_nlink)
    originals[info.st_dev,info.st_ino] = proof
  for directory, dirs, files in os.walk(base):
    for name in files:
      path = Path(directory)/name
      info=path.lstat()
      proof=originals.get((info.st_dev,info.st_ino))
      if proof is not None:
        assert name=='Lokad.Lython.dll' and path.resolve()==path and stat.S_ISREG(info.st_mode)
        assert info.st_uid==os.getuid() and info.st_nlink==proof['links'] and info.st_size==proof['bytes']
        proof['paths'].append(path.relative_to(base).as_posix())
  for proof in originals.values():
    if len(proof['paths'])==proof['links']: proof['verified']=True
  print(json.dumps(dict(free=shutil.disk_usage(base).free,proofs=list(originals.values()))))
'''.replace("PROOFS", repr(proofs))
ssh = ["C:/Windows/System32/OpenSSH/ssh.exe", "-i", str(Path.home()/".ssh/id_lython-bench.pem"),
       "-o", "BatchMode=yes", "-o", "ConnectTimeout=15", "lokad@20.166.121.73", "python3 -"]
live = json.loads(subprocess.check_output(ssh, input=remote, encoding="utf-8", timeout=55))
inventory["free"] = live["free"]
inventory["proofs"].extend(live["proofs"])
inventory_path.write_text(json.dumps(inventory, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps(live, indent=2))
