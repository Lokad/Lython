from collections import defaultdict
from pathlib import Path
import hashlib
import json
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
existing = json.loads((lab / "retire-inventory.json").read_text(encoding="utf-8"))

def sha(value):
    return hashlib.sha256(value).hexdigest()

archived = defaultdict(list)
for path in (repo / "benchmarks/results").rglob("observations.tgz"):
    if path.stat().st_size >= 2_000_000:
        archived[path.stat().st_size].append(path)

remote = r'''
from pathlib import Path
import fcntl, hashlib, json, os, shutil, stat, subprocess
base = Path('/home/lokad/lython-bench-checks').resolve()
sizes = SIZES
def sha(path):
  with path.open('rb') as source: return hashlib.file_digest(source,'sha256').hexdigest()
with (base/'comparison-vm.lock').open('a') as lease:
  fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
  assert not any(os.path.ismount(p) for p in base.glob('*/guest-fixtures'))
  workers = subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True).stdout
  assert not workers, workers
  result = []
  for path in sorted(base.glob('*/observations.tgz')):
    info = path.lstat()
    if info.st_size not in sizes or info.st_nlink != 1 or info.st_uid != os.getuid(): continue
    if not stat.S_ISREG(info.st_mode) or path.resolve()!=path: continue
    result.append(dict(path=path.relative_to(base).as_posix(),bytes=info.st_size,sha256=sha(path)))
  print(json.dumps(dict(free=shutil.disk_usage(base).free,copies=result)))
'''.replace("SIZES", repr(set(archived)))
ssh = ["C:/Windows/System32/OpenSSH/ssh.exe", "-i", str(Path.home()/".ssh/id_lython-bench.pem"),
       "-o", "BatchMode=yes", "-o", "ConnectTimeout=15", "lokad@20.166.121.73", "python3 -"]
result = json.loads(subprocess.check_output(ssh, input=remote, encoding="utf-8", timeout=40))
for replica in sorted(result["copies"], key=lambda item: item["bytes"], reverse=True):
    for candidate in archived[replica["bytes"]]:
        if sha(candidate.read_bytes()) != replica["sha256"]: continue
        path = candidate.relative_to(repo).as_posix()
        tracked = subprocess.check_output(["git", "show", "origin/master:" + path], cwd=repo)
        assert sha(tracked) == replica["sha256"]
        existing["proofs"].append(dict(paths=[replica["path"]], bytes=replica["bytes"], links=1,
                                       sha256=replica["sha256"], canonicalArchive=path, archives={},
                                       optional=False, verified=True))
        break
existing["free"] = result["free"]
(lab / "retire-inventory.json").write_text(json.dumps(existing, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps(dict(free=result["free"], matches=[proof for proof in existing["proofs"] if proof.get("verified")]), indent=2))
