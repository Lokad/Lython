from pathlib import Path

lab = Path(__file__).resolve().parent
template = lab.parent / "numeric-extrema-standalone-20261122" / "archive.py"
source = template.read_text(encoding="utf-8")
source = source.replace('2026-11-22-numeric-extrema-operands', '2026-11-22-regex-prepared-group-metadata')
source = source.replace('52eeb328e', 'e961df912').replace('b6dd01aee', 'ed5e4b527').replace('B1335', 'B1337')
source = source.replace('(("white", 590), ("public", 776))', '(("white", 67), ("public", 425))')
source = source.replace('2026-11-22-direct-jump-layout', '2026-11-22-numeric-extrema-operands')
assert 'len(raw["jobs"]) == receipt["jobs"] == 5' in source
assert '(("white", 67), ("public", 425))' in source
target = lab / "archive.py"
compile(source, str(target), "exec")
target.write_text(source, encoding="utf-8", newline="\n")
