#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/regex-prepared-group-current-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/regex-prepared-group-current-20261122
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter 'Category!=Stress&FullyQualifiedName~Regex' --verbosity quiet > "$logs/white-ubuntu.log" 2>&1 || { tail -40 "$logs/white-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter 'Category!=Stress&FullyQualifiedName~Regex' --verbosity quiet > "$logs/public-ubuntu.log" 2>&1 || { tail -40 "$logs/public-ubuntu.log"; exit 1; }
grep -H 'Passed!' "$logs/white-ubuntu.log" "$logs/public-ubuntu.log"
