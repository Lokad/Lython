from pathlib import Path
import ast
import hashlib
import io
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
base = lab.parent
repo = Path.cwd()
donor = base / 'native-json-encoding-options-r540'
previous = base / 'json-numeric-tokens-r534/cpython'
quiet = lab / 'quiet'
quiet.mkdir()

def read(path):
    return path.read_text(encoding='utf-8-sig')

def write(path, value):
    if path.suffix == '.py':
        ast.parse(value)
    path.write_text(value, encoding='utf-8', newline='\n')

def digest(data):
    return hashlib.sha256(data).hexdigest()

def sha(path):
    return digest(path.read_bytes())

def save(path, data):
    write(path, json.dumps(data, indent=2, ensure_ascii=False) + '\n')

head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert head.startswith('bdab88c54')
assert not subprocess.check_output(['git', 'status', '--porcelain', '--', 'src'])
old = json.loads(read(donor / 'quiet/config.json'))
image = donor / 'frozen/candidate'
files = old['identity']['imageFiles']['candidate']
assert len(files) == 32 and files['Lokad.Lython.dll'].startswith('7170869d')
assert all(sha(image / name) == value for name, value in files.items())
assert sha(donor / 'representative.json') == old['catalogSHA256']

catalog = json.loads(read(donor / 'representative.json'))
edit, manifest = ('scripts.config-edit.small', 'scripts.config-manifest.small')
text = 'scripts.text-normalization.large'
catalog['cases'] = [c for c in catalog['cases'] if c['id'] in (edit, manifest)]
lineage = json.loads(read(base / 'native-index-bounds-r536/representative.json'))
catalog['cases'].append(next(c for c in lineage['cases'] if c['id'] == text))
assert {'schemaVersion', 'cases'} <= catalog.keys() and len(catalog['cases']) == 3
catalog['performanceQualified'] = False
catalog_path = quiet / 'representative.json'
save(catalog_path, catalog)

sdk = Path.home() / '.dotnet11'
dotnet = sdk / 'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk) + os.pathsep + os.environ['PATH'])
with (lab / 'preflight.log').open('w', encoding='utf-8') as log:
    subprocess.run([dotnet, image / 'Lokad.Lython.Benchmarks.dll', '--compare', 'verify',
                    '--catalog', catalog_path, '--dotnet', dotnet, '--python', 'C:/Python313/python.exe',
                    '--python-worker', repo / 'benchmarks/cpython-worker.py', '--out', lab / 'preflight.json'],
                   cwd=repo, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=120, check=True)
assert all(sha(image / name) == value for name, value in files.items())

identity = dict(sourceRevision=head, purpose='Retained builtin JSON output options versus stock CPython',
                coreSHA256={role: files['Lokad.Lython.dll'] for role in ('candidate', 'candidate-control')},
                imageFiles={'candidate': files}, auxiliaryFiles={n:h for n,h in files.items() if n!='Lokad.Lython.dll'},
                catalogSHA256=sha(catalog_path), normalAdapterPin='0.4.0', publicationHeld=True)
save(quiet / 'identity.json', identity)
jobs = [(case, lane) for lane in ('compile', 'warm', 'compile-run') for case in (edit, manifest)]
jobs.append((text, 'warm'))
save(lab / 'jobs.json', jobs)
old_quiet = previous / 'quiet'
collector = read(old_quiet / 'collect.py')
start, end = collector.index('\njobs=') + 1, collector.index('\nenv =')
collector = collector[:start] + 'jobs=' + repr(jobs) + '\nassert len(jobs)==7 and all(case in cases for case,lane in jobs)\n' + collector[end:]
collector = collector.replace(" < 270, 'Reserve60seconds", " < 360, 'Reserve60seconds")
write(quiet / 'collect.py', collector)
write(quiet / 'archive-owned.py', read(old_quiet / 'archive-owned.py').replace("len(raw['jobs'])==4", "len(raw['jobs'])==7").replace('jobs=4,elapsedSeconds', 'jobs=7,elapsedSeconds'))
remote = '/home/lokad/lython-bench-checks/json-options-cpython-b973-20261118'
unit = 'lython-b973-json-options-cpython-20261118'
old_config = json.loads(read(old_quiet / 'config.json'))
write(quiet / 'run.sh', read(old_quiet / 'run.sh').replace(old_config['root'], remote))
assert b'\r' not in (quiet / 'run.sh').read_bytes()
members = ['collect.py', 'archive-owned.py', 'run.sh', 'identity.json', 'representative.json']
payload = quiet / 'payload.tgz'
with tarfile.open(payload, 'w:gz') as archive:
    for name in members:
        archive.add(quiet / name, arcname=name)

results = 'benchmarks/results/'
records = [
    ('native-encoder-b972-20261118/confirmation/confirmation.json','2026-11-18-native-json-encoding-options/observations.tgz','confirmation/confirmation.json'),
    ('strip-owner-b970-20261118/observations.tgz','2026-11-18-shared-trim-ownership/observations.tgz',None),
    ('string-slices-b971-20261118/observations.tgz','2026-11-18-string-slice-ownership/comparison/observations.tgz',None),
    ('json-numeric-confirm-b965-20261118/observations.tgz','2026-11-18-json-number-lexing/confirmation/observations.tgz',None),
    ('json-numeric-cpython-b966-20261118/observations.tgz','2026-11-18-json-numeric-cpython/observations.tgz',None),
    ('native-index-bounds-confirm-b968-20261118/observations.tgz','2026-11-18-native-sequence-bounds/confirmation/observations.tgz',None),
]
proofs = []
total = sum((quiet / name).stat().st_size for name in members)
ssh = ['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),
       '-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
availability = subprocess.check_output(ssh + ['df -B1 --output=avail /home/lokad/lython-bench-checks'], text=True, timeout=30)
available = int(availability.splitlines()[-1])
needed = 254 * 1024 * 1024 + total + 131072
for remote_file, relative, member in records:
    if available + sum(p['bytes'] for p in proofs) > needed:
        break
    canonical = results + relative
    committed = subprocess.check_output(['git', 'show', head + ':' + canonical])
    assert committed == (repo / canonical).read_bytes()
    if member:
        with tarfile.open(fileobj=io.BytesIO(committed)) as archive:
            exact = archive.extractfile(member).read()
    else:
        exact = committed
    proofs.append(dict(kind='exact archived observation replica', canonical=canonical, canonicalSHA256=digest(committed),
                       member=member, sha256=digest(exact), bytes=len(exact), committedBlobVerified=True,
                       links=1, paths=[remote_file]))
assert available + sum(p['bytes'] for p in proofs) > needed, (available, needed, total, [p['bytes'] for p in proofs])
settings = dict(root=remote, unit=unit, source=old['root'], sourceRole='candidate',
                sourceFiles=files, sourceCatalogSHA256=old['catalogSHA256'], catalogSHA256=sha(catalog_path),
                identity=identity, retireGroups=proofs, payloadBytes=payload.stat().st_size,
                payloadSHA256=sha(payload), unpackedBytes=total)
save(quiet / 'config.json', settings)
launcher = read(old_quiet / 'remote-launch.py')
start, end = launcher.index('\nc=') + 1, launcher.index('\nb=Path(')
launcher = launcher[:start] + 'c=' + repr(settings) + launcher[end:]
launcher = launcher.replace(" os.link(source/'representative.json',root/'representative.json')\n",
                            " # The changed catalog is already staged from verified inputs.\n")
launcher = launcher.replace('lython-b966-fixtures', 'lython-b973-fixtures').replace('RuntimeMaxSec=330', 'RuntimeMaxSec=420')
write(quiet / 'remote-launch.py', launcher)
write(quiet / 'retrieve.py', read(old_quiet / 'retrieve.py').replace("['jobs']==4", "['jobs']==7").replace('B966','B973'))
write(lab / 'launch.py', read(previous / 'launch.py').replace('seconds=225', 'seconds=345').replace('before225seconds', 'before345seconds').replace('Four-job JSON CPython','Seven-job configuration CPython'))
write(lab / 'summarize.py', read(previous / 'summarize.py').replace("len(raw['jobs'])==4", "len(raw['jobs'])==7"))
print('Verified three catalog cases and all 32 image files. Staged', total, 'bytes;', len(proofs), 'archive replicas.')
