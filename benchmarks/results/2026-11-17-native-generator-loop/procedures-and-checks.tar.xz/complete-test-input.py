from pathlib import Path
import hashlib,json,tarfile
r=Path(__file__).parent;work=Path('D:/code/Lython/.git/agent-worktrees/native-generators-r494');p=r/'frozen/identity.json';v=json.loads(p.read_text(encoding='utf-8'));name=v['newObservableTest']
with tarfile.open(r/'candidate-sources.tar.xz')as a:(r/'pre-held-cleanup-BufferedGeneratorContinuationTests.cs').write_bytes(a.extractfile(name).read())
for n,h in v['sourceInputs'].items():
 if n!=name:assert hashlib.sha256((work/n).read_bytes()).hexdigest()==h,n
v['sourceInputs'][name]=hashlib.sha256((work/name).read_bytes()).hexdigest()
v['additionalOwnershipValidation']='Async file cleanup held independently of cancellation; result remains pending, file remains open and shared allowance funded until release. Includes success, guest error, cancellation and terminal refusal; subsequent independent execution restores baseline.'
p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as a:
 for n in v['sourceInputs']:a.add(work/n,arcname=n)
print('Held-cleanup regression source included in final2383inputs; all585production inputs unchanged.')
