using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.PublicApi.Tests;

public sealed class BufferedGeneratorContinuationTests
{
    [Theory]
    [InlineData(false, "success")]
    [InlineData(true, "success")]
    [InlineData(false, "guest-error")]
    [InlineData(true, "guest-error")]
    [InlineData(false, "refuse")]
    [InlineData(true, "refuse")]
    [InlineData(true, "cancel")]
    public async Task PartialHelpersPreserveEffectsAliasesAndAwaitedCleanup(bool asynchronous, string mode)
    {
        const string source = """
            events = []
            marker = 'm' * 8192
            with open('/numbers') as stream:
                def reading():
                    events.append(marker)
                    value = stream.readline()
                    if mode == 'refuse': return len('x' * 8388608)
                    return float(value)
                try:
                    total = sum(reading() for index in range(3))
                except ValueError:
                    assert mode == 'guest-error'
                    assert len(events) == 2
                except MemoryError:
                    return 'unexpected recovery'
                else:
                    assert total == 9.0
                    assert len(events) == 3
                assert all(value is marker for value in events)
                return marker
            """;
        var budget = new LythonMemoryBudget(4 * 1024 * 1024);
        using var script = new LythonEngine().Compile(source, budget);
        Assert.True(script.IsValid, string.Join("; ", script.Diagnostics));
        var baseline = budget.ReservedBytes;
        using var cancellation = new CancellationTokenSource();
        var delayed = new DelayedLythonHost();
        var synchronous = new MockLythonHost();
        var text = mode == "guest-error" ? "2\nbad\n4\n" : "2\n3\n4\n";
        delayed.SeedFile("/numbers", text);
        synchronous.SeedFile("/numbers", text);
        var entered = mode == "cancel" ? delayed.PauseReadUntilCancellation("/numbers") : null;
        var options = new LythonRunOptions
        {
            Globals = new Dictionary<string, object?> { ["mode"] = mode },
            CancellationToken = cancellation.Token
        };
        var pending = asynchronous ? script.RunAsync(delayed, options) : Task.FromResult(script.Run(synchronous, options));
        try
        {
            if (entered is not null)
            {
                var first = await Task.WhenAny(entered, pending).WaitAsync(TimeSpan.FromSeconds(5));
                if (ReferenceEquals(first, pending))
                {
                    using var early = await pending;
                    Assert.Fail(early.Failure?.Message ?? "Helper did not suspend in its first read.");
                }
                Assert.False(pending.IsCompleted);
                Assert.True(budget.ReservedBytes > baseline);
                cancellation.Cancel();
            }
            using var result = await pending.WaitAsync(TimeSpan.FromSeconds(5));
            if (mode is "refuse" or "cancel")
            {
                Assert.False(result.Success);
                Assert.Equal(mode == "cancel" ? LythonFailureReason.Cancelled : LythonFailureReason.SharedMemoryAllowance,
                    result.FailureAttribution?.Reason);
                Assert.Empty(result.StandardOutput);
            }
            else
            {
                Assert.True(result.Success, result.Failure?.Message);
                Assert.Equal(new string('m', 8192), result.ReturnValue);
                Assert.True(budget.ReservedBytes > baseline);
                if (asynchronous) Assert.True(delayed.CompletedAsynchronously > 0);
            }
        }
        finally
        {
            cancellation.Cancel();
            using var joined = await pending.WaitAsync(TimeSpan.FromSeconds(5));
        }
        Assert.Equal(baseline, budget.ReservedBytes);
        using (var reusable = script.Run(synchronous, new LythonRunOptions
        {
            Globals = new Dictionary<string, object?> { ["mode"] = "success" }
        })) Assert.True(reusable.Success, reusable.Failure?.Message);
        Assert.Equal(baseline, budget.ReservedBytes);
    }
}
