from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;work=Path('D:/code/Lython/.git/agent-worktrees/native-generators-r494')
identity=r/'frozen/identity.json';v=json.loads(identity.read_text(encoding='utf-8'));name=v['newObservableTest']
shutil.copyfile(identity,r/'first-fixture-input-identity.json')
with tarfile.open(r/'candidate-sources.tar.xz')as a:(r/'first-fixture-BufferedGeneratorContinuationTests.cs').write_bytes(a.extractfile(name).read())
for source,h in v['sourceInputs'].items():
 if source!=name:assert hashlib.sha256((work/source).read_bytes()).hexdigest()==h,source
v['sourceInputs'][name]=hashlib.sha256((work/name).read_bytes()).hexdigest();v['fixtureCorrection']='Reset malformed input before successful budget-reuse run; initial main execution assertions passed, two reuse assertions failed for old bad input. Runtime unchanged; no weakened timeout/ownership/effect assertion.'
identity.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as a:
 for name in v['sourceInputs']:a.add(work/name,arcname=name)
print('Only new fixture input snapshot refreshed; original failure/source retained, every production input unchanged.')
