from pathlib import Path
import gzip,hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;root=Path('D:/code/Lython');work=root/'.git/agent-worktrees/native-generators-r494';prior=r.parent/'json-scalars-r492'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((prior/'main-frozen-identity.json').read_text(encoding='utf-8'));base=json.loads((prior/'frozen/identity.json').read_text(encoding='utf-8'))
assert f['runtimeCommit'].startswith('33bd7efd')and subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip().startswith('22d5a5f3')
changed=subprocess.check_output(['git','diff','--name-only'],cwd=work,text=True).splitlines();assert len(changed)==7 and all(n.startswith('src/Lokad.Lython/')for n in changed)
newtest='tests/Lokad.Lython.PublicApi.Tests/BufferedGeneratorContinuationTests.cs';assert(work/newtest).is_file()
source_names=sorted(list(base['sourceInputs'])+[newtest]);assert len(source_names)==2383
shutil.copyfile(prior/'catalog.json',r/'catalog.json')
frozen=r/'frozen';frozen.mkdir(exist_ok=False)
for role in ['reference','candidate']:
 image=frozen/role;image.mkdir()
 for name,h in f['imageFiles'].items():
  assert sha(prior/'main-frozen'/name)==h
  shutil.copyfile(prior/'main-frozen'/name,image/name)
 for p in(prior/'frozen/reference').glob('ValidatedAllocation.*'):shutil.copyfile(p,image/p.name)
 if role=='candidate':shutil.copyfile(work/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',image/'Lokad.Lython.dll')
images={role:{name:sha(frozen/role/name)for name in f['imageFiles']}for role in ['reference','candidate']}
assert[n for n in f['imageFiles']if images['reference'][n]!=images['candidate'][n]]==['Lokad.Lython.dll']
inputs={name:sha(work/name)for name in source_names}
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as a:
 for name in inputs:a.add(work/name,arcname=name)
(r/'prototype.patch.gz').write_bytes(gzip.compress(subprocess.check_output(['git','diff','--']+changed,cwd=work),mtime=0))
identity=dict(referenceSource='Committed33bd7efd/frozen5e7058a3; full44128892209 pending at preparation',candidateSource='PrivateR494 existing-native-loop generator consumption on22d5a5f3; no promotion',imageFiles=images,sourceInputs=inputs,productionFiles=585,changedProductionFiles=changed,newObservableTest=newtest,catalogSHA256=sha(r/'catalog.json'),normalAdapterPin='0.4.0',publicationHeld=True)
(frozen/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
shutil.copyfile(prior/'main-preflight.json',r/'reference-preflight-reused.json')
dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent));env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
for role in ['reference','candidate']:
 image=frozen/role;commands=[]
 if role=='candidate':commands.append(('preflight',[str(dotnet),str(image/'Lokad.Lython.Benchmarks.dll'),'--compare','verify','--catalog',str(r/'catalog.json'),'--dotnet',str(dotnet),'--python','C:/Python313/python.exe','--python-worker',str(root/'benchmarks/cpython-worker.py'),'--out',str(r/'candidate-preflight.json')]))
 commands.append(('allocation',[str(dotnet),str(image/'ValidatedAllocation.dll'),str(image),str(r/'catalog.json'),str(r/(role+'-allocation.json'))]))
 for label,cmd in commands:
  with(r/(role+'-'+label+'.log')).open('w',encoding='utf-8')as log:p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
  assert p.returncode==0,(r/(role+'-'+label+'.log')).read_text(encoding='utf-8');print(role,label,'pass',flush=True)
print('Seven-file existing-loop prototype frozen; five actual-worker goldens and both allocation/reuse checks pass:',images['candidate']['Lokad.Lython.dll'],flush=True)
