from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).parent;repo=Path('D:/code/utf8regex');head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
paths=['src/Lokad.Utf8Regex.PythonRe/Utf8PythonRegex.Metadata.cs','src/Lokad.Utf8Regex.PythonRe/Utf8PythonRegex.Cursor.cs','src/Lokad.Utf8Regex.PythonRe/Utf8PythonMatchCursor.cs'];rows=[]
for name in paths:
 blob=subprocess.check_output(['git','show',head+':'+name],cwd=repo);actual=(repo/name).read_bytes()
 rows.append(dict(path=name,committedSHA256=hashlib.sha256(blob).hexdigest(),workingSHA256=hashlib.sha256(actual).hexdigest(),workingTextMatchesCommit=actual.decode('utf-8-sig').replace('\r\n','\n')==blob.decode('utf-8-sig').replace('\r\n','\n')))
assert all(row['workingTextMatchesCommit']for row in rows),rows
v=dict(head=head,readOnly=True,files=rows,findings=['UTF8 name-to-number lookup and pattern copying present; UTF8 group-name enumeration still absent.', 'Cursor MoveNext still links retained creation token with current token.', 'Cursor overload selects working allowance; documentation leaves caller-retained result storage separate, no explicit per-match result/staging allowance.', 'Recent text/scalar-coordinate removals do not close those gaps or require a core change.'],normalAdapterPinUnchanged='0.4.0',immutableDevelopment105QualificationReused=True,newQualification=False,coreRuntimeWorkIndependent=True)
(r/'regex-source-check.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n');print('Read-only producer',head[:8],'facts verified against committed source; no producer change, pin change or qualification.')
