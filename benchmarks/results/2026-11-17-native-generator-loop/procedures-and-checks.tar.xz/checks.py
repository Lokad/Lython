from pathlib import Path
import json,os,subprocess,time
r=Path(__file__).parent;work=Path('D:/code/Lython/.git/agent-worktrees/native-generators-r494')
dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent));env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
classes=['Generator','Native','CursorDispatch','ForHelper','CallablePacketOwnership','HelperLocalLifetime','RepresentativeProtocolCancellation','BuiltinCancellation','FloatArithmeticPipeline','BulkConsumption','SequenceConstructionOwnership']
filt='('+'|'.join('FullyQualifiedName~'+name for name in classes)+')&Category!=Stress'
records=[]
for framework in ['net11.0','net10.0']:
 for name,project in [('internal','Lokad.Lython.Tests'),('public','Lokad.Lython.PublicApi.Tests')]:
  label=name+'-'+framework;cmd=[str(dotnet),'test',f'tests/{project}/{project}.csproj','-c','Release','-f',framework,'--no-build','--filter',filt,'--logger','console;verbosity=minimal']
  start=time.monotonic()
  with(r/(label+'.log')).open('w',encoding='utf-8')as log:p=subprocess.run(cmd,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT)
  records.append(dict(name=label,command=cmd,exitCode=p.returncode,seconds=time.monotonic()-start));(r/'checks.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8',newline='\n')
  output=(r/(label+'.log')).read_text(encoding='utf-8');print(label,output.splitlines()[-1],flush=True)
  assert p.returncode==0,output[-6000:]
