from pathlib import Path
import json,os,subprocess,time
r=Path(__file__).parent;work=Path('D:/code/Lython/.git/agent-worktrees/native-generators-r494');dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe')
env=os.environ.copy();env.update(DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent));env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH'];rows=[]
for framework in ['net11.0','net10.0']:
 name='continuation-'+framework;cmd=[str(dotnet),'test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f',framework,'--no-build','--filter','FullyQualifiedName~BufferedGeneratorContinuationTests','--logger','console;verbosity=minimal'];start=time.monotonic()
 with(r/(name+'.log')).open('w',encoding='utf-8')as log:p=subprocess.run(cmd,cwd=work,env=env,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(name=name,command=cmd,exitCode=p.returncode,seconds=time.monotonic()-start));(r/'continuation-checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
 output=(r/(name+'.log')).read_text(encoding='utf-8');print(name,output.splitlines()[-1],flush=True);assert p.returncode==0,output[-5000:]
