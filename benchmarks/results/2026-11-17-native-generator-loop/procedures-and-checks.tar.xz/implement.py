from pathlib import Path
r=Path('D:/code/Lython/.git/agent-worktrees/native-generators-r494')
p=r/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs'
s=p.read_text(encoding='utf-8')
s=s.replace('internal ref partial struct NativeExecution(PyExecutableFunction function, Span<ExecutableSlot> values, bool consumedByIteration, int unpackedReturnCount)', 'internal ref partial struct NativeExecution')
s=s.replace('private readonly PyExecutableFunction _function = function;', 'private readonly PyExecutableFunction? _function;\n        private readonly ExecutionContext? _frame;')
for old,new in [('Code = function.CodeObject','Code'),('Values = values','Values'),('_cells = function.ClosureCells','_cells'),('_scope = function.DefinitionContext','_scope'),('_consumedByIteration = consumedByIteration','_consumedByIteration'),('_unpackedReturnCount = unpackedReturnCount','_unpackedReturnCount'),('Index = function.CodeObject.EntryIndex','Index'),('LiveExtent = function.CodeObject.FirstTemporarySlot','LiveExtent')]:
 s=s.replace(old+';',new+';')
anchor='        internal bool Run(LythonSourceSpan entrySpan'
position=s.index(anchor)
s=s[:position]+'''        internal NativeExecution(PyExecutableFunction function, Span<ExecutableSlot> values,
            bool consumedByIteration, int unpackedReturnCount)
        {
            _function = function;
            Code = function.CodeObject;
            Values = values;
            _cells = function.ClosureCells;
            _scope = function.DefinitionContext;
            _consumedByIteration = consumedByIteration;
            _unpackedReturnCount = unpackedReturnCount;
            Index = Code.EntryIndex;
            LiveExtent = Code.FirstTemporarySlot;
        }

        // Borrow the generator's already-admitted representation, not a second
        // frame, operand array or owner. Its driver retains cleanup authority.
        internal NativeExecution(ExecutionContext frame)
        {
            _frame = frame;
            Code = frame._execution.Code;
            Values = frame._execution.Stack.Values;
            _cells = frame._execution.ClosureCells ?? [];
            _scope = frame;
            Index = frame._execution.InstructionIndex;
            LiveExtent = frame._execution.Stack.LiveExtent;
        }

''' + s[position:]
s=s.replace('''            while (Index < Code.NativePrefixEnd)
            {
''','''            while (Index < Code.NativePrefixEnd)
            {
                if (_frame is not null && _frame._execution.Stack.HasPendingDisposals) return false;
''')
anchor='''                    case ExecutableOpCode.LoadConst:
'''
s=s.replace(anchor,'''                    case ExecutableOpCode.Yield:
                        if (_frame is null) throw new InvalidOperationException("A generator yield requires its retained frame.");
                        SynchronizeFrame();
                        _frame.ExecuteYield(instruction);
                        Index = _frame._execution.InstructionIndex;
                        LiveExtent = _frame._execution.Stack.LiveExtent;
                        if (!_frame.TryBufferYield()) return false;
                        LiveExtent = _frame._execution.Stack.LiveExtent;
                        continue;
''' + anchor,1)
s=s.replace('var caches = _function.GetLookupCaches(instruction.Span);','var caches = _function is not null ? _function.GetLookupCaches(instruction.Span)\n                                : _frame!._execution.Stack.GetLookupCaches(Code.LookupCacheCount, instruction.Span);')
s=s.replace('''                        var source = Read(instruction.InputStart, 0);
                        if (source is PyStringOps.CasedWhitespaceIteration)
''','''                        var source = Read(instruction.InputStart, 0);
                        if (_frame is not null)
                        {
                            SynchronizeFrame();
                            if (!_frame._execution.Stack.TryPrepareNativeIteration(source,
                                instruction.ResultSlot, instruction.LiveExtent, instruction.Span)) return false;
                            LiveExtent = _frame._execution.Stack.LiveExtent;
                            break;
                        }
                        if (source is PyStringOps.CasedWhitespaceIteration)
''')
old='''                        var next = iterator is PyStringOps.CasedWhitespaceIteration words ? words.MoveNext()
                            : ((PyIteration.Cursor)iterator).TryMoveNext();'''
new='''                        PyIterationResult next;
                        if (_frame is null)
                            next = iterator is PyStringOps.CasedWhitespaceIteration words ? words.MoveNext()
                                : ((PyIteration.Cursor)iterator).TryMoveNext();
                        else if (_frame._execution.Stack.TryAdvanceNativeIteration(instruction.InputStart, out var hasValue, out var item))
                            next = hasValue ? PyIterationResult.Yield(item) : PyIterationResult.End;
                        else if (iterator is PyIteration.Cursor { CanPullWithoutGuestCode: true } cursor)
                            next = cursor.TryMoveNext();
                        else return false; // Decline before any user/async pull starts.'''
assert old in s;s=s.replace(old,new)
anchor='''        private void Trim(int liveExtent)
        {
'''
s=s.replace(anchor,anchor+'''            if (_frame is not null)
            {
                _frame._execution.Stack.RestoreNativeExtent(LiveExtent);
                _frame._execution.Stack.RetireTo(liveExtent);
                LiveExtent = _frame._execution.Stack.LiveExtent;
                return;
            }
''')
anchor='''        internal void PrepareTransfer()
'''
s=s.replace(anchor,'''        private void SynchronizeFrame()
        {
            _frame!._execution.InstructionIndex = Index;
            _frame._execution.Stack.RestoreNativeExtent(LiveExtent);
        }

'''+anchor)
s=s.replace('finally { DisposeValues(); }','finally { if (_frame is null) DisposeValues(); }')
anchor='''        internal void RestoreNativePosition(int index, int liveExtent, LythonRuntimeException? failure)
'''
position=s.index(anchor)
s=s[:position]+'''        // Reuse the existing native loop for an admitted buffered generator.
        // Unknown protocols resume at the same PC; prepared children transfer
        // exactly once into the existing call driver. No background work starts.
        private bool TryExecuteBufferedNative(out InstructionPause pause,
            out ValueTask<ExecutionContext?> nextCall)
        {
            pause = InstructionPause.Continue;
            nextCall = default;
            var code = _execution.Code;
            if (_yieldDestination is null || !code.CanRunNativeInstructions || code.ExceptionRegions.Count != 0
                || MirrorsExecutableLocals || MirrorLocalStores || IsClassBody || IsAnnotationScope || IsTypeParameterScope
                || _preparedCallValue is not null || HasPendingCall || _injectedException is not null
                || _execution.Stack.HasPendingDisposals || _execution.InstructionIndex >= code.Instructions.Length)
                return false;
            var native = new NativeExecution(this);
            bool completed;
            ExecutableSlot value;
            try { completed = native.Run(code.Instructions[native.Index].Span, out value); }
            finally
            {
                _execution.InstructionIndex = native.Index;
                _execution.Stack.RestoreNativeExtent(native.LiveExtent);
                try
                {
                    native.PrepareTransfer();
                    native.TransferOwnership(this);
                }
                finally { native.Dispose(); }
            }
            if (completed) _execution.ReturnValue = value;
            if (TakePreparedNativeChild() is { } child)
            {
                nextCall = new(child);
                pause = InstructionPause.Call;
                return true;
            }
            if (_execution.Stack.HasPendingDisposals)
            {
                pause = InstructionPause.Disposal;
                return true;
            }
            if (completed || HasYield)
            {
                pause = InstructionPause.Boundary;
                return true;
            }
            return false;
        }

''' + s[position:]
p.write_text(s,encoding='utf-8',newline='\n')
p=r/'src/Lokad.Lython/Frontend/ExecutableScript.cs';s=p.read_text(encoding='utf-8')
s=s.replace('or ExecutableOpCode.ReturnNone or ExecutableOpCode.Complete or ExecutableOpCode.Dup or ExecutableOpCode.PopTop;', 'or ExecutableOpCode.ReturnNone or ExecutableOpCode.Complete or ExecutableOpCode.Dup or ExecutableOpCode.PopTop\n        or ExecutableOpCode.Yield;')
p.write_text(s,encoding='utf-8',newline='\n')
p=r/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs';s=p.read_text(encoding='utf-8')
anchor='''            nextCall = default;
            var instructions = execution.Code.Instructions;'''
new='''            nextCall = default;
            if (invocation is not null && invocation.TryExecuteBufferedNative(out var nativePause, out nextCall))
            {
                if (nativePause == InstructionPause.Disposal) pending = new(true); // Native PC already advanced.
                if (nativePause == InstructionPause.Call) pendingSpan = invocation.PendingCallSpan;
                return nativePause;
            }
            var instructions = execution.Code.Instructions;'''
assert anchor in s;s=s.replace(anchor,new)
old='''                            invocation!.YieldValue = execution.Stack.TakeSlotValue(instruction.InputStart, instruction.ResultSlot);
                            invocation!.HasYield = true;
                            invocation!._waitingForSend = true;
                            execution.InstructionIndex++;'''
assert old in s;s=s.replace(old,'''                            invocation.ExecuteYield(instruction);''')
p.write_text(s,encoding='utf-8',newline='\n')
p=r/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.cs';s=p.read_text(encoding='utf-8')
s=s.replace('private bool TryBufferYield(object destination)','internal bool TryBufferYield()')
s=s.replace('''            if (_execution.Stack.HasPendingDisposals) return false;
            if (destination is SumState sum)''','''            var destination = _yieldDestination;
            if (destination is null || _execution.Stack.HasPendingDisposals) return false;
            if (destination is SumState sum)''')
anchor='''        internal void BufferYields(object destination, int limit)
'''
s=s.replace(anchor,'''        internal void ExecuteYield(in ExecutableInstruction instruction)
        {
            YieldValue = _execution.Stack.TakeSlotValue(instruction.InputStart, instruction.ResultSlot);
            HasYield = true;
            _waitingForSend = true;
            _execution.InstructionIndex++;
        }

'''+anchor)
s=s.replace('_yieldDestination is { } destination && HasYield && TryBufferYield(destination)', 'HasYield && TryBufferYield()')
s=s.replace('_yieldDestination is { } destination && TryBufferYield(destination)', 'TryBufferYield()')
p.write_text(s,encoding='utf-8',newline='\n')
p=r/'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Sync.cs';s=p.read_text(encoding='utf-8').replace('_yieldDestination is { } destination && HasYield && TryBufferYield(destination)', 'HasYield && TryBufferYield()');p.write_text(s,encoding='utf-8',newline='\n')
p=r/'src/Lokad.Lython/Runtime/PyIteration.cs';s=p.read_text(encoding='utf-8');anchor='''        internal bool IsBuiltinRange => _value is PyRange && _iterator is null;'''
assert anchor in s;s=s.replace(anchor,anchor+'''

        // This proof precedes the pull. Async/user iteration never starts in a
        // synchronous prefix that might otherwise lose its pending operation.
        internal bool CanPullWithoutGuestCode => _asyncEnumerator is null && (_iterator is null
            ? _value is PyList or PyTuple or PyRange or PyBytes or PyString
            : _iterator is PyEnumerableIterator native && native.CanPullWithoutGuestCode);
''')
p.write_text(s,encoding='utf-8',newline='\n')
p=r/'src/Lokad.Lython/Runtime/PyBuiltinIterators.cs';s=p.read_text(encoding='utf-8');anchor='''    internal int? RemainingHint => _hintSource switch'''
s=s.replace(anchor,'''    internal bool CanPullWithoutGuestCode => _source.CanPullWithoutGuestCode;

'''+anchor)
p.write_text(s,encoding='utf-8',newline='\n')
print('Private existing-loop generator prototype applied; original call ABI, admitted arrays, actual pending children and frame cleanup retained.')
