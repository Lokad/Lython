from pathlib import Path
import ast
r=Path(__file__).parent;parent=r.parent
s=(parent/'prepare-quiet.py').read_text(encoding='utf-8')
s=s.replace("old=r.parent/'json-scalars-r492'","old=r.parent.parent/'json-scalars-r492'")
a=s.index('subjects=[]');b=s.index('assert not set',a)
s=s[:a]+'''subjects=[]
canonical='benchmarks/results/2026-11-17-native-generator-loop/candidate-core.dll.gz'
blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=root);assert blob==(root/canonical).read_bytes();data=gzip.decompress(blob)
subjects.append(dict(kind='superseded-core',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='gzip-payload',committedBlobVerified=True))
for canonical,prefix,members in [('benchmarks/results/2026-11-17-native-generator-loop/confirmation/observations.tgz','native-generator-confirm-b913-20261117',['confirmation/confirmation.json','whole-archive']),('benchmarks/results/2026-11-17-call-packet-lifetimes/observations.tgz','call-packet-lifetimes-b905-20261117',['representative.json'])]:
 blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=root);assert blob==(root/canonical).read_bytes()
 with tarfile.open(fileobj=io.BytesIO(blob))as a:
  for member in members:
   data=blob if member=='whole-archive'else a.extractfile(member).read()
   subjects.append(dict(kind='completed-replica',path=prefix+'/'+('observations.tgz'if member=='whole-archive'else member),bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True))
''' + s[b:]
s=s.replace("subjects[:2]","subjects[:1]")
s=s.replace("sourceRevision='Fully qualified33bd7efd/5e7058a3 versus privateR494/1894be6b on22d5a5f3'","sourceRevision='Fully qualified33bd7efd/5e7058a3 versus refined privateR494 on22d5a5f3; redundant frame reference removed'")
s=s.replace("donor=json.loads((old/'confirm/quiet/config.json').read_text(encoding='utf-8'))","donor=json.loads((r.parent/'confirm/quiet/config.json').read_text(encoding='utf-8'))")
s=s.replace('native-generators-b912-20261117','native-generators-refined-b914-20261117').replace('lython-b912-native-generators-20261117','lython-b914-native-generators-refined-20261117').replace('lython-b912-fixtures','lython-b914-fixtures').replace('B912','B914')
s=s.replace("code=s[a:b].replace('SUBJECTS',repr(subjects))", "code=s[a:b].replace('SUBJECTS',repr(subjects)).replace('json-cpython-b908-20261117','native-generator-confirm-b913-20261117')")
# The retained catalog/protocol lives in the sibling first collection, not here.
s=s.replace("(r/'launch.py').read_text(encoding='utf-8')","(r.parent/'launch.py').read_text(encoding='utf-8')")
(r/'prepare-quiet.py').write_text(s,encoding='utf-8',newline='\n');ast.parse(s)
# All five source jobs remain; no unchanged confirmation is represented as final data.
print('Refined five-job staging prepared from existing collector; original source and both prior conditions retained.')
