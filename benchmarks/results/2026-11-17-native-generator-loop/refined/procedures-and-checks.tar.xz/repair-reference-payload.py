from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;q=r/'quiet'
for name in ['config.json','remote-launch.py','launch.log']:shutil.copyfile(q/name,q/('floor-first-'+name))
# The qualified reference already exists in the donor. Ship only the changed
# candidate; remote staging still hashes all32files and hardlinks immutable aux.
names=['collect.py','archive-owned.py','run.sh','identity.json','candidate/Lokad.Lython.dll']
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for name in names:a.add(q/name,arcname=name)
c=json.loads((q/'config.json').read_text(encoding='utf-8'));c['payloadBytes']=(q/'payload.tgz').stat().st_size;c['payloadSHA256']=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest();c['unpackedBytes']=sum((q/name).stat().st_size for name in names)
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(q/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:];(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
(q/'launch.log').rename(q/'floor-first-launch-refusal.log')
print('Removed unnecessary qualified-reference binary from payload; exact verified donor reused, floors unchanged, original pre-mutation refusal preserved.')
