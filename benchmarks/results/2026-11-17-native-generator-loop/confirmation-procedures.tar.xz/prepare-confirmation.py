from pathlib import Path
import ast,hashlib,io,json,subprocess,tarfile
r=Path(__file__).parent;old=r/'quiet';root=Path('D:/code/Lython');parent=r/'confirm';parent.mkdir(exist_ok=False);q=parent/'quiet';q.mkdir()
prior=json.loads((old/'config.json').read_text(encoding='utf-8'));receipt=json.loads((old/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['jobs']==5 and receipt['allWorkersJoined']and receipt['guestFixturesRemoved']
subjects=[]
for canonical,prefix,raw in [('benchmarks/results/2026-11-17-native-generator-loop/first/observations.tgz','native-generators-b912-20261117',True),('benchmarks/results/2026-11-17-json-scalar-construction/confirmation/observations.tgz','json-scalar-confirm-b911-20261117',False)]:
 blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=root);assert blob==(root/canonical).read_bytes()
 subjects.append(dict(path=prefix+'/observations.tgz',bytes=len(blob),sha256=hashlib.sha256(blob).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='whole-archive',committedBlobVerified=True))
 if raw:
  member='confirmation/confirmation.json'
  with tarfile.open(fileobj=io.BytesIO(blob))as a:data=a.extractfile(member).read()
  subjects.append(dict(path=prefix+'/'+member,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True))
s=(r.parent/'json-scalars-r492/prepare-confirmation.py').read_text(encoding='utf-8');a=s.index("code='''")+len("code='''");b=s.index("'''.replace",a);code=s[a:b].replace('SUBJECTS',repr(subjects))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60);assert p.returncode==0,p.stdout+p.stderr
groups=json.loads(p.stdout);(q/'retirement-proofs.json').write_text(json.dumps(groups,indent=2)+'\n',encoding='utf-8',newline='\n')
remote='/home/lokad/lython-bench-checks/native-generator-confirm-b913-20261117'
identity=dict(prior['identity']);identity['purpose']='Bounded unchanged-image/catalog confirmation: first fresh candidate3.40%, helper reference8.03%, call-control candidate13.56%spreads. Preserve original adverse results; three affected/control jobs with8second rotated warmups/five rounds, no source change or promotion.'
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
jobs=[['scripts.numeric-squared-error.floating.large','compile-run'],['scripts.json-summary-helpers.large','warm'],['calls.positional.large','warm']]
s=(old/'collect.py').read_text(encoding='utf-8');a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==3 and all(case in cases for case,lane in jobs)\n'+s[b:];s=s.replace('while min(warmed)<6:','while min(warmed)<8:').replace('if warmed[i]>=6:continue','if warmed[i]>=8:continue');(q/'collect.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'archive-owned.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==5","len(raw['jobs'])==3").replace('jobs=5','jobs=3');(q/'archive-owned.py').write_text(s,encoding='utf-8',newline='\n')
(q/'run.sh').write_text((old/'run.sh').read_text(encoding='utf-8').replace(prior['root'],remote),encoding='utf-8',newline='\n')
names=['identity.json','collect.py','archive-owned.py','run.sh']
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for name in names:a.add(q/name,arcname=name)
c=dict(root=remote,unit='lython-b913-native-generator-confirm-20261117',source=prior['root'],sourceRole='reference',sourceFiles=identity['imageFiles']['reference'],sourceCatalogSHA256=prior['catalogSHA256'],catalogSHA256=prior['catalogSHA256'],identity=identity,retireGroups=groups,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum((q/name).stat().st_size for name in names));(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:]
needle=" for n,h in c['sourceFiles'].items():assert sha(source/c['sourceRole']/n)==h,n";assert needle in s;s=s.replace(needle," for role,files in c['identity']['imageFiles'].items():\n  for n,h in files.items():assert sha(source/role/n)==h,(role,n)")
needle="if not p.exists():os.link(source/c['sourceRole']/n,p)";assert needle in s;s=s.replace(needle,"if not p.exists():os.link(source/role/n,p)")
s=s.replace('lython-b912-fixtures','lython-b913-fixtures').replace('RuntimeMaxSec=300','RuntimeMaxSec=240');(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(r/'launch.py').read_text(encoding='utf-8').replace('seconds=230','seconds=190').replace('before230seconds','before190seconds').replace('Five-job existing-loop generator comparison','Three-job unchanged-image generator confirmation');(parent/'launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'retrieve.py').read_text(encoding='utf-8').replace("['jobs']==5","['jobs']==3").replace('B912','B913');(q/'retrieve.py').write_text(s,encoding='utf-8',newline='\n')
s=(r/'summarize.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==5","len(raw['jobs'])==3").replace("r/'reference-allocation.json'","r.parent/'reference-allocation.json'").replace("r/'candidate-allocation.json'","r.parent/'candidate-allocation.json'");(parent/'summarize.py').write_text(s,encoding='utf-8',newline='\n')
for p in list(q.glob('*.py'))+list(parent.glob('*.py')):ast.parse(p.read_text(encoding='utf-8'))
print('Three affected/control jobs prepared with unchanged images/catalog and8second warmup. Original adversity preserved; exact committed working replicas only, current qualified/candidate cores and primary catalog preserved.')
