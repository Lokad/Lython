from pathlib import Path
import json,shutil,tarfile
r=Path(__file__).parent;root=Path('D:/code/Lython');dest=root/'benchmarks/results/2026-11-17-native-generator-loop';out=dest/'confirmation';out.mkdir(exist_ok=False)
for name in ['summary.json','allocation-summary.json']:shutil.copyfile(r/'confirm'/name,out/name)
for name in ['archive-receipt.json','terminal-status.json','observations.tgz','identity.json']:shutil.copyfile(r/'confirm/quiet'/name,out/name)
shutil.copyfile(r/'baseline-continuation.json',dest/'baseline-continuation.json')
with tarfile.open(dest/'confirmation-procedures.tar.xz','w:xz')as a:
 for p in sorted(r.rglob('*')):
  if not p.is_file():continue
  n=p.relative_to(r)
  if {'retrieved','frozen','candidate','reference'}&set(n.parts)or any(part.startswith('baseline-continuation-image')for part in n.parts)or n.name in ['payload.tgz','observations.tgz','candidate-sources.tar.xz']:continue
  a.add(p,arcname=n.as_posix())
p=dest/'README.md';s=p.read_text(encoding='utf-8')+'''
## B913 confirmation; final footprint refinement selected

Same images/catalog,8second rotated warmups/five rounds, three jobs140.85seconds.
Floating fresh−4.89..−2.09%/CPU−2.97..−1.80%, controls0.48/2.46%; call control
−0.90..−0.05%/CPU−2.02..−0.40%, controls0.43/0.43%. Helper JSON remains uncertain:
−3.58..+3.44%/CPU−4.26..+3.70%, controls2.10/5.08%. Preserve original fresh/control
adversity; improved confirmation does not explain the original13.56%process gap.
No extra unchanged timing campaign is selected. All gates/usersjoined/SHAarchive
pass, terminal cached. Original allocation diagnostics reused, not new measurements.

The same7new semantic/effect/alias/refusal/held-cleanup/reuse assertions also pass
against qualified5e7058a3 in a copied test image: tests do not require this internal
architecture. The first baseline diagnostic mistyped a hardcoded checksum and
refused before testing; repaired by checking both recorded manifests. Mutable
build outputs untouched; original failed script preserved.

One final source simplification before promotion: borrowed mode's existing scope
already references its generator frame, so a separate NativeExecution frame field
is redundant. Reuse that scope when function owner is null, retaining ordinary
call ABI, existing owner lifetimes and exact resume. This removes one stored
reference; it is not proven to explain the first control variation. Focused11/10
checks and one changed-footprint affected pair decide final retention/regression
debt. The current measured footprint is not promoted or permanently rejected.
No final CPU result is attributed to the not-yet-measured refinement.

[Confirmation](confirmation/summary.json),[raw](confirmation/observations.tgz),
[baseline semantics](baseline-continuation.json),[procedures](confirmation-procedures.tar.xz).
Full R492 delivery remains GREEN; broader work/publication hold continue.
''';p.write_text(s,encoding='utf-8',newline='\n')
p=root/'benchmarks/EXPERIMENTS.md'
with p.open('a',encoding='utf-8',newline='\n')as log:log.write('\nR494/B913 [unchanged-image confirmation](results/2026-11-17-native-generator-loop/README.md): three jobs140.85s/8secondwarmups. Floatingfresh−4.89..−2.09%/CPU−2.97..−1.80%; callcontrol−0.90..−0.05% with0.43/0.43%controls; helperstilluncertain/candidate5.08%spread. Original fresh/control adversity remains unexplained/preserved. Seven new external regressions also pass qualifiedbaseline5e7. Before promotion remove redundant native-view frame reference: borrowed scope already is that frame, function-owner null identifies mode. No asserted causal explanation or final-refinement CPU claim; focused11/10 and one changed-source affected pair next. All gates/join/archive pass, no further unchanged campaign. Publicationheld/objectiveactive.\n')
print('Confirmation, independent baseline semantics and original adversity preserved; one redundant-reference refinement selected, no promotion.')
