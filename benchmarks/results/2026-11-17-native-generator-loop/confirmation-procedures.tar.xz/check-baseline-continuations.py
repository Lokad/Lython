from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
r=Path(__file__).parent;work=Path('D:/code/Lython/.git/agent-worktrees/native-generators-r494');source=work/'tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0';image=r/'baseline-continuation-image-final';image.mkdir(exist_ok=False)
for p in source.iterdir():
 if p.is_file():shutil.copyfile(p,image/p.name)
baseline=r.parent/'json-scalars-r492/main-frozen/Lokad.Lython.dll';expected=json.loads((r.parent/'json-scalars-r492/main-frozen-identity.json').read_text(encoding='utf-8'))['coreSHA256'];assert expected==json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))['imageFiles']['reference']['Lokad.Lython.dll'];assert hashlib.sha256(baseline.read_bytes()).hexdigest()==expected
shutil.copyfile(baseline,image/'Lokad.Lython.dll')
dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent));env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
cmd=[str(dotnet),'vstest',str(image/'Lokad.Lython.PublicApi.Tests.dll'),'--TestCaseFilter:FullyQualifiedName~BufferedGeneratorContinuationTests','--logger:console;verbosity=minimal'];start=time.monotonic()
with(r/'baseline-continuation.log').open('w',encoding='utf-8')as log:p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
v=dict(runtimeSource='Fully qualified33bd7efd/frozen5e7058a3',testSource='Current held-cleanup BufferedGeneratorContinuationTests; same binary as private candidate check',copiedTopLevelTestImage=True,mutableBuildOutputsUntouched=True,coreSHA256=hashlib.sha256((image/'Lokad.Lython.dll').read_bytes()).hexdigest(),testAssemblySHA256=hashlib.sha256((image/'Lokad.Lython.PublicApi.Tests.dll').read_bytes()).hexdigest(),command=cmd,exitCode=p.returncode,seconds=time.monotonic()-start,scope='Seven external semantic/effect/alias/refusal/held-cleanup/reuse assertions only; not full baseline requalification.')
(r/'baseline-continuation.json').write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
output=(r/'baseline-continuation.log').read_text(encoding='utf-8');print(output.splitlines()[-1],flush=True);assert p.returncode==0,output[-4500:]
