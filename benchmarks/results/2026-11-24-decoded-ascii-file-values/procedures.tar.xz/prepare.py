from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
tree=repo/'.git/agent-worktrees/decoded-ascii-file-values-20261124'
donor=lab.with_name('regex-flag-continuations-20261124')
comparison=lab/'comparison'
comparison.mkdir(exist_ok=True)


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path,value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')


metadata=read(donor/'comparison/identity.json')
reference=subprocess.check_output(['git','rev-parse','f01360b7f'],cwd=tree,text=True).strip()
subprocess.run(['git','diff','--exit-code',reference,'f01360b7f','--','src','tests'],cwd=tree,check=True)
subprocess.run(['git','merge-base','--is-ancestor',reference,'HEAD'],cwd=tree,check=True)
assert not subprocess.check_output(['git','status','--porcelain','--','src','tests'],cwd=tree)
candidate=subprocess.check_output(['git','rev-parse','HEAD'],cwd=tree,text=True).strip()
assert candidate!=reference
original=lab.with_name('cased-empty-iteration-20261124')/'comparison'
representative=comparison/'representative.json'
catalog=read(original/'representative.json')
distinct=read(lab.with_name('borrowed-cased-words-refined-20261123')/'comparison/representative.json')
unique,=[case for case in distinct['cases'] if case['id']=='diagnostic.text-summary.borrowed-cased-words.unique-medium']
catalog['cases'].insert(3,unique)
assert len(catalog['cases'])==5
save(representative,catalog)
save(comparison/'jobs.json',{'warm':[[c['id'],'warm'] for c in catalog['cases']]})
files=metadata['imageFiles']['candidate']
runtime=Path.home()/'.dotnet11'
dotnet=runtime/'dotnet.exe'
protocol=repo/'benchmarks/cpython-worker.py'
assert digest(protocol)==metadata['cpythonWorkerSHA256']
env=dict(os.environ,DOTNET_ROOT=str(runtime),DOTNET_ROOT_X64=str(runtime))
assert len(files)==32 and all(digest(donor/'candidate'/name)==expected for name,expected in files.items())
core='Lokad.Lython.dll'
images={}
helpers={}
for role in ('reference','candidate'):
    image=lab/role
    image.mkdir(exist_ok=True)
    for name in files:
        if name==core:
            build='frozen' if role=='candidate' else 'reference-build'
            source=lab/build/'bin/Lokad.Lython/release_net11.0'/core
        else: source=donor/'candidate'/name
        shutil.copyfile(source,image/name)
    for suffix in ('.dll','.deps.json','.runtimeconfig.json'):
        helper='ValidatedAllocation'+suffix
        shutil.copyfile(donor/'candidate'/helper,image/helper)
        helpers[helper]=digest(image/helper)
    observed={name:digest(image/name) for name in files}
    result=comparison/(role+'-verify.json')
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',
        representative,'--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',
        protocol,'--out',result],env=env,check=True,timeout=90)
    proof=read(result)
    assert proof['state']=='Completed' and proof['caseCount']==5 and proof['launched']['library']['sha256']==observed[core]
    assert all(digest(image/name)==expected for name,expected in observed.items())
    assert all(digest(image/name)==expected for name,expected in helpers.items())
    images[role]=observed
assert all(files[name]==images['reference'][name] for name in files if name!=core)
assert [name for name in files if images['reference'][name]!=images['candidate'][name]]==[core]
save(comparison/'identity.json',dict(sourceRevision=reference,candidate=candidate,
    purpose='B1580 reuse existing immutable ASCII values in decoded text reads',
    imageFiles=images,helperFiles=helpers,cpythonWorkerSHA256=metadata['cpythonWorkerSHA256'],
    expectedCPythonSHA256=metadata['expectedCPythonSHA256'],
    catalogs={name:dict(sha256=digest(comparison/name)) for name in ('representative.json','jobs.json')},
    coreSHA256={label:images[role][core] for role in images for label in (role,role+'-control')}))
shutil.copyfile(donor/'allocations.py',lab/'allocations.py')
