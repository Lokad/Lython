from pathlib import Path
import concurrent.futures, hashlib, json, os, re, subprocess
lab=Path(__file__).resolve().parent
initial=lab.parent/"native-direct-integer-return-20261122"
def read(path):return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
base=read(lab/"representative.json")
wanted={"diagnostic.helper-placement.function-call","scripts.csv-invoice.helper-accumulation"}
base["cases"]=[c for c in base["cases"] if c["id"] in wanted]
catalog=lab/"codegen-catalog.json"
catalog.write_text(json.dumps(base,indent=2)+"\n",encoding="utf-8",newline="\n")
identity=read(lab/"identity.json")
initial_identity=read(initial/"identity.json")
sdk=Path.home()/".dotnet11"
methods=("PyExecutableFunction:StartNativeCall(","PyExecutableFunction:StartNativeCallWithWorkspace(",
         "PyExecutableFunction:TryStartDirectIntegerReturn(")
def sample(item):
    role, image, expected = item
    assert len(expected)==32 and {name:sha(image/name) for name in expected}==expected
    output=lab/f"{role}-codegen.txt"
    env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"],
        DOTNET_TieredCompilation="0",DOTNET_JitDisasm="*StartNativeCall* *TryStartDirectIntegerReturn*",
        DOTNET_JitStdOutFile=str(output))
    receipt=lab/f"{role}-codegen-allocation.json"
    subprocess.run([sdk/"dotnet.exe",image/"ValidatedAllocation.dll",image,catalog,receipt],env=env,timeout=95,check=True)
    assert all(r["sharedBudgetBaselineRestored"] for r in read(receipt)["rows"])
    code={}
    for segment in output.read_text(encoding="utf-8").split("; Assembly listing for method ")[1:]:
        method=next((m for m in methods if m in segment.splitlines()[0]),None)
        if method:
            size=re.search(r"; Total bytes of code (\d+)",segment)
            assert size
            frame = re.search(r"(?m)^\s*sub\s+rsp,\s*(\d+)",segment)
            code[method[:-1]]=dict(codeBytes=int(size.group(1)),reservedStackBytes=int(frame.group(1)) if frame else 0)
    assert "PyExecutableFunction:StartNativeCall" in code,code
    return role,code
jobs=[("reference",lab/"frozen/reference",identity["imageFiles"]["reference"]),
      ("initial",initial/"frozen/candidate",initial_identity["imageFiles"]["candidate"]),
      ("refined",lab/"frozen/candidate",identity["imageFiles"]["candidate"])]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    result=dict(pool.map(sample,jobs))
record=dict(platform="Windows x64", normalTiering=False, sizes=result)
(lab/"codegen-summary.json").write_text(json.dumps(record,indent=2)+"\n",encoding="utf-8",newline="\n")
print(json.dumps(record,indent=2))
