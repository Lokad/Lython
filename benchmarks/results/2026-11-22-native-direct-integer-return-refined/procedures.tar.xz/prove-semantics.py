from pathlib import Path
import copy,hashlib,json,os,subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
template=json.loads((lab/"representative.json").read_text(encoding="utf-8"))
seed=template["cases"][4]
scripts=[
    ("entire-chain", """def f(a,b,c):return a+b*c
def run(a,b,c):return f(a,b,c)
print(f(2,3,4),run(2,3,4),run(-2,5,-6))
"""),
    ("promotion", """def f(a,b,c):return (a+b)*c
def run(a,b,c):return f(a,b,c)
for a,b,c in [(9223372036854775807,1,-2), (9223372036854775806,1,2), (-9223372036854775808,-1,2)]:
    print(run(a,b,c))
"""),
    ("division-error", """def f(a,b,c):return (a+b)//c
def run(a,b,c):return f(a,b,c)
try:
    raise ValueError('outer')
except ValueError as outer:
    try: run(10,2,0)
    except ZeroDivisionError as error: print(str(error),error.__context__ is outer)
print(run(-10,2,-3),run(-9223372036854775808,0,-1))
"""),
    ("protocols-once", """events=[]
class Scale:
    def __rmul__(self,left):
        events.append(('mul',left))
        return left+20
class Offset:
    def __radd__(self,left):
        events.append(('add',left))
        return left+30
def f(a,b,c):return (a+b)*c
def run(a,b,c):return f(a,b,c)
print(f(2,3,4),run(2,Offset(),Scale()),run(3,4,Scale()),events)
"""),
    ("persistent-lookup", """factor=2
def apply(a,b):return (a+b)*factor
def run(a,b):return apply(a,b)
print(run(4,5))
factor=3
print(run(4,5))
"""),
    ("recursive-call", """def combine(a,b,c):return (a+b)*c
def run(n):
    if n==0:return combine(2,3,4)
    return combine(run(n-1),1,1)
print(run(128))
"""),
]
def sha(contents):return hashlib.sha256(contents.encode("utf-8")).hexdigest()
python="C:/Python313/python.exe"
cases=[]
fixture='{"size":1,"text":null}'
for label,source in scripts:
    oracle=subprocess.run([python,"-I","-S","-X","utf8","-"],input=source,text=True,
        encoding="utf-8",capture_output=True,timeout=12,check=True)
    assert not oracle.stderr and oracle.stdout
    case=copy.deepcopy(seed)
    case.update(id="diagnostic.direct-integer-return."+label,size=1,source=source,sourceUtf8Bytes=len(source.encode("utf-8")),
        sourceSha256=sha(source),fixtureJson=fixture,fixtureSha256=sha(fixture),expectedOutput=oracle.stdout,
        expectedOutputUtf8Bytes=len(oracle.stdout.encode("utf-8")),expectedOutputSha256=sha(oracle.stdout))
    cases.append(case)
manifest=lab/"semantics.json"
manifest.write_text(json.dumps(dict(template,cases=cases),indent=2)+"\n",encoding="utf-8",newline="\n")
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
id=json.loads((lab/"identity.json").read_text(encoding="utf-8"))
for role,files in id["imageFiles"].items():
    image=lab/"frozen"/role
    assert len(files)==32 and {n:hashlib.sha256((image/n).read_bytes()).hexdigest() for n in files}==files
    verify=lab/f"{role}-semantics-verify.json"
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",manifest,
        "--dotnet",dotnet,"--python",python,"--python-worker",repo/"benchmarks/cpython-worker.py","--out",verify],
        env=env,timeout=95,check=True)
    proof=json.loads(verify.read_text(encoding="utf-8"))
    assert proof["state"]=="Completed" and proof["caseCount"]==len(scripts)
    assert proof["catalogSha256"]==hashlib.sha256(manifest.read_bytes()).hexdigest()
print("Exact images match six independent Python goldens, including wide promotion, protocol effects, exception context and nested calls.")
