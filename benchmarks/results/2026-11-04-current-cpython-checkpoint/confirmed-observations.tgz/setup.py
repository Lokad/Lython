from pathlib import Path
import json,hashlib
root=Path("/home/lokad/lython-bench-checks/coupled-cpython-b195-20261104/confirmation-check")
(root/'candidate').symlink_to('/home/lokad/lython-bench-checks/fixed-text-construction-b194-20261104/final/candidate',target_is_directory=True)
(root/'baseline').symlink_to('/home/lokad/lython-bench-checks/combined-storage-checkpoint-b184-20261103/baseline',target_is_directory=True)
d=json.loads((root/'identity.json').read_text())
for label,folder in [('candidate','candidate'),('before-control','baseline'),('after-control','baseline')]:
 assert hashlib.sha256((root/folder/'Lokad.Lython.dll').read_bytes()).hexdigest()==d['coreSHA256'][label]
