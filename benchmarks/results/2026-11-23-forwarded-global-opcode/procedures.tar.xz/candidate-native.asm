; Assembly listing for method Lokad.Lython.Frontend.ExecutableInstruction:Call(int,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Frontend.ExecutableInstruction (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 96
       lea      rbp, [rsp+0x60]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0x20], ymm4
       mov      qword ptr [rbp+0x10], rcx
       mov      dword ptr [rbp+0x18], edx
       mov      gword ptr [rbp+0x20], r8
 
G_M000_IG02:                ;; offset=0x001E
       mov      dword ptr [rsp+0x20], 0x7FFFFFFF
       mov      dword ptr [rsp+0x28], 0x7FFFFFFF
       mov      dword ptr [rsp+0x30], -1
       xor      eax, eax
       mov      dword ptr [rsp+0x38], eax
       lea      rcx, [rbp-0x20]
       mov      r9d, dword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      edx, 42
       call     [Lokad.Lython.Frontend.ExecutableInstruction:.ctor(int,Lokad.Lython.LythonSourceSpan,int,int,int,int,int):this]
       mov      rax, qword ptr [rbp+0x10]
 
G_M000_IG03:                ;; offset=0x0057
       vmovdqu  ymm0, ymmword ptr [rbp-0x20]
       vmovdqu  ymmword ptr [rax], ymm0
 
G_M000_IG04:                ;; offset=0x0060
       mov      rax, qword ptr [rbp+0x10]
 
G_M000_IG05:                ;; offset=0x0064
       vzeroupper 
       add      rsp, 96
       pop      rbp
       ret      
 
; Total bytes of code 109

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInstructionPrefix(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref,byref,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 0xC00
       lea      rbp, [rsp+0xC00]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0xBC0], xmm4
       mov      rax, -0xB70
 
G_M000_IG254:                ;; offset=0x0026
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG254
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      dword ptr [rbp+0x28], r9d
 
G_M000_IG02:                ;; offset=0x0052
       mov      dword ptr [rbp-0x674], 0x3E8
       mov      rax, bword ptr [rbp+0x30]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      rax, bword ptr [rbp+0x38]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
       mov      rax, bword ptr [rbp+0x40]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      qword ptr [rax+0x10], rcx
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      gword ptr [rbp-0x40], rax
       jmp      G_M000_IG235
 
G_M000_IG03:                ;; offset=0x009B
       xor      eax, eax
       mov      dword ptr [rbp-0x44], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x10]
       mov      rcx, gword ptr [rbp-0x40]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG241
       mov      edx, eax
       imul     rdx, rdx, 32
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x58], rcx
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x680], rax
       mov      rdx, gword ptr [rbp-0x680]
       mov      rcx, gword ptr [rbp-0x1C8]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG04:                ;; offset=0x00FE
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0xE4], eax
       cmp      dword ptr [rbp-0xE4], 73
       ja       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0117
       mov      eax, dword ptr [rbp-0xE4]
       lea      rcx, [reloc @RWD00]
       mov      ecx, dword ptr [rcx+4*rax]
       lea      rdx, G_M000_IG02
       add      rcx, rdx
       jmp      rcx
 
G_M000_IG06:                ;; offset=0x0133
       jmp      G_M000_IG221
 
G_M000_IG07:                ;; offset=0x0138
       mov      rcx, 0x7FF9D77EA980
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG239
 
G_M000_IG08:                ;; offset=0x0156
       mov      rcx, 0x7FF9D77EA984
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x5F0], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x5F8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x5FC], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x688], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x688]
       mov      rdx, gword ptr [rbp-0x5F8]
       mov      r8d, dword ptr [rbp-0x5FC]
       mov      rcx, gword ptr [rbp-0x5F0]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadLocal(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x690], rax
       mov      r9, gword ptr [rbp-0x690]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG225
 
G_M000_IG09:                ;; offset=0x01F3
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x218], rax
       mov      rax, gword ptr [rbp-0x218]
       mov      gword ptr [rbp-0xBC0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      rdx, gword ptr [rbp-0xBC0]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG224
       mov      ecx, eax
       imul     rcx, rcx, 16
       lea      rcx, bword ptr [rdx+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_IsUnassigned():bool:this]
       test     eax, eax
       je       G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0243
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_LocalNames():System.Collections.Generic.IReadOnlyList`1[System.String]:this]
       mov      gword ptr [rbp-0x220], rax
       mov      rax, gword ptr [rbp-0x220]
       mov      gword ptr [rbp-0x648], rax
       mov      rcx, gword ptr [rbp-0x648]
       mov      rdx, 0x7FF9D77EA988
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x648]
       mov      gword ptr [rbp-0x698], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x69C], eax
       mov      rcx, gword ptr [rbp-0x698]
       mov      edx, dword ptr [rbp-0x69C]
       mov      r11, 0x7FF9D7091A40
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x228], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x6A8], rax
       mov      rdx, gword ptr [rbp-0x6A8]
       mov      rcx, gword ptr [rbp-0x228]
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG11:                ;; offset=0x02EA
       mov      rcx, 0x7FF9D77EAA90
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG225
 
G_M000_IG12:                ;; offset=0x02FE
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       jne      G_M000_IG14
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x5D0], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x5D8], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x10]
       mov      dword ptr [rbp-0x5DC], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x6AC], eax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9d, dword ptr [rbp-0x6AC]
       mov      rdx, gword ptr [rbp-0x5D8]
       mov      r8d, dword ptr [rbp-0x5DC]
       mov      rcx, gword ptr [rbp-0x5D0]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       je       SHORT G_M000_IG13
       mov      rcx, 0x7FF9D77EAA94
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 16
       mov      bword ptr [rbp-0x5E8], rax
       mov      rax, bword ptr [rbp-0x5E8]
       add      dword ptr [rax], 2
       jmp      G_M000_IG225
 
G_M000_IG13:                ;; offset=0x03C0
       mov      rcx, 0x7FF9D77EAA98
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG14:                ;; offset=0x03CF
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      dword ptr [rbp-0x5C8], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x6B8], rax
       lea      rax, [rbp-0x60]
       mov      qword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x6B8]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8d, dword ptr [rbp-0x5C8]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryLoadClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG15
       mov      rcx, 0x7FF9D77EAA9C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG15:                ;; offset=0x0437
       mov      rcx, 0x7FF9D77EAAA0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      r9, gword ptr [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG225
 
G_M000_IG16:                ;; offset=0x0461
       mov      rcx, 0x7FF9D77EAAA4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:StoreExecutableLocal(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG225
 
G_M000_IG17:                ;; offset=0x048B
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryStoreClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG18
       mov      rcx, 0x7FF9D77EAAA8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG18:                ;; offset=0x04BF
       mov      rcx, 0x7FF9D77EAAAC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG225
 
G_M000_IG19:                ;; offset=0x04D3
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG20
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG20:                ;; offset=0x04E9
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG23
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG21:                ;; offset=0x04F5
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x6D8], ymm0
 
G_M000_IG22:                ;; offset=0x0501
       lea      r8, [rbp-0x6D8]
       lea      rdx, [rbp-0xF8]
       mov      rcx, gword ptr [rbp+0x20]
       xor      r9d, r9d
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rdx, [rbp-0x108]
       lea      rcx, [rbp-0xF8]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter:GetResult():this]
       jmp      G_M000_IG225
 
G_M000_IG23:                ;; offset=0x0544
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG24:                ;; offset=0x0548
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x6F8], ymm0
 
G_M000_IG25:                ;; offset=0x0554
       lea      r8, [rbp-0x6F8]
       lea      rdx, [rbp-0x588]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r9d, 1
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG26:                ;; offset=0x0574
       vmovdqu  xmm0, xmmword ptr [rbp-0x588]
       vmovdqu  xmmword ptr [rbp-0x708], xmm0
 
G_M000_IG27:                ;; offset=0x0584
       lea      rdx, [rbp-0x708]
       lea      rcx, [rbp-0x598]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB38], rax
       mov      rcx, bword ptr [rbp-0xB38]
       mov      rdx, gword ptr [rbp-0x598]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB38]
       mov      rcx, qword ptr [rbp-0x590]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG28
       mov      rcx, 0x7FF9D77EAAB0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x710], rax
       mov      rcx, gword ptr [rbp-0x710]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG239
 
G_M000_IG28:                ;; offset=0x0612
       mov      rcx, 0x7FF9D77EAAB4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG225
 
G_M000_IG29:                ;; offset=0x0630
       mov      rax, bword ptr [rbp+0x10]
       mov      bword ptr [rbp-0x2F0], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x2F8], rax
       mov      rax, bword ptr [rbp-0x58]
       mov      bword ptr [rbp-0x300], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x308], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG30
       mov      rcx, 0x7FF9D77EAAB8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x308], rax
 
G_M000_IG30:                ;; offset=0x067D
       mov      rcx, bword ptr [rbp-0x2F0]
       mov      rdx, gword ptr [rbp-0x2F8]
       mov      r8, bword ptr [rbp-0x300]
       mov      r9, gword ptr [rbp-0x308]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteFormattedInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      SHORT G_M000_IG31
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG32
       mov      rcx, 0x7FF9D77EAABC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG31:                ;; offset=0x06C8
       mov      rcx, 0x7FF9D77EAAC0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG225
 
G_M000_IG32:                ;; offset=0x06DC
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG35
       mov      rcx, 0x7FF9D77EAAC4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG33:                ;; offset=0x06F7
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x730], ymm0
 
G_M000_IG34:                ;; offset=0x0703
       lea      r8, [rbp-0x730]
       lea      rdx, [rbp-0xF8]
       mov      rcx, gword ptr [rbp+0x20]
       xor      r9d, r9d
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rdx, [rbp-0x108]
       lea      rcx, [rbp-0xF8]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter:GetResult():this]
       jmp      G_M000_IG225
 
G_M000_IG35:                ;; offset=0x0746
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG36:                ;; offset=0x074A
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x750], ymm0
 
G_M000_IG37:                ;; offset=0x0756
       lea      r8, [rbp-0x750]
       lea      rdx, [rbp-0x318]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r9d, 1
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG38:                ;; offset=0x0776
       vmovdqu  xmm0, xmmword ptr [rbp-0x318]
       vmovdqu  xmmword ptr [rbp-0x760], xmm0
 
G_M000_IG39:                ;; offset=0x0786
       lea      rdx, [rbp-0x760]
       lea      rcx, [rbp-0x328]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB40], rax
       mov      rcx, bword ptr [rbp-0xB40]
       mov      rdx, gword ptr [rbp-0x328]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB40]
       mov      rcx, qword ptr [rbp-0x320]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG40
       mov      rcx, 0x7FF9D77EAAC8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x768], rax
       mov      rcx, gword ptr [rbp-0x768]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG239
 
G_M000_IG40:                ;; offset=0x0814
       mov      rcx, 0x7FF9D77EAACC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG225
 
G_M000_IG41:                ;; offset=0x0832
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x270], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rcx, gword ptr [rbp-0x270]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG224
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x770], rax
       mov      rdx, gword ptr [rbp-0x770]
       mov      rcx, 0x7FF9D758EAB0
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0x278], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x280], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x284], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x288], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      ecx, dword ptr [rbp-0x288]
       sub      ecx, eax
       mov      dword ptr [rbp-0x774], ecx
       mov      r9d, dword ptr [rbp-0x774]
       lea      rcx, [rbp-0x298]
       mov      rdx, gword ptr [rbp-0x280]
       mov      r8d, dword ptr [rbp-0x284]
       call     [System.MemoryExtensions:AsSpan[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rax, gword ptr [rbp-0x278]
       mov      gword ptr [rbp-0x2A0], rax
 
G_M000_IG42:                ;; offset=0x0914
       vmovdqu  xmm0, xmmword ptr [rbp-0x298]
       vmovdqu  xmmword ptr [rbp-0x2B0], xmm0
 
G_M000_IG43:                ;; offset=0x0924
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_StartsKeywordDefaultsOnly():bool:this]
       mov      dword ptr [rbp-0x2B4], eax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x2C0], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG44
       mov      rcx, 0x7FF9D77EAAD0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x2C0], rax
 
G_M000_IG44:                ;; offset=0x0960
       mov      rcx, 0x7FF9D77EAAD4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG45:                ;; offset=0x096F
       vmovdqu  xmm0, xmmword ptr [rbp-0x2B0]
       vmovdqu  xmmword ptr [rbp-0x788], xmm0
 
G_M000_IG46:                ;; offset=0x097F
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x790], rax
       mov      rax, gword ptr [rbp-0x790]
       mov      gword ptr [rsp+0x20], rax
       lea      rdx, [rbp-0x788]
       mov      r8d, dword ptr [rbp-0x2B4]
       mov      r9, gword ptr [rbp-0x2C0]
       mov      rcx, gword ptr [rbp-0x2A0]
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x2C8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x794], eax
       mov      edx, dword ptr [rbp-0x794]
       mov      rcx, bword ptr [rbp-0x2C8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RestoreNativeExtent(int):this]
       jmp      G_M000_IG225
 
G_M000_IG47:                ;; offset=0x09FB
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x230], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x234], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x798], eax
       mov      r9d, dword ptr [rbp-0x798]
       lea      rdx, [rbp-0x70]
       mov      r8d, dword ptr [rbp-0x234]
       mov      rcx, bword ptr [rbp-0x230]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x7A0], rax
       mov      rdx, gword ptr [rbp-0x7A0]
       lea      rcx, [rbp-0x248]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rax, bword ptr [rbp-0x58]
       mov      bword ptr [rbp-0x250], rax
 
G_M000_IG48:                ;; offset=0x0A89
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0x260], xmm0
 
G_M000_IG49:                ;; offset=0x0A96
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x268], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG50
       mov      rcx, 0x7FF9D77EAAD8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x268], rax
 
G_M000_IG50:                ;; offset=0x0AC2
       mov      rcx, 0x7FF9D77EAADC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG51:                ;; offset=0x0AD1
       vmovdqu  xmm0, xmmword ptr [rbp-0x248]
       vmovdqu  xmmword ptr [rbp-0x7B0], xmm0
 
G_M000_IG52:                ;; offset=0x0AE1
       vmovdqu  xmm0, xmmword ptr [rbp-0x260]
       vmovdqu  xmmword ptr [rbp-0x7C0], xmm0
 
G_M000_IG53:                ;; offset=0x0AF1
       mov      rcx, gword ptr [rbp-0x268]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x7C8], rax
       mov      r9, gword ptr [rbp-0x7C8]
       lea      r8, [rbp-0x7C0]
       lea      rcx, [rbp-0x7B0]
       mov      rdx, bword ptr [rbp-0x250]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG225
 
G_M000_IG54:                ;; offset=0x0B2E
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       lea      rax, [rbp-0x80]
       mov      qword ptr [rsp+0x28], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecutePreparedOperation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG55
       mov      rcx, 0x7FF9D77EAAE0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG55:                ;; offset=0x0B77
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG56
       mov      rcx, 0x7FF9D77EAAE4
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdx, [rbp-0x108]
       lea      rcx, [rbp-0x80]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter:GetResult():this]
       jmp      G_M000_IG225
 
G_M000_IG56:                ;; offset=0x0BB1
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0x7D8], xmm0
 
G_M000_IG57:                ;; offset=0x0BBE
       lea      rdx, [rbp-0x7D8]
       lea      rcx, [rbp-0x5A8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB48], rax
       mov      rcx, bword ptr [rbp-0xB48]
       mov      rdx, gword ptr [rbp-0x5A8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB48]
       mov      rcx, qword ptr [rbp-0x5A0]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG58
       mov      rcx, 0x7FF9D77EAAE8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x7E0], rax
       mov      rcx, gword ptr [rbp-0x7E0]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG239
 
G_M000_IG58:                ;; offset=0x0C4C
       mov      rcx, 0x7FF9D77EAAEC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG225
 
G_M000_IG59:                ;; offset=0x0C6A
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG60
       mov      rcx, 0x7FF9D77EAAF0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG60:                ;; offset=0x0C8F
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x378], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x37C], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x7E4], eax
       mov      r9d, dword ptr [rbp-0x7E4]
       lea      rdx, [rbp-0x118]
       mov      r8d, dword ptr [rbp-0x37C]
       mov      rcx, bword ptr [rbp-0x378]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x10]
       inc      eax
       mov      dword ptr [rbp-0x11C], eax
       mov      rax, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rax+0x70]
       mov      gword ptr [rbp-0x128], rax
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorsExecutableLocals():bool:this]
       test     eax, eax
       jne      G_M000_IG63
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorLocalStores():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG62
       mov      rax, gword ptr [rbp-0x40]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x11C]
       jle      SHORT G_M000_IG61
       mov      rcx, 0x7FF9D77EAAF4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x40]
       mov      ecx, dword ptr [rbp-0x11C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG224
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 30
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x380], eax
       jmp      SHORT G_M000_IG64
 
G_M000_IG61:                ;; offset=0x0D7E
       mov      rcx, 0x7FF9D77EAAF8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG63
 
G_M000_IG62:                ;; offset=0x0D8F
       mov      rcx, 0x7FF9D77EAAFC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG63:                ;; offset=0x0D9E
       xor      eax, eax
       mov      dword ptr [rbp-0x380], eax
 
G_M000_IG64:                ;; offset=0x0DA6
       movzx    rax, byte  ptr [rbp-0x380]
       mov      dword ptr [rbp-0x12C], eax
       cmp      dword ptr [rbp-0x12C], 0
       je       G_M000_IG71
       cmp      gword ptr [rbp-0x128], 0
       je       G_M000_IG68
 
G_M000_IG65:                ;; offset=0x0DCE
       vmovdqu  xmm0, xmmword ptr [rbp-0x118]
       vmovdqu  xmmword ptr [rbp-0x7F8], xmm0
 
G_M000_IG66:                ;; offset=0x0DDE
       lea      r8, [rbp-0x7F8]
       mov      rdx, gword ptr [rbp-0x128]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryAppendBufferedYield(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):bool:this]
       test     eax, eax
       je       G_M000_IG67
       mov      rax, gword ptr [rbp-0x40]
       mov      ecx, dword ptr [rbp-0x11C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG224
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x800], rax
       mov      rdx, gword ptr [rbp-0x800]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x390], rax
       mov      rax, gword ptr [rbp-0x390]
       mov      gword ptr [rbp-0x398], rax
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_HasActiveHandler():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG69
       mov      rax, gword ptr [rbp-0x398]
       mov      gword ptr [rbp-0x3A0], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rax+0x80]
       mov      gword ptr [rbp-0x3A8], rax
       jmp      SHORT G_M000_IG70
 
G_M000_IG67:                ;; offset=0x0E94
       mov      rcx, 0x7FF9D77EAB00
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG71
 
G_M000_IG68:                ;; offset=0x0EA8
       mov      rcx, 0x7FF9D77EAB04
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG71
 
G_M000_IG69:                ;; offset=0x0EBC
       mov      rcx, 0x7FF9D77EAB08
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x398]
       mov      gword ptr [rbp-0x3A0], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CurrentException():Lokad.Lython.Runtime.PyException:this]
       mov      gword ptr [rbp-0x3A8], rax
 
G_M000_IG70:                ;; offset=0x0EF7
       mov      rcx, 0x7FF9D77EAB0C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp-0x3A0]
       mov      rdx, gword ptr [rbp-0x3A8]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:SetCurrentException(Lokad.Lython.Runtime.PyException):Lokad.Lython.Runtime.PyException:this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x3B0], rax
       mov      rax, gword ptr [rbp-0x40]
       mov      ecx, dword ptr [rbp-0x11C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG224
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x804], eax
       mov      edx, dword ptr [rbp-0x804]
       mov      rcx, bword ptr [rbp-0x3B0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 16
       mov      bword ptr [rbp-0x3B8], rax
       mov      rax, bword ptr [rbp-0x3B8]
       add      dword ptr [rax], 2
       jmp      G_M000_IG235
 
G_M000_IG71:                ;; offset=0x0F95
       vmovdqu  xmm0, xmmword ptr [rbp-0x118]
       vmovdqu  xmmword ptr [rbp-0x818], xmm0
 
G_M000_IG72:                ;; offset=0x0FA5
       lea      rdx, [rbp-0x818]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:set_YieldValue(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      rcx, gword ptr [rbp+0x20]
       mov      edx, 1
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:set_HasYield(bool):this]
       mov      rax, gword ptr [rbp+0x20]
       mov      byte  ptr [rax+0xF8], 1
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 16
       mov      bword ptr [rbp-0x388], rax
       mov      rax, bword ptr [rbp-0x388]
       inc      dword ptr [rax]
       cmp      dword ptr [rbp-0x12C], 0
       jne      SHORT G_M000_IG75
       cmp      gword ptr [rbp-0x128], 0
       je       SHORT G_M000_IG74
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [rbp-0x128]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG73
       mov      rcx, 0x7FF9D77EAB10
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG235
 
G_M000_IG73:                ;; offset=0x1030
       mov      rcx, 0x7FF9D77EAB14
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG75
 
G_M000_IG74:                ;; offset=0x1041
       mov      rcx, 0x7FF9D77EAB18
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG75:                ;; offset=0x1050
       mov      rcx, 0x7FF9D77EAB1C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG239
 
G_M000_IG76:                ;; offset=0x106E
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG77
       mov      rcx, 0x7FF9D77EAB20
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG77:                ;; offset=0x1093
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       G_M000_IG81
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG78:                ;; offset=0x10A3
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x838], ymm0
 
G_M000_IG79:                ;; offset=0x10AF
       lea      r8, [rbp-0x838]
       lea      rdx, [rbp-0x370]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteDelegationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB50], rax
       mov      rcx, bword ptr [rbp-0xB50]
       mov      rdx, gword ptr [rbp-0x370]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB50]
       mov      rcx, qword ptr [rbp-0x368]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG80
       mov      rcx, 0x7FF9D77EAB24
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x840], rax
       mov      rcx, gword ptr [rbp-0x840]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG239
 
G_M000_IG80:                ;; offset=0x1143
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG87
 
G_M000_IG81:                ;; offset=0x1152
       mov      rax, gword ptr [rbp+0x20]
       cmp      gword ptr [rax+0x68], 0
       jne      G_M000_IG82
       mov      rcx, 0x7FF9D77EAB28
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x340], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x344], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x844], eax
       mov      r8d, dword ptr [rbp-0x844]
       mov      edx, dword ptr [rbp-0x344]
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      gword ptr [rbp-0x138], rax
       mov      rcx, 0x7FF9D71528A8
       mov      edx, 1
       call     CORINFO_HELP_NEWARR_1_PTR
       mov      gword ptr [rbp-0x350], rax
       mov      rcx, gword ptr [rbp-0x350]
       mov      r8, gword ptr [rbp-0x138]
       xor      edx, edx
       call     [CORINFO_HELP_ARRADDR_ST]
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x850], rax
       mov      rdx, gword ptr [rbp-0x850]
       mov      rcx, gword ptr [rbp-0x350]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:Iter(System.Object[],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x358], rax
       mov      rcx, 0x7FF9D77E7DB8
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x360], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x858], rax
       mov      r9, gword ptr [rbp-0x858]
       mov      rdx, gword ptr [rbp-0x358]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x360]
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:.ctor(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp+0x20]
       lea      rcx, bword ptr [rax+0x68]
       mov      rdx, gword ptr [rbp-0x360]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG82:                ;; offset=0x1281
       mov      rcx, 0x7FF9D77EAB2C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x20]
       mov      r9, gword ptr [rax+0x60]
       mov      rax, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rax+0x68]
       lea      rdx, [rbp-0x338]
       mov      rax, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rax+0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:Advance(System.Object,Lokad.Lython.Runtime.LythonRuntimeException):Lokad.Lython.Runtime.PyIterationResult:this]
 
G_M000_IG83:                ;; offset=0x12B7
       vmovdqu  xmm0, xmmword ptr [rbp-0x338]
       vmovdqu  xmmword ptr [rbp-0x868], xmm0
 
G_M000_IG84:                ;; offset=0x12C7
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG85:                ;; offset=0x12CB
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x888], ymm0
 
G_M000_IG86:                ;; offset=0x12D7
       lea      rdx, [rbp-0x868]
       lea      r8, [rbp-0x888]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteDelegatedStep(Lokad.Lython.Runtime.PyIterationResult,Lokad.Lython.Frontend.ExecutableInstruction):this]
 
G_M000_IG87:                ;; offset=0x12F1
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_HasYield():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG89
       mov      rax, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rax+0x70]
       mov      gword ptr [rbp-0x140], rax
       cmp      gword ptr [rbp-0x140], 0
       je       SHORT G_M000_IG90
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [rbp-0x140]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG88
       mov      rcx, 0x7FF9D77EAB30
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG235
 
G_M000_IG88:                ;; offset=0x1345
       mov      rcx, 0x7FF9D77EAB34
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG90
 
G_M000_IG89:                ;; offset=0x1356
       mov      rcx, 0x7FF9D77EAB38
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG225
 
G_M000_IG90:                ;; offset=0x136A
       mov      rcx, 0x7FF9D77EAB3C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG239
 
G_M000_IG91:                ;; offset=0x1388
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG92
       mov      rcx, 0x7FF9D77EAB40
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG92:                ;; offset=0x13AD
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Imports():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ImportStatementSyntax]:this]
       mov      gword ptr [rbp-0x610], rax
       mov      rax, gword ptr [rbp-0x610]
       mov      gword ptr [rbp-0x650], rax
       mov      rcx, gword ptr [rbp-0x650]
       mov      rdx, 0x7FF9D77EAB48
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x650]
       mov      gword ptr [rbp-0x890], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ImportIndex():int:this]
       mov      dword ptr [rbp-0x894], eax
       mov      rcx, gword ptr [rbp-0x890]
       mov      edx, dword ptr [rbp-0x894]
       mov      r11, 0x7FF9D7091A50
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x88], rax
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG93
       mov      rcx, 0x7FF9D77EAC50
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rax+0x08]
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       mov      rdx, gword ptr [rbp-0x88]
       mov      r9, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteExecutableImport(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext)]
       jmp      G_M000_IG225
 
G_M000_IG93:                ;; offset=0x1462
       lea      rcx, [rbp-0x620]
       mov      rdx, gword ptr [rbp-0x88]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteImportAsync(Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Threading.Tasks.ValueTask]
 
G_M000_IG94:                ;; offset=0x147A
       vmovdqu  xmm0, xmmword ptr [rbp-0x620]
       vmovdqu  xmmword ptr [rbp-0x8A8], xmm0
 
G_M000_IG95:                ;; offset=0x148A
       lea      rdx, [rbp-0x8A8]
       lea      rcx, [rbp-0x630]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB58], rax
       mov      rcx, bword ptr [rbp-0xB58]
       mov      rdx, gword ptr [rbp-0x630]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB58]
       mov      rcx, qword ptr [rbp-0x628]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG96
       mov      rcx, 0x7FF9D77EAC54
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8B0], rax
       mov      rcx, gword ptr [rbp-0x8B0]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG239
 
G_M000_IG96:                ;; offset=0x1518
       mov      rcx, 0x7FF9D77EAC58
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG225
 
G_M000_IG97:                ;; offset=0x1536
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryLoadDirectCallReceiver(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG98
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG99
       mov      rcx, 0x7FF9D77EAC5C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG98:                ;; offset=0x1575
       mov      rcx, 0x7FF9D77EAC60
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG225
 
G_M000_IG99:                ;; offset=0x1589
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG100
       mov      rcx, 0x7FF9D77EAC64
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSynchronousMemberLoad(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG225
 
G_M000_IG100:                ;; offset=0x15BB
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG101:                ;; offset=0x15BF
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x8D0], ymm0
 
G_M000_IG102:                ;; offset=0x15CB
       lea      r8, [rbp-0x8D0]
       lea      rdx, [rbp-0x578]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteMemberLoadAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB60], rax
       mov      rcx, bword ptr [rbp-0xB60]
       mov      rdx, gword ptr [rbp-0x578]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB60]
       mov      rcx, qword ptr [rbp-0x570]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG103
       mov      rcx, 0x7FF9D77EAC68
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8D8], rax
       mov      rcx, gword ptr [rbp-0x8D8]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG239
 
G_M000_IG103:                ;; offset=0x165F
       mov      rcx, 0x7FF9D77EAC6C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG225
 
G_M000_IG104:                ;; offset=0x167D
       mov      rcx, 0x7FF9D77EAC70
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x608], rax
       mov      rax, gword ptr [rbp-0x608]
       mov      gword ptr [rbp-0xBC0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rdx, gword ptr [rbp-0xBC0]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG224
       mov      ecx, eax
       lea      rcx, bword ptr [rdx+8*rcx+0x10]
       mov      rcx, gword ptr [rcx]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      gword ptr [rbp-0x8E0], rax
       mov      r9, gword ptr [rbp-0x8E0]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG225
 
G_M000_IG105:                ;; offset=0x16FF
       mov      rcx, 0x7FF9D77EAC74
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x5C0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      dword ptr [rbp-0x5C4], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8E8], rax
       mov      r8, gword ptr [rbp-0x8E8]
       mov      edx, dword ptr [rbp-0x5C4]
       mov      rcx, gword ptr [rbp-0x5C0]
       mov      r9, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x8F0], rax
       mov      r9, gword ptr [rbp-0x8F0]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG225
 
G_M000_IG106:                ;; offset=0x1780
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG107
       mov      rcx, 0x7FF9D77EAC78
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG107:                ;; offset=0x17A5
       mov      rcx, 0x7FF9D77EAC7C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.String[]:this]
       mov      gword ptr [rbp-0x5B0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      rcx, gword ptr [rbp-0x5B0]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG224
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x5B8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8F8], rax
       mov      rdx, gword ptr [rbp-0x8F8]
       mov      rcx, gword ptr [rbp-0x5B8]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableName(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x900], rax
       mov      r9, gword ptr [rbp-0x900]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG225
 
G_M000_IG108:                ;; offset=0x1843
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG109
       mov      rcx, 0x7FF9D77EAC80
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG109:                ;; offset=0x1868
       mov      rcx, 0x7FF9D77EAC84
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x908], rax
       mov      rdx, gword ptr [rbp-0x908]
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:PreloadImplicitSuperArguments(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG225
 
G_M000_IG110:                ;; offset=0x189E
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG111
       mov      rcx, 0x7FF9D77EAC88
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG111:                ;; offset=0x18C3
       mov      rcx, 0x7FF9D77EAC8C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.String[]:this]
       mov      gword ptr [rbp-0x548], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      rcx, gword ptr [rbp-0x548]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG224
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x550], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x558], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x55C], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x90C], eax
       mov      r8d, dword ptr [rbp-0x90C]
       mov      edx, dword ptr [rbp-0x55C]
       mov      rcx, bword ptr [rbp-0x558]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      gword ptr [rbp-0x568], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x918], rax
       mov      r9, gword ptr [rbp-0x918]
       mov      rdx, gword ptr [rbp-0x568]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x550]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreName(System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG225
 
G_M000_IG112:                ;; offset=0x199E
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG113
       mov      rcx, 0x7FF9D77EAC90
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG113:                ;; offset=0x19C3
       mov      rcx, 0x7FF9D77EAC94
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x510], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x518], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.String[]:this]
       mov      gword ptr [rbp-0x520], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      rcx, gword ptr [rbp-0x520]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG224
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x528], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x530], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x534], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x91C], eax
       mov      r8d, dword ptr [rbp-0x91C]
       mov      edx, dword ptr [rbp-0x534]
       mov      rcx, bword ptr [rbp-0x530]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      gword ptr [rbp-0x540], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x928], rax
       mov      rax, gword ptr [rbp-0x928]
       mov      gword ptr [rsp+0x28], rax
       mov      rdx, gword ptr [rbp-0x518]
       mov      r8, gword ptr [rbp-0x528]
       mov      r9, gword ptr [rbp-0x540]
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, gword ptr [rbp-0x510]
       call     [Lokad.Lython.Runtime.LythonRuntime:AssignExecutableBoundName(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG225
 
G_M000_IG114:                ;; offset=0x1AD3
       mov      rcx, 0x7FF9D77EAC98
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4F8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x4FC], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x500], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x508], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x92C], eax
       mov      edx, dword ptr [rbp-0x92C]
       mov      rcx, bword ptr [rbp-0x508]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x938], rax
       mov      r9, gword ptr [rbp-0x938]
       mov      edx, dword ptr [rbp-0x4FC]
       mov      r8d, dword ptr [rbp-0x500]
       mov      rcx, bword ptr [rbp-0x4F8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishValue(int,int,System.Object):this]
       jmp      G_M000_IG225
 
G_M000_IG115:                ;; offset=0x1B7E
       mov      rcx, 0x7FF9D77EAC9C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4E8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x93C], eax
       mov      edx, dword ptr [rbp-0x93C]
       mov      rcx, bword ptr [rbp-0x4E8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4F0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x940], eax
       mov      edx, dword ptr [rbp-0x940]
       mov      rcx, bword ptr [rbp-0x4F0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       jmp      G_M000_IG225
 
G_M000_IG116:                ;; offset=0x1C02
       mov      rcx, 0x7FF9D77EACA0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4D8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4DC], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x4E0], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x948], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x948]
       mov      edx, dword ptr [rbp-0x4DC]
       mov      r8d, dword ptr [rbp-0x4E0]
       mov      rcx, bword ptr [rbp-0x4D8]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateListFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x950], rax
       mov      r9, gword ptr [rbp-0x950]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG225
 
G_M000_IG117:                ;; offset=0x1CA6
       cmp      gword ptr [rbp+0x20], 0
       je       SHORT G_M000_IG119
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryStageUnpackedFrameReturn(byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG118
       mov      rcx, 0x7FF9D77EACA4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG239
 
G_M000_IG118:                ;; offset=0x1CDF
       mov      rcx, 0x7FF9D77EACA8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG119:                ;; offset=0x1CEE
       mov      rcx, bword ptr [rbp+0x48]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG123
       mov      rax, bword ptr [rbp+0x48]
       mov      r8d, dword ptr [rax+0x08]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CanForwardFixedReturn(byref,byref,int):bool]
       test     eax, eax
       je       SHORT G_M000_IG122
       mov      rcx, 0x7FF9D77EACAC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x48]
 
G_M000_IG120:                ;; offset=0x1D29
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x960], xmm0
 
G_M000_IG121:                ;; offset=0x1D35
       lea      r9, [rbp-0x960]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CopyFixedReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       mov      dword ptr [rbp-0xE8], 2
       jmp      G_M000_IG239
 
G_M000_IG122:                ;; offset=0x1D5D
       mov      rcx, 0x7FF9D77EACB0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG123:                ;; offset=0x1D6C
       mov      rcx, 0x7FF9D77EACB4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4C8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4CC], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x4D0], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x968], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x968]
       mov      edx, dword ptr [rbp-0x4CC]
       mov      r8d, dword ptr [rbp-0x4D0]
       mov      rcx, bword ptr [rbp-0x4C8]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTupleFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyTuple]
       mov      gword ptr [rbp-0x970], rax
       mov      r9, gword ptr [rbp-0x970]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG225
 
G_M000_IG124:                ;; offset=0x1E10
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG125
       mov      rcx, 0x7FF9D77EACB8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG125:                ;; offset=0x1E35
       mov      rcx, 0x7FF9D77EACBC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteStructure(byref):bool:this]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG225
 
G_M000_IG126:                ;; offset=0x1E5C
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG127
       mov      rcx, 0x7FF9D77EACC0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG127:                ;; offset=0x1E81
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG128
       mov      rcx, 0x7FF9D77EACC4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteStructure(byref):bool:this]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG225
 
G_M000_IG128:                ;; offset=0x1EB0
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG129:                ;; offset=0x1EB4
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x990], ymm0
 
G_M000_IG130:                ;; offset=0x1EC0
       lea      r8, [rbp-0x990]
       lea      rdx, [rbp-0x4C0]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteContextManagerAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB68], rax
       mov      rcx, bword ptr [rbp-0xB68]
       mov      rdx, gword ptr [rbp-0x4C0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB68]
       mov      rcx, qword ptr [rbp-0x4B8]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG131
       mov      rcx, 0x7FF9D77EACC8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x998], rax
       mov      rcx, gword ptr [rbp-0x998]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG239
 
G_M000_IG131:                ;; offset=0x1F54
       mov      rcx, 0x7FF9D77EACCC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG225
 
G_M000_IG132:                ;; offset=0x1F75
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x28], rax
       mov      rax, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x30], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteComparisonInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref):int]
       mov      dword ptr [rbp-0x8C], eax
       cmp      dword ptr [rbp-0x8C], 0
       je       SHORT G_M000_IG133
       mov      rcx, 0x7FF9D77EACD0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x8C]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG239
 
G_M000_IG133:                ;; offset=0x1FD4
       mov      rcx, 0x7FF9D77EACD4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG225
 
G_M000_IG134:                ;; offset=0x1FF5
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteBuiltinArithmetic(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG135
       mov      rcx, 0x7FF9D77EACD8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG225
 
G_M000_IG135:                ;; offset=0x2023
       mov      rcx, 0x7FF9D77EACDC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG138
 
G_M000_IG136:                ;; offset=0x2034
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSequenceIndex(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG140
 
G_M000_IG137:                ;; offset=0x2052
       mov      rcx, 0x7FF9D77EACE0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG138:                ;; offset=0x2061
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x28], rax
       mov      rax, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x38], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInputInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref,byref):int]
       mov      dword ptr [rbp-0x90], eax
       cmp      dword ptr [rbp-0x90], 0
       je       SHORT G_M000_IG139
       mov      rcx, 0x7FF9D77EACE4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x90]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG239
 
G_M000_IG139:                ;; offset=0x20C9
       mov      rcx, 0x7FF9D77EACE8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG225
 
G_M000_IG140:                ;; offset=0x20DD
       mov      rcx, 0x7FF9D77EACEC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG225
 
G_M000_IG141:                ;; offset=0x20F1
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG142
       mov      rcx, 0x7FF9D77EACF0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG225
 
G_M000_IG142:                ;; offset=0x2126
       mov      rcx, 0x7FF9D77EACF4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG151
 
G_M000_IG143:                ;; offset=0x213A
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG149
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x2CC], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      eax, dword ptr [rbp-0x2CC]
       jne      G_M000_IG148
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x2D8], rax
       mov      rax, gword ptr [rbp-0x2D8]
       mov      gword ptr [rbp-0xBC0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rdx, gword ptr [rbp-0xBC0]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG224
       mov      ecx, eax
       imul     rcx, rcx, 16
       lea      rcx, bword ptr [rdx+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x9A0], rax
       mov      rdx, gword ptr [rbp-0x9A0]
       mov      rcx, 0x7FF9D77E5D30
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x98], rax
       cmp      gword ptr [rbp-0x98], 0
       je       G_M000_IG147
       mov      rcx, gword ptr [rbp-0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:get_NativeCsvSource():Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:this]
       mov      gword ptr [rbp-0xA0], rax
       cmp      gword ptr [rbp-0xA0], 0
       je       G_M000_IG146
       mov      rcx, gword ptr [rbp-0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:get_CanUnpackDirectly():bool:this]
       test     eax, eax
       je       G_M000_IG145
       mov      rax, bword ptr [rbp-0x58]
       mov      bword ptr [rsp+0x20], rax
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x28], eax
 
G_M000_IG144:                ;; offset=0x2248
       lea      rdx, [rbp-0x2E8]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rbp-0xA0]
       mov      r9, gword ptr [rbp-0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AdvanceCsvUnpack(Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource,Lokad.Lython.Runtime.PyIteration+Cursor,byref,bool):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB70], rax
       mov      rcx, bword ptr [rbp-0xB70]
       mov      rdx, gword ptr [rbp-0x2E8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB70]
       mov      rcx, qword ptr [rbp-0x2E0]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      G_M000_IG150
       mov      rcx, 0x7FF9D77EACF8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x9A8], rax
       mov      rcx, gword ptr [rbp-0x9A8]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG239
 
G_M000_IG145:                ;; offset=0x22E7
       mov      rcx, 0x7FF9D77EACFC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG146:                ;; offset=0x22F8
       mov      rcx, 0x7FF9D77EAD00
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG147:                ;; offset=0x2309
       mov      rcx, 0x7FF9D77EAD04
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG148:                ;; offset=0x231A
       mov      rcx, 0x7FF9D77EAD08
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG149:                ;; offset=0x232B
       mov      rcx, 0x7FF9D77EAD0C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG150:                ;; offset=0x233C
       mov      rcx, 0x7FF9D77EAD10
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG225
 
G_M000_IG151:                ;; offset=0x235D
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x460], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x9AC], eax
       mov      edx, dword ptr [rbp-0x9AC]
       lea      r8, [rbp-0xA8]
       lea      r9, [rbp-0xB8]
       mov      rcx, bword ptr [rbp-0x460]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryAdvanceNativeIteration(int,byref,byref):bool:this]
       test     eax, eax
       je       G_M000_IG155
       movzx    rax, byte  ptr [rbp-0xA8]
       test     eax, eax
       je       SHORT G_M000_IG154
       mov      rcx, 0x7FF9D77EAD14
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG152:                ;; offset=0x23C5
       vmovdqu  xmm0, xmmword ptr [rbp-0xB8]
       vmovdqu  xmmword ptr [rbp-0x9C0], xmm0
 
G_M000_IG153:                ;; offset=0x23D5
       lea      r9, [rbp-0x9C0]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG225
 
G_M000_IG154:                ;; offset=0x23F3
       mov      rcx, 0x7FF9D77EAD18
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x478], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x9C4], eax
       mov      edx, dword ptr [rbp-0x9C4]
       mov      rcx, bword ptr [rbp-0x478]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x10], eax
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG225
 
G_M000_IG155:                ;; offset=0x2457
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG156
       mov      rcx, 0x7FF9D77EAD1C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG156:                ;; offset=0x247C
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG157
       mov      rcx, 0x7FF9D77EAD20
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNext(byref):bool:this]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG225
 
G_M000_IG157:                ;; offset=0x24AB
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG158:                ;; offset=0x24AF
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x9E8], ymm0
 
G_M000_IG159:                ;; offset=0x24BB
       lea      r8, [rbp-0x9E8]
       lea      rdx, [rbp-0x470]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNextAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB78], rax
       mov      rcx, bword ptr [rbp-0xB78]
       mov      rdx, gword ptr [rbp-0x470]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB78]
       mov      rcx, qword ptr [rbp-0x468]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG160
       mov      rcx, 0x7FF9D77EAD24
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x9F0], rax
       mov      rcx, gword ptr [rbp-0x9F0]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG239
 
G_M000_IG160:                ;; offset=0x254F
       mov      rcx, 0x7FF9D77EAD28
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG225
 
G_M000_IG161:                ;; offset=0x2570
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x144], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       cmp      eax, dword ptr [rbp-0x144]
       jne      G_M000_IG164
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x9F4], eax
       mov      edx, dword ptr [rbp-0x9F4]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      gword ptr [rbp-0x150], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x9F8], eax
       mov      edx, dword ptr [rbp-0x9F8]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      gword ptr [rbp-0x158], rax
       mov      rax, gword ptr [rbp-0x150]
       mov      gword ptr [rbp-0x658], rax
       mov      rcx, gword ptr [rbp-0x658]
       mov      rdx, 0x7FF9D77EAD30
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x658]
       mov      gword ptr [rbp-0xA00], rax
       mov      rdx, gword ptr [rbp-0xA00]
       mov      rcx, 0x7FF9D775AC10
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x160], rax
       cmp      gword ptr [rbp-0x160], 0
       je       G_M000_IG168
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xA08], rax
       cmp      gword ptr [rbp+0x20], 0
       setne    al
       movzx    rax, al
       mov      dword ptr [rsp+0x20], eax
       lea      rax, [rbp-0x170]
       mov      qword ptr [rsp+0x28], rax
       mov      r8, gword ptr [rbp-0xA08]
       mov      rdx, gword ptr [rbp-0x158]
       mov      rcx, gword ptr [rbp-0x160]
       mov      r9, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeUnaryBuiltin(Lokad.Lython.Runtime.LythonRuntime+BuiltinCallable,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
 
G_M000_IG162:                ;; offset=0x26AA
       je       G_M000_IG163
       lea      rcx, [rbp-0x170]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x660], rax
       mov      rcx, gword ptr [rbp-0x660]
       mov      rdx, 0x7FF9D77EAE38
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x660]
       mov      gword ptr [rbp-0xA10], rax
       mov      rdx, gword ptr [rbp-0xA10]
       mov      rcx, 0x7FF9D74F0AF8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x178], rax
       cmp      gword ptr [rbp-0x178], 0
       je       SHORT G_M000_IG165
       mov      rcx, 0x7FF9D77EAF40
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x178]
       mov      gword ptr [rbp-0x50], rax
       jmp      G_M000_IG232
 
G_M000_IG163:                ;; offset=0x272F
       mov      rcx, 0x7FF9D77EAF44
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG168
 
G_M000_IG164:                ;; offset=0x2740
       mov      rcx, 0x7FF9D77EAF48
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG169
 
G_M000_IG165:                ;; offset=0x2754
       mov      rcx, 0x7FF9D77EAF4C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG166:                ;; offset=0x2763
       vmovdqu  xmm0, xmmword ptr [rbp-0x170]
       vmovdqu  xmmword ptr [rbp-0xA20], xmm0
 
G_M000_IG167:                ;; offset=0x2773
       lea      r9, [rbp-0xA20]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG225
 
G_M000_IG168:                ;; offset=0x2791
       mov      rcx, 0x7FF9D77EAF50
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x144]
       lea      r8d, [rax+0x01]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp-0x144]
       mov      r9, gword ptr [rbp-0x150]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishValue(int,int,System.Object):this]
       mov      eax, dword ptr [rbp-0x144]
       lea      r8d, [rax+0x02]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      eax, dword ptr [rbp-0x144]
       lea      edx, [rax+0x01]
       mov      r9, gword ptr [rbp-0x158]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishValue(int,int,System.Object):this]
 
G_M000_IG169:                ;; offset=0x27F9
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x400], rax
       mov      rax, gword ptr [rbp-0x400]
       mov      gword ptr [rbp-0x668], rax
       mov      rcx, gword ptr [rbp-0x668]
       mov      rdx, 0x7FF9D77EAF58
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x668]
       mov      gword ptr [rbp-0xA28], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0xA2C], eax
       mov      rcx, gword ptr [rbp-0xA28]
       mov      edx, dword ptr [rbp-0xA2C]
       mov      r11, 0x7FF9D7091A48
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0xC0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0xC4], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x408], rax
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_TargetOffset():int:this]
       add      eax, dword ptr [rbp-0xC4]
       mov      dword ptr [rbp-0xA30], eax
       mov      edx, dword ptr [rbp-0xA30]
       mov      rcx, bword ptr [rbp-0x408]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0xD0], rax
       mov      eax, dword ptr [rbp-0xC4]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rsp+0x28], rax
       lea      rax, [rbp-0xD8]
       mov      qword ptr [rsp+0x30], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       G_M000_IG173
       cmp      gword ptr [rbp-0xD8], 0
       je       SHORT G_M000_IG171
       mov      rax, gword ptr [rbp-0xD8]
       mov      gword ptr [rbp-0x670], rax
       mov      rcx, gword ptr [rbp-0x670]
 
G_M000_IG170:                ;; offset=0x292E
       mov      rdx, 0x7FF9D77EB060
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x670]
       mov      gword ptr [rbp-0xA38], rax
       mov      rdx, gword ptr [rbp-0xA38]
       mov      rcx, 0x7FF9D74F0AF8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x180], rax
       cmp      gword ptr [rbp-0x180], 0
       je       SHORT G_M000_IG172
       mov      rax, gword ptr [rbp-0x180]
       mov      gword ptr [rbp-0x50], rax
       jmp      G_M000_IG232
 
G_M000_IG171:                ;; offset=0x2983
       mov      rcx, 0x7FF9D77EB168
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG225
 
G_M000_IG172:                ;; offset=0x2997
       mov      rcx, 0x7FF9D77EB16C
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x458], xmm0
       vmovdqu  xmmword ptr [rbp-0x450], xmm0
       mov      rdx, gword ptr [rbp-0xD8]
       mov      rcx, 0x7FF9D76A9D18
       call     [CORINFO_HELP_CHKCASTCLASS]
       mov      gword ptr [rbp-0xA40], rax
       mov      r8, gword ptr [rbp-0xA40]
       lea      rcx, [rbp-0x458]
       mov      rdx, 0x7FF9D77E6320
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:.ctor(System.__Canon):this]
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rbp-0xB80], rax
       mov      rcx, bword ptr [rbp-0xB80]
       mov      rax, bword ptr [rbp-0xB80]
       cmp      byte  ptr [rax], al
       lea      rdx, [rbp-0x458]
       mov      r8d, 24
       vzeroupper 
       call     [CORINFO_HELP_BULK_WRITEBARRIER]
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xE8], 3
       jmp      G_M000_IG239
 
G_M000_IG173:                ;; offset=0x2A51
       cmp      gword ptr [rbp+0x20], 0
       jne      G_M000_IG176
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x188]
       mov      qword ptr [rsp+0x28], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp-0xC0]
       mov      r9d, dword ptr [rbp-0xC4]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDeferredChild(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG174
       mov      rcx, 0x7FF9D77EB170
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG174:                ;; offset=0x2AB2
       cmp      gword ptr [rbp-0x188], 0
       je       G_M000_IG175
       mov      rcx, 0x7FF9D77EB174
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x440], xmm0
       vmovdqu  xmmword ptr [rbp-0x438], xmm0
       lea      rcx, [rbp-0x440]
       mov      r8, gword ptr [rbp-0x188]
       mov      rdx, 0x7FF9D77E6320
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:.ctor(System.__Canon):this]
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rbp-0xB88], rax
       mov      rcx, bword ptr [rbp-0xB88]
       mov      rax, bword ptr [rbp-0xB88]
       cmp      byte  ptr [rax], al
       lea      rdx, [rbp-0x440]
       mov      r8d, 24
       vzeroupper 
       call     [CORINFO_HELP_BULK_WRITEBARRIER]
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xE8], 3
       jmp      G_M000_IG239
 
G_M000_IG175:                ;; offset=0x2B5C
       mov      rcx, 0x7FF9D77EB178
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG225
 
G_M000_IG176:                ;; offset=0x2B70
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x28], rax
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      r8d, dword ptr [rbp-0xC4]
       mov      r9, gword ptr [rbp-0xD0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBeginExecutableCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool,byref):bool:this]
       test     eax, eax
       je       G_M000_IG180
       mov      rcx, bword ptr [rbp+0x40]
       mov      rdx, 0x7FF9D77E6320
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:get_IsCompletedSuccessfully():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG178
       mov      rcx, bword ptr [rbp+0x40]
       mov      rdx, 0x7FF9D77E6320
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:get_Result():System.__Canon:this]
       cmp      rax, gword ptr [rbp+0x20]
       je       SHORT G_M000_IG179
 
G_M000_IG177:                ;; offset=0x2BDC
       mov      rcx, 0x7FF9D77EB17C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG178:                ;; offset=0x2BEB
       mov      rcx, 0x7FF9D77EB180
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xE8], 3
       jmp      G_M000_IG239
 
G_M000_IG179:                ;; offset=0x2C24
       mov      rcx, 0x7FF9D77EB184
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x40]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      qword ptr [rax+0x10], rcx
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG225
 
G_M000_IG180:                ;; offset=0x2C50
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG181
       mov      rcx, 0x7FF9D77EB188
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rsp+0x20], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       lea      rdx, [rbp-0xF8]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rbp-0xC0]
       mov      r9d, dword ptr [rbp-0xC4]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       lea      rdx, [rbp-0x108]
       lea      rcx, [rbp-0xF8]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter:GetResult():this]
       jmp      G_M000_IG225
 
G_M000_IG181:                ;; offset=0x2CC0
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rsp+0x20], rax
       mov      dword ptr [rsp+0x28], 1
       lea      rdx, [rbp-0x418]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rbp-0xC0]
       mov      r9d, dword ptr [rbp-0xC4]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG182:                ;; offset=0x2CF5
       vmovdqu  xmm0, xmmword ptr [rbp-0x418]
       vmovdqu  xmmword ptr [rbp-0xA50], xmm0
 
G_M000_IG183:                ;; offset=0x2D05
       lea      rdx, [rbp-0xA50]
       lea      rcx, [rbp-0x428]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB90], rax
       mov      rcx, bword ptr [rbp-0xB90]
       mov      rdx, gword ptr [rbp-0x428]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB90]
       mov      rcx, qword ptr [rbp-0x420]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG184
       mov      rcx, 0x7FF9D77EB18C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xA58], rax
       mov      rcx, gword ptr [rbp-0xA58]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG239
 
G_M000_IG184:                ;; offset=0x2D93
       mov      rcx, 0x7FF9D77EB190
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG225
 
G_M000_IG185:                ;; offset=0x2DB1
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x480], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0xA5C], eax
       mov      edx, dword ptr [rbp-0xA5C]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      gword ptr [rbp-0x488], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x48C], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x490], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xA68], rax
       mov      rax, gword ptr [rbp-0xA68]
       mov      gword ptr [rsp+0x20], rax
       mov      rdx, gword ptr [rbp-0x488]
       mov      r8d, dword ptr [rbp-0x48C]
       mov      r9d, dword ptr [rbp-0x490]
       mov      rcx, bword ptr [rbp-0x480]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryPrepareNativeIteration(System.Object,int,int,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG186
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG187
       mov      rcx, 0x7FF9D77EB194
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG186:                ;; offset=0x2E7C
       mov      rcx, 0x7FF9D77EB198
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG225
 
G_M000_IG187:                ;; offset=0x2E90
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG188
       mov      rcx, 0x7FF9D77EB19C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG225
 
G_M000_IG188:                ;; offset=0x2EBC
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG189:                ;; offset=0x2EC0
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0xA88], ymm0
 
G_M000_IG190:                ;; offset=0x2ECC
       lea      r8, [rbp-0xA88]
       lea      rdx, [rbp-0x4A0]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteGetIteratorAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG191:                ;; offset=0x2EE6
       vmovdqu  xmm0, xmmword ptr [rbp-0x4A0]
       vmovdqu  xmmword ptr [rbp-0xA98], xmm0
 
G_M000_IG192:                ;; offset=0x2EF6
       lea      rdx, [rbp-0xA98]
       lea      rcx, [rbp-0x4B0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB98], rax
       mov      rcx, bword ptr [rbp-0xB98]
       mov      rdx, gword ptr [rbp-0x4B0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB98]
       mov      rcx, qword ptr [rbp-0x4A8]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG193
       mov      rcx, 0x7FF9D77EB1A0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xAA0], rax
       mov      rcx, gword ptr [rbp-0xAA0]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG239
 
G_M000_IG193:                ;; offset=0x2F84
       mov      rcx, 0x7FF9D77EB1A4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG225
 
G_M000_IG194:                ;; offset=0x2FA2
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG195
       mov      rcx, 0x7FF9D77EB1A8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG195:                ;; offset=0x2FC7
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG196
       mov      rcx, 0x7FF9D77EB1AC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG225
 
G_M000_IG196:                ;; offset=0x2FF3
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG197:                ;; offset=0x2FF7
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0xAC0], ymm0
 
G_M000_IG198:                ;; offset=0x3003
       lea      r8, [rbp-0xAC0]
       lea      rdx, [rbp-0x3E8]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSliceValueOperationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG199:                ;; offset=0x301D
       vmovdqu  xmm0, xmmword ptr [rbp-0x3E8]
       vmovdqu  xmmword ptr [rbp-0xAD0], xmm0
 
G_M000_IG200:                ;; offset=0x302D
       lea      rdx, [rbp-0xAD0]
       lea      rcx, [rbp-0x3F8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xBA0], rax
       mov      rcx, bword ptr [rbp-0xBA0]
       mov      rdx, gword ptr [rbp-0x3F8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xBA0]
       mov      rcx, qword ptr [rbp-0x3F0]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG201
       mov      rcx, 0x7FF9D77EB1B0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xAD8], rax
       mov      rcx, gword ptr [rbp-0xAD8]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG239
 
G_M000_IG201:                ;; offset=0x30BB
       mov      rcx, 0x7FF9D77EB1B4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG225
 
G_M000_IG202:                ;; offset=0x30D9
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG203
       mov      rcx, 0x7FF9D77EB1B8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG203:                ;; offset=0x30FE
       mov      rcx, 0x7FF9D77EB1BC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG225
 
G_M000_IG204:                ;; offset=0x3122
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0xADC], eax
       mov      edx, dword ptr [rbp-0xADC]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      gword ptr [rbp-0xE0], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG206
       mov      rcx, gword ptr [rbp-0xE0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       jne      SHORT G_M000_IG205
       mov      rcx, 0x7FF9D77EB1C0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG205:                ;; offset=0x3186
       mov      rcx, 0x7FF9D77EB1C4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG206:                ;; offset=0x3195
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       SHORT G_M000_IG208
       mov      rdx, gword ptr [rbp-0xE0]
       mov      rcx, 0x7FF9D77E9A80
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG209
 
G_M000_IG207:                ;; offset=0x31B9
       mov      rcx, 0x7FF9D77EB1C8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG208:                ;; offset=0x31C8
       mov      rcx, 0x7FF9D77EB1CC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG225
 
G_M000_IG209:                ;; offset=0x31F5
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG210:                ;; offset=0x31F9
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0xB00], ymm0
 
G_M000_IG211:                ;; offset=0x3205
       lea      r8, [rbp-0xB00]
       lea      rdx, [rbp-0x3C8]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteConditionalJumpAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xBA8], rax
       mov      rcx, bword ptr [rbp-0xBA8]
       mov      rdx, gword ptr [rbp-0x3C8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xBA8]
       mov      rcx, qword ptr [rbp-0x3C0]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG212
       mov      rcx, 0x7FF9D77EB1D0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xB08], rax
       mov      rcx, gword ptr [rbp-0xB08]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG239
 
G_M000_IG212:                ;; offset=0x3299
       mov      rcx, 0x7FF9D77EB1D4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG225
 
G_M000_IG213:                ;; offset=0x32BA
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG217
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0x18C], eax
       cmp      dword ptr [rbp-0x18C], 49
       je       SHORT G_M000_IG216
       cmp      dword ptr [rbp-0x18C], 57
       je       SHORT G_M000_IG215
       cmp      dword ptr [rbp-0x18C], 58
       je       SHORT G_M000_IG214
       mov      rcx, 0x7FF9D77EB1D8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG214:                ;; offset=0x330A
       mov      rcx, 0x7FF9D77EB1DC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG217
 
G_M000_IG215:                ;; offset=0x331B
       mov      rcx, 0x7FF9D77EB1E0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG217
 
G_M000_IG216:                ;; offset=0x332C
       mov      rcx, 0x7FF9D77EB1E4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG217:                ;; offset=0x333B
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp-0x44], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x68]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_IsUnassigned():bool:this]
       test     eax, eax
       jne      G_M000_IG219
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       G_M000_IG220
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG218
       mov      rcx, 0x7FF9D77EB1E8
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x3D8], xmm0
       lea      rcx, [rbp-0x3D8]
       mov      edx, dword ptr [rbp-0x44]
       call     [System.Threading.Tasks.ValueTask`1[bool]:.ctor(bool):this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xBB0], rax
       mov      rcx, bword ptr [rbp-0xBB0]
       mov      rdx, gword ptr [rbp-0x3D8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xBB0]
       mov      rcx, qword ptr [rbp-0x3D0]
       mov      qword ptr [rax+0x08], rcx
       mov      dword ptr [rbp-0xE8], 5
       jmp      G_M000_IG239
 
G_M000_IG218:                ;; offset=0x33FE
       mov      rcx, 0x7FF9D77EB1EC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG220
 
G_M000_IG219:                ;; offset=0x340F
       mov      rcx, 0x7FF9D77EB1F0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG225
 
G_M000_IG220:                ;; offset=0x3423
       mov      rcx, 0x7FF9D77EB1F4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG239
 
G_M000_IG221:                ;; offset=0x3441
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x1F0], ymm0
       vmovdqu  xmmword ptr [rbp-0x1D8], xmm0
       lea      rcx, [rbp-0x1F0]
       mov      edx, 27
       mov      r8d, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
 
G_M000_IG222:                ;; offset=0x346D
       vmovdqu  ymm0, ymmword ptr [rbp-0x1F0]
       vmovdqu  ymmword ptr [rbp-0x1B8], ymm0
       mov      rax, qword ptr [rbp-0x1D0]
       mov      qword ptr [rbp-0x198], rax
 
G_M000_IG223:                ;; offset=0x348B
       lea      rcx, [rbp-0x1B8]
       mov      rdx, 0x2C171C92A40
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendLiteral(System.String):this]
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0xB0C], eax
       mov      edx, dword ptr [rbp-0xB0C]
       lea      rcx, [rbp-0x1B8]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x1F8], rax
       lea      rcx, [rbp-0x1B8]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      gword ptr [rbp-0xB18], rax
       mov      rdx, gword ptr [rbp-0xB18]
       mov      rcx, gword ptr [rbp-0x1F8]
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, gword ptr [rbp-0x1F8]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG224:                ;; offset=0x3510
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG225:                ;; offset=0x3516
       mov      eax, dword ptr [rbp-0x674]
       dec      eax
       mov      dword ptr [rbp-0x674], eax
       cmp      dword ptr [rbp-0x674], 0
       jg       SHORT G_M000_IG227
 
G_M000_IG226:                ;; offset=0x352D
       lea      rcx, [rbp-0x674]
       mov      edx, 0x102A
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG227:                ;; offset=0x3540
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       G_M000_IG230
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG229
       mov      rcx, 0x7FF9D77EB204
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x210]
       mov      edx, dword ptr [rbp-0x44]
       call     [System.Threading.Tasks.ValueTask`1[bool]:.ctor(bool):this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xBB8], rax
       mov      rcx, bword ptr [rbp-0xBB8]
       mov      rdx, gword ptr [rbp-0x210]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xBB8]
       mov      rcx, qword ptr [rbp-0x208]
       mov      qword ptr [rax+0x08], rcx
       mov      eax, 5
 
G_M000_IG228:                ;; offset=0x35B8
       vzeroupper 
       add      rsp, 0xC00
       pop      rbp
       ret      
 
G_M000_IG229:                ;; offset=0x35C4
       mov      rcx, 0x7FF9D77EB208
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG230:                ;; offset=0x35D3
       cmp      dword ptr [rbp-0x44], 0
       jne      SHORT G_M000_IG231
       mov      rcx, 0x7FF9D77EB20C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 16
       mov      bword ptr [rbp-0x200], rax
       mov      rax, bword ptr [rbp-0x200]
       inc      dword ptr [rax]
       jmp      SHORT G_M000_IG235
 
G_M000_IG231:                ;; offset=0x3608
       mov      rcx, 0x7FF9D77EB210
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG235
 
G_M000_IG232:                ;; offset=0x3619
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xB30], rax
       mov      r9, gword ptr [rbp-0xB30]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG234
 
G_M000_IG233:                ;; offset=0x3647
       mov      rcx, gword ptr [rbp-0x50]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG234:                ;; offset=0x3651
       mov      rcx, 0x7FF9D77EB214
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG225
 
G_M000_IG235:                ;; offset=0x366C
       mov      eax, dword ptr [rbp-0x674]
       dec      eax
       mov      dword ptr [rbp-0x674], eax
       cmp      dword ptr [rbp-0x674], 0
       jg       SHORT G_M000_IG237
 
G_M000_IG236:                ;; offset=0x3683
       lea      rcx, [rbp-0x674]
       mov      edx, 0x106F
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG237:                ;; offset=0x3696
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x10]
       mov      rcx, gword ptr [rbp-0x40]
       cmp      eax, dword ptr [rcx+0x08]
       jl       G_M000_IG03
       mov      rcx, 0x7FF9D77EB218
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, 1
 
G_M000_IG238:                ;; offset=0x36BE
       vzeroupper 
       add      rsp, 0xC00
       pop      rbp
       ret      
 
G_M000_IG239:                ;; offset=0x36CA
       mov      rcx, 0x7FF9D77EB21C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0xE8]
 
G_M000_IG240:                ;; offset=0x36DF
       vzeroupper 
       add      rsp, 0xC00
       pop      rbp
       ret      
 
G_M000_IG241:                ;; offset=0x36EB
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG242:                ;; offset=0x36F1
       sub      rsp, 72
 
G_M000_IG243:                ;; offset=0x36F5
       mov      gword ptr [rbp-0x640], rcx
       mov      rax, gword ptr [rbp-0x640]
       mov      gword ptr [rbp-0x1C0], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG245
 
G_M000_IG244:                ;; offset=0x3711
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG245:                ;; offset=0x3717
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xB20], rax
       mov      r8, gword ptr [rbp-0xB20]
       mov      rdx, gword ptr [rbp-0x1C0]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryRouteReturn(Lokad.Lython.Runtime.LythonRuntime+ReturnSignal,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG247
       mov      rcx, 0x7FF9D77EB1F8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       lea      rax, G_M000_IG239
 
G_M000_IG246:                ;; offset=0x3766
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG247:                ;; offset=0x376E
       mov      rcx, 0x7FF9D77EB1FC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x44], 1
       lea      rax, G_M000_IG225
 
G_M000_IG248:                ;; offset=0x378B
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG249:                ;; offset=0x3793
       sub      rsp, 72
 
G_M000_IG250:                ;; offset=0x3797
       mov      gword ptr [rbp-0x638], rcx
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xB28], rax
       mov      r9, gword ptr [rbp-0xB28]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x638]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG252
 
G_M000_IG251:                ;; offset=0x37CF
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG252:                ;; offset=0x37D5
       mov      rcx, 0x7FF9D77EB200
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x44], 1
       lea      rax, G_M000_IG225
 
G_M000_IG253:                ;; offset=0x37F2
       vzeroupper 
       add      rsp, 72
       ret      
 
RWD00  	dd	00001336h ; case G_M000_IG91
       	dd	0000162Bh ; case G_M000_IG104
       	dd	00000104h ; case G_M000_IG08
       	dd	000002ACh ; case G_M000_IG12
       	dd	000016ADh ; case G_M000_IG105
       	dd	0000172Eh ; case G_M000_IG106
       	dd	00000ADCh ; case G_M000_IG54
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	0000200Fh ; case G_M000_IG138
       	dd	0000200Fh ; case G_M000_IG138
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	000014E4h ; case G_M000_IG97
       	dd	000014E4h ; case G_M000_IG97
       	dd	000017F1h ; case G_M000_IG108
       	dd	0000040Fh ; case G_M000_IG16
       	dd	00000439h ; case G_M000_IG17
       	dd	0000184Ch ; case G_M000_IG110
       	dd	0000194Ch ; case G_M000_IG112
       	dd	00001A81h ; case G_M000_IG114
       	dd	00001B2Ch ; case G_M000_IG115
       	dd	00001BB0h ; case G_M000_IG116
       	dd	00001C54h ; case G_M000_IG117
       	dd	00001DBEh ; case G_M000_IG124
       	dd	00001DBEh ; case G_M000_IG124
       	dd	00001DBEh ; case G_M000_IG124
       	dd	00001E0Ah ; case G_M000_IG126
       	dd	00001E0Ah ; case G_M000_IG126
       	dd	00001E0Ah ; case G_M000_IG126
       	dd	00001DBEh ; case G_M000_IG124
       	dd	00002D5Fh ; case G_M000_IG185
       	dd	0000230Bh ; case G_M000_IG151
       	dd	000027A7h ; case G_M000_IG169
       	dd	00001FE2h ; case G_M000_IG136
       	dd	00002F50h ; case G_M000_IG194
       	dd	00003087h ; case G_M000_IG202
       	dd	00001FA3h ; case G_M000_IG134
       	dd	00001FA3h ; case G_M000_IG134
       	dd	00001FA3h ; case G_M000_IG134
       	dd	00003268h ; case G_M000_IG213
       	dd	000030D0h ; case G_M000_IG204
       	dd	00001F23h ; case G_M000_IG132
       	dd	00003268h ; case G_M000_IG213
       	dd	00003268h ; case G_M000_IG213
       	dd	00003268h ; case G_M000_IG213
       	dd	00003268h ; case G_M000_IG213
       	dd	00003268h ; case G_M000_IG213
       	dd	00003268h ; case G_M000_IG213
       	dd	00003268h ; case G_M000_IG213
       	dd	000000E6h ; case G_M000_IG07
       	dd	00000C18h ; case G_M000_IG59
       	dd	0000101Ch ; case G_M000_IG76
       	dd	00003268h ; case G_M000_IG213
       	dd	000005DEh ; case G_M000_IG29
       	dd	000005DEh ; case G_M000_IG29
       	dd	000005DEh ; case G_M000_IG29
       	dd	000005DEh ; case G_M000_IG29
       	dd	000005DEh ; case G_M000_IG29
       	dd	0000209Fh ; case G_M000_IG141
       	dd	000020E8h ; case G_M000_IG143
       	dd	000007E0h ; case G_M000_IG41
       	dd	000009A9h ; case G_M000_IG47
       	dd	000001A1h ; case G_M000_IG09
       	dd	0000251Eh ; case G_M000_IG161

; Total bytes of code 14330

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this (Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 976
       lea      rbp, [rsp+0x3D0]
       xor      eax, eax
       mov      qword ptr [rbp-0x388], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x380], xmm4
       vmovdqa  xmmword ptr [rbp-0x370], xmm4
       mov      rax, -864
 
G_M000_IG64:                ;; offset=0x0037
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG64
       mov      bword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
 
G_M000_IG02:                ;; offset=0x0056
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0xD0], rax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x244], eax
       mov      edx, dword ptr [rbp-0x244]
       mov      rcx, gword ptr [rbp-0xD0]
       mov      r11, 0x7FF9D7091C48
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x08], rax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x0C], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0xD8], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_TargetOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0xDC], eax
       mov      rax, bword ptr [rbp-0xD8]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xDC], eax
       jae      G_M000_IG53
       mov      rax, bword ptr [rbp-0xD8]
       mov      ecx, dword ptr [rbp-0xDC]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x250], rax
       mov      rdx, gword ptr [rbp-0x250]
       mov      rcx, 0x7FF9D77F2610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x18], rax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x28], xmm0
 
G_M000_IG03:                ;; offset=0x012D
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG04
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x20], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0x08]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      r9, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG42
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      G_M000_IG51
 
G_M000_IG04:                ;; offset=0x016E
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       jne      G_M000_IG08
       mov      rcx, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:IsRangeBuiltin(System.Object):bool]
       test     eax, eax
       je       G_M000_IG08
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0x200], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x204], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x254], eax
       mov      r9d, dword ptr [rbp-0x254]
       lea      rdx, [rbp-0x218]
       mov      r8d, dword ptr [rbp-0x204]
       mov      rcx, bword ptr [rbp-0x200]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG05:                ;; offset=0x01F2
       vmovdqu  xmm0, xmmword ptr [rbp-0x218]
       vmovdqu  xmmword ptr [rbp-0x268], xmm0
 
G_M000_IG06:                ;; offset=0x0202
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x270], rax
       mov      rdx, gword ptr [rbp-0x270]
       lea      rcx, [rbp-0x268]
       lea      r9, [rbp-0x38]
       mov      rax, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeNativeRange(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG07
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      G_M000_IG51
 
G_M000_IG07:                ;; offset=0x0243
       lea      rcx, [rbp-0x28]
       mov      rdx, gword ptr [rbp-0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       jmp      G_M000_IG42
 
G_M000_IG08:                ;; offset=0x0256
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       G_M000_IG35
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, 0x7FF9D76A4690
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x40], rax
       cmp      gword ptr [rbp-0x40], 0
       je       G_M000_IG35
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0x108], rax
       mov      rax, bword ptr [rbp-0x108]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x0C], eax
       jae      G_M000_IG39
       mov      rax, bword ptr [rbp-0x108]
       mov      ecx, dword ptr [rbp-0x0C]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x48], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       test     eax, eax
       jne      G_M000_IG20
       mov      rdx, gword ptr [rbp-0x48]
       mov      rcx, 0x7FF9D75B1030
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp-0x50], 0
       je       G_M000_IG20
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_SplitPrefix():Lokad.Lython.Frontend.ExecutableSplitPrefix:this]
       mov      gword ptr [rbp-0x278], rax
       mov      rdx, gword ptr [rbp-0x278]
       mov      rcx, 0x7FF9D76A31D0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x58], rax
       cmp      gword ptr [rbp-0x58], 0
       je       G_M000_IG20
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCasedSplit:get_CasingMethod():Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod:this]
 
G_M000_IG09:                ;; offset=0x034C
       cmp      rax, gword ptr [rbp-0x18]
       jne      G_M000_IG20
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG39
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
 
G_M000_IG10:                ;; offset=0x0384
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x90], ymm0
 
G_M000_IG11:                ;; offset=0x0390
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x180], rax
       lea      rcx, [rbp-0x90]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x27C], eax
       mov      edx, dword ptr [rbp-0x27C]
       mov      rcx, gword ptr [rbp-0x180]
       mov      r11, 0x7FF9D7091C60
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x98], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0x188], rax
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCasedSplit:get_CasingCallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x288], rax
       mov      rdx, gword ptr [rbp-0x288]
       mov      rcx, gword ptr [rbp-0x188]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG12:                ;; offset=0x0414
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0x190], rax
       lea      rax, bword ptr [rbp-0x28]
       mov      bword ptr [rbp-0x198], rax
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x1A0], rax
       mov      rax, gword ptr [rbp-0x50]
       mov      gword ptr [rbp-0x1A8], rax
       mov      rax, gword ptr [rbp-0x190]
       mov      gword ptr [rbp-0x1B0], rax
       mov      rcx, gword ptr [rbp-0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ConsumedByIteration():bool:this]
       test     eax, eax
       jne      G_M000_IG14
       mov      rax, bword ptr [rbp-0x198]
       mov      bword ptr [rbp-0x1E0], rax
       mov      rax, gword ptr [rbp-0x1A0]
       mov      gword ptr [rbp-0x1E8], rax
       mov      rax, gword ptr [rbp-0x1A8]
       mov      gword ptr [rbp-0x1F0], rax
       mov      rax, gword ptr [rbp-0x1B0]
       mov      gword ptr [rbp-0x1F8], rax
       mov      rax, bword ptr [rbp+0x10]
       movzx    rax, byte  ptr [rax+0x40]
       test     eax, eax
       je       SHORT G_M000_IG13
       mov      rax, bword ptr [rbp-0x1E0]
       mov      bword ptr [rbp-0x1B8], rax
       mov      rax, gword ptr [rbp-0x1E8]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rax, gword ptr [rbp-0x1F0]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rax, gword ptr [rbp-0x1F8]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rcx, gword ptr [rbp-0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ReturnedDirectly():bool:this]
       mov      dword ptr [rbp-0x1D4], eax
       jmp      G_M000_IG15
 
G_M000_IG13:                ;; offset=0x04FF
       mov      rax, bword ptr [rbp-0x1E0]
       mov      bword ptr [rbp-0x1B8], rax
       mov      rax, gword ptr [rbp-0x1E8]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rax, gword ptr [rbp-0x1F0]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rax, gword ptr [rbp-0x1F8]
       mov      gword ptr [rbp-0x1D0], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x1D4], eax
       jmp      SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x0541
       mov      rax, bword ptr [rbp-0x198]
       mov      bword ptr [rbp-0x1B8], rax
       mov      rax, gword ptr [rbp-0x1A0]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rax, gword ptr [rbp-0x1A8]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rax, gword ptr [rbp-0x1B0]
       mov      gword ptr [rbp-0x1D0], rax
       mov      dword ptr [rbp-0x1D4], 1
 
G_M000_IG15:                ;; offset=0x0583
       mov      rcx, gword ptr [rbp-0x1C0]
       mov      rdx, gword ptr [rbp-0x1C8]
       mov      r8, gword ptr [rbp-0x1D0]
       mov      r9d, dword ptr [rbp-0x1D4]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteCasedSplit(Lokad.Lython.Frontend.ExecutableCasedSplit,Lokad.Lython.Runtime.Text.PyString,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      gword ptr [rbp-0x290], rax
       mov      rdx, gword ptr [rbp-0x290]
       mov      rcx, bword ptr [rbp-0x1B8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       nop      
 
G_M000_IG16:                ;; offset=0x05C1
       call     G_M000_IG54
       nop      
 
G_M000_IG17:                ;; offset=0x05C7
       mov      rax, bword ptr [rbp+0x10]
       add      dword ptr [rax+0x38], 2
 
G_M000_IG18:                ;; offset=0x05CF
       vmovdqu  xmm0, xmmword ptr [rbp-0x28]
       vmovdqu  xmmword ptr [rbp-0x2A0], xmm0
 
G_M000_IG19:                ;; offset=0x05DC
       lea      r8, [rbp-0x2A0]
       lea      rdx, [rbp-0x90]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      dword ptr [rbp-0x2C], 1
       jmp      G_M000_IG51
 
G_M000_IG20:                ;; offset=0x0600
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_SplitPrefix():Lokad.Lython.Frontend.ExecutableSplitPrefix:this]
       mov      gword ptr [rbp-0x2A8], rax
       mov      rdx, gword ptr [rbp-0x2A8]
       mov      rcx, 0x7FF9D77F3450
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x60], rax
       cmp      gword ptr [rbp-0x60], 0
       je       G_M000_IG27
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       add      ecx, 3
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG39
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       cmp      eax, dword ptr [rbp-0x0C]
       jne      G_M000_IG27
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG21:                ;; offset=0x067D
       vmovdqu  xmm0, xmmword ptr [rax+0x48]
       vmovdqu  xmmword ptr [rbp-0x2B8], xmm0
 
G_M000_IG22:                ;; offset=0x068A
       lea      rdx, [rbp-0x2B8]
       lea      rcx, [rbp-0x150]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG23:                ;; offset=0x069E
       vmovdqu  xmm0, xmmword ptr [rbp-0x150]
       vmovdqu  xmmword ptr [rbp-0x2C8], xmm0
 
G_M000_IG24:                ;; offset=0x06AE
       lea      rax, [rbp-0x68]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x70]
       mov      qword ptr [rsp+0x28], rax
       lea      r8, [rbp-0x2C8]
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, gword ptr [rbp-0x08]
       mov      r9d, dword ptr [rbp-0x0C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryReadAsciiTrim(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,byref,byref):bool]
       test     eax, eax
       je       G_M000_IG27
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x158], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       add      ecx, 3
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG39
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x2CC], eax
       mov      edx, dword ptr [rbp-0x2CC]
       mov      rcx, gword ptr [rbp-0x158]
       mov      r11, 0x7FF9D7091C58
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0xA0], rax
       mov      rax, gword ptr [rbp-0x68]
       mov      gword ptr [rbp-0x160], rax
       movzx    rax, byte  ptr [rbp-0x70]
       mov      dword ptr [rbp-0x164], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x170], rax
       mov      rcx, gword ptr [rbp-0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x178], rax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xB0], xmm0
       mov      rax, gword ptr [rbp-0x178]
       mov      gword ptr [rsp+0x20], rax
 
G_M000_IG25:                ;; offset=0x07AC
       vmovdqu  xmm0, xmmword ptr [rbp-0xB0]
       vmovdqu  xmmword ptr [rbp-0x2E0], xmm0
 
G_M000_IG26:                ;; offset=0x07BC
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x2E0]
       mov      qword ptr [rsp+0x28], rax
       mov      rdx, gword ptr [rbp-0x160]
       mov      r8d, dword ptr [rbp-0x164]
       mov      r9, gword ptr [rbp-0x170]
       mov      rcx, gword ptr [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteTrimmedSplit(Lokad.Lython.Frontend.ExecutableTrimmedSplit,Lokad.Lython.Runtime.Text.PyString,byte,Lokad.Lython.LythonSourceSpan,Lokad.Lython.LythonSourceSpan,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x2E8], rax
       mov      rdx, gword ptr [rbp-0x2E8]
       lea      rcx, [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       mov      rax, bword ptr [rbp+0x10]
       add      dword ptr [rax+0x38], 3
       jmp      G_M000_IG42
 
G_M000_IG27:                ;; offset=0x0819
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x110], rax
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG28:                ;; offset=0x082C
       vmovdqu  xmm0, xmmword ptr [rax+0x48]
       vmovdqu  xmmword ptr [rbp-0x2F8], xmm0
 
G_M000_IG29:                ;; offset=0x0839
       lea      rdx, [rbp-0x2F8]
       lea      rcx, [rbp-0x120]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG30:                ;; offset=0x084D
       vmovdqu  xmm0, xmmword ptr [rbp-0x120]
       vmovdqu  xmmword ptr [rbp-0x308], xmm0
 
G_M000_IG31:                ;; offset=0x085D
       mov      rax, gword ptr [rbp-0x08]
       mov      gword ptr [rsp+0x20], rax
       mov      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rsp+0x28], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x38], rax
       lea      r8, [rbp-0x308]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      r9, bword ptr [rax+0x38]
       mov      rdx, gword ptr [rbp-0x110]
       mov      rcx, gword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryConsumePrivateStringResult(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG42
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0x128], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x12C], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x30C], eax
       mov      r9d, dword ptr [rbp-0x30C]
       lea      rdx, [rbp-0x140]
       mov      r8d, dword ptr [rbp-0x12C]
       mov      rcx, bword ptr [rbp-0x128]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG32:                ;; offset=0x090F
       vmovdqu  xmm0, xmmword ptr [rbp-0x140]
       vmovdqu  xmmword ptr [rbp-0x320], xmm0
 
G_M000_IG33:                ;; offset=0x091F
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x328], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x20], rax
       lea      rax, [rbp-0xB8]
       mov      qword ptr [rsp+0x28], rax
       mov      r9, gword ptr [rbp-0x328]
       lea      r8, [rbp-0x320]
       mov      rdx, gword ptr [rbp-0x48]
       mov      rcx, gword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG34
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      G_M000_IG51
 
G_M000_IG34:                ;; offset=0x0975
       lea      rcx, [rbp-0x28]
       mov      rdx, gword ptr [rbp-0xB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       jmp      G_M000_IG42
 
G_M000_IG35:                ;; offset=0x098B
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG36:                ;; offset=0x098F
       vmovdqu  xmm0, xmmword ptr [rax+0x48]
       vmovdqu  xmmword ptr [rbp-0x338], xmm0
 
G_M000_IG37:                ;; offset=0x099C
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x20], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x30], rax
       lea      r8, [rbp-0x338]
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, gword ptr [rbp-0x08]
       mov      r9d, dword ptr [rbp-0x0C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeBuiltinFromSlots(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG41
       lea      rcx, [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x340], rax
       mov      rdx, gword ptr [rbp-0x340]
       mov      rcx, 0x7FF9D74F0AF8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xC0], rax
       cmp      gword ptr [rbp-0xC0], 0
       je       G_M000_IG42
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ExceptionRegions():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableExceptionRegion]:this]
       mov      gword ptr [rbp-0x348], rax
       mov      rcx, gword ptr [rbp-0x348]
       mov      r11, 0x7FF9D7091C50
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       test     eax, eax
       jne      SHORT G_M000_IG40
 
G_M000_IG38:                ;; offset=0x0A45
       mov      rcx, gword ptr [rbp-0xC0]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG39:                ;; offset=0x0A52
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG40:                ;; offset=0x0A58
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:set_Failure(Lokad.Lython.Runtime.LythonRuntimeException):this]
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      G_M000_IG51
 
G_M000_IG41:                ;; offset=0x0A73
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x20], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0x08]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      r9, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG42
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      G_M000_IG51
 
G_M000_IG42:                ;; offset=0x0AA0
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       test     eax, eax
       je       G_M000_IG46
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 15
       jne      G_M000_IG46
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0xE8], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x358], rax
       mov      rdx, gword ptr [rbp-0x358]
       mov      rcx, gword ptr [rbp-0xE8]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x35C], eax
       mov      edx, dword ptr [rbp-0x35C]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0xF0], rax
 
G_M000_IG43:                ;; offset=0x0B8B
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       mov      dword ptr [rbp-0x360], eax
       mov      r9d, dword ptr [rbp-0x360]
       lea      rdx, [rbp-0x100]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      rcx, bword ptr [rbp-0xF0]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG44:                ;; offset=0x0BBC
       vmovdqu  xmm0, xmmword ptr [rbp-0x100]
       vmovdqu  xmmword ptr [rbp-0x370], xmm0
 
G_M000_IG45:                ;; offset=0x0BCC
       lea      rcx, [rbp-0x370]
       call     [System.MemoryExtensions:Reverse[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       jmp      SHORT G_M000_IG49
 
G_M000_IG46:                ;; offset=0x0BDB
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG53
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x388], rax
 
G_M000_IG47:                ;; offset=0x0C09
       vmovdqu  xmm0, xmmword ptr [rbp-0x28]
       vmovdqu  xmmword ptr [rbp-0x380], xmm0
 
G_M000_IG48:                ;; offset=0x0C16
       mov      rdx, bword ptr [rbp-0x388]
       lea      r8, [rbp-0x380]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
 
G_M000_IG49:                ;; offset=0x0C2E
       mov      eax, 1
 
G_M000_IG50:                ;; offset=0x0C33
       vzeroupper 
       add      rsp, 976
       pop      rbp
       ret      
 
G_M000_IG51:                ;; offset=0x0C3F
       mov      eax, dword ptr [rbp-0x2C]
 
G_M000_IG52:                ;; offset=0x0C42
       vzeroupper 
       add      rsp, 976
       pop      rbp
       ret      
 
G_M000_IG53:                ;; offset=0x0C4E
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG54:                ;; offset=0x0C54
       sub      rsp, 72
 
G_M000_IG55:                ;; offset=0x0C58
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
       nop      
 
G_M000_IG56:                ;; offset=0x0C69
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG57:                ;; offset=0x0C71
       sub      rsp, 72
 
G_M000_IG58:                ;; offset=0x0C75
       mov      gword ptr [rbp-0x220], rcx
       mov      rdx, gword ptr [rbp-0x220]
       mov      rcx, 0x7FF9D7192168
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x228], rax
       mov      rax, gword ptr [rbp-0x228]
       mov      gword ptr [rbp-0x230], rax
       cmp      gword ptr [rbp-0x228], 0
       jne      SHORT G_M000_IG59
       xor      eax, eax
       mov      dword ptr [rbp-0x234], eax
       jmp      SHORT G_M000_IG60
 
G_M000_IG59:                ;; offset=0x0CBC
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x350], rax
       mov      rdx, gword ptr [rbp-0x350]
       lea      r8, [rbp-0xC8]
       mov      rcx, gword ptr [rbp-0x230]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       setne    al
       movzx    rax, al
       mov      dword ptr [rbp-0x234], eax
 
G_M000_IG60:                ;; offset=0x0CF8
       mov      eax, dword ptr [rbp-0x234]
 
G_M000_IG61:                ;; offset=0x0CFE
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG62:                ;; offset=0x0D06
       sub      rsp, 72
 
G_M000_IG63:                ;; offset=0x0D0A
       mov      gword ptr [rbp-0x240], rcx
       mov      rcx, gword ptr [rbp-0xC8]
       call     CORINFO_HELP_THROW
       int3     
 
; Total bytes of code 3358

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInstructionPrefix(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref,byref,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int (Tier1-OSR)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1-OSR code
; OSR variant for entry point 0x102a
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 2
; 45 inlinees with PGO data; 274 single block inlinees; 58 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rax
       mov      rax, qword ptr [rbp]
       push     rax
       sub      rsp, 928
       mov      qword ptr [rsp+0xFA8], r15
       mov      qword ptr [rsp+0xFA0], r14
       mov      qword ptr [rsp+0xF98], r13
       mov      qword ptr [rsp+0xF90], r12
       mov      qword ptr [rsp+0xF88], rdi
       mov      qword ptr [rsp+0xF80], rsi
       mov      qword ptr [rsp+0xF78], rbx
       lea      rbp, [rsp+0x3A0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x320], xmm4
       mov      rax, -720
 
G_M000_IG511:                ;; offset=0x0063
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG511
       mov      qword ptr [rbp-0x40], rax
       mov      rcx, bword ptr [rbp+0xC20]
       mov      r9, gword ptr [rbp+0xC28]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      eax, dword ptr [rbp+0xC38]
 
G_M000_IG02:                ;; offset=0x009A
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG491
 
G_M000_IG03:                ;; offset=0x00A7
       cmp      dword ptr [rbp+0xBCC], 0
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x00B0
       mov      rcx, bword ptr [rbp+0xC20]
       inc      dword ptr [rcx+0x10]
 
G_M000_IG05:                ;; offset=0x00BA
       mov      rcx, bword ptr [rbp+0xC20]
       mov      edx, dword ptr [rcx+0x10]
       mov      r8, gword ptr [rbp+0xBD0]
       mov      ebx, dword ptr [r8+0x08]
       cmp      edx, ebx
       jge      G_M000_IG489
 
G_M000_IG06:                ;; offset=0x00D7
       xor      edx, edx
       mov      dword ptr [rbp+0xBCC], edx
       mov      edx, dword ptr [rcx+0x10]
       cmp      edx, ebx
       jae      G_M000_IG497
       mov      r8, gword ptr [rbp+0xBD0]
       shl      rdx, 5
       lea      rdx, bword ptr [r8+rdx+0x10]
       mov      bword ptr [rbp+0xBB8], rdx
       mov      r9, gword ptr [rbp+0xC28]
       mov      rdx, gword ptr [r9+0x98]
       mov      r8, bword ptr [rbp+0xBB8]
       mov      r8, gword ptr [r8]
       mov      r10, gword ptr [rdx+0x88]
       cmp      gword ptr [r10+0x20], 0
       jne      SHORT G_M000_IG09
 
G_M000_IG07:                ;; offset=0x0127
       mov      r10, gword ptr [rdx+0x180]
       test     r10, r10
       je       SHORT G_M000_IG10
 
G_M000_IG08:                ;; offset=0x0133
       cmp      dword ptr [r10+0x20], 0
       setne    r10b
       movzx    r10, r10b
       test     r10d, r10d
       je       SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x0145
       mov      rcx, rdx
       mov      rdx, r8
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG10:                ;; offset=0x0152
       mov      r8, bword ptr [rbp+0xBB8]
       mov      r8d, dword ptr [r8+0x1C]
       cmp      r8d, 73
       ja       G_M000_IG71
 
G_M000_IG11:                ;; offset=0x0167
       mov      r8d, r8d
       lea      rdx, [reloc @RWD00]
       mov      edx, dword ptr [rdx+4*r8]
       lea      rcx, G_M000_IG02
       add      rdx, rcx
       jmp      rdx
 
G_M000_IG12:                ;; offset=0x0181
       mov      rsi, bword ptr [rbp+0xC20]
       mov      rdi, gword ptr [rsi]
       mov      r14, gword ptr [rsi+0x08]
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 2
       je       SHORT G_M000_IG15
 
G_M000_IG13:                ;; offset=0x019E
       cmp      ecx, 25
       je       SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x01A3
       cmp      ecx, 72
       jne      G_M000_IG322
 
G_M000_IG15:                ;; offset=0x01AC
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      r15d, dword ptr [rdx+0x08]
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      r13, gword ptr [rdx]
       cmp      r15d, dword ptr [r14+0x08]
       jae      G_M000_IG484
       mov      edx, r15d
       shl      rdx, 4
       lea      r14, bword ptr [r14+rdx+0x10]
       mov      rdx, gword ptr [r14]
       mov      rcx, 0x2A14B001CE0
       cmp      rdx, gword ptr [rcx]
       je       G_M000_IG46
 
G_M000_IG16:                ;; offset=0x01ED
       mov      rdx, gword ptr [r14]
       mov      rcx, 0x2A14B001CE8
       cmp      rdx, gword ptr [rcx]
       je       G_M000_IG45
 
G_M000_IG17:                ;; offset=0x0203
       cmp      qword ptr [r14+0x08], 0
       jle      G_M000_IG29
 
G_M000_IG18:                ;; offset=0x020E
       mov      rdx, gword ptr [r14]
       mov      rcx, 0x7FF9D7753360
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      r12, rax
       test     r12, r12
       je       G_M000_IG29
 
G_M000_IG19:                ;; offset=0x022D
       mov      eax, dword ptr [r14+0x08]
       dec      eax
       mov      dword ptr [rbp-0x1B4], eax
       mov      rdx, gword ptr [r12+0x08]
       mov      rcx, 0x7FF9D71528A8
       call     [CORINFO_HELP_ISINSTANCEOFARRAY]
       test     rax, rax
       jne      G_M000_IG44
 
G_M000_IG20:                ;; offset=0x0257
       mov      rax, gword ptr [r12+0x08]
       test     rax, rax
       je       SHORT G_M000_IG23
 
G_M000_IG21:                ;; offset=0x0261
       mov      rdx, 0x7FF9D77C2CB8
       cmp      qword ptr [rax], rdx
       je       SHORT G_M000_IG23
 
G_M000_IG22:                ;; offset=0x0270
       xor      rax, rax
 
G_M000_IG23:                ;; offset=0x0272
       test     rax, rax
       jne      G_M000_IG41
 
G_M000_IG24:                ;; offset=0x027B
       cmp      dword ptr [rbp-0x1B4], 0
       jne      G_M000_IG323
       mov      r8, r12
       mov      rcx, 0x7FF9D7864B98
       cmp      qword ptr [r8], rcx
       jne      G_M000_IG324
       lea      r12, bword ptr [r8+0x28]
 
G_M000_IG25:                ;; offset=0x02A2
       mov      rdx, gword ptr [r12]
       mov      rcx, 0x2A14B001CE0
       cmp      rdx, gword ptr [rcx]
       jne      G_M000_IG43
 
G_M000_IG26:                ;; offset=0x02B9
       mov      rcx, 0x7FF9D753B3F0
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x328], rax
       mov      rdx, qword ptr [r12+0x08]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x1C8], xmm0
       lea      rcx, [rbp-0x1C8]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rax, gword ptr [rbp-0x328]
       lea      rcx, bword ptr [rax+0x08]
       mov      rdx, gword ptr [rbp-0x1C8]
       call     CORINFO_HELP_ASSIGN_REF
       mov      r8d, dword ptr [rbp-0x1C0]
       mov      rax, gword ptr [rbp-0x328]
       mov      dword ptr [rax+0x10], r8d
       mov      rdx, rax
       mov      gword ptr [rbp-0x330], rdx
       mov      r8, 0x2A14B001CE0
       mov      r8, gword ptr [r8]
       mov      rcx, r12
       call     System.Threading.Interlocked:CompareExchangeObject(byref,System.Object,System.Object):System.Object
       mov      rcx, 0x2A14B001CE0
       cmp      rax, gword ptr [rcx]
       je       G_M000_IG42
 
G_M000_IG27:                ;; offset=0x0348
       test     rax, rax
       je       G_M000_IG326
       mov      rdx, rax
 
G_M000_IG28:                ;; offset=0x0354
       mov      rcx, r14
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r14+0x08], rcx
 
G_M000_IG29:                ;; offset=0x0362
       mov      r12, gword ptr [r14]
 
G_M000_IG30:                ;; offset=0x0365
       test     r12, r12
       jne      G_M000_IG47
 
G_M000_IG31:                ;; offset=0x036E
       mov      r14, r12
 
G_M000_IG32:                ;; offset=0x0371
       test     r14, r14
       jne      SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x0376
       mov      rcx, rdi
       mov      edx, r15d
       mov      r8, r13
       mov      r9, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r14, rax
 
G_M000_IG34:                ;; offset=0x038F
       mov      rcx, bword ptr [rbp+0xBB8]
       cmp      dword ptr [rcx+0x18], 0
       jl       G_M000_IG67
 
G_M000_IG35:                ;; offset=0x03A0
       lea      rdi, bword ptr [rsi+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       G_M000_IG66
 
G_M000_IG36:                ;; offset=0x03B7
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rcx
       jb       G_M000_IG66
 
G_M000_IG37:                ;; offset=0x03CB
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      r15d, dword ptr [rcx+0x18]
 
G_M000_IG38:                ;; offset=0x03D6
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      r13d, dword ptr [rcx+0x18]
       cmp      r13d, dword ptr [rdi+0x40]
       jge      SHORT G_M000_IG40
 
G_M000_IG39:                ;; offset=0x03E7
       mov      rcx, rdi
       mov      edx, r13d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG40:                ;; offset=0x03F3
       mov      rcx, gword ptr [rdi]
       cmp      r15d, dword ptr [rcx+0x08]
       jae      G_M000_IG484
       mov      edx, r15d
       shl      rdx, 4
       lea      r15, bword ptr [rcx+rdx+0x10]
       mov      rcx, r15
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       xor      r9d, r9d
       mov      qword ptr [r15+0x08], r9
       mov      dword ptr [rdi+0x40], r13d
       jmp      G_M000_IG02
 
G_M000_IG41:                ;; offset=0x0427
       mov      r12d, dword ptr [rbp-0x1B4]
       cmp      r12d, dword ptr [rax+0x08]
       jae      G_M000_IG484
       mov      ecx, r12d
       shl      rcx, 4
       lea      r12, bword ptr [rax+rcx+0x10]
       jmp      G_M000_IG25
 
G_M000_IG42:                ;; offset=0x0449
       mov      r12, gword ptr [rbp-0x330]
       mov      rdx, r12
       jmp      G_M000_IG28
 
G_M000_IG43:                ;; offset=0x0458
       mov      rcx, 0x7FF9D77F2610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rdx, rax
       jmp      G_M000_IG28
 
G_M000_IG44:                ;; offset=0x0470
       mov      r12d, dword ptr [rbp-0x1B4]
       cmp      r12d, dword ptr [rax+0x08]
       jae      G_M000_IG484
       mov      edx, r12d
       mov      rdx, gword ptr [rax+8*rdx+0x10]
       jmp      G_M000_IG28
 
G_M000_IG45:                ;; offset=0x048E
       mov      rcx, 0x7FF9D7186D68
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
       vmovsd   xmm0, qword ptr [r14+0x08]
       vmovsd   qword ptr [r12+0x08], xmm0
       mov      rcx, r14
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r14+0x08], rcx
       jmp      G_M000_IG30
 
G_M000_IG46:                ;; offset=0x04C3
       mov      rcx, 0x7FF9D753B3F0
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
       mov      rdx, qword ptr [r14+0x08]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x1B0], xmm0
       lea      rcx, [rbp-0x1B0]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rcx, bword ptr [r12+0x08]
       mov      rdx, gword ptr [rbp-0x1B0]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rbp-0x1A8]
       mov      dword ptr [r12+0x10], ecx
       mov      rcx, r14
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r14+0x08], rcx
       jmp      G_M000_IG30
 
G_M000_IG47:                ;; offset=0x0524
       mov      rcx, 0x7FF9D77E4838
       cmp      qword ptr [r12], rcx
       jne      G_M000_IG31
 
G_M000_IG48:                ;; offset=0x0538
       mov      rcx, gword ptr [r12+0x10]
       test     rcx, rcx
       je       SHORT G_M000_IG50
 
G_M000_IG49:                ;; offset=0x0542
       cmp      byte  ptr [rcx+0x101], 0
       jne      G_M000_IG57
 
G_M000_IG50:                ;; offset=0x054F
       mov      rcx, gword ptr [r12+0x10]
       test     rcx, rcx
       je       SHORT G_M000_IG52
 
G_M000_IG51:                ;; offset=0x0559
       movzx    rcx, byte  ptr [rcx+0xFF]
       test     ecx, ecx
       jne      SHORT G_M000_IG57
 
G_M000_IG52:                ;; offset=0x0564
       cmp      byte  ptr [r12+0x28], 0
       je       SHORT G_M000_IG55
 
G_M000_IG53:                ;; offset=0x056C
       cmp      gword ptr [r12+0x08], 0
       jne      SHORT G_M000_IG55
 
G_M000_IG54:                ;; offset=0x0574
       mov      rcx, 0x7FF9D753B3F0
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      rdx, qword ptr [r12+0x20]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x1E0], xmm0
       lea      rcx, [rbp-0x1E0]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rcx, bword ptr [r14+0x08]
       mov      rdx, gword ptr [rbp-0x1E0]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rbp-0x1D8]
       mov      dword ptr [r14+0x10], ecx
       lea      rcx, bword ptr [r12+0x08]
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG55:                ;; offset=0x05CB
       mov      r14, gword ptr [r12+0x08]
 
G_M000_IG56:                ;; offset=0x05D0
       jmp      G_M000_IG32
 
G_M000_IG57:                ;; offset=0x05D5
       mov      r14, gword ptr [r12+0x10]
       mov      rcx, gword ptr [r14+0x08]
       test     rcx, rcx
       jne      G_M000_IG62
 
G_M000_IG58:                ;; offset=0x05E7
       mov      rcx, 0x7FF9D719DDF0
       call     CORINFO_HELP_NEWSFAST
       mov      rcx, rax
       mov      gword ptr [rbp-0x338], rcx
       mov      rdx, 0x2A14B000068
       mov      rdx, gword ptr [rdx]
       mov      rax, rdx
       mov      gword ptr [rbp-0x360], rax
       mov      rdx, rax
       lea      rcx, bword ptr [rcx+0x18]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, gword ptr [rbp-0x360]
       call     [System.Collections.Generic.NonRandomizedStringEqualityComparer:GetStringComparer(System.Object):System.Collections.Generic.IEqualityComparer`1[System.String]]
       test     rax, rax
       je       SHORT G_M000_IG60
 
G_M000_IG59:                ;; offset=0x0635
       mov      rcx, gword ptr [rbp-0x338]
       lea      rcx, bword ptr [rcx+0x18]
       mov      rdx, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG60:                ;; offset=0x0648
       lea      rcx, bword ptr [r14+0x08]
       test     rcx, rcx
       je       G_M000_IG325
       mov      rdx, gword ptr [rbp-0x338]
       xor      r8, r8
       call     System.Threading.Interlocked:CompareExchangeObject(byref,System.Object,System.Object):System.Object
       mov      rcx, rax
       test     rcx, rcx
       jne      SHORT G_M000_IG62
 
G_M000_IG61:                ;; offset=0x066C
       mov      r14, gword ptr [rbp-0x338]
       mov      rcx, r14
 
G_M000_IG62:                ;; offset=0x0676
       mov      rdx, gword ptr [r12+0x18]
       lea      r8, [rbp-0x1D0]
       mov      r11, 0x7FF9D7091D00
       call     [r11]System.Collections.Generic.IReadOnlyDictionary`2[System.__Canon,System.__Canon]:TryGetValue(System.__Canon,byref):bool:this
       test     eax, eax
       jne      SHORT G_M000_IG65
 
G_M000_IG63:                ;; offset=0x0693
       xor      r14, r14
 
G_M000_IG64:                ;; offset=0x0696
       xor      rcx, rcx
       mov      gword ptr [rbp-0x1D0], rcx
       jmp      G_M000_IG56
 
G_M000_IG65:                ;; offset=0x06A4
       mov      r14, gword ptr [rbp-0x1D0]
       jmp      SHORT G_M000_IG64
 
G_M000_IG66:                ;; offset=0x06AD
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      r15d, dword ptr [rcx+0x14]
       jmp      G_M000_IG38
 
G_M000_IG67:                ;; offset=0x06BD
       mov      gword ptr [rbp-0x2E0], r14
       xor      r9d, r9d
       mov      qword ptr [rbp-0x2D8], r9
       lea      r9, [rbp-0x2E0]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG68:                ;; offset=0x06F1
       mov      rsi, bword ptr [rbp+0xC20]
       mov      rcx, gword ptr [rsi]
       mov      rax, gword ptr [rcx+0x30]
       mov      rdi, rax
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG484
       mov      ecx, eax
       mov      rcx, gword ptr [rdi+8*rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      rdx, rax
       lea      rcx, [rbp-0x200]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x200]
       mov      rcx, rsi
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG69:                ;; offset=0x0758
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG153
 
G_M000_IG70:                ;; offset=0x0766
       mov      rsi, bword ptr [rbp+0xC20]
       mov      rcx, gword ptr [rsi]
       mov      rdi, gword ptr [rcx+0xA8]
       mov      rcx, bword ptr [rbp+0xBB8]
       xor      edx, edx
       mov      r8, 0x2C171C94708
       call     [Lokad.Lython.Frontend.ExecutableInstruction:ReadPrimaryOperand(int,System.String):int:this]
       mov      edx, eax
       mov      rcx, rdi
       mov      r11, 0x7FF9D7091CF8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG388
       jmp      G_M000_IG387
 
G_M000_IG71:                ;; offset=0x07B4
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x60], ymm0
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
       lea      rcx, [rbp-0x60]
       mov      edx, 27
       mov      r8d, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
 
G_M000_IG72:                ;; offset=0x07D7
       vmovdqu  ymm0, ymmword ptr [rbp-0x60]
       vmovdqu  ymmword ptr [rbp+0xA58], ymm0
       mov      rcx, qword ptr [rbp-0x40]
       mov      qword ptr [rbp+0xA78], rcx
 
G_M000_IG73:                ;; offset=0x07EF
       mov      ecx, dword ptr [rbp+0xA68]
       mov      edx, dword ptr [rbp+0xA78]
       cmp      ecx, edx
       ja       G_M000_IG346
       mov      rax, bword ptr [rbp+0xA70]
       mov      r8d, ecx
       lea      rax, bword ptr [rax+2*r8]
       sub      edx, ecx
       cmp      edx, 27
       jb       G_M000_IG486
 
G_M000_IG74:                ;; offset=0x081C
       vmovups  ymm0, ymmword ptr [reloc @RWD296]
       vmovups  ymmword ptr [rax], ymm0
       vmovups  xmm0, xmmword ptr [reloc @RWD328]
       vmovups  xmmword ptr [rax+0x20], xmm0
       mov      dword ptr [rax+0x30], 0x3A0065
       mov      word  ptr [rax+0x34], 32
       mov      ecx, dword ptr [rbp+0xA68]
       add      ecx, 27
       mov      dword ptr [rbp+0xA68], ecx
 
G_M000_IG75:                ;; offset=0x0851
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x1C]
       lea      rcx, [rbp+0xA58]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rdi, rax
       lea      rcx, [rbp+0xA58]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      rdx, rax
       mov      rcx, rdi
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rdi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG76:                ;; offset=0x089C
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG153
 
G_M000_IG77:                ;; offset=0x08AA
       cmp      byte  ptr [rbp+0xC38], 0
       je       G_M000_IG380
       jmp      G_M000_IG373
 
G_M000_IG78:                ;; offset=0x08BC
       mov      r8, gword ptr [rbp+0xC30]
       cmp      byte  ptr [r8+0xF9], 0
       je       G_M000_IG02
       jmp      G_M000_IG385
 
G_M000_IG79:                ;; offset=0x08D6
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG153
 
G_M000_IG80:                ;; offset=0x08E4
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      edi, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      r9d, eax
       mov      r8d, edi
       mov      rcx, rsi
       lea      rdx, [rbp+0xAF8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      esi, dword ptr [rcx+0x10]
       inc      esi
       mov      rdx, gword ptr [rbp+0xC30]
       mov      rdi, gword ptr [rdx+0x70]
       cmp      byte  ptr [rdx+0x101], 0
       jne      G_M000_IG360
       jmp      G_M000_IG357
 
G_M000_IG81:                ;; offset=0x0945
       test     r15d, r15d
       je       G_M000_IG370
       jmp      G_M000_IG361
 
G_M000_IG82:                ;; offset=0x0953
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      ebx, eax
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      dword ptr [rcx+0x60], ebx
       jne      G_M000_IG296
 
G_M000_IG83:                ;; offset=0x0972
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       mov      r8, gword ptr [rbp+0xC28]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      rsi, rax
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x0C]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      r8, gword ptr [rbp+0xC28]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      rdi, rax
       mov      rdx, rsi
       mov      rcx, 0x7FF9D775AC10
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       G_M000_IG437
       jmp      G_M000_IG432
 
G_M000_IG84:                ;; offset=0x09D7
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rbx, gword ptr [rcx+0x08]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG484
       mov      ecx, eax
       shl      rcx, 4
       cmp      gword ptr [rbx+rcx+0x10], 0
       jne      G_M000_IG02
       jmp      G_M000_IG327
 
G_M000_IG85:                ;; offset=0x0A0F
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      esi, eax
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r9d, eax
       mov      r8d, esi
       mov      rcx, rbx
       lea      rdx, [rbp+0xBA0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       je       G_M000_IG347
 
G_M000_IG86:                ;; offset=0x0A60
       lea      r9, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
 
G_M000_IG87:                ;; offset=0x0A68
       mov      rdx, gword ptr [rbp+0xC30]
       mov      rax, rdx
       test     rax, rax
       jne      SHORT G_M000_IG89
 
G_M000_IG88:                ;; offset=0x0A77
       mov      r10, gword ptr [rbp+0xC28]
       mov      rax, r10
 
G_M000_IG89:                ;; offset=0x0A81
       mov      bword ptr [rbp-0x2F0], r9
       mov      dword ptr [rbp-0x2E8], r8d
 
G_M000_IG90:                ;; offset=0x0A8F
       vmovdqu  xmm0, xmmword ptr [rbp+0xBA0]
       vmovdqu  xmmword ptr [rbp-0x2E0], xmm0
 
G_M000_IG91:                ;; offset=0x0A9F
       lea      rcx, [rbp-0x2F0]
       lea      r8, [rbp-0x2E0]
       mov      r9, gword ptr [rax+0x98]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG02
 
G_M000_IG92:                ;; offset=0x0AC6
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rax, gword ptr [rcx]
       mov      rbx, gword ptr [rax+0x30]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG484
       mov      ecx, eax
       mov      rdx, gword ptr [rbx+8*rcx+0x10]
       mov      rbx, rdx
       test     rbx, rbx
       je       SHORT G_M000_IG94
 
G_M000_IG93:                ;; offset=0x0AF9
       mov      rcx, 0x7FF9D758EAB0
       cmp      qword ptr [rbx], rcx
       jne      G_M000_IG345
 
G_M000_IG94:                ;; offset=0x0B0C
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rsi, gword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      edi, eax
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r14d, eax
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       sub      r14d, eax
       test     rsi, rsi
       jne      G_M000_IG99
 
G_M000_IG95:                ;; offset=0x0B4F
       or       edi, r14d
       jne      G_M000_IG346
       xor      rdx, rdx
       xor      ecx, ecx
 
G_M000_IG96:                ;; offset=0x0B5C
       mov      r8, bword ptr [rbp+0xBB8]
       cmp      dword ptr [r8+0x0C], 0
       setne    r8b
       movzx    r8, r8b
       mov      rax, gword ptr [rbp+0xC30]
       mov      r9, rax
       test     r9, r9
       jne      SHORT G_M000_IG98
 
G_M000_IG97:                ;; offset=0x0B7F
       mov      r10, gword ptr [rbp+0xC28]
       mov      r9, r10
 
G_M000_IG98:                ;; offset=0x0B89
       mov      bword ptr [rbp-0x2F0], rdx
       mov      dword ptr [rbp-0x2E8], ecx
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rdx]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0x2F0]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      dword ptr [rcx+0x60], eax
       jmp      G_M000_IG02
 
G_M000_IG99:                ;; offset=0x0BD1
       mov      edx, edi
       mov      ecx, r14d
       add      rcx, rdx
       mov      r8d, dword ptr [rsi+0x08]
       cmp      rcx, r8
       ja       G_M000_IG346
       shl      rdx, 4
       lea      rdx, bword ptr [rsi+rdx+0x10]
       mov      ecx, r14d
       jmp      G_M000_IG96
 
G_M000_IG100:                ;; offset=0x0BF7
       cmp      gword ptr [rbp+0xC30], 0
       je       SHORT G_M000_IG102
 
G_M000_IG101:                ;; offset=0x0C01
       mov      rcx, bword ptr [rbp+0xC20]
       mov      ebx, dword ptr [rcx+0x60]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      ebx, eax
       je       G_M000_IG411
 
G_M000_IG102:                ;; offset=0x0C20
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rdx+0x10]
       mov      rdx, gword ptr [rbx]
       cmp      esi, dword ptr [rdx+0x08]
       jae      G_M000_IG484
       mov      eax, esi
       shl      rax, 4
       lea      rdi, bword ptr [rdx+rax+0x10]
       mov      rdx, gword ptr [rdi]
       mov      rax, 0x2A14B001CE0
       cmp      rdx, gword ptr [rax]
       je       G_M000_IG186
 
G_M000_IG103:                ;; offset=0x0C62
       mov      rdx, gword ptr [rdi]
       mov      rax, 0x2A14B001CE8
       cmp      rdx, gword ptr [rax]
       je       G_M000_IG185
 
G_M000_IG104:                ;; offset=0x0C78
       cmp      qword ptr [rdi+0x08], 0
       jle      SHORT G_M000_IG109
 
G_M000_IG105:                ;; offset=0x0C7F
       mov      rdx, gword ptr [rdi]
       mov      rcx, 0x7FF9D7753360
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      r14, rax
       test     r14, r14
       je       SHORT G_M000_IG109
 
G_M000_IG106:                ;; offset=0x0C9A
       mov      r15d, dword ptr [rdi+0x08]
       dec      r15d
       mov      rdx, gword ptr [r14+0x08]
       mov      rcx, 0x7FF9D71528A8
       call     [CORINFO_HELP_ISINSTANCEOFARRAY]
       test     rax, rax
       jne      G_M000_IG184
 
G_M000_IG107:                ;; offset=0x0CBE
       mov      rcx, r14
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.PyTuple:WritableValueSlot(int):byref:this]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishSharedInteger():System.Object:this]
 
G_M000_IG108:                ;; offset=0x0CD3
       mov      rcx, rdi
       mov      rdx, rax
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
 
G_M000_IG109:                ;; offset=0x0CE4
       mov      r14, gword ptr [rdi]
 
G_M000_IG110:                ;; offset=0x0CE7
       test     r14, r14
       je       G_M000_IG419
       mov      rdx, 0x7FF9D7838AB0
       cmp      qword ptr [r14], rdx
       jne      G_M000_IG187
 
G_M000_IG111:                ;; offset=0x0D03
       mov      rbx, r14
       mov      eax, dword ptr [rbx+0x34]
       cmp      eax, dword ptr [rbx+0x30]
       jne      G_M000_IG204
 
G_M000_IG112:                ;; offset=0x0D12
       xor      rbx, rbx
 
G_M000_IG113:                ;; offset=0x0D14
       xor      esi, esi
 
G_M000_IG114:                ;; offset=0x0D16
       test     rbx, rbx
       setne    r9b
       movzx    r9, r9b
       test     r9d, r9d
       jne      G_M000_IG217
 
G_M000_IG115:                ;; offset=0x0D2A
       xor      rdx, rdx
       xor      r8d, r8d
 
G_M000_IG116:                ;; offset=0x0D2F
       test     r9d, r9d
       je       G_M000_IG218
 
G_M000_IG117:                ;; offset=0x0D38
       mov      gword ptr [rbp+0xB58], rdx
       mov      qword ptr [rbp+0xB60], r8
       lea      r9, [rbp+0xB58]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG118:                ;; offset=0x0D6D
       movzx    rcx, byte  ptr [rbp+0xC38]
       mov      dword ptr [rsp+0x20], ecx
       lea      rcx, [rbp+0xB90]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecutePreparedOperation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG153
 
G_M000_IG119:                ;; offset=0x0DAE
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG352
 
G_M000_IG120:                ;; offset=0x0DBB
       vmovdqu  xmm0, xmmword ptr [rbp+0xB90]
       vmovdqu  xmmword ptr [rbp+0xB08], xmm0
 
G_M000_IG121:                ;; offset=0x0DCB
       mov      rsi, gword ptr [rbp+0xB08]
       test     rsi, rsi
       je       G_M000_IG02
       jmp      G_M000_IG348
 
G_M000_IG122:                ;; offset=0x0DE0
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG153
 
G_M000_IG123:                ;; offset=0x0DEE
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rax, gword ptr [rcx]
       mov      r12, gword ptr [rax+0x38]
       mov      rsi, r12
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      r10d, dword ptr [rsi+0x08]
       cmp      eax, r10d
       jae      G_M000_IG484
       mov      ecx, eax
       mov      rcx, gword ptr [rsi+8*rcx+0x10]
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rdx]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveName(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      rdx, rax
       lea      rcx, [rbp-0x220]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x220]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG124:                ;; offset=0x0E74
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rsi, gword ptr [rcx]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      edx, eax
       mov      rcx, rsi
       mov      r8, bword ptr [rbp+0xBB8]
       mov      r8, gword ptr [r8]
       mov      r9, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rdx, rax
       lea      rcx, [rbp-0x210]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x210]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG125:                ;; offset=0x0EDE
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      gword ptr [rcx+0x40], 0
       jne      SHORT G_M000_IG127
 
G_M000_IG126:                ;; offset=0x0EEC
       mov      r9, gword ptr [rbp+0xC28]
       mov      gword ptr [rsp+0x20], r9
       mov      rcx, gword ptr [rcx]
       mov      rsi, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rsi+0x18]
       mov      r8d, dword ptr [rsi+0x10]
       mov      r9d, dword ptr [rsi+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      G_M000_IG328
 
G_M000_IG127:                ;; offset=0x0F1C
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      r8d, eax
       lea      r9, [rbp+0xBB0]
       mov      qword ptr [rsp+0x20], r9
       mov      r9, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [r9]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      rcx, bword ptr [rbp+0xC20]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryLoadClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       jne      G_M000_IG329
       jmp      G_M000_IG153
 
G_M000_IG128:                ;; offset=0x0F63
       xor      rcx, rcx
       mov      gword ptr [rbp-0x2D0], rcx
       mov      rcx, gword ptr [rbp+0xC28]
       mov      rdx, gword ptr [rcx+0x98]
       mov      rdx, gword ptr [rdx+0xE8]
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       mov      rdx, r14
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:FindValue(System.__Canon):byref:this]
       test     rax, rax
       je       SHORT G_M000_IG131
 
G_M000_IG129:                ;; offset=0x0F94
       mov      rcx, gword ptr [rax]
       mov      gword ptr [rbp-0x2D0], rcx
       mov      ecx, 1
 
G_M000_IG130:                ;; offset=0x0FA3
       test     ecx, ecx
       jne      G_M000_IG238
       jmp      G_M000_IG462
 
G_M000_IG131:                ;; offset=0x0FB0
       xor      rcx, rcx
       mov      gword ptr [rbp-0x2D0], rcx
 
G_M000_IG132:                ;; offset=0x0FB9
       jmp      SHORT G_M000_IG130
 
G_M000_IG133:                ;; offset=0x0FBB
       cmp      esi, dword ptr [rax+0x08]
       jae      G_M000_IG484
       mov      edx, esi
       mov      rcx, gword ptr [rax+8*rdx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      rdx, rax
       jmp      G_M000_IG239
 
G_M000_IG134:                ;; offset=0x0FD9
       cmp      esi, r15d
       jae      G_M000_IG484
       mov      eax, esi
       shl      rax, 4
       add      rax, r14
       mov      rdx, gword ptr [rax]
       mov      r8, 0x2A14B001CE0
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG146
 
G_M000_IG135:                ;; offset=0x1001
       mov      rdx, gword ptr [rax]
       mov      r8, 0x2A14B001CE8
       cmp      rdx, gword ptr [r8]
       je       SHORT G_M000_IG145
 
G_M000_IG136:                ;; offset=0x1013
       cmp      qword ptr [rax+0x08], 0
       je       SHORT G_M000_IG144
 
G_M000_IG137:                ;; offset=0x101A
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
 
G_M000_IG138:                ;; offset=0x1023
       mov      rcx, rax
       cmp      esi, dword ptr [rdi+0xD8]
       jge      SHORT G_M000_IG147
 
G_M000_IG139:                ;; offset=0x102E
       test     rcx, rcx
       je       SHORT G_M000_IG142
 
G_M000_IG140:                ;; offset=0x1033
       mov      rax, 0x7FF9D77E4838
       cmp      qword ptr [rcx], rax
       jne      SHORT G_M000_IG142
 
G_M000_IG141:                ;; offset=0x1042
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      rcx, rax
 
G_M000_IG142:                ;; offset=0x104B
       test     rcx, rcx
       jne      SHORT G_M000_IG147
 
G_M000_IG143:                ;; offset=0x1050
       mov      rcx, rdi
       mov      edx, r13d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      edx, esi
       mov      rcx, rdi
       mov      r9, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rdx, rax
       jmp      G_M000_IG239
 
G_M000_IG144:                ;; offset=0x107C
       mov      rax, gword ptr [rax]
       jmp      SHORT G_M000_IG138
 
G_M000_IG145:                ;; offset=0x1081
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       jmp      SHORT G_M000_IG138
 
G_M000_IG146:                ;; offset=0x108C
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       jmp      SHORT G_M000_IG138
 
G_M000_IG147:                ;; offset=0x1097
       test     rcx, rcx
       je       G_M000_IG463
       mov      rdx, rcx
       jmp      G_M000_IG239
 
G_M000_IG148:                ;; offset=0x10A8
       not      r8d
       jmp      G_M000_IG242
 
G_M000_IG149:                ;; offset=0x10B0
       mov      r8, bword ptr [rbp+0xBB8]
       mov      r8d, dword ptr [r8+0x14]
       jmp      G_M000_IG242
 
G_M000_IG150:                ;; offset=0x10C0
       mov      r9d, ecx
       not      r9d
       jmp      G_M000_IG244
 
G_M000_IG151:                ;; offset=0x10CB
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 58
       ja       SHORT G_M000_IG153
 
G_M000_IG152:                ;; offset=0x10DA
       mov      rdx, 0x1FDFFFFFFFFFFFF
       bt       rdx, rcx
       jae      G_M000_IG286
 
G_M000_IG153:                ;; offset=0x10EE
       mov      dword ptr [rbp+0xB28], 6
       jmp      G_M000_IG487
 
G_M000_IG154:                ;; offset=0x10FD
       not      esi
       jmp      G_M000_IG302
 
G_M000_IG155:                ;; offset=0x1104
       mov      rax, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rax+0x14]
       jmp      G_M000_IG302
 
G_M000_IG156:                ;; offset=0x1113
       mov      r14, gword ptr [rdi]
       jmp      G_M000_IG306
 
G_M000_IG157:                ;; offset=0x111B
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG306
 
G_M000_IG158:                ;; offset=0x112C
       mov      rcx, 0x7FF9D753B3F0
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      rdx, qword ptr [rdi+0x08]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x2C8], xmm0
       lea      rcx, [rbp-0x2C8]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rcx, bword ptr [r14+0x08]
       mov      rdx, gword ptr [rbp-0x2C8]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rbp-0x2C0]
       mov      dword ptr [r14+0x10], ecx
       mov      rcx, rdi
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
       jmp      G_M000_IG306
 
G_M000_IG159:                ;; offset=0x118B
       mov      edx, edi
       mov      rcx, 0x7FF9D72700F0
       call     CORINFO_HELP_NEWARR_1_VC
       mov      rdx, rax
       mov      rax, gword ptr [rbp-0x350]
       lea      rcx, bword ptr [rax+0x08]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      G_M000_IG211
 
G_M000_IG160:                ;; offset=0x11B4
       cmp      dword ptr [rdx+0x20], 0
       setne    dl
       movzx    rdx, dl
       test     edx, edx
       je       G_M000_IG214
 
G_M000_IG161:                ;; offset=0x11C6
       mov      rdx, gword ptr [rbp-0x348]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       mov      r10, gword ptr [rbp-0x340]
 
G_M000_IG162:                ;; offset=0x11DA
       mov      r8d, dword ptr [rbp-0x284]
       mov      r9d, edi
       sub      r9d, r8d
       cmp      r9d, 0x1000
       jl       G_M000_IG215
 
G_M000_IG163:                ;; offset=0x11F4
       mov      r11d, 0x1000
 
G_M000_IG164:                ;; offset=0x11FA
       lea      ecx, [rsi+r8]
       mov      edx, ecx
       mov      r9d, r11d
       add      rdx, r9
       mov      r9d, r13d
       cmp      rdx, r9
       ja       G_M000_IG346
       mov      edx, ecx
       add      rdx, r15
       mov      ecx, r8d
       mov      r9d, r11d
       add      rcx, r9
       mov      r9d, edi
       cmp      rcx, r9
       ja       G_M000_IG346
       mov      dword ptr [rbp-0x284], r8d
       mov      ecx, r8d
       add      rcx, bword ptr [rbp-0x358]
       mov      dword ptr [rbp-0x288], r11d
       mov      r8d, r11d
       call     [System.SpanHelpers:Memmove(byref,byref,nuint)]
       mov      r8d, dword ptr [rbp-0x288]
       add      r8d, dword ptr [rbp-0x284]
       mov      ecx, r8d
       cmp      ecx, edi
       mov      dword ptr [rbp-0x284], ecx
       jge      G_M000_IG212
 
G_M000_IG165:                ;; offset=0x126C
       mov      r10, gword ptr [rbp-0x340]
       test     r10, r10
       je       G_M000_IG162
 
G_M000_IG166:                ;; offset=0x127C
       mov      rcx, gword ptr [r10+0x98]
       mov      rdx, gword ptr [rcx+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG161
 
G_M000_IG167:                ;; offset=0x1295
       mov      rdx, gword ptr [rcx+0x180]
       test     rdx, rdx
       jne      G_M000_IG160
 
G_M000_IG168:                ;; offset=0x12A5
       mov      r10, gword ptr [rbp-0x340]
       jmp      G_M000_IG162
 
G_M000_IG169:                ;; offset=0x12B1
       xor      r14, r14
       xor      r15d, r15d
       jmp      G_M000_IG221
 
G_M000_IG170:                ;; offset=0x12BC
       mov      rcx, r12
       jmp      G_M000_IG225
 
G_M000_IG171:                ;; offset=0x12C4
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG102
 
G_M000_IG172:                ;; offset=0x12EE
       mov      dword ptr [rbp+0xBCC], 1
       jmp      G_M000_IG02
 
G_M000_IG173:                ;; offset=0x12FD
       mov      rax, gword ptr [rbp+0xC30]
       mov      r9, rax
       test     r9, r9
       jne      SHORT G_M000_IG175
 
G_M000_IG174:                ;; offset=0x130C
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r9, rdx
 
G_M000_IG175:                ;; offset=0x1316
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, rax
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteFormattedInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      G_M000_IG02
 
G_M000_IG176:                ;; offset=0x1335
       movzx    rax, byte  ptr [rbp+0xC38]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r9, gword ptr [rbp+0xC28]
       test     rdx, rdx
       je       G_M000_IG153
 
G_M000_IG177:                ;; offset=0x135A
       test     al, al
       jne      SHORT G_M000_IG181
 
G_M000_IG178:                ;; offset=0x135E
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG179:                ;; offset=0x1365
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x310], ymm0
 
G_M000_IG180:                ;; offset=0x1372
       lea      r8, [rbp-0x310]
       lea      rdx, [rbp+0xB18]
       mov      rcx, gword ptr [rbp+0xC30]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       mov      rbx, gword ptr [rbp+0xB18]
       test     rbx, rbx
       je       G_M000_IG02
       jmp      G_M000_IG338
 
G_M000_IG181:                ;; offset=0x13A5
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG182:                ;; offset=0x13AC
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x310], ymm0
 
G_M000_IG183:                ;; offset=0x13B9
       lea      r8, [rbp-0x310]
       lea      rdx, [rbp-0x80]
       mov      rcx, gword ptr [rbp+0xC30]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x90]
       lea      rdx, [rbp-0x80]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, rcx
       mov      rdx, gword ptr [rbp-0x90]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x88]
       mov      qword ptr [rbx+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [rcx]
       test     rbx, rbx
       je       G_M000_IG278
       jmp      G_M000_IG342
 
G_M000_IG184:                ;; offset=0x1424
       cmp      r15d, dword ptr [rax+0x08]
       jae      G_M000_IG484
       mov      ecx, r15d
       mov      rax, gword ptr [rax+8*rcx+0x10]
       jmp      G_M000_IG108
 
G_M000_IG185:                ;; offset=0x143B
       mov      rcx, 0x7FF9D7186D68
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       vmovsd   xmm0, qword ptr [rdi+0x08]
       vmovsd   qword ptr [r14+0x08], xmm0
       mov      rcx, rdi
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rdi+0x08], rcx
       jmp      G_M000_IG110
 
G_M000_IG186:                ;; offset=0x146E
       mov      rcx, 0x7FF9D753B3F0
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      rdx, qword ptr [rdi+0x08]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x270], xmm0
       lea      rcx, [rbp-0x270]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rcx, bword ptr [r14+0x08]
       mov      rdx, gword ptr [rbp-0x270]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rbp-0x268]
       mov      dword ptr [r14+0x10], ecx
       mov      rcx, rdi
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       xor      edx, edx
       mov      qword ptr [rdi+0x08], rdx
       jmp      G_M000_IG110
 
G_M000_IG187:                ;; offset=0x14CD
       mov      rdx, 0x7FF9D77EA4F0
       cmp      qword ptr [r14], rdx
       je       G_M000_IG194
 
G_M000_IG188:                ;; offset=0x14E0
       mov      rdx, r14
       mov      rcx, 0x7FF9D7753360
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       jne      SHORT G_M000_IG194
 
G_M000_IG189:                ;; offset=0x14F8
       mov      rcx, 0x7FF9D7838D18
       cmp      qword ptr [r14], rcx
       je       SHORT G_M000_IG193
 
G_M000_IG190:                ;; offset=0x1507
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG153
 
G_M000_IG191:                ;; offset=0x1515
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG426
 
G_M000_IG192:                ;; offset=0x1522
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNext(byref):bool:this]
       mov      dword ptr [rbp+0xBCC], eax
       jmp      G_M000_IG02
 
G_M000_IG193:                ;; offset=0x1541
       mov      rcx, r14
       lea      rdx, [rbp-0x260]
       call     [Lokad.Lython.Runtime.PyRange+Enumerator:TryMoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       mov      rbx, gword ptr [rbp-0x260]
       mov      rsi, qword ptr [rbp-0x258]
       jmp      G_M000_IG114
 
G_M000_IG194:                ;; offset=0x1564
       mov      rax, gword ptr [rbx+0x08]
       sub      esi, dword ptr [rbx+0x38]
       cmp      esi, dword ptr [rax+0x08]
       jae      G_M000_IG484
       mov      edx, esi
       lea      rbx, bword ptr [rax+4*rdx+0x10]
       mov      rax, 0x7FF9D77EA4F0
       cmp      qword ptr [r14], rax
       jne      SHORT G_M000_IG197
 
G_M000_IG195:                ;; offset=0x158A
       mov      rax, r14
       mov      edx, dword ptr [rbx]
       cmp      edx, dword ptr [rax+0x28]
       jge      SHORT G_M000_IG200
 
G_M000_IG196:                ;; offset=0x1594
       mov      rax, gword ptr [rax+0x08]
       mov      edx, dword ptr [rbx]
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG484
       mov      rax, gword ptr [rax+8*rdx+0x10]
       inc      dword ptr [rbx]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      rbx, rax
       xor      esi, esi
       jmp      SHORT G_M000_IG201
 
G_M000_IG197:                ;; offset=0x15BA
       mov      rdx, r14
       mov      rcx, 0x7FF9D7753360
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       G_M000_IG425
       mov      edx, dword ptr [rbx]
       mov      rcx, gword ptr [rax+0x08]
       test     rcx, rcx
       jne      SHORT G_M000_IG202
 
G_M000_IG198:                ;; offset=0x15E1
       mov      r8d, 1
 
G_M000_IG199:                ;; offset=0x15E7
       cmp      edx, r8d
       jl       SHORT G_M000_IG203
 
G_M000_IG200:                ;; offset=0x15EC
       xor      rbx, rbx
       xor      esi, esi
 
G_M000_IG201:                ;; offset=0x15F0
       jmp      G_M000_IG114
 
G_M000_IG202:                ;; offset=0x15F5
       mov      r8d, dword ptr [rcx+0x08]
       test     r8d, r8d
       jl       G_M000_IG485
       jmp      SHORT G_M000_IG199
 
G_M000_IG203:                ;; offset=0x1604
       mov      edx, dword ptr [rbx]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.PyTuple:get_Item(int):System.Object:this]
       mov      rdx, rax
       inc      dword ptr [rbx]
       lea      rcx, [rbp-0x298]
       call     [Lokad.Lython.Runtime.PyIterationResult:Yield(System.Object):Lokad.Lython.Runtime.PyIterationResult]
       mov      rbx, gword ptr [rbp-0x298]
       mov      rsi, qword ptr [rbp-0x290]
       jmp      SHORT G_M000_IG201
 
G_M000_IG204:                ;; offset=0x1631
       mov      rax, gword ptr [rbx+0x10]
       test     rax, rax
       je       G_M000_IG420
 
G_M000_IG205:                ;; offset=0x163E
       lea      rdx, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
 
G_M000_IG206:                ;; offset=0x1645
       lea      r8, bword ptr [rbx+0x34]
       mov      esi, dword ptr [r8]
       add      esi, 4
       mov      r10d, dword ptr [r8]
       cmp      r10d, eax
       ja       G_M000_IG346
       mov      r9d, r10d
       add      rdx, r9
       sub      eax, r10d
       cmp      eax, 4
       jl       G_M000_IG421
       mov      edi, dword ptr [rdx]
       lea      eax, [rsi+rdi]
       mov      dword ptr [r8], eax
       movsxd   r14, edi
       add      r14, 128
       cmp      r14, qword ptr [rbx+0x28]
       jg       G_M000_IG422
       mov      rax, gword ptr [rbx+0x10]
       test     rax, rax
       je       G_M000_IG423
       lea      r15, bword ptr [rax+0x10]
       mov      r13d, dword ptr [rax+0x08]
 
G_M000_IG207:                ;; offset=0x169E
       mov      r12, gword ptr [rbx+0x08]
       mov      rax, gword ptr [rbx+0x20]
       mov      gword ptr [rbp-0x348], rax
       mov      rdx, gword ptr [rbx+0x18]
       mov      gword ptr [rbp-0x340], rdx
       test     edi, edi
       je       G_M000_IG216
 
G_M000_IG208:                ;; offset=0x16C0
       mov      rcx, 0x7FF9D75B1030
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x350], rax
       mov      dword ptr [rax+0x1C], -1
       test     edi, edi
       jl       G_M000_IG424
 
G_M000_IG209:                ;; offset=0x16E5
       cmp      edi, 8
       jg       G_M000_IG159
 
G_M000_IG210:                ;; offset=0x16EE
       mov      byte  ptr [rax+0x24], dil
 
G_M000_IG211:                ;; offset=0x16F2
       mov      rax, gword ptr [rbp-0x350]
       mov      dword ptr [rax+0x18], edi
       lea      rcx, bword ptr [rax+0x10]
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      r12, gword ptr [rbp-0x350]
       lea      rdx, [rbp-0x280]
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.Text.PyString:get_UnpublishedUtf8():System.Span`1[byte]:this]
       mov      edi, dword ptr [rbp-0x278]
       mov      rax, bword ptr [rbp-0x280]
       mov      bword ptr [rbp-0x358], rax
       xor      r8d, r8d
       mov      dword ptr [rbp-0x284], r8d
       cmp      r8d, edi
       jl       G_M000_IG165
 
G_M000_IG212:                ;; offset=0x1746
       mov      rcx, r12
       mov      edx, edi
       call     [Lokad.Lython.Runtime.Text.PyString:CompleteUnpublishedUtf8(int):this]
 
G_M000_IG213:                ;; offset=0x1751
       sub      qword ptr [rbx+0x28], r14
       mov      rbx, r12
       jmp      G_M000_IG113
 
G_M000_IG214:                ;; offset=0x175D
       mov      r10, gword ptr [rbp-0x340]
       jmp      G_M000_IG162
 
G_M000_IG215:                ;; offset=0x1769
       mov      r11d, r9d
       jmp      G_M000_IG164
 
G_M000_IG216:                ;; offset=0x1771
       mov      r9, 0x2A14B000F78
       mov      r12, gword ptr [r9]
       jmp      SHORT G_M000_IG213
 
G_M000_IG217:                ;; offset=0x1780
       mov      rdx, rbx
       mov      r8, rsi
       jmp      G_M000_IG116
 
G_M000_IG218:                ;; offset=0x178B
       mov      rcx, bword ptr [rbp+0xC20]
       add      rcx, 32
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      dword ptr [rcx+0x10], eax
       jmp      G_M000_IG172
 
G_M000_IG219:                ;; offset=0x17C2
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rax+0x10]
       mov      rdi, gword ptr [rcx]
       mov      rax, gword ptr [rcx+0x20]
       test     rax, rax
       je       G_M000_IG169
 
G_M000_IG220:                ;; offset=0x17E7
       lea      r14, bword ptr [rax+0x10]
       mov      r15d, dword ptr [rax+0x08]
 
G_M000_IG221:                ;; offset=0x17EF
       mov      r13d, dword ptr [rcx+0x10]
       xor      rax, rax
       mov      gword ptr [rbp-0x2D0], rax
       test     esi, esi
       jge      G_M000_IG134
 
G_M000_IG222:                ;; offset=0x1804
       not      esi
       mov      rax, gword ptr [rdi+0x30]
       cmp      dword ptr [rax+0x08], esi
       jg       G_M000_IG133
 
G_M000_IG223:                ;; offset=0x1813
       mov      r12, gword ptr [rdi+0x38]
       mov      rdx, r12
       mov      r8d, esi
       sub      r8d, dword ptr [rax+0x08]
       mov      r10d, dword ptr [rdx+0x08]
       cmp      r8d, r10d
       jae      G_M000_IG484
       mov      r15, gword ptr [rdx+8*r8+0x10]
       sub      esi, dword ptr [rax+0x08]
       cmp      esi, r10d
       jae      G_M000_IG484
       mov      eax, esi
       mov      r14, gword ptr [r12+8*rax+0x10]
       mov      rcx, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:GetGlobalContext(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      r12, rax
       cmp      byte  ptr [r12+0xFE], 0
       jne      G_M000_IG170
 
G_M000_IG224:                ;; offset=0x1865
       xor      rcx, rcx
 
G_M000_IG225:                ;; offset=0x1867
       test     rcx, rcx
       je       SHORT G_M000_IG231
 
G_M000_IG226:                ;; offset=0x186C
       mov      rdx, gword ptr [rcx+0x118]
       cmp      rdx, gword ptr [rdi+0x40]
       jne      SHORT G_M000_IG230
 
G_M000_IG227:                ;; offset=0x1879
       mov      rdx, gword ptr [rdi+0x48]
       cmp      esi, dword ptr [rdx+0x08]
       jae      G_M000_IG484
       mov      eax, esi
       mov      edx, dword ptr [rdx+4*rax+0x10]
       test     edx, edx
       jl       SHORT G_M000_IG231
 
G_M000_IG228:                ;; offset=0x1890
       mov      rcx, gword ptr [rcx+0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadLocalValue(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int):System.Object]
       test     rax, rax
       je       SHORT G_M000_IG231
 
G_M000_IG229:                ;; offset=0x18A2
       mov      gword ptr [rbp-0x2D0], rax
       jmp      G_M000_IG238
 
G_M000_IG230:                ;; offset=0x18AE
       lea      r8, [rbp-0x2D0]
       mov      rdx, r14
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryResolveLocalOrClosure(System.String,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG238
 
G_M000_IG231:                ;; offset=0x18C8
       mov      rcx, gword ptr [r12+0x08]
       test     rcx, rcx
       jne      SHORT G_M000_IG236
 
G_M000_IG232:                ;; offset=0x18D2
       mov      rcx, 0x7FF9D719DDF0
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       mov      rcx, 0x2A14B000068
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x360], rax
       mov      rdx, rax
       lea      rcx, bword ptr [rsi+0x18]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, gword ptr [rbp-0x360]
       call     [System.Collections.Generic.NonRandomizedStringEqualityComparer:GetStringComparer(System.Object):System.Collections.Generic.IEqualityComparer`1[System.String]]
       test     rax, rax
       je       SHORT G_M000_IG234
 
G_M000_IG233:                ;; offset=0x1916
       lea      rcx, bword ptr [rsi+0x18]
       mov      rdx, rax
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG234:                ;; offset=0x1922
       lea      rcx, bword ptr [r12+0x08]
       test     rcx, rcx
       je       G_M000_IG325
       mov      rdx, rsi
       xor      r8, r8
       call     System.Threading.Interlocked:CompareExchangeObject(byref,System.Object,System.Object):System.Object
       mov      rcx, rax
       test     rcx, rcx
       jne      SHORT G_M000_IG236
 
G_M000_IG235:                ;; offset=0x1943
       mov      rcx, rsi
 
G_M000_IG236:                ;; offset=0x1946
       cmp      byte  ptr [rcx], cl
       mov      rdx, r14
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:FindValue(System.__Canon):byref:this]
       test     rax, rax
       je       G_M000_IG128
 
G_M000_IG237:                ;; offset=0x195A
       mov      rcx, gword ptr [rax]
       mov      gword ptr [rbp-0x2D0], rcx
 
G_M000_IG238:                ;; offset=0x1964
       mov      rdx, gword ptr [rbp-0x2D0]
 
G_M000_IG239:                ;; offset=0x196B
       xor      rcx, rcx
       mov      gword ptr [rbp-0x2D0], rcx
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       G_M000_IG149
 
G_M000_IG240:                ;; offset=0x1987
       mov      r8, 0x7FFFFFFFFF9FF
       bt       r8, rcx
       jb       G_M000_IG149
 
G_M000_IG241:                ;; offset=0x199B
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      r8d, dword ptr [rcx+0x18]
       test     r8d, r8d
       jl       G_M000_IG148
 
G_M000_IG242:                ;; offset=0x19AF
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      ecx, dword ptr [rcx+0x18]
       test     ecx, ecx
       jl       G_M000_IG150
 
G_M000_IG243:                ;; offset=0x19C1
       mov      r9d, ecx
 
G_M000_IG244:                ;; offset=0x19C4
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      rcx, gword ptr [rcx]
       mov      gword ptr [rsp+0x20], rcx
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryPrepareNativeIteration(System.Object,int,int,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      G_M000_IG02
 
G_M000_IG245:                ;; offset=0x19E4
       movzx    rax, byte  ptr [rbp+0xC38]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r9, gword ptr [rbp+0xC28]
       test     rdx, rdx
       je       G_M000_IG153
 
G_M000_IG246:                ;; offset=0x1A09
       test     al, al
       jne      G_M000_IG464
 
G_M000_IG247:                ;; offset=0x1A11
       mov      rdx, gword ptr [rbp+0xC30]
       mov      rcx, rdx
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG02
 
G_M000_IG248:                ;; offset=0x1A2D
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG153
 
G_M000_IG249:                ;; offset=0x1A3B
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG404
       jmp      SHORT G_M000_IG252
 
G_M000_IG250:                ;; offset=0x1A4A
       mov      rcx, bword ptr [rbp+0xC40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp+0xBCC], eax
       jmp      G_M000_IG02
 
G_M000_IG251:                ;; offset=0x1A62
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG153
 
G_M000_IG252:                ;; offset=0x1A70
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteStructure(byref):bool:this]
       mov      dword ptr [rbp+0xBCC], eax
       jmp      G_M000_IG02
 
G_M000_IG253:                ;; offset=0x1A8F
       cmp      gword ptr [rbp+0xC30], 0
       je       SHORT G_M000_IG256
 
G_M000_IG254:                ;; offset=0x1A99
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryStageUnpackedFrameReturn(byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG256
 
G_M000_IG255:                ;; offset=0x1AB1
       mov      dword ptr [rbp+0xB28], 1
       jmp      G_M000_IG487
 
G_M000_IG256:                ;; offset=0x1AC0
       mov      rbx, bword ptr [rbp+0xC58]
       mov      r8d, dword ptr [rbx+0x08]
       test     r8d, r8d
       jne      G_M000_IG401
 
G_M000_IG257:                ;; offset=0x1AD4
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      edi, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      r8d, eax
       mov      rdx, gword ptr [rbp+0xC28]
       mov      gword ptr [rsp+0x20], rdx
       mov      edx, edi
       mov      rcx, rsi
       mov      r9, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [r9]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTupleFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyTuple]
       mov      rdx, rax
       lea      rcx, [rbp-0x250]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x250]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG258:                ;; offset=0x1B51
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      edi, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      r8d, eax
       mov      rdx, gword ptr [rbp+0xC28]
       mov      gword ptr [rsp+0x20], rdx
       mov      edx, edi
       mov      rcx, rsi
       mov      r9, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [r9]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateListFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      rdx, rax
       lea      rcx, [rbp-0x240]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x240]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG259:                ;; offset=0x1BCE
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xC20]
       add      rcx, 32
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       jmp      G_M000_IG02
 
G_M000_IG260:                ;; offset=0x1C11
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       lea      edi, [rax+0x01]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r14d, eax
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xC20]
       add      rcx, 32
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      rdx, rax
       lea      rcx, [rbp-0x230]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x230]
       mov      rcx, rsi
       mov      edx, edi
       mov      r8d, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishSlot(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG02
 
G_M000_IG261:                ;; offset=0x1C81
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG153
 
G_M000_IG262:                ;; offset=0x1C8F
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rsi, gword ptr [rcx]
       mov      rdi, gword ptr [rcx+0x08]
       mov      rax, gword ptr [rcx]
       mov      r12, gword ptr [rax+0x38]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      r10d, dword ptr [r12+0x08]
       cmp      eax, r10d
       jae      G_M000_IG484
       mov      ecx, eax
       mov      r14, gword ptr [r12+8*rcx+0x10]
       mov      rcx, bword ptr [rbp+0xC20]
       lea      r15, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      r13d, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
       mov      edx, r13d
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      r9, rax
       mov      rdx, gword ptr [rbp+0xC30]
       mov      gword ptr [rsp+0x20], rdx
       mov      r8, bword ptr [rbp+0xBB8]
       mov      r8, gword ptr [r8]
       mov      gword ptr [rsp+0x28], r8
       mov      r8, r14
       mov      rcx, rsi
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime:AssignExecutableBoundName(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG02
 
G_M000_IG263:                ;; offset=0x1D2A
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG153
 
G_M000_IG264:                ;; offset=0x1D38
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rax, gword ptr [rcx]
       mov      r12, gword ptr [rax+0x38]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      r10d, dword ptr [r12+0x08]
       cmp      eax, r10d
       jae      G_M000_IG484
       mov      ecx, eax
       mov      rsi, gword ptr [r12+8*rcx+0x10]
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rdi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      r14d, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
       mov      edx, r14d
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      rdx, rax
       mov      rcx, rsi
       mov      r9, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [r9]
       mov      r8, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreName(System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG02
 
G_M000_IG265:                ;; offset=0x1DBC
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryStoreClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG02
       jmp      G_M000_IG153
 
G_M000_IG266:                ;; offset=0x1DE4
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:StoreExecutableLocal(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG02
 
G_M000_IG267:                ;; offset=0x1E0B
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG153
 
G_M000_IG268:                ;; offset=0x1E19
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rdx]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:PreloadImplicitSuperArguments(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG02
 
G_M000_IG269:                ;; offset=0x1E35
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryLoadDirectCallReceiver(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG02
       jmp      G_M000_IG392
 
G_M000_IG270:                ;; offset=0x1E64
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG153
 
G_M000_IG271:                ;; offset=0x1E72
       cmp      byte  ptr [rbp+0xC38], 0
       jne      SHORT G_M000_IG275
 
G_M000_IG272:                ;; offset=0x1E7B
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG273:                ;; offset=0x1E82
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x310], ymm0
 
G_M000_IG274:                ;; offset=0x1E8F
       lea      r8, [rbp-0x310]
       lea      rdx, [rbp+0xB18]
       mov      rcx, gword ptr [rbp+0xC30]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       mov      rsi, gword ptr [rbp+0xB18]
       test     rsi, rsi
       je       G_M000_IG02
       jmp      G_M000_IG330
 
G_M000_IG275:                ;; offset=0x1EC2
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG276:                ;; offset=0x1EC9
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x310], ymm0
 
G_M000_IG277:                ;; offset=0x1ED6
       lea      r8, [rbp-0x310]
       lea      rdx, [rbp-0x160]
       mov      rcx, gword ptr [rbp+0xC30]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x170]
       lea      rdx, [rbp-0x160]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, rcx
       mov      rdx, gword ptr [rbp-0x170]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x168]
       mov      qword ptr [rsi+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, gword ptr [rcx]
       test     rsi, rsi
       jne      G_M000_IG334
 
G_M000_IG278:                ;; offset=0x1F42
       mov      rcx, bword ptr [rbp+0xC40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG02
 
G_M000_IG279:                ;; offset=0x1F54
       movzx    rcx, byte  ptr [rbp+0xC38]
       mov      dword ptr [rsp+0x20], ecx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      bword ptr [rsp+0x28], rcx
       mov      rax, bword ptr [rbp+0xC48]
       mov      bword ptr [rsp+0x30], rax
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteComparisonInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref):int]
       test     eax, eax
       je       G_M000_IG250
 
G_M000_IG280:                ;; offset=0x1FA1
       mov      dword ptr [rbp+0xB28], eax
       jmp      G_M000_IG487
 
G_M000_IG281:                ;; offset=0x1FAC
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      r8, gword ptr [rbp+0xC28]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      rbx, rax
       cmp      gword ptr [rbp+0xC30], 0
       jne      SHORT G_M000_IG283
 
G_M000_IG282:                ;; offset=0x1FDA
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       je       G_M000_IG153
 
G_M000_IG283:                ;; offset=0x1FEB
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG476
 
G_M000_IG284:                ;; offset=0x1FF8
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp+0xBCC], eax
       jmp      G_M000_IG02
 
G_M000_IG285:                ;; offset=0x2025
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG151
 
G_M000_IG286:                ;; offset=0x2033
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp+0xBCC], eax
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      gword ptr [rcx+0x68], 0
       je       G_M000_IG02
 
G_M000_IG287:                ;; offset=0x206D
       movzx    rax, byte  ptr [rbp+0xC38]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r9, gword ptr [rbp+0xC28]
       test     al, al
       je       G_M000_IG255
 
G_M000_IG288:                ;; offset=0x208A
       cmp      gword ptr [rcx+0x40], 0
       je       G_M000_IG255
 
G_M000_IG289:                ;; offset=0x2095
       xor      r8, r8
       mov      r10, bword ptr [rbp+0xC40]
       mov      gword ptr [r10], r8
       mov      word  ptr [r10+0x08], 0
       movzx    r8, byte  ptr [rbp+0xBCC]
       mov      byte  ptr [r10+0x0A], r8b
       mov      byte  ptr [r10+0x0B], 1
       mov      dword ptr [rbp+0xB28], 5
       jmp      G_M000_IG487
 
G_M000_IG290:                ;; offset=0x20C9
       mov      r9, gword ptr [rbp+0xC28]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteBuiltinArithmetic(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG295
       jmp      G_M000_IG02
 
G_M000_IG291:                ;; offset=0x20F7
       cmp      gword ptr [rbp+0xC30], 0
       jne      G_M000_IG247
       jmp      G_M000_IG153
 
G_M000_IG292:                ;; offset=0x210A
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG153
 
G_M000_IG293:                ;; offset=0x2118
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG470
       jmp      G_M000_IG247
 
G_M000_IG294:                ;; offset=0x212A
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSequenceIndex(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG02
 
G_M000_IG295:                ;; offset=0x2154
       movzx    rcx, byte  ptr [rbp+0xC38]
       mov      dword ptr [rsp+0x20], ecx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      bword ptr [rsp+0x28], rcx
       mov      rax, bword ptr [rbp+0xC48]
       mov      bword ptr [rsp+0x30], rax
       mov      r8, bword ptr [rbp+0xC50]
       mov      bword ptr [rsp+0x38], r8
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInputInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref,byref):int]
       test     eax, eax
       je       G_M000_IG02
       jmp      G_M000_IG410
 
G_M000_IG296:                ;; offset=0x21B2
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rcx]
       mov      rax, gword ptr [rdx+0xB0]
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x1C]
       cmp      edx, 42
       je       SHORT G_M000_IG298
 
G_M000_IG297:                ;; offset=0x21D2
       cmp      edx, 73
       jne      G_M000_IG438
 
G_M000_IG298:                ;; offset=0x21DB
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x08]
       mov      r8, 0x7FF9D7638680
       cmp      qword ptr [rax], r8
       jne      G_M000_IG440
       cmp      dword ptr [rax+0x08], edx
       jbe      G_M000_IG439
       mov      rbx, gword ptr [rax+8*rdx+0x10]
 
G_M000_IG299:                ;; offset=0x2206
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x1C]
       cmp      eax, 51
       ja       G_M000_IG155
 
G_M000_IG300:                ;; offset=0x2219
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jb       G_M000_IG155
 
G_M000_IG301:                ;; offset=0x222D
       mov      rax, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rax+0x18]
       test     esi, esi
       jl       G_M000_IG154
 
G_M000_IG302:                ;; offset=0x223F
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rax, bword ptr [rcx+0x20]
       cmp      byte  ptr [rbx], bl
       mov      rax, gword ptr [rax]
       cmp      byte  ptr [rbx+0x30], 0
       setne    dl
       movzx    rdx, dl
       add      edx, esi
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG484
       shl      rdx, 4
       lea      rdi, bword ptr [rax+rdx+0x10]
       mov      rax, gword ptr [rdi]
       mov      rdx, 0x2A14B001CE0
       cmp      rax, gword ptr [rdx]
       je       G_M000_IG158
 
G_M000_IG303:                ;; offset=0x2283
       mov      rax, gword ptr [rdi]
       mov      rdx, 0x2A14B001CE8
       cmp      rax, gword ptr [rdx]
       je       G_M000_IG157
 
G_M000_IG304:                ;; offset=0x2299
       cmp      qword ptr [rdi+0x08], 0
       je       G_M000_IG156
 
G_M000_IG305:                ;; offset=0x22A4
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r14, rax
 
G_M000_IG306:                ;; offset=0x22B0
       test     r14, r14
       je       G_M000_IG441
       mov      dword ptr [rsp+0x20], esi
       mov      gword ptr [rsp+0x28], r14
       lea      rcx, [rbp+0xB38]
       mov      qword ptr [rsp+0x30], rcx
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       G_M000_IG313
 
G_M000_IG307:                ;; offset=0x22F4
       cmp      gword ptr [rbp+0xB38], 0
       je       G_M000_IG02
 
G_M000_IG308:                ;; offset=0x2302
       mov      rdx, gword ptr [rbp+0xB38]
       mov      rcx, 0x7FF9D74F0AF8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      r14, rax
       test     r14, r14
       je       SHORT G_M000_IG310
 
G_M000_IG309:                ;; offset=0x2321
       jmp      G_M000_IG494
 
G_M000_IG310:                ;; offset=0x2326
       mov      rdx, gword ptr [rbp+0xB38]
       mov      rax, rdx
       test     rax, rax
       je       SHORT G_M000_IG312
 
G_M000_IG311:                ;; offset=0x2335
       mov      rcx, 0x7FF9D76A9D18
       cmp      qword ptr [rax], rcx
       jne      G_M000_IG442
 
G_M000_IG312:                ;; offset=0x2348
       xor      rcx, rcx
       mov      r8, bword ptr [rbp+0xC50]
       mov      gword ptr [r8], rcx
       lea      rcx, bword ptr [r8+0x08]
       mov      rdx, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      r8, bword ptr [rbp+0xC50]
       mov      word  ptr [r8+0x10], 0
       mov      byte  ptr [r8+0x12], 1
       jmp      SHORT G_M000_IG319
 
G_M000_IG313:                ;; offset=0x2375
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG443
 
G_M000_IG314:                ;; offset=0x2383
       movzx    rcx, byte  ptr [rbp+0xC38]
       mov      dword ptr [rsp+0x20], ecx
       mov      r8, bword ptr [rbp+0xC50]
       mov      bword ptr [rsp+0x28], r8
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, rbx
       mov      r8d, esi
       mov      r9, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBeginExecutableCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG320
 
G_M000_IG315:                ;; offset=0x23B4
       mov      r8, bword ptr [rbp+0xC50]
       mov      r14, gword ptr [r8]
       test     r14, r14
       jne      G_M000_IG446
 
G_M000_IG316:                ;; offset=0x23C7
       mov      r8, bword ptr [rbp+0xC50]
       mov      rsi, gword ptr [r8]
       test     rsi, rsi
       jne      G_M000_IG449
 
G_M000_IG317:                ;; offset=0x23DA
       mov      rdi, gword ptr [r8+0x08]
 
G_M000_IG318:                ;; offset=0x23DE
       mov      rcx, gword ptr [rbp+0xC30]
       cmp      rdi, rcx
       je       G_M000_IG453
 
G_M000_IG319:                ;; offset=0x23EE
       mov      rdx, gword ptr [rbx+0x18]
       mov      rcx, bword ptr [rbp+0xC48]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp+0xB28], 3
       jmp      G_M000_IG487
 
G_M000_IG320:                ;; offset=0x240D
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG458
 
G_M000_IG321:                ;; offset=0x241A
       mov      gword ptr [rsp+0x20], r14
       xor      edx, edx
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp+0xB18]
       mov      rcx, gword ptr [rbp+0xC30]
       mov      r8, rbx
       mov      r9d, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       mov      r14, gword ptr [rbp+0xB18]
       test     r14, r14
       je       G_M000_IG02
       jmp      G_M000_IG454
 
G_M000_IG322:                ;; offset=0x2454
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      rdx, 0x2C171C8D5F8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG323:                ;; offset=0x2474
       mov      rcx, 0x7FF9D72BE510
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      rcx, r14
       call     [System.IndexOutOfRangeException:.ctor():this]
       mov      rcx, r14
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG324:                ;; offset=0x2498
       mov      rdx, r12
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG325:                ;; offset=0x24A2
       call     [System.ThrowHelper:ThrowNullReferenceException()]
       int3     
 
G_M000_IG326:                ;; offset=0x24A9
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      rcx, r14
       mov      rdx, 0x2C171C8AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, r14
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG327:                ;; offset=0x24D7
       mov      rcx, bword ptr [rbp+0xC20]
       mov      r8, gword ptr [rcx]
       mov      rbx, gword ptr [r8+0x68]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      edx, eax
       mov      rcx, rbx
       mov      r11, 0x7FF9D7091CE8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rcx, rax
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rdx]
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG328:                ;; offset=0x2520
       add      dword ptr [rsi+0x10], 2
       jmp      G_M000_IG02
 
G_M000_IG329:                ;; offset=0x2529
       mov      rdx, gword ptr [rbp+0xBB0]
       lea      rcx, [rbp-0x1F0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x1F0]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG330:                ;; offset=0x2564
       mov      rdx, rsi
       mov      rcx, 0x7FF9D74847C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG333
 
G_M000_IG331:                ;; offset=0x257C
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG02
 
G_M000_IG332:                ;; offset=0x2591
       mov      r8, rax
       mov      rcx, r8
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG02
 
G_M000_IG333:                ;; offset=0x25A4
       mov      rcx, rsi
       movsx    rdx, word  ptr [rbp+0xB20]
       mov      r11, 0x7FF9D7091D08
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG02
 
G_M000_IG334:                ;; offset=0x25C1
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7846388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG335
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG336
 
G_M000_IG335:                ;; offset=0x25EA
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9D7091D10
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG336:                ;; offset=0x2610
       test     edi, edi
       jne      G_M000_IG278
 
G_M000_IG337:                ;; offset=0x2618
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rcx]
       mov      rcx, bword ptr [rbp+0xC48]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp+0xB28], 4
       jmp      G_M000_IG487
 
G_M000_IG338:                ;; offset=0x263D
       mov      rdx, rbx
       mov      rcx, 0x7FF9D74847C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG341
 
G_M000_IG339:                ;; offset=0x2655
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG02
 
G_M000_IG340:                ;; offset=0x266A
       mov      r8, rax
       mov      rcx, r8
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG02
 
G_M000_IG341:                ;; offset=0x267D
       mov      rcx, rbx
       movsx    rdx, word  ptr [rbp+0xB20]
       mov      r11, 0x7FF9D7091D18
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG02
 
G_M000_IG342:                ;; offset=0x269A
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG343
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG344
 
G_M000_IG343:                ;; offset=0x26C3
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7091D20
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG344:                ;; offset=0x26E9
       test     esi, esi
       jne      G_M000_IG278
       jmp      G_M000_IG337
 
G_M000_IG345:                ;; offset=0x26F6
       mov      rax, rcx
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG346:                ;; offset=0x2700
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG347:                ;; offset=0x2707
       xor      r9, r9
       xor      r8d, r8d
       jmp      G_M000_IG87
 
G_M000_IG348:                ;; offset=0x2712
       mov      rdx, rsi
       mov      rcx, 0x7FF9D74847C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG351
 
G_M000_IG349:                ;; offset=0x272A
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG02
 
G_M000_IG350:                ;; offset=0x273F
       mov      r8, rax
       mov      rcx, r8
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG02
 
G_M000_IG351:                ;; offset=0x2752
       mov      rcx, rsi
       movsx    rdx, word  ptr [rbp+0xB10]
       mov      r11, 0x7FF9D7091D28
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG02
 
G_M000_IG352:                ;; offset=0x276F
       vmovdqu  xmm0, xmmword ptr [rbp+0xB90]
       vmovdqu  xmmword ptr [rbp-0x320], xmm0
 
G_M000_IG353:                ;; offset=0x277F
       lea      rdx, [rbp-0x320]
       lea      rcx, [rbp-0x180]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, rcx
       mov      rdx, gword ptr [rbp-0x180]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x178]
       mov      qword ptr [rsi+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, gword ptr [rcx]
       test     rsi, rsi
       je       G_M000_IG278
 
G_M000_IG354:                ;; offset=0x27CA
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7846388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG355
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG356
 
G_M000_IG355:                ;; offset=0x27F3
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9D7091D30
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG356:                ;; offset=0x2819
       test     edi, edi
       jne      G_M000_IG278
       jmp      G_M000_IG337
 
G_M000_IG357:                ;; offset=0x2826
       cmp      byte  ptr [rdx+0xFF], 0
       jne      SHORT G_M000_IG360
 
G_M000_IG358:                ;; offset=0x282F
       cmp      ebx, esi
       jle      SHORT G_M000_IG360
 
G_M000_IG359:                ;; offset=0x2833
       cmp      esi, ebx
       jae      G_M000_IG484
       mov      r8, gword ptr [rbp+0xBD0]
       mov      r14d, esi
       shl      r14, 5
       cmp      dword ptr [r8+r14+0x2C], 30
       sete     r15b
       movzx    r15, r15b
       mov      rdx, gword ptr [rbp+0xC30]
       jmp      G_M000_IG81
 
G_M000_IG360:                ;; offset=0x2863
       mov      rdx, gword ptr [rbp+0xC30]
       xor      r15d, r15d
       jmp      G_M000_IG81
 
G_M000_IG361:                ;; offset=0x2872
       test     rdi, rdi
       je       G_M000_IG370
 
G_M000_IG362:                ;; offset=0x287B
       vmovdqu  xmm0, xmmword ptr [rbp+0xAF8]
       vmovdqu  xmmword ptr [rbp-0x2E0], xmm0
 
G_M000_IG363:                ;; offset=0x288B
       lea      r8, [rbp-0x2E0]
       mov      rdx, rdi
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryAppendBufferedYield(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):bool:this]
       test     eax, eax
       je       G_M000_IG370
 
G_M000_IG364:                ;; offset=0x28AA
       cmp      esi, ebx
       jae      G_M000_IG484
       mov      rcx, gword ptr [rbp+0xBD0]
       mov      r14d, esi
       shl      r14, 5
       mov      r15, gword ptr [rcx+r14+0x10]
       mov      r9, gword ptr [rbp+0xC28]
       mov      rdi, gword ptr [r9+0x98]
       cmp      byte  ptr [rdi], dil
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG366
 
G_M000_IG365:                ;; offset=0x28E3
       mov      rcx, rdi
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG366:                ;; offset=0x28EF
       mov      r9, gword ptr [rbp+0xC28]
       mov      rsi, gword ptr [r9+0x98]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_HasActiveHandler():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG368
 
G_M000_IG367:                ;; offset=0x290E
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, gword ptr [rcx+0x80]
       jmp      SHORT G_M000_IG369
 
G_M000_IG368:                ;; offset=0x291E
       mov      r9, gword ptr [rbp+0xC28]
       mov      rdx, gword ptr [r9+0x98]
       mov      rdx, gword ptr [rdx+0x148]
 
G_M000_IG369:                ;; offset=0x2933
       lea      rcx, bword ptr [rsi+0x148]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, gword ptr [rbp+0xBD0]
       lea      rcx, bword ptr [rax+r14+0x10]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp+0xC20]
       add      dword ptr [rcx+0x10], 2
       jmp      G_M000_IG495
 
G_M000_IG370:                ;; offset=0x2977
       mov      rdx, gword ptr [rbp+0xC30]
       lea      rsi, bword ptr [rdx+0x190]
       mov      rdx, gword ptr [rbp+0xAF8]
       mov      rcx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, qword ptr [rbp+0xB00]
       mov      qword ptr [rsi+0x08], rcx
       mov      rdx, gword ptr [rbp+0xC30]
       mov      word  ptr [rdx+0xF8], 257
       mov      rcx, bword ptr [rbp+0xC20]
       inc      dword ptr [rcx+0x10]
       test     r15d, r15d
       jne      G_M000_IG255
 
G_M000_IG371:                ;; offset=0x29C2
       test     rdi, rdi
       je       G_M000_IG255
 
G_M000_IG372:                ;; offset=0x29CB
       mov      rcx, rdx
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG255
       jmp      G_M000_IG495
 
G_M000_IG373:                ;; offset=0x29E4
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG374:                ;; offset=0x29EB
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x310], ymm0
 
G_M000_IG375:                ;; offset=0x29F8
       lea      r8, [rbp-0x310]
       lea      rdx, [rbp-0xB0]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteDelegationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, rcx
       mov      rdx, gword ptr [rbp-0xB0]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xA8]
       mov      qword ptr [rsi+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, gword ptr [rcx]
       test     rsi, rsi
       je       SHORT G_M000_IG379
 
G_M000_IG376:                ;; offset=0x2A46
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7846388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG377
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG378
 
G_M000_IG377:                ;; offset=0x2A6F
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9D7091D38
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG378:                ;; offset=0x2A95
       test     edi, edi
       je       G_M000_IG337
 
G_M000_IG379:                ;; offset=0x2A9D
       mov      rcx, bword ptr [rbp+0xC40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG78
 
G_M000_IG380:                ;; offset=0x2AAF
       mov      rdx, gword ptr [rbp+0xC30]
       cmp      gword ptr [rdx+0x68], 0
       jne      G_M000_IG382
 
G_M000_IG381:                ;; offset=0x2AC1
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      edi, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      r8d, eax
       mov      edx, edi
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      rsi, rax
       mov      rcx, 0x7FF9D71528A8
       mov      edx, 1
       call     CORINFO_HELP_NEWARR_1_PTR
       mov      rdi, rax
       lea      rcx, bword ptr [rdi+0x10]
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rdx]
       mov      rcx, rdi
       mov      r8, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:Iter(System.Object[],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rsi, rax
       mov      rcx, 0x7FF9D77E7DB8
       call     CORINFO_HELP_NEWSFAST
       mov      rdi, rax
       mov      r9, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [r9]
       mov      rcx, rdi
       mov      rdx, rsi
       mov      r8, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:.ctor(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):this]
       mov      r8, gword ptr [rbp+0xC30]
       lea      rcx, bword ptr [r8+0x68]
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG382:                ;; offset=0x2B76
       mov      rdx, gword ptr [rbp+0xC30]
       mov      rcx, gword ptr [rdx+0x68]
       mov      r8, gword ptr [rdx+0x58]
       mov      r9, gword ptr [rdx+0x60]
       lea      rdx, [rbp-0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:Advance(System.Object,Lokad.Lython.Runtime.LythonRuntimeException):Lokad.Lython.Runtime.PyIterationResult:this]
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG383:                ;; offset=0x2B9F
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x310], ymm0
 
G_M000_IG384:                ;; offset=0x2BAC
       lea      r8, [rbp-0x310]
       lea      rdx, [rbp-0xA0]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteDelegatedStep(Lokad.Lython.Runtime.PyIterationResult,Lokad.Lython.Frontend.ExecutableInstruction):this]
       jmp      G_M000_IG78
 
G_M000_IG385:                ;; offset=0x2BCC
       mov      rdx, r8
       movzx    rax, byte  ptr [rbp+0xC38]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      r9, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rdx+0x70]
       test     r8, r8
       je       G_M000_IG255
 
G_M000_IG386:                ;; offset=0x2BF1
       mov      rcx, rdx
       mov      rdx, r8
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG255
       jmp      G_M000_IG495
 
G_M000_IG387:                ;; offset=0x2C0A
       mov      rcx, gword ptr [rsi]
       mov      r8, gword ptr [rsi+0x08]
       mov      rdx, rax
       mov      r9, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteExecutableImport(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext)]
       jmp      G_M000_IG02
 
G_M000_IG388:                ;; offset=0x2C26
       lea      rcx, [rbp-0x190]
       mov      rdx, rax
       mov      r8, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteImportAsync(Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Threading.Tasks.ValueTask]
       lea      rcx, [rbp-0x1A0]
       lea      rdx, [rbp-0x190]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rdi, rcx
       mov      rdx, gword ptr [rbp-0x1A0]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x198]
       mov      qword ptr [rdi+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rdi, gword ptr [rcx]
       test     rdi, rdi
       je       G_M000_IG278
 
G_M000_IG389:                ;; offset=0x2C88
       mov      rdx, rdi
       mov      rcx, 0x7FF9D7846388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG390
       test     dword ptr [rax+0x34], 0x1600000
       setne    r14b
       movzx    r14, r14b
       jmp      SHORT G_M000_IG391
 
G_M000_IG390:                ;; offset=0x2CB1
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rdi
       mov      r11, 0x7FF9D7091D40
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    r14b
       movzx    r14, r14b
 
G_M000_IG391:                ;; offset=0x2CD7
       test     r14d, r14d
       jne      G_M000_IG278
       jmp      G_M000_IG337
 
G_M000_IG392:                ;; offset=0x2CE5
       movzx    rax, byte  ptr [rbp+0xC38]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r9, gword ptr [rbp+0xC28]
       test     rdx, rdx
       je       G_M000_IG153
 
G_M000_IG393:                ;; offset=0x2D0A
       test     al, al
       jne      SHORT G_M000_IG395
 
G_M000_IG394:                ;; offset=0x2D0E
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSynchronousMemberLoad(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG02
 
G_M000_IG395:                ;; offset=0x2D2A
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG396:                ;; offset=0x2D31
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x310], ymm0
 
G_M000_IG397:                ;; offset=0x2D3E
       lea      r8, [rbp-0x310]
       lea      rdx, [rbp-0x150]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteMemberLoadAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, rcx
       mov      rdx, gword ptr [rbp-0x150]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x148]
       mov      qword ptr [rsi+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rsi, gword ptr [rcx]
       test     rsi, rsi
       je       G_M000_IG278
 
G_M000_IG398:                ;; offset=0x2D90
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7846388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG399
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG400
 
G_M000_IG399:                ;; offset=0x2DB9
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rsi
       mov      r11, 0x7FF9D7091D48
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG400:                ;; offset=0x2DDF
       test     edi, edi
       jne      G_M000_IG278
       jmp      G_M000_IG337
 
G_M000_IG401:                ;; offset=0x2DEC
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CanForwardFixedReturn(byref,byref,int):bool]
       test     eax, eax
       je       G_M000_IG257
 
G_M000_IG402:                ;; offset=0x2E08
       vmovdqu  xmm0, xmmword ptr [rbx]
       vmovdqu  xmmword ptr [rbp-0x2F0], xmm0
 
G_M000_IG403:                ;; offset=0x2E14
       lea      r9, [rbp-0x2F0]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, bword ptr [rbp+0xBB8]
       mov      rcx, bword ptr [rbp+0xC20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CopyFixedReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       mov      dword ptr [rbp+0xB28], 2
       jmp      G_M000_IG487
 
G_M000_IG404:                ;; offset=0x2E45
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG405:                ;; offset=0x2E4C
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x310], ymm0
 
G_M000_IG406:                ;; offset=0x2E59
       lea      r8, [rbp-0x310]
       lea      rdx, [rbp-0x140]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteContextManagerAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, r10
       mov      rdx, gword ptr [rbp-0x140]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x138]
       mov      qword ptr [rbx+0x08], rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       G_M000_IG250
 
G_M000_IG407:                ;; offset=0x2EAB
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG408
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG409
 
G_M000_IG408:                ;; offset=0x2ED4
       mov      r10, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7091D50
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG409:                ;; offset=0x2EFA
       test     esi, esi
       jne      G_M000_IG250
       jmp      G_M000_IG337
 
G_M000_IG410:                ;; offset=0x2F07
       mov      r8d, eax
       movzx    rax, byte  ptr [rbp+0xC38]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r9, gword ptr [rbp+0xC28]
       mov      dword ptr [rbp+0xB28], r8d
       jmp      G_M000_IG487
 
G_M000_IG411:                ;; offset=0x2F32
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rax, gword ptr [rcx+0x20]
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG484
       shl      rdx, 4
       mov      rbx, gword ptr [rax+rdx+0x10]
       test     rbx, rbx
       je       G_M000_IG102
 
G_M000_IG412:                ;; offset=0x2F62
       mov      rax, 0x7FF9D77E5D30
       cmp      qword ptr [rbx], rax
       jne      G_M000_IG102
 
G_M000_IG413:                ;; offset=0x2F75
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:get_NativeCsvSource():Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:this]
       test     rax, rax
       je       G_M000_IG102
 
G_M000_IG414:                ;; offset=0x2F87
       cmp      gword ptr [rax+0x20], 0
       je       G_M000_IG102
 
G_M000_IG415:                ;; offset=0x2F92
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      bword ptr [rsp+0x20], rdx
       movzx    rdx, byte  ptr [rbp+0xC38]
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp-0x70]
       mov      rcx, gword ptr [rbp+0xC30]
       mov      r8, rax
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AdvanceCsvUnpack(Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource,Lokad.Lython.Runtime.PyIteration+Cursor,byref,bool):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, rcx
       mov      rdx, gword ptr [rbp-0x70]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x68]
       mov      qword ptr [rbx+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [rcx]
       test     rbx, rbx
       je       G_M000_IG250
 
G_M000_IG416:                ;; offset=0x2FF1
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG417
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG418
 
G_M000_IG417:                ;; offset=0x301A
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7091D58
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG418:                ;; offset=0x3040
       test     esi, esi
       jne      G_M000_IG250
       jmp      G_M000_IG337
 
G_M000_IG419:                ;; offset=0x304D
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x2C171C8AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG420:                ;; offset=0x307B
       xor      rdx, rdx
       xor      eax, eax
       jmp      G_M000_IG206
 
G_M000_IG421:                ;; offset=0x3084
       mov      ecx, 40
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException(int)]
       int3     
 
G_M000_IG422:                ;; offset=0x3090
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x2C171C94020
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG423:                ;; offset=0x30BE
       xor      r15, r15
       xor      r13d, r13d
       jmp      G_M000_IG207
 
G_M000_IG424:                ;; offset=0x30C9
       mov      ecx, edi
       mov      rdx, 0x2C171C86810
       call     [System.ArgumentOutOfRangeException:ThrowNegativeOrZero[int](int,System.String)]
       int3     
 
G_M000_IG425:                ;; offset=0x30DC
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      rcx, r14
       mov      rdx, 0x2C171C946A8
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, r14
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG426:                ;; offset=0x310A
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG427:                ;; offset=0x3111
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x310], ymm0
 
G_M000_IG428:                ;; offset=0x311E
       lea      r8, [rbp-0x310]
       lea      rdx, [rbp-0x110]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNextAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r10, bword ptr [rbp+0xC40]
       mov      r14, r10
       mov      rdx, gword ptr [rbp-0x110]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x108]
       mov      qword ptr [r14+0x08], rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       G_M000_IG250
 
G_M000_IG429:                ;; offset=0x3170
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG430
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG431
 
G_M000_IG430:                ;; offset=0x3199
       mov      r10, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7091D60
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG431:                ;; offset=0x31BF
       test     esi, esi
       jne      G_M000_IG250
       jmp      G_M000_IG337
 
G_M000_IG432:                ;; offset=0x31CC
       cmp      gword ptr [rbp+0xC30], 0
       setne    r8b
       movzx    r8, r8b
       mov      dword ptr [rsp+0x20], r8d
       lea      r8, [rbp+0xAA0]
       mov      qword ptr [rsp+0x28], r8
       mov      r8, bword ptr [rbp+0xBB8]
       mov      r8, gword ptr [r8]
       mov      rcx, rax
       mov      rdx, rdi
       mov      r9, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeUnaryBuiltin(Lokad.Lython.Runtime.LythonRuntime+BuiltinCallable,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG437
 
G_M000_IG433:                ;; offset=0x320E
       mov      rdx, gword ptr [rbp+0xAA0]
       mov      rcx, 0x7FF9D74F0AF8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      r14, rax
       test     r14, r14
       je       SHORT G_M000_IG435
 
G_M000_IG434:                ;; offset=0x322D
       jmp      G_M000_IG494
 
G_M000_IG435:                ;; offset=0x3232
       vmovdqu  xmm0, xmmword ptr [rbp+0xAA0]
       vmovdqu  xmmword ptr [rbp-0x2E0], xmm0
 
G_M000_IG436:                ;; offset=0x3242
       lea      r9, [rbp-0x2E0]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       mov      rcx, bword ptr [rbp+0xC20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG437:                ;; offset=0x3269
       mov      rcx, bword ptr [rbp+0xC20]
       lea      r14, bword ptr [rcx+0x20]
       lea      rcx, [rbp-0x2A8]
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      esi, [rbx+0x01]
       mov      r8d, esi
       lea      r9, [rbp-0x2A8]
       mov      rcx, r14
       mov      edx, ebx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishSlot(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      rcx, bword ptr [rbp+0xC20]
       lea      r14, bword ptr [rcx+0x20]
       lea      rcx, [rbp-0x2B8]
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       mov      edx, esi
       lea      r8d, [rbx+0x02]
       lea      r9, [rbp-0x2B8]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishSlot(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG296
 
G_M000_IG438:                ;; offset=0x32D2
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      rdx, 0x2C171C8D5C8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG439:                ;; offset=0x32F2
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG440:                ;; offset=0x32F9
       mov      rcx, rax
       mov      r11, 0x7FF9D7091CF0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rbx, rax
       jmp      G_M000_IG299
 
G_M000_IG441:                ;; offset=0x3311
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x2C171C8AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG442:                ;; offset=0x333F
       call     [CORINFO_HELP_CHKCASTCLASS]
       int3     
 
G_M000_IG443:                ;; offset=0x3346
       mov      gword ptr [rsp+0x20], r14
       lea      rcx, [rbp+0xA88]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, rbx
       mov      r9d, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDeferredChild(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       G_M000_IG153
 
G_M000_IG444:                ;; offset=0x3379
       cmp      gword ptr [rbp+0xA88], 0
       je       G_M000_IG02
 
G_M000_IG445:                ;; offset=0x3387
       mov      r8, gword ptr [rbp+0xA88]
       xor      r10, r10
       mov      r11, bword ptr [rbp+0xC50]
       mov      gword ptr [r11], r10
       lea      rcx, bword ptr [r11+0x08]
       mov      rdx, r8
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      r11, bword ptr [rbp+0xC50]
       mov      word  ptr [r11+0x10], 0
       mov      byte  ptr [r11+0x12], 1
       jmp      G_M000_IG319
 
G_M000_IG446:                ;; offset=0x33BF
       mov      rdx, r14
       mov      rcx, 0x7FF9D7885E98
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG447
       mov      rcx, rax
       call     [System.Threading.Tasks.Task:get_IsCompletedSuccessfully():bool:this]
       jmp      SHORT G_M000_IG448
 
G_M000_IG447:                ;; offset=0x33E2
       mov      r8, bword ptr [rbp+0xC50]
       movsx    rdx, word  ptr [r8+0x10]
       mov      rcx, r14
       mov      r11, 0x7FF9D7091D68
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetStatus(short):int:this
       cmp      eax, 1
       sete     al
       movzx    rax, al
 
G_M000_IG448:                ;; offset=0x3407
       test     eax, eax
       je       G_M000_IG319
       jmp      G_M000_IG316
 
G_M000_IG449:                ;; offset=0x3414
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7885E98
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      rdi, rax
       test     rdi, rdi
       je       SHORT G_M000_IG452
       mov      ecx, dword ptr [rdi+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       SHORT G_M000_IG451
 
G_M000_IG450:                ;; offset=0x3440
       mov      rcx, rdi
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG451:                ;; offset=0x344B
       mov      rdi, gword ptr [rdi+0x38]
       jmp      G_M000_IG318
 
G_M000_IG452:                ;; offset=0x3454
       mov      r8, bword ptr [rbp+0xC50]
       movsx    rdx, word  ptr [r8+0x10]
       mov      rcx, rsi
       mov      r11, 0x7FF9D7091D70
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetResult(short):System.__Canon:this
       mov      rdi, rax
       jmp      G_M000_IG318
 
G_M000_IG453:                ;; offset=0x3478
       xor      edx, edx
       mov      r8, bword ptr [rbp+0xC50]
       mov      qword ptr [r8], rdx
       mov      qword ptr [r8+0x08], rdx
       mov      qword ptr [r8+0x10], rdx
       jmp      G_M000_IG172
 
G_M000_IG454:                ;; offset=0x3491
       mov      rdx, r14
       mov      rcx, 0x7FF9D74847C8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG457
 
G_M000_IG455:                ;; offset=0x34A9
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG02
 
G_M000_IG456:                ;; offset=0x34BE
       mov      r8, rax
       mov      rcx, r8
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG02
 
G_M000_IG457:                ;; offset=0x34D1
       mov      rcx, r14
       movsx    rdx, word  ptr [rbp+0xB20]
       mov      r11, 0x7FF9D7091D78
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG02
 
G_M000_IG458:                ;; offset=0x34EE
       mov      gword ptr [rsp+0x20], r14
       mov      dword ptr [rsp+0x28], 1
       lea      rdx, [rbp-0xF0]
       mov      rcx, gword ptr [rbp+0xC30]
       mov      r8, rbx
       mov      r9d, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x100]
       lea      rdx, [rbp-0xF0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r10, bword ptr [rbp+0xC40]
       mov      r14, r10
       mov      rdx, gword ptr [rbp-0x100]
       mov      rcx, r14
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xF8]
       mov      qword ptr [r14+0x08], rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       G_M000_IG278
 
G_M000_IG459:                ;; offset=0x3560
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG460
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG461
 
G_M000_IG460:                ;; offset=0x3589
       mov      r10, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7091D80
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG461:                ;; offset=0x35AF
       test     esi, esi
       jne      G_M000_IG278
       jmp      G_M000_IG337
 
G_M000_IG462:                ;; offset=0x35BC
       mov      rcx, rdi
       mov      edx, r13d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.RuntimeErrors:NameNotDefined(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG463:                ;; offset=0x35E0
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x2C171C8AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG464:                ;; offset=0x360E
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG465:                ;; offset=0x3615
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x310], ymm0
 
G_M000_IG466:                ;; offset=0x3622
       lea      r8, [rbp-0x310]
       lea      rdx, [rbp-0x120]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteGetIteratorAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x130]
       lea      rdx, [rbp-0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, r10
       mov      rdx, gword ptr [rbp-0x130]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x128]
       mov      qword ptr [rbx+0x08], rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       G_M000_IG278
 
G_M000_IG467:                ;; offset=0x3688
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG468
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG469
 
G_M000_IG468:                ;; offset=0x36B1
       mov      r10, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7091D88
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG469:                ;; offset=0x36D7
       test     esi, esi
       jne      G_M000_IG278
       jmp      G_M000_IG337
 
G_M000_IG470:                ;; offset=0x36E4
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG471:                ;; offset=0x36EB
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x310], ymm0
 
G_M000_IG472:                ;; offset=0x36F8
       lea      r8, [rbp-0x310]
       lea      rdx, [rbp-0xD0]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSliceValueOperationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0xE0]
       lea      rdx, [rbp-0xD0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, r10
       mov      rdx, gword ptr [rbp-0xE0]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xD8]
       mov      qword ptr [rbx+0x08], rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       G_M000_IG278
 
G_M000_IG473:                ;; offset=0x375E
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG474
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG475
 
G_M000_IG474:                ;; offset=0x3787
       mov      r10, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7091D90
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG475:                ;; offset=0x37AD
       test     esi, esi
       jne      G_M000_IG278
       jmp      G_M000_IG337
 
G_M000_IG476:                ;; offset=0x37BA
       test     rbx, rbx
       je       G_M000_IG284
 
G_M000_IG477:                ;; offset=0x37C3
       mov      r8, 0x7FF9D77E9A80
       cmp      qword ptr [rbx], r8
       jne      G_M000_IG284
 
G_M000_IG478:                ;; offset=0x37D6
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG479:                ;; offset=0x37DD
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x310], ymm0
 
G_M000_IG480:                ;; offset=0x37EA
       lea      r8, [rbp-0x310]
       lea      rdx, [rbp-0xC0]
       mov      rcx, gword ptr [rbp+0xC30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteConditionalJumpAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, rcx
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xB8]
       mov      qword ptr [rbx+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [rcx]
       test     rbx, rbx
       je       G_M000_IG250
 
G_M000_IG481:                ;; offset=0x383E
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG482
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG483
 
G_M000_IG482:                ;; offset=0x3867
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7091D98
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG483:                ;; offset=0x388D
       test     esi, esi
       jne      G_M000_IG250
       jmp      G_M000_IG337
 
G_M000_IG484:                ;; offset=0x389A
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG485:                ;; offset=0x38A0
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG486:                ;; offset=0x38A6
       lea      rcx, [rbp+0xA58]
       mov      rdx, 0x2C171C92A40
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:GrowThenCopyString(System.String):this]
       jmp      G_M000_IG75
 
G_M000_IG487:                ;; offset=0x38C2
       mov      eax, dword ptr [rbp+0xB28]
 
G_M000_IG488:                ;; offset=0x38C8
       vzeroupper 
       add      rsp, 0xF78
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG489:                ;; offset=0x38DF
       mov      eax, 1
 
G_M000_IG490:                ;; offset=0x38E4
       vzeroupper 
       add      rsp, 0xF78
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG491:                ;; offset=0x38FB
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      gword ptr [rcx+0x40], 0
       je       G_M000_IG03
 
G_M000_IG492:                ;; offset=0x390D
       xor      rax, rax
       mov      rcx, bword ptr [rbp+0xC40]
       mov      gword ptr [rcx], rax
       mov      word  ptr [rcx+0x08], 0
       movzx    rax, byte  ptr [rbp+0xBCC]
       mov      byte  ptr [rcx+0x0A], al
       mov      byte  ptr [rcx+0x0B], 1
       mov      eax, 5
 
G_M000_IG493:                ;; offset=0x3932
       vzeroupper 
       add      rsp, 0xF78
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG494:                ;; offset=0x3949
       mov      r9, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [r9]
       mov      rcx, r14
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       je       SHORT G_M000_IG496
       mov      dword ptr [rbp+0xBCC], 1
       jmp      G_M000_IG02
 
G_M000_IG495:                ;; offset=0x397D
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      dword ptr [rcx+0x10], ebx
       mov      rcx, bword ptr [rbp+0xC20]
       jl       G_M000_IG06
       jmp      G_M000_IG489
 
G_M000_IG496:                ;; offset=0x3999
       mov      rcx, r14
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG497:                ;; offset=0x39A2
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG498:                ;; offset=0x39A8
       sub      rsp, 72
 
G_M000_IG499:                ;; offset=0x39AC
       mov      rbx, rcx
       cmp      gword ptr [rbp+0xC30], 0
       jne      SHORT G_M000_IG501
 
G_M000_IG500:                ;; offset=0x39B9
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG501:                ;; offset=0x39BF
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      rdx, rbx
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryRouteReturn(Lokad.Lython.Runtime.LythonRuntime+ReturnSignal,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG504
 
G_M000_IG502:                ;; offset=0x39E3
       mov      dword ptr [rbp+0xB28], 1
       lea      rax, G_M000_IG487
 
G_M000_IG503:                ;; offset=0x39F4
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG504:                ;; offset=0x39FC
       mov      dword ptr [rbp+0xBCC], 1
       lea      rax, G_M000_IG02
 
G_M000_IG505:                ;; offset=0x3A0D
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG506:                ;; offset=0x3A15
       sub      rsp, 72
 
G_M000_IG507:                ;; offset=0x3A19
       mov      rbx, rcx
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      r9, rax
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG509
 
G_M000_IG508:                ;; offset=0x3A47
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG509:                ;; offset=0x3A4D
       mov      dword ptr [rbp+0xBCC], 1
       lea      rax, G_M000_IG02
 
G_M000_IG510:                ;; offset=0x3A5E
       vzeroupper 
       add      rsp, 72
       ret      
 
RWD00  	dd	000006BEh ; case G_M000_IG69
       	dd	00000657h ; case G_M000_IG68
       	dd	000000E7h ; case G_M000_IG12
       	dd	00000E44h ; case G_M000_IG125
       	dd	00000DDAh ; case G_M000_IG124
       	dd	00000D46h ; case G_M000_IG122
       	dd	00000CD3h ; case G_M000_IG118
       	dd	00001DCAh ; case G_M000_IG270
       	dd	00001DCAh ; case G_M000_IG270
       	dd	000020BAh ; case G_M000_IG295
       	dd	000020BAh ; case G_M000_IG295
       	dd	00001DCAh ; case G_M000_IG270
       	dd	00001DCAh ; case G_M000_IG270
       	dd	00001DCAh ; case G_M000_IG270
       	dd	00001DCAh ; case G_M000_IG270
       	dd	00001DCAh ; case G_M000_IG270
       	dd	00001DCAh ; case G_M000_IG270
       	dd	00001DCAh ; case G_M000_IG270
       	dd	00001DCAh ; case G_M000_IG270
       	dd	00001DCAh ; case G_M000_IG270
       	dd	00001DCAh ; case G_M000_IG270
       	dd	00001DCAh ; case G_M000_IG270
       	dd	00001D9Bh ; case G_M000_IG269
       	dd	00001D9Bh ; case G_M000_IG269
       	dd	00001D71h ; case G_M000_IG267
       	dd	00001D4Ah ; case G_M000_IG266
       	dd	00001D22h ; case G_M000_IG265
       	dd	00001C90h ; case G_M000_IG263
       	dd	00001BE7h ; case G_M000_IG261
       	dd	00001B77h ; case G_M000_IG260
       	dd	00001B34h ; case G_M000_IG259
       	dd	00001AB7h ; case G_M000_IG258
       	dd	000019F5h ; case G_M000_IG253
       	dd	000019C8h ; case G_M000_IG251
       	dd	000019C8h ; case G_M000_IG251
       	dd	000019C8h ; case G_M000_IG251
       	dd	00001993h ; case G_M000_IG248
       	dd	00001993h ; case G_M000_IG248
       	dd	00001993h ; case G_M000_IG248
       	dd	000019C8h ; case G_M000_IG251
       	dd	00001728h ; case G_M000_IG219
       	dd	00000B86h ; case G_M000_IG102
       	dd	00002118h ; case G_M000_IG296
       	dd	00002090h ; case G_M000_IG294
       	dd	00002070h ; case G_M000_IG292
       	dd	0000205Dh ; case G_M000_IG291
       	dd	0000202Fh ; case G_M000_IG290
       	dd	0000202Fh ; case G_M000_IG290
       	dd	0000202Fh ; case G_M000_IG290
       	dd	00001F8Bh ; case G_M000_IG285
       	dd	00001F12h ; case G_M000_IG281
       	dd	00001EBAh ; case G_M000_IG279
       	dd	00001F8Bh ; case G_M000_IG285
       	dd	00001F8Bh ; case G_M000_IG285
       	dd	00001F8Bh ; case G_M000_IG285
       	dd	00001F8Bh ; case G_M000_IG285
       	dd	00001F8Bh ; case G_M000_IG285
       	dd	00001F8Bh ; case G_M000_IG285
       	dd	00001F8Bh ; case G_M000_IG285
       	dd	00001A17h ; case G_M000_IG255
       	dd	0000083Ch ; case G_M000_IG79
       	dd	00000802h ; case G_M000_IG76
       	dd	00001F8Bh ; case G_M000_IG285
       	dd	00001263h ; case G_M000_IG173
       	dd	00001263h ; case G_M000_IG173
       	dd	00001263h ; case G_M000_IG173
       	dd	00001263h ; case G_M000_IG173
       	dd	00001263h ; case G_M000_IG173
       	dd	0000122Ah ; case G_M000_IG171
       	dd	00000B5Dh ; case G_M000_IG100
       	dd	00000A2Ch ; case G_M000_IG92
       	dd	00000975h ; case G_M000_IG85
       	dd	0000093Dh ; case G_M000_IG84
       	dd	000008B9h ; case G_M000_IG82
RWD296 	dq	006E006B006E0055h, 0020006E0077006Fh, 0063006500780065h, 0062006100740075h
RWD328 	dq	006F00200065006Ch, 0064006F00630070h

; Total bytes of code 14950

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 0x420
       lea      rbp, [rsp+0x420]
       xor      eax, eax
       mov      qword ptr [rbp-0x3D8], rax
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x3D0], xmm4
       mov      rax, -960
 
G_M000_IG77:                ;; offset=0x002F
       vmovdqa  xmmword ptr [rax+rbp], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x10], xmm4
       vmovdqa  xmmword ptr [rbp+rax+0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG77
       mov      bword ptr [rbp+0x10], rcx
       mov      bword ptr [rbp+0x18], rdx
 
G_M000_IG02:                ;; offset=0x004E
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0xD0], rax
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rbp-0x248], rax
       mov      rcx, gword ptr [rbp-0x248]
       mov      rdx, 0x7FF9D7A37538
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x248]
       mov      gword ptr [rbp-0x278], rax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x27C], eax
       mov      rcx, gword ptr [rbp-0x278]
       mov      edx, dword ptr [rbp-0x27C]
       mov      r11, 0x7FF9D7092110
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x08], rax
       mov      rcx, bword ptr [rbp+0x18]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x0C], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0xD8], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_TargetOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0xDC], eax
       mov      rax, bword ptr [rbp-0xD8]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0xDC], eax
       jae      G_M000_IG66
       mov      rax, bword ptr [rbp-0xD8]
       mov      ecx, dword ptr [rbp-0xDC]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x288], rax
       mov      rdx, gword ptr [rbp-0x288]
       mov      rcx, 0x7FF9D77F2610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      gword ptr [rbp-0x18], rax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x28], xmm0
 
G_M000_IG03:                ;; offset=0x0157
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_IsPositionalOnly():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG04
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x20], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0x08]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      r9, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG53
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      G_M000_IG64
 
G_M000_IG04:                ;; offset=0x0198
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       jne      G_M000_IG09
       mov      rcx, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:IsRangeBuiltin(System.Object):bool]
       test     eax, eax
       je       G_M000_IG07
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0x200], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x204], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x28C], eax
       mov      r9d, dword ptr [rbp-0x28C]
       lea      rdx, [rbp-0x218]
       mov      r8d, dword ptr [rbp-0x204]
       mov      rcx, bword ptr [rbp-0x200]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG05:                ;; offset=0x021C
       vmovdqu  xmm0, xmmword ptr [rbp-0x218]
       vmovdqu  xmmword ptr [rbp-0x2A0], xmm0
 
G_M000_IG06:                ;; offset=0x022C
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x2A8], rax
       mov      rdx, gword ptr [rbp-0x2A8]
       lea      rcx, [rbp-0x2A0]
       lea      r9, [rbp-0x38]
       mov      rax, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeNativeRange(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG08
       mov      rcx, 0x7FF9D7A37640
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      G_M000_IG64
 
G_M000_IG07:                ;; offset=0x027C
       mov      rcx, 0x7FF9D7A37644
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG09
 
G_M000_IG08:                ;; offset=0x028D
       mov      rcx, 0x7FF9D7A37648
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x28]
       mov      rdx, gword ptr [rbp-0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       jmp      G_M000_IG53
 
G_M000_IG09:                ;; offset=0x02AF
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_HasReceiver():bool:this]
       test     eax, eax
       je       G_M000_IG44
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, 0x7FF9D76A4690
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x40], rax
       cmp      gword ptr [rbp-0x40], 0
       je       G_M000_IG21
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0x108], rax
       mov      rax, bword ptr [rbp-0x108]
       mov      eax, dword ptr [rax+0x08]
       cmp      dword ptr [rbp-0x0C], eax
       jae      G_M000_IG48
       mov      rax, bword ptr [rbp-0x108]
       mov      ecx, dword ptr [rbp-0x0C]
       shl      rcx, 4
       add      rcx, bword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      gword ptr [rbp-0x48], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       test     eax, eax
       jne      G_M000_IG25
       mov      rdx, gword ptr [rbp-0x48]
       mov      rcx, 0x7FF9D75B1030
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x50], rax
       cmp      gword ptr [rbp-0x50], 0
       je       G_M000_IG20
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_SplitPrefix():Lokad.Lython.Frontend.ExecutableSplitPrefix:this]
       mov      gword ptr [rbp-0x2B0], rax
       mov      rdx, gword ptr [rbp-0x2B0]
       mov      rcx, 0x7FF9D76A31D0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x58], rax
       cmp      gword ptr [rbp-0x58], 0
       je       G_M000_IG19
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCasedSplit:get_CasingMethod():Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod:this]
 
G_M000_IG10:                ;; offset=0x03A5
       cmp      rax, gword ptr [rbp-0x18]
       jne      G_M000_IG18
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG48
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
 
G_M000_IG11:                ;; offset=0x03DD
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x90], ymm0
 
G_M000_IG12:                ;; offset=0x03E9
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x180], rax
       mov      rax, gword ptr [rbp-0x180]
       mov      gword ptr [rbp-0x250], rax
       mov      rcx, gword ptr [rbp-0x250]
       mov      rdx, 0x7FF9D7A37650
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x250]
       mov      gword ptr [rbp-0x2B8], rax
       lea      rcx, [rbp-0x90]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x2BC], eax
       mov      rcx, gword ptr [rbp-0x2B8]
       mov      edx, dword ptr [rbp-0x2BC]
       mov      r11, 0x7FF9D7092128
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x98], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0x188], rax
       mov      rcx, gword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCasedSplit:get_CasingCallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x2C8], rax
       mov      rdx, gword ptr [rbp-0x2C8]
       mov      rcx, gword ptr [rbp-0x188]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG13:                ;; offset=0x049F
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0x190], rax
       lea      rax, bword ptr [rbp-0x28]
       mov      bword ptr [rbp-0x198], rax
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rbp-0x1A0], rax
       mov      rax, gword ptr [rbp-0x50]
       mov      gword ptr [rbp-0x1A8], rax
       mov      rax, gword ptr [rbp-0x190]
       mov      gword ptr [rbp-0x1B0], rax
       mov      rcx, gword ptr [rbp-0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ConsumedByIteration():bool:this]
       test     eax, eax
       jne      G_M000_IG15
       mov      rax, bword ptr [rbp-0x198]
       mov      bword ptr [rbp-0x1E0], rax
       mov      rax, gword ptr [rbp-0x1A0]
       mov      gword ptr [rbp-0x1E8], rax
       mov      rax, gword ptr [rbp-0x1A8]
       mov      gword ptr [rbp-0x1F0], rax
       mov      rax, gword ptr [rbp-0x1B0]
       mov      gword ptr [rbp-0x1F8], rax
       mov      rax, bword ptr [rbp+0x10]
       movzx    rax, byte  ptr [rax+0x40]
       test     eax, eax
       je       SHORT G_M000_IG14
       mov      rax, bword ptr [rbp-0x1E0]
       mov      bword ptr [rbp-0x1B8], rax
       mov      rax, gword ptr [rbp-0x1E8]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rax, gword ptr [rbp-0x1F0]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rax, gword ptr [rbp-0x1F8]
       mov      gword ptr [rbp-0x1D0], rax
       mov      rcx, gword ptr [rbp-0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ReturnedDirectly():bool:this]
       mov      dword ptr [rbp-0x1D4], eax
       jmp      G_M000_IG16
 
G_M000_IG14:                ;; offset=0x058A
       mov      rcx, 0x7FF9D7A37758
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x1E0]
       mov      bword ptr [rbp-0x1B8], rax
       mov      rax, gword ptr [rbp-0x1E8]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rax, gword ptr [rbp-0x1F0]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rax, gword ptr [rbp-0x1F8]
       mov      gword ptr [rbp-0x1D0], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x1D4], eax
       jmp      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x05DB
       mov      rcx, 0x7FF9D7A3775C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x198]
       mov      bword ptr [rbp-0x1B8], rax
       mov      rax, gword ptr [rbp-0x1A0]
       mov      gword ptr [rbp-0x1C0], rax
       mov      rax, gword ptr [rbp-0x1A8]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rax, gword ptr [rbp-0x1B0]
       mov      gword ptr [rbp-0x1D0], rax
       mov      dword ptr [rbp-0x1D4], 1
 
G_M000_IG16:                ;; offset=0x062C
       mov      rcx, gword ptr [rbp-0x1C0]
       mov      rdx, gword ptr [rbp-0x1C8]
       mov      r8, gword ptr [rbp-0x1D0]
       mov      r9d, dword ptr [rbp-0x1D4]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteCasedSplit(Lokad.Lython.Frontend.ExecutableCasedSplit,Lokad.Lython.Runtime.Text.PyString,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      gword ptr [rbp-0x2D0], rax
       mov      rdx, gword ptr [rbp-0x2D0]
       mov      rcx, bword ptr [rbp-0x1B8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       nop      
 
G_M000_IG17:                ;; offset=0x066A
       call     G_M000_IG67
       jmp      SHORT G_M000_IG22
 
G_M000_IG18:                ;; offset=0x0671
       mov      rcx, 0x7FF9D7A37760
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG25
 
G_M000_IG19:                ;; offset=0x0685
       mov      rcx, 0x7FF9D7A37764
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG25
 
G_M000_IG20:                ;; offset=0x0696
       mov      rcx, 0x7FF9D7A37768
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG25
 
G_M000_IG21:                ;; offset=0x06A7
       mov      rcx, 0x7FF9D7A3776C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG44
 
G_M000_IG22:                ;; offset=0x06BB
       mov      rcx, 0x7FF9D7A37774
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       add      dword ptr [rax+0x38], 2
 
G_M000_IG23:                ;; offset=0x06D2
       vmovdqu  xmm0, xmmword ptr [rbp-0x28]
       vmovdqu  xmmword ptr [rbp-0x2E0], xmm0
 
G_M000_IG24:                ;; offset=0x06DF
       lea      r8, [rbp-0x2E0]
       lea      rdx, [rbp-0x90]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      dword ptr [rbp-0x2C], 1
       jmp      G_M000_IG64
 
G_M000_IG25:                ;; offset=0x0703
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_SplitPrefix():Lokad.Lython.Frontend.ExecutableSplitPrefix:this]
       mov      gword ptr [rbp-0x2E8], rax
       mov      rdx, gword ptr [rbp-0x2E8]
       mov      rcx, 0x7FF9D77F3450
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x60], rax
       cmp      gword ptr [rbp-0x60], 0
       je       G_M000_IG35
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       add      ecx, 3
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG48
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       cmp      eax, dword ptr [rbp-0x0C]
       jne      G_M000_IG34
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG26:                ;; offset=0x0780
       vmovdqu  xmm0, xmmword ptr [rax+0x48]
       vmovdqu  xmmword ptr [rbp-0x2F8], xmm0
 
G_M000_IG27:                ;; offset=0x078D
       lea      rdx, [rbp-0x2F8]
       lea      rcx, [rbp-0x150]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG28:                ;; offset=0x07A1
       vmovdqu  xmm0, xmmword ptr [rbp-0x150]
       vmovdqu  xmmword ptr [rbp-0x308], xmm0
 
G_M000_IG29:                ;; offset=0x07B1
       lea      rax, [rbp-0x68]
       mov      qword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x70]
       mov      qword ptr [rsp+0x28], rax
       lea      r8, [rbp-0x308]
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, gword ptr [rbp-0x08]
       mov      r9d, dword ptr [rbp-0x0C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryReadAsciiTrim(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,byref,byref):bool]
       test     eax, eax
       je       G_M000_IG33
       mov      rcx, 0x7FF9D7A37778
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x158], rax
       mov      rax, gword ptr [rbp-0x158]
       mov      gword ptr [rbp-0x258], rax
       mov      rcx, gword ptr [rbp-0x258]
       mov      rdx, 0x7FF9D7A37780
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x258]
       mov      gword ptr [rbp-0x310], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       add      ecx, 3
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG48
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x314], eax
       mov      rcx, gword ptr [rbp-0x310]
       mov      edx, dword ptr [rbp-0x314]
       mov      r11, 0x7FF9D7092120
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0xA0], rax
       mov      rax, gword ptr [rbp-0x68]
       mov      gword ptr [rbp-0x160], rax
       movzx    rax, byte  ptr [rbp-0x70]
       mov      dword ptr [rbp-0x164], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x170], rax
       mov      rcx, gword ptr [rbp-0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
 
G_M000_IG30:                ;; offset=0x08D1
       mov      gword ptr [rbp-0x178], rax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xB0], xmm0
       mov      rax, gword ptr [rbp-0x178]
       mov      gword ptr [rsp+0x20], rax
 
G_M000_IG31:                ;; offset=0x08F0
       vmovdqu  xmm0, xmmword ptr [rbp-0xB0]
       vmovdqu  xmmword ptr [rbp-0x328], xmm0
 
G_M000_IG32:                ;; offset=0x0900
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x328]
       mov      qword ptr [rsp+0x28], rax
       mov      rdx, gword ptr [rbp-0x160]
       mov      r8d, dword ptr [rbp-0x164]
       mov      r9, gword ptr [rbp-0x170]
       mov      rcx, gword ptr [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteTrimmedSplit(Lokad.Lython.Frontend.ExecutableTrimmedSplit,Lokad.Lython.Runtime.Text.PyString,byte,Lokad.Lython.LythonSourceSpan,Lokad.Lython.LythonSourceSpan,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x330], rax
       mov      rdx, gword ptr [rbp-0x330]
       lea      rcx, [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       mov      rax, bword ptr [rbp+0x10]
       add      dword ptr [rax+0x38], 3
       jmp      G_M000_IG53
 
G_M000_IG33:                ;; offset=0x095D
       mov      rcx, 0x7FF9D7A37888
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG35
 
G_M000_IG34:                ;; offset=0x096E
       mov      rcx, 0x7FF9D7A3788C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG35:                ;; offset=0x097D
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x110], rax
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG36:                ;; offset=0x0990
       vmovdqu  xmm0, xmmword ptr [rax+0x48]
       vmovdqu  xmmword ptr [rbp-0x340], xmm0
 
G_M000_IG37:                ;; offset=0x099D
       lea      rdx, [rbp-0x340]
       lea      rcx, [rbp-0x120]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
 
G_M000_IG38:                ;; offset=0x09B1
       vmovdqu  xmm0, xmmword ptr [rbp-0x120]
       vmovdqu  xmmword ptr [rbp-0x350], xmm0
 
G_M000_IG39:                ;; offset=0x09C1
       mov      rax, gword ptr [rbp-0x08]
       mov      gword ptr [rsp+0x20], rax
       mov      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rsp+0x28], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x30], rax
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x38], rax
       lea      r8, [rbp-0x350]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      r9, bword ptr [rax+0x38]
       mov      rdx, gword ptr [rbp-0x110]
       mov      rcx, gword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryConsumePrivateStringResult(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG42
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 72
       mov      bword ptr [rbp-0x128], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentOffset():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x12C], eax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_ArgumentCount():int:this]
       mov      dword ptr [rbp-0x354], eax
       mov      r9d, dword ptr [rbp-0x354]
       lea      rdx, [rbp-0x140]
       mov      r8d, dword ptr [rbp-0x12C]
       mov      rcx, bword ptr [rbp-0x128]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG40:                ;; offset=0x0A73
       vmovdqu  xmm0, xmmword ptr [rbp-0x140]
       vmovdqu  xmmword ptr [rbp-0x368], xmm0
 
G_M000_IG41:                ;; offset=0x0A83
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x370], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x20], rax
       lea      rax, [rbp-0xB8]
       mov      qword ptr [rsp+0x28], rax
       mov      r9, gword ptr [rbp-0x370]
       lea      r8, [rbp-0x368]
       mov      rdx, gword ptr [rbp-0x48]
       mov      rcx, gword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG43
       mov      rcx, 0x7FF9D7A37890
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      G_M000_IG64
 
G_M000_IG42:                ;; offset=0x0AE8
       mov      rcx, 0x7FF9D7A37894
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG53
 
G_M000_IG43:                ;; offset=0x0AFC
       mov      rcx, 0x7FF9D7A37898
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x28]
       mov      rdx, gword ptr [rbp-0xB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:set_Object(System.Object):this]
       jmp      G_M000_IG53
 
G_M000_IG44:                ;; offset=0x0B21
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG45:                ;; offset=0x0B25
       vmovdqu  xmm0, xmmword ptr [rax+0x48]
       vmovdqu  xmmword ptr [rbp-0x380], xmm0
 
G_M000_IG46:                ;; offset=0x0B32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rsp+0x20], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x30], rax
       lea      r8, [rbp-0x380]
       mov      rdx, gword ptr [rbp-0x18]
       mov      rcx, gword ptr [rbp-0x08]
       mov      r9d, dword ptr [rbp-0x0C]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeBuiltinFromSlots(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG51
       lea      rcx, [rbp-0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x260], rax
       mov      rcx, gword ptr [rbp-0x260]
       mov      rdx, 0x7FF9D7A378A0
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x260]
       mov      gword ptr [rbp-0x388], rax
       mov      rdx, gword ptr [rbp-0x388]
       mov      rcx, 0x7FF9D74F0AF8
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0xC0], rax
       cmp      gword ptr [rbp-0xC0], 0
       je       SHORT G_M000_IG49
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ExceptionRegions():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableExceptionRegion]:this]
       mov      gword ptr [rbp-0x268], rax
       mov      rcx, gword ptr [rbp-0x268]
       mov      rdx, 0x7FF9D7A379A8
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x268]
       mov      gword ptr [rbp-0x390], rax
       mov      rcx, gword ptr [rbp-0x390]
       mov      r11, 0x7FF9D7092118
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       test     eax, eax
       jne      SHORT G_M000_IG50
 
G_M000_IG47:                ;; offset=0x0C1F
       mov      rcx, gword ptr [rbp-0xC0]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG48:                ;; offset=0x0C2C
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG49:                ;; offset=0x0C32
       mov      rcx, 0x7FF9D7A37AB0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG53
 
G_M000_IG50:                ;; offset=0x0C43
       mov      rcx, 0x7FF9D7A37AB4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:set_Failure(Lokad.Lython.Runtime.LythonRuntimeException):this]
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      G_M000_IG64
 
G_M000_IG51:                ;; offset=0x0C6D
       lea      rax, [rbp-0x28]
       mov      qword ptr [rsp+0x20], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp-0x08]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      r9, gword ptr [rbp-0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG52
       mov      rcx, 0x7FF9D7A37AB8
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
       mov      dword ptr [rbp-0x2C], eax
       jmp      G_M000_IG64
 
G_M000_IG52:                ;; offset=0x0CA9
       mov      rcx, 0x7FF9D7A37ABC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG53:                ;; offset=0x0CB8
       nop      
 
G_M000_IG54:                ;; offset=0x0CB9
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       test     eax, eax
       je       G_M000_IG59
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG66
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 15
       jne      G_M000_IG58
       mov      rcx, 0x7FF9D7A37BD0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x10]
       mov      gword ptr [rbp-0xE8], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG66
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x3A8], rax
       mov      rdx, gword ptr [rbp-0x3A8]
       mov      rcx, gword ptr [rbp-0xE8]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       add      eax, dword ptr [rbp-0x0C]
       mov      dword ptr [rbp-0x3AC], eax
       mov      edx, dword ptr [rbp-0x3AC]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
 
G_M000_IG55:                ;; offset=0x0DA8
       add      rax, 72
       mov      bword ptr [rbp-0xF0], rax
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_UnpackedReturnCount():int:this]
       mov      dword ptr [rbp-0x3B0], eax
       mov      r9d, dword ptr [rbp-0x3B0]
       lea      rdx, [rbp-0x100]
       mov      r8d, dword ptr [rbp-0x0C]
       mov      rcx, bword ptr [rbp-0xF0]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:Slice(int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:this]
 
G_M000_IG56:                ;; offset=0x0DE4
       vmovdqu  xmm0, xmmword ptr [rbp-0x100]
       vmovdqu  xmmword ptr [rbp-0x3C0], xmm0
 
G_M000_IG57:                ;; offset=0x0DF4
       lea      rcx, [rbp-0x3C0]
       call     [System.MemoryExtensions:Reverse[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       jmp      SHORT G_M000_IG62
 
G_M000_IG58:                ;; offset=0x0E03
       mov      rcx, 0x7FF9D7A37BD4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG59:                ;; offset=0x0E12
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [rcx+0x38]
       cmp      ecx, dword ptr [rax+0x08]
       jae      SHORT G_M000_IG66
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x3D8], rax
 
G_M000_IG60:                ;; offset=0x0E40
       vmovdqu  xmm0, xmmword ptr [rbp-0x28]
       vmovdqu  xmmword ptr [rbp-0x3D0], xmm0
 
G_M000_IG61:                ;; offset=0x0E4D
       mov      rdx, bword ptr [rbp-0x3D8]
       lea      r8, [rbp-0x3D0]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
 
G_M000_IG62:                ;; offset=0x0E65
       mov      rcx, 0x7FF9D7A37BD8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, 1
 
G_M000_IG63:                ;; offset=0x0E79
       vzeroupper 
       add      rsp, 0x420
       pop      rbp
       ret      
 
G_M000_IG64:                ;; offset=0x0E85
       mov      rcx, 0x7FF9D7A37BDC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x2C]
 
G_M000_IG65:                ;; offset=0x0E97
       vzeroupper 
       add      rsp, 0x420
       pop      rbp
       ret      
 
G_M000_IG66:                ;; offset=0x0EA3
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG67:                ;; offset=0x0EA9
       sub      rsp, 72
 
G_M000_IG68:                ;; offset=0x0EAD
       mov      rcx, 0x7FF9D7A37770
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax+0x10]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
       nop      
 
G_M000_IG69:                ;; offset=0x0ECD
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG70:                ;; offset=0x0ED5
       sub      rsp, 72
 
G_M000_IG71:                ;; offset=0x0ED9
       mov      gword ptr [rbp-0x220], rcx
       mov      rax, gword ptr [rbp-0x220]
       mov      gword ptr [rbp-0x270], rax
       mov      rcx, gword ptr [rbp-0x270]
       mov      rdx, 0x7FF9D7A37AC0
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x270]
       mov      gword ptr [rbp-0x398], rax
       mov      rdx, gword ptr [rbp-0x398]
       mov      rcx, 0x7FF9D7192168
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x228], rax
       mov      rax, gword ptr [rbp-0x228]
       mov      gword ptr [rbp-0x230], rax
       cmp      gword ptr [rbp-0x228], 0
       jne      SHORT G_M000_IG72
       xor      eax, eax
       mov      dword ptr [rbp-0x234], eax
       jmp      SHORT G_M000_IG73
 
G_M000_IG72:                ;; offset=0x0F52
       mov      rcx, 0x7FF9D7A37BC8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp-0x08]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x3A0], rax
       mov      rdx, gword ptr [rbp-0x3A0]
       lea      r8, [rbp-0xC8]
       mov      rcx, gword ptr [rbp-0x230]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       setne    al
       movzx    rax, al
       mov      dword ptr [rbp-0x234], eax
 
G_M000_IG73:                ;; offset=0x0F9D
       mov      rcx, 0x7FF9D7A37BCC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x234]
 
G_M000_IG74:                ;; offset=0x0FB2
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG75:                ;; offset=0x0FBA
       sub      rsp, 72
 
G_M000_IG76:                ;; offset=0x0FBE
       mov      gword ptr [rbp-0x240], rcx
       mov      rcx, gword ptr [rbp-0xC8]
       call     CORINFO_HELP_THROW
       int3     
 
; Total bytes of code 4050

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Call(byref):bool:this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 92080
; 30 inlinees with PGO data; 108 single block inlinees; 1 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 248
       lea      rbp, [rsp+0x130]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xE0], ymm4
       vmovdqu  ymmword ptr [rbp-0xC0], ymm4
       vmovdqu  ymmword ptr [rbp-0xA0], ymm4
       vmovdqu  ymmword ptr [rbp-0x80], ymm4
       vmovdqu  ymmword ptr [rbp-0x60], ymm4
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      rbx, rdx
 
G_M000_IG02:                ;; offset=0x004E
       mov      rax, gword ptr [rcx+0x08]
       mov      rax, gword ptr [rax+0xB0]
       mov      edx, dword ptr [rbx+0x1C]
       cmp      edx, 42
       jne      G_M000_IG114
 
G_M000_IG03:                ;; offset=0x0065
       mov      edx, dword ptr [rbx+0x08]
       mov      r8, 0x7FF9D7638680
       cmp      qword ptr [rax], r8
       jne      G_M000_IG116
       mov      r8d, dword ptr [rax+0x08]
       cmp      r8d, edx
       jbe      G_M000_IG115
       mov      rsi, gword ptr [rax+8*rdx+0x10]
 
G_M000_IG04:                ;; offset=0x008D
       mov      gword ptr [rbp-0xE8], rsi
       mov      eax, dword ptr [rbx+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x009C
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG117
 
G_M000_IG06:                ;; offset=0x00B0
       mov      edi, dword ptr [rbx+0x14]
 
G_M000_IG07:                ;; offset=0x00B3
       mov      rcx, bword ptr [rbp+0x10]
       lea      rbx, bword ptr [rcx+0x48]
       mov      rax, rbx
       cmp      byte  ptr [rsi+0x30], 0
       setne    dl
       movzx    rdx, dl
       add      edx, edi
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG124
       shl      rdx, 4
       add      rdx, bword ptr [rax]
       mov      r14, gword ptr [rdx]
       mov      rax, 0x2A14B001CE0
       cmp      r14, gword ptr [rax]
       je       G_M000_IG118
 
G_M000_IG08:                ;; offset=0x00F0
       mov      rax, 0x2A14B001CE8
       cmp      r14, gword ptr [rax]
       je       G_M000_IG119
       cmp      qword ptr [rdx+0x08], 0
       jne      G_M000_IG120
 
G_M000_IG09:                ;; offset=0x010E
       test     r14, r14
       je       G_M000_IG121
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
 
G_M000_IG10:                ;; offset=0x0120
       cmp      byte  ptr [rsi+0x34], 0
       je       G_M000_IG71
 
G_M000_IG11:                ;; offset=0x012A
       cmp      byte  ptr [rsi+0x30], 0
       je       G_M000_IG72
 
G_M000_IG12:                ;; offset=0x0134
       cmp      byte  ptr [rsi+0x30], 0
       je       G_M000_IG68
 
G_M000_IG13:                ;; offset=0x013E
       mov      rax, 0x7FF9D76A4690
       cmp      qword ptr [r14], rax
       jne      G_M000_IG68
 
G_M000_IG14:                ;; offset=0x0151
       mov      rax, rbx
       cmp      edi, dword ptr [rax+0x08]
       jae      G_M000_IG103
       mov      edx, edi
       shl      rdx, 4
       add      rdx, bword ptr [rax]
       mov      r15, gword ptr [rdx]
       mov      rax, 0x2A14B001CE0
       cmp      r15, gword ptr [rax]
       je       G_M000_IG76
 
G_M000_IG15:                ;; offset=0x017C
       mov      rax, 0x2A14B001CE8
       cmp      r15, gword ptr [rax]
       je       G_M000_IG77
       cmp      qword ptr [rdx+0x08], 0
       jne      G_M000_IG78
 
G_M000_IG16:                ;; offset=0x019A
       cmp      dword ptr [rsi+0x28], 0
       jne      G_M000_IG54
       test     r15, r15
       je       G_M000_IG54
 
G_M000_IG17:                ;; offset=0x01AD
       mov      rax, 0x7FF9D75B1030
       cmp      qword ptr [r15], rax
       jne      G_M000_IG54
 
G_M000_IG18:                ;; offset=0x01C0
       mov      r13, r15
       mov      r12, gword ptr [rsi+0x20]
       test     r12, r12
       je       G_M000_IG54
 
G_M000_IG19:                ;; offset=0x01D0
       mov      rax, 0x7FF9D76A31D0
       cmp      qword ptr [r12], rax
       jne      G_M000_IG54
 
G_M000_IG20:                ;; offset=0x01E4
       cmp      r14, gword ptr [r12+0x08]
       jne      G_M000_IG54
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x08]
       mov      rax, gword ptr [rax+0x98]
       mov      edx, dword ptr [rcx+0x38]
       add      edx, 2
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG103
       shl      rdx, 5
 
G_M000_IG21:                ;; offset=0x0211
       vmovdqu  ymm0, ymmword ptr [rax+rdx+0x10]
       vmovdqu  ymmword ptr [rbp-0x80], ymm0
 
G_M000_IG22:                ;; offset=0x021C
       mov      rax, gword ptr [rcx+0x08]
       mov      rax, gword ptr [rax+0xB0]
       mov      edx, dword ptr [rbp-0x64]
       cmp      edx, 42
       jne      G_M000_IG79
 
G_M000_IG23:                ;; offset=0x0233
       mov      edx, dword ptr [rbp-0x78]
       mov      r8, 0x7FF9D7638680
       cmp      qword ptr [rax], r8
       jne      G_M000_IG81
       mov      r8d, dword ptr [rax+0x08]
       cmp      r8d, edx
       jbe      G_M000_IG80
       mov      rsi, gword ptr [rax+8*rdx+0x10]
 
G_M000_IG24:                ;; offset=0x025B
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x10]
       mov      rax, gword ptr [r12+0x18]
       mov      rcx, gword ptr [rdx+0x98]
       mov      rdx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG25:                ;; offset=0x027B
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdi, gword ptr [rcx+0x10]
       cmp      byte  ptr [rsi+0x31], 0
       jne      G_M000_IG33
       cmp      byte  ptr [rcx+0x40], 0
       je       G_M000_IG32
       movzx    r14, byte  ptr [rsi+0x32]
 
G_M000_IG26:                ;; offset=0x029C
       mov      rdx, gword ptr [r12+0x10]
       mov      rax, gword ptr [rdi+0x98]
       mov      r8, gword ptr [rax+0x88]
       cmp      gword ptr [r8+0x20], 0
       jne      G_M000_IG35
       mov      r8, gword ptr [rax+0x180]
       test     r8, r8
       jne      G_M000_IG34
 
G_M000_IG27:                ;; offset=0x02CA
       mov      rdx, gword ptr [r12+0x18]
       mov      rax, gword ptr [rdi+0x98]
       mov      r8, gword ptr [rax+0x88]
       cmp      gword ptr [r8+0x20], 0
       jne      G_M000_IG37
       mov      r8, gword ptr [rax+0x180]
       test     r8, r8
       jne      G_M000_IG36
 
G_M000_IG28:                ;; offset=0x02F8
       mov      rdx, gword ptr [r12+0x20]
       mov      rax, gword ptr [rdi+0x98]
       mov      r8, gword ptr [rax+0x88]
       cmp      gword ptr [r8+0x20], 0
       jne      G_M000_IG39
       mov      r8, gword ptr [rax+0x180]
       test     r8, r8
       jne      G_M000_IG38
 
G_M000_IG29:                ;; offset=0x0326
       mov      rdx, gword ptr [r12+0x28]
       mov      rax, gword ptr [rdi+0x98]
       mov      r8, gword ptr [rax+0x88]
       cmp      gword ptr [r8+0x20], 0
       jne      G_M000_IG41
       mov      r8, gword ptr [rax+0x180]
       test     r8, r8
       jne      G_M000_IG40
 
G_M000_IG30:                ;; offset=0x0354
       test     r14d, r14d
       je       G_M000_IG42
       movzx    rdx, byte  ptr [r12+0x30]
       mov      r9, gword ptr [r12+0x28]
       mov      rcx, r13
       mov      r8, rdi
       call     [Lokad.Lython.Runtime.Text.PyStringOps:PrepareCasedWhitespaceIteration(Lokad.Lython.Runtime.Text.PyString,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration]
 
G_M000_IG31:                ;; offset=0x0374
       mov      gword ptr [rbp-0x48], rax
       xor      ecx, ecx
       mov      qword ptr [rbp-0x40], rcx
       jmp      G_M000_IG43
 
G_M000_IG32:                ;; offset=0x0383
       xor      r14d, r14d
       jmp      G_M000_IG26
 
G_M000_IG33:                ;; offset=0x038B
       mov      r14d, 1
       jmp      G_M000_IG26
 
G_M000_IG34:                ;; offset=0x0396
       cmp      dword ptr [r8+0x20], 0
       setne    r8b
       movzx    r8, r8b
       test     r8d, r8d
       je       G_M000_IG27
 
G_M000_IG35:                ;; offset=0x03AC
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG27
 
G_M000_IG36:                ;; offset=0x03BA
       cmp      dword ptr [r8+0x20], 0
       setne    r8b
       movzx    r8, r8b
       test     r8d, r8d
       je       G_M000_IG28
 
G_M000_IG37:                ;; offset=0x03D0
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG28
 
G_M000_IG38:                ;; offset=0x03DE
       cmp      dword ptr [r8+0x20], 0
       setne    r8b
       movzx    r8, r8b
       test     r8d, r8d
       je       G_M000_IG29
 
G_M000_IG39:                ;; offset=0x03F4
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG29
 
G_M000_IG40:                ;; offset=0x0402
       cmp      dword ptr [r8+0x20], 0
       setne    r8b
       movzx    r8, r8b
       test     r8d, r8d
       je       G_M000_IG30
 
G_M000_IG41:                ;; offset=0x0418
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG30
 
G_M000_IG42:                ;; offset=0x0426
       movzx    rdx, byte  ptr [r12+0x30]
       mov      gword ptr [rsp+0x20], rdi
       mov      r8, gword ptr [rdi+0x98]
       mov      r8, gword ptr [r8+0x88]
       mov      r9, gword ptr [r12+0x28]
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.Text.PyStringOps:SplitCasedWhitespace(Lokad.Lython.Runtime.Text.PyString,bool,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       jmp      G_M000_IG31
 
G_M000_IG43:                ;; offset=0x0452
       mov      rcx, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [rcx+0x10]
       mov      rdi, gword ptr [rsi+0x98]
       mov      rax, qword ptr [rdi+0x160]
       test     rax, rax
       jle      SHORT G_M000_IG45
 
G_M000_IG44:                ;; offset=0x046D
       dec      rax
       mov      qword ptr [rdi+0x160], rax
 
G_M000_IG45:                ;; offset=0x0477
       add      dword ptr [rcx+0x38], 2
 
G_M000_IG46:                ;; offset=0x047B
       vmovdqu  xmm0, xmmword ptr [rbp-0x48]
       vmovdqu  xmmword ptr [rbp-0xC0], xmm0
 
G_M000_IG47:                ;; offset=0x0488
       mov      r15d, dword ptr [rbp-0x68]
       test     r15d, r15d
       jl       G_M000_IG84
 
G_M000_IG48:                ;; offset=0x0495
       mov      eax, dword ptr [rbp-0x64]
       cmp      eax, 51
       ja       SHORT G_M000_IG50
 
G_M000_IG49:                ;; offset=0x049D
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG82
 
G_M000_IG50:                ;; offset=0x04B1
       mov      r15d, dword ptr [rbp-0x6C]
 
G_M000_IG51:                ;; offset=0x04B5
       mov      edx, dword ptr [rbp-0x68]
       mov      esi, edx
       not      esi
       test     edx, edx
       cmovge   esi, edx
       mov      rdi, gword ptr [rbp-0xC0]
       mov      r14, qword ptr [rbp-0xB8]
       mov      rcx, bword ptr [rbp+0x10]
       cmp      esi, dword ptr [rcx+0x3C]
       jl       G_M000_IG83
 
G_M000_IG52:                ;; offset=0x04DC
       cmp      r15d, dword ptr [rbx+0x08]
       jae      G_M000_IG103
       mov      r15d, r15d
       shl      r15, 4
       add      r15, bword ptr [rbx]
       mov      rcx, r15
       mov      rdx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      qword ptr [r15+0x08], r14
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x3C], esi
 
G_M000_IG53:                ;; offset=0x0506
       mov      eax, 1
       jmp      G_M000_IG104
 
G_M000_IG54:                ;; offset=0x0510
       mov      rdx, gword ptr [rsi+0x20]
       test     rdx, rdx
       je       SHORT G_M000_IG56
 
G_M000_IG55:                ;; offset=0x0519
       mov      rax, 0x7FF9D77F3450
       xor      r8, r8
       cmp      qword ptr [rdx], rax
       cmovne   rdx, r8
 
G_M000_IG56:                ;; offset=0x052D
       mov      r13, rdx
       test     r13, r13
       je       G_M000_IG62
 
G_M000_IG57:                ;; offset=0x0539
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rcx+0x08]
       mov      rdx, gword ptr [rdx+0x98]
       mov      eax, dword ptr [rcx+0x38]
       add      eax, 3
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG103
       shl      rax, 5
       cmp      dword ptr [rdx+rax+0x20], edi
       jne      G_M000_IG62
 
G_M000_IG58:                ;; offset=0x0565
       vmovdqu  xmm0, xmmword ptr [rbx]
       vmovdqu  xmmword ptr [rbp-0xD0], xmm0
 
G_M000_IG59:                ;; offset=0x0571
       lea      rdx, [rbp-0xD0]
       lea      rcx, [rbp-0xB0]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       lea      r8, [rbp-0x58]
       mov      qword ptr [rsp+0x20], r8
       lea      r8, [rbp-0x60]
       mov      qword ptr [rsp+0x28], r8
       lea      r8, [rbp-0xB0]
       mov      rcx, rsi
       mov      rdx, r14
       mov      r9d, edi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryReadAsciiTrim(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,byref,byref):bool]
       test     eax, eax
       je       G_M000_IG62
 
G_M000_IG60:                ;; offset=0x05B5
       mov      r12, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r12+0x08]
       mov      r14, gword ptr [rcx+0xB0]
       mov      rcx, gword ptr [rcx+0x98]
       mov      eax, dword ptr [r12+0x38]
       add      eax, 3
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG103
       shl      rax, 5
       lea      rcx, bword ptr [rcx+rax+0x10]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      edx, eax
       mov      rcx, r14
       mov      r11, 0x7FF9D70927E8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdx, gword ptr [rbp-0x58]
       movzx    r8, byte  ptr [rbp-0x60]
       mov      r9, gword ptr [rsi+0x18]
       mov      rcx, gword ptr [rax+0x18]
       mov      gword ptr [rsp+0x20], rcx
       xor      rcx, rcx
       mov      bword ptr [rbp-0xD0], rcx
 
G_M000_IG61:                ;; offset=0x061D
       mov      dword ptr [rbp-0xC8], ecx
       mov      rcx, gword ptr [r12+0x10]
       mov      gword ptr [rsp+0x30], rcx
       lea      rcx, [rbp-0xD0]
       mov      qword ptr [rsp+0x28], rcx
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteTrimmedSplit(Lokad.Lython.Frontend.ExecutableTrimmedSplit,Lokad.Lython.Runtime.Text.PyString,byte,Lokad.Lython.LythonSourceSpan,Lokad.Lython.LythonSourceSpan,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x48], rax
       xor      edx, edx
       mov      qword ptr [rbp-0x40], rdx
       add      dword ptr [r12+0x38], 3
       jmp      G_M000_IG105
 
G_M000_IG62:                ;; offset=0x0657
       mov      rcx, bword ptr [rbp+0x10]
       mov      r13, gword ptr [rcx+0x08]
 
G_M000_IG63:                ;; offset=0x065F
       vmovdqu  xmm0, xmmword ptr [rbx]
       vmovdqu  xmmword ptr [rbp-0xD0], xmm0
 
G_M000_IG64:                ;; offset=0x066B
       lea      rdx, [rbp-0xD0]
       lea      rcx, [rbp-0xA0]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      gword ptr [rsp+0x20], rsi
       mov      dword ptr [rsp+0x28], edi
       mov      r12, bword ptr [rbp+0x10]
       mov      r9, gword ptr [r12+0x10]
       mov      gword ptr [rsp+0x30], r9
       lea      r9, [rbp-0x48]
       mov      qword ptr [rsp+0x38], r9
       lea      r9, bword ptr [r12+0x38]
       lea      r8, [rbp-0xA0]
       mov      rcx, r14
       mov      rdx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:TryConsumePrivateStringResult(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,Lokad.Lython.Frontend.ExecutableCodeObject,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Frontend.ExecutableCallSite,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG105
 
G_M000_IG65:                ;; offset=0x06BF
       mov      r8, rbx
       cmp      byte  ptr [rsi+0x30], 0
       setne    r9b
       movzx    r9, r9b
       lea      r9d, [rdi+r9+0x01]
       mov      edx, dword ptr [rsi+0x28]
       mov      ecx, edx
       add      rcx, r9
       mov      eax, dword ptr [r8+0x08]
       cmp      rcx, rax
       ja       G_M000_IG74
       shl      r9, 4
       add      r9, bword ptr [r8]
       mov      bword ptr [rbp-0xD0], r9
       mov      dword ptr [rbp-0xC8], edx
       mov      r8, gword ptr [r12+0x10]
       mov      gword ptr [rsp+0x20], r8
       lea      r8, [rbp-0x88]
       mov      qword ptr [rsp+0x28], r8
       lea      r8, [rbp-0xD0]
       mov      r9, gword ptr [rsi+0x18]
       mov      rdx, r15
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeClosedReceiver(Lokad.Lython.Runtime.LythonRuntime+ReceiverMethod,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG70
 
G_M000_IG66:                ;; offset=0x0731
       mov      r8, gword ptr [rbp-0x88]
       mov      gword ptr [rbp-0x48], r8
 
G_M000_IG67:                ;; offset=0x073C
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       jmp      G_M000_IG105
 
G_M000_IG68:                ;; offset=0x0747
       vmovdqu  xmm0, xmmword ptr [rbx]
       vmovdqu  xmmword ptr [rbp-0xD0], xmm0
 
G_M000_IG69:                ;; offset=0x0753
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rcx+0x10]
       mov      gword ptr [rsp+0x20], r8
       xor      r8d, r8d
       mov      dword ptr [rsp+0x28], r8d
       lea      r8, [rbp-0x48]
       mov      qword ptr [rsp+0x30], r8
       lea      r8, [rbp-0xD0]
       mov      rdx, r14
       mov      rcx, rsi
       mov      r9d, edi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeBuiltinFromSlots(Lokad.Lython.Frontend.ExecutableCallSite,System.Object,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       jne      G_M000_IG101
       lea      rcx, [rbp-0x48]
       mov      qword ptr [rsp+0x20], rcx
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, rsi
       mov      r8d, edi
       mov      r9, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG105
 
G_M000_IG70:                ;; offset=0x07B3
       xor      eax, eax
       jmp      G_M000_IG104
 
G_M000_IG71:                ;; offset=0x07BA
       lea      rdx, [rbp-0x48]
       mov      qword ptr [rsp+0x20], rdx
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, rsi
       mov      r8d, edi
       mov      r9, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:CallFunction(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG105
       jmp      SHORT G_M000_IG70
 
G_M000_IG72:                ;; offset=0x07E0
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:IsRangeBuiltin(System.Object):bool]
       test     eax, eax
       je       G_M000_IG12
 
G_M000_IG73:                ;; offset=0x07F1
       mov      rdx, rbx
       cmp      byte  ptr [rsi+0x30], 0
       setne    r8b
       movzx    r8, r8b
       lea      r8d, [rdi+r8+0x01]
       mov      r9d, dword ptr [rsi+0x28]
       mov      eax, r8d
       mov      r10d, r9d
       add      rax, r10
       mov      r10d, dword ptr [rdx+0x08]
       cmp      rax, r10
       jbe      SHORT G_M000_IG75
 
G_M000_IG74:                ;; offset=0x081B
       mov      r12, bword ptr [rbp+0x10]
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG75:                ;; offset=0x0826
       mov      r8d, r8d
       shl      r8, 4
       add      r8, bword ptr [rdx]
       mov      bword ptr [rbp-0xD0], r8
       mov      dword ptr [rbp-0xC8], r9d
       lea      rcx, [rbp-0xD0]
       mov      rdx, gword ptr [rsi+0x18]
       mov      r12, bword ptr [rbp+0x10]
       mov      r8, gword ptr [r12+0x10]
       lea      r9, [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeNativeRange(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG70
       mov      rax, gword ptr [rbp-0x50]
       mov      gword ptr [rbp-0x48], rax
       jmp      G_M000_IG67
 
G_M000_IG76:                ;; offset=0x0871
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r15, rax
       jmp      G_M000_IG16
 
G_M000_IG77:                ;; offset=0x0882
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r15, rax
       jmp      G_M000_IG16
 
G_M000_IG78:                ;; offset=0x0893
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r15, rax
       jmp      G_M000_IG16
 
G_M000_IG79:                ;; offset=0x08A4
       cmp      edx, 73
       je       G_M000_IG23
       lea      rcx, [rbp-0x80]
       mov      rdx, 0x2C171C8D5C8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG80:                ;; offset=0x08CA
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG81:                ;; offset=0x08D1
       mov      rcx, rax
       mov      r11, 0x7FF9D70927F0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rsi, rax
       jmp      G_M000_IG24
 
G_M000_IG82:                ;; offset=0x08E9
       lea      rcx, [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r15d, eax
       jmp      G_M000_IG51
 
G_M000_IG83:                ;; offset=0x08FB
       mov      edx, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       jmp      G_M000_IG52
 
G_M000_IG84:                ;; offset=0x0908
       mov      eax, r15d
       not      eax
       mov      rcx, bword ptr [rbp+0x10]
       cmp      eax, dword ptr [rcx+0x3C]
       jge      SHORT G_M000_IG86
 
G_M000_IG85:                ;; offset=0x0916
       lea      rcx, [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
 
G_M000_IG86:                ;; offset=0x092C
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x10]
       mov      rcx, gword ptr [rax+0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG90
 
G_M000_IG87:                ;; offset=0x0947
       lea      rcx, [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      ebx, eax
       lea      rcx, [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
 
G_M000_IG88:                ;; offset=0x0960
       vmovdqu  xmm0, xmmword ptr [rbp-0xC0]
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
 
G_M000_IG89:                ;; offset=0x0970
       mov      edx, ebx
       lea      r9, [rbp-0xE0]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Put(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      rcx, bword ptr [rbp+0x10]
       jmp      G_M000_IG53
 
G_M000_IG90:                ;; offset=0x098C
       mov      rsi, rbx
       lea      rcx, [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG103
       mov      rcx, bword ptr [rsi]
       mov      eax, eax
       shl      rax, 4
       xor      edx, edx
       mov      qword ptr [rcx+rax], rdx
       mov      qword ptr [rcx+rax+0x08], rdx
       lea      rcx, [rbp-0x80]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x3C], eax
       mov      rax, gword ptr [rcx+0x08]
       mov      rax, gword ptr [rax+0x98]
       mov      edx, dword ptr [rcx+0x38]
       inc      edx
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG103
       shl      rdx, 5
       lea      rdx, bword ptr [rax+rdx+0x10]
       cmp      dword ptr [rdx+0x1C], 25
       jne      SHORT G_M000_IG94
       cmp      dword ptr [rdx+0x0C], 0x7FFFFFFF
       jne      SHORT G_M000_IG91
       mov      rcx, rdx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG103
       mov      esi, eax
       shl      rsi, 4
       add      rsi, bword ptr [rbx]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, rsi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, qword ptr [rbp-0xB8]
       mov      qword ptr [rsi+0x08], rcx
       jmp      G_M000_IG100
 
G_M000_IG91:                ;; offset=0x0A32
       mov      rcx, rdx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      edx, eax
 
G_M000_IG92:                ;; offset=0x0A3D
       vmovdqu  xmm0, xmmword ptr [rbp-0xC0]
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
 
G_M000_IG93:                ;; offset=0x0A4D
       lea      r8, [rbp-0xE0]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:StoreCapturedLocal(int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG100
 
G_M000_IG94:                ;; offset=0x0A63
       cmp      dword ptr [rdx+0x1C], 71
       jne      SHORT G_M000_IG98
 
G_M000_IG95:                ;; offset=0x0A69
       vmovdqu  xmm0, xmmword ptr [rbx]
       vmovdqu  xmmword ptr [rbp-0xD0], xmm0
 
G_M000_IG96:                ;; offset=0x0A75
       vmovdqu  xmm0, xmmword ptr [rbp-0xC0]
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
 
G_M000_IG97:                ;; offset=0x0A85
       lea      rcx, [rbp-0xD0]
       lea      r8, [rbp-0xE0]
       mov      rsi, bword ptr [rbp+0x10]
       mov      r9, gword ptr [rsi+0x10]
       mov      r9, gword ptr [r9+0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      SHORT G_M000_IG100
 
G_M000_IG98:                ;; offset=0x0AAA
       cmp      dword ptr [rdx+0x1C], 30
       je       SHORT G_M000_IG99
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x2C171C92BE0
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG99:                ;; offset=0x0ADE
       cmp      gword ptr [rbp-0xC0], 0
       jne      SHORT G_M000_IG100
       lea      rcx, [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77F2610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
 
G_M000_IG100:                ;; offset=0x0B08
       mov      rsi, bword ptr [rbp+0x10]
       inc      dword ptr [rsi+0x38]
       mov      rcx, bword ptr [rbp+0x10]
       jmp      G_M000_IG53
 
G_M000_IG101:                ;; offset=0x0B18
       mov      rdx, gword ptr [rbp-0x48]
       mov      rcx, 0x7FF9D74F0AF8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r14, rax
       test     r14, r14
       je       SHORT G_M000_IG105
       mov      r12, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r12+0x08]
       mov      rcx, gword ptr [rcx+0xA0]
       mov      r11, 0x7FF9D70927E0
       call     [r11]System.Collections.Generic.IReadOnlyCollection`1[System.__Canon]:get_Count():int:this
       test     eax, eax
       jne      SHORT G_M000_IG102
       mov      rcx, r14
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG102:                ;; offset=0x0B5D
       mov      gword ptr [r12+0x28], r14
       jmp      G_M000_IG70
 
G_M000_IG103:                ;; offset=0x0B67
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG104:                ;; offset=0x0B6D
       vzeroupper 
       add      rsp, 248
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG105:                ;; offset=0x0B84
       cmp      dword ptr [rsi+0x2C], 0
       je       G_M000_IG109
 
G_M000_IG106:                ;; offset=0x0B8E
       mov      r12, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r12+0x08]
       mov      rcx, gword ptr [rcx+0x98]
       mov      eax, dword ptr [r12+0x38]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG124
       shl      rax, 5
       cmp      dword ptr [rcx+rax+0x2C], 15
       jne      G_M000_IG109
 
G_M000_IG107:                ;; offset=0x0BBB
       mov      rcx, gword ptr [r12+0x10]
       mov      rax, gword ptr [r12+0x08]
       mov      rax, gword ptr [rax+0x98]
       mov      edx, dword ptr [r12+0x38]
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG124
       shl      rdx, 5
       mov      r14, gword ptr [rax+rdx+0x10]
       mov      r15, gword ptr [rcx+0x98]
       cmp      byte  ptr [r15], r15b
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       je       G_M000_IG122
 
G_M000_IG108:                ;; offset=0x0BFE
       mov      edx, edi
       add      edx, dword ptr [rsi+0x2C]
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Trim(int):this]
       mov      rcx, rbx
       mov      eax, dword ptr [rsi+0x2C]
       mov      edx, edi
       mov      r8d, eax
       add      rdx, r8
       mov      r8d, dword ptr [rcx+0x08]
       cmp      rdx, r8
       ja       G_M000_IG123
       mov      edx, edi
       shl      rdx, 4
       add      rdx, bword ptr [rcx]
       mov      bword ptr [rbp-0xD0], rdx
       mov      dword ptr [rbp-0xC8], eax
       lea      rcx, [rbp-0xD0]
       call     [System.MemoryExtensions:Reverse[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       jmp      SHORT G_M000_IG112
 
G_M000_IG109:                ;; offset=0x0C4C
       mov      r12, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [r12+0x08]
       mov      rdx, gword ptr [rdx+0x98]
       mov      r8d, dword ptr [r12+0x38]
       cmp      r8d, dword ptr [rdx+0x08]
       jae      G_M000_IG124
       shl      r8, 5
       lea      rdx, bword ptr [rdx+r8+0x10]
 
G_M000_IG110:                ;; offset=0x0C74
       vmovdqu  xmm0, xmmword ptr [rbp-0x48]
       vmovdqu  xmmword ptr [rbp-0xE0], xmm0
 
G_M000_IG111:                ;; offset=0x0C81
       lea      r8, [rbp-0xE0]
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+NativeExecution:Publish(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
 
G_M000_IG112:                ;; offset=0x0C91
       mov      eax, 1
 
G_M000_IG113:                ;; offset=0x0C96
       vzeroupper 
       add      rsp, 248
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG114:                ;; offset=0x0CAD
       cmp      edx, 73
       je       G_M000_IG03
       mov      rcx, rbx
       mov      rdx, 0x2C171C8D5C8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG115:                ;; offset=0x0CD2
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG116:                ;; offset=0x0CD9
       mov      rcx, rax
       mov      r11, 0x7FF9D70927D8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rsi, rax
       jmp      G_M000_IG04
 
G_M000_IG117:                ;; offset=0x0CF1
       mov      rcx, rbx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edi, eax
       jmp      G_M000_IG07
 
G_M000_IG118:                ;; offset=0x0D01
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG09
 
G_M000_IG119:                ;; offset=0x0D12
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG09
 
G_M000_IG120:                ;; offset=0x0D23
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG09
 
G_M000_IG121:                ;; offset=0x0D34
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
       mov      rcx, r12
       mov      rdx, 0x2C171C8AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, r12
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG122:                ;; offset=0x0D62
       mov      rcx, r15
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG108
 
G_M000_IG123:                ;; offset=0x0D73
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG124:                ;; offset=0x0D7A
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG125:                ;; offset=0x0D80
       sub      rsp, 72
 
G_M000_IG126:                ;; offset=0x0D84
       mov      r12, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [r12+0x10]
       mov      rdi, gword ptr [rsi+0x98]
       mov      rcx, qword ptr [rdi+0x160]
       test     rcx, rcx
       jle      SHORT G_M000_IG128
 
G_M000_IG127:                ;; offset=0x0DA0
       dec      rcx
       mov      qword ptr [rdi+0x160], rcx
 
G_M000_IG128:                ;; offset=0x0DAA
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG129:                ;; offset=0x0DB2
       sub      rsp, 72
 
G_M000_IG130:                ;; offset=0x0DB6
       mov      rdx, rcx
       mov      rcx, 0x7FF9D7192168
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rsi, rax
       test     rsi, rsi
       jne      SHORT G_M000_IG132
 
G_M000_IG131:                ;; offset=0x0DD0
       xor      eax, eax
       jmp      SHORT G_M000_IG133
 
G_M000_IG132:                ;; offset=0x0DD4
       mov      rcx, gword ptr [rbp-0xE8]
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       lea      r8, [rbp-0x90]
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:TryTranslateCallableException(System.Exception,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       setne    al
       movzx    rax, al
 
G_M000_IG133:                ;; offset=0x0DFC
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG134:                ;; offset=0x0E04
       sub      rsp, 72
 
G_M000_IG135:                ;; offset=0x0E08
       mov      rcx, gword ptr [rbp-0x90]
       call     CORINFO_HELP_THROW
       int3     
 
; Total bytes of code 3605

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInstructionPrefix(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref,byref,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 0xC00
       lea      rbp, [rsp+0xC00]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0xBC0], xmm4
       mov      rax, -0xB70
 
G_M000_IG254:                ;; offset=0x0026
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG254
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      dword ptr [rbp+0x28], r9d
 
G_M000_IG02:                ;; offset=0x0052
       mov      dword ptr [rbp-0x674], 0x3E8
       mov      rax, bword ptr [rbp+0x30]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      rax, bword ptr [rbp+0x38]
       xor      rcx, rcx
       mov      gword ptr [rax], rcx
       mov      rax, bword ptr [rbp+0x40]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      qword ptr [rax+0x10], rcx
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      gword ptr [rbp-0x40], rax
       jmp      G_M000_IG235
 
G_M000_IG03:                ;; offset=0x009B
       xor      eax, eax
       mov      dword ptr [rbp-0x44], eax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x10]
       mov      rcx, gword ptr [rbp-0x40]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG241
       mov      edx, eax
       imul     rdx, rdx, 32
       lea      rcx, bword ptr [rcx+rdx+0x10]
       mov      bword ptr [rbp-0x58], rcx
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x680], rax
       mov      rdx, gword ptr [rbp-0x680]
       mov      rcx, gword ptr [rbp-0x1C8]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG04:                ;; offset=0x00FE
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0xE4], eax
       cmp      dword ptr [rbp-0xE4], 73
       ja       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x0117
       mov      eax, dword ptr [rbp-0xE4]
       lea      rcx, [reloc @RWD00]
       mov      ecx, dword ptr [rcx+4*rax]
       lea      rdx, G_M000_IG02
       add      rcx, rdx
       jmp      rcx
 
G_M000_IG06:                ;; offset=0x0133
       jmp      G_M000_IG221
 
G_M000_IG07:                ;; offset=0x0138
       mov      rcx, 0x7FF9D77EA980
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG239
 
G_M000_IG08:                ;; offset=0x0156
       mov      rcx, 0x7FF9D77EA984
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x5F0], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x5F8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x5FC], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x688], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x688]
       mov      rdx, gword ptr [rbp-0x5F8]
       mov      r8d, dword ptr [rbp-0x5FC]
       mov      rcx, gword ptr [rbp-0x5F0]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadLocal(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x690], rax
       mov      r9, gword ptr [rbp-0x690]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG225
 
G_M000_IG09:                ;; offset=0x01F3
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x218], rax
       mov      rax, gword ptr [rbp-0x218]
       mov      gword ptr [rbp-0xBC0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      rdx, gword ptr [rbp-0xBC0]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG224
       mov      ecx, eax
       imul     rcx, rcx, 16
       lea      rcx, bword ptr [rdx+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_IsUnassigned():bool:this]
       test     eax, eax
       je       G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0243
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_LocalNames():System.Collections.Generic.IReadOnlyList`1[System.String]:this]
       mov      gword ptr [rbp-0x220], rax
       mov      rax, gword ptr [rbp-0x220]
       mov      gword ptr [rbp-0x648], rax
       mov      rcx, gword ptr [rbp-0x648]
       mov      rdx, 0x7FF9D77EA988
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x648]
       mov      gword ptr [rbp-0x698], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      dword ptr [rbp-0x69C], eax
       mov      rcx, gword ptr [rbp-0x698]
       mov      edx, dword ptr [rbp-0x69C]
       mov      r11, 0x7FF9D7092940
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x228], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x6A8], rax
       mov      rdx, gword ptr [rbp-0x6A8]
       mov      rcx, gword ptr [rbp-0x228]
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG11:                ;; offset=0x02EA
       mov      rcx, 0x7FF9D77EAA90
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG225
 
G_M000_IG12:                ;; offset=0x02FE
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       jne      G_M000_IG14
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x5D0], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x18]
       mov      gword ptr [rbp-0x5D8], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x10]
       mov      dword ptr [rbp-0x5DC], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x6AC], eax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9d, dword ptr [rbp-0x6AC]
       mov      rdx, gword ptr [rbp-0x5D8]
       mov      r8d, dword ptr [rbp-0x5DC]
       mov      rcx, gword ptr [rbp-0x5D0]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       je       SHORT G_M000_IG13
       mov      rcx, 0x7FF9D77EAA94
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 16
       mov      bword ptr [rbp-0x5E8], rax
       mov      rax, bword ptr [rbp-0x5E8]
       add      dword ptr [rax], 2
       jmp      G_M000_IG225
 
G_M000_IG13:                ;; offset=0x03C0
       mov      rcx, 0x7FF9D77EAA98
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG14:                ;; offset=0x03CF
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      dword ptr [rbp-0x5C8], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x6B8], rax
       lea      rax, [rbp-0x60]
       mov      qword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x6B8]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8d, dword ptr [rbp-0x5C8]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryLoadClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG15
       mov      rcx, 0x7FF9D77EAA9C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG15:                ;; offset=0x0437
       mov      rcx, 0x7FF9D77EAAA0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      r9, gword ptr [rbp-0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG225
 
G_M000_IG16:                ;; offset=0x0461
       mov      rcx, 0x7FF9D77EAAA4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:StoreExecutableLocal(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG225
 
G_M000_IG17:                ;; offset=0x048B
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryStoreClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG18
       mov      rcx, 0x7FF9D77EAAA8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG18:                ;; offset=0x04BF
       mov      rcx, 0x7FF9D77EAAAC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG225
 
G_M000_IG19:                ;; offset=0x04D3
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG20
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG20:                ;; offset=0x04E9
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG23
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG21:                ;; offset=0x04F5
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x6D8], ymm0
 
G_M000_IG22:                ;; offset=0x0501
       lea      r8, [rbp-0x6D8]
       lea      rdx, [rbp-0xF8]
       mov      rcx, gword ptr [rbp+0x20]
       xor      r9d, r9d
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rdx, [rbp-0x108]
       lea      rcx, [rbp-0xF8]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter:GetResult():this]
       jmp      G_M000_IG225
 
G_M000_IG23:                ;; offset=0x0544
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG24:                ;; offset=0x0548
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x6F8], ymm0
 
G_M000_IG25:                ;; offset=0x0554
       lea      r8, [rbp-0x6F8]
       lea      rdx, [rbp-0x588]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r9d, 1
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG26:                ;; offset=0x0574
       vmovdqu  xmm0, xmmword ptr [rbp-0x588]
       vmovdqu  xmmword ptr [rbp-0x708], xmm0
 
G_M000_IG27:                ;; offset=0x0584
       lea      rdx, [rbp-0x708]
       lea      rcx, [rbp-0x598]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB38], rax
       mov      rcx, bword ptr [rbp-0xB38]
       mov      rdx, gword ptr [rbp-0x598]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB38]
       mov      rcx, qword ptr [rbp-0x590]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG28
       mov      rcx, 0x7FF9D77EAAB0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x710], rax
       mov      rcx, gword ptr [rbp-0x710]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG239
 
G_M000_IG28:                ;; offset=0x0612
       mov      rcx, 0x7FF9D77EAAB4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG225
 
G_M000_IG29:                ;; offset=0x0630
       mov      rax, bword ptr [rbp+0x10]
       mov      bword ptr [rbp-0x2F0], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x2F8], rax
       mov      rax, bword ptr [rbp-0x58]
       mov      bword ptr [rbp-0x300], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x308], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG30
       mov      rcx, 0x7FF9D77EAAB8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x308], rax
 
G_M000_IG30:                ;; offset=0x067D
       mov      rcx, bword ptr [rbp-0x2F0]
       mov      rdx, gword ptr [rbp-0x2F8]
       mov      r8, bword ptr [rbp-0x300]
       mov      r9, gword ptr [rbp-0x308]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteFormattedInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      SHORT G_M000_IG31
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG32
       mov      rcx, 0x7FF9D77EAABC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG31:                ;; offset=0x06C8
       mov      rcx, 0x7FF9D77EAAC0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG225
 
G_M000_IG32:                ;; offset=0x06DC
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG35
       mov      rcx, 0x7FF9D77EAAC4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG33:                ;; offset=0x06F7
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x730], ymm0
 
G_M000_IG34:                ;; offset=0x0703
       lea      r8, [rbp-0x730]
       lea      rdx, [rbp-0xF8]
       mov      rcx, gword ptr [rbp+0x20]
       xor      r9d, r9d
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rdx, [rbp-0x108]
       lea      rcx, [rbp-0xF8]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter:GetResult():this]
       jmp      G_M000_IG225
 
G_M000_IG35:                ;; offset=0x0746
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG36:                ;; offset=0x074A
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x750], ymm0
 
G_M000_IG37:                ;; offset=0x0756
       lea      r8, [rbp-0x750]
       lea      rdx, [rbp-0x318]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r9d, 1
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG38:                ;; offset=0x0776
       vmovdqu  xmm0, xmmword ptr [rbp-0x318]
       vmovdqu  xmmword ptr [rbp-0x760], xmm0
 
G_M000_IG39:                ;; offset=0x0786
       lea      rdx, [rbp-0x760]
       lea      rcx, [rbp-0x328]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB40], rax
       mov      rcx, bword ptr [rbp-0xB40]
       mov      rdx, gword ptr [rbp-0x328]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB40]
       mov      rcx, qword ptr [rbp-0x320]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG40
       mov      rcx, 0x7FF9D77EAAC8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x768], rax
       mov      rcx, gword ptr [rbp-0x768]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG239
 
G_M000_IG40:                ;; offset=0x0814
       mov      rcx, 0x7FF9D77EAACC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG225
 
G_M000_IG41:                ;; offset=0x0832
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x270], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rcx, gword ptr [rbp-0x270]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG224
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x770], rax
       mov      rdx, gword ptr [rbp-0x770]
       mov      rcx, 0x7FF9D758EAB0
       call     CORINFO_HELP_CHKCASTCLASS
       mov      gword ptr [rbp-0x278], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x280], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x284], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x288], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      ecx, dword ptr [rbp-0x288]
       sub      ecx, eax
       mov      dword ptr [rbp-0x774], ecx
       mov      r9d, dword ptr [rbp-0x774]
       lea      rcx, [rbp-0x298]
       mov      rdx, gword ptr [rbp-0x280]
       mov      r8d, dword ptr [rbp-0x284]
       call     [System.MemoryExtensions:AsSpan[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot](Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int,int):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rax, gword ptr [rbp-0x278]
       mov      gword ptr [rbp-0x2A0], rax
 
G_M000_IG42:                ;; offset=0x0913
       vmovdqu  xmm0, xmmword ptr [rbp-0x298]
       vmovdqu  xmmword ptr [rbp-0x2B0], xmm0
 
G_M000_IG43:                ;; offset=0x0923
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_StartsKeywordDefaultsOnly():bool:this]
       mov      dword ptr [rbp-0x2B4], eax
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x2C0], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG44
       mov      rcx, 0x7FF9D77EAAD0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x2C0], rax
 
G_M000_IG44:                ;; offset=0x095F
       mov      rcx, 0x7FF9D77EAAD4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG45:                ;; offset=0x096E
       vmovdqu  xmm0, xmmword ptr [rbp-0x2B0]
       vmovdqu  xmmword ptr [rbp-0x788], xmm0
 
G_M000_IG46:                ;; offset=0x097E
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x790], rax
       mov      rax, gword ptr [rbp-0x790]
       mov      gword ptr [rsp+0x20], rax
       lea      rdx, [rbp-0x788]
       mov      r8d, dword ptr [rbp-0x2B4]
       mov      r9, gword ptr [rbp-0x2C0]
       mov      rcx, gword ptr [rbp-0x2A0]
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x2C8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x794], eax
       mov      edx, dword ptr [rbp-0x794]
       mov      rcx, bword ptr [rbp-0x2C8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RestoreNativeExtent(int):this]
       jmp      G_M000_IG225
 
G_M000_IG47:                ;; offset=0x09FA
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x230], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x234], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x798], eax
       mov      r9d, dword ptr [rbp-0x798]
       lea      rdx, [rbp-0x70]
       mov      r8d, dword ptr [rbp-0x234]
       mov      rcx, bword ptr [rbp-0x230]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x7A0], rax
       mov      rdx, gword ptr [rbp-0x7A0]
       lea      rcx, [rbp-0x248]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:op_Implicit(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]):System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]]
       mov      rax, bword ptr [rbp-0x58]
       mov      bword ptr [rbp-0x250], rax
 
G_M000_IG48:                ;; offset=0x0A88
       vmovdqu  xmm0, xmmword ptr [rbp-0x70]
       vmovdqu  xmmword ptr [rbp-0x260], xmm0
 
G_M000_IG49:                ;; offset=0x0A95
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x268], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG50
       mov      rcx, 0x7FF9D77EAAD8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rbp-0x268], rax
 
G_M000_IG50:                ;; offset=0x0AC1
       mov      rcx, 0x7FF9D77EAADC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG51:                ;; offset=0x0AD0
       vmovdqu  xmm0, xmmword ptr [rbp-0x248]
       vmovdqu  xmmword ptr [rbp-0x7B0], xmm0
 
G_M000_IG52:                ;; offset=0x0AE0
       vmovdqu  xmm0, xmmword ptr [rbp-0x260]
       vmovdqu  xmmword ptr [rbp-0x7C0], xmm0
 
G_M000_IG53:                ;; offset=0x0AF0
       mov      rcx, gword ptr [rbp-0x268]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x7C8], rax
       mov      r9, gword ptr [rbp-0x7C8]
       lea      r8, [rbp-0x7C0]
       lea      rcx, [rbp-0x7B0]
       mov      rdx, bword ptr [rbp-0x250]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG225
 
G_M000_IG54:                ;; offset=0x0B2D
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       lea      rax, [rbp-0x80]
       mov      qword ptr [rsp+0x28], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecutePreparedOperation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG55
       mov      rcx, 0x7FF9D77EAAE0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG55:                ;; offset=0x0B76
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG56
       mov      rcx, 0x7FF9D77EAAE4
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdx, [rbp-0x108]
       lea      rcx, [rbp-0x80]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter:GetResult():this]
       jmp      G_M000_IG225
 
G_M000_IG56:                ;; offset=0x0BB0
       vmovdqu  xmm0, xmmword ptr [rbp-0x80]
       vmovdqu  xmmword ptr [rbp-0x7D8], xmm0
 
G_M000_IG57:                ;; offset=0x0BBD
       lea      rdx, [rbp-0x7D8]
       lea      rcx, [rbp-0x5A8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB48], rax
       mov      rcx, bword ptr [rbp-0xB48]
       mov      rdx, gword ptr [rbp-0x5A8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB48]
       mov      rcx, qword ptr [rbp-0x5A0]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG58
       mov      rcx, 0x7FF9D77EAAE8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x7E0], rax
       mov      rcx, gword ptr [rbp-0x7E0]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG239
 
G_M000_IG58:                ;; offset=0x0C4B
       mov      rcx, 0x7FF9D77EAAEC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG225
 
G_M000_IG59:                ;; offset=0x0C69
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG60
       mov      rcx, 0x7FF9D77EAAF0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG60:                ;; offset=0x0C8E
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x378], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x37C], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x7E4], eax
       mov      r9d, dword ptr [rbp-0x7E4]
       lea      rdx, [rbp-0x118]
       mov      r8d, dword ptr [rbp-0x37C]
       mov      rcx, bword ptr [rbp-0x378]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x10]
       inc      eax
       mov      dword ptr [rbp-0x11C], eax
       mov      rax, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rax+0x70]
       mov      gword ptr [rbp-0x128], rax
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorsExecutableLocals():bool:this]
       test     eax, eax
       jne      G_M000_IG63
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorLocalStores():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG62
       mov      rax, gword ptr [rbp-0x40]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbp-0x11C]
       jle      SHORT G_M000_IG61
       mov      rcx, 0x7FF9D77EAAF4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x40]
       mov      ecx, dword ptr [rbp-0x11C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG224
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 30
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x380], eax
       jmp      SHORT G_M000_IG64
 
G_M000_IG61:                ;; offset=0x0D7D
       mov      rcx, 0x7FF9D77EAAF8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG63
 
G_M000_IG62:                ;; offset=0x0D8E
       mov      rcx, 0x7FF9D77EAAFC
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG63:                ;; offset=0x0D9D
       xor      eax, eax
       mov      dword ptr [rbp-0x380], eax
 
G_M000_IG64:                ;; offset=0x0DA5
       movzx    rax, byte  ptr [rbp-0x380]
       mov      dword ptr [rbp-0x12C], eax
       cmp      dword ptr [rbp-0x12C], 0
       je       G_M000_IG71
       cmp      gword ptr [rbp-0x128], 0
       je       G_M000_IG68
 
G_M000_IG65:                ;; offset=0x0DCD
       vmovdqu  xmm0, xmmword ptr [rbp-0x118]
       vmovdqu  xmmword ptr [rbp-0x7F8], xmm0
 
G_M000_IG66:                ;; offset=0x0DDD
       lea      r8, [rbp-0x7F8]
       mov      rdx, gword ptr [rbp-0x128]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryAppendBufferedYield(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):bool:this]
       test     eax, eax
       je       G_M000_IG67
       mov      rax, gword ptr [rbp-0x40]
       mov      ecx, dword ptr [rbp-0x11C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG224
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x800], rax
       mov      rdx, gword ptr [rbp-0x800]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      gword ptr [rbp-0x390], rax
       mov      rax, gword ptr [rbp-0x390]
       mov      gword ptr [rbp-0x398], rax
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_HasActiveHandler():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG69
       mov      rax, gword ptr [rbp-0x398]
       mov      gword ptr [rbp-0x3A0], rax
       mov      rax, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rax+0x80]
       mov      gword ptr [rbp-0x3A8], rax
       jmp      SHORT G_M000_IG70
 
G_M000_IG67:                ;; offset=0x0E93
       mov      rcx, 0x7FF9D77EAB00
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG71
 
G_M000_IG68:                ;; offset=0x0EA7
       mov      rcx, 0x7FF9D77EAB04
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG71
 
G_M000_IG69:                ;; offset=0x0EBB
       mov      rcx, 0x7FF9D77EAB08
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x398]
       mov      gword ptr [rbp-0x3A0], rax
       mov      rcx, gword ptr [rbp+0x18]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_State():Lokad.Lython.Runtime.ExecutionState:this]
       mov      rcx, rax
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:get_CurrentException():Lokad.Lython.Runtime.PyException:this]
       mov      gword ptr [rbp-0x3A8], rax
 
G_M000_IG70:                ;; offset=0x0EF6
       mov      rcx, 0x7FF9D77EAB0C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp-0x3A0]
       mov      rdx, gword ptr [rbp-0x3A8]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.ExecutionState:SetCurrentException(Lokad.Lython.Runtime.PyException):Lokad.Lython.Runtime.PyException:this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x3B0], rax
       mov      rax, gword ptr [rbp-0x40]
       mov      ecx, dword ptr [rbp-0x11C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG224
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x804], eax
       mov      edx, dword ptr [rbp-0x804]
       mov      rcx, bword ptr [rbp-0x3B0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 16
       mov      bword ptr [rbp-0x3B8], rax
       mov      rax, bword ptr [rbp-0x3B8]
       add      dword ptr [rax], 2
       jmp      G_M000_IG235
 
G_M000_IG71:                ;; offset=0x0F94
       vmovdqu  xmm0, xmmword ptr [rbp-0x118]
       vmovdqu  xmmword ptr [rbp-0x818], xmm0
 
G_M000_IG72:                ;; offset=0x0FA4
       lea      rdx, [rbp-0x818]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:set_YieldValue(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       mov      rcx, gword ptr [rbp+0x20]
       mov      edx, 1
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:set_HasYield(bool):this]
       mov      rax, gword ptr [rbp+0x20]
       mov      byte  ptr [rax+0xF8], 1
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 16
       mov      bword ptr [rbp-0x388], rax
       mov      rax, bword ptr [rbp-0x388]
       inc      dword ptr [rax]
       cmp      dword ptr [rbp-0x12C], 0
       jne      SHORT G_M000_IG75
       cmp      gword ptr [rbp-0x128], 0
       je       SHORT G_M000_IG74
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [rbp-0x128]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG73
       mov      rcx, 0x7FF9D77EAB10
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG235
 
G_M000_IG73:                ;; offset=0x102F
       mov      rcx, 0x7FF9D77EAB14
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG75
 
G_M000_IG74:                ;; offset=0x1040
       mov      rcx, 0x7FF9D77EAB18
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG75:                ;; offset=0x104F
       mov      rcx, 0x7FF9D77EAB1C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG239
 
G_M000_IG76:                ;; offset=0x106D
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG77
       mov      rcx, 0x7FF9D77EAB20
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG77:                ;; offset=0x1092
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       G_M000_IG81
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG78:                ;; offset=0x10A2
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x838], ymm0
 
G_M000_IG79:                ;; offset=0x10AE
       lea      r8, [rbp-0x838]
       lea      rdx, [rbp-0x370]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteDelegationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB50], rax
       mov      rcx, bword ptr [rbp-0xB50]
       mov      rdx, gword ptr [rbp-0x370]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB50]
       mov      rcx, qword ptr [rbp-0x368]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG80
       mov      rcx, 0x7FF9D77EAB24
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x840], rax
       mov      rcx, gword ptr [rbp-0x840]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG239
 
G_M000_IG80:                ;; offset=0x1142
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG87
 
G_M000_IG81:                ;; offset=0x1151
       mov      rax, gword ptr [rbp+0x20]
       cmp      gword ptr [rax+0x68], 0
       jne      G_M000_IG82
       mov      rcx, 0x7FF9D77EAB28
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x340], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x344], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x844], eax
       mov      r8d, dword ptr [rbp-0x844]
       mov      edx, dword ptr [rbp-0x344]
       mov      rcx, bword ptr [rbp-0x340]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      gword ptr [rbp-0x138], rax
       mov      rcx, 0x7FF9D71528A8
       mov      edx, 1
       call     CORINFO_HELP_NEWARR_1_PTR
       mov      gword ptr [rbp-0x350], rax
       mov      rcx, gword ptr [rbp-0x350]
       mov      r8, gword ptr [rbp-0x138]
       xor      edx, edx
       call     CORINFO_HELP_ARRADDR_ST
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x850], rax
       mov      rdx, gword ptr [rbp-0x850]
       mov      rcx, gword ptr [rbp-0x350]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:Iter(System.Object[],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x358], rax
       mov      rcx, 0x7FF9D77E7DB8
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x360], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x858], rax
       mov      r9, gword ptr [rbp-0x858]
       mov      rdx, gword ptr [rbp-0x358]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x360]
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:.ctor(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp+0x20]
       lea      rcx, bword ptr [rax+0x68]
       mov      rdx, gword ptr [rbp-0x360]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG82:                ;; offset=0x127F
       mov      rcx, 0x7FF9D77EAB2C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp+0x20]
       mov      r9, gword ptr [rax+0x60]
       mov      rax, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rax+0x68]
       lea      rdx, [rbp-0x338]
       mov      rax, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rax+0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:Advance(System.Object,Lokad.Lython.Runtime.LythonRuntimeException):Lokad.Lython.Runtime.PyIterationResult:this]
 
G_M000_IG83:                ;; offset=0x12B5
       vmovdqu  xmm0, xmmword ptr [rbp-0x338]
       vmovdqu  xmmword ptr [rbp-0x868], xmm0
 
G_M000_IG84:                ;; offset=0x12C5
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG85:                ;; offset=0x12C9
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x888], ymm0
 
G_M000_IG86:                ;; offset=0x12D5
       lea      rdx, [rbp-0x868]
       lea      r8, [rbp-0x888]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteDelegatedStep(Lokad.Lython.Runtime.PyIterationResult,Lokad.Lython.Frontend.ExecutableInstruction):this]
 
G_M000_IG87:                ;; offset=0x12EF
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_HasYield():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG89
       mov      rax, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rax+0x70]
       mov      gword ptr [rbp-0x140], rax
       cmp      gword ptr [rbp-0x140], 0
       je       SHORT G_M000_IG90
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [rbp-0x140]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG88
       mov      rcx, 0x7FF9D77EAB30
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG235
 
G_M000_IG88:                ;; offset=0x1343
       mov      rcx, 0x7FF9D77EAB34
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG90
 
G_M000_IG89:                ;; offset=0x1354
       mov      rcx, 0x7FF9D77EAB38
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG225
 
G_M000_IG90:                ;; offset=0x1368
       mov      rcx, 0x7FF9D77EAB3C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG239
 
G_M000_IG91:                ;; offset=0x1386
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG92
       mov      rcx, 0x7FF9D77EAB40
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG92:                ;; offset=0x13AB
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Imports():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ImportStatementSyntax]:this]
       mov      gword ptr [rbp-0x610], rax
       mov      rax, gword ptr [rbp-0x610]
       mov      gword ptr [rbp-0x650], rax
       mov      rcx, gword ptr [rbp-0x650]
       mov      rdx, 0x7FF9D77EAB48
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x650]
       mov      gword ptr [rbp-0x890], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ImportIndex():int:this]
       mov      dword ptr [rbp-0x894], eax
       mov      rcx, gword ptr [rbp-0x890]
       mov      edx, dword ptr [rbp-0x894]
       mov      r11, 0x7FF9D7092950
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x88], rax
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG93
       mov      rcx, 0x7FF9D77EAC50
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rax+0x08]
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       mov      rdx, gword ptr [rbp-0x88]
       mov      r9, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteExecutableImport(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext)]
       jmp      G_M000_IG225
 
G_M000_IG93:                ;; offset=0x1460
       lea      rcx, [rbp-0x620]
       mov      rdx, gword ptr [rbp-0x88]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteImportAsync(Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Threading.Tasks.ValueTask]
 
G_M000_IG94:                ;; offset=0x1478
       vmovdqu  xmm0, xmmword ptr [rbp-0x620]
       vmovdqu  xmmword ptr [rbp-0x8A8], xmm0
 
G_M000_IG95:                ;; offset=0x1488
       lea      rdx, [rbp-0x8A8]
       lea      rcx, [rbp-0x630]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB58], rax
       mov      rcx, bword ptr [rbp-0xB58]
       mov      rdx, gword ptr [rbp-0x630]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB58]
       mov      rcx, qword ptr [rbp-0x628]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG96
       mov      rcx, 0x7FF9D77EAC54
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8B0], rax
       mov      rcx, gword ptr [rbp-0x8B0]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG239
 
G_M000_IG96:                ;; offset=0x1516
       mov      rcx, 0x7FF9D77EAC58
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG225
 
G_M000_IG97:                ;; offset=0x1534
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryLoadDirectCallReceiver(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG98
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG99
       mov      rcx, 0x7FF9D77EAC5C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG98:                ;; offset=0x1573
       mov      rcx, 0x7FF9D77EAC60
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG225
 
G_M000_IG99:                ;; offset=0x1587
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG100
       mov      rcx, 0x7FF9D77EAC64
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSynchronousMemberLoad(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG225
 
G_M000_IG100:                ;; offset=0x15B9
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG101:                ;; offset=0x15BD
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x8D0], ymm0
 
G_M000_IG102:                ;; offset=0x15C9
       lea      r8, [rbp-0x8D0]
       lea      rdx, [rbp-0x578]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteMemberLoadAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB60], rax
       mov      rcx, bword ptr [rbp-0xB60]
       mov      rdx, gword ptr [rbp-0x578]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB60]
       mov      rcx, qword ptr [rbp-0x570]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG103
       mov      rcx, 0x7FF9D77EAC68
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8D8], rax
       mov      rcx, gword ptr [rbp-0x8D8]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG239
 
G_M000_IG103:                ;; offset=0x165D
       mov      rcx, 0x7FF9D77EAC6C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG225
 
G_M000_IG104:                ;; offset=0x167B
       mov      rcx, 0x7FF9D77EAC70
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Object[]:this]
       mov      gword ptr [rbp-0x608], rax
       mov      rax, gword ptr [rbp-0x608]
       mov      gword ptr [rbp-0xBC0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      rdx, gword ptr [rbp-0xBC0]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG224
       mov      ecx, eax
       lea      rcx, bword ptr [rdx+8*rcx+0x10]
       mov      rcx, gword ptr [rcx]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      gword ptr [rbp-0x8E0], rax
       mov      r9, gword ptr [rbp-0x8E0]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG225
 
G_M000_IG105:                ;; offset=0x16FD
       mov      rcx, 0x7FF9D77EAC74
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x5C0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      dword ptr [rbp-0x5C4], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8E8], rax
       mov      r8, gword ptr [rbp-0x8E8]
       mov      edx, dword ptr [rbp-0x5C4]
       mov      rcx, gword ptr [rbp-0x5C0]
       mov      r9, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x8F0], rax
       mov      r9, gword ptr [rbp-0x8F0]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG225
 
G_M000_IG106:                ;; offset=0x177E
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG107
       mov      rcx, 0x7FF9D77EAC78
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG107:                ;; offset=0x17A3
       mov      rcx, 0x7FF9D77EAC7C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.String[]:this]
       mov      gword ptr [rbp-0x5B0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      rcx, gword ptr [rbp-0x5B0]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG224
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x5B8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x8F8], rax
       mov      rdx, gword ptr [rbp-0x8F8]
       mov      rcx, gword ptr [rbp-0x5B8]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableName(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x900], rax
       mov      r9, gword ptr [rbp-0x900]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG225
 
G_M000_IG108:                ;; offset=0x1841
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG109
       mov      rcx, 0x7FF9D77EAC80
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG109:                ;; offset=0x1866
       mov      rcx, 0x7FF9D77EAC84
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x908], rax
       mov      rdx, gword ptr [rbp-0x908]
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:PreloadImplicitSuperArguments(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG225
 
G_M000_IG110:                ;; offset=0x189C
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG111
       mov      rcx, 0x7FF9D77EAC88
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG111:                ;; offset=0x18C1
       mov      rcx, 0x7FF9D77EAC8C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.String[]:this]
       mov      gword ptr [rbp-0x548], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      rcx, gword ptr [rbp-0x548]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG224
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x550], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x558], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x55C], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x90C], eax
       mov      r8d, dword ptr [rbp-0x90C]
       mov      edx, dword ptr [rbp-0x55C]
       mov      rcx, bword ptr [rbp-0x558]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      gword ptr [rbp-0x568], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x918], rax
       mov      r9, gword ptr [rbp-0x918]
       mov      rdx, gword ptr [rbp-0x568]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x550]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreName(System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG225
 
G_M000_IG112:                ;; offset=0x199C
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG113
       mov      rcx, 0x7FF9D77EAC90
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG113:                ;; offset=0x19C1
       mov      rcx, 0x7FF9D77EAC94
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax]
       mov      gword ptr [rbp-0x510], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x518], rax
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Names():System.String[]:this]
       mov      gword ptr [rbp-0x520], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      rcx, gword ptr [rbp-0x520]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG224
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x528], rax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x530], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x534], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x91C], eax
       mov      r8d, dword ptr [rbp-0x91C]
       mov      edx, dword ptr [rbp-0x534]
       mov      rcx, bword ptr [rbp-0x530]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      gword ptr [rbp-0x540], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x928], rax
       mov      rax, gword ptr [rbp-0x928]
       mov      gword ptr [rsp+0x28], rax
       mov      rdx, gword ptr [rbp-0x518]
       mov      r8, gword ptr [rbp-0x528]
       mov      r9, gword ptr [rbp-0x540]
       mov      rax, gword ptr [rbp+0x20]
       mov      gword ptr [rsp+0x20], rax
       mov      rcx, gword ptr [rbp-0x510]
       call     [Lokad.Lython.Runtime.LythonRuntime:AssignExecutableBoundName(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG225
 
G_M000_IG114:                ;; offset=0x1AD1
       mov      rcx, 0x7FF9D77EAC98
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4F8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       inc      eax
       mov      dword ptr [rbp-0x4FC], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x500], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x508], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x92C], eax
       mov      edx, dword ptr [rbp-0x92C]
       mov      rcx, bword ptr [rbp-0x508]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x938], rax
       mov      r9, gword ptr [rbp-0x938]
       mov      edx, dword ptr [rbp-0x4FC]
       mov      r8d, dword ptr [rbp-0x500]
       mov      rcx, bword ptr [rbp-0x4F8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishValue(int,int,System.Object):this]
       jmp      G_M000_IG225
 
G_M000_IG115:                ;; offset=0x1B7C
       mov      rcx, 0x7FF9D77EAC9C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4E8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x93C], eax
       mov      edx, dword ptr [rbp-0x93C]
       mov      rcx, bword ptr [rbp-0x4E8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4F0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x940], eax
       mov      edx, dword ptr [rbp-0x940]
       mov      rcx, bword ptr [rbp-0x4F0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       jmp      G_M000_IG225
 
G_M000_IG116:                ;; offset=0x1C00
       mov      rcx, 0x7FF9D77EACA0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4D8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4DC], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x4E0], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x948], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x948]
       mov      edx, dword ptr [rbp-0x4DC]
       mov      r8d, dword ptr [rbp-0x4E0]
       mov      rcx, bword ptr [rbp-0x4D8]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateListFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      gword ptr [rbp-0x950], rax
       mov      r9, gword ptr [rbp-0x950]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG225
 
G_M000_IG117:                ;; offset=0x1CA4
       cmp      gword ptr [rbp+0x20], 0
       je       SHORT G_M000_IG119
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryStageUnpackedFrameReturn(byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG118
       mov      rcx, 0x7FF9D77EACA4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG239
 
G_M000_IG118:                ;; offset=0x1CDD
       mov      rcx, 0x7FF9D77EACA8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG119:                ;; offset=0x1CEC
       mov      rcx, bword ptr [rbp+0x48]
       call     [System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]:get_IsEmpty():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG123
       mov      rax, bword ptr [rbp+0x48]
       mov      r8d, dword ptr [rax+0x08]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CanForwardFixedReturn(byref,byref,int):bool]
       test     eax, eax
       je       SHORT G_M000_IG122
       mov      rcx, 0x7FF9D77EACAC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x48]
 
G_M000_IG120:                ;; offset=0x1D27
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x960], xmm0
 
G_M000_IG121:                ;; offset=0x1D33
       lea      r9, [rbp-0x960]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CopyFixedReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       mov      dword ptr [rbp-0xE8], 2
       jmp      G_M000_IG239
 
G_M000_IG122:                ;; offset=0x1D5B
       mov      rcx, 0x7FF9D77EACB0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG123:                ;; offset=0x1D6A
       mov      rcx, 0x7FF9D77EACB4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x4C8], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x4CC], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      dword ptr [rbp-0x4D0], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x968], rax
       mov      rax, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rax
       mov      r9, gword ptr [rbp-0x968]
       mov      edx, dword ptr [rbp-0x4CC]
       mov      r8d, dword ptr [rbp-0x4D0]
       mov      rcx, bword ptr [rbp-0x4C8]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTupleFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyTuple]
       mov      gword ptr [rbp-0x970], rax
       mov      r9, gword ptr [rbp-0x970]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG225
 
G_M000_IG124:                ;; offset=0x1E0E
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG125
       mov      rcx, 0x7FF9D77EACB8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG125:                ;; offset=0x1E33
       mov      rcx, 0x7FF9D77EACBC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteStructure(byref):bool:this]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG225
 
G_M000_IG126:                ;; offset=0x1E5A
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG127
       mov      rcx, 0x7FF9D77EACC0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG127:                ;; offset=0x1E7F
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG128
       mov      rcx, 0x7FF9D77EACC4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteStructure(byref):bool:this]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG225
 
G_M000_IG128:                ;; offset=0x1EAE
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG129:                ;; offset=0x1EB2
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x990], ymm0
 
G_M000_IG130:                ;; offset=0x1EBE
       lea      r8, [rbp-0x990]
       lea      rdx, [rbp-0x4C0]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteContextManagerAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB68], rax
       mov      rcx, bword ptr [rbp-0xB68]
       mov      rdx, gword ptr [rbp-0x4C0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB68]
       mov      rcx, qword ptr [rbp-0x4B8]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG131
       mov      rcx, 0x7FF9D77EACC8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x998], rax
       mov      rcx, gword ptr [rbp-0x998]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG239
 
G_M000_IG131:                ;; offset=0x1F52
       mov      rcx, 0x7FF9D77EACCC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG225
 
G_M000_IG132:                ;; offset=0x1F73
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x28], rax
       mov      rax, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x30], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteComparisonInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref):int]
       mov      dword ptr [rbp-0x8C], eax
       cmp      dword ptr [rbp-0x8C], 0
       je       SHORT G_M000_IG133
       mov      rcx, 0x7FF9D77EACD0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x8C]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG239
 
G_M000_IG133:                ;; offset=0x1FD2
       mov      rcx, 0x7FF9D77EACD4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG225
 
G_M000_IG134:                ;; offset=0x1FF3
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteBuiltinArithmetic(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG135
       mov      rcx, 0x7FF9D77EACD8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG225
 
G_M000_IG135:                ;; offset=0x2021
       mov      rcx, 0x7FF9D77EACDC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG138
 
G_M000_IG136:                ;; offset=0x2032
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSequenceIndex(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG140
 
G_M000_IG137:                ;; offset=0x2050
       mov      rcx, 0x7FF9D77EACE0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG138:                ;; offset=0x205F
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x28], rax
       mov      rax, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x30], rax
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x38], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInputInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref,byref):int]
       mov      dword ptr [rbp-0x90], eax
       cmp      dword ptr [rbp-0x90], 0
       je       SHORT G_M000_IG139
       mov      rcx, 0x7FF9D77EACE4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x90]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG239
 
G_M000_IG139:                ;; offset=0x20C7
       mov      rcx, 0x7FF9D77EACE8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG225
 
G_M000_IG140:                ;; offset=0x20DB
       mov      rcx, 0x7FF9D77EACEC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG225
 
G_M000_IG141:                ;; offset=0x20EF
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG142
       mov      rcx, 0x7FF9D77EACF0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG225
 
G_M000_IG142:                ;; offset=0x2124
       mov      rcx, 0x7FF9D77EACF4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG151
 
G_M000_IG143:                ;; offset=0x2138
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG149
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x2CC], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      eax, dword ptr [rbp-0x2CC]
       jne      G_M000_IG148
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Values():Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[]:this]
       mov      gword ptr [rbp-0x2D8], rax
       mov      rax, gword ptr [rbp-0x2D8]
       mov      gword ptr [rbp-0xBC0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rdx, gword ptr [rbp-0xBC0]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG224
       mov      ecx, eax
       imul     rcx, rcx, 16
       lea      rcx, bword ptr [rdx+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x9A0], rax
       mov      rdx, gword ptr [rbp-0x9A0]
       mov      rcx, 0x7FF9D77E5D30
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x98], rax
       cmp      gword ptr [rbp-0x98], 0
       je       G_M000_IG147
       mov      rcx, gword ptr [rbp-0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:get_NativeCsvSource():Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:this]
       mov      gword ptr [rbp-0xA0], rax
       cmp      gword ptr [rbp-0xA0], 0
       je       G_M000_IG146
       mov      rcx, gword ptr [rbp-0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:get_CanUnpackDirectly():bool:this]
       test     eax, eax
       je       G_M000_IG145
       mov      rax, bword ptr [rbp-0x58]
       mov      bword ptr [rsp+0x20], rax
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x28], eax
 
G_M000_IG144:                ;; offset=0x2245
       lea      rdx, [rbp-0x2E8]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rbp-0xA0]
       mov      r9, gword ptr [rbp-0x98]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AdvanceCsvUnpack(Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource,Lokad.Lython.Runtime.PyIteration+Cursor,byref,bool):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB70], rax
       mov      rcx, bword ptr [rbp-0xB70]
       mov      rdx, gword ptr [rbp-0x2E8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB70]
       mov      rcx, qword ptr [rbp-0x2E0]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      G_M000_IG150
       mov      rcx, 0x7FF9D77EACF8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x9A8], rax
       mov      rcx, gword ptr [rbp-0x9A8]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG239
 
G_M000_IG145:                ;; offset=0x22E4
       mov      rcx, 0x7FF9D77EACFC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG146:                ;; offset=0x22F5
       mov      rcx, 0x7FF9D77EAD00
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG147:                ;; offset=0x2306
       mov      rcx, 0x7FF9D77EAD04
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG148:                ;; offset=0x2317
       mov      rcx, 0x7FF9D77EAD08
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG149:                ;; offset=0x2328
       mov      rcx, 0x7FF9D77EAD0C
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG151
 
G_M000_IG150:                ;; offset=0x2339
       mov      rcx, 0x7FF9D77EAD10
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG225
 
G_M000_IG151:                ;; offset=0x235A
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x460], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x9AC], eax
       mov      edx, dword ptr [rbp-0x9AC]
       lea      r8, [rbp-0xA8]
       lea      r9, [rbp-0xB8]
       mov      rcx, bword ptr [rbp-0x460]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryAdvanceNativeIteration(int,byref,byref):bool:this]
       test     eax, eax
       je       G_M000_IG155
       movzx    rax, byte  ptr [rbp-0xA8]
       test     eax, eax
       je       SHORT G_M000_IG154
       mov      rcx, 0x7FF9D77EAD14
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG152:                ;; offset=0x23C2
       vmovdqu  xmm0, xmmword ptr [rbp-0xB8]
       vmovdqu  xmmword ptr [rbp-0x9C0], xmm0
 
G_M000_IG153:                ;; offset=0x23D2
       lea      r9, [rbp-0x9C0]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG225
 
G_M000_IG154:                ;; offset=0x23F0
       mov      rcx, 0x7FF9D77EAD18
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x478], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x9C4], eax
       mov      edx, dword ptr [rbp-0x9C4]
       mov      rcx, bword ptr [rbp-0x478]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x10], eax
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG225
 
G_M000_IG155:                ;; offset=0x2454
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG156
       mov      rcx, 0x7FF9D77EAD1C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG156:                ;; offset=0x2479
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG157
       mov      rcx, 0x7FF9D77EAD20
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNext(byref):bool:this]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG225
 
G_M000_IG157:                ;; offset=0x24A8
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG158:                ;; offset=0x24AC
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0x9E8], ymm0
 
G_M000_IG159:                ;; offset=0x24B8
       lea      r8, [rbp-0x9E8]
       lea      rdx, [rbp-0x470]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNextAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB78], rax
       mov      rcx, bword ptr [rbp-0xB78]
       mov      rdx, gword ptr [rbp-0x470]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB78]
       mov      rcx, qword ptr [rbp-0x468]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG160
       mov      rcx, 0x7FF9D77EAD24
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x9F0], rax
       mov      rcx, gword ptr [rbp-0x9F0]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG239
 
G_M000_IG160:                ;; offset=0x254C
       mov      rcx, 0x7FF9D77EAD28
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG225
 
G_M000_IG161:                ;; offset=0x256D
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x144], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       cmp      eax, dword ptr [rbp-0x144]
       jne      G_M000_IG164
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x9F4], eax
       mov      edx, dword ptr [rbp-0x9F4]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      gword ptr [rbp-0x150], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      dword ptr [rbp-0x9F8], eax
       mov      edx, dword ptr [rbp-0x9F8]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      gword ptr [rbp-0x158], rax
       mov      rax, gword ptr [rbp-0x150]
       mov      gword ptr [rbp-0x658], rax
       mov      rcx, gword ptr [rbp-0x658]
       mov      rdx, 0x7FF9D77EAD30
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x658]
       mov      gword ptr [rbp-0xA00], rax
       mov      rdx, gword ptr [rbp-0xA00]
       mov      rcx, 0x7FF9D775AC10
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x160], rax
       cmp      gword ptr [rbp-0x160], 0
       je       G_M000_IG168
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xA08], rax
       cmp      gword ptr [rbp+0x20], 0
       setne    al
       movzx    rax, al
       mov      dword ptr [rsp+0x20], eax
       lea      rax, [rbp-0x170]
       mov      qword ptr [rsp+0x28], rax
       mov      r8, gword ptr [rbp-0xA08]
       mov      rdx, gword ptr [rbp-0x158]
       mov      rcx, gword ptr [rbp-0x160]
       mov      r9, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeUnaryBuiltin(Lokad.Lython.Runtime.LythonRuntime+BuiltinCallable,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
 
G_M000_IG162:                ;; offset=0x26A6
       je       G_M000_IG163
       lea      rcx, [rbp-0x170]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Reference():System.Object:this]
       mov      gword ptr [rbp-0x660], rax
       mov      rcx, gword ptr [rbp-0x660]
       mov      rdx, 0x7FF9D77EAE38
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x660]
       mov      gword ptr [rbp-0xA10], rax
       mov      rdx, gword ptr [rbp-0xA10]
       mov      rcx, 0x7FF9D74F0AF8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x178], rax
       cmp      gword ptr [rbp-0x178], 0
       je       SHORT G_M000_IG165
       mov      rcx, 0x7FF9D77EAF40
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x178]
       mov      gword ptr [rbp-0x50], rax
       jmp      G_M000_IG232
 
G_M000_IG163:                ;; offset=0x272A
       mov      rcx, 0x7FF9D77EAF44
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG168
 
G_M000_IG164:                ;; offset=0x273B
       mov      rcx, 0x7FF9D77EAF48
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG169
 
G_M000_IG165:                ;; offset=0x274F
       mov      rcx, 0x7FF9D77EAF4C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG166:                ;; offset=0x275E
       vmovdqu  xmm0, xmmword ptr [rbp-0x170]
       vmovdqu  xmmword ptr [rbp-0xA20], xmm0
 
G_M000_IG167:                ;; offset=0x276E
       lea      r9, [rbp-0xA20]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x58]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG225
 
G_M000_IG168:                ;; offset=0x278C
       mov      rcx, 0x7FF9D77EAF50
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x144]
       lea      r8d, [rax+0x01]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      edx, dword ptr [rbp-0x144]
       mov      r9, gword ptr [rbp-0x150]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishValue(int,int,System.Object):this]
       mov      eax, dword ptr [rbp-0x144]
       lea      r8d, [rax+0x02]
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       mov      eax, dword ptr [rbp-0x144]
       lea      edx, [rax+0x01]
       mov      r9, gword ptr [rbp-0x158]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishValue(int,int,System.Object):this]
 
G_M000_IG169:                ;; offset=0x27F4
       mov      rax, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [rax]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x400], rax
       mov      rax, gword ptr [rbp-0x400]
       mov      gword ptr [rbp-0x668], rax
       mov      rcx, gword ptr [rbp-0x668]
       mov      rdx, 0x7FF9D77EAF58
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x668]
       mov      gword ptr [rbp-0xA28], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0xA2C], eax
       mov      rcx, gword ptr [rbp-0xA28]
       mov      edx, dword ptr [rbp-0xA2C]
       mov      r11, 0x7FF9D7092948
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0xC0], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0xC4], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x408], rax
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_TargetOffset():int:this]
       add      eax, dword ptr [rbp-0xC4]
       mov      dword ptr [rbp-0xA30], eax
       mov      edx, dword ptr [rbp-0xA30]
       mov      rcx, bword ptr [rbp-0x408]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0xD0], rax
       mov      eax, dword ptr [rbp-0xC4]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rsp+0x28], rax
       lea      rax, [rbp-0xD8]
       mov      qword ptr [rsp+0x30], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, gword ptr [rbp-0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       G_M000_IG173
       cmp      gword ptr [rbp-0xD8], 0
       je       SHORT G_M000_IG171
       mov      rax, gword ptr [rbp-0xD8]
       mov      gword ptr [rbp-0x670], rax
       mov      rcx, gword ptr [rbp-0x670]
 
G_M000_IG170:                ;; offset=0x2929
       mov      rdx, 0x7FF9D77EB060
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x670]
       mov      gword ptr [rbp-0xA38], rax
       mov      rdx, gword ptr [rbp-0xA38]
       mov      rcx, 0x7FF9D74F0AF8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      gword ptr [rbp-0x180], rax
       cmp      gword ptr [rbp-0x180], 0
       je       SHORT G_M000_IG172
       mov      rax, gword ptr [rbp-0x180]
       mov      gword ptr [rbp-0x50], rax
       jmp      G_M000_IG232
 
G_M000_IG171:                ;; offset=0x297D
       mov      rcx, 0x7FF9D77EB168
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG225
 
G_M000_IG172:                ;; offset=0x2991
       mov      rcx, 0x7FF9D77EB16C
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x458], xmm0
       vmovdqu  xmmword ptr [rbp-0x450], xmm0
       mov      rdx, gword ptr [rbp-0xD8]
       mov      rcx, 0x7FF9D76A9D18
       call     CORINFO_HELP_CHKCASTCLASS
       mov      gword ptr [rbp-0xA40], rax
       mov      r8, gword ptr [rbp-0xA40]
       lea      rcx, [rbp-0x458]
       mov      rdx, 0x7FF9D77E6320
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:.ctor(System.__Canon):this]
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rbp-0xB80], rax
       mov      rcx, bword ptr [rbp-0xB80]
       mov      rax, bword ptr [rbp-0xB80]
       cmp      byte  ptr [rax], al
       lea      rdx, [rbp-0x458]
       mov      r8d, 24
       vzeroupper 
       call     CORINFO_HELP_BULK_WRITEBARRIER
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xE8], 3
       jmp      G_M000_IG239
 
G_M000_IG173:                ;; offset=0x2A49
       cmp      gword ptr [rbp+0x20], 0
       jne      G_M000_IG176
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rsp+0x20], rax
       lea      rax, [rbp-0x188]
       mov      qword ptr [rsp+0x28], rax
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp-0xC0]
       mov      r9d, dword ptr [rbp-0xC4]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDeferredChild(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG174
       mov      rcx, 0x7FF9D77EB170
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG174:                ;; offset=0x2AAA
       cmp      gword ptr [rbp-0x188], 0
       je       G_M000_IG175
       mov      rcx, 0x7FF9D77EB174
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x440], xmm0
       vmovdqu  xmmword ptr [rbp-0x438], xmm0
       lea      rcx, [rbp-0x440]
       mov      r8, gword ptr [rbp-0x188]
       mov      rdx, 0x7FF9D77E6320
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:.ctor(System.__Canon):this]
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rbp-0xB88], rax
       mov      rcx, bword ptr [rbp-0xB88]
       mov      rax, bword ptr [rbp-0xB88]
       cmp      byte  ptr [rax], al
       lea      rdx, [rbp-0x440]
       mov      r8d, 24
       vzeroupper 
       call     CORINFO_HELP_BULK_WRITEBARRIER
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xE8], 3
       jmp      G_M000_IG239
 
G_M000_IG175:                ;; offset=0x2B53
       mov      rcx, 0x7FF9D77EB178
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG225
 
G_M000_IG176:                ;; offset=0x2B67
       movzx    rax, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], eax
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x28], rax
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [rbp-0xC0]
       mov      r8d, dword ptr [rbp-0xC4]
       mov      r9, gword ptr [rbp-0xD0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBeginExecutableCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool,byref):bool:this]
       test     eax, eax
       je       G_M000_IG180
       mov      rcx, bword ptr [rbp+0x40]
       mov      rdx, 0x7FF9D77E6320
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:get_IsCompletedSuccessfully():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG178
       mov      rcx, bword ptr [rbp+0x40]
       mov      rdx, 0x7FF9D77E6320
       call     [System.Threading.Tasks.ValueTask`1[System.__Canon]:get_Result():System.__Canon:this]
       cmp      rax, gword ptr [rbp+0x20]
       je       SHORT G_M000_IG179
 
G_M000_IG177:                ;; offset=0x2BD3
       mov      rcx, 0x7FF9D77EB17C
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG178:                ;; offset=0x2BE2
       mov      rcx, 0x7FF9D77EB180
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp-0xC0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0xE8], 3
       jmp      G_M000_IG239
 
G_M000_IG179:                ;; offset=0x2C1B
       mov      rcx, 0x7FF9D77EB184
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x40]
       xor      ecx, ecx
       mov      qword ptr [rax], rcx
       mov      qword ptr [rax+0x08], rcx
       mov      qword ptr [rax+0x10], rcx
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG225
 
G_M000_IG180:                ;; offset=0x2C47
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG181
       mov      rcx, 0x7FF9D77EB188
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rsp+0x20], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x28], eax
       lea      rdx, [rbp-0xF8]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rbp-0xC0]
       mov      r9d, dword ptr [rbp-0xC4]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       lea      rdx, [rbp-0x108]
       lea      rcx, [rbp-0xF8]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       lea      rcx, [rbp-0x108]
       call     [System.Runtime.CompilerServices.ValueTaskAwaiter:GetResult():this]
       jmp      G_M000_IG225
 
G_M000_IG181:                ;; offset=0x2CB7
       mov      rax, gword ptr [rbp-0xD0]
       mov      gword ptr [rsp+0x20], rax
       mov      dword ptr [rsp+0x28], 1
       lea      rdx, [rbp-0x418]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r8, gword ptr [rbp-0xC0]
       mov      r9d, dword ptr [rbp-0xC4]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG182:                ;; offset=0x2CEC
       vmovdqu  xmm0, xmmword ptr [rbp-0x418]
       vmovdqu  xmmword ptr [rbp-0xA50], xmm0
 
G_M000_IG183:                ;; offset=0x2CFC
       lea      rdx, [rbp-0xA50]
       lea      rcx, [rbp-0x428]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB90], rax
       mov      rcx, bword ptr [rbp-0xB90]
       mov      rdx, gword ptr [rbp-0x428]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB90]
       mov      rcx, qword ptr [rbp-0x420]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG184
       mov      rcx, 0x7FF9D77EB18C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xA58], rax
       mov      rcx, gword ptr [rbp-0xA58]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG239
 
G_M000_IG184:                ;; offset=0x2D8A
       mov      rcx, 0x7FF9D77EB190
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG225
 
G_M000_IG185:                ;; offset=0x2DA8
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 32
       mov      bword ptr [rbp-0x480], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0xA5C], eax
       mov      edx, dword ptr [rbp-0xA5C]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      gword ptr [rbp-0x488], rax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      dword ptr [rbp-0x48C], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x490], eax
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xA68], rax
       mov      rax, gword ptr [rbp-0xA68]
       mov      gword ptr [rsp+0x20], rax
       mov      rdx, gword ptr [rbp-0x488]
       mov      r8d, dword ptr [rbp-0x48C]
       mov      r9d, dword ptr [rbp-0x490]
       mov      rcx, bword ptr [rbp-0x480]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryPrepareNativeIteration(System.Object,int,int,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG186
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG187
       mov      rcx, 0x7FF9D77EB194
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG186:                ;; offset=0x2E73
       mov      rcx, 0x7FF9D77EB198
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG225
 
G_M000_IG187:                ;; offset=0x2E87
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG188
       mov      rcx, 0x7FF9D77EB19C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG225
 
G_M000_IG188:                ;; offset=0x2EB3
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG189:                ;; offset=0x2EB7
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0xA88], ymm0
 
G_M000_IG190:                ;; offset=0x2EC3
       lea      r8, [rbp-0xA88]
       lea      rdx, [rbp-0x4A0]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteGetIteratorAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG191:                ;; offset=0x2EDD
       vmovdqu  xmm0, xmmword ptr [rbp-0x4A0]
       vmovdqu  xmmword ptr [rbp-0xA98], xmm0
 
G_M000_IG192:                ;; offset=0x2EED
       lea      rdx, [rbp-0xA98]
       lea      rcx, [rbp-0x4B0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xB98], rax
       mov      rcx, bword ptr [rbp-0xB98]
       mov      rdx, gword ptr [rbp-0x4B0]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xB98]
       mov      rcx, qword ptr [rbp-0x4A8]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG193
       mov      rcx, 0x7FF9D77EB1A0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xAA0], rax
       mov      rcx, gword ptr [rbp-0xAA0]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG239
 
G_M000_IG193:                ;; offset=0x2F7B
       mov      rcx, 0x7FF9D77EB1A4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG225
 
G_M000_IG194:                ;; offset=0x2F99
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG195
       mov      rcx, 0x7FF9D77EB1A8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG195:                ;; offset=0x2FBE
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       jne      SHORT G_M000_IG196
       mov      rcx, 0x7FF9D77EB1AC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG225
 
G_M000_IG196:                ;; offset=0x2FEA
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG197:                ;; offset=0x2FEE
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0xAC0], ymm0
 
G_M000_IG198:                ;; offset=0x2FFA
       lea      r8, [rbp-0xAC0]
       lea      rdx, [rbp-0x3E8]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSliceValueOperationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
 
G_M000_IG199:                ;; offset=0x3014
       vmovdqu  xmm0, xmmword ptr [rbp-0x3E8]
       vmovdqu  xmmword ptr [rbp-0xAD0], xmm0
 
G_M000_IG200:                ;; offset=0x3024
       lea      rdx, [rbp-0xAD0]
       lea      rcx, [rbp-0x3F8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xBA0], rax
       mov      rcx, bword ptr [rbp-0xBA0]
       mov      rdx, gword ptr [rbp-0x3F8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xBA0]
       mov      rcx, qword ptr [rbp-0x3F0]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG201
       mov      rcx, 0x7FF9D77EB1B0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xAD8], rax
       mov      rcx, gword ptr [rbp-0xAD8]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG239
 
G_M000_IG201:                ;; offset=0x30B2
       mov      rcx, 0x7FF9D77EB1B4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG225
 
G_M000_IG202:                ;; offset=0x30D0
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG203
       mov      rcx, 0x7FF9D77EB1B8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG203:                ;; offset=0x30F5
       mov      rcx, 0x7FF9D77EB1BC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x58]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG225
 
G_M000_IG204:                ;; offset=0x3119
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0xADC], eax
       mov      edx, dword ptr [rbp-0xADC]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      gword ptr [rbp-0xE0], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG206
       mov      rcx, gword ptr [rbp-0xE0]
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       jne      SHORT G_M000_IG205
       mov      rcx, 0x7FF9D77EB1C0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG205:                ;; offset=0x317D
       mov      rcx, 0x7FF9D77EB1C4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG206:                ;; offset=0x318C
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       SHORT G_M000_IG208
       mov      rdx, gword ptr [rbp-0xE0]
       mov      rcx, 0x7FF9D77E9A80
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG209
 
G_M000_IG207:                ;; offset=0x31AF
       mov      rcx, 0x7FF9D77EB1C8
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG208:                ;; offset=0x31BE
       mov      rcx, 0x7FF9D77EB1CC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG225
 
G_M000_IG209:                ;; offset=0x31EB
       mov      rax, bword ptr [rbp-0x58]
 
G_M000_IG210:                ;; offset=0x31EF
       vmovdqu  ymm0, ymmword ptr [rax]
       vmovdqu  ymmword ptr [rbp-0xB00], ymm0
 
G_M000_IG211:                ;; offset=0x31FB
       lea      r8, [rbp-0xB00]
       lea      rdx, [rbp-0x3C8]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteConditionalJumpAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xBA8], rax
       mov      rcx, bword ptr [rbp-0xBA8]
       mov      rdx, gword ptr [rbp-0x3C8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xBA8]
       mov      rcx, qword ptr [rbp-0x3C0]
       mov      qword ptr [rax+0x08], rcx
       mov      rcx, bword ptr [rbp+0x30]
       call     [System.Threading.Tasks.ValueTask`1[bool]:get_IsCompleted():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG212
       mov      rcx, 0x7FF9D77EB1D0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xB08], rax
       mov      rcx, gword ptr [rbp-0xB08]
       mov      rdx, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PauseOperation(Lokad.Lython.LythonSourceSpan,byref):int]
       mov      dword ptr [rbp-0xE8], eax
       jmp      G_M000_IG239
 
G_M000_IG212:                ;; offset=0x328F
       mov      rcx, 0x7FF9D77EB1D4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x44], eax
       jmp      G_M000_IG225
 
G_M000_IG213:                ;; offset=0x32B0
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG217
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0x18C], eax
       cmp      dword ptr [rbp-0x18C], 49
       je       SHORT G_M000_IG216
       cmp      dword ptr [rbp-0x18C], 57
       je       SHORT G_M000_IG215
       cmp      dword ptr [rbp-0x18C], 58
       je       SHORT G_M000_IG214
       mov      rcx, 0x7FF9D77EB1D8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 6
       jmp      G_M000_IG239
 
G_M000_IG214:                ;; offset=0x3300
       mov      rcx, 0x7FF9D77EB1DC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG217
 
G_M000_IG215:                ;; offset=0x3311
       mov      rcx, 0x7FF9D77EB1E0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG217
 
G_M000_IG216:                ;; offset=0x3322
       mov      rcx, 0x7FF9D77EB1E4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG217:                ;; offset=0x3331
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp-0x44], eax
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x68]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_IsUnassigned():bool:this]
       test     eax, eax
       jne      G_M000_IG219
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       G_M000_IG220
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG218
       mov      rcx, 0x7FF9D77EB1E8
       call     CORINFO_HELP_COUNTPROFILE32
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x3D8], xmm0
       lea      rcx, [rbp-0x3D8]
       mov      edx, dword ptr [rbp-0x44]
       call     [System.Threading.Tasks.ValueTask`1[bool]:.ctor(bool):this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xBB0], rax
       mov      rcx, bword ptr [rbp-0xBB0]
       mov      rdx, gword ptr [rbp-0x3D8]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xBB0]
       mov      rcx, qword ptr [rbp-0x3D0]
       mov      qword ptr [rax+0x08], rcx
       mov      dword ptr [rbp-0xE8], 5
       jmp      G_M000_IG239
 
G_M000_IG218:                ;; offset=0x33F4
       mov      rcx, 0x7FF9D77EB1EC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG220
 
G_M000_IG219:                ;; offset=0x3405
       mov      rcx, 0x7FF9D77EB1F0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG225
 
G_M000_IG220:                ;; offset=0x3419
       mov      rcx, 0x7FF9D77EB1F4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       jmp      G_M000_IG239
 
G_M000_IG221:                ;; offset=0x3437
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x1F0], ymm0
       vmovdqu  xmmword ptr [rbp-0x1D8], xmm0
       lea      rcx, [rbp-0x1F0]
       mov      edx, 27
       mov      r8d, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
 
G_M000_IG222:                ;; offset=0x3463
       vmovdqu  ymm0, ymmword ptr [rbp-0x1F0]
       vmovdqu  ymmword ptr [rbp-0x1B8], ymm0
       mov      rax, qword ptr [rbp-0x1D0]
       mov      qword ptr [rbp-0x198], rax
 
G_M000_IG223:                ;; offset=0x3481
       lea      rcx, [rbp-0x1B8]
       mov      rdx, 0x2C171C92A40
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendLiteral(System.String):this]
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       mov      dword ptr [rbp-0xB0C], eax
       mov      edx, dword ptr [rbp-0xB0C]
       lea      rcx, [rbp-0x1B8]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x1F8], rax
       lea      rcx, [rbp-0x1B8]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      gword ptr [rbp-0xB18], rax
       mov      rdx, gword ptr [rbp-0xB18]
       mov      rcx, gword ptr [rbp-0x1F8]
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, gword ptr [rbp-0x1F8]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG224:                ;; offset=0x3506
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG225:                ;; offset=0x350C
       mov      eax, dword ptr [rbp-0x674]
       dec      eax
       mov      dword ptr [rbp-0x674], eax
       cmp      dword ptr [rbp-0x674], 0
       jg       SHORT G_M000_IG227
 
G_M000_IG226:                ;; offset=0x3523
       lea      rcx, [rbp-0x674]
       mov      edx, 0x102A
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG227:                ;; offset=0x3536
       movzx    rax, byte  ptr [rbp+0x28]
       test     eax, eax
       je       G_M000_IG230
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rax+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG229
       mov      rcx, 0x7FF9D77EB204
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rcx, [rbp-0x210]
       mov      edx, dword ptr [rbp-0x44]
       call     [System.Threading.Tasks.ValueTask`1[bool]:.ctor(bool):this]
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rbp-0xBB8], rax
       mov      rcx, bword ptr [rbp-0xBB8]
       mov      rdx, gword ptr [rbp-0x210]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rax, bword ptr [rbp-0xBB8]
       mov      rcx, qword ptr [rbp-0x208]
       mov      qword ptr [rax+0x08], rcx
       mov      eax, 5
 
G_M000_IG228:                ;; offset=0x35AE
       vzeroupper 
       add      rsp, 0xC00
       pop      rbp
       ret      
 
G_M000_IG229:                ;; offset=0x35BA
       mov      rcx, 0x7FF9D77EB208
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG230:                ;; offset=0x35C9
       cmp      dword ptr [rbp-0x44], 0
       jne      SHORT G_M000_IG231
       mov      rcx, 0x7FF9D77EB20C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp+0x10]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp+0x10]
       add      rax, 16
       mov      bword ptr [rbp-0x200], rax
       mov      rax, bword ptr [rbp-0x200]
       inc      dword ptr [rax]
       jmp      SHORT G_M000_IG235
 
G_M000_IG231:                ;; offset=0x35FE
       mov      rcx, 0x7FF9D77EB210
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG235
 
G_M000_IG232:                ;; offset=0x360F
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xB30], rax
       mov      r9, gword ptr [rbp-0xB30]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG234
 
G_M000_IG233:                ;; offset=0x363D
       mov      rcx, gword ptr [rbp-0x50]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG234:                ;; offset=0x3647
       mov      rcx, 0x7FF9D77EB214
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x44], 1
       jmp      G_M000_IG225
 
G_M000_IG235:                ;; offset=0x3662
       mov      eax, dword ptr [rbp-0x674]
       dec      eax
       mov      dword ptr [rbp-0x674], eax
       cmp      dword ptr [rbp-0x674], 0
       jg       SHORT G_M000_IG237
 
G_M000_IG236:                ;; offset=0x3679
       lea      rcx, [rbp-0x674]
       mov      edx, 0x106F
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG237:                ;; offset=0x368C
       mov      rax, bword ptr [rbp+0x10]
       mov      eax, dword ptr [rax+0x10]
       mov      rcx, gword ptr [rbp-0x40]
       cmp      eax, dword ptr [rcx+0x08]
       jl       G_M000_IG03
       mov      rcx, 0x7FF9D77EB218
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, 1
 
G_M000_IG238:                ;; offset=0x36B4
       vzeroupper 
       add      rsp, 0xC00
       pop      rbp
       ret      
 
G_M000_IG239:                ;; offset=0x36C0
       mov      rcx, 0x7FF9D77EB21C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0xE8]
 
G_M000_IG240:                ;; offset=0x36D5
       vzeroupper 
       add      rsp, 0xC00
       pop      rbp
       ret      
 
G_M000_IG241:                ;; offset=0x36E1
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG242:                ;; offset=0x36E7
       sub      rsp, 72
 
G_M000_IG243:                ;; offset=0x36EB
       mov      gword ptr [rbp-0x640], rcx
       mov      rax, gword ptr [rbp-0x640]
       mov      gword ptr [rbp-0x1C0], rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG245
 
G_M000_IG244:                ;; offset=0x3707
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG245:                ;; offset=0x370D
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xB20], rax
       mov      r8, gword ptr [rbp-0xB20]
       mov      rdx, gword ptr [rbp-0x1C0]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryRouteReturn(Lokad.Lython.Runtime.LythonRuntime+ReturnSignal,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG247
       mov      rcx, 0x7FF9D77EB1F8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0xE8], 1
       lea      rax, G_M000_IG239
 
G_M000_IG246:                ;; offset=0x375C
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG247:                ;; offset=0x3764
       mov      rcx, 0x7FF9D77EB1FC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x44], 1
       lea      rax, G_M000_IG225
 
G_M000_IG248:                ;; offset=0x3781
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG249:                ;; offset=0x3789
       sub      rsp, 72
 
G_M000_IG250:                ;; offset=0x378D
       mov      gword ptr [rbp-0x638], rcx
       mov      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0xB28], rax
       mov      r9, gword ptr [rbp-0xB28]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [rbp-0x638]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG252
 
G_M000_IG251:                ;; offset=0x37C5
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG252:                ;; offset=0x37CB
       mov      rcx, 0x7FF9D77EB200
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x44], 1
       lea      rax, G_M000_IG225
 
G_M000_IG253:                ;; offset=0x37E8
       vzeroupper 
       add      rsp, 72
       ret      
 
RWD00  	dd	00001334h ; case G_M000_IG91
       	dd	00001629h ; case G_M000_IG104
       	dd	00000104h ; case G_M000_IG08
       	dd	000002ACh ; case G_M000_IG12
       	dd	000016ABh ; case G_M000_IG105
       	dd	0000172Ch ; case G_M000_IG106
       	dd	00000ADBh ; case G_M000_IG54
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	0000200Dh ; case G_M000_IG138
       	dd	0000200Dh ; case G_M000_IG138
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	00000481h ; case G_M000_IG19
       	dd	000014E2h ; case G_M000_IG97
       	dd	000014E2h ; case G_M000_IG97
       	dd	000017EFh ; case G_M000_IG108
       	dd	0000040Fh ; case G_M000_IG16
       	dd	00000439h ; case G_M000_IG17
       	dd	0000184Ah ; case G_M000_IG110
       	dd	0000194Ah ; case G_M000_IG112
       	dd	00001A7Fh ; case G_M000_IG114
       	dd	00001B2Ah ; case G_M000_IG115
       	dd	00001BAEh ; case G_M000_IG116
       	dd	00001C52h ; case G_M000_IG117
       	dd	00001DBCh ; case G_M000_IG124
       	dd	00001DBCh ; case G_M000_IG124
       	dd	00001DBCh ; case G_M000_IG124
       	dd	00001E08h ; case G_M000_IG126
       	dd	00001E08h ; case G_M000_IG126
       	dd	00001E08h ; case G_M000_IG126
       	dd	00001DBCh ; case G_M000_IG124
       	dd	00002D56h ; case G_M000_IG185
       	dd	00002308h ; case G_M000_IG151
       	dd	000027A2h ; case G_M000_IG169
       	dd	00001FE0h ; case G_M000_IG136
       	dd	00002F47h ; case G_M000_IG194
       	dd	0000307Eh ; case G_M000_IG202
       	dd	00001FA1h ; case G_M000_IG134
       	dd	00001FA1h ; case G_M000_IG134
       	dd	00001FA1h ; case G_M000_IG134
       	dd	0000325Eh ; case G_M000_IG213
       	dd	000030C7h ; case G_M000_IG204
       	dd	00001F21h ; case G_M000_IG132
       	dd	0000325Eh ; case G_M000_IG213
       	dd	0000325Eh ; case G_M000_IG213
       	dd	0000325Eh ; case G_M000_IG213
       	dd	0000325Eh ; case G_M000_IG213
       	dd	0000325Eh ; case G_M000_IG213
       	dd	0000325Eh ; case G_M000_IG213
       	dd	0000325Eh ; case G_M000_IG213
       	dd	000000E6h ; case G_M000_IG07
       	dd	00000C17h ; case G_M000_IG59
       	dd	0000101Bh ; case G_M000_IG76
       	dd	0000325Eh ; case G_M000_IG213
       	dd	000005DEh ; case G_M000_IG29
       	dd	000005DEh ; case G_M000_IG29
       	dd	000005DEh ; case G_M000_IG29
       	dd	000005DEh ; case G_M000_IG29
       	dd	000005DEh ; case G_M000_IG29
       	dd	0000209Dh ; case G_M000_IG141
       	dd	000020E6h ; case G_M000_IG143
       	dd	000007E0h ; case G_M000_IG41
       	dd	000009A8h ; case G_M000_IG47
       	dd	000001A1h ; case G_M000_IG09
       	dd	0000251Bh ; case G_M000_IG161

; Total bytes of code 14320

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInstructionPrefix(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref,byref,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int (Tier1-OSR)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1-OSR code
; OSR variant for entry point 0x102a
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 242
; 128 inlinees with PGO data; 369 single block inlinees; 8 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rax
       mov      rax, qword ptr [rbp]
       push     rax
       sub      rsp, 800
       mov      qword ptr [rsp+0xF28], r15
       mov      qword ptr [rsp+0xF20], r14
       mov      qword ptr [rsp+0xF18], r13
       mov      qword ptr [rsp+0xF10], r12
       mov      qword ptr [rsp+0xF08], rdi
       mov      qword ptr [rsp+0xF00], rsi
       mov      qword ptr [rsp+0xEF8], rbx
       lea      rbp, [rsp+0x320]
       vxorps   xmm4, xmm4, xmm4
       mov      rax, -624
 
G_M000_IG571:                ;; offset=0x005B
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG571
       mov      qword ptr [rbp-0x40], rax
       mov      eax, dword ptr [rbp+0xC38]
 
G_M000_IG02:                ;; offset=0x007D
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG549
 
G_M000_IG03:                ;; offset=0x008A
       cmp      dword ptr [rbp+0xBCC], 0
       jne      SHORT G_M000_IG05
 
G_M000_IG04:                ;; offset=0x0093
       mov      rcx, bword ptr [rbp+0xC20]
       inc      dword ptr [rcx+0x10]
 
G_M000_IG05:                ;; offset=0x009D
       mov      rcx, bword ptr [rbp+0xC20]
       mov      edx, dword ptr [rcx+0x10]
       mov      rax, gword ptr [rbp+0xBD0]
       mov      ebx, dword ptr [rax+0x08]
       cmp      edx, ebx
       jge      G_M000_IG555
 
G_M000_IG06:                ;; offset=0x00B9
       xor      edx, edx
       mov      dword ptr [rbp+0xBCC], edx
       mov      edx, dword ptr [rcx+0x10]
       cmp      edx, ebx
       jae      G_M000_IG557
       mov      rax, gword ptr [rbp+0xBD0]
       shl      rdx, 5
       lea      rdx, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp+0xBB8], rdx
       mov      r9, gword ptr [rbp+0xC28]
       mov      rdx, gword ptr [r9+0x98]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      rax, gword ptr [rax]
       mov      r8, gword ptr [rdx+0x88]
       cmp      gword ptr [r8+0x20], 0
       jne      G_M000_IG548
       mov      r8, gword ptr [rdx+0x180]
       test     r8, r8
       jne      G_M000_IG547
 
G_M000_IG07:                ;; offset=0x011D
       mov      r8, bword ptr [rbp+0xBB8]
       mov      r8d, dword ptr [r8+0x1C]
       cmp      r8d, 73
       ja       G_M000_IG273
       lea      rdx, [reloc @RWD00]
       mov      edx, dword ptr [rdx+4*r8]
       lea      rax, G_M000_IG02
       add      rdx, rax
       jmp      rdx
 
G_M000_IG08:                ;; offset=0x0149
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rbx, gword ptr [rcx]
       mov      rsi, gword ptr [rcx+0x08]
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x1C]
       cmp      edx, 2
       je       SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x0166
       cmp      edx, 25
       jne      G_M000_IG276
 
G_M000_IG10:                ;; offset=0x016F
       mov      rax, bword ptr [rbp+0xBB8]
       mov      edi, dword ptr [rax+0x08]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      r14, gword ptr [rax]
       cmp      edi, dword ptr [rsi+0x08]
       jae      G_M000_IG544
       mov      eax, edi
       shl      rax, 4
       lea      rax, bword ptr [rsi+rax+0x10]
       mov      rdx, gword ptr [rax]
       mov      r8, 0x2A14B001CE0
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG278
 
G_M000_IG11:                ;; offset=0x01AD
       mov      r8, 0x2A14B001CE8
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG279
       cmp      qword ptr [rax+0x08], 0
       jne      G_M000_IG280
 
G_M000_IG12:                ;; offset=0x01CB
       test     rdx, rdx
       je       SHORT G_M000_IG15
 
G_M000_IG13:                ;; offset=0x01D0
       mov      rax, 0x7FF9D77E4838
       cmp      qword ptr [rdx], rax
       jne      SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x01DF
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       jmp      SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x01EA
       mov      rax, rdx
 
G_M000_IG16:                ;; offset=0x01ED
       test     rax, rax
       je       G_M000_IG281
 
G_M000_IG17:                ;; offset=0x01F6
       mov      rbx, rax
       mov      rdx, bword ptr [rbp+0xBB8]
       cmp      dword ptr [rdx+0x18], 0
       jl       G_M000_IG47
 
G_M000_IG18:                ;; offset=0x020A
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x0224
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG282
 
G_M000_IG20:                ;; offset=0x0238
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edi, dword ptr [rdx+0x14]
 
G_M000_IG21:                ;; offset=0x0242
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      r14d, dword ptr [rdx+0x18]
       test     r14d, r14d
       jl       G_M000_IG30
 
G_M000_IG22:                ;; offset=0x0256
       cmp      r14d, dword ptr [rsi+0x40]
       jge      G_M000_IG29
 
G_M000_IG23:                ;; offset=0x0260
       mov      r15d, dword ptr [rsi+0x40]
       dec      r15d
       mov      r13d, dword ptr [rsi+0x3C]
       cmp      r15d, r13d
       jle      G_M000_IG31
 
G_M000_IG24:                ;; offset=0x0274
       cmp      r13d, r14d
       jge      G_M000_IG32
 
G_M000_IG25:                ;; offset=0x027D
       mov      rdx, gword ptr [rsi]
       mov      eax, dword ptr [rsi+0x40]
       sub      eax, r14d
       test     rdx, rdx
       je       G_M000_IG294
       lea      r8, bword ptr [rdx+0x10]
       xor      r10d, r10d
       mov      r11, qword ptr [rdx]
       cmp      dword ptr [r11+0x04], 24
       jne      G_M000_IG295
 
G_M000_IG26:                ;; offset=0x02A4
       mov      r15d, r14d
       sub      r15d, r10d
       cmp      r14d, r10d
       jl       G_M000_IG46
 
G_M000_IG27:                ;; offset=0x02B3
       mov      r10d, r15d
       or       r10d, eax
       jl       G_M000_IG46
       lea      r10d, [r15+rax]
       cmp      r10d, dword ptr [rdx+0x08]
       ja       G_M000_IG46
       movzx    rdx, word  ptr [r11]
       mov      r10d, r15d
       imul     r10, rdx
       add      r10, r8
       mov      eax, eax
       imul     rdx, rax
       test     dword ptr [r11], 0x1000000
       je       G_M000_IG296
       shr      rdx, 3
       mov      rcx, r10
       call     [System.SpanHelpers:ClearWithReferences(byref,nuint)]
 
G_M000_IG28:                ;; offset=0x02FB
       mov      dword ptr [rsi+0x40], r14d
 
G_M000_IG29:                ;; offset=0x02FF
       mov      rdx, gword ptr [rsi]
       cmp      edi, dword ptr [rdx+0x08]
       jae      G_M000_IG544
       mov      eax, edi
       shl      rax, 4
       lea      rdi, bword ptr [rdx+rax+0x10]
       mov      rcx, rdi
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       xor      eax, eax
       mov      qword ptr [rdi+0x08], rax
       mov      dword ptr [rsi+0x40], r14d
       jmp      G_M000_IG02
 
G_M000_IG30:                ;; offset=0x0330
       not      r14d
       jmp      G_M000_IG22
 
G_M000_IG31:                ;; offset=0x0338
       mov      r13d, r15d
       jmp      G_M000_IG24
 
G_M000_IG32:                ;; offset=0x0340
       cmp      byte  ptr [rsi+0x44], 0
       jne      G_M000_IG283
 
G_M000_IG33:                ;; offset=0x034A
       mov      rdx, gword ptr [rsi]
       cmp      r13d, dword ptr [rdx+0x08]
       jae      G_M000_IG544
       mov      eax, r13d
       shl      rax, 4
       lea      r15, bword ptr [rdx+rax+0x10]
       mov      rdx, gword ptr [rsi+0x18]
       mov      r12, gword ptr [rdx+0x88]
       mov      rdx, gword ptr [r15]
       mov      rax, rdx
       test     rax, rax
       je       SHORT G_M000_IG35
 
G_M000_IG34:                ;; offset=0x0379
       mov      r8, 0x7FF9D7838AB0
       cmp      qword ptr [rax], r8
       jne      SHORT G_M000_IG39
 
G_M000_IG35:                ;; offset=0x0388
       test     rax, rax
       jne      SHORT G_M000_IG40
 
G_M000_IG36:                ;; offset=0x038D
       cmp      qword ptr [r15+0x08], -1
       je       G_M000_IG290
 
G_M000_IG37:                ;; offset=0x0398
       cmp      qword ptr [r15+0x08], -2
       je       G_M000_IG293
 
G_M000_IG38:                ;; offset=0x03A3
       dec      r13d
       cmp      r13d, r14d
       jge      SHORT G_M000_IG32
       jmp      G_M000_IG25
 
G_M000_IG39:                ;; offset=0x03B0
       mov      rcx, 0x7FF9D77CE450
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       jmp      SHORT G_M000_IG35
 
G_M000_IG40:                ;; offset=0x03C1
       xor      edx, edx
       mov      qword ptr [r15], rdx
       mov      qword ptr [r15+0x08], rdx
       mov      rdx, 0x7FF9D7838AB0
       cmp      qword ptr [rax], rdx
       jne      G_M000_IG289
       mov      rdx, gword ptr [rax+0x08]
       cmp      byte  ptr [rdx], dl
       cmp      byte  ptr [rax+0x38], 0
       je       SHORT G_M000_IG38
       mov      byte  ptr [rax+0x38], 0
       xor      r8, r8
       mov      gword ptr [rax+0x18], r8
 
G_M000_IG41:                ;; offset=0x03F4
       mov      gword ptr [rax+0x20], r8
 
G_M000_IG42:                ;; offset=0x03F8
       mov      qword ptr [rax+0x30], r8
       mov      r15, gword ptr [rdx+0x18]
       cmp      byte  ptr [rdx+0x48], 0
       jne      SHORT G_M000_IG45
 
G_M000_IG43:                ;; offset=0x0406
       test     r15, r15
       jne      G_M000_IG287
 
G_M000_IG44:                ;; offset=0x040F
       lea      rcx, bword ptr [rdx+0x18]
       mov      rdx, rax
       call     CORINFO_HELP_ASSIGN_REF
       test     r15, r15
       je       SHORT G_M000_IG38
       jmp      G_M000_IG288
 
G_M000_IG45:                ;; offset=0x0425
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:ReleaseStorage():this]
       jmp      G_M000_IG38
 
G_M000_IG46:                ;; offset=0x0433
       call     [System.ThrowHelper:ThrowIndexOutOfRangeException()]
       int3     
 
G_M000_IG47:                ;; offset=0x043A
       mov      gword ptr [rbp-0x1B0], rax
       xor      edx, edx
       mov      qword ptr [rbp-0x1A8], rdx
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x18]
       not      edx
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      edx, dword ptr [rcx+0x60]
       jl       G_M000_IG62
 
G_M000_IG48:                ;; offset=0x0466
       cmp      gword ptr [rcx+0x40], 0
       jne      G_M000_IG298
       mov      rax, gword ptr [rcx+0x38]
       mov      rdx, gword ptr [rax+0x88]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG298
       mov      rax, gword ptr [rax+0x180]
       test     rax, rax
       jne      G_M000_IG297
 
G_M000_IG49:                ;; offset=0x0497
       lea      rbx, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG51
 
G_M000_IG50:                ;; offset=0x04AA
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG301
 
G_M000_IG51:                ;; offset=0x04BE
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x14]
 
G_M000_IG52:                ;; offset=0x04C8
       mov      rdx, gword ptr [rbx]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG544
       mov      r11d, eax
       shl      r11, 4
       lea      rdx, bword ptr [rdx+r11+0x10]
       xor      r11, r11
       mov      gword ptr [rdx], r11
 
G_M000_IG53:                ;; offset=0x04E6
       mov      qword ptr [rdx+0x08], r11
       mov      dword ptr [rbx+0x40], eax
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rcx]
       mov      rdx, gword ptr [rdx+0x98]
       mov      r11d, dword ptr [rcx+0x10]
       inc      r11d
       cmp      r11d, dword ptr [rdx+0x08]
       jae      G_M000_IG544
       shl      r11, 5
       lea      rdx, bword ptr [rdx+r11+0x10]
       mov      ebx, dword ptr [rdx+0x1C]
       cmp      ebx, 25
       jne      G_M000_IG65
 
G_M000_IG54:                ;; offset=0x0524
       mov      rbx, gword ptr [rcx]
       mov      rsi, gword ptr [rcx+0x08]
       mov      edi, dword ptr [rdx+0x08]
 
G_M000_IG55:                ;; offset=0x052E
       vmovdqu  xmm0, xmmword ptr [rbp-0x1B0]
       vmovdqu  xmmword ptr [rbp-0x1C0], xmm0
 
G_M000_IG56:                ;; offset=0x053E
       mov      rdx, gword ptr [rbx+0x68]
       mov      r11, 0x7FF9D722C7D0
       cmp      qword ptr [rdx], r11
       jne      G_M000_IG303
       cmp      dword ptr [rdx+0x08], edi
       jbe      G_M000_IG302
       mov      r11d, edi
       mov      r14, gword ptr [rdx+8*r11+0x10]
 
G_M000_IG57:                ;; offset=0x0566
       cmp      word  ptr [r14+0x0C], 60
       setne    r15b
       movzx    r15, r15b
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG304
       mov      rdx, gword ptr [rbp+0xC30]
       mov      rax, gword ptr [rdx+0x88]
 
G_M000_IG58:                ;; offset=0x0590
       test     rax, rax
       setne    al
       movzx    rax, al
       test     eax, r15d
       jne      G_M000_IG305
       cmp      edi, dword ptr [rsi+0x08]
       jae      G_M000_IG544
       mov      eax, edi
       shl      rax, 4
       mov      r13, gword ptr [rsi+rax+0x10]
       test     r13, r13
       jne      G_M000_IG63
 
G_M000_IG59:                ;; offset=0x05BF
       mov      eax, edi
       shl      rax, 4
       lea      r13, bword ptr [rsi+rax+0x10]
       mov      rdx, gword ptr [rbp-0x1C0]
       mov      rcx, r13
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, qword ptr [rbp-0x1B8]
       mov      qword ptr [r13+0x08], rcx
       test     r15d, r15d
       je       SHORT G_M000_IG61
 
G_M000_IG60:                ;; offset=0x05E9
       cmp      byte  ptr [rbx+0xF2], 0
       jne      G_M000_IG306
       cmp      gword ptr [rbp+0xC30], 0
       je       SHORT G_M000_IG61
       mov      rdx, gword ptr [rbp+0xC30]
       cmp      byte  ptr [rdx+0xFF], 0
       jne      G_M000_IG306
 
G_M000_IG61:                ;; offset=0x0614
       mov      rsi, bword ptr [rbp+0xC20]
       inc      dword ptr [rsi+0x10]
       jmp      G_M000_IG02
 
G_M000_IG62:                ;; offset=0x0623
       lea      rdx, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x18]
       not      eax
       mov      rcx, rdx
       mov      edx, eax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp+0xC20]
       jmp      G_M000_IG48
 
G_M000_IG63:                ;; offset=0x064A
       mov      rax, 0x7FF9D77E4838
       cmp      qword ptr [r13], rax
       jne      G_M000_IG59
 
G_M000_IG64:                ;; offset=0x065E
       lea      rcx, [rbp-0x1C0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77F2610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rdx, rax
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      SHORT G_M000_IG61
 
G_M000_IG65:                ;; offset=0x068C
       cmp      ebx, 71
       je       G_M000_IG307
       cmp      ebx, 30
       jne      G_M000_IG312
       cmp      gword ptr [rbp-0x1B0], 0
       jne      G_M000_IG61
       jmp      G_M000_IG313
 
G_M000_IG66:                ;; offset=0x06B1
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rcx]
       mov      rax, gword ptr [rdx+0x30]
       mov      rbx, rax
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x1C]
       cmp      edx, 35
       jg       G_M000_IG407
       cmp      edx, 35
       ja       G_M000_IG406
       mov      rax, 0x7FFFFFFBD
       bt       rax, rdx
       jb       G_M000_IG406
 
G_M000_IG67:                ;; offset=0x06F2
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x08]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG544
       mov      rcx, gword ptr [rbx+8*rax+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      rbx, rax
       mov      rcx, bword ptr [rbp+0xBB8]
       cmp      dword ptr [rcx+0x18], 0
       jl       G_M000_IG76
 
G_M000_IG68:                ;; offset=0x0724
       mov      rsi, bword ptr [rbp+0xC20]
       lea      rdi, bword ptr [rsi+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG70
 
G_M000_IG69:                ;; offset=0x073E
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jae      G_M000_IG408
 
G_M000_IG70:                ;; offset=0x0752
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      r14d, dword ptr [rcx+0x14]
 
G_M000_IG71:                ;; offset=0x075D
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      r15d, dword ptr [rcx+0x18]
       test     r15d, r15d
       jl       SHORT G_M000_IG75
 
G_M000_IG72:                ;; offset=0x076D
       cmp      r15d, dword ptr [rdi+0x40]
       jge      SHORT G_M000_IG74
 
G_M000_IG73:                ;; offset=0x0773
       mov      rcx, rdi
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG74:                ;; offset=0x077F
       mov      rcx, gword ptr [rdi]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG544
       mov      edx, r14d
       shl      rdx, 4
       lea      r14, bword ptr [rcx+rdx+0x10]
       mov      rcx, r14
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r14+0x08], rcx
       mov      dword ptr [rdi+0x40], r15d
       jmp      G_M000_IG02
 
G_M000_IG75:                ;; offset=0x07B2
       not      r15d
       jmp      SHORT G_M000_IG72
 
G_M000_IG76:                ;; offset=0x07B7
       mov      gword ptr [rbp-0x208], rbx
       xor      ecx, ecx
       mov      qword ptr [rbp-0x200], rcx
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      ecx, dword ptr [rcx+0x18]
       not      ecx
       mov      rsi, bword ptr [rbp+0xC20]
       cmp      ecx, dword ptr [rsi+0x60]
       jl       G_M000_IG90
 
G_M000_IG77:                ;; offset=0x07E3
       cmp      gword ptr [rsi+0x40], 0
       jne      G_M000_IG410
       mov      rcx, gword ptr [rsi+0x38]
       mov      rax, gword ptr [rcx+0x88]
       cmp      gword ptr [rax+0x20], 0
       jne      G_M000_IG410
       mov      rcx, gword ptr [rcx+0x180]
       test     rcx, rcx
       jne      G_M000_IG409
 
G_M000_IG78:                ;; offset=0x0814
       lea      rbx, bword ptr [rsi+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG80
 
G_M000_IG79:                ;; offset=0x0827
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jae      G_M000_IG413
 
G_M000_IG80:                ;; offset=0x083B
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x14]
 
G_M000_IG81:                ;; offset=0x0845
       mov      rcx, gword ptr [rbx]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG544
       mov      edx, eax
       shl      rdx, 4
       lea      rcx, bword ptr [rcx+rdx+0x10]
       xor      rdx, rdx
       mov      gword ptr [rcx], rdx
 
G_M000_IG82:                ;; offset=0x0861
       mov      qword ptr [rcx+0x08], rdx
       mov      dword ptr [rbx+0x40], eax
       mov      rax, gword ptr [rsi]
       mov      rax, gword ptr [rax+0x98]
       mov      ecx, dword ptr [rsi+0x10]
       inc      ecx
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG544
       shl      rcx, 5
       lea      rdx, bword ptr [rax+rcx+0x10]
       mov      ebx, dword ptr [rdx+0x1C]
       cmp      ebx, 25
       jne      G_M000_IG93
 
G_M000_IG83:                ;; offset=0x0895
       mov      rbx, gword ptr [rsi]
       mov      rdi, gword ptr [rsi+0x08]
       mov      r14d, dword ptr [rdx+0x08]
 
G_M000_IG84:                ;; offset=0x08A0
       vmovdqu  xmm0, xmmword ptr [rbp-0x208]
       vmovdqu  xmmword ptr [rbp-0x218], xmm0
 
G_M000_IG85:                ;; offset=0x08B0
       mov      rcx, gword ptr [rbx+0x68]
       mov      rax, 0x7FF9D722C7D0
       cmp      qword ptr [rcx], rax
       jne      G_M000_IG414
       cmp      dword ptr [rcx+0x08], r14d
       jbe      G_M000_IG302
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG544
       mov      eax, r14d
       mov      r15, gword ptr [rcx+8*rax+0x10]
 
G_M000_IG86:                ;; offset=0x08E3
       cmp      word  ptr [r15+0x0C], 60
       setne    r13b
       movzx    r13, r13b
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG415
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rax, gword ptr [rcx+0x88]
 
G_M000_IG87:                ;; offset=0x090D
       test     rax, rax
       setne    al
       movzx    rax, al
       test     eax, r13d
       jne      G_M000_IG416
       cmp      r14d, dword ptr [rdi+0x08]
       jae      G_M000_IG544
       mov      eax, r14d
       shl      rax, 4
       mov      r12, gword ptr [rdi+rax+0x10]
       test     r12, r12
       jne      G_M000_IG91
 
G_M000_IG88:                ;; offset=0x093E
       cmp      r14d, dword ptr [rdi+0x08]
       jae      G_M000_IG544
       mov      edx, r14d
       shl      rdx, 4
       lea      r12, bword ptr [rdi+rdx+0x10]
       mov      rdx, gword ptr [rbp-0x218]
       mov      rcx, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, qword ptr [rbp-0x210]
       mov      qword ptr [r12+0x08], rcx
       test     r13d, r13d
       je       G_M000_IG61
 
G_M000_IG89:                ;; offset=0x0978
       cmp      byte  ptr [rbx+0xF2], 0
       jne      G_M000_IG417
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG61
       mov      rcx, gword ptr [rbp+0xC30]
       cmp      byte  ptr [rcx+0xFF], 0
       je       G_M000_IG61
       jmp      G_M000_IG417
 
G_M000_IG90:                ;; offset=0x09AC
       lea      rbx, bword ptr [rsi+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       jmp      G_M000_IG77
 
G_M000_IG91:                ;; offset=0x09CD
       mov      rax, 0x7FF9D77E4838
       cmp      qword ptr [r12], rax
       jne      G_M000_IG88
 
G_M000_IG92:                ;; offset=0x09E1
       lea      rcx, [rbp-0x218]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77F2610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rdx, rax
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      G_M000_IG61
 
G_M000_IG93:                ;; offset=0x0A12
       cmp      ebx, 71
       je       G_M000_IG418
       cmp      ebx, 30
       jne      G_M000_IG423
       cmp      gword ptr [rbp-0x208], 0
       jne      G_M000_IG61
       jmp      G_M000_IG424
 
G_M000_IG94:                ;; offset=0x0A37
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG96
 
G_M000_IG95:                ;; offset=0x0A46
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG459
 
G_M000_IG96:                ;; offset=0x0A5A
       mov      rax, bword ptr [rbp+0xBB8]
       mov      ebx, dword ptr [rax+0x14]
 
G_M000_IG97:                ;; offset=0x0A64
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      dword ptr [rcx+0x60], ebx
       jne      G_M000_IG125
       mov      rax, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rax+0x10]
       mov      rdi, gword ptr [rcx]
       mov      rax, gword ptr [rcx+0x20]
       test     rax, rax
       je       G_M000_IG460
       lea      rdx, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
 
G_M000_IG98:                ;; offset=0x0A95
       mov      r14d, dword ptr [rcx+0x10]
       xor      r8, r8
       mov      gword ptr [rbp-0x250], r8
       test     esi, esi
       jl       G_M000_IG134
 
G_M000_IG99:                ;; offset=0x0AAB
       cmp      esi, eax
       jae      G_M000_IG544
       mov      eax, esi
       shl      rax, 4
       add      rax, rdx
       mov      rdx, gword ptr [rax]
       mov      r8, 0x2A14B001CE0
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG466
 
G_M000_IG100:                ;; offset=0x0AD2
       mov      rdx, gword ptr [rax]
       mov      r8, 0x2A14B001CE8
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG467
       cmp      qword ptr [rax+0x08], 0
       jne      G_M000_IG468
       mov      r15, gword ptr [rax]
 
G_M000_IG101:                ;; offset=0x0AF6
       cmp      esi, dword ptr [rdi+0xD8]
       jge      SHORT G_M000_IG106
 
G_M000_IG102:                ;; offset=0x0AFE
       test     r15, r15
       je       SHORT G_M000_IG105
 
G_M000_IG103:                ;; offset=0x0B03
       mov      rax, 0x7FF9D77E4838
       cmp      qword ptr [r15], rax
       jne      SHORT G_M000_IG105
 
G_M000_IG104:                ;; offset=0x0B12
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      r15, rax
 
G_M000_IG105:                ;; offset=0x0B1E
       test     r15, r15
       je       G_M000_IG469
 
G_M000_IG106:                ;; offset=0x0B27
       mov      r9, gword ptr [rbp+0xC28]
       test     r15, r15
       je       G_M000_IG470
       mov      r13, r15
 
G_M000_IG107:                ;; offset=0x0B3A
       xor      rax, rax
       mov      gword ptr [rbp-0x250], rax
       mov      rax, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rax+0x0C]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdi, gword ptr [rcx]
       mov      rax, gword ptr [rcx+0x20]
       test     rax, rax
       je       G_M000_IG471
       lea      rdx, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
 
G_M000_IG108:                ;; offset=0x0B6B
       mov      r14d, dword ptr [rcx+0x10]
       xor      r8, r8
       mov      gword ptr [rbp-0x258], r8
       test     esi, esi
       jl       G_M000_IG146
 
G_M000_IG109:                ;; offset=0x0B81
       cmp      esi, eax
       jae      G_M000_IG544
       mov      eax, esi
       shl      rax, 4
       add      rax, rdx
       mov      rdx, gword ptr [rax]
       mov      r8, 0x2A14B001CE0
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG477
 
G_M000_IG110:                ;; offset=0x0BA8
       mov      rdx, gword ptr [rax]
       mov      r8, 0x2A14B001CE8
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG478
       cmp      qword ptr [rax+0x08], 0
       jne      G_M000_IG479
       mov      r15, gword ptr [rax]
 
G_M000_IG111:                ;; offset=0x0BCC
       cmp      esi, dword ptr [rdi+0xD8]
       jge      SHORT G_M000_IG116
 
G_M000_IG112:                ;; offset=0x0BD4
       test     r15, r15
       je       SHORT G_M000_IG115
 
G_M000_IG113:                ;; offset=0x0BD9
       mov      rax, 0x7FF9D77E4838
       cmp      qword ptr [r15], rax
       jne      SHORT G_M000_IG115
 
G_M000_IG114:                ;; offset=0x0BE8
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      r15, rax
       mov      r9, gword ptr [rbp+0xC28]
 
G_M000_IG115:                ;; offset=0x0BFB
       test     r15, r15
       je       G_M000_IG480
 
G_M000_IG116:                ;; offset=0x0C04
       test     r15, r15
       je       G_M000_IG481
       mov      r12, r15
 
G_M000_IG117:                ;; offset=0x0C10
       xor      rdx, rdx
       mov      gword ptr [rbp-0x258], rdx
       mov      rax, r13
       test     rax, rax
       je       SHORT G_M000_IG119
 
G_M000_IG118:                ;; offset=0x0C21
       mov      rdx, 0x7FF9D77E3D68
       cmp      qword ptr [rax], rdx
       jne      G_M000_IG482
       xor      rax, rax
 
G_M000_IG119:                ;; offset=0x0C36
       test     rax, rax
       jne      G_M000_IG483
 
G_M000_IG120:                ;; offset=0x0C3F
       mov      r9, gword ptr [rbp+0xC28]
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       lea      edi, [rbx+0x01]
       cmp      edi, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG122
 
G_M000_IG121:                ;; offset=0x0C59
       mov      rcx, rsi
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG122:                ;; offset=0x0C64
       mov      rdx, gword ptr [rsi]
       cmp      ebx, dword ptr [rdx+0x08]
       jae      G_M000_IG544
       mov      eax, ebx
       shl      rax, 4
       lea      r14, bword ptr [rdx+rax+0x10]
       mov      rcx, r14
       mov      rdx, r13
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r14+0x08], rcx
       mov      dword ptr [rsi+0x40], edi
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       lea      edi, [rbx+0x02]
       cmp      edi, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG124
 
G_M000_IG123:                ;; offset=0x0CA2
       mov      rcx, rsi
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG124:                ;; offset=0x0CAD
       mov      rdx, gword ptr [rsi]
       lea      eax, [rbx+0x01]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG544
       inc      ebx
       mov      eax, ebx
       shl      rax, 4
       lea      rbx, bword ptr [rdx+rax+0x10]
       mov      rcx, rbx
       mov      rdx, r12
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rbx+0x08], rcx
       mov      dword ptr [rsi+0x40], edi
 
G_M000_IG125:                ;; offset=0x0CDD
       mov      r9, gword ptr [rbp+0xC28]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rcx]
       mov      rdx, gword ptr [rdx+0xB0]
       mov      r11, bword ptr [rbp+0xBB8]
       mov      r11d, dword ptr [r11+0x1C]
       cmp      r11d, 42
       jne      G_M000_IG486
 
G_M000_IG126:                ;; offset=0x0D0A
       mov      r11, bword ptr [rbp+0xBB8]
       mov      r11d, dword ptr [r11+0x08]
       mov      rax, 0x7FF9D7638680
       cmp      qword ptr [rdx], rax
       jne      G_M000_IG487
       cmp      dword ptr [rdx+0x08], r11d
       jbe      G_M000_IG302
       cmp      r11d, dword ptr [rdx+0x08]
       jae      G_M000_IG544
       mov      rbx, gword ptr [rdx+8*r11+0x10]
 
G_M000_IG127:                ;; offset=0x0D41
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG129
 
G_M000_IG128:                ;; offset=0x0D50
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG488
 
G_M000_IG129:                ;; offset=0x0D64
       mov      rax, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rax+0x14]
 
G_M000_IG130:                ;; offset=0x0D6E
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rax, bword ptr [rcx+0x20]
       cmp      byte  ptr [rbx], bl
       mov      rax, gword ptr [rax]
       cmp      byte  ptr [rbx+0x30], 0
       setne    dl
       movzx    rdx, dl
       add      edx, esi
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG544
       shl      rdx, 4
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdx, gword ptr [rax]
       mov      r8, 0x2A14B001CE0
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG489
 
G_M000_IG131:                ;; offset=0x0DB2
       mov      rdx, gword ptr [rax]
       mov      r8, 0x2A14B001CE8
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG490
       cmp      qword ptr [rax+0x08], 0
       jne      G_M000_IG491
       mov      rdi, gword ptr [rax]
 
G_M000_IG132:                ;; offset=0x0DD6
       test     rdi, rdi
       je       G_M000_IG492
       mov      dword ptr [rsp+0x20], esi
       mov      gword ptr [rsp+0x28], rdi
       lea      rdx, [rbp+0xB38]
       mov      qword ptr [rsp+0x30], rdx
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       G_M000_IG163
 
G_M000_IG133:                ;; offset=0x0E16
       cmp      gword ptr [rbp+0xB38], 0
       je       G_M000_IG02
       jmp      G_M000_IG493
 
G_M000_IG134:                ;; offset=0x0E29
       mov      r9, gword ptr [rbp+0xC28]
       not      esi
       mov      rax, gword ptr [rdi+0x30]
       cmp      dword ptr [rax+0x08], esi
       jg       G_M000_IG145
 
G_M000_IG135:                ;; offset=0x0E3F
       mov      rax, gword ptr [rdi+0x38]
       mov      rdx, gword ptr [rdi+0x30]
       mov      r8d, esi
       sub      r8d, dword ptr [rdx+0x08]
       cmp      r8d, dword ptr [rax+0x08]
       jae      G_M000_IG544
       mov      edx, r8d
       mov      r13, gword ptr [rax+8*rdx+0x10]
       mov      rax, gword ptr [rdi+0x30]
       sub      esi, dword ptr [rax+0x08]
       mov      rax, gword ptr [rdi+0x38]
       cmp      esi, dword ptr [rax+0x08]
       jae      G_M000_IG544
       mov      edx, esi
       mov      r15, gword ptr [rax+8*rdx+0x10]
       mov      rcx, r9
       call     [Lokad.Lython.Runtime.LythonRuntime:GetGlobalContext(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      r12, rax
       cmp      byte  ptr [r12+0xFE], 0
       je       G_M000_IG461
       mov      rcx, r12
 
G_M000_IG136:                ;; offset=0x0E99
       test     rcx, rcx
       je       SHORT G_M000_IG137
       mov      rdx, gword ptr [rcx+0x118]
       cmp      rdx, gword ptr [rdi+0x40]
       jne      G_M000_IG463
       mov      rdx, gword ptr [rdi+0x48]
       cmp      esi, dword ptr [rdx+0x08]
       jae      G_M000_IG544
       mov      eax, esi
       mov      edx, dword ptr [rdx+4*rax+0x10]
       test     edx, edx
       jge      G_M000_IG462
 
G_M000_IG137:                ;; offset=0x0ECA
       mov      rcx, gword ptr [r12+0x08]
       test     rcx, rcx
       je       G_M000_IG464
 
G_M000_IG138:                ;; offset=0x0ED8
       cmp      byte  ptr [rcx], cl
       mov      rdx, r15
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:FindValue(System.__Canon):byref:this]
       test     rax, rax
       jne      SHORT G_M000_IG144
 
G_M000_IG139:                ;; offset=0x0EE8
       xor      rcx, rcx
       mov      gword ptr [rbp-0x250], rcx
       mov      rcx, gword ptr [rbp+0xC28]
       mov      rdx, gword ptr [rcx+0x98]
       mov      rdx, gword ptr [rdx+0xE8]
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       mov      rdx, r15
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:FindValue(System.__Canon):byref:this]
       test     rax, rax
       jne      SHORT G_M000_IG143
 
G_M000_IG140:                ;; offset=0x0F19
       xor      rax, rax
       mov      gword ptr [rbp-0x250], rax
 
G_M000_IG141:                ;; offset=0x0F22
       test     eax, eax
       je       G_M000_IG465
 
G_M000_IG142:                ;; offset=0x0F2A
       mov      r13, gword ptr [rbp-0x250]
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG107
 
G_M000_IG143:                ;; offset=0x0F3D
       mov      rcx, gword ptr [rax]
       mov      gword ptr [rbp-0x250], rcx
       mov      eax, 1
       jmp      SHORT G_M000_IG141
 
G_M000_IG144:                ;; offset=0x0F4E
       mov      rcx, gword ptr [rax]
       mov      gword ptr [rbp-0x250], rcx
       jmp      SHORT G_M000_IG142
 
G_M000_IG145:                ;; offset=0x0F5A
       mov      rax, gword ptr [rdi+0x30]
       cmp      esi, dword ptr [rax+0x08]
       jae      G_M000_IG544
       mov      edx, esi
       mov      rcx, gword ptr [rax+8*rdx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r13, rax
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG107
 
G_M000_IG146:                ;; offset=0x0F83
       not      esi
       mov      rax, gword ptr [rdi+0x30]
       cmp      dword ptr [rax+0x08], esi
       jg       G_M000_IG157
 
G_M000_IG147:                ;; offset=0x0F92
       mov      rax, gword ptr [rdi+0x38]
       mov      rdx, gword ptr [rdi+0x30]
       mov      r8d, esi
       sub      r8d, dword ptr [rdx+0x08]
       cmp      r8d, dword ptr [rax+0x08]
       jae      G_M000_IG544
       mov      edx, r8d
       mov      r12, gword ptr [rax+8*rdx+0x10]
       mov      rax, gword ptr [rdi+0x30]
       sub      esi, dword ptr [rax+0x08]
       mov      rax, gword ptr [rdi+0x38]
       cmp      esi, dword ptr [rax+0x08]
       jae      G_M000_IG544
       mov      edx, esi
       mov      r15, gword ptr [rax+8*rdx+0x10]
       mov      rcx, r9
       call     [Lokad.Lython.Runtime.LythonRuntime:GetGlobalContext(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      gword ptr [rbp-0x2D8], rax
       cmp      byte  ptr [rax+0xFE], 0
       je       G_M000_IG472
       mov      rcx, rax
 
G_M000_IG148:                ;; offset=0x0FEE
       test     rcx, rcx
       je       SHORT G_M000_IG149
       mov      rdx, gword ptr [rcx+0x118]
       cmp      rdx, gword ptr [rdi+0x40]
       jne      G_M000_IG474
       mov      rdx, gword ptr [rdi+0x48]
       cmp      esi, dword ptr [rdx+0x08]
       jae      G_M000_IG544
       mov      r8d, esi
       mov      edx, dword ptr [rdx+4*r8+0x10]
       test     edx, edx
       jge      G_M000_IG473
 
G_M000_IG149:                ;; offset=0x1021
       mov      rax, gword ptr [rbp-0x2D8]
       mov      rcx, gword ptr [rax+0x08]
       test     rcx, rcx
       je       G_M000_IG475
 
G_M000_IG150:                ;; offset=0x1035
       cmp      byte  ptr [rcx], cl
       mov      rdx, r15
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:FindValue(System.__Canon):byref:this]
       test     rax, rax
       jne      SHORT G_M000_IG156
 
G_M000_IG151:                ;; offset=0x1045
       xor      rcx, rcx
       mov      gword ptr [rbp-0x258], rcx
       mov      rcx, gword ptr [rbp+0xC28]
       mov      rdx, gword ptr [rcx+0x98]
       mov      rdx, gword ptr [rdx+0xE8]
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       mov      rdx, r15
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:FindValue(System.__Canon):byref:this]
       test     rax, rax
       jne      SHORT G_M000_IG155
 
G_M000_IG152:                ;; offset=0x1076
       xor      rax, rax
       mov      gword ptr [rbp-0x258], rax
 
G_M000_IG153:                ;; offset=0x107F
       test     eax, eax
       je       G_M000_IG476
 
G_M000_IG154:                ;; offset=0x1087
       mov      r12, gword ptr [rbp-0x258]
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG117
 
G_M000_IG155:                ;; offset=0x109A
       mov      rcx, gword ptr [rax]
       mov      gword ptr [rbp-0x258], rcx
       mov      eax, 1
       jmp      SHORT G_M000_IG153
 
G_M000_IG156:                ;; offset=0x10AB
       mov      rcx, gword ptr [rax]
       mov      gword ptr [rbp-0x258], rcx
       jmp      SHORT G_M000_IG154
 
G_M000_IG157:                ;; offset=0x10B7
       mov      rax, gword ptr [rdi+0x30]
       cmp      esi, dword ptr [rax+0x08]
       jae      G_M000_IG544
       mov      edx, esi
       mov      rcx, gword ptr [rax+8*rdx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r12, rax
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG117
 
G_M000_IG158:                ;; offset=0x10E0
       mov      r9, gword ptr [rbp+0xC28]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG171
 
G_M000_IG159:                ;; offset=0x110D
       mov      dword ptr [rbp+0xBCC], 1
       jmp      G_M000_IG02
 
G_M000_IG160:                ;; offset=0x111C
       mov      r9, gword ptr [rbp+0xC28]
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG539
 
G_M000_IG161:                ;; offset=0x1131
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp+0xBCC], eax
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      gword ptr [rcx+0x68], 0
       je       G_M000_IG02
       jmp      G_M000_IG540
 
G_M000_IG162:                ;; offset=0x116C
       mov      r9, gword ptr [rbp+0xC28]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteBuiltinArithmetic(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG250
       jmp      G_M000_IG02
 
G_M000_IG163:                ;; offset=0x119E
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG495
       movzx    rcx, byte  ptr [rbp+0xC38]
       mov      dword ptr [rsp+0x20], ecx
       mov      r8, bword ptr [rbp+0xC50]
       mov      bword ptr [rsp+0x28], r8
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, rbx
       mov      r8d, esi
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBeginExecutableCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG167
 
G_M000_IG164:                ;; offset=0x11DD
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG505
       mov      gword ptr [rsp+0x20], rdi
       xor      edx, edx
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp+0xB18]
       mov      rcx, gword ptr [rbp+0xC30]
       mov      r8, rbx
       mov      r9d, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       mov      r14, gword ptr [rbp+0xB18]
 
G_M000_IG165:                ;; offset=0x1216
       vmovdqu  xmm0, xmmword ptr [rbp+0xB18]
       vmovdqu  xmmword ptr [rbp+0xB08], xmm0
 
G_M000_IG166:                ;; offset=0x1226
       test     r14, r14
       je       G_M000_IG02
       jmp      G_M000_IG503
 
G_M000_IG167:                ;; offset=0x1234
       mov      r8, bword ptr [rbp+0xC50]
       mov      rsi, gword ptr [r8]
       test     rsi, rsi
       jne      G_M000_IG496
 
G_M000_IG168:                ;; offset=0x1247
       mov      r8, bword ptr [rbp+0xC50]
       mov      rsi, gword ptr [r8]
       test     rsi, rsi
       jne      G_M000_IG499
       mov      rdi, gword ptr [r8+0x08]
 
G_M000_IG169:                ;; offset=0x125E
       mov      rcx, gword ptr [rbp+0xC30]
       cmp      rdi, rcx
       je       G_M000_IG502
 
G_M000_IG170:                ;; offset=0x126E
       mov      rdx, gword ptr [rbx+0x18]
       mov      rcx, bword ptr [rbp+0xC48]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp+0xB28], 3
       jmp      G_M000_IG545
 
G_M000_IG171:                ;; offset=0x128D
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xC20]
       add      rcx, 32
       lea      r8, [rbp+0xB68]
       lea      r9, [rbp+0xB58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryAdvanceNativeIteration(int,byref,byref):bool:this]
       test     eax, eax
       jne      G_M000_IG450
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG317
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG454
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNext(byref):bool:this]
       mov      dword ptr [rbp+0xBCC], eax
       jmp      G_M000_IG02
 
G_M000_IG172:                ;; offset=0x12F8
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rax+0x10]
       mov      rdi, gword ptr [rcx]
       mov      rax, gword ptr [rcx+0x20]
       test     rax, rax
       je       G_M000_IG508
       lea      rdx, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
 
G_M000_IG173:                ;; offset=0x1324
       mov      r14d, dword ptr [rcx+0x10]
       xor      r8, r8
       mov      gword ptr [rbp-0x260], r8
       test     esi, esi
       jl       G_M000_IG260
 
G_M000_IG174:                ;; offset=0x133A
       cmp      esi, eax
       jae      G_M000_IG544
       mov      eax, esi
       shl      rax, 4
       add      rax, rdx
       mov      rdx, gword ptr [rax]
       mov      r8, 0x2A14B001CE0
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG514
 
G_M000_IG175:                ;; offset=0x1361
       mov      rdx, gword ptr [rax]
       mov      r8, 0x2A14B001CE8
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG515
       cmp      qword ptr [rax+0x08], 0
       jne      G_M000_IG516
       mov      r15, gword ptr [rax]
 
G_M000_IG176:                ;; offset=0x1385
       cmp      esi, dword ptr [rdi+0xD8]
       jge      SHORT G_M000_IG181
 
G_M000_IG177:                ;; offset=0x138D
       test     r15, r15
       je       SHORT G_M000_IG180
 
G_M000_IG178:                ;; offset=0x1392
       mov      rax, 0x7FF9D77E4838
       cmp      qword ptr [r15], rax
       jne      SHORT G_M000_IG180
 
G_M000_IG179:                ;; offset=0x13A1
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      r15, rax
 
G_M000_IG180:                ;; offset=0x13AD
       test     r15, r15
       je       G_M000_IG517
 
G_M000_IG181:                ;; offset=0x13B6
       mov      r9, gword ptr [rbp+0xC28]
       test     r15, r15
       je       G_M000_IG518
       mov      r13, r15
 
G_M000_IG182:                ;; offset=0x13C9
       xor      rax, rax
       mov      gword ptr [rbp-0x260], rax
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG184
 
G_M000_IG183:                ;; offset=0x13E1
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG519
 
G_M000_IG184:                ;; offset=0x13F5
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x14]
 
G_M000_IG185:                ;; offset=0x13FF
       mov      rdx, bword ptr [rbp+0xBB8]
       cmp      dword ptr [rdx+0x18], 0
       jl       G_M000_IG272
 
G_M000_IG186:                ;; offset=0x1410
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      r10d, dword ptr [rdx+0x18]
 
G_M000_IG187:                ;; offset=0x141B
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rdx]
       mov      gword ptr [rsp+0x20], rdx
       mov      rcx, rbx
       mov      rdx, r13
       mov      r8d, eax
       mov      r9d, r10d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryPrepareNativeIteration(System.Object,int,int,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      G_M000_IG02
 
G_M000_IG188:                ;; offset=0x1444
       movzx    rax, byte  ptr [rbp+0xC38]
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG317
       test     al, al
       jne      G_M000_IG520
 
G_M000_IG189:                ;; offset=0x1461
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG02
 
G_M000_IG190:                ;; offset=0x147A
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG317
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG437
 
G_M000_IG191:                ;; offset=0x1495
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteStructure(byref):bool:this]
       mov      dword ptr [rbp+0xBCC], eax
       jmp      G_M000_IG02
 
G_M000_IG192:                ;; offset=0x14B4
       cmp      gword ptr [rbp+0xC30], 0
       jne      SHORT G_M000_IG191
       jmp      G_M000_IG317
 
G_M000_IG193:                ;; offset=0x14C3
       mov      dword ptr [rbp+0xB28], 1
       jmp      G_M000_IG545
 
G_M000_IG194:                ;; offset=0x14D2
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG196
 
G_M000_IG195:                ;; offset=0x14EC
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG429
 
G_M000_IG196:                ;; offset=0x1500
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x14]
 
G_M000_IG197:                ;; offset=0x150A
       lea      esi, [rax+0x01]
       mov      rax, bword ptr [rbp+0xBB8]
       cmp      dword ptr [rax+0x18], 0
       jl       G_M000_IG202
 
G_M000_IG198:                ;; offset=0x151E
       mov      rax, bword ptr [rbp+0xBB8]
       mov      edi, dword ptr [rax+0x18]
 
G_M000_IG199:                ;; offset=0x1528
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rax, gword ptr [rcx+0x20]
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG544
       shl      rdx, 4
       lea      rcx, bword ptr [rax+rdx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77F2610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r14, rax
       cmp      edi, dword ptr [rbx+0x40]
       jge      SHORT G_M000_IG201
 
G_M000_IG200:                ;; offset=0x1570
       mov      rcx, rbx
       mov      edx, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG201:                ;; offset=0x157B
       mov      rcx, gword ptr [rbx]
       cmp      esi, dword ptr [rcx+0x08]
       jae      G_M000_IG544
       mov      edx, esi
       shl      rdx, 4
       lea      rsi, bword ptr [rcx+rdx+0x10]
       mov      rcx, rsi
       mov      rdx, r14
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rsi+0x08], rcx
       mov      dword ptr [rbx+0x40], edi
       jmp      G_M000_IG02
 
G_M000_IG202:                ;; offset=0x15AB
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x18]
       mov      edi, eax
       not      edi
       jmp      G_M000_IG199
 
G_M000_IG203:                ;; offset=0x15BE
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG317
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rbx, gword ptr [rcx]
       mov      rsi, gword ptr [rcx+0x08]
       mov      rax, gword ptr [rcx]
       mov      rdi, gword ptr [rax+0x38]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      r15d, dword ptr [rdi+0x08]
       cmp      eax, r15d
       jae      G_M000_IG544
       mov      ecx, eax
       mov      r15, gword ptr [rdi+8*rcx+0x10]
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rdi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      r14d, dword ptr [rax+0x10]
       mov      rax, bword ptr [rbp+0xBB8]
       cmp      dword ptr [rax+0x18], 0
       jl       G_M000_IG207
 
G_M000_IG204:                ;; offset=0x1629
       mov      rax, bword ptr [rbp+0xBB8]
       mov      r13d, dword ptr [rax+0x18]
 
G_M000_IG205:                ;; offset=0x1634
       mov      rax, gword ptr [rdi]
       cmp      r14d, dword ptr [rax+0x08]
       jae      G_M000_IG544
       mov      edx, r14d
       shl      rdx, 4
       lea      rcx, bword ptr [rax+rdx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       test     rax, rax
       je       G_M000_IG428
       mov      rcx, gword ptr [rdi]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG544
       mov      edx, r14d
       shl      rdx, 4
       lea      rcx, bword ptr [rcx+rdx+0x10]
       xor      rdx, rdx
       mov      gword ptr [rcx], rdx
 
G_M000_IG206:                ;; offset=0x167A
       mov      qword ptr [rcx+0x08], rdx
       mov      dword ptr [rdi+0x40], r13d
       mov      rdx, gword ptr [rbp+0xC30]
       mov      gword ptr [rsp+0x20], rdx
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      rcx, gword ptr [rcx]
       mov      gword ptr [rsp+0x28], rcx
       mov      rcx, rbx
       mov      rdx, rsi
       mov      r8, r15
       mov      r9, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:AssignExecutableBoundName(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG02
 
G_M000_IG207:                ;; offset=0x16B4
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x18]
       mov      r13d, eax
       not      r13d
       jmp      G_M000_IG205
 
G_M000_IG208:                ;; offset=0x16C9
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rbx, gword ptr [rcx]
       mov      rsi, gword ptr [rcx+0x08]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x1C]
       cmp      eax, 2
       je       SHORT G_M000_IG210
 
G_M000_IG209:                ;; offset=0x16E6
       cmp      eax, 25
       jne      G_M000_IG319
 
G_M000_IG210:                ;; offset=0x16EF
       mov      rax, bword ptr [rbp+0xBB8]
       mov      edi, dword ptr [rax+0x08]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x10]
       mov      rdx, gword ptr [rcx]
       cmp      eax, dword ptr [rdx+0xD8]
       jl       G_M000_IG222
 
G_M000_IG211:                ;; offset=0x1712
       lea      r14, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      r15d, dword ptr [rax+0x10]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      r13d, dword ptr [rax+0x18]
       test     r13d, r13d
       jl       G_M000_IG221
 
G_M000_IG212:                ;; offset=0x1735
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x1E8], xmm0
       mov      rax, gword ptr [r14]
       cmp      r15d, dword ptr [rax+0x08]
       jae      G_M000_IG544
       mov      edx, r15d
       shl      rdx, 4
 
G_M000_IG213:                ;; offset=0x1755
       vmovdqu  xmm0, xmmword ptr [rax+rdx+0x10]
       vmovdqu  xmmword ptr [rbp-0x1E8], xmm0
 
G_M000_IG214:                ;; offset=0x1763
       cmp      gword ptr [rbp-0x1E8], 0
       je       G_M000_IG333
 
G_M000_IG215:                ;; offset=0x1771
       mov      rax, gword ptr [r14]
       cmp      r15d, dword ptr [rax+0x08]
       jae      G_M000_IG544
       mov      edx, r15d
       shl      rdx, 4
       xor      r8d, r8d
       mov      qword ptr [rax+rdx+0x10], r8
       mov      qword ptr [rax+rdx+0x18], r8
       mov      dword ptr [r14+0x40], r13d
       mov      r14, gword ptr [rbp-0x1E8]
       mov      r15, qword ptr [rbp-0x1E0]
       mov      r9, gword ptr [rbp+0xC28]
 
G_M000_IG216:                ;; offset=0x17AB
       mov      gword ptr [rbp-0x1F8], r14
       mov      qword ptr [rbp-0x1F0], r15
       mov      rdx, gword ptr [rbx+0x68]
       mov      r11, 0x7FF9D722C7D0
       cmp      qword ptr [rdx], r11
       jne      G_M000_IG334
       cmp      dword ptr [rdx+0x08], edi
       jbe      G_M000_IG302
       mov      r11d, edi
       mov      r14, gword ptr [rdx+8*r11+0x10]
 
G_M000_IG217:                ;; offset=0x17E1
       cmp      word  ptr [r14+0x0C], 60
       setne    r15b
       movzx    r15, r15b
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG335
       mov      rdx, gword ptr [rbp+0xC30]
       mov      rax, gword ptr [rdx+0x88]
 
G_M000_IG218:                ;; offset=0x180B
       test     rax, rax
       setne    al
       movzx    rax, al
       test     eax, r15d
       jne      G_M000_IG336
       cmp      edi, dword ptr [rsi+0x08]
       jae      G_M000_IG544
       mov      eax, edi
       shl      rax, 4
       mov      r13, gword ptr [rsi+rax+0x10]
       test     r13, r13
       jne      G_M000_IG247
 
G_M000_IG219:                ;; offset=0x183A
       mov      eax, edi
       shl      rax, 4
       lea      r13, bword ptr [rsi+rax+0x10]
       mov      rdx, gword ptr [rbp-0x1F8]
       mov      rcx, r13
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, qword ptr [rbp-0x1F0]
       mov      qword ptr [r13+0x08], rcx
       test     r15d, r15d
       je       G_M000_IG02
 
G_M000_IG220:                ;; offset=0x1868
       movzx    rax, byte  ptr [rbp+0xC38]
       cmp      byte  ptr [rbx+0xF2], 0
       jne      G_M000_IG337
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG02
       mov      rdx, gword ptr [rbp+0xC30]
       cmp      byte  ptr [rdx+0xFF], 0
       je       G_M000_IG02
       jmp      G_M000_IG337
 
G_M000_IG221:                ;; offset=0x18A3
       not      r13d
       jmp      G_M000_IG212
 
G_M000_IG222:                ;; offset=0x18AB
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x10]
       mov      rdx, gword ptr [rcx]
       cmp      eax, dword ptr [rdx+0xD8]
       jge      G_M000_IG320
       mov      rax, bword ptr [rbp+0xBB8]
       mov      r14d, dword ptr [rax+0x10]
       mov      r15, gword ptr [rcx]
       mov      rax, gword ptr [rcx+0x20]
       test     rax, rax
       je       G_M000_IG321
       lea      rdx, bword ptr [rax+0x10]
       mov      eax, dword ptr [rax+0x08]
 
G_M000_IG223:                ;; offset=0x18E6
       mov      r13d, dword ptr [rcx+0x10]
       xor      r8, r8
       mov      gword ptr [rbp-0x1D8], r8
       test     r14d, r14d
       jl       G_M000_IG235
 
G_M000_IG224:                ;; offset=0x18FD
       cmp      r14d, eax
       jae      G_M000_IG544
       mov      eax, r14d
       shl      rax, 4
       add      rax, rdx
       mov      rdx, gword ptr [rax]
       mov      r8, 0x2A14B001CE0
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG328
 
G_M000_IG225:                ;; offset=0x1926
       mov      rdx, gword ptr [rax]
       mov      r8, 0x2A14B001CE8
       cmp      rdx, gword ptr [r8]
       je       G_M000_IG329
       cmp      qword ptr [rax+0x08], 0
       jne      G_M000_IG330
       mov      r12, gword ptr [rax]
 
G_M000_IG226:                ;; offset=0x194A
       cmp      r14d, dword ptr [r15+0xD8]
       jge      SHORT G_M000_IG231
 
G_M000_IG227:                ;; offset=0x1953
       test     r12, r12
       je       SHORT G_M000_IG230
 
G_M000_IG228:                ;; offset=0x1958
       mov      rax, 0x7FF9D77E4838
       cmp      qword ptr [r12], rax
       jne      SHORT G_M000_IG230
 
G_M000_IG229:                ;; offset=0x1968
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      r12, rax
 
G_M000_IG230:                ;; offset=0x1974
       test     r12, r12
       je       G_M000_IG331
 
G_M000_IG231:                ;; offset=0x197D
       mov      r9, gword ptr [rbp+0xC28]
       test     r12, r12
       je       G_M000_IG332
       mov      r14, r12
 
G_M000_IG232:                ;; offset=0x1990
       xor      rdx, rdx
       mov      gword ptr [rbp-0x1D8], rdx
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rdx, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x18]
       test     eax, eax
       jl       G_M000_IG246
 
G_M000_IG233:                ;; offset=0x19B6
       mov      rcx, rdx
       mov      edx, eax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG234:                ;; offset=0x19C1
       xor      r15d, r15d
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG216
 
G_M000_IG235:                ;; offset=0x19D0
       mov      r9, gword ptr [rbp+0xC28]
       not      r14d
       mov      rax, gword ptr [r15+0x30]
       cmp      dword ptr [rax+0x08], r14d
       jg       G_M000_IG322
 
G_M000_IG236:                ;; offset=0x19E8
       mov      rdx, gword ptr [r15+0x38]
       mov      r8d, r14d
       sub      r8d, dword ptr [rax+0x08]
       mov      r10d, dword ptr [rdx+0x08]
       cmp      r8d, r10d
       jae      G_M000_IG544
       mov      r12, gword ptr [rdx+8*r8+0x10]
       sub      r14d, dword ptr [rax+0x08]
       mov      rax, gword ptr [r15+0x38]
       cmp      r14d, r10d
       jae      G_M000_IG544
       mov      edx, r14d
       mov      rax, gword ptr [rax+8*rdx+0x10]
       mov      gword ptr [rbp-0x2C8], rax
       mov      rcx, r9
       call     [Lokad.Lython.Runtime.LythonRuntime:GetGlobalContext(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      gword ptr [rbp-0x2D0], rax
       cmp      byte  ptr [rax+0xFE], 0
       je       G_M000_IG323
       mov      rcx, rax
 
G_M000_IG237:                ;; offset=0x1A45
       test     rcx, rcx
       je       SHORT G_M000_IG238
       mov      rdx, gword ptr [rcx+0x118]
       cmp      rdx, gword ptr [r15+0x40]
       jne      G_M000_IG325
       mov      rdx, gword ptr [r15+0x48]
       cmp      r14d, dword ptr [rdx+0x08]
       jae      G_M000_IG544
       mov      r8d, r14d
       mov      edx, dword ptr [rdx+4*r8+0x10]
       test     edx, edx
       jge      G_M000_IG324
 
G_M000_IG238:                ;; offset=0x1A79
       mov      rax, gword ptr [rbp-0x2D0]
       mov      rcx, gword ptr [rax+0x08]
       test     rcx, rcx
       je       G_M000_IG326
 
G_M000_IG239:                ;; offset=0x1A8D
       cmp      byte  ptr [rcx], cl
       mov      rdx, gword ptr [rbp-0x2C8]
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:FindValue(System.__Canon):byref:this]
       test     rax, rax
       jne      SHORT G_M000_IG245
 
G_M000_IG240:                ;; offset=0x1AA1
       xor      rcx, rcx
       mov      gword ptr [rbp-0x1D8], rcx
       mov      rcx, gword ptr [rbp+0xC28]
       mov      rdx, gword ptr [rcx+0x98]
       mov      rdx, gword ptr [rdx+0xE8]
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       mov      rdx, gword ptr [rbp-0x2C8]
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:FindValue(System.__Canon):byref:this]
       test     rax, rax
       jne      SHORT G_M000_IG244
 
G_M000_IG241:                ;; offset=0x1AD6
       xor      rax, rax
       mov      gword ptr [rbp-0x1D8], rax
 
G_M000_IG242:                ;; offset=0x1ADF
       test     eax, eax
       je       G_M000_IG327
 
G_M000_IG243:                ;; offset=0x1AE7
       mov      r14, gword ptr [rbp-0x1D8]
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG232
 
G_M000_IG244:                ;; offset=0x1AFA
       mov      rcx, gword ptr [rax]
       mov      gword ptr [rbp-0x1D8], rcx
       mov      eax, 1
       jmp      SHORT G_M000_IG242
 
G_M000_IG245:                ;; offset=0x1B0B
       mov      rcx, gword ptr [rax]
       mov      gword ptr [rbp-0x1D8], rcx
       jmp      SHORT G_M000_IG243
 
G_M000_IG246:                ;; offset=0x1B17
       not      eax
       jmp      G_M000_IG233
 
G_M000_IG247:                ;; offset=0x1B1E
       mov      rax, 0x7FF9D77E4838
       cmp      qword ptr [r13], rax
       jne      G_M000_IG219
 
G_M000_IG248:                ;; offset=0x1B32
       lea      rcx, [rbp-0x1F8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77F2610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rdx, rax
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      G_M000_IG02
 
G_M000_IG249:                ;; offset=0x1B63
       mov      r9, gword ptr [rbp+0xC28]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryLoadDirectCallReceiver(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG02
       jmp      G_M000_IG400
 
G_M000_IG250:                ;; offset=0x1B95
       mov      r9, gword ptr [rbp+0xC28]
       movzx    rdx, byte  ptr [rbp+0xC38]
       mov      dword ptr [rsp+0x20], edx
       mov      rax, bword ptr [rbp+0xC40]
       mov      bword ptr [rsp+0x28], rax
       mov      r10, bword ptr [rbp+0xC48]
       mov      bword ptr [rsp+0x30], r10
       mov      r8, bword ptr [rbp+0xC50]
       mov      bword ptr [rsp+0x38], r8
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInputInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref,byref):int]
       test     eax, eax
       je       G_M000_IG02
       jmp      G_M000_IG445
 
G_M000_IG251:                ;; offset=0x1BF6
       mov      r9, gword ptr [rbp+0xC28]
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG317
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG341
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG252:                ;; offset=0x1C1F
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2A0], ymm0
 
G_M000_IG253:                ;; offset=0x1C2C
       lea      r8, [rbp-0x2A0]
       lea      rdx, [rbp+0xB18]
       mov      rcx, gword ptr [rbp+0xC30]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       mov      r14, gword ptr [rbp+0xB18]
 
G_M000_IG254:                ;; offset=0x1C51
       vmovdqu  xmm0, xmmword ptr [rbp+0xB18]
       vmovdqu  xmmword ptr [rbp+0xB08], xmm0
 
G_M000_IG255:                ;; offset=0x1C61
       test     r14, r14
       je       G_M000_IG02
       jmp      G_M000_IG339
 
G_M000_IG256:                ;; offset=0x1C6F
       mov      r9, gword ptr [rbp+0xC28]
       movzx    rdx, byte  ptr [rbp+0xC38]
       mov      dword ptr [rsp+0x20], edx
       lea      rdx, [rbp+0xB90]
       mov      qword ptr [rsp+0x28], rdx
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecutePreparedOperation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG317
       cmp      byte  ptr [rbp+0xC38], 0
       jne      G_M000_IG372
       mov      r14, gword ptr [rbp+0xB90]
 
G_M000_IG257:                ;; offset=0x1CC7
       vmovdqu  xmm0, xmmword ptr [rbp+0xB90]
       vmovdqu  xmmword ptr [rbp+0xB08], xmm0
 
G_M000_IG258:                ;; offset=0x1CD7
       test     r14, r14
       je       G_M000_IG02
       jmp      G_M000_IG370
 
G_M000_IG259:                ;; offset=0x1CE5
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rbx, gword ptr [rcx]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      edx, eax
       mov      rcx, rbx
       mov      r8, bword ptr [rbp+0xBB8]
       mov      r8, gword ptr [r8]
       mov      r9, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x270], rax
       xor      r9d, r9d
       mov      qword ptr [rbp-0x268], r9
       lea      r9, [rbp-0x270]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       mov      rcx, bword ptr [rbp+0xC20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG260:                ;; offset=0x1D50
       mov      r9, gword ptr [rbp+0xC28]
       not      esi
       mov      rax, gword ptr [rdi+0x30]
       cmp      dword ptr [rax+0x08], esi
       jg       G_M000_IG271
 
G_M000_IG261:                ;; offset=0x1D66
       mov      rdx, gword ptr [rdi+0x38]
       mov      r8d, esi
       sub      r8d, dword ptr [rax+0x08]
       mov      r15d, dword ptr [rdx+0x08]
       cmp      r8d, r15d
       jae      G_M000_IG544
       mov      r13, gword ptr [rdx+8*r8+0x10]
       sub      esi, dword ptr [rax+0x08]
       mov      rax, gword ptr [rdi+0x38]
       cmp      esi, r15d
       jae      G_M000_IG544
       mov      edx, esi
       mov      r15, gword ptr [rax+8*rdx+0x10]
       mov      rcx, r9
       call     [Lokad.Lython.Runtime.LythonRuntime:GetGlobalContext(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      r12, rax
       cmp      byte  ptr [r12+0xFE], 0
       je       G_M000_IG509
       mov      rcx, r12
 
G_M000_IG262:                ;; offset=0x1DB8
       test     rcx, rcx
       je       SHORT G_M000_IG263
       mov      rdx, gword ptr [rcx+0x118]
       cmp      rdx, gword ptr [rdi+0x40]
       jne      G_M000_IG511
       mov      rdx, gword ptr [rdi+0x48]
       cmp      esi, dword ptr [rdx+0x08]
       jae      G_M000_IG544
       mov      eax, esi
       mov      edx, dword ptr [rdx+4*rax+0x10]
       test     edx, edx
       jge      G_M000_IG510
 
G_M000_IG263:                ;; offset=0x1DE9
       mov      rcx, gword ptr [r12+0x08]
       test     rcx, rcx
       je       G_M000_IG512
 
G_M000_IG264:                ;; offset=0x1DF7
       cmp      byte  ptr [rcx], cl
       mov      rdx, r15
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:FindValue(System.__Canon):byref:this]
       test     rax, rax
       jne      SHORT G_M000_IG270
 
G_M000_IG265:                ;; offset=0x1E07
       xor      rcx, rcx
       mov      gword ptr [rbp-0x260], rcx
       mov      rcx, gword ptr [rbp+0xC28]
       mov      rdx, gword ptr [rcx+0x98]
       mov      rdx, gword ptr [rdx+0xE8]
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       mov      rdx, r15
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:FindValue(System.__Canon):byref:this]
       test     rax, rax
       jne      SHORT G_M000_IG269
 
G_M000_IG266:                ;; offset=0x1E38
       xor      rax, rax
       mov      gword ptr [rbp-0x260], rax
 
G_M000_IG267:                ;; offset=0x1E41
       test     eax, eax
       je       G_M000_IG513
 
G_M000_IG268:                ;; offset=0x1E49
       mov      r13, gword ptr [rbp-0x260]
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG182
 
G_M000_IG269:                ;; offset=0x1E5C
       mov      rcx, gword ptr [rax]
       mov      gword ptr [rbp-0x260], rcx
       mov      eax, 1
       jmp      SHORT G_M000_IG267
 
G_M000_IG270:                ;; offset=0x1E6D
       mov      rcx, gword ptr [rax]
       mov      gword ptr [rbp-0x260], rcx
       jmp      SHORT G_M000_IG268
 
G_M000_IG271:                ;; offset=0x1E79
       cmp      esi, dword ptr [rax+0x08]
       jae      G_M000_IG544
       mov      edx, esi
       mov      rcx, gword ptr [rax+8*rdx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r13, rax
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG182
 
G_M000_IG272:                ;; offset=0x1E9E
       mov      r10, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [r10+0x18]
       mov      r10d, edx
       not      r10d
       jmp      G_M000_IG187
 
G_M000_IG273:                ;; offset=0x1EB4
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x60], ymm0
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
       lea      rcx, [rbp-0x60]
       mov      edx, 27
       mov      r8d, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
 
G_M000_IG274:                ;; offset=0x1ED7
       vmovdqu  ymm0, ymmword ptr [rbp-0x60]
       vmovdqu  ymmword ptr [rbp+0xA58], ymm0
       mov      rcx, qword ptr [rbp-0x40]
       mov      qword ptr [rbp+0xA78], rcx
 
G_M000_IG275:                ;; offset=0x1EEF
       mov      ecx, dword ptr [rbp+0xA68]
       cmp      ecx, dword ptr [rbp+0xA78]
       jbe      G_M000_IG541
       jmp      G_M000_IG359
 
G_M000_IG276:                ;; offset=0x1F06
       cmp      edx, 72
       je       G_M000_IG10
 
G_M000_IG277:                ;; offset=0x1F0F
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      rdx, 0x2C171C8D5F8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG278:                ;; offset=0x1F2F
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      rcx, rax
       mov      rdx, rcx
       jmp      G_M000_IG12
 
G_M000_IG279:                ;; offset=0x1F43
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      rcx, rax
       mov      rdx, rcx
       jmp      G_M000_IG12
 
G_M000_IG280:                ;; offset=0x1F57
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      rcx, rax
       mov      rdx, rcx
       jmp      G_M000_IG12
 
G_M000_IG281:                ;; offset=0x1F6B
       mov      rcx, rbx
       mov      edx, edi
       mov      r8, r14
       mov      r9, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       jmp      G_M000_IG17
 
G_M000_IG282:                ;; offset=0x1F85
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edi, eax
       jmp      G_M000_IG21
 
G_M000_IG283:                ;; offset=0x1F99
       mov      rdx, gword ptr [rsi]
       cmp      r13d, dword ptr [rdx+0x08]
       jae      G_M000_IG544
       mov      eax, r13d
       shl      rax, 4
       mov      rdx, gword ptr [rdx+rax+0x10]
       mov      rcx, 0x7FF9D77E5D30
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r15, rax
       test     r15, r15
       je       G_M000_IG33
       cmp      gword ptr [rsi+0x28], 0
       jne      SHORT G_M000_IG284
       lea      rcx, bword ptr [rsi+0x20]
       mov      rdx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      SHORT G_M000_IG285
 
G_M000_IG284:                ;; offset=0x1FE2
       mov      rcx, gword ptr [rsi+0x28]
       lea      rcx, bword ptr [rcx+0x48]
       mov      rdx, r15
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG285:                ;; offset=0x1FF2
       lea      rcx, bword ptr [rsi+0x28]
       mov      rdx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, gword ptr [rsi]
       cmp      r13d, dword ptr [rdx+0x08]
       jae      G_M000_IG544
       mov      ecx, r13d
       shl      rcx, 4
       lea      rdx, bword ptr [rdx+rcx+0x10]
       xor      rcx, rcx
       mov      gword ptr [rdx], rcx
 
G_M000_IG286:                ;; offset=0x201C
       mov      qword ptr [rdx+0x08], rcx
       jmp      G_M000_IG38
 
G_M000_IG287:                ;; offset=0x2025
       mov      r8, gword ptr [r15+0x10]
       mov      r8d, dword ptr [r8+0x08]
       mov      r10, gword ptr [rax+0x10]
       cmp      r8d, dword ptr [r10+0x08]
       jge      G_M000_IG45
       jmp      G_M000_IG44
 
G_M000_IG288:                ;; offset=0x2040
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:ReleaseStorage():this]
       jmp      G_M000_IG38
 
G_M000_IG289:                ;; offset=0x204E
       mov      rcx, rax
       mov      rax, qword ptr [rax]
       mov      rax, qword ptr [rax+0x40]
       call     [rax+0x20]Lokad.Lython.Runtime.ExecutableTemporaryValue:Dispose():this
       jmp      G_M000_IG38
 
G_M000_IG290:                ;; offset=0x2060
       mov      rax, gword ptr [r15]
       mov      gword ptr [rbp-0x2C0], rax
       mov      rdx, rax
       mov      rcx, 0x7FF9D7753360
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG291
       mov      rdx, gword ptr [rbp-0x2C0]
       mov      rcx, 0x7FF9D71528A8
       call     CORINFO_HELP_ISINSTANCEOFARRAY
       test     rax, rax
       jne      SHORT G_M000_IG291
       mov      rdx, gword ptr [rbp-0x2C0]
       mov      rcx, 0x7FF9D76608D0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       sete     cl
       movzx    rcx, cl
       test     ecx, ecx
       jne      G_M000_IG37
 
G_M000_IG291:                ;; offset=0x20C3
       mov      rax, gword ptr [r15]
       mov      gword ptr [rbp-0x2B8], rax
       xor      edx, edx
       mov      qword ptr [r15], rdx
       mov      qword ptr [r15+0x08], rdx
       mov      rdx, rax
       mov      rcx, 0x7FF9D71528A8
       call     CORINFO_HELP_ISINSTANCEOFARRAY
       test     rax, rax
       je       SHORT G_M000_IG292
       mov      ecx, dword ptr [rax+0x08]
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:RecordBytes(int):long]
       mov      rdx, rax
       mov      rcx, r12
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:Release(long):this]
       jmp      G_M000_IG38
 
G_M000_IG292:                ;; offset=0x2109
       mov      rcx, r12
       mov      rdx, gword ptr [rbp-0x2B8]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:RefundUnpublishedValue(System.Object):this]
       jmp      G_M000_IG38
 
G_M000_IG293:                ;; offset=0x2120
       mov      rax, gword ptr [r15]
       mov      rdx, 0x2A14B001CE0
       cmp      rax, gword ptr [rdx]
       je       G_M000_IG38
       mov      rax, gword ptr [r15]
       mov      rdx, 0x2A14B001CE8
       cmp      rax, gword ptr [rdx]
       je       G_M000_IG38
       xor      eax, eax
       mov      qword ptr [r15], rax
       mov      qword ptr [r15+0x08], rax
       mov      rcx, 0x7FF9D763E7B8
       call     [CORINFO_HELP_GET_NONGCSTATIC_BASE]
       mov      rdx, qword ptr [(reloc 0x7ff9d708b100)]
       mov      rcx, r12
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:Release(long):this]
       jmp      G_M000_IG38
 
G_M000_IG294:                ;; offset=0x217C
       mov      ecx, 2
       call     [System.ThrowHelper:ThrowArgumentNullException(int)]
       int3     
 
G_M000_IG295:                ;; offset=0x2188
       mov      r10d, dword ptr [r11+0x04]
       add      r10d, -24
       shr      r10d, 3
       movsxd   r15, r10d
       mov      r15d, dword ptr [r8+4*r15]
       shl      r10d, 3
       movsxd   r10, r10d
       add      r8, r10
       mov      r10d, r15d
       jmp      G_M000_IG26
 
G_M000_IG296:                ;; offset=0x21AD
       mov      rcx, r10
       call     [System.SpanHelpers:ClearWithoutReferences(byref,nuint)]
       jmp      G_M000_IG28
 
G_M000_IG297:                ;; offset=0x21BB
       cmp      dword ptr [rax+0x20], 0
       setne    al
       movzx    rax, al
       test     eax, eax
       je       G_M000_IG49
 
G_M000_IG298:                ;; offset=0x21CD
       lea      rbx, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      esi, eax
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
 
G_M000_IG299:                ;; offset=0x21F0
       vmovdqu  xmm0, xmmword ptr [rbp-0x1B0]
       vmovdqu  xmmword ptr [rbp-0x270], xmm0
 
G_M000_IG300:                ;; offset=0x2200
       mov      edx, esi
       mov      rcx, rbx
       lea      r9, [rbp-0x270]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishSlot(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG02
 
G_M000_IG301:                ;; offset=0x2217
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG52
 
G_M000_IG302:                ;; offset=0x2229
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG303:                ;; offset=0x2230
       mov      rcx, rdx
       mov      edx, edi
       mov      r11, 0x7FF9D7092998
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r14, rax
       jmp      G_M000_IG57
 
G_M000_IG304:                ;; offset=0x224A
       xor      rax, rax
       jmp      G_M000_IG58
 
G_M000_IG305:                ;; offset=0x2251
       lea      rcx, [rbp-0x1C0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77F2610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r8, rax
       mov      rdx, r14
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreGlobalNamespaceName(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.String,System.Object)]
       jmp      G_M000_IG61
 
G_M000_IG306:                ;; offset=0x2289
       mov      rdx, gword ptr [rbp+0xC30]
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.ExecutionFrame:get_Variables():System.Collections.Generic.Dictionary`2[System.String,System.Object]:this]
       mov      rbx, rax
       mov      ecx, edi
       shl      rcx, 4
       lea      rcx, bword ptr [rsi+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77F2610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r8, rax
       cmp      byte  ptr [rbx], bl
       mov      rcx, rbx
       mov      rdx, r14
       mov      r9d, 1
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:TryInsert(System.__Canon,System.__Canon,byte):bool:this]
       jmp      G_M000_IG61
 
G_M000_IG307:                ;; offset=0x22DE
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       jne      SHORT G_M000_IG308
       xor      rax, rax
       xor      r8d, r8d
       jmp      SHORT G_M000_IG309
 
G_M000_IG308:                ;; offset=0x22EE
       lea      rax, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
 
G_M000_IG309:                ;; offset=0x22F6
       mov      bword ptr [rbp-0x280], rax
       mov      dword ptr [rbp-0x278], r8d
 
G_M000_IG310:                ;; offset=0x2304
       vmovdqu  xmm0, xmmword ptr [rbp-0x1B0]
       vmovdqu  xmmword ptr [rbp-0x270], xmm0
 
G_M000_IG311:                ;; offset=0x2314
       lea      rcx, [rbp-0x280]
       lea      r8, [rbp-0x270]
       mov      rbx, bword ptr [rbp+0xC20]
       mov      r9, gword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG61
 
G_M000_IG312:                ;; offset=0x2338
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x2C171C92BE0
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG313:                ;; offset=0x2366
       lea      rcx, [rbp-0x1B0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77F2610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       jmp      G_M000_IG61
 
G_M000_IG314:                ;; offset=0x238B
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rbx, gword ptr [rcx+0x08]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG544
       mov      ecx, eax
       shl      rcx, 4
       cmp      gword ptr [rbx+rcx+0x10], 0
       jne      G_M000_IG02
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rcx]
       mov      rbx, gword ptr [rdx+0x68]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      edx, eax
       mov      rcx, rbx
       mov      r11, 0x7FF9D7092980
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rcx, rax
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rdx]
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG315:                ;; offset=0x2407
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      gword ptr [rcx+0x40], 0
       jne      SHORT G_M000_IG316
       mov      r9, gword ptr [rbp+0xC28]
       mov      gword ptr [rsp+0x20], r9
       mov      rcx, gword ptr [rcx]
       mov      rbx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbx+0x18]
       mov      r8d, dword ptr [rbx+0x10]
       mov      r9d, dword ptr [rbx+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       je       SHORT G_M000_IG316
       add      dword ptr [rbx+0x10], 2
       jmp      G_M000_IG02
 
G_M000_IG316:                ;; offset=0x244A
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      r8d, eax
       lea      r9, [rbp+0xBB0]
       mov      qword ptr [rsp+0x20], r9
       mov      r9, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [r9]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      rcx, bword ptr [rbp+0xC20]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryLoadClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG318
 
G_M000_IG317:                ;; offset=0x2488
       mov      dword ptr [rbp+0xB28], 6
       jmp      G_M000_IG545
 
G_M000_IG318:                ;; offset=0x2497
       mov      rdx, gword ptr [rbp+0xBB0]
       lea      rcx, [rbp-0x1D0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x1D0]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG319:                ;; offset=0x24D2
       cmp      eax, 72
       je       G_M000_IG210
       jmp      G_M000_IG277
 
G_M000_IG320:                ;; offset=0x24E0
       lea      r14, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      r15d, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
       mov      edx, r15d
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      r14, rax
       jmp      G_M000_IG234
 
G_M000_IG321:                ;; offset=0x2513
       xor      rdx, rdx
       xor      eax, eax
       jmp      G_M000_IG223
 
G_M000_IG322:                ;; offset=0x251C
       cmp      r14d, dword ptr [rax+0x08]
       jae      G_M000_IG544
       mov      edx, r14d
       mov      rcx, gword ptr [rax+8*rdx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r14, rax
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG232
 
G_M000_IG323:                ;; offset=0x2543
       xor      rcx, rcx
       jmp      G_M000_IG237
 
G_M000_IG324:                ;; offset=0x254A
       mov      rcx, gword ptr [rcx+0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadLocalValue(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int):System.Object]
       test     rax, rax
       je       G_M000_IG238
       mov      gword ptr [rbp-0x1D8], rax
       jmp      G_M000_IG243
 
G_M000_IG325:                ;; offset=0x256C
       lea      r8, [rbp-0x1D8]
       mov      rdx, gword ptr [rbp-0x2C8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryResolveLocalOrClosure(System.String,byref):bool:this]
       test     eax, eax
       je       G_M000_IG238
       jmp      G_M000_IG243
 
G_M000_IG326:                ;; offset=0x258D
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.ExecutionFrame:InitializeVariables():System.Collections.Generic.Dictionary`2[System.String,System.Object]:this]
       mov      rcx, rax
       jmp      G_M000_IG239
 
G_M000_IG327:                ;; offset=0x259E
       mov      rcx, r15
       mov      edx, r13d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.RuntimeErrors:NameNotDefined(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG328:                ;; offset=0x25C2
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r12, rax
       jmp      G_M000_IG226
 
G_M000_IG329:                ;; offset=0x25D3
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r12, rax
       jmp      G_M000_IG226
 
G_M000_IG330:                ;; offset=0x25E4
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r12, rax
       jmp      G_M000_IG226
 
G_M000_IG331:                ;; offset=0x25F5
       mov      rcx, r15
       mov      edx, r13d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      edx, r14d
       mov      rcx, r15
       mov      r9, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r14, rax
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG232
 
G_M000_IG332:                ;; offset=0x2629
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rcx, r15
       mov      rdx, 0x2C171C8AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, r15
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG333:                ;; offset=0x2657
       lea      rcx, [rbp-0x1E8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77F2610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       jmp      G_M000_IG215
 
G_M000_IG334:                ;; offset=0x267C
       mov      rcx, rdx
       mov      edx, edi
       mov      r11, 0x7FF9D70929A0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r14, rax
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG217
 
G_M000_IG335:                ;; offset=0x269D
       xor      rax, rax
       jmp      G_M000_IG218
 
G_M000_IG336:                ;; offset=0x26A4
       lea      rcx, [rbp-0x1F8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77F2610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r8, rax
       mov      rdx, r14
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreGlobalNamespaceName(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.String,System.Object)]
       jmp      G_M000_IG02
 
G_M000_IG337:                ;; offset=0x26DC
       mov      rdx, gword ptr [rbp+0xC30]
       cmp      byte  ptr [rdx], dl
       mov      rcx, rdx
       call     [Lokad.Lython.Runtime.ExecutionFrame:get_Variables():System.Collections.Generic.Dictionary`2[System.String,System.Object]:this]
       mov      rbx, rax
       mov      ecx, edi
       shl      rcx, 4
       lea      rcx, bword ptr [rsi+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77F2610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r8, rax
       cmp      byte  ptr [rbx], bl
       mov      rcx, rbx
       mov      rdx, r14
       mov      r9d, 1
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:TryInsert(System.__Canon,System.__Canon,byte):bool:this]
       jmp      G_M000_IG02
 
G_M000_IG338:                ;; offset=0x2731
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryStoreClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG02
       jmp      G_M000_IG317
 
G_M000_IG339:                ;; offset=0x2759
       mov      rdx, r14
       mov      rcx, 0x7FF9D74847C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG340
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG02
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG02
 
G_M000_IG340:                ;; offset=0x2795
       mov      rcx, r14
       movsx    rdx, word  ptr [rbp+0xB10]
       mov      r11, 0x7FF9D70929A8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG02
 
G_M000_IG341:                ;; offset=0x27B2
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG342:                ;; offset=0x27B9
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2A0], ymm0
 
G_M000_IG343:                ;; offset=0x27C6
       lea      r8, [rbp-0x2A0]
       lea      rdx, [rbp-0x160]
       mov      rcx, gword ptr [rbp+0xC30]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x170]
       lea      rdx, [rbp-0x160]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0xC40]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0x170]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x168]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       SHORT G_M000_IG347
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG344
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG345
 
G_M000_IG344:                ;; offset=0x2856
       mov      rax, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70929B0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG345:                ;; offset=0x287C
       test     esi, esi
       jne      SHORT G_M000_IG347
 
G_M000_IG346:                ;; offset=0x2880
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rcx]
       mov      rcx, bword ptr [rbp+0xC48]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp+0xB28], 4
       jmp      G_M000_IG545
 
G_M000_IG347:                ;; offset=0x28A5
       mov      rax, bword ptr [rbp+0xC40]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG02
 
G_M000_IG348:                ;; offset=0x28BA
       mov      rax, gword ptr [rbp+0xC30]
       mov      r10, rax
       test     r10, r10
       jne      SHORT G_M000_IG349
       mov      r9, gword ptr [rbp+0xC28]
       mov      r10, r9
 
G_M000_IG349:                ;; offset=0x28D3
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, rax
       mov      r8, bword ptr [rbp+0xBB8]
       mov      r9, r10
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteFormattedInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      G_M000_IG02
       movzx    rax, byte  ptr [rbp+0xC38]
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG317
       test     al, al
       jne      G_M000_IG353
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG350:                ;; offset=0x2919
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2A0], ymm0
 
G_M000_IG351:                ;; offset=0x2926
       lea      r8, [rbp-0x2A0]
       lea      rdx, [rbp+0xB18]
       mov      rcx, gword ptr [rbp+0xC30]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp+0xB18]
       lea      rdx, [rbp+0xB08]
       call     [System.Threading.Tasks.ValueTask:GetAwaiter():System.Runtime.CompilerServices.ValueTaskAwaiter:this]
       mov      rbx, gword ptr [rbp+0xB08]
       test     rbx, rbx
       je       G_M000_IG02
       mov      rdx, rbx
       mov      rcx, 0x7FF9D74847C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG352
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG02
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG02
 
G_M000_IG352:                ;; offset=0x29A4
       mov      rcx, rbx
       movsx    rdx, word  ptr [rbp+0xB10]
       mov      r11, 0x7FF9D70929B8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG02
 
G_M000_IG353:                ;; offset=0x29C1
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG354:                ;; offset=0x29C8
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2A0], ymm0
 
G_M000_IG355:                ;; offset=0x29D5
       lea      r8, [rbp-0x2A0]
       lea      rdx, [rbp-0x80]
       mov      rcx, gword ptr [rbp+0xC30]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x90]
       lea      rdx, [rbp-0x80]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, rcx
       mov      rdx, gword ptr [rbp-0x90]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x88]
       mov      qword ptr [rbx+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [rcx]
       test     rbx, rbx
       je       G_M000_IG347
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG356
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG357
 
G_M000_IG356:                ;; offset=0x2A63
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70929C0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG357:                ;; offset=0x2A89
       test     esi, esi
       jne      G_M000_IG347
       jmp      G_M000_IG346
 
G_M000_IG358:                ;; offset=0x2A96
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rax, gword ptr [rcx]
       mov      rbx, gword ptr [rax+0x30]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG544
       mov      edx, eax
       mov      rdx, gword ptr [rbx+8*rdx+0x10]
       mov      rcx, 0x7FF9D758EAB0
       call     CORINFO_HELP_CHKCASTCLASS
       mov      rbx, rax
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rsi, gword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      edi, eax
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r14d, eax
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       sub      r14d, eax
       test     rsi, rsi
       jne      SHORT G_M000_IG361
       or       edi, r14d
       je       SHORT G_M000_IG360
 
G_M000_IG359:                ;; offset=0x2B17
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG360:                ;; offset=0x2B1E
       xor      rdx, rdx
       xor      ecx, ecx
       jmp      SHORT G_M000_IG362
 
G_M000_IG361:                ;; offset=0x2B24
       mov      edx, edi
       mov      ecx, r14d
       add      rdx, rcx
       mov      ecx, dword ptr [rsi+0x08]
       cmp      rdx, rcx
       ja       SHORT G_M000_IG359
       mov      edx, edi
       shl      rdx, 4
       lea      rdx, bword ptr [rsi+rdx+0x10]
       mov      ecx, r14d
 
G_M000_IG362:                ;; offset=0x2B42
       mov      r8, bword ptr [rbp+0xBB8]
       cmp      dword ptr [r8+0x0C], 0
       setne    r8b
       movzx    r8, r8b
       mov      rax, gword ptr [rbp+0xC30]
       mov      r9, rax
       test     r9, r9
       mov      r10, r9
       jne      SHORT G_M000_IG363
       mov      r9, gword ptr [rbp+0xC28]
       mov      r10, r9
 
G_M000_IG363:                ;; offset=0x2B72
       mov      bword ptr [rbp-0x280], rdx
       mov      dword ptr [rbp-0x278], ecx
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rdx]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0x280]
       mov      rcx, rbx
       mov      r9, r10
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      dword ptr [rcx+0x60], eax
       jmp      G_M000_IG02
 
G_M000_IG364:                ;; offset=0x2BBD
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      esi, eax
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r9d, eax
       mov      r8d, esi
       mov      rcx, rbx
       lea      rdx, [rbp+0xBA0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       jne      SHORT G_M000_IG365
       xor      r9, r9
       xor      r8d, r8d
       jmp      SHORT G_M000_IG366
 
G_M000_IG365:                ;; offset=0x2C12
       lea      r9, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
 
G_M000_IG366:                ;; offset=0x2C1A
       mov      rdx, gword ptr [rbp+0xC30]
       mov      rax, rdx
       test     rax, rax
       jne      SHORT G_M000_IG367
       mov      r10, gword ptr [rbp+0xC28]
       mov      rax, r10
 
G_M000_IG367:                ;; offset=0x2C33
       mov      bword ptr [rbp-0x280], r9
       mov      dword ptr [rbp-0x278], r8d
 
G_M000_IG368:                ;; offset=0x2C41
       vmovdqu  xmm0, xmmword ptr [rbp+0xBA0]
       vmovdqu  xmmword ptr [rbp-0x270], xmm0
 
G_M000_IG369:                ;; offset=0x2C51
       lea      rcx, [rbp-0x280]
       lea      r8, [rbp-0x270]
       mov      r9, gword ptr [rax+0x98]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG02
 
G_M000_IG370:                ;; offset=0x2C78
       mov      rdx, r14
       mov      rcx, 0x7FF9D74847C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG371
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG02
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG02
 
G_M000_IG371:                ;; offset=0x2CB4
       mov      rcx, r14
       movsx    rdx, word  ptr [rbp+0xB10]
       mov      r11, 0x7FF9D70929C8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG02
 
G_M000_IG372:                ;; offset=0x2CD1
       vmovdqu  xmm0, xmmword ptr [rbp+0xB90]
       vmovdqu  xmmword ptr [rbp-0x2B0], xmm0
 
G_M000_IG373:                ;; offset=0x2CE1
       lea      rdx, [rbp-0x2B0]
       lea      rcx, [rbp-0x180]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0xC40]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0x180]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x178]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       G_M000_IG347
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG374
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG375
 
G_M000_IG374:                ;; offset=0x2D54
       mov      rax, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70929D0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG375:                ;; offset=0x2D7A
       test     esi, esi
       jne      G_M000_IG347
       jmp      G_M000_IG346
 
G_M000_IG376:                ;; offset=0x2D87
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG317
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rsi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      edi, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      r9d, eax
       mov      r8d, edi
       mov      rcx, rsi
       lea      rdx, [rbp+0xAF8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      esi, dword ptr [rcx+0x10]
       inc      esi
       mov      rax, gword ptr [rbp+0xC30]
       mov      rdi, gword ptr [rax+0x70]
       cmp      byte  ptr [rax+0x101], 0
       jne      SHORT G_M000_IG377
       cmp      byte  ptr [rax+0xFF], 0
       jne      SHORT G_M000_IG377
       cmp      ebx, esi
       jle      SHORT G_M000_IG377
       cmp      esi, ebx
       jae      G_M000_IG544
       mov      r8, gword ptr [rbp+0xBD0]
       mov      edx, esi
       shl      rdx, 5
       cmp      dword ptr [r8+rdx+0x2C], 30
       sete     r14b
       movzx    r14, r14b
       jmp      SHORT G_M000_IG378
 
G_M000_IG377:                ;; offset=0x2E1F
       xor      r14d, r14d
 
G_M000_IG378:                ;; offset=0x2E22
       test     r14d, r14d
       je       G_M000_IG384
       test     rdi, rdi
       je       G_M000_IG384
 
G_M000_IG379:                ;; offset=0x2E34
       vmovdqu  xmm0, xmmword ptr [rbp+0xAF8]
       vmovdqu  xmmword ptr [rbp-0x270], xmm0
 
G_M000_IG380:                ;; offset=0x2E44
       lea      r8, [rbp-0x270]
       mov      rdx, rdi
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryAppendBufferedYield(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):bool:this]
       test     eax, eax
       je       G_M000_IG384
       cmp      esi, ebx
       jae      G_M000_IG544
       mov      rcx, gword ptr [rbp+0xBD0]
       mov      eax, esi
       shl      rax, 5
       mov      r14, gword ptr [rcx+rax+0x10]
       mov      r9, gword ptr [rbp+0xC28]
       mov      rdi, gword ptr [r9+0x98]
       cmp      byte  ptr [rdi], dil
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG381
       mov      rcx, rdi
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG381:                ;; offset=0x2EA3
       mov      r9, gword ptr [rbp+0xC28]
       mov      rbx, gword ptr [r9+0x98]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_HasActiveHandler():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG382
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, gword ptr [rcx+0x80]
       jmp      SHORT G_M000_IG383
 
G_M000_IG382:                ;; offset=0x2ED2
       mov      r9, gword ptr [rbp+0xC28]
       mov      rdx, gword ptr [r9+0x98]
       mov      rdx, gword ptr [rdx+0x148]
 
G_M000_IG383:                ;; offset=0x2EE7
       lea      rcx, bword ptr [rbx+0x148]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rax, gword ptr [rbp+0xBD0]
       mov      edx, esi
       shl      rdx, 5
       lea      rcx, bword ptr [rax+rdx+0x10]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp+0xC20]
       add      dword ptr [rcx+0x10], 2
       jmp      G_M000_IG551
 
G_M000_IG384:                ;; offset=0x2F31
       mov      rax, gword ptr [rbp+0xC30]
       lea      rbx, bword ptr [rax+0x190]
       mov      rdx, gword ptr [rbp+0xAF8]
       mov      rcx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, qword ptr [rbp+0xB00]
       mov      qword ptr [rbx+0x08], rcx
       mov      rax, gword ptr [rbp+0xC30]
       mov      word  ptr [rax+0xF8], 257
       mov      rcx, bword ptr [rbp+0xC20]
       inc      dword ptr [rcx+0x10]
       test     r14d, r14d
       jne      G_M000_IG193
       test     rdi, rdi
       je       G_M000_IG193
       mov      rcx, rax
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG193
       jmp      G_M000_IG551
 
G_M000_IG385:                ;; offset=0x2F9E
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG317
       cmp      byte  ptr [rbp+0xC38], 0
       je       G_M000_IG391
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG386:                ;; offset=0x2FC0
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2A0], ymm0
 
G_M000_IG387:                ;; offset=0x2FCD
       lea      r8, [rbp-0x2A0]
       lea      rdx, [rbp-0xB0]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteDelegationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, rcx
       mov      rdx, gword ptr [rbp-0xB0]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xA8]
       mov      qword ptr [rbx+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [rcx]
       test     rbx, rbx
       je       SHORT G_M000_IG390
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG388
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG389
 
G_M000_IG388:                ;; offset=0x3043
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70929D8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG389:                ;; offset=0x3069
       test     esi, esi
       je       G_M000_IG346
 
G_M000_IG390:                ;; offset=0x3071
       mov      rcx, bword ptr [rbp+0xC40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG395
 
G_M000_IG391:                ;; offset=0x3083
       mov      rax, gword ptr [rbp+0xC30]
       cmp      gword ptr [rax+0x68], 0
       jne      G_M000_IG392
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      r8d, eax
       mov      edx, esi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      rbx, rax
       mov      rcx, 0x7FF9D71528A8
       mov      edx, 1
       call     CORINFO_HELP_NEWARR_1_PTR
       mov      rsi, rax
       lea      rcx, bword ptr [rsi+0x10]
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rdx]
       mov      rcx, rsi
       mov      r8, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:Iter(System.Object[],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rbx, rax
       mov      rcx, 0x7FF9D77E7DB8
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       mov      r9, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [r9]
       mov      rcx, rsi
       mov      rdx, rbx
       mov      r8, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:.ctor(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):this]
       mov      rax, gword ptr [rbp+0xC30]
       lea      rcx, bword ptr [rax+0x68]
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG392:                ;; offset=0x314A
       mov      rax, gword ptr [rbp+0xC30]
       mov      rcx, gword ptr [rax+0x68]
       mov      r8, gword ptr [rax+0x58]
       mov      r9, gword ptr [rax+0x60]
       lea      rdx, [rbp-0xA0]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:Advance(System.Object,Lokad.Lython.Runtime.LythonRuntimeException):Lokad.Lython.Runtime.PyIterationResult:this]
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG393:                ;; offset=0x3173
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2A0], ymm0
 
G_M000_IG394:                ;; offset=0x3180
       lea      r8, [rbp-0x2A0]
       lea      rdx, [rbp-0xA0]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteDelegatedStep(Lokad.Lython.Runtime.PyIterationResult,Lokad.Lython.Frontend.ExecutableInstruction):this]
 
G_M000_IG395:                ;; offset=0x319B
       mov      rcx, gword ptr [rbp+0xC30]
       cmp      byte  ptr [rcx+0xF9], 0
       je       G_M000_IG02
       movzx    rax, byte  ptr [rbp+0xC38]
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, gword ptr [rcx+0x70]
       test     rdx, rdx
       je       G_M000_IG193
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG193
       jmp      G_M000_IG551
 
G_M000_IG396:                ;; offset=0x31DD
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG317
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rcx]
       mov      rbx, gword ptr [rdx+0xA8]
       mov      rcx, bword ptr [rbp+0xBB8]
       xor      edx, edx
       mov      r8, 0x2C171C94708
       call     [Lokad.Lython.Frontend.ExecutableInstruction:ReadPrimaryOperand(int,System.String):int:this]
       mov      edx, eax
       mov      rcx, rbx
       mov      r11, 0x7FF9D7092990
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       cmp      byte  ptr [rbp+0xC38], 0
       jne      SHORT G_M000_IG397
       mov      rsi, bword ptr [rbp+0xC20]
       mov      rcx, gword ptr [rsi]
       mov      r8, gword ptr [rsi+0x08]
       mov      rdx, rax
       mov      r9, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteExecutableImport(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext)]
       jmp      G_M000_IG02
 
G_M000_IG397:                ;; offset=0x3253
       lea      rcx, [rbp-0x190]
       mov      rdx, rax
       mov      r8, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteImportAsync(Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Threading.Tasks.ValueTask]
       lea      rcx, [rbp-0x1A0]
       lea      rdx, [rbp-0x190]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0xC40]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0x1A0]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x198]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       G_M000_IG347
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG398
       test     dword ptr [rax+0x34], 0x1600000
       setne    dil
       movzx    rdi, dil
       jmp      SHORT G_M000_IG399
 
G_M000_IG398:                ;; offset=0x32DD
       mov      rax, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70929E0
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    dil
       movzx    rdi, dil
 
G_M000_IG399:                ;; offset=0x3303
       test     edi, edi
       jne      G_M000_IG347
       jmp      G_M000_IG346
 
G_M000_IG400:                ;; offset=0x3310
       movzx    rax, byte  ptr [rbp+0xC38]
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG317
       test     al, al
       jne      SHORT G_M000_IG401
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSynchronousMemberLoad(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG02
 
G_M000_IG401:                ;; offset=0x3350
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG402:                ;; offset=0x3357
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2A0], ymm0
 
G_M000_IG403:                ;; offset=0x3364
       lea      r8, [rbp-0x2A0]
       lea      rdx, [rbp-0x150]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteMemberLoadAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, rcx
       mov      rdx, gword ptr [rbp-0x150]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x148]
       mov      qword ptr [rbx+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [rcx]
       test     rbx, rbx
       je       G_M000_IG347
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG404
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG405
 
G_M000_IG404:                ;; offset=0x33DE
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70929E8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG405:                ;; offset=0x3404
       test     esi, esi
       jne      G_M000_IG347
       jmp      G_M000_IG346
 
G_M000_IG406:                ;; offset=0x3411
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      rdx, 0x2C171C8D648
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG407:                ;; offset=0x3431
       cmp      edx, 64
       je       G_M000_IG67
       cmp      edx, 67
       je       G_M000_IG67
       cmp      edx, 70
       jne      SHORT G_M000_IG406
       jmp      G_M000_IG67
 
G_M000_IG408:                ;; offset=0x344D
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r14d, eax
       jmp      G_M000_IG71
 
G_M000_IG409:                ;; offset=0x3462
       cmp      dword ptr [rcx+0x20], 0
       setne    cl
       movzx    rcx, cl
       test     ecx, ecx
       je       G_M000_IG78
 
G_M000_IG410:                ;; offset=0x3474
       lea      rbx, bword ptr [rsi+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      edi, eax
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
 
G_M000_IG411:                ;; offset=0x3497
       vmovdqu  xmm0, xmmword ptr [rbp-0x208]
       vmovdqu  xmmword ptr [rbp-0x270], xmm0
 
G_M000_IG412:                ;; offset=0x34A7
       mov      edx, edi
       mov      rcx, rbx
       lea      r9, [rbp-0x270]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishSlot(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG02
 
G_M000_IG413:                ;; offset=0x34BE
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG81
 
G_M000_IG414:                ;; offset=0x34D0
       mov      edx, r14d
       mov      r11, 0x7FF9D70929F0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r15, rax
       jmp      G_M000_IG86
 
G_M000_IG415:                ;; offset=0x34E8
       xor      rax, rax
       jmp      G_M000_IG87
 
G_M000_IG416:                ;; offset=0x34EF
       lea      rcx, [rbp-0x218]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77F2610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r8, rax
       mov      rdx, r15
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreGlobalNamespaceName(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.String,System.Object)]
       jmp      G_M000_IG61
 
G_M000_IG417:                ;; offset=0x3527
       mov      rcx, gword ptr [rbp+0xC30]
       cmp      byte  ptr [rcx], cl
       call     [Lokad.Lython.Runtime.ExecutionFrame:get_Variables():System.Collections.Generic.Dictionary`2[System.String,System.Object]:this]
       mov      rbx, rax
       cmp      r14d, dword ptr [rdi+0x08]
       jae      G_M000_IG544
       mov      ecx, r14d
       shl      rcx, 4
       lea      rcx, bword ptr [rdi+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77F2610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r8, rax
       cmp      byte  ptr [rbx], bl
       mov      rcx, rbx
       mov      rdx, r15
       mov      r9d, 1
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:TryInsert(System.__Canon,System.__Canon,byte):bool:this]
       jmp      G_M000_IG61
 
G_M000_IG418:                ;; offset=0x3584
       mov      rcx, gword ptr [rsi+0x20]
       test     rcx, rcx
       jne      SHORT G_M000_IG419
       xor      r8, r8
       xor      ecx, ecx
       jmp      SHORT G_M000_IG420
 
G_M000_IG419:                ;; offset=0x3594
       lea      r8, bword ptr [rcx+0x10]
       mov      ecx, dword ptr [rcx+0x08]
 
G_M000_IG420:                ;; offset=0x359B
       mov      bword ptr [rbp-0x280], r8
       mov      dword ptr [rbp-0x278], ecx
 
G_M000_IG421:                ;; offset=0x35A8
       vmovdqu  xmm0, xmmword ptr [rbp-0x208]
       vmovdqu  xmmword ptr [rbp-0x270], xmm0
 
G_M000_IG422:                ;; offset=0x35B8
       lea      rcx, [rbp-0x280]
       lea      r8, [rbp-0x270]
       mov      r9, gword ptr [rsi+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG61
 
G_M000_IG423:                ;; offset=0x35D5
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x2C171C92BE0
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG424:                ;; offset=0x3603
       lea      rcx, [rbp-0x208]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77F2610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       jmp      G_M000_IG61
 
G_M000_IG425:                ;; offset=0x3628
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG317
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rax, gword ptr [rcx]
       mov      rbx, gword ptr [rax+0x38]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      r10d, dword ptr [rbx+0x08]
       cmp      eax, r10d
       jae      G_M000_IG544
       mov      ecx, eax
       mov      rcx, gword ptr [rbx+8*rcx+0x10]
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rdx]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveName(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      rdx, rax
       lea      rcx, [rbp-0x228]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x228]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG426:                ;; offset=0x36B9
       mov      r9, gword ptr [rbp+0xC28]
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG317
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      rdx, gword ptr [rdx]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:PreloadImplicitSuperArguments(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG02
 
G_M000_IG427:                ;; offset=0x36EA
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG317
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rax, gword ptr [rcx]
       mov      rbx, gword ptr [rax+0x38]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      r15d, dword ptr [rbx+0x08]
       cmp      eax, r15d
       jae      G_M000_IG544
       mov      ecx, eax
       mov      r15, gword ptr [rbx+8*rcx+0x10]
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
       mov      edx, esi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      rdx, rax
       mov      rcx, r15
       mov      r9, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [r9]
       mov      r8, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreName(System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG02
 
G_M000_IG428:                ;; offset=0x3779
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x2C171C8AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG429:                ;; offset=0x37A7
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG197
 
G_M000_IG430:                ;; offset=0x37B9
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xC20]
       add      rcx, 32
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       jmp      G_M000_IG02
 
G_M000_IG431:                ;; offset=0x37FC
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rax+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      r8d, eax
       mov      r9, gword ptr [rbp+0xC28]
       mov      gword ptr [rsp+0x20], r9
       mov      edx, esi
       mov      rcx, rbx
       mov      rax, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateListFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      rdx, rax
       lea      rcx, [rbp-0x238]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x238]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG432:                ;; offset=0x3879
       cmp      gword ptr [rbp+0xC30], 0
       je       SHORT G_M000_IG433
       mov      rcx, gword ptr [rbp+0xC30]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryStageUnpackedFrameReturn(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG193
 
G_M000_IG433:                ;; offset=0x389F
       mov      rax, bword ptr [rbp+0xC58]
       cmp      dword ptr [rax+0x08], 0
       je       SHORT G_M000_IG436
       mov      r8d, dword ptr [rax+0x08]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CanForwardFixedReturn(byref,byref,int):bool]
       test     eax, eax
       je       SHORT G_M000_IG436
 
G_M000_IG434:                ;; offset=0x38C8
       mov      rax, bword ptr [rbp+0xC58]
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x280], xmm0
 
G_M000_IG435:                ;; offset=0x38DB
       lea      r9, [rbp-0x280]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, bword ptr [rbp+0xBB8]
       mov      rcx, bword ptr [rbp+0xC20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CopyFixedReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       mov      dword ptr [rbp+0xB28], 2
       jmp      G_M000_IG545
 
G_M000_IG436:                ;; offset=0x390C
       mov      rcx, bword ptr [rbp+0xC20]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      esi, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      r8d, eax
       mov      r9, gword ptr [rbp+0xC28]
       mov      gword ptr [rsp+0x20], r9
       mov      edx, esi
       mov      rcx, rbx
       mov      rax, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [rax]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTupleFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyTuple]
       mov      rdx, rax
       lea      rcx, [rbp-0x248]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x248]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG437:                ;; offset=0x3989
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG438:                ;; offset=0x3990
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2A0], ymm0
 
G_M000_IG439:                ;; offset=0x399D
       lea      r8, [rbp-0x2A0]
       lea      rdx, [rbp-0x140]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteContextManagerAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, r10
       mov      rdx, gword ptr [rbp-0x140]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x138]
       mov      qword ptr [rbx+0x08], rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       SHORT G_M000_IG442
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG440
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG441
 
G_M000_IG440:                ;; offset=0x3A13
       mov      r10, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D70929F8
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG441:                ;; offset=0x3A39
       test     esi, esi
       je       G_M000_IG346
 
G_M000_IG442:                ;; offset=0x3A41
       mov      r10, bword ptr [rbp+0xC40]
       mov      rcx, r10
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp+0xBCC], eax
       jmp      G_M000_IG02
 
G_M000_IG443:                ;; offset=0x3A5C
       mov      r9, gword ptr [rbp+0xC28]
       movzx    rdx, byte  ptr [rbp+0xC38]
       mov      dword ptr [rsp+0x20], edx
       mov      rax, bword ptr [rbp+0xC40]
       mov      bword ptr [rsp+0x28], rax
       mov      r10, bword ptr [rbp+0xC48]
       mov      bword ptr [rsp+0x30], r10
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteComparisonInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref):int]
       test     eax, eax
       je       SHORT G_M000_IG442
       mov      dword ptr [rbp+0xB28], eax
       jmp      G_M000_IG545
 
G_M000_IG444:                ;; offset=0x3AB3
       mov      r9, gword ptr [rbp+0xC28]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, r9
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSequenceIndex(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG02
       jmp      G_M000_IG250
 
G_M000_IG445:                ;; offset=0x3AE5
       mov      r8d, eax
       movzx    rax, byte  ptr [rbp+0xC38]
       mov      dword ptr [rbp+0xB28], r8d
       jmp      G_M000_IG545
 
G_M000_IG446:                ;; offset=0x3AFB
       mov      r9, gword ptr [rbp+0xC28]
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG171
       mov      rcx, bword ptr [rbp+0xC20]
       mov      ebx, dword ptr [rcx+0x60]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      ebx, eax
       jne      G_M000_IG171
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp+0xBB8]
       mov      eax, dword ptr [rax+0x10]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG544
       shl      rax, 4
       mov      rdx, gword ptr [rdx+rax+0x10]
       mov      rcx, 0x7FF9D77E5D30
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rbx, rax
       test     rbx, rbx
       je       G_M000_IG171
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:get_NativeCsvSource():Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:this]
       test     rax, rax
       je       G_M000_IG171
       cmp      gword ptr [rax+0x20], 0
       je       G_M000_IG171
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      bword ptr [rsp+0x20], rdx
       movzx    rdx, byte  ptr [rbp+0xC38]
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp-0x70]
       mov      rcx, gword ptr [rbp+0xC30]
       mov      r8, rax
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AdvanceCsvUnpack(Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource,Lokad.Lython.Runtime.PyIteration+Cursor,byref,bool):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, rcx
       mov      rdx, gword ptr [rbp-0x70]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG447:                ;; offset=0x3BD2
       mov      rdx, qword ptr [rbp-0x68]
       mov      qword ptr [rbx+0x08], rdx
       mov      rcx, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [rcx]
       test     rbx, rbx
       je       G_M000_IG442
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG448
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG449
 
G_M000_IG448:                ;; offset=0x3C15
       mov      rcx, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rcx+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7092A00
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG449:                ;; offset=0x3C3B
       test     esi, esi
       jne      G_M000_IG442
       jmp      G_M000_IG346
 
G_M000_IG450:                ;; offset=0x3C48
       cmp      byte  ptr [rbp+0xB68], 0
       je       SHORT G_M000_IG453
 
G_M000_IG451:                ;; offset=0x3C51
       vmovdqu  xmm0, xmmword ptr [rbp+0xB58]
       vmovdqu  xmmword ptr [rbp-0x270], xmm0
 
G_M000_IG452:                ;; offset=0x3C61
       lea      r9, [rbp-0x270]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       mov      rcx, bword ptr [rbp+0xC20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG453:                ;; offset=0x3C88
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xC20]
       add      rcx, 32
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      dword ptr [rcx+0x10], eax
       jmp      G_M000_IG159
 
G_M000_IG454:                ;; offset=0x3CBF
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG455:                ;; offset=0x3CC6
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2A0], ymm0
 
G_M000_IG456:                ;; offset=0x3CD3
       lea      r8, [rbp-0x2A0]
       lea      rdx, [rbp-0x110]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNextAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, r10
       mov      rdx, gword ptr [rbp-0x110]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x108]
       mov      qword ptr [rbx+0x08], rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       G_M000_IG442
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG457
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG458
 
G_M000_IG457:                ;; offset=0x3D4D
       mov      r10, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7092A08
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG458:                ;; offset=0x3D73
       test     esi, esi
       jne      G_M000_IG442
       jmp      G_M000_IG346
 
G_M000_IG459:                ;; offset=0x3D80
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      ebx, eax
       jmp      G_M000_IG97
 
G_M000_IG460:                ;; offset=0x3D94
       xor      rdx, rdx
       xor      eax, eax
       jmp      G_M000_IG98
 
G_M000_IG461:                ;; offset=0x3D9D
       xor      rcx, rcx
       jmp      G_M000_IG136
 
G_M000_IG462:                ;; offset=0x3DA4
       mov      rcx, gword ptr [rcx+0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadLocalValue(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int):System.Object]
       test     rax, rax
       je       G_M000_IG137
       mov      gword ptr [rbp-0x250], rax
       jmp      G_M000_IG142
 
G_M000_IG463:                ;; offset=0x3DC6
       lea      r8, [rbp-0x250]
       mov      rdx, r15
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryResolveLocalOrClosure(System.String,byref):bool:this]
       test     eax, eax
       je       G_M000_IG137
       jmp      G_M000_IG142
 
G_M000_IG464:                ;; offset=0x3DE5
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.ExecutionFrame:InitializeVariables():System.Collections.Generic.Dictionary`2[System.String,System.Object]:this]
       mov      rcx, rax
       jmp      G_M000_IG138
 
G_M000_IG465:                ;; offset=0x3DF6
       mov      rcx, rdi
       mov      edx, r14d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.RuntimeErrors:NameNotDefined(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG466:                ;; offset=0x3E1A
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r15, rax
       jmp      G_M000_IG101
 
G_M000_IG467:                ;; offset=0x3E2B
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r15, rax
       jmp      G_M000_IG101
 
G_M000_IG468:                ;; offset=0x3E3C
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r15, rax
       jmp      G_M000_IG101
 
G_M000_IG469:                ;; offset=0x3E4D
       mov      rcx, rdi
       mov      edx, r14d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      edx, esi
       mov      rcx, rdi
       mov      r9, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r13, rax
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG107
 
G_M000_IG470:                ;; offset=0x3E80
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       mov      rcx, rsi
       mov      rdx, 0x2C171C8AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rsi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG471:                ;; offset=0x3EAE
       xor      rdx, rdx
       xor      eax, eax
       jmp      G_M000_IG108
 
G_M000_IG472:                ;; offset=0x3EB7
       xor      rcx, rcx
       jmp      G_M000_IG148
 
G_M000_IG473:                ;; offset=0x3EBE
       mov      rcx, gword ptr [rcx+0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadLocalValue(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int):System.Object]
       test     rax, rax
       je       G_M000_IG149
       mov      gword ptr [rbp-0x258], rax
       jmp      G_M000_IG154
 
G_M000_IG474:                ;; offset=0x3EE0
       lea      r8, [rbp-0x258]
       mov      rdx, r15
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryResolveLocalOrClosure(System.String,byref):bool:this]
       test     eax, eax
       je       G_M000_IG149
       jmp      G_M000_IG154
 
G_M000_IG475:                ;; offset=0x3EFF
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.ExecutionFrame:InitializeVariables():System.Collections.Generic.Dictionary`2[System.String,System.Object]:this]
       mov      rcx, rax
       jmp      G_M000_IG150
 
G_M000_IG476:                ;; offset=0x3F10
       mov      rcx, rdi
       mov      edx, r14d
       mov      r8d, 1
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.RuntimeErrors:NameNotDefined(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG477:                ;; offset=0x3F37
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r15, rax
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG111
 
G_M000_IG478:                ;; offset=0x3F4F
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r15, rax
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG111
 
G_M000_IG479:                ;; offset=0x3F67
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r15, rax
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG111
 
G_M000_IG480:                ;; offset=0x3F7F
       mov      rcx, rdi
       mov      edx, r14d
       mov      r8d, 1
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      edx, esi
       mov      rcx, rdi
       mov      r9, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r12, rax
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG117
 
G_M000_IG481:                ;; offset=0x3FB5
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       mov      rcx, rsi
       mov      rdx, 0x2C171C8AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rsi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG482:                ;; offset=0x3FE3
       mov      rdx, r13
       mov      rcx, 0x7FF9D775AC10
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG119
 
G_M000_IG483:                ;; offset=0x4001
       cmp      gword ptr [rbp+0xC30], 0
       setne    r8b
       movzx    r8, r8b
       mov      dword ptr [rsp+0x20], r8d
       lea      r8, [rbp+0xAA0]
       mov      qword ptr [rsp+0x28], r8
       mov      r8, bword ptr [rbp+0xBB8]
       mov      r8, gword ptr [r8]
       mov      rcx, rax
       mov      rdx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeUnaryBuiltin(Lokad.Lython.Runtime.LythonRuntime+BuiltinCallable,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG120
       mov      rdx, gword ptr [rbp+0xAA0]
       mov      rcx, 0x7FF9D74F0AF8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rsi, rax
       test     rsi, rsi
       je       SHORT G_M000_IG484
       jmp      G_M000_IG550
 
G_M000_IG484:                ;; offset=0x4063
       vmovdqu  xmm0, xmmword ptr [rbp+0xAA0]
       vmovdqu  xmmword ptr [rbp-0x270], xmm0
 
G_M000_IG485:                ;; offset=0x4073
       lea      r9, [rbp-0x270]
       mov      rdx, gword ptr [rbp+0xC30]
       mov      r8, bword ptr [rbp+0xBB8]
       mov      rcx, bword ptr [rbp+0xC20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG02
 
G_M000_IG486:                ;; offset=0x409A
       cmp      r11d, 73
       je       G_M000_IG126
       mov      rcx, bword ptr [rbp+0xBB8]
       mov      rdx, 0x2C171C8D5C8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG487:                ;; offset=0x40C4
       mov      rcx, rdx
       mov      edx, r11d
       mov      r11, 0x7FF9D7092988
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rbx, rax
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG127
 
G_M000_IG488:                ;; offset=0x40E6
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      esi, eax
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG130
 
G_M000_IG489:                ;; offset=0x4101
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      rdi, rax
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG132
 
G_M000_IG490:                ;; offset=0x4119
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      rdi, rax
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG132
 
G_M000_IG491:                ;; offset=0x4131
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      rdi, rax
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG132
 
G_M000_IG492:                ;; offset=0x4149
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x2C171C8AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG493:                ;; offset=0x4177
       mov      rdx, gword ptr [rbp+0xB38]
       mov      rcx, 0x7FF9D74F0AF8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rsi, rax
       test     rsi, rsi
       je       SHORT G_M000_IG494
       jmp      G_M000_IG550
 
G_M000_IG494:                ;; offset=0x419A
       mov      rdx, gword ptr [rbp+0xB38]
       mov      rcx, 0x7FF9D76A9D18
       call     CORINFO_HELP_CHKCASTCLASS
       xor      rcx, rcx
       mov      r8, bword ptr [rbp+0xC50]
       mov      gword ptr [r8], rcx
       lea      rcx, bword ptr [r8+0x08]
       mov      rdx, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      r8, bword ptr [rbp+0xC50]
       mov      word  ptr [r8+0x10], 0
       mov      byte  ptr [r8+0x12], 1
       jmp      G_M000_IG170
 
G_M000_IG495:                ;; offset=0x41E0
       mov      gword ptr [rsp+0x20], rdi
       lea      rdx, [rbp+0xA88]
       mov      qword ptr [rsp+0x28], rdx
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, rbx
       mov      r9d, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDeferredChild(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       G_M000_IG317
       cmp      gword ptr [rbp+0xA88], 0
       je       G_M000_IG02
       mov      rdx, gword ptr [rbp+0xA88]
       xor      rcx, rcx
       mov      r8, bword ptr [rbp+0xC50]
       mov      gword ptr [r8], rcx
       lea      rcx, bword ptr [r8+0x08]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      r8, bword ptr [rbp+0xC50]
       mov      word  ptr [r8+0x10], 0
       mov      byte  ptr [r8+0x12], 1
       jmp      G_M000_IG170
 
G_M000_IG496:                ;; offset=0x4255
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7885E98
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG497
       mov      rcx, rax
       call     [System.Threading.Tasks.Task:get_IsCompletedSuccessfully():bool:this]
       jmp      SHORT G_M000_IG498
 
G_M000_IG497:                ;; offset=0x4277
       mov      r8, bword ptr [rbp+0xC50]
       movsx    rdx, word  ptr [r8+0x10]
       mov      rcx, rsi
       mov      r11, 0x7FF9D7092A10
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetStatus(short):int:this
       cmp      eax, 1
       sete     al
       movzx    rax, al
 
G_M000_IG498:                ;; offset=0x429C
       test     eax, eax
       je       G_M000_IG170
       jmp      G_M000_IG168
 
G_M000_IG499:                ;; offset=0x42A9
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7885E98
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       test     rdi, rdi
       je       SHORT G_M000_IG501
       mov      ecx, dword ptr [rdi+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       SHORT G_M000_IG500
       mov      rcx, rdi
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG500:                ;; offset=0x42DF
       mov      rdi, gword ptr [rdi+0x38]
       jmp      G_M000_IG169
 
G_M000_IG501:                ;; offset=0x42E8
       mov      r8, bword ptr [rbp+0xC50]
       movsx    rdx, word  ptr [r8+0x10]
       mov      rcx, rsi
       mov      r11, 0x7FF9D7092A18
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetResult(short):System.__Canon:this
       mov      rdi, rax
       jmp      G_M000_IG169
 
G_M000_IG502:                ;; offset=0x430C
       xor      edx, edx
       mov      r8, bword ptr [rbp+0xC50]
       mov      qword ptr [r8], rdx
       mov      qword ptr [r8+0x08], rdx
       mov      qword ptr [r8+0x10], rdx
       jmp      G_M000_IG159
 
G_M000_IG503:                ;; offset=0x4325
       mov      rdx, r14
       mov      rcx, 0x7FF9D74847C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG504
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG02
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG02
 
G_M000_IG504:                ;; offset=0x4361
       mov      rcx, r14
       movsx    rdx, word  ptr [rbp+0xB10]
       mov      r11, 0x7FF9D7092A20
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG02
 
G_M000_IG505:                ;; offset=0x437E
       mov      gword ptr [rsp+0x20], rdi
       mov      dword ptr [rsp+0x28], 1
       lea      rdx, [rbp-0xF0]
       mov      rcx, gword ptr [rbp+0xC30]
       mov      r8, rbx
       mov      r9d, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x100]
       lea      rdx, [rbp-0xF0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r10, bword ptr [rbp+0xC40]
       mov      rdi, r10
       mov      rdx, gword ptr [rbp-0x100]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xF8]
       mov      qword ptr [rdi+0x08], rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       G_M000_IG347
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG506
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG507
 
G_M000_IG506:                ;; offset=0x4418
       mov      r10, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7092A28
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG507:                ;; offset=0x443E
       test     esi, esi
       jne      G_M000_IG347
       jmp      G_M000_IG346
 
G_M000_IG508:                ;; offset=0x444B
       xor      rdx, rdx
       xor      eax, eax
       jmp      G_M000_IG173
 
G_M000_IG509:                ;; offset=0x4454
       xor      rcx, rcx
       jmp      G_M000_IG262
 
G_M000_IG510:                ;; offset=0x445B
       mov      rcx, gword ptr [rcx+0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadLocalValue(Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],int):System.Object]
       test     rax, rax
       je       G_M000_IG263
       mov      gword ptr [rbp-0x260], rax
       jmp      G_M000_IG268
 
G_M000_IG511:                ;; offset=0x447D
       lea      r8, [rbp-0x260]
       mov      rdx, r15
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryResolveLocalOrClosure(System.String,byref):bool:this]
       test     eax, eax
       je       G_M000_IG263
       jmp      G_M000_IG268
 
G_M000_IG512:                ;; offset=0x449C
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.ExecutionFrame:InitializeVariables():System.Collections.Generic.Dictionary`2[System.String,System.Object]:this]
       mov      rcx, rax
       jmp      G_M000_IG264
 
G_M000_IG513:                ;; offset=0x44AD
       mov      rcx, rdi
       mov      edx, r14d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.RuntimeErrors:NameNotDefined(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG514:                ;; offset=0x44D1
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r15, rax
       jmp      G_M000_IG176
 
G_M000_IG515:                ;; offset=0x44E2
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      r15, rax
       jmp      G_M000_IG176
 
G_M000_IG516:                ;; offset=0x44F3
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      r15, rax
       jmp      G_M000_IG176
 
G_M000_IG517:                ;; offset=0x4504
       mov      rcx, rdi
       mov      edx, r14d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      edx, esi
       mov      rcx, rdi
       mov      r9, gword ptr [rbp+0xC28]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r13, rax
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG182
 
G_M000_IG518:                ;; offset=0x4537
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       mov      rcx, rsi
       mov      rdx, 0x2C171C8AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rsi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG519:                ;; offset=0x4565
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r9, gword ptr [rbp+0xC28]
       jmp      G_M000_IG185
 
G_M000_IG520:                ;; offset=0x457E
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG521:                ;; offset=0x4585
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2A0], ymm0
 
G_M000_IG522:                ;; offset=0x4592
       lea      r8, [rbp-0x2A0]
       lea      rdx, [rbp-0x120]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteGetIteratorAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x130]
       lea      rdx, [rbp-0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, r10
       mov      rdx, gword ptr [rbp-0x130]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x128]
       mov      qword ptr [rbx+0x08], rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       G_M000_IG347
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG523
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG524
 
G_M000_IG523:                ;; offset=0x4620
       mov      r10, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7092A30
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG524:                ;; offset=0x4646
       test     esi, esi
       jne      G_M000_IG347
       jmp      G_M000_IG346
 
G_M000_IG525:                ;; offset=0x4653
       mov      r9, gword ptr [rbp+0xC28]
       cmp      gword ptr [rbp+0xC30], 0
       je       G_M000_IG317
       cmp      byte  ptr [rbp+0xC38], 0
       je       G_M000_IG189
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG526:                ;; offset=0x467C
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2A0], ymm0
 
G_M000_IG527:                ;; offset=0x4689
       lea      r8, [rbp-0x2A0]
       lea      rdx, [rbp-0xD0]
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSliceValueOperationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0xE0]
       lea      rdx, [rbp-0xD0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, r10
       mov      rdx, gword ptr [rbp-0xE0]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xD8]
       mov      qword ptr [rbx+0x08], rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [r10]
       test     rbx, rbx
       je       G_M000_IG347
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG528
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG529
 
G_M000_IG528:                ;; offset=0x4717
       mov      r10, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [r10+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7092A38
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG529:                ;; offset=0x473D
       test     esi, esi
       jne      G_M000_IG347
       jmp      G_M000_IG346
 
G_M000_IG530:                ;; offset=0x474A
       mov      r9, gword ptr [rbp+0xC28]
       cmp      gword ptr [rbp+0xC30], 0
       jne      G_M000_IG189
       jmp      G_M000_IG317
 
G_M000_IG531:                ;; offset=0x4764
       mov      r9, gword ptr [rbp+0xC28]
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x10]
       mov      rcx, bword ptr [rbp+0xC20]
       mov      r8, r9
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      rbx, rax
       cmp      gword ptr [rbp+0xC30], 0
       jne      SHORT G_M000_IG532
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       je       G_M000_IG317
 
G_M000_IG532:                ;; offset=0x47A6
       cmp      byte  ptr [rbp+0xC38], 0
       je       SHORT G_M000_IG533
       mov      rdx, rbx
       mov      rcx, 0x7FF9D77E9A80
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG534
 
G_M000_IG533:                ;; offset=0x47C6
       mov      rcx, bword ptr [rbp+0xC20]
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      r9, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp+0xBCC], eax
       jmp      G_M000_IG02
 
G_M000_IG534:                ;; offset=0x47F3
       mov      r8, bword ptr [rbp+0xBB8]
 
G_M000_IG535:                ;; offset=0x47FA
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x2A0], ymm0
 
G_M000_IG536:                ;; offset=0x4807
       lea      r8, [rbp-0x2A0]
       lea      rdx, [rbp-0xC0]
       mov      rcx, gword ptr [rbp+0xC30]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteConditionalJumpAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0xC40]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0xC0]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0xB8]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0xC40]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       G_M000_IG442
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG537
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG538
 
G_M000_IG537:                ;; offset=0x4883
       mov      rax, bword ptr [rbp+0xC40]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7092A40
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG538:                ;; offset=0x48A9
       test     esi, esi
       jne      G_M000_IG442
       jmp      G_M000_IG346
 
G_M000_IG539:                ;; offset=0x48B6
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x1C]
       cmp      edx, 49
       je       G_M000_IG161
       cmp      edx, 57
       je       G_M000_IG161
       cmp      edx, 58
       je       G_M000_IG161
       jmp      G_M000_IG317
 
G_M000_IG540:                ;; offset=0x48E0
       movzx    rax, byte  ptr [rbp+0xC38]
       test     al, al
       je       G_M000_IG193
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      gword ptr [rcx+0x40], 0
       je       G_M000_IG193
       xor      rdx, rdx
       mov      r10, bword ptr [rbp+0xC40]
       mov      gword ptr [r10], rdx
       mov      word  ptr [r10+0x08], 0
       movzx    rdx, byte  ptr [rbp+0xBCC]
       mov      byte  ptr [r10+0x0A], dl
       mov      byte  ptr [r10+0x0B], 1
       mov      dword ptr [rbp+0xB28], 5
       jmp      G_M000_IG545
 
G_M000_IG541:                ;; offset=0x4933
       mov      rdx, bword ptr [rbp+0xA70]
       mov      eax, ecx
       lea      rdx, bword ptr [rdx+2*rax]
       mov      eax, dword ptr [rbp+0xA78]
       sub      eax, ecx
       cmp      eax, 27
       jb       SHORT G_M000_IG542
       vmovups  ymm0, ymmword ptr [reloc @RWD296]
       vmovups  ymmword ptr [rdx], ymm0
       vmovups  xmm0, xmmword ptr [reloc @RWD328]
       vmovups  xmmword ptr [rdx+0x20], xmm0
       mov      dword ptr [rdx+0x30], 0x3A0065
       mov      word  ptr [rdx+0x34], 32
       mov      ecx, dword ptr [rbp+0xA68]
       add      ecx, 27
       mov      dword ptr [rbp+0xA68], ecx
       jmp      SHORT G_M000_IG543
 
G_M000_IG542:                ;; offset=0x4984
       lea      rcx, [rbp+0xA58]
       mov      rdx, 0x2C171C92A40
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:GrowThenCopyString(System.String):this]
 
G_M000_IG543:                ;; offset=0x499B
       mov      rdx, bword ptr [rbp+0xBB8]
       mov      edx, dword ptr [rdx+0x1C]
       lea      rcx, [rbp+0xA58]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       lea      rcx, [rbp+0xA58]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      rdx, rax
       mov      rcx, rbx
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG544:                ;; offset=0x49E6
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG545:                ;; offset=0x49EC
       mov      eax, dword ptr [rbp+0xB28]
 
G_M000_IG546:                ;; offset=0x49F2
       vzeroupper 
       add      rsp, 0xEF8
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG547:                ;; offset=0x4A09
       cmp      dword ptr [r8+0x20], 0
       setne    r8b
       movzx    r8, r8b
       test     r8d, r8d
       je       G_M000_IG07
 
G_M000_IG548:                ;; offset=0x4A1F
       mov      rcx, rdx
       mov      rdx, rax
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG07
 
G_M000_IG549:                ;; offset=0x4A30
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      gword ptr [rcx+0x40], 0
       je       G_M000_IG03
       jmp      SHORT G_M000_IG552
 
G_M000_IG550:                ;; offset=0x4A44
       mov      r9, bword ptr [rbp+0xBB8]
       mov      r9, gword ptr [r9]
       mov      rcx, rsi
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       je       SHORT G_M000_IG554
       mov      dword ptr [rbp+0xBCC], 1
       jmp      G_M000_IG02
 
G_M000_IG551:                ;; offset=0x4A78
       mov      rax, gword ptr [rbp+0xBD0]
       mov      ebx, dword ptr [rax+0x08]
       mov      rcx, bword ptr [rbp+0xC20]
       cmp      dword ptr [rcx+0x10], ebx
       mov      rcx, bword ptr [rbp+0xC20]
       jl       G_M000_IG06
       jmp      SHORT G_M000_IG555
 
G_M000_IG552:                ;; offset=0x4A9B
       xor      rax, rax
       mov      rcx, bword ptr [rbp+0xC40]
       mov      gword ptr [rcx], rax
       mov      word  ptr [rcx+0x08], 0
       movzx    rax, byte  ptr [rbp+0xBCC]
       mov      byte  ptr [rcx+0x0A], al
       mov      byte  ptr [rcx+0x0B], 1
       mov      eax, 5
 
G_M000_IG553:                ;; offset=0x4AC0
       vzeroupper 
       add      rsp, 0xEF8
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG554:                ;; offset=0x4AD7
       mov      rcx, rsi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG555:                ;; offset=0x4AE0
       mov      eax, 1
 
G_M000_IG556:                ;; offset=0x4AE5
       vzeroupper 
       add      rsp, 0xEF8
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG557:                ;; offset=0x4AFC
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG558:                ;; offset=0x4B02
       sub      rsp, 72
 
G_M000_IG559:                ;; offset=0x4B06
       mov      rbx, rcx
       cmp      gword ptr [rbp+0xC30], 0
       jne      SHORT G_M000_IG561
 
G_M000_IG560:                ;; offset=0x4B13
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG561:                ;; offset=0x4B19
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      rdx, rbx
       mov      rcx, gword ptr [rbp+0xC30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryRouteReturn(Lokad.Lython.Runtime.LythonRuntime+ReturnSignal,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG564
 
G_M000_IG562:                ;; offset=0x4B3D
       mov      dword ptr [rbp+0xB28], 1
       lea      rax, G_M000_IG545
 
G_M000_IG563:                ;; offset=0x4B4E
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG564:                ;; offset=0x4B56
       mov      dword ptr [rbp+0xBCC], 1
       lea      rax, G_M000_IG02
 
G_M000_IG565:                ;; offset=0x4B67
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG566:                ;; offset=0x4B6F
       sub      rsp, 72
 
G_M000_IG567:                ;; offset=0x4B73
       mov      rbx, rcx
       mov      rcx, bword ptr [rbp+0xBB8]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      r9, rax
       mov      rdx, gword ptr [rbp+0xC28]
       mov      r8, gword ptr [rbp+0xC30]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG569
 
G_M000_IG568:                ;; offset=0x4BA1
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG569:                ;; offset=0x4BA7
       mov      dword ptr [rbp+0xBCC], 1
       lea      rax, G_M000_IG02
 
G_M000_IG570:                ;; offset=0x4BB8
       vzeroupper 
       add      rsp, 72
       ret      
 
RWD00  	dd	00003160h ; case G_M000_IG396
       	dd	00000634h ; case G_M000_IG66
       	dd	000000CCh ; case G_M000_IG08
       	dd	0000238Ah ; case G_M000_IG315
       	dd	00001C68h ; case G_M000_IG259
       	dd	000035ABh ; case G_M000_IG425
       	dd	00001BF2h ; case G_M000_IG256
       	dd	00001B79h ; case G_M000_IG251
       	dd	00001B79h ; case G_M000_IG251
       	dd	00001B18h ; case G_M000_IG250
       	dd	00001B18h ; case G_M000_IG250
       	dd	00001B79h ; case G_M000_IG251
       	dd	00001B79h ; case G_M000_IG251
       	dd	00001B79h ; case G_M000_IG251
       	dd	00001B79h ; case G_M000_IG251
       	dd	00001B79h ; case G_M000_IG251
       	dd	00001B79h ; case G_M000_IG251
       	dd	00001B79h ; case G_M000_IG251
       	dd	00001B79h ; case G_M000_IG251
       	dd	00001B79h ; case G_M000_IG251
       	dd	00001B79h ; case G_M000_IG251
       	dd	00001B79h ; case G_M000_IG251
       	dd	00001AE6h ; case G_M000_IG249
       	dd	00001AE6h ; case G_M000_IG249
       	dd	0000363Ch ; case G_M000_IG426
       	dd	0000164Ch ; case G_M000_IG208
       	dd	000026B4h ; case G_M000_IG338
       	dd	0000366Dh ; case G_M000_IG427
       	dd	00001541h ; case G_M000_IG203
       	dd	00001455h ; case G_M000_IG194
       	dd	0000373Ch ; case G_M000_IG430
       	dd	0000377Fh ; case G_M000_IG431
       	dd	000037FCh ; case G_M000_IG432
       	dd	00001437h ; case G_M000_IG192
       	dd	00001437h ; case G_M000_IG192
       	dd	00001437h ; case G_M000_IG192
       	dd	000013FDh ; case G_M000_IG190
       	dd	000013FDh ; case G_M000_IG190
       	dd	000013FDh ; case G_M000_IG190
       	dd	00001437h ; case G_M000_IG192
       	dd	0000127Bh ; case G_M000_IG172
       	dd	00001210h ; case G_M000_IG171
       	dd	00000C60h ; case G_M000_IG125
       	dd	00003A36h ; case G_M000_IG444
       	dd	000045D6h ; case G_M000_IG525
       	dd	000046CDh ; case G_M000_IG530
       	dd	000010EFh ; case G_M000_IG162
       	dd	000010EFh ; case G_M000_IG162
       	dd	000010EFh ; case G_M000_IG162
       	dd	0000109Fh ; case G_M000_IG160
       	dd	000046E7h ; case G_M000_IG531
       	dd	000039DFh ; case G_M000_IG443
       	dd	0000109Fh ; case G_M000_IG160
       	dd	0000109Fh ; case G_M000_IG160
       	dd	0000109Fh ; case G_M000_IG160
       	dd	0000109Fh ; case G_M000_IG160
       	dd	0000109Fh ; case G_M000_IG160
       	dd	0000109Fh ; case G_M000_IG160
       	dd	0000109Fh ; case G_M000_IG160
       	dd	00001446h ; case G_M000_IG193
       	dd	00002D0Ah ; case G_M000_IG376
       	dd	00002F21h ; case G_M000_IG385
       	dd	0000109Fh ; case G_M000_IG160
       	dd	0000283Dh ; case G_M000_IG348
       	dd	0000283Dh ; case G_M000_IG348
       	dd	0000283Dh ; case G_M000_IG348
       	dd	0000283Dh ; case G_M000_IG348
       	dd	0000283Dh ; case G_M000_IG348
       	dd	00001063h ; case G_M000_IG158
       	dd	00003A7Eh ; case G_M000_IG446
       	dd	00002A19h ; case G_M000_IG358
       	dd	00002B40h ; case G_M000_IG364
       	dd	0000230Eh ; case G_M000_IG314
       	dd	000009BAh ; case G_M000_IG94
RWD296 	dq	006E006B006E0055h, 0020006E0077006Fh, 0063006500780065h, 0062006100740075h
RWD328 	dq	006F00200065006Ch, 0064006F00630070h

; Total bytes of code 19392

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInstructionPrefix(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref,byref,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):int (Tier1)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 293
; 101 inlinees with PGO data; 312 single block inlinees; 4 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 904
       lea      rbp, [rsp+0x3C0]
       vxorps   xmm4, xmm4, xmm4
       vmovdqa  xmmword ptr [rbp-0x350], xmm4
       mov      rax, -768
 
G_M000_IG547:                ;; offset=0x0031
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm4
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm4
       add      rax, 48
       jne      SHORT G_M000_IG547
       mov      bword ptr [rbp+0x10], rcx
       mov      gword ptr [rbp+0x18], rdx
       mov      gword ptr [rbp+0x20], r8
       mov      dword ptr [rbp+0x28], r9d
       mov      rax, bword ptr [rbp+0x30]
       mov      r10, bword ptr [rbp+0x38]
       mov      r8, bword ptr [rbp+0x40]
 
G_M000_IG02:                ;; offset=0x0065
       xor      r9d, r9d
       mov      qword ptr [rax], r9
       mov      qword ptr [rax+0x08], r9
 
G_M000_IG03:                ;; offset=0x006F
       mov      gword ptr [r10], r9
 
G_M000_IG04:                ;; offset=0x0072
       mov      qword ptr [r8], r9
       mov      qword ptr [r8+0x08], r9
       mov      qword ptr [r8+0x10], r9
       mov      r9, gword ptr [rcx]
       mov      r9, gword ptr [r9+0x98]
       mov      gword ptr [rbp-0x358], r9
       mov      ebx, dword ptr [r9+0x08]
       cmp      dword ptr [rcx+0x10], ebx
       jl       SHORT G_M000_IG11
 
G_M000_IG05:                ;; offset=0x0097
       mov      eax, 1
 
G_M000_IG06:                ;; offset=0x009C
       vzeroupper 
       add      rsp, 904
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG07:                ;; offset=0x00B3
       cmp      byte  ptr [rbp+0x28], 0
       jne      G_M000_IG524
 
G_M000_IG08:                ;; offset=0x00BD
       cmp      dword ptr [rbp-0x3C], 0
       jne      SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x00C3
       mov      r14, bword ptr [rbp+0x10]
       inc      dword ptr [r14+0x10]
 
G_M000_IG10:                ;; offset=0x00CB
       mov      r14, bword ptr [rbp+0x10]
       mov      ecx, dword ptr [r14+0x10]
       mov      r9, gword ptr [rbp-0x358]
       mov      ebx, dword ptr [r9+0x08]
       cmp      ecx, ebx
       mov      rcx, r14
       mov      rdx, gword ptr [rbp+0x18]
       jge      SHORT G_M000_IG05
 
G_M000_IG11:                ;; offset=0x00E9
       xor      r11d, r11d
       mov      dword ptr [rbp-0x3C], r11d
       mov      r11d, dword ptr [rcx+0x10]
       cmp      r11d, ebx
       jae      G_M000_IG533
       shl      r11, 5
       lea      r11, bword ptr [r9+r11+0x10]
       mov      bword ptr [rbp-0x360], r11
       mov      r11, gword ptr [rdx+0x98]
       mov      rsi, bword ptr [rbp-0x360]
       mov      rsi, gword ptr [rsi]
       mov      rdi, gword ptr [r11+0x88]
       cmp      gword ptr [rdi+0x20], 0
       jne      G_M000_IG531
       mov      rdi, gword ptr [r11+0x180]
       test     rdi, rdi
       jne      G_M000_IG530
 
G_M000_IG12:                ;; offset=0x0140
       mov      r11, bword ptr [rbp-0x360]
       mov      r11d, dword ptr [r11+0x1C]
       cmp      r11d, 73
       ja       G_M000_IG212
 
G_M000_IG13:                ;; offset=0x0155
       mov      r11d, r11d
       lea      rsi, [reloc @RWD00]
       mov      esi, dword ptr [rsi+4*r11]
       lea      rdi, G_M000_IG02
       add      rsi, rdi
       jmp      rsi
 
G_M000_IG14:                ;; offset=0x016F
       mov      rcx, bword ptr [rbp+0x10]
       mov      rbx, gword ptr [rcx]
       mov      rsi, gword ptr [rcx+0x08]
       mov      r11, bword ptr [rbp-0x360]
       mov      r11d, dword ptr [r11+0x1C]
       cmp      r11d, 2
       je       SHORT G_M000_IG16
 
G_M000_IG15:                ;; offset=0x018B
       cmp      r11d, 25
       jne      G_M000_IG310
 
G_M000_IG16:                ;; offset=0x0195
       mov      r11, bword ptr [rbp-0x360]
       mov      edi, dword ptr [r11+0x08]
       mov      r11, bword ptr [rbp-0x360]
       mov      r14, gword ptr [r11]
       cmp      edi, dword ptr [rsi+0x08]
       jae      G_M000_IG522
       mov      r11d, edi
       shl      r11, 4
       lea      r11, bword ptr [rsi+r11+0x10]
       mov      rsi, gword ptr [r11]
       mov      r15, 0x2A14B001CE0
       cmp      rsi, gword ptr [r15]
       je       G_M000_IG311
 
G_M000_IG17:                ;; offset=0x01D5
       mov      r15, 0x2A14B001CE8
       cmp      rsi, gword ptr [r15]
       je       G_M000_IG312
       cmp      qword ptr [r11+0x08], 0
       jne      G_M000_IG313
 
G_M000_IG18:                ;; offset=0x01F3
       test     rsi, rsi
       je       SHORT G_M000_IG21
 
G_M000_IG19:                ;; offset=0x01F8
       mov      r11, 0x7FF9D77E4838
       cmp      qword ptr [rsi], r11
       jne      SHORT G_M000_IG21
 
G_M000_IG20:                ;; offset=0x0207
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      rsi, rax
 
G_M000_IG21:                ;; offset=0x0213
       test     rsi, rsi
       je       G_M000_IG314
 
G_M000_IG22:                ;; offset=0x021C
       mov      rbx, rsi
       mov      r11, bword ptr [rbp-0x360]
       cmp      dword ptr [r11+0x18], 0
       jl       G_M000_IG51
 
G_M000_IG23:                ;; offset=0x0231
       mov      rcx, bword ptr [rbp+0x10]
       lea      rsi, bword ptr [rcx+0x20]
       mov      r11, bword ptr [rbp-0x360]
       mov      r11d, dword ptr [r11+0x1C]
       cmp      r11d, 51
       ja       SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x024A
       mov      rdi, 0x7FFFFFFFFF9FF
       bt       rdi, r11
       jae      G_M000_IG315
 
G_M000_IG25:                ;; offset=0x025E
       mov      r11, bword ptr [rbp-0x360]
       mov      edi, dword ptr [r11+0x14]
 
G_M000_IG26:                ;; offset=0x0269
       mov      r11, bword ptr [rbp-0x360]
       mov      r14d, dword ptr [r11+0x18]
       test     r14d, r14d
       jl       G_M000_IG35
 
G_M000_IG27:                ;; offset=0x027D
       cmp      r14d, dword ptr [rsi+0x40]
       jge      G_M000_IG34
 
G_M000_IG28:                ;; offset=0x0287
       mov      r15d, dword ptr [rsi+0x40]
       dec      r15d
       mov      r13d, dword ptr [rsi+0x3C]
       cmp      r15d, r13d
       jle      G_M000_IG36
 
G_M000_IG29:                ;; offset=0x029B
       cmp      r13d, r14d
       jge      G_M000_IG37
 
G_M000_IG30:                ;; offset=0x02A4
       mov      r11, gword ptr [rsi]
       mov      r15d, dword ptr [rsi+0x40]
       sub      r15d, r14d
       test     r11, r11
       je       G_M000_IG328
       lea      r13, bword ptr [r11+0x10]
       xor      r12d, r12d
       mov      r10, qword ptr [r11]
       cmp      dword ptr [r10+0x04], 24
       jne      G_M000_IG329
 
G_M000_IG31:                ;; offset=0x02CC
       mov      r8d, r14d
       sub      r8d, r12d
       cmp      r14d, r12d
       jl       G_M000_IG50
 
G_M000_IG32:                ;; offset=0x02DB
       mov      r12d, r8d
       or       r12d, r15d
       jl       G_M000_IG50
       lea      r12d, [r8+r15]
       cmp      r12d, dword ptr [r11+0x08]
       ja       G_M000_IG50
       movzx    r11, word  ptr [r10]
       mov      r8d, r8d
       imul     r8, r11
       add      r8, r13
       mov      r15d, r15d
       imul     r11, r15
       test     dword ptr [r10], 0x1000000
       je       G_M000_IG330
       mov      rdx, r11
       shr      rdx, 3
       mov      rcx, r8
       call     [System.SpanHelpers:ClearWithReferences(byref,nuint)]
 
G_M000_IG33:                ;; offset=0x0327
       mov      dword ptr [rsi+0x40], r14d
 
G_M000_IG34:                ;; offset=0x032B
       mov      r11, gword ptr [rsi]
       cmp      edi, dword ptr [r11+0x08]
       jae      G_M000_IG522
       mov      edi, edi
       shl      rdi, 4
       lea      rdi, bword ptr [r11+rdi+0x10]
       mov      rcx, rdi
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       xor      eax, eax
       mov      qword ptr [rdi+0x08], rax
       mov      dword ptr [rsi+0x40], r14d
       jmp      G_M000_IG07
 
G_M000_IG35:                ;; offset=0x035D
       not      r14d
       jmp      G_M000_IG27
 
G_M000_IG36:                ;; offset=0x0365
       mov      r13d, r15d
       jmp      G_M000_IG29
 
G_M000_IG37:                ;; offset=0x036D
       cmp      byte  ptr [rsi+0x44], 0
       jne      G_M000_IG316
 
G_M000_IG38:                ;; offset=0x0377
       mov      r11, gword ptr [rsi]
       cmp      r13d, dword ptr [r11+0x08]
       jae      G_M000_IG522
       mov      r15d, r13d
       shl      r15, 4
       lea      r15, bword ptr [r11+r15+0x10]
       mov      r11, gword ptr [rsi+0x18]
       mov      r12, gword ptr [r11+0x88]
       mov      r11, gword ptr [r15]
       mov      r10, r11
       test     r10, r10
       je       SHORT G_M000_IG40
 
G_M000_IG39:                ;; offset=0x03A6
       mov      r8, 0x7FF9D7838AB0
       cmp      qword ptr [r10], r8
       jne      SHORT G_M000_IG44
 
G_M000_IG40:                ;; offset=0x03B5
       test     r10, r10
       jne      SHORT G_M000_IG45
 
G_M000_IG41:                ;; offset=0x03BA
       cmp      qword ptr [r15+0x08], -1
       je       G_M000_IG324
 
G_M000_IG42:                ;; offset=0x03C5
       cmp      qword ptr [r15+0x08], -2
       je       G_M000_IG327
 
G_M000_IG43:                ;; offset=0x03D0
       dec      r13d
       cmp      r13d, r14d
       jge      SHORT G_M000_IG37
       jmp      G_M000_IG30
 
G_M000_IG44:                ;; offset=0x03DD
       mov      rdx, r11
       mov      rcx, 0x7FF9D77CE450
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rcx, rax
       mov      r10, rcx
       jmp      SHORT G_M000_IG40
 
G_M000_IG45:                ;; offset=0x03F7
       xor      r11d, r11d
       mov      qword ptr [r15], r11
       mov      qword ptr [r15+0x08], r11
       mov      r11, 0x7FF9D7838AB0
       cmp      qword ptr [r10], r11
       jne      G_M000_IG323
       mov      r11, gword ptr [r10+0x08]
       cmp      byte  ptr [r11], r11b
       cmp      byte  ptr [r10+0x38], 0
       je       SHORT G_M000_IG43
       mov      byte  ptr [r10+0x38], 0
       xor      r15, r15
       mov      gword ptr [r10+0x18], r15
 
G_M000_IG46:                ;; offset=0x042E
       mov      gword ptr [r10+0x20], r15
 
G_M000_IG47:                ;; offset=0x0432
       mov      qword ptr [r10+0x30], r15
       mov      r15, gword ptr [r11+0x18]
       cmp      byte  ptr [r11+0x48], 0
       jne      G_M000_IG322
 
G_M000_IG48:                ;; offset=0x0445
       test     r15, r15
       jne      G_M000_IG320
 
G_M000_IG49:                ;; offset=0x044E
       lea      rcx, bword ptr [r11+0x18]
       mov      rdx, r10
       call     CORINFO_HELP_ASSIGN_REF
       test     r15, r15
       je       G_M000_IG43
       jmp      G_M000_IG321
 
G_M000_IG50:                ;; offset=0x0468
       call     [System.ThrowHelper:ThrowIndexOutOfRangeException()]
       int3     
 
G_M000_IG51:                ;; offset=0x046F
       mov      gword ptr [rbp-0x258], rsi
       xor      r11d, r11d
       mov      qword ptr [rbp-0x250], r11
       mov      r11, bword ptr [rbp-0x360]
       mov      r11d, dword ptr [r11+0x18]
       not      r11d
       mov      rcx, bword ptr [rbp+0x10]
       cmp      r11d, dword ptr [rcx+0x60]
       jl       G_M000_IG197
 
G_M000_IG52:                ;; offset=0x049C
       cmp      gword ptr [rcx+0x40], 0
       jne      G_M000_IG332
       mov      r11, gword ptr [rcx+0x38]
       mov      rbx, gword ptr [r11+0x88]
       cmp      gword ptr [rbx+0x20], 0
       jne      G_M000_IG332
       mov      r11, gword ptr [r11+0x180]
       test     r11, r11
       jne      G_M000_IG331
 
G_M000_IG53:                ;; offset=0x04CD
       lea      rbx, bword ptr [rcx+0x20]
       mov      r11, bword ptr [rbp-0x360]
       mov      r11d, dword ptr [r11+0x1C]
       cmp      r11d, 51
       ja       SHORT G_M000_IG55
 
G_M000_IG54:                ;; offset=0x04E2
       mov      rsi, 0x7FFFFFFFFF9FF
       bt       rsi, r11
       jae      G_M000_IG335
 
G_M000_IG55:                ;; offset=0x04F6
       mov      r11, bword ptr [rbp-0x360]
       mov      r11d, dword ptr [r11+0x14]
 
G_M000_IG56:                ;; offset=0x0501
       mov      rsi, gword ptr [rbx]
       cmp      r11d, dword ptr [rsi+0x08]
       jae      G_M000_IG522
       mov      edi, r11d
       shl      rdi, 4
       lea      rsi, bword ptr [rsi+rdi+0x10]
       xor      rdi, rdi
       mov      gword ptr [rsi], rdi
 
G_M000_IG57:                ;; offset=0x051F
       mov      qword ptr [rsi+0x08], rdi
       mov      dword ptr [rbx+0x40], r11d
       mov      rcx, bword ptr [rbp+0x10]
       mov      r11, gword ptr [rcx]
       mov      r11, gword ptr [r11+0x98]
       mov      ebx, dword ptr [rcx+0x10]
       inc      ebx
       cmp      ebx, dword ptr [r11+0x08]
       jae      G_M000_IG522
       shl      rbx, 5
       lea      r11, bword ptr [r11+rbx+0x10]
       mov      ebx, dword ptr [r11+0x1C]
       cmp      ebx, 25
       jne      G_M000_IG200
 
G_M000_IG58:                ;; offset=0x055A
       mov      rbx, gword ptr [rcx]
       mov      rsi, gword ptr [rcx+0x08]
       mov      edi, dword ptr [r11+0x08]
 
G_M000_IG59:                ;; offset=0x0565
       vmovdqu  xmm0, xmmword ptr [rbp-0x258]
       vmovdqu  xmmword ptr [rbp-0x268], xmm0
 
G_M000_IG60:                ;; offset=0x0575
       mov      r11, gword ptr [rbx+0x68]
       mov      r14, 0x7FF9D722C7D0
       cmp      qword ptr [r11], r14
       jne      G_M000_IG337
       cmp      dword ptr [r11+0x08], edi
       jbe      G_M000_IG336
       mov      r14d, edi
       mov      r14, gword ptr [r11+8*r14+0x10]
 
G_M000_IG61:                ;; offset=0x059E
       cmp      word  ptr [r14+0x0C], 60
       setne    r15b
       movzx    r15, r15b
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG338
       mov      r11, gword ptr [rbp+0x20]
       mov      r13, gword ptr [r11+0x88]
 
G_M000_IG62:                ;; offset=0x05C2
       test     r13, r13
       setne    r13b
       movzx    r13, r13b
       test     r13d, r15d
       jne      G_M000_IG339
       cmp      edi, dword ptr [rsi+0x08]
       jae      G_M000_IG522
       mov      r13d, edi
       shl      r13, 4
       mov      r13, gword ptr [rsi+r13+0x10]
       test     r13, r13
       jne      G_M000_IG198
 
G_M000_IG63:                ;; offset=0x05F4
       mov      r13d, edi
       shl      r13, 4
       lea      r13, bword ptr [rsi+r13+0x10]
       mov      rdx, gword ptr [rbp-0x268]
       mov      rcx, r13
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, qword ptr [rbp-0x260]
       mov      qword ptr [r13+0x08], rcx
       test     r15d, r15d
       je       SHORT G_M000_IG65
 
G_M000_IG64:                ;; offset=0x061F
       cmp      byte  ptr [rbx+0xF2], 0
       jne      G_M000_IG340
       cmp      gword ptr [rbp+0x20], 0
       je       SHORT G_M000_IG65
       mov      r11, gword ptr [rbp+0x20]
       cmp      byte  ptr [r11+0xFF], 0
       jne      G_M000_IG340
 
G_M000_IG65:                ;; offset=0x0645
       mov      r14, bword ptr [rbp+0x10]
       inc      dword ptr [r14+0x10]
       jmp      G_M000_IG07
 
G_M000_IG66:                ;; offset=0x0652
       lea      rsi, bword ptr [rbx+0x20]
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       jmp      G_M000_IG160
 
G_M000_IG67:                ;; offset=0x0673
       mov      rax, 0x7FF9D77E4838
       cmp      qword ptr [r12], rax
       jne      G_M000_IG171
 
G_M000_IG68:                ;; offset=0x0687
       lea      rcx, [rbp-0x2E8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77F2610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rdx, rax
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      SHORT G_M000_IG65
 
G_M000_IG69:                ;; offset=0x06B5
       cmp      esi, 71
       je       G_M000_IG447
       cmp      esi, 30
       jne      G_M000_IG452
       cmp      gword ptr [rbp-0x2D8], 0
       jne      G_M000_IG65
       jmp      G_M000_IG453
 
G_M000_IG70:                ;; offset=0x06DA
       mov      rdx, bword ptr [rbp-0x360]
       mov      edx, dword ptr [rdx+0x10]
       mov      rbx, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [rbx+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      dword ptr [rbx+0x10], eax
       jmp      G_M000_IG246
 
G_M000_IG71:                ;; offset=0x0707
       mov      rcx, bword ptr [rbp+0x10]
       lea      rbx, bword ptr [rcx+0x20]
       mov      r11, bword ptr [rbp-0x360]
       mov      esi, dword ptr [r11+0x10]
       mov      rdi, gword ptr [rcx]
       mov      r11, gword ptr [rcx+0x20]
       test     r11, r11
       je       G_M000_IG498
       lea      r14, bword ptr [r11+0x10]
       mov      r11d, dword ptr [r11+0x08]
 
G_M000_IG72:                ;; offset=0x0732
       mov      r15d, dword ptr [rcx+0x10]
       xor      r13, r13
       mov      gword ptr [rbp-0x300], r13
       test     esi, esi
       jl       G_M000_IG242
 
G_M000_IG73:                ;; offset=0x0748
       cmp      esi, r11d
       jae      G_M000_IG522
       mov      r11d, esi
       shl      r11, 4
       lea      rcx, bword ptr [r14+r11]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rcx, rax
       cmp      esi, dword ptr [rdi+0xD8]
       jge      SHORT G_M000_IG78
 
G_M000_IG74:                ;; offset=0x076D
       test     rcx, rcx
       je       SHORT G_M000_IG77
 
G_M000_IG75:                ;; offset=0x0772
       mov      rax, 0x7FF9D77E4838
       cmp      qword ptr [rcx], rax
       jne      SHORT G_M000_IG77
 
G_M000_IG76:                ;; offset=0x0781
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:get_Value():System.Object:this]
       mov      rcx, rax
 
G_M000_IG77:                ;; offset=0x078A
       test     rcx, rcx
       je       G_M000_IG501
 
G_M000_IG78:                ;; offset=0x0793
       mov      rdx, rcx
       mov      rcx, 0x7FF9D77F2610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r14, rax
 
G_M000_IG79:                ;; offset=0x07A9
       xor      rcx, rcx
       mov      gword ptr [rbp-0x300], rcx
       mov      rcx, bword ptr [rbp-0x360]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG81
 
G_M000_IG80:                ;; offset=0x07C1
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jae      G_M000_IG502
 
G_M000_IG81:                ;; offset=0x07D5
       mov      rax, bword ptr [rbp-0x360]
       mov      eax, dword ptr [rax+0x14]
 
G_M000_IG82:                ;; offset=0x07DF
       mov      rcx, bword ptr [rbp-0x360]
       cmp      dword ptr [rcx+0x18], 0
       jl       G_M000_IG244
 
G_M000_IG83:                ;; offset=0x07F0
       mov      rcx, bword ptr [rbp-0x360]
       mov      r9d, dword ptr [rcx+0x18]
 
G_M000_IG84:                ;; offset=0x07FB
       mov      rcx, bword ptr [rbp-0x360]
       mov      rcx, gword ptr [rcx]
       mov      gword ptr [rsp+0x20], rcx
       mov      rcx, rbx
       mov      rdx, r14
       mov      r8d, eax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryPrepareNativeIteration(System.Object,int,int,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      G_M000_IG07
 
G_M000_IG85:                ;; offset=0x0821
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG284
 
G_M000_IG86:                ;; offset=0x082C
       cmp      byte  ptr [rbp+0x28], 0
       jne      G_M000_IG503
 
G_M000_IG87:                ;; offset=0x0836
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteValueOperation(byref):this]
       jmp      G_M000_IG07
 
G_M000_IG88:                ;; offset=0x084C
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG284
 
G_M000_IG89:                ;; offset=0x0857
       cmp      byte  ptr [rbp+0x28], 0
       jne      G_M000_IG418
       jmp      SHORT G_M000_IG91
 
G_M000_IG90:                ;; offset=0x0863
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG284
 
G_M000_IG91:                ;; offset=0x086E
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteStructure(byref):bool:this]
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG07
 
G_M000_IG92:                ;; offset=0x0887
       cmp      gword ptr [rbp+0x20], 0
       je       SHORT G_M000_IG94
 
G_M000_IG93:                ;; offset=0x088E
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryStageUnpackedFrameReturn(byref):bool:this]
       test     eax, eax
       jne      G_M000_IG267
 
G_M000_IG94:                ;; offset=0x08A7
       mov      r11, bword ptr [rbp+0x48]
       cmp      dword ptr [r11+0x08], 0
       jne      G_M000_IG415
 
G_M000_IG95:                ;; offset=0x08B6
       mov      rcx, bword ptr [rbp+0x10]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rsi, bword ptr [rbp-0x360]
       mov      esi, dword ptr [rsi+0x10]
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      r8d, eax
       mov      rdx, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rdx
       mov      edx, esi
       mov      rcx, rbx
       mov      r9, bword ptr [rbp-0x360]
       mov      r9, gword ptr [r9]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTupleFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyTuple]
       mov      rdx, rax
       lea      rcx, [rbp-0x2B8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x2B8]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG07
 
G_M000_IG96:                ;; offset=0x0927
       mov      rcx, bword ptr [rbp+0x10]
       mov      rbx, gword ptr [rcx+0x08]
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG522
       mov      ecx, eax
       shl      rcx, 4
       cmp      gword ptr [rbx+rcx+0x10], 0
       jne      G_M000_IG07
       jmp      G_M000_IG348
 
G_M000_IG97:                ;; offset=0x095C
       mov      rcx, bword ptr [rbp+0x10]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      esi, eax
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r9d, eax
       mov      r8d, esi
       mov      rcx, rbx
       lea      rdx, [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rcx+0x20]
       test     r8, r8
       je       G_M000_IG365
       lea      r9, bword ptr [r8+0x10]
       mov      r8d, dword ptr [r8+0x08]
 
G_M000_IG98:                ;; offset=0x09AC
       mov      rdx, gword ptr [rbp+0x20]
       mov      rax, rdx
       test     rax, rax
       jne      SHORT G_M000_IG100
 
G_M000_IG99:                ;; offset=0x09B8
       mov      r10, gword ptr [rbp+0x18]
       mov      rax, r10
 
G_M000_IG100:                ;; offset=0x09BF
       mov      bword ptr [rbp-0x310], r9
       mov      dword ptr [rbp-0x308], r8d
 
G_M000_IG101:                ;; offset=0x09CD
       vmovdqu  xmm0, xmmword ptr [rbp-0x58]
       vmovdqu  xmmword ptr [rbp-0x320], xmm0
 
G_M000_IG102:                ;; offset=0x09DA
       lea      rcx, [rbp-0x310]
       lea      r8, [rbp-0x320]
       mov      r9, gword ptr [rax+0x98]
       mov      rdx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG07
 
G_M000_IG103:                ;; offset=0x0A01
       mov      rcx, bword ptr [rbp+0x10]
       mov      r11, gword ptr [rcx]
       mov      rbx, gword ptr [r11+0x30]
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG522
       mov      ecx, eax
       mov      rdx, gword ptr [rbx+8*rcx+0x10]
       mov      rbx, rdx
       test     rbx, rbx
       je       SHORT G_M000_IG105
 
G_M000_IG104:                ;; offset=0x0A31
       mov      rcx, 0x7FF9D758EAB0
       cmp      qword ptr [rbx], rcx
       jne      G_M000_IG361
 
G_M000_IG105:                ;; offset=0x0A44
       mov      rcx, bword ptr [rbp+0x10]
       mov      rsi, gword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      edi, eax
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r14d, eax
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       sub      r14d, eax
       test     rsi, rsi
       je       G_M000_IG362
       mov      edx, edi
       mov      ecx, r14d
       add      rcx, rdx
       mov      r8d, dword ptr [rsi+0x08]
       cmp      rcx, r8
       ja       G_M000_IG363
       shl      rdx, 4
       lea      rdx, bword ptr [rsi+rdx+0x10]
 
G_M000_IG106:                ;; offset=0x0AA2
       mov      rcx, bword ptr [rbp-0x360]
       cmp      dword ptr [rcx+0x0C], 0
       setne    r8b
       movzx    r8, r8b
       mov      rax, gword ptr [rbp+0x20]
       mov      r9, rax
       test     r9, r9
       jne      SHORT G_M000_IG108
 
G_M000_IG107:                ;; offset=0x0AC1
       mov      r10, gword ptr [rbp+0x18]
       mov      r9, r10
 
G_M000_IG108:                ;; offset=0x0AC8
       mov      bword ptr [rbp-0x310], rdx
       mov      dword ptr [rbp-0x308], r14d
       mov      rdx, bword ptr [rbp-0x360]
       mov      rdx, gword ptr [rdx]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0x310]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      dword ptr [rcx+0x60], eax
       jmp      G_M000_IG07
 
G_M000_IG109:                ;; offset=0x0B0E
       cmp      gword ptr [rbp+0x20], 0
       je       SHORT G_M000_IG111
 
G_M000_IG110:                ;; offset=0x0B15
       mov      rcx, bword ptr [rbp+0x10]
       mov      ebx, dword ptr [rcx+0x60]
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      ebx, eax
       je       G_M000_IG424
 
G_M000_IG111:                ;; offset=0x0B31
       mov      rcx, bword ptr [rbp+0x10]
       lea      rbx, bword ptr [rcx+0x20]
       mov      r11, bword ptr [rbp-0x360]
       mov      esi, dword ptr [r11+0x10]
       mov      r11, gword ptr [rbx]
       cmp      esi, dword ptr [r11+0x08]
       jae      G_M000_IG522
       mov      edi, esi
       shl      rdi, 4
       lea      r11, bword ptr [r11+rdi+0x10]
       mov      rdi, gword ptr [r11]
       mov      r14, 0x2A14B001CE0
       cmp      rdi, gword ptr [r14]
       je       G_M000_IG432
 
G_M000_IG112:                ;; offset=0x0B72
       mov      r14, 0x2A14B001CE8
       cmp      rdi, gword ptr [r14]
       je       G_M000_IG433
       cmp      qword ptr [r11+0x08], 0
       jne      G_M000_IG434
 
G_M000_IG113:                ;; offset=0x0B90
       test     rdi, rdi
       je       G_M000_IG435
       mov      r11, 0x7FF9D7838AB0
       cmp      qword ptr [rdi], r11
       je       G_M000_IG145
 
G_M000_IG114:                ;; offset=0x0BAC
       mov      r11, 0x7FF9D77EA4F0
       cmp      qword ptr [rdi], r11
       je       G_M000_IG144
 
G_M000_IG115:                ;; offset=0x0BBF
       mov      r11, rdi
       mov      r14, 0x7FF9D77E5D30
       cmp      qword ptr [r11], r14
       jne      G_M000_IG436
       xor      r11, r11
 
G_M000_IG116:                ;; offset=0x0BD8
       test     r11, r11
       jne      G_M000_IG144
       mov      r11, 0x7FF9D7838D18
       cmp      qword ptr [rdi], r11
       je       G_M000_IG143
 
G_M000_IG117:                ;; offset=0x0BF4
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG284
 
G_M000_IG118:                ;; offset=0x0BFF
       cmp      byte  ptr [rbp+0x28], 0
       jne      G_M000_IG139
 
G_M000_IG119:                ;; offset=0x0C09
       mov      r11, gword ptr [rbp+0x20]
       mov      rdi, gword ptr [r11+0x138]
       mov      rbx, bword ptr [rbp-0x360]
       mov      esi, dword ptr [rbx+0x10]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG522
       mov      ebx, esi
       shl      rbx, 4
       lea      rbx, bword ptr [rdi+rbx+0x10]
       mov      rsi, gword ptr [rbx]
       mov      rdi, 0x2A14B001CE0
       cmp      rsi, gword ptr [rdi]
       je       G_M000_IG454
 
G_M000_IG120:                ;; offset=0x0C48
       mov      rsi, gword ptr [rbx]
       mov      rdi, 0x2A14B001CE8
       cmp      rsi, gword ptr [rdi]
       je       G_M000_IG455
       cmp      qword ptr [rbx+0x08], 0
       jne      G_M000_IG456
       mov      rsi, gword ptr [rbx]
 
G_M000_IG121:                ;; offset=0x0C6C
       test     rsi, rsi
       je       G_M000_IG457
       mov      rbx, rsi
       test     rbx, rbx
       je       SHORT G_M000_IG123
 
G_M000_IG122:                ;; offset=0x0C7D
       mov      rdi, 0x7FF9D77E5D30
       cmp      qword ptr [rbx], rdi
       jne      G_M000_IG458
 
G_M000_IG123:                ;; offset=0x0C90
       cmp      gword ptr [rbx+0x20], 0
       je       SHORT G_M000_IG125
 
G_M000_IG124:                ;; offset=0x0C97
       mov      edi, dword ptr [rbx+0x50]
       lea      esi, [rdi-0x01]
       mov      dword ptr [rbx+0x50], esi
       test     edi, edi
       je       G_M000_IG459
 
G_M000_IG125:                ;; offset=0x0CA8
       lea      rdx, [rbp-0x2F8]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:TryMoveNextCore():Lokad.Lython.Runtime.PyIterationResult:this]
       mov      rsi, gword ptr [rbp-0x2F8]
       test     rsi, rsi
       je       G_M000_IG461
 
G_M000_IG126:                ;; offset=0x0CC8
       mov      rbx, qword ptr [rbp-0x2F0]
       mov      r11, gword ptr [rbp+0x20]
       lea      rcx, bword ptr [r11+0x118]
       mov      rax, bword ptr [rbp-0x360]
       cmp      dword ptr [rax+0x18], 0
       jl       G_M000_IG138
 
G_M000_IG127:                ;; offset=0x0CEB
       mov      r11, gword ptr [rbp+0x20]
       lea      rdi, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp-0x360]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG129
 
G_M000_IG128:                ;; offset=0x0D02
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jae      G_M000_IG462
 
G_M000_IG129:                ;; offset=0x0D16
       mov      rcx, bword ptr [rbp-0x360]
       mov      r14d, dword ptr [rcx+0x14]
 
G_M000_IG130:                ;; offset=0x0D21
       mov      rcx, bword ptr [rbp-0x360]
       cmp      dword ptr [rcx+0x18], 0
       jl       SHORT G_M000_IG137
 
G_M000_IG131:                ;; offset=0x0D2E
       mov      rcx, bword ptr [rbp-0x360]
       mov      r15d, dword ptr [rcx+0x18]
 
G_M000_IG132:                ;; offset=0x0D39
       cmp      r15d, dword ptr [rdi+0x40]
       jge      SHORT G_M000_IG134
 
G_M000_IG133:                ;; offset=0x0D3F
       mov      rcx, rdi
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG134:                ;; offset=0x0D4B
       mov      rcx, gword ptr [rdi]
       cmp      r14d, dword ptr [rcx+0x08]
       jae      G_M000_IG522
       mov      edx, r14d
       shl      rdx, 4
       lea      r14, bword ptr [rcx+rdx+0x10]
       mov      rcx, r14
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r14+0x08], rbx
       mov      dword ptr [rdi+0x40], r15d
 
G_M000_IG135:                ;; offset=0x0D77
       xor      ebx, ebx
 
G_M000_IG136:                ;; offset=0x0D79
       mov      dword ptr [rbp-0x3C], ebx
       jmp      G_M000_IG07
 
G_M000_IG137:                ;; offset=0x0D81
       mov      rcx, bword ptr [rbp-0x360]
       mov      ecx, dword ptr [rcx+0x18]
       mov      r15d, ecx
       not      r15d
       jmp      SHORT G_M000_IG132
 
G_M000_IG138:                ;; offset=0x0D93
       mov      r11, gword ptr [rbp+0x20]
       mov      gword ptr [rbp-0x320], rsi
       mov      qword ptr [rbp-0x318], rbx
       lea      r9, [rbp-0x320]
       mov      rdx, r11
       mov      r8, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      SHORT G_M000_IG135
 
G_M000_IG139:                ;; offset=0x0DBE
       mov      r11, bword ptr [rbp-0x360]
 
G_M000_IG140:                ;; offset=0x0DC5
       vmovdqu  ymm0, ymmword ptr [r11]
       vmovdqu  ymmword ptr [rbp-0x340], ymm0
 
G_M000_IG141:                ;; offset=0x0DD2
       lea      r8, [rbp-0x340]
       lea      rdx, [rbp-0x1B0]
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteForNextAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0x1B0]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x1A8]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       jne      G_M000_IG463
 
G_M000_IG142:                ;; offset=0x0E1B
       mov      rcx, bword ptr [rbp+0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG07
 
G_M000_IG143:                ;; offset=0x0E2D
       lea      rdx, [rbp-0x2C8]
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.PyRange+Enumerator:TryMoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
       jmp      SHORT G_M000_IG146
 
G_M000_IG144:                ;; offset=0x0E3F
       mov      r11, gword ptr [rbx+0x08]
       sub      esi, dword ptr [rbx+0x38]
       cmp      esi, dword ptr [r11+0x08]
       jae      G_M000_IG522
       mov      ebx, esi
       lea      r11, bword ptr [r11+4*rbx+0x10]
       mov      r8, r11
       lea      rcx, [rbp-0x2C8]
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.PyIteration:AdvanceBuiltinSequence(System.Object,byref):Lokad.Lython.Runtime.PyIterationResult]
       jmp      SHORT G_M000_IG146
 
G_M000_IG145:                ;; offset=0x0E6C
       mov      r11, rdi
       lea      rdx, [rbp-0x2C8]
       mov      rcx, r11
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:MoveNext():Lokad.Lython.Runtime.PyIterationResult:this]
 
G_M000_IG146:                ;; offset=0x0E7F
       cmp      gword ptr [rbp-0x2C8], 0
       setne    cl
       movzx    rcx, cl
       test     ecx, ecx
       jne      G_M000_IG157
 
G_M000_IG147:                ;; offset=0x0E95
       xor      rbx, rbx
       xor      esi, esi
 
G_M000_IG148:                ;; offset=0x0E99
       test     ecx, ecx
       je       G_M000_IG70
 
G_M000_IG149:                ;; offset=0x0EA1
       mov      rcx, bword ptr [rbp-0x360]
       cmp      dword ptr [rcx+0x18], 0
       jl       G_M000_IG159
 
G_M000_IG150:                ;; offset=0x0EB2
       mov      rcx, bword ptr [rbp+0x10]
       lea      rdi, bword ptr [rcx+0x20]
       mov      rax, bword ptr [rbp-0x360]
       mov      eax, dword ptr [rax+0x1C]
       cmp      eax, 51
       ja       SHORT G_M000_IG152
 
G_M000_IG151:                ;; offset=0x0EC9
       mov      rdx, 0x7FFFFFFFFF9FF
       bt       rdx, rax
       jae      G_M000_IG437
 
G_M000_IG152:                ;; offset=0x0EDD
       mov      rdx, bword ptr [rbp-0x360]
       mov      r14d, dword ptr [rdx+0x14]
 
G_M000_IG153:                ;; offset=0x0EE8
       mov      rdx, bword ptr [rbp-0x360]
       mov      r15d, dword ptr [rdx+0x18]
       test     r15d, r15d
       jl       SHORT G_M000_IG158
 
G_M000_IG154:                ;; offset=0x0EF8
       cmp      r15d, dword ptr [rdi+0x40]
       jge      SHORT G_M000_IG156
 
G_M000_IG155:                ;; offset=0x0EFE
       mov      rcx, rdi
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG156:                ;; offset=0x0F0A
       mov      rdx, gword ptr [rdi]
       cmp      r14d, dword ptr [rdx+0x08]
       jae      G_M000_IG522
       mov      eax, r14d
       shl      rax, 4
       lea      r14, bword ptr [rdx+rax+0x10]
       mov      rcx, r14
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       mov      qword ptr [r14+0x08], rsi
       mov      dword ptr [rdi+0x40], r15d
       jmp      G_M000_IG07
 
G_M000_IG157:                ;; offset=0x0F3B
       mov      rbx, gword ptr [rbp-0x2C8]
       mov      rsi, qword ptr [rbp-0x2C0]
       jmp      G_M000_IG148
 
G_M000_IG158:                ;; offset=0x0F4E
       not      r15d
       jmp      SHORT G_M000_IG154
 
G_M000_IG159:                ;; offset=0x0F53
       mov      gword ptr [rbp-0x2D8], rbx
       mov      qword ptr [rbp-0x2D0], rsi
       mov      rcx, bword ptr [rbp-0x360]
       mov      ecx, dword ptr [rcx+0x18]
       not      ecx
       mov      rbx, bword ptr [rbp+0x10]
       cmp      ecx, dword ptr [rbx+0x60]
       jl       G_M000_IG66
 
G_M000_IG160:                ;; offset=0x0F7A
       cmp      gword ptr [rbx+0x40], 0
       jne      G_M000_IG439
       mov      rcx, gword ptr [rbx+0x38]
       mov      rax, gword ptr [rcx+0x88]
       cmp      gword ptr [rax+0x20], 0
       jne      G_M000_IG439
       mov      rcx, gword ptr [rcx+0x180]
       test     rcx, rcx
       jne      G_M000_IG438
 
G_M000_IG161:                ;; offset=0x0FAB
       lea      rsi, bword ptr [rbx+0x20]
       mov      rcx, bword ptr [rbp-0x360]
       mov      ecx, dword ptr [rcx+0x1C]
       cmp      ecx, 51
       ja       SHORT G_M000_IG163
 
G_M000_IG162:                ;; offset=0x0FBE
       mov      rax, 0x7FFFFFFFFF9FF
       bt       rax, rcx
       jae      G_M000_IG442
 
G_M000_IG163:                ;; offset=0x0FD2
       mov      rax, bword ptr [rbp-0x360]
       mov      eax, dword ptr [rax+0x14]
 
G_M000_IG164:                ;; offset=0x0FDC
       mov      rcx, gword ptr [rsi]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG522
       mov      edx, eax
       shl      rdx, 4
       lea      rcx, bword ptr [rcx+rdx+0x10]
       xor      rdx, rdx
       mov      gword ptr [rcx], rdx
 
G_M000_IG165:                ;; offset=0x0FF8
       mov      qword ptr [rcx+0x08], rdx
       mov      dword ptr [rsi+0x40], eax
       mov      rcx, gword ptr [rbx]
       mov      rcx, gword ptr [rcx+0x98]
       mov      edx, dword ptr [rbx+0x10]
       inc      edx
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG522
       shl      rdx, 5
       lea      rdx, bword ptr [rcx+rdx+0x10]
       mov      esi, dword ptr [rdx+0x1C]
       cmp      esi, 25
       jne      G_M000_IG69
 
G_M000_IG166:                ;; offset=0x102C
       mov      rsi, gword ptr [rbx]
       mov      rdi, gword ptr [rbx+0x08]
       mov      r14d, dword ptr [rdx+0x08]
 
G_M000_IG167:                ;; offset=0x1037
       vmovdqu  xmm0, xmmword ptr [rbp-0x2D8]
       vmovdqu  xmmword ptr [rbp-0x2E8], xmm0
 
G_M000_IG168:                ;; offset=0x1047
       mov      rcx, gword ptr [rsi+0x68]
       mov      rdx, 0x7FF9D722C7D0
       cmp      qword ptr [rcx], rdx
       jne      G_M000_IG443
       cmp      dword ptr [rcx+0x08], r14d
       jbe      G_M000_IG336
       mov      edx, r14d
       mov      r15, gword ptr [rcx+8*rdx+0x10]
 
G_M000_IG169:                ;; offset=0x1070
       cmp      word  ptr [r15+0x0C], 60
       setne    r13b
       movzx    r13, r13b
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG444
       mov      rcx, gword ptr [rbp+0x20]
       mov      rax, gword ptr [rcx+0x88]
 
G_M000_IG170:                ;; offset=0x1094
       test     rax, rax
       setne    al
       movzx    rax, al
       test     eax, r13d
       jne      G_M000_IG445
       cmp      r14d, dword ptr [rdi+0x08]
       jae      G_M000_IG522
       mov      eax, r14d
       shl      rax, 4
       mov      r12, gword ptr [rdi+rax+0x10]
       test     r12, r12
       jne      G_M000_IG67
 
G_M000_IG171:                ;; offset=0x10C5
       mov      edx, r14d
       shl      rdx, 4
       lea      r12, bword ptr [rdi+rdx+0x10]
       mov      rdx, gword ptr [rbp-0x2E8]
       mov      rcx, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, qword ptr [rbp-0x2E0]
       mov      qword ptr [r12+0x08], rcx
       test     r13d, r13d
       je       G_M000_IG65
 
G_M000_IG172:                ;; offset=0x10F5
       cmp      byte  ptr [rsi+0xF2], 0
       jne      G_M000_IG446
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG65
       mov      rcx, gword ptr [rbp+0x20]
       cmp      byte  ptr [rcx+0xFF], 0
       je       G_M000_IG65
       jmp      G_M000_IG446
 
G_M000_IG173:                ;; offset=0x1123
       cmp      gword ptr [rbp+0x20], 0
       jne      G_M000_IG87
       jmp      G_M000_IG284
 
G_M000_IG174:                ;; offset=0x1133
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG284
 
G_M000_IG175:                ;; offset=0x113E
       cmp      byte  ptr [rbp+0x28], 0
       jne      G_M000_IG509
       jmp      G_M000_IG87
 
G_M000_IG176:                ;; offset=0x114D
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteSequenceIndex(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG07
 
G_M000_IG177:                ;; offset=0x116E
       movzx    r11, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], r11d
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x28], rax
       mov      r10, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x30], r10
       mov      r8, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x38], r8
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteInputInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref,byref):int]
       test     eax, eax
       je       G_M000_IG07
 
G_M000_IG178:                ;; offset=0x11B4
       mov      dword ptr [rbp-0x74], eax
       jmp      G_M000_IG527
 
G_M000_IG179:                ;; offset=0x11BC
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG284
 
G_M000_IG180:                ;; offset=0x11C7
       cmp      byte  ptr [rbp+0x28], 0
       jne      SHORT G_M000_IG184
 
G_M000_IG181:                ;; offset=0x11CD
       mov      r11, bword ptr [rbp-0x360]
 
G_M000_IG182:                ;; offset=0x11D4
       vmovdqu  ymm0, ymmword ptr [r11]
       vmovdqu  ymmword ptr [rbp-0x340], ymm0
 
G_M000_IG183:                ;; offset=0x11E1
       lea      r8, [rbp-0x340]
       lea      rdx, [rbp-0x88]
       mov      rcx, gword ptr [rbp+0x20]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       mov      rbx, gword ptr [rbp-0x88]
       movsx    rsi, word  ptr [rbp-0x80]
       test     rbx, rbx
       je       G_M000_IG07
       jmp      G_M000_IG350
 
G_M000_IG184:                ;; offset=0x1216
       mov      r11, bword ptr [rbp-0x360]
 
G_M000_IG185:                ;; offset=0x121D
       vmovdqu  ymm0, ymmword ptr [r11]
       vmovdqu  ymmword ptr [rbp-0x340], ymm0
 
G_M000_IG186:                ;; offset=0x122A
       lea      r8, [rbp-0x340]
       lea      rdx, [rbp-0x200]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteTargetInstruction(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x210]
       lea      rdx, [rbp-0x200]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0x210]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x208]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       G_M000_IG258
       jmp      G_M000_IG352
 
G_M000_IG187:                ;; offset=0x1292
       movzx    r11, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], r11d
       lea      r11, [rbp-0x68]
       mov      qword ptr [rsp+0x28], r11
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecutePreparedOperation(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG284
 
G_M000_IG188:                ;; offset=0x12C6
       cmp      byte  ptr [rbp+0x28], 0
       jne      G_M000_IG368
 
G_M000_IG189:                ;; offset=0x12D0
       mov      rbx, gword ptr [rbp-0x68]
       movsx    rsi, word  ptr [rbp-0x60]
       test     rbx, rbx
       je       G_M000_IG07
       jmp      G_M000_IG366
 
G_M000_IG190:                ;; offset=0x12E7
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG284
 
G_M000_IG191:                ;; offset=0x12F2
       mov      rcx, bword ptr [rbp+0x10]
       mov      r11, gword ptr [rcx]
       mov      rbx, gword ptr [r11+0x38]
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG522
       mov      ecx, eax
       mov      rcx, gword ptr [rbx+8*rcx+0x10]
       mov      rdx, bword ptr [rbp-0x360]
       mov      rdx, gword ptr [rdx]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveName(System.String,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool):System.Object]
       mov      rdx, rax
       lea      rcx, [rbp-0x288]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x288]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG07
 
G_M000_IG192:                ;; offset=0x1365
       mov      rcx, bword ptr [rbp+0x10]
       mov      rbx, gword ptr [rcx]
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       mov      edx, eax
       mov      rcx, rbx
       mov      r8, bword ptr [rbp-0x360]
       mov      r8, gword ptr [r8]
       mov      r9, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:ResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      gword ptr [rbp-0x320], rax
       xor      r9d, r9d
       mov      qword ptr [rbp-0x318], r9
       lea      r9, [rbp-0x320]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x360]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG07
 
G_M000_IG193:                ;; offset=0x13C4
       mov      rcx, bword ptr [rbp+0x10]
       cmp      gword ptr [rcx+0x40], 0
       jne      SHORT G_M000_IG195
 
G_M000_IG194:                ;; offset=0x13CF
       mov      rdx, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rdx
       mov      rcx, gword ptr [rcx]
       mov      r14, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [r14+0x18]
       mov      r8d, dword ptr [r14+0x10]
       mov      r9d, dword ptr [r14+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryExecuteClosureArithmetic(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      G_M000_IG349
 
G_M000_IG195:                ;; offset=0x13F9
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ClosureSlot():int:this]
       mov      r8d, eax
       lea      r9, [rbp-0x48]
       mov      qword ptr [rsp+0x20], r9
       mov      r9, bword ptr [rbp-0x360]
       mov      r9, gword ptr [r9]
       mov      rdx, gword ptr [rbp+0x20]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryLoadClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int,Lokad.Lython.LythonSourceSpan,byref):bool]
       test     eax, eax
       je       G_M000_IG284
 
G_M000_IG196:                ;; offset=0x1432
       mov      rdx, gword ptr [rbp-0x48]
       lea      rcx, [rbp-0x278]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x278]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG07
 
G_M000_IG197:                ;; offset=0x1464
       lea      rbx, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp+0x10]
       jmp      G_M000_IG52
 
G_M000_IG198:                ;; offset=0x1489
       mov      r12, 0x7FF9D77E4838
       cmp      qword ptr [r13], r12
       jne      G_M000_IG63
 
G_M000_IG199:                ;; offset=0x149D
       lea      rcx, [rbp-0x268]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77F2610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      rdx, rax
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableCell:set_Value(System.Object):this]
       jmp      G_M000_IG65
 
G_M000_IG200:                ;; offset=0x14CE
       cmp      ebx, 71
       je       G_M000_IG341
       cmp      ebx, 30
       jne      G_M000_IG346
       cmp      gword ptr [rbp-0x258], 0
       jne      G_M000_IG65
       jmp      G_M000_IG347
 
G_M000_IG201:                ;; offset=0x14F3
       mov      rcx, bword ptr [rbp+0x10]
       mov      r11, gword ptr [rcx]
       mov      r11, gword ptr [r11+0x30]
       mov      rbx, r11
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG522
       mov      ecx, eax
       mov      rcx, gword ptr [rbx+8*rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      rbx, rax
       mov      rcx, bword ptr [rbp-0x360]
       cmp      dword ptr [rcx+0x18], 0
       jl       SHORT G_M000_IG207
 
G_M000_IG202:                ;; offset=0x1534
       mov      r14, bword ptr [rbp+0x10]
       lea      rsi, bword ptr [r14+0x20]
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      edi, eax
       mov      rcx, bword ptr [rbp-0x360]
       mov      r15d, dword ptr [rcx+0x18]
       test     r15d, r15d
       jl       SHORT G_M000_IG206
 
G_M000_IG203:                ;; offset=0x155B
       cmp      r15d, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG205
 
G_M000_IG204:                ;; offset=0x1561
       mov      rcx, rsi
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG205:                ;; offset=0x156D
       mov      rcx, gword ptr [rsi]
       cmp      edi, dword ptr [rcx+0x08]
       jae      G_M000_IG522
       mov      edx, edi
       shl      rdx, 4
       lea      rdi, bword ptr [rcx+rdx+0x10]
       mov      rcx, rdi
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       xor      r9d, r9d
       mov      qword ptr [rdi+0x08], r9
       mov      dword ptr [rsi+0x40], r15d
       jmp      G_M000_IG07
 
G_M000_IG206:                ;; offset=0x159F
       not      r15d
       jmp      SHORT G_M000_IG203
 
G_M000_IG207:                ;; offset=0x15A4
       mov      r14, bword ptr [rbp+0x10]
       mov      gword ptr [rbp-0x320], rbx
       xor      r9d, r9d
       mov      qword ptr [rbp-0x318], r9
       lea      r9, [rbp-0x320]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x360]
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteResultConsumer(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG07
 
G_M000_IG208:                ;; offset=0x15D9
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG284
 
G_M000_IG209:                ;; offset=0x15E4
       mov      rcx, bword ptr [rbp+0x10]
       mov      r11, gword ptr [rcx]
       mov      rbx, gword ptr [r11+0xA8]
       mov      rcx, bword ptr [rbp-0x360]
       xor      edx, edx
       mov      r8, 0x2C171C94708
       call     [Lokad.Lython.Frontend.ExecutableInstruction:ReadPrimaryOperand(int,System.String):int:this]
       mov      rcx, 0x7FF9D76385C0
       cmp      qword ptr [rbx], rcx
       jne      G_M000_IG401
       mov      ecx, dword ptr [rbx+0x08]
       cmp      ecx, eax
       jbe      G_M000_IG336
       mov      eax, eax
       mov      rdx, gword ptr [rbx+8*rax+0x10]
 
G_M000_IG210:                ;; offset=0x1630
       cmp      byte  ptr [rbp+0x28], 0
       jne      G_M000_IG402
 
G_M000_IG211:                ;; offset=0x163A
       mov      r14, bword ptr [rbp+0x10]
       mov      rcx, gword ptr [r14]
       mov      r8, gword ptr [r14+0x08]
       mov      r9, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteExecutableImport(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext)]
       jmp      G_M000_IG07
 
G_M000_IG212:                ;; offset=0x1654
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x100], ymm0
       vmovdqu  xmmword ptr [rbp-0xE8], xmm0
       lea      rcx, [rbp-0x100]
       mov      edx, 27
       mov      r8d, 1
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:.ctor(int,int):this]
 
G_M000_IG213:                ;; offset=0x1680
       vmovdqu  ymm0, ymmword ptr [rbp-0x100]
       vmovdqu  ymmword ptr [rbp-0xD8], ymm0
       mov      rcx, qword ptr [rbp-0xE0]
       mov      qword ptr [rbp-0xB8], rcx
 
G_M000_IG214:                ;; offset=0x169E
       mov      ecx, dword ptr [rbp-0xC8]
       cmp      ecx, dword ptr [rbp-0xB8]
       ja       G_M000_IG363
       mov      rdx, bword ptr [rbp-0xC0]
       mov      eax, ecx
       lea      rdx, bword ptr [rdx+2*rax]
       mov      eax, dword ptr [rbp-0xB8]
       sub      eax, ecx
       cmp      eax, 27
       jb       G_M000_IG523
 
G_M000_IG215:                ;; offset=0x16CE
       vmovups  ymm0, ymmword ptr [reloc @RWD296]
       vmovups  ymmword ptr [rdx], ymm0
       vmovups  xmm0, xmmword ptr [reloc @RWD328]
       vmovups  xmmword ptr [rdx+0x20], xmm0
       mov      dword ptr [rdx+0x30], 0x3A0065
       mov      word  ptr [rdx+0x34], 32
       mov      ecx, dword ptr [rbp-0xC8]
       add      ecx, 27
       mov      dword ptr [rbp-0xC8], ecx
 
G_M000_IG216:                ;; offset=0x1703
       mov      rdx, bword ptr [rbp-0x360]
       mov      edx, dword ptr [rdx+0x1C]
       lea      rcx, [rbp-0xD8]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:AppendFormatted[int](int):this]
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       lea      rcx, [rbp-0xD8]
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:ToStringAndClear():System.String:this]
       mov      rdx, rax
       mov      rcx, rbx
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG217:                ;; offset=0x174E
       mov      r11, bword ptr [rbp-0x360]
       mov      r11d, dword ptr [r11+0x1C]
       cmp      r11d, 51
       ja       SHORT G_M000_IG219
 
G_M000_IG218:                ;; offset=0x175F
       mov      rbx, 0x7FFFFFFFFF9FF
       bt       rbx, r11
       jae      G_M000_IG466
 
G_M000_IG219:                ;; offset=0x1773
       mov      r11, bword ptr [rbp-0x360]
       mov      ebx, dword ptr [r11+0x14]
 
G_M000_IG220:                ;; offset=0x177E
       mov      rcx, bword ptr [rbp+0x10]
       cmp      dword ptr [rcx+0x60], ebx
       jne      G_M000_IG231
 
G_M000_IG221:                ;; offset=0x178B
       mov      r11, bword ptr [rbp-0x360]
       mov      r11d, dword ptr [r11+0x10]
       mov      rsi, gword ptr [rcx]
       mov      rdi, gword ptr [rcx+0x20]
       test     rdi, rdi
       je       G_M000_IG467
       lea      r14, bword ptr [rdi+0x10]
       mov      edi, dword ptr [rdi+0x08]
 
G_M000_IG222:                ;; offset=0x17AD
       mov      bword ptr [rbp-0x310], r14
       mov      dword ptr [rbp-0x308], edi
       xor      edi, edi
       mov      dword ptr [rsp+0x20], edi
       mov      rdx, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rbp-0x310]
       mov      r9d, dword ptr [rcx+0x10]
       mov      rcx, rsi
       mov      r8d, r11d
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rsi, rax
       mov      rdx, bword ptr [rbp-0x360]
       mov      r8d, dword ptr [rdx+0x0C]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx]
       mov      rdx, gword ptr [rcx+0x20]
       test     rdx, rdx
       je       G_M000_IG468
       lea      r9, bword ptr [rdx+0x10]
       mov      edx, dword ptr [rdx+0x08]
 
G_M000_IG223:                ;; offset=0x1809
       mov      bword ptr [rbp-0x310], r9
       mov      dword ptr [rbp-0x308], edx
       mov      dword ptr [rsp+0x20], 1
       mov      rdx, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x28], rdx
       lea      rdx, [rbp-0x310]
       mov      r9d, dword ptr [rcx+0x10]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableOperand(Lokad.Lython.Frontend.ExecutableCodeObject,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],int,int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rdi, rax
       mov      rcx, rsi
       test     rcx, rcx
       je       SHORT G_M000_IG225
 
G_M000_IG224:                ;; offset=0x1846
       mov      rdx, 0x7FF9D77E3D68
       cmp      qword ptr [rcx], rdx
       jne      G_M000_IG469
       xor      rcx, rcx
 
G_M000_IG225:                ;; offset=0x185B
       test     rcx, rcx
       jne      G_M000_IG470
 
G_M000_IG226:                ;; offset=0x1864
       mov      rcx, bword ptr [rbp+0x10]
       lea      r14, bword ptr [rcx+0x20]
       lea      r15d, [rbx+0x01]
       cmp      r15d, dword ptr [r14+0x40]
       jge      SHORT G_M000_IG228
 
G_M000_IG227:                ;; offset=0x1876
       mov      rcx, r14
       mov      edx, r15d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG228:                ;; offset=0x1882
       mov      rdx, gword ptr [r14]
       cmp      ebx, dword ptr [rdx+0x08]
       jae      G_M000_IG522
       mov      eax, ebx
       shl      rax, 4
       lea      r13, bword ptr [rdx+rax+0x10]
       mov      rcx, r13
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [r13+0x08], rcx
       mov      dword ptr [r14+0x40], r15d
       mov      rcx, bword ptr [rbp+0x10]
       lea      rsi, bword ptr [rcx+0x20]
       lea      r14d, [rbx+0x02]
       cmp      r14d, dword ptr [rsi+0x40]
       jge      SHORT G_M000_IG230
 
G_M000_IG229:                ;; offset=0x18C0
       mov      rcx, rsi
       mov      edx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG230:                ;; offset=0x18CC
       mov      rdx, gword ptr [rsi]
       lea      eax, [rbx+0x01]
       cmp      eax, dword ptr [rdx+0x08]
       jae      G_M000_IG522
       inc      ebx
       mov      eax, ebx
       shl      rax, 4
       lea      rbx, bword ptr [rdx+rax+0x10]
       mov      rcx, rbx
       mov      rdx, rdi
       call     CORINFO_HELP_ASSIGN_REF
       xor      ecx, ecx
       mov      qword ptr [rbx+0x08], rcx
       mov      dword ptr [rsi+0x40], r14d
 
G_M000_IG231:                ;; offset=0x18FD
       mov      rcx, bword ptr [rbp+0x10]
       mov      r11, gword ptr [rcx]
       mov      r11, gword ptr [r11+0xB0]
       mov      rbx, bword ptr [rbp-0x360]
       mov      ebx, dword ptr [rbx+0x1C]
       cmp      ebx, 42
       jne      G_M000_IG475
 
G_M000_IG232:                ;; offset=0x191E
       mov      rbx, bword ptr [rbp-0x360]
       mov      ebx, dword ptr [rbx+0x08]
       mov      rsi, 0x7FF9D7638680
       cmp      qword ptr [r11], rsi
       jne      G_M000_IG476
       cmp      dword ptr [r11+0x08], ebx
       jbe      G_M000_IG336
       cmp      ebx, dword ptr [r11+0x08]
       jae      G_M000_IG522
       mov      rbx, gword ptr [r11+8*rbx+0x10]
 
G_M000_IG233:                ;; offset=0x1954
       mov      r11, bword ptr [rbp-0x360]
       mov      r11d, dword ptr [r11+0x1C]
       cmp      r11d, 51
       ja       SHORT G_M000_IG235
 
G_M000_IG234:                ;; offset=0x1965
       mov      rsi, 0x7FFFFFFFFF9FF
       bt       rsi, r11
       jae      G_M000_IG477
 
G_M000_IG235:                ;; offset=0x1979
       mov      r11, bword ptr [rbp-0x360]
       mov      esi, dword ptr [r11+0x14]
 
G_M000_IG236:                ;; offset=0x1984
       mov      rcx, bword ptr [rbp+0x10]
       lea      r11, bword ptr [rcx+0x20]
       cmp      byte  ptr [rbx], bl
       mov      r11, gword ptr [r11]
       cmp      byte  ptr [rbx+0x30], 0
       setne    dil
       movzx    rdi, dil
       add      edi, esi
       cmp      edi, dword ptr [r11+0x08]
       jae      G_M000_IG522
       shl      rdi, 4
       lea      r11, bword ptr [r11+rdi+0x10]
       mov      rdi, gword ptr [r11]
       mov      r14, 0x2A14B001CE0
       cmp      rdi, gword ptr [r14]
       je       G_M000_IG478
 
G_M000_IG237:                ;; offset=0x19C8
       mov      rdi, gword ptr [r11]
       mov      r14, 0x2A14B001CE8
       cmp      rdi, gword ptr [r14]
       je       G_M000_IG479
       cmp      qword ptr [r11+0x08], 0
       jne      G_M000_IG480
       mov      rdi, gword ptr [r11]
 
G_M000_IG238:                ;; offset=0x19EC
       test     rdi, rdi
       je       G_M000_IG481
       mov      dword ptr [rsp+0x20], esi
       mov      gword ptr [rsp+0x28], rdi
       lea      r11, [rbp-0x70]
       mov      qword ptr [rsp+0x30], r11
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteNativeCall(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       G_M000_IG289
 
G_M000_IG239:                ;; offset=0x1A24
       cmp      gword ptr [rbp-0x70], 0
       je       G_M000_IG07
 
G_M000_IG240:                ;; offset=0x1A2F
       mov      rdx, gword ptr [rbp-0x70]
       mov      rcx, 0x7FF9D74F0AF8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r14, rax
       test     r14, r14
       je       G_M000_IG285
 
G_M000_IG241:                ;; offset=0x1A4E
       jmp      G_M000_IG529
 
G_M000_IG242:                ;; offset=0x1A53
       not      esi
       mov      r11, gword ptr [rdi+0x30]
       cmp      dword ptr [r11+0x08], esi
       jg       G_M000_IG499
 
G_M000_IG243:                ;; offset=0x1A63
       mov      r14, gword ptr [rdi+0x38]
       mov      r13d, esi
       sub      r13d, dword ptr [r11+0x08]
       cmp      r13d, dword ptr [r14+0x08]
       jae      G_M000_IG522
       mov      r14, gword ptr [r14+8*r13+0x10]
       sub      esi, dword ptr [r11+0x08]
       mov      edx, esi
       lea      r9, [rbp-0x300]
       mov      rcx, rdi
       mov      r8, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryResolveExecutableGlobal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG500
       mov      r14, gword ptr [rbp-0x300]
       jmp      G_M000_IG79
 
G_M000_IG244:                ;; offset=0x1AAB
       mov      r9, bword ptr [rbp-0x360]
       mov      ecx, dword ptr [r9+0x18]
       mov      r9d, ecx
       not      r9d
       jmp      G_M000_IG84
 
G_M000_IG245:                ;; offset=0x1AC1
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG111
 
G_M000_IG246:                ;; offset=0x1AE2
       mov      dword ptr [rbp-0x3C], 1
       jmp      G_M000_IG07
 
G_M000_IG247:                ;; offset=0x1AEE
       mov      r11, gword ptr [rbp+0x20]
       mov      rbx, r11
       test     rbx, rbx
       jne      SHORT G_M000_IG249
 
G_M000_IG248:                ;; offset=0x1AFA
       mov      rdx, gword ptr [rbp+0x18]
       mov      rbx, rdx
 
G_M000_IG249:                ;; offset=0x1B01
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, r11
       mov      r8, bword ptr [rbp-0x360]
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteFormattedInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):bool]
       test     eax, eax
       jne      G_M000_IG07
 
G_M000_IG250:                ;; offset=0x1B20
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG284
 
G_M000_IG251:                ;; offset=0x1B2B
       cmp      byte  ptr [rbp+0x28], 0
       jne      SHORT G_M000_IG255
 
G_M000_IG252:                ;; offset=0x1B31
       mov      r8, bword ptr [rbp-0x360]
 
G_M000_IG253:                ;; offset=0x1B38
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x340], ymm0
 
G_M000_IG254:                ;; offset=0x1B45
       lea      r8, [rbp-0x340]
       lea      rdx, [rbp-0x88]
       mov      rcx, gword ptr [rbp+0x20]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       mov      rbx, gword ptr [rbp-0x88]
       movsx    rsi, word  ptr [rbp-0x80]
       test     rbx, rbx
       je       G_M000_IG07
       jmp      G_M000_IG356
 
G_M000_IG255:                ;; offset=0x1B7A
       mov      r8, bword ptr [rbp-0x360]
 
G_M000_IG256:                ;; offset=0x1B81
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x340], ymm0
 
G_M000_IG257:                ;; offset=0x1B8E
       lea      r8, [rbp-0x340]
       lea      rdx, [rbp-0x120]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r9d, 1
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteFormattedValueAsync(Lokad.Lython.Frontend.ExecutableInstruction,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x130]
       lea      rdx, [rbp-0x120]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0x130]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x128]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       jne      G_M000_IG358
 
G_M000_IG258:                ;; offset=0x1BF1
       mov      rax, bword ptr [rbp+0x30]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG07
 
G_M000_IG259:                ;; offset=0x1C03
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG284
 
G_M000_IG260:                ;; offset=0x1C0E
       cmp      byte  ptr [rbp+0x28], 0
       je       G_M000_IG394
       jmp      G_M000_IG387
 
G_M000_IG261:                ;; offset=0x1C1D
       mov      rcx, gword ptr [rbp+0x20]
       cmp      byte  ptr [rcx+0xF9], 0
       je       G_M000_IG07
       jmp      G_M000_IG399
 
G_M000_IG262:                ;; offset=0x1C33
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG284
 
G_M000_IG263:                ;; offset=0x1C3E
       mov      rcx, bword ptr [rbp+0x10]
       lea      rsi, bword ptr [rcx+0x20]
       mov      r11, bword ptr [rbp-0x360]
       mov      edi, dword ptr [r11+0x10]
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      r9d, eax
       mov      r8d, edi
       mov      rcx, rsi
       lea      rdx, [rbp-0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeSlotValue(int,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:this]
       mov      rcx, bword ptr [rbp+0x10]
       mov      esi, dword ptr [rcx+0x10]
       inc      esi
       mov      rax, gword ptr [rbp+0x20]
       mov      rdi, gword ptr [rax+0x70]
       cmp      byte  ptr [rax+0x101], 0
       je       G_M000_IG373
 
G_M000_IG264:                ;; offset=0x1C92
       xor      r15d, r15d
 
G_M000_IG265:                ;; offset=0x1C95
       test     r15d, r15d
       jne      G_M000_IG376
 
G_M000_IG266:                ;; offset=0x1C9E
       mov      rax, gword ptr [rbp+0x20]
       lea      rbx, bword ptr [rax+0x190]
       mov      rdx, gword ptr [rbp-0x98]
       mov      rcx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, qword ptr [rbp-0x90]
       mov      qword ptr [rbx+0x08], rcx
       mov      rax, gword ptr [rbp+0x20]
       mov      word  ptr [rax+0xF8], 257
       mov      rcx, bword ptr [rbp+0x10]
       inc      dword ptr [rcx+0x10]
       test     r15d, r15d
       je       G_M000_IG385
 
G_M000_IG267:                ;; offset=0x1CE0
       mov      dword ptr [rbp-0x74], 1
       jmp      G_M000_IG527
 
G_M000_IG268:                ;; offset=0x1CEC
       mov      rcx, bword ptr [rbp+0x10]
       lea      rbx, bword ptr [rcx+0x20]
       mov      r11, bword ptr [rbp-0x360]
       mov      esi, dword ptr [r11+0x10]
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ItemCount():int:this]
       mov      r8d, eax
       mov      rdx, gword ptr [rbp+0x18]
       mov      gword ptr [rsp+0x20], rdx
       mov      edx, esi
       mov      rcx, rbx
       mov      r9, bword ptr [rbp-0x360]
       mov      r9, gword ptr [r9]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateListFromStack(byref,int,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.PyList]
       mov      rdx, rax
       lea      rcx, [rbp-0x2A8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x2A8]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG07
 
G_M000_IG269:                ;; offset=0x1D5E
       mov      r11, bword ptr [rbp-0x360]
       mov      edx, dword ptr [r11+0x10]
       mov      rcx, bword ptr [rbp+0x10]
       add      rcx, 32
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      rbx, bword ptr [rbp+0x10]
       lea      rsi, bword ptr [rbx+0x20]
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       jmp      G_M000_IG07
 
G_M000_IG270:                ;; offset=0x1D9C
       mov      rcx, bword ptr [rbp+0x10]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       lea      esi, [rax+0x01]
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edi, eax
       mov      rdx, bword ptr [rbp-0x360]
       mov      edx, dword ptr [rdx+0x10]
       mov      r14, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [r14+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      rdx, rax
       lea      rcx, [rbp-0x298]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:FromObject(System.Object):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]
       lea      r9, [rbp-0x298]
       mov      rcx, rbx
       mov      edx, esi
       mov      r8d, edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishSlot(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG07
 
G_M000_IG271:                ;; offset=0x1E05
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG284
 
G_M000_IG272:                ;; offset=0x1E10
       mov      rcx, bword ptr [rbp+0x10]
       mov      rbx, gword ptr [rcx]
       mov      rsi, gword ptr [rcx+0x08]
       mov      r11, gword ptr [rcx]
       mov      rdi, gword ptr [r11+0x38]
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG522
       mov      ecx, eax
       mov      rdi, gword ptr [rdi+8*rcx+0x10]
       mov      r14, bword ptr [rbp+0x10]
       lea      rcx, bword ptr [r14+0x20]
       mov      rdx, bword ptr [rbp-0x360]
       mov      edx, dword ptr [rdx+0x10]
       mov      r8, bword ptr [rbp-0x360]
       mov      r8d, dword ptr [r8+0x18]
       test     r8d, r8d
       jl       SHORT G_M000_IG274
 
G_M000_IG273:                ;; offset=0x1E61
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      r9, rax
       mov      rdx, gword ptr [rbp+0x20]
       mov      gword ptr [rsp+0x20], rdx
       mov      r8, bword ptr [rbp-0x360]
       mov      r8, gword ptr [r8]
       mov      gword ptr [rsp+0x28], r8
       mov      rdx, rsi
       mov      r8, rdi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:AssignExecutableBoundName(Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot[],System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG07
 
G_M000_IG274:                ;; offset=0x1E96
       not      r8d
       jmp      SHORT G_M000_IG273
 
G_M000_IG275:                ;; offset=0x1E9B
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG284
 
G_M000_IG276:                ;; offset=0x1EA6
       mov      rcx, bword ptr [rbp+0x10]
       mov      r11, gword ptr [rcx]
       mov      rbx, gword ptr [r11+0x38]
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_NameIndex():int:this]
       cmp      eax, dword ptr [rbx+0x08]
       jae      G_M000_IG522
       mov      ecx, eax
       mov      rbx, gword ptr [rbx+8*rcx+0x10]
       mov      r14, bword ptr [rbp+0x10]
       lea      rsi, bword ptr [r14+0x20]
       mov      rcx, bword ptr [rbp-0x360]
       mov      edi, dword ptr [rcx+0x10]
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
       mov      edx, edi
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      rdx, rax
       mov      rcx, rbx
       mov      r9, bword ptr [rbp-0x360]
       mov      r9, gword ptr [r9]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreName(System.String,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG07
 
G_M000_IG277:                ;; offset=0x1F1A
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryStoreClosure(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG07
       jmp      G_M000_IG284
 
G_M000_IG278:                ;; offset=0x1F3C
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:StoreExecutableLocal(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG07
 
G_M000_IG279:                ;; offset=0x1F5A
       cmp      gword ptr [rbp+0x20], 0
       je       SHORT G_M000_IG284
 
G_M000_IG280:                ;; offset=0x1F61
       mov      r11, bword ptr [rbp-0x360]
       mov      rdx, gword ptr [r11]
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:PreloadImplicitSuperArguments(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG07
 
G_M000_IG281:                ;; offset=0x1F7A
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryLoadDirectCallReceiver(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       jne      G_M000_IG07
       jmp      G_M000_IG406
 
G_M000_IG282:                ;; offset=0x1FA0
       mov      r11, bword ptr [rbp-0x360]
       mov      r11d, dword ptr [r11+0x1C]
       cmp      r11d, 58
       ja       SHORT G_M000_IG284
 
G_M000_IG283:                ;; offset=0x1FB1
       mov      rbx, 0x1FDFFFFFFFFFFFF
       bt       rbx, r11
       jae      G_M000_IG305
 
G_M000_IG284:                ;; offset=0x1FC5
       mov      dword ptr [rbp-0x74], 6
       jmp      G_M000_IG527
 
G_M000_IG285:                ;; offset=0x1FD1
       mov      rdx, gword ptr [rbp-0x70]
       mov      rax, rdx
       test     rax, rax
       je       SHORT G_M000_IG287
 
G_M000_IG286:                ;; offset=0x1FDD
       mov      rcx, 0x7FF9D76A9D18
       cmp      qword ptr [rax], rcx
       jne      G_M000_IG482
 
G_M000_IG287:                ;; offset=0x1FF0
       xor      rcx, rcx
       mov      r8, bword ptr [rbp+0x40]
       mov      gword ptr [r8], rcx
       lea      rcx, bword ptr [r8+0x08]
       mov      rdx, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      r8, bword ptr [rbp+0x40]
       mov      word  ptr [r8+0x10], 0
       mov      byte  ptr [r8+0x12], 1
 
G_M000_IG288:                ;; offset=0x2015
       mov      rdx, gword ptr [rbx+0x18]
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0x74], 3
       jmp      G_M000_IG527
 
G_M000_IG289:                ;; offset=0x202E
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG483
 
G_M000_IG290:                ;; offset=0x2039
       movzx    rcx, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], ecx
       mov      r8, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x28], r8
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, rbx
       mov      r8d, esi
       mov      r9, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBeginExecutableCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG293
 
G_M000_IG291:                ;; offset=0x2061
       cmp      byte  ptr [rbp+0x28], 0
       jne      G_M000_IG494
 
G_M000_IG292:                ;; offset=0x206B
       mov      gword ptr [rsp+0x20], rdi
       xor      edx, edx
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp-0x88]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r8, rbx
       mov      r9d, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       mov      rbx, gword ptr [rbp-0x88]
       movsx    rsi, word  ptr [rbp-0x80]
       test     rbx, rbx
       je       G_M000_IG07
       jmp      G_M000_IG492
 
G_M000_IG293:                ;; offset=0x20A7
       mov      r8, bword ptr [rbp+0x40]
       mov      r14, gword ptr [r8]
       test     r14, r14
       je       SHORT G_M000_IG295
 
G_M000_IG294:                ;; offset=0x20B3
       mov      rdx, r14
       mov      rcx, 0x7FF9D7885E98
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       G_M000_IG487
       jmp      G_M000_IG486
 
G_M000_IG295:                ;; offset=0x20D3
       mov      r8, bword ptr [rbp+0x40]
       mov      rsi, gword ptr [r8]
       test     rsi, rsi
       jne      G_M000_IG488
       mov      rdi, gword ptr [r8+0x08]
 
G_M000_IG296:                ;; offset=0x20E7
       mov      rcx, gword ptr [rbp+0x20]
       cmp      rdi, rcx
       je       G_M000_IG491
       jmp      G_M000_IG288
 
G_M000_IG297:                ;; offset=0x20F9
       movzx    r11, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x20], r11d
       mov      rax, bword ptr [rbp+0x30]
       mov      bword ptr [rsp+0x28], rax
       mov      r10, bword ptr [rbp+0x38]
       mov      bword ptr [rsp+0x30], r10
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteComparisonInstruction(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,bool,byref,byref):int]
       test     eax, eax
       je       G_M000_IG142
 
G_M000_IG298:                ;; offset=0x2136
       mov      dword ptr [rbp-0x74], eax
       jmp      G_M000_IG527
 
G_M000_IG299:                ;; offset=0x213E
       mov      r11, bword ptr [rbp-0x360]
       mov      edx, dword ptr [r11+0x10]
       mov      rcx, bword ptr [rbp+0x10]
       mov      r8, gword ptr [rbp+0x18]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ReadOperand(byref,int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,int):System.Object]
       mov      rbx, rax
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG301
 
G_M000_IG300:                ;; offset=0x2164
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime:CanUseNativeTruth(System.Object):bool]
       test     eax, eax
       je       G_M000_IG284
 
G_M000_IG301:                ;; offset=0x2175
       cmp      byte  ptr [rbp+0x28], 0
       je       SHORT G_M000_IG303
 
G_M000_IG302:                ;; offset=0x217B
       test     rbx, rbx
       jne      G_M000_IG515
 
G_M000_IG303:                ;; offset=0x2184
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp-0x3C], eax
       jmp      G_M000_IG07
 
G_M000_IG304:                ;; offset=0x21A5
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG282
 
G_M000_IG305:                ;; offset=0x21B0
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteControlFlow(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       mov      dword ptr [rbp-0x3C], eax
       mov      rcx, bword ptr [rbp+0x10]
       cmp      gword ptr [rcx+0x68], 0
       je       G_M000_IG07
 
G_M000_IG306:                ;; offset=0x21DB
       cmp      byte  ptr [rbp+0x28], 0
       je       G_M000_IG267
 
G_M000_IG307:                ;; offset=0x21E5
       cmp      gword ptr [rcx+0x40], 0
       je       G_M000_IG267
 
G_M000_IG308:                ;; offset=0x21F0
       xor      rdx, rdx
       mov      rax, bword ptr [rbp+0x30]
       mov      gword ptr [rax], rdx
       mov      word  ptr [rax+0x08], 0
       movzx    rdx, byte  ptr [rbp-0x3C]
       mov      byte  ptr [rax+0x0A], dl
       mov      byte  ptr [rax+0x0B], 1
       mov      dword ptr [rbp-0x74], 5
       jmp      G_M000_IG527
 
G_M000_IG309:                ;; offset=0x2216
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteBuiltinArithmetic(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool]
       test     eax, eax
       je       G_M000_IG177
       jmp      G_M000_IG07
 
G_M000_IG310:                ;; offset=0x223C
       cmp      r11d, 72
       je       G_M000_IG16
       mov      rcx, bword ptr [rbp-0x360]
       mov      rdx, 0x2C171C8D5F8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG311:                ;; offset=0x2266
       mov      rcx, r11
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      rsi, rax
       jmp      G_M000_IG18
 
G_M000_IG312:                ;; offset=0x2277
       mov      rcx, r11
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      rsi, rax
       jmp      G_M000_IG18
 
G_M000_IG313:                ;; offset=0x2288
       mov      rcx, r11
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      rsi, rax
       jmp      G_M000_IG18
 
G_M000_IG314:                ;; offset=0x2299
       mov      rcx, rbx
       mov      edx, edi
       mov      r8, r14
       mov      r9, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rsi, rax
       jmp      G_M000_IG22
 
G_M000_IG315:                ;; offset=0x22B3
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edi, eax
       jmp      G_M000_IG26
 
G_M000_IG316:                ;; offset=0x22C7
       mov      r11, gword ptr [rsi]
       cmp      r13d, dword ptr [r11+0x08]
       jae      G_M000_IG522
       mov      r15d, r13d
       shl      r15, 4
       mov      r11, gword ptr [r11+r15+0x10]
       mov      rdx, r11
       mov      rcx, 0x7FF9D77E5D30
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r15, rax
       test     r15, r15
       je       G_M000_IG38
       cmp      gword ptr [rsi+0x28], 0
       jne      SHORT G_M000_IG317
       lea      rcx, bword ptr [rsi+0x20]
       mov      rdx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      SHORT G_M000_IG318
 
G_M000_IG317:                ;; offset=0x2313
       mov      rcx, gword ptr [rsi+0x28]
       lea      rcx, bword ptr [rcx+0x48]
       mov      rdx, r15
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG318:                ;; offset=0x2323
       lea      rcx, bword ptr [rsi+0x28]
       mov      rdx, r15
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, gword ptr [rsi]
       cmp      r13d, dword ptr [rdx+0x08]
       jae      G_M000_IG522
       mov      ecx, r13d
       shl      rcx, 4
       lea      rdx, bword ptr [rdx+rcx+0x10]
       xor      rcx, rcx
       mov      gword ptr [rdx], rcx
 
G_M000_IG319:                ;; offset=0x234D
       mov      qword ptr [rdx+0x08], rcx
       jmp      G_M000_IG43
 
G_M000_IG320:                ;; offset=0x2356
       mov      r12, gword ptr [r15+0x10]
       mov      r12d, dword ptr [r12+0x08]
       mov      dword ptr [rbp-0x374], r12d
       mov      r12, gword ptr [r10+0x10]
       mov      r8d, dword ptr [rbp-0x374]
       cmp      r8d, dword ptr [r12+0x08]
       jge      SHORT G_M000_IG322
       jmp      G_M000_IG49
 
G_M000_IG321:                ;; offset=0x237D
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:ReleaseStorage():this]
       jmp      G_M000_IG43
 
G_M000_IG322:                ;; offset=0x238B
       mov      rcx, r10
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:ReleaseStorage():this]
       jmp      G_M000_IG43
 
G_M000_IG323:                ;; offset=0x2399
       mov      rcx, r10
       mov      r10, qword ptr [r10]
       mov      r10, qword ptr [r10+0x40]
       call     [r10+0x20]Lokad.Lython.Runtime.ExecutableTemporaryValue:Dispose():this
       jmp      G_M000_IG43
 
G_M000_IG324:                ;; offset=0x23AC
       mov      r10, gword ptr [r15]
       mov      gword ptr [rbp-0x370], r10
       mov      rdx, r10
       mov      rcx, 0x7FF9D7753360
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG325
       mov      rdx, gword ptr [rbp-0x370]
       mov      rcx, 0x7FF9D71528A8
       call     CORINFO_HELP_ISINSTANCEOFARRAY
       test     rax, rax
       jne      SHORT G_M000_IG325
       mov      rdx, gword ptr [rbp-0x370]
       mov      rcx, 0x7FF9D76608D0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       sete     cl
       movzx    rcx, cl
       test     ecx, ecx
       jne      G_M000_IG42
 
G_M000_IG325:                ;; offset=0x240F
       mov      rax, gword ptr [r15]
       mov      gword ptr [rbp-0x368], rax
       xor      edx, edx
       mov      qword ptr [r15], rdx
       mov      qword ptr [r15+0x08], rdx
       mov      rdx, rax
       mov      rcx, 0x7FF9D71528A8
       call     CORINFO_HELP_ISINSTANCEOFARRAY
       test     rax, rax
       je       SHORT G_M000_IG326
       mov      ecx, dword ptr [rax+0x08]
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:RecordBytes(int):long]
       mov      rdx, rax
       mov      rcx, r12
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:Release(long):this]
       jmp      G_M000_IG43
 
G_M000_IG326:                ;; offset=0x2455
       mov      rcx, r12
       mov      rdx, gword ptr [rbp-0x368]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:RefundUnpublishedValue(System.Object):this]
       jmp      G_M000_IG43
 
G_M000_IG327:                ;; offset=0x246C
       mov      r10, gword ptr [r15]
       mov      r11, 0x2A14B001CE0
       cmp      r10, gword ptr [r11]
       je       G_M000_IG43
       mov      r10, gword ptr [r15]
       mov      r11, 0x2A14B001CE8
       cmp      r10, gword ptr [r11]
       je       G_M000_IG43
       xor      r10d, r10d
       mov      qword ptr [r15], r10
       mov      qword ptr [r15+0x08], r10
       mov      rcx, 0x7FF9D763E7B8
       call     [CORINFO_HELP_GET_NONGCSTATIC_BASE]
       mov      rdx, qword ptr [(reloc 0x7ff9d708b100)]
       mov      rcx, r12
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:Release(long):this]
       jmp      G_M000_IG43
 
G_M000_IG328:                ;; offset=0x24C9
       mov      ecx, 2
       call     [System.ThrowHelper:ThrowArgumentNullException(int)]
       int3     
 
G_M000_IG329:                ;; offset=0x24D5
       mov      r12d, dword ptr [r10+0x04]
       add      r12d, -24
       shr      r12d, 3
       mov      dword ptr [rbp-0x244], r12d
       movsxd   r12, r12d
       mov      r12d, dword ptr [r13+4*r12]
       mov      r8d, dword ptr [rbp-0x244]
       shl      r8d, 3
       movsxd   r8, r8d
       add      r13, r8
       jmp      G_M000_IG31
 
G_M000_IG330:                ;; offset=0x2506
       mov      rcx, r8
       mov      rdx, r11
       call     [System.SpanHelpers:ClearWithoutReferences(byref,nuint)]
       jmp      G_M000_IG33
 
G_M000_IG331:                ;; offset=0x2517
       cmp      dword ptr [r11+0x20], 0
       setne    r11b
       movzx    r11, r11b
       test     r11d, r11d
       je       G_M000_IG53
 
G_M000_IG332:                ;; offset=0x252D
       lea      rbx, bword ptr [rcx+0x20]
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      esi, eax
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
 
G_M000_IG333:                ;; offset=0x2550
       vmovdqu  xmm0, xmmword ptr [rbp-0x258]
       vmovdqu  xmmword ptr [rbp-0x320], xmm0
 
G_M000_IG334:                ;; offset=0x2560
       mov      edx, esi
       mov      rcx, rbx
       lea      r9, [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishSlot(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG07
 
G_M000_IG335:                ;; offset=0x2577
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r11d, eax
       jmp      G_M000_IG56
 
G_M000_IG336:                ;; offset=0x258C
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG337:                ;; offset=0x2593
       mov      rcx, r11
       mov      edx, edi
       mov      r11, 0x7FF9D7093FF8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r14, rax
       jmp      G_M000_IG61
 
G_M000_IG338:                ;; offset=0x25AD
       xor      r13, r13
       jmp      G_M000_IG62
 
G_M000_IG339:                ;; offset=0x25B5
       lea      rcx, [rbp-0x268]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77F2610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r8, rax
       mov      rdx, r14
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreGlobalNamespaceName(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.String,System.Object)]
       jmp      G_M000_IG65
 
G_M000_IG340:                ;; offset=0x25EA
       mov      r11, gword ptr [rbp+0x20]
       cmp      byte  ptr [r11], r11b
       mov      rcx, r11
       call     [Lokad.Lython.Runtime.ExecutionFrame:get_Variables():System.Collections.Generic.Dictionary`2[System.String,System.Object]:this]
       mov      rbx, rax
       mov      ecx, edi
       shl      rcx, 4
       lea      rcx, bword ptr [rsi+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77F2610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r8, rax
       cmp      byte  ptr [rbx], bl
       mov      rcx, rbx
       mov      rdx, r14
       mov      r9d, 1
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:TryInsert(System.__Canon,System.__Canon,byte):bool:this]
       jmp      G_M000_IG65
 
G_M000_IG341:                ;; offset=0x263D
       mov      rbx, gword ptr [rcx+0x20]
       test     rbx, rbx
       jne      SHORT G_M000_IG342
       xor      rsi, rsi
       xor      ebx, ebx
       jmp      SHORT G_M000_IG343
 
G_M000_IG342:                ;; offset=0x264C
       lea      rsi, bword ptr [rbx+0x10]
       mov      ebx, dword ptr [rbx+0x08]
 
G_M000_IG343:                ;; offset=0x2653
       mov      bword ptr [rbp-0x310], rsi
       mov      dword ptr [rbp-0x308], ebx
 
G_M000_IG344:                ;; offset=0x2660
       vmovdqu  xmm0, xmmword ptr [rbp-0x258]
       vmovdqu  xmmword ptr [rbp-0x320], xmm0
 
G_M000_IG345:                ;; offset=0x2670
       lea      rcx, [rbp-0x310]
       lea      r8, [rbp-0x320]
       mov      r14, bword ptr [rbp+0x10]
       mov      r9, gword ptr [r14+0x38]
       mov      rdx, r11
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG65
 
G_M000_IG346:                ;; offset=0x2694
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x2C171C92BE0
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG347:                ;; offset=0x26C2
       lea      rcx, [rbp-0x258]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77F2610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       jmp      G_M000_IG65
 
G_M000_IG348:                ;; offset=0x26E7
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx]
       mov      rbx, gword ptr [rax+0x68]
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LocalSlot():int:this]
       mov      edx, eax
       mov      rcx, rbx
       mov      r11, 0x7FF9D7093FE0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rcx, rax
       mov      rdx, bword ptr [rbp-0x360]
       mov      rdx, gword ptr [rdx]
       call     [Lokad.Lython.Runtime.RuntimeErrors:UnboundLocalVariable(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG349:                ;; offset=0x272D
       add      dword ptr [r14+0x10], 2
       jmp      G_M000_IG07
 
G_M000_IG350:                ;; offset=0x2737
       mov      rdx, rbx
       mov      rcx, 0x7FF9D74847C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG351
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG07
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG07
 
G_M000_IG351:                ;; offset=0x2773
       mov      rcx, rbx
       mov      edx, esi
       mov      r11, 0x7FF9D7094000
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG07
 
G_M000_IG352:                ;; offset=0x278A
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG353
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG354
 
G_M000_IG353:                ;; offset=0x27B2
       mov      rax, bword ptr [rbp+0x30]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7094008
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG354:                ;; offset=0x27D5
       test     esi, esi
       jne      G_M000_IG258
 
G_M000_IG355:                ;; offset=0x27DD
       mov      rcx, bword ptr [rbp-0x360]
       mov      rdx, gword ptr [rcx]
       mov      rcx, bword ptr [rbp+0x38]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      dword ptr [rbp-0x74], 4
       jmp      G_M000_IG527
 
G_M000_IG356:                ;; offset=0x27FC
       mov      rdx, rbx
       mov      rcx, 0x7FF9D74847C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG357
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG07
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG07
 
G_M000_IG357:                ;; offset=0x2838
       mov      rcx, rbx
       mov      edx, esi
       mov      r11, 0x7FF9D7094010
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG07
 
G_M000_IG358:                ;; offset=0x284F
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG359
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG360
 
G_M000_IG359:                ;; offset=0x2877
       mov      rax, bword ptr [rbp+0x30]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7094018
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG360:                ;; offset=0x289A
       test     esi, esi
       jne      G_M000_IG258
       jmp      G_M000_IG355
 
G_M000_IG361:                ;; offset=0x28A7
       mov      rax, rcx
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG362:                ;; offset=0x28B0
       or       edi, r14d
       je       SHORT G_M000_IG364
 
G_M000_IG363:                ;; offset=0x28B5
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG364:                ;; offset=0x28BC
       xor      rdx, rdx
       xor      r14d, r14d
       jmp      G_M000_IG106
 
G_M000_IG365:                ;; offset=0x28C6
       xor      r9, r9
       xor      r8d, r8d
       jmp      G_M000_IG98
 
G_M000_IG366:                ;; offset=0x28D1
       mov      rdx, rbx
       mov      rcx, 0x7FF9D74847C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG367
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG07
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG07
 
G_M000_IG367:                ;; offset=0x290D
       mov      rcx, rbx
       mov      edx, esi
       mov      r11, 0x7FF9D7094020
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG07
 
G_M000_IG368:                ;; offset=0x2924
       vmovdqu  xmm0, xmmword ptr [rbp-0x68]
       vmovdqu  xmmword ptr [rbp-0x350], xmm0
 
G_M000_IG369:                ;; offset=0x2931
       lea      rdx, [rbp-0x350]
       lea      rcx, [rbp-0x220]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0x220]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x218]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       G_M000_IG258
 
G_M000_IG370:                ;; offset=0x2976
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG371
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG372
 
G_M000_IG371:                ;; offset=0x299E
       mov      rax, bword ptr [rbp+0x30]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7094028
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG372:                ;; offset=0x29C1
       test     esi, esi
       jne      G_M000_IG258
       jmp      G_M000_IG355
 
G_M000_IG373:                ;; offset=0x29CE
       cmp      byte  ptr [rax+0xFF], 0
       jne      G_M000_IG264
 
G_M000_IG374:                ;; offset=0x29DB
       cmp      ebx, esi
       jle      G_M000_IG264
 
G_M000_IG375:                ;; offset=0x29E3
       cmp      esi, ebx
       jae      G_M000_IG522
       mov      r14d, esi
       shl      r14, 5
       mov      r9, gword ptr [rbp-0x358]
       cmp      dword ptr [r9+r14+0x2C], 30
       sete     r15b
       movzx    r15, r15b
       jmp      G_M000_IG265
 
G_M000_IG376:                ;; offset=0x2A0C
       test     rdi, rdi
       je       G_M000_IG266
 
G_M000_IG377:                ;; offset=0x2A15
       vmovdqu  xmm0, xmmword ptr [rbp-0x98]
       vmovdqu  xmmword ptr [rbp-0x320], xmm0
 
G_M000_IG378:                ;; offset=0x2A25
       lea      r8, [rbp-0x320]
       mov      rdx, rdi
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryAppendBufferedYield(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):bool:this]
       test     eax, eax
       je       G_M000_IG266
 
G_M000_IG379:                ;; offset=0x2A40
       cmp      esi, ebx
       jae      G_M000_IG522
       mov      r14d, esi
       shl      r14, 5
       mov      r9, gword ptr [rbp-0x358]
       mov      r15, gword ptr [r9+r14+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      rdi, gword ptr [rdx+0x98]
       cmp      byte  ptr [rdi], dil
       mov      rcx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG381
 
G_M000_IG380:                ;; offset=0x2A76
       mov      rcx, rdi
       mov      rdx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG381:                ;; offset=0x2A82
       mov      rdx, gword ptr [rbp+0x18]
       mov      rbx, gword ptr [rdx+0x98]
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_HasActiveHandler():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG383
 
G_M000_IG382:                ;; offset=0x2A9B
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [rcx+0x80]
       jmp      SHORT G_M000_IG384
 
G_M000_IG383:                ;; offset=0x2AA8
       mov      rdx, gword ptr [rbp+0x18]
       mov      rax, gword ptr [rdx+0x98]
       mov      rax, gword ptr [rax+0x148]
       mov      rdx, rax
 
G_M000_IG384:                ;; offset=0x2ABD
       lea      rcx, bword ptr [rbx+0x148]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rcx, bword ptr [rbp+0x10]
       lea      rbx, bword ptr [rcx+0x20]
       mov      r9, gword ptr [rbp-0x358]
       lea      rcx, bword ptr [r9+r14+0x10]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      edx, eax
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rcx, bword ptr [rbp+0x10]
       add      dword ptr [rcx+0x10], 2
       jmp      G_M000_IG10
 
G_M000_IG385:                ;; offset=0x2AFB
       test     rdi, rdi
       je       G_M000_IG267
 
G_M000_IG386:                ;; offset=0x2B04
       mov      rcx, rax
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG267
       jmp      G_M000_IG10
 
G_M000_IG387:                ;; offset=0x2B1D
       mov      r11, bword ptr [rbp-0x360]
 
G_M000_IG388:                ;; offset=0x2B24
       vmovdqu  ymm0, ymmword ptr [r11]
       vmovdqu  ymmword ptr [rbp-0x340], ymm0
 
G_M000_IG389:                ;; offset=0x2B31
       lea      r8, [rbp-0x340]
       lea      rdx, [rbp-0x150]
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteDelegationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0x150]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x148]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       SHORT G_M000_IG393
 
G_M000_IG390:                ;; offset=0x2B76
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG391
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG392
 
G_M000_IG391:                ;; offset=0x2B9E
       mov      rax, bword ptr [rbp+0x30]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7094030
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG392:                ;; offset=0x2BC1
       test     esi, esi
       je       G_M000_IG355
 
G_M000_IG393:                ;; offset=0x2BC9
       mov      rax, bword ptr [rbp+0x30]
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ConsumeOperation(byref):bool]
       jmp      G_M000_IG261
 
G_M000_IG394:                ;; offset=0x2BDB
       mov      r11, gword ptr [rbp+0x20]
       cmp      gword ptr [r11+0x68], 0
       jne      G_M000_IG396
 
G_M000_IG395:                ;; offset=0x2BEA
       mov      rcx, bword ptr [rbp+0x10]
       lea      rbx, bword ptr [rcx+0x20]
       mov      rsi, bword ptr [rbp-0x360]
       mov      esi, dword ptr [rsi+0x10]
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      r8d, eax
       mov      edx, esi
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TakeValue(int,int):System.Object:this]
       mov      rbx, rax
       mov      rcx, 0x7FF9D71528A8
       mov      edx, 1
       call     CORINFO_HELP_NEWARR_1_PTR
       mov      rsi, rax
       lea      rcx, bword ptr [rsi+0x10]
       mov      rdx, rbx
       call     CORINFO_HELP_ASSIGN_REF
       mov      rdx, bword ptr [rbp-0x360]
       mov      rdx, gword ptr [rdx]
       mov      rcx, rsi
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:Iter(System.Object[],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      rbx, rax
       mov      rcx, 0x7FF9D77E7DB8
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       mov      r9, bword ptr [rbp-0x360]
       mov      r9, gword ptr [r9]
       mov      rcx, rsi
       mov      rdx, rbx
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:.ctor(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):this]
       mov      r11, gword ptr [rbp+0x20]
       lea      rcx, bword ptr [r11+0x68]
       mov      rdx, rsi
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG396:                ;; offset=0x2C93
       mov      r11, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [r11+0x68]
       mov      r8, gword ptr [r11+0x58]
       mov      r9, gword ptr [r11+0x60]
       lea      rdx, [rbp-0x140]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+GeneratorDelegation:Advance(System.Object,Lokad.Lython.Runtime.LythonRuntimeException):Lokad.Lython.Runtime.PyIterationResult:this]
       mov      r8, bword ptr [rbp-0x360]
 
G_M000_IG397:                ;; offset=0x2CB9
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x340], ymm0
 
G_M000_IG398:                ;; offset=0x2CC6
       lea      r8, [rbp-0x340]
       lea      rdx, [rbp-0x140]
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteDelegatedStep(Lokad.Lython.Runtime.PyIterationResult,Lokad.Lython.Frontend.ExecutableInstruction):this]
       jmp      G_M000_IG261
 
G_M000_IG399:                ;; offset=0x2CE3
       mov      rdx, gword ptr [rcx+0x70]
       test     rdx, rdx
       je       G_M000_IG267
 
G_M000_IG400:                ;; offset=0x2CF0
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryBufferYield(System.Object):bool:this]
       test     eax, eax
       je       G_M000_IG267
       jmp      G_M000_IG10
 
G_M000_IG401:                ;; offset=0x2D03
       mov      rcx, rbx
       mov      edx, eax
       mov      r11, 0x7FF9D7093FF0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdx, rax
       jmp      G_M000_IG210
 
G_M000_IG402:                ;; offset=0x2D1D
       lea      rcx, [rbp-0x230]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:ExecuteImportAsync(Lokad.Lython.Frontend.ImportStatementSyntax,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Threading.Tasks.ValueTask]
       lea      rcx, [rbp-0x240]
       lea      rdx, [rbp-0x230]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0x240]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x238]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       G_M000_IG258
 
G_M000_IG403:                ;; offset=0x2D73
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG404
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG405
 
G_M000_IG404:                ;; offset=0x2D9B
       mov      rax, bword ptr [rbp+0x30]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7094038
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG405:                ;; offset=0x2DBE
       test     esi, esi
       jne      G_M000_IG258
       jmp      G_M000_IG355
 
G_M000_IG406:                ;; offset=0x2DCB
       cmp      gword ptr [rbp+0x20], 0
       je       G_M000_IG284
 
G_M000_IG407:                ;; offset=0x2DD6
       cmp      byte  ptr [rbp+0x28], 0
       jne      SHORT G_M000_IG409
 
G_M000_IG408:                ;; offset=0x2DDC
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      r9, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSynchronousMemberLoad(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref)]
       jmp      G_M000_IG07
 
G_M000_IG409:                ;; offset=0x2DFA
       mov      r8, bword ptr [rbp-0x360]
 
G_M000_IG410:                ;; offset=0x2E01
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x340], ymm0
 
G_M000_IG411:                ;; offset=0x2E0E
       lea      r8, [rbp-0x340]
       lea      rdx, [rbp-0x1F0]
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteMemberLoadAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0x1F0]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x1E8]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       G_M000_IG258
 
G_M000_IG412:                ;; offset=0x2E57
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG413
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG414
 
G_M000_IG413:                ;; offset=0x2E7F
       mov      rax, bword ptr [rbp+0x30]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7094040
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG414:                ;; offset=0x2EA2
       test     esi, esi
       jne      G_M000_IG258
       jmp      G_M000_IG355
 
G_M000_IG415:                ;; offset=0x2EAF
       mov      r8d, dword ptr [r11+0x08]
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CanForwardFixedReturn(byref,byref,int):bool]
       test     eax, eax
       je       G_M000_IG95
 
G_M000_IG416:                ;; offset=0x2ECC
       mov      r11, bword ptr [rbp+0x48]
       vmovdqu  xmm0, xmmword ptr [r11]
       vmovdqu  xmmword ptr [rbp-0x310], xmm0
 
G_M000_IG417:                ;; offset=0x2EDD
       lea      r9, [rbp-0x310]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, bword ptr [rbp-0x360]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CopyFixedReturn(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot])]
       mov      dword ptr [rbp-0x74], 2
       jmp      G_M000_IG527
 
G_M000_IG418:                ;; offset=0x2F05
       mov      r11, bword ptr [rbp-0x360]
 
G_M000_IG419:                ;; offset=0x2F0C
       vmovdqu  ymm0, ymmword ptr [r11]
       vmovdqu  ymmword ptr [rbp-0x340], ymm0
 
G_M000_IG420:                ;; offset=0x2F19
       lea      r8, [rbp-0x340]
       lea      rdx, [rbp-0x1E0]
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteContextManagerAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0x1E0]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x1D8]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       G_M000_IG142
 
G_M000_IG421:                ;; offset=0x2F62
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG422
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG423
 
G_M000_IG422:                ;; offset=0x2F8A
       mov      rax, bword ptr [rbp+0x30]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7094048
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG423:                ;; offset=0x2FAD
       test     esi, esi
       jne      G_M000_IG142
       jmp      G_M000_IG355
 
G_M000_IG424:                ;; offset=0x2FBA
       mov      rcx, bword ptr [rbp+0x10]
       mov      rax, gword ptr [rcx+0x20]
       mov      rdx, bword ptr [rbp-0x360]
       mov      edx, dword ptr [rdx+0x10]
       cmp      edx, dword ptr [rax+0x08]
       jae      G_M000_IG522
       shl      rdx, 4
       mov      rbx, gword ptr [rax+rdx+0x10]
       test     rbx, rbx
       je       G_M000_IG111
 
G_M000_IG425:                ;; offset=0x2FE7
       mov      rax, 0x7FF9D77E5D30
       cmp      qword ptr [rbx], rax
       jne      G_M000_IG111
 
G_M000_IG426:                ;; offset=0x2FFA
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.PyIteration+Cursor:get_NativeCsvSource():Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource:this]
       test     rax, rax
       je       G_M000_IG111
 
G_M000_IG427:                ;; offset=0x300C
       cmp      gword ptr [rax+0x20], 0
       je       G_M000_IG111
 
G_M000_IG428:                ;; offset=0x3017
       mov      rdx, bword ptr [rbp-0x360]
       mov      bword ptr [rsp+0x20], rdx
       movzx    rdx, byte  ptr [rbp+0x28]
       mov      dword ptr [rsp+0x28], edx
       lea      rdx, [rbp-0x110]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r8, rax
       mov      r9, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:AdvanceCsvUnpack(Lokad.Lython.Runtime.LythonRuntime+CsvRecordSource,Lokad.Lython.Runtime.PyIteration+Cursor,byref,bool):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0x110]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x108]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       G_M000_IG142
 
G_M000_IG429:                ;; offset=0x3073
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG430
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG431
 
G_M000_IG430:                ;; offset=0x309B
       mov      rax, bword ptr [rbp+0x30]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7094050
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG431:                ;; offset=0x30BE
       test     esi, esi
       jne      G_M000_IG142
       jmp      G_M000_IG355
 
G_M000_IG432:                ;; offset=0x30CB
       mov      rcx, r11
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      rdi, rax
       jmp      G_M000_IG113
 
G_M000_IG433:                ;; offset=0x30DC
       mov      rcx, r11
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      rdi, rax
       jmp      G_M000_IG113
 
G_M000_IG434:                ;; offset=0x30ED
       mov      rcx, r11
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      rdi, rax
       jmp      G_M000_IG113
 
G_M000_IG435:                ;; offset=0x30FE
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x2C171C8AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG436:                ;; offset=0x312C
       mov      rdx, rdi
       mov      rcx, 0x7FF9D7753360
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r11, rax
       jmp      G_M000_IG116
 
G_M000_IG437:                ;; offset=0x3146
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r14d, eax
       jmp      G_M000_IG153
 
G_M000_IG438:                ;; offset=0x315B
       cmp      dword ptr [rcx+0x20], 0
       setne    cl
       movzx    rcx, cl
       test     ecx, ecx
       je       G_M000_IG161
 
G_M000_IG439:                ;; offset=0x316D
       lea      rsi, bword ptr [rbx+0x20]
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       mov      edi, eax
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r8d, eax
 
G_M000_IG440:                ;; offset=0x3190
       vmovdqu  xmm0, xmmword ptr [rbp-0x2D8]
       vmovdqu  xmmword ptr [rbp-0x320], xmm0
 
G_M000_IG441:                ;; offset=0x31A0
       mov      edx, edi
       mov      rcx, rsi
       lea      r9, [rbp-0x320]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:PublishSlot(int,int,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot):this]
       jmp      G_M000_IG07
 
G_M000_IG442:                ;; offset=0x31B7
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG164
 
G_M000_IG443:                ;; offset=0x31C9
       mov      edx, r14d
       mov      r11, 0x7FF9D7094058
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r15, rax
       jmp      G_M000_IG169
 
G_M000_IG444:                ;; offset=0x31E1
       xor      rax, rax
       jmp      G_M000_IG170
 
G_M000_IG445:                ;; offset=0x31E8
       lea      rcx, [rbp-0x2E8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77F2610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r8, rax
       mov      rdx, r15
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreGlobalNamespaceName(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.String,System.Object)]
       jmp      G_M000_IG65
 
G_M000_IG446:                ;; offset=0x321D
       mov      rcx, gword ptr [rbp+0x20]
       cmp      byte  ptr [rcx], cl
       call     [Lokad.Lython.Runtime.ExecutionFrame:get_Variables():System.Collections.Generic.Dictionary`2[System.String,System.Object]:this]
       mov      rsi, rax
       mov      ecx, r14d
       shl      rcx, 4
       lea      rcx, bword ptr [rdi+rcx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77F2610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       mov      r8, rax
       cmp      byte  ptr [rsi], sil
       mov      rcx, rsi
       mov      rdx, r15
       mov      r9d, 1
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:TryInsert(System.__Canon,System.__Canon,byte):bool:this]
       jmp      G_M000_IG65
 
G_M000_IG447:                ;; offset=0x326E
       mov      rcx, gword ptr [rbx+0x20]
       test     rcx, rcx
       jne      SHORT G_M000_IG448
       xor      r8, r8
       xor      ecx, ecx
       jmp      SHORT G_M000_IG449
 
G_M000_IG448:                ;; offset=0x327E
       lea      r8, bword ptr [rcx+0x10]
       mov      ecx, dword ptr [rcx+0x08]
 
G_M000_IG449:                ;; offset=0x3285
       mov      bword ptr [rbp-0x310], r8
       mov      dword ptr [rbp-0x308], ecx
 
G_M000_IG450:                ;; offset=0x3292
       vmovdqu  xmm0, xmmword ptr [rbp-0x2D8]
       vmovdqu  xmmword ptr [rbp-0x320], xmm0
 
G_M000_IG451:                ;; offset=0x32A2
       lea      rcx, [rbp-0x310]
       lea      r8, [rbp-0x320]
       mov      r9, gword ptr [rbx+0x38]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       jmp      G_M000_IG65
 
G_M000_IG452:                ;; offset=0x32BF
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rsi, rax
       mov      rcx, rsi
       mov      rdx, 0x2C171C92BE0
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rsi
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG453:                ;; offset=0x32ED
       lea      rcx, [rbp-0x2D8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:get_Object():System.Object:this]
       mov      rdx, rax
       mov      rcx, 0x7FF9D77F2610
       call     [Lokad.Lython.Internal.NullabilityExtensions:RequireNotNull[System.__Canon](System.__Canon):System.__Canon]
       jmp      G_M000_IG65
 
G_M000_IG454:                ;; offset=0x3312
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      rsi, rax
       jmp      G_M000_IG121
 
G_M000_IG455:                ;; offset=0x3323
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      rsi, rax
       jmp      G_M000_IG121
 
G_M000_IG456:                ;; offset=0x3334
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      rsi, rax
       jmp      G_M000_IG121
 
G_M000_IG457:                ;; offset=0x3345
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x2C171C8AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG458:                ;; offset=0x3373
       mov      rdx, rsi
       mov      rcx, rdi
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG459:                ;; offset=0x337F
       mov      dword ptr [rbx+0x50], 63
       mov      rsi, gword ptr [rbx+0x20]
       mov      rdi, gword ptr [rbx+0x10]
       mov      rsi, gword ptr [rsi+0x98]
       cmp      byte  ptr [rsi], sil
       mov      rcx, rsi
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      G_M000_IG125
 
G_M000_IG460:                ;; offset=0x33A9
       mov      rcx, rsi
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG125
 
G_M000_IG461:                ;; offset=0x33BA
       mov      rcx, gword ptr [rbp+0x20]
       mov      rdx, rbx
       mov      r8, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CompleteForNext(Lokad.Lython.Runtime.PyIteration+Cursor,byref):bool:this]
       mov      ebx, eax
       jmp      G_M000_IG136
 
G_M000_IG462:                ;; offset=0x33D5
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      r14d, eax
       mov      r11, gword ptr [rbp+0x20]
       jmp      G_M000_IG130
 
G_M000_IG463:                ;; offset=0x33EE
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG464
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG465
 
G_M000_IG464:                ;; offset=0x3416
       mov      rax, bword ptr [rbp+0x30]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7094060
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG465:                ;; offset=0x3439
       test     esi, esi
       jne      G_M000_IG142
       jmp      G_M000_IG355
 
G_M000_IG466:                ;; offset=0x3446
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      ebx, eax
       jmp      G_M000_IG220
 
G_M000_IG467:                ;; offset=0x345A
       xor      r14, r14
       xor      edi, edi
       jmp      G_M000_IG222
 
G_M000_IG468:                ;; offset=0x3464
       xor      r9, r9
       xor      edx, edx
       jmp      G_M000_IG223
 
G_M000_IG469:                ;; offset=0x346E
       mov      rdx, rsi
       mov      rcx, 0x7FF9D775AC10
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rcx, rax
       jmp      G_M000_IG225
 
G_M000_IG470:                ;; offset=0x3488
       cmp      gword ptr [rbp+0x20], 0
       setne    r8b
       movzx    r8, r8b
       mov      dword ptr [rsp+0x20], r8d
       lea      r8, [rbp-0xA8]
       mov      qword ptr [rsp+0x28], r8
       mov      r8, bword ptr [rbp-0x360]
       mov      r8, gword ptr [r8]
       mov      rdx, rdi
       mov      r9, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryInvokeUnaryBuiltin(Lokad.Lython.Runtime.LythonRuntime+BuiltinCallable,System.Object,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,byref):bool]
       test     eax, eax
       je       G_M000_IG226
 
G_M000_IG471:                ;; offset=0x34C5
       mov      rdx, gword ptr [rbp-0xA8]
       mov      rcx, 0x7FF9D74F0AF8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      r14, rax
       test     r14, r14
       je       SHORT G_M000_IG473
 
G_M000_IG472:                ;; offset=0x34E3
       jmp      G_M000_IG529
 
G_M000_IG473:                ;; offset=0x34E8
       vmovdqu  xmm0, xmmword ptr [rbp-0xA8]
       vmovdqu  xmmword ptr [rbp-0x320], xmm0
 
G_M000_IG474:                ;; offset=0x34F8
       lea      r9, [rbp-0x320]
       mov      rdx, gword ptr [rbp+0x20]
       mov      r8, bword ptr [rbp-0x360]
       mov      rcx, bword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot)]
       jmp      G_M000_IG07
 
G_M000_IG475:                ;; offset=0x3519
       cmp      ebx, 73
       je       G_M000_IG232
       mov      rcx, bword ptr [rbp-0x360]
       mov      rdx, 0x2C171C8D5C8
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG476:                ;; offset=0x3542
       mov      rcx, r11
       mov      edx, ebx
       mov      r11, 0x7FF9D7093FE8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rbx, rax
       jmp      G_M000_IG233
 
G_M000_IG477:                ;; offset=0x355C
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      esi, eax
       jmp      G_M000_IG236
 
G_M000_IG478:                ;; offset=0x3570
       mov      rcx, r11
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      rdi, rax
       jmp      G_M000_IG238
 
G_M000_IG479:                ;; offset=0x3581
       mov      rcx, r11
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDouble():System.Object:this]
       mov      rdi, rax
       jmp      G_M000_IG238
 
G_M000_IG480:                ;; offset=0x3592
       mov      rcx, r11
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishTupleBorrow():System.Object:this]
       mov      rdi, rax
       jmp      G_M000_IG238
 
G_M000_IG481:                ;; offset=0x35A3
       mov      rcx, 0x7FF9D72BA220
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rcx, rbx
       mov      rdx, 0x2C171C8AC98
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rcx, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG482:                ;; offset=0x35D1
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG483:                ;; offset=0x35D7
       mov      gword ptr [rsp+0x20], rdi
       lea      rdx, [rbp-0xB0]
       mov      qword ptr [rsp+0x28], rdx
       mov      rcx, bword ptr [rbp+0x10]
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, rbx
       mov      r9d, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDeferredChild(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,byref):bool]
       test     eax, eax
       je       G_M000_IG284
 
G_M000_IG484:                ;; offset=0x3604
       cmp      gword ptr [rbp-0xB0], 0
       je       G_M000_IG07
 
G_M000_IG485:                ;; offset=0x3612
       mov      rdx, gword ptr [rbp-0xB0]
       xor      rcx, rcx
       mov      r8, bword ptr [rbp+0x40]
       mov      gword ptr [r8], rcx
       lea      rcx, bword ptr [r8+0x08]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      r8, bword ptr [rbp+0x40]
       mov      word  ptr [r8+0x10], 0
       mov      byte  ptr [r8+0x12], 1
       jmp      G_M000_IG288
 
G_M000_IG486:                ;; offset=0x3640
       mov      rcx, rax
       call     [System.Threading.Tasks.Task:get_IsCompletedSuccessfully():bool:this]
       test     eax, eax
       je       G_M000_IG288
       jmp      G_M000_IG295
 
G_M000_IG487:                ;; offset=0x3656
       mov      r8, bword ptr [rbp+0x40]
       movsx    rdx, word  ptr [r8+0x10]
       mov      rcx, r14
       mov      r11, 0x7FF9D7094068
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetStatus(short):int:this
       cmp      eax, 1
       jne      G_M000_IG288
       jmp      G_M000_IG295
 
G_M000_IG488:                ;; offset=0x367D
       mov      rdx, rsi
       mov      rcx, 0x7FF9D7885E98
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       mov      rdi, rax
       test     rdi, rdi
       je       SHORT G_M000_IG490
       mov      ecx, dword ptr [rdi+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       SHORT G_M000_IG489
       mov      rcx, rdi
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
 
G_M000_IG489:                ;; offset=0x36B3
       mov      rdi, gword ptr [rdi+0x38]
       jmp      G_M000_IG296
 
G_M000_IG490:                ;; offset=0x36BC
       mov      r8, bword ptr [rbp+0x40]
       movsx    rdx, word  ptr [r8+0x10]
       mov      rcx, rsi
       mov      r11, 0x7FF9D7094070
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[System.__Canon]:GetResult(short):System.__Canon:this
       mov      rdi, rax
       jmp      G_M000_IG296
 
G_M000_IG491:                ;; offset=0x36DD
       xor      edx, edx
       mov      r8, bword ptr [rbp+0x40]
       mov      qword ptr [r8], rdx
       mov      qword ptr [r8+0x08], rdx
       mov      qword ptr [r8+0x10], rdx
       jmp      G_M000_IG246
 
G_M000_IG492:                ;; offset=0x36F3
       mov      rdx, rbx
       mov      rcx, 0x7FF9D74847C8
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG493
       mov      ecx, dword ptr [rax+0x34]
       and      ecx, 0x11000000
       cmp      ecx, 0x1000000
       je       G_M000_IG07
       mov      rcx, rax
       xor      edx, edx
       call     [System.Runtime.CompilerServices.TaskAwaiter:HandleNonSuccessAndDebuggerNotification(System.Threading.Tasks.Task,int)]
       jmp      G_M000_IG07
 
G_M000_IG493:                ;; offset=0x372F
       mov      rcx, rbx
       mov      edx, esi
       mov      r11, 0x7FF9D7094078
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource:GetResult(short):this
       jmp      G_M000_IG07
 
G_M000_IG494:                ;; offset=0x3746
       mov      gword ptr [rsp+0x20], rdi
       mov      dword ptr [rsp+0x28], 1
       lea      rdx, [rbp-0x190]
       mov      rcx, gword ptr [rbp+0x20]
       mov      r8, rbx
       mov      r9d, esi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteOrdinaryCall(Lokad.Lython.Frontend.ExecutableCallSite,int,System.Object,bool):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x1A0]
       lea      rdx, [rbp-0x190]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      rdi, rax
       mov      rdx, gword ptr [rbp-0x1A0]
       mov      rcx, rdi
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x198]
       mov      qword ptr [rdi+0x08], rdx
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       G_M000_IG258
 
G_M000_IG495:                ;; offset=0x37AF
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG496
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG497
 
G_M000_IG496:                ;; offset=0x37D7
       mov      rax, bword ptr [rbp+0x30]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7094080
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG497:                ;; offset=0x37FA
       test     esi, esi
       jne      G_M000_IG258
       jmp      G_M000_IG355
 
G_M000_IG498:                ;; offset=0x3807
       xor      r14, r14
       xor      r11d, r11d
       jmp      G_M000_IG72
 
G_M000_IG499:                ;; offset=0x3812
       cmp      esi, dword ptr [r11+0x08]
       jae      G_M000_IG522
       mov      esi, esi
       mov      rcx, gword ptr [r11+8*rsi+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:RuntimeValue(System.Object):System.Object]
       mov      r14, rax
       jmp      G_M000_IG79
 
G_M000_IG500:                ;; offset=0x3831
       mov      rcx, rdi
       mov      edx, r15d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      rdx, rax
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.RuntimeErrors:NameNotDefined(System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rcx, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG501:                ;; offset=0x3855
       mov      rcx, rdi
       mov      edx, r15d
       xor      r8d, r8d
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:OperandReadSpan(int,int):Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      edx, esi
       mov      rcx, rdi
       mov      r9, gword ptr [rbp+0x18]
       call     [Lokad.Lython.Runtime.LythonRuntime:LoadMissingLocal(Lokad.Lython.Frontend.ExecutableCodeObject,int,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):System.Object]
       mov      r14, rax
       jmp      G_M000_IG79
 
G_M000_IG502:                ;; offset=0x387E
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG82
 
G_M000_IG503:                ;; offset=0x3890
       mov      r8, bword ptr [rbp-0x360]
 
G_M000_IG504:                ;; offset=0x3897
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x340], ymm0
 
G_M000_IG505:                ;; offset=0x38A4
       lea      r8, [rbp-0x340]
       lea      rdx, [rbp-0x1C0]
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteGetIteratorAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x1D0]
       lea      rdx, [rbp-0x1C0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0x1D0]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x1C8]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       G_M000_IG258
 
G_M000_IG506:                ;; offset=0x3901
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG507
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG508
 
G_M000_IG507:                ;; offset=0x3929
       mov      rax, bword ptr [rbp+0x30]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7094088
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG508:                ;; offset=0x394C
       test     esi, esi
       jne      G_M000_IG258
       jmp      G_M000_IG355
 
G_M000_IG509:                ;; offset=0x3959
       mov      r11, bword ptr [rbp-0x360]
 
G_M000_IG510:                ;; offset=0x3960
       vmovdqu  ymm0, ymmword ptr [r11]
       vmovdqu  ymmword ptr [rbp-0x340], ymm0
 
G_M000_IG511:                ;; offset=0x396D
       lea      r8, [rbp-0x340]
       lea      rdx, [rbp-0x170]
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteSliceValueOperationAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask:this]
       lea      rcx, [rbp-0x180]
       lea      rdx, [rbp-0x170]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:WithoutJump(System.Threading.Tasks.ValueTask):System.Threading.Tasks.ValueTask`1[bool]]
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0x180]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x178]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       G_M000_IG258
 
G_M000_IG512:                ;; offset=0x39CA
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG513
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG514
 
G_M000_IG513:                ;; offset=0x39F2
       mov      rax, bword ptr [rbp+0x30]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7094090
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG514:                ;; offset=0x3A15
       test     esi, esi
       jne      G_M000_IG258
       jmp      G_M000_IG355
 
G_M000_IG515:                ;; offset=0x3A22
       mov      r8, 0x7FF9D77E9A80
       cmp      qword ptr [rbx], r8
       jne      G_M000_IG303
 
G_M000_IG516:                ;; offset=0x3A35
       mov      r8, bword ptr [rbp-0x360]
 
G_M000_IG517:                ;; offset=0x3A3C
       vmovdqu  ymm0, ymmword ptr [r8]
       vmovdqu  ymmword ptr [rbp-0x340], ymm0
 
G_M000_IG518:                ;; offset=0x3A49
       lea      r8, [rbp-0x340]
       lea      rdx, [rbp-0x160]
       mov      rcx, gword ptr [rbp+0x20]
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:ExecuteConditionalJumpAsync(Lokad.Lython.Frontend.ExecutableInstruction):System.Threading.Tasks.ValueTask`1[bool]:this]
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, rax
       mov      rdx, gword ptr [rbp-0x160]
       mov      rcx, rbx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rdx, qword ptr [rbp-0x158]
       mov      qword ptr [rbx+0x08], rdx
       mov      rax, bword ptr [rbp+0x30]
       mov      rbx, gword ptr [rax]
       test     rbx, rbx
       je       G_M000_IG142
 
G_M000_IG519:                ;; offset=0x3A94
       mov      rdx, rbx
       mov      rcx, 0x7FF9D7846388
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG520
       test     dword ptr [rax+0x34], 0x1600000
       setne    sil
       movzx    rsi, sil
       jmp      SHORT G_M000_IG521
 
G_M000_IG520:                ;; offset=0x3ABC
       mov      rax, bword ptr [rbp+0x30]
       movsx    rdx, word  ptr [rax+0x08]
       mov      rcx, rbx
       mov      r11, 0x7FF9D7094098
       call     [r11]System.Threading.Tasks.Sources.IValueTaskSource`1[bool]:GetStatus(short):int:this
       test     eax, eax
       setne    sil
       movzx    rsi, sil
 
G_M000_IG521:                ;; offset=0x3ADF
       test     esi, esi
       jne      G_M000_IG142
       jmp      G_M000_IG355
 
G_M000_IG522:                ;; offset=0x3AEC
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG523:                ;; offset=0x3AF2
       lea      rcx, [rbp-0xD8]
       mov      rdx, 0x2C171C92A40
       call     [System.Runtime.CompilerServices.DefaultInterpolatedStringHandler:GrowThenCopyString(System.String):this]
       jmp      G_M000_IG216
 
G_M000_IG524:                ;; offset=0x3B0E
       mov      r14, bword ptr [rbp+0x10]
       cmp      gword ptr [r14+0x40], 0
       je       G_M000_IG08
 
G_M000_IG525:                ;; offset=0x3B1D
       xor      rax, rax
       mov      rcx, bword ptr [rbp+0x30]
       mov      gword ptr [rcx], rax
       mov      word  ptr [rcx+0x08], 0
       movzx    rax, byte  ptr [rbp-0x3C]
       mov      byte  ptr [rcx+0x0A], al
       mov      byte  ptr [rcx+0x0B], 1
       mov      eax, 5
 
G_M000_IG526:                ;; offset=0x3B3C
       vzeroupper 
       add      rsp, 904
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG527:                ;; offset=0x3B53
       mov      eax, dword ptr [rbp-0x74]
 
G_M000_IG528:                ;; offset=0x3B56
       vzeroupper 
       add      rsp, 904
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG529:                ;; offset=0x3B6D
       mov      r9, bword ptr [rbp-0x360]
       mov      r9, gword ptr [r9]
       mov      rcx, r14
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       je       SHORT G_M000_IG532
       mov      dword ptr [rbp-0x3C], 1
       jmp      G_M000_IG07
 
G_M000_IG530:                ;; offset=0x3B98
       cmp      dword ptr [rdi+0x20], 0
       setne    dil
       movzx    rdi, dil
       test     edi, edi
       je       G_M000_IG12
 
G_M000_IG531:                ;; offset=0x3BAC
       mov      rcx, r11
       mov      rdx, rsi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
       jmp      G_M000_IG12
 
G_M000_IG532:                ;; offset=0x3BBD
       mov      rcx, r14
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG533:                ;; offset=0x3BC6
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG534:                ;; offset=0x3BCC
       sub      rsp, 72
 
G_M000_IG535:                ;; offset=0x3BD0
       mov      rbx, rcx
       cmp      gword ptr [rbp+0x20], 0
       jne      SHORT G_M000_IG537
 
G_M000_IG536:                ;; offset=0x3BDA
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG537:                ;; offset=0x3BE0
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      r8, rax
       mov      rdx, rbx
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryRouteReturn(Lokad.Lython.Runtime.LythonRuntime+ReturnSignal,Lokad.Lython.LythonSourceSpan):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG540
 
G_M000_IG538:                ;; offset=0x3C01
       mov      dword ptr [rbp-0x74], 1
       lea      rax, G_M000_IG527
 
G_M000_IG539:                ;; offset=0x3C0F
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG540:                ;; offset=0x3C17
       mov      dword ptr [rbp-0x3C], 1
       lea      rax, G_M000_IG07
 
G_M000_IG541:                ;; offset=0x3C25
       vzeroupper 
       add      rsp, 72
       ret      
 
G_M000_IG542:                ;; offset=0x3C2D
       sub      rsp, 72
 
G_M000_IG543:                ;; offset=0x3C31
       mov      rbx, rcx
       mov      rcx, bword ptr [rbp-0x360]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      r9, rax
       mov      rdx, gword ptr [rbp+0x18]
       mov      r8, gword ptr [rbp+0x20]
       mov      rcx, rbx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:RouteInstructionFailure(Lokad.Lython.Runtime.LythonRuntimeException,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool]
       test     eax, eax
       jne      SHORT G_M000_IG545
 
G_M000_IG544:                ;; offset=0x3C59
       call     CORINFO_HELP_RETHROW
       int3     
 
G_M000_IG545:                ;; offset=0x3C5F
       mov      dword ptr [rbp-0x3C], 1
       lea      rax, G_M000_IG07
 
G_M000_IG546:                ;; offset=0x3C6D
       vzeroupper 
       add      rsp, 72
       ret      
 
RWD00  	dd	00001574h ; case G_M000_IG208
       	dd	0000148Eh ; case G_M000_IG201
       	dd	0000010Ah ; case G_M000_IG14
       	dd	0000135Fh ; case G_M000_IG193
       	dd	00001300h ; case G_M000_IG192
       	dd	00001282h ; case G_M000_IG190
       	dd	0000122Dh ; case G_M000_IG187
       	dd	00001157h ; case G_M000_IG179
       	dd	00001157h ; case G_M000_IG179
       	dd	00001109h ; case G_M000_IG177
       	dd	00001109h ; case G_M000_IG177
       	dd	00001157h ; case G_M000_IG179
       	dd	00001157h ; case G_M000_IG179
       	dd	00001157h ; case G_M000_IG179
       	dd	00001157h ; case G_M000_IG179
       	dd	00001157h ; case G_M000_IG179
       	dd	00001157h ; case G_M000_IG179
       	dd	00001157h ; case G_M000_IG179
       	dd	00001157h ; case G_M000_IG179
       	dd	00001157h ; case G_M000_IG179
       	dd	00001157h ; case G_M000_IG179
       	dd	00001157h ; case G_M000_IG179
       	dd	00001F15h ; case G_M000_IG281
       	dd	00001F15h ; case G_M000_IG281
       	dd	00001EF5h ; case G_M000_IG279
       	dd	00001ED7h ; case G_M000_IG278
       	dd	00001EB5h ; case G_M000_IG277
       	dd	00001E36h ; case G_M000_IG275
       	dd	00001DA0h ; case G_M000_IG271
       	dd	00001D37h ; case G_M000_IG270
       	dd	00001CF9h ; case G_M000_IG269
       	dd	00001C87h ; case G_M000_IG268
       	dd	00000822h ; case G_M000_IG92
       	dd	000007FEh ; case G_M000_IG90
       	dd	000007FEh ; case G_M000_IG90
       	dd	000007FEh ; case G_M000_IG90
       	dd	000007E7h ; case G_M000_IG88
       	dd	000007E7h ; case G_M000_IG88
       	dd	000007E7h ; case G_M000_IG88
       	dd	000007FEh ; case G_M000_IG90
       	dd	000006A2h ; case G_M000_IG71
       	dd	00000ACCh ; case G_M000_IG111
       	dd	00001898h ; case G_M000_IG231
       	dd	000010E8h ; case G_M000_IG176
       	dd	000010CEh ; case G_M000_IG174
       	dd	000010BEh ; case G_M000_IG173
       	dd	000021B1h ; case G_M000_IG309
       	dd	000021B1h ; case G_M000_IG309
       	dd	000021B1h ; case G_M000_IG309
       	dd	00002140h ; case G_M000_IG304
       	dd	000020D9h ; case G_M000_IG299
       	dd	00002094h ; case G_M000_IG297
       	dd	00002140h ; case G_M000_IG304
       	dd	00002140h ; case G_M000_IG304
       	dd	00002140h ; case G_M000_IG304
       	dd	00002140h ; case G_M000_IG304
       	dd	00002140h ; case G_M000_IG304
       	dd	00002140h ; case G_M000_IG304
       	dd	00002140h ; case G_M000_IG304
       	dd	00001C7Bh ; case G_M000_IG267
       	dd	00001BCEh ; case G_M000_IG262
       	dd	00001B9Eh ; case G_M000_IG259
       	dd	00002140h ; case G_M000_IG304
       	dd	00001A89h ; case G_M000_IG247
       	dd	00001A89h ; case G_M000_IG247
       	dd	00001A89h ; case G_M000_IG247
       	dd	00001A89h ; case G_M000_IG247
       	dd	00001A89h ; case G_M000_IG247
       	dd	00001A5Ch ; case G_M000_IG245
       	dd	00000AA9h ; case G_M000_IG109
       	dd	0000099Ch ; case G_M000_IG103
       	dd	000008F7h ; case G_M000_IG97
       	dd	000008C2h ; case G_M000_IG96
       	dd	000016E9h ; case G_M000_IG217
RWD296 	dq	006E006B006E0055h, 0020006E0077006Fh, 0063006500780065h, 0062006100740075h
RWD328 	dq	006F00200065006Ch, 0064006F00630070h

; Total bytes of code 15477

