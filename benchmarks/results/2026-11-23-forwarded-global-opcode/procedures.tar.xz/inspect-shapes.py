from pathlib import Path
import hashlib,json,os,shutil,subprocess
lab=Path(__file__).resolve().parent
prior=lab.parent/'closed-definition-return-20261123/inspect/build/bin/Inspect/release_net11.0'
rootd=Path.home()/'.dotnet11'; pair={}
proof=json.loads((lab/'comparison/identity.json').read_text(encoding='utf-8'))
for role,files in proof['imageFiles'].items():
    image=lab/role
    for n in ('Inspect.dll','Inspect.deps.json','Inspect.runtimeconfig.json'): shutil.copyfile(prior/n,image/n)
    output=lab/(role+'-tape.json')
    subprocess.run([rootd/'dotnet.exe',image/'Inspect.dll',lab/'representative.json',output],check=True,timeout=20,env=dict(os.environ,DOTNET_ROOT=str(rootd)))
    pair[role]=json.loads(output.read_text(encoding='utf-8'))
    assert pair[role]['coreSHA256']==files['Lokad.Lython.dll'] and all(hashlib.sha256((image/n).read_bytes()).hexdigest()==digest for n,digest in files.items())
selection=[]
for r,c in zip(pair['reference']['rows'],pair['candidate']['rows'],strict=True):
    assert r['id'] == c['id']
    forwarded=0
    for a,b in zip(r['codes'],c['codes'],strict=True):
        assert a['name']==b['name'] and a['capacity']==b['capacity'] and a['instructions']==b['instructions']
        expected=sum(site['first']<0 for site in a['calls'])
        assert expected==b['opcodeCounts'].get('CallWithForwardedOperands',0)
        if not expected: assert a==b
        forwarded+=expected
    selection.append(dict(id=c['id'],forwarded=forwarded))
assert [s['forwarded'] for s in selection]==[3,3,4,0,0]
(lab/'tape-summary.json').write_text(json.dumps(selection,indent=2)+'\n',encoding='utf-8',newline='\n')
print(selection)
