from pathlib import Path
import json
import shutil
import sys

lab=Path(__file__).resolve().parent
template=lab.parent/'closure-cpython-20261123'
factory=lab.parent/'direct-computed-definition-20261123'
load=lambda path:json.loads(path.read_text(encoding='utf-8'))
write=lambda name,data:(lab/name).write_text(data,encoding='utf-8',newline='\n')
write_json=lambda name,data:write(name,json.dumps(data,indent=2,ensure_ascii=False)+'\n')
source=lab.parent/sys.argv[1]
remote=sys.argv[2]
revision=sys.argv[3]
eager='scripts.annotated-rule-closures.nested-factories'
postponed=eager+'.postponed'
supplied='scripts.ordinary-fully-supplied-helper'
quote='scripts.csv-invoice.method-policy.quoted-control'
catalog=load(factory/'comparison/representative.json')
control=load(template/'representative.json')
for name in (postponed,supplied,quote):
    assert next(r for r in catalog['cases'] if r['id']==name)==next(r for r in control['cases'] if r['id']==name)
catalog['cases']=[row for row in catalog['cases'] if row['id'] in (eager,postponed,supplied,quote)]
assert {row['id'] for row in catalog['cases']}=={eager,postponed,supplied,quote}
write_json('representative.json',catalog)
write_json('jobs.json',[[eager,'warm'],[postponed,'warm'],[supplied,'warm'],[quote,'warm'],[eager,'compile-run'],[postponed,'compile-run']])
write_json('selection.json',dict(lab=source.name,remoteDirectory=remote,retainedRevision=revision))
shutil.copyfile(source/'comparison/quiet/run.sh',lab/'run.sh')
assert b'\r' not in (lab/'run.sh').read_bytes()

def install(name,replacements):
    text=(template/name).read_text(encoding='utf-8')
    for before,after in replacements:
        assert before in text,(name,before)
        text=text.replace(before,after)
    compile(text,name,'exec')
    write(name,text)

install('quiet.py',[
    ('closure-cpython-b1499-20261123','computed-factory-cpython-b1503-20261123'),
    ('lython-b1499-closure-cpython-20261123','lython-b1503-computed-factory-cpython-20261123'),
])
install('collect.py',[
    ('CPython checkpoint after retaining direct closure assignment','CPython checkpoint for computed factory defaults'),
])
install('summarize.py',[])
install('archive.py',[
    ('2026-11-23-closure-cpython','2026-11-23-computed-factory-cpython'),
    ("lab.parent/'closure-result-consumer-20261123/candidate'", "lab.parent/read(lab/'selection.json')['lab']/'candidate'"),
])
