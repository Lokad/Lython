from pathlib import Path
import re


repo = Path(__file__).resolve().parents[4]
runtime = repo / 'src/Lokad.Lython/Runtime/LythonRuntime.BuiltinModuleCatalog.cs'
frontend = repo / 'src/Lokad.Lython/Frontend/StaticContracts.Modules.cs'
resolution = runtime.read_text(encoding='utf-8')
contracts = frontend.read_text(encoding='utf-8')

start = resolution.index('        private static readonly FrozenDictionary<string, BuiltinModuleRegistration> Registrations')
end = resolution.index('\n\n        private static readonly string[] KnownNames', start)
dispatch = dict(re.findall(r'^ +\["([^"]+)"\] = Module\(([^\n]+)\),$', resolution[start:end], re.M))
begin = contracts.index('    internal static readonly Dictionary<string, BuiltinModuleSurface> Surfaces')
after = contracts.index('\n\n    internal static readonly FrozenDictionary<ModuleMemberName, string> Submodules', begin)
surfaces = dict(re.findall(r'^        \["([^"]+)"\] = (.*?),\n(?=        \["|    };)', contracts[begin:after], re.M | re.S))
assert len(dispatch) == len(surfaces) == 66 and set(surfaces) == set(dispatch)


def identifier(name):
    style = {'openpyxl': 'OpenPyxl', 'fnmatch': 'FnMatch', 'pkgutil': 'Pkgutil', 'importlib': 'Importlib'}
    return ''.join(style.get(part, part[:1].upper() + part[1:]) for part in name.strip('_').split('.'))


names = sorted(surfaces)
assert len({identifier(name) for name in names}) == len(names)
for name in names:
    body = re.sub(r'^static (?:_|context) => ', '', dispatch[name])
    dispatch[name] = body.removesuffix(', BuiltinModuleCapability.Subprocess')

source = '''using System.Collections.Frozen;
using Lokad.Lython.Frontend;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal static partial class BuiltinModuleCatalog
    {
        // The registry is shared metadata. Module instances and frontend
        // inventories are both obtained on demand from the selected identifier.
        private static readonly FrozenDictionary<string, ModuleId> Registrations =
            new Dictionary<string, ModuleId>(StringComparer.Ordinal)
            {
'''
source += ''.join(f'                ["{name}"] = ModuleId.{identifier(name)},\n' for name in names)
source += '''            }.ToFrozenDictionary(StringComparer.Ordinal);

        private enum ModuleId : byte
        {
'''
source += ''.join(f'            {identifier(name)},\n' for name in names)
source += '''        }

        private static PyModule LoadModule(ModuleId module, ExecutionContext context) => module switch
        {
'''
source += ''.join(f'            ModuleId.{identifier(name)} => {dispatch[name]},\n' for name in names)
source += '''            _ => throw new ArgumentOutOfRangeException(nameof(module))
        };

        private static StaticModuleCatalog.BuiltinModuleSurface CreateSurface(ModuleId module) => module switch
        {
'''
separate = []
for name in names:
    entry = surfaces[name]
    if '\n' in entry:
        separate.append(name)
        entry = f'Describe{identifier(name)}()'
    source += f'            ModuleId.{identifier(name)} => {entry},\n'
source += '''            _ => throw new ArgumentOutOfRangeException(nameof(module))
        };

        private static StaticModuleCatalog.BuiltinModuleSurface Members(params string[] names)
            => new(names);

        private static StaticModuleCatalog.BuiltinModuleSurface ReexportedMembers(string callableModule, params string[] names)
            => new(names, callableModule);
'''
for name in separate:
    lines = surfaces[name].splitlines()
    source += f'\n        private static StaticModuleCatalog.BuiltinModuleSurface Describe{identifier(name)}()\n'
    source += f'            => {lines[0]}\n'
    source += '\n'.join('    ' + line for line in lines[1:]) + ';\n'
source += '    }\n}\n'

begin = contracts.index('    internal static readonly Dictionary<string, BuiltinModuleSurface> Surfaces')
after = contracts.index('\n\n    internal static readonly FrozenDictionary<ModuleMemberName, string> Submodules', begin)
contracts = contracts[:begin] + contracts[after + 2:]
begin = contracts.index('    internal static readonly IReadOnlyList<string> Names')
after = contracts.index('    internal sealed class BuiltinModuleSurface', begin)
contracts = contracts[:begin] + contracts[after:]
contracts = contracts.replace('using Lokad.Lython.Runtime;', 'using BuiltinModuleCatalog = Lokad.Lython.Runtime.LythonRuntime.BuiltinModuleCatalog;')
contracts = contracts.replace('StaticModuleCatalog.Surfaces.ContainsKey(', 'BuiltinModuleCatalog.IsKnown(')
contracts = contracts.replace('StaticModuleCatalog.Surfaces.TryGetValue(', 'BuiltinModuleCatalog.TryGetSurface(')
contracts = contracts.replace('StaticModuleCatalog.Names', 'BuiltinModuleCatalog.Names')

resolution = resolution[:start] + resolution[end + 2:]
begin = resolution.index('    private enum BuiltinModuleCapability')
after = resolution.index('        public static bool IsKnown', begin)
resolution = resolution[:begin] + '''    internal static partial class BuiltinModuleCatalog
    {
        private static class RegisteredNames
        {
            internal static readonly string[] Sorted = Registrations.Keys.Order(StringComparer.Ordinal).ToArray();
        }

        private static class CapabilityFreeNames
        {
            internal static readonly string[] Sorted = RegisteredNames.Sorted
                .Where(static name => Registrations[name] != ModuleId.Subprocess)
                .ToArray();
        }

        private static class FrontendSurfaces
        {
            internal static readonly StaticModuleCatalog.BuiltinModuleSurface?[] Values = new StaticModuleCatalog.BuiltinModuleSurface?[Registrations.Count];
        }

        public static IReadOnlyList<string> Names => RegisteredNames.Sorted;

        public static IReadOnlyList<string> GetDiscoverableNames(ExecutionContext context)
            => context.State.AllowedBuiltinModules is null
                ? context.Host.SubprocessRunner is null ? CapabilityFreeNames.Sorted : RegisteredNames.Sorted
                : RegisteredNames.Sorted.Where(name => IsDiscoverable(name, context)).ToArray();

''' + resolution[after:]
resolution = resolution.replace('using System.Collections.Frozen;', 'using System.Collections.Frozen;\nusing Lokad.Lython.Frontend;')
begin = resolution.index('        public static bool HasUnavailableCapability')
resolution = resolution[:begin] + '''        public static bool TryGetSurface(string moduleName, [NotNullWhen(true)] out StaticModuleCatalog.BuiltinModuleSurface? surface)
        {
            if (!Registrations.TryGetValue(moduleName, out var module))
            {
                surface = null;
                return false;
            }

            ref var slot = ref FrontendSurfaces.Values[(int)module];
            surface = Volatile.Read(ref slot) ?? PublishSurface(ref slot, module);
            return true;
        }

        private static StaticModuleCatalog.BuiltinModuleSurface PublishSurface(ref StaticModuleCatalog.BuiltinModuleSurface? slot, ModuleId module)
        {
            var surface = CreateSurface(module);
            return Interlocked.CompareExchange(ref slot, surface, null) ?? surface;
        }

''' + resolution[begin:]
resolution = resolution.replace('out var registration', 'out var module')
resolution = resolution.replace('registration.RequiredCapability == BuiltinModuleCapability.Subprocess', 'module == ModuleId.Subprocess')
resolution = resolution.replace('registration.RequiredCapability == BuiltinModuleCapability.None', 'module != ModuleId.Subprocess')
resolution = resolution.replace('Registrations[moduleName].Resolve(context)', 'LoadModule(Registrations[moduleName], context)')
resolution = resolution.replace('registration.Resolve(context)', 'LoadModule(module, context)')
begin = resolution.index('\n\n        private static BuiltinModuleRegistration Module(')
after = resolution.index('\n\n    internal static IReadOnlySet<string>? SnapshotBuiltinModuleGrants', begin)
resolution = resolution[:begin] + '\n    }' + resolution[after:]

runtime.write_text(resolution, encoding='utf-8', newline='\n')
frontend.write_text(contracts, encoding='utf-8', newline='\n')
runtime.with_name('LythonRuntime.BuiltinModuleCatalog.Registrations.cs').write_text(source, encoding='utf-8', newline='\n')
