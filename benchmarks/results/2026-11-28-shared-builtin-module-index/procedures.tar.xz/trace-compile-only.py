from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess


lab = Path(__file__).resolve().parent
pair = lab / 'comparison'
identity = json.loads((pair / 'identity.json').read_bytes())
dotnet = Path.home() / '.dotnet/dotnet'
tracer = Path.home() / '.dotnet/tools/dotnet-trace'
probe = lab / 'probe/bin/Release/net11.0/ModuleProbe.dll'
payload = pair / 'config.json'
reader = lab.parent / 'first-command-phases-b1927-20261128/trace-reader/bin/Release/net11.0/TraceReader.dll'
env = {key: value for key, value in os.environ.items() if not key.startswith(('DOTNET_', 'COMPlus_'))}
env.update(DOTNET_ROOT=str(dotnet.parent), TMPDIR='/dev/shm', LC_ALL='C.UTF-8')
assert sha256(payload.read_bytes()).hexdigest() == identity['catalogs']['config.json']['sha256']
proof = {}
for role in ('reference', 'candidate'):
    assert {path.name: sha256(path.read_bytes()).hexdigest() for path in (pair / role).iterdir()} == identity['imageFiles'][role]
    raw = lab / f'compile-{role}.nettrace'
    output = lab / f'compile-{role}.json'
    errors = lab / f'compile-{role}.stderr'
    if not raw.exists():
        with (lab / f'compile-{role}.log').open('wb') as log:
            command = [tracer, 'collect', '--clrevents', 'jit', '--clreventlevel', 'verbose', '--buffersize', '32',
                '--rundown', 'false', '--output', raw, '--', '/bin/sh', '-c',
                'exec "$1" "$2" "$3" --allocate "$4" > "$5" 2> "$6"', 'capture', dotnet, probe,
                pair / role / 'Lokad.Lython.dll', payload, output, errors]
            subprocess.run(command, env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                           check=True, timeout=40)
    measured = json.loads(output.read_bytes())
    assert not errors.read_bytes() and measured['admitted'] == 67328 and measured['after'] == 0
    interval = json.loads(subprocess.check_output([dotnet, reader, raw], env=env, timeout=30))
    assert interval['starts'] == interval['completed'] == len(interval['intervals']) and not interval['unmatched']
    methods = [(row['Namespace'], row['Method'], row['IlBytes']) for row in interval['intervals']]
    assert not any(method == 'LoadModule' or method == 'ResolveBuiltinModule' for _, method, _ in methods)
    proof[role] = dict(sha256=sha256(raw.read_bytes()).hexdigest(), total=interval['completed'],
        moduleMethods=[item for item in methods if 'ModuleCatalog' in item[0]], allocationAndAdmission=measured,
        runtimeInitializers=[item for item in methods if item[0].startswith('Lokad.Lython.Runtime.')
            and '+BuiltinModuleCatalog' not in item[0] and item[1] == '.cctor'])
(lab / 'compile-traces.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8', newline='\n')
assert proof['reference']['runtimeInitializers'] == proof['candidate']['runtimeInitializers']
print(json.dumps(proof, indent=2))
