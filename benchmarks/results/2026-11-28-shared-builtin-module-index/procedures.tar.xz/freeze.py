from hashlib import sha256
import json
from pathlib import Path
from shutil import copy2, copytree
from subprocess import check_output


lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.parent / 'module-surface-storage-b1947-20261128'
reference = lab.parent / 'first-command-refresh-b1987-20261128'
pair = lab / 'comparison'
build = lab / 'ubuntu-artifacts/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def manifest(folder):
    return {path.name: digest(path) for path in folder.iterdir()}


def write(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')


setup = read(reference / 'setup.json')
head = check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip()
assert not check_output(['git', 'diff', '--name-only', setup['productionSource'], head, '--', 'src'], cwd=repo)
assert len(setup['reference']) == 32 and manifest(reference / 'reference') == setup['reference']
for role in ('reference', 'candidate'):
    copytree(reference / 'reference', pair / role)
copy2(build, pair / 'candidate/Lokad.Lython.dll')
images = {role: manifest(pair / role) for role in ('reference', 'candidate')}
assert images['reference'] == setup['reference']
assert not (pair / 'candidate/Lokad.Lython.dll').samefile(build)
assert {name for name, value in images['reference'].items() if images['candidate'][name] != value} == {'Lokad.Lython.dll'}
patch = check_output(['git', 'diff', '--binary', 'HEAD', '--', 'src', 'tests'], cwd=repo)
assert patch.count(b'diff --git ') == 4
(lab / 'candidate.patch').write_bytes(patch)

catalog = read(prior / 'comparison/representative.json')
config, xml, generated, imports = ('scripts.config-edit.small', 'xml.parse-select.small',
    'compiler.generated-read-only-branches', 'diagnostic.builtin-module-imports')
cases = {case['id']: case for case in catalog['cases']}
source = '''import collections
import functools
import hashlib
import io
import itertools
import json
import math
from xml.etree import ElementTree as et
from urllib.parse import quote
answer = collections.Counter(io.StringIO("x\\nx\\ny\\n"))
values = list(itertools.repeat(answer["x\\n"], 3))
count = functools.reduce(lambda a, b: a + b, values)
print(count, math.isqrt(64), et.fromstring("<message>ok</message>").text,
      quote(json.dumps({"x": 2}, separators=(",", ":"))), hashlib.sha256(b"").hexdigest())
'''
golden = '6 8 ok %7B%22x%22%3A2%7D e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855\n'
fixture = '{"size":9,"text":null}'
cases[imports] = dict(id=imports, family='scripts', category='whole-script', scale='small', size=9,
    source=source, fixtureJson=fixture, expectedOutput=golden, sourceUtf8Bytes=len(source.encode('utf-8')),
    expectedOutputUtf8Bytes=len(golden), fixtureTextUtf8Bytes=0, fixtureTextCodePoints=0,
    sourceSha256=sha256(source.encode()).hexdigest(), fixtureSha256=sha256(fixture.encode()).hexdigest(),
    expectedOutputSha256=sha256(golden.encode()).hexdigest(), expectedFilesSha256=None)
write(pair / 'representative.json', dict(catalog, cases=[cases[key] for key in (config, xml, generated, imports)]))
for name, key in (('config.json', config), ('xml.json', xml), ('generated.json', generated)):
    write(pair / name, dict(catalog, cases=[cases[key]]))
jobs = [(config, 'compile'), (config, 'compile-run'), (xml, 'compile-run'), (generated, 'compile'), (imports, 'warm')]
write(pair / 'jobs.json', {'warm': jobs})
for name in ('collect.py', 'run.sh', 'cpython-worker.py'):
    copy2(prior / 'comparison' / name, pair / name)
assert b'\r' not in (pair / 'run.sh').read_bytes()
assert digest(pair / 'cpython-worker.py') == setup['pythonWorkerSHA256']
write(pair / 'identity.json', dict(sourceRevision=head, sourcePatchSHA256=sha256(patch).hexdigest(), imageFiles=images,
    coreSHA256={role + suffix: hashes['Lokad.Lython.dll'] for role, hashes in images.items() for suffix in ('', '-control')},
    cpythonWorkerSHA256=setup['pythonWorkerSHA256'], expectedCPythonSHA256=setup['pythonSHA256'],
    purpose='Use one module identifier index and materialize frontend surfaces on access.',
    catalogs={name: {'sha256': digest(pair / name)} for name in ('representative.json', 'jobs.json', 'config.json', 'xml.json', 'generated.json')}))

for name in ('collect-cold.py', 'measure-allocations.py', 'summarize-warm.py'):
    content = (prior / name).read_text(encoding='utf-8').replace(prior.name, lab.name)
    if name == 'measure-allocations.py':
        content = content.replace("cases=('config.json','xml.json')", "cases=('config.json','xml.json','generated.json')")
        content = content.replace('verifiedCompilations=28', 'verifiedCompilations=42')
    (lab / name).write_text(content, encoding='utf-8', newline='\n')

probe = lab / 'probe'
probe.mkdir()
for name in ('ModuleProbe.csproj', 'Program.cs'):
    copy2(prior / 'probe' / name, probe / name)
