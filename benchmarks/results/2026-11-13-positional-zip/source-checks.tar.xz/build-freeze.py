from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;prior=r.parent/'checkpoint-cpython-r318'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=json.loads((prior/'candidate-identity.json').read_text(encoding='utf-8'))
paths=list(old['sources'])+['src/Lokad.Lython/Runtime/Zip/ZipDirectoryReader.Source.cs','src/Lokad.Lython/Runtime/Zip/ZipReadSource.cs']
assert len(paths)==len(set(paths))==575
sources={p:sha(p)for p in paths}
sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
p=r/'benchmark-build.log';assert not p.exists()
with p.open('w',encoding='utf-8')as log:done=subprocess.run([str(sdk/'dotnet.exe'),'build','benchmarks/Lokad.Lython.Benchmarks/Lokad.Lython.Benchmarks.csproj','-c','Release','-f','net11.0','--no-restore','--no-incremental','--disable-build-servers','-m:1'],env=env,stdout=log,stderr=subprocess.STDOUT)
print(done.returncode,p.read_text(encoding='utf-8')[-2200:],flush=True);assert done.returncode==0
assert sources=={p:sha(p)for p in paths}
image=Path('benchmarks/Lokad.Lython.Benchmarks/bin/Release/net11.0')
subprocess.run([str(sdk/'dotnet.exe'),str(image/'Lokad.Lython.Benchmarks.dll'),'--compare','list','--profile','representative','--out',str(r/'all-representative.json')],env=env,check=True)
for role in ['candidate','reference']:(r/role).mkdir()
for p in image.iterdir():
 if p.is_file()and(p.suffix=='.dll'or p.name.endswith(('.deps.json','.runtimeconfig.json'))):shutil.copyfile(p,r/'candidate'/p.name)
for p in (prior/'candidate').iterdir():
 if p.is_file():os.link(p,r/'reference'/p.name)
shutil.copyfile(r/'candidate/Lokad.Lython.dll',r/'candidate-core.dll')
identity=dict(headBeforeCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),description='R319 optional opened positional ZIP input; one shared parser; eager validation; selected member storage; actual async and funded private outputs; ZIP64/overlap/index corrections',coreSHA256=sha(r/'candidate-core.dll'),referenceSHA256=old['coreSHA256'],sources=sources,coreSourceCount=575,candidateAuxiliaryFiles={p.name:sha(p)for p in (r/'candidate').iterdir()if p.name!='Lokad.Lython.dll'},referenceAuxiliaryFiles={p.name:sha(p)for p in (r/'reference').iterdir()if p.name!='Lokad.Lython.dll'},fullDeliveryQualified=False)
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as a:
 for p in paths:a.add(p,arcname=p)
print('Frozen',identity['coreSHA256'],'575source inputs; new and old worker identities kept distinct. No delivery/CPU claim.',flush=True)
