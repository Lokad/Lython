from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).parent;prior=r.parent/'checkpoint-cpython-r318';identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in identity['sources'].items())
for framework in ['net11.0','net10.0']:
 s=(prior/'zip-current'/(framework+'-test.log')).read_text(encoding='utf-8');assert 'Test Run Successful.'in s and 'Passed: 27'in s
for kind,count in [('public',49),('internal',26)]:
 s=(prior/'zip-check-r8'/(kind+'-test.log')).read_text(encoding='utf-8');assert 'Test Run Successful.'in s and f'Passed: {count}'in s
out=Path('benchmarks/results/2026-11-13-positional-zip');out.mkdir(exist_ok=True)
with tarfile.open(out/'source-checks.tar.xz','w:xz')as a:
 for name in ['candidate-core.dll','candidate-identity.json','candidate-sources.tar.xz','candidate-build-adapter.dll','benchmark-build.log','build-freeze.py','pin-comparison-adapter.py','python-info-goldens.py','record-source-checks.py']:a.add(r/name,arcname=name)
 for name in ['Lokad.Lython.Benchmarks.dll','Lokad.Lython.Utf8Regex.dll']:a.add(r/'candidate'/name,arcname='candidate/'+name)
 for folder in ['zip-check','zip-check-r2','zip-check-r3','zip-check-r4','zip-check-r5','zip-check-r6','zip-check-r7','zip-check-r8','zip-final-internal','zip-latest','zip-current']:
  for p in sorted((prior/folder).glob('*.log')):a.add(p,arcname='checks/'+folder+'/'+p.name)
 for p in ['tests/Lokad.Lython.PublicApi.Tests/PositionalZipTests.cs','tests/Lokad.Lython.Tests/ZipDirectoryReaderTests.cs','tests/Lokad.Lython.PublicApi.Tests/ComparisonFileWorkerTests.cs','benchmarks/Lokad.Lython.Benchmarks/Comparison/ComparisonFileHost.cs','benchmarks/Lokad.Lython.Benchmarks/Comparison/WorkloadCatalog.cs','benchmarks/scripts/zip-config.py']:a.add(p,arcname=p)
done=subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'python-info-goldens.py')],capture_output=True,text=True,encoding='utf-8');assert done.returncode==0 and done.stdout=="b'hello'\nbad name\nb'hello'\nmissing\n"
(out/'python-info-goldens.log').write_text('CPython3.13.2 independent semantic check\n'+done.stdout,encoding='utf-8',newline='\n')
print('575source inputs and frozen97bb core;27new public per11/10;49public/26internal Release11; initial failures retained. Delivery/performance pending.',flush=True)
