from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).parent;p=r/'candidate-identity.json';identity=json.loads(p.read_text(encoding='utf-8'))
assert not subprocess.check_output(['git','diff','6237552b','--name-only','--','src/Lokad.Lython.Utf8Regex'],text=True).strip()
adapter=r/'candidate/Lokad.Lython.Utf8Regex.dll';backup=r/'candidate-build-adapter.dll';assert not backup.exists()
shutil.copyfile(adapter,backup);original=hashlib.sha256(backup.read_bytes()).hexdigest()
shutil.copyfile(r/'reference/Lokad.Lython.Utf8Regex.dll',adapter)
identity['candidateAuxiliaryFiles'][adapter.name]=hashlib.sha256(adapter.read_bytes()).hexdigest()
identity['comparisonAdapter']=dict(pinnedReferenceBinary=True,normalAdapterSourcesUnchangedSince='6237552b',originalBuildSHA256=original,pinnedSHA256=identity['candidateAuxiliaryFiles'][adapter.name],reason='Retain exact unchanged optional0.4 adapter bytes across source pair; avoid generated Git metadata as a second image difference')
p.write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Pinned unchanged adapter byte identity; original newly built metadata variant retained.',flush=True)
