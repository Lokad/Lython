import io,zipfile
payload=io.BytesIO()
with zipfile.ZipFile(payload,'w')as archive:archive.writestr('small',b'hello')
with zipfile.ZipFile(io.BytesIO(payload.getvalue()))as archive:
 info=zipfile.ZipInfo('small');info.header_offset=0;info.compress_size=5;info.file_size=5;info.CRC=0x3610a686
 print(archive.read(info))
 bad=zipfile.ZipInfo('different');bad.header_offset=0;bad.compress_size=5;bad.file_size=5;bad.CRC=info.CRC
 try:archive.read(bad)
 except zipfile.BadZipFile:print('bad name')
 archive.infolist()[0].filename='renamed'
 print(archive.read('small'))
 try:archive.read('renamed')
 except KeyError:print('missing')
