from pathlib import Path
import os,subprocess
r=Path(__file__).parent/'overlap-correction';r.mkdir()
sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
for framework in ['net11.0','net10.0']:
 for phase,args in [('build',['build','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f',framework,'--no-restore','--disable-build-servers','-m:1']),('test',['vstest','tests/Lokad.Lython.PublicApi.Tests/bin/Release/'+framework+'/Lokad.Lython.PublicApi.Tests.dll','--TestCaseFilter:FullyQualifiedName~ZipCompatibilityTests|FullyQualifiedName~PositionalZipTests','--logger:console;verbosity=normal'])]:
  p=r/(framework+'-'+phase+'.log')
  with p.open('w',encoding='utf-8')as log:done=subprocess.run([str(sdk/'dotnet.exe')]+args,env=env,stdout=log,stderr=subprocess.STDOUT)
  txt=p.read_text(encoding='utf-8');print(p.name,done.returncode,txt[-1700:],flush=True);assert done.returncode==0
