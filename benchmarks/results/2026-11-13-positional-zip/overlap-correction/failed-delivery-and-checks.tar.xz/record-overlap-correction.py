from pathlib import Path
import hashlib,io,json,subprocess,tarfile
r=Path(__file__).parent;state=json.loads((r/'ci-terminal.json').read_text(encoding='utf-8'));candidate=json.loads((r/'delivery-candidate.json').read_text(encoding='utf-8'));identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert state['conclusion']=='failure'and state['headSha']==candidate['head']
out=Path('benchmarks/results/2026-11-13-positional-zip/overlap-correction');out.mkdir(exist_ok=True)
for framework in ['net11.0','net10.0']:
 s=(r/'overlap-correction'/(framework+'-test.log')).read_text(encoding='utf-8');assert 'Test Run Successful.'in s and 'Passed: 120'in s
(out/'ci-terminal-failed.json').write_bytes((r/'ci-terminal.json').read_bytes())
with tarfile.open(out/'failed-delivery-and-checks.tar.xz','w:xz')as a:
 for p in sorted(r.glob('failed-job-*.log')):a.add(p,arcname=p.name)
 for p in sorted((r/'overlap-correction').glob('*.log')):a.add(p,arcname='focused/'+p.name)
 for name in ['python-overlap-golden.py','check-overlap-correction.py','record-overlap-correction.py']:a.add(r/name,arcname=name)
 a.add('tests/Lokad.Lython.PublicApi.Tests/ZipCompatibilityTests.cs',arcname='corrected/ZipCompatibilityTests.cs')
done=subprocess.run(['C:/Python313/python.exe','-X','utf8',str(r/'python-overlap-golden.py')],capture_output=True,text=True,encoding='utf-8');assert done.returncode==0 and done.stdout=="['a', 'a']\nb'x'\noverlapped\n"
(out/'python-overlap-golden.log').write_text('CPython3.13.2 independent semantic reference\n'+done.stdout,encoding='utf-8',newline='\n')
with tarfile.open(r/'candidate-sources.tar.xz')as frozen,tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive',candidate['head'],'src/Lokad.Lython'])))as committed:
 for name,sha in identity['sources'].items():
  b=frozen.extractfile(name).read();assert hashlib.sha256(b).hexdigest()==sha and b.replace(b'\r\n',b'\n')==committed.extractfile(name).read().replace(b'\r\n',b'\n')
(out/'source-proof.json').write_text(json.dumps(dict(commit=candidate['head'],coreSHA256=identity['coreSHA256'],productionFiles=575,allFrozenSourcesMatchCommitWithExplicitNewlineNormalization=True,runtimeUnchangedByTestCorrection=True,fullDeliveryQualified=False,failedRun=candidate['runId']),indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'README.md').write_text('''# Overlapping-entry expectation correction

CI43461763537 on976f9439/frozen97bbeff3 passes4684white-box and17533/17534public
cases on each platform. One old test expects a duplicate physical header to be
readable through its last-name lookup. CPython instead selects the overlapping
duplicate and raises BadZipFile. The first explicit info remains readable.
Later.NET10/stress/installed-consumer gates are skipped; full delivery is incomplete.

Correct the test to preserve duplicate listings, first-info access, Python-shaped
rejection of the overlapping name lookup, append rejection and unchanged source
bytes. Do not weaken the runtime's overlap protection. Independent CPython3.13.2
golden and120focused public cases pass per actual.NET11/10. Runtime sources and
the measured97bbimage are unchanged. Original completed job logs, corrected test,
focused checks and exact575source matches are retained. Corrected delivery is pending.
''',encoding='utf-8',newline='\n')
print('Original failed cross-platform delivery and independent Python golden preserved;120focused per11/10 pass; runtime97bb unchanged.',flush=True)
