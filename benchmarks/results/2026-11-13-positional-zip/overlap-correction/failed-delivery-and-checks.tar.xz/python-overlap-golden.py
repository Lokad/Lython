import io,struct,zipfile
stream=io.BytesIO()
with zipfile.ZipFile(stream,'w')as archive:archive.writestr('a',b'x')
data=stream.getvalue();end=len(data)-22;size,offset=struct.unpack_from('<II',data,end+12)
first=data[offset:offset+size];duplicate=bytearray(data[:offset+size]+first+data[offset+size:]);moved=end+len(first)
struct.pack_into('<HH',duplicate,moved+8,2,2);struct.pack_into('<I',duplicate,moved+12,size+len(first))
with zipfile.ZipFile(io.BytesIO(duplicate))as archive:
 print(archive.namelist())
 print(archive.read(archive.infolist()[0]))
 try:archive.read('a')
 except zipfile.BadZipFile:print('overlapped')
