from pathlib import Path
import base64,hashlib,json,shutil,tarfile
r=Path(__file__).parent;good=r/'b685';failed=r/'b684';out=Path('benchmarks/results/2026-11-13-positional-zip/comparison');out.mkdir(exist_ok=True)
summary=json.loads((good/'summary.json').read_text(encoding='utf-8'));receipt=json.loads((good/'archive-receipt.json').read_text(encoding='utf-8'));assert summary['complete']and summary['jobs']==3
assert hashlib.sha256((good/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
assert hashlib.sha256((failed/'failed-observations.tgz').read_bytes()).hexdigest()==json.loads((failed/'failure-receipt.json').read_text(encoding='utf-8'))['archiveSHA256']
for name in ['observations.tgz','archive-receipt.json','summary.json','terminal-status.json']:shutil.copyfile(good/name,out/name)
for name in ['failed-observations.tgz','failure-receipt.json','failure-details.json']:shutil.copyfile(failed/name,out/name)
with tarfile.open(out/'collection-and-images.tar.xz','w:xz')as a:
 for phase in ['b684','b685']:
  for name in ['collect.py','archive-owned.py','run.sh','launch.py','launch-remote.py','launch-command.py','launch.log','config.json','identity.json','retrieve.py','summarize.py']:
   if(r/phase/name).exists():a.add(r/phase/name,arcname=phase+'/'+name)
 for p in(failed/'preparation-reference-mismatch').iterdir():a.add(p,arcname='initial-reference-mismatch/'+p.name)
 for name in ['verified-reference-Lokad.Lython.Benchmarks.dll','verified-reference-Lokad.Lython.Utf8Regex.dll','candidate-identity.json','committed-source.json','correct-reference-image.py','reference-image-mismatch.json','retirement-inspection.json','additional-core-canonical.json','prepare-wall-confirmation.py','record-comparison.py']:a.add(r/name,arcname=name)
 for name in ['Lokad.Lython.Benchmarks.dll','Lokad.Lython.Utf8Regex.dll']:a.add(r/'candidate'/name,arcname='candidate/'+name)
catalog=json.loads((failed/'representative.json').read_text(encoding='utf-8'))
print([(c['id'],c['size'],sum(len(base64.b64decode(v))for v in json.loads(c['fixtureJson'])['inputFiles'].values()))for c in catalog['cases']],flush=True)
print('Complete same-source confirmation and original partial/error conditions preserved.575runtime sources unchanged; adapter/reference binary correction explicit.',flush=True)
