from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent;old=r/'b684';out=r/'b685';out.mkdir()
oldroot='/home/lokad/lython-bench-checks/positional-zip-b684-20261113';root='/home/lokad/lython-bench-checks/positional-zip-b685-20261113'
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=(old/name).read_text(encoding='utf-8').replace(oldroot,root).replace('lython-b684-positional-zip-20261113','lython-b685-positional-zip-20261113').replace('B684','B685')
 if name=='collect.py':
  s=s.replace('        self.sequence += 1\n        request =','        request_started=time.monotonic()\n        self.sequence += 1\n        request =')
  s=s.replace("        assert response['requestId']", "        self.last_request_seconds=time.monotonic()-request_started\n        assert response['requestId']")
  s=s.replace('targetBatchSeconds=.5','targetBatchSeconds=.25, batchSizingBoundary=\'full request wall time, unchanged guest timing\'')
  s=s.replace("seconds=response['elapsedTicks']/response['clockFrequency']","seconds=w.last_request_seconds")
  s=s.replace('math.ceil(count*.5/max(seconds,.000001))','math.ceil(count*.25/max(seconds,.000001))')
 if name.endswith('.py'):ast.parse(s)
 (out/name).write_text(s,encoding='utf-8',newline='\n')
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'));identity['confirmation']='B684 retained2partial jobs but lacks invoice/final gate after wall-budget guard; B685sizes batches by full request wall time with unchanged guest clocks and240second owner'
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
files={name:out/name for name in ['collect.py','archive-owned.py','run.sh','identity.json']}
with tarfile.open(out/'payload.tgz','w:gz')as a:
 for name,p in files.items():a.add(p,arcname=name)
config=json.loads((old/'config.json').read_text(encoding='utf-8'));config.update(root=root,unit='lython-b685-positional-zip-20261113',sourceRoot=oldroot,identity=identity,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=sha(out/'payload.tgz'),unpackedBytes=sum(p.stat().st_size for p in files.values()),retire=[])
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'launch-remote.py').read_text(encoding='utf-8').replace('positional-zip-b684','positional-zip-b685').replace('lython-b684-fixtures','lython-b685-fixtures')
s=s.replace("{'identity.json','collect.py','archive-owned.py','run.sh','current-core.dll','current-worker.dll','source-identity.json','representative.json'}","{'identity.json','collect.py','archive-owned.py','run.sh'}")
a=s.index(" os.link(source/'cpython-worker.py'");b=s.index(" assert digest(root/'source-identity.json')",a)
s=s[:a]+''' for name in ['cpython-worker.py','source-identity.json','reference-source-identity.json','representative.json']:os.link(source/name,root/name)
 for role in ['candidate','reference']:
  (root/role).mkdir()
  for name,sha in config['identity'][role+'AuxiliaryFiles'].items():
   assert digest(source/role/name)==sha
   os.link(source/role/name,root/role/name)
  assert digest(source/role/'Lokad.Lython.dll')==config['identity']['coreSHA256'][role]
  os.link(source/role/'Lokad.Lython.dll',root/role/'Lokad.Lython.dll')
'''+s[b:]
ast.parse(s.replace('CONFIG_LITERAL','{}'));(out/'launch-remote.py').write_text(s,encoding='utf-8',newline='\n')
(out/'launch.py').write_bytes((old/'launch.py').read_bytes())
print('Prepared bounded same-image confirmation,3jobs/6roles, full-wall batch calibration, unchanged guest measurement/240second owner. No new runtime build/upload.',flush=True)
