from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile
config=CONFIG_LITERAL
base=Path('/home/lokad/lython-bench-checks').resolve()
root=Path(config['root']);source=Path(config['sourceRoot'])
assert root.parent==base and source.parent==base and source.resolve()==source and not root.exists()
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not(source/'guest-fixtures').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[d]otnet.*complete-jobs.dll|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 for name,sha in config['identity']['referenceAuxiliaryFiles'].items():assert digest(source/'reference'/name)==sha
 assert digest(source/'reference/Lokad.Lython.dll')==config['identity']['coreSHA256']['reference']
 payload=sys.stdin.buffer.read(config['payloadBytes']+1)
 assert len(payload)==config['payloadBytes'] and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 before=shutil.disk_usage(base).free
 for old in config['retire']:
  p=base/old['path'];s=p.lstat()
  assert p.resolve(strict=True)==p and p.is_relative_to(base) and stat.S_ISREG(s.st_mode) and s.st_uid==os.getuid()
  assert(s.st_dev,s.st_ino,s.st_nlink,s.st_size)==(old['device'],old['inode'],old['links'],old['bytes'])
  assert digest(p)==old['sha256']
  aliases=[]
  for folder,dirs,files in os.walk(base,followlinks=False):
   for name in files:
    q=Path(folder)/name;t=q.lstat()
    if(t.st_dev,t.st_ino)==(s.st_dev,s.st_ino):aliases.append(str(q.relative_to(base)))
  assert sorted(aliases)==sorted(old['aliases']) and len(aliases)==s.st_nlink
  assert old['sha256']not in config['identity']['coreSHA256'].values()
  assert all('positional-zip-b684'not in name for name in aliases)
 print(json.dumps(dict(freshIdleLease=True,beforeFreeBytes=before,canonicalWorkingCopiesToRetire=sum(old['allocatedBytes']for old in config['retire']),requiredBytes=252*1024*1024+config['unpackedBytes']+2*1024*1024)),flush=True)
 assert before+sum(old['allocatedBytes']for old in config['retire'])>252*1024*1024+config['unpackedBytes']+2*1024*1024
 # Retire only byte-proved obsolete working copies; canonical Git evidence remains.
 for old in config['retire']:
  for name in old['aliases']:
   q=base/name;t=q.lstat()
   assert q.resolve(strict=True)==q and q.is_relative_to(base) and(t.st_dev,t.st_ino)==(old['device'],old['inode'])
   q.unlink()
 after_retirement=shutil.disk_usage(base).free
 assert after_retirement>252*1024*1024+config['unpackedBytes']+2*1024*1024
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:
  assert set(a.getnames())=={'identity.json','collect.py','archive-owned.py','run.sh','current-core.dll','current-worker.dll','source-identity.json','representative.json'}
  a.extractall(root,filter='data')
 os.link(source/'cpython-worker.py',root/'cpython-worker.py')
 os.link(source/'source-identity.json',root/'reference-source-identity.json')
 for role in ['candidate','reference']:
  (root/role).mkdir()
  expected=config['identity'][role+'AuxiliaryFiles']
  for name,sha in expected.items():
   origin=root/'current-worker.dll'if role=='candidate'and name=='Lokad.Lython.Benchmarks.dll'else source/'reference'/name
   assert digest(origin)==sha
   os.link(origin,root/role/name)
  origin=root/'current-core.dll'if role=='candidate'else source/'reference/Lokad.Lython.dll'
  os.link(origin,root/role/'Lokad.Lython.dll')
  assert digest(root/role/'Lokad.Lython.dll')==config['identity']['coreSHA256'][role]
 assert digest(root/'source-identity.json')==config['identity']['sourceIdentitySHA256']
 assert digest(root/'representative.json')==config['identity']['catalogSHA256']
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 (root/'space-preflight.json').write_text(json.dumps(dict(freshIdleLease=True,beforeFreeBytes=before,afterRetirementFreeBytes=after_retirement,afterStagingFreeBytes=shutil.disk_usage(base).free,osFloorMiB=240,evidenceHeadroomMiB=12,additionalArchiveHeadroomMiB=2,retiredByteProvedCanonicalWorkingCopies=config['retire']),indent=2)+'\n')
 assert shutil.disk_usage(base).free>254*1024*1024
 fixture=root/'guest-fixtures';fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b684-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=240','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
live=subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True)
assert'ActiveState=active'in live and'MainPID=0'not in live
print(live)
