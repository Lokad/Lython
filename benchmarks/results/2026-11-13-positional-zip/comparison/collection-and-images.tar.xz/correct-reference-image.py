from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;out=r/'b684';backup=out/'preparation-reference-mismatch';backup.mkdir()
for name in ['launch.log','launch-command.py','identity.json','config.json']:
 if(out/name).exists():shutil.copyfile(out/name,backup/name)
for name in ['candidate-identity.json','candidate-build-adapter.dll']:shutil.copyfile(r/name,backup/name)
manifest=json.loads((r.parent/'checkpoint-cpython-r318/b683/identity.json').read_text(encoding='utf-8'))
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15']
for name in ['Lokad.Lython.Benchmarks.dll','Lokad.Lython.Utf8Regex.dll']:
 p=r/('verified-reference-'+name);assert not p.exists()
 done=subprocess.run(scp+['lokad@20.166.121.73:/home/lokad/lython-bench-checks/retained-external-b683-20261113/reference/'+name,str(p)],capture_output=True,text=True,encoding='utf-8');assert done.returncode==0,done.stderr
 assert hashlib.sha256(p.read_bytes()).hexdigest()==manifest['auxiliaryFiles'][name]
 # Break the old local hard link before replacement, preserving its old bytes.
 old=r/'reference'/name;shutil.copyfile(old,backup/('local-reference-'+name));old.unlink();shutil.copyfile(p,old)
 if name=='Lokad.Lython.Utf8Regex.dll':shutil.copyfile(p,r/'candidate'/name)
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
identity['referenceAuxiliaryFiles']=manifest['auxiliaryFiles']
identity['candidateAuxiliaryFiles']={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in(r/'candidate').iterdir()}
identity['candidateAuxiliaryFiles'].pop('Lokad.Lython.dll')
identity['comparisonAdapter']['pinnedSHA256']=manifest['auxiliaryFiles']['Lokad.Lython.Utf8Regex.dll']
identity['comparisonReferenceCorrection']='Use byte-verified immutable VM image, not locally mutated reference hard links; failed preflight ran no worker'
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
config=json.loads((out/'config.json').read_text(encoding='utf-8'))
config['identity']['referenceAuxiliaryFiles']=identity['referenceAuxiliaryFiles'];config['identity']['candidateAuxiliaryFiles']=identity['candidateAuxiliaryFiles']
config['identity']['sourceIdentitySHA256']=hashlib.sha256((r/'candidate-identity.json').read_bytes()).hexdigest()
files={name:out/name for name in ['collect.py','archive-owned.py','run.sh','representative.json']}
(out/'identity.json').write_text(json.dumps(config['identity'],indent=2)+'\n',encoding='utf-8',newline='\n');files['identity.json']=out/'identity.json'
files.update({'current-core.dll':r/'candidate-core.dll','current-worker.dll':r/'candidate/Lokad.Lython.Benchmarks.dll','source-identity.json':r/'candidate-identity.json'})
with tarfile.open(out/'payload.tgz','w:gz')as a:
 for name,p in files.items():a.add(p,arcname=name)
config.update(payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum(p.stat().st_size for p in files.values()))
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Exact fec79worker/9f728adapter fetched and verified against completed B683; failed local-reference condition preserved. Core97bb/575inputs unchanged.',flush=True)
