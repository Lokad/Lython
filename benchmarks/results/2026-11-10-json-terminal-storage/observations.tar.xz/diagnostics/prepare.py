from pathlib import Path
import hashlib,json,shutil,subprocess
root=Path('D:/code/Lython');home=Path(__file__).parent
base=json.loads((home.parent/'small-integers-r176/baseline.json').read_text(encoding='utf-8'))
names=['Runtime/LythonRuntime.Json.Serialize.cs','Runtime/LythonRuntime.Json.Options.cs']
changed=subprocess.check_output(['git','diff','--name-only','--','src/Lokad.Lython'],text=True).splitlines()
assert set(changed)=={'src/Lokad.Lython/'+p for p in names}
for name in names:
    old=home.parent/'small-integers-r176/before-source'/name
    assert hashlib.sha256(old.read_bytes()).hexdigest()==base['productionSources'][(root/'src/Lokad.Lython'/name).as_posix()]
    dest=home/'before-source'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(old,dest)
shutil.copytree(home.parent/'text-cache-storage-r173/refined/images/candidate',home/'images/before')
shutil.copyfile(home.parent/'call-inputs-r175/catalog.json',home/'catalog.json')
(home/'baseline.json').write_text(json.dumps(dict(revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),productionSources=base['productionSources'],
    contract='Consume only terminal JSON serializer/indent buffers after all writers finish. Existing transfer admits metadata and retains full already-funded capacity. Keep reused iterencode chunk copies.',
    displaced='Two final output-sized UTF-8 array copies and final-copy reservation objects. No new ownership mechanism or configuration.',
    tradeoff='Lower construction overlap and CLR allocation can coexist with more retained spare capacity. Inspect public memory reporting/retained funding before deciding.'),indent=2)+'\n',encoding='utf-8')
print('Qualified baseline source/call paths verified; only two terminal JSON consumption changes.')
