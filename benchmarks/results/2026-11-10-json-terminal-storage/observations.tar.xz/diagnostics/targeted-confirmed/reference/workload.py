import json

with open('records.json') as source:
    records = json.load(source)
with open('manifest.jsonl', 'w', newline='') as target:
    for record in records:
        target.write(json.dumps(record, ensure_ascii=False, sort_keys=True, separators=(',', ':')))
        target.write('\n')
print(len(records))
