from pathlib import Path
import os,subprocess,sys
root=Path('D:/code/Lython');home=Path(__file__).parent
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
public='(Category!=Stress)&(FullyQualifiedName~Json|FullyQualifiedName~FramedFunctionExecutionTests|FullyQualifiedName~NativeReturnFunctionTests|FullyQualifiedName~LythonProbeCliTests)'
internal='(Category!=Stress)&(FullyQualifiedName~Json|FullyQualifiedName~GovernedByteBuilder|FullyQualifiedName~Transferred|FullyQualifiedName~TerminalStringStorage)'
jobs=[('probe11',['build','tools/LythonProbe/LythonProbe.csproj','-f','net11.0']),
 ('public11',['test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-f','net11.0','--filter',public]),
 ('build10',['build','src/Lokad.Lython/Lokad.Lython.csproj','-f','net10.0','--no-incremental']),
 ('internal10',['test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-f','net10.0','--filter',internal]),
 ('probe10',['build','tools/LythonProbe/LythonProbe.csproj','-f','net10.0']),
 ('public10',['test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-f','net10.0','--filter',public]),
 ('freeze11',['build','src/Lokad.Lython/Lokad.Lython.csproj','-f','net11.0','--no-incremental'])]
for name,args in jobs:
    log=home/(name+'.log')
    with log.open('w',encoding='utf-8') as out:
        done=subprocess.run([env['DOTNET_HOST_PATH'],*args,'-c','Release','-v','q'],env=env,cwd=root,stdout=out,stderr=subprocess.STDOUT,timeout=240)
    print(name,'exit',done.returncode,flush=True)
    if done.returncode:print(log.read_text(encoding='utf-8')[-5000:],flush=True);sys.exit(done.returncode)
text=(home.parent/'small-integers-r176/measure.py').read_text(encoding='utf-8')
text=text.replace("purpose='Contract-preserving signed32 guest integer transport; unchanged public BigInteger and CLR ingress contracts.",
    "purpose='Consume terminal JSON buffers through existing transferred-capacity ownership; array copy/lease eliminated, full backing remains funded. No new policy or cache.")
text=text.replace("subprocess.check_output(['git', 'diff', '--binary', '--', 'src/Lokad.Lython', 'tests'])", "subprocess.check_output(['git', '-c', 'core.safecrlf=false', 'diff', '--binary', '--', 'src/Lokad.Lython', 'tests', 'tools/LythonProbe'], stderr=subprocess.DEVNULL)")
(home/'measure.py').write_text(text,encoding='utf-8',newline='\n')
subprocess.run([sys.executable,'-X','utf8',str(home/'measure.py')],env=env,cwd=root,check=True)
