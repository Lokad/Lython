from pathlib import Path
import hashlib,json,shutil,tarfile
root=Path('D:/code/Lython');home=Path(__file__).parent;out=root/'benchmarks/results/2026-11-10-json-terminal-storage';out.mkdir()
for name in ['baseline.json','identity.json','source.patch','desktop.json']:
    shutil.copyfile(home/name,out/name)
shutil.copyfile(home/'targeted-confirmed/desktop.json',out/'jsonl-desktop.json')
shutil.copyfile(home/'targeted-confirmed/golden.json',out/'jsonl-golden.json')
shutil.copyfile(home/'peak/observations.json',out/'peak.json')
with tarfile.open(out/'observations.tar.xz','w:xz')as t:
    for p in sorted(home.rglob('*')):
        if not p.is_file():continue
        rel=p.relative_to(home)
        if 'images'in rel.parts or any(part in ['before','candidate']for part in rel.parts):continue
        t.add(p,arcname='diagnostics/'+rel.as_posix())
    for role in ['before','candidate']:t.add(home/'images'/role/'Lokad.Lython.dll',arcname='cores/'+role+'.dll')
    ident=json.loads((home/'identity.json').read_text())
    for name in ['Runtime/LythonRuntime.Json.Serialize.cs','Runtime/LythonRuntime.Json.Options.cs']:
        p=root/'src/Lokad.Lython'/name
        assert hashlib.sha256(p.read_bytes()).hexdigest()==ident['productionSources'][p.as_posix()]
        t.add(p,arcname='source/candidate/'+name)
        t.add(home/'before-source'/name,arcname='source/before/'+name)
    for p in [root/'tests/Lokad.Lython.Tests/JsonStringEmissionAdmissionTests.cs',root/'tools/LythonProbe/Program.cs']:t.add(p,arcname='source/'+p.relative_to(root).as_posix())
summary={}
for lane,rows in json.loads((home/'targeted-confirmed/desktop.json').read_text()).items():
    row=next(r for r in rows if r['case']=='scripts.report-render.large')
    summary[lane]={k:row[k]for k in ['allocationPercent','elapsedPercent']}
(out/'summary.json').write_text(json.dumps(dict(source='fcf018d2 plus two terminal JSON builder-consumption changes; no R179 guard change in these images',cores=json.loads((home/'identity.json').read_text())['cores'],jsonl=summary,qualification=dict(internalEachTarget=193,publicEachTarget=861,fullCheckpoint='Pending combined retained delivery'),archiveSHA256=hashlib.sha256((out/'observations.tar.xz').read_bytes()).hexdigest()),indent=2)+'\n')
print(json.dumps(summary,indent=2))
