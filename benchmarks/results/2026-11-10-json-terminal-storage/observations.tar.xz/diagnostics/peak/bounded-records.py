import json
for i in range(32):
    value = json.dumps({'name': 'é😀'*65, 'n':i}, ensure_ascii=False, indent=2)
print(len(value))
return value
