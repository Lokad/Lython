import json
value = json.dumps({'name': 'é😀'*4097, 'n':17}, ensure_ascii=False, sort_keys=True)
print(len(value))
return value
