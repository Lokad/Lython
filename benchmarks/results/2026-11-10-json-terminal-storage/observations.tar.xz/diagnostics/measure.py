from pathlib import Path
import hashlib, json, os, shutil, statistics, subprocess

root = Path('D:/code/Lython')
home = Path(__file__).parent
env = os.environ.copy()
env['DOTNET_ROOT'] = 'C:/Users/JoannesVermorel/.dotnet11'
env['DOTNET_HOST_PATH'] = env['DOTNET_ROOT'] + '/dotnet.exe'
env['PATH'] = env['DOTNET_ROOT'] + os.pathsep + env['PATH']
shutil.copytree(home / 'images/before', home / 'images/candidate')
shutil.copyfile(root / 'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll', home / 'images/candidate/Lokad.Lython.dll')
assert all(p.read_bytes() == (home / 'images/candidate' / p.name).read_bytes()
           for p in (home / 'images/before').iterdir() if p.is_file() and p.name != 'Lokad.Lython.dll')
(home / 'source.patch').write_bytes(subprocess.check_output(['git', '-c', 'core.safecrlf=false', 'diff', '--binary', '--', 'src/Lokad.Lython', 'tests', 'tools/LythonProbe'], stderr=subprocess.DEVNULL))
(home / 'identity.json').write_text(json.dumps(dict(
    cores={label: hashlib.sha256((home / 'images' / label / 'Lokad.Lython.dll').read_bytes()).hexdigest() for label in ['before', 'candidate']},
    productionSources={p.as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in (root / 'src/Lokad.Lython').rglob('*.cs') if 'obj' not in p.parts},
    catalogSHA256=hashlib.sha256((home/'catalog.json').read_bytes()).hexdigest(),
    purpose='Consume terminal JSON buffers through existing transferred-capacity ownership; array copy/lease eliminated, full backing remains funded. No new policy or cache. Complete trusted scripts in existing driver; not CPython or CPU qualification.'
), indent=2)+'\n', encoding='utf-8')
summary = {}
for phase, api in [('warm','sync'), ('warm','async'), ('compile','sync')]:
    label = phase+'-'+api
    folder = home / label
    folder.mkdir()
    witness = folder / 'hash-witness.json'
    witness.write_text(json.dumps(dict(source="return [hash('Lython-é😀'), hash((1, 2.0, True))]\n"), ensure_ascii=False)+'\n', encoding='utf-8')
    with (folder/'measurements.json').open('w', encoding='utf-8') as out, (folder/'stderr.txt').open('w', encoding='utf-8') as err:
        done = subprocess.run([env['DOTNET_HOST_PATH'], str(home.parent/'bulk-whitespace-r157/tool/out/complete-jobs.dll'),
            str(home/'images/before/Lokad.Lython.Benchmarks.dll'), str(home/'images/candidate/Lokad.Lython.Benchmarks.dll'),
            str(home/'catalog.json'), str(witness), 'reverse', phase, api], env=env, stdout=out, stderr=err, timeout=120)
    assert done.returncode == 0, (folder/'stderr.txt').read_text(encoding='utf-8')[-3500:]
    data = json.loads((folder/'measurements.json').read_text(encoding='utf-8'))
    assert all(data[k] for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
    summary[label] = []
    for case in data['observations']:
        values = {role: {name: statistics.median(s[field]/s['jobs'] for s in case['samples'] if s['image']==role)
                   for name, field in [('bytes','allocatedBytes'), ('elapsedMs','elapsedMilliseconds' if phase=='compile' else 'executionMilliseconds')]}
                  for role in ['before','before-control','candidate']}
        row = dict(case=case['caseId'], roles=values,
                   allocationPercent=[100*(values['candidate']['bytes']/values[b]['bytes']-1) for b in ['before','before-control']],
                   elapsedPercent=[100*(values['candidate']['elapsedMs']/values[b]['elapsedMs']-1) for b in ['before','before-control']])
        summary[label].append(row)
        print(label, row['case'], 'allocation', [round(v,2) for v in row['allocationPercent']], 'elapsed', [round(v,2) for v in row['elapsedPercent']], flush=True)
    (home/'desktop.json').write_text(json.dumps(summary, indent=2)+'\n', encoding='utf-8')
print('Warm both APIs and compilation complete; goldens/ownership/isolation/cleanup pass. Desktop elapsed remains diagnostic.', flush=True)
