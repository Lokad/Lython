from pathlib import Path
import base64,hashlib,json,shutil,struct,subprocess,sys
root=Path('D:/code/Lython');home=Path(__file__).parent;target=home/'targeted-confirmed';target.mkdir()
catalog=json.loads((home/'catalog.json').read_text(encoding='utf-8'))
row=next(r for r in catalog['cases'] if r['id']=='scripts.report-render.large')
fixture=json.loads(row['fixtureJson'])
def digest_files(files):
    h=hashlib.sha256();h.update(struct.pack('>i',len(files)))
    for name,data in sorted(files.items()):
        raw=name.encode('utf-8');h.update(struct.pack('>i',len(raw)));h.update(raw);h.update(struct.pack('>i',len(data)));h.update(data)
    return h.hexdigest()
assert digest_files({k:base64.b64decode(v) for k,v in fixture['outputFiles'].items()})==row['expectedFilesSha256']
source="""import json

with open('records.json') as source:
    records = json.load(source)
with open('manifest.jsonl', 'w', newline='') as target:
    for record in records:
        target.write(json.dumps(record, ensure_ascii=False, sort_keys=True, separators=(',', ':')))
        target.write('\\n')
print(len(records))
"""
reference=target/'reference';reference.mkdir()
for name,data in fixture['inputFiles'].items():
    assert name=='records.json';(reference/name).write_bytes(base64.b64decode(data))
(reference/'workload.py').write_text(source,encoding='utf-8',newline='\n')
answer=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','workload.py'],cwd=reference,capture_output=True,check=True)
stdout=answer.stdout.decode('utf-8').replace('\r\n','\n')
assert stdout==row['expectedOutput']
output=(reference/'manifest.jsonl').read_bytes();fixture['outputFiles']={'manifest.jsonl':base64.b64encode(output).decode('ascii')}
row['source']=source;row['sourceUtf8Bytes']=len(source.encode('utf-8'));row['sourceSha256']=hashlib.sha256(source.encode('utf-8')).hexdigest()
row['fixtureJson']=json.dumps(fixture,separators=(',',':'),ensure_ascii=True);row['fixtureSha256']=hashlib.sha256(row['fixtureJson'].encode('utf-8')).hexdigest()
row['expectedFilesSha256']=digest_files({'manifest.jsonl':output});catalog['performanceQualified']=False
(target/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False)+'\n',encoding='utf-8')
(target/'golden.json').write_text(json.dumps(dict(python=subprocess.check_output(['C:/Python313/python.exe','--version'],text=True).strip(),
    description='Useful complete JSONL manifest script over existing1024record fixture. Canonical report ID retained only for existing diagnostic driver; source/fixture/outputSHA distinguish it from published Markdown report.',
    records=row['size'],inputBytes=(reference/'records.json').stat().st_size,outputBytes=len(output),sourceSHA256=row['sourceSha256'],fixtureSHA256=row['fixtureSha256'],expectedFilesSHA256=row['expectedFilesSha256'],stdout=stdout,
    goldenBoundary='Independent isolated CPython execution; not Python timing.'),indent=2)+'\n',encoding='utf-8')
identity=json.loads((home/'identity.json').read_text(encoding='utf-8'))
for name,sha in identity['productionSources'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==sha,name
text=(home/'measure.py').read_text(encoding='utf-8')
start=text.index("shutil.copytree(home / 'images/before'");end=text.index('assert all(',start);text=text[:start]+text[end:]
text=text.replace("home / 'images'", "home.parent / 'images'").replace("home / 'images/", "home.parent / 'images/").replace("home/'images/", "home.parent/'images/")
text=text.replace("home.parent/'bulk-whitespace-r157", "home.parent.parent/'bulk-whitespace-r157")
text=text.replace("purpose='Consume terminal JSON buffers", "purpose='Independent JSONL manifest source/fixture/output goldens; canonical report ID reused only for existing five-case diagnostic. Consume terminal JSON buffers")
(target/'measure.py').write_text(text,encoding='utf-8',newline='\n')
print('Independent JSONL goldens:',row['size'],'records,',(reference/'records.json').stat().st_size,'input bytes,',len(output),'output bytes; four controls unchanged.',flush=True)
subprocess.run([sys.executable,'-X','utf8',str(target/'measure.py')],cwd=root,check=True)
