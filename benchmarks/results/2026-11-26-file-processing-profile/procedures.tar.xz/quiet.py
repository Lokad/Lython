from datetime import datetime, timedelta, timezone
from pathlib import Path
import hashlib,json,os,subprocess,sys

lab=Path(__file__).resolve().parent
quiet=lab/'comparison/quiet'
remote='/home/lokad/lython-bench-checks'
unit='lython-b1745-file-processing-profile-20261126'
vm=os.environ['LYTHON_BENCH_HOST']
common=['-i',os.environ['LYTHON_BENCH_IDENTITY'],'-o','BatchMode=yes','-o','ConnectTimeout=12']
configuration=json.loads((quiet/'upload.json').read_text(encoding='utf-8'))
configuration.update(base=remote,unit=unit)
prefix='cfg='+repr(configuration)+'''
from pathlib import Path
import fcntl,hashlib,tarfile,json,os,shutil,subprocess
base=Path(cfg['base'])
root=base/cfg['root']
unit=cfg['unit']
assert root.resolve()==root and root.parent==base and base.resolve()==base
archive=base/(cfg['root']+'.tar.gz')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
'''
invoke=lambda code:subprocess.check_output(['ssh',*common,vm,'python3 -'],input=prefix+code,encoding='utf-8',timeout=48)
scp=['scp',*common]
if sys.argv[1]=='launch':
    payload=quiet/'stage.tar.gz'
    assert hashlib.sha256(payload.read_bytes()).hexdigest()==configuration['payloadSHA256']
    before=json.loads(invoke('''
assert not root.exists() and not archive.exists()
bytes=shutil.disk_usage(base).free
assert bytes>cfg['payloadBytes']+3*1024*1024,bytes
print(json.dumps(dict(freeBeforeUploadBytes=bytes)))
'''))
    subprocess.run(scp+[payload,vm+':'+remote+'/'+configuration['root']+'.tar.gz'],check=True,timeout=90)
    staged=invoke('''
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and archive.resolve()==archive and sha(archive)==cfg['payloadSHA256']
 with tarfile.open(archive) as package:
  frames=package.getmembers()
  assert len(frames)==5 and len(set(f.name for f in frames))==5 and all(f.isfile() for f in frames)
  expanded=sum(f.size for f in frames)
  assert shutil.disk_usage(base).free>=expanded+4*1024*1024
  root.mkdir()
  package.extractall(root,filter='data')
 image=json.loads((root/'identity.json').read_text())
 donor=base/'native-cursor-stack-b1743-20261126'
 frozen=donor/'candidate'
 assert frozen.resolve()==frozen
 receipt=json.loads((donor/'archive-receipt.json').read_text())
 assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['archiveSHA256']==cfg['expectedDonorArchiveSHA256']
 assert sha(donor/'observations.tar.xz')==receipt['archiveSHA256']
 assert {p.name:sha(p) for p in frozen.iterdir()}==image['imageFiles']['candidate'] and len(image['imageFiles']['candidate'])==32
 assert sha(root/'catalog.json')==image['profileCatalogSHA256']
 archive.unlink()
 print(json.dumps(dict(freeBeforeLaunchBytes=shutil.disk_usage(base).free,expandedBytes=expanded)),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit='+unit,'--property=User=lokad','--property=WorkingDirectory='+str(root),
 '--property=RuntimeMaxSec=155','--property=TimeoutStopSec=20','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
''')
    (quiet/'launch.log').write_text(json.dumps(before)+'\n'+staged,encoding='utf-8')
    (quiet/'observe-not-before').write_text((datetime.now(timezone.utc)+timedelta(seconds=110)).isoformat(),encoding='utf-8')
    print(staged)
else:
    assert sys.argv[1]=='retrieve' and datetime.now(timezone.utc)>=datetime.fromisoformat((quiet/'observe-not-before').read_text(encoding='utf-8'))
    status=invoke('''
state=subprocess.run(['systemctl','show',unit+'.service','--property=ActiveState,SubState,MainPID,Result,ExecMainStatus'],capture_output=True,text=True).stdout
if 'ActiveState=active' in state:
 print(json.dumps(dict(live=True,service=state)))
else:
 with (base/'comparison-vm.lock').open('a') as lease:
  fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
  receipt=root/'archive-receipt.json'
  code=root/'exit-code.txt'
  print(json.dumps(dict(live=False,service=state,exitCode=code.read_text().strip() if code.exists() else None,
   receipt=json.loads(receipt.read_text()) if receipt.exists() else None, fixtures=(root/'guest-fixtures').exists(),
   journal=subprocess.run(['journalctl','-u',unit+'.service','-n','38','--no-pager'],capture_output=True,text=True).stdout)))
''')
    result=json.loads(status)
    (quiet/f'status-{datetime.now(timezone.utc):%H%M%S}.json').write_text(status,encoding='utf-8')
    if not result['live']:
        (quiet/'terminal-status.json').write_text(status,encoding='utf-8')
        if result['receipt']:
            archive=quiet/'observations.tar.xz'
            subprocess.run(scp+[vm+':'+remote+'/'+configuration['root']+'/'+archive.name,archive],check=True,timeout=45)
            assert hashlib.sha256(archive.read_bytes()).hexdigest()==result['receipt']['archiveSHA256']
    print(status)
