using System.Text.Json;
using Lokad.Lython.Frontend;
using Lokad.Lython.Tests;

using var catalog = JsonDocument.Parse(File.ReadAllText(args[0]));
var source = catalog.RootElement.GetProperty("cases").EnumerateArray()
    .Single(row => row.GetProperty("id").GetString() == "scripts.file-search.large").GetProperty("source").GetString()!;
var frontend = LythonFrontend.Compile(source);
var code = ExecutableScript.Compile(frontend.Script!).EntryPoint;
var function = code.FunctionBindings().Single(binding => binding.CodeObject.Name == "wanted").CodeObject;
Console.WriteLine($"{function.Name}. Direct return: {function.HasDirectOperandReturn}; locals {function.FirstTemporarySlot}; value slots {function.ValueStorageCapacity}.");
foreach (ref readonly var instruction in function.Instructions.AsSpan())
{
    Console.WriteLine($"{instruction.OpCode}: inputs {instruction.InputStart}, {instruction.SecondInput}; result {instruction.ResultSlot}; extent {instruction.LiveExtent}");
    if (instruction.OpCode == ExecutableOpCode.LoadCallMember) Console.WriteLine($"  member={function.Names[instruction.NameIndex]}");
    if (instruction.OpCode == ExecutableOpCode.LoadConst) Console.WriteLine($"  constant={function.Constants[instruction.ConstantIndex]}");
    if (instruction.OpCode == ExecutableOpCode.Call)
    {
        var site = function.CallSites[instruction.CallSiteIndex];
        Console.WriteLine($"  count={site.ArgumentCount}; offset={site.ArgumentOffset}; receiver={site.HasReceiver}; positional={site.IsPositionalOnly}");
    }
}
