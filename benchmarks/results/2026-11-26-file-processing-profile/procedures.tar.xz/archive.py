from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
lab=Path('.git/agent-notes/review-20261031/file-processing-profile-20261126')
quiet=lab/'comparison/quiet'
read=lambda file:json.loads(file.read_text(encoding='utf-8-sig'))
sha=lambda file:hashlib.sha256(file.read_bytes()).hexdigest()
identity=read(quiet/'identity.json')
assert subprocess.check_output(['git','diff','--name-only',identity['sourceRevision'],'HEAD','--','src','tests','benchmarks/Lokad.Lython.Benchmarks','benchmarks/cpython-worker.py'])==b''
assert sha(quiet/'catalog.json')==identity['profileCatalogSHA256']
verification=read(quiet/'candidate-verification.json')
assert verification['caseCount']==2 and verification['state']=='Completed' and verification['catalogSha256']==identity['profileCatalogSHA256']
assert verification['launched']['library']['sha256']==identity['coreSHA256']['candidate']
status=read(quiet/'terminal-status.json'); receipt=status['receipt']
assert not status['live'] and not status['fixtures'] and status['exitCode']=='0'
assert all(receipt[k]for k in ('complete','quietBeforeAndAfter','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
assert receipt['archiveSHA256']==sha(quiet/'observations.tar.xz')
with tarfile.open(quiet/'observations.tar.xz') as archive:
    assert json.load(archive.extractfile('identity.json'))==identity
    assert hashlib.sha256(archive.extractfile('catalog.json').read()).hexdigest()==identity['profileCatalogSHA256']
    for label,case,role in identity['profiles']:
        rec=json.load(archive.extractfile(f'profiles/{label}/record.json'))
        assert rec['workload']==case and rec['role']==role and rec['closed']['status']=='Closed'
        assert rec['verificationBefore']['status']==rec['verificationAfter']['status']=='Equivalent'
        assert next(lib for lib in rec['identity']['libraries'] if Path(lib['path']).name=='Lokad.Lython.dll')['sha256'].lower()==identity['coreSHA256'][role]
assert 'Direct return: False; locals 1; value slots 5.' in (lab/'tape-final.log').read_text(encoding='utf-8-sig')
out=Path('benchmarks/results/2026-11-26-file-processing-profile');out.mkdir(exist_ok=True)
for name in ('identity.json','terminal-status.json','attribution.json','observations.tar.xz'):shutil.copyfile(quiet/name,out/name)
with tarfile.open(out/'procedures.tar.xz','w:xz')as collection:
    for name in ('prepare.py','quiet.py','archive.py','prepare.log','stage.log','retrieve.log','analyze.log','tape.log','tape-final.log','tape/Program.cs','tape/Inspect.csproj'):
        collection.add(lab/name,arcname=name,recursive=False)
    for name in ('candidate-verification.json','catalog.json','collect.py','ops-profile.py','analyze.py','run.sh','launch.log','upload.json'):
        collection.add(quiet/name,arcname='comparison/quiet/'+name,recursive=False)
print('Verified the current frozen image, exact catalog, 3 joined captures and 2 goldens.')
