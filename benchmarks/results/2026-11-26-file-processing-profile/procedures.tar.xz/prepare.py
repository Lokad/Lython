from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
parent=lab.parent
up=parent/'file-processing-cpython-20261126'
origin=parent/'native-cursor-stack-admission-20261125'
template=parent/'shipment-comprehension-cpu-20261125'
quiet=lab/'comparison/quiet';quiet.mkdir(parents=True,exist_ok=True)
read=lambda f:json.loads(f.read_text(encoding='utf-8-sig'))
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
def write(p,s):p.write_text(s,encoding='utf-8',newline='\n')
def save(p,data):write(p,json.dumps(data,ensure_ascii=False,indent=2)+'\n')
source=read(up/'comparison/quiet/summary.json')['source']
assert source.startswith('a490e9d5f')
assert subprocess.check_output(['git','diff','--name-only',source,'HEAD','--','src','tests','benchmarks/Lokad.Lython.Benchmarks','benchmarks/cpython-worker.py'],cwd=repo)==b''
snapshot=read(origin/'comparison/quiet/identity.json')['imageFiles']['candidate']
image=up/'candidate';assert len(snapshot)==32 and {p.name:sha(p)for p in image.iterdir()}==snapshot
receipt=read(origin/'comparison/quiet/terminal-status.json')['receipt']
assert receipt['complete'] and sha(origin/'comparison/quiet/observations.tar.xz')==receipt['archiveSHA256']
catalog=read(up/'file-search.json')
report='diagnostic.text-summary.nonlocal-computed-width.large'
catalog['cases'].extend(c for c in read(origin/'comparison/quiet/representative.json')['cases'] if c['id']==report)
assert len(catalog['cases'])==2
save(quiet/'catalog.json',catalog)
identity=dict(sourceRevision=source,measurementReference=source,imageFiles={'candidate':snapshot},
    coreSHA256={'candidate':snapshot['Lokad.Lython.dll']},profileCatalogSHA256=sha(quiet/'catalog.json'),
    profiles=[['file-search-warm','scripts.file-search.large','candidate'],['file-search-through','scripts.file-search.large','candidate'],['unicode-report',report,'candidate']],
    donorArchiveSHA256=receipt['archiveSHA256'],purpose='Ordinary early-exit search and Unicode report through the verified Lython image.')
save(quiet/'identity.json',identity)
for name in ('collect.py','ops-profile.py','analyze.py','run.sh'):
 s=(template/name).read_text(encoding='utf-8-sig')
 s=s.replace('arithmetic-call-cpython-b1731c-20261125','native-cursor-stack-b1743-20261126').replace('b1732-fixtures','b1745-fixtures')
 if name.endswith('.py'):compile(s,name,'exec')
 write(quiet/name,s)
assert b'\r' not in (quiet/'run.sh').read_bytes()
s=(up/'quiet.py').read_text(encoding='utf-8-sig').replace('lython-b1744-file-processing-cpython-20261126','lython-b1745-file-processing-profile-20261126')
s=s.replace('len(frames)==6 and len(set(f.name for f in frames))==6','len(frames)==5 and len(set(f.name for f in frames))==5')
s=s.replace(" assert Path(image['frozenImage'])==frozen and frozen.resolve()==frozen", " assert frozen.resolve()==frozen")
a=" for name,metadata in image['catalogs'].items(): assert sha(root/name)==metadata['sha256']\n assert sha(root/'cpython-worker.py')==image['cpythonWorkerSHA256']"
assert a in s
s=s.replace(a," assert sha(root/'catalog.json')==image['profileCatalogSHA256']")
s=s.replace('RuntimeMaxSec=290','RuntimeMaxSec=155').replace('seconds=225','seconds=110')
compile(s,'quiet.py','exec');write(lab/'quiet.py',s)
worker=repo/'benchmarks/cpython-worker.py'
sdk=Path.home()/'.dotnet11'; dotnet=sdk/'dotnet.exe'; env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
verified=quiet/'candidate-verification.json'
subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'catalog.json',
 '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',worker,'--out',verified],cwd=repo,env=env,check=True,timeout=80)
v=read(verified)
assert v['state']=='Completed' and v['caseCount']==2 and v['catalogSha256']==identity['profileCatalogSHA256']
assert v['launched']['library']['sha256']==snapshot['Lokad.Lython.dll']
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=6) as archive:
 for name in ('collect.py','ops-profile.py','run.sh','catalog.json','identity.json'):
  archive.add(quiet/name,arcname=name,recursive=False)
save(quiet/'upload.json',dict(root='file-processing-profile-b1745-20261126',payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size,
 expectedDonorArchiveSHA256=receipt['archiveSHA256']))
