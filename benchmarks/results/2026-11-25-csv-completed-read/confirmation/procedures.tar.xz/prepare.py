from pathlib import Path
import hashlib,json,shutil,tarfile
notes=Path(".git/agent-notes/review-20261031")
base=notes/"csv-read-completed-prefix-20261125"
lab=notes/"csv-read-completed-prefix-confirm-20261125"
q0=base/"comparison/quiet"
q=lab/"comparison/quiet"
q.mkdir(exist_ok=True,parents=True)
read=lambda p:json.loads(p.read_text(encoding="utf-8"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,s): p.write_text(s,encoding="utf-8",newline="\n")
def save(p,data): write(p,json.dumps(data,indent=2)+"\n")
jobs=[
    ["diagnostic.text-summary.nonlocal-computed-width.large","warm-async"],
    ["diagnostic.shipment-file-fed-map","warm-async"],
    ["scripts.csv-invoice.method-policy.quoted-control","warm"],
]
save(q/"jobs.json",{"warm":jobs})
collect=(q0/"collect.py").read_text(encoding="utf-8").replace("b1704-fixtures","b1704-confirm-fixtures").replace(
    "len(jobs) == 6","len(jobs) == 3").replace("targetBatchSeconds=.59","targetBatchSeconds=.83")
compile(collect,"collect.py","exec")
write(q/"collect.py",collect)
shutil.copyfile(q0/"run.sh",q/"run.sh")
assert b"\r" not in (q/"run.sh").read_bytes()
launcher=(base/"quiet.py").read_text(encoding="utf-8").replace("b1704","b1704-confirm").replace(
    "'candidate-core.dll'}","}")
launcher=launcher.replace("'collect.py',}","'collect.py'}")
a=launcher.index("   if name=='Lokad.Lython.dll'")
b=launcher.index("   assert digest(image/name)",a)
launcher=launcher[:a]+"   os.link(reference/role/name,image/name)\n"+launcher[b:]
terminal=read(q0/"terminal-status.json")
anchor=terminal["receipt"]["archiveSHA256"]
assert anchor==sha(q0/"observations.tar.xz")
start=launcher.index("assert donor['archiveSHA256']=='")
end=launcher.index("\n",start)
launcher=launcher[:start]+"assert donor['archiveSHA256']=="+repr(anchor)+launcher[end:]
launcher=launcher.replace("seconds=274","seconds=175").replace("RuntimeMaxSec=350","RuntimeMaxSec=230")
compile(launcher,"quiet.py","exec")
write(lab/"quiet.py",launcher)
save(lab/"verified-raw-replicas.json",[])
summary=(base/"archive.py").read_text(encoding="utf-8").replace("2026-11-25-csv-completed-read","2026-11-25-csv-completed-read/confirmation").replace(
    '==receipt["warmJobs"]==6','==receipt["warmJobs"]==3').replace("timedBatches=168,lanes=6","timedBatches=84,lanes=3")
compile(summary,"archive.py","exec")
write(lab/"archive.py",summary)
identity=read(q0/"identity.json")
for role,files in identity["imageFiles"].items():
    assert {p.name:sha(p) for p in (base/role).iterdir()}==files
    assert read(base/"comparison"/(role+"-verify.json"))["caseCount"]==5
shutil.copyfile(q0/"representative.json",q/"representative.json")
assert sha(q/"representative.json")==identity["catalogs"]["representative.json"]["sha256"]
identity["catalogs"]["jobs.json"]={"sha256":sha(q/"jobs.json")}
save(q/"identity.json",identity)
tar=q/"payload.tar.gz"
with tarfile.open(tar,"w:gz",compresslevel=3) as payload:
    for label in ("identity.json","jobs.json","representative.json","run.sh","collect.py"):
        payload.add(q/label,arcname=label)
save(q/"upload.json",{"root":"csv-read-completed-prefix-b1704-confirm-20261125","reference":"csv-read-completed-prefix-b1704-20261125",
    "payloadSHA256":sha(tar),"payloadBytes":tar.stat().st_size})
