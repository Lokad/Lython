set -eu
export DOTNET_ROOT="$HOME/.dotnet"
lab="$PWD/.git/agent-notes/review-20261031/csv-read-completed-prefix-20261125"
tree="$PWD/.git/agent-worktrees/csv-read-completed-prefix-20261125"
"$DOTNET_ROOT/dotnet" test "$tree/tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj" -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter FullyQualifiedName~TextReadBorrowLifetime > "$lab/ubuntu-borrow.log" 2>&1 || { tail -40 "$lab/ubuntu-borrow.log"; exit 1; }
tail -3 "$lab/ubuntu-borrow.log"
