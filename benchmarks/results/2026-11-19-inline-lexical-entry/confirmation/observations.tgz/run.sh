set -eu
root=/home/lokad/lython-bench-checks/inline-lexical-entry-b1117-control-20261119
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
