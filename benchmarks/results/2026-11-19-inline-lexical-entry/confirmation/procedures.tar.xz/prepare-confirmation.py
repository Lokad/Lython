from pathlib import Path
import ast
import hashlib
import json
import re
import tarfile

lab = Path(__file__).resolve().parent
template = lab.parent / 'framed-unpacked-return-r680'
out = lab / 'confirmation'
out.mkdir(exist_ok=False)


def read(path):
    return path.read_text(encoding='utf-8-sig')


def write(path, source):
    if path.suffix == '.py':
        ast.parse(source)
    path.write_text(source, encoding='utf-8', newline='\n')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


prior = json.loads(read(lab / 'quiet/config.json'))
receipt = json.loads(read(lab / 'quiet/archive-receipt.json'))
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
assert sha(lab / 'quiet/observations.tgz') == receipt['archiveSHA256']
identity = prior['identity']
for role, files in identity['imageFiles'].items():
    assert len(files) == 32
    assert {name: sha(lab / 'frozen' / role / name) for name in files} == files
    verified = json.loads(read(lab / f'{role}-verify.json'))
    assert verified['state'] == 'Completed' and verified['catalogSha256'] == prior['catalogSHA256']

old = json.loads(read(template / 'confirmation/config.json'))
root = prior['root'].replace('b1117-', 'b1117-control-')
unit = prior['unit'].replace('b1117-', 'b1117-control-')
for name in ('collect.py', 'archive-owned.py', 'run.sh', 'retrieve.py'):
    source = read(template / 'confirmation' / name).replace(old['root'], root)
    source = source.replace('Framed unpacked return source pair', 'Common lexical call entry control')
    if name == 'collect.py':
        source = re.sub(r'^jobs = .+$', "jobs = [('scripts.annotated-rule-closures', 'warm')] * 2", source, flags=re.M)
    source = source.replace('==3', '==2').replace('jobs=3,', 'jobs=2,')
    write(out / name, source)
write(out / 'identity.json', json.dumps(identity, ensure_ascii=False, indent=2) + '\n')
names = ['identity.json', 'collect.py', 'archive-owned.py', 'run.sh']
with tarfile.open(out / 'payload.tgz', 'w:gz') as bundle:
    for name in names:
        bundle.add(out / name, arcname=name)
assert all((out / name).is_file() for name in names)
expanded = sum((out / name).stat().st_size for name in names)
assert receipt['freeBytesAfterArchive'] > 182452224 + expanded + 655360
config = dict(root=root, unit=unit, source=prior['root'], sourceFiles=identity['imageFiles'],
              sourceCatalogSHA256=prior['catalogSHA256'], catalogSHA256=prior['catalogSHA256'],
              identity=identity, retireGroups=[], donorArchiveSHA256=receipt['archiveSHA256'],
              payloadBytes=(out / 'payload.tgz').stat().st_size, payloadSHA256=sha(out / 'payload.tgz'),
              unpackedBytes=expanded)
write(out / 'config.json', json.dumps(config, ensure_ascii=False, indent=2) + '\n')
launcher = read(template / 'confirmation/remote-launch.py')
a, b = launcher.index('\nc=') + 1, launcher.index('\nb=Path(')
launcher = launcher[:a] + 'c=' + repr(config) + launcher[b:]
write(out / 'remote-launch.py', launcher.replace('lython-b1113-control-fixtures', 'lython-b1117-control-fixtures'))
write(lab / 'launch-confirmation.py', read(template / 'launch-confirmation.py').replace('227', '158'))
write(lab / 'summarize-confirmation.py', read(template / 'summarize-confirmation.py').replace('==3', '==2'))
print('Verified two warm control blocks with the original frozen images and unchanged catalog.')
