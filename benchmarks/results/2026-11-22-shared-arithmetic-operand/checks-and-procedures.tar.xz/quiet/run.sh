set -eu
root=/home/lokad/lython-bench-checks/shared-arithmetic-operand-b1358-20261122
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
