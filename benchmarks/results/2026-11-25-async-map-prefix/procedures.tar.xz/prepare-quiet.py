from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
base = lab.with_name("compiled-entry-20261125")
quiet = lab / "comparison/quiet"
baseline = base / "comparison/focused-compile"
output = quiet / "payload.tar.gz"
read = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
save = lambda path, data: path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8", newline="\n")
write = lambda path, text: path.write_text(text, encoding="utf-8", newline="\n")
identity = read(quiet / "identity.json")
donor = read(baseline / "identity.json")
receipt = read(baseline / "terminal-status.json")["receipt"]
assert receipt["complete"] and receipt["quietBeforeAndAfter"]
assert digest(baseline / "observations.tar.xz") == receipt["archiveSHA256"]
assert identity["imageFiles"]["reference"] == donor["imageFiles"]["candidate"]
for role, files in identity["imageFiles"].items():
    assert {p.name: digest(p) for p in (lab / role).iterdir()} == files
    assert read(lab / "comparison" / (role + "-verify.json"))["state"] == "Completed"
jobs=[
    ["diagnostic.shipment-routing-callbacks","warm-async"],
    ["diagnostic.shipment-bound-starmap","warm-async"],
    ["diagnostic.shipment-file-fed-map","warm-async"],
    ["diagnostic.shipment-routing-callbacks","warm"],
    ["diagnostic.bound-map-defaulted-readings","warm-async"],
    ["scripts.rule-default-closures","compile-run"],
    ["scripts.csv-invoice.method-policy.quoted-control","warm"],
]
save(quiet / "jobs.json", dict(warm=jobs))
identity["catalogs"]["jobs.json"] = dict(sha256=digest(quiet / "jobs.json"))
save(quiet / "identity.json", identity)
shutil.copyfile(baseline / "run.sh", quiet / "run.sh")
assert b"\r" not in (quiet / "run.sh").read_bytes()
collect=(baseline / "collect.py").read_text(encoding="utf-8").replace("b1689-fixtures","b1692-fixtures")
collect=collect.replace("len(jobs) == 8","len(jobs) == 7")
assert "len(jobs) == 7" in collect
compile(collect,"collect.py","exec")
write(quiet/"collect.py",collect)
with tarfile.open(output, "w:gz", compresslevel=3) as archive:
    for name in ("identity.json", "jobs.json", "representative.json", "run.sh", "collect.py"):
        archive.add(quiet / name, arcname=name)
    archive.add(lab / "candidate/Lokad.Lython.dll", arcname="candidate-core.dll")
save(quiet / "upload.json", dict(root="async-map-prefix-b1692-20261125", reference="compiled-entry-b1689-20261125",
                                 payloadSHA256=digest(output), payloadBytes=output.stat().st_size))
save(lab / "verified-raw-replicas.json", [])
launcher=(base/"quiet.py").read_text(encoding="utf-8")
launcher=launcher.replace('quiet=lab/"comparison/focused-compile"','quiet=lab/"comparison/quiet"')
launcher=launcher.replace("b1689","b1692").replace("lython-b1692-compiled-entry","lython-b1692-async-map-prefix")
launcher=launcher.replace("87a468c03d0573b593aa93b47b69e0e044724627794701f1ceec5f50623db5f7",receipt["archiveSHA256"])
launcher=launcher.replace("seconds=352","seconds=312").replace("RuntimeMaxSec=415","RuntimeMaxSec=375")
compile(launcher,"quiet.py","exec")
write(lab/"quiet.py",launcher)
report=(base/"archive.py").read_text(encoding="utf-8").replace('quiet=lab/"comparison/focused-compile"','quiet=lab/"comparison/quiet"')
report=report.replace("2026-11-25-compiled-entry","2026-11-25-async-map-prefix")
report=report.replace("==8","==7").replace("timedBatches=224,lanes=8","timedBatches=196,lanes=7")
compile(report,"archive.py","exec")
write(lab/"archive.py",report)
print("Prepared 7 lanes and verified both immutable worker images.")
