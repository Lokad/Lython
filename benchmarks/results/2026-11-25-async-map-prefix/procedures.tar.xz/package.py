from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
worktree=repo/".git/agent-worktrees/async-map-prefix-20261125"
out=repo/"benchmarks/results/2026-11-25-async-map-prefix"
quiet=lab/"comparison/quiet"
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
read=lambda path:json.loads(path.read_text(encoding="utf-8-sig"))
identity=read(quiet/"identity.json")
assert (lab/"candidate.patch").read_bytes()==subprocess.check_output(["git","-C",str(worktree),"diff","--binary","--","src"])
(lab/"test.patch").write_bytes(subprocess.check_output(["git","-C",str(worktree),"diff","--binary","--","tests"]))
assert digest(lab/"candidate.patch")==identity["sourcePatchSHA256"]
assert all({p.name:digest(p) for p in (lab/role).iterdir()}==files for role,files in identity["imageFiles"].items())
for folder,name in [(quiet,"identity.json"),(lab,"allocation-summary.json"),(lab,"tape-summary.json")]:
    shutil.copyfile(folder/name,out/name)
files=[
    "candidate.patch","test.patch","freeze.py","make-catalog.py","check-tape.py","allocations.py",
    "candidate-build.log","windows-net11.log","test-ubuntu.sh","ubuntu-net10-Lokad.Lython.PublicApi.Tests.log",
    "ubuntu-net10-Lokad.Lython.Tests.log","tape-candidate.json","tape-reference.json",
    "comparison/reference-verify.json","comparison/candidate-verify.json","candidate-allocation-final.json",
    "reference-allocation-final.json","prepare-quiet.py","quiet.py","archive.py","package.py",
    "comparison/quiet/upload.json","comparison/quiet/launch.log","comparison/quiet/storage-custody.json",
    "retire-one-core.py","retired-core/local-custody.json","retired-core/vm-custody.json",
]
with tarfile.open(out/"procedures.tar.xz","w:xz") as archive:
    for name in files:
        archive.add(lab/name,arcname=name,recursive=False)
with tarfile.open(out/"procedures.tar.xz") as archive:
    assert archive.getnames()==files
    assert all(hashlib.sha256(archive.extractfile(name).read()).hexdigest()==digest(lab/name) for name in files)
print("Packaged the exact source, verification and comparison procedures.")
