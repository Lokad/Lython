from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
donor = lab.with_name("boolean-precedence-20261125")
storage = lab / "retired-core"
storage.mkdir(exist_ok=True)
label = "boolean-precedence-b1690-20261125"
core = "Lokad.Lython.dll"
filename = label + ".dll"
backup = storage / "exact-core.tar.xz"
ssh_tools = Path("C:/Windows/System32/OpenSSH")
host = "lokad@20.166.121.73"
base = "/home/lokad/lython-bench-checks"
key = Path.home() / ".ssh/id_lython-bench.pem"
common = ["-i", str(key), "-o", "BatchMode=yes", "-o", "ConnectTimeout=15"]

def read(path):
    return json.loads(path.read_text(encoding="utf-8"))

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

quiet = donor / "comparison/quiet"
image = read(quiet / "identity.json")["imageFiles"]["candidate"]
terminal = read(quiet / "terminal-status.json")
receipt = terminal["receipt"]
assert not terminal["live"] and not terminal["fixtures"] and terminal["exitCode"] == "0"
assert receipt["complete"] and receipt["allWorkersJoined"] and receipt["archivedAndVerifiedUnderLease"]
assert digest(quiet / "observations.tar.xz") == receipt["archiveSHA256"]
assert {f.name: digest(f) for f in (donor / "candidate").iterdir()} == image
relative = f"{label}/candidate/{core}"
copied = storage / filename
subprocess.run([ssh_tools / "scp.exe", *common, f"{host}:{base}/{relative}", copied],
               check=True, timeout=45)
assert digest(copied) == image[core] and copied.read_bytes() == (donor / "candidate" / core).read_bytes()
with tarfile.open(backup, "w:xz") as archive:
    archive.add(copied, arcname=filename)
with tarfile.open(backup) as archive:
    assert hashlib.sha256(archive.extractfile(filename).read()).hexdigest() == image[core]

proof = dict(root=label, path=relative, image=image, bytes=copied.stat().st_size,
             archiveSHA256=receipt["archiveSHA256"], backupSHA256=digest(backup))
(storage / "local-custody.json").write_text(json.dumps(proof, indent=2) + "\n", encoding="utf-8", newline="\n")

script = "proof = " + repr(proof) + "\n" + """
from pathlib import Path
import fcntl, hashlib, json, shutil
base = Path('/home/lokad/lython-bench-checks').resolve()
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
with (base / 'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    root = base / proof['root']
    path = base / proof['path']
    assert path.resolve() == path and path.parent == root / 'candidate' and path.stat().st_nlink == 1
    assert not (root / 'guest-fixtures').exists()
    receipt = json.loads((root / 'archive-receipt.json').read_text())
    assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['archivedAndVerifiedUnderLease']
    assert digest(root / 'observations.tar.xz') == receipt['archiveSHA256'] == proof['archiveSHA256']
    assert {p.name: digest(p) for p in path.parent.iterdir()} == proof['image']
    assert path.stat().st_size == proof['bytes'] and digest(path) == proof['image'][path.name]
    before = shutil.disk_usage(base).free
    path.unlink()
    print(json.dumps(dict(freeBefore=before, freeAfter=shutil.disk_usage(base).free,
                          archivedCoreReclaimed=str(path.relative_to(base)))))
"""
result = subprocess.run([ssh_tools / "ssh.exe", *common, host, "python3 -"], input=script,
                        encoding="utf-8", check=True, capture_output=True, timeout=40)
(storage / "vm-custody.json").write_text(result.stdout, encoding="utf-8", newline="\n")
print(result.stdout)
