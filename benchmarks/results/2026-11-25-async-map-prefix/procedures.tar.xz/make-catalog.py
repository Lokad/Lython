from pathlib import Path
import base64
import hashlib
import json
import subprocess
import tempfile
lab=Path(__file__).resolve().parent
donor=lab.with_name("closed-iteration-call-20261125")
catalog=json.loads((donor/"comparison/quiet/representative.json").read_text(encoding="utf-8"))
keep={"diagnostic.shipment-routing-callbacks","diagnostic.shipment-bound-starmap","diagnostic.bound-map-defaulted-readings",
      "scripts.csv-invoice.method-policy.quoted-control","scripts.rule-default-closures"}
catalog["cases"]=[case for case in catalog["cases"] if case["id"] in keep]
assert len(catalog["cases"])==5
template=next(case for case in catalog["cases"] if case["id"]=="diagnostic.shipment-routing-callbacks")
source="""import csv
def quantity(row): return int(row['quantity'])
with open('shipments.csv', encoding='utf-8', newline='') as source:
    total = sum(map(quantity, csv.DictReader(source)))
print(total)
"""
with tempfile.TemporaryDirectory(prefix="lython-map-golden-") as folder:
    fixture=json.loads(template["fixtureJson"])
    assert list(fixture["inputFiles"])==["shipments.csv"]
    (Path(folder)/"shipments.csv").write_bytes(base64.b64decode(fixture["inputFiles"]["shipments.csv"]))
    output=subprocess.check_output(["C:/Python313/python.exe","-I","-X","utf8","-c",source],cwd=folder,encoding="utf-8")
sha=lambda text:hashlib.sha256(text.encode("utf-8")).hexdigest()
catalog["cases"].append(template | dict(id="diagnostic.shipment-file-fed-map",source=source,
    sourceUtf8Bytes=len(source.encode("utf-8")),sourceSha256=sha(source),expectedOutput=output,
    expectedOutputSha256=sha(output),expectedOutputUtf8Bytes=len(output.encode("utf-8"))))
(lab/"input-catalog.json").write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
