from pathlib import Path
import ast, hashlib, json, shutil, tarfile

h = Path(__file__).parent
d = h / 'diagnostic'
p = h / 'b552'
p.mkdir()
old = h.parent / 'cold-prefix-r200/b551'
source = json.loads((d / 'identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((h / 'tree' / name).read_bytes()).hexdigest() == digest
           for name, digest in source['source'].items())
assert all(json.loads((d / phase / 'measurements.json').read_text(encoding='utf-8'))[key]
           for phase in ['warm', 'warm-async']
           for key in ['allGoldensPassed', 'allBalancesZero', 'ownedFixturesRemoved', 'imageIsolationVerified', 'normalGcAndTiering'])
for a, b in [('catalog.json', 'representative.json'), ('identity.json', 'source-identity.json'),
             ('source.patch', 'source.patch'), ('script-goldens.json', 'script-goldens.json')]:
    shutil.copyfile(d / a, p / b)
shutil.copyfile(d / 'images/candidate/Lokad.Lython.dll', p / 'current-core.dll')
base = json.loads((h.parent / 'deferred-method-r198/b548/identity.json').read_text(encoding='utf-8'))
identity = dict(sourceRevision='R201 bounded bulk JSON string scan on717dfeb3; reference039 matches qualified66eb runtime. Candidateb6d0 isolated, not promoted/final-qualified.',
    coreSHA256={role: source['cores']['before' if role.startswith('reference') else 'candidate']
               for role in ['reference', 'reference-control', 'candidate', 'candidate-control']},
    auxiliaryFiles=base['auxiliaryFiles'], protocolSHA256=base['protocolSHA256'],
    catalogSHA256=hashlib.sha256((p / 'representative.json').read_bytes()).hexdigest(), performanceQualified=False)
(p / 'identity.json').write_text(json.dumps(identity, indent=2)+'\n', encoding='utf-8', newline='\n')
jobs = [[case['id'], 'warm'] for case in json.loads((p / 'representative.json').read_text(encoding='utf-8'))['cases']]
jobs.append(['scripts.report-render.large', 'warm-async'])
assert len(jobs) == 6
for name in ['collect.py', 'archive-owned.py', 'run.sh', 'retrieve.py', 'summarize.py']:
    s = (old / name).read_text(encoding='utf-8').replace('cold-prefix-b551-20261110', 'json-string-scan-b552-20261110').replace('lython-b551-cold-prefix-20261110', 'lython-b552-json-string-scan-20261110').replace('lython-b551-fixtures', 'lython-b552-fixtures').replace('B551', 'B552')
    if name == 'collect.py':
        a = s.index('jobs='); b = s.index('\nassert len(jobs)', a)
        s = s[:a] + 'jobs=' + repr(jobs) + s[b:]
        s = s.replace('R200 cold opcode bodies and hot instruction frame.', 'R201 bounded bulk JSON string classification, unchanged semantic/ownership paths.')
        a = s.index("purpose='"); b = s.index("',\n", a)
        s = s[:a] + "purpose='R201 complete report/JSON-lines/config workloads, CSV/text controls and async report; bounded source pair, all desktop adversity retained" + s[b:]
    if name.endswith('.py'): ast.parse(s)
    (p / name).write_text(s, encoding='utf-8', newline='\n')
(p / 'contract.md').write_text('''# R201 bounded source pair

Reference039/fullyqualified66eb versus frozenb6d0 JSON string scan. Same existing
five complete scripts: report, JSON-lines helpers, configuration edit, CSV, text;
five warm synchronous jobs plus async report. Four independent source/control
processes;5s warmup,7rotated400msrounds.240sowner/30stop/30margin. Normal GC/tiering.
Run timing includes mediated file I/O, capture, projection, per-run cleanup and
result disposal; excludes compilation, fixture reset, verification and protocol.
External CPU is wider/coarsely ticked. Preserve all identity/golden/quiet/ownership/
join/RAM/archive/SHA gates. Allocation separate; no promotion or CPU claim in advance.
''', encoding='utf-8', newline='\n')
with tarfile.open(p / 'payload.tgz', 'w:gz') as archive:
    for name in ['current-core.dll', 'representative.json', 'identity.json', 'source-identity.json',
                 'source.patch', 'script-goldens.json', 'contract.md', 'collect.py', 'archive-owned.py', 'run.sh']:
        archive.add(p / name, arcname=name)
payload = (p / 'payload.tgz').read_bytes()
with tarfile.open(p / 'payload.tgz') as archive:
    footprint = sum((m.size+4095)//4096*4096 for m in archive.getmembers() if m.isfile()) + 128*1024
s = (old / 'launch.py').read_text(encoding='utf-8').replace('cold-prefix-b551-20261110', 'json-string-scan-b552-20261110').replace('lython-b551-cold-prefix-20261110', 'lython-b552-json-string-scan-20261110').replace('cold-prefix-b551-launch.py', 'json-string-scan-b552-launch.py').replace('lython-b551-fixtures', 'lython-b552-fixtures')
a = s.index('config=dict('); b = s.index('\nscript=', a)
s = s[:a] + 'config=dict(payloadBytes=len(payload),payloadSHA256=hashlib.sha256(payload).hexdigest(),required=(240+12)*1024*1024+max(3*len(payload),' + str(footprint) + '),copies=[])' + s[b:]
assert "source=base/'deferred-method-b548-20261110/candidate'" in s
ast.parse(s)
(p / 'launch.py').write_text(s, encoding='utf-8', newline='\n')
print(json.dumps(dict(jobs=jobs, cores=identity['coreSHA256'], payloadBytes=len(payload),
                      uncompressedFootprintWithMetadata=footprint,
                      requiredFreeBytes=(240+12)*1024*1024+max(3*len(payload), footprint)), indent=2), flush=True)
