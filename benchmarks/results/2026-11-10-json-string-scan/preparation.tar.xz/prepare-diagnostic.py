from pathlib import Path
import base64, hashlib, json, shutil, subprocess, tempfile

h = Path(__file__).parent
t = h / 'tree'
d = h / 'diagnostic'
d.mkdir()
assert all('Passed!' in (h / name).read_text(encoding='utf-8') for name in
           ['public-batched-net11.0.log', 'internal-net11.0.log'])
baseline = h.parent / 'deferred-method-r198/diagnostic/images/candidate'
for role in ['before', 'candidate']:
    shutil.copytree(baseline, d / 'images' / role)
shutil.copyfile(t / 'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',
                d / 'images/candidate/Lokad.Lython.dll')
assert all(p.read_bytes() == (d / 'images/candidate' / p.relative_to(d / 'images/before')).read_bytes()
           for p in (d / 'images/before').rglob('*') if p.is_file() and p.name != 'Lokad.Lython.dll')
old = h.parent / 'iterative-json-r196/refined-diagnostic'
shutil.copyfile(old / 'five-catalog.json', d / 'catalog.json')
shutil.copyfile(old / 'hash-witness.json', d / 'hash-witness.json')
catalog = json.loads((d / 'catalog.json').read_text(encoding='utf-8'))
assert len(catalog['cases']) == 5
goldens = []
for case in catalog['cases']:
    fixture = json.loads(case['fixtureJson'])
    with tempfile.TemporaryDirectory(prefix='lython-r201-golden-') as directory:
        folder = Path(directory)
        for name, encoded in fixture['inputFiles'].items():
            target = folder / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(base64.b64decode(encoded, validate=True))
        p = subprocess.run(['C:/Python313/python.exe', '-I', '-S', '-X', 'utf8', '-c', case['source']],
                           cwd=folder, capture_output=True, text=True, encoding='utf-8', timeout=15)
        assert p.returncode == 0 and not p.stderr and p.stdout == case['expectedOutput'], (case['id'], p.stderr)
        assert all((folder / name).read_bytes() == base64.b64decode(encoded, validate=True)
                   for name, encoded in fixture['outputFiles'].items())
        goldens.append(dict(case=case['id'], sourceSHA256=case['sourceSha256'], allGoldensPassed=True))
(d / 'script-goldens.json').write_text(json.dumps(dict(reference='CPython3.13.2; semantic goldens only', cases=goldens), indent=2)+'\n', encoding='utf-8', newline='\n')
(d / 'source.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary', '--', 'src'], cwd=t))
identity = dict(baseRevision='717dfeb3; source reference039 matches fully qualified66eb runtime.',
    cores={role: hashlib.sha256((d / 'images' / role / 'Lokad.Lython.dll').read_bytes()).hexdigest()
           for role in ['before', 'candidate']},
    source={p.relative_to(t).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in (t / 'src/Lokad.Lython').rglob('*.cs') if 'obj' not in p.parts},
    catalogSHA256=hashlib.sha256((d / 'catalog.json').read_bytes()).hexdigest(),
    status='Isolated bounded bulk JSON string scan; no promotion/CPU gain/final qualification claim.',
    focused='Release NET11 JSON public/internal; original fixture refusal preserved and changed to bounded per-control executions without increasing allowance.',
    freeze='Forced nonincremental core build succeeded. Later changes tests-only; copied final built core and all auxiliary image bytes identical.')
(d / 'identity.json').write_text(json.dumps(identity, indent=2)+'\n', encoding='utf-8', newline='\n')
measure = (h.parent / 'cold-prefix-r200/measure.py').read_text(encoding='utf-8')
# Runtime scan only: compile controls already exist for unchanged frontend.
measure = measure.replace("[('warm','sync','executionMilliseconds'),('warm-async','async','executionMilliseconds'),('compile','sync','elapsedMilliseconds')]",
                          "[('warm','sync','executionMilliseconds'),('warm-async','async','executionMilliseconds')]")
(h / 'measure.py').write_text(measure, encoding='utf-8', newline='\n')
print(json.dumps(dict(cores=identity['cores'], cases=[c['id'] for c in catalog['cases']], allSemanticGoldensPassed=True), indent=2), flush=True)
