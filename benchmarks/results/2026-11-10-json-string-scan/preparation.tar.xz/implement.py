from pathlib import Path
import hashlib,json,shutil,subprocess
h=Path(__file__).parent;repo=Path('D:/code/Lython');tree=h/'tree';assert not tree.exists()
assessment=json.loads((h/'assessment.json').read_text(encoding='utf-8'));path='src/Lokad.Lython/Runtime/LythonRuntime.Json.Deserialize.cs'
assert (repo/path).read_bytes()==(h/'LythonRuntime.Json.Deserialize.cs').read_bytes()
shutil.copyfile(repo/'PLAN.md',h/'selected-PLAN.md');subprocess.run(['git','worktree','add','--detach',str(tree),'HEAD'],cwd=repo,check=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
file=tree/path;s=file.read_text(encoding='utf-8');needle='    private sealed partial class JsonModule : PyModule\n    {\n';assert s.count(needle)==1
s=s.replace(needle,needle+'''        // Fixed JSON delimiters and C0 controls; ordinary UTF-8 bytes share a
        // bounded bulk scan. Validation and unescaping keep their existing path.
        private static readonly SearchValues<byte> JsonStringSpecialBytes = SearchValues.Create(
            [(byte)'"', (byte)'\\\\', 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
                16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31]);

''')
needle='''                    nextCheck = end + Math.Min(1024, original.Length - end);
                }
                var current = original[end++];
''';assert s.count(needle)==1
s=s.replace(needle,'''                    nextCheck = end + Math.Min(1024, original.Length - end);
                }
                var next = original.Slice(end, nextCheck - end).IndexOfAny(JsonStringSpecialBytes);
                if (next < 0)
                {
                    end = nextCheck;
                    continue;
                }
                end += next;
                var current = original[end++];
''')
file.write_text(s,encoding='utf-8',newline='\n')
(h/'source-selection.json').write_text(json.dumps(dict(baseRevision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=tree,text=True).strip(),path=path,changedWork='Ordinary-byte classification is replaced by bulk span searching inside unchanged1024byte cancellation windows; original exceptional-byte handling retained.',metadata='One fixed immutable34byte search alphabet; no per-token buffer/cache/owner/policy.',status='Isolated prototype, no timing/promotion/qualification claim.'),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Isolated bounded JSON scan implemented:',tree,flush=True)
