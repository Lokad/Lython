# R201 bounded source pair

Reference039/fullyqualified66eb versus frozenb6d0 JSON string scan. Same existing
five complete scripts: report, JSON-lines helpers, configuration edit, CSV, text;
five warm synchronous jobs plus async report. Four independent source/control
processes;5s warmup,7rotated400msrounds.240sowner/30stop/30margin. Normal GC/tiering.
Run timing includes mediated file I/O, capture, projection, per-run cleanup and
result disposal; excludes compilation, fixture reset, verification and protocol.
External CPU is wider/coarsely ticked. Preserve all identity/golden/quiet/ownership/
join/RAM/archive/SHA gates. Allocation separate; no promotion or CPU claim in advance.
