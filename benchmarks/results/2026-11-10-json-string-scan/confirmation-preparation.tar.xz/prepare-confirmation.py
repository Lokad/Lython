from pathlib import Path
import ast, hashlib, json, shutil, subprocess, tarfile

h=Path(__file__).parent; old=h/'b552'; p=h/'b553'; p.mkdir(); repo=Path('D:/code/Lython')
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
catalog=json.loads((old/'representative.json').read_text(encoding='utf-8'))
ids=['scripts.text-summary-helpers.large','scripts.json-summary-helpers.large']
catalog['cases']=[next(c for c in catalog['cases'] if c['id']==name) for name in ids]
(p/'representative.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
identity['catalogSHA256']=hashlib.sha256((p/'representative.json').read_bytes()).hexdigest()
identity['sourceRevision']+=' B553 unchanged-image confirmation; text first, opposite initial role order.'
(p/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['source-identity.json','source.patch','script-goldens.json']:shutil.copyfile(old/name,p/name)
canonical=repo/'benchmarks/results/2026-11-10-cold-prefix/refined/observations.tgz'
subprocess.run(['git','ls-files','--error-unmatch',str(canonical.relative_to(repo))],cwd=repo,check=True,stdout=subprocess.DEVNULL)
digest=hashlib.sha256(canonical.read_bytes()).hexdigest();assert digest=='963da57966cdb7df77493c6ea0ff0cd43b490a29ff68b83d59a87b9f20ecf7aa'
copies=[dict(path='cold-prefix-b551-20261110/observations.tgz',bytes=canonical.stat().st_size,sha256=digest,canonical=str(canonical.relative_to(repo)))]
(p/'exact-copies.json').write_text(json.dumps(copies,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=(old/name).read_text(encoding='utf-8').replace('json-string-scan-b552-20261110','json-string-scan-b553-20261110').replace('lython-b552-json-string-scan-20261110','lython-b553-json-string-scan-20261110').replace('B552','B553')
 s=s.replace('len(jobs)==6','len(jobs)==2').replace("len(raw['jobs'])==6","len(raw['jobs'])==2").replace('jobs=6','jobs=2').replace("['jobs']==6","['jobs']==2").replace("elapsedSeconds']<240","elapsedSeconds']<120").replace('six-job','two-job')
 if name=='collect.py':
  a=s.index('jobs=');b=s.index('\nassert len(jobs)',a);s=s[:a]+'jobs='+repr([[name,'warm']for name in ids])+s[b:]
  s=s.replace("labels=['reference','candidate','reference-control','candidate-control']","labels=['candidate-control','reference-control','candidate','reference']").replace('time.monotonic()-started < 200','time.monotonic()-started < 80')
  a=s.index("purpose='");b=s.index("',\n",a);s=s[:a]+"purpose='R201 unchanged-image confirmation after JSON benefit and adverse non-JSON control; text first, reversed initial role order, same clocks/gates, original observations preserved"+s[b:]
 if name.endswith('.py'):ast.parse(s)
 (p/name).write_text(s,encoding='utf-8',newline='\n')
(p/'contract.md').write_text('''# R201 bounded confirmation

Unchanged039/b6d0 binaries/auxiliaries and exact existing text/JSON-lines fixtures.
Original B552 observed JSON benefit but adverse text control; retain it completely.
Text first and reverse initial worker role order; four independent processes,
5s warmup and7rotated400msrounds unchanged.120sowner/30stop/30margin. Same clocks,
normal GC/tiering, semantic/ownership/quiet/join/RAM/archive/SHA gates. This bounded
confirmation resolves uncertainty; it is not an unchanged replay of qualification.
No source refinement or predicted outcome; make an explicit debt decision afterward.
''',encoding='utf-8',newline='\n')
with tarfile.open(p/'payload.tgz','w:gz')as a:
 for name in ['representative.json','identity.json','source-identity.json','source.patch','script-goldens.json','contract.md','collect.py','archive-owned.py','run.sh']:a.add(p/name,arcname=name)
payload=(p/'payload.tgz').read_bytes()
with tarfile.open(p/'payload.tgz')as a:footprint=sum((m.size+4095)//4096*4096 for m in a.getmembers()if m.isfile())+128*1024
s=(old/'launch.py').read_text(encoding='utf-8').replace('json-string-scan-b552-20261110','json-string-scan-b553-20261110').replace('lython-b552-json-string-scan-20261110','lython-b553-json-string-scan-20261110').replace('json-string-scan-b552-launch.py','json-string-scan-b553-launch.py').replace('lython-b552-fixtures','lython-b553-fixtures')
a=s.index('config=dict(');b=s.index('\nscript=',a);s=s[:a]+f"config=dict(payloadBytes=len(payload),payloadSHA256=hashlib.sha256(payload).hexdigest(),required=(240+12)*1024*1024+max(3*len(payload),{footprint}),copies=json.loads((r/'exact-copies.json').read_text(encoding='utf-8')))"+s[b:]
needle=" shutil.copyfile(protocol,root/'cpython-worker.py');os.link(source/'Lokad.Lython.dll',root/'baseline-core.dll')"
assert s.count(needle)==1
s=s.replace(needle," prototype=base/'json-string-scan-b552-20261110/current-core.dll'\n assert hashlib.sha256(prototype.read_bytes()).hexdigest()=='"+identity['coreSHA256']['candidate']+"'\n os.link(prototype,root/'current-core.dll')\n"+needle)
s=s.replace('jobs=6,ownerSeconds=240','jobs=2,ownerSeconds=120').replace('RuntimeMaxSec=240','RuntimeMaxSec=120').replace('timedelta(seconds=300)','timedelta(seconds=180)').replace('ownerSeconds=240,stopSeconds=30','ownerSeconds=120,stopSeconds=30')
ast.parse(s);(p/'launch.py').write_text(s,encoding='utf-8',newline='\n')
print(json.dumps(dict(jobs=ids,unchangedCores=identity['coreSHA256'],payloadBytes=len(payload),footprint=footprint,retireOnlyExactCanonicalCopyIfNeeded=copies),indent=2),flush=True)
