from pathlib import Path
import hashlib,json,shutil,statistics,tarfile

lab=Path(__file__).resolve().parent
initial=lab/"comparison/quiet"
out=lab/"confirm"
quiet=out/"quiet"
quiet.mkdir(parents=True,exist_ok=False)
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,s):
    if p.suffix==".py":compile(s,str(p),"exec")
    p.write_text(s,encoding="utf-8",newline="\n")
def save(p,value):write(p,json.dumps(value,indent=2)+"\n")
old=read(initial/"config.json")
ident=read(initial/"identity.json")
receipt=read(initial/"archive-receipt.json")
assert receipt["complete"] and receipt["archivedAndVerifiedUnderLease"] and receipt["archiveSHA256"]==h(initial/"observations.tgz")
assert ident==old["identity"] and all(
    h(lab/"comparison"/("frozen-"+role)/name)==digest
    for role,manifest in ident["imageFiles"].items() for name,digest in manifest.items())
root=old["root"].replace("b1417","b1418")
unit=old["unit"].replace("b1417","b1418")
labels=[role+suffix for suffix in ("-a","-b","-c","-d") for role in ("candidate","reference")]
core="Lokad.Lython.dll"
ident["purpose"]="Confirm opposing warm factory outcomes with four independent processes per image."
ident["coreSHA256"]={label:ident["imageFiles"][label.split("-")[0]][core] for label in labels}
save(quiet/"identity.json",ident)
shutil.copyfile(initial/"representative.json",quiet/"representative.json")
ids=("scripts.annotated-rule-closures.nested-factories.postponed","scripts.annotated-rule-closures.nested-factories")
for leaf in ("collect.py","run.sh","archive-owned.py","retrieve.py"):
    s=(initial/leaf).read_text(encoding="utf-8").replace(old["root"],root).replace(old["unit"],unit)
    s=s.replace("len(jobs)==7","len(jobs)==2").replace("len(raw['jobs'])==7","len(raw['jobs'])==2")
    s=s.replace("jobs=7,","jobs=2,").replace("['jobs']==7","['jobs']==2")
    if leaf=="collect.py":
        a=s.index("\njob_catalog =")
        b=s.index("\nassert len(jobs)",a)
        s=s[:a]+"\njob_catalog = "+repr({id:"representative.json" for id in ids})+"\njobs = "+repr([(id,"warm") for id in ids])+s[b:]
        s=s.replace("{'reference','reference-control','candidate','candidate-control'}",repr(set(labels)))
        s=s.replace("['reference-control','candidate-control','reference','candidate']",repr(labels))
        s=s.replace("started < 410","started < 250")
    write(quiet/leaf,s)
assert b"\r" not in (quiet/"run.sh").read_bytes()
parts=("identity.json","representative.json","run.sh","collect.py","archive-owned.py")
payload=quiet/"payload.tgz"
with tarfile.open(payload,"w:gz") as t:
    for n in parts:t.add(quiet/n,arcname=n)
cfg={**old,"root":root,"unit":unit,"identity":ident,"source":old["root"],"sourceRole":"reference",
     "sourceFiles":ident["imageFiles"]["reference"],"sourceCatalogSHA256":h(initial/"representative.json"),
     "donorArchiveSHA256":receipt["archiveSHA256"],"retireGroups":[],
     "payloadBytes":payload.stat().st_size,"payloadSHA256":h(payload),
     "unpackedBytes":sum((quiet/n).stat().st_size for n in parts)}
save(quiet/"config.json",cfg)
s=(initial/"remote-launch.py").read_text(encoding="utf-8")
a,b=s.index("\nc=")+1,s.index("\nb=Path(")
s=s[:a]+"c="+repr(cfg)+s[b:]
s=s.replace("for n,h in c['sourceFiles'].items():assert sha(source/c['sourceRole']/n)==h,n",
    "for role,manifest in c['identity']['imageFiles'].items():\n  for n,h in manifest.items():assert sha(source/role/n)==h,n")
s=s.replace("os.link(source/c['sourceRole']/n,p)","os.link(source/role/n,p)")
s=s.replace("RuntimeMaxSec=475","RuntimeMaxSec=305").replace("b1417-fixtures","b1418-fixtures")
write(quiet/"remote-launch.py",s)
s=(lab/"comparison/launch.py").read_text(encoding="utf-8")
write(out/"launch.py",s.replace("seconds=422","seconds=247").replace("before 422 seconds","before 247 seconds"))
