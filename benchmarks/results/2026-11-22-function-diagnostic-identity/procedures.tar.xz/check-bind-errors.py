from pathlib import Path
import hashlib,json,os,shutil,subprocess
lab=Path(__file__).resolve().parent
compare=lab/"comparison"
ident=json.loads((compare/"identity.json").read_text(encoding="utf-8-sig"))
donor=lab/"tools/LythonProbe/bin/Release/net11.0"
sdk=Path.home()/".dotnet11"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
source="""from dataclasses import dataclass
def named(x, /, *, flag): return x
def generator(x): yield x
class Outer:
    def __method(self, x): return x
    def call(self): return self.__method()
@dataclass
class Generated:
    x: int
for call in (named, lambda x: x, generator, lambda x: (yield x), Outer().call, Generated):
    try:
        call()
    except TypeError as error:
        print(str(error))
"""
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(lab/"binding-errors.py").write_text(source,encoding="utf-8",newline="\n")
raw={}
for role,files in ident["imageFiles"].items():
    probe=lab/("probe-errors-"+role)
    probe.mkdir(exist_ok=True)
    for p in donor.iterdir():
        if p.is_file():shutil.copyfile(p,probe/p.name)
    frozen=compare/("frozen-"+role)
    for leaf in ("Lokad.Lython.dll","Lokad.Lython.Utf8Regex.dll","Lokad.Utf8Regex.dll","Lokad.Utf8Regex.PythonRe.dll"):
        assert sha(frozen/leaf)==files[leaf]
        shutil.copyfile(frozen/leaf,probe/leaf)
    for name,args in (("sync",[]),("async",["--async"])):
        result=subprocess.run([sdk/"dotnet.exe",probe/"LythonProbe.dll","-c",source,*args],
                env=env,capture_output=True,text=True,encoding="utf-8",check=True,timeout=24)
        assert not result.stderr
        raw[role,name]=result.stdout
for mode in ("sync","async"):
    assert raw["reference",mode]==raw["candidate",mode]
assert raw["candidate","async"].replace("mode: async\n","")==raw["candidate","sync"]
out=raw["candidate","sync"].split("stdout:\n",1)[1].split("peak execution memory:",1)[0].splitlines()
assert len(out)==6 and ["lambda" in s for s in out]==[False,True,False,True,False,False]
assert "Function '__method'" in out[4] and "Function 'Generated.__init__'" in out[5]
(lab/"binding-errors.json").write_text(json.dumps({"source":source,"identicalOutputs":out},indent=2)+"\n",
                                      encoding="utf-8",newline="\n")
print("\n".join(out))
