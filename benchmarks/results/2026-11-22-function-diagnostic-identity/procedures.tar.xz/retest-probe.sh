#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/native-call-selection-single-proof-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
export DOTNET_HOST_PATH="$DOTNET_ROOT/dotnet"
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/function-diagnostic-identity-20261122
dotnet build tools/LythonProbe/LythonProbe.csproj -c Release -f net10.0 --no-incremental --artifacts-path "$lab/probe-ubuntu" > "$lab/probe-build-ubuntu.log" 2>&1 || { tail -40 "$lab/probe-build-ubuntu.log"; exit 1; }
probe="$lab/tools/LythonProbe/bin/Release/net10.0"
mkdir -p "$probe"
cp "$lab"/probe-ubuntu/bin/LythonProbe/release_net10.0/* "$probe"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --no-build --filter 'FullyQualifiedName~DeepCallRecursionRaisesInIsolatedProcess|FullyQualifiedName~CaughtMethodFailurePreservesIdentityFinallyOrderAndSubsequentCalls' --artifacts-path "$lab/ubuntu" > "$lab/ubuntu-probe-rerun.log" 2>&1 || { tail -40 "$lab/ubuntu-probe-rerun.log"; exit 1; }
tail -6 "$lab/ubuntu-probe-rerun.log"
