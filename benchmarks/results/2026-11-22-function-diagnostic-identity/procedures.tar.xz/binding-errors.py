from dataclasses import dataclass
def named(x, /, *, flag): return x
def generator(x): yield x
class Outer:
    def __method(self, x): return x
    def call(self): return self.__method()
@dataclass
class Generated:
    x: int
for call in (named, lambda x: x, generator, lambda x: (yield x), Outer().call, Generated):
    try:
        call()
    except TypeError as error:
        print(str(error))
