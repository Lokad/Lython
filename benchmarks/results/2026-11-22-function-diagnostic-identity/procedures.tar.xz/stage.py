from pathlib import Path
import gzip,hashlib,io,json,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
base=lab.parent/"native-call-selection-single-proof-20261122/comparison"
out=lab/"comparison"
quiet=out/"quiet"
quiet.mkdir(exist_ok=True)
core="Lokad.Lython.dll"

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha(data):
    return hashlib.sha256(data).hexdigest()

def h(path):
    return sha(path.read_bytes())

def save(path,data):
    write(path,json.dumps(data,ensure_ascii=False,indent=2)+"\n")

def write(path,text):
    if path.suffix==".py":compile(text,str(path),"exec")
    path.write_text(text,encoding="utf-8",newline="\n")

def git(*args):
    return subprocess.check_output(["git",*args],cwd=repo)

def committed(directory,leaf):
    return git("show","origin/master:benchmarks/results/"+directory+"/"+leaf)

info=read(out/"identity.json")
candidate=git("-C",str(repo/".git/agent-worktrees/native-call-selection-single-proof-20261122"),"rev-parse","HEAD").decode().strip()
assert candidate.startswith("77467f919")
reference=info["reference"]
patch=git("diff","--binary",reference,candidate,"--","src","tests")
assert sha(patch)==info["sourcePatchSHA256"] and patch==(out/"source.patch").read_bytes()
for role,files in info["imageFiles"].items():
    assert len(files)==32 and all(h(out/("frozen-"+role)/leaf)==digest for leaf,digest in files.items())
    assert read(out/(role+"-verify.json"))["caseCount"]==6

old=read(base/"quiet/config.json")
root=old["root"].replace("native-call-selection-b1415","function-diagnostic-identity-b1417")
unit=old["unit"].replace("b1415-native-call-selection","b1417-function-diagnostic-identity")
identity=dict(sourceRevision=reference+" versus "+candidate, reference=reference,candidate=candidate,
              testedRevision=candidate,equivalentCoreSource="76b7934f7",imageFiles=info["imageFiles"],
              purpose="Replace per-function diagnostic name and kind transportation with code-owned identity",
              normalAdapterPin="0.4.0",sourcePatchSHA256=info["sourcePatchSHA256"],protocolSHA256=info["protocolSHA256"],
              coreSHA256={role+suffix:files[core] for role,files in info["imageFiles"].items() for suffix in ("","-control")},
              catalogs={"representative.json":{"sha256":info["catalogSHA256"]}})
shutil.copyfile(out/"representative.json",quiet/"representative.json")
assert h(quiet/"representative.json")==info["catalogSHA256"]
shutil.copyfile(base/"jobs.json",out/"jobs.json")
save(quiet/"identity.json",identity)
for role in info["imageFiles"]:
    (quiet/role).mkdir(exist_ok=True)
    shutil.copyfile(out/("frozen-"+role)/core,quiet/role/core)
    assert h(quiet/role/core)==info["imageFiles"][role][core]
for leaf in ("collect.py","run.sh","archive-owned.py","retrieve.py"):
    code=(base/"quiet"/leaf).read_text(encoding="utf-8").replace(old["root"],root).replace(old["unit"],unit)
    if leaf=="collect.py":code=code.replace("job_index % 2 == 0","job_index % 2 != 0")
    if leaf=="retrieve.py":code=code.replace("Branch state ownership observations","Function diagnostic identity observations")
    write(quiet/leaf,code)
assert b"\r" not in (quiet/"run.sh").read_bytes()
parts=("identity.json","representative.json","collect.py","run.sh","archive-owned.py","reference/"+core,"candidate/"+core)
payload=quiet/"payload.tgz"
with tarfile.open(payload,"w:gz") as t:
    for name in parts:t.add(quiet/name,arcname=name)
unpacked=sum((quiet/n).stat().st_size for n in parts)
retire=[]
directory="2026-11-22-native-call-selection-single-proof"
remote="native-call-selection-b1415-20261122"
source=json.loads(committed(directory,"source.json"))
receipt=json.loads(committed(directory,"archive-receipt.json"))
data=gzip.decompress(committed(directory,"candidate-core.dll.gz"))
assert (receipt["complete"] and receipt["archivedAndVerifiedUnderLease"]
        and sha(committed(directory,"observations.tgz"))==receipt["archiveSHA256"])
assert sha(data)==source["imageFiles"]["candidate"][core]==old["identity"]["imageFiles"]["candidate"][core]
retire.append(dict(paths=[remote+"/candidate/"+core],bytes=len(data),links=1,sha256=sha(data),
                   archives={remote+"/observations.tgz":receipt["archiveSHA256"]}))
directory="2026-11-21-expanded-builtin-span"
receipt=json.loads(committed(directory,"archive-receipt.json"))
observations=committed(directory,"observations.tgz")
assert receipt["complete"] and receipt["archivedAndVerifiedUnderLease"] and sha(observations)==receipt["archiveSHA256"]
with tarfile.open(fileobj=io.BytesIO(observations)) as bundle:
    frozen_identity=json.load(bundle.extractfile("identity.json"))["imageFiles"]["reference"]
frozen=lab.parent/"expanded-builtin-span/frozen/reference"
assert len(frozen_identity)==32 and all(h(frozen/leaf)==digest for leaf,digest in frozen_identity.items())
retire.append(dict(paths=["expanded-builtin-span-b1260-20261121/reference/"+core],
                   bytes=(frozen/core).stat().st_size,links=1,sha256=frozen_identity[core],archives={}))
assert old["source"] not in {entry["paths"][0] for entry in retire}
config={**old,"root":root,"unit":unit,"identity":identity,"retireGroups":retire,
        "payloadBytes":payload.stat().st_size,"payloadSHA256":h(payload),"unpackedBytes":unpacked}
save(quiet/"config.json",config)
launch=(base/"quiet/remote-launch.py").read_text(encoding="utf-8")
start,end=launch.index("\nc=")+1,launch.index("\nb=Path(")
write(quiet/"remote-launch.py",(launch[:start]+"c="+repr(config)+launch[end:]).replace("b1415-fixtures","b1417-fixtures"))
for leaf in ("launch.py","summarize.py"):
    code=(base/leaf).read_text(encoding="utf-8").replace("Native call selection","Function diagnostic identity")
    write(out/leaf,code)
print(candidate,root,unpacked,flush=True)
