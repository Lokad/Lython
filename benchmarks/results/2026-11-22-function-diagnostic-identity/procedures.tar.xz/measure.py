from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.parent/"native-call-selection-single-proof-20261122/comparison"
out=lab/"comparison"
out.mkdir(exist_ok=True)
catalog=prior/"quiet/representative.json"
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
save=lambda p, value:p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
protocol=repo/"benchmarks/cpython-worker.py"
identity=read(prior/"quiet/identity.json")
assert sha(catalog)==identity["catalogs"][catalog.name]["sha256"] and sha(protocol)==identity["protocolSHA256"]
base=prior/"frozen-candidate"
donor=identity["imageFiles"]["candidate"]
assert len(donor)==32 and {n:sha(base/n) for n in donor}==donor
allocation=lab.parent/"deferred-word-binding-20261122/comparison/frozen-reference"
core="Lokad.Lython.dll"
paths={role:lab/f"{build}/bin/Lokad.Lython/release_net11.0"/core
       for role,build in (("reference","reference"),("candidate","windows"))}
assert sha(paths["reference"])!=sha(paths["candidate"])
tree=repo/".git/agent-worktrees/native-call-selection-single-proof-20261122"
reference=subprocess.check_output(["git","rev-parse","HEAD"],cwd=tree,text=True).strip()
assert reference.startswith("b5f0c0c18")
assert not subprocess.check_output(["git","diff","76b7934f7",reference,"--","src/Lokad.Lython"],cwd=repo)
patch=subprocess.check_output(["git","diff","--binary","HEAD","--","src","tests"],cwd=tree)
assert patch.count(b"diff --git ")==14
(out/"source.patch").write_bytes(patch)
catalog_copy=out/"representative.json"
shutil.copyfile(catalog,catalog_copy)
results={}
manifests={}
for role,built in paths.items():
    image=out/("frozen-"+role)
    image.mkdir(exist_ok=True)
    for name in donor:shutil.copyfile(built if name==core else base/name,image/name)
    manifest={**donor,core:sha(built)}
    manifests[role]=manifest
    assert {name:sha(image/name) for name in donor}==manifest
    for suffix in (".dll",".deps.json",".runtimeconfig.json"):
        name="ValidatedAllocation"+suffix
        shutil.copyfile(allocation/name,image/name)
    receipt=out/(role+"-verify.json")
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog_copy,
        "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",receipt],
        env=env,cwd=repo,check=True,timeout=90)
    check=read(receipt)
    assert check["state"]=="Completed" and check["caseCount"]==6 and check["catalogSha256"]==sha(catalog_copy)
    report=out/(role+"-allocation.json")
    subprocess.run([dotnet,image/"ValidatedAllocation.dll",image,catalog_copy,report],env=env,cwd=repo,check=True,timeout=85)
    rows=read(report)["rows"]
    assert len(rows)==6 and all(r["sharedBudgetBaselineRestored"] for r in rows)
    results[role]=rows
    assert {name:sha(image/name) for name in manifest}==manifest
save(out/"identity.json",dict(reference=reference,equivalentCoreSource="76b7934f7",imageFiles=manifests,
                             protocolSHA256=sha(protocol),catalogSHA256=sha(catalog_copy),
                             sourcePatchSHA256=sha(out/"source.patch")))
for a,b in zip(results["reference"],results["candidate"],strict=True):
    assert a["id"]==b["id"]
    x,y=[statistics.median(r["allocatedBytesPerInvocation"]) for r in (a,b)]
    print(a["id"],x,y,round(100*(y/x-1),3),a["peakExecutionMemoryBytes"],b["peakExecutionMemoryBytes"],flush=True)
