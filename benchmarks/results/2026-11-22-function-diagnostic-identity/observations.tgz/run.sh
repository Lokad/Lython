set -eu
root=/home/lokad/lython-bench-checks/function-diagnostic-identity-b1417-20261122
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
