from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,zipfile,xml.etree.ElementTree as E
repo=Path('D:/code/Lython');root=Path(__file__).parent;old=root.parent/'adapter40'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,s):
 with (root/n).open('w',encoding='utf-8',newline='\n') as f:f.write(s)
assert not (root/'identity.json').exists()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo).strip()
feed=root/'feed';feed.mkdir();packages={}
for name in ['Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']:
 source=Path('D:/code/utf8regex/artifacts/nuget')/(name+'.0.5.0-dev.44.nupkg');target=feed/source.name
 digest=sha(source);shutil.copyfile(source,target);assert sha(target)==digest
 with zipfile.ZipFile(target) as a:
  nuspec=E.fromstring(a.read(name+'.nuspec'));metadata=nuspec.find('{*}metadata');revision=metadata.find('{*}repository').attrib['commit']
  xml=a.read('lib/net11.0/'+name+'.xml');write(name+'.xml',xml.decode('utf-8-sig'))
  members=E.fromstring(xml).findall('.//member')
  surface=[m.attrib['name'] for m in members if any(k in m.attrib['name'] for k in ['MemoryAllowance','Retained','CreateMatchCursor','MatchDetailedData','TryGetGroup','GetGroupNames'])]
  packages[name]=dict(sha256=digest,revision=revision,version='0.5.0-dev.44',libraries={n:hashlib.sha256(a.read(n)).hexdigest() for n in a.namelist() if n.endswith('/'+name+'.dll')},relevantSurface=surface)
assert len({p['revision'] for p in packages.values()})==1
shutil.copyfile(old/'Utf8RegexProvider.cs',root/'Utf8RegexProvider.cs');shutil.copyfile(old/'filters.json',root/'filters.json')
s=(old/'Directory.Build.props').read_text(encoding='utf-8').replace(str(old).replace('\\','/'),str(root).replace('\\','/'))
s=s.replace('<RestoreFallbackFolders>','<RestoreFallbackFolders>'+str(old/'packages').replace('\\','/')+';')
write('Directory.Build.props',s)
write('Directory.Packages.props',(old/'Directory.Packages.props').read_text(encoding='utf-8').replace('0.5.0-dev.40','0.5.0-dev.44'))
write('NuGet.Config',(old/'NuGet.Config').read_text(encoding='utf-8').replace('adapter40/feed','adapter44/feed'))
identity=dict(developmentOnly=True,promoted=False,coreRevision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),normalPin='0.4.0 unchanged',variant='Existing selected native ranges/current-operation local token bridge; newer immutable producer baseline',providerSHA256=sha(root/'Utf8RegexProvider.cs'),packages=packages)
write('identity.json',json.dumps(identity,indent=2)+'\n')
write('contract.md','''# Lython optional-adapter development — immutable dev44
Core62141d4d remains backend-independent. No normal package pin, source, lock or
runtime dependency change. Reuse the selected private dev40 native-range adapter,
keeping its current-operation token bridge; build/check it against exact immutable
dev44 package bytes and current core. Separate this baseline from any later
funded-program/working-allowance simplification. No inherited qualification.
Reuse existing focused semantics, real compile/match/cursor interruption, refusal,
cache/result retention, cleanup/budget reuse, both actual.NET11/.NET10. Preserve
all fixture/source/load identities; no repeated full platform campaign here.
Native program/working allowance APIs may remove matching-size heuristics through
the existing Lython budget hooks, wholly inside the optional adapter. First prove
exact API lifetime/refusal semantics; never add a per-buffer ledger, policy, tracing,
retry, unsafe code or backend edge to core. Retained programs/caches/native users
must remain funded through actual disposal. Detailed one-shot/name bridges and
creation-token coupling remain explicit limitations until exact APIs remove them.
This is development/contract qualification, not a released-producer safety or
whole-script performance claim. No sibling edits or publication.
''')
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
props=[f'-p:DirectoryBuildPropsPath={root}/Directory.Build.props',f'-p:DirectoryPackagesPropsPath={root}/Directory.Packages.props',f'-p:RestoreConfigFile={root}/NuGet.Config']
for suite in ['internal','public']:
 project='tests/Lokad.Lython.Tests' if suite=='internal' else 'tests/Lokad.Lython.PublicApi.Tests'
 p=root/f'baseline-build-{suite}.log'
 with p.open('w',encoding='utf-8') as output:r=subprocess.run([env['DOTNET_HOST_PATH'],'build',project,'-c','Release','--nologo','--tl:off',*props],cwd=repo,env=env,stdout=output,stderr=subprocess.STDOUT)
 print(suite,'build',r.returncode,flush=True)
 if r.returncode:print(p.read_text(encoding='utf-8')[-12000:]);raise SystemExit(r.returncode)
fixtureManifest=json.loads((old/'workflow-fixture-manifest.json').read_text(encoding='utf-8'))
for relative,files in fixtureManifest.items():
 source=repo/'tests/Fixtures'/relative
 for n,digest in files.items():assert sha(source/n)==digest
 for framework in ['net11.0','net10.0']:shutil.copytree(source,root/f'out/Lokad.Lython.PublicApi.Tests/Release/{framework}/Fixtures'/relative,dirs_exist_ok=False)
worker=root/'out/Lokad.Lython.WorkerFixture/Release';assert worker.is_dir()
link=root/'tests/Lokad.Lython.WorkerFixture/bin/Release';link.parent.mkdir(parents=True)
subprocess.run(['cmd','/c','mklink','/J',str(link),str(worker)],check=True,capture_output=True)
filters=json.loads((root/'filters.json').read_text(encoding='utf-8'));checks={}
for framework in ['net11.0','net10.0']:
 for suite in ['internal','public']:
  project='tests/Lokad.Lython.Tests' if suite=='internal' else 'tests/Lokad.Lython.PublicApi.Tests'
  p=root/f'baseline-{suite}-{framework}.log'
  with p.open('w',encoding='utf-8') as output:r=subprocess.run([env['DOTNET_HOST_PATH'],'test',project,'-c','Release','-f',framework,'--no-build','--no-restore',*props,'--filter',filters['native' if suite=='internal' else 'public']],cwd=repo,env=env,stdout=output,stderr=subprocess.STDOUT)
  t=p.read_text(encoding='utf-8');print(suite,framework,r.returncode,t[-500:],flush=True)
  if r.returncode:print(t[-12000:]);raise SystemExit(r.returncode)
  checks[suite+'-'+framework]=dict(passed=int(re.search(r'Passed:\s+(\d+)',t)[1]))
 folder=root/f'out/Lokad.Lython.PublicApi.Tests/Release/{framework}'
 hashes={n:sha(folder/(n+'.dll')) for n in ['Lokad.Lython','Lokad.Lython.Utf8Regex','Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']}
 for name in ['Lokad.Utf8Regex','Lokad.Utf8Regex.PythonRe']:assert hashes[name]==packages[name]['libraries']['lib/'+framework+'/'+name+'.dll']
 checks[framework+'-loadedFiles']=hashes
write('baseline-qualification.json',json.dumps(dict(identity=identity,checks=checks,limitations='Focused private adapter development only; no released/safety/whole-script promotion'),indent=2)+'\n')
