from pathlib import Path
import hashlib,io,json,shlex,subprocess,tarfile
lab=Path(__file__).parent
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes','-o','ConnectTimeout=12','lokad@20.166.121.73']
archive_parent="""
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess,sys,tarfile,io
parent=Path('/home/lokad/lython-bench-checks'); root=parent/'checkout-stack-guard-baseline-20261012'
assert root.resolve()==root
included=('benchmarks/Lokad.Lython.Benchmarks/bin','src/Lokad.Lython/bin','tools/LythonProbe/bin')
sha=lambda p: hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
def files():
    assert subprocess.check_output(['git','-C',str(root),'rev-parse','--short','HEAD'],text=True).strip()=='3980fa9d'
    assert not subprocess.check_output(['git','-C',str(root),'ls-files','--',*included],text=True).strip()
    for directory in included:
        block=root/directory
        assert block.resolve()==block and block.is_dir()
        for item in sorted(block.rglob('*')):
            assert item.resolve()==item and item.is_relative_to(block)
            meta=item.lstat()
            if item.is_dir(): continue
            assert stat.S_ISREG(meta.st_mode) and meta.st_uid==os.getuid()
            if meta.st_nlink!=1: continue
            yield item.relative_to(root).as_posix(),item
with (parent/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert subprocess.run(['pgrep','-f','[d]otnet.*--compare worker|[p]erf record.*lython-bench-checks'],capture_output=True).returncode==1
"""
backup=archive_parent+"""
    with tarfile.open(fileobj=sys.stdout.buffer,mode='w|gz',compresslevel=3) as target:
        members={}
        for name,item in files():
            target.add(item,arcname=name,recursive=False);members[name]=sha(item)
        data=json.dumps(members,sort_keys=True).encode()
        receipt=tarfile.TarInfo('verified-members.json');receipt.size=len(data);target.addfile(receipt,io.BytesIO(data))
"""
out=lab/'b1674-reusable-vm-space-3980fa9d.tar.gz'
with out.open('wb') as file:
    subprocess.run(ssh+['python3 -c '+shlex.quote(backup)],stdout=file,check=True,timeout=95)
with tarfile.open(out) as archived:
    manifest=json.load(archived.extractfile('verified-members.json'))
    local={item.name:hashlib.file_digest(archived.extractfile(item),'sha256').hexdigest() for item in archived if item.name!='verified-members.json'}
assert local==manifest and len(manifest)>20
retire=archive_parent+"""
    manifest=json.load(sys.stdin)
    current={name:(item,sha(item)) for name,item in files()}
    assert manifest=={name:meta[1] for name,meta in current.items()}
    before=shutil.disk_usage(parent).free
    for item,_ in current.values():item.unlink()
    print(json.dumps(dict(freeBefore=before,freeAfter=shutil.disk_usage(parent).free,fileCount=len(current))))
"""
raw=subprocess.check_output(ssh+['python3 -c '+shlex.quote(retire)],input=json.dumps(manifest),encoding='utf-8',timeout=35)
receipt=json.loads(raw);receipt.update(backupSHA256=hashlib.file_digest(out.open('rb'),'sha256').hexdigest(),backupBytes=out.stat().st_size)
(lab/'vm-build-output-custody.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8');print(receipt)
