from pathlib import Path
import hashlib,json,os,shutil,subprocess
lab=Path(__file__).resolve().parent; repo=lab.parents[3]
source=lab.with_name('default-operand-storage-20261125'); quiet=source/'comparison/quiet'
previous=lab.with_name('post-zip-cpu-final-20261125')
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
save=lambda p,d:write(p,json.dumps(d,ensure_ascii=False,indent=2)+'\n')
git=lambda args:subprocess.check_output(['git',*args],cwd=repo)
production=git(['rev-parse','01f1f6118']).decode().strip(); donor=read(quiet/'identity.json'); images=donor['imageFiles']
patch=git(['diff','--binary',donor['sourceRevision'],production,'--','src'])
assert patch==(source/'candidate.patch').read_bytes() and hashlib.sha256(patch).hexdigest()==donor['sourcePatchSHA256']
assert not git(['diff','--name-only',production,'--','src','benchmarks/Lokad.Lython.Benchmarks','benchmarks/cpython-worker.py','global.json'])
receipt=read(quiet/'terminal-status.json')['receipt']; assert receipt['complete'] and receipt['allWorkersJoined'] and sha(quiet/'observations.tar.xz')==receipt['archiveSHA256']
catalog=read(quiet/'representative.json'); ordinary='diagnostic.generated-ordinary-definitions'; rules='scripts.rule-default-closures'
catalog['cases']=[r for r in catalog['cases'] if r['id'] in (ordinary,rules)]; assert len(catalog['cases'])==2
save(lab/'catalog.json',catalog)
identity=dict(sourceRevision=production,measurementReference=donor['sourceRevision'],sourcePatchSHA256=donor['sourcePatchSHA256'],imageFiles=images,coreSHA256={role:files['Lokad.Lython.dll'] for role,files in images.items()},
    cpythonWorkerSHA256=donor['cpythonWorkerSHA256'],profiles=[[role+'-ordinary-warm',ordinary,role] for role in ('reference','candidate')],
    purpose='Attribute ordinary function definitions before and after retaining singleton positional integers',donorArchiveSHA256=receipt['archiveSHA256'],profileCatalogSHA256=sha(lab/'catalog.json'))
save(lab/'identity.json',identity); save(lab/'verified-raw-replicas.json',[])
sdk=Path.home()/'.dotnet11'; dotnet=sdk/'dotnet.exe'; env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk)); protocol=repo/'benchmarks/cpython-worker.py'
assert sha(protocol)==identity['cpythonWorkerSHA256']
for role,files in images.items():
    folder=source/role; proof=lab/(role+'-verification.json')
    assert len(files)==32 and {p.name:sha(p) for p in folder.iterdir()}==files
    subprocess.run([dotnet,folder/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',lab/'catalog.json',
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',protocol,'--out',proof],env=env,cwd=repo,check=True,timeout=65)
    checked=read(proof); assert checked['state']=='Completed' and checked['caseCount']==2 and checked['catalogSha256']==identity['profileCatalogSHA256']
    assert checked['launched']['library']['sha256']==files['Lokad.Lython.dll']
shutil.copyfile(previous/'run.sh',lab/'run.sh'); assert b'\r' not in (lab/'run.sh').read_bytes()
launcher=(previous/'quiet.py').read_text(encoding='utf-8').replace('post-zip-cpu-final-b1666','ordinary-definition-cpu-b1674').replace('lython-b1666-post-zip-cpu-final','lython-b1674-ordinary-definition-cpu').replace('zip-unpack-20261125','default-operand-storage-20261125')
launcher=launcher.replace('"candidate-verification.json","ops-profile.py"','"candidate-verification.json","reference-verification.json","ops-profile.py"').replace("'candidate-verification.json','ops-profile.py'","'candidate-verification.json','reference-verification.json','ops-profile.py'")
collector=(previous/'collect.py').read_text(encoding='utf-8').replace('zip-unpack-b1665-20261125','default-operand-storage-b1670-20261125').replace('b1666-fixtures','b1674-fixtures')
archive=(previous/'archive.py').read_text(encoding='utf-8').replace('2026-11-25-post-zip-cpu','2026-11-25-ordinary-definition-cpu').replace('startswith("ac9f9211b")','startswith("01f1f6118")')
archive=archive.replace('"candidate-verification.json","verified-raw-replicas.json"','"candidate-verification.json","reference-verification.json","verified-raw-replicas.json","custody-space.py","vm-build-output-custody.json"')
analysis=(previous/'analyze.py').read_text(encoding='utf-8').replace("'default tuple': ('CreatePreparedPositionalDefaults','PositionalDefaults','PyTuple::From','StoreFunctionDefault','TryReadTrailingSlot'),", "'default storage': ('AllocateFunctionDefaults','StartExecutableDefaults','StoreDefaultResult','StoreInlinePositionalDefault','PreparePositionalValue','OwnPrivatePositionalDefault','ReadExecutableDefaults','TryReadTrailingSlot'),\n     'default consumption': ('TryReadPreparedDefaultInteger','ReadPreparedDefault','HasPreparedOmittedArguments','TryGetPositionalDefault','DefaultIntegerOperands'),")
for name,s in [('quiet.py',launcher),('collect.py',collector),('archive.py',archive),('analyze.py',analysis),('ops-profile.py',(previous/'ops-profile.py').read_text(encoding='utf-8'))]:compile(s,name,'exec');write(lab/name,s)
