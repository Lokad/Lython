from pathlib import Path
import hashlib, json, os, shutil, subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
previous = lab.with_name("forwarded-rule-cpu-20261124")
meter = lab.with_name("current-meter-tuple-cpu-20261124")
donor = lab.with_name("shared-prepared-definitions-20261124")
donor_out = donor / "comparison/quiet"
read = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def save(p, v): p.write_text(json.dumps(v, ensure_ascii=False, indent=2)+"\n", encoding="utf-8", newline="\n")
head = subprocess.check_output(["git","rev-parse","HEAD"], cwd=repo, text=True).strip()
assert head.startswith("3d8f68aaf")
identity = read(donor_out / "identity.json")
patch = subprocess.check_output(["git","diff","--binary",identity["sourceRevision"],head,"--","src","tests"], cwd=repo)
assert patch == (donor/"candidate.patch").read_bytes() and hashlib.sha256(patch).hexdigest() == identity["sourcePatchSHA256"]
receipt = read(donor_out/"terminal-status.json")["receipt"]
assert receipt["complete"] and receipt["allWorkersJoined"] and receipt["archivedAndVerifiedUnderLease"]
assert sha(donor_out/"observations.tar.xz") == receipt["archiveSHA256"]
candidate = identity["imageFiles"]["candidate"]
assert {p.name:sha(p) for p in (donor/"candidate").iterdir()} == candidate and len(candidate) == 32

profiles = [
    ("typed-meter", "scripts.csv-meter-report.typed-unicode", "candidate"),
    ("explicit-meter", "scripts.csv-meter-report.explicit-float", "candidate"),
    ("short-report", "diagnostic.text-summary.nonlocal-computed-width.large", "candidate"),
]
catalog = read(meter/"catalog.json")
text_catalog = read(donor_out/"representative.json")
for name in ("schemaVersion", "fixtureEncoding"):
    assert catalog[name] == text_catalog[name]
wanted = {case for _, case, _ in profiles}
catalog["cases"] = [case for case in catalog["cases"] + text_catalog["cases"] if case["id"] in wanted]
assert len(catalog["cases"]) == len(wanted)
save(lab/"catalog.json", catalog)
identity.update(sourceRevision=head, profiles=profiles, donorArchiveSHA256=receipt["archiveSHA256"],
    purpose="Locate remaining CSV record and text processing stages after Unicode decimal conversion and native helper work",
    profileCatalogSHA256=sha(lab/"catalog.json"), imageFiles={"candidate":candidate})
save(lab/"identity.json",identity)
save(lab/"verified-raw-replicas.json",[])
sdk = Path.home()/".dotnet11"
cpython = repo/"benchmarks/cpython-worker.py"
assert sha(cpython)==identity["cpythonWorkerSHA256"]
subprocess.run([sdk/"dotnet.exe",donor/"candidate/Lokad.Lython.Benchmarks.dll","--compare","verify",
    "--catalog",lab/"catalog.json","--dotnet",sdk/"dotnet.exe","--python","C:/Python313/python.exe",
    "--python-worker",cpython,"--out",lab/"candidate-verification.json"],
    cwd=repo,env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk)),timeout=45,check=True)
shutil.copyfile(previous/"run.sh",lab/"run.sh")
assert b"\r" not in (lab/"run.sh").read_bytes()
for name in ("quiet.py","ops-profile.py","collect.py"):
    text=(previous/name).read_text(encoding="utf-8")
    text=text.replace("borrow-forwarded-integers-20261124","shared-prepared-definitions-20261124")
    text=text.replace("borrow-forwarded-integers-b1631-20261124","shared-prepared-definitions-b1635-20261124")
    text=text.replace("forwarded-rule-cpu-b1634-20261124","current-record-text-cpu-b1637-20261124")
    text=text.replace("lython-b1634-forwarded-rule-cpu","lython-b1637-current-record-text-cpu")
    text=text.replace("b1634-fixtures","b1637-fixtures")
    compile(text,name,"exec")
    (lab/name).write_text(text,encoding="utf-8",newline="\n")
print("Verified current frozen source and three full-workload goldens.")
