from pathlib import Path
import subprocess,tarfile
root=Path('/home/lokad/lython-bench-checks/private-csv-b257-20261105');root.mkdir(exist_ok=False)
with tarfile.open('/home/lokad/lython-bench-checks/b257-payload.tgz') as t:t.extractall(root,filter='data')
subprocess.run(['python3',str(root/'setup.py')],check=True)
subprocess.run(['/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet','build',str(root/'jobs/complete-jobs.csproj'),'-c','Release','--nologo'],check=True,stdout=open(root/'driver-build.log','w'),stderr=subprocess.STDOUT)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b257-private-csv-20261105','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=180','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'collect.sh')],check=True)
