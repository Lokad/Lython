from pathlib import Path
import shutil
root=Path('/home/lokad/lython-bench-checks/private-csv-refined-b258-20261105')
base=Path('/home/lokad/lython-bench-checks/known-list-storage-b255-20261105/candidate')
(root/'baseline').symlink_to(base,target_is_directory=True)
for f in base.iterdir():
 if f.name in ['Lokad.Lython.dll','Lokad.Lython.pdb']:continue
 (root/'candidate'/f.name).symlink_to(f.resolve(),target_is_directory=f.is_dir())
assert shutil.disk_usage(root).free>48*1024*1024
