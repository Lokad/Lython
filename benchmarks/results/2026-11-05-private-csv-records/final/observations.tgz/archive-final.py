from pathlib import Path
import hashlib, json, subprocess, tarfile, fcntl

root = Path('/home/lokad/lython-bench-checks/private-csv-refined-b258-20261105')
unit = 'lython-b258-private-csv-refined-20261105'
status = subprocess.check_output(['systemctl','show',unit,'--property=LoadState,ActiveState,Result,MainPID'],text=True)
assert 'ActiveState=inactive' in status and 'MainPID=0' in status and 'Result=success' in status, status
assert (root/'exit-code.txt').read_text().strip() == '0'
(root/'final-service-status.txt').write_text(status,encoding='utf-8')
data = json.loads((root/'comparison.json').read_text())
assert len(data['observations']) == 5
assert all(data[k] for k in ('allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'))
for n in ('before','after'): assert json.loads((root/f'machine-{n}.json').read_text())['gate']['quiet']
with open(root.parent/'comparison-vm.lock','w') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
    assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]omplete-jobs.dll'],capture_output=True).returncode == 1
    with tarfile.open(root/'observations.tgz','w:gz') as archive:
        for f in root.iterdir():
            if f.is_file() and f.name != 'observations.tgz': archive.add(f,arcname=f.name)
        for f in (root/'jobs').iterdir():
            if f.is_file(): archive.add(f,arcname='jobs/'+f.name)
print(hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest())
