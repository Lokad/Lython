from pathlib import Path
import json, shutil, tarfile

root = Path(__file__).resolve().parent
old = root.parent/'private-csv-refined-d34/payload'
remote = '/home/lokad/lython-bench-checks/private-csv-text-confirm-b259-20261105'
unit = 'lython-b259-private-csv-text-confirm-20261105'
(root/'candidate').mkdir()
(root/'jobs').mkdir()
for name in ('candidate-identity.json','source.patch','source-snapshot.tgz','hash-witness.json','reference-check.py'):
    shutil.copy2(old/name,root/name)
catalog = json.loads((old/'catalog.json').read_text(encoding='utf-8'))
catalog['cases'] = [c for c in catalog['cases'] if c['id'] == 'scripts.text-summary-helpers.large']
(root/'catalog.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8')
program = (old/'jobs/Program.cs').read_text(encoding='utf-8')
start = program.index('if (cases.Length !='); end = program.index('var observations =',start)
program = program[:start] + '''if (cases.Length != 1 || cases[0].GetProperty("id").GetString() != "scripts.text-summary-helpers.large" || cases[0].GetProperty("mode").GetString() != "warm")
    throw new InvalidDataException("Only unchanged text confirmation is allowed.");
''' + program[end:]
start = program.index('    using var before ='); end = program.index('    var images =',start)
program = program[:start] + '''    using var control = new Image(beforePath, item, hashSource, "before-control");
    using var candidate = new Image(candidatePath, item, hashSource, "candidate");
    using var before = new Image(beforePath, item, hashSource, "before");
''' + program[end:]
program = program.replace('var caseNumber = 0','var caseNumber = 1').replace('warmupMs < 6000','warmupMs < 10000').replace('200.0 * warmupBatch','250.0 * warmupBatch').replace('warmupGuestSecondsPerImage = 6','warmupGuestSecondsPerImage = 10').replace('targetBatchMilliseconds = 200','targetBatchMilliseconds = 250')
program = program.replace('Private CSV rows versus7efe581b;native and ordinary helperCSV,ordinary fresh,reader and text controls','Unchanged402ae9f1 text confirmation;reversed construction,warmup and longer guestwarmup')
(root/'jobs/Program.cs').write_text(program,encoding='utf-8')
shutil.copy2(old/'jobs/complete-jobs.csproj',root/'jobs/complete-jobs.csproj')
setup = f'''from pathlib import Path
import shutil
root=Path({remote!r})
previous=Path('/home/lokad/lython-bench-checks/private-csv-refined-b258-20261105')
(root/'baseline').symlink_to(previous/'baseline',target_is_directory=True)
for f in (previous/'candidate').iterdir():
 (root/'candidate'/f.name).symlink_to(f.resolve(),target_is_directory=f.is_dir())
assert shutil.disk_usage(root).free>32*1024*1024
'''
(root/'setup.py').write_text(setup,encoding='utf-8')
for name in ('collect.sh','launch.py'):
    text = (old/name).read_text(encoding='utf-8').replace('private-csv-refined-b258-20261105','private-csv-text-confirm-b259-20261105').replace('lython-b258-private-csv-refined-20261105',unit).replace('b258-payload.tgz','b259-payload.tgz').replace('RuntimeMaxSec=185','RuntimeMaxSec=75')
    (root/name).write_text(text,encoding='utf-8',newline='\n')
text = (root.parent/'private-csv-refined-d34/archive-final.py').read_text(encoding='utf-8').replace('private-csv-refined-b258-20261105','private-csv-text-confirm-b259-20261105').replace('lython-b258-private-csv-refined-20261105',unit).replace("len(data['observations']) == 5","len(data['observations']) == 1")
(root/'archive.py').write_text(text,encoding='utf-8')
text = (root.parent/'private-csv-refined-d34/assess.py').read_text(encoding='utf-8').replace('Private CSV rows versus7efe581b;five complete-script/control jobs','Unchanged402ae9f1 text confirmation;one complete-script job')
(root/'assess.py').write_text(text,encoding='utf-8')
shutil.copy2(root/'plan.md',root/'pre-measurement-plan.md')
with tarfile.open(root/'payload.tgz','w:gz') as archive:
    for f in root.iterdir():
        if f.name != 'payload.tgz': archive.add(f,arcname=f.name)
