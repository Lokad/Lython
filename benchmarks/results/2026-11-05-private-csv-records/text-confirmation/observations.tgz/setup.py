from pathlib import Path
import shutil
root=Path('/home/lokad/lython-bench-checks/private-csv-text-confirm-b259-20261105')
previous=Path('/home/lokad/lython-bench-checks/private-csv-refined-b258-20261105')
(root/'baseline').symlink_to(previous/'baseline',target_is_directory=True)
for f in (previous/'candidate').iterdir():
 (root/'candidate'/f.name).symlink_to(f.resolve(),target_is_directory=f.is_dir())
assert shutil.disk_usage(root).free>32*1024*1024
