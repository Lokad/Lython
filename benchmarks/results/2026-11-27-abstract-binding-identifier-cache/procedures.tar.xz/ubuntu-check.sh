#!/bin/bash
set -euo pipefail
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
cd /mnt/d/code/Lython
lab="$PWD/.git/agent-notes/review-20261031/abstract-binding-identifier-cache-20261127"
export NUGET_PACKAGES="$PWD/.git/agent-notes/review-20261031/regex-released-050-20261127/packages-ubuntu"
public=tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj
internal=tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj
{
    dotnet restore "$public" --locked-mode --artifacts-path "$lab/ubuntu" --source https://api.nuget.org/v3/index.json
    dotnet restore "$internal" --locked-mode --artifacts-path "$lab/ubuntu" --source https://api.nuget.org/v3/index.json
} 2>&1 | tee "$lab/ubuntu-restore.log"
dotnet test "$public" -c Release -f net10.0 --no-restore --artifacts-path "$lab/ubuntu" \
    --filter 'Category!=Stress&(FullyQualifiedName~Static|FullyQualifiedName~Diagnostics|FullyQualifiedName~CompilerCancellation|FullyQualifiedName~SharedCompilerFact|FullyQualifiedName~Comprehension|FullyQualifiedName~RegexAnalysis|FullyQualifiedName~AdmissionFailureCommand|FullyQualifiedName~GlobalBinding)' \
    2>&1 | tee "$lab/ubuntu-public-net10.0.log"
dotnet test "$internal" -c Release -f net10.0 --no-restore --artifacts-path "$lab/ubuntu" \
    --filter 'Category!=Stress&(FullyQualifiedName~Static|FullyQualifiedName~Scope|FullyQualifiedName~Compiler|FullyQualifiedName~Ownership)' \
    2>&1 | tee "$lab/ubuntu-internal-net10.0.log"
