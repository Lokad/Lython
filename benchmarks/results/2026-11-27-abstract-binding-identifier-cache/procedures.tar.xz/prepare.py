from hashlib import sha256
from pathlib import Path
from statistics import median
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
notes = lab.parent
repo = lab.parents[3]
prior = notes/'json-eager-traversal-20261127'
donor = notes/'current-frontend-profile-20261127/local'
workers = lab/'comparison/local'
workers.mkdir(parents=True)
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
write = lambda p, value: p.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')
sha = lambda p: sha256(p.read_bytes()).hexdigest()
image = lambda p: {f.name: sha(f) for f in p.iterdir()}
core = 'Lokad.Lython.dll'
worker = 'Lokad.Lython.Benchmarks.dll'
python = Path('C:/Python313/python.exe')
sdk = Path.home() / '.dotnet11'
dotnet = sdk / 'dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
pinned = read(repo/'benchmarks/results/2026-11-27-json-eager-traversal/identity.json')
base = subprocess.check_output(['git','rev-parse','50392d6fa'],cwd=repo,text=True).strip()
assert not subprocess.check_output(['git','diff','--name-only',base,'HEAD','--','src'],cwd=repo)
assert sha256(subprocess.check_output(['git','diff','--binary',pinned['sourceRevision'],base,'--','src'],cwd=repo)).hexdigest()==pinned['sourcePatchSHA256']
patch=subprocess.check_output(['git','diff','--binary','HEAD','--','src'],cwd=repo)
assert b'abstractValueCache' in patch and b'TryResolveUncached' in patch and patch.count(b'diff --git ')==2
(lab/'candidate.patch').write_bytes(patch)
original=prior/'comparison/local'
assert image(original/'candidate')==pinned['imageFiles']['candidate']
for role in ('reference','candidate'):
    shutil.copytree(original/'candidate',workers/role)
fresh=repo/'src/Lokad.Lython/bin/Release/net11.0'/core
assert sha(fresh)!=sha(workers/'reference'/core)
shutil.copyfile(fresh,workers/'candidate'/core)
images={role:image(workers/role) for role in ('reference','candidate')}
assert [name for name, digest in images['reference'].items() if images['candidate'][name]!=digest]==[core]

for name in ('cpython-worker.py','run.sh'):
    shutil.copyfile(original/name,workers/name)
assert b'\r' not in (workers/'run.sh').read_bytes()
catalog=read(donor/'catalog.json')
assert sha(donor/'catalog.json')==read(donor/'identity.json')['profileCatalogSHA256']
nested=next(c for c in read(original/'representative.json')['cases'] if c['id']=='diagnostic.nested-json-document')
catalog['cases'].append(nested)
write(workers/'representative.json',catalog)
jobs=[(catalog['cases'][0]['id'],'compile'),(catalog['cases'][1]['id'],'compile'),
      (catalog['cases'][2]['id'],'compile-run'),(catalog['cases'][2]['id'],'compile'),(nested['id'],'warm')]
write(workers/'jobs.json',{'warm':jobs})
identity=dict(sourceRevision=base,sourcePatchSHA256=sha(lab/'candidate.patch'),productionReference=base,imageFiles=images,
    coreSHA256={role+suffix:files[core] for role,files in images.items() for suffix in ('','-control')},
    comparisonHostRevision=pinned['comparisonHostRevision'],cpythonWorkerSHA256=sha(workers/'cpython-worker.py'),
    independentCPythonVersion=subprocess.check_output([python,'--version'],text=True).strip(),verificationPythonSHA256=sha(python),
    purpose='Remove identifier cache entries and duplicate abstract resolution dispatch. Compare compilation and a nested JSON control.')
identity['catalogs']={name:{'sha256':sha(workers/name)} for name in ('representative.json','jobs.json')}
write(workers/'identity.json',identity)
collector=(original/'collect.py').read_text(encoding='utf-8').replace('lython-b1874-eager-traversal-fixture-','lython-b1876-abstract-binding-fixture-')
compile(collector,'collect.py','exec')
(workers/'collect.py').write_text(collector,encoding='utf-8',newline='\n')
for role, files in images.items():
    report=workers/f'{role}-verify.json'
    subprocess.run([dotnet,workers/role/worker,'--compare','verify','--catalog',workers/'representative.json',
        '--dotnet',dotnet,'--python',python,'--python-worker',workers/'cpython-worker.py','--out',report],env=env,check=True,timeout=75)
    proof=read(report)
    assert proof['state']=='Completed' and proof['caseCount']==4
    assert proof['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert proof['launched']['adapter']['sha256']==files[worker] and proof['launched']['library']['sha256']==files[core]
