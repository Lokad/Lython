from hashlib import sha256
from pathlib import Path
from statistics import median
import json
import re
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
comparison = lab / 'comparison/local'
out = repo / 'benchmarks/results/2026-11-27-abstract-binding-identifier-cache'
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
write = lambda path, value: path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')
sha = lambda path: sha256(path.read_bytes()).hexdigest()
receipt = read(comparison / 'archive-receipt.json')
assert receipt['archivedAndVerifiedUnderLease'] and receipt['guestFixturesRemoved'] and receipt['allWorkersJoined']
assert receipt['archiveSHA256'] == sha(comparison / 'observations.tar.xz')
assert receipt['quietBeforeAndAfter'] is None and receipt['complete']
assert (comparison / 'exit-code.txt').read_text().strip() == '0'
identity = read(comparison / 'identity.json')
assert identity['sourcePatchSHA256'] == sha(lab / 'candidate.patch')
assert subprocess.check_output(['git', 'diff', '--binary', identity['sourceRevision'], '--', 'src'], cwd=repo) == (lab / 'candidate.patch').read_bytes()
prior = read(out.parent / '2026-11-27-json-eager-traversal/identity.json')
assert identity['imageFiles']['reference'] == prior['imageFiles']['candidate']
for role, expected in identity['imageFiles'].items():
    assert len(expected) == 32 and {p.name: sha(p) for p in (comparison / role).iterdir()} == expected
    proof = read(comparison / f'{role}-verify.json')
    assert proof['state'] == 'Completed' and proof['caseCount'] == 4
    assert proof['catalogSha256'] == identity['catalogs']['representative.json']['sha256']
    assert proof['launched']['library']['sha256'] == expected['Lokad.Lython.dll']
assert [name for name, digest in identity['imageFiles']['reference'].items()
    if identity['imageFiles']['candidate'][name] != digest] == ['Lokad.Lython.dll']
parity=read(comparison/'compiler-parity.json')
assert len(parity['cases']) == 17 and sum(c['budgetLevels'] for c in parity['cases']) == 131
assert parity['cancellation']['afterDispose'] == 0
with tarfile.open(comparison / 'observations.tar.xz') as archive:
    assert json.load(archive.extractfile('identity.json')) == identity
    for name, expected in identity['catalogs'].items():
        assert sha256(archive.extractfile(name).read()).hexdigest() == expected['sha256']
    raw = json.load(archive.extractfile('confirmation/confirmation.json'))
    assert raw['complete'] and receipt['warmJobs'] == len(raw['jobs']) == 5
    assert all(job['workersJoinedAndFixturesRemoved'] and len(job['samples']) == 28 for job in raw['jobs'])
    machine = json.load(archive.extractfile('confirmation/machine-local.json'))
    assert machine['affinity'] == [27]

rows = []
for job in raw['jobs']:
    measures = {}
    for role, worker in job['identities'].items():
        binaries = {Path(entry['path']).name: entry['sha256'].lower() for entry in worker['libraries']}
        assert binaries['Lokad.Lython.dll'] == identity['coreSHA256'][role]
        samples = [item for item in job['samples'] if item['engine'] == role]
        assert len(samples) == 7
        elapsed, cpu = [], []
        for sample in samples:
            response = sample['response']
            assert response['status'] == 'Completed'
            count = response['completedInvocations']
            elapsed.append(1e6 * response['elapsedTicks'] / response['clockFrequency'] / count)
            cpu.append(1e6 * sample['externalProcessCpuTicks'] / sample['externalCpuFrequency'] / count)
        measures[role] = dict(elapsed=median(elapsed), cpu=median(cpu))
    change, spread = {}, {}
    for metric in ('elapsed', 'cpu'):
        before, after = ([measures[role][metric], measures[role + '-control'][metric]] for role in ('reference', 'candidate'))
        pairs = [100 * (new / old - 1) for old in before for new in after]
        change[metric] = [min(pairs), max(pairs)]
        spread[metric] = [100 * (max(source) / min(source) - 1) for source in (before, after)]
    row = dict(case=job['case'], lane=job['lane'], percentChange=change, sameSourceSpreadPercent=spread, medianUs=measures)
    rows.append(row)
    print(row['case'], row['lane'], change, spread, flush=True)
out.mkdir(exist_ok=True)
write(out / 'summary.json', dict(timedBatches=140, quietQualified=False, collectionSeconds=raw['elapsedSeconds'], rows=rows))
for name in ('identity.json', 'archive-receipt.json', 'observations.tar.xz', 'exit-code.txt'):
    shutil.copyfile(comparison / name, out / name)
shutil.copyfile(comparison / 'compiler-parity.json', out / 'compiler-parity.json')
files = {name: comparison / name for name in ('reference-verify.json', 'candidate-verify.json','representative.json','jobs.json')}
files.update({name: lab / name for name in ('prepare.py','prepare.log','compile-parity.py','compile-parity.log',
    'candidate.patch','collect-local.sh','collection.log','archive.py','ubuntu-check.sh','ubuntu-restore.log','probe-build-net11.log')})
for role in ('reference','candidate'):
    for name in ('observed.json','cancellation.json'):
        files[f'probe-{role}/{name}']=comparison/f'probe-{role}'/name
for prefix, targets in (('windows', ('net11.0', 'net10.0')), ('ubuntu', ('net10.0',))):
    for target in targets:
        for suite, count in (('public', 598), ('internal', 832)):
            name = f'{prefix}-{suite}-{target}.log'
            path = lab / name
            assert re.search(rf'Failed:\s+0, Passed:\s+{count},', path.read_text(encoding='utf-8-sig')), name
            files[name] = path
with tarfile.open(out / 'procedures.tar.xz', 'w:xz') as archive:
    for name, path in files.items():
        archive.add(path, arcname=name)
with tarfile.open(out / 'procedures.tar.xz') as archive:
    assert set(archive.getnames()) == set(files)
    assert all(sha256(archive.extractfile(name).read()).hexdigest() == sha(path) for name, path in files.items())
