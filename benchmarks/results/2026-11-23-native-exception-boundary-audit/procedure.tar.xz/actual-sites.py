from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.parent / "closed-definition-return-20261123/inspect"
image = lab / "reference"
project = lab / "actual-sites"
project.mkdir(exist_ok=True)
read = lambda path: json.loads(path.read_text(encoding="utf-8"))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
source = (donor / "Program.cs").read_text(encoding="utf-8")
marker = "            codes.Add(new { arithmetic,"
assert marker in source
source = source.replace(marker, """            var exceptionRegions = ((IEnumerable)Read(code, "ExceptionRegions")!).Cast<object>().Count();
            var dictionaryProbes = sites.Count(site => (bool)Read(site, "AccumulatesDictionary")!);
            var loopProbes = counts.GetValueOrDefault("ForNextDictionaryAccumulation");
            var closureProbes = ((IEnumerable)Read(code, "Instructions")!).Cast<object>()
                .Count(i => (bool)Read(i, "HasClosureArithmetic")!);
            var minimumRegionVisits = (long)exceptionRegions * (dictionaryProbes + loopProbes + closureProbes);
            var operations = ((IEnumerable)Read(code, "Instructions")!).Cast<object>()
                .Select(i => Read(i, "OpCode")!.ToString()).ToArray();
            long possibleChecks = 0;
            for (var i = 0; i + 2 < operations.Length; i++)
            {
                if (operations[i] == "Call" && operations[i + 1] == "Binary" && operations[i + 2] == "StoreSubscript")
                    possibleChecks += 2; // Three instructions, plus the enclosing loop if eligible.
                if (operations[i] == "LoadClosure" && operations[i + 1] == "Augmented" && operations[i + 2] == "StoreClosure")
                    possibleChecks++;
            }
            var maximumRegionVisits = exceptionRegions * possibleChecks;
            codes.Add(new { exceptionRegions, dictionaryProbes, loopProbes, closureProbes, minimumRegionVisits, maximumRegionVisits, arithmetic,""")
(project / "Program.cs").write_text(source, encoding="utf-8", newline="\n")
project_file = project / "Inspect.csproj"
project_file.write_text((donor / "Inspect.csproj").read_text(encoding="utf-8").replace("../candidate/", "../reference/"),
                        encoding="utf-8", newline="\n")
shutil.copyfile(donor / "packages.lock.json", project / "packages.lock.json")
cases = read(lab / "audit-cases.json")["cases"]
with tarfile.open(repo / "benchmarks/results/2026-11-16-protected-search-attribution/procedure.tar.xz") as archive:
    protected = json.load(archive.extractfile("profile/catalog.json"))["cases"]
cases.extend(dict(id=row["id"], source=row["source"]) for row in protected)
validator = lab.parent / "sparse-branch-confirmation-20261123/comparison/quiet/representative.json"
cases.extend(dict(id=row["id"], source=row["source"]) for row in read(validator)["cases"])
unique = {}
for row in cases:
    if row["id"] in unique:
        assert row["source"] == unique[row["id"]]["source"]
    unique[row["id"]] = row
catalog = lab / "actual-cases.json"
catalog.write_text(json.dumps(dict(cases=list(unique.values())), indent=2, ensure_ascii=False)+"\n",
                   encoding="utf-8", newline="\n")
dotnet = Path.home() / ".dotnet11/dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
output = project / "build"
subprocess.run([dotnet,"build",project_file,"-c","Release","-o",output], env=env, timeout=50, check=True)
for name in ("Inspect.dll","Inspect.runtimeconfig.json","Inspect.deps.json"):
    shutil.copyfile(output / name, image / name)
raw = lab / "actual-sites-tape.json"
subprocess.run([dotnet,image/"Inspect.dll",catalog,raw], env=env, timeout=35, check=True)
tape = read(raw)
assert tape["coreSHA256"] == sha(image/"Lokad.Lython.dll")
summary = []
for case in tape["rows"]:
    bodies = case["codes"]
    metrics = {name:sum(body[name] for body in bodies) for name in (
        "instructions","exceptionRegions","dictionaryProbes","loopProbes","closureProbes","minimumRegionVisits","maximumRegionVisits")}
    assert metrics["minimumRegionVisits"] <= metrics["maximumRegionVisits"]
    summary.append(dict(case=case["id"],**metrics))
    print(case["id"], metrics)
(lab/"actual-sites-summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8",newline="\n")
