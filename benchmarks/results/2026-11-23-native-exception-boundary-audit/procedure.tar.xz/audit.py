from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
donor = lab.parent / "closure-result-consumer-20261123/candidate"
source = lab.parent / "complete-native-closed-entry-20261123"
dotnet = Path.home() / ".dotnet11/dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
read = lambda path: json.loads(path.read_text(encoding="utf-8"))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
write = lambda path, value: path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n",
                                         encoding="utf-8", newline="\n")
files = read(source / "comparison/identity.json")["imageFiles"]["reference"]
image = lab / "reference"
image.mkdir(exist_ok=True)
for name, digest in files.items():
    old = source / "reference" / name
    assert sha(old) == digest
    shutil.copyfile(old, image / name)
for name in ("Inspect.dll", "Inspect.deps.json", "Inspect.runtimeconfig.json"):
    shutil.copyfile(donor / name, image / name)

catalog = read(source / "comparison/representative.json")
cases = [dict(id="protected.dict-update." + str(n), source=(
    "def report(key):\n    counts = {}\n"
    + ("    try:\n        counts[key] = counts.get(key, 0) + 1\n    except ValueError:\n        pass\n") * n
    + "\n    return counts\nprint(report('valid'))\n"))
    for n in (8, 32, 128)]
cases.extend(dict(id=row["id"], source=row["source"]) for row in catalog["cases"])
write(lab / "audit-cases.json", {"cases": cases})
subprocess.run([dotnet, image / "Inspect.dll", lab / "audit-cases.json", lab / "audit-tape.json"],
               env=env, timeout=35, check=True)
tape = read(lab / "audit-tape.json")
assert tape["coreSHA256"] == files["Lokad.Lython.dll"]
summary = []
for case in tape["rows"]:
    counts = [dict(name=body["name"], instructions=body["instructions"], regions=len(body["regions"]),
                   calls=len(body["calls"]), native=body["native"])
              for body in case["codes"]]
    summary.append(dict(case=case["id"], bodies=counts))
    print(case["id"], counts[:3])
write(lab / "audit-summary.json", summary)
