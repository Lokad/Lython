from pathlib import Path
import hashlib, json, subprocess
lab=Path(__file__).resolve().parent
repo=lab.parents[3]
results=repo/'benchmarks/results'
root='/home/lokad/lython-bench-checks'
host='lokad@20.166.121.73'
common=['-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes','-o','ConnectTimeout=12']
scp=['C:/Windows/System32/OpenSSH/scp.exe',*common]
ssh=['C:/Windows/System32/OpenSSH/ssh.exe',*common,host,'python3 -']
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))

def proof(run, role, digest, folder, archive, receipt, joined, persisted):
    folder=results/folder
    path=folder/archive
    recorded=read(folder/receipt)
    if receipt=='terminal-status.json': recorded=recorded['receipt']
    assert recorded[joined] and recorded[persisted]
    assert sha(path.read_bytes())==recorded['archiveSHA256']
    assert sha(subprocess.check_output(['git','show','origin/master:'+path.relative_to(repo).as_posix()],cwd=repo))==recorded['archiveSHA256']
    return dict(run=run,role=role,core=digest,receipt=receipt,joined=joined,persisted=persisted,
                archive=recorded['archiveSHA256'])

recent='2026-11-24-callable-singleton-defaults/isolated'
roles=read(results/recent/'identity.json')['imageFiles']['candidate']
recent_image=lab.with_name('callable-singleton-defaults-isolated-20261124')/'candidate'
assert len(roles)==32 and {p.name:sha(p.read_bytes()) for p in recent_image.iterdir()}==roles
specs=[proof('callable-singleton-defaults-isolated-b1611-20261124','candidate',roles['Lokad.Lython.dll'],recent,
             'observations.tar.xz','terminal-status.json','allWorkersJoined','archivedAndVerifiedUnderLease')]
specs.append(proof('integer-parsing-b399-20261107','reference',read(results/'2026-11-07-integer-parsing/identity.json')['coreSHA256']['reference'],
    '2026-11-07-integer-parsing/b399','observations.tgz','archive-receipt.json','allWorkersJoined','archivedAndVerifiedUnderLease'))
specs.append(proof('json-input-storage-b411-20261107','reference',read(results/'2026-11-07-json-input-windows/baseline.json')['cores']['net11.0'],
    '2026-11-07-json-input-windows/b411','failed-observations.tgz','failure-receipt.json','allUsersEnded','archivedAndVerifiedUnderMaintenanceLease'))
for spec in specs[1:]:
    path=lab/(spec['run']+'-core.dll')
    if not path.is_file(): subprocess.run(scp+[f"{host}:{root}/{spec['run']}/{spec['role']}/Lokad.Lython.dll",path],timeout=38,check=True)
    assert sha(path.read_bytes())==spec['core']
specs[0]['receipt']='archive-receipt.json'
code='specs='+repr(specs)+'\n'+'''
from pathlib import Path
import fcntl, hashlib, json, lzma, os, shutil, stat, subprocess
base=Path('/home/lokad/lython-bench-checks').resolve()
sha=lambda data:hashlib.sha256(data).hexdigest()
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 print(json.dumps(dict(freeBefore=shutil.disk_usage(base).free)),flush=True)
 for item in specs:
  if shutil.disk_usage(base).free>=16000000: break
  run=base/item['run']
  assert run.resolve()==run and run.parent==base
  assert not (run/'guest-fixtures').exists() and subprocess.run(['pgrep','-af',str(run)],capture_output=True).returncode==1
  receipt=json.loads((run/item['receipt']).read_text())
  assert receipt[item['joined']] and receipt[item['persisted']] and receipt['archiveSHA256']==item['archive']
  core=run/item['role']/'Lokad.Lython.dll'
  assert core.resolve()==core and stat.S_ISREG(core.lstat().st_mode) and core.stat().st_nlink==1
  data=core.read_bytes()
  assert sha(data)==item['core']
  encoded=lzma.compress(data,preset=3)
  assert shutil.disk_usage(base).free>=len(encoded)+1048576
  stored=run/(item['role']+'-core.dll.xz')
  with stored.open('xb') as package:
   package.write(encoded)
   package.flush()
   os.fsync(package.fileno())
  assert lzma.decompress(stored.read_bytes())==data
  core.unlink()
  print(json.dumps(dict(coreSHA256=item['core'],archiveSHA256=item['archive'],compressedSHA256=sha(encoded),
      stored=str(stored.relative_to(base)),freeAfter=shutil.disk_usage(base).free)),flush=True)
 assert shutil.disk_usage(base).free>=15400000
'''
result=subprocess.run(ssh,input=code.encode('utf-8'),capture_output=True,timeout=65)
(lab/'compaction.jsonl').write_bytes(result.stdout)
print(result.stdout.decode(),end='')
if result.returncode:print(result.stderr.decode(),end='')
result.check_returncode()
