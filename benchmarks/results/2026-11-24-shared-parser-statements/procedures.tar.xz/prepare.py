from pathlib import Path
import hashlib,json,os,shutil,subprocess
lab=Path(__file__).resolve().parent
base=lab.parent
repo=lab.parents[3]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,obj:p.write_text(json.dumps(obj,indent=2)+'\n',encoding='utf-8',newline='\n')
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
python=Path('C:/Python313/python.exe')
donor=base/'closed-line-helper-20261124'
reference_files=read(donor/'comparison/identity.json')['imageFiles']['candidate']
reference_image=donor/'candidate'
assert len(reference_files)==32 and {p.name:sha(p) for p in reference_image.iterdir()}==reference_files
roots=base/'syntax-function-roots-20261124'
core='Lokad.Lython.dll'
cores={'reference':roots/'reference-windows.dll',
       'candidate':base/'callable-pair-rollback-20261124/windows/bin/Lokad.Lython/release_net11.0'/core}
assert sha(cores['reference'])!=sha(cores['candidate'])
roles={}
for role,role_core in cores.items():
    folder=lab/role
    folder.mkdir(exist_ok=True)
    expected=reference_files|{core:sha(role_core)}
    for name in expected:shutil.copyfile(role_core if name==core else reference_image/name,folder/name)
    assert {p.name:sha(p) for p in folder.iterdir()}==expected
    roles[role]=expected
catalog_data=read(roots/'catalog.json')
selected={'scripts.config-manifest.small','scripts.config-edit.small','scripts.config-generated-guards.medium.bad-0.sparse-lexical'}
catalog=lab/'catalog.json'
write(catalog,catalog_data|{'cases':[item for item in catalog_data['cases'] if item['id'] in selected]})
patch=subprocess.check_output(['git','diff','--binary','--','src','tests'],cwd=repo)
(lab/'candidate.patch').write_bytes(patch)
write(lab/'identity.json',dict(reference=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
    sourcePatchSHA256=sha(lab/'candidate.patch'), catalogSHA256=sha(catalog),imageFiles=roles,pythonSHA256=sha(python),
    pythonWorkerSHA256=sha(repo/'benchmarks/cpython-worker.py')))
common=['--catalog',catalog,'--dotnet',dotnet,'--python',python,'--python-worker',repo/'benchmarks/cpython-worker.py']
for role,expected in roles.items():
    output=lab/f'{role}-verify.json'
    subprocess.run([dotnet,lab/role/'Lokad.Lython.Benchmarks.dll','--compare','verify',*common,'--out',output],
        env=env,cwd=repo,check=True,timeout=60)
    proof=read(output)
    assert proof['state']=='Completed' and proof['caseCount']==len(selected) and proof['catalogSha256']==sha(catalog)
    assert proof['launched']['library']['sha256']==expected[core]
print('Verified three complete CPython goldens on both exact 32-file images.',flush=True)
source_inspect=base/'demanded-jump-targets-20261122/reference/inspect'
inspection_cases=read(base/'demanded-jump-targets-20261122/inspect-catalog.json')['cases']
inspection_cases += [dict(id=case['id'],source=case['source']) for case in catalog_data['cases'] if case['id'] in selected]
inspection_cases += [dict(id='joined-multiline-suite',source="def f():\r\n\ta = (\r\n\t    1\r\n\t); b = '''x\r\nY'''\r\n\treturn a,b\r\nprint(f())\r\n")]
write(lab/'inspect-catalog.json',{'cases':inspection_cases})
reports=[]
for role,role_core in cores.items():
    directory=lab/f'{role}-inspect'
    directory.mkdir(exist_ok=True)
    for path in source_inspect.iterdir():
        if path.is_file():shutil.copyfile(role_core if path.name==core else path,directory/path.name)
    assert {p.name:sha(p) for p in directory.iterdir()}=={p.name:sha(role_core if p.name==core else p) for p in source_inspect.iterdir() if p.is_file()}
    output=lab/f'{role}-inspection.json'
    subprocess.run([dotnet,directory/'Inspect.dll',lab/'inspect-catalog.json',output],env=env,check=True,timeout=45)
    proof=read(output)
    assert proof['coreSHA256']==sha(role_core)
    reports.append(proof['rows'])
assert reports[0]==reports[1]
print('Matched final code',len(reports[0]),'sources,',sum(len(c['codes']) for c in reports[0]),'code objects.',flush=True)
