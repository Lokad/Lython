#!/bin/sh
set -eu
cd /mnt/d/code/Lython
export DOTNET_ROOT="$HOME/.dotnet" PATH="$HOME/.dotnet:$PATH"
lab=.git/agent-notes/review-20261031/shared-parser-statements-20261124
assets=.git/agent-notes/review-20261031/callable-pair-rollback-20261124/ubuntu
white='Category!=Stress&(FullyQualifiedName~Parser|FullyQualifiedName~Syntax|FullyQualifiedName~Tokeniz|FullyQualifiedName~SourceSpan|FullyQualifiedName~ManagedStack)'
public='Category!=Stress&(FullyQualifiedName~StatementSeparation|FullyQualifiedName~Syntax|FullyQualifiedName~Indentation|FullyQualifiedName~Diagnostic|FullyQualifiedName~FormattedString|FullyQualifiedName~Stack|FullyQualifiedName~CompilationMemory|FullyQualifiedName~CompilationCancellation)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net11.0 --artifacts-path "$assets" --nologo --filter "$white" > "$lab/ubuntu-white.log" 2>&1 || { tail -60 "$lab/ubuntu-white.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net11.0 --artifacts-path "$assets" --nologo --filter "$public" > "$lab/ubuntu-public.log" 2>&1 || { tail -60 "$lab/ubuntu-public.log"; exit 1; }
awk '/Passed!/{n++;print} END{exit n!=2}' "$lab/ubuntu-white.log" "$lab/ubuntu-public.log"
