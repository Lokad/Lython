from pathlib import Path
import hashlib,json,os,subprocess
lab=Path(__file__).resolve().parent
repo=lab.parents[3]
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
evidence=read(lab/'identity.json')
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
runner='Lokad.Lython.Benchmarks.dll'
for role,files in evidence['imageFiles'].items():
    assert len(files)==32 and {p.name:sha(p) for p in (lab/role).iterdir()}==files
assert sha(lab/'catalog.json')==evidence['catalogSHA256']
assert sha(repo/'benchmarks/cpython-worker.py')==evidence['pythonWorkerSHA256']
python=Path('C:/Python313/python.exe')
assert sha(python)==evidence['pythonSHA256']
cases={'validator':'scripts.config-generated-guards.medium.bad-0.sparse-lexical','manifest':'scripts.config-manifest.small','edit':'scripts.config-edit.small'}
jobs=[('validator','compile','reference'), ('validator','compile','candidate'), ('manifest','compile','candidate'),
      ('validator','compile-run','candidate'),('manifest','compile-run','candidate'),('edit','compile','candidate')]
for case,lane,role in jobs:
    name=f'micro-{case}-{lane}-{role}'
    output=lab/(name+'.json')
    assert not output.exists()
    args=['--catalog',lab/'catalog.json','--dotnet',dotnet,'--baseline-worker',lab/'reference'/runner,
          '--python',python,'--python-worker',repo/'benchmarks/cpython-worker.py','--out',output,
          '--case',cases[case],'--lane',lane]
    run=subprocess.run([dotnet,lab/role/runner,'--compare','micro',*args],env=env,cwd=repo,capture_output=True,
        text=True,encoding='utf-8',timeout=44)
    (lab/(name+'.log')).write_text(run.stdout+run.stderr,encoding='utf-8',newline='\n')
    print(name,run.returncode,run.stdout,run.stderr,flush=True)
    assert output.exists()
