using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;

using var catalog = JsonDocument.Parse(File.ReadAllBytes(args[0]));
var engine = new LythonEngine();
var rows = new List<object>();
foreach (var item in catalog.RootElement.EnumerateArray())
{
    var options = new LythonMemoryBudget();
    var source = item.GetString()!;
    using (var compiled = engine.Compile(source, options))
        rows.Add(new { compiled.IsValid, compiled.Diagnostics });
    if (options.ReservedBytes != 0) throw new InvalidOperationException("Compilation retained allowance.");
}
var core = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location)));
File.WriteAllText(args[1], JsonSerializer.Serialize(new { core, rows }, new JsonSerializerOptions { WriteIndented = true }));
