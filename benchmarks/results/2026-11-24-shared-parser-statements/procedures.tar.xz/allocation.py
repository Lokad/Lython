from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess
lab=Path(__file__).resolve().parent
base=lab.parent
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
core='Lokad.Lython.dll'
identity=read(lab/'identity.json')
helper=base/'prepared-closed-defaults-20261124/compiler-owner/reference'
results=[]
for role,assets in identity['imageFiles'].items():
    core_file=lab/role/core
    assert sha(core_file)==assets[core]
    folder=lab/f'{role}-allocation'
    folder.mkdir(exist_ok=True)
    for p in helper.iterdir():
        if p.is_file():shutil.copyfile(core_file if p.name==core else p,folder/p.name)
    output=lab/f'{role}-allocation.json'
    subprocess.run([sdk/'dotnet.exe',folder/'Inspect.dll',lab/'catalog.json',output],env=env,check=True,timeout=25)
    data=read(output)
    assert data['coreSHA256']==assets[core]
    results.append(data['rows'])
rows=[]
for a,b in zip(*results,strict=True):
    assert a['id']==b['id']
    row=dict(case=a['id'],allocationBytes=[statistics.median(item['allocatedBytes']) for item in (a,b)],
        retainedAdmission=[a['retainedAdmission'],b['retainedAdmission']])
    rows.append(row)
    print(row)
(lab/'allocation-summary.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
