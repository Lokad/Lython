from pathlib import Path
import hashlib,json,shutil,tarfile
lab=Path(__file__).resolve().parent
base=lab.parent
old=base/'callable-singleton-defaults-isolated-20261124'
donor=base/'closed-line-helper-20261124'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
save=lambda p,o:write(p,json.dumps(o,indent=2)+'\n')
comparison=lab/'comparison'
quiet=comparison/'quiet'
quiet.mkdir(parents=True,exist_ok=True)
shutil.copyfile(lab/'catalog.json',comparison/'representative.json')
selected=('scripts.config-manifest.small','scripts.config-generated-guards.medium.bad-0.sparse-lexical','scripts.config-edit.small')
jobs=[(selected[0],'compile'),(selected[1],'compile'),(selected[2],'compile'),(selected[0],'compile-run'),(selected[1],'compile-run')]
save(comparison/'jobs.json',{'warm':jobs})
local=read(lab/'identity.json')
old_id=read(old/'comparison/identity.json')
identity=dict(sourceRevision=local['reference'],candidate=local['sourcePatchSHA256'],
    purpose='Shared statement reader and source-span boundary check',imageFiles=local['imageFiles'],
    coreSHA256={alias:local['imageFiles'][role]['Lokad.Lython.dll'] for role in local['imageFiles'] for alias in (role,role+'-control')},
    catalogs={name:dict(sha256=digest(comparison/name)) for name in ('representative.json','jobs.json')},
    expectedCPythonSHA256=old_id['expectedCPythonSHA256'],cpythonWorkerSHA256=local['pythonWorkerSHA256'])
for role,files in identity['imageFiles'].items():
    assert len(files)==32 and {p.name:digest(p) for p in (lab/role).iterdir()}==files
    goldens=read(lab/(role+'-verify.json'))
    assert goldens['caseCount']==3 and goldens['state']=='Completed' and goldens['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert goldens['launched']['library']['sha256']==files['Lokad.Lython.dll']
save(comparison/'identity.json',identity)
collect=(old/'comparison/quiet/collect.py').read_text(encoding='utf-8')
collect=collect.replace('len(jobs) == 7','len(jobs) == 5').replace('b1611-fixtures','b1612-fixtures')
compile(collect,'collect.py','exec')
write(quiet/'collect.py',collect)
shutil.copyfile(old/'comparison/quiet/run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=3) as archive:
    for path in ('identity.json','representative.json','jobs.json'):
        archive.add(comparison/path,arcname=path,recursive=False)
    for path in ('collect.py','run.sh'):
        archive.add(quiet/path,arcname=path,recursive=False)
    for role in identity['imageFiles']:
        archive.add(lab/role/'Lokad.Lython.dll',arcname=role+'-core.dll',recursive=False)
save(quiet/'upload.json',dict(root='shared-parser-statements-b1612-20261124',reference='closed-line-helper-b1608-20261124',
                           payloadSHA256=digest(payload),payloadBytes=payload.stat().st_size))
save(lab/'verified-raw-replicas.json',[])
launcher=(old/'quiet.py').read_text(encoding='utf-8')
launcher=launcher.replace('lython-b1611-callable-singleton-defaults-isolated-', 'lython-b1612-shared-parser-statements-')
launcher=launcher.replace('b1611-', 'b1612-').replace('seconds=354','seconds=260').replace('RuntimeMaxSec=425','RuntimeMaxSec=310')
launcher=launcher.replace("'collect.py','candidate-core.dll'", "'collect.py','candidate-core.dll','reference-core.dll'")
launcher=launcher.replace("if name=='Lokad.Lython.dll' and role=='candidate':","if name=='Lokad.Lython.dll':")
launcher=launcher.replace('needs one core, receipts and working room','needs two cores, receipts and working room')
compile(launcher,'quiet.py','exec')
write(lab/'quiet.py',launcher)
summarize=(old/'summarize.py').read_text(encoding='utf-8')
summarize=summarize.replace('receipt["warmJobs"] == 7','receipt["warmJobs"] == 5').replace('timedBatches=196','timedBatches=140')
compile(summarize,'summarize.py','exec')
write(lab/'summarize.py',summarize)
print('Prepared five short quiet lanes and verified both frozen images.',flush=True)
