from pathlib import Path
import hashlib,json,os,shutil,subprocess
lab=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=read(lab/'identity.json')
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
variants=[]
for sep in (' ', '; ', '\n', ' \\\n'):
    variants += ["message = '''one\ntwo'''"+sep+'other = 2\n',
                 'values = (\n 1,\n 2\n)'+sep+'other = 2\n',
                 'def an_inner():\n    return 1\n'+sep+'other = 2\n',
                 'import json as j, math'+sep+'print(j.dumps(1))\n']
    for indent in ('\t','    '):
        variants += ['def f():\n'+indent+'left = (\n'+indent+'  1\n'+indent+')'+sep.replace('\n','\n'+indent)+'right = 2\n']
variants += ['a=1\n\tb=2\n', 'def f():\n    a=1 b=2\nprint(1)\n', 'a=1\n\nf"{a=}"; b=2\n',
             'if True:\n    match 1:\n        case 1: print(1)print(2)\nprint(3)\n',
             'if True:\n    @print\n    def f(): pass\nprint(3)\n',
             'if True:\n    try:\n        pass\n    except ValueError: pass\nelse:\n    pass\nprint(5)\n']
variants += [''.join(' '*i+'if True:\n' for i in range(depth))+' '*depth+'pass\nprint(1)\n' for depth in (4,32,63,64,65,80)]
cases=[text.replace('\n',end) for text in variants for end in ('\n','\r\n','\r')]
(lab/'diagnostic-input.json').write_text(json.dumps(cases)+'\n',encoding='utf-8',newline='\n')
reports=[]
for role,files in identity['imageFiles'].items():
    frozen=lab/role/'Lokad.Lython.dll'
    assert sha(frozen)==files[frozen.name]
    folder=lab/f'{role}-diagnostics'
    folder.mkdir(exist_ok=True)
    for p in (lab/'diagnostics/bin/Release/net11.0').iterdir():
        if p.is_file() and p.suffix!='.pdb':shutil.copyfile(frozen if p.name==frozen.name else p,folder/p.name)
    output=lab/f'{role}-diagnostics.json'
    subprocess.run([sdk/'dotnet.exe',folder/'Inspect.dll',lab/'diagnostic-input.json',output],env=env,check=True,timeout=25)
    result=read(output)
    assert result['core']==files[frozen.name]
    reports.append(result['rows'])
assert reports[0]==reports[1],[(i,a,b) for i,(a,b) in enumerate(zip(*reports,strict=True)) if a!=b]
print(f'{len(cases)} exact diagnostic comparisons, {sum(row["IsValid"] for row in reports[0])} valid, all owners refund.')
