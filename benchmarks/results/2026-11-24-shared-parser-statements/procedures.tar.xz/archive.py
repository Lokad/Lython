from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/'comparison/quiet'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda data:hashlib.sha256(data).hexdigest()
filehash=lambda p:sha(p.read_bytes())
terminal=read(quiet/'terminal-status.json')
receipt=terminal['receipt']
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode']=='0'
assert receipt['warmJobs']==5 and all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert receipt['archiveSHA256']==filehash(quiet/'observations.tar.xz')
local=read(lab/'identity.json')
identity=read(lab/'comparison/identity.json')
summary=read(quiet/'summary.json')
assert identity['candidate']==local['sourcePatchSHA256']==filehash(lab/'candidate.patch')==summary['candidate']
assert identity['sourceRevision']==local['reference']==summary['source']
assert len(summary['rows'])==5 and summary['timedBatches']==140
for role,paths in identity['imageFiles'].items():
    assert len(paths)==32 and {p.name:filehash(p) for p in (lab/role).iterdir()}==paths
    verification=read(lab/f'{role}-verify.json')
    assert verification['caseCount']==3 and verification['state']=='Completed'
    assert verification['launched']['library']['sha256']==paths['Lokad.Lython.dll']
    assert read(lab/f'{role}-diagnostics.json')['core']==paths['Lokad.Lython.dll']
    assert read(lab/f'{role}-inspection.json')['coreSHA256']==paths['Lokad.Lython.dll']
for group,key,n in (('diagnostics','rows',108),('inspection','rows',16)):
    a,b=[read(lab/f'{role}-{group}.json')[key] for role in ('reference','candidate')]
    assert len(a)==n and a==b
for os in ('windows','ubuntu'):
    assert 'Passed:    54' in (lab/f'{os}-white.log').read_text(encoding='utf-8-sig')
    assert 'Passed:   890' in (lab/f'{os}-public.log').read_text(encoding='utf-8-sig')
all_micro=list(lab.glob('micro-*.json'))
assert len(all_micro)==6
out=repo/'benchmarks/results/2026-11-24-shared-parser-statements'
out.mkdir(exist_ok=True)
for f in ('observations.tar.xz','terminal-status.json','summary.json','storage-custody.json'):
    shutil.copyfile(quiet/f,out/f)
shutil.copyfile(lab/'comparison/identity.json',out/'identity.json')
shutil.copyfile(lab/'compaction.jsonl',out/'compaction.jsonl')
shutil.copyfile(lab/'allocation-summary.json',out/'allocation-summary.json')
probes=['prepare.py','prepare-quiet.py','quiet.py','summarize.py','archive.py','compact.py','compaction.jsonl','compact.log','test-ubuntu.sh',
        'diagnostics.py','diagnostics/Program.cs','diagnostics/Inspect.csproj','diagnostic-build.log','diagnostic-input.json','inspect-catalog.json',
        'candidate.patch','identity.json','catalog.json','micro.py','allocation.py',
        'comparison/representative.json','comparison/jobs.json','comparison/quiet/collect.py','comparison/quiet/run.sh','comparison/quiet/launch.log']
for role in ('reference','candidate'):
    probes += [f'{role}-{name}.json' for name in ('diagnostics','inspection','verify','allocation')]
for os in ('windows','ubuntu'):
    probes += [f'{os}-{s}.log' for s in ('white','public')]
for raw in sorted(all_micro):probes += [raw.name,raw.with_suffix('.log').name]
roots=lab.with_name('syntax-function-roots-20261124')
prior=('candidate.patch','check-compile-allocation.py','local-summary.json','discovery-count.json','windows-public.log',
       'ubuntu-public.log','windows-public-corrected.log','ubuntu-public-corrected.log')
tar_members={p:lab/p for p in probes}|{'binding-roots/'+p:roots/p for p in prior}
with tarfile.open(out/'procedures.tar.xz','w:xz') as archive:
    for name,file in tar_members.items():archive.add(file,arcname=name,recursive=False)
with tarfile.open(out/'procedures.tar.xz') as archive:
    assert {m.name:sha(archive.extractfile(m).read()) for m in archive}=={name:filehash(file) for name,file in tar_members.items()}
print('Archived both exact parser comparisons, 140 attested quiet batches and the withdrawn declaration-discovery candidate.')
