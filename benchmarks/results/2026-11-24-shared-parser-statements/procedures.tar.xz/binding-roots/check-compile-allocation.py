from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess
lab=Path(__file__).resolve().parent
base=lab.parent
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
core_name='Lokad.Lython.dll'
candidate=base/'callable-pair-rollback-20261124/windows/bin/Lokad.Lython/release_net11.0'/core_name
patch=subprocess.check_output(['git','diff','--binary','--','src','tests'])
(lab/'candidate.patch').write_bytes(patch)
manifest=read(base/'current-cold-compiler-attribution/catalog.json')
controls=read(base/'abstract-state-snapshots-20261123/comparison/representative.json')
ids=('scripts.config-manifest.small','scripts.config-edit.small','scripts.config-generated-guards.medium.bad-0.sparse-lexical',
     'scripts.dataclass-inherited-configuration.generated','scripts.annotated-rule-closures.nested-factories.postponed','diagnostic.dead-heavy-validator')
catalog=manifest|{'cases':[next(c for c in manifest['cases']+controls['cases'] if c['id']==id) for id in ids]}
(lab/'catalog.json').write_text(json.dumps(catalog)+'\n',encoding='utf-8',newline='\n')
helper=base/'prepared-closed-defaults-20261124/compiler-owner/reference'
assets={p.name:sha(p) for p in helper.iterdir() if p.is_file() and p.name!=core_name}
roles={'reference':lab/'reference-windows.dll','candidate':candidate}
images={}
for label,core in roles.items():
    target=lab/label
    target.mkdir(exist_ok=True)
    for name in assets:
        shutil.copyfile(helper/name,target/name)
    shutil.copyfile(core,target/core_name)
    images[label]=actual={p.name:sha(p) for p in target.iterdir()}
    assert actual==assets|{core_name:sha(core)}
assert images['reference'][core_name]!=images['candidate'][core_name]
results={}
for role in roles:
    output=lab/f'{role}-compile-allocation.json'
    subprocess.run([sdk/'dotnet.exe',lab/role/'Inspect.dll',lab/'catalog.json',output],env=env,check=True,timeout=40)
    results[role]=read(output)
    assert results[role]['coreSHA256']==images[role][core_name]
rows=[]
for a,b in zip(*(result['rows'] for result in results.values()),strict=True):
    assert a['id']==b['id']
    allocated=[statistics.median(row['allocatedBytes']) for row in (a,b)]
    row=dict(case=a['id'],allocationBytes=allocated,retainedAdmission=[a['retainedAdmission'],b['retainedAdmission']])
    print(row)
    rows.append(row)
(lab/'local-summary.json').write_text(json.dumps(dict(images=images,patchSha=sha(lab/'candidate.patch'),rows=rows),indent=2)+'\n',encoding='utf-8',newline='\n')
