from pathlib import Path
import hashlib,json,shutil,subprocess
root=Path('D:/code/Lython');home=Path(__file__).parent
baseline=json.loads((home.parent/'small-integers-r176/baseline.json').read_text(encoding='utf-8'))
changed=subprocess.check_output(['git','diff','--name-only','--','src/Lokad.Lython'],text=True).splitlines()
assert set(changed)=={'src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeReturn.cs','src/Lokad.Lython/Runtime/PyExecutableFunction.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.Calls.cs'}
for name in changed:
    rel=Path(name).relative_to('src/Lokad.Lython'); origin=home.parent/'small-integers-r176/before-source'/rel
    assert hashlib.sha256(origin.read_bytes()).hexdigest()==baseline['productionSources'][(root/name).as_posix()]
    dst=home/'before-source'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(origin,dst)
shutil.copytree(home.parent/'text-cache-storage-r173/refined/images/candidate',home/'images/before')
shutil.copyfile(home.parent/'call-inputs-r175/catalog.json',home/'catalog.json')
(home/'baseline.json').write_text(json.dumps(dict(revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    productionSources=baseline['productionSources'],changedFiles=changed,
    deletion='One TryExecuteNativeReturn post-frame entry plus three probes,23lines. Keep primary unframed native proof/evaluator unchanged.',
    tradeoff='Contexts excluded by unframed proof use the existing ordinary executable engine after frame creation. No public/API/host policy change; measure active-handler helper scripts and retain source/exception/ownership semantics.',
    acceptance=['class and annotation scopes','active exception context','ordinary/async functions','binding/defaults/closures','source diagnostics','real host suspension','terminal refusal and cleanup']),indent=2)+'\n',encoding='utf-8')
print('Three-file deletion baseline and primary native path protected; existing catalog/worker reused.')
