from pathlib import Path
import hashlib,json,subprocess
home=Path(__file__).parent;dest=home/'b521';old=home.parent/'call-inputs-r175/refined/b520'
required=json.loads((dest/'payload-sizing.json').read_text(encoding='utf-8'))['requiredFreeBytes']+256*1024
spec=[]
for remote,local in [
 ('call-inputs-b519-20261109','2026-11-09-call-input-preparation/original-observations.tgz'),
 ('call-inputs-b520-20261109','2026-11-09-call-input-preparation/refined-observations.tgz'),
 ('record-fields-b478-20261108','2026-11-08-record-field-resolution/observations.tgz'),
 ('compile-phase-b488-20261109','2026-11-09-compile-phase/observations.tgz')]:
    p=Path('benchmarks/results')/local
    assert subprocess.check_output(['git','ls-files','--',p.as_posix()],text=True).strip()==p.as_posix()
    spec.append(dict(path='/home/lokad/lython-bench-checks/'+remote+'/observations.tgz',sha256=hashlib.sha256(p.read_bytes()).hexdigest(),size=p.stat().st_size,preservedLocal=p.resolve().as_posix(),tracked=True))
script=(home.parent/'text-cache-storage-r173/b518/space-recovery-command.py').read_text(encoding='utf-8')
script=script.replace('string-index-storage-b518','bound-native-entry-b521').replace('20261109','20261110').replace('276512768',str(required))
script='\n'.join('spec='+repr(spec) if line.startswith('spec=') else line for line in script.splitlines())+'\n'
script=script.replace("receipt=json.loads((p.parent/'archive-receipt.json').read_text());assert", "receipt=json.loads((p.parent/'archive-receipt.json').read_text());receipt=receipt.get('receipt',receipt);assert")
script=script.replace("assert plan['afterFreeBytes']>free and", "assert plan['afterFreeBytes']>"+str(required)+" and plan['afterFreeBytes']>free and")
(dest/'space-recovery-command.py').write_text(script,encoding='utf-8',newline='\n')
text=(old/'recover-space.py').read_text(encoding='utf-8');start=text.index('required=');end=text.index("ssh=[",start)
text=text[:start]+"script=(home/'space-recovery-command.py').read_text(encoding='utf-8')\n"+text[end:]
(dest/'recover-space.py').write_text(text,encoding='utf-8',newline='\n')
text=(old/'launch.py').read_text(encoding='utf-8').replace("home.parent.parent.parent/'text-cache-storage-r173", "home.parent.parent/'text-cache-storage-r173")
text=text.replace('call-inputs-b520-20261109','bound-native-entry-b521-20261110').replace('lython-b520-call-inputs','lython-b521-bound-native-entry').replace('lython-b520-fixtures','lython-b521-fixtures').replace('call-inputs-b520-launch','bound-native-entry-b521-launch')
text=text.replace("compile(script,'b520-launch','exec')", "script=script.replace('lython-b521-bound-native-entry-20261109','lython-b521-bound-native-entry-20261110')\ncompile(script,'b521-launch','exec')")
text=text.replace('New B519 owner','New B521 owner')
(dest/'launch.py').write_text(text,encoding='utf-8',newline='\n')
text=(old/'retrieve.py').read_text(encoding='utf-8').replace('call-inputs-b520-20261109','bound-native-entry-b521-20261110').replace('lython-b520-call-inputs-20261109','lython-b521-bound-native-entry-20261110').replace('B519','B521')
(dest/'retrieve.py').write_text(text,encoding='utf-8',newline='\n')
(dest/'summarize.py').write_text((old/'summarize.py').read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
print('Exact four known-copy candidates only; fresh sufficient space skips mutation; extra256KiB funds setup metadata, existing floors unchanged. No remote action yet.')
