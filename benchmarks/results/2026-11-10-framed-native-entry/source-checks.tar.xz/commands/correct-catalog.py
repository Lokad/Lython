from pathlib import Path
import hashlib,json,shutil,subprocess,sys
root=Path('D:/code/Lython');home=Path(__file__).parent
old=json.loads((home/'catalog-affected.json').read_text(encoding='utf-8')); assert len(old['cases'])==6
original=json.loads((home/'catalog.json').read_text(encoding='utf-8'))
affected=next(row for row in old['cases'] if row['id'].endswith('.active-handler'))
affected['id']='scripts.text-summary-helpers.large'
original['cases']=[affected if row['id']==affected['id'] else row for row in original['cases']]
original['performanceQualified']=False
assert len(original['cases'])==5
(home/'catalog-corrected.json').write_text(json.dumps(original,ensure_ascii=False)+'\n',encoding='utf-8')
(home/'rejected-attempt.json').write_text(json.dumps(dict(reason='Existing driver requires exactly one text case plus four maintained controls. Six-case catalog rejected before measurements/worker creation.',
    evidence=['catalog-affected.json','identity.json','warm-sync/stderr.txt','warm-sync/measurements.json'],
    correction='Replace only canonical text source with active-handler variant; keep5cases/canonicalIDs, independent unchanged fixture/goldens and explicit new sourceSHA. This is a diagnostic, not the maintained published text row.'),indent=2)+'\n',encoding='utf-8')
current=root/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'
identity=json.loads((home/'identity.json').read_text(encoding='utf-8'))
assert hashlib.sha256(current.read_bytes()).hexdigest()==identity['cores']['candidate']
corrected=home/'corrected';corrected.mkdir()
text=(home/'measure.py').read_text(encoding='utf-8')
start=text.index("shutil.copytree(home / 'images/before'")
end=text.index("assert all(",start)
text=text[:start]+text[end:]
text=text.replace("home / 'images'", "home.parent / 'images'").replace("home / 'images/", "home.parent / 'images/").replace("home/'images/", "home.parent/'images/")
text=text.replace("home/'catalog-affected.json'", "home.parent/'catalog-corrected.json'").replace("home / 'catalog-affected.json'", "home.parent / 'catalog-corrected.json'")
text=text.replace("home.parent/'bulk-whitespace-r157", "home.parent.parent/'bulk-whitespace-r157")
(corrected/'measure.py').write_text(text,encoding='utf-8',newline='\n')
subprocess.run([sys.executable,'-X','utf8',str(corrected/'measure.py')],cwd=root,check=True)
