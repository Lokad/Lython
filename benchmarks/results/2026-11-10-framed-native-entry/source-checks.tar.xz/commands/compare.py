from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,sys,textwrap
root=Path('D:/code/Lython');home=Path(__file__).parent
test=root/'tests/Lokad.Lython.PublicApi.Tests/FramedFunctionExecutionTests.cs'
cases=re.findall(r'\{ "([^"]+)", """\n(.*?)\n\s*""", "((?:[^"\\]|\\.)*)" \}',test.read_text(encoding='utf-8'),re.S)
assert len(cases)==3
references=[]
for name,raw,quoted in cases:
    source=textwrap.dedent(raw); expected=json.loads('"'+quoted+'"')
    wrapped='import json\ndef job():\n'+textwrap.indent(source,'    ')+'\nprint("RESULT:"+json.dumps(job()))\n'
    answer=subprocess.run(['C:/Python313/python.exe','-I','-S','-c',wrapped],capture_output=True,text=True,check=True)
    assert answer.stdout==expected+'RESULT:["retained"]\n',(name,answer.stdout)
    references.append(dict(name=name,source=source,expectedOutput=expected,stdout=answer.stdout))
(home/'reference.json').write_text(json.dumps(dict(python=subprocess.check_output(['C:/Python313/python.exe','--version'],text=True).strip(),
    boundary='Semantic controls only. Wrap guest module return in one function; independently check stdout and returned list.',cases=references),indent=2)+'\n',encoding='utf-8')

original=json.loads((home/'catalog.json').read_text(encoding='utf-8'))
affected=json.loads(json.dumps(next(row for row in original['cases'] if row['id']=='scripts.text-summary-helpers.large')))
source=affected['source']; assert 'from __future__' not in source
affected['id'] += '.active-handler'
affected['source']="try:\n    raise LookupError('active handler')\nexcept LookupError as active_error:\n"+textwrap.indent(source,'    ')
encoded=affected['source'].encode('utf-8'); affected['sourceSha256']=hashlib.sha256(encoded).hexdigest();affected['sourceUtf8Bytes']=len(encoded)
original['cases'].insert(2,affected); original['performanceQualified']=False
(home/'catalog-affected.json').write_text(json.dumps(original,ensure_ascii=False)+'\n',encoding='utf-8')
print('Independent CPython lexical controls pass; add one active-handler version of unchanged text/fixtures/goldens.',flush=True)

env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
jobs=[('internal10',['test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-f','net10.0','--filter',
 '(Category!=Stress)&(FullyQualifiedName~Function|FullyQualifiedName~MethodBody|FullyQualifiedName~OperandRead|FullyQualifiedName~Argument|FullyQualifiedName~ClassCell)']),
 ('public10',['test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-f','net10.0','--filter',
 '(Category!=Stress)&(FullyQualifiedName~FramedFunctionExecutionTests|FullyQualifiedName~NativeReturnFunctionTests|FullyQualifiedName~MethodBodyControlFlowBoundaryTests|FullyQualifiedName~ModuleFunctionSuperBoundaryTests|FullyQualifiedName~AsyncFunctionHostingTests|FullyQualifiedName~CallInputLifetimeTests)']),
 ('freeze11',['build','src/Lokad.Lython/Lokad.Lython.csproj','-f','net11.0','--no-incremental'])]
for name,args in jobs:
    log=home/(name+'.log')
    with log.open('w',encoding='utf-8') as out:
        done=subprocess.run([env['DOTNET_HOST_PATH'],*args,'-c','Release','-v','q'],env=env,cwd=root,stdout=out,stderr=subprocess.STDOUT,timeout=180)
    print(name,'exit',done.returncode,flush=True)
    if done.returncode: print(log.read_text(encoding='utf-8')[-3000:],flush=True);sys.exit(done.returncode)
text=(home.parent/'small-integers-r176/measure.py').read_text(encoding='utf-8')
text=text.replace("home/'catalog.json'","home/'catalog-affected.json'")
text=text.replace("home / 'catalog.json'","home / 'catalog-affected.json'")
text=text.replace("['git', 'diff', '--binary'", "['git', '-c', 'core.safecrlf=false', 'diff', '--binary'")
text=text.replace("purpose='Contract-preserving signed32 guest integer transport; unchanged public BigInteger and CLR ingress contracts.",
    "purpose='Delete post-frame native entry; primary borrowed native entry unchanged. One affected active-handler text variant plus five unchanged scripts.")
(home/'measure.py').write_text(text,encoding='utf-8',newline='\n')
subprocess.run([sys.executable,'-X','utf8',str(home/'measure.py')],cwd=root,env=env,check=True)
