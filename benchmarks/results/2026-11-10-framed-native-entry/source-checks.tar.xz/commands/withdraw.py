from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
root=Path('D:/code/Lython');home=Path(__file__).parent;out=root/'benchmarks/results/2026-11-10-framed-native-entry';out.mkdir()
baseline=json.loads((home/'baseline.json').read_text(encoding='utf-8'));identity=json.loads((home/'corrected/identity.json').read_text(encoding='utf-8'))
for name,sha in identity['productionSources'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==sha,name
for name in ['baseline.json','reference.json','rejected-attempt.json','catalog-affected.json']:
    shutil.copyfile(home/name,out/name)
for name in ['identity.json','desktop.json','source.patch']:
    shutil.copyfile(home/'corrected'/name,out/name)
for lane in ['warm-sync','warm-async','compile-sync']:
    shutil.copytree(home/'corrected'/lane,out/lane)
for name in ['measurements.json','stderr.txt','hash-witness.json']:
    dst=out/'rejected-six-case-catalog'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(home/'warm-sync'/name,dst)
checks=out/'qualification';checks.mkdir()
for p in home.glob('*.log'):shutil.copyfile(p,checks/p.name)
for name in ['observations.tgz','archive-receipt.json','terminal-status.json','space-recovery.json','space-recovery.log','space-recovery-command.py','payload-sizing.json','setup-contract.json','contract.md','pre-measurement-plan.md','identity.json','sizing.json','observe-not-before.json','launch.log','launch-command.py','extraction.json','summary.json']:
    p=home/'b521'/name
    if p.exists():
        dst=out/'quiet'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst)
with tarfile.open(out/'source-checks.tar.xz','w:xz') as tar:
    for name in baseline['changedFiles']:
        rel=Path(name).relative_to('src/Lokad.Lython');tar.add(root/name,arcname='candidate/'+rel.as_posix());tar.add(home/'before-source'/rel,arcname='before/'+rel.as_posix())
    tar.add(root/'tests/Lokad.Lython.PublicApi.Tests/FramedFunctionExecutionTests.cs',arcname='retained-tests/FramedFunctionExecutionTests.cs')
    tar.add(home/'catalog-corrected.json',arcname='representative.json')
    for p in home.glob('*.py'):tar.add(p,arcname='commands/'+p.name)
    for name in ['collect.py','archive-owned.py','run.sh','launch.py','recover-space.py','retrieve.py','summarize.py']:
        tar.add(home/'b521'/name,arcname='commands/b521/'+name)
for name in baseline['changedFiles']:
    original=home/'before-source'/Path(name).relative_to('src/Lokad.Lython');assert hashlib.sha256(original.read_bytes()).hexdigest()==baseline['productionSources'][(root/name).as_posix()]
    (root/name).write_bytes(original.read_bytes())
for name,sha in baseline['productionSources'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==sha,name
(out/'withdrawal.json').write_text(json.dumps(dict(restoredProduction='cac4acf8-equivalent',removedLines=23,affectedFiles=3,retainedPublicCases=3,
    reason='Stable affected-handler CPU cost confirms the post-frame shortcut is useful. Keep it until a broader shared kernel preserves its behavior/performance; not a permanent veto on consolidation.',
    nativePrimaryEntry='Unchanged throughout',fullQualification='Not repeated for withdrawn code. Fresh nonincremental build follows before new source qualification.'),indent=2)+'\n',encoding='utf-8')
print('R177A private deletion fully withdrawn; all raw/adverse evidence and terminal B521 archive preserved. Three public regressions retained.')
