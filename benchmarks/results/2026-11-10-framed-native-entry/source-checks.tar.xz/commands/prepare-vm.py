from pathlib import Path
import hashlib,json,shutil,tarfile
root=Path('D:/code/Lython');home=Path(__file__).parent;old=home.parent/'call-inputs-r175/refined/b520';dest=home/'b521';dest.mkdir()
local=json.loads((home/'corrected/identity.json').read_text(encoding='utf-8'))
for name,digest in local['productionSources'].items(): assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
identity['coreSHA256']={role:local['cores']['before' if role.startswith('reference') else 'candidate'] for role in ['reference','reference-control','candidate','candidate-control']}
identity['sourceRevision']='R177A fcf018d2 plus three-file23line post-frame native-entry deletion; primary borrowed native entry unchanged. R173 baseline production equivalent cac4acf8. Source hashes explicit.'
identity['catalogSHA256']=local['catalogSHA256']
(dest/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
files={'current-core.dll':home/'images/candidate/Lokad.Lython.dll','representative.json':home/'catalog-corrected.json','baseline-source.json':home/'baseline.json','final-source.json':home/'corrected/identity.json','source.patch':home/'corrected/source.patch','FramedFunctionExecutionTests.cs':root/'tests/Lokad.Lython.PublicApi.Tests/FramedFunctionExecutionTests.cs'}
for name in ['LythonRuntime.Executable.Calls.cs','LythonRuntime.Executable.NativeReturn.cs','PyExecutableFunction.cs']:files[name]=root/'src/Lokad.Lython/Runtime'/name
for name,path in files.items():shutil.copyfile(path,dest/name)
for name in ['collect.py','archive-owned.py','run.sh']:
    text=(old/name).read_text(encoding='utf-8').replace('call-inputs-b520-20261109','bound-native-entry-b521-20261110').replace('lython-b520-call-inputs-20261109','lython-b521-bound-native-entry-20261110')
    text=text.replace('R175 ordinary call input source comparison','R177A framed native-entry deletion')
    text=text.replace('R175 ordinary call input preparation; complete CSV/text/report plus adverse Unicode-index control. Text sync/async included. Runtime allocation, compilation debt and elapsed/CPU evidence separate; preserve all adverse controls.',
                      'R177A post-frame native entry deletion; text source wrapped in active handler with original input/goldens, canonical ID required by reused driver; CSV/report/Unicode source controls unchanged. Both text APIs. Not published CPython comparison. Allocation and elapsed/CPU separate; retain adverse observations.')
    text=text.replace("'CallInputLifetimeTests.cs','before-shapes.json','candidate-shapes.json',", "'FramedFunctionExecutionTests.cs','LythonRuntime.Executable.Calls.cs','LythonRuntime.Executable.NativeReturn.cs','PyExecutableFunction.cs',")
    (dest/name).write_text(text,encoding='utf-8',newline='\n')
(dest/'focused.json').write_text(json.dumps(dict(net11Internal=369,net10Internal=369,net11Public=96,net10Public=96,stressExcluded=True),indent=2)+'\n',encoding='utf-8')
for name in ['setup-contract.json','sizing.json']:shutil.copyfile(old/name,dest/name)
contract='''R177A deletion qualification, no CPython or pending-I/O latency claim.
Reuse existing five-job/four-process protocol; two processes/source,5s warmup/role,
seven rotated150ms rounds; ordinary GC/tiering. Affected text source is wrapped in
one active exception handler; same input/stdout/files goldens. CSV/report/Unicode
sources unchanged. SourceSHA/catalogSHA distinguish this from published text cases.
Includes mediated RAM I/O, validation and prior-result cleanup; excludes startup,
reset/protocol/final caches. Process CPU is wider. Compilation measured separately.
Finite210s owner/30s stop/30s margin, join/RAM-unmount/archive/localSHA; no10min lane.
'''
for name in ['contract.md','pre-measurement-plan.md']:(dest/name).write_text(contract,encoding='utf-8',newline='\n')
with tarfile.open(dest/'payload.tgz','w:gz') as tar:
    for p in sorted(dest.iterdir()):
        if p.is_file() and p.name!='payload.tgz':tar.add(p,arcname=p.name)
with tarfile.open(dest/'payload.tgz') as tar:needed=sum(((p.size+4095)//4096)*4096 for p in tar.getmembers())+252*1024*1024+65536
(dest/'payload-sizing.json').write_text(json.dumps(dict(requiredFreeBytes=needed,payloadBytes=(dest/'payload.tgz').stat().st_size,persistentBaselineReused=True,extraSetupHeadroomBytes=65536),indent=2)+'\n',encoding='utf-8')
print('Finite5job payload, one core:',needed,'required bytes;', (dest/'payload.tgz').stat().st_size,'compressed bytes.')
