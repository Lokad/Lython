; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:CreateClosedComputedDefinition(Lokad.Lython.Frontend.ExecutableCreateFunction,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,long,System.Object):Lokad.Lython.Runtime.PyFunctionBase (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rbp based frame
; fully interruptible
; No PGO data
; 0 inlinees with PGO data; 41 single block inlinees; 7 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbx
       sub      rsp, 280
       lea      rbp, [rsp+0x150]
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rbp-0xD0], ymm4
       vmovdqu  ymmword ptr [rbp-0xB0], ymm4
       vmovdqu  ymmword ptr [rbp-0x90], ymm4
       vmovdqu  ymmword ptr [rbp-0x70], ymm4
       vmovdqa  xmmword ptr [rbp-0x50], xmm4
       xor      eax, eax
       mov      qword ptr [rbp-0x40], rax
       mov      gword ptr [rbp+0x20], r8
       mov      rbx, rcx
       mov      rsi, rdx
       mov      rdi, r9
 
G_M000_IG02:                ;; offset=0x0054
       mov      r14, gword ptr [rsi+0x98]
       xor      rcx, rcx
       mov      gword ptr [rbp-0xE0], rcx
 
G_M000_IG03:                ;; offset=0x0064
       mov      dword ptr [rbp-0x84], ecx
 
G_M000_IG04:                ;; offset=0x006A
       xor      r15d, r15d
       mov      rcx, gword ptr [rbx+0x10]
       lea      rdx, bword ptr [rbp-0x58]
       mov      bword ptr [rbp-0x98], rdx
       mov      dword ptr [rbp-0x90], 2
       mov      r13d, dword ptr [r14+0x08]
       test     r13d, r13d
       je       G_M000_IG19
       mov      rdx, gword ptr [r14+0x10]
       mov      gword ptr [rsp+0x20], rdx
       lea      rdx, [rbp-0x98]
       mov      r9, r8
       xor      r8d, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime:StartExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       nop      
 
G_M000_IG05:                ;; offset=0x00B0
       cmp      r13d, 1
       jbe      G_M000_IG15
       mov      r12, gword ptr [r14+0x30]
       mov      r9, gword ptr [rbp+0x20]
       mov      rax, gword ptr [r9+0xA0]
       mov      gword ptr [rbp-0xD8], rax
       cmp      byte  ptr [rax], al
       mov      rcx, rax
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG06
       mov      rcx, gword ptr [rbp-0xD8]
       mov      rdx, r12
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG06:                ;; offset=0x00EF
       mov      rdx, 0x178CC801C38
       mov      rdx, gword ptr [rdx]
       cmp      r13d, 2
       jbe      G_M000_IG15
       lea      r8, bword ptr [r14+0x50]
       mov      gword ptr [rbp-0xA8], rdx
       mov      qword ptr [rbp-0xA0], rdi
       mov      rdx, r8
       lea      r8, [rbp-0xA8]
       mov      r9, gword ptr [rbp+0x20]
       mov      r9, gword ptr [r9+0xA0]
       lea      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(byref,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       cmp      r13d, 3
       jbe      G_M000_IG15
       mov      rdi, gword ptr [r14+0x70]
       mov      r9, gword ptr [rbp+0x20]
       mov      r12, gword ptr [r9+0xA0]
       cmp      byte  ptr [r12], r12b
       mov      rcx, r12
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG07
       mov      rcx, r12
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG07:                ;; offset=0x016D
       lea      rcx, bword ptr [rbp-0x48]
       cmp      r13d, 4
       jbe      G_M000_IG15
       lea      rdx, bword ptr [r14+0x90]
       mov      rdi, gword ptr [rbp+0x30]
       mov      gword ptr [rbp-0xA8], rdi
       xor      r8d, r8d
       mov      qword ptr [rbp-0xA0], r8
       lea      r8, [rbp-0xA8]
       mov      r9, gword ptr [rbp+0x20]
       mov      r9, gword ptr [r9+0xA0]
       call     [Lokad.Lython.Runtime.LythonRuntime:StoreDefaultResult(byref,byref,Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot,Lokad.Lython.Runtime.ExecutionState)]
       cmp      r13d, 5
       jbe      G_M000_IG15
       mov      rdi, gword ptr [r14+0xB0]
       mov      r9, gword ptr [rbp+0x20]
       mov      r14, gword ptr [r9+0xA0]
       cmp      byte  ptr [r14], r14b
       mov      rcx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG08
       mov      rcx, r14
       mov      rdx, rdi
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG08:                ;; offset=0x01E7
       mov      rdx, gword ptr [rbx+0x30]
       test     rdx, rdx
       je       SHORT G_M000_IG09
       mov      r9, gword ptr [rbp+0x20]
       mov      gword ptr [rsp+0x20], r9
       mov      gword ptr [rsp+0x28], rdi
       mov      r9, gword ptr [rbx+0x08]
       lea      rcx, [rbp-0x68]
       mov      r8, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadEagerFunctionAnnotations(Lokad.Lython.Frontend.ExecutableInstruction[],Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.ValueTuple`3[System.Object,int,bool]]
       mov      rcx, gword ptr [rbp-0x68]
       mov      gword ptr [rbp-0xE0], rcx
       mov      ecx, dword ptr [rbp-0x60]
       mov      dword ptr [rbp-0x84], ecx
       movzx    r15, byte  ptr [rbp-0x5C]
 
G_M000_IG09:                ;; offset=0x0228
       mov      rsi, gword ptr [rbx+0x10]
       mov      r14, gword ptr [rbx+0x08]
       mov      rbx, gword ptr [rbx+0x28]
       mov      rcx, rsi
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Frontend.FunctionParameterLayout:get_DefaultStorageCount():int:this]
       mov      r13d, eax
       cmp      r13d, 2
       ja       G_M000_IG14
       mov      rcx, gword ptr [rbp+0x20]
       call     [Lokad.Lython.Runtime.LythonRuntime:GetGlobalContext(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.LythonRuntime+ExecutionContext]
       mov      r12, rax
       lea      r8, bword ptr [rbp-0x58]
       mov      bword ptr [rbp-0xB8], r8
       mov      dword ptr [rbp-0xB0], r13d
       lea      r8, [rbp-0xB8]
       lea      rcx, [rbp-0x80]
       mov      rdx, rsi
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime:ReadExecutableDefaults(Lokad.Lython.Frontend.FunctionParameterLayout,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],bool):Lokad.Lython.Runtime.FunctionDefaults]
       lea      rcx, bword ptr [rbp-0x58]
       mov      edx, r13d
       shl      rdx, 4
       add      rcx, rdx
       mov      edx, r13d
       neg      edx
       add      edx, 2
       lea      r8, [rbp-0x80]
       mov      qword ptr [rsp+0x20], r8
       xor      r8d, r8d
       mov      dword ptr [rsp+0x28], r8d
       mov      r9, gword ptr [rbp+0x20]
       mov      gword ptr [rsp+0x30], r9
       mov      gword ptr [rsp+0x38], rdi
       mov      bword ptr [rbp-0xB8], rcx
       mov      dword ptr [rbp-0xB0], edx
       mov      gword ptr [rsp+0x48], rbx
       mov      rcx, gword ptr [rbp-0xE0]
       mov      gword ptr [rbp-0xC8], rcx
       mov      ecx, dword ptr [rbp-0x84]
       mov      dword ptr [rbp-0xC0], ecx
       mov      byte  ptr [rbp-0xBC], r15b
 
G_M000_IG10:                ;; offset=0x02EA
       mov      dword ptr [rsp+0x58], r8d
 
G_M000_IG11:                ;; offset=0x02EF
       mov      bword ptr [rbp-0x98], r8
 
G_M000_IG12:                ;; offset=0x02F6
       mov      dword ptr [rbp-0x90], r8d
       lea      rcx, [rbp-0xC8]
       mov      qword ptr [rsp+0x50], rcx
       lea      rcx, [rbp-0x98]
       mov      qword ptr [rsp+0x60], rcx
       lea      rcx, [rbp-0xB8]
       mov      qword ptr [rsp+0x40], rcx
       mov      rcx, rsi
       mov      rdx, r14
       mov      r8, r12
       xor      r9, r9
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateFunctionValue(Lokad.Lython.Frontend.FunctionParameterLayout,Lokad.Lython.Frontend.ExecutableCodeObject,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutableCaptures,Lokad.Lython.Runtime.FunctionDefaults,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,System.ReadOnlySpan`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot],Lokad.Lython.Runtime.Text.PyString[],System.ValueTuple`3[System.Object,int,bool],bool,System.Span`1[Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot]):Lokad.Lython.Runtime.PyFunctionBase]
       mov      rbx, rax
       mov      edx, r13d
       add      rdx, rdx
       lea      rcx, bword ptr [rbp-0x58]
       call     [System.SpanHelpers:ClearWithReferences(byref,nuint)]
       xor      rax, rax
       mov      gword ptr [rbp-0xE0], rax
 
G_M000_IG13:                ;; offset=0x034F
       mov      dword ptr [rbp-0x84], eax
       mov      gword ptr [rbp-0xD0], rbx
       jmp      SHORT G_M000_IG16
 
G_M000_IG14:                ;; offset=0x035E
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG15:                ;; offset=0x0365
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG16:                ;; offset=0x036B
       call     G_M000_IG23
       nop      
 
G_M000_IG17:                ;; offset=0x0371
       mov      rax, gword ptr [rbp-0xD0]
 
G_M000_IG18:                ;; offset=0x0378
       add      rsp, 280
       pop      rbx
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG19:                ;; offset=0x038C
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG20:                ;; offset=0x0392
       sub      rsp, 104
 
G_M000_IG21:                ;; offset=0x0396
       lea      rcx, bword ptr [rbp-0x48]
       mov      r9, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [r9+0xA0]
       mov      rdx, gword ptr [rdx+0x88]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:RetireTemporary(Lokad.Lython.Runtime.MemoryGovernor):this]
       mov      r9, gword ptr [rbp+0x20]
       mov      rdx, gword ptr [r9+0xA0]
       mov      rdx, gword ptr [rdx+0x88]
       lea      rcx, bword ptr [rbp-0x58]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:RetireTemporary(Lokad.Lython.Runtime.MemoryGovernor):this]
       nop      
 
G_M000_IG22:                ;; offset=0x03CF
       add      rsp, 104
       ret      
 
G_M000_IG23:                ;; offset=0x03D4
       sub      rsp, 104
 
G_M000_IG24:                ;; offset=0x03D8
       cmp      gword ptr [rbp-0xE0], 0
       je       SHORT G_M000_IG26
       mov      r9, gword ptr [rbp+0x20]
       mov      rcx, gword ptr [r9+0xA0]
       mov      rbx, gword ptr [rcx+0x88]
       mov      ecx, dword ptr [rbp-0x84]
       call     [Lokad.Lython.Runtime.PyDict+RecordKeys:RecordBytes(int):long]
       mov      rdx, rax
       add      rdx, 160
       jo       SHORT G_M000_IG25
       mov      rcx, rbx
       cmp      dword ptr [rcx], ecx
       call     [Lokad.Lython.Runtime.MemoryGovernor:ReleaseReserved(long):this]
       jmp      SHORT G_M000_IG26
 
G_M000_IG25:                ;; offset=0x0419
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG26:                ;; offset=0x041F
       call     G_M000_IG20
       nop      
 
G_M000_IG27:                ;; offset=0x0425
       add      rsp, 104
       ret      
 
; Total bytes of code 1066

