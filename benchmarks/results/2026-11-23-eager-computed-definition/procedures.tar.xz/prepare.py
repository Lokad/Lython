from pathlib import Path
import json
import shutil

lab=Path(__file__).resolve().parent
prior=lab.parent/'direct-computed-definition-20261123'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
write=lambda p,text:p.write_text(text,encoding='utf-8',newline='\n')
eager='scripts.annotated-rule-closures.nested-factories'

def install(name,changes):
    text=(prior/name).read_text(encoding='utf-8')
    for a,b in changes:
        assert a in text,(name,a)
        text=text.replace(a,b)
    compile(text,name,'exec')
    write(lab/name,text)

shutil.copyfile(prior/'comparison/representative.json',lab/'representative.json')
jobs=read(prior/'comparison/jobs.json')
jobs['warm'][0],jobs['warm'][1]=jobs['warm'][1],jobs['warm'][0]
jobs['warm'][-1]=[eager,'compile-run']
write(lab/'jobs.json',json.dumps(jobs,indent=2)+'\n')
install('freeze.py',[
    ('prior = lab.parent / "closure-result-consumer-20261123"','prior = lab.parent / "direct-computed-definition-20261123"'),
    ("'2ab453375'","'a61b79041'"),
    ('direct-computed-b1500/windows','eager-computed-b1501/windows'),
    ('B1500 return a definition with prepared numeric and capture defaults','B1501 share the existing eager annotation preflight within the direct factory'),
])
install('stage.py',[
    ('b1500','b1501'),
    ('direct-computed-definition-b1501-20261123','eager-computed-definition-b1501-20261123'),
    ('closure-result-consumer-b1497-20261123','direct-computed-definition-b1500-20261123'),
])
install('quiet.py',[
    ('direct-computed-definition-20261123','eager-computed-definition-20261123'),
    ('b1500','b1501'),
])
for name in ('summarize.py','allocations.py'):
    shutil.copyfile(prior/name,lab/name)
install('inspect-shapes.py',[
    ("'scripts.annotated-rule-closures.nested-factories.postponed','scripts.factory-observed-defaults'",
     "'scripts.annotated-rule-closures.nested-factories'"),
    ("catalog,result],\n    env=dict(env,DOTNET_TieredCompilation",'''probe,result],
    env=dict(env,DOTNET_TieredCompilation'''),
    ("listing=lab/'computed-definition.asm'",'''fixture=read(catalog)
fixture['cases']=[r for r in fixture['cases'] if r['id']=='scripts.annotated-rule-closures.nested-factories']
assert len(fixture['cases'])==1
probe=lab/'jit-eager-only.json'
probe.write_text(json.dumps(fixture,indent=2)+'\\n',encoding='utf-8')
listing=lab/'computed-definition.asm' '''),
])
install('verify-defaults.py',[
    ("source=f'''from __future__ import annotations\ndef bind(weight):","source=f'''def bind(weight):"),
    ('base: int = seed','base = seed'),
])
install('archive.py',[
    ('direct-computed-b1500','eager-computed-b1501'),
    ('2026-11-23-direct-computed-definition','2026-11-23-eager-computed-definition'),
    ("'2026-11-23-closure-result-consumer/candidate-core.dll.gz'","'2026-11-23-direct-computed-definition/candidate-core.dll.gz'"),
    ("len(read(lab/'selected-returns.json'))==2","len(read(lab/'selected-returns.json'))==1"),
    ("row['allocatedBytes'][0]==row['allocatedBytes'][1] and row['peakAdmission'][0]==row['peakAdmission'][1]",
     "row['peakAdmission'][0]==row['peakAdmission'][1]"),
    ("'first-default-semantics.json','first-reference-default-semantics.json','first-default-semantics.log'",
     "'first-upload.json','first-stage.log','first-launch.log','retire-failed-upload.py','retire-failed-upload.log','jit-eager-only.json'"),
    ("'default-semantics.log'","'verify-defaults.log'"),
    ("'windows-final-Lokad.Lython.Tests.log','windows-final-Lokad.Lython.PublicApi.Tests.log'",
     "'windows-Lokad.Lython.Tests.log','windows-Lokad.Lython.PublicApi.Tests.log'"),
    ("'ubuntu-final-Lokad.Lython.Tests.log','ubuntu-final-Lokad.Lython.PublicApi.Tests.log'",
     "'ubuntu-Lokad.Lython.Tests.log','ubuntu-Lokad.Lython.PublicApi.Tests.log'"),
    ("'computed-defaults-observation.patch','win-retained-defaults.log','ubuntu-retained-defaults.log'",
     "'eager-default-annotations.patch','win-retained-annotations.log','ubuntu-retained-annotations.log'"),
])
