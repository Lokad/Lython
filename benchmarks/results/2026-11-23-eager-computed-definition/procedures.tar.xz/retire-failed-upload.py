from pathlib import Path
import json
import subprocess

lab=Path(__file__).resolve().parent
proof=json.loads((lab/'first-upload.json').read_text(encoding='utf-8'))
digest=proof['payloadSHA256']
assert isinstance(digest,str) and len(digest)==64 and all(ch in '0123456789abcdef' for ch in digest)
code=f'''from pathlib import Path
import fcntl,hashlib
base=Path('/home/lokad/lython-bench-checks')
artifact=base/('.+b1501-'+{digest!r}[:12]+'.tar.gz')
assert artifact.parent==base and not (base/'eager-computed-definition-b1501-20261123').exists()
with (base/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert artifact.is_file() and hashlib.sha256(artifact.read_bytes()).hexdigest()=={digest!r}
    artifact.unlink()
print('Retired the failed stage upload under the lease.')
'''
subprocess.run(['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),
    '-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73','python3 -'],
    input=code,encoding='utf-8',check=True,timeout=25)
