from pathlib import Path
import ast
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.with_name('closed-default-evaluation-20261124')
comparison = lab/'comparison'
quiet = comparison/'quiet'
quiet.mkdir(exist_ok=True)
sha = lambda b: hashlib.sha256(b).hexdigest()
read = lambda p: json.loads(p.read_text(encoding='utf-8'))

def write(path, source):
    path.write_text(source, encoding='utf-8', newline='\n')

def canonical(path):
    return subprocess.check_output(['git','show','origin/master:'+path],cwd=repo)

old = 'benchmarks/results/2026-11-23-short-text-source-pair/'
core_path = 'benchmarks/results/2026-11-23-closed-definition-return/reference-core.dll.gz'
replica_sha = sha(gzip.decompress(canonical(core_path)))
receipt = json.loads(canonical(old+'terminal-status.json'))['receipt']
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['archivedAndVerifiedUnderLease']
assert sha(canonical(old+'observations.tar.xz'))==receipt['archiveSHA256']
assert replica_sha==json.loads(canonical(old+'identity.json'))['imageFiles']['reference']['Lokad.Lython.dll']
retired = dict(sha256=replica_sha,coreArchive=core_path,aliases=[dict(path='short-text-source-pair-b1487-20261123/reference/Lokad.Lython.dll',
    observationSHA256=receipt['archiveSHA256'],source=old)])
write(lab/'verified-replicas.json',json.dumps([retired],indent=2)+'\n')

identity = read(comparison/'identity.json')
old_images = read(donor/'comparison/identity.json')['imageFiles']
assert identity['imageFiles']['reference']==old_images['candidate'] and identity['imageFiles']['prior']==old_images['reference']
for role, files in identity['imageFiles'].items():
    assert len(files)==32 and all(sha((lab/role/name).read_bytes())==digest for name,digest in files.items())
    proof=read(comparison/f'{role}-verify.json')
    assert proof['state']=='Completed' and proof['caseCount']==6
    assert proof['launched']['library']['sha256']==files['Lokad.Lython.dll']
for name, meta in identity['catalogs'].items():
    assert sha((comparison/name).read_bytes())==meta['sha256']

collector=(donor/'comparison/quiet/collect.py').read_text(encoding='utf-8').replace('b1590-','b1591-')
collector=collector.replace("images = {'candidate':root/'candidate','reference':root/'reference'}", "images = {role:root/role for role in ('candidate','reference','prior')}")
collector=collector.replace("{'reference','reference-control','candidate','candidate-control'}", "{label for role in images for label in (role,role+'-control')}")
collector=collector.replace("images['candidate' if label.startswith('candidate') else 'reference']", "images[label.split('-',1)[0]]")
collector=collector.replace("identity['imageFiles']['candidate'if label.startswith('candidate')else'reference']", "identity['imageFiles'][label.split('-',1)[0]]")
collector=collector.replace("            if job_index % 2 == 0: labels.reverse()", "            if case_id.startswith('scripts.annotated-rule-closures'):\n                labels[1:1] = ['prior-control']\n                labels[4:4] = ['prior']\n            if job_index % 2 == 0: labels.reverse()")
collector=collector.replace('started < 315','started < 390')
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
shutil.copyfile(donor/'comparison/quiet/run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz') as out:
    for item in (comparison/'identity.json',quiet/'run.sh',quiet/'collect.py'):
        out.add(item,arcname=item.name)
    out.add(lab/'candidate/Lokad.Lython.dll',arcname='candidate-core.dll')
write(quiet/'upload.json',json.dumps(dict(root='decoded-closed-defaults-b1591-20261124',reference='closed-default-evaluation-b1590-20261124',
    payloadSHA256=sha(payload.read_bytes()),payloadBytes=payload.stat().st_size),indent=2)+'\n')

launch=(donor/'quiet.py').read_text(encoding='utf-8').replace('b1590-closed-default-evaluation','b1591-decoded-closed-defaults').replace('b1590-','b1591-')
launch=launch.replace("assert archive==base/'captured-local-reads-b1589-20261124' and replica==archive/'candidate/Lokad.Lython.dll'", "assert archive==base/'short-text-source-pair-b1487-20261123' and replica==archive/'reference/Lokad.Lython.dll'")
launch=launch.replace("{'identity.json','representative.json','jobs.json','run.sh','collect.py','candidate-core.dll'}", "{'identity.json','run.sh','collect.py','candidate-core.dll'}")
launch=launch.replace(" for name,meta in identity['catalogs'].items():\n  assert", " for name,meta in identity['catalogs'].items():\n  os.link(reference/name,root/name)\n  assert")
launch=launch.replace("'reference':list(identity['imageFiles']['reference']), 'candidate':list(identity['imageFiles']['reference'])}", "role:list(identity['imageFiles']['reference']) for role in ('reference','candidate','prior')}")
launch=launch.replace("os.link(reference/'candidate'/name,image/name)", "os.link(reference/('reference' if role=='prior' else 'candidate')/name,image/name)")
launch=launch.replace('seconds=336','seconds=400').replace('RuntimeMaxSec=411','RuntimeMaxSec=460')
remote,=(node.value for node in ast.walk(ast.parse(launch)) if isinstance(node,ast.Constant) and isinstance(node.value,str) and node.value.startswith('digest=lambda path:'))
compile(remote,'remote-stage','exec')
assert 'short-text-source-pair-b1487-20261123' in remote and 'os.link(reference/name,root/name)' in remote and "role=='prior'" in remote
write(lab/'quiet.py',launch)

summary=(donor/'summarize.py').read_text(encoding='utf-8')
summary=summary.replace('        assert job["workersJoinedAndFixturesRemoved"] and len(job["samples"])==28', '        has_prior=job["case"].startswith("scripts.annotated-rule-closures")\n        assert job["workersJoinedAndFixturesRemoved"] and len(job["samples"])==(42 if has_prior else 28)\n        assert set(job["identities"]) == {label for role in (("reference","candidate","prior") if has_prior else ("reference","candidate")) for label in (role,role+"-control")}')
summary=summary.replace('def change(metric):','def change(metric, candidate="candidate", reference="reference"):').replace('for a in ("candidate","candidate-control")for b in ("reference","reference-control")','for a in (candidate,candidate+"-control") for b in (reference,reference+"-control")')
summary=summary.replace('        warm_rows.append(row)', '''        if has_prior:
            row.update(priorControlPercent=spread('prior'), candidateVsPriorElapsed=change('elapsed','candidate','prior'),
                candidateVsPriorCpu=change('cpu','candidate','prior'), referenceVsPriorElapsed=change('elapsed','reference','prior'),
                referenceVsPriorCpu=change('cpu','reference','prior'))
            print(row['case'],'candidate/prior',row['candidateVsPriorElapsed'],row['candidateVsPriorCpu'],
                'reference/prior',row['referenceVsPriorElapsed'],row['referenceVsPriorCpu'])
        warm_rows.append(row)''').replace('timedBatches=168','timedBatches=196, prior=identity["prior"]')
compile(summary,'summarize.py','exec')
write(lab/'summarize.py',summary)
