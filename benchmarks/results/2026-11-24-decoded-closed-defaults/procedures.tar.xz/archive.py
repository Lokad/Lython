from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
root = lab.parents[3]
comparison = lab / 'comparison'
quiet = comparison / 'quiet'
read = lambda path: json.loads(path.read_text(encoding='utf-8'))
sha = lambda payload: hashlib.sha256(payload).hexdigest()
meta = read(comparison / 'identity.json')
terminal = read(quiet / 'terminal-status.json')
summary = read(quiet / 'summary.json')
receipt = terminal['receipt']
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode'] == '0'
assert all(receipt[key] for key in ('complete', 'allWorkersJoined', 'guestFixturesRemoved', 'quietBeforeAndAfter', 'archivedAndVerifiedUnderLease'))
assert sha((quiet / 'observations.tar.xz').read_bytes()) == receipt['archiveSHA256']
assert summary['timedBatches'] == 196 and len(summary['rows']) == 6
for role in ('prior', 'reference', 'candidate'):
    verified = read(comparison / (role + '-verify.json'))
    assert verified['state'] == 'Completed' and verified['caseCount'] == 6
    files = meta['imageFiles'][role]
    assert len(files) == 32
    assert all(sha((lab / role / name).read_bytes()) == expected for name, expected in files.items())

out = root / 'benchmarks/results/2026-11-24-decoded-closed-defaults'
for role, earlier in [('reference', 'closed-default-evaluation'), ('prior', 'eager-json-owner')]:
    payload = gzip.decompress((out.parent / ('2026-11-24-' + earlier) / 'candidate-core.dll.gz').read_bytes())
    assert sha(payload) == meta['coreSHA256'][role]
out.mkdir(exist_ok=True)
binary = (lab / 'candidate/Lokad.Lython.dll').read_bytes()
(out / 'candidate-core.dll.gz').write_bytes(gzip.compress(binary, mtime=0))
assert sha(gzip.decompress((out / 'candidate-core.dll.gz').read_bytes())) == meta['coreSHA256']['candidate']
files = {
    comparison / 'identity.json': 'identity.json',
    quiet / 'terminal-status.json': 'terminal-status.json',
    quiet / 'observations.tar.xz': 'observations.tar.xz',
    quiet / 'summary.json': 'summary.json',
    lab / 'allocation-summary-six.json': 'allocation-summary.json',
}
for source, name in files.items():
    shutil.copyfile(source, out / name)
patch = subprocess.check_output(['git', 'diff', '--binary', 'e7ca61015', meta['candidate'], '--', 'src', 'tests'], cwd=root)
(lab / 'measured.patch').write_bytes(patch)
procedures = ['prepare.py', 'stage.py', 'archive.py', 'quiet.py', 'summarize.py', 'allocations.py',
    'verified-replicas.json', 'reference-allocation-six.json', 'candidate-allocation-six.json',
    'comparison/quiet/launch.log', 'comparison/prior-verify.json', 'comparison/reference-verify.json',
    'comparison/candidate-verify.json', 'validation.txt', 'measured.patch']
with tarfile.open(out / 'procedures.tar.xz', 'w:xz') as archive:
    for name in procedures:
        archive.add(lab / name, arcname=name)
with tarfile.open(out / 'procedures.tar.xz') as archive:
    assert all(archive.extractfile(name).read() == (lab / name).read_bytes() for name in procedures)
print('Archived B1591, 196 verified batches and three complete images')
