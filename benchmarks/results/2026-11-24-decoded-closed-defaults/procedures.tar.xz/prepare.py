from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
tree = repo/'.git/agent-worktrees/compiled-value-captures-20261122'
donor = lab.with_name('closed-default-evaluation-20261124')
comparison = lab/'comparison'
comparison.mkdir(exist_ok=True)
dotnet = Path.home()/'.dotnet11/dotnet.exe'
core = 'Lokad.Lython.dll'

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')

def git(*args):
    return subprocess.check_output(['git',*args],cwd=tree,text=True).strip()

old = read(donor/'comparison/identity.json')
reference = old['candidate']
prior = old['sourceRevision']
candidate = git('rev-parse','HEAD')
assert candidate != reference and candidate != prior
git('diff','--exit-code',reference,'e7ca61015','--','src','tests')
git('merge-base','--is-ancestor','e7ca61015',candidate)
assert not git('status','--porcelain','--','src','tests')
for name, metadata in old['catalogs'].items():
    shutil.copyfile(donor/'comparison'/name,comparison/name)
    assert digest(comparison/name)==metadata['sha256']
representative = comparison/'representative.json'
protocol = repo/'benchmarks/cpython-worker.py'
assert digest(protocol)==old['cpythonWorkerSHA256']
env = dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent))

roles = {'prior':'reference','reference':'candidate','candidate':'candidate'}
images = {}
for role, original in roles.items():
    image = lab/role
    image.mkdir(exist_ok=True)
    files = old['imageFiles'][original]
    assert len(files)==32 and all(digest(donor/original/name)==checksum for name,checksum in files.items())
    for name in files:
        source = lab/'frozen/bin/Lokad.Lython/release_net11.0'/core if role=='candidate' and name==core else donor/original/name
        shutil.copyfile(source,image/name)
    for name, checksum in old['helperFiles'].items():
        shutil.copyfile(donor/original/name,image/name)
        assert digest(image/name)==checksum
    observed = {name:digest(image/name) for name in files}
    result = comparison/(role+'-verify.json')
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',representative,
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',protocol,'--out',result],env=env,check=True,timeout=100)
    proof = read(result)
    assert proof['state']=='Completed' and proof['caseCount']==6 and proof['launched']['library']['sha256']==observed[core]
    assert all(digest(image/name)==checksum for name,checksum in observed.items())
    assert all(digest(image/name)==checksum for name,checksum in old['helperFiles'].items())
    images[role]=observed
for role in ('prior','candidate'):
    assert [name for name in images['reference'] if images[role][name]!=images['reference'][name]]==[core]
assert len({files[core] for files in images.values()})==3
save(comparison/'identity.json',dict(sourceRevision=reference,prior=prior,candidate=candidate,
    purpose='B1591 reuse decoded exact integers and avoid the captured-default slot round trip',
    imageFiles=images,helperFiles=old['helperFiles'],cpythonWorkerSHA256=old['cpythonWorkerSHA256'],
    expectedCPythonSHA256=old['expectedCPythonSHA256'],catalogs=old['catalogs'],
    coreSHA256={label:images[role][core] for role in roles for label in (role,role+'-control')}))
shutil.copyfile(donor/'allocations.py',lab/'allocations.py')
