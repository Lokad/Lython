from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
quiet = lab / "quiet"
out = Path("benchmarks/results/2026-11-22-complete-decimal-ascii")

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

identity = load(quiet / "identity.json")
a, _, b = identity["sourceRevision"].split()
assert a.startswith("e961df912") and b.startswith("6d2fd2907")
for role, files in identity["imageFiles"].items():
    image = lab / "frozen" / role
    assert len(files) == 32 and {name: sha(image / name) for name in files} == files
    assert sha(quiet / role / "Lokad.Lython.dll") == files["Lokad.Lython.dll"]
    proof = load(lab / f"quiet-{role}-verify.json")
    assert proof["state"] == "Completed" and proof["caseCount"] == 4
    assert proof["catalogSha256"] == identity["catalogSHA256"] == sha(quiet / "representative.json")
for platform in ("win", "ubuntu"):
    for suite, count in (("white", 279), ("public", 1124)):
        log = (lab / f"{suite}-{platform}.log").read_text(encoding="utf-8-sig")
        assert "Passed!" in log and f"Passed: {count:5d}, Skipped:" in log
allocation = load(lab / "allocation-summary.json")
assert len(allocation) == 4 and all(row["allowanceRestored"] for row in allocation)
corpus = load(lab / "corpus.json")["cases"]
assert len(corpus) == 1 and corpus[0]["size"] == 676
assert sha(lab / "corpus-cpython.txt") == corpus[0]["expectedOutputSha256"]
for role in ("reference", "candidate"):
    proof = load(lab / f"{role}-corpus-verify.json")
    assert proof["state"] == "Completed" and proof["caseCount"] == 1
    assert proof["catalogSha256"] == sha(lab / "corpus.json")
receipt = load(quiet / "archive-receipt.json")
terminal = load(quiet / "terminal-status.json")
assert terminal["exitCode"] == "0" and terminal["receipt"] == receipt
assert not terminal["remainingTrace"] and not terminal["remainingWorkers"]
assert all(receipt[k] for k in ("complete", "allWorkersJoined", "guestFixturesRemoved",
                               "archivedAndVerifiedUnderLease", "quietBeforeAndAfter"))
assert sha(quiet / "observations.tgz") == receipt["archiveSHA256"]
raw = load(quiet / "retrieved/confirmation/confirmation.json")
assert raw["warmupSeconds"] == 12 and raw["targetBatchSeconds"] == .65 and raw["rounds"] == 7
cases = {case["id"]: case for case in load(quiet / "representative.json")["cases"]}
assert raw["complete"] and len(raw["jobs"]) == receipt["jobs"] == 5 and len(cases) == 4
assert [(job["case"], job["lane"]) for job in raw["jobs"]] == [(key,"warm") for key in cases] + [(list(cases)[0],"compile-run")]
for job in raw["jobs"]:
    case = cases[job["case"]]
    assert job["workersJoinedAndFixturesRemoved"] and len(job["samples"]) == 28
    for sample in job["samples"]:
        response = sample["response"]
        assert response["completedInvocations"] > 0 and response["status"] == "Completed"
        assert response["sourceSha256"] == case["sourceSha256"] and response["fixtureSha256"] == case["fixtureSha256"]
        assert response.get("actualOutputSha256") == case["expectedOutputSha256"]
        assert response.get("actualFilesSha256") == case.get("expectedFilesSha256")

summary = load(quiet / "quiet-summary.json")
del summary["retentionDecisionPending"]
summary.update(collection="B1339", sourceRevision=identity["sourceRevision"], verifiedTimedBatches=140,
    coreSHA256=identity["coreSHA256"], archiveSHA256=receipt["archiveSHA256"],
    retentionDecision=load(lab / "decision.json")["decision"])
out.mkdir(exist_ok=True)
(out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8", newline="\n")
for name in ("README.md", "allocation-summary.json"):
    shutil.copyfile(lab / name, out / name)
for name in ("archive-receipt.json", "terminal-status.json", "observations.tgz"):
    shutil.copyfile(quiet / name, out / name)
reference = Path("benchmarks/results/2026-11-22-numeric-extrema-operands/candidate-core.dll.gz")
assert gzip.decompress(reference.read_bytes()) == (quiet / "reference/Lokad.Lython.dll").read_bytes()
core = (quiet / "candidate/Lokad.Lython.dll").read_bytes()
image = out / "candidate-core.dll.gz"
image.write_bytes(gzip.compress(core, mtime=0))
assert gzip.decompress(image.read_bytes()) == core
(lab / "measured-source.patch").write_bytes(subprocess.check_output(["git", "diff", a, b, "--", "src", "tests"]))
with tarfile.open(out / "checks-and-procedures.tar.xz", "w:xz", preset=6) as archive:
    for folder in (lab, quiet):
        for path in sorted(folder.iterdir()):
            if path.is_file() and path.suffix not in {".dll", ".tgz"} and path.name != "safe-working-input-inventory.json":
                archive.add(path, arcname=path.relative_to(lab).as_posix())
print("140 timed batches, frozen images and focused Release checks verified.")
