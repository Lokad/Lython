from pathlib import Path
import hashlib,json,re
r=Path(__file__).parent
old=(r.parent/'regex-dev54-r59/preserve.py').read_text(encoding='utf-8').split('history=Path(',1)[0]
old=old.replace('2026-11-07-regex-dev54','2026-11-07-regex-dev55').replace('R59','R68')
old=old.replace('0.5.0-dev.54','0.5.0-dev.55').replace('dev.54','dev.55')
old=old.replace('553acbdfc895d993416e3bad3af47c468a181148','d60679252cf6d16a76f7a77a7b50c34899cd0e50')
old=old.replace('sourcee66b8f72','source824fc6bb').replace('coreaa133dcb','core15c04e2a')
old=old.replace('aa133dcbb1c70bddc3339d09085a53785f789582cf39ff83c883d26f8ef4f20e','15c04e2a6670835841f8790d4ce7a89d49574e5c4c1356d07a147323680687fd')
exec(compile(old,str(r/'preserve-adapted.py'),'exec'),{'__file__':str(__file__)})
out=Path('benchmarks/results/2026-11-07-regex-dev55')
(out/'api-difference.json').write_bytes((r/'api-difference.json').read_bytes())
readme=out/'README.md'
text=readme.read_text(encoding='utf-8').replace('The dirty sibling worktree was neither built nor consumed.', 'The clean sibling source was not built or edited; only exact immutable packages were consumed.')
text=text.replace('No producer API difference requires', 'Compared with dev.54, the346Core/277PythonRe documented member names show no additions or removals ([difference](api-difference.json)); this is a name comparison, not an API compatibility proof. No producer API difference requires')
readme.write_text(text,encoding='utf-8')
history=Path('benchmarks/EXPERIMENTS.md')
history.write_text(history.read_text(encoding='utf-8')+'''
## R67 retained checkpoint / R68 immutable development adapter

[R67/B421](results/2026-11-07-buffered-checkpoint/README.md): source824fc6bb,
core15c04e2a,23CPython jobs/478.32s, all goldens/identity/quiet/Closed/join/fixture
gates and local/remote archive verification pass. Current guide separates
compilation/warm/fresh and preserves source55e510ff tables historically. Variable
roles and CPython IQR stay explicit; no source-pair CPU or debt repayment claim.
Full combined source CI42418518578 remains pending at measurement close.

[R68](results/2026-11-07-regex-dev55/README.md): exact immutable unpublished
0.5.0-dev.55/d6067925, existing bridge reused byte-for-byte in isolated outputs,
assets/feed/locks;86internal/514public per actual11/10 pass. Documented names
unchanged from dev54; DetailedData owner, native name enumeration and independent
creation/current tokens still require bridges. Normal0.4pin/core unchanged;
development semantic compatibility is not final released/safety/backend-performance
qualification. No sibling source edit/build or producer CI replay.
''',encoding='utf-8')
plan=Path('PLAN.md');s=plan.read_text(encoding='utf-8')
s=s.replace('| R67 / B421 | Representative CPython refresh RUNNING; exact source 824fc6bb, frozen core15c04e2a (precommit SourceLink5dd131bf), unchanged normal0.4 adapter/worker. |', '| R67 / B421 | COMPLETE/verified:23CPython jobs/478.32s, source824fc6bb/core15c04e2a. Current guide refreshed; prior tables historical. |')
s=s.replace('| R59 development adapter | Immutable0.5.0-dev.54/553acbdf compatibility completed,86internal/514public per target. Normal optional0.4pin unchanged. Final released-adapter/safety/performance qualification separate. |','| R68 development adapter | Immutable0.5.0-dev.55/d6067925 compatibility complete,86internal/514public per target, unchanged bridge. Normal0.4pin/core untouched. Final released/safety/performance qualification separate. |')
s=s.replace('B421 owns the current collection.', 'B421 is complete/archived/verified; no active VM collection.')
a=s.index('R68 independent dev55 assessment:')
s=s[:a]+'''R68 dev55 compatibility complete: exact packages/nuspec/Core pin/SHA verified,
346Core/277PythonRe documented names unchanged fromdev54; existing adapter bridge
reused byte-for-byte.86internal/514public per actual11/10 pass in isolated images.
No new API/pin/production change justified. Final release/safety/performance remains
separate. [Evidence](benchmarks/results/2026-11-07-regex-dev55/README.md).
'''
s=s.replace('No local build/test/measurement is active.','No local build/test/measurement is active. R68 isolated qualification completed.')
plan.write_text(s,encoding='utf-8')
print('Preserved development-only compatibility; normal core/pin untouched.')
