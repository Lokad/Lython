from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;old=r.parent/'compile-phase-r128';root='agent-runtime-b491-20261109';unit='lython-b491-agent-runtime-20261109'
assert not subprocess.check_output(['git','diff','459813a3','--','src','tests']).strip()
for name in ['ops-profile.py','analyze-cpu-guest.py','run.sh','archive.py','launch.py','retrieve.py']:
 s=(old/name).read_text(encoding='utf8').replace('compile-phase-b488-20261109',root).replace('lython-b488-compile-phase-20261109',unit).replace('compile-phase-b488-launch.py','agent-runtime-b491-launch.py').replace('lython-b488','lython-b491')
 s=s.replace('helper-compile','search-warm').replace('config-compile','config-warm')
 if name=='ops-profile.py':
  s=s.replace('Current compilation-only phase attribution','Current config/search warm runtime and host attribution')
  s=s.replace('("search-warm", "scripts.csv-validated-records.large", "compile")','("search-warm", "scripts.file-search.large", "warm")').replace('("config-warm", "scripts.config-edit.small", "compile")','("config-warm", "scripts.config-edit.small", "warm")')
  s=s.replace('count = 1024  #','count = (2048 if name == "config-warm" else 256)  #').replace('4096 if lane == "compile" else 512','4096')
  s=s.replace("row['seconds'] > .5", "row['seconds'] > .25").replace('Expected actual active compilation worker threads.','Expected actual active runtime/caller workers.')
  s=s.replace('"collector": "perf cpu-clock/fp"','"collector": "perf cpu-clock/fp", "samplingBoundary": "Whole batch worker CPU includes reset/protocol/validation wider than execution clocks; distinguish call stacks, retain all thread CPU and raw samples; no elapsed comparison"')
 if name=='launch.py':s=s.replace("source=(base/'declaration-layout-b487-20261109/candidate').resolve()", "source=(base/'literal-construction-b489-20261109/candidate').resolve()")
 (r/name).write_text(s,encoding='utf8',newline='\n')
shutil.copyfile(r.parent/'agent-workloads-r130/representative.json',r/'catalog.json')
i=json.loads((r.parent/'agent-workloads-r130/identity.json').read_text(encoding='utf8'))
identity=dict(sourceRevision='459813a3; later0e7c1e17 documentation only',coreSHA256=i['coreSHA256']['candidate'],auxiliaryFiles=i['auxiliaryFiles'],catalogSHA256=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest())
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf8')
shutil.copyfile(r.parent/'agent-workloads-r130/core-source.json',r/'core-source.json')
(r/'selection.md').write_text('R131 source gate afterB490: current config/search warm gaps1.26–1.27x/1.69–1.71x, source459/core1be2. Existing two6s perf captures after6s warmup each; no elapsed comparison/new framework/prototype. Observe actual caller/guest workers and retain all thread CPU/raw samples. Sampling includes worker fixture reset/protocol/validation outside execution clock, distinguish these stacks from runtime/host work before attribution. Unknown/inlined/truncated frames explicit; inclusive work is not removable cost. Select at most one coherent complete phase after evidence/source gate; no broad profile or unchanged retiming campaign.180sowner+30stop+30observation, finishusers/RAM/archive underlease/localverification.\n',encoding='utf8')
(r/'sizing.json').write_text(json.dumps(dict(jobs=2,warmupSecondsEach=6,captureSecondsEach=6,ownerSeconds=180,stopSeconds=30,marginSeconds=30),indent=2)+'\n',encoding='utf8');shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
with tarfile.open(r/'payload.tgz','w:gz')as a:
 for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','catalog.json','identity.json','core-source.json','selection.md','sizing.json','pre-measurement-plan.md']:a.add(r/name,arcname=name)
for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py','launch.py','retrieve.py']:compile((r/name).read_text(encoding='utf8'),name,'exec')
print('Prepared two bounded current warm runtime profiles, core',identity['coreSHA256'])
