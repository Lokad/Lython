from hashlib import sha256
from pathlib import Path
from shutil import copyfile
import json
import tarfile

lab=Path(__file__).resolve().parent
notes=lab.parent
repo=lab.parents[3]
pair=lab/"comparison"
quiet=pair/"quiet"
quiet.mkdir()
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
def write(path,value):
    path.write_text(json.dumps(value,indent=2)+"\n",encoding="utf-8",newline="\n")
def image(folder):
    assert folder.is_dir()
    return {p.name:digest(p) for p in folder.iterdir()}

donor=notes/"local-assignment-slots-20261127/comparison/quiet"
donor_state=read(donor/"terminal-status.json")
donor_receipt=donor_state["receipt"]
assert not donor_state["live"] and not donor_state["fixtures"]
assert donor_receipt["archiveSHA256"]==digest(donor/"observations.tar.xz") and donor_receipt["allWorkersJoined"]
donor_files=read(donor/"identity.json")["imageFiles"]["candidate"]
donor_name=read(donor/"upload.json")["root"]
identity=read(pair/"identity.json")
core="Lokad.Lython.dll"
for role, files in identity["imageFiles"].items():
    assert image(pair/role)==files and len(files)==32
    assert [name for name in files if files[name]!=donor_files[name]]==[core]
    proof=read(pair/f"{role}-verify.json")
    assert proof["state"]=="Completed" and proof["caseCount"]==5
    assert proof["launched"]["library"]["sha256"]==files[core]
    assert proof["launched"]["adapter"]["sha256"]==files["Lokad.Lython.Benchmarks.dll"]
identity["donorArchiveSHA256"]=donor_receipt["archiveSHA256"]
identity["purpose"]="Quiet comparison of the refined generator-row callback workspace with reversed worker placement."
for name in ("representative.json","cpython-worker.py"):
    copyfile(pair/name,quiet/name)
jobs=read(pair/"jobs.json")["warm"]
selected=[jobs[index] for index in (4,1,0)]
assert [j[1] for j in selected]==["warm-async","warm-async","warm"]
write(quiet/"jobs.json",{"warm":selected})
identity["catalogs"]["jobs.json"]["sha256"]=digest(quiet/"jobs.json")
prior=notes/"lexical-return-summaries-20261127"
prior_quiet=prior/"comparison/quiet"
copyfile(prior_quiet/"run.sh",quiet/"run.sh")
assert b"\r" not in (quiet/"run.sh").read_bytes()
collector=(prior_quiet/"collect.py").read_text(encoding="utf-8").replace("lython-b1901-lexical-return-fixtures","lython-b1905-generator-row-fixtures")
assert "len(jobs) == 3" in collector
compile(collector,"collect.py","exec")
(quiet/"collect.py").write_text(collector,encoding="utf-8",newline="\n")
write(quiet/"identity.json",identity)
paths={name:quiet/name for name in ("identity.json","representative.json","jobs.json","cpython-worker.py","run.sh","collect.py")}
for role in ("candidate","reference"):
    paths[f"{role}/{core}"]=pair/role/core
payload=quiet/"stage.tar.gz"
with tarfile.open(payload,"w:gz") as bundle:
    for name,path in paths.items(): bundle.add(path,arcname=name)
files={name:dict(length=path.stat().st_size,sha256=digest(path)) for name,path in paths.items()}

retired=[]
for name, unit, archived, local_role, local_image, preserved_archive in [
    ("lexical-return-quiet-b1901-20261127","lython-b1901-lexical-return-quiet",
      prior_quiet,"candidate",prior/"comparison/candidate",
      repo/"benchmarks/results/2026-11-27-lexical-return-summaries/quiet-observations.tar.xz"),
    ("generator-outer-quiet-b1895-20261127","lython-b1895-generator-outer-quiet",
      notes/"quiet-generator-outer-20261127/comparison/quiet","reference",
      notes/"direct-generator-outer-20261127/comparison/reference",
      repo/"benchmarks/results/2026-11-27-generator-outer-quiet/observations.tar.xz"),
]:
    expected=read(archived/"identity.json")["imageFiles"][local_role]
    assert len(expected)==32 and image(local_image)==expected
    state=read(archived/"terminal-status.json")
    receipt=state["receipt"]
    assert not state["live"] and not state["fixtures"] and state["exitCode"]=="0"
    assert receipt["archiveSHA256"]==digest(preserved_archive)
    assert all(receipt[n] for n in ("complete","allWorkersJoined","guestFixturesRemoved","archivedAndVerifiedUnderLease"))
    retired.append(dict(name=name,unit=unit,role=local_role,image=expected,archive=receipt["archiveSHA256"],
                        localImage=str(local_image.relative_to(repo)),preservedArchive=str(preserved_archive.relative_to(repo))))
write(quiet/"upload.json",dict(root="generator-row-workspace-quiet-b1905-20261127",donor=donor_name,
    donorFiles=donor_files,donorArchive=donor_receipt["archiveSHA256"],removals=retired,
    payloadSHA256=digest(payload),files=files,expandedBytes=sum(x["length"] for x in files.values()),
    minimumAfterStageBytes=12*1024*1024))
vm=(prior/"quiet-vm.py").read_text(encoding="utf-8")
vm=vm.replace("lython-b1901-lexical-return-quiet","lython-b1905-generator-row-quiet")
lookup=" assert before>=floor,(before,floor)\n cleared=before"
assert lookup in vm
vm=vm.replace(lookup,r''' deduplicated=[]
 if before<floor:
  eligible=[]
  for saved in cfg['removals']:
   older=base/saved['name']
   assert older.resolve(strict=True)==older and older.parent==base and older!=donor
   state=subprocess.check_output(['systemctl','show',saved['unit']+'.service',
      '--property=ActiveState,MainPID,Result'],text=True)
   assert 'ActiveState=inactive' in state and 'MainPID=0' in state and 'Result=success' in state
   assert not (older/'guest-fixtures').exists()
   older_receipt=json.loads((older/'archive-receipt.json').read_text())
   assert older_receipt['complete'] and older_receipt['allWorkersJoined'] and older_receipt['guestFixturesRemoved']
   assert older_receipt['archiveSHA256']==saved['archive']==sha(older/'observations.tar.xz')
   archived_image=older/saved['role']
   assert archived_image.resolve(strict=True)==archived_image
   assert {p.name:sha(p) for p in archived_image.iterdir()}==saved['image']
   binary=archived_image/'Lokad.Lython.dll'
   snapshot=binary.lstat()
   assert binary.resolve(strict=True)==binary and stat.S_ISREG(snapshot.st_mode)
   assert snapshot.st_uid==os.geteuid() and snapshot.st_nlink==1
   eligible.append((binary,snapshot,saved))
  assert before+sum(s.st_blocks*512 for _,s,_ in eligible)>=floor
  for binary,snapshot,saved in eligible:
   if shutil.disk_usage(base).free>=floor: break
   current=binary.lstat()
   assert (current.st_dev,current.st_ino,current.st_nlink)==(snapshot.st_dev,snapshot.st_ino,1)
   assert sha(binary)==saved['image']['Lokad.Lython.dll']
   binary.unlink()
   deduplicated.append(dict(path=str(binary),sha256=saved['image']['Lokad.Lython.dll'],
     localImage=saved['localImage'],archiveSha=saved['archive']))
  (base/'generator-row-workspace-b1905-replica-custody.json').write_text(
     json.dumps(dict(before=before,after=shutil.disk_usage(base).free,removed=deduplicated),indent=2)+'\n')
 cleared=shutil.disk_usage(base).free
 assert cleared>=floor,(cleared,floor)''')
vm=vm.replace("deduplicated=[],expandedBytes=","deduplicated=deduplicated,expandedBytes=")
compile(vm,"quiet-vm.py","exec")
(lab/"quiet-vm.py").write_text(vm,encoding="utf-8",newline="\n")
summarizer=(lab/"summarize.py").read_text(encoding="utf-8").replace('{"donor": 63, "paired": 0}','{"donor": 62, "paired": 0}')
(lab/"summarize.py").write_text(summarizer,encoding="utf-8",newline="\n")
print("Paired space required",sum(x["length"] for x in files.values())+12*1024*1024+400000)
