from itertools import starmap
marker = []
events = []
def consume(value, item='initial'):
    if value is marker:
        with open('callback.txt') as callback:
            return callback.read() + item
    return 'wrong value'
def row(count):
    yield marker
    with open('input.txt') as source:
        for i in range(count):
            part = source.read(1)
            events.append(part)
            yield part
    consume.__defaults__ = ('changed',)
    events.append('done')
batches = starmap(consume, [row(0), row(1), row(3), row(1)])
print(next(batches), events)
print(next(batches), events)
try:
    next(batches)
except TypeError:
    print('arity', events)
print(next(batches), events)
