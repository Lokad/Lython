from pathlib import Path
import ast

lab = Path(__file__).resolve().parent
template=lab.parent/'postponed-cpython-b1156'/'collect-evidence.py'
source=template.read_text(encoding='utf-8-sig').replace('B1156','B1162')
source=source.replace('2026-11-20-postponed-factories-cpython','2026-11-20-representative-cpython')
source=source.replace('receipt["jobs"] == 2','receipt["jobs"] == 4').replace('len(cases) == 2','len(cases) == 4')
source=source.replace('expected_lanes = ("warm", "compile-run", "compile")',
    'expected_lanes = ("warm",) if case["id"] == "scripts.csv-invoice.large" else ("warm", "compile-run", "compile")')
source=source.replace('assert len(rows) == 6','assert len(rows) == 10').replace('verifiedBatches=120','verifiedBatches=200')
source=source.replace('assert gzip.decompress((out.parent/"2026-11-20-compiled-postponed-annotations/measured-core.dll.gz").read_bytes()) == core_bytes',
    '(out / "measured-core.dll.gz").write_bytes(gzip.compress(core_bytes,mtime=0))')
assert '== 2' not in source and 'verifiedBatches=200' in source
ast.parse(source)
(lab/'collect-evidence.py').write_text(source,encoding='utf-8',newline='\n')
