from pathlib import Path
import ast
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
template = lab.parent/'postponed-cpython-b1156'
pair = lab.parent/'native-keyword-snapshot'
profile = lab.parent/'retained-dispatch-profile'
donor = pair/'quiet'
core = 'Lokad.Lython.dll'
read = lambda p: p.read_text(encoding='utf-8-sig')
load = lambda p: json.loads(read(p))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def write(name, source):
    if name.endswith('.py'): ast.parse(source)
    (lab/name).write_text(source,encoding='utf-8',newline='\n')

def save(name, value): write(name,json.dumps(value,ensure_ascii=False,indent=2)+'\n')

old=load(donor/'config.json')
receipt=load(donor/'archive-receipt.json')
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease'] and receipt['allWorkersJoined']
assert sha(donor/'observations.tgz')==receipt['archiveSHA256']
identity=load(pair/'frozen-identity.json')
measured=identity['referenceCommit']
retained=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'])
subprocess.run(['git','diff','--exit-code',measured,retained,'--','src/Lokad.Lython.Utf8Regex','Directory.Build.props','Directory.Packages.props',
                'benchmarks/Lokad.Lython.Benchmarks','benchmarks/cpython-worker.py','global.json'],check=True)
source=pair/'frozen'/'reference'
image=lab/'frozen/candidate'
image.mkdir(parents=True,exist_ok=True)
donor_files=identity['images']['reference']
assert len(donor_files)==32 and donor_files==old['identity']['imageFiles']['reference']
assert {name:sha(source/name) for name in donor_files}==donor_files
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
with (lab/'current-build.log').open('wb') as log:
    subprocess.run([dotnet,'build','src/Lokad.Lython','-c','Release','-f','net11.0','--no-incremental'],
                   env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
new_core=Path('src/Lokad.Lython/bin/Release/net11.0')/core
files=donor_files | {core:sha(new_core)}
for name in files: shutil.copyfile(new_core if name==core else source/name,image/name)
assert {name:sha(image/name) for name in files}==files

catalog=load(pair/'catalog.json')
cases={case['id']:case for case in load(profile/'catalog.json')['cases']+catalog['cases']}
ids=['scripts.annotated-rule-closures','scripts.report-forwarding.expanded','scripts.report-render.format-selectors.large',
     'scripts.csv-invoice.large']
catalog['cases']=[cases[key] for key in ids]
save('representative.json',catalog)
catalog_hash=sha(lab/'representative.json')
shutil.copyfile(donor/'cpython-worker.py',lab/'cpython-worker.py')
protocol_hash=sha(lab/'cpython-worker.py')
assert protocol_hash==old['protocolSHA256']==sha(Path('benchmarks/cpython-worker.py'))
current=dict(sourceRevision=retained,imageSource=retained,purpose='B1162 representative scripts against CPython',
    imageFiles={'candidate':files},auxiliaryFiles={name:digest for name,digest in files.items() if name!=core},
    coreSHA256={'candidate':files[core],'candidate-control':files[core]},catalogSHA256=catalog_hash,cpythonWorkerSHA256=protocol_hash)
save('identity.json',current)
save('build-revision.json',dict(sourceRevision=retained,imageSource=retained,coreSHA256=files[core]))
with (lab/'verify.log').open('wb') as log:
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',lab/'representative.json',
         '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',lab/'cpython-worker.py',
         '--out',lab/'verify.json'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
verified=load(lab/'verify.json')
assert verified['state']=='Completed' and verified['catalogSha256']==catalog_hash

root='/home/lokad/lython-bench-checks/nov20-cpython-b1162-20261120'
unit='lython-b1162-representative-cpython-20261120'
oldroot=load(template/'config.json')['root']
floor=172*1024*1024
for name in ('collect.py','archive-owned.py','launch.py','retrieve.py','run.sh'):
    code=read(template/name).replace(oldroot,root).replace('B1156','B1162')
    code=code.replace('182452224',str(floor))
    if name=='collect.py':
        start=code.index('    for case_id,diagnostic in ')
        end=code.index('\n',start)
        code=code[:start]+f'    for case_id,diagnostic in {[(key,False) for key in ids]!r}:'+code[end:]
        code=code.replace('lanes = ["warm", "compile-run", "compile"]',
            'lanes = ["warm"] if case_id == "scripts.csv-invoice.large" else ["warm", "compile-run", "compile"]')
        code=code.replace('started<205','started<345')
    if name in ('archive-owned.py','retrieve.py'):
        code=code.replace("['jobs'])==2","['jobs'])==4").replace("['jobs']==2","['jobs']==4").replace('jobs=2,','jobs=4,')
    if name=='launch.py': code=code.replace('185','275')
    write(name,code)
assert b'\r' not in (lab/'run.sh').read_bytes()

staged=lab/'candidate'
staged.mkdir(exist_ok=True)
shutil.copyfile(image/core,staged/core)
names=('representative.json','identity.json','collect.py','archive-owned.py','run.sh','cpython-worker.py','candidate/'+core)
payload=lab/'payload.tgz'
with tarfile.open(payload,'w:gz') as archive:
    for name in names: archive.add(lab/name,arcname=name)
expanded=sum((lab/name).stat().st_size for name in names)
space=load(lab/'quiet-space.json')
available=space['freeBytes']
selected=[]
for proof in space['replicas']:
    if available>floor+expanded+1835008+131072: break
    assert proof['committedBlobVerified'] and proof['sha256']!=files[core]
    selected.append(proof)
    available+=proof['bytes']
assert available>floor+expanded+1835008,(available,expanded)
config=dict(root=root,unit=unit,source=old['root'],sourceRole='reference',sourceFiles=current['auxiliaryFiles'],
    sourceCatalogSHA256=old['catalogSHA256'],catalogSHA256=catalog_hash,identity=current,retireGroups=selected,
    donorArchiveSHA256=receipt['archiveSHA256'],payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),
    unpackedBytes=expanded,cpythonWorkerSHA256=protocol_hash)
save('config.json',config)
launcher=read(template/'remote-launch.py')
start,end=launcher.index('\nc=')+1,launcher.index('\nb=Path(')
launcher=launcher[:start]+'c='+repr(config)+launcher[end:]
write('remote-launch.py',launcher.replace('lython-b1156-fixtures','lython-b1162-fixtures')
    .replace('RuntimeMaxSec=245','RuntimeMaxSec=430').replace('182452224',str(floor)))
print('Verified current complete image and all four CPython goldens. Ten phase/workload pairs prepared.')
