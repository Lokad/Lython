set -eu
root=/home/lokad/lython-bench-checks/nov20-cpython-b1162-20261120
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
