from pathlib import Path
import datetime, hashlib, json, shlex, subprocess

home=Path(__file__).parent
payload=(home/'payload.tgz').read_bytes()
script=(home/'launch-command.py').read_text()
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
stage='/home/lokad/lython-bench-checks/dictionary-cpython-b539-launch.py'
code='from pathlib import Path; import sys; p=Path('+repr(stage)+'); assert not p.exists(); p.write_bytes(sys.stdin.buffer.read())'
done=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=script.encode('utf-8'),capture_output=True)
assert done.returncode==0,done.stderr
done=subprocess.run(ssh+['python3 '+stage],input=payload,capture_output=True)
(home/'launch.log').write_bytes(done.stdout+b'\n'+done.stderr)
print((done.stdout+done.stderr).decode('utf-8'),flush=True)
assert done.returncode==0
assert b'ActiveState=active' in done.stdout and b'MainPID=0' not in done.stdout
now=datetime.datetime.now(datetime.timezone.utc)
(home/'observe-not-before.json').write_text(json.dumps(dict(acknowledgedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=420)).isoformat(),ownerSeconds=360,stopSeconds=30,marginSeconds=30),indent=2)+'\n',encoding='utf-8')
print('New B539 owner verified live; observe after', (now+datetime.timedelta(seconds=420)).isoformat(),flush=True)
