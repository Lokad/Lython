from pathlib import Path
import datetime,hashlib,json,subprocess,tarfile
root=Path(__file__).resolve().parent
assert not (root/'terminal-status.json').exists(), 'Do not requery a recorded terminal run.'
b=json.loads((root/'observe-not-before.json').read_text())
assert datetime.datetime.now(datetime.timezone.utc)>=datetime.datetime.fromisoformat(b['doNotObserveBeforeUTC'])
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
script='''from pathlib import Path
import fcntl,hashlib,json,subprocess
root=Path('/home/lokad/lython-bench-checks/dictionary-cpython-b539-20261110')
lease=(root.parent/'comparison-vm.lock').open('a');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
service=subprocess.run(['systemctl','show','lython-b539-dictionary-cpython-20261110.service','--property=ActiveState,SubState,MainPID,Result,ExecMainStatus'],text=True,capture_output=True)
print(json.dumps({'service':service.stdout,'serviceError':service.stderr,'exitCode':(root/'exit-code.txt').read_text().strip() if (root/'exit-code.txt').exists() else None,'receipt':json.loads((root/'archive-receipt.json').read_text()) if (root/'archive-receipt.json').exists() else None,'remainingWorkers':subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True,text=True).stdout,'remainingFixtures':[str(p) for p in Path('/dev/shm').glob('lython-comparison-files-*')],'ownedRamRemaining':(root/'guest-fixtures').exists()}))
'''
r=subprocess.run([*ssh,'python3 -'],input=script,text=True,encoding='utf-8',capture_output=True)
(root/'observation.json').write_text(r.stdout,encoding='utf-8');assert r.returncode==0,r.stderr
status=json.loads(r.stdout);print(status,flush=True)
assert status['exitCode']=='0' and status['receipt']['complete'] and status['receipt']['jobs']==9
assert not status['remainingWorkers'] and not status['remainingFixtures'] and not status['ownedRamRemaining']
assert 'MainPID=0' in status['service'] and 'ActiveState=active' not in status['service']
(root/'terminal-status.json').write_text(r.stdout,encoding='utf-8')
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for name in ['observations.tgz','archive-receipt.json']:
    p=subprocess.run([*scp,'lokad@20.166.121.73:/home/lokad/lython-bench-checks/dictionary-cpython-b539-20261110/'+name,str(root/name)],capture_output=True,text=True,encoding='utf-8')
    assert p.returncode==0,p.stderr
receipt=json.loads((root/'archive-receipt.json').read_text(encoding='utf-8'))
assert hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
destination=root/'retrieved';destination.mkdir()
with tarfile.open(root/'observations.tgz') as a:a.extractall(destination,filter='data')
print('Retrieved and verified',receipt,flush=True)

