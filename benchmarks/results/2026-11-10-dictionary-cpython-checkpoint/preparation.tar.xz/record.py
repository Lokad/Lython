from pathlib import Path
import json, shutil, tarfile

root = Path('D:/code/Lython')
p = Path(__file__).parent / 'b539'
dest = root / 'benchmarks/results/2026-11-10-dictionary-cpython-checkpoint'
dest.mkdir(exist_ok=True)
data = json.loads((p / 'summary.json').read_text(encoding='utf-8'))
assert data['complete'] and data['jobs'] == 9
for name in ['observations.tgz', 'archive-receipt.json', 'terminal-status.json',
             'summary.json', 'identity.json', 'source-equivalence.json',
             'core-source.json', 'prior-BENCHMARKS.md', 'space-recovery-refined.json',
             'initial-space-refusal.json', 'observe-not-before.json', 'launch.log']:
    shutil.copyfile(p / name, dest / name)
with tarfile.open(dest / 'preparation.tar.xz', 'w:xz') as archive:
    for name in ['collect.py', 'retrieve.py', 'summarize.py', 'launch.py',
                 'launch-command.py', 'archive-owned.py', 'run.sh', 'contract.md',
                 'selection.md', 'sizing.json', 'setup-contract.json',
                 'source.patch', 'focused.json', 'delivery-ci-status.json',
                 'pre-measurement-plan.md', 'space-recovery-command.py',
                 'space-recovery-refined-command.py', 'space-recovery.log',
                 'space-recovery-refined.log', 'exact-copies.json', 'exact-copies-refined.json']:
        archive.add(p / name, arcname=name)
    archive.add(Path(__file__), arcname='record.py')

def rr(values, digits):
    a, b = min(values), max(values)
    x, y = f'{a:.{digits}f}', f'{b:.{digits}f}'
    return x if x == y else f'{x}–{y}'

rows = []
for r in data['timing']:
    rows.append(f"| {r['case']} | {r['lane']} | {rr(r['timeRangeMilliseconds'],4)} | "
                f"{rr(r['pythonTimeRangeMilliseconds'],4)} | {rr(r['ratioRange'],2)}× | "
                f"{r['status']}; L{r['controlPercent']:.2f}%, P{r['pythonControlPercent']:.2f}% / "
                f"{max(r['iqrPercent'].values()):.2f}% |")
readme = '''# R190-source CPython checkpoint

2026-11-10. Committed source e5731404, measured precommit core e364e4d9 from the
existing nonincremental private freeze. All567 production source files match main
after explicit EOL normalization; no postcommit binary identity or arbitrary later
HEAD measurement is implied. [Source proof](source-equivalence.json) and exact
[image identity](identity.json) preserve this distinction. Local ordinary and
installed Release consumers pass; CI42783134761 original Stress was pending at
the collection snapshot. Final delivery qualification is recorded separately.

F4as_v7 Ubuntu24.04.4, four AMD EPYC9V45 vCPUs,16GiB/no swap, actual.NET11RC3,
stock isolated CPython3.13.16. Same workers/adapter0.4/dependencies/scripts/goldens
as the preceding checkpoint. Four independent processes/job, two per engine;
five-second warmup/role, seven rotated150ms rounds, ordinary GC/tiering.

| Complete script | Lane | Lython ms | CPython ms | Lython / CPython | Status; control / max IQR |
| --- | --- | ---: | ---: | ---: | --- |
''' + '\n'.join(rows) + '''

Ratios above one mean slower. All four process-median pairings, not confidence
intervals. L/P indicate absolute same-engine process-median spread. Diagnostic/
Variable describe observed stability, not design acceptance rules. Text compile
IQR3.52%, warm L spread2.22%, complete L spread3.21% and search complete P spread
2.03% remain visible. No retiming or single-change attribution selected here.

Compile constructs/disposes code under the borrowed allowance, without guest I/O.
Warm reuses code; compile-run compiles once and executes once. Both execution
lanes include efficient mediated RAM-file I/O, complete stdout/file validation and
prior-result cleanup. Fixture reset/staging, protocol, process startup and final
cache teardown are excluded. Lython applies capability/path checks and isolated
imports; CPython uses builtin open and retains imported modules. Independent phase
medians need not add up. Wider process CPU includes reset/protocol and is not an
internal execution-cost measurement. Pending I/O, RSS and embedding tail latency
remain unmeasured. Search stops at1025/2049 lines; it is the keyword/default variant,
not the historical literal-prefix source.

Nine jobs complete246.994seconds. All identity/output/ownership/quiet checks pass;
workers are joined, owned RAM removed, persistent archive created/verified under
lease and SHA verified locally. [Receipt](archive-receipt.json), [terminal state](terminal-status.json),
[raw evidence](observations.tgz), [collection/source/setup](preparation.tar.xz),
[all results](summary.json). The original insufficient-space condition and refined
exact-copy retirement receipt remain; only canonically archived terminal copies
were retired, preserving current/reference images. No restart or abandoned user.

The [previous guide](prior-BENCHMARKS.md) preserves historical observations.
Publication remains postponed; normal optional-adapter pins remain unchanged.
'''
(dest / 'README.md').write_text(readme, encoding='utf-8', newline='\n')

doc = root / 'docs/BENCHMARKS.md'
s = doc.read_text(encoding='utf-8')
names = {'CSV validation/helper calls': 'scripts.csv-validated-records.large',
         'Text summary/helpers': 'scripts.text-summary-helpers.large',
         'File search / keyword-default helper': 'scripts.file-search.large'}
lane = 'compile-run'
out = []
for line in s.splitlines():
    if line.startswith('## Warm execution'): lane = 'warm'
    if line.startswith('Compilation alone includes'): lane = 'compile'
    if line.startswith('Startup, RSS'): lane = None
    label = line.split('|')[1].strip() if line.startswith('|') else None
    if label in names and lane:
        r = next(r for r in data['timing'] if r['case'] == names[label] and r['lane'] == lane)
        digits, factor, unit = (1, 1000, 'µs') if lane == 'compile' else (3, 1, 'ms')
        l = rr([v*factor for v in r['timeRangeMilliseconds']], digits)
        py = rr([v*factor for v in r['pythonTimeRangeMilliseconds']], digits)
        inp = line.split('|')[2].strip() if lane == 'compile-run' else None
        prefix = f'| {label} | ' + (f'{inp} | ' if inp else '')
        line = prefix + f"{l} {unit} | {py} {unit} | {rr(r['ratioRange'],2)}× | `e573` | " + \
            f"{r['status']}; L{r['controlPercent']:.2f}%, P{r['pythonControlPercent']:.2f}% / " + \
            f"{max(r['iqrPercent'].values()):.2f}% |"
    out.append(line)
s = '\n'.join(out) + '\n'
s = s.replace('`3a41` = `3a413c59`-equivalent qualified production,',
              '`e573` = committed `e5731404` production source,')
s = s.replace('2026-11-10-combined-cpython-checkpoint/README.md)',
              '2026-11-10-dictionary-cpython-checkpoint/README.md)', 1)
s = s.replace('reuses precommit core `26d43e66`; all 564 production sources match the qualified\nrevision after explicit Git checkout line-ending normalization.',
              'reuses precommit core `e364e4d9`; all 567 production sources match the committed\nrevision after explicit Git checkout line-ending normalization.')
s = s.replace('Current core `26d43e66`', 'Current core `e364e4d9`')
start = s.index('The three current workloads complete nine jobs')
end = s.index('Original literal-prefix search, report and config', start)
s = s[:start] + '''The three current workloads complete nine jobs in246.994seconds with all
identity, output, ownership, quiet, joined-worker and archived-evidence checks
passing. Warm text remains1.45–1.48× CPython, keyword-default search1.50–1.52×,
and CSV validation about1.07×. Compilation ranges0.91× to1.08×.

Text compile max IQR3.52%, warm Lython spread2.22%, complete Lython spread3.21%
and complete search CPython spread2.03% remain explicit. All pairings and adverse
observations are retained. These measurements do not isolate a change's benefit
or establish equivalence or statistical significance.

''' + s[end:]
s = s.replace('2026-11-10-combined-cpython-checkpoint/prior-BENCHMARKS.md)',
              '2026-11-10-dictionary-cpython-checkpoint/prior-BENCHMARKS.md)')
s = s.replace('Search source differs from the main CPython row.',
              'A separate earlier source pair, not attribution from the current CPython rows.')
doc.write_text(s, encoding='utf-8', newline='\n')

exp = root / 'benchmarks/EXPERIMENTS.md'
s = exp.read_text(encoding='utf-8')
at = s.index('The [R190 native dictionary accumulation]')
s = s[:at] + '''The [R191 CPython refresh](results/2026-11-10-dictionary-cpython-checkpoint/README.md)
measures committed e5731404-equivalent frozen e364 on the same three complete
scripts across compile/warm/compile-to-result. Nine jobs246.994s, all gates pass;
warm CSV about1.07×CPython, text1.45–1.48×, keyword-default search1.50–1.52×.
Text/search variability and previous adverse/control observations remain. This
is not a single-change attribution; delivery CI is recorded separately.

''' + s[at:]
exp.write_text(s, encoding='utf-8', newline='\n')
plan = root / 'PLAN.md'
s = plan.read_text(encoding='utf-8')
s = s.replace('R191/B539 is actively refreshing those same three scripts × compile/warm/compile-to-result on frozen e364, CPython3.13.16/.NET11RC3. Results not yet available.',
              'R191/B539 complete9jobs/246.994s, all gates/SHA pass: e573-equivalent e364 warm CSV1.07×, text1.45–1.48×, keyword-default search1.50–1.52×; compile0.91–1.08×. docs/BENCHMARKS.md now reflects this checkpoint, with text/search variability explicit.')
s = s.replace('Retrieve already-owned R191/B539 only after its recorded observation bound.',
              'R191/B539 is terminal, archived/SHA-verified; docs refreshed. Do not requery/restart. Completed acceptance:')
plan.write_text(s, encoding='utf-8', newline='\n')
print('R191 evidence and current guide recorded.')
