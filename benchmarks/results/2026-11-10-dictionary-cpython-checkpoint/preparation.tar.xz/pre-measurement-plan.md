# Lokad.Lython 0.11.0

Updated 2026-11-10. Git-ignored; never force-add. Publication and tagging remain
postponed. The objective is coherent simplification and substantial whole-script
performance improvement, not completion of a succession of isolated experiments.
Current contracts belong in docs/. Detailed history and adverse measurements live
in [EXPERIMENTS](benchmarks/EXPERIMENTS.md) and immutable benchmarks/results/.
The preceding delivery ledger is retained privately under
.git/agent-notes/review-20261031/shared-call-binding-r184/plan-before-b532.md.

## Delivery status

| Milestone | Actual status |
| --- | --- |
| Shared compiler facts; direct UTF-8 formatting/storage; native helper returns | Committed and fully qualified. Native-return allocation fell 19.92% sync / 19.31% async; original elapsed gains were diagnostic. Formatting allocation fell 8.67%; controlled B102 elapsed and CPU improved about 5–8%. The original adverse 15.125 ms observation remains unexplained and preserved. No further unchanged qualification is needed. |
| R178/R179: completed JSON storage and closed helpers inside caller handlers | Production ee448715; fully qualified by cached GREEN CI 42727417102 on Windows/Ubuntu, actual .NET 11/10, original Stress and installed Release consumers. JSON allocation −3.04/−3.03%, elapsed inconclusive. Handler shortcut allocation −47.31/−47.29%, controlled elapsed/CPU about 18–22% lower. Capacity tradeoffs and adverse controls are recorded. |
| Historical CPython checkpoint R181 | Complete: 15 jobs / 409.135 seconds, production core b49e50a6, CPython 3.13.16, .NET 11 RC3, quiet F4as_v7. docs/BENCHMARKS.md separates compilation, warm execution and compile-to-result, with I/O/cleanup boundaries. Warm text is 1.62–1.69× CPython; search about 1.58×. Variable and historical rows remain explicit. |
| Current CPython checkpoint R186 | Complete9jobs/247.200s, qualified3a413c59-equivalent core26d43e66, CPython3.13.16/.NET11RC3. Warm CSV1.09–1.11×, text1.64–1.71×, keyword-default search1.51–1.52×; compile0.93–1.08×. Explicit controls and old historical rows retained; no single-change attribution. |
| Withdrawn R174–R180 | Integer wrappers, call control/arena and generic-prefix replacement are absent. R180 reduced helper-CSV allocation 42.95% but retained roughly 29–53% text CPU regression after refinement. Qualified native shortcuts remain. Frozen sources, failures and adverse controls survive; these outcomes are not permanent architecture vetoes. |
| Withdrawn R183 routing consolidation | Focused semantics pass, allocations flat. Initial modest text/search gains conflicted with adverse Unicode/report controls. Unchanged-source B531 confirmation finished in 111.356 seconds; ranges overlap zero. The extra dispatch/completion protocol did not remove enough work to justify promotion. That prototype was not promoted; its source/evidence is preserved. |
| R184 shared binding and closed named/default native entry | Committed 32d1ea1a; fully qualified GREEN 42758271911 (Windows/Ubuntu, actual11/10, original Stress, installed Release consumers). One Span/presence fill replaces the array-only binder; a small managed inline destination bypasses owned binding/activation for proven closed helpers. Existing exact-positional native calls and general dynamic/async binding remain. Focused checks: 715 public / 82 internal per actual target, including an actual runtime-defined helper executing with further admission denied. Main separately retains 29 default/alias/cancellation/refusal regressions per target. |
| R184 measurements | Desktop search allocation about −0.05%; elapsed +5.46–8.31%, unresolved. Compilation allocation flat; elapsed diagnostic. B532 finished 112.099 seconds, all ownership/output/quiet/archive checks passed. Keyword-default search elapsed −15.7–21.5%, wider CPU −15.4–18.8%; gain survives the 6.75% reference spread. Text/CSV controls remain inconclusive with possible small debt. Retain source change; no general gain/equivalence claim. |
| R185 empty/unbound storage | Committed 3a413c59. Removes UninitializedLocal, per-entry Array.Fill and empty class namespace placeholder. Corrected focused checks3124public/432internal eachactualtarget; main123public pertarget. B533 CSV CPU−1.22–4.71%, controls overlapzero; desktopadversity retained. Full delivery42761050500 GREEN/cached: Windows/Ubuntu, actual11/10, original Stress and installed Release consumers. |
| R188 local-only integer storage | Both variants withdrawn after original/refined complete-script comparisons; only semantic/cancellation regressions retained. Current production source unchanged. Evidence372010d2/ff97272b. |
| Main / regex | Mainc33a6048 contains R184/R185, evidence and retained regression tests; newest fully-qualified runtime is3a413c59. Normal0.4 pins remain unchanged. Supplied immutable dev64 is development-qualified86internal/524public eachtarget on a byte-identical dev59 bridge. Three precise producer API gaps persist; only affected final adapter qualification waits. |

Qualification42727417102,42758271911 and42761050500 is terminal GREEN/cached;
never query them again. R184/R185 full Windows/Ubuntu, actual11/10, original Stress
and installed Release consumers passed. B530–B533 are terminal/locallySHA-verified.
B534/B535/B536/B537 are terminal/SHA-verified; comparisons9/3/4jobs and two current CPU profiles complete, no remaining VM users/RAMfixtures. Never restart terminal owners or requery cachedGREEN CI.
## Priority 1: native dictionary accumulation (R190)

**Delivery remains qualified3a413c59 runtime.** Maine5731404 contains R188/R189/R190 evidence
and useful tests, with no sidecar/runtime promotion. R188 original/refined allocation
falls14%text/18%search; B535112.766s/B536148.225s leave CPU uncertain/adverse outside
a slight search gain. Both prototypes are withdrawn after explicit architecture/
CSV/report/capacity debt assessment, not a percentage veto. Eleven semantic cases
and four counter-loop cancellation cases remain;98focused main checks pass per
actual11/10 after forced builds. Full frozen sources/adversity and exact retirement
proof survive in benchmarks/results/2026-11-10-integer-local-storage/.

**R189 complete:** current-qualified26d/core3a CSV/text attribution captures11.888s;
1193/1145guest samples, unknown leaves5.95/4.89%. Text binding/activation is not
observed. Text dictionary/subscript187samples(16.33%), text248(21.66%) and VM
transport381(33.28%, includes250prefix leaves) are material leads. CSV binding3.60%,
activation4.19%, parser/record/source and VM remain. Inclusive groups include useful
work, not removable taxes. B537 passes all identity/output/quiet/join/map/archive/
SHA gates; terminal cached, no users/RAMfixtures. Evidence:
benchmarks/results/2026-11-10-current-call-transport-attribution/.

**Selected coherent change:** d[k] = d.get(k,default) + increment. Current code
performs a native get/probe, publishes an intermediate value, adds and probes/stores
again. Actual maintained CSV/text compile to adjacent Call → Binary(Add) →
StoreSubscript. Prepare one guarded native accumulation using existing callsite
facts, table publication and integer preflights, eliminating the second hash/probe
and intermediate dispatch/transport. No new engine/dispatcher, cache, argument arena,
integer sidecar, owner/pool/policy or universal value representation. Keep generic
operations for real dynamic cases. No CPU gain is forecast from sample shares.

R190 isolated tree/milestone:
.git/agent-notes/review-20261031/native-dictionary-accumulation-r190/.
Actual source gate confirms receiver/key/increment/result/live positions for both
scripts; temporary instruction-inspection test is removed, captures/source/failure
and correction retained privately. Isolated implementation is active; no runtime promotion yet. Compile facts
must prove same exception region and safe physical inputs; runtime checks actual
method identity, native PyDict/PyString/no protocol keys, matching assignment aliases,
same funded owner/writable capacity and small exact integer result before effects.
No major admission/callback may occur inside the guarded region. Wide/growth/bridge/
protocol/shadowed/noninteger cases keep existing execution before effects. Never
fallback after mutation or refused admission; use original preflights, not duplicate
integer arithmetic or a persistent prepared-query cache.

Acceptance: independent Python aggregates, aliases/identity, defaults/overflow and
mixed values, method/receiver/key shadowing, callbacks/evaluation order and mutation
on admission, actual async protocols, current-token key scans/cancellation, terminal
refusal before mutation, retained funding/results, budget reuse, managed stack and
joined cleanup. Preserve original call/arithmetic/store spans, protected handlers,
outer iterators and pending disposal/store continuation. Success must actually
remove the duplicate probe/transport. Stop/refine if speculation/lifetime machinery
becomes disproportionate; do not silently narrow Python behavior.

B538 completed110.923s, threejobs, all checks/SHApassed. Text elapsed−10.90..14.92%
with widerCPU−8.80..14.29%; CSV elapsed−1.08..5.14%, CPU−1.18..3.38%. Report
control−0.74..+2.30%elapsed/0..+3.03%CPU remains uncertain/debt. Allocationflat;
compiletargetbytes+0.05..0.07%. Original desktopadversity retained. Retain the
coherent source change for delivery, with no general CPU/neutrality claim.
Full private ordinary Release actual11/10 passes16988public/4473internal pertarget
after forced solution build; full platform/Stress/installed-package follow at this retained boundary.
Use this coherent milestone for a targeted existing CPython refresh after source
is stable, without repeating old unchanged qualification. Publication stays off.

R190 currently passes530public focused cases peractual11/10, including twelve
independentPython goldens, retained funding, true suspension/cancellation and
terminal wide-addition refusal. Both operands are restricted to signed bytecounts
under8, which proves the original addition preflight cannot call admission.
Internal checks and existing short warm/compile diagnostic follow.

Focused actual11/10 first; existing five-script warm/compile diagnostic with CSV/
text targets and report/search/config controls. Bounded quiet confirmation/refinement
only as justified, retaining all adversity. Explicitly decide CPU/compile/capacity
debt. A timeout/unstable control means uncertainty, not design failure. Fixed
percentages inform rather than veto. Full platform/Stress/installed-package at a
retained runtime boundary. The broader roadmap and regex work remain independent;
publication/tagging stay postponed.

## Priority 2: select and deliver a substantial redesign

**Completed R184/R185:** shared binding now serves owned and managed-inline
native calls; cleared storage supplies one unbound local/cell state. No new binder,
owner, pool, cache, policy or execution route. Original missing-name failures and
read-order correction, desktop adversity and quiet controls survive in
benchmarks/results/2026-11-10-shared-call-binding/ and
benchmarks/results/2026-11-10-unbound-storage/. Source simplification, negligible
allocation change and targeted/modest CPU gains remain separate. Do not repeat
these completed source migrations or treat them as the whole performance objective.

**CSV reassessment:** B74's 6–8% construction opportunity was subsequently revised
and retained (c23d1a10/8f07764a), then extended with private row arrays and shared
record keys. Current code already removes its cursors, per-field scopes, growth
and wrappers; native input also compacts its owned buffer in place. Do not replay
B74. A different remaining construction saving is required before another trial.
The exact patch/current source/reentry constraints are recorded in
benchmarks/results/2026-11-10-record-construction-assessment/.

Use existing attribution rather than start another broad campaign. R182 validated
CSV: VM prefix including useful/inlined work 47.01%, parser/construction 14.41%,
admission 6.88%, binding 4.50%, activation 4.42%, context initialization one sample.
R166 text: VM 38.71%, text 23.37%, dictionary 8.37%, scalar 6.36%. These are
inclusive/innermost observations, not removable-tax estimates.

1. **Complete call/frame construction and operand transport.** Assess binding,
   initialization, activation and transport together. Bound arguments already
   share final locals; workspaces, direct operands, deferred contexts and native
   helpers already exist. Select only a design eliminating additional actual work,
   with a concrete displaced implementation. Do not reintroduce withdrawn arenas,
   call-control protocols, dispatch-only forwarding or integer wrappers. Preserve
   dynamic binders/live metadata, argument read spans/effects and async ownership.
   Compare complete CSV/helper/report scripts with text/search/Unicode controls;
   compilation stays separate. Completion requires deleting the displaced path
   and deciding remaining regression debt, not merely adding a new fast path.

2. **Per-record construction.** Reassess historical 6–8% bulk-CSV gains against
   current code, not old thresholds. Parsing already adopts arrays, bulk-admits
   fragments and shares record keys. Withdrawn growth increased allocation 8.42%
   and CPU 4.3–6.2%. Confirm only a different identifiable saving. Preserve custom,
   duplicate/wide/mutating headers, insertion order, reentry, retained records and
   preflight rollback. Use complete CSV aggregation and retained-record scripts,
   with an unchanged text control; remove the displaced construction route.

3. **Remaining text conversions and scalar dispatch.** Identify material remaining
   conversions/boxing from profiles and source before implementation. Bulk UTF-8
   casing, final-word splitting, formatting and completed JSON transfers already
   work. JSON GetString preserves invalid-UTF8 errors. Favor removing intermediate
   storage and duplicate dispatch over universal value-representation replacement.
   Preserve Unicode expansion/context, Python protocols/identity, overflow,
   cancellation and admission. Validate complete text/JSON/report work plus controls.

4. **Repeated frontend analysis.** Current passes compute distinct facts; do not
   collapse them based on names alone. Reuse measured duplicate work/facts and
   remove the displaced analysis/retained representation. Compare compilation and
   compile-to-result on new scripts, not cache hits; warm execution is a control.
   Diagnostics, scoping, closures/imports and provider semantics must stay stable.

**Completed preliminary gates / continuing roadmap:** examine complete builtin/call/operand consumers and current
record/text/value representations together, with the profiles below as leads.
Current source already shares ordinary builtin callables and immutable signatures;
mutable builtin types retain perrun isolation. Arguments already occupy final local
capacity; closed helpers bypass frame construction; dynamic binding and pending
protocols still have real consumers. Do not repeat those absent-cost optimizations.
General CallBinder still creates final arrays and array-only delegate signatures,
but default JSON loads/dumps already bypass it; small integers already use coarse
storage headroom. Do not migrate hundreds of signatures or add an integer policy
on the assumption those common costs remain. Identify actual affected ordinary
scripts and displaced work before coding. If the proposed cost is absent, record
the bounded finding and move to the next measured cost, rather than manufacture a
new fast path. Generic-prefix and call-arena CPU regressions remain design lessons.

For a selected redesign, record hypothesis, eliminated work/storage, affected
scripts, semantic criteria, measurement boundary and completion milestone before
editing. Stop an investigation when the current source disproves the supposed
cost or a bounded comparison supports a decision. Inconclusive controls/timeouts
permit bounded confirmation or measurement repair; they are not failed designs.
Fixed percentages inform decisions rather than automatically veto simplification.

## Independent regex track

Continue the Lython-owned Python contract: native UTF-8 names/data, byte ranges,
scalar positions, original-subject windows, captures/replacements/errors, effective
flags, current operation tokens and explicit pattern/cache/result ownership. Use
one provider for frontend/runtime/imports. No backend types/dependencies enter core.
Development producers and adapter-local bridges support testing independently.
R187 verifies immutable0.5.0-dev.64/9af7141f on current qualified runtime, with
86internal/524public focused checks per actual target and no bridge changes.
Evidence: benchmarks/results/2026-11-10-regex-dev64/. No backend speedup/safety
certification or normal-pin promotion follows; do not repeat unchanged qualification.

Dev.64 still lacks a separate single-match working owner, native group-name
enumeration, and token-independent cursor creation despite per-move tokens. Track
each missing capability precisely. Only affected final released-adapter safety,
semantics and performance qualification is deferred. Qualify changed paths with a
cooperating provider: actual in-flight cancellation, refusal, retained caches/results
and budget reuse. Report real-adapter limitations; entry/exit checks do not prove
interruption. Do not repeat unchanged qualification or promote a speculative pin.

## Measurement and delivery

CPython is the primary external baseline; revision improvements remain separate.
Identify exact source/core/reference/date/machine, included I/O, validation and
cleanup. Separate compilation, warm execution, compile-to-result and startup.
Distinguish architectural simplification, allocation savings and demonstrated CPU
improvement. Preserve all original adverse observations and failed conditions.
Temporary regressions require an explicit completion milestone/debt decision.
Size short comparisons for usable observations on the existing quiet VM; reuse
workers/tooling and avoid another framework or open-ended qualification campaign.
Refresh CPython at coherent retained checkpoints/material gaps, not after every
isolated experiment. Focused Release checks during development; batch established
Windows/Ubuntu, actual .NET 11/10, original Stress and installed-package qualification
at retained delivery boundaries. Do not wait idle for CI.

## Lasting constraints

Follow AGENTS.md. Fully managed/memory-safe: no unsafe C#/compilation/Unsafe APIs,
pointers/PInvoke/native stack probes. Preserve managed stack/recursion protection,
host mediation, cancellation and cycle detection. No execution fuel, host quotas,
watchdogs, independent memory/string/collection/read/output caps or hidden allowance.
Keep checked representation limits, XML depth and bounded I/O chunks.

Borrowed-root coarse admission funds capacity, replacement overlap, caches,
escaping results/aliases and pending users through awaited cleanup. First refusal
is terminal with its first structured origin; no retries, skipped optional storage,
heap tracing, weak reclamation, forced GC or abandoned operations. No new memory
infrastructure. Long streams use bounded host-driven executions.

Force nonincremental builds after timestamp-preserving restores and before freezing.
Never overlap local builds/tests/timings. Space CI checks at least five minutes;
cache terminal results. Only core Release packages via tools/pack.ps1 go to
artifacts/nuget; the adapter remains nonpackable. VM lokad@20.166.121.73 uses
~/.ssh/id_lython-bench.pem. Evidence/workers stay persistent, guest fixtures separate;
join/unmount/archive under ownership and verify local SHA. No sole evidence or
active/current-baseline image is retired. Preserve exact-copy recovery receipts and avoid
reprobing known-retired paths or restarting terminal owners.

Known retired VM copies: B535 recovery retired all f8995f65 and b49e50a6 aliases;
B536 recovery retired original76c646d9 and its duplicate B535 compressed archive.
Canonical tracked evidence retains them. Current26d baseline survives; refinedb713 and its duplicate compressed archive are canonical-archived and retired for B537; do not probe retired paths or restart terminal collection owners.

R190 source e5731404 is committed/pushed. Full ordinary private Release passes
16988public/4473internal eachactualtarget. Main source is EOL-normalized-equivalent
to exact frozene364; unchanged-file raw-EOL proof correction is recorded.
Coherent delivery CI42783134761 is dispatched for Windows/Ubuntu, actual11/10,
originalStress and installedRelease consumers; do not query before 2026-11-10T08:37:38.008569+00:00.
