from pathlib import Path
import ast,base64,datetime,hashlib,json,subprocess,tarfile
base=Path(__file__).parent;r=base/'csv-cpython-r399';r.mkdir()
prior=base/'async-cpython-r393'
delivery=json.loads((base/'tuple-transport-r397/delivery/delivery-candidate.json').read_text(encoding='utf-8'))
identity=json.loads((base/'tuple-transport-r397/quiet/identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision=delivery['head']+'/frozen22e5b72c; all source inputs match after explicit newline normalization',runtimeCommit=delivery['head'],purpose='Representative CSV CPython checkpoint: synchronous Run, compilation-only and compile-plus-one-run invoice phases; fulfillment warm execution. Existing workers, host and complete goldens.',coreSHA256={k:v for k,v in identity['coreSHA256'].items()if k.startswith('candidate')},qualification='Committed/pushed tuple transport; full Win/Ubuntu11/10 stress/package CI43708277205 active',roleMeaning=dict(candidate=delivery['head'][:8],**{'candidate-control':delivery['head'][:8]}))
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
    s=(prior/name).read_text(encoding='utf-8').replace('async-cpython-b780-20261115','csv-cpython-b784-20261115').replace('lython-b780-async-cpython-20261115','lython-b784-csv-cpython-20261115').replace('B780','B784')
    s=s.replace("jobs=[['scripts.text-summary-helpers.nonlocal-counter.large', 'warm-async-vs-cpython-warm'], ['scripts.file-search.large.protected', 'warm-async-vs-cpython-warm']]", "jobs=[['scripts.csv-invoice.large','warm'],['scripts.csv-invoice.large','compile'],['scripts.csv-invoice.large','compile-run'],['scripts.csv-fulfillment.large','warm']]")
    s=s.replace("('warm' if label.startswith('CPython') else 'warm-async')","lane")
    s=s.replace('len(jobs)==2','len(jobs)==4').replace("len(raw['jobs'])==2","len(raw['jobs'])==4").replace("['jobs']==2","['jobs']==4").replace('jobs=2','jobs=4').replace("elapsedSeconds']<180","elapsedSeconds']<240").replace(' < 120,',' < 180,')
    s=s.replace('two-job','four-job').replace('async','synchronous') if name=='summarize.py' else s
    if name.endswith('.py'):ast.parse(s)
    (r/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(r/'payload.tgz','w:gz')as a:
    for name in ['identity.json','collect.py','archive-owned.py','run.sh']:a.add(r/name,arcname=name)
config=dict(root='/home/lokad/lython-bench-checks/csv-cpython-b784-20261115',source='/home/lokad/lython-bench-checks/tuple-transport-b782-20261115',unit='lython-b784-csv-cpython-20261115',identity=identity,payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((r/'payload.tgz').read_bytes()).hexdigest())
code='''from pathlib import Path
import fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
config=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['source']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert root.parent==base and not root.exists() and source.parent==base and source.resolve()==source
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(os.path.ismount(p)for p in base.glob('*/guest-fixtures'))
 state=subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=LoadState,MainPID'],text=True)
 assert 'LoadState=not-found'in state and 'MainPID=0'in state
 assert sha(source/'candidate/Lokad.Lython.dll')==config['identity']['coreSHA256']['candidate']
 for name,h in config['identity']['auxiliaryFiles'].items():assert sha(source/'candidate'/name)==h
 assert sha(source/'representative.json')==config['identity']['catalogSHA256']
 assert shutil.disk_usage(base).free>254*1024*1024+65536
 payload=sys.stdin.buffer.read(config['payloadBytes']+1);assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:a.extractall(root,filter='data')
 (root/'candidate').mkdir()
 for p in (source/'candidate').iterdir():assert p.is_file();os.link(p,root/'candidate'/p.name)
 os.link(source/'representative.json',root/'representative.json');os.link(source/'cpython-worker.py',root/'cpython-worker.py')
 fixture=root/'guest-fixtures';fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b784-fixtures',str(fixture)],check=True)
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=240','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True))
'''.replace('CONFIG',repr(config))
ast.parse(code);(r/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
cmd="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
p=subprocess.run(['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73',cmd],input=(r/'payload.tgz').read_bytes(),capture_output=True,timeout=30)
(r/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode()
now=datetime.datetime.now(datetime.timezone.utc)
(r/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=155)).isoformat(),ownerSeconds=240),indent=2)+'\n',encoding='utf-8',newline='\n')
print((p.stdout+p.stderr).decode(),flush=True);print('Observe same unit after',(now+datetime.timedelta(seconds=155)).isoformat(),flush=True)
