from pathlib import Path
import base64,hashlib,json,shutil,tarfile
r=Path(__file__).parent/'csv-cpython-r399';s=json.loads((r/'summary.json').read_text(encoding='utf-8'));t=json.loads((r/'terminal-status.json').read_text(encoding='utf-8'))
assert s['complete'] and s['jobs']==4 and t['receipt']['complete'] and not t['remainingWorkers'] and not t['remainingTrace']
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==t['receipt']['archiveSHA256']
out=Path('benchmarks/results/2026-11-15-csv-cpython-checkpoint');out.mkdir()
for name in ['summary.json','identity.json','terminal-status.json','archive-receipt.json','observations.tgz']:shutil.copyfile(r/name,out/name)
with tarfile.open(out/'procedure.tar.xz','w:xz')as a:
    for name in ['collect.py','archive-owned.py','retrieve.py','summarize.py','launch-command.py','launch.log','identity.json','run.sh']:a.add(r/name,arcname=name)
    a.add(Path(__file__),arcname=Path(__file__).name)
    a.add(Path(__file__).parent/'prepare-csv-cpython-r399.py',arcname='prepare-csv-cpython-r399.py')
catalog=json.loads(Path('.git/agent-notes/review-20261031/tuple-transport-r397/catalog.json').read_text(encoding='utf-8'))
for c in catalog['cases']:
    if c['id'] in ['scripts.csv-invoice.large','scripts.csv-fulfillment.large']:
        f=json.loads(c['fixtureJson']);print(c['id'],{k:len(base64.b64decode(v)) for k,v in f['inputFiles'].items()},'sourceUTF8Bytes',len(c['source'].encode('utf-8')))
print('B784 archived and independently verified; four measured phases, no remaining users/RAM, full source qualification still pending')
