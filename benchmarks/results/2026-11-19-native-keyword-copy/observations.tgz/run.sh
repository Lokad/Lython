set -eu
root=/home/lokad/lython-bench-checks/native-keyword-copy-b1036-20261119
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
