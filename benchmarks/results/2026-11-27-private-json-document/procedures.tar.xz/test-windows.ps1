$lab = Split-Path -Parent $MyInvocation.MyCommand.Path
$dotnet = Join-Path $env:USERPROFILE '.dotnet11/dotnet.exe'
$filter = 'Category!=Stress&(FullyQualifiedName~JsonRetainedTextTests|FullyQualifiedName~JsonTextStreamTests|FullyQualifiedName~JsonReadContinuationTests|FullyQualifiedName~JsonReaderReentrancyTests|FullyQualifiedName~JsonTrailingDataTests|FullyQualifiedName~JsonByteInputTests|FullyQualifiedName~JsonSuspendingCallbackTests|FullyQualifiedName~NativeJson|FullyQualifiedName~TextFile|FullyQualifiedName~SynchronousHostBorrowTests|FullyQualifiedName~GovernedMemoryContractTests|FullyQualifiedName~JsonWindowOwnershipTests|FullyQualifiedName~JsonDecodeAdmissionTests)'
foreach ($suite in @('Lokad.Lython.PublicApi.Tests','Lokad.Lython.Tests')) {
    & $dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --filter $filter --nologo --verbosity minimal 2>&1 | Tee-Object -FilePath "$lab/windows-$suite-net10.0.log"
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}

