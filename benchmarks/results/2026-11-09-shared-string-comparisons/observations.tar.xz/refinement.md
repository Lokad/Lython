Original R164 image/source/diagnostic retained. Five-script warm allocation nearly
flat; textelapsed+4.21to6.25%, search+1.76to3.09%, configcontrol10.38% apart. No CPU
claim or demonstrated cause. Source review finds context-free dictionary comparers
entering a token-aware loop with no context. Keep their existing short pure primitive;
bounded overloads apply with actual context. JSON bridge must preserve existing
guest-hook availability; corrected nested-tuple regression and frozen-image mutation
proof distinguish this from the initial forced-suppression prototype. One bounded
changed-source diagnostic confirmation, same baseline/driver/controls. No VM campaign.
