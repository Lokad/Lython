from pathlib import Path
import shutil
r=Path(__file__).parent;f=r/'final';f.mkdir(exist_ok=False)
shutil.copytree(r/'images/before',f/'images/before')
for n in ['baseline-revision.txt','baseline-proof.json','catalog.json']:shutil.copyfile(r/n,f/n)
for n in ['measure.py','assess-local.py']:
 s=(r/n).read_text(encoding='utf-8').replace("r.parent/'bulk-whitespace-r157/tool/out/complete-jobs.dll'","r.parent.parent/'bulk-whitespace-r157/tool/out/complete-jobs.dll'")
 (f/n).write_text(s,encoding='utf-8')
(r/'refinement.md').write_text('''Original R164 image/source/diagnostic retained. Five-script warm allocation nearly
flat; textelapsed+4.21to6.25%, search+1.76to3.09%, configcontrol10.38% apart. No CPU
claim or demonstrated cause. Source review finds context-free dictionary comparers
entering a token-aware loop with no context. Keep their existing short pure primitive;
bounded overloads apply with actual context. JSON bridge must preserve existing
guest-hook availability; corrected nested-tuple regression and frozen-image mutation
proof distinguish this from the initial forced-suppression prototype. One bounded
changed-source diagnostic confirmation, same baseline/driver/controls. No VM campaign.
''',encoding='utf-8')
print('Original image preserved; final changed-source diagnostic prepared.')
