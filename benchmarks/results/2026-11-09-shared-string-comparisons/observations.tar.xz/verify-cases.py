from pathlib import Path
import json,subprocess,textwrap
r=Path(__file__).parent;rows=[]
def verify(label,source,expected=None):
 x=subprocess.run(['C:/Python313/python.exe','-X','utf8','-I','-c',source],capture_output=True,text=True,encoding='utf-8');assert x.returncode==0,x.stderr
 if expected is not None:assert x.stdout==expected,(label,x.stdout,expected)
 rows.append(dict(label=label,source=source,stdout=x.stdout,stderr=x.stderr));return x.stdout
s=Path('tests/Lokad.Lython.Tests/JsonSortedComparisonTests.cs').read_text(encoding='utf-8')
source=textwrap.dedent(s.split('const string source = """',1)[1].split('"""',1)[0]).strip()+'\n'
verify('nested-json-comparison-hook',source,"{} True\n")
p=Path('tests/Lokad.Lython.PublicApi.Tests/ComparisonValueTests.cs');s=p.read_text(encoding='utf-8')
source=textwrap.dedent(s.split('{ "native_utf8_boundaries", """',1)[1].split('"""',1)[0]).strip()+'\n'
expected=json.loads((r.parent/'scalar-comparison-r163/scalar-strings-cpython.json').read_text(encoding='utf-8'))['stdout'];verify('native-values-methods-structural',source,expected)
source=r'''import json,difflib
first='a'*4095+'\ue000'
second='a'*4095+'\U00010000'
print(list(json.loads(json.dumps({second:2,first:1},sort_keys=True)).values()))
print(difflib.get_close_matches('a',['é','ä'],n=2,cutoff=0))
print(len(repr({first,second})))
'''
expected=verify('native-sorting-rendering',source)
entry='''        { "native_utf8_sorts", """
'''+''.join('            '+line+'\n'for line in source.splitlines())+'''            """, """
'''+''.join('            '+line+'\n'for line in expected.splitlines())+'''            """.ReplaceLineEndings("\\n") + "\\n" },
'''
assert 'native_utf8_sorts'not in s;s=s.replace('        { "native_utf8_boundaries",',entry+'        { "native_utf8_boundaries",',1);p.write_text(s,encoding='utf-8',newline='\n')
(r/'python-proof.json').write_text(json.dumps(dict(reference=subprocess.check_output(['C:/Python313/python.exe','--version'],text=True).strip(),cases=rows),ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print([(x['label'],x['stdout'][-80:])for x in rows])
