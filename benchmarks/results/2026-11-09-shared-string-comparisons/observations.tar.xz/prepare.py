from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).parent;old=r.parent/'scalar-comparison-r163'
shutil.copytree(old/'images/candidate',r/'images/before')
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'images/before/Lokad.Lython.dll')
rev=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert rev.startswith('f6861aa5')
(r/'baseline-revision.txt').write_text(rev+'\n',encoding='utf-8')
(r/'baseline-proof.json').write_text(json.dumps(dict(source=rev,coreSHA256=hashlib.sha256((r/'images/before/Lokad.Lython.dll').read_bytes()).hexdigest(),proof='Fresh nonincremental source build completed before edits; existing shared worker/adapter bits unchanged.',productionSources={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest()for p in Path('src/Lokad.Lython').rglob('*.cs')if'obj'not in p.parts}),indent=2)+'\n',encoding='utf-8')
shutil.copyfile(old/'catalog.json',r/'catalog.json')
for n in ['measure.py','assess-local.py']:
 s=(old/n).read_text(encoding='utf-8')
 s=s.replace("[('warm','sync'),('warm','async'),('compile','sync')]","[('warm','sync')]").replace("['warm-sync','warm-async','compile-sync']","['warm-sync']")
 (r/n).write_text(s,encoding='utf-8')
(r/'selection.md').write_text('''# R164 shared cooperative string comparison kernels

Move the operator-local bounded byte loop into existing PyString methods; preserve
Equals/CompareOrdinal interfaces without context and supply current context from
actual guest callers. Native equality uses SequenceEqual, ordering SequenceCompareTo,
both bounded4096B with reference/length shortcuts. Delete operator-local loop and
rendering-only static comparer. No cache, policy, value representation or allowance.
Existing structural ambient context reaches recursive native equality/ordering.
JSON synchronous key sort borrows existing ambient + guest-dispatch suppression;
do not enable guest callbacks inside CLR comparer or carry scope across await.
Direct string methods/difflib/rendering use actual current invocation context.
Preserve cycles/protocols/refusal/aliases and native internal interfaces. Focused
Release direct/recursive/Unicode/async/owner checks and reuse active-cancellationStress.
One existing five-script warm-sync diagnostic; no repeated VM campaign/CPU claim.
R163 full CI qualifies its source only, independently of this migration.
''',encoding='utf-8')
print('R164 source baseline frozen; one existing diagnostic lane prepared.')
