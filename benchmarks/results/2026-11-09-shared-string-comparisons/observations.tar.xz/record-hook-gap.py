from pathlib import Path
import json,subprocess,textwrap
r=Path(__file__).parent;p=Path('tests/Lokad.Lython.Tests/JsonSortedComparisonTests.cs');s=p.read_text(encoding='utf-8');(r/'json-hook-count-case.cs').write_text(s,encoding='utf-8')
source=textwrap.dedent(s.split('const string source = """',1)[1].split('"""',1)[0]).strip()+'\n'
x=subprocess.run(['C:/Python313/python.exe','-X','utf8','-I','-c',source],capture_output=True,text=True,encoding='utf-8');assert x.returncode==0 and x.stdout=="{} ['equal', 'equal']\n",x.stdout+x.stderr
(r/'json-item-comparison-gap.json').write_text(json.dumps(dict(source=source,reference=subprocess.check_output(['C:/Python313/python.exe','--version'],text=True).strip(),cpythonStdout=x.stdout,lythonStdout="{} ['equal']\n",lythonEvidence='sort-nested-hook-current.log passes exact prior assertion recorded in json-hook-count-case.cs',reason='CPython sorts complete item pairs; key equality can run before key ordering. Lython compares only original keys. Pre-existing difference, separate R165.'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');mark='2. **Continue the whole-script redesign roadmap.**'
s=s.replace(mark,'''2. **R165 — JSON sorted item-pair semantics.** Independent Python probe exposes
   an existing difference: sorted nested tuple keys call guest __eq__ twice under
   CPython item-pair ordering but once under Lython's key-only comparator. Preserve
   event availability in R164 without asserting the incorrect count. Then replace
   key-only ordering with Python-shaped item-pair equality/order, using existing
   comparison/sort machinery; preserve raw hooks, first failure, genuine async
   protocols, funding and cleanup. Start with the exact small reproducer in
   string-comparison-r164/json-item-comparison-gap.json; no broad campaign. If
   current synchronous CLR comparator cannot support required suspension, state
   the contract tradeoff and use an existing supported sort path, not a new framework.

3. **Continue the whole-script redesign roadmap.**''')
s=s.replace('3. **Independent regex development.**','4. **Independent regex development.**')
s=s.replace('   without enabling guest callbacks inside CLR comparers.', '   without enabling guest callbacks where the old native path had none.')
s=s.replace('   structural operation already allowed guest comparison hooks.', '   structural operation already allowed guest comparison hooks.')
p.write_text(s,encoding='utf-8',newline='\n');print('Exact Python/Lython count gap preserved; R165 added, no incorrect golden enshrined.')
