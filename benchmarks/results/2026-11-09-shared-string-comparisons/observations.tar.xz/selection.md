# R164 shared cooperative string comparison kernels

Move the operator-local bounded byte loop into existing PyString methods; preserve
Equals/CompareOrdinal interfaces without context and supply current context from
actual guest callers. Native equality uses SequenceEqual, ordering SequenceCompareTo,
both bounded4096B with reference/length shortcuts. Delete operator-local loop and
rendering-only static comparer. No cache, policy, value representation or allowance.
Existing structural ambient context reaches recursive native equality/ordering.
JSON synchronous key sort borrows existing ambient + guest-dispatch suppression;
do not enable guest callbacks inside CLR comparer or carry scope across await.
Direct string methods/difflib/rendering use actual current invocation context.
Preserve cycles/protocols/refusal/aliases and native internal interfaces. Focused
Release direct/recursive/Unicode/async/owner checks and reuse active-cancellationStress.
One existing five-script warm-sync diagnostic; no repeated VM campaign/CPU claim.
R163 full CI qualifies its source only, independently of this migration.
