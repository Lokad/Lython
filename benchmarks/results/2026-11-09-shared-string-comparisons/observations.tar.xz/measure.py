from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).parent
env=os.environ.copy()
env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11'
env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe'
env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
with (r/'candidate-build.log').open('w',encoding='utf-8') as log:
    done=subprocess.run([env['DOTNET_HOST_PATH'],'build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-restore','--no-incremental'],env=env,stdout=log,stderr=subprocess.STDOUT)
assert done.returncode==0,(r/'candidate-build.log').read_text(encoding='utf-8')[-5000:]
shutil.copytree(r/'images/before',r/'images/candidate')
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'images/candidate/Lokad.Lython.dll')
assert all(p.read_bytes()==(r/'images/candidate'/p.name).read_bytes() for p in (r/'images/before').iterdir() if p.is_file() and p.name!='Lokad.Lython.dll')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src/Lokad.Lython','tests']))
(r/'identity.json').write_text(json.dumps(dict(baselineRevision=(r/'baseline-revision.txt').read_text(encoding='utf-8-sig').strip(),baselineCoreSHA256=hashlib.sha256((r/'images/before/Lokad.Lython.dll').read_bytes()).hexdigest(),candidateCoreSHA256=hashlib.sha256((r/'images/candidate/Lokad.Lython.dll').read_bytes()).hexdigest(),productionSources={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('src/Lokad.Lython').rglob('*.cs') if 'obj' not in p.parts}),indent=2)+'\n',encoding='utf-8')
for phase,api in [('warm','sync')]:
    folder=r/(phase+'-'+api)
    folder.mkdir()
    witness=folder/'hash-witness.json'
    witness.write_text(json.dumps(dict(source="return [hash('Lython-é😀'), hash((1, 2.0, True))]\n"),ensure_ascii=False)+'\n',encoding='utf-8')
    with (folder/'measurements.json').open('w',encoding='utf-8') as out,(folder/'stderr.txt').open('w',encoding='utf-8') as err:
        done=subprocess.run([env['DOTNET_HOST_PATH'],str(r.parent/'bulk-whitespace-r157/tool/out/complete-jobs.dll'),str(r/'images/before/Lokad.Lython.Benchmarks.dll'),str(r/'images/candidate/Lokad.Lython.Benchmarks.dll'),str(r/'catalog.json'),str(witness),'reverse',phase,api],env=env,stdout=out,stderr=err,timeout=120)
    assert done.returncode==0,(folder/'stderr.txt').read_text(encoding='utf-8')[-5000:]
    data=json.loads((folder/'measurements.json').read_text(encoding='utf-8'))
    assert all(data[k] for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
    print(phase,api,'golden/ownership/isolation/cleanup gates pass',flush=True)
