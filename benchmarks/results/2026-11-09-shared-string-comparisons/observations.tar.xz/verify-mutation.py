from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).parent;out=r/'suppression-mutation';out.mkdir(exist_ok=False)
source=Path('tests/Lokad.Lython.Tests/bin/Release/net11.0');shutil.copytree(source,out/'tests')
identity=json.loads((r/'identity.json').read_text(encoding='utf-8'))
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
for role in ['before','candidate']:
 shutil.copyfile(r/'images'/role/'Lokad.Lython.dll',out/'tests/Lokad.Lython.dll')
 assert hashlib.sha256((out/'tests/Lokad.Lython.dll').read_bytes()).hexdigest()==identity['baselineCoreSHA256' if role=='before' else 'candidateCoreSHA256']
 path=r/('baseline-hook.log' if role=='before' else 'suppression-mutation.log')
 with path.open('w',encoding='utf-8')as log:
  x=subprocess.run([env['DOTNET_HOST_PATH'],'vstest',str(out/'tests/Lokad.Lython.WhiteBox.Tests.dll'),'--TestCaseFilter:FullyQualifiedName~JsonSortedComparisonTests','--logger:console;verbosity=minimal'],env=env,stdout=log,stderr=subprocess.STDOUT)
 text=path.read_text(encoding='utf-8')
 if role=='before':assert x.returncode==0 and 'Passed:     1'in text,text[-2500:]
 else:
  assert x.returncode!=0 and 'Values are not comparable.'in text,text[-2500:]
  assert 'Failed:     1'in text and 'Passed:     0'in text,text[-1200:]
(r/'mutation-proof.json').write_text(json.dumps(dict(rejectedFrozenPrototype=True,unchangedBaselinePassed=True,sourceRestored=False,mutation='Original R164 binary always suppressed guest dispatch inside native JSON sorting',coreSHA256=identity['candidateCoreSHA256'],baselineCoreSHA256=identity['baselineCoreSHA256'],testAssemblySHA256=hashlib.sha256((out/'tests/Lokad.Lython.WhiteBox.Tests.dll').read_bytes()).hexdigest(),failure='Values are not comparable.',currentSourceTestPassed=True),indent=2)+'\n',encoding='utf-8')
print('Same regression passes unchanged baseline, fails exact frozen prototype; no production restore.')
