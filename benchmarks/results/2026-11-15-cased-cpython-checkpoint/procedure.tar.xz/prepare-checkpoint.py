from pathlib import Path
import ast,datetime,hashlib,io,json,shlex,subprocess,tarfile
r=Path('.git/agent-notes/review-20261031/cased-preparation-r408');q=r/'checkpoint';q.mkdir();old=r.parent/'csv-cpython-r399';remote='/home/lokad/lython-bench-checks/cased-cpython-b797-20261115';unit='lython-b797-cased-cpython-20261115';identity=json.loads((r/'refined-quiet/identity.json').read_text(encoding='utf-8'));head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();identity.update(sourceRevision=head+'/frozen0edc0c1c',runtimeCommit=head,purpose='Affected captured/direct text CPython delivery checkpoint; separate warm and compile-to-result clocks with full I/O/goldens/cleanup.',coreSHA256={k:v for k,v in identity['coreSHA256'].items()if k.startswith('candidate')},roleMeaning=dict(candidate=head[:8],**{'candidate-control':head[:8]}),qualification='Committed/pushed1b82cd46, focused actual11/10 passed, full43744260423 active')
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
oldjobs="jobs=[['scripts.csv-invoice.large','warm'],['scripts.csv-invoice.large','compile'],['scripts.csv-invoice.large','compile-run'],['scripts.csv-fulfillment.large','warm']]";newjobs="jobs=[['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','compile-run'],['scripts.text-summary.inline.large','warm']]"
for n in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
 s=(old/n).read_text(encoding='utf-8').replace('csv-cpython-b784-20261115','cased-cpython-b797-20261115').replace('lython-b784-csv-cpython-20261115',unit).replace('B784','B797').replace('lython-b784-fixtures','lython-b797-fixtures')
 s=s.replace(oldjobs,newjobs).replace('len(jobs)==4','len(jobs)==3').replace("len(raw['jobs'])==4","len(raw['jobs'])==3").replace("['jobs']==4","['jobs']==3").replace('jobs=4','jobs=3').replace("elapsedSeconds']<240","elapsedSeconds']<270").replace(' < 180,',' < 210,')
 if n=='collect.py':
  s=s.replace("assert len(jobs)==3 and all(case in cases for case,lane in jobs)","cases.update({c['id']:c for c in json.loads((root/'additional.json').read_text())['cases']})\nassert len(jobs)==3 and all(case in cases for case,lane in jobs)")
  s=s.replace("        with contextlib.ExitStack() as stack:\n            labels=","        catalog=root/('additional.json'if case_id=='scripts.text-summary.inline.large'else'representative.json')\n        manifest_hash=hashlib.sha256(catalog.read_bytes()).hexdigest()\n        with contextlib.ExitStack() as stack:\n            labels=")
  s=s.replace('("scripts.text-summary-helpers.nonlocal-counter.large","scripts.report-render.large")','("scripts.text-summary-helpers.nonlocal-counter.large","scripts.text-summary.inline.large")')
 if n.endswith('.py'):ast.parse(s)
 (q/n).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for n in ['identity.json','collect.py','archive-owned.py','run.sh']:t.add(q/n,arcname=n)
canonical='benchmarks/results/2026-11-15-fused-cased-preparation/confirmation/observations.tgz';raw=subprocess.check_output(['git','show',head+':'+canonical]);assert raw==Path(canonical).read_bytes()
with tarfile.open(fileobj=io.BytesIO(raw))as t:data=t.extractfile('confirmation/confirmation.json').read()
retire=[dict(path='casing-controls-b796-20261115/'+n,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),canonicalCommit=head,canonicalPath=canonical,member=member)for n,b,member in [('observations.tgz',raw,None),('confirmation/confirmation.json',data,'confirmation/confirmation.json')]]
config=dict(root=remote,source='/home/lokad/lython-bench-checks/cased-preparation-b795-20261115',unit=unit,identity=identity,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),retire=retire)
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(old/'launch-command.py').read_text(encoding='utf-8');a=s.index('config=');b=s.index('\nbase=',a);s=s[:a]+'config='+repr(config)+s[b:];s=s.replace('import fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile','import fcntl,hashlib,io,json,os,shutil,stat,subprocess,sys,tarfile')
s=s.replace(" assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1"," probe=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True)\n own={str(os.getpid()),str(os.getppid())}\n assert all(v.split(maxsplit=1)[0]in own for v in probe.stdout.splitlines()),probe.stdout")
s=s.replace(" assert shutil.disk_usage(base).free>254*1024*1024+65536\n",'')
s=s.replace(' root.mkdir()\n',""" paths=[]
 for v in config['retire']:
  p=base/v['path'];m=p.lstat()
  assert p.resolve()==p and p.is_relative_to(base)and stat.S_ISREG(m.st_mode)and m.st_uid==os.getuid()and m.st_nlink==1 and m.st_size==v['bytes']and sha(p)==v['sha256']
  paths.append(p)
 assert shutil.disk_usage(base).free+sum(v['bytes']for v in config['retire'])>254*1024*1024+65536
 for p in paths:p.unlink()
 root.mkdir()
""",1)
s=s.replace(" os.link(source/'representative.json',root/'representative.json');os.link(source/'cpython-worker.py',root/'cpython-worker.py')"," os.link(source/'representative.json',root/'representative.json');os.link(source/'additional.json',root/'additional.json');os.link(source/'cpython-worker.py',root/'cpython-worker.py')\n (root/'retirement-receipt.json').write_text(json.dumps(dict(retiredOnly=config['retire'],canonicalBytesVerifiedLocally=True,hashesPathsUIDLinksVerified=True,quietLease=True,freeBytes=shutil.disk_usage(base).free),indent=2)+'\\n')")
s=s.replace('lython-b784-fixtures','lython-b797-fixtures').replace('RuntimeMaxSec=240','RuntimeMaxSec=270');ast.parse(s);(q/'launch-command.py').write_text(s,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];p=subprocess.run(ssh+['python3 -c '+shlex.quote(s)],input=(q/'payload.tgz').read_bytes(),capture_output=True,timeout=45);(q/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode('utf-8','replace')
now=datetime.datetime.now(datetime.timezone.utc);(q/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=215)).isoformat(),ownerSeconds=270),indent=2)+'\n',encoding='utf-8',newline='\n');print((p.stdout+p.stderr).decode());print('Observe same B797 after',now+datetime.timedelta(seconds=215))
