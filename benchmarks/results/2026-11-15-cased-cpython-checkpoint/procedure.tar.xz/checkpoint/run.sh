set -eu
root=/home/lokad/lython-bench-checks/cased-cpython-b797-20261115
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
