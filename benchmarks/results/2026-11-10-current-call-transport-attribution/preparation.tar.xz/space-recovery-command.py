from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess,sys
base=Path('/home/lokad/lython-bench-checks')
config={'requiredFreeBytes': 265560064, 'candidates': [{'path': '/home/lokad/lython-bench-checks/native-integer-b536-20261110/current-core.dll', 'size': 5659648, 'sha256': 'b71300cc1ca4536e513622f77ecbb38c88a1fab8add8dc81d87621f59193b134', 'preservedLocal': 'D:\\code\\Lython\\benchmarks\\results\\2026-11-10-integer-local-storage\\refined\\observations.tgz', 'archiveSHA256': 'ad6bd2b6ad6b2eed347d8d3ad7ecb020e313accae797bd71eabc09e225aef396', 'archiveMember': 'current-core.dll', 'tracked': True, 'kind': 'core'}, {'path': '/home/lokad/lython-bench-checks/native-integer-b536-20261110/observations.tgz', 'size': 4952477, 'sha256': 'ad6bd2b6ad6b2eed347d8d3ad7ecb020e313accae797bd71eabc09e225aef396', 'preservedLocal': 'D:\\code\\Lython\\benchmarks\\results\\2026-11-10-integer-local-storage\\refined\\observations.tgz', 'tracked': True, 'kind': 'archive'}]}
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not(base/'current-work-b537-20261110').exists()
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 free=shutil.disk_usage(base).free;required=config['requiredFreeBytes']
 if free>required:
  print(json.dumps(dict(skipped=True,freeBytes=free,requiredBytes=required)));sys.exit(0)
 rows=[];unavailable=[]
 for e in config['candidates']:
  p=Path(e['path'])
  if not p.exists():unavailable.append(e['path']);continue
  assert p.resolve(strict=True)==p and p.parent.parent==base
  info=p.lstat();assert stat.S_ISREG(info.st_mode) and info.st_uid==os.getuid() and info.st_gid==os.getgid()
  assert info.st_size==e['size'] and hashlib.sha256(p.read_bytes()).hexdigest()==e['sha256']
  if e['kind']=='archive':
   r=json.loads((p.parent/'archive-receipt.json').read_text());assert r['complete']and r['allWorkersJoined']and r['archiveSHA256']==e['sha256']
  rows.append(dict(**e,device=info.st_dev,inode=info.st_ino,links=info.st_nlink,allocatedBytes=info.st_blocks*512,allAliases=[]))
  if free+sum(r['allocatedBytes']for r in rows)>required:break
 assert free+sum(r['allocatedBytes']for r in rows)>required,('Insufficient exact copies; no mutation',free,required,unavailable)
 keys={(r['device'],r['inode']):r for r in rows}
 for folder,dirs,files in os.walk(base,followlinks=False):
  dirs[:]=[d for d in dirs if not(Path(folder)/d).is_symlink()]
  for name in files:
   p=Path(folder)/name;m=p.lstat();r=keys.get((m.st_dev,m.st_ino))
   if r is None:continue
   assert p.resolve(strict=True)==p and stat.S_ISREG(m.st_mode) and m.st_uid==os.getuid()and m.st_gid==os.getgid()
   assert m.st_size==r['size']and hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256']
   for parent in p.parents:assert not parent.is_symlink()and stat.S_ISDIR(parent.lstat().st_mode)
   r['allAliases'].append(str(p))
 for r in rows:assert len(r['allAliases'])==r['links'],('Unknown links; no mutation',r)
 plan=dict(requiredFreeBytes=required,beforeFreeBytes=free,osFloorMiB=240,evidenceHeadroomMiB=12,freshIdleLease=True,files=rows,unavailable=unavailable,operation='Retire exact duplicate remote bytes only; immutable tracked archives retain all core/raw evidence; current qualified26d preserved; only archived withdrawnb713 prototype/duplicate archive retired.')
 out=base/'current-work-b537-space-plan.json'
 with out.open('x')as f:f.write(json.dumps(plan,indent=2)+'\n');f.flush();os.fsync(f.fileno())
 for r in rows:
  for name in r['allAliases']:
   p=Path(name);m=p.lstat();assert(m.st_dev,m.st_ino)==(r['device'],r['inode'])and hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256'];p.unlink()
 plan['afterFreeBytes']=shutil.disk_usage(base).free;assert plan['afterFreeBytes']>required
 (base/'current-work-b537-space-receipt.json').write_text(json.dumps(plan,indent=2)+'\n')
 print(json.dumps(plan))
