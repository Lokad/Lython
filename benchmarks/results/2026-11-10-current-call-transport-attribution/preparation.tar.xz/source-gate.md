# R189 current complete-call/transport gate

Current mainfbc88ca5; production src identical to fullyqualified3a413c59. Native
helper binding/unbound storage are delivered. R188 local-only boxing storage is
withdrawn, complete source/control evidence preserved,98retained main checks per
actual11/10 pass after forced builds. Do not reopen it solely for the14/18%allocation
saving; broader transport semantics and CSV/report debt remain necessary.

Actual source: TryExecuteNativeCall borrows exact positionals or shares Span binding
for proven closed native helpers. BeginPendingCall consumes existing operand storage;
BeginBoundCall shares bound locals, defers invocation context where semantics allow,
and transfers storage/admission through pending binding/cleanup. Non-native handlers,
class/annotation contexts, protocols and mutable defaults retain real frame behavior.
The ordinary native/builtin/receiver paths already avoid many argument arrays.
Function workspaces are existing explicitly-owned storage and clear their used
capacity before reuse. A larger shared workspace need not imply each call allocates
or copies. Do not remove reference clearing without a complete dirty-reference and
pending-disposal proof; it is not the deleted R185 initialization fill.

Function parameter names/index layout is already immutable and compiler-owned.
The remaining shared binder queries keyword-to-slot indices and applies live defaults;
removing one short-name lookup alone cannot plausibly remove the entire old binding
share. Do not add another per-execution mapping cache/admission or duplicate binder
from that observation. Static maps would need a real caller/metadata identity proof,
shared ownership and material measured work. No810-signature rewrite justified yet.

Builtin functions/signatures already shared; mutable types and metadata remain isolated.
CheckExecution is already an inlined refusal/token check with a cold cancellation throw;
there is no hidden work quota or obvious lock in the instruction checkpoint. Do not
weaken cancellation or first-refusal propagation to reduce a source-level call count.

Frontend module/function scope facts are cached after lexical preparation. Class-cell
analysis can ask for nested binding facts before their full lexical context is known.
Those preliminary bindings and context-sensitive class demand are distinct; a new
cache or premature complete-fact reuse risks the previous class-cell correctness fix.
Ordinary no-enclosing-class helpers short-circuit that class-demand walk. This does
not establish a dominant ordinary-script frontend duplication.

OldR182 CSV attribution predates R184/R185. ExistingR166 text profile is a lead;
inclusive VM/native/activation groups include useful/inlined work. Refresh exactly
current-qualified CSV and text, six seconds each under the established profiler:
B537owner120/stop30/margin30, not before07:26:59UTC. Same frozen26d core/common
worker/adapter0.4/current external catalog, no runtime rebuild or elapsed/CPython
lane. Preserve all unknown/thread data and raw stacks; no fresh broad campaign.
The old aggregate10s guard conflicted with two planned6s captures; align to its
documented20s aggregate while keeping each<10s and the owner/read/frame bounds.

After decoding, select one coherent material work/storage elimination and record
actual displaced implementation, representative whole scripts, complete semantic
criteria, bounded controls, completion milestone and debt decision before edits.
If the observation is incomplete, preserve uncertainty and choose only a bounded
setup repair/confirmation justified by that failure. No permanent design veto.
Regex producer limitations remain independent; publication stays postponed.
