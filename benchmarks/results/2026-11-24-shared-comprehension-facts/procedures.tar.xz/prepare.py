from pathlib import Path
import hashlib, json, os, shutil, subprocess, tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.with_name("regex-cursor-original-20261124")
previous = donor / "comparison/quiet"
quiet = lab / "comparison/quiet"
quiet.mkdir(parents=True, exist_ok=True)
read = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
digest = lambda data: hashlib.sha256(data.encode("utf-8")).hexdigest()
save = lambda p, v: p.write_text(json.dumps(v, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
base = read(previous / "identity.json")
core = "Lokad.Lython.dll"
head = subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip()
assert head.startswith("50e187921")
assert subprocess.check_output(["git","diff","--binary",base["sourceRevision"],head,"--","src","tests"],cwd=repo)==(donor/"candidate.patch").read_bytes()
reference = base["imageFiles"]["candidate"]
assert {p.name:sha(p) for p in (donor/"candidate").iterdir()} == reference
current = lab/"windows/bin/Lokad.Lython/release_net11.0"/core
images = {"reference": reference, "candidate": reference | {core:sha(current)}}
assert images["candidate"][core] != reference[core]
for role, files in images.items():
    image=lab/role
    image.mkdir(exist_ok=True)
    for name in files:
        shutil.copyfile(current if role=="candidate" and name==core else donor/"candidate"/name,image/name)
    assert len(files)==32 and {p.name:sha(p) for p in image.iterdir()}==files

generic="diagnostic.prepared-comprehension-rules"
manifest="scripts.config-manifest.small"
sparse="scripts.config-generated-guards.medium.bad-0.sparse-lexical"
jobs=[[generic,"compile"],[sparse,"compile"],[manifest,"compile-run"],[generic,"compile-run"]]
catalog=read(lab.with_name("abstract-collection-graphs-20261124")/"external/representative.json")
controls=[row for row in catalog["cases"] if row["id"] in {manifest,sparse}]
assert len(controls)==2
declarations = []
for index in range(72):
    declarations.append(f"""type Rule{index} = (
    [a + b + {index} for a, *tail in rows for b in tail if b > 0],
    {{b: a + b + {index} for a, *tail in rows for b in tail}},
    {{a + b + {index} for a, *tail in rows for b in tail}},
    tuple(a + b + {index} for a, *tail in rows for b in tail),
)""")
source = "rows = [(1, 2, 3), (4, 5, 6)]\n" + "\n".join(declarations) + """
for alias in (Rule0, Rule36, Rule71):
    values, mapping, distinct, ordered = alias.__value__
    print(values, sorted(mapping.items()), sum(distinct), ordered)
result = [[a + b for b in range(2)] for a in range(3)]
print(result)
"""
python=Path("C:/Python313/python.exe")
golden=subprocess.run([python,"-I","-S","-X","utf8","-"],input=source,encoding="utf-8",capture_output=True,timeout=10,check=True)
assert not golden.stderr and golden.stdout.splitlines()[0] == "[3, 4, 9, 10] [(2, 3), (3, 4), (5, 9), (6, 10)] 26 (3, 4, 9, 10)", golden.stdout
fixture=json.dumps({"size":72,"text":None},separators=(",",":"))
case=dict(id=generic,family="scripts",category="whole-script",scale="small",size=72,source=source,
    fixtureJson=fixture,expectedOutput=golden.stdout,sourceUtf8Bytes=len(source.encode("utf-8")),
    expectedOutputUtf8Bytes=len(golden.stdout.encode("utf-8")),fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,
    sourceSha256=digest(source),fixtureSha256=digest(fixture),expectedOutputSha256=digest(golden.stdout))
catalog["cases"]=[case,*controls]
catalog["fixtureEncoding"]="Canonical base64 file maps in both existing controls. Generated comprehension rules have no file fixture."
expected=quiet/"representative.json"
save(expected,catalog)
save(quiet/"jobs.json",{"warm":jobs})
patch=lab/"candidate.patch"
patch.write_bytes(subprocess.check_output(["git","diff","--binary","--","src","tests"],cwd=repo))
assert b"+                    var facts = ComprehensionSyntaxFacts.PrepareBindings(expression, clauses," in patch.read_bytes()
identity=dict(sourceRevision=head,comparisonRevision=head,sourcePatchSHA256=sha(patch),
    purpose="Share comprehension scope bindings across validation, lexical preparation and lowering",
    imageFiles=images,expectedCPythonSHA256=base["expectedCPythonSHA256"],cpythonWorkerSHA256=base["cpythonWorkerSHA256"],
    coreSHA256={role+suffix:files[core] for role,files in images.items() for suffix in ("","-control")},
    catalogs={name:{"sha256":sha(quiet/name)} for name in ("representative.json","jobs.json")})
save(quiet/"identity.json",identity)
collector=(previous/"collect.py").read_text(encoding="utf-8").replace("b1641-fixtures","b1642-fixtures")
compile(collector,"collect.py","exec")
(quiet/"collect.py").write_text(collector,encoding="utf-8",newline="\n")
shutil.copyfile(previous/"run.sh",quiet/"run.sh")
assert b"\r" not in (quiet/"run.sh").read_bytes()
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
worker=repo/"benchmarks/cpython-worker.py"
assert sha(worker)==identity["cpythonWorkerSHA256"]
for role in images:
    output=lab/"comparison"/(role+"-verify.json")
    subprocess.run([dotnet,lab/role/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",expected,
        "--dotnet",dotnet,"--python",python,"--python-worker",worker,"--out",output],env=env,cwd=repo,check=True,timeout=60)
    checked=read(output)
    assert checked["state"]=="Completed" and checked["caseCount"]==3
    assert checked["catalogSha256"]==sha(expected) and checked["launched"]["library"]["sha256"]==images[role][core]
staged=quiet/"payload.tar.gz"
with tarfile.open(staged,"w:gz",compresslevel=3) as archive:
    for name in ("identity.json","jobs.json","representative.json","collect.py","run.sh"):
        archive.add(quiet/name,arcname=name,recursive=False)
    archive.add(lab/"candidate"/core,arcname="candidate-core.dll",recursive=False)
save(quiet/"upload.json",dict(root="shared-comprehension-facts-b1642-20261124",
    reference="regex-cursor-original-b1641-20261124",payloadSHA256=sha(staged),payloadBytes=staged.stat().st_size))
save(lab/"verified-raw-replicas.json",[])
launch=(donor/"quiet.py").read_text(encoding="utf-8")
receipt=read(previous/"terminal-status.json")["receipt"]
assert receipt["complete"] and sha(previous/"observations.tar.xz")==receipt["archiveSHA256"]
assert "f2a47dbcf304853599860ba0424b0fb8e37120b9b430a37e374dccda27ac5342" in launch
launch=launch.replace("f2a47dbcf304853599860ba0424b0fb8e37120b9b430a37e374dccda27ac5342",receipt["archiveSHA256"])
launch=launch.replace("lython-b1641-regex-cursor-original","lython-b1642-shared-comprehension-facts").replace("b1641-","b1642-")
compile(launch,"quiet.py","exec")
(lab/"quiet.py").write_text(launch,encoding="utf-8",newline="\n")
print("Verified 32 files per image and three complete CPython goldens.")
