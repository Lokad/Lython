from pathlib import Path
import hashlib, json, shutil, subprocess, tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
out = repo / "benchmarks/results/2026-11-24-shared-comprehension-facts"
quiet = lab / "comparison/quiet"
read = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
identity = read(quiet / "identity.json")
patch = subprocess.check_output(["git", "diff", "--binary", "--", "src", "tests"], cwd=repo)
assert patch == (lab / "candidate.patch").read_bytes()
assert hashlib.sha256(patch).hexdigest() == identity["sourcePatchSHA256"]
for role, files in identity["imageFiles"].items():
    assert {p.name: sha(p) for p in (lab / role).iterdir()} == files
    verify = read(lab / "comparison" / (role + "-verify.json"))
    assert verify["state"] == "Completed" and verify["caseCount"] == 3
    assert verify["launched"]["library"]["sha256"] == files["Lokad.Lython.dll"]
    assert read(lab / (role + "-compiler-owner.json"))["coreSHA256"] == files["Lokad.Lython.dll"]
assert read(lab / "initial-candidate-verify.json")["state"] == "Failed"
for platform in ("windows", "ubuntu"):
    for kind, count in (("public", 892), ("white", 141), ("net10", 158)):
        transcript = (lab / f"{platform}-{kind}.log").read_text(encoding="utf-8-sig")
        assert f"Passed:   {count}" in transcript, (platform, kind)
for path in (quiet / "identity.json", lab / "compile-allocation-summary.json", quiet / "retired-stage-custody.json"):
    shutil.copyfile(path, out / path.name)
names = ["package-evidence.py", "make-trial.py", "prepare.py", "prepare.log", "quiet.py", "archive.py", "compile-allocation.py",
         "candidate.patch", "initial-candidate.patch", "initial-candidate-verify.json", "initial-prepare.log", "donor-assertion.log",
         "reference-compiler-owner.json", "candidate-compiler-owner.json", "cpython-alias-oracle.log",
         "comparison/reference-verify.json", "comparison/candidate-verify.json", "comparison/quiet/storage-custody.json",
         "recover-stage-space.py", "windows-public.log", "windows-white.log", "windows-net10.log",
         "ubuntu-public.log", "ubuntu-white.log", "ubuntu-net10.log"]
with tarfile.open(out / "procedures.tar.xz", "w:xz") as archive:
    for name in names:
        archive.add(lab / name, arcname=name, recursive=False)
with tarfile.open(out / "procedures.tar.xz") as archive:
    assert {member.name: hashlib.sha256(archive.extractfile(member).read()).hexdigest() for member in archive} == {
        name: sha(lab / name) for name in names}
print("Verified the corrected source patch, both complete images, compiler ownership and failed initial form.")
