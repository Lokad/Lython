from pathlib import Path

lab = Path(__file__).resolve().parent
donor = lab.with_name("regex-cursor-original-20261124")
prepare = (donor / "prepare.py").read_text(encoding="utf-8")
prepare = prepare.replace('lab.with_name("raw-expression-retirement-20261124")', 'lab.with_name("regex-cursor-original-20261124")')
prepare = prepare.replace('head.startswith("33264df8d")', 'head.startswith("50e187921")')
begin = prepare.index('generic="diagnostic.')
end = prepare.index('case=dict(', begin)
prepare = prepare[:begin] + '''generic="diagnostic.prepared-comprehension-rules"
manifest="scripts.config-manifest.small"
sparse="scripts.config-generated-guards.medium.bad-0.sparse-lexical"
jobs=[[generic,"compile"],[sparse,"compile"],[manifest,"compile-run"],[generic,"compile-run"]]
catalog=read(lab.with_name("abstract-collection-graphs-20261124")/"external/representative.json")
controls=[row for row in catalog["cases"] if row["id"] in {manifest,sparse}]
assert len(controls)==2
declarations = []
for index in range(72):
    declarations.append(f"""type Rule{index} = (
    [a + b + {index} for a, *tail in rows for b in tail if b > 0],
    {{b: a + b + {index} for a, *tail in rows for b in tail}},
    {{a + b + {index} for a, *tail in rows for b in tail}},
    tuple(a + b + {index} for a, *tail in rows for b in tail),
)""")
source = "rows = [(1, 2, 3), (4, 5, 6)]\\n" + "\\n".join(declarations) + """
for alias in (Rule0, Rule36, Rule71):
    values, mapping, distinct, ordered = alias.__value__
    print(values, sorted(mapping.items()), sum(distinct), ordered)
result = [[a + b for b in range(2)] for a in range(3)]
print(result)
"""
python=Path("C:/Python313/python.exe")
golden=subprocess.run([python,"-I","-S","-X","utf8","-"],input=source,encoding="utf-8",capture_output=True,timeout=10,check=True)
assert not golden.stderr and golden.stdout.splitlines()[0] == "[3, 4, 9, 10] [(2, 3), (3, 4), (5, 9), (6, 10)] 26 (3, 4, 9, 10)", golden.stdout
fixture=json.dumps({"size":72,"text":None},separators=(",",":"))
''' + prepare[end:]
prepare = prepare.replace('size=1024,source=source', 'size=72,source=source')
prepare = prepare.replace('The Unicode regex window has no file fixture.', 'Generated comprehension rules have no file fixture.')
prepare = prepare.replace('b"+            internal bool Next()"', 'b"+                    var facts = ComprehensionSyntaxFacts.PrepareBindings(expression, clauses,"')
prepare = prepare.replace('Bind provider cursor validation and projection to the original subject and window', 'Share comprehension scope bindings across validation, lexical preparation and lowering')
prepare = prepare.replace('reference="raw-expression-retirement-b1640-20261124"', 'reference="regex-cursor-original-b1641-20261124"')
prepare = prepare.replace('root="regex-cursor-original-b1641-20261124"', 'root="shared-comprehension-facts-b1642-20261124"')
prepare = prepare.replace('replace("b1640-fixtures","b1641-fixtures")', 'replace("b1641-fixtures","b1642-fixtures")')
prepare = prepare.replace('aad3b1cf2a0f02cb81e237cb052e5a8e7143b22876d77d62c02b39933e9498ac', 'f2a47dbcf304853599860ba0424b0fb8e37120b9b430a37e374dccda27ac5342')
prepare = prepare.replace('replace("lython-b1640-raw-expression-retirement","lython-b1641-regex-cursor-original").replace("b1640-","b1641-")', 'replace("lython-b1641-regex-cursor-original","lython-b1642-shared-comprehension-facts").replace("b1641-","b1642-")')
archive = (donor / "archive.py").read_text(encoding="utf-8").replace('2026-11-24-regex-cursor-original', '2026-11-24-shared-comprehension-facts')
for name, source in (("prepare.py", prepare), ("archive.py", archive), ("allocations.py", (donor / "allocations.py").read_text(encoding="utf-8"))):
    compile(source, name, "exec")
    (lab / name).write_text(source, encoding="utf-8", newline="\n")
