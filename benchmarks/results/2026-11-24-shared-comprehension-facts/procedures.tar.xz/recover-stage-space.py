from pathlib import Path
import hashlib, json, subprocess, tarfile

lab = Path(__file__).resolve().parent
quiet = lab / "comparison/quiet"
local = lab.with_name("native-call-boundary-b116") / "upload.tar.gz"
relative = "native-call-boundary-b116-20261102/upload.tar.gz"
identity = dict(bytes=local.stat().st_size, sha256=hashlib.sha256(local.read_bytes()).hexdigest(), relative=relative)
assert identity["bytes"] == 42428271 and identity["sha256"] == "8567460167be712d2eaee251d13c91d6263a306b4a368677686926ee646cd77c"
stage = quiet / "payload.tar.gz"
with tarfile.open(stage) as archive:
    members = [member.size for member in archive]
remote_source = f"expected = {identity!r}\nmembers = {members!r}\nstage_size = {stage.stat().st_size}\n" + """
from pathlib import Path
import fcntl, hashlib, json, os, shutil, stat, subprocess
base = Path('/home/lokad/lython-bench-checks').resolve(strict=True)
copy = base / expected['relative']
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
with (base / 'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    free_before = shutil.disk_usage(base).free
    block = os.statvfs(base).f_frsize
    needed = max(stage_size + 1400*1024, sum((n+block-1)//block*block for n in members) + 1912*1024)
    retired = False
    if free_before < needed:
        assert copy.resolve(strict=True) == copy and copy.is_relative_to(base)
        meta = copy.stat()
        assert stat.S_ISREG(meta.st_mode) and meta.st_nlink == 1 and meta.st_size == expected['bytes']
        assert digest(copy) == expected['sha256']
        units = subprocess.check_output(['systemctl', 'list-units', '--type=service', '--state=active', '--no-legend', '--plain'], text=True)
        assert 'b116' not in units.lower() and 'native-call-boundary' not in units.lower()
        assert not (copy.parent / 'guest-fixtures').exists()
        copy.unlink()
        retired = True
    free_after = shutil.disk_usage(base).free
    assert free_after >= needed
    print(json.dumps(dict(expected, retiredOnlyRemoteUpload=retired, freeBefore=free_before, freeAfter=free_after, stagedBytesNeeded=needed)))
"""
proc = subprocess.run(["ssh", "-o", "BatchMode=yes", "-o", "ConnectTimeout=10", "-i", str(Path.home()/".ssh/id_lython-bench.pem"),
                       "lokad@20.166.121.73", "python3 -"], input=remote_source, encoding="utf-8", capture_output=True, timeout=25, check=True)
assert hashlib.sha256(local.read_bytes()).hexdigest() == identity["sha256"]
receipt = json.loads(proc.stdout)
receipt["verifiedRetainedLocalCopy"] = True
(quiet / "retired-stage-custody.json").write_text(json.dumps(receipt, indent=2)+"\n", encoding="utf-8", newline="\n")
print(receipt)
