using System.Collections;
using System.Reflection;
using System.Text.Json;

var assembly = Assembly.LoadFrom(Path.GetFullPath(args[0]));
object Read(object value, string name) => value.GetType().GetProperty(name)!.GetValue(value)!;
object Invoke(string type, string method, object value)
{
    var target = assembly.GetType("Lokad.Lython.Frontend." + type)!;
    var entry = target.GetMethods(BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic)
        .Single(m => m.Name == method && (type == "LythonFrontend" || m.GetParameters().Length == 1));
    var parameters = entry.GetParameters().Select(p => p.Position == 0 ? value : Type.Missing).ToArray();
    return entry.Invoke(null, parameters)!;
}
void Dump(object code)
{
    var instructions = ((IEnumerable)Read(code, "Instructions")).Cast<object>().ToArray();
    var sites = ((IEnumerable)Read(code, "CallSites")).Cast<object>().ToArray();
    var locals = ((IEnumerable)Read(code, "LocalNames")).Cast<string>().ToArray();
    var names = ((IEnumerable)Read(code, "Names")).Cast<string>().ToArray();
    Console.WriteLine("code " + Read(code, "Name") + " mirrored=" + Read(code, "RequiresLocalVariableMirroring") + " capacity=" + Read(code, "ValueStorageCapacity") + " locals=" + string.Join(',', locals));
    var interesting = instructions.Select((instruction, index) => (instruction, index))
        .Where(v => Read(v.instruction, "OpCode").ToString() == "Call" && (bool)Read(sites[(int)Read(v.instruction, "CallSiteIndex")], "AccumulatesDictionary"))
        .Select(v => v.index).ToArray();
    foreach (var index in interesting)
    {
        Console.WriteLine("counter call " + index);
        for (var i = Math.Max(0, index - 8); i <= Math.Min(instructions.Length - 1, index + 5); i++)
        {
            var instruction = instructions[i]; var op = Read(instruction, "OpCode").ToString();
            var fields = new List<string>();
            foreach (var name in new[] { "InputStart", "ResultSlot", "LiveExtent", "HasLocalResult" }) fields.Add(name + "=" + Read(instruction, name));
            if (op == "StoreLocal") fields.Add("local=" + Read(instruction, "LocalSlot"));
            if (op is "ForNext" or "Jump") fields.Add("target=" + Read(instruction, "TargetIndex"));
            if (op == "LoadCallMember") fields.Add("name=" + names[(int)Read(instruction, "NameIndex")]);
            if (op is "Binary" or "Augmented" or "StoreSubscript") fields.Add("second=" + Read(instruction, "SecondInput"));
            if (op == "StoreSubscript") fields.Add("third=" + Read(instruction, "ThirdInput"));
            if (op == "Call")
            {
                var site = sites[(int)Read(instruction, "CallSiteIndex")];
                fields.Add("argc=" + Read(site, "ArgumentCount"));
                fields.Add("sources=" + string.Join(',', ((IEnumerable)Read(site, "Arguments")).Cast<object>().Select(v => Read(v, "NativeInput"))));
            }
            Console.WriteLine(i + " " + op + " " + string.Join(' ', fields));
        }
    }
    foreach (var function in (IEnumerable)Read(code, "Functions")) Dump(Read(function, "CodeObject"));
}
var sources = new List<(string Name, string Source)> { ("minimal", "def run(words):\n counts={}\n for word in words: counts[word]=counts.get(word,0)+1\n return counts\nreturn run(('a','b','a'))\n") };
sources.Add(("mirrored-class-reader", "def snapshot(value):\n class Record:\n  payload=value\n return Record.payload\nprint(snapshot(42))\n"));
if (args.Length > 1)
{
    using var catalog = JsonDocument.Parse(File.ReadAllBytes(args[1]));
    foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
        sources.Add((item.GetProperty("id").GetString()!, item.GetProperty("source").GetString()!));
}
foreach (var (name, source) in sources)
{
    Console.WriteLine("case " + name);
    var frontend = Invoke("LythonFrontend", "Compile", source);
    var script = Read(frontend, "Script") ?? throw new InvalidDataException("Frontend failed.");
    var executable = Invoke("ExecutableScript", "Compile", Invoke("LoweredScript", "Lower", script));
    Dump(Read(executable, "EntryPoint"));
}
