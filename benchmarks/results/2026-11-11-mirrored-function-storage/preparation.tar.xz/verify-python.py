from pathlib import Path
import base64,contextlib,io,json,re,subprocess,tempfile,textwrap,os
r=Path(__file__).resolve().parent
text=Path('tests/Lokad.Lython.PublicApi.Tests/MirroredFunctionLifetimeTests.cs').read_text(encoding='utf-8')
source=textwrap.dedent(re.search('private const string Source = """\n(.*?)\n        """;',text,re.S).group(1))
source=source.replace('return [read()[0],item.value[0]]','projected=[read()[0],item.value[0]]')
def opened(path):return io.StringIO('ready')
namespace={'fail_stage':'','open':opened};out=io.StringIO()
with contextlib.redirect_stdout(out):exec(compile(source,'mirrored-lifetime.py','exec'),namespace)
assert out.getvalue()=="4096 ((9,), 4, {'label': 'held'}) 7 ((11,), 3, {})\n"
assert namespace['projected'][0] is namespace['projected'][1]
assert namespace['projected'][0]==['é'*4096]
case=json.loads((r/'catalog.json').read_text(encoding='utf-8'))['cases'][0]
fixture=json.loads(case['fixtureJson'])
with tempfile.TemporaryDirectory(prefix='lython-r241-python-')as folder:
 root=Path(folder)
 for name,value in fixture['inputFiles'].items():
  target=root/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(base64.b64decode(value))
 done=subprocess.run([os.sys.executable,'-X','utf8','-I','-c',case['source']],cwd=root,capture_output=True,timeout=20)
 assert done.returncode==0,done.stderr.decode()
 # CPython's Windows stdout uses CRLF; catalog text output is normalized LF.
 actual=done.stdout.decode().replace('\r\n','\n')
 assert actual==case['expectedOutput'],repr(done.stdout)
 for name,value in fixture['outputFiles'].items():assert(root/name).read_bytes()==base64.b64decode(value),name
data=dict(reference=subprocess.check_output([os.sys.executable,'--version'],text=True).strip(),
 lifetimeOutput=out.getvalue(),aliasIdentity=True,csvOutput=actual,csvFilesMatch=True,
 boundary='Semantic goldens only. In-memory ready input for lifetime script; isolated temporary file tree for CSV. No timing or performance comparison.')
(r/'python-goldens.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print(json.dumps(data,ensure_ascii=False))
