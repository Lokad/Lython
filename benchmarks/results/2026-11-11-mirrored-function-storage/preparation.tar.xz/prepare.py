from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent;repo=Path.cwd();prior=r.parent/'native-counter-segment-r240'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=json.loads((prior/'diagnostic-identity.json').read_text(encoding='utf-8'))
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip().startswith('30b03de0')
assert not(r/'before.json').exists()
targets=['Runtime/PyExecutableFunction.cs','Runtime/PyType.cs','Runtime/LythonRuntime.Executable.Calls.cs','Runtime/LythonRuntime.Executable.cs']
for target in targets:
 name='src/Lokad.Lython/'+target;p=r/'originals'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(name,p)
for role in ['before','candidate']:
 shutil.copytree(prior/'images/candidate',r/'images'/role)
 for name,h in identity['images']['candidate'].items():assert sha(r/'images'/role/name)==h,(role,name)
shutil.copyfile(prior/'candidate-net10.dll',r/'before-net10.dll')
catalog=json.loads((prior/'catalog.json').read_text(encoding='utf-8'))
case=catalog['cases'][0]
source=case['source'].replace('def validated_record(record: dict, *, minimum=0):','def validated_record(record: dict, *, minimum=0, record_types=[]):')
source=source.replace('        processed += 1\n','''        processed += 1
        if not record_types:
            class Record:
                def __init__(self, kind, amount):
                    self.kind = kind
                    self.amount = amount
            record_types.append(Record)
''')
source=source.replace("return record['kind'], amount","return record_types[0](record['kind'], amount)")
source=source.replace('kind, amount = item','kind, amount = item.kind, item.amount')
assert source!=case['source'] and 'class Record:' in source and 'record_types[0]' in source
case['id']='scripts.csv-local-record-class.large';case['source']=source
case['sourceUtf8Bytes']=len(source.encode());case['sourceSha256']=hashlib.sha256(source.encode()).hexdigest()
(r/'mirrored-csv.py').write_text(source,encoding='utf-8')
(r/'catalog.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8')
for phase in ['warm-sync','warm-async','compile']:
 (r/phase).mkdir();shutil.copyfile(prior/phase/'hash-witness.json',r/phase/'hash-witness.json')
before=dict(head='30b03de0',runtimeSource='b5849b04',qualification='Fully qualified b5849b04, terminal GREEN43033830025; source-identical documentation HEAD30b03de0.',
 sourceHashes={p.relative_to(repo).as_posix():sha(p)for p in(repo/'src/Lokad.Lython').rglob('*.cs')if not {'bin','obj'}&set(p.parts)},
 images={role:identity['images']['candidate']for role in ['before','candidate']},net10SHA256=sha(r/'before-net10.dll'),
 hypothesis='Bind every compiled function into final compiler-sized storage, including namespace-mirrored functions. Delete ArgumentsAreLocals selection and duplicate binding/local arrays. Preserve actual mirrored namespaces, cells and contexts. Existing owner/runner only.',
 controls='One complete CSV validation/report script with lazily cached local record class; remaining five existing scripts unchanged. Classes constructed once, records used normally. Not a beneficiary claim for the common unmirrored scripts. Both APIs/compilation separately; desktop clocks diagnostic.',
 contract='Idle full compiler capacity remains funded by existing execution workspace cache until cleanup. Earlier final-capacity admission can refuse sooner; no live alias may borrow the cleared workspace.')
(r/'before.json').write_text(json.dumps(before,indent=2)+'\n',encoding='utf-8')
print('Qualified b584 frozen cores verified; useful local-record CSV target and five unchanged controls prepared before production edits.')
