from pathlib import Path
r=Path(__file__).resolve().parent;p=Path('PLAN.md')
archive=r/'PLAN-before-r241.md'
assert not archive.exists()
archive.write_text(p.read_text(encoding='utf-8'),encoding='utf-8')
p.write_text('''# Lokad.Lython 0.11.0

Updated 2026-11-11. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial whole-script improvements,
including compile-to-result. Finishing one experiment does not complete it.

## Delivery and evidence

| State | Actual outcome / remaining uncertainty |
| --- | --- |
| Fully qualified runtime b5849b04; documentation HEAD30b03de0 | GREEN43033830025: Windows/Ubuntu, actual .NET11/10, originalStress and installed Release consumers. Terminal cached; never query again. Ancestorfe43024046530 also cached. |
| Shared compiler facts | Corrected exponential traversal/nonlocal diagnostics and reused scope/binding facts. Fully qualified; no CPU claim. |
| Direct UTF-8 formatting/storage | Fully qualified. Allocation−8.67%; controlled elapsed/CPU5–8% lower. Original adverse15.125ms remains unexplained and preserved; no unchanged qualification replay. |
| Native helper returns | Fully qualified. Allocation−19.92%sync/−19.31%async is established separately from diagnostic elapsed. R2398314c02d fixes real double refund during cleanup/reentry on both APIs; included in b584 delivery. |
| R237 complete native counting loops | Qualifiedfe, included in b584. Quiet captured sync elapsed9–11% lower; other text shapes/APIs improve with wider controls. Allocation flat. [Evidence](benchmarks/results/2026-11-11-native-counting-loops/README.md). |
| R240 private integer segments | Qualifiedb584. Allocation−9.04%captured/−9.7%ordinary on both APIs. Ordinary-sync direction repeats; captured/async uncertain. Report+0.65..+3.40% does not recur with fresh processes; cause unknown. [All adversity/decision](benchmarks/results/2026-11-11-private-counter-segments/README.md). |
| CPython checkpoint | Qualifiedfe/frozenbf93 vs CPython3.13.16. Warm ordinary text1.21–1.22x, captured2.24–2.27x, CSV1.06–1.08x. Compile and compile-to-result separate. [Current guide](docs/BENCHMARKS.md), [raw9jobs](benchmarks/results/2026-11-11-native-loops-cpython-checkpoint/README.md). These are fe measurements, not current HEAD ratios. |
| Active R241 prototype | All compiled functions bind final workspace, including mirrored functions; actual namespace readers preserved. 30initial public,290internal/2082public net11 checks pass. Both-target qualification and one affected source pair pending; no speed claim. |

Completed invocation setup/async worker reuse, direct calls/receiver entry, shared
CSV keys/adopted rows, lexical writes, returned iteration, canonical construction,
bulk UTF-8/JSON and regex coordinates remain delivered. Full history is archived
outside docs: `.git/agent-notes/review-20261031/mirrored-call-storage-r241/PLAN-before-r241.md`
and [EXPERIMENTS](benchmarks/EXPERIMENTS.md). Do not repeat unchanged qualification.

Debt: historical15f/4aa ordinary-text async+1.92..+2.55%; R237 capturedCSV async
control−1.76..+2.74%; R240 report controls inconclusive. Reassess material debt at
a coherent checkpoint before publication. RSS, pending-I/O performance and
embedding tail latency remain unqualified; no universal CPU/neutrality claim.

## P1 — finish coherent compiled-function storage (R241)

- **Eliminate:** parameter-only binding array plus second local/operand array
  and copy for mirrored functions; ArgumentsAreLocals and redundant runner,
  initializer and clear-length selection. Every compiled invocation uses the
  existing funded compiler-sized workspace. No new owner/carrier/ABI/mode.
- **Keep:** real parameter/namespace mirroring, class/lambda/generator/typing
  readers, cells and scope contexts. Mirrored functions cannot defer their context.
  Modules/imports/generators still allocate storage when no bound array exists.
- **Affected script:** complete CSV validator/report with lazily cached local
  record class; compiler proves mirrored3parameters/10slots. Maintained six-script
  catalog is otherwise unmirrored: unchanged controls, not predicted beneficiaries.
- **Accept:** Python binding/default/protocol order, local classes/super/closures,
  escaped aliases after reuse, genuinely pending host reads, cancellation, first
  terminal refusal despite suppression/finally return, retained/cache funding and
  baseline after joined cleanup. Focused actual11/10 checks, then one existing
  short source-pair diagnostic with five controls and compilation separate.
- **Tradeoff:** admit full capacity before binding; larger idle capacity remains
  funded in the existing execution cache. Earlier denial is acceptable/documented.
  Namespace consumers never borrow reusable backing. No live user refunded early.
- **Completion:** delete displaced branches, retain only if lifetime proof and
  bounded control comparison support the simpler invariant; record allocation,
  elapsed uncertainty and any regression debt separately. Full delivery batches
  at the next coherent boundary. Refine on a real obstacle, not a fixed% veto.

## P2 — select and implement the next whole phase

The remaining captured-text gap is material. R238 currentfe profile has1151guest
leaves/5.8CPU seconds: native loop12.25%, dispatch11.38%, preparation7.91%,
MoveNext4.00%; useful/inlined work overlaps, not removable percentages.
[Profile/source gate](benchmarks/results/2026-11-11-native-word-costs/README.md).

1. Assess complete call/frame construction and captured-local transport on the
   current retained source. Common helpers already borrow operands and reuse
   workspaces; find an entire allocation/namespace/cleanup phase to remove.
   Inspect real class/late-namespace readers before touching cell mirrors.
2. Assess native word construction/admission and per-record collection phases.
   A constant worst-case word estimate can overcharge long words/spaceruns64x;
   it is not an acceptable streaming substitute. Shared CSV keys/adopted rows
   already exist. Preserve retention, duplicate/order/header mutation and reentry.
3. Operand/scalar representation and frontend work require current measured
   evidence of complete duplicated work, exact promotion/identity/projection,
   annotations/generators/executable imports. Compilation does not explain the
   captured warm gap. Do not presume remaining per-character/token conversions.

For each selected redesign: hypothesis, removed work/storage and displaced code,
representative script, semantic/cancellation/ownership acceptance, one bounded
before/after with unchanged controls and compilation separate, completion and
regression-debt decision. A justified temporary regression needs a named delivery
milestone. Stop an investigation after the source/lifetime gate and a usable
bounded observation, or a concrete unresolved dependency; choose/refine next work.

Selective reconsideration is allowed. Bulk CSV’s earlier6–8% result led to shared
keys/adopted storage; inspect any *remaining* relevant phase before reopening.
Slower call arenas/controllers, R235 partial banks, R236 broad canonical-span
staging and R230 range wrappers are removed; preserve lessons and adverse data.
Timeouts, unstable controls and inconclusive data establish uncertainty, not a
failed design. Allow bounded confirmation/refinement/correction with evidence;
retain original failed conditions. No one-attempt/no-retiming/permanent veto rules.

## Independent regex track

Core-owned Python/native-UTF-8 contract, byte/scalar ranges, original windows,
effective flags, current tokens, ownership/cache semantics are delivered. Continue
independently with adapter-local bridges or pinned immutable development producers.
Normal optional nonpackable adapter0.4; immutabledev68/a7e985ed qualified86internal/
532public per target, unchanged Validate bridge/29normal files; reuse this proof.
Only affected **final adapter qualification** awaits: independent single-match
working/result owners; native UTF-8 group-name enumeration (lookup exists);
token-independent cursor creation with cancellable preparation (per-move alone
insufficient). Remove displaced conversions/DetailedData when supported. No
publication polling. Contract tests, backend semantics/CPU/safety/SizeOf are
separate claims. Missing published capabilities never stop independent development.

## Lasting contracts and delivery

Fully managed/safe; no unsafe/Unsafe/pointers/PInvoke/native probing. Preserve
managed stack admission, host capabilities, cancellation, cycles/XML depth,
checked representation bounds/bounded I/O. No fuel/quotas/independent caps/hidden
allowance, tracing/root inventories/weak reclamation/forcedGC/retries/background
users. Borrowed allowance funds capacity/overlap/results/aliases/caches/pending
users until awaited cleanup. First refusal fails command with original structured
origin despite suppression/finally returns; guest MemoryError remains catchable.
Long streams use bounded host commands. Preserve LythonPathRequest/Cwd/component
resolution and destination on refused copy; never delete-before-copy/replacement.

Focused Release correctness/cancellation/ownership during iteration. Batch full
Windows/Ubuntu actual11/10, originalStress and installed consumers at delivery.
No timeout/assertion relaxation. Process-wide GC tests use existing collections.
CPython remains primary external baseline; include warm I/O/checks/prior-result
cleanup explicitly, separate compilation/startup/final teardown. Preserve raw
adversity outside concise current docs. Existing VM needs fresh lease/identity/
disk proof before staging; persistent evidence separate from RAM fixtures, verify
archives and join every user before releasing lease. B576–B580 terminal/cached.
''',encoding='utf-8')
print('PLAN rewritten around delivery status, active coherent storage migration, whole-phase roadmap and independent regex; prior evidence archived.')
