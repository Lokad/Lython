# Lokad.Lython 0.11.0

Updated 2026-11-11. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial whole-script improvements,
including compile-to-result. One isolated experiment does not complete it.

## Delivery status

- **Fully qualified runtime b5849b04:** Windows/Ubuntu, actual .NET11/10,
  originalStress and installed Release consumers; GREEN43033830025 cached.
  Includes R239/R240; ancestorfe43024046530 remains separately cached.
  R237 runs complete native dictionary-counting segments through existing
  cursor/arithmetic/binding paths. Quiet captured sync elapsed9–11% lower;
  other text shapes/APIs improve with wider controls; allocation flat.
  R236 retained698 factory/variance fixes, direct exception tuples and sync-carrier
  deletion are covered. [All source pairs/cores/adversity](benchmarks/results/2026-11-11-native-counting-loops/README.md).
- **Committed/pushed R2398314c02d:** one cleanup finally per function API,
  deleting duplicate workspace returns. Real compiled-helper/refund reentry
  previously refunded160B still cached on both APIs. 960focused actual11/10 checks
  pass; now covered by the full exactb584 delivery. No CPU claim.
  [Proof](benchmarks/results/2026-11-11-native-helper-refund/README.md).
- **Committed/pushed R240 b5849b04, evidence HEADcc2fedc9:** private totals stay
  in a managed long for a proven callback-free segment, then publish ordinary
  BigInteger on every exit. Observable storage/wider promotion unchanged.
  2978focused actual11/10 checks plus8targeted admission checks pass (some repeat),
  16goldens match CPython3.13. Allocation−9.04%captured/−9.7%ordinary on both APIs;
  controls/compile flat. Quiet ordinary-sync improves in both collections;
  captured/async clocks uncertain. Original report+0.65..+3.40% does not recur
  with fresh processes (−2.78..−0.51%); cause unexplained, all adversity preserved.
  [Exact pairs/decision](benchmarks/results/2026-11-11-private-counter-segments/README.md).
- **Delivery complete:** exactb584 CI43033830025 is GREEN, both platforms/targets,
  originalStress and installed consumers. Terminal cached; never query again.
  Evidence/docs-only HEAD has identical production sources. No uncommitted runtime
  change or active VM collection. R241 is a read-only source gate so far.
- **External checkpoint closed:** qualifiedfe/frozenbf93 versus CPython3.13.16,
  original scripts unchanged. Warm ordinary text1.21–1.22x, captured text2.24–2.27x,
  CSV1.06–1.08x. Compilation and compile-to-result separate; captured gap remains.
  [BENCHMARKS](docs/BENCHMARKS.md), [all9jobs/244.887s](benchmarks/results/2026-11-11-native-loops-cpython-checkpoint/README.md).
- **Debt/uncertainty:** R237 capturedCSV async control−1.76..+2.74%, neutrality
  unresolved; ordinary text controls wider than captured sync. Earlier15f versus
  4aa ordinary-text async+1.92..+2.55% is historical debt, not directly remeasured
  by the698source pair. Preserve desktop adverse data. Decide material regression
  debt before publication; RSS/pending-I/O/embedding tail latency unqualified.

## Completed — preserve history, reuse qualification

| Milestone | Established result / limitation |
| --- | --- |
| Shared compiler facts | Exponential traversal and nonlocal diagnostic correction; binding/module/scope facts reused. Fully qualified; no CPU claim. |
| Direct UTF-8 formatting/storage | Fully qualified; allocation−8.67%, controlled elapsed/CPU5–8% lower. Original adverse15.125ms unexplained and preserved. |
| Native helper returns | Fully qualified; allocation−19.92%sync/−19.31%async. Original elapsed diagnostic; no delivery replay. |
| Calls/setup/CSV | Immutable metadata, async startup reuse, shared binding/workspaces/receiver entry delivered. Selective6–8% CSV reassessment produced shared keys/adopted funded rows. Slower arenas/controllers removed. |
| Lexical writes/iteration | Qualified4625/4aa. Counter allocation−27–48%, quiet warm12–21% lower with control debt. Returned iteration−4.84%allocation/−15.06%estimated peak, elapsed inconclusive. |
| Canonical construction | Qualified752/15f, now covered byfe. Correct allocator proof and reentrant capacity/refund behavior; ordinary binder/runner handles named/keyword-only/variadic init. |
| Text/JSON/IR | Final UTF-8 casing/split/format/JSON, inline short text, span tuples/same-suite jumps delivered. No presumed remaining per-character/token conversion. |
| Regex | Core-owned Python UTF-8 boundary, windows/effective flags/current tokens/ownership delivered. Coordinate consolidation−17–18%Unicode allocation; no CPU claim. |
| R235/R236 broad prototypes | Captured operand banks/canonical span staging fully removed, useful regressions/fixes retained. Flat allocation and mixed/adverse controls do not justify their complexity; no permanent veto. |

Old plans/source gates live in `.git/agent-notes/review-20261031/`, including the
R240 archived previous plan. Experiments and rejected alternatives belong in
[EXPERIMENTS](benchmarks/EXPERIMENTS.md), outside current docs.

The b584 milestone accepts scoped allocation reduction and supported ordinary-sync
direction while preserving report/CSV uncertainty and historical15f ordinary-async
debt. No universal CPU/neutrality claim. Revisit material debt at a coherent source
checkpoint before publication, not another unchanged retiming campaign. CPython
tables remain explicitly qualifiedfe source; do not label them as b584 timings.

## P1 — R241 unify compiled-function input and local storage

**Source-established duplication:** PyExecutableFunction uses parameter-sized
binding storage when RequiresLocalVariableMirroring, then CreateExecutableWorkState
allocates/copies a second local/operand array. ArgumentsAreLocals also gates the
existing linear runner and constructor path. Namespace mirroring and storage
ownership are separate requirements. Do not remove real namespace readers.

- **Proposed invariant:** every compiled function binds directly into its funded
  compiler-sized workspace, including mirrored functions. Keep actual namespace
  stores, parameter mirroring, scope-sensitive contexts and lowered consumers.
  Explicitly keep mirrored functions out of deferred-context execution. Reuse
  existing binder/runner/ownership; no ABI migration, new carrier or mode.
- **Delete:** ArgumentsAreLocals and its redundant selection/clear-length branches,
  the mirrored-function second array/copy, and their detour from the ordinary
  compiled call/initializer runner. Keep top-level/import/generator allocation
  behavior where no bound workspace exists. No universal frame/compiler rewrite.
- **Acceptance:** ordinary/keyword/variadic/default binding and timing, class cells/
  super/decorators/annotations, closures and late namespaces, invalidation after
  allocator admission, exception ordering/cleanup, real async protocols, cancellation,
  first refusal, retained aliases and cache funding through final cleanup. Never
  expose/clear the reused backing while a namespace, result or async user needs it.
- **Contract tradeoff:** larger idle compiler workspaces can remain conservatively
  charged to their existing execution cache until cleanup; earlier rejection is
  acceptable/documented. Admit final capacity before allocation/binding effects.
  No hidden allowance or return to tracing/reclamation.
- **Gate outcome so far:** the adapted existing compiler inspector confirms the
  concrete class-reader helper is mirrored and has6workspace slots for1parameter.
  Every function/module in the maintained six-script catalog is unmirrored.
  Those scripts are controls, not beneficiaries. No predicted improvement to the
  captured-text CPython gap. The value is a simpler universal storage invariant;
  select one useful mirrored script and prove its lifetime before implementation.
- **Bounded gate/comparison:** inspect the actual mirror consumers and bound-array
  lifetimes before editing. Prove one representative complete mirrored-helper
  CSV/text/JSON shape, plus existing unchanged scripts/compilation. Most ordinary
  helpers already share storage; do not predict a broad gain. Focused both-target
  semantic/ownership/cancellation checks, one short source pair. A simpler invariant
  with removed work can be useful without a fixed% threshold; claim CPU only if
  measured. If sharing requires new ownership/dispatch machinery or breaks a real
  consumer, record that obstacle and refine or select another complete phase.

**Independent cell assessment:** StoreThroughOwner unconditionally updates a
shadow namespace and resolves its local slot by name, while Value has a conditional
mirror policy. Real lowered class/typing/generator and late namespace consumers
exist, and RetainLocalsForLambda can activate mirroring dynamically. No namespace
copy removed, no new cell metadata/prototype. Do not treat these writes as dead
without a complete reader/lifetime proof. Prefer the simpler array invariant first.

## Next substantial redesign selection

R238 profile reflects currentfe:1151guest leaves/5.8CPU seconds,58unknown;
native loop12.25%, shared dispatch11.38%, word preparation7.91%, MoveNext4.00%.
Useful/inlined work overlaps. [Raw profile/gate](benchmarks/results/2026-11-11-native-word-costs/README.md).
Do not transfer old native offsets or treat method shares as removable overhead.

| Assessed boundary | Evidence / next coherent selection requirement |
| --- | --- |
| Native word transport/admission | Construction per word is real; removal needs exact alias/binding/resume proof. A constant worst-case admission estimate can overcharge long words/spaceruns about64x, so it is not a reasonable streaming replacement. No prototype or timing rejection. Avoid R230 range arrays/wrappers and new deferred-binding framework. |
| Complete calls/frames | Common calls already borrow, bind into compiler-sized reusable storage and defer contexts. R236 blanket ABI staging was flat/slower. Find a complete measured construction/cleanup phase to remove; no new carriers/arenas/controllers. |
| Operand/scalar transport | R235 partial banks added shared costs with flat allocation. Require a whole producer/consumer representation to disappear while preserving identity/protocols/promotion/projection. R240 is deliberately scoped inside an existing whole segment. |
| Per-record collections | CSV shared keys/adopted rows delivered. Select a remaining measured phase; preserve duplicate/order/header mutation/protocol/reentry/retention. |
| Frontend | Shared binding/module/scope/declaration/direct-child/nonlocal facts delivered. Measure actual duplicate work/retention; preserve annotations/generators/mirrors/executable imports. Compilation does not explain captured-text gap. |

Each selected redesign names removed work/storage and code to delete, affected
scripts, semantic acceptance, one bounded source pair with controls and a
completion/debt decision. Allow justified refinement/measurement correction;
timeouts, unstable controls and inconclusive data establish uncertainty. Fixed
percentages inform decisions, never automatically veto coherent simplification.
Do not treat finishing R240 as completion of the performance objective.

Both APIs already share the same nonasync instruction prefix and suspend only on
incomplete work. Short text stores up to8UTF-8bytes inline; casing writes final
fragments; native split prepays all eventual words. R230's extra ranges added8–9%
allocation/163840Bpeak and are removed. Do not propose these completed mechanisms
again or revive their extra representations without new source evidence.

## Independent regex track

Core development is independent of producer publication. Optional nonpackable
adapter0.4 remains normal. Immutabledev68/a7e985ed qualified86internal/532public
per target, unchanged Validate bridge/29normal files; reuse proof. Only affected
final adapter qualification awaits:

1. Independent single-match working and retained-result owners.
2. Native UTF-8 group-name enumeration; lookup already exists.
3. Token-independent cursor creation with cancellable preparation; per-move insufficient.

Continue core contract/semantics with immutable development producers or adapter
bridges. Remove displaced DetailedData/conversions when native APIs arrive.
Preserve Python Match/FullMatch alternatives, flags/captures/windows, byte/scalar
positions, current tokens/cache funding/no dialect fallback. Backend semantics,
CPU, managed safety and SizeOf remain separate claims. No producer polling loop.

## Lasting constraints and delivery

Fully managed/safe: no unsafe/Unsafe/pointers/PInvoke/native probing. Keep managed
stack admission, host capabilities, cancellation, cycles/XML depth, checked
representations/bounded I/O. No fuel/quotas/independent caps/hidden allowance,
tracing/root inventories/weak reclamation/forcedGC/retries/abandoned users. Borrowed
allowance funds capacity/overlap/results/aliases/caches/pending users until awaited
cleanup; scopes reserve zero. First refusal preserves its origin and fails the
command despite suppression/finally returns; native cleanup stays available.
Guest MemoryError catchable; long streams use bounded host commands. Preserve
LythonPathRequest/Cwd/component resolution; no delete-before-copy/replacement.

Focused Release checks during development; batch full Windows/Ubuntu actual11/10,
originalStress and installed consumers at coherent deliveries. No relaxed
timeouts/assertions; process-wide GC/finalizer tests share existing collections.
CPython primary external baseline, compile/warm/startup separate, I/O/checks/prior
cleanup boundary explicit. Preserve adverse/failed conditions outside docs.

VMlokad@20.166.121.73, key~/.ssh/id_lython-bench.pem. B576/B577/B578/B579/B580 terminal/cached,
raw archives verified/no users or RAM fixtures; never query again. Last recorded
free276156416B after B580; require fresh idle lease/identity/
disk proof before staging. Fixed240MiBfloor/12MiBheadroom. Protect current15f/4aa/
c271/fe images and references used by active work. Retired fresh-csv source.tar
and all earlier retired paths are off limits; no stale cleanup recipes. Retirement
requires independent canonical evidence and fresh path/UID/all-alias/SHA proof.
Workers/logs/maps/evidence persistent, separate from RAM fixtures; archive/verify
before ownership ends. Terminal GREEN43033830025/43024046530/42980759461/42976124076 cached.
Core Release packs only via tools/pack.ps1 to artifacts/nuget/; adapter nonpackable.
Publication/tagging postponed.
