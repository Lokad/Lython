from pathlib import Path
import shutil
r=Path(__file__).resolve().parent;old=r.parent/'native-counter-loops-r237/inspect';out=r/'inspect';out.mkdir(exist_ok=False)
shutil.copyfile(old/'inspect.csproj',out/'inspect.csproj')
text=(old/'Program.cs').read_text(encoding='utf-8')
text=text.replace('Console.WriteLine("code " + Read(code, "Name") + " locals " + string.Join(\',\', locals));', 'Console.WriteLine("code " + Read(code, "Name") + " mirrored=" + Read(code, "RequiresLocalVariableMirroring") + " capacity=" + Read(code, "ValueStorageCapacity") + " locals=" + string.Join(\',\', locals));')
needle='if (args.Length > 1)'
assert needle in text
text=text.replace(needle,'sources.Add(("mirrored-class-reader", "def snapshot(value):\\n class Record:\\n  payload=value\\n return Record.payload\\nprint(snapshot(42))\\n"));\n'+needle)
(out/'Program.cs').write_text(text,encoding='utf-8')
print('Existing private compiler inspector adapted for mirror/capacity facts; no runtime mutation or timing.')
