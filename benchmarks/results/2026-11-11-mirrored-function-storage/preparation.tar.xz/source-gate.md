# R241 — compiled function workspace ownership

Read-only gate on b5849b04 runtime/evidencecc2fedc9. No prototype yet.
PyExecutableFunction constructor/ArgumentsAreLocals couples namespace mirroring
to parameter-only binding storage. CreateExecutableWorkState then allocates and
copies a second local array. Existing linear call/initializer entry excludes that
same shape. This is demonstrated source duplication, not a measured dominant cost.

Keep real mirrored namespaces and scope contexts. Bind every compiled function
into final compiler-sized storage, using the existing owner and runner; remove
ArgumentsAreLocals, its array/clear-length/entry branches and the second copy.
CanDeferInvocationContext must retain its explicit no-mirroring condition.
Most ordinary helpers already share storage, so select a useful complete mirrored
script before any speed claim; no blanket span ABI or new framework. Live cache
capacity stays funded; larger idle capacity/earlier denial is a documented tradeoff.

Do not conflate this with removing owner namespaces. Source readers include
ResolveName/TryReadNonlocalValue, lowered class/typing/generator contexts,
RetainLocalsForLambda (which can activate mirroring dynamically), globals and
locals snapshots. ExecutableCell.Value conditionally mirrors while incoming
StoreThroughOwner always writes Variables and resolves a slot by name; these
are candidates for a later complete storage proof, not established dead state.
No cell metadata or namespace changes are authorized by this source finding alone.

Focused semantics/retained aliases/first refusal/real pending cancellation and
cleanup on both actual targets, then one bounded complete-script pair with
controls/compilation. Stop/refine if a real consumer needs another owner/control
framework. No fixed timing veto or permanent rejection from uncertain data.

Actual compiler inspection on frozenb584 source: class-reader snapshot(value)
is mirrored,1parameter/6workspace slots. Every function/module in the six-script
catalog is unmirrored. These existing scripts are controls, not beneficiaries;
do not claim this closes captured-text gap. Require a useful mirrored complete
script; pursue for deleted storage/selection machinery if semantics and control
measurements support it. Existing fullb584 delivery43033830025 is now terminalGREEN.
