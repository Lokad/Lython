from pathlib import Path
import ast,hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;q=r/'b581';q.mkdir(exist_ok=False)
old=r.parent/'native-counter-loops-r237/b576';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
meta=json.loads((r/'diagnostic-identity.json').read_text(encoding='utf-8'))
for name,h in meta['sourceHashes'].items():assert sha(Path(name))==h,name
root='/home/lokad/lython-bench-checks/mirrored-storage-b581-20261111';unit='lython-b581-mirrored-storage-20261111'
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision='R241 compiler-workspace prototype versus fully qualified b5849b04. 4744 focused actual11/10 checks; new CSV local-class beneficiary plus unchanged ordinary CSV control. Desktop allocation -4.92% both APIs, original sync elapsed +7.98..+8.15% preserved. Quiet comparison decides that debt; no CPython ratio.',
 coreSHA256={role:meta['images']['before'if role.startswith('reference')else'candidate']['Lokad.Lython.dll']for role in ['reference','candidate','reference-control','candidate-control']},catalogSHA256=sha(r/'catalog.json'))
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(q/'source-identity.json').write_text(json.dumps(dict(beforeRevision='b5849b04',prototypeUncommitted=True,sourceSHA256=meta['sourceHashes'],changedProductionFiles=meta['changedProductionFiles'],focusedChecks=4744,lastFullyQualified='b5849b04',baselineArchive='Existing private-counter-segments source/core archive contains qualified b584; fresh remote baseline SHA verified, reused as hardlink to avoid unnecessary disk storage.'),indent=2)+'\n',encoding='utf-8')
shutil.copyfile(r/'catalog.json',q/'representative.json')
shutil.copyfile(r/'images/candidate/Lokad.Lython.dll',q/'current-core.dll')
jobs=[['scripts.csv-local-record-class.large','warm'],['scripts.csv-local-record-class.large','warm-async'],['scripts.csv-validated-records.large','warm']]
text=(old/'collect.py').read_text(encoding='utf-8').replace('/native-counter-loops-b576-20261111','/mirrored-storage-b581-20261111')
begin=text.index('jobs=');end=text.index('\nenv = ',begin)
text=text[:begin]+'jobs='+repr(jobs)+'\nassert len(jobs)==3 and all(case in cases for case,lane in jobs)\n'+text[end:]
begin=text.index("purpose='R237");end=text.index("',\n                  warmupSeconds",begin)
text=text[:begin]+"purpose='R241 bounded storage source pair versus qualifiedb584, local-class CSV both APIs and unchanged ordinaryCSVsync. Preserve original desktop sync adversity. Warm includes mediated RAM I/O/full checks/prior-result cleanup, excludes compile/startup/reset/protocol/final caches; no CPython ratio"+text[end:]
text=text.replace(' < 170',' < 110').replace('Reserve40seconds','Reserve40seconds')
ast.parse(text);(q/'collect.py').write_text(text,encoding='utf-8',newline='\n')
for name in ['archive-owned.py','run.sh','retrieve.py','summarize.py','launch.py']:
 text=(old/name).read_text(encoding='utf-8').replace('native-counter-loops-b576','mirrored-storage-b581').replace('lython-b576-native-counter-loops','lython-b581-mirrored-storage').replace('B576 five-job','B581 three-job')
 text=text.replace("len(raw['jobs'])==5","len(raw['jobs'])==3").replace('jobs=5','jobs=3').replace("['jobs']==5","['jobs']==3")
 text=text.replace('ownerSeconds=210','ownerSeconds=150').replace('seconds=270','seconds=210').replace("['elapsedSeconds']<210","['elapsedSeconds']<150")
 if name.endswith('.py'):ast.parse(text)
 (q/name).write_text(text,encoding='utf-8',newline='\n')
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for name in ['current-core.dll','representative.json','source-identity.json','identity.json','collect.py','archive-owned.py','run.sh']:t.add(q/name,arcname=name)
with tarfile.open(q/'payload.tgz')as t:expanded=sum(((m.size+4095)//4096)*4096 for m in t.getmembers())
config=dict(root=root,unit=unit,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha(q/'payload.tgz'),requiredFreeBytes=252*1024*1024+expanded+65536,retire=[],identity=identity)
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
text=(old/'remote-launch.py').read_text(encoding='utf-8').replace('lython-b576-fixtures','lython-b581-fixtures').replace('jobs=5','jobs=3').replace('ownerSeconds=210','ownerSeconds=150').replace('RuntimeMaxSec=210','RuntimeMaxSec=150')
baseline="base/'private-counter-b579-20261111/candidate/Lokad.Lython.dll'"
text=text.replace("with(base/'comparison-vm.lock')", "protected["+baseline+"]="+repr(meta['images']['before']['Lokad.Lython.dll'])+"\nwith(base/'comparison-vm.lock')")
text=text.replace("os.link(root/name,root/role/'Lokad.Lython.dll')","os.link("+baseline+" if role=='reference' else root/name,root/role/'Lokad.Lython.dll')")
ast.parse(text.replace('config=CONFIG','config='+repr(config)).replace('inventoryOnly=INVENTORY_ONLY','inventoryOnly=True'))
(q/'remote-launch.py').write_text(text,encoding='utf-8',newline='\n')
print('Prepared three short source pairs,150s owner. Reuse verified qualifiedb584 hardlink; no remote deletion. Fresh inventory required.')
