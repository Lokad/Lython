from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
root=Path(__file__).resolve().parent
ordered=root/'ordered';ordered.mkdir(exist_ok=True)
candidate=ordered/'candidate';candidate.mkdir(exist_ok=True)
original='/home/lokad/lython-bench-checks/binding-facts-b197-20261104'
remote=original+'/ordered'
binary=Path('benchmarks/Lokad.Lython.Benchmarks/bin/Release/net11.0/Lokad.Lython.dll')
assert binary.read_bytes()==Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll').read_bytes()
shutil.copyfile(binary,candidate/binary.name)
identity=json.loads((root/'identity.json').read_text(encoding='utf-8'))
identity['sourceRevision']='e3f83430 plus B197 explicit binding order and canonical snapshots'
identity['coreSHA256']['candidate']=hashlib.sha256(binary.read_bytes()).hexdigest()
files=subprocess.check_output(['git','diff','--name-only','--','src'],text=True).splitlines()
identity['sourceFiles']={f:hashlib.sha256(Path(f).read_bytes()).hexdigest() for f in files}
(ordered/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
(ordered/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src']))
for f in ['catalog.json','cpython-worker.py','pre-code-plan.md','pre-capture-plan.md','initial-source.patch','module-lifetime-correction.md','pre-order-source.patch','binding-order-correction.md','ordered-binding-golden.py','ordered-binding-golden.txt']:
 shutil.copyfile(root/f,ordered/f)
s=(root/'collect.py').read_text(encoding='utf-8').replace("root = Path('"+original+"')","root = Path('"+remote+"')")
s=s.replace("(0,'warm'),(2,'warm'),(3,'warm')", "(0,'warm'),(3,'warm')").replace('started < 200','started < 170')
s=s.replace('B197 binding construction versus qualified B194;', 'B197 final ordered binding construction and snapshots versus qualified B194;')
(ordered/'collect.py').write_text(s,encoding='utf-8',newline='\n')
setup=(root/'setup.py').read_text(encoding='utf-8').replace("root=Path('"+original+"')","root=Path('"+remote+"')")
(ordered/'setup.py').write_text(setup,encoding='utf-8',newline='\n')
archive=(root/'archive.py').read_text(encoding='utf-8').replace("root=Path('"+original+"')","root=Path('"+remote+"')").replace("len(r['jobs'])==6","len(r['jobs'])==5").replace("'module-lifetime-correction.md'", "'module-lifetime-correction.md','pre-order-source.patch','binding-order-correction.md','ordered-binding-golden.py','ordered-binding-golden.txt'")
(ordered/'archive.py').write_text(archive,encoding='utf-8',newline='\n')
shutil.copyfile(root/'summarize.py',ordered/'summarize.py')
with tarfile.open(ordered/'payload.tgz','w:gz') as t:
 for f in ['candidate','catalog.json','identity.json','source.patch','collect.py','cpython-worker.py','setup.py','archive.py','pre-code-plan.md','pre-capture-plan.md','initial-source.patch','module-lifetime-correction.md','pre-order-source.patch','binding-order-correction.md','ordered-binding-golden.py','ordered-binding-golden.txt']:
  t.add(ordered/f,arcname=f)
print(json.dumps({'frozen':identity['coreSHA256']['candidate'],'payloadBytes':(ordered/'payload.tgz').stat().st_size,'jobs':5}))
