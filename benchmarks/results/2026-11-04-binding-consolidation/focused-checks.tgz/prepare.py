from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
root=Path(__file__).resolve().parent
prior=root.parent/'fixed-text-construction-b194'
remote='/home/lokad/lython-bench-checks/binding-facts-b197-20261104'
before='/home/lokad/lython-bench-checks/fixed-text-construction-b194-20261104/final/candidate'
candidate=root/'candidate';candidate.mkdir(exist_ok=True)
binary=Path('benchmarks/Lokad.Lython.Benchmarks/bin/Release/net11.0/Lokad.Lython.dll')
assert binary.read_bytes()==Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll').read_bytes()
shutil.copyfile(binary,candidate/binary.name)
files=subprocess.check_output(['git','diff','--name-only','--','src'],text=True).splitlines()
assert set(files)=={'src/Lokad.Lython/Frontend/ScopeDirectiveFacts.cs','src/Lokad.Lython/Frontend/ExecutableScript.Builder.cs'}
identity=dict(sourceRevision='e3f83430 plus B197 corrected binding consolidation',baselineRuntimeRevision='2d46dc8e',
 coreSHA256={'before-control':'ba48576af397ef62ce62a493b7ab4eb2ff845874fe44c512e6e5ceadf8e63783',
 'candidate':hashlib.sha256(binary.read_bytes()).hexdigest(),'after-control':'ba48576af397ef62ce62a493b7ab4eb2ff845874fe44c512e6e5ceadf8e63783'},
 sourceFiles={f:hashlib.sha256(Path(f).read_bytes()).hexdigest() for f in files})
(root/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
(root/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src']))
for f in ['catalog.json','cpython-worker.py']:shutil.copyfile(prior/f,root/f)
s=(prior/'collect.py').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/fixed-text-construction-b194-20261104',remote)
s=s.replace("worker = Path('/home/lokad/lython-bench-checks/borrowed-native-arguments-b192-20261104/refinement/candidate/Lokad.Lython.Benchmarks.dll')",f"worker = Path('{before}/Lokad.Lython.Benchmarks.dll')")
s=s.replace("jobs = [(list(cases)[index],lane) for lane in ['warm','warm-async'] for index in [0,1,2,3,4,5]]", "jobs = [(list(cases)[i],lane) for i,lane in [(0,'compile'),(3,'compile'),(4,'compile-run'),(0,'warm'),(2,'warm'),(3,'warm')]]")
s=s.replace('if job_index >= 6:', 'if job_index >= 3:')
s=s.replace('warmupSeconds=3, targetBatchSeconds=.20, rounds=9', 'warmupSeconds=5, targetBatchSeconds=.20, rounds=9').replace('end=time.monotonic()+3;', 'end=time.monotonic()+5;').replace('started < 350','started < 200')
s=s.replace("for api in ['sync','async']:","for api in ['sync']:").replace("'reverse','warm',api]","'reverse','compile',api]")
s=s.replace("str(Path('"+remote+"/tool/complete-jobs.dll'))", "str(Path('/home/lokad/lython-bench-checks/fixed-text-construction-b194-20261104/tool/complete-jobs.dll'))")
s=s.replace('B194 fixed immutable UTF8 construction versus B192; five complete jobs and casing control both APIs; separate eight-case allocation diagnostic includes casing/padding/slices;', 'B197 binding construction versus qualified B194; two compile-only jobs, fresh config and three warm whole-script controls; separate eight-case compilation allocation diagnostic;')
s=s.replace("    subprocess.run([str(dotnet),str(worker),'--compare','check-machine','--out',str(out/'machine-after.json')]", "    time.sleep(5) # Settle owned cleanup before original quiet gate.\n    subprocess.run([str(dotnet),str(worker),'--compare','check-machine','--out',str(out/'machine-after.json')]")
(root/'collect.py').write_text(s,encoding='utf-8',newline='\n')
setup=f'''from pathlib import Path
import hashlib,json,shutil
root=Path({remote!r});before=Path({before!r});candidate=root/'candidate'
for file in before.iterdir():
 if file.name=='Lokad.Lython.dll':continue
 if file.name in ['Lokad.Lython.Benchmarks.dll','Lokad.Lython.Benchmarks.deps.json','Lokad.Lython.Benchmarks.runtimeconfig.json']:shutil.copyfile(file,candidate/file.name)
 else:(candidate/file.name).symlink_to(file.resolve(),target_is_directory=file.is_dir())
assert hashlib.sha256((candidate/'Lokad.Lython.dll').read_bytes()).hexdigest()==json.loads((root/'identity.json').read_text())['coreSHA256']['candidate']
'''
(root/'setup.py').write_text(setup,encoding='utf-8',newline='\n')
archive=(prior/'final/archive.py').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/fixed-text-construction-b194-20261104/final',remote).replace("len(r['jobs'])==12","len(r['jobs'])==6").replace("for api in ['sync','async']:","for api in ['sync']:").replace("'pre-capture-plan.md'","'pre-capture-plan.md','initial-source.patch','module-lifetime-correction.md'")
(root/'archive.py').write_text(archive,encoding='utf-8',newline='\n')
summary=(prior/'summarize.py').read_text(encoding='utf-8').replace("for api in ['sync','async']:","for api in ['sync']:")
(root/'summarize.py').write_text(summary,encoding='utf-8',newline='\n')
with tarfile.open(root/'payload.tgz','w:gz') as t:
 for f in ['candidate','catalog.json','identity.json','source.patch','collect.py','cpython-worker.py','setup.py','archive.py','pre-code-plan.md','pre-capture-plan.md','initial-source.patch','module-lifetime-correction.md']:
  t.add(root/f,arcname=f)
print(json.dumps({'frozen':identity['coreSHA256']['candidate'],'payloadBytes':(root/'payload.tgz').stat().st_size,'jobs':6,'compilationAllocationCases':8}))
