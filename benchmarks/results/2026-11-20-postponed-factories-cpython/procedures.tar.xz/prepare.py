from pathlib import Path
import ast
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
template = lab.parent/'factory-cpython-b1151'
pair = lab.parent/'prepared-postponed-text'
donor = pair/'quiet'
core = 'Lokad.Lython.dll'
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def write(name, value):
    if name.endswith('.py'): ast.parse(value)
    (lab/name).write_text(value,encoding='utf-8',newline='\n')
def save(name, value):
    write(name,json.dumps(value,ensure_ascii=False,indent=2)+'\n')

previous=load(donor/'config.json')
receipt=load(donor/'archive-receipt.json')
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease'] and receipt['allWorkersJoined']
assert sha(donor/'observations.tgz')==receipt['archiveSHA256']
frozen=load(pair/'frozen-identity.json')
measured=frozen['candidateCommit']
retained=subprocess.check_output(['git','rev-parse','551fde44e']).decode().strip()
assert not subprocess.check_output(['git','diff','--name-only',measured,retained,'--','src','Directory.Build.props','Directory.Packages.props',
                                   'benchmarks/Lokad.Lython.Benchmarks','benchmarks/cpython-worker.py','global.json'])
source=pair/'frozen/candidate'
image=lab/'frozen/candidate'
image.mkdir(parents=True,exist_ok=True)
files=frozen['images']['candidate']
assert len(files)==32 and files==previous['identity']['imageFiles']['candidate']
assert {name:sha(source/name) for name in files}==files
for name in files: shutil.copyfile(source/name,image/name)
assert {name:sha(image/name) for name in files}==files

catalog=load(donor/'representative.json')
ids=['scripts.annotated-rule-closures.postponed','scripts.annotated-rule-closures.nested-factories.postponed']
catalog['cases']=[next(c for c in catalog['cases'] if c['id']==key) for key in ids]
save('representative.json',catalog)
catalog_hash=sha(lab/'representative.json')
shutil.copyfile(template/'cpython-worker.py',lab/'cpython-worker.py')
protocol_hash=sha(lab/'cpython-worker.py')
assert protocol_hash==load(template/'identity.json')['cpythonWorkerSHA256']==sha(Path('benchmarks/cpython-worker.py'))
identity=dict(sourceRevision=retained,imageSource=measured,purpose='B1156 postponed factories against CPython',
    imageFiles={'candidate':files},auxiliaryFiles={name:digest for name,digest in files.items() if name!=core},
    coreSHA256={'candidate':files[core],'candidate-control':files[core]},
    catalogSHA256=catalog_hash,cpythonWorkerSHA256=protocol_hash)
save('identity.json',identity)
save('build-revision.json',dict(sourceRevision=retained,imageSource=measured,coreSHA256=files[core]))
sdk = Path.home()/'.dotnet11'
dotnet = sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
with (lab/'verify.log').open('wb') as log:
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',lab/'representative.json',
         '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',lab/'cpython-worker.py',
         '--out',lab/'verify.json'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
verified=load(lab/'verify.json')
assert verified['state']=='Completed' and verified['catalogSha256']==catalog_hash

root='/home/lokad/lython-bench-checks/postponed-cpython-b1156-20261120'
unit='lython-b1156-postponed-cpython-20261120'
oldroot=load(template/'config.json')['root']
for name in ('collect.py','archive-owned.py','launch.py','retrieve.py','run.sh'):
    text=(template/name).read_text(encoding='utf-8').replace(oldroot,root).replace('B1151','B1156')
    if name=='collect.py':
        start=text.index('    for case_id,diagnostic in ')
        end=text.index('\n',start)
        text=text[:start]+f'    for case_id,diagnostic in {[(key,False) for key in ids]!r}:'+text[end:]
        text=text.replace('lanes = ["warm"] if case_id == "scripts.csv-invoice.large" else ["warm", "compile-run", "compile"]',
            'lanes = ["warm", "compile-run", "compile"]')
        text=text.replace('started<225','started<205')
    if name in ('archive-owned.py','retrieve.py'):
        text=text.replace("['jobs'])==3","['jobs'])==2").replace("['jobs']==3","['jobs']==2").replace('jobs=3,','jobs=2,')
    if name=='launch.py': text=text.replace('213','185')
    write(name,text)

names=('representative.json','identity.json','collect.py','archive-owned.py','run.sh','cpython-worker.py')
payload=lab/'payload.tgz'
with tarfile.open(payload,'w:gz') as archive:
    for name in names: archive.add(lab/name,arcname=name)
config=dict(root=root,unit=unit,source=previous['root'],sourceRole='candidate',sourceFiles=files,
    sourceCatalogSHA256=previous['catalogSHA256'],catalogSHA256=catalog_hash,identity=identity,retireGroups=[],
    donorArchiveSHA256=receipt['archiveSHA256'],payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),
    unpackedBytes=sum((lab/name).stat().st_size for name in names),cpythonWorkerSHA256=protocol_hash)
save('config.json',config)
launcher=(template/'remote-launch.py').read_text(encoding='utf-8')
start,end=launcher.index('\nc=')+1,launcher.index('\nb=Path(')
launcher=launcher[:start]+'c='+repr(config)+launcher[end:]
write('remote-launch.py',launcher.replace('lython-b1151-fixtures','lython-b1156-fixtures').replace('RuntimeMaxSec=285','RuntimeMaxSec=245'))
print('Verified full retained image and two CPython goldens for six comparison lanes.')
