set -e
export DOTNET_ROOT=/home/vermorel/.dotnet
export DOTNET_ROOT_X64=$DOTNET_ROOT
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/supplied-operand-window-20261123
"$DOTNET_ROOT/dotnet" test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter 'FullyQualifiedName~SharedIntegerChain|FullyQualifiedName~ExecutableOperandStack|FullyQualifiedName~AssignmentTarget|FullyQualifiedName~Cancellation|FullyQualifiedName~MemoryOwnership|FullyQualifiedName~NativeTupleReturn' > "$lab/ubuntu-public.log" 2>&1 || { tail -30 "$lab/ubuntu-public.log"; exit 1; }
tail -7 "$lab/ubuntu-public.log"
