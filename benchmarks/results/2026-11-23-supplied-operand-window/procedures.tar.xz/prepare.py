from pathlib import Path
import copy, hashlib, json, os, shutil, subprocess, textwrap

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
tree = repo / '.git/agent-worktrees/supplied-operand-window-20261123'
prior = lab.parent / 'supplied-call-accumulation-20261123'
comparison = lab / 'comparison'
comparison.mkdir(exist_ok=True)
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda data: hashlib.sha256(data).hexdigest()
digest = lambda path: sha(path.read_bytes())
def write(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')
git = lambda *args: subprocess.check_output(['git','-C',tree,*args]).decode().strip()
reference, candidate = git('rev-parse','HEAD^'), git('rev-parse','HEAD')
assert not git('status','--porcelain')
assert reference.startswith('4b2700e5a')
dotnet = Path.home() / '.dotnet11/dotnet.exe'
python = 'C:/Python313/python.exe'
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))

original = read(prior/'comparison/representative.json')
catalog = copy.deepcopy(original)
module = catalog['cases'][0]
assert module['id'] == 'scripts.ordinary-fully-supplied-helper'
function = copy.deepcopy(module)
function['id'] += '.local-function'
prefix, loop = module['source'].split('total = 0\n')
assert loop.endswith('print(total)\n')
function['source'] = prefix + '\ndef report():\n' + textwrap.indent('total = 0\n'+loop[:-13], '    ') + '    return total\n\nprint(report())\n'
assert subprocess.check_output([python,'-I','-c',function['source']],text=True) == function['expectedOutput']
body = function['source'].encode('utf-8')
function['sourceSha256'] = sha(body)
function['sourceUtf8Bytes'] = len(body)
catalog['cases'] = [module, function, *catalog['cases'][1:]]
write(comparison/'representative.json',catalog)
jobs = read(prior/'comparison/jobs.json')['warm']
jobs.insert(2,[function['id'],'warm'])
write(comparison/'jobs.json',{'warm':jobs})

protocol = repo/'benchmarks/cpython-worker.py'
proof = read(prior/'comparison/identity.json')
assert digest(protocol) == proof['cpythonWorkerSHA256']
core = 'Lokad.Lython.dll'
actual = {}
for role in ('reference','candidate'):
    image = lab/role
    image.mkdir(exist_ok=True)
    files = proof['imageFiles']['candidate']
    assert len(files) == 32
    for name, expected in files.items():
        donor = prior/'candidate'/name
        assert digest(donor) == expected
        if role == 'candidate' and name == core:
            donor = lab/'frozen/bin/Lokad.Lython/release_net11.0'/core
        shutil.copyfile(donor,image/name)
    actual[role] = {name:digest(image/name) for name in files}
    for helper in ('ValidatedAllocation','Inspect'):
        for suffix in ('.dll','.deps.json','.runtimeconfig.json'):
            name = helper+suffix
            shutil.copyfile(prior/'candidate'/name,image/name)
    subprocess.run([dotnet,image/'Inspect.dll',comparison/'representative.json',lab/(role+'-tape.json')],
        env=env, check=True, timeout=35)
    verification = comparison/(role+'-verify.json')
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',comparison/'representative.json',
        '--dotnet',dotnet,'--python',python,'--python-worker',protocol,'--out',verification],env=env,check=True,timeout=95)
    data = read(verification)
    assert data['state']=='Completed' and data['caseCount']==5
    assert data['launched']['library']['sha256']==actual[role][core]
    assert all(digest(image/name)==expected for name,expected in actual[role].items())
assert [name for name in files if actual['reference'][name]!=actual['candidate'][name]]==[core]
assert actual['reference'][core] == proof['imageFiles']['candidate'][core]
write(comparison/'identity.json',dict(sourceRevision=reference,candidate=candidate,
    purpose='B1524 reuse the exact integer argument window and accumulator before closed calls',
    imageFiles=actual,coreSHA256={k:rows[core] for role,rows in actual.items() for k in (role,role+'-control')},
    cpythonWorkerSHA256=proof['cpythonWorkerSHA256'],expectedCPythonSHA256=proof['expectedCPythonSHA256'],
    catalogs={name:dict(sha256=digest(comparison/name)) for name in ('representative.json','jobs.json')}))

def adapt(name, replacements):
    source = (prior/name).read_text(encoding='utf-8')
    for before, after in replacements:
        assert before in source, (name,before)
        source = source.replace(before, after)
    compile(source,str(lab/name),'exec')
    (lab/name).write_text(source,encoding='utf-8',newline='\n')

adapt('allocations.py',())
adapt('stage.py',(
    ('supplied-call-accumulation-b1522-20261123','supplied-operand-window-b1524-20261123'),
    ('csv-short-utf8-typed-reader-b1520-20261123','supplied-call-accumulation-b1522-20261123'),
    ("'reference':root/'reference'","'reference':root.parent/'{reference}'/'candidate'"),
    ('lython-b1522-fixtures','lython-b1524-fixtures'),('len(jobs) == 5','len(jobs) == 6'),('< 270,','< 320,'),
    ('    for role in ("candidate","reference"):\n        bundle.add(lab/role/"Lokad.Lython.dll",arcname=role+"-core.dll")',
     '    bundle.add(lab/"candidate/Lokad.Lython.dll",arcname="candidate-core.dll")'),
))
previous_quiet = (prior/'quiet.py').read_text(encoding='utf-8')
begin = previous_quiet.index(" for role,files in identity['imageFiles'].items():")
finish = previous_quiet.index(" os.link(reference/'cpython-worker.py'",begin)
adapt('quiet.py',(
    ('lython-b1522-supplied-call-accumulation-20261123','lython-b1524-supplied-operand-window-20261123'),
    ('.+b1522-','.+b1524-'),('lython-b1522-stage-','lython-b1524-stage-'),
    ('Five bounded lanes write under 1 MiB of receipts. A 49 MiB','Six bounded lanes write under 1 MiB of receipts. A 47 MiB'),
    ('49 * 1024 * 1024','47 * 1024 * 1024'),('needs two cores','needs one core'),
    ("'candidate-core.dll','reference-core.dll'","'candidate-core.dll'"),
    (previous_quiet[begin:finish],""" for role,files in identity['imageFiles'].items():
  image=root/role if role=='candidate' else reference/'candidate'
  if role=='candidate':image.mkdir()
  for name,sha in files.items():
   if name=='Lokad.Lython.dll' and role=='candidate':
    (root/'candidate-core.dll').rename(image/name)
   elif role=='candidate':
    os.link(reference/'candidate'/name,image/name)
   assert digest(image/name)==sha,(role,name)
"""),
    ('RuntimeMaxSec=320','RuntimeMaxSec=380'),('seconds=253','seconds=294'),
))
adapt('summarize.py',(
    ('== 5\nassert hashlib','== 6\nassert hashlib'),('len(warm["jobs"])==5','len(warm["jobs"])==6'),
    ('timedBatches=140','timedBatches=168'),
))
