from pathlib import Path
import gzip, hashlib, json, shutil, subprocess, tarfile

lab = Path(__file__).resolve().parent
root = lab.parents[3]
comparison = lab/'comparison'
quiet = comparison/'quiet'
dest = root/'benchmarks/results/2026-11-23-supplied-operand-window'
sha = lambda data: hashlib.sha256(data).hexdigest()
digest = lambda path: sha(path.read_bytes())
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
git = lambda *args: subprocess.check_output(['git',*args],cwd=root)

identity = read(comparison/'identity.json')
receipt = read(quiet/'terminal-status.json')
assert receipt['exitCode']=='0' and not receipt['live'] and not receipt['fixtures']
assert all(receipt['receipt'][k] for k in ('complete','quietBeforeAndAfter','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
assert digest(quiet/'observations.tar.xz')==receipt['receipt']['archiveSHA256']
assert read(quiet/'summary.json')['timedBatches']==168
assert all(row['peakAdmission'][0] == row['peakAdmission'][1] for row in read(lab/'allocation-summary-six.json'))
assert len(read(lab/'tape-summary.json')['onlyInstructionChanges']) == 1
patch = git('diff','--binary',identity['sourceRevision'],identity['candidate'],'--','src','tests')
(lab/'comparison.patch').write_bytes(patch)
identity['comparisonPatchSHA256'] = sha(patch)
if (lab/'retained-revision').exists():
    revision = (lab/'retained-revision').read_text(encoding='utf-8-sig').strip()
    assert not git('diff','--name-only',revision,identity['candidate'],'--','src','tests')
    identity['retainedRevision'] = revision

dest.mkdir(exist_ok=True)
assert all(path.name=='README.md' for path in dest.iterdir())
for role, files in identity['imageFiles'].items():
    assert len(files)==32 and all(digest(lab/role/name)==value for name,value in files.items())
    if role=='candidate':
        core = lab/role/'Lokad.Lython.dll'
        (dest/(role+'-core.dll.gz')).write_bytes(gzip.compress(core.read_bytes(),mtime=0))
(dest/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ('observations.tar.xz','summary.json','terminal-status.json'):
    shutil.copyfile(quiet/name,dest/name)
for name in ('allocation-summary-six.json','tape-summary.json'):
    shutil.copyfile(lab/name,dest/name)
with tarfile.open(dest/'procedures.tar.xz','w:xz') as archive:
    for name in ('archive.py','prepare.py','stage.py','quiet.py','summarize.py','allocations.py','tape_diff.py',
        'test-ubuntu.sh','comparison.patch','reference-tape.json','candidate-tape.json','ubuntu-public.log',
        'reference-allocation-six.json','candidate-allocation-six.json',
        'comparison/reference-verify.json','comparison/candidate-verify.json','comparison/quiet/observe-not-before',
        'comparison/quiet/launch.log'):
        archive.add(lab/name,arcname=name)
print(dest)
