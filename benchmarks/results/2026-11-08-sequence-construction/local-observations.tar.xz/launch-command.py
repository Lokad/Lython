from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'sequence-construction-b428-20261108'
reference=base/'binding-transport-b427-20261108/candidate'
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not root.exists() and not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 payload=sys.stdin.buffer.read(1911699+1)
 assert len(payload)==1911699 and hashlib.sha256(payload).hexdigest()=='fb5c3ed0cc1959c2cecc6ab91d27d62fb4488639b83af752896cb1adcbfff37f'
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as a:
  required=sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+256*1024*1024
  reclaim=None
  if shutil.disk_usage(base).free<=required:
   prior=base/'csv-call-debt-b426-20261108'
   receipt=json.loads((prior/'archive-receipt.json').read_text())
   assert receipt['complete'] and receipt['archiveSHA256']=='6071077a00d06bc869703d2ad81dc7805d1f10a27143868a5f988805ecce190e'
   assert hashlib.sha256((prior/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
   target=prior/'profiles';assert target.is_dir() and not target.is_symlink() and target.resolve().parent==prior.resolve() and prior.resolve().parent==base.resolve()
   before=shutil.disk_usage(base).free
   shutil.rmtree(target)
   reclaim=dict(path=str(target),reason='Verified redundant B426 extract; immutable archive and independently verified local evidence retained.',archiveSHA256=receipt['archiveSHA256'],beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free)
  assert shutil.disk_usage(base).free>required
  root.mkdir();a.extractall(root,filter='data')
  if reclaim:(root/'reclaimed-redundant-extract.json').write_text(json.dumps(reclaim,indent=2)+'\n')
 for role in ['reference','candidate']:
  target=root/role;shutil.copytree(reference,target,copy_function=os.link)
  if role=='candidate':
   (target/'Lokad.Lython.dll').unlink();os.link(root/'current-core.dll',target/'Lokad.Lython.dll')
 os.link(root/'reference/Lokad.Lython.dll',root/'baseline-core.dll')
 (root/'cpython-worker.py').symlink_to(base/'prepared-call-layout-b384-20261107/cpython-worker.py')
 owned_ram=root/'guest-fixtures';assert not owned_ram.exists();owned_ram.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b428-fixtures',str(owned_ram)],check=True)
 identity=json.loads((root/'identity.json').read_text())
 for role in ['candidate','reference']:
  assert hashlib.sha256((root/role/'Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256'][role]
  for name,digest in identity['auxiliaryFiles'].items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==digest
 for name in ['collect.py','archive-owned.py']:ast.parse((root/name).read_text())
 assert 'assert len(jobs)==4 ' in (root/'collect.py').read_text()
 assert "len(r['jobs'])==4" in (root/'archive-owned.py').read_text()
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 setup=dict(freeBytes=shutil.disk_usage(base).free,coreAndEveryAuxiliaryVerifiedInBothRoles=True,
  allFourJobsValidated=True,ownerSeconds=150,stopSeconds=30,marginSeconds=30)
 assert setup['freeBytes']>256*1024*1024
 (root/'setup.json').write_text(json.dumps(setup,indent=2)+'\n');print(json.dumps(setup),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b428-sequence-construction-20261108','--property=User=lokad',
 '--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=150','--property=TimeoutStopSec=30',
 '--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
