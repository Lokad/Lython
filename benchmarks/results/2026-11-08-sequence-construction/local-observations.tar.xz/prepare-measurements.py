from pathlib import Path
import ast, hashlib, json, os, shutil, subprocess, tarfile

r=Path(__file__).parent
previous=r.parent/'linear-keyword-calls-r71-refined/transport-correction'
focused=json.loads((r/'binding-focused.json').read_text(encoding='utf-8'))
for target in ['net11','net10']:
 assert focused['checks']['binding-internal-'+target]['passed']==1729
 assert focused['checks']['binding-public-'+target]['passed']==597
baseline=json.loads((r/'baseline.json').read_text(encoding='utf-8'))
assert hashlib.sha256((r/'images/before/Lokad.Lython.dll').read_bytes()).hexdigest()==baseline['coreSHA256']
shutil.copytree(r/'images/before',r/'images/candidate',copy_function=os.link)
core=r/'images/candidate/Lokad.Lython.dll';core.unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',core)
shutil.copyfile(core,r/'current-core.dll')
assert hashlib.sha256(core.read_bytes()).hexdigest()==focused['checks']['net11-coreSHA256']
for name in ['catalog.json','representative.json','setup-contract.json']:shutil.copyfile(previous/name,r/name)
local=dict(sourceRevision='a34f56b5 plus R72 shared intrinsic list/tuple construction',baseline=baseline,
 coreSHA256={role:hashlib.sha256((r/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']},
 productionSources={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest()for p in Path('src/Lokad.Lython').rglob('*.cs')if not any(x in ['bin','obj']for x in p.parts)})
(r/'identity.json').write_text(json.dumps(local,indent=2)+'\n',encoding='utf-8')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src','tests']))
identity=json.loads((previous/'vm-identity.json').read_text(encoding='utf-8'))
identity['sourceRevision']=local['sourceRevision'];identity['productionSources']=local['productionSources']
identity['sourcePairBaseline']='a34f56b5/R71 transport correction/corebc30d424: focused1366internal/244public per actual11/10 and B427 goldens/ownership/cleanup; corrected full delivery batches with R72, not implied by old-source green.'
identity['originalVariant']='R72 whole intrinsic sequence construction routing deletion; no new constructor or return-shape specialization.'
identity['coreSHA256']={role:(baseline['coreSHA256']if role.startswith('reference')else local['coreSHA256']['candidate'])for role in ['reference','reference-control','candidate','candidate-control']}
(r/'vm-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
for name in ['collect.py','archive-owned.py','run.sh','launch.py','retrieve.py','assess-vm.py']:
 s=(previous/name).read_text(encoding='utf-8').replace('binding-transport-b427-20261108','sequence-construction-b428-20261108')
 s=s.replace('lython-b427-binding-transport-20261108','lython-b428-sequence-construction-20261108').replace('lython-b427-fixtures','lython-b428-fixtures')
 if name=='launch.py':
  s=s.replace("reference=base/'tuple-unpack-b423-20261107/candidate'", "reference=base/'binding-transport-b427-20261108/candidate'")
  s=s.replace('binding-transport-b427-launch.py','sequence-construction-b428-launch.py')
  old="  assert shutil.disk_usage(base).free>sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+256*1024*1024"
  new='''  required=sum(((m.size+4095)//4096)*4096 for m in a.getmembers())+256*1024*1024
  reclaim=None
  if shutil.disk_usage(base).free<=required:
   prior=base/'csv-call-debt-b426-20261108'
   receipt=json.loads((prior/'archive-receipt.json').read_text())
   assert receipt['complete'] and receipt['archiveSHA256']=='6071077a00d06bc869703d2ad81dc7805d1f10a27143868a5f988805ecce190e'
   assert hashlib.sha256((prior/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
   target=prior/'profiles';assert target.is_dir() and not target.is_symlink() and target.resolve().parent==prior.resolve() and prior.resolve().parent==base.resolve()
   before=shutil.disk_usage(base).free
   shutil.rmtree(target)
   reclaim=dict(path=str(target),reason='Verified redundant B426 extract; immutable archive and independently verified local evidence retained.',archiveSHA256=receipt['archiveSHA256'],beforeFreeBytes=before,afterFreeBytes=shutil.disk_usage(base).free)
  assert shutil.disk_usage(base).free>required'''
  assert old in s;s=s.replace(old,new).replace("  root.mkdir();a.extractall(root,filter='data')", "  root.mkdir();a.extractall(root,filter='data')\n  if reclaim:(root/'reclaimed-redundant-extract.json').write_text(json.dumps(reclaim,indent=2)+'\\n')")
 if name=='archive-owned.py':
  s=s.replace("with tarfile.open(root/'observations.tgz','w:gz') as t:","with tarfile.open(root/'observations.tgz','w:gz') as t:\n if (root/'reclaimed-redundant-extract.json').exists():t.add(root/'reclaimed-redundant-extract.json',arcname='reclaimed-redundant-extract.json')")
 if name.endswith('.py'):ast.parse(s)
 (r/name).write_text(s,encoding='utf-8',newline='\n')
for name in ['measure.py','assess-local.py']:
 s=(previous/name).read_text(encoding='utf-8').replace("old=r.parent.parent/'integer-utf8-r45'", "old=r.parent/'integer-utf8-r45'")
 ast.parse(s);(r/name).write_text(s,encoding='utf-8')
shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
(r/'contract.md').write_text('''R72/B428: entire intrinsic list/tuple construction stays in the shared prefix using existing admitted builders, deleting old dispatcher cases/needless lexical context promotion. Starred/set/dict/match/real protocol consumers remain. Tuple backing gains existing list-style post-admission cancellation check. No new constructor, shape, cache, policy or unsafe mechanism.1729internal/597public per actual11/10, matching probes; twenty baseline deferred-context cases before runtime edits cover identity/pending-I/O/cancellation/refusal/first origin/stopped effects/retained aliases/budget reuse. Existing five-script allocation diagnostic separate. Same-shaped four-job pair: returned-record warm/warm-async, ordinary CSV/text warm; two baseline/two candidate processes,5s warmup per role/job,7rotated150ms, normalGC/tiering/quietF4as_v7. Baselinea34f56b5/corebc30d424 R71 correction is focused/semantically qualified, full corrected source batches with this milestone; do not imply the f88191f7 CI or R70green qualifies it. Same worker7cf37ca5/normal optional0.4adapter; invocation/RAMIO/fullgoldens/priorcleanup included, compile/startup/reset/staging/protocol/final teardown excluded. Source/actualReady/auxiliary/runtime/golden/quiet/Closed/exit/join/emptyfixture/archive gates. Persistent evidence separate owned128MiB RAM,256MiB staging floor. If needed reclaim only exact verified redundant B426profiles after validating immutable archiveSHA and local verification; record action, keep archives.150sowner+30stop+30margin, observe210s, no timeout restart. Preserve all adverse/variable/original conditions; explicit retained/restored/debt disposition, no predicted percentage/generalCPU/CPython claim. Batch full Windows/Ubuntu actual11/10, originalStress/installedcore at delivery; publication postponed.
''',encoding='utf-8')
with tarfile.open(r/'payload.tgz','w:gz')as archive:
 for name in ['collect.py','archive-owned.py','run.sh','current-core.dll','representative.json','pre-measurement-plan.md','setup-contract.json','contract.md']:archive.add(r/name,arcname=name)
 for source,target in [('binding-focused.json','focused.json'),('vm-identity.json','identity.json'),('source.patch','source.patch')]:archive.add(r/source,arcname=target)
print('R72 source frozen and focused checks verified:',local['coreSHA256']['candidate'])
