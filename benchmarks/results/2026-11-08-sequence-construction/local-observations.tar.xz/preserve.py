from pathlib import Path
import hashlib,json,re,shutil,tarfile

r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-08-sequence-construction');out.mkdir(exist_ok=True)
assert not(out/'README.md').exists()
receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['jobs']==4
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
identity=json.loads((r/'identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['productionSources'].items())
for name in ['observations.tgz','archive-receipt.json','terminal-status.json','identity.json','vm-identity.json','assessment.json','local-assessment.json','binding-focused.json','pre-code-plan.md','contract.md']:
 shutil.copyfile(r/name,out/name)
shutil.copyfile(r/'retrieved/reclaimed-redundant-extract.json',out/'reclaimed-redundant-extract.json')
with tarfile.open(out/'local-observations.tar.xz','w:xz')as archive:
 for p in r.iterdir():
  if p.is_file()and p.suffix in ['.py','.json','.log','.md','.patch']:archive.add(p,arcname=p.name)
 for folder in ['warm-sync','warm-async']:archive.add(r/folder,arcname=folder)
 archive.add(r/'images/before/Lokad.Lython.dll',arcname='baseline-core.dll')
 archive.add(r/'baseline-net10-core.dll',arcname='baseline-net10-core.dll')
 archive.add(r/'current-core.dll',arcname='current-core.dll')
 archive.add('src/Lokad.Lython/bin/Release/net10.0/Lokad.Lython.dll',arcname='current-net10-core.dll')
raw=json.loads((r/'assessment.json').read_text(encoding='utf-8'))
table='| Complete job | Elapsed change, all process pairs | Baseline / current spread |\n| --- | ---: | ---: |\n'
for job in raw['jobs']:
 values=[v for pair in job['elapsedPercent'].values()for v in pair]
 table+=f"| {job['case'].removeprefix('scripts.')} / {job['lane']} | {min(values):+.2f} to {max(values):+.2f}% | {abs(job['baselineSpreadPercent']):.2f}% / {abs(job['candidateSpreadPercent']):.2f}% |\n"
(out/'README.md').write_text('''# Intrinsic sequence construction — R72/B428

2026-11-08. Retained change on a34f56b5; measured cores a0aef9ef (.NET 11) /
a31eaa94 (.NET 10), exact source inventories/patch/binaries preserved. Full combined
R71 correction + R72 delivery remains pending; publication postponed.

## Removed phase and focused acceptance

The shared instruction prefix now executes the whole plain MakeList/MakeTuple
family using its existing admitted builders. Their two ExecuteStructure cases
and unconditional lexical-context promotion disappear. No new constructor, return
shape, cache, execution engine or ownership policy. Starred displays, set/dict key
protocols, match and real lexical-context consumers retain existing behavior.
Tuple backing allocation gains the post-admission cancellation check already used
by list construction. Overall production change deletes two net lines.

Evaluated inputs retain order, exact identities/aliases, capacity and scalar
headroom, replacement overlap, rollback and retirement/publication semantics.
No API or intended Python behavior change; fewer scratch/context admissions can
avoid prior conservative rejection, not promise identical tiny-budget thresholds.

**1,729 internal / 597 public checks per actual .NET 11/10 pass**, matching probes.
Before runtime edits, all twenty deferred-context tests pass on corrected R71:
ordinary/keyword calls, sequence identities, errors/exception context, real pending
I/O/cancellation, withdrawn aliases, escaping results and budget reuse. Four new
refusal cases admit the work area first, then reject substantial literal storage;
they preserve line-five failure origin, stop publication/guest catch/finally return
and reuse the same budget successfully afterward. Existing function/generator/
recursion/stack/collection/native protocol/projection/refusal/cancellation/lifetime
checks remain. No architecture-only assertion or relaxed timeout/containment check.

## Allocation and diagnostic desktop clocks

Existing five-script driver, both APIs, normal GC/tiering; independent old/current/
old-control assemblies sharing CoreLib/GC/hashing. Goldens, budget balances, image
isolation and fixture cleanup pass. Returned-record CSV allocation falls a further
**23.48% sync / 21.69% async** against corrected R71. Ordinary CSV/text/JSON/report
allocations essentially unchanged. These percentages are separate source pairs,
not additive to earlier R70/R71 improvements.

Desktop elapsed is diagnostic: affected sync −7.12–8.94%, async −1.66–2.78%;
adverse ordinary CSV async +3.26–4.89% and report sync +1.31–2.38% remain. Text
old-role drift −15.81% sync/+7.81% async and contradictory other observations are
preserved, not promoted as CPU evidence.

## Controlled complete-script source pair

Quiet F4as_v7/Ubuntu24.04.4/.NET11RC3, unchanged 7cf37ca5 worker and normal optional
0.4 adapter. Baseline bc30d424 matches corrected R71/a34f56b5: focused checks and
B427 semantic/ownership/golden gates passed; its full corrected delivery batches
with this source. Earlier f88191f7/R70 green checks do not qualify this source.
Two baseline/two current processes, five-second warmup per role/job, seven rotated
150 ms rounds, normal GC/tiering. Four jobs complete in **114.025 seconds**.
Negative elapsed means faster.

'''+table+'''
Affected elapsed improves across both candidate processes. Ordinary CSV stays near
baseline; text varies with a 2.38% candidate spread. Coarse process CPU is favorable
for the affected script, mixed for ordinary CSV and adverse up to **+6.67% for text**.
Its 10 ms quantization and outside-job work limit precision; retain the adverse
result without a causal explanation or general CPU-gain claim. Keep the complete
phase deletion, allocation reduction and controlled affected elapsed benefit.
Remaining ordinary text/regression debt is considered at the combined checkpoint;
this does not complete the whole-script performance objective.

Warm includes public invocation, mediated RAM I/O, full stdout/file validation and
prior-result cleanup. Compilation/startup/staging/reset/protocol/final cached teardown
excluded. Async timing uses completed I/O; actual suspension is correctness-tested.
Desktop includes reset/result disposal and absolute clocks cannot be compared.
No CPython ratio, RSS/startup/pending-I/O/embedding-tail claim.

All source/actualReady/auxiliary/runtime/golden/quiet/Closed/exit/join/empty-fixture
gates pass. Persistent records remain separate from owned 128 MiB RAM fixtures;
all users join/mounts disappear before archive verification under lease and locally.
Staging 271,699,968 B passes the 256 MiB floor after reclaiming only the redundant
B426 profiles extract: its immutable archive SHA6071077a was verified first and
both archive and independently verified local evidence remain. Exact path/free-byte
receipt retained. 150 s owner + 30 s stop + 30 s margin; no measured timeout/restart.
B428 is terminal/archived/verified, never query again. Publication postponed.

[Controlled assessment](assessment.json), [allocation/adverse desktop](local-assessment.json),
[focused checks](binding-focused.json), [identities](identity.json), [VM identities](vm-identity.json),
[pre-code gate](pre-code-plan.md), [contract](contract.md),
[reclaimed redundant extract](reclaimed-redundant-extract.json),
[VM archive](observations.tgz), [local raw/source/cores/tests](local-observations.tar.xz).
''',encoding='utf-8')
receipt['localArchiveSHA256']=hashlib.sha256((out/'local-observations.tar.xz').read_bytes()).hexdigest()
(out/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
p=Path('docs/BENCHMARKS.md');s=p.read_text(encoding='utf-8');anchor='| Shared buffered-line execution'
s=s.replace(anchor,'| Intrinsic sequence construction / returned-record CSV | Further allocation −23.48% sync/−21.69% async; controlled elapsed −1.92–4.79% sync/−2.76–6.49% async | Ordinary CSV near baseline, text mixed/coarse CPU adverse; combined delivery pending. [R72](../benchmarks/results/2026-11-08-sequence-construction/README.md) |\n'+anchor);p.write_text(s,encoding='utf-8')
p=Path('benchmarks/EXPERIMENTS.md');p.write_text(p.read_text(encoding='utf-8')+'''
## Intrinsic sequence construction without lexical promotion

[R72/B428](results/2026-11-08-sequence-construction/README.md) moves plain list/
tuple construction into the shared prefix using existing admitted builders,
deleting the old cases/context promotion; tuple backing gains post-admission
cancellation. Two net production lines deleted; no new shape/builder/cache/policy.
Twenty public cases first pass on corrected R71;1,729internal/597public per actual
11/10 then pass with matching probes. Real suspension/cancellation/retained aliases,
first refusal origin/stopped publication/finally return and budget reuse remain.
Allocation −23.48% sync/−21.69% async; complete four-job pair114.025s, all gates:
affected elapsed−1.92–4.79% sync/−2.76–6.49% async; CSV−0.27to+0.86%, text mixed.
Adverse desktop CSV/report and coarse process CPU text+6.67% preserved, no general
CPU gain or objective-completion claim. Retain complete-phase deletion and bounded
affected benefit. Combined correction+construction full delivery pending. Verified
B426 redundant profiles reclaimed with immutable/local archives retained; receipt
records exact path/free bytes. B428 terminal/archived/verified; publication postponed.
''',encoding='utf-8')
for p in [out/'README.md',Path('docs/BENCHMARKS.md')]:
 for target in re.findall(r'\]\(([^)]+)\)',p.read_text(encoding='utf-8')):
  if '://'not in target and not target.startswith('#'):assert(p.parent/target.split('#',1)[0]).exists(),(p,target)
print('R72 retained: complete construction phase removed, source/archive/link gates verified; adverse controls preserved.')
