events = []
tag = "global"
def decorator():
    events.append("decorator")
    def apply(function):
        events.append(("applied", list(function.__annotations__)))
        return function
    return apply

def factory(tag):
    value = []
    def enclosing():
        nonlocal tag
        def annotation(name, item):
            events.append((name, tag))
            return item
        @decorator()
        def inner(ɑ: annotation("posonly", value), /,
                  some: annotation("positional", value) = annotation("default", value),
                  *, b: (snapshot := annotation("keyword", tag)) = "") -> annotation("return", snapshot):
            return ɑ
        return inner
    return enclosing()

first = factory("first")
second = factory("second")
a, b = first.__annotations__, second.__annotations__
print(events)
print(a is b, list(a), a['ɑ'] is a['some'], a['b'] is a['return'])
a.pop('ɑ')
print(b['ɑ'] is b['some'], b['return'])
class Scope:
    local = "class"
    def method(self) -> local:
        def inside(arg: tag) -> tag:
            return arg
        return inside
print(Scope.method.__annotations__, Scope().method().__annotations__)
def generic[T](arg: T = int):
    def wrapped(value: T = arg) -> T:
        return value
    return wrapped
wrapped = generic()
print(wrapped() is int,
      wrapped.__annotations__['value'] is wrapped.__annotations__['return'])
