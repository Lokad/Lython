from pathlib import Path
import ast, hashlib, json, shutil, tarfile

lab=Path(__file__).resolve().parent
donor=lab.parent/"function-annotation-inputs-r581"
previous=donor/"quiet"
quiet=lab/"quiet"
quiet.mkdir(exist_ok=False)
load=lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
sha=lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,source):
    if path.suffix==".py": ast.parse(source)
    path.write_text(source,encoding="utf-8",newline="\n")
def save(path,data): write(path,json.dumps(data,ensure_ascii=False,indent=2)+"\n")

prior=load(previous/"config.json")
screen=load(lab/"frozen-identity.json")
space=load(lab/"quiet-space.json")
catalog=lab/"catalog.json"
images=screen["images"]
source_files=prior["identity"]["imageFiles"]["candidate"]
core="Lokad.Lython.dll"
assert screen["casesSHA256"]==sha(catalog)
for role,files in images.items():
    assert len(files)==32 and files==source_files|{core:files[core]}
    assert {name:sha(lab/"frozen"/role/name) for name in files}==files
    verified=load(lab/f"{role}-verify.json")
    assert verified["state"]=="Completed" and verified["catalogSha256"]==sha(catalog)
    (quiet/role).mkdir()
    if role=="candidate": shutil.copyfile(lab/"frozen"/role/core,quiet/role/core)

target="scripts.annotated-rule-closures"
jobs=[(target,"warm"),("scripts.rule-default-closures","warm"),("calls.positional.large","warm"),(target,"compile-run"),(target,"compile")]
count=len(jobs)
identity=dict(sourceRevision="0547e5489 versus function annotation storage candidate",
              purpose="R583 direct function annotation evaluation and storage",
              imageFiles=images,catalogSHA256=sha(catalog),normalAdapterPin="0.4.0",
              coreSHA256={label:images[role][core] for role in images for label in (role,role+"-control")})
root="/home/lokad/lython-bench-checks/function-annotation-storage-b1009-20261118"
unit="lython-b1009-function-annotation-storage-20261118"
read=lambda path:path.read_text(encoding="utf-8")
def rename(source):
    return source.replace("Direct function defaults source pair","Executable definition inputs source pair").replace("Fixed-list unpack source pair","Executable definition inputs source pair").replace("Borrowed format source pair","Executable definition inputs source pair")

runner=rename(read(previous/"collect.py"))
a=runner.index("\njobs = ")
b=runner.index("\nassert len(jobs)",a)
runner=runner[:a]+"\njobs = "+repr(jobs)+runner[b:]
write(quiet/"collect.py",runner.replace("assert len(jobs)==5",f"assert len(jobs)=={count}"))
archive=read(previous/"archive-owned.py").replace("len(raw['jobs'])==5",f"len(raw['jobs'])=={count}").replace("jobs=5,",f"jobs={count},")
write(quiet/"archive-owned.py",archive)
write(quiet/"run.sh",read(previous/"run.sh").replace(prior["root"],root))
assert b"\r" not in (quiet/"run.sh").read_bytes()
save(quiet/"identity.json",identity)
shutil.copyfile(catalog,quiet/"representative.json")
names=["collect.py","archive-owned.py","run.sh","identity.json","representative.json","candidate/"+core]
payload=quiet/"payload.tgz"
with tarfile.open(payload,"w:gz") as out:
    for name in names: out.add(quiet/name,arcname=name)
expanded=sum((quiet/name).stat().st_size for name in names)
need=254*1024*1024+expanded+512*1024
available=space["freeBytes"]
selected=[]
for proof in sorted(space["replicas"],key=lambda p:-p["bytes"]):
    if available>=need: break
    available+=proof["bytes"]
    selected.append(proof)
save(quiet/"preflight.json",dict(available=available,need=need,withoutRetirement=space["freeBytes"],selected=selected))
assert available>=need,(available,need)
config=dict(root=root,unit=unit,source=prior["root"],sourceRole="candidate",sourceFiles=source_files,
            sourceCatalogSHA256=prior["catalogSHA256"],catalogSHA256=sha(catalog),identity=identity,
            retireGroups=selected,payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),unpackedBytes=expanded)
save(quiet/"config.json",config)
launcher=read(previous/"remote-launch.py")
a=launcher.index("\nc=")+1
b=launcher.index("\nb=Path(")
launcher=launcher[:a]+"c="+repr(config)+launcher[b:]
launcher=launcher.replace("os.link(source/role/n,p)", "os.link(source/c['sourceRole']/n,p)")
launcher=launcher.replace(" for role,files in c['identity']['imageFiles'].items():\n  for n,h in files.items():assert sha(source/role/n)==h,n",
                          " for n,h in c['sourceFiles'].items():assert sha(source/c['sourceRole']/n)==h,n")
write(quiet/"remote-launch.py",launcher.replace("lython-b1007-fixtures","lython-b1009-fixtures").replace("+65536", "+524288"))
retrieve=rename(read(previous/"retrieve.py")).replace("['jobs']==5",f"['jobs']=={count}")
write(quiet/"retrieve.py",retrieve)
launch=rename(read(donor/"launch-quiet.py")).replace("seconds=280","seconds=280").replace("before 280 seconds","before 280 seconds")
write(lab/"launch-quiet.py",launch)
summary=read(donor/"summarize-quiet.py").replace("len(raw['jobs'])==5","len(raw['jobs'])==5")
write(lab/"summarize-quiet.py",summary)
print("Verified both complete images and",count,"jobs, with",available-need,"bytes above the staging requirement")
