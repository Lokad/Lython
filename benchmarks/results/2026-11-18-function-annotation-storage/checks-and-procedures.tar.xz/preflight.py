from pathlib import Path
import gzip
import hashlib
import json
import subprocess

lab = Path(__file__).resolve().parent
previous = lab.parent / 'executable-definition-inputs-r578'
read = lambda p: p.read_text(encoding='utf-8')
load = lambda p: json.loads(read(p))
sha = lambda data: hashlib.sha256(data).hexdigest()
prior = load(previous / 'quiet-space.json')
proof = next(p for p in prior['replicas'] if p['sha256'].startswith('2ede09fc'))
canonical = proof['canonical']
archived = subprocess.check_output(['git', 'show', f'origin/master:{canonical}'])
assert archived == Path(canonical).read_bytes() and sha(archived) == proof['canonicalSHA256']
raw = gzip.decompress(archived)
assert sha(raw) == proof['sha256'] and len(raw) == proof['bytes']
remote = r'''
from pathlib import Path
import fcntl, hashlib, json, os, shutil, stat, subprocess
root = Path('/home/lokad/lython-bench-checks').resolve()
assert root == Path('/home/lokad/lython-bench-checks')
proof = PROOF
with (root / 'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert not subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.13.*cpython-worker.py'], capture_output=True).stdout
    assert not any(os.path.ismount(p) for p in root.glob('*/guest-fixtures'))
    identities = set()
    for name in proof['paths']:
        path = root / name
        info = path.lstat()
        assert path.resolve() == path and path.is_relative_to(root) and stat.S_ISREG(info.st_mode)
        assert info.st_uid == os.getuid() and info.st_nlink == proof['links'] and info.st_size == proof['bytes']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == proof['sha256']
        identities.add((info.st_dev, info.st_ino))
    assert len(identities) == 1 and len(proof['paths']) == proof['links']
    print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free, replicas=[proof])))
'''.replace('PROOF', repr(proof))
ssh = ['C:/Windows/System32/OpenSSH/ssh.exe', '-i', str(Path.home() / '.ssh/id_lython-bench.pem'),
       '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15', 'lokad@20.166.121.73']
space = subprocess.check_output(ssh + ['python3 -'], input=remote.encode(), timeout=30)
assert load(lab.parent / 'retained-closure-profile-r582/terminal-status.json')['receipt']['complete']
assert json.loads(space)['replicas'] == [proof]
(lab / 'quiet-space.json').write_bytes(space)

