from pathlib import Path


lab = Path(__file__).resolve().parent
work = Path(".git/agent-worktrees/pinned-unicode-casing-20261121")
runtime = work / "src/Lokad.Lython/Runtime"


def edit(filename, before, after):
    path = runtime / filename
    source = path.read_text(encoding="utf-8")
    assert source.count(before) == 1, filename
    path.write_text(source.replace(before, after), encoding="utf-8", newline="\n")


edit("LythonRuntime.Calls.Binding.cs",
     "        var firstExtraPositional = 0;\n        var extraPositionalCount = 0;",
     "        using var stage = LocalCallPhaseMeter.Begin(0);\n"
     "        var firstExtraPositional = 0;\n        var extraPositionalCount = 0;")
edit("LythonRuntime.FunctionDefaults.cs",
     "        context.CheckExecution(span);\n        var positional = layout.PositionalDefaultCount",
     "        using var stage = LocalCallPhaseMeter.Begin(1);\n"
     "        context.CheckExecution(span);\n        var positional = layout.PositionalDefaultCount")
edit("LythonRuntime.Executable.PreparedDefinitions.cs",
     "        // The callable and its final annotation backing are still private.",
     "        using var stage = LocalCallPhaseMeter.Begin(2);\n"
     "        // The callable and its final annotation backing are still private.")
edit("LythonRuntime.Executable.NativeDefinitions.cs",
     "                IReadOnlyList<ExecutableCell> cells = captures is null ? [] :",
     "                IReadOnlyList<ExecutableCell> cells;\n"
     "                using (LocalCallPhaseMeter.Begin(3))\n"
     "                    cells = captures is null ? [] :")
edit("PyExecutableFunction.cs",
     "        if (borrow)\n        {\n            arguments.CopyTo(values!);",
     "        if (borrow)\n        {\n            LocalCallPhaseMeter.Calls[4]++;\n            arguments.CopyTo(values!);")
edit("PyExecutableFunction.cs",
     "        else LythonRuntime.BindFunctionArgumentsInto(values[..ParameterCount],",
     "        else\n        {\n            LocalCallPhaseMeter.Calls[5]++;\n"
     "            LythonRuntime.BindFunctionArgumentsInto(values[..ParameterCount],")
edit("PyExecutableFunction.cs",
     "            [], span, this, context, receiver: receiver, callSite: call, operands: arguments);\n        StartInline",
     "                [], span, this, context, receiver: receiver, callSite: call, operands: arguments);\n"
     "        }\n        StartInline")
(runtime / "LocalCallPhaseMeter.cs").write_bytes((lab / "LocalCallPhaseMeter.cs.txt").read_bytes())
