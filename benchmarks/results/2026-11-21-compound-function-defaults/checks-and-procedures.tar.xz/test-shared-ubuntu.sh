set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/pinned-unicode-casing-20261121
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/factory-call-stages
filter='Category!=Stress&(FullyQualifiedName~Function|FullyQualifiedName~Tuple|FullyQualifiedName~Dataclass|FullyQualifiedName~Copy|FullyQualifiedName~Memory|FullyQualifiedName~Cancellation)'
dotnet build tools/LythonProbe/LythonProbe.csproj -c Release -f net10.0 | tee "$logs/shared-probe-ubuntu.log"
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter "$filter" | tee "$logs/shared-white-ubuntu.log"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter "$filter" | tee "$logs/shared-public-ubuntu.log"
