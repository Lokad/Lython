from pathlib import Path
import hashlib
import json
import statistics


lab = Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


reports = {role: [read(lab / f"{role}-{index}.json") for index in range(2)]
           for role in ("control", "metered")}
for role, pair in reports.items():
    digest = hashlib.sha256((lab / role / "Lokad.Lython.dll").read_bytes()).hexdigest()
    assert all(item["coreSHA256"] == digest and item["instrumented"] == (role == "metered") for item in pair)
    assert all(len(item["rows"]) == 4 for item in pair)
rows = []
for index in range(4):
    control, metered = ([report["rows"][index] for report in reports[role]] for role in ("control", "metered"))
    assert len({row["id"] for row in control + metered}) == 1
    control_elapsed = [statistics.median(batch["invocationMicroseconds"] for batch in row["batches"]) for row in control]
    measurements = []
    for run in metered:
        batches = run["batches"]
        counts = batches[0]["averageCounts"]
        assert len(batches) == 7 and all(batch["averageCounts"] == counts for batch in batches)
        elapsed = statistics.median(batch["invocationMicroseconds"] for batch in batches)
        phases = [statistics.median(batch["estimatedPhaseMicroseconds"][stage] for batch in batches)
                  for stage in range(4)]
        measurements.append(dict(invocationMicroseconds=elapsed, averageCounts=counts,
                                 phaseMicroseconds=phases, phasePercent=[100 * value / elapsed for value in phases]))
    rows.append(dict(id=metered[0]["id"], controlMicroseconds=control_elapsed, instrumented=measurements))
summary = dict(
    revision="7e5cdd6e8",
    boundary=reports["metered"][0]["boundary"],
    phases=reports["metered"][0]["phases"],
    controlCore=reports["control"][0]["coreSHA256"],
    instrumentedCore=reports["metered"][0]["coreSHA256"],
    catalogSHA256=hashlib.sha256((lab / "catalog.json").read_bytes()).hexdigest(),
    controls="Two processes per image executed in reference, diagnostic, diagnostic, reference order. All four sources match isolated CPython stdout. Evaluation and code owners refund after every invocation and compile disposal.",
    decision="Use the call counts and broad attribution to prioritize construction and ownership. Instrumentation perturbs elapsed and phase medians do not establish unaided time or expected gains. Skip a binder-only split.",
    rows=rows)
(lab / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8", newline="\n")
