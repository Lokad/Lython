from pathlib import Path
import hashlib
import json
import subprocess


lab = Path(__file__).resolve().parent
prior = lab.parent


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


catalog = load(prior / "default-storage-delivery-cpython/representative.json")
cases = catalog["cases"]
postponed = next(case for case in cases if "nested-factories.postponed" in case["id"])


def pure_case(name, source):
    result = subprocess.run(["C:/Python313/python.exe", "-I", "-X", "utf8", "-c", source],
                            check=True, capture_output=True, encoding="utf-8")
    assert not result.stderr
    case = dict(postponed)
    case.update(id=name, source=source, expectedOutput=result.stdout)
    for label, value in (("source", source), ("expectedOutput", result.stdout)):
        data = value.encode("utf-8")
        case[label + "Utf8Bytes"] = len(data)
        case[label + "Sha256"] = hashlib.sha256(data).hexdigest()
    return case


needle = "    latest = compile_rule(index)\n"
assert postponed["source"].count(needle) == 1
observer = postponed["source"].replace(
    needle, needle + "    total += latest.__kwdefaults__['weight'] + len(latest.__defaults__)\n")
cases.append(pure_case("scripts.factory-observed-defaults", observer))
fully_supplied = load(lab / "catalog.json")["cases"][-1]
assert fully_supplied["id"] == "scripts.ordinary-fully-supplied-helper"
cases.append(pure_case(fully_supplied["id"], fully_supplied["source"]))
dataclasses = load(prior / "default-container-admission/catalog.json")["cases"]
cases.append(next(case for case in dataclasses if case["id"] == "scripts.dataclass-keyword-configuration.generated"))
assert len(cases) == len({case["id"] for case in cases}) == 7
(lab / "representative.json").write_text(json.dumps(catalog, indent=2) + "\n",
                                         encoding="utf-8", newline="\n")
