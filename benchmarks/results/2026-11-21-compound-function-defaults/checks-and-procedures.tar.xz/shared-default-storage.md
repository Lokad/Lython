# Prepared positional and keyword defaults

The construction diagnostic counts 2,048 pairs of default containers per
factory execution. Each pair owns an eager tuple, its executable-slot array
and a prepared keyword-values array. In the postponed case, callable creation
and default allocation together account for about 28% of instrumented warm
time. Generic binding accounts for about 4.5%. The breakdown includes timer
cost and has instrumented control shifts. It supports selecting construction
for a design study.

The smallest layout worth evaluating keeps the existing tuple and its
executable-slot backing. The private prepared keyword values occupy a tail
of that backing. A logical tuple length excludes the tail from guest
operations. The normal argument binder reads the two sections through the
current positional and keyword completion paths. An observed or explicitly
assigned dictionary continues to use the existing dictionary protocol.
Obtain the cost of a logical length across ordinary tuple paths before
choosing this direction.

This layout can remove the separate keyword-values array from definitions
whose keyword metadata stays unobserved. Reading `__kwdefaults__` creates the
final dictionary and its own values array from the pre-admitted tail. Both
arrays are retained during construction and must be funded at once. After
successful materialization the keyword tail can be cleared. A fallen-through
or replaced keyword view may still have a live sibling positional tuple, so
its shared backing capacity cannot be refunded. Preserve the current
preflight before the first default expression, terminal refusal, cancellation
while copying, identity of already selected values and the current rollback
on definition failure. A suspended call can hold a tuple-backed scalar
reference even if a callback replaces the function's defaults.

Inspect tuple iteration, negative indexing, hashing, unpack, copying,
projection and adopted-array construction. The direct array paths must stop
at the logical positional length. Keep adopted arrays authoritative for
`deepcopy`. Public tuple operations and surviving alias accounting must
remain straightforward. The prototype can stay private if adding the
logical length imposes a material cost on common tuples, keyword observation
requires a new ownership protocol, or another full definition copy remains.

Compare the three factory shapes, a fully supplied helper, a default metadata
observer, default-heavy dataclasses and the tuple-producing CSV invoice.
Record whole warm and compile-to-result timings, local CLR allocation,
accounted peaks, stable duplicate controls and refunded balances. Prior
adverse combined-admission, lazy-tuple and inline-tuple comparisons remain
the references for failure modes.
