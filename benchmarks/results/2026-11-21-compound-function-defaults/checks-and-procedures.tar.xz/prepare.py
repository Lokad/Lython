from pathlib import Path
import hashlib
import json
import subprocess
import sys


lab = Path(__file__).resolve().parent
prior = lab.parent / "post-capture-factory-attribution-confirmation/catalog.json"
cases = json.loads(prior.read_text(encoding="utf-8-sig"))["cases"]
source = """def evaluate(record, base, weight):
    return (record + base) * weight

total = 0
for index in range(2048):
    total += evaluate(index, index % 11, index % 7 + 1)
print(total)
"""
cases.append(dict(id="scripts.ordinary-fully-supplied-helper", source=source,
                  expectedOutput="8421311\n"))
for case in cases:
    result = subprocess.run([sys.executable, "-I", "-X", "utf8", "-c", case["source"]],
                            check=True, capture_output=True, text=True, encoding="utf-8")
    assert result.stdout == case["expectedOutput"] and not result.stderr, (case["id"], result.stdout)
    case["sourceSha256"] = hashlib.sha256(case["source"].encode("utf-8")).hexdigest()
(lab / "catalog.json").write_text(json.dumps(dict(cases=cases), indent=2) + "\n",
                                  encoding="utf-8", newline="\n")
