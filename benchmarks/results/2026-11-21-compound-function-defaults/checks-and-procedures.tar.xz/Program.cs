using System.Diagnostics;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Lokad.Lython;

const int Warmup = 128, Rounds = 7, Iterations = 64;
using var catalog = JsonDocument.Parse(File.ReadAllBytes(args[0]));
var core = typeof(LythonEngine).Assembly;
var meter = core.GetType("Lokad.Lython.Runtime.LocalCallPhaseMeter");
var counts = ReadCounter("Calls");
var samples = ReadCounter("Samples");
var ticks = ReadCounter("Ticks");
var rows = new List<object>();
var host = new ProbeHost();
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var id = item.GetProperty("id").GetString()!;
    var source = item.GetProperty("source").GetString()!;
    var expected = item.GetProperty("expectedOutput").GetString()!;
    var engine = new LythonEngine();
    var budget = new LythonMemoryBudget();
    var options = new LythonRunOptions { MemoryBudget = budget };
    using (var code = engine.Compile(source, budget))
    {
        if (!code.IsValid || code.Diagnostics.Count != 0) throw new InvalidOperationException(id);
        var compiledBalance = budget.ReservedBytes;
        for (var i = 0; i < Warmup; i++) Invoke();
        var batches = new List<object>();
        for (var i = 0; i < Rounds; i++)
        {
            Array.Clear(counts);
            Array.Clear(samples);
            Array.Clear(ticks);
            var begin = Stopwatch.GetTimestamp();
            for (var j = 0; j < Iterations; j++) Invoke();
            var elapsed = Stopwatch.GetElapsedTime(begin);
            var phases = Enumerable.Range(0, ticks.Length).Select(phase =>
                samples[phase] == 0 ? 0 : ticks[phase] * (1_000_000.0 / Stopwatch.Frequency)
                    * counts[phase] / samples[phase] / Iterations).ToArray();
            batches.Add(new
            {
                invocationMicroseconds = elapsed.TotalMicroseconds / Iterations,
                averageCounts = counts.Select(value => value / (double)Iterations).ToArray(),
                samples = samples.ToArray(),
                estimatedPhaseMicroseconds = phases
            });
        }
        rows.Add(new { id, batches });

        void Invoke()
        {
            using (var result = code.Run(host, options))
            {
                if (result.Outcome != LythonExecutionOutcome.Succeeded || result.StandardOutput != expected)
                    throw new InvalidOperationException(id + " output mismatch: " + result.StandardOutput);
            }
            if (budget.ReservedBytes != compiledBalance) throw new InvalidOperationException(id + " execution refund failed");
        }
    }
    if (budget.ReservedBytes != 0) throw new InvalidOperationException(id + " compile refund failed");
}
var resultJson = JsonSerializer.Serialize(new
{
    productionRevision = "7e5cdd6e8",
    instrumented = meter is not null,
    coreSHA256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(core.Location))).ToLowerInvariant(),
    boundary = "Local synchronous warm invocation wall time with output verification and disposal, excluding compilation. Sampled phases instrument the worker and include clock overhead.",
    phases = new[] { "bind function arguments", "allocate default containers", "create funded callable", "capture on native creation", "native fully supplied calls", "native calls through binder" },
    rows
}, new JsonSerializerOptions { WriteIndented = true });
File.WriteAllText(args[1], resultJson + "\n", new UTF8Encoding(false));

long[] ReadCounter(string name)
    => (long[]?)meter?.GetField(name, BindingFlags.Static | BindingFlags.NonPublic)?.GetValue(null) ?? [];

sealed class ProbeHost : ILythonHost
{
    public string Cwd => "/";
    public DateTimeOffset LocalNow => DateTimeOffset.UnixEpoch;
    public DateTimeOffset UtcNow => DateTimeOffset.UnixEpoch;

    public ValueTask<bool> ExistsAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask<IReadOnlyList<string>> ListDirAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask MkDirAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask RemoveAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask CopyAsync(LythonPathRequest source, LythonPathRequest destination, CancellationToken token) => throw new NotSupportedException();
    public ValueTask MoveAsync(LythonPathRequest source, LythonPathRequest destination, CancellationToken token) => throw new NotSupportedException();
    public ValueTask<LythonPathStat> StatAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
}
