from pathlib import Path
import json


lab = Path(__file__).resolve().parent
summary = json.loads((lab / "quiet/quiet-summary.json").read_text(encoding="utf-8"))
allocations = {row["case"]: row["allocationChangePercent"]
               for row in json.loads((lab / "allocation-summary.json").read_text(encoding="utf-8"))}
names = {
    "scripts.annotated-rule-closures": "Eager rules",
    "scripts.annotated-rule-closures.nested-factories": "Eager nested factories",
    "scripts.annotated-rule-closures.nested-factories.postponed": "Postponed nested factories",
    "scripts.csv-invoice.large": "CSV invoice",
    "scripts.factory-observed-defaults": "Factory with default metadata reads",
    "scripts.ordinary-fully-supplied-helper": "Fully supplied helper",
    "scripts.dataclass-keyword-configuration.generated": "Keyword dataclasses",
}


def percent(value):
    return f"{value:+.2f}%".replace("-", "−")


def extent(values):
    return percent(min(values)) + " to " + percent(max(values))


rows = [
    "| Complete script | Boundary | Elapsed change | CPU change | Local warm CLR allocation |",
    "| --- | --- | ---: | ---: | ---: |",
]
for row in summary["rows"]:
    case = row["case"]
    warm = row["lane"] == "warm"
    rows.append(f"| {names[case]} | {'Warm' if warm else 'Compile to result'} | {extent(row['elapsedChangePercent'])}"
                f" | {extent(row['cpuChangePercent'])} | {percent(allocations[case]) if warm else '—'} |")

decision = """Keep this layout private. Both nested factory workloads use less CPU,
and the postponed case reaches its result 2.51–5.66% sooner. Eager
rules alone have a 5.01% candidate control spread and mixed results.
The tuple-producing invoice and the metadata observer both consume
more CPU and allocate more. The invoice never uses compound defaults.
The results support a design that removes storage from ordinary
definitions without changing the tuple layout. A refinement also
needs to cover metadata observation without moving the entire
allocation cost to that read."""
source = (lab / "B1281-template.md").read_text(encoding="utf-8")
result = source.replace("{{results}}", "\n".join(rows)).replace("{{decision}}", decision)
(lab / "B1281-README.md").write_text(result, encoding="utf-8", newline="\n")
(lab / "decision.json").write_text(json.dumps(dict(retained=False, decision=decision), indent=2) + "\n",
                                   encoding="utf-8", newline="\n")
