from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile


lab = Path(__file__).resolve().parent
prior = lab.parent / "compiler-literal-newlines"
template = prior / "quiet"
quiet = lab / "quiet"
repo = lab.parents[3]
core = "Lokad.Lython.dll"


def read(path):
    return path.read_text(encoding="utf-8")


def load(path):
    return json.loads(read(path))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def emit(path, source):
    if path.suffix == ".py":
        compile(source, str(path), "exec")
    path.write_text(source, encoding="utf-8", newline="\n")


def save(path, value):
    emit(path, json.dumps(value, indent=2) + "\n")


index = load(lab / "identity.json")
previous = load(template / "config.json")
receipt = load(template / "archive-receipt.json")
assert receipt["complete"] and receipt["archivedAndVerifiedUnderLease"]
assert receipt["archiveSHA256"] == sha(template / "observations.tgz")
images = index["imageFiles"]
source_files = previous["identity"]["imageFiles"]["candidate"]
assert index["reference"].startswith("7e5cdd6e8") and source_files == images["reference"]
assert len(source_files) == 32 and previous["protocolSHA256"] == index["pythonWorkerSHA256"]
assert [name for name in source_files if source_files[name] != images["candidate"][name]] == [core]
manifest = lab / "representative.json"
cases = load(manifest)["cases"]
postponed = next(case["id"] for case in cases if "nested-factories.postponed" in case["id"])
jobs = [(case["id"], "warm") for case in cases] + [(postponed, "compile-run")]
assert len(jobs) == 8
for role, files in images.items():
    assert {name: sha(lab / "frozen" / role / name) for name in files} == files
    verification = load(lab / f"{role}-verify.json")
    assert verification["state"] == "Completed" and verification["caseCount"] == 7
    assert verification["catalogSha256"] == index["catalogSHA256"] == sha(manifest)

canonical = "benchmarks/results/2026-11-21-compiler-literal-newlines/reference-core.dll.gz"
retired_bytes = gzip.decompress(subprocess.check_output(["git", "show", "HEAD:" + canonical], cwd=repo))
retired_hash = hashlib.sha256(retired_bytes).hexdigest()
assert retired_hash == previous["identity"]["imageFiles"]["reference"][core]
prior_name = Path(previous["root"]).name
retire = [dict(paths=[prior_name + "/reference/" + core], links=1, bytes=len(retired_bytes), sha256=retired_hash,
               archives={prior_name + "/observations.tgz": receipt["archiveSHA256"]},
               verifiedCanonicalGitImage=canonical)]
root = "/home/lokad/lython-bench-checks/compound-defaults-b1281-20261121"
unit = "lython-b1281-compound-defaults-20261121"
quiet.mkdir(exist_ok=False)
identity = dict(sourceRevision=index["reference"] + " versus " + index["candidate"],
                purpose="Shared backing and executable operand for compound function defaults",
                imageFiles=images, normalAdapterPin="0.4.0", catalogSHA256=index["catalogSHA256"],
                coreSHA256={role + suffix: files[core] for role, files in images.items() for suffix in ("", "-control")})
save(quiet / "identity.json", identity)
for name in ("collect.py", "archive-owned.py", "run.sh", "retrieve.py"):
    source = read(template / name).replace(previous["root"], root).replace(previous["unit"], unit)
    if name == "collect.py":
        begin = source.index("\njobs = ")
        end = source.index("\nassert len(jobs)", begin)
        source = source[:begin] + "\njobs = " + repr(jobs) + source[end:]
    source = source.replace("len(jobs)==5", "len(jobs)==8").replace("len(raw['jobs'])==5", "len(raw['jobs'])==8")
    source = source.replace("jobs=5,elapsedSeconds", "jobs=8,elapsedSeconds").replace("status['receipt']['jobs']==5", "status['receipt']['jobs']==8")
    emit(quiet / name, source)
assert b"\r" not in (quiet / "run.sh").read_bytes()
parts = ("identity.json", "representative.json", "collect.py", "archive-owned.py", "run.sh", "candidate/" + core)
(quiet / "candidate").mkdir()
shutil.copyfile(lab / "frozen/candidate" / core, quiet / "candidate" / core)
shutil.copyfile(manifest, quiet / "representative.json")
payload = quiet / "payload.tgz"
with tarfile.open(payload, "w:gz") as packed:
    for name in parts:
        packed.add(quiet / name, arcname=name)
config = dict(root=root, unit=unit, identity=identity, source=previous["root"], sourceRole="candidate",
              sourceFiles=source_files, sourceCatalogSHA256=previous["catalogSHA256"],
              donorArchiveSHA256=receipt["archiveSHA256"], catalogSHA256=identity["catalogSHA256"], retireGroups=retire,
              protocolSource=previous["root"] + "/cpython-worker.py", protocolSHA256=index["pythonWorkerSHA256"],
              payloadBytes=payload.stat().st_size, payloadSHA256=sha(payload),
              unpackedBytes=sum((quiet / name).stat().st_size for name in parts))
save(quiet / "config.json", config)
source = read(template / "remote-launch.py")
begin = source.index("\nc=") + 1
end = source.index("\nb=Path(", begin)
source = source[:begin] + "c=" + repr(config) + source[end:]
emit(quiet / "remote-launch.py", source.replace("lython-b1280-fixtures", "lython-b1281-fixtures"))
emit(lab / "launch-shared.py", read(prior / "launch.py").replace("295", "458")
     .replace("Single-pass literal newlines comparison", "Compound defaults comparison"))
emit(lab / "summarize-shared.py", read(prior / "summarize.py").replace("len(raw['jobs'])==5", "len(raw['jobs'])==8"))
