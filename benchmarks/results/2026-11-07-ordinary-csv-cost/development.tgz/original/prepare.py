from pathlib import Path
import ast,hashlib,json,subprocess,tarfile
r=Path(__file__).parent;old=r.parent/'report-cost-r34';remote='/home/lokad/lython-bench-checks/csv-cost-b390-20261107'
before='/home/lokad/lython-bench-checks/report-cost-b385-20261107'
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','diff','--name-only','--','src'],text=True).strip()
core=Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll');digest=hashlib.sha256(core.read_bytes()).hexdigest()
checks=json.loads((r.parent/'annotation-demand-r38/focused-initial.json').read_text(encoding='utf-8'))
assert digest==checks['coreSHA256']['net11.0']=='c21c0c4b3537c731d76fe5f96afb0c8f13f2c99a8335e09902c2f4c29a1e7fea'
identity=json.loads((old/'identity.json').read_text(encoding='utf-8-sig'));identity['files']['Lokad.Lython.dll']=digest
identity['sourceRevision']=head+'; production b0889a46, focused frozen c21c0c4b built before commit with SourceLink79fddd4a'
identity['sourceSHA256']={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('src/Lokad.Lython').rglob('*.cs') if 'obj' not in p.parts and 'bin' not in p.parts}
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
(r/'catalog.json').write_bytes((r.parent/'annotation-demand-r38/catalog.json').read_bytes())
for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh']:
 s=(old/name).read_text(encoding='utf-8-sig').replace(before,remote).replace('lython-report-cost-b385','lython-csv-cost-b390').replace('report-warm','csv-warm').replace('scripts.report-render.large','scripts.csv-summary-functions.large')
 if name=='ops-profile.py':
  s=s.replace('        worker = tree / "candidate/Lokad.Lython.Benchmarks.dll"','''        env["DOTNET_JitDisasm"]="BeginPendingCall CreateExecutableWorkState BindPositionalOperands RentFunctionArgumentStorage"
        env["DOTNET_JitStdOutFile"]=str(folder/"call-jit.txt")
        worker = tree / "candidate/Lokad.Lython.Benchmarks.dll"''')
  s=s.replace('["DOTNET_PerfMapEnabled"]','["DOTNET_PerfMapEnabled","DOTNET_JitDisasm","DOTNET_JitStdOutFile"]')
 (r/name).write_text(s,encoding='utf-8',newline='\n')
contract='''# R39/B390 ordinary-helper CSV cost gate

One complete maintained CSV summary/ordinary helper script on current committed
b0889a46 production/focused c21c0c4b (metadata-only HEAD recorded separately).
accumulate is a24-instruction executable function, not a closed native body.
The text profile's native words helper and report profile do not establish ordinary
per-record call/frame costs. Source already has direct operands, borrowed native
slices, prepared parameter layout, shared final locals/operand workspace, idle
workspace reuse and lazy invocation contexts. Do not recreate these mechanisms.

Question: is another whole binding/frame/continuation phase material, or does CSV
parse/dictionary/numeric work dominate? One6s CPU-clock/fp199Hz window,6s warmup,
2s settling, actual guest TIDs/unknowns, same checked b94 worker/host/optional0.4,
normal GC/tiering plus explicit PerfMap3 and selected call-method JIT listings.
No runtime prototype, source-pair timing, allocation or new qualification campaign.
Requests include mediated RAM I/O/full output-file goldens/prior-result cleanup;
compile/startup/staging/reset/final teardown excluded. Raw attribution is diagnostic,
not removable CPU or proof of causality. At completion select one source-backed
deletion with semantic/ownership acceptance, or record missing proof and move
boundary; no automatic repeat for a favorable distribution or general frame arena.

Preserve managed stack/cancellation/first refusal/aliases and awaited actual users.
120s owner+30s stop+30s margin before observing. Persistent inputs/outputs; raw RAM
trace archived/verified under lease before removal. Ready/source/aux/golden/quiet/
funding/Closed/joins/fixtures/archive gates required. B389 is terminal/archived;
never query it again. Full delivery42351006316 proceeds independently. Publication
postponed; the whole-script performance objective remains active.
'''
(r/'source-contract.md').write_text(contract,encoding='utf-8',newline='\n')
for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py']:ast.parse((r/name).read_text(encoding='utf-8'))
with tarfile.open(r/'payload.tgz','w:gz') as a:
 for name in ['identity.json','catalog.json','ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','source-contract.md']:a.add(r/name,arcname=name)
 a.add(core,arcname='current-core.dll')
launch=(old/'launch.py').read_text(encoding='utf-8-sig').replace('report-cost-b385-20261107','csv-cost-b390-20261107').replace('canonical-formatting-b374-20261107/candidate','annotation-demand-b389-20261107/candidate').replace('lython-report-cost-b385','lython-csv-cost-b390').replace('lython-b385-report-cost-20261107','lython-b390-csv-cost-20261107').replace('report-cost-b385-launch.py','csv-cost-b390-launch.py')
(r/'launch.py').write_text(launch,encoding='utf-8',newline='\n');ast.parse(launch)
plan=Path('PLAN.md');s=plan.read_text(encoding='utf-8');a=s.index('**Next concrete gate:**');b=s.index('**Selected R38',a)
s=s[:a]+'''**R37 call-transport gate:** static census shows native call slices already
borrow storage; dropping adjacent loads retains that storage and adds evaluated-
snapshot/error-span metadata. No new transport prototype selected.

**R39 selected cost gate:** ordinary CSV accumulate is24executable instructions,
not the text profile's closed native helper. Source already shares parameter layouts,
final locals/operands and idle workspaces, with lazy contexts. One bounded6s current
CSV capture with actual guest TIDs/unknowns and call-method generated code will
decide whether another complete binding/frame phase is material or parsing/container
work dominates. Existing report/text profiles cannot establish this for CSV. No
runtime prototype, general caller arena, aggregate recapture or CPU forecast.
Afterwards select a source-proved deletion/acceptance milestone, or record the missing
proof and move boundary. No automatic repetition. See private csv-cost-r39 contract.

'''+s[b:]
plan.write_text(s,encoding='utf-8',newline='\n')
print('R39 source/cost question recorded; prepared one bounded CSV capture.')
