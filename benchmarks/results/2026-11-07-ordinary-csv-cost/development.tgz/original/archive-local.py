from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;b=r/'b391';repo=Path('D:/code/Lython');o=repo/'benchmarks/results/2026-11-07-ordinary-csv-cost';o.mkdir(exist_ok=True)
receipt=json.loads((b/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['archivedAndVerifiedUnderLease']
assert hashlib.sha256((b/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
failed=json.loads((r/'failure-receipt.json').read_text(encoding='utf-8'));assert failed['noWorkerStarted'] and hashlib.sha256((r/'failed-before-worker.tgz').read_bytes()).hexdigest()==failed['archiveSHA256']
for name in ['observations.tgz','archive-receipt.json','guest-call-chains.json','source-contract.md']:shutil.copyfile(b/name,o/name)
for name in ['failed-before-worker.tgz','failure-receipt.json']:shutil.copyfile(r/name,o/name)
with tarfile.open(o/'development.tgz','w:gz') as t:
 for folder in [r,b]:
  for p in folder.iterdir():
   if p.is_file() and p.suffix in ['.py','.json','.md','.log','.sh']:
    t.add(p,arcname=('original/' if folder==r else 'corrected/')+p.name)
def write(p,s):p.write_text(s,encoding='utf-8',newline='\n')
write(o/'README.md','''# Ordinary-helper CSV cost gate — R39/B391

2026-11-07UTC. Productionb0889a46/metadata HEAD3604f935, frozen c21c0c4b with
precommit SourceLink79fddd4a; source inventory and actual Ready image verified.
Later R40 is excluded. Same b94fa98c worker/host/normal optional0.4, .NET11RC3,
quiet AzureF4as_v7/Ubuntu24.04.4, normal GC/tiering plus PerfMap3/selected call
method listings. One existing complete CSV/helper warm script, six-second warmup,
two-second settling, six-second199Hz CPU-clock/fp window. Diagnostic job clocks
5.7118s, actual guest5.68CPU seconds,1,127guest samples/58unknown leaves.
Other threads, mappings, all raw/code/unknowns and incomplete/inlined stacks retained.

Requests include mediated RAM I/O, complete output/file goldens and prior-result
cleanup. Compilation/startup/staging/reset/final teardown excluded. No source-pair
timing, allocation result, causal saved CPU or new runtime qualification follows.

| Work | Inclusive /self samples | Interpretation |
| --- | ---: | --- |
| BeginPendingCall |550/32|Includes running the ordinary helper; not binding dominance. |
| CreateExecutableWorkState |26/18|Uses final admitted/reused locals/operand backing already. |
| Positional binding |22/18|Prepared layouts and direct operands already exist. |
| ResumePendingCall |11/11|Completion transport remains, but aggregate cost is small. |
| CSV reader NextAsync |377/25|Parsing and collection construction are included. |
| CSV parser Feed |198/35|Useful parsing; not a removable percentage. |
| FinishRecord /TryAdoptRecord |44/34self|Includes completed row storage/identity/admission work. |

This does not select a general frame/call-arena rewrite. Existing source already
has lazy invocation contexts, shared parameter layouts, direct operands, final
locals/operand backing and execution-owned idle workspaces. Earlier slower call-
arena/control results remain relevant. Do not revive delivered work or total
overlapping inclusive stacks as saved CPU. No second aggregate profile selected.
The independent core Unicode projection source gate has a concrete repeated-prefix
algorithm to address; it does not explain these CSV costs or close non-regex gaps.

Original B390 fails before Popen creates a worker: string adaptation makes one
environment-map key a tuple. Preserve its source/terminal/failure archive; there
are no measurements. Archive/verify failed RAM evidence under lease, confirm ended
users/no fixtures, then remove it. B391 corrects only that entry and statically
checks environment subscript keys; runtime and capture conditions stay unchanged.
This is a setup correction, not a failed runtime design or discarded adverse sample.

B391 terminal07:33:40UTC exit0; observe07:37:23UTC after07:36:11.836724bound
(120s owner+30s stop+30s margin). All source/Ready/aux/golden/funding/quiet/Closed/
exit/join/fixture/archive gates pass; raw RAM archived/verified before removal.
Independent retrieval verifies07ce6542. B390/B391 terminal; no more service queries.
R36/R38 full delivery42351006316 remains independent; publication postponed.

[Raw capture/code/gates](observations.tgz), [all chains](guest-call-chains.json),
[receipt](archive-receipt.json), [failed original](failed-before-worker.tgz),
[source and all collection commands](development.tgz).
''')
p=repo/'.gitattributes';s=p.read_text(encoding='utf-8');s+='\n# Preserve the ordinary-helper CSV capture and original failed setup.\nbenchmarks/results/2026-11-07-ordinary-csv-cost/** -text whitespace=cr-at-eol\n';write(p,s)
p=repo/'benchmarks/EXPERIMENTS.md';s=p.read_text(encoding='utf-8');s+='''

## R39 ordinary-helper CSV cost gate

[B391](results/2026-11-07-ordinary-csv-cost/README.md) records1,127guest samples/
5.68CPU seconds on b0889a46 production;58unknown leaves retained. BeginPendingCall
550inclusive/32self includes useful helper work; work-state26/18, binding22/18,
resume11/11 do not establish a dominant removable frame phase. CSV parsing/record
construction also competes. No general frame/call-arena prototype or repeat profile
selected. B390 failed before worker creation on a tuple environment key; original
condition archived/verified before one correction. B391 all gates pass, terminal/
users joined/RAM evidence archived/removed. No source-pair performance claim.
''';write(p,s)
p=repo/'PLAN.md';s=p.read_text(encoding='utf-8');a=s.index('**R39 selected cost gate:**');b_=s.index('**Selected R38',a)
s=s[:a]+'''**R39 closed cost gate:** B391/currentb0889a46 completes all source/golden/quiet/
funding/Closed/join/archive gates:1,127guest samples/5.68CPU seconds,58unknown.
BeginPendingCall550inclusive/32self includes helper execution; work-state26/18,
binding22/18,resume11/11 do not establish a dominant removable frame phase. CSV
parsing/record construction competes. No frame arena/rewrite or repeat aggregate
profile selected; shared layouts/final backing/idle workspaces already exist.
Original B390 setup failed before worker creation; source/condition archived before
one environment-key correction. Historical evidence now in ordinary-csv-cost.

'''+s[b_:]
a=s.index('**Selected R38');b_=s.index('**Completion for a retained redesign:**',a)
s=s[:a]+'''**R38 retained:** irrelevant annotation binding suffixes removed; required control
exit facts and full regex conservative flow preserved. Source b0889a46, focused/
allocation/quiet outcomes recorded above; original3failures and refinement archived
under annotation-demand. Full delivery42351006316 remains pending, independent of
the active R40 prototype. No repeated measurements or qualification selected.

'''+s[b_:]
s=s.replace('B390 failed before worker startup (tuple environment key); original archive\nverified and RAM/users cleaned. B391 corrects only that setup entry and owns\n120+30+30s through07:36:11.836724UTC. No early observation or restart on timeout.','B390/B391 terminal, all users ended and archives independently verified; no\nmore service queries. No owned VM work remains. R40 prototype/focused checks pass\n853internal/1,224public per actual target; timing and new-loop cancellation remain\npending. R36/R38 full CI excludes R40.')
write(p,s)
print('R39 evidence archived; no dominant frame phase selected; R40 remains active.')
