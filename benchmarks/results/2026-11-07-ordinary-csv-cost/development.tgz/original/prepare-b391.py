from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent;b=r/'b391';b.mkdir(exist_ok=False)
names=['identity.json','catalog.json','ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','source-contract.md','launch.py']
for name in names:
 s=(r/name).read_text(encoding='utf-8-sig').replace('csv-cost-b390','csv-cost-b391').replace('lython-b390-csv-cost','lython-b391-csv-cost').replace('R39/B390','R39/B391')
 if name=='ops-profile.py':
  s=s.replace('env["DOTNET_PerfMapEnabled","DOTNET_JitDisasm","DOTNET_JitStdOutFile"] = "3"','env["DOTNET_PerfMapEnabled"] = "3"')
  tree=ast.parse(s)
  assert not any(isinstance(n,ast.Subscript) and isinstance(n.value,ast.Name) and n.value.id=='env' and isinstance(n.slice,ast.Tuple) for n in ast.walk(tree))
 if name=='source-contract.md':s+='\nOriginal B390 fails before worker creation on one tuple environment key. Preserve its archive/terminal condition; this run corrects only that setup entry, retaining runtime/conditions. No observations are discarded or runtime design rejected.\n'
 (b/name).write_text(s,encoding='utf-8',newline='\n')
for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py','launch.py']:ast.parse((b/name).read_text(encoding='utf-8'))
core=r.parent/'annotation-demand-r38/images/candidate/Lokad.Lython.dll';assert hashlib.sha256(core.read_bytes()).hexdigest()=='c21c0c4b3537c731d76fe5f96afb0c8f13f2c99a8335e09902c2f4c29a1e7fea'
with tarfile.open(b/'payload.tgz','w:gz') as t:
 for name in names:
  if name!='launch.py':t.add(b/name,arcname=name)
 t.add(core,arcname='current-core.dll')
collect=(r/'collect.py').read_text(encoding='utf-8-sig').replace('csv-cost-b390','csv-cost-b391').replace('lython-b390-csv-cost','lython-b391-csv-cost')
(b/'collect.py').write_text(collect,encoding='utf-8',newline='\n')
(b/'analyze-chains.py').write_text((r/'analyze-chains.py').read_text(encoding='utf-8-sig'),encoding='utf-8',newline='\n')
print('B391 corrects only environment-map entry; failed original preserved.')
