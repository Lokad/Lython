set -eu
root=/home/lokad/lython-bench-checks/csv-cost-b390-20261107
dotnet=/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet
export DOTNET_ROOT=/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148
export TMPDIR=/dev/shm
date -u +%FT%TZ > "$root/started.utc"
trap 'exit 143' TERM
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"; date -u +%FT%TZ > "$root/stopped.utc"' EXIT
exec 9>/home/lokad/lython-bench-checks/comparison-vm.lock
flock -n 9
sleep 5
"$dotnet" "$root/candidate/Lokad.Lython.Benchmarks.dll" --compare check-machine --out "$root/machine-before.json"
python3 "$root/ops-profile.py" "/dev/shm/lython-csv-cost-b390"
sleep 5
"$dotnet" "$root/candidate/Lokad.Lython.Benchmarks.dll" --compare check-machine --out "$root/machine-after.json"
for case in csv-warm; do
 python3 "$root/analyze-cpu-guest.py" "/dev/shm/lython-csv-cost-b390/$case"
done
# All sudo perf reads have ended before transferring these owned files.
sudo -n chown lokad:lokad "/dev/shm/lython-csv-cost-b390/csv-warm/perf.data"
python3 "$root/archive.py"
python3 - <<'PY'
from pathlib import Path
import shutil
p=Path('/dev/shm/lython-csv-cost-b390')
assert p.is_dir() and not p.is_symlink() and p.resolve()==p
shutil.rmtree(p)
PY
