from pathlib import Path
import hashlib,json,shlex,subprocess,tarfile
r=Path(__file__).parent
script='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess,tarfile
base=Path('/home/lokad/lython-bench-checks');root=base/'csv-cost-b390-20261107';ram=Path('/dev/shm/lython-csv-cost-b390')
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert (root/'exit-code.txt').read_text().strip()=='1'
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 assert ram.resolve()==ram and ram.is_dir() and not ram.is_symlink()
 for p in ram.rglob('*'):assert not p.is_symlink() and p.stat().st_uid==os.getuid()
 archive=root/'failed-before-worker.tgz';assert not archive.exists()
 with tarfile.open(archive,'w:gz') as t:
  t.add(ram,arcname='perf')
  for p in root.iterdir():
   if p.is_file() and p!=archive:t.add(p,arcname=p.name)
 with tarfile.open(archive) as t:assert t.extractfile('exit-code.txt').read().strip()==b'1'
 receipt=dict(complete=False,noWorkerStarted=True,noPerformanceObservations=True,allUsersEnded=True,archiveSHA256=hashlib.sha256(archive.read_bytes()).hexdigest(),archivedAndVerifiedUnderLease=True,condition='Environment map has one tuple key after collector string adaptation; Popen rejects it before child creation.')
 (root/'failure-receipt.json').write_text(json.dumps(receipt,indent=2)+'\\n')
 shutil.rmtree(ram)
 print(json.dumps(receipt))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
stage='/home/lokad/lython-bench-checks/csv-cost-b390-failure-archive.py'
code='from pathlib import Path;import sys;p=Path('+repr(stage)+');assert not p.exists();p.write_bytes(sys.stdin.buffer.read())'
a=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=script.encode('utf-8'),capture_output=True);assert a.returncode==0,a.stderr
a=subprocess.run(ssh+['python3 '+stage],capture_output=True);(r/'failure-archive.log').write_bytes(a.stdout+a.stderr);assert a.returncode==0,a.stderr
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for name in ['failed-before-worker.tgz','failure-receipt.json']:
 a=subprocess.run(scp+['lokad@20.166.121.73:/home/lokad/lython-bench-checks/csv-cost-b390-20261107/'+name,str(r/name)],capture_output=True);assert a.returncode==0,a.stderr
receipt=json.loads((r/'failure-receipt.json').read_text(encoding='utf-8'));assert hashlib.sha256((r/'failed-before-worker.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
print('Failed setup archived and hash-verified; no users or RAM evidence left.')
