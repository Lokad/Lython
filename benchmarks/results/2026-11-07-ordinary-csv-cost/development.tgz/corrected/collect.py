from pathlib import Path
import datetime,hashlib,json,subprocess
root=Path(__file__).parent
bound=json.loads((root/'observe-not-before.json').read_text(encoding='utf-8-sig'))
assert datetime.datetime.now(datetime.timezone.utc)>=datetime.datetime.fromisoformat(bound['doNotObserveBeforeUTC'])
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem',
 '-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
remote='/home/lokad/lython-bench-checks/csv-cost-b391-20261107'
command='systemctl show lython-b391-csv-cost-20261107 -p ActiveState -p SubState -p Result -p ExecMainStatus; journalctl -u lython-b391-csv-cost-20261107 --no-pager -n 35; cat '+remote+'/exit-code.txt '+remote+'/archive-receipt.json'
r=subprocess.run(ssh+[command],capture_output=True)
(root/'terminal.log').write_bytes(r.stdout+b'\n'+r.stderr)
print(r.stdout.decode('utf-8'),flush=True)
assert r.returncode==0,r.stderr.decode('utf-8')
assert b'ActiveState=inactive' in r.stdout and b'ExecMainStatus=0' in r.stdout
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes']
for name in ['archive-receipt.json','observations.tgz']:
 subprocess.run(scp+['lokad@20.166.121.73:'+remote+'/'+name,str(root/name)],check=True)
receipt=json.loads((root/'archive-receipt.json').read_text())
assert hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['quietBeforeAndAfter'] and receipt['archivedAndVerifiedUnderLease']
print('Persistent archive downloaded and hash verified.',flush=True)
