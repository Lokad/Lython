import json
import subprocess
import sys
from pathlib import Path

lab = Path(__file__).resolve().parent
old = lab.parent/'csv-search-sets-r711'
stage = (old/'stage-quiet.py').read_text(encoding='utf-8')
stage = stage.replace('csv-search-sets-b1141','function-binding-inline-b1142')
stage = stage.replace('lython-b1141-csv-search-sets','lython-b1142-function-binding-inline')
stage = stage.replace('lython-b1141-fixtures','lython-b1142-fixtures')
stage = stage.replace('R711 prepared CSV search sets','R712 inline live function binding state')
stage = stage.replace('Prepared CSV search sets','Inline function binding state')
start = stage.index('        jobs = [')
end = stage.index('\n', start)
catalog = json.loads((lab/'catalog.json').read_text(encoding='utf-8'))
jobs = [(case['id'],'warm') for case in catalog['cases']]
jobs.append(('scripts.annotated-rule-closures','compile-run'))
assert len(jobs) == 6
stage = stage[:start] + '        jobs = ' + repr(jobs) + stage[end:]
stage = stage.replace('len(jobs)==5','len(jobs)==6')
stage = stage.replace("len(raw['jobs'])==5","len(raw['jobs'])==6")
stage = stage.replace('jobs=5,','jobs=6,').replace("['jobs']==5","['jobs']==6")
stage = stage.replace('.replace("==6","==5")','')
stage = stage.replace('"295"','"350"').replace('seconds=295','seconds=350')
stage = stage.replace('four-case, five-job','five-case, six-job').replace('}) == 4','}) == 5')
proof = (old/'prove-quiet-space.py').read_text(encoding='utf-8')
start = proof.index('pairs = ')
end = proof.index('\n',start)
pairs = [('csv-search-sets-r711/quiet','2026-11-19-prepared-csv-search-sets','reference','reference-core.dll.gz'),
         ('csv-search-sets-r711/quiet','2026-11-19-prepared-csv-search-sets','candidate','measured-core.dll.gz')]
proof = proof[:start] + 'pairs = ' + repr(pairs) + proof[end:]
for name,value in [('prove-quiet-space.py',proof),('stage-quiet.py',stage)]:
    (lab/name).write_text(value,encoding='utf-8',newline='\n')
    subprocess.run([sys.executable,'-X','utf8',lab/name],check=True)

