from pathlib import Path
import ast
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
prior = lab/'quiet'
out = lab/'confirmation'
out.mkdir(exist_ok=False)
load = lambda path: json.loads(path.read_text(encoding='utf-8'))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
original = load(prior/'config.json')
receipt = load(prior/'archive-receipt.json')
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
assert sha(prior/'observations.tgz') == receipt['archiveSHA256']
identity = load(prior/'identity.json')
source = original['root']
root = '/home/lokad/lython-bench-checks/function-binding-inline-b1142-confirmation-20261119'
unit = 'lython-b1142-function-binding-inline-confirmation-20261119'
assert all(len(files)==32 for files in identity['imageFiles'].values())
assert sha(prior/'representative.json')==identity['catalogSHA256']
cases = {case['id'] for case in load(prior/'representative.json')['cases']}
jobs = [('scripts.csv-invoice.large','warm'),('scripts.annotated-rule-closures','compile-run'),
        ('scripts.captured-rule-closures','warm')]
assert all(case in cases for case,_ in jobs)
def write(path, value):
    if path.suffix == '.py': ast.parse(value)
    path.write_text(value,encoding='utf-8',newline='\n')
for name in ('collect.py','archive-owned.py','retrieve.py','run.sh'):
    code=(prior/name).read_text(encoding='utf-8').replace(source,root)
    code=code.replace('len(jobs)==6','len(jobs)==3').replace("len(raw['jobs'])==6","len(raw['jobs'])==3")
    code=code.replace('jobs=6,','jobs=3,').replace("['jobs']==6","['jobs']==3")
    if name == 'collect.py':
        start,end=code.index('\njobs = ')+1,code.index('\nassert len(jobs)')
        code=code[:start]+'jobs = '+repr(jobs)+code[end:]
        # All three original jobs used the reversed worker order.
        assert '            if job_index >= 2: labels.reverse()\n' in code
        code=code.replace('            if job_index >= 2: labels.reverse()\n','')
    write(out/name,code)
for name in ('representative.json','identity.json'):
    shutil.copyfile(prior/name,out/name)
names=('collect.py','archive-owned.py','run.sh','identity.json')
with tarfile.open(out/'payload.tgz','w:gz') as tar:
    for name in names:tar.add(out/name,arcname=name)
config=dict(root=root,unit=unit,source=source,sourceFiles=identity['imageFiles'],
    sourceCatalogSHA256=identity['catalogSHA256'],catalogSHA256=identity['catalogSHA256'],identity=identity,
    retireGroups=[],payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=sha(out/'payload.tgz'),
    unpackedBytes=sum((out/name).stat().st_size for name in names),donorArchiveSHA256=receipt['archiveSHA256'])
write(out/'config.json',json.dumps(config,indent=2)+'\n')
template=lab.parent/'framed-unpacked-return-r680/confirmation/remote-launch.py'
launcher=template.read_text(encoding='utf-8')
start,end=launcher.index('\nc=')+1,launcher.index('\nb=Path(')
launcher=launcher[:start]+'c='+repr(config)+launcher[end:]
launcher=launcher.replace(" os.link(source/'cpython-worker.py',root/'cpython-worker.py')\n",'')
launcher=launcher.replace('lython-b1113-control-fixtures','lython-b1142-control-fixtures')
launcher=launcher.replace('RuntimeMaxSec=340','RuntimeMaxSec=260')
write(out/'remote-launch.py',launcher)
launch=(lab/'launch-quiet.py').read_text(encoding='utf-8').replace("/'quiet'","/'confirmation'").replace('350','185')
write(lab/'launch-confirmation.py',launch)
analyze=(lab/'summarize-quiet.py').read_text(encoding='utf-8').replace("quiet/retrieved/","confirmation/retrieved/")
analyze=analyze.replace("len(raw['jobs'])==6","len(raw['jobs'])==3").replace('quiet-summary.json','confirmation-summary.json')
write(lab/'summarize-confirmation.py',analyze)
print('Prepared three unchanged cases with reversed worker order and verified image reuse.')

