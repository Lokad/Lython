import json
import subprocess
import sys
from pathlib import Path

lab = Path(__file__).resolve().parent
old = lab.parent/'csv-search-sets-r711'
load = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
catalog = load(lab.parent/'prepared-local-destination-r707/catalog.json')
assert len(catalog['cases']) == 5
(lab/'catalog.json').write_text(json.dumps(catalog,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
source = (old/'freeze-and-verify.py').read_text(encoding='utf-8')
source = source.replace('csv-search-sets-r711','function-binding-inline-r712')
source = source.replace("git('rev-parse','fdacfbe20')", "git('rev-parse','65926a62d')")
source = source.replace('len(load(catalog_path)["cases"]) == 4','len(load(catalog_path)["cases"]) == 5')
source = source.replace('all four cases','all five cases')
assert "trial=repo/'.git/agent-worktrees/function-binding-inline-r712'" in source
assert "git('rev-parse','65926a62d')" in source
(lab/'freeze-and-verify.py').write_text(source,encoding='utf-8',newline='\n')
subprocess.run([sys.executable,'-X','utf8',lab/'freeze-and-verify.py'],check=True)

