from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / 'comparison/quiet'
folder = repo / 'benchmarks/results/2026-11-26-current-async-iterator-profile'
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
terminal = read(quiet / 'terminal-status.json')
receipt = terminal['receipt']
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode'] == '0'
assert all(receipt[k] for k in ('complete','quietBeforeAndAfter','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
assert sha(quiet/'observations.tar.xz') == receipt['archiveSHA256']
identity = read(quiet/'identity.json')
verification = read(quiet/'verification.json')
assert verification['caseCount'] == 2 and verification['state'] == 'Completed'
assert verification['catalogSha256'] == identity['profileCatalogSHA256']
assert verification['launched']['library']['sha256'] == identity['coreSHA256']['candidate']
with tarfile.open(quiet/'observations.tar.xz') as evidence:
    assert json.load(evidence.extractfile('identity.json')) == identity
    assert hashlib.sha256(evidence.extractfile('catalog.json').read()).hexdigest() == identity['profileCatalogSHA256']
    for label, _, _ in identity['profiles']:
        record = json.load(evidence.extractfile(f'profiles/{label}/record.json'))
        assert record['verificationBefore']['status'] == record['verificationAfter']['status'] == 'Equivalent'
        assert record['closed']['status'] == 'Closed'
    for check in ('before-machine.json','after-machine.json'):
        assert json.load(evidence.extractfile(check))['gate']['quiet']
folder.mkdir()
for name in ('attribution.json','identity.json','observations.tar.xz','terminal-status.json'):
    shutil.copyfile(quiet / name, folder / name)
with tarfile.open(folder/'procedures.tar.xz','w:xz') as bundle:
    for directory,names in (
        (lab, ('prepare.py','quiet.py','archive-profile.py','prepare.log','launch-console.log','retrieve.log','analyze.log')),
        (quiet, ('verification.json','analyze.py','launch.log','upload.json')),
    ):
        for name in names: bundle.add(directory/name,arcname=name,recursive=False)
