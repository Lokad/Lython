from pathlib import Path
import json,subprocess
r=Path(__file__).parent;programs=json.loads((r/'programs.json').read_text(encoding='utf8'))
rows=[]
for label,source in programs:
 done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],capture_output=True,text=True,encoding='utf8')
 assert done.returncode==0,(label,done.stderr)
 rows.append(dict(label=label,source=source,expected=done.stdout))
version=subprocess.check_output(['C:/Python313/python.exe','-I','-S','-c','import sys;print(sys.version)'],text=True)
(r/'goldens.json').write_text(json.dumps(dict(reference=version.strip(),programs=rows),ensure_ascii=False,indent=2)+'\n',encoding='utf8')
literal=lambda value:json.dumps(value,ensure_ascii=False)
data='\n'.join('        { '+','.join(literal(row[k])for k in ['label','source','expected'])+' },'for row in rows)
source="""using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.PublicApi.Tests;

public sealed class NativeConditionalHelperTests
{
    // Independent isolated CPython outputs; both APIs share these semantics.
    public static TheoryData<string, string, string> Programs => new()
    {
DATA
    };

    [Theory]
    [MemberData(nameof(Programs))]
    public async Task BranchHelpersPreserveSelectedWorkAndFreshResults(string label, string source, string expected)
    {
        var budget = new LythonMemoryBudget(4 * 1024 * 1024);
        using var script = new LythonEngine().Compile(source, budget);
        Assert.True(script.IsValid, label + ": " + string.Join("; ", script.Diagnostics.Select(d => d.Message)));
        var baseline = budget.ReservedBytes;
        foreach (var asynchronous in new[] { false, true })
        {
            using (var result = asynchronous ? await script.RunAsync(new MockLythonHost()) : script.Run(new MockLythonHost()))
            {
                Assert.True(result.Success, result.Failure?.Message);
                Assert.Equal(expected, result.StandardOutput);
            }
            Assert.Equal(baseline, budget.ReservedBytes);
        }
        script.Dispose();
        Assert.Equal(0, budget.ReservedBytes);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task ActualTruthSuspensionKeepsFundingUntilCancellationOrRefusalFinishes(bool refuse)
    {
        const string source = """
source+='"""+'\n'+"""            class Flag:
                def __bool__(self):
                    with open('/cleanup','w') as target:
                        target.write('before')
                        target.flush()
                    with open('/value') as reader:
                        reader.read()
                    try:
                        if fail: storage='x'*4194304
                    finally:
                        return True
            def choose(flag):
                if flag:return []
                return []
            choose(Flag())
            """+'"""\n'+"""
        ;
        var budget = new LythonMemoryBudget(2 * 1024 * 1024);
        using var script = new LythonEngine().Compile(source, budget);
        Assert.True(script.IsValid);
        var baseline = budget.ReservedBytes;
        using var cancellation = new CancellationTokenSource();
        var host = new DelayedLythonHost();
        host.SeedFile("/value", "1");
        var started = refuse ? null : host.PauseReadUntilCancellation("/value");
        var run = script.RunAsync(host, new LythonRunOptions
        {
            CancellationToken = cancellation.Token,
            Globals = new Dictionary<string, object?> { ["fail"] = refuse }
        });
        try
        {
            if (started is not null)
            {
                await started.WaitAsync(TimeSpan.FromSeconds(10));
                Assert.False(run.IsCompleted);
                Assert.True(budget.ReservedBytes > baseline);
                cancellation.Cancel();
            }
            using var result = await run.WaitAsync(TimeSpan.FromSeconds(10));
            Assert.False(result.Success);
            Assert.Equal(refuse ? LythonFailureReason.SharedMemoryAllowance : LythonFailureReason.Cancelled,
                result.FailureAttribution?.Reason);
        }
        finally
        {
            cancellation.Cancel();
            using var drained = await run.WaitAsync(TimeSpan.FromSeconds(10));
        }
        Assert.Equal("before", host.ReadText("/cleanup"));
        Assert.Equal(baseline, budget.ReservedBytes);
        var fresh = new DelayedLythonHost();
        fresh.SeedFile("/value", "1");
        using (var result = await script.RunAsync(fresh, new LythonRunOptions
            { Globals = new Dictionary<string, object?> { ["fail"] = false } }))
        {
            Assert.True(result.Success, result.Failure?.Message);
            Assert.True(fresh.CompletedAsynchronously > 0);
        }
        Assert.Equal(baseline, budget.ReservedBytes);
    }
}
"""
source=source.replace('DATA',data)
Path('tests/Lokad.Lython.PublicApi.Tests/NativeConditionalHelperTests.cs').write_text(source,encoding='utf8',newline='\n')
print('Independent Python goldens generated for',len(rows),'branch programs; public semantic/real-suspension/ownership checks added.')

