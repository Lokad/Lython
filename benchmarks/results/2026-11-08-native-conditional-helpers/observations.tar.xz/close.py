from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;b=r/'b464'
i=json.loads((r/'identity.json').read_text(encoding='utf8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in i['productionSources'].items())
receipt=json.loads((b/'archive-receipt.json').read_text(encoding='utf8'))
assert receipt['complete']and receipt['jobs']==6 and hashlib.sha256((b/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
vm=json.loads((b/'assessment.json').read_text(encoding='utf8'));local=json.loads((r/'assessment-local.json').read_text(encoding='utf8'))
assert vm['complete']and len(vm['jobs'])==6 and all(len(local[k])==5 for k in ['warm-sync','warm-async','compile-five-sync','fresh-five-sync','compile-confirmation-normal'])
out=Path('benchmarks/results/2026-11-08-native-conditional-helpers');out.mkdir()
(r/'tested-tests').mkdir()
for p in ['tests/Lokad.Lython.Tests/SimpleFunctionExecutionBoundaryTests.cs','tests/Lokad.Lython.PublicApi.Tests/NativeConditionalHelperTests.cs']:shutil.copyfile(p,r/'tested-tests'/Path(p).name)
decision="""Retain R106 one native proof for acyclic return trees, explicit CSV debt.
Remove single-basic-block eligibility and unselected-final-return span assumption.
One existing preparer/guard/evaluator handles conditional/None/empty-sequence nodes;
source indices remain original through physical layout, no duplicated lowering or
new interpreter/control carrier/arena/owner/cache/pool/options. Native entry checks
and old straight-line/local-forwarding/cased kernels preserved. All guards precede
effects, only selected work runs; pure native truth only. Stateful format guard
queries, custom protocols, loops/shared joins retain ordinary executable behavior.
Shared empty-list admission checks cancellation after admission before allocation;
fresh/retained aliases remain funded. Two int metadata fields/node and compile
scratch are explicit tradeoffs, no per-call metadata/working storage added.
205public/42internal peractual11/10 pass. Independent Python outputs, actual
suspended truth/cancellation/refusal/cleanup/budget reuse, fresh aliases and selected
error spans; old native function/stack checks remain. Initial CS0136 name conflict
and Python fixture-generator syntax error preserved/corrected; no runtime failure.
Warm allocation neutral(<0.02%diagnostic differences). Compiler allocation+0.08to
+0.53%, guarded+0.37%. Original unsupported two-case frontend invocation rejected
before collection, preserved; existing five-case driver reused without modification.
Warm not repeated. Desktop async guarded baseline spread22.7%; fresh guarded-60%
diagnostic is not controlled performance evidence.
B464 same frozenaae/67e sourcepair, six jobs168.236s normal settings: guarded sync
elapsed-12.82to-13.48%, coarseCPU-13.51%; async-13.61to-15.93%, CPU-13.24to-14.71%.
Ordinaryrsplit-0.65to+1.52%, CPUflat/slightlylower, nearbaseline/inconclusive.
CSVcompile-1.23to+0.58%, mixedCPU, baseline1.07%/candidate0.75%spread. Original
WindowsCSVcompile+74to+79% not reproduced on quietUbuntu. One bounded changed-order
Windows confirmation: CSV-4.88to-5.98%, but guarded+6.63to+9.62%/JSON+26.76to+31.89%
and other controls variable. Windows compiler timing remains uncertain; original
adverse conditions/cause unresolved. No platform-wide compilation gain claim.
CSVwarm elapsed+2.71to+3.73%, coarseCPU+4.65%, baseline0.66%/candidate0.34%spread:
observed retained regression debt, cause unresolved. Accept for coherent14%text
gain, not a fixed-percentage veto or dismissal as unchanged source. JSON-1.36to
+0.64%/CPU0nearbaseline. Earlier R95/R96/R102/R105 debts remain separate.
All source/core/aux/Ready/golden/quiet/Closed/join/fixture/archive/local gates pass;
B464 terminal/cached, no users/fixtures. Fresh exact-byte hardlinks recovered
27860992B, all original paths/aliases/content/archives retained.240MiBOSfloor+
7MiBevidence+actualpayload preflight. Reuse archivedaae, uploadonly67e.
Commit coherent change; full exact new-source platform/Stress/installed checks at
this boundary. Cached CI42488128858 qualifiesa7, not this candidate. Current CPython
guide stays15c; no per-edit external replay or broader goal closure. Regex/publication
unchanged. Next investigations must name remaining whole work/semantics and stop
without adding machinery when existing source already removes the proposed phase.
"""
(r/'decision.md').write_text(decision,encoding='utf8')
(r/'original-failures.md').write_text('First build: CS0136 local start conflicted with local-function parameter; original build11.log and migrate.py retained, corrected parameter firstInstruction. First public-fixture generator had a Python syntax error before execution; add-public-tests.py retained, corrected generator and independent goldens retained. Original two-case frontend diagnostic rejected by existing five-case driver before collection, compile-sync stderr/catalog/source retained. No runtime semantic test failed.\n',encoding='utf8')
with tarfile.open(out/'observations.tar.xz','w:xz')as a:
 for p in sorted(r.iterdir()):
  if p.name=='images':continue
  if p.name=='tool':
   for n in ['census.csproj','Program.cs']:a.add(p/n,arcname='tool/'+n)
  elif p.name=='b464':
   for child in sorted(p.iterdir()):
    if child.name not in ['retrieved','baseline-core.dll','current-core.dll','payload.tgz']:a.add(child,arcname='b464/'+child.name)
  else:a.add(p,arcname=p.name)
with tarfile.open(out/'observations.tar.xz')as a:assert hashlib.sha256(a.extractfile('b464/observations.tgz').read()).hexdigest()==receipt['archiveSHA256']
for src,name in [(r/'identity.json','identity.json'),(r/'assessment-local.json','allocation-and-local.json'),(b/'assessment.json','controlled-comparison.json')]:shutil.copyfile(src,out/name)
status=dict(status='Retained acyclic native return proof, focused/controlled checks pass; CSV runtime debt and Windows compile uncertainty explicit. Exact new-source full delivery pending.',coreSHA256=i['coreSHA256'],focusedChecks=i['focusedChecks'],archiveSHA256=hashlib.sha256((out/'observations.tar.xz').read_bytes()).hexdigest(),controlledArchiveSHA256=receipt['archiveSHA256'],noRemainingVMUsersOrFixtures=True,referenceGuideSource='15c06863')
(out/'status.json').write_text(json.dumps(status,indent=2)+'\n',encoding='utf8')
readme="""# Native conditional helper returns — 2026-11-08

Retain one existing native-return proof extended to acyclic branch returns.
Remove its single-block restriction and the assumption that the final stored return
is selected. Original source indices survive physical layout; type proofs precede
effects, and only selected Python operations run. Loops/shared joins/custom truth/
data-query format guards keep ordinary executable dispatch. Shared empty-list
construction preserves fresh values, admission, post-admission cancellation and
refunds. Old native expressions/local forwarding/cased kernels remain.

No second lowering/interpreter, control carrier, arena, runtime owner/cache/pool or
public option. Two32-bit immutable metadata fields/node and compiler offset/visited/
per-path scratch are explicit costs. Native combined nesting remains within its
existing proof bound; deeper syntax retains ordinary executable behavior.

Baseline fully qualified a7bd4103/coreaae80cc7 at [cached CI42488128858](../2026-11-08-native-json-construction/delivery-ci.json).
Candidatea7 plus archived five-file patch/core67e76e70, source hashes in identity.
Informational binary revision predates the candidate commit. New-source full
platform/Stress/installed qualification is separate/pending. The primary CPython
guide still names15c; no per-edit external remeasurement.

| Complete script / phase | Controlled elapsed, all four median pairings | Coarse CPU |
| --- | ---: | ---: |
| Guarded text helper, warm sync | −12.82 to −13.48% | −13.51% |
| Guarded text helper, warm async API | −13.61 to −15.93% | −13.24 to −14.71% |
| Ordinary rsplit helper, warm control | −0.65 to +1.52% | flat/slightly lower |
| CSV compilation control | −1.23 to +0.58% | mixed, near baseline |
| CSV warm control | **+2.71 to +3.73%** | **+4.65%** |
| JSON warm control | −1.36 to +0.64% | flat |

Guarded baseline spreads0.51%sync/2.09%async; candidate0.25/0.65%. Short controlled
observations, not confidence intervals or universal gains. CSV runtime regression
has stable baseline0.66%/candidate0.34%spread and remains **accepted debt with
unresolved cause**. Rsplit/JSON are nearbaseline/inconclusive, not causal gains.
Earlier R95/R96/R102/R105 debts are distinct and are not silently repaid.

Warm allocation is neutral(<0.02%diagnostic differences). Compiler allocation
+0.08to+0.53% across the five scripts, guarded+0.37%. Windows desktop elapsed varies:
async guarded old-control spread22.7%, fresh guarded−60% is diagnostic only.
Original Windows CSV compilation+74to+79% was not reproduced on quiet Ubuntu.
One bounded Windows confirmation changed image order: CSV−4.88to−5.98%, but guarded
+6.63to+9.62%, JSON+26.76to+31.89% and other controls vary. **Windows compilation
timing remains uncertain**, and the original adverse cause remains unexplained.
The controlled Linux result does not prove a Windows compiler speedup.

The existing driver rejected an initial two-case frontend catalog before collection.
Original source/catalog/stderr remain. Only compile/fresh were corrected to the
supported five-case catalog; the driver and warm observations were unchanged.
All original runs, adverse controls and confirmation conditions are retained.
Warm local elapsed measures Run only; allocation includes host fixture reset/
validation/cleanup. Compile includes construction/disposal; fresh includes compile,
execution, fixture reset/full validation/disposal. These local clocks differ from
the controlled command boundary and support allocation/diagnostic claims only.

205public/42internal focused Release peractual11/10 pass. Independent isolated
Python goldens cover true/false/nested/implicit returns, missing/unselected work,
changing builtins, formatting, fresh aliases, joins/loops and local forwarding.
Actual truth I/O/cancellation/terminal refusal waits for cleanup, returns the shared
allowance and permits another execution. Four call drivers preserve fresh funding,
post-admission cancellation/refunds, active exceptions and selected error spans.
The frozen-core source diagnostic verifies the maintained guarded helper changes
from ordinary instructions to the native proof. No architecture-only quota tests.

Guarded report:3072lines/35840B, read completely, count words and write full report.
Ordinary rsplit uses the same input; CSV4096records/57361B and JSON4096/110592B.
All unchanged catalog sources/fixtures/full stdout/file goldens are reused exactly.
Quiet Ubuntu24.04.4/AzureF4as_v7,4EPYC9V45vCPUs/16GiB/noswap, actual.NET11RC3,
worker7cf37ca5/optional0.4 unchanged, normalGC/tiering.5swarmup/process/job,
two copies/core,7rotated150msrounds, six jobs168.236s. Warm command-v2 includes
complete execution, mediated RAM I/O/full validation/prior-result cleanup;
compile includes construction/disposal, no guest execution. Compilation/startup/
staging/final cached teardown are outside warm clocks. Actual pending I/O is tested
separately, not timed here; no startup/RSS/embedding-tail claim.

All source/core/aux/Ready/golden/quiet/Closed/exit/join/fixture/archive/local gates
pass. B464 terminal/cached; all workers joined and owned RAM unmounted before archive.
Fresh exact-byte core hardlinks recovered27860992B while preserving every original
path/alias/content/archive; proof retained.240MiBOSfloor+7MiBevidence+actual payload
preflight; archivedaae reused, only67e uploaded. No discarded evidence.

[Controlled results](controlled-comparison.json), [allocation/local/confirmation](allocation-and-local.json),
[identity](identity.json), [status](status.json), [sources/cores/tests/goldens/failures/raw](observations.tar.xz).
"""
(out/'README.md').write_text(readme,encoding='utf8')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf8')+"""
## Native acyclic return trees (2026-11-08)

[R106/B464](results/2026-11-08-native-conditional-helpers/README.md) replaces
single-block native-return selection and final-unselected-return spans with one
existing proof/evaluator for branch returns. Shared empty-list admission; no new
engine/control carrier/arena/runtime owner/cache/options.205public/42internal
peractual11/10 pass, independent Python and actual async truth/cancellation/refusal/
funding/cleanup/selected-span coverage. Warm allocation neutral; compiler allocation
+0.08–0.53%. Controlled guarded elapsed−12.82to−13.48%sync/−13.61to−15.93%async,
coarseCPU agrees. CSVruntime+2.71to+3.73%/CPU+4.65% retained debt, cause unresolved;
rsplit/JSON nearbaseline. Controlled CSVcompile−1.23to+0.58%; original Windows
+74–79% not reproduced on Ubuntu or changed-order Windows confirmation, but other
Windows compiler controls are adverse/variable. Windows compile timing remains
uncertain; all originals/confirmation and rejected two-case driver invocation kept.
Six jobs168.236s, all gates/archive/local verification pass; no users/fixtures.
Exact new-source full delivery pending, a7's green does not qualify this prototype.
No per-edit CPython replay, silent debt repayment or broader objective closure.
"""
p.write_text(s,encoding='utf8')
p=Path('docs/BENCHMARKS.md');s=p.read_text(encoding='utf8');needle='| Native JSON constructor/call transport / normalization |';a=s.index(needle)
s=s[:a]+'| Native acyclic helper returns / guarded text | Allocation neutral; controlled elapsed −13–16% across both APIs, coarse CPU agrees | One return proof; CSVruntime +3% retained debt, Windows compilation uncertain. Full new-source qualification pending. [R106](../benchmarks/results/2026-11-08-native-conditional-helpers/README.md) |\n'+s[a:];p.write_text(s,encoding='utf8')
p=Path('PLAN.md');s=p.read_text(encoding='utf8');a=s.index('1. **R106');z=s.index('2. **R104',a)
s=s[:a]+"""1. **Commit/qualify retained R106.** Core67e76e70, one native return-tree proof
   replaces single-block eligibility/final-unselected-return spans. Shared empty-list
   admission/selected work, old native paths and genuine custom async behavior kept.
   205public/42internal peractual11/10 pass. B464168.236s, all gates/archive/local
   verified; no users/fixtures. Guarded elapsed−13–16%bothAPIs/coarseCPU agrees,
   allocation neutral, compiler allocation+0.08–0.53%. CSVruntime+2.71to+3.73%/
   CPU+4.65% retained observed debt, cause unresolved. Rsplit/JSON nearbaseline.
   Quiet Ubuntu CSVcompile−1.23to+0.58%; original Windows+74–79% not reproduced in
   changed-order Windows confirmation, but new compiler controls adverse/variable.
   Windows compile timing remains uncertain; keep all failed/initial/confirmation
   conditions. No universal compiler gain or old-debt repayment. Commit coherent
   source and dispatch exact new-source full Windows/Ubuntu actual11/10/original
   Stress/installed core qualification once; a7's cached green is independent.
   Continue the remaining source/whole-phase roadmap while CI runs; this isolated
   milestone does not complete the broader performance objective.

"""+s[z:]
s=s.replace('B464 is the only active VM collection;\nobserve after15:05:51UTC, join/unmount/archive and verify before closing.','B464 terminal/archived/locally verified; no active VM users/fixtures.')
p.write_text(s,encoding='utf8')
print('R106 retained, all original/confirmation evidence archived, CSV debt/Windows uncertainty explicit. Archive',status['archiveSHA256'])

