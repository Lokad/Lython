from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).parent
files=['src/Lokad.Lython/Frontend/ExecutableScript.NativeReturns.cs','src/Lokad.Lython/Frontend/ExecutableNativeBody.cs','src/Lokad.Lython/Frontend/ExecutableScript.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeReturn.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.Operations.cs']
(r/'before').mkdir()
for p in files:shutil.copyfile(p,r/'before'/Path(p).name)
(r/'baseline.json').write_text(json.dumps(dict(sourceRevision='a7bd4103',sourceSHA256={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in files},coreSHA256='aae80cc7335167ab87d17559d49de0dad0690a7faa9022134ce0aecfc3a4a9c2',qualification='Full CI42488128858 active independently; focused/controlled R105 green.'),indent=2)+'\n',encoding='utf8')
proposal="""R106 source gate selects one existing native-return proof for acyclic return trees.
Actual maintained helper tests line.isspace(), returns fresh[] on true, otherwise
lower().split(). Frozen-core diagnostic confirms nativeBody=False and conditional/
MakeList/Return instructions. Current guarded1.98–2.02x versus unguardedrsplit
1.59–1.61xCPython selects investigation; these scripts do not isolate dispatch cost.

Replace single-block preparation with one walk of the existing normalized block
instructions. Keep old native expression operators/guards/cased kernel. Track
compile-only original offsets/visited positions; require balanced branch inputs,
terminal return trees and existing combined depth16 eligibility. Cycles/shared
joins/unsupported shapes retain ordinary executable code before any work. Preserve
old straight-line local forwarding and all existing native paths; no second parser,
control carrier/arena/dispatch engine or per-call scratch/metadata arrays.

Add conditional and empty-sequence native expression nodes. Existing guarded truth
can execute only proven native values; custom truth stays on ordinary engine.
Guard all eligible branches before effects, but execute only selected operations.
Format proofs that query container values cannot be speculated across a branch;
reject those native proofs, preserving their existing straight-line support.
Source mappings include selected return instruction; do not use an unselected final
return's span. Share the existing empty-list admission/construction between general
and native execution, with post-admission cancellation before allocation. Empty
tuple remains shared; lists remain fresh/retained aliases funded.

Expected removals: blocks.Count!=1/straight-line-only selection, single final-return
span assumption and duplicated empty-list construction branch. Extra compiler
offset/visited/per-path stack scratch and8B/node of immutable control/exit metadata
are explicit costs; no new runtime lifetime fields/pool/cache/options/owners.
Runtime avoids general per-instruction work/argument workspace for eligible
guarded helpers. No speedup predicted until whole-script source-pair comparison.

Semantic acceptance: true/false/nested/if-else/implicit None, unselected missing
names/errors/formatting/storage, changing builtins/admission reentry, custom truth
and method protocols with actual async I/O, fresh/escaping lists, exact selected
operation/return spans, first refusal/cancellation/cleanup/shared allowance reuse,
managed stack and old unconditional native helper behavior. Public Python golden
cases plus focused native/cased/conditional ownership checks peractual11/10.

Implementation bound~30min before focused validation/refinement. Stop/refine rather
than add a framework if original instruction mappings, guard purity or rollback
need a larger rewrite. One short existing-driver allocation diagnostic then one
six-job source pair on quiet VM: complete guarded text both APIs, ordinaryrsplit,
ordinarysplit, CSV and JSON controls. Independently preserved full goldens. Include
one short compilation/compile-to-result diagnostic for added compiler metadata.
Keep all adverse originals; retain/correct/reject debt explicitly. Full new-source
platform/Stress/installed checks at retained boundary; R105 qualification independent.
Regex/publication unchanged. No per-edit external CPython replay.
"""
(r/'proposal.md').write_text(proposal,encoding='utf8')
p=Path('PLAN.md');s=p.read_text(encoding='utf8');a=s.index('2. **R106');z=s.index('3. **R104',a)
s=s[:a]+'2. **R106 selected: native acyclic return trees.**\n'+''.join('   '+line+'\n'for line in proposal.splitlines())+'\n'+s[z:]
p.write_text(s,encoding='utf8')
print('R106 source gate closed; concrete replacement, tradeoffs and focused/controlled acceptance recorded before editing.')

