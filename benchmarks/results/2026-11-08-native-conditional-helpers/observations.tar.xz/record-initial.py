from pathlib import Path
import hashlib,json
r=Path(__file__).parent
catalog=json.loads((r.parent/'json-cpython-r103/representative.json').read_text(encoding='utf8'))
case=next(c for c in catalog['cases']if c['id']=='scripts.text-summary-guarded-helpers.large')
paths=['src/Lokad.Lython/Frontend/ExecutableScript.NativeReturns.cs','src/Lokad.Lython/Frontend/ExecutableScript.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeReturn.cs']
record=dict(sourceRevision='a7bd4103',sources={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in paths},workloadSource=case['source'],workloadSourceSHA256=case['sourceSha256'],findings=[
'Actual maintained guard is line.isspace(), then fresh empty-list return, otherwise lower().split(). It does not call strip(). Extra native predicate work and generic function/control cost are not separated by the external ratio.',
'Native-body eligibility explicitly requires one reachable basic block. The guarded helper therefore cannot use that proof. No speedup follows solely from this source fact.',
'Native proof runs before operand forwarding, physical-slot preparation and instruction linearization. Its original instruction indices must survive any CFG extension; ordinary executable behavior and existing straight-line native optimizations must remain.',
'Existing guard-before-effects and managed call policy remain required. Conditional support must not evaluate unselected Python operations, restart after effects, lose fresh-result ownership or introduce another control carrier/engine.'
],status='Initial source gate only; no compiler prototype selected or implemented. Continue bounded design proof before editing.')
(r/'source-gate.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
p=Path('PLAN.md');s=p.read_text(encoding='utf8');needle='   Source/design bound~15min.'
s=s.replace(needle,'   Initial source inspection confirms line.isspace()/fresh[]/lower().split(),\n   not strip(). Native proof runs before forwarding/physical layout/linearization;\n   preserve original instruction indices and ordinary code when extending CFGs.\n'+needle)
s=s.replace('first observation after14:10UTC','first observation after14:11:12UTC')
p.write_text(s,encoding='utf8')
print('R106 initial source facts recorded; no compiler prototype or speedup selected.')

