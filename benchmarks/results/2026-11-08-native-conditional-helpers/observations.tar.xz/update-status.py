from pathlib import Path
import json
out=Path('benchmarks/results/2026-11-08-native-json-construction')
p=out/'allocation-and-local.json';d=json.loads(p.read_text(encoding='utf8'));d['limitations']='R105 same-process ALC allocation diagnostic, normal GC/tiering. Warm elapsed is Run phase only; allocation includes full host fixture reset/validation/result cleanup. Shared native JSON initialization/direct bound argument and value calls remove constructor/forwarding transport. Desktop elapsed/coarseCPU are not controlled CPU evidence. Preserve every adverse/unstable control; all focused checks passed on the first implementation. Original archived limitation label inherited R102 wording; this derived interpretation corrects that label without changing numeric observations.'
p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf8')
p=out/'README.md';s=p.read_text(encoding='utf8')+'\nThe derived allocation assessment corrects an inherited R102 limitation label;\noriginal archived labels/data remain intact and numeric observations are unchanged.\n';p.write_text(s,encoding='utf8')
p=Path('PLAN.md');s=p.read_text(encoding='utf8');a=s.index('1. **R106 active');z=s.index('2. **R104',a)
s=s[:a]+"""1. **R106 active prototype: native acyclic return trees.**
   Five-file source/core67e76e70 replaces single-block selection with one walk of
   normalized branch returns in the existing native proof/evaluator. Old native
   expression/local forwarding/cased kernels remain. Loops/shared joins/custom
   truth/data-query format guards retain ordinary execution before any work.
   Guard eligible branches before effects, execute only selected work; selected
   return spans and shared empty-list post-admission cancellation/refund preserved.
   Extra compiler offsets/visited/per-path scratch and two32-bit/node metadata
   fields are explicit tradeoffs; no new runtime owners/caches/arenas/backends/options.

   205public/42internal peractual11/10 pass. Independent Python true/false/nested/
   implicit returns, missing/unselected work, changing builtins, fresh aliases,
   real truth suspension/cancellation/terminal refusal/cleanup/budget reuse and
   selected error spans covered. Original compile-name conflict/test-generator
   syntax error retained with corrected source, not runtime design failures.

   Warm allocation neutral; desktop elapsed mixed/adverse with22.7%async guarded
   baseline drift. CSV compilation+74–79% with2.57%baseline spread is material.
   Original two-case frontend driver invocation rejected before collection; preserve
   it and corrected five-case compile/fresh diagnostic, no driver/framework change.
   B464 controlled pair running: guarded bothAPIs, ordinaryrsplit, CSVcompile/
   CSVwarm and JSONwarm. CSVcompile replaces one redundant text control to resolve
   that adverse gap in the same bounded run.210sowner+30stop+30margin, observe only
   after15:05:51UTC. All source/core/aux/Ready/golden/quiet/Closed/join/fixture/archive/
   local gates required before retain/refine/reject. Keep all original adverse
   evidence, including fresh guarded-60%diagnostic; no normal CPU claim from it.
   Shared original paths/aliases/bytes/archives preserved under fresh exact-byte
   hardlink maintenance; proof accompanies collection. No full CPython refresh.
   Decide remaining compile/runtime debt explicitly, then commit/qualify coherent
   source at a retained boundary and continue the broader roadmap. R105's green
   qualification does not qualify this prototype. No fixed%veto or permanent
   one-attempt rejection; refinement requires evidence and its own stopping point.

"""+s[z:]
s=s.replace('B463 terminal/archived/locally verified; no active users/fixtures.','B463 terminal/archived/locally verified. B464 is the only active VM collection;\nobserve after15:05:51UTC, join/unmount/archive and verify before closing.')
p.write_text(s,encoding='utf8')
print('Current plan condensed; R106 uncertainty active, R105 qualification/interpretation labels corrected.')

