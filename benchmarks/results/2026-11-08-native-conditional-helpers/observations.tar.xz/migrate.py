from pathlib import Path
r=Path(__file__).parent
p=Path('src/Lokad.Lython/Frontend/ExecutableScript.NativeReturns.cs')
old=p.read_text(encoding='utf8')
a=old.index('                case ExecutableOpCode.LoadLocal:')
z=old.index('                default:\n                    return null;',a)
cases=old[a:z]
cases=cases.replace('index + 1 >= instructions.Length - 1','index + 1 >= instructions.Length')
cases=cases.replace('                    index++;\n                    continue;','                    index++;\n                    if (visited[offsets[block] + index]) return null;\n                    visited[offsets[block] + index] = true;\n                    continue;')
cases=cases.replace('stack[^1] = (stack[^1].Value, index, stack[^1].Depth);','stack[^1] = (stack[^1].Value, sourceIndex, stack[^1].Depth, instruction.NameIndex);')
cases=cases.replace('Names[instructions[target.Member].NameIndex]','Names[target.MemberName]')
cases=cases.replace('target.Member == index - 1','target.Member == sourceIndex - 1')
cases=cases.replace('producer.SourceInstruction == producer.Second + 1','producer.SourceInstruction >= offsets[block]\n                                    && producer.SourceInstruction == producer.Second + 1')
cases=cases.replace('PrepareCasedSplit(instructions, producer.SourceInstruction, index, sites)','PrepareCasedSplit(instructions, producer.SourceInstruction - offsets[block], index, sites)')
needle='                    first = stack[^1].Value;\n                    depth = 1 + stack[^1].Depth;'
assert cases.count(needle)==1
cases=cases.replace(needle,needle+"""
                    // Actual dictionary-value queries are not speculated on
                    // an unselected branch. Straight-line proofs retain them.
                    var formattedInput = first;
                    while (values[formattedInput].Operation is NativeReturnOperation.ConvertFormat or NativeReturnOperation.FormatValue)
                        formattedInput = values[formattedInput].First;
                    if (values[formattedInput].Operation == NativeReturnOperation.Subscript) readsFormatStorage = true;""")
header="""using Lokad.Lython.Runtime;

namespace Lokad.Lython.Frontend;

internal sealed partial class ExecutableCodeObject
{
    private ExecutableNativeBody? PrepareNativeBody(IReadOnlyList<ExecutableBasicBlock> blocks,
        int entryBlock, int exceptionRegionCount, ExecutableCallSite[] sites)
    {
        if (!IsFunctionScope || RequiresLocalVariableMirroring || CapturedLocalSlots.Count != 0
            || ClosureNames.Count != 0 || exceptionRegionCount != 0)
            return null;
        if (blocks.Count == 1 && blocks[0].InstructionArray is [{ OpCode: ExecutableOpCode.ReturnNone }])
            return ExecutableNativeBody.ReturnNone;

        // These blocks need no synthetic Complete instruction. Native proofs
        // keep the original sequence, so these offsets also match linearization.
        var offsets = new int[blocks.Count + 1];
        for (var block = 0; block < blocks.Count; block++)
        {
            var instructions = blocks[block].InstructionArray;
            if (instructions.Length == 0 || instructions[^1].OpCode is not
                (ExecutableOpCode.Jump or ExecutableOpCode.Return or ExecutableOpCode.ReturnNone))
                return null;
            offsets[block + 1] = checked(offsets[block] + instructions.Length);
        }
        var visited = new bool[offsets[^1]];
        var values = new List<NativeReturnValue>();
        var hasConditional = false;
        var readsFormatStorage = false;
        var proof = Compile(entryBlock, 0, false, null, 0);
        if (proof is null || hasConditional && readsFormatStorage) return null;
        return new(values.ToArray(), proof.Value.Root);

        (int Root, int Depth)? Compile(int block, int start, bool hasEffects,
            HashSet<int>? forwardedLocals, int controlDepth)
        {
            // Compile/evaluate within the existing native recursion admission.
            // Other control flow keeps ordinary executable code, before effects.
            if (controlDepth > 16) return null;
            var stack = new List<(int Value, int Member, int Depth, int MemberName)>();
            var instructions = blocks[block].InstructionArray;
            for (var index = start; index < instructions.Length; index++)
            {
                var sourceIndex = offsets[block] + index;
                if (visited[sourceIndex]) return null; // cycles or shared joins
                visited[sourceIndex] = true;
                var instruction = instructions[index];
                var operation = NativeReturnOperation.Read;
                LythonRuntime.ReceiverMethod? nativeMethod = null;
                var first = -1;
                var second = -1;
                var depth = 1;
                switch (instruction.OpCode)
                {
                    case ExecutableOpCode.Jump:
                        block = instruction.TargetIndex;
                        instructions = blocks[block].InstructionArray;
                        index = -1;
                        continue;
                    case ExecutableOpCode.JumpIfFalse:
                        if (stack.Count != 1 || stack[0].Member >= 0) return null;
                        hasConditional = true;
                        var condition = stack[0];
                        var consequent = Compile(block, index + 1, hasEffects,
                            forwardedLocals is null ? null : new(forwardedLocals), controlDepth + 1);
                        var alternative = Compile(instruction.TargetIndex, 0, hasEffects,
                            forwardedLocals, controlDepth + 1);
                        if (consequent is null || alternative is null) return null;
                        var conditionalDepth = 1 + Math.Max(condition.Depth,
                            Math.Max(consequent.Value.Depth, alternative.Value.Depth));
                        if (conditionalDepth > 16) return null;
                        values.Add(new(NativeReturnOperation.Conditional, sourceIndex, condition.Value,
                            consequent.Value.Root, Third: alternative.Value.Root));
                        return (values.Count - 1, conditionalDepth);
                    case ExecutableOpCode.Return:
                        if (stack.Count != 1 || stack[0].Member >= 0) return null;
                        var root = stack[0];
                        values[root.Value] = values[root.Value] with { ReturnInstruction = sourceIndex };
                        return (root.Value, root.Depth);
                    case ExecutableOpCode.ReturnNone:
                        if (stack.Count != 0) return null;
                        values.Add(new(NativeReturnOperation.None, sourceIndex, -1, -1,
                            ReturnInstruction: sourceIndex));
                        return (values.Count - 1, 1);
                    case ExecutableOpCode.MakeList or ExecutableOpCode.MakeTuple when instruction.ItemCount == 0:
                        operation = NativeReturnOperation.EmptySequence;
                        break;
"""
footer="""                    default:
                        return null;
                }
                // Eligibility bound, never a guest syntax/nesting limit.
                if (depth > 16) return null;
                if (operation is not (NativeReturnOperation.Read or NativeReturnOperation.Subscript)) hasEffects = true;
                values.Add(new(operation, sourceIndex, first, second, nativeMethod));
                stack.Add((values.Count - 1, -1, depth, -1));
            }
            return null;
        }
    }
}
"""
p.write_text(header+''.join('    '+line+'\n'for line in cases.splitlines())+footer,encoding='utf8',newline='\n')
p=Path('src/Lokad.Lython/Frontend/ExecutableNativeBody.cs');s=p.read_text(encoding='utf8').replace('    ConvertFormat, FormatValue,','    ConvertFormat, FormatValue,\n    Conditional, None, EmptySequence,')
s=s.replace('LythonRuntime.ReceiverMethod? Method = null);','LythonRuntime.ReceiverMethod? Method = null, int Third = -1, int ReturnInstruction = -1);')
p.write_text(s,encoding='utf8',newline='\n')
p=Path('src/Lokad.Lython/Frontend/ExecutableScript.cs');s=p.read_text(encoding='utf8');assert s.count('PrepareNativeBody(blocks, exceptionRegions.Count, callSites)')==1
s=s.replace('PrepareNativeBody(blocks, exceptionRegions.Count, callSites)','PrepareNativeBody(blocks, entryBlockIndex, exceptionRegions.Count, callSites)')
p.write_text(s,encoding='utf8',newline='\n')
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeReturn.cs');s=p.read_text(encoding='utf8')
s=s.replace('                context.State.CheckExecution(code.Instructions[^1].Span);','                CheckNativeReturnExit(body.Root, code, body.Values, context);')
needle='    private enum NativeReturnShape'
a=s.index(needle)
s=s[:a]+"""    private static void CheckNativeReturnExit(int root, ExecutableCodeObject code,
        NativeReturnValue[] values, ExecutionContext context)
    {
        var exit = values[root].ReturnInstruction;
        if (exit >= 0) context.State.CheckExecution(code.Instructions[exit].Span);
    }

"""+s[a:]
needle='            case NativeReturnOperation.Read:\n'
a=s.index(needle)
s=s[:a]+"""            case NativeReturnOperation.None:
                shape = NativeReturnShape.None;
                return true;
            case NativeReturnOperation.EmptySequence:
                shape = NativeReturnShape.Sized;
                return true;
            case NativeReturnOperation.Conditional:
                if (!GuardNativeReturn(value.First, code, values, arguments, context, out var condition)
                    || condition == NativeReturnShape.Other
                    || !GuardNativeReturn(value.Second, code, values, arguments, context, out var consequent)
                    || !GuardNativeReturn(value.Third, code, values, arguments, context, out var alternative))
                    return false;
                shape = consequent == alternative ? consequent : NativeReturnShape.Other;
                return true;
"""+s[a:]
needle='        object? first = null, second = null, third = null, fourth = null;'
a=s.index(needle)
s=s[:a]+"""        if (value.Operation == NativeReturnOperation.Conditional)
        {
            var condition = EvaluateNativeReturn(value.First, code, values, arguments, context, entryException);
            context.State.CheckExecution(instruction.Span);
            var selected = PyTruthiness.IsTruthy(condition) ? value.Second : value.Third;
            var result = EvaluateNativeReturn(selected, code, values, arguments, context, entryException);
            CheckNativeReturnExit(selected, code, values, context);
            return result;
        }
"""+s[a:]
s=s.replace('        if (value.Operation != NativeReturnOperation.Read)','        if (value.Operation is not (NativeReturnOperation.Read or NativeReturnOperation.None or NativeReturnOperation.EmptySequence))')
needle='                case NativeReturnOperation.Read:\n'
a=s.index(needle,s.index('private static object EvaluateNativeReturn'))
s=s[:a]+"""                case NativeReturnOperation.None:
                    return PyNone.Instance;
                case NativeReturnOperation.EmptySequence:
                    return instruction.OpCode == ExecutableOpCode.MakeTuple ? PyTuple.Empty
                        : CreateEmptyList(instruction.Span, context);
"""+s[a:]
p.write_text(s,encoding='utf8',newline='\n')
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.Operations.cs');s=p.read_text(encoding='utf8')
a=s.index('    private static PyList CreateListFromStack(')
s=s[:a]+"""    private static PyList CreateEmptyList(LythonSourceSpan span, ExecutionContext context)
    {
        var bytes = PyList.EstimateCapacityBytes(0);
        using var storage = context.MemoryGovernor.ReserveTemporary(bytes, span);
        context.CheckExecution(span);
        storage.Commit(bytes);
        return PyList.FromTransferredArray(Array.Empty<object>(), context.MemoryGovernor, span);
    }

"""+s[a:]
needle='''    {
        var bytes = PyList.EstimateCapacityBytes(count);'''
assert s.count(needle)==1
s=s.replace(needle,'''    {
        if (count == 0)
        {
            var result = CreateEmptyList(span, context);
            stack.RetireTo(start);
            return result;
        }
        var bytes = PyList.EstimateCapacityBytes(count);''')
s=s.replace('var items = count == 0 ? Array.Empty<object>() : new object[count];','var items = new object[count];')
p.write_text(s,encoding='utf8',newline='\n')
print('R106 one return-tree preparer, existing native guards/evaluator extended; shared empty-list admission, selected exit spans.')

