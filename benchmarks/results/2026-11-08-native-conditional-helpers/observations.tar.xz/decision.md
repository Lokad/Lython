Retain R106 one native proof for acyclic return trees, explicit CSV debt.
Remove single-basic-block eligibility and unselected-final-return span assumption.
One existing preparer/guard/evaluator handles conditional/None/empty-sequence nodes;
source indices remain original through physical layout, no duplicated lowering or
new interpreter/control carrier/arena/owner/cache/pool/options. Native entry checks
and old straight-line/local-forwarding/cased kernels preserved. All guards precede
effects, only selected work runs; pure native truth only. Stateful format guard
queries, custom protocols, loops/shared joins retain ordinary executable behavior.
Shared empty-list admission checks cancellation after admission before allocation;
fresh/retained aliases remain funded. Two int metadata fields/node and compile
scratch are explicit tradeoffs, no per-call metadata/working storage added.
205public/42internal peractual11/10 pass. Independent Python outputs, actual
suspended truth/cancellation/refusal/cleanup/budget reuse, fresh aliases and selected
error spans; old native function/stack checks remain. Initial CS0136 name conflict
and Python fixture-generator syntax error preserved/corrected; no runtime failure.
Warm allocation neutral(<0.02%diagnostic differences). Compiler allocation+0.08to
+0.53%, guarded+0.37%. Original unsupported two-case frontend invocation rejected
before collection, preserved; existing five-case driver reused without modification.
Warm not repeated. Desktop async guarded baseline spread22.7%; fresh guarded-60%
diagnostic is not controlled performance evidence.
B464 same frozenaae/67e sourcepair, six jobs168.236s normal settings: guarded sync
elapsed-12.82to-13.48%, coarseCPU-13.51%; async-13.61to-15.93%, CPU-13.24to-14.71%.
Ordinaryrsplit-0.65to+1.52%, CPUflat/slightlylower, nearbaseline/inconclusive.
CSVcompile-1.23to+0.58%, mixedCPU, baseline1.07%/candidate0.75%spread. Original
WindowsCSVcompile+74to+79% not reproduced on quietUbuntu. One bounded changed-order
Windows confirmation: CSV-4.88to-5.98%, but guarded+6.63to+9.62%/JSON+26.76to+31.89%
and other controls variable. Windows compiler timing remains uncertain; original
adverse conditions/cause unresolved. No platform-wide compilation gain claim.
CSVwarm elapsed+2.71to+3.73%, coarseCPU+4.65%, baseline0.66%/candidate0.34%spread:
observed retained regression debt, cause unresolved. Accept for coherent14%text
gain, not a fixed-percentage veto or dismissal as unchanged source. JSON-1.36to
+0.64%/CPU0nearbaseline. Earlier R95/R96/R102/R105 debts remain separate.
All source/core/aux/Ready/golden/quiet/Closed/join/fixture/archive/local gates pass;
B464 terminal/cached, no users/fixtures. Fresh exact-byte hardlinks recovered
27860992B, all original paths/aliases/content/archives retained.240MiBOSfloor+
7MiBevidence+actualpayload preflight. Reuse archivedaae, uploadonly67e.
Commit coherent change; full exact new-source platform/Stress/installed checks at
this boundary. Cached CI42488128858 qualifiesa7, not this candidate. Current CPython
guide stays15c; no per-edit external replay or broader goal closure. Regex/publication
unchanged. Next investigations must name remaining whole work/semantics and stop
without adding machinery when existing source already removes the proposed phase.
