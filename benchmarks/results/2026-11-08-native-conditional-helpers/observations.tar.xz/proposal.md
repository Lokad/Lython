R106 source gate selects one existing native-return proof for acyclic return trees.
Actual maintained helper tests line.isspace(), returns fresh[] on true, otherwise
lower().split(). Frozen-core diagnostic confirms nativeBody=False and conditional/
MakeList/Return instructions. Current guarded1.98–2.02x versus unguardedrsplit
1.59–1.61xCPython selects investigation; these scripts do not isolate dispatch cost.

Replace single-block preparation with one walk of the existing normalized block
instructions. Keep old native expression operators/guards/cased kernel. Track
compile-only original offsets/visited positions; require balanced branch inputs,
terminal return trees and existing combined depth16 eligibility. Cycles/shared
joins/unsupported shapes retain ordinary executable code before any work. Preserve
old straight-line local forwarding and all existing native paths; no second parser,
control carrier/arena/dispatch engine or per-call scratch/metadata arrays.

Add conditional and empty-sequence native expression nodes. Existing guarded truth
can execute only proven native values; custom truth stays on ordinary engine.
Guard all eligible branches before effects, but execute only selected operations.
Format proofs that query container values cannot be speculated across a branch;
reject those native proofs, preserving their existing straight-line support.
Source mappings include selected return instruction; do not use an unselected final
return's span. Share the existing empty-list admission/construction between general
and native execution, with post-admission cancellation before allocation. Empty
tuple remains shared; lists remain fresh/retained aliases funded.

Expected removals: blocks.Count!=1/straight-line-only selection, single final-return
span assumption and duplicated empty-list construction branch. Extra compiler
offset/visited/per-path stack scratch and8B/node of immutable control/exit metadata
are explicit costs; no new runtime lifetime fields/pool/cache/options/owners.
Runtime avoids general per-instruction work/argument workspace for eligible
guarded helpers. No speedup predicted until whole-script source-pair comparison.

Semantic acceptance: true/false/nested/if-else/implicit None, unselected missing
names/errors/formatting/storage, changing builtins/admission reentry, custom truth
and method protocols with actual async I/O, fresh/escaping lists, exact selected
operation/return spans, first refusal/cancellation/cleanup/shared allowance reuse,
managed stack and old unconditional native helper behavior. Public Python golden
cases plus focused native/cased/conditional ownership checks peractual11/10.

Implementation bound~30min before focused validation/refinement. Stop/refine rather
than add a framework if original instruction mappings, guard purity or rollback
need a larger rewrite. One short existing-driver allocation diagnostic then one
six-job source pair on quiet VM: complete guarded text both APIs, ordinaryrsplit,
ordinarysplit, CSV and JSON controls. Independently preserved full goldens. Include
one short compilation/compile-to-result diagnostic for added compiler metadata.
Keep all adverse originals; retain/correct/reject debt explicitly. Full new-source
platform/Stress/installed checks at retained boundary; R105 qualification independent.
Regex/publication unchanged. No per-edit external CPython replay.
