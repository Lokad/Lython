from pathlib import Path
import ast,json,shutil,tarfile
r=Path(__file__).parent;old=r.parent/'native-json-construction-r105/b463';b=r/'b464';b.mkdir()
source=json.loads((r/'identity.json').read_text(encoding='utf8'));prior=json.loads((old/'identity.json').read_text(encoding='utf8'))
jobs=[['scripts.text-summary-guarded-helpers.large','warm'],['scripts.text-summary-guarded-helpers.large','warm-async'],['scripts.text-summary-rsplit-helpers.large','warm'],['scripts.csv-summary-functions.large','compile'],['scripts.csv-summary-functions.large','warm'],['scripts.json-summary-helpers.large','warm']]
identity={**prior,'sourceRevision':source['candidateSource'],'baselineSource':source['baselineSource'],'coreSHA256':{role:source['coreSHA256']['before'if role.startswith('reference')else'candidate']for role in ['reference','reference-control','candidate','candidate-control']},'productionSources':source['productionSources'],'qualification':source['qualification'],'jobs':jobs}
(b/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf8')
for name in ['collect.py','run.sh','retrieve.py','assess-vm.py','archive-owned.py','launch.py']:
 s=(old/name).read_text(encoding='utf8').replace('native-json-b463-20261108','conditional-helpers-b464-20261108').replace('lython-b463-native-json','lython-b464-conditional-helpers').replace('native-json-b463-launch.py','conditional-helpers-b464-launch.py').replace('lython-b463-fixtures','lython-b464-fixtures')
 if name=='collect.py':
  a=s.index('jobs=');z=s.index('\nassert len(jobs)',a);s=s[:a]+'jobs='+repr(jobs)+s[z:]
  a=s.index("purpose='");z=s.index("',\n",a);s=s[:a]+"purpose='R106 native acyclic return-tree proof, shared empty-sequence admission and selected exit spans; complete guarded text both APIs, ordinary rsplit/CSV/JSON controls, material adverse CSV compilation confirmation"+s[z:]
 if name=='launch.py':s=s.replace("reference=base/'completed-json-b461-20261108/candidate'","reference=base/'native-json-b463-20261108/candidate'")
 if name=='archive-owned.py':
  needle="'shared-worker-common.json']";assert needle in s;s=s.replace(needle,"'shared-worker-common.json','space-maintenance.json']")
 (b/name).write_text(s,encoding='utf8',newline='\n')
 if name.endswith('.py'):ast.parse(s)
for src,name in [(r/'images/candidate/Lokad.Lython.dll','current-core.dll'),(r/'catalog.json','representative.json'),(r/'identity.json','focused.json'),(r/'source.patch','source.patch'),(r/'pre-measurement-plan.md','pre-measurement-plan.md'),(old/'shared-worker-common.json','shared-worker-common.json'),(old/'setup-contract.json','setup-contract.json'),(r/'dedup-proof.json','space-maintenance.json')]:shutil.copyfile(src,b/name)
contract="""R106 one six-job controlled sourcepairaae/67e, unchanged worker/normalGC/tiering.
One existing native-return proof extends to acyclic branch returns; remove
single-block selection/final-unselected-return-span assumption. Shared empty
sequence construction preserves fresh list admission/cancellation/refund.
Guard all eligible native branches before effects, execute only selected branch.
Loops/joins/custom truth/data-query format guards retain ordinary executable path.
No new runtime state/cache/pool/arena/backend/options/owners. Two int metadata
fields/node and compiler scratch are measured tradeoffs.
205public/42internal peractual11/10 pass; independent Python full outputs,
real truth I/O/cancellation/refusal/cleanup, fresh aliases and selected error spans.
Warm allocation neutral in all five local complete scripts. Desktop elapsed is
mixed/adverse, async guarded baseline spread22.7%; no controlled gain inferred.
CSV compile diagnostic+74.34to+78.81% with2.57%baseline spread is a material adverse
gap. Include CSVcompile as fourth job, replacing ordinary-split warm control.
Keep ordinary-rsplit/CSVwarm/JSONwarm controls. Fresh guarded-60%diagnostic is not
a normal-settings gain claim. Original rejected two-case frontend invocation and
supported five-case correction retained; no driver/framework changed/replayedwarm.
Two processes/core,5swarmup/role/job,7rotated150msrounds, coarse process CPU.
210sowner+30stop+30margin. Mediated guest RAM I/O/full validation/prior cleanup
included in warm; compile includes construction/disposal, no guest execution.
Compilation/startup/staging/final cached teardown excluded from warm. Actual
suspension tested independently; no startup/RSS/embedding tail claim.
Reuse archivedB463 baselineaae, uploadonly67e.240MiBOSfloor+7MiBevidence+actual
payload preflight; fresh exact-byte hardlinks preserve all original paths/aliases/
bytes and archives, proof included. All source/core/aux/Ready/golden/quiet/Closed/
join/fixture/archive/local gates. Old CI42488128858 qualifies onlya7, not thissource.
Retain all adverse/control evidence, no fixed%veto or blind retiming. Publication/
regex0.4 unchanged, no per-edit external CPython refresh or objective closure.
"""
(b/'contract.md').write_text(contract,encoding='utf8')
with tarfile.open(b/'payload.tgz','w:gz')as a:
 for n in ['collect.py','run.sh','current-core.dll','representative.json','identity.json','pre-measurement-plan.md','setup-contract.json','contract.md','focused.json','source.patch','shared-worker-common.json','archive-owned.py','space-maintenance.json']:a.add(b/n,arcname=n)
p=Path('PLAN.md');s=p.read_text(encoding='utf8').replace('exact frozen comparison next, no timing claim.','local warm allocation neutral; desktop timing variable/adverse. CSV compilation\n   diagnostic+74–79% is material: controlled B464 replaces ordinary-split warm\n   control with CSVcompile, retaining guarded bothAPIs/ordinaryrsplit/CSVwarm/JSON.\n   Original rejected two-case frontend invocation/five-case correction preserved.\n   B464 controlled pair running; observe only after guarded deadline in its request.')
p.write_text(s,encoding='utf8')
print('B464 prepared: one pair, guarded both APIs and controlled CSV compile correction.')

