using System.Reflection;
using System.Collections;
var assembly = Assembly.LoadFrom(Path.GetFullPath(args[0]));
var source = "def words(line:str)->list:\n if line.isspace():return []\n return line.lower().split()\n";
var method = assembly.GetType("Lokad.Lython.Frontend.LythonFrontend")!.GetMethod("Compile",BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic)!;
var parameters = method.GetParameters();
var supplied = parameters.Select(p => p.Position == 0 ? (object)source : p.ParameterType.IsValueType ? Activator.CreateInstance(p.ParameterType) : null).ToArray();
object Property(object instance,string name) => instance.GetType().GetProperty(name,BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic)!.GetValue(instance)!;
var result = method.Invoke(null,supplied)!;
foreach(var diagnostic in (IEnumerable)Property(result,"Diagnostics")) Console.WriteLine("Diagnostic: "+diagnostic);
var syntax = Property(result,"Script");
var lowered = assembly.GetType("Lokad.Lython.Frontend.LoweredScript")!.GetMethod("Lower")!.Invoke(null,[syntax])!;
var executable = assembly.GetType("Lokad.Lython.Frontend.ExecutableScript")!.GetMethod("Compile")!.Invoke(null,[lowered])!;
var module = Property(executable,"EntryPoint");
foreach(var binding in (IEnumerable)Property(module,"Functions")) {
 var code=Property(binding!,"CodeObject");
 Console.WriteLine("Function "+Property(code,"Name")+", nativeBody="+(Property(code,"NativeBody")is not null));
 int index=0;
 foreach(var instruction in (IEnumerable)Property(code,"Instructions")) {
  var opcode=Property(instruction!,"OpCode").ToString();
  var extra=opcode is "Jump" or "JumpIfFalse" ? " target="+Property(instruction!,"TargetIndex") : "";
  Console.WriteLine($"{index++}: {opcode}{extra}");
 }
}
