from pathlib import Path
import copy,hashlib,json,os,shutil,subprocess
r=Path(__file__).parent;old=r.parent/'native-json-construction-r105'
prior=json.loads((old/'identity.json').read_text(encoding='utf8'))
inventory={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in prior['productionSources']}
hashes={hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in ['src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll','tests/Lokad.Lython.Tests/bin/Release/net11.0/Lokad.Lython.dll','tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0/Lokad.Lython.dll']}
assert len(hashes)==1,'Focused test binaries must match the frozen source build.'
images=r/'images';images.mkdir()
for role in ['before','candidate']:shutil.copytree(old/'images/candidate',images/role,copy_function=os.link)
candidate=images/'candidate/Lokad.Lython.dll';candidate.unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',candidate)
cores={role:hashlib.sha256((images/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']}
assert cores['before']==prior['coreSHA256']['candidate']and cores['before']!=cores['candidate']
identity=dict(baselineSource='Fully qualified a7bd4103/coreaae80cc7, cached CI42488128858',candidateSource='a7bd4103 plus one native return-tree proof, shared empty-sequence admission and selected return spans',coreSHA256=cores,productionSources=inventory,focusedChecks={'public11':205,'public10':205,'internal11':42,'internal10':42},qualification='Focused Release peractual11/10 pass, independent Python outputs/real truth suspension/refusal/cancellation/owners/selected spans. New-source full delivery pending.',controls='Ordinary split/rsplit helpers control existing native functions; CSV and JSON controls remain complete maintained scripts.')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf8')
catalog=json.loads((r.parent/'json-cpython-r103/representative.json').read_text(encoding='utf8'))
ids=['scripts.text-summary-guarded-helpers.large','scripts.text-summary-rsplit-helpers.large','scripts.text-summary-helpers.large','scripts.csv-summary-functions.large','scripts.json-summary-helpers.large']
cases={c['id']:c for c in catalog['cases']};catalog['cases']=[cases[k]for k in ids]
for c in catalog['cases']:
 for field,digest in [('source','sourceSha256'),('fixtureJson','fixtureSha256'),('expectedOutput','expectedOutputSha256')]:assert hashlib.sha256(c[field].encode()).hexdigest()==c[digest]
(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
small=copy.deepcopy(catalog);small['cases']=small['cases'][:2]
(r/'phase-catalog.json').write_text(json.dumps(small,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--',*json.loads((r/'baseline.json').read_text(encoding='utf8'))['sourceSHA256']]))
p=Path('PLAN.md');s=p.read_text(encoding='utf8');needle='1. **R106 active prototype:'
s=s.replace(needle,'1. **R106 active prototype, focused checks pass:**\n   205public/42internal peractual11/10; native guarded CFG verified. Shared empty\n   list post-admission cancellation/refusal, selected spans, fresh aliases and actual\n   truth suspension/budget reuse pass. Exact frozen comparison next, no timing claim.\n\n   ')
p.write_text(s,encoding='utf8')
print('R106 frozen source/core identities',json.dumps(cores),flush=True)
