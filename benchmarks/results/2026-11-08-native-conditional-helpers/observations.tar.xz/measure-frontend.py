from pathlib import Path
import json,os,subprocess
r=Path(__file__).parent;tool=r.parent/'integer-utf8-r45/tool/out/complete-jobs.dll'
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
for phase in ['compile','fresh']:
 folder=r/(phase+'-five-sync');folder.mkdir();witness=folder/'hash-witness.json'
 witness.write_text(json.dumps(dict(source="return [hash('Lython-é😀'), hash((1, 2.0, True))]\n"),ensure_ascii=False)+'\n',encoding='utf8')
 with(folder/'measurements.json').open('w',encoding='utf8')as out,(folder/'stderr.txt').open('w',encoding='utf8')as err:
  done=subprocess.run([env['DOTNET_HOST_PATH'],str(tool),str(r/'images/before/Lokad.Lython.Benchmarks.dll'),str(r/'images/candidate/Lokad.Lython.Benchmarks.dll'),str(r/'catalog.json'),str(witness),'reverse',phase,'sync'],env=env,stdout=out,stderr=err)
 assert done.returncode==0,(folder/'stderr.txt').read_text(encoding='utf8')[-2500:]
 d=json.loads((folder/'measurements.json').read_text(encoding='utf8'))
 assert all(d[k]for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
 print(phase,'same fixed five-case catalog; all golden/ownership/isolation/cleanup gates pass.',flush=True)
(r/'frontend-diagnostic-correction.md').write_text('Original two-case compile invocation rejected by unchanged driver before collection. Preserve compile-sync stderr, original two-case catalog and measure.py. Rerun only compile/fresh with supported unchanged five-case catalog; no driver/framework change, no repeat warm collection.\n',encoding='utf8')
p=r/'assess-local.py';s=p.read_text(encoding='utf8').replace("'compile-sync','fresh-sync'","'compile-five-sync','fresh-five-sync'")
p.write_text(s,encoding='utf8')

