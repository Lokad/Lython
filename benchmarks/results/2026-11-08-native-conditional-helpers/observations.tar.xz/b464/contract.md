R106 one six-job controlled sourcepairaae/67e, unchanged worker/normalGC/tiering.
One existing native-return proof extends to acyclic branch returns; remove
single-block selection/final-unselected-return-span assumption. Shared empty
sequence construction preserves fresh list admission/cancellation/refund.
Guard all eligible native branches before effects, execute only selected branch.
Loops/joins/custom truth/data-query format guards retain ordinary executable path.
No new runtime state/cache/pool/arena/backend/options/owners. Two int metadata
fields/node and compiler scratch are measured tradeoffs.
205public/42internal peractual11/10 pass; independent Python full outputs,
real truth I/O/cancellation/refusal/cleanup, fresh aliases and selected error spans.
Warm allocation neutral in all five local complete scripts. Desktop elapsed is
mixed/adverse, async guarded baseline spread22.7%; no controlled gain inferred.
CSV compile diagnostic+74.34to+78.81% with2.57%baseline spread is a material adverse
gap. Include CSVcompile as fourth job, replacing ordinary-split warm control.
Keep ordinary-rsplit/CSVwarm/JSONwarm controls. Fresh guarded-60%diagnostic is not
a normal-settings gain claim. Original rejected two-case frontend invocation and
supported five-case correction retained; no driver/framework changed/replayedwarm.
Two processes/core,5swarmup/role/job,7rotated150msrounds, coarse process CPU.
210sowner+30stop+30margin. Mediated guest RAM I/O/full validation/prior cleanup
included in warm; compile includes construction/disposal, no guest execution.
Compilation/startup/staging/final cached teardown excluded from warm. Actual
suspension tested independently; no startup/RSS/embedding tail claim.
Reuse archivedB463 baselineaae, uploadonly67e.240MiBOSfloor+7MiBevidence+actual
payload preflight; fresh exact-byte hardlinks preserve all original paths/aliases/
bytes and archives, proof included. All source/core/aux/Ready/golden/quiet/Closed/
join/fixture/archive/local gates. Old CI42488128858 qualifies onlya7, not thissource.
Retain all adverse/control evidence, no fixed%veto or blind retiming. Publication/
regex0.4 unchanged, no per-edit external CPython refresh or objective closure.
