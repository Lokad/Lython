# Lokad.Lython 0.11.0

Updated 2026-11-08. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
An isolated experiment does not complete this objective. Current contracts belong
in docs; completed/rejected designs and adverse evidence stay in
[EXPERIMENTS](benchmarks/EXPERIMENTS.md) and its linked immutable results.

## Actual delivery status

- **Fully qualified:** compiler-fact correction, direct UTF-8 formatting/storage,
  native helper returns and retained R62–R105 changes. Latest qualified runtime
  a7bd4103/coreaae80cc7, cached CI42488128858: Windows/Ubuntu actual .NET11/10,
  original Stress and installed core consumers. R98 independently qualified.
  No replay of completed qualification.
- **Measured separately:** native returns allocation−19.92/−19.31%; original
  elapsed remains diagnostic. Formatting allocation−8.67%, controlled B102
  elapsed/CPU−5–8%; original adverse15.125ms remains unexplained/preserved.
  R99 default-rsplit allocation−16.46%lower/−11.88%upper; controlled lower
  elapsed−14–17%sync/about−13%async, upper−8–12%sync; coarseCPU agrees.
- **Current external baseline:** R103/15c06863/core1674a06c versus CPython3.13.16,
  28jobs581.936s, separate compile/warm/compile-to-result. Current guide accurately
  names that source; older R97 ratios/history remain in the linked prior guide. Full I/O/validation/
  cleanup boundaries and uncertainty are in [BENCHMARKS](docs/BENCHMARKS.md).
- **Completed selection gates R100/R101:** integer sum already has unboxed64-bit
  accumulation; imports already execute compiled code; immutable builtin functions/
  signatures already shared. Setup profile atc74:552guest samples,31unknown5.62%;
  inclusive builtin factory3.44%, context ctor6.34%, JSON16.67%, filehost49.64%,
  kernel leaves60.33%. Groups overlap; no setup dominance or causal encoder timing.
  No lazy/global-root/scalar prototype selected.
- **Committed/pushed R102,15c06863:** two-file unified JSON encoding traversal, four
  ordinary completed-operation helpers replace per-step async state machines;
  four recursive eager walker helpers removed.765public/171internal focused JSON
  checks peractual11/10 pass. Private eager working metadata now temporary, not
  an escaping iterator charge; original50+8 accounting failures preserved.
  Allocation diagnostic: eager complete normalization+4.9%, streamed neutral;
  desktop elapsed mixed/adverse with baseline drift up to35.8%. Controlled B461 complete172.779s: eager elapsed+3.27to+5.01%/CPU+6.25%, streamed
  elapsed−2.02to−6.42%/coarseCPU mixed or nearzero. CSVcontrol adverse/inconclusive
  with6.14%candidate spread. Consolidation retained with explicit eager debt; full
  retained-source qualification fully green/cached13:55UTC, CI42484943603: both
  OSes/actual11/10/originalStress/installed consumers. Later R105 remains separate.
- **R105 committed/pusheda7bd4103/coreaae80cc7:** shared native JSON initializer/direct bound
  options/value calls; constructor dictionary/name-array/native forwarding removed.
  765public/171internal peractual11/10 pass. Eager allocation−27.2–27.7%, streamed
  −23.9–24.0%, config−4.3%; desktop timing variable/adverse preserved. B463
  complete172.758s, all gates/archive/local verified: eager elapsed−9–12% bothAPIs,
  streamed sync−6–7%, coarseCPU agrees. Configelapsednearbaseline/CPU+4.38to+5.70%
  possible debt retained, controls uncertain. Exact new-source full delivery fully green/cached14:35UTC, CI42488128858:
  Windows/Ubuntu actual11/10/originalStress/installed consumers.
- **Independent regex:** exact dev55/d6067925 development qualification remains
  86internal/514public peractual11/10; supplied core/PythonRe SHAs unchanged at
  13:33UTC. Normal optional0.4 pin unchanged; only affected final released adapter
  qualification pending. Core development remains independent.

Historical regression debt remains explicit: R76 float, R79 CSV, R95 text,
R96 possible report, R98 desktop uncertainty and older native-text/control
uncertainty are not repaid by unrelated newer pairs. Old bulk CSV6–8% evidence
and its control regression remain; current shared keys/array adoption already
remove its proposed copying phase. Slower call-arena/control/wide-carrier designs
remain rejected with their lessons; no automatic revival.

## Prioritized execution

1. **R106 active prototype: native acyclic return trees.**
   R106 source gate selects one existing native-return proof for acyclic return trees.
   Actual maintained helper tests line.isspace(), returns fresh[] on true, otherwise
   lower().split(). Frozen-core diagnostic confirms nativeBody=False and conditional/
   MakeList/Return instructions. Current guarded1.98–2.02x versus unguardedrsplit
   1.59–1.61xCPython selects investigation; these scripts do not isolate dispatch cost.
   
   Replace single-block preparation with one walk of the existing normalized block
   instructions. Keep old native expression operators/guards/cased kernel. Track
   compile-only original offsets/visited positions; require balanced branch inputs,
   terminal return trees and existing combined depth16 eligibility. Cycles/shared
   joins/unsupported shapes retain ordinary executable code before any work. Preserve
   old straight-line local forwarding and all existing native paths; no second parser,
   control carrier/arena/dispatch engine or per-call scratch/metadata arrays.
   
   Add conditional and empty-sequence native expression nodes. Existing guarded truth
   can execute only proven native values; custom truth stays on ordinary engine.
   Guard all eligible branches before effects, but execute only selected operations.
   Format proofs that query container values cannot be speculated across a branch;
   reject those native proofs, preserving their existing straight-line support.
   Source mappings include selected return instruction; do not use an unselected final
   return's span. Share the existing empty-list admission/construction between general
   and native execution, with post-admission cancellation before allocation. Empty
   tuple remains shared; lists remain fresh/retained aliases funded.
   
   Expected removals: blocks.Count!=1/straight-line-only selection, single final-return
   span assumption and duplicated empty-list construction branch. Extra compiler
   offset/visited/per-path stack scratch and8B/node of immutable control/exit metadata
   are explicit costs; no new runtime lifetime fields/pool/cache/options/owners.
   Runtime avoids general per-instruction work/argument workspace for eligible
   guarded helpers. No speedup predicted until whole-script source-pair comparison.
   
   Semantic acceptance: true/false/nested/if-else/implicit None, unselected missing
   names/errors/formatting/storage, changing builtins/admission reentry, custom truth
   and method protocols with actual async I/O, fresh/escaping lists, exact selected
   operation/return spans, first refusal/cancellation/cleanup/shared allowance reuse,
   managed stack and old unconditional native helper behavior. Public Python golden
   cases plus focused native/cased/conditional ownership checks peractual11/10.
   
   Implementation bound~30min before focused validation/refinement. Stop/refine rather
   than add a framework if original instruction mappings, guard purity or rollback
   need a larger rewrite. One short existing-driver allocation diagnostic then one
   six-job source pair on quiet VM: complete guarded text both APIs, ordinaryrsplit,
   ordinarysplit, CSV and JSON controls. Independently preserved full goldens. Include
   one short compilation/compile-to-result diagnostic for added compiler metadata.
   Keep all adverse originals; retain/correct/reject debt explicitly. Full new-source
   platform/Stress/installed checks at retained boundary; R105 qualification independent.
   Regex/publication unchanged. No per-edit external CPython replay.

2. **R104 source gate closed; next substantial runtime boundary.**
   Current module/function/lambda lexical facts already persist; builders reuse
   binding order. Native guards protect changing types/builtin identities before
   all effects/admission; existing sample shares do not establish call/frame
   dominance. Reservation reference identity protects transfer/idempotent cleanup;
   no copyable struct/scope wrapper selected from allocation ticks. Trim already
   scans UTF-8 once and native regex lookup already borrows UTF-8 keys. No new
   flat guard engine/consumer flag/cache/view lifetime or repeated binding walk.
   Preserve these source gates and old arena/control failures.
    Use current source/profile evidence to
   select a whole remaining phase and name its displaced code before editing.
   Calls/frames/operand transport already have direct argument projection, native
   workstate/returns and final slots; avoid reintroducing slower arenas or duplicate
   engines. For per-record construction, assess remaining admission/enumerator/
   final-storage costs rather than reviving copying already removed. For text/JSON,
   remove a real conversion/construction phase, preserving Unicode and callback
   semantics. Frontend work must show repeated facts on compile-to-result scripts;
   no speculative visitor/cache/JIT project. For each selected redesign record
   hypothesis, complete affected workloads, eliminated work/storage, source-level
   semantic acceptance and one bounded controlled before/after with controls.
   Finish the coherent deletion and decide remaining regression debt before moving
   to another optimization. Cancellation/admission/aliases must stay effective.

3. **R103 combined representative checkpoint closed.** Completed28-job checkpoint
   at15c06863/core1674, adding eager/streamed normalization warm cases to the
   existing26-job catalog. Same workers/protocol/5swarmup/7rotated150msrounds.
   620s owner+30stop+30margin; reuse archived exact B461 core, no new upload.
   All gates/archive/local verification pass; no active users/fixtures. Full delivery
   status is recorded independently. Preserve earlier guides and all variability.
   Refresh maintained CPython cases at the
   next combined retained boundary, not after each local change. Separate compile,
   warm, compile-to-result/startup; report exact source/core/date/machine and included
   host I/O, validation and cleanup. Startup/pending-I/O/RSS/embedding tail remain
   unmeasured until actually measured. Preserve historical named-source tables.

4. **Independent regex contract/implementation.** Continue Python-owned native
   UTF-8, byte ranges/scalar positions/original windows, flags/captures/replacements/
   errors, cache ownership/current token and consistent frontend/runtime/import
   provider. Core has no backend dependency; optional adapter remains nonpackable.
   Development producers/adapter-local bridges support tests. Distinguish contract
   forwarding/unwind tests, semantic compatibility and real backend performance.
   Exact dev55 gaps: DetailedData lacks separate preparation/working owner, native
   names lack enumeration, cursor creation retains a token despite per-move tokens.
   Existing bridges remain justified. A published producer blocks only affected
   final adapter qualification, never independent work. Qualify released semantics,
   managed safety and performance when supplied; no sibling edits/builds or repeats.

## Evidence and stopping policy

Bounded confirmation, refinement and measurement correction are allowed when
justified. Timeout, unstable unchanged controls or inconclusive observations mean
uncertainty, not permanent design failure. Size runs for usable observations on the
quiet VM; keep adverse data and original failed conditions. Fixed percentages inform
decisions rather than veto useful simplification. Distinguish architecture,
allocation, demonstrated CPU and embedding latency. Temporary regressions require
an explicit completion milestone and retain/correct/reject decision.

AGENTS.md governs managed safety/stack admission, host capabilities, cooperative
tokens and shared coarse memory/preflights/replacement overlap. No unsafe/Unsafe/
native probing, independent caps/fuel/quotas, heap tracing/weak reclamation/forced
GC, silent regex dialect or abandoned work. Keep retained aliases/cache/results/
pending users funded until awaited cleanup. Refusal remains terminal; no retries
or optional-storage escape. Initial long streams use bounded host executions.

Focused Release iteration; no overlapping local builds/tests/measurements; force
fresh builds after timestamp-preserving restores. Batch actual11/10 Windows/Ubuntu,
original Stress and installed core consumers at retained boundaries. Explicit UTF-8.
Only core Release pack into artifacts/nuget; no publication. VM lokad@20.166.121.73,
key ~/.ssh/id_lython-bench.pem. Persistent evidence separate from owned RAM; join,
unmount/archive under lease and verify locally. Exact-byte hardlink maintenance
requires fresh proof and preserves every original path/alias/byte/archive.
B450–B460 and all recorded terminal CI runs are cached; never query/restart them.
B461 terminal/archived/locally verified. B462 terminal/archived/locally verified. B463 terminal/archived/locally verified; no active users/fixtures. CI42484943603/15c06863 is terminal green/cached13:55UTC; never requery.
R105 CI42488128858/a7bd4103 is terminal green/cached14:35UTC; never requery. No duplicate dispatch or source15c CI replay.
CI observations>=5min apart; no duplicate
dispatch. Prior verbose status is preserved in R102 private pre-measurement history.
