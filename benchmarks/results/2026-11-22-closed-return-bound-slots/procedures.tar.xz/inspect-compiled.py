from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
pair=lab/"comparison"
donor=lab.parent/"native-direct-integer-return-refined-20261122/frozen/reference"
identity=json.loads((pair/"images.json").read_text(encoding="utf-8"))
sdk=Path.home()/".dotnet11"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
core="Lokad.Lython.dll"
summaries={}
for role in ("reference","candidate"):
    introspection=pair/f"inspect-{role}"
    introspection.mkdir(exist_ok=True)
    for path in donor.glob("Inspect.*"):
        shutil.copyfile(path,introspection/path.name)
    shutil.copyfile(pair/f"frozen-{role}"/core,introspection/core)
    output=introspection/"tapes.json"
    subprocess.run([sdk/"dotnet.exe",introspection/"Inspect.dll",pair/"catalog.json",output],env=env,check=True,timeout=40)
    inspection=json.loads(output.read_text(encoding="utf-8"))
    assert inspection["coreSHA256"]==identity["imageFiles"][role][core]
    summaries[role]={
        row["id"]:[
            dict(name=code["name"], closedReturn=code["directIntegerReturn"],
                 native=code["native"], instructions=code["instructions"])
            for code in row["codes"]
        ] for row in inspection["rows"]
    }
assert summaries["reference"]==summaries["candidate"]
for case,codes in summaries["reference"].items():
    if "factor" in case:
        assert any(c["name"]=="evaluate" and c["closedReturn"] for c in codes), case
print(json.dumps(summaries["reference"],indent=2))
(pair/"closed-returns.json").write_text(json.dumps(summaries,indent=2)+"\n",encoding="utf-8",newline="\n")
