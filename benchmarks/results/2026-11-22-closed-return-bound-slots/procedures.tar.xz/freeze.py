from pathlib import Path
import hashlib, json, os, shutil, subprocess, textwrap

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
last = lab.parent / "regex-provider-state-20261122/comparison"
worktree = repo / ".git/agent-worktrees/closed-return-bound-slots-20261122"
old_words = lab.parent / "inline-cased-word-headers-20261122"
out = lab / "comparison"
out.mkdir(exist_ok=True)

def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def write(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False)+"\n", encoding="utf-8", newline="\n")

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

catalog_path=out/"catalog.json"
captured_catalog=lab.parent/"inline-default-tuple-20261122/comparison/catalog.json"
shutil.copyfile(captured_catalog,catalog_path)
catalog=read(catalog_path)
assert len(catalog["cases"])==5 and catalog["performanceQualified"] is False
donor=last/"frozen-reference"
donor_files=read(last/"images.json")["imageFiles"]["reference"]
assert len(donor_files)==32 and {leaf:sha(donor/leaf) for leaf in donor_files}==donor_files
core = "Lokad.Lython.dll"
core_paths = {
    "reference":lab/"reference-build/bin/Lokad.Lython/release_net11.0"/core,
    "candidate":worktree/"src/Lokad.Lython/bin/Release/net11.0"/core,
}
assert sha(core_paths["reference"]) != sha(core_paths["candidate"])
sdk = Path.home()/".dotnet11"
dotnet = sdk/"dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk)+os.pathsep+os.environ["PATH"])
protocol = repo/"benchmarks/cpython-worker.py"
assert sha(protocol) == read(last/"images.json")["protocolSHA256"]
files = {}
for role,built_core in core_paths.items():
    image = out/f"frozen-{role}"
    image.mkdir(exist_ok=True)
    for leaf in donor_files:
        shutil.copyfile(built_core if leaf==core else donor/leaf,image/leaf)
    files[role] = {**donor_files, core:sha(built_core)}
    assert {leaf:sha(image/leaf) for leaf in donor_files}==files[role]
    receipt=out/f"{role}-verify.json"
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog_path,
        "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",receipt],
        cwd=repo,env=env,check=True,timeout=90)
    observed=read(receipt)
    assert observed["state"]=="Completed" and observed["caseCount"]==5 and observed["catalogSha256"]==sha(catalog_path)
ref=subprocess.check_output(["git","rev-parse","HEAD"],cwd=repo,text=True).strip()
cand=subprocess.check_output(["git","rev-parse","HEAD"],cwd=worktree,text=True).strip()
assert ref.startswith("8c7da02be") and ref != cand
assert not subprocess.check_output(["git","status","--porcelain","--untracked-files=no"],cwd=worktree)
patch=out/"source.patch"
patch.write_bytes(subprocess.check_output(["git","diff","--binary",ref,cand,"--","src","tests"],cwd=repo))
write(out/"images.json", dict(reference=ref,candidate=cand,imageFiles=files,protocolSHA256=sha(protocol),
    catalogSHA256=sha(catalog_path), sourcePatchSHA256=sha(patch)))
