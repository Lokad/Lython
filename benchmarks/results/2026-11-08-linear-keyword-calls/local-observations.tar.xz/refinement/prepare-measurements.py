from pathlib import Path
import ast,hashlib,json,os,shutil,tarfile
r=Path(__file__).parent;initial=r.parent/'linear-keyword-calls-r71';old=r.parent/'tuple-unpack-r70'
shutil.copytree(initial/'images/before',r/'images/before',copy_function=os.link)
shutil.copyfile(initial/'baseline.json',r/'baseline.json')
shutil.copyfile(initial/'baseline-public.log',r/'baseline-public.log')
s=(old/'prepare-local.py').read_text(encoding='utf-8').replace('fd5ab1c1 plus R70 immutable tuple unpack borrowing','7a81a629 plus R71 refined direct completed contexts and synchronous binding')
(r/'prepare-local.py').write_text(s,encoding='utf-8');exec(compile(s,str(r/'prepare-local.py'),'exec'),{'__file__':str(r/'prepare-local.py')})
local=json.loads((r/'identity.json').read_text(encoding='utf-8'));focused=json.loads((r/'binding-focused.json').read_text(encoding='utf-8'))
for suffix in ['net11','net10']:
    assert focused['checks']['binding-internal-'+suffix]['passed']==1366
    assert focused['checks']['binding-public-'+suffix]['passed']==239
assert focused['checks']['net11-coreSHA256']==local['coreSHA256']['candidate']
prior=json.loads((old/'vm-identity.json').read_text(encoding='utf-8'))
assert local['baseline']['productionSources']==prior['productionSources']
ci=json.loads(Path('benchmarks/results/2026-11-07-tuple-unpack/delivery-ci.json').read_text(encoding='utf-8'));assert ci['conclusion']=='success'and ci['headSha'].startswith('7a81a629')
identity=dict(sourceRevision=local['sourceRevision'],sourcePairBaseline='Fully qualified7a81a629/R70/core d6445fc5,CI42422556519. Local baseline063faf7f has identical production source and7a81a629 metadata.',
    originalVariant='Initial R71 core81fba80c/B424 preserved separately; current collection is the single declared completed-work refinement.',
    coreSHA256={'reference':prior['coreSHA256']['candidate'],'reference-control':prior['coreSHA256']['candidate'],'candidate':local['coreSHA256']['candidate'],'candidate-control':local['coreSHA256']['candidate']},
    auxiliaryFiles=prior['auxiliaryFiles'],productionSources=local['productionSources'],jobs=prior['jobs'],included=prior['included'])
(r/'vm-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8');shutil.copyfile(old/'representative.json',r/'representative.json')
def adapt(s):return s.replace('linear-keyword-b424','linear-keyword-b425').replace('lython-b424-linear-keyword','lython-b425-linear-keyword').replace('lython-b424-fixtures','lython-b425-fixtures')
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','launch.py','assess-vm.py']:
    s=adapt((initial/name).read_text(encoding='utf-8')).replace('R71 shared linear keyword/variadic activation','R71 refined direct completed-context/sync-binding activation')
    if name.endswith('.py'):ast.parse(s)
    (r/name).write_text(s,encoding='utf-8',newline='\n')
shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md');shutil.copyfile(r/'source.patch',r/'vm-source.patch');shutil.copyfile(old/'setup-contract.json',r/'setup-contract.json')
(r/'contract.md').write_text('''R71/B425 one justified final refinement after preserved B424: eliminate newly added completed-frame/sync-binding ValueTask packaging. Same shared binder/linear bound-body/actual pending-default continuation, no persistent fields/new engine/policy. Returned-record CSV warm/warm-async and ordinary CSV/text warm; two baseline/two current processes,5s warmup/role,7rotated150ms rounds, normalGC/tiering/quietF4as_v7. Fully qualified R70d6445fc5/CI42422556519 baseline; final40a4959e(.NET11)/a00c2ce7(.NET10) candidate, unchanged7cf37ca5 manifest worker/normal0.4adapter. Local baseline063faf7f identical production source, distinct metadata. Source gates: original/context-only variants1,366internal/3,118public per target; final direct-sync-binding1,366internal/239targeted public per actual11/10, matching probes;20baseline public default tests. No claim those earlier3118checks ran on final binding cleanup. Include public invocation/RAM I/O/all goldens/prior-result cleanup; exclude compile/startup/staging/reset/transport/final teardown. Existing five-script allocation diagnostic separate; keep original+refined adverse/variable clocks/IQR/10ms externalCPU and all failed conditions. No primary CPython refresh, causal packaging/JIT attribution or fixed veto. Source/actualReady/auxiliary/runtime/golden/quiet/Closed/exit/join/emptyfixtures/archive gates. Persistent workers/records separate owned128MiB RAM fixtures,256MiB staging floor.150sowner+30stop+30margin, observe210s, no timeout restart; join/unmount/archive under lease+locally verify. Stop refinement at retained/restored source and explicit debt decision; full new-source qualification batched, publication postponed, broader roadmap stays active.
''',encoding='utf-8')
with tarfile.open(r/'payload.tgz','w:gz')as t:
    for n in ['collect.py','archive-owned.py','run.sh','current-core.dll','representative.json','pre-measurement-plan.md','setup-contract.json','contract.md']:t.add(r/n,arcname=n)
    t.add(r/'binding-focused.json',arcname='focused.json');t.add(r/'vm-identity.json',arcname='identity.json');t.add(r/'vm-source.patch',arcname='source.patch')
print('Refinement frozen: baseline d6445fc5, current'+local['coreSHA256']['candidate'][:8]+', coherent final checks verified.')
