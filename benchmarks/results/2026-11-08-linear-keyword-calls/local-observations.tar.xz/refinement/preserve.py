from pathlib import Path
import hashlib, json, re, shutil, tarfile

r = Path(__file__).parent
initial = r.with_name('linear-keyword-calls-r71')
out = Path('benchmarks/results/2026-11-08-linear-keyword-calls')
out.mkdir(exist_ok=True)
assert not (out / 'README.md').exists(), 'Preserve once; do not overwrite evidence.'
identity = json.loads((r / 'identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == h for p, h in identity['productionSources'].items())
for source, prefix in [(initial, 'initial-'), (r, '')]:
    receipt = json.loads((source / 'archive-receipt.json').read_text(encoding='utf-8'))
    assert receipt['complete'] and receipt['jobs'] == 4
    assert hashlib.sha256((source / 'observations.tgz').read_bytes()).hexdigest() == receipt['archiveSHA256']
    for name in ['observations.tgz', 'archive-receipt.json', 'terminal-status.json', 'identity.json', 'vm-identity.json', 'assessment.json', 'local-assessment.json', 'contract.md']:
        shutil.copyfile(source / name, out / (prefix + name))
for name in ['binding-focused.json', 'focused.json', 'pre-measurement-plan.md']:
    shutil.copyfile(r / name, out / name)
with tarfile.open(out / 'local-observations.tar.xz', 'w:xz') as archive:
    for source, prefix in [(initial, 'initial'), (r, 'refinement')]:
        for p in source.iterdir():
            if p.is_file() and p.suffix in ['.py', '.json', '.log', '.md', '.patch']:
                archive.add(p, arcname=prefix + '/' + p.name)
        for folder in ['warm-sync', 'warm-async', 'initial-source', 'context-only']:
            if (source / folder).exists():
                archive.add(source / folder, arcname=prefix + '/' + folder)
        archive.add(source / 'current-core.dll', arcname=prefix + '/current-core.dll')
    archive.add(r / 'images/before/Lokad.Lython.dll', arcname='baseline-core.dll')
    archive.add('src/Lokad.Lython/bin/Release/net10.0/Lokad.Lython.dll', arcname='refinement/current-net10-core.dll')

raw = json.loads((r / 'assessment.json').read_text(encoding='utf-8'))
table = '| Complete job | Elapsed change, all process pairs | Baseline / current spread |\n| --- | ---: | ---: |\n'
for job in raw['jobs']:
    values = [v for pair in job['elapsedPercent'].values() for v in pair]
    table += f"| {job['case'].removeprefix('scripts.')} / {job['lane']} | {min(values):+.2f} to {max(values):+.2f}% | {abs(job['baselineSpreadPercent']):.2f}% / {abs(job['candidateSpreadPercent']):.2f}% |\n"
(out / 'README.md').write_text('''# Ordinary executable call activation — R71 / B424–B425

2026-11-08. Retained design on source 7a81a629, with explicit ordinary-CSV
regression debt. Final measured cores 40a4959e (.NET 11) / a00c2ce7 (.NET 10).
Exact source inventories, binaries, patches and original adverse results remain.
No public API or intended Python compatibility change. Full delivery of this new
source is pending; the R70 baseline is qualified separately by CI42422556519.

## Work removed and preserved

Nonmirrored executable keyword/variadic calls now use the positional call runner,
the existing final workspace and shared binder. They no longer recursively enter
the generic InvokeFromOperands / InvokeBound / ExecuteBody driver chain. This also
permits deferred lexical contexts independently of signature. Mirrored functions,
lowered functions and genuine callbacks retain their real generic entry points.
Redundant local-storage state, an impossible positional selector and generic
operand native-borrow attempts/flags with no production eligible caller disappear.
Native opcode borrows and callback native execution after binding remain.

Completed frame transitions and synchronous binding return directly. Only actual
pending default callbacks retain a continuation. Caller operands, binding storage
and call admission stay owned through suspension/body/awaited cleanup and transfer
exactly once. Live defaults, receiver evaluation, closures, varargs/kwargs, errors,
managed stack admission, current cancellation and terminal refusal remain.
No second binder, arena, persistent binding fields, policy or execution engine.

## Correctness and source variants

- Twenty public default checks pass on the baseline first.
- Initial prototype: 1,366 internal / 3,118 public per actual .NET 11/10.
- Intermediate direct-context variant: the same counts per target, archived
  separately; these runs do not qualify the final synchronous-binding cleanup.
- Final measured source: 1,366 internal / 239 targeted public per actual .NET 11/10,
  with matching probes. The public set covers function/default/bound-method/native
  return/deferred/async/lifetime/argument-order/expanded-call/file-worker/namespace/
  definition/generator/recursive-exception/depth behavior.

New default-callback regression really suspends, replaces live default metadata,
withdraws the global input alias, refuses substantial allocation, attempts guest
suppression/finally return, and then reuses the compiled script/shared budget.
It verifies retained arguments, first terminal origin, stopped output, awaited I/O
and balance return. Existing actual cancellation/default mutation and 301-frame
keyword recursion coverage remains. No timeout or containment assertion relaxed.

## Allocation and original experiment

Existing five-script driver, normal GC/tiering, independent before/current/control
assemblies sharing CoreLib/GC/hashing, both public APIs. All goldens, shared-budget
balances, image isolation and fixture cleanup pass. Final returned-record CSV
allocation falls **13.51–13.53% sync / 12.62–12.64% async**; ordinary CSV/text/JSON/
report allocation is essentially unchanged. This establishes allocation reduction,
not a CPU improvement.

Initial B424, 114.295 seconds: affected sync elapsed +0.43–2.76%, async
−0.33–4.51%; ordinary CSV −2.58 to +1.93%, text −3.04 to +3.96%, with baseline
spreads 3.86%/4.63%. Initial desktop CSV +8.47–9.98% remains adverse. Its newly
added completed-value packaging justified one coherent refinement; this does not
establish that packaging caused these timings. Initial sources/raw/cores remain
beside the refined observations.

Final desktop clocks remain diagnostic: affected sync +1.80/+15.99% with 12.23%
old-role drift, ordinary sync CSV −13.26/−8.57% (opposite the initial desktop and
VM direction), async affected about −0.54%, adverse async report +11.81%. No
discarded observation, desktop CPU claim or causal explanation.

## Controlled refined comparison — B425

Quiet Azure F4as_v7, Ubuntu 24.04.4, .NET 11 RC3. Two independent baseline/two
current processes, five-second warmup per role/job, seven rotated 150 ms rounds,
normal GC/tiering. Baseline d6445fc5 matches fully qualified R70/7a81a629;
desktop baseline 063faf7f has identical production source and distinct metadata.
Unchanged 7cf37ca5 manifest worker and normal optional 0.4 adapter. Four jobs
complete in **114.478 seconds**. Negative elapsed means faster.

''' + table + '''
Returned-record sync is flat; async has a modest elapsed benefit. Ordinary CSV
has **+0.07–5.09% elapsed and +6.25–11.70% coarse process CPU**. CPU includes
outside-job work and 10 ms quantization; it still cannot be dismissed as a proven
improvement. Text is mixed. No general CPU gain, CPython multiplier or repayment
of earlier regression debt is claimed.

**Disposition:** retain the coherent execution-route deletion and independently
measured allocation reduction, with ordinary CSV regression debt explicitly open.
Before another runtime optimization, inspect the changed completed-call transport
with a bounded source/generated-code assessment. Correct concrete added work if
found; otherwise keep the cause uncertain and choose a focused attribution or
explicit restoration/debt decision. Do not repeatedly retime unchanged code or
hide the adverse result beneath an unrelated improvement. This experiment does
not complete the whole-script performance objective.

Warm includes public invocation, mediated RAM I/O, full stdout/file validation
and prior-result cleanup; compilation/startup/staging/reset/protocol/final cached
teardown excluded. Async timing uses completed host I/O; genuine suspension is
separately tested. Desktop includes reset/result disposal and absolute clocks are
not comparable. No RSS, startup, pending-I/O or embedding-tail claim.

Every source/actualReady/auxiliary/runtime/golden/quiet/Closed/exit/join/empty-fixture
gate passes. Persistent evidence is separate from owned 128 MiB RAM fixtures;
all users join and the mount is removed before archive verification under lease
and independently locally. Staging 294,662,144 B passes the 256 MiB floor without
reclaim; 150 s owner + 30 s stop + 30 s margin. No timeout restart. B424/B425 are
terminal/archived/verified and must not be queried again. Publication postponed.

[Refined assessment](assessment.json), [initial assessment](initial-assessment.json),
[allocation/adverse desktop](local-assessment.json), [initial desktop](initial-local-assessment.json),
[final focused checks](binding-focused.json), [intermediate checks](focused.json),
[identities](identity.json), [VM identities](vm-identity.json), [contract](contract.md),
[refined VM archive](observations.tgz), [initial VM archive](initial-observations.tgz),
[local source/cores/tests/raw evidence](local-observations.tar.xz).
''', encoding='utf-8')
receipt = json.loads((out / 'archive-receipt.json').read_text(encoding='utf-8'))
receipt['localArchiveSHA256'] = hashlib.sha256((out / 'local-observations.tar.xz').read_bytes()).hexdigest()
(out / 'archive-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')

p = Path('benchmarks/results/2026-11-07-tuple-unpack/README.md')
s = p.read_text(encoding='utf-8').replace('Full Windows/Ubuntu, original Stress and installed-package delivery is pending\nfor this new source; baseline\'s green receipt does not qualify it. Publication\npostponed.', 'Full delivery CI42422556519 is GREEN: Windows/Ubuntu Release actual .NET 11/10,\noriginal Stress both targets and installed core consumers. The cached\n[terminal receipt](delivery-ci.json) qualifies source 7a81a629; never query again.\nPublication postponed.')
p.write_text(s, encoding='utf-8')
p = Path('docs/BENCHMARKS.md')
s = p.read_text(encoding='utf-8').replace('adverse desktop text preserved, full new-source delivery pending.', 'adverse desktop text preserved; full delivery qualified.')
anchor = '| Shared buffered-line execution'
s = s.replace(anchor, '| Linear keyword/variadic calls / returned-record CSV | Allocation −13.5% sync/−12.6% async; controlled sync flat, async elapsed −1.57–4.37% | Ordinary CSV adverse +0.07–5.09% elapsed/+6.25–11.70% coarse CPU remains open debt; full delivery pending. [R71](../benchmarks/results/2026-11-08-linear-keyword-calls/README.md) |\n' + anchor)
p.write_text(s, encoding='utf-8')
p = Path('benchmarks/EXPERIMENTS.md')
p.write_text(p.read_text(encoding='utf-8') + '''
## Linear keyword/variadic executable activation

R70 full delivery CI42422556519 is GREEN: Windows/Ubuntu Release actual .NET 11/10,
original Stress both and installed core consumers. Its cached receipt is final.

[R71/B424–B425](results/2026-11-08-linear-keyword-calls/README.md) removes the
generic recursive driver route for ordinary nonmirrored keyword/variadic helpers,
sharing final argument storage, binder and linear frame runner. Generic mirrored/
lowered callbacks retain real callers. Final measured source: 1,366 internal /
239 targeted public per actual 11/10; earlier initial/context-only source has
1,366/3,118 per target, not claimed for the final binding cleanup. New actual
default suspension/terminal refusal/retained input/reuse coverage and existing
cancellation/deep keyword recursion pass. All evidence gates pass.

Initial B424 adverse sync/desktop/control results remain. Refined B425 takes
114.478s: allocation −13.5% sync/−12.6% async, controlled sync affected flat and
async elapsed −1.57–4.37%. Ordinary CSV is adverse +0.07–5.09% elapsed and
+6.25–11.70% coarse CPU. Retain the complete route deletion/allocation benefit
with explicit ordinary-CSV regression debt, not a general CPU claim. Prioritize
its bounded source/generated-code assessment before another runtime optimization.
No repeated unchanged retiming, performance-objective completion or publication.
New-source full delivery pending; B424/B425 terminal, archived and verified.
''', encoding='utf-8')
for p in [out / 'README.md', Path('docs/BENCHMARKS.md')]:
    for target in re.findall(r'\]\(([^)]+)\)', p.read_text(encoding='utf-8')):
        if '://' not in target and not target.startswith('#'):
            assert (p.parent / target.split('#', 1)[0]).exists(), (p, target)
print('R71 retained with explicit CSV debt; original/refined sources, observations, checks and archives verified.')
