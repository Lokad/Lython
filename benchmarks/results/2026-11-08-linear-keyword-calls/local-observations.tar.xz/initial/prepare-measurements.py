from pathlib import Path
import ast,hashlib,json,shutil,tarfile
r=Path(__file__).parent;old=r.parent/'tuple-unpack-r70'
s=(old/'prepare-local.py').read_text(encoding='utf-8').replace('fd5ab1c1 plus R70 immutable tuple unpack borrowing','7a81a629 plus R71 shared linear ordinary keyword/variadic activation')
(r/'prepare-local.py').write_text(s,encoding='utf-8')
exec(compile(s,str(r/'prepare-local.py'),'exec'),{'__file__':str(r/'prepare-local.py')})
local=json.loads((r/'identity.json').read_text(encoding='utf-8'))
focused=json.loads((r/'focused.json').read_text(encoding='utf-8'))
for suffix in ['net11','net10']:
    assert focused['checks']['final-internal-'+suffix]['passed']==1366
    assert focused['checks']['final-public-'+suffix]['passed']==3118
prior=json.loads((old/'vm-identity.json').read_text(encoding='utf-8'))
assert local['baseline']['productionSources']==prior['productionSources']
jobs=prior['jobs']
identity=dict(sourceRevision=local['sourceRevision'],sourcePairBaseline='7a81a629 retained R70/core d6445fc5; full CI42422556519 separately pending. Local baseline063faf7f has identical production source and7a81a629 metadata.',
    coreSHA256={'reference':prior['coreSHA256']['candidate'],'reference-control':prior['coreSHA256']['candidate'],'candidate':local['coreSHA256']['candidate'],'candidate-control':local['coreSHA256']['candidate']},
    auxiliaryFiles=prior['auxiliaryFiles'],productionSources=local['productionSources'],jobs=jobs,included=prior['included'])
(r/'vm-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
shutil.copyfile(old/'representative.json',r/'representative.json')
def adapt(s):return s.replace('tuple-unpack-b423','linear-keyword-b424').replace('lython-b423-tuple-unpack','lython-b424-linear-keyword').replace('lython-b423-fixtures','lython-b424-fixtures')
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','launch.py','assess-vm.py']:
    s=adapt((old/name).read_text(encoding='utf-8'))
    if name=='collect.py':s=s.replace('R70 immutable tuple unpack transport','R71 shared linear keyword/variadic activation')
    if name=='launch.py':s=s.replace("reference=base/'checkpoint-cpython-b421-20261107/candidate'", "reference=base/'tuple-unpack-b423-20261107/candidate'")
    if name.endswith('.py'):ast.parse(s)
    (r/name).write_text(s,encoding='utf-8',newline='\n')
shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
shutil.copyfile(r/'source.patch',r/'vm-source.patch');shutil.copyfile(old/'setup-contract.json',r/'setup-contract.json')
(r/'contract.md').write_text('''R71/B424 bounded shared-linear-activation source pair on retainedR70: returned-record CSV warm/warm-async, ordinary CSV/text warm controls, two independent baseline/two candidate processes,5s warmup/role/job,7rotated150ms rounds, normalGC/tiering/quietF4as_v7. Exact R70d6445fc5 baseline, final81fba80c candidate, unchanged7cf37ca5 manifest worker/normal0.4 adapter; local baseline063faf7f identical production source, distinct commit metadata. Include public invocation, mediated RAM I/O, full goldens/prior-result cleanup; exclude compile/startup/staging/reset/transport/final teardown. Separate allocation via existing five-script shared-process driver; desktop clocks diagnostic. Preserve all adverse/controls/IQR/10ms processCPU (including outside-job work); no CPython refresh/predicted gain/fixed veto. Source/actualReady/auxiliary/normal-runtime/golden/quiet/Closed/exit/join/emptyfixtures/archive gates. Persistent records/workers separate owned128MiB RAM fixtures,256MiB staging floor.150sowner+30stop+30margin, observe210s, no timeout restart; join/unmount then archive under lease and independently locally.1,366internal/3,118public per actual11/10, matching probes,20baseline public defaults checks complete. R70fullCI independent/pending, newR71fullqualification later; publication postponed. Finish retained/restored activation/debt decision, continue broader objective.
''',encoding='utf-8')
with tarfile.open(r/'payload.tgz','w:gz') as t:
    for n in ['collect.py','archive-owned.py','run.sh','current-core.dll','representative.json','pre-measurement-plan.md','setup-contract.json','focused.json','contract.md']:t.add(r/n,arcname=n)
    t.add(r/'vm-identity.json',arcname='identity.json');t.add(r/'vm-source.patch',arcname='source.patch')
print('Prepared R71 final source/qualification gate; baseline d6445fc5/current '+local['coreSHA256']['candidate'][:8])
