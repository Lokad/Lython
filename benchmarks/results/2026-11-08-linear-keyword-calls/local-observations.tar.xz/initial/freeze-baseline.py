from pathlib import Path
import hashlib,json,os,shutil
r=Path(__file__).parent;image=r/'images/before'
shutil.copytree(r.parent/'tuple-unpack-r70/images/candidate',image,copy_function=os.link)
(image/'Lokad.Lython.dll').unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',image/'Lokad.Lython.dll')
data=dict(sourceRevision='7a81a629 retained R70, full CI pending; no production R71 prototype',
    coreSHA256=hashlib.sha256((image/'Lokad.Lython.dll').read_bytes()).hexdigest(),baselinePublicDefaultChecks=20,
    productionSources={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest()for p in Path('src/Lokad.Lython').rglob('*.cs')if not any(x in ['bin','obj']for x in p.parts)})
(r/'baseline.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
shutil.copyfile('PLAN.md',r/'pre-code-plan.md')
print(data['coreSHA256'])
