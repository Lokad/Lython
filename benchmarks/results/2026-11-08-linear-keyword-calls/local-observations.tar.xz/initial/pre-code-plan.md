# Lokad.Lython 0.11.0

Updated 2026-11-07. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Another experiment, source gate or qualification does not complete this objective.

## Current delivery status

| Work | Authoritative state |
| --- | --- |
| R62 / 70267889 | FULLY QUALIFIED CI 42412531882: Windows/Ubuntu Release actual .NET 11/10, original Stress and installed consumers. Cached receipt in the syntax-validation evidence; never query again. |
| R65 / 5dd131bf | Committed/pushed unused module class-cell analysis deletion; fully qualified in combined CI42418518578. Focused counts/diagnostics/probes preserved in evidence. |
| R66 / 824fc6bb | Committed/pushed shared buffered-line execution. 637 internal / 3,584 public per target; twelve pending-refill/close cases also pass on baseline. B420 complete and verified. No active prototype. |
| Combined R65/R66 | FULLY QUALIFIED CI42418518578 on824fc6bb: Windows/Ubuntu Release actual11/10, original Stress both, installed core consumers. Terminal cached; never query again. |
| R67 / B421 | COMPLETE/verified:23CPython jobs/478.32s, source824fc6bb/core15c04e2a. Current guide refreshed; prior tables historical. |
| R68 development adapter | Immutable0.5.0-dev.55/d6067925 compatibility complete,86internal/514public per target, unchanged bridge. Normal0.4pin/core untouched. Final released/safety/performance qualification separate. |
| R69 / fd5ab1c1 | Committed/pushed complete returned-record CSV workload and bounded CPU attribution; core unchanged. |
| R70 / 7a81a629 | Committed/pushed tuple unpack transport; focused checks/B423 complete. Full platform/Stress/package CI dispatched22:51:27Z, pending. No active measurement. |

R65 removes an unused whole-script class-cell query; genuine capture queries stay.
Compile allocation−3.53–4.64%, warm allocation unchanged; noisy/adverse desktop
elapsed does not establish CPU improvement. R66 removes duplicate line algorithms
and forwarding state machines; pending I/O retains the private builder, native
destinations remain caller-owned. Allocation neutral. Controlled async text elapsed
−2.32–8.26%, JSON−1.46–3.96%; process variation and quantized CPU leave magnitude
uncertain. Preserve sync CSV+0.99%, report elapsed+2.39%/CPU+6.94%, and original
adverse desktop observations. No general CPU/sync gain or debt repayment claim.

[R65 evidence](benchmarks/results/2026-11-07-module-class-facts/README.md),
[R66 evidence](benchmarks/results/2026-11-07-buffered-lines/README.md).
Full source qualification of R62 does not qualify later source. Do not repeat
unchanged qualification or service-query old terminal collections.

## Active R71 — ordinary executable activation through one linear runner

R70 is retained/committed7a81a629; its full CI is independent below. No active
prototype or local measurement yet. R69 current attribution is sufficient for
selection: the recursive keyword-call route is real, but its inclusive431samples
include useful guest work; no saved-CPU percentage is inferred.

Hypothesis/affected scripts: returned-record CSV and ordinary keyword/variadic
helpers can use the same active-child transition as positional calls. Eliminate
their InvokeFromOperands/InvokeBound/ExecuteBody recursive driver entry and defer
unneeded lexical contexts for eligible keyword signatures. Existing binder/final
workspace/native-return/closure machinery stays; no new arena, binder, engine,
owner registry, policy or persistent pending-binding fields.

Implementation/deletion: split the existing BeginPendingCall into preparation and
one bound-body entry. Return a completed ValueTask from normal transitions; await
only genuinely pending shared binding before that same entry. Preserve the direct
positional binder without wrapping its bound storage in another pending value.
Generalize runner eligibility to nonmirrored executable local storage; constructor/
raw protocol limits stay. Derive local-storage eligibility from immutable code,
removing its redundant function bool field. Delete the now-impossible generic
function branch's direct-positional selector; keep general/mirrored/lowered
callback helpers wherever they retain real callers.

Ownership/error contract: call admission begins before binding and transfers once
to pending binding, bound-body entry or child. Caller operands stay live; successful
binding owns its final workspace until child completion or rollback. Async binding
failure releases its own storage; the call transition releases admission exactly
once. Binding errors have no entered-function frame. Preserve current exception
state, live replaced defaults, receiver snapshots, closures, varargs/kwargs, nested
calls, managed stack admission, cancellation, first refusal and awaited cleanup.
Do not route by a preliminary "no protocol defaults" proof.

Validation: existing function/default/binder/async/method/namespace/generator/
ownership regressions plus a real suspending-default refusal/alias/reuse case,
first green on baseline. Both APIs/actual11+10; matching probes when relevant.
One existing five-script allocation diagnostic and a bounded returned-record sync/
async source pair with ordinary CSV/text controls. Retain adverse/variable results;
decide retained/restored source and remaining regression debt. Full delivery at a
coherent retained checkpoint, independent of producer publication. Finish this
activation consolidation before selecting another micro-optimization; continue
the broader whole-script objective after its decision.

## R70 retained delivery status

R67/R68 committed5076359c. R69 adds one complete returned-record CSV workload;
75public file-worker checks per actual11/10 and3CPython cases pass. B422 terminal/
archived/verified,1,121samples/5.64CPU seconds,108unknown. Production unchanged.
Exact tuple unpacking currently creates a checked iterator chain, temporary List,
backing and shell/capacity reservation;21Monitor leaves pass through this phase.
General activation is present but not established as the dominant removable cost.

Selected replacement: borrow exact immutable PyTuple.Items through all synchronous/
asynchronous unpack consumers. Keep general leased snapshots for mutable inputs,
guest protocols, generators and actual suspension. One local value/optional existing
lease replaces unconditional materialization; no new allowance/ledger/cache/engine.
Retire the tuple's duplicate iterator/list/backing/reservation phase, not the
general materializer. Preserve count/star/error rules, order, target side effects,
entry/long-loop cancellation, first refusal and original tuple/item funding through
actual users, pending targets and cleanup. Conservative batch ownership remains.

Acceptance: focused unpack/loop/assignment/generator/JSON-separator and ownership
checks; new regression for returned tuple and input aliases through target
rebinding/actual suspension/cancellation/refusal. Existing list/custom iterator
controls must still snapshot and preserve iterator side effects. Baseline must
pass public semantic regressions. One short returned-record before/after plus
ordinary CSV/text controls, allocation separately; all adverse data retained.
Close with retained/restored source and a debt decision; no fixed percentage veto.
Batch full platform/Stress/package checks at the coherent retained boundary.

Following complete activation consolidation: ordinary keyword/variadic executable
calls still recursively enter the generic driver, while positional calls use the
linear runner. Assess integrating the shared binder into that runner with a
completed prefix/actual pending-default continuation, preserving defaults/metadata/
managed depths/closures/refusal/funded arguments. Do not add another binder, arena,
"no protocol" preselection or per-call async state machine. Native/general paths
still needed for real callers remain. Record displaced phase and controlled pair
before promotion. This and the broader warm performance objective stay active.

[R69 evidence](benchmarks/results/2026-11-07-returned-record-calls/README.md).
R70 retained in4production files.824internal/1,106public union per actual
11/10 pass; matching probes built,24final public semantics also pass on baseline.
Local five-script checks pass all goldens/isolation/balances/fixtures through both
APIs. Returned-record allocation−13.57%sync/−14.40%async; ordinary controls flat.
Desktop elapsed is inconclusive/adverse: text roughly+9–10%sync/+5–8%async, with
other process controls drifting. Keep all original observations; no CPU claim.

B423 source pair COMPLETE/archived/verified,114.591s: affected sync elapsed
−6.45–7.45%,async−7.01–9.34%; ordinary CSV+0.06–0.28%,text−0.15–0.96%.
CoarseCPU direction favorable on affected work, controlCSV+4.07% retained;
quantization and protocol work preclude preciseCPU/universal gain. Desktop text
adversity remains unexplained. Retain storage-phase deletion/allocation/controlled
elapsed. [R70 evidence](benchmarks/results/2026-11-07-tuple-unpack/README.md).

Completed collection used returned-record warm/warm-async, ordinary CSV/text warm,
two baseline/two candidate processes,5s warmup/role,7rotated150ms rounds. Exact
baseline15c04e2a (fully qualified824fc6bb), candidated6445fc5/fd5ab1c1+prototype;
normal0.4adapter/manifest worker unchanged.150sowner+30stop+30margin, no restart,
all users joined/fixtures removed/quiet/archive under lease+localverification.
Staging315,863,040B passes without reclaim. No active local/VM work. Never query
B423 again. R70 committed/pushed7a81a629; ONE full Windows/Ubuntu Release,
actual11/10, original Stress and installed core-consumer qualification dispatched
at22:51:27.670828Z. Do not query before22:56:27.670828Z; use the cached
tuple-unpack-r70/check-ci.py/request, no duplicate dispatch and at least5minutes
between checks. Continue R71 meanwhile. R70 qualification pending despite green baseline.
Publication postponed; no new package release or unchanged benchmark refresh.

R71 next source milestone is the complete activation consolidation described above.
Use R69's existing current attribution; no new profiling campaign. Prepare the
shared binder/linear-runner transition with a synchronous completed prefix and one
continuation only for actual keyword-default suspension. Retire the ordinary
keyword/variadic call's recursive driver/wrapper phase. Preserve the existing
native-return/positional paths and general callbacks/mirrored scopes where real
callers still need them. Before code, finish the local entry/cleanup ownership
design, enumerate helpers displaced and record acceptance for genuinely pending
defaults through completion/cancellation/refusal, managed depths, mutated defaults,
retained caller values, errors and nested calls. No "no protocol" routing guard.
One bounded returned-record pair plus ordinary CSV/text controls, allocation
separate, explicit retained/restored source and debt decision; then continue the
remaining whole-script roadmap. R70 does not complete the performance objective.

## Following deliverable — evidence-led substantial runtime redesign

Use the refreshed workload/phase evidence and current source. R63 text CPU capture
(1,086samples/5.47CPU seconds) places material work in dispatch, inputs, native
split/hash/update and value publication. Inclusive call/helper/split shares overlap.
R52 report binding13self/rent3/frame3 and R56 config builtin17self do not establish
a dominant remaining frame or initialization phase. Do not predict saved CPU by
adding inclusive shares or recreate native paths already delivered.

| Boundary | Hypothesis / affected scripts / acceptance |
| --- | --- |
| Complete calls/frames | Remove a genuinely remaining binding/transport phase in CSV/text/report helpers. Native returns/borrowed operands/final slots/deferred contexts/workspace reuse already exist. Preserve defaults/keywords/variadics/closures/recursion/order/errors/suspension and retained caller storage. Retire displaced code; previous slower arenas/control designs remain evidence. |
| Operand/scalar dispatch | Counters, numeric updates and helper results. Preserve exact promotion, Python identity/aliases, public BigInteger and CLR-ingress round trips. Boxed values alone and60AddExact samples do not justify a universal representation. Choose a complete removable transport/work phase, not a new special case. |
| Per-record construction | CSV/JSON/report. Shared keys, CSV array transfer and direct JSON record slots exist. Select an actual remaining copy/capacity phase; preserve hooks/order/reentry/mutation/overlap and delete replaced construction machinery. |
| Bulk text/I/O | R66 now shares line execution; direct UTF-8 casing/lower-split/final formatting/native parsing already exist. Profile a remaining whole conversion/storage phase before redesign. Preserve Unicode expansion/context, hashes, scalar bounds, native ownership and genuine async I/O. |
| Frontend facts | R55/R58/R62/R65 remove repeated lexical/graph/validity/module work. Remaining function/class demand queries have distinct scope/postponed-annotation rules. Select a coherent fact-preparation deletion, not partial caches or a parser migration without resolving name rewriting. Preserve diagnostics/dead scopes/imports/generators. |

Before each selected redesign: write hypothesis, eliminated work/storage, affected
complete scripts, semantic/token/admission gates, displaced code and explicit
completion/regression-debt decision. Temporary setbacks can be accepted within
that milestone. Prefer removing mechanisms and consolidating invariants. No
parallel dispatcher, dormant backend, ownership framework or configuration switch.

One bounded source/generated-code assessment and, only when existing captures
cannot select the design, one focused current attribution. Stop investigation at
a concrete removable phase or explicit insufficient evidence; then select another
boundary. Stop implementation at a retained/restored source/debt decision and
continue the objective. No broad ownership/profiling campaign or new benchmark
framework. Focused regressions plus a short complete-script comparison with controls.
Timeouts/unstable controls/inconclusive clocks establish uncertainty. Bounded
confirmation/refinement/measurement correction remains available with evidence and
original conditions retained. Percentages inform decisions; no fixed veto or
blanket one-attempt/no-retiming/permanent-closure rules. Distinguish simplification,
allocation, controlled elapsed and CPU; never equate them.

## Independent regex deliverable

Core owns Python/native UTF-8 semantics, byte ranges/scalar positions/original
windows, flags/captures/replacements/errors, cache ownership and current tokens.
No Utf8Regex runtime dependency. Optional adapter is nonpackable0.4.0. Completed
contract/semantic work stands independently of producer publication.

R68 immutable dev55 compatibility is complete with the same adapter-local bridges.
Outstanding producer gaps: DetailedData has no distinct preparation/working-owner
input; native UTF-8 name lookup lacks enumeration; cursor creation retains its
token despite current-move overloads. Track a newer immutable input precisely,
qualify supported released bits and managed safety separately when available.
Development inputs/bridges support implementation; these gaps defer only affected
final adapter qualification. No sibling edits/builds, dialect fallback, regex quota,
new memory infrastructure or abandoned background matching.

## Completed evidence / lasting constraints

Shared compiler-fact correction, direct UTF-8 formatting/storage and native helper
returns are qualified. Returns allocation−19.92/−19.31%; prior elapsed diagnostic.
Formatting allocation−8.67%; controlled B102 elapsed/CPU−5–8% supports retention;
original adverse15.125ms remains preserved/unexplained. No unchanged campaign.
R20/R25 shared CSV keys/value transfer supersede the rigidly rejected constructor
(allocation−7.31/−6.55%, warm−7.72–8.04%, controls mixed). R54/R60 text-window
representations were fully withdrawn; independent public regressions remain.
R61 finds no escaped tokens in current JSON/report/config, and R64 proves common
local-result publication already skips store dispatch. Do not restart those same
prototypes without new evidence. Details stay in benchmarks/EXPERIMENTS.md and
immutable results, not current guides or this active task list.

AGENTS.md governs fully managed/memory-safe code, managed stack admission, host
capabilities, effective cancellation, shared allowance/preflights/replacement overlap/
retained aliases and terminal first refusal with awaited cleanup. No unsafe/Unsafe/
PInvoke/native probes, fuel/quotas/caps/hidden allowance, tracing/weak reclamation or
forced GC. Scope creation reserves nothing. Initial bounded streams use host batches;
XML depth remains. Later compiler passes can finish before their next token check.

Focused Release Category!=Stress and matching probe builds; no overlapping local
builds/tests/measurements. Force nonincremental builds after timestamp-preserving
restores. Batch full Windows/Ubuntu, actual11/10, original Stress and installed
core consumers at coherent retained checkpoints. Explicit UTF-8 text. Only core
Release pack via tools/pack.ps1; no adapter packages or alternate release bundles.

VM lokad@20.166.121.73, key ~/.ssh/id_lython-bench.pem. B385–B423 terminal,
archived/locally verified; never query them again. B421 is complete/archived/verified; no active VM collection.
Persistent records/workers, separate128MiB owned RAM fixtures; archive/verify under
lease and locally, join all users/unmount. Keep256MiB staging headroom; reclaim
only verified redundant extracted copies, preserving immutable archives. No sole
evidence in RAM. Docs describe current Lython; plans/history/receipts stay outside.

R68 dev55 compatibility complete: exact packages/nuspec/Core pin/SHA verified,
346Core/277PythonRe documented names unchanged fromdev54; existing adapter bridge
reused byte-for-byte.86internal/514public per actual11/10 pass in isolated images.
No new API/pin/production change justified. Final release/safety/performance remains
separate. [Evidence](benchmarks/results/2026-11-07-regex-dev55/README.md).
