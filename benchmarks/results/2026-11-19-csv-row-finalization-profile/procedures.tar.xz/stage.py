from pathlib import Path
import subprocess
import sys

lab = Path(__file__).resolve().parent
previous = lab.parent / 'current-rule-profile-b1137'
read = lambda p: p.read_text(encoding='utf-8-sig')
old_root = 'current-rule-profile-b1137-20261119'
new_root = 'current-csv-profile-b1140-20261119'
old_jobs = [('rules', 'scripts.rule-default-closures', 'warm'), ('annotated', 'scripts.annotated-rule-closures', 'warm'), ('captured', 'scripts.captured-rule-closures', 'warm')]
jobs = [('invoice', 'scripts.csv-invoice.large', 'warm'),
        ('keywords', 'scripts.csv-keyword-invoice.large', 'warm'),
        ('validated', 'diagnostic.csv-validated-records.long-fields.large', 'warm')]
labels = repr([label for label, _, _ in jobs])
proof = read(previous / 'prove-quiet-space.py')
a, b = proof.index('pairs = '), proof.index('\nrecords=')
proof = proof[:a] + "pairs = [('prepared-local-destination-r707/quiet','2026-11-19-prepared-local-destination','candidate','measured-core.dll.gz')]" + proof[b:]
prepare = read(previous / 'prepare.py')
a, b = prepare.index("catalog=load(cp"), prepare.index("save('catalog.json',catalog)")
prepare = prepare[:a] + '''catalog=load(lab.parent/'proven-record-keywords-r694/catalog.json')
metadata=load(lab.parent/'csv-final-payload-r379/catalog.json')
jobs=JOBS
catalog['cases'] = [next(case for case in (metadata if label == 'validated' else catalog)['cases']
    if case['id'] == name) for label,name,_ in jobs]
'''.replace('JOBS',repr(jobs)) + prepare[b:]
prepare = prepare.replace("prior=lab.parent/'retained-rule-profile-r664'","prior=lab.parent/'current-rule-profile-b1137'")
prepare = prepare.replace(old_root,new_root).replace('lython-b1137-current-rule-profile','lython-b1140-current-csv-profile')
prepare = prepare.replace('lython-b1137-fixtures','lython-b1140-fixtures')
prepare = prepare.replace('B1137 current rule CPU attribution after native integer transport','B1140 CSV row-finalization CPU attribution')
prepare = prepare.replace("    source=source.replace('R664/B1093 06b40a712 rule-definition CPU attribution','B1137 current rule CPU attribution')",
    "    source=source.replace('B1137 current rule CPU attribution','B1140 CSV row-finalization CPU attribution')")
prepare = prepare.replace("    if name=='ops-profile.py':", '''
    source=source.replace(OLD_JOBS,NEW_JOBS).replace(OLD_LABELS,NEW_LABELS)
    if name=='analyze.py':
        source=source.replace(' focused={name:',FOCUS + ' focused={name:')
    if name=='ops-profile.py':'''.replace('OLD_JOBS',repr(repr(old_jobs))).replace('NEW_JOBS',repr(repr(jobs)))
    .replace('OLD_LABELS',repr("['rules', 'annotated', 'captured']")).replace('NEW_LABELS',repr(labels))
    .replace('FOCUS',repr(""" focus.update({
     'row lookup and adoption': ('TryAdoptRecord','MatchesFields'),
     'row input and byte parsing': ('CsvRecordParser::Feed','CsvRecordSource','FeedOwnedLine'),
     'row finalization': ('FinishRecord','FinishField'),
     'string field materialization': ('CreateReservedUtf8','CompleteUnpublishedUtf8','EstimateApproximateBytes'),
     'dict reader iteration': ('CsvDictReaderObject','GetFieldNamesAsync'),
     'numeric conversion': ('TryParseShortDecimal','ParseOwnedFloatText','ExecuteNativeIntegerConversion'),
 })
""")))
prepare = prepare.replace('three CPython workload goldens','three CSV workload goldens against CPython')
prepare = prepare.replace('Current retained call CPU attribution','CSV row-finalization CPU attribution')
archive = read(previous / 'archive-profile.py').replace('2026-11-19-current-rule-checkpoint-profile','2026-11-19-csv-row-finalization-profile')
archive = archive.replace("'stage.py','preflight.json'","'stage.py','prove-quiet-space.py','preflight.json'")
for name, source in [('prove-quiet-space.py', proof),('prepare.py', prepare), ('archive-profile.py',archive)]:
    (lab/name).write_text(source,encoding='utf-8',newline='\n')
for name in ('prove-quiet-space.py','prepare.py'):
    subprocess.run([sys.executable,'-X','utf8',lab/name],check=True)
