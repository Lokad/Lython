from pathlib import Path
import ast, hashlib, json, os, subprocess, tarfile

lab=Path(__file__).resolve().parent
prior=lab.parent/'current-rule-profile-b1137'
cp=lab.parent/'retained-lexical-cpython-b1122'
donor=lab.parent/'validator-native-roundtrip-r706'
read=lambda p:p.read_text(encoding='utf-8-sig')
load=lambda p:json.loads(read(p))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,text):
    if name.endswith('.py'): ast.parse(text)
    (lab/name).write_text(text,encoding='utf-8',newline='\n')
def save(name,value): write(name,json.dumps(value,indent=2,ensure_ascii=False)+'\n')

old=load(prior/'config.json')
stage=load(donor/'quiet/config.json')
pair=load(donor/'frozen-identity.json')
revision=pair['candidateCommit']
assert revision.startswith('e20604ef4')
files=pair['images']['candidate']
frozen=donor/'frozen/candidate'
assert len(files)==32 and stage['identity']['imageFiles']['candidate']==files
assert {name:sha(frozen/name) for name in files}==files
catalog=load(lab.parent/'proven-record-keywords-r694/catalog.json')
metadata=load(lab.parent/'csv-final-payload-r379/catalog.json')
jobs=[('invoice', 'scripts.csv-invoice.large', 'warm'), ('keywords', 'scripts.csv-keyword-invoice.large', 'warm'), ('validated', 'diagnostic.csv-validated-records.long-fields.large', 'warm')]
catalog['cases'] = [next(case for case in (metadata if label == 'validated' else catalog)['cases']
    if case['id'] == name) for label,name,_ in jobs]
save('catalog.json',catalog)
identity=dict(sourceRevision=revision,purpose='B1140 CSV row-finalization CPU attribution',
    coreSHA256=dict(candidate=files['Lokad.Lython.dll']),imageFiles=dict(candidate=files),
    catalogSHA256=sha(lab/'catalog.json'),diagnosticOnly=True,publicationHeld=True)
save('identity.json',identity)
root='/home/lokad/lython-bench-checks/current-csv-profile-b1140-20261119'
unit='lython-b1140-current-csv-profile-20261119'
for name in ('ops-profile.py','collect.py','launch.py','retrieve.py','run.sh','analyze.py'):
    source=read(prior/name).replace(old['root'],root)
    source=source.replace('B1137 current rule CPU attribution','B1140 CSV row-finalization CPU attribution')

    source=source.replace("[('rules', 'scripts.rule-default-closures', 'warm'), ('annotated', 'scripts.annotated-rule-closures', 'warm'), ('captured', 'scripts.captured-rule-closures', 'warm')]","[('invoice', 'scripts.csv-invoice.large', 'warm'), ('keywords', 'scripts.csv-keyword-invoice.large', 'warm'), ('validated', 'diagnostic.csv-validated-records.long-fields.large', 'warm')]").replace("['rules', 'annotated', 'captured']","['invoice', 'keywords', 'validated']")
    if name=='analyze.py':
        source=source.replace(' focused={name:'," focus.update({\n     'row lookup and adoption': ('TryAdoptRecord','MatchesFields'),\n     'row input and byte parsing': ('CsvRecordParser::Feed','CsvRecordSource','FeedOwnedLine'),\n     'row finalization': ('FinishRecord','FinishField'),\n     'string field materialization': ('CreateReservedUtf8','CompleteUnpublishedUtf8','EstimateApproximateBytes'),\n     'dict reader iteration': ('CsvDictReaderObject','GetFieldNamesAsync'),\n     'numeric conversion': ('TryParseShortDecimal','ParseOwnedFloatText','ExecuteNativeIntegerConversion'),\n })\n" + ' focused={name:')
    if name=='ops-profile.py':
        assert repr(jobs) in source and 'elapsed >= 8' in source
    if name=='launch.py':
        source=source.replace('CSV row-finalization CPU attribution','Current rule CPU attribution after consolidation')
    write(name,source)
assert not b'\r' in (lab/'run.sh').read_bytes()

sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
with (lab/'verify.log').open('wb') as log:
    subprocess.run([dotnet,frozen/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',lab/'catalog.json',
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',Path.cwd()/'benchmarks/cpython-worker.py',
        '--out',lab/'verify.json'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=100,check=True)
result=load(lab/'verify.json')
assert result['state']=='Completed' and result['catalogSha256']==identity['catalogSHA256']
assert {name:sha(frozen/name) for name in files}==files
print('Verified the complete retained image and three CSV workload goldens against CPython.')

names=('identity.json','catalog.json','ops-profile.py','collect.py','run.sh')
payload=lab/'payload.tgz'
with tarfile.open(payload,'w:gz') as archive:
    for name in names: archive.add(lab/name,arcname=name)

receipt=load(donor/'quiet/archive-receipt.json')
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease'] and sha(donor/'quiet/observations.tgz')==receipt['archiveSHA256']
space=load(lab/'quiet-space.json')
needed=182452224+2097152+sum((lab/name).stat().st_size for name in names)
selected=[]
available=space['freeBytes']
for proof in space['replicas']:
    if available>needed+49152: break
    assert proof['sha256'] != files['Lokad.Lython.dll'] and proof['committedBlobVerified']
    available+=proof['bytes']
    selected.append(proof)
save('preflight.json',dict(available=available,required=needed,selected=selected))
assert available>needed,(available,needed)

config=dict(root=root,unit=unit,source=stage['root'],sourceFiles=files,sourceCatalogSHA256=stage['catalogSHA256'],
    catalogSHA256=identity['catalogSHA256'],identity=identity,retireGroups=selected,payloadBytes=payload.stat().st_size,
    payloadSHA256=sha(payload),unpackedBytes=sum((lab/name).stat().st_size for name in names),donorArchive=receipt['archiveSHA256'])
save('config.json',config)
source=read(lab.parent/'validator-warm-profile-b1132/remote-launch.py')
a,b=source.index('\nc=')+1,source.index('\nb=Path(')
source=(source[:a]+'c='+repr(config)+source[b:]).replace('lython-b1132-fixtures','lython-b1140-fixtures')
assert source.count("source/'candidate'/n")==2
write('remote-launch.py',source)
