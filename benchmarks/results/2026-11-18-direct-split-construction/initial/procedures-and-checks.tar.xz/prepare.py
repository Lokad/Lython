from pathlib import Path
import json,subprocess
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');work=repo/'.git/agent-worktrees/direct-split-r513'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert head.startswith('462aea0a')
assert not work.exists()
subprocess.run(['git','worktree','add','--detach','--no-checkout',str(work),head],cwd=repo,check=True)
patterns=subprocess.check_output(['git','sparse-checkout','list'],cwd=repo/'.git/agent-worktrees/buffered-yield-r510',text=True)
subprocess.run(['git','sparse-checkout','init','--no-cone'],cwd=work,check=True)
subprocess.run(['git','sparse-checkout','set','--no-cone','--stdin'],cwd=work,input=patterns,text=True,check=True)
subprocess.run(['git','checkout','--detach',head],cwd=work,check=True)
(r/'source-gate.json').write_text(json.dumps(dict(base=head,state='selected; private tree initialized, no production edits or measurements yet',evidence='R512 current1bce text allocation sample; range inventories17.03percent approximate tick weight, not exact bytes/CPU/saving.',hypothesis='Ordinary deterministic split scanners can count/admit final capacity and then write it directly, removing eager range inventory and its pool growth/copy/clear lifecycle without introducing new escaping representations.',
 remove=['ordinary SplitCore and SplitLineRanges range arrays/loan lifecycle','CollectSeparatedRanges inventory writer','CollectWhitespaceReverse inventory writer','ordinary BuildSplitResult inventory walk; preserve final reservation, UTF8 sharing and final-array adoption'],
 retain=['existing TryReadWhitespaceRange scanner and managed bounded cancellation','range inventory genuinely retained by private cased whitespace iteration','whole-source reuse, stable aliases, inline UTF8 and same-owner backing funding','terminal first refusal and output construction overlap/rollback'],
 design='Reuse existing forward whitespace state; expose equivalent deterministic separated/reverse/line range progression through a small private scanner state. Two bounded passes: count/major estimates, then exact final construction. No public option, universal buffer/tagged value, new owner/cache or tracing.',
 tradeoffs=['additional scan may cost CPU; measured decision required','removed scratch funding changes tiny-budget thresholds conservatively; final storage still admitted before allocation','snapshot source/arguments through admission reentry; no guest operation occurs during scans'],
 acceptance=['existing Unicode29whitespace/custom separators/maxsplit/reverse/linebreak/casing/identity regressions','focused both-target cancellation/refusal/retained aliases/budget cleanup','actual copied32file worker six goldens/allocation/reuse','one bounded whole-text warm/fresh plus floating/positional control source pair; document regression debt; full qualification at retained boundary'],
 publicationHeld=True),indent=2)+'\n',encoding='utf-8')
print('R513 private tree initialized with concrete deletion/replacement and semantic criteria at',head)
