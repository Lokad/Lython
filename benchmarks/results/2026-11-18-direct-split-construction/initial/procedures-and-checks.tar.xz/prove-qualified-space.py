from pathlib import Path
import json
r=Path(__file__).resolve().parent;prior=r.parent/'buffered-yield-r510'
q=json.loads((prior/'delivery/qualification.json').read_text(encoding='utf-8'))
assert q['conclusion']=='success' and q['all586ProductionInputsMatchMeasured1bce52ad']
s=(r.parent/'current-cpu-r508/prove-old-core.py').read_text(encoding='utf-8')
a=s.index('for suffix in ');b=s.index('current=json.loads',a)
s=s[:a]+'''canonical='benchmarks/results/2026-11-18-direct-global-operands/refined/candidate-core.dll.gz';blob=subprocess.check_output(['git','show','HEAD:'+canonical],cwd=repo);assert blob==(repo/canonical).read_bytes();data=gzip.decompress(blob)
assert hashlib.sha256(data).hexdigest()=='abab8760ea4b0bfba2d4f53276d6a58193f8e22a6ce0ae6bfdf832d4e2a08939'
subjects.append(dict(kind='superseded-core',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='gzip-payload',committedBlobVerified=True))
'''+s[b:]
s=s.replace("current=json.loads((r.parent/'bulk-trim-r506/frozen/identity.json').read_text(encoding='utf-8'));","current={'imageFiles':{'candidate':json.loads((r.parent/'buffered-yield-r510/frozen/identity.json').read_text(encoding='utf-8'))['imageFiles']['candidate']}};")
s=s.replace('current65fcAnd5aeImagesPreserved=True','current1bceImagesPreserved=True').replace("r/'old-core-proof.log'","r/'qualified-retirement-proof.log'").replace("r/'old-core-proof.json'","r/'retirement-candidates.json'")
exec(compile(s,str(r/'prove-qualified-space.py'),'exec'),dict(__file__=str(r/'prove-qualified-space.py')))
