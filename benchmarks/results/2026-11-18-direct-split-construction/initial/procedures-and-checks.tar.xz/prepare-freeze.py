from pathlib import Path
r=Path(__file__).resolve().parent;prior=r.parent/'buffered-yield-r510'
s=(prior/'freeze.py').read_text(encoding='utf-8')
s=s.replace("work=repo/'.git/agent-worktrees/buffered-yield-r510';prior=r.parent/'direct-global-r509'","work=repo/'.git/agent-worktrees/direct-split-r513';prior=r.parent/'buffered-yield-r510'")
s=s.replace("names=list(inputs['inputs']);assert len(names)==2388","names=list(inputs['inputs'])+['src/Lokad.Lython/Runtime/Text/PyStringOps.SplitScanner.cs'];assert len(names)==2389")
s=s.replace('assert len(production)==3,production','assert len(production)==2,production').replace('productionFiles=586','productionFiles=587')
a=s.index("referenceSource='");b=s.index("',candidateSource=",a);s=s[:a]+"referenceSource='Committed2e585229 production/frozen1bce52ad; buffered yield transport, full delivery independently tracked"+s[b:]
a=s.index("candidateSource='");b=s.index("',imageFiles=",a);s=s[:a]+"candidateSource='PrivateR513 on462aea0a: deterministic split sizing and direct final construction remove ordinary range inventory/growth/copy/loan lifecycle. Real private cased-iteration inventory remains. Reuses managed scanners; extra scan tradeoff. Existing retained-alias cleanup test now excludes discarded idle inventory. Only core DLL changes in measured image"+s[b:]
s=s.replace("source='R509 candidateabab8760; all32 hashes and unchanged catalog verified'","source='R510 candidate1bce52ad; all32 hashes and unchanged catalog verified'")
(r/'freeze.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared32file image/2389input/587production freeze, actual-worker goldens/allocation/reuse.')
