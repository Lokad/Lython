from pathlib import Path
import json,os,subprocess,sys
r=Path(__file__).resolve().parent;work=Path('D:/code/Lython/.git/agent-worktrees/direct-split-r513')
texts=['',' \t\n',' a  b  ','α\u2003β\u00a0γ ','a::b::','aaaaa','🌊🌊a🌊','\u0085x\u2029y\n']
cases=[(s,sep,n,s.split(sep,n),s.rsplit(sep,n))for s in texts for sep in [None,' ','::','aa','🌊']for n in [-1,0,1,2]]
lines=['','\n','\r\n','a\r\nb\rc\n','é\x85λ\u2028😀\u2029','a\v\f\x1cb\x1d\x1e',' a\t b ']
linecases=[(s,keep,s.splitlines(keep))for s in lines for keep in [False,True]]
source='cases='+repr(cases)+"\nfor text,sep,count,forward,reverse in cases:\n assert text.split(sep,count)==forward\n assert text.rsplit(sep,count)==reverse\nlines="+repr(linecases)+"\nfor text,keep,expected in lines:\n assert text.splitlines(keep)==expected\nprint('ok:334')\n"
(r/'semantic-matrix.py').write_text(source,encoding='utf-8')
cp=subprocess.run([sys.executable,'-I','-S','-X','utf8',str(r/'semantic-matrix.py')],capture_output=True,text=True,encoding='utf-8');assert cp.returncode==0 and cp.stdout=='ok:334\n',cp.stderr
d=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(d.parent),DOTNET_ROOT_X64=str(d.parent));env['PATH']=str(d.parent)+os.pathsep+env['PATH']
rows=[]
for asynchronous in [False,True]:
 cmd=[str(d),str(work/'tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll'),str(r/'semantic-matrix.py'),'--json']+(['--async']if asynchronous else[])
 p=subprocess.run(cmd,env=env,capture_output=True,text=True,encoding='utf-8',timeout=60)
 (r/('probe-async.json'if asynchronous else'probe-sync.json')).write_text(p.stdout,encoding='utf-8')
 assert p.returncode==0,p.stdout+p.stderr
 rows.append(dict(asynchronous=asynchronous,exitCode=p.returncode));print('334independent CPython-backed split assertions pass',asynchronous,flush=True)
(r/'probe-checks.json').write_text(json.dumps(dict(python=sys.version,assertions=334,cases=160,linecases=14,checks=rows),indent=2)+'\n',encoding='utf-8')
