from pathlib import Path
import json
r=Path(__file__).resolve().parent;prior=r.parent/'buffered-yield-r510'
q=json.loads((prior/'delivery/qualification.json').read_text(encoding='utf-8'))
assert q['conclusion']=='success' and q['all586ProductionInputsMatchMeasured1bce52ad']
s=(prior/'prepare-quiet.py').read_text(encoding='utf-8')
# The previous preparer expands its baseline template. Resolve it first without
# running either preparer or creating a partial staging folder.
template=(r.parent/'direct-global-r509/prepare-quiet.py').read_text(encoding='utf-8')
template=template.replace("prior=r.parent/'bulk-trim-r506'","prior=r.parent/'buffered-yield-r510'")
template=template.replace('direct-globals-b933-20261118','direct-split-b937-20261118').replace('lython-b933-direct-globals-20261118','lython-b937-direct-split-20261118').replace('lython-b933-fixtures','lython-b937-fixtures').replace('B933','B937')
template=template.replace("['scripts.numeric-squared-error.floating.large','compile-run']","['scripts.text-normalization.large','compile-run']")
template=template.replace('Qualified0691d64f production/65fcf7d0 versus privateR509/','Qualified2e585229 production/1bce52ad versus privateR513/')
template=template.replace('Direct adjacent global operands eliminate producer instructions/temp publication; current live lookup and native/resumable paths remain. Complete floating warm/fresh, text/call controls. Untimed cbfe source condition retained; no predicted gain.',
 'Ordinary split construction counts and admits final output then writes directly, removing eager range inventory/growth/copy/loan lifecycle. Real private cased iteration retains its inventory. Extra scan tradeoff; whole text warm/fresh plus floating/call controls. No forecast from sampled allocation types.')
template=template.replace('productionFiles=586','productionFiles=587').replace('Four-job direct-global source pair','Four-job direct-split source pair').replace('current65fcPreserved=True','current1bcePreserved=True')
exec(compile(template,str(r/'prepare-quiet.py'),'exec'),dict(__file__=str(r/'prepare-quiet.py')))
