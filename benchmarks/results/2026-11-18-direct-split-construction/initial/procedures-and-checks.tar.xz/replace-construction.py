from pathlib import Path
p=Path('D:/code/Lython/.git/agent-worktrees/direct-split-r513/src/Lokad.Lython/Runtime/Text/PyStringOps.Whitespace.cs')
s=p.read_text(encoding='utf-8');a=s.index('    private static PyList SplitCore(');b=s.index('    private static PyString CreateSplitFragment(',a)
s=s[:a]+'''    private static PyList SplitCore(PyString value, int maxSplit, bool reverse,
        MemoryGovernor? governor, LythonSourceSpan? span, LythonRuntime.ExecutionContext? context,
        CaseMapping? casing = null, PyString? separator = null)
    {
        if (separator is { ByteLength: 0 }) throw new InvalidOperationException("empty separator");
        return BuildSplitResult(value, separator, new(value.ByteLength, maxSplit, reverse, false, false, casing),
            casing, governor, span, context);
    }

    private static PyList SplitLineRanges(PyString value, bool keepEnds, MemoryGovernor? governor,
        LythonSourceSpan? span, LythonRuntime.ExecutionContext? context)
        => BuildSplitResult(value, null, new(value.ByteLength, -1, false, true, keepEnds, null),
            null, governor, span, context);

    private static PyList BuildSplitResult(PyString value, PyString? separator, SplitScanState scan,
        CaseMapping? casing, MemoryGovernor? governor, LythonSourceSpan? span,
        LythonRuntime.ExecutionContext? context)
    {
        governor ??= value.OwnerMemoryGovernor;
        span ??= PyStructuralGuard.AmbientSpan;
        context ??= PyStructuralGuard.AmbientContext;
        governor?.ThrowIfAdmissionFailed();
        context?.CheckExecution(span);
        var source = value.Utf8Span;
        var delimiter = separator is null ? default : separator.Utf8Span;
        var sizing = scan;
        var count = 0;
        long outputBytes = 0, sharedPayload = 0;
        (int Start, int End, int Capacity) first = default;
        while (TryReadSplitRange(source, delimiter, ref sizing, context, span, out var range))
        {
            context?.CheckExecution(span);
            if (count == 0) first = range;
            count = checked(count + 1);
            if (range.Capacity != 0)
                outputBytes = checked(outputBytes + PyString.EstimateApproximateBytes(range.Capacity));
            if (range.Capacity > PyString.InlineUtf8Capacity)
                sharedPayload = checked(sharedPayload + range.Capacity);
        }

        // Deterministic scanning establishes exact final capacity before any
        // allocation. Replay directly into it; no temporary range table or loan.
        var reuseWhole = casing is null && count == 1 && first.Start == 0 &&
            first.End == source.Length && ReferenceEquals(governor, value.OwnerMemoryGovernor);
        if (reuseWhole && first.Capacity != 0)
            outputBytes -= PyString.EstimateApproximateBytes(first.Capacity);
        var borrow = !reuseWhole && casing is null && value.CanBorrowUtf8Ranges(governor);
        var sharedHeader = borrow && sharedPayload != 0 ? value.Utf8SharingHeaderBytes : 0;
        if (borrow) outputBytes -= sharedPayload;
        var resultBytes = checked(outputBytes + PyList.EstimateCapacityBytes(count));
        using var output = governor?.ReserveTemporary(checked(resultBytes + sharedHeader), span);
        context?.CheckExecution(span);
        // Shared source backing survives failed private output construction.
        output?.Commit(sharedHeader);
        var parts = count == 0 ? Array.Empty<object>() : new object[count];
        var index = 0;
        while (TryReadSplitRange(source, delimiter, ref scan, context, span, out var range))
        {
            context?.CheckExecution(span);
            parts[scan.Reverse ? parts.Length - index - 1 : index] = reuseWhole ? value
                : borrow && range.Capacity > PyString.InlineUtf8Capacity
                    ? value.CreateReservedUtf8Range(range.Start, range.Capacity, governor!)
                    : CreateSplitFragment(source, range, casing, governor, span, context);
            index++;
        }
        var result = PyList.FromTransferredArray(parts, governor, span);
        context?.CheckExecution(span);
        output?.Commit(resultBytes);
        return result;
    }

'''+s[b:]
a=s.index('    private static void CollectSeparatedRanges(');b=s.index('    private struct WhitespaceRangeState(',a);s=s[:a]+s[b:]
a=s.index('    private static void CollectWhitespaceReverse(');b=s.index('    private static void AppendSplitRange(',a);s=s[:a]+s[b:]
p.write_text(s,encoding='utf-8',newline='\n')
print('Ordinary split inventories/growth/loan lifecycle removed; private cased scanner/loan remains genuinely used.')
