from pathlib import Path
import gzip,json,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-18-direct-split-construction/initial';out.mkdir(parents=True,exist_ok=False)
decision=dict(retain=False,state='Private, decision pending one unchanged text-only confirmation',reference='Fully qualified2e585229/1bce52ad',candidate='PrivateR513/f5725c55',
 established='Remove ordinary eager split/splitlines range inventory/growth/copy/loan lifecycle; real cased-iteration inventory remains. Text allocation17.319percent lower/accounted peak5.63percent lower. Both targets119internal/298public plus334independent assertions perAPI and sixgoldens/reuse pass.',
 uncertainty='Textfresh elapsed+0.94..+2.96percent with1.25/0.74percent spreads; CPU-3.29..+1.93. Textwarm-3.27..+3.79elapsed with6.97percent unchanged reference spread. Floating/callsCPU straddlezero. No CPU or universal gain.',
 next='One unchanged textwarm/fresh confirmation with longer rotated preparation and opposite preparation roles; original adversity remains. Decide retention/refinement/debt after usable observations, not a percent cutoff.',publicationHeld=True)
(r/'initial-decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8')
for name in ['summary.json','allocation-summary.json','candidate-allocation.json','candidate-preflight.json','candidate-sources.tar.xz','prototype.patch.gz','checks.json','probe-checks.json','semantic-matrix.py','probe-sync.json','probe-async.json','source-gate.json','initial-condition.json','initial-decision.json']:
 shutil.copyfile(r/name,out/name)
for name in ['observations.tgz','archive-receipt.json','terminal-status.json']:shutil.copyfile(r/'quiet'/name,out/name)
shutil.copyfile(r/'frozen/identity.json',out/'identity.json')
(out/'candidate-core.dll.gz').write_bytes(gzip.compress((r/'frozen/candidate/Lokad.Lython.dll').read_bytes(),mtime=0))
with tarfile.open(out/'procedures-and-checks.tar.xz','w:xz')as a:
 for p in sorted(r.rglob('*')):
  if p.is_file()and not any(n in p.relative_to(r).parts for n in ['frozen','retrieved','bin','obj'])and p.suffix in ['.py','.json','.log','.sh']:a.add(p,arcname=p.relative_to(r).as_posix())
(out/'README.md').write_text('''# Direct split construction: first source pair

R513/B937,2026-11-18UTC. Private **f5725c55** on462aea0a versus fully qualified
**2e585229/1bce52ad**. No promotion; one unchanged text-only confirmation selected.
Ordinary split/splitlines count/admit final capacity, then construct it directly.
Remove eager range inventories/growth/copy/clear/temporary-loan lifecycle; reuse
managed deterministic scanners. Real private cased iteration retains its range
storage. No new public API/owner/cache/policy or observable lazy list. A second
bounded scan is the CPU tradeoff.

Both actual11/10 each119internal/298public regressions pass;334independent
CPython3.13.2-backed assertions pass through each API. Six actual-worker goldens/
allocation/shared-budget reuse pass. Initial two obsolete idle-inventory assertions
are replaced by exact retained-funding checks, keeping aliases/refusal/cleanup;
original failures preserved. Two production files/one ownership fixture changed,
587production inputs; no supported behavior removed.

Complete text allocation1,518,312→1,255,352B(−17.319%); accounted peak
2,328,930→2,197,730B(−5.63%). Other six-case diagnostics are effectively flat.
This storage saving is established separately from CPU/elapsed uncertainty.

Quiet AzureF4as_v7/Ubuntu24.04.4/.NET11RC3, defaultGC/tiering, four jobs155.34s,
six-second warmups/five rotated rounds/two processes per source:

| Complete script/phase | Elapsed change | Wider CPU change | Ref/candidate spread |
| --- | ---: | ---: | ---: |
| Text compile-to-result |+0.94..+2.96%|−3.29..+1.93%|1.25/0.74%|
| Text warm |−3.27..+3.79%|−6.23..+1.18%|6.97/0.31%|
| Floating warm |−3.82..+0.75%|−4.07..+0.53%|3.95/0.77%|
| Positional warm |−1.60..−0.39%|−2.82..+1.19%|1.05/0.17%|

Textfresh has an adverse elapsed result; CPU does not establish a regression.
Textwarm's unchanged reference processes differ6.97%, limiting the decision.
Keep all outcomes; do not select a favorable process or infer CPU from allocation.
One unchanged textwarm/fresh confirmation uses8second rotated preparation/opposite
roles. It may confirm uncertainty; no permanent failure verdict or rigid veto.

Warm includes Run, mediatedRAMI/O, goldens/prior-result cleanup; fresh adds compile/
compiled-owner disposal. Startup/reset/protocol/finalcacheteardown excluded; CPU
wider. All32image hashes/catalog/goldens/quiet/join/persistent/localSHA/RAM teardown
pass. Exact oldabab working aliases retired only after current1bce full delivery,
committed canonical-byte proof and fresh path/UID/hash/link/all-alias validation.
Current1bce/catalogs/toolchains/unmatched evidence preserved;254/252MiBfloors intact.

[Initial decision](initial-decision.json),[summary](summary.json),
[allocation](allocation-summary.json),[raw](observations.tgz),[identity](identity.json),
[source](candidate-sources.tar.xz),[patch](prototype.patch.gz),
[checks/procedures](procedures-and-checks.tar.xz).
Publication postponed; wider performance objective continues.
''',encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as a:a.write('''

R513/B937 [direct split first source pair](results/2026-11-18-direct-split-construction/initial/README.md), privatef5725c55 versus qualified1bce: remove eager split/splitlines range inventories/growth/copy/loan lifecycle; keep real private cased iteration. Both targets119internal/298public/334independent assertions perAPI/sixgoldens/reuse pass. Textallocation−17.319%/peak−5.63%; other diagnostics~flat. Fourjobs155.34s: textfresh+0.94..+2.96%elapsed/CPUstraddleszero, textwarm−3.27..+3.79%with6.97%reference spread. Keep private; one unchanged textwarm/fresh confirmation justified, no CPU/universal gain or fixed-cutoff verdict. Original two obsolete-cache assertions strengthened to exact retained balances; alias/refusal/cleanup preserved. All quiet/join/SHAarchive/guards pass,current1bce remains qualified/publication held.
''')
print('Initial source and adverse/uncertain measurements preserved; confirmation still required for retention decision.')
