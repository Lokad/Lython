from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');work=repo/'.git/agent-worktrees/direct-split-r513'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).startswith('e270b5f1')
f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));assert json.loads((r/'decision.json').read_text(encoding='utf-8'))['retain']
assert all(hashlib.sha256((work/n).read_bytes()).hexdigest()==h for n,h in f['sourceInputs'].items())
checks=json.loads((r/'checks.json').read_text(encoding='utf-8'));assert len(checks)==4 and all(x['exitCode']==0 for x in checks)
names=subprocess.check_output(['git','diff','HEAD','--name-only'],cwd=work,text=True).splitlines();assert len(names)==3
assert [n for n in names if n.startswith('src/Lokad.Lython/')]==f['changedProductionFiles']
for n in f['sourceInputs']:
 if not n.startswith('src/Lokad.Lython/')or n in names:continue
 a=(repo/n).read_bytes();b=(work/n).read_bytes();assert a==b or a.decode('utf-8-sig').replace('\r\n','\n')==b.decode('utf-8-sig').replace('\r\n','\n'),n
for n in names:
 assert n in f['sourceInputs'];(repo/n).write_bytes((work/n).read_bytes());assert hashlib.sha256((repo/n).read_bytes()).hexdigest()==f['sourceInputs'][n]
print('Exact measured2production/1ownership-test files integrated; full delivery separately pending.')
