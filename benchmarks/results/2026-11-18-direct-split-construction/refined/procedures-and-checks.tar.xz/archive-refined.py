from pathlib import Path
import gzip,json,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-18-direct-split-construction/refined';out.mkdir(exist_ok=False)
decision=dict(retain=True,reference='Fully qualified2e585229/1bce52ad',candidate='Refined privateR513/2ede09fc',
 reason='Remove ordinary split/splitlines eager range inventories/growth/copy/loan lifecycle, bulk-count common separators/line boundaries for conservative admission and write final storage directly. Stable named whole-text elapsed/CPU benefit and17.319percent allocation reduction.',
 tradeoff='Accounted peak+1.12percent due conservative preflight headroom; earlier denial documented. Commit actual retained estimates/refund only unused reservation headroom. Initial lower peak belongs only tof572.',
 debt='Positional elapsed-4.59..+8.79percent/CPU-4.44..+7.36 with5.22/8.37percent process spreads remains inconclusive. Accept this uncertainty for coherent storage/named text benefit and revisit at the next representative helper checkpoint; no universal/floating-control gain claim or unchanged campaign now.',
 history='Initialf572/adverse unchangedB938 preserved; no source-condition subtraction or causal regression-recovery claim. New source pair is independent.',
 qualification='Focused actual11/10 each119internal/298public plus334independent semantic assertions perAPI, sixgoldens/allocation/reuse; full retained-source qualification separately pending.',publicationHeld=True)
(r/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8')
for n in ['summary.json','allocation-summary.json','candidate-allocation.json','candidate-preflight.json','candidate-sources.tar.xz','prototype.patch.gz','checks.json','probe-checks.json','probe-sync.json','probe-async.json','semantic-matrix.py','decision.json','source-gate.json','refined-prestage-refusal.json']:shutil.copyfile(r/n,out/n)
for n in ['observations.tgz','archive-receipt.json','terminal-status.json']:shutil.copyfile(r/'quiet'/n,out/n)
shutil.copyfile(r/'frozen/identity.json',out/'identity.json')
(out/'candidate-core.dll.gz').write_bytes(gzip.compress((r/'frozen/candidate/Lokad.Lython.dll').read_bytes(),mtime=0))
with tarfile.open(out/'procedures-and-checks.tar.xz','w:xz')as a:
 for p in sorted(r.rglob('*')):
  if p.is_file()and not any(n in p.relative_to(r).parts for n in ['measured-first','frozen','retrieved','bin','obj'])and p.suffix in ['.py','.json','.log','.sh']:a.add(p,arcname=p.relative_to(r).as_posix())
(out/'README.md').write_text('''# Direct split construction: refined retained source

R513/B939,2026-11-18UTC. Private **2ede09fc** on462aea0a versus fully qualified
**2e585229/1bce52ad**. Retain direct ordinary split/splitlines construction.
Eager range inventories/growth/copy/clear/temporary-loan lifecycle disappear;
actual private cased iteration keeps its range storage. Common single-byte
separators/Python line boundaries use bounded managed bulk counts for sizing;
other/cased forms retain deterministic semantic scanners. One final scan writes
directly into admitted output. No new owner/cache/policy/public API or lazy list.

Conservative fragment/payload/header estimates cover capacity and overlap before
allocation; construction commits actual retained estimates and refunds unused
reservation headroom. Shared source backing stays funded. Earlier denial under
tight allowances is intentional. No refund of retained storage or retry.

Both actual11/10 each119internal/298public focused regressions and334independent
CPython-backed assertions through each API pass; six actual-worker goldens/
allocation/reuse pass. Two production files/one existing ownership fixture change,
587production inputs. Initial obsolete inventory assertions become exact retained
balances, preserving aliases/refusal/cleanup. Every32-file copied image is verified.

Complete text allocation1,518,312→1,255,352B(−17.319%). Accounted peak
2,328,930→2,355,001B(+1.12%) reflects conservative preflight, separately recorded
from physical allocation. Firstf572's lower peak is not relabelled as this source.

Quiet AzureF4as_v7/Ubuntu24.04.4/.NET11RC3, defaultGC/tiering, fourjobs153.86s,
six-second warmups/five rotated rounds/two processes per source:

| Complete script/phase | Elapsed change | Wider CPU change | Ref/candidate spread |
| --- | ---: | ---: | ---: |
| Text warm |−2.30..−1.84%|−5.80..−3.95%|0.13/0.35%|
| Text compile-to-result |−2.72..−1.31%|−4.34..−2.57%|0.20/1.25%|
| Floating warm control |−5.12..−0.83%|−5.41..−1.07%|1.22/3.27%|
| Positional warm control |−4.59..+8.79%|−4.44..+7.36%|5.22/8.37%|

Retain coherent removed storage/lifecycle and stable named whole-text benefit.
Positional-call uncertainty is explicit accepted debt, to revisit with the next
representative helper checkpoint; no unchanged control campaign now. Do not claim
a universal/floating-control gain, new CPython ratio, subtraction of source
conditions or causal recovery from the [initial](../initial/README.md) and
[adverse unchanged confirmation](../confirmation/README.md). Full platform/original
stress/installed Release qualification follows this retained source independently.

Warm includes Run, mediatedRAMI/O, goldens/prior-result cleanup; fresh adds compile/
compiled-owner disposal. Startup/reset/protocol/final cache teardown excluded;
process CPU wider. All quiet/join/persistent/localSHA/RAM teardown gates pass.
The first staging guard refused before launch/deletion; preserve it. Fresh exact
Git-canonical/hash/UID/path/link/all-alias proof retires oldf572 working aliases
and three archived raw JSON replicas only. Current1bce/images/catalogs/toolchains/
unmatched evidence remain;254/252MiBfloors unchanged. No measurement restarted.

[Decision](decision.json),[summary](summary.json),[allocation](allocation-summary.json),
[raw](observations.tgz),[identity](identity.json),[source](candidate-sources.tar.xz),
[patch](prototype.patch.gz),[checks/procedures](procedures-and-checks.tar.xz).
Publication postponed; broader performance work continues.
''',encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as a:a.write('''

R513/B939 [refined direct split](results/2026-11-18-direct-split-construction/refined/README.md),2ede09fc versus qualified1bce: retain removed eager inventories/loan lifecycle with bulk-count/conservative admission/direct final writing. Both targets119internal/298public/334independent assertions perAPI/sixgoldens/reuse pass. Allocation−17.319%/accountedpeak+1.12%(headroom), no retained-storage refund. Fourjobs153.86s: textwarm1.84–2.30%lower elapsed/3.95–5.80%lowerCPU; fresh1.31–2.72%lower elapsed/supportingCPU. Calls remain uncertain(5.22/8.37%process spread), explicit accepted debt for next representative helper checkpoint; no universal/control gain or source-condition subtraction. Initialf572/B938adversity preserved. All gates/join/SHAarchive pass; first pre-stage guard refusal/canonical-only retirement preserved, current1bce/254/252MiBguards intact. Full delivery next/publicationheld/objectiveactive.
''')
print('Refined retained condition archived, including peak/call uncertainty and all earlier adverse evidence.')
