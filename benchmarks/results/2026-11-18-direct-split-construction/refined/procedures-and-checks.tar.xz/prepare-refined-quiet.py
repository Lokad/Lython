from pathlib import Path
r=Path(__file__).resolve().parent
s=(r/'prepare-quiet.py').read_text(encoding='utf-8')
s=s.replace('direct-split-b937-20261118','direct-split-refined-b939-20261118').replace('lython-b937-direct-split-20261118','lython-b939-direct-split-refined-20261118').replace('lython-b937-fixtures','lython-b939-fixtures').replace('B937','B939')
s=s.replace('Extra scan tradeoff; whole text warm/fresh plus floating/call controls. No forecast from sampled allocation types.', 'Refinement bulk-counts common separators/lines for conservative sizing and commits exact final estimates, refunding only unused headroom. Initialf572 adversity retained. Whole text warm/fresh plus floating/call controls, no source subtraction or forecast.')
exec(compile(s,str(r/'prepare-refined-quiet.py'),'exec'),dict(__file__=str(r/'prepare-refined-quiet.py')))
p=r/'launch.py';s=p.read_text(encoding='utf-8').replace('Four-job refined direct-global source pair source comparison','Four-job refined direct-split source pair');p.write_text(s,encoding='utf-8',newline='\n')
