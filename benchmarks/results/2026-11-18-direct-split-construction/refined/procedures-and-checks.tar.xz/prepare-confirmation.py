from pathlib import Path
import ast,hashlib,json,re,tarfile
r=Path(__file__).resolve().parent;old=r/'quiet';q=r/'confirmation';q.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'))
assert all(sha(r/'frozen'/role/n)==h for role,files in f['imageFiles'].items()for n,h in files.items())
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'));identity['purpose']='One unchanged textwarm/fresh confirmation: firstB937warm reference spread6.97percent and adversefresh elapsed+0.94..+2.96percent retained. Eight-second rotated warmup/opposite preparation roles; decide actual CPU/storage tradeoff, no source-condition subtraction or forecast.'
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
jobs=[['scripts.text-normalization.large','warm'],['scripts.text-normalization.large','compile-run']]
s=(old/'collect.py').read_text(encoding='utf-8');a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==2 and all(case in cases for case,lane in jobs)\n'+s[b:]
s=s.replace('warmupSeconds=6','warmupSeconds=8').replace('while min(warmed)<6:','while min(warmed)<8:').replace('if warmed[i]>=6:continue','if warmed[i]>=8:continue').replace('if job_index >= 2: labels.reverse()','if job_index % 2 == 1: labels.reverse()')
(q/'collect.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'archive-owned.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==4","len(raw['jobs'])==2").replace('jobs=4','jobs=2');(q/'archive-owned.py').write_text(s,encoding='utf-8',newline='\n')
remote='/home/lokad/lython-bench-checks/direct-split-confirm-b938-20261118';unit='lython-b938-direct-split-confirm-20261118';previous=json.loads((old/'config.json').read_text(encoding='utf-8'))
(q/'run.sh').write_text((old/'run.sh').read_text(encoding='utf-8').replace(previous['root'],remote),encoding='utf-8',newline='\n')
names=['collect.py','archive-owned.py','run.sh','identity.json']
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for n in names:a.add(q/n,arcname=n)
c=dict(root=remote,unit=unit,source=previous['root'],sourceRole='candidate',sourceFiles=f['imageFiles']['candidate'],sourceCatalogSHA256=f['catalogSHA256'],catalogSHA256=f['catalogSHA256'],identity=identity,retireGroups=[],payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha(q/'payload.tgz'),unpackedBytes=sum((q/n).stat().st_size for n in names))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8')
s=(old/'remote-launch.py').read_text(encoding='utf-8');a=s.index('c=');b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(c)+s[b:]
s=s.replace("os.link(source/c['sourceRole']/n,p)","os.link(source/role/n,p)").replace('lython-b937-fixtures','lython-b938-fixtures')
(q/'remote-launch.py').write_text(s,encoding='utf-8',newline='\n')
s=(r/'launch.py').read_text(encoding='utf-8').replace("parent/'quiet'","parent/'confirmation'").replace('Four-job refined direct-global source pair source comparison','Two-job unchanged direct-split confirmation');(r/'launch-confirmation.py').write_text(s,encoding='utf-8',newline='\n')
s=(old/'retrieve.py').read_text(encoding='utf-8').replace("['jobs']==4","['jobs']==2").replace('B934','B938');(q/'retrieve.py').write_text(s,encoding='utf-8',newline='\n')
s=(r/'summarize.py').read_text(encoding='utf-8').replace("r/'quiet/retrieved/confirmation/confirmation.json'","r/'confirmation/retrieved/confirmation/confirmation.json'").replace("len(raw['jobs'])==4","len(raw['jobs'])==2").replace("r/'summary.json'","r/'confirmation-summary.json'").replace("r/'allocation-summary.json'","r/'confirmation-allocation-summary.json'");(r/'summarize-confirmation.py').write_text(s,encoding='utf-8',newline='\n')
for p in list(q.glob('*.py'))+[r/'launch-confirmation.py',r/'summarize-confirmation.py']:ast.parse(p.read_text(encoding='utf-8'))
print(json.dumps(dict(prepared=True,jobs=2,warmupSeconds=8,sourceUnchanged=True,retireGroups=[],unpackedBytes=c['unpackedBytes'],observeAfterSeconds=230)))
