from pathlib import Path
r=Path(__file__).resolve().parent;out=r/'measured-first';out.mkdir(exist_ok=False)
names=['frozen','quiet','confirmation','candidate-sources.tar.xz','prototype.patch.gz','candidate-preflight.json','candidate-preflight.log','candidate-allocation.json','candidate-allocation.log','summary.json','allocation-summary.json','confirmation-summary.json','confirmation-allocation-summary.json','checks.json','build.log','probe-checks.json','probe-sync.json','probe-async.json']
for name in names:(r/name).rename(out/name)
print('First measured source and unchanged adverse confirmation preserved without relabelling.')
