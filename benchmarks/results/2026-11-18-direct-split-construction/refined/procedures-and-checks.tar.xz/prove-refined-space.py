from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');subjects=[]
def committed(name):
 data=subprocess.check_output(['git','show','HEAD:'+name],cwd=repo);assert data==(repo/name).read_bytes();return data
name='benchmarks/results/2026-11-18-direct-split-construction/initial/candidate-core.dll.gz';blob=committed(name);data=gzip.decompress(blob)
assert hashlib.sha256(data).hexdigest()=='f5725c55e39a47569daf1c413504bfea0db00d0a98e92a5de1a659e3be9f673b'
subjects.append(dict(kind='superseded-prototype-core',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),canonical=name,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='gzip-payload',committedBlobVerified=True))
name='benchmarks/results/2026-11-18-affected-cpython-checkpoint/observations.tgz';blob=committed(name);member='confirmation/confirmation.json'
with tarfile.open(fileobj=io.BytesIO(blob))as a:data=a.extractfile(member).read()
subjects.append(dict(kind='archived-raw-observation-replica',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),canonical=name,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True,knownPath='affected-cpython-b936-20261118/'+member))
for suffix,folder in [('initial','direct-split-b937-20261118'),('confirmation','direct-split-confirm-b938-20261118')]:
 name='benchmarks/results/2026-11-18-direct-split-construction/'+suffix+'/observations.tgz';blob=committed(name)
 with tarfile.open(fileobj=io.BytesIO(blob))as a:data=a.extractfile(member).read()
 subjects.append(dict(kind='archived-raw-observation-replica',sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),canonical=name,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member=member,committedBlobVerified=True,knownPath=folder+'/'+member))
code='''from pathlib import Path
import fcntl,hashlib,json,os,stat,subprocess
b=Path('/home/lokad/lython-bench-checks');subjects=SUBJECTS
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert not any(os.path.ismount(p)for p in b.glob('*/guest-fixtures'))
 proofs=[];keys={}
 for item in subjects:
  candidates=[b/item['knownPath']]if'knownPath'in item else list(b.glob('*/*/Lokad.Lython.dll'))
  ps=[]
  for p in candidates:
   if not p.exists():continue
   m=p.lstat()
   if m.st_size==item['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']:ps.append(p)
  assert ps,item
  m=ps[0].lstat();key=(m.st_dev,m.st_ino);assert key not in keys
  for p in ps:
   v=p.lstat();assert p.resolve()==p and p.is_relative_to(b)and stat.S_ISREG(v.st_mode)and v.st_uid==os.getuid()and(v.st_dev,v.st_ino)==key and v.st_nlink==m.st_nlink
  proof=item|dict(paths=sorted(str(p.relative_to(b))for p in ps),links=m.st_nlink)
  proofs.append(proof);keys[key]=proof
 aliases={key:[]for key in keys}
 for base,dirs,names in os.walk(b):
  for name in names:
   p=Path(base)/name;m=p.lstat();key=(m.st_dev,m.st_ino)
   if key in keys:aliases[key].append(str(p.relative_to(b)))
 for key,proof in keys.items():assert sorted(aliases[key])==proof['paths']and len(aliases[key])==proof['links']
 print(json.dumps(dict(readOnly=True,freshIdleLease=True,proofs=proofs,current1bceImagesCatalogsToolchainsAndUnmatchedEvidencePreserved=True)))
'''.replace('SUBJECTS',repr(subjects))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60)
(r/'refined-retirement-proof.log').write_text(p.stdout+p.stderr,encoding='utf-8');assert p.returncode==0,p.stdout+p.stderr
(r/'retirement-candidates.json').write_text(p.stdout,encoding='utf-8');print(p.stdout)
