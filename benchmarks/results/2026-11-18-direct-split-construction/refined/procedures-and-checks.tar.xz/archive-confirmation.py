from pathlib import Path
import json,shutil,tarfile
r=Path(__file__).resolve().parent;repo=Path('D:/code/Lython');out=repo/'benchmarks/results/2026-11-18-direct-split-construction/confirmation';out.mkdir(exist_ok=False)
shutil.copyfile(r/'confirmation-summary.json',out/'summary.json')
for n in ['observations.tgz','archive-receipt.json','terminal-status.json','identity.json']:shutil.copyfile(r/'confirmation'/n,out/n)
with tarfile.open(out/'procedures.tar.xz','w:xz')as a:
 for p in sorted((r/'confirmation').rglob('*')):
  if p.is_file()and'retrieved'not in p.relative_to(r/'confirmation').parts and p.suffix in ['.py','.json','.log','.sh']:a.add(p,arcname='confirmation/'+p.relative_to(r/'confirmation').as_posix())
 for n in ['prepare-confirmation.py','launch-confirmation.py','summarize-confirmation.py','archive-confirmation.py']:a.add(r/n,arcname=n)
(out/'README.md').write_text('''# Direct split: unchanged confirmation

R513/B938,2026-11-18UTC. Same frozenf5725c55/qualified1bce52ad32-file images and
catalog as the [first source pair](../initial/README.md); no changed code/diagnostics.
Two text jobs95.75seconds, eight-second rotated preparation/opposite process roles,
five rounds/two processes per source, defaultGC/tiering on the same quiet VM.

| Text phase | Elapsed change | Wider CPU change | Reference/candidate spread |
| --- | ---: | ---: | ---: |
| Warm |+5.80..+8.39%|+2.52..+3.24%|0.38/2.06%|
| Compile-to-result |+1.07..+2.47%|−1.17..+0.56%|1.22/0.17%|

The stable warm reference resolves the earlier6.97%reference movement into a clear
adverse result for this condition. Keep the first warm uncertainty and both fresh
adverse elapsed results; no recovery or source-condition subtraction. Established
allocation−17.319%/accountedpeak−5.63% is separate. Do not promote unchanged.

Select one coherent changed-source refinement inside this construction milestone:
bulk count common single-byte separators and Python line boundaries for sizing,
reserve conservative existing capacity/header/overlap estimates, and write once
through the same semantic scanner. Commit actual retained estimates and refund
unused reservation headroom, never retained storage. Remove repeated sizing-loop
work while keeping final allocation preflight and managed in-loop cancellation.
Keep exact general/cased scans where needed; no new owner/cache/policy or range
inventory restoration. Earlier conservative denial is a documented tradeoff.

Warm/fresh timing boundaries are unchanged. All goldens/quiet/join/Closed/persistent
and localSHA/RAM cleanup pass. No files retired; images reused/hashes verified,
254/252MiBguards unchanged. No new qualification, CPU gain or final design verdict.
[Summary](summary.json),[raw](observations.tgz),[identity](identity.json),
[procedures](procedures.tar.xz). Publication held; broader objective active.
''',encoding='utf-8',newline='\n')
with(repo/'benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as a:a.write('''

R513/B938 [unchanged split confirmation](results/2026-11-18-direct-split-construction/confirmation/README.md), samef572/1bce32-file images: twojobs95.75s/8second rotated prep/opposite roles/all gates/join/SHAarchive. Warm+5.80..+8.39%elapsed/+2.52..+3.24%CPU with0.38/2.06%controls; fresh+1.07..+2.47%elapsed/CPUstraddleszero. Preserve originalwarmuncertainty/freshadversity and17.319%allocation saving separately. Do not promote unchanged; select bounded bulk-count/conservative-capacity/direct-write refinement, keeping real cased iteration and no new memory layer. No source-condition subtraction/CPU gain/permanent failure verdict; publicationheld/objectiveactive.
''')
print('Adverse unchanged confirmation preserved; changed-source refinement selected, no promotion.')
