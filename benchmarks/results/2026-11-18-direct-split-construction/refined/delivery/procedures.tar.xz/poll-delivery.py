from pathlib import Path
import datetime,json,subprocess
r=Path(__file__).resolve().parent/'delivery';r.mkdir(exist_ok=True)
assert not(r/'terminal.json').exists(),'Terminal already cached; do not requery.'
now=datetime.datetime.now(datetime.timezone.utc)
if(r/'next-observation.json').exists():assert now>=datetime.datetime.fromisoformat(json.loads((r/'next-observation.json').read_text(encoding='utf-8'))['notBeforeUTC'])
p=subprocess.run(['gh','run','view','44234151651','--json','databaseId,event,headSha,status,conclusion,jobs,createdAt,updatedAt,url'],capture_output=True,text=True,encoding='utf-8');assert p.returncode==0,p.stderr
v=json.loads(p.stdout);assert v['databaseId']==44234151651 and v['event']=='workflow_dispatch'and v['headSha']=='10ee56c7f53ca6dc1d7a7f688bb5c2437b9592fd'
(r/('observation-'+now.strftime('%Y%m%dT%H%M%SZ')+'.json')).write_text(p.stdout,encoding='utf-8',newline='\n')
(r/'next-observation.json').write_text(json.dumps(dict(notBeforeUTC=(now+datetime.timedelta(seconds=240)).isoformat()),indent=2)+'\n',encoding='utf-8',newline='\n')
if v['status']=='completed':(r/'terminal.json').write_text(p.stdout,encoding='utf-8',newline='\n')
print(json.dumps(dict(run=v['databaseId'],status=v['status'],conclusion=v['conclusion'],head=v['headSha'],jobs=[dict(name=j['name'],status=j['status'],conclusion=j['conclusion'],current=[s['name']for s in j['steps']if s['status']=='in_progress'])for j in v['jobs']],nextObservationUTC=(now+datetime.timedelta(seconds=240)).isoformat())))
