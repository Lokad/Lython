from pathlib import Path
import json
r=Path(__file__).resolve().parent;d=json.loads((r/'delivery/dispatch.json').read_text(encoding='utf-8'))
s=(r.parent/'buffered-yield-r510/finish-delivery.py').read_text(encoding='utf-8')
s=s.replace('44225923745',str(d['run'])).replace('2e5852298b2cb4b6efe13197b95d6f7303b1cfe7',d['head'])
s=s.replace('2388','2389').replace('586','587').replace('all587ProductionInputsMatchMeasured1bce52ad','all587ProductionInputsMatchMeasured2ede09fc')
s=s.replace('benchmarks/results/2026-11-18-buffered-yield-transport/delivery','benchmarks/results/2026-11-18-direct-split-construction/refined/delivery')
(r/'finish-delivery.py').write_text(s,encoding='utf-8',newline='\n')
print('Prepared16summary/2389input/587production verifier; requires actual GREEN terminal.')
