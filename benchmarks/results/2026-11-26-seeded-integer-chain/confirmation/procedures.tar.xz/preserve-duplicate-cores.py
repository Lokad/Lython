from pathlib import Path
import gzip
import hashlib
import json
import re
import subprocess
import sys

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
assert sys.argv[1:] in (['preview'],['reclaim'])
operation = sys.argv[1]
held = lab/'preserved-cores'
held.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
digest=lambda b:hashlib.sha256(b).hexdigest()
sha=lambda p:digest(p.read_bytes())
copies=[]
for name,artifact in (
    ('converted-dictionary-update-20261126','2026-11-26-converted-dictionary-update'),
    ('json-ready-construction-20261126','2026-11-26-json-ready-construction'),
):
    prior=lab.with_name(name)
    local=prior/'frozen/candidate'
    stage=prior/'comparison/quiet'
    report=read(stage/'terminal-status.json')
    receipt=report['receipt']
    assert report['exitCode']=='0' and not report['live'] and not report['fixtures']
    assert all(receipt[key] for key in ('complete','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
    image=read(stage/'identity.json')['imageFiles']['candidate']
    assert len(image)==32 and {p.name:sha(p) for p in local.iterdir()}==image
    path=f'benchmarks/results/{artifact}/observations.tar.xz'
    published=subprocess.check_output(['git','show','origin/master:'+path],cwd=repo)
    assert digest(published)==receipt['archiveSHA256']==sha(stage/'observations.tar.xz')
    unit,=set(re.findall(r'lython-b[a-z0-9-]+\.service',report['journal']))
    core=local/'Lokad.Lython.dll'
    backup=held/(artifact+'.dll.gz')
    if operation=='preview' and not backup.exists(): backup.write_bytes(gzip.compress(core.read_bytes(),mtime=0))
    assert digest(gzip.decompress(backup.read_bytes()))==image[core.name]
    copies.append(dict(stage=read(stage/'upload.json')['root'],unit=unit,
        bytes=core.stat().st_size,authoritativeImage=str(local),backup=str(backup),image=image,
        archive=path,archiveSHA256=receipt['archiveSHA256']))
upload=read(lab/'chain-quiet/upload.json')
packed=dict(copies=copies,operation=operation,need=upload['payloadBytes']+upload['expandedBytes']+5*1024*1024+256*1024)
remote=r'''
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=Path('/home/lokad/lython-bench-checks')
assert base.resolve()==base
with (base/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert not any(p.is_mount() for p in base.glob('*/guest-fixtures'))
    before=shutil.disk_usage(base).free
    paths=[]
    for claim in cfg['copies']:
        stage=base/claim['stage']
        frozen=stage/'candidate'
        file=frozen/'Lokad.Lython.dll'
        archive=stage/'observations.tar.xz'
        assert stage.parent==base and stage.resolve()==stage and file.resolve()==file and archive.resolve()==archive
        state=subprocess.check_output(['systemctl','show',claim['unit'],'--property=ActiveState,MainPID'],text=True).splitlines()
        assert 'ActiveState=inactive' in state and 'MainPID=0' in state,state
        assert {p.name:sha(p) for p in frozen.iterdir()}==claim['image']
        receipt=json.loads((stage/'archive-receipt.json').read_text())
        assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
        assert receipt['archiveSHA256']==claim['archiveSHA256']==sha(archive)
        info=file.lstat()
        assert stat.S_ISREG(info.st_mode) and info.st_uid==os.getuid() and info.st_nlink==1
        assert info.st_size==claim['bytes']
        paths.append((file,info.st_blocks*512,archive,claim['archiveSHA256']))
    expected=before+sum(blocks for _,blocks,_,_ in paths)
    assert expected>=cfg['need'],(before,expected,cfg['need'])
    if cfg['operation']=='reclaim':
        for file,_,archive,digest in paths:
            file.unlink()
            assert sha(archive)==digest
    print(json.dumps(dict(before=before,after=shutil.disk_usage(base).free,expected=expected,
       requirement=cfg['need'],operation=cfg['operation'],copies=[str(file.relative_to(base)) for file,_,_,_ in paths])))
'''
if operation=='reclaim':
    original=read(lab/'chain-quiet/duplicate-core-preview.json')
    assert original['result']['operation']=='preview' and original['copies']==copies
key=Path.home()/'.ssh/id_lython-bench.pem'
result=subprocess.run(['ssh','-i',str(key),'-o','BatchMode=yes','-o','ConnectTimeout=12',
    'lokad@20.166.121.73','python3 -'],input='cfg='+repr(packed)+'\n'+remote,
    encoding='utf-8',capture_output=True,timeout=45)
if result.returncode:
    print(result.stderr)
    result.check_returncode()
report=dict(result=json.loads(result.stdout),copies=copies)
(lab/f'chain-quiet/duplicate-core-{operation}.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n')
print(report['result'])
