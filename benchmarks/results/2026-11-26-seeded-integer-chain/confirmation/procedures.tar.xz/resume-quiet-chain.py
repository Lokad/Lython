from datetime import datetime,timedelta,timezone
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab=Path(__file__).resolve().parent
quiet=lab/'chain-quiet'
prior=lab.with_name('post-row-cpython-20261126')/'comparison/quiet/identity.json'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
identity=read(quiet/'identity.json')
assert 'expectedCPythonSHA256' not in identity
original=quiet/'original-identity.json'
shutil.copyfile(quiet/'identity.json',original)
external=read(prior)
assert external['imageFiles']['candidate']==identity['imageFiles']['reference']
assert external['cpythonWorkerSHA256']==identity['cpythonWorkerSHA256']
identity['expectedCPythonSHA256']=external['expectedCPythonSHA256']
current=json.dumps(identity,indent=2)+'\n'
configuration=read(quiet/'upload.json')
configuration.update(original=sha(original), corrected=hashlib.sha256(current.encode()).hexdigest(),
    identity=current, unit='lython-b1787-seeded-integer-chain-20261126')
remote=r'''
from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks')
root=base/cfg['root']
unit=cfg['unit']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert base.resolve()==base and root.parent==base and root.resolve()==root and root.is_dir()
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 state=subprocess.run(['systemctl','show',unit+'.service','--property=LoadState,ActiveState,MainPID'],
                       capture_output=True,text=True).stdout.splitlines()
 assert 'LoadState=not-found' in state and 'ActiveState=inactive' in state and 'MainPID=0' in state,state
 assert not (root/'guest-fixtures').exists() and not (base/(cfg['root']+'.tar.gz')).exists()
 assert sha(root/'identity.json')==cfg['original']
 original=json.loads((root/'identity.json').read_text())
 image=json.loads(cfg['identity'])
 assert set(image)==set(original)|{'expectedCPythonSHA256'}
 assert all(image[k]==v for k,v in original.items())
 donor=base/'fixed-row-local-bindings-b1783-20261126'
 assert sha(donor/'observations.tar.xz')==cfg['donorSHA256']
 assert (root/'reference').resolve()==donor/'candidate'
 for role,files in image['imageFiles'].items():
  assert len(files)==32 and {p.name:sha(p) for p in (root/role).iterdir()}==files
 for name,meta in image['catalogs'].items(): assert sha(root/name)==meta['sha256']
 assert sha(root/'cpython-worker.py')==image['cpythonWorkerSHA256']
 python=Path.home()/'lython-bench-toolchains/cpython/3.13.16/bin/python3.13'
 assert sha(python)==image['expectedCPythonSHA256']
 assert shutil.disk_usage(base).free>4*1024*1024
 (root/'identity.tmp').write_text(cfg['identity'])
 (root/'identity.tmp').replace(root/'identity.json')
 assert sha(root/'identity.json')==cfg['corrected']
 sdk=Path.home()/'lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148'
 worker=root/'candidate/Lokad.Lython.Benchmarks.dll'
 verifier=root/'remote-verify.json'
 subprocess.run([sdk/'dotnet',worker,'--compare','verify','--catalog',root/'representative.json',
  '--dotnet',sdk/'dotnet','--python',python,'--python-worker',root/'cpython-worker.py','--out',verifier],
  cwd=root,env=dict(os.environ,DOTNET_ROOT=str(sdk)),check=True,timeout=36)
 proof=json.loads(verifier.read_text())
 assert proof['state']=='Completed' and proof['caseCount']==4
 assert proof['catalogSha256']==image['catalogs']['representative.json']['sha256']
 assert proof['launched']['library']['sha256']==image['coreSHA256']['candidate']
 print(json.dumps(dict(verifiedOriginalState=state,change='add frozen CPython digest',
    freeBeforeLaunchBytes=shutil.disk_usage(base).free)),flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit='+unit,'--property=User=lokad','--property=WorkingDirectory='+str(root),
 '--property=RuntimeMaxSec=285','--property=TimeoutStopSec=20','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
'''
key=Path.home()/'.ssh/id_lython-bench.pem'
result=subprocess.run(['ssh','-i',str(key),'-o','BatchMode=yes','-o','ConnectTimeout=12',
 'lokad@20.166.121.73','python3 -'],input='cfg='+repr(configuration)+'\n'+remote,
 encoding='utf-8',capture_output=True,timeout=50)
write(quiet/'resume-launch.log',result.stdout+result.stderr)
if result.returncode:
    print(result.stdout+result.stderr)
    result.check_returncode()
write(quiet/'identity.json',current)
write(quiet/'observe-not-before',(datetime.now(timezone.utc)+timedelta(seconds=205)).isoformat())
print(result.stdout+result.stderr)
