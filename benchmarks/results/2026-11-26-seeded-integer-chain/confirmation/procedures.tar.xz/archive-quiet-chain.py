from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
local = lab/'local'
quiet = lab/'chain-quiet'
target = repo/'benchmarks/results/2026-11-26-seeded-integer-chain/confirmation'
read = lambda p:json.loads(p.read_text(encoding='utf-8'))
sha = lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
status = read(quiet/'terminal-status.json')
receipt = status['receipt']
assert status['exitCode']=='0' and not status['live'] and not status['fixtures']
assert all(receipt[key] for key in ('complete','quietBeforeAndAfter','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
assert receipt['archiveSHA256']==sha(quiet/'observations.tar.xz')
assert read(quiet/'summary.json')['timedBatches']==140 and receipt['warmJobs']==5
initial, confirmation = (read(folder/'identity.json') for folder in (local,quiet))
assert initial['imageFiles']==confirmation['imageFiles']
assert initial['sourcePatchSHA256']==confirmation['sourcePatchSHA256']
assert confirmation['localArchiveSHA256']==sha(local/'observations.tar.xz')
assert sha(quiet/'representative.json')==sha(local/'representative.json')
original = read(quiet/'original-identity.json')
assert set(confirmation)==set(original)|{'expectedCPythonSHA256'}
assert all(confirmation[key]==value for key,value in original.items())
verification = read(quiet/'remote-verify.json')
assert verification['state']=='Completed' and verification['caseCount']==4
assert verification['catalogSha256']==confirmation['catalogs']['representative.json']['sha256']
assert verification['launched']['library']['sha256']==confirmation['coreSHA256']['candidate']

target.mkdir(exist_ok=True)
for name in ('identity.json','summary.json','observations.tar.xz','terminal-status.json'):
    shutil.copyfile(quiet/name,target/name)
with tarfile.open(target/'procedures.tar.xz','w:xz') as archive:
    for name in ('prepare-quiet-chain.py','quiet-chain.py','resume-quiet-chain.py','preserve-duplicate-cores.py',
        'summarize-quiet-chain.py','archive-quiet-chain.py','retrieve-chain-quiet.log'):
        archive.add(lab/name,arcname=name)
    for name in ('duplicate-core-preview.json','duplicate-core-reclaim.json','remote-verify.json',
                 'upload.json','resume-launch.log','original-identity.json','initial-launch-failure.json'):
        archive.add(quiet/name,arcname=name)
