from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
donor = lab.with_name('fixed-row-local-bindings-20261126')
local = lab/'local'
quiet = lab/'chain-quiet'
quiet.mkdir()
read = lambda p:json.loads(p.read_text(encoding='utf-8'))
sha = lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write = lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
save = lambda p,o:write(p,json.dumps(o,indent=2)+'\n')

def replace(text, edits):
    for before,after in edits:
        assert text.count(before)==1,before
        text=text.replace(before,after)
    return text

base = donor/'comparison/quiet'
identity=read(local/'identity.json')
receipt=read(base/'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['archiveSHA256']==sha(base/'observations.tar.xz')
assert identity['imageFiles']['reference']==read(base/'identity.json')['imageFiles']['candidate']
candidate = local/'candidate'
assert len(identity['imageFiles']['candidate'])==32
assert {p.name:sha(p) for p in candidate.iterdir()}==identity['imageFiles']['candidate']
for name in ('representative.json','cpython-worker.py','run.sh'):
    shutil.copyfile(local/name,quiet/name)
jobs=read(local/'jobs.json')['warm']
assert len(jobs)==6
save(quiet/'jobs.json',{'warm':[jobs[i] for i in (3,1,0,2,4)]})
identity['catalogs']['jobs.json']['sha256']=sha(quiet/'jobs.json')
identity['localArchiveSHA256']=sha(local/'observations.tar.xz')
identity['purpose']='Retest ordinary factory, escaping rules, invoice and file-search control on the quiet VM.'
save(quiet/'identity.json',identity)
collector = replace((base/'collect.py').read_text(encoding='utf-8'), [('lython-b1783-fixtures','lython-b1787-fixtures')])
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
entries=[('new-core.dll',candidate/'Lokad.Lython.dll')]
entries.extend((name,quiet/name) for name in ('identity.json','representative.json','jobs.json','collect.py','run.sh','cpython-worker.py'))
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=6) as package:
    for name,path in entries: package.add(path,arcname=name,recursive=False)
save(quiet/'upload.json',dict(root='seeded-integer-chain-b1787-20261126',payloadSHA256=sha(payload),
    payloadBytes=payload.stat().st_size,expandedBytes=sum(p.stat().st_size for _,p in entries),
    donorSHA256=receipt['archiveSHA256']))
launcher=replace((donor/'quiet.py').read_text(encoding='utf-8'),[
    ("quiet=lab/'comparison/quiet'","quiet=lab/'chain-quiet'"),
    ('lython-b1783-fixed-row-local-bindings-20261126','lython-b1787-seeded-integer-chain-20261126'),
    ('borrowed-loop-iterators-b1782-20261126','fixed-row-local-bindings-b1783-20261126'),
])
compile(launcher,'quiet-chain.py','exec')
write(lab/'quiet-chain.py',launcher)
summary=replace((donor/'summarize-quiet.py').read_text(encoding='utf-8'),[("quiet = lab / 'comparison/quiet'","quiet = lab / 'chain-quiet'")])
compile(summary,'summarize-quiet-chain.py','exec')
write(lab/'summarize-quiet-chain.py',summary)
