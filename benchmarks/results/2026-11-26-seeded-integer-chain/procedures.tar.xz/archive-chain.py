from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
local = lab/'local'
root = repo/'benchmarks/results/2026-11-26-seeded-integer-chain'
read = lambda p:json.loads(p.read_text(encoding='utf-8'))
sha = lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity = read(local/'identity.json')
receipt = read(local/'archive-receipt.json')
assert receipt['archiveSHA256'] == sha(local/'observations.tar.xz')
assert all(receipt[key] for key in ('complete','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
assert receipt['quietBeforeAndAfter'] is None
assert receipt['warmJobs'] == 6 and read(local/'summary.json')['timedBatches'] == 168
assert sha(lab/'candidate.patch') == identity['sourcePatchSHA256']
for side in ('reference','candidate'):
    proof = read(lab/(side + '-verify.json'))
    assert proof['state']=='Completed' and proof['caseCount']==4
    assert proof['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert proof['launched']['library']['sha256']==identity['coreSHA256'][side]
    assert all(row['sharedBudgetBaselineRestored'] for row in read(lab/(side+'-allocation.json'))['rows'])
assert all(row['peak'][0] == row['peak'][1] for row in read(lab/'allocation-summary.json'))
routes = lab/'routes'
assert read(routes/'identity.json')['sourcePatchSHA256'] == identity['sourcePatchSHA256']
assert len(read(routes/'counts.json')['rows']) == 8

root.mkdir(exist_ok=False)
for name in ('summary.json','identity.json','observations.tar.xz','archive-receipt.json'):
    shutil.copyfile(local/name,root/name)
for name in ('candidate.patch','allocation-summary.json'):
    shutil.copyfile(lab/name,root/name)
shutil.copyfile(routes/'counts.json',root/'routes.json')
with tarfile.open(root/'procedures.tar.xz','w:xz') as archive:
    for name in ('prepare-chain.py','prepare-chain.log','summarize-chain.py','archive-chain.py',
        'reference-verify.json','candidate-verify.json','reference-allocation.json','candidate-allocation.json',
        'run-chain.log','routes-chain.py','routes-chain.log','test-ubuntu.sh'):
        archive.add(lab/name,arcname=name)
    for name in ('diagnostic.patch','identity.json','Program.cs','RouteProbe.csproj','build-core.log','run.log'):
        archive.add(routes/name,arcname='routes/'+name)
    for suite, count in (('Lokad.Lython.Tests',604),('Lokad.Lython.PublicApi.Tests',1688)):
        for target in ('win11','ubuntu10'):
            name = f'{suite}-{target}.log'
            path = lab/name
            assert f'Passed:  {count:4d}' in path.read_text(encoding='utf-8').splitlines()[-1]
            archive.add(path,arcname=name)
