from pathlib import Path
from statistics import median
import hashlib
import json
import os
import shutil
import subprocess
import sys

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
reference = lab.with_name('fixed-row-local-bindings-20261126')
external = lab.with_name('post-row-cpython-20261126') / 'comparison/quiet'
prior = lab.with_name('prepared-integer-continuations-20261122')
tool = lab.with_name('json-traversal-20261124') / 'reference'
local = lab / 'local'
core = 'Lokad.Lython.dll'
candidate = Path(sys.argv[1]).resolve()

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def manifest(folder):
    return {file.name: sha(file) for file in folder.iterdir()}

head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
old = read(external / 'identity.json')
subprocess.run(['git', 'diff', '--exit-code', old['sourceRevision'], head, '--', 'src'], cwd=repo, check=True)
patch = subprocess.check_output(['git', 'diff', '--binary', 'HEAD', '--', 'src'], cwd=repo)
assert patch.count(b'diff --git ') == 2 and b'TryContinueIntegerChain' in patch
assert candidate.name == core and candidate.is_file()
local.mkdir()
(lab / 'candidate.patch').write_bytes(patch)
baseline = reference / 'local/candidate'
assert len(old['imageFiles']['candidate']) == 32 and manifest(baseline) == old['imageFiles']['candidate']
images = {}
for role in ('reference', 'candidate'):
    folder = local / role
    shutil.copytree(baseline, folder)
    assert manifest(folder) == old['imageFiles']['candidate']
    if role == 'candidate':
        shutil.copyfile(candidate, folder / core)
    images[role] = manifest(folder)
assert {name for name, digest in images['reference'].items() if images['candidate'][name] != digest} == {core}

ordinary = 'diagnostic.generated-ordinary-definitions'
escaping = 'scripts.rule-default-closures'
invoice = 'scripts.csv-invoice.large'
search = 'scripts.file-search.large'
catalog = read(external / 'representative.json')
catalog['cases'] = [case for case in catalog['cases'] if case['id'] in (ordinary, escaping)]
locations = [p for p in prior.glob('**/representative.json') if 'local' in p.parts or 'quiet' in p.parts]
locations += [p for p in prior.glob('**/catalog.json') if 'local' in p.parts or 'quiet' in p.parts]
known = [case for file in locations for case in read(file)['cases'] if case['id'] == invoice]
assert known and len({(case['sourceSha256'],case['fixtureSha256']) for case in known}) == 1
catalog['cases'].append(known[0])
catalog['cases'].append(next(case for case in read(reference / 'local/representative.json')['cases'] if case['id']==search))
assert {case['id'] for case in catalog['cases']} == {ordinary, escaping, invoice, search}
save(local / 'representative.json', catalog)
save(local / 'jobs.json', dict(warm=[[search, 'warm'], [ordinary, 'warm-async'], [escaping, 'warm'],
    [invoice, 'warm'], [ordinary, 'warm'], [escaping, 'warm-async']]))
shutil.copyfile(external / 'cpython-worker.py', local / 'cpython-worker.py')
assert sha(local / 'cpython-worker.py') == old['cpythonWorkerSHA256']
identity = dict(sourceRevision=head, sourcePatchSHA256=sha(lab / 'candidate.patch'), imageFiles=images,
    coreSHA256={role + label: files[core] for role, files in images.items() for label in ('', '-control')},
    cpythonWorkerSHA256=old['cpythonWorkerSHA256'],
    catalogs={name: {'sha256': sha(local / name)} for name in ('representative.json', 'jobs.json')},
    purpose='Enter only actual integer continuations after a single first arithmetic operation.')
save(local / 'identity.json', identity)

template = reference / 'local'
collector = (template / 'collect.py').read_text(encoding='utf-8')
for before, after in [
    ('len(jobs) == 5', 'len(jobs) == 6'),
    ('lython-json-default-decoder-fixture-', 'lython-seeded-integer-chain-fixture-'),
    ('4 seconds full-request time', '3 seconds full-request time'),
    ('warmupSeconds=4, targetBatchSeconds=.35', 'warmupSeconds=3, targetBatchSeconds=.30'),
]:
    assert collector.count(before) == 1
    collector = collector.replace(before, after)
compile(collector, 'collect.py', 'exec')
(local / 'collect.py').write_text(collector, encoding='utf-8', newline='\n')
shutil.copyfile(template / 'run.sh', local / 'run.sh')
assert b'\r' not in (local / 'run.sh').read_bytes()

sdk = Path.home() / '.dotnet11'
dotnet = sdk / 'dotnet.exe'
settings = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
allocations = {}
for role, files in images.items():
    image = local / role
    verification = lab / (role + '-verify.json')
    subprocess.run([dotnet, image / 'Lokad.Lython.Benchmarks.dll', '--compare', 'verify', '--catalog',
        local / 'representative.json', '--dotnet', dotnet, '--python', 'C:/Python313/python.exe',
        '--python-worker', local / 'cpython-worker.py', '--out', verification], cwd=repo,
        env=settings, check=True, timeout=85)
    proof = read(verification)
    assert proof['state'] == 'Completed' and proof['caseCount'] == 4
    assert proof['catalogSha256'] == identity['catalogs']['representative.json']['sha256']
    assert proof['launched']['library']['sha256'] == files[core]
    allocated = lab / (role + '-allocated')
    shutil.copytree(image, allocated)
    for probe_file in tool.glob('ValidatedAllocation*'):
        shutil.copyfile(probe_file, allocated / probe_file.name)
    output = lab / (role + '-allocation.json')
    subprocess.run([dotnet, allocated / 'ValidatedAllocation.dll', allocated, local / 'representative.json',
        output], cwd=repo, env=settings, check=True, timeout=65)
    allocations[role] = read(output)['rows']
comparisons = []
for before, after in zip(allocations['reference'], allocations['candidate'], strict=True):
    assert before['id'] == after['id'] and before['sharedBudgetBaselineRestored'] and after['sharedBudgetBaselineRestored']
    comparisons.append(dict(case=before['id'],
        bytes=[median(row['allocatedBytesPerInvocation']) for row in (before, after)],
        peak=[row['peakExecutionMemoryBytes'] for row in (before, after)]))
save(lab / 'allocation-summary.json', comparisons)
print(json.dumps(comparisons))
