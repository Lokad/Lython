#!/bin/bash
set -euo pipefail
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
cd /mnt/d/code/Lython
lab="$PWD/.git/agent-notes/review-20261031/json-shared-prefix-20261127"
export NUGET_PACKAGES="$PWD/.git/agent-notes/review-20261031/regex-released-050-20261127/packages-ubuntu"
public=tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj
internal=tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj
public_filter='Category!=Stress&(FullyQualifiedName~Json|FullyQualifiedName~DictWriter|FullyQualifiedName~NativeDictionary)'
internal_filter='Category!=Stress&(FullyQualifiedName~Json|FullyQualifiedName~RecordKeyOwnership|FullyQualifiedName~RecordFieldLookup|FullyQualifiedName~DictionaryIntegerValue)'
dotnet restore "$public" --locked-mode --artifacts-path "$lab/ubuntu" --source https://api.nuget.org/v3/index.json
dotnet restore "$internal" --locked-mode --artifacts-path "$lab/ubuntu" --source https://api.nuget.org/v3/index.json
for framework in net10.0 net11.0; do
  dotnet test "$public" -c Release -f "$framework" --no-restore --artifacts-path "$lab/ubuntu" --filter "$public_filter"
  dotnet test "$internal" -c Release -f "$framework" --no-restore --artifacts-path "$lab/ubuntu" --filter "$internal_filter"
done
