from base64 import b64decode, b64encode
from copy import deepcopy
from hashlib import sha256
from pathlib import Path
from shutil import copyfile, copytree
from statistics import median
import json
import os
import subprocess


root = Path(__file__).resolve().parent
repo = root.parents[3]
source = root.parent / 'wsl-nested-json-cpython-20261127'
regex_source = root.parent / 'pattern-one-shot-20261127/comparison/quiet'
pair = root / 'comparison'
pair.mkdir()
read = lambda path: json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')


def image(folder):
    return {path.name: digest(path) for path in folder.iterdir()}


def diff(*args):
    return subprocess.check_output(['git', 'diff', '--binary', *args], cwd=repo)


original = read(source / 'identity.json')
regex = read(regex_source / 'identity.json')
assert digest(regex_source / 'representative.json') == regex['catalogs']['representative.json']['sha256']
core = 'Lokad.Lython.dll'
adapter = 'Lokad.Lython.Utf8Regex.dll'
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert not diff(original['sourceRevision'], base, '--', 'src')
assert not diff(base, '--', 'src/Lokad.Lython.Utf8Regex')
patch = diff(base, '--', 'src')
assert b'dictionary.SharedRecordKeys' in patch and patch.count(b'diff --git ') == 2
assert diff(base, '--', 'src/Lokad.Lython') == patch
(root / 'candidate.patch').write_bytes(patch)
(root / 'regression.patch').write_bytes(diff(base, '--', 'tests'))
assert image(source / 'candidate') == original['imageFiles']['candidate']
for role in ('reference', 'candidate'):
    copytree(source / 'candidate', pair / role)
bins = repo / 'tests/Lokad.Lython.PublicApi.Tests/bin/Release/net11.0'
fresh = bins / core
assert digest(fresh) == digest(repo / 'src/Lokad.Lython/bin/Release/net11.0' / core)
copyfile(fresh, pair / 'candidate' / core)
images = {role: image(pair / role) for role in ('reference', 'candidate')}
assert [name for name, before in images['reference'].items() if images['candidate'][name] != before] == [core]
for name in regex['signedPackageSHA256']:
    assert digest(bins / name) == images['reference'][name] == regex['imageFiles']['candidate'][name]
copyfile(source / 'cpython-worker.py', pair / 'cpython-worker.py')
assert digest(pair / 'cpython-worker.py') == original['cpythonWorkerSHA256'] == regex['cpythonWorkerSHA256']

catalog = read(source / 'representative.json')
assert digest(source / 'representative.json') == original['catalogs']['representative.json']['sha256']
document = 'diagnostic.nested-json-document'
lines = 'diagnostic.nested-json-lines'
file_map = 'diagnostic.shipment-file-fed-map'
case = deepcopy(next(case for case in catalog['cases'] if case['id'] == lines))
sparse = lines + '.optional-details'
case['id'] = sparse
fixture = json.loads(case['fixtureJson'])
payload = b64decode(fixture['inputFiles']['input.jsonl'])
rows = []
output = []
for line in payload.splitlines(keepends=True):
    if line.strip():
        row = json.loads(line)
        assert list(row['details']) == ['amount']
        if len(rows) % 2 == 0:
            row['details'].update({'currency': 'EUR', 'memo': 'facturé'})
            newline = line[len(line.rstrip(b'\r\n')):]
            line = json.dumps(row, ensure_ascii=False, separators=(',', ':')).encode('utf-8') + newline
        rows.append(row)
    output.append(line)
assert len(rows) == 4096
owned = b''.join(output)
fixture['inputFiles']['input.jsonl'] = b64encode(owned).decode('ascii')
case['fixtureJson'] = json.dumps(fixture, separators=(',', ':'))
case['fixtureSha256'] = sha256(case['fixtureJson'].encode('utf-8')).hexdigest()
catalog['cases'].append(case)
write(root / 'fixture-census.json', dict(denseLinesBytes=len(payload), optionalLinesBytes=len(owned),
    rows=len(rows), optionalRows=sum('memo' in row['details'] for row in rows),
    retainedGoldens=['expectedOutputSha256', 'expectedFilesSha256']))
jobs = [[sparse, 'warm'], [document, 'warm'], [sparse, 'warm-async'], [lines, 'warm-async'], [file_map, 'warm-async']]
write(pair / 'representative.json', catalog)
write(pair / 'jobs.json', {'warm': jobs})
identity = dict(sourceRevision=base, productionReference=original['sourceRevision'],
                sourcePatchSHA256=digest(root / 'candidate.patch'), imageFiles=images,
                coreSHA256={role+suffix: hashes[core] for role, hashes in images.items()
                            for suffix in ('', '-control')},
                cpythonWorkerSHA256=original['cpythonWorkerSHA256'], cpythonPath=original['cpythonPath'],
                expectedCPythonSHA256=original['expectedCPythonSHA256'],
                signedPackageSHA256=regex['signedPackageSHA256'],
                purpose='Retain shared JSON record layouts when an object omits its trailing optional fields.')
identity['catalogs'] = {name: {'sha256': digest(pair / name)} for name in ('representative.json', 'jobs.json')}
write(pair / 'identity.json', identity)
driver = root.parent / 'borrow-regex-arguments-20261127/comparison'
collector = (driver / 'collect.py').read_text(encoding='utf-8')
collector = collector.replace('lython-b1887-borrow-regex-arguments-', 'lython-b1889-json-shared-prefix-').replace('assert len(jobs) == 4', 'assert len(jobs) == 5')
compile(collector, 'collect.py', 'exec')
(pair / 'collect.py').write_text(collector, encoding='utf-8', newline='\n')
copyfile(driver / 'run.sh', pair / 'run.sh')
assert b'\r' not in (pair / 'run.sh').read_bytes()

allocation = root / 'allocation'
allocation.mkdir()
witness = root.parent / 'pattern-one-shot-20261127/local/candidate-allocated'
for role, files in images.items():
    folder = allocation / role
    copytree(pair / role, folder)
    for path in witness.glob('ValidatedAllocation*'):
        copyfile(path, folder / path.name)
    assert (folder / 'ValidatedAllocation.dll').is_file()
    assert all(digest(folder / name) == checksum for name, checksum in files.items())
sdk = Path.home() / '.dotnet11'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
rows = []
for mode in ('sync', 'async'):
    for case in catalog['cases']:
        case['runAsync'] = mode == 'async'
    selection = allocation / f'{mode}-catalog.json'
    write(selection, catalog)
    comparisons = []
    for role in images:
        folder = allocation / role
        report = allocation / f'{role}-{mode}.json'
        subprocess.run([sdk / 'dotnet.exe', folder / 'ValidatedAllocation.dll', folder, selection, report],
                       env=env, check=True, timeout=100)
        comparisons.append(read(report)['rows'])
    for before, after in zip(*comparisons, strict=True):
        assert before['id'] == after['id']
        assert before['sharedBudgetBaselineRestored'] and after['sharedBudgetBaselineRestored']
        row = dict(case=before['id'], mode=mode,
                   clr=[median(r['allocatedBytesPerInvocation']) for r in (before, after)],
                   peak=[r['peakExecutionMemoryBytes'] for r in (before, after)],
                   compiled=[r['compiledReservedBytes'] for r in (before, after)])
        rows.append(row)
        print(row, flush=True)
write(allocation / 'summary.json', rows)
