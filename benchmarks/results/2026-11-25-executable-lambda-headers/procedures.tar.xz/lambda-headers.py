from __future__ import annotations

events = []
payload = []


def mark(label, value):
    events.append(label)
    return value


def skipped() -> (lambda unused=mark('unused', 0): unused):
    pass


def make(seed):
    return [lambda initial=mark('factory', seed + i): lambda: initial
            for i in range(2)]


type Deferred = (lambda item=(lambda value=mark('lazy', payload): value)(): item)()


class Holder:
    local = 8
    method = lambda self, initial=mark('class', local): (yield initial)


first, second = make(10)
print(first()(), second()(), list(Holder().method()), events)
print(Deferred.__value__ is payload, Deferred.__value__ is payload, events)
