set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab="$PWD/.git/agent-notes/review-20261031/executable-lambda-headers-20261125"
filter='(FullyQualifiedName~Lambda|FullyQualifiedName~Frontend|FullyQualifiedName~Scope|FullyQualifiedName~Annotation|FullyQualifiedName~Default|FullyQualifiedName~Generator|FullyQualifiedName~Cancellation|FullyQualifiedName~Ownership)&Category!=Stress'
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
  logfile="$lab/$suite-ubuntu10.log"
  if dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$logfile" 2>&1; then
    tail -4 "$logfile"
  else
    tail -55 "$logfile"
    exit 1
  fi
done
