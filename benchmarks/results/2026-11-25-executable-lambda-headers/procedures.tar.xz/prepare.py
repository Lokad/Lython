from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
quiet = lab / "comparison/quiet"
donor = lab.with_name("borrowed-builtin-bindings-20261125")
procedures = lab.with_name("closed-default-store-links-20261125")
read = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, text):
    path.write_text(text, encoding="utf-8", newline="\n")

identity = read(quiet / "identity.json")
for role, files in identity["imageFiles"].items():
    assert {path.name: sha(path) for path in (lab / role).iterdir()} == files
    verified = read(lab / "comparison" / (role + "-verify.json"))
    assert verified["state"] == "Completed" and verified["caseCount"] == 4

collector = (procedures / "comparison/quiet/collect.py").read_text(encoding="utf-8")
collector = collector.replace("b1711-fixtures", "b1716-fixtures").replace("len(jobs) == 8", "len(jobs) == 6")
collector = collector.replace("targetBatchSeconds=.59", "targetBatchSeconds=.48")
collector = collector.replace("started < 394", "started < 315")
compile(collector, "collect.py", "exec")
write(quiet / "collect.py", collector)
shutil.copyfile(procedures / "comparison/quiet/run.sh", quiet / "run.sh")
assert b"\r" not in (quiet / "run.sh").read_bytes()
launcher = (donor / "quiet.py").read_text(encoding="utf-8")
launcher = launcher.replace("lython-b1715-borrowed-builtin-bindings", "lython-b1716-executable-lambda-headers")
launcher = launcher.replace("b1715", "b1716").replace("if name=='Lokad.Lython.dll' and role=='candidate':", "if name=='Lokad.Lython.dll':")
launcher = launcher.replace("'candidate-core.dll'}", "'candidate-core.dll','reference-core.dll'}")
launcher = launcher.replace("RuntimeMaxSec=382", "RuntimeMaxSec=332").replace("seconds=300", "seconds=240")
anchor = read(donor / "comparison/quiet/terminal-status.json")["receipt"]
assert anchor["complete"] and sha(donor / "comparison/quiet/observations.tar.xz") == anchor["archiveSHA256"]
a = launcher.index("assert donor['archiveSHA256']=='")
b = launcher.index("\n", a)
launcher = launcher[:a] + "assert donor['archiveSHA256']==" + repr(anchor["archiveSHA256"]) + launcher[b:]
compile(launcher, "quiet.py", "exec")
write(lab / "quiet.py", launcher)
write(lab / "verified-raw-replicas.json", "[]\n")

payload = quiet / "payload.tar.gz"
with tarfile.open(payload, "w:gz", compresslevel=3) as out:
    for name in ("identity.json", "jobs.json", "representative.json", "run.sh", "collect.py"):
        out.add(quiet / name, arcname=name)
    for role in identity["imageFiles"]:
        out.add(lab / role / "Lokad.Lython.dll", arcname=role + "-core.dll")
write(quiet / "upload.json", json.dumps(dict(root="executable-lambda-headers-b1716-20261125",
    reference="borrowed-builtin-bindings-b1715-20261125", payloadSHA256=sha(payload),
    payloadBytes=payload.stat().st_size), indent=2) + "\n")
for name in ("compile-allocation.py", "allocations.py"):
    shutil.copyfile(procedures / name, lab / name)
