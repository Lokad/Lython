from pathlib import Path
import ast,hashlib,json,subprocess,tarfile
base=Path(__file__).parent;old=base.parent/'ordered-native-r289/cpu-gate';out=base/'report-cpu';out.mkdir()
root='/home/lokad/lython-bench-checks/report-cpu-b649-20261113';oldroot='/home/lokad/lython-bench-checks/captured-cpu-b647-20261112'
ops=(old/'ops-profile.py').read_text(encoding='utf-8').replace(oldroot,root).replace('"captured-text", "scripts.text-summary-helpers.nonlocal-counter.large"','"report", "scripts.report-render.large"')
ops=ops.replace('import datetime','import datetime\nimport gzip\nimport hashlib\nimport stat')
ops=ops.replace('            assert profiler.returncode == 0','''            assert profiler.returncode == 0
            raw = folder/'perf.data'; metadata = raw.lstat()
            assert raw.resolve() == raw and raw.is_relative_to(candidate) and stat.S_ISREG(metadata.st_mode)
            if metadata.st_uid != os.getuid():
                assert metadata.st_uid == 0
                before_hash = subprocess.check_output(['sudo','-n','sha256sum',str(raw)],text=True).split()[0]
                subprocess.run(['sudo','-n','chown',str(os.getuid())+':'+str(os.getgid()),str(raw)],check=True)
                assert raw.stat().st_ino == metadata.st_ino and hashlib.sha256(raw.read_bytes()).hexdigest() == before_hash
                record['joinedPerfDataOwnershipCorrectedWithoutByteChanges'] = True''')
oldstacks="""            with (folder/'perf-stacks.txt').open('w') as stacks:
                subprocess.run(['sudo','-n','perf','script','-i',str(folder/'perf.data'),'--tid',active_tid], stdout=stacks,stderr=subprocess.STDOUT,check=True,timeout=15)"""
assert oldstacks in ops
ops=ops.replace(oldstacks,"""            stacks = subprocess.check_output(['sudo','-n','perf','script','-i',str(folder/'perf.data'),'--tid',active_tid],stderr=subprocess.STDOUT,timeout=15)
            with gzip.open(folder/'perf-stacks.txt.gz','wb') as compressed:compressed.write(stacks)""")
needle='        print(json.dumps({"name": name'
ops=ops.replace(needle,"""        for map_name in ['perf.map','perfinfo.map']:
            path=folder/map_name
            if path.exists():
                blob=path.read_bytes()
                with gzip.open(str(path)+'.gz','wb') as compressed:compressed.write(blob)
                with gzip.open(str(path)+'.gz','rb') as compressed:assert compressed.read()==blob
                path.unlink()
"""+needle)
ast.parse(ops);(out/'ops-profile.py').write_text(ops,encoding='utf-8',newline='\n')
collect=(old/'collect.py').read_text(encoding='utf-8').replace(oldroot,root).replace('profiles/captured-text','profiles/report').replace("source='2d91eb1a/161cd935'","source='917e01d8/9e53b9fa'")
assert "env['DOTNET_ROOT']"in collect
ast.parse(collect);(out/'collect.py').write_text(collect,encoding='utf-8',newline='\n')
(out/'run.sh').write_text('set -eu\nroot='+root+'\ntrap \'result=$?; printf "%s\\n" "$result" > "$root/exit-code.txt"\' EXIT\npython3 "$root/collect.py"\n',encoding='utf-8',newline='\n')
identity=json.loads((base/'b648/identity.json').read_text(encoding='utf-8'));identity.update(sourceRevision='917e01d8/9e53b9fa current whole report CPU source gate; full delivery independently pending',purpose='One eight-second CPU-clock capture,12s warmup, complete report script; normal GC/tiering, PerfMap only; no elapsed comparison')
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
specs=[]
for canonical,member,remote in [
 ('benchmarks/results/2026-11-12-ordered-final-slots/final/b645/observations-partial.tgz','candidate-sources.tar.xz','ordered-native-b645-20261112/candidate-sources.tar.xz'),
 ('benchmarks/results/2026-11-13-direct-range-construction/source-checks.tar.xz','candidate-sources.tar.xz','direct-ranges-b648-20261113/candidate-sources.tar.xz')]:
 p=Path(canonical);blob=subprocess.check_output(['git','show','HEAD:'+p.as_posix()]);assert blob==p.read_bytes()
 with tarfile.open(p)as archive:content=archive.extractfile(member).read()
 specs.append(dict(path=remote,bytes=len(content),sha256=hashlib.sha256(content).hexdigest(),canonical=canonical+'!'+member))
with tarfile.open(out/'payload.tgz','w:gz')as archive:
 for name in ['ops-profile.py','collect.py','run.sh','identity.json']:archive.add(out/name,arcname=name)
config=dict(root=root,unit='lython-b649-report-cpu-20261113',sourceRoot='/home/lokad/lython-bench-checks/direct-ranges-b648-20261113',identity=identity,retire=specs,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest())
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
print('One existing report CPU capture; compressed raw maps/stacks preserved; root perf-file ownership handled after join. No runtime changes.',flush=True)
