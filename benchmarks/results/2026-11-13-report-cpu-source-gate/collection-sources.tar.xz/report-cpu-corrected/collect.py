from pathlib import Path
import fcntl,json,os,subprocess,time,tarfile,hashlib,shutil
root=Path('/home/lokad/lython-bench-checks/report-cpu-b650-20261113')
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 env=os.environ.copy();env['DOTNET_ROOT']='/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148'
 worker=root/'candidate/Lokad.Lython.Benchmarks.dll';dotnet=env['DOTNET_ROOT']+'/dotnet'
 time.sleep(3)
 subprocess.run([dotnet,str(worker),'--compare','check-machine','--out',str(root/'machine-before.json')],env=env,check=True)
 assert json.loads((root/'machine-before.json').read_text())['gate']['quiet']
 subprocess.run(['python3',str(root/'ops-profile.py'),str(root/'profiles')],check=True)
 time.sleep(3)
 subprocess.run([dotnet,str(worker),'--compare','check-machine','--out',str(root/'machine-after.json')],env=env,check=True)
 assert json.loads((root/'machine-after.json').read_text())['gate']['quiet']
 assert not list((root/'guest-fixtures').iterdir())
 record=json.loads((root/'profiles/report/record.json').read_text());assert record['exitCode']==0 and record['closed']['status']=='Closed'
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 subprocess.run(['sudo','-n','umount',str(root/'guest-fixtures')],check=True);(root/'guest-fixtures').rmdir()
 with tarfile.open(root/'observations.tgz','w:gz',dereference=True)as archive:
  for p in sorted(root.rglob('*')):
   if p.is_file()and p.name!='observations.tgz'and not{'candidate'}&set(p.relative_to(root).parts):archive.add(p,arcname=p.relative_to(root).as_posix())
 with tarfile.open(root/'observations.tgz')as archive:assert json.loads(archive.extractfile('profiles/report/record.json').read())['exitCode']==0
 assert shutil.disk_usage(root).free>252*1024*1024
 receipt=dict(complete=True,allWorkersJoined=True,quietBeforeAndAfter=True,guestFixturesRemoved=True,archivedAndVerifiedUnderLease=True,freeBytes=shutil.disk_usage(root).free,archiveSHA256=hashlib.sha256((root/'observations.tgz').read_bytes()).hexdigest(),source='917e01d8/9e53b9fa',performanceComparison=False)
 (root/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
