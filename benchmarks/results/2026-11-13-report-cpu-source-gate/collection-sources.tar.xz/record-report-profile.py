from pathlib import Path
import gzip,hashlib,json,re,shutil,tarfile
r=Path(__file__).parent;src=r/'report-cpu-corrected';failed=r/'report-cpu';out=Path('benchmarks/results/2026-11-13-report-cpu-source-gate');out.mkdir()
d=json.loads((src/'attribution.json').read_text(encoding='utf-8'))
assert d['samples']==1477 and not d['malformedMapLines']and not d['ambiguousLeafSamples']
for folder,archive,receipt in [(src,'observations.tgz','archive-receipt.json'),(failed,'failure-observations.tgz','failure-recovery.json')]:
 info=json.loads((folder/receipt).read_text(encoding='utf-8'));assert hashlib.sha256((folder/archive).read_bytes()).hexdigest()==info['archiveSHA256']
 shutil.copyfile(folder/archive,out/archive);shutil.copyfile(folder/receipt,out/receipt)
for name in ['attribution.json','terminal-status.json']:shutil.copyfile(src/name,out/name)
with tarfile.open(out/'collection-sources.tar.xz','w:xz')as archive:
 for p in r.iterdir():
  if p.is_file()and'profile'in p.name and p.suffix=='.py':archive.add(p,arcname=p.name)
 for sub in [src,failed]:
  for p in sub.iterdir():
   if p.is_file()and p.suffix in ['.py','.json','.log','.sh']:archive.add(p,arcname=sub.name+'/'+p.name)
rows=[]
for name,count in d['topLeafCpuSamples'][:16]:
 match=re.search(r'(?:Lokad\.Lython\.[^ ]+|System\.[^ ]+)::[^ (]+',name)
 label=match[0].split('::')[-1]if match else ('Unmapped kernel leaf'if'kernel'in name else'Unmapped CLR leaf')
 rows.append(f'| {label} | {count} /{100*count/d["samples"]:.2f}% |')
report=(src/'retrieved/profiles/report/perf-report.txt').read_text(encoding='utf-8');assert 'Lost Samples'in report
(out/'README.md').write_text('''# Whole-report CPU source gate — R294 / B649–B650

2026-11-13, committed917e01d8, measured core9e53b9fa; fixed fec79 worker,
optional adapter0.4, actual.NET11RC3 on quiet F4as_v7 /Ubuntu24.04.4. Same complete
JSON-to-Markdown report as the maintained comparisons. Normal GC/tiering, PerfMap
diagnostic override only. Twelve-second warmup and an eight-second CPU-clock/fp
capture at199Hz;7.43 selected guest CPU seconds /7.766851s execution clocks.

1,477 selected samples;150 unknown leaves(10.16%),0 ambiguous leaves and0 malformed
CLR map lines. Complete all-thread CPU, IP intervals and original native stacks
survive. Saved maps/stacks are losslessly compressed only after their users finish.
This is CPU attribution, not wall-time or a source-pair speed comparison. Nearest
frames include inlined, runtime and useful work and are not removable shares.

| Selected leaf | Samples /share |
| --- | --- |
'''+ '\n'.join(rows)+'''

Nearest-frame attribution includes MemoryGovernor.Reserve9.75%, formatted-opcode
execution4.67%, JSON string reading5.69%, JSON construction4.27%, integer formatting
3.86% and ordinary call dispatch2.57%. Do not add these to overlapping leaf shares.

## Source decision

Ordinary native fields already append into the final UTF-8 builder. Integer output
uses managed UTF-8 formatting and final windows; JSON tokens already borrow
immutable input windows and reuse record keys. These observations do not support
another per-character CLR-string conversion project or prove boxed values/call
arrays dominate. Static format descriptors are prepared once, while field/value
evaluation order and genuinely suspending hooks remain in the executable engine.

Inspect complete formatting operand/instruction construction as one potential
follow-on. A useful redesign must eliminate an actual intermediate stage without
reintroducing a second expression graph/controller. Preserve conversion-before-spec
evaluation, lazy/dynamic fields, original failures, hook I/O, exact PC/live values,
cancellation and funded buffers. Source/semantic gates precede a bounded complete
report/compile-to-result comparison with CSV/text controls. No prototype or CPU
speedup follows from these sample shares alone.

This source review also identifies a separate **ownership hypothesis**: shared
byte-builder growth/release publishes storage fields after an external refund.
First prove whether refusal, throwing or reentrant refund can over-release another
retained input's charge, then consolidate the existing publish/commit/refund
transaction. This is a focused correctness gate, not a claim that removing host
budget locks is safe or that9.75% of CPU can be eliminated. No new budget policy,
pool, tracing, global cache or broad ownership audit is proposed.

## Collector correction and limits

B649 captured samples and per-batch goldens but decoded a caller-owned perf file
as root. perf refused that ownership, and the old collector failed before asking
the worker to quit. Its forced exit−9, missing final verification/normal close and
end quiet gate make that capture **partial**. It is preserved, with the original
journal, perf data/maps and recovery metadata. A fresh idle lease joined all users,
preserved the dead worker's maps and removed only its identified orphan runtime
IPC and empty RAM mount. No runtime defect is inferred from this collector failure.

B650 changes offline decoding order/identity only: normal verification, quit,
exit0, map retirement and fixture cleanup happen first; perf decoding runs as the
file owner. Its outputs/allowance balances, Closed/exit0/join, before/after quiet,
RAM unmount and independently verified persistent/local archive all pass. Same
source/workload; one corrected bounded capture, no repeated timing comparisons.
Owner120s/stop30s/margin30s. Last owned VMfree265154560B, no workers/mounts remain.
OS240MiB/evidence12MiB floors remain; exact archived source duplicates were retired
under fresh path/UID/inode/link/SHA proofs. No RSS or embedding-tail claim.

[Valid raw capture](observations.tgz), [attribution](attribution.json),
[receipt](archive-receipt.json), [terminal](terminal-status.json),
[original partial capture](failure-observations.tgz), [recovery](failure-recovery.json),
[collector/analysis sources and failures](collection-sources.tar.xz).
''',encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');p.write_text(p.read_text(encoding='utf-8')+'''

## R294 — complete report CPU gate

[1,477 current-source CPU samples](results/2026-11-13-report-cpu-source-gate/README.md)
retain10.16% unknown leaves and all raw maps/stacks. Existing UTF8/default numeric
formatting and JSON windows are confirmed, not proposed again. Formatting
instruction/operand construction is a follow-on source gate; shared builder refund
publication is a separate focused ownership hypothesis to reproduce first. Original
B649 decoding/forced-close failure and corrected B650 normal shutdown/quiet/balance
gates survive. No timing comparison or removable-CPU share is claimed.
''',encoding='utf-8',newline='\n')
print('R294 CPU source gate and original/corrected collector evidence recorded; no CPU speed claim.',flush=True)
