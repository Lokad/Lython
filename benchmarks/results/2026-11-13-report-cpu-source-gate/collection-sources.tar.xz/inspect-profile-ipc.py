from pathlib import Path
import subprocess
r=Path(__file__).parent/'report-cpu';ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
code='''from pathlib import Path
import fcntl,json,stat
root=Path('/home/lokad/lython-bench-checks/report-cpu-b649-20261113')
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 print(json.dumps([dict(name=p.name,mode=stat.filemode(p.lstat().st_mode),uid=p.lstat().st_uid,resolved=str(p.resolve()))for p in(root/'guest-fixtures').iterdir()]))
'''
done=subprocess.run(ssh+['python3 -'],input=code,capture_output=True,text=True,encoding='utf-8');assert done.returncode==0,done.stderr
(r/'remaining-ipc.json').write_text(done.stdout,encoding='utf-8');print(done.stdout)
