from pathlib import Path
import ast,json,tarfile,hashlib
base=Path(__file__).parent;old=base/'report-cpu';out=base/'report-cpu-corrected';out.mkdir()
oldroot='/home/lokad/lython-bench-checks/report-cpu-b649-20261113';root='/home/lokad/lython-bench-checks/report-cpu-b650-20261113'
ops=(old/'ops-profile.py').read_text(encoding='utf-8').replace(oldroot,root)
start=ops.index("            raw = folder/'perf.data'");end=ops.index('            if perf_mode:\n                perf_map',start)
ownership=ops[start:end]
ops=ops[:start]+ops[end:]
start=ops.index("                with (folder/'perf-report.txt')")
end=ops.index('            record["verificationAfter"]',start)
analysis=ops[start:end]
analysis=analysis.replace("['sudo','-n','perf','report'","['perf','report'").replace("['sudo','-n','perf','script'","['perf','script'")
# Move all offline decoding after normal worker quit, map retirement and fixture cleanup.
analysis='\n'.join(line[4:]if line.startswith('    ')else line for line in analysis.splitlines())+'\n'
analysis=analysis.replace("            with (folder/'perf-report.txt')","        with (folder/'perf-report.txt')")
# Its report body originally had one extra if-perf indentation; normalize separately.
analysis=analysis.replace("                subprocess.run(['perf','report'","            subprocess.run(['perf','report'")
ops=ops[:start]+ops[end:]
needle="        for map_name in ['perf.map','perfinfo.map']:"
owned='\n'.join(line[4:]if line.startswith('    ')else line for line in ownership.splitlines())+'\n'
ops=ops.replace(needle,owned+analysis+'        (folder / "record.json").write_text(json.dumps(record, indent=2) + "\\n")\n'+needle)
ast.parse(ops);(out/'ops-profile.py').write_text(ops,encoding='utf-8',newline='\n')
for name in ['collect.py','run.sh','identity.json']:
 (out/name).write_text((old/name).read_text(encoding='utf-8').replace(oldroot,root),encoding='utf-8',newline='\n')
config=json.loads((old/'config.json').read_text(encoding='utf-8'));config.update(root=root,unit='lython-b650-report-cpu-20261113',retire=[])
with tarfile.open(out/'payload.tgz','w:gz')as archive:
 for name in ['ops-profile.py','collect.py','run.sh','identity.json']:archive.add(out/name,arcname=name)
config.update(payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest())
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
source=(base/'launch-report-profile.py').read_text(encoding='utf-8').replace("/'report-cpu'","/'report-cpu-corrected'").replace('lython-b649-fixtures','lython-b650-fixtures')
source=source.replace("assert before+sum(p['allocatedBytes']for p in proofs)>254*1024*1024","assert before+sum(p['allocatedBytes']for p in proofs)>253*1024*1024")
# One MiB of new staging is enough: immutable images/catalog borrowed, only scripts staged.
# OS240MiB/evidence12MiB floors remain in collect.py before evidence completes.
(base/'launch-corrected-report.py').write_text(source,encoding='utf-8',newline='\n')
source=(old/'retrieve.py').read_text(encoding='utf-8').replace('report-cpu-b649-20261113','report-cpu-b650-20261113').replace('lython-b649-report-cpu-20261113','lython-b650-report-cpu-20261113').replace('B649','B650')
(out/'retrieve.py').write_text(source,encoding='utf-8',newline='\n')
for name in ['analyze.py','summarize.py']:(out/name).write_bytes((old/name).read_bytes())
print('Corrected offline decoding follows verified worker close/exit and fixture cleanup. No runtime or workload changes; original partial capture preserved.',flush=True)
