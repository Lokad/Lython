from pathlib import Path
import json,subprocess
r=Path(__file__).parent/'report-cpu'
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
code='''from pathlib import Path
import fcntl,json,subprocess
root=Path('/home/lokad/lython-bench-checks/report-cpu-b649-20261113')
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 journal=subprocess.check_output(['journalctl','--unit=lython-b649-report-cpu-20261113.service','--no-pager','-n','100'],text=True)
 print(journal)
 for name in ['profiles/report/record.json','profiles/report/collector.log','profiles/report/worker.stderr']:
  p=root/name
  if p.exists():print(name,p.read_text()[-5000:])
 fixture=root/'guest-fixtures'
 if fixture.exists():
  assert not list(fixture.iterdir());subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir()
 print('All users joined; empty RAM mount retired under fresh idle lease.')
'''
done=subprocess.run(ssh+['python3 -'],input=code,capture_output=True,text=True,encoding='utf-8')
(r/'failure-inspection.log').write_text(done.stdout+done.stderr,encoding='utf-8',newline='\n');print(done.stdout+done.stderr,flush=True);assert done.returncode==0
