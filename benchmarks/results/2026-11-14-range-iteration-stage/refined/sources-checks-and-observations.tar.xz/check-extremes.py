from pathlib import Path
import hashlib,json,os,subprocess,shutil,xml.etree.ElementTree as ET
r=Path(__file__).parent;identity=json.loads((r/'refined/candidate-identity.json').read_text(encoding='utf-8'));assert all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==h for n,h in identity['sources'].items())
env={k:v for k,v in os.environ.items()if k.lower()!='path'};env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+os.environ.get('PATH','');rows=[]
for framework in ['net11.0','net10.0']:
    name='r362-extremes-'+framework+'.trx';log=r/('extremes-'+framework+'.log')
    with log.open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f',framework,'--no-restore','--filter','FullyQualifiedName~RangeIterationStateTests','--logger','trx;LogFileName='+name,'-v','quiet'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
    assert done.returncode==0,log.read_text(encoding='utf-8')[-2500:]
    trx=Path('tests/Lokad.Lython.Tests/TestResults')/name;counts=ET.parse(trx).find('.//{http://microsoft.com/schemas/VisualStudio/TeamTest/2010}Counters').attrib;assert counts['passed']=='11',counts;shutil.copyfile(trx,r/name);rows.append(dict(framework=framework,counters=counts));print(framework,'11 range state/boundary cases pass, including full signed span and minimum stride.',flush=True)
(r/'extreme-checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
