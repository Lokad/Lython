from pathlib import Path
import json,os,subprocess,shutil,xml.etree.ElementTree as ET
r=Path(__file__).parent;env={k:v for k,v in os.environ.items()if k.lower()!='path'};env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+os.environ.get('PATH','');rows=[]
for framework in ['net11.0','net10.0']:
    name='r362-consumers-'+framework+'.trx';log=r/('consumers-'+framework+'.log')
    selection='(Category!=Stress)&(FullyQualifiedName~Generator|FullyQualifiedName~Comprehension|FullyQualifiedName~Itertools|FullyQualifiedName~Zip|FullyQualifiedName~Enumerate|FullyQualifiedName~Sum|FullyQualifiedName~AsyncMidFlightCancellationTests)'
    with log.open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f',framework,'--no-build','--filter',selection,'--logger','trx;LogFileName='+name,'-v','quiet'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
    assert done.returncode==0,log.read_text(encoding='utf-8')[-4000:]
    trx=Path('tests/Lokad.Lython.PublicApi.Tests/TestResults')/name;counts=ET.parse(trx).find('.//{http://microsoft.com/schemas/VisualStudio/TeamTest/2010}Counters').attrib;shutil.copyfile(trx,r/name);rows.append(dict(framework=framework,counters=counts));print(framework,counts['passed'],'generator/iterator/aggregate checks pass',flush=True)
(r/'consumer-checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
