from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).parent;prior=r.parent/'native-range-r361/native-only';identity=json.loads((prior/'candidate-identity.json').read_text(encoding='utf-8'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert all(sha(n)==h for n,h in identity['sources'].items())
for role in ['reference','candidate']:shutil.copytree(prior/'candidate',r/role)
files=['src/Lokad.Lython/Runtime/PyCoreIterators.cs','src/Lokad.Lython/Runtime/PyIteration.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs']
for n in files:
    p=r/'baseline'/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(n,p)
(r/'baseline.json').write_text(json.dumps(dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),runtimeCommit='3bc513b83a424d37b8b6329790fe04a5ce0550ab',coreSHA256=identity['coreSHA256']['candidate'],sources=identity['sources'],changedInputsPlanned=files,fullQualification='43618009133 active at source selection',sourceGate='benchmarks/results/2026-11-14-range-iteration-cost/source-gate.json'),indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('PLAN.md');shutil.copyfile(p,r/'PLAN-before-concise-refresh.md')
p.write_text('''# Lokad.Lython 0.11.0

Updated 2026-11-14. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance,
including compile-once/run-once scripts. One experiment does not finish that
objective. Current contracts belong in `docs/`; history/evidence in
[EXPERIMENTS](benchmarks/EXPERIMENTS.md) and linked immutable results.

## Actual status

| State | Outcome / limits |
| --- | --- |
| Completed foundations | Shared compiler facts/nonlocal correction and lowered retention cleanup; direct UTF-8 formatting/storage; native helper returns; final argument slots/linear continuations; immutable builtin functions; owned/native loops, tuple returns and primitive working storage; shared arithmetic; CSV array adoption/shared keys; UTF-8 JSON/incremental XML. Preserve their correctness fixes and cached qualification. |
| Measurement gaps resolved within bounds | Helper returns: approximately 19–20% less allocation; original elapsed remains diagnostic. Formatting: allocation −8.67%, [controlled confirmation](benchmarks/results/2026-11-02-formatting-confirmation/README.md) supports report elapsed/CPU about −5–8%; original adverse 15.125 ms remains unexplained/preserved. Neither predicts current HEAD. |
| Fully qualified baseline | `98acaa5b` / `a4bfbfd8`, [43605198037 GREEN](benchmarks/results/2026-11-14-native-primitive-storage/delivery/README.md), all platforms/runtimes/original stress/installed consumers. Cached terminal/logs; never requery. R359 short/observed-helper and small JSON CPU debt stays explicit. |
| Latest external checkpoint | [B736](docs/BENCHMARKS.md), exact 98ac/A4 versus stock CPython 3.13.16. Compilation, warm/fresh, mediated I/O, validation and cleanup are separated. Nine jobs/all gates; representative non-JSON gaps about 1.2–1.7×, JSON/report uncertainty retained. Reuse until a material representative milestone; no cross-collection attribution. |
| R360 withdrawn | [Frame primitive transport](benchmarks/results/2026-11-14-frame-primitive-storage/README.md) cuts allocation but regresses CSV/JSON/helpers. Entire migration removed, all 582 baseline inputs restored except independent matrix-routing fix. Retain public lifetimes/TypeError cases and meaningful callback refusal assertions. All original/refined failures/controls preserved; no dormant scalar frame backend. |
| R361 committed; delivery active | `3bc513b8` / frozen `ca1e2331`, [native-only range construction](benchmarks/results/2026-11-14-closed-range-construction/README.md): four inputs; ordinary router restored, constructors remain per execution. 176 final focused actual 11/10 checks, 70 Python controls, 16 worker goldens. Counter warm −31.8–33.2%, allocation −57.23%; short control adverse/variable, observed mixed. All 582 inputs match committed source. Full **43618009133 active**, no green claim. |
| R362 source selection | [One current profile](benchmarks/results/2026-11-14-range-iteration-cost/README.md): 995 guest leaves/38 unknown/0 ambiguous; range generated enumeration owns 326, cursor pulls 66. These include useful work, not removable shares. Three-file iteration-stage design selected; no prototype result or speed forecast yet. |

## Prioritized deliverables

1. **Close R361 delivery while independent work continues.** Cache terminal/logs
   for 43618009133 at exact 3bc513b8, Windows/Ubuntu actual .NET 11/10, original
   stress and installed Release consumers. Queries at least four minutes apart;
   no redispatch after initial run-list lag (accepted URL supplies the ID).
   Keep full qualification separate from experimental timing. Accept remaining
   short-helper/control uncertainty for this bounded whole-loop gain; final 0.11
   debt remains an explicit release decision. No final-source fresh/CSV/JSON
   elapsed or new CPython ratio is inferred from earlier source variants.

2. **R362: replace range iteration/boxed transport as one stage.** A shared explicit
   range enumerator replaces the generated `PyRange.Iterate` state machine.
   Existing cursor acquisition, position/EOF and cleanup serve object and native
   pulls. Native code uses primitive pulls only with already prepared integer
   working storage; no new compiler fact pass/array for unrelated loops.

   **Remove:** generated range MoveNext/object-current pipeline and per-yield
   boxes in eligible native numeric loops. Generic object iteration shares the
   same range state; do not retain a dormant alternate range engine.
   Keep PyRange's CLR/Python interfaces unchanged. Prefer one small iterable
   adapter and independent enumerators to global caches/thread-local reuse.
   Any added legacy acquisition cost must appear in materialization controls.
   Checked machine bounds/progression may use inline state; wider bounds and
   large-yield funding keep exact Python behavior. No new owner, pool, ledger,
   universal values, frame representation, controller or configuration.

   **Acceptance:** signed/int64/wider bounds/strides, empty/negative/huge lengths,
   stable identities/aliases, independent enumerators/Current/sticky EOF, explicit
   iterators, generators/closures, native-to-owned transfer, real I/O, early exit,
   cooperative cancellation, pre-effect first refusal/large-yield origin,
   retained results/shared-budget reuse and awaited cleanup. Preserve unsupported
   serialization/projection and generic object behavior. All surviving storage
   remains funded; no cumulative allocation counting or arbitrary reclamation.

   **Bound:** one coherent three-file prototype or concrete rejection. Focused
   actual .NET 11/10 and independent Python controls first; same-work counter
   warm/fresh, CSV, materializing range, short/observed controls on the quiet VM.
   Allocation separate from elapsed/CPU; decide retention/debt and delete displaced
   code. One current profile suffices for source selection; no new attribution
   inventory without a specific new question. Batch full delivery if retained.

3. **Continue substantial representative-script redesigns.** Each selected design
   states hypothesis, eliminated stage/storage/code, affected scripts, semantic/
   ownership acceptance, bounded controls and final regression-debt decision.

   | Area / workloads | Evidence / selection standard |
   | --- | --- |
   | Calls/frames/operands / helpers, search, invoice | Final slots/native prefixes/tuple returns already remove packaging. Earlier owning profiles do not justify replaying slower call arenas/controllers. Remove a real remaining activation/copy; preserve defaults/keywords/receivers, closures, exact PCs, stack and genuine suspension. |
   | Records / CSV/JSON aggregates, reports | Bulk-record 6–8% evidence was reconsidered, not vetoed by threshold. R355 raw ranges were withdrawn for limited benefit/state/scratch costs; array adoption/shared keys remain. A new design must remove a complete stage and preserve callbacks, mutations/aliases, pre-effect admission and replacement overlap. |
   | Text / summary, search, report | Current casing/formatting already writes UTF-8 directly. Select a real conversion/build stage; profiles include useful mapping/probing. Preserve Unicode context/expansion, hooks, errors, token and funded output. |
   | Frontend / fresh scripts | Shared facts/lowered retention cleanup delivered. Invoice compile is about 0.1 ms versus 7–8 ms execution; pass count alone does not establish dominance. Remove demonstrated duplicate facts/IR, preserving scopes/nonlocals/diagnostics and admission. |

   Refresh representative CPython comparisons after a material retained milestone,
   separating compilation, warm execution, I/O, validation, result cleanup and
   compiled/cache disposal. Do not replay unchanged nine-job checkpoints for
   small corrections. R359/R361 call-heavy debt remains a release decision.

4. **Regex develops independently.** Core owns Python semantics, native UTF-8,
   original-subject windows, byte/scalar coordinates, captures/errors, explicit
   owners and active token. Development producers/adapter-local bridges remain
   acceptable; core stays backend-free. Optional non-packable adapter stays 0.4;
   completed dev80 checks cached. [Source assessment through cd8eb5c7](benchmarks/results/2026-11-14-regex-provider-capabilities/README.md)
   does not qualify package/safety/semantics/interruption/performance.
   Only affected final released-adapter checks wait for separately funded
   one-match scratch/escaping results, native UTF-8 group-name enumeration/copy,
   and token-independent cursor creation with cancellable preparation. Search
   filtering cannot implement anchored/fullmatch. Cached state never retains
   earlier tokens. These gaps stop no independent Lython implementation/testing.

## Measurement and lasting constraints

Simplification, allocation reduction and demonstrated CPU improvement are separate.
Timeouts/unstable controls/inconclusive data establish uncertainty. Allow bounded
confirmation/refinement/measurement correction when evidence justifies it; retain
all adverse samples and original failures. Percentages inform decisions rather
than vetoing useful changes. No blanket one-attempt/no-retiming/permanent rejection
rules and no open-ended campaign. Finish milestones with retention/debt or supported
withdrawal; the wider objective continues.

Use focused Release correctness/cancellation/ownership checks during iteration,
batch full platform/stress/installed consumers at meaningful checkpoints, and reuse
cached checks. Force nonincremental builds after restoration; freeze copies/verify
whole images. Persist/verify evidence before RAM teardown; keep current images,
catalogs/toolchains and 254/252 MiB VM floors. Startup, pending-I/O latency,
contention, heap/RSS peaks and embedding tail latency remain unmeasured.

[AGENTS.md](AGENTS.md) remains binding: fully managed/memory-safe, managed stack,
host mediation/original paths plus contained Cwd, cooperative host cancellation,
cycles, XML depth, checked bounds and bounded I/O chunks. No unsafe/Unsafe APIs,
pointers/PInvoke/native probing; no fuel/quotas, hidden caps/default allowance,
regex work/time policy, tracing, weak reclamation, forced GC or abandoned users.
Borrowed allowance funds capacity/overlap, retained aliases/results/caches and
pending users. First refusal is terminal with original structured origin; await
cleanup and never retry. Long streams use bounded host commands. Only core is
packaged; optional adapter is non-packable. Publication/tagging remain postponed.
''',encoding='utf-8',newline='\n');print('R362baseline frozen and concise PLANupdated before implementation.',flush=True)
