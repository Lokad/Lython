# Complete representative scripts

These ordinary Python jobs cover CSV conversion/filtering/aggregation, Unicode
text counting, newline-delimited JSON aggregation, and mediated directory/file
copying with a deterministic manifest. The file-search job adds a small predicate
helper and an early break inside a file context, with independently checked scan
count and retained matching line. They publish complete output files.
The uppercase-report job reads one bounded UTF-8 text file and publishes its
uppercase form, including full-case expansions. It reports the output's Python
character count; fixtures check exact report bytes independently.
The configuration-edit job loads JSON, edits a flag and retry count, appends one
path and writes the same file back. Independent goldens preserve Unicode and
untouched nested metadata at zero,16 and1,024 existing paths. Zero paths is a
metadata-only configuration, rather than an empty input file. Worker resets
restore the original input before every invocation, including in warm lanes.
Text reports explicitly use LF on Windows and Linux. Each run needs fresh input
files and a writable working directory; the file job creates its output directory.

`RepresentativeScriptTests` supplies independent fixtures and checks exact file
bytes at 0, 16 and 1,024 repetitions through synchronous and genuinely delayed
asynchronous hosts. Small cases use a 256 KiB execution cap; the finite 1,024-repeat
cases use 8 MiB for conservative in-execution retention. Shared-budget host batches
check reuse independently of CLR collection. Cancellation controls interrupt
real host reads. Publication controls pause each complete job's report write,
cancel it, and verify that the previous file bytes remain intact. The file job's
earlier successful binary copies remain published: atomic replacement is per
host operation, rather than a transaction over the whole job.
These tests complement retained-data, alias and preflight gates;
they do not qualify embedding latency or comparative performance.

Alias controls retain one CSV note, JSON kind or Unicode line across the complete
scan and source closure, collect before projection, and compare independent
report bytes. Retaining all emitted values rejects at the same 256 KiB cap.
White-box CSV/JSON success/error controls check acquisition leases, parser storage
and funded escaped storage after abandonment. CSV source/parser storage owns its
shell and actual scratch capacities; emitted values stay charged to their execution owner. Field
growth preflights replacement overlap before allocating. A CSV body-conversion error leaves
the reader resumable and its scratch funded until private storage retirement or
batch cleanup. Caller-retained readers may resume within their execution lifetime.

The fixed file-retention control copies64 distinct8 KiB inputs at the same
256 KiB execution cap, checking every output byte and an independently assembled
manifest. Dropping buffers or keeping only the first buffer completes; retaining
all input buffers rejects before manifest publication. This is containment
evidence, not an additional timed comparison lane. Host-owned completed output
files remain outside guest execution accounting.

Protocol cancellation controls wrap CSV physical lines in a guest generator and
use a JSON `object_hook`. Cancellation occurs with a quoted CSV record pending
or a parent JSON object still parsing, through a specified mediated-output
checkpoint. Both modes report typed cancellation before a completed report is
published. These checks preserve the separate native-cleanup/ownership contract;
they do not establish a general cancellation-latency or host SLO guarantee.

Check the same source and fixtures with an installed CPython:

```powershell
python tools/verify-representative-scripts.py --output-dir <new-receipt-directory>
```

The driver preserves inputs, outputs, source/fixture/output hashes and Python
identity. It normalizes standard-output text line endings while comparing all
published file bytes exactly. Its per-child deadline is 10 seconds. This is a
correctness check. The comparison harness stages identical file fixtures and
validates complete output bytes in both workers; its measured boundaries and
remaining timing qualification are described in [COMPARISON.md](../COMPARISON.md).
