namespace Lokad.Lython.Frontend;

internal sealed record ScopeDirectiveFacts(
    IReadOnlySet<string> GlobalNames,
    IReadOnlySet<string> NonlocalNames,
    IReadOnlySet<string> LocalNames)
{
    // A free __class__ cell is required only by lexical reads in this function
    // or an enclosed scope. A neighboring method does not supply that demand.
    public bool RequiresClassCell { get; init; }

    public static ScopeDirectiveFacts Empty { get; } = new(
        new HashSet<string>(StringComparer.Ordinal),
        new HashSet<string>(StringComparer.Ordinal),
        new HashSet<string>(StringComparer.Ordinal));

    public bool IsGlobal(string name) => GlobalNames.Contains(name);

    public bool IsNonlocal(string name) => NonlocalNames.Contains(name);
}

internal static class ScopeDirectiveFactsCollector
{
    public static bool ContainsScopeDirective(IReadOnlyList<StatementSyntax> statements)
    {
        foreach (var statement in statements)
        {
            if (statement is ScopeDirectiveStatementSyntax)
            {
                return true;
            }

            foreach (var body in StatementSyntaxTraversal.EnumerateChildBodies(statement))
            {
                if (ContainsScopeDirective(body)) return true;
            }
        }

        return false;
    }

    public static ScopeDirectiveFacts ForFunction(
        IReadOnlyList<LoweredFunctionParameter> parameters,
        IReadOnlyList<StatementSyntax> body,
        bool includeClassCellRequirement = true)
    {
        var globalNames = new HashSet<string>(StringComparer.Ordinal);
        var nonlocalNames = new HashSet<string>(StringComparer.Ordinal);
        CollectDirectives(body, globalNames, nonlocalNames);

        var localNames = new HashSet<string>(StringComparer.Ordinal);
        foreach (var parameter in parameters)
        {
            localNames.Add(parameter.Name);
        }

        CollectLocalBindings(body, localNames);
        localNames.ExceptWith(globalNames);
        localNames.ExceptWith(nonlocalNames);

        return new ScopeDirectiveFacts(globalNames, nonlocalNames, localNames)
        {
            RequiresClassCell = includeClassCellRequirement && !globalNames.Contains("__class__") && !localNames.Contains("__class__") &&
                ClassCellSyntaxFacts.ReferencesFromFunction(body)
        };
    }

    public static ScopeDirectiveFacts ForClass(ClassDefinitionStatementSyntax definition)
        => ForFunction([], definition.Body);

    public static ScopeDirectiveFacts ForFunction(FunctionDefinitionStatementSyntax functionDefinition)
    {
        var facts = ForFunction(
            functionDefinition.Parameters.Select(parameter => new LoweredFunctionParameter(
                parameter.Name,
                parameter.Kind,
                Annotation: null,
                DefaultValue: null)).ToArray(),
            functionDefinition.Body, includeClassCellRequirement: functionDefinition.PreparedClassCellRequirement is null);
        return functionDefinition.PreparedClassCellRequirement is { } required
            ? facts with { RequiresClassCell = required } : facts;
    }

    internal static ScopeDirectiveFacts ForFunctionBindings(FunctionDefinitionStatementSyntax definition)
        => ForFunction(definition.Parameters.Select(p => new LoweredFunctionParameter(p.Name, p.Kind, null, null)).ToArray(),
            definition.Body, includeClassCellRequirement: false);

    public static HashSet<string> CollectLambdaLocalNames(LambdaExpressionSyntax lambda)
    {
        var localNames = new HashSet<string>(
            lambda.Parameters.Select(static parameter => parameter.Name),
            StringComparer.Ordinal);
        CollectExpressionBindings(lambda.Body, localNames);
        return localNames;
    }

    public static ScopeDirectiveFacts ForLambda(IReadOnlyList<LoweredFunctionParameter> parameters, ExpressionSyntax body)
    {
        var locals = new HashSet<string>(parameters.Select(p => p.Name), StringComparer.Ordinal);
        CollectExpressionBindings(body, locals);
        return new ScopeDirectiveFacts(EmptyNames, EmptyNames, locals)
        {
            RequiresClassCell = !locals.Contains("__class__") && ClassCellSyntaxFacts.ReferencesFromExpression(body)
        };
    }

    public static ScopeDirectiveFacts ForLambda(LambdaExpressionSyntax lambda)
    {
        var facts = ForLambda(lambda.Parameters.Select(p => new LoweredFunctionParameter(p.Name, p.Kind, null, null)).ToArray(), lambda.Body);
        return lambda.PreparedClassCellRequirement is { } required ? facts with { RequiresClassCell = required } : facts;
    }

    private static readonly IReadOnlySet<string> EmptyNames = new HashSet<string>(StringComparer.Ordinal);

    public static ScopeDirectiveFacts ForLoweredStatements(
        IReadOnlyList<LoweredFunctionParameter>? parameters,
        IReadOnlyList<LoweredStatement> statements)
        => ForFunction(parameters ?? [], statements.Select(GetSyntax).ToArray());

    private static StatementSyntax GetSyntax(LoweredStatement statement)
        => statement switch
        {
            LoweredTypeAliasStatement lowered => lowered.Syntax,
            LoweredImportStatement lowered => lowered.Syntax,
            LoweredScopeDirectiveStatement lowered => lowered.Syntax,
            LoweredFunctionDefinitionStatement lowered => lowered.Syntax,
            LoweredClassDefinitionStatement lowered => lowered.Syntax,
            LoweredAssignmentStatement lowered => lowered.Syntax,
            LoweredExpressionStatement lowered => lowered.Syntax,
            LoweredIfStatement lowered => lowered.Syntax,
            LoweredForStatement lowered => lowered.Syntax,
            LoweredWhileStatement lowered => lowered.Syntax,
            LoweredMatchStatement lowered => lowered.Syntax,
            LoweredWithStatement lowered => lowered.Syntax,
            LoweredTryStatement lowered => lowered.Syntax,
            LoweredPassStatement lowered => lowered.Syntax,
            LoweredBreakStatement lowered => lowered.Syntax,
            LoweredContinueStatement lowered => lowered.Syntax,
            LoweredAssertStatement lowered => lowered.Syntax,
            LoweredDeleteStatement lowered => lowered.Syntax,
            LoweredReturnStatement lowered => lowered.Syntax,
            LoweredRaiseStatement lowered => lowered.Syntax,
            LoweredOtherStatement lowered => lowered.Syntax,
            _ => throw new InvalidOperationException($"Unknown lowered statement kind: {statement.GetType().Name}")
        };

    private static void CollectDirectives(
        IReadOnlyList<StatementSyntax> statements,
        HashSet<string> globalNames,
        HashSet<string> nonlocalNames)
    {
        foreach (var statement in statements)
        {
            if (statement is ScopeDirectiveStatementSyntax directive)
            {
                foreach (var name in directive.Names)
                {
                    if (directive.Kind == ScopeDirectiveKind.Global)
                    {
                        globalNames.Add(name);
                    }
                    else
                    {
                        nonlocalNames.Add(name);
                    }
                }
            }

            if (statement is FunctionDefinitionStatementSyntax or ClassDefinitionStatementSyntax)
            {
                continue;
            }

            foreach (var body in StatementSyntaxTraversal.EnumerateChildBodies(statement))
            {
                CollectDirectives(body, globalNames, nonlocalNames);
            }
        }
    }

    private static void CollectLocalBindings(IReadOnlyList<StatementSyntax> statements, HashSet<string> names)
    {
        foreach (var statement in statements)
        {
            switch (statement)
            {
                case ImportStatementSyntax importStatement:
                    if (importStatement.ImportedMembers is null)
                    {
                        names.Add(importStatement.BindingName);
                    }
                    else
                    {
                        foreach (var memberName in ImportSyntaxFacts.EnumerateBindingNames(importStatement))
                        {
                            names.Add(memberName);
                        }
                    }
                    break;

                case TypeAliasStatementSyntax alias:
                    names.Add(alias.Name);
                    break;
                case AssignmentStatementSyntax assignment:
                    names.Add(assignment.Name);
                    break;

                case ChainedAssignmentStatementSyntax chained:
                    foreach (var target in chained.Targets) CollectAssignmentTargetBindings(target, names);
                    break;

                case AnnotatedAssignmentStatementSyntax annotated:
                    if (annotated.Target is NameAssignmentTargetSyntax name)
                    {
                        names.Add(name.Name);
                    }

                    break;

                case AugmentedAssignmentStatementSyntax { Target: NameAssignmentTargetSyntax nameTarget }:
                    names.Add(nameTarget.Name);
                    break;

                case UnpackingAssignmentStatementSyntax unpacking:
                    foreach (var target in unpacking.Targets) CollectUnpackingTargetNames(target, names);
                    break;

                case ForStatementSyntax forStatement:
                    CollectLoopTargetBindings(forStatement.Target, names);
                    break;

                case WithStatementSyntax withStatement:
                    names.UnionWith(withStatement.BoundNames);
                    break;

                case TryStatementSyntax tryStatement:
                    foreach (var exceptClause in tryStatement.ExceptClauses)
                    {
                        if (exceptClause.ExceptionVariableName is not null) names.Add(exceptClause.ExceptionVariableName);
                        if (exceptClause.ExceptionTypeExpression is not null) CollectExpressionBindings(exceptClause.ExceptionTypeExpression, names);
                    }
                    break;

                case MatchStatementSyntax matchStatement:
                    foreach (var matchCase in matchStatement.Cases)
                    {
                        CollectPatternBindings(matchCase.Pattern, names);
                    }
                    break;

                case DeleteStatementSyntax { Target: IdentifierExpressionSyntax deleted }:
                    names.Add(deleted.Name);
                    break;

                case FunctionDefinitionStatementSyntax functionDefinition:
                    names.Add(functionDefinition.Name);
                    foreach (var expression in StatementSyntaxTraversal.EnumerateDirectExpressions(functionDefinition))
                        CollectExpressionBindings(expression, names);
                    continue;

                case ClassDefinitionStatementSyntax classDefinition:
                    names.Add(classDefinition.Name);
                    foreach (var expression in StatementSyntaxTraversal.EnumerateDirectExpressions(classDefinition))
                        CollectExpressionBindings(expression, names);
                    continue;

                case ExpressionStatementSyntax expressionStatement:
                    CollectExpressionBindings(expressionStatement.Expression, names);
                    break;
            }

            foreach (var expression in StatementSyntaxTraversal.EnumerateDirectExpressions(statement))
                CollectExpressionBindings(expression, names);

            foreach (var body in StatementSyntaxTraversal.EnumerateChildBodies(statement))
            {
                CollectLocalBindings(body, names);
            }
        }

        static void CollectAssignmentTargetBindings(AssignmentTargetSyntax target, HashSet<string> names)
        {
            switch (target)
            {
                case NameAssignmentTargetSyntax name:
                    names.Add(name.Name);
                    break;
                case UnpackingAssignmentTargetGroupSyntax unpacking:
                    foreach (var nestedTarget in unpacking.Targets) CollectUnpackingTargetNames(nestedTarget, names);
                    break;
            }
        }

        static void CollectUnpackingTargetNames(UnpackingTargetSyntax target, HashSet<string> names)
        {
            if (target is UnpackingNameTargetSyntax name)
            {
                names.Add(name.Name);
                return;
            }

            if (target is UnpackingNestedTargetSyntax nested)
            {
                foreach (var nestedItem in nested.Items)
                {
                    CollectUnpackingTargetNames(nestedItem, names);
                }
            }
        }
    }

    private static void CollectLoopTargetBindings(LoopTargetSyntax target, HashSet<string> names)
    {
        switch (target)
        {
            case LoopStoreTargetSyntax store:
                foreach (var binding in AssignmentTargetFacts.Names(store.Target)) names.Add(binding);
                break;
            case LoopNameTargetSyntax name:
                names.Add(name.Name);
                break;
            case LoopStarredTargetSyntax starred:
                names.Add(starred.Name);
                break;
            case LoopTupleTargetSyntax tuple:
                foreach (var item in tuple.Items) CollectLoopTargetBindings(item, names);
                break;
        }
    }

    internal static void CollectPatternBindings(PatternSyntax pattern, HashSet<string> names)
    {
        switch (pattern)
        {
            case MatchCapturePatternSyntax capture:
                names.Add(capture.Name);
                break;
            case MatchSequencePatternSyntax sequence:
                foreach (var item in sequence.Items) CollectPatternBindings(item, names);
                break;
            case MatchMappingPatternSyntax mapping:
                foreach (var item in mapping.Items) CollectPatternBindings(item.Pattern, names);
                if (mapping.RestName is not null) names.Add(mapping.RestName);
                break;
            case MatchClassPatternSyntax classPattern:
                foreach (var item in classPattern.PositionalPatterns) CollectPatternBindings(item, names);
                foreach (var item in classPattern.KeywordPatterns) CollectPatternBindings(item.Pattern, names);
                break;
            case MatchStarPatternSyntax star when star.Name is not null:
                names.Add(star.Name);
                break;
            case MatchAsPatternSyntax asPattern:
                CollectPatternBindings(asPattern.Pattern, names);
                names.Add(asPattern.Name);
                break;
            case MatchOrPatternSyntax orPattern:
                foreach (var item in orPattern.Patterns) CollectPatternBindings(item, names);
                break;
        }
    }

    internal static void CollectExpressionBindings(ExpressionSyntax expression, HashSet<string> names)
    {
        if (expression is LambdaExpressionSyntax lambda)
        {
            foreach (var parameter in lambda.Parameters)
                if (parameter.DefaultValue is not null) CollectExpressionBindings(parameter.DefaultValue, names);
            return;
        }

        if (expression is AssignmentExpressionSyntax assignment)
        {
            names.Add(assignment.Name);
        }

        foreach (var child in ExpressionSyntaxTraversal.EnumerateChildren(expression))
        {
            CollectExpressionBindings(child, names);
        }
    }
}
