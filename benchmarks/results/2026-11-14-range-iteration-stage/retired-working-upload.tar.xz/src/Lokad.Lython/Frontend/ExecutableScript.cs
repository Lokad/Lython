using System.Globalization;
using System.Numerics;
using Lokad.Lython.Runtime;
using Lokad.Lython.Runtime.Numbers;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Frontend;

// Signals that a valid lowered program must use the general interpreter instead of executable IR.
internal sealed class ExecutableLoweringFallbackException(string message) : Exception(message);

internal enum ExecutableOpCode
{
    Import,
    DefineFunction,
    ExecuteFallbackStatement,
    LoadConst,
    LoadLocal,
    LoadClosure,
    LoadGlobal,
    LoadName,
    EvaluateFallbackExpression,
    ApplyOperation,
    LoadMember,
    LoadCallMember,
    LoadCallReceiver,
    PreloadImplicitSuperArguments,
    StoreLocal,
    StoreClosure,
    StoreGlobal,
    StoreName,
    Dup,
    PopTop,
    MakeList,
    MakeTuple,
    MakeSet,
    MakeDict,
    ResolveContextManager,
    EnterContextManager,
    ExitContextManager,
    MatchCase,
    GetIter,
    ForNext,
    Call,
    Subscript,
    Slice,
    MakeSlice,
    Binary,
    Augmented,
    Unary,
    Jump,
    JumpIfFalse,
    ChainLink,
    MatchException,
    BindException,
    ReraiseException,
    ClearException,
    EndFinally,
    Return,
    ReturnNone,
    Yield,
    YieldFrom,
    AbruptJump,
}

internal enum ExecutableBinaryOperator
{
    Or,
    And,
    Add,
    Subtract,
    Multiply,
    MatrixMultiply,
    Divide,
    FloorDivide,
    Modulo,
    Power,
    BitwiseOr,
    BitwiseXor,
    BitwiseAnd,
    LeftShift,
    RightShift,
    Equal,
    NotEqual,
    Less,
    LessEqual,
    Greater,
    GreaterEqual,
    Is,
    IsNot,
    In,
    NotIn,
}

internal enum ExecutableUnaryOperator
{
    Not,
    Plus,
    Minus,
    BitwiseNot,
}

internal enum ExecutableAugmentedOperator
{
    Add,
    Subtract,
    Multiply,
    MatrixMultiply,
    Divide,
    FloorDivide,
    Modulo,
    Power,
    BitwiseOr,
    BitwiseXor,
    BitwiseAnd,
    LeftShift,
    RightShift,
}

[Flags]
internal enum ExecutableSliceParts
{
    None = 0,
    Start = 1,
    End = 2,
    Step = 4,
}

internal readonly record struct ExecutableInstruction
{
    private enum OperandKind
    {
        None,
        ImportIndex,
        FunctionIndex,
        StatementFallbackIndex,
        ConstantIndex,
        LocalSlot,
        ClosureSlot,
        NameIndex,
        ExpressionFallbackIndex,
        MemberCacheIndex,
        ItemCount,
        PairCount,
        MatchCaseIndex,
        BlockIndex,
        CallSiteIndex,
        ExceptionNameIndex,
        CleanupId,
    }

    private readonly record struct Operand(OperandKind Kind, int Value)
    {
        public static Operand None => new(OperandKind.None, 0);
    }

    private readonly Operand _primaryOperand;
    private readonly Operand _secondaryOperand;
    private readonly ExecutableBinaryOperator _binaryOperator;
    private readonly ExecutableUnaryOperator _unaryOperator;
    private readonly ExecutableAugmentedOperator _augmentedOperator;
    private readonly ExecutableSliceParts _sliceParts;

    private ExecutableInstruction(
        ExecutableOpCode opCode,
        LythonSourceSpan span,
        Operand primaryOperand,
        Operand secondaryOperand,
        ExecutableBinaryOperator binaryOperator,
        ExecutableUnaryOperator unaryOperator,
        ExecutableAugmentedOperator augmentedOperator,
        ExecutableSliceParts sliceParts)
    {
        OpCode = opCode;
        Span = span;
        _primaryOperand = primaryOperand;
        _secondaryOperand = secondaryOperand;
        _binaryOperator = binaryOperator;
        _unaryOperator = unaryOperator;
        _augmentedOperator = augmentedOperator;
        _sliceParts = sliceParts;
    }

    public ExecutableOpCode OpCode { get; }

    public LythonSourceSpan Span { get; }

    public int ImportIndex => ReadOperand(_primaryOperand, OperandKind.ImportIndex);
    public int FunctionIndex => ReadOperand(_primaryOperand, OperandKind.FunctionIndex);
    public int StatementFallbackIndex => ReadOperand(_primaryOperand, OperandKind.StatementFallbackIndex);
    public int ConstantIndex => ReadOperand(_primaryOperand, OperandKind.ConstantIndex);
    public int LocalSlot => ReadOperand(_primaryOperand, OperandKind.LocalSlot);
    public int ClosureSlot => ReadOperand(_primaryOperand, OperandKind.ClosureSlot);
    public int NameIndex => ReadOperand(_primaryOperand, OperandKind.NameIndex);
    public int ExpressionFallbackIndex => ReadOperand(_primaryOperand, OperandKind.ExpressionFallbackIndex);
    public int MemberCacheIndex => ReadOperand(_secondaryOperand, OperandKind.MemberCacheIndex);
    public bool DiscardIterator => ReadOperand(_secondaryOperand, OperandKind.ItemCount) != 0;
    public int ItemCount => ReadOperand(_primaryOperand, OperandKind.ItemCount);
    public int PairCount => ReadOperand(_primaryOperand, OperandKind.PairCount);
    public int MatchCaseIndex => ReadOperand(_primaryOperand, OperandKind.MatchCaseIndex);
    public int FailureBlockIndex => ReadOperand(_secondaryOperand, OperandKind.BlockIndex);
    public int TargetBlockIndex => ReadOperand(_primaryOperand, OperandKind.BlockIndex);
    public int ChainSlot => ReadOperand(_primaryOperand, OperandKind.LocalSlot);
    public int CallSiteIndex => ReadOperand(_primaryOperand, OperandKind.CallSiteIndex);
    public int CleanupId => ReadOperand(OpCode == ExecutableOpCode.EndFinally ? _secondaryOperand : _primaryOperand, OperandKind.CleanupId);
    public int ExceptionNameIndex => ReadOperand(_primaryOperand, OperandKind.ExceptionNameIndex);
    public ExecutableSliceParts SliceParts => _sliceParts;
    public ExecutableBinaryOperator BinaryOperator => _binaryOperator;
    public ExecutableUnaryOperator UnaryOperator => _unaryOperator;
    public ExecutableAugmentedOperator AugmentedOperator => _augmentedOperator;

    public static ExecutableInstruction Import(int importIndex, LythonSourceSpan span)
        => CreateIndexed(ExecutableOpCode.Import, new Operand(OperandKind.ImportIndex, importIndex), span);

    public static ExecutableInstruction DefineFunction(int functionIndex, LythonSourceSpan span)
        => CreateIndexed(ExecutableOpCode.DefineFunction, new Operand(OperandKind.FunctionIndex, functionIndex), span);

    public static ExecutableInstruction ExecuteFallbackStatement(int statementIndex, LythonSourceSpan span)
        => CreateIndexed(ExecutableOpCode.ExecuteFallbackStatement, new Operand(OperandKind.StatementFallbackIndex, statementIndex), span);

    public static ExecutableInstruction ApplyOperation(int constantIndex, LythonSourceSpan span)
        => CreateIndexed(ExecutableOpCode.ApplyOperation, new Operand(OperandKind.ConstantIndex, constantIndex), span);

    public static ExecutableInstruction LoadConst(int constantIndex, LythonSourceSpan span)
        => CreateIndexed(ExecutableOpCode.LoadConst, new Operand(OperandKind.ConstantIndex, constantIndex), span);

    public static ExecutableInstruction LoadLocal(int slot, LythonSourceSpan span)
        => CreateIndexed(ExecutableOpCode.LoadLocal, new Operand(OperandKind.LocalSlot, slot), span);

    public static ExecutableInstruction LoadClosure(int slot, LythonSourceSpan span)
        => CreateIndexed(ExecutableOpCode.LoadClosure, new Operand(OperandKind.ClosureSlot, slot), span);

    public static ExecutableInstruction LoadGlobal(int nameIndex, LythonSourceSpan span)
        => CreateIndexed(ExecutableOpCode.LoadGlobal, new Operand(OperandKind.NameIndex, nameIndex), span);

    public static ExecutableInstruction LoadName(int nameIndex, LythonSourceSpan span)
        => CreateIndexed(ExecutableOpCode.LoadName, new Operand(OperandKind.NameIndex, nameIndex), span);

    public static ExecutableInstruction EvaluateFallbackExpression(int expressionIndex, LythonSourceSpan span)
        => CreateIndexed(ExecutableOpCode.EvaluateFallbackExpression, new Operand(OperandKind.ExpressionFallbackIndex, expressionIndex), span);

    public static ExecutableInstruction LoadMember(int nameIndex, int cacheIndex, LythonSourceSpan span)
        => CreateIndexed(
            ExecutableOpCode.LoadMember,
            new Operand(OperandKind.NameIndex, nameIndex),
            new Operand(OperandKind.MemberCacheIndex, cacheIndex),
            span);

    public static ExecutableInstruction LoadCallMember(int nameIndex, int cacheIndex, LythonSourceSpan span)
        => CreateIndexed(
            ExecutableOpCode.LoadCallMember,
            new Operand(OperandKind.NameIndex, nameIndex),
            new Operand(OperandKind.MemberCacheIndex, cacheIndex),
            span);

    public static ExecutableInstruction LoadCallReceiver(int nameIndex, int cacheIndex, LythonSourceSpan span)
        => CreateIndexed(
            ExecutableOpCode.LoadCallReceiver,
            new Operand(OperandKind.NameIndex, nameIndex),
            new Operand(OperandKind.MemberCacheIndex, cacheIndex),
            span);

    public static ExecutableInstruction PreloadImplicitSuperArguments(LythonSourceSpan span)
        => Create(ExecutableOpCode.PreloadImplicitSuperArguments, span);

    public static ExecutableInstruction StoreLocal(int slot, LythonSourceSpan span)
        => CreateIndexed(ExecutableOpCode.StoreLocal, new Operand(OperandKind.LocalSlot, slot), span);

    public static ExecutableInstruction StoreClosure(int slot, LythonSourceSpan span)
        => CreateIndexed(ExecutableOpCode.StoreClosure, new Operand(OperandKind.ClosureSlot, slot), span);

    public static ExecutableInstruction StoreGlobal(int nameIndex, LythonSourceSpan span)
        => CreateIndexed(ExecutableOpCode.StoreGlobal, new Operand(OperandKind.NameIndex, nameIndex), span);

    public static ExecutableInstruction StoreName(int nameIndex, LythonSourceSpan span)
        => CreateIndexed(ExecutableOpCode.StoreName, new Operand(OperandKind.NameIndex, nameIndex), span);

    public static ExecutableInstruction Dup(LythonSourceSpan span)
        => Create(ExecutableOpCode.Dup, span);

    public static ExecutableInstruction PopTop(LythonSourceSpan span)
        => Create(ExecutableOpCode.PopTop, span);

    public static ExecutableInstruction MakeList(int count, LythonSourceSpan span)
        => CreateIndexed(ExecutableOpCode.MakeList, new Operand(OperandKind.ItemCount, count), span);

    public static ExecutableInstruction MakeTuple(int count, LythonSourceSpan span)
        => CreateIndexed(ExecutableOpCode.MakeTuple, new Operand(OperandKind.ItemCount, count), span);

    public static ExecutableInstruction MakeSet(int count, LythonSourceSpan span)
        => CreateIndexed(ExecutableOpCode.MakeSet, new Operand(OperandKind.ItemCount, count), span);

    public static ExecutableInstruction MakeDict(int pairCount, LythonSourceSpan span)
        => CreateIndexed(ExecutableOpCode.MakeDict, new Operand(OperandKind.PairCount, pairCount), span);

    public static ExecutableInstruction ResolveContextManager(LythonSourceSpan span)
        => Create(ExecutableOpCode.ResolveContextManager, span);

    public static ExecutableInstruction EnterContextManager(LythonSourceSpan span)
        => Create(ExecutableOpCode.EnterContextManager, span);

    public static ExecutableInstruction ExitContextManager(LythonSourceSpan span, int cleanupId = -1)
        => CreateIndexed(ExecutableOpCode.ExitContextManager, new Operand(OperandKind.CleanupId, cleanupId), span);

    public static ExecutableInstruction MatchCase(int caseIndex, int failBlockIndex, LythonSourceSpan span)
        => CreateIndexed(
            ExecutableOpCode.MatchCase,
            new Operand(OperandKind.MatchCaseIndex, caseIndex),
            new Operand(OperandKind.BlockIndex, failBlockIndex),
            span);

    public static ExecutableInstruction GetIter(LythonSourceSpan span)
        => Create(ExecutableOpCode.GetIter, span);

    public static ExecutableInstruction ForNext(int targetBlockIndex, LythonSourceSpan span)
        => CreateIndexed(ExecutableOpCode.ForNext, new Operand(OperandKind.BlockIndex, targetBlockIndex), span);


    public static ExecutableInstruction Call(int callSiteIndex, LythonSourceSpan span)
        => CreateIndexed(
            ExecutableOpCode.Call,
            new Operand(OperandKind.CallSiteIndex, callSiteIndex),
            span);

    public static ExecutableInstruction Subscript(LythonSourceSpan span)
        => Create(ExecutableOpCode.Subscript, span);

    public static ExecutableInstruction Slice(ExecutableSliceParts parts, LythonSourceSpan span)
        => new(ExecutableOpCode.Slice, span, Operand.None, Operand.None, default, default, default, parts);

    public static ExecutableInstruction MakeSlice(ExecutableSliceParts parts, LythonSourceSpan span)
        => new(ExecutableOpCode.MakeSlice, span, Operand.None, Operand.None, default, default, default, parts);

    public static ExecutableInstruction Binary(ExecutableBinaryOperator op, LythonSourceSpan span)
        => new(ExecutableOpCode.Binary, span, Operand.None, Operand.None, op, default, default, default);

    public static ExecutableInstruction Augmented(ExecutableAugmentedOperator op, LythonSourceSpan span)
        => new(ExecutableOpCode.Augmented, span, Operand.None, Operand.None, default, default, op, default);

    public static ExecutableInstruction Unary(ExecutableUnaryOperator op, LythonSourceSpan span)
        => new(ExecutableOpCode.Unary, span, Operand.None, Operand.None, default, op, default, default);

    public static ExecutableInstruction AbruptJump(int targetBlockIndex, bool discardIterator, LythonSourceSpan span)
        => CreateIndexed(ExecutableOpCode.AbruptJump, new Operand(OperandKind.BlockIndex, targetBlockIndex), new Operand(OperandKind.ItemCount, discardIterator ? 1 : 0), span);

    public static ExecutableInstruction Jump(int targetBlockIndex, LythonSourceSpan span)
        => CreateIndexed(ExecutableOpCode.Jump, new Operand(OperandKind.BlockIndex, targetBlockIndex), span);

    public static ExecutableInstruction JumpIfFalse(int targetBlockIndex, LythonSourceSpan span)
        => CreateIndexed(ExecutableOpCode.JumpIfFalse, new Operand(OperandKind.BlockIndex, targetBlockIndex), span);

    public static ExecutableInstruction ChainLink(int slot, ExecutableBinaryOperator op, int failBlockIndex, LythonSourceSpan span)
        => new(ExecutableOpCode.ChainLink, span, new Operand(OperandKind.LocalSlot, slot), new Operand(OperandKind.BlockIndex, failBlockIndex), op, default, default, default);

    public static ExecutableInstruction ClearException(int exceptionNameIndex, LythonSourceSpan span)
        => CreateIndexed(ExecutableOpCode.ClearException, new Operand(OperandKind.ExceptionNameIndex, exceptionNameIndex), span);

    public static ExecutableInstruction MatchException(LythonSourceSpan span)
        => Create(ExecutableOpCode.MatchException, span);

    public static ExecutableInstruction BindException(int nameIndex, LythonSourceSpan span)
        => CreateIndexed(ExecutableOpCode.BindException, new Operand(OperandKind.NameIndex, nameIndex), span);

    public static ExecutableInstruction ReraiseException(LythonSourceSpan span)
        => Create(ExecutableOpCode.ReraiseException, span);

    public static ExecutableInstruction EndFinally(int targetBlockIndex, LythonSourceSpan span, int cleanupId = -1)
        => new(ExecutableOpCode.EndFinally, span, new Operand(OperandKind.BlockIndex, targetBlockIndex),
            new Operand(OperandKind.CleanupId, cleanupId), default, default, default, default);

    public static ExecutableInstruction Return(LythonSourceSpan span)
        => Create(ExecutableOpCode.Return, span);

    public static ExecutableInstruction ReturnNone(LythonSourceSpan span)
        => Create(ExecutableOpCode.ReturnNone, span);

    public static ExecutableInstruction Yield(bool delegated, LythonSourceSpan span)
        => Create(delegated ? ExecutableOpCode.YieldFrom : ExecutableOpCode.Yield, span);

    public ExecutableInstruction WithTargetBlockIndex(int targetBlockIndex)
        => OpCode switch
        {
            ExecutableOpCode.AbruptJump => AbruptJump(targetBlockIndex, DiscardIterator, Span),
            ExecutableOpCode.Jump => Jump(targetBlockIndex, Span),
            ExecutableOpCode.JumpIfFalse => JumpIfFalse(targetBlockIndex, Span),
            ExecutableOpCode.ForNext => ForNext(targetBlockIndex, Span),
            ExecutableOpCode.EndFinally => EndFinally(targetBlockIndex, Span, CleanupId),
            _ => throw new InvalidOperationException($"Instruction '{OpCode}' has no target block.")
        };

    public ExecutableInstruction WithFailureBlockIndex(int failureBlockIndex)
        => OpCode switch
        {
            ExecutableOpCode.MatchCase => MatchCase(MatchCaseIndex, failureBlockIndex, Span),
            ExecutableOpCode.ChainLink => ChainLink(ChainSlot, BinaryOperator, failureBlockIndex, Span),
            _ => throw new InvalidOperationException($"Instruction '{OpCode}' has no failure block.")
        };

    private static ExecutableInstruction Create(ExecutableOpCode opCode, LythonSourceSpan span)
        => new(opCode, span, Operand.None, Operand.None, default, default, default, default);

    private static ExecutableInstruction CreateIndexed(ExecutableOpCode opCode, Operand primaryOperand, LythonSourceSpan span)
        => new(opCode, span, primaryOperand, Operand.None, default, default, default, default);

    private static ExecutableInstruction CreateIndexed(ExecutableOpCode opCode, Operand primaryOperand, Operand secondaryOperand, LythonSourceSpan span)
        => new(opCode, span, primaryOperand, secondaryOperand, default, default, default, default);

    private int ReadOperand(Operand operand, OperandKind expectedKind)
        => operand.Kind == expectedKind
            ? operand.Value
            : throw new InvalidOperationException($"Instruction '{OpCode}' has no {expectedKind} operand.");
}

internal sealed record ExecutableBasicBlock(
    int Index,
    ExecutableInstruction[] InstructionArray)
{
    public IReadOnlyList<ExecutableInstruction> Instructions => InstructionArray;
}

internal sealed record ExecutableExceptionRegion(
    int ProtectedStartBlockIndex,
    int ProtectedEndBlockIndex,
    IReadOnlyList<string>? ExceptionTypeNames,
    string? ExceptionVariableName,
    int? ExceptBlockIndex,
    int? FinallyBlockIndex,
    int? SuiteStartBlockIndex,
    int? SuiteEndBlockIndex,
    bool ExceptionTypesAreTuple = false,
    int? CleanupId = null);

internal sealed record ExecutableImportBinding(
    string ModuleName,
    string BindingName,
    string BoundModuleName,
    IReadOnlyList<ImportedMemberSyntax>? ImportedMembers,
    LythonSourceSpan Span);

internal sealed record ExecutableCallArgumentSpec(
    CallArgumentForm Form)
{
    public CallArgumentKind Kind => Form.Kind;

    public string KeywordName => Form.KeywordName;
}

internal sealed record ExecutableCallSite(
    int ArgumentCount,
    IReadOnlyList<ExecutableCallArgumentSpec> Arguments,
    LythonSourceSpan TargetSpan,
    LythonSourceSpan CallSpan,
    bool HasReceiver = false)
{
    public bool IsPositionalOnly { get; } = Arguments.All(argument => argument.Kind == CallArgumentKind.Positional);
    public int TargetOffset => HasReceiver ? 1 : 0;
    public int ArgumentOffset => TargetOffset + 1;
}

internal sealed record ExecutableFunctionBinding(
    LoweredFunctionDefinitionStatement Function,
    ExecutableCodeObject? CodeObject,
    IReadOnlyDictionary<string, LoweredExpression> DefaultValues);

internal sealed record ExecutableMatchCaseBinding(
    MatchCaseSyntax Case,
    IReadOnlyDictionary<string, int> LocalBindingSlots);

internal sealed record ExecutableStatementFallback(
    LoweredStatement Statement);

internal sealed record ExecutableExpressionFallback(
    LoweredExpression Expression);

internal enum ExecutableSimpleReturn
{
    None,
    ReturnNone,
    ReturnValue,
    IntegerAdd,
}

internal sealed class ExecutableCodeObject
{
    public ExecutableCodeObject(
        string name,
        IReadOnlyList<object?> constants,
        IReadOnlyList<string> names,
        IReadOnlyList<string> localNames,
        IReadOnlyDictionary<string, int> localNameToSlot,
        IReadOnlyList<int> capturedLocalSlots,
        IReadOnlyList<string> closureNames,
        IReadOnlyDictionary<string, int> closureNameToSlot,
        ScopeDirectiveFacts scopeFacts,
        IReadOnlyList<ExecutableBasicBlock> blocks,
        int entryBlockIndex,
        IReadOnlyList<ExecutableExceptionRegion> exceptionRegions,
        IReadOnlyList<ExecutableImportBinding> imports,
        IReadOnlyList<ExecutableCallSite> callSites,
        int memberCacheCount,
        IReadOnlyList<ExecutableFunctionBinding> functions,
        IReadOnlyList<ExecutableMatchCaseBinding> matchCases,
        IReadOnlyList<ExecutableStatementFallback> statementFallbacks,
        IReadOnlyList<ExecutableExpressionFallback> expressionFallbacks,
        bool requiresLocalVariableMirroring,
        bool isFunctionScope)
    {
        Name = name;
        Constants = constants;
        Names = names;
        LocalNames = localNames;
        LocalNameToSlot = localNameToSlot;
        CapturedLocalSlots = capturedLocalSlots;
        ClosureNames = closureNames;
        ClosureNameToSlot = closureNameToSlot;
        ScopeFacts = scopeFacts;
        Blocks = blocks;
        EntryBlockIndex = entryBlockIndex;
        ExceptionRegions = exceptionRegions;
        Imports = imports;
        CallSites = callSites;
        MemberCacheCount = memberCacheCount;
        Functions = functions;
        MatchCases = matchCases;
        StatementFallbacks = statementFallbacks;
        ExpressionFallbacks = expressionFallbacks;
        RequiresLocalVariableMirroring = requiresLocalVariableMirroring;
        IsFunctionScope = isFunctionScope;
        SimpleReturn = ClassifySimpleReturn();
    }

    public string Name { get; }

    public IReadOnlyList<object?> Constants { get; }

    public IReadOnlyList<string> Names { get; }

    public IReadOnlyList<string> LocalNames { get; }

    public IReadOnlyDictionary<string, int> LocalNameToSlot { get; }

    public IReadOnlyList<int> CapturedLocalSlots { get; }

    public IReadOnlyList<string> ClosureNames { get; }

    public IReadOnlyDictionary<string, int> ClosureNameToSlot { get; }

    public ScopeDirectiveFacts ScopeFacts { get; }

    public IReadOnlyList<ExecutableBasicBlock> Blocks { get; }

    public int EntryBlockIndex { get; }

    public IReadOnlyList<ExecutableExceptionRegion> ExceptionRegions { get; }

    public IReadOnlyList<ExecutableImportBinding> Imports { get; }

    public IReadOnlyList<ExecutableCallSite> CallSites { get; }

    public int MemberCacheCount { get; }

    public IReadOnlyList<ExecutableFunctionBinding> Functions { get; }

    public IReadOnlyList<ExecutableMatchCaseBinding> MatchCases { get; }

    public IReadOnlyList<ExecutableStatementFallback> StatementFallbacks { get; }

    public IReadOnlyList<ExecutableExpressionFallback> ExpressionFallbacks { get; }

    public bool RequiresLocalVariableMirroring { get; }

    public bool IsFunctionScope { get; }

    public ExecutableSimpleReturn SimpleReturn { get; }

    private ExecutableSimpleReturn ClassifySimpleReturn()
    {
        if (!IsFunctionScope || RequiresLocalVariableMirroring || CapturedLocalSlots.Count != 0
            || ClosureNames.Count != 0 || ExceptionRegions.Count != 0 || Blocks.Count != 1)
            return ExecutableSimpleReturn.None;

        var instructions = Blocks[EntryBlockIndex].InstructionArray;
        if (instructions.Length == 1 && instructions[0].OpCode == ExecutableOpCode.ReturnNone)
            return ExecutableSimpleReturn.ReturnNone;
        if (instructions.Length == 2 && IsOperand(instructions[0]) && instructions[1].OpCode == ExecutableOpCode.Return)
            return ExecutableSimpleReturn.ReturnValue;
        if (instructions.Length == 4 && IsOperand(instructions[0]) && IsOperand(instructions[1])
            && instructions[2].OpCode == ExecutableOpCode.Binary && instructions[2].BinaryOperator == ExecutableBinaryOperator.Add
            && instructions[3].OpCode == ExecutableOpCode.Return)
            return ExecutableSimpleReturn.IntegerAdd;
        return ExecutableSimpleReturn.None;

        static bool IsOperand(ExecutableInstruction instruction) =>
            instruction.OpCode is ExecutableOpCode.LoadLocal or ExecutableOpCode.LoadConst;
    }
}
