using System.Numerics;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed class ExecutionValueObservation
{
    public ExecutionValueObservation(ExecutionState state)
    {
        State = state;
    }

    public ExecutionState State { get; }

    public LythonRuntime.ExecutionLimits Limits => State.Limits;

    public void ObserveString(PyString text, LythonSourceSpan? span)
    {
        EnforceStringLengthLimit(text, span);

        if (text.OwnerMemoryGovernor is null)
        {
            State.MemoryGovernor.EnsureCanReserve(PyString.EstimateApproximateBytes(text.Utf8Bytes.Length), span);
        }
    }

    public void ObserveCollectionCount(int count, LythonSourceSpan? span)
    {
        EnforceCollectionCountLimit(count, span);
    }

    public void ObserveValue(object value, LythonSourceSpan? span)
    {
        // Exact integers have no string/collection limits or governed owner.
        // Keep their transient preflight without generic shape/graph checks.
        if (value is BigInteger integer)
        {
            State.MemoryGovernor.EnsureCanReserve(RuntimeMemoryEstimates.EstimateBigIntegerBytes(integer), span);
            return;
        }

        EnforceValueLimits(value, span);

        if (RequiresTransientSizeCheck(value))
        {
            State.MemoryGovernor.EnsureCanReserve(EstimateApproximateValueBytes(value), span);
        }
    }

    private void EnforceStringLengthLimit(PyString text, LythonSourceSpan? span)
    {
        if (Limits.MaxStringLength is { } maxStringLength && text.Length > maxStringLength)
        {
            throw RuntimeErrors.Attributed("RuntimeError", $"maximum string length exceeded ({maxStringLength})", span,
                LythonFailureReason.StringLengthLimit, maxStringLength, text.Length);
        }
    }

    private void EnforceCollectionCountLimit(int count, LythonSourceSpan? span)
    {
        if (Limits.MaxCollectionSize is { } maxCollectionSize && count > maxCollectionSize)
        {
            throw RuntimeErrors.Attributed("RuntimeError", $"maximum collection size exceeded ({maxCollectionSize})", span,
                LythonFailureReason.CollectionSizeLimit, maxCollectionSize, count);
        }
    }

    private void EnforceValueLimits(object value, LythonSourceSpan? span)
    {
        if (value is PyString text)
        {
            EnforceStringLengthLimit(text, span);
        }

        if (TryGetCollectionCount(value) is { } count)
        {
            EnforceCollectionCountLimit(count, span);
        }
    }

    private static bool RequiresTransientSizeCheck(object value)
    {
        return value switch
        {
            IPyGovernedValue { OwnerMemoryGovernor: not null } => false,
            _ => true
        };
    }

    private static int? TryGetCollectionCount(object value)
    {
        return value switch
        {
            PyList list => list.Count,
            PyTuple tuple => tuple.Count,
            PyDict dict => dict.Count,
            PySet set => set.Count,
            _ => (int?)null
        };
    }

    private static long EstimateApproximateValueBytes(object value)
    {
        if (!IsReferenceTracked(value))
        {
            return EstimateApproximateValueBytesCore(value, null);
        }

        var visited = new HashSet<object>(ReferenceEqualityComparer.Instance);
        visited.Add(value);
        return EstimateApproximateValueBytesCore(value, visited);
    }

    private static long EstimateApproximateValueBytesCore(object value, HashSet<object>? visited)
    {
        return value switch
        {
            PyNone => 8,
            bool => 8,
            BigInteger integer => RuntimeMemoryEstimates.EstimateBigIntegerBytes(integer),
            double => 16,
            PyString text => 32L + text.Utf8Bytes.Length,
            PyBytes bytes => PyBytes.EstimateApproximateBytes(bytes.Length),
            PyList list => EstimateApproximateListBytes(list, visited),
            PyTuple tuple => EstimateApproximateTupleBytes(tuple, visited),
            PyDict dict => EstimateApproximateDictionaryBytes(dict, visited),
            PySet set => EstimateApproximateSetBytes(set, visited),
            LythonRuntime.ExecutionContext.TextFileHandle handle => 64 + handle.Path.Length + handle.Mode.Length,
            LythonRuntime.DictKeysView or LythonRuntime.DictValuesView or LythonRuntime.DictItemsView => 64,
            _ => 64
        };
    }

    private static long EstimateApproximateListBytes(IEnumerable<object> items, HashSet<object>? visited)
    {
        long total = 64;
        foreach (var item in items)
        {
            total += 16;
            total += EstimateApproximateNestedValueBytes(item, visited);
        }

        return total;
    }

    private static long EstimateApproximateTupleBytes(PyTuple tuple, HashSet<object>? visited)
    {
        long total = 48;
        foreach (var item in tuple)
        {
            total += 16;
            total += EstimateApproximateNestedValueBytes(item, visited);
        }

        return total;
    }

    private static long EstimateApproximateDictionaryBytes(PyDict dict, HashSet<object>? visited)
    {
        long total = 96;
        foreach (var pair in dict)
        {
            total += 32;
            total += EstimateApproximateNestedValueBytes(pair.Key, visited);
            total += EstimateApproximateNestedValueBytes(pair.Value, visited);
        }

        return total;
    }

    private static long EstimateApproximateSetBytes(PySet set, HashSet<object>? visited)
    {
        long total = 80;
        foreach (var item in set)
        {
            total += 24;
            total += EstimateApproximateNestedValueBytes(item, visited);
        }

        return total;
    }

    private static long EstimateApproximateNestedValueBytes(object value, HashSet<object>? visited)
    {
        if (!IsReferenceTracked(value))
        {
            return EstimateApproximateValueBytesCore(value, visited);
        }

        if (visited is null || !visited.Add(value))
        {
            return 0;
        }

        return EstimateApproximateValueBytesCore(value, visited);
    }

    private static bool IsReferenceTracked(object value)
    {
        return value is PyList or PyTuple or PyDict or PySet;
    }
}
