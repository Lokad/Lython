set -eu
root=/home/lokad/lython-bench-checks/nested-factories-current-attribution-b1224-20261120
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
