import json
from collections import Counter
from pathlib import Path
lab=Path(__file__).parent
reports=[]
for f in sorted((lab/'confirmation').glob('*/profile.speedscope.json')):
    data=json.loads(f.read_text(encoding='utf8'))
    frames=[item['name'] for item in data['shared']['frames']]
    leaf=Counter()
    record=json.loads((f.parent/'record.json').read_text(encoding='utf8'))
    assert record['traceExit']==0 and record['verifiedAfterCapture'] and record['joined']
    for p in data['profiles']:
        assert p['type']=='evented' and p['unit']=='milliseconds'
        stack=[]
        last=p['startValue']
        for event in p['events']:
            ms=event['at']-last
            last=event['at']
            assert ms>=0
            if stack and stack[-1]=='CPU_TIME':
                seen=next((name.split('(')[0] for name in reversed(stack) if 'Lokad.Lython.Runtime.' in name),None)
                if seen:leaf[seen]+=ms
            if event['type']=='O':stack.append(frames[event['frame']])
            else:assert stack.pop()==frames[event['frame']]
        assert not stack
    reports.append(dict(case=record['case'], source=record['sourceRevision'],
        totalManagedRuntimeCpuTaggedMilliseconds=leaf.total(),nearestManagedRuntimeMilliseconds=dict(leaf.most_common())))
assert len(reports)==3
(lab/'managed-summary.json').write_text(json.dumps(reports,indent=2)+'\n',encoding='utf8',newline='\n')
