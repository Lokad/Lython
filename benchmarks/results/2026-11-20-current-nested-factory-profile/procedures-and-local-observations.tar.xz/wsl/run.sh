#!/bin/sh
set -eu
cd "$(dirname "$0")"
LYTHON_DIAGNOSTIC_FIXTURES=$(mktemp -d /dev/shm/lython-factory-profile.XXXXXXXX)
export LYTHON_DIAGNOSTIC_FIXTURES
trap 'rmdir -- "$LYTHON_DIAGNOSTIC_FIXTURES"' EXIT
# Worker and attached collector need the same runtime socket directory.
timeout --kill-after=15s 135s python3 ./profile.py
