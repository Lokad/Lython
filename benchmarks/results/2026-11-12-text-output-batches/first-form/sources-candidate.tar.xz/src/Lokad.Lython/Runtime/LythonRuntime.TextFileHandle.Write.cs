using System.Numerics;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal sealed partial class ExecutionContext
    {
        private sealed class TextFileWriteState : TextFileState
        {
            private readonly OpenedByteFile _file;
            private readonly ExecutionState _services;
            private readonly TextEncodingMode _encoding;
            private readonly TextErrorMode _errors;
            private readonly TextNewlineMode _newline;
            private readonly GovernedByteBuilder _buffer;
            private BigInteger _publishedPosition;
            private bool _hasWrittenText;
            private bool _bomWritten;
            private static readonly byte[] Utf8Preamble = [0xef, 0xbb, 0xbf];
            private static readonly byte[] Utf16Preamble = [0xff, 0xfe];

            public TextFileWriteState(
                OpenedByteFile file,
                TextFileMode mode,
                ExecutionContext context,
                TextEncodingMode encoding,
                TextErrorMode errors,
                TextNewlineMode newline)
                : base(mode)
            {
                _file = file;
                _services = context.State;
                _encoding = encoding;
                _errors = errors;
                _newline = newline;
                _buffer = new GovernedByteBuilder(context.MemoryGovernor);
            }

            private ReadOnlyMemory<byte> PendingPreamble => !_hasWrittenText || _bomWritten ? default
                : _encoding == TextEncodingMode.Utf8Bom ? Utf8Preamble
                : _encoding == TextEncodingMode.Utf16 ? Utf16Preamble : default;

            public BigInteger Position => _publishedPosition + _buffer.Length + PendingPreamble.Length;

            public BigInteger Write(PyString text) => Write(text.Utf8Span, text);

            // Staging is synchronous. Only the actual awaited host write borrows
            // stable memory; an inline guest string needs no array view here.
            internal BigInteger Write(ReadOnlyMemory<byte> utf8) => Write(utf8.Span, null);

            private BigInteger Write(ReadOnlySpan<byte> source, PyString? original)
            {
                _services.CheckExecution(null);
                var inputLength = original?.GetCharacterCount(_services.CancellationToken, null) ?? CountScalars(source);
                var encoding = EffectiveEncoding;
                var byteCount = EncodedTextByteCount(source, encoding, _errors, _newline, _services, null, original);
                var destination = _buffer.GetWriteWindow(byteCount).Span;
                _services.CheckExecution(null);
                WriteEncodedText(source, destination[..byteCount], encoding, _errors, _newline, _services, null);
                _buffer.Advance(byteCount);
                _hasWrittenText = true;
                return new BigInteger(inputLength);
            }

            // BOM framing remains a flush concern, independently of capacity
            // admission/reentry while a write stages its final payload bytes.
            private TextEncodingMode EffectiveEncoding => _encoding switch
            {
                TextEncodingMode.Utf8Bom => TextEncodingMode.Utf8,
                TextEncodingMode.Utf16 => TextEncodingMode.Utf16LittleEndian,
                _ => _encoding,
            };

            private int CountScalars(ReadOnlySpan<byte> source)
            {
                var count = 0;
                for (var index = 0; index < source.Length; index++)
                {
                    if ((index & 1023) == 0) _services.CheckExecution(null);
                    if ((source[index] & 0xc0) != 0x80) count++;
                }
                return count;
            }

            internal void InitializePosition(long position)
            {
                _publishedPosition = position;
                _bomWritten = Mode == TextFileMode.Append && position > 0;
            }

            public async ValueTask FlushAsync(LythonSourceSpan? span, bool asynchronous)
            {
                var publishedPreamble = false;
                try
                {
                    if (PendingPreamble is { IsEmpty: false } preamble)
                    {
                        await _file.WriteAsync(preamble, span, asynchronous).ConfigureAwait(false);
                        publishedPreamble = true;
                        _bomWritten = true;
                        _services.CheckExecution(span);
                        _publishedPosition = _file.Position(span);
                    }
                    if (_buffer.Length != 0)
                    {
                        // Final bytes stay funded through the real host borrow.
                        await _file.WriteAsync(_buffer.WrittenMemory, span, asynchronous).ConfigureAwait(false);
                        _buffer.Release();
                        _services.CheckExecution(span);
                        _publishedPosition = _file.Position(span);
                    }
                }
                catch
                {
                    // The preamble and payload form one logical publication.
                    // A later zero-byte failure still follows an accepted prefix;
                    // retire the handle instead of allowing that flush to replay.
                    if (publishedPreamble) await _file.CloseAfterFailureAsync(span, asynchronous).ConfigureAwait(false);
                    throw;
                }
                await _file.FlushAsync(span, asynchronous).ConfigureAwait(false);
            }

            public void Release() => _buffer.Release();
        }
    }
}
