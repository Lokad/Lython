from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent
out=Path('benchmarks/results/2026-11-12-text-output-batches/refined')
out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
meta=json.loads((r/'diagnostic-identity.json').read_text(encoding='utf-8'))
assert len(meta['sourceHashes'])==568
assert all(sha(Path(name))==h for name,h in meta['sourceHashes'].items())
for phase in ['warm-sync','warm-async','compile']:shutil.copytree(r/phase,out/phase)
for name in ['diagnostic-identity.json','focused-checks.json','focused-source-identity.json','catalog.json','sources-candidate.tar.xz']:
 shutil.copyfile(r/name,out/name)
for p in r.glob('*.log'):shutil.copyfile(p,out/p.name)
shutil.copytree(r/'tests',out/'tests')
with tarfile.open(out/'preparation.tar.xz','w:xz')as t:
 for name in ['freeze-and-measure.py','run-final-focused.py','summarize.py','preserve.py','candidate-net10.dll']:
  t.add(r/name,arcname=name)
 for p in sorted(Path('tests').rglob('*.cs')):
  if p.name in ['EncodedFileStagingTests.cs','OwnedByteFileTests.cs','Utf16CodecAccountingTests.cs','TextFileWriteCallBoundaryTests.cs']:
   t.add(p,arcname=p.as_posix())
 for p in (r/'tool').glob('*'):
  if p.is_file():t.add(p,arcname='tool/'+p.name)
patch=subprocess.run(['git','diff','--','src/Lokad.Lython','tests'],capture_output=True,check=True).stdout
(out/'implementation.patch').write_bytes(patch)
q=r/'b608';target=out/'b608';target.mkdir()
receipt=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'))
identity=json.loads((q/'identity.json').read_text(encoding='utf-8'))
assert receipt['complete']and receipt['jobs']==6 and receipt['allWorkersJoined']and receipt['guestFixturesRemoved']and receipt['quietBeforeAndAfter']and receipt['archivedAndVerifiedUnderLease']
assert sha(q/'observations.tgz')==receipt['archiveSHA256']
with tarfile.open(q/'observations.tgz')as t:
 assert hashlib.sha256(t.extractfile('current-core.dll').read()).hexdigest()==identity['coreSHA256']['candidate']
raw=json.loads((q/'retrieved/confirmation/confirmation.json').read_text(encoding='utf-8'))
for job in raw['jobs']:
 assert job['workersJoinedAndFixturesRemoved']
 for role,d in job['identities'].items():
  assert next(v['sha256'].lower()for v in d['libraries']if Path(v['path']).name=='Lokad.Lython.dll')==identity['coreSHA256'][role]
for name in ['observations.tgz','archive-receipt.json','identity.json','source-identity.json','summary.json','terminal-status.json','inventory.json','launch.log','observe-not-before.json']:
 shutil.copyfile(q/name,target/name)
with tarfile.open(target/'preparation.tar.xz','w:xz')as t:
 for p in sorted(q.iterdir()):
  if p.is_file()and p.name not in ['observations.tgz','payload.tgz','current-core.dll']:t.add(p,arcname=p.name)
decision=dict(status='Retain coherent final-byte/bounded-output migration; full delivery pending',
 baselineRevision='f4f44caf2bea091e9f1f117abc33b37b2b429f5a',coreSHA256=identity['coreSHA256'],
 qualification='8616focused actual11/10 all pass, four complete scripts bothAPIs/separatecompile allgoldens/files/balances/cleanup pass. No full retained-source qualification claim yet.',
 change='Shared count/write codec kernels; final encoded storage, no normalizedUTF8/alternative counters/flush reencoding. Existing governed file buffer batches output, complete admission and strict validation before first effects. Async ordinary/exposed write,writelines,CSV/JSON/PyTextStream await actual hostusers. Completed receiver methods use same immediate guard; onlypendingoperation retained. Remove CanSuspend/old async guard and unused fuel snapshot.',
 contract='Filled staging publishes before explicitflush; acceptedprefix may survive failure. Physicalcapacity atmost128KiB, eachpayload atmost64KiB. No outputceiling/newowner/pool/allowance. Guestinput/otherallocations retain owners; boundedhostcommands stillstreamingboundary. Explicitflush/close releasesbuffer. Terminalrefusal remainsoriginal, no retry; pendingusersfundedthroughawaitedcleanup.',
 established='UTF8report allocation about-12.7%, UTF16-19.16%, UTF16 admittedpeak-493734B; controls/compileallocation flat. Independently corrected newline-translated codecerror subject/indices, eightCPython3.13.2 goldens. Original localhelper carrier isvaluetype; no removedheapclosure claim.',
 quiet='B608sixjobs169.344s allidentity/output/file/allowance/quiet/join/RAM/archivegates. AsyncUTF8report elapsed-3.77..+1.37%, widerCPU-5.88..-3.96%; UTF16 elapsed-1.22..-.61%, CPU-5.88..-2.44%. SyncUTF8elapsed-3.55..+.44%, CPU-2..+4.49%; syncUTF16-3.07..-.07%, CPU-5.88..+2.38%. TextAsync elapsed-3.11..+3.65%, CPU-3.15..+3.17%. CSVAsync+.03..+1.52%, CPU0. Fourprocessmedianpairings notconfidenceintervals.',
 debt='Accept small CSVelapsed debt and uncertain sync/text clocks in exchange for coherent storage/work removal and measured reportallocation/asyncCPU. No universalCPU/neutrality claim or attribution that refinement caused B607 debt to disappear; separatecollections. Prior R259/R260differentbase debts remain separate. Desktop reportRun+9..15%, compileCSV+3.85..5.75%, and initialB607+2..8.61% asyncreportCPU preserved.',
 priorForms='Original wholefileencodedform raises allocation6.8%/peak208KB, desktop syncUTF16+20..23%; initialbatchdesktop textAsync+18..23%, reportcompile+9.2..9.6%. Earlierarchitecture assertions/goldenfailure/setupmistakes and original unchangedspacefloorfailure remain in committed first-form/batching evidence.',
 boundary='Warm public invocation/mediatedRAMI/O/fullvalidation/priorresultcleanup; excludesstartup,compile,reset/protocol/finalcache. WiderCPUincludesreset/protocol. Desktopincludesreset/immediatedisposal. No newCPython/RSS/tail/largefileclaim.',
 cleanup='B608terminalcached, noVMusers/RAMfixtures. Exactcommitted initialB607candidateallaliases/raw/catalog/records retired onlyafter freshidle/UID/path/inode/allaliases/canonicalGitSHAproof; protected09ad. Free261931008B; freshproof before nextstaging.',
 ongoing='Full exactsource platform/stress/package atdelivery, representativeCPython checkpoint, then completecall/frame/operandsourcegate. Regexindependent; publication/taggingheld. One milestone doesnotcomplete performanceobjective.')
(out/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8')
files={p.relative_to(out).as_posix():dict(bytes=p.stat().st_size,sha256=sha(p))for p in out.rglob('*')if p.is_file()}
(out/'archive-identity.json').write_text(json.dumps(dict(files=files,rawArchivesVerified=True,allLoadedCoreHashesVerified=True,allUsersJoined=True,guestFixturesRemoved=True),indent=2)+'\n',encoding='utf-8')
print('RefinedR263 sources/cores/8616checks/alladversity/B608/decision archived; original evidence unchanged.')
