using System.Text.RegularExpressions;
using Lokad.Lython.Frontend;
using System.Numerics;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Threading;
using Lokad.Lython.Runtime.Numbers;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    private static object ResolveIdentifier(IdentifierExpressionSyntax identifier, ExecutionContext context)
        => ResolveName(identifier.Name, identifier.Span, context);

    internal static object ResolveName(string name, LythonSourceSpan span, ExecutionContext context, bool inlinedBindings = true)
    {
        if (inlinedBindings && context.TryGetInlinedBinding(name, out var binding))
        {
            if (binding.Frame.TryGetVariable(name, out var bound)) return bound;
            throw RuntimeErrors.UnboundLocalVariable(name, span);
        }
        if (inlinedBindings && context.InlinedComprehensionLookup is { } comprehensionLookup)
            return ResolveName(name, span, comprehensionLookup);
        if (context.ScopeFacts.IsGlobal(name))
        {
            var globalContext = GetGlobalContext(context);
            if (globalContext.CurrentExecutableFrame is not null &&
                globalContext.CurrentExecutableFrame.TryResolveLocalOrClosure(name, out var executableValue))
            {
                return executableValue;
            }

            if (globalContext.Frame.TryGetVariable(name, out var globalValue))
            {
                return globalValue;
            }

            if (context.TryGetBuiltin(name, out var builtin)) return builtin;

            throw RuntimeErrors.NameNotDefined(name, span);
        }

        if (context.TryGetNonlocalTarget(name, out _))
        {
            if (context.TryReadNonlocalValue(name, out var nonlocalValue)) return nonlocalValue;
            throw RuntimeErrors.FreeVariableNotAssociated(name, span);
        }

        for (var current = context; current is not null; current = current.ParentContext)
        {
            if (current.IsClassBody && !ReferenceEquals(current, context) && !context.IsAnnotationScope) continue;
            if (context.IsClassBody && !ReferenceEquals(current, context) &&
                context.ScopeFacts.LocalNames.Contains(name) && current.ParentContext is not null) continue;
            if (!ReferenceEquals(current, context) &&
                (current.ScopeFacts.IsGlobal(name) || current.ScopeFacts.IsNonlocal(name)))
                return ResolveName(name, span, current, inlinedBindings: false);
            if (current.CurrentExecutableFrame is not null &&
                current.CurrentExecutableFrame.TryResolveLocalOrClosure(name, out var executableValue))
            {
                return executableValue;
            }

            var found = context.IsAnnotationScope && current.AnnotationClassNamespace is { } classNamespace
                ? classNamespace.TryGetValue(name, out var value)
                : current.Frame.TryGetVariable(name, out value);
            if (found)
            {
                return value!;
            }
            if (current.FunctionName is not null && current.ScopeFacts.LocalNames.Contains(name))
            {
                throw ReferenceEquals(current, context)
                    ? RuntimeErrors.UnboundLocalVariable(name, span)
                    : RuntimeErrors.FreeVariableNotAssociated(name, span);
            }
            if (!current.IsClassBody && current.ClassCell is not null && name == "__class__")
                throw RuntimeErrors.FreeVariableNotAssociated(name, span);
            if (context.IsAnnotationScope && current.IsClassBody && current.ClassCell is { } classCell && name == "__class__")
            {
                if (classCell.Value is null)
                    throw RuntimeErrors.FreeVariableNotAssociated(name, span);
                return classCell.Value;
            }
        }

        if (context.TryGetBuiltin(name, out var builtinValue)) return builtinValue;
        throw RuntimeErrors.NameNotDefined(name, span);
    }

    internal static void StoreName(string name, object value, ExecutionContext context, LythonSourceSpan span)
    {
        // A retained closure cell remains authoritative after its defining
        // executable workspace has detached. Do not write only its old namespace.
        if (context.ScopeFacts.IsNonlocal(name) && !context.TryGetInlinedBinding(name, out _))
            context.CurrentExecutableFrame?.TryStoreLocalOrClosure(name, value);
        var storageContext = ResolveNameStorageContext(name, context, span);
        if (storageContext.GlobalNamespace is not null)
        {
            StoreGlobalNamespaceName(storageContext, name, value);
            return;
        }
        storageContext.Variables[name] = value;
        storageContext.CurrentExecutableFrame?.TryStoreLocalOrClosure(name, value);
    }

    internal static bool DeleteName(string name, ExecutionContext context, LythonSourceSpan span)
    {
        var removed = false;
        if (context.ScopeFacts.IsNonlocal(name) && !context.TryGetInlinedBinding(name, out _)
            && context.CurrentExecutableFrame is { } frame &&
            frame.TryGetCell(name, out var cell))
        {
            removed = cell.Value is not null;
            cell.Value = null;
        }
        var storageContext = ResolveNameStorageContext(name, context, span);
        if (storageContext.GlobalNamespace is not null)
            return storageContext.GlobalNamespaceBacking!.TryGetNameKey(name, out var key) &&
                storageContext.GlobalNamespace.Remove(key);
        removed |= storageContext.Variables.Remove(name);
        removed |= storageContext.CurrentExecutableFrame?.TryDeleteLocalOrClosure(name) == true;

        return removed;
    }

    private static LythonRuntimeException MissingDeletedName(string name, ExecutionContext context, LythonSourceSpan span)
        => context.TryGetNonlocalTarget(name, out _)
            ? RuntimeErrors.FreeVariableNotAssociated(name, span)
            : context.FunctionName is not null && context.ScopeFacts.LocalNames.Contains(name)
                ? RuntimeErrors.UnboundLocalVariable(name, span)
                : RuntimeErrors.NameNotDefined(name, span);

    internal static ExecutionContext ResolveNameStorageContext(string name, ExecutionContext context, LythonSourceSpan span)
    {
        if (context.TryGetInlinedBinding(name, out var binding)) return binding;
        if (context.ScopeFacts.IsGlobal(name))
        {
            return GetGlobalContext(context);
        }

        if (context.TryGetNonlocalTarget(name, out var nonlocalContext))
        {
            return nonlocalContext;
        }

        return context;
    }

    internal static ExecutionContext GetGlobalContext(ExecutionContext context)
    {
        var current = context;
        while (current.ParentContext is not null)
        {
            current = current.ParentContext;
        }

        return current;
    }

    private static object ResolveMember(MemberExpressionSyntax member, ExecutionContext context)
    {
        var target = EvaluateExpression(member.Target, context);
        if (TryResolveRuntimeMember(target, member.MemberName, context, member.Span, out var value))
        {
            return value;
        }

        throw PyMemberAccess.CreateMissingMemberError(target, member.MemberName, member.Span, context);
    }

    internal static bool TryResolveRuntimeMember(object target, string memberName, ExecutionContext context, LythonSourceSpan span, [MaybeNullWhen(false)] out object value)
    {
        if (!PyMemberAccess.TryResolve(target, memberName, context, span, out value))
        {
            return false;
        }

        // Bound engine methods report their receiver like CPython. Each
        // instance is fresh per access, so threading here covers every
        // member table at once; instances, types, supers and modules
        // keep their own binding rules (or none).
        if (value is BoundCallable unbound &&
            target is not PyInstance &&
            target is not PyType &&
            target is not PySuper &&
            target is not PyModule)
        {
            unbound.AttachReceiver(target);
        }

        return true;
    }

    private static object EvaluateSubscript(SubscriptExpressionSyntax subscript, ExecutionContext context)
    {
        var target = EvaluateExpression(subscript.Target, context);
        var index = EvaluateExpression(subscript.Index, context);
        return ReadSubscriptValue(target, index, subscript.Span, context);
    }

    private static object EvaluateSlice(SliceExpressionSyntax slice, ExecutionContext context)
    {
        var target = EvaluateExpression(slice.Target, context);
        var start = slice.Start is null ? null : EvaluateExpression(slice.Start, context);
        var end = slice.End is null ? null : EvaluateExpression(slice.End, context);
        var step = slice.Step is null ? null : EvaluateExpression(slice.Step, context);

        return ReadSliceValue(target, start, end, step, slice.Span, context);
    }

    internal static bool IsTruthy(object value) => PyTruthiness.IsTruthy(value);

    internal static bool IsTruthy(object value, ExecutionContext context, LythonSourceSpan span)
    {
        if (value is not PyInstance instance)
        {
            return PyTruthiness.IsTruthy(value);
        }

        var protocol = ResolveTruthinessSlot(instance, out var rawMember);
        return protocol == TruthinessProtocol.Default
            ? true
            : InterpretTruthinessResult(protocol,
                RequireTruthinessCallable(PyAttributeLookup.BindForInstance(instance, rawMember, context, span), context, span)
                    .Invoke([], span, context), span);
    }

    internal static ValueTask<bool> IsTruthyAsync(object value, ExecutionContext context, LythonSourceSpan span)
        => value is PyInstance instance
            ? IsInstanceTruthyAsync(instance, context, span)
            : new(PyTruthiness.IsTruthy(value));

    private static async ValueTask<bool> IsInstanceTruthyAsync(PyInstance instance, ExecutionContext context, LythonSourceSpan span)
    {
        var protocol = ResolveTruthinessSlot(instance, out var rawMember);
        if (protocol == TruthinessProtocol.Default)
        {
            return true;
        }

        var member = await PyAttributeLookup.BindForInstanceAsync(instance, rawMember, context, span).ConfigureAwait(false);
        var callable = RequireTruthinessCallable(member, context, span);
        var result = await callable.InvokeAsync([], span, context).ConfigureAwait(false);
        return InterpretTruthinessResult(protocol, result, span);
    }

    private static TruthinessProtocol ResolveTruthinessSlot(PyInstance instance, out object rawMember)
    {
        // Implicit truth testing consults type slots and preserves __bool__
        // priority even when its member is invalid, rather than trying __len__.
        if (instance.Type.TryLookupInMro("__bool__", 0, out var boolMember, out _))
        {
            rawMember = boolMember;
            return TruthinessProtocol.Boolean;
        }
        if (instance.Type.TryLookupInMro("__len__", 0, out var lengthMember, out _))
        {
            rawMember = lengthMember;
            return TruthinessProtocol.Length;
        }
        rawMember = PyNone.Instance;
        return TruthinessProtocol.Default;
    }

    private static ICallable RequireTruthinessCallable(object member, ExecutionContext context, LythonSourceSpan span)
        => member is ICallable callable ? callable
            : throw new LythonRuntimeException("TypeError", "'" + UnboundTypeMethod.PythonTypeName(member, context) + "' object is not callable", span);

    private static bool InterpretTruthinessResult(TruthinessProtocol protocol, object result, LythonSourceSpan span)
    {
        if (protocol == TruthinessProtocol.Boolean)
        {
            return result is bool boolean
                ? boolean
                : throw new LythonRuntimeException("TypeError", "__bool__ should return bool", span);
        }

        if (!PyNumberOps.TryAsInteger(result, out var length))
        {
            throw new LythonRuntimeException("TypeError", "__len__() should return an integer", span);
        }

        if (length < 0)
        {
            throw new LythonRuntimeException("ValueError", "__len__() should return >= 0", span);
        }

        if (length > long.MaxValue)
            throw new LythonRuntimeException("OverflowError", "cannot fit '__len__' result into an index-sized integer", span);

        return length != 0;
    }

    private enum TruthinessProtocol
    {
        Default,
        Boolean,
        Length,
    }

    internal static IEnumerable<object> ToSequence(object value, LythonSourceSpan span)
        => PyIteration.ToSequence(value, span);

    internal static IEnumerable<object> ToSequence(object value, LythonSourceSpan span, ExecutionContext context)
        => PyIteration.ToSequence(value, span, context);

    internal static IAsyncEnumerable<object> ToSequenceAsync(object value, LythonSourceSpan span)
        => PyIteration.ToSequenceAsync(value, span);

    internal static IAsyncEnumerable<object> ToSequenceAsync(object value, LythonSourceSpan span, ExecutionContext context)
        => PyIteration.ToSequenceAsync(value, span, context);

    internal static bool AreEqual(object left, object right) => PyEquality.AreEqual(left, right);

    private static int Compare(object left, object right, LythonSourceSpan span) => PyComparison.Compare(left, right, span);

    private static bool Contains(object container, object candidate, LythonSourceSpan span) => PyContainment.Contains(container, candidate, span);

    internal static object GetUserItem(PyInstance instance, object index, ExecutionContext context, LythonSourceSpan span)
        => GetUserItemCoreAsync(instance, index, context, span, false).GetAwaiter().GetResult();

    internal static ValueTask<object> GetUserItemAsync(PyInstance instance, object index, ExecutionContext context, LythonSourceSpan span)
        => GetUserItemCoreAsync(instance, index, context, span, true);

    private static async ValueTask<object> GetUserItemCoreAsync(PyInstance instance, object index,
        ExecutionContext context, LythonSourceSpan span, bool asynchronous)
    {
        if (!instance.Type.TryLookupInMro("__getitem__", 0, out var raw, out _))
            throw new LythonRuntimeException("TypeError", $"'{instance.Type.Name}' object is not subscriptable", span);
        var member = asynchronous
            ? await PyAttributeLookup.BindForInstanceAsync(instance, raw, context, span).ConfigureAwait(false)
            : PyAttributeLookup.BindForInstance(instance, raw, context, span);
        if (member is not ICallable callable) throw NotCallableError(member, context, span);
        return asynchronous
            ? await CallableInvocation.InvokeUnaryAsync(callable, index, span, context).ConfigureAwait(false)
            : CallableInvocation.InvokeUnary(callable, index, span, context);
    }

    internal static async ValueTask<object> ReadTypeSubscriptAsync(PyType type, object index,
        ExecutionContext context, LythonSourceSpan span, bool asynchronous)
    {
        context.CheckExecution(span);
        if (type.TryLookupInMro("__class_getitem__", 0, out var raw, out _))
        {
            object member;
            try
            {
                member = asynchronous
                    ? await PyAttributeLookup.BindForTypeAsync(type, raw, context, span).ConfigureAwait(false)
                    : PyAttributeLookup.BindForType(type, raw, context, span);
            }
            catch (LythonRuntimeException error) when (error.ExceptionType == "AttributeError")
            {
                // Python's optional attribute lookup treats a descriptor's
                // AttributeError as absence, without undoing its earlier effects.
                context.CheckExecution(span);
                member = PyNone.Instance;
            }
            context.CheckExecution(span);
            if (member is not PyNone)
                return await InvokeTypeSubscriptionMemberAsync(member, index, context, span, asynchronous).ConfigureAwait(false);
        }
        else if (ReferenceEquals(type, context.State.TypingGeneric) || type.TryGetMember("__type_params__", out _))
        {
            return await CreateGenericSubscriptAsync(type, index, context, span, asynchronous).ConfigureAwait(false);
        }
        throw new LythonRuntimeException("TypeError", $"type '{type.Name}' is not subscriptable", span);
    }

    private static async ValueTask<object> InvokeTypeSubscriptionMemberAsync(object member, object index,
        ExecutionContext context, LythonSourceSpan span, bool asynchronous)
    {
        context.CheckExecution(span);
        var result = asynchronous
            ? await CallableInvocation.InvokeUnaryAsync(member, index, span, context).ConfigureAwait(false)
            : CallableInvocation.InvokeUnary(member, index, span, context);
        context.CheckExecution(span);
        return result;
    }

    // Shared native sequence/XML conversion: implicit index hooks come from the
    // type, and may suspend during descriptor binding or the call itself.
    // Read-only builtin sequences also convert scalar indices before rejecting
    // assignment/deletion; mappings and user item protocols keep raw keys.
    private static bool UsesNativeMutationIndex(object target)
        => target is IMutablePySequenceValue or PyTuple or PyBytes or PyString or PyRange or string;

    internal static async ValueTask<object?> CoerceTypeIndexAsync(object? index, ExecutionContext context,
        LythonSourceSpan span, bool asynchronous)
    {
        if (index is not PyInstance instance) return index;
        if (!instance.Type.TryLookupInMro("__index__", 0, out var raw, out _)) return index;
        var callable = asynchronous
            ? await PyAttributeLookup.BindForInstanceAsync(instance, raw, context, span).ConfigureAwait(false)
            : PyAttributeLookup.BindForInstance(instance, raw, context, span);
        if (callable is not ICallable) throw NotCallableError(callable, context, span);
        var result = asynchronous
            ? await InvokeCallableTargetAsync(callable, span, span, context,
                () => ValueTask.FromResult(Array.Empty<CallArgumentValue>())).ConfigureAwait(false)
            : InvokeCallableTarget(callable, span, span, context, Array.Empty<CallArgumentValue>());
        if (!PyNumberOps.TryAsInteger(result, out var integer))
            throw RuntimeErrors.Type("__index__ returned non-int (type " +
                UnboundTypeMethod.PythonTypeName(result, context) + ")", span);
        return result is BigInteger ? result : integer;
    }

    internal static async ValueTask<(object? Start, object? End, object? Step)> CoerceSliceBoundsAsync(
        object? start, object? end, object? step, ExecutionContext context, LythonSourceSpan span, bool asynchronous)
    {
        step = await CoerceTypeIndexAsync(step, context, span, asynchronous).ConfigureAwait(false);
        if (PyIndexing.NormalizeSliceBound(step, span) is { IsZero: true })
            throw RuntimeErrors.Value("slice step cannot be zero", span);
        start = await CoerceTypeIndexAsync(start, context, span, asynchronous).ConfigureAwait(false);
        _ = PyIndexing.NormalizeSliceBound(start, span);
        end = await CoerceTypeIndexAsync(end, context, span, asynchronous).ConfigureAwait(false);
        _ = PyIndexing.NormalizeSliceBound(end, span);
        return (start, end, step);
    }

    internal static object CoerceIndexProtocol(object index, ExecutionContext context, LythonSourceSpan span)
        => CoerceTypeIndexAsync(index, context, span, false).GetAwaiter().GetResult()!;

    private static object ValidateIntegerConversionResult(object converted, string method, ExecutionContext context, LythonSourceSpan span)
    {
        if (!PyNumberOps.TryAsInteger(converted, out var integer))
        {
            throw new LythonRuntimeException("TypeError", method + " returned non-int (type " + UnboundTypeMethod.PythonTypeName(converted, context) + ")", span);
        }

        return converted is BigInteger ? converted : integer;
    }

    private static PyString CoercePathLike(object value, ExecutionContext context, LythonSourceSpan span, string owner)
    {
        if (value is PyPath path)
        {
            return path.Value;
        }

        if (value is PyDirEntryObject dirEntry)
        {
            return PyString.FromString(dirEntry.Path, context.MemoryGovernor, span);
        }

        if (PyStringOps.TryAsString(value, out var text))
        {
            return text;
        }

        if (TryInvokeUnarySpecialMethod(value, "__fspath__", context, span, out var result))
            return PyStringOps.TryAsString(result, out var converted) ? converted
                : throw RuntimeErrors.Type("__fspath__() must return str", span);

        throw new LythonRuntimeException("TypeError", owner + " expects a path-like object", span);
    }

    private static async ValueTask<PyString> CoercePathLikeAsync(object value, ExecutionContext context, LythonSourceSpan span, string owner)
    {
        if (value is not PyInstance instance) return CoercePathLike(value, context, span, owner);
        var invocation = await InvokeNumericConversionProtocolAsync(instance, "__fspath__", context, span).ConfigureAwait(false);
        if (invocation.Kind != SpecialMethodInvocationKind.Invoked)
            throw RuntimeErrors.Type(owner + " expects a path-like object", span);
        return PyStringOps.TryAsString(invocation.Value, out var result) ? result
            : throw RuntimeErrors.Type("__fspath__() must return str", span);
    }

    private static object EvaluateListComprehension(ListComprehensionExpressionSyntax comprehension, ExecutionContext context)
    {
        var result = new PyList([], context.MemoryGovernor, comprehension.Span);
        var outer = ToSequence(EvaluateExpression(comprehension.Clauses[0].Iterable, context), comprehension.Clauses[0].Iterable.Span, context);
        using var bindings = context.EnterComprehension(ComprehensionSyntaxFacts.Bindings(comprehension.Clauses.Select(clause => clause.Target)));
        EvaluateComprehensionClauses(
            comprehension.Clauses,
            0,
            context,
            scope => result.Add(RuntimeValue(EvaluateExpression(comprehension.ItemExpression, scope))), outer);

        context.CheckExecution(comprehension.Span);
        return result;
    }

    private static object EvaluateSetComprehension(SetComprehensionExpressionSyntax comprehension, ExecutionContext context)
    {
        using var _ambientScope = PyStructuralGuard.PushAmbient(context, comprehension.Span);
        var result = new PySet(context.MemoryGovernor, comprehension.Span);
        var outer = ToSequence(EvaluateExpression(comprehension.Clauses[0].Iterable, context), comprehension.Clauses[0].Iterable.Span, context);
        using var bindings = context.EnterComprehension(ComprehensionSyntaxFacts.Bindings(comprehension.Clauses.Select(clause => clause.Target)));
        EvaluateComprehensionClauses(
            comprehension.Clauses,
            0,
            context,
            scope =>
            {
                var item = ValidateSetItem(
                    EvaluateExpression(comprehension.ItemExpression, scope),
                    comprehension.ItemExpression.Span);
                result.Add(item);
            }, outer);

        context.CheckExecution(comprehension.Span);
        return result;
    }

    private static object EvaluateDictComprehension(DictComprehensionExpressionSyntax comprehension, ExecutionContext context)
    {
        using var _ambientScope = PyStructuralGuard.PushAmbient(context, comprehension.Span);
        var result = new PyDict(context.MemoryGovernor, comprehension.Span);
        var outer = ToSequence(EvaluateExpression(comprehension.Clauses[0].Iterable, context), comprehension.Clauses[0].Iterable.Span, context);
        using var bindings = context.EnterComprehension(ComprehensionSyntaxFacts.Bindings(comprehension.Clauses.Select(clause => clause.Target)));
        EvaluateComprehensionClauses(
            comprehension.Clauses,
            0,
            context,
            scope =>
            {
                var key = ValidateDictionaryKey(EvaluateExpression(comprehension.KeyExpression, scope), comprehension.KeyExpression.Span);
                result.SetItem(key, RuntimeValue(EvaluateExpression(comprehension.ValueExpression, scope)));
            }, outer);

        context.CheckExecution(comprehension.Span);
        return result;
    }

    private static object EvaluateGeneratorExpression(GeneratorExpressionSyntax generator, ExecutionContext context)
    {
        var clauses = generator.Clauses.Select(clause => new LoweredComprehensionClause(
            clause.Target,
            LoweredScript.LowerStandaloneExpression(clause.Iterable),
            clause.Condition is null ? null : LoweredScript.LowerStandaloneExpression(clause.Condition),
            clause.Span)).ToArray();
        // The outermost iterable is evaluated and acquired eagerly, matching
        // CPython; only element expressions, filters, and later clauses stay
        // deferred. Rebinding the source name later observes the old value.
        var outer = PyIteration.AcquireGeneratorOuter(EvaluateLoweredExpression(clauses[0].Iterable, context), clauses[0].Iterable.Span, context);
        var produced = new PyGeneratorExpression(
            clauses,
            LoweredScript.LowerStandaloneExpression(generator.ItemExpression),
            context.FunctionClosureContext,
            generator.Span,
            outer, generator.PreparedComprehensionScopeFacts ??
                ComprehensionSyntaxFacts.Bindings(clauses.Select(clause => clause.Target), generator: true));
        return produced;
    }

    private static void EvaluateComprehensionClauses(
        IReadOnlyList<ComprehensionClauseSyntax> clauses,
        int index,
        ExecutionContext context,
        Action<ExecutionContext> emit,
        IEnumerable<object>? outerSequence = null)
    {
        var clause = clauses[index];
        var sequence = outerSequence ?? ToSequence(EvaluateExpression(clause.Iterable, context), clause.Iterable.Span, context);

        foreach (var item in sequence)
        {
            AssignLoopTarget(clause.Target, item, clause.Iterable.Span, context);

            if (clause.Condition is not null &&
                !IsTruthy(EvaluateExpression(clause.Condition, context), context, clause.Condition.Span))
            {
                continue;
            }

            if (index + 1 == clauses.Count)
            {
                emit(context);
            }
            else
            {
                EvaluateComprehensionClauses(clauses, index + 1, context, emit);
            }
        }
    }

    internal static void AssignLoopTarget(LoopTargetSyntax target, object value, LythonSourceSpan span, ExecutionContext context)
        => AssignLoopTargetCoreAsync(target, value, span, context, false).GetAwaiter().GetResult();

    internal static ValueTask AssignLoopTargetAsync(LoopTargetSyntax target, object value, LythonSourceSpan span, ExecutionContext context)
        => AssignLoopTargetCoreAsync(target, value, span, context, true);

    private static async ValueTask AssignLoopTargetCoreAsync(
        LoopTargetSyntax target,
        object value,
        LythonSourceSpan span,
        ExecutionContext context, bool asynchronous)
    {
        switch (target)
        {
            case LoopStoreTargetSyntax store:
                if (asynchronous) await AssignTargetAsync(store.LoweredTarget, value, context).ConfigureAwait(false);
                else AssignTarget(store.Target, value, context);
                return;
            case LoopNameTargetSyntax name:
                StoreName(name.Name, value, context, span);
                return;
            case LoopTupleTargetSyntax tuple:
                {
                    var starIndex = -1;
                    for (var i = 0; i < tuple.Items.Count; i++)
                    {
                        if (AssignmentTargetFacts.IsStarred(tuple.Items[i]))
                        {
                            if (starIndex >= 0)
                            {
                                throw new InvalidOperationException("Multiple starred loop targets.");
                            }

                            starIndex = i;
                        }
                    }

                    var layout = new UnpackingLayout(tuple.Items.Count, starIndex);
                    using var materialized = asynchronous
                        ? await MaterializeHeaderSequenceAsync(value, span, context, layout.MaximumReadCount).ConfigureAwait(false)
                        : MaterializeUnpackingSequence(value, span, context, layout.MaximumReadCount);
                    var values = materialized.Items;
                    if (starIndex < 0)
                    {
                        if (values.Count != tuple.Items.Count)
                        {
                            throw new LythonRuntimeException("ValueError", DescribeLoopArityMismatch(tuple.Items.Count, values.Count), span);
                        }

                        for (var i = 0; i < tuple.Items.Count; i++)
                        {
                            await AssignLoopTargetCoreAsync(tuple.Items[i], values[i], span, context, asynchronous).ConfigureAwait(false);
                        }

                        return;
                    }

                    var required = tuple.Items.Count - 1;
                    if (values.Count < required)
                    {
                        throw new LythonRuntimeException("ValueError", $"not enough values to unpack (expected at least {required}, got {values.Count})", span);
                    }

                    for (var i = 0; i < starIndex; i++)
                    {
                        await AssignLoopTargetCoreAsync(tuple.Items[i], values[i], span, context, asynchronous).ConfigureAwait(false);
                    }

                    var starredCount = values.Count - required;
                    if (AssignmentTargetFacts.IsStarred(tuple.Items[starIndex]))
                    {
                        var remainder = new PyList(values.Skip(starIndex).Take(starredCount), context.MemoryGovernor, span);
                        if (tuple.Items[starIndex] is LoopStarredTargetSyntax starred) StoreName(starred.Name, remainder, context, span);
                        else await AssignLoopTargetCoreAsync(tuple.Items[starIndex], remainder, span, context, asynchronous).ConfigureAwait(false);
                    }

                    for (var i = starIndex + 1; i < tuple.Items.Count; i++)
                    {
                        await AssignLoopTargetCoreAsync(tuple.Items[i], values[values.Count - (tuple.Items.Count - i)], span, context, asynchronous).ConfigureAwait(false);
                    }

                    return;
                }
            default:
                throw new InvalidOperationException($"Unsupported loop target type: {target.GetType().Name}");
        }
    }

    private static void AssignTargets(
        IReadOnlyList<UnpackingTargetSyntax> targets,
        object value,
        LythonSourceSpan span,
        ExecutionContext context)
    {
        var layout = UnpackingLayout.FromTargets(targets);
        using var materialized = MaterializeUnpackingSequence(value, span, context, layout.MaximumReadCount);
        var values = materialized.Items;
        if (!layout.AcceptsValueCount(values.Count))
        {
            throw new LythonRuntimeException("ValueError", layout.DescribeArityMismatch(values.Count), span);
        }

        if (!layout.HasStarredTarget)
        {
            for (var i = 0; i < targets.Count; i++)
            {
                StoreUnpackingTarget(targets[i], values[i], context, span);
            }

            return;
        }

        for (var i = 0; i < layout.StarredTargetIndex; i++)
        {
            StoreUnpackingTarget(targets[i], values[i], context, span);
        }

        var starredCount = layout.StarredValueCount(values.Count);
        var remainder = new PyList(values.Skip(layout.StarredTargetIndex).Take(starredCount), context.MemoryGovernor, span);
        StoreUnpackingTarget(targets[layout.StarredTargetIndex], remainder, context, span);

        for (var i = layout.StarredTargetIndex + 1; i < targets.Count; i++)
        {
            var offset = layout.SourceIndexForTrailingTarget(i, values.Count);
            StoreUnpackingTarget(targets[i], values[offset], context, span);
        }
    }

    private static void StoreUnpackingTarget(
        UnpackingTargetSyntax target,
        object value,
        ExecutionContext context,
        LythonSourceSpan span)
    {
        switch (target)
        {
            case UnpackingNameTargetSyntax name:
                StoreName(name.Name, value, context, span);
                return;

            case UnpackingSubscriptTargetSyntax subscript:
                AssignSubscriptTarget(
                    new SubscriptAssignmentTargetSyntax(subscript.Target, subscript.Index, subscript.Span),
                    value,
                    context);
                return;

            case UnpackingSliceTargetSyntax slice:
                AssignSliceTarget(
                    new SliceAssignmentTargetSyntax(slice.Target, slice.Start, slice.End, slice.Step, slice.Span),
                    value,
                    context);
                return;

            case UnpackingMemberTargetSyntax member:
                AssignMemberTarget(
                    new MemberAssignmentTargetSyntax(member.Target, member.MemberName, member.Span),
                    value,
                    context);
                return;

            case UnpackingNestedTargetSyntax nested:
                AssignTargets(nested.Items, value, nested.Span, context);
                return;

            default:
                throw new InvalidOperationException($"Unsupported unpacking target syntax: {target.GetType().Name}");
        }
    }

    // Exact tuples already own immutable item storage. Keep that owner through
    // all target users; other sources still need the existing private snapshot.
    private readonly struct UnpackingValues(IReadOnlyList<object> items, PyIteration.DrainLease? storage = null) : IDisposable
    {
        public IReadOnlyList<object> Items => items;
        public UnpackingValues(PyIteration.DrainLease storage) : this(storage.Items, storage) { }
        public void Dispose() => storage?.Dispose();
    }

    private static UnpackingValues MaterializeUnpackingSequence(object value, LythonSourceSpan span, ExecutionContext context, int? maximumItems = null)
    {
        context.CheckExecution(span);
        if (value is PyTuple tuple) return new(tuple);
        try
        {
            return new(PyIteration.MaterializeLeased(value, span, context, maximumItems));
        }
        catch (PyNotIterableException)
        {
            throw CannotUnpack(value, span, context);
        }
    }

    private static LythonRuntimeException CannotUnpack(object value, LythonSourceSpan span, ExecutionContext context)
    {
        var name = value is PyTypeParameter parameter ? $"typing.{parameter.Kind}" : UnboundTypeMethod.PythonTypeName(value, context);
        return new LythonRuntimeException("TypeError", $"cannot unpack non-iterable {name} object", span);
    }

    private static string DescribeLoopArityMismatch(int targetCount, int valueCount)
        => valueCount > targetCount
            ? $"too many values to unpack (expected {targetCount})"
            : $"not enough values to unpack (expected {targetCount}, got {valueCount})";

}
