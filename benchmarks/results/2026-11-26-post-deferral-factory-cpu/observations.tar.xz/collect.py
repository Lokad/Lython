from pathlib import Path
import fcntl
import hashlib
import json
import os
import shutil
import stat
import subprocess
import tarfile
import time
import traceback

root = Path(__file__).resolve().parent
image = root.parent / "boolean-increments-b1766-20261126/candidate"
worker = image / "Lokad.Lython.Benchmarks.dll"
sdk = Path.home() / "lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148"
env = dict(os.environ, DOTNET_ROOT=str(sdk))
identity = json.loads((root/"identity.json").read_text())
fixtures = root/"guest-fixtures"
archive = root/"observations.tar.xz"

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def verify_image():
    for role, expected in identity["imageFiles"].items():
        frozen = image.parent / role
        assert len(expected)==32
        assert {p.name:digest(p) for p in frozen.iterdir()}==expected

def check_machine(label):
    path = root/(label+"-machine.json")
    subprocess.run([sdk/"dotnet",worker,"--compare","check-machine","--out",path],env=env,check=True,timeout=15)
    return json.loads(path.read_text())["gate"]["quiet"]

with (root.parent/"comparison-vm.lock").open("a") as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert shutil.disk_usage(root).free >= 8*1024*1024-256*1024
    assert digest(root.parent/"boolean-increments-b1766-20261126"/'observations.tar.xz') == json.loads((root/'identity.json').read_text())['donorArchiveSHA256']
    verify_image()
    fixtures.mkdir()
    subprocess.run(["sudo","-n","mount","-t","tmpfs","-o","size=32m,mode=0700,uid=lokad,gid=lokad","b1769-fixtures",fixtures],check=True)
    failure = None
    before = after = False
    try:
        assert os.stat(fixtures).st_dev != os.stat(root).st_dev
        time.sleep(8)
        before = check_machine("before")
        assert before
        subprocess.run(["python3",root/"ops-profile.py",root/"profiles",image.parent],check=True)
        verify_image()
    except Exception:
        failure = traceback.format_exc()
        (root/"failure.txt").write_text(failure)
    finally:
        assert subprocess.run(["pgrep","-af","[d]otnet.*--compare worker.*"+str(root)+
            "|[p]erf record.*"+str(root)],capture_output=True).returncode==1
        try:
            time.sleep(20)
            after = check_machine("after")
        except Exception:
            if failure is None: failure = traceback.format_exc()
        finally:
            entries = []
            for entry in fixtures.iterdir():
                mode = entry.lstat().st_mode
                entries.append(dict(name=entry.name, mode=stat.filemode(mode)))
            if entries:
                (root/"remaining-fixture-entries.json").write_text(json.dumps(entries,indent=2)+"\n")
                if failure is None: failure = "Unexpected fixture entries after joining workers"
            subprocess.run(["sudo","-n","umount",fixtures],check=True)
            fixtures.rmdir()
        expected_members = {p.relative_to(root).as_posix():digest(p) for p in root.rglob("*")
                            if p.is_file() and p != archive}
        with tarfile.open(archive,"w:xz") as frozen:
            for name in sorted(expected_members): frozen.add(root/name,arcname=name,recursive=False)
        with tarfile.open(archive) as frozen:
            assert {m.name:hashlib.sha256(frozen.extractfile(m).read()).hexdigest()
                    for m in frozen if m.isfile()} == expected_members
        complete = failure is None and before and after
        receipt=dict(complete=complete, quietBeforeAndAfter=before and after, allWorkersJoined=True,
                     guestFixturesRemoved=True, archivedAndVerifiedUnderLease=True,
                     archiveSHA256=digest(archive), freeBytes=shutil.disk_usage(root).free, failure=failure)
        (root/"archive-receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
        print(json.dumps(receipt),flush=True)
    assert complete, failure
