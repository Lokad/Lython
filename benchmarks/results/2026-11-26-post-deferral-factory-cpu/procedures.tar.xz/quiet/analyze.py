from pathlib import Path
import bisect,collections,gzip,json,re,tarfile,hashlib
r=Path(__file__).parent;rows=[]
with tarfile.open(r/"observations.tar.xz") as archive:
 archive.extractall(r/"retrieved",filter="data")
for label, case, role in json.loads((r/'identity.json').read_text(encoding='utf-8'))['profiles']:
 f=r/'retrieved/profiles'/label;record=json.loads((f/'record.json').read_text(encoding='utf-8'));ranges=[];malformed=[]
 for line in gzip.open(f/'perf.map.gz','rt',encoding='utf-8').read().splitlines(keepends=True):
  parts=line.rstrip().split(' ',2)
  if len(parts)!=3 or not line.endswith('\n'):malformed.append(line);continue
  start,size,name=parts;ranges.append((int(start,16),int(size,16),name))
 ranges=sorted(set(ranges));starts=[x[0]for x in ranges];prefix=[]
 for start,size,name in ranges:prefix.append(max(start+size,prefix[-1]if prefix else 0))
 def symbol(address,fallback):
  index=bisect.bisect_right(starts,address)-1;matches=set()
  while index>=0 and prefix[index]>address:
   start,size,name=ranges[index]
   if start<=address<start+size:matches.add(name)
   index-=1
  return next(iter(matches))if len(matches)==1 else'[ambiguous] '+repr(sorted(matches))if matches else fallback
 samples=[];current=None;allThreads=collections.Counter()
 for line in gzip.open(f/'all-thread-stacks.txt.gz','rt',encoding='utf-8').read().splitlines():
  header=re.match(r'^.*?\s(\d+)\s+\d+\.\d+:\s+\d+\s+cpu-clock:',line)
  if header:
   allThreads[header[1]]+=1;current=[]
   if current is not None:samples.append(current)
   continue
  frame=re.match(r'^\s+([0-9a-f]+)\s+(.*)$',line)
  if current is not None and frame:current.append(symbol(int(frame[1],16),frame[2]))
 if current is not None:samples.append(current)
 leaves=collections.Counter(s[0]for s in samples if s);nearest=collections.Counter(next((n for n in s if'Lokad.Lython.'in n),'[no Lython frame]')for s in samples if s)
 groups={'frontend':['LythonFrontend','Parser','Lexer','ExecutableScript','ExecutableStackLayout','LoweredScript'],'invocation setup':['CreateBuiltinVariables','ExecutionState','CreateRoot','CreateModuleVariables'],'function entry/binding/retirement':['StartNativeWorkspace','StartNativeCall','StartInline','TryStartBoundInvocation','EnterFunctionCall','LeaveFunctionCall','BindFunctionArgumentsInto','ReturnBoundArguments'],'closed instruction execution':['NativeExecution','ExecutableKernel','ExecuteInstructionPrefix'],'iteration and cased preparation':['Cased','CaseMapped','Whitespace','PyFileObject','StringWordCursor'],'dictionary accumulation':['DictionaryLoop','TryAccumulate','NativeTextIndex'],'cooperative checks':['CheckExecution','CheckCancellation'],'text/bulk':['PyStringOps','GovernedByteBuilder','StringJoin','AppendField'],'JSON':['Json','Utf8Json'],'iteration':['Generator','TryBufferYield','PyIteration','Cursor.Move']}
 def method_key(method):
  head=method.split('(',1)[0]
  if '::' not in head:return head
  owner,name=head.rsplit('::',1);return owner.split()[-1]+'::'+name
 groups.update({'receiver entry':['InvokeReceiverMethod','TryInvokeClosedReceiver'],'interpreter guard':['EnterInterpreterFrame','LeaveInterpreterFrame','GuardedInvocation'],'function complete entry':['StartNativeCall','TryStartBoundInvocation','BindIntoSlots','EnterFunctionCall','LeaveFunctionCall','InitializeFrame'],'storage admission':['MemoryReservation','MemoryScope','MemoryBudget','MemoryGovernor']})
 inclusive={name:sum(any(any(part in method_key(method)for part in parts)for method in stack)for stack in samples)for name,parts in groups.items()}
 guest=[stack for stack in samples if any(method_key(frame).startswith('Lokad.Lython.Runtime.') for frame in stack)]
 fixture=[stack for stack in samples if not any('Lokad.Lython.Runtime.' in frame for frame in stack)
          and any('ComparisonFileHost' in frame or 'ValidateFixtureDirectory' in frame for frame in stack)]
 guest_nearest=collections.Counter(next(n for n in stack if method_key(n).startswith('Lokad.Lython.Runtime.')) for stack in guest if stack)
 focus={
     'compile': ('LythonEngine::Compile','LythonFrontend::','ExecutableScript','AbstractInterpreter'),
     'definition setup': ('TryCompleteImmediatelyCalledDefinition','ApplyDefinition','CreateInlineDefinition','ReadFunctionDefaults','StartFunctionDefaults','SetFunctionDefault',
                          'PrepareFunctionDefaults','CreateFunctionValue','CreateLexicalFunctionValue','CreateBorrowedExecutableFunction'),
     'default storage': ('AllocateFunctionDefaults','StartExecutableDefaults','StoreDefaultResult','StoreInlinePositionalDefault','PreparePositionalValue','OwnPrivatePositionalDefault','ReadExecutableDefaults','TryReadTrailingSlot'),
     'default consumption': ('TryReadPreparedDefaultInteger','ReadPreparedDefault','HasPreparedOmittedArguments','TryGetPositionalDefault','DefaultIntegerOperands'),
     'annotations': ('AttachAdmittedAnnotations','ReadEagerFunctionAnnotations','CopyAnnotationValues'),
     'frame and operand binding': ('StartNativeWorkspace','StartNativeCall','StartInline','InitializeExecutableFrame','NativeExecution::Call','TryStartBoundInvocation',
                                   'BoundFunctionArguments','TryFillPreparedKeywordDefaults'),
     'direct integer return': ('TryStartDirectIntegerReturn','TryReadPreparedDefaultInteger','TryEvaluateDirectIntegerReturn'),
     'cooperative checks': ('CheckExecution','CheckCancellation','ThrowIfCancellationRequested'),
     'definition staging': ('TryDeferDefinition','MaterializeDeferredDefinitions','RefundDeferredDefinitions','CreateClosedPairMember','StartExecutableDefaults','AllocateFunctionDefaults','StoreDefaultResult','ReadExecutableDefaults','ChargeClosureRetention'),
     'JSON construction': ('PushJsonContainer','AcceptJsonValue','FinishJsonContainer','ContinueJsonConstruction','ReadJsonContainerAsync','AppendJsonContainerValue'),
     'JSON text and keys': ('ReadJsonString','ReadJsonObjectKey','MatchDelimitedName','FindName','ShareRecordKeys','SetRecordItem'),
     'JSON scalar tokens': ('TryReadJsonScalar','ReadDefaultJsonNumber','ReadJsonNumber','TryParseJsonInteger','TryMatchJson'),
     'dictionary updates': ('TryExecuteConvertedDictionaryUpdate','TryExecuteDictionaryAccumulation','TryAccumulate'),
     'JSON decoder entry': ('ParseJsonTextCoreAsync','JsonLoadOptions::PrepareAsync','JsonLoadOptions+<PrepareAsync'),
     'numeric conversion': ('StrictFloat','ParseFloat','TryMachineFloat','ShortDecimal','ConvertCsvScalar','Double.TryParse'),
     'CSV input and rows': ('PyCsv','CsvReader','ReadRecord','AdvanceCsv','MaterializeCsv'),
     'file or host I/O': ('PyFileObject','TextFileHandle','ComparisonFileHost','ReadFileRange','FileRead'),
     'native text words': ('Cased','NativeTextIndex','TryAccumulate','StringWordCursor','DictionaryLoop'),
     'retirement and cleanup': ('RetireTo','RetireTemporary','DisposeSources','CompleteExecution','ExecuteFinally'),
     'admission': ('MemoryGovernor::','MemoryReservation','MemoryScope','MemoryBudget'),
 }
 focused={name:sum(any(any(x in method_key(frame) for x in fragments) for frame in stack) for stack in guest)
          for name,fragments in focus.items()}
 nearest_helpers = collections.Counter()
 reserve_ancestors = collections.Counter()
 reserve_without_caller = 0
 for stack in guest:
  runtime = [key for key in map(method_key, stack) if key.startswith('Lokad.Lython.Runtime.')]
  nearest_helpers[runtime[0]] += 1
  if not runtime[0].endswith('MemoryGovernor::Reserve'):
   continue
  caller = next((method for method in runtime[1:] if 'MemoryGovernor' not in method), None)
  if caller is None:
   reserve_without_caller += 1
  else:
   reserve_ancestors[caller] += 1
 print('nearest explicit Reserve source',reserve_ancestors.most_common(20),'unknown caller',reserve_without_caller)
 rows.append(dict(label=label,role=role,case=record['workload'],activeCpuTids=record['activeCpuTids'],allThreadSamples=allThreads,threadCpuSeconds=record['threadCpuSeconds'],sampleCount=len(samples),guestRuntimeAncestry=len(guest),fixtureOutsideRuntime=len(fixture),guestRuntimeFocus=focused,nearestGuestRuntime=guest_nearest.most_common(),unmappedLeafSamples=sum(v for k,v in leaves.items()if'[unknown]'in k),ambiguousLeafSamples=sum(v for k,v in leaves.items()if k.startswith('[ambiguous]')),inclusiveOverlappingGroups=inclusive,nearestLythonFrames=nearest.most_common(),allLeaves=leaves.most_common(),malformedMapLines=malformed,invocations=record['response']['completedInvocations'],guestClockSeconds=record['response']['elapsedTicks']/record['response']['clockFrequency']))
 rows[-1].update(nearestRuntimeMethods=nearest_helpers.most_common(), nearestReserveCallers=reserve_ancestors.most_common(),
                 nearestReserveUnknownCaller=reserve_without_caller)
 # Assign the nearest managed runtime leaf once. Inclusive ancestry counts
 # remain available for callers and never get added to these groups.
 exclusive = {
     'entry and operand movement': ('StartNativeWorkspace','StartNativeCall','StartInline','TryStartBoundInvocation','TryExecuteNativeCall','BindFunctionArgumentsInto','EnterFunctionCall','LeaveFunctionCall','MoveToCurrentStorage'),
     'native instruction dispatch': ('ExecuteInstructionPrefix','NativeExecution::Dispatch','ReadNativeOperand','NativeExecution::Call','NativeExecution::RunCore'),
     'lexical binding operations': ('CaptureExecutable','ExecutableCaptures::','ExecutableCell::','TryLoadClosure', 'TryStoreClosure','TryExecuteClosureArithmetic'),
     'function and defaults construction': ('CompleteClosedDefinitionPair','CreateClosedPairMember','TryReturnDefinition','AllocateFunctionDefaults','ApplyDefinition','CreateInlineDefinition','CreateLexicalFunctionValue','CreateFunctionValue','FunctionDefaults','CreateClosedComputedDefinition','CreateClosedFunctionDefinition','CreatePreparedPositionalDefaults', 'PyFunctionBase::.ctor','PyExecutableFunction::.ctor'),
     'argument transport': ('BoundFunctionArguments','BindIntoSlots','RentFunctionArgumentStorage','ReturnBoundArguments','StoreSuppliedArguments','PrepareExecutableCallArguments'),
     'numeric arithmetic': ('TryIntegerChain','TryMachineBinary','EvaluateClosedIntegerSequence','EvaluateInteger','TryEvaluateDirectIntegerReturn'),
     'iterator pulls and callback routing': ('PyMapIterator::', 'PyZipIterator::', 'PyStarmapIterator::', 'PyIteration::', 'PyIteration+Cursor::',
                                             'InvokeShortRowAsync', 'ReadAvailableOperands', 'StartIterationCallback',
                                             'ResumeShortRowAsync', 'PyRepeatIterator::'),
     'CSV parsing and row construction': ('CsvRecord', 'CsvReaderObject::', 'CsvDictReaderObject::', 'TryAdoptRecord',
                                          'MaterializeCsv', 'ConvertCsvScalar'),
     'admission or retirement': ('MemoryGovernor::','MemoryReservation','MemoryBudget','DisposeSources','RetireTo','RetireTemporary','EndWorkspaceReuse','CloseResources','DisposeScope'),
     'host I/O': ('PyFileObject','TextFileHandle','FileRead','OpenedByteFile','HostOperation::'),
 }
 grouped=collections.Counter()
 for method,count in nearest_helpers.items():
  key=next((label for label, parts in exclusive.items() if any(part in method for part in parts)), 'other resolved runtime')
  grouped[key]+=count
 assert sum(grouped.values()) == len(guest)
 rows[-1]['exclusiveNearestRuntimeGroups']=dict(grouped)
 regions=collections.Counter()
 region_leaves=collections.defaultdict(collections.Counter)
 for stack in guest:
  runtime=[key for key in map(method_key,stack) if key.startswith('Lokad.Lython.Runtime.')]
  if any('TryReturnDefinition' in key or 'CreateClosedFunctionDefinition' in key or 'CreateClosedComputedDefinition' in key or 'TryCompleteImmediatelyCalledDefinition' in key or 'ClosedDefinitionPair' in key for key in runtime):
   region='definition construction'
  elif any('StartNativeWorkspace' in key for key in runtime):
   region='native workspace'
  elif any('TryStartDirectIntegerReturn' in key for key in runtime):
   region='closed integer consumer'
  elif label.startswith('unicode-') and any('Cased' in key or 'NativeTextIndex' in key or 'Whitespace' in key for key in runtime):
   region='word preparation or indexing'
  elif any('PyFileObject' in key or 'TextFileHandle' in key or 'ComparisonFileHost' in frame for key,frame in zip(map(method_key,stack),stack)):
   region='file or host I/O'
  elif any(any(part in key for part in exclusive['CSV parsing and row construction']) for key in runtime):
   region='CSV parsing and row construction'
  elif any(any(part in key for part in exclusive['iterator pulls and callback routing']) for key in runtime):
   region='iterator pulls or callbacks'
  else:
   region='other or unresolved boundary'
  regions[region]+=1
  region_leaves[region][runtime[0]]+=1
 assert sum(regions.values())==len(guest)
 rows[-1]['runtimeRegions']=dict(regions)
 rows[-1]['runtimeRegionLeaves']={region:methods.most_common() for region,methods in region_leaves.items()}
 nearest_lython=[next((key for key in map(method_key,stack) if key.startswith('Lokad.Lython.')), '') for stack in samples]
 rows[-1]['nearestFrontendSamples']=sum(key.startswith(('Lokad.Lython.Frontend.','Lokad.Lython.LythonEngine::Compile'))
                                       for key in nearest_lython)

 rows[-1]['insideGuestComparisonHost'] = sum(any('ComparisonFileHost' in frame for frame in stack) for stack in guest)
 rows[-1]['insideGuestMetadataOrFileStream'] = sum(any('System.IO.' in frame for frame in stack) for stack in guest)
 rows[-1]['unmappedGuestLeaf'] = sum('[unknown]' in stack[0] for stack in guest if stack)

(r/'attribution.json').write_text(json.dumps(dict(kind='RAM-backed whole-batch profile. Guest subset requires a resolved runtime ancestor. Remaining incomplete frames may be guest work. Inclusive groups overlap. Exclusive groups classify only the nearest resolved runtime method. Counts do not establish removable CPU.',rows=rows),indent=2)+'\n',encoding='utf-8',newline='\n')
for x in rows:
 print(x['label'],x['sampleCount'],'samples',x['unmappedLeafSamples'],'unknown',x['guestRuntimeAncestry'],'runtime',x['fixtureOutsideRuntime'],'host outside runtime')
 print(x['guestRuntimeFocus'])
 print('nearest runtime',x['nearestGuestRuntime'][:20])
