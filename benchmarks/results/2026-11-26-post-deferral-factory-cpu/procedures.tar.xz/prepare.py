from pathlib import Path
import ast, hashlib, json, os, subprocess, tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
quiet=lab/'comparison/quiet'
quiet.mkdir(parents=True)
baseline=lab.with_name('post-update-arithmetic-routes-20261126')
old=lab.with_name('post-update-json-attribution-20261126')
template=old/'comparison/quiet'
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(path, data):
    path.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
base=load(baseline/'frozen-identity.json')
donor=baseline/'comparison/quiet'
receipt=load(donor/'terminal-status.json')['receipt']
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['archiveSHA256']==digest(donor/'observations.tar.xz')
subprocess.run(['git','diff','--exit-code','df71fc295','--','src'],cwd=repo,check=True)
image=baseline/'frozen/candidate'
files=base['imageFiles']['candidate']
assert len(files)==32 and {p.name:digest(p) for p in image.iterdir()}==files
catalog=load(lab.with_name('deferred-callable-locals-refined-20261125')/'comparison/quiet/representative.json')
profiles=[['ordinary-definitions','diagnostic.generated-ordinary-definitions','candidate'],
          ['escaping-defaulted-rules','scripts.rule-default-closures','candidate']]
catalog['cases']=[next(c for c in catalog['cases'] if c['id']==key) for _,key,_ in profiles]
save(quiet/'catalog.json',catalog)
identity=dict(sourceRevision='df71fc295',inspectedHead=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),
              sourceDifference=[],imageFiles=dict(candidate=files),coreSHA256=dict(candidate=files['Lokad.Lython.dll']),
              profileCatalogSHA256=digest(quiet/'catalog.json'),cpythonWorkerSHA256=base['cpythonWorkerSHA256'],
              donorArchiveSHA256=receipt['archiveSHA256'],
              expectedCPythonSHA256=load(donor/'identity.json')['expectedCPythonSHA256'],profiles=profiles,
              purpose='Identify a whole staging or call step that remains after deferred callable construction.')
save(quiet/'identity.json',identity)
for name in ('collect.py','ops-profile.py','analyze.py','run.sh'):
    source=(template/name).read_text(encoding='utf-8').replace(
        'converted-dictionary-update-b1763-20261126','boolean-increments-b1766-20261126').replace('b1767-fixtures','b1769-fixtures')
    if name=='analyze.py':
        key="     'JSON construction':"
        assert source.count(key)==1
        source=source.replace(key,"     'definition staging': ('TryDeferDefinition','MaterializeDeferredDefinitions','RefundDeferredDefinitions','CreateClosedPairMember','StartExecutableDefaults','AllocateFunctionDefaults','StoreDefaultResult','ReadExecutableDefaults','ChargeClosureRetention'),\n"+key)
    if name.endswith('.py'):
        tree=ast.parse(source)
        compile(tree,name,'exec')
        if name=='collect.py':
            keys={n.slice.value for n in ast.walk(tree) if isinstance(n,ast.Subscript) and isinstance(n.value,ast.Name)
                  and n.value.id=='identity' and isinstance(n.slice,ast.Constant)}
            assert keys<=identity.keys()
    (quiet/name).write_text(source,encoding='utf-8',newline='\n')
assert b'\r' not in (quiet/'run.sh').read_bytes()
launcher=(old/'quiet.py').read_text(encoding='utf-8')
for before,after in (
    ('b1767-post-update-json-attribution','b1769-post-deferral-factory'),
    ('converted-dictionary-update-b1763-20261126','boolean-increments-b1766-20261126')):
    assert launcher.count(before)==1
    launcher=launcher.replace(before,after)
compile(launcher,'quiet.py','exec')
(lab/'quiet.py').write_text(launcher,encoding='utf-8',newline='\n')
sdk=Path.home()/'.dotnet11'
worker=repo/'benchmarks/cpython-worker.py'
assert digest(worker)==identity['cpythonWorkerSHA256']
proof=quiet/'verification.json'
subprocess.run([sdk/'dotnet.exe',image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',quiet/'catalog.json',
                '--dotnet',sdk/'dotnet.exe','--python','C:/Python313/python.exe','--python-worker',worker,'--out',proof],
               cwd=repo,env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk)),check=True,timeout=65)
result=load(proof)
assert result['state']=='Completed' and result['caseCount']==2
assert result['catalogSha256']==identity['profileCatalogSHA256']
assert result['launched']['library']['sha256'].lower()==identity['coreSHA256']['candidate'].lower()
payload=quiet/'stage.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=6) as package:
    for name in ('identity.json','catalog.json','collect.py','ops-profile.py','run.sh'):
        package.add(quiet/name,arcname=name,recursive=False)
save(quiet/'upload.json',dict(root='post-deferral-factory-b1769-20261126',payloadSHA256=digest(payload),
                             payloadBytes=payload.stat().st_size,expectedDonorArchiveSHA256=receipt['archiveSHA256']))
