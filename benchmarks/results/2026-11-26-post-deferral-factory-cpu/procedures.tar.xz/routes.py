from pathlib import Path
from difflib import unified_diff
import hashlib,json,os,shutil,subprocess,zipfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
prior=lab.with_name('post-update-arithmetic-routes-20261126')
diag=lab/'routes'
diag.mkdir()
source=diag/'source'
archive=diag/'source.zip'
subprocess.run(['git','archive','--format=zip','--output',archive,'df71fc295','--','src',
                'Directory.Build.props','Directory.Build.targets','Directory.Build.rsp',
                'Directory.Packages.props','global.json','NuGet.Config'],cwd=repo,check=True)
with zipfile.ZipFile(archive) as packed:
    assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in packed.namelist())
    packed.extractall(source)
names=['BigIntegerReads','ExecutableConstantReads','ExecutableMachineConstants',
       'ClosedDefaultConstantReads','ClosedDefaultMachineConstants','ComputedScalarCalls']
def read(path):return json.loads(path.read_text(encoding='utf-8'))
def write(path,text):path.write_text(text,encoding='utf-8',newline='\n')
changes=[]
def patch(name, edits):
    rel='src/Lokad.Lython/Runtime/'+name
    file=source/rel
    before=file.read_text(encoding='utf-8')
    after=before
    for old,new in edits:
        assert after.count(old)==1,(name,old)
        after=after.replace(old,new)
    write(file,after)
    changes.extend(unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),'a/'+rel,'b/'+rel))
marker='    // Shared by exact guest operations'
patch('LythonRuntime.IntegerBinary.cs',[(marker,''.join(f'    internal static int Diagnostic{n};\n' for n in names)+'\n'+marker),
    ('        if (value.GetByteCount() <= sizeof(long))','        Interlocked.Increment(ref DiagnosticBigIntegerReads);\n        if (value.GetByteCount() <= sizeof(long))')])
patch('LythonRuntime.Executable.Operands.cs',[
    ('        if (name < 0) return TryMachineInteger(code.Constants[index], out value);','''        if (name < 0)
        {
            Interlocked.Increment(ref DiagnosticExecutableConstantReads);
            if (!TryMachineInteger(code.Constants[index], out value)) return false;
            Interlocked.Increment(ref DiagnosticExecutableMachineConstants);
            return true;
        }''')])
patch('LythonRuntime.Executable.PreparedDefinitions.cs',[
    ('            return source < 0 ? TryMachineInteger(factory.Constants[~source], out value) : prior.TryGetInteger(out value);','''            if (source >= 0) return prior.TryGetInteger(out value);
            Interlocked.Increment(ref DiagnosticClosedDefaultConstantReads);
            if (!TryMachineInteger(factory.Constants[~source], out value)) return false;
            Interlocked.Increment(ref DiagnosticClosedDefaultMachineConstants);
            return true;''')])
patch('LythonRuntime.Executable.Integers.cs',[
    ('receiver: null, call.CallSpan, out result)) return true;','receiver: null, call.CallSpan, out result))\n                    {\n                        Interlocked.Increment(ref DiagnosticComputedScalarCalls);\n                        return true;\n                    }')])
write(diag/'diagnostic.patch',''.join(changes))
catalog=read(lab/'comparison/quiet/catalog.json')
controls=read(prior/'comparison/quiet/representative.json')
catalog['cases']+= [c for c in controls['cases'] if 'text-summary' in c['id']]
assert len(catalog['cases'])==3
catalog['cases']=[case|dict(runAsync=mode) for case in catalog['cases'] for mode in (False,True)]
write(diag/'cases.json',json.dumps(catalog,ensure_ascii=False))
program=(prior/'Program.cs').read_text(encoding='utf-8')
replacement='string[] names = '+json.dumps(names)+';'
start=program.index('string[] names = ')
stop=program.index(';',start)+1
write(diag/'Program.cs',program[:start]+replacement+program[stop:])
shutil.copyfile(prior/'RouteProbe.csproj',diag/'RouteProbe.csproj')
frozen=prior/'frozen/candidate'
manifest=read(lab/'comparison/quiet/identity.json')['imageFiles']['candidate']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert {p.name:sha(p) for p in frozen.iterdir()}==manifest
image=diag/'image'
shutil.copytree(frozen,image)
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
def run(args,name):
    with (diag/name).open('wb') as log:
        subprocess.run([dotnet,*args],stdout=log,stderr=subprocess.STDOUT,env=env,cwd=repo,check=True,timeout=150)
run(['build',source/'src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-incremental',
     '-o',diag/'core'],'build-core.log')
shutil.copyfile(diag/'core/Lokad.Lython.dll',image/'Lokad.Lython.dll')
run(['build',diag/'RouteProbe.csproj','-c','Release','-o',diag/'probe'],'build-probe.log')
for file in (diag/'probe').glob('RouteProbe*'): shutil.copyfile(file,image/file.name)
run([image/'RouteProbe.dll',image,diag/'cases.json',diag/'counts.json'],'run.log')
write(diag/'identity.json',json.dumps(dict(sourceRevision='df71fc295',frozenFiles=manifest,
      instrumentedCoreSHA256=sha(image/'Lokad.Lython.dll'),patchSHA256=sha(diag/'diagnostic.patch'),
      caseSHA256=sha(diag/'cases.json')),indent=2)+'\n')
for row in read(diag/'counts.json')['rows']:
    print(row['id'],row['asynchronous'],row['routes'])
