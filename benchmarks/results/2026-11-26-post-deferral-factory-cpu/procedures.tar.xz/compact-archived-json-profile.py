from pathlib import Path, PurePosixPath
import hashlib, json, subprocess, tarfile

lab=Path(__file__).resolve().parent
evidence=lab.parents[3]/'benchmarks/results/2026-11-26-current-json-attribution'
old=evidence/'observations.tar.xz'
raw=hashlib.sha256(old.read_bytes()).hexdigest()
status=json.loads((evidence/'terminal-status.json').read_text(encoding='utf-8'))
assert status['exitCode']=='0' and status['receipt']['archiveSHA256']==raw
with tarfile.open(old) as archive:
    files={m.name:{'bytes':m.size,'sha256':hashlib.file_digest(archive.extractfile(m),'sha256').hexdigest()}
           for m in archive.getmembers() if m.isfile() and m.size>=65536
           and PurePosixPath(m.name).parts[:2] in (('profiles','json-lines-helpers'),('profiles','json-service-totals'))}
assert len(files)>=2 and sum(v['bytes'] for v in files.values())>=700000
payload=json.loads((lab/'comparison/quiet/upload.json').read_text(encoding='utf-8'))
cfg=dict(raw=raw,files=files,minimum=payload['payloadBytes']+8*1024*1024)
code=r'''
from pathlib import Path
import fcntl,hashlib,json,shutil,stat,subprocess,tarfile
base=Path('/home/lokad/lython-bench-checks')
root=base/'post-update-json-attribution-b1767-20261126'
assert root.resolve()==root and root.parent==base and base.resolve()==base
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 before=shutil.disk_usage(base).free
 if before>cfg['minimum']:
  print(json.dumps(dict(freeBeforeBytes=before,freeAfterBytes=before,compacted=[])));quit()
 result=subprocess.run(['systemctl','show','lython-b1767-post-update-json-attribution-20261126.service',
                        '--property=ActiveState,MainPID'],capture_output=True,text=True).stdout.splitlines()
 assert 'ActiveState=inactive' in result and 'MainPID=0' in result
 receipt=json.loads((root/'archive-receipt.json').read_text())
 archive=root/'observations.tar.xz'
 assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['guestFixturesRemoved']
 assert archive.resolve()==archive and sha(archive)==receipt['archiveSHA256']==cfg['raw']
 paths=[]
 with tarfile.open(archive) as packed:
  for name,expected in cfg['files'].items():
   p=root/name
   st=p.lstat()
   assert p.resolve()==p and p.is_relative_to(root/'profiles') and stat.S_ISREG(st.st_mode) and st.st_nlink==1
   assert st.st_size==expected['bytes'] and sha(p)==expected['sha256']
   assert hashlib.file_digest(packed.extractfile(name),'sha256').hexdigest()==expected['sha256']
   paths.append(p)
 assert before+sum(p.stat().st_size for p in paths)>cfg['minimum']
 for p in paths: p.unlink()
 print(json.dumps(dict(freeBeforeBytes=before,freeAfterBytes=shutil.disk_usage(base).free,
                       preservedArchiveSHA256=cfg['raw'],compacted=[str(p.relative_to(base)) for p in paths])))
'''
identity=Path.home()/'.ssh/id_lython-bench.pem'
command=['ssh','-i',str(identity),'-o','BatchMode=yes','-o','ConnectTimeout=12','lokad@20.166.121.73','python3 -']
result=subprocess.run(command,input='cfg='+repr(cfg)+'\n'+code,encoding='utf-8',capture_output=True,timeout=45)
(lab/'storage-custody.log').write_text(result.stdout+result.stderr,encoding='utf-8')
print(result.stdout+result.stderr)
result.check_returncode()
