from pathlib import Path
import gzip
import hashlib
import io
import json
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
sha = lambda value: hashlib.sha256(value).hexdigest()
def from_origin(path):
    content = subprocess.check_output(["git","show",f"origin/master:{path}"])
    assert content == Path(path).read_bytes()
    return content

canonical = "benchmarks/results/2026-11-18-direct-keyword-overflow/candidate-core.dll.gz"
packed = from_origin(canonical)
binary = gzip.decompress(packed)
assert sha(binary) == "97851ccfa9ec6ee6613c40c06be14c82e03abd31d2fe499675a21993eebbc745"
core = dict(canonical=canonical, canonicalSHA256=sha(packed), sha256=sha(binary), bytes=len(binary),
            anchor="keyword-hash-b991-20261118/candidate/Lokad.Lython.dll",
            kind="exact archived measured core replica", committedBlobVerified=True)
source = "benchmarks/results/2026-11-18-retained-cpython-checkpoint/observations.tgz"
exact = from_origin(source)
member = "confirmation/confirmation.json"
with tarfile.open(fileobj=io.BytesIO(exact),mode="r:gz") as tar:
    raw = tar.extractfile(member).read()
assert json.loads(raw)["complete"]
proofs = [dict(paths=[f"retained-cpython-b993-20261118/{member}"], canonical=source, canonicalSHA256=sha(exact),
              member=member, sha256=sha(raw), bytes=len(raw), links=1, kind="exact archived raw observation replica",
              committedBlobVerified=True)]
prior = json.loads((lab.parent/"borrowed-expanded-call-r566/quiet-space.json").read_text(encoding="utf-8"))
for proof in prior["replicas"]:
    canonical = proof["canonical"]
    if not canonical.startswith(("benchmarks/results/2026-11-16-","benchmarks/results/2026-11-17-")):
        continue
    assert len(proof["paths"]) == proof["links"] == 1 and canonical.endswith("/observations.tgz")
    exact = from_origin(canonical)
    assert sha(exact)==proof["canonicalSHA256"]==proof["sha256"] and len(exact)==proof["bytes"]
    proofs.append(proof)
remote = r'''
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
root=Path('/home/lokad/lython-bench-checks').resolve()
assert root==Path('/home/lokad/lython-bench-checks')
core=CORE
with (root/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert not subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.13.*cpython-worker.py'],capture_output=True).stdout
    assert not any(os.path.ismount(p) for p in root.glob('*/guest-fixtures'))
    def verify(p,proof):
        v=p.lstat()
        assert p.resolve()==p and p.is_relative_to(root) and stat.S_ISREG(v.st_mode)
        assert v.st_uid==os.getuid() and v.st_size==proof['bytes']
        assert hashlib.sha256(p.read_bytes()).hexdigest()==proof['sha256']
        return v
    anchor=root/core.pop('anchor')
    v=verify(anchor,core)
    core['links']=v.st_nlink
    core['paths']=[]
    for directory,_,names in os.walk(root):
        for name in names:
            p=Path(directory)/name
            other=p.lstat()
            if (other.st_dev,other.st_ino)!=(v.st_dev,v.st_ino):continue
            rel=p.relative_to(root).as_posix()
            assert rel in {'keyword-hash-b991-20261118/candidate/Lokad.Lython.dll',
                           'expanded-call-b992-20261118/reference/Lokad.Lython.dll'}
            verify(p,core)
            core['paths'].append(rel)
    assert len(core['paths'])==core['links']
    verified=[core]
    for proof in PROOFS:
        p=root/proof['paths'][0]
        if not p.exists():continue
        assert verify(p,proof).st_nlink==proof['links']
        verified.append(proof)
    print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free,replicas=verified)))
'''.replace("CORE",repr(core)).replace("PROOFS",repr(proofs))
ssh = ["C:/Windows/System32/OpenSSH/ssh.exe","-i",str(Path.home()/".ssh/id_lython-bench.pem"),
       "-o","BatchMode=yes","-o","ConnectTimeout=15","lokad@20.166.121.73"]
result = subprocess.run(ssh+["python3 -"],input=remote.encode("utf-8"),capture_output=True,timeout=45,check=True)
space = json.loads(result.stdout)
(lab/"quiet-space.json").write_text(json.dumps(space,indent=2)+"\n",encoding="utf-8")
print(space["freeBytes"],"bytes free with",len(space["replicas"]),"verified archive recovery choices")
