from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
quiet = lab/"quiet"
out = Path("benchmarks/results/2026-11-18-fixed-list-unpack")
load = lambda p: json.loads(p.read_text(encoding="utf-8-sig"))
sha = lambda contents: hashlib.sha256(contents).hexdigest()
receipt = load(quiet/"archive-receipt.json")
terminal = load(quiet/"terminal-status.json")
assert receipt["jobs"] == 2 and receipt == terminal["receipt"] and terminal["exitCode"] == "0"
assert sha((quiet/"observations.tgz").read_bytes()) == receipt["archiveSHA256"]
assert all(receipt[k] for k in ("complete","allWorkersJoined","guestFixturesRemoved",
                                "quietBeforeAndAfter","archivedAndVerifiedUnderLease"))
for kind in ("public", "wsl"):
    for target in ("net10.0","net11.0"):
        assert re.search(r"Failed:\s+0, Passed:\s+161, Skipped:\s+0",
                         (lab/f"{kind}-{target}.log").read_text(encoding="utf-8-sig"))
identity = load(lab/"frozen-identity.json")
assert identity["casesSHA256"] == sha((lab/"catalog.json").read_bytes())
for role, files in identity["images"].items():
    assert {name:sha((lab/"frozen"/role/name).read_bytes()) for name in files} == files
    assert load(lab/f"{role}-verify.json")["state"] == "Completed"
screen = []
for index, path in enumerate(sorted(lab.glob("micro-*.json"))):
    result=load(path)
    assert result["state"]=="Completed" and result["catalogSha256"]==identity["casesSHA256"]
    medians={s["engine"]:s for s in result["summaries"]}
    a,b=("baseline","candidate") if index<2 else ("candidate","baseline")
    screen.append(dict(file=path.name,reference=medians[a],candidate=medians[b],CPython=medians["CPython"],
                       elapsedDeltaPercent=100*(medians[b]["medianMicroseconds"]/medians[a]["medianMicroseconds"]-1)))
assert len(screen) == 4
patch = subprocess.check_output(["git","-C",".git/agent-worktrees/list-unpack-r568",
                                 "diff","--binary","d63004a6f","--","src","tests"])
(lab/"source.patch").write_bytes(patch)
out.mkdir(exist_ok=False)
for name in ("observations.tgz","archive-receipt.json","terminal-status.json"):
    shutil.copyfile(quiet/name,out/name)
shutil.copyfile(lab/"quiet-summary.json",out/"summary.json")
shutil.copyfile(lab/"allocation-summary.json",out/"allocation-summary.json")
(out/"windows-screen.json").write_text(json.dumps(dict(rows=screen,sourcePatchSHA256=sha(patch)),indent=2)+"\n",encoding="utf-8")
with tarfile.open(out/"checks-and-procedures.tar.xz","w:xz",preset=6) as tar:
    for name in ("collect.py","archive-owned.py","config.json","identity.json","run.sh",
                 "remote-launch.py","observe-not-before.json","retrieve.py","representative.json"):
        tar.add(quiet/name,arcname=name)
    for path in sorted(lab.iterdir()):
        if path.is_file() and path.suffix in {".json",".log",".py",".patch"}:
            tar.add(path,arcname=f"local/{path.name}")
print("Verified B994, focused tests, catalogs, raw observations and source patch.")
