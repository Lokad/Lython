from pathlib import Path

lab = Path(__file__).resolve().parent
donor = lab.parent / "borrowed-expanded-call-r566"
text = (donor / "measure.py").read_text(encoding="utf-8")
text = text.replace("borrowed-expanded-call-r566", "list-unpack-r568")
text = text.replace("direct-keyword-overflow-r565/final-frozen/candidate", "borrowed-expanded-call-r566/frozen/candidate")
text = text.replace("045eb7f44", "d63004a6f")
text = text.replace('(target_id, "warm"), (control_id, "warm"), (target_id, "compile-run"), (target_id, "compile"),\n        (target_id, "compile"), (target_id, "compile-run"), (control_id, "warm"), (target_id, "warm"),',
                    '(target_id, "warm"), (control_id, "warm"), (control_id, "warm"), (target_id, "warm"),')
text = text.replace("if index < 4", "if index < 2")
compile(text, str(lab / "measure.py"), "exec")
(lab / "measure.py").write_text(text, encoding="utf-8", newline="\n")
