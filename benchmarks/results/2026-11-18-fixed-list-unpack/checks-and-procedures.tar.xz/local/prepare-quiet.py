from pathlib import Path

lab = Path(__file__).resolve().parent
template = lab.parent/"borrowed-expanded-call-r566/stage-quiet.py"
source = template.read_text(encoding="utf-8")
replacements = [
    ("direct-keyword-overflow-r565", "borrowed-expanded-call-r566"),
    ('donor / "quiet-corrected"', 'donor / "quiet"'),
    ("045eb7f44 versus R566 borrowed expanded-call arguments", "d63004a6f versus fixed exact-list unpack"),
    ("R566 expanded application paired elapsed and process CPU comparison", "R568 fixed exact-list unpack comparison"),
    ("expanded-call-b992", "fixed-list-unpack-b994"),
    ("lython-b992-expanded-call", "lython-b994-fixed-list-unpack"),
    ("lython-b992-fixtures", "lython-b994-fixtures"),
    ("lython-b991-fixtures", "lython-b992-fixtures"),
    ("Keyword forwarding source pair", "Expanded call source pair"),
    ('.replace("Expanded call source pair", "Expanded call source pair")',
     '.replace("Expanded call source pair", "Fixed-list unpack source pair")'),
    ('donor / "launch-quiet-corrected.py"', 'donor / "launch-quiet.py"'),
    ('donor / "summarize-quiet-corrected.py"', 'donor / "summarize-quiet.py"'),
    ("full B992 worker images", "full B994 worker images"),
]
for before, after in replacements:
    source = source.replace(before, after)
compile(source, str(lab/"stage-quiet.py"), "exec")
(lab/"stage-quiet.py").write_text(source,encoding="utf-8",newline="\n")
