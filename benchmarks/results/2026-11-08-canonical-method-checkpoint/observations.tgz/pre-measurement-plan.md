# Lokad.Lython 0.11.0

Updated 2026-11-08. Git-ignored; never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Another isolated experiment does not finish that objective. Active work below;
historical narratives, rejected designs, original failed conditions and raw data
stay in benchmarks/EXPERIMENTS.md and results. Docs describe current implementation.

## Actual delivery status

| Milestone | Actual status |
| --- | --- |
| Compiler-fact correction, direct UTF-8 formatting/storage, native helper returns | Committed/fully qualified. Native returns allocation−19.92/−19.31%, original elapsed diagnostic. Formatting allocation−8.67%, controlled B102 elapsed/CPU−5–8%; original15.125ms adverse remains unexplained/preserved. No unchanged qualification replay. |
| Retained R62–R76 | Fully qualified; history preserves70267889,824fc6bb,7a81a629,f88191f7+a34f56b5,68d5bffe,33b6c191,79657355+c384956f,38f53c33/06651b11. Compiler facts/native calls/sequence/tuple storage, JSON floats, inline/final UTF-8 storage remain. R71 slower arenas/control/wide carriers, R72 coarseCPU+6.67%, R74 drift and all failed/adverse conditions remain evidence, not current performance claims. |
| R78/R79 | Fully qualified af481194+5b9d569a and913ea550: shared receiver declarations, callback/signature correctness fixes, native workstate before lexical contexts. Existing measured function optimizations preserved. Cached full-delivery receipts; details in EXPERIMENTS/results. |
| R80/R81 attribution; R82 prepared consumers | Attribution/source gates completed71445454; no unsupported namespace/value/accounting redesign selected. R82 production91f15a3e fully qualified CI42451722109; source consistency retained, allocation neutral, modest/mixed elapsed. |
| R77/R83 CPython checkpoints | Guides accurately identify measured38f53c33 and latest91f15a3e, not today's HEAD. Latest B446:26jobs539.117s; compile/warm/compile-to-result and I/O/validation/prior cleanup separated. Ordinary helper warm2.12–2.23×CPython remains a substantial gap. Original failures/uncertainty preserved. |
| R84/R85 | Canonical receivers02c76e52/coreaa4acebe, corrected7796a24f/corecc6b1b15 fully qualified CI42459221409. Failed original CI42457767068/logs retained. Corrected allocation45–52%lower; controlled elapsed22–24%lower belongs to earlier aa4, not cc6. Controls/debt remain explicit in results. |
| R86/R87/R88 | Complete CSV/helper/generated-code source gates committed7796a24f+16e14ee0; B449 terminal/archived/verified. No binder dominance or causal CPU claim. Existing record adoption/keys/batched fields remain. Text source-shape diagnostic selected the next coherent preparation cleanup, not a new arena/engine. |
| R89 | Committed/pushedac5aea97, measured6a098198 core: shared native-method/return facts/direct existing fusion.397internal/2165public per actual11/10 pass. B451 affected elapsed−11–19%, coarseCPU agrees, allocation neutral. Fused/report inconclusive, possible CSV+0.42–1.03% debt accepted. All evidence archived/verified; full CI dispatched08:29UTC, independent/pending. |
| Regex R68 | Exact immutable0.5.0-dev.55/d6067925:86internal/514public per actual11/10, unchanged bridge. Development compatibility only. Normal optional0.4 pin/core unchanged; affected final released adapter qualification pending, independent implementation continues. |

Completed milestones and original evidence remain in benchmarks/EXPERIMENTS.md
and linked results; the table is delivery status, not a replay queue.
Latest fully qualified runtime7796a24f, CI42459221409 green/cached08:01UTC:
Windows/Ubuntu actual11/10, originalStress and installed core consumers. Earlier
failed42457767068 is cached; never requery either. R89 remains a separate prototype.
Never requery/re-dispatch terminal runs or imply that this qualifies later changes.
Allocation reduction, elapsed, coarseCPU and embedding latency are distinct.
R76's float debt and R79's CSV debt are separately accepted; unrelated gains do
not repay them. Preserve native-text/report/control uncertainty and adverse originals.

## Active deliverables

1. **R89: consolidate closed-call preparation, then decide/qualify.** Replace the
   duplicate string-method inventory with canonical ReceiverMethod declarations
   and existing frontend return facts. Removed in the prototype: method-specific
   native-return enum entries, GetNoArgumentsKind/map, enum-indexed declaration
   array/accessors and their guard/evaluation branches. Six missing Boolean facts
   join the existing catalog. The prepared immutable method belongs to its native
   value node, with four generic result shapes; no per-name proof flags, second
   catalog, new engine, owner or pool. Existing lower/upper split fusion and
   argument-bearing proof remain. Exact native receiver/type proof precedes work;
   other shapes use ordinary execution before effects, never retry after work.

   Acceptance: Python metadata/arity/Unicode/evaluation order/spans, dynamic and
   genuinely asynchronous callbacks, cancellation, first terminal refusal, funded
   aliases and awaited cleanup. Three composition/dynamic/sibling/forwarded cases
   have isolated CPython goldens. Final397internal/2165public per actual11/10 pass.
   Initial call-site-metadata prototype/adverse rsplit/report data remain; the
   refinement removes every-callsite fields and proof lookups. Short allocation is
   neutral; desktop clocks/controls remain unstable (old-role161.14% retained).

   B450 terminal/archived/locally verified:167.945s, affected elapsed−13–18% and
   agreeing coarseCPU. Existing fused control+2.52–8.29% (candidate spread3.70%,
   CPUflat-to-adverse) requires correction; CSV/report controls are unstable, all
   adverse data retained. No active VM workers/fixtures; never requery B450.
   Source correction removes the fused kernel's dead lower/upper node, redundant
   proof and empty argument scan, preserving original span-check order. B451
   terminal/archived/locally verified:168.406s, rsplit sync−13.94–17.85%, async
   −16.06–19.25%, casefoldsync−11.14–14.17%, coarseCPU agrees. Allocation neutral.
   Fused−3.77to+2.31%inconclusive; original concern not reproduced, no complete
   causal proof. CSV+0.42–1.03%elapsed/coarseCPUflat accepted as small possible
   debt, separate from prior debt. Reportinconclusive. All source/core/aux/Ready/
   runtime/golden/quiet/Closed/join/fixture/archive gates pass. No active users or
   fixtures; never requery B450/B451. Full source/initial/refined/adverse evidence
   preserved in results/2026-11-08-native-method-facts. Commit, full qualify once,
   then continue the roadmap; performance objective and publication remain open.
   Retain/correct/reject on architectural removal, complete-script elapsed,
   coarseCPU, allocation and explicit control debt separately; no fixed-percent
   veto. If retained, update current docs, commit and batch full Windows/Ubuntu
   actual11/10/originalStress/installed-core qualification. Work while CI runs;
   do not imply that baseline7796a24f's green receipt qualifies the candidate.

2. **Continue substantial whole-script work.** R86–R88 found distributed execution/
   operand, parsing, adoption and numeric costs, not a dominant binder phase.
   Prefix method/tier/code-size identity was verified; most mapped samples are
   fetch/dispatch, with fewer refusal/token checks. Input-handler emitted listing
   is absent, so its samples cannot be assigned to source blocks. Initial text
   helper/inline contrast has neutral allocation and diagnostic elapsed−11–16%;
   CSV has different protected continue flow, allocation+1.5% and unstable clocks.
   Do not treat these as binder-only attribution. Keep all raw/unknown/adverse
   evidence in EXPERIMENTS/results; no further VM run merely to amplify weak
   samples. Proceed through the following design boundaries with an explicit
   removable phase, semantics and bounded source pair. A measurement/CI receipt
   or isolated experiment does not complete the performance objective.

   R90 next: refresh the maintained26-job CPython comparison at committedac5aea97/
   core6a098198 while full CI runs. Same eight representative scripts with compile,
   warm and compile-to-result separated, plus existing rsplit/guarded helper warm
   cases; unchanged catalog, goldens, worker and execution boundaries. Do not add
   a framework/case campaign.570s owner+30stop+30observation margin; all source/
   Ready/golden/quiet/Closed/join/fixture/archive gates. Reuse the exact immutable
   B451 core/archive instead of duplicating core bytes in the new trace archive;
   measured R83 raw/archive footprint+25%=6.08MB fits existing7MiB headroom above
   240MiB OS floor, with payload size checked before launch. No evidence deletion.
   This is an infrequent combined checkpoint, not a retiming of individual changes.
   Keep source/measurement/qualification statuses separate, prior inconclusive
   cases visible and CPython primary. Then select the next substantial phase from
   the current evidence; do not close the performance objective at another receipt.

3. **Independent regex track.** Missing producer publication defers only affected
   final adapter qualification. Core architecture/correctness and non-regex work
   continue independently. Publication/tagging remain postponed.

## Following substantial redesign boundaries

| Boundary | Selection and acceptance |
| --- | --- |
| Remaining calls/operand/scalar dispatch | Indexed operands/native returns/final slots and native workstate dispatch exist. Find a demonstrated complete remaining binding/transport or numeric phase; avoid pools/arenas and duplicated control routes already measured slower. Exact integer promotion, identity/type/projection, callbacks, reentry and alias funding must hold. Machine-integer handling is a hypothesis until current attribution supports its scope; no universal tagged-value replacement. |
| Per-record construction | Current source gate: shared RecordKeys and exclusive funded row-array adoption already remove the old bulk proposal's copying/key phase; it cannot be revived unchanged. Preserve its6–8% improvement/adverse control. Remaining identity checks protect mutable headers and admission reentry; no mutation-version inventory without current measured dominance. Select a genuinely remaining construction phase; preserve hooks/order/escaping aliases. |
| Remaining bulk text/JSON | Direct casing/lower-split/formatting/native parsing, JSON loop/shared scanner and final UTF-8 storage retained. Select a whole remaining conversion/storage phase, preserving Unicode/context/hooks/async I/O. Ordinary R61 JSON has no escaped tokens; do not optimize hypothetical dominance or add a name-marker series. |
| Frontend facts | R55/R58/R62/R65 already remove lexical/graph/validity/module work. Select demonstrated repeated analysis in compile-to-result workloads; preserve class/function/annotation scope and exact diagnostics, then delete displaced analysis. No speculative visitor/cache/parser/JIT project. |

Bounded confirmation/refinement or measurement correction is allowed when evidence
justifies it. Timeout, unstable unchanged control or inconclusive results establish
uncertainty, not a permanently failed design. Keep original failed conditions and
adverse results. Fixed percentages inform judgment, never automatically veto useful
simplification. Temporary regressions require an explicit completion milestone and
retain/correct/reject decision on remaining debt. Batch CPython refreshes at coherent
combined checkpoints with exact source/date/machine and separate compile, warm,
compile-to-result/startup; include I/O/validation/cleanup boundaries and uncertainty.
Current guide accurately names source91f15a3e; do not remeasure after every tweak.

## Independent regex deliverable

Core owns Python/native UTF-8 semantics: byte ranges/scalar positions/original
subject windows, flags/captures/replacements/errors, cache ownership/current tokens
and one provider through frontend/runtime/imports. Core has no Utf8Regex dependency;
adapter remains nonpackable. Contract tests, semantic compatibility and actual
backend performance are separate. Immutable development producers/adapter-local
bridges support development; missing publication does not stop independent work.

Exact dev55 gaps: DetailedData lacks separate preparation/working ownership;
native name lookup lacks enumeration; cursor creation retains its token despite
per-move tokens. Both dev55 package SHAs rechecked bit-identical08:04UTC; no
new supplied version or repeat qualification. Existing bridges remain justified. Qualify the final released
package's semantics, managed safety and actual performance when available. Normal
adapter0.4 pin unchanged pending justified promotion. No sibling edits/builds,
producer-CI replay, dialect fallback, quotas, memory subsystem or abandoned matching.

## Lasting constraints / checks

AGENTS.md governs fully managed safety/managed stack admission: no unsafe/Unsafe,
PInvoke/pointers/native probes. Preserve host capabilities, current cancellation,
checked representation bounds, XML depth, bounded I/O chunks and admitted projection.
Borrow shared allowance for coarse capacity/preflight/replacement storage; fund
retained aliases/caches/results and pending users until awaited cleanup. No caps,
hidden allowances/fuel/quotas/tracing/weak reclamation/forced GC. Initial streaming
uses host batches. First refusal is terminal through suppression/finally; never
retry or skip optional storage. Keep native refunds/cleanup available and awaited.

Focused Release iteration; matching probes when needed and explicit Stress exclusion
with custom filters. No overlapping local builds/tests/measurements; force a fresh
build after timestamp-preserving restores. Batch actual11/10 Windows/Ubuntu,
original Stress and installed consumers at retained boundaries. Explicit UTF-8.
Only core explicit Release pack to artifacts/nuget; no adapter packages/publication.
VM lokad@20.166.121.73,key ~/.ssh/id_lython-bench.pem. B443 terminal/archived/
locally verified; no active user/fixture mount, never requery. Persistent evidence
separate from owned RAM; join/unmount/archive under lease and verify locally.
One byte-identical worker DLL was atomically hardlinked, freeing56MB while keeping
all paths/bytes/cores/sources/archives. No future deletion inferred. CI observations
>=5minutes apart; cached terminal runs never requeried or duplicate-dispatched.
