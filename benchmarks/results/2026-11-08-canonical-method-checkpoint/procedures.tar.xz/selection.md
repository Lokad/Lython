R90: combined current sourceac5aea97/core6a098198 CPython checkpoint after R85/R89.
Same maintained26 jobs: eight complete representative scripts, separate compile,
warm execution and compile-to-result, plus ordinary rsplit/guarded warm helpers.
Unchanged source/fixtures/goldens/toolchain/boundaries and existing worker/collector.
Lython2 independent processes and isolated CPython3.13.16,5s warmup/role/job,
seven rotated150ms rounds, normalGC/tiering, quiet F4as_v7. Keep compile/startup,
I/O/full validation/prior cleanup/final cache teardown boundaries explicit.
All source/core/aux/actualReady/runtime/golden/quiet/Closed/exit/join/fixture/archive
gates required.570sowner+30stop+30margin. Full final-source qualification is an
independent running CI; measurement does not imply containment/release readiness.
Preserve adverse/uncertain/historical cases, CPython primary; no single-change CPU
attribution, prediction, whole-performance-objective closure or publication.
Persistent evidence separate from owned128MiB RAM fixtures. Exact B451 core and
archive reused/verified, no duplicate core in this archive. Prior measured R83
raw/archive footprint+25% fits7MiB above240MiB OSfloor; check exact payload before
launch. No evidence/data/core/path deletion or further deduplication.
