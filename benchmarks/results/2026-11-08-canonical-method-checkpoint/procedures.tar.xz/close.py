from pathlib import Path
import hashlib,json,re,runpy,shutil,tarfile
r=Path(__file__).resolve().parent
receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['jobs']==26
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
summary=json.loads((r/'summary.json').read_text(encoding='utf-8'));identity=json.loads((r/'identity.json').read_text(encoding='utf-8'))
assert summary['complete']and len(summary['timing'])==26 and identity['sourceRevision'].startswith('ac5aea97')
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['productionSources'].items())
assert identity['coreSHA256']['candidate'].startswith('6a098198')
scope=runpy.run_path(str(r/'table-helpers.py'));table,ordinary,affected=[scope[n]for n in ['table','ordinary','affected']]
out=Path('benchmarks/results/2026-11-08-canonical-method-checkpoint');out.mkdir()
for n in ['summary.json','observations.tgz','archive-receipt.json','core-source.json']:shutil.copyfile(r/n,out/n)
history=(r/'prior-BENCHMARKS.md').read_text(encoding='utf-8').replace('../benchmarks/results/','../').replace('../benchmarks/EXPERIMENTS.md','../../EXPERIMENTS.md').replace('../benchmarks/README.md','../../README.md').replace('../tests/README.md','../../../tests/README.md')
(out/'prior-BENCHMARKS.md').write_text('# Historical guide: primary source91f15a3e\n\nThe primary tables below describe91f15a3e, with separate later source comparisons. They are not current ac5aea97 primary measurements.\n\n'+history,encoding='utf-8')
guide=Path('docs/BENCHMARKS.md').read_text(encoding='utf-8');blocks=list(re.finditer(r'\| Workload \|.*?(?=\n\n)',guide,re.S));assert len(blocks)==3
for block,new in reversed(list(zip(blocks,[table('compile-run',ordinary,True).rstrip(),table('warm',ordinary+affected).rstrip(),table('compile',ordinary).rstrip()]))):guide=guide[:block.start()]+new+guide[block.end():]
guide=guide.replace('measured source `91f15a3e`','measured source `ac5aea97`')
a=guide.index('Frozen core `4c072fed`');z=guide.index('## Warm execution',a)
guide=guide[:a]+'''Frozen core `6a098198` matches the measured source's production inventory;
informational SourceLink is precommit `aaa9cb09`. Windows/Ubuntu Release actual
.NET11/.NET10, original Stress and installed core consumers pass
[cached CI42463155006](../benchmarks/results/2026-11-08-native-method-facts/delivery-ci.json).
The benchmark and source qualification are separate evidence.
The [26-job checkpoint](../benchmarks/results/2026-11-08-canonical-method-checkpoint/README.md)
records exact identities and verified raw evidence. Optional0.4 adapter/worker
unchanged; no newer producer is certified. The [earlier source91f15a3e guide](../benchmarks/results/2026-11-08-canonical-method-checkpoint/prior-BENCHMARKS.md)
preserves the previous tables and their inconclusive cases; still older named
measurements remain linked there. These tables describe the recorded source,
not a future HEAD.

'''+guide[z:]
guide=guide.replace('All26 jobs completed in539.12seconds.',f"All26 jobs completed in{summary['elapsedSeconds']:.2f}seconds.")
guide=guide.replace('Full candidate delivery pending. [R89]','Full delivery qualified. [R89]')
Path('docs/BENCHMARKS.md').write_text(guide,encoding='utf-8',newline='\n')
intro=f'''# Canonical-method checkpoint against CPython

2026-11-08. Committed productionac5aea97, frozen6a098198 core, informational
SourceLinkaaa9cb09; complete production inventory matches the measured source.
Unchanged worker7cf37ca5/optional0.4 adapter, CPython3.13.16/.NET11RC3, quiet
Ubuntu24.04.4 F4as_v7 (four EPYC9V45vCPUs,16GiB/no swap). NormalGC/tiering,
five-second warmup per role/job, seven rotated150ms rounds, two independent
identical Lython processes and one isolated CPython process.

26jobs/{summary['elapsedSeconds']:.3f}s: unchanged eight representative scripts with
compilation/warm/compile-to-result separated, plus existing ordinary rsplit/guarded
helper warm cases. Execution includes mediated RAM I/O/full stdout/files validation/
prior-result cleanup; compilation includes construction/disposal. Startup/staging/
reset/protocol/final cached teardown excluded. CPython imports persist; Lython
execution modules remain isolated, filesystem mediation/path checks included.
These small fixtures do not establish large-file throughput. Actual suspension,
RSS and embedding-tail latency remain unmeasured. No single-change CPU attribution
or repayment of earlier regression debt.

All source/core/auxiliary/actualReady/runtime/golden/quiet/Closed/exit/join/fixture/
archive gates pass. Workers joined and owned128MiB RAM fixtures removed/unmounted
before archival under lease and independent local verification.570sowner+30stop+
30margin. Existing immutable B451 core/archive reused with exact proof; historical
measured footprint+25% fits7MiB above240MiB OSfloor. No evidence deletion/dedup.
Full sourceac5aea97 Windows/Ubuntu actual11/10/originalStress/installed delivery is
separately green and cached asCI42463155006; it does not follow from timing.

Ratios=Lythonelapsed/CPythonelapsed; above1 means slower. Ranges span two Lython
process medians, not confidence intervals. Diagnostic/Variable retain uncertainty,
not design vetoes. Guarded helper remains2.15x warm, ordinary rsplit1.80x; allocation/
architecture/source-pair CPU conclusions remain separate from this external baseline.

'''
(out/'README.md').write_text(intro+table('compile-run',ordinary,True)+'\nWarm execution:\n\n'+table('warm',ordinary+affected)+'\nCompilation:\n\n'+table('compile',ordinary)+'\n[Summary](summary.json), [raw evidence](observations.tgz), [receipt](archive-receipt.json), [core provenance](core-source.json), [historical guide](prior-BENCHMARKS.md).\n',encoding='utf-8')
with tarfile.open(out/'procedures.tar.xz','w:xz')as a:
 for n in ['selection.md','prepare.py','launch.py','launch-command.py','launch.log','observe-not-before.json','terminal-status.json','retrieve.py','summarize.py','table-helpers.py','close.py','sizing.json','core-source.json']:a.add(r/n,arcname=n)
print('26-job current-source CPython checkpoint preserved; authoritative guide refreshed, exact-source qualification separate. All historical/adverse cases retained.')
