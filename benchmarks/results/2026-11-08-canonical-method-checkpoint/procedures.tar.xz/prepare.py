from pathlib import Path
import ast,hashlib,json,math,shutil,tarfile
r=Path(__file__).resolve().parent;old=r.parent/'combined-cpython-r83';runtime=r.parent/'native-method-facts-r89'
source=json.loads((runtime/'direct-fusion/identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in source['productionSources'].items())
receipt=json.loads((runtime/'b451/archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']
assert hashlib.sha256((runtime/'b451/observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
with tarfile.open(runtime/'b451/observations.tgz')as a:assert hashlib.sha256(a.extractfile('current-core.dll').read()).hexdigest()==source['coreSHA256']['candidate']
proof=dict(vmArchive='direct-native-fusion-b451-20261108/observations.tgz',archiveSHA256=receipt['archiveSHA256'],member='current-core.dll',coreSHA256=source['coreSHA256']['candidate'],immutableLocalArtifact='benchmarks/results/2026-11-08-native-method-facts/observations.tar.xz (nested B451 archive)')
(r/'core-source.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
shutil.copyfile(old/'representative.json',r/'representative.json')
catalog=json.loads((r/'representative.json').read_text(encoding='utf-8'))
for c in catalog['cases']:
 for field,digest in [('source','sourceSha256'),('fixtureJson','fixtureSha256'),('expectedOutput','expectedOutputSha256')]:assert hashlib.sha256(c[field].encode('utf-8')).hexdigest()==c[digest]
for name in ['collect.py','run.sh','retrieve.py','summarize.py','table-helpers.py','archive-owned.py','launch.py']:
 s=(old/name).read_text(encoding='utf-8').replace('combined-cpython-b446-20261108','native-cpython-b452-20261108').replace('lython-b446-combined-cpython','lython-b452-native-cpython').replace('combined-cpython-b446-launch.py','native-cpython-b452-launch.py')
 s=s.replace('R83 combined91f15a3e checkpoint: eight complete scripts compile/warm/compile-run and two ordinary helper text warm cases','R90 combinedac5aea97 checkpoint: same eight representative scripts/compile/warm/compile-run and ordinary rsplit/guarded helper warm cases')
 if name=='archive-owned.py':
  s=s.replace(", 'current-core.dll'",", 'core-source.json', 'sizing.json'")
  s=s.replace("result=dict(complete=True", "assert __import__('shutil').disk_usage(root).free>240*1024*1024\nresult=dict(complete=True")
 if name=='launch.py':
  s=s.replace("reference=base/'operand-consumers-b445-20261108/candidate'","reference=base/'direct-native-fusion-b451-20261108/candidate'")
  needle=" shutil.copytree(reference,root/'candidate',copy_function=os.link);os.link(reference/'Lokad.Lython.dll',root/'current-core.dll')"
  assert needle in s
  s=s.replace(needle,""" proof=json.loads((root/'core-source.json').read_text());archive=base/proof['vmArchive']
 assert hashlib.sha256(archive.read_bytes()).hexdigest()==proof['archiveSHA256']
 with tarfile.open(archive)as a:assert hashlib.sha256(a.extractfile(proof['member']).read()).hexdigest()==proof['coreSHA256']
"""+needle)
 (r/name).write_text(s,encoding='utf-8',newline='\n')
 if name.endswith('.py'):ast.parse(s)
collect=(r/'collect.py').read_text(encoding='utf-8');a=collect.index('jobs=');z=collect.index('\nassert len(jobs)',a);jobs=ast.literal_eval(collect[a+5:z]);assert len(jobs)==26
vm=dict(sourceRevision='ac5aea97820d5fcfd2a84cbcca2b04b64d88c6c2',coreSHA256={role:source['coreSHA256']['candidate']for role in ['candidate','candidate-control']},auxiliaryFiles=json.loads((runtime/'b451/identity.json').read_text(encoding='utf-8'))['auxiliaryFiles'],productionSources=source['productionSources'],jobs=jobs,referenceVersion='CPython3.13.16',qualification='397internal/2165public per actual11/10 focused Release; full delivery dispatched08:29:35UTC/pending independently. Frozen informational SourceLinkaaa9cb09; production inventory matches committedac5aea97. Optional0.4 adapter unchanged.')
(r/'identity.json').write_text(json.dumps(vm,indent=2)+'\n',encoding='utf-8')
for src,name in [(runtime/'direct-fusion/identity.json','focused.json'),(runtime/'direct-fusion/source.patch','source.patch'),(Path('PLAN.md'),'pre-measurement-plan.md'),(Path('docs/BENCHMARKS.md'),'prior-BENCHMARKS.md')]:shutil.copyfile(src,r/name)
raw=sum((p.stat().st_size+4095)//4096*4096 for p in (old/'retrieved').rglob('*')if p.is_file()and p.name!='current-core.dll')
with tarfile.open(old/'observations.tgz')as a:compressed=len(__import__('gzip').compress(a.extractfile('current-core.dll').read()))
estimate=math.ceil((raw+(old/'observations.tgz').stat().st_size-compressed+max(0,(r/'source.patch').stat().st_size-(old/'source.patch').stat().st_size))*1.25)
assert estimate<7*1024*1024,estimate
(r/'sizing.json').write_text(json.dumps(dict(priorRoundedRawWithoutCoreBytes=raw,priorArchiveBytes=(old/'observations.tgz').stat().st_size,priorCompressedCoreBytes=compressed,estimatedRawAndArchiveWith25PercentBytes=estimate,headroomBytes=7*1024*1024,osFloorBytes=240*1024*1024,coreArchiveReused=True,noEvidenceDeleted=True),indent=2)+'\n',encoding='utf-8')
contract='''R90: combined current sourceac5aea97/core6a098198 CPython checkpoint after R85/R89.
Same maintained26 jobs: eight complete representative scripts, separate compile,
warm execution and compile-to-result, plus ordinary rsplit/guarded warm helpers.
Unchanged source/fixtures/goldens/toolchain/boundaries and existing worker/collector.
Lython2 independent processes and isolated CPython3.13.16,5s warmup/role/job,
seven rotated150ms rounds, normalGC/tiering, quiet F4as_v7. Keep compile/startup,
I/O/full validation/prior cleanup/final cache teardown boundaries explicit.
All source/core/aux/actualReady/runtime/golden/quiet/Closed/exit/join/fixture/archive
gates required.570sowner+30stop+30margin. Full final-source qualification is an
independent running CI; measurement does not imply containment/release readiness.
Preserve adverse/uncertain/historical cases, CPython primary; no single-change CPU
attribution, prediction, whole-performance-objective closure or publication.
Persistent evidence separate from owned128MiB RAM fixtures. Exact B451 core and
archive reused/verified, no duplicate core in this archive. Prior measured R83
raw/archive footprint+25% fits7MiB above240MiB OSfloor; check exact payload before
launch. No evidence/data/core/path deletion or further deduplication.
'''
for n in ['selection.md','contract.md']:(r/n).write_text(contract,encoding='utf-8')
(r/'setup-contract.json').write_text(json.dumps(dict(jobs=jobs,ownerSeconds=570,stopSeconds=30,marginSeconds=30,osFreeFloorMiB=240,evidenceHeadroomMiB=7),indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'payload.tgz','w:gz')as a:
 for n in ['collect.py','archive-owned.py','run.sh','representative.json','identity.json','focused.json','source.patch','contract.md','selection.md','prior-BENCHMARKS.md','setup-contract.json','pre-measurement-plan.md','core-source.json','sizing.json']:a.add(r/n,arcname=n)
print('Current source/core, unchanged26-job catalog and exact existing-core archival proven; measured footprint+25% fits7MiB headroom. No collection yet.')
