events=[]
def double(value):
    if not not value: return 'full'
    return 'empty'
def triple(value):
    if not not not value: return 'empty'
    return 'full'
class Flag:
    def __bool__(self):
        events.append('bool')
        return True
for value in (None,False,0,1,'','x',[],[1]):
    print(double(value),triple(value))
for operation in (double,triple):
    print(operation(Flag()),events)
    events.clear()
