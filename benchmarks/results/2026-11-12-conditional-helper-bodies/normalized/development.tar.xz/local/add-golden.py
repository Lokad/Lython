from pathlib import Path
import json,subprocess
r=Path(__file__).resolve().parent;p=r/'negated-branches.py';source=p.read_text(encoding='utf-8')
done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8',str(p)],text=True,encoding='utf-8',capture_output=True);assert done.returncode==0,done.stderr
(r/'python-golden.json').write_text(json.dumps(dict(version=subprocess.check_output(['C:/Python313/python.exe','--version'],text=True).strip(),source=source,expected=done.stdout,stderr=done.stderr),indent=2)+'\n',encoding='utf-8')
p=Path('tests/Lokad.Lython.PublicApi.Tests/NativeReturnFunctionTests.cs');s=p.read_text(encoding='utf-8');(r/'NativeReturnFunctionTests.cs.before').write_bytes(p.read_bytes())
needle='public static TheoryData<string, string, string> Cases => new()\n    {\n';assert s.count(needle)==1
line='        { '+', '.join(json.dumps(v)for v in ['negated-branches',source,done.stdout])+' },\n'
p.write_text(s.replace(needle,needle+line),encoding='utf-8')
print('IndependentCPython negationparity/protocol-once golden added; runtime unary machinery removed.')
