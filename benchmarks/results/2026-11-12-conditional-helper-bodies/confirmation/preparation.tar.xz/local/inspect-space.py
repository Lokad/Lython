from pathlib import Path
import json,subprocess
r=Path(__file__).resolve().parent
script='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 groups={}
 for folder,dirs,files in os.walk(base):
  for name in files:
   if name not in ['Lokad.Lython.dll','current-core.dll','baseline-core.dll','candidate-core.dll','reference-core.dll']:continue
   p=Path(folder)/name;s=p.stat();key=(s.st_dev,s.st_ino)
   if key not in groups:groups[key]=dict(bytes=s.st_size,blocks=s.st_blocks*512,paths=[],sha256=hashlib.sha256(p.read_bytes()).hexdigest())
   groups[key]['paths'].append(str(p.relative_to(base)))
 print(json.dumps(dict(free=shutil.disk_usage(base).free,total=shutil.disk_usage(base).total,coreGroups=sorted(groups.values(),key=lambda x:x['blocks'],reverse=True)),indent=2))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=script,text=True,encoding='utf-8',capture_output=True)
assert done.returncode==0,done.stderr
(r/'b613/space-core-inventory.json').write_text(done.stdout,encoding='utf-8')
data=json.loads(done.stdout);print('free',data['free'],'of',data['total'],'unique corefiles',len(data['coreGroups']))
for g in data['coreGroups']:print(g['sha256'][:12],g['blocks'],g['paths'][:3])
