from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;old=r/'b612';q=r/'b613';q.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
identity['sourceRevision']+=' B613samefrozen source; onlyguardedRun/capturedRun confirmation12swarmups/350msbatches, existing7rotations/4roles. InitialadversecapturedCPU/elapsed andidenticalprocessdriftpreserved. No sourcechange or causalrecoveryclaim.'
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8');shutil.copyfile(old/'source-identity.json',q/'source-identity.json');shutil.copyfile(old/'representative.json',q/'representative.json')
jobs=[['scripts.file-search.guarded-helper.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','warm']]
for name in ['collect.py','archive-owned.py','run.sh','launch.py','retrieve.py','summarize.py','remote-launch.py']:
 t=(old/name).read_text(encoding='utf-8').replace('conditional-helper-b612-20261112','conditional-confirmation-b613-20261112').replace('lython-b612-conditional-helper-20261112','lython-b613-conditional-confirmation-20261112').replace('conditional-helper-b612-launch.py','conditional-confirmation-b613-launch.py').replace('lython-b612-fixtures','lython-b613-fixtures').replace('B612','B613')
 if name=='collect.py':
  a=t.index('jobs=');b=t.index('\nassert len(jobs)',a);t=t[:a]+'jobs='+repr(jobs)+t[b:]
  t=t.replace('len(jobs)==6','len(jobs)==2').replace('warmupSeconds=5, targetBatchSeconds=.15','warmupSeconds=12, targetBatchSeconds=.35').replace('end=time.monotonic()+5','end=time.monotonic()+12').replace('count*.15','count*.35').replace(' < 175',' < 145')
 if name=='archive-owned.py':t=t.replace("len(raw['jobs'])==6","len(raw['jobs'])==2").replace('complete=True,jobs=6','complete=True,jobs=2')
 if name=='remote-launch.py':
  t=t.replace("source=base/'text-batches-b608-20261112/candidate'","source=base/'conditional-helper-b612-20261112/candidate'")
  t=t.replace("protected={source/'Lokad.Lython.dll':config['identity']['coreSHA256']['reference']}","referenceCore=base/'text-batches-b608-20261112/candidate/Lokad.Lython.dll'\nprotected={source/'Lokad.Lython.dll':config['identity']['coreSHA256']['candidate'],referenceCore:config['identity']['coreSHA256']['reference']}")
  t=t.replace("os.link(source/'Lokad.Lython.dll' if role=='reference' else root/name,root/role/'Lokad.Lython.dll')","os.link(referenceCore if role=='reference' else source/'Lokad.Lython.dll',root/role/'Lokad.Lython.dll')\n os.link(source/'Lokad.Lython.dll',root/'current-core.dll')")
  t=t.replace('jobs=6,ownerSeconds=210','jobs=2,ownerSeconds=180').replace('RuntimeMaxSec=210','RuntimeMaxSec=180')
 if name=='launch.py':t=t.replace('seconds=270','seconds=240').replace('ownerSeconds=210','ownerSeconds=180')
 if name=='retrieve.py':t=t.replace("['jobs']==6","['jobs']==2").replace("['elapsedSeconds']<210","['elapsedSeconds']<180").replace('six-job','two-job')
 if name=='summarize.py':t=t.replace("len(raw['jobs'])==6","len(raw['jobs'])==2").replace('complete=True,jobs=6','complete=True,jobs=2')
 (q/name).write_text(t,encoding='utf-8',newline='\n')
 if name.endswith('.py')and name!='remote-launch.py':ast.parse(t)
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for name in ['representative.json','source-identity.json','identity.json','collect.py','archive-owned.py','run.sh']:t.add(q/name,arcname=name)
with tarfile.open(q/'payload.tgz')as t:expanded=sum(((m.size+4095)//4096)*4096 for m in t.getmembers())
archive=Path('benchmarks/results/2026-11-12-conditional-helper-bodies/initial/b612/observations.tgz');assert archive.read_bytes()==subprocess.check_output(['git','show','HEAD:'+archive.as_posix()]);retire=[]
for member in [None,'representative.json','confirmation/confirmation.json']:
 with tarfile.open(archive)as t:b=archive.read_bytes()if member is None else t.extractfile(member).read()
 spec=dict(kind='exact',knownPath='conditional-helper-b612-20261112/'+(member or 'observations.tgz'),bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),canonicalStorage=archive.as_posix(),reason='OnlyterminalB612duplicate, committed38745af9 canonicalGitSHA verified. Initialadverseconditions/rawsource preserved, b2/R266cores protected; freshidle/UID/path/inode/allaliasesproof, unchangedfloors.')
 if member:spec.update(canonicalEntry=member,canonicalArchiveSHA256=sha(archive))
 retire.append(spec)
config=dict(root='/home/lokad/lython-bench-checks/conditional-confirmation-b613-20261112',unit='lython-b613-conditional-confirmation-20261112',payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha(q/'payload.tgz'),requiredFreeBytes=expanded+252*1024*1024,retire=retire,identity=identity)
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
script=(q/'remote-launch.py').read_text(encoding='utf-8');assert 'referenceCore=base/'in script and "else source/'Lokad.Lython.dll'"in script
ast.parse(script.replace('config=CONFIG','config='+repr(config)).replace('inventoryOnly=INVENTORY_ONLY','inventoryOnly=True'))
assert 'end=time.monotonic()+12'in(q/'collect.py').read_text(encoding='utf-8')and'count*.35'in(q/'collect.py').read_text(encoding='utf-8')
print('Same-source2job confirmation,12swarmups/350msrounds/180sowner/145slaststart/240sobservation; allinitialadversitypreserved.')
