from pathlib import Path
r=Path(__file__).resolve().parent;out=r/'normalized';out.mkdir(exist_ok=False)
s=(r/'ExecutableScript.NativeReturns.cs.before').read_text(encoding='utf-8')
s=s.replace('var instructions = blocks[block].InstructionArray;\n            for (var index', 'var instructions = blocks[block].InstructionArray;\n            var negateCondition = false;\n            for (var index')
needle='''                    case ExecutableOpCode.JumpIfFalse:
'''
replacement='''                    case ExecutableOpCode.Unary when instruction.UnaryOperator == ExecutableUnaryOperator.Not:
                        if (stack.Count != 1 || stack[0].Member is not null) return null;
                        var end = index;
                        do { negateCondition = !negateCondition; end++; }
                        while (end < instructions.Length && instructions[end].OpCode == ExecutableOpCode.Unary
                            && instructions[end].UnaryOperator == ExecutableUnaryOperator.Not);
                        if (end >= instructions.Length || instructions[end].OpCode != ExecutableOpCode.JumpIfFalse)
                            return null;
                        for (var skipped = index + 1; skipped < end; skipped++)
                        {
                            if (visited[offsets[block] + skipped]) return null;
                            visited[offsets[block] + skipped] = true;
                        }
                        index = end - 1;
                        continue;
                    case ExecutableOpCode.JumpIfFalse:
'''
assert s.count(needle)==1;s=s.replace(needle,replacement)
needle='''                        values.Add(new(NativeReturnOperation.Conditional, instruction, condition.Value,
                            consequent.Value.Root, Third: alternative.Value.Root));'''
replacement='''                        var whenTrue = negateCondition ? alternative.Value : consequent.Value;
                        var whenFalse = negateCondition ? consequent.Value : alternative.Value;
                        values.Add(new(NativeReturnOperation.Conditional, instruction, condition.Value,
                            whenTrue.Root, Third: whenFalse.Root));'''
assert s.count(needle)==1;s=s.replace(needle,replacement)
(out/'ExecutableScript.NativeReturns.cs').write_text(s,encoding='utf-8')
(out/'design.md').write_text('''Prospective compiler-only refinement, not applied or qualified. Normalize a not
chain used immediately as a branch predicate by parity and exchange the existing
Conditional roots. Mark skipped source operations visited. Other unary shapes
keep ordinary execution; no Python behavior removed. Native truth guards decline
custom protocols before effects, whose original bytecode remains. Revert rawUnary
enum/shape/guard/evaluator additions; runtime code becomes qualified-baseline
identical. Removes a runtime node/boxing/proof step for negated predicates. No new
dispatcher/owner/cache/option. Validate nested not, branch laziness, custom truth,
admission reentry, retained aliases and cancellation; measure whole scripts before
retention, preserve original variant and controls. No predicted gain.
''',encoding='utf-8')
print('Compiler-only negated-branch normalization drafted privately; production prototype unchanged.')
