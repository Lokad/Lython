from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;q=r/'b613'
for name in ['config.json','inventory.stdout','inventory.stderr']:shutil.copyfile(q/name,q/(name+'.first-space-short'))
archive=Path('benchmarks/results/2026-11-11-incoming-lexical-stores/quiet/observations.tgz')
assert archive.read_bytes()==subprocess.check_output(['git','show','HEAD:'+archive.as_posix()])
with tarfile.open(archive)as t:data=t.extractfile('current-core.dll').read()
h=hashlib.sha256(data).hexdigest();assert h=='cb03fd47311a7c8252691a598c1bbe03b8ce83c67c6d0ae84e5b0266d8514060'
inventory=json.loads((q/'space-core-inventory.json').read_text(encoding='utf-8'))
groups=[g for g in inventory['coreGroups']if g['sha256']==h];assert len(groups)==2
config=json.loads((q/'config.json').read_text(encoding='utf-8'))
for group in groups:
 config['retire'].append(dict(kind='all-aliases',knownPath=group['paths'][0],bytes=len(data),sha256=h,canonicalStorage=archive.as_posix(),canonicalEntry='current-core.dll',canonicalArchiveSHA256=hashlib.sha256(archive.read_bytes()).hexdigest(),reason='Two superseded physicalcopies of oldR221/cb03core; exactcommitted canonicalsource/core/oldmeasurements preserved. No users; currentqualifiedb2andactiveR266protected. Originalfloorfailurepreserved; freshlease/UID/path/inode/allaliasesproofrequired, floorsunchanged.'))
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
print('Two superseded corecopies selected with committedcanonicalGit/SHA proof; firstfailedfloor preserved, no thresholdchange.')
