from pathlib import Path
import json,subprocess
r=Path(__file__).resolve().parent;rows=[]
version=subprocess.check_output(['C:/Python313/python.exe','-I','-S','--version'],text=True).strip()
for name in ['unary-values','unary-protocols']:
 p=r/(name+'.py');source=p.read_text(encoding='utf-8')
 result=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8',str(p)],text=True,encoding='utf-8',capture_output=True)
 assert result.returncode==0,result.stderr
 (r/(name+'.stdout')).write_text(result.stdout,encoding='utf-8');(r/(name+'.stderr')).write_text(result.stderr,encoding='utf-8')
 rows.append(dict(name=name,source=source,expected=result.stdout))
(r/'python-goldens.json').write_text(json.dumps(dict(version=version,cases=rows),indent=2)+'\n',encoding='utf-8')
p=Path('tests/Lokad.Lython.PublicApi.Tests/NativeReturnFunctionTests.cs');source=p.read_text(encoding='utf-8')
original=r/(p.name+'.before');assert not original.exists();original.write_bytes(p.read_bytes())
needle='public static TheoryData<string, string, string> Cases => new()\n    {\n';assert source.count(needle)==1
insert=''.join('        { '+', '.join(json.dumps(v,ensure_ascii=True)for v in [row['name'],row['source'],row['expected']])+' },\n'for row in rows)
p.write_text(source.replace(needle,needle+insert),encoding='utf-8')
print(version,'two independent unary/helper/protocol/untakenbranch goldens prepared')
