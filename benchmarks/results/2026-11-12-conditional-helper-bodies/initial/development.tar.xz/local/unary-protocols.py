events=[]
class Value:
    def __bool__(self):
        events.append('bool')
        return False
    def __pos__(self):
        events.append('plus')
        return 11
    def __neg__(self):
        events.append('minus')
        return 12
    def __invert__(self):
        events.append('invert')
        return 13
def state(value):
    if not value: return 'empty'
    return value.upper()
def positive(value): return +value
def negative(value): return -value
def invert(value): return ~value
def wanted(value, *, prefix='Né'):
    if not value: return False
    return value.startswith(prefix)
value=Value()
print(state(value),positive(value),negative(value),invert(value),events)
print(wanted('',prefix=value),wanted('Néx'),wanted('no'))
