def state(value):
    if not value:
        return 'empty'
    return 'full'
def positive(value): return +value
def negative(value): return -value
def invert(value): return ~value
print([state(value) for value in (None, False, 0, 0.0, '', b'', [], (), {}, set(), range(0), True, 3, 'x')])
for value in (False, True, -3, 0, 1, 1 << 80):
    print(positive(value) is value, positive(value), negative(value), invert(value))
for value in (-0.0, 2.5):
    print(positive(value) is value, positive(value), negative(value))
for operation in (positive, negative, invert):
    try: operation('text')
    except TypeError: print('bad')
