from pathlib import Path
import hashlib
import json
import subprocess
import sys
import tarfile

lab=Path(__file__).resolve().parent
prior=lab.with_name("direct-fixed-return-slots-20261125")
src=(prior/"prepare.py").read_text(encoding="utf-8")
src=src.replace(".git/agent-worktrees/direct-fixed-return-slots-20261125",".git/agent-worktrees/indexed-fixed-return-slots-20261125")
src=src.replace('== 4\n(lab / "candidate.patch")','== 5\n(lab / "candidate.patch")')
start=src.index('jobs = [')
end=src.index("catalog = ",start)
src=src[:start]+'''jobs = [(invoice,"warm-async"),(text,"warm"),(ordinary,"compile-run"),(mapped,"warm-async"),(invoice,"warm")]
'''+src[end:]
src=src.replace('len(catalog["cases"]) == 6','len(catalog["cases"]) == 4').replace('report["caseCount"] == 6','report["caseCount"] == 4')
src=src.replace('collector = collector.replace("b1721-fixtures", "b1722-fixtures").replace("started < 386", "started < 323")',
'''collector = collector.replace("b1721-fixtures", "b1722c-fixtures").replace("started < 386", "started < 260")
collector = collector.replace("5 seconds full-request", "7 seconds full-request").replace("warmupSeconds=5", "warmupSeconds=7")''')
src=src.replace('lython-b1722-direct-fixed-return-slots','lython-b1722c-indexed-fixed-return-slots')
src=src.replace('RuntimeMaxSec=365','RuntimeMaxSec=282').replace('seconds=289','seconds=251')
src=src.replace('direct-fixed-return-slots-b1722-20261125','indexed-fixed-return-slots-b1722c-20261125')
src=src.replace('assert len(read(lab / "verified-raw-replicas.json")) == 6','assert len(read(lab / "verified-raw-replicas.json")) == 7')
src=src.replace('2026-11-25-direct-fixed-return-slots','2026-11-25-direct-fixed-return-slots/indexed')
src=src.replace("receipt[\"warmJobs\"]==7","receipt[\"warmJobs\"]==5").replace("timedBatches=196,lanes=7","timedBatches=140,lanes=5")
assert "== 5" in src and "b1722c-fixtures" in src
root=lab.parents[3]
result=root/"benchmarks/results/2026-11-25-direct-fixed-return-slots"
rows=json.loads((prior/"verified-raw-replicas.json").read_text(encoding="utf-8"))
receipt=json.loads((result/"quiet-terminal-status.json").read_text(encoding="utf-8"))["receipt"]
archive=result/"quiet-observations.tar.xz"
archive_hash=hashlib.sha256(archive.read_bytes()).hexdigest()
assert receipt["complete"] and receipt["allWorkersJoined"] and archive_hash==receipt["archiveSHA256"]
with tarfile.open(archive) as f:
    raw=f.extractfile("confirmation/confirmation.json").read()
assert json.loads(raw)["complete"]
rows.insert(0,dict(location="direct-fixed-return-slots-b1722-20261125",archiveSHA256=archive_hash,
                   rawSHA256=hashlib.sha256(raw).hexdigest(),bytes=len(raw)))
(lab/"verified-raw-replicas.json").write_text(json.dumps(rows,indent=2)+"\n",encoding="utf-8",newline="\n")
compile(src,"prepare.py","exec")
(lab/"prepare.py").write_text(src,encoding="utf-8",newline="\n")
subprocess.run([sys.executable,"-X","utf8",lab/"prepare.py"],check=True,timeout=100)
