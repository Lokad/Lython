using System.Reflection;
using System.Diagnostics;
using System.Text;
using System.Text.Json;
using Lokad.Lython;
using Lokad.Lython.Utf8Regex;

// Existing complete scripts and comparison host; allocation counters only.
// This tool performs no collection and does not claim local elapsed/CPU evidence.
var image = Path.GetFullPath(args[0]);
var catalogPath = Path.GetFullPath(args[1]);
var output = Path.GetFullPath(args[2]);
if (File.Exists(output)) throw new IOException("Preserve original observations.");
var assembly = Assembly.LoadFrom(Path.Combine(image, "Lokad.Lython.Benchmarks.dll"));
const BindingFlags all = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;
var fixtureType = assembly.GetType("Lokad.Lython.Benchmarks.Comparison.ComparisonFileFixture", true)!;
var hostType = assembly.GetType("Lokad.Lython.Benchmarks.Comparison.ComparisonFileHost", true)!;
var plainHostType = assembly.GetType("Lokad.Lython.Benchmarks.Comparison.ComparisonHost", true)!;
var parse = fixtureType.GetMethod("Parse", all)!;
var reset = hostType.GetMethod("Reset", all)!;
var check = hostType.GetMethod("ReadOutputs", all)!;
var digest = fixtureType.GetMethod("Digest", all)!;
using var catalog = JsonDocument.Parse(File.ReadAllText(catalogPath, Encoding.UTF8));
var rows = new List<object>();
var probe = typeof(LythonEngine).Assembly.GetType("Lokad.Lython.Runtime.LythonRuntime", true)!;
var completed = probe.GetField("DiagnosticPreparedTupleExits", all)!;
var copied = probe.GetField("DiagnosticFixedWindowCopies", all)!;

foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var source = item.GetProperty("source").GetString()!;
    var expected = item.GetProperty("expectedOutput").GetString()!;
    var fixture = parse.Invoke(null, [item.GetProperty("fixtureJson").GetString()]);
    var folder = Path.Combine(Path.GetTempPath(), "lython-comparison-files-" + Guid.NewGuid().ToString("N"));
    var budget = new AdmissionWitness(new LythonMemoryBudget(256L * 1024 * 1024));
    var host = fixture is null ? (ILythonHost)Activator.CreateInstance(plainHostType, nonPublic: true)!
        : (ILythonHost)Activator.CreateInstance(hostType, all, null, [fixture, folder], null)!;
    try
    {
        using var script = new LythonEngine(Utf8RegexProvider.Instance).Compile(source, budget);
        if (!script.IsValid) throw new InvalidOperationException(string.Join("|", script.Diagnostics));
        var baseline = budget.Root.ReservedBytes;
        long peakExecutionMemoryBytes = 0;
        void Run(bool asynchronous)
        {
            if (fixture is not null) reset.Invoke(host, null);
            using (var result = asynchronous ? script.RunAsync(host).GetAwaiter().GetResult() : script.Run(host))
            {
                if (!result.Success || result.StandardOutput != expected || result.StandardError != "")
                    throw new InvalidDataException(result.Failure?.Message ?? result.StandardOutput);
                peakExecutionMemoryBytes = Math.Max(peakExecutionMemoryBytes, result.PeakExecutionMemoryBytes);
                if (fixture is not null)
                {
                var files = check.Invoke(host, null);
                var actualFiles = (string)digest.Invoke(null, [files])!;
                if (actualFiles != item.GetProperty("expectedFilesSha256").GetString())
                    throw new InvalidDataException("File golden mismatch.");
                }
            }
            if (budget.Root.ReservedBytes != baseline) throw new InvalidOperationException("Ownership did not return to compilation baseline.");
        }
        foreach (var asynchronous in new[] { false, true })
        {
            completed.SetValue(null, 0);
            copied.SetValue(null, 0);
            peakExecutionMemoryBytes = 0;
            Run(asynchronous);
            rows.Add(new { id = item.GetProperty("id").GetString(), asynchronous,
                preparedTupleReturns = (int)completed.GetValue(null)!, stagedTupleWindowCopies = (int)copied.GetValue(null)!,
                peakExecutionMemoryBytes, allowanceReturned = true });
        }
        script.Dispose();
        if (budget.Root.ReservedBytes != 0) throw new InvalidOperationException("Compiled owner retained allowance.");
    }
    finally
    {
        (host as IDisposable)?.Dispose();
        var full = Path.GetFullPath(folder);
        if (Path.GetDirectoryName(full) != Path.GetFullPath(Path.GetTempPath()).TrimEnd(Path.DirectorySeparatorChar) ||
            !Path.GetFileName(full).StartsWith("lython-comparison-files-", StringComparison.Ordinal))
            throw new InvalidOperationException("Unexpected owned fixture path.");
        if (Directory.Exists(full)) Directory.Delete(full, recursive: true);
    }
}
File.WriteAllText(output, JsonSerializer.Serialize(new { coreSHA256 = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))).ToLowerInvariant(), rows,
    boundary = "Counts from isolated managed route instrumentation in the before/after sources. No timing." }, new JsonSerializerOptions { WriteIndented = true }), new UTF8Encoding(false));

internal sealed class AdmissionWitness(LythonMemoryBudget root) : ILythonMemoryBudget
{
    internal LythonMemoryBudget Root { get; } = root;
    internal Dictionary<long,int> Growths { get; } = new();

    public ILythonMemoryScope CreateScope() => new Scope(this, Root.CreateScope());

    public bool TryReserve(long bytes, [System.Diagnostics.CodeAnalysis.NotNullWhen(true)] out ILythonMemoryReservation? reservation)
        => TryReserve(Root, bytes, out reservation);

    private bool TryReserve(ILythonMemoryBudget scope, long bytes, [System.Diagnostics.CodeAnalysis.NotNullWhen(true)] out ILythonMemoryReservation? reservation)
    {
        reservation = null;
        if (!scope.TryReserve(bytes, out var inner)) return false;
        reservation = new Reservation(this, inner);
        return true;
    }

    private sealed class Scope(AdmissionWitness witness, ILythonMemoryScope inner) : ILythonMemoryScope
    {
        public ILythonMemoryScope CreateScope() => new Scope(witness, inner.CreateScope());
        public bool TryReserve(long bytes, [System.Diagnostics.CodeAnalysis.NotNullWhen(true)] out ILythonMemoryReservation? reservation)
            => witness.TryReserve(inner, bytes, out reservation);
        public void Dispose() => inner.Dispose();
    }

    private sealed class Reservation(AdmissionWitness witness, ILythonMemoryReservation inner) : ILythonMemoryReservation
    {
        public long Bytes => inner.Bytes;
        public bool TryResize(long bytes)
        {
            var growth = bytes - inner.Bytes;
            if (!inner.TryResize(bytes)) return false;
            if (growth > 0) witness.Growths[growth] = witness.Growths.GetValueOrDefault(growth) + 1;
            return true;
        }
        public void Dispose() => inner.Dispose();
    }
}
