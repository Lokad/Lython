from pathlib import Path

lab=Path(__file__).resolve().parent
tree=lab.parents[3]/".git/agent-worktrees/indexed-fixed-return-slots-20261125"
root=tree/"src/Lokad.Lython"

def change(path, edits):
    p=root/path
    text=p.read_text(encoding="utf-8")
    for a,b in edits:
        assert text.count(a)==1,(path,a)
        text=text.replace(a,b)
    p.write_text(text,encoding="utf-8",newline="\n")

change("Frontend/ExecutableScript.cs",[(
"""    internal int PreparedTupleIndex => _secondaryOperand;
    internal ExecutableInstruction WithPreparedTupleReturn(int tupleIndex)
        => new(ExecutableOpCode.PreparedTupleReturn, Span, _primaryOperand, tupleIndex, _inputStart, _resultSlot, _liveExtent);""",
"""    internal const int PreparedTupleSourceBits = 4;
    internal const int PreparedTupleComputedSource = (1 << PreparedTupleSourceBits) - 1;
    internal int PreparedTupleIndex => _secondaryOperand;
    internal uint PreparedTupleSources => unchecked((uint)_inputStart);
    internal ExecutableInstruction WithPreparedTupleReturn(int tupleIndex, uint sources)
        => new(ExecutableOpCode.PreparedTupleReturn, Span, _primaryOperand, tupleIndex, unchecked((int)sources), _resultSlot, _liveExtent);""",
)])
change("Frontend/ExecutableStackLayout.cs", [
    ("if (tuple.ItemCount < 2 || tuple.HasResultConsumer || first < 0 ||",
     "if (tuple.ItemCount is < 2 or > (32 / ExecutableInstruction.PreparedTupleSourceBits) || tuple.HasResultConsumer || first < 0 ||"),
    ("        uint locals = 0;\n        var computed = false;",
     """        uint locals = 0;
        uint sources = 0;
        var computed = false;"""),
    ("""            if (producer.OpCode == ExecutableOpCode.LoadLocal)
            {
                var bit = 1u << producer.LocalSlot;
                if ((locals & bit) != 0 || code.CapturedLocalSlots.Contains(producer.LocalSlot)) return;""",
     """            var source = ExecutableInstruction.PreparedTupleComputedSource;
            if (producer.OpCode == ExecutableOpCode.LoadLocal)
            {
                source = producer.LocalSlot;
                var bit = 1u << source;
                if ((uint)source >= ExecutableInstruction.PreparedTupleComputedSource ||
                    (locals & bit) != 0 || code.CapturedLocalSlots.Contains(source)) return;"""),
    ("""                computed = true;
            }
        }
        tape[offset + first] = block[first].WithPreparedTupleReturn(offset + index);""",
     """                computed = true;
            }
            sources |= (uint)source << ((i - first) * ExecutableInstruction.PreparedTupleSourceBits);
        }
        tape[offset + first] = block[first].WithPreparedTupleReturn(offset + index, sources);"""),
])
change("Runtime/LythonRuntime.Executable.Integers.cs", [
    ("private static bool TryFinishPreparedTupleReturn(ExecutableCodeObject code, Span<ExecutableSlot> values,",
     "private static bool TryFinishPreparedTupleReturn(ExecutableCodeObject code, ReadOnlySpan<ExecutableSlot> values,"),
    ("        var computedIndex = -1;\n", ""),
    ("                computedIndex = i;\n", ""),
    ("""        for (var i = first; i < tupleIndex; i++)
            destination[^(i - first + 1)] = i == computedIndex ? computed : values[instructions[i].LocalSlot];
        return true;""",
     """        var sources = instructions[first].PreparedTupleSources;
        for (var i = destination.Length - 1; i >= 0; i--)
        {
            var source = (int)(sources & ExecutableInstruction.PreparedTupleComputedSource);
            destination[i] = source == ExecutableInstruction.PreparedTupleComputedSource ? computed : values[source];
            sources >>= ExecutableInstruction.PreparedTupleSourceBits;
        }
        return true;"""),
])
