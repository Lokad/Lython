from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import zipfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
donor=lab.with_name("private-definition-admission-20261125")
quiet=lab/"comparison/quiet"
read=lambda p:json.loads(p.read_text(encoding="utf-8"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=read(quiet/"identity.json")
patch=lab/"candidate.patch"
assert sha(patch)==identity["sourcePatchSHA256"]
archive=lab/"diagnostic-source.zip"
subprocess.run(["git","archive","--format=zip",f"--output={archive}",identity["sourceRevision"],"--",
                "global.json","Directory.Build.props","Directory.Packages.props","src/Lokad.Lython"],cwd=repo,check=True)
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))

project=lab/"route-probe"
project.mkdir(exist_ok=True)
old=(donor/"admission-probe/Program.cs").read_text(encoding="utf-8")
assemblies='var probe = typeof(LythonEngine).Assembly.GetType("Lokad.Lython.Runtime.LythonRuntime", true)!;'
old=old.replace("var rows = new List<object>();",
                "var rows = new List<object>();\n"+assemblies+"""
var completed = probe.GetField("DiagnosticPreparedTupleExits", all)!;
var copied = probe.GetField("DiagnosticFixedWindowCopies", all)!;
""")
old=old.replace("budget.Growths.Clear();","completed.SetValue(null, 0);\n            copied.SetValue(null, 0);")
old=old.replace('resizeGrowths = budget.Growths.Values.Sum(), resizeGrowthsByBytes = new SortedDictionary<long,int>(budget.Growths),',
                'preparedTupleReturns = (int)completed.GetValue(null)!, stagedTupleWindowCopies = (int)copied.GetValue(null)!,')
old=old.replace("Observed positive resize requests through the public budget on the unmodified measurement images. No timing.",
                "Counts from isolated managed route instrumentation in the before/after sources. No timing.")
(project/"Program.cs").write_text(old,encoding="utf-8",newline="\n")
csproj=(donor/"admission-probe/AdmissionWitness.csproj").read_text(encoding="utf-8").replace("AdmissionWitness","TupleRouteWitness")
(project/"TupleRouteWitness.csproj").write_text(csproj,encoding="utf-8",newline="\n")
subprocess.run([dotnet,"build",project/"TupleRouteWitness.csproj","-c","Release","--nologo"],
               cwd=lab,env=env,check=True,timeout=70)
files=project/"bin/Release/net11.0"

results={}
for role in ("reference","candidate"):
    source=lab/(role+"-route-source")
    with zipfile.ZipFile(archive) as z:
        z.extractall(source)
    if role=="candidate":
        subprocess.run(["git","apply",patch],cwd=source,check=True,timeout=30)
    runtime=source/"src/Lokad.Lython/Runtime"
    path=runtime/"LythonRuntime.Executable.Integers.cs"
    body=path.read_text(encoding="utf-8")
    first="    private static bool TryEvaluateIntegerInstruction("
    assert body.count(first)==1
    body=body.replace(first,"    internal static int DiagnosticPreparedTupleExits;\n\n"+first)
    anchor="            return completed = true;" if role=="reference" else "sources >>= ExecutableInstruction.PreparedTupleSourceBits;\n        }"
    assert body.count(anchor)==1
    body=body.replace(anchor, "            System.Threading.Interlocked.Increment(ref DiagnosticPreparedTupleExits);\n"+anchor
                      if role=="reference" else anchor+"\n        System.Threading.Interlocked.Increment(ref DiagnosticPreparedTupleExits);")
    path.write_text(body,encoding="utf-8",newline="\n")
    path=runtime/"LythonRuntime.Executable.Operations.cs"
    body=path.read_text(encoding="utf-8")
    anchor="    private static void WriteUnpackOperands(ReadOnlySpan<ExecutableSlot> items, Span<ExecutableSlot> destination)\n    {"
    assert body.count(anchor)==1
    body=body.replace(anchor,"    internal static int DiagnosticFixedWindowCopies;\n\n"+anchor+
                       "\n        System.Threading.Interlocked.Increment(ref DiagnosticFixedWindowCopies);")
    path.write_text(body,encoding="utf-8",newline="\n")
    build=lab/(role+"-route-build")
    with (lab/(role+"-route-build.log")).open("wb") as log:
        subprocess.run([dotnet,"build","src/Lokad.Lython/Lokad.Lython.csproj","-c","Release","-f","net11.0","--no-incremental",
                        "--artifacts-path",build],cwd=source,env=env,check=True,timeout=100,stdout=log,stderr=subprocess.STDOUT)
    image=lab/(role+"-route-image")
    image.mkdir(exist_ok=True)
    assert {p.name:sha(p) for p in (lab/role).iterdir()}==identity["imageFiles"][role]
    for p in (lab/role).iterdir(): shutil.copyfile(p,image/p.name)
    for p in files.glob("TupleRouteWitness.*"): shutil.copyfile(p,image/p.name)
    core=build/"bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll"
    shutil.copyfile(core,image/core.name)
    out=lab/(role+"-routes.json")
    subprocess.run([dotnet,image/"TupleRouteWitness.dll",image,quiet/"representative.json",out],cwd=lab,env=env,check=True,timeout=70)
    data=read(out)
    assert data["coreSHA256"]==sha(core) and data["coreSHA256"]!=identity["coreSHA256"][role]
    results[role]=data["rows"]
summary=[]
for a,b in zip(results["reference"],results["candidate"],strict=True):
    assert (a["id"],a["asynchronous"])==(b["id"],b["asynchronous"]) and a["allowanceReturned"] and b["allowanceReturned"]
    row=dict(case=a["id"],asyncHosting=a["asynchronous"],preparedReturns=[a["preparedTupleReturns"],b["preparedTupleReturns"]],
             stagedWindowCopies=[a["stagedTupleWindowCopies"],b["stagedTupleWindowCopies"]],
             executionPeak=[a["peakExecutionMemoryBytes"],b["peakExecutionMemoryBytes"]])
    summary.append(row)
    print(row,flush=True)
(lab/"routes-summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8",newline="\n")
