Keep both prototypes private. The slot map removes the additional tape read
but the invoice still takes 0.76–2.32% longer warm async and 1.09–1.74%
longer warm sync. Invoice CPU is 1.30–2.08% higher in the sync comparison.
Text and file-fed map also regress despite taking zero prepared exits.
Ordinary definitions through result span zero in this block. The control
movement leaves the cause open. It supplies no evidence that this
publication change makes the complete script faster.
