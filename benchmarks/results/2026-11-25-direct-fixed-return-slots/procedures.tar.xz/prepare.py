from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
tree = repo / ".git/agent-worktrees/direct-fixed-return-slots-20261125"
quiet = lab / "comparison/quiet"
quiet.mkdir(parents=True, exist_ok=True)
donor = lab.with_name("private-definition-admission-20261125")
external = lab.with_name("direct-record-cpython-20261125")
runner = donor
read = lambda path: json.loads(path.read_text(encoding="utf-8-sig"))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, text):
    path.write_text(text, encoding="utf-8", newline="\n")

def save(path, value):
    write(path, json.dumps(value, indent=2) + "\n")

def git(cwd, *args):
    return subprocess.check_output(["git", *args], cwd=cwd)

base = git(tree, "rev-parse", "HEAD").decode().strip()
old = read(donor / "comparison/quiet/identity.json")
production = git(repo, "rev-parse", "93eead293").decode().strip()
assert git(repo, "diff", "--binary", production, base, "--", "src", "tests") == b""
committed_patch = git(repo,"diff","--binary",old["sourceRevision"],production,"--","src")
assert committed_patch == (donor/"candidate.patch").read_bytes()
patch = git(tree, "diff", "--binary", base, "--", "src")
assert patch and patch.count(b"diff --git ") == 4
(lab / "candidate.patch").write_bytes(patch)
(lab / "tests.patch").write_bytes(git(tree, "diff", "--binary", base, "--", "tests"))
frozen = old["imageFiles"]["candidate"]
assert len(frozen) == 32 and {p.name: sha(p) for p in (donor / "candidate").iterdir()} == frozen
core = lab / "bench/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll"
copied = lab / "bench/bin/Lokad.Lython.Benchmarks/release_net11.0/Lokad.Lython.dll"
assert sha(core) == sha(copied) and sha(core) != frozen[core.name]

images = {"reference": frozen, "candidate": frozen | {core.name: sha(core)}}
for role, files in images.items():
    image = lab / role
    image.mkdir(exist_ok=True)
    for name in files:
        shutil.copyfile(core if role == "candidate" and name == core.name else donor / "candidate" / name, image / name)
    assert {p.name: sha(p) for p in image.iterdir()} == files

invoice = "scripts.csv-invoice.method-policy.quoted-control"
ordinary = "diagnostic.generated-ordinary-definitions"
rules = "scripts.rule-default-closures"
mapped = "diagnostic.shipment-file-fed-map"
shipment = "diagnostic.shipment-routing-callbacks"
text = "diagnostic.text-summary.nonlocal-computed-width.large"
jobs = [(invoice,"warm"),(mapped,"warm-async"),(rules,"warm"),(text,"warm"),
        (shipment,"warm-async"),(invoice,"warm-async"),(ordinary,"compile-run")]
catalog = read(external/"external/representative.json")
catalog["cases"] = [case for case in catalog["cases"] if case["id"] in dict(jobs)]
assert len(catalog["cases"]) == 6
save(quiet / "representative.json", catalog)
save(quiet / "jobs.json", {"warm": jobs})
identity = dict(sourceRevision=base, comparisonRevision=production, sourcePatchSHA256=sha(lab / "candidate.patch"),
    imageFiles=images, coreSHA256={role + suffix: files[core.name] for role, files in images.items() for suffix in ("", "-control")},
    expectedCPythonSHA256=old["expectedCPythonSHA256"], cpythonWorkerSHA256=old["cpythonWorkerSHA256"],
    catalogs={name: {"sha256": sha(quiet / name)} for name in ("representative.json", "jobs.json")},
    purpose="Publish prepared tuple returns directly to the funded caller operand window")
save(quiet / "identity.json", identity)

sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
python_worker = repo / "benchmarks/cpython-worker.py"
assert sha(python_worker) == identity["cpythonWorkerSHA256"]
for role, files in images.items():
    evidence = lab / "comparison" / (role + "-verify.json")
    subprocess.run([dotnet, lab / role / "Lokad.Lython.Benchmarks.dll", "--compare", "verify",
                    "--catalog", quiet / "representative.json", "--dotnet", dotnet, "--python", "C:/Python313/python.exe",
                    "--python-worker", python_worker, "--out", evidence],
                   cwd=repo, env=env, check=True, timeout=80)
    report = read(evidence)
    assert report["state"] == "Completed" and report["caseCount"] == 6
    assert report["launched"]["library"]["sha256"] == files[core.name]
    assert {p.name: sha(p) for p in (lab / role).iterdir()} == files
assert patch == git(tree, "diff", "--binary", base, "--", "src")

collector = (runner / "comparison/quiet/collect.py").read_text(encoding="utf-8")
collector = collector.replace("len(jobs) == 9", f"len(jobs) == {len(jobs)}")
collector = collector.replace("b1721-fixtures", "b1722-fixtures").replace("started < 386", "started < 323")
compile(collector, "collect.py", "exec")
write(quiet / "collect.py", collector)
shutil.copyfile(runner / "comparison/quiet/run.sh", quiet / "run.sh")
assert b"\r" not in (quiet / "run.sh").read_bytes()

launcher = (runner / "quiet.py").read_text(encoding="utf-8").replace("lython-b1721-private-definition-admission",
    "lython-b1722-direct-fixed-return-slots")
launcher = launcher.replace("RuntimeMaxSec=430", "RuntimeMaxSec=365").replace("seconds=355", "seconds=289")
anchor = read(donor / "comparison/quiet/terminal-status.json")["receipt"]
assert anchor["complete"] and sha(donor / "comparison/quiet/observations.tar.xz") == anchor["archiveSHA256"]
a = launcher.index("assert donor['archiveSHA256']=='")
b = launcher.index("\n", a)
launcher = launcher[:a] + "assert donor['archiveSHA256']==" + repr(anchor["archiveSHA256"]) + launcher[b:]
compile(launcher, "quiet.py", "exec")
write(lab / "quiet.py", launcher)
assert len(read(lab / "verified-raw-replicas.json")) == 6

payload = quiet / "payload.tar.gz"
with tarfile.open(payload, "w:gz", compresslevel=3) as archive:
    for name in ("identity.json", "jobs.json", "representative.json", "run.sh", "collect.py"):
        archive.add(quiet / name, arcname=name)
    archive.add(lab / "candidate" / core.name, arcname="candidate-core.dll")
save(quiet / "upload.json", dict(root="direct-fixed-return-slots-b1722-20261125",
    reference=read(donor / "comparison/quiet/upload.json")["root"], payloadSHA256=sha(payload), payloadBytes=payload.stat().st_size))
archiver = (runner / "archive.py").read_text(encoding="utf-8").replace("private-definition-admission", "direct-fixed-return-slots")
archiver = archiver.replace('==receipt["warmJobs"]==9', '==receipt["warmJobs"]==7').replace("timedBatches=252,lanes=9","timedBatches=196,lanes=7")
compile(archiver, "archive.py", "exec")
write(lab / "archive.py", archiver)
for name in ("compile-allocation.py", "allocations.py"):
    shutil.copyfile(runner / name, lab / name)
