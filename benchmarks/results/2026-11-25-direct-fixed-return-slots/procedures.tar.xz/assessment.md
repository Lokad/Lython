The measured prototype stays private. Invoice warm sync elapsed crosses
zero. Async invoice elapsed rises 1.10–2.25% and wider CPU rises 2.70%
across all rounded worker pairings. Ordinary definitions also use
1.12–3.87% more CPU through result. Text and file-fed controls show substantial
worker spread. Removing the staging copy alone does not justify the new
publication path. A refinement can remove its second instruction-tape read.
