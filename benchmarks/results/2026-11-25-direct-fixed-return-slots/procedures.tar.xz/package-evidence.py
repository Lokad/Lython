from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
tree=repo/".git/agent-worktrees/direct-fixed-return-slots-20261125"
out=repo/"benchmarks/results/2026-11-25-direct-fixed-return-slots"
quiet=lab/"comparison/quiet"
read=lambda p:json.loads(p.read_text(encoding="utf-8"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=read(quiet/"identity.json")
assert sha(lab/"candidate.patch")==identity["sourcePatchSHA256"]
for path, file in (("src","candidate.patch"),("tests","tests.patch")):
    assert subprocess.check_output(["git","diff","--binary",identity["sourceRevision"],"--",path],cwd=tree)==(lab/file).read_bytes()
for role, files in identity["imageFiles"].items():
    assert {p.name:sha(p) for p in (lab/role).iterdir()}==files
shutil.copyfile(quiet/"identity.json",out/"identity.json")
for name in ("allocation-summary.json","compile-allocation-summary.json","routes-summary.json"):
    shutil.copyfile(lab/name,out/name)
procedures=[
    "prepare-return.py","prepare-stage.py","prepare.py","quiet.py","archive.py","package-evidence.py",
    "candidate.patch","tests.patch","candidate-build.log","prepare.log","launch-console.log","retrieve.log",
    "verified-raw-replicas.json","test-ubuntu.sh","allocations.py","allocations.log",
    "compile-allocation.py","compile-allocation.log","diagnose-routes.py","diagnose-routes.log",
    "route-probe/Program.cs","route-probe/TupleRouteWitness.csproj",
    "comparison/reference-verify.json","comparison/candidate-verify.json","comparison/quiet/storage-custody.json",
    "assessment.md",
]
procedures.extend(sorted(p.name for p in lab.glob("Lokad.Lython.*.log")))
for role in ("reference","candidate"):
    procedures.extend(f"{role}-{name}" for name in ("allocation-final.json","compiler-owner.json","routes.json","route-build.log"))
with tarfile.open(out/"procedures.tar.xz","w:xz") as archive:
    for name in procedures:
        archive.add(lab/name,arcname=name)
with tarfile.open(out/"procedures.tar.xz") as archive:
    assert archive.getnames()==procedures
    for name in procedures:
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==sha(lab/name)
names={
    "diagnostic.generated-ordinary-definitions":"Generated ordinary definitions",
    "scripts.rule-default-closures":"Defaulted rule factories",
    "diagnostic.shipment-file-fed-map":"File-fed CSV map",
    "scripts.csv-invoice.method-policy.quoted-control":"Quoted CSV invoice",
    "diagnostic.shipment-routing-callbacks":"Shipment callback report",
    "diagnostic.text-summary.nonlocal-computed-width.large":"Nonlocal Unicode text",
}
phases={"warm":"Warm sync","warm-async":"Warm async","compile":"Compilation","compile-run":"Compile-to-result"}
def pct(values): return " to ".join(f"{v:+.2f}".replace("-", "−") for v in values)+"%"
def timing_table(summary):
    rows=["| Workload | Phase | Elapsed change | Wider CPU change | Reference / candidate elapsed spread |",
          "| --- | --- | ---: | ---: | ---: |"]
    for row in read(summary)["rows"]:
        cols=(names[row["case"]],phases[row["lane"]],pct(row["elapsedPercent"]),pct(row["cpuPercent"]),
              " / ".join(f"{v:.2f}%" for v in row["sameSourceElapsedSpreadPercent"]))
        rows.append("| "+" | ".join(cols)+" |")
    return "\n".join(rows)
assessment=Path(sys.argv[1]).read_text(encoding="utf-8").strip()
content=f"""# B1722 Publish prepared tuple elements directly

Both executable drivers check the private source slots, hold at most one
computed element in a managed local and admit scalar publication before
writing to the caller's existing unpack operands. This removes the
callee's staging window, extent changes and the subsequent copy from
that window. Refusal, cancellation and a declining type check leave
the caller's destination intact. Multiple computed elements and
dynamic operations use the existing tuple return and unpack paths.

The frozen reference uses the runtime of `93eead293`. Both 32-file images
differ only in the core DLL and match six independent output/file goldens.
A separate instrumented Windows run reaches the prepared exit 4,096 times
per invoice in each hosting mode. The corresponding 4,096 staging copies
disappear. The five controls never take the prepared exit. CLR allocation
essentially matches on the invoice, and all measured admission peaks,
retained compilation estimates and final balances match across the pair.

The quiet Azure F4as_v7 used Ubuntu 24.04.4 and .NET 11 RC3 on
November 25, 2026 UTC. Two workers per image warm for five full-request
seconds and contribute seven rotated batches per phase. Ranges span the
four pairings of worker medians. Warm elapsed includes mediated RAM-backed
I/O where applicable, verification and prior-result cleanup. Wider CPU
includes fixture reset and request framing. Compilation, warm and
compile-to-result are separate.

{timing_table(out/"quiet-summary.json")}

{assessment}

Windows .NET 11 and Ubuntu .NET 10 each pass 436 focused Release checks,
including caller storage on refusal/cancellation, return aliases, target
order, and fallback into an operator that genuinely suspends. All 196
timed batches verify. Workers join and the persistent archive verifies
after fixture removal under the lease.

[Identity](identity.json) · [Timings](quiet-summary.json) · [Route counts](routes-summary.json) ·
[Runtime allocation](allocation-summary.json) · [Compilation allocation](compile-allocation-summary.json) ·
[Observations](quiet-observations.tar.xz) · [Terminal receipt](quiet-terminal-status.json) ·
[Source and procedures](procedures.tar.xz).
"""
(out/"README.md").write_text(content,encoding="utf-8",newline="\n")
print("Verified all procedure archive members.")
