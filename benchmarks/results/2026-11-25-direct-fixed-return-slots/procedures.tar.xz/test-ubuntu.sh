set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab="$PWD/.git/agent-notes/review-20261031/direct-fixed-return-slots-20261125"
worktree="$PWD/.git/agent-worktrees/direct-fixed-return-slots-20261125"
filter='(FullyQualifiedName~TupleReturn|FullyQualifiedName~DefinitionPair|FullyQualifiedName~OrdinaryUnpacking|FullyQualifiedName~BatchedTuplePreflight|FullyQualifiedName~NativeOperationAllocation|FullyQualifiedName~ExecutableStack|FullyQualifiedName~StackSafety|FullyQualifiedName~AsyncFunctionHosting|FullyQualifiedName~NativeCallback)&Category!=Stress'
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
  logfile="$lab/$suite-ubuntu10.log"
  if dotnet test "$worktree/tests/$suite/$suite.csproj" -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$logfile" 2>&1; then
    tail -4 "$logfile"
  else
    tail -50 "$logfile"
    exit 1
  fi
done
