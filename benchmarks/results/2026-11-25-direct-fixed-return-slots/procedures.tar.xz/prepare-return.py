from pathlib import Path

lab=Path(__file__).resolve().parent
tree=lab.parents[3]/".git/agent-worktrees/direct-fixed-return-slots-20261125"
src=tree/"src/Lokad.Lython"
def change(path, edits):
    file=src/path
    text=file.read_text(encoding="utf-8")
    for a,b in edits:
        assert text.count(a)==1, (path,a)
        text=text.replace(a,b)
    file.write_text(text,encoding="utf-8",newline="\n")

change("Frontend/ExecutableStackLayout.cs", [
    ("        uint locals = 0;\n        for (var i = first; i < index; i++)",
     "        uint locals = 0;\n        var computed = false;\n        for (var i = first; i < index; i++)"),
    ("""            else if (producer.OpCode != ExecutableOpCode.Binary ||
                !IsPrivateInput(producer.InputStart) || !IsPrivateInput(producer.SecondInput)) return;""",
     """            else
            {
                // A single computed scalar stays in a managed local until
                // admission. Other elements remain in their existing slots.
                if (computed || producer.OpCode != ExecutableOpCode.Binary ||
                    !IsPrivateInput(producer.InputStart) || !IsPrivateInput(producer.SecondInput)) return;
                computed = true;
            }"""),
])
change("Runtime/LythonRuntime.Executable.Integers.cs", [(
"""    private static bool TryPrepareFixedTupleReturn(ExecutableCodeObject code, Span<ExecutableSlot> values,
        ref int index, int liveExtent, int unpackCount, ExecutionContext scope)
    {
        var tupleIndex = code.Instructions[index].PreparedTupleIndex;
        ref readonly var tuple = ref code.Instructions[tupleIndex];
        if (unpackCount != tuple.ItemCount || liveExtent != tuple.InputStart) return false;

        var items = values.Slice(liveExtent, unpackCount);
        var completed = false;
        long scalarBytes = 0;
        try
        {
            for (var i = 0; i < items.Length; i++)
            {
                ref readonly var producer = ref code.Instructions[index + i];
                scope.CheckExecution(producer.Span);
                ExecutableSlot item;
                if (producer.OpCode == ExecutableOpCode.Binary)
                {
                    if (!TryEvaluatePreparedBinary(code, values, producer, scope, out var result)) return false;
                    item = ExecutableSlot.FromInteger(result);
                }
                else
                {
                    item = values[producer.LocalSlot];
                    if (!item.HasMaterializedValue && !item.TryGetInteger(out _)) return false;
                    // Preserve an already published identity or an existing
                    // tuple borrow. A fresh local has one returned position.
                }
                items[i] = item;
                scalarBytes = checked(scalarBytes + item.ScalarStorageBytes);
            }
            // Until admission succeeds the slots are private to this helper.
            // Keep the tuple's source position for a refusal or cancellation.
            index = tupleIndex;
            scope.State.CheckExecution(tuple.Span);
            AdmitUnpackedReturnScalars(scalarBytes, scope, tuple.Span);
            return completed = true;
        }
        finally
        {
            if (!completed) items.Clear();
        }
    }""",
"""    private static bool TryFinishPreparedTupleReturn(ExecutableCodeObject code, Span<ExecutableSlot> values,
        ref int index, int liveExtent, Span<ExecutableSlot> destination, ExecutionContext scope)
    {
        var instructions = code.Instructions;
        var first = index;
        var tupleIndex = instructions[first].PreparedTupleIndex;
        ref readonly var tuple = ref instructions[tupleIndex];
        if (destination.Length != tuple.ItemCount || liveExtent != tuple.InputStart) return false;

        long scalarBytes = 0;
        var computed = default(ExecutableSlot);
        var computedIndex = -1;
        for (var i = first; i < tupleIndex; i++)
        {
            ref readonly var producer = ref instructions[i];
            scope.CheckExecution(producer.Span);
            ExecutableSlot item;
            if (producer.OpCode == ExecutableOpCode.Binary)
            {
                if (!TryEvaluatePreparedBinary(code, values, producer, scope, out var result)) return false;
                item = computed = ExecutableSlot.FromInteger(result);
                computedIndex = i;
            }
            else
            {
                item = values[producer.LocalSlot];
                if (!item.HasMaterializedValue && !item.TryGetInteger(out _)) return false;
            }
            scalarBytes = checked(scalarBytes + item.ScalarStorageBytes);
        }

        // Leave the caller's inputs and every destination intact through the
        // last fallible operation. The remaining local slots cannot be changed
        // by reentry, and the one computed value is still a managed local.
        index = tupleIndex;
        scope.CheckExecution(tuple.Span);
        AdmitUnpackedReturnScalars(scalarBytes, scope, tuple.Span);
        scope.CheckExecution(instructions[++index].Span);
        for (var i = first; i < tupleIndex; i++)
            destination[^(i - first + 1)] = i == computedIndex ? computed : values[instructions[i].LocalSlot];
        return true;
    }""",
)])
change("Runtime/LythonRuntime.Executable.NativePrefix.cs", [
    ("        private int _unpackedTupleStart = -1;\n        internal bool ReturnedUnpacked => _unpackedTupleStart >= 0;",
     """        private const int NoUnpackedReturn = -1, PreparedUnpackedReturn = -2;
        private int _unpackedTupleStart = NoUnpackedReturn;
        internal bool ReturnedUnpacked => _unpackedTupleStart != NoUnpackedReturn;"""),
    ("var completed = RunCore(out result);","var completed = RunCore(out result, unpackedReturn);"),
    ("""                    WriteUnpackOperands(Values.Slice(_unpackedTupleStart, _unpackedReturnCount), unpackedReturn);
                    Trim(Code.FirstTemporarySlot);
                    _scope.CheckExecution(Code.Instructions[Index + 1].Span);""",
     """                    if (_unpackedTupleStart >= 0)
                        WriteUnpackOperands(Values.Slice(_unpackedTupleStart, _unpackedReturnCount), unpackedReturn);
                    Trim(Code.FirstTemporarySlot);
                    if (_unpackedTupleStart >= 0) _scope.CheckExecution(Code.Instructions[Index + 1].Span);"""),
    ("private bool RunCore(out ExecutableSlot result)","private bool RunCore(out ExecutableSlot result, scoped Span<ExecutableSlot> unpackedReturn)"),
    ("""                            TryPrepareFixedTupleReturn(Code, Values, ref Index, LiveExtent, _unpackedReturnCount, _scope))
                        {
                            _unpackedTupleStart = LiveExtent;
                            LiveExtent += _unpackedReturnCount;""",
     """                            TryFinishPreparedTupleReturn(Code, Values, ref Index, LiveExtent, unpackedReturn, _scope))
                        {
                            _unpackedTupleStart = PreparedUnpackedReturn;"""),
])
change("Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs", [(
"""                                TryPrepareFixedTupleReturn(execution.Code, execution.Stack.Values, ref execution.InstructionIndex,
                                    execution.Stack.LiveExtent, unpackedReturn.Length, scope))
                            {
                                execution.Stack.RestoreNativeExtent(execution.Stack.LiveExtent + unpackedReturn.Length);
                                PublishFixedReturn(ref execution, scope, instructions[execution.InstructionIndex], unpackedReturn);
                                return InstructionPause.UnpackedReturn;
                            }""",
"""                                TryFinishPreparedTupleReturn(execution.Code, execution.Stack.Values, ref execution.InstructionIndex,
                                    execution.Stack.LiveExtent, unpackedReturn, scope))
                                return InstructionPause.UnpackedReturn;""",
)])
