from pathlib import Path
import subprocess
import sys
lab = Path(__file__).resolve().parent
source=lab.with_name("private-definition-admission-20261125")/"prepare.py"
s=source.read_text(encoding="utf-8")
def edit(a,b):
    global s
    assert s.count(a)==1,(a,s.count(a))
    s=s.replace(a,b)
edit('".git/agent-worktrees/private-definition-admission-20261125"', '".git/agent-worktrees/direct-fixed-return-slots-20261125"')
edit('donor = lab.with_name("direct-record-cpython-20261125")', 'donor = lab.with_name("private-definition-admission-20261125")\nexternal = lab.with_name("direct-record-cpython-20261125")')
edit('runner = lab.with_name("csv-direct-record-admission-20261125")','runner = donor')
edit('old = read(donor / "external/identity.json")\nassert git(repo, "diff", "--binary", old["productionSource"], base, "--", "src", "tests") == b""',
     '''old = read(donor / "comparison/quiet/identity.json")
production = git(repo, "rev-parse", "93eead293").decode().strip()
assert git(repo, "diff", "--binary", production, base, "--", "src", "tests") == b""
committed_patch = git(repo,"diff","--binary",old["sourceRevision"],production,"--","src")
assert committed_patch == (donor/"candidate.patch").read_bytes()''')
edit('patch.count(b"diff --git ") == 7','patch.count(b"diff --git ") == 4')
edit('old["productionSource"]','production')
a=s.index('ordinary = "diagnostic.')
b=s.index('save(quiet / "representative.json"',a)
s=s[:a]+'''invoice = "scripts.csv-invoice.method-policy.quoted-control"
ordinary = "diagnostic.generated-ordinary-definitions"
rules = "scripts.rule-default-closures"
mapped = "diagnostic.shipment-file-fed-map"
shipment = "diagnostic.shipment-routing-callbacks"
text = "diagnostic.text-summary.nonlocal-computed-width.large"
jobs = [(invoice,"warm"),(mapped,"warm-async"),(rules,"warm"),(text,"warm"),
        (shipment,"warm-async"),(invoice,"warm-async"),(ordinary,"compile-run")]
catalog = read(external/"external/representative.json")
catalog["cases"] = [case for case in catalog["cases"] if case["id"] in dict(jobs)]
assert len(catalog["cases"]) == 6
'''+s[b:]
edit('purpose="Prepay the callable with the existing private keyword default owner"',
     'purpose="Publish prepared tuple returns directly to the funded caller operand window"')
a=s.index('collector = ')
b=s.index('compile(collector',a)
s=s[:a]+'''collector = (runner / "comparison/quiet/collect.py").read_text(encoding="utf-8")
collector = collector.replace("len(jobs) == 9", f"len(jobs) == {len(jobs)}")
collector = collector.replace("b1721-fixtures", "b1722-fixtures").replace("started < 386", "started < 323")
'''+s[b:]
a=s.index('launcher = ')
b=s.index('assert anchor["complete"]',a)
s=s[:a]+'''launcher = (runner / "quiet.py").read_text(encoding="utf-8").replace("lython-b1721-private-definition-admission",
    "lython-b1722-direct-fixed-return-slots")
launcher = launcher.replace("RuntimeMaxSec=430", "RuntimeMaxSec=365").replace("seconds=355", "seconds=289")
anchor = read(donor / "comparison/quiet/terminal-status.json")["receipt"]
'''+s[b:]
edit('sha(donor / "external/observations.tar.xz")', 'sha(donor / "comparison/quiet/observations.tar.xz")')
edit('save(lab / "verified-raw-replicas.json", [])','assert len(read(lab / "verified-raw-replicas.json")) == 6')
edit('root="private-definition-admission-b1721-20261125"','root="direct-fixed-return-slots-b1722-20261125"')
edit('read(donor / "external/upload.json")','read(donor / "comparison/quiet/upload.json")')
a=s.index('archiver = ')
b=s.index('compile(archiver',a)
s=s[:a]+'''archiver = (runner / "archive.py").read_text(encoding="utf-8").replace("private-definition-admission", "direct-fixed-return-slots")
archiver = archiver.replace('==receipt["warmJobs"]==9', '==receipt["warmJobs"]==7').replace("timedBatches=252,lanes=9","timedBatches=196,lanes=7")
'''+s[b:]
compile(s,"prepare.py","exec")
(lab/"prepare.py").write_text(s,encoding="utf-8",newline="\n")
subprocess.run([sys.executable,"-X","utf8",lab/"prepare.py"],check=True,timeout=100)
