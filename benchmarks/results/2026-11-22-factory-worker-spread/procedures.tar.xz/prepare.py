from pathlib import Path
import gzip,hashlib,json,os,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
out=lab/"comparison"
quiet=out/"quiet"
quiet.mkdir(parents=True,exist_ok=True)
prior=lab.parent/"definition-annotation-transport-20261122"/"comparison"
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda data:hashlib.sha256(data).hexdigest()
def h(p):return sha(p.read_bytes())
def write(p,s):
    if p.suffix==".py":compile(s,str(p),"exec")
    p.write_text(s,encoding="utf-8",newline="\n")
def save(p,obj):write(p,json.dumps(obj,indent=2,ensure_ascii=False)+"\n")
def archive(directory,name):
    return subprocess.check_output(["git","show","origin/master:benchmarks/results/"+directory+"/"+name],cwd=repo)
old=read(prior/"quiet/config.json")
core="Lokad.Lython.dll"
baseline=old["identity"]["reference"]
manifest=old["identity"]["imageFiles"]["reference"]
assert baseline.startswith("55424591f") and len(manifest)==32 and manifest==old["sourceFiles"]
archive_name="2026-11-22-current-source-cpython"
proof=json.loads(archive(archive_name,"source.json"))
assert proof["revision"]==baseline and proof["imageFiles"]["candidate"]==manifest
assert sha(gzip.decompress(archive(archive_name,"candidate-core.dll.gz")))==manifest[core]
catalog=read(prior/"quiet/representative.json")
case=catalog["cases"][0]
assert case["id"]=="scripts.annotated-rule-closures.nested-factories.postponed"
catalog["cases"]=[case]
catalog_path=quiet/"representative.json"
save(catalog_path,catalog)
image=out/"frozen"
image.mkdir(exist_ok=True)
assert {n:h(prior/"frozen-reference"/n) for n in manifest}==manifest
for n in manifest:shutil.copyfile(prior/"frozen-reference"/n,image/n)
assert {p.name:h(p) for p in image.iterdir()}==manifest
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
protocol=repo/"benchmarks/cpython-worker.py"
assert h(protocol)==old["protocolSHA256"]==proof["protocolSHA256"]
verify=out/"verification.json"
subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",catalog_path,
    "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",verify],
    env=env,cwd=repo,check=True,timeout=90)
assert read(verify)["state"]=="Completed" and read(verify)["caseCount"]==1 and read(verify)["catalogSha256"]==h(catalog_path)
assert {p.name:h(p) for p in image.iterdir()}==manifest

old_root,old_unit=old["root"],old["unit"]
root=old_root.replace("definition-annotation-transport-b1413","factory-worker-spread-b1414")
unit=old_unit.replace("b1413-definition-annotation-transport","b1414-factory-worker-spread")
identity=dict(sourceRevision=baseline,reference=baseline,candidate=baseline,
    imageFiles={role:manifest for role in ("reference","candidate")},
    coreSHA256={label:manifest[core] for label in ("reference","reference-control","candidate","candidate-control")},
    purpose="Same-image factory warm worker spread, followed by conditional active CPU sampling",
    normalAdapterPin="0.4.0",protocolSHA256=h(protocol), catalogs={catalog_path.name:{"sha256":h(catalog_path)}})
save(quiet/"identity.json",identity)
for name in ("collect.py","run.sh","archive-owned.py","retrieve.py"):
    code=(prior/"quiet"/name).read_text(encoding="utf-8").replace(old_root,root).replace(old_unit,unit)
    code=code.replace("len(raw['jobs'])==6","len(raw['jobs'])==1").replace("jobs=6,","jobs=1,").replace("['jobs']==6","['jobs']==1")
    if name=="collect.py":
        start,end=code.index("\njob_catalog = "),code.index("\nenv =")
        code=code[:start]+"\ncase_id = "+repr(case["id"])+"\n"+code[end:]
        code=code.replace("assert not any(k.startswith(('DOTNET_', 'COMPlus_')) and k != 'DOTNET_ROOT' for k in env)",
            "assert not any(k.startswith(('DOTNET_', 'COMPlus_')) and k != 'DOTNET_ROOT' for k in env)\nenv['DOTNET_PerfMapEnabled']='3'")
        code=code.replace("not any(self.identity['runtimeOverrides'].values())",
            "not any(v for k,v in self.identity['runtimeOverrides'].items() if k!='DOTNET_PerfMapEnabled')")
        code=code[:code.index("with (root.parent/'comparison-vm.lock')")]
        code+=(lab/"collect-body.py").read_text(encoding="utf-8")
    write(quiet/name,code)
assert b"\r" not in (quiet/"run.sh").read_bytes()
write(quiet/"warm_probe.py",(lab/"warm_probe.py").read_text(encoding="utf-8"))
parts=("identity.json","representative.json","collect.py","warm_probe.py","run.sh","archive-owned.py")
payload=quiet/"payload.tgz"
with tarfile.open(payload,"w:gz") as bundle:
    for name in parts:bundle.add(quiet/name,arcname=name)
unpacked=sum((quiet/n).stat().st_size for n in parts)
prior_dir="2026-11-22-definition-annotation-transport"
old_receipt=json.loads(archive(prior_dir,"archive-receipt.json"))
assert old_receipt["complete"] and old_receipt["archivedAndVerifiedUnderLease"]
assert sha(archive(prior_dir,"observations.tgz"))==old_receipt["archiveSHA256"]
previous_core=gzip.decompress(archive(prior_dir,"candidate-core.dll.gz"))
assert sha(previous_core)==old["identity"]["imageFiles"]["candidate"][core]
retire=[dict(paths=[Path(old_root).name+"/candidate/"+core],bytes=len(previous_core),links=1,sha256=sha(previous_core),
             archives={Path(old_root).name+"/observations.tgz":old_receipt["archiveSHA256"]})]
config={**old,"root":root,"unit":unit,"identity":identity,"retireGroups":retire,
        "payloadBytes":payload.stat().st_size,"payloadSHA256":h(payload),"unpackedBytes":unpacked}
save(quiet/"config.json",config)
launch=(prior/"quiet/remote-launch.py").read_text(encoding="utf-8")
start,end=launch.index("\nc=")+1,launch.index("\nb=Path(")
launch=(launch[:start]+"c="+repr(config)+launch[end:]).replace("b1413-fixtures","b1414-fixtures")
launch=launch.replace("RuntimeMaxSec=415","RuntimeMaxSec=240").replace("2*1024*1024","5*1024*1024")
write(quiet/"remote-launch.py",launch)
launch=(prior/"launch.py").read_text(encoding="utf-8").replace("seconds=366","seconds=178").replace("before 366 seconds","before 178 seconds")
write(out/"launch.py",launch.replace("Definition annotation transport","Factory worker spread"))
