from warm_probe import dump, medians, observe, preserve_maps, sample_profile, warm

with (root.parent/"comparison-vm.lock").open("a") as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    def gate(name):
        subprocess.run([str(dotnet),str(worker),"--compare","check-machine","--out",str(out/name)],env=env,check=True)
        assert json.loads((out/name).read_text())["gate"]["quiet"]
    time.sleep(5)
    gate("machine-before.json")
    (out/"fixture-filesystem.txt").write_text(subprocess.check_output(
        ["findmnt","-T",str(owned_ram),"-o","TARGET,SOURCE,FSTYPE,OPTIONS"],text=True))
    assert all(n not in env for n in ("DOTNET_JitDisasm","COMPlus_JitDisasm"))
    assert manifest_hash == identity["catalogs"][catalog.name]["sha256"]
    started=time.monotonic()
    labels=["reference-control","candidate-control","reference","candidate"]
    pids={}
    record=dict(sourceRevision=identity["sourceRevision"],purpose=identity["purpose"],
                nominalWarmupSeconds=[8,24],nominalBatchSeconds=.6,perfMapMode=3,
                profileTrigger=dict(longElapsedSpreadPercent=4.0,minimumPairedCpuSpreadPercent=2.0),
                complete=False,jobs=[])
    report=out/"confirmation.json"
    dump(report,record)
    try:
        with contextlib.ExitStack() as stack:
            workers=[]
            for label in labels:
                worker_run=Worker(label,cases[case_id],"warm",stack)
                workers.append(worker_run)
                pids[label]=worker_run.process.pid
            counts=[1]*len(workers)
            warmed=[0.0]*len(workers)
            warmups={label:[] for label in labels}
            turn=0
            observations=[]
            job=dict(case=case_id,lane="warm",identities={w.label:w.identity for w in workers},
                     pids=pids,checkpoints=observations,warmupBatches=warmups,profiles=[])
            record["jobs"].append(job)
            for prefix in (8,24):
                turn=warm(workers,counts,warmed,prefix,warmups,turn)
                measurements=observe(workers,counts,7,cpu_frequency)
                observations.append(dict(requestWarmupSeconds=warmed.copy(),sampleIterations=counts.copy(),
                    nominalSeconds=prefix,samples=measurements,medians=medians(labels,measurements)))
                dump(report,record)
            last=observations[-1]["medians"]
            fastest=min(labels,key=lambda label:last[label]["elapsedMs"])
            slowest=max(labels,key=lambda label:last[label]["elapsedMs"])
            elapsed_spread=100*(last[slowest]["elapsedMs"]/last[fastest]["elapsedMs"]-1)
            cpu_spread=100*(last[slowest]["cpuMs"]/last[fastest]["cpuMs"]-1)
            profile=elapsed_spread>=4.0 and cpu_spread>=2.0
            job["decision"]=dict(fastest=fastest,slowest=slowest,elapsedSpreadPercent=elapsed_spread,
                                    pairedCpuSpreadPercent=cpu_spread,profile=profile)
            dump(report,record)
            if profile:
                for label in (fastest,slowest):
                    index=labels.index(label)
                    job["profiles"].append(sample_profile(workers[index],counts[index],out/("profile-"+label),cpu_frequency))
                job["checksAfterProfile"]=observe(workers,counts,3,cpu_frequency)
    finally:
        if pids:
            record["retiredTemporaryMaps"]=preserve_maps(pids,out/"maps")
            dump(report,record)
    job["workersJoinedAndFixturesRemoved"]=True
    time.sleep(5)
    gate("machine-after.json")
    record.update(complete=True,elapsedSeconds=time.monotonic()-started)
    dump(report,record)
    assert not list(owned_ram.iterdir())
    subprocess.run(["sudo","-n","umount",str(owned_ram)],check=True)
    owned_ram.rmdir()
    subprocess.run(["python3",str(root/"archive-owned.py")],check=True)
