from pathlib import Path
from collections import Counter
import gzip,bisect,re,json
lab=Path(__file__).resolve().parent
root=lab/"comparison/quiet/retrieved/confirmation"
methods={"ExecuteInstructionPrefix","RunCore","StartNativeCall","CreateFunctionValue","StartExecutableDefaults",
         "BindFunctionArgumentsInto","StartInline","CanRunNativePrefix","TryExecuteNativeCall"}
sample_line=re.compile(r"^.*?\s(\d+)\s+\d+\.\d+:\s+\d+\s+cpu-clock:")
frame=re.compile(r"^\s+([0-9a-f]+)\s+(.*)$")
summary={}
for folder in sorted(root.glob("profile-*")):
    role=folder.name.removeprefix("profile-")
    entries=[]
    with gzip.open(root/"maps"/(role+"-perf.map.gz"),"rt",encoding="utf-8") as stream:
        for line in stream:
            start,size,symbol=line.rstrip().split(" ",2)
            if "[Lokad.Lython]" not in symbol or "Lokad.Lython.Runtime." not in symbol:continue
            method=symbol.split("::")[-1].split("(",1)[0]
            if method not in methods:continue
            address,length=int(start,16),int(size,16)
            entries.append((address,address+length,method,symbol.rsplit("[",1)[-1].rstrip("]"),length))
    entries.sort()
    starts=[row[0] for row in entries]
    ends=[]
    for start,end,*unused in entries:ends.append(max(ends[-1],end) if ends else end)
    def resolve(address):
        i=bisect.bisect_right(starts,address)-1
        matched=set()
        while i>=0 and address<ends[i]:
            start,end,method,tier,size=entries[i]
            if start<=address<end:matched.add((method,tier,size))
            i-=1
        return next(iter(matched)) if len(matched)==1 else None
    groups=[]
    with gzip.open(folder/"all-thread-stacks.txt.gz","rt",encoding="utf-8") as stream:
        for line in stream:
            if sample_line.match(line):
                groups.append(set())
                continue
            match=frame.match(line)
            if match and groups:
                value=resolve(int(match[1],16))
                if value:groups[-1].add(value)
    histogram=Counter()
    for group in groups:histogram.update(group)
    summary[role]=[dict(method=method,tier=tier,codeBytes=size,stacks=count)
                   for (method,tier,size),count in histogram.most_common()]
(lab/"comparison/quiet/active-jit-versions.json").write_text(json.dumps(summary,indent=2)+"\n",
                                                            encoding="utf-8",newline="\n")
