from pathlib import Path
import gzip
import hashlib
import json
import os
import select
import shutil
import signal
import stat
import statistics
import subprocess
import time

def dump(path, value):
    path.write_text(json.dumps(value, indent=2)+"\n", encoding="utf-8")

def warm(workers, counts, warmed, target, case, turn):
    for _ in range(256):
        if min(warmed) >= target:
            return turn
        for offset in range(len(workers)):
            i=(turn+offset)%len(workers)
            if warmed[i]>=target:continue
            response=workers[i].request("batch",counts[i])
            case[workers[i].label].append(response)
            seconds=workers[i].last_request_seconds
            warmed[i]+=seconds
            counts[i]=max(1,min(100000,round(counts[i]*.6/max(seconds,.000001))))
        turn+=1
    raise TimeoutError("Bounded factory warmup did not settle")

def observe(workers, counts, turns, cpu_frequency):
    samples=[]
    for turn in range(turns):
        for offset in range(len(workers)):
            i=(turn+offset if turn%2==0 else turn-offset)%len(workers)
            worker=workers[i]
            response=worker.request("batch",counts[i])
            samples.append(dict(round=turn,label=worker.label,response=response,
                cpuTicks=worker.last_cpu_ticks,cpuFrequency=cpu_frequency))
    return samples

def medians(labels, samples):
    elapsed=lambda r:r["response"]["elapsedTicks"]/r["response"]["clockFrequency"]
    cpu=lambda r:r["cpuTicks"]/r["cpuFrequency"]
    return {label:{clock:statistics.median(
        1000*value(r)/r["response"]["completedInvocations"] for r in samples if r["label"]==label)
        for clock,value in (("elapsedMs",elapsed),("cpuMs",cpu))} for label in labels}

def task_cpu(pid, frequency):
    out={}
    for task in Path(f"/proc/{pid}/task").iterdir():
        try:
            contents=(task/"stat").read_text()
            fields=contents[contents.rfind(")")+2:].split()
            out[task.name]=dict(name=(task/"comm").read_text().strip(),spent=(int(fields[11])+int(fields[12]))/frequency)
        except FileNotFoundError:
            pass
    return out

def sample_profile(worker, count, folder, cpu_frequency):
    folder.mkdir()
    pid=worker.process.pid
    for name in ("control","ack"):
        os.mkfifo(folder/name)
    fds=[os.open(folder/name,os.O_RDWR|os.O_NONBLOCK) for name in ("control","ack")]
    def control(command, wait=True):
        os.write(fds[0],(command+"\n").encode())
        if wait:
            if not select.select([fds[1]],[],[],5)[0]:raise TimeoutError("perf control")
            assert os.read(fds[1],64).rstrip(b"\0\r\n")==b"ack"
    raw=folder/"perf.data"
    rows=[]
    with (folder/"collector.log").open("wb") as log:
        profile=subprocess.Popen(["sudo","-n","perf","record","-e","cpu-clock","-F","199","--call-graph","fp",
            "--pid",str(pid),"--delay=-1","--control",f"fifo:{folder}/control,{folder}/ack","-o",str(raw)],
            stdout=log,stderr=subprocess.STDOUT)
        try:
            control("enable")
            before=task_cpu(pid,cpu_frequency)
            deadline=time.monotonic()+5.5
            while time.monotonic()<deadline:
                response=worker.request("batch",count)
                rows.append(dict(label=worker.label,response=response,cpuTicks=worker.last_cpu_ticks,cpuFrequency=cpu_frequency))
            after=task_cpu(pid,cpu_frequency)
            control("disable")
        finally:
            try:
                if profile.poll() is None:control("stop",False)
                assert profile.wait(timeout=10)==0
            finally:
                for fd in fds:os.close(fd)
    st=raw.lstat()
    assert raw.resolve()==raw and stat.S_ISREG(st.st_mode)
    if st.st_uid!=os.getuid():
        assert st.st_uid==0
        expected=subprocess.check_output(["sudo","-n","sha256sum",str(raw)],text=True).split()[0]
        subprocess.run(["sudo","-n","chown",f"{os.getuid()}:{os.getgid()}",str(raw)],check=True)
        assert raw.stat().st_ino==st.st_ino and hashlib.sha256(raw.read_bytes()).hexdigest()==expected
    stacks=subprocess.check_output(["perf","script","-i",str(raw)],stderr=subprocess.STDOUT,timeout=15)
    with gzip.open(folder/"all-thread-stacks.txt.gz","wb") as out:out.write(stacks)
    for name in ("control","ack"):
        path=folder/name
        assert path.resolve()==path and stat.S_ISFIFO(path.lstat().st_mode)
        path.unlink()
    cpu=[dict(tid=tid,name=row["name"],seconds=row["spent"]-before.get(tid,{"spent":0})["spent"]) for tid,row in after.items()]
    details=dict(label=worker.label,pid=pid,samples=rows,threadCpuSeconds=cpu,verified=True)
    dump(folder/"record.json",details)
    return details

def preserve_maps(pids, maps):
    maps.mkdir()
    retired=[]
    for label,pid in pids.items():
        for prefix in ("perf","perfinfo"):
            path=Path(f"/tmp/{prefix}-{pid}.map")
            if not path.exists():continue
            assert path.resolve()==path and path.stat().st_uid==os.getuid()
            content=path.read_bytes()
            target=maps/f"{label}-{prefix}.map.gz"
            with gzip.open(target,"wb")as saved:saved.write(content)
            with gzip.open(target,"rb")as saved:assert saved.read()==content
            path.unlink()
            retired.append(dict(label=label,path=path.name,sha256=hashlib.sha256(content).hexdigest()))
        assert not Path(f"/tmp/jit-{pid}.dump").exists()
    return retired
