from pathlib import Path
import json
import os
import subprocess
import zipfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
identity=json.loads((lab/'comparison/identity.json').read_text(encoding='utf-8'))
source=lab/'diagnostic-source'
source.mkdir(exist_ok=True)
archive=lab/'diagnostic-source.zip'
subprocess.run(['git','archive','--format=zip','--output='+str(archive),identity['candidate'],
    'src/Lokad.Lython','Directory.Build.props','Directory.Build.targets','Directory.Build.rsp',
    'Directory.Packages.props','NuGet.Config','global.json'],cwd=repo,check=True)
with zipfile.ZipFile(archive) as package:package.extractall(source)
changes={
    'LythonRuntime.Executable.CasedSplits.cs': (
        'result = ExecutableSlot.FromObject(words);',
        'result = ExecutableSlot.FromObject(words);\n                    System.Console.Error.WriteLine("LYTHON_ROUTE cased-return " + function.Name);'),
    'PyExecutableFunction.cs': (
        '        // after binding and asks the caller to try another execution route.\n        NativeValues buffer = default;',
        '        // after binding and asks the caller to try another execution route.\n'
        '        System.Console.Error.WriteLine("LYTHON_ROUTE workspace " + Name);\n        NativeValues buffer = default;'),
}
for file,(before,after) in changes.items():
    path=source/'src/Lokad.Lython/Runtime'/file
    content=path.read_text(encoding='utf-8-sig')
    assert content.count(before)==1
    path.write_text(content.replace(before,after),encoding='utf-8',newline='\n')
routes=(lab.with_name('closed-capture-pair-20261124')/'routes.py').read_text(encoding='utf-8')
start=routes.index("affected='scripts.captured-rule-closures'")
routes=routes[:start]+'''for row in rows:
    if row['case'].startswith(('diagnostic.text-summary.nonlocal','diagnostic.text-summary.borrowed')):
        assert row['routes']['cased-return words_from_line']>0
        assert row['routes']['workspace words_from_line']==0
    else:
        assert row['routes']['cased-return words_from_line']==0
'''
compile(routes,'routes.py','exec')
(lab/'routes.py').write_text(routes,encoding='utf-8',newline='\n')
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
subprocess.run([sdk/'dotnet.exe','build',source/'src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0',
    '--no-incremental','--artifacts-path',lab/'diagnostic-build','--nologo'],env=env,cwd=source,check=True,timeout=140)
subprocess.run(['C:/Python313/python.exe','-I','-X','utf8',lab/'routes.py'],cwd=repo,check=True,timeout=140)
