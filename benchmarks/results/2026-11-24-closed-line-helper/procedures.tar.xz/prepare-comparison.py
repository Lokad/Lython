from pathlib import Path

lab=Path(__file__).resolve().parent
previous=lab.with_name('prepared-closed-defaults-20261124')
refined=lab.with_name('prepared-closed-defaults-refined-20261124')
prepare=(previous/'prepare.py').read_text(encoding='utf-8')
prepare=prepare.replace('f6d06f638','aa8064b1c').replace('bec00e82d','46c967257')
prepare=prepare.replace("('white',47),('public',199)", "('white',87),('public',639)")
prepare=prepare.replace("lab / f'{host}-{suite}.log'", "lab / ('windows-public-broad.log' if (host,suite)==('windows','public') else f'{host}-{suite}.log')")
start=prepare.index('shutil.copyfile(donor / \'comparison/representative.json\'')
end=prepare.index('identity = dict(',start)
prepare=prepare[:start]+'''catalog=read(donor/'comparison/representative.json')
text=read(lab.with_name('decoded-ascii-file-values-20261124')/'comparison/representative.json')['cases']
inline=read(lab.with_name('current-short-text-cpu-20261123')/'catalog.json')['cases']
short='diagnostic.text-summary.nonlocal-computed-width.large'
text_ids=(short,'diagnostic.text-summary.borrowed-cased-words.mixed-width',
          'diagnostic.text-summary.borrowed-cased-words.unique-medium','diagnostic.text-summary.without-per-line-helper')
rules=('scripts.rule-default-closures','scripts.csv-invoice.method-policy.quoted-control')
cases={case['id']:case for case in catalog['cases']+text+inline}
catalog['cases']=[cases[case] for case in text_ids+rules]
save(comparison/'representative.json',catalog)
jobs=dict(warm=[(case,'warm') for case in text_ids+rules]+[(short,'compile-run')])
save(comparison/'jobs.json',jobs)
'''+prepare[end:]
prepare=prepare.replace('Replace the duplicate direct definition readers with linked compiled default stores',
    'Complete the cased text helper and any proved length update without a native workspace')
start=prepare.index('old_verification =');end=prepare.index('for role, files in proved.items():\n    result=read',start)
prepare=prepare[:start]+'''sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
environment=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
python_worker=repo/'benchmarks/cpython-worker.py'
assert digest(python_worker)==identity['cpythonWorkerSHA256']
for role in ('reference','candidate'):
    subprocess.run([dotnet,lab/role/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',comparison/'representative.json',
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',python_worker,'--out',comparison/(role+'-verify.json')],
        env=environment,cwd=repo,timeout=75,check=True)
'''+prepare[end:]
prepare=prepare.replace('prepared-closed-defaults-b1606-','closed-line-helper-b1608-')
prepare=prepare.replace('lython-b1606-prepared-closed-defaults','lython-b1608-closed-line-helper')
prepare=prepare.replace("'b1606-'","'b1608-'").replace('b1606-fixtures','b1608-fixtures')
prepare=prepare.replace("'len(jobs) == 8'","'len(jobs) == 7'").replace("'== 8\\n'","'== 7\\n'")
prepare=prepare.replace("'timedBatches=224'","'timedBatches=196'")
prepare=prepare.replace("launcher=launcher.replace('seconds=405','seconds=395')",
    "launcher=launcher.replace('seconds=405','seconds=354').replace('RuntimeMaxSec=460','RuntimeMaxSec=425')")
prepare=prepare.replace('Prepared eight short complete-script lanes','Prepared seven short complete-script lanes')
compile(prepare,'prepare.py','exec')
(lab/'prepare.py').write_text(prepare,encoding='utf-8',newline='\n')

compaction=(refined/'compact-archived-cores.py').read_text(encoding='utf-8')
a=compaction.index('sources = (');b=compaction.index('sha = ',a)
compaction=compaction[:a]+"""sources = (
    ('prepared-closed-defaults-refined-20261124','prepared-closed-defaults-refined-b1607-20261124',
        '2026-11-24-prepared-closed-defaults/refined'),
    ('private-definition-call-20261124','private-definition-call-b1598-20261124','2026-11-24-private-definition-call'),
)
"""+compaction[b:]
compile(compaction,'compact-archived-cores.py','exec')
(lab/'compact-archived-cores.py').write_text(compaction,encoding='utf-8',newline='\n')
