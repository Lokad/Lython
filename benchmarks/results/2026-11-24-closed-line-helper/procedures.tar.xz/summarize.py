from pathlib import Path
from statistics import median,quantiles
import hashlib,json,tarfile

lab=Path(__file__).resolve().parent
comparison=lab/"comparison"
quiet=comparison/"quiet"
read=lambda p:json.loads(p.read_text(encoding="utf-8"))
status=read(quiet/"terminal-status.json")
archive=quiet/"observations.tar.xz"
assert not status["live"] and not status["fixtures"] and status["exitCode"]=="0"
receipt=status["receipt"]
assert all(receipt[k] for k in ["complete","allWorkersJoined","guestFixturesRemoved","quietBeforeAndAfter","archivedAndVerifiedUnderLease"])
assert receipt["warmJobs"] == 7
assert hashlib.sha256(archive.read_bytes()).hexdigest()==receipt["archiveSHA256"]
identity=read(comparison/"identity.json")
jobs=read(comparison/"jobs.json")
cases={case["id"]:case for case in read(comparison/"representative.json")["cases"]}
with tarfile.open(archive) as frozen:
    packed=lambda name:json.load(frozen.extractfile(name))
    assert identity==packed("identity.json")
    assert jobs==packed("jobs.json")
    warm=packed("confirmation/confirmation.json")
    assert warm["complete"] and len(warm["jobs"])==len(jobs["warm"])
    assert [(job["case"],job["lane"]) for job in warm["jobs"]]==[tuple(row) for row in jobs["warm"]]
    warm_rows=[]
    for job in warm["jobs"]:
        assert job["workersJoinedAndFixturesRemoved"] and len(job["samples"])==28
        case=cases[job["case"]]
        stats={}
        for role,proof in job["identities"].items():
            assert [lib["sha256"] for lib in proof["libraries"] if Path(lib["path"]).name=="Lokad.Lython.dll"]==[identity["coreSHA256"][role]]
            assert proof["runtimeVersion"]=="11.0.0"
            elapsed=[]
            cpu=[]
            for row in job["samples"]:
                if row["engine"]!=role:continue
                response=row["response"]
                count=response["completedInvocations"]
                assert count>0 and response["status"]=="Completed"
                assert all(response[k]==case[k] for k in ["sourceSha256","expectedOutputSha256","fixtureSha256"])
                assert response.get("actualOutputSha256") == (None if job["lane"]=="compile" else case["expectedOutputSha256"])
                assert response.get("actualFilesSha256") == (None if job["lane"]=="compile" else case.get("expectedFilesSha256"))
                elapsed.append(response["elapsedTicks"]*1000/response["clockFrequency"]/count)
                cpu.append(row["externalProcessCpuTicks"]*1000/row["externalCpuFrequency"]/count)
            assert len(elapsed)==len(cpu)==7
            q=quantiles(elapsed,n=4,method="inclusive")
            stats[role]=dict(elapsed=median(elapsed),cpu=median(cpu),iqrPercent=100*(q[2]-q[0])/median(elapsed))
        def spread(role):
            a=stats[role]["elapsed"]; b=stats[role+"-control"]["elapsed"]
            return (max(a,b)/min(a,b)-1)*100
        def change(metric):
            pairs=[(stats[a][metric]/stats[b][metric]-1)*100
                for a in ("candidate","candidate-control")for b in ("reference","reference-control")]
            return min(pairs),max(pairs)
        row=dict(case=case["id"],lane=job["lane"],medianByWorker=stats,referenceControlPercent=spread("reference"),
            candidateControlPercent=spread("candidate"),elapsedChangePercent=change("elapsed"),cpuChangePercent=change("cpu"))
        warm_rows.append(row)
        print(job["lane"],case["id"],"elapsed",row["elapsedChangePercent"],"CPU",row["cpuChangePercent"],"spread",row["referenceControlPercent"],row["candidateControlPercent"])

(quiet/"summary.json").write_text(json.dumps(dict(source=identity["sourceRevision"],
    candidate=identity["candidate"], elapsedSeconds=warm["elapsedSeconds"],
    timedBatches=196, rows=warm_rows),indent=2)+"\n",encoding="utf-8")
