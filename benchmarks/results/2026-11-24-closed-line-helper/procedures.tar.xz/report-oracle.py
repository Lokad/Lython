from pathlib import Path
import json
import os
import subprocess

lab = Path(__file__).resolve().parent
sdk = Path.home()/'.dotnet11'
env = dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
helper = """def driver(lines):
    width = -1
    def words(line):
        nonlocal width
        width = len(line) * 2 + 1
        return line.lower().split()
"""
cases = [
    helper+"""    for line in lines:
        print([word for word in words(line)], width)
driver(('Étroite\u00a0Σ🙂', '  a  ', ''))
""",
    """builtin_length = len
def len(value):
    print('override', value)
    return 4
"""+helper+"""    for line in lines:
        print(tuple(word for word in words(line)), width)
    globals()['len'] = builtin_length
    for line in lines:
        print(tuple(word for word in words(line)), width)
driver(('A b',))
""",
    """class Span:
    def __len__(self):
        print('length')
        return 5
    def lower(self):
        print('lower')
        raise ValueError('conversion')
"""+helper+"""    for line in lines:
        try:
            for word in words(line):
                print(word)
        except ValueError as error:
            print(type(error).__name__, width)
driver((Span(),))
""",
    """class Length:
    def __mul__(self, other):
        print('multiply', other)
        return 2
def len(value):
    return Length()
"""+helper+"""    ready = words(lines[0])
    print(ready, width)
    ready.append('retained')
    print(words(lines[0]), ready)
driver(('UP Down',))
""",
    helper+"""    results = []
    for line in lines:
        for word in words(line):
            results.append(word)
            break
    print(results, width)
driver((' É F ', 'Á ΣΟΣ', '␣'))
""",
]
request=json.dumps(cases,ensure_ascii=False)
(lab/'report-oracle-input.json').write_text(request+'\n',encoding='utf-8',newline='\n')
probe=lab/'probe-candidate/LythonProbe.dll'
for mode in ('sync','async'):
    options=['--async'] if mode=='async' else []
    result = subprocess.run([sdk/'dotnet.exe',probe,'--batch-json','--compare-python','--python','C:/Python313/python.exe',*options],
        input=request,text=True,encoding='utf-8',capture_output=True,env=env,timeout=70)
    (lab/f'report-oracle-{mode}.jsonl').write_text(result.stdout,encoding='utf-8',newline='\n')
    rows=[json.loads(line) for line in result.stdout.splitlines()]
    assert result.returncode==0 and len(rows)==len(cases) and all(row['Matches'] and row['Lython']['Success'] for row in rows), (result.stdout,result.stderr)
    print(mode,len(rows),'candidate report cases match CPython')
