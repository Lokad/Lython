from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
previous=lab.with_name('prepared-closed-defaults-refined-20261124')
comparison=lab/'comparison'
quiet=comparison/'quiet'
out=repo/'benchmarks/results/2026-11-24-closed-line-helper'
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
sha=lambda data:hashlib.sha256(data).hexdigest()
digest=lambda path:sha(path.read_bytes())
terminal=read(quiet/'terminal-status.json')
receipt=terminal['receipt']
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode']=='0'
assert receipt['warmJobs']==7 and all(receipt[key] for key in (
    'complete','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert receipt['archiveSHA256']==digest(quiet/'observations.tar.xz')
identity=read(comparison/'identity.json')
summary=read(quiet/'summary.json')
assert summary['source']==identity['sourceRevision'] and summary['candidate']==identity['candidate']
assert summary['timedBatches']==196
assert [(row['case'],row['lane']) for row in summary['rows']]==[tuple(job) for job in read(comparison/'jobs.json')['warm']]
for role,files in identity['imageFiles'].items():
    assert len(files)==32 and {path.name:digest(path) for path in (lab/role).iterdir()}==files
    verified=read(comparison/(role+'-verify.json'))
    assert verified['caseCount']==6 and verified['state']=='Completed'
    assert verified['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert verified['launched']['library']['sha256']==files['Lokad.Lython.dll']
    assert read(lab/f'{role}-compiler-owner.json')['coreSHA256']==files['Lokad.Lython.dll']
for mode in ('sync','async'):
    assert (lab/'report-oracle-input.json').read_bytes()==(previous/'report-oracle-input.json').read_bytes()
    shutil.copyfile(previous/f'report-oracle-{mode}.jsonl',lab/f'report-reference-{mode}.jsonl')
    for file in (lab/f'report-oracle-{mode}.jsonl',lab/f'report-reference-{mode}.jsonl'):
        rows=[json.loads(line) for line in file.read_text(encoding='utf-8').splitlines()]
        assert len(rows)==5 and all(row['Compared'] and row['Matches'] and row['Lython']['Success'] for row in rows)
for platform in ('windows','ubuntu'):
    white=(lab/(platform+'-white.log')).read_text(encoding='utf-8-sig')
    public=(lab/('windows-public-broad.log' if platform=='windows' else 'ubuntu-public.log')).read_text(encoding='utf-8-sig')
    assert 'Passed:    87' in white and 'Passed:   639' in public
assert 'Expected: 181' in (lab/'windows-helper-failure.log').read_text(encoding='utf-8-sig')
routes=read(lab/'route-counts.json')
assert routes['diagnosticOnly'] and digest(lab/'candidate/Lokad.Lython.dll')!=routes['imageFiles']['Lokad.Lython.dll']
assert [row['routes'].get('cased-return words_from_line',0) for row in routes['rows']]==[12288,12288,1024,0,0,0]
patch=subprocess.check_output(['git','diff','--binary',identity['sourceRevision'],identity['candidate'],'--','src','tests'],cwd=repo)
assert patch and patch.count(b'diff --git ')==5
(lab/'measured.patch').write_bytes(patch)
out.mkdir(exist_ok=True)
for path in (comparison/'identity.json',quiet/'terminal-status.json',quiet/'summary.json',quiet/'observations.tar.xz',
        quiet/'storage-custody.json',lab/'allocation-summary-six.json',lab/'jit-summary.json',lab/'compaction.jsonl'):
    shutil.copyfile(path,out/path.name)
procedures=('prepare-comparison.py','prepare.py','quiet.py','summarize.py','archive.py','compact-archived-cores.py',
    'prepare-allocation.py','inspect-jit.py','prepare-route.py','routes.py','route-counts.json','candidate-runtime.asm',
    'reference-runtime.asm','measured.patch','report-oracle.py','report-oracle-input.json','report-oracle-sync.jsonl',
    'report-oracle-async.jsonl','report-reference-sync.jsonl','report-reference-async.jsonl','windows-helper-failure.log',
    'candidate-compiler-owner.json','reference-compiler-owner.json',
    'windows-white.log','windows-public-broad.log','ubuntu-white.log','ubuntu-public.log','test-ubuntu.sh',
    'windows-frozen-build.log','comparison/candidate-verify.json','comparison/reference-verify.json',
    'comparison/quiet/run.sh','comparison/quiet/collect.py','comparison/quiet/launch.log')
with tarfile.open(out/'procedures.tar.xz','w:xz') as archive:
    for name in procedures:archive.add(lab/name,arcname=name,recursive=False)
with tarfile.open(out/'procedures.tar.xz') as archive:
    assert {member.name:sha(archive.extractfile(member).read()) for member in archive} == {
        name:digest(lab/name) for name in procedures}
print('Archived B1608 with 196 verified timings, the exact source patch and a separate route diagnostic.')
