from pathlib import Path
import hashlib
import json
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
archive_root = repo / 'benchmarks/results'
sources = (
    ('prepared-closed-defaults-refined-20261124','prepared-closed-defaults-refined-b1607-20261124',
        '2026-11-24-prepared-closed-defaults/refined'),
    ('private-definition-call-20261124','private-definition-call-b1598-20261124','2026-11-24-private-definition-call'),
)
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
verified = []
for local, remote, archived in sources:
    folder = lab.with_name(local)
    evidence = archive_root / archived
    terminal = read(evidence/'terminal-status.json')
    receipt = terminal['receipt']
    assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode']=='0'
    assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['archivedAndVerifiedUnderLease']
    archive = evidence / 'observations.tar.xz'
    assert sha(archive.read_bytes()) == receipt['archiveSHA256']
    assert sha(subprocess.check_output(['git','show','origin/master:'+archive.relative_to(repo).as_posix()],cwd=repo)) == receipt['archiveSHA256']
    expected = read(folder/'comparison/identity.json')['imageFiles']['candidate']
    assert len(expected)==32 and {p.name:sha(p.read_bytes()) for p in (folder/'candidate').iterdir()}==expected
    verified.append(dict(directory=remote,expected=expected,archiveSHA256=receipt['archiveSHA256']))

body = '''
from pathlib import Path
import fcntl, hashlib, json, lzma, os, shutil, stat
root=Path('/home/lokad/lython-bench-checks').resolve()
sha=lambda data:hashlib.sha256(data).hexdigest()
minimum=12582912
with (root/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    before=shutil.disk_usage(root).free
    print(json.dumps(dict(freeBefore=before)),flush=True)
    for item in verified:
        if shutil.disk_usage(root).free>=minimum:break
        directory=root/item['directory']
        assert directory==directory.resolve() and directory.parent==root
        assert not (directory/'guest-fixtures').exists() and (directory/'exit-code.txt').read_text().strip()=='0'
        receipt=json.loads((directory/'archive-receipt.json').read_text())
        assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['archivedAndVerifiedUnderLease']
        assert sha((directory/'observations.tar.xz').read_bytes())==item['archiveSHA256']==receipt['archiveSHA256']
        image=directory/'candidate'
        assert image==image.resolve() and {p.name:sha(p.read_bytes()) for p in image.iterdir()}==item['expected']
        raw=image/'Lokad.Lython.dll'
        assert raw==raw.resolve() and stat.S_ISREG(raw.lstat().st_mode) and raw.stat().st_nlink==1
        data=raw.read_bytes()
        expected=item['expected'][raw.name]
        assert sha(data)==expected
        compressed=lzma.compress(data,preset=3)
        assert shutil.disk_usage(root).free >= len(compressed) + 1048576
        alternate=directory/'candidate-core.dll.xz'
        assert not alternate.exists()
        with alternate.open('xb') as package:
            package.write(compressed)
            package.flush()
            os.fsync(package.fileno())
        assert lzma.decompress(alternate.read_bytes())==data
        raw.unlink()
        print(json.dumps(dict(directory=directory.name,preserved=alternate.name,coreSHA256=expected,
              compressedSHA256=sha(compressed),rawBytes=len(data),storedBytes=len(compressed),
              freeAfter=shutil.disk_usage(root).free)),flush=True)
    assert shutil.disk_usage(root).free>=minimum
'''
remote = 'verified = '+repr(verified)+'\n'+body
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),
     '-o','BatchMode=yes','-o','ConnectTimeout=14','lokad@20.166.121.73','python3 -']
result = subprocess.run(ssh,input=remote.encode('utf-8'),capture_output=True,timeout=55)
(lab/'compaction.jsonl').write_bytes(result.stdout)
print(result.stdout.decode(),end='')
if result.returncode:print(result.stderr.decode(),end='')
result.check_returncode()
