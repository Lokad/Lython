from pathlib import Path
import ast
r=Path(__file__).parent;out=r/'refined/b658';out.mkdir()
code=(r/'prepare-vm.py').read_text(encoding='utf-8')
code=code.replace("r=Path(__file__).parent;out=r/'b657';old=r.parent/'cased-pipeline-r300/b655'", "base=Path(__file__).parent.parent;r=base/'refined';out=r/'b658';old=base.parent/'cased-pipeline-r300/b655'")
code=code.replace('b657','b658').replace('B657','B658').replace('R303/628ab680','refined R303/2f34a48f')
old="jobs=[['scripts.csv-invoice.large','warm'],['scripts.csv-invoice.large','compile-run'],['scripts.csv-invoice.large','compile'],['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.file-search.large','warm'],['scripts.report-render.large','warm']]"
new="jobs=[['scripts.csv-invoice.large','warm'],['scripts.csv-invoice.large','compile-run'],['scripts.text-summary-helpers.nonlocal-counter.large','warm']]"
assert old in code;code=code.replace(old,new).replace('len(jobs)==6','len(jobs)==3').replace("len(raw['jobs'])==6","len(raw['jobs'])==3").replace('jobs=6','jobs=3')
# The generator rewrites the old five-job collector/archive source directly.
code=code.replace("replace(\"len(raw['jobs'])==5\",\"len(raw['jobs'])==3\")", "replace(\"len(raw['jobs'])==5\",\"len(raw['jobs'])==3\")")
code=code.replace("replace('if job_index >= 2:', 'if job_index >= 3:')", "replace('if job_index >= 2:', 'if job_index >= 2:')")
code=code.replace("replace('< 420,','< 300,')", "replace('< 420,','< 180,')")
code=code.replace("status['receipt']['jobs']==6", "status['receipt']['jobs']==3").replace("status['receipt']['elapsedSeconds']<360", "status['receipt']['elapsedSeconds']<240").replace('six-job','three-job')
ast.parse(code);(r/'refined/prepare-vm.py').write_text(code,encoding='utf-8')
code=(r/'b657/launch.py').read_text(encoding='utf-8').replace('b657','b658').replace('B657','B658').replace('RuntimeMaxSec=360','RuntimeMaxSec=240').replace('seconds=240','seconds=150').replace('ownerSeconds=360','ownerSeconds=240').replace('observationSeconds=240','observationSeconds=150')
ast.parse(code);(out/'launch.py').write_text(code,encoding='utf-8')
