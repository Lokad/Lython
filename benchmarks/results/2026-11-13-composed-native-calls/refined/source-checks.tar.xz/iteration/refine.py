from pathlib import Path
import hashlib,json
r=Path(__file__).parent;identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['sources'].items())
p=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs');s=p.read_text(encoding='utf-8')
start=s.index('                var function = target as PyExecutableFunction;');end=s.index('                else if (call.HasReceiver && Values[start] is PyDict dictionary)',start)
block=s[start:end]
body=block[:block.index('                else if (!call.IsPositionalOnly) return false;')]
body=body.replace('                if (function is not null && function.CanStartInline)\n                {','                if (function is null || !function.CanStartInline) return false;')
# Remove the former enclosing conditional's closing brace, keeping nested entry cleanup.
assert body.endswith('                }\n');body=body[:-18]
body='\n'.join(line[4:]if line.startswith('    ')else line for line in body.splitlines())+'\n'
method='''        private bool CallFunction(ExecutableCallSite call, int start, object target, out object result)
        {
            result = PyNone.Instance;
'''+body+'''            return true;
        }

'''
s=s[:start]+'''                if (!call.IsPositionalOnly)
                {
                    if (!CallFunction(call, start, target, out result)) return false;
                }
'''+s[end:].replace('                else if (call.HasReceiver && Values[start] is PyDict dictionary)','                else if (call.HasReceiver && Values[start] is PyDict dictionary)',1)
old='''                    if (call.ArgumentCount != 1 || call.HasReceiver) return false;
                    var argument = Values[start + call.ArgumentOffset];
                    var operation = SelectNativeUnaryOperation(target, argument, out var closed);
                    if (operation is null || !closed) return false;
                    result = InvokeSingleInput(argument, operation, call.CallSpan, _scope);'''
new='''                    var argument = call.ArgumentCount == 1 && !call.HasReceiver
                        ? Values[start + call.ArgumentOffset] : null;
                    var operation = argument is not null ? SelectNativeUnaryOperation(target, argument, out var closed) : null;
                    if (operation is not null && closed)
                        result = InvokeSingleInput(argument!, operation, call.CallSpan, _scope);
                    else if (!CallFunction(call, start, target, out result)) return false;'''
assert s.count(old)==1;s=s.replace(old,new)
anchor='        private bool TryCell(int slot, out ExecutableCell cell)';assert s.count(anchor)==1
s=s.replace(anchor,method+anchor);p.write_text(s,encoding='utf-8',newline='\n')
print('R303 refinement: existing native receiver/unary operations precede user-function selection; composed handoff unchanged.',flush=True)
