from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
base=Path(__file__).parent;r=base/'refined';r.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
initial=json.loads((base/'candidate-identity.json').read_text(encoding='utf-8'))
names=subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True).splitlines();sources={p:sha(p)for p in names};assert len(sources)==571
assert [p for p in names if sources[p]!=initial['sources'][p]]==['src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs']
shutil.copytree(base/'reference',r/'reference',copy_function=os.link)
shutil.copytree(r/'reference',r/'candidate',copy_function=os.link)
(r/'candidate/Lokad.Lython.dll').unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'candidate/Lokad.Lython.dll');shutil.copyfile(r/'candidate/Lokad.Lython.dll',r/'candidate-core.dll')
assert sha(r/'reference/Lokad.Lython.dll')==initial['referenceSHA256']
identity=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),description='R303 composed calls with native receiver/unary operations preceding user-function selection; handoff unchanged',sources=sources,coreSHA256=sha(r/'candidate-core.dll'),referenceSHA256=initial['referenceSHA256'],initialCandidateSHA256=initial['coreSHA256'])
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as archive:
 for p in sources:archive.add(p,arcname=p)
shutil.copytree(base/'tool',r/'tool',copy_function=os.link)
os.link(base/'catalog.json',r/'catalog.json')
code=(base/'diagnostic.py').read_text(encoding='utf-8').replace("r.parent/'bulk-utf16-r276", "r.parent.parent/'bulk-utf16-r276").replace('seven full scripts','eight full scripts')
(r/'diagnostic.py').write_text(code,encoding='utf-8')
code=(base/'summarize.py').read_text(encoding='utf-8').replace("r.parent/'direct-range-r293", "r.parent.parent/'direct-range-r293")
(r/'summarize.py').write_text(code,encoding='utf-8')
print('Refined R303 exact core',identity['coreSHA256'],'reference',identity['referenceSHA256'],flush=True)
