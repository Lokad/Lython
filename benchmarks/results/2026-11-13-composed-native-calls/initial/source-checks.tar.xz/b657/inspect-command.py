from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 paths=[base/'cased-pipeline-b655-20261113/observations.tgz',base/'invoice-cpu-b656-20261113/observations.tgz']
 rows=[]
 for p in paths:
  s=p.lstat();assert p.resolve()==p and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_nlink==1
  rows.append(dict(path=str(p.relative_to(base)),bytes=s.st_size,allocatedBytes=s.st_blocks*512,inode=s.st_ino,device=s.st_dev,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
 print(json.dumps(dict(freshIdleLease=True,freeBytes=shutil.disk_usage(base).free,files=rows)))
