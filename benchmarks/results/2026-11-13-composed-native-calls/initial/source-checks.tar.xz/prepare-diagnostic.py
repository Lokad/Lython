from pathlib import Path
import json,os,shutil,subprocess
r=Path(__file__).parent;old=r.parent/'call-lifecycle-r301'
data=json.loads((old/'catalog.json').read_text(encoding='utf-8'))
print('Existing complete cases:',[c['id']for c in data['cases']],flush=True)
invoice=json.loads((r.parent/'invoice-workload-r302/invoice.json').read_text(encoding='utf-8'))
data['cases'].append(next(c for c in invoice['cases']if c['id']=='scripts.csv-invoice.large'))
assert len(data['cases'])==8
(r/'catalog.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
shutil.copytree(old/'tool',r/'tool',ignore=shutil.ignore_patterns('bin','obj'))
p=r/'tool/Program.cs';source=p.read_text(encoding='utf-8').replace('cases.Length != 7','cases.Length != 8').replace('Require existing seven complete','Require existing eight complete').replace('seven complete unchanged fixtures','eight complete unchanged fixtures').replace('R289 refined ordered final slots; native graph/proof/shape and argument-wrapper metadata removed; record caches preserved; private span tail cleared only at transfer','R303 composed native calls reuse final slots; prepared descendants transfer once to existing runner; no duplicate argument/workspace transport for completed helpers')
p.write_text(source,encoding='utf-8')
sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';'+env['PATH']
with(r/'build-diagnostic.log').open('w',encoding='utf-8')as log:done=subprocess.run([str(sdk/'dotnet.exe'),'build',str(r/'tool/complete-jobs.csproj'),'-c','Release','--disable-build-servers','-m:1'],env=env,stdout=log,stderr=subprocess.STDOUT)
print('Diagnostic build',done.returncode,(r/'build-diagnostic.log').read_text(encoding='utf-8')[-1800:],flush=True);assert done.returncode==0
for name in ['diagnostic.py','summarize.py']:shutil.copyfile(old/name,r/name)
