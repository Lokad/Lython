from pathlib import Path
import hashlib,json,subprocess,tarfile
r=Path(__file__).parent;out=r/'b657';out.mkdir()
local=r.parent/'cased-pipeline-r300/b655/observations.tgz'
print('B655 local original archive',local.stat().st_size,hashlib.sha256(local.read_bytes()).hexdigest(),flush=True)
for p in [r/'candidate-core.dll',r/'catalog.json',r.parent/'invoice-workload-r302/b656/catalog.json']:print(p.name,p.stat().st_size,flush=True)
code='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 paths=[base/'cased-pipeline-b655-20261113/observations.tgz',base/'invoice-cpu-b656-20261113/observations.tgz']
 rows=[]
 for p in paths:
  s=p.lstat();assert p.resolve()==p and stat.S_ISREG(s.st_mode)and s.st_uid==os.getuid()and s.st_nlink==1
  rows.append(dict(path=str(p.relative_to(base)),bytes=s.st_size,allocatedBytes=s.st_blocks*512,inode=s.st_ino,device=s.st_dev,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
 print(json.dumps(dict(freshIdleLease=True,freeBytes=shutil.disk_usage(base).free,files=rows)))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True)
(out/'inspect-command.py').write_text(code,encoding='utf-8');assert done.returncode==0,done.stderr
(out/'space-inspection.json').write_text(done.stdout,encoding='utf-8');print(done.stdout,flush=True)
