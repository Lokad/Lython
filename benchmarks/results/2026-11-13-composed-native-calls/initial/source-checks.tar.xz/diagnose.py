from pathlib import Path
import os,subprocess
r=Path(__file__).parent;env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';'+env['PATH']
args=['C:/Users/JoannesVermorel/.dotnet/tools/dotnet-stack.exe','report','--process-id','48248']
p=r/'stalled-net10-stacks.txt';assert not p.exists()
with p.open('w',encoding='utf-8')as log:
 try:done=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=30)
 except subprocess.TimeoutExpired:
  print('Owned stack report timed out; original log preserved.',flush=True)
 else:print('Owned stack report exit',done.returncode,flush=True)
