from pathlib import Path
import os,subprocess,sys
r=Path(__file__).parent;sdk=Path('C:/Users/JoannesVermorel/.dotnet11')
env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
phase,label=sys.argv[1:];jobs=[]
if phase=='build':
 jobs=[('solution',[str(sdk/'dotnet.exe'),'build','Lokad.Lython.slnx','-c','Release','--disable-build-servers','-m:1'])]
elif phase=='build-dev':
 jobs=[(suite,[str(sdk/'dotnet.exe'),'build',f'tests/{suite}/{suite}.csproj','-c','Release','-f','net11.0','--disable-build-servers','-m:1'])for suite in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']]
else:
 names={'internal':['ComposedNativeCall','SimpleFunctionExecutionBoundary','NativeFunctionRefund','NativeClosureSequence','ExecutableCallFrame','ExecutableCallTransfer','ExecutableStackAdmission','DeferredFunctionOwnership','FormattedStringExecutable','FunctionWorkspaceOwnership'],
 'public':['ComposedHelper','ComparisonFileWorker','OrderedFunctionContinuation','HelperContinuationLifetime','NativeClosureLifetime','FramedFunctionExecution','ReceiverFunctionEntry','ReceiverFunctionLifetime','PreparedFunctionDefaults','CooperativeCancellation','FirstRefusal','NestedFunctionLifetime','FunctionScenario','NumericReport','RecursionDepthScenario']}
 if phase=='new':names={k:[v[0]]for k,v in names.items()}
 for tfm in (['net11.0']if phase=='dev'else['net11.0','net10.0']):
  for suite,selected in names.items():
   project='Lokad.Lython.Tests'if suite=='internal'else'Lokad.Lython.PublicApi.Tests'
   filt='Category!=Stress&('+'|'.join('FullyQualifiedName~'+n for n in selected)+')'
   jobs.append((suite+'-'+tfm,[str(sdk/'dotnet.exe'),'test',f'tests/{project}/{project}.csproj','-c','Release','-f',tfm,'--no-build','--disable-build-servers','--filter',filt,'--logger','console;verbosity=normal','--blame-hang-timeout','45s','--blame-hang-dump-type','none','--results-directory',str(r/f'results-{phase}-{suite}-{tfm}-{label}')]))
for name,args in jobs:
 p=r/f'{phase}-{name}-{label}.log';assert not p.exists()
 with p.open('w',encoding='utf-8',newline='\n')as log:done=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
 output=p.read_text(encoding='utf-8');print(p.name,'exit',done.returncode,output[-1500:],flush=True)
 if done.returncode or 'No test matches'in output:sys.exit(done.returncode or 1)
