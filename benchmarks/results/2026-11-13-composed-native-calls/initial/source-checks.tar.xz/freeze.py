from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;old=r.parent/'call-lifecycle-r301';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
reference=json.loads((old/'candidate-identity.json').read_text(encoding='utf-8'))
names=subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True).splitlines();sources={p:sha(p)for p in names};assert len(sources)==571
changed=[p for p in names if sources[p]!=reference['sources'][p]]
assert changed==['src/Lokad.Lython/Runtime/LythonRuntime.Executable.Calls.Invoke.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.Calls.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativePrefix.cs','src/Lokad.Lython/Runtime/PyExecutableFunction.cs']
shutil.copytree(old/'candidate',r/'reference',copy_function=os.link)
shutil.copytree(r/'reference',r/'candidate',copy_function=os.link)
(r/'candidate/Lokad.Lython.dll').unlink()
shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'candidate/Lokad.Lython.dll')
shutil.copyfile(r/'candidate/Lokad.Lython.dll',r/'candidate-core.dll')
assert sha(r/'reference/Lokad.Lython.dll')==reference['coreSHA256']
identity=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),description='R303 composed calls reuse native final slots; prepared descendants transfer to existing linear runner before suspension',sources=sources,changed=changed,coreSHA256=sha(r/'candidate-core.dll'),referenceSHA256=reference['coreSHA256'])
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as archive:
 for p in sources:archive.add(p,arcname=p)
print('R303 exact candidate frozen:',identity['coreSHA256'],'qualified reference:',identity['referenceSHA256'],flush=True)
