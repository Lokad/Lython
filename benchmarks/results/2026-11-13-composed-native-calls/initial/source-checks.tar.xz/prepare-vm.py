from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent;out=r/'b657';old=r.parent/'cased-pipeline-r300/b655'
source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in source['sources'].items())
root='/home/lokad/lython-bench-checks/composed-native-b657-20261113';oldroot='/home/lokad/lython-bench-checks/cased-pipeline-b655-20261113'
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision='Qualified fc2531b8/6b468bf1 versus uncommitted R303/628ab680 composed native calls; frozen production sources and common fec79 worker',coreSHA256={label:source['referenceSHA256']if label.startswith('reference')else source['coreSHA256']for label in ['reference','candidate','reference-control','candidate-control']},catalogSHA256=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest(),sourceIdentitySHA256=hashlib.sha256((r/'candidate-identity.json').read_bytes()).hexdigest(),productionSourceArchiveSHA256=hashlib.sha256((r/'candidate-sources.tar.xz').read_bytes()).hexdigest())
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
jobs=[['scripts.csv-invoice.large','warm'],['scripts.csv-invoice.large','compile-run'],['scripts.csv-invoice.large','compile'],['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.file-search.large','warm'],['scripts.report-render.large','warm']]
code=(old/'collect.py').read_text(encoding='utf-8').replace(oldroot,root)
start=code.index('jobs=');end=code.index('\nenv =',start)
code=code[:start]+'jobs='+repr(jobs)+'\nassert len(jobs)==6 and all(case in cases for case,lane in jobs)\n'+code[end:]
code=code.replace("purpose='Whole cased-text/range pipeline: private source ownership and borrowed final UTF8 replace per-word casing, small-word representation and capacity metadata; captured warm/fresh with CSV/search/report controls'","purpose='Composed native calls: complete invoice warm/fresh/compile, captured/native-search/report controls; fixed source-pair, no external ratio'")
code=code.replace('rounds=7','rounds=5').replace('range(7)','range(5)').replace('if job_index >= 2:', 'if job_index >= 3:').replace('< 420,','< 300,')
ast.parse(code);(out/'collect.py').write_text(code,encoding='utf-8',newline='\n')
code=(old/'archive-owned.py').read_text(encoding='utf-8').replace(oldroot,root).replace("len(raw['jobs'])==5","len(raw['jobs'])==6").replace('jobs=5','jobs=6')
ast.parse(code);(out/'archive-owned.py').write_text(code,encoding='utf-8',newline='\n')
(out/'run.sh').write_text('set -eu\nroot='+root+'\ntrap \'result=$?; printf "%s\\n" "$result" > "$root/exit-code.txt"\' EXIT\npython3 "$root/collect.py"\n',encoding='utf-8',newline='\n')
files={n:out/n for n in ['identity.json','collect.py','archive-owned.py','run.sh']}
files.update({'current-core.dll':r/'candidate-core.dll','source-identity.json':r/'candidate-identity.json','representative.json':r/'catalog.json','cpython-worker.py':old/'retrieved/cpython-worker.py'})
with tarfile.open(out/'payload.tgz','w:gz')as archive:
 for name,p in files.items():archive.add(p,arcname=name)
config=dict(root=root,unit='lython-b657-composed-native-20261113',sourceRoot='/home/lokad/lython-bench-checks/invoice-cpu-b656-20261113',identity=identity,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum(p.stat().st_size for p in files.values()))
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
code=(old/'retrieve.py').read_text(encoding='utf-8').replace('cased-pipeline-b655-20261113','composed-native-b657-20261113').replace('lython-b655-cased-pipeline-20261113','lython-b657-composed-native-20261113').replace("status['receipt']['jobs']==5","status['receipt']['jobs']==6").replace("status['receipt']['elapsedSeconds']<540","status['receipt']['elapsedSeconds']<360").replace('B655 five-job','B657 six-job')
ast.parse(code);(out/'retrieve.py').write_text(code,encoding='utf-8')
code=(old/'summarize.py').read_text(encoding='utf-8')
ast.parse(code);(out/'summarize.py').write_text(code,encoding='utf-8')
print('B657 prepared',len(jobs),'bounded jobs; staged',config['unpackedBytes'],'bytes; no deletion required given fresh observed VM space.',flush=True)
