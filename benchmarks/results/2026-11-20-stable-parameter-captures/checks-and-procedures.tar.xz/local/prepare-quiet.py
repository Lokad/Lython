import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile
from pathlib import Path

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
template = lab.parent / "private-callsite-preparation/rebased/quiet"
donor = lab.parent / "postponed-annotation-cpython/quiet"
q = lab / "quiet"
core = "Lokad.Lython.dll"


def read(path):
    return path.read_text(encoding="utf-8")


def load(path):
    return json.loads(read(path))


def emit(path, text):
    if path.suffix == ".py":
        compile(text, str(path), "exec")
    path.write_text(text, encoding="utf-8", newline="\n")


def save(path, value):
    emit(path, json.dumps(value, indent=2) + "\n")


def sha(content):
    return hashlib.sha256(content).hexdigest()


def file_sha(path):
    return sha(path.read_bytes())


def committed(path):
    return subprocess.check_output(["git", "cat-file", "blob", "0269120fc:" + path], cwd=repo)


def retire(canonical, expected_sha, cases):
    image = gzip.decompress(committed(canonical))
    assert sha(image) == expected_sha
    archives = {}
    paths = []
    for remote, role, result in cases:
        results = f"benchmarks/results/{result}"
        receipt = json.loads(committed(f"{results}/archive-receipt.json"))
        content = committed(f"{results}/observations.tgz")
        assert all(receipt[key] for key in ("complete", "allWorkersJoined", "guestFixturesRemoved", "archivedAndVerifiedUnderLease"))
        assert receipt["archiveSHA256"] == sha(content)
        archives[f"{remote}/observations.tgz"] = receipt["archiveSHA256"]
        paths.append(f"{remote}/{role}/{core}")
    return dict(archives=archives, paths=paths, bytes=len(image), links=len(paths),
                sha256=expected_sha, verifiedCanonicalGitImage=canonical)


index = load(lab / "identity.json")
assert index["reference"].startswith("0269120fc") and index["candidate"].startswith("fa48b107c")
old = load(template / "config.json")
donor_config = load(donor / "config.json")
donor_receipt = load(donor / "archive-receipt.json")
assert donor_receipt["complete"] and donor_receipt["archivedAndVerifiedUnderLease"]
assert donor_receipt["archiveSHA256"] == file_sha(donor / "observations.tgz")
source_files = donor_config["identity"]["imageFiles"]["candidate"]
protocol = donor_config["cpythonWorkerSHA256"]
assert index["pythonWorkerSHA256"] == protocol
manifest = lab / "representative.json"
assert file_sha(manifest) == index["catalogSHA256"]
for role, files in index["imageFiles"].items():
    assert len(files) == len(source_files) == 32
    assert set(files) == set(source_files)
    assert [n for n in files if files[n] != source_files[n]] == [core]
    assert {n: file_sha(lab / "frozen" / role / n) for n in files} == files
    verification = load(lab / f"{role}-verify.json")
    assert verification["state"] == "Completed"
    assert verification["catalogSha256"] == index["catalogSHA256"]

proposals = [
    retire("benchmarks/results/2026-11-20-callsite-preparation/measured-candidate-core.dll.gz",
           old["identity"]["coreSHA256"]["candidate"], [
               ("callsite-preparation-b1241-20261120", "candidate", "2026-11-20-callsite-preparation"),
               ("callsite-preparation-confirm-b1242-20261120", "candidate", "2026-11-20-callsite-preparation/confirmation"),
           ]),
    retire("benchmarks/results/2026-11-20-private-lexical-definition/measured-candidate-core.dll.gz",
           "bedd2f15165647ef3a929bf18ff91cc646499db0788938a38d08677b01ea4e4c", [
               ("lexical-definition-admission-b1227-20261120", "candidate", "2026-11-20-private-lexical-definition"),
               ("lexical-definition-confirmation-b1228-20261120", "candidate", "2026-11-20-private-lexical-definition/confirmation"),
           ]),
    retire("benchmarks/results/2026-11-20-abstract-join-transfer/measured-candidate-core.dll.gz",
           "d6ff431b665ebeb31887aabb55c648f3863c0fbb30b7bdf040379e11792e0b1f", [
               ("abstract-join-transfer-b1234-20261120", "candidate", "2026-11-20-abstract-join-transfer"),
               ("abstract-join-transfer-confirm-b1235-20261120", "candidate", "2026-11-20-abstract-join-transfer/confirmation"),
               ("format-map-keys-b1236-20261120", "reference", "2026-11-20-prepared-format-map-keys"),
               ("format-map-keys-b1237-20261120", "reference", "2026-11-20-prepared-format-map-keys/refinement"),
           ]),
]
root = "/home/lokad/lython-bench-checks/stable-parameter-captures-b1243-20261120"
unit = "lython-b1243-stable-parameter-captures-20261120"
q.mkdir()
images = index["imageFiles"]
identity = dict(sourceRevision=index["reference"] + " versus " + index["candidate"],
                purpose="Eliminate cells for stable captured parameters in complete nested factories",
                catalogSHA256=index["catalogSHA256"], imageFiles=images, normalAdapterPin="0.4.0",
                coreSHA256={role + suffix: names[core] for role, names in images.items() for suffix in ("", "-control")})
save(q / "identity.json", identity)
jobs = [(row["id"], "warm") for row in load(manifest)["cases"]]
assert len(jobs) == 4 and jobs[-1][0] == "scripts.csv-invoice.large"
for name in ("collect.py", "archive-owned.py", "run.sh", "retrieve.py"):
    content = read(template / name).replace(old["root"], root).replace(old["unit"], unit)
    if name == "collect.py":
        start = content.index("\njobs = ")
        end = content.index("\nassert len(jobs)", start)
        content = content[:start] + "\njobs = " + repr(jobs) + content[end:]
    emit(q / name, content)
assert b"\r" not in (q / "run.sh").read_bytes()

parts = ["identity.json", "representative.json", "collect.py", "archive-owned.py", "run.sh"]
shutil.copyfile(manifest, q / "representative.json")
for role in ("reference", "candidate"):
    (q / role).mkdir()
    shutil.copyfile(lab / "frozen" / role / core, q / role / core)
    parts.append(f"{role}/{core}")
with tarfile.open(q / "payload.tgz", "w:gz") as payload:
    for part in parts:
        payload.add(q / part, arcname=part)
config = dict(root=root, unit=unit, source=donor_config["root"], sourceRole="candidate", sourceFiles=source_files,
              sourceCatalogSHA256=donor_config["catalogSHA256"], protocolSHA256=protocol, catalogSHA256=index["catalogSHA256"],
              identity=identity, retireGroups=proposals, donorArchiveSHA256=donor_receipt["archiveSHA256"],
              payloadBytes=(q / "payload.tgz").stat().st_size, payloadSHA256=file_sha(q / "payload.tgz"),
              unpackedBytes=sum((q / part).stat().st_size for part in parts))
save(q / "config.json", config)
content = read(template / "remote-launch.py")
start = content.index("\nc=") + 1
end = content.index("\nb=Path(", start)
content = (content[:start] + "c=" + repr(config) + content[end:]).replace("lython-b1241-fixtures", "lython-b1243-fixtures")
assert "proof['archives']" in content and "176160768+c['unpackedBytes']+64*1024*1024" in content
emit(q / "remote-launch.py", content)
launch = read(template.parent / "launch.py").replace("Call-site preparation comparison", "Stable parameter capture comparison")
emit(lab / "launch.py", launch)
