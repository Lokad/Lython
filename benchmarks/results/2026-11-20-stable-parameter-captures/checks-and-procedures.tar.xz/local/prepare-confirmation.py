from pathlib import Path
import hashlib
import json
import tarfile

base = Path(__file__).resolve().parent
first = base / "quiet"
lab = base / "confirmation"
q = lab / "quiet"
q.mkdir(parents=True)


def read(path):
    return path.read_text(encoding="utf-8")


def load(path):
    return json.loads(read(path))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def emit(path, text):
    if path.suffix == ".py":
        compile(text, str(path), "exec")
    path.write_text(text, encoding="utf-8", newline="\n")


prior = load(first / "config.json")
receipt = load(first / "archive-receipt.json")
assert receipt["complete"] and receipt["allWorkersJoined"] and receipt["guestFixturesRemoved"]
assert receipt["archivedAndVerifiedUnderLease"] and receipt["archiveSHA256"] == sha(first / "observations.tgz")
summary = load(base / "quiet-summary.json")
job = next(row for row in summary["rows"] if row["case"] == "scripts.annotated-rule-closures.observed.postponed")
assert job["lane"] == "warm" and min(job["cpuChangePercent"]) < 0 < max(job["cpuChangePercent"])
jobs = [(row["case"], "warm") for row in reversed(summary["rows"][:3])]
assert all(any(row["case"] == case and row["lane"] == lane for row in summary["rows"]) for case,lane in jobs)
location = "/home/lokad/lython-bench-checks/stable-parameter-captures-confirm-b1244-20261120"
unit = "lython-b1244-stable-parameter-captures-confirm-20261120"
emit(q / "identity.json", read(first / "identity.json"))
for name in ("collect.py", "run.sh", "archive-owned.py", "retrieve.py"):
    text = read(first / name).replace(prior["root"], location).replace(prior["unit"], unit)
    if name == "collect.py":
        a = text.index("\njobs = ")
        b = text.index("\nassert len(jobs)", a)
        text = text[:a] + "\njobs = " + repr(jobs) + text[b:]
        text = text.replace("len(jobs)==4", "len(jobs)==3")
        text = text.replace("if job_index % 2 == 0: labels.reverse()", "if job_index % 2 != 0: labels.reverse()")
        text = text.replace("accumulate 12 seconds", "accumulate 22 seconds").replace("warmupSeconds=12", "warmupSeconds=22")
        text = text.replace("min(warmed)<12", "min(warmed)<22").replace("warmed[i]>=12", "warmed[i]>=22")
        text = text.replace("targetBatchSeconds=.8", "targetBatchSeconds=1.0").replace("counts[i]*.8/", "counts[i]/")
    if name in ("archive-owned.py", "retrieve.py"):
        text = text.replace("==4", "==3").replace("jobs=4,", "jobs=3,")
    emit(q / name, text)
assert b"\r" not in (q / "run.sh").read_bytes()
assert "len(raw['jobs'])==3" in read(q / "archive-owned.py")
assert "status['receipt']['jobs']==3" in read(q / "retrieve.py")
parts = ("identity.json", "collect.py", "archive-owned.py", "run.sh")
payload = q / "payload.tgz"
with tarfile.open(payload, "w:gz") as bundle:
    for name in parts:
        bundle.add(q / name, arcname=name)
config = dict(prior, root=location, unit=unit, source=prior["root"], sourceRole="reference",
              sourceFiles=prior["identity"]["imageFiles"]["reference"], sourceCatalogSHA256=prior["catalogSHA256"],
              retireGroups=[], donorArchiveSHA256=receipt["archiveSHA256"],
              payloadBytes=payload.stat().st_size, payloadSHA256=sha(payload),
              unpackedBytes=sum((q / name).stat().st_size for name in parts))
emit(q / "config.json", json.dumps(config, indent=2) + "\n")
text = read(first / "remote-launch.py")
a = text.index("\nc=") + 1
b = text.index("\nb=Path(", a)
text = text[:a] + "c=" + repr(config) + text[b:]
text = text.replace("os.link(source/c['sourceRole']/n,p)", "os.link(source/role/n,p)")
text = text.replace("lython-b1243-fixtures", "lython-b1244-fixtures")
emit(q / "remote-launch.py", text)
emit(lab / "launch.py", read(base / "launch.py").replace("seconds=328", "seconds=390").replace("before 328", "before 390"))
emit(lab / "summarize.py", read(base / "summarize.py").replace("len(raw['jobs'])==4", "len(raw['jobs'])==3"))
print("Prepared the three reversed factory lanes using both exact images.")
