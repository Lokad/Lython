import hashlib
import json
import os
import shutil
import statistics
import subprocess
from pathlib import Path

lab = Path(__file__).resolve().parent
manifest = lab / "representative.json"
identity = json.loads((lab / "identity.json").read_text(encoding="utf-8"))
sdk = Path.home() / ".dotnet11"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk)+os.pathsep+os.environ["PATH"])
donor = lab.parent / "private-callsite-preparation/rebased/frozen/reference"
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(manifest) == identity["catalogSHA256"]
payloads = {}
for role, files in identity["imageFiles"].items():
    image = lab / "compile-probe" / role
    assert len(files) == 32
    image.mkdir(parents=True)
    for name in files:
        shutil.copyfile(lab / "frozen" / role / name, image / name)
    assert {name: sha(image / name) for name in files} == files
    for path in donor.glob("CompileAllocation.*"):
        shutil.copyfile(path, image / path.name)
    measured = subprocess.check_output([sdk / "dotnet.exe", image / "CompileAllocation.dll", manifest], env=env, timeout=90)
    (lab / f"{role}-compile-allocation.json").write_bytes(measured)
    payloads[role] = json.loads(measured)
    assert {name: sha(image / name) for name in files} == files
for before, after in zip(payloads["reference"]["rows"], payloads["candidate"]["rows"], strict=True):
    assert before["id"] == after["id"]
    print(before["id"], before, after)
