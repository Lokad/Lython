#!/usr/bin/env bash
set -euo pipefail
repo=/mnt/d/code/Lython
cd "$repo/.git/agent-worktrees/stable-parameter-captures"
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs="$repo/.git/agent-notes/review-20261031/private-stable-parameter-captures"
dotnet test tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj -c Release -f net10.0 --filter 'FullyQualifiedName~StableParameterCapture|FullyQualifiedName~CapturedScalarObservation|FullyQualifiedName~NativeClosureSequence|FullyQualifiedName~AsyncExecutableFunction|FullyQualifiedName~CompiledGeneratorExpressionTests' -v quiet 2>&1 | tee "$logs/white-ubuntu.log"
dotnet test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --filter 'FullyQualifiedName~Closure|FullyQualifiedName~Nonlocal|FullyQualifiedName~Generator|FullyQualifiedName~Comprehension|FullyQualifiedName~PostponedAnnotation|FullyQualifiedName~AsyncInvocationOwnership|FullyQualifiedName~AsyncMidFlightCancellation|FullyQualifiedName~DeleteExecution' -v quiet 2>&1 | tee "$logs/public-ubuntu.log"
