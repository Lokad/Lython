set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab=$1
filter='(FullyQualifiedName~RangeSlotTransport|FullyQualifiedName~IntegerAliasOwnership|FullyQualifiedName~FloatConversionSlot|FullyQualifiedName~FunctionDefault)&Category!=Stress'
dotnet test "tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj" -c Release -f net10.0 --no-build --artifacts-path "$lab/linux" --filter "$filter"
