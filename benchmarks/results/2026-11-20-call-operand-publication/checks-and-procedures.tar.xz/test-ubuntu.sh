set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab=$1
filter='(FullyQualifiedName~Native|FullyQualifiedName~CallBinding|FullyQualifiedName~CallArgument|FullyQualifiedName~ExecutableCall|FullyQualifiedName~DirectLength|FullyQualifiedName~DirectIntegerText|FullyQualifiedName~DirectFloatText|FullyQualifiedName~CooperativeCancellation|FullyQualifiedName~AsyncMidFlightCancellation|FullyQualifiedName~AdmissionFailureCommand)&Category!=Stress'
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="$lab/$suite-continuation-ubuntu.log"
    dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 --artifacts-path "$lab/linux" --filter "$filter" >"$log" 2>&1 || { tail -n 45 "$log"; exit 1; }
    tail -n 8 "$log"
done
