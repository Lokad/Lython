set -eu
root=/home/lokad/lython-bench-checks/flat-operands-b207-20261104
dotnet=/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet
export DOTNET_ROOT=/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148
export TMPDIR=/dev/shm
exec 9>/home/lokad/lython-bench-checks/comparison-vm.lock
flock -n 9
"$dotnet" "$root/candidate/Lokad.Lython.Benchmarks.dll" --compare check-machine --out "$root/report-corrected-machine-before.json"
python3 -c 'import json,sys;assert json.load(open(sys.argv[1]))["gate"]["quiet"]' "$root/report-corrected-machine-before.json"
python3 "$root/profile-report.py" "$root/perf-report-async-corrected"
"$dotnet" "$root/candidate/Lokad.Lython.Benchmarks.dll" --compare check-machine --out "$root/report-corrected-machine-after.json"
python3 -c 'import json,sys;assert json.load(open(sys.argv[1]))["gate"]["quiet"]' "$root/report-corrected-machine-after.json"
for case in before candidate; do
 python3 "$root/analyze-cpu-guest.py" "$root/perf-report-async-corrected/$case"
done
