from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess,time
root=Path('/home/lokad/lython-bench-checks/flat-operands-b207-20261104')
dotnet=Path('/home/lokad/lython-bench-toolchains/dotnet/11.0.100-rc.3.26522.148/dotnet')
before=Path('/home/lokad/lython-bench-checks/compact-fragments-b205-20261104/metadata/candidate/Lokad.Lython.Benchmarks.dll')
original=root/'confirmation/confirmation.json'
record=json.loads(original.read_text())
assert not record['complete'] and len(record['jobs'])==12
assert all(j['workersJoinedAndFixturesRemoved'] for j in record['jobs'])
assert 'Require five complete jobs and three fixed-text controls.' in (root/'confirmation/allocation/sync/stderr.txt').read_text()
env=os.environ.copy();env['DOTNET_ROOT']=str(dotnet.parent);env['TMPDIR']='/dev/shm'
with (root.parent/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    started=time.monotonic()
    assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]omplete-jobs.dll'],capture_output=True).returncode==1
    assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
    out=root/'allocation-correction';out.mkdir(exist_ok=False)
    catalog=root/'allocation-catalog.json'
    shutil.copyfile('/home/lokad/lython-bench-checks/compact-fragments-b205-20261104/metadata/catalog.json',catalog)
    assert len(json.loads(catalog.read_text())['cases'])==8
    def gate(name):
        subprocess.run([str(dotnet),str(before),'--compare','check-machine','--out',str(out/name)],env=env,check=True)
        assert json.loads((out/name).read_text())['gate']['quiet']
    gate('machine-before.json')
    for api in ['sync','async']:
        dest=out/api;dest.mkdir()
        shutil.copyfile('/home/lokad/lython-bench-checks/prepared-format-layout-b160-20261103/hash-witness.json',dest/'hash-witness.json')
        with (dest/'measurements.json').open('w') as result,(dest/'stderr.txt').open('w') as errors:
            subprocess.run([str(dotnet),'/home/lokad/lython-bench-checks/fixed-text-construction-b194-20261104/tool/complete-jobs.dll',str(before),str(root/'candidate/Lokad.Lython.Benchmarks.dll'),str(catalog),str(dest/'hash-witness.json'),'reverse','warm',api],env=env,stdout=result,stderr=errors,check=True)
        a=json.loads((dest/'measurements.json').read_text())
        assert len(a['observations'])==8 and all(a[k] for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
        assert not (dest/'stderr.txt').read_text()
        print('corrected allocation',api,'complete',flush=True)
    time.sleep(5)
    gate('machine-after.json')
    assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]omplete-jobs.dll'],capture_output=True).returncode==1
    assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
    receipt=dict(timingJobsComplete=12,timingReplayed=False,originalCollectionComplete=False,
        originalFailure='Added ninth ordinary-call control rejected by the fixed eight-case allocation diagnostic before measurement; all timed workers had already joined.',
        correction='Only isolated allocation resumed with the unchanged eight-case catalog and exact frozen core images; no timing replay.',
        originalEndingGateMissing=True,continuationQuietBeforeAndAfter=True,allGoldensAndBalances=True,allWorkersJoined=True,
        allocationCasesPerApi=8,callControlAllocationMeasured=False,continuationSeconds=time.monotonic()-started)
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt),flush=True)
