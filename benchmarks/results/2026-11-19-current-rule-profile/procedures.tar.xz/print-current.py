from pathlib import Path
import json
lab=Path(__file__).resolve().parent
data=json.loads((lab/'attribution.json').read_text(encoding='utf-8'))
for row in data['rows']:
  focus=row['guestRuntimeFocus']
  print(row['label'], 'samples', row['sampleCount'], 'runtime', row['guestRuntimeAncestry'],
        'unknown', row['unmappedLeafSamples'])
  print('nearest runtime', row['nearestRuntimeMethods'][:15])
  print('admission by caller', row['nearestReserveCallers'][:10])
  print('overlapping counts', {k:focus[k] for k in ('definition execution','function metadata',
      'function defaults','live argument frame','closure retention','frame operand storage')})