from pathlib import Path
import ast, hashlib, json, os, subprocess, tarfile

lab=Path(__file__).resolve().parent
prior=lab.parent/'retained-rule-profile-r664'
cp=lab.parent/'retained-lexical-cpython-b1122'
donor=lab.parent/'proven-record-keywords-r694'
read=lambda p:p.read_text(encoding='utf-8-sig')
load=lambda p:json.loads(read(p))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,text):
    if name.endswith('.py'): ast.parse(text)
    (lab/name).write_text(text,encoding='utf-8',newline='\n')
def save(name,value): write(name,json.dumps(value,indent=2,ensure_ascii=False)+'\n')

old=load(prior/'config.json')
stage=load(donor/'quiet/config.json')
pair=load(donor/'frozen-identity.json')
revision=pair['referenceCommit']
assert revision.startswith('40ab5132a')
files=pair['images']['reference']
frozen=donor/'frozen/reference'
assert len(files)==32 and stage['identity']['imageFiles']['reference']==files
assert {name:sha(frozen/name) for name in files}==files
catalog=load(cp/'representative.json')
jobs=[('rules','scripts.rule-default-closures','warm'),
      ('annotated','scripts.annotated-rule-closures','warm'),
      ('captured','scripts.captured-rule-closures','warm')]
labels=[label for label,_,_ in jobs]
catalog['cases']=[next(case for case in catalog['cases'] if case['id']==name) for _,name,_ in jobs]
save('catalog.json',catalog)
identity=dict(sourceRevision=revision,purpose='B1125 rule CPU attribution after lexical and ownership consolidation',
    coreSHA256=dict(candidate=files['Lokad.Lython.dll']),imageFiles=dict(candidate=files),
    catalogSHA256=sha(lab/'catalog.json'),diagnosticOnly=True,publicationHeld=True)
save('identity.json',identity)
root='/home/lokad/lython-bench-checks/current-rule-profile-b1125-20261119'
unit='lython-b1125-current-rule-profile-20261119'
for name in ('ops-profile.py','collect.py','launch.py','retrieve.py','run.sh','analyze.py'):
    source=read(prior/name).replace(old['root'],root)
    source=source.replace('R664/B1093 06b40a712 rule-definition CPU attribution','R695/B1125 current rule CPU attribution')
    if name=='ops-profile.py':
        assert repr(jobs) in source and 'elapsed >= 8' in source
    if name=='launch.py':
        source=source.replace('Current retained call CPU attribution','Current rule CPU attribution after consolidation')
    write(name,source)
assert not b'\r' in (lab/'run.sh').read_bytes()

sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
with (lab/'verify.log').open('wb') as log:
    subprocess.run([dotnet,frozen/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',lab/'catalog.json',
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',Path.cwd()/'benchmarks/cpython-worker.py',
        '--out',lab/'verify.json'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=100,check=True)
result=load(lab/'verify.json')
assert result['state']=='Completed' and result['catalogSha256']==identity['catalogSHA256']
assert {name:sha(frozen/name) for name in files}==files
print('Verified the complete retained image and three CPython workload goldens.')

names=('identity.json','catalog.json','ops-profile.py','collect.py','run.sh')
payload=lab/'payload.tgz'
with tarfile.open(payload,'w:gz') as archive:
    for name in names: archive.add(lab/name,arcname=name)
config=dict(root=root,unit=unit,source=stage['root'],sourceFiles=files,sourceCatalogSHA256=stage['catalogSHA256'],
    catalogSHA256=identity['catalogSHA256'],identity=identity,retireGroups=[],payloadBytes=payload.stat().st_size,
    payloadSHA256=sha(payload),unpackedBytes=sum((lab/name).stat().st_size for name in names))
save('config.json',config)
source=read(prior/'remote-launch.py')
a,b=source.index('\nc=')+1,source.index('\nb=Path(')
source=(source[:a]+'c='+repr(config)+source[b:]).replace('lython-b1093-fixtures','lython-b1125-fixtures')
assert source.count("source/'candidate'/n")==2
source=source.replace("source/'candidate'/n","source/'reference'/n")
write('remote-launch.py',source)