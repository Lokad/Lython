from pathlib import Path
import hashlib, json, shutil, tarfile

lab=Path(__file__).resolve().parent
previous=lab.with_name("current-rule-attribution-20261124")
external=lab.with_name("forwarded-integers-cpython-20261124")
external_out=external/"external"
donor=lab.with_name("borrow-forwarded-integers-20261124")
donor_out=donor/"comparison/quiet"
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,s):p.write_text(s,encoding="utf-8",newline="\n")
def save(p,x):write(p,json.dumps(x,indent=2,ensure_ascii=False)+"\n")
ident=read(external_out/"identity.json")
receipt=read(donor_out/"terminal-status.json")["receipt"]
assert receipt["complete"] and receipt["archivedAndVerifiedUnderLease"] and sha(donor_out/"observations.tar.xz")==receipt["archiveSHA256"]
assert ident["sourceRevision"].startswith("d6a168491") and ident["sourceImageArchiveSHA256"]==receipt["archiveSHA256"]
assert ident["imageFiles"]["candidate"]==read(donor_out/"identity.json")["imageFiles"]["candidate"]
assert {p.name:sha(p) for p in (donor/"candidate").iterdir()}==ident["imageFiles"]["candidate"]
ident.update(profiles=[
    ("defaulted-warm","scripts.rule-default-closures","candidate"),
    ("defaulted-through","scripts.rule-default-closures","candidate"),
    ("eager-through","scripts.annotated-rule-closures","candidate"),
],purpose="Locate remaining whole-script execution and setup costs after integer operand forwarding",
    donorArchiveSHA256=receipt["archiveSHA256"],profileCatalogSHA256=sha(external_out/"representative.json"))
save(lab/"identity.json",ident)
shutil.copyfile(external_out/"representative.json",lab/"catalog.json")
shutil.copyfile(external_out/"candidate-verify.json",lab/"candidate-verification.json")
shutil.copyfile(previous/"run.sh",lab/"run.sh")
assert b"\r" not in (lab/"run.sh").read_bytes()
ops=(previous/"ops-profile.py").read_text(encoding="utf-8")
ops=ops.replace('lane = "warm"','lane = "compile-run" if name.endswith("-through") else "warm"')
collect=(previous/"collect.py").read_text(encoding="utf-8")
collect=collect.replace("forwarded-positional-framed-b1624-20261124/candidate","borrow-forwarded-integers-b1631-20261124/candidate")
collect=collect.replace("b1627-fixtures","b1634-fixtures").replace(">= 6*1024*1024",">= 3840*1024")
launcher=(previous/"quiet.py").read_text(encoding="utf-8")
launcher=launcher.replace("current-rule-attribution-b1627-retry-20261124","forwarded-rule-cpu-b1634-20261124")
launcher=launcher.replace("lython-b1627-current-rule-attribution-retry-20261124","lython-b1634-forwarded-rule-cpu-20261124")
launcher=launcher.replace("forwarded-positional-framed-20261124","borrow-forwarded-integers-20261124")
launcher=launcher.replace('checked["caseCount"]==2','checked["caseCount"]==3')
launcher=launcher.replace(',"reference-verification.json"',"").replace(",'reference-verification.json'","")
launcher=launcher.replace('    staging=f"""', '    duplicates=json.loads((lab/"verified-raw-replicas.json").read_text(encoding="utf-8"))\n    staging=f"""')
launcher=launcher.replace(' assert free >= 7*1024*1024, free\n assert not root.exists()\n custody=dict(freeBefore=free)', ''' assert not root.exists()
 plans=[]; available=free
 for row in {duplicates!r}:
  if available>=4*1024*1024:break
  prior=root.parent/row['location']
  raw=prior/'confirmation/confirmation.json'
  archive=prior/'observations.tar.xz'
  marker=prior/'archive-receipt.json'
  if not raw.is_file():continue
  assert raw.resolve()==raw and raw.is_relative_to(root.parent) and raw.stat().st_nlink==1
  if (prior/'guest-fixtures').exists() or not marker.is_file():continue
  info=json.loads(marker.read_text())
  if not info.get('allWorkersJoined') or not info.get('archivedAndVerifiedUnderLease'):continue
  if raw.stat().st_size!=row['bytes'] or not archive.is_file():continue
  sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
  if sha(archive)!=row['archiveSHA256'] or sha(raw)!=row['rawSHA256']:continue
  plans.append((row,raw))
  available+=raw.stat().st_blocks*512
 assert available>=4*1024*1024,(free,available)
 for _,raw in plans:raw.unlink()
 custody=dict(freeBefore=free,verifiedDuplicates=[row for row,_ in plans],freeAfter=shutil.disk_usage(root.parent).free)''')
assert 'for row in {duplicates!r}' in launcher
analyzer=(previous/"analyze.py").read_text(encoding="utf-8")
analyzer=analyzer.replace("if label=='defaulted' and any", "if any")
analyzer=analyzer.replace("'AllocateExecutableDefaults'","'AllocateFunctionDefaults'")
analyzer=analyzer.replace("'RetireTemporary'),","'RetireTemporary','EndWorkspaceReuse','CloseResources','DisposeScope'),")
for name,content in (("ops-profile.py",ops),("collect.py",collect),("quiet.py",launcher),("analyze.py",analyzer)):
    compile(content,name,"exec")
    write(lab/name,content)

replicas=read(external/"verified-raw-replicas.json")
for location, bundle in (
    ("forwarded-integers-cpython-b1633-20261124", external_out/"observations.tar.xz"),
    ("defaults-forwarded-cumulative-b1632-20261124", donor/"cumulative/comparison/quiet/observations.tar.xz"),
):
    terminal=read(bundle.parent/"terminal-status.json")["receipt"]
    assert terminal["allWorkersJoined"] and terminal["archivedAndVerifiedUnderLease"] and sha(bundle)==terminal["archiveSHA256"]
    with tarfile.open(bundle) as data:
        raw=data.extractfile("confirmation/confirmation.json").read()
    replicas.insert(0,dict(location=location,bytes=len(raw),rawSHA256=hashlib.sha256(raw).hexdigest(),archiveSHA256=sha(bundle)))
save(lab/"verified-raw-replicas.json",replicas)
print("Prepared three current-source CPU profiles with separate execution boundaries.")
