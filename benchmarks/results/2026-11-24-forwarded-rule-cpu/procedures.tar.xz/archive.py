from pathlib import Path
import hashlib, json, shutil, tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
out=repo/"benchmarks/results/2026-11-24-forwarded-rule-cpu"
def read(path): return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
terminal=read(lab/"terminal-status.json")
receipt=terminal["receipt"]
assert not terminal["live"] and not terminal["fixtures"] and terminal["exitCode"]=="0"
assert all(receipt[key] for key in ("complete","allWorkersJoined","guestFixturesRemoved",
                                    "quietBeforeAndAfter","archivedAndVerifiedUnderLease"))
assert sha(lab/"observations.tar.xz")==receipt["archiveSHA256"]
identity=read(lab/"identity.json")
assert identity["sourceRevision"].startswith("d6a168491")
rows=read(lab/"attribution.json")["rows"]
assert [(r["label"],r["case"],r["role"]) for r in rows]==list(map(tuple,identity["profiles"]))
for row in rows:
    record=read(lab/"retrieved/profiles"/row["label"]/"record.json")
    intended="compile-run" if row["label"].endswith("-through") else "warm"
    assert record["lane"]==intended and record["warmupSeconds"]>=8
    assert record["exitCode"]==0 and record["closed"]["status"]=="Closed"
    assert record["verificationBefore"]["status"]==record["verificationAfter"]["status"]=="Equivalent"
    assert sum(row["exclusiveNearestRuntimeGroups"].values())==row["guestRuntimeAncestry"]
out.mkdir(exist_ok=True)
for name in ("identity.json","attribution.json","observations.tar.xz","terminal-status.json"):
    shutil.copyfile(lab/name,out/name)
with tarfile.open(out/"procedures.tar.xz","w:xz") as archive:
    for name in ("archive.py","prepare.py","collect.py","ops-profile.py","quiet.py","run.sh","analyze.py",
                 "candidate-verification.json","verified-raw-replicas.json","launch.log","retrieve.log"):
        archive.add(lab/name,arcname=name,recursive=False)
for row in rows:
    print(row["label"], "total",row["sampleCount"], "runtime",row["guestRuntimeAncestry"],
          "unmapped", row["unmappedLeafSamples"],"invocations",row["invocations"],
          "nearest frontend",row["nearestFrontendSamples"],row["runtimeRegions"],
          "runtime groups",row["exclusiveNearestRuntimeGroups"])
    print("nearest construction leaves",row["runtimeRegionLeaves"].get("definition construction",[])[:8])
