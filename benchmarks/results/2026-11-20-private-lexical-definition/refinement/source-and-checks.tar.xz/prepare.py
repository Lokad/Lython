from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
lab=Path(__file__).resolve().parent
base=lab.parent
prev=base/'quiet'; confirm=base/'confirmation/quiet'
q=lab/'quiet';q.mkdir()
def read(p):return p.read_text(encoding='utf8')
def load(p):return json.loads(read(p))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def emit(path,s):
    if path.suffix=='.py':compile(s,str(path),'exec')
    path.write_text(s,encoding='utf8',newline='\n')
def save(path,obj):emit(path,json.dumps(obj,indent=2)+'\n')
old=load(prev/'config.json'); cold=load(confirm/'config.json')
proof=load(prev/'archive-receipt.json')
assert proof['complete'] and proof['archivedAndVerifiedUnderLease'] and proof['archiveSHA256']==sha(prev/'observations.tgz')
assert old['identity']['imageFiles']==cold['identity']['imageFiles']
reference=old['identity']['imageFiles']['reference']; assert len(reference)==32
candidate=load(base/'refined-frozen-identity.json'); assert candidate['source'].startswith('559242ac1'); new=candidate['files']
ref_dir=base/'frozen/reference'; can_dir=base/'refined-frozen'
for image,files in ((ref_dir,reference),(can_dir,new)):
    assert {n:sha(image/n)for n in files}==files
assert candidate['catalog']==old['catalogSHA256']==sha(prev/'representative.json')
for name in ('reference-comparison-verify.json','refined-comparison-verify.json'):
    v=load(base/name); assert v['state']=='Completed' and v['catalogSha256']==candidate['catalog']
assert [n for n in reference if reference[n]!=new[n]]==['Lokad.Lython.dll']
core='Lokad.Lython.dll'
identity=dict(old['identity'],purpose='Refined lexical capture admission',sourceRevision=old['identity']['sourceRevision'].split(' versus ')[0]+' versus '+candidate['source'],imageFiles={'reference':reference,'candidate':new},coreSHA256={label:files[core] for role,files in (('reference',reference),('candidate',new))for label in (role,role+'-control')})
location='/home/lokad/lython-bench-checks/private-lexical-definition-refined-b1230-20261120'
unit='lython-b1230-private-lexical-definition-refined-20261120'
for name in ('collect.py','archive-owned.py','run.sh','retrieve.py'):
    s=read(confirm/name).replace(cold['root'],location).replace(cold['unit'],unit)
    emit(q/name,s)
assert b'\r' not in (q/'run.sh').read_bytes()
save(q/'identity.json',identity)
(q/'candidate').mkdir()
shutil.copyfile(can_dir/core,q/'candidate'/core)
parts=('identity.json','collect.py','archive-owned.py','run.sh','candidate/'+core)
with tarfile.open(q/'payload.tgz','w:gz') as f:
    for name in parts:f.add(q/name,arcname=name)
config=dict(root=location,unit=unit,source=old['root'],sourceRole='reference',sourceFiles=reference,sourceCatalogSHA256=old['catalogSHA256'],
            protocolSHA256=old['protocolSHA256'],catalogSHA256=old['catalogSHA256'],identity=identity,retireGroups=load(lab/'retirement-proofs.json'),
            donorArchiveSHA256=proof['archiveSHA256'],payloadBytes=(q/'payload.tgz').stat().st_size,
            payloadSHA256=sha(q/'payload.tgz'),unpackedBytes=sum((q/name).stat().st_size for name in parts))
save(q/'config.json',config)
s=read(prev/'remote-launch.py');a=s.index('\nc=')+1;b=s.index('\nb=Path(',a);s=s[:a]+'c='+repr(config)+s[b:]
s=s.replace('lython-b1227-fixtures','lython-b1230-fixtures')
needle=" assert sha(root/'cpython-worker.py')==c['protocolSHA256']"
assert s.count(needle)==1
s=s.replace(needle," assert sha(source/'cpython-worker.py')==c['protocolSHA256']\n os.link(source/'cpython-worker.py',root/'cpython-worker.py')\n"+needle)
assert '+64*1024*1024' in s
emit(q/'remote-launch.py',s)
for n in ('launch-quiet.py','summarize-quiet.py'):
    s=read(base/'confirmation'/n).replace(cold['identity']['purpose'],identity['purpose'])
    emit(lab/n,s)
print('Verified 32 files in each image, same catalog, refined source and three benchmark lanes.')
