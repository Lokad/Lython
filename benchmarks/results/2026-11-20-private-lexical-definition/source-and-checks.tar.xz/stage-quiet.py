import gzip, hashlib, json, os, shutil, subprocess, tarfile
from pathlib import Path
lab=Path(__file__).resolve().parent
root=lab.parent
quiet=lab/'quiet'
scripts=root/'native-body-recursion-admission/quiet'
trial=Path('.git/agent-worktrees/private-lexical-definition')
def read(p):return p.read_text(encoding='utf-8-sig')
def load(p):return json.loads(read(p))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],encoding='utf-8').strip()
def write(p,s):
    if p.suffix=='.py':compile(s,str(p),'exec')
    p.write_text(s,encoding='utf-8',newline='\n')
def save(p,obj):write(p,json.dumps(obj,indent=2)+'\n')
quiet.mkdir()
ref=git('rev-parse','46ccc2efa')
candidate=git('-C',str(trial),'rev-parse','HEAD')
assert candidate.startswith('db20a4369') and not git('-C',str(trial),'status','--porcelain')
assert git('rev-parse',candidate+'^')==ref
assert not git('diff','--name-only',ref,'HEAD','--','src','tests','global.json','Directory.Build.props','Directory.Packages.props','benchmarks/Lokad.Lython.Benchmarks','benchmarks/cpython-worker.py')
source=load(scripts/'identity.json')
assert source['sourceRevision'].split(' versus ')[1].startswith('eaf4d65c1')
assert not git('diff','--name-only','eaf4d65c1',ref,'--','src','tests','global.json','Directory.Build.props','Directory.Packages.props','benchmarks/Lokad.Lython.Benchmarks','benchmarks/cpython-worker.py')
ref_files=source['imageFiles']['candidate']
ref_image=scripts.parent/'frozen/candidate'
assert len(ref_files)==32 and {n:sha(ref_image/n) for n in ref_files}==ref_files
base=load(scripts/'config.json')
source_files=base['identity']['imageFiles']['candidate']
core='Lokad.Lython.dll'
assert all(source_files[n]==ref_files[n]for n in ref_files if n!=core)
assert source_files==ref_files
archive=load(scripts/'archive-receipt.json')
assert archive['complete'] and archive['archiveSHA256']==sha(scripts/'observations.tgz')
retire=load(lab/'retirement-proofs.json')
for item in retire:
    path=item['verifiedCanonicalGitImage']
    data=subprocess.check_output(['git','cat-file','blob','origin/master:'+path])
    assert hashlib.sha256(gzip.decompress(data)).hexdigest()==item['sha256']

catalog=load(scripts/'representative.json')
siblings=next(c for c in load(root/'retained-call-profile-r642/catalog.json')['cases'] if c['id']=='scripts.retained-nonlocal-factories')
catalog['cases']=[c for c in catalog['cases'] if 'forwarding' not in c['id']]+[siblings]
a,b,c,d=(row['id'] for row in catalog['cases'])
assert (a,b,c,d)==('scripts.annotated-rule-closures.nested-factories','scripts.annotated-rule-closures.nested-factories.postponed','scripts.csv-invoice.large','scripts.retained-nonlocal-factories')
jobs=[(a,'warm'),(b,'warm'),(d,'warm'),(a,'compile-run'),(c,'warm')]
manifest=quiet/'representative.json'
save(manifest,catalog)
shutil.copyfile('benchmarks/cpython-worker.py',quiet/'cpython-worker.py')
assert sha(quiet/'cpython-worker.py')==base['protocolSHA256']
sdk=Path.home()/'.dotnet11';dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
images={}
for role in ('reference','candidate'):
    work=lab/'frozen'/role; work.mkdir(parents=True)
    for name in ref_files:
        original=(trial/'src/Lokad.Lython/bin/Release/net11.0'/core
                  if role=='candidate' and name==core else ref_image/name)
        shutil.copyfile(original,work/name)
    images[role]={n:sha(work/n)for n in ref_files}
    verified=lab/f'{role}-comparison-verify.json'
    subprocess.run([dotnet,work/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',manifest,'--dotnet',dotnet,
        '--python','C:/Python313/python.exe','--python-worker',quiet/'cpython-worker.py','--out',verified],env=env,check=True,timeout=90)
    assert load(verified)['state']=='Completed' and load(verified)['catalogSha256']==sha(manifest)
    for path in (scripts.parent/'frozen/candidate').glob('ValidatedAllocation.*'):
        shutil.copyfile(path,work/path.name)
    result=lab/f'{role}-comparison-allocation.json'
    subprocess.run([dotnet,work/'ValidatedAllocation.dll',work,manifest,result],env=env,check=True,timeout=90)
    assert all(row['sharedBudgetBaselineRestored'] for row in load(result)['rows'])
    assert {n:sha(work/n)for n in ref_files}==images[role]
    if role=='candidate':
        (quiet/role).mkdir();shutil.copyfile(work/core,quiet/role/core)
assert images['reference']==ref_files and [n for n in ref_files if images['candidate'][n]!=ref_files[n]]==[core]
purpose='Admit lexical function and capture backing together'
location='/home/lokad/lython-bench-checks/lexical-definition-admission-b1227-20261120'
unit='lython-b1227-lexical-definition-admission-20261120'
identity=dict(sourceRevision=ref+' versus '+candidate,purpose=purpose,imageFiles=images,catalogSHA256=sha(manifest),
    normalAdapterPin='0.4.0',coreSHA256={r+s:files[core] for r,files in images.items() for s in ('','-control')})
save(quiet/'identity.json',identity)
for name in ('collect.py','archive-owned.py','run.sh','retrieve.py'):
    text=read(scripts/name).replace(base['root'],location).replace(base['unit'],unit).replace(base['identity']['purpose'],purpose)
    if name=='collect.py':
        i=text.index('\njobs = ');j=text.index('\nassert len(jobs)',i)
        text=text[:i]+'\njobs = '+repr(jobs)+text[j:]
        for previous,new in [('accumulate 7 seconds','accumulate 8 seconds'),('warmupSeconds=7','warmupSeconds=8'),('min(warmed)<7','min(warmed)<8'),('warmed[i]>=7','warmed[i]>=8')]:text=text.replace(previous,new)
    write(quiet/name,text)
assert b'\r' not in (quiet/'run.sh').read_bytes()
parts=['identity.json','representative.json','cpython-worker.py','collect.py','archive-owned.py','run.sh','candidate/'+core]
payload=quiet/'payload.tgz'
with tarfile.open(payload,'w:gz') as f:
    for name in parts:f.add(quiet/name,arcname=name)
config=dict(root=location,unit=unit,source=base['root'],sourceRole='candidate',sourceFiles=source_files,
    sourceCatalogSHA256=base['catalogSHA256'],protocolSHA256=base['protocolSHA256'],catalogSHA256=sha(manifest),identity=identity,
    retireGroups=retire,donorArchiveSHA256=archive['archiveSHA256'],payloadBytes=payload.stat().st_size,
    payloadSHA256=sha(payload),unpackedBytes=sum((quiet/name).stat().st_size for name in parts))
save(quiet/'config.json',config)
text=read(scripts/'remote-launch.py')
i=text.index('\nc=')+1;j=text.index('\nb=Path(',i)
text=text[:i]+'c='+repr(config)+text[j:]
text=text.replace('lython-b1225-fixtures','lython-b1227-fixtures')
anchor="  ps=[b/n for n in proof['paths']]"
assert text.count(anchor)==1 and '+64*1024*1024' in text
assert text.count('canonicalArchiveSHA256')>=1
write(quiet/'remote-launch.py',text)
text=read(scripts.parent/'launch-quiet.py').replace(base['identity']['purpose'],purpose).replace('seconds=237','seconds=249').replace('before 237','before 249')
write(lab/'launch-quiet.py',text)
write(lab/'summarize-quiet.py',read(scripts.parent/'summarize-quiet.py').replace("len(raw['jobs'])==6","len(raw['jobs'])==5"))
print('Both complete images and four CPython goldens verified. Five timing lanes staged.')
