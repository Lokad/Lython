set -eu
root=$PWD
lab=$root/.git/agent-notes/review-20261031/private-lexical-definition
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$lab/../compiler-callback-ownership/tools:$PATH"
cd "$root/.git/agent-worktrees/private-lexical-definition"
dotnet build tools/LythonProbe/LythonProbe.csproj -c Release -f net10.0 -p:RestoreLockedMode=true --no-incremental >"$lab/probe-ubuntu.log" 2>&1 || { tail -n 35 "$lab/probe-ubuntu.log"; exit 1; }
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="$lab/$suite-ubuntu.log"
    filter=$(cat "$lab/focused-filter.txt")
    dotnet test "tests/$suite/$suite.csproj" -c Release -f net10.0 -p:RestoreLockedMode=true --filter "$filter" >"$log" 2>&1 || { tail -n 60 "$log"; exit 1; }
    tail -n 6 "$log"
done