from pathlib import Path
import json,os,re,subprocess
root=Path(__file__).resolve().parent;repo=Path('D:/code/Lython')
text=(repo/'tests/Lokad.Lython.PublicApi.Tests/HashQueryCompatibilityTests.cs').read_text(encoding='utf-8')
raw=[m.group(1) for m in re.finditer(r'"""\n(.*?)\n\s*"""',text,re.S)]
import textwrap
sources=[]
for s in raw:
 s=textwrap.dedent(s)
 if 'OPERATION' in s:
  sources.extend(s.replace('OPERATION',op) for op in ['table[key]=1','table.get(key)','key in table','set().add(key)','{key:1}','hash(key)'])
 else:sources.append(s)
env=dict(os.environ,DOTNET_ROOT='C:/Users/JoannesVermorel/.dotnet11')
result=[]
for source in sources:
 p=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],capture_output=True,timeout=10)
 assert p.returncode==0,p.stderr
 result.append(dict(source=source,stdout=p.stdout.decode('utf-8'),stderr=p.stderr.decode('utf-8')))
(root/'independent-goldens.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
for async_ in [False,True]:
 p=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe',str(repo/'tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll'),'--batch-json','--compare-python','--python','C:/Python313/python.exe']+(['--async'] if async_ else []),input=json.dumps(sources).encode(),capture_output=True,env=env,timeout=30)
 target=root/('after-async' if async_ else 'after-sync')
 target.with_suffix('.jsonl').write_bytes(p.stdout);target.with_suffix('.stderr').write_bytes(p.stderr)
 assert p.returncode==0,p.stderr
 rows=[json.loads(line) for line in p.stdout.decode('utf-8-sig').splitlines()]
 assert len(rows)==len(sources)
 # Each public result records its independently executed CPython comparison.
 for row in rows:
  assert row['Lython']['Success'],row
  assert row['Matches'] and row['Lython']['StandardOutput']==row['CPython']['StandardOutput'],row
 print('async',async_,'all',len(rows),'independent Python results agree')
