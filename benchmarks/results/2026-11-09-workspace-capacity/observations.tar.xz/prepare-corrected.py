from pathlib import Path
import shutil
r = Path(__file__).parent
c = r / 'corrected'
c.mkdir()
(c / 'images').mkdir()
shutil.copytree(r / 'images/before', c / 'images/before')
for name in ['measure.py', 'catalog.json', 'baseline-revision.txt', 'assess-local.py']:
    shutil.copyfile(r / name, c / name)
p = c / 'measure.py'
p.write_text(p.read_text(encoding='utf-8').replace("r.parent/'integer-utf8-r45", "r.parent.parent/'integer-utf8-r45"), encoding='utf-8')
