$ErrorActionPreference = 'Stop'
$env:DOTNET_ROOT = 'C:/Users/JoannesVermorel/.dotnet11'
$env:DOTNET_HOST_PATH = "$env:DOTNET_ROOT/dotnet.exe"
$env:PATH = "$env:DOTNET_ROOT;C:/Python313;$env:PATH"
$internalFilter = 'Category!=Stress&(FullyQualifiedName~Function|FullyQualifiedName~Call|FullyQualifiedName~Generator|FullyQualifiedName~Dataclass|FullyQualifiedName~MemoryGovernor|FullyQualifiedName~BatchedSharedAdmission)'
$publicFilter = 'Category!=Stress&(FullyQualifiedName~Function|FullyQualifiedName~Call|FullyQualifiedName~Generator|FullyQualifiedName~Dataclass|FullyQualifiedName~GovernedMemoryContract|FullyQualifiedName~AdmissionFailureCommand|FullyQualifiedName~MidFlightCancellation)'
foreach ($framework in @('net11.0', 'net10.0')) {
    foreach ($suite in @('internal', 'public')) {
        $project = if ($suite -eq 'internal') { 'tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj' } else { 'tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj' }
        $filter = if ($suite -eq 'internal') { $internalFilter } else { $publicFilter }
        $log = Join-Path $PSScriptRoot "final-$suite-$framework.log"
        & $env:DOTNET_HOST_PATH test $project -c Release -f $framework --no-restore --filter $filter *> $log
        if ($LASTEXITCODE -ne 0) { Get-Content $log -Tail 45; exit $LASTEXITCODE }
        Get-Content $log -Tail 2
    }
}
