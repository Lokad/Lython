from pathlib import Path
r = Path(__file__).parent
p = Path('PLAN.md')
s = p.read_text(encoding='utf-8-sig')
marker = '## Prioritized non-regex deliverables\n'
s = s.replace(marker, marker + '''
0. **R155: valid DEFLATE correctness handoff, next after the R154 freeze.**
   New TODO-zipfile-valid-deflate.md provides a 259-byte valid archive with all
   nineteen code-length entries. Current CodeLengthOrder has only eighteen entries,
   so DecodeDynamic can escape with IndexOutOfRangeException. Preserve the supplied
   reproducer/evidence, complete the format table, and add public sync/async read,
   corruption, cancellation and shared-owner cleanup checks using existing fixtures.
   No decoder redesign or performance claim. Merge/remove handoff after validation.

''')
s = s.replace('1. **R154: one existing function-workspace cache, with capacity-based ownership.**',
'''1. **R154: one existing function-workspace cache, with capacity-based ownership.**
   Active uncommitted prototype, not delivery-qualified. First local image1534e525
   reduces constructor-control allocation0.81%; ordinary/compile allocation unchanged.
   Desktop elapsed mixed, async text+7.7–11.35% and wide-control baseline spread11.58%:
   adverse evidence retained, no CPU claim. A new regression proves deferred-prefix
   locals were not cleared in that prototype (both APIs fail); corrected cleanup
   clears the compiler workspace. Fresh corrected-source comparison in progress.
''')
s = s.replace('No live VM/CI work. R151 production21CF1118/commit99844959 fully qualified.',
'''No live VM/CI work. R151 production21CF1118/commit99844959 fully qualified.
One corrected R154 local comparison in progress; do not overlap local builds/tests.''')
p.write_text(s, encoding='utf-8')
print('Plan records current prototype, adverse controls, proven cleanup correction and next correctness handoff.')
