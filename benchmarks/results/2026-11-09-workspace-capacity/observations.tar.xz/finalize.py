from pathlib import Path
import hashlib, json, re, shutil, subprocess, tarfile
r = Path(__file__).parent
c = r / 'corrected'
out = Path('benchmarks/results/2026-11-09-workspace-capacity')
out.mkdir(exist_ok=True)
identity = json.loads((c / 'identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(n).read_bytes()).hexdigest() == h for n, h in identity['productionSources'].items())
checks = {}
for framework in ['net11.0', 'net10.0']:
    checks[framework] = {}
    for suite in ['internal', 'public']:
        data = (r / f'final-{suite}-{framework}.log').read_text(encoding='utf-8-sig')
        match = re.search(r'Passed!.*?Passed:\s*(\d+)', data)
        assert match and 'Failed:     0' in data, (framework, suite)
        checks[framework][suite] = int(match[1])
assert 'Failed:     2' in (r / 'deferred-original-net11.0.log').read_text(encoding='utf-8-sig')
proof = dict(baseline='4175fe6c, production99844959 fully qualified42605184549',
    measuredCoreSHA256=identity['candidateCoreSHA256'], productionSourceMatchesFreeze=True, focused=checks,
    retained='One existing funded execution-owned idle array; actual-capacity refunds; logical binding and clearing extents; active/pending borrows; terminal first refusal; independent retained values.',
    removed='BoundCallArguments.StorageBytes and ExecutionContext._boundStorageBytes plus their transfers/resets; exact-size eviction and first-return retention choices. No new pool, budget, framework or public option.',
    correction='Both APIs failed a new reference-retirement regression in the original logical-clear prototype; deferred context-free prefixes now clear all compiler workspace slots before returning storage.',
    measurements='Constructor-control warm allocation -0.81% in both APIs, ordinary/compile essentially unchanged. Desktop elapsed inconclusive: original async text +7.7 to11.35%; corrected identical JSON controls26.43% apart. No CPU claim. Both original and corrected raw results retained.',
    qualification='Focused actual11/10 only here; full platform/original Stress/installed package batch at delivery with next bounded correctness fix. No publication.')
(r / 'delivery-source.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8')
(r / 'final-source.patch').write_bytes(subprocess.check_output(['git', 'diff', '--binary', '--', 'src/Lokad.Lython', 'tests']))
for name, source in [('identity.json', c / 'identity.json'), ('summary.json', c / 'assessment-local.json'),
                     ('original-summary.json', r / 'assessment-local.json'), ('delivery-source.json', r / 'delivery-source.json'),
                     ('script-goldens.json', r / 'script-goldens.json')]:
    assert not (out / name).exists()
    shutil.copyfile(source, out / name)
with tarfile.open(out / 'observations.tar.xz', 'w:xz') as archive:
    for p in r.iterdir():
        if p.is_file() and p.name != 'prepare-zip-handoff.py': archive.add(p, arcname=p.name)
    for base, prefix in [(r, 'original'), (c, 'corrected')]:
        for phase in ['warm-sync', 'warm-async', 'compile-sync']: archive.add(base / phase, arcname=prefix + '/' + phase)
    for p in c.iterdir():
        if p.is_file(): archive.add(p, arcname='corrected/' + p.name)
    for p in [Path('tests/Lokad.Lython.PublicApi.Tests/FunctionWorkspaceCapacityTests.cs'), Path('tests/Lokad.Lython.Tests/FunctionWorkspaceOwnershipTests.cs')]:
        archive.add(p, arcname='tests/' + p.name)
print(json.dumps(proof, indent=2))
