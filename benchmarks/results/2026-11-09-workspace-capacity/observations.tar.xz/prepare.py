from pathlib import Path
import base64,copy,hashlib,json,re,subprocess,tempfile,textwrap
r=Path(__file__).parent;previous=r.parent/'borrowed-call-entry-r151'
catalog=json.loads((previous/'catalog.json').read_text(encoding='utf-8'))
cases={item['id']:copy.deepcopy(item) for item in catalog['cases']}
selected=[cases['scripts.'+name+'.large'] for name in ['json-summary-helpers','text-summary-helpers','csv-validated-records']]
selected.append(cases['scripts.csv-validated-records.constructor-control.large'])
wide=copy.deepcopy(cases['scripts.csv-validated-records.large'])
prefix="events=[]\ndef establish_wide_workspace(value):\n"+''.join('    local'+str(i)+'=value\n' for i in range(1024))+"    events.append(value)\n    return value\nestablish_wide_workspace(0)\n\n"
wide['source']=prefix+wide['source'];wide['id']='scripts.csv-validated-records.wide-then-small-control.large'
wide['sourceUtf8Bytes']=len(wide['source'].encode());wide['sourceSha256']=hashlib.sha256(wide['source'].encode()).hexdigest();selected.append(wide)
catalog['cases']=selected
(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
# Four unchanged scripts retain their existing independent Python evidence.
old={g['case']:g for g in json.loads((previous/'script-goldens.json').read_text(encoding='utf-8'))}
goldens=[dict(old[c['id']],reusedFrom='R151 identical source/input/output hashes') for c in selected[:-1]]
fixture=json.loads(wide['fixtureJson'])
with tempfile.TemporaryDirectory(prefix='lython-r154-wide-golden-') as folder:
    folder=Path(folder)
    for name,encoded in fixture['inputFiles'].items():
        p=folder/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(base64.b64decode(encoded,validate=True))
    done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',wide['source']],cwd=folder,encoding='utf-8',capture_output=True,timeout=15)
    assert done.returncode==0 and done.stdout==wide['expectedOutput'] and not done.stderr,done
    for name,encoded in fixture['outputFiles'].items():assert (folder/name).read_bytes()==base64.b64decode(encoded,validate=True)
    goldens.append(dict(case=wide['id'],source=wide['source'],sourceSHA256=wide['sourceSha256'],stdout=done.stdout,allOutputFilesEqual=True))
(r/'script-goldens.json').write_text(json.dumps(goldens,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
test=Path('tests/Lokad.Lython.PublicApi.Tests/FunctionWorkspaceCapacityTests.cs').read_text(encoding='utf-8')
source=textwrap.dedent(re.search(r'"""\n(.*?)\n\s*"""',test,re.S)[1])
converted=source.replace("return next(stream('held'))","print(next(stream('held')))")
with tempfile.TemporaryDirectory(prefix='lython-r154-binding-golden-') as folder:
    Path(folder,'value').write_text('ok',encoding='utf-8')
    done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',converted],cwd=folder,encoding='utf-8',capture_output=True,timeout=10)
    expected="[[['data', 'source', 'x', 'y'], 'a!', 'ok'], ['a', 'a', 'a', 'a', 'a', 'a', 'a', 'a']]\n[[['data', 'source', 'x', 'y'], 'b!', 'ok'], ['b', 'b', 'b', 'b', 'b', 'b', 'b', 'b']]\nRecord(value=3) True\nheld\n"
    assert done.returncode==0 and done.stdout==expected and not done.stderr,done
(r/'python-goldens.json').write_text(json.dumps(dict(source=source,pythonSource=converted,stdout=done.stdout,differences='Only top-level return becomes print; real value file supplies ok.'),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
identity=json.loads((previous/'identity.json').read_text(encoding='utf-8'))
assert hashlib.sha256((r/'images/before/Lokad.Lython.dll').read_bytes()).hexdigest()==identity['candidateCoreSHA256']
subprocess.run(['git','diff','--exit-code','99844959',(r/'baseline-revision.txt').read_text(encoding='utf-8-sig').strip(),'--','src/Lokad.Lython'],check=True)
(r/'baseline-proof.json').write_text(json.dumps(dict(revision=(r/'baseline-revision.txt').read_text(encoding='utf-8-sig').strip(),productionRevision='99844959 fully qualified42605184549',coreSHA256=identity['candidateCoreSHA256'],build='Reuse R151 fresh nonincremental freeze; no source restore, production tree equality verified.',productionSources=identity['productionSources']),indent=2)+'\n',encoding='utf-8')
print('Two new independent Python goldens, four unchanged goldens reused; same frozen fully-qualified production baseline.')
