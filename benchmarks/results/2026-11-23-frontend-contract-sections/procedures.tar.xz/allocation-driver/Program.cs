using System.Text.Json;
using Lokad.Lython;

using var document = JsonDocument.Parse(File.ReadAllBytes(args[0]));
var id = args[1];
var source = document.RootElement.GetProperty("cases").EnumerateArray()
    .Single(row => row.GetProperty("id").GetString() == id).GetProperty("source").GetString()!;
var engine = new LythonEngine();

// Sample allocation on the calling thread. Compilation does all guest
// analysis synchronously. Per-process cold data are distinct from warm data.
Sample Measure()
{
    var budget = new LythonMemoryBudget();
    var before = GC.GetAllocatedBytesForCurrentThread();
    using (var script = engine.Compile(source, budget))
    {
        if (!script.IsValid)
            throw new InvalidOperationException(string.Join(" | ", script.Diagnostics.Select(diagnostic => diagnostic.Message)));
    }
    var allocated = GC.GetAllocatedBytesForCurrentThread() - before;
    if (budget.ReservedBytes != 0)
        throw new InvalidOperationException("Compiled storage did not return to its original balance.");
    return new Sample(allocated, budget.PeakBytes);
}

var cold = Measure();
for (var i = 0; i < 32; i++) Measure();
var warm = new Sample[25];
for (var i = 0; i < warm.Length; i++) warm[i] = Measure();
Console.WriteLine(JsonSerializer.Serialize(new { id, cold, warm }));
internal sealed record Sample(long AllocatedBytes, long PeakAllowance);
