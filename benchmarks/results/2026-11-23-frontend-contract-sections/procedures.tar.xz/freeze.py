from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repository = lab.parents[3]
worktree = repository / ".git/agent-worktrees/frontend-contract-sections-20261123"
deliver = lab.parent / "cpython-runtime-checkpoint-20261123"
read = lambda file: json.loads(file.read_text(encoding="utf-8"))
save = lambda file, value: file.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")
digest = lambda file: hashlib.sha256(file.read_bytes()).hexdigest()

verified = read(deliver / "dfabddb88/verify.json")
donor = read(deliver / "dfabddb88/source.json")
original = Path(verified["launched"]["adapter"]["path"]).parent
dotnet = Path(verified["launched"]["dotnet"]["path"])
python = Path(verified["launched"]["python"]["path"])
protocol = Path(verified["launched"]["pythonWorker"]["path"])
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
assert digest(protocol) == donor["protocolSHA256"]
assert len(donor["imageFiles"]) == 32
assert all(digest(original / name) == expected for name, expected in donor["imageFiles"].items())
git = lambda *args: subprocess.check_output(["git", "-C", str(worktree), *args])
candidate = git("rev-parse", "HEAD").decode("ascii").strip()
assert not git("status", "--porcelain")
assert not git("diff", "--name-only", donor["retained"], "HEAD^", "--", "src", "tests")
assert candidate[:9] == "c6d2f2b3d"
assembly_name = "Lokad.Lython.Benchmarks.dll"
core_name = "Lokad.Lython.dll"
new_core = worktree / "benchmarks/Lokad.Lython.Benchmarks/bin/Release/net11.0" / core_name
out = lab / "comparison"
out.mkdir()
frozen = out / "frozen-candidate"
frozen.mkdir()
for name in donor["imageFiles"]:
    shutil.copyfile(new_core if name == core_name else original / name, frozen / name)
files = {name: digest(frozen / name) for name in donor["imageFiles"]}
assert [name for name in files if files[name] != donor["imageFiles"][name]] == [core_name]

known = out / "canonical.json"
subprocess.run([dotnet, original / assembly_name, "--compare", "list", "--profile", "full", "--out", known],
    env=env, check=True, timeout=45)
combined = read(deliver / "dfabddb88/representative.json")
more = read(known)
assert combined["schemaVersion"] == more["schemaVersion"] and combined["catalogVersion"] == more["catalogVersion"]
cases = {case["id"]:case for case in more["cases"] + combined["cases"]}
cold = ["control.empty.control", "control.tiny.control", "scripts.config-edit.small",
        "scripts.csv-meter-report.typed-ascii", "xml.parse-select.small"]
warm = ["scripts.config-edit.small", "scripts.csv-meter-report.typed-ascii",
        "xml.parse-select.small", "compiler.generated-read-only-branches"]
selected = list(dict.fromkeys(cold + warm))
selected_catalog = out / "representative.json"
save(selected_catalog, dict(combined, cases=[cases[case] for case in selected]))
cold_catalog = out / "fresh.json"
save(cold_catalog, dict(combined, cases=[cases[case] for case in cold]))
save(out / "jobs.json", dict(cold=cold, warm=[[case, "compile"] for case in warm]))
for label, image in (("reference", original), ("candidate", frozen)):
    receipt = out / (label + "-verify.json")
    subprocess.run([dotnet, image / assembly_name, "--compare", "verify", "--catalog", selected_catalog,
        "--dotnet", dotnet, "--python", python, "--python-worker", protocol, "--out", receipt],
        env=env, check=True, timeout=100)
    proof = read(receipt)
    assert proof["state"] == "Completed" and proof["caseCount"] == len(selected)
    assert proof["catalogSha256"] == digest(selected_catalog)
    assert proof["launched"]["library"]["sha256"] == (donor["imageFiles"] if label == "reference" else files)[core_name]

assert all(digest(original / n) == expected for n, expected in donor["imageFiles"].items())
assert all(digest(frozen / n) == expected for n, expected in files.items())
save(out / "identity.json", dict(sourceRevision=donor["retained"], candidate=candidate,
    purpose="B1452 independent immutable frontend catalogs with identical static diagnostics",
    imageFiles=dict(reference=donor["imageFiles"], candidate=files),
    coreSHA256={"reference": donor["imageFiles"][core_name], "reference-control":donor["imageFiles"][core_name],
                "candidate":files[core_name], "candidate-control":files[core_name]},
    cpythonWorkerSHA256=donor["protocolSHA256"], expectedCPythonSHA256=read(deliver / "comparison/quiet/identity.json")["expectedCPythonSHA256"],
    catalogs={p.name:dict(sha256=digest(p)) for p in (selected_catalog, cold_catalog, out / "jobs.json")}))
(out / "source.patch").write_bytes(git("diff", "--binary", "HEAD^", "HEAD"))
print(candidate, len(selected), "goldens verified on both 32-file images")
