using Microsoft.Diagnostics.Tracing;
using System.Text.Json;

foreach (var path in args)
{
    using var trace = new EventPipeEventSource(path);
    var methods = new SortedSet<string>(StringComparer.Ordinal);
    var total = 0;
    trace.Clr.MethodJittingStarted += data =>
    {
        total++;
        if (data.MethodNamespace.StartsWith("Lokad.Lython.Frontend.Static", StringComparison.Ordinal) &&
            data.MethodName == ".cctor")
            methods.Add(data.MethodNamespace);
    };
    trace.Process();
    if (total == 0) throw new InvalidDataException("No JIT events in " + path);
    Console.WriteLine(JsonSerializer.Serialize(new { trace = Path.GetFileName(path), total, constructors = methods }));
}
