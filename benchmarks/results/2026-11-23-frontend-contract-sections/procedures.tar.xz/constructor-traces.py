from pathlib import Path
import hashlib
import json
import os
import subprocess
import tempfile

lab=Path(__file__).resolve().parent
comparison=lab/"comparison"
trace=lab/"constructor-traces"
trace.mkdir()
read=lambda p:json.loads(p.read_text(encoding="utf-8"))
save=lambda p,data:p.write_text(json.dumps(data,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
identity=read(comparison/"identity.json")
receipt=read(comparison/"reference-verify.json")
dotnet=Path(receipt["launched"]["dotnet"]["path"])
tool=Path.home()/".dotnet/tools/dotnet-trace.exe"
env=dict(os.environ,DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent))
images={"reference":Path(receipt["launched"]["adapter"]["path"]).parent,"candidate":comparison/"frozen-candidate"}
digest=lambda payload:hashlib.sha256(payload).hexdigest()
manifest=read(comparison/"representative.json")
cases={c["id"]:c for c in manifest["cases"]}
empty=cases["control.empty.control"]
source="""from openpyxl import Workbook
workbook = Workbook()
sheet = workbook.active
sheet.append([1])
print(sheet.max_row)
"""
output="1\n"
case=dict(empty,id="control.workbook-contracts.small",source=source,expectedOutput=output,
    sourceSha256=digest(source.encode()),expectedOutputSha256=digest(output.encode()),
    sourceUtf8Bytes=len(source.encode()),expectedOutputUtf8Bytes=len(output))
chosen=[empty,cases["scripts.config-edit.small"],case]
raw=[]
for role,image in images.items():
    assert {n:digest((image/n).read_bytes()) for n in identity["imageFiles"][role]}==identity["imageFiles"][role]
    for row in chosen:
        input_file=trace/(row["id"]+".json")
        save(input_file,dict(manifest,cases=[row]))
        worker=[dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","once","--catalog",input_file]
        out=trace/(role+"-"+row["id"]+".nettrace")
        with tempfile.TemporaryDirectory(prefix="lython-comparison-files-") as folder:
            command=subprocess.run(worker,cwd=folder,env=env,capture_output=True,check=True,timeout=25)
            assert not command.stderr and int.from_bytes(command.stdout[:4],"big")==len(command.stdout)-4
            result=json.loads(command.stdout[4:])
            response=result["response"]
            assert response["status"]=="Equivalent" and response["completedInvocations"]==1, response
            assert response["actualOutputSha256"]==row["expectedOutputSha256"]
            assert response.get("actualFilesSha256")==row.get("expectedFilesSha256")
        with tempfile.TemporaryDirectory(prefix="lython-comparison-files-") as folder:
            command=subprocess.run([tool,"collect","--providers","Microsoft-Windows-DotNETRuntime:0x10:5",
                "--output",out,"--",*worker],cwd=folder,env=env,capture_output=True,check=True,timeout=25)
            assert out.is_file() and out.stat().st_size>0
            out.with_suffix(".log").write_bytes(command.stdout+command.stderr)
            raw.append((out,dict(role=role,case=row["id"],traceSha256=digest(out.read_bytes()),semanticResponse=response)))
reader=next((lab/"trace-reader/bin").glob("**/TraceReader.dll"))
result=subprocess.run([dotnet,reader,*(p for p,_ in raw)],env=env,capture_output=True,check=True,timeout=30)
reports=[json.loads(line) for line in result.stdout.decode("utf-8").splitlines()]
assert len(reports)==len(raw)
for (file,sample),report in zip(raw,reports,strict=True):
    assert file.name==report["trace"]
    sample.update(report)
clean=lambda s:s.removeprefix("Lokad.Lython.Frontend.")
by_workload={(entry["role"],entry["case"]):set(map(clean,entry["constructors"])) for _,entry in raw}
for key,catalogs in by_workload.items(): print(key,sorted(catalogs))
save(trace/"summary.json",[entry for _,entry in raw])
program_catalogs=by_workload["candidate","scripts.config-edit.small"]
assert "StaticContracts" in by_workload["reference","scripts.config-edit.small"]
assert "StaticModuleCatalog" in program_catalogs
assert "StaticContracts+WorkbookCallableMemberCatalog" not in program_catalogs and "StaticWorkbookMemberSurfaces" not in program_catalogs
assert {"StaticContracts+WorkbookCallableMemberCatalog","StaticWorkbookMemberSurfaces"} <= by_workload["candidate","control.workbook-contracts.small"]
