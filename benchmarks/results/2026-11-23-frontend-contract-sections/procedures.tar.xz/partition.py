from pathlib import Path
import re

root = Path(".git/agent-worktrees/frontend-contract-sections-20261123")
frontend = root / "src/Lokad.Lython/Frontend"

def change(name, rewrite):
    p = frontend / f"StaticContracts.{name}.cs"
    s = p.read_text(encoding="utf-8")
    t = rewrite(s)
    assert s != t, name
    p.write_text(t, encoding="utf-8", newline="\n")

def once(s, old, new):
    assert s.count(old) == 1, old
    return s.replace(old, new, 1)

def indent(s):
    return "\n".join("    " + line if line else "" for line in s.split("\n"))

def module_catalog(s):
    start = s.index("    private static readonly Dictionary")
    end = s.index("    private static readonly string[] KnownBuiltinModuleNames")
    body = s[start:end].rstrip() + "\n"
    body = body.replace("private static readonly", "internal static readonly")
    body = body.replace("Dictionary<string, BuiltinModuleSurface> ModuleSurfaces = new(StringComparer.Ordinal)",
        "IReadOnlyDictionary<string, BuiltinModuleSurface> Surfaces = new Dictionary<string, BuiltinModuleSurface>(StringComparer.Ordinal)")
    body = body.replace("ModuleMemberModules", "Submodules").replace("ModuleMemberCallableAliases", "CallableAliases")
    check_end = s.index("    public static bool IsKnownBuiltinModule(")
    tail = s[check_end:].replace("ModuleSurfaces", "ModuleCatalog.Surfaces").replace("KnownBuiltinModuleNames", "ModuleCatalog.Names")
    tail = tail.replace("GetModuleCatalog.Names", "GetKnownBuiltinModuleNames").replace("ModuleMemberModules", "ModuleCatalog.Submodules")
    tail = tail.replace("ModuleMemberCallableAliases", "ModuleCatalog.CallableAliases")
    tail = once(tail, "private sealed class BuiltinModuleSurface", "internal sealed class BuiltinModuleSurface")
    tail = once(tail, "private readonly record struct ModuleMemberName", "internal readonly record struct ModuleMemberName")
    return s[:start] + """    internal static class ModuleCatalog
    {
""" + indent(body) + """
        internal static readonly IReadOnlyList<string> Names = Surfaces.Keys.Order(StringComparer.Ordinal).ToArray();
    }

""" + tail

change("Modules", module_catalog)

def known_calls(s):
    s = once(s, "private static readonly StaticKnownCallContract[] KnownCallContracts =", "private static StaticKnownCallContract[] CreateKnownCallContracts() =>")
    return once(s, """    private static readonly IReadOnlyDictionary<string, StaticKnownCallContract> KnownCallContractsByName =
        KnownCallContracts.ToDictionary(static contract => contract.TargetName, StringComparer.Ordinal);""",
"""    private static class KnownCallCatalog
    {
        internal static readonly Dictionary<string, StaticKnownCallContract> ByName =
            CreateKnownCallContracts().ToDictionary(static contract => contract.TargetName, StringComparer.Ordinal);
    }""").replace("=> KnownCallContractsByName.TryGetValue", "=> KnownCallCatalog.ByName.TryGetValue")

change("KnownCalls", known_calls)

def member_values(s):
    s = once(s, "private static readonly StaticMemberValueContract[] MemberValueContracts =", "private static StaticMemberValueContract[] CreateMemberValueContracts() =>")
    return once(s, """    private static readonly IReadOnlyDictionary<StaticMemberContractKey, StaticMemberValueContract> MemberValueContractsByMember =
        MemberValueContracts.ToDictionary(static contract => new StaticMemberContractKey(contract.ReceiverKind, contract.MemberName));""",
"""    private static class MemberValueCatalog
    {
        internal static readonly Dictionary<StaticMemberContractKey, StaticMemberValueContract> ByMember =
            CreateMemberValueContracts().ToDictionary(static contract => new StaticMemberContractKey(contract.ReceiverKind, contract.MemberName));
    }""").replace("MemberValueContractsByMember.TryGetValue", "MemberValueCatalog.ByMember.TryGetValue")

change("MemberValues", member_values)

def return_contracts(s):
    s = once(s, "private static readonly (string MemberName, StaticReturnShape ReturnShape)[] StringMemberReturnShapes =",
        "private static (string MemberName, StaticReturnShape ReturnShape)[] GetStringMemberReturnShapes() =>")
    s = once(s, """    private static readonly StaticMemberReturnContract[] MemberReturnContracts = CreateMemberReturnContracts();
    private static readonly IReadOnlyDictionary<StaticMemberContractKey, StaticMemberReturnContract> MemberReturnContractsByMember =
        MemberReturnContracts.ToDictionary(static contract => new StaticMemberContractKey(contract.ReceiverKind, contract.MemberName));""",
"""    private static class MemberReturnCatalog
    {
        internal static readonly Dictionary<StaticMemberContractKey, StaticReturnShape> ByMember = CreateMemberReturnShapes();
    }""")
    start = s.index("        if (MemberReturnContractsByMember")
    end = s.index("    private static StaticMemberReturnContract[] CreateMemberReturnContracts")
    s = s[:start] + """        return MemberReturnCatalog.ByMember.TryGetValue(new(receiverKind, memberName), out shape);
    }

""" + s[end:]
    start = s.index("    private static StaticMemberReturnContract[] CreateMemberReturnContracts")
    return s[:start] + """    private static Dictionary<StaticMemberContractKey, StaticReturnShape> CreateMemberReturnShapes()
    {
        var core = CreateCoreMemberReturnContracts();
        var extended = CreateExtendedMemberReturnContracts();
        var strings = GetStringMemberReturnShapes();
        var shapes = new Dictionary<StaticMemberContractKey, StaticReturnShape>(core.Length + extended.Length + strings.Length * 2);

        foreach (var contract in core)
            shapes.Add(new(contract.ReceiverKind, contract.MemberName), contract.ReturnShape);
        foreach (var (memberName, shape) in strings)
        {
            shapes.Add(new(AbstractValueKind.String, memberName), shape);
            shapes.Add(new(AbstractValueKind.StringType, memberName), shape);
        }
        foreach (var contract in extended)
            shapes.Add(new(contract.ReceiverKind, contract.MemberName), contract.ReturnShape);

        return shapes;
    }
}
"""

change("MemberReturns", return_contracts)

def make_factory(s, suffix, row_type, kind):
    header = f"    private static class {suffix}{kind}Catalog\n    {{\n        public static readonly {row_type}[] Contracts =\n        ["
    s = once(s, header, f"    private static {row_type}[] Create{suffix}{kind}s() =>\n    [")
    return once(s, "        ];\n    }\n}", "    ];\n}")

for suffix in ["Core", "Extended"]:
    change(f"MemberReturns.{suffix}", lambda s, suffix=suffix: make_factory(s, suffix, "StaticMemberReturnContract", "MemberReturnContract"))

for suffix in ["Core", "Data", "Library", "OpenPyxl"]:
    change(f"CallableMembers.{suffix}", lambda s, suffix=suffix: make_factory(s, suffix, "StaticCallableContract", "CallableContract"))

def callable_contracts(s):
    start = s.index("    private static readonly StaticCallableContract[]")
    end = s.index("    public static bool IsMutatingMember")
    s = s[:start] + """    private static class CallableMemberCatalog
    {
        internal static readonly Dictionary<StaticMemberContractKey, StaticCallableContract> ByMember = CreateCallableMemberIndex();
    }

    private static class WorkbookCallableMemberCatalog
    {
        internal static readonly Dictionary<StaticMemberContractKey, StaticCallableContract> ByMember =
            CreateOpenPyxlCallableContracts().ToDictionary(static contract => new StaticMemberContractKey(contract.ReceiverKind, contract.MemberName));
    }

    public static bool TryGetCallableContract(AbstractValue receiver, string memberName, out StaticCallableContract contract)
    {
        var kind = receiver.Kind == AbstractValueKind.DecimalTuple ? AbstractValueKind.Tuple : receiver.Kind;
        // The OpenPyxl kinds form one contiguous family in AbstractValueKind.
        var catalog = kind is >= AbstractValueKind.OpenPyxlWorkbook and <= AbstractValueKind.OpenPyxlMergedCellSet
            ? WorkbookCallableMemberCatalog.ByMember
            : CallableMemberCatalog.ByMember;
        return catalog.TryGetValue(new(kind, memberName), out contract);
    }

""" + s[end:]
    start = s.index("    private static StaticCallableContract[] CreateCallableContracts()")
    end = s.index("        static void AddStringCallableContracts(")
    s = s[:start] + """    private static Dictionary<StaticMemberContractKey, StaticCallableContract> CreateCallableMemberIndex()
    {
        var core = CreateCoreCallableContracts();
        var data = CreateDataCallableContracts();
        var library = CreateLibraryCallableContracts();
        var contracts = new Dictionary<StaticMemberContractKey, StaticCallableContract>(core.Length + data.Length + library.Length);
        AddContracts(core);
        AddContracts(data);
        AddContracts(library);
        AddStringCallableContracts(contracts);
        AddListCallableContracts(contracts);
        return contracts;

        void AddContracts(StaticCallableContract[] members)
        {
            foreach (var member in members)
                AddContract(contracts, member);
        }

        static void AddContract(Dictionary<StaticMemberContractKey, StaticCallableContract> contracts, StaticCallableContract member)
            => contracts.Add(new(member.ReceiverKind, member.MemberName), member);

""" + s[end:]
    s=s.replace("List<StaticCallableContract> contracts", "Dictionary<StaticMemberContractKey, StaticCallableContract> contracts")
    s=s.replace("contracts.Add(new StaticCallableContract(", "AddContract(contracts, new StaticCallableContract(")
    return s

change("CallableMembers", callable_contracts)

def surfaces(s, first, last, holder):
    start=s.index("    private static readonly HashSet<string> " + first)
    end=s.index(last,start)
    body=s[start:end].rstrip()
    names=re.findall(r"HashSet<string> (\w+) =",body)
    body=body.replace("    private static readonly","    internal static readonly")
    return s[:start] + f"    private static class {holder}\n    {{\n" + indent(body) + "\n    }\n\n" + s[end:], names

def library_surfaces(s):
    s, library = surfaces(s, "RegexPatternMembers", "    private static readonly HashSet<string> OpenPyxlWorkbookMembers", "LibraryMemberSurfaces")
    s, workbook = surfaces(s, "OpenPyxlWorkbookMembers", "\n}", "WorkbookMemberSurfaces")
    return s, library, workbook

library_path = frontend / "StaticContracts.MemberSurfaces.cs"
library_source, library_names, workbook_names = library_surfaces(library_path.read_text(encoding="utf-8"))
library_path.write_text(library_source.replace("    }\n\n\n}", "    }\n}"), encoding="utf-8", newline="\n")

def core_surfaces(s):
    s, names = surfaces(s, "NoneMembers", "    public static bool IsKnownMissingMember", "CoreMemberSurfaces")
    head, body=s.split("    public static bool IsKnownMissingMember",1)
    for holder, fields in [("CoreMemberSurfaces", names), ("LibraryMemberSurfaces", library_names), ("WorkbookMemberSurfaces", workbook_names)]:
        for field in fields:
            body=re.sub(rf"\b{field}(?=\.Contains)", f"{holder}.{field}", body)
    return head + "    public static bool IsKnownMissingMember" + body

change("CoreMemberSurfaces", core_surfaces)

tests=root/"tests/Lokad.Lython.Tests/ModuleContractParityTests.cs"
s=tests.read_text(encoding="utf-8")
i=s.index("    [Fact]\n    public void StaticBuiltinModuleSurfaceIsResolvableAtRuntime")
s=s[:i]+"""    [Fact]
    public void ModuleCatalogAgreesWithRuntimeRegistrationsAndKnownContracts()
    {
        Assert.Equal(LythonRuntime.GetKnownBuiltinModuleNames(), StaticContracts.GetKnownBuiltinModuleNames());
        foreach (var (member, target) in StaticContracts.ModuleCatalog.Submodules)
        {
            Assert.True(StaticContracts.IsKnownBuiltinModuleMember(member.ModuleName, member.MemberName), member.ToString());
            Assert.True(StaticContracts.IsKnownBuiltinModule(target), target);
        }

        foreach (var (member, target) in StaticContracts.ModuleCatalog.CallableAliases)
        {
            Assert.True(StaticContracts.IsKnownBuiltinModuleMember(member.ModuleName, member.MemberName), member.ToString());
            Assert.True(StaticContracts.TryGetKnownCallContract(target, out _), target);
        }
    }

"""+s[i:]
tests.write_text(s,encoding="utf-8",newline="\n")
