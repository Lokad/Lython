from pathlib import Path
import re
import subprocess

root = Path(".git/agent-worktrees/frontend-contract-sections-20261123")
frontend = root / "src/Lokad.Lython/Frontend"

def baseline(name):
    return subprocess.check_output(["git", "-C", str(root), "show", "HEAD:src/Lokad.Lython/Frontend/" + name]).decode("utf-8")

def write(path, source):
    path.write_text(source, encoding="utf-8", newline="\n")

modules_path = frontend / "StaticContracts.Modules.cs"
base = baseline(modules_path.name)
s = modules_path.read_text(encoding="utf-8")
fields = base[base.index("    private static readonly Dictionary"):base.index("    private static readonly string[] KnownBuiltinModuleNames")].rstrip()
fields = fields.replace("private static readonly", "internal static readonly")
fields = fields.replace("ModuleSurfaces", "Surfaces").replace("ModuleMemberModules", "Submodules").replace("ModuleMemberCallableAliases", "CallableAliases")
helpers = s[s.index("    private static BuiltinModuleSurface Members"):].rstrip()
assert helpers.endswith("}")
write(modules_path, base[:base.index("internal static partial class StaticContracts")] + """// Keep module metadata independent of method and return-type contracts.
internal static class StaticModuleCatalog
{
""" + fields + """

    internal static readonly IReadOnlyList<string> Names = Surfaces.Keys.Order(StringComparer.Ordinal).ToArray();

""" + helpers + """

internal static partial class StaticContracts
{
""" + s[s.index("    public static bool IsKnownBuiltinModule("):s.index("    private static BuiltinModuleSurface Members")].replace("ModuleCatalog.", "StaticModuleCatalog.").replace("new ModuleMemberName(", "new StaticModuleCatalog.ModuleMemberName(").rstrip() + "\n}\n")

core_path = frontend / "StaticContracts.CoreMemberSurfaces.cs"
noncore_path = frontend / "StaticContracts.MemberSurfaces.cs"
base_core = baseline(core_path.name)
base_noncore = baseline(noncore_path.name)

def surface_fields(source, first, end):
    start = source.index("    private static readonly HashSet<string> " + first)
    stop = source.index(end, start)
    data = source[start:stop].rstrip()
    fields = re.findall(r"HashSet<string> (\w+) =", data)
    return data.replace("private static readonly", "internal static readonly"), fields

core, core_names = surface_fields(base_core, "NoneMembers", "    public static bool IsKnownMissingMember")
library, library_names = surface_fields(base_noncore, "RegexPatternMembers", "    private static readonly HashSet<string> OpenPyxlWorkbookMembers")
workbook, workbook_names = surface_fields(base_noncore, "OpenPyxlWorkbookMembers", "\n}")
method = base_core[base_core.index("    public static bool IsKnownMissingMember"):]
for owner, names in [
    ("StaticCoreMemberSurfaces", core_names),
    ("StaticLibraryMemberSurfaces", library_names),
    ("StaticWorkbookMemberSurfaces", workbook_names),
]:
    for name in names:
        method = re.sub(rf"\b{name}(?=\.Contains)", f"{owner}.{name}", method)

write(core_path, "namespace Lokad.Lython.Frontend;\n\ninternal static class StaticCoreMemberSurfaces\n{\n" + core +
    "\n}\n\ninternal static partial class StaticContracts\n{\n" + method)
write(noncore_path, "namespace Lokad.Lython.Frontend;\n\ninternal static class StaticLibraryMemberSurfaces\n{\n" + library +
    "\n}\n\ninternal static class StaticWorkbookMemberSurfaces\n{\n" + workbook + "\n}\n")

callables_path = frontend / "StaticContracts.CallableMembers.cs"
base = baseline(callables_path.name)
s = callables_path.read_text(encoding="utf-8")
entry_helpers = base[base.index("        static void AddStringCallableContracts("):]
s = s[:s.index("        static void AddStringCallableContracts(")] + entry_helpers
start = s.index("        var contracts = new Dictionary")
end = s.index("        static void AddStringCallableContracts(")
s = s[:start] + """        var stringsAndLists = new List<StaticCallableContract>();
        AddStringCallableContracts(stringsAndLists);
        AddListCallableContracts(stringsAndLists);

        var contracts = new Dictionary<StaticMemberContractKey, StaticCallableContract>(
            core.Length + data.Length + library.Length + stringsAndLists.Count);
        AddContracts(core);
        AddContracts(data);
        AddContracts(library);
        AddContracts(CollectionsMarshal.AsSpan(stringsAndLists));
        return contracts;

        void AddContracts(ReadOnlySpan<StaticCallableContract> members)
        {
            foreach (var member in members)
                contracts.Add(new(member.ReceiverKind, member.MemberName), member);
        }

""" + s[end:]
s = s.replace("        AddContracts(CollectionsMarshal.AsSpan(stringsAndLists));",
              "        foreach (var member in stringsAndLists)\n            contracts.Add(new(member.ReceiverKind, member.MemberName), member);")
write(callables_path,s)

tests=root/"tests/Lokad.Lython.Tests/ModuleContractParityTests.cs"
s=tests.read_text(encoding="utf-8").replace("StaticContracts.ModuleCatalog.", "StaticModuleCatalog.")
write(tests,s)
