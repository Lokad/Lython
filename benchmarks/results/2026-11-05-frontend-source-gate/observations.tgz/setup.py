from pathlib import Path
import hashlib,json,shutil
r=Path('/home/lokad/lython-bench-checks/frontend-source-gate-b237-20261105')
b=Path('/home/lokad/lython-bench-checks/json-container-final-b236-20261105/candidate')
assert shutil.disk_usage(r).free>64*1024*1024
i=json.loads((r/'identity.json').read_text(encoding='utf-8'))
for n,h in i['files'].items():assert hashlib.sha256((b/n).read_bytes()).hexdigest()==h
(r/'candidate').symlink_to(b,target_is_directory=True)
