; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 960
       lea      rbp, [rsp+0x3C0]
       vxorps   xmm8, xmm8, xmm8
       vmovdqa32 xmmword ptr [rbp-0x3A0], xmm8
       vmovdqa32 xmmword ptr [rbp-0x390], xmm8
       mov      rax, -816
 
G_M000_IG97:                ;; offset=0x002D
       vmovdqa  xmmword ptr [rbp+rax-0x50], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG97
       mov      qword ptr [rbp-0x50], rax
       mov      bword ptr [rbp-0x30], rdi
       mov      gword ptr [rbp-0x38], rsi
       mov      gword ptr [rbp-0x40], rdx
       mov      bword ptr [rbp-0x48], rcx
 
G_M000_IG02:                ;; offset=0x0059
       mov      dword ptr [rbp-0x2BC], 0x3E8
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       lea      rdi, bword ptr [rax+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x174], eax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      eax, dword ptr [rbp-0x174]
       jne      SHORT G_M000_IG04
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       lea      rdi, bword ptr [rax+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG06
 
G_M000_IG03:                ;; offset=0x00A7
       mov      rdi, 0x75E363F76F70
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x00B6
       mov      rdi, 0x75E363F76F74
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG05:                ;; offset=0x00C7
       add      rsp, 960
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x00D0
       mov      rax, bword ptr [rbp-0x30]
       mov      eax, dword ptr [rax+0x20]
       mov      dword ptr [rbp-0x4C], eax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DictionaryLoopCallIndex():int:this]
       mov      dword ptr [rbp-0x50], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x180], rax
       mov      rax, gword ptr [rbp-0x180]
       mov      gword ptr [rbp-0x2A0], rax
       mov      rdi, gword ptr [rbp-0x2A0]
       mov      rsi, 0x75E363F76F78
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x2A0]
       mov      gword ptr [rbp-0x2C8], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x50]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG82
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdi, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x2CC], eax
       mov      rdi, gword ptr [rbp-0x2C8]
       mov      esi, dword ptr [rbp-0x2CC]
       mov      r11, 0x75E361642248
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x58], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x4C]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG82
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x60], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x50]
       inc      ecx
       cmp      ecx, dword ptr [rax+0x08]
 
G_M000_IG07:                ;; offset=0x01C6
       jae      G_M000_IG82
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x68], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x50]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG82
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x70], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Collections.Generic.IReadOnlyList`1[System.Object]:this]
       mov      gword ptr [rbp-0x188], rax
       mov      rax, gword ptr [rbp-0x188]
       mov      gword ptr [rbp-0x2A8], rax
       mov      rdi, gword ptr [rbp-0x2A8]
       mov      rsi, 0x75E363F77080
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x2A8]
       mov      gword ptr [rbp-0x2D8], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x4C]
       add      ecx, 4
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG82
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdi, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      dword ptr [rbp-0x2DC], eax
       mov      rdi, gword ptr [rbp-0x2D8]
       mov      esi, dword ptr [rbp-0x2DC]
       mov      r11, 0x75E361642250
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x78], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Collections.Generic.IReadOnlyList`1[System.Object]:this]
       mov      gword ptr [rbp-0x190], rax
       mov      rax, gword ptr [rbp-0x190]
       mov      gword ptr [rbp-0x2B0], rax
 
G_M000_IG08:                ;; offset=0x02CA
       mov      rdi, gword ptr [rbp-0x2B0]
       mov      rsi, 0x75E363F77188
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x2B0]
       mov      gword ptr [rbp-0x2E8], rax
       mov      rdi, bword ptr [rbp-0x68]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      dword ptr [rbp-0x2EC], eax
       mov      rdi, gword ptr [rbp-0x2E8]
       mov      esi, dword ptr [rbp-0x2EC]
       mov      r11, 0x75E361642258
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x2F8], rax
       mov      rsi, gword ptr [rbp-0x2F8]
       mov      rdi, 0x75E363C2B158
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG09:                ;; offset=0x0338
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x88], xmm0
 
G_M000_IG10:                ;; offset=0x0344
       mov      eax, dword ptr [rbp-0x50]
       add      eax, 3
       mov      dword ptr [rbp-0x8C], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x8C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG82
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdi, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 48
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x90], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x8C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG82
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x98], rax
       cmp      dword ptr [rbp-0x90], 0
       jne      SHORT G_M000_IG13
       call     [System.Numerics.BigInteger:get_Zero():System.Numerics.BigInteger]
       mov      gword ptr [rbp-0x298], rax
       mov      qword ptr [rbp-0x290], rdx
 
G_M000_IG11:                ;; offset=0x03DE
       vmovdqu  xmm0, xmmword ptr [rbp-0x298]
       vmovdqu  xmmword ptr [rbp-0x1A8], xmm0
 
G_M000_IG12:                ;; offset=0x03EE
       jmp      G_M000_IG15
 
G_M000_IG13:                ;; offset=0x03F3
       mov      rdi, 0x75E363F77290
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Collections.Generic.IReadOnlyList`1[System.Object]:this]
       mov      gword ptr [rbp-0x198], rax
       mov      rax, gword ptr [rbp-0x198]
       mov      gword ptr [rbp-0x2B8], rax
       mov      rdi, gword ptr [rbp-0x2B8]
       mov      rsi, 0x75E363F77298
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x2B8]
       mov      gword ptr [rbp-0x300], rax
       mov      rdi, bword ptr [rbp-0x98]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      dword ptr [rbp-0x304], eax
       mov      rdi, gword ptr [rbp-0x300]
       mov      esi, dword ptr [rbp-0x304]
       mov      r11, 0x75E361642260
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x310], rax
       mov      rsi, gword ptr [rbp-0x310]
       mov      rdi, 0x75E363C2B158
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG14:                ;; offset=0x0497
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x1A8], xmm0
 
G_M000_IG15:                ;; offset=0x04A3
       vmovdqu  xmm0, xmmword ptr [rbp-0x1A8]
       vmovdqu  xmmword ptr [rbp-0xA8], xmm0
 
G_M000_IG16:                ;; offset=0x04B3
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_RequiresLocalVariableMirroring():bool:this]
       test     eax, eax
       jne      G_M000_IG22
       cmp      gword ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG17
       mov      dword ptr [rbp-0x27C], 1
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x04DD
       mov      rdi, 0x75E363F773A0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorLocalStores():bool:this]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x27C], eax
 
G_M000_IG18:                ;; offset=0x0504
       cmp      dword ptr [rbp-0x27C], 0
       je       SHORT G_M000_IG19
       cmp      gword ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG20
       xor      rax, rax
       mov      gword ptr [rbp-0x288], rax
       jmp      SHORT G_M000_IG21
 
G_M000_IG19:                ;; offset=0x051F
       mov      rdi, 0x75E363F773A4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG22
 
G_M000_IG20:                ;; offset=0x0530
       mov      rdi, 0x75E363F773A8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x40]
       mov      rax, gword ptr [rax+0x90]
       mov      gword ptr [rbp-0x288], rax
 
G_M000_IG21:                ;; offset=0x0551
       mov      rdi, 0x75E363F773AC
       call     CORINFO_HELP_COUNTPROFILE32
       cmp      gword ptr [rbp-0x288], 0
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x1AC], eax
       jmp      SHORT G_M000_IG23
 
G_M000_IG22:                ;; offset=0x0576
       xor      eax, eax
       mov      dword ptr [rbp-0x1AC], eax
 
G_M000_IG23:                ;; offset=0x057E
       movzx    rax, byte  ptr [rbp-0x1AC]
       mov      dword ptr [rbp-0xAC], eax
       mov      eax, dword ptr [rbp-0x90]
       and      eax, dword ptr [rbp-0xAC]
       mov      dword ptr [rbp-0xB0], eax
       cmp      dword ptr [rbp-0xAC], 0
       jne      SHORT G_M000_IG24
       xor      rax, rax
       mov      gword ptr [rbp-0x1C0], rax
       jmp      SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x05B1
       mov      rdi, 0x75E363F773B0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 40
       mov      bword ptr [rbp-0x1B8], rax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x314], eax
       mov      esi, dword ptr [rbp-0x314]
       mov      rdi, bword ptr [rbp-0x1B8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x320], rax
       mov      rsi, gword ptr [rbp-0x320]
       mov      rdi, 0x75E363F58E40
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x1C0], rax
 
G_M000_IG25:                ;; offset=0x061D
       mov      rax, gword ptr [rbp-0x1C0]
       mov      gword ptr [rbp-0xB8], rax
       cmp      gword ptr [rbp-0xB8], 0
       je       SHORT G_M000_IG26
       mov      rdi, gword ptr [rbp-0xB8]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x278], rax
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       cmp      rax, gword ptr [rbp-0x278]
       je       SHORT G_M000_IG28
       mov      rdi, 0x75E363F773B4
       call     CORINFO_HELP_COUNTPROFILE32
       xor      rax, rax
       mov      gword ptr [rbp-0xB8], rax
 
G_M000_IG26:                ;; offset=0x0678
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x324], eax
       mov      edx, dword ptr [rbp-0x324]
       lea      r8, [rbp-0xD8]
       lea      rcx, [rbp-0xD0]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryReadDictionaryWord(byref,Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration,int,byref,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG29
       mov      rdi, 0x75E363F773B8
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG27:                ;; offset=0x06C2
       add      rsp, 960
       pop      rbp
       ret      
 
G_M000_IG28:                ;; offset=0x06CB
       mov      rdi, 0x75E363F773BC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG26
 
G_M000_IG29:                ;; offset=0x06DC
       movzx    rax, byte  ptr [rbp-0xD8]
       test     eax, eax
       jne      SHORT G_M000_IG31
       mov      rdi, 0x75E363F773C0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 40
       mov      bword ptr [rbp-0x270], rax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x328], eax
       mov      esi, dword ptr [rbp-0x328]
       mov      rdi, bword ptr [rbp-0x270]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x20], eax
       mov      eax, 1
 
G_M000_IG30:                ;; offset=0x0744
       add      rsp, 960
       pop      rbp
       ret      
 
G_M000_IG31:                ;; offset=0x074D
       xor      eax, eax
       mov      dword ptr [rbp-0xDC], eax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
       vmovdqu32 xmmword ptr [rbp-0xF0], xmm0
       xor      eax, eax
       mov      dword ptr [rbp-0xFC], eax
       xor      eax, eax
       mov      qword ptr [rbp-0x108], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x10C], eax
 
G_M000_IG32:                ;; offset=0x0781
       mov      eax, dword ptr [rbp-0x2BC]
       dec      eax
       mov      dword ptr [rbp-0x2BC], eax
       cmp      dword ptr [rbp-0x2BC], 0
       jg       SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x0798
       lea      rdi, [rbp-0x2BC]
       mov      esi, 506
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG34:                ;; offset=0x07AB
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x4C]
       mov      dword ptr [rax+0x20], ecx
       cmp      gword ptr [rbp-0xD0], 0
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x110], eax
       cmp      dword ptr [rbp-0x110], 0
       je       SHORT G_M000_IG37
 
G_M000_IG35:                ;; offset=0x07D2
       vmovdqu32 xmm0, xmmword ptr [rbp-0xD0]
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
       mov      rax, qword ptr [rbp-0xC0]
       mov      qword ptr [rbp-0xE8], rax
 
G_M000_IG36:                ;; offset=0x07EF
       mov      dword ptr [rbp-0xDC], 1
       jmp      SHORT G_M000_IG38
 
G_M000_IG37:                ;; offset=0x07FB
       mov      rdi, 0x75E363F773C4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, gword ptr [rbp-0x40]
       mov      rdx, bword ptr [rbp-0x48]
       mov      rcx, gword ptr [rbp-0xD0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       xor      eax, eax
       mov      dword ptr [rbp-0xDC], eax
 
G_M000_IG38:                ;; offset=0x082B
       mov      rdi, bword ptr [rbp-0x60]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x330], rax
       mov      rsi, gword ptr [rbp-0x330]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rdi, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      rcx, gword ptr [rbp-0x1C8]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG71
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x338], rax
       mov      rsi, gword ptr [rbp-0x338]
       mov      rdi, 0x75E363EDEBC0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x118], rax
       cmp      dword ptr [rbp-0x110], 0
       jne      SHORT G_M000_IG39
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x230], rax
       mov      rdi, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ThirdInput():int:this]
       mov      rcx, gword ptr [rbp-0x230]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG71
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x340], rax
       mov      rsi, gword ptr [rbp-0x340]
       mov      rdi, 0x75E363D43E58
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x1D0], rax
       jmp      SHORT G_M000_IG40
 
G_M000_IG39:                ;; offset=0x090A
       mov      rdi, 0x75E363F773C8
       call     CORINFO_HELP_COUNTPROFILE32
       xor      rax, rax
       mov      gword ptr [rbp-0x1D0], rax
 
G_M000_IG40:                ;; offset=0x0922
       mov      rax, gword ptr [rbp-0x1D0]
       mov      gword ptr [rbp-0x120], rax
       cmp      dword ptr [rbp-0x90], 0
       jne      SHORT G_M000_IG41
       xor      rax, rax
       mov      gword ptr [rbp-0x1E0], rax
       jmp      SHORT G_M000_IG42
 
G_M000_IG41:                ;; offset=0x0944
       mov      rdi, 0x75E363F773CC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rdi, bword ptr [rbp-0x98]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x1D8]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG71
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x1E0], rax
 
G_M000_IG42:                ;; offset=0x0990
       mov      rax, gword ptr [rbp-0x1E0]
       mov      gword ptr [rbp-0x128], rax
       cmp      gword ptr [rbp-0x118], 0
       je       G_M000_IG48
       cmp      dword ptr [rbp-0x110], 0
       jne      SHORT G_M000_IG44
       cmp      gword ptr [rbp-0x120], 0
       je       G_M000_IG51
 
G_M000_IG43:                ;; offset=0x09C3
       mov      rdi, 0x75E363F773D0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG44:                ;; offset=0x09D2
       cmp      dword ptr [rbp-0x90], 0
       je       G_M000_IG52
       mov      rsi, gword ptr [rbp-0x128]
       mov      rdi, 0x75E363C2B158
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG50
       mov      rsi, gword ptr [rbp-0x128]
       mov      rdi, 0x75E363C2B158
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG45:                ;; offset=0x0A12
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x138], xmm0
 
G_M000_IG46:                ;; offset=0x0A1E
       lea      rdi, [rbp-0x138]
       xor      esi, esi
       call     [System.Numerics.BigInteger:GetByteCount(bool):int:this]
       cmp      eax, 8
       jl       SHORT G_M000_IG49
 
G_M000_IG47:                ;; offset=0x0A32
       mov      rdi, 0x75E363F773D4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG48:                ;; offset=0x0A41
       mov      eax, dword ptr [rbp-0x4C]
       add      eax, 2
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x20], eax
       mov      dword ptr [rbp-0x15C], 1
       jmp      G_M000_IG79
 
G_M000_IG49:                ;; offset=0x0A5D
       mov      rdi, 0x75E363F773D8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG52
 
G_M000_IG50:                ;; offset=0x0A6E
       mov      rdi, 0x75E363F773DC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG48
 
G_M000_IG51:                ;; offset=0x0A7F
       mov      rdi, 0x75E363F773E0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG48
 
G_M000_IG52:                ;; offset=0x0A90
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x50]
       mov      dword ptr [rax+0x20], ecx
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x348], rax
       mov      rsi, gword ptr [rbp-0x348]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG53:                ;; offset=0x0AC1
       cmp      dword ptr [rbp-0x110], 0
       jne      SHORT G_M000_IG54
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x350], rax
       mov      rax, gword ptr [rbp-0x350]
       mov      gword ptr [rsp], rax
       mov      rcx, gword ptr [rbp-0x88]
       mov      r8, qword ptr [rbp-0x80]
       mov      rsi, gword ptr [rbp-0x120]
       mov      rdx, gword ptr [rbp-0x78]
       mov      r9, gword ptr [rbp-0x38]
       mov      rdi, gword ptr [rbp-0x118]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateWithoutAdmission(Lokad.Lython.Runtime.Text.PyString,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       mov      dword ptr [rbp-0x1F4], eax
       jmp      G_M000_IG55
 
G_M000_IG54:                ;; offset=0x0B1C
       mov      rdi, 0x75E363F773E4
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdi, [rbp-0xD0]
       call     [Lokad.Lython.Runtime.Text.PyStringOps:CompactWordBytes(byref):System.ReadOnlySpan`1[byte]]
       mov      bword ptr [rbp-0x1F0], rax
       mov      qword ptr [rbp-0x1E8], rdx
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x358], rax
       mov      rax, gword ptr [rbp-0x358]
       mov      gword ptr [rsp+0x08], rax
       mov      r8, gword ptr [rbp-0x88]
       mov      r9, qword ptr [rbp-0x80]
       mov      rsi, bword ptr [rbp-0x1F0]
       mov      rdx, qword ptr [rbp-0x1E8]
       mov      rcx, gword ptr [rbp-0x78]
       mov      rax, gword ptr [rbp-0x38]
       mov      gword ptr [rsp], rax
       mov      rdi, gword ptr [rbp-0x118]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateInlineWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       mov      dword ptr [rbp-0x1F4], eax
 
G_M000_IG55:                ;; offset=0x0B9F
       movzx    rax, byte  ptr [rbp-0x1F4]
       mov      dword ptr [rbp-0x13C], eax
 
G_M000_IG56:                ;; offset=0x0BAC
       call     G_M000_IG83
       nop      
 
G_M000_IG57:                ;; offset=0x0BB2
       cmp      dword ptr [rbp-0x13C], 0
       jne      SHORT G_M000_IG58
       mov      rdi, 0x75E363F773EC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x4C]
       add      eax, 2
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x20], eax
       mov      dword ptr [rbp-0x15C], 1
       jmp      G_M000_IG77
 
G_M000_IG58:                ;; offset=0x0BE6
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 40
       mov      bword ptr [rbp-0x200], rax
       mov      rdi, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x35C], eax
       mov      esi, dword ptr [rbp-0x35C]
       mov      rdi, bword ptr [rbp-0x200]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       cmp      dword ptr [rbp-0x90], 0
       je       G_M000_IG69
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x8C]
       mov      dword ptr [rax+0x20], ecx
       mov      rdi, bword ptr [rbp-0x98]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x368], rax
       mov      rsi, gword ptr [rbp-0x368]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       cmp      dword ptr [rbp-0xB0], 0
       je       G_M000_IG66
       cmp      dword ptr [rbp-0xFC], 0
       jne      SHORT G_M000_IG61
       mov      rsi, gword ptr [rbp-0x128]
       mov      rdi, 0x75E363C2B158
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG59:                ;; offset=0x0C8C
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x378], xmm0
 
G_M000_IG60:                ;; offset=0x0C98
       mov      rdi, gword ptr [rbp-0x378]
       mov      rsi, qword ptr [rbp-0x370]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      qword ptr [rbp-0x228], rax
       jmp      SHORT G_M000_IG62
 
G_M000_IG61:                ;; offset=0x0CB5
       mov      rdi, 0x75E363F773F0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, qword ptr [rbp-0x108]
       mov      qword ptr [rbp-0x228], rax
 
G_M000_IG62:                ;; offset=0x0CD2
       mov      rdi, gword ptr [rbp-0xA8]
       mov      rsi, qword ptr [rbp-0xA0]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       add      rax, qword ptr [rbp-0x228]
       mov      qword ptr [rbp-0x168], rax
       mov      rax, qword ptr [rbp-0x168]
       mov      qword ptr [rbp-0x108], rax
       mov      dword ptr [rbp-0xFC], 1
       mov      rax, 0xFF80000000000000
       cmp      qword ptr [rbp-0x168], rax
       jl       SHORT G_M000_IG64
       mov      rax, 0x80000000000000
       cmp      qword ptr [rbp-0x168], rax
       jl       SHORT G_M000_IG65
 
G_M000_IG63:                ;; offset=0x0D32
       mov      rdi, 0x75E363F773F4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG64:                ;; offset=0x0D41
       mov      rdi, 0x75E363F773F8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x8C]
       add      eax, 2
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x20], eax
       mov      dword ptr [rbp-0x15C], 1
       jmp      G_M000_IG78
 
G_M000_IG65:                ;; offset=0x0D6F
       mov      rdi, 0x75E363F773FC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG69
 
G_M000_IG66:                ;; offset=0x0D83
       mov      rdi, 0x75E363F77400
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rsi, gword ptr [rbp-0x128]
       mov      rdi, 0x75E363C2B158
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG67:                ;; offset=0x0DA9
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x218], xmm0
 
G_M000_IG68:                ;; offset=0x0DB5
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x220], rax
       mov      rdi, bword ptr [rbp-0x98]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x380], rax
       mov      r9, gword ptr [rbp-0x380]
       mov      rdi, gword ptr [rbp-0x218]
       mov      rsi, qword ptr [rbp-0x210]
       mov      rdx, gword ptr [rbp-0xA8]
       mov      rcx, qword ptr [rbp-0xA0]
       mov      r8, gword ptr [rbp-0x220]
       call     [Lokad.Lython.Runtime.LythonRuntime:AddExactIntegers(System.Numerics.BigInteger,System.Numerics.BigInteger,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x170], rax
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, gword ptr [rbp-0x40]
       mov      rdx, bword ptr [rbp-0x98]
       mov      rcx, gword ptr [rbp-0x170]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
 
G_M000_IG69:                ;; offset=0x0E2F
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x4C]
       mov      dword ptr [rax+0x20], ecx
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x388], rax
       mov      rsi, gword ptr [rbp-0x388]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x38C], eax
       mov      edx, dword ptr [rbp-0x38C]
       lea      r8, [rbp-0xD8]
       lea      rcx, [rbp-0x158]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryReadDictionaryWord(byref,Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration,int,byref,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG72
 
G_M000_IG70:                ;; offset=0x0E96
       mov      rdi, 0x75E362F77A68
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x208], rax
       mov      rdi, gword ptr [rbp-0x208]
       mov      rsi, 0x75E360218B68
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, gword ptr [rbp-0x208]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG71:                ;; offset=0x0ED0
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG72:                ;; offset=0x0ED6
       movzx    rax, byte  ptr [rbp-0xD8]
       test     eax, eax
       je       SHORT G_M000_IG75
       mov      rdi, 0x75E363F77404
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG73:                ;; offset=0x0EF0
       vmovdqu  xmm0, xmmword ptr [rbp-0x158]
       vmovdqu32 xmmword ptr [rbp-0xD0], xmm0
       mov      rax, qword ptr [rbp-0x148]
       mov      qword ptr [rbp-0xC0], rax
 
G_M000_IG74:                ;; offset=0x0F0D
       jmp      G_M000_IG32
 
G_M000_IG75:                ;; offset=0x0F12
       mov      rdi, 0x75E363F77408
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x10C], 1
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x20], eax
       mov      dword ptr [rbp-0x15C], 1
 
G_M000_IG76:                ;; offset=0x0F46
       call     G_M000_IG91
       jmp      SHORT G_M000_IG80
 
G_M000_IG77:                ;; offset=0x0F4D
       call     G_M000_IG91
       jmp      SHORT G_M000_IG80
 
G_M000_IG78:                ;; offset=0x0F54
       call     G_M000_IG91
       jmp      SHORT G_M000_IG80
 
G_M000_IG79:                ;; offset=0x0F5B
       call     G_M000_IG91
       nop      
 
G_M000_IG80:                ;; offset=0x0F61
       mov      rdi, 0x75E363F77420
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x15C]
 
G_M000_IG81:                ;; offset=0x0F76
       add      rsp, 960
       pop      rbp
       ret      
 
G_M000_IG82:                ;; offset=0x0F7F
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG83:                ;; offset=0x0F85
       sub      rsp, 24
 
G_M000_IG84:                ;; offset=0x0F89
       mov      rdi, 0x75E363F773E8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
       nop      
 
G_M000_IG85:                ;; offset=0x0FA5
       add      rsp, 24
       ret      
 
G_M000_IG86:                ;; offset=0x0FAA
       sub      rsp, 24
 
G_M000_IG87:                ;; offset=0x0FAE
       cmp      dword ptr [rbp-0xFC], 0
       je       G_M000_IG88
       mov      rdi, 0x75E363F77410
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x250], rax
       mov      rdi, bword ptr [rbp-0x98]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x264], eax
       lea      rdi, [rbp-0x260]
       mov      rsi, qword ptr [rbp-0x108]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rsi, [rbp-0x260]
       mov      rdi, 0x75E363C2B158
       call     [CORINFO_HELP_BOX]
       mov      gword ptr [rbp-0x3A0], rax
       mov      rdx, gword ptr [rbp-0x3A0]
       movsxd   rsi, dword ptr [rbp-0x264]
       mov      rdi, gword ptr [rbp-0x250]
       call     [CORINFO_HELP_ARRADDR_ST]
 
G_M000_IG88:                ;; offset=0x1039
       cmp      dword ptr [rbp-0x10C], 0
       je       SHORT G_M000_IG89
       mov      rdi, 0x75E363F77414
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 40
       mov      bword ptr [rbp-0x248], rax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x3A4], eax
       mov      esi, dword ptr [rbp-0x3A4]
       mov      rdi, bword ptr [rbp-0x248]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG89:                ;; offset=0x1089
       mov      rdi, 0x75E363F77418
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG90:                ;; offset=0x1099
       add      rsp, 24
       ret      
 
G_M000_IG91:                ;; offset=0x109E
       sub      rsp, 24
 
G_M000_IG92:                ;; offset=0x10A2
       cmp      dword ptr [rbp-0xDC], 0
       je       SHORT G_M000_IG93
       mov      rdi, 0x75E363F7740C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x238], rax
       mov      rdi, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ThirdInput():int:this]
       mov      dword ptr [rbp-0x23C], eax
       lea      rsi, [rbp-0xF8]
       mov      rdi, gword ptr [rbp-0xB8]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(byref):System.Object:this]
       mov      gword ptr [rbp-0x398], rax
       mov      rdx, gword ptr [rbp-0x398]
       movsxd   rsi, dword ptr [rbp-0x23C]
       mov      rdi, gword ptr [rbp-0x238]
       call     [CORINFO_HELP_ARRADDR_ST]
 
G_M000_IG93:                ;; offset=0x1111
       nop      
 
G_M000_IG94:                ;; offset=0x1112
       call     G_M000_IG86
       nop      
 
G_M000_IG95:                ;; offset=0x1118
       mov      rdi, 0x75E363F7741C
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG96:                ;; offset=0x1128
       add      rsp, 24
       ret      
 
; Total bytes of code 4397

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Instrumented Tier0 code
; rbp based frame
; fully interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 960
       lea      rbp, [rsp+0x3C0]
       vxorps   xmm8, xmm8, xmm8
       vmovdqa32 xmmword ptr [rbp-0x3A0], xmm8
       vmovdqa32 xmmword ptr [rbp-0x390], xmm8
       mov      rax, -816
 
G_M000_IG97:                ;; offset=0x002D
       vmovdqa  xmmword ptr [rbp+rax-0x50], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG97
       mov      qword ptr [rbp-0x50], rax
       mov      bword ptr [rbp-0x30], rdi
       mov      gword ptr [rbp-0x38], rsi
       mov      gword ptr [rbp-0x40], rdx
       mov      bword ptr [rbp-0x48], rcx
 
G_M000_IG02:                ;; offset=0x0059
       mov      dword ptr [rbp-0x2BC], 0x3E8
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       lea      rdi, bword ptr [rax+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x174], eax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ResultSlot():int:this]
       cmp      eax, dword ptr [rbp-0x174]
       jne      SHORT G_M000_IG04
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       lea      rdi, bword ptr [rax+0x28]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_HasPendingDisposals():bool:this]
       test     eax, eax
       je       SHORT G_M000_IG06
 
G_M000_IG03:                ;; offset=0x00A7
       mov      rdi, 0x75E363F76F70
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG04:                ;; offset=0x00B6
       mov      rdi, 0x75E363F76F74
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG05:                ;; offset=0x00C7
       add      rsp, 960
       pop      rbp
       ret      
 
G_M000_IG06:                ;; offset=0x00D0
       mov      rax, bword ptr [rbp-0x30]
       mov      eax, dword ptr [rax+0x20]
       mov      dword ptr [rbp-0x4C], eax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_DictionaryLoopCallIndex():int:this]
       mov      dword ptr [rbp-0x50], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_CallSites():System.Collections.Generic.IReadOnlyList`1[Lokad.Lython.Frontend.ExecutableCallSite]:this]
       mov      gword ptr [rbp-0x180], rax
       mov      rax, gword ptr [rbp-0x180]
       mov      gword ptr [rbp-0x2A0], rax
       mov      rdi, gword ptr [rbp-0x2A0]
       mov      rsi, 0x75E363F76F78
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x2A0]
       mov      gword ptr [rbp-0x2C8], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x50]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG82
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdi, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_CallSiteIndex():int:this]
       mov      dword ptr [rbp-0x2CC], eax
       mov      rdi, gword ptr [rbp-0x2C8]
       mov      esi, dword ptr [rbp-0x2CC]
       mov      r11, 0x75E3616426F0
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x58], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x4C]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG82
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x60], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x50]
       inc      ecx
       cmp      ecx, dword ptr [rax+0x08]
 
G_M000_IG07:                ;; offset=0x01C6
       jae      G_M000_IG82
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x68], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x50]
       add      ecx, 2
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG82
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x70], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Collections.Generic.IReadOnlyList`1[System.Object]:this]
       mov      gword ptr [rbp-0x188], rax
       mov      rax, gword ptr [rbp-0x188]
       mov      gword ptr [rbp-0x2A8], rax
       mov      rdi, gword ptr [rbp-0x2A8]
       mov      rsi, 0x75E363F77080
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x2A8]
       mov      gword ptr [rbp-0x2D8], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x4C]
       add      ecx, 4
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG82
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdi, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ConstantIndex():int:this]
       mov      dword ptr [rbp-0x2DC], eax
       mov      rdi, gword ptr [rbp-0x2D8]
       mov      esi, dword ptr [rbp-0x2DC]
       mov      r11, 0x75E3616426F8
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x78], rax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Collections.Generic.IReadOnlyList`1[System.Object]:this]
       mov      gword ptr [rbp-0x190], rax
       mov      rax, gword ptr [rbp-0x190]
       mov      gword ptr [rbp-0x2B0], rax
 
G_M000_IG08:                ;; offset=0x02CA
       mov      rdi, gword ptr [rbp-0x2B0]
       mov      rsi, 0x75E363F77188
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x2B0]
       mov      gword ptr [rbp-0x2E8], rax
       mov      rdi, bword ptr [rbp-0x68]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      dword ptr [rbp-0x2EC], eax
       mov      rdi, gword ptr [rbp-0x2E8]
       mov      esi, dword ptr [rbp-0x2EC]
       mov      r11, 0x75E361642700
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x2F8], rax
       mov      rsi, gword ptr [rbp-0x2F8]
       mov      rdi, 0x75E363C2B158
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG09:                ;; offset=0x0338
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x88], xmm0
 
G_M000_IG10:                ;; offset=0x0344
       mov      eax, dword ptr [rbp-0x50]
       add      eax, 3
       mov      dword ptr [rbp-0x8C], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x8C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG82
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      rdi, rax
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_OpCode():int:this]
       cmp      eax, 48
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x90], eax
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Instructions():Lokad.Lython.Frontend.ExecutableInstruction[]:this]
       mov      ecx, dword ptr [rbp-0x8C]
       cmp      ecx, dword ptr [rax+0x08]
       jae      G_M000_IG82
       mov      edx, ecx
       imul     rdx, rdx, 32
       lea      rax, bword ptr [rax+rdx+0x10]
       mov      bword ptr [rbp-0x98], rax
       cmp      dword ptr [rbp-0x90], 0
       jne      SHORT G_M000_IG13
       call     [System.Numerics.BigInteger:get_Zero():System.Numerics.BigInteger]
       mov      gword ptr [rbp-0x298], rax
       mov      qword ptr [rbp-0x290], rdx
 
G_M000_IG11:                ;; offset=0x03DE
       vmovdqu  xmm0, xmmword ptr [rbp-0x298]
       vmovdqu  xmmword ptr [rbp-0x1A8], xmm0
 
G_M000_IG12:                ;; offset=0x03EE
       jmp      G_M000_IG15
 
G_M000_IG13:                ;; offset=0x03F3
       mov      rdi, 0x75E363F77290
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_Constants():System.Collections.Generic.IReadOnlyList`1[System.Object]:this]
       mov      gword ptr [rbp-0x198], rax
       mov      rax, gword ptr [rbp-0x198]
       mov      gword ptr [rbp-0x2B8], rax
       mov      rdi, gword ptr [rbp-0x2B8]
       mov      rsi, 0x75E363F77298
       call     CORINFO_HELP_CLASSPROFILE32
       mov      rax, gword ptr [rbp-0x2B8]
       mov      gword ptr [rbp-0x300], rax
       mov      rdi, bword ptr [rbp-0x98]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       not      eax
       mov      dword ptr [rbp-0x304], eax
       mov      rdi, gword ptr [rbp-0x300]
       mov      esi, dword ptr [rbp-0x304]
       mov      r11, 0x75E361642708
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      gword ptr [rbp-0x310], rax
       mov      rsi, gword ptr [rbp-0x310]
       mov      rdi, 0x75E363C2B158
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG14:                ;; offset=0x0497
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x1A8], xmm0
 
G_M000_IG15:                ;; offset=0x04A3
       vmovdqu  xmm0, xmmword ptr [rbp-0x1A8]
       vmovdqu  xmmword ptr [rbp-0xA8], xmm0
 
G_M000_IG16:                ;; offset=0x04B3
       mov      rax, bword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_RequiresLocalVariableMirroring():bool:this]
       test     eax, eax
       jne      G_M000_IG22
       cmp      gword ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG17
       mov      dword ptr [rbp-0x27C], 1
       jmp      SHORT G_M000_IG18
 
G_M000_IG17:                ;; offset=0x04DD
       mov      rdi, 0x75E363F773A0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MirrorLocalStores():bool:this]
       test     eax, eax
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x27C], eax
 
G_M000_IG18:                ;; offset=0x0504
       cmp      dword ptr [rbp-0x27C], 0
       je       SHORT G_M000_IG19
       cmp      gword ptr [rbp-0x40], 0
       jne      SHORT G_M000_IG20
       xor      rax, rax
       mov      gword ptr [rbp-0x288], rax
       jmp      SHORT G_M000_IG21
 
G_M000_IG19:                ;; offset=0x051F
       mov      rdi, 0x75E363F773A4
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG22
 
G_M000_IG20:                ;; offset=0x0530
       mov      rdi, 0x75E363F773A8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, gword ptr [rbp-0x40]
       mov      rax, gword ptr [rax+0x90]
       mov      gword ptr [rbp-0x288], rax
 
G_M000_IG21:                ;; offset=0x0551
       mov      rdi, 0x75E363F773AC
       call     CORINFO_HELP_COUNTPROFILE32
       cmp      gword ptr [rbp-0x288], 0
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x1AC], eax
       jmp      SHORT G_M000_IG23
 
G_M000_IG22:                ;; offset=0x0576
       xor      eax, eax
       mov      dword ptr [rbp-0x1AC], eax
 
G_M000_IG23:                ;; offset=0x057E
       movzx    rax, byte  ptr [rbp-0x1AC]
       mov      dword ptr [rbp-0xAC], eax
       mov      eax, dword ptr [rbp-0x90]
       and      eax, dword ptr [rbp-0xAC]
       mov      dword ptr [rbp-0xB0], eax
       cmp      dword ptr [rbp-0xAC], 0
       jne      SHORT G_M000_IG24
       xor      rax, rax
       mov      gword ptr [rbp-0x1C0], rax
       jmp      SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x05B1
       mov      rdi, 0x75E363F773B0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 40
       mov      bword ptr [rbp-0x1B8], rax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x314], eax
       mov      esi, dword ptr [rbp-0x314]
       mov      rdi, bword ptr [rbp-0x1B8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:get_Item(int):System.Object:this]
       mov      gword ptr [rbp-0x320], rax
       mov      rsi, gword ptr [rbp-0x320]
       mov      rdi, 0x75E363F58E40
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x1C0], rax
 
G_M000_IG25:                ;; offset=0x061D
       mov      rax, gword ptr [rbp-0x1C0]
       mov      gword ptr [rbp-0xB8], rax
       cmp      gword ptr [rbp-0xB8], 0
       je       SHORT G_M000_IG26
       mov      rdi, gword ptr [rbp-0xB8]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x278], rax
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       cmp      rax, gword ptr [rbp-0x278]
       je       SHORT G_M000_IG28
       mov      rdi, 0x75E363F773B4
       call     CORINFO_HELP_COUNTPROFILE32
       xor      rax, rax
       mov      gword ptr [rbp-0xB8], rax
 
G_M000_IG26:                ;; offset=0x0678
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x324], eax
       mov      edx, dword ptr [rbp-0x324]
       lea      r8, [rbp-0xD8]
       lea      rcx, [rbp-0xD0]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryReadDictionaryWord(byref,Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration,int,byref,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG29
       mov      rdi, 0x75E363F773B8
       call     CORINFO_HELP_COUNTPROFILE32
       xor      eax, eax
 
G_M000_IG27:                ;; offset=0x06C2
       add      rsp, 960
       pop      rbp
       ret      
 
G_M000_IG28:                ;; offset=0x06CB
       mov      rdi, 0x75E363F773BC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG26
 
G_M000_IG29:                ;; offset=0x06DC
       movzx    rax, byte  ptr [rbp-0xD8]
       test     eax, eax
       jne      SHORT G_M000_IG31
       mov      rdi, 0x75E363F773C0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 40
       mov      bword ptr [rbp-0x270], rax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x328], eax
       mov      esi, dword ptr [rbp-0x328]
       mov      rdi, bword ptr [rbp-0x270]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x20], eax
       mov      eax, 1
 
G_M000_IG30:                ;; offset=0x0744
       add      rsp, 960
       pop      rbp
       ret      
 
G_M000_IG31:                ;; offset=0x074D
       xor      eax, eax
       mov      dword ptr [rbp-0xDC], eax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
       vmovdqu32 xmmword ptr [rbp-0xF0], xmm0
       xor      eax, eax
       mov      dword ptr [rbp-0xFC], eax
       xor      eax, eax
       mov      qword ptr [rbp-0x108], rax
       xor      eax, eax
       mov      dword ptr [rbp-0x10C], eax
 
G_M000_IG32:                ;; offset=0x0781
       mov      eax, dword ptr [rbp-0x2BC]
       dec      eax
       mov      dword ptr [rbp-0x2BC], eax
       cmp      dword ptr [rbp-0x2BC], 0
       jg       SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x0798
       lea      rdi, [rbp-0x2BC]
       mov      esi, 506
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG34:                ;; offset=0x07AB
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x4C]
       mov      dword ptr [rax+0x20], ecx
       cmp      gword ptr [rbp-0xD0], 0
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x110], eax
       cmp      dword ptr [rbp-0x110], 0
       je       SHORT G_M000_IG37
 
G_M000_IG35:                ;; offset=0x07D2
       vmovdqu32 xmm0, xmmword ptr [rbp-0xD0]
       vmovdqu  xmmword ptr [rbp-0xF8], xmm0
       mov      rax, qword ptr [rbp-0xC0]
       mov      qword ptr [rbp-0xE8], rax
 
G_M000_IG36:                ;; offset=0x07EF
       mov      dword ptr [rbp-0xDC], 1
       jmp      SHORT G_M000_IG38
 
G_M000_IG37:                ;; offset=0x07FB
       mov      rdi, 0x75E363F773C4
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, gword ptr [rbp-0x40]
       mov      rdx, bword ptr [rbp-0x48]
       mov      rcx, gword ptr [rbp-0xD0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       xor      eax, eax
       mov      dword ptr [rbp-0xDC], eax
 
G_M000_IG38:                ;; offset=0x082B
       mov      rdi, bword ptr [rbp-0x60]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x330], rax
       mov      rsi, gword ptr [rbp-0x330]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rdi, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_SecondInput():int:this]
       mov      rcx, gword ptr [rbp-0x1C8]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG71
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x338], rax
       mov      rsi, gword ptr [rbp-0x338]
       mov      rdi, 0x75E363EDEBC0
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x118], rax
       cmp      dword ptr [rbp-0x110], 0
       jne      SHORT G_M000_IG39
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x230], rax
       mov      rdi, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ThirdInput():int:this]
       mov      rcx, gword ptr [rbp-0x230]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG71
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x340], rax
       mov      rsi, gword ptr [rbp-0x340]
       mov      rdi, 0x75E363D43E58
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       mov      gword ptr [rbp-0x1D0], rax
       jmp      SHORT G_M000_IG40
 
G_M000_IG39:                ;; offset=0x090A
       mov      rdi, 0x75E363F773C8
       call     CORINFO_HELP_COUNTPROFILE32
       xor      rax, rax
       mov      gword ptr [rbp-0x1D0], rax
 
G_M000_IG40:                ;; offset=0x0922
       mov      rax, gword ptr [rbp-0x1D0]
       mov      gword ptr [rbp-0x120], rax
       cmp      dword ptr [rbp-0x90], 0
       jne      SHORT G_M000_IG41
       xor      rax, rax
       mov      gword ptr [rbp-0x1E0], rax
       jmp      SHORT G_M000_IG42
 
G_M000_IG41:                ;; offset=0x0944
       mov      rdi, 0x75E363F773CC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x1D8], rax
       mov      rdi, bword ptr [rbp-0x98]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      rcx, gword ptr [rbp-0x1D8]
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG71
       mov      edx, eax
       lea      rcx, bword ptr [rcx+8*rdx+0x10]
       mov      rax, gword ptr [rcx]
       mov      gword ptr [rbp-0x1E0], rax
 
G_M000_IG42:                ;; offset=0x0990
       mov      rax, gword ptr [rbp-0x1E0]
       mov      gword ptr [rbp-0x128], rax
       cmp      gword ptr [rbp-0x118], 0
       je       G_M000_IG48
       cmp      dword ptr [rbp-0x110], 0
       jne      SHORT G_M000_IG44
       cmp      gword ptr [rbp-0x120], 0
       je       G_M000_IG51
 
G_M000_IG43:                ;; offset=0x09C3
       mov      rdi, 0x75E363F773D0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG44:                ;; offset=0x09D2
       cmp      dword ptr [rbp-0x90], 0
       je       G_M000_IG52
       mov      rsi, gword ptr [rbp-0x128]
       mov      rdi, 0x75E363C2B158
       call     [CORINFO_HELP_ISINSTANCEOFCLASS]
       test     rax, rax
       je       SHORT G_M000_IG50
       mov      rsi, gword ptr [rbp-0x128]
       mov      rdi, 0x75E363C2B158
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG45:                ;; offset=0x0A12
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x138], xmm0
 
G_M000_IG46:                ;; offset=0x0A1E
       lea      rdi, [rbp-0x138]
       xor      esi, esi
       call     [System.Numerics.BigInteger:GetByteCount(bool):int:this]
       cmp      eax, 8
       jl       SHORT G_M000_IG49
 
G_M000_IG47:                ;; offset=0x0A32
       mov      rdi, 0x75E363F773D4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG48:                ;; offset=0x0A41
       mov      eax, dword ptr [rbp-0x4C]
       add      eax, 2
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x20], eax
       mov      dword ptr [rbp-0x15C], 1
       jmp      G_M000_IG79
 
G_M000_IG49:                ;; offset=0x0A5D
       mov      rdi, 0x75E363F773D8
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG52
 
G_M000_IG50:                ;; offset=0x0A6E
       mov      rdi, 0x75E363F773DC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG48
 
G_M000_IG51:                ;; offset=0x0A7F
       mov      rdi, 0x75E363F773E0
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      SHORT G_M000_IG48
 
G_M000_IG52:                ;; offset=0x0A90
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x50]
       mov      dword ptr [rax+0x20], ecx
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x348], rax
       mov      rsi, gword ptr [rbp-0x348]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG53:                ;; offset=0x0AC1
       cmp      dword ptr [rbp-0x110], 0
       jne      SHORT G_M000_IG54
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x350], rax
       mov      rax, gword ptr [rbp-0x350]
       mov      gword ptr [rsp], rax
       mov      rcx, gword ptr [rbp-0x88]
       mov      r8, qword ptr [rbp-0x80]
       mov      rsi, gword ptr [rbp-0x120]
       mov      rdx, gword ptr [rbp-0x78]
       mov      r9, gword ptr [rbp-0x38]
       mov      rdi, gword ptr [rbp-0x118]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateWithoutAdmission(Lokad.Lython.Runtime.Text.PyString,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       mov      dword ptr [rbp-0x1F4], eax
       jmp      G_M000_IG55
 
G_M000_IG54:                ;; offset=0x0B1C
       mov      rdi, 0x75E363F773E4
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdi, [rbp-0xD0]
       call     [Lokad.Lython.Runtime.Text.PyStringOps:CompactWordBytes(byref):System.ReadOnlySpan`1[byte]]
       mov      bword ptr [rbp-0x1F0], rax
       mov      qword ptr [rbp-0x1E8], rdx
       mov      rdi, gword ptr [rbp-0x58]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCallSite:get_CallSpan():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x358], rax
       mov      rax, gword ptr [rbp-0x358]
       mov      gword ptr [rsp+0x08], rax
       mov      r8, gword ptr [rbp-0x88]
       mov      r9, qword ptr [rbp-0x80]
       mov      rsi, bword ptr [rbp-0x1F0]
       mov      rdx, qword ptr [rbp-0x1E8]
       mov      rcx, gword ptr [rbp-0x78]
       mov      rax, gword ptr [rbp-0x38]
       mov      gword ptr [rsp], rax
       mov      rdi, gword ptr [rbp-0x118]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateInlineWord(System.ReadOnlySpan`1[byte],System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       mov      dword ptr [rbp-0x1F4], eax
 
G_M000_IG55:                ;; offset=0x0B9F
       movzx    rax, byte  ptr [rbp-0x1F4]
       mov      dword ptr [rbp-0x13C], eax
 
G_M000_IG56:                ;; offset=0x0BAC
       call     G_M000_IG83
       nop      
 
G_M000_IG57:                ;; offset=0x0BB2
       cmp      dword ptr [rbp-0x13C], 0
       jne      SHORT G_M000_IG58
       mov      rdi, 0x75E363F773EC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x4C]
       add      eax, 2
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x20], eax
       mov      dword ptr [rbp-0x15C], 1
       jmp      G_M000_IG77
 
G_M000_IG58:                ;; offset=0x0BE6
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 40
       mov      bword ptr [rbp-0x200], rax
       mov      rdi, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       mov      dword ptr [rbp-0x35C], eax
       mov      esi, dword ptr [rbp-0x35C]
       mov      rdi, bword ptr [rbp-0x200]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       cmp      dword ptr [rbp-0x90], 0
       je       G_M000_IG69
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x8C]
       mov      dword ptr [rax+0x20], ecx
       mov      rdi, bword ptr [rbp-0x98]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x368], rax
       mov      rsi, gword ptr [rbp-0x368]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       cmp      dword ptr [rbp-0xB0], 0
       je       G_M000_IG66
       cmp      dword ptr [rbp-0xFC], 0
       jne      SHORT G_M000_IG61
       mov      rsi, gword ptr [rbp-0x128]
       mov      rdi, 0x75E363C2B158
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG59:                ;; offset=0x0C8C
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x378], xmm0
 
G_M000_IG60:                ;; offset=0x0C98
       mov      rdi, gword ptr [rbp-0x378]
       mov      rsi, qword ptr [rbp-0x370]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      qword ptr [rbp-0x228], rax
       jmp      SHORT G_M000_IG62
 
G_M000_IG61:                ;; offset=0x0CB5
       mov      rdi, 0x75E363F773F0
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, qword ptr [rbp-0x108]
       mov      qword ptr [rbp-0x228], rax
 
G_M000_IG62:                ;; offset=0x0CD2
       mov      rdi, gword ptr [rbp-0xA8]
       mov      rsi, qword ptr [rbp-0xA0]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       add      rax, qword ptr [rbp-0x228]
       mov      qword ptr [rbp-0x168], rax
       mov      rax, qword ptr [rbp-0x168]
       mov      qword ptr [rbp-0x108], rax
       mov      dword ptr [rbp-0xFC], 1
       mov      rax, 0xFF80000000000000
       cmp      qword ptr [rbp-0x168], rax
       jl       SHORT G_M000_IG64
       mov      rax, 0x80000000000000
       cmp      qword ptr [rbp-0x168], rax
       jl       SHORT G_M000_IG65
 
G_M000_IG63:                ;; offset=0x0D32
       mov      rdi, 0x75E363F773F4
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG64:                ;; offset=0x0D41
       mov      rdi, 0x75E363F773F8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x8C]
       add      eax, 2
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x20], eax
       mov      dword ptr [rbp-0x15C], 1
       jmp      G_M000_IG78
 
G_M000_IG65:                ;; offset=0x0D6F
       mov      rdi, 0x75E363F773FC
       call     CORINFO_HELP_COUNTPROFILE32
       jmp      G_M000_IG69
 
G_M000_IG66:                ;; offset=0x0D83
       mov      rdi, 0x75E363F77400
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rsi, gword ptr [rbp-0x128]
       mov      rdi, 0x75E363C2B158
       call     [CORINFO_HELP_UNBOX]
 
G_M000_IG67:                ;; offset=0x0DA9
       vmovdqu  xmm0, xmmword ptr [rax]
       vmovdqu  xmmword ptr [rbp-0x218], xmm0
 
G_M000_IG68:                ;; offset=0x0DB5
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:get_MemoryGovernor():Lokad.Lython.Runtime.MemoryGovernor:this]
       mov      gword ptr [rbp-0x220], rax
       mov      rdi, bword ptr [rbp-0x98]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x380], rax
       mov      r9, gword ptr [rbp-0x380]
       mov      rdi, gword ptr [rbp-0x218]
       mov      rsi, qword ptr [rbp-0x210]
       mov      rdx, gword ptr [rbp-0xA8]
       mov      rcx, qword ptr [rbp-0xA0]
       mov      r8, gword ptr [rbp-0x220]
       call     [Lokad.Lython.Runtime.LythonRuntime:AddExactIntegers(System.Numerics.BigInteger,System.Numerics.BigInteger,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rbp-0x170], rax
       mov      rdi, bword ptr [rbp-0x30]
       mov      rsi, gword ptr [rbp-0x40]
       mov      rdx, bword ptr [rbp-0x98]
       mov      rcx, gword ptr [rbp-0x170]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
 
G_M000_IG69:                ;; offset=0x0E2F
       mov      rax, bword ptr [rbp-0x30]
       mov      ecx, dword ptr [rbp-0x4C]
       mov      dword ptr [rax+0x20], ecx
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_Span():Lokad.Lython.LythonSourceSpan:this]
       mov      gword ptr [rbp-0x388], rax
       mov      rsi, gword ptr [rbp-0x388]
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:CheckExecution(Lokad.Lython.LythonSourceSpan):this]
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x38C], eax
       mov      edx, dword ptr [rbp-0x38C]
       lea      r8, [rbp-0xD8]
       lea      rcx, [rbp-0x158]
       mov      rsi, gword ptr [rbp-0xB8]
       mov      rdi, bword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryReadDictionaryWord(byref,Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration,int,byref,byref):bool]
       test     eax, eax
       jne      SHORT G_M000_IG72
 
G_M000_IG70:                ;; offset=0x0E96
       mov      rdi, 0x75E362F77A68
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x208], rax
       mov      rdi, gword ptr [rbp-0x208]
       mov      rsi, 0x75E360218B68
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, gword ptr [rbp-0x208]
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG71:                ;; offset=0x0ED0
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG72:                ;; offset=0x0ED6
       movzx    rax, byte  ptr [rbp-0xD8]
       test     eax, eax
       je       SHORT G_M000_IG75
       mov      rdi, 0x75E363F77404
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG73:                ;; offset=0x0EF0
       vmovdqu  xmm0, xmmword ptr [rbp-0x158]
       vmovdqu32 xmmword ptr [rbp-0xD0], xmm0
       mov      rax, qword ptr [rbp-0x148]
       mov      qword ptr [rbp-0xC0], rax
 
G_M000_IG74:                ;; offset=0x0F0D
       jmp      G_M000_IG32
 
G_M000_IG75:                ;; offset=0x0F12
       mov      rdi, 0x75E363F77408
       call     CORINFO_HELP_COUNTPROFILE32
       mov      dword ptr [rbp-0x10C], 1
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_TargetIndex():int:this]
       mov      rcx, bword ptr [rbp-0x30]
       mov      dword ptr [rcx+0x20], eax
       mov      dword ptr [rbp-0x15C], 1
 
G_M000_IG76:                ;; offset=0x0F46
       call     G_M000_IG91
       jmp      SHORT G_M000_IG80
 
G_M000_IG77:                ;; offset=0x0F4D
       call     G_M000_IG91
       jmp      SHORT G_M000_IG80
 
G_M000_IG78:                ;; offset=0x0F54
       call     G_M000_IG91
       jmp      SHORT G_M000_IG80
 
G_M000_IG79:                ;; offset=0x0F5B
       call     G_M000_IG91
       nop      
 
G_M000_IG80:                ;; offset=0x0F61
       mov      rdi, 0x75E363F77420
       call     CORINFO_HELP_COUNTPROFILE32
       mov      eax, dword ptr [rbp-0x15C]
 
G_M000_IG81:                ;; offset=0x0F76
       add      rsp, 960
       pop      rbp
       ret      
 
G_M000_IG82:                ;; offset=0x0F7F
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG83:                ;; offset=0x0F85
       sub      rsp, 24
 
G_M000_IG84:                ;; offset=0x0F89
       mov      rdi, 0x75E363F773E8
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x38]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:LeaveInterpreterFrame():this]
       nop      
 
G_M000_IG85:                ;; offset=0x0FA5
       add      rsp, 24
       ret      
 
G_M000_IG86:                ;; offset=0x0FAA
       sub      rsp, 24
 
G_M000_IG87:                ;; offset=0x0FAE
       cmp      dword ptr [rbp-0xFC], 0
       je       G_M000_IG88
       mov      rdi, 0x75E363F77410
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x250], rax
       mov      rdi, bword ptr [rbp-0x98]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x264], eax
       lea      rdi, [rbp-0x260]
       mov      rsi, qword ptr [rbp-0x108]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rsi, [rbp-0x260]
       mov      rdi, 0x75E363C2B158
       call     [CORINFO_HELP_BOX]
       mov      gword ptr [rbp-0x3A0], rax
       mov      rdx, gword ptr [rbp-0x3A0]
       movsxd   rsi, dword ptr [rbp-0x264]
       mov      rdi, gword ptr [rbp-0x250]
       call     [CORINFO_HELP_ARRADDR_ST]
 
G_M000_IG88:                ;; offset=0x1039
       cmp      dword ptr [rbp-0x10C], 0
       je       SHORT G_M000_IG89
       mov      rdi, 0x75E363F77414
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       cmp      byte  ptr [rax], al
       mov      rax, bword ptr [rbp-0x30]
       add      rax, 40
       mov      bword ptr [rbp-0x248], rax
       mov      rdi, bword ptr [rbp-0x48]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_InputStart():int:this]
       mov      dword ptr [rbp-0x3A4], eax
       mov      esi, dword ptr [rbp-0x3A4]
       mov      rdi, bword ptr [rbp-0x248]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG89:                ;; offset=0x1089
       mov      rdi, 0x75E363F77418
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG90:                ;; offset=0x1099
       add      rsp, 24
       ret      
 
G_M000_IG91:                ;; offset=0x109E
       sub      rsp, 24
 
G_M000_IG92:                ;; offset=0x10A2
       cmp      dword ptr [rbp-0xDC], 0
       je       SHORT G_M000_IG93
       mov      rdi, 0x75E363F7740C
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rax, bword ptr [rbp-0x30]
       mov      rax, gword ptr [rax+0x08]
       mov      gword ptr [rbp-0x238], rax
       mov      rdi, bword ptr [rbp-0x70]
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ThirdInput():int:this]
       mov      dword ptr [rbp-0x23C], eax
       lea      rsi, [rbp-0xF8]
       mov      rdi, gword ptr [rbp-0xB8]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:Materialize(byref):System.Object:this]
       mov      gword ptr [rbp-0x398], rax
       mov      rdx, gword ptr [rbp-0x398]
       movsxd   rsi, dword ptr [rbp-0x23C]
       mov      rdi, gword ptr [rbp-0x238]
       call     [CORINFO_HELP_ARRADDR_ST]
 
G_M000_IG93:                ;; offset=0x1111
       nop      
 
G_M000_IG94:                ;; offset=0x1112
       call     G_M000_IG86
       nop      
 
G_M000_IG95:                ;; offset=0x1118
       mov      rdi, 0x75E363F7741C
       call     CORINFO_HELP_COUNTPROFILE32
       nop      
 
G_M000_IG96:                ;; offset=0x1128
       add      rsp, 24
       ret      
 
; Total bytes of code 4397

; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:TryExecuteDictionaryLoop(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):bool (Tier1)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 709856
; 90 inlinees with PGO data; 211 single block inlinees; 12 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 840
       lea      rbp, [rsp+0x370]
       vxorps   xmm8, xmm8, xmm8
       vmovdqa32 xmmword ptr [rbp-0x1D0], xmm8
       mov      rax, -384
 
G_M000_IG355:                ;; offset=0x002F
       vmovdqa  xmmword ptr [rbp+rax-0x40], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x30], xmm8
       vmovdqa  xmmword ptr [rbp+rax-0x20], xmm8
       add      rax, 48
       jne      SHORT G_M000_IG355
       mov      qword ptr [rbp-0x40], rax
       mov      bword ptr [rbp-0x228], rdi
       mov      gword ptr [rbp-0x230], rsi
       mov      bword ptr [rbp-0x238], rcx
       mov      r15, rdx
       mov      rbx, rcx
 
G_M000_IG02:                ;; offset=0x0066
       mov      r14d, dword ptr [rdi+0x68]
       mov      eax, dword ptr [rbx+0x1C]
       cmp      eax, 52
       ja       SHORT G_M000_IG04
 
G_M000_IG03:                ;; offset=0x0072
       mov      rcx, 0xFFFFFFFFFE7FF
       bt       rcx, rax
       jae      G_M000_IG294
 
G_M000_IG04:                ;; offset=0x0086
       mov      eax, dword ptr [rbx+0x14]
 
G_M000_IG05:                ;; offset=0x0089
       cmp      r14d, eax
       jne      G_M000_IG295
       mov      rdi, bword ptr [rbp-0x228]
       cmp      gword ptr [rdi+0x48], 0
       jne      G_M000_IG295
       mov      r14d, dword ptr [rdi+0x20]
       cmp      dword ptr [rbx+0x1C], 69
       jne      G_M000_IG297
       mov      r13d, dword ptr [rbx+0x0C]
       mov      rsi, gword ptr [rdi]
       mov      rsi, gword ptr [rsi+0x68]
       mov      r11, gword ptr [rdi]
       mov      r11, gword ptr [r11+0x50]
       cmp      r13d, dword ptr [r11+0x08]
       jae      G_M000_IG313
       mov      eax, r13d
       shl      rax, 5
       lea      rax, bword ptr [r11+rax+0x10]
       cmp      dword ptr [rax+0x1C], 43
       jne      G_M000_IG298
       mov      r11d, dword ptr [rax+0x08]
       mov      rax, 0x75E363D4C730
       cmp      qword ptr [rsi], rax
       jne      G_M000_IG300
       cmp      dword ptr [rsi+0x08], r11d
       jbe      G_M000_IG299
       mov      r12, gword ptr [rsi+8*r11+0x10]
 
G_M000_IG06:                ;; offset=0x010A
       mov      rdi, bword ptr [rbp-0x228]
       mov      rsi, gword ptr [rdi]
       mov      rsi, gword ptr [rsi+0x50]
       mov      rax, rsi
       lea      ecx, [r14+0x02]
       mov      edx, dword ptr [rax+0x08]
       cmp      ecx, edx
       jae      G_M000_IG313
       lea      ecx, [r14+0x02]
       shl      rcx, 5
       lea      rax, bword ptr [rax+rcx+0x10]
       mov      bword ptr [rbp-0x240], rax
       mov      rcx, rsi
       lea      r8d, [r13+0x01]
       cmp      r8d, edx
       jae      G_M000_IG313
       lea      r8d, [r13+0x01]
       shl      r8, 5
       lea      rcx, bword ptr [rcx+r8+0x10]
       mov      bword ptr [rbp-0x248], rcx
       mov      r8, rsi
       lea      r9d, [r13+0x02]
       cmp      r9d, edx
       jae      G_M000_IG313
       lea      r9d, [r13+0x02]
       shl      r9, 5
       lea      r8, bword ptr [r8+r9+0x10]
       mov      bword ptr [rbp-0x250], r8
       mov      r8, gword ptr [rdi]
       mov      r8, gword ptr [r8+0x10]
       lea      r9d, [r14+0x04]
       cmp      r9d, edx
       jae      G_M000_IG313
       lea      edx, [r14+0x04]
       shl      rdx, 5
       lea      rdx, bword ptr [rsi+rdx+0x10]
       mov      esi, dword ptr [rdx+0x1C]
       cmp      esi, 8
       jg       G_M000_IG303
       cmp      esi, 3
       jne      G_M000_IG301
 
G_M000_IG07:                ;; offset=0x01BC
       mov      esi, dword ptr [rdx+0x08]
       mov      r11, 0x75E3628627A0
       cmp      qword ptr [r8], r11
       jne      G_M000_IG304
       cmp      dword ptr [r8+0x08], esi
       jbe      G_M000_IG299
       mov      rdx, gword ptr [r8+8*rsi+0x10]
 
G_M000_IG08:                ;; offset=0x01E1
       mov      gword ptr [rbp-0x258], rdx
       mov      rdi, bword ptr [rbp-0x228]
       mov      rsi, gword ptr [rdi]
       mov      rsi, gword ptr [rsi+0x10]
       mov      rcx, bword ptr [rbp-0x248]
       mov      r11d, dword ptr [rcx+0x0C]
       not      r11d
       mov      rcx, 0x75E3628627A0
       cmp      qword ptr [rsi], rcx
       jne      G_M000_IG305
       cmp      dword ptr [rsi+0x08], r11d
       jbe      G_M000_IG299
       mov      rcx, gword ptr [rsi+8*r11+0x10]
 
G_M000_IG09:                ;; offset=0x0226
       mov      rsi, 0x75E363C2B158
       cmp      qword ptr [rcx], rsi
       je       SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0235
       mov      gword ptr [rbp-0x288], rcx
       mov      rsi, rcx
       mov      rdi, 0x75E363C2B158
       call     CORINFO_HELP_UNBOX
       mov      rcx, gword ptr [rbp-0x288]
 
G_M000_IG11:                ;; offset=0x0255
       mov      rsi, gword ptr [rcx+0x08]
       mov      gword ptr [rbp-0x2E0], rsi
       mov      ecx, dword ptr [rcx+0x10]
       mov      dword ptr [rbp-0x1D4], ecx
       lea      r8d, [r13+0x03]
       mov      dword ptr [rbp-0x2C], r8d
       mov      rdi, bword ptr [rbp-0x228]
       mov      r9, gword ptr [rdi]
       mov      r9, gword ptr [r9+0x50]
       cmp      r8d, dword ptr [r9+0x08]
       jae      G_M000_IG313
       mov      r10d, r8d
       shl      r10, 5
       lea      r9, bword ptr [r9+r10+0x10]
       cmp      dword ptr [r9+0x1C], 48
       sete     r10b
       movzx    r10, r10b
       mov      dword ptr [rbp-0x30], r10d
       mov      bword ptr [rbp-0x260], r9
       test     r10d, r10d
       je       G_M000_IG289
 
G_M000_IG12:                ;; offset=0x02B6
       mov      r9, gword ptr [rdi]
       mov      r9, gword ptr [r9+0x10]
       mov      r11, bword ptr [rbp-0x260]
       mov      edx, dword ptr [r11+0x0C]
       not      edx
       mov      rax, 0x75E3628627A0
       cmp      qword ptr [r9], rax
       jne      G_M000_IG307
       cmp      dword ptr [r9+0x08], edx
       jbe      G_M000_IG299
       mov      eax, edx
       mov      rax, gword ptr [r9+8*rax+0x10]
 
G_M000_IG13:                ;; offset=0x02EE
       mov      rdx, 0x75E363C2B158
       cmp      qword ptr [rax], rdx
       je       SHORT G_M000_IG15
 
G_M000_IG14:                ;; offset=0x02FD
       mov      gword ptr [rbp-0x290], rax
       mov      rsi, rax
       mov      rdi, 0x75E363C2B158
       call     CORINFO_HELP_UNBOX
       mov      rax, gword ptr [rbp-0x290]
 
G_M000_IG15:                ;; offset=0x031D
       mov      rdx, gword ptr [rax+0x08]
       mov      eax, dword ptr [rax+0x10]
 
G_M000_IG16:                ;; offset=0x0324
       mov      gword ptr [rbp-0x2E8], rdx
       mov      dword ptr [rbp-0x1D8], eax
       mov      rdi, bword ptr [rbp-0x228]
       mov      r9, gword ptr [rdi]
       cmp      byte  ptr [r9+0xA8], 0
       jne      G_M000_IG291
 
G_M000_IG17:                ;; offset=0x0349
       test     r15, r15
       je       G_M000_IG308
 
G_M000_IG18:                ;; offset=0x0352
       cmp      byte  ptr [r15+0x103], 0
       jne      G_M000_IG291
       mov      r9, gword ptr [r15+0x90]
 
G_M000_IG19:                ;; offset=0x0367
       test     r9, r9
       sete     r9b
       movzx    r9, r9b
 
G_M000_IG20:                ;; offset=0x0372
       mov      r10d, dword ptr [rbp-0x30]
       mov      ecx, r10d
       and      ecx, r9d
       mov      dword ptr [rbp-0x34], ecx
       test     r9d, r9d
       je       SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x0384
       mov      r9, gword ptr [rdi+0x28]
       mov      esi, dword ptr [rbx+0x10]
       cmp      esi, dword ptr [r9+0x08]
       jae      G_M000_IG313
       mov      rsi, gword ptr [r9+8*rsi+0x10]
       test     rsi, rsi
       je       G_M000_IG309
       mov      r9, 0x75E363F58E40
       cmp      qword ptr [rsi], r9
       je       G_M000_IG292
 
G_M000_IG22:                ;; offset=0x03B6
       mov      rdi, bword ptr [rbp-0x228]
       xor      r9, r9
 
G_M000_IG23:                ;; offset=0x03C0
       mov      gword ptr [rbp-0x268], r9
       test     r9, r9
       je       SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x03CC
       mov      r9, gword ptr [r9+0x08]
       mov      rsi, gword ptr [rbp-0x230]
       mov      rax, gword ptr [rsi+0xA0]
       xor      rcx, rcx
       cmp      r9, gword ptr [rax+0x88]
       cmove    rcx, gword ptr [rbp-0x268]
       mov      gword ptr [rbp-0x268], rcx
 
G_M000_IG25:                ;; offset=0x03F6
       mov      r9d, dword ptr [rbx+0x10]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x50], xmm0
       vmovdqu  xmmword ptr [rbp-0x48], xmm0
       cmp      gword ptr [rbp-0x268], 0
       je       G_M000_IG312
       mov      r9, gword ptr [rbp-0x268]
       mov      r9d, dword ptr [r9+0x38]
       mov      rax, gword ptr [rbp-0x268]
       cmp      r9d, dword ptr [rax+0x34]
       je       G_M000_IG293
 
G_M000_IG26:                ;; offset=0x0432
       mov      rax, gword ptr [rbp-0x268]
       mov      rax, gword ptr [rax+0x10]
       mov      r9, gword ptr [rbp-0x268]
       mov      r9d, dword ptr [r9+0x38]
       lea      ecx, [r9+0x01]
       mov      rsi, gword ptr [rbp-0x268]
       mov      dword ptr [rsi+0x38], ecx
       cmp      r9d, dword ptr [rax+0x08]
       jae      G_M000_IG313
       mov      ecx, r9d
       shl      rcx, 4
       lea      rax, bword ptr [rax+rcx+0x10]
       mov      ecx, dword ptr [rax]
       mov      dword ptr [rbp-0x1E4], ecx
       mov      esi, dword ptr [rax+0x04]
       mov      dword ptr [rbp-0x1E8], esi
       mov      eax, dword ptr [rax+0x08]
       mov      dword ptr [rbp-0x1EC], eax
       cmp      eax, 8
       jg       G_M000_IG310
 
G_M000_IG27:                ;; offset=0x048F
       mov      dword ptr [rbp-0x44], eax
       mov      rax, gword ptr [rbp-0x268]
       mov      rdi, gword ptr [rax+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
       mov      esi, dword ptr [rbp-0x1E8]
       mov      r10d, dword ptr [rbp-0x1E4]
       sub      esi, r10d
       mov      edi, r10d
       mov      r8d, esi
       add      rdi, r8
       mov      r8d, edx
       cmp      rdi, r8
       ja       G_M000_IG311
       mov      edi, r10d
       add      rdi, rax
       mov      r8, gword ptr [rbp-0x268]
       mov      r8, gword ptr [r8+0x28]
       mov      gword ptr [rsp], r8
       mov      r8, gword ptr [rbp-0x268]
       mov      r8d, dword ptr [r8+0x30]
       mov      r9, gword ptr [rbp-0x268]
       mov      r9, gword ptr [r9+0x20]
       lea      rdx, bword ptr [rbp-0x40]
       mov      ecx, 8
       call     [Lokad.Lython.Runtime.Text.PyStringOps:WriteCaseUtf8(System.ReadOnlySpan`1[byte],System.Span`1[byte],int,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):int]
       mov      dword ptr [rbp-0x48], eax
 
G_M000_IG28:                ;; offset=0x0507
       mov      eax, 1
 
G_M000_IG29:                ;; offset=0x050C
       test     eax, eax
       je       G_M000_IG281
 
G_M000_IG30:                ;; offset=0x0514
       xor      eax, eax
       mov      dword ptr [rbp-0x58], eax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
       vmovdqu  xmmword ptr [rbp-0x68], xmm0
 
G_M000_IG31:                ;; offset=0x0527
       mov      dword ptr [rbp-0x74], eax
 
G_M000_IG32:                ;; offset=0x052A
       mov      qword ptr [rbp-0x80], rax
 
G_M000_IG33:                ;; offset=0x052E
       mov      dword ptr [rbp-0x84], eax
 
G_M000_IG34:                ;; offset=0x0534
       mov      rdi, bword ptr [rbp-0x228]
       mov      dword ptr [rdi+0x20], r14d
       cmp      gword ptr [rbp-0x50], 0
       sete     al
       movzx    rax, al
       mov      dword ptr [rbp-0x88], eax
       test     eax, eax
       je       G_M000_IG244
 
G_M000_IG35:                ;; offset=0x0558
       vmovdqu  xmm0, xmmword ptr [rbp-0x50]
       vmovdqu  xmmword ptr [rbp-0x70], xmm0
       mov      r9, qword ptr [rbp-0x40]
       mov      qword ptr [rbp-0x60], r9
 
G_M000_IG36:                ;; offset=0x056A
       mov      dword ptr [rbp-0x58], 1
 
G_M000_IG37:                ;; offset=0x0571
       mov      r9, bword ptr [rbp-0x240]
       mov      rcx, gword ptr [r9]
       mov      rdx, gword ptr [rbp-0x230]
       mov      rsi, gword ptr [rdx+0xA0]
       mov      r9, gword ptr [rsi+0x88]
       mov      r9, gword ptr [r9+0x20]
       test     r9, r9
       jne      G_M000_IG274
       mov      rsi, gword ptr [rsi+0x178]
       test     rsi, rsi
       jne      G_M000_IG245
 
G_M000_IG38:                ;; offset=0x05AD
       mov      rcx, gword ptr [rdi+0x08]
       mov      rsi, bword ptr [rbp-0x250]
       mov      r9d, dword ptr [rsi+0x0C]
       cmp      r9d, dword ptr [rcx+0x08]
       jae      G_M000_IG276
       mov      rcx, gword ptr [rcx+8*r9+0x10]
       test     rcx, rcx
       je       SHORT G_M000_IG41
 
G_M000_IG39:                ;; offset=0x05D0
       mov      r9, 0x75E363EDEBC0
       cmp      qword ptr [rcx], r9
       jne      SHORT G_M000_IG41
 
G_M000_IG40:                ;; offset=0x05DF
       mov      gword ptr [rbp-0x270], rcx
       jmp      SHORT G_M000_IG42
 
G_M000_IG41:                ;; offset=0x05E8
       xor      rcx, rcx
       mov      gword ptr [rbp-0x270], rcx
 
G_M000_IG42:                ;; offset=0x05F1
       cmp      dword ptr [rbp-0x88], 0
       je       G_M000_IG52
 
G_M000_IG43:                ;; offset=0x05FE
       mov      rdi, bword ptr [rbp-0x228]
       mov      rsi, bword ptr [rbp-0x250]
       xor      r9, r9
       mov      gword ptr [rbp-0x280], r9
 
G_M000_IG44:                ;; offset=0x0616
       mov      r10d, dword ptr [rbp-0x30]
       test     r10d, r10d
       je       G_M000_IG248
 
G_M000_IG45:                ;; offset=0x0623
       mov      r9, gword ptr [rdi+0x08]
       mov      r11, bword ptr [rbp-0x260]
       mov      esi, dword ptr [r11+0x10]
       cmp      esi, dword ptr [r9+0x08]
       jae      G_M000_IG276
       mov      r9, gword ptr [r9+8*rsi+0x10]
 
G_M000_IG46:                ;; offset=0x0641
       mov      gword ptr [rbp-0x278], r9
       cmp      gword ptr [rbp-0x270], 0
       je       SHORT G_M000_IG50
 
G_M000_IG47:                ;; offset=0x0652
       cmp      dword ptr [rbp-0x88], 0
       je       G_M000_IG249
 
G_M000_IG48:                ;; offset=0x065F
       test     r10d, r10d
       je       G_M000_IG250
 
G_M000_IG49:                ;; offset=0x0668
       test     r9, r9
       jne      SHORT G_M000_IG53
 
G_M000_IG50:                ;; offset=0x066D
       add      r14d, 2
       mov      rdi, bword ptr [rbp-0x228]
       mov      dword ptr [rdi+0x20], r14d
 
G_M000_IG51:                ;; offset=0x067C
       mov      dword ptr [rbp-0xA4], 1
       jmp      G_M000_IG278
 
G_M000_IG52:                ;; offset=0x068B
       mov      r9, gword ptr [rdi+0x08]
       mov      gword ptr [rbp-0x340], r9
       mov      rdi, rsi
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_ThirdInput():int:this]
       mov      rdi, gword ptr [rbp-0x340]
       cmp      eax, dword ptr [rdi+0x08]
       jae      G_M000_IG276
       mov      edx, eax
       mov      rax, gword ptr [rdi+8*rdx+0x10]
       test     rax, rax
       jne      G_M000_IG246
       jmp      G_M000_IG43
 
G_M000_IG53:                ;; offset=0x06C4
       mov      rsi, 0x75E363C2B158
       cmp      qword ptr [r9], rsi
       jne      SHORT G_M000_IG50
 
G_M000_IG54:                ;; offset=0x06D3
       mov      rsi, gword ptr [r9+0x08]
       mov      gword ptr [rbp-0x2F0], rsi
       mov      esi, dword ptr [r9+0x10]
       mov      dword ptr [rbp-0x1DC], esi
       test     esi, esi
       jne      G_M000_IG251
 
G_M000_IG55:                ;; offset=0x06F0
       mov      rdi, bword ptr [rbp-0x228]
       mov      dword ptr [rdi+0x20], r13d
       mov      rsi, gword ptr [r12+0x18]
       mov      rdx, gword ptr [rbp-0x230]
       mov      rdi, gword ptr [rdx+0xA0]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.ExecutionState:EnterInterpreterFrame(Lokad.Lython.LythonSourceSpan):this]
       nop      
 
G_M000_IG56:                ;; offset=0x0717
       cmp      dword ptr [rbp-0x88], 0
       je       G_M000_IG123
 
G_M000_IG57:                ;; offset=0x0724
       mov      eax, dword ptr [rbp-0x48]
       cmp      eax, 8
       ja       G_M000_IG124
       mov      dword ptr [rbp-0x1E0], eax
       mov      rcx, gword ptr [rbp-0x2E0]
       mov      gword ptr [rbp-0x300], rcx
       mov      r9d, dword ptr [rbp-0x1D4]
       mov      edi, r9d
       mov      r10, gword ptr [r12+0x18]
       mov      gword ptr [rbp-0x298], r10
       mov      r11, gword ptr [rbp-0x270]
       cmp      gword ptr [r11+0x28], 0
       mov      r9d, dword ptr [rbp-0x1D4]
       je       G_M000_IG217
       mov      r10, gword ptr [rbp-0x298]
       cmp      gword ptr [r11+0x30], 0
       je       G_M000_IG217
       cmp      gword ptr [r11+0x20], 0
       jne      G_M000_IG217
       cmp      dword ptr [r11+0x50], 0
       jne      G_M000_IG217
       mov      gword ptr [rbp-0x270], r11
       mov      rdx, gword ptr [r11+0x10]
       mov      rsi, gword ptr [rbp-0x230]
       mov      r8, gword ptr [rsi+0xA0]
       cmp      rdx, gword ptr [r8+0x88]
       jne      G_M000_IG217
       test     edi, edi
       jne      G_M000_IG125
 
G_M000_IG58:                ;; offset=0x07C9
       mov      rsi, gword ptr [rbp-0x230]
       mov      rdi, gword ptr [rsi+0xA0]
       mov      rdx, gword ptr [rdi+0x88]
       mov      rdx, gword ptr [rdx+0x20]
       test     rdx, rdx
       jne      G_M000_IG140
       mov      rdi, gword ptr [rdi+0x178]
       test     rdi, rdi
       jne      G_M000_IG141
 
G_M000_IG59:                ;; offset=0x07FB
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x110], ymm0
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x110], ymm0
       xor      edx, edx
 
G_M000_IG60:                ;; offset=0x0815
       mov      dword ptr [rbp-0x114], edx
       cmp      edx, dword ptr [rbp-0x1E0]
       jl       G_M000_IG70
 
G_M000_IG61:                ;; offset=0x0827
       mov      edx, dword ptr [rbp-0xF4]
       mov      edi, edx
       and      edi, 3
       cmp      edx, 4
       jae      G_M000_IG158
 
G_M000_IG62:                ;; offset=0x083B
       mov      r8d, 0x575B9399
 
G_M000_IG63:                ;; offset=0x0841
       lea      edx, [r8+4*rdx]
       test     edi, edi
       je       SHORT G_M000_IG66
 
G_M000_IG64:                ;; offset=0x0849
       imul     r8d, dword ptr [rbp-0x100], 0xFFFFFFFFC2B2AE3D
       add      edx, r8d
       rol      edx, 17
       imul     edx, edx, 0x27D4EB2F
       cmp      edi, 1
       jbe      SHORT G_M000_IG66
 
G_M000_IG65:                ;; offset=0x0865
       imul     r8d, dword ptr [rbp-0xFC], 0xFFFFFFFFC2B2AE3D
       add      r8d, edx
       rol      r8d, 17
       imul     edx, r8d, 0x27D4EB2F
       cmp      edi, 2
       ja       G_M000_IG159
 
G_M000_IG66:                ;; offset=0x0887
       mov      edi, edx
       shr      edi, 15
       xor      edi, edx
       imul     edx, edi, 0xFFFFFFFF85EBCA77
       mov      edi, edx
       shr      edi, 13
       xor      edi, edx
       imul     edx, edi, 0xFFFFFFFFC2B2AE3D
       mov      edi, edx
       shr      edi, 16
       xor      edx, edi
       cmp      edx, -1
       je       G_M000_IG160
 
G_M000_IG67:                ;; offset=0x08B1
       mov      edi, edx
       shr      edi, 16
       xor      edi, edx
       imul     r8d, edi, 0xFFFFFFFF9E3779B9
       mov      edi, r8d
       shr      edi, 16
       xor      r8d, edi
       mov      dword ptr [rbp-0xE8], r8d
       mov      r11, gword ptr [rbp-0x270]
       mov      rdi, gword ptr [r11+0x28]
       mov      gword ptr [rbp-0x2A0], rdi
       cmp      dword ptr [rdi+0x08], 0
       je       G_M000_IG161
 
G_M000_IG68:                ;; offset=0x08EB
       mov      edx, dword ptr [rdi+0x08]
       lea      r10d, [rdx-0x01]
       test     edx, r10d
       jne      G_M000_IG162
       and      r10d, r8d
 
G_M000_IG69:                ;; offset=0x08FE
       cmp      r10d, dword ptr [rdi+0x08]
       jae      G_M000_IG201
       mov      edx, r10d
       lea      rdx, [rdx+4*rdx]
       mov      edx, dword ptr [rdi+8*rdx+0x30]
       dec      edx
       mov      dword ptr [rbp-0x134], edx
       test     edx, edx
       jl       G_M000_IG163
       jmp      G_M000_IG109
 
G_M000_IG70:                ;; offset=0x0928
       mov      rsi, gword ptr [rbp-0x230]
       mov      rdi, gword ptr [rsi+0xA0]
       mov      r8, gword ptr [rdi+0x88]
       mov      r8, gword ptr [r8+0x20]
       test     r8, r8
       jne      G_M000_IG157
       mov      rdi, gword ptr [rdi+0x178]
       test     rdi, rdi
       jne      G_M000_IG142
 
G_M000_IG71:                ;; offset=0x095A
       mov      eax, dword ptr [rbp-0x1E0]
       mov      edx, dword ptr [rbp-0x114]
       mov      r8d, eax
       sub      r8d, edx
       cmp      r8d, 0x1000
       jge      G_M000_IG79
 
G_M000_IG72:                ;; offset=0x0979
       mov      dword ptr [rbp-0x118], r8d
       mov      dword ptr [rbp-0x114], edx
       mov      edi, edx
       mov      r10d, r8d
       add      r10, rdi
       mov      edx, eax
       cmp      r10, rdx
       ja       G_M000_IG124
       lea      rdx, bword ptr [rbp-0x40]
       add      rdx, rdi
       mov      bword ptr [rbp-0x308], rdx
       mov      r10, rdx
       mov      edi, r8d
       cmp      edi, 16
       jl       SHORT G_M000_IG76
       jmp      G_M000_IG143
 
G_M000_IG73:                ;; offset=0x09B7
       cmp      r8d, 1
       jne      G_M000_IG151
 
G_M000_IG74:                ;; offset=0x09C1
       mov      dword ptr [rbp-0xFC], edx
 
G_M000_IG75:                ;; offset=0x09C7
       mov      rdx, bword ptr [rbp-0x310]
       add      rdx, 4
       add      edi, -4
       mov      r10, rdx
 
G_M000_IG76:                ;; offset=0x09D8
       cmp      edi, 4
       jl       SHORT G_M000_IG80
 
G_M000_IG77:                ;; offset=0x09DD
       mov      bword ptr [rbp-0x310], r10
       mov      edx, dword ptr [r10]
       mov      r10d, dword ptr [rbp-0xF4]
       lea      r8d, [r10+0x01]
       mov      dword ptr [rbp-0xF4], r8d
       mov      r8d, r10d
       and      r8d, 3
       jne      SHORT G_M000_IG73
 
G_M000_IG78:                ;; offset=0x0A02
       mov      dword ptr [rbp-0x100], edx
       jmp      SHORT G_M000_IG75
 
G_M000_IG79:                ;; offset=0x0A0A
       mov      r8d, 0x1000
       jmp      G_M000_IG72
 
G_M000_IG80:                ;; offset=0x0A15
       mov      rdx, r10
       mov      bword ptr [rbp-0x318], rdx
       xor      r10d, r10d
       test     edi, edi
       je       SHORT G_M000_IG84
 
G_M000_IG81:                ;; offset=0x0A26
       movzx    rdx, byte  ptr [rdx+r10]
       mov      dword ptr [rbp-0x12C], edx
       mov      edx, dword ptr [rbp-0xF4]
       lea      r8d, [rdx+0x01]
       mov      dword ptr [rbp-0xF4], r8d
       mov      r8d, edx
       and      r8d, 3
       jne      SHORT G_M000_IG85
 
G_M000_IG82:                ;; offset=0x0A4B
       mov      edx, dword ptr [rbp-0x12C]
       mov      dword ptr [rbp-0x100], edx
 
G_M000_IG83:                ;; offset=0x0A57
       inc      r10d
       cmp      r10d, edi
       mov      rdx, bword ptr [rbp-0x318]
       jl       SHORT G_M000_IG81
 
G_M000_IG84:                ;; offset=0x0A66
       mov      edx, dword ptr [rbp-0x114]
       add      edx, dword ptr [rbp-0x118]
       mov      r10, gword ptr [rbp-0x298]
       jmp      G_M000_IG60
 
G_M000_IG85:                ;; offset=0x0A7E
       cmp      r8d, 1
       jne      G_M000_IG154
 
G_M000_IG86:                ;; offset=0x0A88
       mov      edx, dword ptr [rbp-0x12C]
       mov      dword ptr [rbp-0xFC], edx
       jmp      SHORT G_M000_IG83
 
G_M000_IG87:                ;; offset=0x0A96
       mov      r9, 0x75E363D43E58
       cmp      qword ptr [rcx], r9
       jne      G_M000_IG106
 
G_M000_IG88:                ;; offset=0x0AA9
       mov      eax, dword ptr [rbp-0x1E0]
       mov      dword ptr [rbp-0x1F8], eax
       movzx    r9, byte  ptr [rcx+0x24]
       test     r9d, r9d
       je       G_M000_IG165
 
G_M000_IG89:                ;; offset=0x0AC3
       cmp      r9d, 255
       jne      G_M000_IG100
 
G_M000_IG90:                ;; offset=0x0AD0
       mov      r9, gword ptr [rcx+0x08]
       mov      gword ptr [rbp-0x2A8], r9
       lea      r9, bword ptr [rcx+0x28]
       mov      r9d, dword ptr [r9]
       mov      ecx, dword ptr [rcx+0x18]
       mov      dword ptr [rbp-0x140], ecx
       cmp      gword ptr [rbp-0x2A8], 0
       je       G_M000_IG169
       mov      qword ptr [rbp-0x220], r9
       mov      r9d, ecx
       add      r9, qword ptr [rbp-0x220]
       mov      qword ptr [rbp-0x354], r9
       mov      r9, gword ptr [rbp-0x2A8]
       mov      r9d, dword ptr [r9+0x08]
       cmp      qword ptr [rbp-0x354], r9
       ja       G_M000_IG124
       mov      r9, gword ptr [rbp-0x2A8]
       mov      rcx, qword ptr [rbp-0x220]
       lea      rcx, bword ptr [r9+rcx+0x10]
       mov      r9d, dword ptr [rbp-0x140]
 
G_M000_IG91:                ;; offset=0x0B43
       mov      bword ptr [rbp-0x320], rcx
       mov      dword ptr [rbp-0x1F4], r9d
       mov      ecx, dword ptr [rbp-0x1F8]
       cmp      r9d, ecx
       jne      G_M000_IG170
       xor      ecx, ecx
 
G_M000_IG92:                ;; offset=0x0B62
       mov      dword ptr [rbp-0x138], ecx
       cmp      ecx, eax
       jge      G_M000_IG113
 
G_M000_IG93:                ;; offset=0x0B70
       mov      rsi, gword ptr [rbp-0x230]
       mov      r9, gword ptr [rsi+0xA0]
       mov      r8, gword ptr [r9+0x88]
       mov      r8, gword ptr [r8+0x20]
       test     r8, r8
       jne      G_M000_IG198
       mov      r8, gword ptr [r9+0x178]
       test     r8, r8
       jne      G_M000_IG171
 
G_M000_IG94:                ;; offset=0x0BA2
       mov      eax, dword ptr [rbp-0x1E0]
       mov      ecx, dword ptr [rbp-0x138]
       mov      r8d, eax
       sub      r8d, ecx
       cmp      r8d, 0x1000
       jge      G_M000_IG101
 
G_M000_IG95:                ;; offset=0x0BC1
       mov      dword ptr [rbp-0x13C], r8d
       mov      dword ptr [rbp-0x138], ecx
       mov      r9d, ecx
       mov      ecx, r8d
       mov      qword ptr [rbp-0x218], rcx
       lea      r8, [r9+rcx]
       mov      qword ptr [rbp-0x200], r8
       mov      ecx, eax
       cmp      r8, rcx
       ja       G_M000_IG124
       lea      rcx, bword ptr [rbp-0x40]
       add      rcx, r9
       mov      bword ptr [rbp-0x328], rcx
       mov      r8d, dword ptr [rbp-0x1F4]
       cmp      qword ptr [rbp-0x200], r8
       ja       G_M000_IG124
       add      r9, bword ptr [rbp-0x320]
       mov      bword ptr [rbp-0x330], r9
       mov      bword ptr [rbp-0x2B0], rcx
       mov      bword ptr [rbp-0x2B8], r9
       mov      r8, qword ptr [rbp-0x218]
       cmp      r8, 8
       jae      G_M000_IG102
 
G_M000_IG96:                ;; offset=0x0C40
       cmp      r8, 4
       jb       G_M000_IG172
 
G_M000_IG97:                ;; offset=0x0C4A
       add      r8, -4
       mov      qword ptr [rbp-0x178], r8
       mov      r8d, dword ptr [rcx]
       sub      r8d, dword ptr [r9]
       mov      dword ptr [rbp-0x34C], r8d
       mov      r8, qword ptr [rbp-0x178]
       mov      ecx, dword ptr [rcx+r8]
       sub      ecx, dword ptr [r9+r8]
       or       ecx, dword ptr [rbp-0x34C]
       sete     cl
       movzx    rcx, cl
 
G_M000_IG98:                ;; offset=0x0C7D
       test     ecx, ecx
       je       G_M000_IG177
 
G_M000_IG99:                ;; offset=0x0C85
       mov      ecx, dword ptr [rbp-0x138]
       add      ecx, dword ptr [rbp-0x13C]
       jmp      G_M000_IG92
 
G_M000_IG100:                ;; offset=0x0C96
       lea      r9, bword ptr [rcx+0x28]
       mov      ecx, dword ptr [rcx+0x18]
       cmp      ecx, 8
       ja       G_M000_IG124
       mov      edx, ecx
       mov      rcx, r9
       mov      r9d, edx
       jmp      G_M000_IG91
 
G_M000_IG101:                ;; offset=0x0CB3
       mov      r8d, 0x1000
       jmp      G_M000_IG95
 
G_M000_IG102:                ;; offset=0x0CBE
       mov      r9, bword ptr [rbp-0x2B0]
       cmp      r9, bword ptr [rbp-0x2B8]
       je       SHORT G_M000_IG99
       cmp      r8, 64
       jae      G_M000_IG178
 
G_M000_IG103:                ;; offset=0x0CD8
       cmp      r8, 32
       jae      G_M000_IG185
 
G_M000_IG104:                ;; offset=0x0CE2
       cmp      r8, 16
       jae      G_M000_IG191
 
G_M000_IG105:                ;; offset=0x0CEC
       add      r8, -8
       mov      qword ptr [rbp-0x148], r8
       mov      r9, qword ptr [rcx]
       mov      r8, bword ptr [rbp-0x330]
       sub      r9, qword ptr [r8]
       mov      qword ptr [rbp-0x354], r9
       mov      r9, qword ptr [rbp-0x148]
       mov      rcx, qword ptr [rcx+r9]
       sub      rcx, qword ptr [r8+r9]
       or       rcx, qword ptr [rbp-0x354]
       sete     cl
       movzx    rcx, cl
       jmp      G_M000_IG98
 
G_M000_IG106:                ;; offset=0x0D2C
       mov      rdi, gword ptr [rbp-0x2A0]
       mov      r9d, dword ptr [rbp-0x1D4]
 
G_M000_IG107:                ;; offset=0x0D3A
       mov      r10, bword ptr [rbp-0x348]
       mov      edx, dword ptr [r10+0x1C]
       dec      edx
       mov      ecx, edx
       test     ecx, ecx
       mov      dword ptr [rbp-0x134], ecx
       jl       G_M000_IG199
 
G_M000_IG108:                ;; offset=0x0D57
       mov      r8d, dword ptr [rbp-0xE8]
 
G_M000_IG109:                ;; offset=0x0D5E
       mov      rsi, gword ptr [rbp-0x230]
       mov      r10, gword ptr [rsi+0xA0]
       mov      rcx, gword ptr [r10+0x88]
       mov      rcx, gword ptr [rcx+0x20]
       test     rcx, rcx
       jne      G_M000_IG197
       mov      rcx, gword ptr [r10+0x178]
       test     rcx, rcx
       jne      G_M000_IG164
 
G_M000_IG110:                ;; offset=0x0D90
       mov      edx, dword ptr [rbp-0x134]
       mov      rdi, gword ptr [rbp-0x2A0]
       cmp      edx, dword ptr [rdi+0x08]
       jae      G_M000_IG201
       mov      dword ptr [rbp-0x134], edx
       mov      ecx, edx
       lea      rcx, [rcx+4*rcx]
       lea      r10, bword ptr [rdi+8*rcx+0x10]
       mov      bword ptr [rbp-0x348], r10
       cmp      dword ptr [r10+0x18], r8d
       jne      G_M000_IG107
 
G_M000_IG111:                ;; offset=0x0DC8
       mov      rcx, gword ptr [rdi+8*rcx+0x10]
       test     rcx, rcx
       jne      G_M000_IG87
 
G_M000_IG112:                ;; offset=0x0DD6
       mov      rdi, gword ptr [rbp-0x2A0]
       jmp      G_M000_IG107
 
G_M000_IG113:                ;; offset=0x0DE2
       mov      r9d, dword ptr [rbp-0x1D4]
       mov      edx, dword ptr [rbp-0x134]
       mov      eax, edx
 
G_M000_IG114:                ;; offset=0x0DF1
       test     eax, eax
       jl       G_M000_IG217
 
G_M000_IG115:                ;; offset=0x0DF9
       mov      dword ptr [rbp-0x130], eax
       mov      ecx, eax
       mov      dword ptr [rbp-0x18C], ecx
       mov      r11, gword ptr [rbp-0x270]
       mov      rdi, gword ptr [r11+0x28]
       mov      edx, dword ptr [rdi+0x08]
       mov      dword ptr [rbp-0x20C], edx
       cmp      ecx, edx
       jae      G_M000_IG201
       mov      r10d, ecx
       lea      r10, [r10+4*r10]
       mov      qword ptr [rbp-0x208], r10
       mov      rdi, gword ptr [rdi+8*r10+0x10]
       mov      r10, rdi
       test     r10, r10
       je       SHORT G_M000_IG117
 
G_M000_IG116:                ;; offset=0x0E3E
       mov      rdx, 0x75E363D43E58
       cmp      qword ptr [r10], rdx
       jne      G_M000_IG200
 
G_M000_IG117:                ;; offset=0x0E51
       mov      gword ptr [rbp-0x2C8], r10
       vxorps   xmm0, xmm0, xmm0
       vmovdqu32 xmmword ptr [rbp-0x1A0], xmm0
       cmp      gword ptr [r11+0x20], 0
       jne      G_M000_IG204
       mov      rdi, gword ptr [r11+0x30]
       cmp      ecx, dword ptr [rdi+0x08]
       jae      G_M000_IG201
       mov      edx, ecx
       cmp      gword ptr [rdi+8*rdx+0x10], 0
       jne      G_M000_IG203
 
G_M000_IG118:                ;; offset=0x0E89
       mov      rdi, gword ptr [r11+0x28]
       cmp      ecx, dword ptr [rbp-0x20C]
       jae      G_M000_IG201
       mov      rdx, qword ptr [rbp-0x208]
       mov      rdx, qword ptr [rdi+8*rdx+0x20]
       mov      rdi, 0xFF80000000000000
       cmp      rdx, rdi
       jl       G_M000_IG206
       mov      rdi, 0x80000000000000
       cmp      rdx, rdi
       mov      gword ptr [rbp-0x270], r11
       mov      qword ptr [rbp-0x1A8], rdx
       jge      G_M000_IG206
 
G_M000_IG119:                ;; offset=0x0ED9
       mov      rdi, gword ptr [rbp-0x2E0]
       mov      esi, r9d
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      rsi, rax
       add      rsi, qword ptr [rbp-0x1A8]
       mov      rax, gword ptr [rbp-0x270]
       mov      ecx, dword ptr [rax+0x4C]
       mov      dword ptr [rbp-0x1AC], ecx
       cmp      gword ptr [rax+0x20], 0
       jne      G_M000_IG215
       mov      rdi, gword ptr [rax+0x28]
       mov      edx, dword ptr [rbp-0x18C]
       cmp      edx, dword ptr [rdi+0x08]
       jae      G_M000_IG201
       mov      r8d, edx
       lea      r9, [r8+4*r8]
       mov      qword ptr [rdi+8*r9+0x20], rsi
       mov      gword ptr [rbp-0x270], rax
       mov      rdi, gword ptr [rax+0x30]
       cmp      edx, dword ptr [rdi+0x08]
       jae      G_M000_IG201
       xor      rsi, rsi
       mov      gword ptr [rdi+8*r8+0x10], rsi
 
G_M000_IG120:                ;; offset=0x0F48
       mov      rax, gword ptr [rbp-0x270]
       mov      ecx, dword ptr [rbp-0x1AC]
       cmp      dword ptr [rax+0x4C], ecx
       jne      G_M000_IG216
 
G_M000_IG121:                ;; offset=0x0F5E
       mov      r10d, 1
       mov      r9d, dword ptr [rbp-0x1D4]
 
G_M000_IG122:                ;; offset=0x0F6B
       movzx    rdi, r10b
       jmp      G_M000_IG218
 
G_M000_IG123:                ;; offset=0x0F74
       mov      rax, gword ptr [rbp-0x270]
       mov      r9d, dword ptr [rbp-0x1D4]
       mov      r8, gword ptr [r12+0x18]
       mov      gword ptr [rsp], r8
       mov      rcx, gword ptr [rbp-0x2E0]
       mov      r8d, r9d
       mov      rdi, rax
       mov      rsi, gword ptr [rbp-0x280]
       mov      rdx, gword ptr [rbp-0x258]
       mov      r9, gword ptr [rbp-0x230]
       call     [Lokad.Lython.Runtime.PyDict:TryAccumulateWithoutAdmission(Lokad.Lython.Runtime.Text.PyString,System.Object,System.Numerics.BigInteger,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
       mov      r10d, eax
       mov      r9d, dword ptr [rbp-0x1D4]
       jmp      SHORT G_M000_IG122
 
G_M000_IG124:                ;; offset=0x0FBF
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG125:                ;; offset=0x0FC6
       mov      r8, gword ptr [rbp-0x300]
       test     r8, r8
       jne      SHORT G_M000_IG128
       test     edi, edi
       jl       SHORT G_M000_IG126
       xor      edx, edx
       jmp      SHORT G_M000_IG127
 
G_M000_IG126:                ;; offset=0x0FDA
       mov      edx, 255
 
G_M000_IG127:                ;; offset=0x0FDF
       movsxd   rdi, edi
       jmp      G_M000_IG131
 
G_M000_IG128:                ;; offset=0x0FE7
       cmp      edi, -1
       jne      G_M000_IG130
       mov      dword ptr [rbp-0xEC], 255
       lea      rdi, bword ptr [r8+0x10]
       mov      edx, dword ptr [r8+0x08]
       xor      esi, esi
       call     [System.SpanHelpers:NonPackedIndexOfValueType[long,System.SpanHelpers+Negate`1[long]](byref,long,int):int]
       mov      rdi, gword ptr [rbp-0x300]
       mov      ecx, dword ptr [rdi+0x08]
       dec      ecx
       cmp      ecx, dword ptr [rdi+0x08]
       jae      G_M000_IG201
       mov      ecx, dword ptr [rdi+0x08]
       dec      ecx
       mov      rcx, qword ptr [rdi+8*rcx+0x10]
       not      rcx
       mov      edx, dword ptr [rdi+0x08]
       dec      edx
       cmp      edx, eax
       jne      SHORT G_M000_IG129
       inc      rcx
       mov      r8, rdi
       mov      rdi, rcx
       mov      edx, dword ptr [rbp-0xEC]
       mov      r9d, dword ptr [rbp-0x1D4]
       mov      r10, gword ptr [rbp-0x298]
       jmp      SHORT G_M000_IG131
 
G_M000_IG129:                ;; offset=0x1054
       mov      r8, rdi
       mov      rdi, rcx
       mov      edx, dword ptr [rbp-0xEC]
       mov      r9d, dword ptr [rbp-0x1D4]
       mov      r10, gword ptr [rbp-0x298]
       jmp      SHORT G_M000_IG131
 
G_M000_IG130:                ;; offset=0x1070
       xor      edx, edx
       xor      edi, edi
       mov      edx, dword ptr [r8+0x08]
       dec      edx
       cmp      edx, dword ptr [r8+0x08]
       jae      G_M000_IG201
       mov      edx, dword ptr [r8+0x08]
       dec      edx
       mov      rdx, qword ptr [r8+8*rdx+0x10]
       mov      rax, rdx
       mov      edx, edi
       mov      rdi, rax
 
G_M000_IG131:                ;; offset=0x1097
       mov      dword ptr [rbp-0xEC], edx
       test     edx, edx
       jne      SHORT G_M000_IG134
       xor      edx, edx
       lzcnt    rdx, rdi
       shr      edx, 3
       neg      edx
       add      edx, 7
       test     edx, edx
       jle      SHORT G_M000_IG132
       jmp      SHORT G_M000_IG133
 
G_M000_IG132:                ;; offset=0x10B6
       xor      edx, edx
 
G_M000_IG133:                ;; offset=0x10B8
       jmp      SHORT G_M000_IG136
 
G_M000_IG134:                ;; offset=0x10BA
       mov      rdx, rdi
       not      rdx
       lzcnt    rdx, rdx
       shr      edx, 3
       neg      edx
       add      edx, 7
       test     edx, edx
       jle      SHORT G_M000_IG135
       jmp      SHORT G_M000_IG136
 
G_M000_IG135:                ;; offset=0x10D3
       xor      edx, edx
 
G_M000_IG136:                ;; offset=0x10D5
       mov      dword ptr [rbp-0xF0], edx
       shl      edx, 3
       shrx     rdi, rdi, rdx
       movzx    rdi, dil
       and      edi, 128
       mov      edx, dword ptr [rbp-0xEC]
       and      edx, 128
       cmp      edi, edx
       je       SHORT G_M000_IG137
       mov      edi, 1
       jmp      SHORT G_M000_IG138
 
G_M000_IG137:                ;; offset=0x1104
       xor      edi, edi
 
G_M000_IG138:                ;; offset=0x1106
       test     edi, edi
       setne    dil
       movzx    rdi, dil
       mov      edx, dword ptr [rbp-0xF0]
       lea      edi, [rdx+rdi+0x01]
       test     r8, r8
       je       SHORT G_M000_IG139
       mov      edx, dword ptr [r8+0x08]
       sub      edx, 1
       imul     edx, edx, 8
       jo       G_M000_IG202
       add      edi, edx
       jo       G_M000_IG202
 
G_M000_IG139:                ;; offset=0x1137
       cmp      edi, 8
       jl       G_M000_IG58
       jmp      G_M000_IG217
 
G_M000_IG140:                ;; offset=0x1145
       mov      rdi, rdx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG141:                ;; offset=0x114E
       cmp      dword ptr [rdi+0x20], 0
       je       G_M000_IG59
       mov      rdi, r10
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       mov      r9d, dword ptr [rbp-0x1D4]
       mov      r10, gword ptr [rbp-0x298]
       jmp      G_M000_IG59
 
G_M000_IG142:                ;; offset=0x1174
       cmp      dword ptr [rdi+0x20], 0
       je       G_M000_IG71
       mov      rdi, r10
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       mov      r9d, dword ptr [rbp-0x1D4]
       mov      r10, gword ptr [rbp-0x298]
       jmp      G_M000_IG71
 
G_M000_IG143:                ;; offset=0x119A
       cmp      dword ptr [rbp-0xF4], 0
       jne      SHORT G_M000_IG144
       mov      rdx, 0xC6F0F65F65287010
       mov      qword ptr [rbp-0x110], rdx
       mov      rdx, 0xA2CDB23741052BE8
       mov      qword ptr [rbp-0x108], rdx
       jmp      SHORT G_M000_IG147
 
G_M000_IG144:                ;; offset=0x11C7
       mov      edx, dword ptr [rbp-0xF4]
       and      edx, 3
       dec      edx
       cmp      edx, 2
       ja       SHORT G_M000_IG147
       mov      qword ptr [rbp-0x354], rdx
       lea      rdx, [reloc @RWD00]
       mov      dword ptr [rbp-0x1F0], edi
       mov      r9, qword ptr [rbp-0x354]
       mov      edx, dword ptr [rdx+4*r9]
       lea      rcx, G_M000_IG02
       add      rdx, rcx
       jmp      rdx
 
G_M000_IG145:                ;; offset=0x1202
       mov      rax, r10
       jmp      G_M000_IG150
 
G_M000_IG146:                ;; offset=0x120A
       mov      rcx, r10
       jmp      G_M000_IG149
 
G_M000_IG147:                ;; offset=0x1212
       cmp      edi, 16
       jl       G_M000_IG76
       mov      edx, dword ptr [rbp-0x110]
       mov      dword ptr [rbp-0x11C], edx
       imul     edx, dword ptr [r10], 0xFFFFFFFF85EBCA77
       add      edx, dword ptr [rbp-0x11C]
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x110], edx
       mov      edx, dword ptr [rbp-0x10C]
       mov      dword ptr [rbp-0x120], edx
       lea      rdx, bword ptr [r10+0x04]
       imul     edx, dword ptr [rdx], 0xFFFFFFFF85EBCA77
       add      edx, dword ptr [rbp-0x120]
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x10C], edx
       mov      edx, dword ptr [rbp-0x108]
       mov      dword ptr [rbp-0x124], edx
       lea      rdx, bword ptr [r10+0x08]
       imul     edx, dword ptr [rdx], 0xFFFFFFFF85EBCA77
       add      edx, dword ptr [rbp-0x124]
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x108], edx
       mov      edx, dword ptr [rbp-0x104]
       mov      dword ptr [rbp-0x128], edx
       lea      rdx, bword ptr [r10+0x0C]
       imul     edx, dword ptr [rdx], 0xFFFFFFFF85EBCA77
       add      edx, dword ptr [rbp-0x128]
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x104], edx
       mov      edx, dword ptr [rbp-0xF4]
       add      edx, 4
       mov      dword ptr [rbp-0xF4], edx
       add      r10, 16
       add      edi, -16
       mov      rdx, r10
       mov      r10, rdx
       jmp      G_M000_IG147
 
G_M000_IG148:                ;; offset=0x12E5
       mov      r10, bword ptr [rbp-0x308]
       mov      esi, dword ptr [r10]
       lea      rdi, [rbp-0x110]
       call     [System.HashCode:Add(int):this]
       mov      r10, bword ptr [rbp-0x308]
       add      r10, 4
       mov      eax, dword ptr [rbp-0x118]
       lea      edi, [rax-0x04]
       mov      rcx, r10
       mov      dword ptr [rbp-0x1F0], edi
 
G_M000_IG149:                ;; offset=0x1319
       mov      bword ptr [rbp-0x310], rcx
       mov      esi, dword ptr [rcx]
       lea      rdi, [rbp-0x110]
       call     [System.HashCode:Add(int):this]
       mov      rcx, bword ptr [rbp-0x310]
       add      rcx, 4
       mov      edx, dword ptr [rbp-0x1F0]
       add      edx, -4
       mov      rax, rcx
       mov      dword ptr [rbp-0x1F0], edx
 
G_M000_IG150:                ;; offset=0x134C
       mov      bword ptr [rbp-0x310], rax
       mov      esi, dword ptr [rax]
       lea      rdi, [rbp-0x110]
       call     [System.HashCode:Add(int):this]
       mov      rax, bword ptr [rbp-0x310]
       add      rax, 4
       mov      edx, dword ptr [rbp-0x1F0]
       add      edx, -4
       mov      edi, edx
       mov      r10, rax
       mov      r9d, dword ptr [rbp-0x1D4]
       jmp      G_M000_IG147
 
G_M000_IG151:                ;; offset=0x1387
       cmp      r8d, 2
       jne      SHORT G_M000_IG152
       mov      dword ptr [rbp-0xF8], edx
       jmp      G_M000_IG75
 
G_M000_IG152:                ;; offset=0x1398
       cmp      r10d, 3
       jne      SHORT G_M000_IG153
       mov      r8, 0xC6F0F65F65287010
       mov      qword ptr [rbp-0x110], r8
       mov      r8, 0xA2CDB23741052BE8
       mov      qword ptr [rbp-0x108], r8
 
G_M000_IG153:                ;; offset=0x13C0
       imul     r8d, dword ptr [rbp-0x100], 0xFFFFFFFF85EBCA77
       add      r8d, dword ptr [rbp-0x110]
       rol      r8d, 13
       imul     r8d, r8d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x110], r8d
       imul     r8d, dword ptr [rbp-0xFC], 0xFFFFFFFF85EBCA77
       add      r8d, dword ptr [rbp-0x10C]
       rol      r8d, 13
       imul     r8d, r8d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x10C], r8d
       imul     r8d, dword ptr [rbp-0xF8], 0xFFFFFFFF85EBCA77
       add      r8d, dword ptr [rbp-0x108]
       rol      r8d, 13
       imul     r8d, r8d, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x108], r8d
       imul     edx, edx, 0xFFFFFFFF85EBCA77
       add      edx, dword ptr [rbp-0x104]
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x104], edx
       jmp      G_M000_IG75
 
G_M000_IG154:                ;; offset=0x144C
       cmp      r8d, 2
       jne      SHORT G_M000_IG155
       mov      edx, dword ptr [rbp-0x12C]
       mov      dword ptr [rbp-0xF8], edx
       jmp      G_M000_IG83
 
G_M000_IG155:                ;; offset=0x1463
       cmp      edx, 3
       jne      SHORT G_M000_IG156
       mov      rdx, 0xC6F0F65F65287010
       mov      qword ptr [rbp-0x110], rdx
       mov      rdx, 0xA2CDB23741052BE8
       mov      qword ptr [rbp-0x108], rdx
 
G_M000_IG156:                ;; offset=0x148A
       imul     edx, dword ptr [rbp-0x100], 0xFFFFFFFF85EBCA77
       add      edx, dword ptr [rbp-0x110]
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x110], edx
       imul     edx, dword ptr [rbp-0xFC], 0xFFFFFFFF85EBCA77
       add      edx, dword ptr [rbp-0x10C]
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x10C], edx
       imul     edx, dword ptr [rbp-0xF8], 0xFFFFFFFF85EBCA77
       add      edx, dword ptr [rbp-0x108]
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x108], edx
       imul     edx, dword ptr [rbp-0x12C], 0xFFFFFFFF85EBCA77
       add      edx, dword ptr [rbp-0x104]
       rol      edx, 13
       imul     edx, edx, 0xFFFFFFFF9E3779B1
       mov      dword ptr [rbp-0x104], edx
       jmp      G_M000_IG83
 
G_M000_IG157:                ;; offset=0x150B
       mov      rdi, r8
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG158:                ;; offset=0x1514
       rorx     r8d, dword ptr [rbp-0x110], 31
       mov      dword ptr [rbp-0x34C], r8d
       rorx     r8d, dword ptr [rbp-0x10C], 25
       add      r8d, dword ptr [rbp-0x34C]
       mov      dword ptr [rbp-0x34C], r8d
       rorx     r8d, dword ptr [rbp-0x108], 20
       add      r8d, dword ptr [rbp-0x34C]
       mov      dword ptr [rbp-0x34C], r8d
       rorx     r8d, dword ptr [rbp-0x104], 14
       add      r8d, dword ptr [rbp-0x34C]
       jmp      G_M000_IG63
 
G_M000_IG159:                ;; offset=0x156B
       imul     edi, dword ptr [rbp-0xF8], 0xFFFFFFFFC2B2AE3D
       add      edi, edx
       rol      edi, 17
       imul     edx, edi, 0x27D4EB2F
       jmp      G_M000_IG66
 
G_M000_IG160:                ;; offset=0x1585
       mov      edx, -2
       jmp      G_M000_IG67
 
G_M000_IG161:                ;; offset=0x158F
       jmp      G_M000_IG199
 
G_M000_IG162:                ;; offset=0x1594
       mov      r10d, edx
       mov      eax, r8d
       xor      edx, edx
       div      edx:eax, r10d
       mov      r10d, edx
       mov      r8d, dword ptr [rbp-0xE8]
       jmp      G_M000_IG69
 
G_M000_IG163:                ;; offset=0x15AE
       jmp      G_M000_IG199
 
G_M000_IG164:                ;; offset=0x15B3
       cmp      dword ptr [rcx+0x20], 0
       je       G_M000_IG110
       mov      rdi, gword ptr [rbp-0x298]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       mov      r8d, dword ptr [rbp-0xE8]
       mov      r9d, dword ptr [rbp-0x1D4]
       jmp      G_M000_IG110
 
G_M000_IG165:                ;; offset=0x15DD
       mov      r9, gword ptr [rcx+0x08]
       mov      ecx, dword ptr [rcx+0x18]
       test     r9, r9
       jne      SHORT G_M000_IG167
 
G_M000_IG166:                ;; offset=0x15E9
       test     ecx, ecx
       jne      G_M000_IG124
       xor      r9, r9
       xor      ecx, ecx
       jmp      SHORT G_M000_IG168
 
G_M000_IG167:                ;; offset=0x15F8
       cmp      dword ptr [r9+0x08], ecx
       jb       G_M000_IG124
       add      r9, 16
 
G_M000_IG168:                ;; offset=0x1606
       mov      edx, ecx
       mov      rcx, r9
       mov      r9d, edx
       jmp      G_M000_IG91
 
G_M000_IG169:                ;; offset=0x1613
       or       r9d, ecx
       jne      G_M000_IG124
       xor      rcx, rcx
       xor      r9d, r9d
       jmp      G_M000_IG91
 
G_M000_IG170:                ;; offset=0x1626
       mov      rdi, gword ptr [rbp-0x2A0]
       mov      r9d, dword ptr [rbp-0x1D4]
       jmp      G_M000_IG107
 
G_M000_IG171:                ;; offset=0x1639
       cmp      dword ptr [r8+0x20], 0
       je       G_M000_IG94
       mov      rdi, gword ptr [rbp-0x298]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG94
 
G_M000_IG172:                ;; offset=0x1656
       xor      r9d, r9d
       mov      dword ptr [rbp-0x17C], r9d
       mov      r9, r8
       and      r9, 2
       mov      qword ptr [rbp-0x188], r9
       test     r9, r9
       je       SHORT G_M000_IG174
 
G_M000_IG173:                ;; offset=0x1673
       movzx    r9, word  ptr [rcx]
       mov      dword ptr [rbp-0x34C], r9d
       mov      r9, bword ptr [rbp-0x330]
       movzx    r9, word  ptr [r9]
       movzx    rcx, dword ptr [rbp-0x34C]
       sub      ecx, r9d
       mov      r9d, ecx
       mov      dword ptr [rbp-0x17C], r9d
       mov      rcx, bword ptr [rbp-0x328]
 
G_M000_IG174:                ;; offset=0x16A4
       test     r8b, 1
       je       SHORT G_M000_IG176
 
G_M000_IG175:                ;; offset=0x16AA
       mov      r9, qword ptr [rbp-0x188]
       movzx    r8, byte  ptr [rcx+r9]
       mov      rcx, bword ptr [rbp-0x330]
       movzx    rcx, byte  ptr [rcx+r9]
       sub      r8d, ecx
       mov      r9d, r8d
       or       r9d, dword ptr [rbp-0x17C]
       mov      dword ptr [rbp-0x17C], r9d
 
G_M000_IG176:                ;; offset=0x16D6
       cmp      dword ptr [rbp-0x17C], 0
       sete     cl
       movzx    rcx, cl
       jmp      G_M000_IG98
 
G_M000_IG177:                ;; offset=0x16E8
       mov      rdi, gword ptr [rbp-0x2A0]
       mov      r9d, dword ptr [rbp-0x1D4]
       jmp      G_M000_IG107
 
G_M000_IG178:                ;; offset=0x16FB
       xor      ecx, ecx
       add      r8, -64
       mov      qword ptr [rbp-0x170], r8
       test     r8, r8
       je       SHORT G_M000_IG184
 
G_M000_IG179:                ;; offset=0x170D
       vmovups  zmm0, zmmword ptr [r9+rcx]
       mov      r8, bword ptr [rbp-0x2B8]
       vpcmpnequb k1, zmm0, zmmword ptr [r8+rcx]
       kortestq k1, k1
       jne      SHORT G_M000_IG183
       add      rcx, 64
       cmp      qword ptr [rbp-0x170], rcx
       ja       SHORT G_M000_IG182
 
G_M000_IG180:                ;; offset=0x1737
       mov      rcx, qword ptr [rbp-0x170]
       vmovups  zmm0, zmmword ptr [r9+rcx]
       vpcmpeqb k1, zmm0, zmmword ptr [r8+rcx]
       kortestq k1, k1
       jb       G_M000_IG99
 
G_M000_IG181:                ;; offset=0x1757
       mov      rdi, gword ptr [rbp-0x2A0]
       mov      r9d, dword ptr [rbp-0x1D4]
       jmp      G_M000_IG107
 
G_M000_IG182:                ;; offset=0x176A
       jmp      SHORT G_M000_IG179
 
G_M000_IG183:                ;; offset=0x176C
       mov      rdi, gword ptr [rbp-0x2A0]
       mov      r9d, dword ptr [rbp-0x1D4]
       jmp      G_M000_IG107
 
G_M000_IG184:                ;; offset=0x177F
       mov      r8, bword ptr [rbp-0x2B8]
       jmp      SHORT G_M000_IG180
 
G_M000_IG185:                ;; offset=0x1788
       xor      ecx, ecx
       mov      qword ptr [rbp-0x160], rcx
       add      r8, -32
       mov      qword ptr [rbp-0x168], r8
       test     r8, r8
       je       SHORT G_M000_IG189
       vmovups  ymm0, ymmword ptr [r9]
       mov      rcx, bword ptr [rbp-0x2B8]
       vpcmpnequb k1, ymm0, ymmword ptr [rcx]
       kortestd k1, k1
       je       SHORT G_M000_IG187
 
G_M000_IG186:                ;; offset=0x17BB
       mov      rdi, gword ptr [rbp-0x2A0]
       mov      r9d, dword ptr [rbp-0x1D4]
       jmp      G_M000_IG107
 
G_M000_IG187:                ;; offset=0x17CE
       mov      r8, qword ptr [rbp-0x160]
       add      r8, 32
       cmp      qword ptr [rbp-0x168], r8
       ja       SHORT G_M000_IG188
       jmp      SHORT G_M000_IG189
 
G_M000_IG188:                ;; offset=0x17E4
       vmovups  ymm0, ymmword ptr [r9+r8]
       vpcmpnequb k1, ymm0, ymmword ptr [rcx+r8]
       kortestd k1, k1
       mov      qword ptr [rbp-0x160], r8
       je       SHORT G_M000_IG187
       mov      rdi, gword ptr [rbp-0x2A0]
       mov      r9d, dword ptr [rbp-0x1D4]
       jmp      G_M000_IG107
 
G_M000_IG189:                ;; offset=0x1813
       mov      r8, qword ptr [rbp-0x168]
       vmovups  ymm0, ymmword ptr [r9+r8]
       mov      rcx, bword ptr [rbp-0x2B8]
       vpcmpeqb k1, ymm0, ymmword ptr [rcx+r8]
       kortestd k1, k1
       jb       G_M000_IG99
 
G_M000_IG190:                ;; offset=0x1839
       mov      rdi, gword ptr [rbp-0x2A0]
       mov      r9d, dword ptr [rbp-0x1D4]
       jmp      G_M000_IG107
 
G_M000_IG191:                ;; offset=0x184C
       xor      ecx, ecx
       mov      qword ptr [rbp-0x150], rcx
       add      r8, -16
       mov      qword ptr [rbp-0x158], r8
       test     r8, r8
       je       SHORT G_M000_IG195
       vmovups  xmm0, xmmword ptr [r9]
       mov      rcx, bword ptr [rbp-0x2B8]
       vpcmpnequb k1, xmm0, xmmword ptr [rcx]
       kortestw k1, k1
       je       SHORT G_M000_IG193
 
G_M000_IG192:                ;; offset=0x187E
       mov      rdi, gword ptr [rbp-0x2A0]
       mov      r9d, dword ptr [rbp-0x1D4]
       jmp      G_M000_IG107
 
G_M000_IG193:                ;; offset=0x1891
       mov      r8, qword ptr [rbp-0x150]
       add      r8, 16
       cmp      qword ptr [rbp-0x158], r8
       ja       SHORT G_M000_IG194
       jmp      SHORT G_M000_IG195
 
G_M000_IG194:                ;; offset=0x18A7
       vmovups  xmm0, xmmword ptr [r9+r8]
       vpcmpnequb k1, xmm0, xmmword ptr [rcx+r8]
       kortestw k1, k1
       mov      qword ptr [rbp-0x150], r8
       je       SHORT G_M000_IG193
       mov      rdi, gword ptr [rbp-0x2A0]
       mov      r9d, dword ptr [rbp-0x1D4]
       jmp      G_M000_IG107
 
G_M000_IG195:                ;; offset=0x18D5
       mov      r8, qword ptr [rbp-0x158]
       vmovups  xmm0, xmmword ptr [r9+r8]
       mov      rcx, bword ptr [rbp-0x2B8]
       vpcmpeqb k1, xmm0, xmmword ptr [rcx+r8]
       kortestw k1, k1
       jb       G_M000_IG99
 
G_M000_IG196:                ;; offset=0x18FA
       mov      rdi, gword ptr [rbp-0x2A0]
       mov      r9d, dword ptr [rbp-0x1D4]
       jmp      G_M000_IG107
 
G_M000_IG197:                ;; offset=0x190D
       mov      rdi, rcx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG198:                ;; offset=0x1916
       mov      rdi, r8
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG199:                ;; offset=0x191F
       mov      eax, -1
       jmp      G_M000_IG114
 
G_M000_IG200:                ;; offset=0x1929
       mov      rsi, rdi
       mov      rdi, rdx
       call     CORINFO_HELP_CHKCASTCLASS
       int3     
 
G_M000_IG201:                ;; offset=0x1935
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG202:                ;; offset=0x193B
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG203:                ;; offset=0x1941
 
G_M000_IG204:                ;; offset=0x1941
       mov      gword ptr [rbp-0x270], r11
       mov      rdi, r11
       mov      esi, ecx
       call     [Lokad.Lython.Runtime.PyDict:ReadNativeValue(int):System.Object:this]
       mov      gword ptr [rbp-0x2C0], rax
       test     rax, rax
       jne      SHORT G_M000_IG207
 
G_M000_IG205:                ;; offset=0x195F
       mov      r9d, dword ptr [rbp-0x1D4]
 
G_M000_IG206:                ;; offset=0x1966
       xor      r10d, r10d
       jmp      G_M000_IG122
 
G_M000_IG207:                ;; offset=0x196E
       mov      rsi, qword ptr [rax]
       mov      rdi, 0x75E363C2B158
       cmp      rsi, rdi
       je       SHORT G_M000_IG209
 
G_M000_IG208:                ;; offset=0x1980
       mov      r9d, dword ptr [rbp-0x1D4]
       jmp      SHORT G_M000_IG206
 
G_M000_IG209:                ;; offset=0x1989
       mov      rdi, 0x75E363C2B158
       cmp      rsi, rdi
       je       SHORT G_M000_IG211
 
G_M000_IG210:                ;; offset=0x1998
       mov      rsi, rax
       mov      rdi, 0x75E363C2B158
       call     CORINFO_HELP_UNBOX
       mov      rax, gword ptr [rbp-0x2C0]
 
G_M000_IG211:                ;; offset=0x19B1
       vmovdqu  xmm0, xmmword ptr [rax+0x08]
       vmovdqu32 xmmword ptr [rbp-0x1A0], xmm0
 
G_M000_IG212:                ;; offset=0x19BD
       lea      rdi, [rbp-0x1A0]
       xor      esi, esi
       call     [System.Numerics.BigInteger:GetByteCount(bool):int:this]
       cmp      eax, 8
       jl       SHORT G_M000_IG214
 
G_M000_IG213:                ;; offset=0x19D1
       mov      r9d, dword ptr [rbp-0x1D4]
       jmp      SHORT G_M000_IG206
 
G_M000_IG214:                ;; offset=0x19DA
       mov      rdi, gword ptr [rbp-0x1A0]
       mov      rsi, qword ptr [rbp-0x198]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      qword ptr [rbp-0x1A8], rax
       mov      r9d, dword ptr [rbp-0x1D4]
       jmp      G_M000_IG119
 
G_M000_IG215:                ;; offset=0x1A01
       mov      gword ptr [rbp-0x270], rax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu32 xmmword ptr [rbp-0x1C0], xmm0
       lea      rdi, [rbp-0x1C0]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rdi, 0x75E363C2B158
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x2D0], rax
       lea      rdi, bword ptr [rax+0x08]
       mov      rsi, gword ptr [rbp-0x1C0]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rbp-0x1B8]
       mov      rdi, gword ptr [rbp-0x2D0]
       mov      dword ptr [rdi+0x10], ecx
       mov      dword ptr [rsp], 1
       mov      rcx, rdi
       mov      rdi, gword ptr [rbp-0x270]
       mov      esi, dword ptr [rbp-0x130]
       mov      rdx, gword ptr [rbp-0x2C8]
       mov      r8d, dword ptr [rbp-0xE8]
       xor      r9d, r9d
       call     [Lokad.Lython.Runtime.PyDict:PublishNativeValue(int,System.Object,System.Object,uint,bool,bool):System.Object:this]
       jmp      G_M000_IG120
 
G_M000_IG216:                ;; offset=0x1A89
       inc      dword ptr [rax+0x48]
       jmp      G_M000_IG121
 
G_M000_IG217:                ;; offset=0x1A91
       xor      r10d, r10d
       jmp      G_M000_IG122
 
G_M000_IG218:                ;; offset=0x1A99
       mov      rsi, gword ptr [rbp-0x230]
       mov      rax, gword ptr [rsi+0xA0]
       cmp      qword ptr [rax+0x168], 0
       jle      SHORT G_M000_IG220
 
G_M000_IG219:                ;; offset=0x1AB1
       dec      qword ptr [rax+0x168]
 
G_M000_IG220:                ;; offset=0x1AB8
       test     edi, edi
       je       G_M000_IG50
 
G_M000_IG221:                ;; offset=0x1AC0
       mov      rdi, bword ptr [rbp-0x228]
       lea      rax, bword ptr [rdi+0x28]
       mov      rdx, bword ptr [rbp-0x250]
       cmp      dword ptr [rdx+0x18], 0
       jl       G_M000_IG233
 
G_M000_IG222:                ;; offset=0x1ADC
       mov      r8d, dword ptr [rdx+0x18]
 
G_M000_IG223:                ;; offset=0x1AE0
       mov      rdi, rax
       mov      esi, r8d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       cmp      dword ptr [rbp-0x30], 0
       je       G_M000_IG228
 
G_M000_IG224:                ;; offset=0x1AF6
       mov      rdi, bword ptr [rbp-0x228]
       mov      ecx, dword ptr [rbp-0x2C]
       mov      dword ptr [rdi+0x20], ecx
       mov      r11, bword ptr [rbp-0x260]
       mov      rdx, gword ptr [r11]
       mov      rsi, gword ptr [rbp-0x230]
       mov      r8, gword ptr [rsi+0xA0]
       mov      r9, gword ptr [r8+0x88]
       mov      r9, gword ptr [r9+0x20]
       test     r9, r9
       jne      G_M000_IG266
       mov      r8, gword ptr [r8+0x178]
       test     r8, r8
       jne      G_M000_IG267
 
G_M000_IG225:                ;; offset=0x1B3F
       cmp      dword ptr [rbp-0x34], 0
       je       G_M000_IG269
       cmp      dword ptr [rbp-0x74], 0
       je       G_M000_IG234
 
G_M000_IG226:                ;; offset=0x1B53
       mov      r8, qword ptr [rbp-0x80]
       mov      qword ptr [rbp-0xB0], r8
 
G_M000_IG227:                ;; offset=0x1B5E
       mov      rdi, gword ptr [rbp-0x2E8]
       mov      esi, dword ptr [rbp-0x1D8]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       add      rax, qword ptr [rbp-0xB0]
       mov      qword ptr [rbp-0x80], rax
       mov      dword ptr [rbp-0x74], 1
       mov      rsi, 0xFF80000000000000
       cmp      rax, rsi
       jl       G_M000_IG268
       mov      rsi, 0x80000000000000
       cmp      rax, rsi
       jge      G_M000_IG268
 
G_M000_IG228:                ;; offset=0x1BA9
       mov      rdi, bword ptr [rbp-0x228]
       mov      dword ptr [rdi+0x20], r14d
       mov      rcx, gword ptr [rbx]
       mov      rsi, gword ptr [rbp-0x230]
       mov      rdx, gword ptr [rsi+0xA0]
       mov      r8, gword ptr [rdx+0x88]
       mov      r8, gword ptr [r8+0x20]
       test     r8, r8
       jne      G_M000_IG270
       mov      rdx, gword ptr [rdx+0x178]
       test     rdx, rdx
       jne      G_M000_IG271
 
G_M000_IG229:                ;; offset=0x1BE9
       mov      ecx, dword ptr [rbx+0x10]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu32 xmmword ptr [rbp-0x1D0], xmm0
       cmp      gword ptr [rbp-0x268], 0
       je       G_M000_IG272
       lea      rsi, [rbp-0xA0]
       mov      rdi, gword ptr [rbp-0x268]
       call     [Lokad.Lython.Runtime.Text.PyStringOps+CasedWhitespaceIteration:TryReadWord(byref):bool:this]
 
G_M000_IG230:                ;; offset=0x1C19
       test     eax, eax
       je       SHORT G_M000_IG237
 
G_M000_IG231:                ;; offset=0x1C1D
       vmovdqu32 xmm0, xmmword ptr [rbp-0xA0]
       vmovdqu  xmmword ptr [rbp-0x50], xmm0
       mov      rdi, qword ptr [rbp-0x90]
       mov      qword ptr [rbp-0x40], rdi
 
G_M000_IG232:                ;; offset=0x1C34
       jmp      G_M000_IG34
 
G_M000_IG233:                ;; offset=0x1C39
       mov      r8d, dword ptr [rdx+0x18]
       not      r8d
       jmp      G_M000_IG223
 
G_M000_IG234:                ;; offset=0x1C45
       mov      r8, 0x75E363C2B158
       mov      r9, gword ptr [rbp-0x278]
       cmp      qword ptr [r9], r8
       je       SHORT G_M000_IG236
 
G_M000_IG235:                ;; offset=0x1C5B
       mov      rsi, r9
       mov      rdi, 0x75E363C2B158
       call     CORINFO_HELP_UNBOX
       mov      r9, gword ptr [rbp-0x278]
 
G_M000_IG236:                ;; offset=0x1C74
       mov      rdi, gword ptr [r9+0x08]
       mov      rsi, qword ptr [r9+0x10]
       call     [System.Numerics.BigInteger:op_Explicit(System.Numerics.BigInteger):long]
       mov      qword ptr [rbp-0xB0], rax
       jmp      G_M000_IG227
 
G_M000_IG237:                ;; offset=0x1C8E
       mov      dword ptr [rbp-0x84], 1
       mov      edi, dword ptr [rbx+0x1C]
       cmp      edi, 52
       jle      SHORT G_M000_IG241
 
G_M000_IG238:                ;; offset=0x1CA0
       add      edi, -57
       cmp      edi, 12
       ja       SHORT G_M000_IG240
 
G_M000_IG239:                ;; offset=0x1CA8
       mov      esi, 0x1041
       bt       esi, edi
       jb       SHORT G_M000_IG243
 
G_M000_IG240:                ;; offset=0x1CB2
       mov      rdi, rbx
       mov      rsi, 0x75E360215018
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG241:                ;; offset=0x1CCE
       cmp      edi, 42
       je       SHORT G_M000_IG243
 
G_M000_IG242:                ;; offset=0x1CD3
       add      edi, -50
       cmp      edi, 2
       ja       SHORT G_M000_IG240
 
G_M000_IG243:                ;; offset=0x1CDB
       mov      edi, dword ptr [rbx+0x08]
       mov      r15, bword ptr [rbp-0x228]
       mov      dword ptr [r15+0x20], edi
       jmp      G_M000_IG51
 
G_M000_IG244:                ;; offset=0x1CEE
       mov      rsi, r15
       mov      rdx, rbx
       mov      rcx, gword ptr [rbp-0x50]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       xor      edi, edi
       mov      dword ptr [rbp-0x58], edi
       mov      rdi, bword ptr [rbp-0x228]
       jmp      G_M000_IG37
 
G_M000_IG245:                ;; offset=0x1D0F
       cmp      dword ptr [rsi+0x20], 0
       je       G_M000_IG38
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       mov      rdi, bword ptr [rbp-0x228]
       jmp      G_M000_IG38
 
G_M000_IG246:                ;; offset=0x1D2E
       mov      rdi, 0x75E363D43E58
       cmp      qword ptr [rax], rdi
       jne      G_M000_IG43
 
G_M000_IG247:                ;; offset=0x1D41
       mov      gword ptr [rbp-0x280], rax
       mov      rsi, bword ptr [rbp-0x250]
       mov      rdi, bword ptr [rbp-0x228]
       jmp      G_M000_IG44
 
G_M000_IG248:                ;; offset=0x1D5B
       xor      r9, r9
       jmp      G_M000_IG46
 
G_M000_IG249:                ;; offset=0x1D63
       cmp      gword ptr [rbp-0x280], 0
       je       G_M000_IG50
       jmp      G_M000_IG48
 
G_M000_IG250:                ;; offset=0x1D76
       jmp      G_M000_IG55
 
G_M000_IG251:                ;; offset=0x1D7B
       cmp      gword ptr [rbp-0x2F0], 0
       jne      SHORT G_M000_IG254
       test     esi, esi
       jl       SHORT G_M000_IG252
       xor      esi, esi
       jmp      SHORT G_M000_IG253
 
G_M000_IG252:                ;; offset=0x1D8D
       mov      esi, 255
 
G_M000_IG253:                ;; offset=0x1D92
       mov      dword ptr [rbp-0xD4], esi
       movsxd   rsi, dword ptr [rbp-0x1DC]
       jmp      G_M000_IG257
 
G_M000_IG254:                ;; offset=0x1DA4
       cmp      esi, -1
       jne      SHORT G_M000_IG256
       mov      dword ptr [rbp-0xD4], 255
       mov      rsi, gword ptr [rbp-0x2F0]
       add      rsi, 16
       mov      bword ptr [rbp-0x2F8], rsi
       mov      rsi, gword ptr [rbp-0x2F0]
       mov      esi, dword ptr [rsi+0x08]
       mov      rdi, bword ptr [rbp-0x2F8]
       mov      edx, esi
       xor      esi, esi
       call     [System.SpanHelpers:NonPackedIndexOfValueType[long,System.SpanHelpers+Negate`1[long]](byref,long,int):int]
       mov      rdi, gword ptr [rbp-0x2F0]
       mov      esi, dword ptr [rdi+0x08]
       dec      esi
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG276
       mov      esi, dword ptr [rdi+0x08]
       dec      esi
       mov      rsi, qword ptr [rdi+8*rsi+0x10]
       not      rsi
       mov      ecx, dword ptr [rdi+0x08]
       dec      ecx
       cmp      ecx, eax
       jne      SHORT G_M000_IG255
       inc      rsi
       jmp      SHORT G_M000_IG257
 
G_M000_IG255:                ;; offset=0x1E10
       jmp      SHORT G_M000_IG257
 
G_M000_IG256:                ;; offset=0x1E12
       xor      esi, esi
       mov      dword ptr [rbp-0xD4], esi
       mov      rsi, gword ptr [rbp-0x2F0]
       mov      esi, dword ptr [rsi+0x08]
       dec      esi
       mov      r11, gword ptr [rbp-0x2F0]
       cmp      esi, dword ptr [r11+0x08]
       jae      G_M000_IG276
       mov      esi, dword ptr [r11+0x08]
       dec      esi
       mov      rsi, qword ptr [r11+8*rsi+0x10]
 
G_M000_IG257:                ;; offset=0x1E42
       cmp      dword ptr [rbp-0xD4], 0
       jne      SHORT G_M000_IG260
       mov      qword ptr [rbp-0xE0], rsi
       lzcnt    rsi, rsi
       shr      esi, 3
       neg      esi
       add      esi, 7
       test     esi, esi
       jle      SHORT G_M000_IG258
       jmp      SHORT G_M000_IG259
 
G_M000_IG258:                ;; offset=0x1E65
       xor      esi, esi
 
G_M000_IG259:                ;; offset=0x1E67
       jmp      SHORT G_M000_IG262
 
G_M000_IG260:                ;; offset=0x1E69
       mov      qword ptr [rbp-0xE0], rsi
       not      rsi
       lzcnt    rsi, rsi
       shr      esi, 3
       neg      esi
       add      esi, 7
       test     esi, esi
       jle      SHORT G_M000_IG261
       jmp      SHORT G_M000_IG262
 
G_M000_IG261:                ;; offset=0x1E86
       xor      esi, esi
 
G_M000_IG262:                ;; offset=0x1E88
       mov      dword ptr [rbp-0xE4], esi
       shl      esi, 3
       shrx     rsi, qword ptr [rbp-0xE0], rsi
       movzx    rsi, sil
       and      esi, 128
       mov      dword ptr [rbp-0x34C], esi
       mov      esi, dword ptr [rbp-0xD4]
       and      esi, 128
       cmp      dword ptr [rbp-0x34C], esi
       je       SHORT G_M000_IG263
       mov      esi, 1
       jmp      SHORT G_M000_IG264
 
G_M000_IG263:                ;; offset=0x1EC5
       xor      esi, esi
 
G_M000_IG264:                ;; offset=0x1EC7
       test     esi, esi
       setne    sil
       movzx    rsi, sil
       mov      r11d, dword ptr [rbp-0xE4]
       lea      esi, [r11+rsi+0x01]
       mov      r11, gword ptr [rbp-0x2F0]
       test     r11, r11
       je       SHORT G_M000_IG265
       mov      r11d, dword ptr [r11+0x08]
       sub      r11d, 1
       imul     r11d, r11d, 8
       jo       G_M000_IG277
       add      esi, r11d
       jo       G_M000_IG277
 
G_M000_IG265:                ;; offset=0x1F04
       cmp      esi, 8
       jl       G_M000_IG55
       jmp      G_M000_IG50
 
G_M000_IG266:                ;; offset=0x1F12
       mov      rdi, r9
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG267:                ;; offset=0x1F1B
       cmp      dword ptr [r8+0x20], 0
       je       G_M000_IG225
       mov      rdi, rdx
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG225
 
G_M000_IG268:                ;; offset=0x1F34
       mov      r14d, dword ptr [rbp-0x2C]
       add      r14d, 2
       mov      rdi, bword ptr [rbp-0x228]
       mov      dword ptr [rdi+0x20], r14d
       jmp      G_M000_IG51
 
G_M000_IG269:                ;; offset=0x1F4C
       mov      rsi, gword ptr [rbp-0x278]
       mov      rdi, 0x75E363C2B158
       call     CORINFO_HELP_UNBOX
       mov      rdi, gword ptr [rax]
       mov      esi, dword ptr [rax+0x08]
       mov      rax, gword ptr [rbp-0x230]
       mov      r8, gword ptr [rax+0xA0]
       mov      r8, gword ptr [r8+0x88]
       mov      rdx, gword ptr [rbp-0x2E8]
       mov      ecx, dword ptr [rbp-0x1D8]
       mov      r11, bword ptr [rbp-0x260]
       mov      r9, gword ptr [r11]
       call     [Lokad.Lython.Runtime.LythonRuntime:AddExactIntegers(System.Numerics.BigInteger,System.Numerics.BigInteger,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      rcx, rax
       mov      rsi, r15
       mov      rdx, bword ptr [rbp-0x260]
       mov      rdi, bword ptr [rbp-0x228]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutionContext:PublishInstructionResult(byref,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,System.Object)]
       jmp      G_M000_IG228
 
G_M000_IG270:                ;; offset=0x1FB9
       mov      rdi, r8
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG271:                ;; offset=0x1FC2
       cmp      dword ptr [rdx+0x20], 0
       je       G_M000_IG229
       mov      rdi, rcx
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionCanceled(Lokad.Lython.LythonSourceSpan)]
       jmp      G_M000_IG229
 
G_M000_IG272:                ;; offset=0x1FDA
       vxorps   xmm0, xmm0, xmm0
       vmovdqu32 xmmword ptr [rbp-0xA0], xmm0
       vmovdqu  xmmword ptr [rbp-0x98], xmm0
       mov      rdi, bword ptr [rbp-0x228]
       add      rdi, 40
       lea      rdx, [rbp-0x1D0]
       mov      esi, ecx
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryAdvanceNativeIteration(int,byref):bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG273
       mov      rdi, 0x75E362F77A68
       call     CORINFO_HELP_NEWSFAST
       mov      r14, rax
       mov      rdi, r14
       mov      rsi, 0x75E360218B68
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, r14
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG273:                ;; offset=0x2039
       movzx    rax, byte  ptr [rbp-0x1C8]
       mov      dword ptr [rbp-0x54], eax
       test     eax, eax
       je       SHORT G_M000_IG275
       lea      rdi, [rbp-0x1D0]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_Value():System.Object:this]
       mov      gword ptr [rbp-0xA0], rax
       mov      eax, dword ptr [rbp-0x54]
       jmp      G_M000_IG230
 
G_M000_IG274:                ;; offset=0x2063
       mov      rdi, r9
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG275:                ;; offset=0x206C
       mov      eax, dword ptr [rbp-0x54]
       jmp      G_M000_IG230
 
G_M000_IG276:                ;; offset=0x2074
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG277:                ;; offset=0x207A
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG278:                ;; offset=0x2080
       call     G_M000_IG331
       nop      
 
G_M000_IG279:                ;; offset=0x2086
       mov      eax, dword ptr [rbp-0xA4]
 
G_M000_IG280:                ;; offset=0x208C
       vzeroupper 
       add      rsp, 840
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG281:                ;; offset=0x20A1
       mov      esi, dword ptr [rbx+0x10]
       mov      rdi, bword ptr [rbp-0x228]
       add      rdi, 40
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
       mov      edi, dword ptr [rbx+0x1C]
       cmp      edi, 52
       jle      SHORT G_M000_IG285
 
G_M000_IG282:                ;; offset=0x20BD
       add      edi, -57
       cmp      edi, 12
       ja       SHORT G_M000_IG284
 
G_M000_IG283:                ;; offset=0x20C5
       mov      esi, 0x1041
       bt       esi, edi
       jb       SHORT G_M000_IG287
 
G_M000_IG284:                ;; offset=0x20CF
       mov      rdi, rbx
       mov      rsi, 0x75E360215018
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG285:                ;; offset=0x20EB
       cmp      edi, 42
       je       SHORT G_M000_IG287
 
G_M000_IG286:                ;; offset=0x20F0
       add      edi, -50
       cmp      edi, 2
       ja       SHORT G_M000_IG284
 
G_M000_IG287:                ;; offset=0x20F8
       mov      eax, dword ptr [rbx+0x08]
       mov      r15, bword ptr [rbp-0x228]
       mov      dword ptr [r15+0x20], eax
       mov      eax, 1
 
G_M000_IG288:                ;; offset=0x210B
       vzeroupper 
       add      rsp, 840
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG289:                ;; offset=0x2120
       test     byte  ptr [(reloc 0x75e363c2b3a8)], 1
       je       G_M000_IG306
 
G_M000_IG290:                ;; offset=0x212D
       mov      r9, 0x75DB81803ED8
       mov      r9, gword ptr [r9]
       mov      gword ptr [rbp-0x338], r9
       mov      r9, gword ptr [r9+0x08]
       mov      rdx, gword ptr [rbp-0x338]
       mov      edx, dword ptr [rdx+0x10]
       mov      eax, edx
       mov      rdx, r9
       jmp      G_M000_IG16
 
G_M000_IG291:                ;; offset=0x2159
       xor      r9d, r9d
       jmp      G_M000_IG20
 
G_M000_IG292:                ;; offset=0x2161
       mov      r9, rsi
       mov      rdi, bword ptr [rbp-0x228]
       jmp      G_M000_IG23
 
G_M000_IG293:                ;; offset=0x2170
       xor      eax, eax
       jmp      G_M000_IG29
 
G_M000_IG294:                ;; offset=0x2177
       mov      rdi, rbx
       call     [Lokad.Lython.Frontend.ExecutableInstruction:get_LiveExtent():int:this]
       jmp      G_M000_IG05
 
G_M000_IG295:                ;; offset=0x2185
       xor      eax, eax
 
G_M000_IG296:                ;; offset=0x2187
       vzeroupper 
       add      rsp, 840
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG297:                ;; offset=0x219C
       mov      rdi, rbx
       mov      rsi, 0x75E360218BE0
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG298:                ;; offset=0x21B8
       mov      rdi, rax
       mov      rsi, 0x75E360210F00
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG299:                ;; offset=0x21D4
       call     [System.ThrowHelper:ThrowArgumentOutOfRange_IndexMustBeLessException()]
       int3     
 
G_M000_IG300:                ;; offset=0x21DB
       mov      rdi, rsi
       mov      esi, r11d
       mov      r11, 0x75E361642F30
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      r12, rax
       jmp      G_M000_IG06
 
G_M000_IG301:                ;; offset=0x21F6
       cmp      esi, 8
       je       G_M000_IG07
 
G_M000_IG302:                ;; offset=0x21FF
       mov      rdi, rdx
       mov      rsi, 0x75E360211958
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG303:                ;; offset=0x221B
       cmp      esi, 65
       je       G_M000_IG07
       cmp      esi, 68
       jne      SHORT G_M000_IG302
       jmp      G_M000_IG07
 
G_M000_IG304:                ;; offset=0x222E
       mov      rdi, r8
       mov      r11, 0x75E361642F38
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rdx, rax
       jmp      G_M000_IG08
 
G_M000_IG305:                ;; offset=0x2246
       mov      rdi, rsi
       mov      esi, r11d
       mov      r11, 0x75E361642F40
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       mov      rcx, rax
       jmp      G_M000_IG09
 
G_M000_IG306:                ;; offset=0x2261
       mov      rdi, 0x75E363C2B158
       call     CORINFO_HELP_GET_GCSTATIC_BASE
       mov      rdi, bword ptr [rbp-0x228]
       jmp      G_M000_IG290
 
G_M000_IG307:                ;; offset=0x227C
       mov      rdi, r9
       mov      esi, edx
       mov      r11, 0x75E361642F48
       call     [r11]System.Collections.Generic.IReadOnlyList`1[System.__Canon]:get_Item(int):System.__Canon:this
       jmp      G_M000_IG13
 
G_M000_IG308:                ;; offset=0x2293
       xor      r9, r9
       jmp      G_M000_IG19
 
G_M000_IG309:                ;; offset=0x229B
       mov      rdi, 0x75E362F77A68
       call     CORINFO_HELP_NEWSFAST
       mov      rbx, rax
       mov      rdi, rbx
       mov      rsi, 0x75E36020D5A0
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, rbx
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG310:                ;; offset=0x22C9
       mov      r9, gword ptr [rbp-0x268]
       mov      rdi, gword ptr [r9+0x18]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.Text.PyString:get_Utf8Span():System.ReadOnlySpan`1[byte]:this]
       mov      rdi, rax
       mov      esi, edx
       mov      rcx, gword ptr [rbp-0x268]
       mov      r8d, dword ptr [rcx+0x30]
       mov      rcx, gword ptr [rbp-0x268]
       mov      rcx, gword ptr [rcx+0x28]
       mov      gword ptr [rsp], rcx
       mov      rcx, gword ptr [rbp-0x268]
       mov      rcx, gword ptr [rcx+0x20]
       mov      gword ptr [rsp+0x08], rcx
       mov      ecx, dword ptr [rbp-0x1EC]
       mov      edx, dword ptr [rbp-0x1E8]
       shl      rdx, 32
       mov      r9d, dword ptr [rbp-0x1E4]
       or       rdx, r9
       mov      r9, gword ptr [rbp-0x268]
       mov      r9, gword ptr [r9+0x08]
       shl      r8, 32
       or       r8, 1
       call     [Lokad.Lython.Runtime.Text.PyStringOps:CreateSplitFragment(System.ReadOnlySpan`1[byte],System.ValueTuple`3[int,int,int],System.Nullable`1[int],Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext):Lokad.Lython.Runtime.Text.PyString]
       mov      gword ptr [rbp-0x50], rax
       jmp      G_M000_IG28
 
G_M000_IG311:                ;; offset=0x2347
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG312:                ;; offset=0x234E
       add      rdi, 40
       lea      rdx, [rbp-0xD0]
       mov      esi, r9d
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:TryAdvanceNativeIteration(int,byref):bool:this]
       test     eax, eax
       je       G_M000_IG295
       movzx    rax, byte  ptr [rbp-0xC8]
       mov      dword ptr [rbp-0x54], eax
       test     eax, eax
       je       SHORT G_M000_IG314
       lea      rdi, [rbp-0xD0]
       call     [Lokad.Lython.Runtime.PyIterationResult:get_Value():System.Object:this]
       mov      gword ptr [rbp-0x50], rax
       mov      eax, dword ptr [rbp-0x54]
       jmp      G_M000_IG29
 
G_M000_IG313:                ;; offset=0x2391
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG314:                ;; offset=0x2397
       mov      eax, dword ptr [rbp-0x54]
       jmp      G_M000_IG29
 
G_M000_IG315:                ;; offset=0x239F
       sub      rsp, 24
 
G_M000_IG316:                ;; offset=0x23A3
       mov      rsi, gword ptr [rbp-0x230]
       mov      rax, gword ptr [rsi+0xA0]
       cmp      qword ptr [rax+0x168], 0
       jle      SHORT G_M000_IG318
 
G_M000_IG317:                ;; offset=0x23BB
       dec      qword ptr [rax+0x168]
 
G_M000_IG318:                ;; offset=0x23C2
       vzeroupper 
       add      rsp, 24
       ret      
 
G_M000_IG319:                ;; offset=0x23CA
       sub      rsp, 24
 
G_M000_IG320:                ;; offset=0x23CE
       cmp      dword ptr [rbp-0x74], 0
       je       G_M000_IG327
 
G_M000_IG321:                ;; offset=0x23D8
       mov      r15, bword ptr [rbp-0x228]
       mov      rbx, gword ptr [r15+0x08]
       mov      r11, bword ptr [rbp-0x260]
       mov      r14d, dword ptr [r11+0x10]
       lea      rdi, [rbp-0xC0]
       mov      rsi, qword ptr [rbp-0x80]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rdi, 0x75E363C2B158
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       lea      rdi, bword ptr [r13+0x08]
       mov      rsi, gword ptr [rbp-0xC0]
       call     CORINFO_HELP_ASSIGN_REF
       mov      edi, dword ptr [rbp-0xB8]
       mov      dword ptr [r13+0x10], edi
       movsxd   rdi, r14d
       mov      rdx, r13
       mov      esi, dword ptr [rbx+0x08]
       cmp      rsi, rdi
       ja       SHORT G_M000_IG323
 
G_M000_IG322:                ;; offset=0x2439
       call     [System.Runtime.CompilerServices.CastHelpers:ThrowIndexOutOfRangeException()]
       int3     
 
G_M000_IG323:                ;; offset=0x2440
       lea      rdi, bword ptr [rbx+8*rdi+0x10]
       mov      rsi, qword ptr [rbx]
       mov      rsi, qword ptr [rsi+0x30]
       cmp      rsi, qword ptr [rdx]
       jne      SHORT G_M000_IG325
 
G_M000_IG324:                ;; offset=0x2451
       mov      rsi, rdx
       call     CORINFO_HELP_ASSIGN_REF
       jmp      SHORT G_M000_IG327
 
G_M000_IG325:                ;; offset=0x245B
       mov      rax, 0x75E3628627A0
       cmp      qword ptr [rbx], rax
       je       SHORT G_M000_IG324
 
G_M000_IG326:                ;; offset=0x246A
       call     [System.Runtime.CompilerServices.CastHelpers:StelemRef_Helper(byref,ptr,System.Object)]
       nop      
 
G_M000_IG327:                ;; offset=0x2471
       cmp      dword ptr [rbp-0x84], 0
       je       SHORT G_M000_IG329
 
G_M000_IG328:                ;; offset=0x247A
       mov      r15, bword ptr [rbp-0x228]
       lea      rdi, bword ptr [r15+0x28]
       mov      rbx, bword ptr [rbp-0x238]
       mov      esi, dword ptr [rbx+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableValueStorage:RetireTo(int):this]
 
G_M000_IG329:                ;; offset=0x2495
       nop      
 
G_M000_IG330:                ;; offset=0x2496
       vzeroupper 
       add      rsp, 24
       ret      
 
G_M000_IG331:                ;; offset=0x249E
       sub      rsp, 24
 
G_M000_IG332:                ;; offset=0x24A2
       cmp      dword ptr [rbp-0x58], 0
       je       G_M000_IG353
 
G_M000_IG333:                ;; offset=0x24AC
       mov      r15, bword ptr [rbp-0x228]
       mov      rbx, gword ptr [r15+0x08]
       mov      rsi, bword ptr [rbp-0x250]
       mov      edi, dword ptr [rsi+0x1C]
       cmp      edi, 11
       je       SHORT G_M000_IG335
 
G_M000_IG334:                ;; offset=0x24C6
       cmp      edi, 12
       je       SHORT G_M000_IG335
       mov      rdi, rsi
       mov      rsi, 0x75E3602150C0
       call     [Lokad.Lython.Frontend.ExecutableInstruction:InvalidOperand(System.String):System.InvalidOperationException:this]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG335:                ;; offset=0x24E7
       mov      r14d, dword ptr [rsi+0x14]
       mov      rdi, gword ptr [rbp-0x268]
       cmp      byte  ptr [rdi], dil
       cmp      gword ptr [rbp-0x70], 0
       je       SHORT G_M000_IG337
 
G_M000_IG336:                ;; offset=0x24FC
       mov      r13, gword ptr [rbp-0x70]
       jmp      G_M000_IG345
 
G_M000_IG337:                ;; offset=0x2505
       mov      r13d, dword ptr [rbp-0x64]
       mov      rdi, gword ptr [rbp-0x268]
       mov      r12, gword ptr [rdi+0x08]
       mov      rdi, 0x75E363D43E58
       call     CORINFO_HELP_NEWSFAST
       mov      rdx, rax
       mov      gword ptr [rbp-0x2D8], rdx
       mov      dword ptr [rdx+0x1C], -1
       test     r13d, r13d
       jg       SHORT G_M000_IG339
 
G_M000_IG338:                ;; offset=0x2539
       mov      edi, r13d
       mov      rsi, 0x75E360202400
       call     [System.ArgumentOutOfRangeException:ThrowNegativeOrZero[int](int,System.String)]
       int3     
 
G_M000_IG339:                ;; offset=0x254D
       cmp      r13d, 8
       jg       SHORT G_M000_IG340
       mov      byte  ptr [rdx+0x24], r13b
       jmp      SHORT G_M000_IG341
 
G_M000_IG340:                ;; offset=0x2559
       movsxd   rsi, r13d
       mov      rdi, 0x75E36297CCD0
       call     CORINFO_HELP_NEWARR_1_VC
       mov      rsi, rax
       mov      rdx, gword ptr [rbp-0x2D8]
       lea      rdi, bword ptr [rdx+0x08]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG341:                ;; offset=0x257E
       mov      rdx, gword ptr [rbp-0x2D8]
       mov      dword ptr [rdx+0x18], r13d
       lea      rdi, bword ptr [rdx+0x10]
       mov      rsi, r12
       call     CORINFO_HELP_ASSIGN_REF
       mov      r13d, dword ptr [rbp-0x68]
       cmp      r13d, 8
       jbe      SHORT G_M000_IG343
 
G_M000_IG342:                ;; offset=0x259F
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG343:                ;; offset=0x25A6
       mov      rdi, gword ptr [rbp-0x2D8]
       call     [Lokad.Lython.Runtime.Text.PyString:get_UnpublishedUtf8():System.Span`1[byte]:this]
       mov      rdi, rax
       cmp      r13d, edx
       ja       SHORT G_M000_IG344
       mov      edx, r13d
       lea      rsi, bword ptr [rbp-0x60]
       call     [System.SpanHelpers:Memmove(byref,byref,nuint)]
       mov      rdi, gword ptr [rbp-0x2D8]
       mov      esi, dword ptr [rbp-0x68]
       call     [Lokad.Lython.Runtime.Text.PyString:CompleteUnpublishedUtf8(int):this]
       mov      r13, gword ptr [rbp-0x2D8]
       mov      gword ptr [rbp-0x70], r13
       jmp      SHORT G_M000_IG345
 
G_M000_IG344:                ;; offset=0x25E5
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG345:                ;; offset=0x25EC
       movsxd   rdi, r14d
       mov      esi, dword ptr [rbx+0x08]
       cmp      rsi, rdi
       ja       SHORT G_M000_IG347
 
G_M000_IG346:                ;; offset=0x25F7
       call     [System.Runtime.CompilerServices.CastHelpers:ThrowIndexOutOfRangeException()]
       int3     
 
G_M000_IG347:                ;; offset=0x25FE
       lea      rdi, bword ptr [rbx+8*rdi+0x10]
       mov      rsi, qword ptr [rbx]
       mov      rsi, qword ptr [rsi+0x30]
       test     r13, r13
       je       SHORT G_M000_IG350
 
G_M000_IG348:                ;; offset=0x260F
       cmp      rsi, qword ptr [r13]
       jne      SHORT G_M000_IG351
 
G_M000_IG349:                ;; offset=0x2615
       mov      rsi, r13
       call     CORINFO_HELP_ASSIGN_REF
       jmp      SHORT G_M000_IG353
 
G_M000_IG350:                ;; offset=0x261F
       xor      rsi, rsi
       mov      gword ptr [rdi], rsi
       jmp      SHORT G_M000_IG353
 
G_M000_IG351:                ;; offset=0x2626
       mov      rdx, 0x75E3628627A0
       cmp      qword ptr [rbx], rdx
       je       SHORT G_M000_IG349
 
G_M000_IG352:                ;; offset=0x2635
       mov      rdx, r13
       call     [System.Runtime.CompilerServices.CastHelpers:StelemRef_Helper(byref,ptr,System.Object)]
       nop      
 
G_M000_IG353:                ;; offset=0x263F
       call     G_M000_IG319
       nop      
 
G_M000_IG354:                ;; offset=0x2645
       vzeroupper 
       add      rsp, 24
       ret      
 
RWD00  	dd	0000127Fh ; case G_M000_IG148
       	dd	000011A4h ; case G_M000_IG146
       	dd	0000119Ch ; case G_M000_IG145

; Total bytes of code 9805

