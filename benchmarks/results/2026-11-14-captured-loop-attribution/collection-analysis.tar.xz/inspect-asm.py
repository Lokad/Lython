from pathlib import Path
import collections,re
r=Path(__file__).parent
asm=(r/'retrieved/profiles/captured/dictionary-loop.asm').read_text(encoding='utf-8')
for body in re.split(r'(?=; Assembly listing for method )',asm):
 if 'TryExecuteDictionaryLoop('not in body:continue
 print(body.splitlines()[0], re.findall(r'; Total bytes of code (\d+)',body))
 labels=list(re.finditer(r'^(G_M\d+_IG\d+):[^\n]*offset=0x([0-9a-fA-F]+)',body,re.M));offsets=[int(v[2],16)for v in labels]
 print('labels',len(labels),'first/last',[(v[1],v[2])for v in labels[:3]+labels[-3:]],'duplicateOffsets',[(hex(v),n)for v,n in collections.Counter(offsets).items()if n>1])
 print('descending',[(labels[i-1][1],labels[i-1][2],v[1],v[2])for i,v in enumerate(labels)if i and offsets[i]<offsets[i-1]])
 print('end',body[-1800:])
