from pathlib import Path
import datetime,hashlib,json,shutil,tarfile
r=Path(__file__).parent;raw=json.loads((r/'attribution-captured.json').read_text(encoding='utf-8'));groups=json.loads((r/'dictionary-loop-instruction-groups.json').read_text(encoding='utf-8'));receipt=json.loads((r/'archive-receipt.json').read_text(encoding='utf-8'))
assert raw['samples']==963 and groups['dictionaryLoopLeafSamples']==168 and groups['tier1MapBytes']==groups['disassemblyBytes']==9805
assert sum(v['leafSamples']for v in groups['blocks'])==168 and receipt['ramTraceArchivedAndVerifiedBeforeUnmount']
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
out=Path('benchmarks/results/2026-11-14-captured-loop-attribution');out.mkdir()
for name in ['identity.json','prospective.json','attribution-captured.json','dictionary-loop-instruction-groups.json','analysis-correction.json','archive-receipt.json','terminal-status.json','observations.tgz']:shutil.copyfile(r/name,out/name)
with tarfile.open(out/'collection-analysis.tar.xz','w:xz')as t:
 for name in ['PLAN-before-capture.md','catalog.json','config.json','ops-profile.py','collect.py','run.sh','launch.py','launch-command.py','launch.log','observe-not-before.json','retrieve.py','prepare-analysis.py','analyze-captured.py','analyze-loop.py','initial-analyze-loop.py','correct-analysis.py','inspect-asm.py','close-and-select.py']:t.add(r/name,arcname=name)
 t.add(r.parent/'prepare-captured-ip-r342.py',arcname='prepare-captured-ip-r342.py')
(out/'README.md').write_text('''# Captured-text instruction attribution

2026-11-14UTC, B712/R342, exact committed2f606519/frozen53becdb6. One5s199Hz
cpu-clock/fp capture after8guest-second warmup on the quiet F4as_v7, unchanged
complete3072-line/35,840B captured text script and fixed worker/optional0.4adapter.
Perf maps and same-process JIT disassembly are explicit diagnostic overrides.
This is owning-source attribution, not a timing/allocation/CPython comparison.

963guest leaf samples/4.85guest CPU seconds;74unknown leaves(7.68%, including30
kernel), zero ambiguous leaves. Dictionary-loop Tier1 has168samples(17.45%). Its
unique same-process map/disassembly both have9805bytes, and every sampled IP maps
to an instruction group. The initial mapper rejected a zero-length group sharing
the next label address; preserve that failure and correct only the nondecreasing-
offset check. Empty groups map zero samples; no recapture or raw alteration.

Largest groups mix live instruction metadata, compact-word transport, hashing,
bucket/key probing and machine-counter updates. They are useful or mixed work,
with no single dominant complete call/frame/packet to remove. Stop this gate
without another entry/default-cache/argument-form tweak. Sample skid/inlining
limits source granularity; zero samples do not establish zero cost.

The wider profile identifies94leaves(9.76%)in cased-split preparation,53(5.50%)in
the case writer and18(1.87%)in scalar case mapping. These are separate leaves,
not removable shares. Inspecting the current pipeline shows a stored word-range
inventory followed by per-word casing/compact-byte transport. R230's historical
prepared-range reversal and R293/R324's delivered cache/cursor changes are reviewed.
They establish storage/scan tradeoffs, not a permanent ban on a changed pipeline.

Select R343's bounded bulk UTF8 representation redesign: case once into the owned
reusable cursor buffer, scan final bytes for preflight and consumption, and remove
range inventories/growth/copy/clear machinery. It must preserve eager all-word
admission, retained independent words, active/nested loans, current cancellation,
first refusal and reentrant/awaited cleanup. Extra scans and long-word scratch are
explicit risks to measure, not a speedup forecast. The existing cursor loan remains
one funded owner; no new pool, tracer, policy or backend.

All complete-image/golden/balance/quiet/join/archive gates pass. The120s owner
finishes cleanly; every RAM trace is independently archived/verified before unmount.
No workers/fixtures remain, no image/evidence retirement or VM-floor relaxation.
Full R341delivery remains independent; publication held.

[Groups](dictionary-loop-instruction-groups.json),[wider attribution](attribution-captured.json),
[raw](observations.tgz),[tools and initial mapper correction](collection-analysis.tar.xz).
''',encoding='utf-8',newline='\n')
with Path('benchmarks/EXPERIMENTS.md').open('a',encoding='utf-8',newline='\n')as f:f.write('''
## R342 — owning dictionary-loop instruction gate

[B712](results/2026-11-14-captured-loop-attribution/README.md) captures committed
2f606519/frozen53 with same-process JIT/map evidence:963guest leaves,74unknown,
zero ambiguous;168dictionary-loop leaves/unique9805-byte Tier1. Empty-block mapper
assertion corrected without recapture; original preserved. Groups mix useful
hash/update and small transport/protection work; no dominant removable call/frame
packet. Stop entry micro-tweaks. Cased preparation/writer costs motivate R343bulk
UTF8 representation, with R230/R293/R324history and scan/storage tradeoffs explicit.
All image/golden/quiet/join/RAM-archive gates pass; no normal timing/CPU-share forecast.
''')
n=r.parent/'bulk-cased-buffer-r343';n.mkdir();prior=r.parent/'shared-arithmetic-r341'
for name in ['candidate-core.dll','candidate-sources.tar.xz','candidate-identity.json']:shutil.copyfile(prior/name,n/('reference-'+name.removeprefix('candidate-')))
(n/'prospective.json').write_text(json.dumps(dict(recordedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),reference='2f606519/frozen53becdb6',hypothesis='A bulk final-UTF8 case/split representation can remove per-word casing, prepared range arrays and compact-byte transport while preserving the proven reusable owned cursor. R342preparation/case leaves motivate the pipeline, not a predicted removable percentage.',displaced='Remove CollectSeparatedRanges/CollectWhitespaceForward/CollectWhitespaceReverse/AppendSplitRange, range arrays/capacity/growth/copy/clear/cache sizing, per-range case bounds and CompactWordUtf8 copies. One existing cursor loan instead owns a reusable cased byte buffer. Plain splits count/size then scan into final list storage.',acceptance='Python split/rsplit whitespace/separator/maxsplit, Unicode expansion/context, eager full output admission, checked bounds, cancelled long work, terminal first refusal, retained words/results, concurrent/nested/late loans, reentrant refund, actual callback/I/O cleanup and shared allowance baseline reuse.',tradeoffs='Case-buffer capacity replaces range metadata: a long single word may reserve more scratch and reject earlier. Plain split and private consumption rescan bytes. No promise of tiny-budget equality or CPU benefit; final words remain independently funded. No new memory manager/pool/configuration.',measurement='Existing complete captured/ordinary text warm and captured compile-to-result vs exact53 reference, unchanged fulfillment control; short separate allocation diagnostic, one bounded affected/control VM collection. Preserve adverse outcomes; bounded correction/refinement if evidence justifies it. No return to per-line cursor allocation or wider hashing/value-VM redesign.'),indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');(n/'PLAN-before-r343.md').write_text(s,encoding='utf-8',newline='\n');a=s.index('2. **R342 active:');b=s.index('   R336\'s short configuration',a)
s=s[:a]+'''2. **R343 active: bulk final-UTF8 case/split representation.** R342closes its
   source gate:963leaves/74unknown,168dictionary-loop samples map to unique9805-byte
   Tier1. Hash/update and small mixed transport groups establish no dominant call/
   frame packet; no new entry micro-tweak. Preparation94leaves/writer53/scalar case18
   motivate a coherent pipeline question, not removable-time forecasts.
   Case a line once into the existing owned reusable cursor's UTF8 buffer. Count/
   preflight all final words, then scan for consumption; plain splits count/size
   and scan directly into admitted final arrays. Remove range inventories, grow/
   copy/clear plumbing, per-range case bounds and compact-byte copies. Keep one
   cursor loan, no new pool/owner/configuration/engine. Preserve R324's no-per-line-
   cursor-allocation and reentrant-retirement fix; R230/R293history stays archived.
   Compatibility tradeoff: long single words can retain more scratch/deny earlier;
   rescanning may cost CPU. Keep independent word funding and eager admission before
   effects. Acceptance: split/rsplit/maxsplit, all Python whitespace, Unicode
   expansion/context, aliases, cancellation, first refusal, active/nested/late loans,
   reentrant refunds, actual pending cleanup and shared-budget reuse. Delete obsolete
   range architecture assertions; preserve their semantic/lifetime regressions.
   Compare complete captured/ordinary text warm and captured compile-to-result vs
   exact53reference, unchanged fulfillment control; separate short allocation check.
   One bounded VM source pair, retain adversity; allow justified bounded refinement.
   Stop with delivery/debt decision, no wider hashing/value-VM redesign. [Source gate](benchmarks/results/2026-11-14-captured-loop-attribution/README.md).

'''+s[b:];s=s.replace('| Active runtime prototypes | None; R341is retained/committed with full qualification pending. |','| Active runtime prototype | R343bulk cased UTF8 buffer/range-inventory removal, selected from R342; no allocation/timing claim yet. |');p.write_text(s,encoding='utf-8',newline='\n')
print('Archived bounded source gate and selected concrete R343deletions/contract/acceptance before code.',flush=True)
