from pathlib import Path
import ast,datetime,hashlib,json,tarfile
r=Path(__file__).parent/'captured-loop-ip-r342';r.mkdir()
prior=r.parent/'native-entry-ip-r327';source=r.parent/'shared-arithmetic-r341'
oldroot='/home/lokad/lython-bench-checks/native-entry-ip-b695-20261113';root='/home/lokad/lython-bench-checks/captured-loop-ip-b712-20261114'
catalog=json.loads((source/'catalog.json').read_text(encoding='utf-8'));catalog['cases']=[c for c in catalog['cases']if c['id']=='scripts.text-summary-helpers.nonlocal-counter.large'];assert len(catalog['cases'])==1
(r/'catalog.json').write_text(json.dumps(catalog,separators=(',',':'),ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
image=json.loads((source/'b711/identity.json').read_text(encoding='utf-8'))
identity=dict(coreSHA256={'candidate':image['coreSHA256']['candidate']},auxiliaryFiles=image['candidateAuxiliaryFiles'],catalogSHA256=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest(),sourceRevision='Committed2f606519/frozen53becdb6; R342 captured dictionary-loop instruction attribution',diagnosticOnly=True,scriptCaptureWallSeconds=5,warmGuestSeconds=8,compilationExcluded=True,allocationStacksNotMeasured=True,disassemblyCollectedInTheSameProcessAsSamples=True,fullDelivery='43548640898pending; qualified reference1778c30d/38c0562f',noSpeedupForecast=True)
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
for name in ['ops-profile.py','collect.py','run.sh','retrieve.py']:
 s=(prior/name).read_text(encoding='utf-8').replace(oldroot,root).replace('Committede698656c/frozen660a0338; R327 native-entry instruction attribution',identity['sourceRevision'])
 if name=='ops-profile.py':s=s.replace("[('search', 'scripts.file-search.large', 'warm')]", "[('captured', 'scripts.text-summary-helpers.nonlocal-counter.large', 'warm')]").replace('*StartNativeCall*','*TryExecuteDictionaryLoop*').replace('native-entry.asm','dictionary-loop.asm')
 if name=='collect.py':s=s.replace("['search']","['captured']").replace('profiles/search/record.json','profiles/captured/record.json')
 if name.endswith('.py'):ast.parse(s)
 (r/name).write_text(s,encoding='utf-8',newline='\n')
s=(r.parent/'post-loan-profile-r325/launch.py').read_text(encoding='utf-8').replace('lython-b692-fixtures','lython-b712-fixtures')
s=s.replace("  shutil.copytree", "  shutil.copytree")
needle=" for name,sha in config['identity']['auxiliaryFiles'].items():assert digest(source/'candidate'/name)==sha"
assert needle in s
s=s.replace(needle,needle+"\n assert {p.name for p in(source/'candidate').iterdir()}==set(config['identity']['auxiliaryFiles'])|{'Lokad.Lython.dll'}\n assert source.resolve()==source and source.parent==base")
(r/'launch.py').write_text(s,encoding='utf-8',newline='\n');ast.parse(s)
with tarfile.open(r/'payload.tgz','w:gz')as t:
 for name in ['catalog.json','identity.json','ops-profile.py','collect.py','run.sh']:t.add(r/name,arcname=name)
with tarfile.open(r/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
config=dict(root=root,sourceRoot='/home/lokad/lython-bench-checks/shared-arithmetic-b711-20261114',unit='lython-b712-captured-loop-ip-20261114',identity=identity,payloadBytes=(r/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((r/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(r/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
(r/'prospective.json').write_text(json.dumps(dict(recordedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),previousGoalTurn='progress: R338/R339 full delivery and R340 external refresh archived; R341shared kernel committed/focused-qualified with bounded source-pair evidence and full delivery running',question='Do owning instruction groups in captured-text dictionary accumulation identify a substantial repeated phase or representation to remove?',hypothesis='R325method-level24% mixes useful inlined hash/update, scalar transport, call admission and cleanup. Exact same-process IP groups can distinguish candidates without equating a method share to removable overhead.',bound='One5s199Hz capture after8guest seconds warmup,120s owner, exact committed53 core and complete copied immutable image; no normal timing or speedup claim.',stoppingCriterion='Use the available groups to select a coherent eliminated phase/representation with semantic acceptance, or preserve a negative/uncertain decision and move the roadmap. No automatic micro-tweak, generic entry remeasurement, or new profiler framework.',constraints='Managed-only, current cancellation, admission/first refusal, retained owners and joined cleanup remain. Keep all unknown/adverse evidence; archive and verify every RAM trace before unmount.'),indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8');(r/'PLAN-before-capture.md').write_text(s,encoding='utf-8',newline='\n');s=s.replace('2. **R342: select a substantive next removal from owning work.**','2. **R342 active: select a substantive next removal from owning work.**');s=s.replace('   normal timing. Stop with a supported removal', '   normal timing. B712uses committed2f606519/frozen53, unchanged complete captured\n   source, one5s199Hz capture after8guest seconds, same-process dictionary-loop\n   JIT/disassembly and complete immutable image verification under120s ownership.\n   Stop with a supported removal');p.write_text(s,encoding='utf-8',newline='\n')
print('Prepared one bounded captured-text source gate; complete frozen image, no production mutation or timing campaign.',flush=True)
