from pathlib import Path
import json,shutil
r=Path(__file__).parent;p=r/'analyze-loop.py';shutil.copyfile(p,r/'initial-analyze-loop.py')
s=p.read_text(encoding='utf-8');s=s.replace('assert sorted(set(offsets)) == offsets and offsets[-1] < size','assert sorted(offsets) == offsets and offsets[-1] < size')
p.write_text(s,encoding='utf-8',newline='\n')
(r/'analysis-correction.json').write_text(json.dumps(dict(originalFailure='Unique-offset assertion rejected two adjacent labels at0x1941 in the same Tier1 method.',explanation='A zero-length instruction group shares the following label address. Preserve both blocks, allow nondecreasing offsets, and map an IP with bisect_right to the last group at its address. The empty block receives zero samples. Exact total code length and unique same-process Tier1 checks remain.',noRecapture=True,rawMeasurementUnchanged=True),indent=2)+'\n',encoding='utf-8',newline='\n')
