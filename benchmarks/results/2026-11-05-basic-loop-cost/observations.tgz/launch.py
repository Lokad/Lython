from pathlib import Path
import subprocess,tarfile
root=Path('/home/lokad/lython-bench-checks/integer-loop-cost-b289-20261105')
root.mkdir(exist_ok=False)
with tarfile.open('/home/lokad/lython-bench-checks/b289-payload.tgz') as t:t.extractall(root,filter='data')
subprocess.run(['python3',str(root/'setup.py')],check=True)
subprocess.run(['sudo','-n','systemd-run','--unit=lython-b289-integer-loop-cost-20261105','--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=45','--property=TimeoutStopSec=15','--property=KillMode=control-group','/bin/sh',str(root/'collect.sh')],check=True)
