from pathlib import Path
import ast,hashlib,json,os,re,subprocess,tarfile

lab=Path(__file__).resolve().parent
old=lab.parent/'rule-and-forwarding-attribution-r592/annotation-confirmation'
format_lab=lab.parent/'prepared-format-selectors-r598'
read=lambda p:p.read_text(encoding='utf-8-sig')
load=lambda p:json.loads(read(p))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,value):
    if name.endswith('.py'):ast.parse(value)
    (lab/name).write_text(value,encoding='utf-8',newline='\n')
def save(name,data):write(name,json.dumps(data,ensure_ascii=False,indent=2)+'\n')

stage=load(format_lab/'quiet/config.json')
images=load(format_lab/'frozen-identity.json')['images']['candidate']
image=format_lab/'frozen/candidate'
assert len(images)==32 and {name:sha(image/name) for name in images}==images
assert images==stage['identity']['imageFiles']['candidate']
catalog_path=lab/'catalog.json'
catalog=load(lab.parent/'annotation-and-forwarding-cpython-r590/representative.json')
catalog['cases']=[case for case in catalog['cases'] if case['id'] in ('scripts.rule-default-closures','scripts.annotated-rule-closures')]
assert len(catalog['cases'])==2
save(catalog_path.name,catalog)
root='/home/lokad/lython-bench-checks/current-rule-costs-b1027-20261119'
unit='lython-b1027-current-rule-costs-20261119'
labels=['rules','annotated']
jobs=[(label,case,'warm') for label,case in zip(labels,('scripts.rule-default-closures','scripts.annotated-rule-closures'))]
assert {case for label,case,lane in jobs}=={case['id'] for case in catalog['cases']}
identity=dict(sourceRevision='b8532e0ef',purpose='Post-definition-completion rule cost attribution',
    coreSHA256=dict(candidate=images['Lokad.Lython.dll']),imageFiles=dict(candidate=images),
    catalogSHA256=sha(catalog_path),diagnosticOnly=True,publicationHeld=True)
save('identity.json',identity)
prev=load(old/'config.json')
body=read(old/'ops-profile.py').replace(prev['root'],root)
body=body.replace("[('annotated', 'scripts.annotated-rule-closures', 'warm')]",repr(jobs))
body=body.replace('total_capture_seconds > 12','total_capture_seconds > 20').replace(
    'Initial capture window exceeded','Combined two-profile capture window exceeded')
write('ops-profile.py',body)
collect=read(old/'collect.py').replace(prev['root'],root).replace("['annotated']",repr(labels)).replace('len(records)==1','len(records)==2')
collect=re.sub(r"source='R592[^']+'",f"source='R600/B1027 b8532e0ef/{images['Lokad.Lython.dll'][:8]} rule closure attribution'",collect,count=1)
write('collect.py',collect)
write('run.sh',read(old/'run.sh').replace(prev['root'],root))
launch=read(old/'launch.py').replace('Annotated runtime CPU confirmation','Current rule closure attribution').replace('seconds=32','seconds=58').replace('before 32 seconds','before 58 seconds')
write('launch.py',launch)
write('retrieve.py',read(old/'retrieve.py'))
analysis=read(old/'analyze.py').replace("['annotated']",repr(labels))
analysis=analysis.replace("'ExecutePreparedDefinitionOperationAsync'", "'ExecutePreparedDefinitionOperation'")
analysis=analysis.replace("'CreateExecutableFunctionAsync'","'CreateExecutableFunction'")
write('analyze.py',analysis)
names=['identity.json','catalog.json','ops-profile.py','collect.py','run.sh']
payload=lab/'payload.tgz'
with tarfile.open(payload,'w:gz') as stream:
    for name in names:stream.add(lab/name,arcname=name)
config=dict(root=root,unit=unit,source=stage['root'],sourceFiles=images,
    sourceCatalogSHA256=stage['catalogSHA256'],catalogSHA256=sha(catalog_path),identity=identity,
    retireGroups=[],payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),unpackedBytes=sum((lab/n).stat().st_size for n in names))
save('config.json',config)
launcher=read(old/'remote-launch.py')
a,b=launcher.index('\nc=')+1,launcher.index('\nb=Path(')
write('remote-launch.py',re.sub(r'lython-b[0-9]+(?:-annotated)?-fixtures','lython-b1027-fixtures',
    launcher[:a]+'c='+repr(config)+launcher[b:]))

sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),
    PATH=str(sdk)+os.pathsep+os.environ['PATH'])
with (lab/'verify.log').open('wb') as log:
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',catalog_path,
      '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',Path.cwd()/'benchmarks/cpython-worker.py',
      '--out',lab/'verify.json'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=95,check=True)
verified=load(lab/'verify.json')
assert verified['state']=='Completed' and verified['catalogSha256']==sha(catalog_path)
assert {name:sha(image/name) for name in images}==images
print('Current retained image verified with both exact rule scripts and their CPython goldens.')
