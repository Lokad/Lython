# Lokad.Lython 0.11.0

Updated 2026-11-09 (Paris). Git-ignored: never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Current contracts belong in docs; original/adverse conditions and prototypes live
in [experimental history](benchmarks/EXPERIMENTS.md) and immutable linked results.

## Actual delivery status

- **R125 committed, delivery qualification active:**3109c871/core004e; text-reader retirement waits for the
  actual copy/decoder/append borrower and pending host operations. Qualified-source
  regressions demonstrated a342B premature refund, including the72B raw source.
  228internal/140public focused Release checks pass peractual11/10;16new lifetime
  cases cover cancellation, first refusal and nonblocking awaited disposal. B485
  controlled3jobs86.526s/allgates/archive/localpass: async text adverse does not
  reproduce; sync text variable, no CPU gain claim. CI42536319061 dispatched at
  23:40:47UTC for full Windows/Ubuntu actual11/10, stress both and installed core.
  Do not observe before23:45:47UTC. Prior terminal results remain cached.
- **Fully qualified production:** R119 d05/core19b8; R120/R121 runtime6f76/corec617
  plus typed fixture correction d97. Cached CI42527042378success22:19:56UTC verifies
  Windows/Ubuntu full Release actual.NET11/.NET10, original stress on both targets,
  and installed-core consumers. Earlier CI42519822299/d05 and42512127664/b1 also
  cached success. Never requery terminal runs or repeat unchanged qualification.
- **Completed earlier work preserved:** shared compiler-fact correction,
  direct UTF8 formatting/storage, native helper returns, native JSON construction,
  record capacity/adoption, primitive result-shape facts/accounting, flat lookup
  storage and function-execution-owned field facts. No new engine/owner/options.
  Function lookup capacity conservatively survives until execution cleanup;
  admission reentrancy, actual suspension, refusal and retained aliases are covered.
- **Current external baseline:** [BENCHMARKS](docs/BENCHMARKS.md), R122/B481,
  measured6f76/corec617 versus CPython3.13.16. Fifteen jobs311.685s, all source,
  golden, quiet, ownership, cleanup, archive and local-verification gates pass.
  Compile-to-result: validatedCSV1.17x, CSV1.01–1.03xvariable, text1.52–1.53x,
  JSON0.91–0.96xvariable, report1.32–1.33x. Warm/compile separate; mediated RAM-file
  I/O, full validation and prior-result cleanup included. Startup, pending I/O,
  RSS and embedding tails unmeasured. Config/search/manifest remain historical726.
- **R124 prototype HELD, not promoted:** compile-owned named-argument slots/shared
  defaults, currentC4bb. Correctness81internal/41public peractual11/10 plus262public11
  pass; warm allocation neutral, compile allocation+0.20–0.25%. B483114.346s and
  B484109.217s verified; mainCSV candidate spread4.33% prevents a stable CPU claim.
  Original async text adverse remains; confirmation improves it, not consistently
  reproducing the adverse. Narrow registry/mapping/guard adds mechanisms while
  general binding remains necessary. No automatic percentage veto or permanent
  rejection: full source/binaries/data preserved for a broader redesign. Production
  restored to qualified source with forced fresh builds. Useful named/default/
  suspension/cancellation/refusal/alias regressions retained; targeted5internal/
  6public cases pass on each target after restoration. R125 is the separate active correctness migration.

**Separate claims/debts:** native-return allocation−19.92/−19.31%, original elapsed
only diagnostic; formatting allocation−8.67%, controlledB102 elapsed/CPU−5–8%,
original adverse15.125ms unexplained/preserved. R110 wide allocation−8.56–8.58%.
R119 complete CSV/JSON~5–10% elapsed/custom~3–6%, supporting CPU; text inconclusive,
report CPU+1.53–6.25%possible debt. R120 custom allocation−1.71%, no CPU claim.
R121 confirmation report−6.09–6.66%, validatedCSV−3.30–5.45%/supportingCPU, inline
control±0.60%; async float variable. Combined earlier source pair's possible
async-float+1–2%debt remains. Independent source pairs are not additive and do not
silently settle older custom/config/report debts. Initial failed fixtures, widened
frames, report-cache inflation and inventory/collection mistakes remain in history.

## Prioritized roadmap

0. **Close R125 read-lifetime delivery before representation changes.** Remove
   immediate raw/decoded/file retirement while a read owns that storage. Requested
   cleanup completes after the active operation unwinds; asynchronous disposal is
   awaited without parking the caller. Buffered copying may finish; another refill
   cannot start. Reentrant reads fail explicitly. No ledger, tracing, refcount,
   background work, allowance or policy. Preserve Python output/cursor/codec/newline
   behavior, independent retained strings, first refusal and failure precedence.
   Focused callback-copy/append/decode, pending reads/close, cancellation/refusal,
   funding and reuse tests pass. Both desktop rounds/adverse samples preserved. B485 short quiet confirmation
   passes: sync text−1.19..+2.62%variable, async text−2.78..−0.22%, report−1.01..+0.89%;
   CPU coarse/variable, no speed claim. Batch platform/stress/installed-core checks.

1. **Complete call/frame/operand design, not another isolated binding bypass.**
   R126 selected source gate: reassess the five explicit NoInlining boundaries
   on input/comparison/result/formatted/store helpers whose stated purpose is CLR
   temporary liveness. Cooperative batch ownership does not reclaim allowance by
   tracing CLR roots; logical retirement is independent of collection. Hypothesis:
   remove this obsolete scheduling/liveness policy and let the existing executable
   engine/JIT optimize its canonical handlers, preserving funded slots/continuations
   and explicit retirement. This challenges the earlier "fence stays" assumption;
   it is not established safe or faster yet. Do not remove thread/stack/admission
   or recursive-empty-storage boundaries. Existing text samples attribute substantial
   useful work to these handlers, not a predicted removable percentage.
   Expected deletion: five attributes and GC-only dispatch comments/imports; no new
   engine, owner, carrier, option or alternate route. Public ownership/refusal/
   cancellation/cleanup and completed-result/context tests are hard gates. Immediate
   physical collection after guest reference withdrawal inside an active batch is
   not an accounting guarantee; document any resulting contract distinction before
   retention and preserve independent regression assertions. Stop/refine if an
   actual pending-user/alias/managed-stack invariant depends on a boundary.
   Validate helper/CSV/text/JSON/report semantics, real suspension and both targets;
   one bounded whole-script allocation/elapsed/control diagnostic after correctness.
   Preserve adverse evidence and defer full qualification to coherent retention.
   This policy simplification alone does not close the whole-script objective.

   Hypothesis: shared compiler facts and canonical executable invocation can remove
   complete repeated call preparation/operand classification transitions. R123 current
   complete helper/inline evidence~5.1vs3.3ms includes real calls/tuple work, not pure
   overhead. Binding/workspace4.97%leaf, preparation4.14%, context0; inclusive frame
   samples include useful execution. Current13instruction helper borrows bound locals;
   no missing local array/context allocation exists. Exact tuple unpack already
   borrows immutable items; tuple creation transfers its final array.

   Source gate about20min: identify a COMPLETE removable construction/dispatch phase,
   affected validatedCSV/report/JSON/text helper scripts and displaced code before
   selecting a redesign. Preserve measured native return allocation benefits, direct
   operands, managed stack admission, defaults/closures/recursion/evaluation order,
   actual callback suspension, cleanup and funded pending/retained aliases. Do not
   revive slower R71 arena/control/carriers or add another evaluator/owner/dispatcher.
   R124 positions may participate in broader fact consolidation; do not replay its
   unchanged narrow form just to chase timing. A temporary setback needs an explicit
   implementation-completion milestone and regression-debt decision before delivery.

   Acceptance: existing semantic/current-token cancellation/refusal/ownership tests,
   primary complete scripts and unchanged native controls; compile/warm/allocation/CPU
   separate. One bounded before/after on the quiet VM after source/correctness gates;
   confirmation/refinement allowed for specific evidence, not automatic thresholds.

   Current source correction: ordinary executable calls already use the linear
   BeginPendingCall/BeginBoundCall/caller-return runner. Do not propose a new VM
   call stack or another carrier to replace an imagined nested interpreter route.
   Borrowed prefixes promote only when context is actually required. Parameter
   layouts and ordinary presence bits are already shared/inline. Generic variadic
   binding still stages extras in PyList/CLR dictionary, but the measured primary
   helper does not use those signatures: no dominant-cost claim or prototype yet.

2. **Bulk record/text/frontend simplification as an independent track.**
   - Per-record construction: revisit actual current intermediates, preserve order,
     duplicate keys, rest fields, hooks and retained rows. Original bulkCSV6–8% was
     reassessed with its adverse control; current CSV already adopts arrays and JSON
     constructs direct/shared-layout values. Copying premise is gone; no automatic
     promotion or permanent ban. R118 get/add/store would duplicate CFG/proofs and
     canonical code; no prototype selected. Any new design must displace real work.
   - Remaining text conversions: inline/native UTF8, casing-split, final-buffer
     formatting and cached hashes are delivered. Input windows already borrow raw
     bytes; returned copies protect refill immutability. A string-view representation
     needs explicit retained-lifetime/identity tradeoffs and a completion milestone.
     Select actual conversion/storage from existing CPU evidence, not assumed copies.
     Existing b1/core93e9 text CPU capture remains named-source evidence, not current
     HEAD:18.79%prefix,8.36%casing/split,4.31%monitor,0leafbinding/context. Its exact
     PC/lifetime analysis already rejects imagined hash walks, repeated proofs,
     per-fragment budget resizes and dead input fences. Reuse that evidence; no
     new capture/credit policy solely to revisit an unchanged premise. R125/B485
     checks the changed input lifetime; it is not a fresh full CPU attribution.
   - Frontend: compilation is a product boundary. Reuse immutable binding/scope facts
     and retain only live representations. ScopeDirectiveFacts already memoizes facts
     on syntax; LexicalScopePreparation publishes them before lowering. The apparent
     repeated ForFunction calls do not imply duplicate walks: inspected, no prototype
     or new measurement. A new analysis consolidation needs exact current callers,
     compile-to-result workloads and storage/work deleted; no new parser/framework.

   For each selected milestone record hypothesis, expected code/storage removal,
   representative scripts, Python/ownership/cancellation acceptance and bounded
   controls BEFORE implementation. Source gate about20min; if no coherent phase is
   demonstrated, record uncertainty and pursue independent work. No open-ended audit
   or measurement campaign. Scoped scalar/dispatch changes need dominant-cost evidence;
   boxing/inclusive samples alone do not justify universal tagged slots, JIT or VM
   stack replacement. This objective remains open after individual experiments.

3. **Independent regex contract/implementation and final adapter qualification.**
   Core owns Python/native UTF8 names, byte captures/scalar positions/original windows,
   effective flags/errors/replacements, one frontend/runtime/import provider, current
   tokens and explicit existing ownership. Development producers/adapter-local bridges
   are allowed; core has no Utf8Regex dependency and must not wait for publication.
   Optional adapter nonpackable, ordinary selected pin0.4. Dev55/d6067925 focused
   86internal/514public peractual11/10 already passed: no unchanged replay or sibling
   edits/builds. Final selected-package qualification needs DetailedData with separate
   preparation/working owners, native-name enumeration and cursor creation without
   retaining an earlier token. Track these precise capabilities, not a blanket block.
   Separate contract forwarding/unwind, Python semantics and actual backend speed.

## Iteration and containment

Bounded confirmation, source refinement and measurement correction are allowed
when evidence justifies them. Timeout, unstable unchanged controls or inconclusive
measurements establish uncertainty, not failed designs or permanent closure.
Percentages inform decisions, not automatic vetoes. Preserve original adverse/source/
control conditions. Architectural simplification, allocation reduction and measured
CPU improvement are distinct. Batch full platform/stress/installed-package checks
at retained coherent delivery boundaries; focused Release regressions during work.

AGENTS.md governs fully managed memory safety/stack admission, host mediation,
cooperative current-token cancellation, shared coarse admission/preflights/replacement
overlap, funded aliases/results/caches/pending users and awaited cleanup. Refusal is
terminal. No unsafe/Unsafe/native probes, tracing/weak reclaim/forcedGC, independent
caps/fuel/quotas, hidden allowance, silent regex fallback or abandoned work. No local
build/test/measurement overlap; force nonincremental builds after source restoration.
Explicit UTF8. Only core Release pack to artifacts/nuget; no publication.

VM lokad@20.166.121.73, key~/.ssh/id_lython-bench.pem. Persistent workers/catalog/raw
separate from owned RAM fixtures; join/verify/unmount/archive under lease and verify
locally. All collections throughB485 terminal/cached/locally verified; no VM users or
fixtures, never requery. Cached terminal CI never queried again; observations of any
new active run at least5min apart. Space recovery only fresh idle exact-byte links,
permitted canonical ownership/writable parents/all-inode-alias/SHA proof and persisted
plan before mutation. Preserve every historical path/byte/archive. Original failed
conditions/corrections remain linked in history. Publication stays postponed.
