from pathlib import Path
import json,shutil,tarfile
r=Path(__file__).parent;dest=Path('benchmarks/results/2026-11-09-dispatch-liveness');dest.mkdir(exist_ok=True)
for name in ['identity.json','assessment-local.json']:shutil.copyfile(r/name,dest/name)
validation=dict(actualFrameworks=['net11.0','net10.0'],eachTarget=dict(internalLifetimeOwnership=189,publicSemanticsProtocols=229,internalStack=21,publicStackAndCycles=60),probes='Explicit matching Release builds/current core',testsRemoved=0,assertionsRelaxed=0,fullDelivery='Pending coherent checkpoint; R125 CI qualifies3109only',performance='Allocation neutral within0.064%; desktop elapsed diagnostic, adverse syncJSON retained; quiet comparison pending',decision='Retain development policy deletion; no CPU-gain claim or release qualification')
(dest/'focused-validation.json').write_text(json.dumps(validation,indent=2)+'\n',encoding='utf8')
with tarfile.open(dest/'source-and-diagnostics.tar.xz','w:xz')as a:
 for p in sorted(r.iterdir()):
  if p.is_file()and p.suffix in ['.py','.log','.json','.md','.patch']:a.add(p,arcname=p.name)
 for name in ['warm-sync','warm-async']:a.add(r/name,arcname=name)
 a.add(r/'images-verified/candidate/Lokad.Lython.dll',arcname='candidate-core85e.dll')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf8')
s+='\n\n## Dispatch CLR-liveness policy removal (2026-11-09 Paris)\n\n[R126](results/2026-11-09-dispatch-liveness/README.md), committedR125/core004e\nversusworking85e: five forcedNoInlining attributes/comments/imports removed,17lines,\nsame canonical algorithms/operand owners/retirement. Thread/stack/empty-recursion\nboundaries remain.189internal/229public +21internalStack/60publicStack eachactual\n11/10 pass, matching probes built; no test/assertion/timeout changes. Allocation\nneutral within0.064%, full goldens/balances/isolation/cleanup pass. Desktop sync\ntext−5.51..−6.04%/report−7.93..−8.96%, but JSON+5.69..+8.16%adverse survives;\nasync controls drift17.54%. No CPU-gain or universal-neutrality claim. Retain\ndevelopment simplification with explicit JSON debt; one bounded quiet confirmation\nof text/report/adverseJSON next, no unchanged desktop replay. Full coherent\nplatform/stress/package qualification pending; R125CI3109 is separate. Existing\nlinear runner/shared layouts/inline presence/borrowed locals/tuple/adopted CSV\ncorrect source assumptions; no imagined duplicate phase or new VM. Publication\npostponed; complete-script objective remains open.\n'
p.write_text(s,encoding='utf8')
p=Path('PLAN.md');s=p.read_text(encoding='utf8')
s=s.replace('R126 selected source gate:', 'R126 retained development deletion (not fully qualified):')
s=s.replace('it is not established safe or faster yet.', 'focused checks pass; CPU effects remain uncertain.')
s=s.replace('Expected deletion: five attributes', 'Deleted: five attributes')
s=s.replace('This policy simplification alone does not close the whole-script objective.', '189internal/229public plus21internalStack/60publicStack pass eachactual11/10;\n   no tests/assertions changed. Allocation neutral within0.064%; sync text/report\n   diagnostic improvements, sync JSON+5.69..+8.16%adverse, async controls drift17.54%.\n   No CPU claim. Debt decision: retain mechanism deletion during development; next\n   bounded quiet comparison isolates text/report/adverseJSON before final qualification.\n   No unchanged desktop replay. Broader whole-script objective remains open.')
s=s.replace('Do not observe before23:45:47UTC.', 'Second observation23:51:20UTC:11passedboth,10inprogress; next>=23:56:20UTC.')
p.write_text(s,encoding='utf8')
print('R126 evidence archived; development retention, performance/full-delivery pending')
