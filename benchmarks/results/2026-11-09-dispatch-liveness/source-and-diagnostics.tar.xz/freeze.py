from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).parent;prior=r.parent/'text-read-lifetime-r125'
images=r/'images-verified';assert not images.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cores=[Path(p)/'bin/Release/net11.0/Lokad.Lython.dll'for p in ['src/Lokad.Lython','tests/Lokad.Lython.Tests','tests/Lokad.Lython.PublicApi.Tests','tools/LythonProbe']]
assert len({sha(p)for p in cores})==1
for role in ['before','candidate']:shutil.copytree(prior/'refined/images-verified/candidate',images/role)
assert sha(images/'before/Lokad.Lython.dll')=='004e844658a33543dbc73572181f4a74524182c91557804cd9d5357599c90b12'
shutil.copyfile(cores[0],images/'candidate/Lokad.Lython.dll')
for name in ['catalog.json','measure.py']:shutil.copyfile(prior/name,r/name)
s=(prior/'assess-local.py').read_text(encoding='utf8');start=s.index("out['limitations']=");end=s.index("\n(r/'assessment-local",start)
s=s[:start]+"out['limitations']='R126 removal of five forced CLR-liveness NoInlining policies. Committed R125/core004e reference, same worker/optional0.4. Five unchanged complete scripts, both APIs, public Run/awaitedRunAsync/fullgoldens/budgetbalances/cleanup. Compilation excluded. SharedALCs/CoreLib/processGC/desktop controls; elapsed diagnostic only. No CPU-gain claim or full candidate delivery qualification.'"+s[end:]
(r/'assess-local.py').write_text(s,encoding='utf8')
changed=subprocess.check_output(['git','diff','--name-only','--','src'],text=True).splitlines();assert len(changed)==5
i=dict(baselineCommit='3109c871',baselineQualification='CI42536319061 active,11passedbothplatforms;10/stress/packagepending23:51UTC',candidate='R126 five dispatch helper liveness policies removed, same algorithms/ownership/public API',coreSHA256={role:sha(images/role/'Lokad.Lython.dll')for role in ['before','candidate']},changedSourceHashes={p:sha(Path(p))for p in changed},unchangedSourceBase='All other tracked production paths match3109c871',qualification='189internal/229public peractual11/10; separate focused managed stack/probe checks')
(r/'identity.json').write_text(json.dumps(i,indent=2)+'\n',encoding='utf8')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src']))
print(i['coreSHA256'])
