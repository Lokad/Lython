# Lokad.Lython 0.11.0

Updated 2026-11-09 (Paris). Git-ignored: never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Current contracts live in docs; historical conditions, failed/adverse results and
prototypes remain in [experimental history](benchmarks/EXPERIMENTS.md) and linked
immutable results. Completing an experiment does not complete this objective.

## Actual delivery status

- **Fully qualified reference:** R119 d05; R120/R121 runtime 6f76/core C617 with
  typed-fixture correction d97. Cached CI 42527042378 success, observed Nov8
  22:19:56 UTC: Windows/Ubuntu full Release actual .NET11/10, original stress
  both targets and installed-core consumers. Do not repeat unchanged qualification.
- **R125 committed, delivery active:** 3109c871/core004e. Requested text-reader
  cleanup waits for copy/decoder/append borrows, pending reads and awaited disposal.
  Qualified-reference regressions demonstrated premature342B refund including72B
  raw input.228 internal/140 public focused cases peractual11/10,16 new cases pass.
  B485 three jobs86.526s, all source/golden/quiet/ownership/cleanup/archive gates pass;
  no CPU gain claim. CI42536319061 at23:56:39 UTC: both platforms passed Release11,
  Release10 and installed-core consumers; original stress running. Next observation
  no earlier than Nov9 00:01:40 UTC. Named-source status remains separate from HEAD.
- **R126 committed development change, not fully qualified:** 9f2e1f51/core85e.
  Five forced CLR-liveness NoInlining attributes/comments/imports removed:17 lines,
  same algorithms/owners/retirement.189 internal/229 public plus21 internal stack/
  60 public stack cases pass peractual11/10; matching probes rebuilt. Existing
  GC/lifetime tests unchanged. Allocation neutral within0.064%; no CPU gain claim.
  Desktop sync text/report improve diagnostically, JSON+5.69..+8.16% adverse;
  async controls drift17.54%. Retain development simplification with explicit debt;
  bounded quiet confirmation and full coherent delivery remain pending.
- **R124 held, not promoted:** compiler-owned named slots/shared defaults; extra
  registry/mapping/guard left general binding necessary. Warm allocation neutral,
  compile allocation+0.20–0.25%; B483/B484 no stable whole-script CPU gain, primary
  CSV candidate spread4.33%. Correctness/source/binaries/original adverse evidence
  preserved. Production restored with fresh builds; useful named/default/suspended/
  cancellation/refusal/alias tests retained. No permanent rejection or percentage veto.
- **Earlier completed work preserved:** shared compiler-fact correction, direct
  UTF-8 formatting/storage, native helper returns, native JSON construction, record
  capacity/adoption, primitive result facts, flat lookup storage and execution-owned
  function field facts. Native-return allocation−19.92/−19.31% is established;
  original elapsed improvements diagnostic. Delivered code qualified, no replay.

**Separate measurements/debts:** formatting allocation−8.67% established;
controlled B102 elapsed/CPU−5–8% supports retention, original adverse15.125ms remains
unexplained/preserved. R110 wide allocation−8.56–8.58%. R119 CSV/JSON~5–10% elapsed,
custom~3–6%, supporting CPU; text inconclusive, report CPU+1.53–6.25% possible debt.
R120 custom allocation−1.71%, no CPU claim. R121 confirmation report−6.09–6.66%,
validated CSV−3.30–5.45%, supporting CPU; inline control±0.60%, async float variable.
Earlier combined async-float+1–2% possible debt remains. Source pairs are not
additive and do not silently settle older custom/config/report debts.

**CPython baseline:** [BENCHMARKS](docs/BENCHMARKS.md), R122/B481, measured6f76/C617
versus CPython3.13.16:15 jobs311.685s, all collection/archive gates pass. Compile-to-
result validated CSV1.17x, CSV1.01–1.03x variable, text1.52–1.53x, JSON0.91–0.96x
variable, report1.32–1.33x. Compilation/warm separate; mediated RAM-file I/O,
validation and prior-result cleanup included. Startup/pending I/O/RSS/embedding tails
unmeasured. Config/search/manifest remain historical726. Refresh after a substantial
coherent change; do not relabel historical measurements as current HEAD.

## Next deliverables: runtime/performance track

1. **Close R125 delivery and R126 measurement debt.** Cache the final R125 CI result;
   do not query completed runs again. R126 challenges the prior assumption that
   CLR-liveness fences must remain: explicit admitted slots/continuations/retirement
   own real users independently of physical collection. Thread/managed-stack and
   recursive-empty-storage boundaries remain. No public API or existing test/assertion
   changed. Bounded quiet comparison: complete text and report plus adverse JSON,
   independent reference/candidate controls, same worker/fixtures/normal GC/tiering.
   Separate allocation, elapsed and CPU; preserve original adverse desktop conditions.
   Prefer targeted refinement supported by evidence over a blanket policy. No further
   unchanged desktop replay without a specific measurement correction. Then batch
   platform/stress/installed-core qualification at a coherent retained boundary.

2. **Complete call/frame/operand simplification.** Hypothesis: consolidate canonical
   preparation/shared compiler facts to eliminate a COMPLETE repeated phase.
   R123 helper/inline~5.1/3.3ms includes useful calls/tuple work; binding/workspace
   4.97%leaf, preparation4.14%, tuple0.99%, context0. Inclusive frame work is not a
   removable tax. Existing BeginPendingCall/BeginBoundCall already uses a linear
   caller-return runner and lazy context promotion. Bound locals, tuple unpack and
   final tuple arrays already borrow/transfer; layouts are shared and ordinary
   presence bits inline. Do not recreate a VM stack, missing local array or context.
   Generic variadic staging exists but is absent from the measured primary helper;
   it is not demonstrated dominant work. R124 facts may serve broader consolidation.
   Source gate ~20min: name actual eliminated storage/work, displaced code and
   affected validated CSV/report/JSON/text helpers BEFORE implementation. Preserve
   native returns/direct operands, defaults/closures/recursion/order, real suspension
   and funded aliases. Do not revive slower R71 arenas/control/carriers or add an
   evaluator/owner/dispatcher. A justified temporary setback needs an explicit
   implementation-completion milestone and a remaining regression-debt decision.
   Acceptance: semantics/current cancellation/refusal/ownership; primary scripts and
   native controls, separate compile/warm/allocation/CPU, bounded quiet comparison.

3. **Independent bulk/text/frontend work.** Each selected redesign must name its
   hypothesis, complete work/storage eliminated, affected scripts, semantic acceptance,
   displaced implementation and bounded controls before coding. Source gate ~20min;
   if no real phase is demonstrated, record uncertainty and pursue independent work.
   - Bulk CSV6–8% was reconsidered with its adverse control. Current CSV adopts row
     arrays and bulk-admits final fields; JSON constructs direct/shared-layout values.
     The old copying premise is gone. Preserve duplicates/order/rest fields/hooks/
     retained rows. R118 get/add/store would duplicate CFG/proofs; no prototype.
   - Text: native/inline UTF-8, casing split, final-buffer formatting and cached hashes
     delivered. Raw windows already borrow input; independent output protects refill.
     R125 fixes actual pending-borrow funding first. R54/R60 views had width/accessor/
     control debt; a new representation needs retained-page/identity/completion proof.
     Existing b1/core93e9 text CPU/PC evidence is named-source evidence, not HEAD:
     18.79%prefix,8.36%casing/split,4.31%monitor,0leafbinding/context. Hash walks,
     repeated proofs and per-fragment budget resizes were not present. R126 reassesses
     only the liveness-policy premise, not all useful work in those samples.
   - Frontend: ScopeDirectiveFacts already memoizes syntax, LexicalScopePreparation
     publishes before lowering. Repeated ForFunction callers are not duplicate walks.
     Identify actual repeated analysis and compile-to-result costs before consolidation.
   No open-ended audit/capture campaign. Boxing/inclusive samples alone do not justify
   universal tagged slots, a JIT or VM-stack replacement. The whole-script objective
   remains active after individual deletions or experiments.

## Independent regex track

Core owns Python/native UTF-8 names, byte captures/scalar positions/original-subject
windows, effective flags/errors/replacements, one frontend/runtime/import provider,
current tokens and existing explicit ownership. Continue core development independently
of publication. Adapter-local bridges/pinned development producers are allowed outside
core. Optional adapter nonpackable, ordinary selected pin0.4. Dev55/d6067925 focused
86 internal/514 public peractual11/10 already passed; no unchanged replay or sibling
edits/builds. Final selected-package qualification needs DetailedData with distinct
preparation/working owners, native-name enumeration and cursor creation without an
earlier token. Only affected final adapter checks defer. Contract forwarding/unwind,
Python semantics and actual backend speed remain separate evidence.

## Iteration and containment

Bounded confirmation/refinement/measurement correction is allowed when justified.
Timeout, unstable controls or inconclusive observations establish uncertainty, not
failed designs or permanent closure. Size runs for usable quiet-VM observations;
percentages inform decisions, not automatic vetoes. Preserve original failed/adverse
conditions. Simplification, allocation reduction and CPU gains are distinct claims.
Focused Release checks during development; batch full delivery at meaningful boundaries.

AGENTS.md governs fully managed safety/stack admission, host mediation, current-token
cancellation, coarse shared admission/preflights/overlap, funded aliases/results/
caches/pending users and awaited cleanup. Refusal is terminal. No unsafe/Unsafe/native
probes, tracing/weak reclaim/forced GC, caps/fuel/quotas, hidden allowance, silent regex
fallback or abandoned work. No local build/test/measurement overlap. Fresh nonincremental
builds after restoration; explicit UTF-8. Only core Release packages to artifacts/nuget.

VM lokad@20.166.121.73, key ~/.ssh/id_lython-bench.pem. Persistent worker/catalog/raw
storage separate from owned RAM fixtures; join/verify/unmount/archive under lease,
verify locally. ThroughB485 terminal/cached/verified, no users/fixtures; never requery.
New active CI observations at least5min apart; cache terminal results. Space recovery
only fresh idle exact-byte links, permitted canonical ownership/writable parents,
all inode aliases/SHA proof and a persisted pre-mutation plan. Preserve every historical
path/byte/archive and original failed collection condition. Publication postponed.
