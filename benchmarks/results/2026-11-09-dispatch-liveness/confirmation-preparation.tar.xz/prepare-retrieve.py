from pathlib import Path
r=Path(__file__).parent
s=(r.parent/'text-read-lifetime-r125/retrieve-b485.py').read_text(encoding='utf8')
s=s.replace("r=Path(__file__).parent/'b485'","r=Path(__file__).parent/'b486'")
s=s.replace('text-read-lifetime-b485-20261108','dispatch-liveness-b486-20261109')
s=s.replace('lython-b485-read-lifetime-20261108','lython-b486-dispatch-liveness-20261109').replace('B485','B486')
compile(s,'retrieve-b486','exec')
(r/'retrieve-b486.py').write_text(s,encoding='utf8')
print('Prepared gated B486 retrieval; no observation yet')
