from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;b=r/'b486';b.mkdir()
old=r.parent/'text-read-lifetime-r125/b485';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
root='dispatch-liveness-b486-20261109';unit='lython-b486-dispatch-liveness-20261109'
base=json.loads((r/'identity.json').read_text(encoding='utf8'))
for p,h in base['changedSourceHashes'].items():assert sha(Path(p))==h
for name in ['collect.py','archive-owned.py','run.sh','launch-retry2.py']:
 s=(old/name).read_text(encoding='utf8')
 s=s.replace('text-read-lifetime-b485-20261108',root).replace('lython-b485-read-lifetime-20261108',unit)
 s=s.replace('text-read-lifetime-b485-launch-retry2.py','dispatch-liveness-b486-launch.py').replace('launch-retry2.log','launch.log')
 s=s.replace("reference=base/'function-lookups-b479-20261108/candidate'","reference=base/'text-read-lifetime-b485-20261108/candidate'")
 if name=='collect.py':
  at=s.index('jobs=');end=s.index('\nassert len(jobs)',at)
  s=s[:at]+"jobs=[['scripts.text-summary-helpers.large','warm'],['scripts.report-render.large','warm'],['scripts.json-summary-helpers.large','warm']]"+s[end:]
  at=s.index("purpose='R125");end=s.index("',\n",at)
  s=s[:at]+"purpose='R126 five forced CLR-liveness barriers removed. R125/core004e versus85e, same algorithms/ownership. Complete text/report/adverseJSON with independent controls. Preserve diagnostic JSON+5.69..8.16percent, no assumed speedup"+s[end:]
 (b/('launch.py'if name=='launch-retry2.py'else name)).write_text(s,encoding='utf8',newline='\n')
candidate=r/'images-verified/candidate/Lokad.Lython.dll';shutil.copyfile(candidate,b/'current-core.dll')
shutil.copyfile(r/'catalog.json',b/'representative.json')
i=dict(sourceRevision='9f2e1f51 runtime source, frozen workingcore85e',coreSHA256={role:base['coreSHA256']['before'if role.startswith('reference')else'candidate']for role in ['reference','reference-control','candidate','candidate-control']},auxiliaryFiles={p.name:sha(p)for p in (r/'images-verified/before').glob('*.dll')if p.name!='Lokad.Lython.dll'},catalogSHA256=sha(b/'representative.json'))
(b/'identity.json').write_text(json.dumps(i,indent=2)+'\n',encoding='utf8')
shutil.copyfile('PLAN.md',b/'pre-measurement-plan.md');shutil.copyfile(r/'source.patch',b/'source.patch')
for name,data in {
 'baseline-source.json':base,
 'setup-contract.json':dict(roles=4,jobs=3,ownerSeconds=180,stopSeconds=30,normalGcAndTiering=True,publication=False),
 'focused.json':dict(eachTarget=dict(internal=189,public=229,internalStack=21,publicStack=60),actualFrameworks=['net11.0','net10.0'],assertionsChanged=0),
 'sizing.json':dict(warmupSecondsPerRole=5,rounds=7,batchSeconds=.15,expectedSeconds=90,ownerSeconds=180,cleanupSeconds=30)
}.items():(b/name).write_text(json.dumps(data,indent=2)+'\n',encoding='utf8')
(b/'contract.md').write_text('R126 same canonical executable handlers, operand owners and awaited retirement, five forced liveness attributes removed. Retain first refusal/cancellation/aliases/managed stack; no new abstraction or public API. Complete text/report/adverseJSON, source004e versus85e, four independent processes, same auxiliary binaries/goldens/budgets/cleanup. Warm only, normalGC/tiering; compilation/startup/reset/protocol/finalcacheteardown excluded. Original adverse desktop data retained. Quiet gates, finite owner, join/RAMunmount/archive-under-lease/local verification required.\n',encoding='utf8')
space=json.loads((r/'aux-space-commit.json').read_text(encoding='utf8'))
for n,key in [('space-plan.json','plan'),('space-receipt.json','receipt')]:(b/n).write_text(json.dumps(space[key],indent=2)+'\n',encoding='utf8')
s=(b/'archive-owned.py').read_text(encoding='utf8').replace("'sizing.json']","'sizing.json','space-plan.json','space-receipt.json']")
assert "'space-plan.json'"in s;(b/'archive-owned.py').write_text(s,encoding='utf8',newline='\n')
names=['collect.py','archive-owned.py','run.sh','current-core.dll','identity.json','pre-measurement-plan.md','baseline-source.json','source.patch','setup-contract.json','focused.json','sizing.json','contract.md','space-plan.json','space-receipt.json']
with tarfile.open(b/'payload.tgz','w:gz')as a:
 for name in names:a.add(b/name,arcname=name)
for name in ['collect.py','archive-owned.py','launch.py']:compile((b/name).read_text(encoding='utf8'),name,'exec')
print('Prepared B486',sha(candidate),(b/'payload.tgz').stat().st_size)
