from pathlib import Path
import json,shlex,subprocess
r=Path(__file__).parent;probe=json.loads((r/'aux-space-probe.json').read_text(encoding='utf8'))
g=next(g for g in probe['groups']if g['name']=='Microsoft.CodeAnalysis.CSharp.dll')
canonical=next(i for i in g['usableInodes']if any('/text-read-lifetime-b485-20261108/candidate/'in p for p in i['paths']))
targets=sorted((i for i in g['usableInodes']if i['inode']!=canonical['inode']and len(i['paths'])==1),key=lambda i:i['paths'][0])[:2]
assert len(targets)==2
selection=dict(sha256=g['sha256'],canonical=canonical,targets=targets)
remote=r'''from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks');selection=SELECTION
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]ollector.dll|[p]erf record'],capture_output=True).returncode==1
 groups=[selection['canonical']]+selection['targets'];keys={(i['device'],i['inode']):i for i in groups}
 fresh={k:[]for k in keys}
 for p in base.rglob('Microsoft.CodeAnalysis.CSharp.dll'):
  st=p.lstat();key=(st.st_dev,st.st_ino)
  if key in fresh:fresh[key].append(str(p))
 for key,record in keys.items():
  assert sorted(fresh[key])==sorted(record['paths'])
  for path in record['paths']:
   p=Path(path);st=p.lstat()
   assert stat.S_ISREG(st.st_mode)and p.resolve()==p and base in p.parents
   assert st.st_uid==os.geteuid()and os.access(p.parent,os.W_OK)
   assert(st.st_dev,st.st_ino)==key and st.st_nlink==len(record['paths'])
  assert hashlib.sha256(Path(record['paths'][0]).read_bytes()).hexdigest()==selection['sha256']
 plan=base/'r126-b486-exact-aux-space-plan.json';assert not plan.exists()
 before=shutil.disk_usage(base).free
 plan.write_text(json.dumps(dict(beforeFreeBytes=before,selection=selection,allAliasesVerified=True,noUsers=True,mutation='Atomic replacement of two exact-byte singleton aliases with links to permitted canonical; preserve all historical paths/bytes'),indent=2)+'\n')
 source=next(Path(p)for p in selection['canonical']['paths']if '/text-read-lifetime-b485-20261108/candidate/'in p)
 for record in selection['targets']:
  target=Path(record['paths'][0]);temporary=target.with_name('.r126-b486-exact-aux-link')
  assert not temporary.exists();os.link(source,temporary)
  assert hashlib.sha256(temporary.read_bytes()).hexdigest()==selection['sha256']
  os.replace(temporary,target)
 for record in groups:
  for path in record['paths']:
   p=Path(path);assert p.stat().st_ino==source.stat().st_ino and p.stat().st_dev==source.stat().st_dev
 assert hashlib.sha256(source.read_bytes()).hexdigest()==selection['sha256']
 after=shutil.disk_usage(base).free
 receipt=dict(freeBefore=before,freeAfter=after,recoveredBytes=after-before,allOriginalPathsAndBytesPreserved=True,displacedInodes=2,allInodeAliasesVerified=True,preMutationPlan=str(plan),sha256=selection['sha256'])
 (base/'r126-b486-exact-aux-space-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps(dict(plan=json.loads(plan.read_text()),receipt=receipt)))
'''.replace('SELECTION',repr(selection))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -c '+shlex.quote(remote)],capture_output=True)
(r/'aux-space-commit.log').write_bytes(done.stdout+b'\n'+done.stderr)
assert done.returncode==0,done.stderr.decode()
d=json.loads(done.stdout);(r/'aux-space-commit.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf8');print(d['receipt'])
