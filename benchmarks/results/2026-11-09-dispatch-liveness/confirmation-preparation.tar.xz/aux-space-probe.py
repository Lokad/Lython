from pathlib import Path
import hashlib,json,shlex,subprocess
r=Path(__file__).parent
source=r/'images-verified/before'
expected={n:hashlib.sha256((source/n).read_bytes()).hexdigest()for n in ['Microsoft.CodeAnalysis.CSharp.dll','Microsoft.CodeAnalysis.dll']}
remote=r'''from pathlib import Path
import collections,fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks');expected=EXPECTED
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[c]ollector.dll|[p]erf record'],capture_output=True).returncode==1
 groups=[]
 for name,digest in expected.items():
  inodes=collections.defaultdict(list)
  for p in base.rglob(name):
   st=p.lstat()
   if not stat.S_ISREG(st.st_mode)or p.is_symlink():continue
   if hashlib.sha256(p.read_bytes()).hexdigest()!=digest:continue
   inodes[(st.st_dev,st.st_ino)].append(p)
  usable=[]
  for key,paths in inodes.items():
   st=paths[0].stat()
   if st.st_nlink!=len(paths)or any(p.stat().st_uid!=os.geteuid()or not os.access(p.parent,os.W_OK)for p in paths):continue
   usable.append(dict(device=key[0],inode=key[1],bytes=st.st_size,allocated=st.st_blocks*512,nlink=st.st_nlink,paths=[str(p)for p in paths]))
  groups.append(dict(name=name,sha256=digest,usableInodes=usable,potentialBytes=sum(i['allocated']for i in usable[1:]),otherInodes=len(inodes)-len(usable)))
 out=dict(freeBytes=shutil.disk_usage(base).free,groups=groups,noActiveUsers=True,readOnly=True)
 print(json.dumps(out))
'''.replace('EXPECTED',repr(expected))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
done=subprocess.run(ssh+['python3 -c '+shlex.quote(remote)],capture_output=True)
(r/'aux-space-probe.log').write_bytes(done.stdout+b'\n'+done.stderr)
assert done.returncode==0,done.stderr.decode()
d=json.loads(done.stdout);(r/'aux-space-probe.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf8')
print('free',d['freeBytes'],'potential exact bytes',[(g['name'],g['potentialBytes'],len(g['usableInodes']),g['otherInodes'])for g in d['groups']])
