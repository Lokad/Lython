from pathlib import Path
import hashlib, json, os, shutil, statistics, subprocess

lab=Path(__file__).resolve().parent
repo=Path.cwd()
previous=lab.parent/'trim-policy-scan-r634'
allocation=lab.parent/'prepared-compiler-bindings-r627/compile-allocation/bin/candidate'
trial=repo/'.git/agent-worktrees/combined-operand-preparation-r638'
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b).hexdigest()
write=lambda p,d:p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
git=lambda *args:subprocess.check_output(['git',*args])
ref=git('rev-parse','12fabffb1').decode().strip()
can=git('-C',str(trial),'rev-parse','HEAD').decode().strip()
manifest=load(previous/'frozen-identity.json')
assert not git('diff','--name-only',manifest['candidateCommit'],ref,'--','src')
assert not git('-C',str(trial),'status','--porcelain')
assert not git('diff','--name-only',ref,can,'--','benchmarks','src/Lokad.Lython.Utf8Regex')
(lab/'measured-source.patch').write_bytes(git('diff','--binary',ref,can,'--','src','tests'))
catalog_path=lab/'catalog.json'
original=lab.parent/'prepared-binding-diagnostics-r616/catalog.json'
catalog=load(original)
assert [v['id'] for v in catalog['cases']]==['scripts.config-manifest.small','scripts.config-generated-guards.medium',
    'scripts.config-edit.small','scripts.report-render.format-selectors.large']
shutil.copyfile(original,catalog_path)
assert sha(original.read_bytes())==sha(catalog_path.read_bytes())
python=Path('C:/Python313/python.exe')
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
source=previous/'frozen/candidate'
files=manifest['images']['candidate']
core='Lokad.Lython.dll'
assert len(files)==32 and {name:sha((source/name).read_bytes()) for name in files}==files
images={}
for role in ('reference','candidate'):
    image=lab/'frozen'/role
    image.mkdir(parents=True,exist_ok=True)
    expected=files.copy()
    for name in files:
        origin=source/name
        if role=='candidate' and name==core:
            origin=trial/'src/Lokad.Lython/bin/Release/net11.0'/name
            expected[name]=sha(origin.read_bytes())
        if not (image/name).exists():shutil.copyfile(origin,image/name)
    if role=='candidate':assert expected[core]!=files[core]
    assert {name:sha((image/name).read_bytes()) for name in files}==expected
    with (lab/(role+'-verify.log')).open('wb') as log:
        subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',catalog_path,
            '--dotnet',dotnet,'--python',python,'--python-worker',repo/'benchmarks/cpython-worker.py',
            '--out',lab/(role+'-verify.json')],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=120)
    verified=load(lab/(role+'-verify.json'))
    assert verified['state']=='Completed' and verified['catalogSha256']==sha(catalog_path.read_bytes())
    diagnostics=lab/'compile-allocation'/role
    diagnostics.mkdir(parents=True,exist_ok=True)
    for name in ('CompileAllocation.dll','CompileAllocation.deps.json','CompileAllocation.runtimeconfig.json'):
        shutil.copyfile(allocation/name,diagnostics/name)
    shutil.copyfile(image/core,diagnostics/core)
    with (lab/(role+'-allocation.json')).open('wb') as out, (lab/(role+'-allocation.log')).open('wb') as err:
        subprocess.run([dotnet,diagnostics/'CompileAllocation.dll',catalog_path],env=env,stdout=out,stderr=err,
            check=True,timeout=120)
    assert load(lab/(role+'-allocation.json'))['coreSha256']==expected[core]
    assert {name:sha((image/name).read_bytes()) for name in files}==expected
    images[role]=expected
write(lab/'frozen-identity.json',dict(referenceCommit=ref,candidateCommit=can,casesSHA256=sha(catalog_path.read_bytes()),images=images))
for left,right in zip(*[load(lab/(role+'-allocation.json'))['rows'] for role in ('reference','candidate')],strict=True):
    assert left['id']==right['id'] and left['characters']==right['characters']
    a,b=[statistics.median(row['bytes']) for row in (left,right)]
    print(left['id'],f'{a:,} to {b:,}',f'{100*(b/a-1):+.2f}%',flush=True)
print('Both 32-file images verified with four exact CPython goldens. All local compile owners refunded.')
