set -eu
export DOTNET_ROOT=/home/vermorel/.dotnet
export DOTNET_ROOT_X64=$DOTNET_ROOT
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/marked-cased-split-20261123
"$DOTNET_ROOT/dotnet" test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 --artifacts-path "$lab/combined-ubuntu" --filter 'FullyQualifiedName~Cased|FullyQualifiedName~TrimmedSplit|FullyQualifiedName~NativeWordBinding|FullyQualifiedName~RegexProviderContract|FullyQualifiedName~RegexFindAllList|FullyQualifiedName~RegexCaptureMaterialization'
