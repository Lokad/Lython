from pathlib import Path
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
donor = lab.with_name('module-failure-bindings-20261123')
prototype = lab.with_name('marked-cased-split-20261123')
external = lab.with_name('owned-class-cpython-20261123')
quiet = lab / 'comparison/quiet'
quiet.mkdir(parents=True, exist_ok=True)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo)


def adapt(source, target, pairs):
    code = source.read_text(encoding='utf-8')
    for before, after in pairs:
        assert code.count(before) == 1, (source, before)
        code = code.replace(before, after)
    compile(code, str(target), 'exec')
    target.write_text(code, encoding='utf-8', newline='\n')


revision = git('rev-parse', '43688c753').decode().strip()
assert not git('diff', '--name-only', revision, 'origin/master', '--', 'src', 'tests')
prior = read(donor / 'comparison/identity.json')
protocol = repo / 'benchmarks/cpython-worker.py'
assert sha(protocol.read_bytes()) == prior['cpythonWorkerSHA256']
reference = prior['imageFiles']['candidate']
local_image = lab / 'candidate'
local_image.mkdir(exist_ok=True)
assert len(reference) == 32
for name, expected in reference.items():
    source = donor / 'candidate' / name
    assert sha(source.read_bytes()) == expected
    if name == 'Lokad.Lython.dll':
        source = lab / 'frozen/bin/Lokad.Lython/release_net11.0' / name
    shutil.copyfile(source, local_image / name)
candidate = {name: sha((local_image / name).read_bytes()) for name in reference}
assert [name for name in reference if reference[name] != candidate[name]] == ['Lokad.Lython.dll']

catalog = read(prototype / 'comparison/representative.json')
_, short, mixed, _ = catalog['cases']
assert 'nonlocal-computed-width' in short['id'] and 'mixed-width' in mixed['id']
catalog['cases'] = [short, mixed]
write(quiet / 'representative.json', catalog)
write(quiet / 'jobs.json', [[short['id'], lane] for lane in ('warm', 'compile-run', 'compile')] + [[mixed['id'], 'warm']])
dotnet = Path.home() / '.dotnet11/dotnet.exe'
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent))
verified = quiet / 'candidate-verify.json'
subprocess.run([dotnet, local_image / 'Lokad.Lython.Benchmarks.dll', '--compare', 'verify', '--catalog',
                quiet / 'representative.json', '--dotnet', dotnet, '--python', 'C:/Python313/python.exe',
                '--python-worker', protocol, '--out', verified],
               env=env, check=True, timeout=70)
verification = read(verified)
assert verification['state'] == 'Completed' and verification['caseCount'] == 2
assert verification['launched']['library']['sha256'] == candidate['Lokad.Lython.dll']
assert all(sha((local_image / name).read_bytes()) == h for name, h in candidate.items())

run = 'combined-cased-split-cpython-b1539-20261123'
write(quiet / 'identity.json', dict(sourceRevision=revision, candidate=revision,
    frozenImage='/home/lokad/lython-bench-checks/' + run + '/candidate',
    imageFiles=dict(reference=reference, candidate=candidate),
    auxiliaryFiles={name:h for name,h in candidate.items() if name != 'Lokad.Lython.dll'},
    coreSHA256={key:candidate['Lokad.Lython.dll'] for key in ('candidate', 'candidate-control')},
    cpythonWorkerSHA256=prior['cpythonWorkerSHA256'], expectedCPythonSHA256=prior['expectedCPythonSHA256'],
    catalogs={name:dict(sha256=sha((quiet / name).read_bytes())) for name in ('representative.json', 'jobs.json')}))
adapt(external / 'comparison/quiet/collect.py', quiet / 'collect.py', (
    ('len(jobs) == 3', 'len(jobs) == 4'),
    ('<175,', '<220,'),
    ('lython-b1534-fixtures', 'lython-b1539-fixtures'),
    ('CPython checkpoint for the retained quote-heavy invoice', 'CPython checkpoint after isolating native cased splits'),
))
adapt(external / 'comparison/quiet/summarize.py', quiet / 'summarize.py', (
    ('len(raw["jobs"])==3 and receipt["warmJobs"]==3', 'len(raw["jobs"])==4 and receipt["warmJobs"]==4'),
))
adapt(prototype / 'quiet.py', lab / 'quiet.py', (
    ('lython-b1538-marked-cased-split-20261123', 'lython-b1539-cased-split-cpython-20261123'),
    ('.+b1538-', '.+b1539-'),
    ('lython-b1538-stage-', 'lython-b1539-stage-'),
    ('A 14 MiB', 'A 13.5 MiB'),
    ('14 * 1024 * 1024', '27 * 512 * 1024'),
    ('RuntimeMaxSec=345', 'RuntimeMaxSec=260'),
    ('seconds=270', 'seconds=207'),
))
shutil.copyfile(external / 'comparison/quiet/run.sh', quiet / 'run.sh')
assert b'\r' not in (quiet / 'run.sh').read_bytes()
payload = quiet / 'payload.tar.gz'
with tarfile.open(payload, 'w:gz') as archive:
    for name in ('identity.json', 'representative.json', 'jobs.json', 'run.sh', 'collect.py'):
        archive.add(quiet / name, arcname=name)
    archive.add(local_image / 'Lokad.Lython.dll', arcname='candidate-core.dll')
write(quiet / 'upload.json', dict(root=run, reference='module-failure-bindings-b1536-20261123',
    payloadBytes=payload.stat().st_size, payloadSHA256=sha(payload.read_bytes())))

archive = 'benchmarks/results/2026-11-23-marked-cased-split/'
def tracked(name):
    return git('show', 'origin/master:' + archive + name)

receipt = json.loads(tracked('terminal-status.json'))['receipt']
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
assert sha(tracked('observations.tar.xz')) == receipt['archiveSHA256']
filename = 'candidate-core.dll.gz'
old = gzip.decompress(tracked(filename))
assert sha(old) == json.loads(tracked('identity.json'))['imageFiles']['candidate']['Lokad.Lython.dll']
write(lab / 'verified-replicas.json', [dict(path='marked-cased-split-b1538-20261123/candidate/Lokad.Lython.dll',
    sha256=sha(old), observationSHA256=receipt['archiveSHA256'], trackedArchive=archive + filename)])
