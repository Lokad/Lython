from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab / 'comparison/quiet'
dest = repo / 'benchmarks/results/2026-11-23-combined-cased-split-cpython'
focused = lab.with_name('marked-cased-split-20261123')


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def sha(data):
    return hashlib.sha256(data).hexdigest()


identity = read(quiet / 'identity.json')
status = read(quiet / 'terminal-status.json')
receipt = status['receipt']
assert not status['live'] and not status['fixtures'] and status['exitCode'] == '0'
assert all(receipt[key] for key in ('complete', 'archivedAndVerifiedUnderLease', 'allWorkersJoined',
                                   'guestFixturesRemoved', 'quietBeforeAndAfter'))
assert sha((quiet / 'observations.tar.xz').read_bytes()) == receipt['archiveSHA256']
assert read(quiet / 'summary.json')['timedBatches'] == 112
assert not subprocess.check_output(['git', 'diff', '--name-only', identity['sourceRevision'],
                                    'origin/master', '--', 'src', 'tests'], cwd=repo)
files = identity['imageFiles']['candidate']
image = lab / 'candidate'
assert len(files) == 32 and all(sha((image / name).read_bytes()) == h for name, h in files.items())
dest.mkdir(exist_ok=True)
assert all(path.name == 'README.md' for path in dest.iterdir())
(dest / 'candidate-core.dll.gz').write_bytes(gzip.compress((image / 'Lokad.Lython.dll').read_bytes(), mtime=0))
for name in ('observations.tar.xz', 'identity.json', 'summary.json', 'terminal-status.json'):
    shutil.copyfile(quiet / name, dest / name)
with tarfile.open(dest / 'procedures.tar.xz', 'w:xz') as bundle:
    for name in ('archive.py', 'prepare.py', 'quiet.py', 'windows-build.log', 'verified-replicas.json',
                 'comparison/quiet/launch.log', 'comparison/quiet/observe-not-before',
                 'comparison/quiet/candidate-verify.json', 'comparison/quiet/summarize.py'):
        bundle.add(lab / name, arcname=name)
    for name in ('combined-windows.log', 'combined-ubuntu.log', 'combined-ubuntu.sh'):
        bundle.add(focused / name, arcname=name)
print(dest)
