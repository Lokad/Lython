set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/pinned-unicode-casing-20261121
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/shared-function-binding-facts-on-current
white='Category!=Stress&(FullyQualifiedName~SimpleFunctionExecutionBoundary|FullyQualifiedName~ExecutableFunctionInvocationBoundary|FullyQualifiedName~ExecutableAsyncIteratorCleanup|FullyQualifiedName~NativeFunctionRefund|FullyQualifiedName~BoundMethodInvocationBoundary|FullyQualifiedName~FunctionDefaultConstruction|FullyQualifiedName~ManagedStackGuard|FullyQualifiedName~CallArgumentEvaluation|FullyQualifiedName~TokenSourceCoordinates)'
public='Category!=Stress&(FullyQualifiedName~FunctionDefaultMetadata|FullyQualifiedName~FunctionAttributeAccountingScenario|FullyQualifiedName~PreparedCallArgument|FullyQualifiedName~FunctionValueAccountingScenario|FullyQualifiedName~GeneratorStorageSemantics|FullyQualifiedName~MatchGuardScope|FullyQualifiedName~MatchSubjectExpressionList|FullyQualifiedName~LoweredMatchBody|FullyQualifiedName~CallArgumentEvaluation|FullyQualifiedName~FunctionWrapper|FullyQualifiedName~Dataclass)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter "$white" | tee "$logs/white-ubuntu.log"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter "$public" | tee "$logs/public-ubuntu.log"
