from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile


lab = Path(__file__).resolve().parent
quiet = lab / "quiet"
out = Path("benchmarks/results/2026-11-21-compiled-call-metadata")


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


identity = load(lab / "identity.json")
for role, files in identity["imageFiles"].items():
    assert len(files) == 32 and {name: sha(lab / "frozen" / role / name) for name in files} == files
    verification = load(lab / f"{role}-verify.json")
    assert verification["state"] == "Completed" and verification["caseCount"] == 7
    assert verification["catalogSha256"] == identity["catalogSHA256"] == sha(lab / "representative.json")
    quiet_verification = load(lab / f"quiet-{role}-verify.json")
    assert quiet_verification["state"] == "Completed" and quiet_verification["caseCount"] == 4
    assert quiet_verification["catalogSha256"] == sha(lab / "quiet-catalog.json")
allocation = load(lab / "allocation-summary.json")
assert len(allocation) == 7 and all(row["budgetReturnedToBaseline"] for row in allocation)
for platform in ("win", "ubuntu"):
    for suite, count in (("white", 116), ("public", 388)):
        log = (lab / f"{suite}-{platform}.log").read_text(encoding="utf-8-sig")
        assert any(line.strip().startswith("Passed!") and f"Passed: {count:5d}, Skipped:" in line for line in log.splitlines())

receipt = load(quiet / "archive-receipt.json")
terminal = load(quiet / "terminal-status.json")
assert terminal["exitCode"] == "0" and terminal["receipt"] == receipt
assert not terminal["remainingTrace"] and not terminal["remainingWorkers"]
assert all(receipt[key] for key in ("complete", "allWorkersJoined", "guestFixturesRemoved",
                                   "archivedAndVerifiedUnderLease", "quietBeforeAndAfter"))
assert sha(quiet / "observations.tgz") == receipt["archiveSHA256"]
staged = load(quiet / "identity.json")
assert staged["imageFiles"] == identity["imageFiles"] and staged["catalogSHA256"] == sha(lab / "quiet-catalog.json")
raw = load(quiet / "retrieved/confirmation/confirmation.json")
assert raw["warmupSeconds"] == 8 and raw["targetBatchSeconds"] == .65 and raw["rounds"] == 7
cases = {case["id"]: case for case in load(lab / "quiet-catalog.json")["cases"]}
assert raw["complete"] and len(raw["jobs"]) == receipt["jobs"] == 5 and len(cases) == 4
assert [(job["case"], job["lane"]) for job in raw["jobs"]] == [
    ("scripts.annotated-rule-closures.nested-factories.postponed", "warm"),
    ("scripts.annotated-rule-closures.nested-factories.postponed", "compile-run"),
    ("scripts.annotated-rule-closures.nested-factories", "warm"),
    ("scripts.ordinary-fully-supplied-helper", "warm"),
    ("scripts.dataclass-keyword-configuration.generated", "compile"),
]
for job in raw["jobs"]:
    case = cases[job["case"]]
    assert job["workersJoinedAndFixturesRemoved"] and len(job["samples"]) == 28
    for sample in job["samples"]:
        response = sample["response"]
        assert response["completedInvocations"] > 0 and response["status"] == "Completed"
        assert response["sourceSha256"] == case["sourceSha256"] and response["fixtureSha256"] == case["fixtureSha256"]
        compilation = job["lane"] == "compile"
        assert response.get("actualOutputSha256") == (None if compilation else case["expectedOutputSha256"])
        assert response.get("actualFilesSha256") == (None if compilation else case.get("expectedFilesSha256"))

decision = load(lab / "decision.json")
summary = load(quiet / "quiet-summary.json")
del summary["retentionDecisionPending"]
summary.update(collection="B1284", reference=identity["reference"], referenceImageSource=identity["referenceImageSource"],
               candidate=identity["candidate"], verifiedTimedBatches=140, coreSHA256=staged["coreSHA256"],
               archiveSHA256=receipt["archiveSHA256"], retentionDecision=decision["decision"])
out.mkdir(exist_ok=True)
(out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8", newline="\n")
for name in ("README.md", "allocation-summary.json", "compile-allocation-summary.json"):
    shutil.copyfile(lab / name, out / name)
for name in ("archive-receipt.json", "terminal-status.json", "observations.tgz"):
    shutil.copyfile(quiet / name, out / name)
candidate = (lab / "frozen/candidate/Lokad.Lython.dll").read_bytes()
artifact = out / "candidate-core.dll.gz"
artifact.write_bytes(gzip.compress(candidate, mtime=0))
assert gzip.decompress(artifact.read_bytes()) == candidate
known_reference = Path("benchmarks/results/2026-11-21-direct-function-override-admission/candidate-core.dll.gz")
assert gzip.decompress(known_reference.read_bytes()) == (lab / "frozen/reference/Lokad.Lython.dll").read_bytes()
(lab / "measured-source.patch").write_bytes(subprocess.check_output(
    ["git", "diff", identity["reference"], identity["candidate"], "--", "src", "tests"]))
with tarfile.open(out / "checks-and-procedures.tar.xz", "w:xz", preset=6) as archive:
    for folder in (lab, quiet):
        for path in sorted(folder.iterdir()):
            if (path.is_file() and path.suffix not in {".dll", ".tgz"}
                    and path.name not in {"launch.py", "retrieve.py"}):
                archive.add(path, arcname=path.relative_to(lab).as_posix())
print("140 timed batches and both complete frozen worker images verified.")
