# B1284 compiled call metadata

The compiled code object holds the checked operand and pattern storage
extents. Each callable reads these extents directly. The parameter layout
owns the ordinary positional-binding eligibility flag. This removes two
per-callable flag fields, a nullable capacity field and duplicate
positional checks before borrowing operands.

Reference `47fc47d91` uses the exact production-equivalent image from
`a887d3e8a`. The candidate is `4dbd1b94c`. The collection ran November 21,
2026 UTC on the quiet Azure F4as_v7 with Ubuntu 24.04.4 and .NET 11 RC3.
Two processes per source warmed for at least eight seconds and
contributed seven rotated batches per lane. Ranges compare the four
pairings of process medians. Warm elapsed covers mediated RAM-backed
I/O, goldens and prior-result disposal. Compilation covers compilation
and code-owner disposal. Time to result includes both costs. Process
CPU covers the full request. Startup and final teardown are separate.

{{results}}

The local seven-script allocation diagnostic returns every execution
allowance to baseline. Accounted execution and compilation estimates
match. Compilation of the keyword dataclass fixture allocates 408 more
CLR bytes in the local diagnostic. The isolated source comparison,
before the first-write override change was integrated, shows factory
allocation reductions of 3.52–5.14%. The table uses the final source pair.

Both complete 32-file images reproduce seven local goldens and the
four goldens in the exact quiet catalog. Windows .NET 11 and Ubuntu
.NET 10 each pass 116 white-box and 388 public focused checks in the
measured revision. The focused cases cover positional binding, live
defaults, generators, pattern storage and retained wrapper metadata.

{{decision}}

All 140 timed batches passed. The workers joined, RAM fixtures were
removed and the persistent observations verified under the lease.

[Timing](summary.json) · [Execution allocation](allocation-summary.json)
· [Compilation allocation](compile-allocation-summary.json)
· [Raw observations](observations.tgz)
· [Source, checks and procedures](checks-and-procedures.tar.xz).
