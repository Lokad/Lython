from pathlib import Path
import json


lab = Path(__file__).resolve().parent
earlier = lab.parent / "shared-function-binding-facts"
defaults = lab.parent / "factory-call-stages"
catalog = json.loads((earlier / "representative.json").read_text(encoding="utf-8"))
controls = json.loads((defaults / "representative.json").read_text(encoding="utf-8"))
catalog["cases"].append(next(case for case in controls["cases"] if case["id"] == "scripts.ordinary-fully-supplied-helper"))
assert len(catalog["cases"]) == 7
(lab / "representative.json").write_text(json.dumps(catalog, indent=2) + "\n",
                                         encoding="utf-8", newline="\n")
source = (earlier / "freeze.py").read_text(encoding="utf-8-sig")
source = source.replace('donor = lab.parent / "regex-program-equality"',
                        'donor = lab.parent / "callable-standard-overrides-direct"')
source = source.replace('"2906249c5"', '"47fc47d91"').replace('result["caseCount"] == 6', 'result["caseCount"] == 7')
compile(source, str(lab / "freeze.py"), "exec")
(lab / "freeze.py").write_text(source, encoding="utf-8", newline="\n")
