from pathlib import Path
from statistics import median
import hashlib,json,re,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
out=repo/'benchmarks/results/2026-11-25-compiled-regex-subject'
out.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=read(lab/'identity.json')
assert sha(lab/'candidate.patch')==identity['sourcePatchSHA256']
assert sha(lab/'representative.json')==identity['catalogSHA256']
for folder,patch in [('src','candidate.patch'),('tests','tests.patch')]:
    assert subprocess.check_output(['git','diff','--binary','HEAD','--',folder],cwd=repo)==(lab/patch).read_bytes()
results,observations={},{}
for role,files in identity['imageFiles'].items():
    assert len(files)==32 and {p.name:sha(p)for p in (lab/role).iterdir()}==files
    verified=read(lab/(role+'-verify.json'))
    assert verified['state']=='Completed' and verified['caseCount']==7
    assert verified['catalogSha256']==identity['catalogSHA256']
    core=files['Lokad.Lython.dll']
    assert verified['launched']['library']['sha256']==core
    allocated=read(lab/(role+'-allocations.json'))
    trace=read(lab/(role+'-subject-trace.json'))
    assert allocated['coreSHA256']==trace['coreSHA256']==core
    assert len(allocated['rows'])==7 and len(trace['rows'])==4
    results[role]=allocated['rows']; observations[role]=trace['rows']
rows=[]
for before,after in zip(results['reference'],results['candidate'],strict=True):
    assert before['id']==after['id'] and before['retainedAdmission']==after['retainedAdmission']
    assert len(before['samples'])==len(after['samples'])==11
    rows.append(dict(case=before['id'],allocationBytes=[median(d['samples'])for d in (before,after)],
        retainedAdmission=before['retainedAdmission']))
assert [b-a for a,b in (row['allocationBytes'] for row in rows)]==[0,-608,-16496,-16496,0,0,0]
expected=[8,264,8202,8202]
for i,(previous,current) in enumerate(zip(observations['reference'],observations['candidate'],strict=True)):
    assert previous['id']==current['id'] and previous['id']==rows[i]['case']
    for obs in (previous,current):
        assert [o['Phase']for o in obs['Observations']]==['compile','compile','run']
        assert [o['Length']for o in obs['Observations']]==[expected[i]]*3
        assert len({str(o['Window'])for o in obs['Observations']})==1
    assert len({o['Backing']for o in previous['Observations']})==3
    assert len({o['Backing']for o in current['Observations']})==(3 if i==0 else 1)
for suite,n in [('Lokad.Lython.PublicApi.Tests',616),('Lokad.Lython.Tests',77)]:
    for platform in ('win11','ubuntu10'):
        assert re.search(rf'Failed:\s+0, Passed:\s+{n},',(lab/f'{suite}-{platform}.log').read_text(encoding='utf-8-sig'))
shutil.copyfile(lab/'identity.json',out/'identity.json')
(out/'allocation-summary.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
(out/'subject-trace.json').write_text(json.dumps(observations,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'procedures.tar.xz','w:xz') as bundle:
    for p in ('prepare.py','package-evidence.py','candidate.patch','tests.patch',
        'Program.cs','RouteProbe.csproj','measure-build.log','probe-build.log','prepare.log',
        'trace/Program.cs','trace/SubjectTrace.csproj','trace/build.log','representative.json',
        'reference-verify.json','candidate-verify.json','reference-allocations.json','candidate-allocations.json',
        'test-ubuntu.sh','Lokad.Lython.PublicApi.Tests-win11.log','Lokad.Lython.PublicApi.Tests-ubuntu10.log',
        'Lokad.Lython.Tests-win11.log','Lokad.Lython.Tests-ubuntu10.log'):
        bundle.add(lab/p,arcname=p,recursive=False)
print('Verified exact patches, seven goldens per image, equal admitted memory, 693 tests per platform and subject backing witnesses.')
