from pathlib import Path
import hashlib,json,os,shutil,subprocess
lab=Path(__file__).resolve().parent
repo=lab.parents[3]
b1738=lab.with_name('csv-combined-record-admission-20261125')
b1734=lab.with_name('regex-shared-literal-refined-20261125')
b1727=lab.with_name('formatted-report-cpython-20261125')
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
digest=lambda s:hashlib.sha256(s.encode('utf-8')).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=repo)
def save(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
head=git('rev-parse','HEAD').decode().strip()
assert head.startswith('d661e0d27')
ref=read(b1738/'comparison/quiet/identity.json')
assert git('diff','--binary',ref['sourceRevision'],head,'--','src')==(b1738/'candidate.patch').read_bytes()
base=ref['imageFiles']['candidate']
assert len(base)==32 and {p.name:sha(p)for p in (b1738/'candidate').iterdir()}==base
core=repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'
assert sha(core)==sha(repo/'tools/LythonProbe/bin/Release/net11.0/Lokad.Lython.dll')
patch=git('diff','--binary','HEAD','--','src')
assert patch.count(b'diff --git ')==5
(lab/'candidate.patch').write_bytes(patch)
(lab/'tests.patch').write_bytes(git('diff','--binary','HEAD','--','tests'))
images=dict(reference=base,candidate=base|{core.name:sha(core)})
for role,files in images.items():
    path=lab/role
    path.mkdir(exist_ok=True)
    for name in files:
        shutil.copyfile(core if role=='candidate' and name==core.name else b1738/'candidate'/name,path/name)
    assert {p.name:sha(p)for p in path.iterdir()}==files

cases=[]
for tail,matched in [(0,True),(128,True),(4097,True),(4097,False)]:
    text='😀x尾'+'ŵ'*tail
    if matched:
        source=f"import re\np=re.compile('x')\nm=p.match('{text}',1,2)\nprint(m.span(),m.group(),len(m.string))\n"
        result=f'(1, 2) x {len(text)}\n'
    else:
        source=f"import re\np=re.compile('q')\nm=p.search('{text}',1,2)\nprint(m)\n"
        result='None\n'
    fixture=json.dumps(dict(size=len(text),text=None),separators=(',',':'))
    cases.append(dict(id=f'diagnostic.regex-subject-{tail}-'+('match' if matched else 'miss'),
        family='diagnostic.regex-subject',category='regex',scale='small',size=len(text),source=source,
        fixtureJson=fixture,expectedOutput=result,sourceUtf8Bytes=len(source.encode('utf-8')),expectedOutputUtf8Bytes=len(result.encode('utf-8')),
        fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,sourceSha256=digest(source),fixtureSha256=digest(fixture),expectedOutputSha256=digest(result)))
catalog=read(b1734/'representative.json')
controls=('scripts.file-manifest.small','diagnostic.generated-ordinary-definitions','diagnostic.shipment-routing-callbacks')
catalog['cases']=cases+[next(item for item in catalog['cases'] if item['id']==name) for name in controls]
save(lab/'representative.json',catalog)
identity=dict(sourceRevision=head,sourcePatchSHA256=sha(lab/'candidate.patch'),
    catalogSHA256=sha(lab/'representative.json'),imageFiles=images,
    coreSHA256={role:files[core.name]for role,files in images.items()},cpythonWorkerSHA256=ref['cpythonWorkerSHA256'])
save(lab/'identity.json',identity)
sdk=Path.home()/'.dotnet11'; dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
worker=repo/'benchmarks/cpython-worker.py'
assert sha(worker)==identity['cpythonWorkerSHA256']
for role,files in images.items():
    image=lab/role
    evidence=lab/(role+'-verify.json')
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',lab/'representative.json',
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',worker,'--out',evidence],
        cwd=repo,env=env,check=True,timeout=80)
    checked=read(evidence)
    assert checked['state']=='Completed' and checked['caseCount']==7
    assert checked['catalogSha256']==identity['catalogSHA256']
    assert checked['launched']['library']['sha256']==files[core.name]
print('Verified all seven independent CPython goldens per image.')
