from pathlib import Path
import shutil
r=Path(__file__).parent
old=r.parent/'record-resolution-r119/census'
(r/'census').mkdir()
for name in ['census.csproj','packages.lock.json']:shutil.copyfile(old/name,r/'census'/name)
source=(old/'Program.cs').read_text(encoding='utf-8')
needle='operations.Add(new { op, line = Get(span, "Line"),'
assert needle in source
source=source.replace(needle,'operations.Add(new { op, hasLocalResult=Get(instruction,"HasLocalResult"), line = Get(span, "Line"),')
(r/'census/Program.cs').write_text(source,encoding='utf-8')
(r/'selection.md').write_text('''# R147 general operand transport source gate

R140/R143 profiles show substantial useful work inside the VM prefix, not a
removable tax. Check actual emitted code/source before another redesign. Reuse
the existing compile-only metadata census; no guest run, runtime instrumentation,
fuel/checkpoint counter, frame arena or production visitor.
Hypothesis: immediate producer/local-store paths still transport values through
temporary operand slots. Source already finds HasLocalResult/CompleteLocalResult
forwarding, input forwarding and retained cleanup continuation. Census five
maintained complete scripts to distinguish current live work from already removed
phases. Inspect lowered class/capture limits without weakening semantic bridges.
Budget: source/census gate under20min; no new capture/timing without a coherent
remaining phase/storage deletion. Static counts are not dynamic CPU shares.
Preserve per-store terminal checks/spans, current cells/mirrors, pending cleanup
before publication, retained values and host cancellation. Existing direct final
UTF8/managed ASCII casing, fused split and coarse small-integer admission are
completed paths, not new optimization targets. Missing producer APIs do not block
this independent source work. Publication remains postponed.
''',encoding='utf-8')
print('Reused compile-only census with current local-result marker; no guest/runtime changes.')
