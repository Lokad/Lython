set -eu
root=/home/lokad/lython-bench-checks/native-conversion-failure-b1134-20261119
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
