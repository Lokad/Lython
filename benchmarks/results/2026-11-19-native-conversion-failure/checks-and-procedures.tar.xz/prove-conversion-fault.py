import json
import os
from pathlib import Path
import subprocess
import textwrap

lab = Path(__file__).resolve().parent
tree = Path.cwd() / '.git/agent-worktrees/native-conversion-failure-r704'
test = tree / 'tests/Lokad.Lython.PublicApi.Tests/DirectIntegerTextCallTests.cs'
test_source = test.read_text(encoding='utf-8')
section = test_source.split('"conversion_error_unwind",', 1)[1]
raw_source = section.split('"""', 2)[1]
program = textwrap.dedent(raw_source[1:])
unhandled = "def parse(value):\n    return int(value)\nparse('invalid')\n"
sdk = Path.home() / '.dotnet11'
dotnet = sdk / 'dotnet.exe'
probe = lab / 'tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll'
python = Path('C:/Python313/python.exe')
env = dict(os.environ, DOTNET_ROOT=str(sdk), PATH=str(sdk) + os.pathsep + os.environ['PATH'])
for flags in ([], ['--async']):
    name = 'async' if flags else 'sync'
    result = subprocess.run([dotnet, probe, '--batch-json', '--compare-python', '--python', python, *flags],
                            input=json.dumps([program, unhandled]), env=env, capture_output=True, text=True,
                            encoding='utf-8', cwd=lab, timeout=30)
    (lab / f'probe-{name}.jsonl').write_text(result.stdout, encoding='utf-8', newline='\n')
    (lab / f'probe-{name}.stderr').write_text(result.stderr, encoding='utf-8', newline='\n')
    records = [json.loads(line) for line in result.stdout.splitlines()]
    assert len(records) == 2 and result.returncode in (0, 1) and not result.stderr, result.stderr
    assert all(item['Compared'] and item['Matches'] for item in records), records
    assert records[1]['Lython']['Failure']['ExceptionType'] == 'ValueError'
