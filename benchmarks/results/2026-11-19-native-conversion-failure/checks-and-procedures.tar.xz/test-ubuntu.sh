#!/usr/bin/env bash
set -euo pipefail
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/validator-errors-r704
cd /mnt/d/code/Lython/.git/agent-worktrees/native-conversion-failure-r704
export PATH="$HOME/.dotnet:$PATH"
filter='(FullyQualifiedName~IntegerText|FullyQualifiedName~Utf8Integer|FullyQualifiedName~Exception|FullyQualifiedName~AdmissionFailureCommand|FullyQualifiedName~Protected)&Category!=Stress'
dotnet test tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj -c Release -f net10.0 \
  -p:ArtifactsPath="$lab/ubuntu" --filter "$filter" --nologo
