import json
import subprocess
import sys
from pathlib import Path

lab = Path(__file__).resolve().parent
previous = lab.parent / 'opened-file-acquisition-r702'
load = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
catalog = load(previous / 'catalog.json')
valid, = (case for case in load(lab / 'input-contrast.json')['cases'] if case['id'].endswith('.bad-0'))
catalog['cases'].insert(1, valid)
assert len(catalog['cases']) == 5
(lab / 'catalog.json').write_text(json.dumps(catalog, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')
source = (previous / 'freeze-and-verify.py').read_text(encoding='utf-8')
source = source.replace('opened-file-acquisition-r702', 'native-conversion-failure-r704')
source = source.replace("git('rev-parse','e7cb313d1')", "git('rev-parse','7d120c9ea')")
source = source.replace('len(load(catalog_path)["cases"]) == 4', 'len(load(catalog_path)["cases"]) == 5')
source = source.replace('all four cases', 'all five cases')
(lab / 'freeze-and-verify.py').write_text(source, encoding='utf-8', newline='\n')
subprocess.run([sys.executable, '-X', 'utf8', lab / 'freeze-and-verify.py'], check=True)
