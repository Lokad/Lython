import json
import subprocess
import sys
from pathlib import Path

lab = Path(__file__).resolve().parent
previous = lab.parent / 'opened-file-acquisition-r702'
stage = (previous / 'stage-quiet.py').read_text(encoding='utf-8')
stage = stage.replace('opened-file-acquisition-b1133', 'native-conversion-failure-b1134')
stage = stage.replace('lython-b1133-opened-file-acquisition', 'lython-b1134-native-conversion-failure')
stage = stage.replace('lython-b1133-fixtures', 'lython-b1134-fixtures')
stage = stage.replace('R702 completed file acquisition without a forwarding await',
                      'R704 route malformed integer conversion without CLR unwinding')
stage = stage.replace('Opened file acquisition source pair', 'Native conversion failure source pair')
start = stage.index('        jobs = [')
end = stage.index('\n', start)
catalog = json.loads((lab / 'catalog.json').read_text(encoding='utf-8'))
jobs = [(case['id'], 'warm') for case in catalog['cases']]
assert len(jobs) == 5 and jobs[1][0].endswith('.bad-0')
stage = stage[:start] + '        jobs = ' + repr(jobs) + stage[end:]
stage = stage.replace('==4', '==5').replace('jobs=4,', 'jobs=5,').replace('}) == 4', '}) == 5')
stage = stage.replace('"four-case, four-job', '"five-case, five-job').replace('four-case, four-job', 'five-case, five-job')
stage = stage.replace('"238"', '"295"').replace('seconds=238', 'seconds=295')
stage = stage.replace('"Completed machine integer prefix").replace', '"Native conversion failure").replace')
assert '"reference/" + core, "candidate/" + core' in stage

proof = (previous / 'prove-quiet-space.py').read_text(encoding='utf-8')
start = proof.index('pairs = ')
end = proof.index('\n', start)
pairs = [('opened-file-acquisition-r702/quiet', '2026-11-19-opened-file-acquisition', 'candidate', 'measured-core.dll.gz'),
         ('opened-file-acquisition-r702/quiet', '2026-11-19-opened-file-acquisition', 'reference', 'reference-core.dll.gz')]
proof = proof[:start] + 'pairs = ' + repr(pairs) + proof[end:]
for name, contents in [('prove-quiet-space.py', proof), ('stage-quiet.py', stage)]:
    (lab / name).write_text(contents, encoding='utf-8', newline='\n')
    subprocess.run([sys.executable, '-X', 'utf8', lab / name], check=True)
