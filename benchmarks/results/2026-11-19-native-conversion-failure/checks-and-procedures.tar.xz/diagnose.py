import base64
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess

lab = Path(__file__).resolve().parent
repo = Path.cwd()
previous = lab.parent / 'opened-file-acquisition-r702'
load = lambda path: json.loads(path.read_text(encoding='utf-8-sig'))
digest = lambda value: hashlib.sha256(value).hexdigest()
catalog = load(previous / 'catalog.json')
original = next(case for case in catalog['cases'] if case['id'] == 'scripts.config-generated-guards.medium')
original_fixture = json.loads(original['fixtureJson'])
original_bytes = base64.b64decode(original_fixture['inputFiles']['config.json'], validate=True)
assert original_bytes.count(b'"bad"') == 6
assert original_fixture['outputFiles'] == {}
fields, total, errors = map(int, original['expectedOutput'].split())
assert fields == 96 and errors >= 6
cases = {6: original}
for failures in (0, 3):
    case = dict(original)
    replacement = original_bytes.replace(b'"bad"', b'"000"', 6 - failures)
    assert len(replacement) == len(original_bytes) and replacement.count(b'"bad"') == failures
    fixture = dict(original_fixture, inputFiles={'config.json': base64.b64encode(replacement).decode('ascii')})
    fixture_json = json.dumps(fixture, separators=(',', ':'), ensure_ascii=False)
    expected = f'{fields} {total} {errors - (6 - failures)}\n'
    case.update(id=f'{original["id"]}.bad-{failures}', fixtureJson=fixture_json, expectedOutput=expected,
                fixtureSha256=digest(fixture_json.encode('utf-8')), expectedOutputSha256=digest(expected.encode('utf-8')),
                expectedOutputUtf8Bytes=len(expected.encode('utf-8')))
    cases[failures] = case
catalog['cases'] = [cases[count] for count in (0, 3, 6)]
catalog_file = lab / 'input-contrast.json'
catalog_file.write_text(json.dumps(catalog, indent=2, ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')
identity = load(previous / 'frozen-identity.json')
image = previous / 'frozen/reference'
expected_image = identity['images']['reference']

def check_image():
    assert len(expected_image) == 32
    assert {name: digest((image / name).read_bytes()) for name in expected_image} == expected_image

sdk = Path.home() / '.dotnet11'
dotnet = sdk / 'dotnet.exe'
python = Path('C:/Python313/python.exe')
adapter = image / 'Lokad.Lython.Benchmarks.dll'
worker = repo / 'benchmarks/cpython-worker.py'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk) + os.pathsep + os.environ['PATH'])
verify = ['--catalog', catalog_file, '--dotnet', dotnet, '--python', python, '--python-worker', worker]

def run(args, log, timeout):
    with (lab / log).open('wb') as output:
        subprocess.run(args, env=env, stdout=output, stderr=subprocess.STDOUT, cwd=lab, timeout=timeout, check=True)

check_image()
run([dotnet, adapter, '--compare', 'verify', *verify, '--out', lab / 'verify.json'], 'verify.log', 120)
assert load(lab / 'verify.json')['state'] == 'Completed'
run([dotnet, image / 'ValidatedAllocation.dll', image, catalog_file, lab / 'allocation.json'], 'allocation.log', 120)
allocation = {row['id']: row for row in load(lab / 'allocation.json')['rows']}
samples = {count: [] for count in cases}
for occurrence, order in enumerate(((0, 3, 6), (6, 3, 0))):
    for count in order:
        label = f'bad-{count}-run-{occurrence + 1}'
        result = lab / (label + '.json')
        case_id = cases[count]['id']
        run([dotnet, adapter, '--compare', 'micro', *verify, '--baseline-worker', adapter,
             '--case', case_id, '--lane', 'warm', '--out', result], label + '.log', 30)
        record = load(result)
        assert record['state'] == 'Completed' and not record['performanceQualified']
        samples[count].append(record['summaries'])
        check_image()

for count, timings in sorted(samples.items()):
    record = allocation[cases[count]['id']]
    assert record['sharedBudgetBaselineRestored']
    timing = [[(row['engine'], round(row['medianMicroseconds'], 3), round(row['iqrFraction'] * 100, 2))
               for row in batch] for batch in timings]
    print(count, 'bad fields', 'allocation', statistics.median(record['allocatedBytesPerInvocation']),
          'peak', record['peakExecutionMemoryBytes'], 'timing and IQR %', timing, flush=True)
