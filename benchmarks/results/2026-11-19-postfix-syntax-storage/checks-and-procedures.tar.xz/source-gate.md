# R591 source gate

B1014 found call-postfix parsing in 30 nearest phase samples on the manifest
and 50 on the generated validator. ParsePostfixExpression added 27 and 29
respectively. Sampling includes useful parser work.

Parser.Expressions.Postfix allocates three once-per-process form parser
singletons. One private interface call routes each postfix member, call or
subscription. Through the same path, every call allocates a List and builds
the ordered AST arguments with two filtered enumerations and a copy.
The call compilers, validators and rewrites consume the result as an owned
IReadOnlyList and do not mutate it. Verify that the producer can transfer
its list for already ordered normal calls. Allocate one stable reordered
array only when a later bare star must move before earlier keyword forms.
Make empty calls use the shared empty collection.

A simple index or slice also creates a list and a collection-item record,
then discards both before creating the AST node. Keep its first parsed
expression directly until a comma or star proves it needs tuple items.
Replace the postfix strategy types with private Parser operations.

Keep exact evaluation order for legal keyword-before-star forms, multiple
star and double-star forms, generators, spaces, trailing commas, tuple and
slice indexes, and managed nesting checks and spans. Differentially compare
ordered diagnostics on invalid cases. Measure public compilation and
compile-to-result for both B1014 scripts with warm controls.
