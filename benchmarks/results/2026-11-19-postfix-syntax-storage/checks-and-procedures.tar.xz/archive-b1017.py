from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
quiet = lab / 'quiet'
out = Path('benchmarks/results/2026-11-19-postfix-syntax-storage')
base = '6c1da75b76a1f406210c035caf78841cf574e853'
candidate = (lab / 'prototype-commit.txt').read_text(encoding='utf-8').strip()
load = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
terminal, receipt = [load(quiet / f'{file}.json') for file in ('terminal-status', 'archive-receipt')]
assert terminal['receipt'] == receipt and terminal['exitCode'] == '0'
assert not terminal['remainingWorkers'] and not terminal['remainingTrace']
assert all(receipt[field] for field in ['complete','allWorkersJoined','guestFixturesRemoved',
                                      'quietBeforeAndAfter','archivedAndVerifiedUnderLease'])
assert receipt['jobs'] == 5 and receipt['archiveSHA256'] == sha(quiet / 'observations.tgz')
identity = load(quiet / 'identity.json')
catalog = load(lab / 'catalog.json')
assert sha(lab / 'catalog.json') == identity['catalogSHA256']
cases = {case['id']: case for case in catalog['cases']}
raw = load(quiet / 'retrieved/confirmation/confirmation.json')
assert raw['complete'] and len(raw['jobs']) == 5
for job in raw['jobs']:
    case = cases[job['case']]
    assert job['workersJoinedAndFixturesRemoved'] and len(job['samples']) == 20
    assert set(job['identities']) == set(identity['coreSHA256'])
    for engine, info in job['identities'].items():
        native = next(lib for lib in info['libraries'] if Path(lib['path']).name == 'Lokad.Lython.dll')
        assert native['sha256'].lower() == identity['coreSHA256'][engine]
    for sample in job['samples']:
        response = sample['response']
        assert response['status'] == 'Completed' and response['completedInvocations'] > 0
        assert response['sourceSha256'] == case['sourceSha256'] and response['fixtureSha256'] == case['fixtureSha256']
        expected = case['expectedOutputSha256'] if job['lane'] != 'compile' else None
        assert response.get('actualOutputSha256') == expected
        expected = case.get('expectedFilesSha256') if job['lane'] != 'compile' else None
        assert response.get('actualFilesSha256') == expected
out.mkdir(exist_ok=True)
summary = load(lab / 'quiet-summary.json')
summary.update(referenceRuntime='6c1da75b7', candidateBase=base, measuredPrototype=candidate,
               cores=identity['coreSHA256'], archiveSHA256=receipt['archiveSHA256'], retentionDecisionPending=False, retainedCommit='c6d4683e5')
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8', newline='\n')
for name in ['observations.tgz','archive-receipt.json','terminal-status.json']:
    shutil.copyfile(quiet / name, out / name)
diff = subprocess.check_output(['git','diff','--binary',base,candidate,'--','src','tests'])
assert b'-    private interface IPostfixParser' in diff and b'+    private IReadOnlyList<CallArgumentSyntax>? ParseCallArguments' in diff
(lab / 'measured-source.patch').write_bytes(diff)
with tarfile.open(out / 'checks-and-procedures.tar.xz','w:xz',preset=6) as archive:
    for name in ['measured-source.patch','verify-pair.py','reference-verify.json','candidate-verify.json',
                 'reference-allocation.json','candidate-allocation.json','quiet-space.json','stage-quiet.py',
                 'launch-quiet.py','archive-b1017.py','summarize-quiet.py',
                 'focused-whitebox-win-net11.log','focused-public-win-net11.log',
                 'focused-whitebox-wsl-net10.log','focused-public-wsl-net10.log','focused-public-wsl-probe-ready-net10.log','focused-public-wsl-fixture-ready-net10.log','compare-probes.py','probes.json',
                 'comparison.json','reference-sync.jsonl','reference-async.jsonl','candidate-sync.jsonl','candidate-async.jsonl',
                 'probe-build-wsl-net10.log','freeze-build.log','archive-prior-core.py','canonical-space.py','source-gate.md','prototype-commit.txt']:
        archive.add(lab / name, arcname=name)
    for name in ['config.json','preflight.json','launch.log','remote-launch.py','retrieve.py','observe-not-before.json']:
        archive.add(quiet / name, arcname='quiet/' + name)
print('Verified B1017 against both hashes, all 100 golden responses, and the measured source patch.')

