from pathlib import Path
import json, os, subprocess

lab=Path(__file__).resolve().parent
repo=Path.cwd()
source = ['def f():return 7\nprint(f())', 'def f(x,y=9,**kw): return x,y,kw\nprint(f(1,a=4),f(2,3),f(y=12,x=5))', "events=[]\ndef mark(label,value):\n events.append(label)\n return value\ndef f(*a,**kw): return a,kw\nprint(f(mark('first',1),a=mark('kw',2),*mark('star',[3]),z=mark('last',4),**mark('mapping',{'late':5})))\nprint(events)", "def f(*a,**kw): return a,kw\nprint(f(*[1], first=2, *[3], second=4, *[5], **{'third':6}))", 'print(sum(i*i for i in range(6)))', 'print(list((i for i in range(5)),))', 'print(list(\n (x+1 for x in range(3)), # grouping\n))', 'class Box:\n def __getitem__(self,key):return key\nb=Box()\nprint(b[1],b[1,],b[*[1]],b[*[2,3],4])', 'class Box:\n def __getitem__(self,key):return key\nb=Box()\nprint(b[1:3],b[1:3,],b[1:-2:3,2:],b[:])', 'class Box:\n def __getitem__(self,key):return key\nb=Box()\nprint(b[\n 1 : 9, # comment\n *[2,3],\n])', 'print([1,2,3][1:][0].real)', "d={'a':[3,4]}\nd['a'][0]=7\nprint(d['a'][0])", 'print((lambda n:n)(4).real)', 'print((lambda x, *,y=2: x+y)(y=3,*(1,)))', "def f(*a, **kw):return kw\nprint(f(**{'x':1},**{'y':2}))", 'def f(*a, **kw): pass\nf(**{}, *[1])', 'def f(*a, **kw): pass\nf(x=1,2)', 'def f(*a, **kw): pass\nf(a=1,a=2)', 'f(,)', 'f(1', 'f(x=)', 'a[]', 'a[,1]', 'a[1,', 'a[1:2:3:4]', 'a[*[1]:]', 'a.', 'f(1 for x in [], 2)', 'f(*(1,), **{}, x=4, *[2])', 'print([x for x in range(3)][-1:])', 'a.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x', 'a.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x', 'a.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x', 'a.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x.x']
source.extend([
 'class Empty():\n pass\nprint(Empty.__name__)',
 'class Base: pass\nbases=(Base,)\nclass Derived(*bases,metaclass=type): pass\nprint(issubclass(Derived,Base))',
 'class Base: pass\nclass Derived(metaclass=type, *(Base,)): pass\nprint(issubclass(Derived,Base))',
 'class Derived(metaclass=type, metaclass=type): pass',
 'class Derived(metaclass=): pass',
 'class Derived(,): pass',
])
(lab/'probes.json').write_text(json.dumps(source,ensure_ascii=False)+'\n',encoding='utf-8')
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
probes={
 'reference':repo/'.git/agent-worktrees/abstract-value-facts-r589/tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll',
 'candidate':repo/'.git/agent-worktrees/postfix-result-construction-r591/tools/LythonProbe/bin/Release/net11.0/LythonProbe.dll',
}
compared=[]
fields=('Success','StandardOutput','StandardError','ExitCode','Diagnostics','Failure')
for mode in ['sync','async']:
 rows={}
 for label,probe in probes.items():
  args=[str(sdk/'dotnet.exe'),str(probe),'--batch-json','--max-memory-bytes','4194304']
  if mode=='async':args+=['--async']
  actual=subprocess.run(args,env=env,input=(lab/'probes.json').read_bytes(),capture_output=True,timeout=90)
  (lab/f'{label}-{mode}.jsonl').write_bytes(actual.stdout)
  (lab/f'{label}-{mode}.stderr').write_bytes(actual.stderr)
  records=[json.loads(line) for line in actual.stdout.decode('utf-8-sig').splitlines()]
  assert len(records)==len(source),(label,mode,len(records),actual.stderr)
  rows[label]=[{k:r['Lython'].get(k) for k in fields} for r in records]
 differences=[i for i,(a,b) in enumerate(zip(rows['reference'],rows['candidate'])) if a!=b]
 compared.append(dict(mode=mode,matching=len(source)-len(differences),total=len(source),differences=differences))
(lab/'comparison.json').write_text(json.dumps(compared,indent=2)+'\n',encoding='utf-8')
print(compared)
assert all(not row['differences'] for row in compared)
