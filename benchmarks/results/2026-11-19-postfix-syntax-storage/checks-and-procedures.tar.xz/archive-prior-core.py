from pathlib import Path
import gzip, hashlib, json, subprocess

lab = Path(__file__).resolve().parent
core = 'Lokad.Lython.dll'
prior = lab.parent / 'trailing-keyword-operands-r587'
image = prior / 'frozen' / 'candidate'
shas = json.loads((prior/'frozen-identity.json').read_text(encoding='utf-8-sig'))['images']['candidate']
sha = lambda data: hashlib.sha256(data).hexdigest()
assert len(shas)==32 and all(sha((image/n).read_bytes())==digest for n,digest in shas.items())
assert shas[core].startswith('df78258f')
target = Path('benchmarks/results/2026-11-18-trailing-keyword-operands/candidate-core.dll.gz')
content = (image/core).read_bytes()
canonical = gzip.compress(content,6,mtime=0)
assert gzip.decompress(canonical)==content
if target.exists():
    assert target.read_bytes()==canonical
else:
    target.write_bytes(canonical)
print(target, sha(canonical))