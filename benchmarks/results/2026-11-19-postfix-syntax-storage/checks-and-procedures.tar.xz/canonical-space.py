from pathlib import Path
import gzip,hashlib,json,subprocess

lab=Path(__file__).resolve().parent
target=Path('benchmarks/results')
sha=lambda content: hashlib.sha256(content).hexdigest()
groups=[]
for name, filename, paths in [
    ('trailing-keyword-operands','candidate-core.dll.gz',
     ['trailing-keyword-operands-b1012-20261118/candidate/Lokad.Lython.dll',
      'current-compile-attribution-b1013-20261118/candidate/Lokad.Lython.dll',
      'current-compile-attribution-b1014-20261118/candidate/Lokad.Lython.dll']),
    ('current-compile-attribution','observations.tgz',['current-compile-attribution-b1014-20261118/observations.tgz']),
    ('post-transport-attribution','observations.tgz',['post-transport-attribution-b1011-20261118/observations.tgz']),
]:
    canonical=(target/f'2026-11-18-{name}'/filename).as_posix()
    archived=subprocess.check_output(['git','show',f'origin/master:{canonical}'])
    assert archived==Path(canonical).read_bytes()
    raw=gzip.decompress(archived) if filename.endswith('.gz') else archived
    groups.append(dict(bytes=len(raw),sha256=sha(raw),canonical=canonical,canonicalSHA256=sha(archived),
                       committedBlobVerified=True,kind='exact archived measured replica',paths=paths,links=len(paths)))
assert groups[0]['sha256'].startswith('df78258f')

remote="""
from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
root=Path('/home/lokad/lython-bench-checks'); assert root.resolve()==root
groups=PROOFS
with (root/'comparison-vm.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.13.*cpython-worker.py'],capture_output=True).stdout
 assert not any(os.path.ismount(p) for p in root.glob('*/guest-fixtures'))
 inodes=set()
 for proof in groups:
  inode=None
  for name in proof['paths']:
   path=root/name
   assert path.resolve()==path and path.is_relative_to(root)
   st=path.lstat(); key=(st.st_dev,st.st_ino)
   assert stat.S_ISREG(st.st_mode) and st.st_uid==os.getuid() and st.st_size==proof['bytes'] and st.st_nlink==proof['links']
   assert hashlib.sha256(path.read_bytes()).hexdigest()==proof['sha256']
   if inode is None: inode=key
   assert key==inode
  assert inode not in inodes
  inodes.add(inode)
 print(json.dumps(dict(freeBytes=shutil.disk_usage(root).free,replicas=groups)))
""".replace('PROOFS',repr(groups))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i',str(Path.home()/'.ssh/id_lython-bench.pem'),
     '-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
verified=json.loads(subprocess.check_output(ssh+['python3 -'],input=remote.encode(),timeout=30))
assert verified['replicas']==groups
(lab/'quiet-space.json').write_text(json.dumps(verified,indent=2)+'\n',encoding='utf-8')
print(verified['freeBytes'],[(g['sha256'][:8],g['bytes']) for g in groups])