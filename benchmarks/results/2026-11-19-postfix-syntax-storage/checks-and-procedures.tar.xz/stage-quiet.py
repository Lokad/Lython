from pathlib import Path
import ast,hashlib,json,shutil,tarfile

lab=Path(__file__).resolve().parent
prior=lab.parent/'abstract-value-facts-r589'
quiet_prior=prior/'quiet'
quiet=lab/'quiet'
quiet.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
read=lambda p:p.read_text(encoding='utf-8')
def write(path,source):
    if path.suffix=='.py': ast.parse(source)
    path.write_text(source,encoding='utf-8',newline='\n')
def save(path,data):write(path,json.dumps(data,ensure_ascii=False,indent=2)+'\n')

old=load(quiet_prior/'config.json')
screen=load(lab/'frozen-identity.json')
space=load(lab/'quiet-space.json')
catalog=lab/'catalog.json'
images=screen['images']
source_files=old['identity']['imageFiles']['candidate']
core='Lokad.Lython.dll'
assert screen['casesSHA256']==sha(catalog)==old['catalogSHA256']
assert source_files==images['reference']
for role,files in images.items():
    assert len(files)==32 and files==source_files|{core:files[core]}
    assert {name:sha(lab/'frozen'/role/name) for name in files}==files
    verify=load(lab/f'{role}-verify.json')
    assert verify['state']=='Completed' and verify['catalogSha256']==sha(catalog)
    (quiet/role).mkdir()
    shutil.copyfile(lab/'frozen'/role/core,quiet/role/core)
prototype=read(lab/'prototype-commit.txt').strip()
identity=dict(sourceRevision='6c1da75b7 versus '+prototype,
              purpose='R591 final postfix syntax storage',
              imageFiles=images,catalogSHA256=sha(catalog),normalAdapterPin='0.4.0',
              coreSHA256={label:images[role][core] for role in images for label in (role,role+'-control')})
root='/home/lokad/lython-bench-checks/postfix-syntax-storage-b1017-20261119'
unit='lython-b1017-postfix-syntax-storage-20261119'
for name in ['collect.py','archive-owned.py','run.sh']:
    write(quiet/name,read(quiet_prior/name).replace(old['root'],root))
save(quiet/'identity.json',identity)
shutil.copyfile(catalog,quiet/'representative.json')
names=['collect.py','archive-owned.py','run.sh','identity.json','representative.json','candidate/'+core]
payload=quiet/'payload.tgz'
with tarfile.open(payload,'w:gz') as out:
    for name in names:out.add(quiet/name,arcname=name)
expanded=sum((quiet/name).stat().st_size for name in names)
need=254*1024*1024+expanded+512*1024
available=space['freeBytes']
selected=[]
for proof in sorted(space['replicas'],key=lambda p:-p['bytes']):
    if available>=need:break
    assert proof['committedBlobVerified']
    available+=proof['bytes']
    selected.append(proof)
save(quiet/'preflight.json',dict(available=available,need=need,withoutRetirement=space['freeBytes'],selected=selected))
assert available>=need,(available,need)
config=dict(root=root,unit=unit,source=old['root'],sourceRole='candidate',sourceFiles=source_files,
            sourceCatalogSHA256=old['catalogSHA256'],catalogSHA256=sha(catalog),identity=identity,
            retireGroups=selected,payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),unpackedBytes=expanded)
save(quiet/'config.json',config)
launch=read(quiet_prior/'remote-launch.py')
a=launch.index('\nc=')+1
b=launch.index('\nb=Path(')
write(quiet/'remote-launch.py',(launch[:a]+'c='+repr(config)+launch[b:]).replace('lython-b1015-fixtures','lython-b1017-fixtures'))
write(lab/'launch-quiet.py',read(prior/'launch-quiet.py').replace('Executable definition inputs source pair','Postfix syntax storage source pair'))
write(quiet/'retrieve.py',read(quiet_prior/'retrieve.py'))
write(lab/'summarize-quiet.py',read(prior/'summarize-quiet.py'))
print('Verified both full images and five jobs with', available-need, 'bytes above the staging requirement')