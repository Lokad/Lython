# Lokad.Lython 0.11.0

Updated 2026-11-11. Git-ignored: never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial whole-script improvement,
including compilation. One isolated experiment does not complete this objective.

## Actual delivery status

- **Committed runtime:** `4aa2d46d`, fully qualified and pushed. Evidence `be08b541`/`2f6fa99e`, workload `e5262da5`, all pushed. All 568 production source hashes remain equal
  to qualified4aa before R230. No active CI; cached GREEN
  [42953725339](https://github.com/Lokad/Lython/actions/runs/42953725339): Windows/Ubuntu,
  actual .NET11/.NET10, original Stress and installed Release consumers. Never
  query completed runs again. [Receipt](benchmarks/results/2026-11-11-ordinary-return-consumption/delivery-ci.json).
- **R229 comparison complete, committed2f6fa99e:** four jobs/114.763s,
  qualified4aa/frozen9ee7 versus stock CPython3.13.16. Patch warm0.86–0.90×,
  complete0.85–0.86×, compilation0.98–1.00×. Warm Lython control4.44% is variable;
  complete controls tighter. All output/ownership/quiet/join/archive gates pass.
  Single-edit fixture establishes no general diff throughput or optimization gain.
  [Evidence](benchmarks/results/2026-11-11-patch-workflow/README.md).
- **R230 complete/withdrawn:** private prepared ranges remove a scan but add an
  allocation/copy,20net lines and replacement overlap. Text allocation+8.48–9.11%,
  execution allowance peaks+163,840B/about9.85%, not RSS. Desktop clocks mixed/
  adverse with moving controls; no CPU claim. Exact qualified4aa source restored;
  forced nonincremental build20.05s/zero warnings/errors and45internal/263public
  focused checks per actual target pass. No active prototype/check/CI/VM collection.
  [Evidence](benchmarks/results/2026-11-11-prepared-split-ranges-withdrawn/README.md).
- **Regex development:** immutable dev68/a7e985ed qualified with unchanged Validate
  bridge:86 internal/532 public checks per actual target, loaded hashes match,
  29 normal-state files unchanged. Normal optional adapter stays0.4/non-packable;
  no backend CPU/safety/final-publication claim. Core remains decoupled.

## Completed milestones

| Delivered | Established result / limitation |
| --- | --- |
| Shared compiler facts | Corrects exponential shared-expression traversal; reuses binding/module/scope facts. R222 uses resolved nonlocal targets, preserving global barriers and runtime deletion/handler checks. Read-only declarations conservatively defer diagnosis. Fully qualified; no speed claim. |
| Direct UTF-8 formatting/storage | Fully qualified. Allocation−8.67%; controlled elapsed/CPU about5–8% lower. Original adverse15.125ms survives unexplained. No unchanged replay. |
| Native helper returns | Fully qualified. Allocation−19.92% sync/−19.31% async; original elapsed gains diagnostic. No pending delivery checks. |
| Calls/setup/CSV | Immutable builtin metadata, async startup reuse, shared binding/workspace, receiver entry and deferred contexts delivered. CSV shares keys/adopts funded rows after revisiting6–8% findings. Slower arenas/control designs removed. |
| R221 lexical writes | Fully qualified4625. Owner updates slot/namespace once; removes writer-context promotion/name search/duplicate sync. Counter CSV/text/report allocation−41.4/47.9/27.5%; quiet warm about16–17/19–21/12–15% lower with wider CPU support. Control neutrality unresolved; adversity retained. |
| R225 returned iteration | Fully qualified4aa. Removes eager result-list/range/word-reference construction for direct ordinary returns consumed by iteration. Captured text allocation−4.84% both APIs; estimated allowance peak−15.06%, not RSS. Compile allocation+.05–.16%; quiet elapsed−1.88..+.34% inconclusive, ordinary control CPU up to+3.31% possible debt. Preserve custom-intermediate-result type-error correction. |
| Text/JSON/IR | Native casing/split/formatting/final JSON UTF-8, span tuple construction and same-suite jumps delivered. R217 removes156 net lines, allocation neutral on short strings, elapsed uncertain. |
| Regex | Core-owned Python UTF-8 contract, consistent frontend/runtime/import provider, original windows/effective flags/current tokens/ownership delivered. R219 removes two per-match coordinate arrays/reservation/plumbing, Unicode allocation−17–18%, no CPU claim. |

Current source-labelled comparisons: [BENCHMARKS](docs/BENCHMARKS.md). Historical
source pairs, failures, rejected work and qualification:
[EXPERIMENTS](benchmarks/EXPERIMENTS.md). Prior plans remain under
`.git/agent-notes/review-20261031/`. Do not repeat completed qualification.

## P1 — useful-script construction and transport

**Next: complete call/frame/operand pipeline design gate.** Build from R221/R225's
existing direct operands, shared bound/local workspace, cached immutable call
metadata and deferred contexts. Reuse R227 current-source samples, not a new broad
profile: call entry4.29%, operand/result transport7.89%, native selection5.40%;
these include useful work and do not predict removable CPU. Source confirms the
idle function workspace is already funded/reused without renewed admission on a
cache hit; another pool/lock-avoidance layer is not selected.

Prepare one coherent replacement proposal for an actual remaining construction/
transition/transport phase, with the displaced helpers/storage named. It must reach
ordinary positional/keyword helpers, methods or callbacks in complete agent scripts,
not just add another native-return recognition or opcode branch. Stop the source
gate when elimination and meaningful workload reach are demonstrated, or explicitly
reject it and move to the next boundary below; no indefinite audit or speculative
rewrite. No assumed extra packet, frame, boxed-value cause or speed percentage.

Before implementation: specify source/alias/descriptor/default/keyword/closure/
handler/evaluation-order/generator/suspension acceptance, original diagnostic spans,
managed stack/cancellation/terminal-refusal/funded retention and awaited cleanup.
Use existing six complete scripts/unchanged controls; allocation and Run-only/
envelope distinct, compile separate. One short affected quiet confirmation when
design/diagnostic evidence merits it. Retain/refine/withdraw explicitly, including
remaining regression debt; batch full delivery only for retained runtime work.

**R230 lesson:** keeping ranges trades a second scan for a per-input array/copy and
more lifetime/overlap accounting. Captured text sync envelope+5.98..+7.17%, async
+1.19..+4.75%; ordinary text−2.56..+.64%/−.14..+2.75%, controls variable. Precise
allocation rises8.48–9.11%, giving back more than R225 saved. No compensating
whole-script benefit is established. Withdraw whole variant rather than add inline
tiers/cache/pool; no quiet confirmation selected. This is a construction/storage
decision, not a fixed percentage veto/permanent ban on another coherent design.
Preserve all original failure conditions, source pairs, checks and adverse clocks;
no repeated scan experiment without a materially different elimination.

**Source gates already closed:** namespace mirroring remains necessary for lazy
annotations, generator scopes and live globals views; compiled lambdas already use
cells. Removing the old-looking helper without migrating those observers repeats
the failed escaped-annotation design. No speculative namespace registry is selected.
R228's direct completion routes add22 net lines/duplicate cleanup guards, allocation
flat and clocks variable/adverse; whole prototype withdrawn for complexity, not a
percentage veto. R229 does not justify diff optimization; current matcher already
reuses two native match-length maps. Prior builtin12/545 samples do not justify lazy
mutable builtin construction. Do not repeat unchanged gates.

| Next design boundary | Work/storage to remove; semantic and measurement gate |
| --- | --- |
| Complete call/frame entry | Binding and prepared locals already share storage; no presumed second argument packet/context. Select actual remaining construction/transition across ordinary calls, methods and callbacks, preserving defaults/keywords/descriptors/closures/handlers/suspension/diagnostics. R227 call-entry4.29% alone is no dominant-cost proof. Slower arena/target mutation requires a materially different elimination. |
| Operand/scalar transport | Replace a complete producer/consumer boundary, never add tagged sidecars beside object slots. Exact promotion, identity/aliases/hooks/projection and original failure spans remain gates. Retire displaced dispatch/storage; scalar3.00% samples alone do not justify a universal representation rewrite. |
| Per-record construction | CSV keys and admitted rows already shared/adopted. Select a demonstrated remaining parse/construction/copy phase, preserving order/duplicates/mutable headers/protocols/retention/reentry. Patch does not exhibit a measured deficit. |
| Text/format boundaries | Final UTF-8 casing/split/format/JSON already delivered; .NET11 numeric TryFormat native, .NET10 admitted char bridge. Eliminate actual repeated passes/conversions with Unicode/hooks/errors and ownership intact. R230 tradeoff documented/withdrawn; another design needs a materially different elimination. |
| Frontend/compile-to-result | Shared facts, compact declarations/direct children and resolved nonlocal facts delivered. Visitors retain distinct facts; no presumed redundant walk. Select measured repeated analysis/storage, preserve scoping/diagnostics. Imports already executable. |

Each selected redesign records hypothesis, actual eliminated code/storage, complete
scripts, compile/retained-capacity costs, semantic gates, controlled source pair and
completion decision. Temporary setbacks are acceptable through an explicit milestone;
decide remaining regression debt before delivery. Continue beyond isolated experiments.

## P2 — CPython refresh at material checkpoints

Current4aa patch and4625 text checkpoints complete. CSV retains e543/6f76,
JSON/report e122, other rows their explicit sources. Refresh affected representative
scripts after material retained work/fairness gaps, not every patch. Compile,
warm execution/startup separate. Warm/complete include mediated RAM I/O, full
output checks/prior-result cleanup; exclude reset/protocol/final caches. Compilation
includes construction/disposal. Independent medians need not add. RSS, pending I/O
and embedding tail latency remain unqualified. CPython is the primary baseline.

## Independent regex track

Core/contract development continues independently of publication. Test providers,
immutable development inputs and adapter-local bridges permitted. R226/dev68 has
no relevant new public API to replace the Validate bridge. Precisely outstanding:

1. Single-match working owner independent of retained-result owner.
2. Native UTF-8 group-name enumeration; lookup already exists.
3. Token-independent cursor creation with cancellable preparation; per-move tokens
   do not prove creation/preparation interruption.

When native APIs arrive, remove displaced DetailedData/conversion plumbing and
qualify immutable released input. Match/FullMatch alternative selection, captures,
windows/byte+scalar offsets/effective flags/current tokens/caches/funding preserved;
filtered Search is not equivalent. Contract/semantic tests, backend performance,
safety and SizeOf are separate. Missing producer APIs defer only affected final
adapter qualification. Normal0.4/non-packable adapter; no core dependency/fallback.

## Iteration and lasting constraints

Timeouts/unstable unchanged controls/inconclusive observations establish uncertainty,
not failed designs. Allow bounded justified confirmation/refinement/correction and
retain original failures/adversity. No blanket one-attempt/no-retiming/permanent
closure policy. Percentages inform decisions, not automatic vetoes. Distinguish
simplification/allocation/demonstrated CPU/accounted capacity/latency.

Focused Release correctness/cancellation/ownership; no overlapping local build/test/
timing. Force nonincremental build after timestamped restoration. Batch Windows/
Ubuntu, actual11/10, original Stress and installed Release consumers at meaningful
runtime delivery; keep working meanwhile. Active CI queries >=5min apart, terminal
cached/never re-queried. Only core Release packages via tools/pack.ps1 into artifacts/
nuget/. Publication/tagging postponed.

Fully managed/memory-safe: no unsafe/Unsafe/pointers/PInvoke/native stack probing.
Preserve managed stack admission, capabilities, effective current-token cancellation,
cycles/XML depth/checked representations/bounded IO. No fuel/quotas, independent
caps/hidden allowances, tracing/root inventories, weak reclamation/forced GC,
admission retries or abandoned users. Shared borrowed allowance funds major capacity,
replacement overlap/results/aliases/caches/pending users through awaited cleanup;
scope creation reserves zero. First refusal fails command with original attribution
despite suppression/finally returns; native cleanup remains available. Guest-raised
MemoryError catchable. Long streaming uses bounded host commands. Preserve original
LythonPathRequest/Cwd/component resolution; no delete-before-copy/replacement.

## VM / evidence boundary

lokad@20.166.121.73, key ~/.ssh/id_lython-bench.pem. No active VM/CI collection.
B573 terminal cached:4jobs/114.763s, joined workers/RAM removed/archive verified,
final free265,469,952B. Never query it again. Exact committed B572 compressed
archive and both f6c8fd22 core aliases retired with canonical/path/UID/link/inode/
SHA proofs; those paths and all earlier retired paths are off limits. Qualified
9ee7/c271/9dadd survive unchanged. Fresh idle lease/identity/disk proof before new
staging; fixed240MiBfloor/12MiBheadroom, never replay stale retirement recipes.
All prior failures/raw observations/source proofs survive canonical archives.
