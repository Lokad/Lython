from pathlib import Path
import json,re
repo=Path.cwd();r=Path(__file__).parent
changed=[];removed=0
for base in ['src/Lokad.Lython','tests/Lokad.Lython.Tests']:
 for p in (repo/base).rglob('*.cs'):
  if 'obj'in p.parts or 'bin'in p.parts:continue
  before=p.read_text(encoding='utf-8');t=before
  # Delete the old sync array wrappers before making the borrowed entry canonical.
  t,n=re.subn(r'    (?:    )?public object Invoke\(CallArgumentValue\[\] arguments, LythonSourceSpan span, (?:LythonRuntime\.)?ExecutionContext context\)\n        (?:    )?=> InvokeBorrowed\(arguments, span, context\);\n\n','',t)
  removed+=n
  if p.name=='LythonRuntime.Calls.cs':
   start=t.index('        // Consume borrowed inputs before returning pending work.')
   end=t.index('        ValueTask<object> InvokeBorrowedAsync(',start)
   t=t[:start]+'''        // Asynchronous implementations may retain their invocation-private
        // packet until completion. Synchronous calls only borrow their inputs.
'''+t[end:]
  t=t.replace('InvokeBorrowed(', 'Invoke(')
  # Only synchronous entry signatures change. Actual asynchronous retention
  # continues using its existing owned-array contract and awaited cleanup.
  t=re.sub(r'(?m)(\bobject Invoke\()CallArgumentValue\[\]( arguments,)',r'\1ReadOnlySpan<CallArgumentValue>\2',t)
  if p.name=='PyFunctionBase.cs':
   t=t.replace('=> Invoke(arguments, span, context);','=> Invoke(arguments, span, context, receiver: null);')
  if t!=before:
   p.write_text(t,encoding='utf-8',newline='\n');changed.append(p.relative_to(repo).as_posix())
(r/'migration.json').write_text(json.dumps(dict(files=changed,removedSyncArrayForwarders=removed),indent=2)+'\n',encoding='utf-8')
print('Migrated',len(changed),'files; removed',removed,'sync array forwarders.')
