from pathlib import Path
import hashlib,json,subprocess,tarfile
repo=Path.cwd();r=Path(__file__).parent
paths=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
assert paths and all(p.startswith(('src/Lokad.Lython/','tests/Lokad.Lython.Tests/'))and p.endswith('.cs')for p in paths)
snapshot={p:hashlib.sha256((repo/p).read_bytes()).hexdigest()for p in paths}
(r/'candidate-source.patch').write_bytes(subprocess.check_output(['git','diff']))
with tarfile.open(r/'partial-candidate.tar.xz','w:xz')as t:
 for p in paths:t.add(repo/p,arcname=p)
with tarfile.open(r/'before-source.tar')as t:
 before={m.name:t.extractfile(m).read()for m in t.getmembers()if m.isfile()and m.name in paths}
assert set(before)==set(paths)
for name in paths:
 p=repo/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==snapshot[name];p.write_bytes(before[name])
assert not subprocess.check_output(['git','status','--porcelain'])
decision=dict(status='Source gate closed: do not promote the incomplete synchronous signature migration. All original physical sources restored; no runtime mechanism or test change remains.',
    candidateFiles=len(paths),candidateSHA256=snapshot,
    finding='The existing borrowed sync API has a real packet copy for general callables, but simply making it canonical reaches many shared asynchronous core helpers and array-typed delegates. The second compiler pass reports82 body/consumer mismatches after the three initial signature/forwarder corrections.',
    contract='Shared async helpers really retain inputs through callbacks, constructors and cache/descriptor work. New per-call copies/clearing wrappers around those helpers would relocate rather than remove the packaging phase. A coherent future migration must consume arguments into the actual prepared state before suspension, together with its owned storage.',
    scope='No call/frame arena, native proof, compatibility switch or delegate dispatch framework introduced. Do not create another owned-callable adapter hierarchy merely to make the signature migration compile.',
    limitations='No working candidate or timing was produced, so no performance/semantic rejection follows from compiler failures. Original source, partial candidate, all build failures and correction are preserved. This is a coupled preparation/ownership scope finding, not a one-attempt or permanent design veto.',
    next='Use a representative affected construction/callback workload to establish actual retained-packet/preparation cost before selecting the coupled redesign. Current text call-entry4.29% alone cannot justify a repo-wide rewrite. Inspect the existing constructor CSV case; no new benchmark framework or broad ownership audit.',
    restoration='Exact original sources restored. Force a nonincremental build before further no-build checks or freezing a current image. Existing fully qualified4aa remains the runtime delivery source.')
(r/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf-8')
print('Source gate preserved; exact original',len(paths),'files restored. No timed or qualified prototype claimed.')
