from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
repo=Path.cwd();r=Path(__file__).parent;out=repo/'benchmarks/results/2026-11-11-sync-call-contract-source-gate';out.mkdir()
assert not subprocess.check_output(['git','status','--porcelain'])
checks=json.loads((r/'restored-checks.json').read_text(encoding='utf-8'))
assert len(checks)==2 and all(x['exitCode']==0 and x['counts']['failed']=='0'for x in checks.values())
for name in ['before.json','decision.json','migration.json','restored-checks.json']:shutil.copyfile(r/name,out/name)
with tarfile.open(out/'preparation.tar.xz','w:xz')as t:
 for p in sorted(r.rglob('*')):
  if p.is_file()and p.name!='before-source.tar'and '__pycache__'not in p.parts:t.add(p,arcname=p.relative_to(r).as_posix())
p=out/'preparation.tar.xz'
with tarfile.open(p)as t:
 for m in t.getmembers():
  if m.isfile():t.extractfile(m).read()
(out/'archive-identity.json').write_text(json.dumps(dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()),indent=2)+'\n',encoding='utf-8')
(out/'README.md').write_text('''# R231 — synchronous call-contract source gate

2026-11-11, runtime fully qualified4aa, evidence HEADbe08b541. **No runtime edit or
working performance prototype retained.** Exact178 original physical source/test
files are restored. Nonincremental solution build23.96s/zero warnings/errors and
44public call/lifetime/default/named-binding checks per actual.NET11/.NET10 pass.
Prior full runtime/platform/stress/package qualification stays cached; no replay.

The existing ICallable has array Invoke plus borrowed InvokeBorrowed. General sync
borrowed calls materialize/clear a private packet. Known functions/bound methods/
binders consume spans directly. The attempted canonical-span sync signature removes
the default copy and forwarding shims, reaching descriptors, constructors, generated
methods, modules and protocol callbacks. [Initial scope](before.json).

The first compiler pass identifies three signature/duplicate-forwarder corrections;
the second exposes82 real consumer mismatches. Many are shared async core helpers
and array-typed delegates, not dormant compatibility code. Their inputs can live
through callbacks, constructors or cache/descriptor work. Merely wrapping them in
new ToArray/clearing adapters relocates the phase rather than completing the desired
removal. A coupled migration must consume inputs into actual prepared state before
suspension and preserve its retained ownership. No new owned-callable hierarchy or
generic dispatch/arena framework is selected to hide this work.

This source gate does not establish a failed performance design: there is no valid
candidate, semantic qualification, allocation observation or timing. Compiler errors
show scope/ownership constraints, not a speed result or permanent architectural veto.
Current text call-entry4.29% samples alone do not justify the repo-wide rewrite.
[Decision and guarded source identities](decision.json).

Continue with the existing constructor CSV source. Its ordinary __init__ stores an
instance field, requiring context promotion and first attribute-capacity growth.
Assess that actual per-record construction boundary while preserving the canonical
constructor/initializer selection and real dynamic protocols. No repeat profile or
new benchmark framework follows from this signature-only gate.

All original/partial source, exact patch, compiler errors/corrections, restoration
build, commands and focused outputs survive in [preparation](preparation.tar.xz),
verified by [archive identity](archive-identity.json). The partial source is private
evidence, not an alternate backend or build option. Publication postponed.
''',encoding='utf-8',newline='\n')
print('R231 source gate archived; all original source restored, no timing claim.')
