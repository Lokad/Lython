from pathlib import Path
import json,os,subprocess,xml.etree.ElementTree as ET
r=Path(__file__).parent;dotnet='C:/Users/JoannesVermorel/.dotnet11/dotnet.exe'
env=os.environ.copy();env['DOTNET_ROOT']=str(Path(dotnet).parent);env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+env['PATH']
checks={}
for framework in ['net11.0','net10.0']:
 name='restored-'+framework;trx=name+'.trx'
 cmd=[dotnet,'test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f',framework,'--no-build','--no-restore','--filter','(FullyQualifiedName~CallInputLifetimeTests|FullyQualifiedName~FunctionDefaultMetadataTests|FullyQualifiedName~NamedFunctionBindingTests|FullyQualifiedName~ExecutableCallLifetimeTests)&Category!=Stress','--logger','trx;LogFileName='+trx,'--results-directory',str(r/'tests')]
 with(r/(name+'.log')).open('wb')as log:done=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 counts=ET.parse(r/'tests'/trx).find('.//{*}Counters').attrib
 checks[name]=dict(command=cmd,exitCode=done.returncode,counts=counts)
 (r/'restored-checks.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8')
 print(name,counts,flush=True);assert done.returncode==0 and counts['failed']=='0'
