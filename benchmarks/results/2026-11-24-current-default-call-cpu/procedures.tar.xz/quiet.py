from pathlib import Path
import datetime
import hashlib
import io
import json
import os
import shlex
import subprocess
import sys
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
host="lokad@20.166.121.73"
root="/home/lokad/lython-bench-checks/current-default-call-cpu-b1657-20261124"
unit="lython-b1657-current-default-call-cpu-20261124"
ssh_options=["-i",str(Path.home()/".ssh/id_lython-bench.pem"),"-o","BatchMode=yes","-o","ConnectTimeout=14"]
ssh=["C:/Windows/System32/OpenSSH/ssh.exe",*ssh_options,host]
scp=["C:/Windows/System32/OpenSSH/scp.exe",*ssh_options]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc)

if sys.argv[1]=="launch":
    proof=json.loads((lab/"identity.json").read_text(encoding="utf-8"))
    python_worker=repo/"benchmarks/cpython-worker.py"
    assert sha(python_worker)==proof["cpythonWorkerSHA256"]
    sdk=Path.home()/".dotnet11"
    dotnet=sdk/"dotnet.exe"
    catalog=lab/"catalog.json"
    for role, expected in proof['imageFiles'].items():
        image=lab.parent/'inline-positional-default-20261124'/role
        assert len(expected)==32 and {p.name:sha(p) for p in image.iterdir()}==expected
        verification=lab/(role+"-verification.json")
        checked=json.loads(verification.read_text(encoding="utf-8"))
        assert checked["state"]=="Completed" and checked["caseCount"]==5 and checked["catalogSha256"]==sha(catalog)
        assert checked["launched"]["library"]["sha256"]==expected["Lokad.Lython.dll"]
        assert {p.name:sha(p) for p in image.iterdir()}==expected
    archived=io.BytesIO()
    with tarfile.open(fileobj=archived,mode="w:gz") as target:
        for name in ("catalog.json","identity.json","candidate-verification.json","ops-profile.py","collect.py","run.sh"):
            target.add(lab/name,arcname=name,recursive=False)
    assert b"\r" not in (lab/"run.sh").read_bytes()
    data=archived.getvalue()
    (lab/"payload.tgz").write_bytes(data)
    duplicates=json.loads((lab/"verified-raw-replicas.json").read_text(encoding="utf-8"))
    staging=f"""
from pathlib import Path
import fcntl,hashlib,io,json,shutil,subprocess,sys,tarfile
root=Path({root!r})
bundle=sys.stdin.buffer.read()
assert hashlib.sha256(bundle).hexdigest()=={hashlib.sha256(data).hexdigest()!r}
with (root.parent/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 free = shutil.disk_usage(root.parent).free
 assert not root.exists()
 plans=[]; available=free
 for row in {duplicates!r}:
  if available>=4*1024*1024:break
  prior=root.parent/row['location']
  raw=prior/'confirmation/confirmation.json'
  archive=prior/'observations.tar.xz'
  marker=prior/'archive-receipt.json'
  if not raw.is_file():continue
  assert raw.resolve()==raw and raw.is_relative_to(root.parent) and raw.stat().st_nlink==1
  if (prior/'guest-fixtures').exists() or not marker.is_file():continue
  info=json.loads(marker.read_text())
  if not info.get('allWorkersJoined') or not info.get('archivedAndVerifiedUnderLease'):continue
  if raw.stat().st_size!=row['bytes'] or not archive.is_file():continue
  sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
  if sha(archive)!=row['archiveSHA256'] or sha(raw)!=row['rawSHA256']:continue
  plans.append((row,raw))
  available+=raw.stat().st_blocks*512
 assert available>=4*1024*1024,(free,available)
 for _,raw in plans:raw.unlink()
 custody=dict(freeBefore=free,verifiedDuplicates=[row for row,_ in plans],freeAfter=shutil.disk_usage(root.parent).free)
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(bundle)) as archive:
  assert set(archive.getnames())=={{'catalog.json','identity.json','candidate-verification.json','ops-profile.py','collect.py','run.sh'}}
  archive.extractall(root,filter='data')
 (root/'storage-custody.json').write_text(json.dumps(custody,indent=2))
print('Staged three profiles',root,flush=True)
subprocess.run(['sudo','-n','systemd-run','--unit={unit}','--property=User=lokad','--property=WorkingDirectory='+str(root),
 '--property=RuntimeMaxSec=125','--property=TimeoutStopSec=20','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
"""
    result=subprocess.run(ssh+["python3 -c "+shlex.quote(staging)],input=data,capture_output=True,timeout=30)
    (lab/"launch.log").write_bytes(result.stdout+result.stderr)
    print((result.stdout+result.stderr).decode(),end="")
    result.check_returncode()
    (lab/"observe-not-before").write_text((now()+datetime.timedelta(seconds=87)).isoformat(),encoding="utf-8")
else:
    assert sys.argv[1]=="retrieve"
    assert now()>=datetime.datetime.fromisoformat((lab/"observe-not-before").read_text(encoding="utf-8"))
    state=f"""
from pathlib import Path
import fcntl,json,subprocess
root=Path({root!r})
service=subprocess.run(['systemctl','show','{unit}.service','--property=ActiveState,Result,MainPID,ExecMainStatus'],capture_output=True,text=True).stdout
if 'ActiveState=active' in service:
 print(json.dumps(dict(live=True,service=service)))
else:
 with (root.parent/'comparison-vm.lock').open('a') as lease:
  fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
  read=lambda name: (root/name).read_text().strip() if (root/name).exists() else None
  print(json.dumps(dict(live=False,service=service,exitCode=read('exit-code.txt'),receipt=json.loads(read('archive-receipt.json') or 'null'),
        fixtures=(root/'guest-fixtures').exists(),
        journal=subprocess.run(['journalctl','-u','{unit}.service','-n','32','--no-pager'],capture_output=True,text=True).stdout)))
"""
    fetched=subprocess.check_output(ssh+["python3 -c "+shlex.quote(state)],encoding="utf-8",timeout=25)
    report=json.loads(fetched)
    (lab/("status-"+now().strftime("%H%M%S")+".json")).write_text(fetched,encoding="utf-8")
    print(fetched,end="")
    if not report["live"] and report["receipt"] is not None:
        archive=lab/"observations.tar.xz"
        subprocess.run(scp+[host+":"+root+"/observations.tar.xz",archive],check=True,timeout=35)
        assert sha(archive)==report["receipt"]["archiveSHA256"]
        (lab/"terminal-status.json").write_text(fetched,encoding="utf-8")
        assert report["exitCode"]=="0" and report["receipt"]["complete"] and not report["fixtures"]
