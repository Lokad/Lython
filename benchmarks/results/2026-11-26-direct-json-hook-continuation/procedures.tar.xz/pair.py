import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
from statistics import median

lab = Path(__file__).resolve().parent
probe = lab / 'probe/bin/Release/net11.0'
inputs = {
    'before': lab.parent / 'affix-text-attribution-20261126/candidate-tape/Lokad.Lython.dll',
    'after': Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'),
}
identity = json.loads((lab.parent / 'affix-text-attribution-20261126/comparison/quiet/identity.json').read_text(encoding='utf-8'))
def sha(file):
    return hashlib.sha256(file.read_bytes()).hexdigest()
assert sha(inputs['before']) == identity['coreSHA256']['candidate']
files = ['Probe.dll', 'Probe.deps.json', 'Probe.runtimeconfig.json', 'Lokad.Lython.dll']
hashes = {}
for image, source in inputs.items():
    target = lab / image
    target.mkdir(exist_ok=True)
    for file in files:
        file_source = source if file == 'Lokad.Lython.dll' else probe / file
        shutil.copyfile(file_source, target / file)
        assert sha(file_source) == sha(target / file)
    hashes[image] = {file: sha(target / file) for file in files}
assert hashes['before']['Lokad.Lython.dll'] != hashes['after']['Lokad.Lython.dll']
(dotnet := Path(os.environ['DOTNET_ROOT']) / 'dotnet.exe').stat()
results = []
with (lab / 'observations.jsonl').open('w', encoding='utf-8') as output:
    for workload in ('hooks', 'default'):
        for order in [('before', 'after'), ('after', 'before'), ('before', 'after')]:
            for image in order:
                target = lab / image
                assert all(sha(target / file) == value for file, value in hashes[image].items())
                done = subprocess.run([str(dotnet), str(target / 'Probe.dll'), workload],
                                      capture_output=True, text=True, encoding='utf-8', timeout=40)
                row = {'image': image, 'workload': workload, 'exit': done.returncode,
                       'out': done.stdout.strip(), 'error': done.stderr.strip()}
                print(json.dumps(row), file=output, flush=True)
                done.check_returncode()
                values = json.loads(row['out'])
                assert values['CoreSha256'] == hashes[image]['Lokad.Lython.dll']
                results.append((workload, image, values))
summary = {workload: {image: {field: median(row[field] for w, i, row in results if w == workload and i == image)
                             for field in ('BytesPerRequest', 'PeakBytes', 'ElapsedMilliseconds', 'CpuMilliseconds')}
                      for image in inputs} for workload in ('hooks', 'default')}
assert all(row['Hooks'] == (288 if workload == 'hooks' else 0) for workload, _, row in results)
(lab / 'diagnostic.json').write_text(json.dumps({'images': hashes, 'median': summary}, indent=2) + '\n', encoding='utf-8')
print(json.dumps(summary, indent=2))
