using System.Diagnostics;
using System.Globalization;
using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;

const string prefix = """
    import json
    import time
    def parse(token):
        time.sleep(0.001)
        return int(token) + 1
    def convert(row):
        time.sleep(0.001)
        return row['n'] + 1
    """;
const string suspension = """
    result = 0
    for _ in range(4):
        result += sum(json.loads('[{"n":4},{"n":7},{"n":8}]', parse_int=parse, object_hook=convert))
    return result
    """;
const string control = """
    result = 0
    for _ in range(4):
        result += sum(row['n'] + 2 for row in json.loads('[{"n":4},{"n":7},{"n":8}]'))
    return result
    """;

var workload = args.Single();
var usesHooks = workload switch { "hooks" => true, "default" => false, _ => throw new ArgumentException(workload) };
var budget = new LythonMemoryBudget(4 * 1024 * 1024);
using var code = new LythonEngine().Compile(prefix + "\n" + (usesHooks ? suspension : control), budget);
if (!code.IsValid) throw new InvalidOperationException(string.Join("\n", code.Diagnostics));
var baseline = budget.ReservedBytes;
var host = new ClockHost();
for (var iteration = 0; iteration < (usesHooks ? 4 : 128); iteration++) await Verify();
var callsBefore = host.Delays;
using var process = Process.GetCurrentProcess();
var iterations = usesHooks ? 12 : 512;
var allocationsBefore = GC.GetTotalAllocatedBytes(precise: true);
var cpuBefore = process.TotalProcessorTime;
var started = Stopwatch.GetTimestamp();
for (var iteration = 0; iteration < iterations; iteration++) await Verify();
var elapsed = Stopwatch.GetElapsedTime(started);
var cpu = process.TotalProcessorTime - cpuBefore;
var bytes = GC.GetTotalAllocatedBytes(precise: true) - allocationsBefore;
var calls = host.Delays - callsBefore;
if (calls != (usesHooks ? iterations * 24 : 0)) throw new InvalidOperationException("Unexpected hook count");
code.Dispose();
if (budget.ReservedBytes != 0) throw new InvalidOperationException("Code allowance did not refund");
Console.WriteLine(JsonSerializer.Serialize(new {
    Workload = workload, Iterations = iterations, Hooks = calls,
    BytesPerRequest = bytes / (double)iterations, PeakBytes = budget.PeakBytes, BaselineBytes = baseline,
    ElapsedMilliseconds = elapsed.TotalMilliseconds, CpuMilliseconds = cpu.TotalMilliseconds,
    CoreSha256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))).ToLowerInvariant()
}));

async ValueTask Verify()
{
    using (var result = await code.RunAsync(host))
    {
        if (!result.Success || Convert.ToString(result.ReturnValue, CultureInfo.InvariantCulture) != "100")
            throw new InvalidOperationException(result.Failure?.Message ?? $"Unexpected output {result.ReturnValue}");
    }
    if (budget.ReservedBytes != baseline) throw new InvalidOperationException("Execution allowance did not refund");
}

sealed class ClockHost : ILythonHost, ILythonTiming
{
    private int _delays;
    public int Delays => Volatile.Read(ref _delays);
    public string Cwd => "/";
    public DateTimeOffset LocalNow => DateTimeOffset.UnixEpoch;
    public DateTimeOffset UtcNow => DateTimeOffset.UnixEpoch;
    public ILythonTiming Timing => this;
    public long MonotonicNanoseconds => 0;
    public ValueTask DelayAsync(TimeSpan duration, CancellationToken cancellationToken)
    {
        Interlocked.Increment(ref _delays);
        var operation = Task.Delay(duration, cancellationToken);
        if (operation.IsCompleted) throw new InvalidOperationException("The diagnostic requires a pending host operation");
        return new ValueTask(operation);
    }
    public ValueTask<bool> ExistsAsync(LythonPathRequest path, CancellationToken cancellationToken) => throw Unavailable();
    public ValueTask<IReadOnlyList<string>> ListDirAsync(LythonPathRequest path, CancellationToken cancellationToken) => throw Unavailable();
    public ValueTask MkDirAsync(LythonPathRequest path, CancellationToken cancellationToken) => throw Unavailable();
    public ValueTask RemoveAsync(LythonPathRequest path, CancellationToken cancellationToken) => throw Unavailable();
    public ValueTask CopyAsync(LythonPathRequest source, LythonPathRequest destination, CancellationToken cancellationToken) => throw Unavailable();
    public ValueTask MoveAsync(LythonPathRequest source, LythonPathRequest destination, CancellationToken cancellationToken) => throw Unavailable();
    public ValueTask<LythonPathStat> StatAsync(LythonPathRequest path, CancellationToken cancellationToken) => throw Unavailable();
    private static InvalidOperationException Unavailable() => new("The diagnostic exercises the delay capability only.");
}
