from pathlib import Path
import json

archive = Path("benchmarks/results/2026-11-19-retained-lexical-cpython")
guide = Path("docs/BENCHMARKS.md")
summary = json.loads((archive / "summary.json").read_text(encoding="utf-8"))
names = {
    "scripts.rule-default-closures": "Unannotated rule closures",
    "scripts.captured-rule-closures": "Captured rule closures",
    "scripts.annotated-rule-closures": "Annotated rule closures",
    "scripts.config-generated-guards.medium": "Generated validator",
    "scripts.config-manifest.small": "Configuration manifest",
}
phase = {"warm": "Warm", "compile": "Compilation only", "compile-run": "Compile-to-result"}


def interval(values, digits):
    first, second = (f"{value:.{digits}f}" for value in values)
    return first if first == second else f"{first}–{second}"


def cells(row):
    digits = 5 if row["lane"] == "compile" else 3
    left = interval(row["lythonMs"], digits)
    right = interval(row["cpythonMs"], digits)
    ratio = interval(row["ratio"], 2)
    status = (
        f"B1122 diagnostic. Controls L/C {row['lythonControlPercent']:.2f} / "
        f"{row['cpythonControlPercent']:.2f}%. IQR ≤{row['maxIQRPercent']:.2f}%."
    )
    if row["ratio"][0] <= 1 <= row["ratio"][1]:
        status += " Spans parity."
    if row["lythonControlPercent"] >= 4 or row["cpythonControlPercent"] >= 4:
        status += " Gap size uncertain."
    return f"{left} ms | {right} ms | {ratio}× | {status} |"


sections = guide.read_text(encoding="utf-8").split("## Earlier measured workloads", 1)
assert len(sections) == 2
head, history = sections
for row in summary["rows"]:
    name = names[row["case"]]
    lane = row["lane"]
    candidates = [line for line in head.splitlines() if line.startswith(f"| {name} | ")]
    if lane == "warm":
        candidates = [line for line in candidates if "Compilation only" not in line and "Compile-to-result" not in line]
    else:
        candidates = [line for line in candidates if line.startswith(f"| {name} | {phase[lane]} |")]
    (old,) = candidates
    prefix = " | ".join(old.split(" | ")[:2])
    head = head.replace(old, f"{prefix} | {cells(row)}")

before = head[head.index('B1114 measures '):head.index('[B1106 observations]')]
assert '3e67fd010' in before
source = summary["source"][:9]
core = summary["coreSHA256"][:8]
after = f"""B1122 measures **{source} / frozen {core}** for the three rule scripts
and compiler workloads. B1114 measures the CSV invoice at **2841f6ac2 /
frozen a2ec3ec4**. B1109 measures expanded forwarding and retained
siblings at **3e67fd010 / frozen aa15d342**. B1102 measures inline
forwarding at **80cbf4988 / frozen f26c8272**. B1069 measures the shipment
report at **12fabffb1 / frozen 9b8511fc**.
All ran **2026-11-19 UTC** against stock **CPython 3.13.16** on the quiet
**Azure F4as_v7** with Ubuntu 24.04.4 and .NET 11 RC3. Each collection
uses duplicate processes per engine. Each row describes its measured revision.
[B1122 observations](../benchmarks/results/2026-11-19-retained-lexical-cpython/README.md) ·
[B1114 observations](../benchmarks/results/2026-11-19-retained-return-cpython/README.md) ·
[B1109 history](../benchmarks/results/2026-11-19-retained-factories-cpython/README.md) ·
"""
assert before in head
head = head.replace(before, after)
guide.write_text(head + "## Earlier measured workloads" + history, encoding="utf-8")

table = "\n".join(
    f"| {names[row['case']]} | {phase[row['lane']]} | {cells(row)}"
    for row in summary["rows"]
)
(archive / "README.md").write_text(f"""# B1122 retained rule and compiler workloads against CPython

This diagnostic uses Lython `{source}`, core SHA-256 beginning `{core}`,
and stock CPython 3.13.16. The quiet Azure F4as_v7 ran Ubuntu 24.04.4 with
.NET 11 RC3 on November 19, 2026 UTC. The complete 32-file Lython image
and five CPython workload goldens passed verification before collection.
Ratios divide Lython elapsed by CPython elapsed across all four
combinations of duplicate process medians. Above one means slower.

| Workload | Boundary | Lython | CPython | Ratio | Measurement status |
| --- | --- | ---: | ---: | ---: | --- |
{table}

Warm execution includes mediated RAM-backed I/O, golden checks and
previous-result cleanup. Compilation includes compiled-owner disposal.
Compile-to-result adds compilation and compiled-owner disposal to the
execution boundary. CPython uses its native file APIs. The Lython worker
uses shared accounting and checks the returned allowance. Guest clocks
exclude startup, fixture reset, request framing and final cache teardown.
The wider process CPU and control spreads are preserved in the summary.

All {summary["verifiedBatches"]} timed batches verified in {summary["elapsedSeconds"]:.2f} seconds.
Both quiet gates passed, workers joined, fixtures were removed and the
observation archive was verified under the VM lease.

[Benchmark guide](../../../docs/BENCHMARKS.md) · [Summary](summary.json) ·
[Raw observations](observations.tgz) · [Lease receipt](archive-receipt.json) ·
[Procedures](procedures.tar.xz).
""", encoding="utf-8")
