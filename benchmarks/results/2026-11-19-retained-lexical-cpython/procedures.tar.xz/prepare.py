from pathlib import Path
import ast, hashlib, json, os, shutil, subprocess, tarfile

lab=Path(__file__).resolve().parent
previous=lab.parent/'retained-return-cpython-b1114'
source=lab.parent/'inline-function-binding-r690'
read=lambda p:p.read_text(encoding='utf-8-sig')
load=lambda p:json.loads(read(p))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,text):
    if name.endswith('.py'): ast.parse(text)
    (lab/name).write_text(text,encoding='utf-8',newline='\n')
def save(name,value): write(name,json.dumps(value,indent=2,ensure_ascii=False)+'\n')

pair=load(source/'frozen-identity.json')
revision=pair['referenceCommit']
assert revision.startswith('0d16f8307')
old=load(source/'quiet/config.json')
receipt=load(source/'quiet/archive-receipt.json')
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
assert sha(source/'quiet/observations.tgz')==receipt['archiveSHA256']
files=pair['images']['reference']
assert len(files)==32 and old['identity']['imageFiles']['reference']==files
frozen=lab/'frozen/candidate'
frozen.mkdir(parents=True)
for name,digest in files.items():
    origin=source/'frozen/reference'/name
    assert sha(origin)==digest
    shutil.copyfile(origin,frozen/name)
assert {n:sha(frozen/n) for n in files}==files
core='Lokad.Lython.dll'
save('build-revision.json',dict(sourceRevision=revision,imageSource=revision,coreSHA256=files[core]))

catalog=load(previous/'representative.json')
wanted=('scripts.rule-default-closures','scripts.annotated-rule-closures','scripts.captured-rule-closures')
rules=[c for c in catalog['cases'] if c['id'] in wanted]
prior_rules=[c for c in load(source/'catalog.json')['cases'] if c['id'] in wanted]
assert len(rules)==3 and {c['id']:c['sourceSha256'] for c in rules}=={c['id']:c['sourceSha256'] for c in prior_rules}
frontend=lab.parent/'token-source-transport-r673/catalog.json'
front_names=('scripts.config-generated-guards.medium','scripts.config-manifest.small')
front_cases=[c for c in load(frontend)['cases'] if c['id'] in front_names]
assert len(front_cases)==2
catalog['cases']=rules+front_cases
save('representative.json',catalog)
catalog_hash=sha(lab/'representative.json')
worker=lab/'cpython-worker.py'
shutil.copyfile(previous/'cpython-worker.py',worker)
worker_hash=sha(worker)
assert worker_hash==sha(Path('benchmarks/cpython-worker.py'))==load(previous/'identity.json')['cpythonWorkerSHA256']
identity=dict(sourceRevision=revision,imageSource=revision,purpose='B1122 retained lexical and frontend scripts versus CPython',
    imageFiles={'candidate':files},auxiliaryFiles={name:digest for name,digest in files.items() if name!=core},
    coreSHA256={label:files[core] for label in ('candidate','candidate-control')},catalogSHA256=catalog_hash,
    cpythonWorkerSHA256=worker_hash,normalAdapterPin='0.4.0')
save('identity.json',identity)
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
with (lab/'verify.log').open('wb') as log:
    subprocess.run([dotnet,frozen/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',lab/'representative.json',
        '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',worker,'--out',lab/'verify.json'],
        env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120,check=True)
verification=load(lab/'verify.json')
assert verification['state']=='Completed' and verification['catalogSha256']==catalog_hash
assert {name:sha(frozen/name) for name in files}==files

before=load(previous/'config.json')
root='/home/lokad/lython-bench-checks/retained-lexical-cpython-b1122-20261119'
unit='lython-b1122-retained-lexical-cpython-20261119'
jobs=[(case['id'],False) for case in catalog['cases']]
for name in ('collect.py','archive-owned.py','launch.py','retrieve.py','run.sh'):
    text=read(previous/name).replace(before['root'],root).replace('B1114','B1122')
    if name=='collect.py':
        a=text.index('    for case_id,diagnostic in ')
        b=text.index('\n',a)
        text=text[:a]+f'    for case_id,diagnostic in {jobs!r}:'+text[b:]
        phase='        lanes = ["warm", "compile-run", "compile"]'
        assert text.count(phase)==1
        text=text.replace(phase,phase+f' if case_id in {wanted!r} else ["compile-run", "compile"]')
    elif name=='archive-owned.py':
        text=text.replace("len(raw['jobs'])==4","len(raw['jobs'])==5").replace('jobs=4,','jobs=5,')
        assert "len(raw['jobs'])==5" in text and 'jobs=5,' in text
    elif name=='retrieve.py':
        text=text.replace("['jobs']==4","['jobs']==5")
        assert "['jobs']==5" in text
    elif name=='launch.py':
        text=text.replace('315','325')
        assert 'timedelta(seconds=325)' in text
    write(name,text)

names=('representative.json','identity.json','collect.py','archive-owned.py','run.sh','cpython-worker.py')
payload=lab/'payload.tgz'
with tarfile.open(payload,'w:gz') as archive:
    for name in names: archive.add(lab/name,arcname=name)
config=dict(root=root,unit=unit,source=old['root'],sourceRole='reference',sourceFiles=files,
      sourceCatalogSHA256=old['catalogSHA256'],catalogSHA256=catalog_hash,identity=identity,retireGroups=[],
      donorArchiveSHA256=receipt['archiveSHA256'],payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),
      unpackedBytes=sum((lab/name).stat().st_size for name in names),cpythonWorkerSHA256=worker_hash)
save('config.json',config)
launcher=read(previous/'remote-launch.py')
a,b=launcher.index('\nc=')+1,launcher.index('\nb=Path(')
launcher=launcher[:a]+'c='+repr(config)+launcher[b:]
write('remote-launch.py',launcher.replace('lython-b1114-fixtures','lython-b1122-fixtures'))
print('Verified 32 image files and five CPython goldens for the retained source.')