$lab='.git/agent-notes/review-20261031/generator-only-dispatch-b1993-20261128'
$sdk=Join-Path $env:USERPROFILE '.dotnet11/dotnet.exe'
$filter='Category!=Stress&(FullyQualifiedName~Generator|FullyQualifiedName~StarmapMaterializationParity|FullyQualifiedName~NativeCallbackArguments|FullyQualifiedName~ReceiverFunctionEntry|FullyQualifiedName~NamedFunctionBinding|FullyQualifiedName~OrdinaryFunctionCall|FullyQualifiedName~FunctionBindingLifetime|FullyQualifiedName~MethodBodyCompilationBoundary|FullyQualifiedName~ExecutionThread|FullyQualifiedName~NativeConditionalHelper|FullyQualifiedName~ConstructorLifetime|FullyQualifiedName~CompilerCancellation|FullyQualifiedName~AdmissionFailureCommand)'
foreach ($tfm in 'net11.0','net10.0') {
  foreach ($suite in 'Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests') {
    $log="$lab/windows-$suite-$tfm.log"
    & $sdk test "tests/$suite/$suite.csproj" -c Release -f $tfm --filter $filter *> $log
    $code=$LASTEXITCODE
    if ($code -ne 0) { Get-Content $log -Encoding utf8 -Tail 60; exit $code }
    Get-Content $log -Encoding utf8 -Tail 2
  }
}
