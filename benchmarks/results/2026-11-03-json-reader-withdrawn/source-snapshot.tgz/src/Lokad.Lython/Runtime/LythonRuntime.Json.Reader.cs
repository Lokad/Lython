using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    private sealed partial class JsonModule
    {
        private enum JsonContainerKind { None, Array, Object, Pairs }

        private struct JsonReadFrame
        {
            internal JsonContainerKind Kind;
            internal object? Container;
            internal PyString? Key;
            internal PyString[]? ExpectedKeys;
            internal bool MatchedKeys;
            internal int OpenByte;
            internal int ValueEnd;
        }

        // One invocation owns the traversal and its suspended callbacks. Ordinary
        // children stay in this loop; only nesting needs admitted parent storage.
        private async ValueTask<(object Value, int End)> ReadJsonValueExactAsync(PyString input,
            JsonLoadOptions options, ExecutionContext context, LythonSourceSpan span, int position, bool asynchronous)
        {
            var bytes = input.Utf8Bytes;
            JsonReadFrame current = default;
            JsonReadFrame[]? parents = null;
            var parentCount = 0;
            MemoryGovernor.TemporaryMemoryReservation? parentStorage = null;
            var needValue = true;
            try
            {
                while (true)
                {
                    context.CheckExecution(span);
                    (object Value, int End) decoded;
                    if (needValue)
                    {
                        if (position < bytes.Length && bytes.Span[position] is (byte)'{' or (byte)'[')
                        {
                            var array = bytes.Span[position] == (byte)'[';
                            var depth = current.Kind == JsonContainerKind.None ? 0 : parentCount + 1;
                            if (depth >= 64) throw CreateJsonDepthError(input, position, array, span, context);
                            if (current.Kind != JsonContainerKind.None)
                            {
                                PushJsonParent(current, ref parents, ref parentCount, ref parentStorage, context, span);
                            }
                            var kind = array ? JsonContainerKind.Array
                                : options.ObjectPairsHook is null ? JsonContainerKind.Object : JsonContainerKind.Pairs;
                            current = new JsonReadFrame
                            {
                                Kind = kind,
                                Container = kind == JsonContainerKind.Object
                                    ? new PyDict(context.MemoryGovernor, span)
                                    : new PyList([], context.MemoryGovernor, span),
                                ExpectedKeys = array ? null : context.State.JsonRecordKeys,
                                MatchedKeys = true,
                                OpenByte = position,
                                ValueEnd = -1,
                            };
                            needValue = false;
                            continue;
                        }
                        var scalar = ReadJsonScalarAsync(input, options, context, span, position, asynchronous);
                        decoded = scalar.IsCompleted ? scalar.GetAwaiter().GetResult()
                            : await scalar.ConfigureAwait(false);
                    }
                    else
                    {
                        var array = current.Kind == JsonContainerKind.Array;
                        var close = array ? (byte)']' : (byte)'}';
                        var peek = SkipJsonWhitespace(bytes.Span,
                            current.ValueEnd < 0 ? current.OpenByte + 1 : current.ValueEnd, context, span);
                        if (peek < bytes.Length && bytes.Span[peek] == close)
                        {
                            if (!array) RememberJsonContainerKeys(current, context, span);
                            var value = current.Container!;
                            var hook = current.Kind == JsonContainerKind.Pairs ? options.ObjectPairsHook
                                : current.Kind == JsonContainerKind.Object ? options.ObjectHook : null;
                            if (hook is not null)
                            {
                                var callback = InvokeJsonCallbackCoreAsync(hook, value, context, span, asynchronous);
                                value = callback.IsCompleted ? callback.GetAwaiter().GetResult()
                                    : await callback.ConfigureAwait(false);
                            }
                            decoded = (value, peek + 1);
                            if (parentCount == 0) current = default;
                            else
                            {
                                current = parents![--parentCount];
                                parents[parentCount] = default;
                            }
                        }
                        else
                        {
                            if (current.ValueEnd >= 0)
                            {
                                var comma = EnsureJsonComma(bytes.Span, current.ValueEnd, input, span, context);
                                peek = SkipJsonWhitespace(bytes.Span, comma + 1, context, span);
                                if (peek < bytes.Length && bytes.Span[peek] == close)
                                    throw NewJsonDecodeFailure(input, array
                                        ? "Illegal trailing comma before end of array"
                                        : "Illegal trailing comma before end of object", comma, null, span, context);
                            }
                            if (!array)
                            {
                                if (peek >= bytes.Length || bytes.Span[peek] != (byte)'"')
                                    throw CreateJsonExpectingError(input, Math.Min(peek, bytes.Length),
                                        JsonIncompleteExpectation.PropertyName, span, context);
                                var key = ReadJsonObjectKey(input, options, peek, context, span, current.ExpectedKeys!);
                                current.Key = key.Value;
                                current.MatchedKeys &= key.Reused;
                                var colon = EnsureJsonColon(bytes.Span, key.End, input, span, context);
                                peek = SkipJsonWhitespace(bytes.Span, colon + 1, context, span);
                            }
                            position = peek;
                            needValue = true;
                            continue;
                        }
                    }

                    if (current.Kind == JsonContainerKind.None) return decoded;
                    switch (current.Kind)
                    {
                        case JsonContainerKind.Array:
                            ((PyList)current.Container!).Add(decoded.Value);
                            break;
                        case JsonContainerKind.Pairs:
                            var pair = PyTuple.FromOwnedArray([current.Key!, decoded.Value], context.MemoryGovernor, span);
                            ((PyList)current.Container!).Add(pair);
                            break;
                        default:
                            ((PyDict)current.Container!).SetItem(current.Key!, decoded.Value);
                            break;
                    }
                    current.Key = null;
                    current.ValueEnd = decoded.End;
                    context.CheckExecution(span);
                    needValue = false;
                }
            }
            finally
            {
                // Callback users have completed before this finally runs. Drop
                // private references before returning their working allowance.
                current = default;
                if (parents is not null) Array.Clear(parents);
                parentStorage?.Dispose();
            }
        }

        private static void RememberJsonContainerKeys(JsonReadFrame frame, ExecutionContext context, LythonSourceSpan span)
        {
            var expected = frame.ExpectedKeys!;
            if (frame.Kind == JsonContainerKind.Pairs)
            {
                var pairs = (PyList)frame.Container!;
                if (frame.MatchedKeys && pairs.Count == expected.Length) context.State.JsonRecordKeys = expected;
                else context.State.RememberJsonRecordKeys(JsonPairKeys(pairs), pairs.Count, span);
            }
            else
            {
                var dictionary = (PyDict)frame.Container!;
                if (frame.MatchedKeys && dictionary.Count == expected.Length) context.State.JsonRecordKeys = expected;
                else context.State.RememberJsonRecordKeys(dictionary.Keys, dictionary.Count, span);
            }
        }

        private static void PushJsonParent(JsonReadFrame current, ref JsonReadFrame[]? parents,
            ref int count, ref MemoryGovernor.TemporaryMemoryReservation? storage,
            ExecutionContext context, LythonSourceSpan span)
        {
            if (parents is null || count == parents.Length)
            {
                var oldCapacity = parents?.Length ?? 0;
                var capacity = oldCapacity == 0 ? 4 : checked(oldCapacity * 2);
                // Conservative reference/metadata capacity, including replacement
                // overlap. No guest values are staged outside their final container.
                var charge = 32L + 128L * capacity;
                if (storage is null) storage = context.MemoryGovernor.ReserveTemporary(charge, span);
                else storage.Grow(charge, span);
                var replacement = new JsonReadFrame[capacity];
                if (parents is not null)
                {
                    parents.AsSpan(0, count).CopyTo(replacement);
                    Array.Clear(parents);
                    storage.Shrink(32L + 128L * oldCapacity);
                }
                parents = replacement;
            }
            parents[count++] = current;
        }
    }
}
