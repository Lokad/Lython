from hashlib import sha256
from pathlib import Path
from shutil import copy2
from subprocess import check_output
import json
import re
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
bench = lab / 'comparison'
out = repo / 'benchmarks/results/2026-11-28-private-generator-lookup-storage'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
identity = read(bench / 'identity.json')
assert identity['sourceRevision'].startswith('68ee4b4db')
patch = lab / 'candidate.patch'
assert check_output(['git', 'diff', '--binary', identity['sourceRevision'], '--', 'src/Lokad.Lython', 'tests'], cwd=repo) == patch.read_bytes()
assert digest(patch) == identity['sourcePatchSHA256']
for role, expected in identity['imageFiles'].items():
    assert len(expected) == 32 and {p.name:digest(p) for p in (bench/role).iterdir()} == expected
assert {n for n, checksum in identity['imageFiles']['reference'].items() if identity['imageFiles']['candidate'][n] != checksum} == {'Lokad.Lython.dll'}
summary = read(bench / 'summary.json')
assert summary['verifiedTimedBatches'] == 168 and len(summary['rows']) == 6
receipt = read(bench/'archive-receipt.json')
assert receipt['archiveSHA256'] == digest(bench/'observations.tar.xz')
assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
alloc = read(lab/'allocation/summary.json')
assert len(alloc) == 8 and all(row['compiled'][0] == row['compiled'][1] for row in alloc)
for row in alloc:
    assert row['admittedPeak'][0] - row['admittedPeak'][1] in (0, 32)
    if row['case'].endswith('row-generator-reduction'):
        assert 98_200 <= row['clr'][0] - row['clr'][1] <= 98_300
    elif row['case'].endswith('row-range-generator-reduction'):
        assert 147_350 <= row['clr'][0] - row['clr'][1] <= 147_450
    else:
        assert abs(row['clr'][0] - row['clr'][1]) <= 56
logs = sorted(lab.glob('*-Lokad.Lython.*Tests-net*.log'))
assert len(logs) == 6
for log in logs:
    count = 742 if 'PublicApi' in log.name else 211
    assert re.search(rf'Failed: +0, Passed: +{count}, Skipped: +0', log.read_text(encoding='utf-8-sig')), log
layouts = {}
for role in identity['imageFiles']:
    observed = read(lab/f'layout/{role}.json')
    assert observed['core'] == identity['imageFiles'][role]['Lokad.Lython.dll']
    assert observed['catalog'] == identity['catalogs']['representative.json']['sha256']
    layouts[role] = {x['id']: x['layouts'] for x in observed['observations']}
for case, reference in layouts['reference'].items():
    final = layouts['candidate'][case]
    assert [x['opcodes'] for x in reference] == [x['opcodes'] for x in final]
    if case.endswith(('row-generator-reduction', 'row-range-generator-reduction')):
        assert final[1]['lookupCount'] == reference[1]['lookupCount'] + final[2]['lookupCount']
        assert final[2]['recordLookupsOnly'] and final[1]['generatorOperands'][0]['sharedLookupStart'] == reference[1]['lookupCount']
    else:
        assert [x['lookupCount'] for x in reference] == [x['lookupCount'] for x in final]
out.mkdir(exist_ok=True)
(out/'lookup-layout.json').write_text(json.dumps(layouts,indent=2)+'\n',encoding='utf-8',newline='\n')
artifacts = {name:bench/name for name in ('identity.json','summary.json','observations.tar.xz','archive-receipt.json')}
artifacts['allocation.json'] = lab/'allocation/summary.json'
for name, source in artifacts.items():
    copy2(source,out/name)
    assert digest(out/name) == digest(source)
procedures = {p.name:p for p in logs}
for name in ('candidate.patch','freeze.py','test-ubuntu.sh','test-windows.ps1','ubuntu-core-build.log','summarize.py','measure-allocation.py','publish.py'):
    procedures[name] = lab/name
for name in ('collection.log','reference-verify.json','candidate-verify.json','exit-code.txt'):
    procedures[name] = bench/name
for p in (lab/'allocation').glob('*.json'):
    procedures[f'allocation/{p.name}'] = p
for name in ('InspectLayout.csproj','Program.cs','build.log','reference.json','candidate.json'):
    procedures[f'layout/{name}'] = lab/'layout'/name
with tarfile.open(out/'procedures.tar.xz','w:xz') as archive:
    for name, path in procedures.items(): archive.add(path, arcname=name)
with tarfile.open(out/'procedures.tar.xz') as archive:
    assert all(digest(path) == sha256(archive.extractfile(name).read()).hexdigest() for name,path in procedures.items())
print('Private generator lookup source, result files and procedures verified.')
