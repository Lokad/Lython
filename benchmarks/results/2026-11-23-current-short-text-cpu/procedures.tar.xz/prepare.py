from pathlib import Path
import hashlib
import json
import shutil
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
old = lab.with_name('retained-short-text-cpu-20261123')
donor = lab.with_name('combined-cased-split-cpython-20261123')
archive = 'benchmarks/results/2026-11-23-combined-cased-split-cpython/'


def tracked(name):
    return subprocess.check_output(['git', 'show', 'origin/master:' + archive + name], cwd=repo)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write(name, data):
    (lab / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')


def adapt(name, edits):
    src = (old / name).read_text(encoding='utf-8')
    for before, after in edits:
        assert src.count(before) == 1, (name, before)
        src = src.replace(before, after)
    compile(src, str(lab / name), 'exec')
    (lab / name).write_text(src, encoding='utf-8', newline='\n')


identity = json.loads(tracked('identity.json'))
receipt = json.loads(tracked('terminal-status.json'))['receipt']
assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['archivedAndVerifiedUnderLease']
assert sha(tracked('observations.tar.xz')) == receipt['archiveSHA256']
assert not subprocess.check_output(['git', 'diff', '--name-only', identity['sourceRevision'],
                                    'origin/master', '--', 'src', 'tests'], cwd=repo)
catalog = json.loads((lab.with_name('short-text-boundaries-20261123') / 'catalog.json').read_text(encoding='utf-8'))
short, _, inline, *_ = catalog['cases']
assert short['id'] == 'diagnostic.text-summary.nonlocal-computed-width.large'
assert inline['id'] == 'diagnostic.text-summary.without-per-line-helper'
for key in ('fixtureSha256', 'expectedOutputSha256', 'expectedFilesSha256'):
    assert short[key] == inline[key]
catalog['cases'] = [short, inline]
write('catalog.json', catalog)
identity.update(purpose='B1540 identify remaining short report CPU costs after marked cased-split dispatch',
                donorArchiveSHA256=receipt['archiveSHA256'], profileCatalogSHA256=sha((lab / 'catalog.json').read_bytes()))
write('identity.json', identity)
adapt('ops-profile.py', (
    ("[('nonlocal-warm', 'diagnostic.text-summary.nonlocal-computed-width.large', 'warm'), ('mixed-width-warm', 'diagnostic.text-summary.borrowed-cased-words.mixed-width', 'warm'), ('nonlocal-compile-run', 'diagnostic.text-summary.nonlocal-computed-width.large', 'compile-run')]",
     "[('nonlocal-warm', 'diagnostic.text-summary.nonlocal-computed-width.large', 'warm'), ('inline-warm', 'diagnostic.text-summary.without-per-line-helper', 'warm')]"),
    ('batches=[];deadline=time.monotonic()+5', 'batches=[];deadline=time.monotonic()+6'),
    ("assert record[\"identity\"][\"catalogSha256\"] == hashlib.sha256(catalog.read_bytes()).hexdigest()",
     "assert record[\"identity\"][\"catalogSha256\"] == expected_image['profileCatalogSHA256'] == hashlib.sha256(catalog.read_bytes()).hexdigest()"),
))
adapt('collect.py', (
    ('short-text-source-pair-b1487-20261123/candidate', 'combined-cased-split-cpython-b1539-20261123/candidate'),
    ('assert shutil.disk_usage(root).free >= 128*1024*1024',
     "assert shutil.disk_usage(root).free >= 10*1024*1024\n    assert digest(image.parent/'observations.tar.xz') == json.loads((root/'identity.json').read_text())['donorArchiveSHA256']"),
    ('b1488-fixtures', 'b1540-fixtures'),
))
adapt('quiet.py', (
    ('retained-short-text-cpu-b1488-20261123-confirmation', 'current-short-text-cpu-b1540-20261123'),
    ('lython-b1488-retained-short-text-cpu-20261123-confirmation', 'lython-b1540-current-short-text-cpu-20261123'),
    ('short-text-source-pair-20261123/candidate', 'combined-cased-split-cpython-20261123/candidate'),
    ('checked["caseCount"]==3', 'checked["caseCount"]==2'),
    ('>= 128*1024*1024', '>= 11*1024*1024'),
    ('RuntimeMaxSec=125', 'RuntimeMaxSec=100'),
    ('seconds=83', 'seconds=63'),
    ('Staged immutable short and mixed-width text inputs', 'Staged the two exact short text source shapes'),
))
adapt('analyze.py', (
    ("['nonlocal-warm', 'mixed-width-warm', 'nonlocal-compile-run']", "['nonlocal-warm', 'inline-warm']"),
))
shutil.copyfile(old / 'run.sh', lab / 'run.sh')
assert b'\r' not in (lab / 'run.sh').read_bytes()
