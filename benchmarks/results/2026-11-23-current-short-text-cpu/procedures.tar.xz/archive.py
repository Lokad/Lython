from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
dest = repo / 'benchmarks/results/2026-11-23-current-short-text-cpu'


def read(name):
    return json.loads((lab / name).read_text(encoding='utf-8'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


report = read('terminal-status.json')
receipt = report['receipt']
assert report['exitCode'] == '0' and not report['live'] and not report['fixtures']
assert all(receipt[key] for key in ('complete', 'quietBeforeAndAfter', 'allWorkersJoined', 'guestFixturesRemoved', 'archivedAndVerifiedUnderLease'))
assert sha(lab / 'observations.tar.xz') == receipt['archiveSHA256']
assert sha(lab / 'catalog.json') == read('identity.json')['profileCatalogSHA256']
assert [row['label'] for row in read('attribution.json')['rows']] == ['nonlocal-warm', 'inline-warm']
assert {row['invocations'] for row in read('attribution.json')['rows']} == {4608, 6400}
dest.mkdir(exist_ok=True)
assert all(path.name == 'README.md' for path in dest.iterdir())
for name in ('observations.tar.xz', 'identity.json', 'terminal-status.json', 'attribution.json'):
    shutil.copyfile(lab / name, dest / name)
with tarfile.open(dest / 'procedures.tar.xz', 'w:xz') as bundle:
    for name in ('archive.py', 'prepare.py', 'analyze.py', 'quiet.py', 'analysis.log', 'launch.log'):
        bundle.add(lab / name, arcname=name)
print(dest)
