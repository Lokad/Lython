# Lokad.Lython 0.11.0

Updated2026-11-09 (Paris). Git-ignored: never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Current contracts: docs. Historical source pairs, variants, adverse/failed conditions
and receipts: [experimental history](benchmarks/EXPERIMENTS.md) and immutable results.
An isolated experiment does not complete this objective.

## Delivery and measurement status

- **Fully qualified foundations:** R119–R121 runtime6f76/coreC617 +typed-fixture d97,
  cachedCI42527042378; R125 text-read borrow/awaited cleanup3109/core004e,
  cachedCI42536319061; R126 obsolete CLR-liveness fences9f2e/core85e,
  cachedCI42538659198. Preserve their correctness fixes. Full Windows/Ubuntu actual
  11/10, original stress both and installed-core consumers pass; no unchanged replay.
- **Fully qualified R127:** 8472935f/coreac6b, shared declaration signature/generator
  facts, no role arrays/per-shape maps/body rescans/synthetic lowered-name wrappers.
  CachedCI42543394041success. Actual compileallocation−.10..−.32%, warm neutral;
  CPU mixed/possible small CSV debt. [Evidence](benchmarks/results/2026-11-09-declaration-metadata/README.md).
- **Fully qualified R129:** 459813a3/core1be2, source-span literal/body decoding,
  lazy concatenation/parts, synthetic f-string delimiters removed. CachedCI42545629905
  success: fullplatform/actual11+10/originalstressboth/installedcore. Compileallocation
  −2.94..−9.89%, bounded configcompile elapsed−3.66..−4.79%, completeconfig−1.08..−3.35%,
  supportingCPU. Warmtext~+1%possible debt; original adverse desktop timings retained.
  [Evidence](benchmarks/results/2026-11-09-literal-construction/README.md).
- **Committed R132, candidate delivery running:** c343687b/frozen95fc. Native helper
  consumed constants/locals share ordinary operand sources; removed read nodes and
  recursive leaf dispatch/private index plumbing; fixed local prefix published once.
  Wanted3→1/words2→1/charge9→4 nodes; ordinary instructions/prefix counts identical.
  Each real variant4f7/3afe/95fc passes87internal/394public peractual11/10; no tests,
  assertions or timeouts changed. Compileallocation small reductions, report+.014%;
  warmwithin.038%. B492/B493 sixjobs each~170s, allgates/archive/localpass. Final
  syncsearch elapsed−2.45..−3.40%with close controls; CPU not consistently supportive.
  TextCPU0..+5.35%possible debt, report/numeric/asynccontrol spread up5.53%; no universal
  gain/neutrality claim. Retain shared representation with debt explicit, no unchanged
  retiming selected. CI42552506089 dispatched02:43:42UTC; observation02:55:24UTC: both platform builds pass, tests running; next>=03:00:24UTC.
  [Evidence](benchmarks/results/2026-11-09-native-inputs/README.md).
- **Earlier completed work preserved:** shared compiler-fact correction, directUTF8
  formatting/storage, native helper returns, primitive result facts, native JSON,
  record adoption/capacity and execution-owned flat lookup facts. Native-return
  allocation−19.92/−19.31% established, original elapsed diagnostic, delivered source
  fully qualified. Formatting allocation−8.67%, controlledB102elapsed/CPU−5–8% supports
  retention; original adverse15.125ms unexplained/preserved. No replay or additive gains.
- **Held R124:** prepared named maps/defaults added registry/guard while general
  binding remained; compileallocation+.20–.25%, no stable CPU gain. Prototype/adverse
  data retained, production restored with fresh builds; useful semantic/lifetime cases
  retained. Slower arena/call-control designs remain evidence, not permanent bans.

## Representative comparisons and source gates completed

[Maintained CPython guide](docs/BENCHMARKS.md): every row names source6f76 or4598.
R122/B481 primary five source6f76: compile-to-result validatedCSV1.17x, CSV1.01–1.03x
variable, text1.52–1.53x, JSON.91–.96xvariable, report1.32–1.33x versusCPython3.13.16.
R130/B490 refreshed stale source459 config/search/manifest: complete1.09–1.10xVariable
(IQR3.95%),1.40–1.41x,1.47–1.48x; warm1.26–1.27/1.69–1.71/1.56–1.59x; compile
1.08–1.09/.96–.97/1.25–1.27x. Manifest has two small files, not large-tree throughput.
No later-HEAD relabeling or unchanged main-five replay. Compile/warm separate;
mediated RAM-file I/O/full validation/prior-result cleanup included, startup/reset/
protocol/final cached teardown excluded. ProcessCPU includes wider reset/protocol.
Startup/pending I/O/RSS/embedding tails unmeasured. All B490 users/RAM/archive gates pass.

R128/B488 compile attribution: parsing26–43%, abstract19–29%, executable~19%, lexical
7–8%, lowering2–4%; unknown/inlining limits explicit. No single duplicate phase
supports a general rewrite. R129 removes actual literal staging. R131/B491 current
config/search separates guest/caller/reset/protocol/tiering; guestbuiltininit13/549
and11/875 samples is not dominant. Search native guard/eval136leaf/875(15.54%) or
178innermost phase samples(20.34%) includes useful work; R132 targets its leaf transport,
not all sampled work. Original classifier included one TieredJIT thread; corrected
from saved names/raw with no capture rerun. No runtime compiler phase observed in
these saved samples; do not invent one. Raw host streams already have governed
runtime read/write buffering, so no new buffering layer selected.

## Next deliverables

1. **Close R132 delivery.** Observe only currentCI42552506089 at>=5min intervals;
   cache terminal, inspect full Windows/Ubuntu actual11/10, originalstressboth and
   installed-core steps. R127/R129 are complete: never query/replay their terminal
   runs. Keep working while CI runs; no duplicate full local suite. Record outcomes
   without relabeling earlier source pairs or erasing textCPU/control uncertainty.

2. **Complete call/frame/operand consolidation.** Hypothesis: eliminate an entire
   repeated argument/local construction or ordinary-call preparation phase through
   canonical compiler/function facts, rather than new narrow cases. R123 helper/
   inline5.1/3.3ms includes useful calls/tuple work; binding/workspace4.97%leaf,
   preparation4.14%, tuple.99%, context0. Existing linear caller-return runner/lazy
   promotion, borrowed locals/tuple unpack, adopted final tuple/CSV arrays, shared
   layouts and inline presence bits are real. Generic variadic staging exists but
   is absent from the profiled primary helper. R127/R132 supply completed facts;
   inspect real remaining transformations before another prepared-map attempt.
   Source gate completed in~10min: ordinary calls already bind operands into final
   locals; no missing arena/argument array. Native/builtin packaging survives for
   actual dynamic interfaces, not a demonstrated dominant cost. No speculative
   call registry/owner/carrier selected. Independent R133 below removes a complete
   repeated frontend call-construction phase using immutable syntax facts.

3. **Active R133: canonical static call shape.** R128 shows abstract analysis19–29%
   of compile samples, including useful work, not a removable-tax estimate. Source:
   19 static-call consumers repeatedly partition unchanged ordinary arguments;
   binding-aware queries allocate four collections even without expansion. Share
   one syntax-only positional/keyword partition per finalized CallExpressionSyntax;
   ordinary queries retain no AbstractState/AbstractValue. Keep expansion rebuilt
   from current bindings and preserve existing overwrite/diagnostic/evaluation order.
   Remove repeated ordinary partition/list/map/value-list construction from both
   query routes; no runtime binder, owner, registry or public option. Existing
   coarse compilation admission funds retained syntax facts; estimate unchanged.
   Affected config/validatedCSV/text/JSON/report compilation; warm execution is a
   control. Acceptance: existing frontend/known-call/private-name/expanded/default/
   regex diagnostics, state invalidation, cancellation/refusal and budget reuse.
   Gate focused actual11/10, separate compileallocation/elapsed and completeconfig
   latency on quiet VM with unchanged controls; preserve adverse observations.
   Bound initial implementation+checks~45min, one~3min affected comparison if justified;
   refine only for source-specific evidence. Retain/remove decision states actual
   simplification/allocation/CPU separately, then proceed to remaining roadmap.

4. **Bulk/text/frontend follow-through.** Select only demonstrated complete-script
   costs. Current CSV already adopts rows/bulk-admits fields; JSON uses native/shared
   layouts. Old bulkCSV6–8%copy premise is gone; no automatic promotion. Casing/cased
   split/final-buffer formatting/hash caching, input borrowing and R125pending-borrow
   funding remain. Lexical walks requiring complete parent bindings are not duplicate
   analysis merely because there are multiple callers. No universal tagged-value,
   JIT, VM-stack or string-view project from boxing/inclusive samples alone.
   Selected designs must state hypothesis, removed work/storage/code, affected scripts,
   semantic acceptance and a bounded controlled comparison; stop with a retention/
   refinement/debt decision, then continue the broader performance objective.

## Independent regex track

Core owns Python/nativeUTF8 names, byte captures/scalar positions/original windows,
effective flags/errors/replacements, current tokens, one frontend/runtime/import
provider and explicit owners. Core development/contract tests remain independent
of publication; adapter-local bridges/pinned development producers are allowed.
Optional nonpackable adapter ordinarypin0.4; Dev55/d6067925 focused86internal/514public
peractual11/10 already passed. No unchanged replay or sibling edits/builds. Final
selected-package qualification needs DetailedData with distinct preparation/working
owners, native-name enumeration and cursor creation without an earlier token.
Only affected final adapter checks defer. Forwarding/unwind, Python semantics and
actual backend speed remain separate evidence; no blanket development stop.

## Iteration and lasting constraints

Bounded confirmation/refinement/measurement correction is allowed for justified
uncertainty. Timeout, unstable unchanged controls and inconclusive data do not prove
failed designs or permanent closure. Percentages inform decisions, not automatic
vetoes. Preserve original failed/adverse conditions. Simplification, allocation
reduction and demonstrated CPU gains are distinct claims. Focused Release checks
while developing; batch full platform/stress/package checks at delivery boundaries.

Fully managed and memory-safe is lasting: no unsafe/Unsafe/raw pointers/PInvoke/native
stack probing; preserve managed admission/nesting bounds. Host mediation, active
CancellationToken, checked representation bounds, coarse borrowed shared admission/
preflight/replacement overlap, funded aliases/results/caches/pending users and awaited
cleanup remain. Refusal terminal. No tracing/weak reclaim/forcedGC, caps/fuel/quotas,
hidden allowances, silent regex fallback or abandoned work. AGENTS.md is authoritative.
No localbuild/test/timing overlap; fresh nonincremental builds after restoration,
explicitUTF8. Only core Release packages to artifacts/nuget; no publication/tagging.

VM lokad@20.166.121.73, key ~/.ssh/id_lython-bench.pem. Persistent workers/catalog/raw,
owned RAM fixtures separate. Join/verify/unmount/archive under lease, verify locally.
ThroughB493 terminal/cached/verified, no users/fixtures; never requery. Space recovery
only fresh idle exact-byte proof, all inode aliases/SHA/permitted canonical metadata/
writable parents and persisted pre-mutation plan. Preserve every historical path,
byte/archive and original refusal. No more unchanged timing/capture campaign selected.
