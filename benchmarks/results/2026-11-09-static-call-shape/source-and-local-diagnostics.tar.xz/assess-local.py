from pathlib import Path
import json,statistics
r=Path(__file__).parent;out={}
for api in ['warm-sync','warm-async']:
 d=json.loads((r/api/'measurements.json').read_text(encoding='utf-8'));assert all(d[k]for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
 rows=[]
 for o in d['observations']:
  roles={role:dict(milliseconds=statistics.median(s['executionMilliseconds']/s['jobs']for s in o['samples']if s['image']==role),allocation=statistics.median(s['allocatedBytes']/s['jobs']for s in o['samples']if s['image']==role))for role in ['before','before-control','candidate']}
  row=dict(case=o['caseId'],roles=roles,allocationPercent=[100*(roles['candidate']['allocation']/roles[b]['allocation']-1)for b in ['before','before-control']],elapsedPercent=[100*(roles['candidate']['milliseconds']/roles[b]['milliseconds']-1)for b in ['before','before-control']],oldSpreadPercent=100*(roles['before-control']['milliseconds']/roles['before']['milliseconds']-1))
  rows.append(row);print(api,o['caseId'],'alloc%',*[round(v,3)for v in row['allocationPercent']],'elapsed%',*[round(v,3)for v in row['elapsedPercent']],'oldSpread',round(row['oldSpreadPercent'],3))
 out[api]=rows
out['limitations']='R133 canonical static call syntax; reference c343/core95fc versus candidate. Existing five complete CSV/text/JSON/report/config scripts. Compile/warm allocation separate; same-process ALC/desktop elapsed diagnostic, normal GC/tiering. Full goldens, ownership, image isolation, cleanup required; no CPython or CPU inference.'
(r/'assessment-local.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
