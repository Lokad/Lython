from pathlib import Path
import json,hashlib,shutil,subprocess
r=Path(__file__).parent;prior=r.parent/'native-inputs-r132'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cores=[Path(p)/'bin/Release/net11.0/Lokad.Lython.dll' for p in ['src/Lokad.Lython','tests/Lokad.Lython.Tests','tests/Lokad.Lython.PublicApi.Tests']]
assert len({sha(p)for p in cores})==1
for role in ['before','candidate']:shutil.copytree(prior/'images-verified/candidate',r/'images-verified'/role)
assert sha(r/'images-verified/before/Lokad.Lython.dll')=='95fccafa9dd6934e638041c1b249f7e8fa3783fa6ace093f9b7a42c7fd880d8e'
shutil.copyfile(cores[0],r/'images-verified/candidate/Lokad.Lython.dll')
shutil.copyfile(r.parent/'literal-construction-r129/catalog.json',r/'catalog.json')
sources=['src/Lokad.Lython/Frontend/Syntax.cs','src/Lokad.Lython/Frontend/StaticCallArguments.cs','tests/Lokad.Lython.Tests/StaticCallArgumentStateTests.cs']
for p in sources:
 out=r/'source'/p;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,out)
identity=dict(beforeRevision='c343687b (full checkpoint42552506089 independently running)',patchBase=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),coreSHA256={role:sha(r/'images-verified'/role/'Lokad.Lython.dll')for role in ['before','candidate']},changedSources={p:sha(Path(p))for p in sources},contract='Immutable syntactic partition only; no binding-state values retained. Current-binding expansions unchanged. No runtime/API/owner/admission estimate changes.',qualification='47 internal/206 public per actual11/10 after final source; 3 new observable binding-state cases, existing assertions unchanged')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf8')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src','tests']))
for n in ['measure.py','compile-diagnostic.py','assess-local.py']:shutil.copyfile(prior/n,r/n)
p=r/'assess-local.py';s=p.read_text(encoding='utf8');at=s.index("out['limitations']=");end=s.index("\n(r/'assessment-local",at);s=s[:at]+"out['limitations']='R133 canonical static call syntax; reference c343/core95fc versus candidate. Existing five complete CSV/text/JSON/report/config scripts. Compile/warm allocation separate; same-process ALC/desktop elapsed diagnostic, normal GC/tiering. Full goldens, ownership, image isolation, cleanup required; no CPython or CPU inference.'"+s[end:];p.write_text(s,encoding='utf8')
print(identity['coreSHA256'],flush=True)
