from pathlib import Path
import json,subprocess,hashlib,tarfile
r=Path('.git/agent-notes/review-20261031/module-bindings-r520');q=r/'confirmation';c=json.loads((q/'config.json').read_text(encoding='utf-8'))
code='''from pathlib import Path
import fcntl,hashlib,json,os,stat,subprocess,tarfile
root=Path(ROOT);b=root.parent;fixture=root/'guest-fixtures'
assert root==Path('/home/lokad/lython-bench-checks/module-bindings-confirm-b950-20261118')and root.resolve()==root
with(b/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 state=subprocess.check_output(['systemctl','show','lython-b950-module-bindings-confirm-20261118.service','--property=MainPID,ExecMainStatus,ActiveState'],text=True);assert 'MainPID=0'in state and 'ExecMainStatus=2'in state and 'ActiveState=failed'in state
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert fixture.resolve()==fixture and os.path.ismount(fixture)and not any(fixture.iterdir())
 evidence=[p for p in root.iterdir()if p.is_file()and p.suffix in ['.py','.sh','.json']];manifest={}
 for p in evidence:
  v=p.lstat();assert stat.S_ISREG(v.st_mode)and v.st_uid==os.getuid()and p.resolve()==p;manifest[p.name]=hashlib.sha256(p.read_bytes()).hexdigest()
 archive=root/'failed-launch-observations.tgz'
 assert not archive.exists()
 with tarfile.open(archive,'w:gz')as a:
  for p in evidence:a.add(p,arcname=p.name)
 with tarfile.open(archive)as a:
  for n,h in manifest.items():assert hashlib.sha256(a.extractfile(n).read()).hexdigest()==h
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir()
 receipt=dict(complete=False,noWorkloadStarted=True,noPerformanceObservation=True,allWorkersJoined=True,freshIdleLease=True,emptyRAMFixtureVerified=True,archivedAndVerifiedBeforeUnmount=True,manifest=manifest,archiveSHA256=hashlib.sha256(archive.read_bytes()).hexdigest(),failure='Windows line endings in owned shell launcher; /bin/sh set option rejected before collector',unitState=state)
 (root/'failure-recovery-receipt.json').write_text(json.dumps(receipt,indent=2)+'\\n');print(json.dumps(receipt))
'''.replace('ROOT',repr(c['root']))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73'];p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=45);(q/'recovery.log').write_text(p.stdout+p.stderr,encoding='utf-8');assert p.returncode==0,p.stdout+p.stderr;receipt=json.loads(p.stdout)
(q/'failure-recovery-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
for n in ['failed-launch-observations.tgz','failure-recovery-receipt.json']:
 p=subprocess.run(['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','lokad@20.166.121.73:'+c['root']+'/'+n,str(q/n)],capture_output=True);assert p.returncode==0,p.stderr
assert hashlib.sha256((q/'failed-launch-observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256'];print('No workload started; original launcher/source conditions archived and SHA verified before empty mount cleanup.')
