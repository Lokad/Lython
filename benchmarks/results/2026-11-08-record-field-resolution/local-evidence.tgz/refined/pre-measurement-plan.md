# Lokad.Lython 0.11.0

Updated 2026-11-08. Git-ignored: never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script performance.
Current contracts belong in docs; experimental designs, failures and adverse raw
evidence remain in [EXPERIMENTS](benchmarks/EXPERIMENTS.md) and linked results.

## Actual delivery status

- **Committed/pushed, fully qualified productionb1e17b64/frozen93e926fe:** cached
  CI42512127664, Windows/Ubuntu actual.NET11/.NET10 full Release, original Stress
  both and installed core consumers. Shared compiler-fact correction, directUTF8
  formatting/storage, original native returns and R105/R106/R110 are delivered;
  combined R113–R115 shares one primitive result-shape fact, removes runtime proof
  source offsets and native/ordinary-forwarding mutual exclusion. No new engine,
  owner/cache/arena/value representation or public API. Do not replay qualification.
- **Claims remain separate:** original native-return allocation−19.92/−19.31%,
  elapsed diagnostic. Formatting allocation−8.67%, controlledB102elapsed/CPU−5–8%,
  original adverse15.125ms unexplained/preserved. R110wide allocation−8.56–8.58%.
  R115integerCSV/JSONelapsed−3.5–5.2%, float−1.8–6.2%across APIs/supportingCPU;
  incremental warm allocations neutral. Direct compile allocation+1.40–1.48%
  accounting/+0.59%text/report unchanged, elapsed uncertain; proof nodes32→72B,
  instructions32B unchanged. Conservative admitted metadata is not free storage.
- **Explicit debt:** custom-operator async+1.28–3.36%elapsed/+6.67%CPU inR115;
  text controls variable, report elapsedflat/CPUpossible debt. Older R76/R79/R95/
  R96/R102/R105config debts remain source-pair-specific; newer data do not silently
  repay them. R113/R114intermediates are superseded by qualified combined source,
  their original adverse conditions/source/binaries remain. Active uncommitted R119 prototype; no full delivery claim. R112not retained: duplicated cold namespace branches, neutral
  allocation/mixed timing. Prior qualified0579 restoration preserved.
- **Current primary CPython checkpoint R117:** sourceb1e17b64/core93e9 versus
  CPython3.13.16, five unchanged CSV/text/JSON/report scripts,15jobs311.431s,
  allgates/archive/localverified. [BENCHMARKS](docs/BENCHMARKS.md) separates compile,
  warm and compile-to-result, mediated I/O/validation/cleanup. Compile-to-result:
  returnedCSV1.23–1.25x, CSV1.06–1.07x, text1.52x, JSON0.92–0.96xvariable,
  report1.42–1.46xvariable. Warmtext1.58–1.65xvariable. Historicalconfig/search/
  manifest/extra variants remain726, not current-source claims. Startup/RSS/
  pending-I/O/embedding tails remain unmeasured. No isolated causal gain inference.
- **R116 assessment complete, no prototype:**1160guest samples/5.85CPU seconds/
  67unknown5.78%, prefix18.79%leaf, input5.95%, hash4.14%, casing/split8.36%,
  proof0.60%, binding/contexts0leaf.218/218prefixPCs exactly match existingTier1
  blocks; fetch/checks/loop control/opcode routing are mixed work, not removable
  dispatch tax. Input NoInlining fence keeps transient values out of the loop;
  jumped state carries async-disposal continuation. Keep both. R108 measured report,
  not this text. R111 loop~1.17xCPython diagnostic lacked quiet-after; preserved.

## Prioritized deliverables

1. **R119 selected prototype: flat lookup storage and shared record fields.**
   R118 source gate completed without a prototype: guarded get/add/store syntax
   fusion would add conditional opcode/CFG/local proof machinery plus the original
   sequence for a narrow shape. No measured failure/permanent closure is inferred.

   Reuse the existing per-frame cache: replace individual member-cache objects
   with flat funded entries, and resolve repeated UTF8 string fields once per
   immutable shared CSV/JSON key layout. Remove repeated row hashing/probing and
   cache-record allocations, without a new opcode, owner, engine or cache framework.
   R108dictionary13%leaf/R116hash work motivates inspection, no speedup prediction.
   See private R119design for source inventory/frozen93e9 before image.

   Acquire cache backing before proving current layout because admission can mutate
   rows. Entries retain layout/key/index, never originating rows or stale values.
   Read current live slot; missing/deleted/detached/dynamic/protocol shapes stay on
   canonical semantics. Preserve original evaluation/spans, real async protocols,
   current-token cancellation, terminal refusal and funding through awaited cleanup.
   Validate cross-row sharing, aliases, mutations/reinsertion, dynamic keys, custom
   equality/hash, denial and reentrancy, retained results/budget reuse. Focused
   actual11/10Release; unchanged complete five-case before/after with full goldens,
   allocation and compile separate, then bounded quiet source pair if warranted.
   Retain/refine/reject with explicit remaining regression debt. Full platform,
   Stress and installed core only at coherent retained delivery. Completion of
   this prototype does not complete the whole-script performance objective.

2. **Substantial redesign roadmap: eliminate a demonstrated whole phase.**
   Current text/report gaps remain~1.5x; R119 alone will not settle this objective.
   After its bounded decision, select the next phase using existing source/captures
   plus targeted evidence where a material attribution is missing:

   - **Complete calls/frames and operand transport:** native returns/direct argument
     borrows/deferred contexts/reusable local workspaces already remove packaging
     on common routes. R116binding/context0leaf and R108routing3.96%leaf do not
     establish whole-frame construction as dominant; inclusive84% contains useful
     callee work. Initial R119 census corrects the report inference: render uses ordinary executable formatting; once-only frame caches add 96B per call. Assess
     shared operation/lookup execution across those routes before introducing a new
     call carrier. A selected redesign must retire displaced route/storage and pass
     actual suspension, closure/rebinding, recursion/cleanup and alias/refusal tests.
     Preserve slower R71arena/control/wide-carrier lessons; no universal tagged
     slots/JIT/stack redesign from boxing/inclusive samples alone.
   - **Per-record construction:** shared key layouts, JSON direct value filling and
     CSV array adoption already eliminate earlier copying. Bulk CSV6–8% was
     reassessed with its adverse control: do not promote an absent old phase. R119
     targets subsequent field resolution, not row construction. Any further change
     must identify surviving intermediate arrays/objects in actual current source,
     preserve order/duplicate keys/hooks/retained rows and replace that storage.
   - **Text and frontend:** directUTF8/inline strings/casing-split/final-buffer
     formatting/shared compiler facts are established. R116rules out per-update
     root resizing and recursive native-string hashing. Remaining conversion or
     analysis proposals need exact current callers and allocation/CPU attribution,
     not reintroducing a second formatter/parser/evaluator. Cover Unicode/format
     hooks and diagnostics/scoping; compile measured separately from warm/cleanup.

   For the selected next milestone, record hypothesis, work/storage removed,
   affected complete scripts, semantic/cancellation/ownership acceptance and a
   bounded before/after with unchanged controls BEFORE implementation. Assess source
   scope~20min, then one useful existing capture or short targeted diagnostic if
   needed. Stop gathering when the candidate is attributable and testable, or record
   specific unresolved evidence and move to an independent track. A timeout or
   unstable control permits justified bounded correction/refinement, not permanent
   closure. Finish temporary regression debt at an explicit coherent delivery
   milestone; do not accumulate unmeasured narrow paths or repeat qualified work.

3. **Independent regex contract/implementation.** Core owns Python/nativeUTF8
   names, byte captures/scalar positions/original windows, flags/errors/replacements,
   cache ownership/current tokens and one frontend/runtime/import provider. Optional
   adapter nonpackable, ordinary0.4pin. Dev55/d6067925 development checks86internal/
   514public peractual11/10 completed; no unchanged replays or sibling edits/builds.
   Missing producer capabilities: DetailedData separate preparation/working owner,
   native-name enumeration and cursor creation without retaining an earlier token.
   Existing adapter-local bridges/development producers support independent work.
   Released capabilities defer only affected final adapter qualification, never
   core development. Separate forwarding/unwind, semantics and backend performance.

## Operating and experimental policy

Bounded confirmation/refinement/measurement correction are allowed when justified.
Timeout, unstable unchanged controls and inconclusive measurements establish
uncertainty, not failed design. Size runs for useful quiet-VM observations. Retain
all adverse results and original failed conditions. Percentages inform decisions
rather than automatically veto simplification. Temporary setbacks need an explicit
completion milestone and regression-debt decision; no unsupported CPU predictions.

AGENTS.md governs fully managed memory safety/stack admission, host mediation,
current-token cancellation, shared coarse admission/preflights/replacement overlap,
funded aliases/results/caches/pending users and awaited cleanup. Refusal is terminal.
No unsafe/Unsafe/native probes, independent caps/fuel/quotas, tracing/weak reclaim/
forcedGC, silent regex fallback, abandoned work or hidden default allowance.
Focused Release iteration; no overlapping local builds/tests/measurements. Fresh
nonincremental build after timestamp-preserving restores, exact source/binary
identities. UTF8 text. Core only explicit Release pack to artifacts/nuget.

VM lokad@20.166.121.73, key~/.ssh/id_lython-bench.pem. Persistent workers/catalogs/
raw separate from owned RAM; join, verify maps, unmount, archive under lease and
verify locally. No evidence deletion; exact-byte hardlinks require fresh identity/
inode/alias proof. Free-space floors remain. B450–B477terminal/cached/archived/
locallyverified; no VMusers/fixtures. All recorded older terminal CI cached,
including42512127664/b1e17b64; never query again. No duplicate dispatch, observations
>=5min apart. Publication/tagging stay postponed.

R118 source gate closed; R119 design recorded before implementation. R119 flat lookup array/shared-row resolution is an uncommitted prototype. Initial19internal/14public actual11 pass; broader actual11/10 focused checks running. Initial candidate core138b6a09 report allocation+9.02% explained by 96B cache array per render call; census proves ordinary, not native, execution. Preserve mistaken initial inference and adverse text timings as corrected evidence. Refinement limits field-cache slots to existing loop/comprehension sites; no caching across calls/new framework. Production b1e17b64 remains fully qualified; R119 is not delivered.
