from hashlib import sha256
from pathlib import Path
from shutil import copyfile, copytree
import json
import os
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
notes = lab.parent
previous = notes / "current-checkpoint-b1906-20261127/comparison/quiet"
archive_source = notes / "generator-row-workspace-refined-20261127/comparison"
old = archive_source / "quiet"
current = notes / "json-list-initial-admission-b1913-20261128/comparison"
regex = notes / "wsl-log-cpython-20261127"
quiet = lab / "comparison/quiet"
quiet.mkdir(parents=True)
core = "Lokad.Lython.dll"

def read(path):
    return json.loads(path.read_bytes())

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def manifest(folder):
    return {p.name:digest(p) for p in folder.iterdir()}

def write(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")

def catalog(folder):
    p = folder / "representative.json"
    assert digest(p) == read(folder / "identity.json")["catalogs"][p.name]["sha256"]
    return read(p)

def git(*args):
    return subprocess.check_output(["git", *args], cwd=repo)

head = git("rev-parse", "HEAD").decode().strip()
assert head.startswith("24218276c") and not git("status", "--porcelain")
measured = read(current / "identity.json")
patch = git("diff", "--binary", measured["sourceRevision"], head, "--", "src")
assert sha256(patch).hexdigest() == measured["sourcePatchSHA256"]
image = measured["imageFiles"]["candidate"]
assert len(image) == 32 and manifest(current / "candidate") == image
copytree(current / "candidate", quiet / "local-image")
assert manifest(quiet / "local-image") == image

donor = read(previous / "identity.json")["imageFiles"]["candidate"]
donor_state = read(previous / "terminal-status.json")
assert not donor_state["live"] and not donor_state["fixtures"] and donor_state["exitCode"] == "0"
donor_receipt = donor_state["receipt"]
gates = ("complete", "allWorkersJoined", "guestFixturesRemoved", "quietBeforeAndAfter", "archivedAndVerifiedUnderLease")
assert all(donor_receipt[key] for key in gates)
assert digest(previous / "observations.tar.xz") == donor_receipt["archiveSHA256"]
assert {name for name, checksum in image.items() if donor[name] != checksum} == {core}

# Keep all observations and source. This idle VM binary can be restored from
# the verified persistent local copy if its exact historical image is needed.
restorable = read(old / "identity.json")["imageFiles"]["reference"]
local_old = archive_source / "reference"
assert manifest(local_old) == restorable
old_state = read(old / "terminal-status.json")
assert not old_state["live"] and not old_state["fixtures"] and old_state["exitCode"] == "0"
assert all(old_state["receipt"][key] for key in gates)
old_archive = old_state["receipt"]["archiveSHA256"]
assert digest(old / "observations.tar.xz") == old_archive
retire = dict(name=read(old / "upload.json")["root"], unit="lython-b1905-generator-row-quiet",
              role="reference", image=restorable, localImage=str(local_old.relative_to(repo)), archive=old_archive)

selected = catalog(previous)
shipment, dense, csv, config, first, later, generated = [case["id"] for case in selected["cases"]]
selected["cases"] = [case for case in selected["cases"] if case["id"] != later]
log_cases = catalog(regex)["cases"]
compiled_log, module_log = [case["id"] for case in log_cases]
selected["cases"] += log_cases
assert len(selected["cases"]) == 8
write(quiet / "representative.json", selected)
jobs = [[shipment,"warm-async"],[dense,"warm"],[csv,"warm"],[compiled_log,"warm"],[generated,"compile"],
        [shipment,"warm"],[dense,"warm-async"],[first,"warm"],[module_log,"warm"],[config,"compile-run"]]
write(quiet / "jobs.json", jobs)

for name in ("cpython-worker.py","run.sh"):
    copyfile(previous / name, quiet / name)
assert b"\r" not in (quiet / "run.sh").read_bytes()
assert digest(quiet / "cpython-worker.py") == measured["cpythonWorkerSHA256"]
stage_name = "script-cpython-quiet-b1914-20261128"
identity = dict(sourceRevision=head, productionHead=head, purpose="Current whole-script CPython checkpoint.",
                imageFiles={"candidate":image},
                coreSHA256={k:image[core] for k in ("candidate","candidate-control")},
                auxiliaryFiles={k:v for k,v in image.items() if k != core},
                frozenImage="/home/lokad/lython-bench-checks/" + stage_name + "/candidate",
                catalogs={name:{"sha256":digest(quiet / name)} for name in ("representative.json","jobs.json")},
                expectedCPythonSHA256=measured["expectedCPythonSHA256"], cpythonWorkerSHA256=measured["cpythonWorkerSHA256"],
                donorArchiveSHA256=donor_receipt["archiveSHA256"])
write(quiet / "identity.json", identity)

collect = (previous / "collect.py").read_text(encoding="utf-8")
collect = collect.replace("lython-b1906-cpython-fixtures", "lython-b1914-cpython-fixtures")
a = collect.index("    fresh = out/'fresh'\n")
b = collect.index("    time.sleep(20)", a)
collect = collect[:a] + collect[b:]
collect = collect.replace("'representative.json','fresh-config.json','jobs.json'", "'representative.json','jobs.json'")
compile(collect, "collect.py", "exec")
(quiet / "collect.py").write_text(collect, encoding="utf-8", newline="\n")

paths = {name:quiet / name for name in ("identity.json","representative.json","jobs.json","cpython-worker.py","run.sh","collect.py")}
paths["candidate/" + core] = quiet / "local-image" / core
payload = quiet / "stage.tar.gz"
with tarfile.open(payload, "w:gz") as output:
    for name, path in paths.items(): output.add(path, arcname=name)
files = {name:dict(length=path.stat().st_size, sha256=digest(path)) for name,path in paths.items()}
write(quiet / "upload.json", dict(root=stage_name, donor=read(previous / "upload.json")["root"],
    donorFiles=donor, donorArchive=donor_receipt["archiveSHA256"], payloadSHA256=digest(payload), files=files,
    expandedBytes=sum(row["length"] for row in files.values()), minimumAfterStageBytes=12*1024*1024,
    removals=[retire]))

vm = (previous.parents[1] / "quiet-vm.py").read_text(encoding="utf-8")
reclaim = (archive_source.parent / "quiet-vm.py").read_text(encoding="utf-8")
a = reclaim.index(" deduplicated=[]")
b = reclaim.index(" root.mkdir()",a)
reclaim = reclaim[a:b].replace("generator-row-workspace-b1905-replica-custody.json","script-cpython-b1914-replica-custody.json")
vm = vm.replace("lython-b1906-current-cpython","lython-b1914-current-cpython").replace("proof['caseCount']==7","proof['caseCount']==8")
a = vm.index(" assert before>=floor")
b = vm.index(" root.mkdir()",a)
vm = vm[:a] + reclaim + vm[b:]
vm = vm.replace("requiredBeforeStage=floor,deduplicated=[]","requiredBeforeStage=floor,deduplicated=deduplicated")
compile(vm,"quiet-vm.py","exec")
(lab / "quiet-vm.py").write_text(vm,encoding="utf-8",newline="\n")
sdk = Path.home()/".dotnet11"
dotnet = sdk / "dotnet.exe"
subprocess.run([dotnet,quiet/"local-image/Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",
    quiet/"representative.json","--dotnet",dotnet,"--python","C:/Python313/python.exe",
    "--python-worker",quiet/"cpython-worker.py","--out",lab/"local-verify.json"],
    cwd=repo,env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk)),check=True,timeout=60)
preflight=read(lab/"local-verify.json")
assert preflight["state"]=="Completed" and preflight["caseCount"]==8 and preflight["catalogSha256"]==identity["catalogs"]["representative.json"]["sha256"]
assert preflight["launched"]["library"]["sha256"]==image[core]
print(head, len(jobs), "lanes", sum(row["length"] for row in files.values()), "bytes to stage")
