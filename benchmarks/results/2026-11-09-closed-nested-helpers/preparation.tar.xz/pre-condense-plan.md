# Lokad.Lython 0.11.0

Updated 2026-11-09 (Paris). Git-ignored: never force-add. Publication and tagging
remain postponed. Objective: coherent simplification and substantial complete-script
performance. Finishing an isolated experiment does not complete that objective.
Current contracts belong in docs; [experimental history](benchmarks/EXPERIMENTS.md)
and immutable results retain old variants, failed conditions and adverse evidence.

## Actual delivery status

- **Fully qualified:** shared compiler-fact correction and earlier UTF-8/native-return
  work; R119–R121 lookup facts (runtime6f76/coreC617 + fixture d97), R125 pending
  text-read funding/awaited cleanup (3109/core004e), R126 obsolete liveness fences
  (9f2e/core85e), R127 shared declaration metadata (847/coreac6b), R129 literal
  construction (459/core1be2). Cached Windows/Ubuntu, actual .NET11/10, original
  stress both and installed-core consumers pass. Do not repeat unchanged qualification.
- **Fully qualified:** R132 c343687b/core95fc removes consumed
  native read nodes and shares ordinary operand sources/fixed local-prefix facts.
  Every real variant passed 87 internal/394 public focused checks per framework.
  CachedCI42552506089success, observed03:17:40UTC: full Windows/Ubuntu actual11/10,
  originalstressboth and installed-package consumers pass. Never query again.
  [Evidence](benchmarks/results/2026-11-09-native-inputs/README.md).
- **Committed R1339db554b3, full qualification pending:** canonical ordinary static-call syntax
  partition; inferred values and expansions remain binding-state-dependent. Removes
  repeated positional/keyword/value-container construction, adds no runtime binder,
  owner or public API. Frozen36fd versus c343/core95fc; 47 internal/206 public checks
  per actual framework pass, including3 new binding-state cases. Compilation allocation
  falls2.59–4.14%; no general CPU gain established. Seven quiet jobs196.114s, all
  identity/golden/ownership/quiet/join/RAM/archive/local-SHA gates pass. Completeconfig
  remains inconclusive with candidate spread3.34% and wider processCPU+3.17–5.14%
  possible debt. Original desktop configcompile+15.74–17.70% remains preserved,
  without consistent reproduction on VM. Full delivery batches at a coherent boundary.
  [Evidence](benchmarks/results/2026-11-09-static-call-shape/README.md).
- **Held prototypes:** R124 prepared named maps added a registry/guard while general
  binding remained; no stable whole-script CPU benefit, compilation allocation rose.
  Production was freshly restored; useful semantic/lifetime regressions survive.
  Slower arena/call-control and shared-string-window designs remain evidence, not
  permanent design bans. No unchanged replays selected.

## What the measurements establish

[Maintained CPython comparison](docs/BENCHMARKS.md) labels every row by measured
source (6d73,459,6f76), not today's HEAD. Compilation, warm execution and compile-to-result
are separate. Current validatedCSV/text/report complete ratios are1.15–1.16x/
1.44–1.45x/1.35–1.38x versus CPython3.13.16; report and compile rows variable.
Earlier config/search/manifest and ordinaryCSV/JSON remain historical. Included: mediated RAM-file I/O, full validation,
prior-result cleanup. Excluded: startup, fixture reset/protocol and final cache teardown.
Wider processCPU has a different boundary. Large-tree throughput/embedding tails/RSS
remain unmeasured. Refresh at a meaningful checkpoint, not after each source edit.

Native helper-return allocation reductions19.92/19.31% are established independently
of their original diagnostic elapsed gains. Formatting allocation falls8.67%; controlled
B102 elapsed/CPU supports retention. The original adverse15.125ms remains unexplained
and preserved. R132 improves bounded syncsearch elapsed2.45–3.40% with close controls,
but textCPU and other control spreads remain debt; no universal gain/neutrality claim.

R128 compilation attribution shows parsing26–43%, abstract analysis19–29%, executable
construction~19%, lexical7–8%, lowering2–4%. These include useful work. R131 config/search
separates caller/reset/protocol/tiering; builtin setup is not dominant. No runtime
compilation phase or missing buffering layer was observed. Ordinary calls already
borrow operands into final locals and use the linear runner/lazy promotion. Current
CSV adopts rows and shares key layouts; the old6–8% copying premise is gone. Do not
rebuild already-removed phases from inclusive sample counts.

## Prioritized deliverables

1. **Delivery correction before further source qualification.** R1339db and
   R1356d73 are committed/pushed. CI42558487979 is terminal/cached: Ubuntu full
   actual11/10, original stress both and installed-package consumers pass. Windows
   actual11 has4437 internal passes/one failure and16853 public passes; later
   Windows stages skipped. NativeHashCancellationTests binary case completes its
   64MiB hash before the parent resumes from SpinWait/IsCompleted assertion. This
   establishes a scheduling-dependent fixture failure, not failed cancellation
   after a request (none had yet been issued). Preserve original log/conditions.
   Bounded correction must retain detection of missing in-loop cancellation,
   unpublished cache, original attribution, awaited users and budget reuse, without
   runtime hooks, instruction accounting or relaxed timeout. R137 moves only the
   64MiB timed scan to Stress, arms a1ms timer on the hashing worker, removing the
   late-parent scheduling assertion. Actual native cancellation/cache assertions remain. Small
   deterministic cancellation/cache/refusal checks stay ordinary. Mutation-check
   the actual loop cancellation before accepting; original failure stays archived. Do not call the source fully
   qualified or silently rerun green. R137 complete:16/16actual11/10 pass after
   nonincremental builds. Removing only in-loop checks, retaining entry, makes both
   native cases fail; exact runtime source restored. No timeout/size/runtime-policy
   change. Batch corrected Windows qualification with R138. Never requery terminal handles.

2. **R133–R135 committed, focused-qualified; full Windows qualification pending.**
   R1339db shares immutable ordinary static-call syntax partitions while resolving
   expansions/inferred values from current bindings. Compile allocation−2.59–4.14%,
   CPU inconclusive; complete-config/process-CPU uncertainty retained. R134 sampled
   allocation associations, not CPU or exact type sizes: text PyString35.13% /
   BigInteger24.63%; CSV Boolean9.05%. R1356d73 uses two native Boolean boxes and
   corrects id/is identity keys, preserving arbitrary protocol return objects.
   97internal/385public peractual11/10 pass. Warm allocationCSV−9.09%,search−11.5–11.7%;
   no general CPU gain, report+.11–2.44% possible elapsed debt. Original failed
   conditions/desktop adversity and controls remain in immutable evidence.
   [R133](benchmarks/results/2026-11-09-static-call-shape/README.md),
   [R134](benchmarks/results/2026-11-09-runtime-allocation/README.md),
   [R135](benchmarks/results/2026-11-09-native-booleans/README.md).

3. **R136 CPython checkpoint complete.** Fresh post-commit6d73/coreea65/worker22331;
   runtime IL matches focused76d, source metadata differs. Existing worker/host/
   external-source boundary unchanged; only default catalog differs. Nine quiet
   jobs188.968s, all identity/golden/budget/Closed/join/RAM/archive/local-SHA gates
   pass. Current compile/warm/complete tables updated for validatedCSV/text/report;
   complete1.15–1.16/1.44–1.45/1.35–1.38x. Compile/report variability remains explicit.
   Older459/6f76 rows accurately historical; no per-change speedup attribution.
   [Evidence](benchmarks/results/2026-11-09-cpython-checkpoint/README.md).

4. **R138 closed nested helpers implemented; measurement active.** Compiler capture
   facts already exclude captured cells from native bodies. Remove the two lexical-
   parent invocation barriers and use existing native/deferred paths, preserving
   lexical closure retention and promotion before scope-sensitive work. No new
   binder, frame arena, cache or option. Three complete main()-wrapped CSV/text/report
   programs exercise the removed phase; original JSON/search are controls. Genuine
   captures/classes/annotations/type-parameter scopes keep existing handling.
   Broad68internal/279public eachactual11/10 pass, then final36/76 after method rename
   and extra nested capacity-admission cases. Independent Python goldens, genuine
   suspension, cancellation/refusal, retained aliases, locals/globals/unbound lookup,
   live cells and managed-depth cleanup pass. Candidate345f warm allocation falls
   CSV38.67%,text46.5%,report28.5%; compile allocation measured separately. Desktop
   async report+2.25–10.25% adverse/variable controls retained. B497 six-job quiet
   source pair active, finite240s owner; observe terminal no earlier04:45:48UTC.
   Check async report specifically; no CPU gain assumed. Decide retention/regression
   debt after all source/quiet/ownership/join/RAM/archive/local-SHA gates. Preserve
   original conditions and evidence, not a rigid improvement-percentage veto.

5. **Next frame milestone: explicit lexical operands, source gate first.**
   Hypothesis: capture presence still eagerly constructs a context although the
   existing work state already owns closure/local cells. Inspect direct cell reads
   and promotion requirements; eliminate a frame-dependent cell-read bridge only
   if the existing state can carry the same semantics. Affected scripts: main()
   helpers reading shared configuration or predicates. Preserve nonlocal writes,
   late rebinding, escaped closures, class barriers, annotations, generators, locals,
   async protocols, cancellation/refusal and ownership. No new call arena or backend.
   Stop after a20min source/invariant gate if no complete phase can disappear.
   If justified, one bounded before/after whole-script comparison with unchanged
   controls, then explicitly decide remaining CPU/compilation regression debt.

6. **Record/text/frontend roadmap, evidence before redesign.** Ordinary calls already
   borrow operands into final locals; a universal value/operand rewrite is not selected
   from boxing alone. Earlier arena/control/string-window slowdowns remain lessons.
   Current CSV adopts rows/shared layouts: the historical bulk-CSV6–8% copying premise
   is displaced. No automatic promotion or rigid percentage rejection. Reconsider
   only a newly demonstrated per-record construction phase, including the adverse
   control; retire its displaced implementation on completion. Current text uses
   bulk casing/split/final UTF8 formatting and native JSON construction. Remaining
   conversions require one bounded source/profile gate on retained whole-script
   evidence, not another series of isolated intrinsics. Frontend parsing/analysis/
   executable construction do useful work; repeated binding facts and lower-call
   wrappers require real-consumer inspection (class headers/prepared definitions),
   not another carrier/registry. For each selected redesign name eliminated work,
   representative scripts, semantic/ownership/cancellation acceptance and one
   controlled source pair before implementation. Stop a gate without a coherent
   deletion target; record uncertainty rather than inventing a replacement project.

## Independent regex delivery

Core owns Python/nativeUTF-8 names, byte ranges/scalar positions/original windows,
effective flags/errors/replacements, current tokens, one frontend/runtime/import
provider and explicit owners. Core development and contract tests are independent
of producer publication; adapter-local bridges/pinned development producers are
allowed. Optional nonpackable adapter ordinary pin0.4; Dev55/d6067925 focused86internal/
514public per actual11/10 already pass. No unchanged replay or sibling edits/builds.
Selected final-package qualification still needs DetailedData with distinct
preparation/working owners, native-name enumeration and cursor creation without
an earlier caller token. Only affected final adapter checks defer. Keep forwarding/
unwind, Python semantics and real-backend performance as separate evidence.

## Iteration and lasting constraints

A timeout, unstable unchanged control or inconclusive measurement establishes
uncertainty, not a failed design. Allow bounded confirmation/refinement/correction
when source-specific evidence warrants it. Percentages inform decisions, not vetoes.
Preserve original adverse/failed conditions; simplification, allocation reduction
and demonstrated CPU improvement are distinct outcomes. Focused Release checks
while developing; full platform/stress/installed-package checks at delivery boundaries.

AGENTS.md remains authoritative: fully managed safety and validated managed stack
admission; host mediation and current cancellation; coarse borrowed shared admission,
preflights/replacement overlap, funded aliases/results/caches/pending users and awaited
cleanup. Refusal is terminal. No unsafe/native probing, quotas/caps/hidden allowance,
heap tracing/weak reclaim/forcedGC, silent regex fallback or abandoned work. Keep
compilation estimates conservative; no tiny-budget precision or exact GC reachability.

No overlapping local build/test/timing. Fresh nonincremental builds after restored
snapshots, explicit UTF-8. Only core Release packages under artifacts/nuget; no publication.
VM lokad@20.166.121.73/key ~/.ssh/id_lython-bench.pem. ThroughB496 terminal/cached/local
verified, no users/fixtures; never requery. Evidence stays persistent, separate from
RAM fixtures; join/unmount/archive under lease/local SHA. Space recovery requires
fresh idle exact bytes/all inode aliases/SHA/permitted ownership/modes/writable parents
and a persisted pre-mutation plan. Preserve all historical paths and bytes; floors stay.
