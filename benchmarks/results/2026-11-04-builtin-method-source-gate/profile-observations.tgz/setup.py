from pathlib import Path
r=Path('/home/lokad/lython-bench-checks/builtin-method-source-gate-b216-20261104')
(r/'candidate').symlink_to('/home/lokad/lython-bench-checks/runtime-cpython-b214-20261104/candidate',target_is_directory=True)
