from pathlib import Path
from shutil import copy2,copytree
from hashlib import sha256
import json

lab=Path(__file__).resolve().parent
first=lab/'comparison'
repeat=lab/'repeat'
assert (first/'exit-code.txt').read_text().strip()=='0'
receipt=json.loads((first/'archive-receipt.json').read_bytes())
assert receipt['complete'] and sha256((first/'observations.tar.xz').read_bytes()).hexdigest()==receipt['archiveSHA256']
repeat.mkdir()
identity=json.loads((first/'identity.json').read_bytes())
sha=lambda p:sha256(p.read_bytes()).hexdigest()
for role, expected in identity['imageFiles'].items():
    assert {p.name:sha(p) for p in (first/role).iterdir()}==expected and len(expected)==32
    copytree(first/role,repeat/role)
    assert {p.name:sha(p) for p in (repeat/role).iterdir()}==expected
    proof=first/f'{role}-verify.json'
    checked=json.loads(proof.read_bytes())
    assert checked['caseCount']==5 and checked['state']=='Completed'
    assert checked['catalogSha256']==identity['catalogs']['representative.json']['sha256']
    assert checked['launched']['library']['sha256']==expected['Lokad.Lython.dll']
    copy2(proof,repeat/proof.name)
for name in ('representative.json','cpython-worker.py'):
    copy2(first/name,repeat/name)
assert sha(repeat/'representative.json')==identity['catalogs']['representative.json']['sha256']
jobs=[
 ['diagnostic.shipment-row-generator-reduction','warm'],
 ['diagnostic.shipment-row-generator-reduction','warm-async'],
 ['diagnostic.shipment-file-fed-map','warm-async'],
 ['diagnostic.shipment-starmap-iterable-rows','warm-async'],
]
(repeat/'jobs.json').write_text(json.dumps({'warm':jobs},indent=2)+'\n',encoding='utf-8',newline='\n')
identity['catalogs']['jobs.json']['sha256']=sha(repeat/'jobs.json')
identity['purpose']='B1934 same-image callback repeat with reversed worker placement'
(repeat/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
driver=(first/'collect.py').read_bytes()
assert driver.count(b'len(jobs) == 8')==driver.count(b'job_index % 2 != 0')==1
initial_jobs=json.loads((first/'jobs.json').read_bytes())['warm']
reversed_placements=tuple(i for i,job in enumerate(jobs) if initial_jobs.index(job)%2==0)
placement=('job_index in '+repr(reversed_placements)).encode('ascii')
(repeat/'collect.py').write_bytes(driver.replace(b'len(jobs) == 8',b'len(jobs) == 4').replace(b'job_index % 2 != 0',placement))
launcher=(first/'run.sh').read_bytes()
front,tail=launcher.split(b'for role in reference candidate; do\n',1)
end=tail.split(b'done\n',1)[1].replace(b'330s',b'185s')
(repeat/'run.sh').write_bytes(front+end)
assert b'\r' not in (repeat/'run.sh').read_bytes()
summary=(lab/'summarize.py').read_text(encoding='utf-8')
for a,b in [('else "comparison")','else "repeat")'),('receipt["warmJobs"] == 8','receipt["warmJobs"] == 4'),('== 224','== 112')]:
    assert summary.count(a)==1
    summary=summary.replace(a,b)
(lab/'summarize-repeat.py').write_text(summary,encoding='utf-8',newline='\n')
print('Same 32-file images verified for a four-lane repeat.')
