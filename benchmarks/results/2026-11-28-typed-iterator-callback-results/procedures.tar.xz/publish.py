from pathlib import Path
from shutil import copy2
from hashlib import sha256
from subprocess import check_output
import json,re,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
bench=lab/'comparison'
output=repo/'benchmarks/results/2026-11-28-typed-iterator-callback-results'
def read(p):return json.loads(p.read_bytes())
def digest(p):return sha256(p.read_bytes()).hexdigest()
identity=read(bench/'identity.json')
source=check_output(['git','diff','--binary',identity['sourceRevision'],'--','src/Lokad.Lython'],cwd=repo)
assert source==(lab/'candidate.patch').read_bytes()
assert sha256(source).hexdigest()==identity['sourcePatchSHA256']
assert check_output(['git','diff','--binary','--','tests'],cwd=repo)==(lab/'test.patch').read_bytes()
for role,manifest in identity['imageFiles'].items():
    assert len(manifest)==32 and {p.name:digest(p) for p in (bench/role).iterdir()}==manifest
timing=read(bench/'summary.json')
assert timing['verifiedTimedBatches']==224 and len(timing['rows'])==8
receipt=read(bench/'archive-receipt.json')
assert all(receipt[x] for x in ('complete','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
assert receipt['archiveSHA256']==digest(bench/'observations.tar.xz')
rows=read(lab/'allocation/summary.json')
assert len(rows)==10 and all(row['compiled'][0]==row['compiled'][1] and row['admittedPeak'][0]==row['admittedPeak'][1] for row in rows)
ordinary=[row for row in rows if row['case']=='diagnostic.shipment-row-generator-reduction']
assert {row['mode']:row['clr'][0]-row['clr'][1] for row in ordinary}=={'sync':65536,'async':65568}
assert all(abs(row['clr'][0]-row['clr'][1])<=230 for row in rows if row not in ordinary)
logs=list(lab.glob('windows-*net*.log'))+list(lab.glob('ubuntu-*net*.log'))
assert len(logs)==6
for log in logs:
    count=1379 if 'PublicApi' in log.name or 'public' in log.name else 776
    assert re.search(f'Failed: +0, Passed: +{count}, Skipped: +0',log.read_text(encoding='utf-8-sig')),log
output.mkdir(exist_ok=True)
artifacts={name:bench/name for name in ('identity.json','summary.json','observations.tar.xz','archive-receipt.json')}
artifacts['allocation.json']=lab/'allocation/summary.json'
repeat=lab/'repeat'
repeat_id=read(repeat/'identity.json')
assert repeat_id['imageFiles']==identity['imageFiles']
assert repeat_id['catalogs']['representative.json']==identity['catalogs']['representative.json']
assert repeat_id['sourcePatchSHA256']==identity['sourcePatchSHA256']
assert read(repeat/'summary.json')['verifiedTimedBatches']==112
repeat_receipt=read(repeat/'archive-receipt.json')
assert all(repeat_receipt[x] for x in ('complete','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
assert repeat_receipt['archiveSHA256']==digest(repeat/'observations.tar.xz')
for role,manifest in repeat_id['imageFiles'].items():
    assert {path.name:digest(path) for path in (repeat/role).iterdir()}==manifest
    assert digest(repeat/f'{role}-verify.json')==digest(bench/f'{role}-verify.json')
artifacts.update({'repeat-summary.json':repeat/'summary.json','repeat-observations.tar.xz':repeat/'observations.tar.xz'})
for name,source in artifacts.items():
    copy2(source,output/name)
    assert digest(output/name)==digest(source)
procedures={p.name:p for p in logs}
for name in ('candidate.patch','test.patch','test-ubuntu.sh','summarize.py','measure-allocation.py','publish.py','initial-whitebox-build.log'):
    procedures[name]=lab/name
for name in ('collection.log','reference-verify.json','candidate-verify.json','exit-code.txt'):
    procedures[name]=bench/name
for name in ('collection.log','exit-code.txt','archive-receipt.json'):
    procedures['repeat/'+name]=repeat/name
for name in ('prepare-repeat.py','summarize-repeat.py'):
    procedures[name]=lab/name
for p in (lab/'allocation').glob('*.json'):
    procedures['allocation/'+p.name]=p
with tarfile.open(output/'procedures.tar.xz','w:xz') as a:
    for name,source in procedures.items(): a.add(source,arcname=name)
with tarfile.open(output/'procedures.tar.xz') as a:
    assert all(digest(p)==sha256(a.extractfile(name).read()).hexdigest() for name,p in procedures.items())
print('Verified typed callback evidence.')
