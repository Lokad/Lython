#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/regex-template-source-ranges-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
dir=/mnt/d/code/Lython/.git/agent-notes/review-20261031/regex-template-source-ranges-20261122
artifacts="$dir/refined-ubuntu"
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter 'Category!=Stress&(FullyQualifiedName~Regex|FullyQualifiedName~Casing)' --artifacts-path "$artifacts" --nologo > "$dir/refined-white-ubuntu.log" 2>&1 || { tail -55 "$dir/refined-white-ubuntu.log"; exit 1; }
dotnet build tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --artifacts-path "$artifacts" --nologo > "$dir/refined-build-ubuntu.log" 2>&1 || { tail -55 "$dir/refined-build-ubuntu.log"; exit 1; }
cp Directory.Build.props "$artifacts/Directory.Build.props"
fixture="$artifacts/tests/Lokad.Lython.WorkerFixture/bin/Release/net10.0"
mkdir -p "$fixture"
cp -a "$artifacts/bin/Lokad.Lython.WorkerFixture/release_net10.0/." "$fixture/"
cmp "$fixture/Lokad.Lython.dll" "$artifacts/bin/Lokad.Lython.PublicApi.Tests/release_net10.0/Lokad.Lython.dll"
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter 'Category!=Stress&(FullyQualifiedName~Regex|FullyQualifiedName~Fnmatch|FullyQualifiedName~Glob)' --no-build --artifacts-path "$artifacts" --nologo > "$dir/refined-public-ubuntu.log" 2>&1 || { tail -55 "$dir/refined-public-ubuntu.log"; exit 1; }
awk '/Passed!/{count++;print} END{exit count!=2}' "$dir/refined-white-ubuntu.log" "$dir/refined-public-ubuntu.log"
