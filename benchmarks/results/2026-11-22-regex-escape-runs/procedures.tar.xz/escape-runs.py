from pathlib import Path
import sys
p=Path(sys.argv[1])
s=p.read_text(encoding="utf-8")
def replace(old,new):
    global s
    assert s.count(old)==1,old
    s=s.replace(old,new)
replace("internal const int LiteralScalar = -2;","internal const int EscapedRange = -2;")
replace("internal sealed class RegexReplacementPlan(RegexReplacementPiece[] parts, int count,",
        "internal sealed class RegexReplacementPlan(RegexReplacementPiece[] parts, byte[] escaped, int count,")
replace("        private RegexReplacementPiece[] _parts = parts;","        private RegexReplacementPiece[] _parts = parts;\n        private byte[] _escaped = escaped;")
replace("""        private static void AppendLiteral(GovernedByteBuilder builder, PyString template, RegexReplacementPiece part,
            ExecutionContext context, LythonSourceSpan span)
        {
            if (part.Group == RegexReplacementPiece.LiteralRange)
                AppendRegexBytes(builder, template.Utf8Span.Slice(part.Start, part.Length), context, span);
            else
            {
                builder.Append(new Rune(part.Start));
                context.CheckExecution(span);
            }
        }""","""        private void AppendLiteral(GovernedByteBuilder builder, PyString template, RegexReplacementPiece part,
            ExecutionContext context, LythonSourceSpan span)
        {
            var source = part.Group == RegexReplacementPiece.LiteralRange ? template.Utf8Span : _escaped.AsSpan();
            AppendRegexBytes(builder, source.Slice(part.Start, part.Length), context, span);
        }""")
replace("""            _parts = [];
            Interlocked""","""            _parts = [];
            _escaped = [];
            Interlocked""")
replace("""                var count = 0;
                var literalStart = 0;
                void FlushLiteral(int end)
                {
                    if (end != literalStart)
                        parts[count++] = new(RegexReplacementPiece.LiteralRange, literalStart, end - literalStart);
                }
                void AddPiece(RegexReplacementPiece piece, int escapeStart, int escapeEnd)
                {
                    FlushLiteral(escapeStart);
                    parts[count++] = piece;
                    literalStart = escapeEnd;
                }""","""                var count = 0;
                var literalStart = 0;
                byte[]? escapedBytes = null;
                var escapeLength = 0;
                var escapeRunStart = 0;
                long nameScratch = 0;
                void FlushLiterals(int end)
                {
                    if (escapeLength != escapeRunStart)
                    {
                        parts[count++] = new(RegexReplacementPiece.EscapedRange, escapeRunStart, escapeLength - escapeRunStart);
                        escapeRunStart = escapeLength;
                    }
                    if (end != literalStart)
                        parts[count++] = new(RegexReplacementPiece.LiteralRange, literalStart, end - literalStart);
                }
                void AddGroup(int group, int escapeStart, int escapeEnd)
                {
                    FlushLiterals(escapeStart);
                    parts[count++] = new(group, 0, 0);
                    literalStart = escapeEnd;
                }
                void AppendEscape(int value, int escapeStart, int escapeEnd)
                {
                    if (escapeStart != literalStart) FlushLiterals(escapeStart);
                    if (escapedBytes is null)
                    {
                        // Recognized escapes emit at most two UTF-8 bytes
                        // and consume at least two original bytes.
                        var capacity = (int)Math.Min(template.ByteLength, 2L * slashes);
                        storage!.Grow(32L + capacity, span);
                        context.CheckExecution(span);
                        escapedBytes = new byte[capacity];
                    }
                    escapeLength += new Rune(value).EncodeToUtf8(escapedBytes.AsSpan(escapeLength));
                    literalStart = escapeEnd;
                }""")
replace("""                        var group = ResolveReplacementGroup(pattern, name, template, nameStart, context, span);
                        AddPiece(new(group, 0, 0), escapeStart, offset);""","""                        var group = ResolveReplacementGroup(pattern, name, template, nameStart, storage, ref nameScratch, context, span);
                        AddGroup(group, escapeStart, offset);""")
assert s.count("AddPiece(new(RegexReplacementPiece.LiteralScalar, value, 0), escapeStart, offset);")==2
s=s.replace("AddPiece(new(RegexReplacementPiece.LiteralScalar, value, 0), escapeStart, offset);","AppendEscape(value, escapeStart, offset);")
replace("AddPiece(new(RegexReplacementPiece.LiteralScalar, literal, 0), escapeStart, offset);","AppendEscape(literal, escapeStart, offset);")
replace("AddPiece(new(index, 0, 0), escapeStart, offset);","AddGroup(index, escapeStart, offset);")
replace("""                FlushLiteral(source.Length);
                var plan = new RegexReplacementPlan(parts, count, storage);""","""                FlushLiterals(source.Length);
                storage.Shrink(nameScratch);
                context.CheckExecution(span);
                var plan = new RegexReplacementPlan(parts, escapedBytes ?? [], count, storage);""")
replace("            PyString template, int nameStart, ExecutionContext context, LythonSourceSpan span)",
        """            PyString template, int nameStart, MemoryGovernor.TemporaryMemoryReservation storage, ref long nameScratch,
            ExecutionContext context, LythonSourceSpan span)""")
replace("""                using var diagnostic = context.MemoryGovernor.ReserveTemporary(checked(192L + 4L * name.Length), span);
                context.CheckExecution(span);""","""                FundReplacementName(name.Length, storage, ref nameScratch, context, span);""")
replace("""            // Fund the temporary lookup and diagnostic rendering from this
            // name's length. The plan itself keeps no decoded name.
            using var scratch = context.MemoryGovernor.ReserveTemporary(checked(192L + 4L * name.Length), span);
            context.CheckExecution(span);""","""            FundReplacementName(name.Length, storage, ref nameScratch, context, span);""")
anchor="        private static LythonRuntimeException ReplacementError"
replace(anchor,"""        private static void FundReplacementName(int length, MemoryGovernor.TemporaryMemoryReservation storage,
            ref long scratch, ExecutionContext context, LythonSourceSpan span)
        {
            // One name is read at a time. Keep enough temporary funding
            // for the largest lookup and refund it before replay.
            var required = checked(192L + 4L * length);
            if (required <= scratch) return;
            storage.Grow(required - scratch, span);
            scratch = required;
            context.CheckExecution(span);
        }

"""+anchor)
assert "LiteralScalar" not in s
p.write_text(s,encoding="utf-8",newline="\n")
