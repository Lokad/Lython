from hashlib import sha256
from pathlib import Path
from shutil import copyfile
from statistics import median, quantiles
import json
import tarfile


root = Path(__file__).resolve().parent
pair = root / 'comparison'
repo = root.parents[3]
out = repo / 'benchmarks/results/2026-11-27-borrow-regex-arguments'
out.mkdir(exist_ok=True)
read = lambda path: json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')


assert (pair / 'exit-code.txt').read_bytes().strip() == b'0'
identity = read(pair / 'identity.json')
cases = {case['id']: case for case in read(pair / 'representative.json')['cases']}
receipt = read(pair / 'archive-receipt.json')
archive = pair / 'observations.tar.xz'
assert digest(archive) == receipt['archiveSHA256'] and receipt['quietBeforeAndAfter'] is None
assert all(receipt[k] for k in ('complete', 'allWorkersJoined', 'guestFixturesRemoved', 'archivedAndVerifiedUnderLease'))
for role, image in identity['imageFiles'].items():
    proof = read(pair / f'{role}-verify.json')
    assert {p.name: digest(p) for p in (pair / role).iterdir()} == image
    assert proof['state'] == 'Completed' and proof['caseCount'] == 4
    assert proof['launched']['library']['sha256'] == identity['coreSHA256'][role]
    assert proof['launched']['python']['sha256'] == identity['expectedCPythonSHA256']
    assert proof['catalogSha256'] == identity['catalogs']['representative.json']['sha256']
with tarfile.open(archive) as bundle:
    raw = json.load(bundle.extractfile('confirmation/confirmation.json'))
    machine = json.load(bundle.extractfile('confirmation/machine-local.json'))
    assert raw['complete'] and machine['affinity'] == [27]
    assert json.load(bundle.extractfile('identity.json')) == identity
    jobs = json.load(bundle.extractfile('jobs.json'))['warm']
    for name, expected in identity['catalogs'].items():
        assert sha256(bundle.extractfile(name).read()).hexdigest() == expected['sha256']

summary = dict(source=identity['sourceRevision'], reference=identity['productionReference'],
               elapsedSeconds=raw['elapsedSeconds'], timingQualification=False, rows=[])
for job, (case_id, lane) in zip(raw['jobs'], jobs, strict=True):
    assert job['case'] == case_id and job['lane'] == lane and job['workersJoinedAndFixturesRemoved']
    case = cases[case_id]
    elapsed = {}
    cpu = {}
    iqr = []
    for label, worker in job['identities'].items():
        by_name = {Path(entry['path']).name: entry['sha256'].lower() for entry in worker['libraries']}
        assert by_name['Lokad.Lython.dll'] == identity['coreSHA256'][label]
        role = 'candidate' if label.startswith('candidate') else 'reference'
        assert Path(next(entry['path'] for entry in worker['libraries'] if Path(entry['path']).name == 'Lokad.Lython.dll')).parent.name == role
        measurements = [entry for entry in job['samples'] if entry['engine'] == label]
        assert len(measurements) == 7
        times = []
        active = []
        for entry in measurements:
            pre = entry['response']
            assert pre['status'] == 'Completed' and pre['completedInvocations'] > 0
            assert all(pre[key] == case[key] for key in ('sourceSha256', 'fixtureSha256', 'expectedOutputSha256'))
            assert pre['actualOutputSha256'] == case['expectedOutputSha256']
            assert pre['actualFilesSha256'] == case['expectedFilesSha256']
            count = pre['completedInvocations']
            times.append(1000 * pre['elapsedTicks'] / pre['clockFrequency'] / count)
            active.append(1000 * entry['externalProcessCpuTicks'] / entry['externalCpuFrequency'] / count)
        elapsed[label] = median(times)
        cpu[label] = median(active)
        q = quantiles(times, n=4, method='inclusive')
        iqr.append((q[2] - q[0]) * 100 / elapsed[label])
    def change(values):
        changes = [100 * (values[candidate] / values[reference] - 1)
                   for candidate in ('candidate', 'candidate-control')
                   for reference in ('reference', 'reference-control')]
        return [min(changes), max(changes)]
    def spread(values, role):
        bounds = sorted([values[role], values[role + '-control']])
        return 100 * (bounds[1] / bounds[0] - 1)
    row = dict(case=case_id, lane=lane, elapsedMilliseconds=elapsed, cpuMilliseconds=cpu,
               elapsedChangePercent=change(elapsed), cpuChangePercent=change(cpu),
               referenceElapsedSpreadPercent=spread(elapsed, 'reference'),
               candidateElapsedSpreadPercent=spread(elapsed, 'candidate'),
               maximumElapsedIqrPercent=max(iqr))
    summary['rows'].append(row)
    print(case_id, lane, 'elapsed', *map(lambda v: f'{v:.2f}', row['elapsedChangePercent']),
          'CPU', *map(lambda v: f'{v:.2f}', row['cpuChangePercent']),
          'same-image elapsed spread', round(row['referenceElapsedSpreadPercent'], 2),
          round(row['candidateElapsedSpreadPercent'], 2))
summary['verifiedTimedBatches'] = sum(len(job['samples']) for job in raw['jobs'])
assert summary['verifiedTimedBatches'] == 112
write(out / 'summary.json', summary)
copyfile(root / 'allocation' / 'summary.json', out / 'allocation-summary.json')
for name in ('identity.json', 'archive-receipt.json', 'observations.tar.xz'):
    copyfile(pair / name, out / name)
files = [root / name for name in ('prepare.py', 'archive.py', 'candidate.patch', 'regression.patch', 'rebuild.log', 'prepare.log')]
files.extend(root / 'allocation' / f'{role}-{lane}.json' for role in ('reference', 'candidate') for lane in ('sync', 'async'))
files.extend(pair / name for name in ('reference-verify.json', 'candidate-verify.json', 'collection.log', 'exit-code.txt'))
files.extend(root / name for name in ('validate-ubuntu.sh', 'ubuntu.log'))
files.extend(sorted(root.glob('windows-*.log')))
files.extend(path for path in (root / 'initial-attempt').rglob('*') if path.is_file())
with tarfile.open(out / 'procedures.tar.xz', 'w:xz') as bundle:
    for path in files:
        bundle.add(path, arcname=path.relative_to(root))
with tarfile.open(out / 'procedures.tar.xz') as bundle:
    assert all(bundle.extractfile(path.relative_to(root).as_posix()).read() == path.read_bytes() for path in files)
