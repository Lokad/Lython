#!/bin/bash
set -euo pipefail
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
cd /mnt/d/code/Lython
lab="$PWD/.git/agent-notes/review-20261031/borrow-regex-arguments-20261127"
export NUGET_PACKAGES="$PWD/.git/agent-notes/review-20261031/regex-released-050-20261127/packages-ubuntu"
project=tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj
dotnet restore "$project" --locked-mode --artifacts-path "$lab/ubuntu" --source https://api.nuget.org/v3/index.json 2>&1 | tee "$lab/ubuntu-restore.log"
for framework in net10.0 net11.0; do
    dotnet test "$project" -c Release -f "$framework" --no-restore --artifacts-path "$lab/ubuntu" --filter 'Category!=Stress&(FullyQualifiedName~Regex|FullyQualifiedName~Fnmatch|FullyQualifiedName~Glob|FullyQualifiedName~Pathlib|FullyQualifiedName~ExpandedCallExecution|FullyQualifiedName~PositionalCallSemantics|FullyQualifiedName~MathModuleFunction)' 2>&1 | tee "$lab/ubuntu-$framework.log"
done
