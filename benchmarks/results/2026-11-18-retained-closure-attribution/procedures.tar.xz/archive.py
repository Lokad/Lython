from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
out = Path('benchmarks/results/2026-11-18-retained-closure-attribution')
load = lambda p: json.loads(p.read_text(encoding='utf-8'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
terminal = load(lab / 'terminal-status.json')
receipt = load(lab / 'archive-receipt.json')
assert terminal['exitCode'] == '0' and terminal['receipt'] == receipt
assert not terminal['remainingWorkers'] and not terminal['remainingTrace']
assert all(receipt[name] for name in ['complete', 'allWorkersJoined', 'quietBeforeAndAfter',
    'guestFixturesRemoved', 'archivedAndVerifiedUnderLease', 'ramTraceArchivedAndVerifiedBeforeUnmount'])
assert sha(lab / 'observations.tgz') == receipt['archiveSHA256']
for name in ['identity.json', 'catalog.json', 'ops-profile.py', 'collect.py', 'run.sh']:
    assert sha(lab / name) == sha(lab / 'retrieved' / name)
out.mkdir(exist_ok=True)
for name in ['attribution.json', 'terminal-status.json', 'archive-receipt.json', 'observations.tgz']:
    shutil.copyfile(lab / name, out / name)
with tarfile.open(out / 'procedures.tar.xz', 'w:xz', preset=6) as tar:
    for name in ['prepare.py', 'analyze.py', 'retrieve.py', 'archive.py', 'launch.py', 'remote-launch.py', 'launch.log', 'observe-not-before.json']:
        tar.add(lab / name, arcname=name)


