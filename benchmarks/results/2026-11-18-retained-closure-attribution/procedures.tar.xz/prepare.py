from pathlib import Path
import ast
import gzip
import hashlib
import json
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
donor = lab.parent / 'function-annotation-inputs-r581'
previous = lab.parent / 'post-defaults-attribution-r577'
read = lambda p: p.read_text(encoding='utf-8-sig')
load = lambda p: json.loads(read(p))
sha = lambda b: hashlib.sha256(b).hexdigest()
def write(name, value):
    if name.endswith('.py'): ast.parse(value)
    (lab / name).write_text(value, encoding='utf-8', newline='\n')
def save(name, value): write(name, json.dumps(value, indent=2)+'\n')

old = load(previous/'config.json')
source = load(donor/'quiet/config.json')
terminal = load(donor/'quiet/terminal-status.json')
assert terminal['receipt']['complete'] and not terminal['remainingWorkers'] and not terminal['remainingTrace']
assert terminal['receipt']['archiveSHA256'] == sha((donor/'quiet/observations.tgz').read_bytes())
image = source['identity']['imageFiles']['candidate']
assert image['Lokad.Lython.dll'].startswith('62665014') and len(image)==32
assert {name:sha((donor/'frozen/candidate'/name).read_bytes()) for name in image} == image
catalog = (donor/'catalog.json').read_bytes()
assert source['catalogSHA256'] == sha(catalog) == load(donor/'candidate-verify.json')['catalogSha256']
assert load(donor/'candidate-verify.json')['state'] == 'Completed'
head = subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head.startswith('0547e5489')
assert not subprocess.check_output(['git','diff','--name-only','8cfa31043',head,'--','src','tests'])
root='/home/lokad/lython-bench-checks/retained-closure-profile-b1008-20261118'
unit='lython-b1008-retained-closure-profile-20261118'
identity=dict(sourceRevision=head,purpose='Closure factories after retained definition changes',coreSHA256={'candidate':image['Lokad.Lython.dll']},
              imageFiles={'candidate':image},catalogSHA256=sha(catalog),diagnosticOnly=True,publicationHeld=True)
save('identity.json',identity)
(lab/'catalog.json').write_bytes(catalog)
jobs = [('rules', 'scripts.rule-default-closures', 'warm'), ('annotated', 'scripts.annotated-rule-closures', 'warm')]
ops=read(previous/'ops-profile.py').replace(old['root'],root)
p=ops.index('    for name, case_id, lane in ')
e=ops.index(':\n',p)
ops=ops[:p]+'    for name, case_id, lane in '+repr(jobs)+ops[e:]
ops=ops.replace('count = 128 if name == "forwarding" else 256','count = 256')
write('ops-profile.py',ops)
collect=read(previous/'collect.py').replace(old['root'],root).replace("['forwarding', 'rules']", "['rules', 'annotated']")
collect=collect.replace('R577/B1003 53df08565/6c4cb50a forwarding and rule-closure CPU attribution',f'R582/B1008 {head}/62665014 closure CPU attribution')
assert 'B1008' in collect and "['rules', 'annotated']" in collect
write('collect.py',collect)
write('run.sh',read(previous/'run.sh').replace(old['root'],root))
write('launch.py',read(previous/'launch.py').replace('Post-defaults CPU attribution','Retained closure CPU attribution'))
write('retrieve.py',read(previous/'retrieve.py'))
analysis=read(previous/'analyze.py').replace("['forwarding', 'rules']","['rules', 'annotated']")
analysis=analysis.replace("     'formatting':", """     'definition execution':('CreateExecutableFunctionAsync','CreateLambdaFunction','ExecutePreparedDefinitionOperationAsync'),
     'closure retention':('ChargeClosureRetention','CaptureExecutableClosures'),
     'live argument frame':('CreateNativeContinuation','EnterInvocationFrame','ExecuteInitializedFrame','RentFunctionArgumentStorage'),
     'function defaults':('PendingFunctionDefaults','EvaluateDefaultsAsync','TryGetPositionalDefault','TryGetNativeKeywordIndex'),
     'formatting':""")
write('analyze.py',analysis)
names=['identity.json','catalog.json','ops-profile.py','collect.py','run.sh']
with tarfile.open(lab/'payload.tgz','w:gz') as out:
    for name in names: out.add(lab/name,arcname=name)
expanded=sum((lab/name).stat().st_size for name in names)
# The previously verified inventory names every hard link. The launcher
# repeats all checks under a fresh idle lease before retiring this replica.
inventory=load(lab.parent/'executable-definition-inputs-r578/quiet-space.json')
retire=next(row for row in inventory['replicas'] if row['sha256'].startswith('a5038a28'))
canonical=subprocess.check_output(['git','show',f"origin/master:{retire['canonical']}"])
assert canonical==Path(retire['canonical']).read_bytes() and sha(canonical)==retire['canonicalSHA256']
raw=gzip.decompress(canonical)
assert sha(raw)==retire['sha256'] and len(raw)==retire['bytes']
cfg=dict(root=root,unit=unit,source=source['root'],sourceFiles=image,sourceCatalogSHA256=sha(catalog),catalogSHA256=sha(catalog),
         identity=identity,retireGroups=[retire],payloadBytes=(lab/'payload.tgz').stat().st_size,
         payloadSHA256=sha((lab/'payload.tgz').read_bytes()),unpackedBytes=expanded)
save('config.json',cfg)
launcher=read(previous/'remote-launch.py')
l,r=launcher.index('\nc=')+1,launcher.index('\nb=Path(')
write('remote-launch.py',(launcher[:l]+'c='+repr(cfg)+launcher[r:]).replace('lython-b1003-fixtures','lython-b1008-fixtures'))
