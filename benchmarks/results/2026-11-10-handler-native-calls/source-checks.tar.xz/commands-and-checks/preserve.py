from pathlib import Path
import hashlib,json,shutil,tarfile
root=Path('D:/code/Lython');home=Path(__file__).parent;out=root/'benchmarks/results/2026-11-10-handler-native-calls';out.mkdir()
for name in ['identity.json','source.patch','desktop-summary.json','cpython-goldens.json','rejected-six-case-catalog.json','vm-preflight.json']:
    shutil.copyfile(home/name,out/name)
for name in ['summary.json','archive-receipt.json','terminal-status.json','observations.tgz','space-recovery.json','payload-sizing.json','identity.json','observe-not-before.json']:
    p=home/'b522'/name;dest=out/'quiet'/name;dest.parent.mkdir(exist_ok=True)
    if p.exists():shutil.copyfile(p,dest)
with tarfile.open(out/'source-checks.tar.xz','w:xz')as t:
    for p in home.iterdir():
        if p.is_file():t.add(p,arcname='commands-and-checks/'+p.name)
    for lane in ['warm-sync','warm-async','compile-sync','rejected-six-case-attempt']:t.add(home/lane,arcname=lane)
    for name in ['src/Lokad.Lython/Runtime/PyExecutableFunction.cs','tests/Lokad.Lython.PublicApi.Tests/FramedFunctionExecutionTests.cs','tests/Lokad.Lython.PublicApi.Tests/NativeReturnFunctionTests.cs']:t.add(root/name,arcname='source/'+name)
    for p in (home/'b522').glob('*.py'):t.add(p,arcname='commands-and-checks/b522/'+p.name)
(out/'status.json').write_text(json.dumps(dict(status='Retained candidate; full delivery and bounded ordinary-control confirmation pending',focusedPublicEachTarget=79,pythonSemanticCases=6,quietJobs=5,archiveSHA256=hashlib.sha256((out/'quiet/observations.tgz').read_bytes()).hexdigest(),terminalCached=True,remainingWorkersAndFixtures=False,limitations=['Specific active-handler call cliff, not ordinary script universal gain','Adverse report and Unicode controls unresolved','Desktop isolated allocation comparison uses R178 baseline; quiet comparison qualified R173 baseline with R178+R179 candidate']),indent=2)+'\n')
print('Retained first quiet outcome, every adverse control, original failed setup and final focused checks. No live VM users.')
