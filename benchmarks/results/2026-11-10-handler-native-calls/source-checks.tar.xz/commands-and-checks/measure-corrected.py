from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,textwrap
root=Path('D:/code/Lython'); home=Path(__file__).parent
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11'
env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe'
env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
def runlog(label,args,timeout=180):
    with (home/(label+'.log')).open('w',encoding='utf-8') as log:
        done=subprocess.run([env['DOTNET_HOST_PATH'],*args],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
    assert done.returncode==0,(home/(label+'.log')).read_text(encoding='utf-8')[-3000:]
    print(label,'passed',flush=True)
summary={}
for phase,api in [('warm','sync'),('warm','async'),('compile','sync')]:
    folder=home/(phase+'-'+api);folder.mkdir()
    witness=folder/'hash-witness.json';witness.write_text(json.dumps(dict(source="return [hash('Lython-é😀'), hash((1, 2.0, True))]\n"),ensure_ascii=False)+'\n',encoding='utf-8')
    with (folder/'measurements.json').open('w',encoding='utf-8') as out,(folder/'stderr.txt').open('w',encoding='utf-8') as err:
        done=subprocess.run([env['DOTNET_HOST_PATH'],str(home.parent/'bulk-whitespace-r157/tool/out/complete-jobs.dll'),str(home/'images/before/Lokad.Lython.Benchmarks.dll'),str(home/'images/candidate/Lokad.Lython.Benchmarks.dll'),str(home/'catalog.json'),str(witness),'reverse',phase,api],env=env,stdout=out,stderr=err,timeout=120)
    assert done.returncode==0,(folder/'stderr.txt').read_text()[-2500:]
    data=json.loads((folder/'measurements.json').read_text())
    assert all(data[k] for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
    summary[phase+'-'+api]=data
    print(phase,api,'passed',flush=True)
(home/'desktop.json').write_text(json.dumps(summary,indent=2)+'\n')
