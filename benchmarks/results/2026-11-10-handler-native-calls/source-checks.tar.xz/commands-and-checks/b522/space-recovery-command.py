from pathlib import Path
import fcntl,hashlib,json,os,shutil,stat,subprocess
base=Path('/home/lokad/lython-bench-checks')
spec=[{'path': '/home/lokad/lython-bench-checks/json-record-capacity-b468-20261108/observations.tgz', 'size': 4307842, 'sha256': 'cf4bb6544c8bb3db587bab80b364d1c3b089cc3edaf6dab602b96fcc27793127', 'preservedLocal': 'D:/code/Lython/benchmarks/results/2026-11-08-json-record-capacity-initial/observations.tar.xz', 'preservedMember': 'b468/observations.tgz', 'tracked': True, 'outerSHA256': '96a712b617854b9a4c1a0ec49f0c2efa74d214ceb10b82ac81d7ddeac62b71b2'}, {'path': '/home/lokad/lython-bench-checks/refined-record-capacity-b469-20261108/observations.tgz', 'size': 4307605, 'sha256': '3386de9c03c6e856e600181a12de8a9c3a050e654773ce4582449e9ed29b4399', 'preservedLocal': 'D:/code/Lython/benchmarks/results/2026-11-08-json-record-capacity/observations.tar.xz', 'preservedMember': 'b469/observations.tgz', 'tracked': True, 'outerSHA256': '7175e5ff4278e270c88cab6f6ce5d2536ceb647e2c5d5ec6acc360fa7996277a'}, {'path': '/home/lokad/lython-bench-checks/dedicated-comparison-b456-20261108/observations.tgz', 'size': 3927751, 'sha256': 'f1e7e170c47939bda7ef7f499312c879badbf1c9d2e23930c6ce9109b77308ad', 'preservedLocal': 'D:/code/Lython/benchmarks/results/2026-11-08-direct-comparison-branches/observations.tar.xz', 'preservedMember': 'b456/observations.tgz', 'tracked': True, 'outerSHA256': '93b2f6b295a920a072ee9db7812efd291374a02678de732cf08dbcdb79ab796c'}]
with (base/'comparison-vm.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not (base/'handler-native-entry-b522-20261110').exists()
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*')) and not Path('/dev/shm/lython-b512').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[o]ps-profile.py'],capture_output=True).returncode==1
 free=shutil.disk_usage(base).free
 if free>271126528:
  print(json.dumps(dict(skipped=True,beforeFreeBytes=free,requiredFreeBytes=271126528,reason='Fresh space sufficient; no mutation')));__import__('sys').exit(0)
 rows=[];unavailable=[]
 for entry in spec:
  p=Path(entry['path'])
  if not p.exists():unavailable.append(entry['path']);continue
  assert p.resolve(strict=True)==p and p.parent.parent==base and p.name=='observations.tgz'
  info=p.lstat();assert stat.S_ISREG(info.st_mode) and info.st_nlink==1 and info.st_uid==os.getuid() and info.st_gid==os.getgid()
  assert info.st_size==entry['size'] and hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256']
  receipt=json.loads((p.parent/'archive-receipt.json').read_text());receipt=receipt.get('receipt',receipt);assert receipt['complete'] and receipt['allWorkersJoined'] and receipt['archiveSHA256']==entry['sha256']
  parents=[]
  for parent in p.parents:
   meta=parent.lstat();assert stat.S_ISDIR(meta.st_mode) and not parent.is_symlink()
   parents.append(dict(path=str(parent),uid=meta.st_uid,gid=meta.st_gid,mode=oct(meta.st_mode)))
  rows.append(dict(**entry,device=info.st_dev,inode=info.st_ino,links=info.st_nlink,uid=info.st_uid,gid=info.st_gid,mode=oct(info.st_mode),parents=parents,allAliases=[str(p)]))
  if free+sum(Path(e['path']).stat().st_blocks*512 for e in rows)>271126528:break
 assert free+sum(Path(e['path']).stat().st_blocks*512 for e in rows)>271126528, ('Exact copies cannot fund unchanged payload/floors; no mutation',dict(freeBytes=free,requiredBytes=271126528,selectedBytes=sum(Path(e['path']).stat().st_blocks*512 for e in rows),unavailable=unavailable))
 plan=dict(requiredFreeBytes=271126528,freshIdleLease=True,beforeFreeBytes=free,osFloorMiB=240,evidenceHeadroomMiB=12,files=rows,unavailable=unavailable,operation='Remove only redundant remote compressed archives. Their raw trees, receipts, frozen workers and byte-identical tracked local archives survive.')
 target=base/'handler-native-entry-b522-space-plan.json'
 with target.open('x') as f:f.write(json.dumps(plan,indent=2)+'\n');f.flush();os.fsync(f.fileno())
 for entry in rows:
  p=Path(entry['path']);info=p.lstat()
  assert info.st_dev==entry['device'] and info.st_ino==entry['inode'] and info.st_nlink==1 and hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256']
  p.unlink()
 plan['afterFreeBytes']=shutil.disk_usage(base).free
 assert plan['afterFreeBytes']>271126528 and plan['afterFreeBytes']>free and plan['afterFreeBytes']>(240+12)*1024*1024
 (base/'handler-native-entry-b522-space-receipt.json').write_text(json.dumps(plan,indent=2)+'\n')
 print(json.dumps(plan))
