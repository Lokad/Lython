from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
root=Path('D:/code/Lython');home=Path(__file__).parent;old=home.parent/'bound-native-entry-r177/b521';dest=home/'b522';dest.mkdir()
local=json.loads((home/'identity.json').read_text())
for name,digest in local['productionSources'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
identity=json.loads((old/'identity.json').read_text())
identity['sourceRevision']='fcf018d2 plus R178 terminal JSON buffer transfer and R179 closed-native caller-handler exclusion removal. Compare qualified cac4acf8-equivalent R173 baseline. Text script performs no JSON serialization; JSON changes affect neither its source nor input/output.'
identity['coreSHA256']={role:('e833f03ce220fe7569b6cc2db89bb3a93504773b3b5e33a9e1b92a4d4d4c55ba' if role.startswith('reference') else local['cores']['candidate']) for role in ['reference','reference-control','candidate','candidate-control']}
identity['catalogSHA256']=hashlib.sha256((home/'catalog.json').read_bytes()).hexdigest()
(dest/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
files={'current-core.dll':home/'images/candidate/Lokad.Lython.dll','representative.json':home/'catalog.json','baseline-source.json':home.parent/'bound-native-entry-r177/baseline.json','final-source.json':home/'identity.json','source.patch':home/'source.patch','FramedFunctionExecutionTests.cs':root/'tests/Lokad.Lython.PublicApi.Tests/FramedFunctionExecutionTests.cs'}
for name in ['LythonRuntime.Json.Serialize.cs','LythonRuntime.Json.Options.cs','PyExecutableFunction.cs']:files[name]=root/'src/Lokad.Lython/Runtime'/name
for name,p in files.items():shutil.copyfile(p,dest/name)
def adapt(text):return text.replace('bound-native-entry-b521-20261110','handler-native-entry-b522-20261110').replace('lython-b521-bound-native-entry-20261110','lython-b522-handler-native-entry-20261110').replace('lython-b521-fixtures','lython-b522-fixtures').replace('R177A framed native-entry deletion','R179 closed native calls under active handlers')
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py']:
    text=adapt((old/name).read_text())
    text=text.replace("'LythonRuntime.Executable.Calls.cs','LythonRuntime.Executable.NativeReturn.cs'","'LythonRuntime.Json.Serialize.cs','LythonRuntime.Json.Options.cs'")
    (dest/name).write_text(text,encoding='utf-8',newline='\n')
for name in ['setup-contract.json','sizing.json']:shutil.copyfile(old/name,dest/name)
(dest/'focused.json').write_text(json.dumps(dict(net11Public=75,net10Public=75,cpythonSemanticCases=6,priorR178InternalEachTarget=193,priorR178PublicEachTarget=861,fullCheckpointPending=True),indent=2)+'\n')
contract='''R179 closed-native calls while the caller owns active handler aliases.
Baseline qualified R173; candidate also includes R178 JSON terminal transfer,
which is not exercised by affected text (no JSON serialization).
Same source/catalog/goldens and five-job protocol as B521: four processes,
two/source,5s warmup/role,7rotated150msrounds, ordinary GC/tiering.
CSV/report/Unicode controls unchanged. Not a published CPython comparison.
Includes mediated RAM I/O/full validation/prior-result cleanup, excludes startup,
reset/protocol/final caches. ProcessCPU wider; compilation measured separately.
Keep all adverse observations. Finite210s owner/30sstop/30smargin; join/unmount,
archive under ownership and localSHA. No instruction/work policies or GC forcing.
'''
for name in ['contract.md','pre-measurement-plan.md']:(dest/name).write_text(contract)
with tarfile.open(dest/'payload.tgz','w:gz')as t:
    for p in sorted(dest.iterdir()):
        if p.is_file()and p.name!='payload.tgz':t.add(p,arcname=p.name)
with tarfile.open(dest/'payload.tgz')as t:required=sum(((m.size+4095)//4096)*4096 for m in t.getmembers())+(240+12)*1024*1024+65536+256*1024
(dest/'payload-sizing.json').write_text(json.dumps(dict(requiredFreeBytes=required,payloadBytes=(dest/'payload.tgz').stat().st_size),indent=2)+'\n')
spec=[]
for remote,folder,member in [('json-record-capacity-b468-20261108','2026-11-08-json-record-capacity-initial','b468/observations.tgz'),('refined-record-capacity-b469-20261108','2026-11-08-json-record-capacity','b469/observations.tgz'),('dedicated-comparison-b456-20261108','2026-11-08-direct-comparison-branches','b456/observations.tgz')]:
    outer=root/'benchmarks/results'/folder/'observations.tar.xz'
    assert subprocess.check_output(['git','ls-files','--',outer.relative_to(root).as_posix()],text=True).strip()==outer.relative_to(root).as_posix()
    with tarfile.open(outer)as t:data=t.extractfile(member).read()
    spec.append(dict(path='/home/lokad/lython-bench-checks/'+remote+'/observations.tgz',size=len(data),sha256=hashlib.sha256(data).hexdigest(),preservedLocal=outer.as_posix(),preservedMember=member,tracked=True,outerSHA256=hashlib.sha256(outer.read_bytes()).hexdigest()))
script=adapt((old/'space-recovery-command.py').read_text())
script=script.replace('bound-native-entry-b521','handler-native-entry-b522').replace('271130624',str(required))
script='\n'.join('spec='+repr(spec)if line.startswith('spec=')else line for line in script.splitlines())+'\n'
(dest/'space-recovery-command.py').write_text(script)
text=(old/'recover-space.py').read_text();text=adapt(text)
(dest/'recover-space.py').write_text(text)
payload=(dest/'payload.tgz').read_bytes()
script=adapt((old/'launch-command.py').read_text())
script='\n'.join(' payload=sys.stdin.buffer.read('+str(len(payload))+'+1);assert len(payload)=='+str(len(payload))+' and hashlib.sha256(payload).hexdigest()=='+repr(hashlib.sha256(payload).hexdigest()) if line.startswith(' payload=')else line for line in script.splitlines())+'\n'
(dest/'launch-command.py').write_text(script)
launch=(old/'launch.py').read_text();start=launch.index('script=');end=launch.index("ssh=[",start)
launch=launch[:start]+"script=(home/'launch-command.py').read_text()\n"+launch[end:]
launch=adapt(launch).replace('bound-native-entry-b521-launch','handler-native-entry-b522-launch').replace('B521','B522')
(dest/'launch.py').write_text(launch)
print('Prepared bounded B522 with existing unchanged protocol. Required free bytes',required,'payload',len(payload))
