from pathlib import Path
import hashlib,json,os,re,shutil,subprocess,textwrap
root=Path('D:/code/Lython'); home=Path(__file__).parent
env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11'
env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe'
env['PATH']=env['DOTNET_ROOT']+os.pathsep+'C:/Python313'+os.pathsep+env['PATH']
def runlog(label,args,timeout=180):
    with (home/(label+'.log')).open('w',encoding='utf-8') as log:
        done=subprocess.run([env['DOTNET_HOST_PATH'],*args],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
    assert done.returncode==0,(home/(label+'.log')).read_text(encoding='utf-8')[-3000:]
    print(label,'passed',flush=True)
source=(root/'tests/Lokad.Lython.PublicApi.Tests/FramedFunctionExecutionTests.cs').read_text()
cases=[]
for name,body,expected in re.findall(r'\{ "([^"]+)", """\n(.*?)\n\s+""", "((?:\\.|[^"\\])*)" \}',source,re.S):
    body=textwrap.dedent(body)
    python='\n'.join(line for line in body.splitlines() if not line.startswith('return '))+'\n'
    result=subprocess.run(['C:/Python313/python.exe','-X','utf8','-I','-c',python],capture_output=True,encoding='utf-8',timeout=10)
    expected=json.loads('"'+expected+'"')
    assert result.returncode==0 and result.stdout==expected,(name,result.stdout,result.stderr,expected)
    cases.append(dict(name=name,source=body,stdout=result.stdout))
assert len(cases)==6
(home/'cpython-goldens.json').write_text(json.dumps(dict(version='3.13.2',cases=cases),indent=2)+'\n')
runlog('public10',['test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f','net10.0','--filter','FullyQualifiedName~FramedFunctionExecutionTests|FullyQualifiedName~NativeReturnFunctionTests|FullyQualifiedName~CallInputLifetimeTests'])
runlog('freeze11',['build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-incremental'])
shutil.copytree(home.parent/'json-terminal-storage-r178/images/candidate',home/'images/before')
shutil.copytree(home/'images/before',home/'images/candidate')
shutil.copyfile(root/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',home/'images/candidate/Lokad.Lython.dll')
shutil.copyfile(home.parent/'bound-native-entry-r177/catalog-corrected.json',home/'catalog.json')
assert all(p.read_bytes()==(home/'images/candidate'/p.name).read_bytes() for p in (home/'images/before').iterdir() if p.is_file() and p.name!='Lokad.Lython.dll')
(home/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','src/Lokad.Lython','tests/Lokad.Lython.PublicApi.Tests/FramedFunctionExecutionTests.cs'],stderr=subprocess.DEVNULL))
(home/'identity.json').write_text(json.dumps(dict(cores={role:hashlib.sha256((home/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest() for role in ['before','candidate']},
    productionSources={p.as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'src/Lokad.Lython').rglob('*.cs') if 'obj' not in p.parts},
    comparison='R178 versus R178 plus closed-native caller-handler exclusion removal. Same original active-handler complete text script as B521; unchanged four controls. Desktop elapsed diagnostic only.'),indent=2)+'\n')
summary={}
for phase,api in [('warm','sync'),('warm','async'),('compile','sync')]:
    folder=home/(phase+'-'+api);folder.mkdir()
    witness=folder/'hash-witness.json';witness.write_text(json.dumps(dict(source="return [hash('Lython-é😀'), hash((1, 2.0, True))]\n"),ensure_ascii=False)+'\n',encoding='utf-8')
    with (folder/'measurements.json').open('w',encoding='utf-8') as out,(folder/'stderr.txt').open('w',encoding='utf-8') as err:
        done=subprocess.run([env['DOTNET_HOST_PATH'],str(home.parent/'bulk-whitespace-r157/tool/out/complete-jobs.dll'),str(home/'images/before/Lokad.Lython.Benchmarks.dll'),str(home/'images/candidate/Lokad.Lython.Benchmarks.dll'),str(home/'catalog.json'),str(witness),'reverse',phase,api],env=env,stdout=out,stderr=err,timeout=120)
    assert done.returncode==0,(folder/'stderr.txt').read_text()[-2500:]
    data=json.loads((folder/'measurements.json').read_text())
    assert all(data[k] for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
    summary[phase+'-'+api]=data
    print(phase,api,'passed',flush=True)
(home/'desktop.json').write_text(json.dumps(summary,indent=2)+'\n')
