R179 closed-native calls while the caller owns active handler aliases.
Baseline qualified R173; candidate also includes R178 JSON terminal transfer,
which is not exercised by affected text (no JSON serialization).
Same source/catalog/goldens and five-job protocol as B521: four processes,
two/source,5s warmup/role,7rotated150msrounds, ordinary GC/tiering.
CSV/report/Unicode controls unchanged. Not a published CPython comparison.
Includes mediated RAM I/O/full validation/prior-result cleanup, excludes startup,
reset/protocol/final caches. ProcessCPU wider; compilation measured separately.
Keep all adverse observations. Finite210s owner/30sstop/30smargin; join/unmount,
archive under ownership and localSHA. No instruction/work policies or GC forcing.
