using System.Numerics;
using Lokad.Lython.Tests.Harness;

namespace Lokad.Lython.PublicApi.Tests;

/// <summary>
/// MG08: math.prod owns its running product like the other accumulations do.
/// Two hundred thousand-digit factors must exceed a 64KiB budget in both
/// modes. Each retained product is small; only their accumulation trips.
/// </summary>
public sealed class MathProdAccountingScenarioTests
{
    [Theory, InlineData(false), InlineData(true)]
    public async Task StartsAndNumericTransitionsFollowPython(bool asynchronous)
    {
        const string source = """
            import math
            for start in [True, False, 1234567890123456789, 1.5, -0.0]:
                result = math.prod([], start=start)
                print(result is start, type(result).__name__, repr(result))
            print(math.prod([True, False, 2]), math.prod([2, 3.5], start=2), math.prod([-2, -3], start=-1))
            print(math.prod([1 << 63, 2]), math.prod([1 << 63, -2]))
            """;
        const string expected = """
            True bool True
            True bool False
            True int 1234567890123456789
            False float 1.5
            False float -0.0
            0 14.0 -6
            18446744073709551616 -18446744073709551616

            """;
        var budget = new LythonMemoryBudget(2 * 1024 * 1024);
        using (var script = new LythonEngine().Compile(source, budget))
        {
            Assert.True(script.IsValid);
            var held = budget.ReservedBytes;
            var options = new LythonRunOptions { MemoryBudget = budget, ResultMemoryBudget = budget };
            using (var result = asynchronous ? await script.RunAsync(new MockLythonHost(), options)
                : script.Run(new MockLythonHost(), options))
            {
                Assert.True(result.Success, result.Failure?.Message);
                Assert.Equal(expected.ReplaceLineEndings("\n"), result.StandardOutput);
            }
            Assert.Equal(held, budget.ReservedBytes);
        }
        Assert.Equal(0, budget.ReservedBytes);
    }

    [Fact]
    public async Task ManyRetainedProductsStayCharged()
    {
        var script = new LythonEngine(Utf8RegexProvider.Instance).Compile(
            """
            import math
            xs = [10 ** 100] * 200
            rs = []
            i = 0
            while i < 20:
                rs.append(math.prod(xs))
                i = i + 1
            return 0
            """);
        Assert.True(script.IsValid);
        var options = new LythonRunOptions { MemoryBudget = new LythonMemoryBudget(65536) };
        var sync = script.Run(new MockLythonHost(), options);
        Assert.False(sync.Success);
        Assert.Equal("MemoryError", sync.Failure?.ExceptionType);

        var asyncResult = await script.RunAsync(new MockLythonHost(), options);
        Assert.False(asyncResult.Success);
        Assert.Equal("MemoryError", asyncResult.Failure?.ExceptionType);
    }

    [Fact]
    public async Task ProdBehaviorsStillProject()
    {
        var script = new LythonEngine(Utf8RegexProvider.Instance).Compile(
            """
            import math
            return [math.prod([2, 3, 4]), math.prod([], start=5)]
            """);
        Assert.True(script.IsValid);
        var expected = new List<object?> { new BigInteger(24), new BigInteger(5) };
        var sync = script.Run(new MockLythonHost());
        Assert.True(sync.Success, sync.Failure?.Message);
        Assert.Equal(expected, sync.ReturnValue);

        var asyncResult = await script.RunAsync(new MockLythonHost());
        Assert.True(asyncResult.Success, asyncResult.Failure?.Message);
        Assert.Equal(expected, asyncResult.ReturnValue);
    }
}
