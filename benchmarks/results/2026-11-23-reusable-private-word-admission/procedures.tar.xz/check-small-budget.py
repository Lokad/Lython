from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
out=lab/"small-budget"
out.mkdir()
pair=lab/"comparison"
identity=json.loads((pair/"identity.json").read_text(encoding="utf-8"))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,s):p.write_text(s,encoding="utf-8",newline="\n")
counter=lab/"admission-counter"
text=(counter/"Program.cs").read_text(encoding="utf-8")
text=text.replace('    var source = item.GetProperty("source").GetString()!;', '''    if (item.GetProperty("id").GetString() != "diagnostic.text-summary.nonlocal-computed-width.large") continue;
    var source = item.GetProperty("source").GetString()!;''')
text=text.replace("new LythonMemoryBudget(256L * 1024 * 1024)", "new LythonMemoryBudget(1_000_000)")
text=text.replace("        void Run()",'''        LythonFailureReason? reason = null;
        bool success = false;
        void Run()''')
point='''                if (!result.Success || result.StandardOutput != expected || result.StandardError != "")'''
text=text.replace(point,'''                success = result.Success;
                if (!success)
                {
                    reason = result.Failure?.Attribution?.Reason;
                    if (reason != LythonFailureReason.SharedMemoryAllowance)
                        throw new InvalidDataException(result.Failure?.Message);
                    return;
                }
                if (result.StandardOutput != expected || result.StandardError != "")''')
text=text.replace("        Run();\n        rows.Add",'''        Run();
        if (budget.ReservedBytes != baseline) throw new InvalidOperationException("Ownership did not return to compilation baseline.");
        rows.Add''')
text=text.replace("asynchronous, peakExecutionMemoryBytes,", "asynchronous, success, reason = reason?.ToString(), peakExecutionMemoryBytes,")
text=text.replace("One golden-verified warm execution and its cleanup. Counts successful positive and negative changes at the host execution allowance. Compilation and result scopes are passed directly to the original allowance.",
                  "One nonlocal report with a 1,000,000-byte shared allowance including compilation, execution and projection. Compare successful result and first admission failure, and verify cleanup.")
save(out/"Program.cs",text)
file=(counter/"AdmissionCounter.csproj").read_text(encoding="utf-8")
project=out/"BudgetCheck.csproj"
save(project,file)
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
with (out/"build.log").open("w",encoding="utf-8") as log:
    subprocess.run([dotnet,"build",project,"-c","Release","--no-incremental"],cwd=out,env=env,check=True,timeout=75,stdout=log,stderr=subprocess.STDOUT)
for role,manifest in identity["imageFiles"].items():
    image=pair/("frozen-"+role)
    assert {n:sha(image/n)for n in manifest}==manifest
    for p in (out/"bin/Release/net11.0").glob("BudgetCheck.*"):
        shutil.copyfile(p,image/p.name)
    report=out/(role+".json")
    subprocess.run([dotnet,image/"BudgetCheck.dll",image,pair/"representative.json",report],env=env,check=True,timeout=60)
    assert {n:sha(image/n)for n in manifest}==manifest
    one, = json.loads(report.read_text(encoding="utf-8"))["rows"]
    assert one["success"]==(role=="candidate") and one["sharedBudgetBaselineRestored"]
    assert one["coreSha256"]==manifest["Lokad.Lython.dll"]
    print(role, one["success"], one["reason"], one["peakExecutionMemoryBytes"],one["compiledReservedBytes"],flush=True)
