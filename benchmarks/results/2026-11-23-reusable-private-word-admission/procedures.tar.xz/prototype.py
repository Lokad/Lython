from pathlib import Path
root=Path(".git/agent-worktrees/reuse-private-word-admission-20261123")

def edit(name, mapper):
    p=root/name
    raw=p.read_bytes()
    text=raw.decode("utf-8").replace("\r\n","\n")
    result=mapper(text)
    assert result!=text
    p.write_bytes(result.replace("\n","\r\n" if b"\r\n" in raw else "\n").encode("utf-8"))

def replace(text,old,new):
    assert text.count(old)==1,old[:100]
    return text.replace(old,new)

def implementation(text):
    text=replace(text,
"""    // Admit every eventual word before the first loop effect, just as eager split
    // does. The execution owner retains unused capacity until its normal cleanup.""",
"""    // Admit every eventual word before the first loop effect, just as eager split
    // does. Unused capacity can fund the next loan of the same scratch cursor.""")
    a=text.index("            // Prepay every eventual immutable word")
    b=text.index("        }\n        finally",a)
    text=text[:a]+"""            prepared.Initialize(context, span, used, outputBytes);
            var result = prepared;
            prepared = null;
            return result;
"""+text[b:]
    text=replace(text,"        private bool _loaned = true;",
"""        private bool _loaned = true;
        private long _unpublishedWordBytes;""")
    text=replace(text,"        internal long StorageBytes => HeaderBytes + EncodedStorageBytes(EncodedCapacity);\n","")
    text=replace(text,
"""            try { ReleaseEncoded(); }
            finally { _owner.Release(HeaderBytes); }""",
"""            var unused = _unpublishedWordBytes;
            _unpublishedWordBytes = 0;
            try { ReleaseEncoded(); }
            finally { _owner.Release(checked(HeaderBytes + unused)); }""")
    text=replace(text,
"""        internal void Initialize(LythonRuntime.ExecutionContext context, LythonSourceSpan span, int length)
        {
            _context = context;
            _span = span;
            _length = length;
            _position = 0;
        }""",
"""        internal void Initialize(LythonRuntime.ExecutionContext context, LythonSourceSpan span, int length,
            long wordBytes)
        {
            // Reserve the entire batch before its first loop effect. Earlier
            // loans can reuse storage only if no word received its ownership.
            var growth = Math.Max(0, wordBytes - _unpublishedWordBytes);
            _owner.Reserve(growth, span);
            try
            {
                context.CheckExecution(span);
                _owner.Commit(growth);
                _unpublishedWordBytes += growth;
                _context = context;
                _span = span;
                _length = length;
                _position = 0;
            }
            catch { _owner.ReleaseReserved(growth); throw; }
        }""")
    text=replace(text,"return PyIterationResult.Yield(CreateSplitFragment(_encoded.AsSpan(), range, null, _owner, _span, _context));",
        "return PyIterationResult.Yield(Materialize(range));")
    text=replace(text,"word = CreateSplitFragment(_encoded.AsSpan(), range, null, _owner, _span, _context);","word = Materialize(range);")
    text=replace(text,"""        // The eager preflight already funds this value. Unwind must be able""",
"""        private PyString Materialize((int Start, int End, int Capacity) range)
        {
            var charge = WordCharge(range.Capacity);
            var result = CreateSplitFragment(_encoded.AsSpan(), range, null, _owner, _span, _context);
            _unpublishedWordBytes -= charge;
            return result;
        }

        private long WordCharge(int length)
        {
            var charge = PyString.EstimateApproximateBytes(length);
            if (charge > _unpublishedWordBytes)
                throw new InvalidOperationException("Cased word was materialized without prepaid storage.");
            return charge;
        }

        // The eager preflight already funds this value. Unwind must be able""")
    text=replace(text,"""            var value = PyString.CreateReservedUtf8(bytes.Length, _owner);
            bytes.CopyTo(value.UnpublishedUtf8);
            value.CompleteUnpublishedUtf8(bytes.Length);
            return value;""",
"""            var charge = WordCharge(bytes.Length);
            var value = PyString.CreateReservedUtf8(bytes.Length, _owner);
            bytes.CopyTo(value.UnpublishedUtf8);
            value.CompleteUnpublishedUtf8(bytes.Length);
            _unpublishedWordBytes -= charge;
            return value;""")
    return text

def test(text):
    point="    [Theory]\n    [InlineData(false), InlineData(true)]\n    public void WordAdvancementUsesPrepaidStorage"
    return replace(text,point,"""    [Fact]
    public void AnUnpublishedWordBatchFundsLaterLoansWhileAnEscapedWordStaysCharged()
    {
        var budget = new LythonMemoryBudget(64 * 1024);
        using (var owner = budget.CreateScope())
        {
            var hook = new AdmissionHookMemoryBudget(owner);
            var context = new LythonRuntime.ExecutionContext(new MockLythonHost(), new() { MemoryBudget = hook });
            var span = new LythonSourceSpan(0, 1, 1, 1);
            var input = PyString.FromString("FIRST SECOND THIRD");
            PyString retained;
            using (var cursor = PyStringOps.PrepareCasedWhitespaceIteration(input, false, context, span))
            {
                Assert.True(cursor.TryReadWord(out var bytes, out var word));
                Assert.Null(word);
                retained = cursor.Materialize(bytes);
            }
            // A new batch replenishes the escaped word's allowance once.
            using (PyStringOps.PrepareCasedWhitespaceIteration(input, false, context, span)) { }
            var allowance = budget.ReservedBytes;
            hook.RefuseGrowth = _ => throw new InvalidOperationException("Previously funded batch requested more storage.");
            for (var iteration = 0; iteration < 4; iteration++)
            {
                using var cursor = PyStringOps.PrepareCasedWhitespaceIteration(input, false, context, span);
                var count = 0;
                while (cursor.TryReadWord(out var bytes, out var word))
                {
                    Assert.False(bytes.IsEmpty);
                    Assert.Null(word);
                    count++;
                }
                Assert.Equal(3, count);
                Assert.Equal(allowance, budget.ReservedBytes);
            }
            context.State.CloseResources();
            Assert.Equal(retained.CommittedOwnedBytes, budget.ReservedBytes);
            Assert.Equal("first", retained.AsString());
        }
        Assert.Equal(0, budget.ReservedBytes);
    }

"""+point)

edit("src/Lokad.Lython/Runtime/Text/PyStringOps.Whitespace.cs",implementation)
edit("tests/Lokad.Lython.Tests/CasedSplitOwnershipTests.cs",test)
