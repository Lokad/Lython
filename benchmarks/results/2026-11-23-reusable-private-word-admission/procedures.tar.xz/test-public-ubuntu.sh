#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/reuse-private-word-admission-20261123
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/reuse-private-word-admission-20261123
filter='Category!=Stress&(FullyQualifiedName~BulkCasedSplit|FullyQualifiedName~DictionaryCounting|FullyQualifiedName~NativeConsumerStreaming|FullyQualifiedName~CaseFolding|FullyQualifiedName~NativeTextKeyCancellation)'
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" > "$lab/public-ubuntu.log" 2>&1 || { tail -45 "$lab/public-ubuntu.log"; exit 1; }
tail -6 "$lab/public-ubuntu.log"
