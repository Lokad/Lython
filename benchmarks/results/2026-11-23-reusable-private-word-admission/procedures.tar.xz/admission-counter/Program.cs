using System.Reflection;
using System.Diagnostics;
using System.Text;
using System.Text.Json;
using Lokad.Lython;
using Lokad.Lython.Utf8Regex;

var image = Path.GetFullPath(args[0]);
var catalogPath = Path.GetFullPath(args[1]);
var output = Path.GetFullPath(args[2]);
if (File.Exists(output)) throw new IOException("Preserve original observations.");
var assembly = Assembly.LoadFrom(Path.Combine(image, "Lokad.Lython.Benchmarks.dll"));
const BindingFlags all = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;
var fixtureType = assembly.GetType("Lokad.Lython.Benchmarks.Comparison.ComparisonFileFixture", true)!;
var hostType = assembly.GetType("Lokad.Lython.Benchmarks.Comparison.ComparisonFileHost", true)!;
var plainHostType = assembly.GetType("Lokad.Lython.Benchmarks.Comparison.ComparisonHost", true)!;
var parse = fixtureType.GetMethod("Parse", all)!;
var reset = hostType.GetMethod("Reset", all)!;
var check = hostType.GetMethod("ReadOutputs", all)!;
var digest = fixtureType.GetMethod("Digest", all)!;
using var catalog = JsonDocument.Parse(File.ReadAllText(catalogPath, Encoding.UTF8));
var rows = new List<object>();
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var source = item.GetProperty("source").GetString()!;
    var asynchronous = item.TryGetProperty("runAsync", out var mode) && mode.GetBoolean();
    var expected = item.GetProperty("expectedOutput").GetString()!;
    var fixture = parse.Invoke(null, [item.GetProperty("fixtureJson").GetString()]);
    var folder = Path.Combine(Path.GetTempPath(), "lython-comparison-files-" + Guid.NewGuid().ToString("N"));
    var budget = new LythonMemoryBudget(256L * 1024 * 1024);
    var host = fixture is null ? (ILythonHost)Activator.CreateInstance(plainHostType, nonPublic: true)!
        : (ILythonHost)Activator.CreateInstance(hostType, all, null, [fixture, folder], null)!;
    try
    {
        using var script = new LythonEngine(Utf8RegexProvider.Instance).Compile(source, budget);
        if (!script.IsValid) throw new InvalidOperationException(string.Join("|", script.Diagnostics));
        var baseline = budget.ReservedBytes;
        long peakExecutionMemoryBytes = 0;
        var observer = new ObservedBudget(budget);
        var options = new LythonRunOptions { MemoryBudget = observer, ResultMemoryBudget = budget };
        void Run()
        {
            if (fixture is not null) reset.Invoke(host, null);
            using (var result = asynchronous ? script.RunAsync(host, options).GetAwaiter().GetResult() : script.Run(host, options))
            {
                if (!result.Success || result.StandardOutput != expected || result.StandardError != "")
                    throw new InvalidDataException(result.Failure?.Message ?? result.StandardOutput);
                peakExecutionMemoryBytes = Math.Max(peakExecutionMemoryBytes, result.PeakExecutionMemoryBytes);
                if (fixture is not null)
                {
                var files = check.Invoke(host, null);
                var actualFiles = (string)digest.Invoke(null, [files])!;
                if (actualFiles != item.GetProperty("expectedFilesSha256").GetString())
                    throw new InvalidDataException("File golden mismatch.");
                }
            }
            if (budget.ReservedBytes != baseline) throw new InvalidOperationException("Ownership did not return to compilation baseline.");
        }
        Run();
        rows.Add(new { id = item.GetProperty("id").GetString(), asynchronous, peakExecutionMemoryBytes,
            compiledReservedBytes = baseline, sharedBudgetBaselineRestored = true,
            observer.GrowthCalls, observer.GrownBytes, observer.ShrinkCalls, observer.ShrunkBytes,
            coreSha256 = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(
                File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))).ToLowerInvariant() });
        script.Dispose();
        if (budget.ReservedBytes != 0) throw new InvalidOperationException("Compiled owner retained allowance.");
    }
    finally
    {
        (host as IDisposable)?.Dispose();
        var full = Path.GetFullPath(folder);
        if (Path.GetDirectoryName(full) != Path.GetFullPath(Path.GetTempPath()).TrimEnd(Path.DirectorySeparatorChar) ||
            !Path.GetFileName(full).StartsWith("lython-comparison-files-", StringComparison.Ordinal))
            throw new InvalidOperationException("Unexpected owned fixture path.");
        if (Directory.Exists(full)) Directory.Delete(full, recursive: true);
    }
}
File.WriteAllText(output, JsonSerializer.Serialize(new { assembly = typeof(LythonEngine).Assembly.FullName, rows,
    boundary = "One golden-verified warm execution and its cleanup. Counts successful positive and negative changes at the host execution allowance. Compilation and result scopes are passed directly to the original allowance." }, new JsonSerializerOptions { WriteIndented = true }), new UTF8Encoding(false));


internal sealed class ObservedBudget(ILythonMemoryBudget inner) : ILythonMemoryBudget
{
    internal int GrowthCalls { get; private set; }
    internal long GrownBytes { get; private set; }
    internal int ShrinkCalls { get; private set; }
    internal long ShrunkBytes { get; private set; }

    public ILythonMemoryScope CreateScope() => new Scope(this, inner.CreateScope());

    public bool TryReserve(long bytes, [System.Diagnostics.CodeAnalysis.NotNullWhen(true)] out ILythonMemoryReservation? reservation)
        => TryReserve(inner, bytes, out reservation);

    private bool TryReserve(ILythonMemoryBudget budget, long bytes,
        [System.Diagnostics.CodeAnalysis.NotNullWhen(true)] out ILythonMemoryReservation? reservation)
    {
        if (!budget.TryReserve(bytes, out var stored))
        {
            reservation = null;
            return false;
        }
        Observe(bytes);
        reservation = new Reservation(this, stored);
        return true;
    }

    private void Observe(long change)
    {
        if (change > 0)
        {
            GrowthCalls++;
            GrownBytes += change;
        }
        else if (change < 0)
        {
            ShrinkCalls++;
            ShrunkBytes -= change;
        }
    }

    private sealed class Scope(ObservedBudget observer, ILythonMemoryScope scope) : ILythonMemoryScope
    {
        public ILythonMemoryScope CreateScope() => new Scope(observer, scope.CreateScope());
        public bool TryReserve(long bytes, [System.Diagnostics.CodeAnalysis.NotNullWhen(true)] out ILythonMemoryReservation? reservation)
            => observer.TryReserve(scope, bytes, out reservation);
        public void Dispose() => scope.Dispose();
    }

    private sealed class Reservation(ObservedBudget observer, ILythonMemoryReservation stored) : ILythonMemoryReservation
    {
        public long Bytes => stored.Bytes;
        public bool TryResize(long bytes)
        {
            var previous = stored.Bytes;
            if (!stored.TryResize(bytes)) return false;
            observer.Observe(bytes - previous);
            return true;
        }
        public void Dispose() => stored.Dispose();
    }
}
