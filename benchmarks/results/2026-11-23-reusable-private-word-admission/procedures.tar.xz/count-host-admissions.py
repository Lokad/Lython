from pathlib import Path
import hashlib,json,os,shutil,subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
pair=lab/"comparison"
out=lab/"admission-counter"
out.mkdir()
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
identity=json.loads((pair/"identity.json").read_text(encoding="utf-8"))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,s):p.write_text(s,encoding="utf-8",newline="\n")
catalog=pair/"representative.json"
assert sha(catalog)==identity["catalogSHA256"]
template=lab.parent/"text-target-publication-20261122/counter/Program.cs"
text=template.read_text(encoding="utf-8")
a,b=text.index("// Existing complete"),text.index("var image =")
text=text[:a]+text[b:]
a,b=text.index("        var compileBefore"),text.index("        if (!script.IsValid")
text=text[:a]+"        using var script = new LythonEngine(Utf8RegexProvider.Instance).Compile(source, budget);\n"+text[b:]
text=text.replace("        long peakExecutionMemoryBytes = 0;", """        long peakExecutionMemoryBytes = 0;
        var observer = new ObservedBudget(budget);
        var options = new LythonRunOptions { MemoryBudget = observer, ResultMemoryBudget = budget };""")
text=text.replace("script.RunAsync(host).GetAwaiter().GetResult() : script.Run(host)", 
                  "script.RunAsync(host, options).GetAwaiter().GetResult() : script.Run(host, options)")
a,b=text.index("        var type ="),text.index("        script.Dispose();")
text=text[:a]+"""        rows.Add(new { id = item.GetProperty("id").GetString(), asynchronous, peakExecutionMemoryBytes,
            compiledReservedBytes = baseline, sharedBudgetBaselineRestored = true,
            observer.GrowthCalls, observer.GrownBytes, observer.ShrinkCalls, observer.ShrunkBytes,
            coreSha256 = Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(
                File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))).ToLowerInvariant() });
"""+text[b:]
text=text.replace("One verified complete run. Scratch instrumented core counts prepared-loop entries and normal final-word publications. No comparative timings.",
                  "One golden-verified warm execution and its cleanup. Counts successful positive and negative changes at the host execution allowance. Compilation and result scopes are passed directly to the original allowance.")
text+='''
internal sealed class ObservedBudget(ILythonMemoryBudget inner) : ILythonMemoryBudget
{
    internal int GrowthCalls { get; private set; }
    internal long GrownBytes { get; private set; }
    internal int ShrinkCalls { get; private set; }
    internal long ShrunkBytes { get; private set; }

    public ILythonMemoryScope CreateScope() => new Scope(this, inner.CreateScope());

    public bool TryReserve(long bytes, [System.Diagnostics.CodeAnalysis.NotNullWhen(true)] out ILythonMemoryReservation? reservation)
        => TryReserve(inner, bytes, out reservation);

    private bool TryReserve(ILythonMemoryBudget budget, long bytes,
        [System.Diagnostics.CodeAnalysis.NotNullWhen(true)] out ILythonMemoryReservation? reservation)
    {
        if (!budget.TryReserve(bytes, out var stored))
        {
            reservation = null;
            return false;
        }
        Observe(bytes);
        reservation = new Reservation(this, stored);
        return true;
    }

    private void Observe(long change)
    {
        if (change > 0)
        {
            GrowthCalls++;
            GrownBytes += change;
        }
        else if (change < 0)
        {
            ShrinkCalls++;
            ShrunkBytes -= change;
        }
    }

    private sealed class Scope(ObservedBudget observer, ILythonMemoryScope scope) : ILythonMemoryScope
    {
        public ILythonMemoryScope CreateScope() => new Scope(observer, scope.CreateScope());
        public bool TryReserve(long bytes, [System.Diagnostics.CodeAnalysis.NotNullWhen(true)] out ILythonMemoryReservation? reservation)
            => observer.TryReserve(scope, bytes, out reservation);
        public void Dispose() => scope.Dispose();
    }

    private sealed class Reservation(ObservedBudget observer, ILythonMemoryReservation stored) : ILythonMemoryReservation
    {
        public long Bytes => stored.Bytes;
        public bool TryResize(long bytes)
        {
            var previous = stored.Bytes;
            if (!stored.TryResize(bytes)) return false;
            observer.Observe(bytes - previous);
            return true;
        }
        public void Dispose() => stored.Dispose();
    }
}
'''
save(out/"Program.cs",text)
project=out/"AdmissionCounter.csproj"
save(project,'''<Project Sdk="Microsoft.NET.Sdk">
<PropertyGroup><OutputType>Exe</OutputType><TargetFramework>net11.0</TargetFramework><ImplicitUsings>enable</ImplicitUsings><Nullable>enable</Nullable></PropertyGroup>
<ItemGroup>
<Reference Include="Lokad.Lython"><HintPath>../comparison/frozen-reference/Lokad.Lython.dll</HintPath></Reference>
<Reference Include="Lokad.Lython.Utf8Regex"><HintPath>../comparison/frozen-reference/Lokad.Lython.Utf8Regex.dll</HintPath></Reference>
<Reference Include="Lokad.Utf8Regex.PythonRe"><HintPath>../comparison/frozen-reference/Lokad.Utf8Regex.PythonRe.dll</HintPath></Reference>
</ItemGroup></Project>
''')
with (out/"build.log").open("w",encoding="utf-8") as log:
    subprocess.run([dotnet,"build",project,"-c","Release","--no-incremental"],cwd=out,env=env,check=True,timeout=75,stdout=log,stderr=subprocess.STDOUT)
for role,manifest in identity["imageFiles"].items():
    image=pair/("frozen-"+role)
    assert len(manifest)==32 and {n:sha(image/n)for n in manifest}==manifest
    for p in (out/"bin/Release/net11.0").glob("AdmissionCounter.*"):
        shutil.copyfile(p,image/p.name)
    report=out/(role+".json")
    subprocess.run([dotnet,image/"AdmissionCounter.dll",image,catalog,report],cwd=repo,env=env,check=True,timeout=60)
    assert {n:sha(image/n)for n in manifest}==manifest
for before,after in zip(*(json.loads((out/(role+".json")).read_text(encoding="utf-8"))["rows"] for role in identity["imageFiles"]),strict=True):
    assert before["id"]==after["id"] and before["sharedBudgetBaselineRestored"] and after["sharedBudgetBaselineRestored"]
    for role,row in zip(identity["imageFiles"],(before,after),strict=True):
        assert row["coreSha256"]==identity["imageFiles"][role]["Lokad.Lython.dll"]
    print(before["id"], "growths",before["GrowthCalls"],after["GrowthCalls"],"grown bytes",before["GrownBytes"],after["GrownBytes"],
          "shrink operations",before["ShrinkCalls"],after["ShrinkCalls"],flush=True)
