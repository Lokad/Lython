from pathlib import Path
import hashlib,json,shutil,tarfile

base=Path(__file__).parent
r=base/'tuple-cost-r394'
r.mkdir()
previous=base/'invocation-lifetime-r390'
source=json.loads((previous/'candidate-identity.json').read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
image=r/'image';image.mkdir()
for name,digest in source['frozenFiles']['candidate'].items():
    p=previous/'candidate'/name
    assert p.is_file() and sha(p)==digest,(name,'Frozen source image changed')
    shutil.copyfile(p,image/name)
assert all(sha(image/name)==digest for name,digest in source['frozenFiles']['candidate'].items())
shutil.copyfile(previous/'catalog.json',r/'catalog.json')
with tarfile.open('benchmarks/results/2026-11-13-allocation-origins/traces-and-collector.tar.xz') as archive:
    for tool in ['reader','collector']:
        (r/tool).mkdir()
        for name in ['Program.cs','Diagnostics.csproj']:
            (r/tool/name).write_bytes(archive.extractfile(tool+'/'+name).read())
identity=dict(revision='b58e2dc44d5b75669ec78e9027ae3d6ffb100d86',
    source='Fully qualified scheduled-invocation lifetime; current frozen image',
    files=source['frozenFiles']['candidate'],catalogSHA256=sha(r/'catalog.json'))
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
s=(base/'allocation-origin-r323/collect-ready.py').read_text(encoding='utf-8')
s=s.replace("r/'confirmed-readiness'","r/'capture'")
s=s.replace("[('captured','scripts.text-summary-helpers.nonlocal-counter.large',256),('search','scripts.file-search.large',1024)]",
    "[('invoice','scripts.csv-invoice.large',128),('json-control','scripts.json-summary-helpers.large',128)]")
assert "('invoice','scripts.csv-invoice.large',128)" in s
s=s.replace("assert not timeout and not list(fixture.iterdir())", """assert not timeout
for p in sorted(fixture.rglob('*'),key=lambda p:len(p.parts),reverse=True):
 assert p.resolve().is_relative_to(fixture.resolve()) and p.is_dir() and not p.is_symlink() and not list(p.iterdir()),p
 p.rmdir()
assert not list(fixture.iterdir())
fixture.rmdir()""")
(r/'capture').mkdir()
(r/'collect.py').write_text(s,encoding='utf-8',newline='\n')
compile(s,str(r/'collect.py'),'exec')
plan=Path('PLAN.md');text=plan.read_text(encoding='utf-8')
needle='Attribute that work before selecting the larger migration; stop if no material\nwhole-script target appears. Keep text/JSON/reference-heavy controls.'
assert needle in text
text=text.replace(needle,needle+'''
R394 reuses the managed EventPipe allocation collector, exact qualified f304b3db
image and unchanged invoice/JSON scripts: four warm guest seconds, 128 complete
invocations each, one local capture per shape. Production stacks identify sampled
allocation origins, not exact per-type bytes or CPU shares; no forced GC or runtime
changes. Preserve unresolved samples and any adverse capture conditions. Select
an end-to-end tuple migration only if actual transport/construction is material;
otherwise move to the demonstrated larger stage without repeated capture tuning.
''')
plan.write_text(text,encoding='utf-8',newline='\n')
print('Prepared existing collector, immutable current image and two complete scripts; no production changes')
