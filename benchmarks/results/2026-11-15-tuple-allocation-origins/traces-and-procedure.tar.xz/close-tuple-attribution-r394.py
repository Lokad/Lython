from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent/'tuple-cost-r394'
fixture=(r/'capture/fixtures').resolve()
assert fixture.is_relative_to(r.resolve()) and fixture.name=='fixtures'
# The reused collector ran both users to Closed/exit and joined the traces.
# Its last assertion found compiler analyzer shadow copies, not guest storage.
records=[json.loads((r/'capture'/n/'record.json').read_text(encoding='utf-8')) for n in ['invoice','json-control']]
assert all(x['allGoldensPassed'] and x['workerAndTraceJoined'] for x in records)
inspection=[dict(path=str(p.relative_to(fixture)),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in fixture.rglob('*') if p.is_file()]
assert all(x['path'].startswith('VBCSCompiler\\AnalyzerPathResolver\\') for x in inspection)
(r/'tool-cache-cleanup.json').write_text(json.dumps(dict(originalFailure='Final empty-fixture assertion found compiler analyzer shadow copies after all guest/collector users joined',compilerShutdown='dotnet build-server shutdown --vbcscompiler completed successfully',files=inspection),indent=2)+'\n',encoding='utf-8',newline='\n')
assert not any(p.is_symlink() for p in fixture.rglob('*'))
shutil.rmtree(fixture)
receipt=dict(completeCaptures=True,allGoldensPassed=True,allActualUsersJoined=True,fixturesRemoved=True,compilerShadowCacheRemovedAfterServerShutdown=True,initialSetupPathErrorPreserved=True,cleanupAssertionFailurePreserved=True,exactTypeBytesOrCpuClaim=False,productionChanged=False)
(r/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8',newline='\n')
out=Path('benchmarks/results/2026-11-15-tuple-allocation-origins');out.mkdir()
for name in ['invoice','json-control']:
    (out/name).mkdir()
    for f in ['record.json','origins.json']:shutil.copyfile(r/'capture'/name/f,out/name/f)
shutil.copyfile(r/'identity.json',out/'identity.json');shutil.copyfile(r/'receipt.json',out/'receipt.json')
with tarfile.open(out/'traces-and-procedure.tar.xz','w:xz') as archive:
    for p in [r/'collect.py',r/'collect-attempt1.py',r/'identity.json',r/'catalog.json',r/'receipt.json',r/'tool-cache-cleanup.json',Path(__file__),Path(__file__).parent/'prepare-tuple-cost-r394.py']:
        archive.add(p,arcname=p.name)
    for tool in ['reader','collector']:
        for name in ['Program.cs','Diagnostics.csproj']:archive.add(r/tool/name,arcname=tool+'/'+name)
        archive.add(r/(tool+'-build.log'),arcname=tool+'-build.log')
    for p in (r/'capture').rglob('*'):
        if p.is_file() and p.suffix!='.etlx':archive.add(p,arcname='capture/'+p.relative_to(r/'capture').as_posix())
print('Both captures archived; goldens, joins and guest/tool fixture cleanup verified')
