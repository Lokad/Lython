from pathlib import Path
import json
lab=Path('.git/agent-notes/review-20261031/numeric-callable-catalog-b1928-20261128')
records=[json.loads(line) for line in (lab/'jit-intervals.jsonl').read_text(encoding='utf-8-sig').splitlines()]
assert [r['trace'] for r in records]==['config.nettrace','numeric.nettrace']
summary={}
for raw in records:
    assert raw['completed']==raw['starts'] and not raw['unmatched']
    reached=[dict(method=row['Method'],ilBytes=row['IlBytes']) for row in raw['intervals']
        if row['Namespace']=='Lokad.Lython.Frontend.StaticContracts'
        and row['Method'] in ('CreateNumericCallableContracts','CreateDataCallableContracts')]
    name=raw['trace'].removesuffix('.nettrace')
    assert any(r['method']=='CreateNumericCallableContracts' for r in reached)==(name=='numeric'),(name,reached)
    summary[name]=dict(completedJitIntervals=raw['completed'],reached=reached)
print(json.dumps(summary,indent=2))
(lab/'trace-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
