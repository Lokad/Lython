from hashlib import sha256
from pathlib import Path
from shutil import copyfile
import json
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
pair=lab/'comparison'
report=repo/'benchmarks/results/2026-11-28-numeric-callable-catalog'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
identity=read(pair/'identity.json')
warm=read(pair/'summary.json')
cold=read(lab/'cold-summary.json')
receipt=read(pair/'archive-receipt.json')
expected=identity['sourcePatchSHA256']
patch=subprocess.check_output(['git','diff','--binary',identity['sourceRevision'],'--','src'],cwd=repo)
assert patch==(lab/'candidate.patch').read_bytes() and sha256(patch).hexdigest()==expected
assert warm['candidatePatchSHA256']==cold['candidatePatchSHA256']==expected
assert warm['verifiedTimedBatches']==84 and warm['quietMachine'] is False
assert cold['verifiedInvocations']==48 and read(lab/'cold-observations.json')['completedRounds']==12
assert all(receipt[key] for key in ('complete','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
assert digest(pair/'observations.tar.xz')==receipt['archiveSHA256']
for role,files in identity['imageFiles'].items():
    assert len(files)==32
    assert {p.name:digest(p) for p in (pair/role).iterdir()}==files
    verification=read(pair/(role+'-verify.json'))
    assert verification['state']=='Completed' and verification['caseCount']==3
contract=read(lab/'reference-contracts.json')
assert contract==read(lab/'candidate-contracts.json')
assert len(contract['rows'])==962 and contract['queries']==57408 and len(contract['diagnostics'])==11
traces=read(lab/'trace-receipt.json')
assert len(traces)==2
assert all(t['workerAndTracerJoined'] and digest(lab/t['trace'])==t['traceSha256'] for t in traces)
report.mkdir(exist_ok=True)
for name,source in [('identity.json',pair/'identity.json'),('warm-summary.json',pair/'summary.json'),
                    ('cold-summary.json',lab/'cold-summary.json'),('trace-summary.json',lab/'trace-summary.json'),
                    ('warm-observations.tar.xz',pair/'observations.tar.xz')]:
    copyfile(source,report/name)
files=[lab/name for name in ('archive.py','candidate.patch','prepare.py','numeric.py','numeric-golden.txt','collect-cold.py',
    'cold-collection.log','cold-observations.json','summarize-warm.py','initial-warm-summary-catalogs.log',
    'test-ubuntu.sh','trace.py','trace-receipt.json',
    'jit-intervals.jsonl','summarize-trace.py','reference-contracts.json','candidate-contracts.json',
    'probe/Program.cs','probe/ContractProbe.csproj','probe/build.log')]
files.extend(lab.glob('*net*.log'))
files.extend(pair/name for name in ('archive-receipt.json','reference-verify.json','candidate-verify.json','run.sh',
    'collect.py','config.json','numeric.json','jobs.json','representative.json','collection.log','exit-code.txt'))
for name in ('config','numeric'): files.extend(lab/(name+suffix) for suffix in ('.nettrace','.frame','.stderr','-trace.log'))
with tarfile.open(report/'procedures.tar.xz','w:xz') as archive:
    for path in files: archive.add(path,arcname=path.relative_to(lab))
with tarfile.open(report/'procedures.tar.xz') as archive:
    assert all(archive.extractfile(path.relative_to(lab).as_posix()).read()==path.read_bytes() for path in files)
print(f'{len(files)} evidence files verified')
