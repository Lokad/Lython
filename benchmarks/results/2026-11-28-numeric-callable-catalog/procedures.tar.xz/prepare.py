from hashlib import sha256
from pathlib import Path
from shutil import copyfile,copytree
import json
import subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
first=lab.parent/'first-command-phases-b1927-20261128'
checkpoint=lab.parent/'compiler-checkpoint-b1926-20261128'
existing=lab.parent/'direct-lexical-binding-slots-b1925-20261128/comparison'
pair=lab/'comparison'
read=lambda p:json.loads(p.read_bytes())
digest=lambda p:sha256(p.read_bytes()).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],cwd=repo)
image=lambda folder:{p.name:digest(p) for p in folder.iterdir()}
hash_text=lambda text:sha256(text.encode('utf-8')).hexdigest()
def write(path,data):
    path.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')

base=git('rev-parse','HEAD').decode().strip()
setup=read(first/'setup.json')
assert not git('diff','--name-only',setup['productionSource'],base,'--','src')
patch=git('diff','--binary',base,'--','src')
assert patch.count(b'diff --git ')==2 and b'NumericCallableMemberCatalog' in patch
(lab/'candidate.patch').write_bytes(patch)
pair.mkdir()
core='Lokad.Lython.dll'
assert image(first/'reference')==setup['reference'] and len(setup['reference'])==32
for role in ('reference','candidate'):
    copytree(first/'reference',pair/role)
compiled=repo/'src/Lokad.Lython/bin/Release/net11.0'/core
assert digest(compiled)!=setup['reference'][core]
copyfile(compiled,pair/'candidate'/core)
images={role:image(pair/role) for role in ('reference','candidate')}
assert {name for name in images['reference'] if images['reference'][name]!=images['candidate'][name]}=={core}
for name in ('cpython-worker.py','config.json'):
    copyfile(first/name,pair/name)
copyfile(existing/'run.sh',pair/'run.sh')
assert b'\r' not in (pair/'run.sh').read_bytes()

source = """number = int('37')
flag = bool('yes')
value = float('1.5')
print((5).bit_length(), number.bit_count(), True.bit_count(), flag.bit_length())
print((1.5).as_integer_ratio(), value.hex())
"""
(lab/'numeric.py').write_text(source,encoding='utf-8',newline='\n')
python='/mnt/d/code/Lython/.git/agent-notes/review-20261031/bench-cpython-3.13.16-runtime/runtime/bin/python3.13'
golden=subprocess.check_output(['wsl',python,'-I','-S','-X','utf8','/mnt/d/code/Lython/'+(lab/'numeric.py').relative_to(repo).as_posix()],cwd=repo)
assert golden.decode('utf-8')=='3 3 1 1\n(3, 2) 0x1.8000000000000p+0\n'
(lab/'numeric-golden.txt').write_bytes(golden)
fixture='{"size":1,"text":null}'
numeric=dict(id='diagnostic.numeric-members',family='diagnostic',category='whole-script',scale='small',size=1,
             source=source,fixtureJson=fixture,expectedOutput=golden.decode('utf-8'),
             sourceUtf8Bytes=len(source.encode('utf-8')),expectedOutputUtf8Bytes=len(golden),
             fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,sourceSha256=hash_text(source),
             fixtureSha256=hash_text(fixture),expectedOutputSha256=sha256(golden).hexdigest(),expectedFilesSha256=None)
catalog=read(checkpoint/'comparison/quiet/representative.json')
control=next(c for c in read(existing/'representative.json')['cases'] if c['id']=='diagnostic.generated-guarded-report')
config,=read(pair/'config.json')['cases']
catalog['cases']=[config,numeric,control]
write(pair/'representative.json',catalog)
write(pair/'numeric.json',{**read(pair/'config.json'),'cases':[numeric]})
write(pair/'jobs.json',{'warm':[[config['id'],'compile'],[numeric['id'],'compile-run'],[control['id'],'compile']]})
identity=dict(sourceRevision=base,sourcePatchSHA256=digest(lab/'candidate.patch'),imageFiles=images,
    coreSHA256={role+suffix:hashes[core] for role,hashes in images.items() for suffix in ('','-control')},
    cpythonWorkerSHA256=setup['pythonWorkerSHA256'],expectedCPythonSHA256=setup['pythonSHA256'],cpythonPath=python,
    purpose='Quantify the removal of duplicate primitive callable metadata from first compilation.',
    catalogs={name:{'sha256':digest(pair/name)} for name in ('representative.json','jobs.json','config.json','numeric.json')})
write(pair/'identity.json',identity)
collector=(existing/'collect.py').read_text(encoding='utf-8')
collector=collector.replace('lython-direct-lexical-binding-slots-','lython-numeric-callable-catalog-').replace('len(jobs) == 5','len(jobs) == 3')
compile(collector,'collect.py','exec')
(pair/'collect.py').write_text(collector,encoding='utf-8',newline='\n')
print('Frozen',base,identity['sourcePatchSHA256'])
