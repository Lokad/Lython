set -e
cd /mnt/d/code/Lython/.git/agent-worktrees/prepared-definition-dispatch-r646
export PATH="$HOME/.dotnet:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/prepared-definition-dispatch-r646
filter='(FullyQualifiedName~Definition|FullyQualifiedName~Nonlocal|FullyQualifiedName~FunctionDefault|FullyQualifiedName~Decorator|FullyQualifiedName~GovernedMemoryContract)&Category!=Stress'
for project in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="$logs/$project-combined-wsl-net10.log"
    code=0
    dotnet test "tests/$project" -c Release -f net10.0 --artifacts-path "$PWD/tests/artifacts/r646-wsl" --filter "$filter" > "$log" 2>&1 || code=$?
    if [ "$code" != 0 ]; then tail -25 "$log"; exit "$code"; fi
    tail -4 "$log"
done
