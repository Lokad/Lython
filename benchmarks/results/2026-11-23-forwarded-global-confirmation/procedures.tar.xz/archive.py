from pathlib import Path
import gzip, hashlib, json, shutil, tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
quiet = lab/'comparison/quiet'
root = repo/'benchmarks/results'
prior = root/'2026-11-23-forwarded-global-call'
dest = root/'2026-11-23-forwarded-global-confirmation'
read = lambda path: json.loads(path.read_text(encoding='utf-8'))
sha = lambda blob: hashlib.sha256(blob).hexdigest()
identity = read(lab/'comparison/identity.json')
old = read(prior/'identity.json')
assert old['imageFiles'] == identity['imageFiles']
for role, files in identity['imageFiles'].items():
    assert len(files) == 32
    assert all(sha((lab.parent/'forwarded-global-call-20261123'/role/name).read_bytes()) == digest for name, digest in files.items())
    assert sha(gzip.decompress((prior/(role+'-core.dll.gz')).read_bytes())) == files['Lokad.Lython.dll']
terminal = read(quiet/'terminal-status.json')
assert terminal['exitCode'] == '0' and not terminal['live'] and not terminal['fixtures']
assert all(terminal['receipt'][name] for name in ('complete','archivedAndVerifiedUnderLease','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter'))
assert sha((quiet/'observations.tar.xz').read_bytes()) == terminal['receipt']['archiveSHA256']
assert read(quiet/'summary.json')['timedBatches'] == 112
dest.mkdir(exist_ok=True)
shutil.copyfile(lab/'comparison/identity.json',dest/'identity.json')
for name in ('terminal-status.json','observations.tar.xz','summary.json'):
    shutil.copyfile(quiet/name,dest/name)
with tarfile.open(dest/'procedures.tar.xz','w:xz') as archive:
    for name in ('archive.py','quiet.py','stage.py','summarize.py','launch.log','retrieval.log',
                 'comparison/reference-verify.json','comparison/candidate-verify.json','comparison/quiet/observe-not-before'):
        archive.add(lab/name,arcname=name,recursive=False)
print(dest)
