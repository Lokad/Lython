from pathlib import Path
import datetime,json,subprocess
r=Path(__file__).parent;head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head.startswith('15f457f7') and not (r/'ci-dispatch.json').exists()
cmd=['gh','workflow','run','ci.yml','--ref','master','-f','stress=true']
done=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8')
now=datetime.datetime.now(datetime.timezone.utc)
(r/'ci-dispatch.json').write_text(json.dumps(dict(head=head,UTC=now.isoformat(),command=cmd,exitCode=done.returncode,stdout=done.stdout,stderr=done.stderr),indent=2)+'\n',encoding='utf-8')
assert done.returncode==0,done.stderr
cmd=['gh','run','list','--workflow','ci.yml','--branch','master','--event','workflow_dispatch','--limit','1','--json','databaseId,headSha,status,conclusion,url']
done=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8')
(r/'ci-initial.stdout').write_text(done.stdout,encoding='utf-8');(r/'ci-initial.stderr').write_text(done.stderr,encoding='utf-8')
assert done.returncode==0,done.stderr
data=json.loads(done.stdout);assert len(data)==1 and data[0]['headSha']==head,data
d=data[0];gate=dict(run=d['databaseId'],source=head,lastObservedUTC=now.isoformat(),nextQueryNotBeforeUTC=(now+datetime.timedelta(minutes=5)).isoformat(),lastObservedStatus=d['status'],terminalCached=False)
(r/'ci-next-query.json').write_text(json.dumps(gate,indent=2)+'\n',encoding='utf-8')
print(json.dumps(d,indent=2))
