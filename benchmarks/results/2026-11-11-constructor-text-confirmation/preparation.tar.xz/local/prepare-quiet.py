from pathlib import Path
import ast,datetime,hashlib,json,re,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;q=r/'b574';q.mkdir(exist_ok=True)
assert not (q/'payload.tgz').exists()
old=r.parent/'patch-workflow-r229/b573';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='15f457f7786703bfe2ee251b3fe84145ad155fbe'
meta=json.loads((r/'diagnostic-identity.json').read_text(encoding='utf-8'))
base=json.loads((r/'before.json').read_text(encoding='utf-8'))
expected=dict(base['sourceHashes'],**meta['sourceHashes'])
for p,h in expected.items():assert sha(Path(p))==h,p
source=dict(revision='15f457f7786703bfe2ee251b3fe84145ad155fbe',all568SourcesMatch=True,sourceSHA256=expected,
    coreIsMeasuredPrecommitFreeze=True,coreSHA256=meta['images']['candidate']['Lokad.Lython.dll'],fullQualification='pending exact15f CI;752 is independently fully qualified')
(q/'source-identity.json').write_text(json.dumps(source,indent=2)+'\n',encoding='utf-8')
root='/home/lokad/lython-bench-checks/constructor-binding-b574-20261111'
catalog=(r/'catalog.json').read_bytes();(q/'representative.json').write_bytes(catalog)
aux=json.loads((old/'config.json').read_text(encoding='utf-8'))['identity']['auxiliaryFiles']
worker_metadata_differences={name:dict(local=meta['images']['candidate'][name],quiet=h) for name,h in aux.items() if meta['images']['candidate'][name]!=h}
assert set(worker_metadata_differences)=={'Lokad.Lython.Benchmarks.dll','Lokad.Lython.Utf8Regex.dll'},worker_metadata_differences
reference='9ee7e700580399ff80d803f0a7535d2de5ff0f10d35a736370f457383be1b67f'
identity=dict(sourceRevision='Exact15f457f7/R232+R233 production sources, measured precommit frozen core, versus qualified4aa/frozen9ee7. Five affected whole-script source pairs, normal GC/tiering. Only core differs; no individual-change attribution or CPython performance claim.',
    coreSHA256={'reference':reference,'reference-control':reference,'candidate':source['coreSHA256'],'candidate-control':source['coreSHA256']},auxiliaryFiles=aux,catalogSHA256=sha(q/'representative.json'),
    workerMetadataDifferencesFromDesktop=worker_metadata_differences,desktopVsQuiet='Separately identified fixed workers. Each pair changes core only. Do not combine cross-host clocks or attribute worker changes to runtime.')
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
jobs=[['scripts.csv-validated-records.constructor-keyword.large','warm'],['scripts.csv-validated-records.constructor-keyword.large','warm-async'],['scripts.csv-validated-records.constructor-keyword-only.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','warm-async'],['scripts.text-summary-helpers.large','warm-async']]
text=(old/'collect.py').read_text(encoding='utf-8').replace('/patch-cpython-b573-20261111','/constructor-binding-b574-20261111')
begin=text.index('jobs=[[');end=text.index('\nenv = ',begin)
text=text[:begin]+'jobs='+repr(jobs)+'\nassert len(jobs)==5 and all(case in cases for case,lane in jobs)\n'+text[end:]
text=text.replace("assert set(identity['coreSHA256']) == {'candidate','candidate-control'}","assert set(identity['coreSHA256']) == {'reference','reference-control','candidate','candidate-control'}")
text=text.replace("labels=['CPython','candidate','CPython-control','candidate-control']","labels=['reference','candidate','reference-control','candidate-control']")
text=text.replace("< 140, 'Reserve40seconds", "< 170, 'Reserve40seconds")
begin=text.index("purpose='R229");end=text.index("',\n                  warmupSeconds",begin)
text=text[:begin]+"purpose='R234 bounded constructor/text latency confirmation, exact15f sources versus qualified4aa; same scripts and frozen common worker per image, no CPython or separate R232/R233 attribution. Warm includes mediated RAM I/O/full checks/prior-result cleanup, excludes compile/startup/reset/protocol/final caches"+text[end:]
ast.parse(text);(q/'collect.py').write_text(text,encoding='utf-8',newline='\n')
text=(old/'archive-owned.py').read_text(encoding='utf-8').replace('/patch-cpython-b573-20261111','/constructor-binding-b574-20261111').replace("==4","==5").replace('jobs=4','jobs=5')
text=text.replace("and'candidate'not in path.relative_to(r).parts", "and not {'candidate','reference'}&set(path.relative_to(r).parts)")
ast.parse(text);(q/'archive-owned.py').write_text(text,encoding='utf-8',newline='\n')
text=(old/'retrieved/run.sh').read_text(encoding='utf-8').replace('patch-cpython-b573','constructor-binding-b574')
(q/'run.sh').write_text(text,encoding='utf-8',newline='\n')
shutil.copyfile(r/'images/candidate/Lokad.Lython.dll',q/'current-core.dll')
retire=[];canonical=Path('benchmarks/results/2026-11-09-borrowed-call-entry/observations.tgz')
subprocess.run(['git','ls-files','--error-unmatch',str(canonical)],check=True,capture_output=True)
with tarfile.open(canonical)as t:
 for role,member,remote in [('reference','baseline-core.dll','baseline-core.dll'),('candidate','current-core.dll','current-core.dll')]:
  raw=t.extractfile(member).read();h=hashlib.sha256(raw).hexdigest()
  assert h not in identity['coreSHA256'].values()
  retire.append(dict(kind='core',knownPath='borrowed-call-entry-b506-20261109/'+remote,
      paths=['borrowed-call-entry-b506-20261109/'+remote,'borrowed-call-entry-b506-20261109/'+role+'/Lokad.Lython.dll'],
      canonical=canonical.as_posix(),canonicalMember=member,bytes=len(raw),sha256=h))
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for name in ['current-core.dll','representative.json','source-identity.json','identity.json','collect.py','archive-owned.py','run.sh']:t.add(q/name,arcname=name)
with tarfile.open(q/'payload.tgz')as t:expanded=sum(((m.size+4095)//4096)*4096 for m in t.getmembers())
config=dict(root=root,unit='lython-b574-constructor-binding-20261111',payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha(q/'payload.tgz'),requiredFreeBytes=(240+12)*1024*1024+expanded+65536,retire=retire,identity=identity)
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
dispatch=json.loads((r/'ci-dispatch.json').read_text(encoding='utf-8'));run=int(re.search(r'/runs/(\d+)',dispatch['stdout']).group(1));now=datetime.datetime.fromisoformat(dispatch['UTC'])
(r/'ci-next-query.json').write_text(json.dumps(dict(run=run,source=dispatch['head'],lastObservedUTC=dispatch['UTC'],nextQueryNotBeforeUTC=(now+datetime.timedelta(minutes=5)).isoformat(),lastObservedStatus='dispatch-acknowledged',terminalCached=False,initialListRace='Earlier completed run appeared before the newly dispatched run was listed; use acknowledged URL, do not redispatch or requery old terminal.'),indent=2)+'\n',encoding='utf-8')
print('Prepared five short source-pair jobs, fixed210sowner/30stop/30margin. Exact prior archived core retirement candidates verified locally; fresh remote inventory required before staging.')
