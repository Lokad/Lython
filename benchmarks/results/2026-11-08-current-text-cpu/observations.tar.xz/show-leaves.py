from pathlib import Path
import json,re
r=Path(__file__).parent;d=json.loads((r/'attribution.json').read_text(encoding='utf8'))
for name,count in d['topLeaves'][:35]:
    head=name.split('(',1)[0]
    print(count,round(count*100/d['guestSamples'],2),'%',head[-160:])
