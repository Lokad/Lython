from pathlib import Path
r=Path(__file__).parent
s=(r.parent/'scalar-cost-r111/profile-corrected/attribute.py').read_text(encoding='utf8').replace('retrieved/profiles/integer-warm','retrieved/profiles/text-warm').replace("sourceRevision='05790317'","sourceRevision='b1e17b64'")
needle='counts={tag:'
at=s.index(needle)
s=s[:at]+'''patterns.update(
 casingAndSplit=lambda n:'[Lokad.Lython]' in n and any(t in n for t in ['WriteCase','CaseOutput','CasedSplit','BuildSplit','Whitespace','CollectSeparated','CaseRune']),
 utf8Hash=lambda n:any(t in n for t in ['HashCode::AddBytes','HashUtf8','PyString::GetHashCode']),
 nativeShapeProof=lambda n:any(t in n for t in ['GuardNativeReturn','GuardNativeBody','TryGetNativeBinaryShape']))
# Match actual owner/method heads, not type names occurring only in arguments.
def head(name):return name.split('(',1)[0]+'('
patterns={tag:(lambda n,test=test:test(head(n))) for tag,test in patterns.items()}
'''+s[at:]
s=s.replace('print(json.dumps(out,indent=2))', '''print('source',out['sourceRevision'],'samples',out['guestSamples'],'guestCPU',out['guestCpuSeconds'],'unknown',out['unknownLeaf'],flush=True)
for tag,c in out['groups'].items():print(tag,'leaf',c['leaf'],'inclusive',c['inclusive'],flush=True)
for row in out['topLeaves'][:30]:print(str(row)[:240],flush=True)''')
exec(compile(s,str(r/'attribute.py'),'exec'))
