from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).parent;i=json.loads((r/'identity.json').read_text(encoding='utf8'));a=json.loads((r/'archive-receipt.json').read_text(encoding='utf8'))
assert a['complete'] and a['allWorkersJoined'] and a['guestFixturesRemoved'] and a['quietBeforeAndAfter']
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==a['archiveSHA256']
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in i['productionSources'].items())
d=json.loads((r/'attribution.json').read_text(encoding='utf8'));assert d['guestSamples']==1160 and d['unknownLeaf']==67
decision=dict(status='Assessment complete; no runtime prototype selected from this capture.',facts='1160guest samples/5.85CPU seconds/67unknown5.78%. Prefix21818.79%, input69 5.95%, structuralhash48 4.14%, whitespace41 3.53%, publication38 3.28%, dictionaryget37 3.19%, smallintegeradd36 3.10%, nativecallselection35 3.02%, store31 2.67%, nativeevaluator30 2.59%. Casing/split97leaf8.36%, native proof7leaf0.60%, callbinding/context0leaf. Inclusive groups overlap; no normal elapsed/causal speed inference.',sourceAssessment='Native leaf hashes already cached/context-aware; no general cycle traversal to delete. Dictionary scalar replacement is a funded array assignment. Fragment commit moves accounting without a shared-budget resize; monitors50samples4.31%resolve to real preallocation reservations, scopes already share one lock. Supplied positional calls already carry nativeAttempted, not repeated pre-frame proofs. Module mirroring selective, not forced by every helper. Existing inline UTF8/casing-split/final representation eliminate proposed old conversions. No demonstrated dominant redundant construction phase identified.',stoppingDecision='Do not invent primitive hash detours, instruction frameworks, allocation-credit policies or shared input windows from inclusive samples alone. Input windows would require a different retained-buffer lifetime; coarse credit would change earlier denial/refund timing and add policy for a small sample share. No redesign selected without a concrete whole-phase deletion and bounded semantics/ownership proof. This is uncertainty, not a permanent design rejection.',next='Complete exact-source delivery and targeted current CPython checkpoint for five representative scripts across compile/warm/compile-to-result. Reuse current stacks/JIT offline if needed to separate useful prefix work from removable transport; bounded15min before another prototype. Custom async debt unresolved; no measured dominant cause yet. Performance roadmap remains open.')
(r/'decision.json').write_text(json.dumps(decision,indent=2)+'\n',encoding='utf8')
out=Path('benchmarks/results/2026-11-08-current-text-cpu');out.mkdir()
with tarfile.open(out/'observations.tar.xz','w:xz') as t:
    for p in sorted(r.iterdir()):
        if p.name not in ['retrieved','payload.tgz']:t.add(p,arcname=p.name)
with tarfile.open(out/'observations.tar.xz') as t:assert hashlib.sha256(t.extractfile('observations.tgz').read()).hexdigest()==a['archiveSHA256']
for src,name in [(r/'identity.json','identity.json'),(r/'attribution.json','attribution.json'),(r/'decision.json','decision.json'),(r/'archive-receipt.json','archive-receipt.json'),(r/'source-gate.md','source-gate.md')]:shutil.copyfile(src,out/name)
(out/'README.md').write_text('''# Current complete-text CPU assessment

2026-11-08. Committedb1e17b64/frozen93e926fe; production inventory matches.
One full delivery is pending independently. No new runtime change or requalification.
Existing text-summary-helpers script3072lines/35840B, full stdout/counts report,
same frozen7cf worker/host/optional0.4. Quiet F4as_v7/.NET11RC3,6sguestwarmup,
2ssettle,6swall CPU-clock/fp199Hz,64completeinvocations/request. PerfMap/JIT
diagnostics: **not normal elapsed evidence**. R108 profiled report, not this text.

5.924guest-clock seconds/5.85guest CPU,1160samples/67unknown leaves(5.78%).
All source/core/aux/Ready/fullgoldens/quiet/Closed/exit/join/maps/fixture/archive/
local verification gates pass. Live120sowner captured; no users or owned RAM remain.
Temporary CLR maps copied/hash-verified after users ended before owned unmount.

| Leaf work | Samples / share |
| --- | ---: |
| Instruction prefix |218 /18.79%|
| Input handling |69 /5.95%|
| Structural hash wrapper/native hash |48 /4.14%|
| Whitespace collection |41 /3.53%|
| Local result publication |38 /3.28%|
| Dictionary get |37 /3.19%|
| Exact small-integer add |36 /3.10%|
| Native call selection |35 /3.02%|
| Subscript store |31 /2.67%|
| Native evaluator |30 /2.59%|

Casing/split group97leaf8.36%; native type proof7leaf0.60%; callbinding and context
construction0leaf. Monitor enter/exit50leaf4.31%resolve to MemoryGovernor.Reserve
through split/input string allocation, not per-fragment commits or dictionary
scalar replacement. Groups overlap; inlining/unwind limits apply. Prefix samples
include useful operations/checks/retirement, not all removable dispatch.

Source assessment rules out proposed duplicate phases: native string hashes
already use cached/context-aware values without general cycle traversal; scalar
dict updates use funded capacity; split fragments commit without shared-budget
resize; scopes share one lock. Direct supplied positional calls already suppress
repeated pre-frame proof via nativeAttempted. Raw method definitions were not
evidence that the measured custom call repeats three probes. Module mirroring is
selective. Inline UTF8 and final-fragment casing/split already remove old copies.

**No runtime prototype selected.** No demonstrated dominant redundant phase yet.
Do not add hash detours, instruction frameworks, credit policies or shared input
windows from these samples: windows change retained-buffer lifetime, and coarse
credit changes admission/refund timing for a small sample share. Preserve safety
checks and actual reservations. This is uncertainty, not permanent design closure.
Next: exact-source delivery/current CPython checkpoint, then bounded offline
prefix-PC/source analysis using this existing capture if justified. Before any
redesign, name whole work/storage eliminated and its semantic/ownership proof.
Custom async debt remains separate and unresolved; no broad CPU claim.

[Decision](decision.json), [attribution](attribution.json), [source audit](source-gate.md),
[identity](identity.json), [receipt](archive-receipt.json),
[all raw/maps/code/unknown evidence](observations.tar.xz).
''',encoding='utf8')
p=Path('benchmarks/EXPERIMENTS.md');p.write_text(p.read_text(encoding='utf8')+'''
## Current complete-text CPU assessment (2026-11-08)

[R116/B476](results/2026-11-08-current-text-cpu/README.md), b1e17b64/core93e9,
1160samples/5.85CPU/67unknown5.78%, all gates/archive/local. Prefix21818.79%,
input69 5.95%, hash48 4.14%, split/casing97leaf8.36%, nativeproof7 0.60%,
binding/contexts0leaf. Monitor50leaf4.31%maps to actual allocation preflights;
fragment commit and dictionary replacement already avoid root resize. Direct
positional calls already suppress duplicate pre-frame proof; earlier generic
repeated-probe discussion was unverified for that measured route. No dominant
redundant phase established, no prototype selected. Keep required checks/budget
semantics, use bounded existing-PC/source analysis before any further redesign.
Next current CPython checkpoint, custom async debt remains explicit.
''',encoding='utf8')
p=Path('benchmarks/results/2026-11-08-primitive-helper-delivery/README.md');s=p.read_text(encoding='utf8').replace('Rejected\nproof attempts are source-visible, not isolated attribution of all CPU.','A rejected\nproof adds work on custom calls. Direct positional calls already suppress a repeated\npre-frame proof; raw method definitions do not establish repeated work on that route.\nThe dominant cause of the custom regression remains unprofiled.')
if s==p.read_text(encoding='utf8'):
    s=s.replace('Rejected\nproof attempts are source-visible, not isolated attribution of all CPU.','The cause of the custom regression remains unprofiled.')
p.write_text(s,encoding='utf8')
p=Path('PLAN.md');s=p.read_text(encoding='utf8');s+='''
R116/B476 complete/archived/localverified:1160samples/5.85CPU/67unknown5.78%,
prefix18.79%leaf, input5.95%, hash4.14%, split/casing8.36%, proof0.60%, binding/
contexts0leaf. No dominant redundant phase established, no prototype selected.
Actual reservations account for monitor samples; hashes/scalar stores/fragment
commits already avoid the hypothesized extra machinery. Direct positional calls
already suppress repeated pre-frame proof. Continue targeted current CPython
checkpoint; optional existing-PC/source assessment bounded15min before a new design.
No new hash detour, credit policy, borrowed-input lifetime redesign or unsafe code.
B476 terminal cached; never requery. Fullb1 qualification remains independent.
''';p.write_text(s,encoding='utf8')
print('R116 bounded assessment/evidence closed; no speculative runtime prototype, continue current CPython checkpoint.')
