from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;old=r.parent/'scalar-cost-r111/profile-corrected';delivery=r.parent/'primitive-proof-r115'
i=json.loads((delivery/'identity.json').read_text(encoding='utf8'));prior=json.loads((old/'identity.json').read_text(encoding='utf8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in i['productionSources'].items())
identity={**prior,'sourceRevision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'files':{'Lokad.Lython.dll':i['coreSHA256']['candidate']},'productionSources':i['productionSources'],'qualification':'Committed/pushedb1e17b64, focused Release actual11/10 passed; one full delivery dispatched and pending. No repeated qualification or new runtime change.'}
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf8')
catalog=json.loads((delivery/'catalog.json').read_text(encoding='utf8'));catalog['cases']=[next(c for c in catalog['cases'] if c['id']=='scripts.text-summary-helpers.large')]
(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
receipt=json.loads((delivery/'b475/archive-receipt.json').read_text(encoding='utf8'));assert hashlib.sha256((delivery/'b475/observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
(r/'core-source.json').write_text(json.dumps(dict(vmArchive='primitive-proof-b475-20261108/observations.tgz',archiveSHA256=receipt['archiveSHA256'],member='current-core.dll',coreSHA256=i['coreSHA256']['candidate'],immutableLocalArtifact='benchmarks/results/2026-11-08-primitive-helper-delivery/observations.tar.xz (nested B475)'),indent=2)+'\n',encoding='utf8')
for name in ['ops-profile.py','analyze-cpu-guest.py','retrieve.py','run.sh','archive.py','launch.py']:
    s=(old/name).read_text(encoding='utf8').replace('corrected-scalar-profile-b471-20261108','current-text-profile-b476-20261108').replace('lython-b471-corrected-scalar-profile','lython-b476-current-text-profile').replace('corrected-scalar-profile-b471-launch.py','current-text-profile-b476-launch.py').replace('lython-b471','lython-b476').replace('integer-warm','text-warm')
    if name=='ops-profile.py':s=s.replace('loops.integer.large','scripts.text-summary-helpers.large').replace('ExecuteInstructionPrefix EvaluateBinaryOperator','ExecuteInstructionPrefix GuardNativeReturn TryGetNativeBinaryShape')
    if name=='launch.py':s=s.replace("source=(base/'refined-record-capacity-b469-20261108/candidate').resolve()","source=(base/'primitive-proof-b475-20261108/candidate').resolve()")
    if name=='archive.py':s=s.replace('verified immutable B469 archive','verified immutable B475 archive')
    if name=='run.sh':
        marker='date -u +%FT%TZ > "$root/started.utc"\n';assert marker in s
        s=s.replace(marker,marker+'systemctl show lython-b476-current-text-profile-20261108.service --property=RuntimeMaxUSec,LoadState,ActiveState,MainPID > "$root/live-unit.txt"\n')
    (r/name).write_text(s,encoding='utf8',newline='\n')
    if name.endswith('.py'):ast.parse(s)
shutil.copyfile(delivery/'source.patch',r/'source.patch');shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
shutil.copyfile(old/'sizing.json',r/'sizing.json')
contract='''R116 bounded current complete-text CPU assessment during one pending full delivery ofb1e17b64. Frozen93e926fe source inventory matches committed production; core/aux reused from verified B475 archive, no new binary/upload/prototype or repeated old qualification. Existing scripts.text-summary-helpers.large,3072lines35840B, complete counts report/stdout, frozen7cf/host/normaloptional0.4. HistoricalR109 text warm1.55–1.62xCPython is named-source diagnostic, not current ratio or dominance proof. R108 profiles report, not current text. Inspect actual casing/split/dictionary/iteration/operand/call work, keep unknown/inlining limits; source~20min to name one complete removable phase/storage and affected scripts before any next redesign. Existing numeric dict updates already use capacity and array assignment; no phantom budget-lock campaign or slower carrier revival. Custom async+1.28–3.36%/CPU+6.67% debt remains separate, no inference it is repaired by source/profile.
Reuse existing6s guestwarmup/2s settle/6s wall CPU-clock/fp199Hz,64completeinvocations/request. PerfMap/JIT diagnostics, not normal elapsed.120sowner+30stop+30margin, live finite unit recorded. All source/core/aux/Ready/fullfilegoldens/quiet/Closed/exit/join/maps/fixture/archive/local gates. Persistentraw/maps, owned128MiBRAMfixtures/tempCLRmaps copied+verified after users end before retirement/unmount. OS240MiB+trace/archive8MiB+actualpayload guard unchanged, baselinecorearchive reused, no historical evidence deletion. Then current CPU/source assessment and select coherent next phase; performance objective/primary comparison remain open, regex/publication independent.
'''
for name in ['contract.md','selection.md']:(r/name).write_text(contract,encoding='utf8')
with tarfile.open(r/'payload.tgz','w:gz') as t:
    for name in ['ops-profile.py','analyze-cpu-guest.py','archive.py','run.sh','catalog.json','identity.json','source.patch','contract.md','selection.md','sizing.json','core-source.json','pre-measurement-plan.md']:t.add(r/name,arcname=name)
p=Path('PLAN.md');s=p.read_text(encoding='utf8');s+='\nR116 source gate active: one existing six-second complete-text CPU capture at\nb1e17b64/frozen93e926fe; source/hash/quiet/ownership/archive gates and unknowns,\nno new runtime or normal elapsed claim. R108 measured report, so this closes a\ncurrent-text attribution gap. Full delivery runs independently; no terminal CI\nrequeries or duplicated qualification.\n';p.write_text(s,encoding='utf8')
print('R116 existing complete-text profile prepared; frozen committed source, no new runtime/probe framework.')
