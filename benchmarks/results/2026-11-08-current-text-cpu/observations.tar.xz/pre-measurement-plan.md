# Lokad.Lython 0.11.0

Updated 2026-11-08. Git-ignored: never force-add. Publication/tagging postponed.
Objective: coherent simplification and substantial complete-script improvements.
Current contracts belong in docs; [experimental history](benchmarks/EXPERIMENTS.md)
and immutable results preserve earlier designs, corrections and adverse evidence.

## Actual delivery status

- **Committed/pushed and fully qualified:** production05790317/core13107e6b,
  cached CI42502610937, Windows/Ubuntu actual.NET11/10 full Release, original Stress
  both and installed core consumers. Shared compiler-fact correction, direct UTF8
  formatting/storage, original native helper returns, R105 native JSON, R106 guarded
  helpers and R110 ordered-prefix capacity are delivered. Do not replay unchanged
  qualification. Laterb1e17b64 commits the new milestone; its full qualification is pending.
- **Established claims remain separate:** original native returns allocation
  −19.92/−19.31%, elapsed diagnostic; formatting allocation−8.67%, controlledB102
  elapsed/CPU−5–8%, original adverse15.125ms unexplained/preserved. R110 wide-record
  allocation−8.56–8.58%bothAPIs, CPU supports elapsed gain. Older R76/R79/R95/R96/
  R102 and R105 configuration CPU debts remain source-pair-specific.
- **Latest representative external baseline:** R109/source7265538c/core1aa68ce9,
  CPython3.13.16,28jobs581.729s, qualified source and verified observations.
  [BENCHMARKS](docs/BENCHMARKS.md) separates compilation/warm/compile-to-result,
  names I/O/validation/cleanup and preserves inconclusive controls. It does not
  describe today’s uncommitted runtime. Startup/RSS/pending-I/O/embedding tails
  remain unmeasured. Do not infer individual changes’ CPU gains from those ratios.
- **Closed assessments/prototypes:** R108 frames3.96%leaf despite84%inclusive;
  work/unknown/inlining limits remain. R111 loop~1.17xCPython diagnostic, no quiet-
  after; publication24.53%leaf includes required checks/cleanup. R112 not retained:
  allocation neutral, duplicated namespace branches, mixed timing/report CPU debt;
  exact qualified implementation restored. Failures/raw/source/binaries preserved.
- **Committed/pushedb1e17b64 R113–R115/core93e926fe:** one combined proof/forwarding
  milestone below. Focused1526public/104internal Release pass peractual11/10.
  Native descriptors’ initial/refined checks and all intermediate measurements
  remain distinct. One full platform/Stress/installed-package qualification is dispatched, pending.

## Prioritized deliverables

1. **Finish coherent primitive helper/proof milestone (R113–R115).** Replace
   Add-only native proof with one pure compiler/runtime result-shape fact for
   BigInteger/double/bool and existing string addition; use canonical operators,
   never duplicate arithmetic. Reject permanently unsupported native binary proofs
   during preparation; supported Python operations still use ordinary execution.
   Existing proof nodes own immutable instruction descriptors/member/return spans,
   removing runtime source offsets and native/ordinary-forwarding mutual exclusion.
   Ordinary bytecode always forwards operands, including failed guards. No new
   engine, value representation, call-control carrier, arena, owner/cache or option.
   Preserve spans/evaluation order, promotion/negative floor/modulo, defaults,
   globals after admission, custom/suspending protocols, cleanup and managed depth.

   **Evidence/tradeoffs:** R113 integer accounting gains with neutral allocation;
   R114 against qualified1310 improves integer scripts/text but async floatCSV
   +4.14–6.29%adverse. Both intermediate sources/results archived, not promoted.
   R115 bounded refinement extends the same fact to primitive floats/bools; actual
   Quantity.__mul__ ordinary guard-miss workload added, float is no longer labelled
   a miss. Local incremental warm allocation neutral; desktop controls unstable.
   Direct qualified1310→93e9 compilation allocation+1.40–1.48%accounting/+0.59%text/
   report unchanged, elapsed inconclusive. Native nodes32→72B; instructions32B
   unchanged and forwarded loads disappear. Coarse admitted compilation estimate
   keeps deliberate headroom; no exact tiny-budget threshold promise.

   **Retained decision:** B4758jobs224.458s/allgates/archive/localverified; no users/
   RAM remain. IntegerCSV/JSONelapsed−3.5–5.2%, float−1.8–6.2%across APIs, CPU
   supports. Customasync+1.28–3.36%elapsed/+6.67%CPU is accepted explicit debt;
   customsync/text variable, report elapsed flat/CPUpossible debt. No universal
   speed claim. Live270sowner verified atstartup; earlier metadata errors/terminal
   infinity preserved. Committed/pushedb1e17b64, delivery active; previous adverse pairs
   remain, this milestone does not complete the performance objective.

2. **Coherent delivery and primary comparison checkpoint.** Once retained, commit
   source/tests/current architecture docs/evidence together. One exact-source full
   Windows/Ubuntu Release actual11/10, original Stress both, installed core consumer
   qualification; cached0579 remains independent until it passes. Continue useful
   work during CI, observe>=5min apart, no duplicate dispatch or terminal requery.
   Refresh representative CPython comparisons when this boundary is stable, reuse
   existing workers/goldens. Separate compilation, warm execution, compile-to-result
   and included I/O/cleanup; keep old/unstable/missing evidence visible. No new
   framework or per-edit full external comparison. Publication stays postponed.

3. **Next substantial design selection: current complete text/custom-operator costs.**
   Profiles and retained paths already establish direct arguments/final slots,
   deferred contexts, reusable workspaces, shared scope facts/immutable builtin
   metadata, executable imports, native UTF8/casing-split/final-buffer formatting,
   JSON record filling and adopted CSV arrays. Ordinary dictionary numeric updates
   already use funded capacity and an array assignment; no budget transition to
   remove. R110 removes intermediate value replacements using known shared keys.
   Old bulk CSV6–8% work was reassessed: its proposed copying is already gone;
   preserve evidence/control regression, no automatic promotion. Keep measured
   slower R71 arena/call-control/wide-carrier lessons.

   At retained source use existing short guest-CPU capture on complete text/custom-operator
   scripts, with source identity/quiet/unknowns/owned archive and separate compile,
   I/O/cleanup boundaries. Bounded~6CPU seconds percase plus~20min source assessment;
   do not infer dominance from inclusive frames, boxing or allocation alone.
   Assess whole call/frame selection, operand transport, per-record construction,
   remaining text conversions and repeated frontend work against actual stacks.
   Before a redesign name affected scripts, complete phase/storage eliminated,
   displaced code to delete, semantic/cancellation/ownership criteria and bounded
   controlled comparison. If work is absent or attribution unresolved, record that
   and select another demonstrated cost. Temporary setbacks need a completion
   milestone and a regression-debt decision, not indefinite experiment closure.

4. **Independent regex contract/implementation.** Core owns Python/nativeUTF8
   names, byte captures/scalar positions/original windows, flags/errors/replacement
   semantics, cache ownership/current tokens and one frontend/runtime/import
   provider. Optional adapter nonpackable, normal0.4 pin. Dev55/d6067925 development
   qualification86internal/514public peractual11/10 already completed; no unchanged
   replay or sibling edits/builds. Missing producer capabilities: DetailedData
   separate preparation/working owner, native-name enumeration, cursor creation
   without retaining an earlier token. Existing adapter-local bridges/development
   producers support independent implementation and semantic testing. Released
   capabilities defer only affected final adapter qualification, never core work.
   Separate forwarding/unwind, semantics and actual backend performance evidence.

## Operating and experimental policy

Bounded confirmation/refinement/measurement correction are allowed when justified.
Timeout, unstable unchanged controls and inconclusive measurements establish
uncertainty, not failed design. Size runs for useful quiet-VM observations; retain
all adverse results and original failed conditions. Percentages inform decisions
rather than automatically veto simplification. No unsupported CPU/speed predictions.

AGENTS.md governs fully managed memory safety/stack admission, host mediation,
current-token cancellation, shared coarse admission/preflights/replacement overlap,
funded aliases/results/caches/pending users and awaited cleanup. Refusal is terminal.
No unsafe/Unsafe/native probes, independent caps/fuel/quotas, tracing/weak reclaim/
forcedGC, silent regex dialect fallback, abandoned work or hidden default allowance.
Focused Release iteration; no overlapping local builds/tests/measurements. Fresh
nonincremental build after timestamp-preserving restores; preserve exact source and
binary identities. UTF8 text. Core only explicit Release pack to artifacts/nuget.

VM lokad@20.166.121.73, key~/.ssh/id_lython-bench.pem. Persistent workers/catalogs/
raw separate from owned RAM; join, verify maps, unmount, archive under lease and
verify locally. No evidence deletion; exact-byte hardlinks require fresh identity/
inode/alias proof. Free-space floors remain. B450–B475 terminal/cached/archived/locallyverified; no VM users/fixtures.
All recorded older terminal CI runs cached; never query them again.

Current deliveryb1e17b64: one dispatch; first status after2026-11-08T18:57:08.944805+00:00. Continue source/performance assessment meanwhile.
