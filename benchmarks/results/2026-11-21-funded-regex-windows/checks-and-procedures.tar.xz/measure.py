from pathlib import Path
import hashlib
import json
import os
import shutil
import statistics
import subprocess

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
baseline = "151b05134"
candidate = "d05150e9d"
worktree = repo / ".git/agent-worktrees/regex-shared-group-utf8-20261121"
donor = lab.parent / "packed-annotations-in-creation"
prior = lab.parent / "direct-regex-group-copy"
source_owner = lab.parent / "observed-regex-coordinates/frozen/reference"
dotnet = Path.home() / ".dotnet11/dotnet.exe"
python = Path("C:/Python313/python.exe")
protocol = repo / "benchmarks/cpython-worker.py"
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent),
           PATH=str(dotnet.parent) + os.pathsep + os.environ["PATH"])

def sha(data):
    return hashlib.sha256(data).hexdigest()

def load(p):
    return json.loads(p.read_text(encoding="utf-8-sig"))

def save(p, value):
    p.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8", newline="\n")

assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=worktree, text=True).startswith(candidate)
assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=worktree)
catalog = load(prior / "representative.json")
rows = []
for row in catalog["cases"][:2]:
    # Replace the compiled literal with the same subject built by the command.
    rest = row["source"].split("\n", 2)[2]
    source = "import re\ntext=('é😀a'*1366)[:4096]\n" + rest
    rows.append((dict(row), source))
prototype = dict(catalog["cases"][0])
rows.extend([
    (dict(prototype, id="scripts.regex.log-messages", size=256), """import re
body = 'tempŝérature stable et signal reçu. ' * 9
log = ('INFO sensor7 #' + body + '\n' + 'WARN sensor9 #' + body + '\n') * 128
messages = re.findall(r'^WARN [^#]+#([^\n]+)$', log, re.M)
print(len(messages), sum(len(msg) for msg in messages), sum(msg.count('reçu') for msg in messages))
""".replace("#' + body + '\n'", "#' + body + '\\n'").replace("[^\n]", "[^\\n]")),
    (dict(prototype, id="scripts.regex.log-split", size=128), """import re
body = 'capture packet status received. ' * 12
log = ('INFO-7:' + body + '\\n' + 'WARN-9:' + body + '\\n') * 64
sections = re.split(r'(?m)^(?:INFO|WARN)-[0-9]+:', log)
print(len(sections), sum(len(msg) for msg in sections), sum(msg.count('packet') for msg in sections))
""")
])
catalog["cases"] = []
for row, source in rows:
    outcome = subprocess.run([python, "-X", "utf8", "-I", "-c", source],
                             check=True, capture_output=True, timeout=15)
    assert not outcome.stderr
    stdout = outcome.stdout.replace(b"\r\n", b"\n")
    fixture = json.loads(row["fixtureJson"])
    fixture["size"] = row["size"]
    fixture_json = json.dumps(fixture, separators=(",", ":"))
    row.update(fixtureJson=fixture_json, fixtureSha256=sha(fixture_json.encode()),
               source=source, sourceSha256=sha(source.encode()), expectedOutput=stdout.decode(),
               expectedOutputSha256=sha(stdout))
    catalog["cases"].append(row)
manifest = lab / "representative.json"
save(manifest, catalog)

identity = load(donor / "quiet/identity.json")["imageFiles"]["reference"]
reference = donor / "quiet-workers/reference"
assert len(identity) == 32 and {name: sha((reference / name).read_bytes()) for name in identity} == identity
images = {}
core = "Lokad.Lython.dll"
for role, root in (("reference", repo), ("candidate", worktree)):
    image = lab / "frozen" / role
    image.mkdir(parents=True, exist_ok=True)
    for name in identity:
        origin = root / "src/Lokad.Lython/bin/Release/net11.0" / name if name == core else reference / name
        shutil.copyfile(origin, image / name)
    images[role] = {name: sha((image / name).read_bytes()) for name in identity}
    for path in source_owner.glob("ValidatedAllocation.*"):
        shutil.copyfile(path, image / path.name)
    receipt = lab / f"{role}-verify.json"
    subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog", manifest,
         "--dotnet", dotnet, "--python", python, "--python-worker", protocol, "--out", receipt],
         env=env, check=True, timeout=90)
    proof = load(receipt)
    assert proof["state"] == "Completed" and proof["caseCount"] == 4 and proof["catalogSha256"] == sha(manifest.read_bytes())
    subprocess.run([dotnet, image / "ValidatedAllocation.dll", image, manifest, lab / f"{role}-allocation.json"],
                   env=env, check=True, timeout=90)
    assert {name: sha((image / name).read_bytes()) for name in identity} == images[role]
assert [name for name in identity if images["reference"][name] != images["candidate"][name]] == [core]
save(lab / "identity.json", dict(reference=baseline, candidate=candidate,
     catalogSHA256=sha(manifest.read_bytes()), imageFiles=images))
before, after = [load(lab / f"{role}-allocation.json")["rows"] for role in ("reference", "candidate")]
result = []
for left, right in zip(before, after, strict=True):
    assert left["id"] == right["id"] and left["sharedBudgetBaselineRestored"] and right["sharedBudgetBaselineRestored"]
    start, end = [statistics.median(row["allocatedBytesPerInvocation"]) for row in (left, right)]
    result.append(dict(case=left["id"], reference=start, candidate=end, allocationChangePercent=100*(end/start-1),
                       referenceAccountedPeak=left["peakExecutionMemoryBytes"], candidateAccountedPeak=right["peakExecutionMemoryBytes"],
                       allowanceRestored=True))
    print(result[-1])
save(lab / "allocation-summary.json", result)
