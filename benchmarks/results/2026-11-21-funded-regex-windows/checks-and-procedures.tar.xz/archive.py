from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
out = Path("benchmarks/results/2026-11-21-funded-regex-windows")
out.mkdir(exist_ok=True)

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

identity = load(lab / "identity.json")
assert identity["reference"] == "151b05134"
assert identity["candidate"] == "d05150e9d"
assert identity["catalogSHA256"] == sha(lab / "representative.json")
for role, expected in identity["imageFiles"].items():
    image = lab / "frozen" / role
    assert len(expected) == 32 and {name: sha(image / name) for name in expected} == expected
    verification = load(lab / f"{role}-verify.json")
    assert verification["state"] == "Completed" and verification["caseCount"] == 4
    assert verification["catalogSha256"] == identity["catalogSHA256"]
for platform in ("win", "ubuntu"):
    for suite, count in (("white", 67), ("public", 422)):
        log = (lab / f"{suite}-{platform}.log").read_text(encoding="utf-8-sig")
        assert "Passed!" in log and f"Passed: {count:5d}, Skipped:" in log

cases = {case["id"]: case for case in load(lab / "representative.json")["cases"]}
allocation = load(lab / "allocation-summary.json")
assert len(cases) == len(allocation) == 4 and all(row["allowanceRestored"] for row in allocation)
timing = load(lab / "local-timing.json")
assert timing["identity"] == identity and len(timing["rows"]) == 4
for row in timing["rows"]:
    case = cases[row["case"]]
    assert len(row["samples"]) == 4
    for samples in row["samples"].values():
        assert len(samples) == 5
        for sample in samples:
            assert sample["status"] == "Completed" and sample["completedInvocations"] > 0
            assert sample["actualOutputSha256"] == case["expectedOutputSha256"]
            assert sample["sourceSha256"] == case["sourceSha256"] and sample["fixtureSha256"] == case["fixtureSha256"]
            assert sample.get("actualFilesSha256") == case.get("expectedFilesSha256")
summary = {
    "collection": "B1293",
    "reference": identity["reference"],
    "candidate": identity["candidate"],
    "verifiedTimedBatches": 80,
    "qualifiedElapsed": False,
    "allocation": allocation,
    "elapsed": [{"case": row["case"], "localChangePercent": row["changePercent"],
                 "processMediansMilliseconds": row["medianMilliseconds"]} for row in timing["rows"]],
}
(out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8", newline="\n")
(lab / "measured-source.patch").write_bytes(subprocess.check_output(
    ["git", "diff", identity["reference"], identity["candidate"], "--", "src", "tests"]))
with tarfile.open(out / "checks-and-procedures.tar.xz", "w:xz", preset=6) as archive:
    for p in sorted(lab.iterdir()):
        if p.is_file() and p.suffix in {".json", ".log", ".py", ".sh", ".patch", ".stderr"}:
            archive.add(p, arcname=p.name)
shutil.copyfile(lab / "README.md", out / "README.md")
print("Verified 80 diagnostic batches, all 64 image entries and cross-platform focused checks.")
