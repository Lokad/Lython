from pathlib import Path
from io import BytesIO
import hashlib
import json
import os
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.parent / "native-only-method-lookup-20261121"
source_run = prior / "quiet"
template = lab.parent / "current-factories-cpython"
quiet = lab / "quiet"

def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def emit(path, source):
    if path.suffix == ".py":
        compile(source, str(path), "exec")
    path.write_text(source, encoding="utf-8", newline="\n")

def save(path, value):
    emit(path, json.dumps(value, indent=2) + "\n")

configured = load(source_run / "config.json")
verified = load(source_run / "archive-receipt.json")
terminal = load(source_run / "terminal-status.json")
assert verified == terminal["receipt"] and terminal["exitCode"] == "0"
assert verified["complete"] and verified["archivedAndVerifiedUnderLease"] and verified["quietBeforeAndAfter"]
assert sha(source_run / "observations.tgz") == verified["archiveSHA256"]
revision = configured["identity"]["sourceRevision"].split()[-1]
origin = subprocess.check_output(["git", "rev-parse", "origin/master"], cwd=repo, text=True).strip()
assert revision.startswith("8f210d967")
assert not subprocess.check_output(["git", "diff", "--name-only", origin, revision, "--", "src", "tests"], cwd=repo)
files = configured["identity"]["imageFiles"]["candidate"]
image = prior / "frozen/candidate"
assert len(files) == 32 and {name: sha(image / name) for name in files} == files
protocol = repo / "benchmarks/cpython-worker.py"
assert sha(protocol) == configured["protocolSHA256"]

quiet.mkdir()
case_id = "scripts.csv-invoice.method-policy"
catalog = load(prior / "representative.json")
catalog["cases"] = [case for case in catalog["cases"] if case["id"] == case_id]
assert len(catalog["cases"]) == 1
manifest = quiet / "representative.json"
save(manifest, catalog)
dotnet = Path.home() / ".dotnet11/dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(dotnet.parent), DOTNET_ROOT_X64=str(dotnet.parent),
           PATH=str(dotnet.parent) + os.pathsep + os.environ["PATH"])
proof_path = lab / "verify.json"
subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog",
                manifest, "--dotnet", dotnet, "--python", "C:/Python313/python.exe", "--python-worker",
                protocol, "--out", proof_path], env=env, check=True, timeout=95)
proof = load(proof_path)
assert proof["state"] == "Completed" and proof["caseCount"] == 1 and proof["catalogSha256"] == sha(manifest)

root = "/home/lokad/lython-bench-checks/cpython-method-invoice-b1298-20261121"
unit = "lython-b1298-cpython-method-invoice-20261121"
core = "Lokad.Lython.dll"
identity = dict(sourceRevision=revision, productionEquivalent=origin, imageSource=revision,
    purpose="Retained CSV policy invoice versus stock CPython", imageFiles=dict(candidate=files),
    catalogSHA256=sha(manifest), cpythonWorkerSHA256=sha(protocol),
    auxiliaryFiles={name: digest for name, digest in files.items() if name != core},
    coreSHA256={label: files[core] for label in ("candidate", "candidate-control")})
save(quiet / "identity.json", identity)
old = load(template / "quiet/config.json")
jobs = [(case_id, lane) for lane in ("warm", "compile", "compile-run")]
for name in ("collect.py", "archive-owned.py", "run.sh", "retrieve.py"):
    text = (template / "quiet" / name).read_text(encoding="utf-8")
    text = text.replace(old["root"], root).replace(old["unit"], unit)
    if name == "collect.py":
        start = text.index("    for case_id,lane in ")
        stop = text.index("        assert time.monotonic()", start)
        text = text[:start] + f"    for case_id,lane in {jobs!r}:\n" + text[stop:]
    if name == "archive-owned.py":
        text = text.replace("len(raw['jobs'])==4", "len(raw['jobs'])==3").replace("jobs=4,", "jobs=3,")
    if name == "retrieve.py":
        text = text.replace("['jobs']==4", "['jobs']==3")
    emit(quiet / name, text.replace("B1285", "B1298"))
assert b"\r" not in (quiet / "run.sh").read_bytes()

# Retire only unpacked duplicates of exact members preserved in the
# Git archive with their original surrounding observations.
member = "confirmation/confirmation.json"
retire = []
for remote, relative in (
    ("current-factories-cpython-b1285-20261121", "2026-11-21-cpython-current-factories/observations.tgz"),
    ("direct-method-control-b1296-20261121", "2026-11-21-native-method-lookup/confirmation/observations.tgz"),
    ("native-only-method-lookup-b1297-20261121", "2026-11-21-native-only-method-lookup/observations.tgz"),
):
    packed = subprocess.check_output(["git", "show", "origin/master:benchmarks/results/" + relative], cwd=repo)
    with tarfile.open(fileobj=BytesIO(packed), mode="r:gz") as file:
        entry = file.getmember(member)
        assert entry.isfile()
        data = file.extractfile(entry).read()
        assert len(data) == entry.size and json.loads(data)["complete"]
    retire.append(dict(paths=[remote + "/" + member], links=1, bytes=len(data),
        sha256=hashlib.sha256(data).hexdigest(),
        archives={remote + "/observations.tgz": hashlib.sha256(packed).hexdigest()}, optional=False))

parts = ("identity.json", "representative.json", "collect.py", "archive-owned.py", "run.sh")
payload = quiet / "payload.tgz"
with tarfile.open(payload, "w:gz") as packed:
    for name in parts:
        packed.add(quiet / name, arcname=name)
config = dict(root=root, unit=unit, identity=identity, source=configured["root"],
    sourceRole="candidate", sourceFiles=files, sourceCatalogSHA256=configured["catalogSHA256"],
    donorArchiveSHA256=verified["archiveSHA256"], catalogSHA256=identity["catalogSHA256"],
    retireGroups=retire, cpythonWorkerSHA256=identity["cpythonWorkerSHA256"],
    payloadBytes=payload.stat().st_size, payloadSHA256=sha(payload),
    unpackedBytes=sum((quiet / name).stat().st_size for name in parts))
save(quiet / "config.json", config)
text = (template / "quiet/remote-launch.py").read_text(encoding="utf-8")
start, end = text.index("\nc=") + 1, text.index("\nb=Path(")
text = text[:start] + "c=" + repr(config) + text[end:]
text = text.replace("lython-b1285-fixtures","lython-b1298-fixtures").replace("c['unpackedBytes']+8*1024*1024","c['unpackedBytes']+640*1024")
old_check = "assert sha(root/'cpython-worker.py')==c['cpythonWorkerSHA256']"
assert old_check in text
text = text.replace(old_check, "os.link(source/'cpython-worker.py',root/'cpython-worker.py')\n " + old_check)
emit(quiet / "remote-launch.py", text)
emit(lab / "launch.py", (template / "launch.py").read_text(encoding="utf-8")
    .replace("B1285 factory", "B1298 method invoice").replace("250", "210"))
print("Prepared warm, compile and compile-to-result lanes for the exact retained image.")
