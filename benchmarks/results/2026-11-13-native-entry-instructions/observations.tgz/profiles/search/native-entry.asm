; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[System.Object],byref,byref,byref):this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 560
       lea      rbp, [rsp+0x230]
       xor      eax, eax
       mov      qword ptr [rbp-0x1C8], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqu32 zmmword ptr [rbp-0x1C0], zmm8
       vmovdqu32 zmmword ptr [rbp-0x180], zmm8
       vmovdqu32 zmmword ptr [rbp-0x140], zmm8
       vmovdqu32 zmmword ptr [rbp-0x100], zmm8
       vmovdqu32 zmmword ptr [rbp-0xC0], zmm8
       vmovdqu  ymmword ptr [rbp-0x80], ymm8
       mov      qword ptr [rbp-0x60], rax
       mov      gword ptr [rbp-0x30], rdi
       mov      gword ptr [rbp-0x38], rsi
       mov      bword ptr [rbp-0x48], rdx
       mov      qword ptr [rbp-0x40], rcx
       mov      gword ptr [rbp-0x50], r8
       mov      gword ptr [rbp-0x58], r9
 
G_M000_IG02:                ;; offset=0x0062
       mov      dword ptr [rbp-0x1B4], 0x3E8
       vxorps   ymm0, ymm0, ymm0
       vmovdqu32 zmmword ptr [rbp-0xD8], zmm0
       vmovdqu32 zmmword ptr [rbp-0x98], zmm0
       lea      rsi, [rbp-0xD8]
       mov      rdi, 0x72AC1E674538
       mov      edx, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,System.__Canon](byref,int):System.Span`1[System.__Canon]]
       mov      bword ptr [rbp-0x158], rax
       mov      qword ptr [rbp-0x150], rdx
 
G_M000_IG03:                ;; offset=0x00AE
       vmovdqu  xmm0, xmmword ptr [rbp-0x158]
       vmovdqu  xmmword ptr [rbp-0xE8], xmm0
 
G_M000_IG04:                ;; offset=0x00BE
       mov      rax, gword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0x1B8], eax
       mov      ecx, dword ptr [rbp-0x1B8]
       lea      rdi, [rbp-0xE8]
       mov      rsi, 0x72AC1DDFB4E8
       xor      edx, edx
       call     [System.Span`1[System.__Canon]:Slice(int,int):System.Span`1[System.__Canon]:this]
       mov      bword ptr [rbp-0x168], rax
       mov      qword ptr [rbp-0x160], rdx
 
G_M000_IG05:                ;; offset=0x0101
       vmovdqu  xmm0, xmmword ptr [rbp-0x168]
       vmovdqu  xmmword ptr [rbp-0xE8], xmm0
 
G_M000_IG06:                ;; offset=0x0111
       mov      rdi, gword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_BindingPlan():Lokad.Lython.Runtime.FunctionBindingPlan:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x1BC], eax
       mov      esi, dword ptr [rbp-0x1BC]
       lea      rdi, [rbp-0x100]
       call     [Lokad.Lython.Runtime.ArgumentPresence:.ctor(int):this]
       movzx    rax, byte  ptr [rbp+0x20]
       test     eax, eax
       je       G_M000_IG11
       mov      rdx, bword ptr [rbp-0xE8]
       mov      rcx, qword ptr [rbp-0xE0]
       lea      rdi, [rbp-0x48]
       mov      rsi, 0x72AC1DDFB3E8
       call     [System.ReadOnlySpan`1[System.__Canon]:CopyTo(System.Span`1[System.__Canon]):this]
       xor      eax, eax
       mov      dword ptr [rbp-0x104], eax
       jmp      SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x0177
       mov      rdi, 0x72AC1E6745B8
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdi, [rbp-0x100]
       mov      esi, dword ptr [rbp-0x104]
       mov      edx, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
       mov      eax, dword ptr [rbp-0x104]
       inc      eax
       mov      dword ptr [rbp-0x104], eax
 
G_M000_IG08:                ;; offset=0x01AC
       mov      eax, dword ptr [rbp-0x1B4]
       dec      eax
       mov      dword ptr [rbp-0x1B4], eax
       cmp      dword ptr [rbp-0x1B4], 0
       jg       SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x01C3
       lea      rdi, [rbp-0x1B4]
       mov      esi, 85
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG10:                ;; offset=0x01D6
       lea      rdi, [rbp-0x100]
       call     [Lokad.Lython.Runtime.ArgumentPresence:get_Length():int:this]
       cmp      eax, dword ptr [rbp-0x104]
       jg       SHORT G_M000_IG07
       jmp      G_M000_IG14
 
G_M000_IG11:                ;; offset=0x01F0
       mov      rdi, 0x72AC1E6745BC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_BindingPlan():Lokad.Lython.Runtime.FunctionBindingPlan:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x1C0], eax
       mov      ecx, dword ptr [rbp-0x1C0]
       lea      rdi, [rbp-0xE8]
       mov      rsi, 0x72AC1DDFB4E8
       xor      edx, edx
       call     [System.Span`1[System.__Canon]:Slice(int,int):System.Span`1[System.__Canon]:this]
       mov      bword ptr [rbp-0x178], rax
       mov      qword ptr [rbp-0x170], rdx
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x118], xmm0
 
G_M000_IG12:                ;; offset=0x0253
       vmovdqu  xmm0, xmmword ptr [rbp-0x118]
       vmovdqu  xmmword ptr [rbp-0x188], xmm0
 
G_M000_IG13:                ;; offset=0x0263
       mov      rdi, gword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_BindingPlan():Lokad.Lython.Runtime.FunctionBindingPlan:this]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rsp+0x08], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x10], eax
       mov      rax, gword ptr [rbp-0x50]
       mov      gword ptr [rsp+0x18], rax
       mov      rax, gword ptr [rbp-0x38]
       mov      gword ptr [rsp+0x20], rax
       lea      rdi, [rsp+0x28]
       lea      rsi, [rbp-0x48]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x28], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rax, gword ptr [rbp-0x1C8]
       mov      gword ptr [rsp], rax
       mov      rdi, bword ptr [rbp-0x178]
       mov      rsi, qword ptr [rbp-0x170]
       lea      rdx, [rbp-0x100]
       mov      rcx, bword ptr [rbp-0x188]
       mov      r8, qword ptr [rbp-0x180]
       mov      r9, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[System.Object],byref,System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object])]
 
G_M000_IG14:                ;; offset=0x02E8
       mov      rdi, 0x72AC1E6745C0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG15:                ;; offset=0x02F7
       vmovdqu  xmm0, xmmword ptr [rbp-0xE8]
       vmovdqu  xmmword ptr [rbp-0x198], xmm0
 
G_M000_IG16:                ;; offset=0x0307
       vmovdqu32 xmm0, xmmword ptr [rbp-0x100]
       vmovdqu32 xmmword ptr [rbp-0x1B0], xmm0
       mov      rax, qword ptr [rbp-0xF0]
       mov      qword ptr [rbp-0x1A0], rax
 
G_M000_IG17:                ;; offset=0x0323
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x148], ymm0
       vmovdqu  xmmword ptr [rbp-0x128], xmm0
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x1B0]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       movsq    
       lea      rdi, [rsp+0x18]
       lea      rsi, [rbp-0x148]
       movsq    
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x20], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x28], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x30], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       movsq    
       lea      rdi, [rsp+0x48]
       lea      rsi, [rbp+0x28]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x48], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x58], rax
       mov      rax, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x60], rax
       movzx    r8, byte  ptr [rbp+0x18]
       mov      rsi, bword ptr [rbp-0x198]
       mov      rdx, qword ptr [rbp-0x190]
       mov      rdi, gword ptr [rbp-0x30]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[System.Object],Lokad.Lython.Runtime.ArgumentPresence,System.Nullable`1[Lokad.Lython.Runtime.BoundCallArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[System.Object],byref,byref,byref):this]
       nop      
 
G_M000_IG18:                ;; offset=0x03EA
       add      rsp, 560
       pop      rbp
       ret      
 
; Total bytes of code 1011

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[System.Object],byref,byref,byref):this (Instrumented Tier0)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Instrumented Tier0 code
; rbp based frame
; partially interruptible
; compiling with minopt

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       sub      rsp, 560
       lea      rbp, [rsp+0x230]
       xor      eax, eax
       mov      qword ptr [rbp-0x1C8], rax
       vxorps   xmm8, xmm8, xmm8
       vmovdqu32 zmmword ptr [rbp-0x1C0], zmm8
       vmovdqu32 zmmword ptr [rbp-0x180], zmm8
       vmovdqu32 zmmword ptr [rbp-0x140], zmm8
       vmovdqu32 zmmword ptr [rbp-0x100], zmm8
       vmovdqu32 zmmword ptr [rbp-0xC0], zmm8
       vmovdqu  ymmword ptr [rbp-0x80], ymm8
       mov      qword ptr [rbp-0x60], rax
       mov      gword ptr [rbp-0x30], rdi
       mov      gword ptr [rbp-0x38], rsi
       mov      bword ptr [rbp-0x48], rdx
       mov      qword ptr [rbp-0x40], rcx
       mov      gword ptr [rbp-0x50], r8
       mov      gword ptr [rbp-0x58], r9
 
G_M000_IG02:                ;; offset=0x0062
       mov      dword ptr [rbp-0x1B4], 0x3E8
       vxorps   ymm0, ymm0, ymm0
       vmovdqu32 zmmword ptr [rbp-0xD8], zmm0
       vmovdqu32 zmmword ptr [rbp-0x98], zmm0
       lea      rsi, [rbp-0xD8]
       mov      rdi, 0x72AC1E674538
       mov      edx, 16
       call     [<PrivateImplementationDetails>:InlineArrayAsSpan[Lokad.Lython.Runtime.PyExecutableFunction+NativeValues,System.__Canon](byref,int):System.Span`1[System.__Canon]]
       mov      bword ptr [rbp-0x158], rax
       mov      qword ptr [rbp-0x150], rdx
 
G_M000_IG03:                ;; offset=0x00AE
       vmovdqu  xmm0, xmmword ptr [rbp-0x158]
       vmovdqu  xmmword ptr [rbp-0xE8], xmm0
 
G_M000_IG04:                ;; offset=0x00BE
       mov      rax, gword ptr [rbp-0x30]
       mov      rdi, gword ptr [rax+0x68]
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Frontend.ExecutableCodeObject:get_ValueStorageCapacity():int:this]
       mov      dword ptr [rbp-0x1B8], eax
       mov      ecx, dword ptr [rbp-0x1B8]
       lea      rdi, [rbp-0xE8]
       mov      rsi, 0x72AC1DDFB4E8
       xor      edx, edx
       call     [System.Span`1[System.__Canon]:Slice(int,int):System.Span`1[System.__Canon]:this]
       mov      bword ptr [rbp-0x168], rax
       mov      qword ptr [rbp-0x160], rdx
 
G_M000_IG05:                ;; offset=0x0101
       vmovdqu  xmm0, xmmword ptr [rbp-0x168]
       vmovdqu  xmmword ptr [rbp-0xE8], xmm0
 
G_M000_IG06:                ;; offset=0x0111
       mov      rdi, gword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_BindingPlan():Lokad.Lython.Runtime.FunctionBindingPlan:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x1BC], eax
       mov      esi, dword ptr [rbp-0x1BC]
       lea      rdi, [rbp-0x100]
       call     [Lokad.Lython.Runtime.ArgumentPresence:.ctor(int):this]
       movzx    rax, byte  ptr [rbp+0x20]
       test     eax, eax
       je       G_M000_IG11
       mov      rdx, bword ptr [rbp-0xE8]
       mov      rcx, qword ptr [rbp-0xE0]
       lea      rdi, [rbp-0x48]
       mov      rsi, 0x72AC1DDFB3E8
       call     [System.ReadOnlySpan`1[System.__Canon]:CopyTo(System.Span`1[System.__Canon]):this]
       xor      eax, eax
       mov      dword ptr [rbp-0x104], eax
       jmp      SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x0177
       mov      rdi, 0x72AC1E6745B8
       call     CORINFO_HELP_COUNTPROFILE32
       lea      rdi, [rbp-0x100]
       mov      esi, dword ptr [rbp-0x104]
       mov      edx, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
       mov      eax, dword ptr [rbp-0x104]
       inc      eax
       mov      dword ptr [rbp-0x104], eax
 
G_M000_IG08:                ;; offset=0x01AC
       mov      eax, dword ptr [rbp-0x1B4]
       dec      eax
       mov      dword ptr [rbp-0x1B4], eax
       cmp      dword ptr [rbp-0x1B4], 0
       jg       SHORT G_M000_IG10
 
G_M000_IG09:                ;; offset=0x01C3
       lea      rdi, [rbp-0x1B4]
       mov      esi, 85
       call     CORINFO_HELP_PATCHPOINT
       jmp      rax
 
G_M000_IG10:                ;; offset=0x01D6
       lea      rdi, [rbp-0x100]
       call     [Lokad.Lython.Runtime.ArgumentPresence:get_Length():int:this]
       cmp      eax, dword ptr [rbp-0x104]
       jg       SHORT G_M000_IG07
       jmp      G_M000_IG14
 
G_M000_IG11:                ;; offset=0x01F0
       mov      rdi, 0x72AC1E6745BC
       call     CORINFO_HELP_COUNTPROFILE32
       mov      rdi, gword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_BindingPlan():Lokad.Lython.Runtime.FunctionBindingPlan:this]
       mov      rdi, rax
       cmp      dword ptr [rdi], edi
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_ParameterCount():int:this]
       mov      dword ptr [rbp-0x1C0], eax
       mov      ecx, dword ptr [rbp-0x1C0]
       lea      rdi, [rbp-0xE8]
       mov      rsi, 0x72AC1DDFB4E8
       xor      edx, edx
       call     [System.Span`1[System.__Canon]:Slice(int,int):System.Span`1[System.__Canon]:this]
       mov      bword ptr [rbp-0x178], rax
       mov      qword ptr [rbp-0x170], rdx
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rbp-0x118], xmm0
 
G_M000_IG12:                ;; offset=0x0253
       vmovdqu  xmm0, xmmword ptr [rbp-0x118]
       vmovdqu  xmmword ptr [rbp-0x188], xmm0
 
G_M000_IG13:                ;; offset=0x0263
       mov      rdi, gword ptr [rbp-0x30]
       call     [Lokad.Lython.Runtime.PyFunctionBase:get_BindingPlan():Lokad.Lython.Runtime.FunctionBindingPlan:this]
       mov      gword ptr [rbp-0x1C8], rax
       mov      rax, gword ptr [rbp-0x58]
       mov      gword ptr [rsp+0x08], rax
       xor      eax, eax
       mov      dword ptr [rsp+0x10], eax
       mov      rax, gword ptr [rbp-0x50]
       mov      gword ptr [rsp+0x18], rax
       mov      rax, gword ptr [rbp-0x38]
       mov      gword ptr [rsp+0x20], rax
       lea      rdi, [rsp+0x28]
       lea      rsi, [rbp-0x48]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x28], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rax, gword ptr [rbp-0x1C8]
       mov      gword ptr [rsp], rax
       mov      rdi, bword ptr [rbp-0x178]
       mov      rsi, qword ptr [rbp-0x170]
       lea      rdx, [rbp-0x100]
       mov      rcx, bword ptr [rbp-0x188]
       mov      r8, qword ptr [rbp-0x180]
       mov      r9, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindFunctionArgumentsInto(System.Span`1[System.Object],byref,System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,bool,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object])]
 
G_M000_IG14:                ;; offset=0x02E8
       mov      rdi, 0x72AC1E6745C0
       call     CORINFO_HELP_COUNTPROFILE32
 
G_M000_IG15:                ;; offset=0x02F7
       vmovdqu  xmm0, xmmword ptr [rbp-0xE8]
       vmovdqu  xmmword ptr [rbp-0x198], xmm0
 
G_M000_IG16:                ;; offset=0x0307
       vmovdqu32 xmm0, xmmword ptr [rbp-0x100]
       vmovdqu32 xmmword ptr [rbp-0x1B0], xmm0
       mov      rax, qword ptr [rbp-0xF0]
       mov      qword ptr [rbp-0x1A0], rax
 
G_M000_IG17:                ;; offset=0x0323
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0x148], ymm0
       vmovdqu  xmmword ptr [rbp-0x128], xmm0
       lea      rdi, [rsp]
       lea      rsi, [rbp-0x1B0]
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       movsq    
       lea      rdi, [rsp+0x18]
       lea      rsi, [rbp-0x148]
       movsq    
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x20], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x28], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x30], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       movsq    
       lea      rdi, [rsp+0x48]
       lea      rsi, [rbp+0x28]
       mov      rcx, bword ptr [rsi]
       mov      bword ptr [rsp+0x48], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       mov      rax, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x58], rax
       mov      rax, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x60], rax
       movzx    r8, byte  ptr [rbp+0x18]
       mov      rsi, bword ptr [rbp-0x198]
       mov      rdx, qword ptr [rbp-0x190]
       mov      rdi, gword ptr [rbp-0x30]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[System.Object],Lokad.Lython.Runtime.ArgumentPresence,System.Nullable`1[Lokad.Lython.Runtime.BoundCallArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[System.Object],byref,byref,byref):this]
       nop      
 
G_M000_IG18:                ;; offset=0x03EA
       add      rsp, 560
       pop      rbp
       ret      
 
; Total bytes of code 1011

; Assembly listing for method Lokad.Lython.Runtime.PyExecutableFunction:StartNativeCall(Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object],System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool,bool,System.Span`1[System.Object],byref,byref,byref):this (Tier1)
; Emitting BLENDED_CODE for x64 + VEX + EVEX on Unix
; Tier1 code
; optimized code
; optimized using Synthesized PGO
; rbp based frame
; fully interruptible
; with Synthesized PGO: fgCalledCount is 1026176
; 28 inlinees with PGO data; 72 single block inlinees; 2 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     rbp
       push     r15
       push     r14
       push     r13
       push     r12
       push     rbx
       sub      rsp, 632
       lea      rbp, [rsp+0x2A0]
       vxorps   xmm8, xmm8, xmm8
       vmovdqu32 zmmword ptr [rbp-0x180], zmm8
       vmovdqu32 zmmword ptr [rbp-0x140], zmm8
       vmovdqu32 zmmword ptr [rbp-0x100], zmm8
       vmovdqu32 zmmword ptr [rbp-0xC0], zmm8
       vmovdqu32 zmmword ptr [rbp-0x80], zmm8
       vmovdqa  xmmword ptr [rbp-0x40], xmm8
       xor      eax, eax
       mov      qword ptr [rbp-0x30], rax
       mov      bword ptr [rbp-0x208], rdx
       mov      rbx, rdi
       mov      r13, rsi
       mov      r12d, ecx
       mov      r14, r8
       mov      r15, r9
 
G_M000_IG02:                ;; offset=0x0062
       mov      rsi, gword ptr [rbx+0x68]
       mov      edx, dword ptr [rsi+0x9C]
       mov      edi, dword ptr [rsi+0x98]
       mov      r8d, 4
       cmp      edi, 4
       cmovg    r8d, edi
       add      edx, r8d
       jo       G_M000_IG110
       add      edx, dword ptr [rsi+0xA4]
       jo       G_M000_IG110
       cmp      edx, 16
       ja       G_M000_IG75
       mov      rcx, gword ptr [rbp+0x10]
       mov      dword ptr [rbp-0x184], edx
       mov      rsi, gword ptr [rbx+0x08]
       mov      r8, gword ptr [rsi+0x08]
       mov      gword ptr [rbp-0x230], r8
       mov      r9, gword ptr [r8+0x08]
       mov      gword ptr [rbp-0x228], r9
       mov      esi, dword ptr [r9+0x08]
       mov      dword ptr [rbp-0xB0], esi
       xor      edi, edi
       mov      qword ptr [rbp-0xB8], rdi
       cmp      esi, 64
       jg       G_M000_IG76
       mov      r10, 0x72AC18653EF8
 
G_M000_IG03:                ;; offset=0x00E7
       mov      gword ptr [rbp-0xC0], r10
       cmp      byte  ptr [rbp+0x20], 0
       jne      G_M000_IG77
 
G_M000_IG04:                ;; offset=0x00F8
       mov      r9, gword ptr [rbp-0x228]
       mov      r9d, dword ptr [r9+0x08]
       cmp      r9d, dword ptr [rbp-0x184]
       ja       G_M000_IG75
       mov      dword ptr [rbp-0x188], r9d
       mov      r10, gword ptr [rbx+0x08]
       mov      gword ptr [rbp-0x198], r10
       mov      rax, bword ptr [rbp-0x208]
       mov      r11, rax
       mov      bword ptr [rbp-0x210], r11
       mov      edi, r12d
       xor      rsi, rsi
       mov      gword ptr [rbp-0xF8], rsi
 
G_M000_IG05:                ;; offset=0x013F
       mov      gword ptr [rbp-0x100], rsi
 
G_M000_IG06:                ;; offset=0x0146
       mov      r8, gword ptr [rbp-0x230]
       cmp      dword ptr [r8+0x28], 0
       jge      G_M000_IG82
       test     r13, r13
       je       SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x015D
       movzx    rax, byte  ptr [r13+0x34]
       test     eax, eax
       je       G_M000_IG81
 
G_M000_IG08:                ;; offset=0x016A
       mov      eax, dword ptr [r8+0x18]
       test     r14, r14
       setne    r8b
       movzx    r8, r8b
       sub      eax, r8d
       cmp      eax, edi
       jl       G_M000_IG84
       test     r14, r14
       jne      G_M000_IG85
 
G_M000_IG09:                ;; offset=0x018D
       test     edi, edi
       je       SHORT G_M000_IG12
 
G_M000_IG10:                ;; offset=0x0191
       xor      r14d, r14d
       mov      r13d, edi
 
G_M000_IG11:                ;; offset=0x0197
       lea      edi, [rsi+0x01]
       mov      r12d, edi
       cmp      esi, r9d
       jae      G_M000_IG111
       lea      rdi, bword ptr [rbp-0xA8]
       mov      esi, esi
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, gword ptr [r11+r14]
       test     rsi, rsi
       je       G_M000_IG86
       mov      gword ptr [rbp+0x10], rcx
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       add      r14, 8
       dec      r13d
       mov      esi, r12d
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9d, dword ptr [rbp-0x188]
       mov      r11, bword ptr [rbp-0x210]
       jne      SHORT G_M000_IG11
 
G_M000_IG12:                ;; offset=0x01E7
       xor      edi, edi
       test     esi, esi
       jle      SHORT G_M000_IG15
 
G_M000_IG13:                ;; offset=0x01ED
       mov      eax, dword ptr [rbp-0xB0]
       cmp      edi, eax
       jae      G_M000_IG87
       cmp      edi, 64
       jge      G_M000_IG88
       mov      rax, qword ptr [rbp-0xB8]
       bts      rax, rdi
       mov      qword ptr [rbp-0xB8], rax
 
G_M000_IG14:                ;; offset=0x0216
       inc      edi
       cmp      edi, esi
       jl       SHORT G_M000_IG13
 
G_M000_IG15:                ;; offset=0x021C
       xor      r12d, r12d
       mov      r10, gword ptr [rbp-0x198]
       mov      rdi, gword ptr [r10+0x08]
       cmp      dword ptr [rdi+0x18], 0
       jle      SHORT G_M000_IG18
 
G_M000_IG16:                ;; offset=0x0230
       mov      esi, dword ptr [rbp-0xB0]
       cmp      r12d, esi
       jae      G_M000_IG89
       cmp      r12d, 64
       jge      G_M000_IG90
       mov      rdi, qword ptr [rbp-0xB8]
       bt       rdi, r12
       jae      G_M000_IG91
 
G_M000_IG17:                ;; offset=0x025A
       inc      r12d
       mov      rdi, gword ptr [r10+0x08]
       cmp      r12d, dword ptr [rdi+0x18]
       jl       SHORT G_M000_IG16
 
G_M000_IG18:                ;; offset=0x0267
       xor      r12d, r12d
       jmp      G_M000_IG61
 
G_M000_IG19:                ;; offset=0x026F
       mov      rdi, rax
       mov      rsi, r8
       mov      rdx, r15
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyDict:PrepareQueryKey(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.ValueTuple`2[uint,bool]:this]
       mov      qword ptr [rbp-0x158], rax
       mov      eax, dword ptr [rbp-0x158]
       mov      dword ptr [rbp-0x15C], eax
       movzx    rcx, byte  ptr [rbp-0x154]
       mov      dword ptr [rbp-0x160], ecx
       mov      rdx, gword ptr [rbp-0x1A0]
       cmp      gword ptr [rdx+0x28], 0
       je       G_M000_IG32
       cmp      dword ptr [rdx+0x50], 0
       jne      G_M000_IG31
 
G_M000_IG20:                ;; offset=0x02BE
       mov      ecx, dword ptr [rbp-0x160]
       test     ecx, ecx
       jne      G_M000_IG49
       mov      rcx, gword ptr [rdx+0x28]
       mov      gword ptr [rbp-0x1C0], rcx
       cmp      dword ptr [rdx+0x4C], 0
       je       G_M000_IG33
 
G_M000_IG21:                ;; offset=0x02E1
       mov      edi, dword ptr [rcx+0x08]
       blsr     esi, edi
       jne      G_M000_IG34
       dec      edi
       and      edi, dword ptr [rbp-0x158]
 
G_M000_IG22:                ;; offset=0x02F7
       cmp      edi, dword ptr [rcx+0x08]
       jae      G_M000_IG54
       mov      edi, edi
       lea      rdi, [rdi+4*rdi]
       mov      esi, dword ptr [rcx+8*rdi+0x30]
       dec      esi
       js       G_M000_IG37
 
G_M000_IG23:                ;; offset=0x0312
       cmp      esi, dword ptr [rcx+0x08]
       jae      G_M000_IG54
       mov      edi, esi
       lea      rdi, [rdi+4*rdi]
       lea      r8, bword ptr [rcx+8*rdi+0x10]
       mov      bword ptr [rbp-0x1C8], r8
       mov      rdx, gword ptr [rbp-0x1A0]
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG36
 
G_M000_IG24:                ;; offset=0x033F
       mov      eax, dword ptr [rbp-0x15C]
       cmp      dword ptr [r8+0x18], eax
       jne      G_M000_IG38
       mov      rdi, 0x72A43D801818
       mov      r9, gword ptr [rdi]
       mov      gword ptr [rbp-0x1D0], r9
       mov      r10, gword ptr [r8]
       mov      gword ptr [rbp-0x1D8], r10
       mov      r11, r15
       test     r11, r11
       je       G_M000_IG39
 
G_M000_IG25:                ;; offset=0x0379
       mov      rdi, gword ptr [rbp+0x10]
       mov      r9, rdi
       test     r9, r9
       je       G_M000_IG40
 
G_M000_IG26:                ;; offset=0x0389
       mov      r10, gword ptr [rbp-0x1D8]
       mov      rax, gword ptr [rbp-0x1B8]
       cmp      r10, rax
       jne      G_M000_IG41
       test     rax, rax
       mov      r8, bword ptr [rbp-0x1C8]
       je       G_M000_IG38
 
G_M000_IG27:                ;; offset=0x03B0
       mov      eax, esi
 
G_M000_IG28:                ;; offset=0x03B2
       test     eax, eax
       jl       G_M000_IG56
       mov      rcx, gword ptr [rdx+0x30]
       test     rcx, rcx
       je       G_M000_IG55
       cmp      gword ptr [rdx+0x20], 0
       jne      G_M000_IG53
       mov      gword ptr [rbp-0x1F0], rcx
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG54
       mov      esi, eax
       mov      r8, gword ptr [rcx+8*rsi+0x10]
       test     r8, r8
       je       G_M000_IG52
 
G_M000_IG29:                ;; offset=0x03F2
       mov      rcx, r8
 
G_M000_IG30:                ;; offset=0x03F5
       mov      gword ptr [rbp-0x110], rcx
       not      eax
       shr      eax, 31
       mov      dword ptr [rbp-0x164], eax
       jmp      G_M000_IG57
 
G_M000_IG31:                ;; offset=0x040C
       mov      ecx, dword ptr [rbp-0x160]
       jmp      G_M000_IG49
 
G_M000_IG32:                ;; offset=0x0417
       mov      rdi, gword ptr [rdx+0x08]
       mov      r11, 0x72AC1BC62BD8
       call     [r11]Lokad.Lython.Runtime.IPyDictStorage:get_HasProtocolKeys():bool:this
       test     eax, eax
       mov      rdx, gword ptr [rbp-0x1A0]
       jne      SHORT G_M000_IG35
       jmp      G_M000_IG20
 
G_M000_IG33:                ;; offset=0x0438
       mov      rdx, gword ptr [rbp-0x1A0]
       jmp      G_M000_IG48
 
G_M000_IG34:                ;; offset=0x0444
       mov      eax, dword ptr [rbp-0x158]
       xor      edx, edx
       div      edx:eax, edi
       mov      edi, edx
       jmp      G_M000_IG22
 
G_M000_IG35:                ;; offset=0x0455
       mov      ecx, dword ptr [rbp-0x160]
       jmp      G_M000_IG49
 
G_M000_IG36:                ;; offset=0x0460
       mov      rdi, gword ptr [rdx+0x30]
       cmp      dword ptr [rdi+0x08], esi
       jbe      SHORT G_M000_IG38
       mov      rdi, gword ptr [rdx+0x30]
       cmp      esi, dword ptr [rdi+0x08]
       jae      G_M000_IG54
       mov      dword ptr [rbp-0x16C], esi
       mov      r9d, esi
       cmp      gword ptr [rdi+8*r9+0x10], 0
       setne    dil
       movzx    rdi, dil
       test     edi, edi
       mov      rdx, gword ptr [rbp-0x1A0]
       mov      esi, dword ptr [rbp-0x16C]
       je       SHORT G_M000_IG38
       jmp      G_M000_IG24
 
G_M000_IG37:                ;; offset=0x04A3
       mov      rdx, gword ptr [rbp-0x1A0]
       jmp      G_M000_IG48
 
G_M000_IG38:                ;; offset=0x04AF
       mov      r9, gword ptr [rbp+0x10]
       mov      rsi, r9
       test     rsi, rsi
       je       G_M000_IG46
       jmp      G_M000_IG47
 
G_M000_IG39:                ;; offset=0x04C4
       mov      dword ptr [rbp-0x16C], esi
       mov      edi, 19
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       mov      r11, gword ptr [rax+0x18]
       mov      rax, r11
       mov      r11, rax
       mov      rdx, gword ptr [rbp-0x1A0]
       mov      esi, dword ptr [rbp-0x16C]
       jmp      G_M000_IG25
 
G_M000_IG40:                ;; offset=0x04F1
       mov      r9, gword ptr [rdx+0x18]
       mov      gword ptr [rbp-0x1E8], r9
       mov      rdx, gword ptr [rbp-0x1A0]
       mov      r9, gword ptr [rbp-0x1E8]
       jmp      G_M000_IG26
 
G_M000_IG41:                ;; offset=0x050F
       mov      gword ptr [rbp-0x1E0], r11
       test     r11, r11
       mov      dword ptr [rbp-0x16C], esi
       mov      gword ptr [rbp-0x1E8], r9
       je       SHORT G_M000_IG42
       mov      rsi, r10
       mov      rdi, 0x72AC1E2DE6B0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       je       SHORT G_M000_IG43
       mov      r8, gword ptr [rbp-0x1B8]
       mov      rsi, r8
       test     rsi, rsi
       mov      r10, gword ptr [rbp-0x1D8]
       jne      SHORT G_M000_IG44
       mov      rax, gword ptr [rbp-0x1B8]
 
G_M000_IG42:                ;; offset=0x055C
       mov      rdi, gword ptr [rbp-0x1D0]
       mov      rsi, r10
       mov      rdx, rax
       call     [Lokad.Lython.Runtime.PyValueComparer:Equals(System.Object,System.Object):bool:this]
       jmp      SHORT G_M000_IG45
 
G_M000_IG43:                ;; offset=0x0571
       mov      rax, gword ptr [rbp-0x1B8]
       mov      r10, gword ptr [rbp-0x1D8]
       jmp      SHORT G_M000_IG42
 
G_M000_IG44:                ;; offset=0x0581
       mov      rdi, rax
       mov      rdx, gword ptr [rbp-0x1E0]
       mov      rcx, gword ptr [rbp-0x1E8]
       call     [Lokad.Lython.Runtime.Text.PyString:Equals(Lokad.Lython.Runtime.Text.PyString,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):bool:this]
 
G_M000_IG45:                ;; offset=0x0598
       test     eax, eax
       mov      rdx, gword ptr [rbp-0x1A0]
       mov      esi, dword ptr [rbp-0x16C]
       mov      r8, bword ptr [rbp-0x1C8]
       je       G_M000_IG38
       jmp      G_M000_IG27
 
G_M000_IG46:                ;; offset=0x05B9
       mov      rsi, gword ptr [rdx+0x18]
 
G_M000_IG47:                ;; offset=0x05BD
       mov      rdi, r15
       call     [Lokad.Lython.Runtime.PyStructuralGuard:NoteWork(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan)]
       mov      rdi, bword ptr [rbp-0x1C8]
       mov      esi, dword ptr [rdi+0x1C]
       dec      esi
       mov      eax, esi
       test     eax, eax
       mov      esi, eax
       mov      rcx, gword ptr [rbp-0x1C0]
       jge      G_M000_IG23
       mov      rdx, gword ptr [rbp-0x1A0]
 
G_M000_IG48:                ;; offset=0x05EC
       mov      eax, -1
       jmp      G_M000_IG28
 
G_M000_IG49:                ;; offset=0x05F6
       test     r15, r15
       jne      SHORT G_M000_IG51
       mov      rdi, rdx
       mov      rsi, gword ptr [rbp-0x1B8]
       call     [Lokad.Lython.Runtime.PyDict:FindNativeIdentity(System.Object):int:this]
       test     eax, eax
       jge      SHORT G_M000_IG50
       mov      rdi, gword ptr [rbp-0x1A0]
       mov      rsi, gword ptr [rbp-0x1B8]
       mov      edx, dword ptr [rbp-0x158]
       xor      rcx, rcx
       xor      r8, r8
       call     [Lokad.Lython.Runtime.PyDict:FindNativeIndex(System.Object,uint,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):int:this]
       mov      rdx, gword ptr [rbp-0x1A0]
       jmp      G_M000_IG28
 
G_M000_IG50:                ;; offset=0x063A
       mov      rdx, gword ptr [rbp-0x1A0]
       jmp      G_M000_IG28
 
G_M000_IG51:                ;; offset=0x0646
       xor      esi, esi
       mov      dword ptr [rsp], esi
       mov      rdi, rdx
       mov      rsi, gword ptr [rbp-0x1B8]
       mov      edx, dword ptr [rbp-0x158]
       mov      r8, r15
       mov      r9, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyDict:ResolveContextualKey(System.Object,uint,bool,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,bool):int:this]
       mov      rdx, gword ptr [rbp-0x1A0]
       jmp      G_M000_IG28
 
G_M000_IG52:                ;; offset=0x0674
       vxorps   xmm0, xmm0, xmm0
       vmovdqu32 xmmword ptr [rbp-0x180], xmm0
       mov      rsi, gword ptr [rdx+0x28]
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG54
       mov      dword ptr [rbp-0x168], eax
       mov      edx, eax
       lea      rdx, [rdx+4*rdx]
       mov      rsi, qword ptr [rsi+8*rdx+0x20]
       lea      rdi, [rbp-0x180]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rdi, 0x72AC1E2E9A20
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x1F8], rax
       lea      rdi, bword ptr [rax+0x08]
       mov      rsi, gword ptr [rbp-0x180]
       call     CORINFO_HELP_ASSIGN_REF
       mov      esi, dword ptr [rbp-0x178]
       mov      rax, gword ptr [rbp-0x1F8]
       mov      dword ptr [rax+0x10], esi
       mov      gword ptr [rbp-0x200], rax
       mov      esi, dword ptr [rbp-0x168]
       mov      rdi, gword ptr [rbp-0x1F0]
       mov      rdx, rax
       call     CORINFO_HELP_ARRADDR_ST
       mov      rdi, gword ptr [rbp-0x200]
       mov      rcx, rdi
       mov      eax, dword ptr [rbp-0x168]
       jmp      G_M000_IG30
 
G_M000_IG53:                ;; offset=0x0711
       cmp      eax, dword ptr [rcx+0x08]
       jae      SHORT G_M000_IG54
       mov      edx, eax
       mov      rcx, gword ptr [rcx+8*rdx+0x10]
       jmp      G_M000_IG30
 
G_M000_IG54:                ;; offset=0x0722
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG55:                ;; offset=0x0728
       mov      rcx, 0x72A43D801728
       mov      r8, gword ptr [rcx]
       jmp      G_M000_IG29
 
G_M000_IG56:                ;; offset=0x073A
       mov      rcx, 0x72A43D801728
       mov      rcx, gword ptr [rcx]
       jmp      G_M000_IG30
 
G_M000_IG57:                ;; offset=0x074C
       cmp      byte  ptr [rbp-0x18C], 0
       jne      G_M000_IG99
 
G_M000_IG58:                ;; offset=0x0759
       mov      eax, dword ptr [rbp-0x164]
 
G_M000_IG59:                ;; offset=0x075F
       test     eax, eax
       je       G_M000_IG100
       mov      r14d, dword ptr [rbp-0x188]
       cmp      r13d, r14d
       jae      G_M000_IG111
       lea      rsi, bword ptr [rbp-0xA8]
       mov      eax, r13d
       lea      rdi, bword ptr [rsi+8*rax]
       mov      rsi, gword ptr [rbp-0x110]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      r9d, r14d
       mov      rcx, gword ptr [rbp+0x10]
       mov      r10, gword ptr [rbp-0x198]
 
G_M000_IG60:                ;; offset=0x079F
       inc      r12d
 
G_M000_IG61:                ;; offset=0x07A2
       mov      r14, gword ptr [r10+0x08]
       cmp      r12d, dword ptr [r14+0x1C]
       jge      G_M000_IG67
 
G_M000_IG62:                ;; offset=0x07B0
       mov      edi, r12d
       add      edi, dword ptr [r14+0x18]
       mov      r13d, edi
       mov      esi, dword ptr [rbp-0xB0]
       cmp      r13d, esi
       jae      G_M000_IG94
       cmp      r13d, 64
       jge      G_M000_IG95
       mov      rax, qword ptr [rbp-0xB8]
       bt       rax, r13
       jb       SHORT G_M000_IG60
 
G_M000_IG63:                ;; offset=0x07E0
       mov      gword ptr [rbp+0x10], rcx
 
G_M000_IG64:                ;; offset=0x07E4
       mov      rax, gword ptr [r14+0x08]
       cmp      edi, dword ptr [rax+0x08]
       jae      G_M000_IG111
       mov      edi, edi
       mov      r14, gword ptr [rax+8*rdi+0x10]
       mov      rdi, r10
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:get_KeywordDefaultStorage():Lokad.Lython.Runtime.PyDict:this]
       mov      gword ptr [rbp-0x1A0], rax
       test     rax, rax
       je       G_M000_IG100
       mov      rcx, gword ptr [rbp-0x198]
       mov      rdi, gword ptr [rcx+0x28]
       cmp      r12d, dword ptr [rdi+0x08]
       jae      G_M000_IG111
       mov      r8, gword ptr [rdi+8*r12+0x10]
       mov      gword ptr [rbp-0x1B8], r8
       cmp      gword ptr [rax+0x28], 0
       je       G_M000_IG96
       test     r8, r8
       je       G_M000_IG98
       mov      r8, gword ptr [rbp-0x1B8]
       cmp      dword ptr [rax+0x50], 0
       setne    dil
       movzx    rdi, dil
       test     edi, edi
       jne      G_M000_IG97
 
G_M000_IG65:                ;; offset=0x0861
       mov      rax, gword ptr [rbp-0x1A0]
       xor      r9, r9
       xor      r10, r10
       xor      r11d, r11d
 
G_M000_IG66:                ;; offset=0x0871
       mov      gword ptr [rbp-0x218], r9
       mov      gword ptr [rbp-0x220], r10
       mov      byte  ptr [rbp-0x18C], r11b
       jmp      G_M000_IG19
 
G_M000_IG67:                ;; offset=0x088B
       cmp      dword ptr [r14+0x28], 0
       jge      G_M000_IG101
 
G_M000_IG68:                ;; offset=0x0896
       mov      rdi, gword ptr [r10+0x08]
       cmp      dword ptr [rdi+0x2C], 0
       jge      G_M000_IG106
 
G_M000_IG69:                ;; offset=0x08A4
       xor      rdi, rdi
       mov      gword ptr [rbp-0xF8], rdi
 
G_M000_IG70:                ;; offset=0x08AD
       mov      gword ptr [rbp-0x100], rdi
 
G_M000_IG71:                ;; offset=0x08B4
       mov      gword ptr [rbp-0x108], rdi
 
G_M000_IG72:                ;; offset=0x08BB
       mov      gword ptr [rbp-0x110], rdi
       mov      gword ptr [rbp+0x10], rcx
 
G_M000_IG73:                ;; offset=0x08C6
       mov      rdi, gword ptr [rbp-0xC0]
       mov      rsi, qword ptr [rbp-0xB8]
       mov      r8d, dword ptr [rbp-0xB0]
       vxorps   ymm0, ymm0, ymm0
       vmovdqu  ymmword ptr [rbp-0xF0], ymm0
       vmovdqu32 xmmword ptr [rbp-0xD0], xmm0
       mov      gword ptr [rsp], rdi
       mov      qword ptr [rsp+0x08], rsi
       mov      dword ptr [rsp+0x10], r8d
       lea      rdi, [rsp+0x18]
       lea      rsi, [rbp-0xF0]
       movsq    
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x20], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x28], rcx
       add      rsi, 8
       add      rdi, 8
       mov      rcx, gword ptr [rsi]
       mov      gword ptr [rsp+0x30], rcx
       add      rsi, 8
       add      rdi, 8
       movsq    
       movsq    
       mov      r15, bword ptr [rbp+0x28]
       mov      bword ptr [rsp+0x48], r15
       mov      r14d, dword ptr [rbp+0x30]
       mov      dword ptr [rsp+0x50], r14d
       mov      r15, bword ptr [rbp+0x40]
       mov      bword ptr [rsp+0x58], r15
       mov      r15, bword ptr [rbp+0x48]
       mov      bword ptr [rsp+0x60], r15
       lea      rsi, bword ptr [rbp-0xA8]
       mov      edx, dword ptr [rbp-0x184]
       movzx    r8, byte  ptr [rbp+0x18]
       mov      rdi, rbx
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9, bword ptr [rbp+0x38]
       call     [Lokad.Lython.Runtime.PyExecutableFunction:StartInline(System.Span`1[System.Object],Lokad.Lython.Runtime.ArgumentPresence,System.Nullable`1[Lokad.Lython.Runtime.BoundCallArguments],Lokad.Lython.LythonSourceSpan,bool,System.Span`1[System.Object],byref,byref,byref):this]
       nop      
 
G_M000_IG74:                ;; offset=0x0986
       add      rsp, 632
       pop      rbx
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       pop      rbp
       ret      
 
G_M000_IG75:                ;; offset=0x0998
       call     [System.ThrowHelper:ThrowArgumentOutOfRangeException()]
       int3     
 
G_M000_IG76:                ;; offset=0x099F
       mov      gword ptr [rbp+0x10], rcx
       add      esi, -64
       mov      rdi, 0x72AC1D663830
       call     CORINFO_HELP_NEWARR_1_VC
       mov      r10, rax
       mov      rcx, gword ptr [rbp+0x10]
       jmp      G_M000_IG03
 
G_M000_IG77:                ;; offset=0x09C1
       mov      rax, bword ptr [rbp-0x208]
       mov      edx, dword ptr [rbp-0x184]
       cmp      r12d, edx
       ja       SHORT G_M000_IG78
       mov      gword ptr [rbp+0x10], rcx
       mov      edi, r12d
       lea      rdx, [8*rdi]
       lea      rdi, bword ptr [rbp-0xA8]
       mov      rsi, rax
       call     [System.Buffer:BulkMoveWithWriteBarrier(byref,byref,nuint)]
       xor      r15d, r15d
       jmp      SHORT G_M000_IG80
 
G_M000_IG78:                ;; offset=0x09F7
       call     [System.ThrowHelper:ThrowArgumentException_DestinationTooShort()]
       int3     
 
G_M000_IG79:                ;; offset=0x09FE
       lea      rdi, [rbp-0xC0]
       mov      esi, r15d
       mov      edx, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
       inc      r15d
 
G_M000_IG80:                ;; offset=0x0A16
       cmp      r15d, dword ptr [rbp-0xB0]
       jl       SHORT G_M000_IG79
       jmp      G_M000_IG73
 
G_M000_IG81:                ;; offset=0x0A24
       mov      gword ptr [rbp+0x10], rcx
       jmp      SHORT G_M000_IG83
 
G_M000_IG82:                ;; offset=0x0A2A
       mov      gword ptr [rbp+0x10], rcx
 
G_M000_IG83:                ;; offset=0x0A2E
       mov      r10, gword ptr [rbp-0x198]
       mov      gword ptr [rsp], r10
       mov      gword ptr [rsp+0x08], r15
       mov      gword ptr [rsp+0x10], r14
       mov      gword ptr [rsp+0x18], r13
       mov      rax, bword ptr [rbp-0x208]
       mov      bword ptr [rsp+0x20], rax
       mov      dword ptr [rsp+0x28], r12d
       lea      rdi, [rbp-0xF8]
       mov      qword ptr [rsp+0x30], rdi
       lea      rdi, [rbp-0x100]
       mov      qword ptr [rsp+0x38], rdi
       lea      rdi, bword ptr [rbp-0xA8]
       mov      esi, r9d
       lea      rdx, [rbp-0xC0]
       xor      rcx, rcx
       xor      r8d, r8d
       mov      r9, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:BindSuppliedFunctionArguments(System.Span`1[System.Object],byref,System.ReadOnlySpan`1[Lokad.Lython.Runtime.CallArgumentValue],Lokad.Lython.LythonSourceSpan,Lokad.Lython.Runtime.FunctionBindingPlan,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,System.Object,Lokad.Lython.Frontend.ExecutableCallSite,System.ReadOnlySpan`1[System.Object],byref,byref)]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9d, dword ptr [rbp-0x188]
       jmp      G_M000_IG15
 
G_M000_IG84:                ;; offset=0x0AA1
       mov      r10, gword ptr [rbp-0x198]
       mov      edi, dword ptr [r10+0x30]
       mov      rsi, gword ptr [r10+0x10]
       mov      rdx, rcx
       call     [Lokad.Lython.Runtime.CallErrors:TooManyPositional(int,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG85:                ;; offset=0x0AC2
       mov      esi, 1
       test     r9d, r9d
       je       G_M000_IG111
       mov      gword ptr [rbp-0xA8], r14
       jmp      G_M000_IG09
 
G_M000_IG86:                ;; offset=0x0ADC
       mov      rdi, 0x72AC1D597A68
       call     CORINFO_HELP_NEWSFAST
       mov      r15, rax
       mov      rdi, r15
       mov      rsi, 0x72AC1860E590
       call     [System.InvalidOperationException:.ctor(System.String):this]
       mov      rdi, r15
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG87:                ;; offset=0x0B0A
       mov      esi, eax
       mov      rdx, 0x72AC18653F10
       call     [System.ArgumentOutOfRangeException:ThrowGreaterEqual[uint](uint,uint,System.String)]
       int3     
 
G_M000_IG88:                ;; offset=0x0B1D
       lea      eax, [rdi-0x40]
       mov      r8, gword ptr [rbp-0xC0]
       cmp      eax, dword ptr [r8+0x08]
       jae      G_M000_IG111
       mov      rax, gword ptr [rbp-0xC0]
       lea      r8d, [rdi-0x40]
       mov      byte  ptr [rax+r8+0x10], 1
       jmp      G_M000_IG14
 
G_M000_IG89:                ;; offset=0x0B47
       mov      edi, r12d
       mov      rdx, 0x72AC18653F10
       call     [System.ArgumentOutOfRangeException:ThrowGreaterEqual[uint](uint,uint,System.String)]
       int3     
 
G_M000_IG90:                ;; offset=0x0B5B
       lea      edi, [r12-0x40]
       mov      rsi, gword ptr [rbp-0xC0]
       cmp      edi, dword ptr [rsi+0x08]
       jae      G_M000_IG111
       mov      rdi, gword ptr [rbp-0xC0]
       lea      esi, [r12-0x40]
       movzx    rdi, byte  ptr [rdi+rsi+0x10]
       test     edi, edi
       jne      G_M000_IG17
       mov      gword ptr [rbp+0x10], rcx
       jmp      SHORT G_M000_IG92
 
G_M000_IG91:                ;; offset=0x0B90
       mov      gword ptr [rbp+0x10], rcx
 
G_M000_IG92:                ;; offset=0x0B94
       mov      rdi, gword ptr [r10+0x08]
       mov      rdi, gword ptr [rdi+0x08]
       cmp      r12d, dword ptr [rdi+0x08]
       jae      G_M000_IG111
       mov      r14, gword ptr [rdi+8*r12+0x10]
       lea      rdx, [rbp-0x108]
       mov      rdi, r10
       mov      esi, r12d
       call     [Lokad.Lython.Runtime.FunctionBindingPlan:TryGetPositionalDefault(int,byref):bool:this]
       test     eax, eax
       je       SHORT G_M000_IG93
       cmp      r12d, dword ptr [rbp-0x188]
       jae      G_M000_IG111
       lea      rdi, bword ptr [rbp-0xA8]
       lea      rdi, bword ptr [rdi+8*r12]
       mov      rsi, gword ptr [rbp-0x108]
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9d, dword ptr [rbp-0x188]
       mov      r10, gword ptr [rbp-0x198]
       jmp      G_M000_IG17
 
G_M000_IG93:                ;; offset=0x0BFD
       mov      r15, gword ptr [rbp-0x198]
       mov      edi, dword ptr [r15+0x30]
       mov      rsi, gword ptr [r15+0x10]
       mov      rdx, r14
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.CallErrors:MissingArgument(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG94:                ;; offset=0x0C22
       mov      edi, r13d
       mov      rdx, 0x72AC18653F10
       call     [System.ArgumentOutOfRangeException:ThrowGreaterEqual[uint](uint,uint,System.String)]
       int3     
 
G_M000_IG95:                ;; offset=0x0C36
       lea      eax, [r13-0x40]
       mov      rsi, gword ptr [rbp-0xC0]
       cmp      eax, dword ptr [rsi+0x08]
       jae      G_M000_IG111
       mov      rax, gword ptr [rbp-0xC0]
       lea      esi, [r13-0x40]
       movzx    rax, byte  ptr [rax+rsi+0x10]
       test     eax, eax
       jne      G_M000_IG60
       mov      gword ptr [rbp+0x10], rcx
       jmp      G_M000_IG64
 
G_M000_IG96:                ;; offset=0x0C6B
       lea      r8, [rbp-0x110]
       mov      rdi, rax
       mov      rsi, gword ptr [rbp-0x1B8]
       mov      rdx, r15
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyDict:TryGetBridgeValue(System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan,byref):bool:this]
       jmp      G_M000_IG59
 
G_M000_IG97:                ;; offset=0x0C8E
       lea      rdi, [rbp-0x150]
       mov      rsi, r15
       mov      rdx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.PyStructuralGuard:PushAmbient(Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyStructuralGuard+AmbientScope]
       mov      r9, gword ptr [rbp-0x150]
       mov      r10, gword ptr [rbp-0x148]
       movzx    r11, byte  ptr [rbp-0x140]
       mov      rax, gword ptr [rbp-0x1A0]
       mov      r8, gword ptr [rbp-0x1B8]
       jmp      G_M000_IG66
 
G_M000_IG98:                ;; offset=0x0CCB
       jmp      SHORT G_M000_IG97
 
G_M000_IG99:                ;; offset=0x0CCD
       mov      edi, 19
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       lea      rdi, bword ptr [rax+0x18]
       mov      rsi, gword ptr [rbp-0x218]
       call     CORINFO_HELP_ASSIGN_REF
       mov      edi, 19
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       lea      rdi, bword ptr [rax+0x20]
       mov      rsi, gword ptr [rbp-0x220]
       call     CORINFO_HELP_ASSIGN_REF
       jmp      G_M000_IG58
 
G_M000_IG100:                ;; offset=0x0D08
       mov      rbx, gword ptr [rbp-0x198]
       mov      edi, dword ptr [rbx+0x30]
       mov      rsi, gword ptr [rbx+0x10]
       mov      rdx, r14
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.CallErrors:MissingArgument(int,System.String,System.String,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.LythonRuntimeException]
       mov      rdi, rax
       call     CORINFO_HELP_THROW
       int3     
 
G_M000_IG101:                ;; offset=0x0D2C
       mov      gword ptr [rbp+0x10], rcx
       mov      rdi, 0x72AC1E674838
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       mov      r14d, dword ptr [r14+0x28]
       lea      rdi, bword ptr [r13+0x08]
       mov      rsi, gword ptr [rbp-0xF8]
       call     CORINFO_HELP_ASSIGN_REF
       cmp      gword ptr [r13+0x08], 0
       je       SHORT G_M000_IG102
       mov      rdi, gword ptr [r13+0x08]
       cmp      dword ptr [rdi+0x28], 0
       jne      G_M000_IG104
 
G_M000_IG102:                ;; offset=0x0D6B
       cmp      r14d, dword ptr [rbp-0x188]
       jae      G_M000_IG111
       lea      rdi, bword ptr [rbp-0xA8]
       mov      eax, r14d
       lea      r12, bword ptr [rdi+8*rax]
       mov      rdi, 0x72A43D803620
       mov      rsi, gword ptr [rdi]
       test     rsi, rsi
       jne      SHORT G_M000_IG103
       mov      rdi, 0x72AC1E61C5D0
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x1A8], rax
       mov      rdi, 0x72A43D8035F8
       mov      rsi, gword ptr [rdi]
       mov      rdi, gword ptr [rbp-0x1A8]
       mov      rdx, 0x72AC1E60BA50
       call     [System.Delegate:CtorClosed(System.Object,nint):this]
       mov      rdi, 0x72A43D803620
       mov      rsi, gword ptr [rbp-0x1A8]
       call     CORINFO_HELP_ASSIGN_REF
       mov      rsi, gword ptr [rbp-0x1A8]
 
G_M000_IG103:                ;; offset=0x0DEF
       mov      rcx, gword ptr [rbp+0x10]
       mov      rdx, r15
       xor      edi, edi
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTuple(int,System.Func`2[int,System.Object],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      rsi, rax
       mov      rdi, r12
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       jmp      SHORT G_M000_IG105
 
G_M000_IG104:                ;; offset=0x0E0B
       mov      r12, gword ptr [r13+0x08]
       mov      rdi, 0x72AC1E61C5D0
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rbp-0x1B0], rax
       mov      r12d, dword ptr [r12+0x28]
       mov      rdi, rax
       mov      rsi, r13
       mov      rdx, 0x72AC1E60BA68
       call     [System.Delegate:CtorClosed(System.Object,nint):this]
       mov      edi, r12d
       mov      rsi, gword ptr [rbp-0x1B0]
       mov      rdx, r15
       mov      rcx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.LythonRuntime:CreateTuple(int,System.Func`2[int,System.Object],Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.PyTuple]
       mov      r13d, dword ptr [rbp-0x188]
       cmp      r14d, r13d
       jae      G_M000_IG111
       lea      rdi, bword ptr [rbp-0xA8]
       mov      esi, r14d
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, rax
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
 
G_M000_IG105:                ;; offset=0x0E7D
       lea      rdi, [rbp-0xC0]
       mov      esi, r14d
       mov      edx, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
       mov      rcx, gword ptr [rbp+0x10]
       mov      r9d, dword ptr [rbp-0x188]
       mov      r10, gword ptr [rbp-0x198]
       jmp      G_M000_IG68
 
G_M000_IG106:                ;; offset=0x0EA9
       mov      gword ptr [rbp+0x10], rcx
       mov      r14, gword ptr [r15+0xA0]
       mov      rdi, 0x72AC1E5FBAE0
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       mov      rdx, gword ptr [r14+0x88]
       mov      rdi, r13
       mov      rcx, gword ptr [rbp+0x10]
       xor      esi, esi
       xor      r8d, r8d
       call     [Lokad.Lython.Runtime.PyDict:.ctor(int,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan,bool):this]
       cmp      gword ptr [rbp-0x100], 0
       je       SHORT G_M000_IG109
       lea      rsi, [rbp-0x138]
       mov      rdi, gword ptr [rbp-0x100]
       cmp      dword ptr [rdi], edi
       call     [System.Collections.Generic.Dictionary`2[System.__Canon,System.__Canon]:GetEnumerator():System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:this]
       jmp      SHORT G_M000_IG108
 
G_M000_IG107:                ;; offset=0x0F01
       mov      rdi, gword ptr [rbp-0x120]
       mov      r14, gword ptr [rbp-0x118]
       mov      rsi, gword ptr [r15+0xA0]
       mov      rsi, gword ptr [rsi+0x88]
       mov      rdx, gword ptr [rbp+0x10]
       call     [Lokad.Lython.Runtime.Text.PyString:FromString(System.String,Lokad.Lython.Runtime.MemoryGovernor,Lokad.Lython.LythonSourceSpan):Lokad.Lython.Runtime.Text.PyString]
       mov      rsi, rax
       mov      rdi, r13
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.PyDict:SetItem(System.Object,System.Object):this]
 
G_M000_IG108:                ;; offset=0x0F36
       lea      rdi, [rbp-0x138]
       mov      rsi, 0x72AC1E5F5850
       call     [System.Collections.Generic.Dictionary`2+Enumerator[System.__Canon,System.__Canon]:MoveNext():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG107
 
G_M000_IG109:                ;; offset=0x0F51
       mov      r15, gword ptr [rbp-0x198]
       mov      rdi, gword ptr [r15+0x08]
       mov      r15d, dword ptr [rdi+0x2C]
       cmp      r15d, dword ptr [rbp-0x188]
       jae      SHORT G_M000_IG111
       lea      rdi, bword ptr [rbp-0xA8]
       mov      esi, r15d
       lea      rdi, bword ptr [rdi+8*rsi]
       mov      rsi, r13
       call     CORINFO_HELP_CHECKED_ASSIGN_REF
       lea      rdi, [rbp-0xC0]
       mov      esi, r15d
       mov      edx, 1
       call     [Lokad.Lython.Runtime.ArgumentPresence:set_Item(int,bool):this]
       mov      rcx, gword ptr [rbp+0x10]
       jmp      G_M000_IG69
 
G_M000_IG110:                ;; offset=0x0F9D
       call     CORINFO_HELP_OVERFLOW
       int3     
 
G_M000_IG111:                ;; offset=0x0FA3
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
G_M000_IG112:                ;; offset=0x0FA9
       sub      rsp, 104
 
G_M000_IG113:                ;; offset=0x0FAD
       cmp      byte  ptr [rbp-0x18C], 0
       je       SHORT G_M000_IG115
 
G_M000_IG114:                ;; offset=0x0FB6
       mov      edi, 19
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       lea      rdi, bword ptr [rax+0x18]
       mov      rsi, gword ptr [rbp-0x218]
       call     CORINFO_HELP_ASSIGN_REF
       mov      edi, 19
       call     [CORINFO_HELP_GETDYNAMIC_GCTHREADSTATIC_BASE_NOCTOR_OPTIMIZED]
       lea      rdi, bword ptr [rax+0x20]
       mov      rsi, gword ptr [rbp-0x220]
       call     CORINFO_HELP_ASSIGN_REF
 
G_M000_IG115:                ;; offset=0x0FEC
       nop      
 
G_M000_IG116:                ;; offset=0x0FED
       add      rsp, 104
       ret      
 
; Total bytes of code 4082

