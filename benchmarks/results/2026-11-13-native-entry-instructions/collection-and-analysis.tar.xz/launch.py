from pathlib import Path
import ast,base64,datetime,json,subprocess
r=Path(__file__).parent;config=json.loads((r/'config.json').read_text(encoding='utf-8'))
code=r'''from pathlib import Path
import ast,fcntl,hashlib,io,json,os,shutil,subprocess,sys,tarfile
config=CONFIG
base=Path('/home/lokad/lython-bench-checks').resolve();root=Path(config['root']);source=Path(config['sourceRoot'])
assert root.parent==base and source.parent==base and not root.exists()
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not(source/'guest-fixtures').exists()
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True).returncode==1
 assert digest(source/'candidate/Lokad.Lython.dll')==config['identity']['coreSHA256']['candidate']
 for name,sha in config['identity']['auxiliaryFiles'].items():assert digest(source/'candidate'/name)==sha
 free=shutil.disk_usage(base).free
 retired=[]
 for proof in config['retire']:
  old=base/proof['path'];st=old.lstat()
  assert old.resolve(strict=True)==old and old.is_relative_to(base)and old.is_file()and not old.is_symlink()and st.st_uid==os.getuid()and st.st_nlink==1 and st.st_size==proof['bytes']and digest(old)==proof['sha256']
  retired.append((old,st.st_blocks*512))
 assert free+sum(size for _,size in retired)>254*1024*1024+config['unpackedBytes']
 for old,_ in retired:old.unlink()
 free=shutil.disk_usage(base).free
 assert free>252*1024*1024+config['unpackedBytes']+2*1024*1024,(free,config['unpackedBytes'])
 payload=sys.stdin.buffer.read(config['payloadBytes']+1);assert len(payload)==config['payloadBytes']and hashlib.sha256(payload).hexdigest()==config['payloadSHA256']
 root.mkdir()
 with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz')as a:a.extractall(root,filter='data')
 shutil.copytree(source/'candidate',root/'candidate',copy_function=os.link)
 assert digest(root/'catalog.json')==config['identity']['catalogSHA256']
 for name in ['collect.py','ops-profile.py']:ast.parse((root/name).read_text())
 subprocess.run(['/bin/sh','-n',str(root/'run.sh')],check=True)
 assert shutil.disk_usage(base).free>254*1024*1024
 fixture=root/'guest-fixtures';fixture.mkdir()
 subprocess.run(['sudo','-n','mount','-t','tmpfs','-o','size=128m,mode=0700,uid=lokad,gid=lokad','lython-b695-fixtures',str(fixture)],check=True)
 (root/'space-preflight.json').write_text(json.dumps(dict(freshIdleLease=True,beforeFreeBytes=free,afterStagingFreeBytes=shutil.disk_usage(base).free,osAndEvidenceFloorMiB=252,additionalStagingHeadroomMiB=2,noNewImageUpload=True),indent=2),encoding='utf-8')
try:subprocess.run(['sudo','-n','systemd-run','--unit='+config['unit'],'--property=User=lokad','--property=WorkingDirectory='+str(root),'--property=RuntimeMaxSec=120','--property=TimeoutStopSec=30','--property=KillMode=control-group','/bin/sh',str(root/'run.sh')],check=True)
except BaseException:
 subprocess.run(['sudo','-n','umount',str(fixture)],check=True);fixture.rmdir();raise
print(subprocess.check_output(['systemctl','show',config['unit']+'.service','--property=ActiveState,MainPID,RuntimeMaxUSec'],text=True))
'''.replace('CONFIG',repr(config))
ast.parse(code);(r/'launch-command.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
command="python3 -c 'import base64;exec(base64.b64decode(\""+base64.b64encode(code.encode()).decode()+"\"))'"
done=subprocess.run(ssh+[command],input=(r/'payload.tgz').read_bytes(),capture_output=True)
(r/'launch.log').write_bytes(done.stdout+done.stderr);print((done.stdout+done.stderr).decode(),flush=True);assert done.returncode==0
now=datetime.datetime.now(datetime.timezone.utc)
(r/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=45)).isoformat(),ownerSeconds=120),indent=2)+'\n',encoding='utf-8',newline='\n')
