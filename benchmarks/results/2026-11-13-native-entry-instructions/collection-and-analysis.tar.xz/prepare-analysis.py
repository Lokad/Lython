from pathlib import Path
import ast
r = Path(__file__).parent
s = (r.parent / 'post-loan-profile-r325/analyze-search.py').read_text(encoding='utf-8')
s = s.replace('Committed557d18d4/frozen9d157bb2', 'Committede698656c/frozen660a0338').replace('3s capture', '5s capture')
s = s.replace('samples=[];current=None', 'samples=[];current=None;leafIps=[]')
s = s.replace("    if current is not None and frame:current.append(symbol(int(frame[1],16),frame[2]))", "    if current is not None and frame:\n        if not current:leafIps.append(int(frame[1],16))\n        current.append(symbol(int(frame[1],16),frame[2]))")
ast.parse(s)
(r / 'analyze-search.py').write_text(s, encoding='utf-8', newline='\n')
