from pathlib import Path
import hashlib, json, subprocess
r = Path(__file__).parent
specs = [('benchmarks/results/2026-11-13-final-slot-binding/b694-observations.tgz', 'final-slot-binding-b694-20261113/observations.tgz'), ('benchmarks/results/2026-11-13-word-buffer-loan/b690/observations.tgz', 'word-buffer-loan-b690-20261113/observations.tgz'), ('benchmarks/results/2026-11-13-post-loan-cpu-attribution/observations.tgz', 'post-loan-profile-b692-20261113/observations.tgz')]
proofs = []
for canonical, relative in specs:
    p = Path(canonical)
    if not p.exists(): continue
    assert subprocess.check_output(['git', 'show', 'HEAD:' + canonical]) == p.read_bytes()
    proofs.append(dict(path=relative, canonical=canonical, sha256=hashlib.sha256(p.read_bytes()).hexdigest(), bytes=p.stat().st_size))
code = '''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess
proofs=PROOFS
base=Path('/home/lokad/lython-bench-checks').resolve()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1
 rows=[]
 for proof in proofs:
  p=base/proof['path'];st=p.lstat()
  assert p.resolve(strict=True)==p and p.is_relative_to(base)and p.is_file()and not p.is_symlink()and st.st_uid==os.getuid()and st.st_nlink==1 and st.st_size==proof['bytes']and hashlib.sha256(p.read_bytes()).hexdigest()==proof['sha256']
  rows.append(dict(**proof,allocatedBytes=st.st_blocks*512))
 print(json.dumps(dict(readOnly=True,freshIdleLease=True,freeBytes=shutil.disk_usage(base).free,provedArchivedWorkingCopies=rows)))
'''.replace('PROOFS', repr(proofs))
ssh = ['C:/Windows/System32/OpenSSH/ssh.exe', '-i', 'C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15', 'lokad@20.166.121.73']
done = subprocess.run(ssh + ['python3 -'], input=code, text=True, encoding='utf-8', capture_output=True)
assert done.returncode == 0, done.stderr
(r / 'space-inspection.json').write_text(done.stdout, encoding='utf-8', newline='\n')
print(done.stdout, flush=True)
