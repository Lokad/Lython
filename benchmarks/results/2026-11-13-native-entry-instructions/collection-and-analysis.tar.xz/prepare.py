from pathlib import Path
import ast, hashlib, json, subprocess, tarfile
r = Path(__file__).parent
prior = r.parent / 'post-loan-profile-r325'
oldroot = '/home/lokad/lython-bench-checks/post-loan-profile-b692-20261113'
root = '/home/lokad/lython-bench-checks/native-entry-ip-b695-20261113'
source = '/home/lokad/lython-bench-checks/final-slot-binding-b694-20261113'
catalog = json.loads((prior / 'catalog.json').read_text(encoding='utf-8'))
catalog['cases'] = [c for c in catalog['cases'] if c['id'] == 'scripts.file-search.large']
assert len(catalog['cases']) == 1
(r / 'catalog.json').write_text(json.dumps(catalog, separators=(',', ':'), ensure_ascii=False) + '\n', encoding='utf-8', newline='\n')
old = json.loads((r.parent / 'final-slot-binding-r326/b694/identity.json').read_text(encoding='utf-8'))
identity = dict(coreSHA256={'candidate': old['coreSHA256']['candidate']}, auxiliaryFiles=old['candidateAuxiliaryFiles'], catalogSHA256=hashlib.sha256((r / 'catalog.json').read_bytes()).hexdigest(), sourceRevision='Committede698656c/frozen660a0338; R327 native-entry instruction attribution', diagnosticOnly=True, scriptCaptureWallSeconds=5, warmGuestSeconds=8, compilationExcluded=True, allocationStacksNotMeasured=True, disassemblyCollectedInTheSameProcessAsSamples=True)
(r / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8', newline='\n')
description = identity['sourceRevision']
for name in ['ops-profile.py', 'collect.py', 'run.sh', 'retrieve.py']:
    s = (prior / name).read_text(encoding='utf-8').replace(oldroot, root)
    s = s.replace('Committed557d18d4/frozen9d157bb2 after word-buffer loan consolidation; corrected full delivery independently running', description)
    if name == 'ops-profile.py':
        s = s.replace("[('captured', 'scripts.text-summary-helpers.nonlocal-counter.large', 'warm'), ('search', 'scripts.file-search.large', 'warm')]", "[('search', 'scripts.file-search.large', 'warm')]")
        s = s.replace('deadline=time.monotonic()+3', 'deadline=time.monotonic()+5')
        s = s.replace('        folder.mkdir()\n', "        folder.mkdir()\n        env['DOTNET_JitDisasm']='*StartNativeCall*'\n        env['DOTNET_JitStdOutFile']=str(folder/'native-entry.asm')\n")
        s = s.replace('["DOTNET_PerfMapEnabled"]}', '["DOTNET_PerfMapEnabled", "DOTNET_JitDisasm", "DOTNET_JitStdOutFile"]}')
    if name == 'collect.py': s = s.replace("for name in ['captured','search']", "for name in ['search']")
    if name.endswith('.py'): ast.parse(s)
    (r / name).write_text(s, encoding='utf-8', newline='\n')
canonical = 'benchmarks/results/2026-11-13-final-slot-binding/b694-observations.tgz'
p = Path(canonical)
assert subprocess.check_output(['git', 'show', 'HEAD:' + canonical]) == p.read_bytes()
retire = [row for row in json.loads((r / 'space-inspection.json').read_text(encoding='utf-8'))['provedArchivedWorkingCopies'] if row['path'].startswith(('final-slot-binding-b694-', 'word-buffer-loan-b690-'))]
assert len(retire) == 2
for row in retire:
    data = Path(row['canonical']).read_bytes()
    assert subprocess.check_output(['git', 'show', 'HEAD:' + row['canonical']]) == data and hashlib.sha256(data).hexdigest() == row['sha256'] and len(data) == row['bytes']
with tarfile.open(r / 'payload.tgz', 'w:gz') as t:
    for name in ['catalog.json', 'identity.json', 'ops-profile.py', 'collect.py', 'run.sh']: t.add(r / name, arcname=name)
with tarfile.open(r / 'payload.tgz') as t: unpacked = sum(m.size for m in t.getmembers())
config = dict(root=root, sourceRoot=source, unit='lython-b695-native-entry-ip-20261113', identity=identity, retire=retire, payloadBytes=(r / 'payload.tgz').stat().st_size, payloadSHA256=hashlib.sha256((r / 'payload.tgz').read_bytes()).hexdigest(), unpackedBytes=unpacked)
(r / 'config.json').write_text(json.dumps(config, indent=2) + '\n', encoding='utf-8', newline='\n')
s = (prior / 'launch.py').read_text(encoding='utf-8').replace('lython-b692-fixtures', 'lython-b695-fixtures')
s = s.replace(' free=shutil.disk_usage(base).free\n', ''' free=shutil.disk_usage(base).free
 retired=[]
 for proof in config['retire']:
  old=base/proof['path'];st=old.lstat()
  assert old.resolve(strict=True)==old and old.is_relative_to(base)and old.is_file()and not old.is_symlink()and st.st_uid==os.getuid()and st.st_nlink==1 and st.st_size==proof['bytes']and digest(old)==proof['sha256']
  retired.append((old,st.st_blocks*512))
 assert free+sum(size for _,size in retired)>254*1024*1024+config['unpackedBytes']
 for old,_ in retired:old.unlink()
 free=shutil.disk_usage(base).free
''')
ast.parse(s)
(r / 'launch.py').write_text(s, encoding='utf-8', newline='\n')
p = Path('PLAN.md'); s = p.read_text(encoding='utf-8')
s = s.replace('**R327 next selection gate:**', '**R327 selection gate active:**')
s = s.replace('that choice. No new arena, controller or blanket parameter representation.', '''that choice. B695 uses current frozen660, the same complete search script,
   one5sCPU capture after8guest-second warmup, and same-process native-entry JIT
   disassembly to resolve sampled offsets. Existing120s owner/image/golden/quiet/
   join/archive gates remain. No elapsed/allocation comparison. Stop after this
   instruction-level selection; no new arena/controller or blanket representation.''')
p.write_text(s, encoding='utf-8', newline='\n')
print('Prepared one5s same-process CPU/JIT source gate on frozen660; no new worker image.', flush=True)
