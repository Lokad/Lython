using System.Numerics;
using System.Security.Cryptography;
using System.Text.Json;
using Lokad.Lython;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime;

var rows = new List<object>();
foreach (var op in new[] { BinaryOperatorSyntax.Add, BinaryOperatorSyntax.Subtract, BinaryOperatorSyntax.Multiply, BinaryOperatorSyntax.FloorDivide, BinaryOperatorSyntax.Modulo })
{
    var budget = new LythonMemoryBudget(16 * 1024 * 1024);
    using (var owner = budget.CreateScope())
    {
        var gate = new Gate(owner);
        var context = new LythonRuntime.ExecutionContext(new Host(), new LythonRunOptions { MemoryBudget = gate });
        var span = new LythonSourceSpan(0, 1, 1, 1);
        var left = (BigInteger.One << 524288) + 19;
        var right = (BigInteger.One << 256) + 3;
        object lhs = LythonRuntime.OwnFreshInteger(left, context.MemoryGovernor, span);
        object rhs = LythonRuntime.OwnFreshInteger(right, context.MemoryGovernor, span);
        gate.Before = GC.GetAllocatedBytesForCurrentThread(); gate.Armed = true;
        string? failure = null;
        try { _ = LythonRuntime.EvaluateBinaryOperator(op, lhs, rhs, context, span); }
        catch (LythonRuntimeException error) { failure = error.Attribution?.Reason.ToString(); }
        rows.Add(new { operation = op.ToString(), failure, allocatedBeforeRefusal = gate.AllocatedAtRefusal, requestedBytes = gate.Requested, leftBits = left.GetBitLength(), rightBits = right.GetBitLength(), inputsUnchanged = (BigInteger)lhs == left && (BigInteger)rhs == right });
        gate.Armed = false;
        context.State.CloseResources();
    }
    if (budget.ReservedBytes != 0) throw new InvalidOperationException("Scope cleanup did not return funding.");
}
Console.WriteLine(JsonSerializer.Serialize(new { coreSHA256 = Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))), perThreadAllocationDiagnostic = true, noForcedGc = true, rows }));

sealed class Gate(ILythonMemoryBudget parent) : ILythonMemoryBudget
{
    internal bool Armed;
    internal long Before;
    internal long? AllocatedAtRefusal;
    internal long? Requested;
    private bool Refuse(long bytes)
    {
        if (!Armed) return false;
        AllocatedAtRefusal ??= GC.GetAllocatedBytesForCurrentThread() - Before;
        Requested ??= bytes;
        return true;
    }
    public ILythonMemoryScope CreateScope() => parent.CreateScope();
    public bool TryReserve(long bytes, [System.Diagnostics.CodeAnalysis.NotNullWhen(true)] out ILythonMemoryReservation? reservation)
    {
        if (bytes > 0 && Refuse(bytes)) { reservation = null; return false; }
        if (!parent.TryReserve(bytes, out var inner)) { reservation = null; return false; }
        reservation = new Reservation(this, inner!); return true;
    }
    private sealed class Reservation(Gate gate, ILythonMemoryReservation inner) : ILythonMemoryReservation
    {
        public long Bytes => inner.Bytes;
        public bool TryResize(long bytes) => bytes > inner.Bytes && gate.Refuse(bytes - inner.Bytes) ? false : inner.TryResize(bytes);
        public void Dispose() => inner.Dispose();
    }
}
sealed class Host : ILythonHost
{
    public string Cwd => "/";
    public DateTimeOffset LocalNow => DateTimeOffset.UnixEpoch;
    public DateTimeOffset UtcNow => DateTimeOffset.UnixEpoch;
    public ValueTask<bool> ExistsAsync(LythonPathRequest p, CancellationToken t) => new(false);
    public ValueTask<IReadOnlyList<string>> ListDirAsync(LythonPathRequest p, CancellationToken t) => new(Array.Empty<string>());
    public ValueTask MkDirAsync(LythonPathRequest p, CancellationToken t) => throw new LythonHostCapabilityUnavailableException("mkdir");
    public ValueTask RemoveAsync(LythonPathRequest p, CancellationToken t) => throw new LythonHostCapabilityUnavailableException("remove");
    public ValueTask CopyAsync(LythonPathRequest p, LythonPathRequest q, CancellationToken t) => throw new LythonHostCapabilityUnavailableException("copy");
    public ValueTask MoveAsync(LythonPathRequest p, LythonPathRequest q, CancellationToken t) => throw new LythonHostCapabilityUnavailableException("move");
    public ValueTask<LythonPathStat> StatAsync(LythonPathRequest p, CancellationToken t) => throw new LythonHostCapabilityUnavailableException("stat");
}
