from pathlib import Path
import json,os,subprocess
r=Path(__file__).parent;sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';'+env['PATH']
with(r/'build.log').open('w',encoding='utf-8')as log:done=subprocess.run([str(sdk/'dotnet.exe'),'build',str(r/'probe/probe.csproj'),'-c','Release','--disable-build-servers','-m:1'],env=env,stdout=log,stderr=subprocess.STDOUT)
assert done.returncode==0,(r/'build.log').read_text(encoding='utf-8')
with(r/'before.json').open('w',encoding='utf-8')as log, (r/'stderr.log').open('w',encoding='utf-8')as error:done=subprocess.run([str(sdk/'dotnet.exe'),str(r/'probe/bin/Release/net11.0/Lokad.Lython.WhiteBox.Tests.dll')],env=env,stdout=log,stderr=error)
assert done.returncode==0,(r/'stderr.log').read_text(encoding='utf-8')
d=json.loads((r/'before.json').read_text(encoding='utf-8'));assert d['coreSHA256'].lower()=='2e74ef4fd844a4940f4e7800d0d801e6353babf124f35a720ebc2aa025b0c1ae'
print(json.dumps(d,indent=2),flush=True)
