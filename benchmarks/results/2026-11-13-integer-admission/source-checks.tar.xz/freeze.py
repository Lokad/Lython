from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).parent;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=r.parent/'composed-native-r303';reference=json.loads((old/'stack-continuation/corrected-identity.json').read_text(encoding='utf-8'))
names=subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True).splitlines()+['src/Lokad.Lython/Runtime/LythonRuntime.IntegerBinary.cs'];assert len(names)==len(set(names))==572
sources={p:sha(p) for p in names};changed=[p for p in names if sources[p]!=reference['sources'].get(p)]
assert len(changed)==7,changed
for role in ['reference','candidate']:
 shutil.copytree(old/'reference',r/role,copy_function=__import__('os').link)
 (r/role/'Lokad.Lython.dll').unlink()
 shutil.copyfile(r/'reference-core.dll'if role=='reference'else Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll'),r/role/'Lokad.Lython.dll')
shutil.copy2(r/'candidate/Lokad.Lython.dll',r/'candidate-core.dll')
identity=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),description='R305 pre-admitted integer arithmetic; exact dispatch and shared accumulator kernel',sources=sources,changed=changed,coreSHA256=sha(r/'candidate-core.dll'),referenceSHA256=sha(r/'reference-core.dll'))
(r/'candidate-identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as archive:
 for p in sources:archive.add(p,arcname=p)
shutil.copy2(old/'catalog.json',r/'catalog.json')
print(identity['coreSHA256'],changed,flush=True)
