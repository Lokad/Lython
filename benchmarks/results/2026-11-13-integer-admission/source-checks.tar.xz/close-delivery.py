from pathlib import Path
import subprocess
r=Path(__file__).parent
(r/'build.log').rename(r/'build-bad-reference.log')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')
s=s.replace('| Current delivery candidate |', '| Fully qualified current runtime |').replace('Full delivery [43378817838](https://github.com/Lokad/Lython/actions/runs/43378817838) is running.', 'Full delivery [43378817838](https://github.com/Lokad/Lython/actions/runs/43378817838) is GREEN: both platforms, actual.NET11/10, original stress and installed Release consumers. Terminal logs,16step counts and571source proof are cached in the correction delivery directory.')
start=s.index('   Focused66cases/actualtarget');end=s.index('\n2. **',start)
s=s[:start]+'''   CLOSED: focused66cases/actualtarget and full delivery are GREEN. The source
   proof matches all571frozen production inputs; generated metadata does not prove
   CI byte identity. Reuse cached logs; no further unchanged stack qualification or
   separate stack redesign is required.
'''+s[end:]
s=s.replace('Prepare B660 for corrected', 'B660 launched06:53:23UTC for corrected').replace('63389c9d/2e74ef4f; launch only after source-matched GREEN.', '63389c9d/2e74ef4f after source-matched GREEN; owned360sunit, first observation240s.')
p.write_text(s,encoding='utf-8')
subprocess.run(['git','add','benchmarks/results/2026-11-13-native-call-stack-handoff/delivery'],check=True)
subprocess.run(['git','commit','-m','Record qualified managed call handoff delivery [skip ci]'],check=True)
