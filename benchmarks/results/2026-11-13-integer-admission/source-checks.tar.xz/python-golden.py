from pathlib import Path
import subprocess
r=Path(__file__).parent;s=Path('tests/Lokad.Lython.PublicApi.Tests/IntegerBinarySemanticsTests.cs').read_text(encoding='utf-8');s=s.split('const string source = """\n',1)[1].split('            """;',1)[0];s='\n'.join(line[12:] for line in s.splitlines()).replace('return big*3,big*3','print(big*3,big*3)')
(r/'semantics.py').write_text(s+'\n',encoding='utf-8')
done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8',str(r/'semantics.py')],capture_output=True,text=True,encoding='utf-8')
(r/'python-golden.log').write_text(done.stdout+done.stderr,encoding='utf-8');assert done.returncode==0,done.stderr
assert done.stdout=='3802951800684688204490109616179 3802951800684688204490109616179\n';print(done.stdout)
