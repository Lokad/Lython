from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent;old=r.parent/'composed-native-r303/b657';out=r/'b661';out.mkdir()
source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in source['sources'].items())
root='/home/lokad/lython-bench-checks/integer-b661-20261113';oldroot='/home/lokad/lython-bench-checks/composed-native-b657-20261113'
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision='Qualified63389c9d/2e74ef4f versus uncommitted R305 integer kernel; exact frozen inputs',coreSHA256={k:source['referenceSHA256']if k.startswith('reference')else source['coreSHA256'] for k in ['reference','candidate','reference-control','candidate-control']},catalogSHA256=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest(),sourceIdentitySHA256=hashlib.sha256((r/'candidate-identity.json').read_bytes()).hexdigest(),productionSourceArchiveSHA256=hashlib.sha256((r/'candidate-sources.tar.xz').read_bytes()).hexdigest())
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
jobs=[['scripts.csv-invoice.large','warm'],['scripts.csv-invoice.large','compile-run'],['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.json-summary-helpers.large','warm']]
code=(old/'collect.py').read_text(encoding='utf-8').replace(oldroot,root)
start=code.index('jobs=');end=code.index('\nenv =',start);code=code[:start]+'jobs='+repr(jobs)+'\nassert len(jobs)==4 and all(case in cases for case,lane in jobs)\n'+code[end:]
code=code.replace('Composed native calls: complete invoice warm/fresh/compile, captured/native-search/report controls; fixed source-pair, no external ratio','Pre-admitted integer kernel; invoice warm/fresh, captured and JSON controls; exact source-pair, no external ratio').replace('if job_index >= 3:','if job_index >= 2:').replace('< 300,','< 240,')
ast.parse(code);(out/'collect.py').write_text(code,encoding='utf-8',newline='\n')
code=(old/'archive-owned.py').read_text(encoding='utf-8').replace(oldroot,root).replace("len(raw['jobs'])==6","len(raw['jobs'])==4").replace('jobs=6','jobs=4');ast.parse(code);(out/'archive-owned.py').write_text(code,encoding='utf-8',newline='\n')
(out/'run.sh').write_text('set -eu\nroot='+root+'\ntrap \'result=$?; printf "%s\\n" "$result" > "$root/exit-code.txt"\' EXIT\npython3 "$root/collect.py"\n',encoding='utf-8',newline='\n')
files={n:out/n for n in ['identity.json','collect.py','archive-owned.py','run.sh']};files.update({'current-core.dll':r/'candidate-core.dll','source-identity.json':r/'candidate-identity.json','representative.json':r/'catalog.json','cpython-worker.py':old.parent/'b660/retrieved/cpython-worker.py'})
with tarfile.open(out/'payload.tgz','w:gz')as a:
 for name,p in files.items():a.add(p,arcname=name)
config=dict(root=root,unit='lython-b661-integer-20261113',sourceRoot='/home/lokad/lython-bench-checks/invoice-external-b660-20261113',identity=identity,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum(p.stat().st_size for p in files.values()))
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
code=(old/'launch.py').read_text(encoding='utf-8').replace('b657','b661').replace('B657','B661').replace('RuntimeMaxSec=360','RuntimeMaxSec=300').replace('seconds=240','seconds=180').replace('ownerSeconds=360','ownerSeconds=300').replace('observationSeconds=240','observationSeconds=180');ast.parse(code);(out/'launch.py').write_text(code,encoding='utf-8')
code=(old/'retrieve.py').read_text(encoding='utf-8').replace('composed-native-b657-20261113','integer-b661-20261113').replace('lython-b657-composed-native-20261113','lython-b661-integer-20261113').replace("status['receipt']['jobs']==6","status['receipt']['jobs']==4").replace("status['receipt']['elapsedSeconds']<360","status['receipt']['elapsedSeconds']<300").replace('B657 six-job','B661 four-job');ast.parse(code);(out/'retrieve.py').write_text(code,encoding='utf-8')
code=(old/'summarize.py').read_text(encoding='utf-8');ast.parse(code);(out/'summarize.py').write_text(code,encoding='utf-8')
print('B661 prepared four bounded jobs; fresh idle/storage lease required at launch.',flush=True)
