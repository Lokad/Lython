from pathlib import Path
import os,subprocess,sys
r=Path(__file__).parent;sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
label=sys.argv[1];filt=sys.argv[2]if len(sys.argv)>2 else'FullyQualifiedName~IntegerBinaryAdmissionTests'
jobs=[('build',[str(sdk/'dotnet.exe'),'build','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f','net11.0','--disable-build-servers','-m:1']),('test',[str(sdk/'dotnet.exe'),'test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f','net11.0','--no-build','--disable-build-servers','--filter','Category!=Stress&('+filt+')','--logger','console;verbosity=normal'])]
for name,args in jobs:
 p=r/(label+'-'+name+'.log');assert not p.exists()
 with p.open('w',encoding='utf-8')as log:done=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
 text=p.read_text(encoding='utf-8');print(name,done.returncode,text[-4200:],flush=True)
 if done.returncode or 'No test matches'in text:raise SystemExit(done.returncode or 1)
