from pathlib import Path
import os,subprocess
r=Path(__file__).parent;sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';C:/Python313;'+env['PATH']
internal='IntegerBinaryAdmissionTests|IntegerAdditionAdmissionTests|CounterIntegerAdmissionTests|PyNumberPrimitiveTests|ProductAdmissionTests|ExactIntegerUnaryAdmissionTests'
public='IntegerBinarySemanticsTests|ComposedHelperTests|Numeric|Arithmetic|OperatorProtocol|Cancellation'
for kind in ['public','internal']:
 project='tests/'+('Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj'if kind=='public'else'Lokad.Lython.Tests/Lokad.Lython.Tests.csproj')
 for phase in ['build','test']:
  p=r/('focused-'+kind+'-'+phase+'.log');assert not p.exists()
  args=[str(sdk/'dotnet.exe'),phase,project,'-c','Release','-f','net11.0','--disable-build-servers']
  if phase=='build':args+=['-m:1']
  else:args+=['--no-build','--filter','Category!=Stress&('+'|'.join('FullyQualifiedName~'+k for k in (public if kind=='public'else internal).split('|'))+')','--logger','console;verbosity=normal']
  with p.open('w',encoding='utf-8')as log:done=subprocess.run(args,env=env,stdout=log,stderr=subprocess.STDOUT)
  text=p.read_text(encoding='utf-8');print(p.name,done.returncode,text[-4500:],flush=True)
  if done.returncode or 'No test matches'in text:raise SystemExit(done.returncode or 1)
