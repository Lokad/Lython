from pathlib import Path
import json,os,subprocess
r=Path(__file__).parent;sdk=Path('C:/Users/JoannesVermorel/.dotnet11');env=os.environ.copy();env['DOTNET_ROOT']=str(sdk);env['PATH']=str(sdk)+';'+env['PATH']
with(r/'after-build.log').open('w',encoding='utf-8')as log:done=subprocess.run([str(sdk/'dotnet.exe'),'build',str(r/'probe/probe.csproj'),'-c','Release','--no-restore','--disable-build-servers','-m:1'],env=env,stdout=log,stderr=subprocess.STDOUT)
assert done.returncode==0,(r/'after-build.log').read_text(encoding='utf-8')
with(r/'after.json').open('w',encoding='utf-8')as log,(r/'after-stderr.log').open('w',encoding='utf-8')as err:done=subprocess.run([str(sdk/'dotnet.exe'),str(r/'probe/bin/Release/net11.0/Lokad.Lython.WhiteBox.Tests.dll')],env=env,stdout=log,stderr=err)
assert done.returncode==0,(r/'after-stderr.log').read_text(encoding='utf-8')
d=json.loads((r/'after.json').read_text(encoding='utf-8'));identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'));assert d['coreSHA256'].lower()==identity['coreSHA256']
assert all(row['failure']=='SharedMemoryAllowance'and row['allocatedBeforeRefusal']<32768 and row['inputsUnchanged']for row in d['rows'])
print(json.dumps(d,indent=2),flush=True)
