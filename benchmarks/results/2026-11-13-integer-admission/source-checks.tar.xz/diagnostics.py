from pathlib import Path
import ast,subprocess,sys
r=Path(__file__).parent;old=r.parent/'composed-native-r303'
code=(old/'diagnostic.py').read_text(encoding='utf-8')
code=code.replace("str(r/'tool/bin/Release/net11.0/complete-jobs.dll')", "str(r.parent/'composed-native-r303/tool/bin/Release/net11.0/complete-jobs.dll')")
ast.parse(code);(r/'diagnostic.py').write_text(code,encoding='utf-8')
code=(old/'summarize.py').read_text(encoding='utf-8');ast.parse(code);(r/'summarize.py').write_text(code,encoding='utf-8')
for phase in ['warm-sync','warm-async']:
 subprocess.run([sys.executable,'-X','utf8',str(r/'diagnostic.py'),phase],check=True)
subprocess.run([sys.executable,'-X','utf8',str(r/'summarize.py')],check=True)
