from pathlib import Path
import json
r=Path(__file__).parent
catalog=json.loads((r/'catalog.json').read_text(encoding='utf-8'))
case=next(c for c in catalog['cases']if c['id']=='scripts.text-summary-helpers.nonlocal-counter.large')
print('Case fields:',list(case));print(case.get('source',case.get('sourceText','Source referenced elsewhere')))
for name in ['warm-sync','warm-async']:
 d=json.loads((r/name/'scripts.text-summary-helpers.nonlocal-counter.large.json').read_text(encoding='utf-8'))
 print(name,'evidence fields:',list(d)if isinstance(d,dict)else type(d).__name__)
