from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).parent;p=Path('PLAN.md');s=p.read_text(encoding='utf-8');at=s.index('3. **Continue substantial')
end=s.index('\n4. **Independent regex',at)
old=s[at:end];(r/'previous-roadmap.md').write_text(old,encoding='utf-8')
s=s[:at]+'''3. **R305: consolidate pre-admitted integer arithmetic (active).** Current633/2e
   source/probe confirms subtract/multiply allocate~64KiB before first refusal,
   floor division/modulo~128KiB; addition refuses after32diagnostic bytes. Inputs
   remain unchanged and cleanup returns baseline. This is a demonstrated admission
   defect, separately from the CPU hypothesis. Modulo currently constructs a full
   quotient, product and difference. B656 also names arithmetic/classification;
   invoice still has a1.45–1.46×warm external gap.

   Migration: one integer kernel for subtract/multiply/floor-divide/modulo, shared
   from exact guest dispatch and bool/ingress numeric fallback. Pre-admit major
   result/workspace overlap, commit the surviving magnitude from that reservation;
   retain the tiny-scalar fast tier. Replace modulo's quotient/product with signed
   remainder correction. Reuse the kernel in math.prod/sumprod and Counter subtraction
   to remove duplicate multiplication preflight and post-allocation ownership.
   Remove displaced generic integer branches/helpers rather than add a parallel
   evaluator. Addition's measured fast path and existing power/shift guards remain.

   Acceptance: exact signed floor/mod and overflow promotion; mixed float/bool,
   reflected/subclass protocols and augmented evaluation order unchanged. Denial
   before major allocation/mutation preserves first structured origin; retained
   input/result aliases funded, reservations refunded, cancellation during admission
   aborts publication and cleanup returns shared allowance. BCL arithmetic itself
   cannot be interrupted mid-operation; do not claim new in-flight support there.
   Conservative scratch can reject earlier; no tiny-threshold contract.

   Development: focused Release numeric/protocol/admission/ownership/cancellation
   tests, regression demonstrated before correction, short exact source-pair invoice
   warm/fresh plus captured/JSON controls on the quiet VM. Compare allocation
   separately from elapsed/widerCPU. Preserve adverse observations; refine/retain/
   withdraw using semantic and complete-script evidence. End this milestone with
   displaced code removed, docs/contract limits current, then batch platform/stress/
   installed consumers at the coherent boundary. No extra external refresh needed.

   Remaining roadmap: source-gate per-record construction/operand transport and
   repeated frontend analysis after R305. Existing bulk CSV/shared keys, final slots,
   live cells, direct UTF8 casing/formatting and JSON windows are already delivered;
   select an actual remaining copy/retained intermediate with representative cost.
   Preserve source identities and existing slower call-arena/control lessons.
'''+s[end:];p.write_text(s,encoding='utf-8')
core=Path('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll');shutil.copy2(core,r/'reference-core.dll')
assert hashlib.sha256(core.read_bytes()).hexdigest()=='2e74ef4fd844a4940f4e7800d0d801e6353babf124f35a720ebc2aa025b0c1ae'
(r/'source-gate.json').write_text(json.dumps(dict(reference='63389c9d/2e74ef4f',cpuHypothesis='Remove repeated generic dispatch and modulo quotient/product intermediates; magnitude unknown',correctnessFinding=json.loads((r/'before.json').read_text(encoding='utf-8'))),indent=2)+'\n',encoding='utf-8')
