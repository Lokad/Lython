from pathlib import Path
import datetime,hashlib,io,json,re,subprocess,tarfile
r=Path(__file__).parent;frozen=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in frozen['sources'].items())
assert not subprocess.check_output(['git','diff','--cached','--name-only'],text=True).strip()
paths=frozen['changed']+['tests/Lokad.Lython.Tests/PyNumberPrimitiveTests.cs','tests/Lokad.Lython.Tests/IntegerBinaryAdmissionTests.cs','tests/Lokad.Lython.PublicApi.Tests/IntegerBinarySemanticsTests.cs','docs/RUNTIME.md','tests/README.md','CHANGELOG.md','benchmarks/EXPERIMENTS.md','benchmarks/results/2026-11-13-integer-admission']
for args in [['add','--',*paths],['diff','--cached','--check'],['commit','-m','Consolidate integer arithmetic with admission before allocation [skip ci]']]:subprocess.run(['git',*args],check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
def normal(data):
 try:return data.decode('utf-8').replace('\r\n','\n').encode('utf-8')
 except UnicodeError:return data
count=0
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive',head,'src/Lokad.Lython'])))as a:
 for m in a.getmembers():
  if m.isfile():assert normal(a.extractfile(m).read())==normal(Path(m.name).read_bytes());count+=1
assert count==len(frozen['sources'])==572
subprocess.run(['git','push','origin','master'],check=True)
done=subprocess.run(['C:/Program Files/GitHub CLI/gh.exe','workflow','run','ci.yml','--ref','master','-f','stress=true'],capture_output=True,text=True,encoding='utf-8');assert done.returncode==0,done.stderr
run=re.search(r'/runs/(\d+)',done.stdout+done.stderr);assert run,done.stdout+done.stderr
candidate=dict(head=head,coreSHA256=frozen['coreSHA256'],productionFiles=count,allFrozenSourcesMatchCommitWithExplicitNewlineNormalization=True,runId=run[1],url='https://github.com/Lokad/Lython/actions/runs/'+run[1],dispatchedUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),fullQualificationPending=True,publicationHeld=True)
(r/'delivery-candidate.json').write_text(json.dumps(candidate,indent=2)+'\n',encoding='utf-8')
(r/'check-ci.py').write_bytes((r.parent/'composed-native-r303/check-ci.py').read_bytes())
print(json.dumps(candidate),flush=True)
