from pathlib import Path
r=Path(__file__).parent
def replace(path,old,new,count=1):
 p=Path(path);s=p.read_text(encoding='utf-8');assert s.count(old)>=count,(path,s.count(old),old);p.write_text(s.replace(old,new,count),encoding='utf-8')
root='src/Lokad.Lython/Runtime/'
(Path(root)/'LythonRuntime.IntegerBinary.cs').write_text((r/'IntegerBinary.cs.txt').read_text(encoding='utf-8'),encoding='utf-8')
replace(root+'LythonRuntime.OperatorDispatch.cs','''        if (TryEvaluateScalarComparison(op, left, right, context, span, out var scalarComparison))''','''        if (op is BinaryOperatorSyntax.Subtract or BinaryOperatorSyntax.Multiply
            or BinaryOperatorSyntax.FloorDivide or BinaryOperatorSyntax.Modulo
            && left is BigInteger exactLeft && right is BigInteger exactRight)
            return EvaluateIntegerBinary(op, exactLeft, exactRight, context, span);

        if (TryEvaluateScalarComparison(op, left, right, context, span, out var scalarComparison))''',2)
p=root+'LythonRuntime.Evaluation.Operators.cs'
for name,operation,float_code in [('Subtract','Subtract','PyNumberOps.ToDoubleChecked(lhs) - PyNumberOps.ToDoubleChecked(rhs)'),('Multiply','Multiply','PyNumberOps.ToDoubleChecked(lhs) * PyNumberOps.ToDoubleChecked(rhs)'),('FloorDivide','FloorDivide','PyNumberOps.FloatDivMod(PyNumberOps.ToDoubleChecked(lhs), PyNumberOps.ToDoubleChecked(rhs)).Quotient'),('Modulo','Modulo','PyNumberOps.FloatDivMod(PyNumberOps.ToDoubleChecked(lhs), PyNumberOps.ToDoubleChecked(rhs)).Remainder')]:
 replace(p,f'return OwnHeapInteger(PyNumberOps.{name}(lhs, rhs), context.MemoryGovernor, span);',f'''return !lhs.IsFloat && !rhs.IsFloat
                ? EvaluateIntegerBinary(BinaryOperatorSyntax.{operation}, lhs.Integer, rhs.Integer, context, span)
                : {float_code};''')
replace(root+'LythonRuntime.Operations.cs','return PyNumberOps.Subtract(lhs, rhs);','''return !lhs.IsFloat && !rhs.IsFloat
            ? EvaluateIntegerBinary(BinaryOperatorSyntax.Subtract, lhs.Integer, rhs.Integer, context, span, governor)
            : PyNumberOps.ToDoubleChecked(lhs) - PyNumberOps.ToDoubleChecked(rhs);''')
p=Path(root+'LythonRuntime.Modules.cs');s=p.read_text(encoding='utf-8');a=s.index('                // Keep the granted capacity alive through computation');b=s.index('\n            }',a)
s=s[:a]+'''                return !left.IsFloat && !right.IsFloat
                    ? EvaluateIntegerBinary(Frontend.BinaryOperatorSyntax.Multiply, left.Integer, right.Integer, context, span)
                    : PyNumberOps.ToDoubleChecked(left) * PyNumberOps.ToDoubleChecked(right);'''+s[b:];p.write_text(s,encoding='utf-8')
p=Path(root+'LythonRuntime.MathModule.cs');s=p.read_text(encoding='utf-8')
old='product = PyNumberOps.Multiply(left, right);';assert s.count(old)==2
s=s.replace(old,'''product = !left.IsFloat && !right.IsFloat
                        ? EvaluateIntegerBinary(Frontend.BinaryOperatorSyntax.Multiply, left.Integer, right.Integer, context, span)
                        : PyNumberOps.ToDoubleChecked(left) * PyNumberOps.ToDoubleChecked(right);''')
s=s.replace('EvaluateAdd(total, OwnHeapInteger(product, context.MemoryGovernor, span), context, span)','EvaluateAdd(total, product, context, span)');p.write_text(s,encoding='utf-8')
p=Path(root+'Numbers/PyNumberOps.cs');s=p.read_text(encoding='utf-8')
a=s.index('    public static object Subtract(');b=s.index('    public static object TrueDivide(',a);s=s[:a]+s[b:]
a=s.index('    public static object FloorDivide(');b=s.index('    // Adapted from CPython',a);s=s[:a]+s[b:]
s=s.replace('private static BigInteger FloorDivideIntegers','internal static BigInteger FloorDivideIntegers')
at=s.index('    internal static BigInteger FloorDivideIntegers');s=s[:at]+'''    internal static BigInteger ModuloIntegers(BigInteger left, BigInteger right)
    {
        // BCL remainder has the dividend's sign; Python uses the divisor's.
        // Avoid constructing the full quotient and product to obtain it.
        var remainder = left % right;
        return !remainder.IsZero && remainder.Sign != right.Sign ? remainder + right : remainder;
    }

'''+s[at:];p.write_text(s,encoding='utf-8')
p=Path('tests/Lokad.Lython.Tests/PyNumberPrimitiveTests.cs');s=p.read_text(encoding='utf-8')
for name,expected in [('Subtract',4),('Multiply',21),('FloorDivide',2),('Modulo',1)]:
 s=s.replace(f'PyNumberOps.{name}(seven, three)',f'Runtime.LythonRuntime.EvaluateIntegerBinary(Frontend.BinaryOperatorSyntax.{name}, seven.Integer, three.Integer, context, new(0, 1, 1, 1))')
p.write_text(s,encoding='utf-8')
print('Migrated integer kernel and removed duplicate numeric branches/preflight.',flush=True)
