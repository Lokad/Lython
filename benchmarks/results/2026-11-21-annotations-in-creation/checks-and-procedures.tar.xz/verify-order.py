from pathlib import Path
import hashlib,json,os,subprocess

lab=Path('.git/agent-notes/review-20261031/packed-annotations-in-creation').resolve()
root=lab.parents[3]
base=json.loads((lab/'representative.json').read_bytes())
cases=[
('annotations.default-decorator-order', """events = []
saved = []
Alias = int
def decorator_expression():
    events.append('decorator expression')
    def apply(function):
        global Alias
        Alias = float
        events.append('decorator call')
        saved.append(function.__annotations__)
        return function
    return apply
def choose_default():
    global Alias
    Alias = str
    events.append('default')
    return 'selected'
def build():
    @decorator_expression()
    def example(value: Alias = choose_default()) -> Alias:
        return value
    return example
f = build()
print(events)
print(f(), Alias.__name__, f.__annotations__)
print(saved[0] is f.__annotations__)
"""),
('annotations.dynamic-name-failure-order', """events = []
Alias = int
def decorator_expression():
    events.append('decorator expression')
    def apply(function):
        events.append('decorator call')
        return function
    return apply
def choose_default():
    global Alias
    del Alias
    events.append('default')
    return 'selected'
def build():
    @decorator_expression()
    def example(value: str = choose_default()) -> Alias:
        return value
    return example
try:
    build()
except NameError:
    print(events)
""")]
ref="C:/Python313/python.exe"
digest=lambda text:hashlib.sha256(text.encode("utf-8")).hexdigest()
base['cases']=[]
for case,source in cases:
    result=subprocess.check_output([ref,'-I','-S','-c',source],encoding='utf-8')
    fixture='{"size":1,"text":null}'
    base['cases'].append(dict(id=case,family='scripts',category='whole-script',scale='small',size=1,source=source,
        fixtureJson=fixture,expectedOutput=result,sourceUtf8Bytes=len(source.encode('utf-8')),expectedOutputUtf8Bytes=len(result.encode('utf-8')),
        fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,sourceSha256=digest(source),fixtureSha256=digest(fixture),expectedOutputSha256=digest(result)))
manifest=lab/'semantic-catalog.json'
manifest.write_text(json.dumps(base,indent=2)+'\n',encoding='utf-8',newline='\n')
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
for role in ('reference','candidate'):
    image=lab/'quiet-workers'/role
    expected=json.loads((lab/'quiet/identity.json').read_bytes())['imageFiles'][role]
    assert len(expected)==32 and {f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in image.iterdir()}==expected
    receipt=lab/f'{role}-semantic-verify.json'
    subprocess.run([dotnet,image/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',manifest,'--dotnet',dotnet,
        '--python',ref,'--python-worker',root/'benchmarks/cpython-worker.py','--out',receipt],check=True,env=env,timeout=120)
    data=json.loads(receipt.read_bytes())
    assert data['state']=='Completed' and data['caseCount']==2
