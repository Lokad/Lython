using Lokad.Lython.Frontend;
using System.Security.Cryptography;
using System.Text.Json;

using var catalog = JsonDocument.Parse(File.ReadAllBytes(args[0]));
var rows = new List<object>();
foreach (var item in catalog.RootElement.GetProperty("cases").EnumerateArray())
{
    var source = item.GetProperty("source").GetString()!;
    var root = ExecutableScript.Compile(LythonFrontend.Compile(source).Script
        ?? throw new InvalidOperationException("Source did not parse.")).EntryPoint;
    var definitions = new List<object>();
    var seen = new HashSet<ExecutableCodeObject>(ReferenceEqualityComparer.Instance);
    Visit(root);
    rows.Add(new { id = item.GetProperty("id").GetString(), definitions });

    void Visit(ExecutableCodeObject code)
    {
        if (!seen.Add(code)) return;
        var operations = code.Instructions.Where(instruction => instruction.OpCode == ExecutableOpCode.ApplyOperation)
            .Select(instruction => code.Constants[instruction.ConstantIndex]).ToArray();
        var packed = operations.Where(operation => operation?.GetType().Name == "ExecutableReadFunctionAnnotations")
            .Sum(operation => ((ExecutableInstruction[])operation!.GetType().GetProperty("Reads")!.GetValue(operation)!).Length);
        packed += operations.OfType<ExecutableCreateFunction>().Sum(operation =>
            (operation.GetType().GetProperty("EagerAnnotationReads")?.GetValue(operation) as ExecutableInstruction[])?.Length ?? 0);
        definitions.Add(new { code.Name, instructions = code.Instructions.Length, code.ValueStorageCapacity,
            packedReads = packed, eagerOperandSlots = operations.OfType<ExecutableCreateFunction>().Sum(operation => operation.AnnotationOperandCount) });
        foreach (var operation in operations)
        {
            var child = operation switch
            {
                ExecutableCreateFunction function => function.CodeObject,
                ExecutableCreateLambda lambda => lambda.CodeObject,
                ExecutableCreateClass type => type.Body,
                ExecutableCreateGeneratorExpression generator => generator.CodeObject,
                _ => null
            };
            if (child is not null) Visit(child);
        }
    }
}
var binary = File.ReadAllBytes(typeof(LythonFrontend).Assembly.Location);
Console.WriteLine(JsonSerializer.Serialize(new { coreSHA256 = Convert.ToHexStringLower(SHA256.HashData(binary)), rows },
    new JsonSerializerOptions { WriteIndented = true }));

