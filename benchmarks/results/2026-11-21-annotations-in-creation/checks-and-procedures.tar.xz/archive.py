from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile


lab = Path(__file__).resolve().parent
quiet = lab / "quiet"
out = Path("benchmarks/results/2026-11-21-annotations-in-creation")


def load(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


identity = load(quiet / "identity.json")
assert identity["sourceRevision"].split()[0].startswith("256c5e651")
assert identity["sourceRevision"].split()[-1].startswith("595798ffa")
for role, files in identity["imageFiles"].items():
    image = lab / "quiet-workers" / role
    assert len(files) == 32 and {f.name: sha(f) for f in image.iterdir()} == files
    local = load(lab / f"quiet-{role}-verify.json")
    assert local["state"] == "Completed" and local["caseCount"] == 5
    assert local["catalogSha256"] == identity["catalogSHA256"] == sha(quiet / "representative.json")
    semantic = load(lab / f"{role}-semantic-verify.json")
    assert semantic["state"] == "Completed" and semantic["caseCount"] == 2
    assert semantic["catalogSha256"] == sha(lab / "semantic-catalog.json")
for platform in ("win", "ubuntu"):
    for suite, count in (("white", 363), ("public", 455)):
        log = (lab / f"rebased-{suite}-{platform}.log").read_text(encoding="utf-8-sig")
        assert "Passed!" in log and f"Passed: {count:5d}, Skipped:" in log

receipt = load(quiet / "archive-receipt.json")
terminal = load(quiet / "terminal-status.json")
assert terminal["exitCode"] == "0" and terminal["receipt"] == receipt
assert not terminal["remainingTrace"] and not terminal["remainingWorkers"]
assert all(receipt[key] for key in ("complete", "allWorkersJoined", "guestFixturesRemoved",
                                   "archivedAndVerifiedUnderLease", "quietBeforeAndAfter"))
assert sha(quiet / "observations.tgz") == receipt["archiveSHA256"]
raw = load(quiet / "retrieved/confirmation/confirmation.json")
assert raw["warmupSeconds"] == 8 and raw["targetBatchSeconds"] == .65 and raw["rounds"] == 7
cases = {case["id"]: case for case in load(quiet / "representative.json")["cases"]}
assert raw["complete"] and len(raw["jobs"]) == receipt["jobs"] == 5 and len(cases) == 5
assert [(job["case"], job["lane"]) for job in raw["jobs"]] == [(case,"warm") for case in cases]
for job in raw["jobs"]:
    case = cases[job["case"]]
    assert job["workersJoinedAndFixturesRemoved"] and len(job["samples"]) == 28
    for sample in job["samples"]:
        response = sample["response"]
        assert response["completedInvocations"] > 0 and response["status"] == "Completed"
        assert response["sourceSha256"] == case["sourceSha256"] and response["fixtureSha256"] == case["fixtureSha256"]
        assert response.get("actualOutputSha256") == (None if job["lane"] == "compile" else case["expectedOutputSha256"])
        assert response.get("actualFilesSha256") == (None if job["lane"] == "compile" else case.get("expectedFilesSha256"))

summary = load(quiet / "quiet-summary.json")
del summary["retentionDecisionPending"]
summary.update(collection="B1291", sourceRevision=identity["sourceRevision"],
               verifiedTimedBatches=140, coreSHA256=identity["coreSHA256"],
               archiveSHA256=receipt["archiveSHA256"], retentionDecision=load(lab / "decision.json")["decision"])
out.mkdir(exist_ok=True)
(out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8", newline="\n")
shutil.copyfile(lab / "README.md", out / "README.md")
shutil.copyfile(lab / "allocation-summary.json", out / "local-allocations.json")
shape = {role: load(lab / f"{role}-shape.json") for role in ("reference", "candidate")}
for role, output in shape.items():
    assert output["coreSHA256"] == identity["imageFiles"][role]["Lokad.Lython.dll"]
(out / "annotation-shape.json").write_text(json.dumps(shape, indent=2) + "\n", encoding="utf-8", newline="\n")
assert all(row["budgetReturnedToBaseline"] for row in load(lab / "allocation-summary.json"))
for name in ("archive-receipt.json", "terminal-status.json", "observations.tgz"):
    shutil.copyfile(quiet / name, out / name)
candidate = (quiet / "candidate/Lokad.Lython.dll").read_bytes()
artifact = out / "candidate-core.dll.gz"
artifact.write_bytes(gzip.compress(candidate, mtime=0))
assert gzip.decompress(artifact.read_bytes()) == candidate
reference = "benchmarks/results/2026-11-21-cpython-current-factories/measured-core.dll.gz"
assert gzip.decompress(Path(reference).read_bytes()) == (lab / "quiet-workers/reference/Lokad.Lython.dll").read_bytes()
start, _, end = identity["sourceRevision"].split()
(lab / "measured-source.patch").write_bytes(subprocess.check_output(["git", "diff", start, end, "--", "src", "tests"]))
with tarfile.open(out / "checks-and-procedures.tar.xz", "w:xz", preset=6) as archive:
    for folder in (lab, quiet, lab / "shape"):
        for path in sorted(folder.iterdir()):
            if path.is_file() and path.suffix not in {".dll", ".tgz"} and path.name not in {"launch.py", "retrieve.py"}:
                archive.add(path, arcname=path.relative_to(lab).as_posix())
print("140 timed batches and both complete frozen worker images verified.")
