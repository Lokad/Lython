from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
prior = lab / "quiet"
quiet = lab / "confirmation"
quiet.mkdir()

def load(path):
    return json.loads(path.read_text(encoding="utf-8"))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def emit(path, source):
    if path.suffix == ".py":
        compile(source, str(path), "exec")
    path.write_text(source, encoding="utf-8", newline="\n")

def save(path, value):
    emit(path, json.dumps(value, indent=2) + "\n")

old = load(prior / "config.json")
receipt = load(prior / "archive-receipt.json")
terminal = load(prior / "terminal-status.json")
assert terminal["receipt"] == receipt and terminal["exitCode"] == "0"
assert receipt["complete"] and receipt["archivedAndVerifiedUnderLease"]
assert sha(prior / "observations.tgz") == receipt["archiveSHA256"]
identity = load(prior / "identity.json")
for role, expected in identity["imageFiles"].items():
    folder = lab / "quiet-workers" / role
    assert len(expected) == 32 and {f.name: sha(f) for f in folder.iterdir()} == expected
    proof = load(lab / f"quiet-{role}-verify.json")
    assert proof["state"] == "Completed" and proof["caseCount"] == 5
    assert proof["catalogSha256"] == identity["catalogSHA256"] == sha(prior / "representative.json")

root = "/home/lokad/lython-bench-checks/annotations-in-creation-confirm-b1292-20261121"
unit = "lython-b1292-annotations-in-creation-confirm-20261121"
jobs = [("scripts.ordinary-fully-supplied-helper", "warm"), ("scripts.annotated-rule-closures", "warm"),
        ("scripts.annotated-rule-closures", "compile-run")]
identity["purpose"] = "Confirm eager annotations in callable creation and its unchanged helper control, and add eager time to result"
save(quiet / "identity.json", identity)
for name in ("collect.py", "archive-owned.py", "run.sh", "retrieve.py"):
    source = (prior / name).read_text(encoding="utf-8").replace(old["root"], root).replace(old["unit"], unit)
    if name == "collect.py":
        begin = source.index("\njobs = ")
        end = source.index("\nassert len(jobs)", begin)
        source = (source[:begin] + "\njobs = " + repr(jobs) + source[end:]).replace("len(jobs)==5", "len(jobs)==3")
    if name == "archive-owned.py":
        source = source.replace("len(raw['jobs'])==5", "len(raw['jobs'])==3").replace("jobs=5,", "jobs=3,")
    if name == "retrieve.py":
        source = source.replace("['jobs']==5", "['jobs']==3")
    emit(quiet / name, source)
assert b"\r" not in (quiet / "run.sh").read_bytes()
parts = ("identity.json", "collect.py", "archive-owned.py", "run.sh")
payload = quiet / "payload.tgz"
with tarfile.open(payload, "w:gz") as packed:
    for name in parts:
        packed.add(quiet / name, arcname=name)
stage = dict(root=root, unit=unit, identity=identity, source=old["root"], sourceRole="reference",
             sourceFiles=identity["imageFiles"]["reference"], sourceCatalogSHA256=identity["catalogSHA256"],
             donorArchiveSHA256=receipt["archiveSHA256"], protocolSource=old["root"] + "/cpython-worker.py",
             protocolSHA256=old["protocolSHA256"], payloadBytes=payload.stat().st_size,
             payloadSHA256=sha(payload), retireGroups=[], catalogSHA256=identity["catalogSHA256"],
             unpackedBytes=sum((quiet / name).stat().st_size for name in parts))
save(quiet / "config.json", stage)
source = (prior / "remote-launch.py").read_text(encoding="utf-8")
begin, end = source.index("\nc=") + 1, source.index("\nb=Path(")
source = source[:begin] + "c=" + repr(stage) + source[end:]
source = source.replace("lython-b1291-fixtures", "lython-b1292-fixtures")
assert "c['unpackedBytes']+3*512*1024" in source
source = source.replace("c['unpackedBytes']+3*512*1024", "c['unpackedBytes']+1024*1024")
source = source.replace("if not p.exists():os.link(source/c['sourceRole']/n,p)",
                        "if not p.exists():\n    assert sha(source/role/n)==h,n\n    os.link(source/role/n,p)")
emit(quiet / "remote-launch.py", source)
emit(lab / "launch-confirmation.py", (lab / "launch.py").read_text(encoding="utf-8")
     .replace("/'quiet'", "/'confirmation'").replace("355", "225"))
emit(lab / "summarize-confirmation.py", (lab / "summarize.py").read_text(encoding="utf-8")
     .replace("'quiet/", "'confirmation/").replace("len(raw['jobs'])==5", "len(raw['jobs'])==3"))
print("Prepared three lanes using the existing immutable images.")
