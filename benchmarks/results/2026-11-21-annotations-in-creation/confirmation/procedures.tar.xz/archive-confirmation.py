from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
root = lab / "confirmation"
archive = Path("benchmarks/results/2026-11-21-annotations-in-creation")
out = archive / "confirmation"

def load(path):
    return json.loads(path.read_text(encoding="utf-8"))

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

before, after = (load(path / "identity.json") for path in (lab / "quiet", root))
del before["purpose"], after["purpose"]
assert before == after
for role, expected in after["imageFiles"].items():
    image = lab / "quiet-workers" / role
    assert len(expected) == 32 and {path.name: sha(path) for path in image.iterdir()} == expected
    proof = load(lab / f"quiet-{role}-verify.json")
    assert proof["state"] == "Completed" and proof["caseCount"] == 5
    assert proof["catalogSha256"] == after["catalogSHA256"] == sha(lab / "quiet/representative.json")

receipt = load(root / "archive-receipt.json")
status = load(root / "terminal-status.json")
assert status["receipt"] == receipt and status["exitCode"] == "0" and not status["remainingTrace"] and not status["remainingWorkers"]
assert all(receipt[key] for key in ("complete", "allWorkersJoined", "guestFixturesRemoved",
                                   "archivedAndVerifiedUnderLease", "quietBeforeAndAfter"))
assert sha(root / "observations.tgz") == receipt["archiveSHA256"]
raw = load(root / "retrieved/confirmation/confirmation.json")
assert raw["warmupSeconds"] == 8 and raw["targetBatchSeconds"] == .65 and raw["rounds"] == 7
assert raw["complete"] and len(raw["jobs"]) == receipt["jobs"] == 3
actual = [(job["case"], job["lane"]) for job in raw["jobs"]]
assert actual == [("scripts.ordinary-fully-supplied-helper", "warm"), ("scripts.annotated-rule-closures", "warm"),
                  ("scripts.annotated-rule-closures", "compile-run")]
cases = {case["id"]: case for case in load(lab / "quiet/representative.json")["cases"]}
for job in raw["jobs"]:
    case = cases[job["case"]]
    assert job["workersJoinedAndFixturesRemoved"] and len(job["samples"]) == 28
    for sample in job["samples"]:
        response = sample["response"]
        assert response["completedInvocations"] > 0 and response["status"] == "Completed"
        assert response["sourceSha256"] == case["sourceSha256"] and response["fixtureSha256"] == case["fixtureSha256"]
        assert response.get("actualOutputSha256") == case["expectedOutputSha256"]
        assert response.get("actualFilesSha256") == case.get("expectedFilesSha256")

summary = load(root / "quiet-summary.json")
del summary["retentionDecisionPending"]
summary.update(collection="B1292", sourceRevision=after["sourceRevision"], verifiedTimedBatches=84,
               coreSHA256=after["coreSHA256"], archiveSHA256=receipt["archiveSHA256"],
               retentionDecision="Retain integrated annotation reads. Warm eager elapsed is directionally favorable across both runs. Time to result improves with lower CPU. The unchanged helper regression did not recur.")
out.mkdir(exist_ok=True)
(out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8", newline="\n")
for name in ("archive-receipt.json", "terminal-status.json", "observations.tgz"):
    shutil.copyfile(root / name, out / name)
with tarfile.open(out / "procedures.tar.xz", "w:xz", preset=6) as procedures:
    for path in sorted(root.iterdir()):
        if path.is_file() and path.suffix not in {".tgz"}:
            procedures.add(path, arcname=path.name)
    for name in ("prepare-confirmation.py", "launch-confirmation.py", "summarize-confirmation.py", "archive-confirmation.py"):
        procedures.add(lab / name, arcname=name)
print("84 timed batches, both complete images and the original observations verified.")
