set -eu
root=/home/lokad/lython-bench-checks/annotations-in-creation-confirm-b1292-20261121
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
