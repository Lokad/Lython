from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

lab=Path(__file__).resolve().parent
notes=lab.parent
prior=notes/"borrowed-cased-words-refined-20261123"
identity=json.loads((prior/"comparison/identity.json").read_text(encoding="utf-8"))
manifest=identity["imageFiles"]["candidate"]
bases=notes/"native-stack-initialization-20261123/comparison/representative.json"
catalog=json.loads(bases.read_text(encoding="utf-8"))
match={c["id"]:c for c in catalog["cases"]}
image=lab/"retained"
image.mkdir()
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
for name,digest in manifest.items():
    src=prior/"candidate"/name
    assert sha(src)==digest
    shutil.copyfile(src,image/name)
driver=notes/"factory-checkpoint-source-pair-20261122/reservation-probe/bin/Release/net11.0"
for name in ("Reservations.dll","Reservations.deps.json","Reservations.runtimeconfig.json"):
    shutil.copyfile(driver/name,image/name)
sdk=Path.home()/".dotnet11"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
for role,suffix in (("postponed",".postponed"),("eager","")):
    key="scripts.annotated-rule-closures.nested-factories"+suffix
    case=match[key].copy()
    # The existing diagnostic selects a suffix. Preserve the script and golden
    # while giving the instrumentation an isolated one-case catalog.
    case["id"]="diagnostic."+role+".nested-factories.postponed"
    variant=lab/(role+"-catalog.json")
    variant.write_text(json.dumps(dict(catalog,cases=[case]),indent=2)+"\n",encoding="utf-8",newline="\n")
    result=subprocess.run([sdk/"dotnet.exe",image/"Reservations.dll",image,variant],env=env,
        capture_output=True,encoding="utf-8",check=True,timeout=55)
    data=json.loads(result.stdout)
    assert not result.stderr and data["core"]==manifest["Lokad.Lython.dll"] and len(data["rows"])==2
    (lab/(role+"-observations.json")).write_text(
        json.dumps(dict(case=key,data=data),indent=2)+"\n",encoding="utf-8",newline="\n")
    for row in data["rows"]:
        print(role,row["growths"],row["peak"],[(r["Value"],r["Key"].split(" > ")[:4])for r in row["requests"][:4]])
assert {name:sha(image/name)for name in manifest}==manifest
