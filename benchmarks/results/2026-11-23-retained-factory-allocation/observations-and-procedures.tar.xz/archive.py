from pathlib import Path
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
dest = repo/"benchmarks/results/2026-11-23-retained-factory-allocation"
source = json.loads((repo/"benchmarks/results/2026-11-23-borrowed-cased-words-append/identity.json").read_text(encoding="utf-8"))
summary = json.loads((lab/"run-summary.json").read_text(encoding="utf-8"))
assert summary["sourceRevision"] == source["retainedRevision"]
assert summary["allProcessesJoined"] and summary["totalVerifiedBatches"] == 286
assert not summary["timingQualification"]
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
files = source["imageFiles"]["candidate"]
assert len(files)==32 and all(sha(lab/"retained"/n)==h for n,h in files.items())
dest.mkdir()
(dest/"identity.json").write_text(json.dumps({**summary,"imageFiles":files},indent=2)+"\n", encoding="utf-8", newline="\n")
rows=[]
for role in ("postponed","eager"):
    run=lab/(role+"-factories")
    report=json.loads((run/"record.json").read_text(encoding="utf-8"))
    assert report["allProcessesJoined"] and report["coreSha"] == files["Lokad.Lython.dll"]
    assert sha(run/"warm.nettrace")==report["nettraceSha"]
    allocation=json.loads((run/"sampled-allocation.json").read_text(encoding="utf-8-sig"))
    reserve=json.loads((lab/(role+"-observations.json")).read_text(encoding="utf-8"))["data"]
    assert reserve["core"]==files["Lokad.Lython.dll"] and len(reserve["rows"])==2
    assert all(row["growths"]==6169 for row in reserve["rows"])
    rows.append(dict(workload=report["workload"],traceSHA256=report["nettraceSha"],verifiedBatches=len(report["batches"]),
        allocation=allocation,admission=reserve["rows"]))
(dest/"summary.json").write_text(json.dumps(rows,indent=2)+"\n",encoding="utf-8",newline="\n")
with tarfile.open(dest/"observations-and-procedures.tar.xz","w:xz") as archive:
    for name in ("trace.py", "profile-allocation.py", "verification.json", "catalog.json", "run-summary.json",
            "eager-catalog.json", "postponed-catalog.json", "boxing-sites.log", "read-il/Program.cs", "read-il/ReadIl.csproj",
            "inspect-stack/Program.cs", "inspect-stack/InspectStacks.csproj", "executable-shape.json", "archive.py"):
        archive.add(lab/name,arcname=name,recursive=False)
    for role in ("postponed", "eager"):
        for name in ("warm.nettrace", "capture.log", "record.json", "sampled-allocation.json", "allocation-stacks.json"):
            path=role+"-factories/"+name
            archive.add(lab/path,arcname=path,recursive=False)
        path=role+"-observations.json"
        archive.add(lab/path,arcname=path,recursive=False)
    archive.add(lab/"postponed-factories/allocation-offsets.json",arcname="postponed-factories/allocation-offsets.json",recursive=False)
    driver=lab.parent/"factory-checkpoint-source-pair-20261122/reservation-probe"
    for name in ("Program.cs","Reservations.csproj"):
        archive.add(driver/name,arcname="reservation-probe/"+name,recursive=False)
print(dest)
