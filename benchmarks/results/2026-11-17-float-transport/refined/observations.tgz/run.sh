set -eu
root=/home/lokad/lython-bench-checks/float-refined-b880-20261117
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
