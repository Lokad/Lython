from pathlib import Path
import datetime,hashlib,json,shlex,subprocess,tarfile
r=Path(__file__).parent/'quiet';config=json.loads((r/'config.json').read_text(encoding='utf-8'));bound=json.loads((r/'observe-not-before.json').read_text(encoding='utf-8'))
assert not(r/'terminal-status.json').exists()
assert datetime.datetime.now(datetime.timezone.utc)>=datetime.datetime.fromisoformat(bound['doNotObserveBeforeUTC'])
code=r'''from pathlib import Path
import fcntl,hashlib,json,subprocess
c=CONFIG
root=Path(c['root'])
service=subprocess.check_output(['systemctl','show',c['unit']+'.service','--property=ActiveState,SubState,MainPID,Result,ExecMainStatus'],text=True)
assert 'ActiveState=active'not in service and 'MainPID=0'in service,service
with(root.parent/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 assert not subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[p]ython3.*cpython-worker.py'],capture_output=True,text=True).stdout
 assert not(root/'guest-fixtures').exists()
 raw=json.loads((root/'confirmation/confirmation.json').read_text());assert raw['complete']and len(raw['jobs'])==4 and all(j['workersJoinedAndFixturesRemoved']for j in raw['jobs'])
 assert all(json.loads((root/'confirmation'/n).read_text())['gate']['quiet']for n in ['machine-before.json','machine-after.json'])
 originalExit=(root/'exit-code.txt').read_text().strip();assert originalExit=='1'
 journal=subprocess.check_output(['journalctl','-u',c['unit']+'.service','-n','35','--no-pager'],text=True)
 assert 'archive-owned.py'in journal and 'AssertionError'in journal
 for role,files in c['identity']['imageFiles'].items():
  for name,h in files.items():assert hashlib.sha256((root/role/name).read_bytes()).hexdigest()==h
 original=(root/'archive-owned.py').read_text();assert "len(raw['jobs'])==5"in original and 'jobs=5'in original
 corrected=original.replace("len(raw['jobs'])==5","len(raw['jobs'])==4").replace('jobs=5','jobs=4')
 recovery=dict(originalService=service,originalExit=originalExit,journal=journal,reason='Inherited archival receipt expects5jobs but bounded collection intentionally has4. All4jobs completed, original gates passed, all workers joined and RAM removed before this assertion. Correct only offline receipt count under fresh idle lease; no timings rerun or overwritten.',originalArchiveScriptSHA256=hashlib.sha256(original.encode()).hexdigest(),correctedArchiveScriptSHA256=hashlib.sha256(corrected.encode()).hexdigest())
 (root/'archive-recovery.json').write_text(json.dumps(recovery,indent=2)+'\n')
 (root/'archive-recovery.py').write_text(corrected)
 exec(compile(corrected,str(root/'archive-recovery.py'),'exec'),{'__file__':str(root/'archive-recovery.py'),'__name__':'__main__'})
 receipt=json.loads((root/'archive-receipt.json').read_text());assert receipt['jobs']==4 and receipt['complete']
 print('TERMINAL'+json.dumps(dict(live=False,service=service,originalExitCode=originalExit,recoveredArchivalOnly=True,receipt=receipt,remainingWorkers='',remainingTrace=False)))
'''.replace('CONFIG',repr(config))
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=code,text=True,encoding='utf-8',capture_output=True,timeout=60)
(r/'retrieve-recovery.log').write_text(p.stdout+p.stderr,encoding='utf-8',newline='\n');assert p.returncode==0,p.stdout+p.stderr
status=json.loads(next(line[8:]for line in p.stdout.splitlines()if line.startswith('TERMINAL')))
(r/'terminal-status.json').write_text(json.dumps(status,indent=2)+'\n',encoding='utf-8',newline='\n')
scp=['C:/Windows/System32/OpenSSH/scp.exe','-i',ssh[2],'-o','BatchMode=yes','-o','ConnectTimeout=15']
for name in ['archive-receipt.json','observations.tgz']:
 p=subprocess.run(scp+['lokad@20.166.121.73:'+config['root']+'/'+name,str(r/name)],capture_output=True,timeout=60);assert p.returncode==0,p.stderr
assert hashlib.sha256((r/'observations.tgz').read_bytes()).hexdigest()==status['receipt']['archiveSHA256']
out=r/'retrieved';out.mkdir(exist_ok=False)
with tarfile.open(r/'observations.tgz')as archive:
 members=archive.getmembers();regular=[m for m in members if m.isfile()or m.isdir()];assert all(m.isfifo()and m.size==0 for m in members if m not in regular)
 archive.extractall(out,members=regular,filter='data')
print('B878 four jobs complete, original gates passed; offline archival count corrected, original failure preserved. All users joined, RAM removed, archive SHA verified; terminal cached.')
