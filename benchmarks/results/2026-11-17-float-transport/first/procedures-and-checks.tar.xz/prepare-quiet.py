from pathlib import Path
import ast,gzip,hashlib,io,json,shutil,subprocess,tarfile
r=Path(__file__).parent;base=Path('D:/code/Lython');old=r.parent/'call-argument-staging-r470';q=r/'quiet';q.mkdir(exist_ok=False)
remote='/home/lokad/lython-bench-checks/float-transport-b878-20261117'
f=json.loads((r/'frozen-identity.json').read_text(encoding='utf-8'))
jobs=[['scripts.numeric-squared-error.floating.large','warm'],['scripts.numeric-squared-error.floating.large','compile-run'],['scripts.numeric-squared-error.large','warm'],['scripts.text-normalization.helper-list','warm']]
collect=(old/'confirmation/collect.py').read_text(encoding='utf-8');a=collect.index('jobs=');b=collect.index('\n\nenv =',a);collect=collect[:a]+'jobs='+repr(jobs)+"\nassert len(jobs)==4 and all(case in cases for case,lane in jobs)"+collect[b:]
(q/'collect.py').write_text(collect,encoding='utf-8',newline='\n');shutil.copyfile(old/'quiet/archive-owned.py',q/'archive-owned.py')
(q/'run.sh').write_text((old/'quiet/run.sh').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/call-operands-b876-20261117',remote),encoding='utf-8',newline='\n')
ref=f['imageFiles']['reference']['Lokad.Lython.dll'];cand=f['imageFiles']['candidate']['Lokad.Lython.dll'];catalog=r/'diagnostic-catalog.json';cataloghash=hashlib.sha256(catalog.read_bytes()).hexdigest()
identity=dict(sourceRevision='Qualifiedccf20ba3/frozen7a599347 versus privateR471 oncb7472e7/frozen'+cand,purpose='R471 scoped floating arithmetic/helper/iteration/sum transport; same complete numeric-report script and4096records, existing dataset dividedby8. Integer/text controls. Same fixed three-case catalog for all four processes, not a cross-collection source claim.',coreSHA256={'reference':ref,'reference-control':ref,'candidate':cand,'candidate-control':cand},auxiliaryFiles={n:h for n,h in f['imageFiles']['reference'].items()if n!='Lokad.Lython.dll'},imageFiles=f['imageFiles'],sourceInputsArchiveSHA256=hashlib.sha256((r/'candidate-sources.tar.xz').read_bytes()).hexdigest(),productionFiles=f['productionFiles'],catalogSHA256=cataloghash,catalogInitialization='Three complete scripts from locally verified13case catalog, shared identically across sources. Interleaved warmup accumulates8seconds of full requests for each process. No forcedGC/runtime override.',normalAdapterPin='0.4.0',publicationHeld=True)
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n');(q/'candidate').mkdir();shutil.copyfile(r/'candidate/Lokad.Lython.dll',q/'candidate/Lokad.Lython.dll');shutil.copyfile(catalog,q/'representative.json')
def committed(path):
    blob=subprocess.check_output(['git','show','HEAD:'+path],cwd=base);assert blob==(base/path).read_bytes();return blob
groups=[]
canonical='benchmarks/results/2026-11-17-call-operand-forwarding/candidate-core.dll.gz';blob=committed(canonical);data=gzip.decompress(blob)
groups.append(dict(paths=['call-operands-b876-20261117/candidate/Lokad.Lython.dll','call-operands-b877-20261117/candidate/Lokad.Lython.dll'],bytes=len(data),links=2,sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='gzip-payload',committedBlobVerified=True,withdrawnPrototypeOnly=True))
canonical='benchmarks/results/2026-11-17-call-operand-forwarding/procedures-and-checks.tar.xz';blob=committed(canonical)
with tarfile.open(fileobj=io.BytesIO(blob))as archive:data=archive.extractfile('catalog.json').read()
assert data==(old/'catalog.json').read_bytes()
groups.append(dict(paths=['json-token-scan-b875-20261117/representative.json','call-operands-b876-20261117/representative.json','call-operands-b877-20261117/representative.json'],bytes=len(data),links=3,sha256=hashlib.sha256(data).hexdigest(),canonical=canonical,canonicalSHA256=hashlib.sha256(blob).hexdigest(),member='catalog.json',committedBlobVerified=True,supersededWorkingCatalogOnly=True))
names=['collect.py','archive-owned.py','run.sh','identity.json','candidate/Lokad.Lython.dll','representative.json']
with tarfile.open(q/'payload.tgz','w:gz')as archive:
    for name in names:archive.add(q/name,arcname=name)
c=dict(root=remote,unit='lython-b878-float-transport-20261117',source='/home/lokad/lython-bench-checks/call-operands-b877-20261117',sourceRole='reference',sourceFiles=f['imageFiles']['reference'],sourceCatalogSHA256=groups[-1]['sha256'],catalogSHA256=cataloghash,identity=identity,retireGroups=groups,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum((q/n).stat().st_size for n in names))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
launch=(old/'quiet/remote-launch.py').read_text(encoding='utf-8');a=launch.index('c=');b=launch.index('\nb=Path(',a);launch=launch[:a]+'c='+repr(c)+launch[b:]
launch=launch.replace(" os.link(source/'representative.json',root/'representative.json')\n",'').replace('lython-b876-fixtures','lython-b878-fixtures')
(q/'remote-launch.py').write_text(launch,encoding='utf-8',newline='\n')
(r/'launch.py').write_text((old/'launch.py').read_text(encoding='utf-8').replace('Five-job call operand source pair launched; do not observe before180seconds.','Four-job float transport source pair launched; do not observe before230seconds.').replace('timedelta(seconds=180)','timedelta(seconds=230)'),encoding='utf-8',newline='\n')
(q/'retrieve.py').write_text((old/'quiet/retrieve.py').read_text(encoding='utf-8').replace('B876','B878'),encoding='utf-8',newline='\n')
for p in list(q.glob('*.py'))+[r/'launch.py']:ast.parse(p.read_text(encoding='utf-8'))
print('Prepared4jobs, interleaved8s request warmups; retired replicas',sum(g['bytes']for g in groups),'stage',c['unpackedBytes'],'candidate',cand)
