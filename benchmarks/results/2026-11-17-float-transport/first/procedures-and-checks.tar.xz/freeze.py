from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
r=Path(__file__).parent;base=Path('D:/code/Lython');work=base/'.git/agent-worktrees/call-operands-r470'
candidate=r/'candidate';candidate.mkdir(exist_ok=False)
identity=json.loads((r/'identity.json').read_text(encoding='utf-8'))
for name,h in identity['imageFiles'].items():
    source=r/'baseline'/name;assert hashlib.sha256(source.read_bytes()).hexdigest()==h
    shutil.copyfile(source,candidate/name)
shutil.copyfile(work/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',candidate/'Lokad.Lython.dll')
images={role:{name:hashlib.sha256((folder/name).read_bytes()).hexdigest()for name in identity['imageFiles']}for role,folder in [('reference',r/'baseline'),('candidate',candidate)]}
assert [name for name in images['reference']if images['reference'][name]!=images['candidate'][name]]==['Lokad.Lython.dll']
inputs=json.loads((base/'benchmarks/results/2026-11-17-receiver-calls/delivery/inputs.json').read_text(encoding='utf-8'))['inputs']
inputs=list(inputs)+['tests/Lokad.Lython.PublicApi.Tests/FloatArithmeticPipelineTests.cs']
sources={name:hashlib.sha256((work/name).read_bytes()).hexdigest()for name in inputs}
with tarfile.open(r/'candidate-sources.tar.xz','w:xz')as archive:
    for name in sources:archive.add(work/name,arcname=name)
production=[name for name in sources if name.startswith('src/Lokad.Lython/')]
different=[name for name in production if (work/name).read_text(encoding='utf-8-sig')!=(base/name).read_text(encoding='utf-8-sig')]
assert sorted(different)==sorted(['src/Lokad.Lython/Runtime/LythonRuntime.Executable.Slot.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.Arithmetic.cs','src/Lokad.Lython/Runtime/LythonRuntime.BuiltinIterables.Aggregates.cs','src/Lokad.Lython/Runtime/Protocols/IPyIterableValue.cs']),different
frozen=dict(imageFiles=images,sourceInputs=sources,productionFiles=len(production),changedProductionFiles=different,catalogSHA256=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest(),reference='Fully qualified ccf20ba3, frozen7a599347',candidate='Private four-file R471 on cb7472e7; existing slot scalar bits and compensated sum, no new owner/backend',normalAdapterPin='0.4.0',publicationHeld=True)
(r/'frozen-identity.json').write_text(json.dumps(frozen,indent=2)+'\n',encoding='utf-8',newline='\n')
for p in (r/'baseline').glob('ValidatedAllocation.*'):shutil.copyfile(p,candidate/p.name)
dotnet=Path('C:/Users/JoannesVermorel/.dotnet11/dotnet.exe');env=os.environ.copy();env.update(DOTNET_ROOT=str(dotnet.parent),DOTNET_ROOT_X64=str(dotnet.parent));env['PATH']=str(dotnet.parent)+os.pathsep+env['PATH']
with(r/'candidate-preflight.log').open('w',encoding='utf-8')as log:
    p=subprocess.run([str(dotnet),str(candidate/'Lokad.Lython.Benchmarks.dll'),'--compare','verify','--catalog',str(r/'catalog.json'),'--dotnet',str(dotnet),'--python','C:/Python313/python.exe','--python-worker',str(base/'benchmarks/cpython-worker.py'),'--out',str(r/'candidate-preflight.json')],env=env,stdout=log,stderr=subprocess.STDOUT)
assert p.returncode==0,(r/'candidate-preflight.log').read_text(encoding='utf-8')
print('Candidate13case worker/CPython goldens pass.',flush=True)
with(r/'candidate-allocation.log').open('w',encoding='utf-8')as log:
    p=subprocess.run([str(dotnet),str(candidate/'ValidatedAllocation.dll'),str(candidate),str(r/'diagnostic-catalog.json'),str(r/'candidate-allocation.json')],env=env,stdout=log,stderr=subprocess.STDOUT)
assert p.returncode==0,(r/'candidate-allocation.log').read_text(encoding='utf-8')
for d in json.loads((r/'candidate-allocation.json').read_text(encoding='utf-8'))['rows']:print(d['id'],d['allocatedBytesPerInvocation'],d['peakExecutionMemoryBytes'],d['sharedBudgetBaselineRestored'])
