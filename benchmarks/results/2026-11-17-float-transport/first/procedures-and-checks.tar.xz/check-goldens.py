from pathlib import Path
import json,re,subprocess,textwrap
r=Path(__file__).parent
source=Path('D:/code/Lython/.git/agent-worktrees/call-operands-r470/tests/Lokad.Lython.PublicApi.Tests/FloatArithmeticPipelineTests.cs').read_text(encoding='utf-8')
programs=re.findall(r'yield return \["""(.*?)"""\];',source,re.S);assert len(programs)==6
rows=[]
for i,program in enumerate(programs):
    code=textwrap.dedent(program).strip()+'\n'
    p=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',code],capture_output=True,timeout=10)
    assert p.returncode==0,(i,p.stderr)
    assert p.stdout.replace(b'\r\n',b'\n')==b'ok\n',(i,p.stdout)
    rows.append(dict(case=i,success=True,stdout=p.stdout.decode(),source=code))
(r/'cpython-semantic-goldens.json').write_text(json.dumps(dict(version=subprocess.check_output(['C:/Python313/python.exe','--version'],text=True).strip(),rows=rows),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Six independent CPython3.13.2 semantic scripts pass.')
