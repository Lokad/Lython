from pathlib import Path
r=Path(__file__).parent
source=(r/'summarize.py').read_text(encoding='utf-8').split('reference=json.loads')[0]
source=source.replace("r/'quiet/retrieved/confirmation/confirmation.json'","r/'confirmation/retrieved/confirmation/confirmation.json'").replace("len(raw['jobs'])==4","len(raw['jobs'])==1").replace("r/'summary.json'","r/'confirmation-summary.json'")
source=source.replace("archivalOnlyRecovery='Inherited5job receipt corrected offline to4 after all work/gates/cleanup completed; originalserviceexit1 preserved. Timings not repeated.'","archivalOnlyRecovery=None")
exec(compile(source,str(__file__),'exec'),{'__file__':str(__file__),'__name__':'__main__'})
