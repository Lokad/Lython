from pathlib import Path
import ast,hashlib,json,shutil,tarfile
r=Path(__file__).parent;old=r/'quiet';q=r/'confirmation';q.mkdir(exist_ok=False)
remote='/home/lokad/lython-bench-checks/float-control-b879-20261117'
collect=(old/'collect.py').read_text(encoding='utf-8');a=collect.index('jobs=');b=collect.index('\n\nenv =',a);collect=collect[:a]+"jobs=[['scripts.numeric-squared-error.large','warm']]\nassert len(jobs)==1 and all(case in cases for case,lane in jobs)"+collect[b:]
collect=collect.replace("preserve original B876sequential4second condition","bounded unchanged-source integer-control confirmation after moving B878process controls")
(q/'collect.py').write_text(collect,encoding='utf-8',newline='\n')
archive=(old/'archive-owned.py').read_text(encoding='utf-8').replace("len(raw['jobs'])==5","len(raw['jobs'])==1").replace('jobs=5','jobs=1');assert "len(raw['jobs'])==1"in archive
(q/'archive-owned.py').write_text(archive,encoding='utf-8',newline='\n')
(q/'run.sh').write_text((old/'run.sh').read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/float-transport-b878-20261117',remote),encoding='utf-8',newline='\n')
c=json.loads((old/'config.json').read_text(encoding='utf-8'));c.update(root=remote,unit='lython-b879-float-control-20261117',source='/home/lokad/lython-bench-checks/float-transport-b878-20261117',sourceCatalogSHA256=c['catalogSHA256'],retireGroups=[])
c['identity']['purpose']='One bounded unchanged-source confirmation of integer report control after B878between-process movement; same sources/images/three-case catalog, no failed conditions overwritten.'
(q/'identity.json').write_text(json.dumps(c['identity'],indent=2)+'\n',encoding='utf-8',newline='\n')
names=['collect.py','archive-owned.py','run.sh','identity.json']
with tarfile.open(q/'payload.tgz','w:gz')as archive:
    for name in names:archive.add(q/name,arcname=name)
c.update(payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=sum((q/n).stat().st_size for n in names))
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
launch=(old/'remote-launch.py').read_text(encoding='utf-8');a=launch.index('c=');b=launch.index('\nb=Path(',a);launch=launch[:a]+'c='+repr(c)+launch[b:]
launch=launch.replace("os.link(source/c['sourceRole']/n,p)","os.link(source/role/n,p)").replace(" assert (root/'representative.json').is_file()"," os.link(source/'representative.json',root/'representative.json')\n assert (root/'representative.json').is_file()").replace('lython-b878-fixtures','lython-b879-fixtures')
(q/'remote-launch.py').write_text(launch,encoding='utf-8',newline='\n')
launch=(r/'launch.py').read_text(encoding='utf-8').replace("parent/'quiet'","parent/'confirmation'").replace('timedelta(seconds=230)','timedelta(seconds=100)').replace('Four-job float transport source pair launched; do not observe before230seconds.','One-job unchanged-source integer control launched; do not observe before100seconds.')
(r/'launch-confirmation.py').write_text(launch,encoding='utf-8',newline='\n')
retrieve=(r.parent/'call-argument-staging-r470/quiet/retrieve.py').read_text(encoding='utf-8').replace("__file__).parent","__file__).parent/'confirmation'").replace("['jobs']==5","['jobs']==1").replace('B876','B879')
(r/'retrieve-confirmation.py').write_text(retrieve,encoding='utf-8',newline='\n')
for p in list(q.glob('*.py'))+[r/'launch-confirmation.py',r/'retrieve-confirmation.py']:ast.parse(p.read_text(encoding='utf-8'))
print('Prepared one unchanged-source integer-control job; no retirement/copy of cores or catalog.')
