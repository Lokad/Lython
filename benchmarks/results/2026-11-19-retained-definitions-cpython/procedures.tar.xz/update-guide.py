from pathlib import Path
import json

out = Path('benchmarks/results/2026-11-19-retained-definitions-cpython')
summary = json.loads((out / 'summary.json').read_text(encoding='utf-8'))
assert (summary['source'], summary['collection']) == ('eb444b988', 'B1078')
labels = {
    'scripts.rule-default-closures': ('Unannotated rule closures', '2,048 inputs / 4,096 definitions'),
    'scripts.annotated-rule-closures': ('Annotated rule closures', '2,048 inputs / 2,048 definitions'),
    'scripts.captured-rule-closures': ('Captured rule closures', '2,048 inputs / 4,096 returned closures'),
    'scripts.retained-nonlocal-factories': ('Retained nonlocal siblings', '240 factories / 720 returned closures'),
    'scripts.report-forwarding.expanded': ('Expanded forwarding report', '1,024 records / 26,112 B'),
}
rows = {(row['case'], row['lane']): row for row in summary['rows']}
phases = {'compile': 'Compilation only', 'compile-run': 'Compile-to-result'}
assert set(rows) == {(case, lane) for case in labels for lane in ('warm', *phases)}

def display(values, digits):
    low, high = (f'{value:.{digits}f}' for value in values)
    return f'{low}–{high}' if low != high else low

def metrics(row, lane):
    digits = 5 if lane == 'compile' else 3
    lython = display(row['lythonMs'], digits)
    python = display(row['cpythonMs'], digits)
    ratio = display(row['ratio'], 2)
    lc, rc, iqr = (row[name] for name in ('lythonControlPercent', 'cpythonControlPercent', 'maxIQRPercent'))
    note = ' Gap size uncertain.' if max(lc, rc, iqr) > 5 else ''
    return f'{lython} ms | {python} ms | {ratio}× | B1078 diagnostic. Controls L/C {lc:.2f} / {rc:.2f}%. IQR ≤{iqr:.2f}%.{note}'

def new_table(old, contents):
    names = {label for label, _ in labels.values()}
    lines = old.splitlines()
    older = [line for line in lines[2:] if line.split('|')[1].strip() not in names]
    return '\n'.join([*lines[:2], *contents, *older])

warm = [f'| {label} | {size} | {metrics(rows[case, "warm"], "warm")} |' for case,(label,size) in labels.items()]
phase = [f'| {label} | {name} | {metrics(rows[case,lane],lane)} |' for case,(label,_) in labels.items() for lane,name in phases.items()]
path = Path('docs/BENCHMARKS.md')
text = path.read_text(encoding='utf-8-sig')
assert 'B1078 measured' not in text
start = text.index('| Workload / warm execution')
end = text.index('\n\n**Ratio', start)
text = text[:start] + new_table(text[start:end], warm) + text[end:]
start = text.index('B1069 measured')
end = text.index('Warm clocks include', start)
text = text[:start]+f'''B1078 measured **eb444b988 / frozen {summary['coreSHA256'][:8]}**. The B1069
shipment and CSV rows measure **12fabffb1 / frozen 9b8511fc**. Both collections
ran **2026-11-19 UTC** against stock **CPython 3.13.16** on the quiet **Azure
F4as_v7**, with Ubuntu 24.04.4 and .NET 11 RC3. Each workload ran three phases
on duplicate processes per engine.
[B1078 observations](../benchmarks/results/2026-11-19-retained-definitions-cpython/README.md) ·
[B1069 observations](../benchmarks/results/2026-11-19-retained-trim-cpython/README.md).

'''+text[end:]
start = text.index('| Workload | Phase |')
end = text.index('\n\nCompilation includes', start)
text = text[:start]+new_table(text[start:end], phase)+text[end:]
text = text.replace('B1069 excludes cold startup. Earlier startup measurements use separate boundaries.',
    'Both collections exclude cold startup. Earlier startup measurements use separate boundaries.')
path.write_text(text,encoding='utf-8',newline='\n')
for case,(label,size) in labels.items():
    print(f'| {label} | {size} | '+ ' | '.join(display(rows[case,lane]['ratio'],2)+'×' for lane in ('compile','warm','compile-run'))+' |')
