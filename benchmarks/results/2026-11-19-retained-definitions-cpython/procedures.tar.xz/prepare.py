from pathlib import Path
import ast, hashlib, json, os, re, shutil, subprocess, tarfile

lab=Path(__file__).resolve().parent
repo=Path.cwd()
prior=lab.parent/'retained-trim-cpython-r640'
donor=lab.parent/'prepared-definition-dispatch-r646'
read=lambda p:p.read_text(encoding='utf-8-sig')
load=lambda p:json.loads(read(p))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,s):
    if name.endswith('.py'):ast.parse(s)
    (lab/name).write_text(s,encoding='utf-8',newline='\n')
def save(name,x):write(name,json.dumps(x,ensure_ascii=False,indent=2)+'\n')
old=load(donor/'quiet/config.json');receipt=load(donor/'quiet/archive-receipt.json')
files=old['identity']['imageFiles']['candidate'];frozen=donor/'frozen/candidate'
assert len(files)==32 and {name:sha(frozen/name) for name in files}==files
assert not subprocess.check_output(['git','diff','--name-only','eb444b988','0cbe8f867','--','src'])
assert load(Path('benchmarks/results/2026-11-19-prepared-dispatch-confirmation/summary.json'))['cores']['candidate']==files['Lokad.Lython.dll']
assert receipt['complete'] and receipt['archivedAndVerifiedUnderLease']
cat=load(prior/'representative.json')
all_cases=load(donor/'catalog.json')['cases']
case_ids=['scripts.rule-default-closures','scripts.annotated-rule-closures','scripts.captured-rule-closures',
    'scripts.retained-nonlocal-factories','scripts.report-forwarding.expanded']
cat['cases']=[next(case for case in all_cases if case['id']==name) for name in case_ids]
save('representative.json',cat);catalog=lab/'representative.json'
shutil.copyfile(repo/'benchmarks/cpython-worker.py',lab/'cpython-worker.py')
script_hash=sha(lab/'cpython-worker.py')
identity=dict(sourceRevision='eb444b988',purpose='Retained rule definition and capture checkpoint against CPython',
    imageFiles={'candidate':files},auxiliaryFiles={k:v for k,v in files.items() if k!='Lokad.Lython.dll'},
    coreSHA256={role:files['Lokad.Lython.dll'] for role in ('candidate','candidate-control')},
    catalogSHA256=sha(catalog),cpythonWorkerSHA256=script_hash,normalAdapterPin='0.4.0')
save('identity.json',identity)
sdk=Path.home()/'.dotnet11';dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
with (lab/'verify.log').open('wb') as log:
    subprocess.run([dotnet,frozen/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',catalog,
        '--dotnet',dotnet,'--python',Path('C:/Python313/python.exe'),'--python-worker',lab/'cpython-worker.py',
        '--out',lab/'verify.json'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120,check=True)
assert load(lab/'verify.json')['state']=='Completed' and load(lab/'verify.json')['catalogSha256']==sha(catalog)
assert {name:sha(frozen/name) for name in files}==files
root='/home/lokad/lython-bench-checks/retained-definitions-cpython-b1078-20261119'
unit='lython-b1078-retained-definitions-cpython-20261119'
prior_root=load(prior/'config.json')['root']
for name in ('collect.py','archive-owned.py','launch.py','retrieve.py','run.sh','collect-evidence.py'):
    source=read(prior/name).replace(prior_root,root).replace('B1069','B1078')
    if name=='collect.py':
        a=source.index('    for case_id,diagnostic in ');b=source.index('\n',a)
        source=source[:a]+f'    for case_id,diagnostic in {[(case,False) for case in case_ids]!r}:'+source[b:]
        source=source.replace('started<350','started<440').replace("3 if lane=='compile' or case_id=='scripts.config-edit.small' else 6 if case_id=='scripts.text-normalization.helper-list' else 4", "3 if lane=='compile' else 6 if lane=='warm' else 4")
    elif name=='archive-owned.py':
        source=source.replace("len(raw['jobs'])==4","len(raw['jobs'])==5").replace('jobs=4,','jobs=5,')
    elif name=='launch.py':source=source.replace('291','400')
    elif name=='retrieve.py':source=source.replace("['jobs']==4","['jobs']==5")
    elif name=='collect-evidence.py':
        source=source.replace('2026-11-19-retained-trim-cpython','2026-11-19-retained-definitions-cpython')
        source=source.replace('receipt["jobs"] == 4','receipt["jobs"] == 5').replace('len(cases) == 4','len(cases) == 5')
    write(name,source)

payload=lab/'payload.tgz'
names=['representative.json','identity.json','collect.py','archive-owned.py','run.sh','cpython-worker.py']
with tarfile.open(payload,'w:gz') as gz:
    for name in names:gz.add(lab/name,arcname=name)
config=dict(root=root,unit=unit,source=old['root'],sourceRole='candidate',sourceFiles=files,
    sourceCatalogSHA256=old['catalogSHA256'],catalogSHA256=sha(catalog),identity=identity,retireGroups=[],
    donorArchiveSHA256=receipt['archiveSHA256'],payloadBytes=payload.stat().st_size,payloadSHA256=sha(payload),
    unpackedBytes=sum((lab/name).stat().st_size for name in names),cpythonWorkerSHA256=script_hash)
save('config.json',config)
launcher=read(prior/'remote-launch.py')
a,b=launcher.index('\nc=')+1,launcher.index('\nb=Path(')
launcher=launcher[:a]+'c='+repr(config)+launcher[b:]
launcher=re.sub(r'lython-b[0-9]+-fixtures','lython-b1078-fixtures',launcher)
assert "for role in ['candidate']:" in launcher and "assert sha(root/'cpython-worker.py')==c['cpythonWorkerSHA256']" in launcher
launcher=launcher.replace('RuntimeMaxSec=410','RuntimeMaxSec=520')
write('remote-launch.py',launcher)
print('Verified all 32 image files and five CPython goldens. Sized the external refresh to the changed reports and existing controls.')
