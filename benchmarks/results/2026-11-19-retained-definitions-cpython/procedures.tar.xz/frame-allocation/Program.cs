using Lokad.Lython;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime;
using System.Security.Cryptography;
using System.Text.Json;

var parent = new LythonRuntime.ExecutionContext(new EmptyHost(), null);
var slots = new LythonRuntime.ExecutionContext[8192];
MakeFrames();
var before = GC.GetAllocatedBytesForCurrentThread();
MakeFrames();
var bytes = GC.GetAllocatedBytesForCurrentThread() - before;
GC.KeepAlive(slots);
Console.WriteLine(JsonSerializer.Serialize(new {
    coreSha256 = Convert.ToHexStringLower(SHA256.HashData(File.ReadAllBytes(typeof(LythonEngine).Assembly.Location))),
    count = slots.Length, bytes, bytesPerFrame = (double)bytes / slots.Length,
}));

void MakeFrames()
{
    for (var index = 0; index < slots.Length; index++)
        slots[index] = new LythonRuntime.ExecutionContext(parent, ScopeDirectiveFacts.Empty, nonlocalsAreCaptured: true);
}

sealed class EmptyHost : ILythonHost
{
    public string Cwd => "/";
    public DateTimeOffset LocalNow => throw new NotSupportedException();
    public DateTimeOffset UtcNow => throw new NotSupportedException();
    public ValueTask<bool> ExistsAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask<IReadOnlyList<string>> ListDirAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask MkDirAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask RemoveAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
    public ValueTask CopyAsync(LythonPathRequest source, LythonPathRequest destination, CancellationToken token) => throw new NotSupportedException();
    public ValueTask MoveAsync(LythonPathRequest source, LythonPathRequest destination, CancellationToken token) => throw new NotSupportedException();
    public ValueTask<LythonPathStat> StatAsync(LythonPathRequest path, CancellationToken token) => throw new NotSupportedException();
}
