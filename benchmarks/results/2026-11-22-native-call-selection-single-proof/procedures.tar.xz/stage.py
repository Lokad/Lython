from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import gzip,hashlib,json,os,shutil,statistics,subprocess,tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
out=lab/"comparison"
quiet=out/"quiet"
quiet.mkdir(parents=True,exist_ok=True)
previous=lab.parent/"factory-checkpoint-source-pair-20261122"/"comparison"
donor=lab.parent/"histogram-total-slots-20261122"/"comparison"
inspection=lab.parent/"module-leading-indentation-20261122"/"comparison"/"inspect-reference"
allocation=lab.parent/"deferred-word-binding-20261122"/"comparison"/"frozen-reference"
core="Lokad.Lython.dll"
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda b:hashlib.sha256(b).hexdigest()
def h(p):return sha(p.read_bytes())
def write(p,text):
    if p.suffix==".py":compile(text,str(p),"exec")
    p.write_text(text,encoding="utf-8",newline="\n")
def save(p,data):write(p,json.dumps(data,ensure_ascii=False,indent=2)+"\n")
def archive(directory,leaf):
    return subprocess.check_output(["git","show","origin/master:benchmarks/results/"+directory+"/"+leaf],cwd=repo)
def check_archive(directory):
    receipt=json.loads(archive(directory,"archive-receipt.json"))
    raw=archive(directory,"observations.tgz")
    assert all(receipt[key] for key in ("complete","allWorkersJoined","archivedAndVerifiedUnderLease"))
    assert sha(raw)==receipt["archiveSHA256"]
    return receipt
old_config=read(previous/"quiet/config.json")
source=old_config["source"]
reference=old_config["identity"]["candidate"]
base_core=old_config["sourceFiles"]
known=read(donor/"images.json")
assert len(base_core)==32 and base_core==known["imageFiles"]["reference"]
assert reference.startswith("55424591f")
ref_image=donor/"frozen-reference"
assert {name:h(ref_image/name) for name in base_core}==base_core
candidate_core=lab/"frozen-build/bin/Lokad.Lython/release_net11.0"/core
worktree=repo/".git/agent-worktrees/native-call-selection-single-proof-measured-20261122"
git=lambda *args:subprocess.check_output(["git",*args],cwd=repo)
candidate=git("-C",str(worktree),"rev-parse","HEAD").decode().strip()
assert candidate.startswith("b88d14745")
patch=git("diff","--binary",reference,candidate,"--","src","tests")
assert patch==git("diff","--binary","b5f0c0c18^","b5f0c0c18","--","src","tests")
(out/"source.patch").write_bytes(patch)
files={"reference":base_core,"candidate":{**base_core,core:h(candidate_core)}}
catalog=read(previous/"quiet/representative.json")
receipt=check_archive("2026-11-22-repeated-eager-annotations")
eager_raw=repo/"benchmarks/results/2026-11-22-repeated-eager-annotations/observations.tgz"
assert h(eager_raw)==receipt["archiveSHA256"]
with tarfile.open(eager_raw) as bundle:eager=json.load(bundle.extractfile("representative.json"))
by_id={c["id"]:c for c in eager["cases"]}
word,quotes=(catalog["cases"][i] for i in (1,2))
postponed=catalog["cases"][0]
assert postponed==by_id[postponed["id"]]
positional_dir="2026-11-22-json-positional-control"
positional_receipt=check_archive(positional_dir)
positional_archive=repo/"benchmarks/results"/positional_dir/"observations.tgz"
assert h(positional_archive)==positional_receipt["archiveSHA256"]
with tarfile.open(positional_archive) as bundle:
    control=json.load(bundle.extractfile("positional.json"))
positional=next(case for case in control["cases"] if case["id"]=="calls.positional.large")
ids=(postponed["id"],"scripts.annotated-rule-closures.nested-factories","scripts.factory-observed-defaults",
     "scripts.ordinary-fully-supplied-helper",quotes["id"],positional["id"])
catalog["cases"]=[postponed,*[by_id[s] for s in ids[1:4]],quotes,positional]
case_file=quiet/"representative.json"
save(case_file,catalog)
jobs=[(ids[0],"warm"),(ids[0],"compile-run"),*[(key,"warm") for key in ids[1:]]]
save(out/"jobs.json",jobs)
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
protocol=repo/"benchmarks/cpython-worker.py"
assert h(protocol)==old_config["protocolSHA256"]

def validate(role):
    image=out/("frozen-"+role)
    image.mkdir(exist_ok=True)
    for name in files[role]:
        shutil.copyfile(candidate_core if name==core and role=="candidate" else ref_image/name,image/name)
    assert {p.name:h(p) for p in image.iterdir()}==files[role]
    proof=out/(role+"-verify.json")
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",case_file,
        "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",proof],
        env=env,cwd=repo,check=True,timeout=100)
    verified=read(proof)
    assert verified["state"]=="Completed" and verified["caseCount"]==len(ids) and verified["catalogSha256"]==h(case_file)
    assert {p.name:h(p) for p in image.iterdir()}==files[role]
with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(validate,files))
tapes={}
for role in files:
    image=out/("frozen-"+role)
    inspect=out/("inspect-"+role)
    inspect.mkdir(exist_ok=True)
    for leaf in ("Inspect.dll","Inspect.deps.json","Inspect.runtimeconfig.json"):
        shutil.copyfile(inspection/leaf,inspect/leaf)
    shutil.copyfile(image/core,inspect/core)
    result=out/(role+"-tapes.json")
    subprocess.run([dotnet,inspect/"Inspect.dll",case_file,result],env=env,check=True,timeout=75)
    info=read(result)
    assert info["coreSHA256"]==files[role][core]
    tapes[role]=info["rows"]
assert tapes["reference"]==tapes["candidate"]
print("Matching executable code objects",sum(len(row["codes"]) for row in tapes["reference"]),flush=True)
old_root,old_unit=old_config["root"],old_config["unit"]
root=old_root.replace("factory-source-pair-b1412","native-call-selection-b1415")
unit=old_unit.replace("b1412-factory-source-pair","b1415-native-call-selection")
identity=dict(sourceRevision=reference+" versus "+candidate,reference=reference,candidate=candidate,
    testedRevision=git("rev-parse","b5f0c0c18").decode().strip(),
    imageFiles=files,purpose="Use one shared native function entry decision before work or default binding",
    normalAdapterPin="0.4.0", sourcePatchSHA256=sha(patch), protocolSHA256=h(protocol),
    coreSHA256={role+suffix:values[core] for role,values in files.items() for suffix in ("","-control")},
    catalogs={"representative.json":{"sha256":h(case_file)}})
save(quiet/"identity.json",identity)
(quiet/"candidate").mkdir(exist_ok=True)
shutil.copyfile(candidate_core,quiet/"candidate"/core)
for name in ("collect.py","run.sh","archive-owned.py","retrieve.py"):
    program=(previous/"quiet"/name).read_text(encoding="utf-8").replace(old_root,root).replace(old_unit,unit)
    program=program.replace("len(jobs)==4","len(jobs)==7").replace("len(raw['jobs'])==4","len(raw['jobs'])==7")
    program=program.replace("jobs=4,","jobs=7,").replace("['jobs']==4","['jobs']==7")
    if name=="collect.py":
        start,end=program.index("\njob_catalog = "),program.index("\nassert len(jobs)")
        program=program[:start]+"\njob_catalog = "+repr({case:case_file.name for case,_ in jobs})+"\njobs = "+repr(jobs)+program[end:]
        program=program.replace("started < 245","started < 410").replace("job_index % 2 != 0","job_index % 2 == 0")
    write(quiet/name,program)
assert b"\r" not in (quiet/"run.sh").read_bytes()
parts=("identity.json","representative.json","collect.py","run.sh","archive-owned.py","candidate/"+core)
payload=quiet/"payload.tgz"
with tarfile.open(payload,"w:gz") as bundle:
    for name in parts:bundle.add(quiet/name,arcname=name)
unpacked=sum((quiet/n).stat().st_size for n in parts)
prior_case="2026-11-21-shared-annotation-boundaries"
staging_receipt=check_archive(prior_case)
retired=repo/"benchmarks/results"/prior_case/"observations.tgz"
assert h(retired)==staging_receipt["archiveSHA256"]
with tarfile.open(retired) as bundle: retired_identity=json.load(bundle.extractfile("identity.json"))
old_file=lab.parent/"shared-annotation-boundaries/frozen/reference"/core
expected=retired_identity["imageFiles"]["reference"][core]
assert h(old_file)==expected and old_file.stat().st_size==5681664
proof=dict(paths=["shared-annotation-boundaries-b1259-20261121/reference/"+core],
           bytes=old_file.stat().st_size,links=1,sha256=expected,archives={})

config={**old_config,"root":root,"unit":unit,"identity":identity,"retireGroups":[proof],
        "payloadBytes":payload.stat().st_size,"payloadSHA256":h(payload),"unpackedBytes":unpacked}
save(quiet/"config.json",config)
launch=(previous/"quiet/remote-launch.py").read_text(encoding="utf-8")
start,end=launch.index("\nc=")+1,launch.index("\nb=Path(")
launch=(launch[:start]+"c="+repr(config)+launch[end:]).replace("b1412-fixtures","b1415-fixtures").replace("RuntimeMaxSec=290","RuntimeMaxSec=475")
write(quiet/"remote-launch.py",launch)
for name in ("launch.py","summarize.py"):
    program=(previous/name).read_text(encoding="utf-8").replace("seconds=255","seconds=422").replace("before 255 seconds","before 422 seconds")
    program=program.replace("Factory source pair","Native call selection").replace("len(raw['jobs'])==4","len(raw['jobs'])==7")
    write(out/name,program)
