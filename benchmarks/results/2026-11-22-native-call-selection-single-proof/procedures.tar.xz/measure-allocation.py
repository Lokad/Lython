from pathlib import Path
import hashlib,json,os,shutil,statistics,subprocess
lab=Path(__file__).resolve().parent
out=lab/"comparison"
catalog=out/"quiet/representative.json"
read=lambda p:json.loads(p.read_text(encoding="utf-8-sig"))
identity=read(out/"quiet/identity.json")
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(catalog)==identity["catalogs"][catalog.name]["sha256"]
sdk=Path.home()/".dotnet11"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
allocation=lab.parent/"deferred-word-binding-20261122/comparison/frozen-reference"
results=[]
for role,manifest in identity["imageFiles"].items():
    source=out/("frozen-"+role)
    assert {name:sha(source/name) for name in manifest}==manifest
    image=out/("allocation-"+role)
    image.mkdir(exist_ok=True)
    for name in manifest:shutil.copyfile(source/name,image/name)
    for suffix in (".dll",".deps.json",".runtimeconfig.json"):
        name="ValidatedAllocation"+suffix
        shutil.copyfile(allocation/name,image/name)
    report=out/(role+"-allocation.json")
    subprocess.run([sdk/"dotnet.exe",image/"ValidatedAllocation.dll",image,catalog,report],
        env=env,check=True,timeout=80)
    raw=read(report)["rows"]
    assert len(raw)==len(read(catalog)["cases"]) and all(r["sharedBudgetBaselineRestored"] for r in raw)
    results.append(raw)
    assert {name:sha(image/name) for name in manifest}==manifest
for a,b in zip(*results,strict=True):
    assert a["id"]==b["id"]
    left,right=[statistics.median(r["allocatedBytesPerInvocation"]) for r in (a,b)]
    print(a["id"],left,right,a["peakExecutionMemoryBytes"],b["peakExecutionMemoryBytes"],flush=True)
