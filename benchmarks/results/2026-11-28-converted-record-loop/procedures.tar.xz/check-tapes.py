from hashlib import sha256
from pathlib import Path
from tempfile import TemporaryDirectory
import json
import os
import re
import subprocess
from shutil import copyfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
pair=lab/"comparison"
read=lambda p:json.loads(p.read_bytes())
hash=lambda p:sha256(p.read_bytes()).hexdigest()
identity=read(pair/"identity.json")
specimen=(repo/"tests/Lokad.Lython.PublicApi.Tests/ConvertedDictionaryUpdateTests.cs").read_text(encoding="utf-8")
snippet=re.search(r"RecordLoopPreservesPartialBindingsAndResumesDynamicRows\(\).*?const string source = \"\"\"\n(.*?)\n {12}\"\"\";",specimen,re.S)
assert snippet
source="\n".join(line[12:] for line in snippet[1].splitlines())+"\n"
with TemporaryDirectory() as cwd:
    (Path(cwd)/"quantity.txt").write_text("7",encoding="utf-8")
    result=subprocess.run(["C:/Python313/python.exe","-I","-S","-X","utf8","-"],
        input=source.encode(),cwd=cwd,capture_output=True,check=True,timeout=30)
assert result.stdout.decode().replace("\r\n","\n")=="read service\nread details\n({'same': 10, 'dynamic': 7}, 'missing', '5')\n"
assert not result.stderr
(lab/"reference-python.log").write_bytes(result.stdout)
cases=read(pair/"representative.json")["cases"]
files=[dict(id=c["id"],source=c["source"]) for c in cases]+[dict(id="mixed-rows",source=source)]
cat=lab/"full-tape-input.json"
cat.write_text(json.dumps({"cases":files},indent=2,ensure_ascii=False)+"\n",encoding="utf-8",newline="\n")
sdk=Path.home()/".dotnet11"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk))
rows=[]
for role in ("reference","candidate"):
    folder=lab/("probe-"+role)
    assert {x.name:hash(x) for x in (pair/role).iterdir()}==identity["imageFiles"][role]
    assert hash(folder/"Lokad.Lython.dll")==identity["imageFiles"][role]["Lokad.Lython.dll"]
    out=lab/(role+"-full-tape.json")
    subprocess.run([sdk/"dotnet.exe",folder/"CompilerFacts.dll",cat,out],env=env,cwd=folder,check=True,timeout=55)
    rows.append(read(out))
summary=[]
for a,b in zip(*rows,strict=True):
    for key in ("id","peak","growth","testLimits","refusals"):
        assert a[key]==b[key],(a["id"],key)
    differences=[]
    for left,right in zip(a["tape"],b["tape"],strict=True):
        assert {k:v for k,v in left.items() if k!="steps"}=={k:v for k,v in right.items() if k!="steps"}
        for index,(x,y) in enumerate(zip(left["steps"],right["steps"],strict=True)):
            if x!=y:
                assert x["op"]=="ForNext" and y["op"]=="ForNextDictionaryAccumulation"
                differences.append(dict(function=left["name"],index=index,before=x,after=y))
    summary.append(dict(id=a["id"],budgetLevels=len(a["testLimits"]),marked=differences))
    print(a["id"],len(differences),"marked loops",len(a["testLimits"]),"budget levels")
assert [len(r["marked"]) for r in summary[:5]]==[1,0,0,0,1]
assert all(not row["marked"] for row in summary[5:])
(lab/"tape-summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8",newline="\n")
