from pathlib import Path
import os,subprocess,sys
r=Path(__file__).parent;phase=sys.argv[1]
env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';'+env['PATH']
for target in ['net11.0','net10.0']:
    path=r/(phase+'-new-'+target+'.log')
    with path.open('wb')as log:done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe','test','tests/Lokad.Lython.PublicApi.Tests/Lokad.Lython.PublicApi.Tests.csproj','-c','Release','-f',target,'--no-restore','--filter','FullyQualifiedName~WhileHelperExecutionTests','--logger','trx;LogFileName='+phase+'-'+target+'.trx','--results-directory',str((r/(phase+'-'+target)).resolve())],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=120)
    print(phase,target,done.returncode,path.read_text(encoding='utf-8')[-2400:],flush=True)
    assert done.returncode==0
