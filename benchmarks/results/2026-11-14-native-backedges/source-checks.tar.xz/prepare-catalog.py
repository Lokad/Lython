from pathlib import Path
import base64,copy,csv,hashlib,io,json,struct,subprocess,tempfile
r=Path(__file__).parent
old=json.loads((r.parent/'checkpoint-cpython-r332/b704/catalog.json').read_text(encoding='utf-8'))
control=next(c for c in old['cases']if c['id']=='scripts.csv-invoice.large')
buffer=io.StringIO(newline='');writer=csv.writer(buffer,lineterminator='\n');writer.writerow(['code','group'])
for i in range(4096):writer.writerow([10000000+(i*15485863)%89999999,'g'+str(i%8)])
data=buffer.getvalue().encode()
source="""import csv

def digit_sum(value):
    total=0
    while value>0:
        total+=value%10
        value//=10
    return total

totals={}
count=0
with open('input.csv',newline='') as source:
    for row in csv.DictReader(source):
        check=digit_sum(int(row['code']))
        group=row['group']
        totals[group]=totals.get(group,0)+check
        count+=1
with open('report.csv','w',newline='') as target:
    writer=csv.writer(target,lineterminator='\\n')
    writer.writerow(['group','digit_sum'])
    for group in sorted(totals): writer.writerow([group,totals[group]])
print(count,sum(totals.values()))
"""
with tempfile.TemporaryDirectory(prefix='while-csv-control-',dir=r.resolve())as folder:
    work=Path(folder).resolve();assert work.parent==r.resolve()
    (work/'input.csv').write_bytes(data)
    done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],cwd=work,capture_output=True,text=True,encoding='utf-8',timeout=15)
    assert done.returncode==0 and not done.stderr,done.stderr
    output=(work/'report.csv').read_bytes();assert(work/'input.csv').read_bytes()==data
fixture=dict(size=4096,text=None,inputFiles={'input.csv':base64.b64encode(data).decode()},outputFiles={'report.csv':base64.b64encode(output).decode()})
c=copy.deepcopy(control);c.update(id='scripts.csv-check-digits.large',size=4096,source=source,fixtureJson=json.dumps(fixture,separators=(',',':'),ensure_ascii=False),expectedOutput=done.stdout,sourceUtf8Bytes=len(source.encode()),expectedOutputUtf8Bytes=len(done.stdout.encode()),fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,sourceSha256=hashlib.sha256(source.encode()).hexdigest(),expectedOutputSha256=hashlib.sha256(done.stdout.encode()).hexdigest())
c['fixtureSha256']=hashlib.sha256(c['fixtureJson'].encode()).hexdigest()
name=b'report.csv';c['expectedFilesSha256']=hashlib.sha256(struct.pack('>i',1)+struct.pack('>i',len(name))+name+struct.pack('>i',len(output))+output).hexdigest()
old['cases']=[c,control]
(r/'catalog.json').write_text(json.dumps(old,separators=(',',':'),ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
(r/'workload-python-controls.json').write_text(json.dumps(dict(reference='CPython3.13.2 isolated',case=c['id'],sourceSHA256=c['sourceSha256'],fixtureSHA256=c['fixtureSha256'],inputBytes=len(data),stdout=done.stdout,outputBytes=len(output),unchangedInput=True,control=control['id'],sameSourcesAcrossRevisions=True),indent=2)+'\n',encoding='utf-8',newline='\n')
print('Complete4096-row CSV validation/report and unchanged invoice control prepared; exact CPython stdout/files, no timing claim.',flush=True)
