from pathlib import Path
import ast,hashlib,json,tarfile
r=Path(__file__).parent
prior=r.parent/'xml-iterparse-r335'
source=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert json.loads((r/'inspection.json').read_text(encoding='utf-8'))['unchangedInvoiceFacts']
# Reuse the independent frozen-worker/golden verification, with identical guest
# sources across the pair. These files are diagnostics, not a new worker protocol.
s=(prior/'verify-worker.py').read_text(encoding='utf-8')
s=s.replace("[('reference',0),('candidate',1),('reference',2),('candidate',2)]","[('reference',0),('candidate',0),('reference',1),('candidate',1)]")
ast.parse(s);(r/'verify-worker.py').write_text(s,encoding='utf-8',newline='\n')
for role in ['reference','candidate']:(r/('allocation-'+role+'-catalog.json')).write_bytes((r/'catalog.json').read_bytes())
(r/'measure-allocation.py').write_bytes((r.parent/'utf8-byte-ownership-r334/measure-allocation.py').read_bytes())
out=r/'b708';out.mkdir()
aux=json.loads((prior/'b706/identity.json').read_text(encoding='utf-8'))['candidateAuxiliaryFiles']
assert all(source['auxiliaryFiles'][role][name]==sha for role in ['reference','candidate']for name,sha in aux.items())
identity=dict(sourceRevision='R338 frozen'+source['coreSHA256']['candidate'][:8]+' vs fully qualified R335/cdd92944 frozenf4c4f027',purpose='Same-source complete CSV check-digit validation/report: warm and compile-to-result, with unchanged invoice control. Remove blanket native-prefix backedge exclusion; no external timing claim.',coreSHA256={label:source['coreSHA256']['candidate'if label.startswith('candidate')else'reference']for label in ['reference','candidate','reference-control','candidate-control']},candidateAuxiliaryFiles=aux,referenceAuxiliaryFiles=aux,catalogSHA256=hashlib.sha256((r/'catalog.json').read_bytes()).hexdigest(),referenceCase='scripts.csv-check-digits.large',variantCase='scripts.csv-check-digits.large',controlCase='scripts.csv-invoice.large',sourceAndScriptDifferIntentionally=False)
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
oldroot='/home/lokad/lython-bench-checks/xml-iterparse-b706-20261114'
root='/home/lokad/lython-bench-checks/native-backedges-b708-20261114'
unit='lython-b708-native-backedges-20261114'
jobs=[['scripts.csv-check-digits.large','warm'],['scripts.csv-check-digits.large','compile-run'],['scripts.csv-invoice.large','warm']]
for name in ['collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py','launch.py']:
    s=(prior/'b706'/name).read_text(encoding='utf-8').replace(oldroot,root).replace('lython-b706-xml-iterparse-20261114',unit).replace('B706','B708')
    if name=='collect.py':
        a=s.index('jobs=');b=s.index('\nenv =',a)
        s=s[:a]+'jobs='+repr(jobs)+'\nassert len(jobs)==3 and all(case in cases for case,lane in jobs)\n'+s[b:]
    if name=='summarize.py':
        s=s.replace('sourceAndScriptDifferIntentionally=True','sourceAndScriptDifferIntentionally=False')
        s=s.replace('No external timing; two distinct source algorithms have isolated CPython3.13.2 exact file/stdout goldens. Control has identical guest source.','No external timing; the identical complete CSV script has isolated CPython3.13.2 stdout/files goldens.')
    if name.endswith('.py'):ast.parse(s)
    (out/name).write_text(s,encoding='utf-8',newline='\n')
with tarfile.open(out/'payload.tgz','w:gz')as t:
    for name in ['identity.json','collect.py','archive-owned.py','run.sh']:t.add(out/name,arcname=name)
    for name,arc in [('catalog.json','representative.json'),('candidate-core.dll','candidate-core.dll'),('reference-core.dll','reference-core.dll'),('candidate-identity.json','source-identity.json'),('reference-identity.json','reference-source-identity.json')]:t.add(r/name,arcname=arc)
with tarfile.open(out/'payload.tgz')as t:unpacked=sum(m.size for m in t.getmembers())
config=dict(root=root,sourceRoot='/home/lokad/lython-bench-checks/current-external-b704-20261113',unit=unit,identity=identity,payloadBytes=(out/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((out/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=unpacked)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Prepared one three-job300s owner; same sources and fixed workers, two processes/revision/job; reused allocation diagnostic.',flush=True)
