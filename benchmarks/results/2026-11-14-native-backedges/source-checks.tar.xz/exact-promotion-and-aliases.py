def grow(value,n):
    first=value
    i=0
    while i<n:
        value=value*3+1
        i+=1
    alias=value
    return first,value,alias is value
print(grow(9223372036854775807,3))
def divide(n):
    value=-17
    while n>0:
        value=value//3
        n-=1
    return value
print(divide(3))
