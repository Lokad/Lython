def keep(n):
    i=0
    first=None
    while i<n:
        items=[i,i+1]
        if i==0: first=items
        i+=1
    return first,items
first,last=keep(4)
print(first,last,first is last)
first.append(99)
print(first,last)
