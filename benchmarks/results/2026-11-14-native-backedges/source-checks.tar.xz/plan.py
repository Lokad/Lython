from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).parent
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')
(r/'PLAN-before-r338.md').write_bytes(p.read_bytes())
marker='2. **R336 phase gate complete; choose the next coherent removal from owning work.**'
assert marker in s
block='''2. **R338 active: remove the blanket backward-branch exclusion from native prefixes.**
   Source proves NativeExecution already executes Jump/JumpIfFalse/CompareJump and
   checks current cancellation/refusal on every instruction, but CanInlineInstructions
   rejects every backward branch. Numeric while helpers therefore allocate ordinary
   binding/frame/work storage even when every opcode is already supported. Hypothesis:
   use the same prefix for these loops to remove complete per-call materialization,
   not a new loop optimizer/arena, typed-value VM or numeric special case. Delete the
   separate backward-edge eligibility scan; keep opcode/value-capacity/exception/
   closure restrictions, logical calls, managed-stack admission and exact promotion.
   Native-prefix dispatch remains object-valued; no unboxed-local representation is
   selected. No speedup forecast follows from source alone.
   Acceptance: while/else/break/continue, loop-carried locals and big-integer promotion,
   unbound/error order, aliases, closure/nonlocal writes, real async host work reached
   after iterations without replay, cancellation of nonallocating loops, terminal
   memory refusal and cleanup/shared-budget reuse. Existing small-stack/recursion
   regressions remain. Compare complete CSV check-digit/validation warm and compile-
   to-result jobs against the exact qualified f4 reference with unchanged invoice
   control, fixed workers/two fresh processes and all file/stdout/allowance gates.
   Use existing short allocation diagnostics only if needed to quantify the eliminated
   frame storage. Preserve all adverse observations. Stop after usable semantic,
   ownership, cancellation and affected/control evidence plus a debt decision; do not
   add support for unrelated opcodes or expand the prefix into a new engine. Batch
   full platform/stress/package qualification only at retained delivery.

3. **R336 phase gate complete; choose further removals from owning work.**'''
s=s.replace(marker,block).replace('3. **Select substantive redesigns','4. **Select substantive redesigns').replace('4. **Regex is an independent','5. **Regex is an independent')
p.write_text(s,encoding='utf-8',newline='\n')
prior=r.parent/'xml-iterparse-r335'
identity=json.loads((prior/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in identity['sources'].items())
assert json.loads((prior/'delivery/ci-terminal.json').read_text(encoding='utf-8'))['conclusion']=='success'
for name in ['candidate-core.dll','candidate-sources.tar.xz']:
    shutil.copyfile(prior/name,r/name.replace('candidate','reference'))
shutil.copytree(prior/'candidate',r/'reference')
reference=dict(head='cdd929449305211acc346b9a4617da3152deb80a',coreSHA256=identity['coreSHA256']['candidate'],sources=identity['sources'],productionFiles=len(identity['sources']),auxiliaryFiles=identity['auxiliaryFiles']['candidate'],qualified=True,qualification='GREEN43536449801, both platforms/actual11/10, original stress and installed consumers')
(r/'reference-identity.json').write_text(json.dumps(reference,indent=2)+'\n',encoding='utf-8',newline='\n')
print('R338 pre-code design recorded; exact qualified f4 reference copied before edits. No new engine or representation.',flush=True)
