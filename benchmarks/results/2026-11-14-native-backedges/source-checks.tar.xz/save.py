from pathlib import Path
import hashlib,json,re,shutil,tarfile
r=Path(__file__).parent
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==sha for p,sha in identity['sources'].items())
allocation=json.loads((r/'allocation-summary.json').read_text(encoding='utf-8'))
timing=json.loads((r/'b708/summary.json').read_text(encoding='utf-8'))
receipt=json.loads((r/'b708/archive-receipt.json').read_text(encoding='utf-8'))
assert timing['complete']and timing['jobs']==3 and receipt['allWorkersJoined']and receipt['guestFixturesRemoved']
assert hashlib.sha256((r/'b708/observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
counts={}
for assembly in ['Lokad.Lython.Tests','Lokad.Lython.PublicApi.Tests']:
    for target in ['net11.0','net10.0']:
        name=assembly+'-'+target+'.log';text=(r/name).read_text(encoding='utf-8')
        match=re.search(r'Passed!.*?Failed:\s+0, Passed:\s+(\d+)',text);assert match,name
        counts[name]=int(match[1])
assert list(counts.values())==[637,637,1551,1551]
out=Path('benchmarks/results/2026-11-14-native-backedges');out.mkdir()
for name in ['candidate-identity.json','reference-identity.json','workload-python-controls.json','python-controls.json','worker-verification.json','inspection.json','allocation-summary.json','focused-checks.json','hypothesis-correction.json']:shutil.copyfile(r/name,out/name)
for name in ['summary.json','archive-receipt.json','terminal-status.json','observations.tgz']:shutil.copyfile(r/'b708'/name,out/name)
with tarfile.open(out/'source-checks.tar.xz','w:xz')as t:
    for name in ['plan.py','PLAN-before-r338.md','PLAN-before-allocation-correction.md','reference-core.dll','reference-sources.tar.xz','freeze-candidate.py','candidate-build.log','candidate-core.dll','candidate-sources.tar.xz','python-controls.py','prepare-catalog.py','catalog.json','check-new.py','check-related.py','inspect.py','prepare-measurements.py','verify-worker.py','measure-allocation.py','allocation-reference-catalog.json','allocation-candidate-catalog.json','correct-hypothesis.py','save.py']+list(counts):t.add(r/name,arcname=name)
    for pattern in ['reference-new-*.log','candidate-new-*.log','probe-build-*.log','*.stdout','*.stderr','reference-allocation-*.*','candidate-allocation-*.*']:
        for p in r.glob(pattern):t.add(p,arcname=p.name)
    for p in r.glob('**/*.trx'):t.add(p,arcname=p.relative_to(r).as_posix())
    for name in ['inspection/Program.cs','inspection/Inspection.csproj']:t.add(r/name,arcname=name)
    for name in ['loop-control-and-carried-locals','nested-loops-and-return','exact-promotion-and-aliases','nonlocal-writes-and-final-values','late-locals-observation-and-error-order','loop-storage-aliases-survive-promotion']:t.add(r/(name+'.py'),arcname=name+'.py')
    for name in ['tests/Lokad.Lython.PublicApi.Tests/WhileHelperExecutionTests.cs','tests/Lokad.Lython.PublicApi.Tests/RecursionDepthScenarioTests.cs']:t.add(name,arcname=name)
    for name in ['identity.json','config.json','collect.py','archive-owned.py','run.sh','retrieve.py','summarize.py','launch.py','launch-command.py','launch.log','observe-not-before.json','extraction.json']:t.add(r/'b708'/name,arcname='b708/'+name)
    for name in ['Program.cs','Allocation.csproj']:t.add(r.parent/'word-buffer-loan-r324/allocation'/name,arcname='allocation-tool/'+name)
    for p in(r/'reference').glob('Allocation.*'):t.add(p,arcname='allocation-tool/'+p.name)
table='| Complete script / phase | Elapsed change | Wider CPU change | Process spread candidate/reference | Max IQR |\n| --- | ---: | ---: | ---: | ---: |\n'
for row in timing['timing']:
    elapsed=row['lythonSourcePairElapsedPercent'];cpu=row['lythonSourcePairWiderCpuPercent']
    table+=f"|{row['case'].removeprefix('scripts.')} /{row['lane']}|{min(elapsed):+.2f}..{max(elapsed):+.2f}%|{min(cpu):+.2f}..{max(cpu):+.2f}%|{row['candidateProcessSpreadPercent']:.2f}/{row['referenceProcessSpreadPercent']:.2f}%|{max(row['iqrPercent'].values()):.2f}%|\n"
(out/'README.md').write_text(f'''# Native-prefix backward branches

2026-11-14UTC, R338fro zene2482e0b over fully qualified R335cdd92944/frozenf4c4f027.
**Retain the eligibility deletion for the demonstrated whole-script CPU gain.**
637internal/1551public focused Release cases pass per actual.NET11/10; full retained
platform/stress/installed-consumer delivery is pending at the coherent eligibility
checkpoint. Publication/tagging remain postponed.

The native executable loop already supports Jump/conditional branches and checks
current cancellation/refusal before every instruction. Remove the separate
backward-branch exclusion from compiler eligibility. Existing opcode, capacity,
exception, lexical and managed-stack protections stay; unsupported operations
transfer their exact PC and live values through the existing continuation. No new
optimizer, engine, arena, typed-value representation, policy or public option.

The initial claim that this removes per-call frame allocation was **incorrect**.
BeginBoundCall already uses the ordinary deferred instruction prefix without a
materialized context for this loop. The original pre-code plan and its explicit
[correction](hypothesis-correction.json) survive. The change selects the smaller
native dispatch rather than proving a large storage removal. Four allocation
processes show5131631–5131635B versus5131559B per complete4096-row script:
only72–76B, effectively flat. Invoice control is flat. No heap/RSS/tail gain follows.

## Semantic and ownership validation

Six isolated CPython3.13.2 controls preserve while/else/break/continue, nested
loops, integer promotion, aliases, nonlocal writes, late locals observation and
error order. Initial11new cases pass on both reference and candidate Release11/10;
the expanded suite includes13new public cases. Actual I/O after native iterations
occurs once; cancellation joins cleanup and restores the shared allowance.
An empty nonallocating loop remains cancellable. Retained formatted results from
two executions stay funded. Native recursion crosses the existing continuation;
deep while recursion is checked in the isolated probe, built for each target.
All4376related checks pass; original stress scales remain for delivery.

Independent frozen-core inspection shows the exact same11instructions/6slots/
one backward branch for digit_sum: native=False at f4, True at e248. Invoice
function facts are unchanged. Each worker independently verifies exact complete
file/stdout goldens and accounting reuse before timing.

## One bounded affected/control comparison

{table}
B708finishes{timing['elapsedSeconds']:.3f}s under one300s owner, quiet AzureF4as_v7/
Ubuntu24.04.4/.NET11RC3, ordinary workstation GC/tiering, fixed B685worker and
optional adapter0.4. Two fresh processes per revision/job, eight-second full-request
wall warmups and five rotating0.5s wall-sized batches. Guest source, fixtures,
outputs and auxiliary worker/adapter bytes are identical across revisions.

The complete4096-row CSV job parses codes, runs a numeric digit-sum while helper,
aggregates eight groups and writes a checked report. Warm reference8.269–8.485ms
versus6.830–6.861ms; compile-run8.213–8.320ms versus6.924–6.998ms. Supporting wider
CPU direction is15–19%warm and15.5–16.9%fresh. Retain this affected-workload result,
not a universal runtime or CPython speedup. Invoice control spans−0.48..+1.63%
elapsed/−0.48..+1.52%wider CPU with1.75%candidate spread: small regression debt
remains uncertainty, not proved neutrality. All raw/adverse points survive; no
unchanged retiming is needed for this bounded retention decision.

Warm guest clocks include mediated RAM-file I/O, full stdout/file validation and
prior-result cleanup; compilation/startup, fixture reset/protocol and final caches
are excluded. Compile-to-result adds compilation/compiled-owner disposal. Wider
CPU includes reset/protocol. Ranges span process medians, not confidence intervals.
The separate desktop allocation diagnostic includes reset/checks/cleanup and uses
CLR process-wide counters with no forced GC or timing claim. No external timing,
allocation percentage, embedding-tail or safety relaxation is inferred.

All identity/golden/balance/quiet/join/archive gates pass. No VM users or RAM
fixtures remain; persistent evidence SHA verifies. No evidence/image is retired
and no disk floor is relaxed. Further operand/call consolidation remains separate;
this useful source deletion does not complete the performance objective.

[Timing/wider CPU](summary.json), [allocation](allocation-summary.json),
[inspection](inspection.json), [raw](observations.tgz),
[exact frozen sources/bits, prospective conditions and checks](source-checks.tar.xz).
'''.replace('R338fro zen','R338frozen'),encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md')
with p.open('a',encoding='utf-8',newline='\n')as f:f.write('''
## R338 — native-prefix backward branches

[Retained source pair](results/2026-11-14-native-backedges/README.md) deletes the
blanket backward-edge eligibility scan. Existing native dispatch, current-token/
refusal checks and exact continuation serve numeric while helpers. The initial
per-call allocation explanation is corrected: the ordinary engine already defers
context materialization. Allocation is effectively flat; originals remain.
637internal/1551public focused cases pass each actual11/10, plus six independent
Python controls. B708three jobs/141.481s/all gates: complete4096-row CSV validation
warm−19.50..−17.03%, fresh−16.78..−14.80%, with wider CPU support. Invoice control
−0.48..+1.63% and1.75%candidate spread remain uncertainty. No universal/CPython gain
or large storage claim. Full delivery is batched at the coherent eligibility
checkpoint; publication held. Broader performance/operand work remains active.
''')
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')
s=s.replace('| Active uncommitted runtime prototypes | None. R335 is committed and fully qualified; focused correctness, B706timing and B707phase observations remain separate evidence. |', '| Retained uncommitted runtime prototype | R338e2482e0b over qualifiedf4 removes native backedge exclusion.637internal/1551public focused cases each actual11/10; B708three jobs/141.481s/all gates. CSV validation warm−17..−19.5%, fresh−14.8..−16.8%, wider CPU support; allocation effectively flat. Invoice control−0.48..+1.63% remains uncertainty. Full delivery pending coherent eligibility checkpoint. [Evidence](benchmarks/results/2026-11-14-native-backedges/README.md). |')
s=s.replace('**R338 active:', '**R338 retained; focused qualified:')
s=s.replace('   full platform/stress/package qualification only at retained delivery.', '   full platform/stress/package qualification at the coherent eligibility delivery.\n   B708complete141.481s/all gates: CSV warm−17..−19.5%, fresh−14.8..−16.8% with\n   wider CPU support. Allocation flat. Invoice−0.48..+1.63%/candidate spread1.75%\n   remains uncertainty.637internal/1551public per actual11/10 pass. Retain deletion\n   with explicit control debt; no external or large-storage improvement claim.')
p.write_text(s,encoding='utf-8',newline='\n')
print('Saved R338 exact sources/checks/B708, allocation correction and retention/debt decision; full delivery remains separate.',flush=True)
