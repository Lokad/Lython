def compute(n):
    i=0
    total=0
    while i<n:
        j=0
        while j<i:
            total+=i*10+j
            j+=1
        i+=1
    return total
print([compute(n) for n in [0,1,2,4]])
