from pathlib import Path
import hashlib,json,re,subprocess,textwrap
r=Path(__file__).parent
s=Path('tests/Lokad.Lython.PublicApi.Tests/WhileHelperExecutionTests.cs').read_text(encoding='utf-8')
cases=re.findall(r'yield return \["([^"]+)", """\n(.*?)\n            """, "((?:\\.|[^"\\])*)"\];',s,re.S)
assert len(cases)==6,len(cases)
rows=[]
for name,body,target in cases:
    source=textwrap.dedent(body)+'\n';path=r/(name+'.py');path.write_text(source,encoding='utf-8',newline='\n')
    done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8',str(path.resolve())],capture_output=True,text=True,encoding='utf-8',timeout=10)
    (r/(name+'.stdout')).write_text(done.stdout,encoding='utf-8',newline='\n');(r/(name+'.stderr')).write_text(done.stderr,encoding='utf-8',newline='\n')
    expected=json.loads('"'+target+'"')
    row=dict(name=name,sourceSHA256=hashlib.sha256(source.encode()).hexdigest(),returncode=done.returncode,exactOutput=done.stdout==expected);rows.append(row)
    print(name,row['exactOutput'],done.returncode,flush=True)
    assert row['exactOutput']and not done.returncode,(done.stdout,expected,done.stderr)
(r/'python-controls.json').write_text(json.dumps(dict(reference='CPython3.13.2 isolated',cases=rows),indent=2)+'\n',encoding='utf-8',newline='\n')
