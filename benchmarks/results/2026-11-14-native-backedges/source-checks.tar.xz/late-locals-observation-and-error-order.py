def observe(n):
    i=0
    total=0
    while i<n:
        total+=i
        i+=1
    return locals()
values=observe(4)
print(values['n'],values['i'],values['total'])
def error(n,divisor):
    i=0
    while i<n:
        i+=1
        value=10//divisor
    return value
for n,d in [(2,0),(0,0),(2,2)]:
    try: print(error(n,d))
    except ZeroDivisionError: print('zero')
    except UnboundLocalError: print('unbound')
