from pathlib import Path
import hashlib,json,os,shutil,subprocess
r=Path(__file__).parent
env=dict(os.environ);env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11'
tool=r/'inspection/bin/Release/net11.0'
identity=json.loads((r/'candidate-identity.json').read_text(encoding='utf-8'))
for role in ['reference','candidate']:
    folder=r/('inspect-'+role);folder.mkdir()
    for file in tool.iterdir():
        if file.is_file():shutil.copyfile(file,folder/file.name)
    shutil.copyfile(r/role/'Lokad.Lython.dll',folder/'Lokad.Lython.dll')
    assert hashlib.sha256((folder/'Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256'][role]
    done=subprocess.run([env['DOTNET_ROOT']+'/dotnet.exe',str((folder/'Inspection.dll').resolve()),str((r/'catalog.json').resolve())],capture_output=True,env=env,timeout=30)
    (r/('inspection-'+role+'.stdout')).write_bytes(done.stdout);(r/('inspection-'+role+'.stderr')).write_bytes(done.stderr)
    assert done.returncode==0,done.stderr.decode('utf-8',errors='replace')
    data=json.loads(done.stdout)
    fn=next(f for c in data if c['id']=='scripts.csv-check-digits.large'for f in c['functions']if f['name']=='digit_sum')
    assert fn['backwardBranches']>0 and fn['native']==(role=='candidate'),fn
    print(role,fn,flush=True)
before=json.loads((r/'inspection-reference.stdout').read_text(encoding='utf-8'))
after=json.loads((r/'inspection-candidate.stdout').read_text(encoding='utf-8'))
assert next(c for c in before if c['id']=='scripts.csv-invoice.large')==next(c for c in after if c['id']=='scripts.csv-invoice.large')
(r/'inspection.json').write_text(json.dumps(dict(sourceAndScriptIdentical=True,qualifiedReferenceCore=identity['coreSHA256']['reference'],candidateCore=identity['coreSHA256']['candidate'],reference=before,candidate=after,unchangedInvoiceFacts=True),indent=2)+'\n',encoding='utf-8',newline='\n')
