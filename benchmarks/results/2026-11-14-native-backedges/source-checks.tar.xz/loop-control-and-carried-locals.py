def count(n):
    i=0
    total=0
    while i<n:
        i+=1
        if i==2: continue
        if i==5: break
        total+=i
    else: total+=100
    return i,total
print([count(n) for n in [-1,0,1,3,8]])
