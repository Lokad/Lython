def outer():
    total=3
    def add(n):
        nonlocal total
        while n>0:
            total+=n
            n-=1
        return total
    print(add(3),add(2),total)
outer()
