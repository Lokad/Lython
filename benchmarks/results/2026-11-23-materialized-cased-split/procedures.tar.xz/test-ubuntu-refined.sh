#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/materialized-cased-split-20261123
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
export DOTNET_HOST_PATH="$DOTNET_ROOT/dotnet"
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/materialized-cased-split-20261123
filter='Category!=Stress&(FullyQualifiedName~Split|FullyQualifiedName~Casing|FullyQualifiedName~StringWindow|FullyQualifiedName~WordBufferLoan|FullyQualifiedName~DictionaryCountingLoop|FullyQualifiedName~DictionaryAccumulationLifetime|FullyQualifiedName~NativeReturnFunction|FullyQualifiedName~NativeConditionalHelper|FullyQualifiedName~CapturedScalarObservation|FullyQualifiedName~CooperativeCancellation|FullyQualifiedName~ManagedStackGuard)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --artifacts-path "$lab/ubuntu-refined" --filter "$filter" > "$lab/white-refined-ubuntu.log" 2>&1 || { tail -38 "$lab/white-refined-ubuntu.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --artifacts-path "$lab/ubuntu-refined" --filter "$filter" > "$lab/public-refined-ubuntu.log" 2>&1 || { tail -38 "$lab/public-refined-ubuntu.log"; exit 1; }
awk '/Passed!/{count++;print} END{exit count!=2}' "$lab/white-refined-ubuntu.log" "$lab/public-refined-ubuntu.log"

dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --no-build --artifacts-path "$lab/ubuntu-refined" --filter 'Category=Stress&FullyQualifiedName~NativeTextConstructionRollback' > "$lab/stress-ubuntu.log" 2>&1 || { tail -38 "$lab/stress-ubuntu.log"; exit 1; }
awk '/Passed!/{count++;print} END{exit count!=1}' "$lab/stress-ubuntu.log"
