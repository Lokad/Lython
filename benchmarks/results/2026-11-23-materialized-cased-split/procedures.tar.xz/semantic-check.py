
from pathlib import Path
import hashlib
import json
import os
import subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
comparison=lab/"comparison-refined"
out=lab/"semantic"
out.mkdir()
source=(lab/"casing-corpus.py").read_text(encoding="utf-8")
python=Path("C:/Python313/python.exe")
result=subprocess.run([python,"-I","-S","-X","utf8","-c",source],check=True,capture_output=True,timeout=15)
assert not result.stderr
expected=result.stdout.decode("utf-8").replace("\r\n","\n")
sha=lambda b:hashlib.sha256(b).hexdigest()
def digest(s):return sha(s.encode("utf-8"))
fixture='{"size":1,"text":null}'
identity=json.loads((comparison/"identity.json").read_text(encoding="utf-8"))
catalog=json.loads((comparison/"representative.json").read_text(encoding="utf-8"))
case=dict(id="scripts.cased-list-utf8-boundaries",family="scripts",category="whole-script",scale="small",size=1,source=source,
    fixtureJson=fixture,expectedOutput=expected,sourceUtf8Bytes=len(source.encode("utf-8")),expectedOutputUtf8Bytes=len(expected.encode("utf-8")),
    fixtureTextUtf8Bytes=0,fixtureTextCodePoints=0,sourceSha256=digest(source),fixtureSha256=digest(fixture),expectedOutputSha256=digest(expected))
manifest=out/"catalog.json"
manifest.write_text(json.dumps({**catalog,"cases":[case]},ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
protocol=repo/"benchmarks/cpython-worker.py"
assert sha(protocol.read_bytes())==identity["protocolSHA256"]
for role in ("reference","candidate"):
    image=comparison/f"frozen-{role}"
    expected_image=identity["imageFiles"][role]
    assert {n:sha((image/n).read_bytes())for n in expected_image}==expected_image
    proof=out/f"{role}-verify.json"
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",manifest,
        "--dotnet",dotnet,"--python",python,"--python-worker",protocol,"--out",proof],env=env,cwd=repo,check=True,timeout=45)
    response=json.loads(proof.read_text(encoding="utf-8"))
    assert response["state"]=="Completed" and response["caseCount"]==1
print(len(expected.encode("utf-8")), "verified output bytes")

