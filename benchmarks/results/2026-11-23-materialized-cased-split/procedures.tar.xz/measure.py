from pathlib import Path
import base64
import hashlib
import importlib.util
import json
import os
import shutil
import statistics
import subprocess
import tempfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
tree = repo / ".git/agent-worktrees/materialized-cased-split-20261123"
before = lab.parent / "body-signature-20261123"
previous = lab.parent / "direct-bound-integer-refined-20261123" / "comparison"
out = lab / "comparison"
out.mkdir()
def read(p): return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(data): return hashlib.sha256(data).hexdigest()
def digest(p): return sha(p.read_bytes())
def save(p, value): p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
def git(*args, cwd=repo): return subprocess.check_output(["git", *args], cwd=cwd)

core = "Lokad.Lython.dll"
published = read(repo / "benchmarks/results/2026-11-23-direct-bound-integer-refined/source.json")
known = published["imageFiles"]["candidate"]
reference = previous / "frozen-candidate"
assert len(known) == 32 and {n: digest(reference / n) for n in known} == known
base = git("rev-parse", "f53c32e53", cwd=tree).decode().strip()
assert not git("diff", "--name-only", published["candidate"], base, "--", "src", "tests")
patch = git("diff", "--binary", base, "--", "src", "tests", cwd=tree)
assert patch.count(b"diff --git ") == 2
(out / "source.patch").write_bytes(patch)
python = Path("C:/Python313/python.exe")
protocol = repo / "benchmarks/cpython-worker.py"
assert digest(protocol) == published["protocolSHA256"]
spec = importlib.util.spec_from_file_location("proto", protocol)
proto = importlib.util.module_from_spec(spec)
spec.loader.exec_module(proto)

routes = read(before / "text-route-catalog.json")
immediate, materialized = routes["cases"]
assert materialized["id"] == "diagnostic.text-summary.materialized-line.large"
short_fixture = base64.b64decode(json.loads(materialized["fixtureJson"])["inputFiles"]["input.txt"], validate=True)
def generated(id, template, source, data, size):
    with tempfile.TemporaryDirectory(prefix="lython-cased-text-golden-") as temp:
        root = Path(temp)
        (root / "input.txt").write_bytes(data)
        result = subprocess.run([python, "-I", "-S", "-X", "utf8", "-c", source], cwd=root,
            check=True, capture_output=True, timeout=30)
        assert not result.stderr
        outputs = {"report.txt": (root / "report.txt").read_bytes()}
    expected = result.stdout.decode("utf-8").replace("\r\n", "\n")
    encode = lambda b: base64.b64encode(b).decode("ascii")
    fixture = json.dumps(dict(size=size,text=None,inputFiles={"input.txt":encode(data)},
        outputFiles={k:encode(v) for k,v in outputs.items()}),ensure_ascii=False,separators=(",",":"))
    source_bytes = source.encode("utf-8")
    return {**template, "id":id,"size":size,"source":source,"fixtureJson":fixture,
        "expectedOutput":expected,"sourceUtf8Bytes":len(source_bytes),"expectedOutputUtf8Bytes":len(expected.encode("utf-8")),
        "sourceSha256":sha(source_bytes),"fixtureSha256":sha(fixture.encode("utf-8")),
        "expectedOutputSha256":sha(expected.encode("utf-8")),"expectedFilesSha256":proto.file_digest(outputs)}

wide_input = ("ΠΣ́ Café " + ("VériFICATion-" * 24) + " İ οΣ K İß Café\u2003SUPPLY\n") * 512 + "Z"
wide = generated("diagnostic.text-summary.materialized-wide", materialized, materialized["source"], wide_input.encode("utf-8"), 512)
ascii_input = ("ALPHA aLaRM REPORT PAYLoad status LOAD TAG CHECK\n" * 2047 + "Z").encode()
ascii_case = generated("diagnostic.text-summary.materialized-ascii", materialized, materialized["source"], ascii_input, 1024)
split = generated("diagnostic.text-summary.materialized-ordinary-split", materialized,
    materialized["source"].replace("line.lower().split()", "line.split()"), short_fixture, materialized["size"])
prior_text = read(lab.parent/"prepared-histogram-20261122/comparison/catalog.json")
dense = next(c for c in prior_text["cases"] if c["id"]=="diagnostic.text-summary.dense-line")
invoice = next(c for c in read(previous/"representative.json")["cases"] if c["id"].startswith("scripts.csv-invoice"))
cases = [materialized, wide, ascii_case, immediate, dense, split, invoice]
catalog = out / "representative.json"
save(catalog, {**routes,"cases":cases})

sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk)+os.pathsep+os.environ["PATH"])
images, allocation = {}, {}
candidate = lab / "windows/bin/Lokad.Lython/release_net11.0" / core
for role, built in (("reference", reference / core), ("candidate", candidate)):
    image = out / f"frozen-{role}"
    image.mkdir()
    files = {**known, core: digest(built)}
    for name in files:
        shutil.copyfile(built if name == core else reference / name, image / name)
    assert {n: digest(image / n) for n in files} == files
    images[role] = files
    for suffix in (".dll", ".deps.json", ".runtimeconfig.json"):
        name = "ValidatedAllocation" + suffix
        shutil.copyfile(reference / name, image / name)
    proof = out / f"{role}-verify.json"
    subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog", catalog,
        "--dotnet", dotnet, "--python", python, "--python-worker", protocol, "--out", proof],
        env=env, cwd=repo, check=True, timeout=90)
    state = read(proof)
    assert state["state"] == "Completed" and state["catalogSha256"] == digest(catalog) and state["caseCount"] == len(cases)
    report = out / f"{role}-allocation.json"
    subprocess.run([dotnet, image / "ValidatedAllocation.dll", image, catalog, report],
        env=env, cwd=repo, check=True, timeout=85)
    rows = read(report)["rows"]
    assert len(rows) == len(cases) and all(r["sharedBudgetBaselineRestored"] for r in rows)
    allocation[role] = rows
    assert {n: digest(image / n) for n in files} == files

save(out / "identity.json", dict(reference=base, verifiedReferenceSource=published["candidate"], patchBase=base,
    sourcePatchSHA256=sha(patch), imageFiles=images, protocolSHA256=digest(protocol), catalogSHA256=digest(catalog)))
for a,b in zip(allocation["reference"],allocation["candidate"],strict=True):
    assert a["id"]==b["id"]
    x,y=(statistics.median(row["allocatedBytesPerInvocation"]) for row in (a,b))
    print(a["id"],x,y,y-x,round(100*(y/x-1),3),a["peakExecutionMemoryBytes"],b["peakExecutionMemoryBytes"],flush=True)
