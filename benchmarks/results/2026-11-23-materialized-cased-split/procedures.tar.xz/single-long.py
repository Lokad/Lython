from pathlib import Path
import base64,hashlib,importlib.util,json,os,statistics,subprocess

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
comparison=lab/"comparison-refined"
identity=json.loads((comparison/"identity.json").read_text(encoding="utf-8"))
protocol=repo/"benchmarks/cpython-worker.py"
spec=importlib.util.spec_from_file_location("proto",protocol)
proto=importlib.util.module_from_spec(spec)
spec.loader.exec_module(proto)
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(protocol.read_bytes())==identity["protocolSHA256"]
catalog=json.loads((comparison/"representative.json").read_text(encoding="utf-8"))
source="""with open('input.txt') as source:
    text = source.read()
words = text.lower().split()
print(len(words), len(words[0]), len(words[1]))
"""
data=b"A"*(128*1024)+b" "+b"B"*4096
fixture=json.dumps(dict(size=len(data),text=None,inputFiles={"input.txt":base64.b64encode(data).decode("ascii")},
    outputFiles={}),separators=(",",":"))
expected="2 131072 4096\n"
case=dict(catalog["cases"][0],id="diagnostic.text-summary.materialized-single-long-word",size=len(data),
    source=source, fixtureJson=fixture, expectedOutput=expected, sourceUtf8Bytes=len(source.encode()),
    expectedOutputUtf8Bytes=len(expected.encode()), sourceSha256=sha(source.encode()),
    fixtureSha256=sha(fixture.encode()), expectedOutputSha256=sha(expected.encode()), expectedFilesSha256=proto.file_digest({}))
manifest=lab/"single-long-catalog.json"
manifest.write_text(json.dumps({**catalog,"cases":[case]},ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
sdk=Path.home()/".dotnet11"
dotnet=sdk/"dotnet.exe"
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ["PATH"])
for role in ("reference","candidate"):
    image=comparison/f"frozen-{role}"
    assert {n:sha((image/n).read_bytes()) for n in identity["imageFiles"][role]}==identity["imageFiles"][role]
    proof=lab/f"single-long-{role}-verify.json"
    subprocess.run([dotnet,image/"Lokad.Lython.Benchmarks.dll","--compare","verify","--catalog",manifest,
        "--dotnet",dotnet,"--python","C:/Python313/python.exe","--python-worker",protocol,"--out",proof],
        env=env,cwd=repo,check=True,timeout=45)
    receipt=json.loads(proof.read_text(encoding="utf8"))
    assert receipt["state"]=="Completed" and receipt["caseCount"]==1 and receipt["catalogSha256"]==sha(manifest.read_bytes())
    report=lab/f"single-long-{role}-allocation.json"
    subprocess.run([dotnet,image/"ValidatedAllocation.dll",image,manifest,report],env=env,cwd=repo,check=True,timeout=60)
    row,=json.loads(report.read_text(encoding="utf8"))["rows"]
    assert row["sharedBudgetBaselineRestored"]
    print(role,statistics.median(row["allocatedBytesPerInvocation"]),row["peakExecutionMemoryBytes"])
