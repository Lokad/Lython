from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
tree = repo / ".git/agent-worktrees/materialized-cased-split-20261123"
out = lab / "comparison-refined"
previous = lab.parent / "body-signature-20261123" / "comparison-refined"
quiet = out / "quiet"
quiet.mkdir()
core = "Lokad.Lython.dll"
def read(p): return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(data): return hashlib.sha256(data).hexdigest()
def digest(p): return sha(p.read_bytes())
def save(p, value): write(p, json.dumps(value, ensure_ascii=False, indent=2) + "\n")
def write(p, source):
    if p.suffix == ".py": compile(source, str(p), "exec")
    p.write_text(source, encoding="utf-8", newline="\n")
def git(*args, cwd=repo): return subprocess.check_output(["git", *args], cwd=cwd)
def published(folder, name): return git("show", f"origin/master:benchmarks/results/{folder}/{name}")
def archive(folder):
    receipt = json.loads(published(folder, "archive-receipt.json"))
    data = published(folder, "observations.tgz")
    assert all(receipt[k] for k in ("complete", "allWorkersJoined", "archivedAndVerifiedUnderLease"))
    assert sha(data) == receipt["archiveSHA256"]
    return receipt["archiveSHA256"]

template = read(previous / "quiet/config.json")
donor = "2026-11-23-direct-bound-integer-refined"
prior = json.loads(published(donor, "source.json"))
assert prior["imageFiles"]["candidate"] == template["sourceFiles"]
before = read(out / "identity.json")
candidate = git("rev-parse", "HEAD", cwd=tree).decode().strip()
assert not git("status", "--porcelain", cwd=tree)
patch = git("diff", "--binary", before["patchBase"], candidate, "--", "src", "tests")
assert sha(patch) == before["sourcePatchSHA256"] and patch == (out/"source.patch").read_bytes()
files = before["imageFiles"]
assert prior["imageFiles"]["candidate"] == files["reference"] and len(files["reference"]) == 32
assert [n for n in files["reference"] if files["reference"][n] != files["candidate"][n]] == [core]

finished = "2026-11-23-body-owned-signatures-refined"
old = json.loads(published(finished, "source.json"))
blob = gzip.decompress(published(finished, "candidate-core.dll.gz"))
assert sha(blob) == old["imageFiles"]["candidate"][core]
old_root = Path(template["root"]).name
retire = [dict(paths=[old_root + "/candidate/" + core], bytes=len(blob), sha256=sha(blob), links=1,
    archives={old_root + "/observations.tgz": archive(finished)})]

catalog = out / "representative.json"
ids = [row["id"] for row in read(catalog)["cases"]]
jobs = [(ids[0], "warm"), (ids[0], "compile-run")] + [(id, "warm") for id in ids[1:]]
assert len(jobs) == 8
save(out / "jobs.json", jobs)
shutil.copyfile(catalog, quiet / "representative.json")
for role, manifest in files.items():
    image = out / f"frozen-{role}"
    proof = read(out / f"{role}-verify.json")
    assert proof["state"] == "Completed" and proof["catalogSha256"] == digest(catalog) and proof["caseCount"] == len(ids)
    assert {n: digest(image / n) for n in manifest} == manifest

(quiet / "candidate").mkdir()
shutil.copyfile(out / "frozen-candidate" / core, quiet / "candidate" / core)
identity = {**before, "sourceRevision": before["reference"] + " versus " + candidate, "candidate": candidate,
    "purpose": "Share the packed casing and boundary scan, fund one list, and reuse wide scratch.",
    "normalAdapterPin": "0.4.0", "coreSHA256": {r+s:m[core] for r,m in files.items() for s in ("", "-control")},
    "catalogs": {"representative.json": {"sha256": digest(catalog)}}}
save(quiet / "identity.json", identity)
root = "/home/lokad/lython-bench-checks/materialized-cased-split-b1435-20261123"
unit = "lython-b1435-materialized-cased-split-20261123"
for name in ("collect.py", "run.sh", "archive-owned.py", "retrieve.py"):
    source = (previous / "quiet" / name).read_text(encoding="utf-8").replace(template["root"], root).replace(template["unit"], unit)
    if name == "collect.py":
        start, end = source.index("\njob_catalog ="), source.index("\nassert len(jobs)")
        source = source[:start] + "\njob_catalog = " + repr({id:"representative.json" for id in ids}) + "\njobs = " + repr(jobs) + source[end:]
        source = source.replace("if job_index % 2 != 0: labels.reverse()", "if job_index % 2 == 0: labels.reverse()").replace("len(jobs)==8", "len(jobs)==8")
    elif name == "archive-owned.py":
        source = source.replace("len(raw['jobs'])==8", "len(raw['jobs'])==8").replace("jobs=8,elapsedSeconds", "jobs=8,elapsedSeconds")
    elif name == "retrieve.py":
        source = source.replace("status['receipt']['jobs']==8", "status['receipt']['jobs']==8")
    write(quiet / name, source.replace("Reuse the selected signature", "Materialized cased words"))
assert b"\r" not in (quiet / "run.sh").read_bytes()
parts = ("identity.json", "representative.json", "collect.py", "run.sh", "archive-owned.py", "candidate/" + core)
payload = quiet / "payload.tgz"
with tarfile.open(payload, "w:gz") as bundle:
    for name in parts: bundle.add(quiet / name, arcname=name)
cfg = {**template, "root": root, "unit": unit, "identity": identity,
       "sourceFiles": files["reference"], "sourceCatalogSHA256": prior["catalogs"]["representative.json"]["sha256"],
       "donorArchiveSHA256": archive(donor), "retireGroups": retire, "payloadBytes": payload.stat().st_size,
       "payloadSHA256": digest(payload), "unpackedBytes": sum((quiet / n).stat().st_size for n in parts)}
save(quiet / "config.json", cfg)
seed = (previous / "quiet/remote-launch.py").read_text(encoding="utf-8")
a,b = seed.index("\nc=")+1, seed.index("\nb=Path(")
write(quiet / "remote-launch.py", (seed[:a] + "c=" + repr(cfg) + seed[b:]).replace("b1434-fixtures", "b1435-fixtures"))
launch = (previous / "launch.py").read_text(encoding="utf-8").replace("Reuse the selected signature", "Materialized cased words")
write(out / "launch.py", launch.replace("seconds=465", "seconds=465").replace("before 465 seconds", "before 465 seconds"))
summary = (previous / "summarize.py").read_text(encoding="utf-8")
write(out / "summarize.py", summary.replace("len(raw['jobs'])==8", "len(raw['jobs'])==8"))
print(candidate, root, cfg["unpackedBytes"], sum(group["bytes"] for group in retire))
