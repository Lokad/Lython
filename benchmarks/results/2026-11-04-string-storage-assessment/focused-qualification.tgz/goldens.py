from pathlib import Path
import hashlib,json,re,subprocess,tempfile,textwrap
p=Path(__file__).resolve().parent
source=Path('D:/code/Lython/tests/Lokad.Lython.PublicApi.Tests/WhitespaceFragmentValueTests.cs').read_text(encoding='utf-8')
parts=re.findall(r'\.Compile\("""\n(.*?)\n\s*""", budget\);',source,re.S)
assert len(parts)==2
results=[]
for body in parts:
 body=textwrap.dedent(body)
 wrapped='def run():\n'+textwrap.indent(body,'    ')+'\n\nprint(repr(run()))\n'
 with tempfile.TemporaryDirectory(prefix='lython-fragment-golden-') as directory:
  result=subprocess.run(['C:/Python313/python.exe','-I','-X','utf8','-c',wrapped],cwd=directory,text=True,encoding='utf-8',capture_output=True,timeout=15)
  assert result.returncode==0,(result.stdout,result.stderr)
  assert not result.stderr,result.stderr
  results.append(dict(source=body,sourceSHA256=hashlib.sha256(body.encode('utf-8')).hexdigest(),stdout=result.stdout,returnCode=result.returncode))
(p/'python-goldens.json').write_text(json.dumps(dict(reference='CPython3.13.2 -I -X utf8; trusted snippet wrapped for top-level return; isolated temporary filesystem',cases=results),indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps([dict(sourceSHA256=r['sourceSHA256'],stdout=r['stdout']) for r in results]))
