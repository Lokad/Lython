# B205 storage decision and metadata simplification - before code

Two correct windowed implementations were measured. Initialbe5 embedded segments:
text allocation-4.73%, but multiple text/JSON/report elapsed costs2-4%. Refined801
managed buffer/offset/count has the same allocation, sync text near old roles,
async JSON+2.08..2.44% (old spread0.35), sync report+5.14..6.03% (spread0.84).
Refined capture303.304s, original322.363s; all goldens/balances/gates/joins PASS.
Neither demonstrates a whole-script CPU improvement or closes B203 text debt.

WITHDRAW general string windows and compact split payload: their access/lifetime
and admission costs do not justify this result. Retain raw observations, failed
offset regression/correction and sources. This is not a permanent prohibition;
a future design needs materially different work elimination/cost evidence, not
unchanged retiming. Delete shared-payload flag/factory and offset fields; restore
ordinary independent fragment construction and its existing ownership contract.
Restore the old component-sum fixture, whose premise only changed for windows.
Preserve useful independent string/regex/real-I/O/alias regressions, which also
apply to the original storage and should not enforce the discarded layout.

Selected simpler implementation: remove _committedCacheBytes and its setter.
Only one optional rune-offset array uses that accumulator; derive its owned
charge from its actual retained capacity. Preserve allocation preflight and the
new construction rollback, without changing string/split owner lifetimes or
estimates. Removing the field should reduce normal metadata72->64B; verify the
actual CLR objects, not just a synthetic shape. No new owner/backend/policy.

Hypothesis/source evidence: PyString36.68% of sampled current guest allocation,
only18.37% in split. Smaller metadata can affect all representative scripts,
without a new access path or shared backing. No promised CPU percentage.

Same focused Release actual11/10 semantics/refusal/cache/aliases/cancellation,
real delayed I/O and regex checks; independent CPython goldens. One short final
source-pair comparison6 jobs(text/report BOTH APIs, JSONasync/CSVsync), qualified
B203/candidate/B203,6s warmups,9 rotated~200ms samples, separate existing allocation
both APIs.420s owned bound. No new external/compiler campaign or benchmark
framework. Record allocation/elapsed/peaks and explicit B203 debt decision;
do not add independent deltas. Full delivery on final retained source only.
Publication postponed and the larger performance roadmap remains active.


Before final capture:444 internal/2667 public per actual11/10, nonincremental
Release zero warnings/errors. One new refund assertion had double-counted backing
under the restored independent-copy contract; changed to actual backing+metadata+
cache funding lower bound, preserving first failure. General semantic/alias/real
I/O/regex checks still pass and CPython goldens remain. No window machinery or
shared-component fixture remains. Source patch contains only PyString.cs.
