# B205 managed-buffer refinement - before code

Initialbe5dd48f passes444 internal/2667 public per actual11/10, actual object72B,
real delayed write, regex pattern/subject/replacement windows and ownership checks.
8-job four-image comparison/allocation completes322.363s, all gates/goldens/
balances/joins. Text allocation-4.73%, other allocation effectively flat. Adverse
elapsed: async text+2.07..3.08% (old spread0.98), async JSON+2.88..2.94% (spread0.06),
sync report+1.64..3.05%, sync CSV+1.19..1.41%. Sync text+2.62..6.70% with3.98%
old spread; pre-list reference also moves. No CPU gain/debt closure established.
Keep original source/raw conditions and added-header admission cost.

Hypothesis: embedding ArraySegment in each string adds segment indexing/access
work and changes hot-field placement. It is not established as the sole cause.
Refine to ordinary managed byte[] plus readonly logical offset/count. Retain
checked array/span access, the batch-owned payload and child metadata-only refund.
No Unsafe/pointers/native telemetry or new backend/owner/configuration. Keep
ArraySegment only as the validated construction argument for a shared window.
Normal construction no longer constructs an embedded segment; logical-window
operations still use the same UTF8 helpers. Cache accumulator remains removed.

This is the same coherent representation/construction migration, not a new
specialized formatter or change to ownership/estimates. Actual normal size must
remain checked, source/metadata semantics and all focused regressions actual11/10.
Do not infer CPU from bytes or attribute regressions to layout without evidence.

One bounded confirmation:6 jobs(text BOTH APIs, JSON async, report BOTH APIs,
CSV sync), old B203/qualified pre-list B201/initialbe5/refined/old B203.5 images
with6s warmup,9 rotating~200ms samples, original quiet gates, existing allocation
both APIs,420s owned service. This preserves normal-string adverse conditions and
permits actual pre-list debt comparison without adding independent percentages.
No external/compiler retiming or new benchmark framework. If still adverse,
decide correction/accepted debt/withdrawal explicitly, preserving useful regression
coverage and not leaving dormant window machinery. Publication postponed.


Correction before capture: new offset-value regressions caught two raw-buffer
replacement copies that needed logical offsets after this representation change.
Both use the logical span, empty-pattern replacement added and independently
CPython verified. Initial broken source/TRX/logs retained. Final full focused
actual11/10 selection rerun with zero warnings/errors, no weakened assertions.
