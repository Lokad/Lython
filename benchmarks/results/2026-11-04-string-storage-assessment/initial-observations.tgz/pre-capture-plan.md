# A9/B205 compact UTF8 fragments - design before implementation

Parentf74b5193; runtimeae9b82b7/frozen67373996 fully qualified in cached41793317194
(all8 gates). Prior turn made concrete progress: B201/B202/B203 committed and
qualified, current B204 allocation profile and managed metadata model recorded.
No current processes or unresolved qualification are prerequisites for this work.

Source/profile: whitespace split allocates one byte array and PyString per word;
byte arrays there are8.06% of sampled active-guest allocation, not CPU shares.
Normal PyString metadata72B, managed segment/no-cache-accumulator model72B on both
actual11/10. Actual implementation/access costs still need checking. Current
sync-text1.2-2.9% elapsed debt remains explicit and must be evaluated on this source.

Replace byte[] plus logical length with ArraySegment<byte> in ordinary PyString.
Remove _committedCacheBytes and CommitCacheCharge: the one optional rune-index
array determines its actual owned cache charge. Preflight its allocation and
rollback reserved capacity on construction failure. Preserve normal string full-
backing charges, including unused builder capacity. Do not remove rune indexing.

Whitespace split/rsplit keeps its existing scanner/range scratch and formatter
semantics. Admit metadata plus one compact payload before constructing it, then
ordinary string windows describe disjoint ranges. Remove per-word byte arrays;
no borrowed input data, deferred split object, new backend, pool or owner layer.
One flag distinguishes a window's own metadata/cache charge from batch payload.
The existing execution governor owns that payload (including array header) until
batch cleanup; child unpublished refunds must never refund shared backing. All
actual aliases/users remain funded. Bounded host-driven executions remain the
streaming contract, not arbitrary guest-reference reclamation.

Contract tradeoffs: escaped words can retain the whole compact payload; owner
funding stays conservatively held until execution/result cleanup. A separately
charged payload header can require modest additional admission versus per-word
storage estimates; identical tiny thresholds are not a requirement. No fallback
or retry after admission/native work. Copy in bounded, cancellation-checked chunks,
including after the list's own admission. Current token never enters cached data.

All raw accesses must apply logical offsets: concat/repeat/slices/indexing/rune
iteration/hash/encoding/format/regex/public projection. Direct charge consumers
previously inspected create fresh standalone data (warnings/private native decoder
windows/fresh cache keyword labels). Preserve execution scope/result/cache/borrow
contracts; no broader inventory or tracing work. Keep array adoption/copy rules
for arbitrary FromUtf8 inputs unchanged.

Focused Release actual11/10 string/scalar/whitespace/hash/index/format/codec/JSON,
shared-root/refusal/rollback/cancellation, independent escaped words after source
cleanup and full ownership cleanup. Translate only an exact component-sum fixture
whose premise changes; preserve independent funding/nonrefund assertions. Add
regressions for nonzero-offset strings and unpublished-window refunds with live
siblings, not architecture-only eligibility tests. Verify actual metadata size.

One bounded whole-script old/candidate/old collection using existing workers:
complete text BOTH APIs, normal-string JSON/report controls, allocation/elapsed/
admitted peaks separately. Compilation unchanged; no repeated external CPython
campaign or new framework. Preserve all adverse conditions, allow justified
bounded refinement. End in an explicit retention/correction/withdrawal and B203
debt decision. Batch full Windows/Ubuntu/stress/installed consumers at delivery.
No dormant window path or permanent half migration. Publication postponed.


Final before capture: actual444 internal/2667 public each.NET11/10 PASS,
nonincremental Release solution build zero warnings/errors; new semantic sources
independently CPython3.13.2 PASS, real delayed host write and existing0.4 adapter
pattern/subject/replacement windows. Actual normal string metadata72B on both.
8 jobs(text,JSON,report,CSV BOTH APIs),4 verified images,current B203 old roles,
candidate and pre-list B201 reference;6s warmup/image,9 rotated~200ms samples.
Existing8-case isolated allocation driver both APIs.420s owned service bound,
persistent evidence/RAM guest fixtures. No frontend/compiler or external refresh.
Added payload header can increase admitted peak; one escaping word retains the
whole compact output. Measure and document both costs, no allocation->CPU claim.
