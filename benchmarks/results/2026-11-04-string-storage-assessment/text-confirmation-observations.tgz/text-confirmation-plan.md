# B205 text-only measurement correction

The six-job final-source collection is valid and preserved: synchronous text
+4.02/+8.25% versus old roles differing3.90%, async -5.67/+5.47% versus roles
 differing10.56%. Both APIs allocate about4.07% less. Report improves modestly;
JSON/CSV are control-limited. Do not call this a CPU improvement or close B203 debt.

One unchanged-source text-only confirmation is justified by inconsistent old roles.
Use the exact454 candidate and6737 baseline, no source/binary/environment changes.
Increase per-process warmup6->20seconds;11 rotated~300ms batches; reverse worker
creation order on the second API. Two complete jobs only. Retain all warmup/sample
responses, original observations, gates, identities, normal exits and cleanup.
Owned bound240seconds; no allocation/compiler/external/unchanged qualification
replay. Interpretation includes controls and spread, not a percentage veto. Decide
retention/debt after this observation; no automatic further retries.
