; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:EvaluateClosedDefault(Lokad.Lython.Frontend.ExecutableCodeObject,long,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref,int):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; partially interruptible
; No PGO data
; 1 inlinees with PGO data; 23 single block inlinees; 14 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 200
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x60], ymm4
       vmovdqu  ymmword ptr [rsp+0x80], ymm4
       vmovdqu  ymmword ptr [rsp+0xA0], ymm4
       xor      eax, eax
       mov      qword ptr [rsp+0xC0], rax
       mov      rdi, rcx
       mov      rsi, r9
       mov      rbx, bword ptr [rsp+0x130]
 
G_M000_IG02:                ;; offset=0x0047
       mov      ebp, dword ptr [rsp+0x138]
       mov      r14, r8
       mov      r15, rdx
       xor      r13, r13
       xor      r12d, r12d
       jmp      G_M000_IG46
 
G_M000_IG03:                ;; offset=0x005F
       mov      r8d, dword ptr [rax+0x08]
       and      r8d, 0x7FFFFFFF
       mov      dword ptr [rsp+0xAC], r8d
       mov      r8d, dword ptr [rsp+0xAC]
 
G_M000_IG04:                ;; offset=0x007A
       mov      ecx, dword ptr [rax+0x10]
       cmp      ecx, ebp
       je       G_M000_IG16
 
G_M000_IG05:                ;; offset=0x0085
       test     ecx, ecx
       jge      SHORT G_M000_IG06
       mov      dword ptr [rsp+0xAC], r8d
       mov      rdx, gword ptr [r15+0x30]
       mov      r10d, ecx
       not      r10d
       cmp      r10d, dword ptr [rdx+0x08]
       jae      G_M000_IG62
       not      ecx
       mov      rcx, gword ptr [rdx+8*rcx+0x10]
       lea      rdx, [rsp+0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       mov      r8d, dword ptr [rsp+0xAC]
       jmp      G_M000_IG14
 
G_M000_IG06:                ;; offset=0x00C7
       mov      rdx, 0x2850B401CF0
       cmp      r13, gword ptr [rdx]
       je       G_M000_IG12
       test     r12, r12
       mov      dword ptr [rsp+0xAC], r8d
       jle      SHORT G_M000_IG07
       mov      rdx, r13
       mov      rcx, 0x7FF9CC8D8AB0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG08
 
G_M000_IG07:                ;; offset=0x00FE
       lea      rdx, [rsp+0xC0]
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       mov      ecx, eax
       mov      r8d, dword ptr [rsp+0xAC]
       jmp      SHORT G_M000_IG13
 
G_M000_IG08:                ;; offset=0x011B
       mov      r10, rax
       lea      r9d, [r12-0x01]
       mov      dword ptr [rsp+0xA8], r9d
       mov      gword ptr [rsp+0x38], r10
       mov      rdx, gword ptr [r10+0x08]
       mov      rcx, 0x7FF9CC382560
       call     CORINFO_HELP_ISINSTANCEOFARRAY
       test     rax, rax
       je       SHORT G_M000_IG10
       xor      ecx, ecx
       mov      qword ptr [rsp+0xC0], rcx
 
G_M000_IG09:                ;; offset=0x0152
       xor      eax, eax
       jmp      SHORT G_M000_IG11
 
G_M000_IG10:                ;; offset=0x0156
       mov      rcx, gword ptr [rsp+0x38]
       mov      edx, dword ptr [rsp+0xA8]
       call     [Lokad.Lython.Runtime.PyTuple:WritableValueSlot(int):byref:this]
       mov      rcx, rax
       lea      rdx, [rsp+0xC0]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
 
G_M000_IG11:                ;; offset=0x0179
       mov      ecx, eax
       mov      r8d, dword ptr [rsp+0xAC]
       jmp      SHORT G_M000_IG13
 
G_M000_IG12:                ;; offset=0x0185
       mov      qword ptr [rsp+0xC0], r12
       mov      ecx, 1
 
G_M000_IG13:                ;; offset=0x0192
       mov      eax, ecx
 
G_M000_IG14:                ;; offset=0x0194
       test     eax, eax
       jne      SHORT G_M000_IG17
 
G_M000_IG15:                ;; offset=0x0198
       mov      eax, r8d
       jmp      G_M000_IG30
 
G_M000_IG16:                ;; offset=0x01A0
       mov      qword ptr [rsp+0xC0], r14
 
G_M000_IG17:                ;; offset=0x01A8
       mov      rax, bword ptr [rsp+0x58]
       mov      ecx, dword ptr [rax+0x0C]
       cmp      ecx, ebp
       je       G_M000_IG28
       test     ecx, ecx
       jge      SHORT G_M000_IG18
       mov      dword ptr [rsp+0xAC], r8d
       mov      rdx, gword ptr [r15+0x30]
       mov      r10d, ecx
       not      r10d
       cmp      r10d, dword ptr [rdx+0x08]
       jae      G_M000_IG62
       not      ecx
       mov      rcx, gword ptr [rdx+8*rcx+0x10]
       lea      rdx, [rsp+0xB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       mov      r8d, dword ptr [rsp+0xAC]
       jmp      G_M000_IG26
 
G_M000_IG18:                ;; offset=0x01FA
       mov      rdx, 0x2850B401CF0
       cmp      r13, gword ptr [rdx]
       je       G_M000_IG24
       test     r12, r12
       mov      dword ptr [rsp+0xAC], r8d
       jle      SHORT G_M000_IG19
       mov      rdx, r13
       mov      rcx, 0x7FF9CC8D8AB0
       call     CORINFO_HELP_ISINSTANCEOFCLASS
       test     rax, rax
       jne      SHORT G_M000_IG20
 
G_M000_IG19:                ;; offset=0x0231
       lea      rdx, [rsp+0xB8]
       mov      rcx, r13
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineInteger(System.Object,byref):bool]
       mov      r9d, eax
       mov      r8d, dword ptr [rsp+0xAC]
       jmp      SHORT G_M000_IG25
 
G_M000_IG20:                ;; offset=0x024F
       mov      r10, rax
       lea      r9d, [r12-0x01]
       mov      dword ptr [rsp+0xA4], r9d
       mov      gword ptr [rsp+0x30], r10
       mov      rdx, gword ptr [r10+0x08]
       mov      rcx, 0x7FF9CC382560
       call     CORINFO_HELP_ISINSTANCEOFARRAY
       test     rax, rax
       je       SHORT G_M000_IG22
       xor      ecx, ecx
       mov      qword ptr [rsp+0xB8], rcx
 
G_M000_IG21:                ;; offset=0x0286
       xor      eax, eax
       jmp      SHORT G_M000_IG23
 
G_M000_IG22:                ;; offset=0x028A
       mov      rcx, gword ptr [rsp+0x30]
       mov      edx, dword ptr [rsp+0xA4]
       call     [Lokad.Lython.Runtime.PyTuple:WritableValueSlot(int):byref:this]
       mov      rcx, rax
       lea      rdx, [rsp+0xB8]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:TryGetInteger(byref):bool:this]
 
G_M000_IG23:                ;; offset=0x02AD
       mov      r9d, eax
       mov      r8d, dword ptr [rsp+0xAC]
       jmp      SHORT G_M000_IG25
 
G_M000_IG24:                ;; offset=0x02BA
       mov      qword ptr [rsp+0xB8], r12
       mov      r9d, 1
 
G_M000_IG25:                ;; offset=0x02C8
       mov      eax, r9d
 
G_M000_IG26:                ;; offset=0x02CB
       test     eax, eax
       jne      SHORT G_M000_IG29
 
G_M000_IG27:                ;; offset=0x02CF
       mov      eax, r8d
       jmp      SHORT G_M000_IG30
 
G_M000_IG28:                ;; offset=0x02D4
       mov      qword ptr [rsp+0xB8], r14
 
G_M000_IG29:                ;; offset=0x02DC
       lea      r9, [rsp+0xB0]
       mov      dword ptr [rsp+0xAC], r8d
       mov      ecx, r8d
       mov      rdx, qword ptr [rsp+0xC0]
       mov      r8, qword ptr [rsp+0xB8]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineBinary(int,long,long,byref):bool]
       test     eax, eax
       jne      G_M000_IG59
       mov      eax, dword ptr [rsp+0xAC]
       lea      ecx, [rax-0x0F]
       cmp      ecx, 5
       mov      eax, dword ptr [rsp+0xAC]
       jbe      G_M000_IG51
 
G_M000_IG30:                ;; offset=0x0327
       mov      rdx, bword ptr [rsp+0x58]
       mov      r8d, dword ptr [rdx+0x10]
       mov      gword ptr [rsp+0x90], r13
       mov      qword ptr [rsp+0x98], r12
       cmp      r8d, ebp
       jne      SHORT G_M000_IG31
       mov      dword ptr [rsp+0xAC], eax
       mov      rcx, 0x7FF9CC75FD50
       call     CORINFO_HELP_NEWSFAST
       mov      gword ptr [rsp+0x28], rax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rsp+0x80], xmm0
       lea      rcx, [rsp+0x80]
       mov      rdx, r14
       call     [System.Numerics.BigInteger:.ctor(long):this]
       mov      rax, gword ptr [rsp+0x28]
       lea      rcx, bword ptr [rax+0x08]
       mov      rdx, gword ptr [rsp+0x80]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rsp+0x88]
       mov      rax, gword ptr [rsp+0x28]
       mov      dword ptr [rax+0x10], ecx
       mov      r8, rax
       mov      eax, dword ptr [rsp+0xAC]
       jmp      G_M000_IG37
 
G_M000_IG31:                ;; offset=0x03B2
       test     r8d, r8d
       jge      SHORT G_M000_IG32
       mov      rcx, gword ptr [r15+0x30]
       mov      r10d, r8d
       not      r10d
       cmp      r10d, dword ptr [rcx+0x08]
       jae      G_M000_IG62
       not      r8d
       mov      rcx, gword ptr [rcx+8*r8+0x10]
       mov      r8, rcx
       jmp      G_M000_IG37
 
G_M000_IG32:                ;; offset=0x03DB
       mov      rcx, gword ptr [rsp+0x90]
       mov      r8, 0x2850B401CF0
       cmp      rcx, gword ptr [r8]
       je       G_M000_IG35
       mov      rcx, gword ptr [rsp+0x90]
       mov      r8, 0x2850B401CF8
       cmp      rcx, gword ptr [r8]
       je       SHORT G_M000_IG34
       cmp      qword ptr [rsp+0x98], 0
       jne      SHORT G_M000_IG33
       mov      r8, gword ptr [rsp+0x90]
       mov      dword ptr [rsp+0xAC], eax
       jmp      SHORT G_M000_IG36
 
G_M000_IG33:                ;; offset=0x0429
       mov      dword ptr [rsp+0xAC], eax
       lea      rcx, [rsp+0x90]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDeferredValue():System.Object:this]
       mov      r8, rax
       jmp      SHORT G_M000_IG36
 
G_M000_IG34:                ;; offset=0x0443
       mov      dword ptr [rsp+0xAC], eax
       mov      rcx, 0x7FF9CC3B6488
       call     CORINFO_HELP_NEWSFAST
       vmovsd   xmm0, qword ptr [rsp+0x98]
       vmovsd   qword ptr [rax+0x08], xmm0
       mov      r8, rax
       mov      gword ptr [rsp+0x90], r8
       xor      ecx, ecx
       mov      qword ptr [rsp+0x98], rcx
       jmp      SHORT G_M000_IG36
 
G_M000_IG35:                ;; offset=0x047E
       mov      dword ptr [rsp+0xAC], eax
       lea      rcx, [rsp+0x90]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r8, rax
 
G_M000_IG36:                ;; offset=0x0496
       mov      gword ptr [rsp+0x50], r8
       mov      eax, dword ptr [rsp+0xAC]
       mov      r8, gword ptr [rsp+0x50]
 
G_M000_IG37:                ;; offset=0x04A7
       mov      rdx, bword ptr [rsp+0x58]
       mov      r10d, dword ptr [rdx+0x0C]
       mov      gword ptr [rsp+0x70], r13
       mov      qword ptr [rsp+0x78], r12
       cmp      r10d, ebp
       jne      SHORT G_M000_IG38
       mov      gword ptr [rsp+0x50], r8
       mov      dword ptr [rsp+0xAC], eax
       mov      rcx, 0x7FF9CC75FD50
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rsp+0x60], xmm0
       lea      rcx, [rsp+0x60]
       mov      rdx, r14
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rcx, bword ptr [r13+0x08]
       mov      rdx, gword ptr [rsp+0x60]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rsp+0x68]
       mov      dword ptr [r13+0x10], ecx
       mov      r8, r13
       mov      r10, r8
       mov      eax, dword ptr [rsp+0xAC]
       mov      r8, gword ptr [rsp+0x50]
       jmp      G_M000_IG44
 
G_M000_IG38:                ;; offset=0x0522
       test     r10d, r10d
       jge      SHORT G_M000_IG39
       mov      rcx, gword ptr [r15+0x30]
       mov      r9d, r10d
       not      r9d
       cmp      r9d, dword ptr [rcx+0x08]
       jae      G_M000_IG62
       not      r10d
       mov      rcx, gword ptr [rcx+8*r10+0x10]
       mov      r10, rcx
       jmp      G_M000_IG44
 
G_M000_IG39:                ;; offset=0x054B
       mov      rcx, gword ptr [rsp+0x70]
       mov      r10, 0x2850B401CF0
       cmp      rcx, gword ptr [r10]
       je       G_M000_IG42
       mov      rcx, gword ptr [rsp+0x70]
       mov      r10, 0x2850B401CF8
       cmp      rcx, gword ptr [r10]
       je       SHORT G_M000_IG41
       cmp      qword ptr [rsp+0x78], 0
       jne      SHORT G_M000_IG40
       mov      r10, gword ptr [rsp+0x70]
       mov      gword ptr [rsp+0x50], r8
       mov      dword ptr [rsp+0xAC], eax
       jmp      SHORT G_M000_IG43
 
G_M000_IG40:                ;; offset=0x0592
       mov      gword ptr [rsp+0x50], r8
       mov      dword ptr [rsp+0xAC], eax
       lea      rcx, [rsp+0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDeferredValue():System.Object:this]
       mov      r10, rax
       jmp      SHORT G_M000_IG43
 
G_M000_IG41:                ;; offset=0x05AE
       mov      gword ptr [rsp+0x50], r8
       mov      dword ptr [rsp+0xAC], eax
       mov      rcx, 0x7FF9CC3B6488
       call     CORINFO_HELP_NEWSFAST
       vmovsd   xmm0, qword ptr [rsp+0x78]
       vmovsd   qword ptr [rax+0x08], xmm0
       mov      r10, rax
       mov      gword ptr [rsp+0x70], r10
       xor      ecx, ecx
       mov      qword ptr [rsp+0x78], rcx
       jmp      SHORT G_M000_IG43
 
G_M000_IG42:                ;; offset=0x05E5
       mov      gword ptr [rsp+0x50], r8
       mov      dword ptr [rsp+0xAC], eax
       lea      rcx, [rsp+0x70]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r10, rax
 
G_M000_IG43:                ;; offset=0x05FF
       mov      eax, dword ptr [rsp+0xAC]
       mov      r8, gword ptr [rsp+0x50]
 
G_M000_IG44:                ;; offset=0x060B
       mov      rdx, bword ptr [rsp+0x58]
       mov      rcx, gword ptr [rdx]
       mov      gword ptr [rsp+0x20], rcx
       mov      ecx, eax
       mov      rdx, r8
       mov      r8, r10
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateBinaryOperator(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      r13, rax
 
G_M000_IG45:                ;; offset=0x062C
       xor      r12d, r12d
 
G_M000_IG46:                ;; offset=0x062F
       mov      rcx, gword ptr [r15+0x98]
       mov      eax, dword ptr [rbx]
       mov      edx, eax
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG62
       shl      rdx, 5
       lea      rdx, bword ptr [rcx+rdx+0x10]
       cmp      dword ptr [rdx+0x1C], 46
       jne      G_M000_IG60
 
G_M000_IG47:                ;; offset=0x0656
       inc      eax
       mov      dword ptr [rbx], eax
       mov      rax, rdx
       mov      bword ptr [rsp+0x58], rax
       mov      rdx, gword ptr [rax]
       mov      gword ptr [rsp+0x48], rdx
       mov      r8, gword ptr [rsi+0xA0]
       mov      gword ptr [rsp+0x40], r8
       cmp      byte  ptr [r8], r8b
       mov      rcx, r8
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG49
 
G_M000_IG48:                ;; offset=0x0686
       mov      rcx, gword ptr [rsp+0x40]
       mov      rdx, gword ptr [rsp+0x48]
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG49:                ;; offset=0x0696
       mov      rax, bword ptr [rsp+0x58]
       cmp      dword ptr [rax+0x1C], 51
       jne      G_M000_IG03
 
G_M000_IG50:                ;; offset=0x06A5
       mov      r8d, dword ptr [rax+0x14]
       jmp      G_M000_IG04
 
G_M000_IG51:                ;; offset=0x06AE
       mov      rcx, qword ptr [rsp+0xB8]
       cmp      qword ptr [rsp+0xC0], rcx
       jge      SHORT G_M000_IG54
 
G_M000_IG52:                ;; offset=0x06C0
       mov      edx, -1
 
G_M000_IG53:                ;; offset=0x06C5
       mov      ecx, eax
       call     [Lokad.Lython.Runtime.LythonRuntime:CompareOrderedResult(int,int):bool]
       test     eax, eax
       jne      SHORT G_M000_IG57
       mov      rax, 0x2850B4013C8
       mov      r13, gword ptr [rax]
       jmp      SHORT G_M000_IG58
 
G_M000_IG54:                ;; offset=0x06E0
       cmp      qword ptr [rsp+0xC0], rcx
       jle      SHORT G_M000_IG56
 
G_M000_IG55:                ;; offset=0x06EA
       mov      edx, 1
       jmp      SHORT G_M000_IG53
 
G_M000_IG56:                ;; offset=0x06F1
       xor      edx, edx
       jmp      SHORT G_M000_IG53
 
G_M000_IG57:                ;; offset=0x06F5
       mov      rax, 0x2850B4013C0
       mov      r13, gword ptr [rax]
 
G_M000_IG58:                ;; offset=0x0702
       jmp      G_M000_IG45
 
G_M000_IG59:                ;; offset=0x0707
       mov      r12, qword ptr [rsp+0xB0]
       mov      rax, 0x2850B401CF0
       mov      r13, gword ptr [rax]
       jmp      G_M000_IG46
 
G_M000_IG60:                ;; offset=0x0721
       mov      gword ptr [rdi], r13
       mov      qword ptr [rdi+0x08], r12
       mov      rax, rdi
 
G_M000_IG61:                ;; offset=0x072B
       add      rsp, 200
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG62:                ;; offset=0x073F
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1861

