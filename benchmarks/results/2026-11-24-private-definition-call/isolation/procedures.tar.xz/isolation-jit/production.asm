; Assembly listing for method Lokad.Lython.Runtime.LythonRuntime:EvaluateClosedDefault(Lokad.Lython.Frontend.ExecutableCodeObject,long,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,byref):Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot (FullOpts)
; Emitting BLENDED_CODE for x64 + VEX on Windows
; FullOpts code
; optimized code
; rsp based frame
; partially interruptible
; No PGO data
; 1 inlinees with PGO data; 21 single block inlinees; 8 inlinees without PGO data

G_M000_IG01:                ;; offset=0x0000
       push     r15
       push     r14
       push     r13
       push     r12
       push     rdi
       push     rsi
       push     rbp
       push     rbx
       sub      rsp, 168
       vxorps   xmm4, xmm4, xmm4
       vmovdqu  ymmword ptr [rsp+0x30], ymm4
       vmovdqu  ymmword ptr [rsp+0x50], ymm4
       vmovdqu  ymmword ptr [rsp+0x70], ymm4
       vmovdqa  xmmword ptr [rsp+0x90], xmm4
       xor      eax, eax
       mov      qword ptr [rsp+0xA0], rax
       mov      rdi, rcx
       mov      rsi, r9
       mov      rbx, bword ptr [rsp+0x110]
 
G_M000_IG02:                ;; offset=0x004A
       mov      qword ptr [rsp+0xA0], r8
       mov      gword ptr [rsp+0x98], rdx
       jmp      G_M000_IG24
 
G_M000_IG03:                ;; offset=0x005F
       mov      r14d, dword ptr [rbp+0x08]
       and      r14d, 0x7FFFFFFF
 
G_M000_IG04:                ;; offset=0x006A
       mov      ecx, dword ptr [rbp+0x10]
       lea      rdx, [rsp+0x88]
       lea      r8, [rsp+0x80]
       lea      r9, [rsp+0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime:<EvaluateClosedDefault>g__TryReadInteger|824_0(int,byref,byref,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG06
 
G_M000_IG05:                ;; offset=0x008F
       mov      ecx, dword ptr [rbp+0x0C]
       lea      rdx, [rsp+0x88]
       lea      r8, [rsp+0x78]
       lea      r9, [rsp+0x98]
       call     [Lokad.Lython.Runtime.LythonRuntime:<EvaluateClosedDefault>g__TryReadInteger|824_0(int,byref,byref,byref):bool]
       test     eax, eax
       je       SHORT G_M000_IG06
       lea      r9, [rsp+0x70]
       mov      ecx, r14d
       mov      rdx, qword ptr [rsp+0x80]
       mov      r8, qword ptr [rsp+0x78]
       call     [Lokad.Lython.Runtime.LythonRuntime:TryMachineBinary(int,long,long,byref):bool]
       test     eax, eax
       jne      G_M000_IG37
       lea      ecx, [r14-0x0F]
       cmp      ecx, 5
       jbe      G_M000_IG29
 
G_M000_IG06:                ;; offset=0x00E1
       mov      r15d, dword ptr [rbp+0x10]
 
G_M000_IG07:                ;; offset=0x00E5
       vmovdqu  xmm0, xmmword ptr [rsp+0x88]
       vmovdqu  xmmword ptr [rsp+0x60], xmm0
 
G_M000_IG08:                ;; offset=0x00F4
       test     r15d, r15d
       jne      SHORT G_M000_IG09
       mov      rcx, 0x7FF9CC75FD50
       call     CORINFO_HELP_NEWSFAST
       mov      r13, rax
       mov      rdx, qword ptr [rsp+0xA0]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rsp+0x50], xmm0
       lea      rcx, [rsp+0x50]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rcx, bword ptr [r13+0x08]
       mov      rdx, gword ptr [rsp+0x50]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rsp+0x58]
       mov      dword ptr [r13+0x10], ecx
       jmp      G_M000_IG14
 
G_M000_IG09:                ;; offset=0x0143
       test     r15d, r15d
       jge      SHORT G_M000_IG10
       mov      rcx, gword ptr [rsp+0x98]
       mov      rcx, gword ptr [rcx+0x30]
       mov      eax, r15d
       not      eax
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG40
       mov      eax, r15d
       not      eax
       mov      r13, gword ptr [rcx+8*rax+0x10]
       jmp      G_M000_IG14
 
G_M000_IG10:                ;; offset=0x0171
       mov      rcx, gword ptr [rsp+0x60]
       mov      rax, 0x16AF6401CF0
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG13
       mov      rcx, gword ptr [rsp+0x60]
       mov      rax, 0x16AF6401CF8
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG12
       cmp      qword ptr [rsp+0x68], 0
       jne      SHORT G_M000_IG11
       mov      r13, gword ptr [rsp+0x60]
       jmp      SHORT G_M000_IG14
 
G_M000_IG11:                ;; offset=0x01A8
       lea      rcx, [rsp+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDeferredValue():System.Object:this]
       mov      r13, rax
       jmp      SHORT G_M000_IG14
 
G_M000_IG12:                ;; offset=0x01B8
       mov      rcx, 0x7FF9CC3B6488
       call     CORINFO_HELP_NEWSFAST
       vmovsd   xmm0, qword ptr [rsp+0x68]
       vmovsd   qword ptr [rax+0x08], xmm0
       mov      r13, rax
       mov      gword ptr [rsp+0x60], r13
       xor      ecx, ecx
       mov      qword ptr [rsp+0x68], rcx
       jmp      SHORT G_M000_IG14
 
G_M000_IG13:                ;; offset=0x01E3
       lea      rcx, [rsp+0x60]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r13, rax
 
G_M000_IG14:                ;; offset=0x01F1
       mov      r15d, dword ptr [rbp+0x0C]
 
G_M000_IG15:                ;; offset=0x01F5
       vmovdqu  xmm0, xmmword ptr [rsp+0x88]
       vmovdqu  xmmword ptr [rsp+0x40], xmm0
 
G_M000_IG16:                ;; offset=0x0204
       test     r15d, r15d
       jne      SHORT G_M000_IG17
       mov      rcx, 0x7FF9CC75FD50
       call     CORINFO_HELP_NEWSFAST
       mov      r12, rax
       mov      rdx, qword ptr [rsp+0xA0]
       vxorps   xmm0, xmm0, xmm0
       vmovdqu  xmmword ptr [rsp+0x30], xmm0
       lea      rcx, [rsp+0x30]
       call     [System.Numerics.BigInteger:.ctor(long):this]
       lea      rcx, bword ptr [r12+0x08]
       mov      rdx, gword ptr [rsp+0x30]
       call     CORINFO_HELP_ASSIGN_REF
       mov      ecx, dword ptr [rsp+0x38]
       mov      dword ptr [r12+0x10], ecx
       mov      r8, r12
       jmp      G_M000_IG22
 
G_M000_IG17:                ;; offset=0x0258
       test     r15d, r15d
       jge      SHORT G_M000_IG18
       mov      r8, gword ptr [rsp+0x98]
       mov      rcx, gword ptr [r8+0x30]
       mov      eax, r15d
       not      eax
       cmp      eax, dword ptr [rcx+0x08]
       jae      G_M000_IG40
       mov      eax, r15d
       not      eax
       mov      r8, gword ptr [rcx+8*rax+0x10]
       jmp      G_M000_IG22
 
G_M000_IG18:                ;; offset=0x0286
       mov      rcx, gword ptr [rsp+0x40]
       mov      rax, 0x16AF6401CF0
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG21
       mov      rcx, gword ptr [rsp+0x40]
       mov      rax, 0x16AF6401CF8
       cmp      rcx, gword ptr [rax]
       je       SHORT G_M000_IG20
       cmp      qword ptr [rsp+0x48], 0
       jne      SHORT G_M000_IG19
       mov      r8, gword ptr [rsp+0x40]
       jmp      SHORT G_M000_IG22
 
G_M000_IG19:                ;; offset=0x02BD
       lea      rcx, [rsp+0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishDeferredValue():System.Object:this]
       mov      r8, rax
       jmp      SHORT G_M000_IG22
 
G_M000_IG20:                ;; offset=0x02CD
       mov      rcx, 0x7FF9CC3B6488
       call     CORINFO_HELP_NEWSFAST
       vmovsd   xmm0, qword ptr [rsp+0x48]
       vmovsd   qword ptr [rax+0x08], xmm0
       mov      r8, rax
       mov      gword ptr [rsp+0x40], r8
       xor      ecx, ecx
       mov      qword ptr [rsp+0x48], rcx
       jmp      SHORT G_M000_IG22
 
G_M000_IG21:                ;; offset=0x02F8
       lea      rcx, [rsp+0x40]
       call     [Lokad.Lython.Runtime.LythonRuntime+ExecutableSlot:PublishInteger():System.Object:this]
       mov      r8, rax
 
G_M000_IG22:                ;; offset=0x0306
       mov      rcx, gword ptr [rbp]
       mov      gword ptr [rsp+0x20], rcx
       mov      ecx, r14d
       mov      rdx, r13
       mov      r9, rsi
       call     [Lokad.Lython.Runtime.LythonRuntime:EvaluateBinaryOperator(int,System.Object,System.Object,Lokad.Lython.Runtime.LythonRuntime+ExecutionContext,Lokad.Lython.LythonSourceSpan):System.Object]
       mov      gword ptr [rsp+0x88], rax
 
G_M000_IG23:                ;; offset=0x0326
       xor      eax, eax
       mov      qword ptr [rsp+0x90], rax
 
G_M000_IG24:                ;; offset=0x0330
       mov      rcx, gword ptr [rsp+0x98]
       mov      rcx, gword ptr [rcx+0x98]
       mov      eax, dword ptr [rbx]
       mov      edx, eax
       cmp      edx, dword ptr [rcx+0x08]
       jae      G_M000_IG40
       shl      rdx, 5
       lea      rbp, bword ptr [rcx+rdx+0x10]
       cmp      dword ptr [rbp+0x1C], 46
       jne      G_M000_IG38
 
G_M000_IG25:                ;; offset=0x035F
       inc      eax
       mov      dword ptr [rbx], eax
       mov      r14, gword ptr [rbp]
       mov      r15, gword ptr [rsi+0xA0]
       cmp      byte  ptr [r15], r15b
       mov      rcx, r15
       call     [Lokad.Lython.Runtime.ExecutionState:get_CanContinue():bool:this]
       test     eax, eax
       jne      SHORT G_M000_IG27
 
G_M000_IG26:                ;; offset=0x037E
       mov      rcx, r15
       mov      rdx, r14
       call     [Lokad.Lython.Runtime.ExecutionState:ThrowExecutionFailure(Lokad.Lython.LythonSourceSpan):this]
 
G_M000_IG27:                ;; offset=0x038A
       cmp      dword ptr [rbp+0x1C], 51
       jne      G_M000_IG03
 
G_M000_IG28:                ;; offset=0x0394
       mov      r14d, dword ptr [rbp+0x14]
       jmp      G_M000_IG04
 
G_M000_IG29:                ;; offset=0x039D
       mov      rcx, qword ptr [rsp+0x78]
       cmp      qword ptr [rsp+0x80], rcx
       jge      SHORT G_M000_IG32
 
G_M000_IG30:                ;; offset=0x03AC
       mov      edx, -1
 
G_M000_IG31:                ;; offset=0x03B1
       mov      ecx, r14d
       call     [Lokad.Lython.Runtime.LythonRuntime:CompareOrderedResult(int,int):bool]
       test     eax, eax
       jne      SHORT G_M000_IG35
       mov      rax, 0x16AF64013C8
       mov      rax, gword ptr [rax]
       jmp      SHORT G_M000_IG36
 
G_M000_IG32:                ;; offset=0x03CD
       cmp      qword ptr [rsp+0x80], rcx
       jle      SHORT G_M000_IG34
 
G_M000_IG33:                ;; offset=0x03D7
       mov      edx, 1
       jmp      SHORT G_M000_IG31
 
G_M000_IG34:                ;; offset=0x03DE
       xor      edx, edx
       jmp      SHORT G_M000_IG31
 
G_M000_IG35:                ;; offset=0x03E2
       mov      rax, 0x16AF64013C0
       mov      rax, gword ptr [rax]
 
G_M000_IG36:                ;; offset=0x03EF
       mov      gword ptr [rsp+0x88], rax
       jmp      G_M000_IG23
 
G_M000_IG37:                ;; offset=0x03FC
       mov      rax, qword ptr [rsp+0x70]
       mov      rcx, 0x16AF6401CF0
       mov      rcx, gword ptr [rcx]
       mov      gword ptr [rsp+0x88], rcx
       mov      qword ptr [rsp+0x90], rax
       jmp      G_M000_IG24
 
G_M000_IG38:                ;; offset=0x0423
       mov      rax, gword ptr [rsp+0x88]
       mov      gword ptr [rdi], rax
       mov      rax, qword ptr [rsp+0x90]
       mov      qword ptr [rdi+0x08], rax
       mov      rax, rdi
 
G_M000_IG39:                ;; offset=0x043D
       add      rsp, 168
       pop      rbx
       pop      rbp
       pop      rsi
       pop      rdi
       pop      r12
       pop      r13
       pop      r14
       pop      r15
       ret      
 
G_M000_IG40:                ;; offset=0x0451
       call     CORINFO_HELP_RNGCHKFAIL
       int3     
 
; Total bytes of code 1111

