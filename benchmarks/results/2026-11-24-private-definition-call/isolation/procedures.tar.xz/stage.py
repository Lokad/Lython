from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
root=lab.parents[3]
parent=lab.with_name('private-definition-call-20261124')
comparison=lab/'comparison'
quiet=comparison/'quiet'
quiet.mkdir(parents=True,exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,s:p.write_text(s,encoding='utf-8',newline='\n')
save=lambda p,o:write(p,json.dumps(o,indent=2)+'\n')
meta=read(parent/'comparison/identity.json')
rev=subprocess.check_output(['git','rev-parse','642c8f957'],cwd=root,text=True).strip()
meta['candidate']=rev
meta['purpose']='Use one arithmetic body with static input selection, isolating both annotated control shapes'
jit=read(parent/'isolation-jit/summary.json')
core=parent/'windows-isolated/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'
assert sha(core)==jit['isolated']['coreSHA256']
assert sha(parent/'reference/Lokad.Lython.dll')==jit['production']['coreSHA256']==meta['coreSHA256']['reference']
for name in ('representative.json','jobs.json'):
    shutil.copyfile(parent/'comparison'/name,comparison/name)
    assert sha(comparison/name)==meta['catalogs'][name]['sha256']
for role,files in meta['imageFiles'].items():
    image=lab/role
    image.mkdir(exist_ok=True)
    for name,expected in list(files.items()):
        item=parent/role/name
        assert sha(item)==expected
        shutil.copyfile(core if role=='candidate' and name==core.name else item,image/name)
    if role=='candidate':files[core.name]=sha(core)
    assert len(files)==32 and {p.name:sha(p) for p in image.iterdir()}==files
    for name in (role,role+'-control'):meta['coreSHA256'][name]=files[core.name]
save(comparison/'identity.json',meta)

sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
protocol=root/'benchmarks/cpython-worker.py'
assert sha(protocol)==meta['cpythonWorkerSHA256']
for role in ('reference','candidate'):
    check=comparison/(role+'-verify.json')
    subprocess.run([dotnet,lab/role/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',comparison/'representative.json','--dotnet',dotnet,
        '--python','C:/Python313/python.exe','--python-worker',protocol,'--out',check],env=env,cwd=root,check=True,timeout=85)
    receipt=read(check)
    assert receipt['state']=='Completed' and receipt['caseCount']==6 and receipt['launched']['library']['sha256']==meta['coreSHA256'][role]

collector=(parent/'comparison/quiet/collect.py').read_text(encoding='utf-8').replace('b1598-','b1599-')
compile(collector,'collect.py','exec')
write(quiet/'collect.py',collector)
shutil.copyfile(parent/'comparison/quiet/run.sh',quiet/'run.sh')
assert b'\r' not in (quiet/'run.sh').read_bytes()
payload=quiet/'payload.tar.gz'
with tarfile.open(payload,'w:gz',compresslevel=3) as package:
    for name in ('identity.json','representative.json','jobs.json'):package.add(comparison/name,arcname=name)
    for name in ('run.sh','collect.py'):package.add(quiet/name,arcname=name)
    package.add(lab/'candidate'/core.name,arcname='candidate-core.dll')
save(quiet/'upload.json',dict(root='private-call-isolation-b1599-20261124',reference='private-definition-call-b1598-20261124',
    payloadSHA256=sha(payload),payloadBytes=payload.stat().st_size))
shutil.copyfile(parent/'verified-raw-replicas.json',lab/'verified-raw-replicas.json')
launcher=(parent/'quiet.py').read_text(encoding='utf-8').replace('b1598-private-definition-call','b1599-private-call-isolation').replace('b1598-','b1599-')
launcher=launcher.replace('17*1024*1024','11*1024*1024')
launcher=launcher.replace("'candidate-core.dll','reference-core.dll'}", "'candidate-core.dll'}")
launcher=launcher.replace("if name=='Lokad.Lython.dll':", "if name=='Lokad.Lython.dll' and role=='candidate':")
launcher=launcher.replace("os.link(reference/'candidate'/name,image/name)", "os.link(reference/'reference'/name,image/name)")
compile(launcher,'quiet.py','exec')
write(lab/'quiet.py',launcher)
shutil.copyfile(parent/'summarize.py',lab/'summarize.py')
print('Prepared source-isolated B1599, same reference and seven short lanes')
