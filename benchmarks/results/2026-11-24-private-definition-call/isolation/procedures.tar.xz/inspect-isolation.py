from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess

lab=Path(__file__).resolve().parent
parts=lab/'isolation-jit'
parts.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
identity=read(lab/'comparison/identity.json')
helpers=read(lab.with_name('closed-factory-pairs-entry-20261124')/'comparison/identity.json')['helperFiles']
catalog=lab/'comparison/representative.json'
assert sha(catalog)==identity['catalogs']['representative.json']['sha256']
sdk=Path.home()/'.dotnet11'
new_core=lab/'windows-isolated/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'
results={}
for role, source in (('production','reference'),('initial','candidate'),('isolated','candidate')):
    image=parts/role
    image.mkdir(exist_ok=True)
    files=identity['imageFiles'][source]|helpers
    for name,expected in files.items():
        original=lab/'allocation'/source/name
        assert sha(original)==expected
        shutil.copyfile(new_core if role=='isolated' and name==new_core.name else original,image/name)
    hashes={p.name:sha(p) for p in image.iterdir()}
    assert hashes==files if role!='isolated' else hashes==files|{new_core.name:sha(new_core)}
    trace=parts/(role+'.asm')
    if trace.exists():trace.unlink()
    output=parts/(role+'-allocation.json')
    env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),DOTNET_TieredCompilation='0',
        DOTNET_JitDisasm='EvaluateClosedDefault EvaluateClosedIntegerSequence',DOTNET_JitStdOutFile=str(trace))
    subprocess.run([sdk/'dotnet.exe',image/'ValidatedAllocation.dll',image,catalog,output],env=env,timeout=50,check=True)
    assert all(row['sharedBudgetBaselineRestored'] for row in read(output)['rows'])
    entries={}
    for part in trace.read_text(encoding='utf-8-sig').split('; Assembly listing for method ')[1:]:
        signature,asm=part.split('\n',1)
        if 'LythonRuntime:EvaluateClosed' not in signature:continue
        method=signature.split(':',1)[-1].split('(',1)[0]
        frame=re.search(r'\bsub\s+rsp,\s*(\d+)\b',asm)
        size=re.search(r'Total bytes of code (\d+)',asm)
        entries[method]=dict(stackBytes=int(frame[1]) if frame else None,nativeBytes=int(size[1]),
            callsOperandPolicy=bool(re.search(r'call.*IsArgument',asm)))
    assert len(entries)==(2 if role=='isolated' else 1)
    assert not any(item['callsOperandPolicy'] for item in entries.values())
    results[role]=dict(methods=entries,coreSHA256=hashes[new_core.name])
    print(role, entries,flush=True)
(parts/'summary.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8',newline='\n')
