#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/private-definition-call-20261124
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/private-definition-call-20261124
white='Category!=Stress&(FullyQualifiedName~ExecutableDefinitionPair|FullyQualifiedName~ExecutableCall|FullyQualifiedName~FunctionDefaultConstruction|FullyQualifiedName~ManagedStackGuard)'
public='Category!=Stress&(FullyQualifiedName~NativeDefinitionPair|FullyQualifiedName~PreparedFunctionDefaults|FullyQualifiedName~NativeTupleReturn|FullyQualifiedName~SharedExecutionBudget|FullyQualifiedName~CooperativeCancellation)'
dotnet test tests/Lokad.Lython.Tests -c Release -f net11.0 --filter "$white" --artifacts-path "$lab/ubuntu-fresh" --nologo > "$lab/ubuntu-white-fixed.log" 2>&1 || { tail -42 "$lab/ubuntu-white-fixed.log"; exit 1; }
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net11.0 --filter "$public" --artifacts-path "$lab/ubuntu-fresh" --nologo > "$lab/ubuntu-public-fixed.log" 2>&1 || { tail -42 "$lab/ubuntu-public-fixed.log"; exit 1; }
awk '/Passed!/{count++;print} END{exit count!=2}' "$lab/ubuntu-white-fixed.log" "$lab/ubuntu-public-fixed.log"
