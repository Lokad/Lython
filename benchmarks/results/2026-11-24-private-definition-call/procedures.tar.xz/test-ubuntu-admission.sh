#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/private-definition-call-20261124
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab=/mnt/d/code/Lython/.git/agent-notes/review-20261031/private-definition-call-20261124
project=tests/Lokad.Lython.Tests
dotnet build "$project" -c Release -f net11.0 --no-incremental --artifacts-path "$lab/ubuntu-fresh" --nologo > "$lab/ubuntu-admission-build.log" 2>&1 || { tail -42 "$lab/ubuntu-admission-build.log"; exit 1; }
dotnet test "$project" -c Release -f net11.0 --no-build --filter 'Category!=Stress&FullyQualifiedName~ExecutableDefinitionPair' --artifacts-path "$lab/ubuntu-fresh" --nologo > "$lab/ubuntu-admission.log" 2>&1 || { tail -42 "$lab/ubuntu-admission.log"; exit 1; }
tail -12 "$lab/ubuntu-admission.log"
