from pathlib import Path
import json
import os
import subprocess

lab = Path(__file__).resolve().parent
sdk = Path.home() / '.dotnet11'
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk), PATH=str(sdk) + os.pathsep + os.environ['PATH'])
common = '''def make(index):
    offset = index % 7
    weight = index % 5 + 1
    enabled = index % 3 != 0
    def apply(base):
        return (base + offset) * weight if enabled else base
    def alternate():
        step = (index + 1) % 7
        return lambda base: (base - step) * 2
    return apply, alternate()
'''
cases = [common + '''for index in (0, 1, -1, 9223372036854775807, -9223372036854775808, 1 << 80, True):
    a, b = make(index)
    aa, bb = make(index)
    print(a(100), b(100), a is aa, b is bb, a.__qualname__, b.__qualname__)
''', common.replace('    return apply, alternate()', '''    snapshot = locals()
    result = alternate()
    return apply, result, snapshot['alternate']''') + '''a, b, observed = make(55)
print(a(100), b(100), observed()(100), b is observed(), observed.__name__)
''', common.replace('        step = (index + 1) % 7', '''        step = (index + 1) % 7
        def replace(value):
            nonlocal step
            step = value
        return (lambda base: (base - step) * 2), replace''').replace('        return lambda base: (base - step) * 2\n', '') + '''a, (b, replace) = make(55)
print(b(100))
replace(100)
print(b(100), a(100))
''', '''events=[]
class Seed:
    def __mod__(self, divisor):
        events.append(('mod', divisor))
        return 1
    def __add__(self, value):
        events.append(('add', value))
        return 6
''' + common + '''a, b = make(Seed())
print(a(100), b(100), events)
''']
request = json.dumps(cases)
(lab / 'captured-oracle-input.json').write_text(request+'\n', encoding='utf-8', newline='\n')
for role in ('reference', 'candidate'):
    run = subprocess.run([sdk / 'dotnet.exe', lab / ('probe-'+role) / 'LythonProbe.dll', '--batch-json', '--compare-python', '--python', 'C:/Python313/python.exe'], input=request, env=env, timeout=100, capture_output=True, text=True, encoding='utf-8')
    (lab / ('captured-'+role+'-oracle.jsonl')).write_text(run.stdout, encoding='utf-8', newline='\n')
    outputs = [json.loads(line) for line in run.stdout.splitlines()]
    for i, out in enumerate(outputs):
        print(role, i, out['Matches'], out['Lython']['Success'])
        if not (out['Matches'] and out['Lython']['Success']):
            print(out)
    assert run.returncode == 0,(run.stdout,run.stderr)
    assert len(outputs) == len(cases) and all(item['Compared'] and item['Matches'] and item['Lython']['Success'] for item in outputs)
