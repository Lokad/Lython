from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile

lab=Path(__file__).resolve().parent
root=lab.parents[3]
comparison=lab/'comparison'
quiet=comparison/'quiet'
read=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda payload:hashlib.sha256(payload).hexdigest()
digest=lambda path:sha(path.read_bytes())
meta=read(comparison/'identity.json')
terminal=read(quiet/'terminal-status.json')
summary=read(quiet/'summary.json')
receipt=terminal['receipt']
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode']=='0'
assert all(receipt[k] for k in ('complete','allWorkersJoined','guestFixturesRemoved','quietBeforeAndAfter','archivedAndVerifiedUnderLease'))
assert digest(quiet/'observations.tar.xz')==receipt['archiveSHA256']
assert summary['timedBatches']==196 and len(summary['rows'])==7
assert summary['source']==meta['sourceRevision'] and summary['candidate']==meta['candidate']
assert [(row['case'],row['lane']) for row in summary['rows']]==[tuple(job) for job in read(comparison/'jobs.json')['warm']]
for role,files in meta['imageFiles'].items():
    verify=read(comparison/(role+'-verify.json'))
    assert verify['state']=='Completed' and verify['caseCount']==6
    assert verify['launched']['library']['sha256']==files['Lokad.Lython.dll']==meta['coreSHA256'][role]
    assert len(files)==32 and {p.name:digest(p) for p in (lab/role).iterdir()}==files
    oracle=[json.loads(line) for line in (lab/('captured-'+role+'-oracle.jsonl')).read_text(encoding='utf-8').splitlines()]
    assert len(oracle)==4 and all(item['Matches'] and item['Compared'] and item['Lython']['Success'] for item in oracle)
rows=read(lab/'route-counts.json')['rows']
assert len(rows)==6
row=next(r for r in rows if r['case']=='scripts.captured-rule-closures')
assert row['routes']=={'workspace make_rules':8192,'private-call alternate':8192}
for prefix in ('windows','ubuntu'):
    for key,count in (('white',39),('public',59)):
        assert f'Passed: {count:5d}' in (lab/(prefix+'-'+key+'-fixed.log')).read_text(encoding='utf-8-sig')
    assert 'Passed:    13' in (lab/(prefix+'-admission.log')).read_text(encoding='utf-8-sig')
allocations=read(lab/'allocation-summary-six.json')
assert len(allocations)==6
for role in ('reference','candidate'):
    assert all(x['sharedBudgetBaselineRestored'] for x in read(lab/'allocation'/(role+'-allocation-six.json'))['rows'])
out=root/'benchmarks/results/2026-11-24-private-definition-call'
out.mkdir(exist_ok=True)
for role in ('reference','candidate'):
    core=(lab/role/'Lokad.Lython.dll').read_bytes()
    path=out/(role+'-core.dll.gz')
    path.write_bytes(gzip.compress(core,mtime=0))
    assert sha(gzip.decompress(path.read_bytes()))==meta['coreSHA256'][role]
for source,name in {comparison/'identity.json':'identity.json',quiet/'terminal-status.json':'terminal-status.json',quiet/'summary.json':'summary.json',
                    quiet/'observations.tar.xz':'observations.tar.xz',lab/'allocation-summary-six.json':'allocation-summary.json',
                    lab/'route-counts.json':'route-counts.json',quiet/'storage-custody.json':'storage-custody.json'}.items():
    shutil.copyfile(source,out/name)
(lab/'measured.patch').write_bytes(subprocess.check_output(['git','diff','--binary',meta['sourceRevision'],meta['candidate'],'--','src','tests'],cwd=root))
(lab/'admission-tests.patch').write_bytes(subprocess.check_output(['git','diff','--binary',meta['candidate'],'b9d2f073f','--','tests'],cwd=root))
subprocess.run(['git','diff','--exit-code',meta['candidate'],'b9d2f073f','--','src'],cwd=root,check=True)
procedures=['prepare-route.py','prepare-allocation.py','stage.py','quiet.py','summarize.py','archive.py','measured.patch','test-ubuntu-fixed.sh',
    'comparison/reference-verify.json','comparison/candidate-verify.json','comparison/quiet/launch.log','verified-raw-replicas.json',
    'allocation/reference-allocation-six.json','allocation/candidate-allocation-six.json','allocation/allocations.py',
    'routes.py','captured-oracle.py','captured-oracle-input.json','captured-reference-oracle.jsonl','captured-candidate-oracle.jsonl',
    'windows-white.log','windows-public.log','windows-white-fixed.log','windows-public-fixed.log','ubuntu-public.log','ubuntu-white-fixed.log','ubuntu-public-fixed.log',
    'test-ubuntu-admission.sh','admission-tests.patch','windows-admission.log','ubuntu-admission.log']
with tarfile.open(out/'procedures.tar.xz','w:xz',preset=4) as tar:
    for name in procedures:tar.add(lab/name,arcname=name)
with tarfile.open(out/'procedures.tar.xz') as tar:
    assert all(sha(tar.extractfile(name).read())==digest(lab/name) for name in procedures)
print('Archived B1598, 196 checked batches and exact source images')
