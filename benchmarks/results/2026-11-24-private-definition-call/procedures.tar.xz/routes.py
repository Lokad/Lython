from collections import Counter
from pathlib import Path
import hashlib
import importlib.util
import io
import json
import os
import shutil
import subprocess
import tempfile

lab=Path(__file__).resolve().parent
root=lab.parents[3]
read=lambda path:json.loads(path.read_text(encoding='utf-8-sig'))
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
identity=read(lab/'comparison/identity.json')
image=lab/'diagnostic-image'
image.mkdir(exist_ok=True)
core=lab/'diagnostic-build/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'
observed={}
for name,expected in identity['imageFiles']['candidate'].items():
    source=lab/'candidate'/name
    assert sha(source)==expected
    shutil.copyfile(core if name==core.name else source,image/name)
    observed[name]=sha(image/name)
assert [name for name,hash in observed.items() if hash!=identity['imageFiles']['candidate'][name]]==[core.name]
script=root/'benchmarks/cpython-worker.py'
assert sha(script)==identity['cpythonWorkerSHA256']
spec=importlib.util.spec_from_file_location('worker_protocol',script)
protocol=importlib.util.module_from_spec(spec)
spec.loader.exec_module(protocol)
catalog=lab/'comparison/representative.json'
assert sha(catalog)==identity['catalogs']['representative.json']['sha256']
sdk=Path.home()/'.dotnet11'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
rows=[]
for case in read(catalog)['cases']:
    request=dict(protocolVersion=2,requestId=1,operation='batch',caseId=case['id'],lane='warm',iterations=1,
                 **{key:case[key] for key in ('sourceSha256','fixtureSha256','expectedOutputSha256')})
    payload=io.BytesIO()
    protocol.write_frame(payload,dict(request,operation='verify'))
    protocol.write_frame(payload,dict(request,requestId=2))
    protocol.write_frame(payload,dict(request,requestId=3,lane='warm-async'))
    protocol.write_frame(payload,dict(protocolVersion=2,requestId=4,operation='quit'))
    with tempfile.TemporaryDirectory(prefix='lython-comparison-files-') as fixture:
        capture=subprocess.run([sdk/'dotnet.exe',image/'Lokad.Lython.Benchmarks.dll','--compare','worker','--catalog',catalog],
            input=payload.getvalue(),cwd=fixture,env=env,capture_output=True,timeout=50)
    if capture.returncode:
        (lab/'initial-route-stderr.log').write_bytes(capture.stderr)
        (lab/'initial-route-stdout.bin').write_bytes(capture.stdout)
        raise RuntimeError(capture.stderr.decode('utf-8',errors='replace'))
    frames=io.BytesIO(capture.stdout)
    ready,verified,result,async_result,closed=(protocol.read_frame(frames) for _ in range(5))
    assert ready['status']=='Ready' and next(item for item in ready['libraries'] if Path(item['path']).name==core.name)['sha256']==observed[core.name]
    assert verified['status']=='Equivalent' and verified['completedInvocations']==2
    for response in (result,async_result):
        assert response['status']=='Completed' and response['completedInvocations']==1 and response['actualOutputSha256']==case['expectedOutputSha256']
        assert response.get('actualFilesSha256')==case.get('expectedFilesSha256')
    assert closed['status']=='Closed' and protocol.read_frame(frames) is None
    data=capture.stderr.decode('utf-8').splitlines()
    assert all(line.startswith('LYTHON_ROUTE ') for line in data)
    route=Counter(line.removeprefix('LYTHON_ROUTE ') for line in data)
    rows.append(dict(case=case['id'],routes=route,verified=verified,result=result,asyncResult=async_result))
    print(case['id'],dict(route),flush=True)
assert {p.name:sha(p) for p in image.iterdir()}==observed
(lab/'route-counts.json').write_text(json.dumps(dict(diagnosticOnly=True,imageFiles=observed,rows=rows),indent=2)+'\n',encoding='utf-8')
affected='scripts.captured-rule-closures'
for row in rows:
    target=row['case']==affected
    assert row['routes']['private-call alternate']==(8192 if target else 0), row['routes']
    if target:
        assert row['routes']['workspace make_rules']==8192 and row['routes']['workspace alternate']==0, row['routes']
