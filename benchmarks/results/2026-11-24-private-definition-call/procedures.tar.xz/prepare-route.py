from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import zipfile

lab = Path(__file__).resolve().parent
root = lab.parents[3]
donor = lab.parent / 'closed-factory-pairs-entry-20261124'
source = lab / 'diagnostic-source'
source.mkdir(exist_ok=True)
rev = '689ad2b7c'
reference = '722b49f2d'
read = lambda p: json.loads(p.read_text(encoding='utf-8-sig'))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
write = lambda path, content: path.write_text(content, encoding='utf-8', newline='\n')
archive = lab/'diagnostic-source.zip'
subprocess.run(['git', 'archive', '--format=zip', '--output='+str(archive), rev, 'src/Lokad.Lython', 'Directory.Build.props',
    'Directory.Build.targets', 'Directory.Build.rsp', 'Directory.Packages.props','NuGet.Config','global.json'], cwd=root,check=True)
with zipfile.ZipFile(archive) as package:
    package.extractall(source)
if archive.is_file(): archive.unlink()
changes = {
    'LythonRuntime.Executable.NativeDefinitions.cs':(
        '                Publish(invoke, function);\n                return true;',
        '                Publish(invoke, function);\n                System.Console.Error.WriteLine("LYTHON_ROUTE private-call " + body.Name);\n                return true;'),
    'PyExecutableFunction.cs':(
        '        // after binding and asks the caller to try another execution route.\n        NativeValues buffer = default;',
        '        // after binding and asks the caller to try another execution route.\n'
        '        System.Console.Error.WriteLine("LYTHON_ROUTE workspace " + Name);\n        NativeValues buffer = default;'),
}
for file, (before, after) in changes.items():
    path = source/'src/Lokad.Lython/Runtime'/file
    content = path.read_text(encoding='utf-8-sig')
    assert content.count(before) == 1
    write(path,content.replace(before,after))

candidate = lab/'candidate'
candidate.mkdir(exist_ok=True)
base_image = read(donor/'comparison/identity.json')
files = base_image['imageFiles']['candidate']
assert len(files) == 32
core = lab/'windows/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'
replacement_core='Lokad.Lython.dll'
for name,expected in files.items():
    original = donor/'candidate'/name
    assert sha(original)==expected
    shutil.copyfile(core if name==replacement_core else original,candidate/name)
actual = {p.name:sha(p) for p in candidate.iterdir()}
assert [name for name,expected in files.items() if actual[name]!=expected]==[replacement_core]
comparison=lab/'comparison'
comparison.mkdir(exist_ok=True)
catalog=comparison/'representative.json'
shutil.copyfile(donor/'comparison/representative.json',catalog)
assert sha(catalog)==base_image['catalogs']['representative.json']['sha256']
full=lambda git_ref:subprocess.check_output(['git','rev-parse',git_ref],cwd=root,text=True).strip()
identity=dict(sourceRevision=full(reference),candidate=full(rev),imageFiles={'candidate':actual},
    coreSHA256={'candidate':actual[replacement_core]},catalogs=base_image['catalogs'],cpythonWorkerSHA256=base_image['cpythonWorkerSHA256'])
write(comparison/'identity.json',json.dumps(identity,indent=2)+'\n')
routes=(donor/'routes.py').read_text(encoding='utf-8')
start=routes.index("assert all(row['routes']['direct-pair")
routes=routes[:start]+'''affected='scripts.captured-rule-closures'
for row in rows:
    target=row['case']==affected
    assert row['routes']['private-call alternate']==(8192 if target else 0), row['routes']
    if target:
        assert row['routes']['workspace make_rules']==8192 and row['routes']['workspace alternate']==0, row['routes']
'''
write(lab/'routes.py',routes)
sdk=Path.home()/'.dotnet11'
dotnet=sdk/'dotnet.exe'
env=dict(os.environ,DOTNET_ROOT=str(sdk),DOTNET_ROOT_X64=str(sdk),PATH=str(sdk)+os.pathsep+os.environ['PATH'])
protocol=root/'benchmarks/cpython-worker.py'
assert sha(protocol)==identity['cpythonWorkerSHA256']
subprocess.run([dotnet,candidate/'Lokad.Lython.Benchmarks.dll','--compare','verify','--catalog',catalog,
    '--dotnet',dotnet,'--python','C:/Python313/python.exe','--python-worker',protocol,'--out',comparison/'candidate-verify.json'],
    env=env,cwd=root,check=True,timeout=85)
check=read(comparison/'candidate-verify.json')
assert check['state']=='Completed' and check['caseCount']==6 and check['launched']['library']['sha256']==actual[replacement_core]
print('Candidate image verified all six CPython goldens')
subprocess.run([dotnet,'build',source/'src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-incremental',
    '--artifacts-path',lab/'diagnostic-build','--nologo'],env=env,cwd=source,check=True,timeout=140)
subprocess.run(['C:/Python313/python.exe','-I','-X','utf8',lab/'routes.py'],cwd=root,check=True,timeout=140)
