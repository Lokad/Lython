using Lokad.Lython.Runtime.Numbers;
using System.Numerics;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime;
using Lokad.Lython.Tests.Harness;
using Context = Lokad.Lython.Runtime.LythonRuntime.ExecutionContext;
using ICallable = Lokad.Lython.Runtime.LythonRuntime.ICallable;

namespace Lokad.Lython.Tests;

public sealed class ExecutableStackAdmissionTests
{
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task FrameWorkspaceRefusesBeforeObservableGuestWork(bool asynchronous)
    {
        var budget = new LythonMemoryBudget(1024 * 1024);
        using var owner = budget.CreateScope();
        var context = new Context(new MockLythonHost(), new LythonRunOptions { MemoryBudget = owner });
        var addition = new ObserveAddition();
        var type = new PyType("Left", [], new() { ["__add__"] = addition });
        context.Variables["seed"] = new PyInstance(type);
        var marker = new Sink(0);
        context.Variables["marker"] = marker;
        var code = Compile("marker()\nleft=seed\nright=1\nreturn ("
            + string.Join(",", Enumerable.Range(0, 100)) + ",left+right)\n");
        // The complete frame workspace must be funded before its first effect.
        // Enough remains for the former small initial buffer, but not this frame.
        _ = new FillBudget(budget, 512).Invoke([], code.Instructions[0].Span, context);
        var failure = await Assert.ThrowsAsync<LythonRuntimeException>(async () =>
        {
            if (asynchronous) await LythonRuntime.ExecuteExecutableCodeObjectAsync(code, context);
            else LythonRuntime.ExecuteExecutableCodeObject(code, context, default, null);
        });
        Assert.Same(context.MemoryGovernor.AdmissionFailure, failure);
        Assert.Equal(LythonFailureReason.SharedMemoryAllowance, failure.Attribution?.Reason);
        Assert.Equal(0, marker.Calls);
        Assert.Equal(0, addition.Calls);
        Assert.True(context.MemoryGovernor.LastDeniedReservationBytes > 0);
        Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
        Assert.Null(context.CurrentExecutableFrame);
        owner.Dispose();
        Assert.Equal(0, budget.ReservedBytes);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task NativeCallArgumentsRefuseBeforeInvokingTheConsumer(bool asynchronous)
    {
        var budget = new LythonMemoryBudget(4 * 1024 * 1024);
        using var owner = budget.CreateScope();
        var context = new Context(new MockLythonHost(), new LythonRunOptions
        { MemoryBudget = owner},regexProvider:Utf8RegexProvider.Instance);
        var fill = new FillBudget(budget);
        var sink = new Sink(64);
        var warmup = new Sink(64);
        context.Variables["warmup"] = warmup;
        context.Variables["fill"] = fill;
        context.Variables["sink"] = sink;
        var arguments = string.Join(",", Enumerable.Range(0, 64));
        // Prime operand capacity before pressure. The next native-call packet
        // must get its own admission, regardless of operand implementation.
        var code = Compile("warmup(" + arguments + ")\nfill()\nsink(" + arguments + ")");
        var failure = await Assert.ThrowsAsync<LythonRuntimeException>(async () =>
        {
            if (asynchronous) await LythonRuntime.ExecuteExecutableCodeObjectAsync(code, context);
            else LythonRuntime.ExecuteExecutableCodeObject(code, context, default, null);
        });
        Assert.Same(context.MemoryGovernor.AdmissionFailure, failure);
        Assert.Equal(LythonFailureReason.SharedMemoryAllowance, failure.Attribution?.Reason);
        Assert.Equal(3, failure.Span?.Line);
        Assert.Equal(1, warmup.Calls);
        Assert.Equal(0, sink.Calls);
        Assert.True(context.MemoryGovernor.LastDeniedReservationBytes > 0);
        Assert.Equal(fill.Bytes, context.MemoryGovernor.CurrentAccountedBytes);
        Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
        owner.Dispose();
        Assert.Equal(0, budget.ReservedBytes);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task OperandWorkspaceRemainsFundedUntilItsConsumerFinishes(bool asynchronous)
    {
        var budget = new LythonMemoryBudget(4 * 1024 * 1024);
        using var owner = budget.CreateScope();
        var context = new Context(new MockLythonHost(), new LythonRunOptions
        { MemoryBudget = owner},regexProvider:Utf8RegexProvider.Instance);
        var baseline = budget.ReservedBytes;
        var sink = new Sink(1024, pause: true);
        context.Variables["sink"] = sink;
        var code = Compile("sink(" + string.Join(",", Enumerable.Range(0, 1024)) + ")");
        if (asynchronous)
        {
            var pending = LythonRuntime.ExecuteExecutableCodeObjectAsync(code, context).AsTask();
            try
            {
                await sink.Entered.Task.WaitAsync(TimeSpan.FromSeconds(5));
                Assert.False(pending.IsCompleted);
                Assert.True(budget.ReservedBytes > baseline);
                Assert.True(context.MemoryGovernor.CurrentCommittedBytes > 0);
            }
            finally
            {
                sink.Release.TrySetResult();
                _ = await pending.WaitAsync(TimeSpan.FromSeconds(5));
            }
        }
        else LythonRuntime.ExecuteExecutableCodeObject(code, context, default, null);
        Assert.Equal(1, sink.Calls);
        Assert.Equal(0, context.MemoryGovernor.CurrentAccountedBytes);
        Assert.Equal(baseline, budget.ReservedBytes);
        owner.Dispose();
        Assert.Equal(0, budget.ReservedBytes);
    }

    [Fact]
    public async Task YieldRetainsBufferAndCloseRefundsOnlyThatStorage()
    {
        var budget = new LythonMemoryBudget(4 * 1024 * 1024);
        using var owner = budget.CreateScope();
        var context = new Context(new MockLythonHost(), new LythonRunOptions
        { MemoryBudget = owner},regexProvider:Utf8RegexProvider.Instance);
        var code = Compile("result=([" + string.Join(",", Enumerable.Range(0, 1024)) + "] for i in source)");
        var operation = Assert.Single(code.Constants.OfType<ExecutableCreateGeneratorExpression>());
        var generator = await LythonRuntime.PyGenerator.CreateExpressionAsync(operation.CodeObject, context,
            new PyTuple([BigInteger.Zero]), operation.OuterSpan, operation.OuterSpan, true);
        var initial = budget.ReservedBytes;
        var item = await generator.TryMoveNextAsync();
        Assert.True(item.HasValue);
        var retained = Assert.IsType<PyList>(item.Value);
        var grown = budget.ReservedBytes;
        Assert.True(grown >= initial + retained.CommittedStorageBytes);
        Assert.True(generator.TryGetMember("close", out var close));
        _ = await Assert.IsAssignableFrom<ICallable>(close).InvokeAsync([], operation.OuterSpan, context);
        var remaining = budget.ReservedBytes;
        Assert.True(remaining < grown);
        Assert.True(remaining >= retained.CommittedStorageBytes);
        Assert.Equal(1024, retained.Count);
        Assert.Equal(new BigInteger(1023), PyNumberOps.GetInteger(retained[1023]));
        Assert.True(budget.ReservedBytes > 0);
        owner.Dispose();
        Assert.Equal(0, budget.ReservedBytes);
    }

    private static ExecutableCodeObject Compile(string source)
    {
        var frontend = LythonFrontend.Compile(source,regexProvider:Utf8RegexProvider.Instance);
        Assert.NotNull(frontend.Script);
        return ExecutableScript.Compile(LoweredScript.Lower(frontend.Script)).EntryPoint;
    }

    private sealed class FillBudget(LythonMemoryBudget budget, long headroom = 64) : ICallable
    {
        internal long Bytes;
        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, Context context)
        {
            var governor = context.MemoryGovernor;
            // Leave only small control headroom. A new native-call argument
            // packet exceeds it; pre-existing operand capacity remains owned.
            Bytes = budget.LimitBytes!.Value - governor.CurrentAccountedBytes - headroom;
            governor.Reserve(Bytes, span);
            governor.Commit(Bytes);
            return PyNone.Instance;
        }
    }

    private sealed class ObserveAddition : ICallable
    {
        internal int Calls;
        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, Context context)
        {
            Calls++;
            return BigInteger.One;
        }
    }

    private sealed class Sink(int count, bool pause = false) : ICallable
    {
        internal int Calls;
        internal TaskCompletionSource Entered = new(TaskCreationOptions.RunContinuationsAsynchronously);
        internal TaskCompletionSource Release = new(TaskCreationOptions.RunContinuationsAsynchronously);
        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, Context context)
        {
            Calls++;
            Assert.Equal(count, arguments.Length);
            for (var i = 0; i < count; i++) Assert.Equal(new BigInteger(i), PyNumberOps.GetInteger(arguments[i].Value));
            return PyNone.Instance;
        }
        public async ValueTask<object> InvokeAsync(CallArgumentValue[] arguments, LythonSourceSpan span, Context context)
        {
            if (pause)
            {
                Entered.TrySetResult();
                await Release.Task.ConfigureAwait(false);
            }
            return Invoke(arguments, span, context);
        }
    }
}
