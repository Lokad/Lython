using System.Numerics;
using Lokad.Lython.Runtime.Numbers;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal sealed class PyRegexFindIterator : PyIteratorBase, IDisposable
    {
        private readonly RePatternObject _pattern;
        private readonly RegexSubjectRange _range;
        private readonly ExecutionContext _context;
        private readonly LythonSourceSpan _span;
        private RegexMatcher.PreparedSubject? _subject;
        private ILythonRegexCursor? _cursor;
        private RegexScalarPosition _position;
        private bool _finished;
        internal PyRegexFindIterator? NextResource;

        public PyRegexFindIterator(RePatternObject pattern, RegexSubjectRange range, ExecutionContext context, LythonSourceSpan span)
        {
            ChargeIteratorValue(context.MemoryGovernor, span);
            _pattern = pattern; _range = range; _context = context; _span = span;
        }

        public override bool TryMoveNext([MaybeNullWhen(false)] out object value)
        {
            _context.CheckExecution(_span);
            value = PyNone.Instance;
            if (_finished || !_range.IsValid) return false;
            try
            {
                if (_subject is null)
                {
                    _subject = RegexMatcher.Prepare(_pattern, _range, _context, _span);
                    _cursor = _subject.Find();
                    _context.State.TrackRegexIterator(this);
                }
                if (!_subject.Next(_cursor!)) { Dispose(); return false; }
                value = RegexMatcher.CreateMatchObject(_pattern, _range, _subject, ref _position, _context, _span);
                return true;
            }
            catch { Dispose(); throw; }
        }

        public void Dispose()
        {
            if (_finished) return;
            _finished = true;
            _context.State.UntrackRegexIterator(this);
            var cursor = _cursor; _cursor = null;
            var subject = _subject; _subject = null;
            try { cursor?.Dispose(); }
            finally { subject?.Dispose(); }
        }

        public override PyString RenderPython(PyRenderingContext context) => PyString.FromString("<callable_iterator object>");
    }

    internal static partial class ReMatchMembers
    {
        // N17: hot fixed signatures hoisted per family (see ListMembers).
        private static readonly LythonCallableSignature MatchGroupsSignature = LythonCallableSignature.Create("match.groups", ["default"], 0);
        private static readonly LythonCallableSignature MatchGroupDictSignature = LythonCallableSignature.Create("match.groupdict", ["default"], 0);
        private static readonly LythonCallableSignature MatchExpandSignature = LythonCallableSignature.Create("match.expand", ["template"]);
        private static readonly LythonCallableSignature MatchStartSignature = LythonCallableSignature.Create("match.start", ["group"], 0, ArgumentCountLimit.AtMost(1), LythonVariadicParameters.None, 1);
        private static readonly LythonCallableSignature MatchEndSignature = LythonCallableSignature.Create("match.end", ["group"], 0, ArgumentCountLimit.AtMost(1), LythonVariadicParameters.None, 1);
        private static readonly LythonCallableSignature MatchSpanSignature = LythonCallableSignature.Create("match.span", ["group"], 0, ArgumentCountLimit.AtMost(1), LythonVariadicParameters.None, 1);
        private static readonly LythonCallableSignature MatchGetItemSignature = LythonCallableSignature.Create("match.__getitem__", ["key"], 1, ArgumentCountLimit.AtMost(1), LythonVariadicParameters.None, 1);
        private readonly record struct RegexGroupBounds(BigInteger Start, BigInteger End);

        private static readonly ReceiverMethod GroupMethod = new(LythonCallableSignature.Create("bound method"),
            static (receiver, arguments, span, context) => GroupCoreAsync((ReMatchObject)receiver, arguments, context, span, false).GetAwaiter().GetResult(),
            static (receiver, arguments, span, context) => GroupCoreAsync((ReMatchObject)receiver, arguments, context, span, true));
        private static readonly ReceiverMethod GetItemMethod = new(MatchGetItemSignature,
            static (receiver, arguments, span, context) => GetSubscript((ReMatchObject)receiver, arguments.Span[0]!, span, context),
            static (receiver, arguments, span, context) => GetSubscriptAsync((ReMatchObject)receiver, arguments.Span[0]!, span, context));
        private static readonly ReceiverMethod GroupsMethod = new(MatchGroupsSignature,
            static (receiver, arguments, span, context) => Groups((ReMatchObject)receiver, arguments.Length == 1 ? arguments.Span[0]! : PyNone.Instance, context, span));
        private static readonly ReceiverMethod GroupDictMethod = new(MatchGroupDictSignature,
            static (receiver, arguments, span, context) => GroupDictionary((ReMatchObject)receiver, arguments.Length == 1 ? arguments.Span[0]! : PyNone.Instance, context, span));
        private static readonly ReceiverMethod ExpandMethod = new(MatchExpandSignature,
            static (receiver, arguments, span, context) =>
            {
                if (!PyStringOps.TryAsString(arguments.Span[0]!, out var template))
                    throw new LythonRuntimeException("TypeError", "match.expand(template) expects one string argument.", span);
                return ExpandReplacementTemplate((ReMatchObject)receiver, template, context, span);
            });
        private static readonly ReceiverMethod StartMethod = new(MatchStartSignature,
            static (receiver, arguments, span, context) => GetBoundsCoreAsync((ReMatchObject)receiver, arguments, context, span, false).GetAwaiter().GetResult().Start,
            static async (receiver, arguments, span, context) => (await GetBoundsCoreAsync((ReMatchObject)receiver, arguments, context, span, true).ConfigureAwait(false)).Start);
        private static readonly ReceiverMethod EndMethod = new(MatchEndSignature,
            static (receiver, arguments, span, context) => GetBoundsCoreAsync((ReMatchObject)receiver, arguments, context, span, false).GetAwaiter().GetResult().End,
            static async (receiver, arguments, span, context) => (await GetBoundsCoreAsync((ReMatchObject)receiver, arguments, context, span, true).ConfigureAwait(false)).End);
        private static readonly ReceiverMethod SpanMethod = new(MatchSpanSignature,
            static (receiver, arguments, span, context) => BoundsTuple(GetBoundsCoreAsync((ReMatchObject)receiver, arguments, context, span, false).GetAwaiter().GetResult(), context, span),
            static async (receiver, arguments, span, context) => BoundsTuple(await GetBoundsCoreAsync((ReMatchObject)receiver, arguments, context, span, true).ConfigureAwait(false), context, span));

        internal static ReceiverMethod? GetMethod(string name) => name switch
        {
            "group" => GroupMethod,
            "__getitem__" => GetItemMethod,
            "groups" => GroupsMethod,
            "groupdict" => GroupDictMethod,
            "expand" => ExpandMethod,
            "start" => StartMethod,
            "end" => EndMethod,
            "span" => SpanMethod,
            _ => null,
        };

        public static bool TryGetMember(ReMatchObject match, string name, ExecutionContext context, LythonSourceSpan span, [MaybeNullWhen(false)] out object value)
        {
            if (GetMethod(name) is { } method) { value = method.Bind(match); return true; }
            value = name switch
            {
                "__module__" => LythonRuntime.ExceptionTypeValue.SharedModuleLabel("re"),
                "re" => match.Pattern,
                "string" => match.String,
                "pos" => new BigInteger(match.Pos),
                "endpos" => new BigInteger(match.EndPos),
                "lastindex" => LastIndex(match),
                "lastgroup" => LastGroup(match),
                "regs" => Registers(match, context, span),
                _ => MissingMemberValue.Instance,
            };
            return !ReferenceEquals(value, MissingMemberValue.Instance);
        }

        private static object Registers(ReMatchObject match, ExecutionContext context, LythonSourceSpan span)
            => CreateTuple(match.CaptureSlotCount, i =>
                CreateTuple(2, j => new BigInteger(j == 0 ? match.Captures[i].Start : match.Captures[i].End), context, span), context, span);

        private static object Groups(ReMatchObject match, object defaultValue, ExecutionContext context, LythonSourceSpan span)
            => CreateTuple(match.CaptureSlotCount - 1,
                i => ResolveIndexedGroup(match, i + 1, span, context, defaultValue), context, span);

        private static object GroupDictionary(ReMatchObject match, object defaultValue, ExecutionContext context, LythonSourceSpan span)
        {
            var dict = new PyDict(match.NamedGroups.Count, context.MemoryGovernor, span);
            foreach (var entry in match.NamedGroups)
                dict.SetItem(entry.Key, ResolveIndexedGroup(match, entry.Value, span, context, defaultValue));
            return dict;
        }

        private static object BoundsTuple(RegexGroupBounds bounds, ExecutionContext context, LythonSourceSpan span)
            => CreateTuple(2, i => i == 0 ? bounds.Start : bounds.End, context, span);

        internal static object GetSubscript(ReMatchObject match, object key, LythonSourceSpan span, ExecutionContext? context)
            => GetSubscriptCoreAsync(match, key, span, context, false).GetAwaiter().GetResult();

        internal static ValueTask<object> GetSubscriptAsync(ReMatchObject match, object key, LythonSourceSpan span, ExecutionContext context)
            => GetSubscriptCoreAsync(match, key, span, context, true);

        private static async ValueTask<object> GetSubscriptCoreAsync(ReMatchObject match, object key, LythonSourceSpan span, ExecutionContext? context, bool asynchronous)
        {
            key = await CoerceGroupKeyAsync(key, context, span, asynchronous).ConfigureAwait(false);
            return TryResolveGroupIndex(match, key, span, out var index)
                ? ResolveIndexedGroup(match, index, span, context)
                : throw new LythonRuntimeException("IndexError", "no such group", span);
        }

        private static async ValueTask<object> GroupCoreAsync(ReMatchObject match, ReadOnlyMemory<object?> arguments, ExecutionContext context, LythonSourceSpan span, bool asynchronous)
        {
            if (arguments.Length == 0)
            {
                return match.MaterializeGroup(0, context, span);
            }
            if (arguments.Length == 1)
            {
                return await GetSubscriptCoreAsync(match, arguments.Span[0]!, span, context, asynchronous).ConfigureAwait(false);
            }

            if (!asynchronous)
                return CreateTuple(arguments.Length, i => GetSubscript(match, arguments.Span[i]!, span, context), context, span);
            return await CreateTupleAsync(arguments.Length,
                i => GetSubscriptAsync(match, arguments.Span[i]!, span, context), context, span).ConfigureAwait(false);
        }

        private static async ValueTask<RegexGroupBounds> GetBoundsCoreAsync(ReMatchObject match, ReadOnlyMemory<object?> arguments, ExecutionContext context, LythonSourceSpan span, bool asynchronous)
        {
            var key = await CoerceGroupKeyAsync(arguments.Length == 0 ? BigInteger.Zero : arguments.Span[0]!, context, span, asynchronous).ConfigureAwait(false);
            return ResolveGroupBounds(match, key, span);
        }

        private static async ValueTask<object> CoerceGroupKeyAsync(object key, ExecutionContext? context, LythonSourceSpan span, bool asynchronous)
        {
            if (context is null || key is not PyInstance instance ||
                !instance.Type.TryLookupInMro("__index__", 0, out var rawValue, out _))
            {
                return key;
            }

            // Numeric protocol slots come from the type, bypassing instance
            // attributes and __getattr__/__getattribute__ as Python does.
            var member = asynchronous
                ? await PyAttributeLookup.BindForInstanceAsync(instance, rawValue, context, span).ConfigureAwait(false)
                : PyAttributeLookup.BindForInstance(instance, rawValue, context, span);
            if (member is not ICallable callable)
            {
                throw new LythonRuntimeException("TypeError", "'" + UnboundTypeMethod.PythonTypeName(member, context) + "' object is not callable", span);
            }
            var converted = asynchronous
                ? await callable.InvokeAsync([], span, context).ConfigureAwait(false)
                : callable.Invoke([], span, context);
            if (!PyNumberOps.TryAsInteger(converted, out var integer))
            {
                throw new LythonRuntimeException("TypeError", "__index__ returned non-int (type " + UnboundTypeMethod.PythonTypeName(converted, context) + ")", span);
            }
            return integer;
        }

        private static object ResolveIndexedGroup(ReMatchObject match, int index, LythonSourceSpan span, ExecutionContext? context)
            => ResolveIndexedGroup(match, index, span, context, PyNone.Instance);

        private static object ResolveIndexedGroup(ReMatchObject match, int index, LythonSourceSpan span,
            ExecutionContext? context, object defaultValue)
        {
            if (index < 0 || index >= match.CaptureSlotCount)
                throw new LythonRuntimeException("IndexError", "Regex group index is out of range.", span);
            return match.Captures[index].StartByte < 0 ? defaultValue : match.MaterializeGroup(index, context, span);
        }

        private static RegexGroupBounds ResolveGroupBounds(ReMatchObject match, object group, LythonSourceSpan span)
        {
            if (TryResolveGroupIndex(match, group, span, out var index))
            {
                var capture = match.Captures[index];
                return new RegexGroupBounds(capture.Start, capture.End);
            }
            throw new LythonRuntimeException("IndexError", "no such group", span);
        }

        private static bool TryResolveGroupIndex(ReMatchObject match, object group, LythonSourceSpan span, out int index)
        {
            index = group switch
            {
                _ when PyNumberOps.TryAsInteger(group, out var integer) => ResolveIntegerGroupIndex(match, integer, span),
                _ when PyStringOps.TryAsString(group, out var nameText) => match.NamedGroups.TryGetValue(nameText, out var namedIndex)
                    ? namedIndex
                    : throw new LythonRuntimeException("IndexError", $"Regex group '{nameText.AsString()}' is not defined.", span),
                _ => int.MinValue
            };

            if (index == int.MinValue)
            {
                return false;
            }

            if (index < 0 || index >= match.CaptureSlotCount)
            {
                throw new LythonRuntimeException("IndexError", "Regex group index is out of range.", span);
            }

            return true;
        }

        private static int ResolveIntegerGroupIndex(ReMatchObject match, BigInteger index, LythonSourceSpan span)
        {
            // Validate the Python integer before narrowing: enormous guest
            // indices must stay catchable IndexErrors, never CLR overflows.
            if (index < 0 || index >= match.CaptureSlotCount)
            {
                throw new LythonRuntimeException("IndexError", "Regex group index is out of range.", span);
            }

            return (int)index;
        }

        private static object LastIndex(ReMatchObject match)
            => match.LastCapturedIndex is { } index ? new BigInteger(index) : PyNone.Instance;

        private static object LastGroup(ReMatchObject match)
        {
            var lastIndex = LastIndex(match);
            if (lastIndex is not BigInteger index)
            {
                return PyNone.Instance;
            }

            foreach (var entry in match.NamedGroups)
            {
                if (entry.Value == (int)index)
                {
                    return entry.Key;
                }
            }

            return PyNone.Instance;
        }

    }

    internal static class RePatternMembers
    {
        // N17: hot fixed signatures hoisted per family (see ListMembers).
        private static readonly LythonCallableSignature PatternSearchSignature = LythonCallableSignature.Create("pattern.search", ["string", "pos", "endpos"], 1);
        private static readonly LythonCallableSignature PatternMatchSignature = LythonCallableSignature.Create("pattern.match", ["string", "pos", "endpos"], 1);
        private static readonly LythonCallableSignature PatternFullMatchSignature = LythonCallableSignature.Create("pattern.fullmatch", ["string", "pos", "endpos"], 1);
        private static readonly LythonCallableSignature PatternFindAllSignature = LythonCallableSignature.Create("pattern.findall", ["string", "pos", "endpos"], 1);
        private static readonly LythonCallableSignature PatternFindIterSignature = LythonCallableSignature.Create("pattern.finditer", ["string", "pos", "endpos"], 1);
        private static readonly LythonCallableSignature PatternSubSignature = LythonCallableSignature.Create("pattern.sub", ["repl", "string", "count", "pos", "endpos"], 2);
        private static readonly LythonCallableSignature PatternSubnSignature = LythonCallableSignature.Create("pattern.subn", ["repl", "string", "count", "pos", "endpos"], 2);
        private static readonly LythonCallableSignature PatternSplitSignature = LythonCallableSignature.Create("pattern.split", ["string", "maxsplit", "pos", "endpos"], 1);
        public static bool TryGetMember(RePatternObject pattern, string name, [MaybeNullWhen(false)] out object value)
        {
            value = name switch
            {
                "pattern" => pattern.Pattern,
                "flags" => new BigInteger(pattern.Flags),
                "groups" => new BigInteger(Math.Max(0, pattern.CaptureSlotCount - 1)),
                "groupindex" => CreateGroupIndex(pattern),
                "search" => BoundCallable.CreateWithPresence((arguments, span, context) => ExecuteMatch(pattern, arguments, span, context, LythonRegexMatchMode.Search), PatternSearchSignature),
                "match" => BoundCallable.CreateWithPresence((arguments, span, context) => ExecuteMatch(pattern, arguments, span, context, LythonRegexMatchMode.Match), PatternMatchSignature),
                "fullmatch" => BoundCallable.CreateWithPresence((arguments, span, context) => ExecuteMatch(pattern, arguments, span, context, LythonRegexMatchMode.FullMatch), PatternFullMatchSignature),
                "findall" => BoundCallable.CreateWithPresence((arguments, span, context) => ExecuteFindAll(pattern, arguments, span, context), PatternFindAllSignature),
                "finditer" => BoundCallable.CreateWithPresence((arguments, span, context) => ExecuteFindIter(pattern, arguments, span, context), PatternFindIterSignature),
                "sub" => BoundCallable.CreateWithPresence((arguments, span, context) => ExecuteSub(pattern, arguments, span, context, RegexSubstitutionMode.TextOnly), PatternSubSignature, (arguments, span, context) => ExecuteSubCoreAsync(pattern, arguments, span, context, RegexSubstitutionMode.TextOnly, true)),
                "subn" => BoundCallable.CreateWithPresence((arguments, span, context) => ExecuteSub(pattern, arguments, span, context, RegexSubstitutionMode.TextAndCount), PatternSubnSignature, (arguments, span, context) => ExecuteSubCoreAsync(pattern, arguments, span, context, RegexSubstitutionMode.TextAndCount, true)),
                "split" => BoundCallable.CreateWithPresence((arguments, span, context) => ExecuteSplit(pattern, arguments, span, context), PatternSplitSignature),
                _ => MissingMemberValue.Instance,
            };

            return !ReferenceEquals(value, MissingMemberValue.Instance);
        }

        private static PyDict CreateGroupIndex(RePatternObject pattern)
        {
            var dict = new PyDict();
            foreach (var entry in pattern.NamedGroups)
            {
                dict.SetItem(entry.Key, new BigInteger(entry.Value));
            }

            return dict;
        }

        private static object ExecuteMatch(
            RePatternObject pattern,
            BoundCallArguments bound,
            LythonSourceSpan span,
            ExecutionContext context,
            LythonRegexMatchMode operation)
        {
            var arguments = bound.Values;
            context.CheckExecution(span);
            if (arguments.Length is < 1 or > 3 || !PyStringOps.TryAsString(arguments[0], out var text))
            {
                throw new LythonRuntimeException("TypeError", "Compiled regex method expects string, optional pos, and optional endpos.", span);
            }

            var range = RegexCompiler.CreateSubjectRange(
                text,
                bound.Assigned[1] ? RegexCompiler.ParsePosition(arguments[1], span, context) : 0,
                bound.Assigned[2] ? RegexCompiler.ParsePosition(arguments[2], span, context) : text.Length);
            return RegexMatcher.Match(pattern, range, operation, span, context);
        }

        private static object ExecuteFindAll(RePatternObject pattern, BoundCallArguments bound, LythonSourceSpan span, ExecutionContext context)
        {
            var arguments = bound.Values;
            context.CheckExecution(span);
            if (arguments.Length is < 1 or > 3 || !PyStringOps.TryAsString(arguments[0], out var text))
            {
                throw new LythonRuntimeException("TypeError", "pattern.findall(string[, pos[, endpos]]) expects a string argument.", span);
            }

            var range = RegexCompiler.CreateSubjectRange(
                text,
                bound.Assigned[1] ? RegexCompiler.ParsePosition(arguments[1], span, context) : 0,
                bound.Assigned[2] ? RegexCompiler.ParsePosition(arguments[2], span, context) : text.Length);
            return RegexMatcher.CreateFindAllResult(pattern, range, span, context);
        }

        private static object ExecuteFindIter(RePatternObject pattern, BoundCallArguments bound, LythonSourceSpan span, ExecutionContext context)
        {
            var arguments = bound.Values;
            context.CheckExecution(span);
            if (arguments.Length is < 1 or > 3 || !PyStringOps.TryAsString(arguments[0], out var text))
            {
                throw new LythonRuntimeException("TypeError", "pattern.finditer(string[, pos[, endpos]]) expects a string argument.", span);
            }

            var range = RegexCompiler.CreateSubjectRange(
                text,
                bound.Assigned[1] ? RegexCompiler.ParsePosition(arguments[1], span, context) : 0,
                bound.Assigned[2] ? RegexCompiler.ParsePosition(arguments[2], span, context) : text.Length);
            // Finditer shells charge per live instance like other iterator factories.
            PyIteratorBase.ChargeIteratorValue(context.MemoryGovernor, span);
            var findIter = RegexMatcher.CreateFindIterMatches(pattern, range, context, span);
            return findIter;
        }

        private static object ExecuteSub(RePatternObject pattern, BoundCallArguments bound, LythonSourceSpan span, ExecutionContext context, RegexSubstitutionMode mode)
            => ExecuteSubCoreAsync(pattern, bound, span, context, mode, false).GetAwaiter().GetResult();

        private static ValueTask<object> ExecuteSubCoreAsync(RePatternObject pattern, BoundCallArguments bound, LythonSourceSpan span,
            ExecutionContext context, RegexSubstitutionMode mode, bool asynchronous)
        {
            var arguments = bound.Values;
            context.CheckExecution(span);
            var operationName = mode == RegexSubstitutionMode.TextAndCount ? "pattern.subn" : "pattern.sub";
            if (arguments.Length is < 2 or > 5 || !PyStringOps.TryAsString(arguments[1], out var text))
            {
                throw new LythonRuntimeException("TypeError", mode == RegexSubstitutionMode.TextAndCount
                    ? "pattern.subn(replacement, string[, count[, pos[, endpos]]]) expects replacement, text string, and optional count/pos/endpos."
                    : "pattern.sub(replacement, string[, count[, pos[, endpos]]]) expects replacement, text string, and optional count/pos/endpos.", span);
            }

            var replacement = arguments[0];
            if (!PyStringOps.TryAsString(replacement, out _) && replacement is not ICallable)
            {
                throw new LythonRuntimeException("TypeError", mode == RegexSubstitutionMode.TextAndCount
                    ? "pattern.subn(...) replacement must be a string or callable."
                    : "pattern.sub(...) replacement must be a string or callable.", span);
            }

            var count = bound.Assigned[2] ? RegexCompiler.ParseExplicitInt(arguments[2], "count", operationName, span, context) : 0;
            var range = RegexCompiler.CreateSubjectRange(
                text,
                bound.Assigned[3] ? RegexCompiler.ParsePosition(arguments[3], span, context) : 0,
                bound.Assigned[4] ? RegexCompiler.ParsePosition(arguments[4], span, context) : text.Length);
            return asynchronous ? RegexMatcher.ExecuteSubstituteAsync(pattern, replacement, range, count, span, context, mode)
                : new ValueTask<object>(RegexMatcher.ExecuteSubstitute(pattern, replacement, range, count, span, context, mode));
        }

        private static object ExecuteSplit(RePatternObject pattern, BoundCallArguments bound, LythonSourceSpan span, ExecutionContext context)
        {
            var arguments = bound.Values;
            context.CheckExecution(span);
            if (arguments.Length is < 1 or > 4 || !PyStringOps.TryAsString(arguments[0], out var text))
            {
                throw new LythonRuntimeException("TypeError", "pattern.split(string[, maxsplit[, pos[, endpos]]]) expects a string and optional maxsplit/pos/endpos.", span);
            }

            var maxSplit = bound.Assigned[1] ? RegexCompiler.ParseExplicitInt(arguments[1], "maxsplit", "pattern.split", span, context) : 0;
            var range = RegexCompiler.CreateSubjectRange(
                text,
                bound.Assigned[2] ? RegexCompiler.ParsePosition(arguments[2], span, context) : 0,
                bound.Assigned[3] ? RegexCompiler.ParsePosition(arguments[3], span, context) : text.Length);
            return RegexMatcher.Split(pattern, range, maxSplit, span, context);
        }
    }

}
