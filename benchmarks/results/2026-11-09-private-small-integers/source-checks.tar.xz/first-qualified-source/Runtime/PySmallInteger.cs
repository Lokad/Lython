using System.Numerics;

namespace Lokad.Lython.Runtime;

// Private guest representation. CLR ingress remains unchanged; public projection
// materializes BigInteger under the result owner's admission before allocation.
internal readonly record struct PySmallInteger(int Value)
{
    internal static object Box(BigInteger value)
        => value >= int.MinValue && value <= int.MaxValue ? new PySmallInteger((int)value) : value;

    internal static object Box(long value)
        => value >= int.MinValue && value <= int.MaxValue ? new PySmallInteger((int)value) : new BigInteger(value);
}
