using System.Buffers;
using System.Globalization;
using System.Numerics;
using System.Text;
using Lokad.Lython.Runtime.Numbers;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal enum TextEncodingMode
    {
        Utf8,
        Utf8Bom,
        Latin1,
        Ascii,
        Windows1252,
        Utf16,
        Utf16LittleEndian,
        Utf16BigEndian,
    }

    private readonly record struct BoundOpenArguments(object[] Values, ArgumentPresence Assigned, int Count)
    {
        public static BoundOpenArguments From(BoundCallArguments bound)
        {
            var count = bound.Assigned.Length;
            while (count > 0 && !bound.Assigned[count - 1])
            {
                count--;
            }

            return new BoundOpenArguments(bound.Values, bound.Assigned, count);
        }
    }

    internal enum TextFileOperation
    {
        Read,
        Write,
        Append,
    }

    private readonly record struct TextOpenArguments(
        PyString Path,
        TextFileOperation Operation,
        TextEncodingMode EncodingMode,
        TextErrorMode Errors,
        TextNewlineMode Newline,
        bool Binary);

    private static object Open(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        => Open(BindPositionalOpenArguments(arguments, span), span, context);

    private static object Open(BoundOpenArguments arguments, LythonSourceSpan span, ExecutionContext context)
    {
        var (path, operation, encodingMode, errors, newline, binary) = ParseOpenArgumentsAsync(arguments, span, context, false).GetAwaiter().GetResult();
        using var scratch = PathOps.ReserveWorking(path, context, span);
        var pathBytes = checked(64L + 2L * path.ByteLength);
        context.MemoryGovernor.Reserve(pathBytes, span); context.MemoryGovernor.Commit(pathBytes);
        if (binary) return ExecutionContext.BinaryFileHandle.OpenAsync(path.AsString(), operation, context, span, false).GetAwaiter().GetResult();
        return operation switch
        {
            TextFileOperation.Read => ExecutionContext.TextFileHandle.ForRead(path.AsString(), context, encodingMode, errors, newline),
            TextFileOperation.Write => ExecutionContext.TextFileHandle.ForWrite(path.AsString(), context, encodingMode, errors, newline),
            TextFileOperation.Append => ExecutionContext.TextFileHandle.ForAppend(path.AsString(), context, encodingMode, errors, newline),
            _ => throw new ArgumentOutOfRangeException(nameof(operation), operation, "Unknown text file operation."),
        };
    }

    private static async ValueTask<object> OpenAsync(BoundOpenArguments arguments, LythonSourceSpan span, ExecutionContext context)
    {
        var (path, operation, encodingMode, errors, newline, binary) = await ParseOpenArgumentsAsync(arguments, span, context, true).ConfigureAwait(false);
        using var scratch = PathOps.ReserveWorking(path, context, span);
        var pathBytes = checked(64L + 2L * path.ByteLength);
        context.MemoryGovernor.Reserve(pathBytes, span); context.MemoryGovernor.Commit(pathBytes);
        if (binary) return await ExecutionContext.BinaryFileHandle.OpenAsync(path.AsString(), operation, context, span, true).ConfigureAwait(false);
        return operation switch
        {
            TextFileOperation.Read => await ExecutionContext.TextFileHandle.ForReadAsync(path.AsString(), context, encodingMode, errors, newline).ConfigureAwait(false),
            TextFileOperation.Write => await ExecutionContext.TextFileHandle.ForWriteAsync(path.AsString(), context, encodingMode, errors, newline).ConfigureAwait(false),
            TextFileOperation.Append => await ExecutionContext.TextFileHandle.ForAppendAsync(path.AsString(), context, encodingMode, errors, newline).ConfigureAwait(false),
            _ => throw new ArgumentOutOfRangeException(nameof(operation), operation, "Unknown text file operation."),
        };
    }

    private static async ValueTask<TextOpenArguments> ParseOpenArgumentsAsync(BoundOpenArguments boundArguments, LythonSourceSpan span, ExecutionContext context, bool asynchronous)
    {
        var arguments = boundArguments.Values;
        if (boundArguments.Count is < 1 or > 8)
        {
            throw new LythonRuntimeException("TypeError", "open(file/path[, mode][, buffering][, encoding][, errors][, newline][, closefd][, opener]) expects a string file/path plus supported file-mode options.", span);
        }

        var path = asynchronous ? await CoercePathLikeAsync(arguments[0], context, span, "open()").ConfigureAwait(false) : CoercePathLike(arguments[0], context, span, "open()");

        var mode = boundArguments.Assigned[1]
            ? arguments[1] switch
            {
                PyString text => text,
                _ => throw new LythonRuntimeException("TypeError", "open(file/path, mode) expects mode to be a string.", span)
            }
            : PyString.FromString("r");

        var (operation, binary) = ParseFileOpenMode(mode, "open()", span);
        if (binary) await ValidateBinaryOpenOptionsAsync(boundArguments, 2, "open()", span, context, asynchronous).ConfigureAwait(false);

        if (!binary && boundArguments.Count >= 3)
        {
            ValidateTextBuffering(arguments[2], "open()", span);
        }

        var encodingMode = boundArguments.Count >= 4
            ? ParseTextEncoding(arguments[3], "open()", span)
            : TextEncodingMode.Utf8;
        var errors = boundArguments.Count >= 5
            ? ParseTextErrors(arguments[4], "open()", span)
            : TextErrorMode.Strict;
        var newline = boundArguments.Count >= 6
            ? ParseTextNewline(arguments[5], "open()", span)
            : TextNewlineMode.TranslateUniversal;

        if (boundArguments.Count >= 7)
        {
            ValidateCloseFd(arguments[6], "open()", span);
        }

        if (boundArguments.Count == 8)
        {
            ValidateOpener(arguments[7], "open()", span);
        }

        return new TextOpenArguments(path, operation, encodingMode, errors, newline, binary);
    }

    private static BoundOpenArguments BindPositionalOpenArguments(object[] arguments, LythonSourceSpan span)
    {
        if (arguments.Length > 8)
        {
            throw new LythonRuntimeException("TypeError", "open(file/path[, mode][, buffering][, encoding][, errors][, newline][, closefd][, opener]) received too many positional arguments.", span);
        }

        var bound = new object[8];
        Array.Fill(bound, PyNone.Instance);
        var assigned = new ArgumentPresence(8);
        for (var i = 0; i < arguments.Length; i++)
        {
            bound[i] = arguments[i];
            assigned[i] = true;
        }

        return new BoundOpenArguments(bound, assigned, arguments.Length);
    }

    private static object Input(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length > 1)
        {
            throw new LythonRuntimeException("TypeError", "input([prompt]) expects zero or one string argument.", span);
        }

        if (arguments.Length == 1)
        {
            if (!PyStringOps.TryAsString(arguments[0], out var prompt))
            {
                throw new LythonRuntimeException("TypeError", "input(prompt) expects prompt to be a string.", span);
            }

            _ = context.State.Stdout.Write(prompt, span);
        }

        var line = context.State.Stdin.ReadLine(span);
        return PyStringOps.TrimTrailingNewline(line);
    }

    private static async ValueTask<object> InputAsync(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length > 1)
        {
            throw new LythonRuntimeException("TypeError", "input([prompt]) expects zero or one string argument.", span);
        }

        if (arguments.Length == 1)
        {
            if (!PyStringOps.TryAsString(arguments[0], out var prompt))
            {
                throw new LythonRuntimeException("TypeError", "input(prompt) expects prompt to be a string.", span);
            }

            _ = await context.State.Stdout.WriteAsync(prompt, span).ConfigureAwait(false);
        }

        var line = await context.State.Stdin.ReadLineAsync(span).ConfigureAwait(false);
        return PyStringOps.TrimTrailingNewline(line);
    }

    private static readonly Func<object, LythonSourceSpan, ExecutionContext, object> NativeStrOperation
        = static (value, _, context) => PyRendering.ToInterpolatedPyString(value, new PyRenderingContext(context));

    private sealed class StrCallable() : BuiltinCallable(
        LythonCallableSignature.Create("str", ["object", "encoding", "errors"], requiredCount: 0,
            maximumPositionalArgumentCount: 3, variadicParameters: LythonVariadicParameters.None), DecodeStr, null)
    {
        protected override bool PreservePresence => true;

        protected override object InvokeBoundWithPresence(BoundCallArguments bound, LythonSourceSpan span, ExecutionContext context)
        {
            // Codec-name types precede object validation, even without an object.
            // Omitted slots retain the binder's internal None defaults; an explicit
            // None must fail here before reaching the shared codec parsers.
            if (bound.Assigned[1]) RequireCodecNameType(bound.Values[1], "str()", "encoding", span);
            if (bound.Assigned[2]) RequireCodecNameType(bound.Values[2], "str()", "errors", span);

            if (!bound.Assigned[0]) return PyString.Empty;
            if (!bound.Assigned[1] && !bound.Assigned[2])
                return NativeStrOperation(bound.Values[0], span, context);

            return base.InvokeBound(bound.Values, span, context);
        }

        protected override ValueTask<object> InvokeBoundWithPresenceAsync(BoundCallArguments bound, LythonSourceSpan span, ExecutionContext context)
            => bound.Assigned[0] && !bound.Assigned[1] && !bound.Assigned[2] && bound.Values[0] is PyInstance or PyException
                ? RenderValueStringAsync(bound.Values[0], 's', context, span)
                : new(InvokeBoundWithPresence(bound, span, context));
    }

    private static object DecodeStr(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments[0] is PyString or string)
        {
            throw new LythonRuntimeException("TypeError", "decoding str is not supported", span);
        }

        if (arguments[0] is not PyBytes bytes)
        {
            throw new LythonRuntimeException("TypeError", "decoding to str: need a bytes-like object, " + RuntimeErrors.OperandTypeName(arguments[0]) + " found", span);
        }

        // Empty input needs neither codec lookup nor a private input copy.
        if (bytes.Length == 0) return PyString.Empty;
        var encoding = ParseTextEncoding(arguments[1], "str()", span);
        var errors = ParseTextErrors(arguments[2], "str()", span);
        return DecodeText(bytes.Memory, encoding, context, span, errors, TextNewlineMode.PreserveUniversal);
    }

    private static ValueTask<object> ReprAsync(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        => arguments.Length == 1 && arguments[0] is PyInstance or PyException
            ? RenderValueStringAsync(arguments[0], 'r', context, span)
            : new(Repr(arguments, span, context));

    private static ValueTask<object> AsciiAsync(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        => arguments.Length == 1 && arguments[0] is PyInstance or PyException
            ? RenderValueStringAsync(arguments[0], 'a', context, span)
            : new(Ascii(arguments, span, context));

    internal static async ValueTask<object> RenderValueStringAsync(object value, char conversion,
        ExecutionContext context, LythonSourceSpan span)
    {
        var rendering = new PyRenderingContext(context);
        var text = conversion == 's'
            ? await PyRendering.ToInterpolatedPyStringAsync(value, rendering).ConfigureAwait(false)
            : await PyRendering.ToReprPyStringAsync(value, rendering).ConfigureAwait(false);
        return conversion == 'a' ? EscapeNonAsciiPyString(text, context, span) : text;
    }

    private static object Repr(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length != 1)
        {
            throw new LythonRuntimeException("TypeError", "repr(value) expects one argument.", span);
        }

        return ToReprPyString(arguments[0], context);
    }

    private static object Ascii(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length != 1)
        {
            throw new LythonRuntimeException("TypeError", "ascii(value) expects one argument.", span);
        }

        return EscapeNonAsciiPyString(ToReprPyString(arguments[0], context), context, span);
    }

    private static object Format(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        var spec = ReadFormatSpecifier(arguments, span, context);
        return arguments[0] is PyDate or PyTime or PyDateTime
            ? PyDateTimeOps.FormatValue(arguments[0], spec, span, context)
            : FormatValue(arguments[0], spec.AsString(), context, span);
    }

    private static ValueTask<object> FormatAsync(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        => arguments.Length > 0 && arguments[0] is PyInstance instance
            ? FormatInstanceAsync(instance, ReadFormatSpecifier(arguments, span, context).AsString(), context, span, true)
            : new(Format(arguments, span, context));

    private static PyString ReadFormatSpecifier(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length is < 1 or > 2)
        {
            throw new LythonRuntimeException("TypeError", "format(value[, format_spec]) expects one or two arguments.", span);
        }

        var spec = PyString.Empty;
        if (arguments.Length == 2)
        {
            if (!PyStringOps.TryAsString(arguments[1], out var formatSpec))
            {
                throw new LythonRuntimeException("TypeError", $"format() argument 2 must be str, not {IsoformatTypeName(arguments[1], context)}", span);
            }

            spec = formatSpec;
        }

        return spec;
    }

    private static object Bool(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length > 1)
        {
            throw new LythonRuntimeException("TypeError", "bool([value]) expects at most one argument.", span);
        }

        return RuntimeValue(arguments.Length == 1 && IsTruthy(arguments[0], context, span));
    }

    private static async ValueTask<object> BoolAsync(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length > 1)
        {
            throw new LythonRuntimeException("TypeError", "bool([value]) expects at most one argument.", span);
        }

        return RuntimeValue(arguments.Length == 1 && await IsTruthyAsync(arguments[0], context, span).ConfigureAwait(false));
    }

    private static readonly Func<object, LythonSourceSpan, ExecutionContext, object> IntegerTextOperation
        = static (value, span, context) => ConvertIntegerValue(value, 10, context, span);

    private static object Int(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length > 2)
        {
            throw new LythonRuntimeException("TypeError", "int([x[, base]]) expects at most two arguments.", span);
        }

        if (arguments.Length == 0)
        {
            return BigInteger.Zero;
        }

        if (arguments.Length == 1 && arguments[0] is PyInstance intInstance)
        {
            // Preserve the returned box; major aliases remain conservatively
            // charged without a scalar identity ledger.
            return OwnFreshInteger(ConvertInstanceToInteger(intInstance, context, span), context.MemoryGovernor, span);
        }

        var numberBase = 10;
        if (arguments.Length == 2)
        {
            TryConvertIntegerIndex(arguments[1], context, span, out var indexedBase);
            numberBase = ValidateIntegerBase(indexedBase, arguments[1], arguments[0], context, span);
        }

        return ConvertIntegerValue(arguments[0], numberBase, context, span);
    }

    private static int ValidateIntegerBase(object indexedBase, object originalBase, object value,
        ExecutionContext context, LythonSourceSpan span)
    {
        if (!PyNumberOps.TryAsInteger(indexedBase, out var requestedBase))
            throw new LythonRuntimeException("TypeError", "'" + RuntimeErrors.DatetimeQualifiedTypeName(originalBase, context) + "' object cannot be interpreted as an integer", span);
        if (requestedBase < 0 || requestedBase > 36 || requestedBase == 1)
            throw new LythonRuntimeException("ValueError", "int() base must be >= 2 and <= 36, or 0", span);
        if (value is not PyString and not PyBytes)
            throw new LythonRuntimeException("TypeError", "int() can't convert non-string with explicit base", span);
        return (int)requestedBase;
    }

    private static object ConvertIntegerValue(object value, int numberBase, ExecutionContext context, LythonSourceSpan span)
    {
        try
        {
            return value switch
            {
                PySmallInteger or BigInteger => value,
                _ when PyNumberOps.TryAsInteger(value, out var integer) => OwnFreshInteger(integer, context.MemoryGovernor, span),
                double floating => OwnFreshInteger(FloatToInteger(floating, span, Math.Truncate), context.MemoryGovernor, span),
                PyDecimal decimalValue => OwnFreshInteger(new BigInteger(decimal.Truncate(decimalValue.Value)), context.MemoryGovernor, span),
                PyString or PyBytes => ParseOwnedIntegerText(value, numberBase, context, span),
                _ => throw new LythonRuntimeException("TypeError", "int() argument must be a string, a bytes-like object or a real number, not '" + UnboundTypeMethod.PythonTypeName(value, context) + "'", span)
            };
        }
        catch (FormatException ex)
        {
            throw new LythonRuntimeException("ValueError", ex.Message, span);
        }
        catch (OverflowException ex)
        {
            throw new LythonRuntimeException("OverflowError", ex.Message, span);
        }
    }

    private static readonly Func<object, LythonSourceSpan, ExecutionContext, object> AbsoluteOperation
        = static (value, span, context) => AbsValueWithoutProtocols(value, context, span);

    private static object Abs(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length != 1)
        {
            throw new LythonRuntimeException("TypeError", "abs(x) expects one argument.", span);
        }

        return AbsValue(arguments[0], context, span);
    }

    private static object AbsValue(object value, ExecutionContext context, LythonSourceSpan span)
    {
        if (value is PyInstance absInstance &&
            TryInvokeUnarySpecialMethod(absInstance, "__abs__", context, span, out var absolute))
        {
            return absolute;
        }

        return AbsValueWithoutProtocols(value, context, span);
    }

    private static object AbsValueWithoutProtocols(object value, ExecutionContext context, LythonSourceSpan span)
    {
        if (value is PyComplex complex) return complex.Magnitude(span);
        if (value is PyDecimal decimalValue)
        {
            return OwnDecimalValue(PyDecimalOps.ApplyContext(new PyDecimal(decimal.Abs(decimalValue.Value), decimalValue.Exponent), context.DecimalContext, context, span), context, span);
        }

        if (value is PyTimedelta delta)
        {
            return PyDateTimeOps.Abs(delta, context, span);
        }

        if (!PyNumberOps.TryAsNumber(value, out var number))
        {
            throw new LythonRuntimeException("TypeError", "bad operand type for abs(): '" + RuntimeErrors.DatetimeQualifiedTypeName(value, context) + "'", span);
        }

        if (value is PySmallInteger { Value: >= 0 } || value is BigInteger { Sign: >= 0 }) return value;
        return number.IsFloat ? Math.Abs(number.Floating) : OwnHeapInteger(BigInteger.Abs(number.Integer), context.MemoryGovernor, span);
    }

    private static object Pow(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length is < 2 or > 3)
        {
            throw new LythonRuntimeException("TypeError", "pow(base, exp[, mod]) expects two or three arguments.", span);
        }

        if (arguments.Length == 3 && arguments[2] is not PyNone && arguments.Take(2).Any(value => value is PyComplex))
            throw new LythonRuntimeException("ValueError", "complex modulo", span);

        // User-defined __pow__ takes precedence like CPython, binary and ternary
        // (an explicit None modulus behaves as absent everywhere).
        if (TryInvokePowProtocol(arguments, context, span, out var protocolResult))
        {
            return protocolResult;
        }

        if (arguments.Length == 3 && arguments[2] is not PyNone)
        {
            if (!PyNumberOps.TryAsInteger(arguments[0], out var integerBase) ||
                !PyNumberOps.TryAsInteger(arguments[1], out var exponent) ||
                !PyNumberOps.TryAsInteger(arguments[2], out var modulus))
            {
                if (arguments[0] is double || arguments[1] is double || arguments[2] is double)
                {
                    throw new LythonRuntimeException("TypeError", "pow() 3rd argument not allowed unless all arguments are integers", span);
                }

                if (arguments[0] is PyDecimal || arguments[1] is PyDecimal || arguments[2] is PyDecimal)
                {
                    return OwnDecimalValue(PyDecimalOps.PowerMod(arguments[0], arguments[1], arguments[2], span, context), context, span);
                }

                throw new LythonRuntimeException("TypeError", $"unsupported operand type(s) for ** or pow(): '{RuntimeErrors.OperandTypeName(arguments[0])}', '{RuntimeErrors.OperandTypeName(arguments[1])}', '{RuntimeErrors.OperandTypeName(arguments[2])}'", span);
            }

            if (modulus == BigInteger.Zero)
            {
                throw new LythonRuntimeException("ValueError", "pow() 3rd argument cannot be 0", span);
            }

            if (exponent < BigInteger.Zero)
            {
                integerBase = ModularInverse(integerBase, BigInteger.Abs(modulus), span);
                exponent = -exponent;
            }

            var absModulus = BigInteger.Abs(modulus);
            var normalizedBase = integerBase % absModulus;
            if (normalizedBase < BigInteger.Zero)
            {
                normalizedBase += absModulus;
            }

            var result = BigInteger.ModPow(normalizedBase, exponent, absModulus);
            return OwnHeapInteger(modulus < BigInteger.Zero && result != BigInteger.Zero ? result - absModulus : result, context.MemoryGovernor, span);
        }

        return EvaluatePower(arguments[0], arguments[1], context, span);
    }

    private static bool TryInvokePowProtocol(object[] arguments, ExecutionContext context, LythonSourceSpan span, out object result)
    {
        if (arguments.Length == 3 && arguments[2] is not PyNone)
        {
            // Ternary __pow__ receives (exp, mod); reflected ternary is
            // unreachable without builtin subclassing (CPython skips it for
            // plain classes, reporting the three-operand form instead).
            if (arguments[0] is PyInstance powInstance &&
                powInstance.TryGetAttribute("__pow__", context, span, out var powMember))
            {
                if (powMember is not ICallable powCallable)
                {
                    throw new LythonRuntimeException("TypeError", "'" + UnboundTypeMethod.PythonTypeName(powMember, context) + "' object is not callable", span);
                }

                result = CallableInvocation.InvokeBinary(powCallable, arguments[1], arguments[2], span, context);
                return true;
            }

            result = PyNone.Instance;
            return false;
        }

        if (TryInvokePowOperand(arguments[0], "__pow__", arguments[1], context, span, out result))
        {
            return true;
        }

        return TryInvokePowOperand(arguments[1], "__rpow__", arguments[0], context, span, out result);
    }

    private static bool TryInvokePowOperand(object target, string method, object argument, ExecutionContext context, LythonSourceSpan span, out object result)
    {
        if (target is PyInstance powInstance &&
            powInstance.TryGetAttribute(method, context, span, out var member))
        {
            if (member is not ICallable callable)
            {
                throw new LythonRuntimeException("TypeError", "'" + UnboundTypeMethod.PythonTypeName(member, context) + "' object is not callable", span);
            }

            var value = CallableInvocation.InvokeUnary(callable, argument, span, context);
            if (value is PyNotImplemented)
            {
                result = PyNone.Instance;
                return false;
            }

            result = value;
            return true;
        }

        result = PyNone.Instance;
        return false;
    }

    private static BigInteger ModularInverse(BigInteger value, BigInteger modulus, LythonSourceSpan span)
    {
        var oldR = value % modulus;
        var r = modulus;
        var oldS = BigInteger.One;
        var s = BigInteger.Zero;
        while (r != BigInteger.Zero)
        {
            var quotient = oldR / r;
            (oldR, r) = (r, oldR - quotient * r);
            (oldS, s) = (s, oldS - quotient * s);
        }

        if (BigInteger.Abs(oldR) != BigInteger.One)
        {
            throw new LythonRuntimeException("ValueError", "base is not invertible for the given modulus", span);
        }

        var inverse = oldS % modulus;
        return inverse < BigInteger.Zero ? inverse + modulus : inverse;
    }

    private static object Bin(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        return FormatIntegerBase(arguments, "bin(number) expects an integer.", 'b', span, context);
    }

    private static object Oct(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        return FormatIntegerBase(arguments, "oct(number) expects an integer.", 'o', span, context);
    }

    private static object Hex(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        return FormatIntegerBase(arguments, "hex(number) expects an integer.", 'x', span, context);
    }

    private static object Chr(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length != 1)
        {
            throw new LythonRuntimeException("TypeError", "chr(i) expects one integer argument.", span);
        }

        var index = CoerceIndexProtocol(arguments[0], context, span);
        if (!PyNumberOps.TryAsInteger(index, out var codePoint))
        {
            throw new LythonRuntimeException("TypeError", "'" + RuntimeErrors.DatetimeQualifiedTypeName(arguments[0], context) + "' object cannot be interpreted as an integer", span);
        }
        if (codePoint < BigInteger.Zero || codePoint > new BigInteger(0x10FFFF))
        {
            throw new LythonRuntimeException("ValueError", "chr() arg not in range(0x110000)", span);
        }

        var value = (int)codePoint;
        if (!Rune.IsValid(value))
        {
            throw new LythonRuntimeException("ValueError", "chr() arg is not a valid Unicode scalar value.", span);
        }

        return PyString.FromString(new Rune(value).ToString(), context.MemoryGovernor, span);
    }

    private static object Ord(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length == 1 && arguments[0] is PyBytes bytes && bytes.Length == 1)
        {
            return new BigInteger(bytes.Bytes[0]);
        }

        if (arguments.Length == 1 && PyStringOps.TryAsString(arguments[0], out var text))
        {
            if (text.Length == 1)
            {
                var source = text.AsString();
                var status = Rune.DecodeFromUtf16(source, out var rune, out var consumed);
                if (status == OperationStatus.Done && consumed == source.Length)
                {
                    return new BigInteger(rune.Value);
                }
            }

            throw new LythonRuntimeException("TypeError", $"ord() expected a character, but string of length {text.Length} found", span);
        }

        if (arguments.Length == 1 && arguments[0] is PyBytes wrongLengthBytes)
        {
            throw new LythonRuntimeException("TypeError", $"ord() expected a character, but string of length {wrongLengthBytes.Length} found", span);
        }

        if (arguments.Length == 1)
        {
            throw new LythonRuntimeException("TypeError", $"ord() expected string of length 1, but {UnboundTypeMethod.PythonTypeName(arguments[0], context)} found", span);
        }

        throw new LythonRuntimeException("TypeError", "ord(c) expects a character.", span);
    }

    private static object Callable(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length != 1)
        {
            throw new LythonRuntimeException("TypeError", "callable(object) expects one argument.", span);
        }

        return RuntimeValue(IsCallable(arguments[0]));
    }

    // Python's tp_call presence depends on the type's slot. No ordinary
    // attribute lookup or descriptor execution is needed for callable().
    internal static bool IsCallable(object value)
        => value is PyInstance instance
            ? instance.Type.TryLookupInMro("__call__", 0, out _, out _)
            : value is ICallable;

    // Native builtin hash members share structural values. Python callbacks and
    // compound public hashes use PyHashProtocols with the active context.
    internal static object ComputeBuiltinHash(object value, LythonSourceSpan span, ExecutionContext context)
        => new BigInteger(ComputeStructuralHashCode(value, span, context));

    internal static int ComputeStructuralHashCode(object value, LythonSourceSpan? span, ExecutionContext context)
    {
        context.CheckExecution(span);
        try
        {
            // Native buffers need the current caller through the actual scan.
            // The CLR comparer stays context-free and never dispatches guests.
            if (value is PyString text)
                return PyValueComparer.NormalizeHash(text.GetHashCode(context.State.CancellationToken, span));
            if (value is PyBytes bytes)
                return PyValueComparer.NormalizeHash(bytes.GetHashCode(context.State.CancellationToken, span));
            return PyValueComparer.Instance.GetHashCode(value);
        }
        catch (PyUnhashableException error)
        {
            throw RuntimeErrors.UnhashableType(error.Value, span);
        }
    }

    private static object Hash(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length != 1)
        {
            throw new LythonRuntimeException("TypeError", "hash(object) expects one argument.", span);
        }

        return new BigInteger(PyHashProtocols.GetProtocolHash(arguments[0], context, span));
    }

    private static async ValueTask<object> HashAsync(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length != 1)
            throw RuntimeErrors.Type("hash(object) expects one argument.", span);
        return new BigInteger(await PyHashProtocols.GetProtocolHashAsync(arguments[0], context, span).ConfigureAwait(false));
    }

    private static object Id(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length != 1)
        {
            throw new LythonRuntimeException("TypeError", "id() takes exactly one argument (" + arguments.Length + " given)", span);
        }

        return context.State.GetObjectId(arguments[0]);
    }

    private static int ToInt32(BigInteger value, string owner, LythonSourceSpan span)
    {
        if (value < int.MinValue || value > int.MaxValue)
        {
            throw new LythonRuntimeException("OverflowError", $"{owner} integer argument is too large.", span);
        }

        return (int)value;
    }

    private static object FormatIntegerBase(object[] arguments, string message, char type, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length != 1)
        {
            throw new LythonRuntimeException("TypeError", message, span);
        }

        var indexed = CoerceIndexProtocol(arguments[0], context, span);
        if (!PyNumberOps.TryAsInteger(indexed, out var integer))
        {
            throw new LythonRuntimeException("TypeError", "'" + RuntimeErrors.DatetimeQualifiedTypeName(arguments[0], context) + "' object cannot be interpreted as an integer", span);
        }
        var output = new GovernedByteBuilder(context.MemoryGovernor, span);
        try
        {
            AppendIntegerFormat(output, integer, new(-1, null, null, true, false, null, null, null, type),
                context, span, RuntimeErrors.OperandTypeName(arguments[0]));
            return output.ToPyStringAndRelease();
        }
        finally { output.Release(); }
    }

    // Shared int() conversion failure: quotes the offending source like CPython
    // (str form for strings, bytes form for bytes). Rendered lazily like the
    // float() path: building it eagerly committed a retained repr per call.
    private static string IntFailureDisplay(object source, ExecutionContext context)
        => PyRendering.ToReprPyString(source, new PyRenderingContext(context)).AsString();

    private static object ParseOwnedIntegerText(object source, int numberBase, ExecutionContext context, LythonSourceSpan span)
    {
        context.MemoryGovernor.ThrowIfAdmissionFailed();
        ReadOnlySpan<byte> utf8 = source is PyString text ? text.Utf8Span : ((PyBytes)source).Bytes;
        // A bounded native decimal needs neither decoded text nor major scratch.
        // Complete consumption rejects suffixes/NULs; all other Python forms and
        // overflow keep the admitted general path. Small boxes use control headroom.
        if (numberBase == 10 && utf8.Length <= 20 &&
            System.Buffers.Text.Utf8Parser.TryParse(utf8, out long integer, out var consumed) && consumed == utf8.Length)
            return new BigInteger(integer);

        MemoryGovernor.TemporaryMemoryReservation? admission = null;
        try
        {
            var result = ParseIntegerUtf8(utf8, source is PyString, numberBase, span, source, context, ref admission);
            context.CheckExecution(span);
            object box = result;
            if (admission is not null)
                admission.Commit(RuntimeMemoryEstimates.EstimateBigIntegerBytes(result));
            return box;
        }
        finally { admission?.Dispose(); }
    }

    // CPython resolves int(instance) through __int__, then __index__, then
    // the deprecated __trunc__ hook (whose result still coerces through
    // __index__). Every present hook is called like CPython, so a
    // non-callable hook raises the typed not-callable error.
    private static object ConvertInstanceToInteger(
        PyInstance instance,
        ExecutionContext context,
        LythonSourceSpan span)
    {
        if (TryGetNumericConversionMember(instance, "__int__", context, span, out var intMember))
        {
            if (intMember is not ICallable intCallable)
            {
                throw NotCallableError(intMember, context, span);
            }

            return ValidateIntegerConversionResult(intCallable.Invoke([], span, context), "__int__", context, span);
        }

        if (TryConvertIntegerIndex(instance, context, span, out var indexedValue))
        {
            return indexedValue;
        }

        if (TryGetNumericConversionMember(instance, "__trunc__", context, span, out var truncMember))
        {
            if (truncMember is not ICallable truncCallable)
            {
                throw NotCallableError(truncMember, context, span);
            }

            var truncated = truncCallable.Invoke([], span, context);
            TryConvertIntegerIndex(truncated, context, span, out var indexed);
            return ValidateTruncatedInteger(truncated, indexed, context, span);
        }

        throw IntegerConversionError(instance, context, span);
    }

    private static bool TryGetNumericConversionMember(PyInstance instance, string name,
        ExecutionContext context, LythonSourceSpan span, out object member)
    {
        if (instance.Type.TryLookupInMro(name, 0, out var raw, out _))
        {
            member = PyAttributeLookup.BindForInstance(instance, raw, context, span);
            return true;
        }

        member = PyNone.Instance;
        return false;
    }

    private static bool TryConvertIntegerIndex(object value, ExecutionContext context,
        LythonSourceSpan span, out object converted)
    {
        converted = value;
        if (value is not PyInstance instance ||
            !TryGetNumericConversionMember(instance, "__index__", context, span, out var member))
            return false;
        if (member is not ICallable callable) throw NotCallableError(member, context, span);
        converted = ValidateIntegerConversionResult(callable.Invoke([], span, context), "__index__", context, span);
        return true;
    }

    private static object ValidateTruncatedInteger(object truncated, object indexed, ExecutionContext context, LythonSourceSpan span)
    {
        if (!PyNumberOps.TryAsInteger(indexed, out var integer))
            throw new LythonRuntimeException("TypeError", "__trunc__ returned non-Integral (type " + UnboundTypeMethod.PythonTypeName(truncated, context) + ")", span);
        return indexed is PySmallInteger or BigInteger ? indexed : integer;
    }

    internal static LythonRuntimeException NotCallableError(object member, ExecutionContext context, LythonSourceSpan span)
        => new("TypeError", "'" + UnboundTypeMethod.PythonTypeName(member, context) + "' object is not callable", span);

    private static LythonRuntimeException IntegerConversionError(PyInstance instance, ExecutionContext context, LythonSourceSpan span)
        => new("TypeError", "int() argument must be a string, a bytes-like object or a real number, not '" + UnboundTypeMethod.PythonTypeName(instance, context) + "'", span);

    private static BigInteger FloatToInteger(
        double value,
        LythonSourceSpan span,
        Func<double, double> transform)
    {
        if (double.IsNaN(value))
        {
            throw new LythonRuntimeException("ValueError", "cannot convert float NaN to integer", span);
        }

        if (double.IsInfinity(value))
        {
            throw new LythonRuntimeException("OverflowError", "cannot convert float infinity to integer", span);
        }

        try
        {
            return new BigInteger(transform(value));
        }
        catch (OverflowException ex)
        {
            throw new LythonRuntimeException("OverflowError", ex.Message, span);
        }
    }

    private static string EscapeNonAscii(string text)
    {
        var builder = new StringBuilder(text.Length);
        foreach (var rune in text.EnumerateRunes())
        {
            if (rune.Value <= 0x7F)
            {
                builder.Append(rune.ToString());
            }
            else if (rune.Value <= 0xFF)
            {
                builder.Append(CultureInfo.InvariantCulture, $"\\x{rune.Value:x2}");
            }
            else if (rune.Value <= 0xFFFF)
            {
                builder.Append(CultureInfo.InvariantCulture, $"\\u{rune.Value:x4}");
            }
            else
            {
                builder.Append(CultureInfo.InvariantCulture, $"\\U{rune.Value:x8}");
            }
        }

        return builder.ToString();
    }

}
