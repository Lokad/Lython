using System.Numerics;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Numbers;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    private sealed class OperatorModule : PyModule
    {
        public static readonly OperatorModule Instance = new();

        private OperatorModule() : base("operator")
        {
        }

        public override bool TryGetMember(string name, [MaybeNullWhen(false)] out object value)
        {
            value = name switch
            {
                "truth" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorTruth,
                    (a, span, context) => IsTruthy(a[0], context, span),
                    async (a, span, context) => await IsTruthyAsync(a[0], context, span).ConfigureAwait(false)),
                "not_" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorNot,
                    (a, span, context) => EvaluateUnaryOperator(UnaryOperatorSyntax.Not, a[0], context, span),
                    (a, span, context) => EvaluateUnaryOperatorAsync(UnaryOperatorSyntax.Not, a[0], context, span)),
                "is_" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorIs, (arguments, span, _) => CompareBool(arguments, span, static (left, right, _) => AreIdentical(left, right))),
                "is_not" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorIsNot, (arguments, span, _) => CompareBool(arguments, span, static (left, right, _) => !AreIdentical(left, right))),
                "abs" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorAbs,
                    (arguments, span, context) => Unary(arguments, span, (value, innerSpan) => AbsValue(value, context, innerSpan)),
                    EvaluateAbsoluteAsync),
                "neg" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorNeg,
                    (arguments, span, context) => EvaluateUnaryOperator(UnaryOperatorSyntax.Minus, arguments[0], context, span),
                    (arguments, span, context) => EvaluateUnaryOperatorAsync(UnaryOperatorSyntax.Minus, arguments[0], context, span)),
                "pos" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorPos,
                    (arguments, span, context) => EvaluateUnaryOperator(UnaryOperatorSyntax.Plus, arguments[0], context, span),
                    (arguments, span, context) => EvaluateUnaryOperatorAsync(UnaryOperatorSyntax.Plus, arguments[0], context, span)),
                "invert" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorInvert,
                    (arguments, span, context) => EvaluateUnaryOperator(UnaryOperatorSyntax.BitwiseNot, arguments[0], context, span),
                    (arguments, span, context) => EvaluateUnaryOperatorAsync(UnaryOperatorSyntax.BitwiseNot, arguments[0], context, span)),
                "index" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorIndex,
                    (arguments, span, context) => EvaluateIndex(arguments[0], context, span),
                    (arguments, span, context) => EvaluateIndexAsync(arguments[0], context, span)),
                "add" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorAdd, (arguments, span, context) => Binary(arguments, span, (left, right, innerSpan) => EvaluateAdd(left, right, context, innerSpan))),
                "sub" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorSub, (arguments, span, context) => Binary(arguments, span, (left, right, innerSpan) => EvaluateSubtract(left, right, context, innerSpan))),
                "mul" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorMul,
                    (a, span, context) => EvaluateBinaryOperator(BinaryOperatorSyntax.Multiply, a[0], a[1], context, span),
                    (a, span, context) => EvaluateBinaryOperatorAsync(BinaryOperatorSyntax.Multiply, a[0], a[1], context, span)),
                "truediv" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorTrueDiv, (arguments, span, context) => Binary(arguments, span, (left, right, innerSpan) => EvaluateDivide(left, right, context, innerSpan))),
                "floordiv" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorFloorDiv, (arguments, span, context) => Binary(arguments, span, (left, right, innerSpan) => EvaluateFloorDivide(left, right, context, innerSpan))),
                "mod" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorMod, (arguments, span, context) => Binary(arguments, span, (left, right, innerSpan) => EvaluateModulo(left, right, context, innerSpan))),
                "pow" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorPow, (arguments, span, context) => Binary(arguments, span, (left, right, innerSpan) => EvaluatePower(left, right, context, innerSpan))),
                "matmul" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorMatMul, (arguments, span, context) => EvaluateMatrixMultiplyAsync(arguments[0], arguments[1], context, span, false).GetAwaiter().GetResult(), (arguments, span, context) => EvaluateMatrixMultiplyAsync(arguments[0], arguments[1], context, span, true)),
                "imatmul" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorIMatMul, (arguments, span, context) => EvaluateMatrixInPlaceAsync(arguments[0], arguments[1], context, span, false).GetAwaiter().GetResult(), (arguments, span, context) => EvaluateMatrixInPlaceAsync(arguments[0], arguments[1], context, span, true)),
                "lshift" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorLShift, (arguments, span, context) => Binary(arguments, span, (left, right, innerSpan) => EvaluateLeftShift(left, right, context, innerSpan))),
                "rshift" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorRShift, (arguments, span, context) => Binary(arguments, span, (left, right, innerSpan) => EvaluateRightShift(left, right, context, innerSpan))),
                "and_" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorAnd, (arguments, span, context) => Binary(arguments, span, (left, right, innerSpan) => EvaluateBitwiseAnd(left, right, context, innerSpan))),
                "or_" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorOr, (arguments, span, context) => Binary(arguments, span, (left, right, innerSpan) => EvaluateBitwiseOr(left, right, context, innerSpan))),
                "xor" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorXor, (arguments, span, context) => Binary(arguments, span, (left, right, innerSpan) => EvaluateBitwiseXor(left, right, context, innerSpan))),
                "concat" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorConcat, (arguments, span, context) => Binary(arguments, span, (left, right, innerSpan) => EvaluateConcat(left, right, context, innerSpan))),
                "eq" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorEq,
                    (a, span, context) => EvaluateBinaryOperator(BinaryOperatorSyntax.Equal, a[0], a[1], context, span),
                    (a, span, context) => EvaluateBinaryOperatorAsync(BinaryOperatorSyntax.Equal, a[0], a[1], context, span)),
                "ne" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorNe,
                    (a, span, context) => EvaluateBinaryOperator(BinaryOperatorSyntax.NotEqual, a[0], a[1], context, span),
                    (a, span, context) => EvaluateBinaryOperatorAsync(BinaryOperatorSyntax.NotEqual, a[0], a[1], context, span)),
                "lt" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorLt,
                    (a, span, context) => EvaluateBinaryOperator(BinaryOperatorSyntax.Less, a[0], a[1], context, span),
                    (a, span, context) => EvaluateBinaryOperatorAsync(BinaryOperatorSyntax.Less, a[0], a[1], context, span)),
                "le" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorLe,
                    (a, span, context) => EvaluateBinaryOperator(BinaryOperatorSyntax.LessEqual, a[0], a[1], context, span),
                    (a, span, context) => EvaluateBinaryOperatorAsync(BinaryOperatorSyntax.LessEqual, a[0], a[1], context, span)),
                "gt" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorGt,
                    (a, span, context) => EvaluateBinaryOperator(BinaryOperatorSyntax.Greater, a[0], a[1], context, span),
                    (a, span, context) => EvaluateBinaryOperatorAsync(BinaryOperatorSyntax.Greater, a[0], a[1], context, span)),
                "ge" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorGe,
                    (a, span, context) => EvaluateBinaryOperator(BinaryOperatorSyntax.GreaterEqual, a[0], a[1], context, span),
                    (a, span, context) => EvaluateBinaryOperatorAsync(BinaryOperatorSyntax.GreaterEqual, a[0], a[1], context, span)),
                "getitem" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorGetItem, GetItem, GetItemAsync),
                "setitem" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorSetItem, SetItem),
                "delitem" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorDelItem, DelItem),
                "contains" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorContains,
                    (a, span, context) => Contains(a[0], a[1], context, span),
                    async (a, span, context) => await ContainsAsync(a[0], a[1], context, span).ConfigureAwait(false)),
                "length_hint" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorLengthHint, LengthHint, LengthHintAsync),
                "countOf" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorCountOf, CountOf, CountOfAsync),
                "indexOf" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorIndexOf, IndexOf, IndexOfAsync),
                "iadd" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorIAdd, (arguments, span, context) => InPlaceBinary(arguments, span, context, AugmentedAssignmentOperatorSyntax.Add)),
                "isub" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorISub, (arguments, span, context) => InPlaceBinary(arguments, span, context, AugmentedAssignmentOperatorSyntax.Subtract)),
                "imul" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorIMul, (arguments, span, context) => InPlaceBinary(arguments, span, context, AugmentedAssignmentOperatorSyntax.Multiply)),
                "itruediv" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorITrueDiv, (arguments, span, context) => InPlaceBinary(arguments, span, context, AugmentedAssignmentOperatorSyntax.Divide)),
                "ifloordiv" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorIFloorDiv, (arguments, span, context) => InPlaceBinary(arguments, span, context, AugmentedAssignmentOperatorSyntax.FloorDivide)),
                "imod" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorIMod, (arguments, span, context) => InPlaceBinary(arguments, span, context, AugmentedAssignmentOperatorSyntax.Modulo)),
                "ipow" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorIPow, (arguments, span, context) => InPlaceBinary(arguments, span, context, AugmentedAssignmentOperatorSyntax.Power)),
                "ilshift" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorILShift, (arguments, span, context) => InPlaceBinary(arguments, span, context, AugmentedAssignmentOperatorSyntax.LeftShift)),
                "irshift" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorIRShift, (arguments, span, context) => InPlaceBinary(arguments, span, context, AugmentedAssignmentOperatorSyntax.RightShift)),
                "iand" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorIAnd, (arguments, span, context) => InPlaceBinary(arguments, span, context, AugmentedAssignmentOperatorSyntax.BitwiseAnd)),
                "ior" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorIOr, (arguments, span, context) => InPlaceBinary(arguments, span, context, AugmentedAssignmentOperatorSyntax.BitwiseOr)),
                "ixor" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorIXor, (arguments, span, context) => InPlaceBinary(arguments, span, context, AugmentedAssignmentOperatorSyntax.BitwiseXor)),
                "iconcat" => BuiltinCallable.Create(LythonKnownCallableSignatures.OperatorIConcat, InPlaceConcat),
                "call" => new OperatorFactoryCallable("operator.call", CallTarget),
                "itemgetter" => new OperatorFactoryCallable("operator.itemgetter", CreateItemGetter),
                "attrgetter" => new OperatorFactoryCallable("operator.attrgetter", CreateAttrGetter),
                "methodcaller" => new OperatorFactoryCallable("operator.methodcaller", CreateMethodCaller),
                _ => MissingMemberValue.Instance,
            };

            return !ReferenceEquals(value, MissingMemberValue.Instance);
        }
    }

    private sealed class OperatorFactoryCallable : ICallable, INamedRuntimeCallable, IPyRenderableValue
    {
        private readonly string _name;
        private readonly Func<CallArgumentValue[], LythonSourceSpan, ExecutionContext, object> _implementation;

        public OperatorFactoryCallable(string name, Func<CallArgumentValue[], LythonSourceSpan, ExecutionContext, object> implementation)
        {
            _name = name;
            _implementation = implementation;
        }

        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            context.CheckExecution(span);
            return _implementation(arguments, span, context);
        }

        public string Name => _name;

        public PyString RenderPython(PyRenderingContext context)
        {
            _ = context;
            // operator factories denote types like CPython, except call (a
            // plain builtin function).
            return PyString.FromString(BuiltinCallable.ShortCallableName(_name) switch
            {
                "call" => "<built-in function call>",
                _ => $"<class '{_name}'>",
            });
        }

        public PyString RenderInterpolated(PyRenderingContext context) => RenderPython(context);

        public override string ToString() => _name;
    }

    private sealed class PyItemGetter : ICallable, IPyRenderableValue
    {
        private readonly object[] _items;

        public PyItemGetter(object[] items)
        {
            _items = items;
        }

        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            if (arguments.Length != 1 || arguments[0].IsKeyword)
            {
                throw new LythonRuntimeException("TypeError", "operator.itemgetter(...)(obj) expects one positional argument.", span);
            }

            var target = arguments[0].Value;
            if (_items.Length == 1)
            {
                return ReadItem(target, _items[0], span, context);
            }

            var values = new object[_items.Length];
            for (var i = 0; i < _items.Length; i++)
            {
                values[i] = ReadItem(target, _items[i], span, context);
            }

            return new PyTuple(values, context.MemoryGovernor, span);
        }

        public async ValueTask<object> InvokeAsync(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            if (arguments.Length != 1 || arguments[0].IsKeyword)
            {
                throw new LythonRuntimeException("TypeError", "operator.itemgetter(...)(obj) expects one positional argument.", span);
            }
            var target = arguments[0].Value;
            if (_items.Length == 1)
            {
                return await ReadItemAsync(target, _items[0], span, context).ConfigureAwait(false);
            }
            var values = new object[_items.Length];
            for (var i = 0; i < _items.Length; i++)
            {
                values[i] = await ReadItemAsync(target, _items[i], span, context).ConfigureAwait(false);
            }
            return new PyTuple(values, context.MemoryGovernor, span);
        }

        public PyString RenderPython(PyRenderingContext context)
            => PyRendering.JoinRenderedSequence(
                "operator.itemgetter(",
                _items.Select(item => PyRendering.ToReprPyString(item, context)),
                ")",
                context);

        public PyString RenderInterpolated(PyRenderingContext context) => RenderPython(context);
    }

    private sealed class PyAttrGetter : ICallable, IPyRenderableValue
    {
        private readonly string[][] _paths;

        public PyAttrGetter(string[][] paths)
        {
            _paths = paths;
        }

        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            if (arguments.Length != 1 || arguments[0].IsKeyword)
            {
                throw new LythonRuntimeException("TypeError", "operator.attrgetter(...)(obj) expects one positional argument.", span);
            }

            var target = arguments[0].Value;
            if (_paths.Length == 1)
            {
                return ReadPath(target, _paths[0], span, context);
            }

            var values = new object[_paths.Length];
            for (var i = 0; i < _paths.Length; i++)
            {
                values[i] = ReadPath(target, _paths[i], span, context);
            }

            return new PyTuple(values, context.MemoryGovernor, span);
        }

        public PyString RenderPython(PyRenderingContext context)
            => PyRendering.JoinRenderedSequence(
                "operator.attrgetter(",
                _paths.Select(path => PyRendering.ToReprPyString(PyString.FromString(string.Join(".", path)), context)),
                ")",
                context);

        public PyString RenderInterpolated(PyRenderingContext context) => RenderPython(context);

        private static object ReadPath(object target, IReadOnlyList<string> path, LythonSourceSpan span, ExecutionContext context)
        {
            var current = target;
            foreach (var part in path)
            {
                var memberTarget = current;
                if (!PyMemberAccess.TryResolve(memberTarget, part, context, span, out current))
                {
                    throw PyMemberAccess.CreateMissingMemberError(memberTarget, part, span, context);
                }
            }

            return current;
        }
    }

    private sealed class PyMethodCaller : ICallable, IPyRenderableValue
    {
        private readonly string _name;
        private readonly CallArgumentValue[] _arguments;

        public PyMethodCaller(string name, CallArgumentValue[] arguments)
        {
            _name = name;
            _arguments = arguments;
        }

        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            if (arguments.Length != 1 || arguments[0].IsKeyword)
            {
                throw new LythonRuntimeException("TypeError", "operator.methodcaller(...)(obj) expects one positional argument.", span);
            }

            if (!PyMemberAccess.TryResolve(arguments[0].Value, _name, context, span, out var member))
            {
                throw PyMemberAccess.CreateMissingMemberError(arguments[0].Value, _name, span, context);
            }

            return InvokeCallableTarget(member, span, span, context, () => _arguments);
        }

        public PyString RenderPython(PyRenderingContext context)
        {
            var rendered = new List<PyString> { PyRendering.ToReprPyString(PyString.FromString(_name), context) };
            foreach (var argument in _arguments)
            {
                if (argument.IsPositional)
                {
                    rendered.Add(PyRendering.ToReprPyString(argument.Value, context));
                    continue;
                }

                rendered.Add(PyString.FromString(argument.KeywordName + "=" + PyRendering.ToReprPyString(argument.Value, context).AsString()));
            }

            return PyRendering.JoinRenderedSequence("operator.methodcaller(", rendered, ")", context);
        }

        public PyString RenderInterpolated(PyRenderingContext context) => RenderPython(context);
    }

    private static object Unary(object[] arguments, LythonSourceSpan span, Func<object, LythonSourceSpan, object> operation)
    {
        if (arguments.Length != 1)
        {
            throw new LythonRuntimeException("TypeError", "operator unary function expects one argument.", span);
        }

        return operation(arguments[0], span);
    }

    private static object Binary(object[] arguments, LythonSourceSpan span, Func<object, object, LythonSourceSpan, object> operation)
    {
        if (arguments.Length != 2)
        {
            throw new LythonRuntimeException("TypeError", "operator function expects two arguments.", span);
        }

        return operation(arguments[0], arguments[1], span);
    }

    private static ValueTask<object> EvaluateAbsoluteAsync(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        => arguments.Length == 1 ? AbsValueAsync(arguments[0], context, span)
            : ValueTask.FromResult(Unary(arguments, span, (value, innerSpan) => AbsValue(value, context, innerSpan)));

    private static object EvaluateIndex(object value, ExecutionContext context, LythonSourceSpan span)
    {
        var converted = value is PyInstance
            ? CoerceTypeIndexAsync(value, context, span, false).GetAwaiter().GetResult() ?? PyNone.Instance
            : value;
        return NormalizeOperatorIndex(converted, context, span);
    }

    private static async ValueTask<object> EvaluateIndexAsync(object value, ExecutionContext context, LythonSourceSpan span)
        => NormalizeOperatorIndex(await CoerceTypeIndexAsync(value, context, span, true).ConfigureAwait(false)
            ?? PyNone.Instance, context, span);

    private static object NormalizeOperatorIndex(object value, ExecutionContext context, LythonSourceSpan span)
    {
        if (!PyNumberOps.TryAsInteger(value, out var integer))
        {
            throw new LythonRuntimeException("TypeError", "'" + RuntimeErrors.DatetimeQualifiedTypeName(value, context) + "' object cannot be interpreted as an integer", span);
        }

        return value is PySmallInteger or BigInteger ? value : integer;
    }

    private static object EvaluateConcat(object left, object right, ExecutionContext context, LythonSourceSpan span)
    {
        if (PyStringOps.TryAsString(left, out _) && PyStringOps.TryAsString(right, out _) ||
            left is PyList && right is PyList ||
            left is PyBytes && right is PyBytes ||
            PyTupleLike.TryGetItems(left, out _) && PyTupleLike.TryGetItems(right, out _) ||
            left is PyDeque && right is PyDeque)
        {
            return EvaluateAdd(left, right, context, span);
        }

        throw ConcatMismatch(left, right, span);
    }

    // Concatenation mismatch errors mirror the + operator arms for sequence
    // left operands; anything else is not concatenable at all.
    private static LythonRuntimeException ConcatMismatch(object left, object right, LythonSourceSpan span)
    {
        if (left is PyString)
        {
            return RuntimeErrors.ConcatError("str", right, span);
        }

        if (left is PyBytes)
        {
            return RuntimeErrors.CantConcatToBytes(right, span);
        }

        if (left is PyList)
        {
            return RuntimeErrors.ConcatError("list", right, span);
        }

        if (PyTupleLike.TryGetItems(left, out _))
        {
            return RuntimeErrors.ConcatError("tuple", right, span);
        }

        if (left is PyDeque)
        {
            return RuntimeErrors.ConcatError("deque", right, span);
        }

        return RuntimeErrors.Type($"'{RuntimeErrors.OperandTypeName(left)}' object can't be concatenated", span);
    }

    private static object CompareBool(object[] arguments, LythonSourceSpan span, Func<object, object, LythonSourceSpan, bool> operation)
    {
        if (arguments.Length != 2)
        {
            throw new LythonRuntimeException("TypeError", "operator comparison expects two arguments.", span);
        }

        return operation(arguments[0], arguments[1], span);
    }

    private static object GetItem(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length != 2)
        {
            throw new LythonRuntimeException("TypeError", "operator.getitem(obj, key) expects two arguments.", span);
        }

        return ReadItem(arguments[0], arguments[1], span, context);
    }

    private static object ReadItem(object target, object index, LythonSourceSpan span, ExecutionContext context)
    {
        if (target is PyDefaultDict defaultDict)
        {
            return defaultDict.GetOrCreate(ValidateDictionaryKey(index, span), context, span);
        }

        return PyIndexing.ReadIndex(target, index, span, context);
    }

    private static ValueTask<object> GetItemAsync(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        => ReadItemAsync(arguments[0], arguments[1], span, context);

    private static ValueTask<object> ReadItemAsync(object target, object index, LythonSourceSpan span, ExecutionContext context)
        => target is ElementTreeModule.Element element
            ? ElementTreeModule.ReadIndexAsync(element, index, context, span, true)
            : target is ReMatchObject match
            ? ReMatchMembers.GetSubscriptAsync(match, index, span, context)
            : new(ReadItem(target, index, span, context));

    private static object DelItem(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        using var _ambientScope = PyStructuralGuard.PushAmbient(context, span);
        if (arguments.Length != 2)
        {
            throw new LythonRuntimeException("TypeError", "operator.delitem(obj, key) expects two arguments.", span);
        }

        var target = arguments[0];
        var index = arguments[1];
        // Slice objects delete through the shared slice path on lists like
        // CPython; every other receiver keeps its existing behaviour.
        if (index is PySlice slice && target is PyList)
        {
            ExecuteSliceDeletion(target, slice.StartBound, slice.StopBound, slice.StepBound, span, context);
            return PyNone.Instance;
        }

        switch (target)
        {
            case IDeletablePySubscriptableValue subscriptable:
                subscriptable.DeleteSubscript(index, span);
                return PyNone.Instance;
            case IMutablePySequenceValue sequence:
                sequence.RemoveAt(PyIndexing.NormalizeIndex(index, sequence.Count, span, PyIndexing.TargetKind(sequence), PyIndexing.IndexOperation.Delete));
                return PyNone.Instance;
            case PyDict dict:
                if (!dict.Remove(ValidateDictionaryKey(index, span)))
                {
                    throw RuntimeErrors.MissingKey(index, span);
                }

                return PyNone.Instance;
            case PyDefaultDict defaultDict:
                if (!defaultDict.Remove(ValidateDictionaryKey(index, span)))
                {
                    throw RuntimeErrors.MissingKey(index, span);
                }

                return PyNone.Instance;
            case PyCounter counter:
                _ = counter.Remove(ValidateDictionaryKey(index, span));
                return PyNone.Instance;
            case PyTuple:
                throw new LythonRuntimeException("TypeError", "'tuple' object doesn't support item deletion", span);
            case PyBytes:
                throw new LythonRuntimeException("TypeError", "'bytes' object doesn't support item deletion", span);
            default:
                if (PyStringOps.TryAsString(target, out _))
                {
                    throw new LythonRuntimeException("TypeError", "'str' object doesn't support item deletion", span);
                }

                throw DeletionNotSupported(target, context, span);
        }
    }

    private static object SetItem(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length != 3)
        {
            throw new LythonRuntimeException("TypeError", "operator.setitem(obj, key, value) expects three arguments.", span);
        }

        SetSubscriptValue(arguments[0], arguments[1], arguments[2], span, context);
        return PyNone.Instance;
    }

    private static object LengthHint(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        => LengthHintCoreAsync(arguments, span, context, false).GetAwaiter().GetResult();

    private static ValueTask<object> LengthHintAsync(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        => LengthHintCoreAsync(arguments, span, context, true);

    private static async ValueTask<object> LengthHintCoreAsync(object[] arguments, LythonSourceSpan span, ExecutionContext context, bool asynchronous)
    {
        // Python validates the default first, even when len() will succeed.
        var fallback = arguments.Length < 2 ? BigInteger.Zero : PyNumberOps.GetInteger(asynchronous
            ? await EvaluateIndexAsync(arguments[1], context, span).ConfigureAwait(false)
            : EvaluateIndex(arguments[1], context, span));
        if (fallback < long.MinValue || fallback > long.MaxValue)
            throw new LythonRuntimeException("OverflowError", "length hint default does not fit the supported index representation", span);
        try
        {
            return asynchronous
                ? await LenAsync([arguments[0]], span, context).ConfigureAwait(false)
                : GetLength(arguments[0], span, context);
        }
        catch (LythonRuntimeException error) when (MatchesExceptionType(BuiltinException("TypeError"), error.Identity))
        {
            context.CheckExecution(span);
        }
        if (arguments[0] is not PyInstance instance ||
            !instance.Type.TryLookupInMro("__length_hint__", 0, out var raw, out _)) return NativeHint();
        // Lookup/descriptor errors propagate. Only TypeError from the call itself
        // asks Python to use the supplied default.
        var member = asynchronous
            ? await PyAttributeLookup.BindForInstanceAsync(instance, raw, context, span).ConfigureAwait(false)
            : PyAttributeLookup.BindForInstance(instance, raw, context, span);
        object hinted;
        try
        {
            hinted = asynchronous
                ? await InvokeCallableTargetAsync(member, span, span, context, static () => ValueTask.FromResult<CallArgumentValue[]>([])).ConfigureAwait(false)
                : InvokeCallableTarget(member, span, span, context, static () => []);
        }
        catch (LythonRuntimeException error) when (MatchesExceptionType(BuiltinException("TypeError"), error.Identity))
        {
            context.CheckExecution(span);
            return fallback;
        }
        if (hinted is PyNotImplemented) return fallback;
        if (!PyNumberOps.TryAsInteger(hinted, out var length))
            throw new LythonRuntimeException("TypeError", "__length_hint__ must be an integer", span);
        if (length < 0) throw new LythonRuntimeException("ValueError", "__length_hint__() should return >= 0", span);
        if (length > long.MaxValue) throw new LythonRuntimeException("OverflowError", "length hint exceeds the supported index representation", span);
        return length;

        object NativeHint() => arguments[0] switch
        {
            PyEnumerableIterator iterator when iterator.RemainingHint is { } remaining => new BigInteger(remaining),
            PyReversedIterator iterator => new BigInteger(iterator.RemainingHint),
            StructModule.RecordIterator records => new BigInteger(records.Remaining),
            PyRepeatIterator repeat when repeat.RemainingHint is { } remaining => new BigInteger(remaining),
            _ => fallback,
        };
    }

    private static object CountOf(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        => SequenceSearchAsync(arguments, span, context, false, count: true).GetAwaiter().GetResult();

    private static ValueTask<object> CountOfAsync(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        => SequenceSearchAsync(arguments, span, context, true, count: true);

    private static object IndexOf(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        => SequenceSearchAsync(arguments, span, context, false, count: false).GetAwaiter().GetResult();

    private static ValueTask<object> IndexOfAsync(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        => SequenceSearchAsync(arguments, span, context, true, count: false);

    private static async ValueTask<object> SequenceSearchAsync(object[] arguments, LythonSourceSpan span, ExecutionContext context, bool asynchronous, bool count)
    {
        var matches = BigInteger.Zero;
        var index = BigInteger.Zero;
        if (asynchronous)
        {
            await foreach (var item in ToSequenceAsync(arguments[0], span, context).ConfigureAwait(false))
            {
                context.CheckExecution(span);
                if (await ElementEqualsAsync(item, arguments[1], context, span).ConfigureAwait(false))
                {
                    if (!count) return index;
                    matches++;
                }
                if (!count) index++;
            }
        }
        else
        {
            foreach (var item in ToSequence(arguments[0], span, context))
            {
                context.CheckExecution(span);
                if (ElementEquals(item, arguments[1], context, span))
                {
                    if (!count) return index;
                    matches++;
                }
                if (!count) index++;
            }
        }
        if (count) return matches;
        throw new LythonRuntimeException("ValueError", "sequence.index(x): x not in sequence", span);
    }

    private static object InPlaceBinary(
        object[] arguments,
        LythonSourceSpan span,
        ExecutionContext context,
        AugmentedAssignmentOperatorSyntax op)
        => Binary(arguments, span, (left, right, innerSpan) => EvaluateAugmentedAssignment(left, right, op, context, innerSpan));

    private static object InPlaceConcat(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        => Binary(arguments, span, (left, right, innerSpan) =>
        {
            if (left is PyList || PyStringOps.TryAsString(left, out _) && PyStringOps.TryAsString(right, out _) || PyTupleLike.TryGetItems(left, out _) && PyTupleLike.TryGetItems(right, out _) || left is PyBytes && right is PyBytes || left is PyDeque && right is PyDeque)
            {
                return EvaluateAugmentedAssignment(left, right, AugmentedAssignmentOperatorSyntax.Add, context, innerSpan);
            }

            throw ConcatMismatch(left, right, innerSpan);
        });

    private static object CallTarget(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length == 0 || arguments[0].IsKeyword)
        {
            throw new LythonRuntimeException("TypeError", "operator.call(obj, /, *args, **kwargs) expects a callable first positional argument.", span);
        }

        return InvokeCallableTarget(arguments[0].Value, span, span, context, () => arguments[1..]);
    }

    private static object CreateItemGetter(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length == 0)
        {
            throw new LythonRuntimeException("TypeError", "operator.itemgetter(item[, ...]) expects one or more positional arguments.", span);
        }

        var items = new object[arguments.Length];
        for (var i = 0; i < arguments.Length; i++)
        {
            if (arguments[i].IsKeyword)
            {
                throw new LythonRuntimeException("TypeError", "operator.itemgetter(item[, ...]) expects one or more positional arguments.", span);
            }

            items[i] = RuntimeValue(arguments[i].Value);
        }

        // The items array is retained with aliased values; own the object and backing.
        var ownedItems = checked(160L + 16L * items.Length);
        context.MemoryGovernor.Reserve(ownedItems, span);
        context.MemoryGovernor.Commit(ownedItems);
        return new PyItemGetter(items);
    }

    private static object CreateAttrGetter(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length == 0)
        {
            throw new LythonRuntimeException("TypeError", "operator.attrgetter(attr[, ...]) expects one or more positional string arguments.", span);
        }

        var paths = new string[arguments.Length][];
        var totalParts = 0;
        for (var i = 0; i < arguments.Length; i++)
        {
            var argument = arguments[i];
            if (argument.IsKeyword)
            {
                throw new LythonRuntimeException("TypeError", "operator.attrgetter(attr[, ...]) expects one or more positional string arguments.", span);
            }

            if (!PyStringOps.TryAsString(argument.Value, out var text))
            {
                throw new LythonRuntimeException("TypeError", "operator.attrgetter(attr[, ...]) expects string arguments.", span);
            }

            var parts = text.AsString().Split('.');
            if (parts.Length == 0 || parts.Any(static part => part.Length == 0))
            {
                throw new LythonRuntimeException("TypeError", "operator.attrgetter(attr[, ...]) expects non-empty dotted attribute names.", span);
            }

            paths[i] = parts;
            totalParts += parts.Length;
        }

        // Path strings derive from already-owned argument payloads; own the
        // object, the outer array and one backing slot per part.
        var ownedPaths = checked(160L + 48L * paths.Length + 16L * totalParts);
        context.MemoryGovernor.Reserve(ownedPaths, span);
        context.MemoryGovernor.Commit(ownedPaths);
        return new PyAttrGetter(paths);
    }

    private static object CreateMethodCaller(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length == 0 || arguments[0].IsKeyword || !PyStringOps.TryAsString(arguments[0].Value, out var name))
        {
            throw new LythonRuntimeException("TypeError", "operator.methodcaller(name, ...) expects the first argument to be a method name string.", span);
        }

        // The name and argument values stay aliased; own the object and the copied argument array.
        var ownedCall = checked(160L + 16L * (arguments.Length - 1));
        context.MemoryGovernor.Reserve(ownedCall, span);
        context.MemoryGovernor.Commit(ownedCall);
        return new PyMethodCaller(name.AsString(), arguments[1..]);
    }
}
