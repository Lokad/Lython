using System.Globalization;
using System.Numerics;
using Lokad.Lython.Runtime.Numbers;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    private static object Round(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length is < 1 or > 2)
        {
            throw new LythonRuntimeException("TypeError", "round(number[, ndigits]) expects one or two arguments.", span);
        }

        var hasDigits = arguments.Length == 2 && arguments[1] is not PyNone;

        // User-defined __round__ takes precedence like CPython, receiving
        // ndigits untouched when present; anything it resolves to is called.
        if (arguments[0] is PyInstance roundInstance &&
            roundInstance.TryGetAttribute("__round__", context, span, out var roundMember))
        {
            if (roundMember is not ICallable roundCallable)
            {
                throw new LythonRuntimeException("TypeError", "'" + UnboundTypeMethod.PythonTypeName(roundMember, context) + "' object is not callable", span);
            }

            return hasDigits
                ? CallableInvocation.InvokeUnary(roundCallable, arguments[1], span, context)
                : roundCallable.Invoke([], span, context);
        }

        int? digits = null;
        if (hasDigits)
        {
            var coercedDigits = CoerceIndexProtocol(arguments[1], context, span);
            if (!PyNumberOps.TryAsInteger(coercedDigits, out var digitsValue))
            {
                throw new LythonRuntimeException("TypeError", "'" + RuntimeErrors.DatetimeQualifiedTypeName(arguments[1], context) + "' object cannot be interpreted as an integer", span);
            }

            digits = ToInt32(digitsValue, "round(number[, ndigits])", span);
        }

        if (arguments[0] is (PySmallInteger or BigInteger) && (digits is null || digits >= 0)) return arguments[0];

        var rounded = arguments[0] switch
        {
            bool boolean => RoundInteger(boolean ? BigInteger.One : BigInteger.Zero, digits, span),
            _ when PyNumberOps.TryAsInteger(arguments[0], out var integer) => RoundInteger(integer, digits, span),
            double floating => RoundFloat(floating, digits, span),
            PyDecimal decimalValue => RoundDecimal(decimalValue, digits, context, span),
            _ => throw new LythonRuntimeException("TypeError", $"type {RuntimeErrors.DatetimeQualifiedTypeName(arguments[0], context)} doesn't define __round__ method", span)
        };

        // Decimal rounding creates a result; keep its ownership through projection.
        if (rounded is PyDecimal roundedDecimal)
        {
            return OwnDecimalValue(roundedDecimal, context, span);
        }

        return OwnHeapInteger(rounded, context.MemoryGovernor, span);

        static object RoundInteger(BigInteger value, int? digits, LythonSourceSpan span)
        {
            if (digits is null || digits >= 0)
            {
                return value;
            }

            if (value.IsZero)
            {
                return BigInteger.Zero;
            }

            var places = -(long)digits.Value;
            var decimalDigitUpperBound = (long)Math.Ceiling(BigInteger.Abs(value).GetBitLength() * Math.Log10(2.0));
            if (places > decimalDigitUpperBound)
            {
                return BigInteger.Zero;
            }

            if (places > int.MaxValue)
            {
                throw new LythonRuntimeException("OverflowError", "round() ndigits is too large.", span);
            }

            var factor = BigInteger.Pow(10, (int)places);
            var sign = value < BigInteger.Zero ? -1 : 1;
            var quotient = BigInteger.DivRem(BigInteger.Abs(value), factor, out var remainder);
            var comparison = (remainder * 2).CompareTo(factor);
            if (comparison > 0 || (comparison == 0 && !quotient.IsEven))
            {
                quotient += BigInteger.One;
            }

            return quotient * factor * sign;
        }

        static object RoundDecimal(PyDecimal value, int? digits, ExecutionContext context, LythonSourceSpan span)
        {
            if (digits is null)
            {
                return new BigInteger(decimal.Round(value.Value, 0, MidpointRounding.ToEven));
            }

            return PyDecimalOps.Quantize(value, -(long)digits.Value, PyNone.Instance, context.DecimalContext, context, span);
        }

        static object RoundFloat(double value, int? digits, LythonSourceSpan span)
        {
            if (digits is null)
            {
                return FloatToInteger(value, span, static number => Math.Round(number, MidpointRounding.ToEven));
            }

            try
            {
                return RoundToDigits(value, digits.Value);
            }
            catch (OverflowException ex)
            {
                throw new LythonRuntimeException("OverflowError", ex.Message, span);
            }

            static double RoundToDigits(double value, int digits)
            {
                if (!double.IsFinite(value)
                    || value == 0.0
                    || digits > 323
                    || (digits >= 0 && Math.Abs(value) >= 9_007_199_254_740_992.0))
                {
                    return value;
                }

                if (digits < -308)
                {
                    return Math.CopySign(0.0, value);
                }

                // A binary64 value is an exact integer times a power of two. Round that
                // rational value directly so decimal halfway decisions do not inherit
                // System.Math.Round's decimal-scaling approximation (for example 2.675).
                var bits = (ulong)BitConverter.DoubleToInt64Bits(Math.Abs(value));
                var exponentBits = (int)((bits >> 52) & 0x7FF);
                var fraction = bits & 0x000F_FFFF_FFFF_FFFF;
                var significand = exponentBits == 0 ? fraction : fraction | 0x0010_0000_0000_0000;
                var binaryExponent = exponentBits == 0 ? -1074 : exponentBits - 1023 - 52;

                var numerator = new BigInteger(significand);
                var denominator = BigInteger.One;
                if (digits >= 0)
                {
                    numerator *= BigInteger.Pow(5, digits);
                }
                else
                {
                    denominator = BigInteger.Pow(5, -digits);
                }

                binaryExponent += digits;
                if (binaryExponent >= 0)
                {
                    numerator <<= binaryExponent;
                }
                else
                {
                    denominator <<= -binaryExponent;
                }

                var rounded = BigInteger.DivRem(numerator, denominator, out var remainder);
                var midpointComparison = (remainder * 2).CompareTo(denominator);
                if (midpointComparison > 0 || (midpointComparison == 0 && !rounded.IsEven))
                {
                    rounded += BigInteger.One;
                }

                // Parsing the exact decimal result delegates the final binary64 choice to
                // the runtime's correctly-rounded parser, including subnormal results. The
                // cutoffs above bound this representation to 344 characters.
                Span<char> text = stackalloc char[344];
                if (!rounded.TryFormat(text, out var length, default, CultureInfo.InvariantCulture))
                {
                    throw new InvalidOperationException("rounded float text exceeded its proven bound");
                }

                text[length++] = 'e';
                if (!(-digits).TryFormat(text[length..], out var exponentLength, default, CultureInfo.InvariantCulture))
                {
                    throw new InvalidOperationException("rounded float exponent exceeded its proven bound");
                }

                length += exponentLength;
                var result = double.Parse(text[..length], NumberStyles.Float, CultureInfo.InvariantCulture);
                if (!double.IsFinite(result))
                {
                    throw new OverflowException("rounded value too large to represent");
                }

                return Math.CopySign(result, value);
            }
        }
    }
}
