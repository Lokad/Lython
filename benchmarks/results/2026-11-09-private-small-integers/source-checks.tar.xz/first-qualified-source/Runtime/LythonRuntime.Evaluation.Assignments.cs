using System.Text.RegularExpressions;
using Lokad.Lython.Frontend;
using System.Numerics;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.Json;
using System.Threading;
using Lokad.Lython.Runtime.Numbers;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    private static void ThrowAssertionError(object? message, ExecutionContext context, LythonSourceSpan span)
    {
        var args = new PyTuple(message is null ? [] : [message], context.MemoryGovernor, span);
        var error = new LythonRuntimeException("AssertionError", string.Empty, span)
        {
            OriginalPythonException = new PyException(PythonExceptionIdentity.FromRuntimeTypeName("AssertionError"), string.Empty, null, args),
        };
        // Raising does not render the argument. Reuse the existing authoritative
        // args path so later str() sees mutations and invokes protocols lazily.
        throw error;
    }

    private static bool TryGetDeleteDisplayItems(
        LoweredExpression loweredTarget,
        out IReadOnlyList<CollectionDisplayItemSyntax> syntaxItems,
        out IReadOnlyList<LoweredCollectionDisplayItem> loweredItems)
    {
        if (loweredTarget is LoweredTupleLiteralExpression loweredTuple
            && loweredTuple.Items.Count == loweredTuple.Tuple.Items.Count)
        {
            syntaxItems = loweredTuple.Tuple.Items;
            loweredItems = loweredTuple.Items;
            return true;
        }

        if (loweredTarget is LoweredListLiteralExpression loweredList
            && loweredList.Items.Count == loweredList.List.Items.Count)
        {
            syntaxItems = loweredList.List.Items;
            loweredItems = loweredList.Items;
            return true;
        }

        syntaxItems = [];
        loweredItems = [];
        return false;
    }

    internal static void DeleteSubscriptValue(object target, object index, LythonSourceSpan span, ExecutionContext context)
    {
        using var _ambientScope = PyStructuralGuard.PushAmbient(context, span);
        // Slice objects delete through the shared slice path on lists like
        // CPython; every other receiver keeps its existing behaviour.
        if (index is PySlice sliceIndex && target is PyList)
        {
            ExecuteSliceDeletion(target, sliceIndex.StartBound, sliceIndex.StopBound, sliceIndex.StepBound, span, context);
            return;
        }
        if (UsesNativeMutationIndex(target) && index is PyInstance)
            index = CoerceTypeIndexAsync(index, context, span, false).GetAwaiter().GetResult() ?? PyNone.Instance;

        switch (target)
        {
            case IDeletablePySubscriptableValue subscriptable:
                subscriptable.DeleteSubscript(index, span);
                return;

            case IMutablePySequenceValue sequence:
                sequence.RemoveAt(PyIndexing.NormalizeIndex(index, sequence.Count, span, PyIndexing.TargetKind(sequence), PyIndexing.IndexOperation.Delete));
                return;

            case PyDict dict:
                if (!dict.Remove(ValidateDictionaryKey(index, span)))
                {
                    throw RuntimeErrors.MissingKey(index, span);
                }

                return;

            case PyDefaultDict defaultDict:
                if (!defaultDict.Remove(ValidateDictionaryKey(index, span)))
                {
                    throw RuntimeErrors.MissingKey(index, span);
                }

                return;

            case PyCounter counter:
                _ = counter.Remove(ValidateDictionaryKey(index, span));
                return;

            case PyInstance instance:
                InvokeItemMutation(instance, "__delitem__", [CallArgumentValue.Positional(index)], context, span);
                return;

            case PyTuple:
                throw new LythonRuntimeException("TypeError", "'tuple' object doesn't support item deletion", span);

            case PyString:
                throw new LythonRuntimeException("TypeError", "'str' object doesn't support item deletion", span);
            case PyBytes:
                throw new LythonRuntimeException("TypeError", "'bytes' object doesn't support item deletion", span);

            default:
                throw DeletionNotSupported(target, context, span);
        }
    }

    private static object EvaluateChainedComparison(ChainedComparisonExpressionSyntax chainedComparison, ExecutionContext context)
    {
        var left = EvaluateExpression(chainedComparison.Operands[0], context);
        for (var i = 0; i < chainedComparison.Operators.Count; i++)
        {
            var right = EvaluateExpression(chainedComparison.Operands[i + 1], context);
            var result = EvaluateBinaryOperator(chainedComparison.Operators[i], left, right, context, chainedComparison.Span);
            if (i == chainedComparison.Operators.Count - 1 || !IsTruthy(result, context, chainedComparison.Span))
            {
                return result;
            }

            left = right;
        }

        return true;
    }

    private static object CreateLambda(LambdaExpressionSyntax lambda, ExecutionContext context)
        => CreateLoweredLambda(lambda.PreparedCallable.RequireNotNull(), context);

    private sealed record AugmentedAssignmentTargetReference(object CurrentValue, Action<object> Store, Func<object, ValueTask>? AsyncStore = null)
    {
        public ValueTask StoreValueAsync(object value)
        {
            if (AsyncStore is not null) return AsyncStore(value);
            Store(value); return ValueTask.CompletedTask;
        }
    }

    private static void InvokeItemMutation(
        PyInstance instance,
        string methodName,
        CallArgumentValue[] arguments,
        ExecutionContext context,
        LythonSourceSpan span)
    {
        if (!instance.Type.TryLookupInMro(methodName, 0, out var raw, out _))
            throw new LythonRuntimeException("TypeError", $"'{instance.Type.Name}' object does not support item mutation", span);
        var member = PyAttributeLookup.BindForInstance(instance, raw, context, span);
        if (member is not ICallable callable)
        {
            throw new LythonRuntimeException("TypeError", $"'{instance.Type.Name}' object does not support item mutation", span);
        }

        _ = callable.Invoke(arguments, span, context);
    }

    internal static void AssignTarget(AssignmentTargetSyntax target, object value, ExecutionContext context)
    {
        switch (target)
        {
            case NameAssignmentTargetSyntax name:
                StoreName(name.Name, value, context, name.Span);
                return;
            case UnpackingAssignmentTargetGroupSyntax unpacking:
                AssignTargets(unpacking.Targets, value, unpacking.Span, context);
                return;
            case SubscriptAssignmentTargetSyntax subscript:
                AssignSubscriptTarget(subscript, value, context);
                return;
            case SliceAssignmentTargetSyntax slice:
                AssignSliceTarget(slice, value, context);
                return;
            case MemberAssignmentTargetSyntax member:
                AssignMemberTarget(member, value, context);
                return;
            default:
                throw new InvalidOperationException($"Unsupported assignment target syntax: {target.GetType().Name}");
        }
    }

    private static void AssignSubscriptTarget(SubscriptAssignmentTargetSyntax subscript, object value, ExecutionContext context)
    {
        var target = EvaluateExpression(subscript.Target, context);
        var index = EvaluateExpression(subscript.Index, context);
        SetSubscriptValue(target, index, value, subscript.Span, context);
    }

    internal static void SetSubscriptValue(object target, object index, object value, LythonSourceSpan span, ExecutionContext context)
    {
        if (target is PyDict native && native.TryWriteKeyWithoutAdmission(index, value, context, span))
        {
            context.CheckExecution(span);
            return;
        }
        using var _ambientScope = PyStructuralGuard.PushAmbient(context, span);
        // Slice objects assign through the shared slice path on lists like
        // CPython; every other receiver keeps its existing behaviour.
        if (index is PySlice slice && target is PyList)
        {
            ExecuteSliceAssignment(target, slice.StartBound, slice.StopBound, slice.StepBound, value, span, context);
            return;
        }
        if (UsesNativeMutationIndex(target) && index is PyInstance)
            index = CoerceTypeIndexAsync(index, context, span, false).GetAwaiter().GetResult() ?? PyNone.Instance;

        switch (target)
        {
            case IMutablePySubscriptableValue subscriptable:
                subscriptable.SetSubscript(index, value, span);
                return;

            case IMutablePySequenceValue sequence:
                sequence.SetItem(PyIndexing.NormalizeIndex(index, sequence.Count, span, PyIndexing.TargetKind(sequence), PyIndexing.IndexOperation.Assign), value);
                return;
            case PyDict dict:
                dict.AttachMemoryGovernor(context.MemoryGovernor, span);
                dict.SetItem(ValidateDictionaryKey(index, span), value);
                context.CheckExecution(span);
                return;
            case PyDefaultDict defaultDict:
                defaultDict.AttachMemoryGovernor(context.MemoryGovernor, span);
                defaultDict.SetItem(ValidateDictionaryKey(index, span), value);
                context.CheckExecution(span);
                return;
            case PyCounter counter:
                counter.AttachMemoryGovernor(context.MemoryGovernor, span);
                counter.SetItem(ValidateDictionaryKey(index, span), value);
                context.CheckExecution(span);
                return;
            case PyInstance instance:
                InvokeItemMutation(
                    instance,
                    "__setitem__",
                    [CallArgumentValue.Positional(index), CallArgumentValue.Positional(value)],
                    context,
                    span);
                return;
            case PyTuple:
                throw new LythonRuntimeException("TypeError", "'tuple' object does not support item assignment", span);
            case PyString:
                throw new LythonRuntimeException("TypeError", "'str' object does not support item assignment", span);
            case PyBytes:
                throw new LythonRuntimeException("TypeError", "'bytes' object does not support item assignment", span);
            default:
                throw AssignmentNotSupported(target, context, span);
        }
    }

    // Deletion names scalar receivers with does-not like CPython and every
    // other receiver with doesn't; stores always use does-not.
    private static LythonRuntimeException DeletionNotSupported(object target, ExecutionContext context, LythonSourceSpan span)
    {
        var name = target switch
        {
            PyNamedTupleObject named => named.Type.Name,
            _ => UnboundTypeMethod.PythonTypeName(target, context),
        };
        var verb = PyNumberOps.IsInteger(target) || target is double || target is PyNone ? "does not" : "doesn't";
        return new LythonRuntimeException("TypeError", $"'{name}' object {verb} support item deletion", span);
    }

    private static LythonRuntimeException AssignmentNotSupported(object target, ExecutionContext context, LythonSourceSpan span)
    {
        var name = target switch
        {
            PyNamedTupleObject named => named.Type.Name,
            _ => UnboundTypeMethod.PythonTypeName(target, context),
        };
        return new LythonRuntimeException("TypeError", $"'{name}' object does not support item assignment", span);
    }

    private static void AssignSliceTarget(SliceAssignmentTargetSyntax slice, object value, ExecutionContext context)
    {
        ExecuteSliceAssignment(
            EvaluateExpression(slice.Target, context),
            slice.Start is null ? null : EvaluateExpression(slice.Start, context),
            slice.End is null ? null : EvaluateExpression(slice.End, context),
            slice.Step is null ? null : EvaluateExpression(slice.Step, context),
            value,
            slice.Span,
            context);
    }

    private static void AssignMemberTarget(MemberAssignmentTargetSyntax member, object value, ExecutionContext context)
    {
        var target = EvaluateExpression(member.Target, context);
        SetMemberValue(target, member.MemberName, value, member.Span, context);
    }

    private static void SetMemberValue(object target, string memberName, object value, LythonSourceSpan span, ExecutionContext context)
    {
        if (!PyMemberAccess.TryAssign(target, memberName, value, context, span))
        {
            throw new LythonRuntimeException("TypeError", "Object does not support attribute assignment.", span);
        }
    }

    private static AugmentedAssignmentTargetReference ResolveAugmentedAssignmentTarget(AssignmentTargetSyntax target, ExecutionContext context)
    {
        switch (target)
        {
            case NameAssignmentTargetSyntax name:
                var currentValue = ResolveName(name.Name, name.Span, context);

                return new AugmentedAssignmentTargetReference(
                    currentValue,
                    value => StoreName(name.Name, value, context, name.Span));

            case SubscriptAssignmentTargetSyntax subscript:
                var subscriptTarget = EvaluateExpression(subscript.Target, context);
                var index = EvaluateExpression(subscript.Index, context);
                var subscriptValue = ReadSubscriptValue(subscriptTarget, index, subscript.Span, context);
                return new AugmentedAssignmentTargetReference(
                    subscriptValue,
                    value => SetSubscriptValue(subscriptTarget, index, value, subscript.Span, context));

            case SliceAssignmentTargetSyntax slice:
                var sliceTarget = EvaluateExpression(slice.Target, context);
                var start = slice.Start is null ? null : EvaluateExpression(slice.Start, context);
                var end = slice.End is null ? null : EvaluateExpression(slice.End, context);
                var step = slice.Step is null ? null : EvaluateExpression(slice.Step, context);
                if (sliceTarget is PyInstance instance)
                {
                    var sliceIndex = CreateSliceValue(start, end, step, slice.Span, context);
                    var current = GetUserItem(instance, sliceIndex, context, slice.Span);
                    return new AugmentedAssignmentTargetReference(current,
                        value => SetSubscriptValue(instance, sliceIndex, value, slice.Span, context));
                }
                var sliceValue = PyIndexing.ReadSlice(sliceTarget, start, end, step, slice.Span, context);
                return new AugmentedAssignmentTargetReference(
                    sliceValue,
                    value => ExecuteSliceAssignment(sliceTarget, start, end, step, value, slice.Span, context));

            case MemberAssignmentTargetSyntax member:
                var memberTarget = EvaluateExpression(member.Target, context);
                if (!TryResolveRuntimeMember(memberTarget, member.MemberName, context, member.Span, out var memberValue))
                {
                    throw PyMemberAccess.CreateMissingMemberError(memberTarget, member.MemberName, member.Span, context);
                }

                return new AugmentedAssignmentTargetReference(
                    memberValue,
                    value => SetMemberValue(memberTarget, member.MemberName, value, member.Span, context));

            default:
                throw new LythonRuntimeException("TypeError", "Unsupported augmented assignment target.", target.Span);
        }
    }

    internal static object ReadSubscriptValue(object target, object index, LythonSourceSpan span, ExecutionContext context)
    {
        if (target is ElementTreeModule.Element element)
            return ElementTreeModule.ReadIndexAsync(element, index, context, span, false).GetAwaiter().GetResult();
        if (target is ReMatchObject match)
        {
            return ReMatchMembers.GetSubscript(match, index, span, context);
        }

        if (target is PyDefaultDict defaultDict)
        {
            return defaultDict.GetOrCreate(ValidateDictionaryKey(index, span), context, span);
        }

        if (target is PyInstance instance)
        {
            return GetUserItem(instance, index, context, span);
        }

        if ((target is IPyIndexableValue or PyRange) && index is PyInstance)
            index = CoerceTypeIndexAsync(index, context, span, false).GetAwaiter().GetResult() ?? PyNone.Instance;
        return PyIndexing.ReadIndex(target, index, span, context);
    }

    private static async ValueTask ExtendDequeAsync(PyDeque target, object source, LythonSourceSpan span,
        ExecutionContext context, bool asynchronous)
    {
        if (ReferenceEquals(target, source))
        {
            using var snapshot = PyIteration.DrainLeased(target.Iterate(), span, context);
            foreach (var item in snapshot.Items)
            {
                context.CheckExecution(span);
                target.Append(item);
            }
        }
        else if (asynchronous)
        {
            await foreach (var item in ToSequenceAsync(source, span, context).ConfigureAwait(false)) target.Append(item);
        }
        else
        {
            foreach (var item in ToSequence(source, span, context)) target.Append(item);
        }
    }

    private static void ExecuteSliceAssignment(object target, object? start, object? end, object? step,
        object value, LythonSourceSpan span, ExecutionContext context)
        => ExecuteSliceAssignmentCoreAsync(target, start, end, step, value, span, context, false).GetAwaiter().GetResult();

    private static ValueTask ExecuteSliceAssignmentAsync(object target, object? start, object? end, object? step,
        object value, LythonSourceSpan span, ExecutionContext context)
        => ExecuteSliceAssignmentCoreAsync(target, start, end, step, value, span, context, true);

    private static async ValueTask ExecuteSliceAssignmentCoreAsync(
        object target,
        object? start,
        object? end,
        object? step,
        object value,
        LythonSourceSpan span,
        ExecutionContext context, bool asynchronous)
    {
        if (target is PyInstance)
        {
            var key = CreateSliceValue(start, end, step, span, context);
            if (asynchronous) await SetHeaderSubscriptAsync(target, key, value, span, context).ConfigureAwait(false);
            else SetSubscriptValue(target, key, value, span, context);
            return;
        }

        // Mappings store colon slices as keys like CPython; bounds stay raw.
        if (target is PyDict || target is PyCounter || target is PyDefaultDict || target is PyChainMap)
        {
            SetSubscriptValue(target, PyIndexing.CreateMappingSliceKey(start, end, step, context, span), value, span, context);
            return;
        }

        if (target is PyDeque)
            throw new LythonRuntimeException("TypeError", "sequence index must be integer, not 'slice'", span);

        // Complete bound validation before draining replacement values.
        (start, end, step) = await CoerceSliceBoundsAsync(start, end, step, context, span, asynchronous).ConfigureAwait(false);

        if (target is PyList list)
        {
            list.AttachMemoryGovernor(context.MemoryGovernor, span);
            // Keep replacement backing funded alongside destination growth.
            using var replacement = asynchronous
                ? await PyIteration.MaterializeLeasedAsync(value, span, context).ConfigureAwait(false)
                : PyIteration.MaterializeLeased(value, span, context);
            var bounds = PyIndexing.NormalizeSliceBounds(list.Count, start, end, step, span);
            list.SetSlice(bounds, replacement.Items, span);
            context.CheckExecution(span);
            return;
        }

        if (target is PyTuple)
        {
            throw new LythonRuntimeException("TypeError", "'tuple' object does not support item assignment", span);
        }

        if (PyStringOps.TryAsString(target, out _))
        {
            throw new LythonRuntimeException("TypeError", "'str' object does not support item assignment", span);
        }

        throw new LythonRuntimeException("TypeError", "Object does not support slice assignment.", span);
    }

    private static void ExecuteSliceDeletion(object target, object? start, object? end, object? step,
        LythonSourceSpan span, ExecutionContext context)
        => ExecuteSliceDeletionCoreAsync(target, start, end, step, span, context, false).GetAwaiter().GetResult();

    private static async ValueTask ExecuteSliceDeletionCoreAsync(
        object target,
        object? start,
        object? end,
        object? step,
        LythonSourceSpan span,
        ExecutionContext context, bool asynchronous)
    {
        if (target is PyInstance instance)
        {
            var key = CreateSliceValue(start, end, step, span, context);
            if (asynchronous) await ExecuteResolvedSubscriptDeletionAsync(instance, key, span, context).ConfigureAwait(false);
            else InvokeItemMutation(instance, "__delitem__", [CallArgumentValue.Positional(key)], context, span);
            return;
        }
        // Mappings delete colon slices as keys like CPython; bounds stay raw.
        if (target is PyDict || target is PyCounter || target is PyDefaultDict || target is PyChainMap)
        {
            var key = ValidateDictionaryKey(PyIndexing.CreateMappingSliceKey(start, end, step, context, span), span);
            switch (target)
            {
                case PyChainMap chainMap:
                    chainMap.DeleteSubscript(key, span);
                    return;
                case PyDict dict:
                    if (!dict.Remove(key))
                    {
                        throw RuntimeErrors.MissingKey(key, span);
                    }

                    return;

                case PyDefaultDict defaultDict:
                    if (!defaultDict.Remove(key))
                    {
                        throw RuntimeErrors.MissingKey(key, span);
                    }

                    return;

                default:
                    _ = ((PyCounter)target).Remove(key);
                    return;
            }
        }

        if (target is PyDeque)
            throw new LythonRuntimeException("TypeError", "sequence index must be integer, not 'slice'", span);

        (start, end, step) = await CoerceSliceBoundsAsync(start, end, step, context, span, asynchronous).ConfigureAwait(false);

        if (target is PyList list)
        {
            var bounds = PyIndexing.NormalizeSliceBounds(list.Count, start, end, step, span);
            list.DeleteSlice(bounds);
            return;
        }

        if (target is PyTuple)
        {
            throw new LythonRuntimeException("TypeError", "'tuple' object does not support item deletion", span);
        }

        if (PyStringOps.TryAsString(target, out _))
        {
            throw new LythonRuntimeException("TypeError", "'str' object does not support item deletion", span);
        }

        throw new LythonRuntimeException("TypeError", "Object does not support slice deletion.", span);
    }

    private static void ExecuteWithStatement(
        WithStatementSyntax statement,
        LoweredExpression loweredContextExpression,
        IReadOnlyList<LoweredStatement> loweredBody,
        ExecutionContext context)
    {
        _ = PyContextManagers.ExecuteWith(
            EvaluateLoweredExpression(loweredContextExpression, context),
            statement.LoweredTarget,
            loweredBody,
            statement.Span,
            statement.ContextExpression.Span,
            context);
    }

    private static async ValueTask ExecuteWithStatementAsync(
        WithStatementSyntax statement,
        LoweredExpression loweredContextExpression,
        IReadOnlyList<LoweredStatement> loweredBody,
        ExecutionContext context)
    {
        _ = await PyContextManagers.ExecuteWithAsync(
                await EvaluateLoweredExpressionAsync(loweredContextExpression, context).ConfigureAwait(false),
                statement.LoweredTarget,
                loweredBody,
                statement.Span,
                statement.ContextExpression.Span,
                context)
            .ConfigureAwait(false);
    }

    private static object EvaluateAugmentedAssignment(
        object currentValue,
        object right,
        AugmentedAssignmentOperatorSyntax op,
        ExecutionContext context,
        LythonSourceSpan span)
    {
        if (op == AugmentedAssignmentOperatorSyntax.Add &&
            currentValue is (PySmallInteger or BigInteger) && right is (PySmallInteger or BigInteger))
            return AddExactIntegers(currentValue, right, context.MemoryGovernor, span);

        if (op == AugmentedAssignmentOperatorSyntax.MatrixMultiply) return EvaluateMatrixInPlaceAsync(currentValue, right, context, span, false).GetAwaiter().GetResult();
        var inPlaceMethod = AugmentedInPlaceMethod(op);
        if (inPlaceMethod is not null &&
            TryInvokeBinarySpecialMethod(currentValue, inPlaceMethod, right, context, span, out var inPlaceResult) &&
            inPlaceResult is not PyNotImplemented)
        {
            return inPlaceResult;
        }

        if (op == AugmentedAssignmentOperatorSyntax.Multiply && IsSequenceOperand(currentValue) && right is PyInstance)
        {
            if (TryEvaluateNumericProtocol(BinaryOperatorSyntax.Multiply, currentValue, right, context, span, out var repeated))
                return repeated;
            var count = CoerceIndexProtocol(right, context, span);
            if (!PyNumberOps.IsInteger(count)) throw RuntimeErrors.MultiplySequenceError(right, span);
            right = count;
        }

        if (op == AugmentedAssignmentOperatorSyntax.Add &&
            currentValue is PyList currentList)
        {
            currentList.AddRange(ToSequence(right, span, context), context, span);
            return currentList;
        }

        if (op == AugmentedAssignmentOperatorSyntax.Add &&
            currentValue is PyDeque currentDeque)
        {
            ExtendDequeAsync(currentDeque, right, span, context, false).GetAwaiter().GetResult();
            return currentDeque;
        }

        if (op == AugmentedAssignmentOperatorSyntax.Multiply &&
            currentValue is PyList multipliedList &&
            TryRepeatCount(right, context, span, out var repeatCount))
        {
            multipliedList.RepeatInPlace(ToListRepeatCount(repeatCount, span), span, context);
            context.CheckExecution(span);
            return multipliedList;
        }

        if (op == AugmentedAssignmentOperatorSyntax.Multiply &&
            currentValue is PyDeque multipliedDeque &&
            TryRepeatCount(right, context, span, out var dequeRepeatCount))
        {
            multipliedDeque.RepeatInPlace(dequeRepeatCount, span, context);
            context.CheckExecution(span);
            return multipliedDeque;
        }

        // R13b: in-place set algebra below observes ambient provenance.
        using var _ambientScope = PyStructuralGuard.PushAmbient(context, span);
        if (currentValue is PySet currentSet && right is PySet rightSet)
        {
            switch (op)
            {
                case AugmentedAssignmentOperatorSyntax.BitwiseOr:
                    currentSet.UnionWith(rightSet);
                    return currentSet;
                case AugmentedAssignmentOperatorSyntax.BitwiseAnd:
                    currentSet.IntersectWith(rightSet);
                    return currentSet;
                case AugmentedAssignmentOperatorSyntax.BitwiseXor:
                    currentSet.SymmetricExceptWith(rightSet);
                    return currentSet;
                case AugmentedAssignmentOperatorSyntax.Subtract:
                    currentSet.ExceptWith(rightSet);
                    return currentSet;
            }
        }

        if (op == AugmentedAssignmentOperatorSyntax.BitwiseOr &&
            currentValue is PyDict currentDict)
        {
            // Stage through a temporary like dict.update so pair
            // iterables merge exactly like mappings.
            var stagedDict = new PyDict(context.MemoryGovernor, span);
            UpdateDictionaryFromSource(stagedDict, right, context, span);
            using var ambient = PyStructuralGuard.PushAmbient(context, span);
            foreach (var pair in stagedDict)
            {
                currentDict.SetItem(pair.Key, pair.Value);
            }

            return currentDict;
        }

        if (op == AugmentedAssignmentOperatorSyntax.BitwiseOr &&
            currentValue is PyDefaultDict currentDefault)
        {
            var stagedDefault = new PyDict(context.MemoryGovernor, span);
            UpdateDictionaryFromSource(stagedDefault, right, context, span);
            using var ambient = PyStructuralGuard.PushAmbient(context, span);
            foreach (var pair in stagedDefault)
            {
                currentDefault.SetItem(pair.Key, pair.Value);
            }

            return currentDefault;
        }

        if (op == AugmentedAssignmentOperatorSyntax.BitwiseOr &&
            currentValue is PyCounter currentCounter)
        {
            if (!IsInPlaceMergeOperand(right))
            {
                throw PyMemberAccess.CreateMissingMemberError(right, "items", span, context);
            }

            MergeCounterUnionInPlace(currentCounter, right, span, context);
            return currentCounter;
        }

        if (op == AugmentedAssignmentOperatorSyntax.BitwiseOr &&
            currentValue is PyChainMap currentChain)
        {
            var staged = new PyDict(context.MemoryGovernor, span);
            UpdateDictionaryFromSource(staged, right, context, span);
            using var ambient = PyStructuralGuard.PushAmbient(context, span);
            foreach (var pair in staged)
            {
                currentChain.SetSubscript(pair.Key, pair.Value, span);
            }

            return currentChain;
        }

        // A missing or declining in-place slot falls back to ordinary binary
        // protocols, including reflected/subclass precedence. Keep the final
        // builtin funnel below so unsupported operands still name the += token.
        var binaryOperator = AugmentedBinaryOperator(op);
        if (TryEvaluateNumericProtocol(binaryOperator, currentValue, right, context, span, out var fallbackResult))
            return fallbackResult;

        return EvaluateAugmentedBuiltin(currentValue, right, op, context, span);
    }

    private static string? AugmentedInPlaceMethod(AugmentedAssignmentOperatorSyntax op)
        => op switch
        {
            AugmentedAssignmentOperatorSyntax.Add => "__iadd__",
            AugmentedAssignmentOperatorSyntax.Subtract => "__isub__",
            AugmentedAssignmentOperatorSyntax.Multiply => "__imul__",
            AugmentedAssignmentOperatorSyntax.Divide => "__itruediv__",
            AugmentedAssignmentOperatorSyntax.FloorDivide => "__ifloordiv__",
            AugmentedAssignmentOperatorSyntax.Modulo => "__imod__",
            AugmentedAssignmentOperatorSyntax.Power => "__ipow__",
            AugmentedAssignmentOperatorSyntax.BitwiseOr => "__ior__",
            AugmentedAssignmentOperatorSyntax.BitwiseXor => "__ixor__",
            AugmentedAssignmentOperatorSyntax.BitwiseAnd => "__iand__",
            AugmentedAssignmentOperatorSyntax.LeftShift => "__ilshift__",
            AugmentedAssignmentOperatorSyntax.RightShift => "__irshift__",
            _ => null,
        };

    private static BinaryOperatorSyntax AugmentedBinaryOperator(AugmentedAssignmentOperatorSyntax op)
        => op switch
        {
            AugmentedAssignmentOperatorSyntax.Add => BinaryOperatorSyntax.Add,
            AugmentedAssignmentOperatorSyntax.Subtract => BinaryOperatorSyntax.Subtract,
            AugmentedAssignmentOperatorSyntax.Multiply => BinaryOperatorSyntax.Multiply,
            AugmentedAssignmentOperatorSyntax.Divide => BinaryOperatorSyntax.Divide,
            AugmentedAssignmentOperatorSyntax.FloorDivide => BinaryOperatorSyntax.FloorDivide,
            AugmentedAssignmentOperatorSyntax.Modulo => BinaryOperatorSyntax.Modulo,
            AugmentedAssignmentOperatorSyntax.Power => BinaryOperatorSyntax.Power,
            AugmentedAssignmentOperatorSyntax.BitwiseOr => BinaryOperatorSyntax.BitwiseOr,
            AugmentedAssignmentOperatorSyntax.BitwiseXor => BinaryOperatorSyntax.BitwiseXor,
            AugmentedAssignmentOperatorSyntax.BitwiseAnd => BinaryOperatorSyntax.BitwiseAnd,
            AugmentedAssignmentOperatorSyntax.LeftShift => BinaryOperatorSyntax.LeftShift,
            AugmentedAssignmentOperatorSyntax.RightShift => BinaryOperatorSyntax.RightShift,
            _ => throw new InvalidOperationException($"Unsupported augmented assignment operator: {op}")
        };

    private static object EvaluateAugmentedBuiltin(object currentValue, object right,
        AugmentedAssignmentOperatorSyntax op, ExecutionContext context, LythonSourceSpan span)
        => op switch
        {
            AugmentedAssignmentOperatorSyntax.Add => EvaluateAdd(currentValue, right, context, span, "+="),
            AugmentedAssignmentOperatorSyntax.Subtract => EvaluateSubtract(currentValue, right, context, span, "-="),
            AugmentedAssignmentOperatorSyntax.Multiply => EvaluateMultiply(currentValue, right, context, span, "*="),
            AugmentedAssignmentOperatorSyntax.Divide => EvaluateDivide(currentValue, right, context, span, "/="),
            AugmentedAssignmentOperatorSyntax.FloorDivide => EvaluateFloorDivide(currentValue, right, context, span, "//="),
            AugmentedAssignmentOperatorSyntax.Modulo => EvaluateModulo(currentValue, right, context, span, "%="),
            AugmentedAssignmentOperatorSyntax.Power => EvaluatePower(currentValue, right, context, span, "**="),
            AugmentedAssignmentOperatorSyntax.BitwiseOr => EvaluateBitwiseOr(currentValue, right, context, span, "|="),
            AugmentedAssignmentOperatorSyntax.BitwiseXor => EvaluateBitwiseXor(currentValue, right, context, span, "^="),
            AugmentedAssignmentOperatorSyntax.BitwiseAnd => EvaluateBitwiseAnd(currentValue, right, context, span, "&="),
            AugmentedAssignmentOperatorSyntax.LeftShift => EvaluateLeftShift(currentValue, right, context, span, "<<="),
            AugmentedAssignmentOperatorSyntax.RightShift => EvaluateRightShift(currentValue, right, context, span, ">>="),
            _ => throw new InvalidOperationException($"Unsupported augmented assignment operator: {op}")
        };

    private static async ValueTask<object> EvaluateAugmentedAssignmentAsync(
        object currentValue,
        object right,
        AugmentedAssignmentOperatorSyntax op,
        ExecutionContext context,
        LythonSourceSpan span)
    {
        if (op == AugmentedAssignmentOperatorSyntax.MatrixMultiply) return await EvaluateMatrixInPlaceAsync(currentValue, right, context, span, true).ConfigureAwait(false);
        if (currentValue is PyInstance)
        {
            var inPlace = await InvokeBinarySpecialMethodAsync(currentValue, AugmentedInPlaceMethod(op)!, right, context, span).ConfigureAwait(false);
            if (inPlace.Kind == SpecialMethodInvocationKind.Invoked && inPlace.Value is not PyNotImplemented)
                return inPlace.Value;
            return await EvaluateAugmentedProtocolFallbackAsync(currentValue, right, op, context, span).ConfigureAwait(false);
        }
        if (op == AugmentedAssignmentOperatorSyntax.Multiply && IsSequenceOperand(currentValue) && right is PyInstance)
        {
            var repeated = await EvaluateNumericProtocolAsync(BinaryOperatorSyntax.Multiply, currentValue, right, context, span).ConfigureAwait(false);
            if (repeated.Kind == SpecialMethodInvocationKind.Invoked) return repeated.Value;
            var count = (await CoerceTypeIndexAsync(right, context, span, true).ConfigureAwait(false))!;
            if (!PyNumberOps.IsInteger(count)) throw RuntimeErrors.MultiplySequenceError(right, span);
            right = count;
        }
        // Async twin covering the in-place drains whose sources can suspend
        // (list/deque extension, dict-family staged merges). User instance slots
        // use the async protocol path; builtin mutation branches retain their order.
        if (op == AugmentedAssignmentOperatorSyntax.Add &&
            currentValue is PyList currentList)
        {
            await currentList.AddRangeAsync(right, context, span).ConfigureAwait(false);
            return currentList;
        }

        if (op == AugmentedAssignmentOperatorSyntax.Add &&
            currentValue is PyDeque currentDeque)
        {
            await ExtendDequeAsync(currentDeque, right, span, context, true).ConfigureAwait(false);
            return currentDeque;
        }

        if (op == AugmentedAssignmentOperatorSyntax.BitwiseOr &&
            currentValue is PyDict currentDict)
        {
            // Stage through a temporary like dict.update so pair
            // iterables merge exactly like mappings.
            var stagedDict = new PyDict(context.MemoryGovernor, span);
            await UpdateDictionaryFromSourceAsync(stagedDict, right, context, span).ConfigureAwait(false);
            using var ambient = PyStructuralGuard.PushAmbient(context, span);
            foreach (var pair in stagedDict)
            {
                currentDict.SetItem(pair.Key, pair.Value);
            }

            return currentDict;
        }

        if (op == AugmentedAssignmentOperatorSyntax.BitwiseOr &&
            currentValue is PyDefaultDict currentDefault)
        {
            var stagedDefault = new PyDict(context.MemoryGovernor, span);
            await UpdateDictionaryFromSourceAsync(stagedDefault, right, context, span).ConfigureAwait(false);
            using var ambient = PyStructuralGuard.PushAmbient(context, span);
            foreach (var pair in stagedDefault)
            {
                currentDefault.SetItem(pair.Key, pair.Value);
            }

            return currentDefault;
        }

        if (op == AugmentedAssignmentOperatorSyntax.BitwiseOr &&
            currentValue is PyChainMap currentChain)
        {
            var staged = new PyDict(context.MemoryGovernor, span);
            await UpdateDictionaryFromSourceAsync(staged, right, context, span).ConfigureAwait(false);
            using var ambient = PyStructuralGuard.PushAmbient(context, span);
            foreach (var pair in staged)
            {
                currentChain.SetSubscript(pair.Key, pair.Value, span);
            }

            return currentChain;
        }

        // Builtin numeric values have no native in-place container behavior.
        // Their reflected user slot can suspend just like a user left slot.
        if (right is PyInstance && (op == AugmentedAssignmentOperatorSyntax.Add ||
            currentValue is PyComplex or PyDecimal || PyNumberOps.TryAsNumber(currentValue, out _)))
            return await EvaluateAugmentedProtocolFallbackAsync(currentValue, right, op, context, span).ConfigureAwait(false);
        return EvaluateAugmentedAssignment(currentValue, right, op, context, span);
    }

    private static async ValueTask<object> EvaluateAugmentedProtocolFallbackAsync(
        object left, object right, AugmentedAssignmentOperatorSyntax op, ExecutionContext context, LythonSourceSpan span)
    {
        var fallback = await EvaluateNumericProtocolAsync(AugmentedBinaryOperator(op), left, right, context, span).ConfigureAwait(false);
        if (fallback.Kind == SpecialMethodInvocationKind.Invoked) return fallback.Value;
        return op == AugmentedAssignmentOperatorSyntax.Multiply
            ? await EvaluateMultiplyAsync(left, right, context, span, "*=").ConfigureAwait(false)
            : EvaluateAugmentedBuiltin(left, right, op, context, span);
    }
}
