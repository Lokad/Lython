using Lokad.Lython.Runtime.Numbers;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Calls;
using System.Collections.Frozen;
using System.Text;
using System.Text.RegularExpressions;
using System.Numerics;
using System.Runtime.CompilerServices;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal interface INamedRuntimeCallable
{
    string Name { get; }
}

internal sealed partial class LythonRuntime
{
    private static readonly PyString DefaultPrintSeparator = PyString.FromOwnedUtf8([(byte)' ']);
    private static readonly PyString DefaultPrintEnding = PyString.FromOwnedUtf8([(byte)'\n']);

    private static object InvokeCall(CallExpressionSyntax call, ExecutionContext context)
    {
        var target = EvaluateExpression(call.Target, context);
        if (call.PreloadImplicitSuperArguments)
        {
            context.CheckExecution(call.Span);
            PreloadImplicitSuperArguments(context, call.Span);
        }
        return InvokeCallableTarget(
            target,
            call.Target.Span,
            call.Span,
            context,
            () => CallExpansion.ExpandRawArguments(call.Arguments, context, EvaluateExpression, target));
    }

    internal static object InvokeCallableTarget(
        object target,
        LythonSourceSpan targetSpan,
        LythonSourceSpan callSpan,
        ExecutionContext context,
        Func<CallArgumentValue[]> expandArguments)
    {
        if (target is not ICallable callable)
        {
            // Python evaluates arguments (and their failures) before rejecting
            // the target. Keep callable frame admission on its existing path.
            _ = expandArguments();
            throw RuntimeErrors.NotCallable(targetSpan);
        }

        return InvokeCallable(
            callable,
            callSpan,
            context,
            new DeferredCallArguments(expandArguments));
    }

    private static object InvokeCallable<TArguments>(
        ICallable callable,
        LythonSourceSpan callSpan,
        ExecutionContext context,
        TArguments arguments)
        where TArguments : struct, ICallArguments
    {
        context.EnterInterpreterFrame(callSpan);
        try
        {
            return RuntimeValue(callable.Invoke(arguments.Expand(), callSpan, context));
        }
        catch (Exception ex) when (TryTranslateCallableException(ex, callSpan, out var translated))
        {
            throw translated;
        }
        finally
        {
            context.LeaveInterpreterFrame();
        }
    }

    // Prepared arrays use the same awaited frame policy as deferred arguments,
    // without a capturing factory. The caller owns them until the call completes.
    internal static ValueTask<object> InvokeCallableTargetAsync(
        object target,
        LythonSourceSpan targetSpan,
        LythonSourceSpan callSpan,
        ExecutionContext context,
        Func<ValueTask<CallArgumentValue[]>> expandArguments)
        => InvokeCallableTargetAsync(target, targetSpan, callSpan, context, new DeferredAsyncCallArguments(expandArguments));

    internal static ValueTask<object> InvokeCallableTargetAsync(
        object target,
        LythonSourceSpan targetSpan,
        LythonSourceSpan callSpan,
        ExecutionContext context,
        CallArgumentValue[] arguments)
        => InvokeCallableTargetAsync(target, targetSpan, callSpan, context, new PreparedCallArguments(arguments));

    private static async ValueTask<object> InvokeCallableTargetAsync<TArguments>(
        object target,
        LythonSourceSpan targetSpan,
        LythonSourceSpan callSpan,
        ExecutionContext context,
        TArguments arguments)
        where TArguments : struct, IAsyncCallArguments
    {
        if (target is not ICallable callable)
        {
            _ = await arguments.ExpandAsync().ConfigureAwait(false);
            throw RuntimeErrors.NotCallable(targetSpan);
        }

        context.EnterInterpreterFrame(callSpan);
        try
        {
            var expanded = await arguments.ExpandAsync().ConfigureAwait(false);
            return RuntimeValue(await callable.InvokeAsync(expanded, callSpan, context).ConfigureAwait(false));
        }
        catch (Exception ex) when (TryTranslateCallableException(ex, callSpan, out var translated))
        {
            throw translated;
        }
        finally
        {
            context.LeaveInterpreterFrame();
        }
    }

    private static object InvokeCallableFromOperands(
        PyFunctionBase function, ReadOnlyMemory<object?> arguments, LythonSourceSpan span, ExecutionContext context,
        object? receiver = null, ExecutableCallSite? callSite = null)
    {
        context.EnterInterpreterFrame(span);
        try
        {
            return RuntimeValue(function.InvokeFromOperands(arguments.Span, span, context, receiver, callSite));
        }
        catch (Exception ex) when (TryTranslateCallableException(ex, span, out var translated)) { throw translated; }
        finally { context.LeaveInterpreterFrame(); }
    }

    private static async ValueTask<object> InvokeCallableFromOperandsAsync(
        PyFunctionBase function, ReadOnlyMemory<object?> arguments, LythonSourceSpan span, ExecutionContext context,
        object? receiver = null, ExecutableCallSite? callSite = null)
    {
        context.EnterInterpreterFrame(span);
        try
        {
            // Remaining lowered/mirrored calls bind owned values.
            // The caller keeps its operand array alive until this call finishes.
            var pending = function.InvokeFromOperandsAsync(arguments.Span, span, context, receiver, callSite);
            return RuntimeValue(await pending.ConfigureAwait(false));
        }
        catch (Exception ex) when (TryTranslateCallableException(ex, span, out var translated)) { throw translated; }
        finally { context.LeaveInterpreterFrame(); }
    }

    private static async ValueTask<object> InitializePreparedConstructorAsync(PyInstance instance,
        CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context, bool asynchronous)
    {
        context.EnterInterpreterFrame(span);
        try
        {
            return await instance.Type.InitializeInstanceAsync(instance, arguments, span, context, asynchronous).ConfigureAwait(false);
        }
        catch (Exception ex) when (TryTranslateCallableException(ex, span, out var translated)) { throw translated; }
        finally { context.LeaveInterpreterFrame(); }
    }

    // Exact native file writes stage governed output synchronously. Publication
    // remains on the existing flush/close and execution cleanup paths.
    internal static object InvokeFileWrite(object receiver, object value, LythonSourceSpan span, ExecutionContext context)
    {
        context.EnterInterpreterFrame(span);
        try
        {
            if (receiver is ExecutionContext.TextFileHandle text)
                return TextFileHandleMembers.Write(text, value, span);
            return ((ExecutionContext.BinaryFileHandle)receiver).Write(value, span);
        }
        catch (Exception ex) when (TryTranslateCallableException(ex, span, out var translated)) { throw translated; }
        finally { context.LeaveInterpreterFrame(); }
    }

    // A private producer range is copied into the file's admitted staging before
    // this guard returns. It never escapes to a guest or asynchronous borrower.
    internal static object InvokeFileWrite(ExecutionContext.TextFileHandle receiver, ReadOnlyMemory<byte> utf8,
        LythonSourceSpan span, ExecutionContext context)
    {
        context.EnterInterpreterFrame(span);
        try
        {
            return receiver.WriteUtf8(utf8);
        }
        catch (Exception ex) when (TryTranslateCallableException(ex, span, out var translated)) { throw translated; }
        finally { context.LeaveInterpreterFrame(); }
    }

    private static object InvokeSingleInput<T>(T value,
        Func<T, LythonSourceSpan, ExecutionContext, object> operation, LythonSourceSpan span, ExecutionContext context) where T : class
    {
        context.EnterInterpreterFrame(span);
        try
        {
            return operation(value, span, context);
        }
        catch (Exception ex) when (TryTranslateCallableException(ex, span, out var translated)) { throw translated; }
        finally { context.LeaveInterpreterFrame(); }
    }

    private static object InvokeStringAffix(PyString receiver, object prefix, LythonSourceSpan span, ExecutionContext context, bool isStart)
    {
        context.EnterInterpreterFrame(span);
        try
        {
            return RuntimeValue(StringMembers.StartsOrEndsWith(receiver, prefix, 0, receiver.ByteLength, true, isStart, span));
        }
        catch (Exception ex) when (TryTranslateCallableException(ex, span, out var translated)) { throw translated; }
        finally { context.LeaveInterpreterFrame(); }
    }

    private static object InvokeStringSplit(PyString receiver, object? separator, object? count, LythonSourceSpan span, ExecutionContext context)
    {
        context.EnterInterpreterFrame(span);
        try
        {
            return StringMembers.Split(receiver, separator, count, span, context);
        }
        catch (Exception ex) when (TryTranslateCallableException(ex, span, out var translated)) { throw translated; }
        finally { context.LeaveInterpreterFrame(); }
    }

    private static object InvokeStringReplace(PyString receiver, object oldValue, object newValue, object? countValue, LythonSourceSpan span, ExecutionContext context)
    {
        context.EnterInterpreterFrame(span);
        try
        {
            return StringMembers.Replace(receiver, oldValue, newValue, countValue, span, context);
        }
        catch (Exception ex) when (TryTranslateCallableException(ex, span, out var translated)) { throw translated; }
        finally { context.LeaveInterpreterFrame(); }
    }

    private static object InvokeDictionaryGet(PyDict receiver, object key, object fallback, LythonSourceSpan span, ExecutionContext context)
    {
        context.EnterInterpreterFrame(span);
        try
        {
            return DictMembers.Get(receiver, key, fallback, span, context);
        }
        catch (Exception ex) when (TryTranslateCallableException(ex, span, out var translated)) { throw translated; }
        finally { context.LeaveInterpreterFrame(); }
    }

    private static bool TryTranslateCallableException(
        Exception exception,
        LythonSourceSpan callSpan,
        [MaybeNullWhen(false)] out LythonRuntimeException translated)
    {
        translated = exception switch
        {
            RegexParseException regex => new LythonRuntimeException("ValueError", regex.Message, callSpan),
            InvalidOperationException invalidOperation => RuntimeErrors.Runtime(invalidOperation.Message, callSpan),
            _ => null
        };
        return translated is not null;
    }

    internal static readonly IReadOnlyDictionary<PythonExceptionIdentity, PythonExceptionIdentity[]> ExceptionBaseIdentities =
        new Dictionary<PythonExceptionIdentity, PythonExceptionIdentity[]>
        {
            [BuiltinException("Exception")] = [BuiltinException("BaseException")],
            [BuiltinException("SystemExit")] = [BuiltinException("BaseException")],
            [BuiltinException("GeneratorExit")] = [BuiltinException("BaseException")],
            [BuiltinException("KeyboardInterrupt")] = [BuiltinException("BaseException")],
            [BuiltinException("ArithmeticError")] = [BuiltinException("Exception")],
            [BuiltinException("AssertionError")] = [BuiltinException("Exception")],
            [BuiltinException("AttributeError")] = [BuiltinException("Exception")],
            [BuiltinException("EOFError")] = [BuiltinException("Exception")],
            [BuiltinException("ImportError")] = [BuiltinException("Exception")],
            [BuiltinException("LookupError")] = [BuiltinException("Exception")],
            [BuiltinException("MemoryError")] = [BuiltinException("Exception")],
            [BuiltinException("NameError")] = [BuiltinException("Exception")],
            [BuiltinException("UnboundLocalError")] = [BuiltinException("NameError")],
            [BuiltinException("OSError")] = [BuiltinException("Exception")],
            [BuiltinException("RuntimeError")] = [BuiltinException("Exception")],
            [BuiltinException("StopIteration")] = [BuiltinException("Exception")],
            [BuiltinException("SyntaxError")] = [BuiltinException("Exception")],
            [BuiltinException("TypeError")] = [BuiltinException("Exception")],
            [BuiltinException("ValueError")] = [BuiltinException("Exception")],
            [BuiltinException("Warning")] = [BuiltinException("Exception")],
            [BuiltinException("FutureWarning")] = [BuiltinException("Warning")],
            [BuiltinException("ZeroDivisionError")] = [BuiltinException("ArithmeticError")],
            [BuiltinException("OverflowError")] = [BuiltinException("ArithmeticError")],
            [BuiltinException("KeyError")] = [BuiltinException("LookupError")],
            [BuiltinException("IndexError")] = [BuiltinException("LookupError")],
            [BuiltinException("ModuleNotFoundError")] = [BuiltinException("ImportError")],
            [BuiltinException("FileNotFoundError")] = [BuiltinException("OSError")],
            [BuiltinException("FileExistsError")] = [BuiltinException("OSError")],
            [BuiltinException("IsADirectoryError")] = [BuiltinException("OSError")],
            [BuiltinException("NotADirectoryError")] = [BuiltinException("OSError")],
            [BuiltinException("PermissionError")] = [BuiltinException("OSError")],
            [BuiltinException("BrokenPipeError")] = [BuiltinException("OSError")],
            [BuiltinException("TimeoutError")] = [BuiltinException("OSError")],
            [BuiltinException("IOError")] = [BuiltinException("OSError")],
            [BuiltinException("EnvironmentError")] = [BuiltinException("OSError")],
            [BuiltinException("NotImplementedError")] = [BuiltinException("RuntimeError")],
            [BuiltinException("RecursionError")] = [BuiltinException("RuntimeError")],
            [BuiltinException("UnicodeError")] = [BuiltinException("ValueError")],
            [BuiltinException("UnicodeEncodeError")] = [BuiltinException("UnicodeError")],
            [BuiltinException("UnicodeDecodeError")] = [BuiltinException("UnicodeError")],
            [BuiltinException("UnicodeTranslateError")] = [BuiltinException("UnicodeError")],
            [ModuleException("argparse", "ArgumentError")] = [BuiltinException("Exception")],
            [ModuleException("argparse", "ArgumentTypeError")] = [BuiltinException("Exception")],
            [ModuleException("copy", "Error")] = [BuiltinException("Exception")],
            [ModuleException("csv", "Error")] = [BuiltinException("Exception")],
            [ModuleException("dataclasses", "FrozenInstanceError")] = [BuiltinException("AttributeError")],
            [ModuleException("decimal", "DecimalException")] = [BuiltinException("ArithmeticError")],
            [ModuleException("decimal", "InvalidOperation")] = [ModuleException("decimal", "DecimalException")],
            [ModuleException("decimal", "DivisionByZero")] = [ModuleException("decimal", "DecimalException"), BuiltinException("ZeroDivisionError")],
            [ModuleException("decimal", "Inexact")] = [ModuleException("decimal", "DecimalException")],
            [ModuleException("decimal", "Rounded")] = [ModuleException("decimal", "DecimalException")],
            [ModuleException("decimal", "Overflow")] = [ModuleException("decimal", "Inexact"), ModuleException("decimal", "Rounded")],
            [ModuleException("decimal", "Underflow")] = [ModuleException("decimal", "Inexact"), ModuleException("decimal", "Rounded"), ModuleException("decimal", "Subnormal")],
            [ModuleException("decimal", "Subnormal")] = [ModuleException("decimal", "DecimalException")],
            [ModuleException("decimal", "Clamped")] = [ModuleException("decimal", "DecimalException")],
            [ModuleException("decimal", "FloatOperation")] = [ModuleException("decimal", "DecimalException"), BuiltinException("TypeError")],
            [ModuleException("decimal", "DivisionUndefined")] = [ModuleException("decimal", "InvalidOperation")],
            [ModuleException("decimal", "ConversionSyntax")] = [ModuleException("decimal", "InvalidOperation")],
            [ModuleException("decimal", "DivisionImpossible")] = [ModuleException("decimal", "InvalidOperation")],
            [ModuleException("gzip", "BadGzipFile")] = [BuiltinException("OSError")],
            [ModuleException("struct", "error")] = [BuiltinException("Exception")],
            [ModuleException("zlib", "error")] = [BuiltinException("Exception")],
            [ModuleException("xml.etree.ElementTree", "ParseError")] = [BuiltinException("SyntaxError")],
            [ModuleException("json", "JSONDecodeError")] = [BuiltinException("ValueError")],
            [ModuleException("io", "UnsupportedOperation")] = [BuiltinException("OSError"), BuiltinException("ValueError")],
            [ModuleException("openpyxl.utils.exceptions", "CellCoordinatesException")] = [BuiltinException("ValueError")],
            [ModuleException("openpyxl.utils.exceptions", "IllegalCharacterError")] = [BuiltinException("ValueError")],
            [ModuleException("openpyxl.utils.exceptions", "InvalidFileException")] = [BuiltinException("Exception")],
            [ModuleException("openpyxl.utils.exceptions", "NamedRangeException")] = [BuiltinException("Exception")],
            [ModuleException("openpyxl.utils.exceptions", "ReadOnlyWorkbookException")] = [BuiltinException("Exception")],
            [ModuleException("openpyxl.utils.exceptions", "SheetTitleException")] = [BuiltinException("Exception")],
            [ModuleException("openpyxl.utils.exceptions", "WorkbookAlreadySaved")] = [BuiltinException("Exception")],
            [ModuleException("re", "PatternError")] = [BuiltinException("Exception")],
            [ModuleException("shutil", "Error")] = [BuiltinException("OSError")],
            [ModuleException("shutil", "SameFileError")] = [ModuleException("shutil", "Error")],
            [ModuleException("statistics", "StatisticsError")] = [BuiltinException("ValueError")],
            [ModuleException("subprocess", "SubprocessError")] = [BuiltinException("Exception")],
            [ModuleException("subprocess", "CalledProcessError")] = [ModuleException("subprocess", "SubprocessError")],
            [ModuleException("subprocess", "TimeoutExpired")] = [ModuleException("subprocess", "SubprocessError")],
            [ModuleException("zipfile", "BadZipFile")] = [BuiltinException("Exception")],
            [ModuleException("zipfile", "LargeZipFile")] = [BuiltinException("Exception")],
        };

    private static PythonExceptionIdentity BuiltinException(string typeName)
        => PythonExceptionIdentity.Builtin(typeName);

    internal static PythonExceptionIdentity ModuleException(string moduleName, string typeName)
        => PythonExceptionIdentity.Module(moduleName, typeName);

    private static bool MatchesExceptionType(
        PythonExceptionIdentity caughtIdentity,
        PythonExceptionIdentity thrownIdentity)
        => caughtIdentity == thrownIdentity || IsExceptionSubtype(thrownIdentity, caughtIdentity);

    private static bool IsExceptionSubtype(
        PythonExceptionIdentity thrownIdentity,
        PythonExceptionIdentity caughtIdentity)
    {
        var pending = new Stack<PythonExceptionIdentity>();
        pending.Push(thrownIdentity);
        var seen = new HashSet<PythonExceptionIdentity>();
        while (pending.Count > 0)
        {
            var current = pending.Pop();
            if (!seen.Add(current))
            {
                continue;
            }

            if (!ExceptionBaseIdentities.TryGetValue(current, out var bases))
            {
                continue;
            }

            foreach (var baseName in bases)
            {
                if (baseName == caughtIdentity)
                {
                    return true;
                }

                pending.Push(baseName);
            }
        }

        return false;
    }

    private static object InvokeCallableTarget(
        object target,
        LythonSourceSpan targetSpan,
        LythonSourceSpan callSpan,
        ExecutionContext context,
        CallArgumentValue[] arguments)
    {
        if (target is not ICallable callable)
        {
            throw RuntimeErrors.NotCallable(targetSpan);
        }

        return InvokeCallable(
            callable,
            callSpan,
            context,
            new PreparedCallArguments(arguments));
    }

    private static object InvokeBorrowedCallableTarget(object target, ExecutableCallSite call,
        ReadOnlySpan<CallArgumentValue> arguments, ExecutionContext context)
    {
        if (target is not ICallable callable) throw RuntimeErrors.NotCallable(call.TargetSpan);
        context.EnterInterpreterFrame(call.CallSpan);
        try { return RuntimeValue(callable.InvokeBorrowed(arguments, call.CallSpan, context)); }
        catch (Exception error) when (TryTranslateCallableException(error, call.CallSpan, out var translated)) { throw translated; }
        finally { context.LeaveInterpreterFrame(); }
    }

    private static ValueTask<object> InvokeBorrowedCallableTargetAsync(object target, ExecutableCallSite call,
        ReadOnlySpan<CallArgumentValue> arguments, ExecutionContext context)
    {
        try
        {
            if (target is not ICallable callable) throw RuntimeErrors.NotCallable(call.TargetSpan);
            context.EnterInterpreterFrame(call.CallSpan);
            var pendingFrame = false;
            try
            {
                var pending = callable.InvokeBorrowedAsync(arguments, call.CallSpan, context);
                if (pending.IsCompletedSuccessfully) return new(RuntimeValue(pending.Result));
                pendingFrame = true;
                return AwaitBorrowedCall(pending, call.CallSpan, context);
            }
            catch (Exception error) when (TryTranslateCallableException(error, call.CallSpan, out var translated)) { throw translated; }
            finally { if (!pendingFrame) context.LeaveInterpreterFrame(); }
        }
        catch (Exception error) { return ValueTask.FromException<object>(error); }
    }

    private static async ValueTask<object> AwaitBorrowedCall(ValueTask<object> pending, LythonSourceSpan span, ExecutionContext context)
    {
        try { return RuntimeValue(await pending.ConfigureAwait(false)); }
        catch (Exception error) when (TryTranslateCallableException(error, span, out var translated)) { throw translated; }
        finally { context.LeaveInterpreterFrame(); }
    }

    private interface ICallArguments
    {
        /// <summary>Supplies arguments after the target has been confirmed callable and its interpreter frame entered.</summary>
        CallArgumentValue[] Expand();
    }

    private readonly record struct DeferredCallArguments(Func<CallArgumentValue[]> ExpandArguments) : ICallArguments
    {
        public CallArgumentValue[] Expand() => ExpandArguments();
    }

    private interface IAsyncCallArguments
    {
        ValueTask<CallArgumentValue[]> ExpandAsync();
    }

    private readonly record struct DeferredAsyncCallArguments(Func<ValueTask<CallArgumentValue[]>> ExpandArguments) : IAsyncCallArguments
    {
        public ValueTask<CallArgumentValue[]> ExpandAsync() => ExpandArguments();
    }

    private readonly record struct PreparedCallArguments(CallArgumentValue[] Arguments) : ICallArguments, IAsyncCallArguments
    {
        public CallArgumentValue[] Expand() => Arguments;
        public ValueTask<CallArgumentValue[]> ExpandAsync() => ValueTask.FromResult(Arguments);
    }

    internal interface ICallable
    {
        object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context);

        ValueTask<object> InvokeAsync(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
            => ValueTask.FromResult(Invoke(arguments, span, context));

        // Consume borrowed inputs before returning pending work. A callable may
        // borrow its invocation-private packet through completion, never after it.
        // Escaping guest values need their ordinary retained storage, not this packet.
        object InvokeBorrowed(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        {
            var owned = arguments.ToArray();
            try { return Invoke(owned, span, context); }
            finally { Array.Clear(owned); }
        }

        ValueTask<object> InvokeBorrowedAsync(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        {
            var owned = arguments.ToArray();
            var pendingOwner = false;
            try
            {
                var pending = InvokeAsync(owned, span, context);
                if (pending.IsCompletedSuccessfully) return new(pending.Result);
                pendingOwner = true;
                return CompleteOwnedArguments(pending, owned);
            }
            finally { if (!pendingOwner) Array.Clear(owned); }
        }

        private static async ValueTask<object> CompleteOwnedArguments(ValueTask<object> pending, CallArgumentValue[] owned)
        {
            try { return await pending.ConfigureAwait(false); }
            finally { Array.Clear(owned); }
        }
    }

    private abstract class BoundArgumentsCallable : ICallable
    {
        private readonly PythonCallableKind _callableKind;

        protected BoundArgumentsCallable(
            LythonCallableSignature signature,
            PythonCallableKind callableKind)
        {
            Signature = signature;
            _callableKind = callableKind;
        }

        protected LythonCallableSignature Signature { get; }

        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
            => InvokeBorrowed(arguments, span, context);

        public object InvokeBorrowed(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        {
            context.CheckExecution(span);
            return PreservePresence
                ? InvokeBoundWithPresence(CallBinder.BindNamedArgumentsWithPresence(arguments, span, Signature, _callableKind), span, context)
                : InvokeBound(CallBinder.BindNamedArguments(arguments, span, Signature, _callableKind), span, context);
        }

        public ValueTask<object> InvokeAsync(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
            => InvokeBorrowedAsync(arguments, span, context);

        public ValueTask<object> InvokeBorrowedAsync(ReadOnlySpan<CallArgumentValue> arguments, LythonSourceSpan span, ExecutionContext context)
        {
            context.CheckExecution(span);
            return PreservePresence
                ? InvokeBoundWithPresenceAsync(CallBinder.BindNamedArgumentsWithPresence(arguments, span, Signature, _callableKind), span, context)
                : InvokeBoundAsync(CallBinder.BindNamedArguments(arguments, span, Signature, _callableKind), span, context);
        }

        /// <summary>Whether calls bind with assignment tracking so omitted arguments stay distinguishable from explicit values.</summary>
        protected virtual bool PreservePresence => false;

        /// <summary>Invokes the callable after named arguments have been bound into positional slots.</summary>
        protected abstract object InvokeBound(object[] arguments, LythonSourceSpan span, ExecutionContext context);

        /// <summary>Invokes the callable with assignment tracking; by default degrades to the positional body.</summary>
        protected virtual object InvokeBoundWithPresence(BoundCallArguments bound, LythonSourceSpan span, ExecutionContext context)
            => InvokeBound(bound.Values, span, context);

        /// <summary>Asynchronous <see cref="InvokeBoundWithPresence"/>; by default runs the synchronous body inline.</summary>
        protected virtual ValueTask<object> InvokeBoundWithPresenceAsync(BoundCallArguments bound, LythonSourceSpan span, ExecutionContext context)
            => ValueTask.FromResult(InvokeBoundWithPresence(bound, span, context));

        /// <summary>
        /// Invokes the callable asynchronously after named arguments have been bound into positional slots.
        /// The default implementation runs the synchronous body inline and returns an already-completed task;
        /// overrides that await host operations must honor the execution cancellation token. Callers own the
        /// returned task and await it exactly once.
        /// </summary>
        protected virtual ValueTask<object> InvokeBoundAsync(object[] arguments, LythonSourceSpan span, ExecutionContext context)
            => ValueTask.FromResult(InvokeBound(arguments, span, context));
    }

    private abstract class DelegateBoundArgumentsCallable : BoundArgumentsCallable
    {
        private readonly Func<object[], LythonSourceSpan, ExecutionContext, object> _implementation;
        private readonly Func<object[], LythonSourceSpan, ExecutionContext, ValueTask<object>>? _asyncImplementation;

        protected DelegateBoundArgumentsCallable(
            LythonCallableSignature signature,
            PythonCallableKind callableKind,
            Func<object[], LythonSourceSpan, ExecutionContext, object> implementation,
            Func<object[], LythonSourceSpan, ExecutionContext, ValueTask<object>>? asyncImplementation)
            : base(signature, callableKind)
        {
            _implementation = implementation;
            _asyncImplementation = asyncImplementation;
        }

        /// <inheritdoc />
        protected sealed override object InvokeBound(object[] arguments, LythonSourceSpan span, ExecutionContext context)
            => _implementation(arguments, span, context);

        /// <inheritdoc />
        protected sealed override ValueTask<object> InvokeBoundAsync(object[] arguments, LythonSourceSpan span, ExecutionContext context)
            => _asyncImplementation is null
                ? ValueTask.FromResult(_implementation(arguments, span, context))
                : _asyncImplementation(arguments, span, context);
    }

    // Builtin type constructors expose CPython-style __bases__/__mro__ resolved
    // through the run builtins table (bool derives int, the rest derive object).
    // Hierarchy tuples build once per callable and alias stably like CPython.
    private static readonly IReadOnlyDictionary<string, string[]> BuiltinTypeBaseNames =
        new Dictionary<string, string[]>(StringComparer.Ordinal)
        {
            ["bool"] = ["int"],
            ["int"] = ["object"],
            ["float"] = ["object"],
            ["complex"] = ["object"],
            ["list"] = ["object"],
            ["tuple"] = ["object"],
            ["dict"] = ["object"],
            ["set"] = ["object"],
            ["str"] = ["object"],
            ["bytes"] = ["object"],
            ["decimal.Decimal"] = ["object"],
            ["decimal.DecimalTuple"] = ["tuple"],
            ["decimal.Context"] = ["object"],
            ["range"] = ["object"],
            ["slice"] = ["object"],
            ["zip"] = ["object"],
            ["staticmethod"] = ["object"],
            ["classmethod"] = ["object"],
            ["property"] = ["object"],
            ["super"] = ["object"],
        };

    internal sealed record BuiltinTypeHierarchy(PyTuple Bases, PyTuple Mro);

    // Module singletons (and their members) are shared across runs, so a cached
    // hierarchy must be keyed by its owning run: base objects come from the run
    // builtins table and go stale for any other run.
    internal sealed record OwnedTypeHierarchy(ExecutionState Owner, BuiltinTypeHierarchy Hierarchy);

    internal static bool TryGetOwnedHierarchy(
        string name,
        object self,
        ExecutionContext context,
        LythonSourceSpan span,
        ref OwnedTypeHierarchy? cache,
        out BuiltinTypeHierarchy hierarchy)
    {
        if (cache is not null && ReferenceEquals(cache.Owner, context.State))
        {
            hierarchy = cache.Hierarchy;
            return true;
        }

        var built = BuildBuiltinTypeHierarchy(name, self, context, span);
        if (built is null)
        {
            hierarchy = null!;
            return false;
        }

        cache = new OwnedTypeHierarchy(context.State, built);
        hierarchy = built;
        return true;
    }

    internal static BuiltinTypeHierarchy? BuildBuiltinTypeHierarchy(
        string name,
        object self,
        ExecutionContext context,
        LythonSourceSpan span)
    {
        if (!BuiltinTypeBaseNames.TryGetValue(name, out var baseNames))
        {
            return null;
        }

        var bases = new object[baseNames.Length];
        for (var i = 0; i < baseNames.Length; i++)
        {
            if (!context.TryGetBuiltin(baseNames[i], out var baseValue) || baseValue is null)
            {
                return null;
            }

            bases[i] = baseValue;
        }

        // __mro__ always terminates at object like CPython.
        if (!context.TryGetBuiltin("object", out var objectBase) || objectBase is null)
        {
            return null;
        }

        var mroLength = bases.Length + 1;
        if (bases.Length == 0 || !ReferenceEquals(bases[bases.Length - 1], objectBase))
        {
            mroLength++;
        }

        var mro = new object[mroLength];
        mro[0] = self;
        Array.Copy(bases, 0, mro, 1, bases.Length);
        if (mroLength > bases.Length + 1)
        {
            mro[mroLength - 1] = objectBase;
        }

        return new BuiltinTypeHierarchy(
            new PyTuple(bases, context.MemoryGovernor, span),
            new PyTuple(mro, context.MemoryGovernor, span));
    }

    // Singleton types deriving object resolve __bases__/__mro__ per read: the
    // object base comes from the run builtins table, so tuples cannot be shared
    // across runs.
    internal static bool TryGetObjectBases(
        object self,
        ExecutionContext context,
        LythonSourceSpan span,
        string member,
        [MaybeNullWhen(false)] out object value)
    {
        if (!context.TryGetBuiltin("object", out var obj) || obj is null)
        {
            value = PyNone.Instance;
            return false;
        }

        if (member == "__bases__")
        {
            value = new PyTuple([obj], context.MemoryGovernor, span);
            return true;
        }

        value = new PyTuple([self, obj], context.MemoryGovernor, span);
        return true;
    }

    // Builtin functions report their host module like CPython (len -> builtins,
    // math.sqrt -> math), resolving through the run import registry so identity
    // matches the imported module object (registering on first touch like import).
    internal static bool TryGetCallableModule(
        string callableName,
        ExecutionContext context,
        [MaybeNullWhen(false)] out PyModule module)
    {
        var dot = callableName.LastIndexOf((char)46);
        var moduleName = dot < 0 ? "builtins" : callableName.Substring(0, dot);
        var found = TryResolveKnownImportedModule(moduleName, context, out var cached);
        module = cached as PyModule;
        return found && module is not null;
    }

    // Core values report their run type object like CPython: plain names resolve
    // through builtins, dotted names through the defining module registry.
    // Core values report their run type object like CPython (plain names resolve
    // through builtins, dotted names through the defining module registry).
    internal static bool TryGetValueClass(
        object value,
        ExecutionContext context,
        [MaybeNullWhen(false)] out object classValue)
    {
        // Type-denoting objects report the type builtin itself.
        if (value is BuiltinCallable { Name: var ctorName } && BuiltinTypeBaseNames.ContainsKey(ctorName) ||
            value is DictCallable or ZipCallable ||
            value is ReModule.RegexFlagFactory or ZipInfoCallable or ZipFileCallable ||
            value is PathlibModule.PathlibPathType or PyBuiltinRuntimeType ||
            value is ExceptionTypeValue or UrllibParseModule.UrlResultType)
        {
            classValue = TryGetBuiltinOrNull(context, "type");
            return classValue is not null;
        }

        object? resolved = value switch
        {
            PyNamedTupleObject namedTuple => namedTuple.Type,
            PyNamedTupleType => TryGetBuiltinOrNull(context, "type"),
            PyList => TryGetBuiltinOrNull(context, "list"),
            PyMappingProxy => PyType.MappingProxyType,
            PyDict => TryGetBuiltinOrNull(context, "dict"),
            PyTuple => TryGetBuiltinOrNull(context, "tuple"),
            PySet => TryGetBuiltinOrNull(context, "set"),
            PyString => TryGetBuiltinOrNull(context, "str"),
            string => TryGetBuiltinOrNull(context, "str"),
            PyBytes => TryGetBuiltinOrNull(context, "bytes"),
            byte[] => TryGetBuiltinOrNull(context, "bytes"),
            bool => TryGetBuiltinOrNull(context, "bool"),
            _ when Numbers.PyNumberOps.IsInteger(value) => TryGetBuiltinOrNull(context, "int"),
            double => TryGetBuiltinOrNull(context, "float"),
            PyComplex => TryGetBuiltinOrNull(context, "complex"),
            PyDecimal => TryGetNativeModuleType(context, "decimal", "Decimal"),
            PyDate => TryGetNativeModuleType(context, "datetime", "date"),
            PyTime => TryGetNativeModuleType(context, "datetime", "time"),
            PyDateTime => TryGetNativeModuleType(context, "datetime", "datetime"),
            PyIsoCalendarDate => PyDateTimeOps.IsoCalendarDateType,
            PyTimedelta => TryGetNativeModuleType(context, "datetime", "timedelta"),
            PyTimezone => TryGetNativeModuleType(context, "datetime", "timezone"),
            PyPath path => PathClass(path),
            ElementTreeModule.Element => ElementTreeModule.ElementType,
            // Struct-time values resolve through the dedicated singleton rather
            // than the import registry, so they keep their class without an
            // import; the registry holds the same object, preserving identity.
            TimeStructTimeValue => TimeStructTimeType.Instance,
            UrllibParseModule.UrlResult result => result.Type,
            LythonRuntime.StatisticsModule.PyNormalDist => TryGetNativeModuleType(context, "statistics", "NormalDist"),
            LythonRuntime.RandomModule.PyRandom => TryGetNativeModuleType(context, "random", "Random"),
            PyZipInfo => TryGetNativeModuleType(context, "zipfile", "ZipInfo"),
            PyNone => PyType.NoneType,
            PyEllipsis => PyType.EllipsisType,
            PyNotImplemented => PyType.NotImplementedType,
            PyModule => PyType.ModuleType,
            PyPartial => TryGetNativeModuleType(context, "functools", "partial"),
            PyCounter => TryGetNativeModuleType(context, "collections", "Counter"),
            ArgparseNamespaceObject => ArgparseModule.NamespaceType,
            ArgumentParserObject => ArgparseModule.ParserType,
            BytesIOObject => BytesIOClass.Instance,
            StringIOObject => StringIOClass.Instance,
            GzipFileObject => GzipFileClass.Instance,
            JsonDecoderObject => TryGetNativeModuleType(context, "json", "JSONDecoder"),
            JsonEncoderObject => TryGetNativeModuleType(context, "json", "JSONEncoder"),
            PyException exception when exception.Identity.IsBuiltin => TryGetBuiltinOrNull(context, exception.Identity.TypeName),
            PyException exception when exception.Identity == ModuleException("re", "PatternError") => ReModule.PatternErrorType,
            PyException exception when exception.Identity == ModuleException("struct", "error") => StructModule.ErrorType,
            PyException exception when exception.Identity == ModuleException("zlib", "error") => ZlibModule.ErrorType,
            PyException exception when exception.Identity == ModuleException("io", "UnsupportedOperation") => IoModule.UnsupportedOperationType,
            PyException exception => TryGetNativeModuleType(context, exception.Identity.ModuleName, exception.Identity.TypeName),
            PyDefaultDict => TryGetNativeModuleType(context, "collections", "defaultdict"),
            PyDeque => TryGetNativeModuleType(context, "collections", "deque"),
            PyChainMap => TryGetNativeModuleType(context, "collections", "ChainMap"),
            CollectionsCallable member when member.Name is "collections.namedtuple" => PyType.FunctionType,
            JsonEncoderClass => TryGetBuiltinOrNull(context, "type"),
            BytesIOClass => TryGetBuiltinOrNull(context, "type"),
            StringIOClass => TryGetBuiltinOrNull(context, "type"),
            GzipFileClass => GzipFileMetaType.Instance,
            GzipFileMetaType => TryGetBuiltinOrNull(context, "type"),
            JsonDecoderClass => TryGetBuiltinOrNull(context, "type"),
            CollectionsCallable => TryGetBuiltinOrNull(context, "type"),
            PartialFactory => TryGetBuiltinOrNull(context, "type"),
            PartialMethodFactory => TryGetBuiltinOrNull(context, "type"),
            PyTypingAlias alias when alias.ShortName is "NamedTuple" or "TypedDict" => PyType.FunctionType,
            INamedRuntimeCallable callable when callable.Name is "typing.TypeVar" or "typing.NewType" => TryGetBuiltinOrNull(context, "type"),
            INamedRuntimeCallable callable when callable.Name is "typing.cast" or "typing.get_origin" or "typing.get_args" => PyType.FunctionType,
            PyTypeParameter parameter => parameter.Kind switch { TypeParameterKind.TypeVar => PyTypeParameter.TypeVarType, TypeParameterKind.TypeVarTuple => PyTypeParameter.TypeVarTupleType, _ => PyTypeParameter.ParamSpecType },
            PyTypeAlias => PyTypeAlias.RuntimeType,
            PyGenericAlias alias => alias.Definition is not null ? PyGenericAlias.TypingRuntimeType : alias.IsUnion ? PyGenericAlias.UnionType : alias.Origin is PyType ? PyGenericAlias.TypingRuntimeType : PyGenericAlias.RuntimeType,
            PyTyping.NewTypeIdentityCallable => PyTyping.NewTypeType,
            LythonRuntime.RePatternObject => PyType.RegexPatternType,
            LythonRuntime.ReMatchObject => PyType.RegexMatchType,
            PyStaticMethod => TryGetBuiltinOrNull(context, "staticmethod"),
            PyClassMethod => TryGetBuiltinOrNull(context, "classmethod"),
            PyProperty => TryGetBuiltinOrNull(context, "property"),
            PyType type => type.MetaType ?? TryGetBuiltinOrNull(context, "type"),
            PyFunctionBase => PyType.FunctionType,
            PyGenerator or PyGeneratorExpression => PyType.GeneratorType,
            FunctionNewMethod => PyType.FunctionType,
            IPySlotWrapper => PyType.WrapperDescriptorType,
            ObjectNewMethod => PyType.BuiltinFunctionType,
            PyBoundMethod method => method.Function switch
            {
                IPySlotWrapper => PyType.MethodWrapperType,
                IPyBoundEngineMethod => PyType.BuiltinFunctionType,
                _ => PyType.MethodType,
            },
            BuiltinCallable => PyType.BuiltinFunctionType,
            ICallable callable when ZlibModule.IsCallable(callable) => PyType.BuiltinFunctionType,
            IPyBoundEngineMethod => PyType.BuiltinFunctionType,
            MinMaxCallable => PyType.BuiltinFunctionType,
            OpenCallable => PyType.BuiltinFunctionType,
            PrintCallable => PyType.BuiltinFunctionType,
            PyDateTimeOps.TypeMemberCallable => PyType.BuiltinFunctionType,
            IPyRawBoundCallable => PyType.BuiltinFunctionType,
            BuiltinTypeMethod => PyType.BuiltinFunctionType,
            UnboundTypeMethod => PyType.MethodDescriptorType,
            ObjectFormatMethod => PyType.MethodDescriptorType,
            ObjectDirMethod => PyType.MethodDescriptorType,
            BuiltinDataDescriptor dataDescriptor => dataDescriptor.Kind == DataDescriptorKind.Member ? PyType.MemberDescriptorType : PyType.GetSetDescriptorType,
            PyRange => TryGetBuiltinOrNull(context, "range"),
            PySlice => TryGetBuiltinOrNull(context, "slice"),
            TupleGetter => PyType.TupleGetterType,
            PyDataclass.DataclassInitMethod => PyType.FunctionType,
            PyDataclass.DataclassReprMethod => PyType.FunctionType,
            PyDataclass.DataclassEqMethod => PyType.FunctionType,
            PyDataclass.DataclassOrderMethod => PyType.FunctionType,
            PyDataclass.DataclassHashMethod => PyType.FunctionType,
            PyDataclass.DataclassFrozenSetAttrMethod => PyType.FunctionType,
            PyDataclass.DataclassFrozenDelAttrMethod => PyType.FunctionType,
            TotalOrderingMethod => PyType.FunctionType,
            _ => null,
        };

        classValue = resolved;
        return resolved is not null;
    }

    private static object? TryGetBuiltinOrNull(ExecutionContext context, string name)
    {
        return context.TryGetBuiltin(name, out var value) ? value : null;
    }

    // __init_subclass__ binds the type itself like CPython: user and builtin
    // types, exception types and member factories that denote types bind their
    // own object, while the function-shaped namedtuple factory binds function
    // like its __new__ slot; every other value binds its value class.
    internal static bool TryGetBoundSubclassTarget(object target, ExecutionContext context, [MaybeNullWhen(false)] out object typeValue)
    {
        typeValue = target switch
        {
            PyType => target,
            BuiltinCallable ctor when BuiltinTypeBaseNames.ContainsKey(ctor.Name) => target,
            DictCallable => target,
            ZipCallable => target,
            ExceptionTypeValue => target,
            PathlibModule.PathlibPathType => target,
            PyBuiltinRuntimeType => target,
            TimeStructTimeType => target,
            CollectionsCallable member when member.Name is "collections.namedtuple" => PyType.FunctionType,
            CollectionsCallable => target,
            PartialFactory => target,
            PartialMethodFactory => target,
            PyNamedTupleType => target,
            PyNamedTupleObject namedTuple => namedTuple.Type,
            _ => null,
        };

        if (typeValue is not null)
        {
            return true;
        }

        return TryGetValueClass(target, context, out typeValue) && typeValue is not null;
    }

    // Names callable and type-denoting values for operator errors like CPython,
    // mirroring TryGetValueClass without needing its run context. Engine
    // one-off callables without class identity (itertools factories and kin)
    // keep the shared object fallback like the type builtin does.

    internal static string CallableOperandTypeName(object value)
    {
        return value switch
        {
            PyBoundMethod method => method.Function switch
            {
                IPySlotWrapper => "method-wrapper",
                IPyBoundEngineMethod => "builtin_function_or_method",
                _ => "method",
            },
            PyFunctionBase or FunctionNewMethod => "function",
            PyDataclass.DataclassInitMethod or PyDataclass.DataclassReprMethod or PyDataclass.DataclassEqMethod or PyDataclass.DataclassOrderMethod or PyDataclass.DataclassHashMethod or PyDataclass.DataclassFrozenSetAttrMethod or PyDataclass.DataclassFrozenDelAttrMethod => "function",
            BuiltinCallable ctor when BuiltinTypeBaseNames.ContainsKey(ctor.Name) => "type",
            DictCallable or ZipCallable or ReModule.RegexFlagFactory or ZipInfoCallable or ZipFileCallable or PathlibModule.PathlibPathType => "type",
            BuiltinCallable or IPyBoundEngineMethod or IPyRawBoundCallable or MinMaxCallable or OpenCallable or PrintCallable or PyDateTimeOps.TypeMemberCallable or BuiltinTypeMethod or ObjectNewMethod => "builtin_function_or_method",
            UnboundTypeMethod or ObjectFormatMethod or ObjectDirMethod => "method_descriptor",
            IPySlotWrapper => "wrapper_descriptor",
            BuiltinDataDescriptor dataDescriptor => dataDescriptor.Kind == DataDescriptorKind.Member ? "member_descriptor" : "getset_descriptor",
            TupleGetter => "collections._tuplegetter",
            PyStaticMethod => "staticmethod",
            PyClassMethod => "classmethod",
            PyPartial => "functools.partial",
            CollectionsCallable member when member.Name is "collections.namedtuple" => "function",
            CollectionsCallable => "type",
            PartialFactory or PartialMethodFactory => "type",
            PyZipInfo => "ZipInfo",
            PyType or PyBuiltinRuntimeType or ExceptionTypeValue => "type",
            PyModule => "module",
            _ => "object",
        };
    }

    private static object? TryGetNativeModuleType(ExecutionContext context, string moduleName, string memberName)
    {
        return BuiltinModuleCatalog.ResolveType(moduleName, memberName, context);
    }

    // Unbound builtin type methods behave like CPython method descriptors:
    // list.append takes its receiver as the first argument, validates it
    // against the owning type, then delegates to the bound member path so
    // call semantics stay identical. Wrappers cache per constructor beside
    // the __new__ slots and carry no run state beyond the owning callable.
    // There is deliberately no __self__ or __module__ (CPython raises
    // AttributeError for both) and no __doc__ (the engine keeps no doc
    // corpus); __get__ and __text_signature__ stay out for the same reason.
    internal sealed class UnboundTypeMethod : ICallable, IPyDynamicAttributes, IPyHashableValue, IPyRenderableValue
    {
        private readonly object _owner;
        private readonly string _ownerName;
        private readonly string _memberName;
        private readonly string _qualifiedName;

        internal UnboundTypeMethod(object owner, string ownerName, string memberName)
        {
            _owner = owner;
            _ownerName = ownerName;
            _memberName = memberName;
            _qualifiedName = ownerName + "." + memberName;
        }

        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            var bound = BindCall(arguments, span, context);
            return bound.Callable.Invoke(bound.Arguments, span, context);
        }

        public ValueTask<object> InvokeAsync(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            var bound = BindCall(arguments, span, context);
            return bound.Callable.InvokeAsync(bound.Arguments, span, context);
        }

        private (ICallable Callable, CallArgumentValue[] Arguments) BindCall(
            CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            context.CheckExecution(span);
            var receiverIndex = -1;
            for (var i = 0; i < arguments.Length; i++)
            {
                if (arguments[i].IsPositional)
                {
                    receiverIndex = i;
                    break;
                }
            }

            if (receiverIndex < 0)
            {
                throw new LythonRuntimeException("TypeError", "unbound method " + _qualifiedName + "() needs an argument", span);
            }

            var receiver = arguments[receiverIndex].Value;
            var boundCallable = (ICallable)BindReceiver(receiver, span, context);

            var rest = new CallArgumentValue[arguments.Length - 1];
            Array.Copy(arguments, 0, rest, 0, receiverIndex);
            Array.Copy(arguments, receiverIndex + 1, rest, receiverIndex, rest.Length - receiverIndex);
            return (boundCallable, rest);
        }

        internal object BindReceiver(object? receiver, LythonSourceSpan span, ExecutionContext context)
        {
            if (receiver is null || !DoesObjectMatchBuiltinType(_ownerName, receiver))
            {
                throw new LythonRuntimeException("TypeError", "descriptor '" + _memberName + "' for '" + _ownerName + "' objects doesn't apply to a '" + PythonTypeName(receiver, context) + "' object", span);
            }

            // A base dict descriptor keeps its implementation even when the
            // receiver overrides it (notably Counter.__delitem__).
            if (_ownerName == "dict" && _memberName is "__getitem__" or "__setitem__" or "__delitem__")
            {
                return DictMembers.BindItemMethod(receiver, _memberName);
            }

            if (!TryResolveRuntimeMember(receiver, _memberName, context, span, out var bound) || bound is not ICallable)
            {
                throw PyMemberAccess.CreateMissingMemberError(receiver, _memberName, span, context);
            }

            return bound;
        }

        public bool TryGetMember(string name, [MaybeNullWhen(false)] out object value)
        {
            if (name == "__name__")
            {
                value = PyString.FromString(_memberName);
                return true;
            }

            if (name == "__qualname__")
            {
                value = PyString.FromString(_qualifiedName);
                return true;
            }

            if (name == "__objclass__")
            {
                value = _owner;
                return true;
            }

            if (name == "__get__")
            {
                value = new PyBoundMethod(this, UnboundGetMethod.Instance);
                return true;
            }

            value = PyNone.Instance;
            return false;
        }

        public PyString RenderPython(PyRenderingContext context)
        {
            _ = context;
            return PyString.FromString("<method '" + _memberName + "' of '" + _ownerName + "' objects>");
        }

        public PyString RenderInterpolated(PyRenderingContext context) => RenderPython(context);

        public int GetPyHashCode() => HashCode.Combine(RuntimeHelpers.GetHashCode(_owner), StringComparer.Ordinal.GetHashCode(_memberName));

        internal static string PythonTypeName(object? receiver, ExecutionContext context)
        {
            // User instances report their class short name like CPython; every
            // other shape resolves through the shared value-class helper.
            if (receiver is PyInstance instance)
            {
                return instance.Type.Name;
            }

            if (receiver is not null &&
                TryGetValueClass(receiver, context, out var classValue) &&
                classValue is not null)
            {
                return classValue switch
                {
                    BuiltinCallable builtin => BuiltinCallable.ShortCallableName(builtin.Name),
                    PyBuiltinRuntimeType runtimeType => BuiltinCallable.ShortCallableName(runtimeType.Name),
                    TimeStructTimeType => "time.struct_time",
                    PyType type => type.Name,
                    INamedRuntimeCallable named => BuiltinCallable.ShortCallableName(named.Name),
                    _ => "object",
                };
            }

            return "object";
        }

        // Bound engine methods render like CPython built-in methods minus the
        // address suffix (Lython display names stay deterministic): the short
        // member name plus the receiver owner resolved through the shared
        // value-class helper (type objects report type like CPython).
        internal static string BoundEngineMethodDisplay(string shortName, object? receiver, ExecutionContext context)
            => "<built-in method " + shortName + " of " + PythonTypeName(receiver, context) + " object>";

        // Only plain dotted owner.member names take the builtin-method shape;
        // decorated display names (spaces, brackets) keep the legacy rendering.
        internal static bool IsPlainBoundMethodName(string name)
            => name.Contains(".") && !name.Contains(" ") && !name.Contains("(") && !name.Contains("[");
    }

    // The __get__ slot of unbound descriptors behaves like CPython method
    // wrappers: binding a receiver returns its bound member, binding None
    // against an explicit type returns the descriptor itself, and arity,
    // keyword and receiver failures use the exact wrapper texts. One shared
    // instance serves every descriptor: all member reads are constant and
    // calls delegate to the descriptor riding in as the bound self. There is
    // deliberately no __module__ or __doc__ like the other engine slot
    // wrappers (the engine keeps no doc corpus).
    internal sealed class UnboundGetMethod : ICallable, IPyDynamicAttributes, IPySlotWrapper
    {
        internal static readonly UnboundGetMethod Instance = new();

        private UnboundGetMethod()
        {
        }

        public bool TryGetMember(string name, [MaybeNullWhen(false)] out object value)
        {
            if (name == "__name__")
            {
                value = PyString.FromString("__get__");
                return true;
            }

            if (name == "__qualname__")
            {
                value = PyString.FromString("method_descriptor.__get__");
                return true;
            }

            if (name == "__objclass__")
            {
                value = PyType.MethodDescriptorType;
                return true;
            }

            value = PyNone.Instance;
            return false;
        }

        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            context.CheckExecution(span);
            foreach (var argument in arguments)
            {
                if (argument.IsKeyword)
                {
                    throw new LythonRuntimeException("TypeError", "wrapper __get__() takes no keyword arguments", span);
                }
            }

            // arguments[0] is the descriptor the bound method prepended.
            var positionals = arguments.Length - 1;
            if (positionals < 1)
            {
                throw new LythonRuntimeException("TypeError", " expected at least 1 argument, got 0", span);
            }

            if (positionals > 2)
            {
                throw new LythonRuntimeException("TypeError", " expected at most 2 arguments, got " + positionals + "", span);
            }

            if (arguments[0].Value is not UnboundTypeMethod descriptor)
            {
                throw new LythonRuntimeException("TypeError", "__get__(None, None) is invalid", span);
            }

            var target = arguments[1].Value;
            if (target is PyNone)
            {
                if (positionals == 2 && arguments[2].Value is not PyNone)
                {
                    return descriptor;
                }

                throw new LythonRuntimeException("TypeError", "__get__(None, None) is invalid", span);
            }

            // Binding drops the owner argument like CPython and resolves
            // through the shared helper, so receiver validation and bound
            // member construction stay in one place.
            return descriptor.BindReceiver(arguments[1].Value, span, context);
        }
    }

    // Builtin numeric data attributes behave like CPython getset
    // descriptors: the short __name__, the qualified owner.member name,
    // the owning type as __objclass__, per-member documentation, and
    // __get__/__set__/__delete__ slots. Descriptors are not callable;
    // binding resolves through the instance member tables. Wrappers cache
    // per constructor, so identity holds like CPython.
    // Getset descriptors carry documentation and writable-shaped errors;
    // member descriptors report None docs and read-only errors.
    internal enum DataDescriptorKind
    {
        GetSet,
        Member,
    }

    internal sealed class BuiltinDataDescriptor : IPyDynamicAttributes, IPyRenderableValue, IPyHashableValue
    {
        private readonly object _owner;
        private readonly string _ownerName;
        private readonly string _memberName;
        private readonly string _qualifiedName;
        private readonly string? _documentation;
        private readonly DataDescriptorKind _kind;

        internal BuiltinDataDescriptor(object owner, string ownerName, string memberName, string? documentation, DataDescriptorKind kind)
        {
            _owner = owner;
            _ownerName = ownerName;
            _memberName = memberName;
            _qualifiedName = ownerName + "." + memberName;
            _documentation = documentation;
            _kind = kind;
        }

        internal string OwnerName => _ownerName;

        internal string MemberName => _memberName;

        internal DataDescriptorKind Kind => _kind;

        public bool TryGetMember(string name, [MaybeNullWhen(false)] out object value)
        {
            if (name == "__name__")
            {
                value = PyString.FromString(_memberName);
                return true;
            }

            if (name == "__qualname__")
            {
                value = PyString.FromString(_qualifiedName);
                return true;
            }

            if (name == "__objclass__")
            {
                value = _owner;
                return true;
            }

            if (name == "__doc__")
            {
                value = _documentation is null ? PyNone.Instance : PyString.FromString(_documentation);
                return true;
            }

            if (name == "__get__")
            {
                value = new PyBoundMethod(this, _kind == DataDescriptorKind.Member ? DataGetMethod.Member : DataGetMethod.GetSet);
                return true;
            }

            if (name == "__set__")
            {
                value = new PyBoundMethod(this, _kind == DataDescriptorKind.Member ? DataSetMethod.Member : DataSetMethod.GetSet);
                return true;
            }

            if (name == "__delete__")
            {
                value = new PyBoundMethod(this, _kind == DataDescriptorKind.Member ? DataDeleteMethod.Member : DataDeleteMethod.GetSet);
                return true;
            }

            value = PyNone.Instance;
            return false;
        }

        public PyString RenderPython(PyRenderingContext context)
        {
            _ = context;
            var kindName = _kind == DataDescriptorKind.Member ? "member" : "attribute";
            return PyString.FromString("<" + kindName + " '" + _memberName + "' of '" + _ownerName + "' objects>");
        }

        public PyString RenderInterpolated(PyRenderingContext context) => RenderPython(context);

        public int GetPyHashCode() => HashCode.Combine(RuntimeHelpers.GetHashCode(_owner), StringComparer.Ordinal.GetHashCode(_memberName));
    }

    // The __get__ slot of builtin data descriptors binds like CPython: a
    // receiver resolves through the instance member tables, None against an
    // explicit type returns the descriptor itself, and arity, keyword and
    // receiver failures use the exact wrapper texts. One shared instance
    // serves every descriptor like the method-descriptor slot.
    internal sealed class DataGetMethod : ICallable, IPyDynamicAttributes, IPySlotWrapper
    {
        internal static readonly DataGetMethod GetSet = new(DataDescriptorKind.GetSet);

        internal static readonly DataGetMethod Member = new(DataDescriptorKind.Member);

        private readonly DataDescriptorKind _kind;

        private DataGetMethod(DataDescriptorKind kind)
        {
            _kind = kind;
        }

        public bool TryGetMember(string name, [MaybeNullWhen(false)] out object value)
        {
            if (name == "__name__")
            {
                value = PyString.FromString("__get__");
                return true;
            }

            if (name == "__qualname__")
            {
                value = PyString.FromString((_kind == DataDescriptorKind.Member ? "member_descriptor" : "getset_descriptor") + ".__get__");
                return true;
            }

            if (name == "__objclass__")
            {
                value = _kind == DataDescriptorKind.Member ? PyType.MemberDescriptorType : PyType.GetSetDescriptorType;
                return true;
            }

            value = PyNone.Instance;
            return false;
        }

        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            context.CheckExecution(span);
            foreach (var argument in arguments)
            {
                if (argument.IsKeyword)
                {
                    throw new LythonRuntimeException("TypeError", "wrapper __get__() takes no keyword arguments", span);
                }
            }

            // arguments[0] is the descriptor the bound method prepended.
            var positionals = arguments.Length - 1;
            if (positionals < 1)
            {
                throw new LythonRuntimeException("TypeError", " expected at least 1 argument, got 0", span);
            }

            if (positionals > 2)
            {
                throw new LythonRuntimeException("TypeError", " expected at most 2 arguments, got " + positionals + "", span);
            }

            if (arguments[0].Value is not BuiltinDataDescriptor descriptor)
            {
                throw new LythonRuntimeException("TypeError", "__get__(None, None) is invalid", span);
            }

            var target = arguments[1].Value;
            if (target is PyNone)
            {
                if (positionals == 2 && arguments[2].Value is not PyNone)
                {
                    return descriptor;
                }

                throw new LythonRuntimeException("TypeError", "__get__(None, None) is invalid", span);
            }

            if (!DoesObjectMatchBuiltinType(descriptor.OwnerName, target))
            {
                throw new LythonRuntimeException("TypeError", "descriptor '" + descriptor.MemberName + "' for '" + descriptor.OwnerName + "' objects doesn't apply to a '" + UnboundTypeMethod.PythonTypeName(target, context) + "' object", span);
            }

            if (!TryResolveRuntimeMember(target, descriptor.MemberName, context, span, out var bound))
            {
                throw PyMemberAccess.CreateMissingMemberError(target, descriptor.MemberName, span, context);
            }

            return bound;
        }
    }

    // The __set__ slot of builtin data descriptors always fails like CPython:
    // numeric data attributes are read-only. One shared instance serves
    // every descriptor; the bound descriptor names the attribute.
    internal sealed class DataSetMethod : ICallable, IPyDynamicAttributes, IPySlotWrapper
    {
        internal static readonly DataSetMethod GetSet = new(DataDescriptorKind.GetSet);

        internal static readonly DataSetMethod Member = new(DataDescriptorKind.Member);

        private readonly DataDescriptorKind _kind;

        private DataSetMethod(DataDescriptorKind kind)
        {
            _kind = kind;
        }

        public bool TryGetMember(string name, [MaybeNullWhen(false)] out object value)
        {
            if (name == "__name__")
            {
                value = PyString.FromString("__set__");
                return true;
            }

            if (name == "__qualname__")
            {
                value = PyString.FromString((_kind == DataDescriptorKind.Member ? "member_descriptor" : "getset_descriptor") + ".__set__");
                return true;
            }

            if (name == "__objclass__")
            {
                value = _kind == DataDescriptorKind.Member ? PyType.MemberDescriptorType : PyType.GetSetDescriptorType;
                return true;
            }

            value = PyNone.Instance;
            return false;
        }

        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            context.CheckExecution(span);
            foreach (var argument in arguments)
            {
                if (argument.IsKeyword)
                {
                    throw new LythonRuntimeException("TypeError", "wrapper __set__() takes no keyword arguments", span);
                }
            }

            if (arguments.Length - 1 != 2)
            {
                throw new LythonRuntimeException("TypeError", " expected 2 arguments, got " + (arguments.Length - 1), span);
            }

            if (arguments[0].Value is not BuiltinDataDescriptor descriptor)
            {
                throw new LythonRuntimeException("TypeError", "__set__(None, None) is invalid", span);
            }

            if (_kind == DataDescriptorKind.Member)
            {
                throw new LythonRuntimeException("AttributeError", "readonly attribute", span);
            }

            throw new LythonRuntimeException("AttributeError", "attribute '" + descriptor.MemberName + "' of '" + descriptor.OwnerName + "' objects is not writable", span);
        }
    }

    // The __delete__ slot mirrors __set__: numeric data attributes cannot
    // be deleted either. Separate singleton so __name__ reports correctly.
    internal sealed class DataDeleteMethod : ICallable, IPyDynamicAttributes, IPySlotWrapper
    {
        internal static readonly DataDeleteMethod GetSet = new(DataDescriptorKind.GetSet);

        internal static readonly DataDeleteMethod Member = new(DataDescriptorKind.Member);

        private readonly DataDescriptorKind _kind;

        private DataDeleteMethod(DataDescriptorKind kind)
        {
            _kind = kind;
        }

        public bool TryGetMember(string name, [MaybeNullWhen(false)] out object value)
        {
            if (name == "__name__")
            {
                value = PyString.FromString("__delete__");
                return true;
            }

            if (name == "__qualname__")
            {
                value = PyString.FromString((_kind == DataDescriptorKind.Member ? "member_descriptor" : "getset_descriptor") + ".__delete__");
                return true;
            }

            if (name == "__objclass__")
            {
                value = _kind == DataDescriptorKind.Member ? PyType.MemberDescriptorType : PyType.GetSetDescriptorType;
                return true;
            }

            value = PyNone.Instance;
            return false;
        }

        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            context.CheckExecution(span);
            foreach (var argument in arguments)
            {
                if (argument.IsKeyword)
                {
                    throw new LythonRuntimeException("TypeError", "wrapper __delete__() takes no keyword arguments", span);
                }
            }

            if (arguments.Length - 1 != 1)
            {
                throw new LythonRuntimeException("TypeError", "expected 1 argument, got " + (arguments.Length - 1), span);
            }

            if (arguments[0].Value is not BuiltinDataDescriptor descriptor)
            {
                throw new LythonRuntimeException("TypeError", "__delete__(None, None) is invalid", span);
            }

            if (_kind == DataDescriptorKind.Member)
            {
                throw new LythonRuntimeException("AttributeError", "readonly attribute", span);
            }

            throw new LythonRuntimeException("AttributeError", "attribute '" + descriptor.MemberName + "' of '" + descriptor.OwnerName + "' objects is not writable", span);
        }
    }

    // Builtin classmethods (dict.fromkeys, bytes.fromhex) and staticmethods
    // (str.maketrans) behave like CPython bound-to-type builtins: the short
    // __name__, the qualified __qualname__, a None __module__, and the owning
    // type as __self__ for classmethods (staticmethods expose none), with
    // value equality by owner and member. Classmethods stay fresh per read
    // like CPython (identity never holds); the staticmethod shape is one
    // shared object. There is deliberately no __doc__ like the other engine
    // shapes (the engine keeps no doc corpus). Keyword arguments always fail
    // with the qualified wrapper text; arity and value validation live in
    // each implementation with the exact CPython texts.
    internal sealed class BuiltinTypeMethod : ICallable, IPyDynamicAttributes, IPyContextualDynamicAttributes, IPyRenderableValue, IPyHashableValue
    {
        private readonly string _ownerName;
        private readonly string _memberName;
        private readonly bool _bindsOwner;
        private readonly Func<CallArgumentValue[], LythonSourceSpan, ExecutionContext, object> _implementation;
        private readonly Func<CallArgumentValue[], LythonSourceSpan, ExecutionContext, ValueTask<object>>? _asyncImplementation;
        private readonly string _qualifiedName;

        // str.maketrans carries no run state (names plus static
        // implementation), so one process-wide object serves every read like
        // CPython, where the static shape is identical everywhere.
        internal static readonly BuiltinTypeMethod StrMaketrans = new("str", "maketrans", bindsOwner: false, StrMaketransImpl);

        internal static readonly BuiltinTypeMethod BytesMaketrans = new("bytes", "maketrans", bindsOwner: false, BytesMaketransImpl);

        internal BuiltinTypeMethod(string ownerName, string memberName, bool bindsOwner, Func<CallArgumentValue[], LythonSourceSpan, ExecutionContext, object> implementation)
            : this(ownerName, memberName, bindsOwner, implementation, null)
        {
        }

        internal BuiltinTypeMethod(string ownerName, string memberName, bool bindsOwner, Func<CallArgumentValue[], LythonSourceSpan, ExecutionContext, object> implementation, Func<CallArgumentValue[], LythonSourceSpan, ExecutionContext, ValueTask<object>>? asyncImplementation)
        {
            _ownerName = ownerName;
            _memberName = memberName;
            _bindsOwner = bindsOwner;
            _implementation = implementation;
            _asyncImplementation = asyncImplementation;
            _qualifiedName = ownerName + "." + memberName;
        }

        internal string OwnerName => _ownerName;

        internal string MemberName => _memberName;

        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            context.CheckExecution(span);
            return _implementation(arguments, span, context);
        }

        public ValueTask<object> InvokeAsync(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            context.CheckExecution(span);
            return _asyncImplementation is null
                ? ValueTask.FromResult(_implementation(arguments, span, context))
                : _asyncImplementation(arguments, span, context);
        }

        public bool TryGetMember(string name, [MaybeNullWhen(false)] out object value)
        {
            if (name == "__name__")
            {
                value = PyString.FromString(_memberName);
                return true;
            }

            if (name == "__qualname__")
            {
                value = PyString.FromString(_qualifiedName);
                return true;
            }

            if (name == "__module__")
            {
                value = PyNone.Instance;
                return true;
            }

            // Staticmethod shapes report a None __self__ like CPython
            // instead of missing.
            if (name == "__self__" && !_bindsOwner)
            {
                value = PyNone.Instance;
                return true;
            }

            value = PyNone.Instance;
            return false;
        }

        public bool TryGetMember(string name, ExecutionContext context, LythonSourceSpan span, [MaybeNullWhen(false)] out object value)
        {
            if (name == "__self__" && _bindsOwner &&
                context.TryGetBuiltin(_ownerName, out var owner) && owner is not null)
            {
                value = owner;
                return true;
            }

            return TryGetMember(name, out value);
        }

        // Type methods (dict.fromkeys and kin) render like CPython built-in
        // methods bound to the type, minus the address suffix.
        public PyString RenderPython(PyRenderingContext context)
        {
            _ = context;
            return PyString.FromString("<built-in method " + _memberName + " of type object>");
        }

        public PyString RenderInterpolated(PyRenderingContext context) => RenderPython(context);

        public int GetPyHashCode() => HashCode.Combine(StringComparer.Ordinal.GetHashCode(_ownerName), StringComparer.Ordinal.GetHashCode(_memberName));
    }

    // Shared choke point for builtin classmethods and staticmethods: only the
    // modeled (owner, member) pairs serve wrappers, so every other miss keeps
    // the shared missing-member error.
    private static bool TryGetBuiltinTypeMethod(object owner, string ownerName, string memberName, [MaybeNullWhen(false)] out object value)
    {
        _ = owner;
        value = (ownerName, memberName) switch
        {
            ("dict", "fromkeys") => new BuiltinTypeMethod(ownerName, memberName, bindsOwner: true, DictFromKeys, DictFromKeysAsync),
            ("bytes", "fromhex") => new BuiltinTypeMethod(ownerName, memberName, bindsOwner: true, BytesFromHex),
            ("str", "maketrans") => BuiltinTypeMethod.StrMaketrans,
            ("bytes", "maketrans") => BuiltinTypeMethod.BytesMaketrans,
            ("int", "from_bytes") => new BuiltinTypeMethod(ownerName, memberName, bindsOwner: true, IntFromBytes, IntFromBytesAsync),
            ("bool", "from_bytes") => new BuiltinTypeMethod(ownerName, memberName, bindsOwner: true, BoolFromBytes, BoolFromBytesAsync),
            ("float", "fromhex") => new BuiltinTypeMethod(ownerName, memberName, bindsOwner: true, FloatFromHex),
            _ => null,
        };

        if (value is null)
        {
            value = PyNone.Instance;
            return false;
        }

        return true;
    }

    internal static void RejectKeywordArguments(string qualifiedName, CallArgumentValue[] arguments, LythonSourceSpan span)
    {
        foreach (var argument in arguments)
        {
            if (argument.IsKeyword)
            {
                throw new LythonRuntimeException("TypeError", qualifiedName + "() takes no keyword arguments", span);
            }
        }
    }

    private static object[] PositionalArguments(CallArgumentValue[] arguments)
    {
        var positional = new object[arguments.Length];
        for (var i = 0; i < arguments.Length; i++)
        {
            positional[i] = arguments[i].Value;
        }

        return positional;
    }

    private static object DictFromKeys(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        RejectKeywordArguments("dict.fromkeys", arguments, span);
        return DictFromKeysPositional(PositionalArguments(arguments), span, context);
    }

    private static object DictFromKeysPositional(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length < 1)
        {
            throw new LythonRuntimeException("TypeError", "fromkeys expected at least 1 argument, got 0", span);
        }

        if (arguments.Length > 2)
        {
            throw new LythonRuntimeException("TypeError", "fromkeys expected at most 2 arguments, got " + arguments.Length, span);
        }

        var value = arguments.Length == 2 ? arguments[1] : PyNone.Instance;
        var result = new PyDict(context.MemoryGovernor, span);
        using var _ambientScope = PyStructuralGuard.PushAmbient(context, span);
        foreach (var key in ToSequence(arguments[0], span, context))
        {
            result.SetItem(ValidateDictionaryKey(key, span), value);
        }

        context.CheckExecution(span);
        return result;
    }

    private static async ValueTask<object> DictFromKeysPositionalAsync(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        // Async twin: keys await each pull while validation and insertion
        // stay identical to the streaming sync path above.
        if (arguments.Length < 1)
        {
            throw new LythonRuntimeException("TypeError", "fromkeys expected at least 1 argument, got 0", span);
        }

        if (arguments.Length > 2)
        {
            throw new LythonRuntimeException("TypeError", "fromkeys expected at most 2 arguments, got " + arguments.Length, span);
        }

        var value = arguments.Length == 2 ? arguments[1] : PyNone.Instance;
        var result = new PyDict(context.MemoryGovernor, span);
        await foreach (var key in ToSequenceAsync(arguments[0], span, context).ConfigureAwait(false))
        {
            using var ambient = PyStructuralGuard.PushAmbient(context, span);
            result.SetItem(ValidateDictionaryKey(key, span), value);
        }

        context.CheckExecution(span);
        return result;
    }

    private static async ValueTask<object> DictFromKeysAsync(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        RejectKeywordArguments("dict.fromkeys", arguments, span);
        return await DictFromKeysPositionalAsync(PositionalArguments(arguments), span, context).ConfigureAwait(false);
    }

    private static object BytesFromHex(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        RejectKeywordArguments("bytes.fromhex", arguments, span);
        return BytesFromHexPositional(PositionalArguments(arguments), span, context);
    }

    private static object BytesFromHexPositional(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length != 1)
        {
            throw new LythonRuntimeException("TypeError", "bytes.fromhex() takes exactly one argument (" + arguments.Length + " given)", span);
        }

        if (arguments[0] is not PyString text)
        {
            throw new LythonRuntimeException("TypeError", "fromhex() argument must be str, not " + UnboundTypeMethod.PythonTypeName(arguments[0], context), span);
        }

        // Positions count in the original string (spaces included): a space
        // directly inside a pair is invalid, while a lone trailing nibble
        // reports one past the end like CPython.
        var source = text.Utf8Span;
        var builder = new GovernedByteBuilder(context.MemoryGovernor, span);
        var index = 0;
        try
        {
            while (true)
            {
                context.CheckExecution(span);
                while (index < source.Length && IsHexSpace((char)source[index]))
                {
                    if ((index & 1023) == 0) context.CheckExecution(span);
                    index++;
                }
                if (index >= source.Length) break;
                var high = HexValue((char)source[index]);
                if (high < 0) throw InvalidHex(index);
                if (++index >= source.Length) throw InvalidHex(source.Length);
                var low = HexValue((char)source[index]);
                if (low < 0) throw InvalidHex(index);
                index++;
                builder.Append((byte)((high << 4) | low));
            }
            return builder.ToPyBytesAndRelease();
        }
        finally { builder.Release(); }

        LythonRuntimeException InvalidHex(int position) => new("ValueError", "non-hexadecimal number found in fromhex() arg at position " + position, span);
    }

    private static bool IsHexSpace(char value)
        => value is ' ' or '\t' or '\n' or '\v' or '\f' or '\r';

    private static int HexValue(char value)
    {
        if (value >= '0' && value <= '9')
        {
            return value - '0';
        }

        if (value >= 'a' && value <= 'f')
        {
            return value - 'a' + 10;
        }

        if (value >= 'A' && value <= 'F')
        {
            return value - 'A' + 10;
        }

        return -1;
    }

    private static object StrMaketransImpl(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        RejectKeywordArguments("str.maketrans", arguments, span);
        return StrMaketransPositional(PositionalArguments(arguments), span, context);
    }

    private static object StrMaketransPositional(object[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        if (arguments.Length < 1)
        {
            throw new LythonRuntimeException("TypeError", "maketrans expected at least 1 argument, got 0", span);
        }

        if (arguments.Length > 3)
        {
            throw new LythonRuntimeException("TypeError", "maketrans expected at most 3 arguments, got " + arguments.Length, span);
        }

        var result = new PyDict(context.MemoryGovernor, span);
        if (arguments.Length == 1)
        {
            if (arguments[0] is not PyDict table)
            {
                throw new LythonRuntimeException("TypeError", "if you give only one argument to maketrans it must be a dict", span);
            }

            foreach (var pair in table)
            {
                result.SetItem(MaketransKey(pair.Key, span), pair.Value);
            }

            context.CheckExecution(span);
            return result;
        }

        if (arguments[0] is not PyString from)
        {
            throw new LythonRuntimeException("TypeError", "first maketrans argument must be a string if there is a second argument", span);
        }

        if (arguments[1] is not PyString to)
        {
            throw new LythonRuntimeException("TypeError", "maketrans() argument 2 must be str, not " + UnboundTypeMethod.PythonTypeName(arguments[1], context), span);
        }

        var fromRunes = ToRunes(from);
        var toRunes = ToRunes(to);
        if (fromRunes.Count != toRunes.Count)
        {
            throw new LythonRuntimeException("ValueError", "the first two maketrans arguments must have equal length", span);
        }

        for (var i = 0; i < fromRunes.Count; i++)
        {
            result.SetItem(new BigInteger(fromRunes[i].Value), new BigInteger(toRunes[i].Value));
        }

        if (arguments.Length == 3)
        {
            if (arguments[2] is not PyString deletions)
            {
                throw new LythonRuntimeException("TypeError", "maketrans() argument 3 must be str, not " + UnboundTypeMethod.PythonTypeName(arguments[2], context), span);
            }

            foreach (var rune in ToRunes(deletions))
            {
                result.SetItem(new BigInteger(rune.Value), PyNone.Instance);
            }
        }

        context.CheckExecution(span);
        return result;
    }

    private static List<Rune> ToRunes(PyString text)
    {
        var runes = new List<Rune>();
        foreach (var rune in text.AsString().EnumerateRunes())
        {
            runes.Add(rune);
        }

        return runes;
    }

    // Translate-table keys are single code points or integers; values ride
    // through unvalidated like CPython (translate() rejects them instead).
    private static object MaketransKey(object key, LythonSourceSpan span)
    {
        if (key is PyString text)
        {
            var runes = ToRunes(text);
            if (runes.Count != 1)
            {
                throw new LythonRuntimeException("ValueError", "string keys in translate table must be of length 1", span);
            }

            return new BigInteger(runes[0].Value);
        }

        if (Numbers.PyNumberOps.IsInteger(key))
        {
            return key;
        }

        throw new LythonRuntimeException("TypeError", "keys in translate table must be strings or integers", span);
    }

    // int.to_bytes and int.from_bytes share the (first, byteorder, signed)
    // shape: the first two ride positionally or by keyword, signed is
    // keyword-only, with the exact CPython diagnostics.
    private static void ParseByteOrderArguments(string method, string firstName, CallArgumentValue[] arguments, LythonSourceSpan span, out object? first, out object? byteorder, out object? signed)
    {
        first = null;
        byteorder = null;
        signed = null;
        var haveFirst = false;
        var haveOrder = false;
        var totalPositionals = 0;
        foreach (var argument in arguments)
        {
            if (argument.IsPositional)
            {
                totalPositionals++;
            }
        }

        var positionalIndex = 0;
        foreach (var argument in arguments)
        {
            if (!argument.IsKeyword)
            {
                positionalIndex++;
                if (positionalIndex == 1)
                {
                    first = argument.Value;
                    haveFirst = true;
                }
                else if (positionalIndex == 2)
                {
                    byteorder = argument.Value;
                    haveOrder = true;
                }
                else
                {
                    throw new LythonRuntimeException("TypeError", method + "() takes at most 2 positional arguments (" + totalPositionals + " given)", span);
                }

                continue;
            }

            if (argument.KeywordName == firstName)
            {
                if (haveFirst)
                {
                    throw new LythonRuntimeException("TypeError", "argument for " + method + "() given by name ('" + firstName + "') and position (1)", span);
                }

                first = argument.Value;
                haveFirst = true;
            }
            else if (argument.KeywordName == "byteorder")
            {
                if (haveOrder)
                {
                    throw new LythonRuntimeException("TypeError", "argument for " + method + "() given by name ('byteorder') and position (2)", span);
                }

                byteorder = argument.Value;
                haveOrder = true;
            }
            else if (argument.KeywordName == "signed")
            {
                signed = argument.Value;
            }
            else
            {
                throw new LythonRuntimeException("TypeError", method + "() got an unexpected keyword argument '" + argument.KeywordName + "'", span);
            }
        }
    }

    private static async ValueTask<(bool LittleEndian, bool Signed)> ParseByteOrderAsync(object? byteorder, object? signedValue,
        string method, ExecutionContext context, LythonSourceSpan span, bool asynchronous)
    {
        // Argument type conversion precedes signed truthiness; byte-order content
        // validation belongs to the operation body and follows that callback.
        if (byteorder is not null and not PyString)
        {
            throw new LythonRuntimeException("TypeError", method + "() argument 'byteorder' must be str, not " + UnboundTypeMethod.PythonTypeName(byteorder, context), span);
        }

        var signed = signedValue is not null && (asynchronous
            ? await IsTruthyAsync(signedValue, context, span).ConfigureAwait(false) : IsTruthy(signedValue, context, span));
        if (byteorder is null) return (false, signed);
        var text = (PyString)byteorder;
        if (text.Utf8Span.SequenceEqual("little"u8))
        {
            return (true, signed);
        }

        if (text.Utf8Span.SequenceEqual("big"u8))
        {
            return (false, signed);
        }

        throw new LythonRuntimeException("ValueError", "byteorder must be either 'little' or 'big'", span);
    }

    // __index__-style operands (including user slots through the shared
    // protocol) with the exact CPython rejection text.
    private static BigInteger InterpretByteInteger(object value, ExecutionContext context, LythonSourceSpan span)
    {
        var coerced = TryInvokeUnarySpecialMethod(value, "__index__", context, span, out var indexed)
            ? ValidateIntegerConversionResult(indexed, "__index__", context, span) : value;
        return RequireByteInteger(coerced, context, span);
    }

    private static BigInteger RequireByteInteger(object value, ExecutionContext context, LythonSourceSpan span)
        => value switch
        {
            _ when Numbers.PyNumberOps.TryAsInteger(value, out var integer) => integer,
            _ => throw new LythonRuntimeException("TypeError", "'" + RuntimeErrors.DatetimeQualifiedTypeName(value, context) + "' object cannot be interpreted as an integer", span),
        };

    private static object IntToBytes(BigInteger value, CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        => IntToBytesCoreAsync(value, arguments, span, context, false).GetAwaiter().GetResult();

    private static ValueTask<object> IntToBytesAsync(BigInteger value, CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        => IntToBytesCoreAsync(value, arguments, span, context, true);

    private static async ValueTask<object> IntToBytesCoreAsync(BigInteger value, CallArgumentValue[] arguments,
        LythonSourceSpan span, ExecutionContext context, bool asynchronous)
    {
        ParseByteOrderArguments("to_bytes", "length", arguments, span, out var lengthValue, out var orderValue, out var signedValue);
        var length = lengthValue is null ? BigInteger.One : asynchronous
            ? RequireByteInteger(await ConvertIntegerIndexAsync(lengthValue, context, span).ConfigureAwait(false), context, span)
            : InterpretByteInteger(lengthValue, context, span);
        if (length < (long)nint.MinValue || length > (long)nint.MaxValue)
            throw new LythonRuntimeException("OverflowError", "Python int too large to convert to C ssize_t", span);
        var (littleEndian, signed) = await ParseByteOrderAsync(orderValue, signedValue, "to_bytes", context, span, asynchronous).ConfigureAwait(false);
        if (length < 0)
        {
            throw new LythonRuntimeException("ValueError", "length argument must be non-negative", span);
        }

        if (length > int.MaxValue)
        {
            throw new LythonRuntimeException("OverflowError", "bytes object is too large", span);
        }

        if (value.Sign < 0 && !signed)
        {
            throw new LythonRuntimeException("OverflowError", "can't convert negative int to unsigned", span);
        }

        var size = (int)length;
        // CPython permits zero-width encodings of zero and signed minus one.
        var count = size == 0 && (value.IsZero || signed && value == BigInteger.MinusOne)
            ? 0 : value.GetByteCount(isUnsigned: !signed);
        if (count > size)
        {
            throw new LythonRuntimeException("OverflowError", "int too big to convert", span);
        }

        context.CheckExecution(span);
        using var storage = context.MemoryGovernor.ReserveTemporary(PyBytes.EstimateApproximateBytes(size), span);
        context.CheckExecution(span);
        var raw = new byte[size];
        // One managed linear write replaces a fresh shrinking BigInteger per byte.
        if (count != 0 && !value.TryWriteBytes(raw.AsSpan(littleEndian ? 0 : size - count, count),
                out _, isUnsigned: !signed, isBigEndian: !littleEndian))
            throw new InvalidOperationException("Integer byte count changed during conversion.");
        if (value.Sign < 0)
        {
            var end = littleEndian ? size : size - count;
            for (var offset = littleEndian ? count : 0; offset < end;)
            {
                context.CheckExecution(span);
                var chunk = Math.Min(16384, end - offset);
                raw.AsSpan(offset, chunk).Fill(0xff);
                offset += chunk;
            }
        }
        context.CheckExecution(span);
        return new PyBytes(raw, context.MemoryGovernor, span, storage);
    }

    private static object IntFromBytes(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        => IntFromBytesCoreAsync(arguments, span, context, false).GetAwaiter().GetResult();

    private static ValueTask<object> IntFromBytesAsync(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        => IntFromBytesCoreAsync(arguments, span, context, true);

    private static async ValueTask<object> IntFromBytesCoreAsync(CallArgumentValue[] arguments, LythonSourceSpan span,
        ExecutionContext context, bool asynchronous)
    {
        ParseByteOrderArguments("from_bytes", "bytes", arguments, span, out var source, out var orderValue, out var signedValue);
        if (source is null)
            throw new LythonRuntimeException("TypeError", "from_bytes() missing required argument 'bytes' (pos 1)", span);
        var (littleEndian, signed) = await ParseByteOrderAsync(orderValue, signedValue, "from_bytes", context, span, asynchronous).ConfigureAwait(false);
        if (source is PyInstance instance)
        {
            var protocol = asynchronous
                ? await InvokeUnarySpecialMethodAsync(instance, "__bytes__", context, span).ConfigureAwait(false)
                : TryInvokeUnarySpecialMethod(instance, "__bytes__", context, span, out var converted)
                    ? SpecialMethodInvocation.Invoked(converted) : SpecialMethodInvocation.Missing;
            if (protocol.Kind == SpecialMethodInvocationKind.Invoked)
                source = ValidateBytesConversionResult(protocol.Value, context, span);
        }
        if (source is PyBytes bytes) return IntegerFromStorage(bytes.Bytes, littleEndian, signed, context, span);
        if (source is PyString)
            throw new LythonRuntimeException("TypeError", "cannot convert 'str' object to bytes", span);
        var builder = new GovernedByteBuilder(context.MemoryGovernor, span);
        try
        {
            if (asynchronous) await FillBytesOperandsAsync(source, builder, context, span).ConfigureAwait(false);
            else FillBytesOperands(source, builder, context, span);
            return IntegerFromStorage(builder.WrittenSpan, littleEndian, signed, context, span);
        }
        finally { builder.Release(); }
    }

    private static object IntegerFromStorage(ReadOnlySpan<byte> raw, bool littleEndian, bool signed,
        ExecutionContext context, LythonSourceSpan span)
    {
        context.CheckExecution(span);
        using var admission = GuardIntegerResultBytes(33L + raw.Length, context.MemoryGovernor, span);
        return OwnFreshInteger(new BigInteger(raw, isUnsigned: !signed, isBigEndian: !littleEndian), context.MemoryGovernor, span);
    }

    private static void FillBytesOperands(object source, GovernedByteBuilder builder, ExecutionContext context, LythonSourceSpan span)
    {
        try
        {
            foreach (var item in ToSequence(source, span, context))
                builder.Append(ValidateByteOperand(InterpretByteInteger(item, context, span), span));
        }
        catch (PyNotIterableException)
        {
            throw new LythonRuntimeException("TypeError", "cannot convert '" + UnboundTypeMethod.PythonTypeName(source, context) + "' object to bytes", span);
        }
    }

    private static async ValueTask FillBytesOperandsAsync(object source, GovernedByteBuilder builder, ExecutionContext context, LythonSourceSpan span)
    {
        try
        {
            await foreach (var item in ToSequenceAsync(source, span, context).ConfigureAwait(false))
            {
                var value = await ConvertIntegerIndexAsync(item, context, span).ConfigureAwait(false);
                if (!Numbers.PyNumberOps.TryAsInteger(value, out var number))
                    throw new LythonRuntimeException("TypeError", "'" + RuntimeErrors.DatetimeQualifiedTypeName(item, context) + "' object cannot be interpreted as an integer", span);
                builder.Append(ValidateByteOperand(number, span));
            }
        }
        catch (PyNotIterableException)
        {
            throw new LythonRuntimeException("TypeError", "cannot convert '" + UnboundTypeMethod.PythonTypeName(source, context) + "' object to bytes", span);
        }
    }

    private static byte ValidateByteOperand(BigInteger number, LythonSourceSpan span)
        => number >= 0 && number <= 255 ? (byte)number
            : throw new LythonRuntimeException("ValueError", "bytes must be in range(0, 256)", span);

    private static object FloatFromHex(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        _ = context;
        RejectKeywordArguments("float.fromhex", arguments, span);
        var positional = PositionalArguments(arguments);
        if (positional.Length != 1)
        {
            throw new LythonRuntimeException("TypeError", "float.fromhex() takes exactly one argument (" + positional.Length + " given)", span);
        }

        if (positional[0] is not PyString text)
        {
            throw new LythonRuntimeException("TypeError", "bad argument type for built-in operation", span);
        }

        return FloatFromHex(text.AsString(), span);
    }

    private static object BoolFromBytes(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        // IntFromBytes always returns the BigInteger magnitude.
        var number = PyNumberOps.GetInteger(IntFromBytes(arguments, span, context));
        return RuntimeValue(!number.IsZero);
    }

    private static async ValueTask<object> BoolFromBytesAsync(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        => RuntimeValue(!PyNumberOps.GetInteger(await IntFromBytesAsync(arguments, span, context).ConfigureAwait(false)).IsZero);

    private static object BytesMaketransImpl(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
    {
        _ = context;
        RejectKeywordArguments("bytes.maketrans", arguments, span);
        var positional = PositionalArguments(arguments);
        if (positional.Length != 2)
        {
            throw new LythonRuntimeException("TypeError", "maketrans expected 2 arguments, got " + positional.Length, span);
        }

        if (positional[0] is not PyBytes from || positional[1] is not PyBytes to)
        {
            var offender = positional[0] is not PyBytes ? positional[0] : positional[1];
            throw new LythonRuntimeException("TypeError", "a bytes-like object is required, not '" + UnboundTypeMethod.PythonTypeName(offender, context) + "'", span);
        }

        // Both operands are immutable, so length checks and indexed
        // traversal read their spans directly: no per-call array copies and
        // no transient reservation tripwires for scratch that no longer
        // allocates. The 256-byte table and the result stay governed.
        ReadOnlySpan<byte> source = from.Bytes;
        ReadOnlySpan<byte> target = to.Bytes;
        if (source.Length != target.Length)
        {
            throw new LythonRuntimeException("ValueError", "maketrans arguments must have same length", span);
        }

        var table = new byte[256];
        for (var i = 0; i < 256; i++)
        {
            table[i] = (byte)i;
        }

        for (var i = 0; i < source.Length; i++)
        {
            table[source[i]] = target[i];
        }

        return CreateBytes(table, context, span);
    }

    // Shared choke point for unbound builtin type methods: only constructors
    // for types with instance member tables (list, str, bytes, dict, set)
    // serve descriptors, and only for members their tables resolve to a
    // callable on a probe receiver, so every other miss keeps the shared
    // missing-member error.
    private static bool TryGetUnboundTypeMethod(object owner, string ownerName, ref Dictionary<string, UnboundTypeMethod>? cache, string memberName, [MaybeNullWhen(false)] out object value)
    {
        value = PyNone.Instance;
        // Consult the existing method cache before constructing a probe
        // receiver and resolving its member: tables are fixed per run, so a
        // cached entry is exactly what the full path below would return.
        if (cache is not null && cache.TryGetValue(memberName, out var cachedMethod))
        {
            value = cachedMethod;
            return true;
        }

        var probe = ownerName switch
        {
            "list" => (object)new PyList(),
            "str" => PyString.FromString(""),
            "bytes" => new PyBytes([]),
            "dict" => new PyDict(),
            "tuple" => new PyTuple(Array.Empty<object>()),
            "int" => BigInteger.Zero,
            "float" => 0.0,
            "range" => new PyRange(BigInteger.Zero, BigInteger.Zero, BigInteger.One),
            "slice" => new PySlice(PyNone.Instance, PyNone.Instance, PyNone.Instance),
            "set" => new PySet(),
            _ => null,
        };

        if (probe is null ||
            !PyMemberAccess.TryResolveInstanceTableMember(probe, memberName, out var resolved) ||
            resolved is not ICallable)
        {
            return false;
        }

        cache ??= new Dictionary<string, UnboundTypeMethod>(StringComparer.Ordinal);
        if (!cache.TryGetValue(memberName, out var method))
        {
            method = new UnboundTypeMethod(owner, ownerName, memberName);
            cache[memberName] = method;
        }

        value = method;
        return true;
    }

    // Shared choke point for unbound builtin data descriptors: int and float
    // expose their scalar data attributes as getset descriptors like CPython.
    // Only members the instance tables resolve to a plain value qualify, so
    // methods keep flowing through the descriptor choke above; bool shares
    // int's cache through the delegation below.
    private static bool TryGetUnboundDataDescriptor(object owner, string ownerName, ref Dictionary<string, BuiltinDataDescriptor>? cache, string memberName, [MaybeNullWhen(false)] out object value)
    {
        value = PyNone.Instance;
        // Same cache-first shape as the method choke above: descriptor tables
        // are fixed per run, so a cached entry matches the full path.
        if (cache is not null && cache.TryGetValue(memberName, out var cachedDescriptor))
        {
            value = cachedDescriptor;
            return true;
        }

        (string? documentation, DataDescriptorKind? kind) = (ownerName, memberName) switch
        {
            ("int", "real") => ("the real part of a complex number", DataDescriptorKind.GetSet),
            ("int", "imag") => ("the imaginary part of a complex number", DataDescriptorKind.GetSet),
            ("int", "numerator") => ("the numerator of a rational number in lowest terms", DataDescriptorKind.GetSet),
            ("int", "denominator") => ("the denominator of a rational number in lowest terms", DataDescriptorKind.GetSet),
            ("float", "real") => ("the real part of a complex number", DataDescriptorKind.GetSet),
            ("float", "imag") => ("the imaginary part of a complex number", DataDescriptorKind.GetSet),
            ("range", "start") => ((string?)null, DataDescriptorKind.Member),
            ("range", "stop") => ((string?)null, DataDescriptorKind.Member),
            ("range", "step") => ((string?)null, DataDescriptorKind.Member),
            _ => ((string?)null, (DataDescriptorKind?)null),
        };

        if (kind is null)
        {
            return false;
        }

        var probe = ownerName switch
        {
            "int" => (object)BigInteger.Zero,
            "float" => (object)0.0,
            "range" => (object)new PyRange(BigInteger.Zero, BigInteger.Zero, BigInteger.One),
            _ => null,
        };

        if (probe is null ||
            !PyMemberAccess.TryResolveInstanceTableMember(probe, memberName, out var resolved) ||
            resolved is ICallable)
        {
            return false;
        }

        cache ??= new Dictionary<string, BuiltinDataDescriptor>(StringComparer.Ordinal);
        if (!cache.TryGetValue(memberName, out var descriptor))
        {
            descriptor = new BuiltinDataDescriptor(owner, ownerName, memberName, documentation, kind.Value);
            cache[memberName] = descriptor;
        }

        value = descriptor;
        return true;
    }

    // Marks bound engine-method wrappers (per-access or receiver-bound) so member
    // resolution treats them uniformly without naming generic instantiations.
    internal interface IPyBoundEngineMethod
    {
    }

    // Marks raw bound callables carrying names (dict/defaultdict update,
    // bytes translate, int to_bytes) so equality treats them uniformly
    // without naming the private wrapper.
    internal interface IPyRawBoundCallable
    {
        string? BoundName { get; }

        object? BoundReceiver { get; }
    }

    // Types expose their own stable __new__ slot like CPython (int.__new__
    // is int.__new__, qualified by the type, bound to it). Construction
    // through the slot is unsupported; type(...) builds values. Wrappers
    // are cached as fixed type metadata, beside their owning type object.
    internal sealed class TypeNewMethod : ICallable, IPyDynamicAttributes, IPyBoundEngineMethod, IPyRenderableValue
    {
        private readonly object _owner;
        private readonly string _shortName;
        // Names derive from the immutable short type name, so each wrapper caches
        // its two constants once: repeated reads alias stably like CPython
        // instead of minting (and retaining) a fresh string per read.
        private readonly PyString _nameValue = PyString.FromString("__new__");
        private readonly PyString _qualNameValue;

        internal TypeNewMethod(object owner, string shortName)
        {
            _owner = owner;
            _shortName = shortName;
            _qualNameValue = PyString.FromString(shortName + ".__new__");
        }

        public bool TryGetMember(string name, [MaybeNullWhen(false)] out object value)
        {
            if (name is "__name__")
            {
                value = _nameValue;
                return true;
            }

            if (name is "__qualname__")
            {
                value = _qualNameValue;
                return true;
            }

            if (name is "__module__")
            {
                value = PyNone.Instance;
                return true;
            }

            if (name is "__self__")
            {
                value = _owner;
                return true;
            }

            value = PyNone.Instance;
            return false;
        }

        // Type __new__ slots render like CPython built-in methods bound to
        // the type, minus the address suffix.
        public PyString RenderPython(PyRenderingContext context)
        {
            _ = context;
            return PyString.FromString("<built-in method __new__ of type object>");
        }

        public PyString RenderInterpolated(PyRenderingContext context) => RenderPython(context);

        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            // Construction routes to the owning type like CPython
            // (int.__new__(int, value) builds int(value)); exception slots
            // forward to the receiving subclass instead. Anything else
            // fails explicitly since cls-threading is unsupported.
            if (arguments.Length == 0 || arguments[0].IsKeyword)
            {
                throw new LythonRuntimeException("TypeError", "type.__new__ construction expects the type as its first argument in Lython.", span);
            }

            if (ReferenceEquals(arguments[0].Value, _owner) &&
                _owner is LythonRuntime.ICallable ownerCallable)
            {
                return ownerCallable.Invoke(arguments[1..], span, context);
            }

            if (_owner is LythonRuntime.ExceptionTypeValue &&
                arguments[0].Value is LythonRuntime.ExceptionTypeValue subclassCtor)
            {
                return subclassCtor.Invoke(arguments[1..], span, context);
            }

            throw new LythonRuntimeException("TypeError", "type.__new__ construction expects the type as its first argument in Lython.", span);
        }
    }

    // Pure-Python-modeled types expose their __new__ slot as a plain function
    // like CPython (no __self__, function identity); wrappers are cached on
    // the owning type object beside it.
    internal sealed class FunctionNewMethod : ICallable, IPyDynamicAttributes, IPyRenderableValue
    {
        private readonly object _owner;
        private readonly string _shortName;
        // Same immutable-name caching as TypeNewMethod above.
        private readonly PyString _nameValue = PyString.FromString("__new__");
        private readonly PyString _qualNameValue;

        internal FunctionNewMethod(object owner, string shortName)
        {
            _owner = owner;
            _shortName = shortName;
            _qualNameValue = PyString.FromString(shortName + ".__new__");
        }

        public bool TryGetMember(string name, [MaybeNullWhen(false)] out object value)
        {
            if (name == "__annotations__" && _owner is PyNamedTupleType namedTuple)
            {
                value = namedTuple.GetConstructorAnnotations();
                return true;
            }

            if (name is "__name__")
            {
                value = _nameValue;
                return true;
            }

            if (name is "__qualname__")
            {
                value = _qualNameValue;
                return true;
            }

            if (name is "__module__")
            {
                value = PyNone.Instance;
                return true;
            }

            value = PyNone.Instance;
            return false;
        }

        // Pure-Python-modeled __new__ slots render like CPython plain
        // functions, minus the address suffix.
        public PyString RenderPython(PyRenderingContext context)
        {
            _ = context;
            return PyString.FromString("<function " + _shortName + ".__new__>");
        }

        public PyString RenderInterpolated(PyRenderingContext context) => RenderPython(context);

        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
            => ConstructionTarget(arguments, span, context).Invoke(arguments[1..], span, context);

        public ValueTask<object> InvokeAsync(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
            => ConstructionTarget(arguments, span, context).InvokeAsync(arguments[1..], span, context);

        private ICallable ConstructionTarget(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            // Preserve exact-owner construction for modeled types. Path slots
            // also construct their supported concrete subclasses.
            if (arguments.Length != 0 && !arguments[0].IsKeyword &&
                (ReferenceEquals(arguments[0].Value, _owner) ||
                 _owner is PathlibModule.PathlibPathType && arguments[0].Value is PathlibModule.PathlibPathType &&
                 IsSubclassAgainstSingleType(arguments[0].Value, _owner, context)) && arguments[0].Value is ICallable target)
                return target;
            throw new LythonRuntimeException("TypeError", "type.__new__ construction expects the type as its first argument in Lython.", span);
        }
    }

    // Shared choke point for type __new__ slots: builtin type-table entries
    // denote constructors with their own slot, and the core runtime types
    // (function, method, module, NoneType) bind their singleton like CPython.
    // Anything else keeps its own rules.
    internal static bool TryGetTypeNewSlot(object classValue, [MaybeNullWhen(false)] out object value)
    {
        if (classValue is BuiltinCallable ctor && BuiltinTypeBaseNames.ContainsKey(ctor.Name))
        {
            ctor.NewSlot ??= new TypeNewMethod(ctor, BuiltinCallable.ShortCallableName(ctor.Name));
            value = ctor.NewSlot;
            return true;
        }

        if (classValue is DictCallable dictCallable && BuiltinTypeBaseNames.ContainsKey(dictCallable.Name))
        {
            dictCallable.NewSlot ??= new TypeNewMethod(dictCallable, dictCallable.Name);
            value = dictCallable.NewSlot;
            return true;
        }

        if (classValue is ZipCallable zipCallable && BuiltinTypeBaseNames.ContainsKey(zipCallable.Name))
        {
            zipCallable.NewSlot ??= new TypeNewMethod(zipCallable, zipCallable.Name);
            value = zipCallable.NewSlot;
            return true;
        }

        if (ReferenceEquals(classValue, PyType.FunctionType))
        {
            value = _functionTypeNewSlot;
            return true;
        }

        if (ReferenceEquals(classValue, PyType.MethodType))
        {
            value = _methodTypeNewSlot;
            return true;
        }

        if (ReferenceEquals(classValue, PyType.ModuleType))
        {
            value = _moduleTypeNewSlot;
            return true;
        }

        if (ReferenceEquals(classValue, PyType.NoneType))
        {
            value = _noneTypeNewSlot;
            return true;
        }

        if (ReferenceEquals(classValue, PyType.EllipsisType))
        {
            value = _ellipsisTypeNewSlot;
            return true;
        }

        if (ReferenceEquals(classValue, PyType.NotImplementedType))
        {
            value = _notImplementedTypeNewSlot;
            return true;
        }

        // Datetime, random and tzinfo runtime types own their slot too,
        // qualified by the short type name like CPython. The table is frozen
        // by the static constructor, so concurrent first access from
        // independent runs performs a pure lookup with no shared mutation.
        if (classValue is PyBuiltinRuntimeType datetimeType &&
            _datetimeTypeNewSlots.TryGetValue(datetimeType, out var datetimeSlot))
        {
            value = datetimeSlot;
            return true;
        }

        // deque owns its slot through its stable collections member, like
        // the builtin constructors above.
        if (classValue is CollectionsCallable dequeCallable && dequeCallable.Name is "collections.deque")
        {
            dequeCallable.NewSlot ??= new TypeNewMethod(dequeCallable, "deque");
            value = dequeCallable.NewSlot;
            return true;
        }

        // The partial factory owns its slot through its global singleton,
        // like the builtin constructors above. The static constructor
        // publishes it once (Instance is the only instance), so this is a
        // pure read under concurrent first access.
        if (classValue is PartialFactory partialFactory)
        {
            value = partialFactory.NewSlot!;
            return true;
        }

        // struct_time owns its slot through its dedicated singleton, like
        // the builtin constructors above.
        if (classValue is TimeStructTimeType structTimeType)
        {
            // Published once by the static constructor (Instance is the only
            // instance), so this is a pure read under concurrent first access.
            value = structTimeType.NewSlot!;
            return true;
        }

        value = PyNone.Instance;
        return false;
    }

    // Shared choke point for builtin exception __new__ slots: the caller
    // resolves the defining type along the builtin hierarchy; the wrapper
    // is cached on that type object like constructor slots.
    internal static bool TryGetExceptionNewSlot(ExceptionTypeValue typeValue, string shortName, [MaybeNullWhen(false)] out object value)
    {
        typeValue.NewSlot ??= new TypeNewMethod(typeValue, shortName);
        value = typeValue.NewSlot;
        return true;
    }

    // Shared __new__ slots for process-wide type singletons. Every owner
    // below (PyType.*, PyDateTimeOps.*, RandomType, and the two singleton
    // factories) is shared across independent runs, so the static constructor
    // publishes each wrapper exactly once and the choke above only reads them
    // afterwards. Per-run type constructors (BuiltinCallable, DictCallable,
    // ZipCallable, per-access CollectionsCallable, per-run ExceptionTypeValue)
    // and their per-instance unbound caches keep their lazy slot: those
    // objects are confined to a single run's thread. A run stays
    // single-threaded; independent engines on separate threads are the
    // supported concurrency shape, sharing only this prebuilt metadata plus
    // thread-safe interners, ThreadStatic scratch pools, and per-run state.
    static LythonRuntime()
    {
        _functionTypeNewSlot = new TypeNewMethod(PyType.FunctionType, PyType.FunctionType.Name);
        _methodTypeNewSlot = new TypeNewMethod(PyType.MethodType, PyType.MethodType.Name);
        _moduleTypeNewSlot = new TypeNewMethod(PyType.ModuleType, PyType.ModuleType.Name);
        _noneTypeNewSlot = new TypeNewMethod(PyType.NoneType, PyType.NoneType.Name);
        _ellipsisTypeNewSlot = new TypeNewMethod(PyType.EllipsisType, PyType.EllipsisType.Name);
        _notImplementedTypeNewSlot = new TypeNewMethod(PyType.NotImplementedType, PyType.NotImplementedType.Name);
        _datetimeTypeNewSlots = new Dictionary<PyBuiltinRuntimeType, TypeNewMethod>(ReferenceEqualityComparer.Instance)
        {
            [PyDateTimeOps.TimedeltaType] = new TypeNewMethod(PyDateTimeOps.TimedeltaType, BuiltinCallable.ShortCallableName(PyDateTimeOps.TimedeltaType.Name)),
            [PyDateTimeOps.DateType] = new TypeNewMethod(PyDateTimeOps.DateType, BuiltinCallable.ShortCallableName(PyDateTimeOps.DateType.Name)),
            [PyDateTimeOps.TimeType] = new TypeNewMethod(PyDateTimeOps.TimeType, BuiltinCallable.ShortCallableName(PyDateTimeOps.TimeType.Name)),
            [PyDateTimeOps.DateTimeType] = new TypeNewMethod(PyDateTimeOps.DateTimeType, BuiltinCallable.ShortCallableName(PyDateTimeOps.DateTimeType.Name)),
            [PyDateTimeOps.TimezoneType] = new TypeNewMethod(PyDateTimeOps.TimezoneType, BuiltinCallable.ShortCallableName(PyDateTimeOps.TimezoneType.Name)),
            [PyDateTimeOps.TzInfoType] = new TypeNewMethod(PyDateTimeOps.TzInfoType, BuiltinCallable.ShortCallableName(PyDateTimeOps.TzInfoType.Name)),
            [RandomModule.RandomType] = new TypeNewMethod(RandomModule.RandomType, BuiltinCallable.ShortCallableName(RandomModule.RandomType.Name)),
        }.ToFrozenDictionary(ReferenceEqualityComparer.Instance);
        // Both singleton factories publish their slot here instead of lazily:
        // each Instance is unique, so the choke only reads them afterwards.
        PartialFactory.Instance.NewSlot = new TypeNewMethod(PartialFactory.Instance, "partial");
        TimeStructTimeType.Instance.NewSlot = new TypeNewMethod(TimeStructTimeType.Instance, BuiltinCallable.ShortCallableName(TimeStructTimeType.Instance.Name));
    }

    private static readonly TypeNewMethod _functionTypeNewSlot;
    private static readonly TypeNewMethod _methodTypeNewSlot;
    private static readonly TypeNewMethod _moduleTypeNewSlot;
    private static readonly TypeNewMethod _noneTypeNewSlot;
    private static readonly TypeNewMethod _ellipsisTypeNewSlot;
    private static readonly TypeNewMethod _notImplementedTypeNewSlot;
    private static readonly FrozenDictionary<PyBuiltinRuntimeType, TypeNewMethod> _datetimeTypeNewSlots;

    private class BuiltinCallable : DelegateBoundArgumentsCallable, INamedRuntimeCallable, IPyRenderableValue, IPyHashableValue, IPyDynamicAttributes, IPyContextualDynamicAttributes
    {
        protected BuiltinCallable(
            LythonCallableSignature signature,
            Func<object[], LythonSourceSpan, ExecutionContext, object> implementation,
            Func<object[], LythonSourceSpan, ExecutionContext, ValueTask<object>>? asyncImplementation)
            : base(signature, PythonCallableKind.Builtin, implementation, asyncImplementation)
        { }

        private readonly Func<BoundCallArguments, LythonSourceSpan, ExecutionContext, ValueTask<object>>? _presence;
        private readonly Func<BoundCallArguments, LythonSourceSpan, ExecutionContext, object>? _syncPresence;
        private BuiltinCallable(LythonCallableSignature signature,
            Func<BoundCallArguments, LythonSourceSpan, ExecutionContext, object> sync,
            Func<BoundCallArguments, LythonSourceSpan, ExecutionContext, ValueTask<object>> async)
            : this(signature, static (object[] _, LythonSourceSpan __, ExecutionContext ___) => throw new InvalidOperationException("Missing argument presence"), null)
        { _presence = async; _syncPresence = sync; }
        protected override bool PreservePresence => _presence is not null;
        protected override object InvokeBoundWithPresence(BoundCallArguments arguments, LythonSourceSpan span, ExecutionContext context)
            => _syncPresence!(arguments, span, context);
        protected override ValueTask<object> InvokeBoundWithPresenceAsync(BoundCallArguments arguments, LythonSourceSpan span, ExecutionContext context)
            => _presence!(arguments, span, context);
        public static BuiltinCallable CreateWithPresence(LythonCallableSignature signature,
            Func<BoundCallArguments, LythonSourceSpan, ExecutionContext, object> sync,
            Func<BoundCallArguments, LythonSourceSpan, ExecutionContext, ValueTask<object>> async)
            => new(signature, sync, async);

        public static BuiltinCallable Create(LythonCallableSignature signature, Func<object[], LythonSourceSpan, ExecutionContext, object> implementation)
            => new(signature, implementation, null);

        public static BuiltinCallable Create(
            LythonCallableSignature signature,
            Func<object[], LythonSourceSpan, ExecutionContext, object> implementation,
            Func<object[], LythonSourceSpan, ExecutionContext, ValueTask<object>> asyncImplementation)
            => new(signature, implementation, asyncImplementation);

        public static BuiltinCallable Create(string name, Func<object[], LythonSourceSpan, ExecutionContext, object> implementation)
            => Create(LythonCallableSignature.Create(name), implementation);

        public static BuiltinCallable Create(string name, Func<object[], LythonSourceSpan, ExecutionContext, object> implementation, string[] parameterNames)
            => Create(LythonCallableSignature.Create(name, parameterNames), implementation);

        public static BuiltinCallable Create(
            string name,
            Func<object[], LythonSourceSpan, ExecutionContext, object> implementation,
            string[] parameterNames,
            int requiredCount)
            => Create(LythonCallableSignature.Create(name, parameterNames, requiredCount), implementation);

        public static BuiltinCallable Create(string name, Func<object[], LythonSourceSpan, ExecutionContext, object> implementation, Func<object[], LythonSourceSpan, ExecutionContext, ValueTask<object>> asyncImplementation)
            => Create(LythonCallableSignature.Create(name), implementation, asyncImplementation);

        public static BuiltinCallable Create(string name, Func<object[], LythonSourceSpan, ExecutionContext, object> implementation, Func<object[], LythonSourceSpan, ExecutionContext, ValueTask<object>> asyncImplementation, string[] parameterNames)
            => Create(LythonCallableSignature.Create(name, parameterNames), implementation, asyncImplementation);

        public static BuiltinCallable Create(
            string name,
            Func<object[], LythonSourceSpan, ExecutionContext, object> implementation,
            Func<object[], LythonSourceSpan, ExecutionContext, ValueTask<object>> asyncImplementation,
            string[] parameterNames,
            int requiredCount)
            => Create(LythonCallableSignature.Create(name, parameterNames, requiredCount), implementation, asyncImplementation);

        public static BuiltinCallable CreateUnsupported(string qualifiedName)
            => Create(
                qualifiedName,
                (_, span, _) => throw new LythonRuntimeException(
                    "NotImplementedError",
                    qualifiedName + " is unsupported by Lython.",
                    span));

        public string Name => Signature.Name;

        public PyString RenderPython(PyRenderingContext context)
        {
            _ = context;
            // Type constructors render like CPython type objects; plain
            // builtins render like CPython builtin functions under their
            // short name.
            return PyString.FromString(BuiltinTypeBaseNames.ContainsKey(Name) ? $"<class '{Name}'>" : $"<built-in function {ShortCallableName(Name)}>");
        }

        public PyString RenderInterpolated(PyRenderingContext context) => RenderPython(context);

        public int GetPyHashCode() => RuntimeHelpers.GetHashCode(this);

        private OwnedTypeHierarchy? _hierarchy;

        internal TypeNewMethod? NewSlot { get; set; }

        private Dictionary<string, UnboundTypeMethod>? _unboundMethods;
        private Dictionary<string, BuiltinDataDescriptor>? _unboundDataDescriptors;

        public bool TryGetMember(string name, ExecutionContext context, LythonSourceSpan span, [MaybeNullWhen(false)] out object value)
        {
            if ((name == "__bases__" || name == "__mro__") &&
                TryGetOwnedHierarchy(Signature.Name, this, context, span, ref _hierarchy, out var hierarchy))
            {
                value = name == "__mro__" ? hierarchy.Mro : hierarchy.Bases;
                return true;
            }

            // Table members are type constructors even where the legacy gate does
            // not cover them (range, slice, decimal.Decimal); they report the shared
            // builtins or module label like CPython.
            if (name == "__self__" && !BuiltinTypeBaseNames.ContainsKey(Signature.Name) &&
                TryGetCallableModule(Signature.Name, context, out var selfModule))
            {
                value = selfModule;
                return true;
            }

            if (name == "__module__" && BuiltinTypeBaseNames.ContainsKey(Signature.Name))
            {
                value = ExceptionTypeValue.SharedModuleLabel(CallableModuleName(Signature.Name));
                return true;
            }

            // Builtin constructors expose classmethods (dict.fromkeys,
            // bytes.fromhex) and staticmethods (str.maketrans) like CPython
            // through one shared choke. It runs before the unbound
            // descriptors because the instance tables serve both shapes.
            if (TryGetBuiltinTypeMethod(this, Signature.Name, name, out value))
            {
                return true;
            }

            // Type constructors expose their instance methods as unbound
            // descriptors like CPython (list.append takes its receiver as
            // the first argument); wrappers cache per constructor.
            if (BuiltinTypeBaseNames.ContainsKey(Signature.Name) &&
                TryGetUnboundTypeMethod(this, Signature.Name, ref _unboundMethods, name, out value))
            {
                return true;
            }

            // Builtin numeric types expose their scalar data attributes as
            // getset descriptors like CPython (int.real binds through the
            // shared data slots); wrappers cache per constructor.
            if ((Signature.Name is "int" or "float" or "range") &&
                TryGetUnboundDataDescriptor(this, Signature.Name, ref _unboundDataDescriptors, name, out value))
            {
                return true;
            }

            // bool shares int's method surface like CPython
            // (bool.bit_length is int.bit_length): own dunders resolved
            // above and bool.from_bytes in the choke above, so whatever
            // remains delegates to the int constructor's cache.
            if (Signature.Name == "bool" &&
                !TryGetMember(name, out value) &&
                context.TryGetBuiltin("int", out var intType) &&
                intType is BuiltinCallable intCallable &&
                intCallable.TryGetMember(name, context, span, out value))
            {
                return true;
            }

            return TryGetMember(name, out value);
        }

        public bool TryGetMember(string name, [MaybeNullWhen(false)] out object value)
        {
            // Every builtin callable exposes CPython-style __name__/__module__:
            // the short name and the dotted module part (shared builtins for
            // top-level names). __name__ stays fresh per read like CPython;
            // __module__ reuses the shared label catalog where it hits.
            if (name is "__name__" or "__qualname__")
            {
                value = PyString.FromString(ShortCallableName(Name));
                return true;
            }

            if (name == "__module__")
            {
                value = ExceptionTypeValue.SharedModuleLabel(CallableModuleName(Name));
                return true;
            }

            if (name == "__new__" && LythonRuntime.TryGetTypeNewSlot(this, out value))
            {
                return true;
            }

            value = PyNone.Instance;
            return false;
        }

        internal static string ShortCallableName(string name)
        {
            var dot = name.LastIndexOf('.');
            return dot < 0 ? name : name.Substring(dot + 1);
        }

        private static string CallableModuleName(string name)
        {
            var dot = name.LastIndexOf('.');
            return dot < 0 ? "builtins" : name.Substring(0, dot);
        }
    }

    private sealed class BoundCallable : BoundArgumentsCallable, IPyDynamicAttributes, IPyRenderableValue, IPyBoundEngineMethod, IPyHashableValue
    {
        public int GetPyHashCode() => HashCode.Combine(RuntimeHelpers.GetHashCode(_receiver), StringComparer.Ordinal.GetHashCode(ShortMethodName(Signature.Name)));

        // The receiver threads in at member-resolution time (see
        // TryResolveRuntimeMember), since every instance is fresh per
        // access and closures alone cannot report it.
        private object? _receiver;

        internal void AttachReceiver(object receiver) => _receiver = receiver;

        // Bound engine methods render like CPython built-in methods minus the
        // address suffix; decorated display names keep the legacy shape.
        public PyString RenderPython(PyRenderingContext context)
            => PyString.FromString(
                UnboundTypeMethod.IsPlainBoundMethodName(Signature.Name)
                    ? UnboundTypeMethod.BoundEngineMethodDisplay(ShortMethodName(Signature.Name), _receiver, context.Context)
                    : "<object>");

        public PyString RenderInterpolated(PyRenderingContext context) => RenderPython(context);

        // Bound engine methods expose CPython-style __name__/__module__ like
        // C-implemented methods: the short decorated name and None, since every
        // wrapper is engine-implemented (CPython reports the class module only
        // for Python-implemented methods such as Random.gauss).
        public bool TryGetMember(string name, [MaybeNullWhen(false)] out object value)
        {
            if (name == "__self__" && _receiver is not null)
            {
                value = _receiver;
                return true;
            }

            if (name == "__name__")
            {
                value = PyString.FromString(ShortMethodName(Signature.Name));
                return true;
            }

            // __qualname__ keeps the full dotted path like CPython bound
            // methods (list.append), falling back to the short name for
            // decorated display names (gzip file.read([size]) -> read).
            if (name == "__qualname__")
            {
                value = PyString.FromString(QualMethodName(Signature.Name));
                return true;
            }

            if (name == "__module__")
            {
                value = PyNone.Instance;
                return true;
            }

            value = PyNone.Instance;
            return false;
        }

        private static string ShortMethodName(string name)
        {
            var dot = name.LastIndexOf('.');
            var tail = dot < 0 ? name : name.Substring(dot + 1);
            var cut = tail.IndexOfAny([' ', '(', '[']);
            return cut < 0 ? tail : tail.Substring(0, cut);
        }

        private static string QualMethodName(string name)
        {
            var cut = name.IndexOfAny([' ', '(', '[']);
            return cut < 0 ? name : ShortMethodName(name);
        }

        private BoundCallable(
            Func<object[], LythonSourceSpan, ExecutionContext, object> implementation,
            LythonCallableSignature signature,
            Func<object[], LythonSourceSpan, ExecutionContext, ValueTask<object>>? asyncImplementation)
            : base(signature, PythonCallableKind.Method)
        {
            _implementation = implementation;
            _asyncImplementation = asyncImplementation;
        }

        private readonly object? _implementation;
        private readonly Func<object[], LythonSourceSpan, ExecutionContext, ValueTask<object>>? _asyncImplementation;

        private BoundCallable(object receiver, ReceiverMethod method)
            : base(method.Signature, PythonCallableKind.Method)
        {
            _receiver = receiver;
            _implementation = method;
        }

        internal static BoundCallable Create(object receiver, ReceiverMethod method) => new(receiver, method);

        protected override object InvokeBound(object[] arguments, LythonSourceSpan span, ExecutionContext context)
            => _implementation is ReceiverMethod method ? method.Invoke(_receiver!, arguments, span, context)
                : ((Func<object[], LythonSourceSpan, ExecutionContext, object>)_implementation!)(arguments, span, context);

        protected override ValueTask<object> InvokeBoundAsync(object[] arguments, LythonSourceSpan span, ExecutionContext context)
            => _implementation is ReceiverMethod method ? method.InvokeAsync(_receiver!, arguments, span, context)
                : _asyncImplementation is null ? new(InvokeBound(arguments, span, context))
                : _asyncImplementation(arguments, span, context);

        private readonly Func<BoundCallArguments, LythonSourceSpan, ExecutionContext, object>? _presenceImplementation;
        private readonly Func<BoundCallArguments, LythonSourceSpan, ExecutionContext, ValueTask<object>>? _asyncPresenceImplementation;

        private BoundCallable(
            Func<BoundCallArguments, LythonSourceSpan, ExecutionContext, object> implementation,
            LythonCallableSignature signature,
            Func<BoundCallArguments, LythonSourceSpan, ExecutionContext, ValueTask<object>>? asyncImplementation = null)
            : base(signature, PythonCallableKind.Method)
        {
            _presenceImplementation = implementation;
            _asyncPresenceImplementation = asyncImplementation;
        }

        protected override bool PreservePresence => _presenceImplementation is not null;

        protected override object InvokeBoundWithPresence(BoundCallArguments bound, LythonSourceSpan span, ExecutionContext context)
            => _presenceImplementation!(bound, span, context);

        protected override ValueTask<object> InvokeBoundWithPresenceAsync(BoundCallArguments bound, LythonSourceSpan span, ExecutionContext context)
            => _asyncPresenceImplementation is null ? new(InvokeBoundWithPresence(bound, span, context))
                : _asyncPresenceImplementation(bound, span, context);

        public static BoundCallable CreateWithPresence(
            Func<BoundCallArguments, LythonSourceSpan, ExecutionContext, object> implementation,
            LythonCallableSignature signature,
            Func<BoundCallArguments, LythonSourceSpan, ExecutionContext, ValueTask<object>> asyncImplementation)
            => new(implementation, signature, asyncImplementation);

        public static BoundCallable Create(Func<object[], LythonSourceSpan, ExecutionContext, object> implementation, LythonCallableSignature signature)
            => new(implementation, signature, null);

        public static BoundCallable Create(
            Func<object[], LythonSourceSpan, ExecutionContext, object> implementation,
            LythonCallableSignature signature,
            Func<object[], LythonSourceSpan, ExecutionContext, ValueTask<object>> asyncImplementation)
            => new(implementation, signature, asyncImplementation);

        public static BoundCallable Create(Func<object[], LythonSourceSpan, ExecutionContext, object> implementation)
            => Create(implementation, LythonCallableSignature.Create("bound method"));

        public static BoundCallable Create(Func<object[], LythonSourceSpan, ExecutionContext, object> implementation, string name)
            => Create(implementation, LythonCallableSignature.Create(name));

        public static BoundCallable Create(Func<object[], LythonSourceSpan, ExecutionContext, object> implementation, string name, string[] parameterNames)
            => Create(implementation, LythonCallableSignature.Create(name, parameterNames));

        public static BoundCallable Create(
            Func<object[], LythonSourceSpan, ExecutionContext, object> implementation,
            string name,
            string[] parameterNames,
            int requiredCount)
            => Create(implementation, LythonCallableSignature.Create(name, parameterNames, requiredCount));

        public static BoundCallable CreateWithPresence(
            Func<BoundCallArguments, LythonSourceSpan, ExecutionContext, object> implementation,
            string name,
            string[] parameterNames,
            int requiredCount)
            => new(implementation, LythonCallableSignature.Create(name, parameterNames, requiredCount));

        public static BoundCallable CreateWithPresence(
            Func<BoundCallArguments, LythonSourceSpan, ExecutionContext, object> implementation,
            LythonCallableSignature signature)
            => new(implementation, signature);

        public static BoundCallable Create(Func<object[], LythonSourceSpan, ExecutionContext, object> implementation, Func<object[], LythonSourceSpan, ExecutionContext, ValueTask<object>> asyncImplementation)
            => Create(implementation, LythonCallableSignature.Create("bound method"), asyncImplementation);

        public static BoundCallable Create(Func<object[], LythonSourceSpan, ExecutionContext, object> implementation, Func<object[], LythonSourceSpan, ExecutionContext, ValueTask<object>> asyncImplementation, string name)
            => Create(implementation, LythonCallableSignature.Create(name), asyncImplementation);

        public static BoundCallable Create(Func<object[], LythonSourceSpan, ExecutionContext, object> implementation, Func<object[], LythonSourceSpan, ExecutionContext, ValueTask<object>> asyncImplementation, string name, string[] parameterNames)
            => Create(implementation, LythonCallableSignature.Create(name, parameterNames), asyncImplementation);

        public static BoundCallable Create(
            Func<object[], LythonSourceSpan, ExecutionContext, object> implementation,
            Func<object[], LythonSourceSpan, ExecutionContext, ValueTask<object>> asyncImplementation,
            string name,
            string[] parameterNames,
            int requiredCount)
            => Create(implementation, LythonCallableSignature.Create(name, parameterNames, requiredCount), asyncImplementation);

        public static ICallable CreateNoArguments<TReceiver>(
            TReceiver receiver,
            string name,
            Func<TReceiver, LythonSourceSpan, ExecutionContext, object> implementation)
            => NoArgumentsReceiverBoundCallable<TReceiver>.Create(receiver, name, implementation, null);

        public static ICallable CreateNoArguments<TReceiver>(
            TReceiver receiver,
            string name,
            Func<TReceiver, LythonSourceSpan, ExecutionContext, object> implementation,
            Func<TReceiver, LythonSourceSpan, ExecutionContext, ValueTask<object>> asyncImplementation)
            => NoArgumentsReceiverBoundCallable<TReceiver>.Create(receiver, name, implementation, asyncImplementation);

    }

    private sealed class NoArgumentsReceiverBoundCallable<TReceiver> : ICallable, IPyDynamicAttributes, IPyRenderableValue, IPyBoundEngineMethod, IPyHashableValue
    {
        public int GetPyHashCode() => HashCode.Combine(RuntimeHelpers.GetHashCode(_receiver), StringComparer.Ordinal.GetHashCode(ShortMethodName(Name)));

        // Bound engine methods expose CPython-style __name__/__module__ like
        // C-implemented methods: the short decorated name and None, since every
        // wrapper is engine-implemented (CPython reports the class module only
        // for Python-implemented methods such as Random.gauss).
        public bool TryGetMember(string name, [MaybeNullWhen(false)] out object value)
        {
            if (name == "__self__")
            {
                value = _receiver!;
                return true;
            }

            if (name == "__class__")
            {
                value = PyType.BuiltinFunctionType;
                return true;
            }

            if (name == "__name__")
            {
                value = PyString.FromString(ShortMethodName(Name));
                return true;
            }

            // __qualname__ keeps the full dotted path like CPython bound
            // methods (list.append), falling back to the short name for
            // decorated display names (gzip file.read([size]) -> read).
            if (name == "__qualname__")
            {
                value = PyString.FromString(QualMethodName(Name));
                return true;
            }

            if (name == "__module__")
            {
                value = PyNone.Instance;
                return true;
            }

            value = PyNone.Instance;
            return false;
        }

        private static string ShortMethodName(string name)
        {
            var dot = name.LastIndexOf('.');
            var tail = dot < 0 ? name : name.Substring(dot + 1);
            var cut = tail.IndexOfAny([' ', '(', '[']);
            return cut < 0 ? tail : tail.Substring(0, cut);
        }

        private static string QualMethodName(string name)
        {
            var cut = name.IndexOfAny([' ', '(', '[']);
            return cut < 0 ? name : ShortMethodName(name);
        }

        private readonly Func<TReceiver, LythonSourceSpan, ExecutionContext, object> _implementation;
        private readonly Func<TReceiver, LythonSourceSpan, ExecutionContext, ValueTask<object>>? _asyncImplementation;
        private readonly TReceiver _receiver;

        private NoArgumentsReceiverBoundCallable(
            TReceiver receiver,
            string name,
            Func<TReceiver, LythonSourceSpan, ExecutionContext, object> implementation,
            Func<TReceiver, LythonSourceSpan, ExecutionContext, ValueTask<object>>? asyncImplementation)
        {
            Name = name;
            _receiver = receiver;
            _implementation = implementation;
            _asyncImplementation = asyncImplementation;
        }

        public static NoArgumentsReceiverBoundCallable<TReceiver> Create(
            TReceiver receiver,
            string name,
            Func<TReceiver, LythonSourceSpan, ExecutionContext, object> implementation,
            Func<TReceiver, LythonSourceSpan, ExecutionContext, ValueTask<object>>? asyncImplementation)
            => new(receiver, name, implementation, asyncImplementation);

        private string Name { get; }

        // Bound engine methods render like CPython built-in methods minus the
        // address suffix; decorated display names keep the legacy shape.
        public PyString RenderPython(PyRenderingContext context)
            => PyString.FromString(
                UnboundTypeMethod.IsPlainBoundMethodName(Name)
                    ? UnboundTypeMethod.BoundEngineMethodDisplay(ShortMethodName(Name), _receiver, context.Context)
                    : "<object>");

        public PyString RenderInterpolated(PyRenderingContext context) => RenderPython(context);

        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            context.CheckExecution(span);
            RejectArguments(arguments, span);
            var result = _implementation(_receiver, span, context);
            return result;
        }

        public ValueTask<object> InvokeAsync(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            context.CheckExecution(span);
            RejectArguments(arguments, span);
            if (_asyncImplementation is null)
            {
                var immediate = _implementation(_receiver, span, context);
                return ValueTask.FromResult(immediate);
            }

            return InvokeAsyncCore();

            async ValueTask<object> InvokeAsyncCore()
            {
                var result = await _asyncImplementation!(_receiver, span, context).ConfigureAwait(false);
                return result;
            }
        }

        private void RejectArguments(CallArgumentValue[] arguments, LythonSourceSpan span)
        {
            // Validate the raw call here to preserve each method's Python-shaped
            // error text and avoid materializing a bound empty argument array.
            if (arguments.Length != 0)
            {
                throw new LythonRuntimeException("TypeError", $"{Name}() expects no arguments.", span);
            }
        }
    }

    private sealed class MinMaxCallable(ExtremumOperation operation) : ICallable, INamedRuntimeCallable, IPyRenderableValue, IPyHashableValue, IPyDynamicAttributes, IPyContextualDynamicAttributes
    {
        public string Name => operation == ExtremumOperation.Minimum ? "min" : "max";

        public bool TryGetMember(string name, ExecutionContext context, LythonSourceSpan span, [MaybeNullWhen(false)] out object value)
        {
            if (name == "__self__" && TryGetCallableModule(Name, context, out var module))
            {
                value = module;
                return true;
            }

            return TryGetMember(name, out value);
        }
        // Singleton builtins expose CPython-style __name__/__module__ like
        // BuiltinCallable: the fixed name and the shared builtins label.
        public bool TryGetMember(string name, [MaybeNullWhen(false)] out object value)
        {
            if (name is "__name__" or "__qualname__")
            {
                value = PyString.FromString(Name);
                return true;
            }

            if (name == "__module__")
            {
                value = ExceptionTypeValue.SharedModuleLabel("builtins");
                return true;
            }

            value = PyNone.Instance;
            return false;
        }

        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            context.CheckExecution(span);
            return MinMax(arguments, operation, span, context);
        }

        public ValueTask<object> InvokeAsync(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            context.CheckExecution(span);
            return MinMaxAsync(arguments, operation, span, context);
        }

        public PyString RenderPython(PyRenderingContext context) => PyString.FromString($"<built-in function {Name}>");

        public PyString RenderInterpolated(PyRenderingContext context) => RenderPython(context);

        public int GetPyHashCode() => RuntimeHelpers.GetHashCode(this);

    }

    private sealed class ZipCallable : ICallable, INamedRuntimeCallable, IPyRenderableValue, IPyHashableValue, IPyDynamicAttributes, IPyContextualDynamicAttributes
    {
        public string Name => "zip";

        private OwnedTypeHierarchy? _hierarchy;

        internal TypeNewMethod? NewSlot { get; set; }

        public bool TryGetMember(string name, ExecutionContext context, LythonSourceSpan span, [MaybeNullWhen(false)] out object value)
        {
            if ((name == "__bases__" || name == "__mro__") &&
                TryGetOwnedHierarchy("zip", this, context, span, ref _hierarchy, out var hierarchy))
            {
                value = name == "__mro__" ? hierarchy.Mro : hierarchy.Bases;
                return true;
            }

            return TryGetMember(name, out value);
        }

        // Singleton builtins expose CPython-style __name__/__module__ like
        // BuiltinCallable: the fixed name and the shared builtins label.
        public bool TryGetMember(string name, [MaybeNullWhen(false)] out object value)
        {
            if (name is "__name__" or "__qualname__")
            {
                value = PyString.FromString(Name);
                return true;
            }

            if (name == "__module__")
            {
                value = ExceptionTypeValue.SharedModuleLabel("builtins");
                return true;
            }

            if (name == "__new__" && LythonRuntime.TryGetTypeNewSlot(this, out value))
            {
                return true;
            }

            value = PyNone.Instance;
            return false;
        }

        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            context.CheckExecution(span);
            return Zip(arguments, span, context);
        }

        public PyString RenderPython(PyRenderingContext context) => PyString.FromString($"<class '{Name}'>");
        public PyString RenderInterpolated(PyRenderingContext context) => RenderPython(context);
        public int GetPyHashCode() => RuntimeHelpers.GetHashCode(this);
    }

    private sealed class DictCallable : ICallable, INamedRuntimeCallable, IPyRenderableValue, IPyHashableValue, IPyDynamicAttributes, IPyContextualDynamicAttributes
    {
        public string Name => "dict";

        private OwnedTypeHierarchy? _hierarchy;

        internal TypeNewMethod? NewSlot { get; set; }

        private Dictionary<string, UnboundTypeMethod>? _unboundMethods;

        public bool TryGetMember(string name, ExecutionContext context, LythonSourceSpan span, [MaybeNullWhen(false)] out object value)
        {
            if ((name == "__bases__" || name == "__mro__") &&
                TryGetOwnedHierarchy("dict", this, context, span, ref _hierarchy, out var hierarchy))
            {
                value = name == "__mro__" ? hierarchy.Mro : hierarchy.Bases;
                return true;
            }

            // dict.fromkeys rides the shared classmethod choke like the
            // builtin constructors above. It runs before the unbound
            // descriptors because the instance table serves both shapes.
            if (TryGetBuiltinTypeMethod(this, Name, name, out value))
            {
                return true;
            }

            // The dict constructor exposes its instance methods as unbound
            // descriptors like CPython, sharing the builtin choke and cache.
            if (TryGetUnboundTypeMethod(this, Name, ref _unboundMethods, name, out value))
            {
                return true;
            }

            return TryGetMember(name, out value);
        }

        // Singleton builtins expose CPython-style __name__/__module__ like
        // BuiltinCallable: the fixed name and the shared builtins label.
        public bool TryGetMember(string name, [MaybeNullWhen(false)] out object value)
        {
            if (name is "__name__" or "__qualname__")
            {
                value = PyString.FromString(Name);
                return true;
            }

            if (name == "__module__")
            {
                value = ExceptionTypeValue.SharedModuleLabel("builtins");
                return true;
            }

            if (name == "__new__" && LythonRuntime.TryGetTypeNewSlot(this, out value))
            {
                return true;
            }

            value = PyNone.Instance;
            return false;
        }

        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            context.CheckExecution(span);
            var result = (PyDict)Dict(arguments, span, context);
            return result;
        }

        public async ValueTask<object> InvokeAsync(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            context.CheckExecution(span);
            var result = (PyDict)await DictAsync(arguments, span, context).ConfigureAwait(false);
            return result;
        }

        public PyString RenderPython(PyRenderingContext context) => PyString.FromString($"<class '{Name}'>");
        public PyString RenderInterpolated(PyRenderingContext context) => RenderPython(context);
        public int GetPyHashCode() => RuntimeHelpers.GetHashCode(this);
    }

    private sealed class OpenCallable : ICallable, INamedRuntimeCallable, IPyRenderableValue, IPyHashableValue, IPyDynamicAttributes, IPyContextualDynamicAttributes
    {
        private static readonly LythonCallableSignature CallSignature = LythonCallableSignature.Create(
            "open",
            ["file", "mode", "buffering", "encoding", "errors", "newline", "closefd", "opener"],
            requiredCount: 1);

        public string Name => "open";

        public bool TryGetMember(string name, ExecutionContext context, LythonSourceSpan span, [MaybeNullWhen(false)] out object value)
        {
            if (name == "__self__" && TryGetCallableModule(Name, context, out var module))
            {
                value = module;
                return true;
            }

            return TryGetMember(name, out value);
        }
        // Singleton builtins expose CPython-style __name__/__module__ like
        // BuiltinCallable: the fixed name and the shared builtins label.
        public bool TryGetMember(string name, [MaybeNullWhen(false)] out object value)
        {
            if (name is "__name__" or "__qualname__")
            {
                value = PyString.FromString(Name);
                return true;
            }

            if (name == "__module__")
            {
                value = ExceptionTypeValue.SharedModuleLabel("builtins");
                return true;
            }

            value = PyNone.Instance;
            return false;
        }

        public PyString RenderPython(PyRenderingContext context)
        {
            _ = context;
            return PyString.FromString($"<built-in function {Name}>");
        }

        public PyString RenderInterpolated(PyRenderingContext context) => RenderPython(context);

        public int GetPyHashCode() => RuntimeHelpers.GetHashCode(this);

        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            context.CheckExecution(span);
            return Open(BindArguments(arguments, span), span, context);
        }

        public async ValueTask<object> InvokeAsync(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            context.CheckExecution(span);
            return await OpenAsync(BindArguments(arguments, span), span, context).ConfigureAwait(false);
        }

        private static BoundOpenArguments BindArguments(CallArgumentValue[] arguments, LythonSourceSpan span)
            => BoundOpenArguments.From(CallBinder.BindNamedArgumentsWithPresence(arguments, span, CallSignature, PythonCallableKind.Builtin));
    }

}
