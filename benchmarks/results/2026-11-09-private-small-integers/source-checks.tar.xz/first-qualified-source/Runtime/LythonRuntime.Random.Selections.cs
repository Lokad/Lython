using System.Numerics;
using System.Runtime.CompilerServices;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Numbers;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed partial class LythonRuntime
{
    internal sealed partial class RandomModule : PyModule
    {
        private static object CreateRandom(CallArgumentValue[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            var bound = CallBinder.BindNamedArguments(arguments, span, LythonKnownCallableSignatures.RandomClass, PythonCallableKind.Builtin);
            var state = new PyRandomState();
            if (bound.Length >= 1 && bound[0] is not PyNone)
            {
                state.Seed(ParseSeed(bound[0], context, span));
            }

            context.MemoryGovernor.Reserve(64L, span);
            context.MemoryGovernor.Commit(64L);
            var random = new PyRandom(state);
            return random;
        }

        private static object UnsupportedSystemRandom(object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            _ = arguments;
            _ = context;
            throw new LythonRuntimeException("NotImplementedError", "random.SystemRandom is unsupported by Lython because system entropy is not exposed.", span);
        }

        private static object Seed(PyRandomState state, object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            if (arguments.Length > 2)
            {
                throw new LythonRuntimeException("TypeError", "random.seed(a=None, version=2) expects zero to two arguments.", span);
            }

            if (arguments.Length >= 2 && arguments[1] is not PyNone)
            {
                var version = ExpectInteger(arguments[1], "random.seed(..., version=...) expects version 1 or 2.", span);
                if (version != BigInteger.One && version != new BigInteger(2))
                {
                    throw new LythonRuntimeException("ValueError", "random.seed(..., version=...) expects version 1 or 2.", span);
                }
            }

            state.Seed(ParseSeed(arguments.Length == 0 || arguments[0] is PyNone ? PyNone.Instance : arguments[0], context, span));
            return PyNone.Instance;
        }

        private static object Random(PyRandomState state, object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            _ = context;
            if (arguments.Length != 0)
            {
                throw new LythonRuntimeException("TypeError", "random.random() expects no arguments.", span);
            }

            return state.NextDouble();
        }

        private static object GetState(PyRandomState state, object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            if (arguments.Length != 0)
            {
                throw new LythonRuntimeException("TypeError", "random.getstate() expects no arguments.", span);
            }

            return new PyTuple(
                [
                    SharedStateTag,
                    new BigInteger(state.Snapshot())
                ],
                context.MemoryGovernor,
                span);
        }

        private static object SetState(PyRandomState state, object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            if (arguments.Length != 1)
            {
                throw new LythonRuntimeException("TypeError", "random.setstate(state) expects one state object.", span);
            }

            state.Restore(ParseState(arguments[0], span, context));
            return PyNone.Instance;
        }

        private static object RandRange(PyRandomState state, object[] arguments, LythonSourceSpan span, ExecutionContext context)
            => RandRangeCoreAsync(state, arguments, span, context, false).GetAwaiter().GetResult();

        private static ValueTask<object> RandRangeAsync(PyRandomState state, object[] arguments, LythonSourceSpan span, ExecutionContext context)
            => RandRangeCoreAsync(state, arguments, span, context, true);

        private static async ValueTask<object> RandRangeCoreAsync(PyRandomState state, object[] arguments, LythonSourceSpan span, ExecutionContext context, bool asynchronous)
        {
            var start = asynchronous ? await CoerceRandomIndexAsync(arguments[0], context, span).ConfigureAwait(false)
                : CoerceRandomIndex(arguments[0], context, span);
            var singleBound = arguments.Length < 2 || arguments[1] is PyNone;
            // CPython accepts stop=None, but an explicit non-default step fails
            // before invoking that step's index protocol.
            if (singleBound && arguments.Length == 3 && arguments[2] is not (BigInteger { IsOne: true } or int and 1))
                throw new LythonRuntimeException("TypeError", "Missing a non-None stop argument", span);
            var stop = singleBound ? start : asynchronous
                ? await CoerceRandomIndexAsync(arguments[1], context, span).ConfigureAwait(false)
                : CoerceRandomIndex(arguments[1], context, span);
            if (singleBound) start = BigInteger.Zero;
            var step = arguments.Length < 3 ? BigInteger.One : asynchronous
                ? await CoerceRandomIndexAsync(arguments[2], context, span).ConfigureAwait(false)
                : CoerceRandomIndex(arguments[2], context, span);
            return await DrawRangeAsync(state, start, stop, step, arguments, singleBound, context, span, asynchronous).ConfigureAwait(false);
        }

        private static object RandInt(PyRandomState state, object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            var start = CoerceRandomIndex(arguments[0], context, span);
            var last = CoerceRandomIndex(arguments[1], context, span);
            using var addition = GuardIntegerAddition(last, BigInteger.One, context.MemoryGovernor, span);
            var stop = last + BigInteger.One;
            return DrawRangeAsync(state, start, stop, BigInteger.One, [start, stop], false, context, span, false).GetAwaiter().GetResult();
        }

        private static async ValueTask<object> DrawRangeAsync(PyRandomState state, BigInteger start, BigInteger stop, BigInteger step,
            object[] original, bool singleBound, ExecutionContext context, LythonSourceSpan span, bool asynchronous)
        {
            // Division, rejection candidates and final arithmetic coexist. Hold
            // conservative major-magnitude scratch before doing any of them.
            var bits = Math.Max(start.GetBitLength(), Math.Max(stop.GetBitLength(), step.GetBitLength()));
            using var storage = context.MemoryGovernor.ReserveTemporary(bits <= 63 ? 0 :
                RuntimeMemoryEstimates.SaturatingMultiply(16, RuntimeMemoryEstimates.EstimateBigIntegerBytesFromBitCount(bits + 2)), span);
            context.CheckExecution(span);
            if (step.IsZero) throw new LythonRuntimeException("ValueError", "zero step for randrange()", span);
            var count = step.Sign > 0 ? stop <= start ? BigInteger.Zero : ((stop - start - 1) / step) + 1
                : stop >= start ? BigInteger.Zero : ((start - stop - 1) / BigInteger.Abs(step)) + 1;
            if (count.IsZero)
            {
                if (singleBound) throw new LythonRuntimeException("ValueError", "empty range for randrange()", span);
                var builder = new GovernedByteBuilder(context.MemoryGovernor, span);
                try
                {
                    builder.AppendAscii("empty range in randrange(");
                    var fields = step.IsOne ? 2 : 3;
                    for (var i = 0; i < fields; i++)
                    {
                        if (i != 0) builder.AppendAscii(", ");
                        builder.Append(asynchronous ? await PyRendering.ToInterpolatedPyStringAsync(original[i], new PyRenderingContext(context)).ConfigureAwait(false)
                            : PyRendering.ToInterpolatedPyString(original[i], new PyRenderingContext(context)));
                    }
                    builder.AppendAscii(")");
                    var rendered = builder.ToPyStringAndRelease();
                    using var messageStorage = context.MemoryGovernor.ReserveTemporary(checked(32L + 2L * rendered.ByteLength), span);
                    var message = rendered.AsString();
                    messageStorage.Commit(checked(32L + 2L * message.Length));
                    throw new LythonRuntimeException("ValueError", message, span);
                }
                finally { builder.Release(); }
            }
            var offset = DrawBelow(state, count, context, span);
            return OwnFreshInteger(start + offset * step, context.MemoryGovernor, span, storage);
        }

        // Preserve the established small-domain draw sequence; wider domains
        // use the already-admitted bit generator and discard candidates in-place.
        private static BigInteger DrawBelow(PyRandomState state, BigInteger upper, ExecutionContext context, LythonSourceSpan span)
        {
            if (upper <= ulong.MaxValue) return state.NextBelow((ulong)upper, context, span);
            var bits = upper.GetBitLength();
            BigInteger value;
            do
            {
                context.CheckExecution(span);
                value = state.GetRandBits(bits, context, span);
            } while (value >= upper);
            return value;
        }

        private static object Choice(PyRandomState state, object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            if (arguments.Length != 1)
            {
                throw new LythonRuntimeException("TypeError", "random.choice(seq) expects one sequence argument.", span);
            }

            var population = GetPopulation(arguments[0], "random.choice", span, context);
            if (population.Length == 0)
                throw new LythonRuntimeException("IndexError", "Cannot choose from an empty sequence", span);
            return RuntimeValue(population.GetAt((long)state.NextBelow((ulong)population.Length, context, span)));
        }

        private static object Choices(PyRandomState state, object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            if (arguments.Length is < 1 or > 4)
            {
                throw new LythonRuntimeException("TypeError", "random.choices(population[, weights][, cum_weights][, k]) expects one to four arguments.", span);
            }

            var population = GetPopulation(arguments[0], "random.choices", span, context);
            var populationLength = population.Length;
            using var weightScratch = context.MemoryGovernor.ReserveTemporary(0, span);

            // N07: converted weight copies are caller-scoped scratch; they
            // live for the selection and release on every exit path.
            var weights = arguments.Length >= 2 && arguments[1] is not PyNone ? ReadWeights(arguments[1], populationLength, "random.choices(..., weights=...)", span, context, weightScratch) : null;
            var cumulative = arguments.Length >= 3 && arguments[2] is not PyNone ? ReadCumulativeWeights(arguments[2], populationLength, "random.choices(..., cum_weights=...)", span, context, weightScratch) : null;
            if (weights is not null && cumulative is not null)
            {
                throw new LythonRuntimeException("TypeError", "random.choices(...) does not accept both weights and cum_weights.", span);
            }

            var rawCount = arguments.Length == 4 ? CoerceRandomIndex(arguments[3], context, span) : BigInteger.One;
            if (rawCount > Array.MaxLength)
            {
                throw new LythonRuntimeException("OverflowError", "random choices exceeds the supported result size", span);
            }

            // Like CPython (repeat yields empty), negative counts draw nothing.
            var count = rawCount < BigInteger.Zero ? 0 : (int)rawCount;
            var total = ValidateWeightTotal(weights, cumulative, context, span);
            if (populationLength == 0 && count > 0)
                throw new LythonRuntimeException("IndexError", "Cannot choose from an empty sequence", span);
            var result = new PyList([], context.MemoryGovernor, span);
            for (var i = 0; i < count; i++)
            {
                var pick = ChooseWeightedIndex(state, populationLength, weights, cumulative, total, context, span);
                result.Add(RuntimeValue(population.GetAt(pick)));
                context.CheckExecution(span);
            }

            return result;
        }

        private static object Shuffle(PyRandomState state, object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            if (arguments.Length != 1)
            {
                throw new LythonRuntimeException("TypeError", "random.shuffle(x) expects one mutable sequence argument.", span);
            }

            if (arguments[0] is not IMutablePyIndexableValue mutable)
            {
                throw new LythonRuntimeException("TypeError", "random.shuffle(x) expects a mutable sequence.", span);
            }

            for (var i = mutable.Length - 1; i > 0; i--)
            {
                if ((i & 1023) == 0) context.CheckExecution(span);
                var j = (int)state.NextBelow((ulong)(i + 1), context, span);
                var left = mutable.GetIndex(i);
                var right = mutable.GetIndex(j);
                mutable.SetIndex(i, right);
                mutable.SetIndex(j, left);
            }

            return PyNone.Instance;
        }

        private static object Sample(PyRandomState state, object[] arguments, LythonSourceSpan span, ExecutionContext context)
        {
            if (arguments.Length is < 2 or > 3)
            {
                throw new LythonRuntimeException("TypeError", "random.sample(population, k, *, counts=None) expects two arguments plus optional counts.", span);
            }

            var population = GetPopulation(arguments[0], "random.sample", span, context);
            var populationLength = population.Length;
            var rawCount = arguments[1] is int smallCount ? new BigInteger(smallCount) : arguments[1];
            // Like CPython, k flows through dispatched comparisons first and
            // the selection multiplies by k, so each failure keeps its own text.
            // With counts, k validates against the expanded total inside.
            if (!IsTruthy(EvaluateBinaryOperator(BinaryOperatorSyntax.LessEqual, BigInteger.Zero, rawCount, context, span), context, span))
            {
                throw new LythonRuntimeException("ValueError", "Sample larger than population or is negative", span);
            }

            if (arguments.Length >= 3 && arguments[2] is not PyNone)
            {
                return SampleCountedPositions(population.GetAt, populationLength, arguments[2], rawCount, state, span, context);
            }

            if (!IsTruthy(EvaluateBinaryOperator(BinaryOperatorSyntax.LessEqual, rawCount, new BigInteger(populationLength), context, span), context, span))
            {
                throw new LythonRuntimeException("ValueError", "Sample larger than population or is negative", span);
            }

            var count = CoerceSampleCount(rawCount, span);
            if ((long)count * 4 <= populationLength)
            {
                return SampleDirectPositions(state, population.GetAt, populationLength, count, context.MemoryGovernor, span, context);
            }

            using var populationScratch = context.MemoryGovernor.ReserveTemporary(0, span);
            var materialized = MaterializeSequence(arguments[0], span, context, populationScratch);
            ShuffleMaterialized(state, materialized, context, span);
            using var resultScratch = context.MemoryGovernor.ReserveTemporary(32L + 8L * count, span);
            var result = new object[count];
            for (var i = 0; i < count; i++)
            {
                result[i] = materialized[i];
            }

            return new PyList(result, context.MemoryGovernor, span);
        }

        // After the bound checks, k sizes like the multiplied selection, so
        // surviving non-integers report the multiply shape.
        private static int CoerceSampleCount(object rawCount, LythonSourceSpan span)
        {
            if (!PyNumberOps.TryAsInteger(rawCount, out var integer)) throw RuntimeErrors.MultiplySequenceError(rawCount, span);
            if (integer > Array.MaxLength)
                throw new LythonRuntimeException("OverflowError", "random sample exceeds the supported result size", span);
            return (int)integer;
        }

        private static object GetRandBits(PyRandomState state, object[] arguments, LythonSourceSpan span, ExecutionContext context)
            => GetRandBitsCoreAsync(state, arguments, span, context, false).GetAwaiter().GetResult();

        private static ValueTask<object> GetRandBitsAsync(PyRandomState state, object[] arguments, LythonSourceSpan span, ExecutionContext context)
            => GetRandBitsCoreAsync(state, arguments, span, context, true);

        private static async ValueTask<object> GetRandBitsCoreAsync(PyRandomState state, object[] arguments, LythonSourceSpan span, ExecutionContext context, bool asynchronous)
        {
            if (arguments.Length != 1)
            {
                throw new LythonRuntimeException("TypeError", "random.getrandbits(k) expects one integer argument.", span);
            }

            var rawCount = asynchronous
                ? await CoerceRandomIndexAsync(arguments[0], context, span).ConfigureAwait(false)
                : CoerceRandomIndex(arguments[0], context, span);
            return DrawBits(state, ValidateBitWidth(rawCount, span), context, span);
        }

        private static object DrawBits(PyRandomState state, long bits, ExecutionContext context, LythonSourceSpan span)
        {
            // A k-bit draw retains k bits of fresh magnitude: deny on bit scale
            // before generating, then own the fresh result.
            using var integerAdmission = GuardIntegerResultBytes(
                RuntimeMemoryEstimates.SaturatingMultiply(2, RuntimeMemoryEstimates.EstimateBigIntegerBytesFromBitCount(bits)),
                context.MemoryGovernor,
                span);
            context.CheckExecution(span);
            return OwnFreshInteger(state.GetRandBits(bits, context, span), context.MemoryGovernor, span, integerAdmission);
        }

        private static object RandBytes(PyRandomState state, object[] arguments, LythonSourceSpan span, ExecutionContext context)
            => RandBytesCoreAsync(state, arguments, span, context, false).GetAwaiter().GetResult();

        private static ValueTask<object> RandBytesAsync(PyRandomState state, object[] arguments, LythonSourceSpan span, ExecutionContext context)
            => RandBytesCoreAsync(state, arguments, span, context, true);

        private static async ValueTask<object> RandBytesCoreAsync(PyRandomState state, object[] arguments, LythonSourceSpan span, ExecutionContext context, bool asynchronous)
        {
            if (arguments.Length != 1)
            {
                throw new LythonRuntimeException("TypeError", "random.randbytes(n) expects one integer argument.", span);
            }

            // Like CPython (getrandbits(n * 8).to_bytes(n)): the width
            // multiplies first, so hook and operand failures keep their texts.
            var multiplied = asynchronous
                ? await EvaluateBinaryOperatorAsync(BinaryOperatorSyntax.Multiply, arguments[0], new BigInteger(8), context, span).ConfigureAwait(false)
                : EvaluateBinaryOperator(BinaryOperatorSyntax.Multiply, arguments[0], new BigInteger(8), context, span);
            var width = asynchronous
                ? await CoerceRandomIndexAsync(multiplied, context, span).ConfigureAwait(false)
                : CoerceRandomIndex(multiplied, context, span);
            var bits = ValidateBitWidth(width, span);
            if (!PyNumberOps.IsInteger(arguments[0]))
            {
                // Python draws before converting the original n for to_bytes;
                // __mul__ and __index__ need not describe the same width.
                var integer = PyNumberOps.GetInteger(DrawBits(state, bits, context, span));
                return await IntToBytesCoreAsync(integer,
                    [CallArgumentValue.Positional(arguments[0]), CallArgumentValue.Positional(PyString.FromString("little"))],
                    span, context, asynchronous).ConfigureAwait(false);
            }
            var count = checked((int)(bits / 8));
            using var storage = context.MemoryGovernor.ReserveTemporary(PyBytes.EstimateApproximateBytes(count), span);
            context.CheckExecution(span);
            var bytes = new byte[count];
            state.FillBytes(bytes, context, span);
            return new PyBytes(bytes, context.MemoryGovernor, span, storage);
        }

        private static long ValidateBitWidth(BigInteger width, LythonSourceSpan span)
        {
            if (width.Sign < 0) throw new LythonRuntimeException("ValueError", "number of bits must be non-negative", span);
            if (width > 8L * Array.MaxLength)
                throw new LythonRuntimeException("OverflowError", "random result exceeds the supported buffer size", span);
            return (long)width;
        }
    }
}
