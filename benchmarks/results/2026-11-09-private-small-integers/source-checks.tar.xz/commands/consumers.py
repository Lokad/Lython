exec((__import__('pathlib').Path(__file__).parent/'prepare.py').read_text(encoding='utf-8').split('(src/\'Runtime/PySmallInteger.cs\')')[0].split('for name, expected')[0])

def edit(name,old,new,count=None):
    path=src/name
    text=path.read_text(encoding='utf-8')
    n=text.count(old)
    assert n and (count is None or n==count),(name,old,n,count)
    text=text.replace(old,new)
    if 'PyNumberOps.' in text and 'using Lokad.Lython.Runtime.Numbers;' not in text and 'namespace Lokad.Lython.Runtime.Numbers;' not in text:
        text='using Lokad.Lython.Runtime.Numbers;\n'+text
    path.write_text(text,encoding='utf-8',newline='\n')

# These consumers require an exact builtin integer, not a concrete CLR box shape.
for name,value,var in [
    ('ArgparseParser.Definitions','value','integer'),('DateTimeMembers','coerced','integer'),
    ('Json.Options','value','integer'),('Statistics.Descriptive','value','integer'),
    ('Random.Distributions','value','integer')]:
    guard=f'PyNumberOps.TryAsInteger({value}, out var {var})'
    if name=='Random.Distributions': guard=f'value is not bool && {guard}'
    edit(f'Runtime/LythonRuntime.{name}.cs',f'{value} is BigInteger {var}',guard)
edit('Runtime/LythonRuntime.Random.Distributions.cs','items[1] is not BigInteger stateValue','!PyNumberOps.TryAsInteger(items[1], out var stateValue)',1)
edit('Runtime/LythonRuntime.Shlex.Lexer.Members.cs','value is not BigInteger line','!PyNumberOps.TryAsInteger(value, out var line)',1)
edit('Runtime/LythonRuntime.Complex.cs','integer.Value is not BigInteger result','!PyNumberOps.TryAsInteger(integer.Value, out var result)',1)
edit('Runtime/LythonRuntime.SubprocessModule.Arguments.cs','value is BigInteger bigInteger &&','PyNumberOps.TryAsInteger(value, out var bigInteger) &&',1)
edit('Runtime/Text/PyStringOps.Helpers.cs','bound is not BigInteger big','!PyNumberOps.TryAsInteger(bound, out var big)',1)
edit('Runtime/LythonRuntime.RegexCompiler.cs','coerced is not BigInteger big','!PyNumberOps.TryAsInteger(coerced, out var big)',1)
edit('Runtime/LythonRuntime.RegexCompiler.cs','                int small => small,','                PySmallInteger small => small.Value,\n                int small => small,',1)
edit('Runtime/LythonRuntime.Random.Selections.cs','arguments[0] is not (bool or int or BigInteger)','!PyNumberOps.IsInteger(arguments[0])',1)
edit('Runtime/LythonRuntime.Evaluation.Assignments.cs','target is BigInteger or int or bool or double','PyNumberOps.IsInteger(target) || target is double',1)

for name in ['Runtime/PyDecimalOps.Arithmetic.cs','Runtime/PyDateTimeOps.Helpers.cs','Runtime/LythonRuntime.PercentFormatting.cs']:
    edit(name,'case BigInteger integer:','case object candidate when PyNumberOps.TryAsInteger(candidate, out var integer):',1)
edit('Runtime/LythonRuntime.Statistics.Descriptive.cs','case BigInteger bigInteger:','case object candidate when PyNumberOps.TryAsInteger(candidate, out var bigInteger):',1)

# Switch expressions use shared classification and retire redundant int/bool arms
# where the whole operation already treated all integer values identically.
edit('Runtime/LythonRuntime.SubprocessModule.cs',
'''            BigInteger integer => integer,
            int integer => new BigInteger(integer),
            bool flag => flag ? BigInteger.One : BigInteger.Zero,''',
'''            _ when PyNumberOps.TryAsInteger(arguments[1], out var integer) => integer,''',1)
edit('Runtime/LythonRuntime.RegexObjects.cs',
'''                BigInteger integer => ResolveIntegerGroupIndex(match, integer, span),
                int integer => ResolveIntegerGroupIndex(match, integer, span),
                bool boolean => ResolveIntegerGroupIndex(match, boolean ? BigInteger.One : BigInteger.Zero, span),''',
'''                _ when PyNumberOps.TryAsInteger(group, out var integer) => ResolveIntegerGroupIndex(match, integer, span),''',1)
edit('Runtime/LythonRuntime.UrllibParseModule.cs',
'''                    BigInteger integer => integer,
                    bool boolean => boolean ? BigInteger.One : BigInteger.Zero,''',
'''                    _ when PyNumberOps.TryAsInteger(item, out var integer) => integer,''',1)
edit('Runtime/LythonRuntime.StringMembers.cs',
'''                    BigInteger integer => integer > textLength,
                    int integer => integer > textLength,
                    bool flag => flag && textLength == 0,''',
'''                    _ when start is not null && PyNumberOps.TryAsInteger(start, out var integer) => integer > textLength,''',1)
for name in ['OpenPyxlHelpers','OpenPyxlStylesModule']:
    edit(f'Runtime/LythonRuntime.{name}.cs','BigInteger integer => (double)integer,','_ when PyNumberOps.TryAsInteger(value, out var integer) => (double)integer,',1)
edit('Runtime/LythonRuntime.OpenPyxlPackage.WorksheetWriter.cs','BigInteger integer => integer.ToString(CultureInfo.InvariantCulture),','PySmallInteger integer => integer.Value.ToString(CultureInfo.InvariantCulture),\n                BigInteger integer => integer.ToString(CultureInfo.InvariantCulture),',1)
edit('Runtime/LythonRuntime.OpenPyxlHelpers.cs','value is PyNone or bool or BigInteger','value is PyNone or bool or PySmallInteger or BigInteger',1)
edit('Runtime/LythonRuntime.StandardModules.cs','                BigInteger integer => RuntimeMemoryEstimates.EstimateBigIntegerBytes(integer),','                PySmallInteger => 24,\n                BigInteger integer => RuntimeMemoryEstimates.EstimateBigIntegerBytes(integer),',1)
edit('Runtime/Zip/ZipMemberReader.cs','            BigInteger => "int",','            PySmallInteger or BigInteger => "int",',1)
edit('Runtime/LythonRuntime.cs','                BigInteger integer when integer >= int.MinValue','                PySmallInteger integer => integer.Value,\n                BigInteger integer when integer >= int.MinValue',1)
edit('Runtime/LythonRuntime.PathMembers.cs','arguments[0] is not BigInteger && arguments[0] is not int && arguments[0] is not bool','!PyNumberOps.IsInteger(arguments[0])')

print('Module integer consumers consolidated; private BigInteger state casts retained.')
