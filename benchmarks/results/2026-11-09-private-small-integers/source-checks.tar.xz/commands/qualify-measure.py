from pathlib import Path
import os, subprocess, sys
root=Path('D:/code/Lython'); home=Path(__file__).parent
env=os.environ.copy(); env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11'; env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe'
env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
jobs=[('internal-accepted', [env['DOTNET_HOST_PATH'],'test','tests/Lokad.Lython.Tests/Lokad.Lython.Tests.csproj','-c','Release','-f','net11.0','--filter',
       '(Category!=Stress)&(FullyQualifiedName~Integer|FullyQualifiedName~Projection|FullyQualifiedName~Executable|FullyQualifiedName~Cancellation|FullyQualifiedName~ScalarComparison)', '-v','q']),
      ('freeze-build',[env['DOTNET_HOST_PATH'],'build','src/Lokad.Lython/Lokad.Lython.csproj','-c','Release','-f','net11.0','--no-incremental','-v','q'])]
for name,cmd in jobs:
    with (home/(name+'.log')).open('w',encoding='utf-8') as log:
        result=subprocess.run(cmd,env=env,cwd=root,stdout=log,stderr=subprocess.STDOUT,timeout=180)
    print(name,'exit',result.returncode,flush=True)
    if result.returncode:
        print((home/(name+'.log')).read_text(encoding='utf-8')[-2000:],flush=True);sys.exit(result.returncode)
subprocess.run([sys.executable,'-X','utf8',str(home/'measure.py')],env=env,cwd=root,check=True)
