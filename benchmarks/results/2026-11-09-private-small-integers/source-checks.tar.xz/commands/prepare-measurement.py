from pathlib import Path
import shutil
home=Path(__file__).parent
shutil.copytree(home.parent/'text-cache-storage-r173/refined/images/candidate',home/'images/before')
shutil.copyfile(home.parent/'call-inputs-r175/catalog.json',home/'catalog.json')
text=(home.parent/'call-inputs-r175/measure.py').read_text(encoding='utf-8')
text=text.replace("purpose='Call argument source preparation; unchanged numeric/host/ownership contracts.",
    "purpose='Contract-preserving signed32 guest integer transport; unchanged public BigInteger and CLR ingress contracts.")
text=text.replace("('elapsedMs','executionMilliseconds')", "('elapsedMs','elapsedMilliseconds' if phase=='compile' else 'executionMilliseconds')")
(home/'measure.py').write_text(text,encoding='utf-8',newline='\n')
print('Reuse unchanged complete-script worker, five-job catalog, two qualified controls and corrected compile-only clock.')
