from pathlib import Path
import json, subprocess, shutil
root=Path('D:/code/Lython'); home=Path(__file__).parent; src=root/'src/Lokad.Lython'
stage=home/'initial-source'; stage.mkdir()
for p in src.rglob('*.cs'):
    if 'obj' in p.parts or 'bin' in p.parts: continue
    dst=stage/p.relative_to(src); dst.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(p,dst)
(home/'initial.patch').write_bytes(subprocess.check_output(['git','-c','core.safecrlf=false','diff','--','src/Lokad.Lython'],stderr=subprocess.DEVNULL))

def edit(name,old,new):
    path=src/name; text=path.read_text(encoding='utf-8'); assert old in text,(name,old)
    text=text.replace(old,new)
    if 'PyNumberOps.' in text and 'using Lokad.Lython.Runtime.Numbers;' not in text and 'namespace Lokad.Lython.Runtime.Numbers;' not in text:
        text='using Lokad.Lython.Runtime.Numbers;\n'+text
    path.write_text(text,encoding='utf-8',newline='\n')

edit('Runtime/Numbers/PyNumberOps.cs','    // Like CPython, converting an out-of-range integer to float fails',
'''    // Internal consumers of already validated integer results must not assume
    // that every result uses the arbitrary-precision representation.
    internal static BigInteger GetInteger(object value)
        => TryAsInteger(value, out var integer) ? integer
            : throw new System.Diagnostics.UnreachableException("expected a validated builtin integer");

    // Like CPython, converting an out-of-range integer to float fails''')
edit('Runtime/LythonRuntime.Builtins.Numeric.Async.cs','(BigInteger)ValidateIntegerConversionResult(protocol.Value, "__index__", context, span)',
    'PyNumberOps.GetInteger(ValidateIntegerConversionResult(protocol.Value, "__index__", context, span))')
edit('Runtime/LythonRuntime.Builtins.ObjectAndBytes.cs','(BigInteger)indexed','PyNumberOps.GetInteger(indexed)')
edit('Runtime/LythonRuntime.Builtins.ObjectAndBytes.cs','(BigInteger)ValidateIntegerConversionResult(protocol.Value, "__index__", context, span)',
    'PyNumberOps.GetInteger(ValidateIntegerConversionResult(protocol.Value, "__index__", context, span))')
edit('Runtime/LythonRuntime.Calls.cs','(BigInteger)IntFromBytes(arguments, span, context)','PyNumberOps.GetInteger(IntFromBytes(arguments, span, context))')
edit('Runtime/LythonRuntime.Calls.cs','((BigInteger)await IntFromBytesAsync(arguments, span, context).ConfigureAwait(false))',
    'PyNumberOps.GetInteger(await IntFromBytesAsync(arguments, span, context).ConfigureAwait(false))')
for name in ['CsvObjects','GzipModule','OperatorModule','Statistics.Descriptive']:
    edit(f'Runtime/LythonRuntime.{name}.cs','(BigInteger)(','PyNumberOps.GetInteger(')
edit('Runtime/LythonRuntime.Difflib.Matcher.cs','(BigInteger)count','PyNumberOps.GetInteger(count)')
edit('Runtime/LythonRuntime.Random.Selections.cs','(BigInteger)DrawBits(state, bits, context, span)','PyNumberOps.GetInteger(DrawBits(state, bits, context, span))')
edit('Runtime/LythonRuntime.Shlex.Lexer.cs','(BigInteger)AddExactIntegers(LineNumber, BigInteger.One, _context.MemoryGovernor, span)',
    'PyNumberOps.GetInteger(AddExactIntegers(LineNumber, BigInteger.One, _context.MemoryGovernor, span))')
edit('Runtime/LythonRuntime.UrllibParseModule.Query.cs','(BigInteger)Len([value], span, context)','PyNumberOps.GetInteger(Len([value], span, context))')
edit('Runtime/LythonRuntime.UrllibParseModule.Cache.cs','(BigInteger)ComputeBuiltinHash(value, span, context)','PyNumberOps.GetInteger(ComputeBuiltinHash(value, span, context))')

# The existing integer sort shortcut applies to both representations.
edit('Runtime/LythonRuntime.BuiltinIterables.Ordering.cs','left is BigInteger leftInteger && right is BigInteger rightInteger',
    'PyNumberOps.TryAsInteger(left, out var leftInteger) && PyNumberOps.TryAsInteger(right, out var rightInteger)')
print('Snapshot original failed conditions; remove concrete boxed-result casts through shared validated extraction.')
