from pathlib import Path
import hashlib, json, shutil, subprocess

root = Path('D:/code/Lython')
home = Path(__file__).parent
src = root / 'src/Lokad.Lython'
baseline = json.loads((home.parent/'machine-integers-r174/baseline.json').read_text(encoding='utf-8'))
for name, expected in baseline['productionSources'].items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == expected, name
    target = home/'before-source'/Path(name).relative_to(src)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(name, target)
(home/'baseline.json').write_text(json.dumps(dict(revision=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    productionSources=baseline['productionSources'], representation='private immutable signed32; larger BigInteger; public guest integers BigInteger',
    projection='reserve32 before materializing each public compact integer; old owner survives projection',
    displaced='small fresh BigInteger boxes, scattered BigInteger-only acceptance checks',
    acceptance=['host ingress round trips','identity-returning methods','hash/mixed arithmetic','promotion','projection refusal and retained ownership','cancellation','whole-script goldens and controls']),indent=2)+'\n',encoding='utf-8')

def edit(name, old, new, count=None):
    path=src/name
    text=path.read_text(encoding='utf-8')
    found=text.count(old)
    assert found and (count is None or found==count), (name,old,found,count)
    path.write_text(text.replace(old,new),encoding='utf-8',newline='\n')

(src/'Runtime/PySmallInteger.cs').write_text('''using System.Numerics;

namespace Lokad.Lython.Runtime;

// Private guest representation. CLR ingress remains unchanged; public projection
// materializes BigInteger under the result owner's admission before allocation.
internal readonly record struct PySmallInteger(int Value)
{
    internal static object Box(BigInteger value)
        => value >= int.MinValue && value <= int.MaxValue ? new PySmallInteger((int)value) : value;

    internal static object Box(long value)
        => value >= int.MinValue && value <= int.MaxValue ? new PySmallInteger((int)value) : new BigInteger(value);
}
''',encoding='utf-8',newline='\n')
edit('Runtime/Numbers/PyNumberOps.cs','value is bool or BigInteger or sbyte','value is bool or PySmallInteger or BigInteger or sbyte')
edit('Runtime/Numbers/PyNumberOps.cs','            case BigInteger integer:',
'''            case PySmallInteger integer:
                number = PyNumber.FromInteger(integer.Value);
                return true;
            case BigInteger integer:''',1)
for op in ['+', '-', '*']:
    edit('Runtime/Numbers/PyNumberOps.cs',f'? lhs.Integer {op} rhs.Integer :',f'? PySmallInteger.Box(lhs.Integer {op} rhs.Integer) :',1)
edit('Runtime/Numbers/PyNumberOps.cs','return FloorDivideIntegers(lhs.Integer, rhs.Integer);','return PySmallInteger.Box(FloorDivideIntegers(lhs.Integer, rhs.Integer));',1)
edit('Frontend/ExecutableScript.Expressions.cs','InternConstant(integer.Value)','InternConstant(PySmallInteger.Box(integer.Value))',1)
edit('Runtime/LythonRuntime.Operations.cs', '    // Major magnitudes stay conservatively charged to the execution owner.',
'''    // Typed fresh producers avoid creating a BigInteger box before selecting
    // the compact representation. The object overload preserves ingress aliases.
    private static object OwnHeapInteger(BigInteger value, MemoryGovernor governor, LythonSourceSpan? span)
        => OwnFreshInteger(value, governor, span);

    internal static object OwnFreshInteger(BigInteger value, MemoryGovernor governor, LythonSourceSpan? span,
        MemoryGovernor.TemporaryMemoryReservation? storage = null)
        => OwnFreshInteger(PySmallInteger.Box(value), governor, span, storage);

    // Major magnitudes stay conservatively charged to the execution owner.''',1)
edit('Runtime/PublicProjection.cs','            BigInteger integer => ProjectInteger(value, integer, budget),',
'''            PySmallInteger integer => ProjectSmallInteger(integer, budget),
            BigInteger integer => ProjectInteger(value, integer, budget),''',1)
edit('Runtime/PublicProjection.cs','    private static object ProjectInteger(',
'''    private static object ProjectSmallInteger(PySmallInteger integer, ProjectionBudget? budget)
    {
        budget?.Reserve(32);
        return new BigInteger(integer.Value);
    }

    private static object ProjectInteger(''',1)
edit('Runtime/PyMemberAccess.cs','            [typeof(BigInteger)] =',
'''            [typeof(PySmallInteger)] = static (object target, string memberName, [MaybeNullWhen(false)] out object value) => LythonRuntime.IntMembers.TryGetMember(target, memberName, out value),
            [typeof(BigInteger)] =''',1)

# Central native eligibility remains the existing engine, not a second dispatcher.
for name in ['Executable.Inputs','Executable.Interpreter.Dispatch','Executable.NativeCalls','Executable.PreparedOperations']:
    edit('Runtime/LythonRuntime.'+name+'.cs','BigInteger or','PySmallInteger or BigInteger or')
edit('Runtime/LythonRuntime.Executable.NativeReturn.cs','        BigInteger => NativeReturnShape.Integer,','        PySmallInteger or BigInteger => NativeReturnShape.Integer,',1)

# Preserve identity-returning integer operations, including user __index__ values.
for name,receiver in [('Members','receiver'),('Builtins','indexed'),('Modules','value'),('OperatorModule','value'),('Resolution','result'),('Resolution','converted')]:
    edit('Runtime/LythonRuntime.'+name+'.cs',f'{receiver} is BigInteger ?',f'{receiver} is PySmallInteger or BigInteger ?')
edit('Runtime/LythonRuntime.Builtins.cs','                BigInteger => value,','                PySmallInteger or BigInteger => value,',1)
edit('Runtime/LythonRuntime.Builtins.cs','        if (value is BigInteger integer && integer.Sign >= 0) return value;',
'''        if (value is PySmallInteger { Value: >= 0 } || value is BigInteger { Sign: >= 0 }) return value;''',1)
edit('Runtime/LythonRuntime.Builtins.Rounding.cs','arguments[0] is BigInteger &&','arguments[0] is (PySmallInteger or BigInteger) &&',1)
edit('Runtime/LythonRuntime.Builtins.Rounding.cs','            BigInteger integer => RoundInteger(integer, digits, span),','            _ when PyNumberOps.TryAsInteger(arguments[0], out var integer) => RoundInteger(integer, digits, span),',1)

# Existing exact-add funnel now accepts both private builtin representations.
for name in ['OperatorDispatch','Evaluation.Operators']:
    edit('Runtime/LythonRuntime.'+name+'.cs','left is BigInteger leftInteger && right is BigInteger rightInteger',
         'left is (PySmallInteger or BigInteger) && right is (PySmallInteger or BigInteger)')
    edit('Runtime/LythonRuntime.'+name+'.cs','AddExactIntegers(leftInteger, rightInteger,','AddExactIntegers(left, right,')
edit('Runtime/LythonRuntime.Evaluation.Assignments.cs','currentValue is BigInteger leftInteger && right is BigInteger rightInteger',
    'currentValue is (PySmallInteger or BigInteger) && right is (PySmallInteger or BigInteger)',1)
edit('Runtime/LythonRuntime.Evaluation.Assignments.cs','AddExactIntegers(leftInteger, rightInteger,','AddExactIntegers(currentValue, right,',1)
edit('Runtime/LythonRuntime.Evaluation.Operators.cs','    private static object AddExactIntegers(BigInteger left,',
'''    private static object AddExactIntegers(object left, object right, MemoryGovernor? governor, LythonSourceSpan span)
    {
        if (left is PySmallInteger a && right is PySmallInteger b)
            return PySmallInteger.Box((long)a.Value + b.Value);
        _ = PyNumberOps.TryAsInteger(left, out var lhs);
        _ = PyNumberOps.TryAsInteger(right, out var rhs);
        return AddExactIntegers(lhs, rhs, governor, span);
    }

    private static object AddExactIntegers(BigInteger left,''',1)
edit('Runtime/LythonRuntime.Evaluation.Operators.cs','            return result;\n        }\n        catch (OverflowException ex)',
    '            return PySmallInteger.Box(result);\n        }\n        catch (OverflowException ex)',1)

print('Baseline snapshotted; compact producers, shared consumers, identity and projection migrated.')
