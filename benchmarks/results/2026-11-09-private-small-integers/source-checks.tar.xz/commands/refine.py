from pathlib import Path
import shutil, subprocess
root=Path('D:/code/Lython'); home=Path(__file__).parent; src=root/'src/Lokad.Lython'
for p in src.rglob('*.cs'):
    if 'obj' in p.parts or 'bin' in p.parts: continue
    dst=home/'first-qualified-source'/p.relative_to(src); dst.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(p,dst)
(home/'first-qualified.patch').write_bytes(subprocess.check_output(['git','-c','core.autocrlf=false','diff','--','src/Lokad.Lython','tests']))
plan=root/'PLAN.md'; text=plan.read_text(encoding='utf-8'); text=text.replace('   A complete candidate needs focused', '''   Initial coherent wrapper:824focused internal and821affected public checks,
   plus733existing public cancellation/ownership and5new semantic cases pass11.
   Desktop actual text allocation−6.91%, CSV−1.49%; elapsed mixed/adverse text,
   not CPU qualification. Preserve this source and all original failed conditions.
   One bounded refinement carries signed32 through the existing PyNumber view,
   removing repeated BigInteger reconstruction in common arithmetic/comparison.
   No new execution route or VM tags. Reuse the same five scripts and controls;
   decide whether this migration is worthwhile before wider qualification.
   A complete candidate needs focused'''); plan.write_text(text,encoding='utf-8',newline='\n')

(src/'Runtime/Numbers/PyNumber.cs').write_text('''using System.Numerics;

namespace Lokad.Lython.Runtime.Numbers;

internal readonly record struct PyNumber
{
    private readonly BigInteger _integer;
    private readonly int _smallInteger;
    private readonly NumberKind _kind;

    private enum NumberKind : byte { Integer, SmallInteger, Float }

    private PyNumber(BigInteger integer)
    {
        _integer = integer;
        _smallInteger = 0;
        _kind = NumberKind.Integer;
        Floating = 0.0;
    }

    private PyNumber(int integer)
    {
        _integer = default;
        _smallInteger = integer;
        _kind = NumberKind.SmallInteger;
        Floating = 0.0;
    }

    private PyNumber(double floating)
    {
        _integer = default;
        _smallInteger = 0;
        _kind = NumberKind.Float;
        Floating = floating;
    }

    public bool IsFloat => _kind == NumberKind.Float;
    internal bool IsSmallInteger => _kind == NumberKind.SmallInteger;
    internal int SmallInteger => _smallInteger;
    public BigInteger Integer => IsSmallInteger ? _smallInteger : _integer;
    public double Floating { get; }

    public bool IsZero => _kind switch
    {
        NumberKind.Float => Floating == 0.0,
        NumberKind.SmallInteger => _smallInteger == 0,
        _ => _integer.IsZero,
    };

    public double ToDouble() => IsFloat ? Floating : IsSmallInteger ? _smallInteger : (double)_integer;
    public static PyNumber FromBoolean(bool value) => new(value ? 1 : 0);
    public static PyNumber FromSmallInteger(int value) => new(value);
    public static PyNumber FromInteger(BigInteger value) => new(value);
    public static PyNumber FromFloat(double value) => new(value);
}
''',encoding='utf-8',newline='\n')

path=src/'Runtime/Numbers/PyNumberOps.cs'; text=path.read_text(encoding='utf-8')
text=text.replace('number = PyNumber.FromInteger(integer.Value);','number = PyNumber.FromSmallInteger(integer.Value);')
for typename in ['sbyte','byte','short','ushort','int']:
    text=text.replace(f'case {typename} integer:\n                number = PyNumber.FromInteger(integer);',f'case {typename} integer:\n                number = PyNumber.FromSmallInteger(integer);')
text=text.replace('=> number.IsFloat ? number.Floating : BigIntegerToDouble(number.Integer);',
    '=> number.IsFloat ? number.Floating : number.IsSmallInteger ? number.SmallInteger : BigIntegerToDouble(number.Integer);')
for name,op in [('Add','+'),('Subtract','-'),('Multiply','*')]:
    old=f'    public static object {name}(PyNumber lhs, PyNumber rhs)\n        => !lhs.IsFloat && !rhs.IsFloat ? PySmallInteger.Box(lhs.Integer {op} rhs.Integer) : ToDoubleChecked(lhs) {op} ToDoubleChecked(rhs);'
    new=f'''    public static object {name}(PyNumber lhs, PyNumber rhs)
        => lhs.IsSmallInteger && rhs.IsSmallInteger ? PySmallInteger.Box((long)lhs.SmallInteger {op} rhs.SmallInteger)
            : !lhs.IsFloat && !rhs.IsFloat ? PySmallInteger.Box(lhs.Integer {op} rhs.Integer) : ToDoubleChecked(lhs) {op} ToDoubleChecked(rhs);'''
    assert old in text,name; text=text.replace(old,new)
text=text.replace('            comparison = lhs.Integer.CompareTo(rhs.Integer);',
    '            comparison = lhs.IsSmallInteger && rhs.IsSmallInteger\n                ? lhs.SmallInteger.CompareTo(rhs.SmallInteger) : lhs.Integer.CompareTo(rhs.Integer);')
text=text.replace('=> number.IsFloat ? -number.Floating : PySmallInteger.Box(-number.Integer);',
    '=> number.IsFloat ? -number.Floating : number.IsSmallInteger ? PySmallInteger.Box(-(long)number.SmallInteger) : PySmallInteger.Box(-number.Integer);')
path.write_text(text,encoding='utf-8',newline='\n')

refined=home/'refined'; refined.mkdir()
shutil.copytree(home/'images/before',refined/'images/before')
shutil.copyfile(home/'catalog.json',refined/'catalog.json')
measure=(home/'measure.py').read_text(encoding='utf-8').replace("home.parent/'bulk-whitespace-r157", "home.parent.parent/'bulk-whitespace-r157")
measure=measure.replace("['git', 'diff', '--binary'", "['git', '-c', 'core.autocrlf=false', 'diff', '--binary'")
(refined/'measure.py').write_text(measure,encoding='utf-8',newline='\n')
qualify=(home/'qualify-measure.py').read_text(encoding='utf-8')
(refined/'qualify-measure.py').write_text(qualify,encoding='utf-8',newline='\n')
print('Original exact source/identity/measurements retained; refine the existing numeric view, not the VM.')
