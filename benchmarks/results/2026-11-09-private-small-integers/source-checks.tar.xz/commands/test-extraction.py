from pathlib import Path
import re, shutil
root=Path('D:/code/Lython'); home=Path(__file__).parent
log=(home/'internal-focused-corrected.log').read_text(encoding='utf-8')
names=set(re.findall(r'\\Lokad.Lython.Tests\\([A-Za-z0-9_.]+\.cs):line',log))
def arguments(text):
    level=0; quote=None; escape=False; start=0; parts=[]
    for i,c in enumerate(text):
        if quote:
            if escape: escape=False
            elif c=='\\': escape=True
            elif c==quote: quote=None
        elif c in '\"\'': quote=c
        elif c in '([{': level+=1
        elif c in ')]}': level-=1
        elif c==',' and level==0: parts.append(text[start:i].strip()); start=i+1
    parts.append(text[start:].strip()); return parts
changed=[]
for name in sorted(names):
    path=root/'tests/Lokad.Lython.Tests'/name
    backup=home/'before-tests'/name; backup.parent.mkdir(parents=True,exist_ok=True)
    if not backup.exists(): shutil.copyfile(path,backup)
    before=backup.read_text(encoding='utf-8')
    lines=before.splitlines()
    for i,line in enumerate(lines):
        token='Assert.Equal('
        start=line.find(token); end=line.rfind(');')
        if start<0 or end<start: continue
        args=arguments(line[start+len(token):end])
        if len(args)==2 and (args[0].startswith('new BigInteger(') or args[0].startswith('BigInteger.')):
            lines[i]=line[:start]+token+args[0]+', PyNumberOps.GetInteger('+args[1]+'));'+line[end+2:]
    text='\n'.join(lines)+'\n'
    text=text.replace('.Cast<BigInteger>()','.Select(PyNumberOps.GetInteger)')
    # Only assertions which actually failed on the private representation.
    for m in re.finditer(re.escape(name)+r':line (\d+)',log):
        index=int(m[1])-1
        if index<len(lines) and 'Assert.IsType<BigInteger>(' in lines[index]:
            text=text.replace(lines[index],lines[index].replace('Assert.IsType<BigInteger>(', 'PyNumberOps.GetInteger('))
    if name=='LoweringArchitectureSubsystemTests.cs':
        text=re.sub(r'Assert.Contains\(new BigInteger\((\d+)\), (.+)\);',
            r'Assert.Contains(\2, value => PyNumberOps.TryAsInteger(value, out var integer) && integer == \1);',text)
    if text!=before:
        if 'PyNumberOps.' in text and 'using Lokad.Lython.Runtime.Numbers;' not in text:
            text='using Lokad.Lython.Runtime.Numbers;\n'+text
        path.write_text(text,encoding='utf-8',newline='\n'); changed.append(name)
print('Keep numeric values/type checks and all ownership/cleanup assertions; canonical integer extraction in',len(changed),'white-box fixtures.')
