using System.Numerics;

namespace Lokad.Lython.Runtime.Numbers;

internal readonly record struct PyNumber
{
    private readonly BigInteger _integer;
    private readonly int _smallInteger;
    private readonly NumberKind _kind;

    private enum NumberKind : byte { Integer, SmallInteger, Float }

    private PyNumber(BigInteger integer)
    {
        _integer = integer;
        _smallInteger = 0;
        _kind = NumberKind.Integer;
        Floating = 0.0;
    }

    private PyNumber(int integer)
    {
        _integer = default;
        _smallInteger = integer;
        _kind = NumberKind.SmallInteger;
        Floating = 0.0;
    }

    private PyNumber(double floating)
    {
        _integer = default;
        _smallInteger = 0;
        _kind = NumberKind.Float;
        Floating = floating;
    }

    public bool IsFloat => _kind == NumberKind.Float;
    internal bool IsSmallInteger => _kind == NumberKind.SmallInteger;
    internal int SmallInteger => _smallInteger;
    public BigInteger Integer => IsSmallInteger ? _smallInteger : _integer;
    public double Floating { get; }

    public bool IsZero => _kind switch
    {
        NumberKind.Float => Floating == 0.0,
        NumberKind.SmallInteger => _smallInteger == 0,
        _ => _integer.IsZero,
    };

    public double ToDouble() => IsFloat ? Floating : IsSmallInteger ? _smallInteger : (double)_integer;
    public static PyNumber FromBoolean(bool value) => new(value ? 1 : 0);
    public static PyNumber FromSmallInteger(int value) => new(value);
    public static PyNumber FromInteger(BigInteger value) => new(value);
    public static PyNumber FromFloat(double value) => new(value);
}
