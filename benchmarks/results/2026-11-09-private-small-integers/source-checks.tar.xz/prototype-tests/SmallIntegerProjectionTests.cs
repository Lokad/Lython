using System.Numerics;
using Lokad.Lython.Runtime;

namespace Lokad.Lython.Tests;

public sealed class SmallIntegerProjectionTests
{
    [Fact]
    public void NewPublicIntegerBoxIsFundedUntilResultOwnerEnds()
    {
        var root = new LythonMemoryBudget(1024);
        using (var resultOwner = root.CreateScope())
        {
            var projection = new ProjectionBudget(resultOwner);
            var value = PublicProjection.NormalizeValue(new PySmallInteger(42), projection);
            Assert.Equal(new BigInteger(42), Assert.IsType<BigInteger>(value));
            Assert.True(root.ReservedBytes >= 32);
        }
        Assert.Equal(0, root.ReservedBytes);
    }

    [Fact]
    public void RefusedIntegerProjectionPreservesFirstFailureAndBalance()
    {
        var root = new LythonMemoryBudget(0);
        using var resultOwner = root.CreateScope();
        var projection = new ProjectionBudget(resultOwner);
        var value = new PySmallInteger(42);
        var failure = Assert.Throws<ProjectionException>(() => PublicProjection.NormalizeValue(value, projection));
        Assert.Equal(LythonFailureReason.SharedMemoryAllowance, failure.Attribution.Reason);
        Assert.Equal(0, root.ReservedBytes);
        Assert.Equal(0, projection.CurrentBytes);
        Assert.Same(failure, Assert.Throws<ProjectionException>(() => PublicProjection.NormalizeValue(value, projection)));
    }
}
