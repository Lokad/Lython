using System.Diagnostics;
using System.Numerics;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime;
using Lokad.Lython.Runtime.Text;
using Lokad.Lython.Tests.Harness;
using Context = Lokad.Lython.Runtime.LythonRuntime.ExecutionContext;

namespace Lokad.Lython.Tests;

public sealed class ExecutableCallFrameTests
{
    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task OrdinaryGuestRecursionDoesNotGrowTheClrCallStack(bool asynchronous)
    {
        const string source = "def descend(n):\n if n==0:return sample()\n return descend(n-1)\nreturn descend(depth)";
        var code = Compile(source);
        var counts = new List<int>();
        var budget = new LythonMemoryBudget(4 * 1024 * 1024);
        foreach (var depth in new[] { 1, 64 })
        {
            using (var owner = budget.CreateScope())
            {
                var context = new Context(new MockLythonHost(), new LythonRunOptions { MemoryBudget = owner });
                context.Variables["depth"] = new BigInteger(depth);
                context.Variables["sample"] = new Sample(counts);
                var result = asynchronous ? await LythonRuntime.ExecuteExecutableCodeObjectAsync(code, context)
                    : LythonRuntime.ExecuteExecutableCodeObject(code, context, default, null);
                Assert.Same(PyNone.Instance, result);
                Unwound(context);
            }
            Assert.Equal(0, budget.ReservedBytes);
        }
        Assert.Equal(2, counts.Count);
        Assert.InRange(counts[1] - counts[0], -12, 12);
    }

    [Theory]
    [InlineData(false, false), InlineData(false, true)]
    [InlineData(true, false), InlineData(true, true)]
    public async Task TypeSubscriptionRecursionDoesNotGrowTheClrCallStack(bool descriptor, bool asynchronous)
    {
        var source = descriptor ? """
            def keep(key):return keep
            class Slot:
             def __get__(self,obj,owner):
              n=owner.remaining
              if n==0:
               sample()
               return keep
              owner.remaining=n-1
              return owner[0]
            class Loop:
             remaining=depth
             __class_getitem__=Slot()
            Loop[0]
            return None
            """ : """
            class Loop:
             def __class_getitem__(cls,n):
              if n==0:return sample()
              return cls[n-1]
            return Loop[depth]
            """;
        var code = Compile(source);
        var counts = new List<int>();
        var budget = new LythonMemoryBudget(4 * 1024 * 1024);
        foreach (var depth in new[] { 1, 64 })
        {
            using (var owner = budget.CreateScope())
            {
                var context = new Context(new MockLythonHost(), new LythonRunOptions { MemoryBudget = owner });
                context.Variables["depth"] = new BigInteger(depth);
                context.Variables["sample"] = new Sample(counts);
                var result = asynchronous ? await LythonRuntime.ExecuteExecutableCodeObjectAsync(code, context)
                    : LythonRuntime.ExecuteExecutableCodeObject(code, context, default, null);
                Assert.Same(PyNone.Instance, result);
                Unwound(context);
            }
            Assert.Equal(0, budget.ReservedBytes);
        }
        Assert.Equal(2, counts.Count);
        Assert.InRange(counts[1] - counts[0], -12, 12);
    }

    [Theory]
    [InlineData(false, false), InlineData(false, true)]
    [InlineData(true, false), InlineData(true, true)]
    public async Task TypeSubscriptionFailureRunsEveryFinallyAndRetainsItsTraceback(bool descriptor, bool asynchronous)
    {
        var source = descriptor ? """
            class Slot:
             def __get__(self,obj,owner):
              n=owner.remaining
              try:
               if n==0:raise ValueError('leaf')
               owner.remaining=n-1
               return owner[0]
              finally:events.append(n)
            class Loop:
             remaining=12
             __class_getitem__=Slot()
            Loop[0]
            """ : """
            class Loop:
             def __class_getitem__(cls,n):
              try:
               if n==0:raise ValueError('leaf')
               return cls[n-1]
              finally:events.append(n)
            Loop[12]
            """;
        var budget = new LythonMemoryBudget(4 * 1024 * 1024);
        using (var owner = budget.CreateScope())
        {
            var context = new Context(new MockLythonHost(), new LythonRunOptions { MemoryBudget = owner });
            var original = new PyException("LookupError", "outer", PyNone.Instance);
            context.State.SetCurrentException(original);
            var events = new PyList([], context.MemoryGovernor, null);
            context.Variables["events"] = events;
            var failure = await Assert.ThrowsAsync<LythonRuntimeException>(async () =>
            {
                var code = Compile(source);
                if (asynchronous) await LythonRuntime.ExecuteExecutableCodeObjectAsync(code, context);
                else LythonRuntime.ExecuteExecutableCodeObject(code, context, default, null);
            });
            Assert.Equal("ValueError", failure.ExceptionType);
            Assert.Equal(Enumerable.Range(0, 13).Select(i => new BigInteger(i)), events.Cast<BigInteger>());
            Assert.Equal(13, failure.Frames.Count);
            Assert.All(failure.Frames, frame => Assert.Equal(descriptor ? "__get__" : "__class_getitem__", frame.FunctionName));
            Assert.Same(original, context.State.CurrentException);
            Unwound(context);
        }
        Assert.Equal(0, budget.ReservedBytes);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task EveryCallerRunsFinallyAndRetainsItsGuestTraceback(bool asynchronous)
    {
        const string source = """
def descend(n):
 try:
  if n==0:raise ValueError('leaf')
  return descend(n-1)
 finally:events.append(n)
descend(12)
""";
        var budget = new LythonMemoryBudget(4 * 1024 * 1024);
        using (var owner = budget.CreateScope())
        {
            var context = new Context(new MockLythonHost(), new LythonRunOptions { MemoryBudget = owner });
            var original = new PyException("LookupError", "outer", PyNone.Instance);
            context.State.SetCurrentException(original);
            var events = new PyList([], context.MemoryGovernor, null);
            context.Variables["events"] = events;
            var code = Compile(source);
            var failure = await Assert.ThrowsAsync<LythonRuntimeException>(async () =>
            {
                if (asynchronous) await LythonRuntime.ExecuteExecutableCodeObjectAsync(code, context);
                else LythonRuntime.ExecuteExecutableCodeObject(code, context, default, null);
            });
            Assert.Equal("ValueError", failure.ExceptionType);
            var guest = Assert.IsType<PyException>(failure.OriginalPythonException);
            Assert.Equal("leaf", Assert.IsType<PyString>(Assert.Single(guest.GetArgs())).AsString());
            Assert.Equal(Enumerable.Range(0, 13).Select(i => new BigInteger(i)), events.Cast<BigInteger>());
            Assert.Equal(13, failure.Frames.Count);
            Assert.All(failure.Frames, frame => Assert.Equal("descend", frame.FunctionName));
            Assert.Same(original, context.State.CurrentException);
            Unwound(context);
        }
        Assert.Equal(0, budget.ReservedBytes);
    }

    private static ExecutableCodeObject Compile(string source)
        => ExecutableScript.Compile(LoweredScript.Lower(LythonFrontend.Compile(source).Script!)).EntryPoint;

    private static void Unwound(Context context)
    {
        Assert.Null(context.CurrentExecutableFrame);
        Assert.Equal(0, context.State.CurrentRecursionDepth);
        Assert.Equal(0, context.State.CurrentInterpreterDepth);
        Assert.Equal(0, context.MemoryGovernor.CurrentReservedBytes);
    }

    private sealed class Sample(List<int> counts) : LythonRuntime.ICallable
    {
        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, Context context)
        {
            Assert.Empty(arguments);
            Assert.True(context.TryResolveOwnLocal("n", out var value));
            Assert.Equal(BigInteger.Zero, value);
            // Managed test diagnostic only; no runtime stack telemetry/admission.
            counts.Add(new StackTrace().FrameCount);
            return PyNone.Instance;
        }
    }
}
