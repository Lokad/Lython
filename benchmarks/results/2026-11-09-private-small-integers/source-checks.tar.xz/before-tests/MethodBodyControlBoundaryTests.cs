using System.Numerics;
using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime;
using Lokad.Lython.Tests.Harness;
using Context = Lokad.Lython.Runtime.LythonRuntime.ExecutionContext;

namespace Lokad.Lython.Tests;

public sealed class MethodBodyControlBoundaryTests
{
    private static readonly LythonSourceSpan CallSpan = new(2000, 4, 90, 1);
    private const string Source = """
        class Runner:
         def run(self):
          result=0
          for i in range(3):
           if i==1:
            try:continue
            finally:stamp('continue',i)
           while True:
            result+=stamp('value',i)
            break
          else:result+=10
          return result
         def identity(self):return self
        runner=Runner()
        """;

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task MethodBodiesPreserveEffectsAndScopeCleanup(bool asynchronous)
    {
        var full = await Define(asynchronous);
        var before = full.Root.MemoryGovernor.CurrentAccountedBytes;
        Assert.Equal(new BigInteger(12), await Invoke(full.Method, full.Root, asynchronous));
        var funded = full.Root.MemoryGovernor.CurrentAccountedBytes - before;
        Assert.True(funded > 0);
        Assert.Equal(new[] { "value:0", "continue:1", "value:2" }, full.Tape.Events);
        AssertUnwound(full.Root);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task RealHostPauseSupportsSameRunReentryAndCancellation(bool cancel)
    {
        using var cancellation = new CancellationTokenSource();
        var fixture = await Define(true, cancellation.Token);
        fixture.Tape.Pause = true;
        var pending = Invoke(fixture.Method, fixture.Root, true).AsTask();
        var frame = await fixture.Tape.Started.Task.WaitAsync(TimeSpan.FromSeconds(5));
        try
        {
            Assert.False(pending.IsCompleted);
            Assert.Same(fixture.Root.State, frame.State);
            Assert.Same(fixture.Root.MemoryGovernor, frame.MemoryGovernor);
            Assert.Same(fixture.Active, frame.State.CurrentException);
            Assert.NotNull(frame.CurrentExecutableFrame);
            var depth = frame.State.CurrentInterpreterDepth;
            var recursion = frame.State.CurrentRecursionDepth;
            Assert.True(depth > 0);
            Assert.True(recursion > 0);
            Assert.Same(fixture.Receiver, await Invoke(Bind(fixture.Receiver, "identity"), fixture.Root, true));
            Assert.Equal(depth, frame.State.CurrentInterpreterDepth);
            Assert.Equal(recursion, frame.State.CurrentRecursionDepth);
            if (cancel)
            {
                cancellation.Cancel();
                await Assert.ThrowsAnyAsync<OperationCanceledException>(async () => await pending);
            }
            else
            {
                fixture.Tape.Release.SetResult();
                Assert.Equal(new BigInteger(12), await pending);
            }
        }
        finally
        {
            fixture.Tape.Release.TrySetResult();
            try { await pending; }
            catch (OperationCanceledException) when (cancellation.IsCancellationRequested) { }
        }
        AssertUnwound(fixture.Root);
        Assert.Same(fixture.Active, fixture.Root.State.CurrentException);
    }

    private sealed class Tape(Context root, PyException active, CancellationToken cancellation) : LythonRuntime.ICallable
    {
        internal List<string> Events { get; } = [];
        internal bool Pause { get; set; }
        internal TaskCompletionSource<Context> Started { get; } = new(TaskCreationOptions.RunContinuationsAsynchronously);
        internal TaskCompletionSource Release { get; } = new(TaskCreationOptions.RunContinuationsAsynchronously);
        public object Invoke(CallArgumentValue[] arguments, LythonSourceSpan span, Context frame)
        {
            Assert.False(Pause);
            Assert.Same(root.State, frame.State);
            Assert.Same(root.MemoryGovernor, frame.MemoryGovernor);
            Assert.Same(active, frame.State.CurrentException);
            Assert.NotNull(frame.CurrentExecutableFrame);
            var phase = arguments[0].Value.ToString()!;
            Events.Add($"{phase}:{arguments[1].Value}");
            Assert.Equal(0, frame.MemoryGovernor.CurrentReservedBytes);
            Assert.True(frame.State.CurrentInterpreterDepth > 0);
            Assert.Equal(1, frame.State.CurrentRecursionDepth);
            return arguments[1].Value;
        }
        public async ValueTask<object> InvokeAsync(CallArgumentValue[] arguments, LythonSourceSpan span, Context frame)
        {
            var pause = Pause;
            Pause = false;
            var value = Invoke(arguments, span, frame);
            Pause = pause;
            if (pause && !Started.Task.IsCompleted)
            {
                Started.SetResult(frame);
                await Release.Task.WaitAsync(cancellation);
            }
            else await Task.Yield();
            return value;
        }
    }

    private sealed record Fixture(Context Root, PyInstance Receiver, PyBoundMethod Method, Tape Tape, PyException Active);
    private static async Task<Fixture> Define(bool asynchronous, CancellationToken cancellation = default)
    {
        var frontend = LythonFrontend.Compile(Source,regexProvider:Utf8RegexProvider.Instance);
        Assert.DoesNotContain(frontend.Diagnostics, d => d.Severity == LythonDiagnosticSeverity.Error);
        var lowered = LoweredScript.Lower(frontend.Script.RequireNotNull());
        var root = new Context(new MockLythonHost(), new LythonRunOptions
        {
            MemoryBudget = new LythonMemoryBudget(1024 * 1024),
            SourcePath = "/method-control.py", CancellationToken = cancellation
        },regexProvider:Utf8RegexProvider.Instance);
        var active = new PyException("ValueError", "outer", PyNone.Instance);
        root.State.SetCurrentException(active);
        var tape = new Tape(root, active, cancellation);
        root.Variables["stamp"] = tape;
        if (asynchronous) await LythonRuntime.ExecuteStatementsAsync(lowered.Statements, root);
        else LythonRuntime.ExecuteExecutableCodeObject(ExecutableScript.Compile(lowered).EntryPoint, root, default, null);
        var receiver = Assert.IsType<PyInstance>(root.Variables["runner"]);
        AssertUnwound(root);
        return new(root, receiver, Bind(receiver, "run"), tape, active);
    }
    private static PyBoundMethod Bind(PyInstance receiver, string name)
    {
        Assert.True(receiver.Type.TryGetOwnMember(name, out var member));
        return Assert.IsType<PyBoundMethod>(Assert.IsAssignableFrom<PyFunctionBase>(member).Bind(receiver));
    }
    private static ValueTask<object> Invoke(LythonRuntime.ICallable method, Context root, bool asynchronous)
        => asynchronous ? method.InvokeAsync([], CallSpan, root) : ValueTask.FromResult(method.Invoke([], CallSpan, root));
    private static void AssertUnwound(Context root)
    {
        Assert.Equal(0, root.State.CurrentRecursionDepth);
        Assert.Equal(0, root.State.CurrentInterpreterDepth);
        Assert.Equal(0, root.MemoryGovernor.CurrentReservedBytes);
        Assert.Null(root.CurrentExecutableFrame);
    }
}
