# Closed aggregation segment entry

B626:1,152selectedsamples/5.81guestCPU seconds,64unknown. Native dictionary loop
185leafsamples(16.1%), casing prep/scanning/writing dominates another visible group;
66guard/67evaluation include useful Python work. Not removable-cost forecasts.

Select one coherent segment-entry prototype, not a second evaluator/arena. Current
histogram body proves local dictionary/key/total bindings uncaptured; closed native
iteration and TryAccumulateWithoutAdmission/TryAccumulateInlineWord cannot run guest
code, host admission or I/O. Cased words were admitted eagerly; later fragments use
CreateReservedUtf8, not Reserve. Existing fallthrough is the exact effect boundary.

For that existing private segment, enter managed interpreter-frame admission once
at the first actual get (same span/depth/order), retain it until exit, and reuse the
already validated local dictionary/initial scalar. Keep per-word token/terminal
checks and dynamic dictionary/value guards. Mirrored namespaces keep ordinary
per-word admission/reloads. Any fallback/protocol/growth leaves the segment and
releases its frame before publishing pending word/total and ordinary resumption.
No public option, metadata plan, controller, storage owner or opcode is added.
Expected deletion: recurring managed frame enter/leave and local type/bounds reads
inside callback-free native work, not the guards for possible protocol/reentry.

Accept Python alias/type/promotion/last-binding/namespace semantics, errors/spans,
new-key/growth/refusal ordering, genuine async callbacks, cancellation, pending
borrows/cleanup, shared ownership and frame balance. Reuse counting-loop/cased/native
word/stack tests on actual11/10, six complete scripts, then one bounded affected/
control comparison if allocation/control observations justify it. Stop/revise if
any native helper can actually reenter or preserving it needs another dispatcher.
This does not alter recursion/stack limits, reduce cancellation or predict speedup.
