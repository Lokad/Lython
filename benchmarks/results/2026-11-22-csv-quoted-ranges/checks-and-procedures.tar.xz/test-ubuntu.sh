set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/csv-quoted-ranges-20261122
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
logs=/mnt/d/code/Lython/.git/agent-notes/review-20261031/csv-quoted-ranges-20261122
filter='Category!=Stress&FullyQualifiedName~Csv'
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
  dotnet test "tests/$suite" -c Release -f net10.0 --filter "$filter" --verbosity quiet > "$logs/$suite-ubuntu.log" 2>&1 || { tail -45 "$logs/$suite-ubuntu.log"; exit 1; }
  grep 'Passed!' "$logs/$suite-ubuntu.log"
done
