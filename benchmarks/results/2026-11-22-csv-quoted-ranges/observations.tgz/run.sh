set -eu
root=/home/lokad/lython-bench-checks/csv-quoted-ranges-b1314-20261122
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
