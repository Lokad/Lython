from pathlib import Path
import fcntl, hashlib, json, os, shutil, stat, subprocess, tarfile

base=Path('/home/lokad/lython-bench-checks')
root=base/'rules-and-forwarding-b1018-20261119'
unit='lython-b1018-rules-and-forwarding-20261119.service'
assert root.resolve()==root and root.is_dir()
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
with (base/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    state=subprocess.check_output(['systemctl','show',unit,'--property=ActiveState,MainPID,Result'],text=True)
    assert 'ActiveState=failed' in state and 'MainPID=0' in state
    assert not subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).stdout
    fixture=root/'guest-fixtures'
    assert fixture.resolve()==fixture and os.path.ismount(fixture)
    assert subprocess.check_output(['findmnt','-n','-o','SOURCE,FSTYPE','--target',str(fixture)],text=True).split()==['lython-b1018-fixtures','tmpfs']
    raw=fixture/'profiles/annotated/perf.data'
    info=raw.lstat()
    assert raw.resolve()==raw and stat.S_ISREG(info.st_mode) and info.st_uid==0 and info.st_nlink==1
    digest=subprocess.check_output(['sudo','-n','sha256sum',str(raw)],text=True).split()[0]
    subprocess.run(['sudo','-n','chown',f'{os.getuid()}:{os.getgid()}',str(raw)],check=True)
    assert raw.lstat().st_ino==info.st_ino and sha(raw)==digest
    manifest=[]; files={}
    for path in sorted(fixture.rglob('*')):
        metadata=path.lstat()
        assert path.resolve()==path and metadata.st_uid==os.getuid()
        name=path.relative_to(fixture).as_posix()
        item=dict(path=name,mode=oct(metadata.st_mode),bytes=metadata.st_size,uid=metadata.st_uid)
        if stat.S_ISREG(metadata.st_mode):
            item['sha256']=sha(path);files[name]=item['sha256']
        else:
            assert stat.S_ISDIR(metadata.st_mode) or stat.S_ISFIFO(metadata.st_mode) or stat.S_ISSOCK(metadata.st_mode)
        manifest.append(item)
    (root/'failure-ram-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    subprocess.run(['journalctl','-u',unit,'--no-pager','-n','45'],stdout=(root/'failure-journal.txt').open('wb'),check=True)
    archive=root/'observations.tgz'
    assert not archive.exists()
    assert shutil.disk_usage(root).free>252*1024*1024+1_300_000
    with tarfile.open(archive,'x:gz') as export:
        for path in sorted(root.iterdir()):
            if path.is_file() and path!=archive:export.add(path,arcname=path.name)
        for name in files:export.add(fixture/name,arcname=name)
    with tarfile.open(archive) as exported:
        assert all(hashlib.sha256(exported.extractfile(name).read()).hexdigest()==digest for name,digest in files.items())
    subprocess.run(['sudo','-n','umount',str(fixture)],check=True)
    fixture.rmdir()
    out=dict(complete=False, allWorkersJoined=True, quietBeforeAndAfter=True, guestFixturesRemoved=True,
             archivedAndVerifiedUnderLease=True, ramTraceArchivedAndVerifiedBeforeUnmount=True,
             recoveredFrom='inherited two-workload capture ceiling and interrupted perf.data ownership normalization',
             archiveSHA256=sha(archive), freeBytes=shutil.disk_usage(root).free, perfOwnerChangedWithoutByteChanges=True)
    (root/'archive-receipt.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out))