from pathlib import Path
import subprocess
lab=Path(__file__).resolve().parent
endpoint='lokad@20.166.121.73'
options=['-i',str(Path.home()/'.ssh/id_lython-bench.pem'),'-o','BatchMode=yes','-o','ConnectTimeout=12']
result=subprocess.check_output(['ssh',*options,endpoint,'python3 -'],input=(lab/'recover-partial.py').read_bytes(),timeout=30)
(lab/'recovery.log').write_bytes(result)
print(result.decode())