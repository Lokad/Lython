from pathlib import Path
import ast,hashlib,json,subprocess

lab=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda d:hashlib.sha256(d).hexdigest()
canonical='benchmarks/results/2026-11-18-retained-closure-attribution/observations.tgz'
archived=subprocess.check_output(['git','show',f'origin/master:{canonical}'])
assert archived==Path(canonical).read_bytes()
digest=sha(archived)
receipt=load(Path(canonical).with_name('archive-receipt.json'))
assert receipt['complete'] and receipt['archiveSHA256']==digest
cfg=load(lab/'config.json')
assert not cfg['retireGroups']
cfg['retireGroups']=[dict(bytes=len(archived),sha256=digest,canonical=canonical,canonicalSHA256=digest,
                         committedBlobVerified=True,kind='exact archived measured replica',links=1,
                         paths=['retained-closure-profile-b1008-20261118/observations.tgz'])]
(lab/'config.json').write_text(json.dumps(cfg,indent=2)+'\n',encoding='utf-8')
launcher=lab/'remote-launch.py'
code=launcher.read_text(encoding='utf-8')
a,b=code.index('\nc=')+1,code.index('\nb=Path(')
code=code[:a]+'c='+repr(cfg)+code[b:]
ast.parse(code)
launcher.write_text(code,encoding='utf-8',newline='\n')
print('One verified trace duplicate is eligible for retirement under the fresh quiet-VM lease.')