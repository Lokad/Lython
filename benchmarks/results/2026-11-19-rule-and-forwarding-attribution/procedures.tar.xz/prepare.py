from pathlib import Path
import ast,hashlib,json,subprocess,tarfile

lab=Path(__file__).resolve().parent
donor=lab.parent/'abstract-value-facts-r589'
previous=lab.parent/'retained-closure-profile-r582'
scripts=lab.parent/'annotation-and-forwarding-cpython-r590'
read=lambda p:p.read_text(encoding='utf-8-sig')
load=lambda p:json.loads(read(p))
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(name,value):
    if name.endswith('.py'):ast.parse(value)
    (lab/name).write_text(value,encoding='utf-8',newline='\n')
def save(name,value):write(name,json.dumps(value,indent=2)+'\n')

old=load(previous/'config.json')
source=load(donor/'quiet/config.json')
terminal=load(donor/'quiet/terminal-status.json')
assert terminal['receipt']['complete'] and not terminal['remainingWorkers'] and not terminal['remainingTrace']
assert terminal['receipt']['archiveSHA256']==sha((donor/'quiet/observations.tgz').read_bytes())
image=source['identity']['imageFiles']['candidate']
assert image['Lokad.Lython.dll'].startswith('c9969271') and len(image)==32
assert {name:sha((donor/'frozen/candidate'/name).read_bytes()) for name in image}==image
verified=load(lab/'verify.json')
catalog=(scripts/'representative.json').read_bytes()
assert sha(catalog)==verified['catalogSha256'] and verified['state']=='Completed'
assert sha(catalog)==load(scripts/'identity.json')['catalogSHA256']
head=subprocess.check_output(['git','rev-parse','6c1da75b7'],text=True).strip()
assert not subprocess.check_output(['git','diff','--name-only','7a35af179',head,'--','src','tests'])
root='/home/lokad/lython-bench-checks/rules-and-forwarding-b1018-20261119'
unit='lython-b1018-rules-and-forwarding-20261119'
identity=dict(sourceRevision=head,purpose='Whole-script runtime after current forwarding and function definition changes',
              coreSHA256={'candidate':image['Lokad.Lython.dll']},imageFiles={'candidate':image},
              catalogSHA256=sha(catalog),diagnosticOnly=True,publicationHeld=True)
save('identity.json',identity)
(lab/'catalog.json').write_bytes(catalog)
jobs=[('forwarding','scripts.report-forwarding.expanded','warm'),
      ('rules','scripts.rule-default-closures','warm'),
      ('annotated','scripts.annotated-rule-closures','warm')]
case_labels=[name for name,_,_ in jobs]
ops=read(previous/'ops-profile.py').replace(old['root'],root)
a=ops.index('    for name, case_id, lane in ')
b=ops.index(':\n',a)
write('ops-profile.py',ops[:a]+'    for name, case_id, lane in '+repr(jobs)+ops[b:])
collect=read(previous/'collect.py').replace(old['root'],root).replace("['rules', 'annotated']",repr(case_labels))
collect=collect.replace('len(records)==2','len(records)==3')
a=collect.index("source='R582/B1008")
b=collect.index("',performanceComparison",a)
write('collect.py',collect[:a]+f"source='R592/B1018 {head}/c9969271 whole-script runtime CPU attribution"+collect[b:])
write('run.sh',read(previous/'run.sh').replace(old['root'],root))
write('launch.py',read(previous/'launch.py').replace('Retained closure CPU attribution','Retained rules and forwarding CPU attribution'))
write('retrieve.py',read(previous/'retrieve.py'))
analysis=read(previous/'analyze.py').replace("['rules', 'annotated']",repr(case_labels))
analysis=analysis.replace("     'formatting':", """     'trailing mapping and native call operands':('StartNativeCall','TryStartBoundInvocation','BindPreparedKeywords','BuildFixedFunctionKeywords','BuildTrailingCallDictionary','InvokeTrailing'),
     'formatting':""")
write('analyze.py',analysis)
names=['identity.json','catalog.json','ops-profile.py','collect.py','run.sh']
with tarfile.open(lab/'payload.tgz','w:gz') as out:
    for name in names: out.add(lab/name,arcname=name)
expanded=sum((lab/name).stat().st_size for name in names)
cfg=dict(root=root,unit=unit,source=source['root'],sourceFiles=image,sourceCatalogSHA256=source['catalogSHA256'],
         catalogSHA256=sha(catalog),identity=identity,retireGroups=[],payloadBytes=(lab/'payload.tgz').stat().st_size,
         payloadSHA256=sha((lab/'payload.tgz').read_bytes()),unpackedBytes=expanded)
save('config.json',cfg)
launcher=read(previous/'remote-launch.py')
a,b=launcher.index('\nc=')+1,launcher.index('\nb=Path(')
write('remote-launch.py',(launcher[:a]+'c='+repr(cfg)+launcher[b:]).replace('lython-b1008-fixtures','lython-b1018-fixtures'))
print('Three verified whole-script runtime workloads are ready for the next idle quiet-VM lease.')