from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile

lab=Path(__file__).resolve().parent
out=lab/'annotation-confirmation'; out.mkdir(exist_ok=False)
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda content:hashlib.sha256(content).hexdigest()
def write(name,value):
    if name.endswith('.py'):ast.parse(value)
    (out/name).write_text(value,encoding='utf-8',newline='\n')
def read(name):return (lab/name).read_text(encoding='utf-8')

config=load(lab/'config.json')
assert load(lab/'archive-receipt.json')['guestFixturesRemoved']
old=config['root']
root=old+'-annotated'
unit=config['unit']+'-annotated'
raw=read('ops-profile.py').replace(old,root)
raw=raw.replace("[('forwarding', 'scripts.report-forwarding.expanded', 'warm'), ('rules', 'scripts.rule-default-closures', 'warm'), ('annotated', 'scripts.annotated-rule-closures', 'warm')]","[('annotated', 'scripts.annotated-rule-closures', 'warm')]")
assert "for name, case_id, lane in [('annotated'" in raw
# Normalize exact joined trace ownership on both success and failure.
start=raw.index("        raw = folder/'perf.data'; metadata")
stop=raw.index("        with (folder/'perf-report.txt')",start)
block=raw[start:stop]
raw=raw[:start]+raw[stop:]
normalize=block.replace("raw = folder/'perf.data'; metadata = raw.lstat()","raw = folder/'perf.data'; metadata = raw.lstat()")
at=raw.index('            retired_maps = []')
lines=''.join('    '+line+'\n' for line in normalize.splitlines())
raw=raw[:at]+"            if (folder/'perf.data').exists():\n"+''.join('    '+line+'\n' for line in lines.splitlines())+raw[at:]
write('ops-profile.py',raw)
collect=read('collect.py').replace(old,root).replace("['forwarding', 'rules', 'annotated']","['annotated']").replace('len(records)==3','len(records)==1')
write('collect.py',collect)
write('run.sh',read('run.sh').replace(old,root))
write('launch.py',read('launch.py').replace('Retained rules and forwarding CPU attribution','Annotated runtime CPU confirmation').replace('seconds=70','seconds=32').replace('before70 seconds','before 32 seconds'))
write('retrieve.py',read('retrieve.py'))
write('analyze.py',read('analyze.py').replace("['forwarding', 'rules', 'annotated']","['annotated']"))
for name in ['identity.json','catalog.json']:shutil.copyfile(lab/name,out/name)
names=['identity.json','catalog.json','ops-profile.py','collect.py','run.sh']
payload=out/'payload.tgz'
with tarfile.open(payload,'w:gz') as target:
    for name in names:target.add(out/name,arcname=name)
groups=[]
for case, path in [
    ('2026-11-19-rule-and-forwarding-attribution','rules-and-forwarding-b1018-20261119'),
    ('2026-11-18-abstract-value-facts','abstract-value-facts-b1015-20261118'),
    ('2026-11-18-annotation-and-forwarding-cpython','annotation-and-forwarding-cpython-b1016-20261118'),
]:
    canonical=f'benchmarks/results/{case}/observations.tgz'
    archived=subprocess.check_output(['git','show',f'origin/master:{canonical}'])
    assert archived==Path(canonical).read_bytes()
    digest=sha(archived)
    assert digest==load(Path(canonical).with_name('archive-receipt.json'))['archiveSHA256']
    groups.append(dict(bytes=len(archived),sha256=digest,canonical=canonical,canonicalSHA256=digest,
                       committedBlobVerified=True,kind='exact archived measured replica',links=1,
                       paths=[f'{path}/observations.tgz']))
config.update(root=root,unit=unit,retireGroups=groups,payloadBytes=payload.stat().st_size,
              payloadSHA256=sha(payload.read_bytes()),unpackedBytes=sum((out/n).stat().st_size for n in names))
write('config.json',json.dumps(config,indent=2)+'\n')
launcher=read('remote-launch.py')
a,b=launcher.index('\nc=')+1,launcher.index('\nb=Path(')
write('remote-launch.py',(launcher[:a]+'c='+repr(config)+launcher[b:]).replace('lython-b1018-fixtures','lython-b1018-annotated-fixtures'))
print('The one-workload confirmation verifies the same image and catalog. The original trace is committed.')