set -eu
root=/home/lokad/lython-bench-checks/rules-and-forwarding-b1018-20261119-annotated
trap 'result=$?; printf "%s\n" "$result" > "$root/exit-code.txt"' EXIT
python3 "$root/collect.py"
