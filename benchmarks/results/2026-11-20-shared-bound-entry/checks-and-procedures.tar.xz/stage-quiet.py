import ast
import hashlib
import json
from pathlib import Path
import re
import shutil
import tarfile

lab = Path(__file__).resolve().parent
prior = lab.parent / "prepared-postponed-text" / "quiet"
template = lab.parent / "private-keyword-mapping-r660"
previous = template / "quiet"
quiet = lab / "quiet"
def read(path):
    return path.read_text(encoding="utf-8-sig")
def load(path):
    return json.loads(read(path))
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path, value):
    if path.suffix == ".py":
        ast.parse(value)
    path.write_text(value, encoding="utf-8", newline="\n")
def save(path, value):
    write(path, json.dumps(value, ensure_ascii=False, indent=2) + "\n")

old = load(prior / "config.json")
template_config = load(previous / "config.json")
donor_archive=load(prior/"archive-receipt.json")
assert donor_archive["complete"] and donor_archive["archivedAndVerifiedUnderLease"]
minimum_headroom = 174 * 1024 * 1024
pair = load(lab / "frozen-identity.json")
catalog = lab / "catalog.json"
images = pair["images"]
source_files = old["identity"]["imageFiles"]["candidate"]
core = "Lokad.Lython.dll"
assert {n:h for n,h in source_files.items() if n != core} == {
    n:h for n,h in images["reference"].items() if n != core}
assert pair["casesSHA256"] == sha(catalog)
for role, files in images.items():
    assert len(files) == 32 and files == source_files | {core: files[core]}
    assert {name: sha(lab / "frozen" / role / name) for name in files} == files
    verified = load(lab / f"{role}-verify.json")
    assert verified["state"] == "Completed" and verified["catalogSha256"] == sha(catalog)

quiet.mkdir(exist_ok=True)
for role in images:
    image = quiet / role
    image.mkdir(exist_ok=True)
    shutil.copyfile(lab / "frozen" / role / core, image / core)
shutil.copyfile(catalog, quiet / "representative.json")
identity = dict(sourceRevision=pair["referenceCommit"] + " versus " + pair["candidateCommit"],
    purpose="Shared bound invocation entry for linear calls and callbacks", imageFiles=images,
    catalogSHA256=sha(catalog), normalAdapterPin="0.4.0",
    coreSHA256={label: images[role][core] for role in images for label in (role, role + "-control")})
save(quiet / "identity.json", identity)

root = "/home/lokad/lython-bench-checks/shared-bound-entry-b1157-20261120"
unit = "lython-b1157-shared-bound-entry-20261120"
for name in ("collect.py", "archive-owned.py", "run.sh", "retrieve.py"):
    source = read(previous / name).replace(template_config["root"], root)
    source = source.replace("Completed machine integer prefix", "Completed machine integer prefix source pair")
    if name == "collect.py":
        a,b=source.index("\njobs = "),source.index("\nassert len(jobs)")
        jobs = [('scripts.json-object-hook-rules', 'warm'), ('scripts.stable-sort-record-keys', 'warm'), ('scripts.annotated-rule-closures', 'warm'), ('scripts.captured-rule-closures', 'warm'), ('scripts.csv-invoice.large', 'warm'), ('scripts.json-object-hook-rules', 'compile-run')]
        source=source[:a]+"\njobs = "+repr(jobs)+source[b:]
    source = source.replace("len(jobs)==6","len(jobs)==6").replace("len(raw['jobs'])==6","len(raw['jobs'])==6").replace("jobs=6,","jobs=6,").replace("['jobs']==6","['jobs']==6")
    if name == "collect.py":
        source = source.replace("accumulate8seconds", "accumulate10seconds").replace("warmupSeconds=8", "warmupSeconds=10")
        source = source.replace("min(warmed)<8", "min(warmed)<10").replace("warmed[i]>=8", "warmed[i]>=10")
        source = source.replace("Deferred factory frame source pair", "Shared bound entry source pair")
    if name == "retrieve.py":
        source = source.replace("Deferred factory frame source pair", "Shared bound entry source pair")
    if name == "archive-owned.py":
        source=source.replace(str(192*1024*1024), str(minimum_headroom))
    write(quiet / name, source)
write(lab / "launch-quiet.py", read(template / "launch-quiet.py").replace(
    "Separated default and explicit trim scan", "Shared bound entry").replace("323","355"))
write(lab / "summarize-quiet.py", read(template / "summarize-quiet.py").replace("len(raw['jobs'])==6","len(raw['jobs'])==6"))
parts = ["collect.py", "archive-owned.py", "run.sh", "identity.json", "representative.json",
         "candidate/" + core, "reference/" + core]
payload = quiet / "payload.tgz"
with tarfile.open(payload, "w:gz") as archive:
    for part in parts:
        archive.add(quiet / part, arcname=part)
expanded = sum((quiet / part).stat().st_size for part in parts)
archive_headroom = 1280 * 1024 # The latest comparable runs used under 900 KiB after staging. Preserve the 174 MiB floor.
needed = minimum_headroom + expanded + archive_headroom
space = load(lab / "quiet-space.json")
available = space["freeBytes"]
selected = []
for proof in sorted(space["replicas"], key=lambda item: -item["bytes"]):
    if available > needed + 49152:
        break
    assert proof["sha256"] != source_files[core]
    assert proof["committedBlobVerified"]
    available += proof["bytes"]
    selected.append(proof)
save(lab / "preflight.json", dict(available=available, need=needed, withoutRetirement=space["freeBytes"], selected=selected))
assert available > needed, (available, needed)

config = dict(root=root, unit=unit, source=old["root"], sourceRole="candidate",
              sourceFiles=source_files, sourceCatalogSHA256=old["catalogSHA256"],
              protocolSHA256=old["protocolSHA256"],
              catalogSHA256=sha(catalog), identity=identity, retireGroups=selected, donorArchiveSHA256=donor_archive["archiveSHA256"],
              payloadBytes=payload.stat().st_size, payloadSHA256=sha(payload), unpackedBytes=expanded)
save(quiet / "config.json", config)
launcher = read(lab.parent / "prepared-compiler-bindings-r627" / "quiet" / "remote-launch.py")
a, b = launcher.index("\nc=") + 1, launcher.index("\nb=Path(")
launcher = launcher[:a] + "c=" + repr(config) + launcher[b:]
launcher = re.sub(r"lython-b[0-9]+-fixtures", "lython-b1157-fixtures", launcher)
launcher = launcher.replace(str(200*1024*1024), str(minimum_headroom)).replace("+2097152,", f"+{archive_headroom},")
assert sha(lab.parent / "factory-cpython-b1151" / "cpython-worker.py") == config["protocolSHA256"]
launcher = launcher.replace(" payload=sys.stdin.buffer.read", " assert sha(source/'cpython-worker.py')==c['protocolSHA256']\n payload=sys.stdin.buffer.read")
write(quiet / "remote-launch.py", launcher)
print("Verified both full images and the five-case, six-job plan. Staging headroom", available - needed, "bytes.")

collector = read(quiet / 'collect.py')
archive = read(quiet / 'archive-owned.py')
assert 'assert len(jobs)==6' in collector
assert "len(raw['jobs'])==6" in archive and 'jobs=6,' in archive
assert "['jobs']==6" in read(quiet / 'retrieve.py')
assert "len(raw['jobs'])==6" in read(lab / 'summarize-quiet.py')

staged = load(quiet / 'config.json')
assert sha(quiet / 'candidate' / core) == images['candidate'][core]
assert staged['sourceFiles'] == source_files and staged['sourceRole'] == 'candidate'
assert sha(quiet / "reference" / core) == images["reference"][core]
assert 'timedelta(seconds=355)' in read(lab / 'launch-quiet.py')

assert 'warmupSeconds=10' in collector and 'warmed[i]>=10' in collector
assert 'RuntimeMaxSec=540' in read(quiet / 'remote-launch.py')
assert len({case for case, lane in ast.literal_eval(re.search(r'^jobs = (.*)$', collector, re.M).group(1))}) == 5
