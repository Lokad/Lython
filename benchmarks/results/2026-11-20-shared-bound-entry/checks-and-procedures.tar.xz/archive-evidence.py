from pathlib import Path
import gzip
import hashlib
import json
import shutil
import tarfile

lab = Path(__file__).resolve().parent
quiet = lab / 'quiet'
out = Path('benchmarks/results/2026-11-20-shared-bound-entry')
def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

terminal = read(quiet/'terminal-status.json')
receipt = read(quiet/'archive-receipt.json')
assert terminal['exitCode'] == '0' and terminal['receipt'] == receipt
assert not terminal['remainingWorkers'] and not terminal['remainingTrace']
assert all(receipt[name] for name in ('complete','quietBeforeAndAfter','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
assert receipt['jobs'] == 6 and receipt['archiveSHA256'] == sha(quiet/'observations.tgz')
identity = read(lab/'frozen-identity.json')
assert identity['referenceCommit'].startswith('9bdd10a70') and identity['candidateCommit'].startswith('87a269f2b')
assert identity['casesSHA256'] == sha(lab/'catalog.json')
for role, files in identity['images'].items():
    assert len(files) == 32
    assert {name: sha(lab/'frozen'/role/name) for name in files} == files
    verified = read(lab/(role+'-verify.json'))
    assert verified['state'] == 'Completed' and verified['catalogSha256'] == identity['casesSHA256']

raw = read(quiet/'retrieved/confirmation/confirmation.json')
assert raw['complete'] and len(raw['jobs']) == 6 and raw['warmupSeconds'] >= 10
cases = {case['id']: case for case in read(lab/'catalog.json')['cases']}
observed_batches = 0
for row in raw['jobs']:
    case, lane = cases[row['case']], row['lane']
    assert row['workersJoinedAndFixturesRemoved']
    for label, worker in row['identities'].items():
        role = label.split('-', 1)[0]
        files = identity['images'][role]
        observed = {Path(lib['path']).name: lib['sha256'].lower() for lib in worker['libraries']}
        assert observed['Lokad.Lython.dll'] == files['Lokad.Lython.dll']
        assert all(observed[name] == files[name] for name in observed.keys() & files.keys())
    for sample in row['samples']:
        result = sample['response']
        assert result['status'] == 'Completed' and result['completedInvocations'] > 0
        for key in ('sourceSha256', 'fixtureSha256', 'expectedOutputSha256'):
            assert result[key] == case[key]
        assert result.get('actualOutputSha256') == (None if lane == 'compile' else case['expectedOutputSha256'])
        assert result.get('actualFilesSha256') == (None if lane == 'compile' else case.get('expectedFilesSha256'))
        observed_batches += 1
assert observed_batches == 120

out.mkdir(exist_ok=True)
for name in ('archive-receipt.json','terminal-status.json','observations.tgz'):
    shutil.copyfile(quiet/name, out/name)
summary = read(lab/'quiet-summary.json')
summary.update(reference=identity['referenceCommit'], candidate=identity['candidateCommit'],
               cores={role: files['Lokad.Lython.dll'] for role,files in identity['images'].items()},
               archiveSHA256=receipt['archiveSHA256'])
(out/'summary.json').write_text(json.dumps(summary, indent=2)+'\n', encoding='utf8', newline='\n')
for role, binary in [('reference','reference-core.dll.gz'),('candidate','measured-core.dll.gz')]:
    (out/binary).write_bytes(gzip.compress((lab/'frozen'/role/'Lokad.Lython.dll').read_bytes(),mtime=0))
with tarfile.open(out/'checks-and-procedures.tar.xz','w:xz',preset=6) as tar:
    for name in ('prepare-pair.py','freeze-and-verify.py','measured-source.patch','catalog.json','catalog-initial.json','frozen-identity.json',
                 'reference-verify.json','candidate-verify.json','reference-allocation.json','candidate-allocation.json','verification.log',
                 'initial-fixture-verify.log','windows-public.log','windows-whitebox.log','ubuntu-public.log','ubuntu-whitebox.log',
                 'test-ubuntu.sh','stage-quiet.py','prove-quiet-space.py','launch-quiet.py','summarize-quiet.py','archive-evidence.py','preflight.json',
                 'stage.log','quiet-space.json','retrieval.log'):
        tar.add(lab/name,arcname=name)
    for name in ('identity.json','config.json','collect.py','archive-owned.py','run.sh','remote-launch.py','retrieve.py',
                 'launch.log','observe-not-before.json'):
        tar.add(quiet/name,arcname='quiet/'+name)
print('Verified both 32-file images, five CPython goldens, six lanes and 120 batch records.')
