set -euo pipefail
cd /mnt/d/code/Lython/.git/agent-worktrees/shared-bound-entry
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab=../../agent-notes/review-20261031/shared-bound-entry
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Json|FullyQualifiedName~Sort|FullyQualifiedName~Function|FullyQualifiedName~Default|FullyQualifiedName~Generator|FullyQualifiedName~Interruption|FullyQualifiedName~Recursion|FullyQualifiedName~Stack|FullyQualifiedName~Callback|FullyQualifiedName~AdmissionFailureCommand)&Category!=Stress' 2>&1 | tee "$lab/ubuntu-public.log"
dotnet test tests/Lokad.Lython.Tests -c Release -f net10.0 --filter '(FullyQualifiedName~Call|FullyQualifiedName~Frame|FullyQualifiedName~Executable|FullyQualifiedName~Workspace)&Category!=Stress' 2>&1 | tee "$lab/ubuntu-whitebox.log"
