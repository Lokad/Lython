from pathlib import Path
import base64, hashlib, json, subprocess, tempfile

lab=Path(__file__).resolve().parent
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
put=lambda name,s:(lab/name).write_text(s,encoding='utf-8',newline='\n')
sha=lambda b:hashlib.sha256(b).hexdigest()
root=lab.parent
donor=root/'prepared-postponed-text'
catalog=load(donor/'catalog.json')
cases={row['id']:row for row in catalog['cases']}
catalog['cases']=[cases['scripts.annotated-rule-closures'], cases['scripts.csv-invoice.large']]
more=load(root/'compiled-definition-keys'/'catalog.json')
captured_id='scripts.captured-rule-closures'
captured=next((row for row in more['cases'] if row['id']==captured_id),None)
if captured is None:
    for path in (root/'factory-cpython-b1151', root/'retained-inline-lexical-entry-b1117', root/'csv-rule-cpython-b1143',
        root/'current-rule-checkpoint-profile', root/'retained-lexical-cpython-b1122'):
        for file in (path/'representative.json',path/'catalog.json'):
            if file.exists():
                captured=next((row for row in load(file)['cases'] if row['id']==captured_id),None)
                if captured is not None:break
        if captured is not None:break
assert captured is not None, captured_id
catalog['cases'].insert(1,captured)
records=[dict(code=i,rank=(i*73)%19, name=f"région {i%53:02d}",units=i%31+1) for i in range(768)]
data=json.dumps(records,ensure_ascii=False,separators=(',',':')).encode('utf-8')+b'\n'
fixture=json.dumps(dict(size=len(records),text=None,inputFiles={'records.json':base64.b64encode(data).decode('ascii')},outputFiles={}),
    separators=(',',':'),ensure_ascii=False)
sources={
'json-object-hook-rules':"""import json
def rule(row):
    def amount(scale=row["rank"] + 1):
        return row["units"] * scale
    return amount
with open("records.json", encoding="utf-8") as stream:
    rules = json.load(stream, object_hook=rule)
print(sum(entry() for entry in rules), rules[-1]())
""",
'stable-sort-record-keys':"""import json
def key(row):
    def by_region():
        return row["rank"], row["name"]
    return by_region()
with open("records.json", encoding="utf-8") as stream:
    records = json.load(stream)
ordered = sorted(records, key=key)
print(ordered[0]["code"], ordered[-1]["code"], sum(row["units"] for row in ordered[:64]))
"""}
for name,source in sources.items():
    with tempfile.TemporaryDirectory(prefix='lython-callback-catalog-') as folder:
        (Path(folder)/'records.json').write_bytes(data)
        expected=subprocess.run(['C:/Python313/python.exe','-I','-X','utf8','-'],
            input=source.encode('utf-8'),cwd=folder,stdout=subprocess.PIPE,check=True).stdout.replace(b'\r\n',b'\n')
    catalog['cases'].append(dict(id='scripts.'+name, family='scripts',category='callback',scale='medium',size=len(records),
        source=source,fixtureJson=fixture,expectedOutput=expected.decode('utf-8'),
        sourceUtf8Bytes=len(source.encode('utf-8')),expectedOutputUtf8Bytes=len(expected),fixtureTextUtf8Bytes=0,
        fixtureTextCodePoints=0,sourceSha256=sha(source.encode('utf-8')),fixtureSha256=sha(fixture.encode('utf-8')),
        expectedOutputSha256=sha(expected),expectedFilesSha256=sha(bytes(4))))
assert len(catalog['cases'])==5
put('catalog.json',json.dumps(catalog,indent=2,ensure_ascii=False)+'\n')

code=(donor/'freeze-and-verify.py').read_text(encoding='utf-8')
code=code.replace("previous=lab.parent/'prepared-mutation-calls'","previous=lab.parent/'ordered-class-headers'")
code=code.replace("trial=repo/'.git/agent-worktrees/prepared-postponed-text'","trial=repo/'.git/agent-worktrees/shared-bound-entry'")
code=code.replace("ref=git('rev-parse','e025a7f1c')","ref=git('rev-parse','9bdd10a70')")
code=code.replace("manifest=load(previous/'quiet/identity.json')","manifest=load(previous/'frozen-identity.json')")
code=code.replace("manifest['imageFiles']['candidate']","manifest['images']['candidate']")
code=code.replace('== 6','== 5').replace('all six cases','all five cases')
put('freeze-and-verify.py',code)

