def record():
    with open('cleanup.txt', 'a') as target:
        target.write('cleanup\n')
try:
    raise ValueError('active')
except ValueError as error:
    for i in range(3):
        if i == 0:
            continue
        print(str(error))
        break
    try:
        raise
    except ValueError:
        print('reraised')
    record()
try:
    error
except NameError:
    print('cleared')
