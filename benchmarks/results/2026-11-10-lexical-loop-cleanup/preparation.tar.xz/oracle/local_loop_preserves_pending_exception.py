def record():
    with open('cleanup.txt', 'a') as target:
        target.write('cleanup\n')
try:
    try:
        raise ValueError('kept')
    finally:
        i = 0
        while True:
            i += 1
            if i == 1:
                continue
            print('loop', i)
            break
        record()
except ValueError as error:
    print(str(error))
