def record():
    with open('cleanup.txt', 'a') as target:
        target.write('cleanup\n')
def keep():
    try:
        return 'kept'
    finally:
        for i in range(3):
            if i == 0:
                continue
            print('loop', i)
            break
        record()
print(keep())
