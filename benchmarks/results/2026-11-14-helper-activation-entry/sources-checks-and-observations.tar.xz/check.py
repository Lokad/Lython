from pathlib import Path
import hashlib,json,os,shutil,subprocess,xml.etree.ElementTree as ET
r=Path(__file__).parent;env={k:v for k,v in os.environ.items()if k.casefold()!='path'};env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['PATH']=env['DOTNET_ROOT']+';C:/Python313;'+os.environ.get('PATH','');sdk=env['DOTNET_ROOT']+'/dotnet.exe';rows=[]
selections={'Lokad.Lython.Tests':['SimpleFunctionExecutionBoundaryTests','ComposedNativeCallTests','CompletedHelperCallOwnershipTests','OwnedTupleReturnTests','NativeTupleReturnTests','FunctionWorkspaceOwnershipTests','FunctionBodyTemporaryLifetimeTests','CallBindingSubsystemTests','FunctionDefaultConstructionTests','ReentrantAdmissionOwnershipTests','ManagedStackGuardTests','ExecutableCallTransferTests','DeferredFunctionOwnershipTests','NativeIntegerChainTests','NativeSequenceAdmissionTests'], 'Lokad.Lython.PublicApi.Tests':['OrdinaryFunctionCallTests','OrdinaryMethodCallTests','PreparedFunctionDefaultsTests','PreparedFunctionHostLifetimeTests','ReceiverFunctionLifetimeTests','ReceiverFunctionEntryTests','OrderedFunctionContinuationTests','PositionalCallSemanticsTests','PrefixCallCompatibilityTests','NativeTupleReturnTests','FrameIntegerLifetimeTests','ForHelperExecutionTests','WhileHelperExecutionTests','RangeHelperExecutionTests','StackGuardScenarioTests']}
for framework in ['net11.0','net10.0']:
    log=r/('probe-build-'+framework+'.log')
    with log.open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([sdk,'build','tools/LythonProbe/LythonProbe.csproj','-c','Release','-f',framework,'--no-restore','--no-incremental','--disable-build-servers','-m:1','-v','quiet'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
    assert done.returncode==0,log.read_text(encoding='utf-8')[-4000:]
    print(framework,'forced probe/core build pass',flush=True)
    for project,classes in selections.items():
        name='r364-'+project+'-'+framework+'.trx';log=r/(project+'-'+framework+'.log');selection='(Category!=Stress)&('+'|'.join('FullyQualifiedName~'+v for v in classes)+')'
        with log.open('w',encoding='utf-8',newline='\n')as f:done=subprocess.run([sdk,'test','tests/'+project+'/'+project+'.csproj','-c','Release','-f',framework,'--no-restore','--filter',selection,'--logger','trx;LogFileName='+name,'-v','quiet'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=240)
        trx=Path('tests')/project/'TestResults'/name;counts=ET.parse(trx).find('.//{http://microsoft.com/schemas/VisualStudio/TeamTest/2010}Counters').attrib if trx.exists()else None
        if trx.exists():shutil.copyfile(trx,r/name)
        rows.append(dict(framework=framework,project=project,selection=selection,exitCode=done.returncode,counters=counts));(r/'focused-checks.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n')
        assert done.returncode==0,log.read_text(encoding='utf-8')[-5000:]
        print(framework,project,counts['passed'],'activation/binding/cleanup/stack checks pass',flush=True)
baseline=json.loads((r/'baseline.json').read_text(encoding='utf-8'));changed=[n for n,h in baseline['sources'].items()if hashlib.sha256(Path(n).read_bytes()).hexdigest()!=h];assert changed==['src/Lokad.Lython/Runtime/PyExecutableFunction.cs'];print('Only one production input changed; existing tests reused.',flush=True)
