from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent;p=r/'node-method';p.mkdir()
original=json.loads((r/'identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(f).read_bytes()).hexdigest()==h for f,h in original['productionSources'].items())

f=Path('src/Lokad.Lython/Frontend/ExecutableNativeBody.cs');s=f.read_text(encoding='utf-8')
s='using Lokad.Lython.Runtime;\n\n'+s
s=s.replace('    ReceiverMethod,','    StringMethod, BytesMethod, BooleanMethod, ListMethod,')
s=s.replace('int First, int Second);','int First, int Second,\n    LythonRuntime.ReceiverMethod? Method = null);')
f.write_text(s,encoding='utf-8',newline='\n')
f=Path('src/Lokad.Lython/Frontend/ExecutableScript.cs');s=f.read_text(encoding='utf-8')
a=s.index('    // Prepared once with the closed native body, before publication.');b=s.index('    public int NativeArgumentIndex',a)
s=s[:a]+s[b:];f.write_text(s,encoding='utf-8',newline='\n')

f=Path('src/Lokad.Lython/Frontend/ExecutableScript.NativeReturns.cs');s=f.read_text(encoding='utf-8')
s=s.replace('            var operation = NativeReturnOperation.Read;','            var operation = NativeReturnOperation.Read;\n            LythonRuntime.ReceiverMethod? nativeMethod = null;')
s=s.replace('''                            site.NativeReceiverMethod = method;
                            site.NativeReceiverReturnShape = shape;
                            operation = NativeReturnOperation.ReceiverMethod;''','''                            nativeMethod = method;
                            operation = shape switch
                            {
                                StaticReturnShape.String => NativeReturnOperation.StringMethod,
                                StaticReturnShape.Bytes => NativeReturnOperation.BytesMethod,
                                StaticReturnShape.Boolean => NativeReturnOperation.BooleanMethod,
                                _ => NativeReturnOperation.ListMethod,
                            };''')
s=s.replace('values[first].Operation == NativeReturnOperation.ReceiverMethod','values[first].Operation == NativeReturnOperation.StringMethod')
s=s.replace('var producer = CallSites[instructions[values[first].SourceInstruction].CallSiteIndex].NativeReceiverMethod;','var producer = values[first].Method;')
s=s.replace('values.Add(new(operation, index, first, second));','values.Add(new(operation, index, first, second, nativeMethod));')
f.write_text(s,encoding='utf-8',newline='\n')

f=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeReturn.cs');s=f.read_text(encoding='utf-8')
a=s.index('            case NativeReturnOperation.ReceiverMethod:');b=s.index('            case NativeReturnOperation.SplitLowerWhitespace',a)
s=s[:a]+'''            case NativeReturnOperation.StringMethod or NativeReturnOperation.BytesMethod
                or NativeReturnOperation.BooleanMethod or NativeReturnOperation.ListMethod:
                shape = value.Operation switch
                {
                    NativeReturnOperation.StringMethod => NativeReturnShape.String,
                    NativeReturnOperation.BytesMethod => NativeReturnShape.Bytes,
                    NativeReturnOperation.BooleanMethod => NativeReturnShape.Boolean,
                    _ => NativeReturnShape.Sized,
                };
                return first == NativeReturnShape.String;
'''+s[b:]
s=s.replace('''            if (value.Operation == NativeReturnOperation.ReceiverMethod)
                return InvokeReceiverMethod(site.NativeReceiverMethod!, receiver, site.CallSpan, context);''','''            if (value.Method is { } method)
                return InvokeReceiverMethod(method, receiver, site.CallSpan, context);''')
f.write_text(s,encoding='utf-8',newline='\n')
(p/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython','tests/Lokad.Lython.PublicApi.Tests/NativeReturnFunctionTests.cs']))
shutil.copyfile('PLAN.md',p/'pre-validation-plan.md')
print('Prepared method reference now belongs to its native value node. Two fields removed from every call site; generic result-shape operations reuse existing facts. Initial source/core/adverse comparisons preserved.')
