from pathlib import Path
import hashlib,json,os,re,shutil,subprocess
r=Path(__file__).resolve().parent;p=r/'node-method'
for n in ['catalog.json','independent-goldens.json']:shutil.copyfile(r/n,p/n)
for role in ['before','candidate']:shutil.copytree(r/'images/before',p/'images'/role,copy_function=os.link)
core=p/'images/candidate/Lokad.Lython.dll';core.unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',core)
checks={}
for name,expected in [('internal-node11',397),('public-node11',2164),('internal-node10',397),('public-node10',2164)]:
 s=(r/(name+'.log')).read_text(encoding='utf-8');assert 'Failed:     0'in s and re.search(r'Passed:\s+'+str(expected)+r'\b',s);checks[name]=dict(passed=expected)
inventory={str(f).replace('\\','/'):hashlib.sha256(f.read_bytes()).hexdigest()for f in Path('src/Lokad.Lython').rglob('*')if f.is_file()and not {'bin','obj'}&set(f.parts)}
base=json.loads((r/'identity.json').read_text(encoding='utf-8'))
(p/'identity.json').write_text(json.dumps(dict(baselineSource=base['baselineSource'],candidateSource='16e14ee0 plus R89 node-owned canonical native-method/shared return-fact patch',coreSHA256={role:hashlib.sha256((p/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']},productionSources=inventory,baselineProductionSources=base['baselineProductionSources'],focusedChecks=checks,qualification='397internal/2164public focused Release per actual.NET11/10 pass; includes 2 independently CPython-checked composition/dynamic-receiver cases. Controlled comparison/full delivery pending.'),indent=2)+'\n',encoding='utf-8')
(p/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython','tests/Lokad.Lython.PublicApi.Tests/NativeReturnFunctionTests.cs']))
s=(r/'measure.py').read_text(encoding='utf-8').replace("old=r.parent/'integer-utf8-r45'","old=r.parent.parent/'integer-utf8-r45'")
(p/'measure.py').write_text(s,encoding='utf-8')
s=(r/'assess-local.py').read_text(encoding='utf-8').replace('Preserve all adverse controls and original 17 functional failures before signature correction.','Preserve original call-site-metadata prototype and all adverse/unstable controls. No new controlled elapsed claim.')
(p/'assess-local.py').write_text(s,encoding='utf-8');shutil.copyfile('PLAN.md',p/'pre-measurement-plan.md')
print('Refined node-owned method/source/core frozen; focused397/2164 per actual11/10 pass, original prototype and adverse raw data retained.')
