from pathlib import Path
import copy,hashlib,json,os,shutil,subprocess
r=Path(__file__).resolve().parent;prior=r.parent/'receiver-contract-r85/binding-correction'
base=json.loads((prior/'identity.json').read_text(encoding='utf-8'))
d=json.loads((prior/'catalog.json').read_text(encoding='utf-8'));checkpoint=json.loads((r.parent/'combined-cpython-r83/representative.json').read_text(encoding='utf-8'))
byid={c['id']:c for c in [*d['cases'],*checkpoint['cases']]}
ids=['scripts.text-summary-rsplit-helpers.large','scripts.text-summary-casefold-helpers.large','scripts.text-summary-helpers.large','scripts.csv-summary-functions.large','scripts.report-render.large']
d['cases']=[byid[id]for id in ids];assert len(d['cases'])==5
for c in d['cases']:
 for field,digest in [('source','sourceSha256'),('fixtureJson','fixtureSha256'),('expectedOutput','expectedOutputSha256')]:assert hashlib.sha256(c[field].encode('utf-8')).hexdigest()==c[digest]
(r/'catalog.json').write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for role in ['before','candidate']:shutil.copytree(prior/'images/candidate',r/'images'/role,copy_function=os.link)
p=r/'images/candidate/Lokad.Lython.dll';p.unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',p)
inventory={str(p).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest()for p in Path('src/Lokad.Lython').rglob('*')if p.is_file()and not {'bin','obj'}&set(p.parts)}
checks={}
for name,expected in [('internal-prototype11',373),('internal-native-boundary11',24),('public-prototype11',2162),('public-new-cases11',42),('internal-prototype10',397),('public-prototype10',2164)]:
 s=(r/(name+'.log')).read_text(encoding='utf-8');assert 'Failed:     0'in s and __import__('re').search(r'Passed:\s+'+str(expected)+r'\b',s);checks[name]=dict(passed=expected)
identity=dict(baselineSource='7796a24f (CI42459221409 running)',candidateSource='16e14ee0 plus R89 canonical native-method/shared return-fact patch',coreSHA256={role:hashlib.sha256((r/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']},productionSources=inventory,baselineProductionSources=base['productionSources'],focusedChecks=checks,qualification='Focused actual.NET11/10 pass including 2 new independently CPython-checked semantic cases; no full candidate delivery or measured performance yet.')
(r/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython','tests/Lokad.Lython.PublicApi.Tests/NativeReturnFunctionTests.cs']))
s=(prior/'measure.py').read_text(encoding='utf-8').replace("old=r.parent.parent/'integer-utf8-r45'","old=r.parent/'integer-utf8-r45'")
(r/'measure.py').write_text(s,encoding='utf-8');shutil.copyfile(prior/'assess-local.py',r/'assess-local.py')
shutil.copyfile('PLAN.md',r/'pre-measurement-plan.md')
print('Exact R89 source/core and focused actual11/10 frozen; rsplit/casefold affected, existing fused text/CSV/report controls. Five complete-script short pairs, no new framework.')
