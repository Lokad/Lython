from pathlib import Path
import json,subprocess
r=Path(__file__).resolve().parent
cases=[('canonical-closed-compositions', '''def folded(value):return value.casefold().rsplit()
def capitalized(value):return value.capitalize().splitlines()
def titled(value):return value.title().lstrip().rstrip()
def swapped(value):return value.swapcase().expandtabs()
def encoded(value):return len(value.encode())
print(folded(' Aİß Σ\u2003C\\n'))
print(capitalized('élAN\\nΣΙΣ'))
print(titled('  élAN σΙΣ  '))
print(swapped('ß\\tÉ😀'))
print(encoded('A😀é'))
print(folded(''),capitalized(''),encoded(''))
'''),('canonical-closed-dynamic-receiver', '''def folded(value):return value.casefold().rsplit()
class Subject:
 def casefold(self):
  print('casefold once')
  return self
 def rsplit(self):
  print('rsplit once')
  return ['custom']
print(folded(Subject()))
''')]
records=[]
for name,source in cases:
 done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],capture_output=True)
 assert done.returncode==0 and not done.stderr,done.stderr
 records.append(dict(name=name,source=source,expected=done.stdout.decode('utf-8').replace('\r\n','\n')))
(r/'independent-goldens.json').write_text(json.dumps(dict(referenceVersion=subprocess.check_output(['C:/Python313/python.exe','--version'],text=True).strip(),cases=records),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
p=Path('tests/Lokad.Lython.PublicApi.Tests/NativeReturnFunctionTests.cs');s=p.read_text(encoding='utf-8')
needle='    public static TheoryData<string, string, string> Cases => new()\n    {\n';assert needle in s
rows=''.join('        { '+', '.join(json.dumps(c[k],ensure_ascii=False)for k in ['name','source','expected'])+' },\n'for c in records)
s=s.replace(needle,needle+rows,1);p.write_text(s,encoding='utf-8',newline='\n')
print('Two closed-method compositions/dynamic-receiver cases independently checked against isolated CPython; existing semantic assertions unchanged.')
