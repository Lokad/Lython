from pathlib import Path
import hashlib,json,tarfile
r=Path(__file__).resolve().parent;out=Path('benchmarks/results/2026-11-08-native-method-facts')
out.mkdir(exist_ok=True)
identity=json.loads((r/'direct-fusion/identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in identity['productionSources'].items())
vm=json.loads((r/'b451/assessment.json').read_text(encoding='utf-8'));assert vm['complete']
for n in ['b450','b451']:
 receipt=json.loads((r/n/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['allWorkersJoined']
 assert hashlib.sha256((r/n/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
decision=json.loads((r/'decision.json').read_text(encoding='utf-8'))
data=dict(decision=decision,source=identity,firstControlledSourcePair=json.loads((r/'b450/assessment.json').read_text(encoding='utf-8')),refinedControlledSourcePair=vm,finalShortComparison=json.loads((r/'direct-fusion/assessment-local.json').read_text(encoding='utf-8')),limitations=['Elapsed/coarseCPU/allocation/architecture are separate; no refreshed CPython ratio, startup or embedding-tail claim.','Original callsite-metadata prototype, B450 fused adverse control and all desktop/adverse/unstable controls retained.','Focused actual11/10 is not complete Windows/Ubuntu originalStress/installed qualification; final candidate delivery follows retained commit.'])
(out/'assessment.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
with tarfile.open(out/'observations.tar.xz','w:xz')as a:
 for p in sorted(r.rglob('*')):
  if p.is_file()and not any(part in ['images','retrieved','__pycache__']for part in p.relative_to(r).parts)and p.name not in ['payload.tgz','current-core.dll','baseline-core.dll']:
   a.add(p,arcname=p.relative_to(r).as_posix())
 a.add(r/'images/candidate/Lokad.Lython.dll',arcname='initial-callsite-prototype-core.dll')
with tarfile.open(out/'observations.tar.xz')as a:
 for m in a.getmembers():
  p=r/'images/candidate/Lokad.Lython.dll'if m.name=='initial-callsite-prototype-core.dll'else r/m.name
  assert m.isfile()and hashlib.sha256(a.extractfile(m).read()).digest()==hashlib.sha256(p.read_bytes()).digest()
print('Full R89 sources/cores, all initial/refined/adverse observations and validation preserved and locally verified:',(out/'observations.tar.xz').stat().st_size)
