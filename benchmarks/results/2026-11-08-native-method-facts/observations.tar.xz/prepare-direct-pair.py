from pathlib import Path
import ast,hashlib,json,os,re,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;p=r/'direct-fusion'
for n in ['catalog.json','independent-goldens.json']:shutil.copyfile(r/n,p/n)
for role in ['before','candidate']:shutil.copytree(r/'images/before',p/'images'/role,copy_function=os.link)
core=p/'images/candidate/Lokad.Lython.dll';core.unlink();shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',core)
checks={}
for name,expected in [('internal-direct11',397),('public-direct-final11',2165),('internal-direct10',397),('public-direct10',2165)]:
 s=(r/(name+'.log')).read_text(encoding='utf-8');assert 'Failed:     0'in s and re.search(r'Passed:\s+'+str(expected)+r'\b',s);checks[name]=dict(passed=expected)
base=json.loads((r/'node-method/identity.json').read_text(encoding='utf-8'))
inventory={str(f).replace('\\','/'):hashlib.sha256(f.read_bytes()).hexdigest()for f in Path('src/Lokad.Lython').rglob('*')if f.is_file()and not {'bin','obj'}&set(f.parts)}
identity=dict(baselineSource='7796a24f fully qualified CI42459221409',candidateSource='aaa9cb09 plus R89 canonical native-method/shared facts and direct existing-fusion plan',coreSHA256={role:hashlib.sha256((p/'images'/role/'Lokad.Lython.dll').read_bytes()).hexdigest()for role in ['before','candidate']},productionSources=inventory,baselineProductionSources=base['baselineProductionSources'],focusedChecks=checks,qualification='397internal/2165public focused Release per actual.NET11/10 pass, 3 independently CPython-checked composition/dynamic/sibling/forwarded cases. Full candidate delivery pending.')
(p/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8');(p/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython','tests/Lokad.Lython.PublicApi.Tests/NativeReturnFunctionTests.cs']))
for n in ['measure.py','assess-local.py']:shutil.copyfile(r/'node-method'/n,p/n)
shutil.copyfile('PLAN.md',p/'pre-measurement-plan.md')

b=r/'b451';b.mkdir();old=r/'b450'
for n in ['collect.py','run.sh','retrieve.py','assess-vm.py','archive-owned.py','launch.py']:
 s=(old/n).read_text(encoding='utf-8').replace('native-method-facts-b450-20261108','direct-native-fusion-b451-20261108').replace('lython-b450-native-method-facts','lython-b451-direct-native-fusion').replace('native-method-facts-b450-launch.py','direct-native-fusion-b451-launch.py')
 if n=='collect.py':s=s.replace('R89 node-owned canonical native-method/shared return-fact consolidation; rsplit/casefold affected, existing fused text/CSV/report controls','R89 direct existing-fusion plan removes dead producer/proof/empty arguments after B450 fused-control concern; rsplit/casefold affected, fused/CSV/report controls unchanged')
 if n=='launch.py':
  s=s.replace("reference=base/'receiver-contract-b448-20261108/candidate'","reference=base/'native-method-facts-b450-20261108/reference'")
  needle=" identity=json.loads((root/'identity.json').read_text());assert set(identity['coreSHA256'])=={'reference','reference-control','candidate','candidate-control'}"
  assert needle in s
  s=s.replace(needle,needle+"\n assert hashlib.sha256((reference/'Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256']['reference']\n os.link(reference/'Lokad.Lython.dll',root/'baseline-core.dll')")
 (b/n).write_text(s,encoding='utf-8',newline='\n')
 if n.endswith('.py'):ast.parse(s)
prior=json.loads((old/'identity.json').read_text(encoding='utf-8'))
vmidentity={**prior,'sourceRevision':identity['candidateSource'],'baselineSource':identity['baselineSource'],'coreSHA256':{role:identity['coreSHA256']['before'if role.startswith('reference')else'candidate']for role in ['reference','reference-control','candidate','candidate-control']},'productionSources':inventory,'qualification':identity['qualification']}
(b/'identity.json').write_text(json.dumps(vmidentity,indent=2)+'\n',encoding='utf-8')
for src,name in [(p/'images/candidate/Lokad.Lython.dll','current-core.dll'),(p/'catalog.json','representative.json'),(p/'source.patch','source.patch'),(p/'identity.json','focused.json'),(Path('PLAN.md'),'pre-measurement-plan.md'),(old/'shared-worker-common.json','shared-worker-common.json')]:shutil.copyfile(src,b/name)
contract=(old/'contract.md').read_text(encoding='utf-8')+'''
B450167.945s confirmed affected elapsed−13–18%, but fused control+2.52–8.29%
and CPUflat-to-adverse. Original source/core/adverse raw data and all controls
retained. Direct existing-fusion plan removes a dead lower/upper node, duplicate
type proof and empty argument scan while preserving original span-check order.
No new fusion/policy.397/2165focused peractual11/10,3CPython-checked semantic cases.
One justified refined source-pair confirmation, same six jobs/settings/controls.
Existing B450/reference exact qualified cc6 baseline image/core reused under idle
lease with SHA proof before linking. Payload needs only the new candidate core;
baseline bytes are archived again. No old evidence/data/core/path is removed.
'''
(b/'contract.md').write_text(contract,encoding='utf-8');shutil.copyfile(old/'setup-contract.json',b/'setup-contract.json')
with tarfile.open(b/'payload.tgz','w:gz')as a:
 for n in ['collect.py','run.sh','current-core.dll','representative.json','identity.json','pre-measurement-plan.md','setup-contract.json','contract.md','focused.json','source.patch','shared-worker-common.json','archive-owned.py']:a.add(b/n,arcname=n)
print('Final direct-fusion source/core frozen; 397/2165 peractual11/10. One refined same-six-job source pair prepared, exact baseline hardlink reused without deleting evidence.')
