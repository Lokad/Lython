from pathlib import Path
import hashlib,json,re,subprocess
r=Path(__file__).resolve().parent
files=['src/Lokad.Lython/Frontend/ExecutableNativeBody.cs','src/Lokad.Lython/Frontend/ExecutableScript.cs','src/Lokad.Lython/Frontend/ExecutableScript.NativeReturns.cs','src/Lokad.Lython/Frontend/StaticContracts.MemberReturns.cs','src/Lokad.Lython/Runtime/LythonRuntime.StringMembers.Basic.cs','src/Lokad.Lython/Runtime/LythonRuntime.StringMembers.Casing.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeReturn.cs']
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
originals={f:subprocess.check_output(['git','show',head+':'+f]).decode('utf-8')for f in files}
if not (r/'baseline.json').exists():
 (r/'baseline.json').write_text(json.dumps(dict(head=head,qualifiedProductionReference='7796a24f (full delivery CI42459221409 running)',files={f:hashlib.sha256(Path(f).read_bytes()).hexdigest()for f in files}),indent=2)+'\n',encoding='utf-8')
else:
 (r/'initial-migration-assertion.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython']))
__import__('shutil').copyfile('PLAN.md',r/'pre-code-plan.md')

f=files[0];s=originals[f]
s=s.replace('    Strip, Lower, Upper, IsLower, IsUpper, IsTitle, IsAlpha, IsDigit, IsAlnum,\n    IsAscii, IsDecimal, IsIdentifier, IsNumeric, IsPrintable, IsSpace,','    ReceiverMethod,')
Path(f).write_text(s,encoding='utf-8',newline='\n')

f=files[1];s=originals[f];needle='    public int NativeArgumentIndex(int index)'
assert needle in s
s=s.replace(needle,'''    // Prepared once with the closed native body, before publication. Ordinary
    // calls keep their original binding and do not consume this metadata.
    public LythonRuntime.ReceiverMethod? NativeReceiverMethod { get; set; }
    public StaticReturnShape NativeReceiverReturnShape { get; set; }
    public int NativeArgumentIndex(int index)''')
Path(f).write_text(s,encoding='utf-8',newline='\n')

f=files[3];s=originals[f]
s=s.replace('        ("isupper", StaticReturnShape.Boolean),','        ("isupper", StaticReturnShape.Boolean),\n'+''.join(f'        ("{name}", StaticReturnShape.Boolean),\n'for name in ['istitle','isascii','isdecimal','isidentifier','isnumeric','isprintable']).rstrip('\n'))
start=s.index('        if (MemberReturnContractsByMember.TryGetValue(');end=s.index('        value = default;',start)
s=s[:start]+'''        if (TryGetMemberReturnShape(receiver.Kind, memberName, out var shape))
        {
            value = CreateReturnValue(shape, receiver, span);
            return true;
        }

'''+s[end:]
needle='    private static StaticMemberReturnContract[] CreateMemberReturnContracts()'
s=s.replace(needle,'''    internal static bool TryGetMemberReturnShape(AbstractValueKind receiverKind, string memberName, out StaticReturnShape shape)
    {
        if (MemberReturnContractsByMember.TryGetValue(new(receiverKind, memberName), out var contract))
        {
            shape = contract.ReturnShape;
            return true;
        }
        shape = default;
        return false;
    }

'''+needle)
Path(f).write_text(s,encoding='utf-8',newline='\n')

f=files[4];s=originals[f].replace('using Lokad.Lython.Frontend;\n','')
start=s.index('        internal static NativeReturnOperation? GetNoArgumentsKind(');end=s.index('        internal static ReceiverMethod? GetMethod',start)
s=s[:start]+s[end:]
s=s.replace('GetNoArgumentsMethod(NativeReturnOperation.Strip)','StripMethod')
names=['Lower','Upper','IsLower','IsUpper','IsTitle','IsAlpha','IsDigit','IsAlnum','IsAscii','IsDecimal','IsIdentifier','IsNumeric','IsPrintable','IsSpace']
for name in names:s=s.replace(f'GetNoArgumentsMethod(NativeReturnOperation.{name})',f'CasingMethods.{name}')
Path(f).write_text(s,encoding='utf-8',newline='\n')

f=files[5];s=originals[f].replace('using Lokad.Lython.Frontend;\n','')
start=s.index('        internal static ReceiverMethod GetNoArgumentsMethod(');end=s.index('        private static class CasingMethods',start)
s=s[:start]+'''        // Shared immutable declarations; native preparation reuses these same
        // methods and the frontend's existing return facts, without an enum index.
'''+s[end:]
start=s.index('            internal static readonly ReceiverMethod[] Native =');end=s.index('            internal static readonly ReceiverMethod Capitalize',start)
old=s[start:end];matches=re.findall(r'                new\((LythonCallableSignature.Create\("str\.[^\n]+)\n                    (static [^\n]+)\),',old)
assert len(matches)==len(names),(len(matches),len(names))
decl=[]
for name,(signature,implementation)in zip(names,matches):
 assert implementation.endswith(')'),implementation
 decl.append(f'            internal static readonly ReceiverMethod {name} = new(\n                {signature}\n                {implementation});\n')
s=s[:start]+'\n'.join(decl)+'\n'+s[end:]
Path(f).write_text(s,encoding='utf-8',newline='\n')

f=files[2];s=originals[f]
start=s.index('                        var selected = member switch');end=s.index('                    }\n                    for (var a = 0;',start)
s=s[:start]+'''                        if (site.ArgumentCount == 0 && LythonRuntime.StringMembers.GetMethod(member) is { } method
                            && method.AcceptsPositional(0)
                            && StaticContracts.TryGetMemberReturnShape(AbstractValueKind.String, member, out var shape)
                            && shape is StaticReturnShape.String or StaticReturnShape.Bytes or StaticReturnShape.Boolean or StaticReturnShape.ListOfString)
                        {
                            site.NativeReceiverMethod = method;
                            site.NativeReceiverReturnShape = shape;
                            operation = NativeReturnOperation.ReceiverMethod;
                            if (ReferenceEquals(method, LythonRuntime.StringMembers.GetMethod("split"))
                                && values[first].Operation == NativeReturnOperation.ReceiverMethod)
                            {
                                var producer = CallSites[instructions[values[first].SourceInstruction].CallSiteIndex].NativeReceiverMethod;
                                if (ReferenceEquals(producer, LythonRuntime.StringMembers.GetMethod("lower"))) operation = NativeReturnOperation.SplitLowerWhitespace;
                                else if (ReferenceEquals(producer, LythonRuntime.StringMembers.GetMethod("upper"))) operation = NativeReturnOperation.SplitUpperWhitespace;
                            }
                        }
                        else
                        {
                            var selected = member switch
                            {
                                "split" when site.ArgumentCount is 1 or 2 => NativeReturnOperation.Split,
                                "replace" when site.ArgumentCount is 2 or 3 => NativeReturnOperation.Replace,
                                "startswith" when site.ArgumentCount == 1 => NativeReturnOperation.StartsWith,
                                "endswith" when site.ArgumentCount == 1 => NativeReturnOperation.EndsWith,
                                _ => (NativeReturnOperation?)null
                            };
                            if (selected is null) return null;
                            operation = selected.Value;
                        }
'''+s[end:]
Path(f).write_text(s,encoding='utf-8',newline='\n')

f=files[6];s=originals[f]
old='''            case >= NativeReturnOperation.Strip and <= NativeReturnOperation.IsSpace:
                shape = value.Operation <= NativeReturnOperation.Upper ? NativeReturnShape.String : NativeReturnShape.Boolean;
                return first == NativeReturnShape.String;'''
assert old in s
s=s.replace(old,'''            case NativeReturnOperation.ReceiverMethod:
                shape = code.CallSites[code.Instructions[value.SourceInstruction].CallSiteIndex].NativeReceiverReturnShape switch
                {
                    StaticReturnShape.String => NativeReturnShape.String,
                    StaticReturnShape.Bytes => NativeReturnShape.Bytes,
                    StaticReturnShape.Boolean => NativeReturnShape.Boolean,
                    StaticReturnShape.ListOfString => NativeReturnShape.Sized,
                    _ => NativeReturnShape.Other,
                };
                return first == NativeReturnShape.String && shape != NativeReturnShape.Other;''')
s=s.replace('''            if (value.Operation is >= NativeReturnOperation.Strip and <= NativeReturnOperation.IsSpace)
                return InvokeReceiverMethod(StringMembers.GetNoArgumentsMethod(value.Operation), receiver, site.CallSpan, context);''','''            if (value.Operation == NativeReturnOperation.ReceiverMethod)
                return InvokeReceiverMethod(site.NativeReceiverMethod!, receiver, site.CallSpan, context);''')
Path(f).write_text(s,encoding='utf-8',newline='\n')
(r/'original-sources.json').write_text(json.dumps(originals,indent=2)+'\n',encoding='utf-8')
print('Canonical native-call prototype: shared existing method/return facts; duplicate method enums/map/index array removed. Baseline and pre-code plan preserved. Build/semantics/measurements pending.')
