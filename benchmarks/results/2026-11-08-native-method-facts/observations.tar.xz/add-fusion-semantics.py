from pathlib import Path
import json,subprocess
r=Path(__file__).resolve().parent
source='''def words(value):
 prepared=value.lower()
 return prepared.split()
def combined(left,right,size=len):
 return size(left.upper().split())+size(right.lower().split())
print(words('  İΣ ΣΙΣ ß\\u2003'))
print(combined(' ß ΣΙΣ ', ' İΣ '))
print(words(''),combined('', ''))
'''
done=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],capture_output=True)
assert done.returncode==0 and not done.stderr
row=dict(name='fused-siblings-and-forwarded-local',source=source,expected=done.stdout.decode('utf-8').replace('\r\n','\n'))
(r/'direct-fusion/independent-golden.json').write_text(json.dumps(dict(referenceVersion=subprocess.check_output(['C:/Python313/python.exe','--version'],text=True).strip(),case=row),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
p=Path('tests/Lokad.Lython.PublicApi.Tests/NativeReturnFunctionTests.cs');s=p.read_text(encoding='utf-8');needle='    public static TheoryData<string, string, string> Cases => new()\n    {\n';assert needle in s
s=s.replace(needle,needle+'        { '+', '.join(json.dumps(row[k],ensure_ascii=False)for k in ['name','source','expected'])+' },\n',1)
s=s.replace('// Goldens independently captured with isolated CPython 3.13.2.','// Goldens independently captured with isolated CPython 3.13.')
p.write_text(s,encoding='utf-8',newline='\n')
print('Added independent CPython golden for sibling fused results and forwarded-local casing, exercising node removal without architecture assertions.')
