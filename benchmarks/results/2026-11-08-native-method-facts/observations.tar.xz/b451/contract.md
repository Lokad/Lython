R89: consolidate closed-call preparation onto existing canonical declarations and
frontend return facts. Remove per-method native enums/map/indexed array. Method
reference belongs to the native value node, four generic result shapes; no new
per-name proof marker/catalog/engine/owner/pool. Keep existing lower/upper split
fusion and argument-bearing proofs, dynamic ordinary execution before effects,
managed stack/cancellation/admission/alias funding/awaited cleanup.397/2164focused
peractual11/10 pass. Initial callsite-metadata prototype/core and adverse desktop
observations retained; refinement removes every-callsite fields/proof lookups.
One six-job source pair: ordinary rsplit sync/async and casefold sync affected;
existing fused helper sync, CSV sync, report async controls. Two old/two candidate
processes,5s warmup/role/job,seven rotated150ms rounds, normalGC/tiering, quietVM.
Complete invocation/mediated RAM I/O/full validation/prior cleanup included;
compile/startup/staging/reset/protocol/final cached teardown excluded. Actual
suspension tested separately. All source/core/aux/Ready/runtime/golden/quiet/Closed/
exit/join/fixture/archive gates retained; archive underlease/localverify.210owner+
30stop+30margin;240MiB OSfloor+7MiB evidence headroom. Reuse previous byte-identical
auxiliary images, overwrite only core hardlinks; no new deduplication/deletion.
Allocation reduction, architectural removal, elapsed, coarseCPU and embedding
latency are separate. Retain all adverse/unstable controls and explicit regression
debt; one bounded confirmation/refinement if supported, no fixed-percentage veto.
Publication and whole performance-objective completion remain postponed.

B450167.945s confirmed affected elapsed−13–18%, but fused control+2.52–8.29%
and CPUflat-to-adverse. Original source/core/adverse raw data and all controls
retained. Direct existing-fusion plan removes a dead lower/upper node, duplicate
type proof and empty argument scan while preserving original span-check order.
No new fusion/policy.397/2165focused peractual11/10,3CPython-checked semantic cases.
One justified refined source-pair confirmation, same six jobs/settings/controls.
Existing B450/reference exact qualified cc6 baseline image/core reused under idle
lease with SHA proof before linking. Payload needs only the new candidate core;
baseline bytes are archived again. No old evidence/data/core/path is removed.
