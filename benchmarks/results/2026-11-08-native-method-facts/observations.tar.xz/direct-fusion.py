from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent;p=r/'direct-fusion';p.mkdir()
identity=json.loads((r/'node-method/identity.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256(Path(f).read_bytes()).hexdigest()==h for f,h in identity['productionSources'].items())
shutil.copyfile('PLAN.md',p/'pre-code-plan.md')
f=Path('src/Lokad.Lython/Frontend/ExecutableScript.NativeReturns.cs');s=f.read_text(encoding='utf-8')
old='''                            if (ReferenceEquals(method, LythonRuntime.StringMembers.GetMethod("split"))
                                && values[first].Operation == NativeReturnOperation.StringMethod)
                            {
                                var producer = values[first].Method;
                                if (ReferenceEquals(producer, LythonRuntime.StringMembers.GetMethod("lower"))) operation = NativeReturnOperation.SplitLowerWhitespace;
                                else if (ReferenceEquals(producer, LythonRuntime.StringMembers.GetMethod("upper"))) operation = NativeReturnOperation.SplitUpperWhitespace;
                            }'''
assert old in s
new='''                            if (ReferenceEquals(method, LythonRuntime.StringMembers.GetMethod("split"))
                                && first == values.Count - 1 && target.Member == index - 1
                                && values[first].Operation == NativeReturnOperation.StringMethod)
                            {
                                var producer = values[first];
                                if (producer.SourceInstruction == producer.Second + 1)
                                {
                                    if (ReferenceEquals(producer.Method, LythonRuntime.StringMembers.GetMethod("lower"))) operation = NativeReturnOperation.SplitLowerWhitespace;
                                    else if (ReferenceEquals(producer.Method, LythonRuntime.StringMembers.GetMethod("upper"))) operation = NativeReturnOperation.SplitUpperWhitespace;
                                }
                                if (operation is NativeReturnOperation.SplitLowerWhitespace or NativeReturnOperation.SplitUpperWhitespace)
                                {
                                    // The kernel consumes the original string. Retain
                                    // the producer's instruction/spans, not a dead
                                    // method node and its redundant result proof.
                                    first = producer.First;
                                    second = producer.SourceInstruction;
                                    nativeMethod = null;
                                    values.RemoveAt(values.Count - 1);
                                }
                            }'''
s=s.replace(old,new);f.write_text(s,encoding='utf-8',newline='\n')
f=Path('src/Lokad.Lython/Runtime/LythonRuntime.Executable.NativeReturn.cs');s=f.read_text(encoding='utf-8')
old='''                ref readonly var producer = ref values[value.First];
                first = EvaluateNativeReturn(producer.First, code, values, arguments, context, entryException);
                context.State.CheckExecution(code.Instructions[producer.Second].Span);
                context.State.CheckExecution(code.CallSites[code.Instructions[producer.SourceInstruction].CallSiteIndex].CallSpan);'''
assert old in s
s=s.replace(old,'''                first = EvaluateNativeReturn(value.First, code, values, arguments, context, entryException);
                // Preparation proved both zero-argument member/call pairs are
                // adjacent. Preserve their checks in original evaluation order.
                context.State.CheckExecution(code.Instructions[value.Second - 1].Span);
                context.State.CheckExecution(code.CallSites[code.Instructions[value.Second].CallSiteIndex].CallSpan);
                context.State.CheckExecution(code.Instructions[value.SourceInstruction - 1].Span);''')
s=s.replace('else if (value.Operation is >= NativeReturnOperation.BuiltinUnary and <= NativeReturnOperation.SplitUpperWhitespace)','else if (value.Operation is >= NativeReturnOperation.BuiltinUnary and <= NativeReturnOperation.EndsWith)')
f.write_text(s,encoding='utf-8',newline='\n')
(p/'source.patch').write_bytes(subprocess.check_output(['git','diff','--','src/Lokad.Lython','tests/Lokad.Lython.PublicApi.Tests/NativeReturnFunctionTests.cs']))
print('Existing fused plan now reads the original receiver directly, removing a dead method node/type proof/empty argument scan. Original member/call span-check order retained; no new fusion or policy.')
