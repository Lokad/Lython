from pathlib import Path
import json
p=Path('PLAN.md');s=p.read_text(encoding='utf-8')
start=s.index('| R84/R85/R86 |');end=s.index('\n| Regex /R68 |',start)if '\n| Regex /R68 |'in s[start:]else s.index('\n| Regex R68 |',start)
s=s[:start]+'''| R84/R85 | Canonical receivers02c76e52/coreaa4acebe, corrected7796a24f/corecc6b1b15 fully qualified CI42459221409. Failed original CI42457767068/logs retained. Corrected allocation45–52%lower; controlled elapsed22–24%lower belongs to earlier aa4, not cc6. Controls/debt remain explicit in results. |
| R86/R87/R88 | Complete CSV/helper/generated-code source gates committed7796a24f+16e14ee0; B449 terminal/archived/verified. No binder dominance or causal CPU claim. Existing record adoption/keys/batched fields remain. Text source-shape diagnostic selected the next coherent preparation cleanup, not a new arena/engine. |
| R89 | Active uncommitted prototype on production7796a24f: shared native-method/return facts,397internal/2164public Release per actual11/10 pass. Initial and refined sources/cores/adverse desktop data frozen. Allocation neutral; B450 controlled source pair running. No candidate delivery/CPU claim yet. |'''+s[end:]
start=s.index('## Active deliverables');end=s.index('## Following substantial redesign boundaries',start)
s=s[:start]+'''## Active deliverables

1. **R89: consolidate closed-call preparation, then decide/qualify.** Replace the
   duplicate string-method inventory with canonical ReceiverMethod declarations
   and existing frontend return facts. Removed in the prototype: method-specific
   native-return enum entries, GetNoArgumentsKind/map, enum-indexed declaration
   array/accessors and their guard/evaluation branches. Six missing Boolean facts
   join the existing catalog. The prepared immutable method belongs to its native
   value node, with four generic result shapes; no per-name proof flags, second
   catalog, new engine, owner or pool. Existing lower/upper split fusion and
   argument-bearing proof remain. Exact native receiver/type proof precedes work;
   other shapes use ordinary execution before effects, never retry after work.

   Acceptance: Python metadata/arity/Unicode/evaluation order/spans, dynamic and
   genuinely asynchronous callbacks, cancellation, first terminal refusal, funded
   aliases and awaited cleanup. Two new composition/dynamic receiver cases have
   isolated CPython goldens. Refined397internal/2164public per actual11/10 pass.
   Initial call-site-metadata prototype/adverse rsplit/report data remain; the
   refinement removes every-callsite fields and proof lookups. Short allocation is
   neutral; desktop clocks/controls remain unstable (old-role161.14% retained).

   B450: one bounded six-job normal-settings source pair, rsplit sync/async and
   casefold sync affected; existing fused helper sync/CSV sync/report async
   controls.210sowner+30stop+30margin; observe only>=08:05:45UTC. Preserve source/
   core/aux/Ready/runtime/golden/quiet/Closed/exit/join/fixture/archive gates.
   Retain/correct/reject on architectural removal, complete-script elapsed,
   coarseCPU, allocation and explicit control debt separately; no fixed-percent
   veto. If retained, update current docs, commit and batch full Windows/Ubuntu
   actual11/10/originalStress/installed-core qualification. Work while CI runs;
   do not imply that baseline7796a24f's green receipt qualifies the candidate.

2. **Continue substantial whole-script work.** R86–R88 found distributed execution/
   operand, parsing, adoption and numeric costs, not a dominant binder phase.
   Prefix method/tier/code-size identity was verified; most mapped samples are
   fetch/dispatch, with fewer refusal/token checks. Input-handler emitted listing
   is absent, so its samples cannot be assigned to source blocks. Initial text
   helper/inline contrast has neutral allocation and diagnostic elapsed−11–16%;
   CSV has different protected continue flow, allocation+1.5% and unstable clocks.
   Do not treat these as binder-only attribution. Keep all raw/unknown/adverse
   evidence in EXPERIMENTS/results; no further VM run merely to amplify weak
   samples. Proceed through the following design boundaries with an explicit
   removable phase, semantics and bounded source pair. A measurement/CI receipt
   or isolated experiment does not complete the performance objective.

3. **Independent regex track.** Missing producer publication defers only affected
   final adapter qualification. Core architecture/correctness and non-regex work
   continue independently. Publication/tagging remain postponed.

'''+s[end:]
p.write_text(s,encoding='utf-8',newline='\n')
print('PLAN condensed: actual qualified7796a24f separated from active R89; completed attribution/history remains linked, criteria and independent tracks preserved.')
