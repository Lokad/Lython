from pathlib import Path
import ast,hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;b=r/'b450';b.mkdir();old=r.parent/'receiver-contract-r85/b448';pair=r/'node-method'
jobs=[['scripts.text-summary-rsplit-helpers.large','warm'],['scripts.text-summary-rsplit-helpers.large','warm-async'],['scripts.text-summary-casefold-helpers.large','warm'],['scripts.text-summary-helpers.large','warm'],['scripts.csv-summary-functions.large','warm'],['scripts.report-render.large','warm-async']]
for n in ['collect.py','run.sh','retrieve.py','assess-vm.py','archive-owned.py','launch.py']:
 s=(old/n).read_text(encoding='utf-8').replace('receiver-contract-b448-20261108','native-method-facts-b450-20261108').replace('lython-b448-receiver-contract','lython-b450-native-method-facts').replace('receiver-contract-b448-launch.py','native-method-facts-b450-launch.py')
 if n=='collect.py':
  a=s.index('jobs=');z=s.index('\nassert len(jobs)',a);s=s[:a]+'jobs='+repr(jobs)+s[z:]
  s=s.replace('R85 canonical receiver callable consolidation with fixed-arity zero-argument invocation; casefold/title affected, rsplit/CSV/report controls','R89 node-owned canonical native-method/shared return-fact consolidation; rsplit/casefold affected, existing fused text/CSV/report controls')
 if n=='launch.py':s=s.replace("reference=base/'combined-cpython-b446-20261108/candidate'","reference=base/'receiver-contract-b448-20261108/candidate'")
 (b/n).write_text(s,encoding='utf-8',newline='\n')
 if n.endswith('.py'):ast.parse(s)
d=json.loads((pair/'identity.json').read_text(encoding='utf-8'));assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in d['productionSources'].items())
base=json.loads((old/'identity.json').read_text(encoding='utf-8'))
identity=dict(sourceRevision=d['candidateSource'],baselineSource='7796a24f; full CI42459221409 Windows green/Ubuntu Stress running at last observation',coreSHA256={role:d['coreSHA256']['before'if role.startswith('reference')else'candidate']for role in ['reference','reference-control','candidate','candidate-control']},auxiliaryFiles=base['auxiliaryFiles'],productionSources=d['productionSources'],baselineProductionSources=d['baselineProductionSources'],jobs=jobs,included=base['included'],qualification='397internal/2164public focused Release per actual11/10 pass; 2 independently CPython-checked composition/dynamic receiver cases. No full candidate/producer qualification or prior CPU claim.')
(b/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
for src,name in [(pair/'images/candidate/Lokad.Lython.dll','current-core.dll'),(pair/'images/before/Lokad.Lython.dll','baseline-core.dll'),(pair/'catalog.json','representative.json'),(pair/'source.patch','source.patch'),(pair/'identity.json','focused.json'),(Path('PLAN.md'),'pre-measurement-plan.md'),(old/'shared-worker-common.json','shared-worker-common.json')]:shutil.copyfile(src,b/name)
contract='''R89: consolidate closed-call preparation onto existing canonical declarations and
frontend return facts. Remove per-method native enums/map/indexed array. Method
reference belongs to the native value node, four generic result shapes; no new
per-name proof marker/catalog/engine/owner/pool. Keep existing lower/upper split
fusion and argument-bearing proofs, dynamic ordinary execution before effects,
managed stack/cancellation/admission/alias funding/awaited cleanup.397/2164focused
peractual11/10 pass. Initial callsite-metadata prototype/core and adverse desktop
observations retained; refinement removes every-callsite fields/proof lookups.
One six-job source pair: ordinary rsplit sync/async and casefold sync affected;
existing fused helper sync, CSV sync, report async controls. Two old/two candidate
processes,5s warmup/role/job,seven rotated150ms rounds, normalGC/tiering, quietVM.
Complete invocation/mediated RAM I/O/full validation/prior cleanup included;
compile/startup/staging/reset/protocol/final cached teardown excluded. Actual
suspension tested separately. All source/core/aux/Ready/runtime/golden/quiet/Closed/
exit/join/fixture/archive gates retained; archive underlease/localverify.210owner+
30stop+30margin;240MiB OSfloor+7MiB evidence headroom. Reuse previous byte-identical
auxiliary images, overwrite only core hardlinks; no new deduplication/deletion.
Allocation reduction, architectural removal, elapsed, coarseCPU and embedding
latency are separate. Retain all adverse/unstable controls and explicit regression
debt; one bounded confirmation/refinement if supported, no fixed-percentage veto.
Publication and whole performance-objective completion remain postponed.
'''
(b/'contract.md').write_text(contract,encoding='utf-8');(b/'setup-contract.json').write_text(json.dumps(dict(jobs=jobs,ownerSeconds=210,stopSeconds=30,marginSeconds=30,osFreeFloorMiB=240,evidenceHeadroomMiB=7),indent=2)+'\n',encoding='utf-8')
with tarfile.open(b/'payload.tgz','w:gz')as a:
 for name in ['collect.py','run.sh','current-core.dll','baseline-core.dll','representative.json','identity.json','pre-measurement-plan.md','setup-contract.json','contract.md','focused.json','source.patch','shared-worker-common.json','archive-owned.py']:a.add(b/name,arcname=name)
print('One bounded six-job R89 source pair prepared with fused/CSV/report controls; every exact source/core and original adverse condition retained.')
