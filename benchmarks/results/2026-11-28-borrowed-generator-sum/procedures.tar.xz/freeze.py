from hashlib import sha256
from pathlib import Path
from shutil import copy2, copytree
from subprocess import check_output, run
import json
import sys

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.parent / 'lazy-closure-count-b1955-20261128' / 'comparison'
pair = lab / 'comparison'
build = lab / 'ubuntu-artifacts/bin/Lokad.Lython/release_net11.0/Lokad.Lython.dll'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
manifest = lambda folder: {file.name: digest(file) for file in folder.iterdir()}

def git(*args):
    return check_output(['git', *args], cwd=repo)

def verify_baseline():
    old = read(prior / 'identity.json')
    baseline_revision = git('rev-parse', 'HEAD^').decode().strip()
    assert baseline_revision.startswith('52d38a3e4')
    patch = git('diff', '--binary', old['sourceRevision'], baseline_revision, '--', 'src/Lokad.Lython', 'tests')
    assert sha256(patch).hexdigest() == old['sourcePatchSHA256']
    assert not git('diff', 'HEAD^', 'HEAD', '--', 'src')
    assert not git('diff', 'HEAD', '--', 'Directory.Packages.props', 'src/Lokad.Lython.Utf8Regex')
    return old

def candidate_patch():
    tracked = git('diff', '--binary', 'HEAD', '--', 'src', 'tests')
    new = git('ls-files', '--others', '--exclude-standard', '--', 'src', 'tests').decode().splitlines()
    assert new == ['src/Lokad.Lython/Runtime/LythonRuntime.Executable.GeneratorSum.cs']
    addition = run(['git', 'diff', '--binary', '--no-index', '--', '/dev/null', new[0]],
                   cwd=repo, capture_output=True)
    assert addition.returncode == 1 and addition.stdout.startswith(b'diff --git ')
    return tracked + addition.stdout

if sys.argv[1:] == ['--verify']:
    identity = read(pair / 'identity.json')
    assert sha256(candidate_patch()).hexdigest() == identity['sourcePatchSHA256']
    for role, files in identity['imageFiles'].items():
        assert manifest(pair / role) == files, role
    assert digest(build) == identity['imageFiles']['candidate']['Lokad.Lython.dll']
    sys.exit()

old = verify_baseline()
base = old['imageFiles']['candidate']
assert len(base) == 32 and manifest(prior / 'candidate') == base
pair.mkdir()
for role in ('reference', 'candidate'):
    copytree(prior / 'candidate', pair / role)
copy2(build, pair / 'candidate/Lokad.Lython.dll')
assert not (pair / 'candidate/Lokad.Lython.dll').samefile(build)
images = {role: manifest(pair / role) for role in ('reference', 'candidate')}
assert {name for name, checksum in base.items() if images['candidate'][name] != checksum} == {'Lokad.Lython.dll'}
assert base == images['reference']

for name in ('representative.json', 'cpython-worker.py', 'run.sh', 'jobs.json', 'collect.py'):
    copy2(prior / name, pair / name)
assert digest(pair / 'cpython-worker.py') == old['cpythonWorkerSHA256']
assert b'\r' not in (pair / 'run.sh').read_bytes()
assert len(read(pair / 'jobs.json')['warm']) == 5
assert all(digest(pair / name) == item['sha256'] for name, item in old['catalogs'].items())
patch = candidate_patch()
(lab / 'candidate.patch').write_bytes(patch)
identity = dict(sourceRevision=git('rev-parse', 'HEAD').decode().strip(),
    sourcePatchSHA256=sha256(patch).hexdigest(), imageFiles=images,
    coreSHA256={r+s: files['Lokad.Lython.dll'] for r, files in images.items() for s in ('', '-control')},
    expectedCPythonSHA256=old['expectedCPythonSHA256'], cpythonWorkerSHA256=old['cpythonWorkerSHA256'],
    catalogs=old['catalogs'], purpose='Reduce exact builtin generator expressions without activating the native prefix frame.')
(pair / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n', encoding='utf-8', newline='\n')
