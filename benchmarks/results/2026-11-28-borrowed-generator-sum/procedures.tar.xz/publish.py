from hashlib import sha256
from pathlib import Path
from shutil import copy2
import json
import re
import subprocess
import sys
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
pair = lab / 'comparison'
output = repo / 'benchmarks/results/2026-11-28-borrowed-generator-sum'
read = lambda path: json.loads(path.read_bytes())
digest = lambda path: sha256(path.read_bytes()).hexdigest()
subprocess.run([sys.executable, lab / 'freeze.py', '--verify'], check=True)
identity = read(pair / 'identity.json')
assert identity['sourceRevision'].startswith('bcc822ecc')
assert digest(lab / 'candidate.patch') == identity['sourcePatchSHA256']
summary = read(pair / 'summary.json')
assert summary['verifiedTimedBatches'] == 140 and len(summary['rows']) == 5
receipt = read(pair / 'archive-receipt.json')
assert receipt['archiveSHA256'] == digest(pair / 'observations.tar.xz')
assert all(receipt[name] for name in ('complete', 'allWorkersJoined', 'guestFixturesRemoved', 'archivedAndVerifiedUnderLease'))
allocation = read(lab / 'allocation/summary.json')
assert len(allocation) == 8
for row in allocation:
    assert row['compiled'][0] == row['compiled'][1]
    savings = row['clr'][0] - row['clr'][1]
    if 'generator-reduction' in row['case']:
        assert savings == 491_520
        assert row['admittedPeak'][1] < row['admittedPeak'][0]
    else:
        assert abs(savings) <= 56
        assert row['admittedPeak'][0] == row['admittedPeak'][1]
admission = read(lab / 'admission/summary.json')
assert len(admission) == 8
for row in admission:
    assert row['requests'][0] == row['requests'][1]
for role in identity['imageFiles']:
    assert read(lab / f'admission/{role}.json')['coreSHA256'] == identity['imageFiles'][role]['Lokad.Lython.dll']

logs = sorted(lab.glob('*-net*.log'))
assert len(logs) == 3
for log in logs:
    assert re.search(r'Failed: +0, Passed: +611, Skipped: +0', log.read_text(encoding='utf-8-sig')), log
inactive = lab.with_name(lab.name + '-inactive')
inactive_admission = read(inactive / 'admission/summary.json')
assert all(row['peak'][0] == row['peak'][1] for row in inactive_admission)
procedures = {path.name: path for path in logs}
for filename in ('candidate.patch', 'freeze.py', 'measure-allocation.py', 'check-admission.py', 'check-python.py',
                 'summarize.py', 'publish.py', 'first-collection-environment.log', 'second-collection-output-directory.log'):
    procedures[filename] = lab / filename
for filename in ('run.log', 'exit-code.txt', 'reference-verify.json', 'candidate-verify.json'):
    procedures[filename] = pair / filename
for folder in ('allocation', 'admission'):
    for path in (lab / folder).glob('*.json'):
        procedures[f'{folder}/{path.name}'] = path
    for path in (inactive / folder).glob('*.json'):
        procedures[f'inactive/{folder}/{path.name}'] = path
for relative in ('candidate.patch', 'comparison/identity.json'):
    procedures[f'inactive/{relative}'] = inactive / relative

output.mkdir()
artifacts = {name: pair / name for name in ('identity.json', 'summary.json', 'observations.tar.xz', 'archive-receipt.json')}
artifacts['allocation.json'] = lab / 'allocation/summary.json'
artifacts['admission.json'] = lab / 'admission/summary.json'
for name, source in artifacts.items():
    copy2(source, output / name)
    assert digest(output / name) == digest(source)
with tarfile.open(output / 'procedures.tar.xz', 'w:xz') as archive:
    for name, path in procedures.items():
        archive.add(path, arcname=name)
with tarfile.open(output / 'procedures.tar.xz') as archive:
    assert all(digest(path) == sha256(archive.extractfile(name).read()).hexdigest() for name, path in procedures.items())
print('B1957 source, failed starts, tests and observations verified.')
