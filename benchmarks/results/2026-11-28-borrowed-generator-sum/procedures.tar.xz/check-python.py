from pathlib import Path
from textwrap import dedent

source = Path('tests/Lokad.Lython.PublicApi.Tests/NativeGeneratorSumTests.cs').read_text(encoding='utf-8')
start = source.index('        checks = []\n')
end = source.index("        return 'ok'\n", start)
exec(compile(dedent(source[start:end]), '<numeric generator regression>', 'exec'))
print('CPython numeric and protocol checks passed')
