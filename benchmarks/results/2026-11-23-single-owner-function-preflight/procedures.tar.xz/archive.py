
from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import sys
import tarfile

lab=Path(__file__).resolve().parent
repo=lab.parents[3]
comparison=lab/"comparison"
quiet=comparison/"quiet"
out=repo/"benchmarks/results/2026-11-23-single-owner-function-preflight"
decision=sys.argv[1]
retained=sys.argv[2] if len(sys.argv)>2 else None
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
def git(*args):return subprocess.check_output(["git",*args],cwd=repo)

identity=read(quiet/"identity.json")
assert identity==read(quiet/"retrieved/identity.json")
patch=git("diff","--binary",identity["patchBase"],identity["candidate"],"--","src","tests")
assert sha(patch)==identity["sourcePatchSHA256"] and patch==(comparison/"source.patch").read_bytes()
if retained:
    paths=git("diff","--name-only",identity["patchBase"],identity["candidate"],"--","src","tests").decode().splitlines()
    assert len(paths)==12 and not git("diff","--name-only",identity["candidate"],retained,"--",*paths)
identity.update(outcome=decision,retainedRevision=retained)
receipt=read(quiet/"archive-receipt.json")
assert all(receipt[k] for k in ("complete","allWorkersJoined","guestFixturesRemoved","quietBeforeAndAfter","archivedAndVerifiedUnderLease"))
assert sha((quiet/"observations.tgz").read_bytes())==receipt["archiveSHA256"]
raw=read(quiet/"retrieved/confirmation/confirmation.json")
assert raw["complete"] and receipt["jobs"]==len(raw["jobs"])==8
cases={c["id"]:c for c in read(quiet/"representative.json")["cases"]}
for job in raw["jobs"]:
    assert job["workersJoinedAndFixturesRemoved"] and len(job["samples"])==28
    case=cases[job["case"]]
    for batch in job["samples"]:
        result=batch["response"]
        assert result["status"]=="Completed"
        assert all(result[k]==case[k] for k in ("sourceSha256","fixtureSha256","expectedOutputSha256"))
        for name in ("Output","Files"):
            assert result.get("actual"+name+"Sha256")== (None if job["lane"]=="compile" else case.get("expected"+name+"Sha256"))
summary=read(quiet/"quiet-summary.json")
summary.update(outcome=decision,retentionDecisionPending=False,timedBatches=sum(len(j["samples"])for j in raw["jobs"]))
out.mkdir()
save(out/"source.json",identity)
save(out/"summary.json",summary)
save(out/"local-allocation.json",{role:read(comparison/f"{role}-allocation.json") for role in identity["imageFiles"]})
save(out/"local-growths.json",{role:read(lab/f"{name}-growths.json") for role,name in
    (("reference","retained"),("candidate","candidate"))})
core="Lokad.Lython.dll"
for role,manifest in identity["imageFiles"].items():
    image=comparison/f"frozen-{role}"
    assert manifest=={name:sha((image/name).read_bytes()) for name in manifest}
    if role=="candidate":(out/f"{role}-core.dll.gz").write_bytes(gzip.compress((image/core).read_bytes(),compresslevel=9,mtime=0))
for name in ("archive-receipt.json","observations.tgz","terminal-status.json"):
    shutil.copyfile(quiet/name,out/name)
with tarfile.open(out/"procedures.tar.xz","w:xz") as bundle:
    names=["measure.py","allocation.log","stage.py","archive.py",
           "test-windows.ps1","test-ubuntu.sh","test-windows-qualified.ps1","test-ubuntu-qualified.sh",
           "control-early-refusal.log","debug-assertions.log","Program.cs","Probe.csproj","build.log","catalog.json",
           "recover-archives-remote.py","recover-archives.log","definition-order.py","verify-definition-order.py",
           "definition-order.log","definition-order/catalog.json",
           "definition-order/eager-expected.txt","definition-order/postponed-expected.txt",
           "comparison/source.patch","comparison/identity.json",
           "comparison/launch.py","comparison/summarize.py",
           "comparison/representative.json","comparison/jobs.json"]
    names += [f"definition-order/{mode}-async.{suffix}" for mode in ("eager", "postponed") for suffix in ("log", "json")]
    for role in ("reference","candidate"):
        names += [f"comparison/{role}-verify.json", f"definition-order/{role}-verify.json"]
    for platform in ("windows","ubuntu"):
        names += [f"{suite}-{period}{platform}.log" for suite in ("white","public","stress") for period in ("","qualified-")]
    names += ["comparison/quiet/"+n for n in ("remote-launch.py","collect.py","archive-owned.py","retrieve.py",
                "run.sh","launch.log","launch-missing-archive.log","observe-not-before.json","config.json")]
    for n in names:bundle.add(lab/n,arcname=n,recursive=False)
