events = []
kept = []
def mark(name, value):
    events.append(name)
    return value
def abandon():
    raise LookupError('no value')
def lookup():
    with open('input.txt') as source:
        return mark('default', source.read())
def remember(function):
    events.append('decorator')
    kept.append(function)
    raise ValueError('retained anyway')
def choose():
    return mark('decorator expression', remember)
def outer():
    current = 'previous'
    try:
        @choose()
        def current(value: mark('annotation', str) = lookup(),
                    *, phase: str = mark('keyword', 'go')) -> mark('return annotation', str):
            return value, phase
    except ValueError as error:
        print(current, str(error))
    return kept[-1]
first = outer()
saved = first.__defaults__
keyword = first.__kwdefaults__
print(first(), list(first.__annotations__))
first.__defaults__ = ('changed',)
first.__kwdefaults__ = {'phase': 'stop'}
print(first(), saved, keyword)
def maker(seed):
    return lambda a=seed: (a, seed)
a = maker(3)
b = maker(7)
print(a(), b(), a.__defaults__ is b.__defaults__)
def failed():
    prior = 'old'
    try:
        def prior(a=mark('first default', saved), b=abandon()):
            return a, b
    except LookupError:
        return prior
print(failed(), saved)
class Demo:
    def read(self, value=mark('class default', saved)):
        return value
print(Demo().read() is saved)
print(events)
