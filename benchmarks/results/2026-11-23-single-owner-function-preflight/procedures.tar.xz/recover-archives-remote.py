from pathlib import Path
import hashlib, json, os, fcntl, shutil, stat, base64
p=Path('/home/lokad/lython-bench-checks')
def sha(data): return hashlib.sha256(data).hexdigest()
with (p/'comparison-vm.lock').open('a') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert not any(os.path.ismount(t) for t in p.glob('*/guest-fixtures'))
    files=[]
    for name, proof in archived.items():
        d=p/name
        assert d.resolve()==d and d.parent==p and d.is_dir()
        raw=d/'observations.tgz'
        assert not raw.is_symlink()
        prior=json.loads((d/'archive-receipt.json').read_text())
        assert prior['archiveSHA256']==proof['sha256'] and prior['archivedAndVerifiedUnderLease'], (name,prior)
        data=base64.b64decode(proof['base64'],validate=True)
        assert sha(data)==proof['sha256']
        if raw.exists():
            assert stat.S_ISREG(raw.lstat().st_mode) and sha(raw.read_bytes())==proof['sha256']
        else:
            files.append((raw,data))
    assert shutil.disk_usage(p).free > 176160768+sum(len(data) for _,data in files)+512*1024
    for raw,data in files:
        with raw.open('xb') as handle: handle.write(data)
        assert sha(raw.read_bytes())==sha(data)
    print(json.dumps(dict(recovered=[str(f.relative_to(p)) for f,_ in files], freeBytes=shutil.disk_usage(p).free)))
