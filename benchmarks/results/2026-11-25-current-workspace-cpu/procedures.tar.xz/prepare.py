from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
prior = lab.with_name("post-async-map-cpu-20261125")
donor = lab.with_name("iteration-native-storage-prepared-20261125")
external = donor / "comparison/quiet"
read = lambda p: json.loads(p.read_text(encoding="utf-8"))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def write(p, contents):
    p.write_text(contents, encoding="utf-8", newline="\n")
def save(p, data):
    write(p, json.dumps(data, ensure_ascii=False, indent=2) + "\n")

observed = read(external / "identity.json")
receipt = read(external / "terminal-status.json")["receipt"]
assert receipt["complete"] and sha(external / "observations.tar.xz") == receipt["archiveSHA256"]
source = subprocess.check_output(["git", "rev-parse", "7d24cfe9a"], cwd=repo).decode().strip()
assert sha(donor/"candidate.patch") == observed["sourcePatchSHA256"]
assert subprocess.check_output(["git","diff","--binary",source+"^",source,"--","src"],cwd=repo)==(donor/"candidate.patch").read_bytes()
image = donor / "candidate"
files = observed["imageFiles"]["candidate"]
assert len(files) == 32 and {p.name: sha(p) for p in image.iterdir()} == files
shipment = "diagnostic.shipment-routing-callbacks"
rules = "scripts.rule-default-closures"
ordinary = "diagnostic.generated-ordinary-definitions"
catalog = read(external / "representative.json")
catalog["cases"] = [case for case in catalog["cases"] if case["id"] in (shipment, rules, ordinary)]
assert len(catalog["cases"]) == 3
save(lab / "catalog.json", catalog)
save(lab / "identity.json", dict(
    sourceRevision=source, measurementReference=source, imageFiles={"candidate": files},
    coreSHA256={"candidate": files["Lokad.Lython.dll"]},
    cpythonWorkerSHA256=observed["cpythonWorkerSHA256"],
    profiles=[["ordinary-warm", ordinary, "candidate"], ["shipment-async", shipment, "candidate"],
              ["defaulted-rules-through", rules, "candidate"]],
    purpose="Current instruction dispatch, iteration and callable construction after workspace borrowing",
    donorArchiveSHA256=receipt["archiveSHA256"], profileCatalogSHA256=sha(lab / "catalog.json"),
))
sdk = Path.home() / ".dotnet11"
dotnet = sdk / "dotnet.exe"
env = dict(os.environ, DOTNET_ROOT=str(sdk), DOTNET_ROOT_X64=str(sdk))
protocol = repo / "benchmarks/cpython-worker.py"
assert sha(protocol) == observed["cpythonWorkerSHA256"]
proof = lab / "candidate-verification.json"
subprocess.run([dotnet, image / "Lokad.Lython.Benchmarks.dll", "--compare", "verify", "--catalog",
                lab / "catalog.json", "--dotnet", dotnet, "--python", "C:/Python313/python.exe",
                "--python-worker", protocol, "--out", proof], env=env, cwd=repo, check=True, timeout=65)
checked = read(proof)
assert checked["state"] == "Completed" and checked["caseCount"] == 3
assert checked["catalogSha256"] == sha(lab / "catalog.json")
assert checked["launched"]["library"]["sha256"] == files["Lokad.Lython.dll"]


collector = (prior/"collect.py").read_text(encoding="utf-8").replace("retained-async-cpython-b1694-20261125", "iteration-native-storage-prepared-b1708b-20261125").replace("b1696-fixtures", "b1709-fixtures")
ops = (prior/"ops-profile.py").read_text(encoding="utf-8")
launcher = (prior/"quiet.py").read_text(encoding="utf-8")
launcher = launcher.replace("post-async-map-cpu-b1696", "current-workspace-cpu-b1709").replace("lython-b1696-post-async-map-cpu", "lython-b1709-current-workspace-cpu")
launcher = launcher.replace("retained-async-cpython-20261125", "iteration-native-storage-prepared-20261125").replace('checked["caseCount"]==2','checked["caseCount"]==3')
for name, contents in (("quiet.py", launcher), ("collect.py", collector), ("ops-profile.py", ops)):
    compile(contents, name, "exec")
    write(lab / name, contents)

shutil.copyfile(prior / "run.sh", lab / "run.sh")
assert b"\r" not in (lab / "run.sh").read_bytes()
if not (lab / "verified-raw-replicas.json").exists():
    candidates=read(lab/"archived-duplicates.json")
    duplicates=[]
    for row in candidates:
        path=repo/row["path"]
        assert path.is_file() and path.is_relative_to(repo/"benchmarks/results") and sha(path)==row["sha"]
        with tarfile.open(path) as archive:
            member=archive.getmember("confirmation/confirmation.json")
            assert member.isfile() and member.size==row["rawBytes"]
            raw=archive.extractfile(member).read()
            assert json.loads(raw)["complete"]
        duplicates.append(dict(location=row["run"], archiveSHA256=row["sha"], bytes=len(raw), rawSHA256=hashlib.sha256(raw).hexdigest()))
    save(lab / "verified-raw-replicas.json", duplicates)
