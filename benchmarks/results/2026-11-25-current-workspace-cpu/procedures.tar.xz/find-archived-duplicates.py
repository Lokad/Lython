from pathlib import Path
import hashlib,json,subprocess
lab=Path(__file__).resolve().parent
repo=lab.parents[3]
base="/home/lokad/lython-bench-checks"
key=Path.home()/".ssh/id_lython-bench.pem"
ssh=["C:/Windows/System32/OpenSSH/ssh.exe","-i",str(key),"-o","BatchMode=yes","-o","ConnectTimeout=12","lokad@20.166.121.73","python3 -"]
def remote(script):
 proc=subprocess.run(ssh,input=script,capture_output=True,encoding="utf-8",timeout=38)
 if proc.returncode: raise RuntimeError(proc.stderr.strip())
 return json.loads(proc.stdout)
inventory=remote('''
from pathlib import Path
import heapq,json,shutil
p=Path("/home/lokad/lython-bench-checks")
def locations():
 for d in p.iterdir():
  try:
   raw=d/"confirmation/confirmation.json"
   a=d/"observations.tar.xz"
   if raw.is_file() and a.is_file() and raw.stat().st_nlink==1:
    j=json.loads((d/"archive-receipt.json").read_text())
    if j.get("complete") and j.get("allWorkersJoined") and j.get("archivedAndVerifiedUnderLease") and not (d/"guest-fixtures").exists():
      yield (raw.stat().st_size, d.name, a.stat().st_size, j["archiveSHA256"])
  except (OSError,ValueError,KeyError): pass
print(json.dumps({"free":shutil.disk_usage(p).free,"runs":heapq.nlargest(200,locations())}))
''')
by_size={}
for size,name,archive,digest in inventory["runs"]: by_size.setdefault(archive,{})[digest]=name
tracked=subprocess.check_output(["git","ls-files","-z","--","benchmarks/results"],cwd=repo).decode("utf-8").split("\0")
available={}
for name in tracked:
 p=repo/name
 if p.suffix!=".xz" or not p.is_file(): continue
 rs=by_size.get(p.stat().st_size)
 if not rs:continue
 sha=hashlib.sha256(p.read_bytes()).hexdigest()
 if (source:=rs.get(sha)): available[source]={"path":name,"sha":sha}
planned=[]
free=inventory["free"]
for size,run,archive,digest in inventory["runs"]:
 if free>=6*1024*1024: break
 if run not in available: continue
 planned.append(dict(run=run,rawBytes=size,**available[run]))
 free+=size-4096
assert free>=6*1024*1024,(inventory["free"],free,planned)
(lab/"archived-duplicates.json").write_text(json.dumps(planned,indent=2)+"\n",encoding="utf-8",newline="\n")
print(json.dumps({"minimumFreeAfter":free,"copies":len(planned),"freeBefore":inventory["free"]}))
