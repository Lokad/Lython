from pathlib import Path
import hashlib,json,shutil
root=Path("/home/lokad/lython-bench-checks/prepared-text-report-cpu-b248-20261105")
base=Path('/home/lokad/lython-bench-checks/native-preparation-b246-20261105/candidate')
(root/'candidate').symlink_to(base,target_is_directory=True)
for name,expected in json.loads((root/'identity.json').read_text())['files'].items():
 assert hashlib.sha256((base/name).read_bytes()).hexdigest()==expected
assert shutil.disk_usage(root).free>64*1024*1024
