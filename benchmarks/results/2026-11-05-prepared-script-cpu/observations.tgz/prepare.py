from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
root=Path(__file__).resolve().parent
old=root.parent/'ordinary-text-report-cpu-b220'
remote='/home/lokad/lython-bench-checks/prepared-text-report-cpu-b248-20261105'
unit='lython-b248-prepared-text-report-cpu-20261105'
for name in ['launch.py','archive.py','collect.sh','profile.py','analyze-cpu-guest.py','analyze-inclusive.py']:
    text=(old/name).read_text(encoding='utf-8').replace('/home/lokad/lython-bench-checks/ordinary-text-report-cpu-b220-20261104',remote).replace(
        'lython-b220-text-report-cpu-20261104',unit).replace('b220-payload.tgz','b248-payload.tgz')
    if name=='profile.py':
        text=text.replace('for _ in range(64):','for _ in range(128):').replace('env.pop("DOTNET_TieredCompilation", None)','assert env.get("DOTNET_TieredCompilation") is None')
    if name=='collect.sh':
        text=text.replace('flock -n 9','flock -n 9\ndate -u +%FT%TZ > "$root/started.utc"\ntrap \'exit 143\' TERM\ntrap \'result=$?; printf "%s\\n" "$result" > "$root/exit-code.txt"; date -u +%FT%TZ > "$root/stopped.utc"\' EXIT')
    if name=='archive.py':
        text=text.replace('--property=ActiveState,Result,MainPID','--property=LoadState,ActiveState,Result,MainPID')
        text=text.replace("(root/'final-service-status.txt').write_text", "assert (root/'started.utc').is_file() and (root/'stopped.utc').is_file() and (root/'exit-code.txt').read_text().strip()=='0'\n(root/'final-service-status.txt').write_text")
        text=text.replace("assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))", "assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))\n assert subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record'],capture_output=True).returncode==1")
    (root/name).write_text(text,encoding='utf-8',newline='\n')
catalog=json.loads((old/'catalog.json').read_text(encoding='utf-8'))
assert {c['id'] for c in catalog['cases']}=={'scripts.text-summary-helpers.large','scripts.report-render.large'}
(root/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False)+'\n',encoding='utf-8')
identity=json.loads((root.parent/'native-preparation-b246/candidate-identity.json').read_text(encoding='utf-8'))
files=identity['files'];files['Lokad.Lython.dll']=identity['candidateCoreSHA256']
assert files['Lokad.Lython.dll']=='81deb3be4bf45f73a4a6372f1223014edc3bf09e8439f8da1eeffa018d1b4cfa'
(root/'identity.json').write_text(json.dumps(dict(sourceRevision='8475a8dd/current prepared native bodies;attribution only,full CI running',files=files),indent=2)+'\n',encoding='utf-8')
(root/'setup.py').write_text('''from pathlib import Path
import hashlib,json,shutil
root=Path("'''+remote+'''")
base=Path('/home/lokad/lython-bench-checks/native-preparation-b246-20261105/candidate')
(root/'candidate').symlink_to(base,target_is_directory=True)
for name,expected in json.loads((root/'identity.json').read_text())['files'].items():
 assert hashlib.sha256((base/name).read_bytes()).hexdigest()==expected
assert shutil.disk_usage(root).free>64*1024*1024
''',encoding='utf-8')
shutil.copyfile(root/'plan.md',root/'pre-measurement-plan.md')
with tarfile.open(root/'payload.tgz','w:gz') as archive:
    for file in root.iterdir():
        if file.is_file() and file.name not in ['payload.tgz']:archive.add(file,arcname=file.name)
print(json.dumps(dict(payloadBytes=(root/'payload.tgz').stat().st_size,core=files['Lokad.Lython.dll'])))
