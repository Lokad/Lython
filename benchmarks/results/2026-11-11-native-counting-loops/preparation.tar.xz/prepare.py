from pathlib import Path
import hashlib,json,shutil,subprocess
r=Path(__file__).resolve().parent;repo=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert not subprocess.check_output(['git','status','--porcelain'],text=True).strip()
assert not (r/'before.json').exists()
targets=['src/Lokad.Lython/Frontend/ExecutableScript.cs','src/Lokad.Lython/Frontend/ExecutableScript.DictionaryAccumulation.cs',
 'src/Lokad.Lython/Runtime/LythonRuntime.Executable.Interpreter.Dispatch.cs','src/Lokad.Lython/Runtime/LythonRuntime.Executable.DictionaryAccumulation.cs']
for name in targets:
 p=r/'originals'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/name,p)
prior=r.parent/'call-preparation-r236'
for role in ['before','candidate']:
 shutil.copytree(prior/'images/before',r/'images'/role)
 shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',r/'images'/role/'Lokad.Lython.dll')
shutil.copyfile(repo/'src/Lokad.Lython/bin/Release/net10.0/Lokad.Lython.dll',r/'before-net10.dll')
shutil.copyfile(prior/'catalog.json',r/'catalog.json')
for phase in ['warm-sync','warm-async','compile']:
 (r/phase).mkdir();shutil.copyfile(prior/phase/'hash-witness.json',r/phase/'hash-witness.json')
data=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),runtimeSource='698f7e77',
 sourceHashes={p.relative_to(repo).as_posix():sha(p)for p in(repo/'src/Lokad.Lython').rglob('*.cs')if not {'bin','obj'}&set(p.parts)},
 images={role:{p.name:sha(p)for p in(r/'images'/role).iterdir()if p.is_file()}for role in['before','candidate']},
 net10SHA256=sha(r/'before-net10.dll'),
 qualification='R236 retained source:11074 actual11/10 checks. Full platform/stress/package delivery batches with this milestone; qualified15f is the last complete delivery.',
 hypothesis='A complete native text histogram loop, including an optional integer total, can reuse native iteration and non-admitting dictionary updates while eliminating repeated VM dispatch and argument-window publication. No new owner/control hierarchy, plan table, scalar/string representation or execution backend.',
 controls='Maintained CSV/report/JSON are controls; actual CSV loops validate/unpack mediated records and do not match the initial native segment. Both text variants are intended beneficiaries. Compile separate; no predicted CPU gain.')
(r/'before.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print('R237 clean source/binary baseline frozen on '+data['head'][:8]+'. Existing native iteration/no-admission kernel and actual text instruction windows inspected.')
