from pathlib import Path
import json,re,subprocess
r=Path(__file__).resolve().parent
source=Path('tests/Lokad.Lython.PublicApi.Tests/DictionaryCountingLoopTests.cs').read_text(encoding='utf-8')
string=r'"(?:[^"\\]|\\.)*"'
cases=re.findall(r'\{ ('+string+r'), ('+string+r'), ('+string+r') \}',source)
assert len(cases)==12,len(cases)
results=[]
for values in cases:
    name,code,expected=map(json.loads,values)
    p=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',code],capture_output=True,text=True,encoding='utf-8',timeout=10)
    assert p.returncode==0 and p.stdout==expected,(name,p.returncode,p.stdout,p.stderr,expected)
    results.append(dict(case=name,source=code,stdout=p.stdout,stderr=p.stderr,exit=p.returncode))
(r/'cpython-goldens-complete.json').write_text(json.dumps(dict(reference=subprocess.check_output(['C:/Python313/python.exe','--version'],text=True).strip(),cases=results),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('All 12 semantic goldens match isolated CPython 3.13.')
