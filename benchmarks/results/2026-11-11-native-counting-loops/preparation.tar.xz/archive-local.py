from pathlib import Path
import gzip,hashlib,json,tarfile
r=Path(__file__).resolve().parent;repo=Path.cwd()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
before=json.loads((r/'before.json').read_text(encoding='utf-8'))
candidate=json.loads((r/'diagnostic-identity.json').read_text(encoding='utf-8'))
for role,hashes in [('before',before['sourceHashes']),('candidate',candidate['sourceHashes'])]:
 target=r/('sources-'+role+'.tar.xz');assert not target.exists()
 with tarfile.open(target,'w:xz')as t:
  for name,h in hashes.items():
   original=r/'originals'/name
   path=original if role=='before'and original.exists()else repo/name
   assert sha(path)==h,(role,name)
   t.add(path,arcname=name)
 for framework in ['net11.0','net10.0']:
  core=r/'images'/('before'if role=='before'else'candidate')/'Lokad.Lython.dll'if framework=='net11.0'else r/('before-net10.dll'if role=='before'else'candidate-net10.dll')
  expected=(before if role=='before'else candidate)
  assert sha(core)==(expected['images'][role]['Lokad.Lython.dll']if framework=='net11.0'else expected['net10SHA256'])
  with gzip.open(r/(role+'-'+framework+'.dll.gz'),'wb')as out:out.write(core.read_bytes())
fixes=dict(sourceRoute='Initial optional-total recognition inspected BinaryOperator instead of AugmentedOperator. Minimal histogram-only already prepared; after correction both maintained text loops and admission fixture contain the native opcode. Keep both instruction dumps and failed assertions.',
 fixture='Prebuilt dictionary had an explicit empty owner span; growth correctly preserved it. Replaced that fixture span with a meaningful original owner span and enabled existing local mirroring to inspect unwind. It now verifies same failure identity, original span, two completed updates, unchanged failed destination, no suppression, zero outstanding reservations and allowance reuse.',
 build='Initial diagnostic assertion escaped quotes inside a C# interpolation; build failed before tests. Corrected syntax, original build log retained.',
 quietSetup='Initial local retirement candidate was rejected because its core is still a protected reference; a different old path was absent and read-only inventory refused it. No mutation occurred. Final fresh inventory verified one existing63MB source.tar duplicate against its pre-existing persistent independent local original, including path/UID/inode/all aliases/bytes/SHA. Only that duplicate retired; all current images protected. Do not reuse any rejected/retired candidate.')
(r/'corrections.json').write_text(json.dumps(fixes,indent=2)+'\n',encoding='utf-8')
with tarfile.open(r/'preparation.tar.xz','w:xz')as t:
 for path in sorted(r.rglob('*')):
  rel=path.relative_to(r)
  if not path.is_file()or 'images'in rel.parts or 'b576'in rel.parts or 'bin'in rel.parts or 'obj'in rel.parts:continue
  if path.suffix in {'.dll','.xz','.gz'}or rel.parts[0]in ['warm-sync','warm-async','compile']:continue
  t.add(path,arcname=rel.as_posix())
 for name in ['tests/Lokad.Lython.PublicApi.Tests/DictionaryCountingLoopTests.cs','tests/Lokad.Lython.PublicApi.Tests/CooperativeCancellationTests.cs','tests/Lokad.Lython.Tests/DictionaryCountingLoopAdmissionTests.cs']:
  t.add(repo/name,arcname=name)
print('Exact before/candidate sources, both target cores, original failures, instruction proof, goldens and focused checks archived locally.')
