from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;q=r/'b576';q.mkdir(exist_ok=True)
assert not(q/'payload.tgz').exists()
old=r.parent/'closure-operands-r235/b575'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
meta=json.loads((r/'diagnostic-identity.json').read_text(encoding='utf-8'))
for name,h in meta['sourceHashes'].items():assert sha(Path(name))==h,name
root='/home/lokad/lython-bench-checks/native-counter-loops-b576-20261111'
unit='lython-b576-native-counter-loops-20261111'
aux=json.loads((old/'identity.json').read_text(encoding='utf-8'))['auxiliaryFiles']
identity=dict(sourceRevision='R237 uncommitted native histogram-loop prototype versus exact retained698 sources on clean1ce; both freshly frozen actual.NET11 cores, 2692 focused actual11/10 checks. Fixed common quiet worker differs from separately identified desktop worker. Only core changes; no CPython or isolated-allocation claim.',
 coreSHA256={role:meta['images']['before'if role.startswith('reference')else'candidate']['Lokad.Lython.dll']for role in ['reference','candidate','reference-control','candidate-control']},
 auxiliaryFiles=aux,catalogSHA256=sha(r/'catalog.json'))
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
source=dict(beforeRevision='1ce7fbbc',runtimeBefore='698f7e77',prototypeUncommitted=True,sourceSHA256=meta['sourceHashes'],changedProductionFiles=meta['changedProductionFiles'],focusedChecks=2692,sourceQualification='Actual11/10 focused checks only; last full delivery15f. No fully qualified claim for either new core.')
(q/'source-identity.json').write_text(json.dumps(source,indent=2)+'\n',encoding='utf-8')
shutil.copyfile(r/'catalog.json',q/'representative.json')
for role,name in [('before','baseline-core.dll'),('candidate','current-core.dll')]:shutil.copyfile(r/'images'/role/'Lokad.Lython.dll',q/name)
jobs=[['scripts.text-summary-helpers.nonlocal-counter.large','warm'],['scripts.text-summary-helpers.large','warm'],['scripts.text-summary-helpers.nonlocal-counter.large','warm-async'],['scripts.text-summary-helpers.large','warm-async'],['scripts.csv-validated-records.nonlocal-counter.large','warm-async']]
text=(old/'collect.py').read_text(encoding='utf-8').replace('/closure-operands-b575-20261111','/native-counter-loops-b576-20261111')
begin=text.index('jobs=');end=text.index('\nenv = ',begin)
text=text[:begin]+'jobs='+repr(jobs)+'\nassert len(jobs)==5 and all(case in cases for case,lane in jobs)\n'+text[end:]
text=text.replace("< 140, 'Reserve40seconds","< 170, 'Reserve40seconds")
begin=text.index("purpose='R235");end=text.index("',\n                  warmupSeconds",begin)
text=text[:begin]+"purpose='R237 bounded native-loop confirmation versus retained698, both text variants/APIs and unchanged capturedCSV async control; complete warm includes mediated RAM I/O/full checks/prior-result cleanup, excludes compile/startup/reset/protocol/final caches. No CPython ratio"+text[end:]
ast.parse(text);(q/'collect.py').write_text(text,encoding='utf-8',newline='\n')
for name in ['archive-owned.py','run.sh','retrieve.py','summarize.py']:
 text=(old/name).read_text(encoding='utf-8').replace('closure-operands-b575','native-counter-loops-b576').replace('lython-b575-closure-operands','lython-b576-native-counter-loops').replace('==4','==5').replace('jobs=4','jobs=5').replace('jobs=4,','jobs=5,').replace('jobs=4','jobs=5').replace("jobs']==4","jobs']==5").replace("elapsedSeconds']<180","elapsedSeconds']<210").replace('B575 four-job','B576 five-job')
 if name.endswith('.py'):ast.parse(text)
 (q/name).write_text(text,encoding='utf-8',newline='\n')
text=(old/'launch.py').read_text(encoding='utf-8').replace('closure-operands-b575-launch','native-counter-loops-b576-launch').replace('seconds=240','seconds=270').replace('ownerSeconds=180','ownerSeconds=210')
(q/'launch.py').write_text(text,encoding='utf-8',newline='\n')
retire=[]
for canonical,known,member in [
 ('benchmarks/results/2026-11-11-captured-operand-transport/quiet/observations.tgz','closure-operands-b575-20261111/current-core.dll','current-core.dll'),
 ('benchmarks/results/2026-11-10-integer-local-storage/refined/observations.tgz','native-integer-b536-20261110/current-core.dll','current-core.dll'),
 ('benchmarks/results/2026-11-11-captured-operand-transport/quiet/observations.tgz','closure-operands-b575-20261111/observations.tgz',None)]:
 p=Path(canonical);subprocess.run(['git','ls-files','--error-unmatch',canonical],check=True,capture_output=True)
 if member:
  with tarfile.open(p)as t:raw=t.extractfile(member).read()
 else:raw=p.read_bytes()
 spec=dict(kind='core'if member else'exact',knownPath=known,canonical=canonical,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
 if member:spec['canonicalMember']=member
 assert spec['sha256']not in json.loads((r/'vm-fresh-inventory.json').read_text(encoding='utf-8'))['protected'].values()
 retire.append(spec)
with tarfile.open(q/'payload.tgz','w:gz')as t:
 for name in ['baseline-core.dll','current-core.dll','representative.json','source-identity.json','identity.json','collect.py','archive-owned.py','run.sh']:t.add(q/name,arcname=name)
with tarfile.open(q/'payload.tgz')as t:expanded=sum(((m.size+4095)//4096)*4096 for m in t.getmembers())
config=dict(root=root,unit=unit,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha(q/'payload.tgz'),requiredFreeBytes=252*1024*1024+expanded+65536,retire=retire,identity=identity)
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
text=(old/'remote-launch.py').read_text(encoding='utf-8')
begin=text.index('protected=');end=text.index('\nwith(base/',begin)
protected=json.loads((r/'vm-fresh-inventory.json').read_text(encoding='utf-8'))['protected']
text=text[:begin]+'protected={base/name:h for name,h in '+repr(protected)+'.items()}'+text[end:]
text=text.replace("os.link(source/'Lokad.Lython.dll',root/'baseline-core.dll')\n ",'')
text=text.replace(" (root/'candidate/Lokad.Lython.dll').unlink();os.link(root/'current-core.dll',root/'candidate/Lokad.Lython.dll')", " for role,name in [('reference','baseline-core.dll'),('candidate','current-core.dll')]:\n  (root/role/'Lokad.Lython.dll').unlink();os.link(root/name,root/role/'Lokad.Lython.dll')")
text=text.replace('lython-b575-fixtures','lython-b576-fixtures').replace('jobs=4','jobs=5').replace('ownerSeconds=180','ownerSeconds=210').replace('RuntimeMaxSec=180','RuntimeMaxSec=210').replace("canonicalCommit='64b6800c'","canonicalCommit='1ce7fbbc'")
ast.parse(text.replace('config=CONFIG','config='+repr(config)).replace('inventoryOnly=INVENTORY_ONLY','inventoryOnly=True'))
(q/'remote-launch.py').write_text(text,encoding='utf-8',newline='\n')
print('Prepared five short source-pair jobs,210sowner. Fresh exact inventory before mutation; no retired path reused, current role images preserved.')
