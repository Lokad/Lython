from pathlib import Path
import json,subprocess
r=Path(__file__).resolve().parent
script='''from pathlib import Path
import fcntl,hashlib,json,os,shutil,subprocess
base=Path('/home/lokad/lython-bench-checks').resolve()
with(base/'comparison-vm.lock').open('a')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
 users=subprocess.run(['pgrep','-af','[d]otnet.* --compare worker|[p]erf record|[c]omplete-jobs.dll|[p]ython3.*cpython-worker.py'],capture_output=True,text=True)
 assert users.returncode in(0,1) and not users.stdout,users.stdout
 assert not list(Path('/dev/shm').glob('lython-comparison-files-*'))
 protected={'constructor-binding-b574-20261111/candidate/Lokad.Lython.dll':'f5ae2355139a', 'iteration-returns-b570-20261111/candidate/Lokad.Lython.dll':'9ee7e700580399ff80d803f0a7535d2de5ff0f10d35a736370f457383be1b67f','json-string-b565-20261111/reference/Lokad.Lython.dll':'c27160d53d66489976b181fb425b2f46c927fa85156433b80dc6f5477a3e5506'}
 # The current qualified15f quiet core has its own recorded hash, not the
 # separately frozen local core. Read its exact expected quiet identity.
 identity=json.loads((base/'constructor-binding-b574-20261111/identity.json').read_text())
 protected['constructor-binding-b574-20261111/candidate/Lokad.Lython.dll']=identity['coreSHA256']['candidate']
 for name,h in protected.items():assert hashlib.sha256((base/name).read_bytes()).hexdigest()==h,name
 files=[]
 for p in base.rglob('*'):
  if p.is_file() and not p.is_symlink():
   s=p.stat()
   if s.st_size>1000000:files.append(dict(path=p.relative_to(base).as_posix(),bytes=s.st_size,allocated=s.st_blocks*512,links=s.st_nlink,uid=s.st_uid))
 print(json.dumps(dict(freshIdleLease=True,protected=protected,freeBytes=shutil.disk_usage(base).free,files=sorted(files,key=lambda f:f['allocated'],reverse=True)[:55])))
'''
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -'],input=script,capture_output=True,text=True,encoding='utf-8',timeout=40)
(r/'vm-fresh-inventory.stdout').write_text(p.stdout,encoding='utf-8');(r/'vm-fresh-inventory.stderr').write_text(p.stderr,encoding='utf-8')
assert p.returncode==0,p.stderr
data=json.loads(p.stdout);(r/'vm-fresh-inventory.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print(json.dumps(data,indent=2))
