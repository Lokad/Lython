from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent;q=r/'b576'
assert not(q/'observe-not-before.json').exists()
# Earlier source packaging already has a complete independent persistent local
# copy. Retire only its freshly verified remote duplicate, not a current core.
p=Path('.git/agent-notes/fresh-csv-20261017/source.tar')
assert p.is_file() and p.stat().st_size==63375360
config=json.loads((q/'config.json').read_text(encoding='utf-8'))
(q/'config-rejected-space-candidate.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
config['retire']=[dict(kind='exact',knownPath='fresh-csv-20261017/source.tar',canonical=str(p.resolve()),
    canonicalStorage='Pre-existing persistent local working evidence, independently byte-verified; not a sole VM copy. No new release bundle or source archive created.',
    bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())]
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
path=q/'remote-launch.py';text=path.read_text(encoding='utf-8').replace("canonicalCommit='1ce7fbbc'","canonicalStorage='Pre-existing independently verified persistent local source.tar; exact path/bytes/SHA recorded in files'")
path.write_text(text,encoding='utf-8',newline='\n')
print('Selected existing63MB source-package duplicate with independently verified persistent local original; all current cores and evidence remain.')
