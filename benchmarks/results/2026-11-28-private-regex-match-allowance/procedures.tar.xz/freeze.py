from hashlib import sha256
from pathlib import Path
from shutil import copy2, copytree
import json
import subprocess
import zipfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
source = lab.parent / 'staged-generator-activation-refined-b1936-20261128'
reference = lab.parent / 'current-shipment-checkpoint-b1937-20261128/comparison/quiet'
old = lab.parent / 'current-checkpoint-b1932-20261128/comparison/quiet'
groups = lab.parent / 'regex-group-costs-b1931-20261128/comparison-corrected'
signed = lab.parent / 'regex-released-050-20261127'
pair = lab / 'comparison'
adapter = 'Lokad.Lython.Utf8Regex.dll'
build = lab / 'ubuntu-artifacts/bin/Lokad.Lython.Utf8Regex/release_net11.0' / adapter
def digest(path):
    return sha256(path.read_bytes()).hexdigest()
def read(path):
    return json.loads(path.read_bytes())
def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')
def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo)
def files(folder):
    return {path.name:digest(path) for path in folder.iterdir()}
def adapt(old, new, replacements):
    text = old.read_text(encoding='utf-8')
    for before,after in replacements:
        assert before in text, before
        text = text.replace(before,after)
    new.write_text(text, encoding='utf-8', newline='\n')

head = git('rev-parse','HEAD').decode().strip()
identity = read(reference/'identity.json')
assert not git('diff','--binary',identity['sourceRevision'],head,'--','src','Directory.Packages.props')
assert git('diff','--name-only','HEAD').decode().splitlines() == ['src/Lokad.Lython.Utf8Regex/Utf8RegexProvider.cs']
donor = reference/'local-image'
assert files(donor) == identity['imageFiles']['candidate'] and len(files(donor)) == 32
producer = {}
for dll in ('Lokad.Utf8Regex.dll','Lokad.Utf8Regex.PythonRe.dll'):
    name = dll.lower().removesuffix('.dll') + '.0.5.0.nupkg'
    package = signed / name
    assemblies = {}
    with zipfile.ZipFile(package) as archive:
        for tfm in ('net10.0','net11.0'):
            sha = sha256(archive.read(f'lib/{tfm}/{dll}')).hexdigest()
            assemblies[tfm] = sha
            for suite in ('Lokad.Lython.PublicApi.Tests','Lokad.Lython.Tests'):
                assert digest(repo/'tests'/suite/'bin/Release'/tfm/dll) == sha
                if tfm == 'net11.0':
                    assert digest(lab/'ubuntu-artifacts/bin'/suite/'release_net11.0'/dll) == sha
            if tfm == 'net11.0':
                assert digest(donor/dll) == sha
    producer[name] = dict(sha256=digest(package), dll=dll, assemblies=assemblies)
write(lab/'producer.json',producer)
pair.mkdir()
for role in ('reference','candidate'):
    copytree(donor,pair/role)
copy2(build,pair/'candidate'/adapter)
images = {role:files(pair/role) for role in ('reference','candidate')}
assert images['reference'] == identity['imageFiles']['candidate']
assert {name for name, sha in images['reference'].items() if images['candidate'][name] != sha} == {adapter}
assert images['candidate'][adapter] == digest(build)
patch = git('diff','--binary','HEAD','--','src/Lokad.Lython.Utf8Regex')
(lab/'candidate.patch').write_bytes(patch)

def catalog(folder):
    p=folder/'representative.json'
    assert digest(p) == read(folder/'identity.json')['catalogs'][p.name]['sha256']
    return read(p)
selection = catalog(old)
control = catalog(groups)
assert selection['catalogVersion'] == control['catalogVersion']
available = {case['id']: case for case in selection['cases'] + control['cases']}
ids = ('scripts.regex-log-search.compiled', 'scripts.regex-log-search.module', 'scripts.regex-unicode-groups', 'diagnostic.file-search-first-line')
selection['cases'] = [available[case_id] for case_id in ids]
write(pair/'representative.json',selection)
write(pair/'jobs.json',{'warm':[[case_id,'warm'] for case_id in ids]})
copy2(reference/'cpython-worker.py',pair/'cpython-worker.py')
assert digest(pair/'cpython-worker.py') == identity['cpythonWorkerSHA256']
write(pair/'identity.json',dict(sourceRevision=head, sourcePatchSHA256=sha256(patch).hexdigest(), imageFiles=images,
    coreSHA256={label:images[role]['Lokad.Lython.dll'] for role in images for label in (role,role+'-control')},
    catalogs={name:{'sha256':digest(pair/name)} for name in ('representative.json','jobs.json')},
    cpythonWorkerSHA256=identity['cpythonWorkerSHA256'], expectedCPythonSHA256=identity['expectedCPythonSHA256'],
    purpose='Remove the adapter monitor and its object on each synchronous one-shot working allowance.'))
adapt(source/'comparison/run.sh',pair/'run.sh',[('270s','220s')])
assert b'\r' not in (pair/'run.sh').read_bytes()
adapt(source/'comparison/collect.py',pair/'collect.py',[
    ('-started < 255','-started < 205'),('assert len(jobs) == 5','assert len(jobs) == 4')])
adapt(source/'summarize.py',lab/'summarize.py',[
    ('receipt["warmJobs"] == 5','receipt["warmJobs"] == 4'),('== 140','== 112'),
    ('assert libraries["Lokad.Lython.Benchmarks.dll"] == identity["imageFiles"][role]["Lokad.Lython.Benchmarks.dll"]',
     'assert libraries["Lokad.Lython.Benchmarks.dll"] == identity["imageFiles"][role]["Lokad.Lython.Benchmarks.dll"]\n        if "Lokad.Lython.Utf8Regex.dll" in libraries:\n            assert libraries["Lokad.Lython.Utf8Regex.dll"] == identity["imageFiles"][role]["Lokad.Lython.Utf8Regex.dll"]')])
adapt(source/'measure-allocation.py',lab/'measure-allocation.py',[
    ("=={'Lokad.Lython.dll'}","=={'Lokad.Lython.Utf8Regex.dll'}")])
print('Four matched lanes and all signed producer assemblies verified.')
