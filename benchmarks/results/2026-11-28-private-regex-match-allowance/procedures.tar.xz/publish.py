from hashlib import sha256
from pathlib import Path
from shutil import copy2
from subprocess import check_output
import json
import re
import tarfile

lab = Path(__file__).resolve().parent
repo = lab.parents[3]
pair = lab / 'comparison'
out = repo / 'benchmarks/results/2026-11-28-private-regex-match-allowance'
def read(path):
    return json.loads(path.read_bytes())
def digest(path):
    return sha256(path.read_bytes()).hexdigest()

identity = read(pair/'identity.json')
patch = check_output(['git','diff','--binary',identity['sourceRevision'],'--','src/Lokad.Lython.Utf8Regex'],cwd=repo)
assert patch == (lab/'candidate.patch').read_bytes() and sha256(patch).hexdigest() == identity['sourcePatchSHA256']
assert not check_output(['git','diff','--binary',identity['sourceRevision'],'--','src/Lokad.Lython'],cwd=repo)
for role,manifest in identity['imageFiles'].items():
    assert len(manifest)==32 and {p.name:digest(p) for p in (pair/role).iterdir()} == manifest
assert {name for name, checksum in identity['imageFiles']['reference'].items()
        if identity['imageFiles']['candidate'][name] != checksum} == {'Lokad.Lython.Utf8Regex.dll'}
summary = read(pair/'summary.json')
assert summary['verifiedTimedBatches']==112 and len(summary['rows'])==4
receipt = read(pair/'archive-receipt.json')
assert all(receipt[key] for key in ('complete','allWorkersJoined','guestFixturesRemoved','archivedAndVerifiedUnderLease'))
assert receipt['archiveSHA256']==digest(pair/'observations.tar.xz')
alloc = read(lab/'allocation/summary.json')
assert len(alloc)==8 and all(row['compiled'][0]==row['compiled'][1] and row['admittedPeak'][0]==row['admittedPeak'][1] for row in alloc)
assert {row['clr'][0]-row['clr'][1] for row in alloc if row['case']=='scripts.regex-log-search.compiled'}=={73728}
for row in alloc:
    if row['case']=='scripts.regex-log-search.module':
        assert abs(row['clr'][0]-row['clr'][1]-73728)<=56
    if row['case'] not in ('scripts.regex-log-search.compiled','scripts.regex-log-search.module'):
        assert row['clr'][0]==row['clr'][1]
out.mkdir(exist_ok=True)
artifacts = {name:pair/name for name in ('identity.json','summary.json','observations.tar.xz','archive-receipt.json')}
artifacts['allocation.json'] = lab/'allocation/summary.json'
artifacts['producer.json'] = lab/'producer.json'
for name,path in artifacts.items():
    copy2(path,out/name)
    assert digest(out/name)==digest(path)
logs = sorted(lab.glob('*-Lokad.Lython.*Tests-net*.log'))
assert len(logs)==6
for log in logs:
    count=716 if 'PublicApi' in log.name else 102
    assert re.search(rf'Failed: +0, Passed: +{count}, Skipped: +0',log.read_text(encoding='utf-8-sig')),log
procedures = {p.name:p for p in logs}
for name in ('candidate.patch','freeze.py','test-ubuntu.sh','test-windows.ps1',
             'ubuntu-adapter-build.log','summarize.py','measure-allocation.py','publish.py'):
    procedures[name]=lab/name
for name in ('collection.log','reference-verify.json','candidate-verify.json','exit-code.txt'):
    procedures[name]=pair/name
for p in (lab/'allocation').glob('*.json'):
    procedures[f'allocation/{p.name}']=p
with tarfile.open(out/'procedures.tar.xz','w:xz') as archive:
    for name,path in procedures.items():
        archive.add(path,arcname=name)
with tarfile.open(out/'procedures.tar.xz') as archive:
    assert all(digest(path)==sha256(archive.extractfile(name).read()).hexdigest() for name,path in procedures.items())
print('Private regex allowance evidence verified.')
