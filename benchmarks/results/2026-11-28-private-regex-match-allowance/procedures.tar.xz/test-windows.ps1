$root=(Get-Location).Path
$lab="$root/.git/agent-notes/review-20261031/private-regex-allowance-b1938-20261128"
$env:NUGET_PACKAGES="$root/.git/agent-notes/review-20261031/regex-released-050-20261127/packages"
$exe=Join-Path $env:USERPROFILE '.dotnet11/dotnet.exe'
$filter='Category!=Stress&(FullyQualifiedName~Regex|FullyQualifiedName~Fnmatch|FullyQualifiedName~Glob)'
foreach ($tfm in 'net11.0','net10.0') {
  foreach ($suite in 'Lokad.Lython.PublicApi.Tests','Lokad.Lython.Tests') {
    $log="$lab/windows-$suite-$tfm.log"
    & $exe test "tests/$suite/$suite.csproj" -c Release -f $tfm --filter $filter *> $log
    $code=$LASTEXITCODE
    if ($code -ne 0) { Get-Content $log -Encoding utf8 -Tail 45; exit $code }
    Get-Content $log -Encoding utf8 -Tail 2
  }
}
