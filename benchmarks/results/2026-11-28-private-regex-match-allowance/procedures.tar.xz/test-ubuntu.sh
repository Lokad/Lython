#!/bin/bash
set -euo pipefail
cd /mnt/d/code/Lython
lab=.git/agent-notes/review-20261031/private-regex-allowance-b1938-20261128
export NUGET_PACKAGES=$PWD/.git/agent-notes/review-20261031/regex-released-050-20261127/packages-ubuntu
log="$lab/ubuntu-adapter-build.log"
~/.dotnet/dotnet build src/Lokad.Lython.Utf8Regex/Lokad.Lython.Utf8Regex.csproj -c Release -f net11.0 --artifacts-path "$lab/ubuntu-artifacts" --no-incremental --disable-build-servers > "$log" 2>&1 || { tail -50 "$log"; exit 1; }
tail -5 "$log"
filter='Category!=Stress&(FullyQualifiedName~Regex|FullyQualifiedName~Fnmatch|FullyQualifiedName~Glob)'
for suite in Lokad.Lython.PublicApi.Tests Lokad.Lython.Tests; do
  log="$lab/ubuntu-$suite-net11.0.log"
  ~/.dotnet/dotnet test "tests/$suite/$suite.csproj" -c Release -f net11.0 --artifacts-path "$lab/ubuntu-artifacts" --filter "$filter" > "$log" 2>&1 || { tail -50 "$log"; exit 1; }
  tail -2 "$log"
done
