from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path(__file__).resolve().parent;q=r/'b598';out=Path('benchmarks/results/2026-11-12-native-inputs-cpython-checkpoint');assert not out.exists()
receipt=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'));summary=json.loads((q/'summary.json').read_text(encoding='utf-8'))
assert receipt['complete']and receipt['jobs']==18 and receipt['allWorkersJoined']and receipt['guestFixturesRemoved']and receipt['quietBeforeAndAfter']and receipt['archivedAndVerifiedUnderLease']
assert hashlib.sha256((q/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
core=summary['coreSHA256']['candidate']
with tarfile.open(q/'observations.tgz')as a:
 assert hashlib.sha256(a.extractfile('current-core.dll').read()).hexdigest()==core
 raw=json.loads(a.extractfile('confirmation/confirmation.json').read());assert raw['complete']and len(raw['jobs'])==18
 for job in raw['jobs']:
  assert job['workersJoinedAndFixturesRemoved']
  for name,identity in job['identities'].items():
   if name.startswith('candidate'):assert next(v['sha256']for v in identity['libraries']if Path(v['path']).name=='Lokad.Lython.dll').lower()==core
out.mkdir();shutil.copyfile('docs/BENCHMARKS.md',out/'prior-BENCHMARKS.md')
for n in ['summary.json','identity.json','source-identity.json','archive-receipt.json','observations.tgz','terminal-status.json','inventory.json','config.json','observe-not-before.json','launch.log']:shutil.copyfile(q/n,out/n)
with tarfile.open(out/'preparation.tar.xz','w:xz')as a:
 for p in [*q.glob('*.py'),q/'run.sh',r/'prepare-external.py',r/'record-external.py']:a.add(p,arcname=p.name)
mapping={'scripts.text-summary-helpers.nonlocal-counter.large':'Text / captured helper + counter','scripts.text-summary-helpers.large':'Text summary/helpers','scripts.csv-validated-records.large':'CSV validation/helper calls','scripts.json-summary-helpers.large':'JSON-lines/helpers','scripts.report-render.large':'JSON-to-Markdown report','scripts.file-search.large':'File search / keyword-default helper'}
rows={(mapping[j['case']],j['lane']):j for j in summary['timing']}
def times(v):
 factor,unit,digits=(1,'ms',3)if max(v)>=.5 else(1000,'µs',2)
 return f'{min(v)*factor:.{digits}f}–{max(v)*factor:.{digits}f} {unit}'
guide=Path('docs/BENCHMARKS.md');text=guide.read_text(encoding='utf-8');lane='compile-run';count=0;lines=[]
for line in text.splitlines():
 if line=='## Warm execution, compilation and startup':lane='warm'
 if line.startswith('Compilation alone includes'):lane='compile'
 fields=line.split('|')
 if len(fields)>=7 and fields[1].strip()in mapping.values():
  row=rows[(fields[1].strip(),lane)];start=3 if lane=='compile-run' else 2
  fields[start]=' '+times(row['timeRangeMilliseconds'])+' ';fields[start+1]=' '+times(row['pythonTimeRangeMilliseconds'])+' '
  fields[start+2]=f" {min(row['ratioRange']):.2f}–{max(row['ratioRange']):.2f}× ";fields[start+3]=' `2ec9d67f` '
  fields[start+4]=f" {row['status']}; L{row['controlPercent']:.2f}%, P{row['pythonControlPercent']:.2f}% / {max(row['iqrPercent'].values()):.2f}% "
  line='|'.join(fields);count+=1
 lines.append(line)
assert count==18,count;text='\n'.join(lines)+'\n'
start=text.index('**Measured source:**');end=text.index('The captured-helper variant',start)
text=text[:start]+f'''**Measured source:** retained `2ec9d67f`, 2026-11-12 (collection began
2026-11-11 UTC), frozen core `{core[:8]}` with precommit assembly metadata.
All production source hashes match. Stock CPython 3.13.16 runs on the same VM.
Full Windows/Ubuntu .NET11/10 tests and installed Release consumers pass;
original stress qualification is separately pending in the delivery checkpoint.
Earlier rows remain historical: `4aa` = qualified `4aa2d46d` (patch, 2026-11-11),
`ee44` = `ee448715` (config/original search, 2026-11-10), `6f76` = `6f76f99d`
(CSV summary, 2026-11-08), `4598` = `459813a3` (manifest, 2026-11-09).
They do not describe current HEAD.

The [six-script checkpoint](../benchmarks/results/2026-11-12-native-inputs-cpython-checkpoint/README.md)
refreshes compilation, warm execution and compile-to-result with existing workers
and unchanged sources/fixtures. All identity/output/ownership/quiet/join/archive
gates pass. Its [prior guide](../benchmarks/results/2026-11-12-native-inputs-cpython-checkpoint/prior-BENCHMARKS.md)
preserves the replaced `8f8628a4` rows, detailed historical improvements, adverse
results and uncertainty. Separate checkpoints cannot attribute a gain to one change.

'''+text[end:]
start=text.index('Actual .NET 11 RC3');end=text.index('Identical scripts and fixtures',start)
text=text[:start]+f'''Actual .NET 11 RC3 and isolated CPython 3.13.16 use ordinary GC/tiering;
five-second warmups per role/job and seven rotated 150 ms rounds. Six current
scripts use core `{core[:8]}` (retained `2ec9d67f` production sources), fixed common
worker `fec79afd` and optional adapter 0.4. Other rows keep their recorded images.
These observations do not qualify a newer regex producer.

'''+text[end:]
start=text.index('Captured text retains a substantial');end=text.index('Original literal-prefix search and config',start)
text=text[:start]+'''Captured text retains a substantial warm gap at1.74×CPython; keyword-default
search is1.52–1.60×. Ordinary text is0.99–1.06×, CSV1.08–1.09×, JSON-lines0.85–0.89×,
report1.26–1.31×. Ordinary/JSON/search/report retain variable cases. Search complete
compile-to-result is1.51–1.55×. Current source-pair text gains do not translate into
the same external ratio change: both engines have new observations. No isolated
cause follows from comparison with an earlier checkpoint.

Additional reportAsync source-pair widerCPU0..+6.25% versus8f8628a4 remains accepted
uncertainty; its elapsed overlaps zero. Earlier8f8628a4 report debt has a different
reference. Do not compound/equate those ranges; these synchronous external rows do
not settle either async issue. Allocation reduction alone does not establish CPU
gain, and independently measured compilation/warm medians need not sum.

'''+text[end:]
start=text.index('| Change / affected work');end=text.index('Other delivered source pairs',start)
oldtable=text[start:end];kept=[]
for line in oldtable.splitlines():
 if line.startswith('| Change /')or line.startswith('| ---')or any(line.startswith('| '+label)for label in ['Native dictionary integer storage','Captured native helper sequences','Shared compiled workspace','Private integer totals','Native helper-return expressions','Direct UTF8 formatting/storage']):kept.append(line)
kept.insert(2,'| Native storage and borrowed call inputs / complete text | Allocation−20.43–22.44%; quiet captured Run elapsed−8.74..−4.66%, ordinary Run−9.68..−8.54%/RunAsync−12.48..−9.49%, supporting CPU | Retained2ec9d67f versus8f8628a4. Captured async CPU uncertain; earlier search/CSV adversity not reproduced without a cause claim. Additional reportAsync CPU0..+6.25% uncertainty accepted; full stress qualification pending. [Source pair](../benchmarks/results/2026-11-12-native-inputs/README.md) |')
text=text[:start]+'\n'.join(kept)+'\n\n'+text[end:]
text=text.replace('Other delivered source pairs, rejected designs, detailed qualification and original','Detailed older source pairs remain in the [prior guide](../benchmarks/results/2026-11-12-native-inputs-cpython-checkpoint/prior-BENCHMARKS.md).\nOther delivered source pairs, rejected designs, detailed qualification and original')
guide.write_text(text,encoding='utf-8')
print('Archived exact18-job checkpoint and prior guide. Updated18 revision-labelled rows; condensed historical improvements behind links. Full stress qualification remains separately pending.')
