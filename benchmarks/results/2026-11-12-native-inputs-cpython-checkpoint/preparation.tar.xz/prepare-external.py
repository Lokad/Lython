from pathlib import Path
import ast,hashlib,json,shutil,subprocess,tarfile
r=Path(__file__).resolve().parent;q=r/'b598';q.mkdir();old=r.parent/'dictionary-value-storage-r245/b590'
sha=lambda b:hashlib.sha256(b).hexdigest();name='native-inputs-cpython-b598-20261112';unit='lython-b598-native-inputs-cpython-20261112'
meta=json.loads((r/'diagnostic-identity.json').read_text(encoding='utf-8'))
for n,h in meta['sourceHashes'].items():assert sha(Path(n).read_bytes())==h,n
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head.startswith('2ec9d67f')
identity=json.loads((old/'identity.json').read_text(encoding='utf-8'))
identity.update(sourceRevision='Retained2ec9d67f native storage/input migration, exact frozen source/core with precommit assembly metadata. All production source hashes match. 10904focused actual11/10 plus14overlapping cell/reentry checks pass. Full43119174279 dispatched once separately pending. Six unchanged complete scripts versus stockCPython3.13.16; compilation/warm/compile-to-result separate. R250originaladversity/B596diagnosticuncertainty/B597combinedsourcepair preserved. Additional reportAsync widerCPU uncertainty not settled by synchronous external rows.',coreSHA256={role:meta['images']['candidate']['Lokad.Lython.dll']for role in ['candidate','candidate-control']},catalogSHA256=sha((old/'representative.json').read_bytes()),protectedPriorReferenceSHA256=meta['images']['before']['Lokad.Lython.dll'])
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8')
(q/'source-identity.json').write_text(json.dumps(dict(sourceRevision=head,sourceSHA256=meta['sourceHashes'],changedProductionFiles=meta['changedProductionFiles'],qualification='10904focused actual11/10,14cell/reentry checks; full43119174279active, not yet qualified.',measuredBinary='Exact frozen B597 candidate; precommit informational metadata. No rebuild/reinterpretation from timestamps.'),indent=2)+'\n',encoding='utf-8')
shutil.copyfile(old/'representative.json',q/'representative.json')
for filename in ['collect.py','archive-owned.py','run.sh','launch.py','retrieve.py','summarize.py','remote-launch.py']:
 s=(old/filename).read_text(encoding='utf-8').replace('dictionary-checkpoint-b590-20261111',name).replace('lython-b590-dictionary-checkpoint-20261111',unit).replace('dictionary-checkpoint-b590-launch.py','native-inputs-cpython-b598-launch.py').replace('lython-b590-fixtures','lython-b598-fixtures').replace('B590','B598')
 if filename=='remote-launch.py':
  s=s.replace("source=base/'dictionary-values-b589-20261111/candidate'","source=base/'native-inputs-b597-20261112/candidate'")
  s=s.replace("protected={source/'Lokad.Lython.dll':config['identity']['coreSHA256']['candidate']}","protected={source/'Lokad.Lython.dll':config['identity']['coreSHA256']['candidate'],base/'native-inputs-b597-20261112/reference/Lokad.Lython.dll':config['identity']['protectedPriorReferenceSHA256']}")
 if filename=='collect.py':
  a=s.index("purpose='");b=s.index("',\n                  warmupSeconds",a)
  s=s[:a]+"purpose='Retained2ec9d67f native storage/input checkpoint versus stock CPython3.13.16. Six unchanged representative scripts; compilation, warm and compile-to-result separate. Fixed common worker/adapter and original command-v2 boundary. No isolated source-change attribution; reportAsync CPU uncertainty remains separate"+s[b:]
 (q/filename).write_text(s,encoding='utf-8',newline='\n')
 if filename.endswith('.py')and filename!='remote-launch.py':ast.parse(s)
with tarfile.open(q/'payload.tgz','w:gz')as a:
 for n in ['representative.json','identity.json','source-identity.json','collect.py','archive-owned.py','run.sh']:a.add(q/n,arcname=n)
with tarfile.open(q/'payload.tgz')as a:expanded=sum(((m.size+4095)//4096)*4096 for m in a.getmembers())
retire=[]
for remote,canonical in [
 ('native-inputs-b597-20261112/observations.tgz','benchmarks/results/2026-11-12-native-inputs/quiet/observations.tgz'),
 ('native-inputs-b597-20261112/representative.json','benchmarks/results/2026-11-12-native-inputs/quiet/representative.json'),
 ('dictionary-values-b588-20261111/representative.json','benchmarks/results/2026-11-11-dictionary-integer-storage/initial/quiet/representative.json'),
 ('known-call-binding-b586-20261111/representative.json','benchmarks/results/2026-11-11-known-call-binding/initial/quiet/representative.json')]:
 p=Path(canonical);b=p.read_bytes();assert b==subprocess.check_output(['git','show','HEAD:'+p.as_posix()])
 retire.append(dict(kind='exact',knownPath=remote,bytes=len(b),sha256=sha(b),canonicalStorage=p.as_posix(),reason='Unused terminal duplicate archive/catalog. Fresh read-only inventory confirms existence; exact committed Git bytes verified. Both current selected core roles protected; new checkpoint supplies own catalog. Fresh path/UID/inode/all-alias proof required.'))
p=Path('benchmarks/results/2026-11-11-current-storage-costs/observations.tgz');b=p.read_bytes();assert b==subprocess.check_output(['git','show','HEAD:'+p.as_posix()])
with tarfile.open(p)as a:data=a.extractfile('profiles/prefix-jit.txt').read()
retire.append(dict(kind='exact',knownPath='current-value-profile-b591-20261111/profiles/prefix-jit.txt',bytes=len(data),sha256=sha(data),canonicalStorage=p.as_posix(),canonicalArchiveSHA256=sha(b),canonicalEntry='profiles/prefix-jit.txt',reason='Unused terminal duplicate disassembly; exact committed archive entry verified. Current source/profiles remain preserved; fresh path/UID/inode/all-alias proof required.'))
config=dict(root='/home/lokad/lython-bench-checks/'+name,unit=unit,payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=sha((q/'payload.tgz').read_bytes()),requiredFreeBytes=252*1024*1024+expanded+65536,retire=retire,identity=identity)
(q/'config.json').write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8')
ast.parse((q/'remote-launch.py').read_text(encoding='utf-8').replace('config=CONFIG','config='+repr(config)).replace('inventoryOnly=INVENTORY_ONLY','inventoryOnly=True'))
assert "source=base/'native-inputs-b597-20261112/candidate'"in(q/'remote-launch.py').read_text(encoding='utf-8')
assert 'RuntimeMaxSec=570'in(q/'remote-launch.py').read_text(encoding='utf-8')
assert 'native-inputs-cpython-b598-launch.py'in(q/'launch.py').read_text(encoding='utf-8')
print('One existing18-job external delivery checkpoint prepared,570sowner/630sobservation. Reuses frozen selected core; no new binary copies or benchmark protocol. Both current image roles protected. Fresh idle/disk proof required.')
