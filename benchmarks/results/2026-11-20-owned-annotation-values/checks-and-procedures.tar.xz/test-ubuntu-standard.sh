set -eu
export DOTNET_ROOT="$HOME/.dotnet"
export PATH="$DOTNET_ROOT:$PATH"
lab=$1
filter=$(cat "$lab/filter.txt")
dotnet test tests/Lokad.Lython.PublicApi.Tests -c Release -f net10.0 --filter "$filter"
