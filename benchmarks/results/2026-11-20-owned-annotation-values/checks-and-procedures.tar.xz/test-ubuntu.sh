set -eu
export DOTNET_ROOT="$HOME/.dotnet"
lab=$1
filter=$(cat "$lab/filter.txt")
for suite in Lokad.Lython.Tests Lokad.Lython.PublicApi.Tests; do
    log="$lab/$suite-ubuntu.log"
    "$DOTNET_ROOT/dotnet" test "tests/$suite/$suite.csproj" -c Release -f net10.0 --artifacts-path "$lab/ubuntu" --filter "$filter" >"$log" 2>&1 || { tail -n 35 "$log"; exit 1; }
    tail -n 8 "$log"
done
