from hashlib import sha256
import json
from pathlib import Path
from shutil import copy2, copytree
from subprocess import check_output
import tarfile


lab = Path(__file__).resolve().parent
repo = lab.parents[3]
historical = lab.parent / 'fresh-command-cpython-b1970-20261128'
donor = lab.parent / 'owner-type-new-slots-b1990-20261128' / 'comparison'
quiet = lab / 'comparison/quiet'
template = historical / 'comparison/quiet'
stage = 'script-current-cpython-fresh-b1992-release-20261128'
revision = '04159957a'


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8', newline='\n')


identity = read(donor / 'quiet/identity.json')
terminal = read(donor / 'quiet/terminal-status.json')
receipt = terminal['receipt']
assert not terminal['live'] and not terminal['fixtures'] and terminal['exitCode'] == '0'
assert receipt['complete'] and receipt['quietBeforeAndAfter'] and receipt['allWorkersJoined']
assert receipt['archiveSHA256'] == digest(donor / 'quiet/observations.tar.xz')
patch = check_output(['git', 'diff', '--binary', identity['sourceRevision'], revision, '--', 'src', 'tests'], cwd=repo)
assert sha256(patch).hexdigest() == identity['sourcePatchSHA256']
files = identity['imageFiles']['candidate']
assert len(files) == 32 and {path.name: digest(path) for path in (donor / 'candidate').iterdir()} == files
quiet.mkdir(parents=True, exist_ok=True)
if not (quiet / 'local-image').exists():
    copytree(donor / 'candidate', quiet / 'local-image')
assert {path.name: digest(path) for path in (quiet / 'local-image').iterdir()} == files
for name in ('representative.json', 'jobs.json', 'collect.py', 'run.sh', 'cpython-worker.py'):
    copy2(template / name, quiet / name)
assert digest(quiet / 'cpython-worker.py') == identity['cpythonWorkerSHA256']
assert b'\r' not in (quiet / 'run.sh').read_bytes()
assert len(read(quiet / 'representative.json')['cases']) == 2
identity.update(sourceRevision=check_output(['git', 'rev-parse', revision], cwd=repo).decode().strip(),
    purpose='Measure fresh commands on the landed B1990 core.',
    imageFiles={'candidate': files}, coreSHA256={role: files['Lokad.Lython.dll'] for role in ('candidate', 'candidate-control')},
    frozenImage=f'/home/lokad/lython-bench-checks/{stage}/candidate',
    catalogs={name: {'sha256': digest(quiet / name)} for name in ('representative.json', 'jobs.json')},
    donorArchiveSHA256=receipt['archiveSHA256'])
save(quiet / 'identity.json', identity)

paths = {name: quiet / name for name in ('identity.json', 'representative.json', 'jobs.json', 'cpython-worker.py', 'run.sh', 'collect.py')}
payload = quiet / 'stage.tar.gz'
with tarfile.open(payload, 'w:gz') as archive:
    for name, path in paths.items():
        archive.add(path, arcname=name)
with tarfile.open(payload) as archive:
    assert all(sha256(archive.extractfile(name).read()).hexdigest() == digest(path) for name, path in paths.items())
save(quiet / 'upload.json', dict(root=stage, donor=read(donor / 'quiet/upload.json')['root'], donorFiles=files,
    donorArchive=receipt['archiveSHA256'], payloadSHA256=digest(payload),
    files={name: dict(length=path.stat().st_size, sha256=digest(path)) for name, path in paths.items()},
    expandedBytes=sum(path.stat().st_size for path in paths.values()), minimumAfterStageBytes=3 * 1024 * 1024, caseCount=2))
for name, old, new in (
    ('quiet-vm.py', 'lython-b1970-fresh-command-cpython', 'lython-b1992-current-fresh-cpython'),
    ('verify.sh', historical.name, lab.name),
    ('summarize.py', '83042273c', revision),
):
    script = (historical / name).read_text(encoding='utf-8')
    assert script.count(old) == 1
    (lab / name).write_text(script.replace(old, new), encoding='utf-8', newline='\n')
