from pathlib import Path
import shutil
r=Path(__file__).parent;d=r/'allocation-short';d.mkdir()
source=(r.parent/'format-sinks-r416/allocation/Program.cs').read_text(encoding='utf-8')
source=source.replace('i < 128 || warm.Elapsed < TimeSpan.FromSeconds(4)','i < 4 || warm.Elapsed < TimeSpan.FromSeconds(0.5)').replace('block < 5','block < 3').replace('i < 64','i < 4').replace('/ 64.0','/ 4.0')
(d/'Program.cs').write_text(source,encoding='utf-8',newline='\n')
shutil.copyfile(r.parent/'format-sinks-r416/allocation/Allocation.csproj',d/'Allocation.csproj')
shutil.copyfile(r/'catalog.json',d/'catalog.json')
shutil.copyfile(r/'measure-allocation.py',r/'original-long-measure-allocation.py')
s=(r/'measure-allocation.py').read_text(encoding='utf-8').replace("d=r/'allocation-corrected'","d=r/'allocation-short'")
(r/'measure-allocation.py').write_text(s,encoding='utf-8',newline='\n')
print('Existing allocation diagnostic resized: >=4/.5s warmup,3x4 observations; same images/goldens/budget/cleanup. Original timeout/procedure preserved.')
