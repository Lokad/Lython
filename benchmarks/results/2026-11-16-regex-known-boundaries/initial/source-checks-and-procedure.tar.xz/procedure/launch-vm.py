from pathlib import Path
import ast,datetime,hashlib,json,shlex,subprocess,tarfile

r=Path(__file__).parent;q=r/'quiet';q.mkdir();old=r.parent/'format-operation-r419/quiet'
root='/home/lokad/lython-bench-checks/regex-boundaries-b817-20261116';unit='lython-b817-regex-boundaries-20261116'
f=json.loads((r/'frozen/identity.json').read_text(encoding='utf-8'));keys=set(json.loads((old/'identity.json').read_text(encoding='utf-8'))['imageFiles']['candidate'])
images={role:{n:h for n,h in files.items()if n in keys}for role,files in f['images'].items()}
identity=dict(sourceRevision='R422 uncommitted'+images['candidate']['Lokad.Lython.dll'][:8]+' versus qualifiedc023042d/frozen0393331a',purpose='Known subject/window scalar anchors replace repeated Unicode capture walks. Growing complete lookahead scripts plus ASCII/short-capture controls; ordinary released PythonRe0.4 unchanged. Not isolated CPU or universal regex throughput.',coreSHA256={label:images['candidate'if label.startswith('candidate')else'reference']['Lokad.Lython.dll']for label in ['candidate','candidate-control','reference','reference-control']},imageFiles=images,prototype=True,publicationHeld=True,candidateSourceIdentitySHA256=hashlib.sha256((r/'frozen/identity.json').read_bytes()).hexdigest())
(q/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
catalog=json.loads((r/'catalog.json').read_text(encoding='utf-8'));jobs=[[c['id'],'warm']for c in catalog['cases']]
for n in ['collect.py','archive-owned.py','run.sh','retrieve.py']:
    s=(old/n).read_text(encoding='utf-8').replace('format-operation-b814-20261115','regex-boundaries-b817-20261116').replace('lython-b814-format-operation-20261115',unit).replace('B814','B817')
    if n=='collect.py':
        a=s.index('jobs=');b=s.index('\nenv =',a);s=s[:a]+'jobs='+repr(jobs)+"\nassert len(jobs)==4 and all(case in cases for case,lane in jobs)\n"+s[b:]
        s=s.replace("catalog = root/('additional.json' if case_id=='scripts.report-render.format-method.large' else 'representative.json')","catalog = root/'representative.json'")
    if n.endswith('.py'):ast.parse(s)
    (q/n).write_text(s,encoding='utf-8',newline='\n')
shutil=None
(q/'representative.json').write_bytes((r/'catalog.json').read_bytes())
with tarfile.open(q/'payload.tgz','w:gz')as a:
    for n in ['identity.json','collect.py','archive-owned.py','run.sh','representative.json']:a.add(q/n,arcname=n)
    a.add(r/'frozen/candidate/Lokad.Lython.dll',arcname='candidate/Lokad.Lython.dll')
with tarfile.open(q/'payload.tgz')as a:size=sum(m.size for m in a if m.isfile())
proof=json.loads((r/'historical-aliases.json').read_text(encoding='utf-8'))
assert subprocess.check_output(['git','show',proof['custody']['commit']+':'+proof['custody']['archive']])==Path(proof['custody']['archive']).read_bytes()
c=dict(root=root,unit=unit,source='/home/lokad/lython-bench-checks/format-operation-b814-20261115',sourceFiles=images['reference'],sourceCatalogSHA256=hashlib.sha256((old/'retrieved/representative.json').read_bytes()).hexdigest(),catalogSHA256=hashlib.sha256((q/'representative.json').read_bytes()).hexdigest(),identity=identity,retireGroups=[proof],payloadBytes=(q/'payload.tgz').stat().st_size,payloadSHA256=hashlib.sha256((q/'payload.tgz').read_bytes()).hexdigest(),unpackedBytes=size)
(q/'config.json').write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
oldcode=(old/'remote-launch.py').read_text(encoding='utf-8');code=oldcode[:oldcode.index('c=')]+ 'c='+repr(c)+'\n'+oldcode[oldcode.index("b=Path("):]
code=code.replace("os.link(source/'representative.json',root/'representative.json');","assert sha(root/'representative.json')==c['catalogSHA256'];").replace('lython-b809-fixtures','lython-b817-fixtures')
ast.parse(code);(q/'remote-launch.py').write_text(code,encoding='utf-8',newline='\n')
ssh=['C:/Windows/System32/OpenSSH/ssh.exe','-i','C:/Users/JoannesVermorel/.ssh/id_lython-bench.pem','-o','BatchMode=yes','-o','ConnectTimeout=15','lokad@20.166.121.73']
p=subprocess.run(ssh+['python3 -c '+shlex.quote(code)],input=(q/'payload.tgz').read_bytes(),capture_output=True,timeout=45);(q/'launch.log').write_bytes(p.stdout+p.stderr);assert p.returncode==0,(p.stdout+p.stderr).decode('utf-8','replace')
now=datetime.datetime.now(datetime.timezone.utc);(q/'observe-not-before.json').write_text(json.dumps(dict(startedUTC=now.isoformat(),doNotObserveBeforeUTC=(now+datetime.timedelta(seconds=200)).isoformat(),ownerSeconds=240),indent=2)+'\n',encoding='utf-8',newline='\n')
print(p.stdout.decode('utf-8'),flush=True)
