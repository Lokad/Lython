import re
text='é😀a'*64
matches=list(re.finditer(r'(?=(.*))',text))
print(len(matches),sum(m.start() for m in matches),sum(m.end(1) for m in matches))
print(matches[0].regs,matches[-1].regs,matches[17].group(1)==text[17:])
re.purge()
print(matches[0].string is text,matches[0].span(1),matches[-1].group(1))
