import re
text='é😀a'*64
p=re.compile(r'(?<=(..))(?=(.*))|(?P<missing>Z)')
matches=list(p.finditer(text,5,len(text)-7))
print(len(matches),sum(m.start() for m in matches),sum(m.end(2) for m in matches))
print(matches[0].regs,matches[-1].regs,matches[0].pos,matches[0].endpos)
re.purge()
print(matches[0].group(1)==text[3:5],matches[0].group(2)==text[5:-7],matches[-1].group(2),matches[-1].span('missing'))
