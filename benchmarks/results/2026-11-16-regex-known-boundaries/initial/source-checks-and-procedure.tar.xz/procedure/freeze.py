from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile

r=Path(__file__).parent;f=r/'frozen';f.mkdir();images={}
base=r.parent/'format-operation-r419/frozen/candidate'
for role in ['reference','candidate']:
    target=f/role;shutil.copytree(base,target)
    if role=='candidate':shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',target/'Lokad.Lython.dll')
    images[role]={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in target.iterdir()if p.is_file()}
assert images['reference']['Lokad.Lython.dll']=='0393331afcdd9bffcb3dc1b2e1764316df152a20749ec08cec0c51f6e9a1b12f'
assert all(images['candidate'][n]==h for n,h in images['reference'].items()if n!='Lokad.Lython.dll')
paths=subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True).splitlines()
paths+=['Directory.Build.props','Directory.Packages.props','NuGet.Config','global.json','tests/Lokad.Lython.Tests/RegexScalarCursorCancellationTests.cs','tests/Lokad.Lython.PublicApi.Tests/RegexScalarCursorTests.cs']
sources={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in paths}
with tarfile.open(f/'sources-and-checks.tar.xz','w:xz')as a:
    for p in paths:a.add(p,arcname=p)
    for p in (r/'checks').iterdir():
        if p.is_file():a.add(p,arcname='checks/'+p.name)
identity=dict(baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),prototype=True,images=images,sources=sources,contracts='Nearest known scalar anchor replaces repeated prefix/suffix walking; no map/cache/provider/dependency or memory policy. Unicode original-window captures, cancellation/refusal/owners unchanged.')
(f/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')
cases=[];sha=lambda s:hashlib.sha256(s.encode('utf-8')).hexdigest()
for label,n,atom,pattern in [('unicode-tail',1024,'é😀a','(?=(.*))'),('unicode-tail',4096,'é😀a','(?=(.*))'),('ascii-tail',4096,'abc','(?=(.*))'),('unicode-short',4096,'é😀a','(?=(.))')]:
    text=(atom*((n+2)//3))[:n]
    source=f"import re\ntext={text!r}\ncount=0\nchecksum=0\nfor m in re.finditer({pattern!r},text):\n count+=1\n checksum+=m.start()+m.end(1)\nprint(count,checksum)\n"
    expected=f'{n+1} {3*n*(n+1)//2}\n'if pattern=='(?=(.*))'else f'{n} {n*n}\n'
    run=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8','-c',source],capture_output=True,text=True,encoding='utf-8',timeout=10);assert run.returncode==0 and run.stdout==expected,(label,n,run.stdout,run.stderr)
    fixture=json.dumps(dict(size=n,text=''),separators=(',',':'))
    cases.append(dict(id=f'diagnostic.regex.{label}.{n}',family='regex',category='diagnostic',scale=str(n),size=n,source=source,fixtureJson=fixture,expectedOutput=expected,sourceSha256=sha(source),fixtureSha256=sha(fixture),expectedOutputSha256=sha(expected)))
catalog=dict(schemaVersion=1,catalogVersion=1,fixtureEncoding='No files; exact literal UTF8 subject and independent arithmetic checksum',entropySeed='0x5EED1234',performanceQualified=False,cases=cases)
(r/'catalog.json').write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
d=r/'allocation';d.mkdir();shutil.copyfile(r/'catalog.json',d/'catalog.json')
for p in(r.parent/'format-operation-r419/allocation/bin/Release/net11.0').glob('ValidatedAllocation.*'):
    dst=d/'bin/Release/net11.0'/p.name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst)
s=(r.parent/'format-operation-r419/measure-allocation.py').read_text(encoding='utf-8');(r/'measure-allocation.py').write_text(s,encoding='utf-8',newline='\n')
print(dict(core={role:v['Lokad.Lython.dll']for role,v in images.items()},sourceInputs=len(paths),independentPythonGoldens=len(cases)))
