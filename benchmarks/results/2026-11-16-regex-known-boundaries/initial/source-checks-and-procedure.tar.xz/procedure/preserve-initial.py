from pathlib import Path
import hashlib,json,shutil,tarfile

r=Path(__file__).parent;out=Path('benchmarks/results/2026-11-16-regex-known-boundaries/initial');out.mkdir(parents=True)
q=r/'quiet';receipt=json.loads((q/'archive-receipt.json').read_text(encoding='utf-8'));assert receipt['complete']and receipt['allWorkersJoined']and hashlib.sha256((q/'observations.tgz').read_bytes()).hexdigest()==receipt['archiveSHA256']
for source,n in [(r/'summary.json','summary.json'),(r/'allocation-summary.json','allocation-summary.json'),(r/'focused-checks.json','focused-checks.json'),(r/'cpython-semantics.json','cpython-semantics.json'),(r/'frozen/identity.json','identity.json'),(q/'observations.tgz','observations.tgz'),(q/'archive-receipt.json','archive-receipt.json'),(q/'terminal-status.json','terminal-status.json')]:shutil.copyfile(source,out/n)
p=out/'allocation-summary.json';v=json.loads(p.read_text(encoding='utf-8'));v['boundary']='Local complete warm runs with empty file fixtures/reset/full stdout and file goldens/result disposal. >=4/.5s warmup,3x4 allocation observations, natural process-wide counters. Compile/startup/final cache teardown excluded. No elapsed/CPU claim.';p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n')
with tarfile.open(out/'source-checks-and-procedure.tar.xz','w:xz')as a:
    for n in ['sources-and-checks.tar.xz','reference/Lokad.Lython.dll','candidate/Lokad.Lython.dll']:a.add(r/'frozen'/n,arcname='frozen/'+n)
    for p in r.iterdir():
        if p.is_file():a.add(p,arcname='procedure/'+p.name)
    for p in q.iterdir():
        if p.is_file()and p.name not in {'observations.tgz','payload.tgz'}:a.add(p,arcname='quiet/'+p.name)
    for directory in ['allocation','allocation-corrected','allocation-short']:
        for p in (r/directory).iterdir():
            if p.is_file():a.add(p,arcname=directory+'/'+p.name)
    for p in (r/'allocation-short/bin/Release/net11.0').glob('ValidatedAllocation.*'):a.add(p,arcname='allocation-driver/'+p.name)
    a.add(r/'checks',arcname='checks')
(out/'README.md').write_text('''# Initial known-boundary projection — retained adverse evidence

R422/B817,2026-11-16, uncommitteddcf39f7f versus fully-qualifiedc023042d/
0393331a. Ordinary released PythonRe0.4 and complete worker/auxiliary images
identical. Four complete scripts iterate real captures and check independent
arithmetic goldens: Unicode suffix lookahead at1,024/4,096scalars, ASCII suffix
and short Unicode capture controls at4,096. Not representative file processing,
isolated core CPU or a general linear-regex claim. Two engine processes/source,
5s full-request warmups/five rotated~0.5s rounds, normal GC/tiering, quiet F4as_v7
Ubuntu24.04.4/four EPYC9V45vCPUs/16GiB/no swap/.NET11RC3.

| Case | Elapsed change | Wider process CPU change | Reference/candidate spread |
| --- | ---: | ---: | ---: |
| Unicode suffix1,024 |−11.45..−8.30%|−11.11..−7.41%|3.16/0.40%|
| Unicode suffix4,096 |−4.77..−3.43%|−3.28%|0.94/0.47%|
| ASCII suffix4,096 |−0.60..+0.66%|−1.75..0%|0.44/0.82%|
| Unicode short4,096 |−0.08..+4.72%|0..+3.05%|1.06/3.70%|

All source/control pairings preserved; positive means slower. Existing backend
capture-text staging remains quadratic in these suffix cases and dominates
larger inputs. These clocks do not isolate that causal share or prove new
whole-script asymptotic behavior. The short control is adverse/moving, not parity.

The algorithm replaces the origin-only reset with nearest known subject/window
anchors, using the existing bidirectional cursor and coordinate buffer. Keeps
window bounds16B/invocation; allocation otherwise flat. No dense map/cache, new
owner, API/backend/dependency or policy. All64internal/363public regex cases
pass each actual.NET11/10, including active backward-scan cancellation, refusal,
joined provider/alias cleanup and baseline reuse. Two additional complete Python
programs independently agree with CPython3.13.2 on original windows/empty groups/
retained suffix captures. Four growing-input goldens agree too.

Local allocation initially encounters an unsupported empty non-file fixture in
the reused file-only diagnostic, before sampling. Identical empty file maps fix
that driver condition without changing guest work. Its original hundreds-of-calls
procedure then exceeds60s and the child is killed/joined; that failed run has no
cleanup/qualification witness. Preserve both original conditions. The corrected
bounded diagnostic uses>=4/.5s warmup and3x4 observations, checks every stdout/file
golden and budget baseline/final zero, completes26.639s. Each case adds16B; no
allocation reduction or local timing claim.

B817four jobs complete152.693s; every full-image/golden/budget/quiet/Closed/exit/
join/archive gate passes, all workers and RAM fixtures removed. Raw archive
SHA verified locally and under lease. Only prior9d runtime's exact committed
archived replicas retired after fresh UID/path/hash/link/all-alias proofs;
current039 and newdcf images/toolchains remain at this capture.254/252MiB floors
unchanged. Terminal cached forever. Warm includes Run/backend/output validation/
prior-result cleanup; reset/protocol/startup/compilation/final cached teardown
excluded. WiderCPU includes reset/protocol; no pending-I/O/RSS/tail claim.

**Decision:** bounded source refinement removes duplicate full-window anchor
comparisons identified alongside short-capture adversity. Do not discard these
results or claim refinement fixes them before its own source/control comparison.
No full platform/package qualification of this initial prototype. Publication held.
[All medians](summary.json),[allocation](allocation-summary.json),
[focused checks](focused-checks.json),[exact source/images/procedures/conditions](source-checks-and-procedure.tar.xz),
[raw](observations.tgz). Broader non-regex work remains independent.
''',encoding='utf-8',newline='\n')
p=Path('benchmarks/EXPERIMENTS.md');s=p.read_text(encoding='utf-8');s+='\n\n[R422/B817 initial scalar-boundary correction](results/2026-11-16-regex-known-boundaries/initial/README.md): normal0.4 real backend, Unicode suffix elapsed8–11%/3–5%lower at1,024/4,096scalars, allocation+16B. ASCII mixed; short Unicode up to4.72%slower with3.70%candidate spread. Retain every adverse control and failed allocation-driver condition. One justified source refinement removes duplicate full-window anchors; no unchanged retiming or broader objective completion.\n';p.write_text(s,encoding='utf-8',newline='\n')
print('B817 source/cores, controls, original failed allocation conditions and complete cleanup proof preserved.')
