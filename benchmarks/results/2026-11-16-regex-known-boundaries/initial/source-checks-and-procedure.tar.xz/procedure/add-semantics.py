from pathlib import Path
import json,subprocess

r=Path(__file__).parent
cases=[
"""import re
text='é😀a'*64
matches=list(re.finditer(r'(?=(.*))',text))
print(len(matches),sum(m.start() for m in matches),sum(m.end(1) for m in matches))
print(matches[0].regs,matches[-1].regs,matches[17].group(1)==text[17:])
re.purge()
print(matches[0].string is text,matches[0].span(1),matches[-1].group(1))
""",
"""import re
text='é😀a'*64
p=re.compile(r'(?<=(..))(?=(.*))|(?P<missing>Z)')
matches=list(p.finditer(text,5,len(text)-7))
print(len(matches),sum(m.start() for m in matches),sum(m.end(2) for m in matches))
print(matches[0].regs,matches[-1].regs,matches[0].pos,matches[0].endpos)
re.purge()
print(matches[0].group(1)==text[3:5],matches[0].group(2)==text[5:-7],matches[-1].group(2),matches[-1].span('missing'))
"""
]
values=[]
for i,source in enumerate(cases):
    p=r/f'case-{i}.py';p.write_text(source,encoding='utf-8',newline='\n')
    run=subprocess.run(['C:/Python313/python.exe','-I','-S','-X','utf8',str(p)],capture_output=True,text=True,encoding='utf-8',timeout=10)
    assert run.returncode==0,run.stderr
    values.append(dict(source=source,expected=run.stdout))
    print(run.stdout,end='')
(r/'cpython-semantics.json').write_text(json.dumps(dict(version=subprocess.check_output(['C:/Python313/python.exe','--version'],text=True).strip(),cases=values),indent=2)+'\n',encoding='utf-8',newline='\n')
p=Path('tests/Lokad.Lython.PublicApi.Tests/RegexScalarCursorTests.cs');s=p.read_text(encoding='utf-8')
marker='    };\n\n    [Theory]';assert s.count(marker)==1
lines=''.join('        { '+json.dumps(c['source'],ensure_ascii=False)+', '+json.dumps(c['expected'],ensure_ascii=False)+' },\n'for c in values)
s=s.replace(marker,lines+marker);p.write_text(s,encoding='utf-8',newline='\n')
