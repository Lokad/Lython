from pathlib import Path
import hashlib,json,shutil
r=Path(__file__).parent;shutil.copyfile(r/'catalog.json',r/'original-no-file-fixture-catalog.json')
v=json.loads((r/'catalog.json').read_text(encoding='utf-8'))
for c in v['cases']:
    f=json.loads(c['fixtureJson']);f.update(inputFiles={},outputFiles={});c['fixtureJson']=json.dumps(f,separators=(',',':'));c['fixtureSha256']=hashlib.sha256(c['fixtureJson'].encode()).hexdigest();c['expectedFilesSha256']=hashlib.sha256(bytes(4)).hexdigest()
(r/'catalog.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
d=r/'allocation-corrected';d.mkdir();shutil.copyfile(r/'catalog.json',d/'catalog.json')
for p in(r/'allocation/bin/Release/net11.0').glob('ValidatedAllocation.*'):
    dst=d/'bin/Release/net11.0'/p.name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst)
shutil.copyfile(r/'measure-allocation.py',r/'original-measure-allocation.py')
s=(r/'measure-allocation.py').read_text(encoding='utf-8').replace("d=r/'allocation'","d=r/'allocation-corrected'");(r/'measure-allocation.py').write_text(s,encoding='utf-8',newline='\n')
print('Original unsupported no-file allocation-host condition retained; both sources now use identical empty file maps/full goldens. No timing retried.')
