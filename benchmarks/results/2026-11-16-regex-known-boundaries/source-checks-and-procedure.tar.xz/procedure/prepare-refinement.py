from pathlib import Path
import ast,shutil
root=Path(__file__).parent;r=root/'refinement'
s=(root/'freeze.py').read_text(encoding='utf-8');s=s[:s.index('cases=[];')]
s=s.replace("r.parent/'format-operation-r419","r.parent.parent/'format-operation-r419")
s+="""
shutil.copyfile(r.parent/'catalog.json',r/'catalog.json')
d=r/'allocation-short';d.mkdir();shutil.copyfile(r/'catalog.json',d/'catalog.json')
for p in(r.parent/'allocation-short/bin/Release/net11.0').glob('ValidatedAllocation.*'):
    dst=d/'bin/Release/net11.0'/p.name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst)
(r/'measure-allocation.py').write_text((r.parent/'measure-allocation.py').read_text(encoding='utf-8'),encoding='utf-8',newline='\\n')
print(dict(core={role:v['Lokad.Lython.dll']for role,v in images.items()},sourceInputs=len(paths)))
"""
ast.parse(s);(r/'freeze.py').write_text(s,encoding='utf-8',newline='\n')
s=(root/'inspect-vm.py').read_text(encoding='utf-8').replace('2026-11-15-runtime-format-operation/source-checks-and-procedure.tar.xz','2026-11-16-regex-known-boundaries/initial/source-checks-and-procedure.tar.xz').replace("member='frozen/reference/Lokad.Lython.dll'","member='frozen/candidate/Lokad.Lython.dll'").replace('9d071eba52291e91d609b6887195485c3e92d7e84538f8513cbe2dbd548cdbd2','dcf39f7fdb7a5e13e7203162c780e219e22f90b5e184f5da870845bab5b2286f').replace("r.parent/'format-sinks-r416","r.parent.parent/'format-sinks-r416").replace('format-operation-b814-20261115/reference','regex-boundaries-b817-20261116/candidate')
ast.parse(s);(r/'inspect-vm.py').write_text(s,encoding='utf-8',newline='\n')
s=(root/'launch-vm.py').read_text(encoding='utf-8').replace("r.parent/'format-operation-r419","r.parent.parent/'format-operation-r419").replace('regex-boundaries-b817-20261116','regex-boundaries-b818-20261116').replace('lython-b817-regex-boundaries-20261116','lython-b818-regex-boundaries-20261116').replace('B817','B818').replace('lython-b817-fixtures','lython-b818-fixtures')
ast.parse(s);(r/'launch-vm.py').write_text(s,encoding='utf-8',newline='\n')
shutil.copyfile(root/'summarize.py',r/'summarize.py')
print('Prepared one changed-source confirmation; original complete scripts/controls/settings preserved.')
