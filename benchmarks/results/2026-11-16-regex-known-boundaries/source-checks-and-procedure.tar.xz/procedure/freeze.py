from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile

r=Path(__file__).parent;f=r/'frozen';f.mkdir();images={}
base=r.parent.parent/'format-operation-r419/frozen/candidate'
for role in ['reference','candidate']:
    target=f/role;shutil.copytree(base,target)
    if role=='candidate':shutil.copyfile('src/Lokad.Lython/bin/Release/net11.0/Lokad.Lython.dll',target/'Lokad.Lython.dll')
    images[role]={p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in target.iterdir()if p.is_file()}
assert images['reference']['Lokad.Lython.dll']=='0393331afcdd9bffcb3dc1b2e1764316df152a20749ec08cec0c51f6e9a1b12f'
assert all(images['candidate'][n]==h for n,h in images['reference'].items()if n!='Lokad.Lython.dll')
paths=subprocess.check_output(['git','ls-files','src/Lokad.Lython'],text=True).splitlines()
paths+=['Directory.Build.props','Directory.Packages.props','NuGet.Config','global.json','tests/Lokad.Lython.Tests/RegexScalarCursorCancellationTests.cs','tests/Lokad.Lython.PublicApi.Tests/RegexScalarCursorTests.cs']
sources={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in paths}
with tarfile.open(f/'sources-and-checks.tar.xz','w:xz')as a:
    for p in paths:a.add(p,arcname=p)
    for p in (r/'checks').iterdir():
        if p.is_file():a.add(p,arcname='checks/'+p.name)
identity=dict(baseCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),prototype=True,images=images,sources=sources,contracts='Nearest known scalar anchor replaces repeated prefix/suffix walking; no map/cache/provider/dependency or memory policy. Unicode original-window captures, cancellation/refusal/owners unchanged.')
(f/'identity.json').write_text(json.dumps(identity,indent=2)+'\n',encoding='utf-8',newline='\n')

shutil.copyfile(r.parent/'catalog.json',r/'catalog.json')
d=r/'allocation-short';d.mkdir();shutil.copyfile(r/'catalog.json',d/'catalog.json')
for p in(r.parent/'allocation-short/bin/Release/net11.0').glob('ValidatedAllocation.*'):
    dst=d/'bin/Release/net11.0'/p.name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dst)
(r/'measure-allocation.py').write_text((r.parent/'measure-allocation.py').read_text(encoding='utf-8'),encoding='utf-8',newline='\n')
print(dict(core={role:v['Lokad.Lython.dll']for role,v in images.items()},sourceInputs=len(paths)))
