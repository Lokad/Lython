using Lokad.Lython.Frontend;
using Lokad.Lython.Runtime.Text;

namespace Lokad.Lython.Runtime;

internal sealed class FunctionBindingPlan
{
    public FunctionBindingPlan(
        string callableName,
        PythonCallableKind callableKind,
        IReadOnlyList<LoweredFunctionParameter> parameters,
        IReadOnlyDictionary<string, object> defaultValues,
        LythonRuntime.ExecutionContext? context = null,
        ExecutableCodeObject? codeObject = null)
    {
        var governor = context?.MemoryGovernor;
        // Executable parameter slots are already the compiler's local prefix.
        // Only runtime-generated/lowered signatures need a new names/map owner.
        var layoutBytes = codeObject is not null || parameters.Count == 0 ? 0 : 128L + 128L * parameters.Count;
        governor?.Reserve(layoutBytes, null);
        try
        {
            CallableName = callableName;
            CallableKind = callableKind;
            var variadicList = false;
            var variadicDictionary = false;
            foreach (var parameter in parameters)
            {
                switch (parameter.Kind)
                {
                    case FunctionParameterKind.PositionalOnly: PositionalCount++; PositionalOnlyCount++; break;
                    case FunctionParameterKind.Positional: PositionalCount++; break;
                    case FunctionParameterKind.KeywordOnly: KeywordOnlyCount++; break;
                    case FunctionParameterKind.VariadicList: variadicList = true; break;
                    case FunctionParameterKind.VariadicDictionary: variadicDictionary = true; break;
                    default: throw new InvalidOperationException("Unknown function parameter kind.");
                }
            }
            NamedLayoutCount = PositionalCount + KeywordOnlyCount;
            ParameterCount = parameters.Count;
            VariadicListIndex = variadicList ? NamedLayoutCount : -1;
            VariadicDictionaryIndex = variadicDictionary ? NamedLayoutCount + (variadicList ? 1 : 0) : -1;
            if (codeObject is not null)
            {
                ParameterNames = codeObject.LocalNames;
                LayoutParameterIndex = codeObject.LocalNameToSlot;
            }
            else
            {
                var names = ParameterCount == 0 ? [] : new string[ParameterCount];
                var indexes = new Dictionary<string, int>(ParameterCount, StringComparer.Ordinal);
                var positional = 0;
                var keywordOnly = PositionalCount;
                foreach (var parameter in parameters)
                {
                    var slot = parameter.Kind switch
                    {
                        FunctionParameterKind.PositionalOnly or FunctionParameterKind.Positional => positional++,
                        FunctionParameterKind.KeywordOnly => keywordOnly++,
                        FunctionParameterKind.VariadicList => VariadicListIndex,
                        FunctionParameterKind.VariadicDictionary => VariadicDictionaryIndex,
                        _ => throw new InvalidOperationException("Unknown function parameter kind.")
                    };
                    names[slot] = parameter.Name;
                    indexes.Add(parameter.Name, slot);
                }
                ParameterNames = names;
                LayoutParameterIndex = indexes;
            }

            var nameStorageBytes = KeywordOnlyCount == 0 ? 0 : 32L + 8L * KeywordOnlyCount;
            governor?.Reserve(nameStorageBytes, null);
            try { KeywordDefaultNames = KeywordOnlyCount == 0 ? [] : new PyString[KeywordOnlyCount]; }
            catch { governor?.ReleaseReserved(nameStorageBytes); throw; }
            governor?.Commit(nameStorageBytes);
            try
            {
                for (var i = 0; i < KeywordDefaultNames.Length; i++)
                    KeywordDefaultNames[i] = context is null
                        ? PyString.FromString(ParameterNames[PositionalCount + i])
                        : PyString.FromString(ParameterNames[PositionalCount + i], context.MemoryGovernor, null);

                var firstDefault = PositionalCount;
                while (firstDefault > 0 && defaultValues.ContainsKey(ParameterNames[firstDefault - 1])) firstDefault--;
                var count = PositionalCount - firstDefault;
                if (count != 0)
                    PositionalDefaults = context is null
                        ? new PyTuple(Enumerable.Range(firstDefault, count).Select(i => defaultValues[ParameterNames[i]]))
                        : new PyTuple(Enumerable.Range(firstDefault, count).Select(i => defaultValues[ParameterNames[i]]), context.MemoryGovernor);

                for (var i = 0; i < KeywordOnlyCount; i++)
                {
                    if (!defaultValues.TryGetValue(ParameterNames[PositionalCount + i], out var value)) continue;
                    var dictionary = KeywordDefaultStorage;
                    if (dictionary is null)
                    {
                        dictionary = context is null ? new PyDict() : new PyDict(context.MemoryGovernor);
                        KeywordDefaults = dictionary;
                    }
                    dictionary.SetItem(KeywordDefaultNames[i], value);
                }
            }
            catch
            {
                // These values have not escaped the constructor. Refunding only
                // their new storage preserves funding for the supplied default values.
                if (governor is not null)
                {
                    if (PositionalDefaults is { } positionalDefaults) governor.RefundUnpublishedValue(positionalDefaults);
                    if (KeywordDefaults is { } keywordDefaults) governor.RefundUnpublishedValue(keywordDefaults);
                    foreach (var name in KeywordDefaultNames)
                        if (name is not null) governor.RefundUnpublishedValue(name);
                    governor.Release(nameStorageBytes);
                }
                throw;
            }
            governor?.Commit(layoutBytes);
        }
        catch
        {
            governor?.ReleaseReserved(layoutBytes);
            throw;
        }
    }

    public string CallableName { get; }

    public PythonCallableKind CallableKind { get; }

    public int PositionalCount { get; }
    public int KeywordOnlyCount { get; }
    public int PositionalOnlyCount { get; }
    public int NamedLayoutCount { get; }
    public int ParameterCount { get; }
    public int VariadicListIndex { get; }
    public int VariadicDictionaryIndex { get; }

    // Only the first ParameterCount names bind arguments. A compiled map also
    // contains body locals; keyword matching must exclude those, positional-only
    // parameters and variadic slots. Mutable defaults belong to this function.
    public IReadOnlyList<string> ParameterNames { get; }
    public IReadOnlyDictionary<string, int> LayoutParameterIndex { get; }

    public object? PositionalDefaults { get; private set; }
    public object? KeywordDefaults { get; private set; }
    public PyString[] KeywordDefaultNames { get; }

    public PyDict? KeywordDefaultStorage => KeywordDefaults switch
    {
        PyDict dictionary => dictionary,
        PyDefaultDict dictionary => dictionary.InnerDict,
        PyCounter dictionary => dictionary.InnerDict,
        _ => null,
    };

    public bool TryGetPositionalDefault(int parameterIndex, [MaybeNullWhen(false)] out object value)
    {
        if (PositionalDefaults is { } defaults && PyTupleLike.TryGetItems(defaults, out var items))
        {
            var index = parameterIndex - (PositionalCount - items.Count);
            if (index >= 0 && index < items.Count)
            {
                value = items[index];
                return true;
            }
        }
        value = null;
        return false;
    }

    public bool TryGetDefaultMetadata(string name, out object value)
    {
        value = name switch
        {
            "__defaults__" => PositionalDefaults ?? PyNone.Instance,
            "__kwdefaults__" => KeywordDefaults ?? PyNone.Instance,
            _ => PyNone.Instance,
        };
        return name is "__defaults__" or "__kwdefaults__";
    }

    public bool TrySetDefaultMetadata(string name, object value, LythonSourceSpan? span = null)
    {
        if (name == "__defaults__")
        {
            if (value is not PyNone && !PyTupleLike.TryGetItems(value, out _))
                throw new LythonRuntimeException("TypeError", "__defaults__ must be set to a tuple object", span);
            PositionalDefaults = value is PyNone ? null : value;
            return true;
        }
        if (name == "__kwdefaults__")
        {
            if (value is not (PyNone or PyDict or PyDefaultDict or PyCounter))
                throw new LythonRuntimeException("TypeError", "__kwdefaults__ must be set to a dict object", span);
            KeywordDefaults = value is PyNone ? null : value;
            return true;
        }
        return false;
    }
}
