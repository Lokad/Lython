from pathlib import Path
import hashlib,json,os,shutil,subprocess
root=Path(__file__).parent;out=root/'allocation';failed=out/'failed-witness';failed.mkdir(exist_ok=False)
for n in ['hash-witness.json','measurements.json','stderr.txt']:shutil.copyfile(out/'sync'/n,failed/n)
(failed/'reason.md').write_text('The initial witness printed hashes, while the existing driver expects an array return value. It failed in witness result decoding before any workload sample. Preserve that source and stderr; correct only the witness return contract. Reuse the existing images/driver and all unchanged workload/golden/ownership checks. No completed workload measurements were discarded.\n',encoding='utf-8')
repo=Path('D:/code/Lython');env=os.environ.copy();env['DOTNET_ROOT']='C:/Users/JoannesVermorel/.dotnet11';env['DOTNET_HOST_PATH']=env['DOTNET_ROOT']+'/dotnet.exe';env['PATH']=env['DOTNET_ROOT']+os.pathsep+env['PATH']
tool=next(p for p in (root.parent/'fixed-text-construction-b194/tool').rglob('complete-jobs.dll') if 'obj' not in p.parts)
identity=json.loads((out/'identity.json').read_text(encoding='utf-8'))
for role in ['baseline','candidate']:assert hashlib.sha256((out/role/'Lokad.Lython.dll').read_bytes()).hexdigest()==identity['coreSHA256'][role]
assert hashlib.sha256(tool.read_bytes()).hexdigest()==identity['toolSHA256']
for api in ['sync','async']:
 folder=out/api;folder.mkdir(exist_ok=True)
 witness=folder/'hash-witness.json';witness.write_text(json.dumps(dict(source="return [hash('Lython-é😀'), hash((1, 2.0, True))]\n"),ensure_ascii=False)+'\n',encoding='utf-8')
 with (folder/'measurements.json').open('w',encoding='utf-8') as output,(folder/'stderr.txt').open('w',encoding='utf-8') as errors:
  r=subprocess.run([env['DOTNET_HOST_PATH'],str(tool),str(out/'baseline/Lokad.Lython.Benchmarks.dll'),str(out/'candidate/Lokad.Lython.Benchmarks.dll'),str(out/'catalog.json'),str(witness),'reverse','warm',api],cwd=repo,env=env,stdout=output,stderr=errors)
 print(api,r.returncode,flush=True)
 if r.returncode:print((folder/'stderr.txt').read_text(encoding='utf-8'));raise SystemExit(r.returncode)
 result=json.loads((folder/'measurements.json').read_text(encoding='utf-8'))
 assert all(result[k] for k in ['allGoldensPassed','allBalancesZero','ownedFixturesRemoved','imageIsolationVerified'])
 print(api,'all existing allocation/semantic/ownership gates pass',flush=True)
